
# evt114 testTakerBanChanged Event
evt114 testTakerBanChanged Event




Event published by _____


Put description here


| Code | Description |
| ---- | ----------- |
| 202 | Accepted |



| Name | Type | Description | Required |
| ---- | ---- | ----------- | -------- |


| Name | Type | Description | Required |
| ---- | ---- | ----------- | -------- |
