
# evt116 bookingBanned Event
evt116 bookingBanned Event




Event published by _____


Put description here


| Code | Description |
| ---- | ----------- |
| 202 | Accepted |



| Name | Type | Description | Required |
| ---- | ---- | ----------- | -------- |


| Name | Type | Description | Required |
| ---- | ---- | ----------- | -------- |
