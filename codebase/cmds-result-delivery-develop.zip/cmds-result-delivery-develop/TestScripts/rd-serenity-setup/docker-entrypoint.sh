#!/bin/sh
echo "INFO: Processing request for rd serenity setup for integration: $1"

case $1 in
   
   "sample")
   echo -n "INFO: Setting up environment for Integration Id: sample"
   java -Dcucumber.options="--tags @IMOD_1111" -jar rd-serenity-setup-exec.jar classpath:features
   ;; 
    
    "acceptselectionsetup")
    echo -n "INFO: Setting up environment for Integration Id: acceptselectionsetup"
    java -Dcucumber.options="--tags @acceptselectionsetup" -jar rd-serenity-setup-exec.jar classpath:features
    ;; 
   
    "updateroselectionsetup")
    echo -n "INFO: Setting up environment for Integration Id: updateroselectionsetup"
    java -Dcucumber.options="--tags @updateroselectionsetup" -jar rd-serenity-setup-exec.jar classpath:features
    ;;
   
   "acceptuaselectionsetup")
    echo -n "INFO: Setting up environment for Integration Id: acceptuaselectionsetup"
    java -Dcucumber.options="--tags @acceptuaselectionsetup" -jar rd-serenity-setup-exec.jar classpath:features
    ;;
    
   "updateuaselectionsetup")
    echo -n "INFO: Setting up environment for Integration Id: updateuaselectionsetup"
    java -Dcucumber.options="--tags @updateuaselectionsetup" -jar rd-serenity-setup-exec.jar classpath:features
    ;;
   
   "acceptuaselectionsetup")
   echo -n "INFO: Setting up environment for Integration Id: acceptuaselectionsetup"
   java -Dcucumber.options="--tags @acceptuaselectionsetup" -jar rd-serenity-setup-exec.jar classpath:features
   ;;   

   "bookingeventconsumption")
   echo -n "INFO: Setting up environment for Integration Id: bookingeventconsumption"
   java -Dcucumber.options="--tags @bookingeventconsumption" -jar rd-serenity-setup-exec.jar classpath:features
   ;;

   "bookingevent")
   echo -n "INFO: Setting up environment for Integration Id: bookingevent"
   java -Dcucumber.options="--tags @bookingevent" -jar rd-serenity-setup-exec.jar classpath:features
   ;;

   "downloadtrfbookingselectionsetup")
   echo -n "INFO: Setting up environment for Integration Id: downloadtrfbookingselectionsetup"
   java -Dcucumber.options="--tags @downloadtrfbookingselectionsetup" -jar rd-serenity-setup-exec.jar classpath:features
   ;;

   "locationevent")
   echo -n "INFO: Setting up environment for Integration Id: locationevent"
   java -Dcucumber.options="--tags @locationevent" -jar rd-serenity-setup-exec.jar classpath:features
   ;;

   "rbacusersbookingsearchsetup")
   echo -n "INFO: Setting up environment for Integration Id: rbacusersbookingsearchsetup"
   java -Dcucumber.options="--tags @rbacusersbookingsearchsetup" -jar rd-serenity-setup-exec.jar classpath:features
   ;;

   "foundationresult")
   echo -n "INFO: Setting up environment for Integration Id: foundationresult"
   java -Dcucumber.options="--tags @foundationresult" -jar rd-serenity-setup-exec.jar classpath:features
   ;;

   "selectiondeliverytolasetup")
   echo -n "INFO: Setting up environment for Integration Id: selectiondeliverytolasetup"
   java -Dcucumber.options="--tags @selectiondeliverytolasetup" -jar rd-serenity-setup-exec.jar classpath:features
   ;;

   "publisheventforosrtrf")
   echo -n "INFO: Setting up environment for Integration Id: publisheventforosrtrf"
   java -Dcucumber.options="--tags @publisheventforosrtrf" -jar rd-serenity-setup-exec.jar classpath:features
   ;;

   "bookingselectionssearchsetup")
   echo -n "INFO: Setting up environment for Integration Id: bookingselectionssearchsetup"
   java -Dcucumber.options="--tags @bookingselectionssearchsetup" -jar rd-serenity-setup-exec.jar classpath:features
   ;;

   "publisheventfortrfioc")
   echo -n "INFO: Setting up environment for Integration Id: publisheventfortrfioc"
   java -Dcucumber.options="--tags @publisheventfortrfioc" -jar rd-serenity-setup-exec.jar classpath:features
   ;;

   "publisheventfortrfsetupiol")
   echo -n "INFO: Setting up environment for Integration Id: publisheventfortrfsetupiol"
   java -Dcucumber.options="--tags @publisheventfortrfsetupiol" -jar rd-serenity-setup-exec.jar classpath:features
   ;;

   "updatenonstedroselectionsetup")
   echo -n "INFO: Setting up environment for Integration Id: updatenonstedroselectionsetup"
   java -Dcucumber.options="--tags @updatenonstedroselectionsetup" -jar rd-serenity-setup-exec.jar classpath:features
   ;;

   "updatenonstedvoselectionsetup")
   echo -n "INFO: Setting up environment for Integration Id: updatenonstedvoselectionsetup"
   java -Dcucumber.options="--tags @updatenonstedvoselectionsetup" -jar rd-serenity-setup-exec.jar classpath:features
   ;;

   "updateroselectionsetup")
   echo -n "INFO: Setting up environment for Integration Id: updateroselectionsetup"
   java -Dcucumber.options="--tags @updateroselectionsetup" -jar rd-serenity-setup-exec.jar classpath:features
   ;;

   "updateuaselectionsetup")
   echo -n "INFO: Setting up environment for Integration Id: updateuaselectionsetup"
   java -Dcucumber.options="--tags @updateuaselectionsetup" -jar rd-serenity-setup-exec.jar classpath:features
   ;;

   "rdregressiontestsetup")
   echo -n "INFO: Setting up environment for Integration Id: rdregressiontestsetup"
   java -Dcucumber.options="--tags @resultdeliveryregressiontestsetup" -jar rd-serenity-setup-exec.jar classpath:features
   ;;

   "cmdsrdregressiontestsetup")
   echo -n "INFO: Setting up environment for Integration Id: cmdsrdregressiontestsetup"
   java -Dcucumber.options="--tags @cmdsrdregressiontestsetup" -jar rd-serenity-setup-exec.jar classpath:features
   ;;
   
   "consumeresultsstatusupdatesetup")
   echo -n "INFO: Setting up environment for Integration Id: consumeresultsstatusupdatesetup"
   java -Dcucumber.options="--tags @consumeresultsstatusupdatesetup" -jar rd-serenity-setup-exec.jar classpath:features
   ;;
   
   "publisheventforeorlettergenerationsetup")
   echo -n "INFO: Setting up environment for Integration Id: publisheventforeorlettergenerationsetup"
   java -Dcucumber.options="--tags @publisheventforeorlettergenerationsetup" -jar rd-serenity-setup-exec.jar classpath:features
   ;;
   
   "resultpublicationrequestedeconsumptionsetup")
   echo -n "INFO: Setting up environment for Integration Id: resultpublicationrequestedeconsumptionsetup"
   java -Dcucumber.options="--tags @resultpublicationrequestedeconsumptionsetup" -jar rd-serenity-setup-exec.jar classpath:features
   ;;
   
   "rdoutboxmanagementsetup")
   echo -n "INFO: Setting up environment for Integration Id: rdoutboxmanagementsetup"
   java -Dcucumber.options="--tags @rdoutboxmanagementsetup" -jar rd-serenity-setup-exec.jar classpath:features
   ;;
   
   "consumelegacyresultpublishedsetup")
   echo -n "INFO: Setting up environment for Integration Id: consumelegacyresultpublishedsetup"
   java -Dcucumber.options="--tags @consumelegacyresultpublishedsetup" -jar rd-serenity-setup-exec.jar classpath:features
   ;;
   *)
    echo -n "INFO: Setting up environment for New Integration Id: $WM_INTEGRATION_ID"
    java -Dcucumber.options="--tags @$WM_INTEGRATION_ID" -jar rd-serenity-setup-exec.jar classpath:features
    exit 1
    ;;
    
esac
echo "INFO: --- Setup completed ---"



