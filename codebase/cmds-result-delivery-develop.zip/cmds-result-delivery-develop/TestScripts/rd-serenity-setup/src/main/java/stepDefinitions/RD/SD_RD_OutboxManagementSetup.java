package stepDefinitions.RD;

import java.io.FileNotFoundException;
import java.io.IOException;

import common.CommonModules;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import stepImplementations.RD.SI_RD_OutboxManagementSetup;

public class SD_RD_OutboxManagementSetup extends CommonModules {
	
	CommonModules common = new CommonModules();
	SI_RD_OutboxManagementSetup stepImp = new SI_RD_OutboxManagementSetup();
    
    String hostname = "";
	Integer portnum;
	String basepath = "";
	String rdOutboxManagementDBName = "";
	String rdOutboxManagementReqCollection = "";
	String rdOutboxManagementBaseUrl="";
	String rdOutboxManagementServerCollection="";
	String mockBasePath="";
	String asyncDBName = "";
	String asyncCollectionName = "";
	String swaggerVersion=System.getenv("SWAGGER_VERSION");

	@Given("^Clean the Mongo db for new data setup for Result Delivery Mx for outbox management$")
	public void clean_the_Mongo_db_for_new_data_setup_for_Result_Delivery_Mx_for_outbox_management() throws FileNotFoundException, IOException {
		common.getEnvironmentConfigurationsOpen();
        hostname = CommonModules.getEnvironmentConfigurations("common.hostname");
        portnum = Integer.parseInt(CommonModules.getEnvironmentConfigurations("common.portnum"));

        rdOutboxManagementDBName = CommonModules.getEnvironmentConfigurations("rdOutboxManagement.DBName");
        rdOutboxManagementReqCollection = CommonModules.getEnvironmentConfigurations("rdOutboxManagement.ReqCollection");
        rdOutboxManagementServerCollection=CommonModules.getEnvironmentConfigurations("rdOutboxManagement.ServerCollection");
        
        rdOutboxManagementBaseUrl =CommonModules.getEnvironmentConfigurations("rdOutboxManagement.baseurl");
        mockBasePath = CommonModules.getEnvironmentConfigurations("common.path");
        
        asyncDBName = CommonModules.getEnvironmentConfigurations("common.RD.AsyncDBname");
        asyncCollectionName = CommonModules.getEnvironmentConfigurations("common.RD.AsyncCollection");
        
        stepImp.cleanDatebaseModule(hostname,portnum, rdOutboxManagementDBName,rdOutboxManagementServerCollection);
        stepImp.cleanDatebaseModule(hostname,portnum,rdOutboxManagementDBName,rdOutboxManagementReqCollection);
        common.cleanAsyncDBCollection(hostname,portnum, asyncDBName, asyncCollectionName);
	    
	}


	@Then("^Insert the request and responses to mongodb for Result Delivery Mx for outbox management$")
	public void insert_the_request_and_responses_to_mongodb_for_Result_Delivery_Mx_for_outbox_management() {
		if(swaggerVersion.equals("v1"))
		{
		stepImp.ConnectAndInsertRequestIntoMongoDB(hostname,portnum,rdOutboxManagementDBName,rdOutboxManagementReqCollection);
		}
		else if(swaggerVersion.equals("v2"))
		{
		stepImp.v2_ConnectAndInsertRequestIntoMongoDB(hostname, portnum, rdOutboxManagementDBName, rdOutboxManagementReqCollection);
		}
		stepImp.ConnectAndInsertServerFilesIntoMongoDB(hostname,portnum,rdOutboxManagementDBName,rdOutboxManagementServerCollection);
	    
	}

	@Then("^Setup the Server responses in Inspera Mock server for Result Delivery Mx for outbox management$")
	public void setup_the_Server_responses_in_Inspera_Mock_server_for_Result_Delivery_Mx_for_outbox_management() {
		stepImp.fetchMockDataFromMongoDB(hostname,portnum,rdOutboxManagementDBName,rdOutboxManagementServerCollection);
		stepImp.postMockDataIntoMockServer(rdOutboxManagementBaseUrl,mockBasePath);
	    
	}

}
