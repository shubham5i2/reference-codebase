package stepImplementations.RD;

import com.mongodb.*;
import com.mongodb.util.JSON;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import net.serenitybdd.core.Serenity;
import stepDefinitions.RD.SD_RD_UpdateROSelectionSetup;
import stepImplementations.RD.SI_RD_BookingCreatedConsumptionForSelectionSetup;
import stepImplementations.RD.SI_RD_ROCreatedConsumptionForSelectionSetup;
import common.CommonModules;
import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.Claim;
import com.github.javafaker.Faker;
import common.dbabstraction.CMDSMongoClientAdapter;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertEquals;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import java.util.Objects;

public class SI_RD_UpdateROSelectionSetup extends CommonModules {

	public String testdataPath = System.getenv("TEST_SETUP_FILE_PATH");
	public String var0 = testdataPath;
	int counter1 = 0;
	int cnt = 0;
	int counter = 0;
	int totalindex = 0;
	String str = "";
	String postbody = "";
	String inputjson[] = new String[6];
	int removehead = 51;
	int actResponseCode;
	static String strVal = "";
	static String strValMongoDB = "";
	String errorMessage = "";
	String queueTransactionId = "";
	String queueStatusCode = "";
	String queueStatusBody = "";
	String expectedStatusCode = " 202 ACCEPTED";
	String expectedStatusBody = "Accepted";
	static String postBodyreqMongoDB = "";
	static String eventDateTime;
	public static String postBodyreq = "";
	static String requestBody = "";
	static String curlyB = "{";
	int resPONSECODE200 = 200;
	int resPONSECODE202 = 202;
	int resPONSECODE400 = 400;
	int resPONSECODE401 = 401;
	int resPONSECODE403 = 403;
	int expectedTranLength202 = 56;
	int expectedTranLength400 = 35;
	String actResponse = "";
	int actualResponselen;
	String bookingid = null;
	static String responseFromBooking = null;
	static String responseFromBooking_headers = null;
	static String expectedTransactionID = "";
	Statement stmt = null;
	ResultSet rs = null;
	static Response response = null;
	public static boolean validationFail = true;
	boolean allFields = true;
	static boolean minimumFields = true;
	public static String externalBookId;
	public static String externalBookingReference;
	public static String organizationUuid;
	public static String testDate;
	public static String organizationUuidDB;
	public static String componentValue;
	public static String minimumScoreValue;
	public static String personDepartment;
	static String overallMinimumScoreValue;
	static Boolean validationFail1 = true;
	static String valueInJsonFile;
	static String externalSelectionId;
	static int count = 0;
	static String authTokenFromORS = "";
	static String authTokenFromAync = "";
	public static String jwtToken;

	public void cleanDatebaseModule(String hostname, Integer portnum, String dbname, String collname) {
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostname, portnum)) {
			DB db = mongoclient.getDB(dbname);
			System.out.println("Mondb connected");
			DBCollection coll = db.getCollection(collname);
			coll.remove(new BasicDBObject());
		}
	}
	
	public void connectandInsertDBdataReqDataInMongoDB(String arg1, Integer arg2, String arg3, String arg4)
			throws IOException, ParseException {

		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(arg1, arg2)) {
			DB db = mongoclient.getDB(arg3);
			DBCollection collstr = db.getCollection(arg4);
			String var1 = "/RDDB_testdata/ReferenceRequest";
			String var3 = ".json";
			int cntx = 1;
			while (counter < 1) {
				int var2 = cntx;
				String pathstr = var0 + var1 + var2 + var3;
				JSONParser parser = new JSONParser();
				Object obj = parser.parse(new FileReader(pathstr));
				JSONObject jsonObject = (JSONObject) obj;
				System.out.println("Json : " + jsonObject);
				DBObject object = (DBObject) JSON.parse(jsonObject.toString());
				collstr.insert(object);
				counter++;
				cntx++;
			}
		}
	}

	public void connectandInsertORSReqDataInMongoDB(String arg1, Integer arg2, String arg3, String arg4)
			throws IOException, ParseException {

		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(arg1, arg2)) {
			DB db = mongoclient.getDB(arg3);
			DBCollection collstr = db.getCollection(arg4);
			String var1 = "/RDUpdateSelection/ReferenceRequest";
			String var3 = ".json";
			int cntx = 1;
			while (counter < 24) {
				int var2 = cntx;
				String pathstr = var0 + var1 + var2 + var3;
				JSONParser parser = new JSONParser();
				Object obj = parser.parse(new FileReader(pathstr));
				JSONObject jsonObject = (JSONObject) obj;
				System.out.println("Json : " + jsonObject);
				DBObject object = (DBObject) JSON.parse(jsonObject.toString());
				collstr.insert(object);
				counter++;
				cntx++;
			}
		}
	}

	public void v2_connectandInsertORSReqDataInMongoDB(String arg1, Integer arg2, String arg3, String arg4)
			throws IOException, ParseException {

		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(arg1, arg2)) {
			DB db = mongoclient.getDB(arg3);
			DBCollection collstr = db.getCollection(arg4);
			String var1 = "/RDUpdateSelection/v2_ReferenceRequest";
			String var3 = ".json";
			int cntx = 1;
			while (counter < 24) {
				int var2 = cntx;
				String pathstr = var0 + var1 + var2 + var3;
				JSONParser parser = new JSONParser();
				Object obj = parser.parse(new FileReader(pathstr));
				JSONObject jsonObject = (JSONObject) obj;
				System.out.println("Json : " + jsonObject);
				DBObject object = (DBObject) JSON.parse(jsonObject.toString());
				collstr.insert(object);
				counter++;
				cntx++;
			}
		}
	}

	public void ConnectandInsertORSResDataInMongoDB(String arg1, Integer arg2, String arg3, String arg4)
			throws FileNotFoundException, IOException, ParseException {
		CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(arg1, arg2);
		DB db = mongoclient.getDB(arg3);
		System.out.println("Mondb connected");
		DBCollection collstr = db.getCollection(arg4);
		String var1 = "/RDCommonMappings/ReferenceResponse";
		String var3 = ".json";
		int cntx = 1;
		counter = 0;
		while (counter < 6) {
			int var2 = cntx;
			String pathstr = var0 + var1 + var2 + var3;
			System.out.println("pathstr :" + pathstr);
			JSONParser parser = new JSONParser();
			Object obj = parser.parse(new FileReader(pathstr));
			JSONObject jsonObject = (JSONObject) obj;
			System.out.println("Json : " + jsonObject);
			DBObject object = (DBObject) JSON.parse(jsonObject.toString());
			collstr.insert(object);
			counter++;
			cntx++;
		}
	}

	public void connectandInsertORSCommonresDataInMongoDB(String arg1, Integer arg2, String arg3, String arg4) {
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(arg1, arg2)) {
			DB db = mongoclient.getDB(arg3);
			System.out.println("Mondb connected");
			DBCollection collstr = db.getCollection(arg4);
			String Var1 = "/commonerrorcodes/CommonResponse";
			String Var3 = ".json";
			int cntl = 1;
			while (counter1 < 5) {
				int Var2 = cntl;
				String pathstr = var0 + Var1 + Var2 + Var3;
				System.out.println("pathstr :" + pathstr);
				JSONParser parser = new JSONParser();
				Object obj = parser.parse(new FileReader(pathstr));
				JSONObject jsonObject = (JSONObject) obj;
				System.out.println("Json : " + jsonObject);
				DBObject object = (DBObject) JSON.parse(jsonObject.toString());
				collstr.insert(object);
				counter1++;
				cntl++;
			}
		} catch (IOException | ParseException e) {
			e.printStackTrace();
		}
	}

	public void TakeORSMockDataFromMongoDB(String hostname, Integer portnum, String dbname, String collectionname) {
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostname, portnum)) {
			DB db = mongoclient.getDB(dbname);
			DBCollection coll = db.getCollection(collectionname);
			DBCursor cursor = coll.find();
			int i = 0;
			while (cursor.hasNext()) {

				DBObject result = cursor.next();
				str = new String(String.valueOf(result));
				Integer length = str.length();
				String subpostbody = str.substring(removehead, length);
				postbody = "{" + subpostbody;
				inputjson[i] = postbody;
				i++;
				totalindex = i;
			}
		}
	}

	public void PostORSMockDataIntoWiremock(String orsCallbackurl, String mockpath) {

		while (count < totalindex) {
			postbody = inputjson[count];
			RestAssured.baseURI = orsCallbackurl;
			System.out.println("path is:" + orsCallbackurl);
			RestAssured.basePath = "";
			Response response = given().contentType(ContentType.TEXT).log().all().body(postbody).post(mockpath);
			response.prettyPrint();
			count++;
		}
	}

	public void response(int expectedResponse) {
		try {

			actResponseCode = response.getStatusCode();
			actResponse = response.asString();
			actualResponselen = actResponse.length();
			String[] actres = actResponse.split(":");
			if (expectedResponse == actResponseCode) {
				if (expectedResponse == resPONSECODE202) {
					expectedTransactionID = actres[1].replace("\"", "").replaceAll("\\s+", "").replace("}", "");
					System.out.println(expectedTransactionID);
					String tranId = actres[0].replace("\"", "");
					tranId = tranId.replace("{", "");
					assertEquals(tranId, "transactionId");
					Serenity.recordReportData().withTitle("TransactionID").andContents(expectedTransactionID);
				} else if (expectedResponse == resPONSECODE400) {
					errorMessage = actres[1].replace("\"", "").replace("}", "");
					Serenity.recordReportData().withTitle("Error").andContents(errorMessage);
				}

			}
		} catch (Exception e) {
			Serenity.recordReportData().withTitle("").andContents(e.toString());
		}
	}

	public void cmdsRetrunsTransactiondetails(String expResponse401, String expResponse403) {
		if (actResponseCode == resPONSECODE202) {
			assertEquals(expectedTranLength202, actualResponselen);
		}
		if (actResponseCode == resPONSECODE400) {
			assertEquals(expectedTranLength400, actualResponselen);
		}
		if (actResponseCode == resPONSECODE401) {
			assertEquals(expResponse401, actResponse);
		}
		if (actResponseCode == resPONSECODE403) {
			assertEquals(expResponse403, actResponse);
		}
	}

	public static Boolean verifyFieldValueInRequest(String fieldValue) throws ParseException {
		JSONParser parser = new JSONParser();
		JSONObject json = (JSONObject) parser.parse(postBodyreq);
		try {
			ArrayList<String> json1 = new ArrayList<>();
			if (fieldValue.contains("_")) {
				String[] values = fieldValue.split("_");
				for (int i = 0; i < values.length; i++) {
					json1.add(values[i]);
				}
				for (int i = 0; i < values.length - 1; i++) {
					String counter = json1.get(i);
					valueInJsonFile = json.get(counter).toString();

					// valueInJsonFile = valueInJsonFile.replace("[{", "{").replace("}]", "}");
					System.out.println(valueInJsonFile);
					json = (JSONObject) parser.parse(valueInJsonFile);
				}
				try {
					String counter = json1.get(json1.size() - 1);
					valueInJsonFile = (String) json.get(counter);
				} catch (ClassCastException e) {
					String counter = json1.get(json1.size() - 1);
					valueInJsonFile = String.valueOf(json.get(counter));
				}

			} else {
				if (fieldValue.equalsIgnoreCase("consentGiven") || fieldValue.equalsIgnoreCase("isVoid")
						|| fieldValue.equalsIgnoreCase("bannedStatus")
						|| fieldValue.equalsIgnoreCase("specialArrangementsRequired")) {
					Boolean flag = (Boolean) json.get(fieldValue);
					valueInJsonFile = Boolean.toString(flag);
				} else
					valueInJsonFile = json.get(fieldValue).toString();
			}
			if (valueInJsonFile == null || valueInJsonFile.equalsIgnoreCase("")) {
				Serenity.recordReportData().asEvidence().withTitle("Field or Field value is not provided : ")
						.andContents(fieldValue);
				validationFail1 = false;
				count++;
			}
			if (fieldValue.equalsIgnoreCase("testTaker_uniqueTestTakerUuid") && validationFail1) {
				validationFail1 = true;
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return validationFail1;
	}

	public static String getRequestbodyFromDB(String hostName, Integer portNum, String dbName,
			String requestCollectionName, String externalTestTakerId) throws ParseException {

		externalSelectionId = externalTestTakerId;
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostName, portNum)) {
			DB db = mongoclient.getDB(dbName);
			DBCollection coll = db.getCollection(requestCollectionName);
			DBObject query = new BasicDBObject("selection.externalSelectionUuid",
					new BasicDBObject("$eq", externalTestTakerId));
			DBObject result = coll.findOne(query);
			strVal = String.valueOf(result);
			Integer length = strVal.length();
			String subpostbody = strVal.substring(CommonModules.removehead, length);
			externalSelectionId = CommonModules.randomUUID();
			postBodyreq = curlyB + subpostbody;
			verifyFieldValueInRequest("externalBookingUuid");
			externalBookId = valueInJsonFile;
			verifyFieldValueInRequest("externalBookingReference");
			externalBookingReference = valueInJsonFile;
			verifyFieldValueInRequest("selection_organisation_organisationUuid");
			organizationUuid = valueInJsonFile;
			verifyFieldValueInRequest("selection_personDepartment");
			personDepartment = valueInJsonFile;
			postBodyreq = postBodyreq.replace(externalBookId,
					SI_RD_BookingCreatedConsumptionForSelectionSetup.expectedexternalBookingUuid);
			postBodyreq = postBodyreq.replace(externalBookingReference,
					SI_RD_BookingCreatedConsumptionForSelectionSetup.expectedexternalBookingReference);
			postBodyreq = postBodyreq.replace(organizationUuid,
					SI_RD_ROCreatedConsumptionForSelectionSetup.expectedrecognisingOrganisationUuid);
			postBodyreq = postBodyreq.replace(personDepartment, personDepartment + "_New");
			postBodyreq = postBodyreq.replace(externalTestTakerId, externalSelectionId);
			try (CMDSMongoClientAdapter mongoclient1 = new CMDSMongoClientAdapter(hostName, portNum)) {
				DB db1 = mongoclient1.getDB(dbName);
				DBCollection collstr = db1.getCollection(requestCollectionName);
				DBObject object = (DBObject) JSON.parse(postBodyreq.toString());
				collstr.insert(object);
			} catch (Exception e) {
				System.out.println("Error");
			}
		} catch (Exception e) {
			System.out.println("Error");
		}
		return postBodyreq;
	}

	String expectedUaOrgName = "";
	String uaOrgName = "";
	static Faker faker = new Faker();

	public static String getRequestbodyFromDBForUASelection(String hostName, Integer portNum, String dbName,
			String requestCollectionName, String externalTestTakerId) throws ParseException {

		externalSelectionId = externalTestTakerId;
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostName, portNum)) {
			DB db = mongoclient.getDB(dbName);
			DBCollection coll = db.getCollection(requestCollectionName);
			DBObject query = new BasicDBObject("selection.externalSelectionUuid",
					new BasicDBObject("$eq", externalTestTakerId));
			DBObject result = coll.findOne(query);
			strVal = String.valueOf(result);
			Integer length = strVal.length();
			String subpostbody = strVal.substring(CommonModules.removehead, length);
			externalSelectionId = CommonModules.randomUUID();
			postBodyreq = curlyB + subpostbody;
			verifyFieldValueInRequest("externalBookingUuid");
			externalBookId = valueInJsonFile;
			verifyFieldValueInRequest("externalBookingReference");
			externalBookingReference = valueInJsonFile;
			String firstName = faker.name().firstName();
			String expectedUaOrgName = firstName + "_University";
			verifyFieldValueInRequest("selection_unverifiedAddress_organisationName");
			String uaOrgName = valueInJsonFile;
			verifyFieldValueInRequest("selection_personDepartment");
			personDepartment = valueInJsonFile;
			postBodyreq = postBodyreq.replace(externalBookId,
					SI_RD_BookingCreatedConsumptionForSelectionSetup.expectedexternalBookingUuid);
			postBodyreq = postBodyreq.replace(externalBookingReference,
					SI_RD_BookingCreatedConsumptionForSelectionSetup.expectedexternalBookingReference);
			postBodyreq = postBodyreq.replace(uaOrgName, expectedUaOrgName);
			postBodyreq = postBodyreq.replace(personDepartment, personDepartment + "_New");
			postBodyreq = postBodyreq.replace(externalTestTakerId, externalSelectionId);
			try (CMDSMongoClientAdapter mongoclient1 = new CMDSMongoClientAdapter(hostName, portNum)) {
				DB db1 = mongoclient1.getDB(dbName);
				DBCollection collstr = db1.getCollection(requestCollectionName);
				DBObject object = (DBObject) JSON.parse(postBodyreq.toString());
				collstr.insert(object);
			} catch (Exception e) {
				System.out.println("Error");
			}
		} catch (Exception e) {
			System.out.println("Error");
		}
		return postBodyreq;
	}

	public static void orsPostRegistrationToCMDS(String actUrl, String actPath, String randomUUID, String accessToken) {
		eventDateTime = generateEventDateTime().toString();
		RestAssured.baseURI = actUrl;
		response = CommonModules.commonROSelectionRequest(actUrl, actPath, randomUUID, eventDateTime, accessToken,
				postBodyreq);
	}

	public static String generateEventDateTime() {
		LocalDateTime currenttimestamp = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		String neweventdatetime = currenttimestamp.format(formatter).toString();
		return neweventdatetime;
	}

	public static void getPartnerCodefromJWT() {

		String accessTokenIDP = null;
		jwtToken = SD_RD_UpdateROSelectionSetup.accessTokenIDP;
		final String key = "partnerCode";
		// String dataFromClaims = getDataFromClaims(jwtToken, key);
	}

	public static String getDataFromClaims(final String jwtToken, final String keyEndingWith) {
		final Map<String, Claim> claims = JWT.decode(jwtToken.replace("Bearer ", "")).getClaims();
		if (Objects.nonNull(claims)) {
			final Claim claimValue = claims.entrySet().stream().filter(e -> e.getKey().endsWith("/" + keyEndingWith))
					.map(Map.Entry::getValue).findFirst().orElse(null);
			return Objects.nonNull(claimValue) ? claimValue.asString() : null;
		}
		return null;
	}

	public String ActUrl = "";

	public String TakeActUrl(String Env) {

		System.out.println(Env);
		switch (Env) {
		case "sandbox":
			ActUrl = CommonModules.getEnvironmentConfigurations("cmds268.SandboxresultActurl");
			break;
		case "sandbox2":
			ActUrl = CommonModules.getEnvironmentConfigurations("cmds268.Sandbox2resultActurl");
			break;
		case "dev":
			ActUrl = CommonModules.getEnvironmentConfigurations("cmds268.DevresultActurl");
			break;
		}
		return ActUrl;
	}

	public String EnvKeyQueue = "";

	public String TakeEnvKeyQueue(String Env) {

		System.out.println(Env);
		switch (Env) {
		case "sandbox":
			EnvKeyQueue = CommonModules.getEnvironmentConfigurations("int189.SandboxenvKeyQueue");
			break;
		case "sandbox2":
			EnvKeyQueue = CommonModules.getEnvironmentConfigurations("int189.Sandbox2envKeyQueue");
			break;
		case "dev":
			EnvKeyQueue = CommonModules.getEnvironmentConfigurations("int189.DevenvKeyQueue");
			break;
		}
		return EnvKeyQueue;
	}

	public static String authUrlForBooking = "";

	public static String takeAuthUrlForBooking(String partner) {
		String env = System.getenv("ENVIRONMENT");
		switch (env) {

		case "sandbox":
			if (partner.equalsIgnoreCase("IDP")) {
				authUrlForBooking = CommonModules.getEnvironmentConfigurations("Sandbox_IDP.AuthURL");
			} else if (partner.equalsIgnoreCase("BC")) {
				authUrlForBooking = CommonModules.getEnvironmentConfigurations("Sandbox_BC.AuthURL");
			}
			break;
		case "dev":
			if (partner.equalsIgnoreCase("IDP")) {
				authUrlForBooking = CommonModules.getEnvironmentConfigurations("Dev_IDP.AuthURL");
			} else if (partner.equalsIgnoreCase("BC")) {
				authUrlForBooking = CommonModules.getEnvironmentConfigurations("Dev_BC.AuthURL");
			}
			break;
		case "sit":
			if (partner.equalsIgnoreCase("IDP")) {
				authUrlForBooking = CommonModules.getEnvironmentConfigurations("sit_IDP.AuthURL");
			} else if (partner.equalsIgnoreCase("BC")) {
				authUrlForBooking = CommonModules.getEnvironmentConfigurations("sit_BC.AuthURL");
			}
			break;
		}
		return authUrlForBooking;
	}

	public static String authReqForBooking = "";

	public static String takeAuthReqForBooking(String partner) {
		String env = System.getenv("ENVIRONMENT");
		switch (env) {
		case "sandbox":
			if (partner.equalsIgnoreCase("IDP")) {
				authReqForBooking = CommonModules.getEnvironmentConfigurations("Sandbox_IDP.AuthReq");
			} else if (partner.equalsIgnoreCase("BC")) {
				authReqForBooking = CommonModules.getEnvironmentConfigurations("Sandbox_BC.AuthReq");
			}
			break;
		case "dev":
			if (partner.equalsIgnoreCase("IDP")) {
				authReqForBooking = CommonModules.getEnvironmentConfigurations("Dev_IDP.AuthReq");
			} else if (partner.equalsIgnoreCase("BC")) {
				authReqForBooking = CommonModules.getEnvironmentConfigurations("Dev_BC.AuthReq");
			}
			break;
		case "sit":
			if (partner.equalsIgnoreCase("IDP")) {
				authReqForBooking = CommonModules.getEnvironmentConfigurations("sit_IDP.AuthReq");
			} else if (partner.equalsIgnoreCase("BC")) {
				authReqForBooking = CommonModules.getEnvironmentConfigurations("sit_BC.AuthReq");
			}
			break;
		}
		return authReqForBooking;
	}

	public String DbUrl = "";

	public String TakeDbUrl(String Env) {

		System.out.println(Env);
		switch (Env) {
		case "sandbox":
			ActUrl = CommonModules.getEnvironmentConfigurations("cmds268.dbUrlSandbox");
			break;
		case "sandbox2":
			ActUrl = CommonModules.getEnvironmentConfigurations("cmds268.dbUrlSandbox");
			break;
		case "dev":
			ActUrl = CommonModules.getEnvironmentConfigurations("cmds268.dbUrlDev");
			break;
		}
		return ActUrl;
	}

}
