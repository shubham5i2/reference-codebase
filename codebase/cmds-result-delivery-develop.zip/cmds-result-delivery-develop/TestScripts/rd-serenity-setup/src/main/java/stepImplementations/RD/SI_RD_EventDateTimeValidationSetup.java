package stepImplementations.RD;

import static io.restassured.RestAssured.given;

import java.io.FileReader;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import common.dbabstraction.CMDSMongoClientAdapter;
import com.mongodb.util.JSON;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class SI_RD_EventDateTimeValidationSetup {
	static final String TESTDATAPATH = System.getenv("TEST_SETUP_FILE_PATH");
	static final String VAR0 = TESTDATAPATH;
	int counterVar = 0;
	String str = "";
    String postbody = "";
    int removehead = 51;
    int count=0;
    int totalIndex = 0;
    String postBody="";
	String inputJson[]= new String[11];
	
	@SuppressWarnings("deprecation")
	public void cleanDatebaseModule(String hostName, Integer portNum, String dbName, String collName) {
		try(CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostName, portNum);){
		DB db = mongoclient.getDB(dbName);
		System.out.println("MongoDB connected");
		DBCollection coll = db.getCollection(collName);
		coll.remove(new BasicDBObject());
		}
	}
	
	public void v2_ConnectAndInsertRequestIntoMongoDB(String hostName, Integer portNum, String dbName, String collName) {
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostName, portNum);) {
		DB db = mongoclient.getDB(dbName);
		System.out.println("MongoDB connected");
		DBCollection collstr = db.getCollection(collName);
		String var1 = "/RD_EventDateTimeValidation/v2_ReferenceRequest";
		String var3 = ".json";
		int cntx = 1;
		while (counterVar < 11) {
			int var2 = cntx;
			String pathstr = VAR0 + var1 + var2 + var3;
			System.out.println("pathstr :" + pathstr);
			JSONParser parser = new JSONParser();
			try {
				Object obj = parser.parse(new FileReader(pathstr));
				JSONObject jsonObject = (JSONObject) obj;
				DBObject object = (DBObject) JSON.parse(jsonObject.toString());
				collstr.insert(object);
				counterVar++;
				cntx++;

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		}
	}
	
	int counter = 0;
	public void ConnectAndInsertServerFilesIntoMongoDB(String hostName, Integer portNum, String dbName, String collName) {
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostName, portNum);) {
		DB db = mongoclient.getDB(dbName);
		System.out.println("MongoDB connected to insert server responses");
		DBCollection collstr = db.getCollection(collName);
		String var1 = "/RD_EventDateTimeValidation/ReferenceServerResponse";
		String var3 = ".json";
		int cntx = 1;
		while (counter < 10) {
			int var2 = cntx;
			String pathstr = VAR0 + var1 + var2 + var3;
			System.out.println("pathstr :" + pathstr);
			JSONParser parser = new JSONParser();
			try {
				Object obj = parser.parse(new FileReader(pathstr));
				JSONObject jsonObject = (JSONObject) obj;
				System.out.println("Json : " + jsonObject);
				DBObject object = (DBObject) JSON.parse(jsonObject.toString());
				collstr.insert(object);
				counter++;
				cntx++;

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		}
	}
	
	@SuppressWarnings("deprecation")
	public void fetchMockDataFromMongoDB(String hostName, Integer portNum, String dbName,String collectionName)
    {
		try(CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostName, portNum);){
        DB db = mongoclient.getDB(dbName);
        DBCollection coll = db.getCollection(collectionName);
        DBCursor cursor = coll.find();
        int i=0;
        while(cursor.hasNext()) {

            DBObject result= cursor.next();
            str = new String(String.valueOf(result));
            Integer length = str.length();
            String subpostbody = str.substring(removehead,length);
            postBody = "{" + subpostbody;
            inputJson[i] = postBody;
            i++;
            totalIndex = i ;
        }
		}
    }
	
	/************************************************************************
	 * Function Name: postMockDataIntoMockServer 
	 * Function Description: To post the server responses into mock server
	 **************************************************************************/
	public void postMockDataIntoMockServer(String baseUrl, String basePath) {
       while (count < totalIndex) {
    	   RestAssured.baseURI = baseUrl;
           RestAssured.basePath = "";
            postBody= inputJson[count];
            Response actResponse = given().contentType(ContentType.JSON).log().all().body(postBody).post(basePath);
            actResponse.prettyPrint();
            count++;
        }
    }

}
