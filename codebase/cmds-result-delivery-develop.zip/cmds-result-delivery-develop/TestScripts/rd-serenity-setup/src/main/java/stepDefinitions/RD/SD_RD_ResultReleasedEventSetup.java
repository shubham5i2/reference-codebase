package stepDefinitions.RD;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.json.simple.parser.ParseException;

import common.CommonModules;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import stepImplementations.RD.SI_RD_BookingCreatedEventSetup;
import stepImplementations.RD.SI_RD_PhotoPublishEventSetup;
import stepImplementations.RD.SI_RD_ResultReleasedEventSetup;

public class SD_RD_ResultReleasedEventSetup extends CommonModules {

	static CommonModules common = new CommonModules();
	String env = System.getenv("ENVIRONMENT");
	public String swaggerVersion = System.getenv("SWAGGER_VERSION");
	public static String AuthURL = "";
	static String AuthReq = "";
	public static String mxName = "";
	public static String DBUrl = "";
	public static String dbUrl = "";

	public static String enviroment = "";
	static String authURL = "";
	static String authReq = "";
	static String accessToken = "";
	static String destinationQueue = "";
	static String envkeyQueue = "";
	static String destinationTopic = "";
	static String envkeyTopic = "";
	public static String ors338dbname = "";
	public static String ors338reqcollection = "";
	public static String ors338servercollection = "";
	public static String ors338baseurl = "";
	public static String basepath = "";
	public static String ors081dbname = "";
	public static String ors081reqcollection = "";
	public static String ors081servercollection = "";
	public static String ors081baseurl = "";
	public static String ors189dbname = "";
	public static String ors189reqcollection = "";
	public static String ors189servercollection = "";
	public static String ors189baseurl = "";
	public static String int081Acturl = "";
	public static String int081Actpath = "";

	public static String RD_AsyncDB;
	public static String RD_AsyncCollection;

	boolean dummy = false;
	static SI_RD_ResultReleasedEventSetup setupImple = new SI_RD_ResultReleasedEventSetup();
	static SI_RD_BookingCreatedEventSetup booking = new SI_RD_BookingCreatedEventSetup();
	static SI_RD_PhotoPublishEventSetup photo = new SI_RD_PhotoPublishEventSetup();

	@Given("^Clean the Mongo database for new data setup for RM Event$")
	public void clean_the_Mongo_database_for_new_data_setup_for_RM_Event() throws IOException {
		common.getEnvironmentConfigurationsOpen();
		hostname = common.getEnvironmentConfigurations("common.hostname");
		portnum = Integer.parseInt(common.getEnvironmentConfigurations("common.portnum"));

		errordb = common.getEnvironmentConfigurations("common.errordb");
		errorcollection = common.getEnvironmentConfigurations("common.errorcollection");
		RD_AsyncCollection = common.getEnvironmentConfigurations("common.RD.AsyncCollection");
		RD_AsyncDB = common.getEnvironmentConfigurations("common.RD.AsyncDBname");

		ors338dbname = common.getEnvironmentConfigurations("int338.dbname");
		ors338reqcollection = common.getEnvironmentConfigurations("int338.reqcollection");
		ors338servercollection = common.getEnvironmentConfigurations("int338.servercollection");
		ors338baseurl = common.getEnvironmentConfigurations("int338.baseurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		photo.cleanDatebaseModule(hostname, portnum, ors338dbname, ors338reqcollection);
		photo.cleanDatebaseModule(hostname, portnum, errordb, errorcollection);
		photo.cleanDatebaseModule(hostname, portnum, ors338dbname, ors338servercollection);

		ors081dbname = common.getEnvironmentConfigurations("int081.dbname");
		ors081reqcollection = common.getEnvironmentConfigurations("int081.reqcollection");
		ors081servercollection = common.getEnvironmentConfigurations("int081.servercollection");
		ors081baseurl = common.getEnvironmentConfigurations("int081.baseurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		setupImple.cleanDatebaseModule(hostname, portnum, ors081dbname, ors081reqcollection);
		setupImple.cleanDatebaseModule(hostname, portnum, errordb, errorcollection);
		setupImple.cleanDatebaseModule(hostname, portnum, ors081dbname, ors081servercollection);

		ors189dbname = common.getEnvironmentConfigurations("int189.dbname");
		ors189reqcollection = common.getEnvironmentConfigurations("int189.reqcollection");
		ors189servercollection = common.getEnvironmentConfigurations("int189.servercollection");
		ors189baseurl = common.getEnvironmentConfigurations("int189.baseurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		booking.cleanDatebaseModule(hostname, portnum, ors189dbname, ors189reqcollection);
		booking.cleanDatebaseModule(hostname, portnum, errordb, errorcollection);
		booking.cleanDatebaseModule(hostname, portnum, ors189dbname, ors189servercollection);
		common.cleanAsyncDBCollection(hostname, portnum, RD_AsyncDB, RD_AsyncCollection);
	}

	@Then("^Insert the request and responses to mongodb for RM Event$")
	public void insert_the_request_and_responses_to_mongodb_for_RM_Event() throws IOException, ParseException {
		if (swaggerVersion.equalsIgnoreCase("v1")) {
			setupImple.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors081dbname, ors081reqcollection);
			booking.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors189dbname, ors189reqcollection);
			photo.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors338dbname, ors338reqcollection);
		} else if (swaggerVersion.equalsIgnoreCase("v2")) {
			setupImple.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors081dbname, ors081reqcollection);
			booking.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors189dbname, ors189reqcollection);
			photo.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors338dbname, ors338reqcollection);

		}

		setupImple.connectandInsertORSCommonresDataInMongoDB(hostname, portnum, errordb, errorcollection);
		booking.connectandInsertORSCommonresDataInMongoDB(hostname, portnum, errordb, errorcollection);
		photo.connectandInsertORSCommonresDataInMongoDB(hostname, portnum, errordb, errorcollection);
		setupImple.connectandInsertDBdataReqDataInMongoDB(hostname, portnum, ors189dbname, ors189reqcollection);
		setupImple.connectandInsertDBdataReqDataInMongoDB(hostname, portnum, ors338dbname, ors338reqcollection);
		setupImple.connectandInsertDBdataReqDataInMongoDB(hostname, portnum, ors081dbname, ors081reqcollection);
	}

	@Then("^Setup the Server responses in Mock server for RM Event$")
	public void setup_the_Server_responses_in_Mock_server_for_RM_Event()
			throws FileNotFoundException, IOException, ParseException {
		setupImple.ConnectandInsertORSResDataInMongoDB(hostname, portnum, ors081dbname, ors081servercollection);
		setupImple.TakeORSMockDataFromMongoDB(hostname, portnum, ors081dbname, ors081servercollection);
		// setupImple.PostORSMockDataIntoWiremock(ors081baseurl,basepath);
	}

	@Then("^Setup the Server responses in Mock server for Legacy Adapter Flow$")
	public void setup_the_Server_responses_in_Mock_server_for_Legacy_Adapter_Flow()
			throws FileNotFoundException, IOException, ParseException {
		setupImple.ConnectandInsertORSResDataInMongoDBForLAFlow(hostname, portnum, ors081dbname,
				ors081servercollection);
		setupImple.TakeORSMockDataFromMongoDB(hostname, portnum, ors081dbname, ors081servercollection);
		setupImple.PostORSMockDataIntoWiremock(ors081baseurl, basepath);
	}

	@Then("^Test data setup completed sucessfully for RM Event$")
	public void test_data_setup_completed_sucessfully_for_RM_Event() {
		System.out.println("Test data set up is completed successfully");
	}

	@Given("^MongoDB configuration set up has been done for the RM event \"([^\"]*)\"$")
	public void mongodb_configuration_set_up_has_been_done_for_the_RM_event(String partner) throws IOException {
		common.getEnvironmentConfigurationsOpen();
		hostname = common.getEnvironmentConfigurations("common.hostname");
		portnum = Integer.parseInt(common.getEnvironmentConfigurations("common.portnum"));

		errordb = common.getEnvironmentConfigurations("common.errorDB");
		errorcollection = common.getEnvironmentConfigurations("common.errorcollection");

		ors081dbname = common.getEnvironmentConfigurations("int081.dbname");
		ors081reqcollection = common.getEnvironmentConfigurations("int081.reqcollection");

//	    int081Acturl = common.getEnvironmentConfigurations("int081.Acturl");
		int081Acturl = setupImple.TakeActUrl(env);
		int081Actpath = common.getEnvironmentConfigurations("int081.rmevent.path");

		destinationQueue = common.getEnvironmentConfigurations("int081.DestinationQueue");
		// envkeyQueue = common.getEnvironmentConfigurations("int081.envKeyQueue");

		envkeyQueue = setupImple.TakeEnvKeyQueue(env);
		AuthURL = setupImple.takeAuthUrlForBooking(partner);
		AuthReq = setupImple.takeAuthReqForBooking(partner);
		mxName = "RD";
		enviroment = env;
		DBUrl = setupImple.TakeDbUrl(env);
		dbUrl = DBUrl;
		accessToken = common.RetrieveToken(AuthURL, AuthReq);

	}

	@When("^RM event updates are made available to CMDS-RDS \"([^\"]*)\"$")
	public void rm_event_updates_are_made_available_to_CMDS_RDS(String transactionId)
			throws InterruptedException, ParseException {
		setupImple.getInputRequestBodyUsingTransactionId(hostname, portnum, ors081dbname, ors081reqcollection,
				transactionId);
	}

	@Then("^Post the RM event to rds-in-queue$")
	public void post_the_RM_event_to_rds_in_queue() throws ParseException, InterruptedException {
		setupImple.postRequest(int081Acturl, int081Actpath, destinationQueue, envkeyQueue, accessToken);
		setupImple.insertRecordInMongoDB(hostname, portnum, ors081dbname, ors081reqcollection);
		setupImple.verifyResponse();
	}

	@Then("^Post the RM event to rds-in-queue for Booking Change Analysis$")
	public void postresulteventforbookingchangeanalysis() throws ParseException, InterruptedException {
		setupImple.postRequest(int081Acturl, int081Actpath, destinationQueue, envkeyQueue, accessToken);
		setupImple.verifyResponse();
	}

}
