package stepDefinitions.RD;

public class SD_RD_ResultStatusChangedEventSetup {

}
