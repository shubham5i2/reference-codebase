package stepDefinitions.RD;

import java.io.IOException;

import org.json.simple.parser.ParseException;

import com.fasterxml.jackson.core.JsonProcessingException;

import common.CommonModules;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import stepImplementations.RD.SI_RD_ROCreatedConsumptionForSelectionSetup;

public class SD_RD_ROCreatedConsumptionForSelectionSetup extends CommonModules {

	CommonModules common = new CommonModules();
	SI_RD_ROCreatedConsumptionForSelectionSetup stepimplement = new SI_RD_ROCreatedConsumptionForSelectionSetup();
	String env = System.getenv("ENVIRONMENT");
	public String swaggerVersion = System.getenv("SWAGGER_VERSION");
	public static String AuthURL = "";
	static String AuthReq = "";
	public static String mxName = "";
	public static String DBUrl = "";
	public static String dbUrl = "";

	public static String enviroment = "";
	static String authURL = "";
	static String authReq = "";
	static String accessToken = "";
	static String destinationQueue = "";
	static String envkeyQueue = "";
	static String destinationTopic = "";
	static String envkeyTopic = "";

	boolean dummy = false;

	protected static String int70dbname = "";
	protected static String int70reqcollection = "";
	protected static String int70Acturl = "";
	protected static String int70Actpath = "";

	@Given("^MongoDB configuration set up has been done for the organizationChanged event \"([^\"]*)\"$")
	public void mongodb_Configuration_Set_up_has_been_done_for_RDS_ROChanged_event(String partner) throws IOException {
		common.getEnvironmentConfigurationsOpen();
		hostname = common.getEnvironmentConfigurations("common.hostname");
		portnum = Integer.parseInt(common.getEnvironmentConfigurations("common.portnum"));

		errordb = common.getEnvironmentConfigurations("common.errordb");
		errorcollection = common.getEnvironmentConfigurations("common.errorcollection");

		int70dbname = common.getEnvironmentConfigurations("int70.dbname");
		int70reqcollection = common.getEnvironmentConfigurations("int70.reqcollection");

		// int70Acturl = common.getEnvironmentConfigurations("int70.Acturl");
		int70Acturl = stepimplement.TakeActUrl(env);
		int70Actpath = common.getEnvironmentConfigurations("int70.roevent.path");

		destinationQueue = common.getEnvironmentConfigurations("int70.DestinationQueue");
		envkeyQueue = common.getEnvironmentConfigurations("int70.envKeyQueue");

		envkeyQueue = stepimplement.TakeEnvKeyQueue(env);
		AuthURL = stepimplement.takeAuthUrlForBooking(partner);
		AuthReq = stepimplement.takeAuthReqForBooking(partner);
		mxName = "RD";
		enviroment = env;
		DBUrl = stepimplement.TakeDbUrl(env);
		dbUrl = DBUrl;
		accessToken = common.RetrieveToken(AuthURL, AuthReq);
		System.out.println(accessToken);

	}

	@When("^organizationChanged event updates are made available to CMDS-RDS \"([^\"]*)\"$")
	public void rochanged_event_updates_for_the_Test_Events_are_made_available_to_CMDS_RDS(String transactionId)
			throws ParseException, InterruptedException {
		stepimplement.getInputRequestBodyfromTestDB(hostname, portnum, int70dbname, int70reqcollection, transactionId);
		stepimplement.constructROEventCreated();
	}

	@When("^organizationChanged event contains all the mandatory fields$")
	public void rochanged_event_contains_all_the_mandatory_fields() throws ParseException {
		stepimplement.getJsonFeildValuesfromRequestbody();
		stepimplement.allFields();
	}

	@Then("^Post the organizationChanged event to rds-in-queue$")
	public void cmds_RDS_will_accept_the_ROChanged_event_updates() throws ParseException {
		stepimplement.postRequest(int70Acturl, int70Actpath, destinationQueue, envkeyQueue, accessToken);
		stepimplement.verifyResponse();
		stepimplement.getJsonFeildValuesfromRequestbody();
	}

	@Then("^CMDS-RDS will upsert the OrganizationChanged event details in RDS and publish OrganizationChanged ConsumedEvent$")
	public void cmds_RDS_will_upsert_the_ROChanged_event_details_in_RDS_and_publish_ROConsumedEvent()
			throws InterruptedException, ParseException {
		stepimplement.connectMongoDB(hostname, portnum);
		stepimplement.validatePublishedMessage();
		stepimplement.verifyMandatoryFieldInRecognisedProducts();
	}

	@Then("^Construct event request body with eventdate time as \"([^\"]*)\"$")
	public void Construct_event_request_body_with_old_eventDateTime(String eventDateTimeFlag)
			throws InterruptedException, ParseException {
		stepimplement.constructROEventWithOldEventDateTime(eventDateTimeFlag);
	}

	@Then("^CMDS-RDS will reject the OrganizationChanged event details in RDS and publish OrganizationChanged ConsumedEvent$")
	public void rejectevent() throws InterruptedException, ParseException {
		stepimplement.connectMongoDB(hostname, portnum);
		stepimplement.verifyErrorInPublishedMessage();
	}

	@When("^Construct linked RO Hierarchy event for \"([^\"]*)\"$")
	public void rochangejd_event_updates_for_the_Test_Events_are_made_available_to_CMDS_RDS(String typeValue)
			throws ParseException, InterruptedException, JsonProcessingException {
		stepimplement.commonUpdates(typeValue);
	}

	@Then("^Saved the organisationUuid for linking the organisation$")
	public void cmds_RDS_will_achcept_the_ROChanged_event_updates() throws ParseException {
		stepimplement.savedRecognisinOrganisationUuid();
	}

	@When("^Construct linked RO Hierarchy event for RO selection flow$")
	public void rochanged_evente_contains_all_the_mandatory_fields() throws ParseException, JsonProcessingException {
		stepimplement.constructROHierarchyEvent();

	}
}
