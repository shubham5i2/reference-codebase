package testRunners.RD;

import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;
import java.util.stream.Stream;
import cucumber.api.CucumberOptions;

@RunWith(CucumberWithSerenity.class)
    @CucumberOptions(
        features = {"src/main/resources/features/RD/RD_RBAC_UI_API_Setup.feature"},
        glue= {"stepDefinitions"},
        format = { "pretty", "html:target/results" },
        monochrome = true,
        strict = true,
        dryRun=false,
		tags={"@RBACBookingSelectionsSearch"})

public class TR_RD_RBAC_UI_API_Setup {

	private static String[] defaultOptions = {
            "--glue", "stepDefinitions",
            "--plugin", "pretty",
            "--plugin", "html:target/results"
    };

    public static void main(String[] args) throws Throwable {
        Stream<String> cucumberOptions = Stream.concat(Stream.of(defaultOptions), Stream.of(args));
        net.serenitybdd.cucumber.cli.Main.main(cucumberOptions.toArray(String[]::new));
    }
	
}

