package stepDefinitions.RD;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.json.simple.parser.ParseException;

import common.CommonModules;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import stepImplementations.RD.SI_RD_AcceptROSelectionSetup;
import stepImplementations.RD.SI_RD_BookingCreatedEventSetup;
import stepImplementations.RD.SI_RD_PhotoPublishEventSetup;
import stepImplementations.RD.SI_RD_ROCreatedEventSetup;
import stepImplementations.RD.SI_RD_ResultReleasedEventSetup;
import stepImplementations.RD.SI_RD_TRFBookingSelectionSearch;

public class SD_RD_TRFBookingSelectionSearch_setup extends CommonModules {
	static CommonModules common = new CommonModules();
	public String swaggerVersion = System.getenv("SWAGGER_VERSION");
	static SI_RD_TRFBookingSelectionSearch SelectionSearch = new SI_RD_TRFBookingSelectionSearch();
	static SI_RD_PhotoPublishEventSetup photo = new SI_RD_PhotoPublishEventSetup();
	static SI_RD_ResultReleasedEventSetup result = new SI_RD_ResultReleasedEventSetup();
	static SI_RD_BookingCreatedEventSetup booking = new SI_RD_BookingCreatedEventSetup();
	static SI_RD_ROCreatedEventSetup organisation = new SI_RD_ROCreatedEventSetup();
	static SI_RD_AcceptROSelectionSetup ExternalSelection = new SI_RD_AcceptROSelectionSetup();

	public static String ors189dbname = "";
	public static String ors189reqcollection = "";
	public static String ors189servercollection = "";
	public static String ors189baseurl = "";

	public static String ors081dbname = "";
	public static String ors081reqcollection = "";
	public static String ors081servercollection = "";
	public static String ors081baseurl = "";

	public static String ors338dbname = "";
	public static String ors338reqcollection = "";
	public static String ors338servercollection = "";
	public static String ors338baseurl = "";

	public static String ors70dbname = "";
	public static String ors70reqcollection = "";
	public static String ors70servercollection = "";
	public static String ors70baseurl = "";
	public static String basepath = "";
	public static String ors268dbname = "";
	public static String ors268reqcollection = "";
	public static String ors268servercollection = "";
	public static String ors268callbackurl = "";
	protected static String cmds268resultActpath = "";
	protected static String cmds268resultActurl = "";
	public static String ors169dbname = "";
	public static String ors169reqcollection = "";
	public static String ors169servercollection = "";
	public static String ors169callbackurl = "";
	protected static String cmds169resultActpath = "";
	protected static String cmds169resultActurl = "";
	public static String ors889dbname = "";
	public static String ors889reqcollection = "";
	public static String ors889servercollection = "";
	public static String ors889callbackurl = "";
	protected static String cmds889resultActpath = "";
	protected static String cmds889resultActurl = "";
	public static String RD_AsyncDB;
	public static String RD_AsyncCollection;

	@Given("^Clean the Mongo database for new data setup for Booking Selections Search Event$")
	public void clean_the_Mongo_database_for_new_data_setup_for_Booking_Selections_Search_Event() throws IOException {
		common.getEnvironmentConfigurationsOpen();
		hostname = common.getEnvironmentConfigurations("common.hostname");
		portnum = Integer.parseInt(common.getEnvironmentConfigurations("common.portnum"));
		RD_AsyncCollection = common.getEnvironmentConfigurations("common.RD.AsyncCollection");
		RD_AsyncDB = common.getEnvironmentConfigurations("common.RD.AsyncDBname");
		ors70dbname = common.getEnvironmentConfigurations("int70.dbname");
		ors70reqcollection = common.getEnvironmentConfigurations("int70.reqcollection");
		ors70servercollection = common.getEnvironmentConfigurations("int70.servercollection");
		ors70baseurl = common.getEnvironmentConfigurations("int70.baseurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		errordb = common.getEnvironmentConfigurations("common.errordb");
		errorcollection = common.getEnvironmentConfigurations("common.errorcollection");

		organisation.cleanDatebaseModule(hostname, portnum, ors70dbname, ors70reqcollection);
		organisation.cleanDatebaseModule(hostname, portnum, errordb, errorcollection);
		organisation.cleanDatebaseModule(hostname, portnum, ors70dbname, ors70servercollection);

		ors189dbname = common.getEnvironmentConfigurations("int189.dbname");
		ors189reqcollection = common.getEnvironmentConfigurations("int189.reqcollection");
		ors189servercollection = common.getEnvironmentConfigurations("int189.servercollection");
		ors189baseurl = common.getEnvironmentConfigurations("int189.baseurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		booking.cleanDatebaseModule(hostname, portnum, ors189dbname, ors189reqcollection);
		booking.cleanDatebaseModule(hostname, portnum, ors189dbname, ors189servercollection);

		ors081dbname = common.getEnvironmentConfigurations("int081.dbname");
		ors081reqcollection = common.getEnvironmentConfigurations("int081.reqcollection");
		ors081servercollection = common.getEnvironmentConfigurations("int081.servercollection");
		ors081baseurl = common.getEnvironmentConfigurations("int081.baseurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		result.cleanDatebaseModule(hostname, portnum, ors081dbname, ors081reqcollection);
		result.cleanDatebaseModule(hostname, portnum, ors081dbname, ors081servercollection);

		ors338dbname = common.getEnvironmentConfigurations("int338.dbname");
		ors338reqcollection = common.getEnvironmentConfigurations("int338.reqcollection");
		ors338servercollection = common.getEnvironmentConfigurations("int338.servercollection");
		ors338baseurl = common.getEnvironmentConfigurations("int338.baseurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		photo.cleanDatebaseModule(hostname, portnum, ors338dbname, ors338reqcollection);
		photo.cleanDatebaseModule(hostname, portnum, errordb, errorcollection);
		photo.cleanDatebaseModule(hostname, portnum, ors338dbname, ors338servercollection);

		ors268dbname = common.getEnvironmentConfigurations("int268.dbname");
		ors268reqcollection = common.getEnvironmentConfigurations("int268.reqcollection");
		ors268servercollection = common.getEnvironmentConfigurations("int268.servercollection");
		ors268callbackurl = common.getEnvironmentConfigurations("int268.mockurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		ExternalSelection.cleanDatebaseModule(hostname, portnum, ors268dbname, ors268reqcollection);
		ExternalSelection.cleanDatebaseModule(hostname, portnum, ors268dbname, ors268servercollection);

		ors169dbname = common.getEnvironmentConfigurations("int169.dbname");
		ors169reqcollection = common.getEnvironmentConfigurations("int169.reqcollection");
		ors169servercollection = common.getEnvironmentConfigurations("int169.servercollection");
		ors169callbackurl = common.getEnvironmentConfigurations("int169.mockurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		SelectionSearch.cleanDatebaseModule(hostname, portnum, ors169dbname, ors169reqcollection);
		SelectionSearch.cleanDatebaseModule(hostname, portnum, ors169dbname, ors169servercollection);
		SelectionSearch.cleanDatebaseModule(hostname, portnum, errordb, errorcollection);

		ors889dbname = common.getEnvironmentConfigurations("int889.dbname");
		ors889reqcollection = common.getEnvironmentConfigurations("int889.reqcollection");
		ors889servercollection = common.getEnvironmentConfigurations("int889.servercollection");
		ors889callbackurl = common.getEnvironmentConfigurations("int889.mockurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		SelectionSearch.cleanDatebaseModule(hostname, portnum, ors889dbname, ors889reqcollection);
		SelectionSearch.cleanDatebaseModule(hostname, portnum, ors889dbname, ors889servercollection);
		SelectionSearch.cleanDatebaseModule(hostname, portnum, errordb, errorcollection);
		common.cleanAsyncDBCollection(hostname, portnum, RD_AsyncDB, RD_AsyncCollection);
	}

	@Then("^Insert the request and responses to mongodb for Booking Selections Search Event$")
	public void insert_the_request_and_responses_to_mongodb_for_Booking_Selections_Search_Event()
			throws IOException, ParseException {
		if (swaggerVersion.equalsIgnoreCase("v1")) {
			booking.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors189dbname, ors189reqcollection);
			organisation.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors70dbname, ors70reqcollection);
			photo.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors338dbname, ors338reqcollection);
			result.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors081dbname, ors081reqcollection);
			ExternalSelection.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors268dbname, ors268reqcollection);
		} else if (swaggerVersion.equalsIgnoreCase("v2")) {
			booking.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors189dbname, ors189reqcollection);
			organisation.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors70dbname, ors70reqcollection);
			photo.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors338dbname, ors338reqcollection);
			result.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors081dbname, ors081reqcollection);
			ExternalSelection.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors268dbname,
					ors268reqcollection);
		}
		booking.connectandInsertORSCommonresDataInMongoDB(hostname, portnum, errordb, errorcollection);
		photo.connectandInsertORSCommonresDataInMongoDB(hostname, portnum, errordb, errorcollection);
		result.connectandInsertORSCommonresDataInMongoDB(hostname, portnum, errordb, errorcollection);
		ExternalSelection.connectandInsertErrorResponseMongoDB(hostname, portnum, ors268dbname, ors268reqcollection);
		SelectionSearch.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors169dbname, ors169reqcollection);
		SelectionSearch.connectandInsertORSCommonresDataInMongoDB(hostname, portnum, ors169dbname, ors169reqcollection);
		SelectionSearch.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors889dbname, ors889reqcollection);
		SelectionSearch.connectandInsertORSCommonresDataInMongoDB(hostname, portnum, ors889dbname, ors889reqcollection);
		SelectionSearch.connectandInsertDBdataReqDataInMongoDB(hostname, portnum, ors268dbname, ors268reqcollection);
		SelectionSearch.connectandInsertDBdataReqDataInMongoDB(hostname, portnum, ors169dbname, ors169reqcollection);
		SelectionSearch.connectandInsertDBdataReqDataInMongoDB(hostname, portnum, ors889dbname, ors889reqcollection);
	}

	@Then("^Setup the Server responses in the Mock server$")
	public void setup_the_Server_responses_in_the_Mock_server() throws IOException, ParseException {
		SelectionSearch.ConnectandInsertORSResDataInMongoDB(hostname, portnum, ors169dbname, ors169servercollection);
		SelectionSearch.TakeORSMockDataFromMongoDB(hostname, portnum, ors169dbname, ors169servercollection);
		SelectionSearch.PostORSMockDataIntoWiremock(ors169callbackurl, basepath);
		SelectionSearch.ConnectandInsertORSResDataInMongoDB(hostname, portnum, ors889dbname, ors889servercollection);
		SelectionSearch.TakeORSMockDataFromMongoDB(hostname, portnum, ors889dbname, ors889servercollection);
		SelectionSearch.PostORSMockDataIntoWiremock(ors889callbackurl, basepath);
	}

	@Then("^Test data setup completed sucessfully for Booking Selections Search Event$")
	public void test_data_setup_completed_sucessfully_for_Booking_Selections_Search_Event() {
		System.out.println("Reference data set up is completed successfully");

	}

}
