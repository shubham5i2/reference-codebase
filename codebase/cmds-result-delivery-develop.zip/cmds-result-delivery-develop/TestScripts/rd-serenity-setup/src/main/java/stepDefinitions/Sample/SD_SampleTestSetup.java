package stepDefinitions.Sample;
import common.CommonModules;
import java.io.FileNotFoundException;
import java.io.IOException;
import org.json.simple.parser.ParseException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import stepImplementations.Sample.SI_SampleTestSetup;


public class SD_SampleTestSetup extends CommonModules {
	
	CommonModules common = new CommonModules();
	SI_SampleTestSetup implimentation =new SI_SampleTestSetup();
	
	public static String sampledbname="";
 	public static String samplereqcollection="";
 	public static String sampleservercollection="";
 	public static String sampleBaseurl="";
 	public static String samplebasepath="";
 	public static String samplecallbackurl="";
 	
	
	@Given("^Clean Mongo DB database for Sample booking Test$")
	public void clean_Mongo_DB_database_for_bookingSample_IMOD()throws IOException{

    common.getEnvironmentConfigurationsOpen();
          
    hostname = common.getEnvironmentConfigurations("common.hostname");
    System.out.println("hostname is" +hostname);     
        
    portnum = Integer.parseInt(common.getEnvironmentConfigurations("common.portnum"));
    System.out.println("portnum is" +portnum);     

    errordb = common.getEnvironmentConfigurations("common.errordb");
    System.out.println("errordb is" +errordb); 
    
    errorcollection = common.getEnvironmentConfigurations("common.errorcollection");
    System.out.println("errorcollection is" +errorcollection); 
        
    sampledbname = common.getEnvironmentConfigurations("sample.dbname");
    System.out.println("sampledbname is" +sampledbname); 
    
    samplereqcollection = common.getEnvironmentConfigurations("sample.reqcollection");
    System.out.println("samplereqcollection is" +samplereqcollection);
    
    sampleservercollection = common.getEnvironmentConfigurations("sample.servercollection");   
    System.out.println("sampleservercollection is" +sampleservercollection); 
    
    samplecallbackurl = common.getEnvironmentConfigurations("sample.callbackurl");
    System.out.println("samplecallbackurl is" +samplecallbackurl); 
    
    samplebasepath = common.getEnvironmentConfigurations("sample.Basepath");
    System.out.println("samplebasepath is" +samplebasepath); 
    
    sampleBaseurl = common.getEnvironmentConfigurations("sample.BaseURL");  
    System.out.println("sampleBaseurl is" +sampleBaseurl); 
    
    
    implimentation.cleanDatebaseModule(hostname,portnum,sampledbname, samplereqcollection);
    implimentation.cleanDatebaseModule(hostname,portnum,errordb, errorcollection);
    implimentation.cleanDatebaseModule(hostname,portnum,sampledbname,sampleservercollection);
    
    
	String env = System.getenv("ENVIRONMENT");
	System.out.println("ENVIRONMENT is : "+env);
}

	@Then("^Insert the testdata files into mongodb for Booking$")
	public void insert_the_testdata_files_into_mongodb_for_Booking() throws FileNotFoundException, IOException, ParseException {
	implimentation.connectandInsertbookingReqDataInMongoDB(hostname,portnum,sampledbname,samplereqcollection);
	implimentation.connectandInsertbookingresDataInMongoDB(hostname,portnum,errordb,errorcollection);
   
}

@Then("^Insert mappings data into the Mock server$")
public void insert_mappings_data_into_the_Mock_server() {
    
	implimentation.ConnectandInsertBookingCommonResDataInMongoDB(hostname,portnum, sampledbname,sampleservercollection);    	
	implimentation.TakeBookingMockDataFromMongoDB(hostname,portnum, sampledbname,sampleservercollection);
	implimentation.PostBookingMockDataIntoWiremock(sampleBaseurl,samplebasepath);
}


@Then("^Testdata files setup completed successfully for Booking Sample$")
public void testdata_files_setup_completed_successfully_for_Booking_Sample() {
	System.out.println("Reference data set up is completed successfully");     
} 
	 
}
