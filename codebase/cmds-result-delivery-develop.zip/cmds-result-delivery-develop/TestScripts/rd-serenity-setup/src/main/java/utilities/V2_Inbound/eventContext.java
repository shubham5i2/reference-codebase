package utilities.V2_Inbound;

import lombok.Data;

@Data
public class eventContext {
	private String bookingUuid;
	private String userAction;
}
