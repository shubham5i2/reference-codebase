package utilities.locationChangedEvent;

import lombok.Data;

@Data
public class RequestEvent {
	
	private EventHeaders eventHeader;
	private RequestEventBody eventBody;
	private Object eventErrors;
	private Object audit;

}
