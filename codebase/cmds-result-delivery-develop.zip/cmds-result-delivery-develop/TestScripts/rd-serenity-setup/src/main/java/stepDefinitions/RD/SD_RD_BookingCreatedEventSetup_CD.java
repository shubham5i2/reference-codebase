package stepDefinitions.RD;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.json.simple.parser.ParseException;

import common.CommonModules;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import stepImplementations.RD.SI_RD_BookingCreatedEventSetup;
import stepImplementations.RD.SI_RD_BookingCreatedEventSetup_CD;
import stepImplementations.RD.SI_RD_PhotoPublishEventSetup;
import stepImplementations.RD.SI_RD_ResultReleasedEventSetup_CD;

public class SD_RD_BookingCreatedEventSetup_CD extends CommonModules {

	public static String ors189dbname = "";
	public static String ors189reqcollection = "";
	public static String ors189servercollection = "";
	public static String ors189baseurl = "";
	public static String ors081dbname = "";
	public static String ors081reqcollection = "";
	public static String ors081servercollection = "";
	public static String ors081baseurl = "";
	public static String basepath = "";
	public static String ors338dbname = "";
	public static String ors338reqcollection = "";
	public static String ors338servercollection = "";
	public static String ors338baseurl = "";
	public static String ors70dbname = "";
	public static String ors70reqcollection = "";
	public static String ors70servercollection = "";
	public static String ors70baseurl = "";

	public static String RD_AsyncDB;
	public static String RD_AsyncCollection;

	static CommonModules common = new CommonModules();
	public String swaggerVersion = System.getenv("SWAGGER_VERSION");
//	static SI_RD_BookingCreatedEventSetup setupImple = new SI_RD_BookingCreatedEventSetup();
	static SI_RD_BookingCreatedEventSetup_CD setupImplementation = new SI_RD_BookingCreatedEventSetup_CD();
	static SI_RD_PhotoPublishEventSetup photo = new SI_RD_PhotoPublishEventSetup();
	static SI_RD_ResultReleasedEventSetup_CD result = new SI_RD_ResultReleasedEventSetup_CD();

	@Given("^Clean the Mongo database for new data setup for bookingCreated/Updated Event for CD$")
	public void clean_the_Mongo_database_for_new_data_setup_for_bookingCreated_Updated_Event() throws IOException {
		common.getEnvironmentConfigurationsOpen();
		hostname = common.getEnvironmentConfigurations("common.hostname");
		portnum = Integer.parseInt(common.getEnvironmentConfigurations("common.portnum"));

		errordb = common.getEnvironmentConfigurations("common.errordb");
		errorcollection = common.getEnvironmentConfigurations("common.errorcollection");

		RD_AsyncCollection = common.getEnvironmentConfigurations("common.RD.AsyncCollection");
		RD_AsyncDB = common.getEnvironmentConfigurations("common.RD.AsyncDBname");

		ors189dbname = common.getEnvironmentConfigurations("int189.dbname");
		ors189reqcollection = common.getEnvironmentConfigurations("int189.reqcollection");
		ors189servercollection = common.getEnvironmentConfigurations("int189.servercollection");
		ors189baseurl = common.getEnvironmentConfigurations("int189.baseurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		setupImplementation.cleanDatebaseModule(hostname, portnum, ors189dbname, ors189reqcollection);
		setupImplementation.cleanDatebaseModule(hostname, portnum, errordb, errorcollection);
		setupImplementation.cleanDatebaseModule(hostname, portnum, ors189dbname, ors189servercollection);

		ors081dbname = common.getEnvironmentConfigurations("int081.dbname");
		ors081reqcollection = common.getEnvironmentConfigurations("int081.reqcollection");
		ors081servercollection = common.getEnvironmentConfigurations("int081.servercollection");
		ors081baseurl = common.getEnvironmentConfigurations("int081.baseurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		setupImplementation.cleanDatebaseModule(hostname, portnum, ors081dbname, ors081reqcollection);
		setupImplementation.cleanDatebaseModule(hostname, portnum, errordb, errorcollection);
		setupImplementation.cleanDatebaseModule(hostname, portnum, ors081dbname, ors081servercollection);

		ors338dbname = common.getEnvironmentConfigurations("int338.dbname");
		ors338reqcollection = common.getEnvironmentConfigurations("int338.reqcollection");
		ors338servercollection = common.getEnvironmentConfigurations("int338.servercollection");
		ors338baseurl = common.getEnvironmentConfigurations("int338.baseurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		setupImplementation.cleanDatebaseModule(hostname, portnum, ors338dbname, ors338reqcollection);
		setupImplementation.cleanDatebaseModule(hostname, portnum, errordb, errorcollection);
		setupImplementation.cleanDatebaseModule(hostname, portnum, ors338dbname, ors338servercollection);
		common.cleanAsyncDBCollection(hostname, portnum, RD_AsyncDB, RD_AsyncCollection);
	}

	@Then("^Insert the request and responses to mongodb for bookingCreated/Updated Event for CD$")
	public void insert_the_request_and_responses_to_mongodb_for_bookingCreated_Updated_Event()
			throws IOException, ParseException {
		if (swaggerVersion.equalsIgnoreCase("v1")) {
			setupImplementation.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors189dbname,
					ors189reqcollection);
			photo.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors338dbname, ors338reqcollection);
			result.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors081dbname, ors081reqcollection);
		} else if (swaggerVersion.equalsIgnoreCase("v2")) {
			setupImplementation.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors189dbname,
					ors189reqcollection);
			photo.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors338dbname, ors338reqcollection);
			result.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors081dbname, ors081reqcollection);
		}

		setupImplementation.connectandInsertORSCommonresDataInMongoDB(hostname, portnum, errordb, errorcollection);
		photo.connectandInsertORSCommonresDataInMongoDB(hostname, portnum, errordb, errorcollection);
		result.connectandInsertORSCommonresDataInMongoDB(hostname, portnum, errordb, errorcollection);
		setupImplementation.connectandInsertDBdataReqDataInMongoDB(hostname, portnum, ors189dbname, ors189reqcollection);
		setupImplementation.connectandInsertDBdataReqDataInMongoDB(hostname, portnum, ors338dbname, ors338reqcollection);
		setupImplementation.connectandInsertDBdataReqDataInMongoDB(hostname, portnum, ors081dbname, ors081reqcollection);
	}

	@Then("^Setup the Server responses in the Mock server for the TRF Flow for CD$")
	public void setup_the_Server_responses_in_the_Mock_server_for_the_TRF_Adapter_Flow()
			throws FileNotFoundException, IOException, ParseException {
		setupImplementation.ConnectandInsertORSResDataInMongoDBForTRFFlow(hostname, portnum, ors338dbname,
				ors338servercollection);
		setupImplementation.TakeORSMockDataFromMongoDB(hostname, portnum, ors338dbname, ors338servercollection);
		setupImplementation.PostORSMockDataIntoWiremock(ors338baseurl, basepath);
	}

	@Then("^Test data setup completed sucessfully for bookingCreated/Updated Event for CD$")
	public void test_data_setup_completed_sucessfully_for_bookingCreated_Updated_Event() {
		System.out.println("Test data set up is completed successfully");
	}
}
