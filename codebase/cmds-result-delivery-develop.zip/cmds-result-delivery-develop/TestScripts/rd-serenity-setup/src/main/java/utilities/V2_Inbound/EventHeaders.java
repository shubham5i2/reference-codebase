package utilities.V2_Inbound;

import lombok.Data;

@Data
public class EventHeaders {
	private String transactionId;
	private String callbackURL;
	private String correlationId;
	private String partnerCode;
	private String eventDateTime;
	private String eventDateTimeAsString;
	private String connectionId;
	private String eventName;
	private String xaccessToken;
    private eventContext eventContext;

}
