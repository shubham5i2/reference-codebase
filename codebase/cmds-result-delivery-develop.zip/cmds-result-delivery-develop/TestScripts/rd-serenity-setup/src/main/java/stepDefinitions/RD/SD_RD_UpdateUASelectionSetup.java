package stepDefinitions.RD;

import com.mongodb.*;
import com.mongodb.util.JSON;

import common.CommonModules;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import stepImplementations.RD.SI_RD_AcceptROSelectionSetup;
import stepImplementations.RD.SI_RD_BookingCreatedEventSetup;
import stepImplementations.RD.SI_RD_ROCreatedEventSetup;
import stepImplementations.RD.SI_RD_UpdateROSelectionSetup;
import stepImplementations.RD.SI_RD_UpdateUASelectionSetup;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import static io.restassured.RestAssured.given;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class SD_RD_UpdateUASelectionSetup extends CommonModules {

	static CommonModules common = new CommonModules();
	static SI_RD_BookingCreatedEventSetup booking = new SI_RD_BookingCreatedEventSetup();
	static SI_RD_ROCreatedEventSetup organisation = new SI_RD_ROCreatedEventSetup();
	static SI_RD_AcceptROSelectionSetup stepImplementation = new SI_RD_AcceptROSelectionSetup();
	static SI_RD_UpdateROSelectionSetup implementation = new SI_RD_UpdateROSelectionSetup();
	static SI_RD_UpdateUASelectionSetup uaSetup = new SI_RD_UpdateUASelectionSetup();
	public String swaggerVersion = System.getenv("SWAGGER_VERSION");
	public static String RD_AsyncDB;
	public static String RD_AsyncCollection;
	public static String ors468dbname = "";
	public static String ors468reqcollection = "";
	public static String ors468servercollection = "";
	public static String ors468callbackurl = "";
	protected static String cmds468resultActpath = "";
	protected static String cmds468resultActurl = "";

	public static String ors70dbname = "";
	public static String ors70reqcollection = "";
	public static String ors70servercollection = "";
	public static String ors70baseurl = "";

	public static String ors189dbname = "";
	public static String ors189reqcollection = "";
	public static String ors189servercollection = "";
	public static String ors189baseurl = "";
	public static String basepath = "";

	public static String randomUUIDString = "";
	public static String authURLIDP = "";
	public static String authReqIDP = "";
	public static String enviroment = "";
	public static String dbUrlSandbox = "";
	protected static String dbUrl = "";
	protected static String dbUrlDev = "";
	public static String accessTokenIDP;

	@Given("^Clean the Mondodb database for update selection IMOD-25998$")
	public void cleantheMondodbdatabaseforupdateselectionIMOD() throws IOException {
		common.getEnvironmentConfigurationsOpen();
		hostname = common.getEnvironmentConfigurations("common.hostname");
		portnum = Integer.parseInt(common.getEnvironmentConfigurations("common.portnum"));

		errordb = common.getEnvironmentConfigurations("common.errordb");
		errorcollection = common.getEnvironmentConfigurations("common.errorcollection");
		RD_AsyncCollection = common.getEnvironmentConfigurations("common.RD.AsyncCollection");
		RD_AsyncDB = common.getEnvironmentConfigurations("common.RD.AsyncDBname");
		ors189dbname = common.getEnvironmentConfigurations("int189.dbname");
		ors189reqcollection = common.getEnvironmentConfigurations("int189.reqcollection");
		ors189servercollection = common.getEnvironmentConfigurations("int189.servercollection");
		ors189baseurl = common.getEnvironmentConfigurations("int189.baseurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		booking.cleanDatebaseModule(hostname, portnum, ors189dbname, ors189reqcollection);
		booking.cleanDatebaseModule(hostname, portnum, ors189dbname, ors189servercollection);

		ors468dbname = common.getEnvironmentConfigurations("int468.dbname");
		ors468reqcollection = common.getEnvironmentConfigurations("int468.reqcollection");
		ors468servercollection = common.getEnvironmentConfigurations("int468.servercollection");
		ors468callbackurl = common.getEnvironmentConfigurations("int468.mockurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		implementation.cleanDatebaseModule(hostname, portnum, ors468dbname, ors468reqcollection);
		implementation.cleanDatebaseModule(hostname, portnum, ors468dbname, ors468servercollection);
		implementation.cleanDatebaseModule(hostname, portnum, errordb, errorcollection);
		common.cleanAsyncDBCollection(hostname, portnum, RD_AsyncDB, RD_AsyncCollection);
	}

	@Then("^Insert the request for IMOD-25998$")
	public void insert_the_request_IMOD() throws IOException, ParseException {
		if (swaggerVersion.equalsIgnoreCase("v1")) {
			booking.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors189dbname, ors189reqcollection);
			uaSetup.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors468dbname, ors468reqcollection);
		} else if (swaggerVersion.equalsIgnoreCase("v2")) {
			booking.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors189dbname, ors189reqcollection);
			uaSetup.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors468dbname, ors468reqcollection);
		}

		booking.connectandInsertORSCommonresDataInMongoDB(hostname, portnum, errordb, errorcollection);
		uaSetup.connectandInsertErrorResponseMongoDB(hostname, portnum, ors468dbname, ors468reqcollection);
		uaSetup.connectandInsertORSCommonresDataInMongoDB(hostname, portnum, errordb, errorcollection);
	}

	@Then("^Insert mock data into Ors Mock_Callback Server for UA Selection Setup$")
	public void insert_mock_data_into_Ors_Mock_Callback_Server_IMOD()
			throws FileNotFoundException, IOException, ParseException {

		uaSetup.ConnectandInsertORSResDataInMongoDB(hostname, portnum, ors468dbname, ors468servercollection);
		uaSetup.TakeORSMockDataFromMongoDB(hostname, portnum, ors468dbname, ors468servercollection);
		uaSetup.PostORSMockDataIntoWiremock(ors468callbackurl, basepath);
	}
}
