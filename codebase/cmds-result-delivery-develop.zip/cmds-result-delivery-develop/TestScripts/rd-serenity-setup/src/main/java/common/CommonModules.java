
package common;

import static io.restassured.RestAssured.given;
import static common.CommonModules.s3Client;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Properties;
import java.util.UUID;
import java.util.regex.Pattern;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.context.annotation.Profile;
import com.amazonaws.HttpMethod;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.auth.STSAssumeRoleSessionCredentialsProvider;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import common.dbabstraction.CMDSMongoClientAdapter;
import io.restassured.RestAssured;
import io.restassured.config.DecoderConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.core.Serenity;

public class CommonModules {

	static AmazonS3 s3Client;
	public static String hostname = "";
	public static Integer portnum;
	public static String errordb = "";
	public static String errorcollection;
	public static String basepath="";
	public static String resCollection= "";
	private final static String status = "Status";
	String response200 = "200";
	String response202 = "202";
	String response400 = "400";
	String response401 = "401";
	String response403 = "403";
	String tranResponseCode;
	protected String expResponse200 = "";
	protected String expResponse202 = "";
	protected String expResponse400 = "";
	protected String expResponse401 = "";
	protected String expResponse403 = "";
	protected String expResponse404 = "";
	String port_num = "";
	protected static Integer appID;
	String curlybraces = "{";
	String str = "";
	String verifybody = "";
	int startPosition = 13;
	int responselength = 16;
	int startpos = 19;
	int removeheadplus = 51;
	public static Response response;
	public static int removehead = 51;

	static Properties prop = new Properties();

	public void getEnvironmentConfigurationsOpen() throws  IOException,FileNotFoundException   {

		String sysEnvStr = System.getenv("PROPERTY_FILE_PATH");
		System.out.println("PROPERTY_FILE_PATH : " + sysEnvStr);
		
		InputStream input1 = new FileInputStream(sysEnvStr);
		InputStreamReader inputStreamReader = new InputStreamReader(input1);
		prop.load(inputStreamReader);
	}

	public static String getEnvironmentConfigurations(String variableName) {
		String variable = prop.getProperty(variableName);
		System.out.println(variableName + " = " + variable);
		return variable;
	}
	
	public void cleanBookingAsyncDatabase(String hostName, Integer portNum,String Asynccollection,String Asyndb) {
		CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostName, portNum);
		DB db = mongoclient.getDB(Asyndb);
		System.out.println("Mondb connected");
		DBCollection coll = db.getCollection(Asynccollection);
		coll.remove(new BasicDBObject());
	}
	
	public void cleanRIAsyncDatabase(String hostName, Integer portNum, String Asyndb, String Asynccollection) {
        CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostName, portNum);
        DB db = mongoclient.getDB(Asyndb);
        System.out.println("Mondb connected");
        DBCollection coll = db.getCollection(Asynccollection);
        coll.remove(new BasicDBObject());
    }
    public void cleanPRCAsyncDatabase(String hostName, Integer portNum, String Asyndb, String Asynccollection) {
        CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostName, portNum);
        DB db = mongoclient.getDB(Asyndb);
        System.out.println("Mondb connected");
        DBCollection coll = db.getCollection(Asynccollection);
        coll.remove(new BasicDBObject());
    }
    public void cleanAsyncDatabaseLds(String hostName, Integer portNum, String Asyndb, String Asynccollection) {
        CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostName, portNum);
        DB db = mongoclient.getDB(Asyndb);
        System.out.println("Mondb connected");
        DBCollection coll = db.getCollection(Asynccollection);
        coll.remove(new BasicDBObject());
    }
	
	public void cleanAsyncDBCollection(String hostName, Integer portNum, String AsyncDBName, String AsyncCollectionName) {

		CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostName, portNum);
        DB db = mongoclient.getDB(AsyncDBName);
        System.out.println("Mondb connected");
        DBCollection coll = db.getCollection(AsyncCollectionName);
        coll.remove(new BasicDBObject());
    }



	/************************************************************************
	 * Function Name: uploadFileToMockS3 Function Description: To Write the contents
	 * in a file and upload it to AWS S3 bucket
	 *************************************************************************/
	public static void uploadFileToMockS3(String bucketName, String fileName, String dataToUpload) throws IOException {
		s3Client = AmazonS3ClientBuilder.standard().withRegion(Regions.EU_WEST_2)
				.withCredentials(awsCredentialsProvider()).build();

		try (Writer writer = new BufferedWriter(
				new OutputStreamWriter(new FileOutputStream(fileName), StandardCharsets.UTF_8))) {
			writer.write(dataToUpload);
		}

		try (InputStream is = new FileInputStream(fileName)) {
			ObjectMetadata metadata = new ObjectMetadata();
			metadata.setContentType("binary/octet-stream");

			PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName, fileName, is, metadata);
			s3Client.putObject(putObjectRequest);
			System.out.println("File uploaded successfully");
		}

	}

	/************************************************************************
	 * Function Name: generatePreSignedUrl Function Description: To generate
	 * pre-signed URL for the uploaded files
	 *************************************************************************/
	public static String generatePreSignedUrl(String bucketName, String fileName) {
		Date expiration = new Date();
		long expTimeMillis = expiration.getTime();
		expTimeMillis += 1000 * 60 * 60;
		;
		expiration.setTime(expTimeMillis);
		GeneratePresignedUrlRequest generatePresignedUrlRequest = new GeneratePresignedUrlRequest(bucketName, fileName)
				.withMethod(HttpMethod.GET).withExpiration(expiration);
		URL url = s3Client.generatePresignedUrl(generatePresignedUrlRequest);

		System.out.println("Pre-Signed URL: " + url.toString());
		return url.toString();

	}

	/************************************************************************
	 * Function Name: AWSCredentialsProvider Function Description: AWS Credential
	 * provider method to use STS Assume Role in Pipeline
	 *************************************************************************/
/*
	public static AWSCredentialsProvider awsCredentialsProvider() {
		return new AWSCredentialsProvider() {
			@Override
			public AWSCredentials getCredentials() {
				DefaultAWSCredentialsProviderChain defaultAWSCredentialsProviderChain = new DefaultAWSCredentialsProviderChain();
				return defaultAWSCredentialsProviderChain.getCredentials();
			}

			@Override
			public void refresh() {
			}
		};
	}
	*/
	/************************************************************************
	 * Function Name: AWSCredentialsProvider Function Description: AWS Credential
	 * provider method to use STS Assume Role in local
	 *************************************************************************/
	
	  public static AWSCredentialsProvider awsCredentialsProvider() { return new
	  AWSCredentialsProvider() {
	  
	  @Override public AWSCredentials getCredentials() { final
	  STSAssumeRoleSessionCredentialsProvider sts = new
	  STSAssumeRoleSessionCredentialsProvider.Builder(
	  "arn:aws:iam::685269225798:role/ielts-cmds-role-shared-developer",
	  "test").build(); return sts.getCredentials(); }
	  
	  @Override public void refresh() {
	  
	  } }; }
	  
	 

	/************************************************************************
	 * Function Name: randomUUID Function Description: To get the random UUID Author
	 * Name: Madhuri Mandhare Date: 10/10/2020
	 * 
	 * @return
	 *************************************************************************/
	public static String randomUUID() {
		UUID uuid = UUID.randomUUID();
		return uuid.toString();
	}

	/************************************************************************
	 * Function Name: RetrieveToken Function Description: To get and return the JWT
	 * Access token at run time Author Name: Prabhakaran D Date: 15/10/2020
	 *************************************************************************/

	public static String RetrieveToken(String authURL, String authReq) {
		RestAssured.baseURI = authURL;
		String req = authReq;

		Response response = given().contentType(ContentType.JSON).log().all().body(req).post("oauth/token");

		JSONObject jsonObject = new JSONObject(response.getBody().asString());
		return jsonObject.get("access_token").toString();
	}

	public String getCommonExpectedResponse200MongoDB() throws org.json.simple.parser.ParseException {
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostname, portnum)) {
			System.out.println(errordb);
			System.out.println(hostname);
			System.out.println(portnum);
			DB db = mongoclient.getDB(errordb);
			DBCollection coll = db.getCollection(errorcollection);
			DBObject query = new BasicDBObject(status, new BasicDBObject("$eq", response200));
			DBObject result = coll.findOne(query);
			String expResponseconvert = getformatdoneinfunction(result);
			System.out.println(expResponseconvert);
			if (tranResponseCode.equals(response200)) {
				expResponse200 = expResponseconvert.toString();
			}
		}
		return expResponse200;
	}

	public String getCommonExpectedResponse202MongoDB() throws org.json.simple.parser.ParseException {
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostname, portnum)) {
			DB db = mongoclient.getDB(errordb);
			DBCollection coll = db.getCollection(errorcollection);
			DBObject query = new BasicDBObject(status, new BasicDBObject("$eq", response202));
			DBObject result = coll.findOne(query);
			String expResponseconvert = getformatdoneinfunction(result);
			if (tranResponseCode.equals(response202)) {
				expResponse202 = expResponseconvert.toString();
			}
		}
		return expResponse202;
	}

	public String getCommonExpectedResponse400MongoDB() throws org.json.simple.parser.ParseException {
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostname, portnum)) {
			DB db = mongoclient.getDB(errordb);
			DBCollection coll = db.getCollection(errorcollection);
			DBObject query = new BasicDBObject(status, new BasicDBObject("$eq", response400));
			DBObject result = coll.findOne(query);
			String expResponseconvert = getformatdoneinfunction(result);
			if (tranResponseCode.equals(response400)) {
				expResponse400 = expResponseconvert.toString();
			}
		}
		return expResponse400;

	}

	public String getCommonExpectedResponse401MongoDB() throws org.json.simple.parser.ParseException {
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostname, portnum)) {
			DB db = mongoclient.getDB(errordb);
			DBCollection coll = db.getCollection(errorcollection);
			DBObject query = new BasicDBObject(status, new BasicDBObject("$eq", response401));
			DBObject result = coll.findOne(query);
			String expResponseconvert = getformatdoneinfunction(result);
			if (tranResponseCode.equals(response401)) {
				expResponse401 = expResponseconvert.toString();
			}
		}
		return expResponse401;
	}

	public String getCommonExpectedResponse403MongoDB() throws org.json.simple.parser.ParseException {
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostname, portnum)) {
			DB db = mongoclient.getDB(errordb);
			DBCollection coll = db.getCollection(errorcollection);
			DBObject query = new BasicDBObject(status, new BasicDBObject("$eq", response403));
			DBObject result = coll.findOne(query);
			String expResponseconvert = getformatdoneinfunction(result);
			if (tranResponseCode.equals(response403)) {
				expResponse403 = expResponseconvert.toString();
			}
		}
		return expResponse403;
	}

	public String getformatdoneinfunction(DBObject result) throws org.json.simple.parser.ParseException {
		str = (String.valueOf(result));
		Integer length = str.length();
		String subpostbody = str.substring(removeheadplus, length);
		verifybody = curlybraces + subpostbody;
		tranResponseCode = verifybody.substring(startPosition, responselength);
		Integer bodylength = verifybody.length();
		String subverifybody = curlybraces + verifybody.substring(startpos, bodylength);
		return subverifybody;
	}

	public static Response postRequestToBookingDB(String postUrl, String accessToken, String postBody) {

		response = given()
				.config(RestAssuredConfig.config()
						.decoderConfig(DecoderConfig.decoderConfig().defaultContentCharset("UTF-8")))
				.headers("Authorization", "Bearer " + accessToken).contentType(ContentType.JSON).log().all()
				.body(postBody).post(postUrl);
		return response;

	}

	/************************************************************************
	 * Function Name: Booking Request Call (PUT) Function Description: To post
	 * request with common headers to API endpoint Author Name:
	 * 
	 * @return
	 * @throws ParseException 
	 *************************************************************************/
	public static Response commonRequestBooking(String actUrl, String actPath, String correlationId,
			String eventDateTime, String accessToken, String callBackURL, String postBody) throws ParseException {
		RestAssured.baseURI = actUrl;

		response = SerenityRest.given()
				.config(RestAssuredConfig.config()
						.decoderConfig(DecoderConfig.decoderConfig().defaultContentCharset("UTF-8")))
				.headers("correlationId", correlationId, "eventDateTime", eventDateTime, "Authorization",
						"Bearer " + accessToken, "callbackURL", callBackURL)
				.contentType(ContentType.JSON).log().all().body(postBody).basePath(actPath).when().put();
		return response;
	}

	public String getEnvironmentConfigurationshostname() {
		hostname = prop.getProperty("common.hostname");
		System.out.println("common.hostname:" + hostname);
		return hostname;
	}

	public String getEnvironmentConfigurationserrordb() {
		errordb = prop.getProperty("common.errordb");
		System.out.println("common.errordb:" + errordb);
		return errordb;
	}

	public String getEnvironmentConfigurationserrorcollection() {
		errorcollection = prop.getProperty("common.errorcollection");
		System.out.println("common.errorCollection-env:" + errorcollection);
		return errorcollection;
	}

	public String getEnvironmentConfigurationsbasepath() {
		basepath = prop.getProperty("common.path");
		return basepath;
	}

	@SuppressWarnings("deprecation")
	public static String connectMongoDBandfetchAsyncResponseForRDS(String hostname, Integer portnum,
			String transactionId) throws InterruptedException {
		Thread.sleep(6000);
		String async = null;
		String strVal = null;
		int removeHead = 51;
		int count = 1;
		boolean flag = false;
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostname, portnum)) {
			DB db = mongoclient.getDB("AsyncDB");
			DBCollection coll = db.getCollection("AsyncCollection");
			while (flag = false || count < 50) {
				Thread.sleep(100);
				DBObject query = new BasicDBObject("body.eventHeader.transactionId",
						new BasicDBObject("$eq", transactionId));
				DBObject result = coll.findOne(query);
				strVal = String.valueOf(result);

				if (strVal != null) {
					flag = true;
				}

				count++;
			}
			int length = strVal.length();
			String subpostbody = strVal.substring(removeHead, length);
			async = "{" + subpostbody;
			System.out.println("Async call from mongoDB-" + async);
		} catch (Exception e) {
			Serenity.recordReportData().withTitle("").andContents(e.toString());
			System.out.println("Required Async message not available in Mongo DB");

		}
		return async;
	}

	/************************************************************************
	 * Function Name: Booking Request Call (PUT) Function Description: To post
	 * request with common headers to API endpoint Author Name:
	 * 
	 * @return
	 *************************************************************************/
	public static Response commonROSelectionRequest(String actUrl, String actPath, String correlationId,
			String eventDateTime, String accessToken, String postBody) {
		RestAssured.baseURI = actUrl;
		response = SerenityRest.given()
				.config(RestAssuredConfig.config()
						.decoderConfig(DecoderConfig.decoderConfig().defaultContentCharset("UTF-8")))
				.headers("correlationId", correlationId, "eventDateTime", eventDateTime, "x-access-token",
						"Bearer " + accessToken)
				.contentType(ContentType.JSON).log().all().body(postBody).basePath(actPath).when().put();
		return response;
	}

	public static String connectMongoDBAndFetchAsyncMessage(String hostName, Integer portNum, String transactionId,String AsynDB,String AsynCollection)
			throws InterruptedException {
		System.out.println("Transcation Id" + " " + transactionId);
		String async = null;
		String strVal = null;
		int count = 1;
		boolean flag = false;
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostname, portnum)) {
			DB db = mongoclient.getDB(AsynDB);
			DBCollection coll = db.getCollection(AsynCollection);
			while (flag = false || count < 50) {
				Thread.sleep(500);

				DBObject query = new BasicDBObject("body.Message",
						new BasicDBObject("$regex", ".*" + Pattern.quote(transactionId) + ".*"));

				DBObject result = coll.findOne(query);
				strVal = String.valueOf(result);

				if (strVal != null) {
					flag = true;
				}

				count++;
			}
			Integer length = strVal.length();
			String subpostbody = strVal.substring(removehead, length);
			async = "{" + subpostbody;
			System.out.println("Async Message from mongoDB - " + async);
		} catch (Exception e) {
			Serenity.recordReportData().withTitle("").andContents(e.toString());
			System.out.println("no async message");
		}
		return async;
	}
protected static String ActUrl;
	
	public  String getMxUIActURLURLExecutionEnvironment() throws IOException
	{
		String Env = System.getenv("ENVIRONMENT"); 
		System.out.println(System.getenv("ENVIRONMENT")+"enrivron");
		switch (Env) {
		 case "sandbox":
		 ActUrl = getEnvironmentConfigurations("UIAPIgateWay.Sandbox.ActURL");
		   break;
		 case "sandbox2": 
		 ActUrl = getEnvironmentConfigurations("UIAPIgateWay.Sandbox2.ActURL");
		   break;
		 case "dev":
		 ActUrl = getEnvironmentConfigurations("UIAPIgateWay.Dev.ActURL");
		   break;
		 case "sit":
		 ActUrl = getEnvironmentConfigurations("UIAPIgateWay.SIT.ActURL");
		   break;
		}
		return ActUrl;	
	}
	
	protected static String AccessToken;
	public  String getUIAPIGatewayAccessToken()
	{
		String Env = System.getenv("ENVIRONMENT");
		System.out.println(Env);
		switch (Env) {
		 case "sandbox":
			 AccessToken = GenerateUIAccessTokenSandbox();
		   break;
		 case "sandbox2": 
			 AccessToken = GenerateUIAccessTokenSandbox();
		   break;

		 case "dev":
			 AccessToken = GenerateUIAccessTokenDev();
		   break;
		 case "sit":
			 AccessToken = GenerateUIAccessTokenDev();
		   break;
		}
		return AccessToken;
		

	}
	public String GenerateUIAccessTokenSandbox(){
		RestAssured.baseURI = "https://cmds-sandbox.eu.auth0.com";
		Response response = given().contentType("application/x-www-form-urlencoded; charset=utf-8")
		        .formParam("grant_type", "password")
		        .formParam("username", "IELTSGlobalOperationsAdmin@cambridgeassessment.org.uk")
		        .formParam("password", "TestUser@1234")
		        .formParam("audience", "cmds-sandbox-ui-api")
		        .formParam("scope", "read:sample")
		        .formParam("client_id", "6npJHKKJiGZHkLIPN5aBW3naE0lAmOnY")
		        .formParam("client_secret", "TFQ91o5YayqGriFcJ1EZV38_wNhO7pztp_6IuxaCH_aoC4CHQbUuVMvIQrRhRCLO").log().all().basePath("oauth/token").when().post();

		JSONObject jsonObject = new JSONObject(response.getBody().asString()); 
		return jsonObject.get("access_token").toString();

		}
	public String GenerateUIAccessTokenDev(){
		RestAssured.baseURI = "https://cmds-dev.eu.auth0.com";
		Response response = given().contentType("application/x-www-form-urlencoded; charset=utf-8")
		        .formParam("grant_type", "password")
		        .formParam("username", "IELTSGlobalOperationsAdmin@cambridgeassessment.org.uk")
		        .formParam("password", "TestUser@1234")
		        .formParam("audience", "cmds-dev-ui-api")
		        .formParam("scope", "read:sample")
		        .formParam("client_id", "jT0ascC0inkEvfmgbM7x5L3lxqYGQL50")
		        .formParam("client_secret", "jqnlwR2Dc6Us3PbybxUXkqyscCvEATFGFltWg2yyM9hfte9_NKdE2b-kpkhYO5AP").log().all().basePath("oauth/token").when().post();

		JSONObject jsonObject = new JSONObject(response.getBody().asString()); 
		return jsonObject.get("access_token").toString();

		}
	public Integer getEnvironmentConfigurationsPortnum()  {
        port_num = prop.getProperty("common.portnum");
        portnum = Integer.parseInt(port_num);
        return portnum;
    }
	
}
