package stepImplementations.RD;

import com.mongodb.*;
import com.mongodb.util.JSON;

import common.CommonModules;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.rest.SerenityRest;

import org.json.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import common.dbabstraction.CMDSMongoClientAdapter;
import static io.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;

public class SI_RD_ResultReleasedEventSetup_CD extends CommonModules {

	public String testdataPath = System.getenv("TEST_SETUP_FILE_PATH");
	public String var0 = testdataPath;
	int counter1 = 0;
	int cnt = 0;
	int counter = 0;
	int count = 0;
	int totalindex = 0;
	String str = "";
	String postbody = "";
	String inputjson[] = new String[60];
	int removehead = 51;
	static String postBody = "";
	static boolean validationFail1 = true;
	static Response response = null;
	static String expectedTransactionID = "";
	static String expectedBookingUuid = "";
	public static String responseFromPOSTCall = null;
	String curlybraces = "{";
	int removeHead = 51;
	String strVal = "";
	int actResponseCode;
	String actResponse = "";
	int actualResponselen;
	int resPONSECODE202 = 202;
	int resPONSECODE400 = 400;
	int resPONSECODE401 = 401;
	int resPONSECODE403 = 403;
	int expectedTranLength202 = 56;
	int expectedTranLength400 = 35;
	static String valueInJsonFile;
	static ArrayList<String> bookingLineUuid = new ArrayList<>();
	static ArrayList<String> externalBookingLineUuid = new ArrayList<>();
	String neweventdatetime;
	public static String expectedresultUuid = "";
	public static String expectedbookingUuid = "";
	public static String expectedexternalTestId = "";
	public static String expectedtrfNumber = "";
	public static String expectedresultScore = "";
	public static String expectedcefrLevel = "";
	public static String expectedresultTypeUuid = "";
	public static String expectedpublishedTime = "";

	boolean allFields = true;
	boolean minimumFields = true;
	JSONArray arrayExpected;
	JSONArray arrayActual;
	String eventName;

	ArrayList<String> requestFields = new ArrayList<>(Arrays.asList("eventBody_bookingResultInfo_resultUuid",
			"eventBody_bookingResultInfo_bookingUuid", "eventBody_bookingResultInfo_resultTypeUuid",
			"eventBody_bookingResultInfo_trfNumber", "eventBody_bookingResultInfo_overallScore",
			"eventBody_bookingResultInfo_cefrLevel", "eventBody_bookingResultInfo_bookingResultConcurrencyVersion",
			"eventBody_bookingResultInfo_bookingResultStatus_resultsStatusHistoryUuid",
			"eventBody_bookingResultInfo_bookingResultStatus_resultStatusLabelUuid",
			"eventBody_bookingResultInfo_bookingResultStatus_resultStatusComment",
			"eventBody_bookingResultInfo_bookingResultStatus_resultStatusCommentUuid",
			"eventBody_bookingResultInfo_bookingResultStatus_resultStatusUpdatedBy"));

	static ArrayList<String> resultLines = new ArrayList<>(
			Arrays.asList("resultLineUuid", "resultLineScore", "productUuid", "bookingLineUuid"));

	public void cleanDatebaseModule(String hostname, Integer portnum, String dbname, String collname) {
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostname, portnum)) {
			DB db = mongoclient.getDB(dbname);
			System.out.println("Mondb connected");
			DBCollection coll = db.getCollection(collname);
			coll.remove(new BasicDBObject());
		}
	}
	
	public void connectandInsertDBdataReqDataInMongoDB(String arg1, Integer arg2, String arg3, String arg4)
			throws IOException, ParseException {

		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(arg1, arg2)) {
			DB db = mongoclient.getDB(arg3);
			DBCollection collstr = db.getCollection(arg4);
			String var1 = "/RDDB_testdata/ReferenceRequest";
			String var3 = ".json";
			int cntx = 1;
			while (counter < 1) {
				int var2 = cntx;
				String pathstr = var0 + var1 + var2 + var3;
				JSONParser parser = new JSONParser();
				Object obj = parser.parse(new FileReader(pathstr));
				JSONObject jsonObject = (JSONObject) obj;
				System.out.println("Json : " + jsonObject);
				DBObject object = (DBObject) JSON.parse(jsonObject.toString());
				collstr.insert(object);
				counter++;
				cntx++;
			}
		}
	}

	public void connectandInsertORSReqDataInMongoDB(String arg1, Integer arg2, String arg3, String arg4)
			throws IOException, ParseException {

		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(arg1, arg2)) {
			DB db = mongoclient.getDB(arg3);
			DBCollection collstr = db.getCollection(arg4);
			String var1 = "/RDResultReleasedEvent/ReferenceRequest";
			String var3 = ".json";
			int cntx = 1;
			while (counter < 56) {

				int var2 = cntx;
				String pathstr = var0 + var1 + var2 + var3;
				JSONParser parser = new JSONParser();
				Object obj = parser.parse(new FileReader(pathstr));
				JSONObject jsonObject = (JSONObject) obj;
				System.out.println("Json : " + jsonObject);
				DBObject object = (DBObject) JSON.parse(jsonObject.toString());
				collstr.insert(object);
				counter++;
				cntx++;
			}
		}
	}

	public void v2_connectandInsertORSReqDataInMongoDB(String arg1, Integer arg2, String arg3, String arg4)
			throws IOException, ParseException {

		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(arg1, arg2)) {
			DB db = mongoclient.getDB(arg3);
			DBCollection collstr = db.getCollection(arg4);
			String var1 = "/RDResultReleasedEvent/v2_ReferenceRequest";
			String var3 = ".json";
			int cntx = 1;
			while (counter < 65) {
				int var2 = cntx;
				String pathstr = var0 + var1 + var2 + var3;
				JSONParser parser = new JSONParser();
				Object obj = parser.parse(new FileReader(pathstr));
				JSONObject jsonObject = (JSONObject) obj;
				System.out.println("Json : " + jsonObject);
				DBObject object = (DBObject) JSON.parse(jsonObject.toString());
				collstr.insert(object);
				counter++;
				cntx++;
			}
		}
	}

	public void ConnectandInsertORSResDataInMongoDB(String arg1, Integer arg2, String arg3, String arg4)
			throws FileNotFoundException, IOException, ParseException {
		CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(arg1, arg2);
		DB db = mongoclient.getDB(arg3);
		System.out.println("Mondb connected");
		DBCollection collstr = db.getCollection(arg4);
		String var1 = "/RDResultReleasedEvent/ReferenceResponse";
		String var3 = ".json";
		int cntx = 1;
		counter = 0;
		while (counter < 2) {
			int var2 = cntx;
			String pathstr = var0 + var1 + var2 + var3;
			System.out.println("pathstr :" + pathstr);
			JSONParser parser = new JSONParser();
			Object obj = parser.parse(new FileReader(pathstr));
			JSONObject jsonObject = (JSONObject) obj;
			System.out.println("Json : " + jsonObject);
			DBObject object = (DBObject) JSON.parse(jsonObject.toString());
			collstr.insert(object);
			counter++;
			cntx++;
		}
	}

	public void ConnectandInsertORSResDataInMongoDBForLAFlow(String arg1, Integer arg2, String arg3, String arg4)
			throws FileNotFoundException, IOException, ParseException {
		CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(arg1, arg2);
		DB db = mongoclient.getDB(arg3);
		System.out.println("Mondb connected");
		DBCollection collstr = db.getCollection(arg4);
		String var1 = "/RDLegacyAdapterMappings/ReferenceResponse";
		String var3 = ".json";
		int cntx = 1;
		counter = 0;
		while (counter < 2) {
			int var2 = cntx;
			String pathstr = var0 + var1 + var2 + var3;
			System.out.println("pathstr :" + pathstr);
			JSONParser parser = new JSONParser();
			Object obj = parser.parse(new FileReader(pathstr));
			JSONObject jsonObject = (JSONObject) obj;
			System.out.println("Json : " + jsonObject);
			DBObject object = (DBObject) JSON.parse(jsonObject.toString());
			collstr.insert(object);
			counter++;
			cntx++;
		}
	}

	public void connectandInsertORSCommonresDataInMongoDB(String arg1, Integer arg2, String arg3, String arg4) {
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(arg1, arg2)) {
			DB db = mongoclient.getDB(arg3);
			System.out.println("Mondb connected");
			DBCollection collstr = db.getCollection(arg4);
			String Var1 = "/commonerrorcodes/CommonResponse";
			String Var3 = ".json";
			int cntl = 1;
			while (counter1 < 5) {
				int Var2 = cntl;
				String pathstr = var0 + Var1 + Var2 + Var3;
				System.out.println("pathstr :" + pathstr);
				JSONParser parser = new JSONParser();
				Object obj = parser.parse(new FileReader(pathstr));
				JSONObject jsonObject = (JSONObject) obj;
				System.out.println("Json : " + jsonObject);
				DBObject object = (DBObject) JSON.parse(jsonObject.toString());
				collstr.insert(object);
				counter1++;
				cntl++;
			}
		} catch (IOException | ParseException e) {
			e.printStackTrace();
		}
	}

	public void TakeORSMockDataFromMongoDB(String hostname, Integer portnum, String dbname, String collectionname) {
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostname, portnum)) {
			DB db = mongoclient.getDB(dbname);
			DBCollection coll = db.getCollection(collectionname);
			DBCursor cursor = coll.find();
			int i = 0;
			while (cursor.hasNext()) {

				DBObject result = cursor.next();
				str = new String(String.valueOf(result));
				Integer length = str.length();
				String subpostbody = str.substring(removehead, length);
				postbody = "{" + subpostbody;
				inputjson[i] = postbody;
				i++;
				totalindex = i;
			}
		}
	}

	public void PostORSMockDataIntoWiremock(String orsCallbackurl, String mockpath) {

		while (count < totalindex) {
			postbody = inputjson[count];
			RestAssured.baseURI = orsCallbackurl;
			System.out.println("path is:" + orsCallbackurl);
			RestAssured.basePath = "";
			Response response = given().contentType(ContentType.TEXT).log().all().body(postbody).post(mockpath);
			response.prettyPrint();
			count++;
		}
	}

	/************************************************************************
	 * Function Name: postRequest Function Description: To post request body with
	 * headers to API endpoint
	 * 
	 * @throws InterruptedException
	 *************************************************************************/
	public Response postRequest(String actUrl, String actPath, String destination, String envKey, String accessToken)
			throws InterruptedException {
		Thread.sleep(100);
		RestAssured.baseURI = actUrl;
		response = SerenityRest.given()
				.headers("envKey", envKey, "destination", destination, "Authorization", "Bearer " + accessToken)
				.contentType(ContentType.JSON).log().all().body(postBody).post(actPath);
		return response;
	}

	/************************************************************************
	 * Function Name: verifyResponse Function Description: To validate the response
	 * code
	 *************************************************************************/
	public void verifyResponse() {

		actResponseCode = response.getStatusCode();
		actResponse = response.asString();

		if (actResponseCode == resPONSECODE202) {
			assertEquals(actResponseCode, resPONSECODE202);
			System.out.println("ResponseCode: " + actResponseCode);
			System.out.println("Response: " + actResponse);
			Serenity.recordReportData().withTitle("Response").andContents(actResponse);
		} else {
			assertEquals(actResponseCode, resPONSECODE400);
		}
	}

	/************************************************************************
	 * Function Name: verifyResponseStatusCode Function Description: To validate the
	 * response code
	 *************************************************************************/
	public void verifyResponseStatusCode(int expstatusCode) {

		actResponseCode = response.getStatusCode();
		actResponse = response.asString();

		if (actResponseCode == expstatusCode) {
			assertEquals(actResponseCode, expstatusCode);
			System.out.println("ResponseCode: " + actResponseCode);
			System.out.println("Response: " + actResponse);
		} else {
			assertEquals(actResponseCode, resPONSECODE400);
		}
	}

	/************************************************************************
	 * Function Name: getInputRequestBodyUsingTransactionId Function Description: To
	 * get the required request body from MongoDB id and fetch the expected values
	 * 
	 * @throws InterruptedException
	 *************************************************************************/
	public String acceptanceCriteria;

	@SuppressWarnings("deprecation")
	public String getInputRequestBodyUsingTransactionId(String hostName, Integer portNum, String dbName,
			String requestCollectionName, String transactionId) throws InterruptedException {
		acceptanceCriteria = transactionId;
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostName, portNum);) {
			DB db = mongoclient.getDB(dbName);
			DBCollection coll = db.getCollection(requestCollectionName);
			DBObject query = new BasicDBObject("eventHeader.transactionId", new BasicDBObject("$eq", transactionId));
			DBObject result = coll.findOne(query);
			String str = String.valueOf(result);
			Integer length = str.length();
			String subpostbody = str.substring(removehead, length);
			String postbodyRaw = curlybraces + subpostbody;
			expectedTransactionID = CommonModules.randomUUID();
			postBody = postbodyRaw.replaceAll(transactionId, expectedTransactionID);

			String resultUuid = getResultUuidInRequest();
			String bookingUuid = getBookingUuidInRequest();
			String correlationid = getCorrelationIdInRequest();
			String eventdatetime = geteventDateTimeInRequest();
			String transactionid = getTransactionIdInRequest();

			String newcorrelationid = CommonModules.randomUUID();
			expectedTransactionID = CommonModules.randomUUID();
			String newbookingUuid = CommonModules.randomUUID();
			String newresultUuid = CommonModules.randomUUID();

			LocalDateTime currenttimestamp = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			String neweventdatetime = currenttimestamp.format(formatter).toString();

			ArrayList<String> bookinglineUuidList = getExpectedBookingLineUuid();
			ArrayList<String> resultlineUuidList = getExpectedResultLineUuid();
			ArrayList<String> productUuidList = getExpectedProductUuid();

			postBody = postBody.replaceAll(correlationid, newcorrelationid);
			postBody = postBody.replaceAll(transactionid, expectedTransactionID);
			postBody = postBody.replaceAll(eventdatetime, neweventdatetime);
			postBody = postBody.replaceAll(bookingUuid,
					SI_RD_BookingCreatedConsumptionForSelectionSetup.expectedbookingUuid);
			postBody = postBody.replaceAll(resultUuid, newresultUuid);

			for (int i = 0; i < bookinglineUuidList.size(); i++) {
				String bookinglineUuid = bookinglineUuidList.get(i).toString();
				postBody = postBody.replaceAll(bookinglineUuid,
						SI_RD_BookingCreatedConsumptionForSelectionSetup.expectedBookingLineUuidList.get(i));
			}

			for (int i = 0; i < resultlineUuidList.size(); i++) {
				String resultlineUuid = resultlineUuidList.get(i).toString();
				String newResultLineUuid = CommonModules.randomUUID();
				postBody = postBody.replaceAll(resultlineUuid, newResultLineUuid);
			}

			/*
			 * for(int i=0;i<productUuidList.size();i++) { String productUuid =
			 * productUuidList.get(i).toString(); postBody =
			 * postBody.replaceAll(productUuid,
			 * SI_RD_BookingCreatedConsumptionForSelectionSetup.expectedProductUuidList.get(
			 * i)); }
			 */
		} catch (Exception e) {
			System.out.println("Error");
		}
		System.out.println(postBody);
		return postBody;
	}

	public void insertRecordInMongoDB(String hostName, Integer portNum, String dbName, String requestCollectionName)
			throws ParseException {
		verifyFieldValueInRequest("eventHeader_eventName");
		eventName = valueInJsonFile;
		postBody = postBody.replace(eventName, eventName + "_" + acceptanceCriteria);

		try (CMDSMongoClientAdapter mongoclient1 = new CMDSMongoClientAdapter(hostName, portNum)) {
			DB db1 = mongoclient1.getDB(dbName);
			DBCollection collstr = db1.getCollection(requestCollectionName);
			DBObject object = (DBObject) JSON.parse(postBody.toString());
			collstr.insert(object);
		} catch (Exception e) {
			System.out.println("Error");
		}
	}

	public String getResultUuidInRequest() throws ParseException {
		verifyFieldValueInRequest("eventBody_bookingResultInfo_resultUuid");
		return valueInJsonFile;
	}

	public String getBookingUuidInRequest() throws ParseException {
		verifyFieldValueInRequest("eventBody_bookingResultInfo_bookingUuid");
		return valueInJsonFile;
	}

	public String getCorrelationIdInRequest() throws ParseException {
		verifyFieldValueInRequest("eventHeader_correlationId");
		return valueInJsonFile;
	}

	public String getTransactionIdInRequest() throws ParseException {
		verifyFieldValueInRequest("eventHeader_transactionId");
		return valueInJsonFile;
	}

	public String getEventNameInRequest() throws ParseException {
		verifyFieldValueInRequest("eventHeader_eventName");
		return valueInJsonFile;
	}

	public String geteventDateTimeInRequest() throws ParseException {
		verifyFieldValueInRequest("eventHeader_eventDateTime");
		return valueInJsonFile;
	}

	public void getExpectedValuesFromResultLines() throws ParseException {
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(postBody);
		JSONObject jsonObject = (JSONObject) obj;
		Object EventBody = jsonObject.get("eventBody");
		String eventBody = EventBody.toString();
		Object obj1 = parser.parse(eventBody);
		JSONObject jsonObject1 = (JSONObject) obj1;
		JSONObject jsonObject2 = (JSONObject) jsonObject1.get("bookingResultInfo");
		String jsonResponse1 = jsonObject2.get("bookingResultLines").toString();
		arrayExpected = new JSONArray(jsonResponse1);
	}

	public ArrayList<String> getExpectedBookingLineUuid() throws ParseException {
		getExpectedValuesFromResultLines();
		String bookingLineUuid = null;
		boolean containNull = true;
		ArrayList<String> expectedBookingLineUuidList = new ArrayList<String>();
		for (int i = 0; i < arrayExpected.length(); i++) {
			org.json.JSONObject innerJsonObject = arrayExpected.getJSONObject(i);
			bookingLineUuid = (String) innerJsonObject.optString("bookingLineUuid");
			expectedBookingLineUuidList.add(bookingLineUuid);
			if (bookingLineUuid == null || bookingLineUuid.isEmpty()) {
				containNull = false;
			}
		}
		return expectedBookingLineUuidList;
	}

	public ArrayList<String> getExpectedProductUuid() throws ParseException {
		getExpectedValuesFromResultLines();
		String productUuid = null;
		boolean containNull = true;
		ArrayList<String> expectedProductUuidList = new ArrayList<String>();
		for (int i = 0; i < arrayExpected.length(); i++) {
			org.json.JSONObject innerJsonObject = arrayExpected.getJSONObject(i);
			productUuid = (String) innerJsonObject.optString("productUuid");
			expectedProductUuidList.add(productUuid);
			if (productUuid == null || productUuid.isEmpty()) {
				containNull = false;
			}
		}
		return expectedProductUuidList;
	}

	public ArrayList<String> getExpectedResultLineUuid() throws ParseException {
		getExpectedValuesFromResultLines();
		String resultLineUuid = null;
		boolean containNull = true;
		ArrayList<String> expectedResultLineUuidList = new ArrayList<String>();
		for (int i = 0; i < arrayExpected.length(); i++) {
			org.json.JSONObject innerJsonObject = arrayExpected.getJSONObject(i);
			resultLineUuid = (String) innerJsonObject.optString("resultLineUuid");
			expectedResultLineUuidList.add(resultLineUuid);
			if (resultLineUuid == null || resultLineUuid.isEmpty()) {
				containNull = false;
			}
		}
		return expectedResultLineUuidList;
	}

	public static Boolean verifyFieldValueInRequest(String fieldValue) throws ParseException {
		JSONParser parser = new JSONParser();
		JSONObject json = (JSONObject) parser.parse(postBody);
		try {
			ArrayList<String> json1 = new ArrayList<>();
			if (fieldValue.contains("_")) {
				String[] values = fieldValue.split("_");
				for (int i = 0; i < values.length; i++) {
					json1.add(values[i]);
				}
				for (int i = 0; i < values.length - 1; i++) {
					String counter = json1.get(i);
					valueInJsonFile = json.get(counter).toString();
					// valueInJsonFile = valueInJsonFile.replace("[{", "{").replace("}]", "}");
					json = (JSONObject) parser.parse(valueInJsonFile);
				}
				try {
					String counter = json1.get(json1.size() - 1);
					valueInJsonFile = (String) json.get(counter);
				} catch (ClassCastException e) {
					String counter = json1.get(json1.size() - 1);
					valueInJsonFile = String.valueOf(json.get(counter));
				}

			} else {
				valueInJsonFile = json.get(fieldValue).toString();
			}
			if (valueInJsonFile == null || valueInJsonFile.equalsIgnoreCase("")) {
				Serenity.recordReportData().asEvidence().withTitle("Field or Field value is not provided : ")
						.andContents(fieldValue);
				validationFail1 = false;

			} else {
				validationFail1 = true;
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return validationFail1;
	}

}
