package stepImplementations.RD;

import static io.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;

import org.json.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Assert;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import common.dbabstraction.CMDSMongoClientAdapter;
import com.mongodb.util.JSON;

import common.CommonModules;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.rest.SerenityRest;

public class SI_RD_PhotoPublishEventSetup {

	public String testdataPath = System.getenv("TEST_SETUP_FILE_PATH");
	public String var0 = testdataPath;
	int counter1 = 0;
	int cnt = 0;
	int counter = 0;
	int count = 0;
	int totalindex = 0;
	String str = "";
	String postbody = "";
	String inputjson[] = new String[20];
	int removehead = 51;
	static String postBody = "";
	static boolean validationFail1 = true;
	static Response response = null;
	static String expectedTransactionID = "";
	static String expectedBookingUuid = "";
	public static String responseFromPOSTCall = null;
	String curlybraces = "{";
	int removeHead = 51;
	String strVal = "";
	int actResponseCode;
	String actResponse = "";
	int actualResponselen;
	int resPONSECODE202 = 202;
	int resPONSECODE400 = 400;
	int resPONSECODE401 = 401;
	int resPONSECODE403 = 403;
	int expectedTranLength202 = 56;
	int expectedTranLength400 = 35;
	static String valueInJsonFile;
	static ArrayList<String> bookingLineUuid = new ArrayList<>();
	static ArrayList<String> externalBookingLineUuid = new ArrayList<>();
	String neweventdatetime;

	public static String expected_bookingUuid = "";
	public static String expected_photoUuid = "";
	public static String expected_compositeCandidateNumber = "";
	public static String expected_photoTypeUuid = "";
	public static String expected_photoPath = "";
	public static String expected_photoVersion = "";

	public static String actualBookingUuid = "";
	public static String actualPhotoUuid = "";
	public static String actualPhotoTypeUuid = "";
	public static String actualPhotoPath = "";
	public static String actualPhotoVersion = "";

	boolean allFields = true;
	boolean minimumFields = true;
	JSONArray arrayExpected;
	JSONArray arrayActual;
	String eventName;

	ArrayList<String> requestFields = new ArrayList<>(
			Arrays.asList("eventBody_photoUuid", "eventBody_bookingUuid", "eventBody_compositeCandidateNumber",
					"eventBody_photoTypeUuid", "eventBody_photoPath", "eventBody_photoVersion"));

	public void cleanDatebaseModule(String hostname, Integer portnum, String dbname, String collname) {
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostname, portnum)) {
			DB db = mongoclient.getDB(dbname);
			System.out.println("Mondb connected");
			DBCollection coll = db.getCollection(collname);
			coll.remove(new BasicDBObject());
		}
	}

	public static void connectMongoDB(String hostname, Integer portnum) throws InterruptedException, ParseException {
		String strVal;
		strVal = CommonModules.connectMongoDBandfetchAsyncResponseForRDS(hostname, portnum, expectedTransactionID);
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject = (JSONObject) jsonParser.parse(strVal);
		JSONObject jsonResponse = (JSONObject) jsonObject.get("body");
		responseFromPOSTCall = jsonResponse.toString();
		Serenity.recordReportData().withTitle("Actual Response on Topic-Out:").andContents(responseFromPOSTCall);
	}

	public void connectandInsertDBdataReqDataInMongoDB(String arg1, Integer arg2, String arg3, String arg4)
			throws IOException, ParseException {

		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(arg1, arg2)) {
			DB db = mongoclient.getDB(arg3);
			DBCollection collstr = db.getCollection(arg4);
			String var1 = "/RDDB_testdata/ReferenceRequest";
			String var3 = ".json";
			int cntx = 1;
			while (counter < 1) {
				int var2 = cntx;
				String pathstr = var0 + var1 + var2 + var3;
				JSONParser parser = new JSONParser();
				Object obj = parser.parse(new FileReader(pathstr));
				JSONObject jsonObject = (JSONObject) obj;
				System.out.println("Json : " + jsonObject);
				DBObject object = (DBObject) JSON.parse(jsonObject.toString());
				collstr.insert(object);
				counter++;
				cntx++;
			}
		}
	}
	
	public void connectandInsertORSReqDataInMongoDB(String arg1, Integer arg2, String arg3, String arg4)
			throws IOException, ParseException {

		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(arg1, arg2)) {
			DB db = mongoclient.getDB(arg3);
			DBCollection collstr = db.getCollection(arg4);
			String var1 = "/RDPhotoPublishEvent/ReferenceRequest";
			String var3 = ".json";
			int cntx = 1;
			while (counter < 20) {
				int var2 = cntx;
				String pathstr = var0 + var1 + var2 + var3;
				JSONParser parser = new JSONParser();
				Object obj = parser.parse(new FileReader(pathstr));
				JSONObject jsonObject = (JSONObject) obj;
				System.out.println("Json : " + jsonObject);
				DBObject object = (DBObject) JSON.parse(jsonObject.toString());
				collstr.insert(object);
				counter++;
				cntx++;
			}
		}
	}

	public void v2_connectandInsertORSReqDataInMongoDB(String arg1, Integer arg2, String arg3, String arg4)
			throws IOException, ParseException {

		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(arg1, arg2)) {
			DB db = mongoclient.getDB(arg3);
			DBCollection collstr = db.getCollection(arg4);
			String var1 = "/RDPhotoPublishEvent/v2_ReferenceRequest";
			String var3 = ".json";
			int cntx = 1;
			while (counter < 23) {
				int var2 = cntx;
				String pathstr = var0 + var1 + var2 + var3;
				JSONParser parser = new JSONParser();
				Object obj = parser.parse(new FileReader(pathstr));
				JSONObject jsonObject = (JSONObject) obj;
				System.out.println("Json : " + jsonObject);
				DBObject object = (DBObject) JSON.parse(jsonObject.toString());
				collstr.insert(object);
				counter++;
				cntx++;
			}
		}
	}

	public void ConnectandInsertORSResDataInMongoDB(String arg1, Integer arg2, String arg3, String arg4)
			throws FileNotFoundException, IOException, ParseException {
		CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(arg1, arg2);
		DB db = mongoclient.getDB(arg3);
		System.out.println("Mondb connected");
		DBCollection collstr = db.getCollection(arg4);
		String var1 = "/RDPhotoPublishEvent/ReferenceResponse";
		String var3 = ".json";
		int cntx = 1;
		counter = 0;
		while (counter < 2) {
			int var2 = cntx;
			String pathstr = var0 + var1 + var2 + var3;
			System.out.println("pathstr :" + pathstr);
			JSONParser parser = new JSONParser();
			Object obj = parser.parse(new FileReader(pathstr));
			JSONObject jsonObject = (JSONObject) obj;
			System.out.println("Json : " + jsonObject);
			DBObject object = (DBObject) JSON.parse(jsonObject.toString());
			collstr.insert(object);
			counter++;
			cntx++;
		}
	}

	public void ConnectandInsertORSResDataInMongoDBForLAFlow(String arg1, Integer arg2, String arg3, String arg4)
			throws FileNotFoundException, IOException, ParseException {
		CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(arg1, arg2);
		DB db = mongoclient.getDB(arg3);
		System.out.println("Mondb connected");
		DBCollection collstr = db.getCollection(arg4);
		String var1 = "/RDLegacyAdapterMappings/ReferenceResponse";
		String var3 = ".json";
		int cntx = 1;
		counter = 0;
		while (counter < 2) {
			int var2 = cntx;
			String pathstr = var0 + var1 + var2 + var3;
			System.out.println("pathstr :" + pathstr);
			JSONParser parser = new JSONParser();
			Object obj = parser.parse(new FileReader(pathstr));
			JSONObject jsonObject = (JSONObject) obj;
			System.out.println("Json : " + jsonObject);
			DBObject object = (DBObject) JSON.parse(jsonObject.toString());
			collstr.insert(object);
			counter++;
			cntx++;
		}
	}

	public void connectandInsertORSCommonresDataInMongoDB(String arg1, Integer arg2, String arg3, String arg4) {
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(arg1, arg2)) {
			DB db = mongoclient.getDB(arg3);
			System.out.println("Mondb connected");
			DBCollection collstr = db.getCollection(arg4);
			String Var1 = "/commonerrorcodes/CommonResponse";
			String Var3 = ".json";
			int cntl = 1;
			while (counter1 < 5) {
				int Var2 = cntl;
				String pathstr = var0 + Var1 + Var2 + Var3;
				System.out.println("pathstr :" + pathstr);
				JSONParser parser = new JSONParser();
				Object obj = parser.parse(new FileReader(pathstr));
				JSONObject jsonObject = (JSONObject) obj;
				System.out.println("Json : " + jsonObject);
				DBObject object = (DBObject) JSON.parse(jsonObject.toString());
				collstr.insert(object);
				counter1++;
				cntl++;
			}
		} catch (IOException | ParseException e) {
			e.printStackTrace();
		}
	}

	public void TakeORSMockDataFromMongoDB(String hostname, Integer portnum, String dbname, String collectionname) {
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostname, portnum)) {
			DB db = mongoclient.getDB(dbname);
			DBCollection coll = db.getCollection(collectionname);
			DBCursor cursor = coll.find();
			int i = 0;
			while (cursor.hasNext()) {

				DBObject result = cursor.next();
				str = new String(String.valueOf(result));
				Integer length = str.length();
				String subpostbody = str.substring(removehead, length);
				postbody = "{" + subpostbody;
				inputjson[i] = postbody;
				i++;
				totalindex = i;
			}
		}
	}

	public void PostORSMockDataIntoWiremock(String orsCallbackurl, String mockpath) {

		while (count < totalindex) {
			postbody = inputjson[count];
			RestAssured.baseURI = orsCallbackurl;
			System.out.println("path is:" + orsCallbackurl);
			RestAssured.basePath = "";
			Response response = given().contentType(ContentType.TEXT).log().all().body(postbody).post(mockpath);
			response.prettyPrint();
			count++;
		}
	}

	public String acceptanceCriteria;

	@SuppressWarnings("deprecation")
	public String getInputRequestBodyUsingTransactionId(String hostName, Integer portNum, String dbName,
			String requestCollectionName, String transactionId) throws InterruptedException {
		acceptanceCriteria = transactionId;
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostName, portNum);) {
			DB db = mongoclient.getDB(dbName);
			DBCollection coll = db.getCollection(requestCollectionName);
			DBObject query = new BasicDBObject("eventHeader.transactionId", new BasicDBObject("$eq", transactionId));
			DBObject result = coll.findOne(query);
			String str = String.valueOf(result);
			Integer length = str.length();
			String subpostbody = str.substring(removehead, length);
			String postbodyRaw = curlybraces + subpostbody;
			expectedTransactionID = CommonModules.randomUUID();
			postBody = postbodyRaw.replaceAll(transactionId, expectedTransactionID);

			String photoUuid = getPhotoUuidInRequest();
			String bookingUuid = getBookingUuidInRequest();
			String correlationid = getCorrelationIdInRequest();
			String eventdatetime = geteventDateTimeInRequest();
			String transactionid = getTransactionIdInRequest();
			String compositeCandidateNumber = getCompositeCandidateNumber();

			String newcorrelationid = CommonModules.randomUUID();
			expectedTransactionID = CommonModules.randomUUID();
			// String newbookingUuid = CommonModules.randomUUID();
			String newphotoUuid = CommonModules.randomUUID();

			LocalDateTime currenttimestamp = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			String neweventdatetime = currenttimestamp.format(formatter).toString();

//		ArrayList<String> bookinglineUuidList = getExpectedBookingLineUuid();
//		ArrayList<String> resultlineUuidList = getExpectedResultLineUuid();

			postBody = postBody.replaceAll(correlationid, newcorrelationid);
			postBody = postBody.replaceAll(transactionid, expectedTransactionID);
			postBody = postBody.replaceAll(eventdatetime, neweventdatetime);
			postbody = postBody.replaceAll(compositeCandidateNumber,
					SI_RD_BookingCreatedConsumptionForSelectionSetup.expectedtestTaker_compositeCandidateNumber);
			postBody = postBody.replaceAll(bookingUuid,
					SI_RD_BookingCreatedConsumptionForSelectionSetup.expectedbookingUuid);
			postBody = postBody.replaceAll(photoUuid, newphotoUuid);

//		for(int i=0;i<bookinglineUuidList.size();i++) {
//			String bookinglineUuid = bookinglineUuidList.get(i).toString();
//			postBody = postBody.replaceAll(bookinglineUuid, StepImplementationRDSBookingConsumeEvent.expectedBookingLineUuidList.get(i));
//		}
//
//		for(int i=0;i<resultlineUuidList.size();i++) {
//			String resultlineUuid = resultlineUuidList.get(i).toString();
//			String newResultLineUuid = CommonModules.randomUUID();
//			postBody = postBody.replaceAll(resultlineUuid, newResultLineUuid);	
//		}
		} catch (Exception e) {
			System.out.println("Error");
		}
		return postbody;
	}

	public void insertRecordInMongoDB(String hostName, Integer portNum, String dbName, String requestCollectionName)
			throws ParseException {
		verifyFieldValueInRequest("eventHeader_eventName");
		eventName = valueInJsonFile;
		postBody = postBody.replace(eventName, eventName + "_" + acceptanceCriteria);

		try (CMDSMongoClientAdapter mongoclient1 = new CMDSMongoClientAdapter(hostName, portNum)) {
			DB db1 = mongoclient1.getDB(dbName);
			DBCollection collstr = db1.getCollection(requestCollectionName);
			DBObject object = (DBObject) JSON.parse(postBody.toString());
			collstr.insert(object);
		} catch (Exception e) {
			System.out.println("Error");
		}
	}

	public String getPhotoUuidInRequest() throws ParseException {
		verifyFieldValueInRequest("eventBody_photoUuid");
		return valueInJsonFile;
	}

	public String getBookingUuidInRequest() throws ParseException {
		verifyFieldValueInRequest("eventBody_bookingUuid");
		return valueInJsonFile;
	}

	public String getCorrelationIdInRequest() throws ParseException {
		verifyFieldValueInRequest("eventHeader_correlationId");
		return valueInJsonFile;
	}

	public String getTransactionIdInRequest() throws ParseException {
		verifyFieldValueInRequest("eventHeader_transactionId");
		return valueInJsonFile;
	}

	public String getEventNameInRequest() throws ParseException {
		verifyFieldValueInRequest("eventHeader_eventName");
		return valueInJsonFile;
	}

	public String geteventDateTimeInRequest() throws ParseException {
		verifyFieldValueInRequest("eventHeader_eventDateTime");
		return valueInJsonFile;
	}

	public String getCompositeCandidateNumber() throws ParseException {
		verifyFieldValueInRequest("eventBody_compositeCandidateNumber");
		return valueInJsonFile;
	}

	public void getJsonFeildValuesfromRequestbody() throws ParseException {

		verifyFieldValueInRequest(requestFields.get(0));
		expected_photoUuid = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(1));
		expected_bookingUuid = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(2));
		expected_compositeCandidateNumber = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(3));
		expected_photoTypeUuid = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(4));
		expected_photoPath = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(5));
		expected_photoVersion = valueInJsonFile;

	}

	public static Boolean verifyFieldValueInRequest(String fieldValue) throws ParseException {
		JSONParser parser = new JSONParser();
		JSONObject json = (JSONObject) parser.parse(postBody);
		try {
			ArrayList<String> json1 = new ArrayList<>();
			if (fieldValue.contains("_")) {
				String[] values = fieldValue.split("_");
				for (int i = 0; i < values.length; i++) {
					json1.add(values[i]);
				}
				for (int i = 0; i < values.length - 1; i++) {
					String counter = json1.get(i);
					valueInJsonFile = json.get(counter).toString();
					// valueInJsonFile = valueInJsonFile.replace("[{", "{").replace("}]", "}");
					json = (JSONObject) parser.parse(valueInJsonFile);
				}
				try {
					String counter = json1.get(json1.size() - 1);
					valueInJsonFile = (String) json.get(counter);
				} catch (ClassCastException e) {
					String counter = json1.get(json1.size() - 1);
					valueInJsonFile = String.valueOf(json.get(counter));
				}

			} else {
				valueInJsonFile = json.get(fieldValue).toString();
			}
			if (valueInJsonFile == null || valueInJsonFile.equalsIgnoreCase("")) {
				Serenity.recordReportData().asEvidence().withTitle("Field or Field value is not provided : ")
						.andContents(fieldValue);
				validationFail1 = false;

			} else {
				validationFail1 = true;
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return validationFail1;
	}

	public static String retriveValueFromResponseJson(String fieldValue) throws ParseException {
		JSONParser parser = new JSONParser();
		JSONObject valueInJsonFile1;
		String valueInJsonFile2 = null;
		JSONObject json = (JSONObject) parser.parse(responseFromPOSTCall);
		if (fieldValue.contains("_")) {
			String[] values = fieldValue.split("_");
			try {
				JSONArray array = (JSONArray) json.get(values[0]);
				String valuesUpdate = array.toString().replace("[", "").replace("]", "");
				JSONObject filedList = (JSONObject) parser.parse(valuesUpdate);
				valueInJsonFile2 = filedList.get(values[1]).toString();
				if (values.length > 2) {
					valueInJsonFile1 = (JSONObject) parser.parse(valueInJsonFile2);
					valueInJsonFile2 = valueInJsonFile1.get(values[2]).toString();
				}
			} catch (ClassCastException e) {
				// JSONObject object = (JSONObject) json.get(values[0]);
				String eventBody = (String) json.get(values[0]);
				JSONObject object = (JSONObject) parser.parse(eventBody);
				valueInJsonFile2 = object.get(values[1]).toString();
				if (values.length > 2) {
					valueInJsonFile1 = (JSONObject) parser.parse(valueInJsonFile2);
					valueInJsonFile2 = valueInJsonFile1.get(values[2]).toString();
					if (values.length > 3) {
						if (valueInJsonFile2.startsWith("[")) {
							String temp = (String) valueInJsonFile1.get(values[2]).toString();
							JSONArray array2 = new JSONArray(temp);
							String valuesUpdate = array2.toString().replace("[", "").replace("]", "");
							JSONObject filedList = (JSONObject) parser.parse(valuesUpdate);
							valueInJsonFile2 = filedList.get(values[3]).toString();
						} else {
							valueInJsonFile1 = (JSONObject) parser.parse(valueInJsonFile2);
							valueInJsonFile2 = valueInJsonFile1.get(values[3]).toString();
						}
						if (values.length > 4) {
							if (valueInJsonFile2.startsWith("[")) {
								String temp1 = (String) valueInJsonFile1.get(values[3]).toString();
								JSONArray array3 = new JSONArray(temp1);
								String valuesUpdate2 = array3.toString().replace("[", "").replace("]", "");
								JSONObject filedList2 = (JSONObject) parser.parse(valuesUpdate2);
								valueInJsonFile2 = filedList2.get(values[4]).toString();
							} else {
								valueInJsonFile1 = (JSONObject) parser.parse(valueInJsonFile2);
								valueInJsonFile2 = valueInJsonFile1.get(values[4]).toString();
							}

						}
					}
				}
			}
		} else {
			valueInJsonFile2 = (String) json.get(fieldValue);
		}

		return valueInJsonFile2;
	}

	public void validatePublishedMessage() throws org.json.simple.parser.ParseException {

		JSONParser jsonParser = new JSONParser();
		System.out.println("Response" + responseFromPOSTCall);
		JSONObject jsonObject = (JSONObject) jsonParser.parse(responseFromPOSTCall);
		String eventBody = (String) jsonObject.get("eventBody");
		JSONObject EventBody = (JSONObject) jsonParser.parse(eventBody);
		System.out.println("Event Body = " + EventBody);
		assert EventBody != null;
		actualPhotoUuid = retriveValueFromResponseJson("eventBody_photoUuid");
		Assert.assertEquals(expected_photoUuid, actualPhotoUuid);

		actualBookingUuid = retriveValueFromResponseJson("eventBody_bookingUuid");
		Assert.assertEquals(expected_bookingUuid, actualBookingUuid);

		actualPhotoTypeUuid = retriveValueFromResponseJson("eventBody_photoTypeUuid");
		Assert.assertEquals(expected_photoTypeUuid, actualPhotoTypeUuid);

		actualPhotoPath = retriveValueFromResponseJson("eventBody_filePath");
		Assert.assertEquals(expected_photoPath, actualPhotoPath);

		actualPhotoVersion = retriveValueFromResponseJson("eventBody_photoVersion");
		Assert.assertEquals(expected_photoVersion, actualPhotoVersion);

	}

	/************************************************************************
	 * Function Name: postRequest Function Description: To post request body with
	 * headers to API endpoint
	 *************************************************************************/
	public Response postRequest(String actUrl, String actPath, String destination, String envKey, String accessToken) {
		RestAssured.baseURI = actUrl;
		response = SerenityRest.given()
				.headers("envKey", envKey, "destination", destination, "Authorization", "Bearer " + accessToken)
				.contentType(ContentType.JSON).log().all().body(postBody).post(actPath);
		return response;
	}

	/************************************************************************
	 * Function Name: verifyResponse Function Description: To validate the response
	 * code
	 *************************************************************************/
	public void verifyResponse() {

		actResponseCode = response.getStatusCode();
		actResponse = response.asString();

		if (actResponseCode == resPONSECODE202) {
			assertEquals(actResponseCode, resPONSECODE202);
			System.out.println("ResponseCode: " + actResponseCode);
			System.out.println("Response: " + actResponse);
			Serenity.recordReportData().withTitle("Response").andContents(actResponse);
		} else {
			assertEquals(actResponseCode, resPONSECODE400);
		}
	}

	public String ActUrl = "";

	public String TakeActUrl(String Env) {

		System.out.println(Env);
		switch (Env) {
		case "sandbox":
			ActUrl = CommonModules.getEnvironmentConfigurations("int338.SandboxActurl");
			break;
		case "sandbox2":
			ActUrl = CommonModules.getEnvironmentConfigurations("int338.Sandbox2Acturl");
			break;
		case "dev":
			ActUrl = CommonModules.getEnvironmentConfigurations("int338.DevActurl");
			break;
		}
		return ActUrl;
	}

	public String EnvKeyQueue = "";

	public String TakeEnvKeyQueue(String Env) {

		System.out.println(Env);
		switch (Env) {
		case "sandbox":
			EnvKeyQueue = CommonModules.getEnvironmentConfigurations("int189.SandboxenvKeyQueue");
			break;
		case "sandbox2":
			EnvKeyQueue = CommonModules.getEnvironmentConfigurations("int189.Sandbox2envKeyQueue");
			break;
		case "dev":
			EnvKeyQueue = CommonModules.getEnvironmentConfigurations("int189.DevenvKeyQueue");
			break;
		}
		return EnvKeyQueue;
	}

	public static String authUrlForBooking = "";

	public static String takeAuthUrlForBooking(String partner) {
		String env = System.getenv("ENVIRONMENT");
		switch (env) {

		case "sandbox":
			if (partner.equalsIgnoreCase("IDP")) {
				authUrlForBooking = CommonModules.getEnvironmentConfigurations("Sandbox_IDP.AuthURL");
			} else if (partner.equalsIgnoreCase("BC")) {
				authUrlForBooking = CommonModules.getEnvironmentConfigurations("Sandbox_BC.AuthURL");
			}
			break;
		case "dev":
			if (partner.equalsIgnoreCase("IDP")) {
				authUrlForBooking = CommonModules.getEnvironmentConfigurations("Dev_IDP.AuthURL");
			} else if (partner.equalsIgnoreCase("BC")) {
				authUrlForBooking = CommonModules.getEnvironmentConfigurations("Dev_BC.AuthURL");
			}
			break;
		case "sit":
			if (partner.equalsIgnoreCase("IDP")) {
				authUrlForBooking = CommonModules.getEnvironmentConfigurations("sit_IDP.AuthURL");
			} else if (partner.equalsIgnoreCase("BC")) {
				authUrlForBooking = CommonModules.getEnvironmentConfigurations("sit_BC.AuthURL");
			}
			break;
		}
		return authUrlForBooking;
	}

	public static String authReqForBooking = "";

	public static String takeAuthReqForBooking(String partner) {
		String env = System.getenv("ENVIRONMENT");
		switch (env) {
		case "sandbox":
			if (partner.equalsIgnoreCase("IDP")) {
				authReqForBooking = CommonModules.getEnvironmentConfigurations("Sandbox_IDP.AuthReq");
			} else if (partner.equalsIgnoreCase("BC")) {
				authReqForBooking = CommonModules.getEnvironmentConfigurations("Sandbox_BC.AuthReq");
			}
			break;
		case "dev":
			if (partner.equalsIgnoreCase("IDP")) {
				authReqForBooking = CommonModules.getEnvironmentConfigurations("Dev_IDP.AuthReq");
			} else if (partner.equalsIgnoreCase("BC")) {
				authReqForBooking = CommonModules.getEnvironmentConfigurations("Dev_BC.AuthReq");
			}
			break;
		case "sit":
			if (partner.equalsIgnoreCase("IDP")) {
				authReqForBooking = CommonModules.getEnvironmentConfigurations("sit_IDP.AuthReq");
			} else if (partner.equalsIgnoreCase("BC")) {
				authReqForBooking = CommonModules.getEnvironmentConfigurations("sit_BC.AuthReq");
			}
			break;
		}
		return authReqForBooking;
	}

	public String DbUrl = "";

	public String TakeDbUrl(String Env) {

		System.out.println(Env);
		switch (Env) {
		case "sandbox":
			ActUrl = CommonModules.getEnvironmentConfigurations("cmds268.dbUrlSandbox");
			break;
		case "sandbox2":
			ActUrl = CommonModules.getEnvironmentConfigurations("cmds268.dbUrlSandbox");
			break;
		case "dev":
			ActUrl = CommonModules.getEnvironmentConfigurations("cmds268.dbUrlDev");
			break;
		}
		return ActUrl;
	}

}
