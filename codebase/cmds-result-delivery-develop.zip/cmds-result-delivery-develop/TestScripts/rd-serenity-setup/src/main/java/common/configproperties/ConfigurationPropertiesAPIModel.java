package common.configproperties;

import common.PropertyFileLoader;
import lombok.Getter;

@Getter
public class ConfigurationPropertiesAPIModel {
	
	private String hostname;
	private int portnum;
	private String wiremockBaseURL;
	private String basePath;
	private String asyncCollection;
	private String asyncDB;
	
	public void setHostname() {
		this.hostname = PropertyFileLoader.getEnvironmentConfigurations("common.hostname");
	}
	
	public void setPortnum() {
		this.portnum = Integer.parseInt(PropertyFileLoader.getEnvironmentConfigurations("common.portnum"));
	}
	
	public void setWiremockBaseURL() {
		this.wiremockBaseURL = PropertyFileLoader.getEnvironmentConfigurations("RI.Common.WiremockBaseURL");
	}
	
	public void setBasePath() {
		this.basePath = PropertyFileLoader.getEnvironmentConfigurations("common.path");
	}
	
	public void setAsyncCollection() {
		this.asyncCollection = PropertyFileLoader.getEnvironmentConfigurations("cmds.ri.asyncCollection");
	}
	
	public void setAsyncDB() {
		this.asyncDB = PropertyFileLoader.getEnvironmentConfigurations("cmds.ri.asyncDb");
	}

}
