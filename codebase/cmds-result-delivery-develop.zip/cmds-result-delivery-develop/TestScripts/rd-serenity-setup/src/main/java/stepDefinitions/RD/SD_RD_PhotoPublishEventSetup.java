package stepDefinitions.RD;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.json.simple.parser.ParseException;

import common.CommonModules;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import stepImplementations.RD.SI_RD_BookingCreatedEventSetup;
import stepImplementations.RD.SI_RD_PhotoPublishEventSetup;
import stepImplementations.RD.SI_RD_ResultReleasedEventSetup;

public class SD_RD_PhotoPublishEventSetup extends CommonModules {

	static CommonModules common = new CommonModules();
	String env = System.getenv("ENVIRONMENT");
	public String swaggerVersion = System.getenv("SWAGGER_VERSION");
	public static String AuthURL = "";
	static String AuthReq = "";
	public static String mxName = "";
	public static String DBUrl = "";
	public static String dbUrl = "";

	public static String enviroment = "";
	static String authURL = "";
	static String authReq = "";
	static String accessToken = "";
	static String destinationQueue = "";
	static String envkeyQueue = "";
	static String destinationTopic = "";
	static String envkeyTopic = "";
	public static String ors338dbname = "";
	public static String ors338reqcollection = "";
	public static String ors338servercollection = "";
	public static String ors338baseurl = "";
	public static String basepath = "";
	public static String ors189dbname = "";
	public static String ors189reqcollection = "";
	public static String ors189servercollection = "";
	public static String ors189baseurl = "";
	public static String ors081dbname = "";
	public static String ors081reqcollection = "";
	public static String ors081servercollection = "";
	public static String ors081baseurl = "";
	public static String RD_AsyncDB;
	public static String RD_AsyncCollection;
	protected static String int338Acturl = "";
	protected static String int338Actpath = "";

	boolean dummy = false;
	static SI_RD_PhotoPublishEventSetup stepImp = new SI_RD_PhotoPublishEventSetup();
	static SI_RD_ResultReleasedEventSetup result = new SI_RD_ResultReleasedEventSetup();
	static SI_RD_BookingCreatedEventSetup booking = new SI_RD_BookingCreatedEventSetup();

	@Given("^Clean the Mongo database for new data setup for photo publish Event$")
	public void clean_the_Mongo_database_for_new_data_setup_for_photo_publish_Event() throws IOException {
		common.getEnvironmentConfigurationsOpen();
		common.getEnvironmentConfigurationsOpen();
		hostname = common.getEnvironmentConfigurations("common.hostname");
		portnum = Integer.parseInt(common.getEnvironmentConfigurations("common.portnum"));

		errordb = common.getEnvironmentConfigurations("common.errordb");
		errorcollection = common.getEnvironmentConfigurations("common.errorcollection");
		RD_AsyncCollection = common.getEnvironmentConfigurations("common.RD.AsyncCollection");
		RD_AsyncDB = common.getEnvironmentConfigurations("common.RD.AsyncDBname");

		ors338dbname = common.getEnvironmentConfigurations("int338.dbname");
		ors338reqcollection = common.getEnvironmentConfigurations("int338.reqcollection");
		ors338servercollection = common.getEnvironmentConfigurations("int338.servercollection");
		ors338baseurl = common.getEnvironmentConfigurations("int338.baseurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		stepImp.cleanDatebaseModule(hostname, portnum, ors338dbname, ors338reqcollection);
		stepImp.cleanDatebaseModule(hostname, portnum, errordb, errorcollection);
		stepImp.cleanDatebaseModule(hostname, portnum, ors338dbname, ors338servercollection);

		ors189dbname = common.getEnvironmentConfigurations("int189.dbname");
		ors189reqcollection = common.getEnvironmentConfigurations("int189.reqcollection");
		ors189servercollection = common.getEnvironmentConfigurations("int189.servercollection");
		ors189baseurl = common.getEnvironmentConfigurations("int189.baseurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		booking.cleanDatebaseModule(hostname, portnum, ors189dbname, ors189reqcollection);
		booking.cleanDatebaseModule(hostname, portnum, ors189dbname, ors189servercollection);

		ors081dbname = common.getEnvironmentConfigurations("int081.dbname");
		ors081reqcollection = common.getEnvironmentConfigurations("int081.reqcollection");
		ors081servercollection = common.getEnvironmentConfigurations("int081.servercollection");
		ors081baseurl = common.getEnvironmentConfigurations("int081.baseurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		result.cleanDatebaseModule(hostname, portnum, ors081dbname, ors081reqcollection);
		result.cleanDatebaseModule(hostname, portnum, ors081dbname, ors081servercollection);
		common.cleanAsyncDBCollection(hostname, portnum, RD_AsyncDB, RD_AsyncCollection);

	}

	@Then("^Insert the request and responses to mongodb for photo publish Event$")
	public void insert_the_request_and_responses_to_mongodb_for_photo_publish_Event()
			throws IOException, ParseException {
		if (swaggerVersion.equalsIgnoreCase("v1")) {
			stepImp.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors338dbname, ors338reqcollection);
			result.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors081dbname, ors081reqcollection);
			booking.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors189dbname, ors189reqcollection);
		} else if (swaggerVersion.equalsIgnoreCase("v2")) {
			stepImp.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors338dbname, ors338reqcollection);
			result.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors081dbname, ors081reqcollection);
			booking.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors189dbname, ors189reqcollection);
		}

		stepImp.connectandInsertORSCommonresDataInMongoDB(hostname, portnum, errordb, errorcollection);
		result.connectandInsertORSCommonresDataInMongoDB(hostname, portnum, errordb, errorcollection);
		booking.connectandInsertORSCommonresDataInMongoDB(hostname, portnum, errordb, errorcollection);
		stepImp.connectandInsertDBdataReqDataInMongoDB(hostname, portnum, ors189dbname, ors189reqcollection);
		stepImp.connectandInsertDBdataReqDataInMongoDB(hostname, portnum, ors338dbname, ors338reqcollection);
		stepImp.connectandInsertDBdataReqDataInMongoDB(hostname, portnum, ors081dbname, ors081reqcollection);
	}

	@Then("^Setup the Server responses in Mock server for photo publish Event$")
	public void setup_the_Server_responses_in_Mock_server_for_photo_publish_Event()
			throws FileNotFoundException, IOException, ParseException {
		stepImp.ConnectandInsertORSResDataInMongoDB(hostname, portnum, ors338dbname, ors338servercollection);
		stepImp.TakeORSMockDataFromMongoDB(hostname, portnum, ors338dbname, ors338servercollection);
		stepImp.PostORSMockDataIntoWiremock(ors338baseurl, basepath);
	}

	@Then("^Setup the Server responses in the Mock server for the Legacy Adapter Flow$")
	public void setup_the_Server_responses_in_the_Mock_server_for_the_Legacy_Adapter_Flow()
			throws FileNotFoundException, IOException, ParseException {
		stepImp.ConnectandInsertORSResDataInMongoDBForLAFlow(hostname, portnum, ors338dbname, ors338servercollection);
		stepImp.TakeORSMockDataFromMongoDB(hostname, portnum, ors338dbname, ors338servercollection);
		stepImp.PostORSMockDataIntoWiremock(ors338baseurl, basepath);
	}

	@Then("^Test data setup completed sucessfully for photo publish Event$")
	public void test_data_setup_completed_sucessfully_for_photo_publish_Event() {
		System.out.println("Test data set up is completed successfully");
	}

	@Given("^MongoDB configuration set up has been done for the Photo Publish event \"([^\"]*)\"$")
	public void mongodb_configuration_set_up_has_been_done_for_the_Photo_Publish_event(String partner)
			throws IOException {
		common.getEnvironmentConfigurationsOpen();
		hostname = common.getEnvironmentConfigurations("common.hostname");
		portnum = Integer.parseInt(common.getEnvironmentConfigurations("common.portnum"));

		errordb = common.getEnvironmentConfigurations("common.errorDB");
		errorcollection = common.getEnvironmentConfigurations("common.errorcollection");

		ors338dbname = common.getEnvironmentConfigurations("int338.dbname");
		ors338reqcollection = common.getEnvironmentConfigurations("int338.reqcollection");

		// int338Acturl = common.getEnvironmentConfigurations("int338.Acturl");
		int338Acturl = stepImp.TakeActUrl(env);
		int338Actpath = common.getEnvironmentConfigurations("int338.ppevent.path");

		destinationQueue = common.getEnvironmentConfigurations("int338.DestinationQueue");
		// envkeyQueue = common.getEnvironmentConfigurations("int338.envKeyQueue");
		envkeyQueue = stepImp.TakeEnvKeyQueue(env);
		AuthURL = stepImp.takeAuthUrlForBooking(partner);
		AuthReq = stepImp.takeAuthReqForBooking(partner);
		mxName = "RD";
		enviroment = env;
		DBUrl = stepImp.TakeDbUrl(env);
		dbUrl = DBUrl;
		accessToken = common.RetrieveToken(AuthURL, AuthReq);

	}

	@When("^Photo Publish event updates are made available to CMDS-RDS \"([^\"]*)\"$")
	public void photo_Publish_event_updates_are_made_available_to_CMDS_RDS(String transactionId)
			throws InterruptedException {
		stepImp.getInputRequestBodyUsingTransactionId(hostname, portnum, ors338dbname, ors338reqcollection,
				transactionId);
	}

	@Then("^Post the Photo Publish event to rds-in-queue$")
	public void post_the_Photo_Publish_event_to_rds_in_queue() throws ParseException {
		stepImp.postRequest(int338Acturl, int338Actpath, destinationQueue, envkeyQueue, accessToken);
		stepImp.insertRecordInMongoDB(hostname, portnum, ors338dbname, ors338reqcollection);
		stepImp.verifyResponse();
		stepImp.getJsonFeildValuesfromRequestbody();
	}

	@Then("^Post the Photo Publish event to rds-in-queue for Booking Change Analysis$")
	public void post_the_Photo_Publish_event_to_rds_in_queue_for_Booking_Change_Analysis() {
		stepImp.postRequest(int338Acturl, int338Actpath, destinationQueue, envkeyQueue, accessToken);
		stepImp.verifyResponse();
	}

	@Then("^CMDS-RDS will upsert the TT photo details in RDS and publish PhotoPublishedConsumedEvent$")
	public void cmds_RDS_will_upsert_the_TT_photo_details_in_RDS_and_publish_PhotoPublishedConsumedEvent()
			throws InterruptedException, ParseException {
		stepImp.connectMongoDB(hostname, portnum);
		stepImp.validatePublishedMessage();
	}

}
