package common;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

import static common.constants.UtilityConstants.PROPERTY_FILE_PATH_ENV_VARIABLE_NAME;

import lombok.experimental.UtilityClass;

@UtilityClass
public class PropertyFileLoader {
	
	static Properties prop = new Properties();
	
	public static void getEnvironmentConfigurationsOpen() throws  IOException,FileNotFoundException   {
		String sysEnvStr = System.getenv(PROPERTY_FILE_PATH_ENV_VARIABLE_NAME);
		System.out.println("PROPERTY_FILE_PATH : " + sysEnvStr);
		
		InputStream input = new FileInputStream(sysEnvStr);
		InputStreamReader inputStreamReader = new InputStreamReader(input);
		prop.load(inputStreamReader);
	}
	
	public static String getEnvironmentConfigurations(String variableName) {
		String variable = prop.getProperty(variableName);
		System.out.println(variableName + " = " + variable);
		return variable;
	}

}
