package common.constants;

public class TestDataFolderNameConstants {
	
	private TestDataFolderNameConstants() {

	}

	public static final String RILocationChangedTestData = "RILocationChangedTestData";
	public static final String RIBookingChangedTestData = "RIBookingChangedTestData";
	public static final String RIUtilityTestData = "RIUtilityTestData";
	public static final String RIMappingTestData = "RIMappingTestData";

}
