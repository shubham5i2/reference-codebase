package stepDefinitions.RD;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.json.simple.parser.ParseException;

import common.CommonModules;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import stepImplementations.RD.SI_RD_EorOutcomeLetterGenerationSetup;

public class SD_RD_EorOutcomeLetterGenerationSetup extends CommonModules {

	public static String eorOutcomedbname = "";
	public static String eorOutcomereqcollection = "";
	public static String eorOutcomeservercollection = "";
	public static String eorOutcomebaseurl = "";
	public static String eorOutcomebasepath = "";
	static CommonModules common = new CommonModules();
	public String swaggerVersion = System.getenv("SWAGGER_VERSION");
	public static String RD_AsyncDB;
	public static String RD_AsyncCollection;

	static SI_RD_EorOutcomeLetterGenerationSetup stepImp = new SI_RD_EorOutcomeLetterGenerationSetup();

	@Given("^Clean the Mongo database for new data setup for EOR outcome letter generation$")
	public void clean_the_Mongo_database_for_new_data_setup_for_EOR_outcome_letter_generation() throws IOException {
		common.getEnvironmentConfigurationsOpen();
		hostname = common.getEnvironmentConfigurations("common.hostname");
		portnum = Integer.parseInt(common.getEnvironmentConfigurations("common.portnum"));

		errordb = common.getEnvironmentConfigurations("common.errordb");
		errorcollection = common.getEnvironmentConfigurations("common.errorcollection");

		RD_AsyncCollection = common.getEnvironmentConfigurations("common.RD.AsyncCollection");
		RD_AsyncDB = common.getEnvironmentConfigurations("common.RD.AsyncDBname");

		eorOutcomedbname = common.getEnvironmentConfigurations("EorOutcomeLetterGeneration.dbname");
		eorOutcomereqcollection = common.getEnvironmentConfigurations("EorOutcomeLetterGeneration.reqcollection");
		eorOutcomeservercollection = common.getEnvironmentConfigurations("EorOutcomeLetterGeneration.servercollection");
		eorOutcomebaseurl = common.getEnvironmentConfigurations("EorOutcomeLetterGeneration.baseurl");
		eorOutcomebasepath = common.getEnvironmentConfigurations("common.path");

		stepImp.cleanDatebaseModule(hostname, portnum, eorOutcomedbname, eorOutcomereqcollection);
		stepImp.cleanDatebaseModule(hostname, portnum, errordb, errorcollection);
		stepImp.cleanDatebaseModule(hostname, portnum, eorOutcomedbname, eorOutcomeservercollection);
		common.cleanAsyncDBCollection(hostname, portnum, RD_AsyncDB, RD_AsyncCollection);
	}

	@Then("^Insert the request and responses to mongodb for EOR outcome letter generation$")
	public void insert_the_request_and_responses_to_mongodb_for_EOR_outcome_letter_generation()
			throws IOException, ParseException {
		if (swaggerVersion.equalsIgnoreCase("v1")) {
		} else if (swaggerVersion.equalsIgnoreCase("v2")) {
			stepImp.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, eorOutcomedbname, eorOutcomereqcollection);
		}
		stepImp.connectandInsertORSCommonresDataInMongoDB(hostname, portnum, errordb, errorcollection);
		stepImp.connectandInsertDBdataReqDataInMongoDB(hostname, portnum, eorOutcomedbname, eorOutcomereqcollection);
	
	}

	@Then("^Setup the Server responses in Mock server for EOR outcome letter generation Flow$")
	public void setup_the_Server_responses_in_Mock_server_for_EOR_outcome_letter_generation()
			throws FileNotFoundException, IOException, ParseException {
		stepImp.ConnectandInsertORSResDataInMongoDB(hostname, portnum, eorOutcomedbname, eorOutcomeservercollection);
		stepImp.ConnectandInsertORSResDataInMongoDBForTRFFlow(hostname, portnum, eorOutcomedbname, eorOutcomeservercollection);
		stepImp.TakeORSMockDataFromMongoDB(hostname, portnum, eorOutcomedbname, eorOutcomeservercollection);
		stepImp.PostORSMockDataIntoWiremock(eorOutcomebaseurl, eorOutcomebasepath);
	}

	@Then("^Test data setup completed sucessfully for EOR outcome letter generation Flow$")
	public void test_data_setup_completed_sucessfully_for_EOR_outcome_letter_generation() {
		System.out.println("Test data set up is completed successfully");
	}

}
