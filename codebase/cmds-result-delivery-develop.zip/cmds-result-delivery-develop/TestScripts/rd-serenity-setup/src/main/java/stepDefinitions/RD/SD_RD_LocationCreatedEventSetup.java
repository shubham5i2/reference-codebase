package stepDefinitions.RD;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.json.simple.parser.ParseException;

import common.CommonModules;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import stepImplementations.RD.SI_RD_LocationCreatedEventSetup;

public class SD_RD_LocationCreatedEventSetup extends CommonModules {

	static CommonModules common = new CommonModules();
	public String swaggerVersion = System.getenv("SWAGGER_VERSION");
	static SI_RD_LocationCreatedEventSetup setupImple = new SI_RD_LocationCreatedEventSetup();

	public static String ors68dbname = "";
	public static String ors68reqcollection = "";
	public static String ors68servercollection = "";
	public static String ors68baseurl = "";
	public static String basepath = "";

	public static String RD_AsyncDB;
	public static String RD_AsyncCollection;

	@Given("^Clean the Mongo database for new data setup for Result Delivery Mx$")
	public static void CleantheMondodbdatabasefornewdatasetup() throws IOException {
		common.getEnvironmentConfigurationsOpen();
		hostname = common.getEnvironmentConfigurations("common.hostname");
		portnum = Integer.parseInt(common.getEnvironmentConfigurations("common.portnum"));

		errordb = common.getEnvironmentConfigurations("common.errordb");
		errorcollection = common.getEnvironmentConfigurations("common.errorcollection");

		RD_AsyncCollection = common.getEnvironmentConfigurations("common.RD.AsyncCollection");
		RD_AsyncDB = common.getEnvironmentConfigurations("common.RD.AsyncDBname");
		ors68dbname = common.getEnvironmentConfigurations("int68.dbname");
		ors68reqcollection = common.getEnvironmentConfigurations("int68.reqcollection");
		ors68servercollection = common.getEnvironmentConfigurations("int68.servercollection");
		ors68baseurl = common.getEnvironmentConfigurations("int68.baseurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		setupImple.cleanDatebaseModule(hostname, portnum, ors68dbname, ors68reqcollection);
		setupImple.cleanDatebaseModule(hostname, portnum, errordb, errorcollection);
		setupImple.cleanDatebaseModule(hostname, portnum, ors68dbname, ors68servercollection);
		common.cleanAsyncDBCollection(hostname, portnum, RD_AsyncDB, RD_AsyncCollection);
	}

	@When("^Insert the request and responses to mongodb for Result Delivery Mx$")
	public void insertRequestAndResponse() throws IOException, ParseException {
		if (swaggerVersion.equalsIgnoreCase("v1")) {
			setupImple.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors68dbname, ors68reqcollection);
		} else if (swaggerVersion.equalsIgnoreCase("v2")) {
			setupImple.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors68dbname, ors68reqcollection);
		}
		setupImple.connectandInsertORSCommonresDataInMongoDB(hostname, portnum, errordb, errorcollection);
		setupImple.connectandInsertDBdataReqDataInMongoDB(hostname, portnum, ors68dbname, ors68reqcollection);
	}

	@Then("^Setup the Server responses in Inspera Mock server for Result Delivery Mx$")
	public void InsertmockdataintoOrsMockCallbackServer() throws FileNotFoundException, IOException, ParseException {
		setupImple.ConnectandInsertORSResDataInMongoDB(hostname, portnum, ors68dbname, ors68servercollection);
		setupImple.TakeORSMockDataFromMongoDB(hostname, portnum, ors68dbname, ors68servercollection);
		setupImple.PostORSMockDataIntoWiremock(ors68baseurl, basepath);
	}

	@When("^Test data setup completed sucessfully for Result Delivery Mx$")
	public void referencedatasetupiscompletedsuccessfully() {
		System.out.println("Test data set up is completed successfully");
	}

}
