package stepImplementations.RD;

import static io.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.time.Clock;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.regex.Pattern;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.javafaker.Faker;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.json.*;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.json.simple.JSONObject;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import common.dbabstraction.CMDSMongoClientAdapter;

import common.CommonModules;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.junit.Assert;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.rest.SerenityRest;

public class SI_RD_ROCreatedConsumptionForSelectionSetup extends CommonModules {
	static String postbody = "";
	static Response response = null;
	public static String expectedTransactionID = "";
	public static String responseFromPOSTCall = null;
	String curlybraces = "{";
	int removeHead = 51;
	String strVal = "";
	int actResponseCode;
	String actResponse = "";
	int actualResponselen;
	int resPONSECODE202 = 202;
	int resPONSECODE400 = 400;
	int resPONSECODE401 = 401;
	int resPONSECODE403 = 403;
	int expectedTranLength202 = 56;
	int expectedTranLength400 = 35;
	public static String valueInJsonFile;
	String neweventdatetime = "";
	static JSONObject jsonInputBody;
	String inputDataForParsing = "";

	static String postBodyreq = "";
	public static String expectedrecognisingOrganisationUuid = "";
	public static String expectedorganisationName = "";
	public static String expectedorganisationId = "";
	public static String expectedorganisationTypeUuid = "";
	public static String expectedorganisationStatus = "";
	public static String expectedparentRecognisingOrganisationUuid = "";
	public static String expectedverificationStatus = "";
	public static String expectedmethodOfDelivery = "";
	public static String expectedorganisationCode = "";
	public static String expectedpartnerCode = "";
	static Boolean validationFail1 = true;
	public static String actualpartnerCode = "";
	public static String actualrecognisingOrganisationUuid = "";
	public static String actualorganisationTypeUuid = "";
	public static String actualorganisationId = "";
	public static String actualorganisationName = "";
	public static String actualverificationStatus = "";
	public static String actualmethodOfDelivery = "";
	public static String actualparentRecognisingOrganisationUuid = "";
	public static String actualorganisationStatus = "";
	public static String actualorganisationCode = "";
	public static String actualEventName = "";
	public static String neworganisationId = "";
	public static String orgProductUuid = "";
	public static String newRecognizedProuctUuid;
	JSONArray arrayExpected;
	static JSONObject jsonResponseTopicOut;
	boolean allFields = true;
	ArrayList<String> recognisedProductsList = new ArrayList<>();
	ArrayList<String> requestFields = new ArrayList<>(
			Arrays.asList("eventBody_recognisingOrganisationUuid", "eventBody_organisationName",
					"eventBody_organisationId", "eventBody_organisationTypeUuid", "eventBody_organisationStatus",
					"eventBody_parentRecognisingOrganisationUuid", "eventBody_verificationStatus",
					"eventBody_partnerCode", "eventBody_partnerContact", "eventBody_methodOfDelivery",
					"eventBody_sectorTypeUuid", "eventBody_websiteUrl", "eventBody_organisationCode"));

	static ArrayList<String> recognisedProducts = new ArrayList<>(
			Arrays.asList("recognisedProductUuid", "productUuid", "effectiveFromDateTime", "effectiveToDateTime"));

	/************************************************************************
	 * Function Name: postRequest Function Description: To post request body with
	 * headers to API endpoint
	 *************************************************************************/
	public Response postRequest(String actUrl, String actPath, String destination, String envKey, String accessToken) {
		RestAssured.baseURI = actUrl;
		response = SerenityRest.given()
				.headers("envKey", envKey, "destination", destination, "Authorization", "Bearer " + accessToken)
				.contentType(ContentType.JSON).log().all().body(postbody).post(actPath);
		return response;
	}

	/************************************************************************
	 * Function Name: verifyResponse Function Description: To validate the response
	 * code
	 *************************************************************************/
	public void verifyResponse() {

		actResponseCode = response.getStatusCode();
		actResponse = response.asString();

		if (actResponseCode == resPONSECODE202) {
			assertEquals(actResponseCode, resPONSECODE202);
			System.out.println("ResponseCode: " + actResponseCode);
			System.out.println("Response: " + actResponse);
		} else {
			assertEquals(actResponseCode, resPONSECODE400);
		}
	}

	/************************************************************************
	 * Function Name: verifyResponseStatusCode Function Description: To validate the
	 * response code
	 *************************************************************************/
	public void verifyResponseStatusCode(int expstatusCode) {

		actResponseCode = response.getStatusCode();
		actResponse = response.asString();

		if (actResponseCode == expstatusCode) {
			assertEquals(actResponseCode, expstatusCode);
			System.out.println("ResponseCode: " + actResponseCode);
			System.out.println("Response: " + actResponse);
		} else {
			assertEquals(actResponseCode, resPONSECODE400);
		}
	}

	/************************************************************************
	 * Function Name: getInputRequestBody Function Description: To get the required
	 * request body from MongoDB id and fetch the expected values
	 * 
	 * @throws InterruptedException
	 *************************************************************************/
	@SuppressWarnings("deprecation")
	public String getInputRequestBodyfromTestDB(String hostName, Integer portNum, String dbName,
			String requestCollectionName, String transactionId) throws InterruptedException {

		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostName, portNum);) {
			DB db = mongoclient.getDB(dbName);
			DBCollection coll = db.getCollection(requestCollectionName);
			DBObject query = new BasicDBObject("eventHeader.transactionId", new BasicDBObject("$eq", transactionId));
			DBObject result = coll.findOne(query);
			String str = String.valueOf(result);
			int length = str.length();
			String subpostbody = str.substring(removehead, length);
			String postbodyRaw = curlybraces + subpostbody;
			expectedTransactionID = CommonModules.randomUUID();
			postbody = postbodyRaw.replaceAll(transactionId, expectedTransactionID);
			System.out.println("postbody" + postbody);
			return postbody;

		}
	}

	Faker faker = new Faker();
	public static String newrecognisingOrganisationUuid;
	public static String organisationName;
	public static String orgName;

	/************************************************************************
	 * Function Name: constructOrganizationChanged Event Function Description: to
	 * use unique value at each time
	 *************************************************************************/
	public String constructROEventCreated() throws org.json.simple.parser.ParseException {
		String recognisingOrganisationUuid = getFieldValueInRequest("eventBody_recognisingOrganisationUuid");
		String organisationId = getFieldValueInRequest("eventBody_organisationId");
		String parentRecognisingOrganisationUuid = getFieldValueInRequest(
				"eventBody_parentRecognisingOrganisationUuid");
		organisationName = getFieldValueInRequest("eventBody_organisationName");
		String correlationid = getFieldValueInRequest("eventHeader_correlationId");
		String eventdatetime = getFieldValueInRequest("eventHeader_eventDateTime");
		String transactionId = getFieldValueInRequest("eventHeader_transactionId");

		String newcorrelationid = CommonModules.randomUUID();
		LocalDateTime currenttimestamp = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		String neweventdatetime = currenttimestamp.format(formatter).toString();

		newrecognisingOrganisationUuid = CommonModules.randomUUID();
		String newparentRecognisingOrganisationUuid = CommonModules.randomUUID();
		expectedTransactionID = CommonModules.randomUUID();

		Random random = new Random();
		int num = random.nextInt(100000);
		String formatted = String.format("%05d", num);
		neworganisationId = formatted;
		String firstName = faker.name().firstName();
		orgName = firstName + "_University";

		ArrayList<String> productList = getExpectedValuesFromRecognisedProducts();
		for (int i = 0; i < productList.size(); i++) {

			String recognizedProuctUuid = productList.get(i).toString();
			newRecognizedProuctUuid = CommonModules.randomUUID();
			postbody = postbody.replaceAll(recognizedProuctUuid, newRecognizedProuctUuid);

		}

		ArrayList<String> addressList = getExpectedValuesFromAddress();
		for (int i = 0; i < addressList.size(); i++) {

			String recognizedProuctUuid = addressList.get(i).toString();
			newRecognizedProuctUuid = CommonModules.randomUUID();
			postbody = postbody.replaceAll(recognizedProuctUuid, newRecognizedProuctUuid);

		}

		postbody = postbody.replaceAll(recognisingOrganisationUuid, newrecognisingOrganisationUuid);
		postbody = postbody.replaceAll(organisationId, neworganisationId);
		postbody = postbody.replaceAll(organisationName, orgName);
		postbody = postbody.replaceAll(parentRecognisingOrganisationUuid, newparentRecognisingOrganisationUuid);
		postbody = postbody.replaceAll(correlationid, newcorrelationid);
		postbody = postbody.replaceAll(eventdatetime, neweventdatetime);
		postbody = postbody.replaceAll(transactionId, expectedTransactionID);

		return postbody;
	}

	public ArrayList<String> getExpectedValuesFromAddress() throws ParseException {
		// formatInputRequestBody();
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject = (JSONObject) jsonParser.parse(postbody);
		String eventBody = jsonObject.get("eventBody").toString();
		JSONObject eventBodyJson = (JSONObject) jsonParser.parse(eventBody);
		String jsonResponse1 = eventBodyJson.get("addresses").toString();
		System.out.println(jsonResponse1);
		JSONArray jsonArray = (JSONArray) new JSONParser().parse(jsonResponse1);

		for (int i = 0; i < jsonArray.size(); i++) {
			postBodyreq = jsonArray.get(i).toString();
			verifyFieldValueInRequest("addressUuid");
			String status = valueInJsonFile;
			addressListData.add(status);
			System.out.println("addressListData :" + addressListData);
		}
		return addressListData;
	}

	ArrayList<String> addressListData = new ArrayList<>();
	public static String targetRecognisingOrganisationUuid;

	public static void savedRecognisinOrganisationUuid() {
		targetRecognisingOrganisationUuid = newrecognisingOrganisationUuid;
	}

	/************************************************************************
	 * Function Name: construct organizationChanged event With Old EventDateTime
	 * Function Description: to use unique value at each time
	 *************************************************************************/
	public String constructROEventWithOldEventDateTime(String eventDateTimeFlag)
			throws org.json.simple.parser.ParseException {

		String correlationid = getFieldValueInRequest("eventHeader_correlationId");
		String eventdatetime = getFieldValueInRequest("eventHeader_eventDateTime");
		String transactionId = getFieldValueInRequest("eventHeader_transactionId");
		String eventName = getFieldValueInRequest("eventHeader_eventName");
		String organisationId = getFieldValueInRequest("eventBody_organisationId");
		String organisationStatus = getFieldValueInRequest("eventBody_organisationStatus");

		String newcorrelationid = CommonModules.randomUUID();
		expectedTransactionID = CommonModules.randomUUID();

		if (eventDateTimeFlag.equalsIgnoreCase("future")) {
			LocalDateTime currenttimestamp = LocalDateTime.now();
			currenttimestamp = currenttimestamp.plusDays(1);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			neweventdatetime = currenttimestamp.format(formatter).toString();
		} else if (eventDateTimeFlag.equalsIgnoreCase("past")) {
			LocalDateTime currenttimestamp = LocalDateTime.now();
			currenttimestamp = currenttimestamp.minusHours(2);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			neweventdatetime = currenttimestamp.format(formatter).toString();
		}

		postbody = postbody.replaceAll(correlationid, newcorrelationid);
		postbody = postbody.replaceAll(eventdatetime, neweventdatetime);
		postbody = postbody.replaceAll(transactionId, expectedTransactionID);
		postbody = postbody.replaceAll(organisationId, neworganisationId);
		postbody = postbody.replaceAll(organisationStatus, "INACTIVE");
		postbody = postbody.replace(eventName, "RoChanged");
		return postbody;
	}

	/************************************************************************
	 * Function Name: getFieldValueInRequest Function Description: get expected
	 * values from request
	 *************************************************************************/

	public String constructROHierarchyEvent() throws org.json.simple.parser.ParseException, JsonProcessingException {

		String correlationid = getFieldValueInRequest("eventHeader_correlationId");
		String eventdatetime = getFieldValueInRequest("eventHeader_eventDateTime");
		String transactionId = getFieldValueInRequest("eventHeader_transactionId");
		String eventName = getFieldValueInRequest("eventHeader_eventName");
		// String organisationId = getFieldValueInRequest("eventBody_organisationId");
		// String organisationStatus =
		// getFieldValueInRequest("eventBody_organisationStatus");
		String newcorrelationid = CommonModules.randomUUID();
		String linkedOrganisationUuid = CommonModules.randomUUID();
		expectedTransactionID = CommonModules.randomUUID();
		LocalDateTime currenttimestamp = LocalDateTime.now();
		currenttimestamp = currenttimestamp.plusDays(1);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		neweventdatetime = currenttimestamp.format(formatter).toString();

		postbody = postbody.replaceAll(correlationid, newcorrelationid);
		postbody = postbody.replaceAll(eventdatetime, neweventdatetime);
		postbody = postbody.replaceAll(transactionId, expectedTransactionID);
		// postbody = postbody.replaceAll(organisationId,neworganisationId);
		// postbody = postbody.replaceAll(organisationStatus,"INACTIVE");
		postbody = postbody.replace(eventName, "RoChanged");
		ObjectMapper mapper = new ObjectMapper();
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject = (JSONObject) jsonParser.parse(postbody);
		String eventBody = jsonObject.get("eventBody").toString();
		JSONObject eventBodyJson = (JSONObject) jsonParser.parse(eventBody);

		JSONObject linkedOrganisationFields = new JSONObject();
		linkedOrganisationFields.put("linkedRecognisingOrganisationUuid", linkedOrganisationUuid);
		linkedOrganisationFields.put("targetRecognisingOrganisationUuid", targetRecognisingOrganisationUuid);
		linkedOrganisationFields.put("linkType", "RESULTS_DELIVERY");
		linkedOrganisationFields.put("linkEffectiveFromDateTime", "2022-01-02T13:15:57.040Z");
		linkedOrganisationFields.put("linkEffectiveToDateTime", "2030-02-19T13:15:57.040Z");

		JSONArray linkedOrganisation = new JSONArray();
		linkedOrganisation.add(linkedOrganisationFields);

		eventBodyJson.put("linkedOrganisations", linkedOrganisation);

		String eventBodyInString = mapper.writeValueAsString(eventBodyJson);
		jsonObject.put("eventBody", eventBodyInString);
		postbody = mapper.writeValueAsString(jsonObject);
		return postbody;
	}

	public String commonUpdatesForInvaidDateTime(String typeValue) throws ParseException, JsonProcessingException {
		String correlationid = getFieldValueInRequest("eventHeader_correlationId");
		String eventdatetime = getFieldValueInRequest("eventHeader_eventDateTime");
		String transactionId = getFieldValueInRequest("eventHeader_transactionId");
		String eventName = getFieldValueInRequest("eventHeader_eventName");
		// String organisationId = getFieldValueInRequest("eventBody_organisationId");
		// String organisationStatus =
		// getFieldValueInRequest("eventBody_organisationStatus");
		String newcorrelationid = CommonModules.randomUUID();
		String linkedOrganisationUuid = CommonModules.randomUUID();
		expectedTransactionID = CommonModules.randomUUID();
		LocalDateTime currenttimestamp = LocalDateTime.now();
		currenttimestamp = currenttimestamp.plusDays(1);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		neweventdatetime = currenttimestamp.format(formatter).toString();

		postbody = postbody.replaceAll(correlationid, newcorrelationid);
		postbody = postbody.replaceAll(eventdatetime, neweventdatetime);
		postbody = postbody.replaceAll(transactionId, expectedTransactionID);
		// postbody = postbody.replaceAll(organisationId,neworganisationId);
		// postbody = postbody.replaceAll(organisationStatus,"INACTIVE");
		postbody = postbody.replace(eventName, "RoChanged");
		ObjectMapper mapper = new ObjectMapper();
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject = (JSONObject) jsonParser.parse(postbody);
		String eventBody = jsonObject.get("eventBody").toString();
		JSONObject eventBodyJson = (JSONObject) jsonParser.parse(eventBody);

		JSONObject linkedOrganisationFields = new JSONObject();
		linkedOrganisationFields.put("linkedRecognisingOrganisationUuid", linkedOrganisationUuid);
		linkedOrganisationFields.put("targetRecognisingOrganisationUuid", targetRecognisingOrganisationUuid);
		linkedOrganisationFields.put("linkType", typeValue);
		linkedOrganisationFields.put("linkEffectiveFromDateTime", "2000-01-02T13:15:57.040Z");
		linkedOrganisationFields.put("linkEffectiveToDateTime", "2021-12-19T13:15:57.040Z");

		JSONArray linkedOrganisation = new JSONArray();
		linkedOrganisation.add(linkedOrganisationFields);

		eventBodyJson.put("linkedOrganisations", linkedOrganisation);

		String eventBodyInString = mapper.writeValueAsString(eventBodyJson);
		jsonObject.put("eventBody", eventBodyInString);
		postbody = mapper.writeValueAsString(jsonObject);
		return postbody;
	}

	public String commonUpdates(String typeValue) throws ParseException, JsonProcessingException {
		String correlationid = getFieldValueInRequest("eventHeader_correlationId");
		String eventdatetime = getFieldValueInRequest("eventHeader_eventDateTime");
		String transactionId = getFieldValueInRequest("eventHeader_transactionId");
		String eventName = getFieldValueInRequest("eventHeader_eventName");
		// String organisationId = getFieldValueInRequest("eventBody_organisationId");
		// String organisationStatus =
		// getFieldValueInRequest("eventBody_organisationStatus");
		String newcorrelationid = CommonModules.randomUUID();
		String linkedOrganisationUuid = CommonModules.randomUUID();
		expectedTransactionID = CommonModules.randomUUID();
		LocalDateTime currenttimestamp = LocalDateTime.now();
		currenttimestamp = currenttimestamp.plusDays(1);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		neweventdatetime = currenttimestamp.format(formatter).toString();

		postbody = postbody.replaceAll(correlationid, newcorrelationid);
		postbody = postbody.replaceAll(eventdatetime, neweventdatetime);
		postbody = postbody.replaceAll(transactionId, expectedTransactionID);
		// postbody = postbody.replaceAll(organisationId,neworganisationId);
		// postbody = postbody.replaceAll(organisationStatus,"INACTIVE");
		postbody = postbody.replace(eventName, "RoChanged");
		ObjectMapper mapper = new ObjectMapper();
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject = (JSONObject) jsonParser.parse(postbody);
		String eventBody = jsonObject.get("eventBody").toString();
		JSONObject eventBodyJson = (JSONObject) jsonParser.parse(eventBody);

		JSONObject linkedOrganisationFields = new JSONObject();
		linkedOrganisationFields.put("linkedRecognisingOrganisationUuid", linkedOrganisationUuid);
		linkedOrganisationFields.put("targetRecognisingOrganisationUuid", targetRecognisingOrganisationUuid);
		linkedOrganisationFields.put("linkType", typeValue);
		linkedOrganisationFields.put("linkEffectiveFromDateTime", "2022-01-02T13:15:57.040Z");
		linkedOrganisationFields.put("linkEffectiveToDateTime", "2030-02-19T13:15:57.040Z");

		JSONArray linkedOrganisation = new JSONArray();
		linkedOrganisation.add(linkedOrganisationFields);

		eventBodyJson.put("linkedOrganisations", linkedOrganisation);

		String eventBodyInString = mapper.writeValueAsString(eventBodyJson);
		jsonObject.put("eventBody", eventBodyInString);
		postbody = mapper.writeValueAsString(jsonObject);
		return postbody;
	}

	/************************************************************************
	 * Function Name: getFieldValueInRequest Function Description: get expected
	 * values from request
	 *************************************************************************/

	public String getFieldValueInRequest(String fieldValue) throws ParseException {

		JSONParser parser = new JSONParser();
		JSONObject json = (JSONObject) parser.parse(postbody);

		ArrayList<String> json1 = new ArrayList<>();
		if (fieldValue.contains("_")) {
			String[] values = fieldValue.split("_");
			java.util.Collections.addAll(json1, values);
			for (int i = 0; i < values.length - 1; i++) {
				String counter = json1.get(i);
				valueInJsonFile = (String) json.get(counter).toString();
				// valueInJsonFile = valueInJsonFile.replace("[{", "{").replace("}]}}",
				// "}}").replace("}]", "}");
				json = (JSONObject) parser.parse(valueInJsonFile);
			}
			try {
				String counter = json1.get(json1.size() - 1);
				valueInJsonFile = (String) json.get(counter);
			} catch (ClassCastException e) {
				String counter = json1.get(json1.size() - 1);
				valueInJsonFile = String.valueOf(json.get(counter));
			}

		} else {
			valueInJsonFile = (String) json.get(fieldValue);
		}
		if (valueInJsonFile == null || valueInJsonFile.equalsIgnoreCase("")) {
			Serenity.recordReportData().asEvidence().withTitle("Field or Field value is not provided : ")
					.andContents(fieldValue);

		}
		return valueInJsonFile;
	}

	/************************************************************************
	 * Function Name: getJsonFeildValuesfromRequestbody Function Description: get
	 * expected values from request
	 *************************************************************************/
	public void getJsonFeildValuesfromRequestbody() throws ParseException {
		expectedrecognisingOrganisationUuid = getFieldValueInRequest(requestFields.get(0));
		expectedorganisationName = getFieldValueInRequest(requestFields.get(1));
		expectedorganisationId = getFieldValueInRequest(requestFields.get(2));
		expectedorganisationTypeUuid = getFieldValueInRequest(requestFields.get(3));
		expectedorganisationStatus = getFieldValueInRequest(requestFields.get(4));
		expectedparentRecognisingOrganisationUuid = getFieldValueInRequest(requestFields.get(5));
		expectedverificationStatus = getFieldValueInRequest(requestFields.get(6));
		expectedpartnerCode = getFieldValueInRequest(requestFields.get(7));
		expectedmethodOfDelivery = getFieldValueInRequest(requestFields.get(9));
		expectedorganisationCode = getFieldValueInRequest(requestFields.get(12));
	}

	/************************************************************************
	 * Function Name: connectMongoDB Function Description: get response values from
	 * asynch db
	 *************************************************************************/
	public static void connectMongoDB(String hostname, Integer portnum) throws InterruptedException, ParseException {
		String strVal;
		strVal = CommonModules.connectMongoDBandfetchAsyncResponseForRDS(hostname, portnum, expectedTransactionID);
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject = (JSONObject) jsonParser.parse(strVal);
		JSONObject jsonResponse = (JSONObject) jsonObject.get("body");
		responseFromPOSTCall = jsonResponse.toString();
		Serenity.recordReportData().withTitle("Actual Response on Topic-Out:").andContents(responseFromPOSTCall);
	}

	public void asyncInRDS() throws ParseException {
		responseFromPOSTCall = responseFromPOSTCall.replace(":\"{\"", ":{\"");
		responseFromPOSTCall = responseFromPOSTCall.replace("\\\"", "\"");
		responseFromPOSTCall = responseFromPOSTCall.replace("}\",\"", "},\"");
		responseFromPOSTCall = responseFromPOSTCall.replace("}\"}", "}}").replace(":\"{\"", ":{\"");
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject = (JSONObject) jsonParser.parse(responseFromPOSTCall);
		jsonResponseTopicOut = (JSONObject) jsonObject.get("eventBody");
	}

	public void formatInputRequestBody() throws ParseException {
		inputDataForParsing = postbody.toString();
		inputDataForParsing = inputDataForParsing.replace("\"{\\", "{");
		inputDataForParsing = inputDataForParsing.replace("}\" }", "}}");
		inputDataForParsing = inputDataForParsing.replace(",\\", ",");
		inputDataForParsing = inputDataForParsing.replace("\\\": \\\"", "\": \"").replace("\\\",", "\",")
				.replace("[{\\", "[{").replace("\\\":", "\":").replace("\\\"}]", "\"}]").replace("}}}", "}}");
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject = (JSONObject) jsonParser.parse(inputDataForParsing);
		jsonInputBody = (JSONObject) jsonObject.get("eventBody");
	}

	/************************************************************************
	 * Function Name: validatePublishedMessage Function Description: validate
	 * published response with expected values
	 *************************************************************************/
	public void validatePublishedMessage() throws org.json.simple.parser.ParseException {

		asyncInRDS();
		postBodyreq = jsonResponseTopicOut.toString();

		verifyFieldValueInRequest("recognisingOrganisationUuid");
		actualrecognisingOrganisationUuid = valueInJsonFile;
		Assert.assertEquals(expectedrecognisingOrganisationUuid, actualrecognisingOrganisationUuid);

		verifyFieldValueInRequest("organisationTypeUuid");
		actualorganisationTypeUuid = valueInJsonFile;
		Assert.assertEquals(expectedorganisationTypeUuid, actualorganisationTypeUuid);

		verifyFieldValueInRequest("partnerCode");
		actualpartnerCode = valueInJsonFile;
		Assert.assertEquals(expectedpartnerCode, actualpartnerCode);

		verifyFieldValueInRequest("organisationId");
		actualorganisationId = valueInJsonFile;
		Assert.assertEquals(expectedorganisationId, actualorganisationId);

		verifyFieldValueInRequest("name");
		actualorganisationName = valueInJsonFile;
		Assert.assertEquals(expectedorganisationName, actualorganisationName);

		verifyFieldValueInRequest("verificationStatus");
		actualverificationStatus = valueInJsonFile;
		Assert.assertEquals(expectedverificationStatus, actualverificationStatus);

		verifyFieldValueInRequest("parentRecognisingOrganisationUuid");
		actualparentRecognisingOrganisationUuid = valueInJsonFile;
		Assert.assertEquals(expectedparentRecognisingOrganisationUuid, actualparentRecognisingOrganisationUuid);

		verifyFieldValueInRequest("organisationStatus");
		actualorganisationStatus = valueInJsonFile;
		Assert.assertEquals(expectedorganisationStatus, actualorganisationStatus);

		verifyFieldValueInRequest("organisationCode");
		actualorganisationCode = valueInJsonFile;
		Assert.assertEquals(expectedorganisationCode, actualorganisationCode);

		/*
		 * verifyFieldValueInRequest("methodOfDelivery"); actualmethodOfDelivery =
		 * valueInJsonFile; Assert.assertEquals(expectedmethodOfDelivery,
		 * actualmethodOfDelivery);
		 */

	}

	/************************************************************************
	 * Function Name: verifyErrorInPublishedMessage Function Description: validate
	 * published error response with expected values
	 *************************************************************************/
	public void verifyErrorInPublishedMessage() throws ParseException {

		postbody = responseFromPOSTCall;
		String actualEventName = getFieldValueInRequest("eventHeader_eventName");
		Assert.assertEquals(actualEventName, "SelectionRoChangeFailed");

	}

	/************************************************************************
	 * Function Name: verifyMandatoryFieldInRecognisedProducts Function Description:
	 * validate published response contain all values
	 *************************************************************************/
	static ArrayList<String> productUuidList = new ArrayList<>();

	public void verifyMandatoryFieldInRecognisedProducts() throws ParseException {
		asyncInRDS();
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject = (JSONObject) jsonParser.parse(jsonResponseTopicOut.toString());
		String jsonResponse1 = jsonObject.get("recognisedProducts").toString();

		JSONArray jsonArray = (JSONArray) new JSONParser().parse(jsonResponse1);
		// JSONArray jsonArray = new JSONArray(jsonResponse1);

		Boolean minimumFields = true;
		for (int i = 0; i < jsonArray.size(); i++) {

			postBodyreq = jsonArray.get(i).toString();
			for (int i1 = 0; i1 < recognisedProducts.size(); i1++) {
				minimumFields = verifyFieldValueInRequest(recognisedProducts.get(i1));
				verifyFieldValueInRequest("productUuid");
				productUuidList.add(i, valueInJsonFile);

			}
			orgProductUuid = productUuidList.get(i);
		}
		if (minimumFields) {
			Serenity.recordReportData().withTitle("Required fields provided ");
		} else {
			Serenity.recordReportData().withTitle("Required fields not provided ");
		}
	}

	/************************************************************************
	 * Function Name: allFields Function Description: Checking all the fields are
	 * provided or not
	 *************************************************************************/
	public void allFields() throws ParseException {

		String minimumFields = "true";
		for (int i = 0; i < requestFields.size(); i++) {

			minimumFields = getFieldValueInRequest(requestFields.get(i));
			System.out.println(i);
		}
		if (minimumFields == "true") {
			Serenity.recordReportData().withTitle("Required fields provided ");
		} else {
			Serenity.recordReportData().withTitle("Required fields not provided ");
		}
	}

	public ArrayList<String> getExpectedValuesFromRecognisedProducts() throws ParseException {
		// formatInputRequestBody();
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject = (JSONObject) jsonParser.parse(postbody);
		String eventBody = jsonObject.get("eventBody").toString();
		JSONObject eventBodyJson = (JSONObject) jsonParser.parse(eventBody);
		String jsonResponse1 = eventBodyJson.get("recognisedProducts").toString();
		System.out.println(jsonResponse1);
		JSONArray jsonArray = (JSONArray) new JSONParser().parse(jsonResponse1);
		// JSONArray jsonArray = new JSONArray(jsonResponse1);

		for (int i = 0; i < jsonArray.size(); i++) {
			postBodyreq = jsonArray.get(i).toString();
			verifyFieldValueInRequest("recognisedProductUuid");
			String status = valueInJsonFile;
			recognisedProductsList.add(status);
			System.out.println("recognisedProductsList :" + recognisedProductsList);
		}
		return recognisedProductsList;
	}

	public static Boolean verifyFieldValueInRequest(String fieldValue) throws ParseException {
		JSONParser parser = new JSONParser();
		JSONObject json = (JSONObject) parser.parse(postBodyreq);
		try {
			ArrayList<String> json1 = new ArrayList<>();
			if (fieldValue.contains("_")) {
				String[] values = fieldValue.split("_");
				for (int i = 0; i < values.length; i++) {
					json1.add(values[i]);
				}
				for (int i = 0; i < values.length - 1; i++) {
					String counter = json1.get(i);
					valueInJsonFile = json.get(counter).toString();
					valueInJsonFile = valueInJsonFile.replace("[{", "{").replace("}]", "}");
					json = (JSONObject) parser.parse(valueInJsonFile);
				}
				try {
					String counter = json1.get(json1.size() - 1);
					valueInJsonFile = (String) json.get(counter);
				} catch (ClassCastException e) {
					String counter = json1.get(json1.size() - 1);
					valueInJsonFile = String.valueOf(json.get(counter));
				}

			} else {
				if (fieldValue.equalsIgnoreCase("consentGiven") || fieldValue.equalsIgnoreCase("isVoid")
						|| fieldValue.equalsIgnoreCase("bannedStatus")
						|| fieldValue.equalsIgnoreCase("specialArrangementsRequired")) {
					Boolean flag = (Boolean) json.get(fieldValue);
					valueInJsonFile = Boolean.toString(flag);
				} else
					valueInJsonFile = json.get(fieldValue).toString();
			}
			if (valueInJsonFile == null || valueInJsonFile.equalsIgnoreCase("")) {
				Serenity.recordReportData().asEvidence().withTitle("Field or Field value is not provided : ")
						.andContents(fieldValue);
				validationFail1 = false;
				count++;
			}
			if (fieldValue.equalsIgnoreCase("testTaker_uniqueTestTakerUuid") && validationFail1) {
				validationFail1 = true;
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return validationFail1;
	}

	static int count = 0;

	public String ActUrl = "";

	public String TakeActUrl(String Env) {

		System.out.println(Env);
		switch (Env) {
		case "sandbox":
			ActUrl = CommonModules.getEnvironmentConfigurations("int70.SandboxActurl");
			break;
		case "sandbox2":
			ActUrl = CommonModules.getEnvironmentConfigurations("int70.Sandbox2Acturl");
			break;
		case "dev":
			ActUrl = CommonModules.getEnvironmentConfigurations("int70.DevActurl");
			break;
		}
		return ActUrl;
	}

	public String EnvKeyQueue = "";

	public String TakeEnvKeyQueue(String Env) {

		System.out.println(Env);
		switch (Env) {
		case "sandbox":
			EnvKeyQueue = CommonModules.getEnvironmentConfigurations("int189.SandboxenvKeyQueue");
			break;
		case "sandbox2":
			EnvKeyQueue = CommonModules.getEnvironmentConfigurations("int189.Sandbox2envKeyQueue");
			break;
		case "dev":
			EnvKeyQueue = CommonModules.getEnvironmentConfigurations("int189.DevenvKeyQueue");
			break;
		}
		return EnvKeyQueue;
	}

	public static String authUrlForBooking = "";

	public static String takeAuthUrlForBooking(String partner) {
		String env = System.getenv("ENVIRONMENT");
		switch (env) {

		case "sandbox":
			if (partner.equalsIgnoreCase("IDP")) {
				authUrlForBooking = CommonModules.getEnvironmentConfigurations("Sandbox_IDP.AuthURL");
			} else if (partner.equalsIgnoreCase("BC")) {
				authUrlForBooking = CommonModules.getEnvironmentConfigurations("Sandbox_BC.AuthURL");
			}
			break;
		case "dev":
			if (partner.equalsIgnoreCase("IDP")) {
				authUrlForBooking = CommonModules.getEnvironmentConfigurations("Dev_IDP.AuthURL");
			} else if (partner.equalsIgnoreCase("BC")) {
				authUrlForBooking = CommonModules.getEnvironmentConfigurations("Dev_BC.AuthURL");
			}
			break;
		case "sit":
			if (partner.equalsIgnoreCase("IDP")) {
				authUrlForBooking = CommonModules.getEnvironmentConfigurations("sit_IDP.AuthURL");
			} else if (partner.equalsIgnoreCase("BC")) {
				authUrlForBooking = CommonModules.getEnvironmentConfigurations("sit_BC.AuthURL");
			}
			break;
		}
		return authUrlForBooking;
	}

	public static String authReqForBooking = "";

	public static String takeAuthReqForBooking(String partner) {
		String env = System.getenv("ENVIRONMENT");
		switch (env) {
		case "sandbox":
			if (partner.equalsIgnoreCase("IDP")) {
				authReqForBooking = CommonModules.getEnvironmentConfigurations("Sandbox_IDP.AuthReq");
			} else if (partner.equalsIgnoreCase("BC")) {
				authReqForBooking = CommonModules.getEnvironmentConfigurations("Sandbox_BC.AuthReq");
			}
			break;
		case "dev":
			if (partner.equalsIgnoreCase("IDP")) {
				authReqForBooking = CommonModules.getEnvironmentConfigurations("Dev_IDP.AuthReq");
			} else if (partner.equalsIgnoreCase("BC")) {
				authReqForBooking = CommonModules.getEnvironmentConfigurations("Dev_BC.AuthReq");
			}
			break;
		case "sit":
			if (partner.equalsIgnoreCase("IDP")) {
				authReqForBooking = CommonModules.getEnvironmentConfigurations("sit_IDP.AuthReq");
			} else if (partner.equalsIgnoreCase("BC")) {
				authReqForBooking = CommonModules.getEnvironmentConfigurations("sit_BC.AuthReq");
			}
			break;
		}
		return authReqForBooking;
	}

	public String DbUrl = "";

	public String TakeDbUrl(String Env) {

		System.out.println(Env);
		switch (Env) {
		case "sandbox":
			ActUrl = CommonModules.getEnvironmentConfigurations("cmds268.dbUrlSandbox");
			break;
		case "sandbox2":
			ActUrl = CommonModules.getEnvironmentConfigurations("cmds268.dbUrlSandbox");
			break;
		case "dev":
			ActUrl = CommonModules.getEnvironmentConfigurations("cmds268.dbUrlDev");
			break;
		}
		return ActUrl;
	}

}
