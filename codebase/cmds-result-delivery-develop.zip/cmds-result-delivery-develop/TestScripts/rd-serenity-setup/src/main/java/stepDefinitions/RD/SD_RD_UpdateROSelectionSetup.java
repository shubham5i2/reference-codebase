package stepDefinitions.RD;

import com.mongodb.util.JSON;

import common.CommonModules;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import stepImplementations.RD.SI_RD_AcceptROSelectionSetup;
import stepImplementations.RD.SI_RD_BookingCreatedEventSetup;
import stepImplementations.RD.SI_RD_ROCreatedEventSetup;
import stepImplementations.RD.SI_RD_UpdateROSelectionSetup;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import static io.restassured.RestAssured.given;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class SD_RD_UpdateROSelectionSetup extends CommonModules {

	static CommonModules common = new CommonModules();
	static SI_RD_BookingCreatedEventSetup booking = new SI_RD_BookingCreatedEventSetup();
	static SI_RD_ROCreatedEventSetup organisation = new SI_RD_ROCreatedEventSetup();
	static SI_RD_AcceptROSelectionSetup stepImplementation = new SI_RD_AcceptROSelectionSetup();
	static SI_RD_UpdateROSelectionSetup implementation = new SI_RD_UpdateROSelectionSetup();
	String env = System.getenv("ENVIRONMENT");
	public String swaggerVersion = System.getenv("SWAGGER_VERSION");
	public static String RD_AsyncDB;
	public static String RD_AsyncCollection;
	public static String envkeyQueue = "";
	public static String AuthURL = "";
	static String AuthReq = "";
	public static String mxName = "";
	public static String DBUrl = "";
	public static String dbUrl = "";
	public static String accessToken = "";

	public static String ors268dbname = "";
	public static String ors268reqcollection = "";
	public static String ors268servercollection = "";
	public static String ors268callbackurl = "";
	protected static String cmds268resultActpath = "";
	protected static String cmds268resultActurl = "";

	public static String ors70dbname = "";
	public static String ors70reqcollection = "";
	public static String ors70servercollection = "";
	public static String ors70baseurl = "";

	public static String ors189dbname = "";
	public static String ors189reqcollection = "";
	public static String ors189servercollection = "";
	public static String ors189baseurl = "";
	public static String basepath = "";

	public static String randomUUIDString = "";
	public static String authURLIDP = "";
	public static String authReqIDP = "";
	public static String enviroment = "";
	public static String dbUrlSandbox = "";

	protected static String dbUrlDev = "";
	public static String accessTokenIDP;

	@Given("^Clean the Mondodb database for update selection IMOD-8082$")
	public void cleantheMondodbdatabaseforupdateselectionIMOD() throws IOException {
		common.getEnvironmentConfigurationsOpen();
		hostname = common.getEnvironmentConfigurations("common.hostname");
		portnum = Integer.parseInt(common.getEnvironmentConfigurations("common.portnum"));

		errordb = common.getEnvironmentConfigurations("common.errordb");
		errorcollection = common.getEnvironmentConfigurations("common.errorcollection");
		RD_AsyncCollection = common.getEnvironmentConfigurations("common.RD.AsyncCollection");
		RD_AsyncDB = common.getEnvironmentConfigurations("common.RD.AsyncDBname");
		ors70dbname = common.getEnvironmentConfigurations("int70.dbname");
		ors70reqcollection = common.getEnvironmentConfigurations("int70.reqcollection");
		ors70servercollection = common.getEnvironmentConfigurations("int70.servercollection");
		ors70baseurl = common.getEnvironmentConfigurations("int70.baseurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		errordb = common.getEnvironmentConfigurations("common.errordb");
		errorcollection = common.getEnvironmentConfigurations("common.errorcollection");

		organisation.cleanDatebaseModule(hostname, portnum, ors70dbname, ors70reqcollection);
		organisation.cleanDatebaseModule(hostname, portnum, errordb, errorcollection);
		organisation.cleanDatebaseModule(hostname, portnum, ors70dbname, ors70servercollection);

		ors189dbname = common.getEnvironmentConfigurations("int189.dbname");
		ors189reqcollection = common.getEnvironmentConfigurations("int189.reqcollection");
		ors189servercollection = common.getEnvironmentConfigurations("int189.servercollection");
		ors189baseurl = common.getEnvironmentConfigurations("int189.baseurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		booking.cleanDatebaseModule(hostname, portnum, ors189dbname, ors189reqcollection);
		booking.cleanDatebaseModule(hostname, portnum, ors189dbname, ors189servercollection);

		ors268dbname = common.getEnvironmentConfigurations("int268.dbname");
		ors268reqcollection = common.getEnvironmentConfigurations("int268.reqcollection");
		ors268servercollection = common.getEnvironmentConfigurations("int268.servercollection");
		ors268callbackurl = common.getEnvironmentConfigurations("int268.mockurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		implementation.cleanDatebaseModule(hostname, portnum, ors268dbname, ors268reqcollection);
		implementation.cleanDatebaseModule(hostname, portnum, ors268dbname, ors268servercollection);
		implementation.cleanDatebaseModule(hostname, portnum, errordb, errorcollection);
		common.cleanAsyncDBCollection(hostname, portnum, RD_AsyncDB, RD_AsyncCollection);
	}
	
	@Then("^Insert the request for IMOD-8082$")
	public void insert_the_request_IMOD() throws IOException, ParseException {
		if (swaggerVersion.equalsIgnoreCase("v1")) {
			booking.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors189dbname, ors189reqcollection);
			organisation.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors70dbname, ors70reqcollection);
			implementation.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors268dbname, ors268reqcollection);
		} else if (swaggerVersion.equalsIgnoreCase("v2")) {
			booking.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors189dbname, ors189reqcollection);
			organisation.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors70dbname, ors70reqcollection);
			implementation.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors268dbname, ors268reqcollection);
		}

		booking.connectandInsertORSCommonresDataInMongoDB(hostname, portnum, errordb, errorcollection);
		stepImplementation.connectandInsertErrorResponseMongoDB(hostname, portnum, ors268dbname, ors268reqcollection);
		implementation.connectandInsertORSCommonresDataInMongoDB(hostname, portnum, errordb, errorcollection);
		stepImplementation.connectandInsertDBdataReqDataInMongoDB(hostname, portnum, ors189dbname, ors189reqcollection);
		stepImplementation.connectandInsertDBdataReqDataInMongoDB(hostname, portnum, ors268dbname, ors268reqcollection);
		stepImplementation.connectandInsertDBdataReqDataInMongoDB(hostname, portnum, ors70dbname, ors70reqcollection);
	
	}

	@Then("^Insert mock data into Ors Mock_Callback Server IMOD-(\\d+)$")
	public void insert_mock_data_into_Ors_Mock_Callback_Server_IMOD(int arg1)
			throws FileNotFoundException, IOException, ParseException {

		implementation.ConnectandInsertORSResDataInMongoDB(hostname, portnum, ors268dbname, ors268servercollection);
		implementation.TakeORSMockDataFromMongoDB(hostname, portnum, ors268dbname, ors268servercollection);
		implementation.PostORSMockDataIntoWiremock(ors268callbackurl, basepath);
	}

	@Then("^Update RO Selection Testdata files setup completed successfully$")
	public void update_RO_Selection_Testdata_files_setup_completed_successfully() {
		System.out.println("Reference data set up is completed successfully");

	}

	@Given("^CMDS Result Delivery Service is Ready for IMOD-8225 \"([^\"]*)\"$")
	public void cmdsResultDeliveryServiceisReadyIMODCreateSelection(String partner) throws IOException {
		common.getEnvironmentConfigurationsOpen();
		hostname = common.getEnvironmentConfigurations("common.hostname");
		portnum = Integer.parseInt(common.getEnvironmentConfigurations("common.portnum"));
		ors268dbname = common.getEnvironmentConfigurations("ors268.dbname");
		ors268reqcollection = common.getEnvironmentConfigurations("ors268.reqcollection");
		errordb = common.getEnvironmentConfigurations("common.errordb");
		errorcollection = common.getEnvironmentConfigurations("common.errorcollection");
		// cmds268resultActurl =
		// common.getEnvironmentConfigurations("cmds268.resultActurl");
		cmds268resultActurl = implementation.TakeActUrl(env);
		cmds268resultActpath = common.getEnvironmentConfigurations("cmds268.result.path");
		randomUUIDString = common.randomUUID();

		envkeyQueue = implementation.TakeEnvKeyQueue(env);
		AuthURL = implementation.takeAuthUrlForBooking(partner);
		AuthReq = implementation.takeAuthReqForBooking(partner);
		mxName = "RD";
		enviroment = env;
		DBUrl = implementation.TakeDbUrl(env);
		dbUrl = DBUrl;
		accessToken = common.RetrieveToken(AuthURL, AuthReq);

	}

	@When("^Get the request body form test DB using unique \"([^\"]*)\"$")
	public void gettherequestbodyformtestDBusinguniqueValue(String externalSelectionUuid) throws ParseException {
		implementation.getRequestbodyFromDB(hostname, portnum, ors268dbname, ors268reqcollection,
				externalSelectionUuid);
	}

	@When("^Get the request body form test DB using unique \"([^\"]*)\" for UA selection$")
	public void gettherequestbodyformtestDBusinguniqueforUSselection(String externalSelectionUuid)
			throws ParseException {
		implementation.getRequestbodyFromDBForUASelection(hostname, portnum, ors268dbname, ors268reqcollection,
				externalSelectionUuid);
	}

	@When("^RDS will Respond \"([^\"]*)\"$")
	public void rdmx_will_respond_status_code(int expectedResponse) {
		implementation.response(expectedResponse);
	}

	@When("^RDS will send transaction id$")
	public void rd_mx_will_send_transaction_Ids() {
		implementation.cmdsRetrunsTransactiondetails(expResponse401, expResponse403);
	}

	@When("^ORS post selection details to rds endpoint$")
	public void ors_post_selection_details_to_rdmx_endpoint() throws ParseException {
		implementation.getPartnerCodefromJWT();
		implementation.orsPostRegistrationToCMDS(cmds268resultActurl, cmds268resultActpath, randomUUIDString,
				accessToken);

	}
}
