package stepDefinitions.RD;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.json.simple.parser.ParseException;

import common.CommonModules;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import stepImplementations.RD.SI_RD_ConsumeLegacyResultPublishedV2Setup;

public class SD_RD_ConsumeLegacyResultPublishedV2EventSetup extends CommonModules
{
	String hostname;
	int portnum;
	private String evt178bname;
	private String evt178reqcollection;
	private String evt178servercollection;
	private String RD_AsyncCollection;
	private String RD_AsyncDB;
	
	public static CommonModules common = new CommonModules();
	SI_RD_ConsumeLegacyResultPublishedV2Setup stepImp = new SI_RD_ConsumeLegacyResultPublishedV2Setup();
	private String evt20baseurl;
	private String evt20basepath;
	
	@Given("Clean the Mongo database for new data setup for LegacyResultPublishedV2 event consumption$")
	public void Clean_the_Mongo_database_for_new_data_setup_for_LegacyResultPublishedV2_event_consumption() throws FileNotFoundException, IOException
	{
		common.getEnvironmentConfigurationsOpen();
		hostname = common.getEnvironmentConfigurations("common.hostname");
		portnum = Integer.parseInt(common.getEnvironmentConfigurations("common.portnum"));
		
		RD_AsyncCollection = common.getEnvironmentConfigurations("common.RD.AsyncCollection");
		RD_AsyncDB = common.getEnvironmentConfigurations("common.RD.AsyncDBname");
		
		evt178bname = common.getEnvironmentConfigurations("LegacyResultPublishedV2.dbname");
		evt178reqcollection = common.getEnvironmentConfigurations("LegacyResultPublishedV2.reqCollection");
		evt178servercollection = common.getEnvironmentConfigurations("LegacyResultPublishedV2.serverCollection");
		evt20baseurl = common.getEnvironmentConfigurations("common.baseurl");
		evt20basepath = common.getEnvironmentConfigurations("common.path");
		
		stepImp.cleanDatebaseModule(hostname, portnum, evt178bname, evt178reqcollection);
		stepImp.cleanDatebaseModule(hostname, portnum, evt178bname, evt178servercollection);
		common.cleanAsyncDBCollection(hostname, portnum, RD_AsyncDB, RD_AsyncCollection);
		
	}
	
	@Then("^Insert the request and responses to mongodb for LegacyResultPublishedV2 event consumption$")
	public void Insert_the_request_and_responses_to_mongodb_for_LegacyResultPublishedV2_event_consumption() throws IOException, ParseException
	{
		stepImp.v2_connectandInsertReqDataInMongoDB(hostname, portnum, evt178bname, evt178reqcollection);
	}
	
	@Then("^Setup the Server responses in the Mock server for the LegacyResultPublishedV2 event consumption Flow$")
	public void Setup_the_Server_responses_in_the_Mock_server_for_the_LegacyResultPublishedV2_event_consumption_Flow() throws FileNotFoundException, IOException, ParseException
	{
		stepImp.ConnectandInsertORSResDataInMongoDB(hostname, portnum, evt178bname, evt178servercollection);
		stepImp.TakeORSMockDataFromMongoDB(hostname, portnum, evt178bname, evt178servercollection);
		stepImp.PostORSMockDataIntoWiremock(evt20baseurl, evt20basepath);
	}
}