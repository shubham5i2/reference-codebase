package stepDefinitions.RD;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.json.simple.parser.ParseException;

import common.CommonModules;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import stepImplementations.RD.SI_RD_AcceptROSelectionSetup;
import stepImplementations.RD.SI_RD_AcceptUASelectionSetup;
import stepImplementations.RD.SI_RD_BookingCreatedEventSetup;
import stepImplementations.RD.SI_RD_ROCreatedEventSetup;

public class SD_RD_AcceptUASelectionSetup extends CommonModules {
	static CommonModules common = new CommonModules();
	public String swaggerVersion = System.getenv("SWAGGER_VERSION");
	static SI_RD_BookingCreatedEventSetup booking = new SI_RD_BookingCreatedEventSetup();
	static SI_RD_ROCreatedEventSetup organisation = new SI_RD_ROCreatedEventSetup();
	static SI_RD_AcceptROSelectionSetup stepImplementation = new SI_RD_AcceptROSelectionSetup();
	static SI_RD_AcceptUASelectionSetup uaSelection = new SI_RD_AcceptUASelectionSetup();

	public static String RD_AsyncDB;
	public static String RD_AsyncCollection;

	public static String ors189dbname = "";
	public static String ors189reqcollection = "";
	public static String ors189servercollection = "";
	public static String ors189baseurl = "";

	public static String ors70dbname = "";
	public static String ors70reqcollection = "";
	public static String ors70servercollection = "";
	public static String ors70baseurl = "";
	public static String basepath = "";
	public static String ors268dbname = "";
	public static String ors268reqcollection = "";
	public static String ors268servercollection = "";
	public static String ors268callbackurl = "";
	protected static String cmds268resultActpath = "";
	protected static String cmds268resultActurl = "";

	@Given("^Clean the Mondodb database for IMOD-25995$")
	public void clean_the_Mondodb_database_for_IMOD() throws IOException {
		common.getEnvironmentConfigurationsOpen();
		hostname = common.getEnvironmentConfigurations("common.hostname");
		portnum = Integer.parseInt(common.getEnvironmentConfigurations("common.portnum"));

		errordb = common.getEnvironmentConfigurations("common.errordb");
		errorcollection = common.getEnvironmentConfigurations("common.errorcollection");

		RD_AsyncCollection = common.getEnvironmentConfigurations("common.RD.AsyncCollection");
		RD_AsyncDB = common.getEnvironmentConfigurations("common.RD.AsyncDBname");

		ors189dbname = common.getEnvironmentConfigurations("int189.dbname");
		ors189reqcollection = common.getEnvironmentConfigurations("int189.reqcollection");
		ors189servercollection = common.getEnvironmentConfigurations("int189.servercollection");
		ors189baseurl = common.getEnvironmentConfigurations("int189.baseurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		booking.cleanDatebaseModule(hostname, portnum, ors189dbname, ors189reqcollection);
		booking.cleanDatebaseModule(hostname, portnum, ors189dbname, ors189servercollection);

		ors268dbname = common.getEnvironmentConfigurations("int368.dbname");
		ors268reqcollection = common.getEnvironmentConfigurations("int368.reqcollection");
		ors268servercollection = common.getEnvironmentConfigurations("int368.servercollection");
		ors268callbackurl = common.getEnvironmentConfigurations("int368.mockurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		uaSelection.cleanDatebaseModule(hostname, portnum, ors268dbname, ors268reqcollection);
		uaSelection.cleanDatebaseModule(hostname, portnum, ors268dbname, ors268servercollection);
		common.cleanAsyncDBCollection(hostname, portnum, RD_AsyncDB, RD_AsyncCollection);
	}

	@Given("^Insert the request for test data setup in mongodb for ua selection setup$")
	public void insert_the_request_for_test_data_setup_in_mongodb_for_ua_selection_setup()
			throws IOException, ParseException {
		if (swaggerVersion.equalsIgnoreCase("v1")) {
			booking.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors189dbname, ors189reqcollection);
			uaSelection.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors268dbname, ors268reqcollection);
		} else if (swaggerVersion.equalsIgnoreCase("v2")) {
			booking.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors189dbname, ors189reqcollection);
			uaSelection.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors268dbname, ors268reqcollection);
		}
		uaSelection.connectandInsertErrorResponseMongoDB(hostname, portnum, ors268dbname, ors268reqcollection);
		uaSelection.connectandInsertORSCommonresDataInMongoDB(hostname, portnum, errordb, errorcollection);
		uaSelection.connectandInsertDBdataReqDataInMongoDB(hostname, portnum, ors268dbname, ors268reqcollection);
		uaSelection.connectandInsertDBdataReqDataInMongoDB(hostname, portnum, ors189dbname, ors189reqcollection);
	}

	@Given("^Insert response mapping for wiremock for ua selection setup$")
	public void insert_response_mapping_for_wiremock_for_ua_selection_setup()
			throws FileNotFoundException, IOException, ParseException {

		uaSelection.ConnectandInsertORSResDataInMongoDB(hostname, portnum, ors268dbname, ors268servercollection);
		uaSelection.TakeORSMockDataFromMongoDB(hostname, portnum, ors268dbname, ors268servercollection);
		uaSelection.PostORSMockDataIntoWiremock(ors268callbackurl, basepath);
	}

	@Then("^RO Selection reference request data set up is completed successfully for ua selection setup$")
	public void ro_Selection_reference_request_data_set_up_is_completed_successfully_for_ua_selection_setup() {
		System.out.println(
				"RO Selection reference request data set up is completed successfully for ua selection setup..");

	}

}
