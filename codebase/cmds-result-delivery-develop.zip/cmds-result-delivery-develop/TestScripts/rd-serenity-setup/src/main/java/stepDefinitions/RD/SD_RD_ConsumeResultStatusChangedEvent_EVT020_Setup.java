package stepDefinitions.RD;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.json.simple.parser.ParseException;

import common.CommonModules;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import stepImplementations.RD.SI_RD_ConsumeResultStatusChangedEvent_EVT020_Setup;

public class SD_RD_ConsumeResultStatusChangedEvent_EVT020_Setup extends CommonModules {

	public static String evt20dbname = "";
	public static String evt20reqcollection = "";
	public static String evt20servercollection = "";
	public static String evt20baseurl = "";
	public static String evt20basepath = "";
	public static String RD_AsyncDB;
	public static String RD_AsyncCollection;
	public static CommonModules common = new CommonModules();
	public String swaggerVersion = System.getenv("SWAGGER_VERSION");	

	static SI_RD_ConsumeResultStatusChangedEvent_EVT020_Setup stepImp = new SI_RD_ConsumeResultStatusChangedEvent_EVT020_Setup();

	@Given("^Clean the Mongo database for new data setup for ResultStatusChanged event consumption$")
	public void clean_the_Mongo_database_for_new_data_setup_for_ResultStatusChanged_event_consumption() throws IOException {
		common.getEnvironmentConfigurationsOpen();
		hostname = common.getEnvironmentConfigurations("common.hostname");
		portnum = Integer.parseInt(common.getEnvironmentConfigurations("common.portnum"));

		errordb = common.getEnvironmentConfigurations("common.errordb");
		errorcollection = common.getEnvironmentConfigurations("common.errorcollection");

		RD_AsyncCollection = common.getEnvironmentConfigurations("common.RD.AsyncCollection");
		RD_AsyncDB = common.getEnvironmentConfigurations("common.RD.AsyncDBname");

		evt20dbname = common.getEnvironmentConfigurations("ResultStatusChanged.dbname");
		evt20reqcollection = common.getEnvironmentConfigurations("ResultStatusChanged.reqcollection");
		evt20servercollection = common.getEnvironmentConfigurations("ResultStatusChanged.servercollection");
		evt20baseurl = common.getEnvironmentConfigurations("ResultStatusChanged.baseurl");
		evt20basepath = common.getEnvironmentConfigurations("common.path");

		stepImp.cleanDatebaseModule(hostname, portnum, evt20dbname, evt20reqcollection);
		stepImp.cleanDatebaseModule(hostname, portnum, errordb, errorcollection);
		stepImp.cleanDatebaseModule(hostname, portnum, evt20dbname, evt20servercollection);
		common.cleanAsyncDBCollection(hostname, portnum, RD_AsyncDB, RD_AsyncCollection);
	}

	@Then("^Insert the request and responses to mongodb for ResultStatusChanged event consumption$")
	public void insert_the_request_and_responses_to_mongodb_for_ResultStatusChanged_event_consumption()
			throws IOException, ParseException {
		if (swaggerVersion.equalsIgnoreCase("v1")) {
		} else if (swaggerVersion.equalsIgnoreCase("v2")) {
			stepImp.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, evt20dbname, evt20reqcollection);
		}
		stepImp.connectandInsertORSCommonresDataInMongoDB(hostname, portnum, errordb, errorcollection);
		stepImp.connectandInsertDBdataReqDataInMongoDB(hostname, portnum, evt20dbname, evt20reqcollection);
	
	}

	@Then("^Setup the Server responses in the Mock server for the ResultStatusChanged event consumption Flow$")
	public void setup_the_Server_responses_in_Mock_server_for_ResultStatusChanged_event_consumption()
			throws FileNotFoundException, IOException, ParseException {
		stepImp.ConnectandInsertORSResDataInMongoDB(hostname, portnum, evt20dbname, evt20servercollection);
		stepImp.TakeORSMockDataFromMongoDB(hostname, portnum, evt20dbname, evt20servercollection);
		stepImp.PostORSMockDataIntoWiremock(evt20baseurl, evt20basepath);
	}

	@Then("^Test data setup completed sucessfully for ResultStatusChanged event consumption$")
	public void test_data_setup_completed_sucessfully_for_ResultStatusChanged_event_consumption() {
		System.out.println("Test data set up is completed successfully");
	}

}
