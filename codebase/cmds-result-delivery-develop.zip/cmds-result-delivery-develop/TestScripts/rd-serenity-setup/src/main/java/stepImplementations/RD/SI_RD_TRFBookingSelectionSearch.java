package stepImplementations.RD;

import static io.restassured.RestAssured.given;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import common.dbabstraction.CMDSMongoClientAdapter;
import com.mongodb.util.JSON;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class SI_RD_TRFBookingSelectionSearch {
	public String testdataPath = System.getenv("TEST_SETUP_FILE_PATH");
	public String var0 = testdataPath;
	int counter1 = 0;
	int cnt = 0;
	int counter = 0;
	int count = 0;
	int totalindex = 0;
	String str = "";
	String postbody = "";
	String inputjson[] = new String[25];
	int removehead = 51;

	public void cleanDatebaseModule(String hostname, Integer portnum, String dbname, String collname) {
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostname, portnum)) {
			DB db = mongoclient.getDB(dbname);
			System.out.println("Mondb connected");
			DBCollection coll = db.getCollection(collname);
			coll.remove(new BasicDBObject());
		}

	}
	
	public void connectandInsertDBdataReqDataInMongoDB(String arg1, Integer arg2, String arg3, String arg4)
			throws IOException, ParseException {

		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(arg1, arg2)) {
			DB db = mongoclient.getDB(arg3);
			DBCollection collstr = db.getCollection(arg4);
			String var1 = "/RDDB_testdata/ReferenceRequest";
			String var3 = ".json";
			int cntx = 1;
			while (counter < 1) {
				int var2 = cntx;
				String pathstr = var0 + var1 + var2 + var3;
				JSONParser parser = new JSONParser();
				Object obj = parser.parse(new FileReader(pathstr));
				JSONObject jsonObject = (JSONObject) obj;
				System.out.println("Json : " + jsonObject);
				DBObject object = (DBObject) JSON.parse(jsonObject.toString());
				collstr.insert(object);
				counter++;
				cntx++;
			}
		}
	}

	public void connectandInsertORSReqDataInMongoDB(String arg1, Integer arg2, String arg3, String arg4)
			throws IOException, ParseException {

		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(arg1, arg2)) {
			DB db = mongoclient.getDB(arg3);
			DBCollection collstr = db.getCollection(arg4);
			String var1 = "/RDBookingSelectionSearch/ReferenceRequest";
			String var3 = ".json";
			int cntx = 1;
			while (counter < 3) {
				int var2 = cntx;
				String pathstr = var0 + var1 + var2 + var3;
				JSONParser parser = new JSONParser();
				Object obj = parser.parse(new FileReader(pathstr));
				JSONObject jsonObject = (JSONObject) obj;
				System.out.println("Json : " + jsonObject);
				DBObject object = (DBObject) JSON.parse(jsonObject.toString());
				collstr.insert(object);
				counter++;
				cntx++;
			}
		}

	}

	public void connectandInsertErrorResponseMongoDB(String arg1, Integer arg2, String arg3, String arg4)
			throws IOException, ParseException {
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(arg1, arg2)) {
			DB db = mongoclient.getDB(arg3);
			DBCollection collstr = db.getCollection(arg4);
			String var1 = "/RDErrorCodeList/errorCode_ResultDelivery.json";
			String pathstr = var0 + var1;
			JSONParser parser = new JSONParser();
			Object obj = parser.parse(new FileReader(pathstr));
			JSONObject jsonObject = (JSONObject) obj;
			System.out.println("Json : " + jsonObject);
			DBObject object = (DBObject) JSON.parse(jsonObject.toString());
			collstr.insert(object);

		}
	}

	public void ConnectandInsertORSResDataInMongoDB(String arg1, Integer arg2, String arg3, String arg4)
			throws FileNotFoundException, IOException, ParseException {
		CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(arg1, arg2);
		DB db = mongoclient.getDB(arg3);
		System.out.println("Mondb connected");
		DBCollection collstr = db.getCollection(arg4);
		String var1 = "/RDCommonMappings/ReferenceResponse";
		String var3 = ".json";
		int cntx = 1;
		counter = 0;
		while (counter < 11) {
			int var2 = cntx;
			String pathstr = var0 + var1 + var2 + var3;
			System.out.println("pathstr :" + pathstr);
			JSONParser parser = new JSONParser();
			Object obj = parser.parse(new FileReader(pathstr));
			JSONObject jsonObject = (JSONObject) obj;
			System.out.println("Json : " + jsonObject);
			DBObject object = (DBObject) JSON.parse(jsonObject.toString());
			collstr.insert(object);
			counter++;
			cntx++;
		}
	}

	public void connectandInsertORSCommonresDataInMongoDB(String arg1, Integer arg2, String arg3, String arg4) {
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(arg1, arg2)) {
			DB db = mongoclient.getDB(arg3);
			System.out.println("Mondb connected");
			DBCollection collstr = db.getCollection(arg4);
			String Var1 = "/commonerrorcodes/CommonResponse";
			String Var3 = ".json";
			int cntl = 1;
			while (counter1 < 5) {
				int Var2 = cntl;
				String pathstr = var0 + Var1 + Var2 + Var3;
				System.out.println("pathstr :" + pathstr);
				JSONParser parser = new JSONParser();
				Object obj = parser.parse(new FileReader(pathstr));
				JSONObject jsonObject = (JSONObject) obj;
				System.out.println("Json : " + jsonObject);
				DBObject object = (DBObject) JSON.parse(jsonObject.toString());
				collstr.insert(object);
				counter1++;
				cntl++;
			}
		} catch (IOException | ParseException e) {
			e.printStackTrace();
		}
	}

	public void TakeORSMockDataFromMongoDB(String hostname, Integer portnum, String dbname, String collectionname) {
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostname, portnum)) {
			DB db = mongoclient.getDB(dbname);
			DBCollection coll = db.getCollection(collectionname);
			DBCursor cursor = coll.find();
			int i = 0;
			while (cursor.hasNext()) {

				DBObject result = cursor.next();
				str = new String(String.valueOf(result));
				Integer length = str.length();
				String subpostbody = str.substring(removehead, length);
				postbody = "{" + subpostbody;
				inputjson[i] = postbody;
				i++;
				totalindex = i;
			}
		}
	}

	public void PostORSMockDataIntoWiremock(String orsCallbackurl, String mockpath) {

		while (count < totalindex) {
			postbody = inputjson[count];
			RestAssured.baseURI = orsCallbackurl;
			System.out.println("path is:" + orsCallbackurl);
			RestAssured.basePath = "";
			Response response = given().contentType(ContentType.TEXT).log().all().body(postbody).post(mockpath);
			response.prettyPrint();
			count++;
		}
	}

}