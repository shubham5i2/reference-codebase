package stepImplementations.RD;

import static org.junit.Assert.assertEquals;

import java.nio.charset.Charset;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

import org.json.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Assert;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import common.dbabstraction.CMDSMongoClientAdapter;
import com.mongodb.util.JSON;

import common.CommonModules;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.rest.SerenityRest;

public class SI_RD_BookingCreatedConsumptionForSelectionSetup extends CommonModules {
	static String postbody = "";
	static boolean validationFail1 = true;
	static Response response = null;
	static String expectedTransactionID = "";
	static String expectedBookingUuid = "";
	public static String responseFromPOSTCall = null;
	String curlybraces = "{";
	int removeHead = 51;
	String strVal = "";
	int actResponseCode;
	String actResponse = "";
	int actualResponselen;
	int resPONSECODE202 = 202;
	int resPONSECODE400 = 400;
	int resPONSECODE401 = 401;
	int resPONSECODE403 = 403;
	int expectedTranLength202 = 56;
	int expectedTranLength400 = 35;
	static String valueInJsonFile;
	String intValue;
	static ArrayList<String> bookingLineUuid = new ArrayList<>();
	static ArrayList<String> externalBookingLineUuid = new ArrayList<>();
	String neweventdatetime;

	public static String expectedbookingUuid = "";
	public static String expectedexternalBookingUuid = "";
	public static String expectedexternalBookingReference = "";
	public static String expectedpartnerCode = "";
	public static String expectedlocationUuid = "";
	public static String expectedproductUuid = "";
	public static String expectedtestDate = "";
	public static String expectedbookingStatus = "";
	public static String expectedbookingDetailStatus = "";
	public static String expectedtestTaker_bannedStatus = "";
	public static String expectedtestTaker_uniqueTestTakerUuid = "";
	public static String expectedtestTaker_uniqueTestTakerId = "";
	public static String expectedtestTaker_shortCandidateNumber = "";
	public static String expectedtestTaker_compositeCandidateNumber = "";
	public static String expectedtestTaker_testPlatformUsername = "";
	public static String expectedtestTaker_testPlatformPassword = "";
	public static String expectedtestTaker_sebPassword = "";
	public static String expectedtestPlatformReady = "";
	public static String expectedtestTaker_externalUniqueTestTakerUuid = "";
	public static String expectedtestTaker_identityVerificationStatus = "";
	public static String expectedtestTaker_firstName = "";
	public static String expectedtestTaker_lastName = "";
	public static String expectedtestTaker_birthDate = "";
	public static String expectedtestTaker_email = "";
	public static String expectedtestTaker_languageUuid = "";
	public static String expectedbookingLines_bookingLineUuid = "";
	public static String expectedbookingLines_externalBookingLineUuid = "";
	public static String expectedbookingLines_startDateTime = "";
	public static String expectedbookingLines_startTimeLocal = "";
	public static String expectedbookingLines_productUuid = "";
	public static String expectedbookingLines_bookingLineStatus = "";

	public static String actual_bookingUuid = "";
	public static String actual_externalBookingUuid = "";
	public static String actual_productUuid = "";
	public static String actual_bookingStatus = "";
	public static String actual_testDate = "";
	boolean allFields = true;
	boolean minimumFields = true;
	JSONArray arrayExpected;
	JSONArray arrayActual;

	ArrayList<String> requestFields = new ArrayList<>(Arrays.asList("eventBody_bookingUuid",
			"eventBody_externalBookingUuid", "eventBody_externalBookingReference", "eventBody_partnerCode",
			"eventBody_locationUuid", "eventBody_productUuid", "eventBody_testDate", "eventBody_bookingStatus",
			"eventBody_bookingDetailStatus", "eventBody_testTaker_bannedStatus",
			"eventBody_testTaker_uniqueTestTakerUuid", "eventBody_testTaker_uniqueTestTakerId",
			"eventBody_testTaker_shortCandidateNumber", "eventBody_testTaker_compositeCandidateNumber",
			"eventBody_testTaker_testPlatformUsername", "eventBody_testTaker_testPlatformPassword",
			"eventBody_testTaker_sebPassword", "eventBody_testPlatformReady",
			"eventBody_testTaker_externalUniqueTestTakerUuid", "eventBody_testTaker_identityVerificationStatus",
			"eventBody_testTaker_firstName", "eventBody_testTaker_lastName", "eventBody_testTaker_birthDate",
			"eventBody_testTaker_email", "eventBody_testTaker_languageUuid", "eventBody_testTaker_notes",
			"eventBody_testTaker_address_addressLine1", "eventBody_testTaker_address_stateTerritoryUuid",
			"eventBody_testTaker_address_countryIso3Code", "eventBody_marketingInfo_yearsOfStudy",
			"eventBody_marketingInfo_educationLevelUuid", "eventBody_marketingInfo_currentEnglishStudyPlace",
			"eventBody_consentGiven", "eventBody_agentName"));

	static ArrayList<String> bookingLines = new ArrayList<>(
			Arrays.asList("bookingLineUuid", "externalBookingLineUuid", "bookingLineStatus", "productUuid"));

	/************************************************************************
	 * Function Name: getInputRequestBodyUsingTransactionId Function Description: To
	 * get the required request body from MongoDB id and fetch the expected values
	 * 
	 * @throws InterruptedException
	 *************************************************************************/
	public String acceptanceCriteria;

	@SuppressWarnings("deprecation")
	public String getInputRequestBodyUsingTransactionId(String hostName, Integer portNum, String dbName,
			String requestCollectionName, String transactionId) throws InterruptedException {

		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostName, portNum);) {
			DB db = mongoclient.getDB(dbName);
			DBCollection coll = db.getCollection(requestCollectionName);
			DBObject query = new BasicDBObject("eventHeader.transactionId", new BasicDBObject("$eq", transactionId));
			DBObject result = coll.findOne(query);
			String str = String.valueOf(result);
			Integer length = str.length();
			String subpostbody = str.substring(removeHead, length);
			String postbodyRaw = curlybraces + subpostbody;
			expectedTransactionID = CommonModules.randomUUID();
			postbody = postbodyRaw.replaceAll(transactionId, expectedTransactionID);
			System.out.println("Request Body: " + postbody);
			return postbody;

		}
	}

	Random random = new Random();

	@SuppressWarnings("deprecation")
	public String getInputRequestBodyForUpdatedScenarios(String hostName, Integer portNum, String dbName,
			String requestCollectionName, String transactionId) throws InterruptedException, ParseException {
		acceptanceCriteria = transactionId;
		try (CMDSMongoClientAdapter mongoclient = new CMDSMongoClientAdapter(hostName, portNum);) {
			DB db = mongoclient.getDB(dbName);
			DBCollection coll = db.getCollection(requestCollectionName);
			DBObject query = new BasicDBObject("eventHeader.transactionId", new BasicDBObject("$eq", transactionId));
			DBObject result = coll.findOne(query);
			String str = String.valueOf(result);
			Integer length = str.length();
			String subpostbody = str.substring(removeHead, length);
			String postbodyRaw = curlybraces + subpostbody;
			expectedTransactionID = CommonModules.randomUUID();
			postbody = postbodyRaw.replaceAll(transactionId, expectedTransactionID);
			int num1 = random.nextInt(581748);
			String formatted1 = String.format("%06d", num1);
			String newS = formatted1;

			String locationUuid = getLocationUuidInRequest();
			String testDate = getTestDateInRequest();
			String correlationid = getCorrelationIdInRequest();
			String eventdatetime = geteventDateTimeInRequest();
			String bookingUuid = getbookingUuidInRequest();
			String externalbookingUuid = getexternalbookingUuidInRequest();
			String transactionid = getTransactionIdInRequest();
			String identityNumber = getIdentityNumberInRequest();
			String externalBookingReference = getexternalbookingReferenceInRequest();
			verifyFieldValueInRequest(requestFields.get(12));
			expectedtestTaker_shortCandidateNumber = valueInJsonFile;

			String newcorrelationid = CommonModules.randomUUID();
			expectedTransactionID = CommonModules.randomUUID();
			String newbookingUuid = CommonModules.randomUUID();
			String newexternalbookingUuid = CommonModules.randomUUID();
			String newlocationUuid = CommonModules.randomUUID();
			String newIdentityNumber = generateRandomString(7);

			LocalDateTime currenttimestamp = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			String neweventdatetime = currenttimestamp.format(formatter).toString();

			LocalDate localDate = LocalDate.now();
			String NextDate = localDate.plusDays(1).toString();

			Random random = new Random();
			int num = random.nextInt(100000);
			String formatted = String.format("%05d", num);
			String newExternalBookingReference = formatted;

			ArrayList<String> bookinglineUuidList = getExpectedBookingLineUuidinBookingLinesRequest();

			postbody = postbody.replaceAll(correlationid, newcorrelationid);
			postbody = postbody.replaceAll(transactionid, expectedTransactionID);
			postbody = postbody.replaceAll(eventdatetime, neweventdatetime);
			// postbody = postbody.replaceAll(locationUuid,newlocationUuid);
			postbody = postbody.replaceAll(bookingUuid, newbookingUuid);
			postbody = postbody.replaceAll(externalbookingUuid, newexternalbookingUuid);
			postbody = postbody.replaceAll(identityNumber, newIdentityNumber);
			// postbody = postbody.replaceAll(testDate,NextDate);
			postbody = postbody.replace(expectedtestTaker_shortCandidateNumber, newS);
			for (int i = 0; i < bookinglineUuidList.size(); i++) {

				String bookinglineUuid = bookinglineUuidList.get(i).toString();
				String newbookinglineUuid = CommonModules.randomUUID();
				postbody = postbody.replaceAll(bookinglineUuid, newbookinglineUuid);
			}

			/*
			 * try (CMDSMongoClientAdapter mongoclient1 = new CMDSMongoClientAdapter(hostName, portNum)) { DB db1
			 * = mongoclient1.getDB(dbName); DBCollection collstr =
			 * db1.getCollection(requestCollectionName); DBObject object = (DBObject)
			 * JSON.parse(postbody.toString()); collstr.insert(object); }catch(Exception e)
			 * { System.out.println("Error"); }
			 */
		} catch (Exception e) {
			System.out.println("Error");
		}

		return postbody;
	}

	public String generateRandomString(int n) {
		// length is bounded by 256 Character
		byte[] array = new byte[256];
		new Random().nextBytes(array);

		String randomString = new String(array, Charset.forName("UTF-8"));

		// Create a StringBuffer to store the result
		StringBuffer r = new StringBuffer();

		// Append first n alphanumeric characters
		// from the generated random String into the result
		for (int k = 0; k < randomString.length(); k++) {

			char ch = randomString.charAt(k);

			if (((ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9')) && (n > 0)) {

				r.append(ch);
				n--;
			}
		}

		// return the resultant string
		return r.toString();

	}

	public void insertRecord(String hostName, Integer portNum, String dbName, String requestCollectionName)
			throws ParseException {
		verifyFieldValueInRequest("eventHeader_eventName");
		eventName = valueInJsonFile;
		postbody = postbody.replace(eventName, eventName + "_" + acceptanceCriteria);
		try (CMDSMongoClientAdapter mongoclient1 = new CMDSMongoClientAdapter(hostName, portNum)) {
			DB db1 = mongoclient1.getDB(dbName);
			DBCollection collstr = db1.getCollection(requestCollectionName);
			DBObject object = (DBObject) JSON.parse(postbody.toString());
			collstr.insert(object);
		} catch (Exception e) {
			System.out.println("Error");
		}
	}

	public String constructNewpostbodywithNewLocation() throws org.json.simple.parser.ParseException {

		String locationUuid = getLocationUuidInRequest();
		String testDate = getTestDateInRequest();
		String correlationid = getCorrelationIdInRequest();
		String eventdatetime = geteventDateTimeInRequest();
		String bookingUuid = getbookingUuidInRequest();
		String externalbookingUuid = getexternalbookingUuidInRequest();
		String transactionid = getTransactionIdInRequest();
		String externalBookingReference = getexternalbookingReferenceInRequest();

		String newcorrelationid = CommonModules.randomUUID();
		expectedTransactionID = CommonModules.randomUUID();
		String newbookingUuid = CommonModules.randomUUID();
		String newexternalbookingUuid = CommonModules.randomUUID();
		String newlocationUuid = CommonModules.randomUUID();

		LocalDateTime currenttimestamp = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		String neweventdatetime = currenttimestamp.format(formatter).toString();

		// LocalDate localDate = LocalDate.now();
		// String NextDate = localDate.plusDays(1).toString();

		Random random = new Random();
		int num = random.nextInt(100000);
		String formatted = String.format("%05d", num);
		String newExternalBookingReference = formatted;

		ArrayList<String> bookinglineUuidList = getExpectedBookingLineUuidinBookingLinesRequest();

		postbody = postbody.replaceAll(correlationid, newcorrelationid);
		postbody = postbody.replaceAll(transactionid, expectedTransactionID);
		postbody = postbody.replaceAll(eventdatetime, neweventdatetime);
		postbody = postbody.replaceAll(locationUuid, newlocationUuid);
		postbody = postbody.replaceAll(bookingUuid, newbookingUuid);
		postbody = postbody.replaceAll(externalbookingUuid, newexternalbookingUuid);
		postbody = postbody.replaceAll(externalBookingReference, newExternalBookingReference);
		// postbody = postbody.replaceAll(testDate,NextDate);

		for (int i = 0; i < bookinglineUuidList.size(); i++) {

			String bookinglineUuid = bookinglineUuidList.get(i).toString();
			String newbookinglineUuid = CommonModules.randomUUID();
			postbody = postbody.replaceAll(bookinglineUuid, newbookinglineUuid);

		}
		System.out.println("New BookingCreated event with new location: " + postbody);
		return postbody;

	}

	public String constructNewpostbodywithNewEventDateTimeForUpdateBooking(String eventDateTimeFlag)
			throws org.json.simple.parser.ParseException {
		String correlationid = getCorrelationIdInRequest();
		String eventdatetime = geteventDateTimeInRequest();
		String transactionid = getTransactionIdInRequest();
		String eventName = getEventNameInRequest();

		String newcorrelationid = CommonModules.randomUUID();
		expectedTransactionID = CommonModules.randomUUID();

		if (eventDateTimeFlag.equalsIgnoreCase("future")) {
			LocalDateTime currenttimestamp = LocalDateTime.now();
			currenttimestamp = currenttimestamp.plusDays(1);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			neweventdatetime = currenttimestamp.format(formatter).toString();
		} else if (eventDateTimeFlag.equalsIgnoreCase("past")) {
			LocalDateTime currenttimestamp = LocalDateTime.now();
			currenttimestamp = currenttimestamp.minusDays(5).minusMonths(1);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			neweventdatetime = currenttimestamp.format(formatter).toString();
		}

		postbody = postbody.replaceAll(correlationid, newcorrelationid);
		postbody = postbody.replaceAll(transactionid, expectedTransactionID);
		postbody = postbody.replaceAll(eventdatetime, neweventdatetime);
		postbody = postbody.replaceAll(eventName, "BookingUpdated");

		return postbody;

	}

	/************************************************************************
	 * Function Name: postRequest Function Description: To post request body with
	 * headers to API endpoint
	 *************************************************************************/
	public Response postRequest(String actUrl, String actPath, String destination, String envKey, String accessToken) {
		RestAssured.baseURI = actUrl;
		response = SerenityRest.given()
				.headers("envKey", envKey, "destination", destination, "Authorization", "Bearer " + accessToken)
				.contentType(ContentType.JSON).log().all().body(postbody).post(actPath);
		return response;
	}

	/************************************************************************
	 * Function Name: verifyResponse Function Description: To validate the response
	 * code
	 *************************************************************************/
	public void verifyResponse() {

		actResponseCode = response.getStatusCode();
		actResponse = response.asString();

		if (actResponseCode == resPONSECODE202) {
			assertEquals(actResponseCode, resPONSECODE202);
			System.out.println("ResponseCode: " + actResponseCode);
			System.out.println("Response: " + actResponse);
		} else {
			assertEquals(actResponseCode, resPONSECODE400);
		}
	}

	/************************************************************************
	 * Function Name: verifyResponseStatusCode Function Description: To validate the
	 * response code
	 *************************************************************************/
	public void verifyResponseStatusCode(int expstatusCode) {

		actResponseCode = response.getStatusCode();
		actResponse = response.asString();

		if (actResponseCode == expstatusCode) {
			assertEquals(actResponseCode, expstatusCode);
			System.out.println("ResponseCode: " + actResponseCode);
			System.out.println("Response: " + actResponse);
		} else {
			assertEquals(actResponseCode, resPONSECODE400);
		}
	}

	public static String eventName;

	public void getJsonFeildValuesfromRequestbody() throws ParseException {

		verifyFieldValueInRequest(requestFields.get(0));
		expectedbookingUuid = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(1));
		expectedexternalBookingUuid = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(2));
		expectedexternalBookingReference = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(3));
		expectedpartnerCode = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(4));
		expectedlocationUuid = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(5));
		expectedproductUuid = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(6));
		expectedtestDate = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(7));
		expectedbookingStatus = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(8));
		expectedbookingDetailStatus = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(9));
		expectedtestTaker_bannedStatus = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(10));
		expectedtestTaker_uniqueTestTakerUuid = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(11));
		expectedtestTaker_uniqueTestTakerId = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(12));
		expectedtestTaker_shortCandidateNumber = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(13));
		expectedtestTaker_compositeCandidateNumber = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(14));
		expectedtestTaker_testPlatformUsername = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(15));
		expectedtestTaker_testPlatformPassword = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(16));
		expectedtestTaker_sebPassword = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(17));
		expectedtestPlatformReady = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(18));
		expectedtestTaker_externalUniqueTestTakerUuid = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(19));
		expectedtestTaker_identityVerificationStatus = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(20));
		expectedtestTaker_firstName = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(21));
		expectedtestTaker_lastName = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(22));
		expectedtestTaker_birthDate = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(23));
		expectedtestTaker_email = valueInJsonFile;

		verifyFieldValueInRequest(requestFields.get(24));
		expectedtestTaker_languageUuid = valueInJsonFile;

	}

	public static Boolean verifyFieldValueInRequest(String fieldValue) throws ParseException {
		JSONParser parser = new JSONParser();
		JSONObject json = (JSONObject) parser.parse(postbody);
		try {
			ArrayList<String> json1 = new ArrayList<>();
			if (fieldValue.contains("_")) {
				String[] values = fieldValue.split("_");
				for (int i = 0; i < values.length; i++) {
					json1.add(values[i]);
				}
				for (int i = 0; i < values.length - 1; i++) {
					String counter = json1.get(i);
					valueInJsonFile = json.get(counter).toString();
					// valueInJsonFile = valueInJsonFile.replace("[{", "{").replace("}]", "}");
					json = (JSONObject) parser.parse(valueInJsonFile);
				}
				try {
					String counter = json1.get(json1.size() - 1);
					valueInJsonFile = (String) json.get(counter);
				} catch (ClassCastException e) {
					String counter = json1.get(json1.size() - 1);
					valueInJsonFile = String.valueOf(json.get(counter));
				}

			} else {
				valueInJsonFile = json.get(fieldValue).toString();
			}
			if (valueInJsonFile == null || valueInJsonFile.equalsIgnoreCase("")) {
				Serenity.recordReportData().asEvidence().withTitle("Field or Field value is not provided : ")
						.andContents(fieldValue);
				validationFail1 = false;

			} else {
				validationFail1 = true;
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return validationFail1;
	}

	public static String retriveValueFromResponseJson(String fieldValue) throws ParseException {
		JSONParser parser = new JSONParser();
		JSONObject valueInJsonFile1;
		String valueInJsonFile2 = null;
		JSONObject json = (JSONObject) parser.parse(responseFromPOSTCall);
		if (fieldValue.contains("_")) {
			String[] values = fieldValue.split("_");
			try {
				JSONArray array = (JSONArray) json.get(values[0]);
				String valuesUpdate = array.toString().replace("[", "").replace("]", "");
				JSONObject filedList = (JSONObject) parser.parse(valuesUpdate);
				valueInJsonFile2 = filedList.get(values[1]).toString();
				if (values.length > 2) {
					valueInJsonFile1 = (JSONObject) parser.parse(valueInJsonFile2);
					valueInJsonFile2 = valueInJsonFile1.get(values[2]).toString();
				}
			} catch (ClassCastException e) {
				// JSONObject object = (JSONObject) json.get(values[0]);
				String eventBody = (String) json.get(values[0]);
				JSONObject object = (JSONObject) parser.parse(eventBody);
				valueInJsonFile2 = object.get(values[1]).toString();
				if (values.length > 2) {
					valueInJsonFile1 = (JSONObject) parser.parse(valueInJsonFile2);
					valueInJsonFile2 = valueInJsonFile1.get(values[2]).toString();
					if (values.length > 3) {
						if (valueInJsonFile2.startsWith("[")) {
							String temp = (String) valueInJsonFile1.get(values[2]).toString();
							JSONArray array2 = new JSONArray(temp);
							String valuesUpdate = array2.toString().replace("[", "").replace("]", "");
							JSONObject filedList = (JSONObject) parser.parse(valuesUpdate);
							valueInJsonFile2 = filedList.get(values[3]).toString();
						} else {
							valueInJsonFile1 = (JSONObject) parser.parse(valueInJsonFile2);
							valueInJsonFile2 = valueInJsonFile1.get(values[3]).toString();
						}
						if (values.length > 4) {
							if (valueInJsonFile2.startsWith("[")) {
								String temp1 = (String) valueInJsonFile1.get(values[3]).toString();
								JSONArray array3 = new JSONArray(temp1);
								String valuesUpdate2 = array3.toString().replace("[", "").replace("]", "");
								JSONObject filedList2 = (JSONObject) parser.parse(valuesUpdate2);
								valueInJsonFile2 = filedList2.get(values[4]).toString();
							} else {
								valueInJsonFile1 = (JSONObject) parser.parse(valueInJsonFile2);
								valueInJsonFile2 = valueInJsonFile1.get(values[4]).toString();
							}

						}
					}
				}
			}
		} else {
			valueInJsonFile2 = (String) json.get(fieldValue);
		}

		return valueInJsonFile2;
	}

	public void validatePublishedMessage() throws org.json.simple.parser.ParseException {

		JSONParser jsonParser = new JSONParser();
		System.out.println("Response" + responseFromPOSTCall);
		JSONObject jsonObject = (JSONObject) jsonParser.parse(responseFromPOSTCall);
		String eventBody = (String) jsonObject.get("eventBody");
		JSONObject EventBody = (JSONObject) jsonParser.parse(eventBody);
		System.out.println("Event Body = " + EventBody);
		assert EventBody != null;
		actual_bookingUuid = retriveValueFromResponseJson("eventBody_bookingUuid");
		Assert.assertEquals(expectedbookingUuid, actual_bookingUuid);

		actual_testDate = retriveValueFromResponseJson("eventBody_testDate");
		Assert.assertEquals(expectedtestDate, actual_testDate);

		actual_externalBookingUuid = retriveValueFromResponseJson("eventBody_externalBookingUuid");
		Assert.assertEquals(expectedexternalBookingUuid, actual_externalBookingUuid);

		actual_productUuid = retriveValueFromResponseJson("eventBody_productUuid");
		Assert.assertEquals(expectedproductUuid, actual_productUuid);

		actual_bookingStatus = retriveValueFromResponseJson("eventBody_bookingStatus");
		Assert.assertEquals(expectedbookingStatus, actual_bookingStatus);

	}

	public String getTestDateInRequest() throws ParseException {
		verifyFieldValueInRequest("eventBody_testDate");
		return valueInJsonFile;
	}

	public String getbookingUuidInRequest() throws ParseException {
		verifyFieldValueInRequest("eventBody_bookingUuid");
		return valueInJsonFile;
	}

	public String getexternalbookingUuidInRequest() throws ParseException {
		verifyFieldValueInRequest("eventBody_externalBookingUuid");
		return valueInJsonFile;
	}

	public String getexternalbookingReferenceInRequest() throws ParseException {
		verifyFieldValueInRequest("eventBody_externalBookingReference");
		return valueInJsonFile;
	}

	public String getLocationUuidInRequest() throws ParseException {
		verifyFieldValueInRequest("eventBody_locationUuid");
		return valueInJsonFile;
	}

	public String getCorrelationIdInRequest() throws ParseException {
		verifyFieldValueInRequest("eventHeader_correlationId");
		return valueInJsonFile;
	}

	public String getTransactionIdInRequest() throws ParseException {
		verifyFieldValueInRequest("eventHeader_transactionId");
		return valueInJsonFile;
	}

	public String getEventNameInRequest() throws ParseException {
		verifyFieldValueInRequest("eventHeader_eventName");
		return valueInJsonFile;
	}

	public String geteventDateTimeInRequest() throws ParseException {
		verifyFieldValueInRequest("eventHeader_eventDateTime");
		return valueInJsonFile;
	}

	public String getIdentityNumberInRequest() throws ParseException {
		verifyFieldValueInRequest("eventBody_testTaker_identityNumber");
		return valueInJsonFile;
	}

	public void getExpectedValuesFromBookingLines() throws ParseException {
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(postbody);
		JSONObject jsonObject = (JSONObject) obj;
		Object EventBody = jsonObject.get("eventBody");
		String eventBody = EventBody.toString();
		Object obj1 = parser.parse(eventBody);
		JSONObject jsonObject1 = (JSONObject) obj1;
		String jsonResponse1 = jsonObject1.get("bookingLines").toString();
		arrayExpected = new JSONArray(jsonResponse1);
	}

	public void getActualValuesFromBookingLines() throws ParseException {
		JSONParser jsonParser = new JSONParser();
		System.out.println("Response" + responseFromPOSTCall);
		JSONObject jsonObject = (JSONObject) jsonParser.parse(responseFromPOSTCall);
		String eventBody = (String) jsonObject.get("eventBody");
		JSONObject EventBody = (JSONObject) jsonParser.parse(eventBody);
		String jsonResponse1 = EventBody.get("bookingLines").toString();
		arrayActual = new JSONArray(jsonResponse1);
	}

	public static ArrayList<String> expectedBookingLineUuidList = new ArrayList<String>();

	public ArrayList<String> getExpectedBookingLineUuidinBookingLinesRequest() throws ParseException {
		getExpectedValuesFromBookingLines();
		String bookingLineUuid = null;
		boolean containNull = true;
		expectedBookingLineUuidList.clear();
		for (int i = 0; i < arrayExpected.length(); i++) {
			org.json.JSONObject innerJsonObject = arrayExpected.getJSONObject(i);
			bookingLineUuid = (String) innerJsonObject.optString("bookingLineUuid");
			expectedBookingLineUuidList.add(bookingLineUuid);
			if (bookingLineUuid == null || bookingLineUuid.isEmpty()) {
				containNull = false;
			}
		}
		return expectedBookingLineUuidList;
	}

	public static ArrayList<String> expectedProductUuidList = new ArrayList<String>();

	public ArrayList<String> getExpectedProductUuidinBookingLinesRequest() throws ParseException {
		getExpectedValuesFromBookingLines();
		String productUuid = null;
		boolean containNull = true;
		expectedProductUuidList.clear();
		for (int i = 0; i < arrayExpected.length(); i++) {
			org.json.JSONObject innerJsonObject = arrayExpected.getJSONObject(i);
			productUuid = (String) innerJsonObject.optString("productUuid");
			expectedProductUuidList.add(productUuid);
			if (productUuid == null || productUuid.isEmpty()) {
				containNull = false;
			}
		}
		return expectedProductUuidList;
	}

	public static ArrayList<String> actualBookingLineUuidList = new ArrayList<String>();

	public ArrayList<String> getActualBookingLineUuidinChildrenEnrolmentsResponse() throws ParseException {
		getActualValuesFromBookingLines();
		String actbookingLineUuid = null;
		boolean containNull = true;

		for (int i = 0; i < arrayActual.length(); i++) {
			org.json.JSONObject innerJsonObject = arrayActual.getJSONObject(i);
			actbookingLineUuid = (String) innerJsonObject.optString("bookingLineUuid");
			actualBookingLineUuidList.add(actbookingLineUuid);
			if (actbookingLineUuid == null || actbookingLineUuid.isEmpty()) {
				containNull = false;
			}

		}
		return actualBookingLineUuidList;
	}

	public ArrayList<String> getExpectedProductUuidValueInBookingLinesRequest() throws ParseException {
		getExpectedValuesFromBookingLines();
		String productUuid = null;
		boolean containNull = true;
		ArrayList<String> expectedProductUuidlist = new ArrayList<>();
		for (int i = 0; i < arrayExpected.length(); i++) {

			org.json.JSONObject jsonObjectInner = (org.json.JSONObject) arrayExpected.get(i);
			productUuid = (String) jsonObjectInner.get("productUuid");
			expectedProductUuidlist.add(productUuid);
			if (productUuid == null || productUuid.isEmpty()) {
				containNull = false;
			}
		}
		return expectedProductUuidlist;
	}

	public ArrayList<String> getActualProductUuidinChildrenEnrolmentsResponse() throws ParseException {
		getActualValuesFromBookingLines();
		String productUuid = null;
		boolean containNull = true;
		ArrayList<String> actualProductUuidList = new ArrayList<String>();
		for (int i = 0; i < arrayActual.length(); i++) {
			org.json.JSONObject innerJsonObject = arrayActual.getJSONObject(i);
			productUuid = (String) innerJsonObject.optString("productUuid");
			actualProductUuidList.add(productUuid);
			if (productUuid == null || productUuid.isEmpty()) {
				containNull = false;
			}

		}
		return actualProductUuidList;
	}

	public void verifybookingLineUuid() throws ParseException {

		ArrayList<String> expected = getExpectedBookingLineUuidinBookingLinesRequest();
		ArrayList<String> actual = getActualBookingLineUuidinChildrenEnrolmentsResponse();
		Assert.assertTrue(actual.containsAll(expected));

	}

	public void verifyproductUuid() throws ParseException {

		ArrayList<String> expected = getExpectedProductUuidValueInBookingLinesRequest();
		ArrayList<String> actual = getActualProductUuidinChildrenEnrolmentsResponse();
		Assert.assertTrue(actual.containsAll(expected));

	}

	public void verifyErrorInPublishedMessage() throws ParseException {
		postbody = responseFromPOSTCall;
		verifyFieldValueInRequest("eventHeader_eventName");
		String actualEventName = valueInJsonFile;
		Assert.assertEquals(actualEventName, "SelectionBookingChangeFailed");

	}

	public static void connectMongoDB(String hostname, Integer portnum) throws InterruptedException, ParseException {
		String strVal;
		strVal = CommonModules.connectMongoDBandfetchAsyncResponseForRDS(hostname, portnum, expectedTransactionID);
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject = (JSONObject) jsonParser.parse(strVal);
		JSONObject jsonResponse = (JSONObject) jsonObject.get("body");
		responseFromPOSTCall = jsonResponse.toString();
		Serenity.recordReportData().withTitle("Actual Response on Topic-Out:").andContents(responseFromPOSTCall);
	}

	public void allFields() throws ParseException {
		minimumFields = false;
		for (int i = 0; i < requestFields.size(); i++) {
			allFields = verifyFieldValueInRequest(requestFields.get(i));
		}
		if (allFields) {
			Serenity.recordReportData().withTitle("All Required fields provided ");
		} else {
			Serenity.recordReportData().withTitle("All Required fields not provided ");
		}
	}

	public void verifyMandatoryFieldInBookingLines() throws ParseException {
		JSONParser jsonParser = new JSONParser();
		Boolean minimumFields = true;
		JSONObject jsonObject = (JSONObject) jsonParser.parse(responseFromPOSTCall);
		System.out.println("postbody" + responseFromPOSTCall);
		Boolean flag = true;
		String eventBody = (String) jsonObject.get("eventBody");
		JSONObject EventBody = (JSONObject) jsonParser.parse(eventBody);
		String jsonResponse1 = EventBody.get("bookingLines").toString();
		JSONArray jsonArray = new JSONArray(jsonResponse1);
		for (int i = 0; i < jsonArray.length(); i++) {
			SI_RD_ROCreatedConsumptionForSelectionSetup.postBodyreq = jsonArray.get(i).toString();
			for (int i1 = 0; i1 < bookingLines.size(); i1++) {
				minimumFields = SI_RD_ROCreatedConsumptionForSelectionSetup
						.verifyFieldValueInRequest(bookingLines.get(i1));
			}
		}
		if (minimumFields) {
			Serenity.recordReportData().withTitle("Minimum Required fields provided ");
		} else {
			Serenity.recordReportData().withTitle("Minimum Required fields not provided ");
		}
	}

	public String ActUrl = "";

	public String TakeActUrl(String Env) {

		System.out.println(Env);
		switch (Env) {
		case "sandbox":
			ActUrl = CommonModules.getEnvironmentConfigurations("int189.SandboxActurl");
			break;
		case "sandbox2":
			ActUrl = CommonModules.getEnvironmentConfigurations("int189.Sandbox2Acturl");
			break;
		case "dev":
			ActUrl = CommonModules.getEnvironmentConfigurations("int189.DevActurl");
			break;
		}
		return ActUrl;
	}

	public String EnvKeyQueue = "";

	public String TakeEnvKeyQueue(String Env) {

		System.out.println(Env);
		switch (Env) {
		case "sandbox":
			EnvKeyQueue = CommonModules.getEnvironmentConfigurations("int189.SandboxenvKeyQueue");
			break;
		case "sandbox2":
			EnvKeyQueue = CommonModules.getEnvironmentConfigurations("int189.Sandbox2envKeyQueue");
			break;
		case "dev":
			EnvKeyQueue = CommonModules.getEnvironmentConfigurations("int189.DevenvKeyQueue");
			break;
		}
		return EnvKeyQueue;
	}

	public static String authUrlForBooking = "";

	public static String takeAuthUrlForBooking(String partner) {
		String env = System.getenv("ENVIRONMENT");
		switch (env) {

		case "sandbox":
			if (partner.equalsIgnoreCase("IDP")) {
				authUrlForBooking = CommonModules.getEnvironmentConfigurations("Sandbox_IDP.AuthURL");
			} else if (partner.equalsIgnoreCase("BC")) {
				authUrlForBooking = CommonModules.getEnvironmentConfigurations("Sandbox_BC.AuthURL");
			}
			break;
		case "dev":
			if (partner.equalsIgnoreCase("IDP")) {
				authUrlForBooking = CommonModules.getEnvironmentConfigurations("Dev_IDP.AuthURL");
			} else if (partner.equalsIgnoreCase("BC")) {
				authUrlForBooking = CommonModules.getEnvironmentConfigurations("Dev_BC.AuthURL");
			}
			break;
		case "sit":
			if (partner.equalsIgnoreCase("IDP")) {
				authUrlForBooking = CommonModules.getEnvironmentConfigurations("sit_IDP.AuthURL");
			} else if (partner.equalsIgnoreCase("BC")) {
				authUrlForBooking = CommonModules.getEnvironmentConfigurations("sit_BC.AuthURL");
			}
			break;
		}
		return authUrlForBooking;
	}

	public static String authReqForBooking = "";

	public static String takeAuthReqForBooking(String partner) {
		String env = System.getenv("ENVIRONMENT");
		switch (env) {
		case "sandbox":
			if (partner.equalsIgnoreCase("IDP")) {
				authReqForBooking = CommonModules.getEnvironmentConfigurations("Sandbox_IDP.AuthReq");
			} else if (partner.equalsIgnoreCase("BC")) {
				authReqForBooking = CommonModules.getEnvironmentConfigurations("Sandbox_BC.AuthReq");
			}
			break;
		case "dev":
			if (partner.equalsIgnoreCase("IDP")) {
				authReqForBooking = CommonModules.getEnvironmentConfigurations("Dev_IDP.AuthReq");
			} else if (partner.equalsIgnoreCase("BC")) {
				authReqForBooking = CommonModules.getEnvironmentConfigurations("Dev_BC.AuthReq");
			}
			break;
		case "sit":
			if (partner.equalsIgnoreCase("IDP")) {
				authReqForBooking = CommonModules.getEnvironmentConfigurations("sit_IDP.AuthReq");
			} else if (partner.equalsIgnoreCase("BC")) {
				authReqForBooking = CommonModules.getEnvironmentConfigurations("sit_BC.AuthReq");
			}
			break;
		}
		return authReqForBooking;
	}

	public String DbUrl = "";

	public String TakeDbUrl(String Env) {

		System.out.println(Env);
		switch (Env) {
		case "sandbox":
			ActUrl = CommonModules.getEnvironmentConfigurations("cmds268.dbUrlSandbox");
			break;
		case "sandbox2":
			ActUrl = CommonModules.getEnvironmentConfigurations("cmds268.dbUrlSandbox");
			break;
		case "dev":
			ActUrl = CommonModules.getEnvironmentConfigurations("cmds268.dbUrlDev");
			break;
		}
		return ActUrl;
	}

}
