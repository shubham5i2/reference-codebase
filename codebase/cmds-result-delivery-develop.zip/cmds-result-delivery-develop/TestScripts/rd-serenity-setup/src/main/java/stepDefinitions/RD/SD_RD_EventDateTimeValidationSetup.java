package stepDefinitions.RD;

import java.io.FileNotFoundException;
import java.io.IOException;

import common.CommonModules;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import stepImplementations.RD.SI_RD_EventDateTimeValidationSetup;

public class SD_RD_EventDateTimeValidationSetup{
	public String swaggerVersion = System.getenv("SWAGGER_VERSION");
	CommonModules common = new CommonModules();
	SI_RD_EventDateTimeValidationSetup stepImp = new SI_RD_EventDateTimeValidationSetup();
	String hostname = "";
	int portnum;
	String rdEventDateTimeValidationdbname = "";
	String rdEventDateTimeValidationreqcollection = "";
	String rdEventDateTimeValidationservercollection = "";
	String errordb;
	String errorcollection;
	String RD_AsyncCollection;
	String RD_AsyncDB;
	private String ors268callbackurl;
	private String basepath;
	
	
	@Given("^Clean the Mondodb database for event date time validation$")
	public void Clean_the_Mondodb_database_for_event_date_time_validation() throws FileNotFoundException, IOException
	{
		common.getEnvironmentConfigurationsOpen();
		hostname = common.getEnvironmentConfigurations("common.hostname");
		portnum = Integer.parseInt(common.getEnvironmentConfigurations("common.portnum"));
		rdEventDateTimeValidationdbname = common.getEnvironmentConfigurations("Imod48101.dbname");
		rdEventDateTimeValidationreqcollection = common.getEnvironmentConfigurations("Imod48101.reqCollection");
		
		ors268callbackurl = common.getEnvironmentConfigurations("ors268.mockurl");
		basepath = common.getEnvironmentConfigurations("common.path");


		RD_AsyncCollection = common.getEnvironmentConfigurations("common.RD.AsyncCollection");
		RD_AsyncDB = common.getEnvironmentConfigurations("common.RD.AsyncDBname");
		stepImp.cleanDatebaseModule(hostname, portnum, rdEventDateTimeValidationdbname, rdEventDateTimeValidationreqcollection);
		stepImp.cleanDatebaseModule(hostname, portnum, rdEventDateTimeValidationdbname, RD_AsyncCollection);
		
	}
	
	@And("^Insert the request for test data setup in mongodb for event date time validation$")
	public void Insert_the_request_for_test_data_setup_in_mongodb_for_event_date_time_validation()
	{
		stepImp.v2_ConnectAndInsertRequestIntoMongoDB(hostname, portnum, rdEventDateTimeValidationdbname, rdEventDateTimeValidationreqcollection);
		stepImp.ConnectAndInsertServerFilesIntoMongoDB(hostname, portnum, rdEventDateTimeValidationdbname, RD_AsyncCollection);
	}
	
	@And("^Insert response mapping for wiremock for event date time validation$")
	public void Insert_response_mapping_for_wiremock_for_event_date_time_validation()
	{
		stepImp.fetchMockDataFromMongoDB(hostname,portnum,rdEventDateTimeValidationdbname,RD_AsyncCollection);
		stepImp.postMockDataIntoMockServer(ors268callbackurl,basepath);	
	}
}