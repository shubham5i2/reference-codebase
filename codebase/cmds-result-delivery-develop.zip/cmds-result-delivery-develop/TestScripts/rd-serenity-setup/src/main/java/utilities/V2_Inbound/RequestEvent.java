package utilities.V2_Inbound;

import lombok.Data;

@Data
public class RequestEvent {
	
	private EventHeaders eventHeader;
	private Object eventBody;
	private Object eventErrors;
	private Object audit;

}
