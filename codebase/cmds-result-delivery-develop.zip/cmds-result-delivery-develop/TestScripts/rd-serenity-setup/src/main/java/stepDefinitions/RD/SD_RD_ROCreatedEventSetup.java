package stepDefinitions.RD;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.json.simple.parser.ParseException;

import common.CommonModules;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import stepImplementations.RD.SI_RD_ROCreatedEventSetup;

public class SD_RD_ROCreatedEventSetup extends CommonModules {
	public static String basepath = "";
	static CommonModules common = new CommonModules();
	public String swaggerVersion = System.getenv("SWAGGER_VERSION");
	static SI_RD_ROCreatedEventSetup setupImple = new SI_RD_ROCreatedEventSetup();
	public static String ors70dbname = "";
	public static String ors70reqcollection = "";
	public static String ors70servercollection = "";
	public static String ors70baseurl = "";
	public static String RD_AsyncDB;
	public static String RD_AsyncCollection;

	@Given("^Clean the Mongo database for new data setup for RO Event$")
	public void clean_the_Mongo_database_for_new_data_setup_for_RO_Event() throws IOException {

		common.getEnvironmentConfigurationsOpen();
		hostname = common.getEnvironmentConfigurations("common.hostname");
		portnum = Integer.parseInt(common.getEnvironmentConfigurations("common.portnum"));

		errordb = common.getEnvironmentConfigurations("common.errordb");
		errorcollection = common.getEnvironmentConfigurations("common.errorcollection");

		RD_AsyncCollection = common.getEnvironmentConfigurations("common.RD.AsyncCollection");
		RD_AsyncDB = common.getEnvironmentConfigurations("common.RD.AsyncDBname");
		ors70dbname = common.getEnvironmentConfigurations("int70.dbname");
		ors70reqcollection = common.getEnvironmentConfigurations("int70.reqcollection");
		ors70servercollection = common.getEnvironmentConfigurations("int70.servercollection");
		ors70baseurl = common.getEnvironmentConfigurations("int70.baseurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		setupImple.cleanDatebaseModule(hostname, portnum, ors70dbname, ors70reqcollection);
		setupImple.cleanDatebaseModule(hostname, portnum, errordb, errorcollection);
		setupImple.cleanDatebaseModule(hostname, portnum, ors70dbname, ors70servercollection);
		common.cleanAsyncDBCollection(hostname, portnum, RD_AsyncDB, RD_AsyncCollection);

	}

	@Then("^Insert the request and responses to mongodb for RO Event$")
	public void insert_the_request_and_responses_to_mongodb_for_RO_Event() throws IOException, ParseException {
		if (swaggerVersion.equalsIgnoreCase("v1")) {
			setupImple.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors70dbname, ors70reqcollection);
		} else if (swaggerVersion.equalsIgnoreCase("v2")) {
			setupImple.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors70dbname, ors70reqcollection);
		}

		setupImple.connectandInsertORSCommonresDataInMongoDB(hostname, portnum, errordb, errorcollection);
		setupImple.connectandInsertDBdataReqDataInMongoDB(hostname, portnum, ors70dbname, ors70reqcollection);
	}

	@Then("^Setup the Server responses in Mock server for RO Event$")
	public void setup_the_Server_responses_in_Mock_server_for_RO_Event()
			throws FileNotFoundException, IOException, ParseException {
		setupImple.ConnectandInsertORSResDataInMongoDB(hostname, portnum, ors70dbname, ors70servercollection);
		setupImple.TakeORSMockDataFromMongoDB(hostname, portnum, ors70dbname, ors70servercollection);
		setupImple.PostORSMockDataIntoWiremock(ors70baseurl, basepath);
	}

	@Then("^Test data setup completed sucessfully for RO Event$")
	public void test_data_setup_completed_sucessfully_for_RO_Event() {
		System.out.println("Test data set up is completed successfully");
	}

}
