package testRunners.RD;

import java.util.stream.Stream;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(features = { "src/main/resources/features/RD/RD_ConsumeResultStatusChangedEvent_EVT020_Setup.feature" }, glue = {
		"stepDefinitions" }, format = { "pretty",
				"html:target/results" }, monochrome = true, strict = true, dryRun = false, tags = {
						"@consumeresultsstatusupdatesetup" })

public class TR_RD_ConsumeResultsStatusUpdate_EVT020_Setup {

	private static String[] defaultOptions = { "--glue", "stepDefinitions", "--plugin", "pretty", "--plugin",
			"html:target/results" };

	public static void main(String[] args) throws Throwable {
		Stream<String> cucumberOptions = Stream.concat(Stream.of(defaultOptions), Stream.of(args));
		net.serenitybdd.cucumber.cli.Main.main(cucumberOptions.toArray(String[]::new));
	}

}
