package common.constants;

public class UtilityConstants {
	
	private UtilityConstants() {

	}

	public static final String FORWARD_SLASH = "/";
	public static final String REQUEST_FILE_NAME = "ReferenceRequest";
	public static final String REQUEST_FILE_NAME_V2 = "v2_ReferenceRequest";
	public static final String JSON_EXTENSION = ".json";
	public static final String MAPPINGS_FILE_NAME = "ReferenceResponse";
	public static final String OPENING_CURLY_BRACES = "{";
	public static final String TEST_SETUP_FILE_PATH = "TEST_SETUP_FILE_PATH";
	public static final int REMOVE_HEAD = 51;
	public static final String SWAGGER_VERSION_V1 = "v1";
	public static final String SWAGGER_VERSION_V2 = "v2";
	public static final String SWAGGER_VERSION_ENV_VARIABLE_NAME = "SWAGGER_VERSION";
	public static final String PROPERTY_FILE_PATH_ENV_VARIABLE_NAME = "PROPERTY_FILE_PATH";
	public static final String DB_REQUEST = "DBRequest";

}
