package stepDefinitions.RD;

import java.io.IOException;

import org.json.simple.parser.ParseException;
import common.CommonModules;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import stepImplementations.RD.SI_RD_BookingCreatedConsumptionForSelectionSetup;
import stepImplementations.RD.SI_RD_ROCreatedConsumptionForSelectionSetup;

public class SD_RD_BookingEventConsumptionForSelectionSetup extends CommonModules {

	CommonModules common = new CommonModules();
	SI_RD_BookingCreatedConsumptionForSelectionSetup stepimplement = new SI_RD_BookingCreatedConsumptionForSelectionSetup();
	String env = System.getenv("ENVIRONMENT");
	public String swaggerVersion = System.getenv("SWAGGER_VERSION");

	public static String envkeyQueue = "";
	public static String AuthURL = "";
	static String AuthReq = "";
	public static String mxName = "";
	public static String DBUrl = "";
	public static String dbUrl = "";
	public static String accessToken = "";
	public static String enviroment = "";
	static String authURL = "";
	static String authReq = "";

	static String destinationQueue = "";
	static String destinationTopic = "";
	static String envkeyTopic = "";

	protected static String int189dbname = "";
	protected static String int189reqcollection = "";
	protected static String int189Acturl = "";
	protected static String int189Actpath = "";

	public static String RD_AsyncDB;
	public static String RD_AsyncCollection;

	@Given("^MongoDB configuration set up has been done for the booking event \"([^\"]*)\"$")
	public void mongodb_Configuration_Set_up_has_been_done_for_RDS_BookingCreated_UpdatedEvent(String partner)
			throws IOException {
		common.getEnvironmentConfigurationsOpen();
		hostname = common.getEnvironmentConfigurations("common.hostname");
		portnum = Integer.parseInt(common.getEnvironmentConfigurations("common.portnum"));

		errordb = common.getEnvironmentConfigurations("common.errordb");
		errorcollection = common.getEnvironmentConfigurations("common.errorcollection");

		RD_AsyncCollection = common.getEnvironmentConfigurations("common.RD.AsyncCollection");
		RD_AsyncDB = common.getEnvironmentConfigurations("common.RD.AsyncDBname");

		int189dbname = common.getEnvironmentConfigurations("int189.dbname");
		int189reqcollection = common.getEnvironmentConfigurations("int189.reqcollection");

		// int189Acturl = common.getEnvironmentConfigurations("int189.Acturl");
		int189Acturl = stepimplement.TakeActUrl(env);
		int189Actpath = common.getEnvironmentConfigurations("int189.booking.path");

		destinationQueue = common.getEnvironmentConfigurations("int189.DestinationQueue");
		// envkeyQueue = common.getEnvironmentConfigurations("int189.envKeyQueue");

		envkeyQueue = stepimplement.TakeEnvKeyQueue(env);
		AuthURL = stepimplement.takeAuthUrlForBooking(partner);
		AuthReq = stepimplement.takeAuthReqForBooking(partner);
		mxName = "RD";
		enviroment = env;
		DBUrl = stepimplement.TakeDbUrl(env);
		dbUrl = DBUrl;
		accessToken = common.RetrieveToken(AuthURL, AuthReq);

	}

	@When("^booking event updates are made available to CMDS-RDS \"([^\"]*)\"$")
	public void booking_updates_for_the_Test_Events_are_made_available_to_CMDS_RDS(String transactionId)
			throws InterruptedException, ParseException {
		stepimplement.getInputRequestBodyUsingTransactionId(hostname, portnum, int189dbname, int189reqcollection,
				transactionId);
		stepimplement.constructNewpostbodywithNewLocation();

	}

	@When("^booking event updates are made available to CMDS-RD System \"([^\"]*)\"$")
	public void booking_updates_for_the_Test_Events_are_made_available_to_CMDS_RD_System(String transactionId)
			throws InterruptedException, ParseException {
		stepimplement.getInputRequestBodyForUpdatedScenarios(hostname, portnum, int189dbname, int189reqcollection,
				transactionId);
	}

	@When("^event contains all the mandatory fields$")
	public void bookingcreated_BookingUpdated_contains_all_the_mandatory_fields() throws ParseException {
		stepimplement.getJsonFeildValuesfromRequestbody();
		stepimplement.allFields();
	}

	@Then("^Post the booking event to rds-in-queue$")
	public void cmds_RDS_will_accept_the_booking_updates() throws ParseException {
		stepimplement.postRequest(int189Acturl, int189Actpath, destinationQueue, envkeyQueue, accessToken);
		stepimplement.insertRecord(hostname, portnum, int189dbname, int189reqcollection);
		stepimplement.getExpectedBookingLineUuidinBookingLinesRequest();
		stepimplement.getExpectedProductUuidinBookingLinesRequest();
		stepimplement.verifyResponse();
		stepimplement.getJsonFeildValuesfromRequestbody();

	}

	@Then("^CMDS-RDS will upsert the booking details in RDS and publish BookingConsumedEvent$")
	public void cmds_RDS_will_upsert_the_booking_details_in_RDS_and_publish_BookingConsumedEvent()
			throws InterruptedException, ParseException {
		stepimplement.connectMongoDB(hostname, portnum);
		stepimplement.validatePublishedMessage();
		stepimplement.verifyMandatoryFieldInBookingLines();
		stepimplement.verifybookingLineUuid();
		stepimplement.verifyproductUuid();

	}

	@Then("^Construct the Booking updated event with eventDateTime as \"([^\"]*)\"$")
	public void constructneweventbodyforUpdatedevent(String eventDateTimeFlag) throws ParseException {
		stepimplement.constructNewpostbodywithNewEventDateTimeForUpdateBooking(eventDateTimeFlag);
	}

	@Then("^CMDS-RDS will reject update event and publish error event$")
	public void rejecttheevent() throws ParseException, InterruptedException {
		stepimplement.connectMongoDB(hostname, portnum);
		stepimplement.verifyErrorInPublishedMessage();

	}

}
