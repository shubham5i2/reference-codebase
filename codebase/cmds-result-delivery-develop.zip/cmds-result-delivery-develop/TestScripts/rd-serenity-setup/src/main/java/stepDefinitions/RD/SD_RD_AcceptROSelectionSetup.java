package stepDefinitions.RD;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.json.simple.parser.ParseException;

import common.CommonModules;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import stepImplementations.RD.SI_RD_AcceptROSelectionSetup;
import stepImplementations.RD.SI_RD_BookingCreatedEventSetup;
import stepImplementations.RD.SI_RD_ROCreatedEventSetup;

public class SD_RD_AcceptROSelectionSetup extends CommonModules {

	static CommonModules common = new CommonModules();
	public String swaggerVersion = System.getenv("SWAGGER_VERSION");
	static SI_RD_BookingCreatedEventSetup booking = new SI_RD_BookingCreatedEventSetup();
	public static String RD_AsyncDB;
	public static String RD_AsyncCollection;
	static SI_RD_ROCreatedEventSetup organisation = new SI_RD_ROCreatedEventSetup();
	static SI_RD_AcceptROSelectionSetup stepImplementation = new SI_RD_AcceptROSelectionSetup();

	public static String ors189dbname = "";
	public static String ors189reqcollection = "";
	public static String ors189servercollection = "";
	public static String ors189baseurl = "";

	public static String ors70dbname = "";
	public static String ors70reqcollection = "";
	public static String ors70servercollection = "";
	public static String ors70baseurl = "";
	public static String basepath = "";
	public static String ors268dbname = "";
	public static String ors268reqcollection = "";
	public static String ors268servercollection = "";
	public static String ors268callbackurl = "";
	protected static String cmds268resultActpath = "";
	protected static String cmds268resultActurl = "";

	@Given("^Clean the Mondodb database for IMOD-8225$")
	public void cleantheMondodbdatabase() throws IOException {

		common.getEnvironmentConfigurationsOpen();
		hostname = common.getEnvironmentConfigurations("common.hostname");
		portnum = Integer.parseInt(common.getEnvironmentConfigurations("common.portnum"));
		ors70dbname = common.getEnvironmentConfigurations("int70.dbname");
		ors70reqcollection = common.getEnvironmentConfigurations("int70.reqcollection");
		ors70servercollection = common.getEnvironmentConfigurations("int70.servercollection");
		ors70baseurl = common.getEnvironmentConfigurations("int70.baseurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		errordb = common.getEnvironmentConfigurations("common.errordb");
		errorcollection = common.getEnvironmentConfigurations("common.errorcollection");

		RD_AsyncCollection = common.getEnvironmentConfigurations("common.RD.AsyncCollection");
		RD_AsyncDB = common.getEnvironmentConfigurations("common.RD.AsyncDBname");
		organisation.cleanDatebaseModule(hostname, portnum, ors70dbname, ors70reqcollection);
		organisation.cleanDatebaseModule(hostname, portnum, errordb, errorcollection);
		organisation.cleanDatebaseModule(hostname, portnum, ors70dbname, ors70servercollection);

		ors189dbname = common.getEnvironmentConfigurations("int189.dbname");
		ors189reqcollection = common.getEnvironmentConfigurations("int189.reqcollection");
		ors189servercollection = common.getEnvironmentConfigurations("int189.servercollection");
		ors189baseurl = common.getEnvironmentConfigurations("int189.baseurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		booking.cleanDatebaseModule(hostname, portnum, ors189dbname, ors189reqcollection);
		booking.cleanDatebaseModule(hostname, portnum, ors189dbname, ors189servercollection);

		ors268dbname = common.getEnvironmentConfigurations("ors268.dbname");
		ors268reqcollection = common.getEnvironmentConfigurations("ors268.reqcollection");
		ors268servercollection = common.getEnvironmentConfigurations("ors268.servercollection");
		ors268callbackurl = common.getEnvironmentConfigurations("ors268.mockurl");
		basepath = common.getEnvironmentConfigurations("common.path");

		stepImplementation.cleanDatebaseModule(hostname, portnum, ors268dbname, ors268reqcollection);
		stepImplementation.cleanDatebaseModule(hostname, portnum, ors268dbname, ors268servercollection);
		common.cleanAsyncDBCollection(hostname, portnum, RD_AsyncDB, RD_AsyncCollection);
	}

	@Given("^Insert the request for test data setup in mongodb$")
	public void inserttherequestfortestdatasetupinmongodb() throws FileNotFoundException, IOException, ParseException {

		if (swaggerVersion.equalsIgnoreCase("v1")) {
			booking.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors189dbname, ors189reqcollection);
			organisation.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors70dbname, ors70reqcollection);
			stepImplementation.connectandInsertORSReqDataInMongoDB(hostname, portnum, ors268dbname,
					ors268reqcollection);
		} else if (swaggerVersion.equalsIgnoreCase("v2")) {
			booking.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors189dbname, ors189reqcollection);
			organisation.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors70dbname, ors70reqcollection);
			stepImplementation.v2_connectandInsertORSReqDataInMongoDB(hostname, portnum, ors268dbname,
					ors268reqcollection);
		}
		stepImplementation.connectandInsertErrorResponseMongoDB(hostname, portnum, ors268dbname, ors268reqcollection);
		stepImplementation.connectandInsertORSCommonresDataInMongoDB(hostname, portnum, errordb, errorcollection);
		stepImplementation.connectandInsertDBdataReqDataInMongoDB(hostname, portnum, ors268dbname, ors268reqcollection);
	}

	@Given("^Insert response mapping for wiremock$")
	public void insertresponsemappingforwiremock() throws FileNotFoundException, IOException, ParseException {

		stepImplementation.ConnectandInsertORSResDataInMongoDB(hostname, portnum, ors268dbname, ors268servercollection);
		stepImplementation.TakeORSMockDataFromMongoDB(hostname, portnum, ors268dbname, ors268servercollection);
		stepImplementation.PostORSMockDataIntoWiremock(ors268callbackurl, basepath);

	}

	@Then("^RO Selection reference request data set up is completed successfully$")
	public void roSelectionreferencerequestdatasetupiscompletedsuccessfully() {
		System.out.println("Reference data set up is completed successfully");
	}

}
