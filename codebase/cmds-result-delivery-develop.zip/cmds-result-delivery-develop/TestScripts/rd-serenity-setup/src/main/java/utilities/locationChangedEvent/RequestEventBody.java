package utilities.locationChangedEvent;

import lombok.Data;

@Data
public class RequestEventBody {
	private String locationUuid;
    private String parentLocationUuid;
    private String status;
    private String locationType;
    private String partnerCode;
    private String testCentreNumber;
    private String testCentreLocationUuid;
    private String locationName;
}
