package common.dbabstraction;

import com.mongodb.DB;
import com.mongodb.MongoClient;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class CMDSMongoClientAdapter extends MongoClient {

	private final String hostName;
	private final Integer portNum;

	public static final String ASYNC_DB = "async";

	private final String pipelineId = System.getenv("PIPELINE_ID");

	private MongoClient mongoClient() {
		try {
			return new MongoClient(hostName, portNum);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@SuppressWarnings("deprecation")
	public DB getDB(final String dbName) {
		if (!dbName.contains(ASYNC_DB)) {
			return mongoClient().getDB(pipelineId+"_"+dbName);
		} else {
			return mongoClient().getDB(dbName);
		}
	}

}
