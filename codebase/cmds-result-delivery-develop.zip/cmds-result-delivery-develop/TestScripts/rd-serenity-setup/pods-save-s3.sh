#!/bin/bash

pwd
cd /var/podlogs/pods/
pwd
namespace=$(ls | grep wm-setup-jobs-$ENVIRONMENT)
echo $namespace
cd /var/podlogs/pods/$namespace
pwd
ls -la
cd /var/podlogs/pods/$namespace/executesetup
pwd
find -type l  -print0 | xargs -0 ls -plah | awk '{print $11}'
filecount=$(find -type l -print0 | xargs -0 ls -plah | awk '{print $11}' | wc -l)
find -type l -print0 | xargs -0 ls -plah | awk '{print $11}' > filename.dat
while read file_name;do
 file_name_folder=$(echo $file_name | sed 's|\(.*\)/.*|\1|')
 log_file=$(echo $file_name | sed 's|.*/||')
 cd $file_name_folder
 echo "present working directory"
 pwd
 ls -la
 #chown -R 501:501 $log_file
 echo "----- $file_name--------"
    #echo $file_name_folder
 echo "uploading the file $log_file......."
 aws s3  cp $log_file  s3://ielts-cmds-lambdafuction-artifact/ekslogs/ --recursive
done < filename.dat
