package com.ielts.cmds.integration.constants;

public class ReceiverConstants {
	
	private ReceiverConstants() {}

	public static final String RD_UI_TOPIC_IN_ARN = "rd_ui_topic_in_arn";
	public static final String PARTNER_CODE = "partnerCode";

	public static final String SELECTIONS_SEARCH_REQUESTED_EVENT_NAME = "POST/v1/trf/booking/{bookingUuid}/selections/search";
	public static final String TRF_DOWNLOAD_REQUESTED_EVENT_NAME = "POST/v1/trf/booking/{bookingUuid}/download/trf";
	public static final String ETRF_DOWNLOAD_REQUESTED_EVENT_NAME = "POST/v1/etrf/booking/{bookingUuid}/download/etrf";

	public static final String SELECTIONS_SEARCH_REQUESTED_OUTGOING_EVENT_NAME = "SelectionsSearchRequested";
	public static final String TRF_DOWNLOAD_REQUESTED_OUTGOING_EVENT_NAME = "TRFDownloadRequested";
	public static final String ETRF_DOWNLOAD_REQUESTED_OUTGOING_EVENT_NAME = "ETRFDownloadRequested";

}
