package com.ielts.cmds.integration.services;

import static com.ielts.cmds.integration.constants.ReceiverConstants.ETRF_DOWNLOAD_REQUESTED_OUTGOING_EVENT_NAME;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.rdui003etrfdownloadrequested.TRFBookingETRFDownloadRequestV1;
import com.ielts.cmds.serialization.lambda.receiver.service.RequestWithParamsReceiverService;

public class ETRFDownloadRequestedService extends RequestWithParamsReceiverService<TRFBookingETRFDownloadRequestV1> {

	public ETRFDownloadRequestedService(ObjectMapper mapper) {
		super(mapper);
	}

	@Override
	public String getOutgoingEventName() {
		return ETRF_DOWNLOAD_REQUESTED_OUTGOING_EVENT_NAME;
	}
}
