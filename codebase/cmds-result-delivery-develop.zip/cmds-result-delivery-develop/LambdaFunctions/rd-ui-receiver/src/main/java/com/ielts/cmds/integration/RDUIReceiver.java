package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.constants.ReceiverConstants.ETRF_DOWNLOAD_REQUESTED_EVENT_NAME;
import static com.ielts.cmds.integration.constants.ReceiverConstants.PARTNER_CODE;
import static com.ielts.cmds.integration.constants.ReceiverConstants.RD_UI_TOPIC_IN_ARN;
import static com.ielts.cmds.integration.constants.ReceiverConstants.SELECTIONS_SEARCH_REQUESTED_EVENT_NAME;
import static com.ielts.cmds.integration.constants.ReceiverConstants.TRF_DOWNLOAD_REQUESTED_EVENT_NAME;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.utils.CMDSCommonUtils;
import com.ielts.cmds.integration.factory.ReceiverServiceFactory;
import com.ielts.cmds.integration.services.ETRFDownloadRequestedService;
import com.ielts.cmds.integration.services.SelectionsSearchRequestedService;
import com.ielts.cmds.integration.services.TRFDownloadRequestedService;
import com.ielts.cmds.serialization.lambda.AbstractReceiverLambda;
import com.ielts.cmds.serialization.lambda.mapper.IObjectMapper;
import com.ielts.cmds.serialization.lambda.receiver.service.AbstractServiceFactory;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import lombok.NoArgsConstructor;

/**
 * The type Rd ui receiver.
 */
@NoArgsConstructor
public class RDUIReceiver extends AbstractReceiverLambda implements IObjectMapper {

	@Override
	public AbstractServiceFactory getServiceFactory() {
		@SuppressWarnings("rawtypes")
		final Map<String, IReceiverService> initServices = new HashMap<>();
		final ObjectMapper mapper = getMapperWithProperties();
		initServices.put(SELECTIONS_SEARCH_REQUESTED_EVENT_NAME, new SelectionsSearchRequestedService());
		initServices.put(TRF_DOWNLOAD_REQUESTED_EVENT_NAME, new TRFDownloadRequestedService(mapper));
		initServices.put(ETRF_DOWNLOAD_REQUESTED_EVENT_NAME, new ETRFDownloadRequestedService(mapper));
		return new ReceiverServiceFactory(initServices);
	}

	@Override
	public String getTopicArn() {
		return System.getenv(RD_UI_TOPIC_IN_ARN);
	}

	@Override
	protected String getPartnerCode() {
		return CMDSCommonUtils.getDataFromClaims(ThreadLocalHeaderContext.getContext().getXaccessToken(), PARTNER_CODE);
	}
}
