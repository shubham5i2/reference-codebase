package com.ielts.cmds.integration.services;

import static com.ielts.cmds.integration.constants.ReceiverConstants.TRF_DOWNLOAD_REQUESTED_OUTGOING_EVENT_NAME;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.rdui002trfdownloadrequested.TRFBookingTRFDownloadRequestV1;
import com.ielts.cmds.serialization.lambda.receiver.service.RequestWithParamsReceiverService;

public class TRFDownloadRequestedService extends RequestWithParamsReceiverService<TRFBookingTRFDownloadRequestV1> {

	public TRFDownloadRequestedService(ObjectMapper mapper) {
		super(mapper);
	}

	@Override
	public String getOutgoingEventName() {
		return TRF_DOWNLOAD_REQUESTED_OUTGOING_EVENT_NAME;
	}
}
