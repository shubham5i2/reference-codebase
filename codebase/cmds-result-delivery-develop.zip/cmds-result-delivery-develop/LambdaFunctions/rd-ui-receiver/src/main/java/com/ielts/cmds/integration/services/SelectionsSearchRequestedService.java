package com.ielts.cmds.integration.services;

import static com.ielts.cmds.integration.constants.ReceiverConstants.SELECTIONS_SEARCH_REQUESTED_OUTGOING_EVENT_NAME;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.ielts.cmds.api.rdui001selectionssearchrequested.SearchPaginationV1;
import com.ielts.cmds.api.rdui001selectionssearchrequested.SearchSortV1Item;
import com.ielts.cmds.api.rdui001selectionssearchrequested.TRFBookingSelectionsSearchCriteriaV1;
import com.ielts.cmds.api.rdui001selectionssearchrequested.TRFBookingSelectionsSearchRequestV1;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;

public class SelectionsSearchRequestedService implements IReceiverService<com.ielts.cmds.api.common.ui_client.TRFBookingSelectionsSearchRequestV1, TRFBookingSelectionsSearchRequestV1> {

	@Override
	public String getOutgoingEventName() {
		return SELECTIONS_SEARCH_REQUESTED_OUTGOING_EVENT_NAME;
	}

	@Override
	public TRFBookingSelectionsSearchRequestV1 process(final com.ielts.cmds.api.common.ui_client.TRFBookingSelectionsSearchRequestV1 incomingEvent) {
		TRFBookingSelectionsSearchRequestV1 outgoingEvent = new TRFBookingSelectionsSearchRequestV1();
		
		TRFBookingSelectionsSearchCriteriaV1 criteria = new TRFBookingSelectionsSearchCriteriaV1();
		criteria.setBookingUuid(UUID.fromString(incomingEvent.getCriteria().getBookingUuid()));
		outgoingEvent.setCriteria(criteria);
		
		SearchPaginationV1 pagination = new SearchPaginationV1();
		pagination.setPageNumber(incomingEvent.getPagination().getPageNumber());
		pagination.setPageSize(incomingEvent.getPagination().getPageSize());
		outgoingEvent.setPagination(pagination);
		
		final List<SearchSortV1Item> sortItems = new ArrayList<>();
		incomingEvent.getSorting().forEach(incomingSortItem -> {
			SearchSortV1Item sortItem = new SearchSortV1Item();
			sortItem.setSortBy(incomingSortItem.getSortBy());
			sortItem.setSortType(incomingSortItem.getSortType());
			sortItems.add(sortItem);
		});
		outgoingEvent.setSorting(sortItems);
		
		return outgoingEvent;
	}

}
