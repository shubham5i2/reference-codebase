package com.ielts.cmds.integration.helper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.ielts.cmds.api.common.ui_client.SearchPaginationV1;
import com.ielts.cmds.api.common.ui_client.SearchSortV1Item;
import com.ielts.cmds.api.common.ui_client.TRFBookingSelectionsSearchCriteriaV1;
import com.ielts.cmds.api.common.ui_client.TRFBookingSelectionsSearchRequestV1;

public class RDUIReceiverTestSetup {

	public static TRFBookingSelectionsSearchRequestV1 getSelectionsSearchRequestedEventForTest() {

		TRFBookingSelectionsSearchRequestV1 selectionsSearchRequested = new TRFBookingSelectionsSearchRequestV1();
		TRFBookingSelectionsSearchCriteriaV1 criteria = new TRFBookingSelectionsSearchCriteriaV1();
		criteria.setBookingUuid(UUID.randomUUID().toString());
		selectionsSearchRequested.setCriteria(criteria);

		SearchPaginationV1 pagination = new SearchPaginationV1();
		pagination.setPageNumber(BigDecimal.ONE);
		pagination.setPageSize(BigDecimal.TEN);
		selectionsSearchRequested.setPagination(pagination);

		final List<SearchSortV1Item> sortItems = new ArrayList<>();
		for (int i = 0; i < 5; i++) {
			SearchSortV1Item sortItem = new SearchSortV1Item();
			sortItem.setSortBy("name");
			sortItem.setSortType("asc");
			sortItems.add(sortItem);
		}
		selectionsSearchRequested.setSorting(sortItems);

		return selectionsSearchRequested;
	}

	public static String getXAccessToken() {
		return "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkJTT3YxZ21Zam1vSWNUZFpFcGN3XyJ9.eyJodHRwczovL2NtZHNpei5jb20vcGFydG5lckNvZGUiOiJHTE9CQUxfSUVMVFMiLCJodHRwczovL2NtZHNpei5jb20vaWQiOiJhdXRoMHxkZDc2MDM1Zi0xZjgxLTQ5M2ItYjY3Yi03ZGVlMTliNTIzYTQiLCJodHRwczovL2NtZHNpei5jb20vcm9sZXMiOlsibDpjNmQ2Yjc5NS1iMjBiLTQ2NmMtOTJlZi03YTUzNzUyZTIzOGMvZzo4ZjQwZDlkOS00ZmQ0LTQ3YTYtOTcyMi1kOWI5ZmM1ZTgxYWQiXSwiaHR0cHM6Ly9jbWRzaXouY29tL2VtYWlsIjoic2hhcm1hLnM1QGNhbWJyaWRnZWFzc2Vzc21lbnQub3JnLnVrIiwiaHR0cHM6Ly9jbWRzaXouY29tL2ZpcnN0TmFtZSI6IlNoaXZhbmsiLCJodHRwczovL2NtZHNpei5jb20vbGFzdE5hbWUiOiJTaGFybWEiLCJpc3MiOiJodHRwczovL2NtZHMtc2FuZGJveC5ldS5hdXRoMC5jb20vIiwic3ViIjoiYXV0aDB8ZGQ3NjAzNWYtMWY4MS00OTNiLWI2N2ItN2RlZTE5YjUyM2E0IiwiYXVkIjpbImNtZHMtc2FuZGJveC11aS1hcGkiLCJodHRwczovL2NtZHMtc2FuZGJveC5ldS5hdXRoMC5jb20vdXNlcmluZm8iXSwiaWF0IjoxNjgwMjY3MTg0LCJleHAiOjE2ODAyODE1ODQsImF6cCI6IjZucEpIS0tKaUdaSGtMSVBONWFCVzNuYUUwbEFtT25ZIiwic2NvcGUiOiJvcGVuaWQgcHJvZmlsZSBlbWFpbCJ9.mho84Bjz97Ort6e1I3_7dmSqoHAM7GnF-q3jNATTk7djYBR9tLMB3CK7woHQ1nWVTrL6ltFvF0cMNJH8fVTxc4wDhoT9H3opemAs7Ssbf8--by4SXV6bxICYLSN6RVPvrJ9mqJj1MI-V__fB63gTGcfaLUQQIlGpST9AuSYtfSkqzDtGjVFEv1OTm0Obx-c0wFUZFfngzJx8pgy1VHR5qIZBJ1s_z-23RNYeRqjdIjKvTViAC1sk-7oI7-jGTpQFx_K2pVwpNmxJvZoR4GmwbKaAdNGM7_uBPSl7cUb6C19zuCuGpa9vtvpEUTRnPRaSy-xiX3ihPucoZUlSyKH4pQ";
	}

}
