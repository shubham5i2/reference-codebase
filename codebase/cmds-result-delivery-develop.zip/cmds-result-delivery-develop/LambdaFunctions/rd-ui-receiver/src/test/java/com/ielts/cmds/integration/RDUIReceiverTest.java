package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.constants.ReceiverConstants.RD_UI_TOPIC_IN_ARN;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.auth0.jwt.exceptions.JWTDecodeException;
import com.ielts.cmds.integration.factory.ReceiverServiceFactory;
import com.ielts.cmds.integration.helper.RDUIReceiverTestSetup;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import uk.org.webcompere.systemstubs.environment.EnvironmentVariables;
import uk.org.webcompere.systemstubs.jupiter.SystemStub;
import uk.org.webcompere.systemstubs.jupiter.SystemStubsExtension;

/**
 * The type Rd ui receiver test.
 */
@ExtendWith(MockitoExtension.class)
@ExtendWith(SystemStubsExtension.class)
class RDUIReceiverTest {

	@SystemStub
	private EnvironmentVariables environmentVariables;

	@Mock
	private RDUIReceiver rdUiReceiver;

	/**
	 * Sets up.
	 *
	 * @throws Exception the exception
	 */
	@BeforeEach
	void setUp() {
		environmentVariables.set(RD_UI_TOPIC_IN_ARN, "rd-topic-url");
		rdUiReceiver = Mockito.spy(rdUiReceiver);

	}

	@Test
	void whenTokenIsNotNull_thenGetPartnerCode() {
		HeaderContext headerContext = new HeaderContext();
		headerContext.setXaccessToken(RDUIReceiverTestSetup.getXAccessToken());
		ThreadLocalHeaderContext.setContext(headerContext);
		String expectedPartnerCode = "GLOBAL_IELTS";
		String actualPartnerCode = rdUiReceiver.getPartnerCode();
		assertEquals(expectedPartnerCode, actualPartnerCode);
	}

	@Test
	void whenCallingGetPartnerCodeAndTokenIsNull_thenThrowException() {
		HeaderContext headerContext = new HeaderContext();
		headerContext.setXaccessToken("token");
		ThreadLocalHeaderContext.setContext(headerContext);
		assertThrows(JWTDecodeException.class, () -> rdUiReceiver.getPartnerCode());
	}

	@Test
	void whenCallingGetTopicArn_thenReturnTopicArn() {
		String expectedTopicUrl = "rd-topic-url";
		assertEquals(expectedTopicUrl, rdUiReceiver.getTopicArn());
	}

	@Test
	void test_getServiceFactory() {
		assertTrue(rdUiReceiver.getServiceFactory() instanceof ReceiverServiceFactory);
	}

}
