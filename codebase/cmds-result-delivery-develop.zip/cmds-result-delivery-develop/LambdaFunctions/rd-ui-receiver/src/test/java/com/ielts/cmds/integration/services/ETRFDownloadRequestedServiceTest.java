package com.ielts.cmds.integration.services;

import static com.ielts.cmds.integration.constants.ReceiverConstants.ETRF_DOWNLOAD_REQUESTED_OUTGOING_EVENT_NAME;
import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ETRFDownloadRequestedServiceTest {

	@InjectMocks
	private ETRFDownloadRequestedService etrfDownloadRequestedService;

	@Test
	void when_callingGetOutgoingEventName_thenReturnEvent() {
		String actualEventName = etrfDownloadRequestedService.getOutgoingEventName();
		assertEquals(ETRF_DOWNLOAD_REQUESTED_OUTGOING_EVENT_NAME, actualEventName);
	}

}
