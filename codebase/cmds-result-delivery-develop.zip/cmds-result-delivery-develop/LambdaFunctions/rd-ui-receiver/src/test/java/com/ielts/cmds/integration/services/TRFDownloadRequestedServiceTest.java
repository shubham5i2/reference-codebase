package com.ielts.cmds.integration.services;

import static com.ielts.cmds.integration.constants.ReceiverConstants.TRF_DOWNLOAD_REQUESTED_OUTGOING_EVENT_NAME;
import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class TRFDownloadRequestedServiceTest {

	@InjectMocks
	private TRFDownloadRequestedService trfDownloadRequestedService;

	@Test
	void when_callingGetOutgoingEventName_thenReturnEvent() {
		String actualEventName = trfDownloadRequestedService.getOutgoingEventName();
		assertEquals(TRF_DOWNLOAD_REQUESTED_OUTGOING_EVENT_NAME, actualEventName);
	}

}
