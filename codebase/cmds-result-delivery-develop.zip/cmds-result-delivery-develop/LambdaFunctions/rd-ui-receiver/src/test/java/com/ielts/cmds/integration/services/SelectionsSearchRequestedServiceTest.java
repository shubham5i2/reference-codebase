package com.ielts.cmds.integration.services;

import static com.ielts.cmds.integration.constants.ReceiverConstants.SELECTIONS_SEARCH_REQUESTED_OUTGOING_EVENT_NAME;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.api.rdui001selectionssearchrequested.TRFBookingSelectionsSearchRequestV1;
import com.ielts.cmds.integration.helper.RDUIReceiverTestSetup;

@ExtendWith(MockitoExtension.class)
class SelectionsSearchRequestedServiceTest {

	@InjectMocks
	private SelectionsSearchRequestedService selectionsSearchRequestedService;

	@Test
	void whenReceiveSelectionsSearchRequested_thenProcessEvent() {
		com.ielts.cmds.api.common.ui_client.TRFBookingSelectionsSearchRequestV1 expectedSelectionsSearchRequest = RDUIReceiverTestSetup.getSelectionsSearchRequestedEventForTest();
		TRFBookingSelectionsSearchRequestV1 actualSelectionsSearchRequest = selectionsSearchRequestedService.process(expectedSelectionsSearchRequest);
		
		assertNotNull(actualSelectionsSearchRequest);
		assertEquals(expectedSelectionsSearchRequest.getCriteria().getBookingUuid(), actualSelectionsSearchRequest.getCriteria().getBookingUuid().toString());
		assertEquals(expectedSelectionsSearchRequest.getPagination().getPageNumber(), actualSelectionsSearchRequest.getPagination().getPageNumber());
		assertEquals(expectedSelectionsSearchRequest.getPagination().getPageSize(), actualSelectionsSearchRequest.getPagination().getPageSize());
		
		for(int i=0; i< expectedSelectionsSearchRequest.getSorting().size(); i++) {
			assertEquals(expectedSelectionsSearchRequest.getSorting().get(i).getSortBy(), actualSelectionsSearchRequest.getSorting().get(i).getSortBy());
			assertEquals(expectedSelectionsSearchRequest.getSorting().get(i).getSortType(), actualSelectionsSearchRequest.getSorting().get(i).getSortType());
		}
	}

	@Test
	void when_callingGetOutgoingEventName_thenReturnEvent() {
		String actualEventName = selectionsSearchRequestedService.getOutgoingEventName();
		assertEquals(SELECTIONS_SEARCH_REQUESTED_OUTGOING_EVENT_NAME, actualEventName);
	}

}
