DO $$
BEGIN
IF NOT EXISTS (select * from information_schema.role_table_grants Where grantee = 'rd_impl_role'
AND table_name = 'outbox_event_attribute' AND privilege_type='DELETE')
THEN
  GRANT DELETE ON rd_owner.outbox_event_attribute TO rd_impl_role;
END IF;
END $$;


