CREATE TABLE IF NOT EXISTS rd_owner.result_booking(
	result_booking_uuid UUID NOT NULL,
	result_uuid UUID NOT NULL,
	booking_uuid UUID NOT NULL,
	external_booking_uuid UUID,
	short_candidate_number integer,
	first_name varchar(100),
	last_name varchar(100),
	identity_number varchar(100),
	identity_type_uuid UUID,
	identity_issuing_auth varchar(100),
	identity_expiry_date date,
	birth_date date,
	sex_uuid UUID,
	language_uuid UUID,
	nationality_uuid UUID,
	nationality_other varchar(300),
	concurrency_version integer,
	booking_version integer,
	CONSTRAINT pk_result_booking PRIMARY KEY (result_booking_uuid)
	
);