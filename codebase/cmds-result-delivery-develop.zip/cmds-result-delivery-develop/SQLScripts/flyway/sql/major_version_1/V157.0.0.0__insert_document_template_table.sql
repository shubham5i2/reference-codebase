insert into rd_owner.document_template(document_template_uuid, document_template_name,partner_code,document_type_uuid,effective_from_date,effective_to_date) values ('aaf174f6-0913-4efd-8522-0fea662fe70d',
'OSR_EOR_POSITIVE_BC','BC','ddb28ed4-334f-4650-8a65-16077858783c','2024-01-26','2099-12-31');

insert into rd_owner.document_template(document_template_uuid, document_template_name,partner_code,document_type_uuid,effective_from_date,effective_to_date) values ('83e57ac5-a9e8-46d7-8030-c47303c7a74f',
'OSR_EOR_POSITIVE_BC','BC_CHN','ddb28ed4-334f-4650-8a65-16077858783c','2024-01-26','2099-12-31');

