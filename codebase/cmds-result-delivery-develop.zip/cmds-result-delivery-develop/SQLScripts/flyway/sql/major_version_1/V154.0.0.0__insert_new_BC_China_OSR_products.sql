INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('848d6c85-90b2-43cc-994b-d319977cf2d0',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        'cb7cd48c-5e79-4a28-8104-e0bcd8e39999',
		'BC_CHN',
		'TRF_SSR_CD',
		'ACADEMIC');
		
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('d377f650-ad69-4179-bad6-d5bf3103a6a5',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        'c37e2fab-898d-46d4-a61b-17f24bb29e83',
		'BC_CHN',
		'TRF_SSR_CD',
		'GENERAL TRAINING');

		
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('764a3b41-f47b-402a-bf4a-aa9dde79418c',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        'cb7cd48c-5e79-4a28-8104-e0bcd8e39999',
		'BC_CHN',
		'ETRF_SSR_CD',
		'ACADEMIC');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('b35ce483-245e-4806-8827-5df280f56e04',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        'c37e2fab-898d-46d4-a61b-17f24bb29e83',
		'BC_CHN',
		'ETRF_SSR_CD',
		'GENERAL TRAINING');
