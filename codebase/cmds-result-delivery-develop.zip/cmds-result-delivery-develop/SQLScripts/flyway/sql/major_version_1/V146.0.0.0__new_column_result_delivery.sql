ALTER TABLE rd_owner.result_delivery
ADD COLUMN IF NOT EXISTS status_received_datetime TIMESTAMPTZ;
