-- To Update existing booking columns

UPDATE rd_owner.booking
SET
	test_date_string = TO_CHAR(test_date::timestamp AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
	timezone_offset = 'Z',
	test_date_utc = test_date::timestamp AT TIME ZONE 'UTC'
WHERE test_date_utc IS NULL;
