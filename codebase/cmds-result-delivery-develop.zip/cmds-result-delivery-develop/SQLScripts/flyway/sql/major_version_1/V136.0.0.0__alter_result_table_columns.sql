ALTER TABLE rd_owner.result ALTER COLUMN result_type_uuid DROP NOT NULL;
ALTER TABLE rd_owner.result ALTER COLUMN result_score DROP NOT NULL;
ALTER TABLE rd_owner.result_line ALTER COLUMN result_line_score DROP NOT NULL;
