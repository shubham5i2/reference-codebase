--DML scripts for product_config UKVI OSR data 

--IDP TRF
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('0e2fac52-ce64-4425-8e08-e6adb8be73c0',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        '2948e48b-519b-484e-aed9-93a30a8a9485',
		'IDP',
		'UKVI_TRF_SSR_IOL',
		'ACADEMIC');
		
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('0e11e507-d142-488f-b96c-66064dafdfb6',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        '58c171e7-6789-498c-9e2e-e26f4bf8c90c',
		'IDP',
		'UKVI_TRF_SSR_IOL',
		'GENERAL TRAINING');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('1b53cd67-a16c-48d4-944c-7b8b5703efa7',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        'de58e8e0-39c6-4c54-b62e-40cacbc6c56d',
		'IDP',
		'UKVI_TRF_SSR_CD',
		'ACADEMIC');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('b2b690f7-f6a2-4a59-afaf-8b1666bab1dd',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        'fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db',
		'IDP',
		'UKVI_TRF_SSR_CD',
		'GENERAL TRAINING');
		
--IDP ETRF
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('2e259f61-bf09-4069-ada6-75c1a3267a14',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        '2948e48b-519b-484e-aed9-93a30a8a9485',
		'IDP',
		'UKVI_ETRF_SSR_IOL',
		'ACADEMIC');
		
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('dc18af3c-56af-4454-8357-2e8203d3fe98',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        '58c171e7-6789-498c-9e2e-e26f4bf8c90c',
		'IDP',
		'UKVI_ETRF_SSR_IOL',
		'GENERAL TRAINING');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('33f165f3-e43f-4e83-b2bf-1aca0cbd220e',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        'de58e8e0-39c6-4c54-b62e-40cacbc6c56d',
		'IDP',
		'UKVI_ETRF_SSR_CD',
		'ACADEMIC');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('3b570b23-28ea-4a29-b2d0-3dd8018f5324',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        'fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db',
		'IDP',
		'UKVI_ETRF_SSR_CD',
		'GENERAL TRAINING'); 

--BC TRF
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('95ca6406-df65-4157-888c-cbabd9b62416',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        '2948e48b-519b-484e-aed9-93a30a8a9485',
		'BC',
		'UKVI_TRF_SSR_IOL',
		'ACADEMIC');
		
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('69ba2550-6ea0-463e-8fb6-135a07721ca4',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        '58c171e7-6789-498c-9e2e-e26f4bf8c90c',
		'BC',
		'UKVI_TRF_SSR_IOL',
		'GENERAL TRAINING');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('10507875-db33-4836-a57f-32d7cb267dc5',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        'de58e8e0-39c6-4c54-b62e-40cacbc6c56d',
		'BC',
		'UKVI_TRF_SSR_CD',
		'ACADEMIC');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('58cdeb60-7319-49a6-a4cb-d2ba033c2928',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        'fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db',
		'BC',
		'UKVI_TRF_SSR_CD',
		'GENERAL TRAINING');
		
--BC ETRF
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('759debfc-0f36-4859-a32a-44d22822bfbf',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        '2948e48b-519b-484e-aed9-93a30a8a9485',
		'BC',
		'UKVI_ETRF_SSR_IOL',
		'ACADEMIC');
		
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('0e6d5fd7-689c-47b6-9a30-0faaca0ffdf7',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        '58c171e7-6789-498c-9e2e-e26f4bf8c90c',
		'BC',
		'UKVI_ETRF_SSR_IOL',
		'GENERAL TRAINING');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('d562c34b-d76a-433d-b28d-948548a4ad10',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        'de58e8e0-39c6-4c54-b62e-40cacbc6c56d',
		'BC',
		'UKVI_ETRF_SSR_CD',
		'ACADEMIC');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('34ffcfeb-f6bb-4375-b9d4-e309ef2565ce',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        'fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db',
		'BC',
		'UKVI_ETRF_SSR_CD',
		'GENERAL TRAINING');
		
--BC_CHN TRF

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('3bf621fa-4db9-4d3b-88b4-e3d8c0bf27eb',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        '2948e48b-519b-484e-aed9-93a30a8a9485',
		'BC_CHN',
		'UKVI_TRF_SSR_IOL',
		'ACADEMIC');
		
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('cc8a5a43-3466-4803-95d8-b815fa1488ff',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        '58c171e7-6789-498c-9e2e-e26f4bf8c90c',
		'BC_CHN',
		'UKVI_TRF_SSR_IOL',
		'GENERAL TRAINING');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('cba45eed-8239-4009-a682-761a29aa68d7',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        'de58e8e0-39c6-4c54-b62e-40cacbc6c56d',
		'BC_CHN',
		'UKVI_TRF_SSR_CD',
		'ACADEMIC');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('59aa307d-2827-41a4-90c5-ebf77054e8bc',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        'fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db',
		'BC_CHN',
		'UKVI_TRF_SSR_CD',
		'GENERAL TRAINING');
		
--BC_CHN ETRF

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('4302a4f0-831f-4c58-a261-54026499cb41',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        '2948e48b-519b-484e-aed9-93a30a8a9485',
		'BC_CHN',
		'UKVI_ETRF_SSR_IOL',
		'ACADEMIC');
		
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('2055692f-38a6-414f-9232-bc2a9db05572',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        '58c171e7-6789-498c-9e2e-e26f4bf8c90c',
		'BC_CHN',
		'UKVI_ETRF_SSR_IOL',
		'GENERAL TRAINING');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('a58ad0b2-69db-4f08-a2cd-d258804d7962',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        'de58e8e0-39c6-4c54-b62e-40cacbc6c56d',
		'BC_CHN',
		'UKVI_ETRF_SSR_CD',
		'ACADEMIC');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('8e179572-7dc9-419e-ad4a-f88b63ad2dc0',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        'fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db',
		'BC_CHN',
		'UKVI_ETRF_SSR_CD',
		'GENERAL TRAINING');