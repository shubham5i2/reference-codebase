CREATE TABLE IF NOT EXISTS rd_owner.document(
	document_uuid UUID NOT NULL,
	event_uuid UUID NOT NULL,
	document_template_uuid UUID NOT NULL,
	booking_uuid UUID NOT NULL,
	document_renditions TEXT,
	CONSTRAINT pk_document PRIMARY KEY (document_uuid)
);