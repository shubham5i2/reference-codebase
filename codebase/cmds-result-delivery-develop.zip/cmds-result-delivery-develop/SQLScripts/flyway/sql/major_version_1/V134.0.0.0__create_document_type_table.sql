CREATE TABLE IF NOT EXISTS rd_owner.document_type
(
    document_type_uuid uuid NOT NULL,
    document_type_code VARCHAR(30) NOT NULL,
	document_type_description VARCHAR(60) NOT NULL,
	effective_from_date DATE NOT NULL DEFAULT '2020-07-01',
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
	created_by VARCHAR(36) NOT NULL DEFAULT 'Operations User',
	updated_by VARCHAR(36),
	created_datetime timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_datetime timestamp with time zone,
    concurrency_version integer NOT NULL DEFAULT 0,
    CONSTRAINT pk_document_type PRIMARY KEY (document_type_uuid)
);
