ALTER TABLE rd_owner.result RENAME COLUMN event_datetime TO status_event_datetime;

ALTER TABLE rd_owner.result ADD COLUMN IF NOT EXISTS result_event_datetime TIMESTAMPTZ;

UPDATE rd_owner.result SET result_event_datetime = status_updated_datetime