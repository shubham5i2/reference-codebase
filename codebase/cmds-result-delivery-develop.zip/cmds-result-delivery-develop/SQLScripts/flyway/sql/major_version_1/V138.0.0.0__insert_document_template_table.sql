insert into rd_owner.document_template(document_template_uuid, document_template_name,partner_code,document_type_uuid,effective_from_date,effective_to_date) values ('ef503b0b-6870-40a0-b7fa-841804c90bdb',
'EOR_POSITIVE_BC','BC','b4e8b611-731a-43c8-8ed2-e72b56685228','2023-09-21','2099-12-31');

insert into rd_owner.document_template(document_template_uuid, document_template_name,partner_code,document_type_uuid,effective_from_date,effective_to_date) values ('d384908c-b4ef-440f-abef-483be41f8adb',
'EOR_POSITIVE_BC','BC_CHN','b4e8b611-731a-43c8-8ed2-e72b56685228','2023-09-21','2099-12-31');


insert into rd_owner.document_template(document_template_uuid, document_template_name,partner_code,document_type_uuid,effective_from_date,effective_to_date) values ('3b8e3d65-3daf-4c32-b62b-0631d1c014a3',
'EOR_NEGATIVE_BC','BC','96ea497a-6485-402f-b5e6-ee4bd3dfd147','2023-09-21','2099-12-31');

insert into rd_owner.document_template(document_template_uuid, document_template_name,partner_code,document_type_uuid,effective_from_date,effective_to_date) values ('b02f3e7a-6509-4736-a52c-b692dee1d441',
'EOR_NEGATIVE_BC','BC_CHN','96ea497a-6485-402f-b5e6-ee4bd3dfd147','2023-09-21','2099-12-31');
