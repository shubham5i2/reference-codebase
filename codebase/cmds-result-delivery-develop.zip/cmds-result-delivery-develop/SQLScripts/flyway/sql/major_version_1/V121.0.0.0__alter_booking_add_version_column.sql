ALTER TABLE rd_owner.booking
ADD COLUMN booking_version integer;