INSERT INTO rd_owner.results_status_label
(results_status_label_uuid, results_status_type_uuid, results_status_label, results_status_label_code, results_status_comment_mandatory, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('a69a26d1-2ef5-48d9-9088-1da741337cbf'::uuid, '3d189282-e531-47f2-aa22-d24eef1d20b6'::uuid, 'Marked Absent in error', 'MARKED_ABSENT_IN_ERROR', false, '2020-07-01', '2099-12-31', 'Operations User', now(), NULL, NULL, 0);
