CREATE TABLE IF NOT EXISTS rd_owner.document_template
(
    document_template_uuid uuid NOT NULL,
    document_template_name VARCHAR(25) NOT NULL,
	partner_code VARCHAR(20) NOT NULL,
    document_type_uuid uuid NOT NULL,
	effective_from_date DATE NOT NULL DEFAULT '2020-07-01',
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
	created_by VARCHAR(36) NOT NULL DEFAULT 'Operations User',
	updated_by VARCHAR(36),
	created_datetime timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_datetime timestamp with time zone,
    concurrency_version integer NOT NULL DEFAULT 0,
    CONSTRAINT pk_document_template PRIMARY KEY (document_template_uuid),
	CONSTRAINT uk_01_document_type_uuid_partner_code UNIQUE(partner_code, document_type_uuid)
);
