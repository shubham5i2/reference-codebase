INSERT INTO rd_owner.test_taker_photo_type(
    photo_type_uuid, photo_type_code, photo_type_description, updated_datetime, concurrency_version, created_by)
    VALUES ('1050fc8a-0fe8-4395-94db-e76cb047104a', 'TT_ID_S_WC', 'TT Identity document - Speaking- Web-Cam TT Web-cam for IaH Speaking test only', NULL, '1', 'Operations User')ON CONFLICT(photo_type_uuid) DO NOTHING;
	