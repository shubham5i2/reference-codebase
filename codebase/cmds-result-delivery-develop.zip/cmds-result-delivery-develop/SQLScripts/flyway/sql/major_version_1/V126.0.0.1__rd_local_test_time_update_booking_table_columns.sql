-- To add new columns

ALTER TABLE rd_owner.booking
ADD COLUMN IF NOT EXISTS test_date_string varchar(40),
ADD COLUMN IF NOT EXISTS timezone_offset varchar(200),
ADD COLUMN IF NOT EXISTS test_date_utc timestamptz;
