-- Insert new product photo types [TT_P_HR_IAM_ADD, TT_P_HR_IAM_ADD, TT_P_ORIGINAL_BOOKING_ADD] for products [IOC SELT OSR AC, IOC SELT OSR GT]

INSERT INTO rd_owner.product_photo_type(product_photo_type_uuid, product_uuid, photo_type_uuid)
VALUES
('41c7f20c-a56c-498d-962b-4dceb54851eb', 'de58e8e0-39c6-4c54-b62e-40cacbc6c56d', 'a101702b-d8dd-4bcd-bcc5-a39cc6cf6fc5'),
('074d6ae6-568c-4ed2-8dee-16bbc6a86031', 'de58e8e0-39c6-4c54-b62e-40cacbc6c56d', 'd03a1dbc-d00b-4e7d-89da-859248fbf7de'),
('575de2b0-53c7-4814-bba4-2811139b5059', 'de58e8e0-39c6-4c54-b62e-40cacbc6c56d', 'af60ef99-86bb-4c52-a9a6-3a38bd7e4b0b'),
('44a5ffee-6458-428d-b799-5bef9de8c4dd', 'fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db', 'a101702b-d8dd-4bcd-bcc5-a39cc6cf6fc5'),
('6873751c-2fa8-47d0-86a5-a924e0b787cf', 'fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db', 'd03a1dbc-d00b-4e7d-89da-859248fbf7de'),
('efe97805-93ba-442b-8ddb-87b04c17aea2', 'fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db', 'af60ef99-86bb-4c52-a9a6-3a38bd7e4b0b')
ON CONFLICT(product_photo_type_uuid) DO NOTHING;
