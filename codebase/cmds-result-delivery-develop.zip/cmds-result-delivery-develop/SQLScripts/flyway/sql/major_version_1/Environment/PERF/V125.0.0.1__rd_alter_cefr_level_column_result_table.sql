alter table rd_owner.result alter column cefr_level TYPE varchar(32);
