
-- Delete TT_P_HR_IAM_ADD configuration for UKVI IOC OSR AC/GT products.
DELETE FROM rd_owner.product_photo_type
WHERE product_photo_type_uuid IN ('074d6ae6-568c-4ed2-8dee-16bbc6a86031', '6873751c-2fa8-47d0-86a5-a924e0b787cf');

-- Add SSR_ORIGINAL_BOOKING_TRF configuration for UKVI IOC OSR AC/GT products.
INSERT INTO rd_owner.product_photo_type(product_photo_type_uuid, product_uuid, photo_type_uuid)
VALUES
('074d6ae6-568c-4ed2-8dee-16bbc6a86031', 'de58e8e0-39c6-4c54-b62e-40cacbc6c56d', '5a8ca226-7e07-4819-9af0-7dae099a26c2'),
('6873751c-2fa8-47d0-86a5-a924e0b787cf', 'fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db', '5a8ca226-7e07-4819-9af0-7dae099a26c2')
ON CONFLICT(product_photo_type_uuid) DO NOTHING;
