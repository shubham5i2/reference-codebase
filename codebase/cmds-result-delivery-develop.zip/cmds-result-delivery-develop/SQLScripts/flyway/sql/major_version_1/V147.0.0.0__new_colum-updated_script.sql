UPDATE rd_owner.result_delivery SET
	status_received_datetime = (status_updated_datetime::timestamp AT TIME ZONE 'UTC')
WHERE status_received_datetime IS NULL;