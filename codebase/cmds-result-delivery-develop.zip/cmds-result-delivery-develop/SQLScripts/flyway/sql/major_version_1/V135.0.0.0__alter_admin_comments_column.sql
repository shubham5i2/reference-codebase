alter table rd_owner.result alter column administrator_comments type varchar(1000);
