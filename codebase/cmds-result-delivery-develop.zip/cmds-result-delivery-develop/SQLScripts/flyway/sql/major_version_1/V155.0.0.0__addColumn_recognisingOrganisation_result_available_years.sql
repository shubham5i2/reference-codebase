ALTER TABLE rd_owner.recognising_organisation
ADD COLUMN IF NOT EXISTS result_available_for_years INTEGER DEFAULT 3;
