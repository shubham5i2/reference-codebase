-- Insert new product photo types [TT_P_HR_IAM_ADD, TT_P_HR_IAM_ADD] for products [IOC SELT AC, IOC SELT GT]

INSERT INTO rd_owner.product_photo_type(product_photo_type_uuid, product_uuid, photo_type_uuid)
VALUES
('04783f74-7107-439a-b53e-46a3cd3c0720', '6d04f596-22f2-49c4-9d47-85b167b8ca6f', 'a101702b-d8dd-4bcd-bcc5-a39cc6cf6fc5'),
('646abb84-f1d4-4398-8fae-ac50c059ad9a', '6d04f596-22f2-49c4-9d47-85b167b8ca6f', 'd03a1dbc-d00b-4e7d-89da-859248fbf7de'),
('6b39ec9c-9d25-4db4-9440-6214c3849227', '54b9d8df-c07a-4cb4-b397-adc4faa87c3f', 'a101702b-d8dd-4bcd-bcc5-a39cc6cf6fc5'),
('ad28c1a2-144a-4656-a2e4-0471a569dd10', '54b9d8df-c07a-4cb4-b397-adc4faa87c3f', 'd03a1dbc-d00b-4e7d-89da-859248fbf7de')
ON CONFLICT(product_photo_type_uuid) DO NOTHING;
