CREATE TABLE IF NOT EXISTS rd_owner.event(
	event_uuid UUID NOT NULL,
	event_name varchar(100) NOT NULL,
	booking_uuid UUID NOT NULL,
	transaction_uuid UUID NOT NULL,
	event_body jsonb NOT NULL,
	event_datetime timestamp with time zone NOT NULL, 
	created_datetime timestamp with time zone NOT NULL,
	CONSTRAINT pk_event PRIMARY KEY (event_uuid),
	CONSTRAINT uk_01_event_booking_uuid_transaction_uuid UNIQUE(booking_uuid, transaction_uuid)
);

CREATE INDEX IF NOT EXISTS idx_event_event_name  ON rd_owner.event(event_name);

CREATE INDEX IF NOT EXISTS idx_event_booking_uuid  ON rd_owner.event(booking_uuid);

CREATE INDEX IF NOT EXISTS idx_event_transaction_uuid  ON rd_owner.event(transaction_uuid);