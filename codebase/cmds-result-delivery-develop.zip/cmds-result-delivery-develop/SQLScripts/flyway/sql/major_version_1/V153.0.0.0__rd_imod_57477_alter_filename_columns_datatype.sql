--Change document_template_name column datatype from VARCHAR to TEXT

ALTER TABLE rd_owner.document_template ALTER COLUMN document_template_name TYPE TEXT;

--Change template_name column datatype from VARCHAR to TEXT

ALTER TABLE rd_owner.product_config ALTER COLUMN template_name TYPE TEXT;

--Change rendition_file_path column datatype from VARCHAR to TEXT

ALTER TABLE rd_owner.results_rendition ALTER COLUMN rendition_file_path TYPE TEXT;

--Change file_path column datatype from VARCHAR to TEXT

ALTER TABLE rd_owner.test_taker_photo ALTER COLUMN file_path TYPE TEXT;
