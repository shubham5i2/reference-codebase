INSERT INTO rd_owner.result_type(result_type_uuid, result_type,  result_type_code, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('2bf8a999-5da5-4a87-aa04-a7b205272b30',
		'Pending EOR',
		'PENDING_EOR',
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(result_type_uuid) DO NOTHING;

