CREATE TABLE IF NOT exists rd_owner.product_photo_type(
	product_photo_type_uuid uuid NOT NULL,
	product_uuid uuid NOT NULL,
	photo_type_uuid uuid NOT NULL,
	created_by varchar(36) NOT NULL DEFAULT 'Operations User',
	created_datetime timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_by varchar(36) NULL,
	updated_datetime timestamptz NULL,
	concurrency_version int4 NOT NULL DEFAULT 0,
	CONSTRAINT pk_product_photo_type PRIMARY KEY (product_photo_type_uuid)
	);
