--DML script for results type

INSERT INTO rd_owner.result_type(result_type_uuid, result_type,  result_type_code, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('385eb1aa-d205-481e-af0c-cd5afab98402',
		'Incomplete',
        'INCOMPLETE',
		'2023-05-08',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(result_type_uuid) DO NOTHING;