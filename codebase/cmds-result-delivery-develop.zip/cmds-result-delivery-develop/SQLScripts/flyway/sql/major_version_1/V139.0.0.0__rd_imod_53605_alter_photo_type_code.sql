--Alter the photo_type_code type and add new types

ALTER type rd_owner.photo_type_code ADD VALUE 'TT_P_HR_IAM_ADD';

ALTER type rd_owner.photo_type_code ADD VALUE 'TT_P_ORIGINAL_BOOKING_ADD';
