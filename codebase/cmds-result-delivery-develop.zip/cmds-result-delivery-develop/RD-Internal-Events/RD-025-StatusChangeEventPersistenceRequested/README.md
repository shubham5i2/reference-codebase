
# RD-025-StatusChangeEventPersistenceRequested Event
RD-025-StatusChangeEventPersistenceRequested Event




Event published by _____


Put description here


| Code | Description |
| ---- | ----------- |
| 202 | Accepted |



| Name | Type | Description | Required |
| ---- | ---- | ----------- | -------- |


| Name | Type | Description | Required |
| ---- | ---- | ----------- | -------- |
