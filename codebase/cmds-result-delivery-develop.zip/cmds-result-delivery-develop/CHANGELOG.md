## [7.2.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v7.1.4...v7.2.0) (2024-05-16)


### Features

* <h2>Technical Features</h2><h3>IMOD-52995 RD: BookingCreated event SQS Segregation</h3><p><h3>IMOD-52997 RD: PhotoPublished event SQS Segregation</h3><h3>IMOD-53007 RD: LegacyResultPublihed event SQS Segregation</h3><h3>IMOD-61780 update to latest outbox processor version</h3><p><ol><li>DevOps Ticket: IMOD-61955</li><li>Infra Ticket: IMOD-60530</li></ol> ([313c7a7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/commit/313c7a7b596c2e39ea44ce7eba0c8b569ddedc8b))

### [7.1.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v7.1.3...v7.1.4) (2024-05-10)


### ⚠ BREAKING CHANGES

* IMOD-61780 &  IMOD-61781 update outbox library. Add constraint validation logs

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery!604

* Merge branch 'feature/IMOD-61780-update_outbox_library' into 'develop' ([d52af1b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/commit/d52af1b0cb8c361f96e0230142ed6cb0ea99952a))

### [7.1.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v7.1.2...v7.1.3) (2024-04-30)

### [7.1.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v7.1.1...v7.1.2) (2024-04-30)

### [7.1.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v7.1.0...v7.1.1) (2024-04-30)

### [7.1.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v7.1.0...v7.1.1-hotfix.1) (2024-04-19)

### [6.27.1-hotfix.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.27.1-hotfix.2...v6.27.1-hotfix.3) (2024-04-19)

### [6.27.1-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.27.1-hotfix.1...v6.27.1-hotfix.2) (2024-04-03)

### [6.27.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.27.0...v6.27.1-hotfix.1) (2024-03-15)

## [7.1.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v7.0.4...v7.1.0) (2024-04-12)

### [7.0.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v7.0.3...v7.0.4) (2024-04-09)

### [7.0.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v7.0.2...v7.0.3) (2024-04-08)

### [7.0.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v7.0.1...v7.0.2) (2024-04-05)

### [7.0.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v7.0.0...v7.0.1) (2024-04-04)

## [7.0.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.32.4...v7.0.0) (2024-04-03)

### [6.32.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.32.3...v6.32.4) (2024-03-26)

### [6.27.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.27.0...v6.27.1-hotfix.1) (2024-03-15)

### [6.32.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.32.2...v6.32.3) (2024-03-25)

### [6.32.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.32.1...v6.32.2) (2024-03-19)

### [6.32.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.32.0...v6.32.1) (2024-03-07)

## [6.32.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.31.1...v6.32.0) (2024-03-07)


### Features

* <h2>Business Features</h2><h3>	IMOD-57415 RD Mx: TRF/eTRF template configuration for IOC UKVI OSR BC China bookings</h3><p><strong>Purpose:</strong><br />Test Taker’s ‘Country or Region of Origin’ field data to be populated for IOC UKVI OSR BC China bookings.So that TRF/eTRF business rules for BC China booking can be adhered<h3>	IMOD-57414 RD Mx: TRF/eTRF template configuration for IOC OSR BC China bookings</h3><p><strong>Purpose:</strong><br /> Test Taker’s ‘Country or Region of Origin’ field data to be populated for IOC OSR BC China bookings So that TRF/eTRF business rules for BC China booking can be adhered.<h2>Technical Features</h2><h3>	IMOD-57477 	[RD] Change data type of 'fileName' column to text in the database</h3><ol><li>DevOps Ticket: IMOD-59123</li></ol> ([9d371cc](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/commit/9d371cc9a116ea5d6c3cfa4d4865ed56985de1d4))

### [6.31.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.31.0...v6.31.1) (2024-03-05)

## [6.31.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.30.0...v6.31.0) (2024-02-28)

## [6.30.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.29.1...v6.30.0) (2024-02-26)

### [6.29.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.29.0...v6.29.1) (2024-02-21)

## [6.29.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.28.0...v6.29.0) (2024-02-21)

## [6.28.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.27.0...v6.28.0) (2024-02-09)


## [6.27.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.26.0...v6.27.0) (2024-02-08)

## [6.26.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.25.5...v6.26.0) (2024-02-07)

### [6.25.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.25.4...v6.25.5) (2024-02-06)

### [6.25.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.25.3...v6.25.4) (2024-01-30)

### [6.25.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.25.2...v6.25.3) (2024-01-29)

### [6.25.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.25.1...v6.25.2) (2024-01-19)

### [6.25.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.25.0...v6.25.1) (2024-01-17)

## [6.25.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.24.2...v6.25.0) (2024-01-16)

### [6.24.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.24.1...v6.24.2) (2024-01-11)

### [6.24.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.24.0...v6.24.1) (2024-01-10)


### ⚠ BREAKING CHANGES

* Fix data type issue

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery!555

* Merge branch 'feature/bugFix' into 'develop' ([6c1e287](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/commit/6c1e2871d2782e26b3ecf6fa6c321224384731eb))

## [6.24.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.23.0...v6.24.0) (2024-01-10)

## [6.23.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.22.0...v6.23.0) (2024-01-09)

## [6.22.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.21.1...v6.22.0) (2024-01-08)

### [6.21.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.21.0...v6.21.1) (2024-01-04)

## [6.21.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.20.0...v6.21.0) (2024-01-02)

## [6.20.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.19.3...v6.20.0) (2023-12-21)

### [6.19.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.19.2...v6.19.3) (2023-12-13)

### [6.19.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.19.1...v6.19.2) (2023-12-12)

### [6.19.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.19.0...v6.19.1) (2023-11-28)

## [6.19.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.18.0...v6.19.0) (2023-11-27)

## [6.18.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.17.1...v6.18.0) (2023-11-17)

### [6.17.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.17.0...v6.17.1) (2023-11-16)

## [6.17.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.16.0...v6.17.0) (2023-11-15)

## [6.16.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.15.0...v6.16.0) (2023-11-14)

## [6.15.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.14.0...v6.15.0) (2023-11-14)

## [6.14.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.13.2...v6.14.0) (2023-11-14)

### [6.13.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.13.1...v6.13.2) (2023-11-03)

### [6.13.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.13.0...v6.13.1) (2023-10-31)

## [6.13.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.12.4...v6.13.0) (2023-10-30)

### [6.12.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.12.3...v6.12.4) (2023-10-27)


### ⚠ BREAKING CHANGES

* Use release version for internal and UI events

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery!519

* Merge branch 'feature/Release-Version-Pipeline' into 'develop' ([3501003](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/commit/350100314590b685558738e59e7f2dbbb895189c))

### [6.12.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.12.2...v6.12.3) (2023-10-27)

### [6.4.3-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.4.2...v6.4.3-hotfix.1) (2023-10-09)

### [6.12.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.12.1...v6.12.2) (2023-10-06)

### [6.12.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.12.0...v6.12.1) (2023-10-05)

## [6.12.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.11.0...v6.12.0) (2023-10-04)

## [6.11.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.10.2...v6.11.0) (2023-10-03)

### [6.10.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.10.1...v6.10.2) (2023-09-26)

### [6.10.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.10.0...v6.10.1) (2023-09-26)

## [6.10.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.9.0...v6.10.0) (2023-09-25)

## [6.9.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.8.0...v6.9.0) (2023-09-25)


### Features

* <h2>Business Features</h2><h3>IMOD-39417 RD: Use local test date on TRFs for all IELTS products</h3><p><strong>Purpose:</strong><br />  RD to use local test date in TRF number for all IELTS products So that the TRF number will have the right info<h3>IMOD-42950 UI: Display  local test date in RM & RD specific UI pages</h3><p><strong>Purpose:</strong><br />Display the local test date of the bookings in the RM & RD specific UI pages.<h3>IMOD-40436 RD: Generate TRF/eTRF with admin comments included</h3><p><strong>Purpose:</strong><br /> RD to display the defined admin comments in the TRF/eTRF documents.<ol><li>DevOps Ticket: IMOD-51277</li></ol> ([88e3ad3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/commit/88e3ad365cb9da478b797f5a866f9cda95e1209b))

## [6.8.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.7.0...v6.8.0) (2023-09-21)

## [6.7.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.6.1...v6.7.0) (2023-09-20)

### [6.6.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.6.0...v6.6.1) (2023-09-19)

## [6.6.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.5.1...v6.6.0) (2023-09-15)

### [6.5.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.5.0...v6.5.1) (2023-09-14)

## [6.5.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.4.5...v6.5.0) (2023-09-12)

### [6.4.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.4.4...v6.4.5) (2023-09-06)

### [6.4.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.4.3...v6.4.4) (2023-08-25)

### [6.1.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.1.0...v6.1.1-hotfix.1) (2023-08-14)

### [6.4.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.4.2...v6.4.3) (2023-08-23)
>>>>>>> c7a28e2b426dd326bf947ea59678125381e133d7

### [6.4.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.4.1...v6.4.2) (2023-08-23)

### [6.4.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.4.0...v6.4.1) (2023-08-18)

## [6.4.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.3.0...v6.4.0) (2023-08-18)

## [6.3.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.2.3...v6.3.0) (2023-08-16)

### [6.2.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.2.2...v6.2.3) (2023-08-11)

### [6.2.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.2.1...v6.2.2) (2023-08-10)

### [6.2.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.2.0...v6.2.1) (2023-08-09)

## [6.2.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.1.0...v6.2.0) (2023-08-09)

## [6.1.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.0.3...v6.1.0) (2023-08-08)


### Features

* <h2>Business Features</h2><h3>IMOD-44422 Update IOC TRF & eTRF template to use Open Sans font</h3><p><strong>Purpose:</strong><br />Update TRF & ETRF template of IOC bookings to use Open Sans Font in order to support latin diacritics in name.<h3>IMOD-44423 Update IOC OSR TRF & eTRF template to use Open Sans font</h3><p><strong>Purpose:</strong><br />Update TRF & ETRF template of IOC OSR bookings to use Open Sans Font in order to support latin diacritics in name.<h3>IMOD-44425 Update IOL TRF & eTRF template to use Open Sans font</h3><p><strong>Purpose:</strong><br />Update TRF & ETRF template of IOL bookings to use Open Sans Font in order to support latin diacritics in name.<h3>IMOD-44426 Update IOL OSR TRF & eTRF template to use Open Sans font</h3><p><strong>Purpose:</strong><br />Update TRF & ETRF template of IOL OSR bookings to use Open Sans Font in order to support latin diacritics in name.<h3>IMOD-44428 Update IOC UKVI TRF & eTRF template to use Open Sans font</h3><p><strong>Purpose:</strong><br />Update TRF & ETRF template of IOC UKVI bookings to use Open Sans Font in order to support latin diacritics in name.<h3>IMOD-44429 Update IOL UKVI TRF & eTRF template to use Open Sans font</h3><p><strong>Purpose:</strong><br />Update TRF & ETRF template of IOL UKVI bookings to use Open Sans Font in order to support latin diacritics in name.<h3>IMOD-47018 Generate IOC UKVI OSR TRF & eTRF template</h3><p><strong>Purpose:</strong><br />Generate reports for IOC UKVI OSR booking.<h3>IMOD-48997 Updated versions of TRF & eTRF Open Sans templates (8 templates, non-UKVI)</h3><p><strong>Purpose:</strong><br />To use approved non-ukvi templates for generation.<h3>IMOD-49082 Updated versions of TRF & eTRF Open Sans templates (6 templates, UKVI)</h3><p><strong>Purpose:</strong><br />To use approved non-ukvi templates for generation.<ol><li>DevOps Ticket: IMOD-49597</li></ol> ([bb4c3e6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/commit/bb4c3e6c2db7ffcbbd91af67d49cd1dadc7d5660))

### [6.0.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.0.2...v6.0.3) (2023-08-07)

### [6.0.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.0.1...v6.0.2) (2023-08-04)


### Features

* <h2>Business Features</h2><h3>IMOD-47856 Update validation stamp in all eTRF templates - Open Sans</h3><p><strong>Purpose:</strong><br />Update stamps in all ETRF templates with openSans font<h3>IMOD-44422 Update IOC TRF & eTRF template to use Open Sans font</h3><p><strong>Purpose:</strong><br />Update TRF & ETRF template of IOC bookings to use Open Sans Font in order to support latin diacritics in name.<h3>IMOD-44423 Update IOC OSR TRF & eTRF template to use Open Sans font</h3><p><strong>Purpose:</strong><br />Update TRF & ETRF template of IOC OSR bookings to use Open Sans Font in order to support latin diacritics in name.<h3>IMOD-44425 Update IOL TRF & eTRF template to use Open Sans font</h3><p><strong>Purpose:</strong><br />Update TRF & ETRF template of IOL bookings to use Open Sans Font in order to support latin diacritics in name.<h3>IMOD-44426 Update IOL OSR TRF & eTRF template to use Open Sans font</h3><p><strong>Purpose:</strong><br />Update TRF & ETRF template of IOL OSR bookings to use Open Sans Font in order to support latin diacritics in name.<h3>IMOD-44428 Update IOC UKVI TRF & eTRF template to use Open Sans font</h3><p><strong>Purpose:</strong><br />Update TRF & ETRF template of IOC UKVI bookings to use Open Sans Font in order to support latin diacritics in name.<h3>IMOD-44429 Update IOL UKVI TRF & eTRF template to use Open Sans font</h3><p><strong>Purpose:</strong><br />Update TRF & ETRF template of IOL UKVI bookings to use Open Sans Font in order to support latin diacritics in name.<h3>IMOD-44391 RD: Consume results type and status 'Incomplete' from LPR</h3><p><strong>Purpose:</strong><br />Consume results type and status "Incomplete" from LPR so that the data in RD is in sync with LPR.<h3>IMOD-45040 Process UKVI IOC OSR Results (AC & GT)</h3><p><strong>Purpose:</strong><br />Process results for UKVI IOC OSR booking.<h3>IMOD-47018 Generate IOC UKVI OSR TRF & eTRF template</h3><p><strong>Purpose:</strong><br />Generate reports for IOC UKVI OSR booking.<h2>Technical Stories</h2><h3>IMOD-46705 RD - Copy scripts from LPR Mx to activate UKVI IOC OSR product</h3><h3>IMOD-40655 RD: Upgrade for Object Serialized Event Consumption in rd-mx</h3><p><strong>Purpose:</strong><br />Result Delivery Microservice Event serialization consumer changes.<h3>IMOD-40657 RD: Upgrade for Object Serialized Event Consumption in rd-ui-receiver</h3><p><strong>Purpose:</strong><br />RD Mx Event serialization consumer changes for rd-ui-receiver lambda.<h2>Bug Fixes</h2><h3>IMOD-45110 PERF - Result status code is coming null and not present in RD DB</h3><ol><li>DevOps Ticket: IMOD-47936</li><li>Infra Ticket: IMOD-45839</li></ol> ([23db3b5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/commit/23db3b50378caaed84ca5af3dc6e5f8ba687b92a))

### [6.0.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v6.0.0...v6.0.1) (2023-07-18)

## [6.0.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v5.4.0...v6.0.0) (2023-07-18)


### Features

* <h2>Business Features</h2><h3>IMOD-44422 Update IOC TRF & eTRF template to use Open Sans font</h3><p><strong>Purpose:</strong><br />Update TRF & ETRF template of IOC bookings to use Open Sans Font in order to support latin diacritics in name.<h3>IMOD-44423 Update IOC OSR TRF & eTRF template to use Open Sans font</h3><p><strong>Purpose:</strong><br />Update TRF & ETRF template of IOC OSR bookings to use Open Sans Font in order to support latin diacritics in name.<h3>IMOD-44425 Update IOL TRF & eTRF template to use Open Sans font</h3><p><strong>Purpose:</strong><br />Update TRF & ETRF template of IOL bookings to use Open Sans Font in order to support latin diacritics in name.<h3>IMOD-44426 Update IOL OSR TRF & eTRF template to use Open Sans font</h3><p><strong>Purpose:</strong><br />Update TRF & ETRF template of IOL OSR bookings to use Open Sans Font in order to support latin diacritics in name.<h3>IMOD-44428 Update IOC UKVI TRF & eTRF template to use Open Sans font</h3><p><strong>Purpose:</strong><br />Update TRF & ETRF template of IOC UKVI bookings to use Open Sans Font in order to support latin diacritics in name.<h3>IMOD-44429 Update IOL UKVI TRF & eTRF template to use Open Sans font</h3><p><strong>Purpose:</strong><br />Update TRF & ETRF template of IOL UKVI bookings to use Open Sans Font in order to support latin diacritics in name.<h3>IMOD-44391 RD: Consume results type and status 'Incomplete' from LPR</h3><p><strong>Purpose:</strong><br />Consume results type and status "Incomplete" from LPR so that the data in RD is in sync with LPR.<h3>IMOD-45040 Process UKVI IOC OSR Results (AC & GT)</h3><p><strong>Purpose:</strong><br />Process results for UKVI IOC OSR booking.<h3>IMOD-47018 Generate IOC UKVI OSR TRF & eTRF template</h3><p><strong>Purpose:</strong><br />Generate reports for IOC UKVI OSR booking.<h2>Technical Stories</h2><h3>IMOD-46705 RD - Copy scripts from LPR Mx to activate UKVI IOC OSR product</h3><h3>IMOD-40655 RD: Upgrade for Object Serialized Event Consumption in rd-mx</h3><p><strong>Purpose:</strong><br />Result Delivery Microservice Event serialization consumer changes.<h3>IMOD-40657 RD: Upgrade for Object Serialized Event Consumption in rd-ui-receiver</h3><p><strong>Purpose:</strong><br />RD Mx Event serialization consumer changes for rd-ui-receiver lambda.<h2>Bug Fixes</h2><h3>IMOD-45110 PERF - Result status code is coming null and not present in RD DB</h3><ol><li>DevOps Ticket: IMOD-47936</li><li>Infra Ticket: IMOD-45839</li></ol> ([a3eea41](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/commit/a3eea41b8c497bfcfd0189238a62d6ec249e51fb))
* <h2>Business Features</h2><h3>IMOD-44422 Update IOC TRF & eTRF template to use Open Sans font</h3><p><strong>Purpose:</strong><br />Update TRF & ETRF template of IOC bookings to use Open Sans Font in order to support latin diacritics in name.<h3>IMOD-44423 Update IOC OSR TRF & eTRF template to use Open Sans font</h3><p><strong>Purpose:</strong><br />Update TRF & ETRF template of IOC OSR bookings to use Open Sans Font in order to support latin diacritics in name.<h3>IMOD-44425 Update IOL TRF & eTRF template to use Open Sans font</h3><p><strong>Purpose:</strong><br />Update TRF & ETRF template of IOL bookings to use Open Sans Font in order to support latin diacritics in name.<h3>IMOD-44426 Update IOL OSR TRF & eTRF template to use Open Sans font</h3><p><strong>Purpose:</strong><br />Update TRF & ETRF template of IOL OSR bookings to use Open Sans Font in order to support latin diacritics in name.<h3>IMOD-44428 Update IOC UKVI TRF & eTRF template to use Open Sans font</h3><p><strong>Purpose:</strong><br />Update TRF & ETRF template of IOC UKVI bookings to use Open Sans Font in order to support latin diacritics in name.<h3>IMOD-44429 Update IOL UKVI TRF & eTRF template to use Open Sans font</h3><p><strong>Purpose:</strong><br />Update TRF & ETRF template of IOL UKVI bookings to use Open Sans Font in order to support latin diacritics in name.<h3>IMOD-44391 RD: Consume results type and status 'Incomplete' from LPR</h3><p><strong>Purpose:</strong><br />Consume results type and status "Incomplete" from LPR so that the data in RD is in sync with LPR.<h3>IMOD-45040 Process UKVI IOC OSR Results (AC & GT)</h3><p><strong>Purpose:</strong><br />Process results for UKVI IOC OSR booking.<h3>IMOD-47018 Generate IOC UKVI OSR TRF & eTRF template</h3><p><strong>Purpose:</strong><br />Generate reports for IOC UKVI OSR booking.<h2>Technical Stories</h2><h3>IMOD-46705 RD - Copy scripts from LPR Mx to activate UKVI IOC OSR product</h3><h3>IMOD-40655 RD: Upgrade for Object Serialized Event Consumption in rd-mx</h3><p><strong>Purpose:</strong><br />Result Delivery Microservice Event serialization consumer changes.<h3>IMOD-40657 RD: Upgrade for Object Serialized Event Consumption in rd-ui-receiver</h3><p><strong>Purpose:</strong><br />RD Mx Event serialization consumer changes for rd-ui-receiver lambda.<h2>Bug Fixes</h2><h3>IMOD-45110 PERF - Result status code is coming null and not present in RD DB</h3><ol><li>DevOps Ticket: IMOD-47936</li><li>Infra Ticket: IMOD-45839</li></ol> ([ea3f38a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/commit/ea3f38af0bc678236f2fba0b499be32114c5baf0))

## [5.4.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v5.3.0...v5.4.0) (2023-06-28)

## [5.3.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v5.2.1...v5.3.0) (2023-06-28)

### [5.2.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v5.2.0...v5.2.1) (2023-06-26)

## [5.2.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v5.1.2...v5.2.0) (2023-06-15)

### [5.1.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v5.1.1...v5.1.2) (2023-06-05)

### [5.1.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v5.1.0...v5.1.1) (2023-05-31)

## [5.1.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v5.0.1...v5.1.0) (2023-05-17)

### [5.0.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v5.0.0...v5.0.1) (2023-05-12)

## [5.0.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.24.2...v5.0.0) (2023-05-09)

### [4.24.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.24.1...v4.24.2) (2023-04-28)

### [4.24.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.24.0...v4.24.1) (2023-04-28)

## [4.24.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.23.0...v4.24.0) (2023-04-25)

### [4.14.1-hotfix.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.14.1-hotfix.3...v4.14.1-hotfix.4) (2023-04-06)

### [4.14.1-hotfix.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.14.1-hotfix.2...v4.14.1-hotfix.3) (2023-04-06)

### [4.14.1-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.14.1-hotfix.1...v4.14.1-hotfix.2) (2023-02-24)

### [4.14.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.14.0...v4.14.1-hotfix.1) (2023-02-22)

## [4.23.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.22.0...v4.23.0) (2023-04-10)

## [4.22.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.21.1...v4.22.0) (2023-04-06)

### [4.14.1-hotfix.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.14.1-hotfix.2...v4.14.1-hotfix.3) (2023-04-06)

### [4.14.1-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.14.1-hotfix.1...v4.14.1-hotfix.2) (2023-02-24)

### [4.14.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.14.0...v4.14.1-hotfix.1) (2023-02-22)

### [4.21.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.21.0...v4.21.1) (2023-02-27)

### [4.14.1-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.14.1-hotfix.1...v4.14.1-hotfix.2) (2023-02-24)

### [4.14.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.14.0...v4.14.1-hotfix.1) (2023-02-22)

## [4.21.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.20.0...v4.21.0) (2023-02-27)

## [4.20.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.19.1...v4.20.0) (2023-02-21)

### [4.19.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.19.0...v4.19.1) (2023-02-10)

## [4.19.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.18.0...v4.19.0) (2023-02-02)

## [4.18.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.17.0...v4.18.0) (2023-02-01)

## [4.17.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.16.0...v4.17.0) (2023-01-30)

## [4.16.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.15.1...v4.16.0) (2023-01-30)

### [4.15.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.15.0...v4.15.1) (2023-01-30)


### ⚠ BREAKING CHANGES

* Update lpr events to accept BC_CHN

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery!397

* Merge branch 'feature/BC_CHN_lpr_events_change' into 'develop' ([7bcdaf5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/commit/7bcdaf508ca2d82b2748a149fca6059028ad83fd))

## [4.15.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.14.1...v4.15.0) (2023-01-25)

### [4.14.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.14.0...v4.14.1) (2023-01-24)

## [4.14.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.13.2...v4.14.0) (2023-01-17)

### [4.13.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.13.1...v4.13.2) (2023-01-06)

### [4.13.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.13.0...v4.13.1) (2023-01-04)

## [4.13.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.12.0...v4.13.0) (2022-12-13)

## [4.12.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.11.4...v4.12.0) (2022-11-22)

### [4.11.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.11.3...v4.11.4) (2022-11-18)

### [4.11.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.11.2...v4.11.3) (2022-11-10)

### [4.11.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.11.1...v4.11.2) (2022-11-09)

### [4.11.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.11.0...v4.11.1) (2022-11-07)

## [4.11.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.10.0...v4.11.0) (2022-11-02)

## [4.10.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.9.8...v4.10.0) (2022-10-26)

### [4.9.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.9.7...v4.9.8) (2022-10-21)

### [4.9.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.9.6...v4.9.7) (2022-10-18)

### [4.9.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.9.5...v4.9.6) (2022-10-18)

### [4.9.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.9.4...v4.9.5) (2022-10-13)

### [4.9.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.9.3...v4.9.4) (2022-10-12)

### [4.9.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.9.2...v4.9.3) (2022-10-12)

### [4.9.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.9.1...v4.9.2) (2022-10-07)


### ⚠ BREAKING CHANGES

* Branch to create release version for IMOD-36596- Hotfix- admin signature field templates in SIT (Dummy Changes)

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery!358
* IMOD-36596- Prod Hotfix- admin signature field templates

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery!356

* Merge branch 'feature/branch_to_create_release' into 'develop' ([ccad072](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/commit/ccad0727a9a39703802cc4a57e5da0766f6afe8d))
* Merge branch 'hotfix' into 'develop' ([874265d](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/commit/874265d71a74225e3b8a4212390be724afe4ceb5))

### [4.1.5-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.1.4...v4.1.5-hotfix.1) (2022-10-07)

### [4.9.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.9.0...v4.9.1) (2022-09-26)

## [4.9.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.8.0...v4.9.0) (2022-09-23)

## [4.8.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.7.0...v4.8.0) (2022-09-22)

## [4.7.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.6.0...v4.7.0) (2022-09-22)

## [4.6.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.5.2...v4.6.0) (2022-09-21)

### [4.5.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.5.1...v4.5.2) (2022-09-20)

### [4.5.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.5.0...v4.5.1) (2022-09-20)

## [4.5.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.4.0...v4.5.0) (2022-09-19)

## [4.4.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.3.1...v4.4.0) (2022-09-19)

### [4.3.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.3.0...v4.3.1) (2022-09-19)

## [4.3.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.2.0...v4.3.0) (2022-09-16)

## [4.2.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.1.4...v4.2.0) (2022-09-14)

### [4.1.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.1.3...v4.1.4) (2022-09-12)

### [4.1.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.1.2...v4.1.3) (2022-09-01)

### [4.1.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.1.1...v4.1.2) (2022-08-30)

### [4.1.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.1.0...v4.1.1) (2022-08-26)

## [4.1.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.0.0...v4.1.0) (2022-08-25)

## [4.0.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.11.1...v4.0.0) (2022-08-24)

### [3.11.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.11.0...v3.11.1) (2022-08-18)

## [3.11.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.10.1...v3.11.0) (2022-08-10)

### [3.10.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.10.0...v3.10.1) (2022-08-10)

## [3.10.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.9.4...v3.10.0) (2022-08-09)

### [3.9.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.9.3...v3.9.4) (2022-08-09)

### [3.9.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.9.2...v3.9.3) (2022-08-09)

### [3.9.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.9.1...v3.9.2) (2022-08-09)

### [3.9.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.9.0...v3.9.1) (2022-08-09)

## [3.9.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.8.1...v3.9.0) (2022-08-08)

### [3.8.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.8.0...v3.8.1) (2022-08-05)

## [3.8.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.7.0...v3.8.0) (2022-08-02)

## [3.7.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.6.1...v3.7.0) (2022-07-29)

### [3.6.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.6.0...v3.6.1) (2022-07-28)

## [3.6.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.5.1...v3.6.0) (2022-07-26)

### [3.5.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.5.0...v3.5.1) (2022-07-26)

## [3.5.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.4.0...v3.5.0) (2022-07-26)

## [3.4.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.3.0...v3.4.0) (2022-07-26)

## [3.3.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.2.0...v3.3.0) (2022-07-26)

## [3.2.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.1.0...v3.2.0) (2022-07-25)

## [3.1.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.0.0...v3.1.0) (2022-07-25)

## [3.0.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.10.0...v3.0.0) (2022-07-25)

## [2.10.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.9.0...v2.10.0) (2022-07-22)

## [2.9.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.8.0...v2.9.0) (2022-07-18)

## [2.8.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.7.0...v2.8.0) (2022-07-15)

## [2.7.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.6.0...v2.7.0) (2022-07-12)

## [2.6.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.5.1...v2.6.0) (2022-07-11)

### [2.5.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.5.0...v2.5.1) (2022-07-08)

## [2.5.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.4.0...v2.5.0) (2022-07-05)

## [2.4.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.3.3...v2.4.0) (2022-06-27)

### [2.3.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.3.2...v2.3.3) (2022-06-21)

### [2.3.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.3.1...v2.3.2) (2022-06-20)

### [2.3.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.3.0...v2.3.1) (2022-06-14)

## [2.3.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.2.0...v2.3.0) (2022-06-14)

## [2.2.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.1.7...v2.2.0) (2022-06-14)

### [2.1.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.1.6...v2.1.7) (2022-06-14)


### ⚠ BREAKING CHANGES

* DB CI CD Implementation

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery!265

* Merge branch 'feature/IMOD-30940_rd_db_pipeline' into 'develop' ([4e04d5c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/commit/4e04d5c34a35665b6468b17c87c81906a8f85b1f))

### [2.1.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.1.5...v2.1.6) (2022-06-08)

### [2.1.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.1.4...v2.1.5) (2022-06-08)

### [2.1.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.1.3...v2.1.4) (2022-06-06)

### [2.1.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.1.2...v2.1.3) (2022-06-06)

### [2.1.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.1.1...v2.1.2) (2022-05-18)

### [2.1.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.1.0...v2.1.1) (2022-05-17)

## [2.1.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.0.4...v2.1.0) (2022-05-16)

### [2.0.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.0.3...v2.0.4) (2022-05-16)

### [2.0.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.0.2...v2.0.3) (2022-05-16)

### [2.0.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.0.1...v2.0.2) (2022-05-13)

### [2.0.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.0.0...v2.0.1) (2022-05-11)

## [2.0.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.44.0...v2.0.0) (2022-05-10)

## [1.44.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.43.4...v1.44.0) (2022-04-28)

### [1.43.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.43.3...v1.43.4) (2022-04-21)

### [1.43.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.43.2...v1.43.3) (2022-04-21)

### [1.43.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.43.1...v1.43.2) (2022-04-18)

### [1.43.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.43.0...v1.43.1) (2022-04-18)

## [1.43.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.42.0...v1.43.0) (2022-04-13)

## [1.42.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.41.0...v1.42.0) (2022-04-06)

## [1.41.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.40.0...v1.41.0) (2022-04-04)

## [1.40.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.39.0...v1.40.0) (2022-03-31)

## [1.39.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.38.0...v1.39.0) (2022-03-31)

## [1.38.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.37.0...v1.38.0) (2022-03-28)

## [1.37.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.36.1...v1.37.0) (2022-03-25)

### [1.36.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.36.0...v1.36.1) (2022-03-23)

## [1.36.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.12...v1.36.0) (2022-03-10)

### [1.35.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.11...v1.35.12) (2022-02-24)

### [1.35.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.10...v1.35.11) (2022-02-24)

### [1.35.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.9...v1.35.10) (2022-02-24)

### [1.35.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.8...v1.35.9) (2022-02-18)

### [1.35.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.7...v1.35.8) (2022-02-18)

### [1.35.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.6...v1.35.7) (2022-02-14)

### [1.35.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.5...v1.35.6) (2022-02-10)

### [1.35.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.4...v1.35.5) (2022-02-10)

### [1.35.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.3...v1.35.4) (2022-02-10)

### [1.35.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.2...v1.35.3) (2022-02-08)

### [1.35.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.1...v1.35.2) (2022-02-08)

### [1.35.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.0...v1.35.1) (2022-02-07)

## [1.35.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.34.4...v1.35.0) (2022-02-07)

### [1.34.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.34.3...v1.34.4) (2022-02-01)

### [1.34.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.34.2...v1.34.3) (2022-01-31)

### [1.34.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.34.1...v1.34.2) (2022-01-25)

### [1.34.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.34.0...v1.34.1) (2022-01-21)

## [1.34.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.33.0...v1.34.0) (2022-01-14)

## [1.33.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.32.0...v1.33.0) (2022-01-11)

## [1.32.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.31.1...v1.32.0) (2022-01-10)

### [1.31.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.31.0...v1.31.1) (2021-12-28)

## [1.31.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.30.6...v1.31.0) (2021-12-24)

### [1.30.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.30.5...v1.30.6) (2021-12-24)

### [1.30.5-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.30.5-hotfix.1...v1.30.5-hotfix.2) (2021-12-20)

### [1.30.5-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.30.4...v1.30.5-hotfix.1) (2021-12-08)

### [1.30.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.30.4...v1.30.5) (2021-12-10)

### [1.30.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.30.3...v1.30.4) (2021-12-03)

### [1.30.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.30.2...v1.30.3) (2021-12-03)

### [1.30.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.30.1...v1.30.2) (2021-12-02)

### [1.30.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.30.0...v1.30.1) (2021-12-02)

## [1.30.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.29.0...v1.30.0) (2021-12-01)

## [1.29.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.28.1...v1.29.0) (2021-11-30)

### [1.28.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.28.0...v1.28.1) (2021-11-26)

## [1.28.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.27.0...v1.28.0) (2021-11-24)

## [1.27.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.26.0...v1.27.0) (2021-11-22)

## [1.26.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.25.0...v1.26.0) (2021-11-22)

## [1.25.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.24.0...v1.25.0) (2021-11-19)

## [1.24.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.23.0...v1.24.0) (2021-11-17)

## [1.23.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.22.0...v1.23.0) (2021-11-17)

## [1.22.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.21.0...v1.22.0) (2021-11-17)

## [1.21.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.20.0...v1.21.0) (2021-11-17)

## [1.20.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.19.0...v1.20.0) (2021-11-17)

## [1.19.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.18.0...v1.19.0) (2021-11-16)

## [1.18.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.17.0...v1.18.0) (2021-11-16)

## [1.17.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.16.0...v1.17.0) (2021-11-16)

## [1.16.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.15.0...v1.16.0) (2021-11-16)

## [1.15.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.14.0...v1.15.0) (2021-11-11)

## [1.14.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.13.0...v1.14.0) (2021-11-10)

## [1.13.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.12.0...v1.13.0) (2021-11-10)

## [1.12.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.11.0...v1.12.0) (2021-11-09)

## [1.11.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.10.0...v1.11.0) (2021-11-08)

## [1.10.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.9.0...v1.10.0) (2021-10-11)

## [1.9.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.8.0...v1.9.0) (2021-10-11)

## [1.8.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.7.0...v1.8.0) (2021-10-06)

## [1.7.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.6.0...v1.7.0) (2021-09-27)

## [1.6.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.5.0...v1.6.0) (2021-09-23)

## [1.5.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.4.0...v1.5.0) (2021-09-23)

## [1.4.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.3.0...v1.4.0) (2021-09-20)

## [1.3.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.2.0...v1.3.0) (2021-09-13)

## [1.2.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.1.1...v1.2.0) (2021-09-13)

### [1.1.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.1.0...v1.1.1) (2021-08-18)

## [1.1.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.0.1...v1.1.0) (2021-08-17)
