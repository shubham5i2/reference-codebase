import { configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

const nodeCrypto = require('crypto');
//@ts-ignore
global.crypto = {
  getRandomValues: function (buffer) {
    return nodeCrypto.randomFillSync(buffer);
  },
};

configure({ adapter: new Adapter() });
