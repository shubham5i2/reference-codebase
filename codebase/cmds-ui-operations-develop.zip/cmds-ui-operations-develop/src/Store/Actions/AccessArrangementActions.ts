export const AA_SEARCH = 'AA_SEARCH';
export const AA_CLEAR_SEARCH = 'AA_CLEAR_SEARCH';
export const AA_VIEW = 'AA_VIEW';
