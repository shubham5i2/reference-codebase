export const DATA_LOADED = 'DATA_LOADED';
export const DATA_LOAD_ERROR = 'DATA_LOAD_ERROR';
export const DATA_LOADING = 'DATA_LOADING';
