export const IS_LOADING = 'IS_LOADING';
