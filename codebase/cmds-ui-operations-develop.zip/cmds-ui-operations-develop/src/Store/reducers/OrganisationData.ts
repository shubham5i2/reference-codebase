import { Action } from '../../services/Models/Api';
import {
  initialOrganisationProfile,
  initialContactDetails,
  initialMinimumScore,
} from '../../components/Templates/Organisation/OrganisationConstants';
import * as OrganisationDataActions from '../Actions/OrganisationDataActions';

export const organisationDataInitialState = {
  organisationDetail: initialOrganisationProfile,
  contactDetail: initialContactDetails,
  minimumScore: initialMinimumScore,
  currentRoID: '',
};

export default (state = organisationDataInitialState, action: Action) => {
  switch (action.type) {
    case OrganisationDataActions.ORGANISATION_DATA_SUCCESS:
      return action.payload;
    case OrganisationDataActions.CLEAR_ORGANISATION_DATA:
      return organisationDataInitialState;
    default:
      return state;
  }
};
