import { Action } from '../../services/Models/Api';
import { LocationCache, LocationType } from '../../components/Organisms/LocationDropdown/LocationDropdownUtils';
import { DataState } from '../../services/Models/UIModels';
import { DATA_LOADED, DATA_LOADING, DATA_LOAD_ERROR } from '../Actions/LocationActions';

type LocationDataState = {
  [key in LocationType]?: LocationCache;
};

const initalState: LocationDataState = {};

export default (state: LocationDataState = initalState, action: Action) => {
  switch (action.type) {
    case DATA_LOADED: {
      return {
        ...state,
        [action.payload.locationType]: {
          dataState: DataState.LOADED,
          response: action.payload.response,
          transformedData: action.payload.transformedData,
          lastRefreshTime: new Date(),
        },
      };
    }
    case DATA_LOADING: {
      return {
        ...state,
        [action.payload.locationType]: {
          dataState: DataState.LOADING,
          response: [],
          transformedData: [],
        },
      };
    }
    case DATA_LOAD_ERROR: {
      return {
        ...state,
        [action.payload.locationType]: {
          dataState: DataState.ERROR,
          response: [],
          transformedData: [],
        },
      };
    }
    default: {
      return state;
    }
  }
};
