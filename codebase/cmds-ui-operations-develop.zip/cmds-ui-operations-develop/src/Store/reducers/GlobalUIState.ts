import * as UIStateActions from '../Actions/UIStateActions';
import { Action } from '../../services/Models/Api';

const initialState = {
  isLoading: false,
};

export const globalUIState = (state = initialState, action: Action) => {
  switch (action.type) {
    case UIStateActions.IS_LOADING:
      return {
        ...state,
        isLoading: action.payload,
      };
    default:
      return state;
  }
};
