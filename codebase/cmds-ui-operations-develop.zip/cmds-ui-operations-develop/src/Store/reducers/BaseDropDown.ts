import * as BaseDropDownActions from '../Actions/BaseDropDownActions';
import { Action } from '../../services/Models/Api';

const initialState = {
  countries: [],
  countriesResponse: [],
  territories: {},
  sectorTypes: [],
  partners: [],
  organisationTypes: [],
  nationalities: [],
  resultsStatusLabel: [],
  resultsStatusComments: [],
  additionalDeliveryOrgs: [],
  products: [],
};

export const baseDropDown = (state = initialState, action: Action) => {
  switch (action.type) {
    case BaseDropDownActions.COUNTRIES_ADDED:
      return {
        ...state,
        countries: action.payload.countries,
        countriesResponse: action.payload.countriesResponse,
      };
    case BaseDropDownActions.TERRITORIES_ADDED:
      return {
        ...state,
        territories: {
          ...state.territories,
          ...action.payload,
        },
      };
    case BaseDropDownActions.SECTOR_TYPES_ADDED:
      return {
        ...state,
        sectorTypes: action.payload,
      };
    case BaseDropDownActions.PARTNERS_ADDED:
      return {
        ...state,
        partners: action.payload,
      };
    case BaseDropDownActions.ORGANISATION_TYPES_ADDED:
      return {
        ...state,
        organisationTypes: action.payload,
      };
    case BaseDropDownActions.NATIONALITIES_ADDED:
      return {
        ...state,
        nationalities: action.payload.nationalities,
      };
    case BaseDropDownActions.RESULTS_STATUS_LABEL_ADDED:
      return {
        ...state,
        resultsStatusLabel: action.payload.response,
      };
    case BaseDropDownActions.RESULTS_STATUS_COMMENTS_ADDED:
      return {
        ...state,
        resultsStatusComments: action.payload.response,
      };

    case BaseDropDownActions.SAVE_PRODUCTS:
      return {
        ...state,
        products: action.payload.response,
      };
    default:
      return state;
  }
};
