import { DataState, Dictionary, DropdownCache } from '../../services/Models/UIModels';
import { Action } from '../../services/Models/Api';
import { ReferenceDropdownType } from '../../components/Organisms/ReferenceDropdown/UseReferenceFetch';
import { DATA_LOADED, DATA_LOADING, DATA_LOAD_ERROR } from '../Actions/ReferenceActions';

type ReferenceDataState = {
  [key in ReferenceDropdownType]?: DropdownCache | Dictionary;
};

const initalState: ReferenceDataState = {};

const defaultCacheState = {
  response: [],
  transformedData: [],
};

export default (state: ReferenceDataState = initalState, action: Action) => {
  const getUpdatedDropdownState = (cache: DropdownCache) => {
    const parent = action.payload?.subkey;
    const currentState = state as Dictionary;
    return parent ? { ...currentState[action.payload.dropdownType], [parent]: cache } : cache;
  };
  switch (action.type) {
    case DATA_LOADED: {
      return {
        ...state,
        [action.payload.dropdownType]: getUpdatedDropdownState({
          dataState: DataState.LOADED,
          response: action.payload.response,
          transformedData: action.payload.transformedData,
        }),
      };
    }
    case DATA_LOAD_ERROR: {
      return {
        ...state,
        [action.payload.dropdownType]: getUpdatedDropdownState({
          dataState: DataState.ERROR,
          ...defaultCacheState,
        }),
      };
    }
    case DATA_LOADING: {
      return {
        ...state,
        [action.payload.dropdownType]: getUpdatedDropdownState({
          dataState: DataState.LOADING,
          ...defaultCacheState,
        }),
      };
    }
    default: {
      return state;
    }
  }
};
