import * as ManageUserActions from '../Actions/ManageUserActions';
import { Action } from '../../services/Models/Api';
import { DataState } from '../../services/Models/UIModels';

const initialState = {
  userData: {
    partnerCode: '',
    givenName: '',
    familyName: '',
    nickname: '',
    phoneNumber: '',
    email: '',
    emailVerified: false,
    phoneVerified: false,
    userStatus: 'ACTIVE',
    assignGroupData: [],
  },
  userEditStatus: false,
  searchData: {
    searchName: '',
    body: null,
    selectedUserStatus: null,
    selectedPage: 1,
    selectedPageSizeIndex: 0,
    sortOption: {
      sortType: '',
      sortBy: '',
    },
    selectedUserGroup: {
      value: '',
      text: '',
    },
  },
  userGroupsData: {},
  searchResult: {
    totalCount: 0,
    deletedUserId: '',
    deletedRow: null,
    deletedUserName: '',
  },
  testCenters: {
    testcentersResponse: [],
    testcentersData: [],
  },
  locations: {
    locationsResponse: [],
    locationsData: [],
  },
};

export const ManageUser = (state = initialState, action: Action) => {
  switch (action.type) {
    case ManageUserActions.USER_PROFILE_DATA:
      return {
        ...state,
        userData: { ...action.payload },
      };
    case ManageUserActions.USER_GROUPS_DATA_LOADING:
      return {
        ...state,
        userGroupsData: {
          ...state.userGroupsData,
          [getUserGroupDataKey(action.payload)]: {
            dataState: DataState.LOADING,
            options: [],
          },
        },
      };
    case ManageUserActions.USER_GROUPS_DATA:
      return {
        ...state,
        userGroupsData: {
          ...state.userGroupsData,
          [getUserGroupDataKey(action.payload)]: {
            dataState: DataState.LOADED,
            options: action.payload.userGroupData,
          },
        },
      };
    case ManageUserActions.USER_GROUPS_DATA_ERROR:
      return {
        ...state,
        userGroupsData: {
          ...state.userGroupsData,
          [getUserGroupDataKey(action.payload)]: {
            dataState: DataState.ERROR,
            options: [],
          },
        },
      };
    case ManageUserActions.EDIT_USER_PROFILE_DATA:
      return {
        ...state,
        userData: { ...action.payload },
        userEditStatus: false,
      };
    case ManageUserActions.MANAGE_USER_SEARCH:
      return {
        ...state,
        searchData: action.payload,
      };
    case ManageUserActions.CLEAR_USER_SEARCH:
      return {
        ...state,
        searchData: initialState.searchData,
      };
    case ManageUserActions.USER_EDIT_STATUS:
      return {
        ...state,
        userEditStatus: action.payload,
      };
    case ManageUserActions.CLEAR_USER_DATA:
      return {
        ...state,
        userData: { ...initialState.userData },
        userEditStatus: false,
      };
    case ManageUserActions.SEARCH_SUCCESS:
      return {
        ...state,
        searchResult: {
          totalCount: action.payload.totalCount,
          deletedUserId: '',
          deletedRow: null,
          deletedUserName: '',
        },
      };
    case ManageUserActions.USER_DELETED:
      return {
        ...state,
        searchResult: {
          ...state.searchResult,
          deletedUserId: action.payload.deletedUserId,
          deletedRow: action.payload.deletedRow,
          deletedUserName: action.payload.deletedUserName,
        },
      };
    case ManageUserActions.SAVE_TESTCENTERS:
      return {
        ...state,
        testCenters: {
          testcentersResponse: action.payload.response,
          testcentersData: action.payload.formattedData,
        },
      };
    case ManageUserActions.SAVE_LOCATIONS:
      return {
        ...state,
        locations: {
          locationsResponse: action.payload.response,
          locationsData: action.payload.formattedData,
        },
      };
    case ManageUserActions.CLEAR_LOCATIONS: {
      return {
        ...state,
        locations: {
          locationsData: [],
          locationsResponse: [],
        },
      };
    }
    default:
      return state;
  }
};

export const getUserGroupDataKey = (payload: { locationUuid?: string; partnerCode?: string; emailDomain?: string }) => {
  const { locationUuid, partnerCode, emailDomain } = payload || {};
  if (!locationUuid && !partnerCode && !emailDomain) {
    return 'defaultUserGroup';
  }
  return `${partnerCode}_${locationUuid}_${emailDomain}`;
};
