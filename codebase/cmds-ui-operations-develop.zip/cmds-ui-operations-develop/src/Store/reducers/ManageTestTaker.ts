import * as ManageTestTakerActions from '../Actions/ManageTestTakerActions';
import { Action } from '../../services/Models/Api';

const initialState = {
  searchData: {
    searchName: '',
    body: null,
    selectedPage: 1,
    selectedPageSizeIndex: 0,
    sortOption: {
      sortType: '',
      sortBy: '',
    },
  },
  searchResult: {
    totalCount: 0,
  },
  viewBookingHistoryData: {
    selectedUniqueTestTakerUuid: '',
    selectedBookingUuid: '',
  },
  locations: {
    locationsResponse: [],
    locationsData: [],
  },
  products: {
    productsData: [],
  },
};

export const manageTestTaker = (state = initialState, action: Action) => {
  switch (action.type) {
    case ManageTestTakerActions.MANAGE_TEST_TAKER_SEARCH:
      return {
        ...state,
        searchData: action.payload,
      };
    case ManageTestTakerActions.CLEAR_TEST_TAKER_SEARCH:
      return {
        ...state,
        searchData: initialState.searchData,
      };
    case ManageTestTakerActions.SEARCH_SUCCESS:
      return {
        ...state,
        searchResult: {
          totalCount: action.payload.totalCount,
        },
      };
    case ManageTestTakerActions.VIEW_BOOKING:
      return {
        ...state,
        viewBookingHistoryData: {
          selectedUniqueTestTakerUuid: action.payload.selectedUniqueTestTakerUuid,
          selectedBookingUuid: action.payload.selectedBookingUuid,
        },
      };
    case ManageTestTakerActions.SAVE_LOCATIONS:
      return {
        ...state,
        locations: {
          locationsResponse: action.payload.response,
          locationsData: action.payload.formattedData,
        },
      };
    case ManageTestTakerActions.PRODUCTS:
      return {
        ...state,
        products: {
          productsData: action.payload.response,
        },
      };
    default:
      return state;
  }
};
