import { Action } from '../../services/Models/Api';
import { DataState, DropdownCache } from '../../services/Models/UIModels';
import { DATA_LOADED, DATA_LOADING, DATA_LOAD_ERROR, CLEAR_DATA } from '../Actions/ProductActions';

const initalState: DropdownCache = {};

const defaultCacheState = {
  response: [],
};

export default (state = initalState, action: Action) => {
  switch (action.type) {
    case DATA_LOADED: {
      return {
        dataState: DataState.LOADED,
        response: action.payload,
      };
    }
    case DATA_LOAD_ERROR: {
      return {
        dataState: DataState.ERROR,
        ...defaultCacheState,
      };
    }
    case DATA_LOADING: {
      return {
        dataState: DataState.LOADING,
        ...defaultCacheState,
      };
    }
    case CLEAR_DATA: {
      return initalState;
    }
    default: {
      return state;
    }
  }
};
