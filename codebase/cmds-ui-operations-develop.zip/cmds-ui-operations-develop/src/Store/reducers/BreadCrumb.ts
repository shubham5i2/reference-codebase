import * as BreadCrumbActions from '../Actions/BreadCrumbActions';
import { Action } from '../../services/Models/Api';

const initialState = {
  showBack: false,
  id: '',
};

export const breadCrumb = (state = initialState, action: Action) => {
  switch (action.type) {
    case BreadCrumbActions.SHOW_BACK:
      return {
        ...state,
        showBack: true,
        id: action.payload,
      };
    case BreadCrumbActions.HIDE_BACK:
      return {
        showBack: false,
      };

    default:
      return state;
  }
};
