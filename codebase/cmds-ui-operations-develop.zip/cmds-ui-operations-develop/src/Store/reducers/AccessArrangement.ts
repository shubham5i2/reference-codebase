import { Action } from '../../services/Models/Api';
import * as AccessArrangementActions from '../Actions/AccessArrangementActions';

const initialState = {
  searchData: {
    caseNumber: '',
  },
};

export const AccessArrangement = (state = initialState, action: Action) => {
  switch (action.type) {
    case AccessArrangementActions.AA_SEARCH:
      return {
        ...state,
        searchData: { ...action.payload },
      };
    case AccessArrangementActions.AA_CLEAR_SEARCH:
      return {
        ...state,
        searchData: initialState.searchData,
      };
    case AccessArrangementActions.AA_VIEW:
      return {
        ...state,
        searchData: { ...action.payload },
      };
    default:
      return state;
  }
};
