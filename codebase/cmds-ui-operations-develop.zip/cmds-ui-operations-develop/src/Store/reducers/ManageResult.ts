import * as ManageResultActions from '../Actions/ManageResultActions';
import { Action } from '../../services/Models/Api';
import { ResultsSearchResult, ResultsState } from '../../services/Models/Result';
import { SelectAllInitialData } from '../../components/Organisms/ResultsGrid/ResultsGridConstants';
import { ResultsGridData } from '../../components/Organisms/ResultsGrid/ResultsGrid';
import { GridSelectAllData } from '../../services/Models/UIModels';

const initialState: ResultsState = {
  searchData: {
    searchName: '',
    body: null,
    selectedPage: { page: 1 },
    selectedPageSizeIndex: 0,
    sortOption: {
      sortType: '',
      sortBy: '',
    },
  },
  searchResult: {
    totalCount: 0,
  },
  testCenters: {
    testcentersResponse: [],
    testcentersData: [],
  },
  resultStatuses: {
    resultStatusesResponse: [],
  },
  products: {
    productsResponse: [],
  },
  resultsStatusUpdatedMessage: '',
  resultsStatusUpdatedErrorMessage: '',
  searchResultsData: [],
  selectedBookings: [],
  selectAllStatus: [...SelectAllInitialData],
  searchBody: '',
};

let updatedResults: ResultsSearchResult[] = [];

const setSelectAllCheckboxStatus = (state: ResultsState, checked: boolean) => {
  const selectAllDetails: GridSelectAllData[] = [...state.selectAllStatus];
  const rowId =
    state.selectAllStatus &&
    state.selectAllStatus.findIndex(function (item: GridSelectAllData) {
      return item.page === state.searchData.selectedPage.page;
    });
  if (rowId >= 0) {
    selectAllDetails[rowId].checked = checked;
  } else {
    selectAllDetails.push({ page: state.searchData.selectedPage.page, checked: checked });
  }
  return {
    ...state,
    selectAllStatus: selectAllDetails,
  };
};

const selectAllHandler = (state: ResultsState, isChecked: boolean) => {
  const selectedData = [...state.selectedBookings];
  if (isChecked) {
    state.searchResultsData.forEach((item: ResultsGridData, index: number) => {
      const rowIndex = state.selectedBookings.findIndex(function (item: ResultsGridData) {
        return item.bookingUuid === state.searchResultsData[index].bookingUuid;
      });
      if (rowIndex === -1) {
        selectedData.push(item);
      }
    });
  } else {
    state.searchResultsData.forEach((rowItem: ResultsSearchResult) => {
      const rowIndex = selectedData.findIndex(function (item: ResultsGridData) {
        return item.bookingUuid === rowItem.bookingUuid;
      });
      if (rowIndex >= 0) {
        selectedData.splice(rowIndex, 1);
      }
    });
  }
  return {
    ...state,
    selectedBookings: selectedData,
  };
};

export const manageResult = (state = initialState, action: Action) => {
  switch (action.type) {
    case ManageResultActions.SAVE_TESTCENTERS:
      return {
        ...state,
        testCenters: {
          testcentersResponse: action.payload.response,
          testcentersData: action.payload.formattedData,
        },
      };
    case ManageResultActions.SAVE_RESULT_STATUS:
      return {
        ...state,
        resultStatuses: {
          resultStatusesResponse: action.payload.response,
        },
      };
    case ManageResultActions.SAVE_PRODUCTS:
      return {
        ...state,
        products: {
          productsResponse: action.payload.response,
        },
      };
    case ManageResultActions.SEARCH:
      return {
        ...state,
        searchData: action.payload,
      };
    case ManageResultActions.RESULTS_UPDATE_MESSAGE:
      return {
        ...state,
        resultsStatusUpdatedMessage: action.payload,
      };
    case ManageResultActions.CLEAR_RESULTS_TOAST_MESSAGE:
      return {
        ...state,
        resultsStatusUpdatedMessage: '',
      };
    case ManageResultActions.RESULTS_UPDATE_ERROR_MESSAGE:
      return {
        ...state,
        resultsStatusUpdatedErrorMessage: action.payload,
      };
    case ManageResultActions.CLEAR_RESULTS_ERROR_MESSAGE:
      return {
        ...state,
        resultsStatusUpdatedErrorMessage: '',
      };
    case ManageResultActions.SEARCH_SUCCESS:
      return {
        ...state,
        searchResult: {
          totalCount: action.payload.totalCount,
        },
        searchResultsData: action.payload.searchResultsData,
      };
    case ManageResultActions.UPDATE_ONHOLD:
      action.payload.bookingUuidList.forEach((bookingId: string) => {
        updatedResults = state.searchResultsData.map((booking: ResultsSearchResult) => {
          if (booking.bookingUuid === bookingId) {
            booking.onHold = action.payload.onHoldStatus;
          }
          return booking;
        });
      });
      return {
        ...state,
        searchResultsData: updatedResults,
      };
    case ManageResultActions.SELECT_BOOKING:
      return {
        ...state,
        selectedBookings: action.payload,
      };
    case ManageResultActions.CLEAR_SELECTED_BOOKING:
      return {
        ...state,
        selectedBookings: [],
        selectAllStatus: [{ page: 1, checked: false }],
      };
    case ManageResultActions.DELETE_SELECTED_BOOKING:
      return {
        ...state,
        selectedBookings: action.payload,
      };
    case ManageResultActions.SELECT_ALL_BOOKING:
      return selectAllHandler(state, action.payload);
    case ManageResultActions.SET_SELECT_ALL_CHECKBOX_STATUS:
      return setSelectAllCheckboxStatus(state, action.payload);

    case ManageResultActions.CLEAR_RESULTS_SEARCH:
      return {
        ...initialState,
      };
    default:
      return state;
  }
};
