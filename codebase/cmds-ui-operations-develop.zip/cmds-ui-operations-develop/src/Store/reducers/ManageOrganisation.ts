import * as OrganisationActions from '../Actions/OrganisationActions';
import { Action } from '../../services/Models/Api';

const initialState = {
  searchData: {
    searchName: '',
    body: null,
    selectedPage: 1,
    selectedPageSizeIndex: 0,
    sortOption: {
      sortType: '',
      sortBy: '',
    },
  },
  searchResult: {
    totalCount: 0,
  },
  duplicateSearchData: {
    searchName: '',
    body: null,
    selectedPage: 1,
    selectedPageSizeIndex: 0,
  },
  duplicateSearchResult: {
    totalCount: 0,
  },
  organisationCreatedMessage: '',
};

export const ManageOrganisation = (state = initialState, action: Action) => {
  switch (action.type) {
    case OrganisationActions.ORGANISATION_SEARCH:
      return {
        ...state,
        searchData: action.payload,
      };
    case OrganisationActions.CLEAR_ORGANISATION_SEARCH:
      return {
        ...state,
        searchData: initialState.searchData,
      };
    case OrganisationActions.ORGANISATION_DUPLICATE_SEARCH:
      return {
        ...state,
        duplicateSearchData: action.payload,
      };
    case OrganisationActions.CLEAR_ORGANISATION_DUPLICATE_SEARCH:
      return {
        ...state,
        duplicateSearchData: initialState.duplicateSearchData,
      };
    case OrganisationActions.ORGANISATION_ADD_UPDATE_MESSAGE:
      return {
        ...state,
        organisationCreatedMessage: action.payload,
      };
    case OrganisationActions.CLEAR_ORGANISATION_TOAST_MESSAGE:
      return {
        ...state,
        organisationCreatedMessage: '',
      };
    case OrganisationActions.SEARCH_SUCCESS:
      return {
        ...state,
        searchResult: {
          totalCount: action.payload.totalCount,
        },
      };
    case OrganisationActions.DUPLICATE_SEARCH_SUCCESS:
      return {
        ...state,
        duplicateSearchResult: {
          totalCount: action.payload.totalCount,
        },
      };
    default:
      return state;
  }
};
