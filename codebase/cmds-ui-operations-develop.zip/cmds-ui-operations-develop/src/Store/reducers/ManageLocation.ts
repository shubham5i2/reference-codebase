import * as LocationManagementActions from '../Actions/LocationManagementActions';
import { Action } from '../../services/Models/Api';

export const manageLocationInitialState = {
  searchData: null,
  pageNumber: '1',
  pageSize: {
    page: 0,
  },
  sorting: {
    sortBy: '',
    sortType: '',
  },
  totalCount: 0,
};

export const manageLocation = (state = manageLocationInitialState, action: Action) => {
  switch (action.type) {
    case LocationManagementActions.LOCATION_SEARCH:
      return {
        ...state,
        searchData: action.payload.searchData,
        pageNumber: action.payload.pageNumber,
        pageSize: action.payload.pageSize,
        sorting: action.payload.sorting,
        totalCount: action.payload.totalCount,
      };
    case LocationManagementActions.CLEAR_LOCATION_SEARCH:
      return {
        ...manageLocationInitialState,
      };
    default:
      return state;
  }
};
