import * as IncidentManagementActions from '../Actions/IncidentManagementActions';
import { Action } from '../../services/Models/Api';
import { IncidentManagementState } from '../../services/Models/IncidentManagement';

export const initialState: IncidentManagementState = {
  searchData: {
    searchName: '',
    body: null,
    selectedPage: 1,
    selectedPageSizeIndex: 0,
    sortOption: {
      sortType: '',
      sortBy: '',
    },
  },
  searchResult: {
    totalCount: 0,
  },
  testCenters: {
    testcentersResponse: [],
    testcentersData: [],
  },
  products: {
    productsResponse: [],
  },
};

export const incidentManagement = (state = initialState, action: Action) => {
  switch (action.type) {
    case IncidentManagementActions.INCIDENT_MANAGEMENT_SEARCH:
      return {
        ...state,
        searchData: action.payload,
      };
    case IncidentManagementActions.CLEAR_SEARCH:
      return {
        ...state,
        searchData: initialState.searchData,
      };
    case IncidentManagementActions.SEARCH_SUCCESS:
      return {
        ...state,
        searchResult: {
          totalCount: action.payload.totalCount,
        },
      };
    case IncidentManagementActions.SAVE_PRODUCTS:
      return {
        ...state,
        products: {
          productsResponse: action.payload.response,
        },
      };
    case IncidentManagementActions.SAVE_TESTCENTERS:
      return {
        ...state,
        testCenters: {
          testcentersResponse: action.payload.response,
          testcentersData: action.payload.formattedData,
        },
      };
    default:
      return state;
  }
};
