import { useContext } from 'react';
import { AppContext } from '../AppContext/AppContext';

export const useStateValue = () => useContext(AppContext);
