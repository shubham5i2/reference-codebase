import { Reducer } from 'react';

import { ManageUser } from '../reducers/ManageUser';
import { breadCrumb } from '../reducers/BreadCrumb';
import organisationData from '../reducers/OrganisationData';
import { ManageOrganisation } from '../reducers/ManageOrganisation';
import { manageTestTaker } from '../reducers/ManageTestTaker';
import { baseDropDown } from '../reducers/BaseDropDown';
import { globalUIState } from '../reducers/GlobalUIState';
import { manageResult } from '../reducers/ManageResult';
import { incidentManagement } from '../reducers/IncidentManagement';
import { manageLocation } from '../reducers/ManageLocation';
import { AccessArrangement } from '../reducers/AccessArrangement';
import locationData from '../reducers/LocationData';
import referenceData from '../reducers/ReferenceData';
import products from '../reducers/Product';

export interface Action {
  type: string;
  [args: string]: any;
}

interface Reducers {
  [key: string]: Reducer<any, Action>;
}

const combineReducer =
  (reducers: Reducers): Reducer<Action, any> =>
  (action: Action, state = {}) => {
    const nextState: any = {};
    Object.keys(reducers).forEach((key) => (nextState[key] = reducers[key](state[key], action)));
    return nextState;
  };

export const combinedReducers = combineReducer({
  ManageUser,
  breadCrumb,
  organisationData,
  ManageOrganisation,
  baseDropDown,
  globalUIState,
  manageTestTaker,
  manageResult,
  incidentManagement,
  locationData,
  referenceData,
  products,
  manageLocation,
  AccessArrangement,
});
