import React from 'react';
import { combinedReducers } from '../helpers/CombineReducer';

export const initialAppState = combinedReducers({ type: '' }, {});

export const AppContext = React.createContext<{ state: any; dispatch: React.Dispatch<any> }>({
  state: initialAppState, // default value
  dispatch: () => null,
});
