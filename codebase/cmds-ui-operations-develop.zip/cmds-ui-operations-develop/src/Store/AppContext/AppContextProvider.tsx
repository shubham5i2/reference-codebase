import React, { useReducer } from 'react';
import UI from 'ielts-cmds-ui-component-library';
import { useAuth0 } from '@auth0/auth0-react';

import { AppContext, initialAppState } from './AppContext';
import { Action, combinedReducers } from '../helpers/CombineReducer';
import {
  DEFAULT_WEBSOCKET_CONNECTION_ATTEMPTS,
  DEFAULT_WEBSOCKET_TIMEOUT_CHECK_INTERVAL,
  DEFAULT_WEBSOCKET_TIMEOUT_INTERVAL,
} from '../../constants/GlobalConstants';

interface AppContextProviderProps {
  onMaxConnectionAttemptsFailure: () => void;
  accessToken: string;
}

export const globalDispatcher = (state: any, action: Action) => combinedReducers(action, state);

const AppContextProvider: React.FC<AppContextProviderProps> = ({
  children,
  accessToken,
  onMaxConnectionAttemptsFailure,
}) => {
  const [globalAppState, dispatch] = useReducer(globalDispatcher, initialAppState);
  const { isAuthenticated, isLoading, user } = useAuth0();

  const appState = {
    ...globalAppState,
    authState: {
      isAuthenticated,
      isLoading,
      user,
    },
  };

  console.log({ appState });

  return (
    <UI.Connector
      socketUrl={process.env.REACT_APP_SOCKET_URL}
      accessToken={accessToken}
      timeOutInterval={DEFAULT_WEBSOCKET_TIMEOUT_INTERVAL}
      checkTimeOutEvery={DEFAULT_WEBSOCKET_TIMEOUT_CHECK_INTERVAL}
      maxConnectionAttempts={DEFAULT_WEBSOCKET_CONNECTION_ATTEMPTS}
      onMaxConnectionAttemptsFailure={onMaxConnectionAttemptsFailure}
    >
      <AppContext.Provider value={{ state: appState, dispatch }}> {children} </AppContext.Provider>
    </UI.Connector>
  );
};

export default AppContextProvider;
