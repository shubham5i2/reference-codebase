import OverviewIcon from '../assets/images/Home_Black.svg';
import FolderIcon from '../assets/images/Folder.svg';
import UserIcon from '../assets/images/Users.svg';
import ResultsIcon from '../assets/images/Results.svg';
import BookingIcon from '../assets/images/BookingCalendar.svg';
import CheckIcon from '../assets/images/Checks-icon.svg';
import IncidentManagementIcon from '../assets/images/Incident_management.png';
import AccessArrangementIcon from '../assets/images/AccessArrangement.png';
// import SettingsIcon from '../assets/images/Settings.svg';
// import DownArrowIcon from '../../../assets/images/Chevron_Down.svg';
import ArrowRight from '../assets/images/ArrowRight.svg';
import { languageService } from '../services/Language/LanguageService';
// import CollapseIcon from '../../../assets/images/ArrowLeft.svg';
import LocationIcon from '../assets/images/Location.svg';
import ProductIcon from '../assets/images/NavProductIconBlack.png';

type MenuItem = {
  label: string;
  icon?: SVGAnimatedString;
  url: string;
  subMenu?: MenuItem[];
  subMenuTitle?: string;
};

const commonLabels = languageService().common;

export const aaLeftNavigationMenu: MenuItem = {
  label: commonLabels.navMenuAccessArrangement,
  icon: AccessArrangementIcon,
  url: '/accessarrangements',
  subMenuTitle: commonLabels.navMenuAccessArrangement,
  subMenu: [
    {
      label: commonLabels.navMenuAccessArrangement,
      icon: ArrowRight,
      url: '/accessarrangements',
      subMenu: [],
    },
  ],
};

const Value: MenuItem[] = [
  {
    label: commonLabels.navMenuHome,
    icon: OverviewIcon,
    url: '/',
    subMenu: [],
  },
  {
    label: commonLabels.navMenuTestTaker,
    icon: BookingIcon,
    url: '/managetesttaker',
    subMenuTitle: commonLabels.navMenuTestTaker,
    subMenu: [
      {
        label: commonLabels.navMenuTestTaker,
        icon: ArrowRight,
        url: '/managetesttaker',
        subMenu: [],
      },
    ],
  },
  {
    label: commonLabels.navMenuSM,
    icon: UserIcon,
    url: '/manageuser',
    subMenuTitle: commonLabels.navMenuSM,
    subMenu: [
      {
        label: commonLabels.navSubMenuSearchUser,
        icon: ArrowRight,
        url: '/manageuser',
        subMenu: [],
      },
      {
        label: commonLabels.navSubMenuAddUser,
        icon: ArrowRight,
        url: '/manageuser/adduser',
        subMenu: [],
      },
    ],
  },
  {
    label: commonLabels.navMenuOrganisation,
    icon: FolderIcon,
    url: '/organisation',
    subMenuTitle: commonLabels.navMenuOrganisation,
    subMenu: [
      {
        label: commonLabels.navSubMenuSearchOrg,
        icon: ArrowRight,
        url: '/organisation',
      },
      {
        label: commonLabels.navSubMenuAddOrg,
        icon: ArrowRight,
        url: '/organisation/duplicatesearch',
      },
    ],
  },
  {
    label: commonLabels.navMenuResults,
    icon: ResultsIcon,
    url: '/results',
    subMenuTitle: commonLabels.navMenuResults,
    subMenu: [
      {
        label: commonLabels.navSubMenuSearchResults,
        icon: ArrowRight,
        url: '/results',
      },
    ],
  },
  {
    label: commonLabels.navMenuManageTestTakerPreReleaseCheck,
    icon: CheckIcon,
    url: '/manageprereleasecheck',
    subMenuTitle: commonLabels.navMenuManageTestTakerPreReleaseCheck,
    subMenu: [
      {
        label: commonLabels.navMenuManageTestTakerPreReleaseCheck,
        icon: ArrowRight,
        url: '/manageprereleasecheck',
        subMenu: [],
      },
    ],
  },
  //locations left navigation icon
  {
    label: commonLabels.navMenuLocation,
    icon: LocationIcon,
    url: '/locationManagement',
    subMenuTitle: commonLabels.navMenuLocation,
    subMenu: [
      {
        label: commonLabels.navSubMenuSearch,
        icon: ArrowRight,
        url: '/locationManagement',
      },
      {
        label: commonLabels.navSubMenuAdd,
        icon: ArrowRight,
        url: '/locationManagement/addLocation',
      },
    ],
  },
  {
    label: 'Products',
    icon: ProductIcon,
    url: '/productsManagement',
  },
  {
    label: commonLabels.navMenuIncidentManagement,
    icon: IncidentManagementIcon,
    url: '/incidentmanagement',
    subMenuTitle: commonLabels.navMenuIncidentManagement,
    subMenu: [
      {
        label: commonLabels.navMenuIncidentManagement,
        icon: ArrowRight,
        url: '/incidentmanagement',
        subMenu: [],
      },
    ],
  },
];
export default Value;
