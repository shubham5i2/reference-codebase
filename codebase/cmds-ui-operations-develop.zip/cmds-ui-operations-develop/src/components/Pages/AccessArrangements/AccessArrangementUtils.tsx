import { languageService } from '../../../services/Language/LanguageService';

const aaLabels = languageService().accessArrangements;

export interface ArrangementDetails {
  accessArrangementUuid?: string;
  externalAccessArrangementUuid?: string;
  arrangementTypeUuid: string;
  component: string;
  accessArrangementName?: string;
  note?: string;
  isChecked?: boolean;
  name?: string;
}

export interface TestTaker {
  firstName: string;
  lastName: string;
}

export type AAComponentTypes = {
  name: string;
  componentDetails: ArrangementDetails[];
};

export const aaComponentTypes: AAComponentTypes[] = [
  {
    name: aaLabels.listening,
    componentDetails: [
      {
        accessArrangementName: aaLabels.excemption,
        arrangementTypeUuid: '5868ebc0-d026-489b-b031-086da0793927',
        isChecked: false,
        component: 'L',
      },
      {
        accessArrangementName: aaLabels.extraTimeAsAppropriate,
        arrangementTypeUuid: 'c1a53e78-8023-4bc4-93f9-7b76edaab5fb',
        isChecked: false,
        component: 'L',
      },
      {
        accessArrangementName: aaLabels.pauseAudio,
        arrangementTypeUuid: '36919201-eb3c-46a3-8f44-9b2730fae3b8',
        isChecked: false,
        component: 'L',
      },
      {
        accessArrangementName: aaLabels.replayAudio,
        arrangementTypeUuid: '52b87476-5fb2-4eca-8af7-5e914c6ab72a',
        isChecked: false,
        component: 'L',
      },
      {
        accessArrangementName: aaLabels.separateInvigilation,
        arrangementTypeUuid: 'b8fc563a-d5c3-495d-aba1-bf95307b8ccf',
        isChecked: false,
        component: 'L',
      },
      {
        accessArrangementName: aaLabels.supervisedBreaks,
        arrangementTypeUuid: '33671ddf-a08b-4f8f-a600-b0837a7dacfc',
        isChecked: false,
        component: 'L',
      },
    ],
  },
  {
    name: aaLabels.reading,
    componentDetails: [
      {
        accessArrangementName: aaLabels.excemption,
        arrangementTypeUuid: '5868ebc0-d026-489b-b031-086da0793927',
        isChecked: false,
        component: 'R',
      },
      {
        accessArrangementName: aaLabels.twentyFivePercentExtraTime,
        isChecked: false,
        arrangementTypeUuid: '4c345957-2d0d-4fc2-812f-d62a2553f169',
        component: 'R',
      },
      {
        accessArrangementName: aaLabels.fiftyPercentExtraTime,
        isChecked: false,
        arrangementTypeUuid: 'eca2cff4-a6af-40ca-ab9f-f0aecf3746c7',
        component: 'R',
      },
      {
        accessArrangementName: aaLabels.separateInvigilation,
        arrangementTypeUuid: 'b8fc563a-d5c3-495d-aba1-bf95307b8ccf',
        isChecked: false,
        component: 'R',
      },
      {
        accessArrangementName: aaLabels.supervisedBreaks,
        arrangementTypeUuid: '33671ddf-a08b-4f8f-a600-b0837a7dacfc',
        isChecked: false,
        component: 'R',
      },
    ],
  },
  {
    name: aaLabels.writing,
    componentDetails: [
      {
        accessArrangementName: aaLabels.excemption,
        arrangementTypeUuid: '5868ebc0-d026-489b-b031-086da0793927',
        isChecked: false,
        component: 'W',
      },
      {
        accessArrangementName: aaLabels.twentyFivePercentExtraTime,
        isChecked: false,
        arrangementTypeUuid: '4c345957-2d0d-4fc2-812f-d62a2553f169',
        component: 'W',
      },
      {
        accessArrangementName: aaLabels.fiftyPercentExtraTime,
        isChecked: false,
        arrangementTypeUuid: 'eca2cff4-a6af-40ca-ab9f-f0aecf3746c7',
        component: 'W',
      },
      {
        accessArrangementName: aaLabels.separateInvigilation,
        arrangementTypeUuid: 'b8fc563a-d5c3-495d-aba1-bf95307b8ccf',
        isChecked: false,
        component: 'W',
      },
      {
        accessArrangementName: aaLabels.supervisedBreaks,
        arrangementTypeUuid: '33671ddf-a08b-4f8f-a600-b0837a7dacfc',
        isChecked: false,
        component: 'W',
      },
    ],
  },
  {
    name: aaLabels.speaking,
    componentDetails: [
      {
        accessArrangementName: aaLabels.excemption,
        arrangementTypeUuid: '5868ebc0-d026-489b-b031-086da0793927',
        isChecked: false,
        component: 'S',
      },
      {
        accessArrangementName: aaLabels.extraTimeAsAppropriate,
        arrangementTypeUuid: 'c1a53e78-8023-4bc4-93f9-7b76edaab5fb',
        isChecked: false,
        component: 'S',
      },
      {
        accessArrangementName: aaLabels.supervisedBreaks,
        arrangementTypeUuid: '33671ddf-a08b-4f8f-a600-b0837a7dacfc',
        isChecked: false,
        component: 'S',
      },
    ],
  },
];

export interface AASearch {
  arrangementDetails: ArrangementDetails[];
  testTaker: TestTaker;
  expiryDate: string;
  targetTestDate: string;
  externalCaseNumberId: string;
  externalCaseNumberUuid?: string;
  accessArrangementCaseUuid?: string;
  additionalNotes?: string;
}

export interface AccessArrangementSearchResponse {
  search: AASearch[];
  pagination: {
    pageNumber: number;
    pageSize: number;
  };
  result: {
    totalCount: number;
  };
}
