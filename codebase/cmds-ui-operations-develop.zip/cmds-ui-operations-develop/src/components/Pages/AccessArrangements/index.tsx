import { Route, Switch } from 'react-router-dom';
import React from 'react';
import AccessArrangementsSearch from './AccessArrangementsSearch/AccessArrangementsSearch';
import styles from './styles.module.scss';
import AccessArranagemetViewPanel from '../../Organisms/AccessArrangements/AccessArrangementViewPanel/AccessArrangementViewPanel';
import AccessArrangementsCreatePanel from '../../Organisms/AccessArrangements/AccessArrangementsCreatePanel/AccessArrangementsCreatePanel';

export default (props: any) => {
  const currentUrl = props.match.url;

  return (
    <div className={styles.container}>
      <Switch>
        <Route path={currentUrl + '/viewAccessArrangementsDetails'} component={AccessArranagemetViewPanel}></Route>
        <Route path={currentUrl + '/createAccessArrangement'} component={AccessArrangementsCreatePanel}></Route>
        <Route path={currentUrl} component={AccessArrangementsSearch}></Route>
      </Switch>
    </div>
  );
};
