import React, { useEffect, useState, useContext } from 'react';
import AccessArrangementsGrid from '../../../Organisms/AccessArrangements/AccessArrangementsGrid/AccessArrangementsGrid';
import { searchAA } from '../../../../services/API/AccessArrangements/SearchAA';
import UI from 'ielts-cmds-ui-component-library';
import withServiceRequest, { ConnectorInterface, ServiceRequest } from '../../../../services/utils/ServiceRequest';
import styles from './AccessArrangementsSearch.module.scss';
import { RouteComponentProps } from 'react-router-dom';
import * as BreadCrumbActions from '../../../../Store/Actions/BreadCrumbActions';
import * as AccessArrangementActions from '../../../../Store/Actions/AccessArrangementActions';
import { languageService } from '../../../../services/Language/LanguageService';
import SearchPanel from '../../../Organisms/SearchPanel/SearchPanel';
import { useStateValue } from '../../../../Store/helpers/UseStateValue';
import { useEffectUpdate } from '../../../utils/utilities';
import ToastMessage, { Mode, Position } from '../../../Organisms/ToastMessage/ToastMessage';
import { DEFAULT_TOAST_MESSAGE_TIMER } from '../../../../constants/GlobalConstants';
import { AccessArrangementSearchResponse } from '../AccessArrangementUtils';

interface AccessArrangementsSearchProps extends RouteComponentProps {
  serviceRequest: ServiceRequest;
}

const aaLabels = languageService().accessArrangements;
export const AccessArrangementsSearch = (props: AccessArrangementsSearchProps) => {
  const [basicSearchValue, setBasicSearchValue] = useState('');
  const [showToastError, setShowToastErrorMessage] = useState(false);
  const [aaGridData, setAAGridData] = useState<AccessArrangementSearchResponse>();
  const { dispatch, state } = useStateValue();
  const [isCaseNumberStateChanged, setCaseNumberStateChanged] = useState(false);
  const [isApiCalled, setApiCalled] = useState(false);
  const [isLoading, setLoading] = useState(false);
  const connectorContext = useContext<ConnectorInterface>(UI.ConnectorContext);
  const currentUrl = props.match.url;

  useEffect(() => {
    dispatch({ type: BreadCrumbActions.SHOW_BACK, payload: true });
    return () => {
      dispatch({
        type: AccessArrangementActions.AA_CLEAR_SEARCH,
        payload: {
          caseNumber: '',
        },
      });
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (state.AccessArrangement && state.AccessArrangement.searchData.caseNumber) {
      const { caseNumber } = state.AccessArrangement.searchData;
      setCaseNumberStateChanged(true);
      setBasicSearchValue(caseNumber);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [connectorContext.connectionId]);

  useEffectUpdate(() => {
    onSearch();
  }, [isCaseNumberStateChanged]);

  const onSearch = () => {
    if (!basicSearchValue) {
      setApiCalled(false);
      setShowToastErrorMessage(true);
      return;
    }
    fetchAAData();
  };

  const fetchAAData = () => {
    setLoading(true);
    const request = {
      externalCaseNumberId: basicSearchValue,
    };
    dispatch({
      type: AccessArrangementActions.AA_SEARCH,
      payload: {
        caseNumber: request.externalCaseNumberId,
      },
    });
    searchAA(request, props.serviceRequest).subscribe((response) => {
      setLoading(false);
      setAAGridData(response?.gridData);
      setApiCalled(true);
    });
  };
  const onCreateCaseHandler = () => {
    props.history.push(currentUrl + '/createAccessArrangement');
  };

  const getAADataForGrid = () => (aaGridData && aaGridData.search && aaGridData.search.length) || 0;

  const getAAGrid = () => {
    return {
      totalRecords: getAADataForGrid(),
      initialState: {
        pageSize: getAADataForGrid(),
      },
      selectedPage: 1,
      selectedOptionValue: getAADataForGrid(),
    };
  };

  const getErrorMessage = () => {
    return showToastError ? (
      <ToastMessage
        id="toast_panel_error"
        color={Mode.ERROR}
        position={Position.DEFAULT}
        dismissable={true}
        onChange={() => {
          setShowToastErrorMessage(false);
        }}
        duration={DEFAULT_TOAST_MESSAGE_TIMER}
        message={aaLabels.searchAAValidationToastErrorMsg}
      ></ToastMessage>
    ) : null;
  };

  return (
    <div className={styles.accessArrangementsSearch}>
      {getErrorMessage()}
      <div className={styles.accessArrangementSearchPanel} style={{ marginTop: '30px' }}>
        <SearchPanel
          title={aaLabels.accesArrangementsTitle}
          titleType="regular"
          titleSize={32}
          addButtonLabel={aaLabels.createNewCase}
          onAddUserHandler={onCreateCaseHandler}
          addButtonColor="blueLine"
          addButtonIcon="plus"
          subTitleType="regular"
          subTitleSize={16}
          searchBoxPlaceholder={aaLabels.searchBoxPlaceHolder}
          onSearchHandler={onSearch}
          basicSearchValue={basicSearchValue}
          onBasicSearchValueChange={(value: string) => setBasicSearchValue(value)}
          searchBoxSearchIcon="button"
          searchButtonColor="primary"
        ></SearchPanel>
      </div>
      {isLoading && !isApiCalled && <UI.Spinner />}
      {isApiCalled && (
        <div className={styles.accessArrangementGrid}>
          <AccessArrangementsGrid aaGridData={aaGridData?.search} gridState={getAAGrid()} />
        </div>
      )}
    </div>
  );
};

export default withServiceRequest(AccessArrangementsSearch);
