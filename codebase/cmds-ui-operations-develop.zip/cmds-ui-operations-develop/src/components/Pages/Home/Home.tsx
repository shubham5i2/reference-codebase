import * as React from 'react';
import Styles from './Home.module.scss';
import { useStateValue } from '../../../Store/helpers/UseStateValue';
import { useEffect, useState } from 'react';
import useFeatureToggle from '../../../services/feature-toggle/UseFeatureToggle';
import ROOT_FEATURE from '../../../services/feature-toggle/feature-types/RootFeature';
import { HOME_SUB_FEATURE } from '../../../services/feature-toggle/feature-types/sub-feature/SubFeature';
import { languageService } from '../../../services/Language/LanguageService';
import useRBAC from '../../../services/hooks/useRBAC';
import { Dictionary } from '../../../services/Models/UIModels';
import * as ManageUserActions from '../../../Store/Actions/ManageUserActions';
import * as OrganisationActions from '../../../Store/Actions/OrganisationActions';
import * as ManageTestTakerActions from '../../../Store/Actions/ManageTestTakerActions';
import * as ManageResultActions from '../../../Store/Actions/ManageResultActions';
import * as IncidentManagementActions from '../../../Store/Actions/IncidentManagementActions';
import * as LocationManagementActions from '../../../Store/Actions/LocationManagementActions';

const Home = (props: any) => {
  const { dispatch } = useStateValue();
  // This is for RBAC
  const [showCardBasedonRBAC, setShowCardBasedonRBAC] = useState<Dictionary>({
    [HOME_SUB_FEATURE.manageUserLabel]: true,
    [HOME_SUB_FEATURE.organisationLabel]: false,
    [HOME_SUB_FEATURE.manageTestTakerLabel]: true,
    [HOME_SUB_FEATURE.manageResultsLabel]: true,
    [HOME_SUB_FEATURE.manageTestTakerPreReleaseLabel]: true,
    [HOME_SUB_FEATURE.incidentManagementLabel]: true,
    [HOME_SUB_FEATURE.accessArrangementsLabel]: true,
    [HOME_SUB_FEATURE.locationManagement]: true,
    [HOME_SUB_FEATURE.productsManagement]: true,
  });
  // This is for feature toggle
  const [FeatureToggleProvider] = useFeatureToggle();
  const userAccess = useRBAC('organisation');
  const aaUserAccess = useRBAC('accessarrangements');
  const locationManagementAccess = useRBAC('locationManagement');
  const productsManagementAccess = useRBAC('productsManagement');

  const commonLabels = languageService().common;

  useEffect(() => {
    setShowCardBasedonRBAC((prevState) => ({
      ...prevState,
      [HOME_SUB_FEATURE.organisationLabel]: !!userAccess?.isReadAccess,
      [HOME_SUB_FEATURE.accessArrangementsLabel]: !!aaUserAccess?.isReadAccess,
      [HOME_SUB_FEATURE.locationManagement]: !!locationManagementAccess?.isReadAccess,
      [HOME_SUB_FEATURE.productsManagement]: !!productsManagementAccess?.isReadAccess,
    }));
  }, [userAccess, aaUserAccess, locationManagementAccess, productsManagementAccess]);

  useEffect(() => {
    dispatch({ type: ManageUserActions.CLEAR_USER_SEARCH });
    dispatch({ type: OrganisationActions.CLEAR_ORGANISATION_SEARCH });
    dispatch({ type: ManageTestTakerActions.CLEAR_TEST_TAKER_SEARCH });
    dispatch({ type: ManageResultActions.CLEAR_RESULTS_SEARCH });
    dispatch({ type: IncidentManagementActions.CLEAR_SEARCH });
    dispatch({ type: LocationManagementActions.CLEAR_LOCATION_SEARCH });
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getHomeElements = () => {
    return [
      {
        label: commonLabels.navMenuSM,
        featurekey: HOME_SUB_FEATURE.manageUserLabel,
        id: 'manageUserDetailsContainer',
        url: '/manageuser',
      },
      {
        label: commonLabels.navMenuOrganisation,
        featurekey: HOME_SUB_FEATURE.organisationLabel,
        id: 'organisationContainer',
        url: '/organisation',
      },
      {
        label: commonLabels.navMenuTestTaker,
        featurekey: HOME_SUB_FEATURE.manageTestTakerLabel,
        id: 'manageTestTakerContainer',
        url: '/managetesttaker',
      },
      {
        label: commonLabels.navMenuResults,
        featurekey: HOME_SUB_FEATURE.manageResultsLabel,
        id: 'manageResultsContainer',
        url: '/results',
      },
      {
        label: commonLabels.navMenuManageTestTakerPreReleaseCheck,
        featurekey: HOME_SUB_FEATURE.manageTestTakerPreReleaseLabel,
        id: 'manageTestTakerPreReleaseCheckContainer',
        url: '/manageprereleasecheck',
      },
      {
        label: commonLabels.navMenuIncidentManagement,
        featurekey: HOME_SUB_FEATURE.incidentManagementLabel,
        id: 'incidentmanagementContainer',
        url: '/incidentmanagement',
      },
      {
        label: commonLabels.locationManagment,
        featurekey: HOME_SUB_FEATURE.locationManagement,
        id: 'locationManagement',
        url: '/locationManagement',
      },
      {
        label: commonLabels.accessArrangements,
        featurekey: HOME_SUB_FEATURE.accessArrangementsLabel,
        id: 'accessarrangements',
        url: '/accessarrangements',
      },
      {
        label: commonLabels.productsMangement,
        featurekey: HOME_SUB_FEATURE.productsManagement,
        id: 'productsManagement',
        url: '/productsManagement',
      },
    ].filter((data) => showCardBasedonRBAC[data.featurekey]);
  };

  const onCardSelection = (url: string) => props.history?.push(url);

  const getCards = () => {
    return getHomeElements().map((ele) => {
      return (
        <div className={Styles.card} onClick={() => onCardSelection(ele.url)} key={ele.id} {...ele}>
          {ele.label}
        </div>
      );
    });
  };

  return (
    <FeatureToggleProvider featurekey={ROOT_FEATURE.home}>
      <div className={Styles.cardHolder} {...{ isrequired: true }}>
        {getCards()}
      </div>
    </FeatureToggleProvider>
  );
};

export default Home;
