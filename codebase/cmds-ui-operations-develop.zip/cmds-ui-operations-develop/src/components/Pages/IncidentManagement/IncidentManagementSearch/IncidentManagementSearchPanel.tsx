//: Search panel will refactored as part of https://btsservice.atlassian.net/browse/IMOD-33283

import React, { useState, useEffect, useRef } from 'react';
import styles from './IncidentManagementSearchPanel.module.scss';
import SearchPanel from '../../../Organisms/IncidentManagementSearchPanel/IncidentManagementSearchPanel';
import { languageService } from '../../../../services/Language/LanguageService';
import withServiceRequest, { ServiceRequest } from '../../../../services/utils/ServiceRequest';
import { useStateValue } from '../../../../Store/helpers/UseStateValue';
import * as BreadCrumbActions from '../../../../Store/Actions/BreadCrumbActions';
import { getValue, useEffectUpdate } from '../../../utils/utilities';
import { RouteComponentProps } from 'react-router-dom';
import { ColumnSort } from '../../../../services/Models/UIModels';
import { pageSizeOptions } from '../../../Organisms/ManageUsersGrid/ManageUsersGridConstants';
import * as IncidentManagementActions from '../../../../Store/Actions/IncidentManagementActions';
import {
  IncidentManagementSearchPayload,
  IncidentSearchResponse,
  AdvancedSearchDataType,
  BasicSearchDataType,
  IncidentManagementSearchType,
} from '../../../../services/Models/IncidentManagement';
import { incidentManagementSearchResult } from '../../../../services/API/IncidentManagement/GetIncidentSearchResult';
import IncidentManagementGrid from '../../../Organisms/IncidentManagementGrid/IncidentManagementGrid';
import {
  initialBasicSearchData,
  initialAdvancedSearchData,
  sortConstant,
} from '../../../../constants/IncidentManagement/IncidentManagementSearchPanelConstants';
import { getSearchRequestBody } from './IncidentManagementSearchService';

interface IncidentManagementSearchPanelProps extends RouteComponentProps {
  serviceRequest: ServiceRequest;
}

const IncidentManagementSearchPanel = (props: IncidentManagementSearchPanelProps) => {
  const [initialOpenState, setInitialOpenState] = useState(false);
  const [isClearBasicSearch, setClearBasicSearch] = useState(false);
  const [isClearAdvancedSearch, setClearAdvancedSearch] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');
  const [advancedSearchData, setAdvancedSearchData] = useState(initialAdvancedSearchData);
  const [basicSearchData, setBasicSearchData] = useState(initialBasicSearchData);
  const [isSearchCriteriaValid, setSearchCriteriaValid] = useState(true);
  const [isSearchResults, setSearchResults] = useState(false);
  const [searchResultsData, setSearchResultsData] = useState<IncidentSearchResponse[]>([]);
  const [totalSearchResult, setTotalSearchResult] = useState(0);
  const [currentSelectedPage, setCurrentSelectedPage] = useState({ page: 1 });
  const [currentSelectedPageSize, setCurrentSelectedPageSize] = useState(pageSizeOptions[2].value);
  const [selectedSortOption, setSelectedSortOption] = useState(sortConstant);

  const isFromSearchClick = useRef(false);
  const selectedSearchType = useRef('');

  const { state, dispatch } = useStateValue();

  const incidentManagementLabels = languageService().incidentManagement;

  const [isGridLoading, setIsGridLoading] = useState(false);

  useEffectUpdate(() => {
    if (!isFromSearchClick.current) {
      const { searchName } = state.incidentManagement.searchData;
      const name = searchName || IncidentManagementSearchType.DEFAULT;
      const reqBody = getSearchRequestBody(
        selectedSortOption,
        basicSearchData,
        advancedSearchData,
        currentSelectedPage,
        currentSelectedPageSize,
      );
      getSearchResults(name, reqBody, true);
    } else if (isFromSearchClick.current && selectedSearchType.current !== '') {
      const reqBody = getSearchRequestBody(
        selectedSortOption,
        basicSearchData,
        advancedSearchData,
        currentSelectedPage,
        currentSelectedPageSize,
      );
      getSearchResults(selectedSearchType.current, reqBody, true);
      selectedSearchType.current = '';
    }
  }, [currentSelectedPage]);

  const updateUI = (searchName: string, body: IncidentManagementSearchPayload) => {
    const { criteria } = body;
    setBasicSearchData({
      dateRange: {
        startDate: new Date(getValue(criteria.testDateFrom)),
        endDate: new Date(getValue(criteria.testDateTo)),
      },
      testCentre: getValue(criteria.locationUuid),
      product: getValue(criteria.productUuid),
    });
    if (searchName === IncidentManagementSearchType.BASIC || searchName === IncidentManagementSearchType.DEFAULT) {
      setClearBasicSearch(true);
    } else {
      setAdvancedSearchData({
        givenname: getValue(criteria.firstName),
        lastname: getValue(criteria.lastName),
        shortcandidatenumber: getValue(criteria.shortCandidateNumber),
        uniquetesttakerid: getValue(criteria.uniqueTestTakerId),
        identitynumber: getValue(criteria.identityNumber),
        incidentcatagory: getValue(criteria.incidentCategoryUuid),
        incidentstatus: getValue(criteria.incidentStatusTypeUuid),
        incidenttype: getValue(criteria.incidentTypeUuid),
        incidentseverity: getValue(criteria.incidentSeverity),
      });
      setInitialOpenState(true);
      setClearAdvancedSearch(true);
    }
  };

  useEffect(() => {
    dispatch({ type: BreadCrumbActions.SHOW_BACK });
    getSearchResultsOnLoad();
    // eslint-disable-next-line
  }, []);

  const onBasicSearchHandler = () => {
    const isSearchDataEmpty = basicSearchDataValidationCheck(basicSearchData);
    if (!isClearBasicSearch || isSearchDataEmpty) {
      setSearchCriteriaValid(false);
      setSearchResults(false);
      return;
    }
    isFromSearchClick.current = true;
    selectedSearchType.current = IncidentManagementSearchType.BASIC;
    setCurrentSelectedPage(() => {
      return { page: 1 };
    });
    setSearchCriteriaValid(true);
    setSearchResults(true);
  };

  const onAdvancedSearchHandler = () => {
    const isAdvancedSearchDataEmpty = advancedSearchDataValidationCheck(advancedSearchData);
    const isBasicSearchDataEmpty = basicSearchDataValidationCheck(basicSearchData);
    if ((!isClearBasicSearch && !isClearAdvancedSearch) || isBasicSearchDataEmpty) {
      if (isBasicSearchDataEmpty && !isAdvancedSearchDataEmpty) {
        setErrorMessage(incidentManagementLabels.startDateAndEndDateErrorMessage);
      }
      setSearchCriteriaValid(false);
      setSearchResults(false);
      return;
    }
    isFromSearchClick.current = true;
    selectedSearchType.current = IncidentManagementSearchType.ADVANCE;
    setCurrentSelectedPage(() => {
      return { page: 1 };
    });
    setSearchCriteriaValid(true);
    setSearchResults(true);
  };

  const getSearchResults = (name: string, body: IncidentManagementSearchPayload, shouldUpdateState: boolean) => {
    const selectedPageSizeIndex = pageSizeOptions.findIndex((option) => option.value === currentSelectedPageSize);
    if (shouldUpdateState) {
      dispatch({
        type: IncidentManagementActions.INCIDENT_MANAGEMENT_SEARCH,
        payload: {
          body,
          searchName: name,
          selectedPage: currentSelectedPage,
          selectedPageSizeIndex,
          sortOption: selectedSortOption,
        },
      });
    }
    setIsGridLoading(true);
    incidentManagementSearchResult(body, props.serviceRequest).subscribe((data) => {
      if (!data) return;
      const gridData = data.gridData || [];
      const totalRecords = data.totalCount || 0;
      dispatch({ type: IncidentManagementActions.SEARCH_SUCCESS, payload: { totalCount: totalRecords } });
      setTotalSearchResult(totalRecords);
      setSearchResultsData(gridData);
      setSearchResults(totalRecords > 0);
      setIsGridLoading(false);
    });
  };

  const getSearchResultsOnLoad = () => {
    const { searchName, body, selectedPage, selectedPageSizeIndex, sortOption } = state.incidentManagement.searchData;
    setInitialOpenState(false);
    const reqBody = getSearchRequestBody(
      selectedSortOption,
      basicSearchData,
      advancedSearchData,
      currentSelectedPage,
      currentSelectedPageSize,
    );
    if (searchName !== '' && body) {
      isFromSearchClick.current = true;
      setCurrentSelectedPage(selectedPage);
      setCurrentSelectedPageSize(pageSizeOptions[selectedPageSizeIndex].value);
      setSelectedSortOption(sortOption);
      updateUI(searchName, body);
      getSearchResults(searchName, body, true);
    } else {
      getSearchResults(IncidentManagementSearchType.DEFAULT, reqBody, true);
    }
  };

  const basicSearchDataValidationCheck = (basicSearchDataArg: BasicSearchDataType) => {
    const { dateRange, testCentre, product } = basicSearchDataArg;
    const { startDate, endDate } = dateRange;
    if (!startDate && !endDate && testCentre.trim() === '' && product.trim() === '') {
      setErrorMessage(incidentManagementLabels.searchCriteriaError);
      return true;
    } else if (!startDate || !endDate) {
      setErrorMessage(incidentManagementLabels.startDateAndEndDateErrorMessage);
      return true;
    }
    return false;
  };

  const advancedSearchDataValidationCheck = (advancedSearchDataArg: AdvancedSearchDataType) => {
    const {
      givenname,
      lastname,
      incidentcatagory,
      incidenttype,
      incidentseverity,
      identitynumber,
      shortcandidatenumber,
      uniquetesttakerid,
      incidentstatus,
    } = advancedSearchDataArg;
    if (
      givenname.trim() === '' &&
      lastname.trim() === '' &&
      incidentcatagory.trim() === '' &&
      incidentseverity.trim() === '' &&
      incidentstatus.trim() === '' &&
      incidenttype.trim() === '' &&
      identitynumber.trim() === '' &&
      shortcandidatenumber.trim() === '' &&
      uniquetesttakerid.trim() === ''
    ) {
      setErrorMessage(incidentManagementLabels.searchCriteriaError);
      return true;
    }
    return false;
  };

  const onPageChangeHandler = (page: number) => {
    isFromSearchClick.current = false;
    setCurrentSelectedPage(() => {
      return { page: page + 1 };
    });
  };

  const onPageSizeChangeHandler = (value: number) => {
    setCurrentSelectedPageSize(() => value);
    isFromSearchClick.current = false;
    setCurrentSelectedPage(() => {
      return { page: 1 };
    });
  };

  const onColumnSortHandler = (column: ColumnSort) => {
    const sortType =
      JSON.stringify(selectedSortOption.sortBy) === JSON.stringify(column.Header.name)
        ? selectedSortOption.sortType === 'ASC'
          ? 'DESC'
          : 'ASC'
        : 'ASC';
    const sortOption = {
      sortBy: column.Header.name,
      sortType,
    };
    setSelectedSortOption(() => sortOption);
    isFromSearchClick.current = false;
    setCurrentSelectedPage(() => {
      return { page: 1 };
    });
  };

  const testTakerData = searchResultsData && searchResultsData.length > 0 ? searchResultsData : [];

  const getIncidentGrid = () => {
    const gridState = {
      totalRecords: totalSearchResult,
      initialState: {
        pageSize: currentSelectedPageSize,
      },
      selectedPage: currentSelectedPage.page,
      selectedOptionValue: currentSelectedPageSize,
    };
    return (
      <div className={styles.searchResults}>
        <IncidentManagementGrid
          data={testTakerData}
          onPageChange={onPageChangeHandler}
          onPageSizeChange={onPageSizeChangeHandler}
          gridState={gridState}
          pageSizeOptions={pageSizeOptions}
          onColumnSort={onColumnSortHandler}
          sortOption={selectedSortOption}
          sort={true}
          isSearchResults={isSearchResults}
          serviceRequest={props.serviceRequest}
          isLoading={isGridLoading}
        />
      </div>
    );
  };

  return (
    <React.Fragment>
      <SearchPanel
        basicSearchData={basicSearchData}
        onBasicSearchHandler={onBasicSearchHandler}
        onAdvancedSearchHandler={onAdvancedSearchHandler}
        initialOpenState={initialOpenState}
        setClearAdvancedSearch={setClearAdvancedSearch}
        fetchProductDataOnLoad={true}
        serviceRequest={props.serviceRequest}
        setAdvancedSearchData={setAdvancedSearchData}
        advanceSearchData={advancedSearchData}
        setClearBasicSearch={setClearBasicSearch}
        setBasicSearchData={setBasicSearchData}
        errorMessage={errorMessage}
        isSearchCriteriaValid={isSearchCriteriaValid}
        setSearchCriteriaValid={setSearchCriteriaValid}
      />
      {getIncidentGrid()}
    </React.Fragment>
  );
};

export default withServiceRequest(IncidentManagementSearchPanel);
