import {
  IncidentManagementSearchPayload,
  IncidentManagementSearchSortItem,
  AdvancedSearchDataType,
  BasicSearchDataType,
} from '../../../../services/Models/IncidentManagement';
import { formatDate, getValue } from '../../../utils/utilities';
import { languageService } from '../../../../services/Language/LanguageService';

const incidentManagementLabels = languageService().incidentManagement;

const getReqBody = (basicSearchData: BasicSearchDataType, advancedSearchData: AdvancedSearchDataType) => {
  const fromDate = getValue(basicSearchData.dateRange.startDate ? String(basicSearchData.dateRange.startDate) : '');
  const toDate = getValue(basicSearchData.dateRange.endDate ? String(basicSearchData.dateRange.endDate) : '');
  return {
    uniqueTestTakerId: getValue(advancedSearchData.uniquetesttakerid.trim()),
    shortCandidateNumber: getValue(advancedSearchData.shortcandidatenumber.trim()),
    identityNumber: getValue(advancedSearchData.identitynumber.trim()),
    firstName: getValue(advancedSearchData.givenname.trim()),
    lastName: getValue(advancedSearchData.lastname.trim()),
    incidentCategoryUuid: getValue(advancedSearchData.incidentcatagory),
    incidentStatusTypeUuid: getValue(advancedSearchData.incidentstatus),
    incidentTypeUuid: getValue(advancedSearchData.incidenttype),
    incidentSeverity: getValue(advancedSearchData.incidentseverity),
    testDateFrom: formatDate(new Date(fromDate), incidentManagementLabels.inputDateFormat),
    testDateTo: formatDate(new Date(toDate), incidentManagementLabels.inputDateFormat),
    productUuid: getValue(basicSearchData.product),
    locationUuid: getValue(basicSearchData.testCentre),
  };
};

const getSortingElement = (sortBy: string, sortType: string) => ({ sortBy, sortType });

export const getSearchRequestBody = (
  selectedSortOption: IncidentManagementSearchSortItem,
  basicSearchData: BasicSearchDataType,
  advancedSearchData: AdvancedSearchDataType,
  currentSelectedPage: { page: number },
  currentSelectedPageSize: number,
) => {
  const sorting = Array.isArray(selectedSortOption.sortBy)
    ? selectedSortOption.sortBy.map((sortBy) => getSortingElement(sortBy, selectedSortOption.sortType))
    : [getSortingElement(selectedSortOption.sortBy, selectedSortOption.sortType)];

  const reqBody: IncidentManagementSearchPayload = {
    criteria: getReqBody(basicSearchData, advancedSearchData),
    pagination: {
      pageNumber: currentSelectedPage.page - 1,
      pageSize: currentSelectedPageSize,
    },
    sorting,
  };
  return reqBody;
};
