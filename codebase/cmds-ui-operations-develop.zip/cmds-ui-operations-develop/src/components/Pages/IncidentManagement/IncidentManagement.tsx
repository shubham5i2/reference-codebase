import React from 'react';
import { Switch } from 'react-router-dom';
import PrivateRoute from '../../../routes/PrivateRoute';
import ROOT_FEATURE from '../../../services/feature-toggle/feature-types/RootFeature';
import useFeatureToggle from '../../../services/feature-toggle/UseFeatureToggle';
import IncidentManagementPhotoVerificationPanel from '../../Organisms/IncidentManagementPhotoVerificationPanel/IncidentManagementPhotoVerificationPanel';
import IncidentManagementViewPanel from '../../Organisms/IncidentManagementViewPanel/IncidentManagementViewPanel';
import styles from './IncidentManagement.module.scss';
import IncidentManagementSearchPanel from './IncidentManagementSearch/IncidentManagementSearchPanel';

const IncidentManagement = (props: any) => {
  const currentUrl = props.match.url;
  useFeatureToggle(ROOT_FEATURE.incidentmanagement);
  return (
    <div className={styles.container}>
      <Switch>
        <PrivateRoute
          path={currentUrl + '/incidentmanagementviewdetails/incidentmanagementidverification/:id'}
          exact
          component={IncidentManagementPhotoVerificationPanel}
        />
        <PrivateRoute
          path={currentUrl + '/incidentmanagementviewdetails/:id'}
          exact
          component={IncidentManagementViewPanel}
        />
        <PrivateRoute path={currentUrl} component={IncidentManagementSearchPanel} />
      </Switch>
    </div>
  );
};

export default IncidentManagement;
