import React, { useState, useEffect, useRef, useContext } from 'react';
import { languageService } from '../../../../services/Language/LanguageService';
import { pageSizeOptions } from '../../../Organisms/ManageUsersGrid/ManageUsersGridConstants';
import { formatDate, transformRequestValueFromString, useEffectUpdate } from '../../../utils/utilities';
import { useStateValue } from '../../../../Store/helpers/UseStateValue';
import * as BreadCrumbActions from '../../../../Store/Actions/BreadCrumbActions';
import UI from 'ielts-cmds-ui-component-library';
import styles from './ManageTestTakerPreReleaseCheckSearchPanel.module.scss';
import { RouteComponentProps } from 'react-router-dom';
import {
  PreReleaseSearchPayload,
  PreReleaseSearchResult,
  PreReleaseSearchCriteria,
  PreReleaseSearchData,
} from '../../../../services/Models/PreReleaseManagement';
import { ColumnSort } from '../../../../services/Models/UIModels';
import NoResultsFound from '../../../Molecules/NoResultsFound/NoResultsFound';
import { preReleaseSearchResult } from '../../../../services/API/PreReleaseSearch/GetPreReleaseSearchResult';
import withServiceRequest, { ConnectorInterface, ServiceRequest } from '../../../../services/utils/ServiceRequest';
import PreReleaseCheckGrid from '../../../Organisms/PreReleaseCheckGrid/PreReleaseCheckGrid';
import PreReleaseSearchPanel from '../../../Organisms/PreReleaseSearchPanel/PreReleaseSearchPanel';
import {
  generateCheckOutComeStatusUuId,
  generateCheckOutComeTypeUuId,
  CheckOutComeStatusUuIdGenerationType,
} from '../../../../services/API/Reference/CheckOutcomeStatus';

interface ManageTestTakerPreReleaseCheckSearchPanelProps extends RouteComponentProps {
  serviceRequest: ServiceRequest;
}

enum DateType {
  DATE_OF_BIRTH = 'DATE_OF_BIRTH',
  TEST_DATE = 'TEST_DATE',
}

export const MESSAGE_TIMER = 3000;
export const DEFAULT = 'defaultSearch';

const generateCheckOutcomeCriteria = () => {
  return {
    checkOutcomeStatusUuid: generateCheckOutComeStatusUuId(CheckOutComeStatusUuIdGenerationType.FLAGGED_FOR_REVIEW),
    checkOutcomeTypeUuid: generateCheckOutComeTypeUuId(CheckOutComeStatusUuIdGenerationType.PRE_RELEASE_CHECK),
  };
};

const ManageTestTakerPreReleaseCheckSearchPanel = (props: ManageTestTakerPreReleaseCheckSearchPanelProps) => {
  const initialSearchData = {
    givenname: '',
    familyname: '',
    identitydocumentnumber: '',
    dateofbirth: '',
    uniquetesttakerid: '',
    centrenumber: '',
    testtakernumber: '',
    testdate: '',
  };
  const preSearchCriteria = {
    uniqueTestTakerId: '',
    centreId: '',
    identityNumber: '',
    firstName: '',
    lastName: '',
    shortCandidateNumber: '',
    birthDate: '',
    testDate: '',
    checkOutcome: generateCheckOutcomeCriteria(),
  };

  const testTakerLabels = languageService().preReleaseCheck;
  const isFromSearchClick = useRef(false);
  const connectorContext = useContext<ConnectorInterface>(UI.ConnectorContext);
  const selectedSearchType = useRef('');
  const [totalSearchResult, setTotalSearchResult] = useState(0);
  const { dispatch } = useStateValue();
  const [basicSearchData, setBasicSearchData] = useState(initialSearchData);
  const [isSearchResults, setSearchResults] = useState(false);
  const [searchResultsData, setSearchResultsData] = useState<PreReleaseSearchResult[]>([]);
  const [isSearchCriteriaValid, setSearchCriteriaValid] = useState(true);
  const [isClearBasicSearch, setClearBasicSearch] = useState(false);
  const [currentSelectedPage, setCurrentSelectedPage] = useState({ page: 1 });
  const [currentSelectedPageSize, setCurrentSelectedPageSize] = useState(pageSizeOptions[0].value);
  const [selectedSortOption, setSelectedSortOption] = useState({
    sortType: 'ASC',
    sortBy: 'centreId',
  });
  const [searchState, setSearchState] = useState<PreReleaseSearchCriteria>(preSearchCriteria);
  const initialValidator = {
    isValid: true,
    message: '',
  };
  const [validatorFields, setValidatorFields] = useState(initialValidator);
  const [isGridLoading, setIsGridLoading] = useState(false);

  useEffectUpdate(() => {
    if (!isFromSearchClick.current) {
      const name = DEFAULT;
      const reqBody = getSearchRequestBody();
      getSearchResults(name, reqBody);
    } else if (isFromSearchClick.current && selectedSearchType.current !== '') {
      const reqBody = getSearchRequestBody();
      getSearchResults(selectedSearchType.current, reqBody);
      selectedSearchType.current = '';
    }
  }, [currentSelectedPage]);

  const basicSearchDataValidationCheck = (basicSearchDataArg: PreReleaseSearchData) => {
    const {
      uniquetesttakerid,
      dateofbirth,
      testdate,
      centrenumber,
      testtakernumber,
      familyname,
      givenname,
      identitydocumentnumber,
    } = basicSearchDataArg;
    return (
      uniquetesttakerid.trim() === '' &&
      dateofbirth.trim() === '' &&
      identitydocumentnumber.trim() === '' &&
      testdate.trim() === '' &&
      dateofbirth.trim() === '' &&
      centrenumber.trim() === '' &&
      testtakernumber.trim() === '' &&
      familyname.trim() === '' &&
      givenname.trim() === ''
    );
  };

  const handleInputExpression = (basicSearchDataArg: PreReleaseSearchData) => {
    const { testtakernumber } = basicSearchDataArg;
    const regxTestTakerNumber = /^[0-9]*$/;
    !regxTestTakerNumber.test(testtakernumber) &&
      setValidatorFields({ isValid: false, message: testTakerLabels.ttNumberExpressionErrorMessage });
    regxTestTakerNumber.test(testtakernumber) && setValidatorFields(initialValidator);
    return regxTestTakerNumber.test(testtakernumber);
  };

  const getSearchResultsOnLoad = () => {
    const reqBody = getSearchRequestBody();
    getSearchResults(DEFAULT, reqBody);
  };

  useEffect(() => {
    dispatch({ type: BreadCrumbActions.SHOW_BACK });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    getSearchResultsOnLoad();
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [connectorContext.connectionId]);

  const handleBasicInputChange = (e: React.FormEvent<HTMLInputElement>) => {
    setClearBasicSearch(true);
    const target = e.target as HTMLInputElement;
    const value = target.value;
    setBasicSearchData({ ...basicSearchData, [target.name]: value });
  };

  const handleDateChanges = (dateArg: Date, type: string) => {
    setClearBasicSearch(true);
    if (type === DateType.DATE_OF_BIRTH) {
      setBasicSearchData({
        ...basicSearchData,
        dateofbirth: formatDate(dateArg, testTakerLabels.inputDateFormat),
      });
    } else if (type === DateType.TEST_DATE) {
      setBasicSearchData({
        ...basicSearchData,
        testdate: formatDate(dateArg, testTakerLabels.inputDateFormat),
      });
    }
  };

  const getReqBody = () => {
    return {
      uniqueTestTakerId: transformRequestValueFromString(basicSearchData.uniquetesttakerid),
      centreId: transformRequestValueFromString(basicSearchData.centrenumber),
      identityNumber: transformRequestValueFromString(basicSearchData.identitydocumentnumber),
      firstName: transformRequestValueFromString(basicSearchData.givenname),
      lastName: transformRequestValueFromString(basicSearchData.familyname),
      shortCandidateNumber: transformRequestValueFromString(basicSearchData.testtakernumber),
      birthDate: transformRequestValueFromString(basicSearchData.dateofbirth),
      testDate: transformRequestValueFromString(basicSearchData.testdate),
      checkOutcome: generateCheckOutcomeCriteria(),
    };
  };

  const getSortingElement = (sortBy: string, sortType: string) => ({ sortBy, sortType });

  const onPageChangeHandler = (page: number) => {
    isFromSearchClick.current = false;
    setCurrentSelectedPage(() => {
      return { page: page + 1 };
    });
  };
  const onPageSizeChangeHandler = (value: number) => {
    setCurrentSelectedPageSize(() => value);
    isFromSearchClick.current = false;
    setCurrentSelectedPage(() => {
      return { page: 1 };
    });
  };

  const onColumnSortHandler = (column: ColumnSort) => {
    let sortType;
    if (JSON.stringify(selectedSortOption.sortBy) === JSON.stringify(column.Header.name)) {
      sortType = selectedSortOption.sortType === 'ASC' ? 'DESC' : 'ASC';
    } else {
      sortType = 'ASC';
    }
    const sortOption = {
      sortBy: column.Header.name,
      sortType,
    };
    setSelectedSortOption(() => sortOption);
    isFromSearchClick.current = false;
    setCurrentSelectedPage(() => {
      return { page: 1 };
    });
  };

  const getSearchRequestBody = (): PreReleaseSearchPayload => {
    const sorting = Array.isArray(selectedSortOption.sortBy)
      ? selectedSortOption.sortBy.map((sortBy) => getSortingElement(sortBy, selectedSortOption.sortType))
      : [getSortingElement(selectedSortOption.sortBy, selectedSortOption.sortType)];

    const reqBody: PreReleaseSearchPayload = {
      criteria: isFromSearchClick.current ? getReqBody() : searchState,
      pagination: {
        pageNumber: currentSelectedPage.page - 1,
        pageSize: currentSelectedPageSize,
      },
      sorting,
    };
    return reqBody;
  };

  const getSearchResults = (name: string, body: PreReleaseSearchPayload) => {
    setIsGridLoading(true);
    preReleaseSearchResult(body, props.serviceRequest).subscribe((data) => {
      if (!data) return;
      const gridData = data.gridData || [];
      const totalRecords = data.totalCount || 0;
      setTotalSearchResult(totalRecords);
      setSearchResultsData(gridData);
      setSearchResults(totalRecords > 0);
      setIsGridLoading(false);
    });
  };

  const onClearBasicSearch = (event: React.FormEvent<HTMLInputElement>) => {
    event.preventDefault();
    setBasicSearchData(initialSearchData);
    setClearBasicSearch(false);
  };

  const onBasicSearchHandler = () => {
    const isSearchDataEmpty = basicSearchDataValidationCheck(basicSearchData);
    const inputExpression = handleInputExpression(basicSearchData);
    if (!inputExpression) {
      setSearchResults(false);
      return;
    } else if (!isClearBasicSearch || isSearchDataEmpty) {
      setSearchCriteriaValid(false);
      setSearchResults(false);
      return;
    }
    isFromSearchClick.current = true;
    selectedSearchType.current = DEFAULT;
    setCurrentSelectedPage(() => {
      return { page: 1 };
    });
    setSearchCriteriaValid(true);
    setSearchResults(true);
    setSearchState(getReqBody());
  };

  const testTakerData = searchResultsData && searchResultsData.length > 0 ? searchResultsData : [];

  const getTestTakerGrid = () => {
    const gridState = {
      totalRecords: totalSearchResult,
      initialState: {
        pageSize: currentSelectedPageSize,
      },
      selectedPage: currentSelectedPage.page,
      selectedOptionValue: currentSelectedPageSize,
    };
    return (
      <div className={styles.searchResults}>
        <PreReleaseCheckGrid
          data={testTakerData}
          onPageChange={onPageChangeHandler}
          onPageSizeChange={onPageSizeChangeHandler}
          gridState={gridState}
          pageSizeOptions={pageSizeOptions}
          onColumnSort={onColumnSortHandler}
          sortOption={selectedSortOption}
          sort={true}
          pageNumber={currentSelectedPage.page}
          reloadData={getSearchResultsOnLoad}
          isLoading={isGridLoading}
        />
      </div>
    );
  };
  return (
    <React.Fragment>
      {!isSearchCriteriaValid ? (
        <div className={styles.messageContainer}>
          <UI.Message
            message={testTakerLabels.searchCriteriaError}
            color="error"
            dismissable
            onChange={() => setSearchCriteriaValid(true)}
            visibleTill={MESSAGE_TIMER}
          />
        </div>
      ) : null}
      <PreReleaseSearchPanel
        title={testTakerLabels.manageTestTakerPreReleaseTitle}
        titleType="regular"
        titleSize={32}
        subTitle={testTakerLabels.manageTestTakerPreReleaseSubTitle}
        subTitleType="regular"
        subTitleSize={16}
        basicSearchData={basicSearchData}
        onClearBasicSearch={onClearBasicSearch}
        clearBasicSearch={
          JSON.stringify(basicSearchData) !== JSON.stringify(initialSearchData) ? testTakerLabels.clearSearch : ''
        }
        basicSearchButtonLabel={testTakerLabels.searchLabel}
        basicSearchButtonColor="primary"
        onBasicSearchHandler={onBasicSearchHandler}
        handleBasicInputChange={handleBasicInputChange}
        ieltsTestTakerLabel={testTakerLabels.uniqueTestTakerId}
        centreNumberLabel={testTakerLabels.ttcentreNumberLabel}
        identityDocumentNumberLabel={testTakerLabels.identityDocumentNumber}
        testTakerNumberLabel={testTakerLabels.ttNumberLabel}
        givenNameLabel={testTakerLabels.givenName}
        familyNameLabel={testTakerLabels.familyName}
        isSearchResults={isSearchResults}
        validation={validatorFields}
      >
        <div className={styles.dateWrapper}>
          <div className={styles.textBoxLabel}>{testTakerLabels.dateOfBirth}</div>
          <span>
            <UI.DatePicker
              id="dateOfBirth"
              minDate="1900-01-01"
              maxDate="2100-12-31"
              value={basicSearchData.dateofbirth}
              onChange={(val: Date) => handleDateChanges(val, DateType.DATE_OF_BIRTH)}
              resetDate={basicSearchData.dateofbirth === ''}
            />
          </span>
        </div>
        <div className={styles.dateWrapper}>
          <div className={styles.textBoxLabel}>{testTakerLabels.ttbhBookingTestDate}</div>
          <span>
            <UI.DatePicker
              id="testDate"
              minDate="1900-01-01"
              maxDate="2100-12-31"
              value={basicSearchData.testdate}
              onChange={(val: Date) => handleDateChanges(val, DateType.TEST_DATE)}
              resetDate={basicSearchData.testdate === ''}
            />
          </span>
        </div>
      </PreReleaseSearchPanel>
      {isSearchResults ? (
        getTestTakerGrid()
      ) : (
        <NoResultsFound
          title={testTakerLabels.noResultsFoundTitle}
          description={testTakerLabels.noResultsFoundPreReleaseSearchDesp}
        />
      )}
    </React.Fragment>
  );
};

export default withServiceRequest(ManageTestTakerPreReleaseCheckSearchPanel);
