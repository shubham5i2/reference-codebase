import React from 'react';
import { Switch } from 'react-router-dom';
import PrivateRoute from '../../../routes/PrivateRoute';
import ROOT_FEATURE from '../../../services/feature-toggle/feature-types/RootFeature';
import useFeatureToggle from '../../../services/feature-toggle/UseFeatureToggle';
import styles from './ManageTestTakerPreReleaseCheck.module.scss';
import ManageTestTakerPreReleaseCheckSearchPanel from './ManageTestTakerPreReleaseCheckSearchPanel/ManageTestTakerPreReleaseCheckSearchPanel';

const ManageTestTakerPreReleaseCheck = (props: any) => {
  const currentUrl = props.match.url;
  useFeatureToggle(ROOT_FEATURE.prereleasecheck);
  return (
    <div className={styles.container}>
      <Switch>
        <PrivateRoute path={currentUrl} component={ManageTestTakerPreReleaseCheckSearchPanel} />
      </Switch>
    </div>
  );
};

export default ManageTestTakerPreReleaseCheck;
