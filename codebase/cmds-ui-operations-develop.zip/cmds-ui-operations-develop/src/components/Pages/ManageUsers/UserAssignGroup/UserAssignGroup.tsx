import React, { useState, useEffect } from 'react';
import AssignGroup from '../../../Templates/ManageUser/UserAssignGroup';
import WithUser from '../../../../services/Hoc/WithUser';
import { useStateValue } from '../../../../Store/helpers/UseStateValue';
import withServiceRequest, { ServiceRequest } from '../../../../services/utils/ServiceRequest';
import { updateUserGroups } from '../../../../services/API/ManageUser/UpdateUserGroups';
import { UserFormError, RouteParams } from '../../../../services/Models/UIModels';
import { AssignGroupData, User } from '../../../../services/Models/StaffManagement';
import { useHistory, useParams } from 'react-router-dom';
import { formatLanguageString, languageService } from '../../../../services/Language/LanguageService';
import { getUserGroupAssignmentsName } from '../../../utils/utilities';
import manageUserFormRules, { FormStepType, FormActionType } from '../../../utils/ValidationRules/ManageUserForm';
import { FormValidation } from '../../../utils/FormValidation';
import AssignUserGroupDialog from '../../../Others/AssignUserGroupDialog/AssignUserGroupDialog';

interface AssignUserGroupProps {
  serviceRequest: ServiceRequest;
}

const AssignUserGroup = (props: AssignUserGroupProps) => {
  const { id } = useParams<RouteParams>();
  const { state } = useStateValue();
  const [userData, setUserData] = useState(state.ManageUser.userData);
  const [assignGroupData, setAssignGroup] = useState<AssignGroupData[]>([]);
  const [error, setErrorState] = useState<UserFormError>({});
  const [isAssignGroupDialog, setAssignGroupDialog] = useState(false);
  const smLabels = languageService().staffManagement;
  const history = useHistory();

  const OBJECT_TYPE = 'object';

  useEffect(() => {
    setUserData(state.ManageUser.userData);
    setAssignGroup(state.ManageUser.userData.assignGroupData);
  }, [state.ManageUser.userData]);

  const handleInputChange = (e: any) => {
    if (e.action === FormActionType.ADD) {
      const updateUserData = assignGroupData;
      updateUserData.push(e.value);
      setAssignGroup(updateUserData);
      return;
    }
    if (e.action === FormActionType.UPDATE) {
      const updatedObj = (assignGroupData || []).map((assignGroupItem: AssignGroupData, index: number) => {
        if (e.index === index) {
          const value = e.target.value || '';
          const nameKey = `${e.target.name}Name`;
          setErrorState((prevObjs) => ({
            ...prevObjs,
            [index]: { ...error[index], [e.target.name]: { isValid: true } },
          }));
          return {
            ...assignGroupItem,
            [e.target.name]: typeof value === OBJECT_TYPE ? { ...value } : value,
            [nameKey]: e.target[nameKey],
          };
        }

        return assignGroupItem;
      });
      setUserData({ ...userData, assignGroupData: updatedObj });
      setAssignGroup(updatedObj);
      return;
    }
  };

  const onClose = (index: number) => {
    const updatedPanel = assignGroupData;
    updatedPanel.splice(index - 1, 1);
    setAssignGroup(updatedPanel);
  };

  const userAssignmentsvalidator = () => {
    let isAssignmentsValid = true;
    const errorObject: UserFormError = {};

    const formStepRules = manageUserFormRules(FormStepType.ASSIGN_GROUP, id);
    Object.keys(formStepRules).forEach((key: string) => {
      if (!isAssignmentsValid) {
        return;
      }
      userData.assignGroupData.map((item: AssignGroupData, index: number) => {
        const isElementValid = FormValidation(userData.assignGroupData[index][key] || '', formStepRules[key]);
        errorObject[index] = errorObject[index] || {};
        errorObject[index][key] = isElementValid;
        if (!errorObject[index][key].isValid) isAssignmentsValid = false;

        return item;
      });
    });
    return { isAssignmentsValid, errorObject };
  };

  const assignUserGroupHandler = () => {
    const { isAssignmentsValid, errorObject } = userAssignmentsvalidator();
    if (!isAssignmentsValid) {
      setErrorState(errorObject);
      return;
    }
    setAssignGroupDialog(true);
  };

  const assingUserConfirmationHandler = () => {
    setAssignGroupDialog(false);
    const userGroupPayload = userData.assignGroupData.map((userGroupData: AssignGroupData) => {
      return {
        userGroupAssignmentUuid: userGroupData.userGroupAssignmentId || '',
        userGroupUuid: userGroupData.userGroup,
        locationUuid: userGroupData.location,
        effectiveFromDatetime: userGroupData.dateRange.startDate,
        effectiveToDatetime: userGroupData.dateRange.endDate,
      };
    });
    updateUserGroups(userGroupPayload, props.serviceRequest, id).subscribe((user: User) => {
      const userGroupString = getUserGroupAssignmentsName(user.userGroupAssignments);
      const userKeys = {
        givenName: user.givenName,
        familyName: user.familyName,
        userUuid: user.userUuid || '',
        group: `${smLabels.group} ${userGroupString}`,
      };
      const message = formatLanguageString(smLabels.assignUsergroupMessage, userKeys);
      history.push('/manageuser', message);
    });
  };

  return (
    <>
      <AssignGroup
        userData={userData}
        assignGroupData={assignGroupData}
        error={error}
        handleInputChange={handleInputChange}
        onClose={onClose}
        assignUserGroupHandler={assignUserGroupHandler}
      />
      {isAssignGroupDialog ? (
        <AssignUserGroupDialog
          modalCloseHandler={() => setAssignGroupDialog(false)}
          userGroups={userData.assignGroupData}
          assignUserHandler={assingUserConfirmationHandler}
        />
      ) : null}
    </>
  );
};

export default withServiceRequest(WithUser(AssignUserGroup));
