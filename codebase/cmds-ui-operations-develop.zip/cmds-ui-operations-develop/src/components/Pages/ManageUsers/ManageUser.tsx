import React from 'react';
import Form from './ManageUserForm/ManageUserFormHandler';
import AssignGroup from './UserAssignGroup/UserAssignGroup';
import Search from './ManageUsersSearchPanel/ManageUserSearchPanel';
import styles from './ManageUser.module.scss';
import PrivateRoute from '../../../routes/PrivateRoute';
import { Switch } from 'react-router-dom';
import ViewUserPage from '../../../components/Pages/ViewUserPage/ViewUserPage';

const ManageUsers = (props: any) => {
  const currentUrl = props.match.url;

  return (
    <div className={styles.container}>
      <Switch>
        <PrivateRoute path={currentUrl + '/viewUserPage/:id/updateuser/:id'} exact component={Form} />
        <PrivateRoute path={currentUrl + '/viewUserPage/:id/assigngroup/:id'} exact component={AssignGroup} />
        <PrivateRoute path={currentUrl + '/viewUserPage/:id'} exact component={ViewUserPage} />
        <PrivateRoute path={currentUrl + '/adduser'} component={Form} />
        <PrivateRoute path={currentUrl + '/updateuser/:id'} component={Form} />
        <PrivateRoute path={currentUrl + '/assigngroup/:id'} component={AssignGroup} />
        <PrivateRoute path={currentUrl} component={Search} />
      </Switch>
    </div>
  );
};

export default ManageUsers;
