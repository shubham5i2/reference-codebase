import React, { useState, useEffect, useContext } from 'react';
import UI from 'ielts-cmds-ui-component-library';

import { useStateValue } from '../../../../Store/helpers/UseStateValue';
import { FormValidation } from '../../../utils/FormValidation';
import manageUserFormRules, { FormStepType, FormActionType } from '../../../utils/ValidationRules/ManageUserForm';
import ManageUserForm from '../../../Templates/ManageUser/ManageUser';
import { useParams, useHistory } from 'react-router-dom';
import { addUserData } from '../../../../services/API/ManageUser/AddUserData';

import { getUserDetails } from '../../../../services/API/ManageUser/ViewUserDetails';
import withServiceRequest, { ServiceRequest, ConnectorInterface } from '../../../../services/utils/ServiceRequest';
import * as ManageUserActions from '../../../../Store/Actions/ManageUserActions';
import * as BreadCrumbActions from '../../../../Store/Actions/BreadCrumbActions';

import { AsyncResponseStatus, HttpMethod } from '../../../../services/Models/Api';
import { languageService, formatLanguageString } from '../../../../services/Language/LanguageService';
import { AssignGroupData } from '../../../../services/Models/StaffManagement';
import { UserFormError, RouteParams } from '../../../../services/Models/UIModels';

interface ManageUserFromProps {
  serviceRequest: ServiceRequest;
}
const StaffManagementForm = (props: ManageUserFromProps) => {
  const connectorContext = useContext<ConnectorInterface>(UI.ConnectorContext);
  const [currentStep, setcurrentStep] = useState(0);
  const smLabels = languageService().staffManagement;
  const formTitle = [smLabels.personalInformationTitle, smLabels.assignGroupsTitle, smLabels.ReviewDetailsTitle];
  const { state, dispatch } = useStateValue();
  const progressSteps = [smLabels.viewUserHeaderText, smLabels.assignUserGroupStepTitle, smLabels.ReviewDetailsTitle];
  const formSteps = [FormStepType.PERSONAL_PROFILE, FormStepType.ASSIGN_GROUP, FormStepType.REVIEW_PROFILE];
  const userInputData: any = [];

  const [userData, setUserData] = useState(state.ManageUser.userData);
  const [error, setErrorState] = useState<UserFormError>({});
  const [saveUserData, setSaveUserData] = useState(false);
  const [showError, setShowError] = useState(false);

  const { id } = useParams<RouteParams>();
  const history = useHistory();
  useEffect(() => {
    const method = id ? HttpMethod.PUT : HttpMethod.POST;
    const setUserData = () => {
      const userGroupAssignments = userData.assignGroupData.map((item: AssignGroupData) => ({
        userGroupAssignmentUuid: item.userGroupAssignmentId || '',
        userGroupUuid: item.userGroup,
        locationUuid: item.location,
        effectiveFromDatetime: item.dateRange.startDate,
        effectiveToDatetime: item.dateRange.endDate,
      }));
      const payLoadData = { ...userData, userGroupAssignments: userGroupAssignments };
      delete payLoadData.assignGroupData;

      addUserData(method, payLoadData, props.serviceRequest, id).subscribe((response) => {
        if (response.status === AsyncResponseStatus.SUCCESS && response.user) {
          const { user } = response;
          const userKeys = { givenName: user.givenName, familyName: user.familyName, userUuid: user.userUuid || '' };
          const message = id
            ? formatLanguageString(smLabels.updateUserMessage, userKeys)
            : formatLanguageString(smLabels.addUserMessage, userKeys);
          history.push('/manageuser', message);
        }
        setSaveUserData(false);
      });
    };
    if (saveUserData) {
      setUserData();
    }

    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [saveUserData]);

  useEffect(() => {
    if (id && state.ManageUser.userEditStatus) {
      getUserDetails(id, props.serviceRequest).subscribe((data) => {
        if (data) {
          dispatch({
            type: ManageUserActions.EDIT_USER_PROFILE_DATA,
            payload: data,
          });
          setUserData({ ...data });
        }
      });
    } else if (state.ManageUser.userEditStatus) {
      setUserData({});
      dispatch({
        type: ManageUserActions.CLEAR_USER_DATA,
        payload: {},
      });
    }

    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.ManageUser.userData, connectorContext.connectionId]);

  useEffect(() => {
    if (currentStep > 0) {
      dispatch({ type: BreadCrumbActions.HIDE_BACK });
    } else {
      dispatch({ type: BreadCrumbActions.SHOW_BACK, payload: id });
    }
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentStep]);

  const handleInputChange = (e: any) => {
    console.log({ e });
    if (e.type === FormStepType.ASSIGN_GROUP) {
      console.log({ e });
      if (e.action === FormActionType.ADD) {
        const updateUserData = userData.assignGroupData;
        updateUserData.push(e.value);
        setUserData({ ...userData, assignGroupData: updateUserData });
        return;
      }
      if (e.action === FormActionType.UPDATE) {
        const updatedObj = (userData.assignGroupData || []).map((assignGroupItem: AssignGroupData, index: number) => {
          if (e.index === index) {
            const value = e.target.value || '';
            const nameKey = `${e.target.name}Name`;
            const setError = { ...error };
            setErrorState((prevObjs) => ({
              ...prevObjs,
              [index]: { ...setError[index], [e.target.name]: { isValid: true } },
            }));
            let updatedItem = {
              ...assignGroupItem,
              [e.target.name]: typeof value === 'object' ? { ...value } : value,
              [nameKey]: e.target[nameKey],
            };

            if (e.target.name === 'locationType') {
              // Clear the locaiton and usergroup when locationType changes
              updatedItem = {
                ...updatedItem,
                location: '',
                locationName: '',
                userGroup: '',
              };
              dispatch({ type: ManageUserActions.CLEAR_LOCATIONS });
            }
            return updatedItem;
          }
          return assignGroupItem;
        });
        setUserData({ ...userData, assignGroupData: updatedObj });
        return;
      }
    } else if (e.target.name === 'partnerCode') {
      setUserData((prevState: any) => ({
        ...prevState,
        assignGroupData: [],
        [e.target.name]: e.target.value,
      }));
    } else {
      const eventType = e.target.type === 'toggle';
      const value = eventType ? e.target.checked : e.target.value;
      setUserData({ ...userData, [e.target.name]: value });
    }

    setErrorState({ ...error, [e.target.name]: { isValid: true } });
  };

  const onClose = (index: number) => {
    const updatedPanel = userData.assignGroupData;
    updatedPanel.splice(index - 1, 1);
    setUserData({ ...userData, assignGroupData: updatedPanel });
  };

  const errorHandler = () => {
    let isFormvalid = true;
    const formStepRules = manageUserFormRules(formSteps[currentStep], id);
    Object.keys(formStepRules).forEach((key: string) => {
      if (formSteps[currentStep] === FormStepType.ASSIGN_GROUP) {
        userData.assignGroupData.map((item: AssignGroupData, index: number) => {
          if (formStepRules[key]) {
            const data = FormValidation(userData.assignGroupData[index][key] || '', formStepRules[key]);
            const allowValidation = formStepRules[key].validationDependentValue;
            userInputData[index] = userInputData[index] || {};
            userInputData[index][key] = allowValidation
              ? userInputData[index][allowValidation]?.isValid === true
                ? data
                : { isValid: true }
              : data;
            if (!userInputData[index][key]?.isValid) isFormvalid = false;
          }
          return item;
        });
      } else {
        userInputData[key] = FormValidation(userData[key] || '', formStepRules[key], userData);
        if (!userInputData[key].isValid) isFormvalid = false;
      }
    });

    return [isFormvalid, userInputData];
  };
  const handleSubmit = () => {
    const isDependentFieldValid = true;
    const [isFormValid, errorObject] = errorHandler();
    setErrorState(errorObject);

    if (isFormValid && isDependentFieldValid) {
      setShowError(false);
      if (currentStep === 2) {
        setSaveUserData(true);
      }
    } else {
      setShowError(true);
    }
    return isFormValid && isDependentFieldValid;
  };

  const currentStepChangehandler = (currentIdx: number) => {
    setcurrentStep(currentIdx);
  };

  return (
    <ManageUserForm
      userData={userData}
      error={error}
      handleInputChange={handleInputChange}
      currentStep={currentStep}
      handleSubmit={handleSubmit}
      formTitle={formTitle}
      progressSteps={progressSteps}
      setcurrentStep={currentStepChangehandler}
      onClose={onClose}
      showError={showError}
      setShowError={setShowError}
    />
  );
};

export default withServiceRequest(StaffManagementForm);
