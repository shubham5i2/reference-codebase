import React, { useEffect } from 'react';
import ManageUsersGrid from '../../../Templates/ManageSearch/ManageSearchResults/ManageSearchResults';

const ManageUserSearchResults = (props: any) => {
  useEffect(() => {
    console.log('Inside Search Results - props :', props);
  }, [props]);

  const myProps = {
    data: [
      {
        name: ['HARRY', 'HART', 'orange'],
        staffId: '436670',
        emailId: 'hart.h@thoughtstrom.org',
        userGroups: 'Test Centre Admin',
        status: 'Active',
      },
    ],
    onPageChange: jest.fn(),
    onPageSizeChange: jest.fn(),
    gridState: {
      totalRecords: 1,
      initialState: {
        pageIndex: 0,
        pageSize: 2,
      },
      selectedPage: 1,
      selectedOptionValue: 20,
    },
    pageSizeOptions: [
      { text: '1-10', value: 10 },
      { text: '1-20', value: 20 },
      { text: '1-50', value: 50 },
    ],
    onColumnSort: jest.fn(),
    sortOption: {
      sortBy: 'name',
      sortType: 'DESC',
    },
  };

  return <ManageUsersGrid {...myProps} />;
};

export default ManageUserSearchResults;
