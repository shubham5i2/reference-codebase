import React, { useState, useEffect, useContext, useRef } from 'react';
import styles from './ManageUserSearchPanel.module.scss';
import SearchPanel from '../../../Templates/ManageSearch/ManageSearch';
import UI from 'ielts-cmds-ui-component-library';
import { useStateValue } from '../../../../Store/helpers/UseStateValue';
import { searchResult } from '../../../../services/API/ManageUser/SearchResult';
import ManageUsersGrid from '../../../Organisms/ManageUsersGrid/ManageUsersGrid';
import { useEffectUpdate, transformRequestValueFromString, getOptionsListWithId } from '../../../utils/utilities';
import { pageSizeOptions } from '../../../Organisms/ManageUsersGrid/ManageUsersGridConstants';
import withServiceRequest, { ConnectorInterface, ServiceRequest } from '../../../../services/utils/ServiceRequest';
import { DropDownDataSource } from '../../../../services/Models/UIModels';
import * as searchType from '../../../../constants/ManageUserSearchType';
import * as ManageUserActions from '../../../../Store/Actions/ManageUserActions';
import * as BreadCrumbActions from '../../../../Store/Actions/BreadCrumbActions';
import { languageService, formatLanguageString } from '../../../../services/Language/LanguageService';
import { ManageUserSearchPayload, UserStatus } from '../../../../services/Models/StaffManagement';
import { RouteComponentProps } from 'react-router-dom';
import UserGroupDropDown from '../../../Organisms/BaseDropDown/UserGroupDropDown/UserGroupDropDown';
import { DEFAULT_TOAST_MESSAGE_TIMER } from '../../../../constants/GlobalConstants';
import { LocationType } from '../../../Organisms/LocationDropdown/LocationDropdownUtils';
import LocationDropdown from '../../../Organisms/LocationDropdown/LocationDropdown';

interface MangeUserSearchPanelProps extends RouteComponentProps {
  serviceRequest: ServiceRequest;
}

const MangeUserSearchPanel = (props: MangeUserSearchPanelProps) => {
  const isFromSearchClick = useRef(false);
  const selectedSearchType = useRef('');
  const { state, dispatch } = useStateValue();
  const connectorContext = useContext<ConnectorInterface>(UI.ConnectorContext);

  const initialSearchData = { nickName: '', phoneNumber: '' };

  const [userData, setUserData] = useState([]);
  const [totalSearchResult, setTotalSearchResult] = useState(0);
  const [currentSelectedPage, setCurrentSelectedPage] = useState({ page: 1 });
  const [currentSelectedPageSize, setCurrentSelectedPageSize] = useState(pageSizeOptions[0].value);
  const [selectedSortOption, setSelectedSortOption] = useState({
    sortType: 'ASC',
    sortBy: 'userUuid',
  });

  const [basicSearchValue, setBasicSearchValue] = useState('');
  const [initialOpenState, setInitialOpenState] = useState(false);
  const [isSearchCriteriaValid, setSearchCriteriaValid] = useState(true);
  const [deleteUserMessage, setDeleteUserMessage] = useState('');
  const [isClearSearch, setClearSearch] = useState(false);
  const [searchData, setSearchData] = useState(initialSearchData);
  const [selectedUserGroup, setSelectedUserGroup] = useState<DropDownDataSource>({
    value: '',
    text: '',
  });
  const [testCentreList, setTestCentreList] = useState({
    selectedValue: '',
  });
  const [statusList, setStatusList] = useState({
    selectedValue: '',
  });
  const [isLoading, setLoading] = useState(false);
  const smLabels = languageService().staffManagement;

  useEffectUpdate(() => {
    if (!isFromSearchClick.current) {
      const { searchName, selectedUserStatus } = state.ManageUser.searchData;
      const name = searchName || searchType.DEFAULT;
      const reqBody = getSearchRequestBody(name, selectedUserStatus);
      getSearchResults(name, reqBody);
    } else if (isFromSearchClick.current && selectedSearchType.current !== '') {
      const reqBody = getSearchRequestBody(selectedSearchType.current);
      getSearchResults(selectedSearchType.current, reqBody);
      selectedSearchType.current = '';
    }
  }, [currentSelectedPage]);

  const getSearchResultsOnLoad = () => {
    const { searchName, body, selectedPage, selectedPageSizeIndex, sortOption, selectedUserStatus } =
      state.ManageUser.searchData;
    const selectedUserGroupState = state.ManageUser.searchData.selectedUserGroup;
    const { deletedUserId, deletedRow, deletedUserName } = state.ManageUser.searchResult;
    if (searchName !== '' && body) {
      isFromSearchClick.current = true;
      setCurrentSelectedPage(selectedPage);
      setCurrentSelectedPageSize(pageSizeOptions[selectedPageSizeIndex].value);
      setSelectedSortOption(sortOption);

      updateUI(searchName, body, selectedUserGroupState, selectedUserStatus);
      deletedUserId === ''
        ? getSearchResults(searchName, body, false)
        : onDeleteUserHandler(deletedRow, deletedUserId, deletedUserName, selectedPage);
    } else {
      const reqBody = getSearchRequestBody(searchType.DEFAULT);
      getSearchResults(searchType.DEFAULT, reqBody, false);
      deletedUserId !== '' && updateDeleteUserMessage(deletedUserId, deletedUserName);
    }
  };

  useEffect(() => {
    dispatch({ type: BreadCrumbActions.SHOW_BACK, payload: true });
    dispatch({
      type: ManageUserActions.CLEAR_USER_DATA,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    getSearchResultsOnLoad();
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [connectorContext.connectionId]);

  const updateUI = (
    searchName: string,
    body: ManageUserSearchPayload,
    userGroup: DropDownDataSource,
    userStatus: string,
  ) => {
    const { criteria } = body;
    if (searchName === searchType.BASIC || searchName === searchType.DEFAULT) {
      setBasicSearchValue(criteria.searchPhrase);
    } else {
      setBasicSearchValue(criteria.searchPhrase);
      setSearchData({ nickName: criteria.nickName, phoneNumber: criteria.phoneNumber });
      setSelectedUserGroup(userGroup);
      setTestCentreList({
        selectedValue: criteria.testCentre,
      });
      setStatusList({
        selectedValue: userStatus || '',
      });
      setInitialOpenState(true);
      setClearSearch(true);
    }
  };

  const statusOptions = [
    { value: UserStatus.ALL, text: smLabels.allStatus },
    { value: UserStatus.ACTIVE, text: smLabels.active },
    { value: UserStatus.INACTIVE, text: smLabels.inActive },
  ];

  const handleInputChange = (e: any) => {
    setClearSearch(true);
    const value = e.target.value;
    setSearchData({ ...searchData, [e.target.name]: value });
  };

  const onUserGroupDropdownChange = (value: string, text: string) => {
    setClearSearch(true);
    setSelectedUserGroup({
      value,
      text,
    });
  };

  const onTestCentreDropdownChange = (value: string) => {
    setClearSearch(true);
    setTestCentreList({
      selectedValue: value,
    });
  };

  const onStatusDropdownChange = (value: string) => {
    setClearSearch(true);
    setStatusList({
      selectedValue: value,
    });
  };
  const onClearSearch = (event: any) => {
    event.preventDefault();
    setSearchData(initialSearchData);
    setSelectedUserGroup({
      value: '',
      text: '',
    });
    setTestCentreList({
      selectedValue: '',
    });
    setStatusList({
      selectedValue: '',
    });
    setClearSearch(false);
  };

  const currentUrl = props.match.url;

  const onSearchHandler = (value: any) => {
    if (value === null || value === undefined || value === '') {
      setSearchCriteriaValid(false);
      return;
    }
    isFromSearchClick.current = true;
    selectedSearchType.current = searchType.BASIC;
    setCurrentSelectedPage(() => {
      return { page: 1 };
    });
    setSearchCriteriaValid(true);
  };

  const onAdvancedSearchHandler = () => {
    if (!basicSearchValue && !isClearSearch) {
      setSearchCriteriaValid(false);
    } else {
      isFromSearchClick.current = true;
      selectedSearchType.current = searchType.ADVANCE;
      setCurrentSelectedPage(() => {
        return { page: 1 };
      });
      setSearchCriteriaValid(true);
    }
  };

  const getSortingElement = (sortBy: string, sortType: string) => ({ sortBy, sortType });

  const getSearchRequestBody = (name: string, userStatusValue: string = statusList.selectedValue) => {
    const sorting = Array.isArray(selectedSortOption.sortBy)
      ? selectedSortOption.sortBy.map((sortBy) => getSortingElement(sortBy, selectedSortOption.sortType))
      : [getSortingElement(selectedSortOption.sortBy, selectedSortOption.sortType)];

    const userStatus = userStatusValue && userStatusValue !== UserStatus.ALL ? userStatusValue : '';
    const reqBody = {
      criteria: {
        searchPhrase: transformRequestValueFromString(basicSearchValue),
        userGroup: transformRequestValueFromString(selectedUserGroup.text),
        nickName: transformRequestValueFromString(searchData.nickName),
        phoneNumber: transformRequestValueFromString(searchData.phoneNumber),
        userStatus: transformRequestValueFromString(userStatus),
        testCentre: transformRequestValueFromString(testCentreList.selectedValue),
      },
      pagination: {
        pageNumber: currentSelectedPage.page - 1,
        pageSize: currentSelectedPageSize,
      },
      sorting,
    };
    return reqBody;
  };
  const getSearchResults = (name: string, body: any, shouldUpdateState = true) => {
    setLoading(true);
    const selectedPageSizeIndex = pageSizeOptions.findIndex((option) => option.value === currentSelectedPageSize);
    if (shouldUpdateState) {
      dispatch({
        type: ManageUserActions.MANAGE_USER_SEARCH,
        payload: {
          body,
          searchName: name,
          selectedUserStatus: statusList.selectedValue,
          selectedPage: currentSelectedPage,
          selectedPageSizeIndex,
          sortOption: selectedSortOption,
          selectedUserGroup: selectedUserGroup,
        },
      });
    }
    searchResult(body, props.serviceRequest).subscribe((data) => {
      setLoading(false);
      const gridData = data.gridData || [];
      const totalRecords = data.totalCount || 0;
      dispatch({ type: ManageUserActions.SEARCH_SUCCESS, payload: { totalCount: totalRecords } });
      setTotalSearchResult(totalRecords);
      setUserData(gridData);
    });
  };

  const onAddUserHandler = () => {
    props.history.push(currentUrl + '/adduser');
  };

  const onPageChangeHandler = (page: number) => {
    isFromSearchClick.current = false;
    setCurrentSelectedPage(() => {
      return { page: page + 1 };
    });
  };

  const onPageSizeChangeHandler = (value: any) => {
    setCurrentSelectedPageSize(() => value);
    isFromSearchClick.current = false;
    setCurrentSelectedPage(() => {
      return { page: 1 };
    });
  };

  const onColumnSortHandler = (column: any) => {
    const sortType =
      JSON.stringify(selectedSortOption.sortBy) === JSON.stringify(column.Header.name)
        ? selectedSortOption.sortType === 'ASC'
          ? 'DESC'
          : 'ASC'
        : 'ASC';
    const sortOption = {
      sortBy: column.Header.name,
      sortType,
    };
    setSelectedSortOption(() => sortOption);
    isFromSearchClick.current = false;
    setCurrentSelectedPage(() => {
      return { page: 1 };
    });
  };

  const removeMessage = () => {
    props.history.replace('/manageuser', '');
  };

  const onDeleteUserHandler = (
    deletedUserRow: number,
    deletedUserId: string,
    deletedUserName: string,
    currentPage: any = {},
  ) => {
    currentPage = currentPage.page ? currentPage : currentSelectedPage;
    updateDeleteUserMessage(deletedUserId, deletedUserName);
    isFromSearchClick.current = false;
    const { totalCount } = state.ManageUser.searchResult;
    const pageStartRow = (currentPage.page - 1) * currentSelectedPageSize;
    const deletedRow = pageStartRow + deletedUserRow;
    if (totalCount === deletedRow && deletedUserRow === 1) {
      setCurrentSelectedPage((prev) => {
        const page = prev.page - 1 > 0 ? prev.page - 1 : 1;
        return { page };
      });
    } else {
      setCurrentSelectedPage((prev) => {
        return { ...prev };
      });
    }
  };

  const updateDeleteUserMessage = (deleteUserId: string, userName: string) => {
    const deleteuserMsg = formatLanguageString(smLabels.deleteUserMessage, { userName, deleteUserId });
    setDeleteUserMessage(deleteuserMsg);
  };

  const getManageUsersGrid = () => {
    const gridState = {
      totalRecords: totalSearchResult,
      initialState: {
        pageSize: currentSelectedPageSize,
      },
      selectedPage: currentSelectedPage.page,
      selectedOptionValue: currentSelectedPageSize,
    };
    return (
      <div className={styles.searchResults}>
        <ManageUsersGrid
          data={userData || []}
          onPageChange={onPageChangeHandler}
          onPageSizeChange={onPageSizeChangeHandler}
          gridState={gridState}
          pageSizeOptions={pageSizeOptions}
          onColumnSort={onColumnSortHandler}
          sortOption={selectedSortOption}
          onUserDeleted={onDeleteUserHandler}
          isLoading={isLoading}
        />
      </div>
    );
  };

  return (
    <React.Fragment>
      <div className={styles.toastMessage}>
        {props.history.location?.state ? (
          <UI.Message
            id="toast_pane_success"
            color="success"
            dismissable
            onChange={removeMessage}
            visibleTill={DEFAULT_TOAST_MESSAGE_TIMER}
          >
            {<label id="toast_pane_success_msg">{props.history.location?.state}</label>}
          </UI.Message>
        ) : (
          ''
        )}
      </div>
      <div className={styles.toastMessage}>
        {deleteUserMessage !== '' ? (
          <UI.Message
            id="toast_pane_delete_success"
            color="success"
            dismissable
            onChange={() => setDeleteUserMessage('')}
            visibleTill={DEFAULT_TOAST_MESSAGE_TIMER}
          >
            {<label id="toast_pane_success_msg">{deleteUserMessage}</label>}
          </UI.Message>
        ) : null}
      </div>
      {!isSearchCriteriaValid ? (
        <div className={styles.messageContainer}>
          <UI.Message
            message={smLabels.searchCriteriaError}
            color="error"
            dismissable
            onChange={() => setSearchCriteriaValid(true)}
          />
        </div>
      ) : null}
      <SearchPanel
        title={smLabels.manageUserTitle}
        titleType="regular"
        titleSize={32}
        addButtonLabel={smLabels.addButtonLabel}
        addButtonColor="blueLine"
        addButtonIcon="plus"
        subTitle={smLabels.subTitle}
        subTitleType="regular"
        subTitleSize={16}
        searchBoxPlaceholder={smLabels.searchBoxPlaceHolder}
        searchBoxSearchIcon="button"
        onSearchHandler={() => onSearchHandler(basicSearchValue)}
        onAddUserHandler={onAddUserHandler}
        collapseTitle={smLabels.collapseTitle}
        collapseOpenTitle={smLabels.collapseTitle}
        collapseFooterTitle={smLabels.collapseFooterTitle}
        clearSearch={isClearSearch ? smLabels.clearSearch : ''}
        searchButtonLabel={smLabels.searchLabel}
        searchButtonColor="primary"
        onClearSearch={onClearSearch}
        onAdvancedSearchHandler={onAdvancedSearchHandler}
        basicSearchValue={basicSearchValue}
        onBasicSearchValueChange={(value: any) => setBasicSearchValue(value)}
        initialOpenState={initialOpenState}
      >
        <div className={styles.col3}>
          <UserGroupDropDown
            id="userGroup"
            label={smLabels.userGroup}
            serviceRequest={props.serviceRequest}
            selectedUserGroupValue={selectedUserGroup.value}
            onUserGroupChange={onUserGroupDropdownChange}
            searchPlaceHolderText={smLabels.usergroupSearchPlaceholder}
            canUseStoreData
            isFilterEnabled={true}
          />

          <UI.TextBox
            label={smLabels.nickName}
            name="nickName"
            placeholder=""
            value={searchData.nickName}
            onChange={handleInputChange}
          />

          <UI.TextBox
            label={smLabels.phonenumber}
            name="phoneNumber"
            placeholder=""
            value={searchData.phoneNumber}
            onChange={handleInputChange}
          />

          <UI.Dropdown
            id="status"
            label={smLabels.status}
            selectedValue={statusList.selectedValue}
            onChange={onStatusDropdownChange}
            list={statusOptions}
          />

          <LocationDropdown
            id={'testCentre'}
            labelText={smLabels.testCenter}
            locationType={LocationType.TEST_CENTRE}
            dataSource={'getLocations'}
            value={testCentreList.selectedValue}
            getOptionsList={getOptionsListWithId}
            onChange={({ value }: DropDownDataSource) => {
              onTestCentreDropdownChange(value);
            }}
          />
        </div>
      </SearchPanel>
      {getManageUsersGrid()}
    </React.Fragment>
  );
};

export default withServiceRequest(MangeUserSearchPanel);
