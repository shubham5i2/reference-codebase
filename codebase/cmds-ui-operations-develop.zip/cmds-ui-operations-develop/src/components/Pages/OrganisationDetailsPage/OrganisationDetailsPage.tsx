import React, { useEffect, useState, useContext } from 'react';
import styles from './OrganisationDetailsPage.module.scss';
import OrganisationDetails from '../../Molecules/OrganisationDetails/OrganisationDetails';
import ContactDetails from '../../Molecules/ContactDetails/ContactDetails';
import MinimumScoreData from '../../Organisms/MinimumScoreData/MinimumScoreData';
import OrganisationDetailsHeader from '../../Molecules/OrganisationDetailsHeader/OrganisationDetailsHeader';
import { useStateValue } from '../../../Store/helpers/UseStateValue';
import * as BreadCrumbActions from '../../../Store/Actions/BreadCrumbActions';
import { getOrganisation } from '../../../services/API/Organisation/OrganisationDetails';
import withServiceRequest, { ConnectorInterface, ServiceRequest } from '../../../services/utils/ServiceRequest';
import { useParams, useHistory } from 'react-router-dom';
import UI from 'ielts-cmds-ui-component-library';
import { OrganisationDetailResponseData } from '../../../services/Models/Organisation';
import * as OrganisationDataActions from '../../../Store/Actions/OrganisationDataActions';
import useDirectChild from './UseDirectChild';
import { RouteParams } from '../../../services/Models/UIModels';

interface OrganisationDetailsPageProps {
  serviceRequest: ServiceRequest;
}

const OrganisationDetailsPage = (props: OrganisationDetailsPageProps) => {
  const { dispatch } = useStateValue();
  const [organisationDetail, setOrganisationDetail] = useState<OrganisationDetailResponseData>(Object);
  const connectorContext = useContext<ConnectorInterface>(UI.ConnectorContext);
  const { id } = useParams<RouteParams>();
  const history = useHistory();
  const { setRoId, directChildren } = useDirectChild(props.serviceRequest);

  useEffect(() => {
    dispatch({ type: BreadCrumbActions.SHOW_BACK });
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    getOrganisation(id, props.serviceRequest).subscribe((organisationDetail) => {
      if (organisationDetail) {
        setOrganisationDetail(organisationDetail);
        setRoId(organisationDetail.organisationDetail?.recognisingOrganisationUuid);
        dispatch({ type: OrganisationDataActions.ORGANISATION_DATA_SUCCESS, payload: organisationDetail });
      }
    });
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [connectorContext.connectionId]);

  const onHeaderActionHandler = (selectedAction: string) => {
    const currentUrl = history.location.pathname.split('/organisationDetails')?.[0];
    switch (selectedAction) {
      case 'Update': {
        history.push(`${currentUrl}/update/${organisationDetail?.currentRoID}`);
        break;
      }
    }
  };

  return (
    <div className={styles.orgDetailPageContainer}>
      <div className={styles.orgHeaderWrapper}>
        <div className={styles.orgHeaderContainer}>
          <OrganisationDetailsHeader
            headerData={organisationDetail?.organisationDetail}
            onHeaderActionHandler={onHeaderActionHandler}
          />
        </div>
      </div>
      <div className={styles.orgDetails}>
        <OrganisationDetails
          organisationDetail={organisationDetail?.organisationDetail}
          directChildren={directChildren}
        />
      </div>
      <div className={styles.orgDetails}>
        <ContactDetails
          primaryContactAddress={organisationDetail?.contactDetail?.primaryContactAddress}
          adminContactAddress={organisationDetail?.contactDetail?.adminContactAddress}
        />
      </div>
      <div className={styles.orgDetails}>
        <MinimumScoreData minimumScore={organisationDetail?.minimumScore} />
      </div>
    </div>
  );
};

export default withServiceRequest(OrganisationDetailsPage);
