import { useEffect, useState } from 'react';
import { getAdditionalDeliveryOrganisation } from '../../../services/API/Organisation/AdditionalDeliveryOrganisation';
import { AsyncResponseStatus } from '../../../services/Models/Api';
import { ServiceRequest } from '../../../services/utils/ServiceRequest';
import { DropDownDataSource } from '../../../services/Models/UIModels';

const useDirectChild = (serviceRequest: ServiceRequest) => {
  const [roID, setRoId] = useState('');
  const [directChildren, setDirectChildren] = useState<DropDownDataSource[]>([]);
  useEffect(() => {
    if (roID) {
      getAdditionalDeliveryOrganisation(serviceRequest, '', roID, true).subscribe((data) => {
        if (data.status === AsyncResponseStatus.SUCCESS) {
          setDirectChildren(data.additionalDeliveryOrganisationData || []);
        }
      });
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [roID]);

  return {
    directChildren,
    setRoId,
  };
};

export default useDirectChild;
