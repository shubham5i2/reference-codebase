import React, { useContext, useEffect, useRef, useState } from 'react';
import UI from 'ielts-cmds-ui-component-library';
import { useParams, useHistory } from 'react-router-dom';
import { getTestTakerBookingHistory } from '../../../services/API/TestTaker/GetTestTakerBookingHistory';
import withServiceRequest, { ConnectorInterface, ServiceRequest } from '../../../services/utils/ServiceRequest';
import * as BreadCrumbActions from '../../../Store/Actions/BreadCrumbActions';
import { useStateValue } from '../../../Store/helpers/UseStateValue';
import {
  DeleteBanDetails,
  TestTakerBookingHistoryResponse,
  TestTakerInfo,
} from '../../../services/Models/TestTakerManagement';
import TestTakerBookingHistoryHeader from '../../Organisms/TestTakerBookingHistoryHeader/TestTakerBookingHistoryHeader';
import { languageService } from '../../../services/Language/LanguageService';
import TestTakerBookingHistoryLeftPanel from '../../Organisms/TestTakerBookingHistoryLeftPanel/TestTakerBookingHistoryLeftPanel';
import TestTakerBookingHistoryExclusionPanel from '../../Organisms/TestTakerBookingHistoryExclusionPanel/TestTakerBookingHistoryExclusionPanel';
import visibilityIcon from '../../../assets/images/visibility.svg';
import EditIcon from '../../../assets/images/Edit.svg';
import DeleteIcon from '../../../assets/images/Delete.svg';
import { getResultStatuses } from '../../../services/API/TestTaker/GetTestTakerResultStatus';
import styles from './TestTakerBookingHistoryPage.module.scss';
import { Action, AsyncResponseStatus } from '../../../services/Models/Api';
import RemoveBookingDialog from '../../Others/RemoveBookingDialog/RemoveBookingDialog';
import * as TestTakerAction from '../../../Store/Actions/ManageTestTakerActions';
import { BookingResultsResponseV2 } from '../../Pages/Results/ResultsTestTakerDetails/ResultsTestTakerDetailsConstants';
import BanPanel from '../../Organisms/Ban/BanPanel';
import AddBan, { BanDetails } from '../../Organisms/Ban/AddBan';
import UpdateBan from '../../Organisms/Ban/UpdateBan';
import { addUpdateBan } from '../../../services/API/ManageUser/AddUpdateBan';
import { getAllBanReasons, getOtherReason } from '../../../services/API/Reference/BanReason';
import {
  initialBookingHistoryData,
  initialCurrentResultStatus,
} from '../../../constants/ManageTestTaker/BookingHistory';
import GenericPopup, { ButtonPosition, DialogType, TitlePosition } from '../../Organisms/GenericPopup/GenericPopup';
import { deleteBan } from '../../../services/API/ManageUser/DeleteBan';
import { UIButtonType } from '../../../services/Models/UIModels';

interface TestTakerBookingHistoryPageProps {
  errorMessage: string | null;
  addButtonIcon: string;
  serviceRequest: ServiceRequest;
  testTakerInfo: TestTakerInfo;
  testTakerUuid: string;
  deleteBanDetails: DeleteBanDetails;
  showErrorMessage: boolean;
  onRemoveErrorMessage: () => void;
}

export interface TestTakerBookingHistoryPageActionsProps {
  action: Action;
  index: number;
  bookingUuid: string;
  uniqueTestTakerUuid: string;
  testTakerName: string;
}

export interface BookingHistoryActionsProps {
  label: string;
  type: string;
  icon: SVGElement;
}

export interface BanActionsProps {
  label: string;
  type: string;
  icon: SVGElement;
}

const TestTakerBookingHistoryPage = (props: TestTakerBookingHistoryPageProps) => {
  const { state, dispatch } = useStateValue();
  const { id } = useParams<{ id: string }>();
  const ttbhActionsContainerRef = useRef<HTMLSpanElement>();
  const [selectedToolTipIndex, setSelectedToolTipIndex] = useState<number | null>(null);
  const [selectedBanToolTipIndex, setSelectedBanToolTipIndex] = useState<number | null>(null);
  const [isDeleteBookingIdx, setisDeleteBookingIdx] = useState(-1);
  const [selectedBookingUuid, setSelectedBookingUuid] = useState('');
  const [selectedUniqueTestTakerUuid, setSelectedUniqueTestTakerUuid] = useState('');
  const [isExclusionPanelAction, setExclusionPanelAction] = useState(false);
  const [testTakerName, setTestTakerName] = useState('');
  const [isSingleBookingHistory, setSingleBookingHistory] = useState(false);
  const [selectedUniqueTestTakerId, setSelectedUniqueTestTakerId] = useState('');
  const testTakerLabels = languageService().testTaker;
  const [activeTab, setActiveTab] = useState(testTakerLabels.bookingHistory);
  const [isAddBanClicked, setIsAddBanClicked] = useState(false);
  const [currentResultStatus, setCurrentResultStatus] = useState(initialCurrentResultStatus);
  const [banMandatoryFieldError, setBanMandatoryFieldError] = useState('');
  const [removeBanMandatoryFieldError, setremoveBanMandatoryFieldError] = useState('');

  const [updateBanMandatoryFieldError, setUpdateBanMandatoryFieldError] = useState('');
  const [isStartDateEmpty, setIsStartDateEmpty] = useState(false);
  const [isDurationEmpty, setIsDurationEmpty] = useState(false);
  const [isReasonEmpty, setIsReasonEmpty] = useState(false);
  const [currentActionType, setCurrentActionType] = useState('');
  const [isPartnerSecondaryApproverEmpty, setIsPartnerSecondaryApproverEmpty] = useState(false);
  const [isBanCommentsMoreThan100Chars, setIsBanCommentsMoreThan100Chars] = useState(false);
  const [isBanCommentWithNonOtherReason, setIsBanCommentWithNonOtherReason] = useState(false);
  const [isEmptyBanCommentWithOtherReason, setIsEmptyBanCommentWithOtherReason] = useState(false);
  const [isAddBanModalOpen, setIsAddBanModalOpen] = useState(false);
  const [banPeriodUuid, setBanPeriodUuid] = useState('');
  const [deleteBanData, setDeleteBanData] = useState('');
  const [isDeleteBanMode, setisDeleteBanMode] = useState(-1);
  const [isUpdateBanModalOpen, setIsUpdateBanModalOpen] = useState(false);
  const [addBanAPIResponseMessage, setBanActionAPIResponseMessage] = useState('');
  const [banInUpdateMode, setBanInUpdateMode] = useState<number | null>(null);
  const [isUpdateBanMode, setIsUpdateBanMode] = useState(false);
  const connectorContext = useContext<ConnectorInterface>(UI.ConnectorContext);
  const [bookingHistoryDetail, setBookingHistoryDetail] =
    useState<TestTakerBookingHistoryResponse>(initialBookingHistoryData);

  const history = useHistory();
  const [selectedBooking, setSelectedBooking] = useState(
    history.location.state?.selectedBookingUuid ? history.location.state.selectedBookingUuid : '',
  );
  const [selectedBan, setSelectedBan] = useState(
    history.location.state?.selectedBanPeriodUuid ? history.location.state.selectedBanPeriodUuid : '',
  );
  const bookingHistoryActions: BookingHistoryActionsProps[] = [
    {
      label: testTakerLabels.viewDetails,
      type: TestTakerAction.VIEW_BOOKING,
      icon: visibilityIcon,
    },
    {
      label: isExclusionPanelAction ? testTakerLabels.removeExclusion : testTakerLabels.removeBooking,
      type: TestTakerAction.DELETE_BOOKING,
      icon: DeleteIcon,
    },
  ];
  const banActions: BanActionsProps[] = [
    {
      label: testTakerLabels.editBan,
      type: TestTakerAction.UPDATE_BAN,
      icon: EditIcon,
    },
    {
      label: testTakerLabels.deleteBan,
      type: TestTakerAction.DELETE_BAN,
      icon: DeleteIcon,
    },
  ];

  useEffect(() => {
    document.addEventListener('mousedown', handleClick);
    return () => {
      document.removeEventListener('mousedown', handleClick);
    };
  }, []);

  /** - IMOD-16990 created to handle this globally */
  const handleClick = (e: Event) => {
    const bookingHistoryActionsContainerClassName =
      ttbhActionsContainerRef.current && ttbhActionsContainerRef.current !== null
        ? ttbhActionsContainerRef.current?.className
        : '';
    const target = e.target as HTMLElement;
    const targetElementClassName =
      target.offsetParent && target.offsetParent !== null ? target.offsetParent.className : '';
    if (
      bookingHistoryActionsContainerClassName === targetElementClassName ||
      targetElementClassName.includes('TestTakerBookingHistoryExclusionPanel_exclusionListActionsContainer') ||
      targetElementClassName.includes('ManageUsersActions_manageUsersActions') ||
      targetElementClassName.includes('TestTakerBookingHistoryLeftPanel_ttbhActionsContainer')
    ) {
      return;
    }
    setSelectedToolTipIndex(null);
    setSelectedBanToolTipIndex(null);
  };

  const addBookingActionHandler = (action: Action) => {
    const currentUrl = history.location.pathname;
    switch (action.type) {
      case TestTakerAction.ADD_BOOKING:
        history.push(`${currentUrl}/associateuttid`, {
          ignoreIncompleteBooking: true,
          uniqueTestTakerId: bookingHistoryDetail.uniqueTestTakerId,
        });
        break;
    }
  };

  const ttbhActionsHandler = (props: TestTakerBookingHistoryPageActionsProps) => {
    const currentUrl = history.location.pathname;
    setSelectedBookingUuid(props.bookingUuid);
    setSelectedUniqueTestTakerUuid(props.uniqueTestTakerUuid);
    setTestTakerName(props.testTakerName);
    switch (props.action.type) {
      case TestTakerAction.VIEW_BOOKING:
        dispatch({
          type: TestTakerAction.VIEW_BOOKING,
          payload: {
            selectedUniqueTestTakerUuid: props.uniqueTestTakerUuid,
            selectedBookingUuid: selectedBooking,
          },
        });
        history.push(`${currentUrl}/testtakerbookingdetails/${props.bookingUuid}`, {
          selectedBookingUuid: props.bookingUuid,
          selectedTestTakerUuid: props.uniqueTestTakerUuid,
          selectedUniqueTestTakerId: selectedUniqueTestTakerId,
        });
        break;
      case TestTakerAction.DELETE_BOOKING:
        setisDeleteBookingIdx(props.index + 1);
        break;
    }
    setSelectedToolTipIndex(null);
  };

  const banActionsHandler = (action: Action, index: number, banPeriodUuid: string) => {
    switch (action.type) {
      case TestTakerAction.UPDATE_BAN:
        setIsUpdateBanMode(true);
        setCurrentActionType('update');
        setBanInUpdateMode(index);
        break;
      case TestTakerAction.DELETE_BAN:
        //this will be updated with actual logic when working on delete ban feature
        setisDeleteBanMode(index + 1);
        setBanPeriodUuid(banPeriodUuid);
        setCurrentActionType('delete');
        break;
    }
    setSelectedToolTipIndex(null);
  };

  const moreClickHandler = (index: number, exclusionAction: boolean) => {
    if (selectedToolTipIndex === index) {
      setSelectedToolTipIndex(null);
      setExclusionPanelAction(exclusionAction);
    } else {
      setSelectedToolTipIndex(index);
      setExclusionPanelAction(exclusionAction);
    }
  };

  const toolTipClickHandler = (index: number) => {
    setCurrentActionType('');
    setSelectedBanToolTipIndex(index);
  };

  const getBookingHistoryData = () => {
    const { selectedUniqueTestTakerUuid: historicalUttUuid, selectedBookingUuid: historicalBookingUuid } =
      state.manageTestTaker.viewBookingHistoryData;

    const searchUttUuid = historicalUttUuid !== '' ? historicalUttUuid : id;

    historicalBookingUuid !== '' && setSelectedBooking(historicalBookingUuid);

    getTestTakerBookingHistory(searchUttUuid, props.serviceRequest).subscribe(
      (bookingHistoryData: TestTakerBookingHistoryResponse) => {
        if (bookingHistoryData && bookingHistoryData.bookingHistory?.length > 0) {
          setBookingHistoryDetail(bookingHistoryData);
          setSingleBookingHistory(bookingHistoryData.bookingHistory.length === 1);
          setSelectedUniqueTestTakerId(bookingHistoryData.uniqueTestTakerId);
        }
      },
    );
  };

  const removeBookingHandler = () => {
    !isSingleBookingHistory
      ? getBookingHistoryData()
      : !isExclusionPanelAction
      ? history.push('/managetesttaker')
      : getBookingHistoryData();
  };

  const getRemoveBookingModal = () => {
    return isDeleteBookingIdx > 0 ? (
      <RemoveBookingDialog
        id="removeBookingDialogComponent"
        title={isExclusionPanelAction ? testTakerLabels.removeExclusionTitle : testTakerLabels.removeBooking}
        label={testTakerLabels.removeExclusionLabel}
        bookingUuid={selectedBookingUuid}
        modalCloseHandler={() => setisDeleteBookingIdx(-1)}
        removeHandler={removeBookingHandler}
        uniqueTestTakerUuid={selectedUniqueTestTakerUuid}
        isExclusionAction={isExclusionPanelAction}
        testTakerName={testTakerName}
      />
    ) : null;
  };

  const handleTextArea = (e: React.FormEvent<HTMLInputElement>) => {
    const target = e.target as HTMLInputElement;
    const value = target.value;
    setDeleteBanData(value);
  };

  const deleteBanDetails: DeleteBanDetails = {
    banDeleteReason: deleteBanData,
  };

  const renderToastErrorMsg = () => (
    <div className={styles.toastMessage} id="toastError">
      <UI.Message
        id="toastErrorMsg"
        color="error"
        dismissable
        onChange={removeBanAddedConfirmationMessage}
        visibleTill={5000}
      >
        {<label id="toastErrorLable">{testTakerLabels.banDeleteReason}</label>}
      </UI.Message>
    </div>
  );

  const onConfirmClick = () => {
    setBanActionAPIResponseMessage('');
    const uniqueTestTakerUuid = bookingHistoryDetail.uniqueTestTakerUuid;
    if (deleteBanDetails.banDeleteReason.trim() !== '') {
      setisDeleteBanMode(-1);
      deleteBan(deleteBanDetails, props.serviceRequest, uniqueTestTakerUuid, banPeriodUuid).subscribe((res) => {
        if (res.status === AsyncResponseStatus.SUCCESS && res?.response?.message) {
          setBanActionAPIResponseMessage(res?.response.message);
          refetchBookingHistory();
        }
      });
    } else {
      setremoveBanMandatoryFieldError(testTakerLabels.banDeleteReason);
    }
  };

  const getRemoveBanModal = () => {
    return isDeleteBanMode > 0 ? (
      <React.Fragment>
        {console.log('sdsf', removeBanMandatoryFieldError)}
        {removeBanMandatoryFieldError !== '' ? renderToastErrorMsg() : null}
        {addBanAPIResponseMessage ? renderBanAddedAPIResponseToastMsg(addBanAPIResponseMessage) : null}
        <GenericPopup
          id="ConfirmButton"
          title={testTakerLabels.deleteBan}
          titlePosition={TitlePosition.DEFAULT}
          buttonStyle={ButtonPosition.RIGHT}
          dialogType={DialogType.CUSTOM}
          label={testTakerLabels.removeBanExclusionLabel}
          buttonData={ButtonData}
          modalCloseHandler={() => setisDeleteBanMode(-1)}
        >
          <div className={styles.popupChildrens}>
            <div>
              <span>
                {bookingHistoryDetail.bookingHistory[0].bookingDetails.testTakerInfo.firstName}
                {bookingHistoryDetail.bookingHistory[0].bookingDetails.testTakerInfo.lastName} (
                {bookingHistoryDetail.uniqueTestTakerId})
              </span>
            </div>
            <br></br>
            <UI.TextArea
              label={testTakerLabels.banRemovalReason}
              labelId="banRemoval"
              value={deleteBanData}
              name="banRemoval"
              errorMessage={removeBanMandatoryFieldError}
              className={styles.banCommentContainer}
              id="banRemoval"
              inputType="textArea"
              onChange={handleTextArea}
              maxLength={2000}
              mandatory
            />
          </div>
        </GenericPopup>
      </React.Fragment>
    ) : null;
  };

  const ButtonData = [
    {
      id: 'ConfirmButton',
      text: 'Confirm',
      type: UIButtonType.PRIMARY,
      onChange: onConfirmClick,
    },
  ];

  const changeTabHandler = (e: React.MouseEvent<HTMLElement>) => {
    const tabElement = e.target as HTMLElement;
    const tab = tabElement.innerHTML;
    setActiveTab(tab);
  };

  const addBanClickHandler = () => {
    if (!isUpdateBanMode) {
      setIsAddBanClicked(true);
    }
  };

  const getResultStatusData = (bookingUuid: string) => {
    getResultStatuses(bookingUuid, props.serviceRequest).subscribe((resultStatusResponse: BookingResultsResponseV2) => {
      resultStatusResponse &&
        resultStatusResponse.bookingDetails &&
        setCurrentResultStatus(resultStatusResponse.bookingDetails.currentResultStatus);
    });
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case testTakerLabels.bookingHistory:
        return (
          <div className={styles.tthistoryContainer}>
            <div className={styles.tthistorySubContainer}>
              {getRemoveBookingModal()}
              {bookingHistoryDetail.bookingHistory?.map((booking, index) => {
                const isExpanded = selectedBooking && selectedBooking === booking.bookingUuid;
                const bookingHistoryProps = {
                  ...booking,
                  uniqueTestTakerUuid: bookingHistoryDetail.uniqueTestTakerUuid,
                  index: index + 1,
                  isExpanded,
                  onExpandClickHandler,
                  selectedToolTipIndex,
                  historyPanelActions: bookingHistoryActions,
                  moreClickHandler,
                  userActionsClickHandler: ttbhActionsHandler,
                  actionContainerRef: ttbhActionsContainerRef as React.RefObject<HTMLSpanElement>,
                  isExclusionPanelAction,
                  getResultStatusData,
                  resultData: currentResultStatus,
                };
                return <TestTakerBookingHistoryLeftPanel {...bookingHistoryProps} key={booking.bookingUuid} />;
              })}
              <div
                className={`${styles.tthistorySubContainer} ${styles.addButton}`}
                id="addBookingButtonContainer"
                onClick={() => addBookingActionHandler({ type: TestTakerAction.ADD_BOOKING })}
              >
                <UI.Button label={testTakerLabels.ttbhAddBookingLabel} color="blueLine" icon="plus" id="addBooking" />
              </div>
              <TestTakerBookingHistoryExclusionPanel
                exclusionList={bookingHistoryDetail.exclusionList}
                selectedToolTipIndex={selectedToolTipIndex}
                exclusionPanelActions={bookingHistoryActions}
                moreClickHandler={moreClickHandler}
                userActionsClickHandler={ttbhActionsHandler}
                actionContainerRef={ttbhActionsContainerRef as React.RefObject<HTMLSpanElement>}
                isExclusionPanelAction={isExclusionPanelAction}
              />
            </div>
          </div>
        );
      case testTakerLabels.ttbhBanDetailsLabel:
        return (
          <div className={styles.banList}>
            {getRemoveBanModal()}
            {bookingHistoryDetail.testtakerBanInfo.map((ban, index) => {
              const banPanelProps = {
                banDetails: ban,
                banPeriodUuid: ban.bannedPeriodUuid,
                banActions: banActions,
                banActionsClickHandler: banActionsHandler,
                currentActionType: currentActionType,
                index: index,
                isExpanded: selectedBan && selectedBan === ban.bannedPeriodUuid,
                onExpandClickHandler: onExpandBanClickHandler,
                selectedToolTipIndex: selectedBanToolTipIndex,
                toolTipClickHandler: toolTipClickHandler,
              };
              return <BanPanel {...banPanelProps} key={ban.bannedPeriodUuid} />;
            })}
          </div>
        );
    }
  };

  useEffect(() => {
    dispatch({ type: BreadCrumbActions.SHOW_BACK });
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    getBookingHistoryData();
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [connectorContext.connectionId]);

  const onExpandClickHandler = (bookingUuid: string) => {
    const selectedBookingUuid = selectedBooking === bookingUuid ? '' : bookingUuid;
    setSelectedBooking(selectedBookingUuid);
    selectedBooking !== bookingUuid && getResultStatusData(bookingUuid);
  };

  const onExpandBanClickHandler = (banPeriodUuid: string) => {
    const selectedBanPeriodUuid = selectedBan === banPeriodUuid ? '' : banPeriodUuid;
    setSelectedBan(selectedBanPeriodUuid);
  };

  const onCancelBanHandler = () => {
    setIsAddBanClicked(false);
    setIsStartDateEmpty(false);
    setIsDurationEmpty(false);
    setIsReasonEmpty(false);
    setIsPartnerSecondaryApproverEmpty(false);
    setIsBanCommentsMoreThan100Chars(false);
    setIsBanCommentWithNonOtherReason(false);
    setIsEmptyBanCommentWithOtherReason(false);
    setBanMandatoryFieldError('');
  };

  const onCancelUpdateActionHandler = () => {
    setIsUpdateBanMode(false);
    setBanInUpdateMode(null);
    setIsStartDateEmpty(false);
    setIsDurationEmpty(false);
    setIsReasonEmpty(false);
    setIsPartnerSecondaryApproverEmpty(false);
    setIsBanCommentsMoreThan100Chars(false);
    setIsBanCommentWithNonOtherReason(false);
    setIsEmptyBanCommentWithOtherReason(false);
    setUpdateBanMandatoryFieldError('');
  };

  const onAddBanBtnClickHandler = (newBan: BanDetails) => {
    const otherReasonAndEmptyComments = newBan.reasonUuid === getOtherReason() && isNullOrEmpty(newBan.banComments);

    const nonOtherReasonAndNonEmptyComments =
      newBan.reasonUuid !== getOtherReason() && !isNullOrEmpty(newBan.banComments);

    if (anyBanFieldsError(newBan, otherReasonAndEmptyComments, nonOtherReasonAndNonEmptyComments)) {
      setBanMandatoryFieldError(testTakerLabels.toastErrorBan);
    }

    banFieldsEmptyChecks(newBan, otherReasonAndEmptyComments, nonOtherReasonAndNonEmptyComments);

    if (isAllFieldsEnteredCorrectly(newBan)) {
      setIsAddBanModalOpen(true);
    }
  };

  const onUpdateBanClickHandler = (updatedBan: BanDetails) => {
    setUpdateBanMandatoryFieldError('');

    const otherReasonAndEmptyComments =
      updatedBan.reasonUuid === getOtherReason() && isNullOrEmpty(updatedBan.banComments);

    const nonOtherReasonAndNonEmptyComments =
      updatedBan.reasonUuid !== getOtherReason() && !isNullOrEmpty(updatedBan.banComments);

    if (anyBanFieldsError(updatedBan, otherReasonAndEmptyComments, nonOtherReasonAndNonEmptyComments)) {
      setUpdateBanMandatoryFieldError(testTakerLabels.toastErrorBan);
    }

    banFieldsEmptyChecks(updatedBan, otherReasonAndEmptyComments, nonOtherReasonAndNonEmptyComments);

    if (isAllFieldsEnteredCorrectly(updatedBan)) {
      setIsUpdateBanModalOpen(true);
    }
  };

  const removeErrorMessage = () => {
    setBanMandatoryFieldError('');
  };

  const removeUpdateErrorMessage = () => {
    setUpdateBanMandatoryFieldError('');
  };

  const removeBanAddedConfirmationMessage = () => {
    setBanActionAPIResponseMessage('');
    setremoveBanMandatoryFieldError('');
  };

  const updateStartDateToNotEmpty = () => {
    setIsStartDateEmpty(false);
  };

  const updateDurationToNotEmpty = () => {
    setIsDurationEmpty(false);
  };

  const updateBanReasonToNotEmpty = () => {
    setIsReasonEmpty(false);
  };

  const updateSecondaryPartnerApproverToNotEmpty = () => {
    setIsPartnerSecondaryApproverEmpty(false);
  };

  const updateSecondaryPartnerApproverEmpty = () => {
    setIsPartnerSecondaryApproverEmpty(true);
  };

  const updateBanCommentsMoreThan100Chars = (isMoreThan100chars: boolean) => {
    setIsBanCommentsMoreThan100Chars(isMoreThan100chars);
  };

  const updateBanCommentWithNonOtherReason = (isEnteredWithOtherReason: boolean) => {
    setIsBanCommentWithNonOtherReason(isEnteredWithOtherReason);
  };

  const updateEmptyBanCommentWithOtherReason = (isOtherReasonAndEmptyComment: boolean) => {
    setIsEmptyBanCommentWithOtherReason(isOtherReasonAndEmptyComment);
  };

  const closeAddBanModal = () => {
    setIsAddBanModalOpen(false);
  };

  const closeUpdateBanModal = () => {
    setIsUpdateBanModalOpen(false);
  };

  const callAddNewBanAPIwithPayload = (newBan: BanDetails) => {
    setBanActionAPIResponseMessage('');
    const uniqueTestTakerUuid = bookingHistoryDetail.uniqueTestTakerUuid;

    addUpdateBan(newBan, props.serviceRequest, uniqueTestTakerUuid).subscribe((res) => {
      if (res.status === AsyncResponseStatus.SUCCESS && res?.response?.message) {
        setIsAddBanModalOpen(false);
        setIsAddBanClicked(false);
        setBanActionAPIResponseMessage(res?.response.message);
        refetchBookingHistory();
      }
    });
  };

  const callUpdateBanAPIwithPayload = (updatedBan: BanDetails) => {
    setBanActionAPIResponseMessage('');
    const uniqueTestTakerUuid = bookingHistoryDetail.uniqueTestTakerUuid;

    addUpdateBan(updatedBan, props.serviceRequest, uniqueTestTakerUuid).subscribe((res) => {
      if (res.status === AsyncResponseStatus.SUCCESS && res?.response?.message) {
        setIsUpdateBanModalOpen(false);
        setIsUpdateBanMode(false);
        setBanActionAPIResponseMessage(res?.response.message);
        refetchBookingHistory();
      }
    });
  };

  function refetchBookingHistory() {
    //waiting 5 secs for succesful message to disappear before refetching data
    setTimeout(function () {
      setDeleteBanData('');
      getBookingHistoryData();
    }, 5000);
  }

  const renderBanAddedAPIResponseToastMsg = (addBanAPIResponseMessage: string) => (
    <div className={styles.toastMessage} id="toast_panel_ban_added_container">
      <UI.Message
        id="toast_panel_results_successful"
        dismissable
        onChange={removeBanAddedConfirmationMessage}
        visibleTill={5000}
        color={isSuccessful(addBanAPIResponseMessage) ? 'success' : 'error'}
      >
        {<label id="toast_panel_results_successful_msg">{addBanAPIResponseMessage}</label>}
      </UI.Message>
    </div>
  );

  function isSuccessful(addBanAPIResponseMessage: string) {
    return addBanAPIResponseMessage === 'Ban event is successfully processed';
  }

  function banFieldsEmptyChecks(
    ban: BanDetails,
    otherReasonAndEmptyComments: boolean,
    nonOtherReasonAndNonEmptyComments: boolean,
  ) {
    if (isNullOrEmpty(ban.effectiveFromDate)) {
      setIsStartDateEmpty(true);
    }

    if (isNullOrEmpty(ban.duration)) {
      setIsDurationEmpty(true);
    }

    if (isNullOrEmpty(ban.reasonUuid)) {
      setIsReasonEmpty(true);
    }

    if (isNullOrEmpty(ban.partnerSecondaryApprover) || ban.partnerSecondaryApprover.trim().length === 0) {
      setIsPartnerSecondaryApproverEmpty(true);
    }

    if (otherReasonAndEmptyComments) {
      setIsEmptyBanCommentWithOtherReason(true);
    }

    if (nonOtherReasonAndNonEmptyComments) {
      setIsBanCommentWithNonOtherReason(true);
    }
  }

  function anyBanFieldsError(
    ban: BanDetails,
    otherReasonAndEmptyComments: boolean,
    nonOtherReasonAndNonEmptyComments: boolean,
  ) {
    return (
      isNullOrEmpty(ban.effectiveFromDate) ||
      isNullOrEmpty(ban.duration) ||
      isNullOrEmpty(ban.reasonUuid) ||
      otherReasonAndEmptyComments ||
      nonOtherReasonAndNonEmptyComments ||
      isNullOrEmpty(ban.partnerSecondaryApprover) ||
      (ban.banComments !== null && ban.banComments.length > 99)
    );
  }

  return (
    <React.Fragment>
      {addBanAPIResponseMessage ? renderBanAddedAPIResponseToastMsg(addBanAPIResponseMessage) : null}
      <TestTakerBookingHistoryHeader
        uniqueTestTakerId={bookingHistoryDetail.uniqueTestTakerId}
        uniqueTestTakerUuid={bookingHistoryDetail.uniqueTestTakerUuid}
        ttbhSubTitle={testTakerLabels.ttbhSubTitle}
        ttbhTitle={testTakerLabels.ttbhTitle}
        ttbhLabel={testTakerLabels.ttbhLabel}
        ttbhBanDetailsLabel={testTakerLabels.ttbhBanDetailsLabel}
        changeTabHandler={changeTabHandler}
        isTtbhClickable={true}
        isTtbhBanDetailsClickable={true}
        isTestTakerBanned={isTestTakerBannedToday(bookingHistoryDetail)}
        addBanClickHandler={addBanClickHandler}
        isAddBanClicked={isAddBanClicked}
      />
      {isAddBanClicked ? (
        <AddBan
          testTakerInfo={bookingHistoryDetail.bookingHistory[0].bookingDetails.testTakerInfo}
          testTakerUuid={bookingHistoryDetail.uniqueTestTakerId}
          onAddBanClickHandler={onAddBanBtnClickHandler}
          onCancelBanHandler={onCancelBanHandler}
          errorMessage={banMandatoryFieldError}
          onRemoveErrorMessage={removeErrorMessage}
          isStartDateEmpty={isStartDateEmpty}
          isDurationEmpty={isDurationEmpty}
          isReasonEmpty={isReasonEmpty}
          isPartnerSecondaryApproverEmpty={isPartnerSecondaryApproverEmpty}
          isBanCommentsMoreThan100Chars={isBanCommentsMoreThan100Chars}
          isBanCommentWithNonOtherReason={isBanCommentWithNonOtherReason}
          isEmptyBanCommentWithOtherReason={isEmptyBanCommentWithOtherReason}
          isAddBanModalOpen={isAddBanModalOpen}
          reasonOptions={banReasonListFrom()}
          updateStartDateToNotEmpty={updateStartDateToNotEmpty}
          updateDurationToNotEmpty={updateDurationToNotEmpty}
          updateBanReasonToNotEmpty={updateBanReasonToNotEmpty}
          updateSecondaryPartnerApproverToNotEmpty={updateSecondaryPartnerApproverToNotEmpty}
          updateSecondaryPartnerApproverEmpty={updateSecondaryPartnerApproverEmpty}
          updateBanCommentsMoreThan100Chars={updateBanCommentsMoreThan100Chars}
          updateBanCommentWithNonOtherReason={updateBanCommentWithNonOtherReason}
          updateBanCommentWithOtherReason={updateEmptyBanCommentWithOtherReason}
          closeConfirmationModal={closeAddBanModal}
          callAddNewBanAPIwithPayload={callAddNewBanAPIwithPayload}
        />
      ) : isUpdateBanMode && banInUpdateMode !== null ? (
        <UpdateBan
          testTakerInfo={bookingHistoryDetail.bookingHistory[0].bookingDetails.testTakerInfo}
          testTakerUuid={bookingHistoryDetail.uniqueTestTakerId}
          existingBanDetails={bookingHistoryDetail.testtakerBanInfo[banInUpdateMode]}
          onUpdateBanClickHandler={onUpdateBanClickHandler}
          onCancelUpdateActionHandler={onCancelUpdateActionHandler}
          errorMessage={updateBanMandatoryFieldError}
          onRemoveErrorMessage={removeUpdateErrorMessage}
          isStartDateEmpty={isStartDateEmpty}
          isDurationEmpty={isDurationEmpty}
          isReasonEmpty={isReasonEmpty}
          isPartnerSecondaryApproverEmpty={isPartnerSecondaryApproverEmpty}
          isBanCommentsMoreThan100Chars={isBanCommentsMoreThan100Chars}
          isBanCommentWithNonOtherReason={isBanCommentWithNonOtherReason}
          isEmptyBanCommentWithOtherReason={isEmptyBanCommentWithOtherReason}
          isUpdateBanModalOpen={isUpdateBanModalOpen}
          reasonOptions={banReasonListFrom()}
          updateStartDateToNotEmpty={updateStartDateToNotEmpty}
          updateDurationToNotEmpty={updateDurationToNotEmpty}
          updateBanReasonToNotEmpty={updateBanReasonToNotEmpty}
          updateSecondaryPartnerApproverToNotEmpty={updateSecondaryPartnerApproverToNotEmpty}
          updateSecondaryPartnerApproverEmpty={updateSecondaryPartnerApproverEmpty}
          updateBanCommentsMoreThan100Chars={updateBanCommentsMoreThan100Chars}
          updateBanCommentWithNonOtherReason={updateBanCommentWithNonOtherReason}
          updateBanCommentWithOtherReason={updateEmptyBanCommentWithOtherReason}
          closeConfirmationModal={closeUpdateBanModal}
          callUpdateBanAPIwithPayload={callUpdateBanAPIwithPayload}
        />
      ) : (
        renderTabContent()
      )}
    </React.Fragment>
  );

  function isAllFieldsEnteredCorrectly(newBan: BanDetails) {
    const otherReasonAndEmptyComments = newBan.reasonUuid === getOtherReason() && isNullOrEmpty(newBan.banComments);

    const nonOtherReasonAndNonEmptyComments =
      newBan.reasonUuid !== getOtherReason() && !isNullOrEmpty(newBan.banComments);
    return (
      !isNullOrEmpty(newBan.effectiveFromDate) &&
      !isNullOrEmpty(newBan.duration) &&
      !isNullOrEmpty(newBan.reasonUuid) &&
      !otherReasonAndEmptyComments &&
      !nonOtherReasonAndNonEmptyComments &&
      !isNullOrEmpty(newBan.partnerSecondaryApprover) &&
      (isNullOrEmpty(newBan.banComments) || newBan.banComments.length <= 99)
    );
  }
};

function isTestTakerBannedToday(history: TestTakerBookingHistoryResponse): boolean {
  let isBannedToday = false;

  const bannedPeriods = history.testtakerBanInfo;

  if (bannedPeriods !== null && bannedPeriods?.length !== 0) {
    for (let i = 0; i < bannedPeriods?.length; ++i) {
      if (bannedPeriods[i].status === 'ACTIVE') {
        isBannedToday = true;
      }

      if (isBannedToday === true) {
        break;
      }
    }
  }
  return isBannedToday;
}

function isNullOrEmpty(field: string) {
  return field === null || field === '';
}

function banReasonListFrom() {
  const response = getAllBanReasons();
  const reasons = [];
  for (let i = 0; i < response.length; i++) {
    const reasonUuid = response[i].ban_reason_uuid;
    const banDescription = response[i].ban_description;
    reasons.push({ value: reasonUuid, text: banDescription });
  }
  return reasons;
}

export default withServiceRequest(TestTakerBookingHistoryPage);
