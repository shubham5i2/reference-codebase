import React from 'react';
import { Switch } from 'react-router';

import PrivateRoute from '../../../routes/PrivateRoute';
import ProductsSearch from './ProductsSearch/ProductsSearch';

const productsManagementPage = (props: any) => {
  const currentUrl = props.match.url;

  return (
    <Switch>
      <PrivateRoute path={currentUrl} component={ProductsSearch} />
    </Switch>
  );
};

export default productsManagementPage;
