import { ProductsResponse } from '../../../services/Models/Result';
import { ProductType } from './ProductsSearch/ProductsSearch';

const PRODUCTS_ORDER = [
  'IELTS ${productName} AC',
  'IELTS ${productName} GT',
  'IELTS OSR ${productName} AC',
  'IELTS OSR ${productName} GT',
  'IELTS SELT ${productName} AC',
  'IELTS SELT ${productName} GT',
  'IELTS OSR SELT ${productName} AC',
  'IELTS OSR SELT ${productName} GT',
];

export const orderProducts = (products: ProductsResponse[] = [], productType: ProductType) => {
  const orderedProducts: ProductsResponse[] = [];
  const filteredProducts = products
    .filter((prod: ProductsResponse) => prod.bookable)
    ?.filter((prod: ProductsResponse) => prod.productName.includes(productType));
  // Ordering Products
  PRODUCTS_ORDER.forEach((product) => {
    const idx = filteredProducts.findIndex(
      (onlineProduct: ProductsResponse) => onlineProduct.productName === product.replace('${productName}', productType),
    );
    if (idx !== -1) {
      orderedProducts.push(filteredProducts[idx]);
      filteredProducts.splice(idx, 1);
    }
  });
  return orderedProducts.concat(filteredProducts);
};
