import React, { useState } from 'react';
import UI from 'ielts-cmds-ui-component-library';

import styles from './ProductsSearch.module.scss';
import ProductsManagementGrid from '../../../Organisms/ProductsManagementGrid/ProductsManagementGrid';
import { languageService } from '../../../../services/Language/LanguageService';

const tabs: { text: string; value: ProductType }[] = [
  { text: 'IOL PRODUCTS', value: 'Online' },
  { text: 'IOC PRODUCTS', value: 'on Computer' },
];

export type ProductType = 'Online' | 'on Computer';

const ProductsSearch = () => {
  const commonLabels = languageService().common;

  const [selectedTab, setSelectedTab] = useState(tabs[0]);

  const onTabChange = (e: React.MouseEvent<HTMLElement>) => {
    const tabElement = e.target as HTMLElement;
    const currentTab = tabs.find((tab) => tab.text === tabElement.innerText) || tabs[0];
    setSelectedTab(currentTab);
  };

  return (
    <div>
      <div className={styles.searchPanel}>
        <UI.Typography label={commonLabels.productsMangement} id="title" type="regular" size={32} />
        <UI.Tabs
          initialActiveTab={selectedTab.text}
          tabBtnStyle={styles.tabBtn}
          buttonStyle={styles.btn}
          activeBtnStyle={styles.btnActive}
          changeTabHandler={onTabChange}
        >
          {tabs.map((tab) => (
            <UI.Tab label={tab.text} isClickable={true} key={tab} />
          ))}
        </UI.Tabs>
      </div>
      <div id="TabContent" className={styles.searchResult}>
        <ProductsManagementGrid type={selectedTab.value} />
      </div>
    </div>
  );
};

export default ProductsSearch;
