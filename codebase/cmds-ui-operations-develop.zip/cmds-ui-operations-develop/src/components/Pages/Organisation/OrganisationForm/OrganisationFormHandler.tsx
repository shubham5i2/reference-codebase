import React, { useState, useEffect, useContext } from 'react';
import { useStateValue } from '../../../../Store/helpers/UseStateValue';
import UI from 'ielts-cmds-ui-component-library';
import OrganisationDetail from '../../../Templates/Organisation/OrganisationDetails';
import { FormValidation } from '../../../utils/FormValidation';
import organisationAddFormRules, {
  adminContactDetailsValidator,
  OrganisationFormRule,
} from '../../../utils/ValidationRules/OrganisationAddForm';
import { useHistory, useParams, useLocation } from 'react-router-dom';
import { FormStepRule, Dictionary, FormRule, RouteParams } from '../../../../services/Models/UIModels';
import {
  OrganisationFromInputChangeEvent,
  OrganisationFormType,
  MinimumScoreData,
  OrganisationProfileData,
  ContactDetailsData,
  OrganisationFormAction,
} from '../../../../services/Models/Organisation';
import withServiceRequest, { ServiceRequest, ConnectorInterface } from '../../../../services/utils/ServiceRequest';
import { addUpdateOrganisation } from '../../../../services/API/Organisation/AddUpdateOrganisation';
import { formatLanguageString } from '../../../../services/Language/LanguageService';
import OrganisationLabels from '../../../../services/Language/en/en.organisation';
import * as OrganisationActions from '../../../../Store/Actions/OrganisationActions';
import { organisationDataInitialState } from '../../../../Store/reducers/OrganisationData';
import * as BreadCrumbActions from '../../../../Store/Actions/BreadCrumbActions';
import { getOrganisation } from '../../../../services/API/Organisation/OrganisationDetails';
import * as OrganisationDataActions from '../../../../Store/Actions/OrganisationDataActions';

interface OrganisationFormHandlerProps {
  serviceRequest: ServiceRequest;
}

const OrganisationFormHandler = (props: OrganisationFormHandlerProps) => {
  const history = useHistory();
  const { id } = useParams<RouteParams>();
  const location = useLocation();

  const { state, dispatch } = useStateValue();
  const [organisationDetails, setOrganisationData] = useState<OrganisationProfileData>(
    organisationDataInitialState.organisationDetail,
  );
  const [contactDetails, setcontactDetails] = useState<ContactDetailsData>(organisationDataInitialState.contactDetail);
  const [minimumScore, setMinimumScore] = useState<MinimumScoreData>(organisationDataInitialState.minimumScore);
  const [error, setErrorState] = useState<Dictionary>({});
  const [showError, setShowErrorMessage] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [orgFormActionType, setOrgFormActionType] = useState(OrganisationFormAction.ADD);
  const [isForceReload, setForceReload] = useState(false);
  const connectorContext = useContext<ConnectorInterface>(UI.ConnectorContext);

  useEffect(() => {
    dispatch({ type: BreadCrumbActions.SHOW_BACK });
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (location.pathname?.toLowerCase().includes('update')) {
      setOrgFormActionType(OrganisationFormAction.UPDATE);
    } else {
      setOrgFormActionType(OrganisationFormAction.ADD);
    }
  }, [location.pathname]);

  useEffect(() => {
    isForceReload && getOrganisationData();
    setForceReload(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isForceReload]);

  useEffect(() => {
    const { currentRoID, organisationDetail, contactDetail, minimumScore } = state.organisationData;
    if (currentRoID === id) {
      setOrganisationData(organisationDetail);
      setcontactDetails(contactDetail);
      setMinimumScore(minimumScore);
    } else if (id) {
      getOrganisationData();
    }
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, state.organisationData, connectorContext.connectionId]);

  const getOrganisationData = () => {
    getOrganisation(id, props.serviceRequest).subscribe((orgData) => {
      if (orgData) {
        dispatch({ type: OrganisationDataActions.ORGANISATION_DATA_SUCCESS, payload: orgData });
      }
    });
  };

  // : This needs to be refactored, need to pass this data as part of organisationData state.
  useEffect(() => {
    if (state.ManageOrganisation?.duplicateSearchData?.body?.criteria && !id) {
      const { criteria } = state.ManageOrganisation?.duplicateSearchData?.body;
      criteria.organisationName &&
        setOrganisationData((prevOrgData) => ({
          ...prevOrgData,
          organisationName: criteria.organisationName,
        }));
      criteria.city &&
        setOrganisationData((prevOrgData) => ({
          ...prevOrgData,
          mainAddress: {
            ...prevOrgData.mainAddress,
            city: criteria.city,
          },
        }));
      criteria.postalCode &&
        setOrganisationData((prevOrgData) => ({
          ...prevOrgData,
          mainAddress: {
            ...prevOrgData.mainAddress,
            postalCode: criteria.postalCode,
          },
        }));
    }
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.ManageOrganisation?.duplicateSearchData]);

  const formState: Dictionary = {
    [OrganisationFormType.PROFILE_FORM]: organisationDetails,
    [OrganisationFormType.CONTACT_DETAILS_FORM]: contactDetails,
    [OrganisationFormType.MINIMUM_SCORE_FORM]: minimumScore,
  };

  const handleInputChange = (e: OrganisationFromInputChangeEvent) => {
    //Updated code for onchange event handler in organisationprofile
    const value = e.target.value;

    const getFieldState = formState[e.formtype];

    const name = e.target.name || '';

    let updatedState = { ...getFieldState };

    if (e.target.addressName) {
      updatedState = {
        [e.target.addressName]: {
          ...getFieldState[e.target.addressName],

          [name]: value,
        },
      };

      const updatedError = {
        ...error,

        [e.target.addressName]: {
          ...error[e.target.addressName],

          [e.target.name]: { isValid: true },
        },
      };

      setErrorState(updatedError);
    } else {
      updatedState = { [name]: value };
      setErrorState({ ...error, [e.target.name]: { isValid: true } });
    }
    setOrganisationFromState(e.formtype, { [e.formtype]: updatedState });
  };

  const setOrganisationFromState = (fromType: OrganisationFormType, updatedState: Dictionary) => {
    switch (fromType) {
      case OrganisationFormType.PROFILE_FORM:
        setOrganisationData((prevState) => ({ ...prevState, ...updatedState[fromType] }));
        break;

      case OrganisationFormType.CONTACT_DETAILS_FORM:
        setcontactDetails((prevState) => ({ ...prevState, ...updatedState[fromType] }));
        break;

      case OrganisationFormType.MINIMUM_SCORE_FORM:
        setMinimumScore((prevState) => ({ ...prevState, ...updatedState[fromType] }));
        break;

      default:
        return;
    }
  };

  const errorHandler = () => {
    const orgFromRules = organisationAddFormRules(
      organisationDetails.organisationType.value,
      adminContactDetailsValidator({
        organisationDetails,
        contactDetails,
      }),
    );
    const orgProfileError = getOrganisationError(organisationDetails, orgFromRules.organisationProfile);
    const { isFormvalid, orgData } = getOrganisationError(
      contactDetails,
      orgFromRules.contactDetails,
      orgProfileError.isFormvalid,
      orgProfileError.orgData,
    );
    return [isFormvalid, orgData];
  };

  const getOrganisationError = (state: Dictionary, rule: OrganisationFormRule, isValid = true, orgData: any = {}) => {
    let isFormvalid = isValid;
    Object.keys(rule).forEach((key) => {
      if (rule[key].required === undefined) {
        const profileElement = rule[key] as FormStepRule;
        state[key]?.isRequired &&
          Object.keys(profileElement).forEach((elementKey) => {
            orgData[key] = orgData[key] || {};
            orgData[key][elementKey] = FormValidation(
              (state[key] && state[key][elementKey]) || '',
              profileElement[elementKey],
            );
            if (!orgData[key][elementKey].isValid) isFormvalid = false;
          });
      } else {
        const orgFormRule = rule[key] as FormRule;
        orgData[key] = FormValidation(state[key] || '', orgFormRule);
        if (!orgData[key].isValid) isFormvalid = false;
      }
    });
    return { isFormvalid, orgData: orgData };
  };

  const handleCancel = () => {
    history.push('/organisation');
  };

  const handleSubmit = () => {
    const [isFormValid, errorObject] = errorHandler();
    setErrorState(errorObject);
    setShowErrorMessage(!isFormValid);

    if (isFormValid) {
      setShowConfirmation(true);
    }
  };

  const handleAddOrgConfirmation = () => {
    const organisationData = {
      organisationProfile: organisationDetails,
      contactDetails: contactDetails,
      minimumScore: minimumScore,
    };
    addUpdateOrganisation(organisationData, props.serviceRequest, id).subscribe((response) => {
      if (response?.organisation?.organisationId) {
        const { organisation } = response;
        const userKeys = { orgName: organisation.organisationName, orgId: organisation.organisationId };
        const addUpdateLabel =
          orgFormActionType === OrganisationFormAction.UPDATE
            ? OrganisationLabels.orgUpdateToastMessage
            : OrganisationLabels.orgAddedToastMessage;
        const message = formatLanguageString(addUpdateLabel, userKeys);
        history.push('/organisation');
        dispatch({ type: OrganisationActions.ORGANISATION_ADD_UPDATE_MESSAGE, payload: message });
      }
    });
    setShowConfirmation(false);
  };

  const onHandleAddOrgConfirmationCancel = (isFromWarningDialog: boolean) => {
    setShowConfirmation(false);
    if (isFromWarningDialog) {
      setForceReload(true);
    }
  };

  return (
    <>
      <OrganisationDetail
        organisationDetails={organisationDetails}
        contactDetails={contactDetails}
        minimumScore={minimumScore}
        handleInputChange={handleInputChange}
        onSubmit={handleSubmit}
        onCancel={handleCancel}
        error={error}
        showErrorMessage={showError}
        onRemoveErrorMessage={() => setShowErrorMessage(false)}
        showConfirmationDialog={showConfirmation}
        handleAddOrgConfirmationCancel={onHandleAddOrgConfirmationCancel}
        handleAddOrgConfirmation={handleAddOrgConfirmation}
        orgFormAction={orgFormActionType}
        setOrganisationForm={setOrganisationFromState}
      />
    </>
  );
};

export default withServiceRequest(OrganisationFormHandler);
