import React from 'react';
import Search from './OrganisationSearchPanel/OrganisationSearchPanel';
import DuplicateSearch from './OrganisationDuplicateSearchPanel/OrganisationDuplicateSearchPanel';
import Form from './OrganisationForm/OrganisationFormHandler';
import styles from './Organisation.module.scss';
import PrivateRoute from '../../../routes/PrivateRoute';
import { Switch } from 'react-router-dom';
import useFeatureToggle from '../../../services/feature-toggle/UseFeatureToggle';
import ROOT_FEATURE from '../../../services/feature-toggle/feature-types/RootFeature';
import OrganisationDetailsPage from '../../../components/Pages/OrganisationDetailsPage/OrganisationDetailsPage';

const OrganisationRoutes = (props: any) => {
  const currentUrl = props.match.url;
  useFeatureToggle(ROOT_FEATURE.organisation);

  return (
    <div className={styles.container}>
      <Switch>
        <PrivateRoute path={currentUrl + '/organisationDetails/:id'} component={OrganisationDetailsPage} />
        <PrivateRoute path={currentUrl + '/update/:id'} component={Form} />
        <PrivateRoute
          path={currentUrl + '/duplicatesearch/organisationDetails/:id'}
          component={OrganisationDetailsPage}
        />
        <PrivateRoute path={currentUrl + '/duplicatesearch/update/:id'} component={Form} />
        <PrivateRoute path={currentUrl + '/duplicatesearch/addnew'} component={Form} />
        <PrivateRoute path={currentUrl + '/duplicatesearch'} component={DuplicateSearch} />
        <PrivateRoute path={currentUrl} component={Search} />
      </Switch>
    </div>
  );
};

export default OrganisationRoutes;
