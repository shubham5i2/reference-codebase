import React, { useState, useEffect, useRef } from 'react';
import styles from './OrganisationSearchPanel.module.scss';
import SearchPanel from '../../../Templates/OrganisationSearch/OrganisationSearch';
import UI from 'ielts-cmds-ui-component-library';
import { useStateValue } from '../../../../Store/helpers/UseStateValue';
import NoResultsFound from '../../../Molecules/NoResultsFound/NoResultsFound';
import { roSearchResult } from '../../../../services/API/Organisation/RoSearchResult';
import withServiceRequest, { ServiceRequest } from '../../../../services/utils/ServiceRequest';
import { RouteComponentProps } from 'react-router-dom';
import * as organisationSearchType from '../../../../constants/OrganisationSearchType';
import { languageService } from '../../../../services/Language/LanguageService';
import * as BreadCrumbActions from '../../../../Store/Actions/BreadCrumbActions';
import {
  OrganisationStatus,
  VerificationStatus,
  OrganisationReqBodySearchPayload,
  OrganisationInputChangeEvent,
  OrganisationAdvancedSearch,
  OrganisationBasicSearch,
  OrganisationFromData,
} from '../../../../services/Models/Organisation';
import { pageSizeOptions } from '../../../Organisms/ManageUsersGrid/ManageUsersGridConstants';
import ROGrid, { ColumnSort } from '../../../Organisms/ROGrid/ROGrid';
import { useEffectUpdate, transformRequestValueFromString, getCountryISOCode } from '../../../utils/utilities';
import * as OrganisationActions from '../../../../Store/Actions/OrganisationActions';
import PartnerDropDown from '../../../Organisms/BaseDropDown/PartnerDropDown/PartnerDropDown';
import { DEFAULT_TOAST_MESSAGE_TIMER } from '../../../../constants/GlobalConstants';
import ReferenceDropdown from '../../../Organisms/ReferenceDropdown/ReferenceDropdown';
import { getDefaultReferenceDropdownProps } from '../../../Organisms/ReferenceDropdown/ReferenceDropdownPropsHelper';
import { ReferenceDropdownType } from '../../../Organisms/ReferenceDropdown/UseReferenceFetch';
import { DropDownDataSource } from '../../../../services/Models/UIModels';
import TerritoryDropDown from '../../../Organisms/BaseDropDown/TerritoryDropDown/TerritoryDropDown';
import { initialDropDownDataSource } from '../../../Templates/Organisation/OrganisationConstants';

interface OrganisationSearchPanelProps extends RouteComponentProps {
  serviceRequest: ServiceRequest;
}

const OrganisationSearchPanel = (props: OrganisationSearchPanelProps) => {
  const currentUrl = props.match.url;
  const isFromSearchClick = useRef(false);
  const selectedSearchType = useRef('');

  const organisationLabels = languageService().organisation;

  const initialBasicSearchData = { organisationName: '', organisationId: '', contactName: '', fuzzyMatch: false };

  const [basicSearchData, setBasicSearchData] = useState<OrganisationBasicSearch>(initialBasicSearchData);

  const [initialOpenState, setInitialOpenState] = useState(false);

  const { state, dispatch } = useStateValue();

  const [isSearchCriteriaValid, setSearchCriteriaValid] = useState(true);

  const [isSearchResults, setSearchResults] = useState(false);

  const [searchResultsData, setSearchResultsData] = useState([]);

  const [totalSearchResult, setTotalSearchResult] = useState(0);
  const [currentSelectedPage, setCurrentSelectedPage] = useState({ page: 1 });
  const [currentSelectedPageSize, setCurrentSelectedPageSize] = useState(pageSizeOptions[0].value);
  const [selectedSortOption, setSelectedSortOption] = useState({
    sortType: 'ASC',
    sortBy: 'name',
  });
  const [isGridLoading, setIsGridLoading] = useState(false);

  useEffectUpdate(() => {
    if (!isFromSearchClick.current) {
      const { searchName } = state.ManageOrganisation.searchData;
      const name = searchName || organisationSearchType.DEFAULT;
      const reqBody = getSearchRequestBody();
      getOrganisationSearchResults(name, reqBody);
    } else if (isFromSearchClick.current && selectedSearchType.current !== '') {
      const reqBody = getSearchRequestBody();
      getOrganisationSearchResults(selectedSearchType.current, reqBody);
      selectedSearchType.current = '';
    }
  }, [currentSelectedPage]);

  useEffect(() => {
    dispatch({ type: BreadCrumbActions.SHOW_BACK, payload: true });
    const { searchName, body, selectedPage, selectedPageSizeIndex, sortOption } = state.ManageOrganisation.searchData;

    if (searchName !== '' && body) {
      isFromSearchClick.current = true;
      setCurrentSelectedPage(selectedPage);
      setCurrentSelectedPageSize(pageSizeOptions[selectedPageSizeIndex].value);
      setSelectedSortOption(sortOption);
      updateUI(searchName, body);
      getOrganisationSearchResults(searchName, body, false);
    }
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const initialAdvancedSearchData = {
    city: '',
    postalCode: '',
    contactEmail: '',
    partnerCode: '',
    organisationStatus: '',
    verificationStatus: '',
    organisationTypeUuid: '',
    country: '',
    territory: '',
    territoryName: '',
  };

  const [advancedSearchData, setAdvancedSearchData] = useState<OrganisationAdvancedSearch>(initialAdvancedSearchData);
  const handleBasicInputChange = (e: OrganisationInputChangeEvent) => {
    const value = e.target.value;
    setBasicSearchData({ ...basicSearchData, [e.target.name]: value });
  };

  const onClearBasicSearch = (event: React.FormEvent<HTMLInputElement>) => {
    event.preventDefault();
    setBasicSearchData(initialBasicSearchData);
  };

  const basicSearchDataValidationCheck = (basicSearchDataArg: OrganisationBasicSearch) => {
    const { organisationName, organisationId, contactName } = basicSearchDataArg;
    return organisationName?.trim() === '' && organisationId === '' && contactName?.trim() === '';
  };

  const advanceSearchDataValidationCheck = (advanceSearchDataArg: OrganisationAdvancedSearch) => {
    const {
      city,
      postalCode,
      contactEmail,
      partnerCode,
      organisationStatus,
      verificationStatus,
      organisationTypeUuid,
      country,
    } = advanceSearchDataArg;
    return (
      city?.trim() === '' &&
      postalCode?.trim() === '' &&
      contactEmail?.trim() === '' &&
      partnerCode?.trim() === '' &&
      organisationStatus?.trim() === '' &&
      verificationStatus?.trim() === '' &&
      organisationTypeUuid?.trim() === '' &&
      country?.trim() === ''
    );
  };

  const onBasicSearchHandler = () => {
    const isSearchDataEmpty = basicSearchDataValidationCheck(basicSearchData);
    if (isSearchDataEmpty) {
      setSearchCriteriaValid(false);
      setSearchResults(false);
      return;
    }
    isFromSearchClick.current = true;
    selectedSearchType.current = organisationSearchType.BASIC;
    setCurrentSelectedPage(() => {
      return { page: 1 };
    });
    setSearchCriteriaValid(true);
    setSearchResults(true);
  };

  const organisationStatusOptions = [
    { value: OrganisationStatus.ACTIVE, text: organisationLabels.active },
    { value: OrganisationStatus.INACTIVE, text: organisationLabels.inActive },
  ];

  const verificationStatusOptions = [
    { value: VerificationStatus.APPROVED, text: organisationLabels.approved },
    { value: VerificationStatus.PENDING, text: organisationLabels.pending },
    { value: VerificationStatus.REJECTED, text: organisationLabels.rejected },
    { value: VerificationStatus.VERIFIED, text: organisationLabels.verified },
  ];

  const handleAdvancedInputChange = (e: OrganisationInputChangeEvent) => {
    const value = e.target.value;
    setAdvancedSearchData({ ...advancedSearchData, [e.target.name]: value });
  };

  const onTerritoryChange = (e: OrganisationFromData) => {
    setAdvancedSearchData((previousState) => {
      return { ...previousState, [e.name]: e.value };
    });
  };

  //country dropdown onChange
  const handleCountryChange = (e: { name: string; value: string; text: string }) => {
    setAdvancedSearchData({ ...advancedSearchData, [e.name]: e.value });
  };

  const onClearAdvancedSearch = (event: React.FormEvent<HTMLInputElement>) => {
    event.preventDefault();
    setBasicSearchData(initialBasicSearchData);
    setAdvancedSearchData(initialAdvancedSearchData);
  };

  const onAdvancedSearchHandler = () => {
    const isAdvancedSearchDataEmpty = advanceSearchDataValidationCheck(advancedSearchData);
    const isBasicSearchDataEmpty = basicSearchDataValidationCheck(basicSearchData);
    if (isAdvancedSearchDataEmpty && isBasicSearchDataEmpty) {
      setSearchCriteriaValid(false);
      setSearchResults(false);
      return;
    }
    isFromSearchClick.current = true;
    selectedSearchType.current = organisationSearchType.ADVANCE;
    setCurrentSelectedPage(() => {
      return { page: 1 };
    });
    setSearchCriteriaValid(true);
  };

  const getSortingElement = (sortBy: string, sortType: string) => ({ sortBy, sortType });

  const getSearchRequestBody = () => {
    const sorting = Array.isArray(selectedSortOption.sortBy)
      ? selectedSortOption.sortBy.map((sortBy) => getSortingElement(sortBy, selectedSortOption.sortType))
      : [getSortingElement(selectedSortOption.sortBy, selectedSortOption.sortType)];

    const reqBody = {
      criteria: {
        organisationName: transformRequestValueFromString(basicSearchData.organisationName),
        organisationId: basicSearchData.organisationId ? Number(basicSearchData.organisationId) : undefined,
        contactName: transformRequestValueFromString(basicSearchData.contactName),
        city: transformRequestValueFromString(advancedSearchData.city),
        postalCode: transformRequestValueFromString(advancedSearchData.postalCode),
        contactEmail: transformRequestValueFromString(advancedSearchData.contactEmail),
        partnerCode: transformRequestValueFromString(advancedSearchData.partnerCode),
        organisationStatus: transformRequestValueFromString(advancedSearchData.organisationStatus),
        verificationStatus: transformRequestValueFromString(advancedSearchData.verificationStatus),
        organisationTypeUuid: transformRequestValueFromString(advancedSearchData.organisationTypeUuid),
        country: transformRequestValueFromString(advancedSearchData.country),
        territory: transformRequestValueFromString(advancedSearchData.territory),
        fuzzyMatch: basicSearchData.fuzzyMatch,
      },
      pagination: {
        pageNumber: currentSelectedPage.page - 1,
        pageSize: currentSelectedPageSize,
      },
      sorting,
    };
    return reqBody;
  };

  const getOrganisationSearchResults = (
    name: string,
    body: OrganisationReqBodySearchPayload,
    shouldUpdateState = true,
  ) => {
    const searchMode = 'generic';
    const selectedPageSizeIndex = pageSizeOptions.findIndex((option) => option.value === currentSelectedPageSize);

    if (shouldUpdateState) {
      dispatch({
        type: OrganisationActions.ORGANISATION_SEARCH,
        payload: {
          body,
          searchName: name,
          selectedPage: currentSelectedPage,
          selectedPageSizeIndex,
          sortOption: selectedSortOption,
        },
      });
    }
    setIsGridLoading(true);
    roSearchResult(searchMode, body, props.serviceRequest).subscribe((data) => {
      if (!data) return;
      const gridData = data.gridData || [];
      const totalRecords = data.totalCount || 0;
      dispatch({ type: OrganisationActions.SEARCH_SUCCESS, payload: { totalCount: totalRecords } });
      setTotalSearchResult(totalRecords);
      setSearchResultsData(gridData);
      setSearchResults(totalRecords > 0);
      setIsGridLoading(false);
    });
  };

  const updateUI = (searchName: string, body: OrganisationReqBodySearchPayload) => {
    const { criteria } = body;
    setBasicSearchData({
      organisationName: criteria.organisationName,
      organisationId: criteria.organisationId,
      contactName: criteria.contactName,
      fuzzyMatch: criteria.fuzzyMatch,
    });
    if (searchName === organisationSearchType.ADVANCE) {
      setAdvancedSearchData({
        city: criteria.city,
        postalCode: criteria.postalCode,
        contactEmail: criteria.contactEmail,
        partnerCode: criteria.partnerCode,
        organisationStatus: criteria.organisationStatus,
        verificationStatus: criteria.verificationStatus,
        organisationTypeUuid: criteria.organisationTypeUuid,
        country: criteria.country,
        territory: criteria.territory,
      });
      setInitialOpenState(true);
    }
  };

  const onAddUserHandler = () => {
    dispatch({ type: OrganisationActions.CLEAR_ORGANISATION_DUPLICATE_SEARCH });
    props.history.push(currentUrl + '/duplicatesearch');
  };

  const onPageChangeHandler = (page: number) => {
    isFromSearchClick.current = false;
    setCurrentSelectedPage(() => {
      return { page: page + 1 };
    });
  };

  const onPageSizeChangeHandler = (value: number) => {
    setCurrentSelectedPageSize(() => value);
    isFromSearchClick.current = false;
    setCurrentSelectedPage(() => {
      return { page: 1 };
    });
  };

  const onColumnSortHandler = (column: ColumnSort) => {
    let sortType;
    if (JSON.stringify(selectedSortOption.sortBy) === JSON.stringify(column.Header.name)) {
      sortType = selectedSortOption.sortType === 'ASC' ? 'DESC' : 'ASC';
    } else {
      sortType = 'ASC';
    }
    const sortOption = {
      sortBy: column.Header.name,
      sortType,
    };
    setSelectedSortOption(() => sortOption);
    isFromSearchClick.current = false;
    setCurrentSelectedPage(() => {
      return { page: 1 };
    });
  };

  const getROGrid = () => {
    const gridState = {
      totalRecords: totalSearchResult,
      initialState: {
        pageSize: currentSelectedPageSize,
      },
      selectedPage: currentSelectedPage.page,
      selectedOptionValue: currentSelectedPageSize,
    };
    return (
      <div className={styles.searchResults}>
        <ROGrid
          data={searchResultsData || []}
          onPageChange={onPageChangeHandler}
          onPageSizeChange={onPageSizeChangeHandler}
          gridState={gridState}
          pageSizeOptions={pageSizeOptions}
          onColumnSort={onColumnSortHandler}
          sortOption={selectedSortOption}
          sort={true}
          isLoading={isGridLoading}
        />
      </div>
    );
  };

  const getOrgSuccessMessage = () => {
    return state.ManageOrganisation.organisationCreatedMessage ? (
      <div className={styles.messageContainer}>
        <UI.Message
          message={state.ManageOrganisation.organisationCreatedMessage}
          color="success"
          dismissable
          onChange={() => dispatch({ type: 'CLEAR_ORGANISATION_TOAST_MESSAGE' })}
          visibleTill={DEFAULT_TOAST_MESSAGE_TIMER}
        />
      </div>
    ) : null;
  };

  return (
    <React.Fragment>
      {!isSearchCriteriaValid ? (
        <div className={styles.messageContainer}>
          <UI.Message
            message={organisationLabels.searchCriteriaError}
            color="error"
            dismissable
            onChange={() => setSearchCriteriaValid(true)}
          />
        </div>
      ) : null}
      {getOrgSuccessMessage()}
      <SearchPanel
        title={organisationLabels.organisationTitle}
        titleType="regular"
        titleSize={32}
        addButtonLabel={organisationLabels.addButtonLabel}
        addButtonColor="blueLine"
        addButtonIcon="plus"
        subTitle={organisationLabels.subTitle}
        subTitleType="regular"
        subTitleSize={16}
        basicSearchData={basicSearchData}
        clearBasicSearch={!basicSearchDataValidationCheck(basicSearchData) ? organisationLabels.clearSearch : ''}
        basicSearchButtonLabel={organisationLabels.searchLabel}
        basicSearchButtonColor="primary"
        onClearBasicSearch={onClearBasicSearch}
        handleBasicInputChange={handleBasicInputChange}
        onBasicSearchHandler={onBasicSearchHandler}
        clearAdvancedSearch={
          !advanceSearchDataValidationCheck(advancedSearchData) ? organisationLabels.clearSearch : ''
        }
        advanceSearchButtonLabel={organisationLabels.searchLabel}
        advanceSearchButtonColor="primary"
        onClearAdvancedSearch={onClearAdvancedSearch}
        handleAdvancedInputChange={handleAdvancedInputChange}
        onAdvancedSearchHandler={onAdvancedSearchHandler}
        onAddUserHandler={onAddUserHandler}
        collapseTitle={organisationLabels.collapseTitle}
        collapseOpenTitle={organisationLabels.collapseTitle}
        collapseFooterTitle={organisationLabels.collapseFooterTitle}
        initialOpenState={initialOpenState}
      >
        <div className={styles.col3}>
          <UI.TextBox
            label={organisationLabels.city}
            name="city"
            placeholder=""
            value={advancedSearchData.city}
            onChange={handleAdvancedInputChange}
          />

          <UI.TextBox
            label={organisationLabels.postCode}
            name="postalCode"
            placeholder=""
            value={advancedSearchData.postalCode}
            onChange={handleAdvancedInputChange}
          />

          <UI.TextBox
            label={organisationLabels.contactEmail}
            name="contactEmail"
            placeholder=""
            value={advancedSearchData.contactEmail}
            onChange={handleAdvancedInputChange}
          />

          <PartnerDropDown
            id="partnerLead"
            labelId={'partnerLeadLB'}
            label={organisationLabels.partnerLead}
            selectedPartner={advancedSearchData.partnerCode}
            textBoxPlaceHolder={organisationLabels.partnerLeadPlaceholder}
            serviceRequest={props.serviceRequest}
            canUseStoreData
            isFilterEnabled={false}
            onPartnerChange={(e: string) => {
              const event = {
                target: {
                  name: 'partnerCode',
                  value: e,
                },
              };
              return handleAdvancedInputChange(event);
            }}
          />

          <UI.Dropdown
            id="organisationStatus"
            label={organisationLabels.organisationStatus}
            selectedValue={advancedSearchData.organisationStatus}
            placeholder={organisationLabels.organisationStatusPlaceholder}
            onChange={(e: string) => {
              const event = {
                target: {
                  name: 'organisationStatus',
                  value: e,
                },
              };
              return handleAdvancedInputChange(event);
            }}
            list={organisationStatusOptions}
          />

          <UI.Dropdown
            id="verificationStatus"
            label={organisationLabels.verificationStatus}
            selectedValue={advancedSearchData.verificationStatus}
            placeholder={organisationLabels.verificationStatusPlaceholder}
            onChange={(e: string) => {
              const event = {
                target: {
                  name: 'verificationStatus',
                  value: e,
                },
              };
              return handleAdvancedInputChange(event);
            }}
            list={verificationStatusOptions}
          />

          <ReferenceDropdown
            {...getDefaultReferenceDropdownProps({
              dropdownType: ReferenceDropdownType.ORGANISATION_TYPE,
              value: advancedSearchData.organisationTypeUuid,
              onChange: ({ value }: DropDownDataSource) => {
                const event = {
                  target: {
                    name: 'organisationTypeUuid',
                    value: value,
                  },
                };
                return handleAdvancedInputChange(event);
              },
            })}
          />

          <ReferenceDropdown
            {...getDefaultReferenceDropdownProps({
              dropdownType: ReferenceDropdownType.COUNTRY,
              value: advancedSearchData.country,
              onChange: ({ value, text }: DropDownDataSource) => {
                handleCountryChange({
                  name: 'country',
                  value: value,
                  text: text,
                });
              },
            })}
          />
          <TerritoryDropDown
            id={'territory'}
            label={organisationLabels.territoryLabel}
            isMandatory={false}
            labelId={'TerriroryLB'}
            textBoxPlaceHolder={organisationLabels.pleaseSelectPlaceHolder}
            selectedTerritory={
              { value: advancedSearchData.territory || '', text: advancedSearchData.territoryName || '' } ||
              initialDropDownDataSource
            }
            serviceRequest={props.serviceRequest}
            isFilterEnabled={true}
            canUseStoreData
            countryCode={getCountryISOCode(state, advancedSearchData.country)}
            onTerritoryChange={(value: string, text: string) => {
              onTerritoryChange({
                name: 'territory',
                value: value,
              });
              onTerritoryChange({
                name: 'territoryName',
                value: text,
              });
            }}
          />
        </div>
      </SearchPanel>
      {isSearchResults || isGridLoading ? (
        getROGrid()
      ) : (
        <NoResultsFound
          title={organisationLabels.noResultsFoundTitle}
          description={organisationLabels.noResultsFoundDesp}
        />
      )}
    </React.Fragment>
  );
};

export default withServiceRequest(OrganisationSearchPanel);
