import React from 'react';
import OrganisationGrid from '../../../Templates/OrganisationSearch/OrganisationSearchResults/OrganisationSearchResults';

const OrganisationSearchResults = () => {
  const myProps = {
    data: [
      {
        roName: 'Architectural Association school of Architecture',
        roId: '13455',
        address: '36, Bedford Square, London',
        country: 'United Kingdom',
        activeStatus: 'Active',
        verificationStatus: 'Verified',
        city: 'London',
        postCode: 'WC1B 3ES',
        organisationType: 'Recognising Organisation',
      },
      {
        roName: 'Architectural Association school of Architecture',
        roId: '13456',
        address: '55, Bedford Square, London',
        country: 'United Kingdom',
        activeStatus: 'Active',
        verificationStatus: 'Rejected',
        city: 'London',
        postCode: 'WC1B 3ES',
        organisationType: 'Verified Organisation',
      },
      {
        roName: 'Architectural Association school of Architecture',
        roId: '13457',
        address: '22, Bedford Square, London',
        country: 'United Kingdom',
        activeStatus: 'Active',
        verificationStatus: 'Rejected',
        city: 'London',
        postCode: 'WC1B 3ES',
        organisationType: 'Recognising Organisation',
      },
      {
        roName: 'School of Architecture',
        roId: '13458',
        address: '22, Bedford Square, London',
        country: 'United Kingdom',
        activeStatus: 'Active',
        verificationStatus: 'Rejected',
        city: 'London',
        postCode: 'WC1B 3ES',
        organisationType: 'Recognising Organisation',
      },
    ],
    onPageChange: jest.fn(),
    onPageSizeChange: jest.fn(),
    gridState: {
      totalRecords: 1,
      initialState: {
        pageIndex: 0,
        pageSize: 2,
      },
      selectedPage: 1,
      selectedOptionValue: 20,
    },
    pageSizeOptions: [
      { text: '1-10', value: 10 },
      { text: '1-20', value: 20 },
      { text: '1-50', value: 50 },
    ],
    onColumnSort: jest.fn(),
    sortOption: {
      sortBy: 'name',
      sortType: 'DESC',
    },
  };

  return <OrganisationGrid {...myProps} />;
};

export default OrganisationSearchResults;
