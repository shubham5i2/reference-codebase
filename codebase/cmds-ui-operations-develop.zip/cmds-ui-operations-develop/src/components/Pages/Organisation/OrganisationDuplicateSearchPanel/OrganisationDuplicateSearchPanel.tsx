import React, { useState, useEffect, useRef } from 'react';
import styles from './OrganisationDuplicateSearchPanel.module.scss';
import SearchPanel from '../../../Templates/OrganisationDuplicateSearch/OrganisationDuplicateSearch';
import UI from 'ielts-cmds-ui-component-library';
import { useStateValue } from '../../../../Store/helpers/UseStateValue';
import NoResultsFound from '../../../Molecules/NoResultsFound/NoResultsFound';
import { roSearchResult } from '../../../../services/API/Organisation/RoSearchResult';
import withServiceRequest, { ServiceRequest } from '../../../../services/utils/ServiceRequest';
import { RouteComponentProps } from 'react-router-dom';
import * as organisationSearchType from '../../../../constants/OrganisationSearchType';
import { languageService } from '../../../../services/Language/LanguageService';
import * as BreadCrumbActions from '../../../../Store/Actions/BreadCrumbActions';
import {
  OrganisationDuplicateSearchPayload,
  OrganisationInputChangeEvent,
  OrganisationReqBodyDuplicateSearchPayload,
} from '../../../../services/Models/Organisation';
import { pageSizeOptions } from '../../../Organisms/ManageUsersGrid/ManageUsersGridConstants';
import ROGrid from '../../../Organisms/ROGrid/ROGrid';
import { useEffectUpdate, transformRequestValueFromString } from '../../../utils/utilities';
import * as OrganisationActions from '../../../../Store/Actions/OrganisationActions';

interface OrganisationDuplicateSearchPanelProps extends RouteComponentProps {
  serviceRequest: ServiceRequest;
}

interface DuplicateSearchDataType {
  organisationName?: string;
  city?: string;
  postCode?: string;
}

const OrganisationDuplicateSearchPanel = (props: OrganisationDuplicateSearchPanelProps) => {
  const currentUrl = props.match.url;
  const isFromSearchClick = useRef(false);
  const selectedSearchType = useRef('');

  const organisationLabels = languageService().organisation;

  const initialDuplicateSearchData = { organisationName: '', city: '', postCode: '', fuzzyMatch: false };

  const [duplicateSearchData, setDuplicateSearchData] = useState(initialDuplicateSearchData);

  const { state, dispatch } = useStateValue();

  const [isSearchCriteriaValid, setSearchCriteriaValid] = useState(true);

  const currentPathName = props.location.pathname;
  const routerCheck = new RegExp('/(organisation)/(.+?)*', 'gm');

  const [isSearchResults, setSearchResults] = useState(false);

  const [searchResultsData, setSearchResultsData] = useState([]);

  const [totalSearchResult, setTotalSearchResult] = useState(-1);
  const [currentSelectedPage, setCurrentSelectedPage] = useState({ page: 1 });
  const [currentSelectedPageSize, setCurrentSelectedPageSize] = useState(pageSizeOptions[0].value);
  const [isGridLoading, setGridLoading] = useState(false);

  useEffectUpdate(() => {
    if (!isFromSearchClick.current) {
      const { searchName } = state.ManageOrganisation.duplicateSearchData;
      const name = searchName || organisationSearchType.DEFAULT;
      const reqBody = getSearchRequestBody();
      getOrganisationSearchResults(name, reqBody);
    } else if (isFromSearchClick.current && selectedSearchType.current !== '') {
      const reqBody = getSearchRequestBody();
      getOrganisationSearchResults(selectedSearchType.current, reqBody);
      selectedSearchType.current = '';
    }
  }, [currentSelectedPage]);

  useEffect(() => {
    const { searchName, body, selectedPage, selectedPageSizeIndex } = state.ManageOrganisation.duplicateSearchData;
    if (searchName !== '' && body) {
      isFromSearchClick.current = true;
      setCurrentSelectedPage(selectedPage);
      setCurrentSelectedPageSize(pageSizeOptions[selectedPageSizeIndex].value);
      updateUI(searchName, body);
      getOrganisationSearchResults(searchName, body, false);
    }
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (currentPathName === '/organisation') {
      dispatch({ type: BreadCrumbActions.HIDE_BACK });
    } else if (routerCheck.test(currentPathName)) {
      dispatch({ type: BreadCrumbActions.SHOW_BACK });
    }
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentPathName]);

  const handleDuplicateInputChange = (e: OrganisationInputChangeEvent) => {
    const value = e.target.value;
    setDuplicateSearchData({ ...duplicateSearchData, [e.target.name]: value });
  };

  const onClearDuplicateSearch = (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>) => {
    event.preventDefault();
    setDuplicateSearchData(initialDuplicateSearchData);
  };

  const basicDuplicateSearchValidationCheck = (basicDuplicateSearchDataArg: DuplicateSearchDataType) => {
    const { organisationName, city, postCode } = basicDuplicateSearchDataArg;
    return organisationName?.trim() === '' && city?.trim() === '' && postCode?.trim() === '';
  };

  const onDuplicateSearchHandler = () => {
    const isSearchDataEmpty = basicDuplicateSearchValidationCheck(duplicateSearchData);
    if (isSearchDataEmpty) {
      setSearchCriteriaValid(false);
      return;
    }
    isFromSearchClick.current = true;
    selectedSearchType.current = organisationSearchType.DUPLICATE;
    setCurrentSelectedPage(() => {
      return { page: 1 };
    });
    setSearchCriteriaValid(true);
  };

  const getSearchRequestBody = () => {
    const reqBody = {
      criteria: {
        organisationName: transformRequestValueFromString(duplicateSearchData.organisationName),
        city: transformRequestValueFromString(duplicateSearchData.city),
        postalCode: transformRequestValueFromString(duplicateSearchData.postCode),
        fuzzyMatch: duplicateSearchData.fuzzyMatch,
      },
      pagination: {
        pageNumber: currentSelectedPage.page - 1,
        pageSize: currentSelectedPageSize,
      },
    };
    return reqBody;
  };

  const getOrganisationSearchResults = (
    name: string,
    body: OrganisationReqBodyDuplicateSearchPayload,
    shouldUpdateState = true,
  ) => {
    setGridLoading(true);
    const searchMode = 'duplicate';
    const selectedPageSizeIndex = pageSizeOptions.findIndex((option) => option.value === currentSelectedPageSize);
    if (shouldUpdateState) {
      dispatch({
        type: OrganisationActions.ORGANISATION_DUPLICATE_SEARCH,
        payload: {
          body,
          searchName: name,
          selectedPage: currentSelectedPage,
          selectedPageSizeIndex,
        },
      });
    }
    roSearchResult(searchMode, body, props.serviceRequest).subscribe((data) => {
      setGridLoading(false);
      if (!data) return;
      const gridData = data.gridData || [];
      const totalRecords = data.totalCount || 0;
      dispatch({ type: OrganisationActions.DUPLICATE_SEARCH_SUCCESS, payload: { totalCount: totalRecords } });
      setTotalSearchResult(totalRecords);
      setSearchResultsData(gridData);
      setSearchResults(totalRecords > 0);
    });
  };

  const updateUI = (searchName: string, body: OrganisationDuplicateSearchPayload) => {
    const { criteria } = body;
    setDuplicateSearchData({
      organisationName: criteria.organisationName,
      city: criteria.city,
      postCode: criteria.postalCode,
      fuzzyMatch: criteria.fuzzyMatch,
    });
  };

  const handleCancel = () => {
    props.history.push('/organisation');
  };

  const onAddUserHandler = () => {
    props.history.push(currentUrl + '/addnew');
  };

  const onPageChangeHandler = (page: number) => {
    isFromSearchClick.current = false;
    setCurrentSelectedPage(() => {
      return { page: page + 1 };
    });
  };

  const onPageSizeChangeHandler = (value: number) => {
    setCurrentSelectedPageSize(() => value);
    isFromSearchClick.current = false;
    setCurrentSelectedPage(() => {
      return { page: 1 };
    });
  };

  const getROGrid = () => {
    const gridState = {
      totalRecords: totalSearchResult,
      initialState: {
        pageSize: currentSelectedPageSize,
      },
      selectedPage: currentSelectedPage.page,
      selectedOptionValue: currentSelectedPageSize,
    };
    return (
      <div className={styles.searchResults}>
        <ROGrid
          data={searchResultsData || []}
          onPageChange={onPageChangeHandler}
          onPageSizeChange={onPageSizeChangeHandler}
          gridState={gridState}
          pageSizeOptions={pageSizeOptions}
          sort={false}
          isLoading={isGridLoading}
        />
      </div>
    );
  };

  return (
    <React.Fragment>
      {!isSearchCriteriaValid ? (
        <div className={styles.messageContainer}>
          <UI.Message
            message={organisationLabels.searchCriteriaError}
            color="error"
            dismissable
            onChange={() => setSearchCriteriaValid(true)}
          />
        </div>
      ) : null}
      <SearchPanel
        title={organisationLabels.duplicateSearchTitle}
        titleType="regular"
        titleSize={32}
        duplicateSearchData={duplicateSearchData}
        clearDuplicateSearch={
          !basicDuplicateSearchValidationCheck(duplicateSearchData) ? organisationLabels.clearSearch : ''
        }
        duplicateSearchButtonLabel={organisationLabels.searchLabel}
        duplicateSearchButtonColor="primary"
        onClearDuplicateSearch={onClearDuplicateSearch}
        handleDuplicateInputChange={handleDuplicateInputChange}
        onDuplicateSearchHandler={onDuplicateSearchHandler}
      />
      {isSearchResults || isGridLoading ? (
        getROGrid()
      ) : (
        <NoResultsFound
          title={organisationLabels.noResultsFoundTitle}
          description={organisationLabels.noResultsFoundDesp}
        />
      )}
      {totalSearchResult >= 0 && !isGridLoading ? (
        <div className={styles.footerButtons}>
          <div className={styles.buttonContainer}>
            <UI.Button
              color="secondary"
              label={organisationLabels.cancelButtonTitle}
              id="cancelDuplicateNewOrg"
              onChange={handleCancel}
            />
            <UI.Button
              color="primary"
              label={organisationLabels.addButtonTitle}
              id="addDuplicateNewOrg"
              onChange={onAddUserHandler}
            />
          </div>
        </div>
      ) : null}
    </React.Fragment>
  );
};

export default withServiceRequest(OrganisationDuplicateSearchPanel);
