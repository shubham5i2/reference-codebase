import React from 'react';
import { Switch } from 'react-router-dom';
import TestTakerTRFBookingDetails from './TestTakerTRFBookingDetails/TestTakerTRFBookingDetails';
import PrivateRoute from '../../../routes/PrivateRoute';

export default (props: any) => {
  const currentUrl = props.match.url;
  return (
    <div>
      <Switch>
        <PrivateRoute path={`${currentUrl}/:bookingId`} component={TestTakerTRFBookingDetails} />
      </Switch>
    </div>
  );
};
