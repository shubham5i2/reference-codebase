import React, { useState, useEffect, useContext, useRef } from 'react';
import * as BreadCrumbActions from '../../../../Store/Actions/BreadCrumbActions';
import { useStateValue } from '../../../../Store/helpers/UseStateValue';
import { languageService } from '../../../../services/Language/LanguageService';
import TestTakerBookingGrid from '../../../Organisms/TestTakerBookingGrid/TestTakerBookingGrid';
import withServiceRequest, { ConnectorInterface, ServiceRequest } from '../../../../services/utils/ServiceRequest';
import {
  getTestTakerTRFBookingDetails,
  getTRFSignedUrl,
  downloadTestTakerTRF,
} from '../../../../services/API/TestTaker/GetTestTakerBookingDetails';
import UI from 'ielts-cmds-ui-component-library';
import { AsyncResponseStatus } from '../../../../services/Models/Api';
import { ManageTestTakerSearchPayload, Sorting, SortType } from '../../../../services/Models/TestTakerManagement';
import TestTakerTRFGrid from '../../../Organisms/TestTakerTRFGrid/TestTakerTRFGrid';
import { ColumnSort } from '../../../../services/Models/UIModels';
import styles from './TestTakerTRFBookingDetails.module.scss';
import { TestTakerTRFResponse, TestTakerTRFSignedUrlRequest } from '../../../../services/Models/TestTakerTRF';
import { sortByField } from '../../../utils/utilities';
import { useParams } from 'react-router-dom';

interface TestTakerTRFBookingDetailsPageProps {
  serviceRequest: ServiceRequest;
}

const TestTakerTRFBookingDetails = (props: TestTakerTRFBookingDetailsPageProps) => {
  const { dispatch } = useStateValue();
  const { bookingId } = useParams<{ bookingId: string }>();
  const connectorContext = useContext<ConnectorInterface>(UI.ConnectorContext);
  const [currentSelectedPage, setCurrentSelectedPage] = useState({ page: 1 });
  const testTakerTRFLabels = languageService().testTakerTRF;
  const [data, setData] = useState<TestTakerTRFResponse>();
  const [reportType, setReportType] = useState('');
  const isFromSearchClick = useRef(false);
  const [testTakerData, setTestTakerData] = useState([] as TestTakerTRFResponse['selections']);
  const [isDownloadRequested, setDownloadRequested] = useState(false);
  const [downloadResponse, setDownloadResponse] = useState();
  const [selectedSortOption, setSelectedSortOption] = useState([
    {
      sortType: 'ASC',
      sortBy: 'organisationId',
    },
    {
      sortType: 'ASC',
      sortBy: 'organisationName',
    },
    {
      sortType: 'ASC',
      sortBy: 'organisationAddress',
    },
    {
      sortType: 'ASC',
      sortBy: 'caseNumber',
    },
    {
      sortType: 'ASC',
      sortBy: 'selectionDate',
    },
    {
      sortType: 'ASC',
      sortBy: 'personDepartment',
    },
    {
      sortType: 'ASC',
      sortBy: 'confirmationStatus',
    },
    {
      sortType: 'ASC',
      sortBy: 'confirmationStatusChangedDatetime',
    },
    {
      sortType: 'ASC',
      sortBy: 'printStatus',
    },
    {
      sortType: 'ASC',
      sortBy: 'printStatusDatetime',
    },
    {
      sortType: 'ASC',
      sortBy: 'organisationType',
    },
  ]);

  useEffect(() => {
    dispatch({ type: BreadCrumbActions.SHOW_BACK, payload: true });
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const sortingData: Sorting = {
      sortBy: 'confirmationStatus',
      sortType: 'DESC',
    };
    getTestTakerBookingDetails(sortingData);
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [connectorContext.connectionId]);

  const getTestTakerBookingDetails = (sortingData: Sorting) => {
    const reqBody: ManageTestTakerSearchPayload = {
      criteria: {
        bookingUuid: bookingId,
      },
      pagination: {
        pageNumber: 1,
        pageSize: 50,
      },
      sorting: [sortingData],
    };
    getTestTakerTRFBookingDetails(reqBody, bookingId, props.serviceRequest).subscribe(
      (bookingDetailsData: { bookingData: TestTakerTRFResponse; status: AsyncResponseStatus }) => {
        setBookingData(bookingDetailsData.bookingData);
        bookingDetailsData.bookingData && setTestTakerData(bookingDetailsData.bookingData.selections);
      },
    );
    //eslint-disable-next-line react-hooks/exhaustive-deps
  };

  const setBookingData = async (booking: TestTakerTRFResponse) => {
    booking?.selections.forEach((selection) => {
      if (selection.confirmationStatus?.toLowerCase() === 'conditional') {
        selection.confirmationStatus = `${selection.confirmationStatus}: ${selection.minimumScoreSatisfied
          .toLocaleLowerCase()
          .charAt(0)
          .toUpperCase()}${selection.minimumScoreSatisfied.toLowerCase().slice(1)}`;
        selection.confirmationStatus =
          selection.minimumScoreSatisfied.toLowerCase() === 'unsatisfied'
            ? selection.confirmationStatus.replace('Unsatisfied', 'Not Satisfied')
            : selection.confirmationStatus;
      }
    });
    setData(booking);
  };

  const downloadTRF = (signedUrl: string, fileName: string) => {
    downloadTestTakerTRF(signedUrl, fileName);
  };

  const isSelectionsAvailable = () => data && data.selections && data.selections.length > 0;

  const isBookingDataAvailable = () =>
    (data && Object.keys(data).length > 0) || (isDownloadRequested && downloadResponse !== '');

  const getDataForTestTakerGrid = () => (data && data.selections && data?.selections.length) || 0;

  const getSignedUrl = async (requestedReportType: string) => {
    setDownloadRequested(true);
    const bookingUuid = bookingId;
    const req: TestTakerTRFSignedUrlRequest = {
      criteria: {
        bookingUuid: bookingUuid,
      },
    };
    getTRFSignedUrl(req, bookingUuid, props.serviceRequest, requestedReportType).subscribe(
      ({ signedUrl, printCount, printedBy, printedDateTime, fileName }) => {
        console.log('test taker data ', testTakerData);
        if (signedUrl) {
          downloadTRF(signedUrl, fileName);
          const bookingDetails: TestTakerTRFResponse = data || ({} as TestTakerTRFResponse);
          setReportType(requestedReportType);
          setData({
            ...bookingDetails,
            [requestedReportType]: {
              printEventCount: printCount,
              printedBy: printedBy,
              printedDateTime: printedDateTime,
            },
          });
          setDownloadResponse(signedUrl);
        }
      },
    );
  };

  const getTestTakerGrid = () => {
    return {
      totalRecords: getDataForTestTakerGrid(),
      initialState: {
        pageSize: getDataForTestTakerGrid(),
      },
      selectedPage: 1,
      selectedOptionValue: getDataForTestTakerGrid(),
    };
  };

  const onColumnSortHandler = (column: ColumnSort) => {
    const sortedList = selectedSortOption;
    let sortIndex = 0;
    sortedList.forEach((sl, index) => {
      if (JSON.stringify(sl.sortBy) === JSON.stringify(column.Header.name)) {
        if (sl.sortType === SortType.desc) {
          sl.sortType = SortType.asc;
        } else {
          sl.sortType = SortType.desc;
        }
        sortIndex = index;
      }
    });
    setSelectedSortOption(() => sortedList);
    isFromSearchClick.current = false;
    setCurrentSelectedPage(() => {
      return { page: 1 };
    });
    const fieldName = selectedSortOption[sortIndex].sortBy;
    const orderBy = selectedSortOption[sortIndex].sortType.toLowerCase();
    sortByField(data?.selections || [], fieldName, orderBy);
  };

  return (
    <>
      {isBookingDataAvailable() && (
        <div className={isSelectionsAvailable() ? styles.width97 : styles.fullWidth}>
          <div className={styles.testTakerTRFBookingDetails}>
            <TestTakerBookingGrid
              title={testTakerTRFLabels.title}
              titleType="regular"
              titleSize={32}
              downloadReportHandler={getSignedUrl}
              subTitle={testTakerTRFLabels.subTitle}
              subTitleType="regular"
              subTitleSize={18}
              reportType={reportType}
              data={data}
            />
            <div className={styles.resultUpdated}>Result last updated : {data && data.resultLastUpdatedDate}</div>

            {isSelectionsAvailable() && (
              <div className={styles.searchResults}>
                <TestTakerTRFGrid
                  data={(data && data.selections) || []}
                  gridState={getTestTakerGrid()}
                  pageNumber={currentSelectedPage.page}
                  onColumnSort={onColumnSortHandler}
                  sortOptionArray={selectedSortOption}
                  sort={true}
                />
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
};

export default withServiceRequest(TestTakerTRFBookingDetails);
