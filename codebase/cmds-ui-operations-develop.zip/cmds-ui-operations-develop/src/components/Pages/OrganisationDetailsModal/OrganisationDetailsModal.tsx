import React, { useState, useEffect, useContext } from 'react';
import UI from 'ielts-cmds-ui-component-library';
import styles from './OrganisationDetailsModal.module.scss';
import OrganisationDetailsHeader from '../../Molecules/OrganisationDetailsHeader/OrganisationDetailsHeader';
import OrganisationDetails from '../../Molecules/OrganisationDetails/OrganisationDetails';
import ContactDetails from '../../Molecules/ContactDetails/ContactDetails';
import MinimumScoreData from '../../Organisms/MinimumScoreData/MinimumScoreData';
import { OrganisationDetailResponseData } from '../../../services/Models/Organisation';
import CloseIcon from '../../../assets/images/Close.svg';
import withServiceRequest, { ConnectorInterface } from '../../../services/utils/ServiceRequest';
import { getOrganisation } from '../../../services/API/Organisation/OrganisationDetails';
import { ServiceRequestParentProps } from '../../../services/Models/UIModels';
import useDirectChild from '../OrganisationDetailsPage/UseDirectChild';

interface OrganisationDetailsModalProps extends ServiceRequestParentProps {
  onDialogClose: () => void;
  parentOrgId: string;
}

const OrganisationDetailsModal = (props: OrganisationDetailsModalProps) => {
  const connectorContext = useContext<ConnectorInterface>(UI.ConnectorContext);
  const [parentOrgId, setParentOrgId] = useState(props.parentOrgId);
  const [organisationDetail, setOrganisationDetail] = useState<OrganisationDetailResponseData>(Object);
  const { setRoId, directChildren } = useDirectChild(props.serviceRequest);

  useEffect(() => {
    parentOrgId &&
      getOrganisation(parentOrgId, props.serviceRequest).subscribe((organisationDetail) => {
        organisationDetail && setOrganisationDetail(organisationDetail);
        organisationDetail && setRoId(organisationDetail.organisationDetail?.recognisingOrganisationUuid);
      });
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [connectorContext.connectionId, parentOrgId]);

  const onParentOrgChange = (parentOrgId: string) => {
    setParentOrgId(parentOrgId);
  };

  return (
    <div className={styles.oranisationDetailModal}>
      <div className={styles.backDrop} onClick={props.onDialogClose}></div>
      <div className={styles.content}>
        <div>
          <img id="closeIcon" alt="" src={CloseIcon} className={styles.closeButton} onClick={props.onDialogClose} />
          <div className={styles.headerWrapper}>
            <div className={styles.headerContainer}>
              <OrganisationDetailsHeader headerData={organisationDetail?.organisationDetail} />
            </div>
          </div>

          <div className={styles.organisationDetail}>
            <OrganisationDetails
              organisationDetail={organisationDetail?.organisationDetail}
              onParentChange={onParentOrgChange}
              directChildren={directChildren}
            />
          </div>
          <div className={styles.organisationDetail}>
            <ContactDetails
              primaryContactAddress={organisationDetail?.contactDetail?.primaryContactAddress}
              adminContactAddress={organisationDetail?.contactDetail?.adminContactAddress}
            />
          </div>
          <div className={`${styles.organisationDetail} ${styles.minimumScoreContainer}`}>
            <MinimumScoreData minimumScore={organisationDetail?.minimumScore} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default withServiceRequest(OrganisationDetailsModal);
