import React, { useEffect, useState } from 'react';
import { languageService } from '../../../../services/Language/LanguageService';
import styles from './ResultsTestTakerDetails.module.scss';
import ResultDetailsBadge from '../../../../assets/images/ResultDetailsBadge.svg';
import TTPhotoVerificationSymbol from '../../../../assets/images/Icon_Check.svg';
import ScoreHistoryGrid from '../../../Organisms/ScoreHistoryGrid/ScoreHistoryGrid';
import { useStateValue } from '../../../../Store/helpers/UseStateValue';
import * as BreadCrumbActions from '../../../../Store/Actions/BreadCrumbActions';
import { getBookingResults } from '../../../../services/API/Result/Booking';
import { useHistory } from 'react-router-dom';
import withServiceRequest, { ServiceRequest } from '../../../../services/utils/ServiceRequest';

import {
  componentGradeTypes,
  ComponentRoundInfo,
  photoTypes,
  ResultScoreInfo,
  ResultStatusInfo,
  ResultTTPhotoDetails,
  HeaderData,
} from './ResultsTestTakerDetailsConstants';
import ResultsTestTakerDetailsHeader from '../../../Organisms/ResultsTestTakerDetailsHeader/ResultsTestTakerDetailsHeader';
import TestTakerPhoto from '../../../Organisms/TestTakerPhoto/TestTakerPhoto';
import StatusHistoryGrid from '../../../Organisms/StatusHistoryGrid/StatusHistoryGrid';
import ResultsBookingDetails from '../../../Organisms/ResultsBookingDetails/ResultsBookingDetails';
import ScoreHistoryGridRawScore from '../../../Organisms/ScoreHistoryGrid/ScoreHistoryGridRawScore';
import { BookingDetails } from '../../../../services/Models/Result';

interface ResultsTestTakerDetailsProps {
  defaultActiveTab?: string;
  serviceRequest: ServiceRequest;
}

export interface Scores {
  overall: ComponentRoundInfo[] | undefined;
  listening: ComponentRoundInfo[] | undefined;
  reading: ComponentRoundInfo[] | undefined;
  writing: ComponentRoundInfo[] | undefined;
  speaking: ComponentRoundInfo[] | undefined;
}

const ResultsTestTakerDetails = (props: ResultsTestTakerDetailsProps) => {
  const { dispatch } = useStateValue();
  const resultLabels = languageService().result;
  const history = useHistory();
  const [bookingDetails, setBookingDetails] = useState<BookingDetails>();
  const [scores, setScores] = useState<Scores>();
  const [resultsStatusLabel, setResultsStatusLabel] = useState('');
  const [activeTab, setActiveTab] = useState(props.defaultActiveTab || resultLabels.bookingDetailsLabel.toUpperCase());
  const [ORSphoto, setORSphoto] = useState('');
  const [testDayPhoto, setTestDayPhoto] = useState('');
  const [ttIdPhoto, setTtIdPhoto] = useState('');
  const [statusHistory, setStatusHistory] = useState([] as ResultStatusInfo[]);
  const [headerData, setHeaderData] = useState<HeaderData | null>(null);

  useEffect(() => {
    dispatch({ type: BreadCrumbActions.SHOW_BACK, payload: true });
    getResultsTestTakerDetails();
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getComponent = (compName: string) => (r: ResultScoreInfo) => r.componentGradeType.toLowerCase() === compName;
  const getResultsTestTakerDetails = () => {
    getBookingResults(history.location.state.selectedBookingUuid, props.serviceRequest).subscribe((data) => {
      setHeaderData({
        selectedBookingUuid: history.location.state.selectedBookingUuid,
        bookingResults: data.bookingResults?.bookingDetails,
      });
      setStatusHistory(data.bookingResults?.resultStatusHistory);

      setScores({
        overall: data.bookingResults?.resultScoreHistory?.find(getComponent(componentGradeTypes.OVERALL.toLowerCase()))
          ?.componentRounds,
        listening: data.bookingResults?.resultScoreHistory?.find(
          getComponent(componentGradeTypes.LISTENING.toLowerCase()),
        )?.componentRounds,
        reading: data.bookingResults?.resultScoreHistory?.find(getComponent(componentGradeTypes.READING.toLowerCase()))
          ?.componentRounds,
        speaking: data.bookingResults?.resultScoreHistory?.find(
          getComponent(componentGradeTypes.SPEAKING.toLowerCase()),
        )?.componentRounds,
        writing: data.bookingResults?.resultScoreHistory?.find(getComponent(componentGradeTypes.WRITING.toLowerCase()))
          ?.componentRounds,
      });
      setBookingDetails(data.bookingResults.bookingDetails);
      setResultsStatusLabel(data.bookingResults.bookingDetails.currentResultStatus.resultStatusLabel);
      setTestTakerPhotoDetails(data.bookingResults.resultTTPhotoDetails);
    });
  };

  const onTabChange = (e: React.MouseEvent<HTMLElement>) => {
    const tabElement = e.target as HTMLElement;
    const tab = tabElement.innerHTML;
    setActiveTab(tab);
  };

  const setTestTakerPhotoDetails = (photos: ResultTTPhotoDetails[]) => {
    photos.forEach((photo) => {
      if (photo.photoType === photoTypes.TT_ID_HR_R) {
        setORSphoto(photo.photoUrl);
      } else if (photo.photoType === photoTypes.TT_P_LR_LRW_WC) {
        setTestDayPhoto(photo.photoUrl);
      } else if (photo.photoType === photoTypes.TT_ID_LRW_WC) {
        setTtIdPhoto(photo.photoUrl);
      }
    });
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case resultLabels.bookingDetailsLabel.toUpperCase():
        return (
          <div className={styles.ResultsTestTakerDetailsWrapper}>
            <ResultsBookingDetails
              bookingDetails={bookingDetails}
              getResultsTestTakerDetails={getResultsTestTakerDetails}
            />
          </div>
        );
      case resultLabels.statusHistoryLabel.toUpperCase():
        return (
          <div className={styles.ResultsTestTakerDetailsWrapper}>
            <StatusHistoryGrid statusHistory={statusHistory} />
          </div>
        );
      case resultLabels.scoreHistoryLabel.toUpperCase():
        return (
          <div className={styles.ResultsTestTakerDetailsWrapper}>
            <div className={styles.ResultsTestTakerDetails}>
              <div className={styles.header}>
                <div className={styles.headerTitle}>
                  <img alt="" src={ResultDetailsBadge} className={styles.headerIcon} />
                  {resultLabels.scoresLabel}
                </div>
              </div>
              <div className={styles.body}>
                <div className={styles.sectionHeader}>{resultLabels.scoreOverallLabel}</div>
                <ScoreHistoryGrid data={scores?.overall || []} />
                <div className={styles.sectionHeader}>{resultLabels.scoreListeningLabel}</div>
                <ScoreHistoryGridRawScore data={scores?.listening || []} />
                <div className={styles.sectionHeader}>{resultLabels.scoreReadingLabel}</div>
                <ScoreHistoryGridRawScore data={scores?.reading || []} />
                <div className={styles.sectionHeader}>{resultLabels.scoreWritingLabel}</div>
                <ScoreHistoryGrid data={scores?.writing || []} expandable />
                <div className={styles.sectionHeader}>{resultLabels.scoreSpeakingLabel}</div>
                <ScoreHistoryGrid data={scores?.speaking || []} expandable component="speaking" />
              </div>
            </div>
          </div>
        );
      case resultLabels.testTakerPhotoLabel.toUpperCase():
        return (
          <div className={styles.ttPhotoWrapper}>
            <div className={styles.ttPhotoDetails}>
              <div className={styles.header}>
                <div className={styles.headerTitle}>
                  <img alt={''} src={TTPhotoVerificationSymbol} className={styles.headerIcon} />
                  {resultLabels.photoVerificationLabel}
                </div>
              </div>
              <div className={styles.body}>
                <div className={styles.photoGroup}>
                  <div className={styles.testTakerPhoto}>
                    <div className={styles.photoLabel}>{resultLabels.testTakerPhotoORS}</div>
                    <TestTakerPhoto
                      photoUrl={ORSphoto}
                      photoStyle={styles.photoCard}
                      defaultPhotoStyle={styles.defaultPicture}
                      wrapperDivStyle={styles.photoCard}
                    />
                  </div>
                  <div className={styles.testTakerPhoto}>
                    <div className={styles.photoLabel}>{resultLabels.testTakerPhotoLRWTestDay}</div>
                    <TestTakerPhoto
                      photoUrl={testDayPhoto}
                      photoStyle={styles.photoCard}
                      defaultPhotoStyle={styles.defaultPicture}
                      wrapperDivStyle={styles.photoCard}
                    />
                  </div>
                  <div className={styles.testTakerPhoto}>
                    <div className={styles.photoLabel}>{resultLabels.testTakerPhotoLRWId}</div>
                    <TestTakerPhoto
                      photoUrl={ttIdPhoto}
                      photoStyle={styles.photoCard}
                      defaultPhotoStyle={styles.defaultPicture}
                      wrapperDivStyle={styles.photoCard}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <>
      <ResultsTestTakerDetailsHeader
        onTabChange={onTabChange}
        testTakerTitle={
          bookingDetails && bookingDetails !== null
            ? bookingDetails?.personalDetails.givenName + ' ' + bookingDetails?.personalDetails.familyName
            : ''
        }
        resultsStatus={bookingDetails?.currentResultStatus.resultStatusType}
        resultsStatusLabel={resultsStatusLabel}
        resultsOnHoldStatus={bookingDetails?.currentResultStatus.onHold}
        headerData={headerData}
      />
      {renderTabContent()}
    </>
  );
};

export default withServiceRequest(ResultsTestTakerDetails);
