import { BookingDetails } from '../../../../services/Models/Result';
import { resultsBookingDetailsMockData } from '../../../../mocks/Results/ResultsViewDetails/ResultsViewBookingDetails';

export enum componentGradeTypes {
  LISTENING = 'Listening',
  OVERALL = 'Overall',
  READING = 'Reading',
  SPEAKING = 'Speaking',
  WRITING = 'Writing',
}

export enum photoTypes {
  TT_ID_HR_R = 'TT_ID_HR_R',
  TT_P_LR_LRW_WC = 'TT_P_LR_LRW_WC',
  TT_ID_LRW_WC = 'TT_ID_LRW_WC',
}

export interface ResultStatusInfo {
  onHold: boolean;
  resultsStatusHistoryUuid: string;
  resultStatusTypeUuid: string;
  resultStatusLabelUuid: string;
  resultStatusComment: string;
  resultStatusCommentUuid: string;
  resultStatusUpdateDatetime: string;
  resultStatusUpdatedBy: string;
  resultStatusType: string;
  resultStatusLabel: string;
}

export interface Criteria {
  criteriaUuid: string;
  criteriaScore?: number;
  criteriaValue: string;
}

export interface TaskInfo {
  taskNumber?: number;
  examiner?: number;
  criterias?: Criteria[];
}

export interface ComponentRoundInfo {
  componentEvaluationRoundId: number;
  overallResultType: string;
  overallFinalGrade?: number | null;
  dateReceived: string;
  rawScore?: number | null;
  tasks?: TaskInfo[];
  isUpdated?: boolean;
}

export interface ResultScoreInfo {
  componentGradeType: string;
  componentRounds: ComponentRoundInfo[];
}

export interface LatestComponentScore {
  overall: ComponentRoundInfo | null;
  reading: ComponentRoundInfo | null;
  speaking: ComponentRoundInfo | null;
  listening: ComponentRoundInfo | null;
  writing: ComponentRoundInfo | null;
}
export interface HeaderData {
  selectedBookingUuid?: string;
  bookingResults?: BookingDetails;
}

export interface ResultTTPhotoDetails {
  photoUuid: string;
  photoUrl: string;
  photoType: photoTypes.TT_ID_HR_R | photoTypes.TT_P_LR_LRW_WC | photoTypes.TT_ID_LRW_WC;
}

export interface BookingResultsResponse {
  bookingUuid: string;
  resultConcurrencyVersion: number;
  currentResultStatus: ResultStatusInfo;
  resultStatusHistory: ResultStatusInfo[];
  resultScoreHistory: ResultScoreInfo[];
  latestComponentScore: LatestComponentScore;
}

export interface BookingResultsResponseV2 {
  bookingDetails: BookingDetails;
  resultStatusHistory: ResultStatusInfo[];
  resultScoreHistory: ResultScoreInfo[];
  resultTTPhotoDetails: ResultTTPhotoDetails[];
}

export const bookingResultsMockData: BookingResultsResponseV2 = {
  bookingDetails: resultsBookingDetailsMockData,
  resultStatusHistory: [
    {
      onHold: false,
      resultsStatusHistoryUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
      resultStatusTypeUuid: '735d2d71-b4a9-47ec-b566-34b2d3015540',
      resultStatusLabelUuid: '52a50291-bd70-4989-9fce-584b0aa3cc65',
      resultStatusComment: '',
      resultStatusCommentUuid: '4d237446-2245-4ad0-93fa-1089bcaf0338',
      resultStatusUpdateDatetime: '1995-09-07T10:40:52Z',
      resultStatusUpdatedBy: 'John Amber',
      resultStatusType: 'Permanently Withheld',
      resultStatusLabel: 'Pre-release Check Investigation',
    },
    {
      onHold: false,
      resultsStatusHistoryUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
      resultStatusTypeUuid: '3d189282-e531-47f2-aa22-d24eef1d20b6',
      resultStatusLabelUuid: 'aee4f1ac-d11a-4423-b1b6-61cb5bb30a78',
      resultStatusComment: 'Tampered/counterfeit TRF',
      resultStatusCommentUuid: '',
      resultStatusUpdateDatetime: '1995-09-06T10:40:52Z',
      resultStatusUpdatedBy: 'John Amber',
      resultStatusType: 'Permanently Withheld',
      resultStatusLabel: 'Pre-release Check Investigation',
    },
    {
      onHold: false,
      resultsStatusHistoryUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
      resultStatusTypeUuid: '19bdb4b7-74bc-4f3d-b846-eb4a4e8022e6',
      resultStatusLabelUuid: '456a33a0-693c-4dfd-824f-962784f8bf7d',
      resultStatusComment: 'In-room identity swap',
      resultStatusCommentUuid: '123a33a0-693c-4dfd-824f-962784f8bf7d',
      resultStatusUpdateDatetime: '1995-09-05T10:40:52Z',
      resultStatusUpdatedBy: '',
      resultStatusType: 'Permanently Withheld',
      resultStatusLabel: 'Pre-release Check Investigation',
    },
    {
      onHold: false,
      resultsStatusHistoryUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
      resultStatusTypeUuid: '27c03460-2662-4a63-b1aa-6d158b85c0a5',
      resultStatusLabelUuid: '456a33a0-693c-4dfd-824f-962784f8bf7d',
      resultStatusComment: 'In-room identity swap',
      resultStatusCommentUuid: '123a33a0-693c-4dfd-824f-962784f8bf7d',
      resultStatusUpdateDatetime: '1995-09-04T10:40:52Z',
      resultStatusUpdatedBy: '',
      resultStatusType: 'Permanently Withheld',
      resultStatusLabel: 'Pre-release Check Investigation',
    },
  ],
  resultScoreHistory: [
    {
      componentGradeType: 'Overall',
      componentRounds: [
        {
          componentEvaluationRoundId: 1,
          overallResultType: 'Jagged 1',
          overallFinalGrade: 6.5,
          isUpdated: false,
          dateReceived: '2020-02-15T12:50:00.000Z',
        },
        {
          componentEvaluationRoundId: 2,
          overallResultType: 'Jagged 2',
          overallFinalGrade: 6.5,
          isUpdated: false,
          dateReceived: '2020-02-15T12:50:00.000Z',
        },
        {
          componentEvaluationRoundId: 3,
          overallResultType: 'Normal',
          overallFinalGrade: 7,
          isUpdated: false,
          dateReceived: '2020-02-15T12:50:00.000Z',
        },
        {
          componentEvaluationRoundId: 3,
          overallResultType: 'EOR',
          overallFinalGrade: 7.5,
          dateReceived: '2020-02-15T12:50:00.000Z',
        },
      ],
    },
    {
      componentGradeType: 'Listening',
      componentRounds: [
        {
          componentEvaluationRoundId: 1,
          overallResultType: 'Normal',
          overallFinalGrade: 7,
          isUpdated: false,
          dateReceived: '2020-02-15T12:50:00.000Z',
          rawScore: 38,
        },
        {
          componentEvaluationRoundId: 2,
          overallResultType: 'Normal',
          overallFinalGrade: null,
          isUpdated: false,
          dateReceived: '2020-02-15T12:50:00.000Z',
          rawScore: 38,
        },
      ],
    },
    {
      componentGradeType: 'Reading',
      componentRounds: [
        {
          componentEvaluationRoundId: 1,
          overallResultType: 'Normal',
          overallFinalGrade: 8,
          isUpdated: false,
          dateReceived: '2020-02-15T12:50:00.000Z',
          rawScore: 38,
        },
        {
          componentEvaluationRoundId: 2,
          overallResultType: 'Normal',
          overallFinalGrade: undefined,
          isUpdated: false,
          dateReceived: '2020-02-15T12:50:00.000Z',
          rawScore: 38,
        },
      ],
    },
    {
      componentGradeType: 'Writing',
      componentRounds: [
        {
          componentEvaluationRoundId: 1,
          overallResultType: 'Jagged 1',
          overallFinalGrade: 6.5,
          isUpdated: false,
          dateReceived: '2020-02-15T12:50:00.000Z',
          tasks: [
            {
              taskNumber: 1,
              examiner: 3487300,
              criterias: [
                { criteriaUuid: '1182960a-e547-4e57-b06a-db499e4927ee', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: '574a9570-da1d-45c7-ad44-c56c29f4d1bc', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: 'e0dc0b2e-70fc-466c-aaf3-d90389169174', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: 'd0d2b953-7370-47e1-9508-4383fe46b3bb', criteriaScore: 8, criteriaValue: 'p' },
              ],
            },
            {
              taskNumber: 2,
              examiner: 3487300,
              criterias: [
                { criteriaUuid: '600bc354-b1f5-4567-b8c5-84b1a3344e65', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: '574a9570-da1d-45c7-ad44-c56c29f4d1bc', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: 'e0dc0b2e-70fc-466c-aaf3-d90389169174', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: 'd0d2b953-7370-47e1-9508-4383fe46b3bb', criteriaScore: 8, criteriaValue: 'p' },
              ],
            },
          ],
        },
        {
          componentEvaluationRoundId: 2,
          overallResultType: 'Normal',
          overallFinalGrade: 8,
          isUpdated: false,
          dateReceived: '2020-02-15T12:50:00.000Z',
          tasks: [
            {
              taskNumber: 1,
              examiner: 3487300,
              criterias: [
                { criteriaUuid: '1182960a-e547-4e57-b06a-db499e4927ee', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: '574a9570-da1d-45c7-ad44-c56c29f4d1bc', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: 'e0dc0b2e-70fc-466c-aaf3-d90389169174', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: 'd0d2b953-7370-47e1-9508-4383fe46b3bb', criteriaScore: 8, criteriaValue: 'p' },
              ],
            },
            {
              taskNumber: 2,
              examiner: 3487300,
              criterias: [
                { criteriaUuid: '1182960a-e547-4e57-b06a-db499e4927ee', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: '574a9570-da1d-45c7-ad44-c56c29f4d1bc', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: 'e0dc0b2e-70fc-466c-aaf3-d90389169174', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: 'd0d2b953-7370-47e1-9508-4383fe46b3bb', criteriaScore: 8, criteriaValue: 'p' },
              ],
            },
          ],
        },
        {
          componentEvaluationRoundId: 3,
          overallFinalGrade: 0,
          overallResultType: 'Normal',
          isUpdated: false,
          dateReceived: '2020-02-15T12:50:00.000Z',
          tasks: [
            {
              taskNumber: 1,
              examiner: 3487300,
              criterias: [
                { criteriaUuid: '1182960a-e547-4e57-b06a-db499e4927ee', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: '574a9570-da1d-45c7-ad44-c56c29f4d1bc', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: 'e0dc0b2e-70fc-466c-aaf3-d90389169174', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: 'd0d2b953-7370-47e1-9508-4383fe46b3bb', criteriaScore: 8, criteriaValue: 'p' },
              ],
            },
            {
              taskNumber: 2,
              examiner: 3487300,
              criterias: [
                { criteriaUuid: '1182960a-e547-4e57-b06a-db499e4927ee', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: '574a9570-da1d-45c7-ad44-c56c29f4d1bc', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: 'e0dc0b2e-70fc-466c-aaf3-d90389169174', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: 'd0d2b953-7370-47e1-9508-4383fe46b3bb', criteriaScore: 8, criteriaValue: 'p' },
              ],
            },
          ],
        },
        {
          componentEvaluationRoundId: 4,
          overallFinalGrade: 7,
          overallResultType: 'EOR',
          isUpdated: true,
          dateReceived: '2020-02-15T12:50:00.000Z',
          tasks: [
            {
              taskNumber: 1,
              examiner: 3487300,
              criterias: [
                { criteriaUuid: '1182960a-e547-4e57-b06a-db499e4927ee', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: '574a9570-da1d-45c7-ad44-c56c29f4d1bc', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: 'e0dc0b2e-70fc-466c-aaf3-d90389169174', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: 'd0d2b953-7370-47e1-9508-4383fe46b3bb', criteriaScore: 8, criteriaValue: 'p' },
              ],
            },
            {
              taskNumber: 2,
              examiner: 3487300,
              criterias: [
                { criteriaUuid: '1182960a-e547-4e57-b06a-db499e4927ee', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: '574a9570-da1d-45c7-ad44-c56c29f4d1bc', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: 'e0dc0b2e-70fc-466c-aaf3-d90389169174', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: 'd0d2b953-7370-47e1-9508-4383fe46b3bb', criteriaScore: 8, criteriaValue: 'p' },
              ],
            },
          ],
        },
      ],
    },
    {
      componentGradeType: 'Speaking',
      componentRounds: [
        {
          componentEvaluationRoundId: 1,
          overallFinalGrade: 6.5,
          overallResultType: 'Jagged 1',
          isUpdated: false,
          dateReceived: '2020-02-15T12:50:00.000Z',
          tasks: [
            {
              examiner: 2382731,
              criterias: [
                { criteriaUuid: '1182960a-e547-4e57-b06a-db499e4927ee', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: '574a9570-da1d-45c7-ad44-c56c29f4d1bc', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: 'e0dc0b2e-70fc-466c-aaf3-d90389169174', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: 'd0d2b953-7370-47e1-9508-4383fe46b3bb', criteriaScore: 8, criteriaValue: 'p' },
              ],
            },
          ],
        },
        {
          componentEvaluationRoundId: 2,
          overallFinalGrade: 6.5,
          overallResultType: 'Jagged 2',
          isUpdated: false,
          dateReceived: '2020-02-15T12:50:00.000Z',
          tasks: [
            {
              examiner: 2382731,
              criterias: [
                { criteriaUuid: '1182960a-e547-4e57-b06a-db499e4927ee', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: '574a9570-da1d-45c7-ad44-c56c29f4d1bc', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: 'e0dc0b2e-70fc-466c-aaf3-d90389169174', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: 'd0d2b953-7370-47e1-9508-4383fe46b3bb', criteriaScore: 8, criteriaValue: 'p' },
              ],
            },
          ],
        },
        {
          componentEvaluationRoundId: 3,
          overallFinalGrade: 7,
          overallResultType: 'Normal',
          isUpdated: false,
          dateReceived: '2020-02-15T12:50:00.000Z',
          tasks: [
            {
              examiner: 2382731,
              criterias: [
                { criteriaUuid: '1182960a-e547-4e57-b06a-db499e4927ee', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: '574a9570-da1d-45c7-ad44-c56c29f4d1bc', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: 'e0dc0b2e-70fc-466c-aaf3-d90389169174', criteriaScore: 8, criteriaValue: 'p' },
                { criteriaUuid: 'd0d2b953-7370-47e1-9508-4383fe46b3bb', criteriaScore: 8, criteriaValue: 'p' },
              ],
            },
          ],
        },
      ],
    },
  ],
  resultTTPhotoDetails: [
    {
      photoUuid: 'fb0f4d7c-d897-423f-9340-b1ce9d665423',
      photoUrl:
        'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAABhWlDQ1BJQ0MgcHJvZmlsZQAAKJF9kT1Iw0AcxV/TlkqpONihiEOGKggWREUcpYpFsFDaCq06mFz6BU0akhQXR8G14ODHYtXBxVlXB1dBEPwAcXRyUnSREv+XFlrEeHDcj3f3HnfvAKFZZarpmwBUzTLSibiYy6+KgVf44UMQEYxJzNSTmcUsXMfXPTx8vYvxLPdzf45+pWAywCMSzzHdsIg3iGc2LZ3zPnGYlSWF+Jx43KALEj9yXW7zG+eSwwLPDBvZ9DxxmFgs9bDcw6xsqMTTxFFF1ShfyLVZ4bzFWa3WWeee/IWhgraS4TrNYSSwhCRSECGjjgqqsBCjVSPFRJr24y7+IcefIpdMrgoYORZQgwrJ8YP/we9uzeLUZDspFAf8L7b9MQIEdoFWw7a/j227dQJ4n4ErreuvNYHZT9IbXS16BAxsAxfXXU3eAy53gMiTLhmSI3lpCsUi8H5G35QHBm+B4Fq7t84+Th+ALHW1fAMcHAKjJcped3l3X29v/57p9PcDYNpyoNtc9GwAAAAGYktHRAD/AP8A/6C9p5MAAAAJcEhZcwAADdcAAA3XAUIom3gAAAAHdElNRQfmBQQKGhzi8GlaAAADqElEQVRIx+2VTWwbRRTHZz9nd+tdb7w2doUqSIEi0aqNFDuWTG2shgSBInGgcIJDq7YXFCEEooIiJE4IBAcOSAWp5MCppeLcUlKFEFL8kaZWm14qpU2RkyZxEnvXO7MfszaHZiXbipOIc99t/3r7fvM07/0HgCexQ1A7JQwMHD0rQnhClGAvxzM8AAC4judg7Mxjyx7L5//65n8BksnUsByQL+0JCEELOzZC9h1CvAUAAGBZ5llJggcFkYd1A1dr67V3irdy13YNGOhPj0Ziwe+J6znra8a5wszUd92661HlL1mO4SvL+miuOPnDjoBkMjUcDoeuYGSvmahxKJcbXwYAgMOHU09Bjn6PoqiG10S/zMzMVAAAoL8/vVcNirehwIVWl9aHCrM3xrcFvDr4WpVhaKFac57xiyeTmfPhsHKGZRkKAACI6zVWV/Sv8sXJz31IWAvcJ8TD49d/72mtx3S2HNKUkcqq/mkuP3ENAAAG4ukPY3t7ztUNtLC2Ujtt1NCvgKZS4Yg8osrRSnlxobC09LCuaTFX05QRVYma5cWFab8m3QoQITxhYcfOFSa/9bWALHyGsWMCynuhODt9uTg7fblSWXresly0R4Ff+Hn5/NTXFnZsKHAnW2u2AyTYi5B9p1UTRL4Hm3ZpYmKC+Nrc3JyD6tYtCHmtNReZ9l1Jgs91BbAcw/mj6EfDa3oMy4Q674pm6HDDa5BWjXjeA5ZjuK6AzfBaP8y6VZIV8cV4/OU3fK2vL/VmUJUOmKY12zYxFOV1FmPbTuB6LsPQva2a5ZC3JIfc00LKb9lsNgAAAJAXL9q2axl163jbxDD0ftchTtcOMLLvSxI81KoVCpP/1qr1nwSRh7pOjug6OSKIPDRq6HypdKPcdoci/xLGznx3gO38LEpQSPQf/cjf6Fcyx+5FouooQjZWFLakKGwJY9vSIsEPMunBu4lE+vTjEU9/IkpQwMi+sO2iDR4b3uA4VnJdYgRkUbMt19Fr5hWvyZ7xFy+RyOzjWfpHOSgNQcixho4qPM8pxPXMP65fDW0LiPclh6JPR66yLEMtP6qO/ZP78xQAoLGVF2WzWdaxmmORqPqu65LmVlbBdP60+Kg8HwrGKlDkXoeQO6iFY6Rcfji1FSAa3XdWVQPvN5tNem3FGM3f/Pviru063pccCoaClwKyqG7a9Rwh3oNOuzYNa6O2ob/defJdPzjJROZjKHAnRZHfz/Hs5oNDHj84yL7QzcqfxK7jP5v/rUsgIAYtAAAAAElFTkSuQmCC',
      photoType: photoTypes.TT_ID_HR_R,
    },
    {
      photoUuid: 'fb0f4d7c-d897-423f-9340-b1ce9d665424',
      photoUrl:
        'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAABhWlDQ1BJQ0MgcHJvZmlsZQAAKJF9kT1Iw0AcxV/TlkqpONihiEOGKggWREUcpYpFsFDaCq06mFz6BU0akhQXR8G14ODHYtXBxVlXB1dBEPwAcXRyUnSREv+XFlrEeHDcj3f3HnfvAKFZZarpmwBUzTLSibiYy6+KgVf44UMQEYxJzNSTmcUsXMfXPTx8vYvxLPdzf45+pWAywCMSzzHdsIg3iGc2LZ3zPnGYlSWF+Jx43KALEj9yXW7zG+eSwwLPDBvZ9DxxmFgs9bDcw6xsqMTTxFFF1ShfyLVZ4bzFWa3WWeee/IWhgraS4TrNYSSwhCRSECGjjgqqsBCjVSPFRJr24y7+IcefIpdMrgoYORZQgwrJ8YP/we9uzeLUZDspFAf8L7b9MQIEdoFWw7a/j227dQJ4n4ErreuvNYHZT9IbXS16BAxsAxfXXU3eAy53gMiTLhmSI3lpCsUi8H5G35QHBm+B4Fq7t84+Th+ALHW1fAMcHAKjJcped3l3X29v/57p9PcDYNpyoNtc9GwAAAAGYktHRAD/AP8A/6C9p5MAAAAJcEhZcwAADdcAAA3XAUIom3gAAAAHdElNRQfmBQQKGhzi8GlaAAADqElEQVRIx+2VTWwbRRTHZz9nd+tdb7w2doUqSIEi0aqNFDuWTG2shgSBInGgcIJDq7YXFCEEooIiJE4IBAcOSAWp5MCppeLcUlKFEFL8kaZWm14qpU2RkyZxEnvXO7MfszaHZiXbipOIc99t/3r7fvM07/0HgCexQ1A7JQwMHD0rQnhClGAvxzM8AAC4judg7Mxjyx7L5//65n8BksnUsByQL+0JCEELOzZC9h1CvAUAAGBZ5llJggcFkYd1A1dr67V3irdy13YNGOhPj0Ziwe+J6znra8a5wszUd92661HlL1mO4SvL+miuOPnDjoBkMjUcDoeuYGSvmahxKJcbXwYAgMOHU09Bjn6PoqiG10S/zMzMVAAAoL8/vVcNirehwIVWl9aHCrM3xrcFvDr4WpVhaKFac57xiyeTmfPhsHKGZRkKAACI6zVWV/Sv8sXJz31IWAvcJ8TD49d/72mtx3S2HNKUkcqq/mkuP3ENAAAG4ukPY3t7ztUNtLC2Ujtt1NCvgKZS4Yg8osrRSnlxobC09LCuaTFX05QRVYma5cWFab8m3QoQITxhYcfOFSa/9bWALHyGsWMCynuhODt9uTg7fblSWXresly0R4Ff+Hn5/NTXFnZsKHAnW2u2AyTYi5B9p1UTRL4Hm3ZpYmKC+Nrc3JyD6tYtCHmtNReZ9l1Jgs91BbAcw/mj6EfDa3oMy4Q674pm6HDDa5BWjXjeA5ZjuK6AzfBaP8y6VZIV8cV4/OU3fK2vL/VmUJUOmKY12zYxFOV1FmPbTuB6LsPQva2a5ZC3JIfc00LKb9lsNgAAAJAXL9q2axl163jbxDD0ftchTtcOMLLvSxI81KoVCpP/1qr1nwSRh7pOjug6OSKIPDRq6HypdKPcdoci/xLGznx3gO38LEpQSPQf/cjf6Fcyx+5FouooQjZWFLakKGwJY9vSIsEPMunBu4lE+vTjEU9/IkpQwMi+sO2iDR4b3uA4VnJdYgRkUbMt19Fr5hWvyZ7xFy+RyOzjWfpHOSgNQcixho4qPM8pxPXMP65fDW0LiPclh6JPR66yLEMtP6qO/ZP78xQAoLGVF2WzWdaxmmORqPqu65LmVlbBdP60+Kg8HwrGKlDkXoeQO6iFY6Rcfji1FSAa3XdWVQPvN5tNem3FGM3f/Pviru063pccCoaClwKyqG7a9Rwh3oNOuzYNa6O2ob/defJdPzjJROZjKHAnRZHfz/Hs5oNDHj84yL7QzcqfxK7jP5v/rUsgIAYtAAAAAElFTkSuQmCC',
      photoType: photoTypes.TT_P_LR_LRW_WC,
    },
    {
      photoUuid: 'fb0f4d7c-d897-423f-9340-b1ce9d665425',
      photoUrl:
        'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAABhWlDQ1BJQ0MgcHJvZmlsZQAAKJF9kT1Iw0AcxV/TlkqpONihiEOGKggWREUcpYpFsFDaCq06mFz6BU0akhQXR8G14ODHYtXBxVlXB1dBEPwAcXRyUnSREv+XFlrEeHDcj3f3HnfvAKFZZarpmwBUzTLSibiYy6+KgVf44UMQEYxJzNSTmcUsXMfXPTx8vYvxLPdzf45+pWAywCMSzzHdsIg3iGc2LZ3zPnGYlSWF+Jx43KALEj9yXW7zG+eSwwLPDBvZ9DxxmFgs9bDcw6xsqMTTxFFF1ShfyLVZ4bzFWa3WWeee/IWhgraS4TrNYSSwhCRSECGjjgqqsBCjVSPFRJr24y7+IcefIpdMrgoYORZQgwrJ8YP/we9uzeLUZDspFAf8L7b9MQIEdoFWw7a/j227dQJ4n4ErreuvNYHZT9IbXS16BAxsAxfXXU3eAy53gMiTLhmSI3lpCsUi8H5G35QHBm+B4Fq7t84+Th+ALHW1fAMcHAKjJcped3l3X29v/57p9PcDYNpyoNtc9GwAAAAGYktHRAD/AP8A/6C9p5MAAAAJcEhZcwAADdcAAA3XAUIom3gAAAAHdElNRQfmBQQKGhzi8GlaAAADqElEQVRIx+2VTWwbRRTHZz9nd+tdb7w2doUqSIEi0aqNFDuWTG2shgSBInGgcIJDq7YXFCEEooIiJE4IBAcOSAWp5MCppeLcUlKFEFL8kaZWm14qpU2RkyZxEnvXO7MfszaHZiXbipOIc99t/3r7fvM07/0HgCexQ1A7JQwMHD0rQnhClGAvxzM8AAC4judg7Mxjyx7L5//65n8BksnUsByQL+0JCEELOzZC9h1CvAUAAGBZ5llJggcFkYd1A1dr67V3irdy13YNGOhPj0Ziwe+J6znra8a5wszUd92661HlL1mO4SvL+miuOPnDjoBkMjUcDoeuYGSvmahxKJcbXwYAgMOHU09Bjn6PoqiG10S/zMzMVAAAoL8/vVcNirehwIVWl9aHCrM3xrcFvDr4WpVhaKFac57xiyeTmfPhsHKGZRkKAACI6zVWV/Sv8sXJz31IWAvcJ8TD49d/72mtx3S2HNKUkcqq/mkuP3ENAAAG4ukPY3t7ztUNtLC2Ujtt1NCvgKZS4Yg8osrRSnlxobC09LCuaTFX05QRVYma5cWFab8m3QoQITxhYcfOFSa/9bWALHyGsWMCynuhODt9uTg7fblSWXresly0R4Ff+Hn5/NTXFnZsKHAnW2u2AyTYi5B9p1UTRL4Hm3ZpYmKC+Nrc3JyD6tYtCHmtNReZ9l1Jgs91BbAcw/mj6EfDa3oMy4Q674pm6HDDa5BWjXjeA5ZjuK6AzfBaP8y6VZIV8cV4/OU3fK2vL/VmUJUOmKY12zYxFOV1FmPbTuB6LsPQva2a5ZC3JIfc00LKb9lsNgAAAJAXL9q2axl163jbxDD0ftchTtcOMLLvSxI81KoVCpP/1qr1nwSRh7pOjug6OSKIPDRq6HypdKPcdoci/xLGznx3gO38LEpQSPQf/cjf6Fcyx+5FouooQjZWFLakKGwJY9vSIsEPMunBu4lE+vTjEU9/IkpQwMi+sO2iDR4b3uA4VnJdYgRkUbMt19Fr5hWvyZ7xFy+RyOzjWfpHOSgNQcixho4qPM8pxPXMP65fDW0LiPclh6JPR66yLEMtP6qO/ZP78xQAoLGVF2WzWdaxmmORqPqu65LmVlbBdP60+Kg8HwrGKlDkXoeQO6iFY6Rcfji1FSAa3XdWVQPvN5tNem3FGM3f/Pviru063pccCoaClwKyqG7a9Rwh3oNOuzYNa6O2ob/defJdPzjJROZjKHAnRZHfz/Hs5oNDHj84yL7QzcqfxK7jP5v/rUsgIAYtAAAAAElFTkSuQmCC',
      photoType: photoTypes.TT_ID_LRW_WC,
    },
  ],
};
