import { languageService } from '../../../../services/Language/LanguageService';

const resultLabels = languageService().result;
export const initialOnHoldInputValue = {
  checked: true,
  label: resultLabels.showAllResults,
  value: undefined,
};
