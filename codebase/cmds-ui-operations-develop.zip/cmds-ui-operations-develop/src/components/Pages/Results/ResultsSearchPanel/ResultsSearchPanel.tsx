import React, { useEffect, useRef, useState } from 'react';
import { addMinutes } from 'date-fns';
import styles from './ResultsSearchPanel.module.scss';
import SearchPanel from '../../../Templates/ResultsSearch/ResultsSearch';
import UI from 'ielts-cmds-ui-component-library';
import { useStateValue } from '../../../../Store/helpers/UseStateValue';
import NoResultsFound from '../../../Molecules/NoResultsFound/NoResultsFound';
import withServiceRequest, { ServiceRequest } from '../../../../services/utils/ServiceRequest';
import { RouteComponentProps } from 'react-router-dom';
import { languageService } from '../../../../services/Language/LanguageService';
import {
  AdvancedResultSearchCriteria,
  BasicResultSearchCriteria,
  BookingDetailStatus,
  BookingStatus,
  ResultsBookingResponse,
  ResultsReqBodySearchPayload,
  ResultDataError,
} from '../../../../services/Models/Result';
import ResultStatusDropDown from '../../../Organisms/BaseDropDown/ResultStatusDropDown/ResultStatusDropDown';
import ResultsGrid, { ColumnSort } from '../../../Organisms/ResultsGrid/ResultsGrid';
import { pageSizeOptions } from '../../../Organisms/ManageUsersGrid/ManageUsersGridConstants';
import { bookingsSearch } from '../../../../services/API/Result/Booking';
import * as ManageResultActions from '../../../../Store/Actions/ManageResultActions';
import { useEffectUpdate, transformRequestValueFromString } from '../../../utils/utilities';
import * as manageResultsSearchType from '../../../../constants/ManageResultsSearchType';
import * as BreadCrumbActions from '../../../../Store/Actions/BreadCrumbActions';
import { DEFAULT_TOAST_MESSAGE_TIMER } from '../../../../constants/GlobalConstants';
import { FormStepRule, Dictionary, DropDownType } from '../../../../services/Models/UIModels';
import { FormValidation } from '../../../utils/FormValidation';
import { ResultSearchRules } from '../../../utils/ValidationRules/ResultSearchForm';
import { initialOnHoldInputValue } from './ResultsSearchPanelConstants';
import PartnerDropDown, { Partner } from '../../../Organisms/BaseDropDown/PartnerDropDown/PartnerDropDown';

interface ResultsSearchPanelProps extends RouteComponentProps {
  serviceRequest: ServiceRequest;
  initialBasicSearchData?: BasicResultSearchCriteria;
  initialAdvancedSearchData?: AdvancedResultSearchCriteria;
}

export const initialBasicSearchData: BasicResultSearchCriteria = {
  dateRange: {
    startDate: undefined,
    endDate: undefined,
  },
  testCentre: [],
  product: [],
};

export const initialAdvancedSearchData: AdvancedResultSearchCriteria = {
  lastName: '',
  firstName: '',
  identityNumber: '',
  resultStatus: undefined,
  testTakerNumber: '',
  uniqueTestTakerId: '',
  onHold: undefined,
  partnerCodeList: undefined,
};

export interface dateRange {
  startDate: Date;
  endDate: Date;
}

interface IErrorField {
  [key: string]: string;
}

export interface IBookingResults {
  [bookingUuid: string]: ResultsBookingResponse;
}
export type OnHoldInputData = {
  checked: boolean;
  label: string;
  value?: boolean | undefined;
};

const ResultsSearchPanel = (props: ResultsSearchPanelProps) => {
  const isFromSearchClick = useRef(false);
  const selectedSearchType = useRef('');

  const resultLabels = languageService().result;
  const commonLabels = languageService().common;

  const [basicSearchData, setBasicSearchData] = useState(props.initialBasicSearchData || initialBasicSearchData);
  const [advancedSearchData, setAdvancedSearchData] = useState(
    props.initialAdvancedSearchData || initialAdvancedSearchData,
  );
  const [initialOpenState, setInitialOpenState] = useState(false);
  const [isClearBasicSearch, setClearBasicSearch] = useState(false);
  const [isClearAdvancedSearch, setClearAdvancedSearch] = useState(false);
  const [isSentForm, setIsSentForm] = useState(false);
  const [isSearchResults, setSearchResults] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [fieldErrors, setFieldErrors] = useState({} as IErrorField);
  const { state, dispatch } = useStateValue();

  const [currentSelectedPage, setCurrentSelectedPage] = useState({ page: 1 });
  const [currentSelectedPageSize, setCurrentSelectedPageSize] = useState(pageSizeOptions[0].value);
  const [selectedSortOption, setSelectedSortOption] = useState({
    sortType: 'ASC',
    sortBy: 'firstName',
  });

  const [holdOnSearchInput, setHoldOnSearchInput] = useState<OnHoldInputData>(initialOnHoldInputValue);
  const [isLoading, setLoading] = useState(false);

  const setOnHoldInputField = (onHold: boolean | undefined) => {
    let onHoldData: OnHoldInputData = initialOnHoldInputValue;
    if (onHold) {
      onHoldData = { ...onHoldData, label: resultLabels.showHoldOnSearchText, value: true };
    } else if (onHold === false) {
      onHoldData = {
        ...onHoldData,
        label: resultLabels.hideHoldOnSearchText,
        value: false,
      };
    }
    setHoldOnSearchInput(onHoldData);
  };
  useEffect(() => {
    dispatch({ type: BreadCrumbActions.SHOW_BACK, payload: true });
    const { searchName, body, selectedPage, selectedPageSizeIndex, sortOption } = state?.manageResult?.searchData || {};
    if (searchName !== '' && body) {
      isFromSearchClick.current = true;
      setCurrentSelectedPage(selectedPage);
      setCurrentSelectedPageSize(pageSizeOptions[selectedPageSizeIndex].value);
      setSelectedSortOption(sortOption);
      updateUI(searchName, body);
      getResultsSearchResults(searchName, body, false);
    }
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const updateUI = (searchName: string, body: ResultsReqBodySearchPayload) => {
    const { criteria } = body;
    setBasicSearchData({
      dateRange: {
        startDate: new Date(criteria.timeRange.startTime),
        endDate: new Date(criteria.timeRange.endTime),
      },
      testCentre: criteria.testCentreUuidList || [],
      product: criteria.productUuidList || [],
    });
    setClearBasicSearch(true);
    if (searchName === manageResultsSearchType.ADVANCE) {
      setAdvancedSearchData({
        lastName: criteria.lastName,
        firstName: criteria.firstName,
        identityNumber: criteria.identityNumber,
        resultStatus: criteria.resultStatusUuid,
        testTakerNumber: criteria.shortCandidateNumber,
        uniqueTestTakerId: criteria.uniqueTestTakerId,
        onHold: criteria.onHold,
        partnerCodeList: criteria.partnerCodeList,
      });
      setOnHoldInputField(criteria.onHold);
      setInitialOpenState(true);
      setClearAdvancedSearch(true);
    }
  };

  useEffectUpdate(() => {
    if (!isFromSearchClick.current) {
      const { searchName } = state.manageResult.searchData;
      const name = searchName || manageResultsSearchType.DEFAULT;
      const reqBody = getSearchRequestBody();
      getResultsSearchResults(name, reqBody as ResultsReqBodySearchPayload);
    } else if (isFromSearchClick.current && selectedSearchType.current !== '') {
      const reqBody = getSearchRequestBody();
      getResultsSearchResults(selectedSearchType.current, reqBody as ResultsReqBodySearchPayload);
      selectedSearchType.current = '';
    }
  }, [currentSelectedPage]);

  const getSortingElement = (sortBy: string, sortType: string) => ({ sortBy, sortType });
  const onChangeOnHold = (e: OnHoldInputData) => {
    let onHoldSearchInputValue: boolean | undefined;
    if (e.label === resultLabels.showHoldOnSearchText) {
      onHoldSearchInputValue = true;
    } else if (e.label === resultLabels.hideHoldOnSearchText) {
      onHoldSearchInputValue = false;
    } else {
      onHoldSearchInputValue = undefined;
    }
    const onHoldSearchInput = { ...e, value: onHoldSearchInputValue };

    setHoldOnSearchInput(onHoldSearchInput);
  };

  const getSearchRequestBody = () => {
    const sorting = Array.isArray(selectedSortOption.sortBy)
      ? selectedSortOption.sortBy.map((sortBy) => getSortingElement(sortBy, selectedSortOption.sortType))
      : [getSortingElement(selectedSortOption.sortBy, selectedSortOption.sortType)];

    // transform time range to correct UTC times
    let utcStartDate;
    let utcEndDate;
    if (basicSearchData && basicSearchData.dateRange && basicSearchData.dateRange.startDate) {
      const startTimeOffset = basicSearchData.dateRange.startDate.getTimezoneOffset();
      utcStartDate = addMinutes(basicSearchData.dateRange.startDate as Date, -startTimeOffset);
    }
    if (basicSearchData && basicSearchData.dateRange && basicSearchData.dateRange.endDate) {
      const endTimeOffset = basicSearchData.dateRange.endDate.getTimezoneOffset();
      utcEndDate = addMinutes(basicSearchData.dateRange.endDate, -endTimeOffset);
    }
    return {
      criteria: {
        firstName: transformRequestValueFromString(advancedSearchData.firstName),
        identityNumber: transformRequestValueFromString(advancedSearchData.identityNumber),
        lastName: transformRequestValueFromString(advancedSearchData.lastName),
        productUuidList: basicSearchData.product,
        resultStatusUuid: transformRequestValueFromString(advancedSearchData.resultStatus),
        testCentreUuidList: basicSearchData.testCentre,
        partnerCodeList: advancedSearchData.partnerCodeList,
        shortCandidateNumber: advancedSearchData.testTakerNumber
          ? transformRequestValueFromString(Number(advancedSearchData.testTakerNumber).toString())
          : undefined,
        timeRange: {
          startTime: transformRequestValueFromString(utcStartDate?.toISOString()),
          endTime: transformRequestValueFromString(utcEndDate?.toISOString()),
        },
        uniqueTestTakerId: transformRequestValueFromString(advancedSearchData.uniqueTestTakerId),
        bookingStatus: BookingStatus.PAID,
        bookingDetailStatus: BookingDetailStatus.COMPLETE,
        isVoid: false,
        onHold: holdOnSearchInput.value,
      },
      pagination: {
        pageNumber: currentSelectedPage.page - 1,
        pageSize: currentSelectedPageSize,
      },
      sorting,
    };
  };

  const getResultsSearchResults = (name: string, body: ResultsReqBodySearchPayload, shouldUpdateState = true) => {
    const selectedPageSizeIndex = pageSizeOptions.findIndex((option) => option.value === currentSelectedPageSize);
    setLoading(true);
    if (shouldUpdateState) {
      dispatch({
        type: ManageResultActions.SEARCH,
        payload: {
          body,
          searchName: name,
          selectedPage: currentSelectedPage,
          selectedPageSizeIndex,
          sortOption: selectedSortOption,
        },
      });
    }
    bookingsSearch(body, props.serviceRequest).subscribe((data) => {
      setLoading(false);
      if (!data) return;
      const gridData = data.gridData || [];
      const totalRecords = data.totalCount || 0;
      dispatch({
        type: ManageResultActions.SEARCH_SUCCESS,
        payload: { totalCount: totalRecords, searchResultsData: gridData },
      });
      setSearchResults(totalRecords > 0);
    });
  };

  const onRemoveErrorMessage = () => {
    setErrorMessage('');
  };

  const renderErrorMessage = () => (
    <div className={styles.toastMessage} id="toast_panel_results_error_container">
      <UI.Message
        id="toast_panel_results_error"
        color="error"
        dismissable
        onChange={onRemoveErrorMessage}
        visibleTill={5000}
      >
        {<label id="toast_panel_results_error_msg">{errorMessage}</label>}
      </UI.Message>
    </div>
  );

  const onPageChangeHandler = (page: number) => {
    isFromSearchClick.current = false;
    setCurrentSelectedPage({ page: page + 1 });
  };

  const onPageSizeChangeHandler = (value: number) => {
    setCurrentSelectedPageSize(value);
    isFromSearchClick.current = false;
    setCurrentSelectedPage({ page: 1 });
  };

  const onColumnSortHandler = (column: ColumnSort) => {
    let sortType;
    if (JSON.stringify(selectedSortOption.sortBy) === JSON.stringify(column.Header.name)) {
      sortType = selectedSortOption.sortType === 'ASC' ? 'DESC' : 'ASC';
    } else {
      sortType = 'ASC';
    }
    const sortOption = {
      sortBy: column.Header.name,
      sortType,
    };
    setSelectedSortOption(sortOption);
    isFromSearchClick.current = false;
    setCurrentSelectedPage({ page: 1 });
  };

  const getResultsGrid = () => {
    const gridState = {
      totalRecords: state?.manageResult?.searchResult?.totalCount,
      initialState: {
        pageSize: currentSelectedPageSize,
      },
      selectedPage: currentSelectedPage.page,
      selectedOptionValue: currentSelectedPageSize,
    };
    return (
      <div className={styles.searchResults}>
        <ResultsGrid
          data={state.manageResult.searchResultsData || []}
          onPageChange={onPageChangeHandler}
          onPageSizeChange={onPageSizeChangeHandler}
          gridState={gridState}
          pageSizeOptions={pageSizeOptions}
          onColumnSort={onColumnSortHandler}
          sortOption={selectedSortOption}
          sort={true}
          isLoading={isLoading}
        />
      </div>
    );
  };

  const handleBasicInputChange = (key: string, value: string | dateRange) => {
    setClearBasicSearch(true);
    setBasicSearchData({ ...basicSearchData, [key]: value });
    setIsSentForm(false);
  };

  const handleAdvancedInputChange = (key: string, value: string | dateRange) => {
    setClearAdvancedSearch(true);
    setAdvancedSearchData({ ...advancedSearchData, [key]: value });
    setIsSentForm(false);
  };

  const onClearSearch = (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>) => {
    event.preventDefault();
    setBasicSearchData(initialBasicSearchData);
    setClearBasicSearch(false);
    setAdvancedSearchData(initialAdvancedSearchData);
    setClearAdvancedSearch(false);
    setHoldOnSearchInput({
      checked: true,
      label: resultLabels.showAllResults,
      value: undefined,
    });
  };

  const onBasicSearchHandler = () => {
    if (validate()) {
      // call sync validation
      setSearchResults(true);
      setIsSentForm(true);
      isFromSearchClick.current = true;
      selectedSearchType.current = manageResultsSearchType.BASIC;
      setCurrentSelectedPage({ page: 1 });
      dispatch({
        type: ManageResultActions.CLEAR_SELECTED_BOOKING,
      });
    }
  };

  const onAdvancedSearchHandler = () => {
    if (validate()) {
      // call sync validation
      setSearchResults(true);
      setIsSentForm(true);
      isFromSearchClick.current = true;
      selectedSearchType.current = manageResultsSearchType.ADVANCE;
      setCurrentSelectedPage({ page: 1 });
      dispatch({
        type: ManageResultActions.CLEAR_SELECTED_BOOKING,
      });
    }
  };

  const getFieldValidation = (fieldName: string) => {
    if (fieldErrors[fieldName]) {
      return {
        isValid: false,
        message: fieldErrors[fieldName],
      };
    } else {
      return {
        isValid: true,
      };
    }
  };

  const getSearchResultError = (
    state: Dictionary,
    rule: FormStepRule,
    isValid = true,
    resultData: ResultDataError = {},
  ) => {
    let isFormvalid = isValid;
    Object.keys(rule).forEach((key) => {
      const resultFormRule = rule[key];
      resultData[key] = FormValidation(state[key] || '', resultFormRule);
      if (!resultData[key].isValid) isFormvalid = false;
    });

    return { isFormvalid, resultData: resultData };
  };
  const validate = () => {
    const {
      dateRange: { startDate, endDate },
    } = basicSearchData;
    let valid = true;
    const resultDataError: ResultDataError = {};
    if (!startDate || !endDate) {
      setErrorMessage(`${commonLabels.requiredFieldmissingMessage('date')}`);
      valid = false;
    }
    const { isFormvalid, resultData } = getSearchResultError(advancedSearchData, ResultSearchRules);
    if (!isFormvalid) {
      Object.keys(resultData).forEach((key) => {
        resultDataError[key] = resultData[key].message;
      });
      setFieldErrors({ ...fieldErrors, ...resultDataError });
      valid = false;
    } else {
      setFieldErrors({});
    }
    return valid;
  };

  const getSuccessMessage = () => {
    return state.manageResult.resultsStatusUpdatedMessage ? (
      <div className={styles.messageContainer}>
        <UI.Message
          message={state.manageResult.resultsStatusUpdatedMessage}
          color="success"
          dismissable
          onChange={() => dispatch({ type: ManageResultActions.CLEAR_RESULTS_TOAST_MESSAGE })}
          visibleTill={DEFAULT_TOAST_MESSAGE_TIMER}
        />
      </div>
    ) : null;
  };
  const getErrorMessage = () => {
    return state.manageResult.resultsStatusUpdatedErrorMessage !== '' ? (
      <div className={styles.messageContainer}>
        <UI.Message
          message={state.manageResult.resultsStatusUpdatedErrorMessage}
          color="error"
          dismissable
          onChange={() => dispatch({ type: ManageResultActions.CLEAR_RESULTS_ERROR_MESSAGE })}
          visibleTill={DEFAULT_TOAST_MESSAGE_TIMER}
        />
      </div>
    ) : null;
  };

  return (
    <>
      {errorMessage ? renderErrorMessage() : null}
      {getSuccessMessage()}
      {getErrorMessage()}
      <SearchPanel
        title={resultLabels.resultTitle}
        titleType="regular"
        titleSize={32}
        subTitle={resultLabels.subTitle}
        subTitleType="regular"
        subTitleSize={20}
        basicSearchData={basicSearchData}
        advancedSearchData={advancedSearchData}
        clearSearchLabel={isClearBasicSearch || isClearAdvancedSearch ? resultLabels.clearSearch : ''}
        basicSearchButtonLabel={resultLabels.searchLabel}
        basicSearchButtonColor="primary"
        onClearSearch={onClearSearch}
        handleBasicInputChange={handleBasicInputChange}
        handleAdvancedInputChange={handleAdvancedInputChange}
        onBasicSearchHandler={onBasicSearchHandler}
        onAdvancedSearchHandler={onAdvancedSearchHandler}
        advanceSearchButtonLabel={resultLabels.searchLabel}
        advanceSearchButtonColor="primary"
        collapseTitle={resultLabels.collapseTitle}
        collapseOpenTitle={resultLabels.collapseTitle}
        collapseFooterTitle={resultLabels.collapseFooterTitle}
        initialOpenState={initialOpenState}
        serviceRequest={props.serviceRequest}
        fetchProductDataOnLoad
        fetchLocationDataOnLoad
      >
        <div className={styles.row}>
          <div className={styles.textBoxWrapper}>
            <div className={styles.textBoxLabel}>{resultLabels.firstNameLabel}</div>
            <UI.TextBox
              id="firstName"
              label=""
              name="firstName"
              placeholder=""
              value={advancedSearchData.firstName}
              onChange={(ev: React.ChangeEvent<HTMLInputElement>) =>
                handleAdvancedInputChange('firstName', ev.target.value)
              }
              inputFieldValidation={getFieldValidation('firstName')}
            />
          </div>
          <div className={styles.textBoxWrapper}>
            <div className={styles.textBoxLabel}>{resultLabels.lastNameLabel}</div>
            <UI.TextBox
              id="lastName"
              label=""
              name="lastName"
              placeholder=""
              value={advancedSearchData.lastName}
              onChange={(ev: React.ChangeEvent<HTMLInputElement>) =>
                handleAdvancedInputChange('lastName', ev.target.value)
              }
              inputFieldValidation={getFieldValidation('lastName')}
            />
          </div>
          <div className={styles.textBoxWrapper}>
            <div className={styles.textBoxLabel}>{resultLabels.testTakerNumberLabel}</div>
            <UI.TextBox
              id="testTakerNumber"
              label=""
              name="testTakerNumber"
              placeholder=""
              value={advancedSearchData.testTakerNumber}
              onChange={(ev: React.ChangeEvent<HTMLInputElement>) =>
                handleAdvancedInputChange('testTakerNumber', ev.target.value)
              }
              inputFieldValidation={getFieldValidation('testTakerNumber')}
            />
          </div>
        </div>
        <div className={styles.row}>
          <div className={styles.textBoxWrapper}>
            <div className={styles.textBoxLabel}>{resultLabels.uniqueTestTakerIdLabel}</div>
            <UI.TextBox
              id="uniqueTestTakerId"
              label=""
              name="uniqueTestTakerId"
              placeholder=""
              value={advancedSearchData.uniqueTestTakerId}
              onChange={(ev: React.ChangeEvent<HTMLInputElement>) =>
                handleAdvancedInputChange('uniqueTestTakerId', ev.target.value)
              }
              inputFieldValidation={getFieldValidation('uniqueTestTakerId')}
            />
          </div>
          <div className={styles.textBoxWrapper}>
            <div className={styles.textBoxLabel}>{resultLabels.idDocumentNumberLabel}</div>
            <UI.TextBox
              id="identityNumber"
              label=""
              name="identityNumber"
              placeholder=""
              value={advancedSearchData.identityNumber}
              onChange={(ev: React.ChangeEvent<HTMLInputElement>) =>
                handleAdvancedInputChange('identityNumber', ev.target.value)
              }
              inputFieldValidation={getFieldValidation('identityNumber')}
            />
          </div>
          <div className={styles.dropdownWrapper}>
            <div className={styles.textBoxLabel}>{resultLabels.resultsStatusLabel}</div>
            <ResultStatusDropDown
              id="resultStatus"
              isFetchDataOnLoad
              isFilterEnabled={false}
              label=""
              labelId="resultStatusLB"
              onChange={(value: string) => handleAdvancedInputChange('resultStatus', value)}
              selectedValue={advancedSearchData?.resultStatus || ''}
              serviceRequest={props.serviceRequest}
            />
          </div>
        </div>
        <div className={styles.row}>
          <div className={styles.productDropdownWrapper}>
            <PartnerDropDown
              id={'partner'}
              labelId={'partnerCodeLbl'}
              label={resultLabels.partner}
              selectedPartner={advancedSearchData?.partnerCodeList}
              isFilterEnabled
              textBoxPlaceHolder={''}
              canUseStoreData
              isFetchDataOnLoad
              serviceRequest={props.serviceRequest}
              hiddenPartner={[Partner.Cambridge, Partner.Global]}
              dropDownType={DropDownType.MULTIPLE}
              onPartnerChange={(value: string) => {
                handleAdvancedInputChange('partnerCodeList', value);
              }}
            />
          </div>
          <div>
            <UI.RadioButton
              checked={holdOnSearchInput.label === resultLabels.showHoldOnSearchText && holdOnSearchInput.checked}
              label={resultLabels.showHoldOnSearchText}
              onChange={onChangeOnHold}
            />
            <UI.RadioButton
              checked={holdOnSearchInput.label === resultLabels.hideHoldOnSearchText && holdOnSearchInput.checked}
              label={resultLabels.hideHoldOnSearchText}
              onChange={onChangeOnHold}
            />
            <UI.RadioButton
              checked={holdOnSearchInput.label === resultLabels.showAllResults && holdOnSearchInput.checked}
              label={resultLabels.showAllResults}
              onChange={onChangeOnHold}
            />
          </div>
          <div className={styles.dropdownWrapper}></div>
        </div>
      </SearchPanel>
      <>
        {isSearchResults || isLoading ? getResultsGrid() : null}
        {!isSearchResults && isSentForm ? (
          <NoResultsFound title={resultLabels.noResultsFoundTitle} description={resultLabels.noResultsFoundDesp} />
        ) : null}
      </>
    </>
  );
};

export default withServiceRequest(ResultsSearchPanel);
