import React from 'react';
import { Switch } from 'react-router-dom';
import Search from '../Results/ResultsSearchPanel/ResultsSearchPanel';
import ResultsTestTakerDetails from './ResultsTestTakerDetails/ResultsTestTakerDetails';
import styles from './Results.module.scss';
import PrivateRoute from '../../../routes/PrivateRoute';
import useFeatureToggle from '../../../services/feature-toggle/UseFeatureToggle';
import ROOT_FEATURE from '../../../services/feature-toggle/feature-types/RootFeature';
import ResultsUpdateStatus from '../ResultsUpdateStatus/ResultsUpdateStatus';
import MultipleResultsUpdateStatus from '../ResultsUpdateStatus/MultipleUpdate/MultipleResultsUpdateStatus';

export default (props: any) => {
  const currentUrl = props.match.url;
  useFeatureToggle(ROOT_FEATURE.results);
  return (
    <div className={styles.container}>
      <Switch>
        <PrivateRoute path={currentUrl + '/updateresultstatus/:id'} component={ResultsUpdateStatus} />
        <PrivateRoute path={currentUrl + '/updateresultsstatus'} component={MultipleResultsUpdateStatus} />
        <PrivateRoute path={currentUrl + '/viewTestTakerDetails/:id'} component={ResultsTestTakerDetails} />
        <PrivateRoute path={currentUrl} component={Search} />
      </Switch>
    </div>
  );
};
