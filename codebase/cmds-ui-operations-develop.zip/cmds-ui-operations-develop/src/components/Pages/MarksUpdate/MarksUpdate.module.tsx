import React, { useState, useEffect } from 'react';
import styles from './MarksUpdate.module.scss';
import UI from 'ielts-cmds-ui-component-library';
import cx from 'classnames';
import { useAuth0 } from '@auth0/auth0-react';
import { useStateValue } from '../../../Store/helpers/UseStateValue';
import { updateRequestedComponentMarks, getSearchedMarks } from '../../../services/API/MarkManager/MarkManager';
import { MarkModel, marks } from '../../../services/API/MarkManager/MarkModel';
import * as BreadCrumbActions from '../../../Store/Actions/BreadCrumbActions';
import { languageService } from '../../../services/Language/LanguageService';
import { useLocation } from 'react-router-dom';
import withServiceRequest, { ServiceRequest } from '../../../services/utils/ServiceRequest';
import { AsyncResponseStatus } from '../../../services/Models/Api';

interface MarksUpdatePageProps {
  serviceRequest: ServiceRequest;
}

const MarksUpdate = (props: MarksUpdatePageProps) => {
  const { dispatch } = useStateValue();
  const [component, setComponent] = useState('');
  const [accessToken, setAccessToken] = useState('');
  const { isAuthenticated, getAccessTokenSilently } = useAuth0();
  const [response, setResponse] = useState<string>();
  const [errorMessage, setErrorMessage] = useState<string>();
  const [marksSearch, setMarksSearch] = useState<MarkModel[]>([]);
  const [writingTaskNumber] = useState('');
  const [examinerIdStatus, setExaminerIdStatus] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const marksUpdateLabels = languageService().marksUpdate;
  const location = useLocation();
  const { candidateCompositeNumber } = location.state || '';
  const [candidateNumber, setCandidateNumber] = useState(candidateCompositeNumber);
  const DEFAULT_TOAST_MESSAGE_TIMER = 15000;

  useEffect(() => {
    dispatch({ type: BreadCrumbActions.SHOW_BACK, payload: true });
    const getAccessToken = async () => {
      if (isAuthenticated) {
        const token = await getAccessTokenSilently({ audience: process.env.REACT_APP_REST_BASE_AUDIENCE });
        if (token !== undefined) {
          setAccessToken(token);
        }
      }
    };
    getAccessToken();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated, accessToken]);

  useEffect(() => {
    dispatch({ type: BreadCrumbActions.SHOW_BACK, payload: true });
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onMarksChange = (e: any, parentIndex: number, childIndex: number) => {
    const { value } = e.target;
    if ((component === 'L' || component === 'R') && (value.toString().length > 1 || value < 0 || value > 1)) {
      return;
    }
    if ((component === 'W' && value.toString().length > 3) || value < 0 || value > 9) {
      return;
    }
    if (value.toString().includes('00')) {
      return;
    }
    const marksList: MarkModel[] = [...marksSearch];
    let total = 0;
    marksList[parentIndex].marks?.map((mark: marks, i: number) => {
      if (i === childIndex) {
        mark.markValue = +value;
      }
    });
    marksList[parentIndex].marks?.map((mark: marks) => {
      if (mark.markValue !== undefined && mark.markValue > 0) {
        total += +mark.markValue;
      }
    });
    marksList[parentIndex].testComponentInfo.componentTotal = total;
    console.log('markList ', marksList);
    setMarksSearch(marksList);
  };

  const searchMarksByCandidateNumber = async () => {
    if (!candidateNumber || !component) {
      setErrorMessage('Please enter valid candidate number or component!');
      return;
    }
    setIsLoading(true);
    const request = {
      candidateNumber: candidateNumber,
      component: component,
      writingTaskNumber: '',
    };
    if (writingTaskNumber) {
      request.writingTaskNumber = writingTaskNumber;
    }
    getSearchedMarks(request, props.serviceRequest).subscribe(
      (response: { marks: any; status: AsyncResponseStatus }) => {
        setIsLoading(false);
        setMarksSearch(response.marks);
      },
    );
  };
  const updateMarks = async () => {
    if (examinerIdStatus) {
      window.scrollTo(0, 0);
      setErrorMessage('Please enter valid examiner id');
      return;
    }
    const request = {
      updatedMarks: marksSearch,
    };
    updateRequestedComponentMarks(request, props.serviceRequest).subscribe(
      (response: { marks: any; status: AsyncResponseStatus }) => {
        if (response.marks && response.status !== 'error') {
          setResponse('Candidate Marks has been successfully updated');
        }
      },
    );
  };

  const onComponentChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setMarksSearch([]);
    setComponent(e.toString());
  };

  const onExaminerId1Change = (e: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const { value } = e.target;
    const marksList: MarkModel[] = [...marksSearch];
    if (!value) {
      setExaminerIdStatus(true);
    } else {
      setExaminerIdStatus(false);
    }
    marksList[index].examinerId1 = value;
    setMarksSearch(marksList);
  };

  const onExaminerId2Change = (e: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const { value } = e.target;
    const marksList: MarkModel[] = [...marksSearch];
    if (!value) {
      setExaminerIdStatus(true);
    } else {
      setExaminerIdStatus(false);
    }
    marksList[index].examinerId2 = value;
    setMarksSearch(marksList);
  };

  return (
    <>
      <div className={styles.marksUpdateMain}>
        <div className="marksUpdateForm">
          {response && (
            <UI.Message
              message={response}
              color="success"
              dismissable
              visibleTill={DEFAULT_TOAST_MESSAGE_TIMER}
              onChange={() => setResponse('')}
            />
          )}
          {errorMessage && (
            <UI.Message
              message={errorMessage}
              color="error"
              dismissable
              visibleTill={DEFAULT_TOAST_MESSAGE_TIMER}
              onChange={() => setErrorMessage('')}
            />
          )}
          <div className={styles.TitleContainer}>
            <div className={styles.TitleLeftSide}>
              <div className={styles.Title}>
                <UI.Typography label={marksUpdateLabels.title} size={24} type="regular" id="testTakerTitle" />
              </div>
            </div>
          </div>
          <div className={styles.markDetails}>
            <div className={styles.SubTitle}>
              <UI.Typography label={marksUpdateLabels.subtitle} size={18} id="testTakerSubTitle" type="regular" />
            </div>
            <hr style={{ marginBottom: '15px' }} />
            <div className={styles.marksForm}>
              <div className={cx(styles.col3, styles.markInputContainer, styles.ogGridPadding)}>
                <label htmlFor="candidateNumber">{marksUpdateLabels.candidateCompositeLabel}</label>
                <UI.TextBox
                  label={''}
                  labelId={''}
                  value={candidateNumber}
                  inputDisabled={true}
                  name={'candidateNumber'}
                  id={'CandidateNumber'}
                  placeholder="Please Enter"
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCandidateNumber(e.target.value)}
                />
              </div>
              <div className={cx(styles.col3, styles.markInputContainer, styles.ogGridPadding)}>
                <label htmlFor="candidateNumber">{marksUpdateLabels.componentLabel}</label>
                <UI.Dropdown
                  selectedValue={component}
                  placeholder={'Please Select'}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => onComponentChange(e)}
                  list={[
                    { text: 'Reading', value: 'R' },
                    { text: 'Writing', value: 'W' },
                    { text: 'Listening', value: 'L' },
                  ]}
                />
              </div>
              <div className={cx(styles.col3, styles.ogFormGrid, styles.ogGridPadding)}>
                <>
                  <div></div>
                </>
              </div>
            </div>
          </div>
          <div className={styles.markButton}>
            <UI.Button
              label={'Retrieve Marks'}
              onChange={searchMarksByCandidateNumber}
              color="blueLine"
              id="retrieveMarks"
            />
          </div>
          {isLoading ? (
            <UI.Spinner />
          ) : (
            <div>
              {marksSearch &&
                marksSearch.length > 0 &&
                marksSearch.map((ms: MarkModel, parentIndex) => (
                  <div className={styles.searchResults} key={parentIndex}>
                    <div className={styles.topTableGrid}>
                      {ms.testComponentInfo?.component === 'W' &&
                        (ms.marks && ms.marks[ms.marks.length - 1].markReference === '4' ? (
                          <h2>Writing Task 1</h2>
                        ) : (
                          <h2>Writing Task 2</h2>
                        ))}
                      <table className={styles.topStyledTable}>
                        <thead>
                          <tr>
                            {ms.testComponentInfo.component === 'W' && <th>Examiner Id</th>}
                            <th>Mark Type</th>
                            <th>Test Format</th>
                            <th>Candidate Marks Status</th>
                            <th>Component Total</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr key={parentIndex}>
                            {ms.marks && ms.marks.length > 0 && component === 'W' && (
                              <>
                                {ms.marks &&
                                ms.marks.length > 0 &&
                                ms.marks[ms.marks.length - 1].markReference === '4' ? (
                                  <td>
                                    <input
                                      type="text"
                                      onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                                        onExaminerId1Change(e, parentIndex)
                                      }
                                      value={ms.examinerId1}
                                      readOnly={!ms.examinerId1 && !examinerIdStatus}
                                    />
                                  </td>
                                ) : (
                                  <td>
                                    <input
                                      type="text"
                                      onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                                        onExaminerId2Change(e, parentIndex)
                                      }
                                      value={ms.examinerId2}
                                      readOnly={!ms.examinerId2 && !examinerIdStatus}
                                    />
                                  </td>
                                )}
                              </>
                            )}
                            <td>{ms.testComponentInfo.markType}</td>
                            <td>{ms.testInfo.testFormat}</td>
                            <td>{ms.candidateMarksStatus}</td>
                            <td>{ms.testComponentInfo.componentTotal}</td>
                          </tr>
                        </tbody>
                      </table>
                      <table className={styles.styledTable}>
                        <thead>
                          <tr>
                            <th>Mark Reference</th>
                            <th>Shared Question ID</th>
                            <th>Mark Value</th>
                          </tr>
                        </thead>
                        <tbody>
                          {ms.marks &&
                            ms.marks.length > 0 &&
                            ms.marks.map(
                              (mark: marks, childIndex) =>
                                mark.sharedQuestionId && (
                                  <tr key={childIndex + 4}>
                                    <td>{mark.markReference}</td>
                                    <td>{mark.sharedQuestionId}</td>
                                    <td>
                                      <input
                                        type="number"
                                        min={0}
                                        step={'0'}
                                        value={mark.markValue}
                                        onInput={(e: React.ChangeEvent<HTMLInputElement>) =>
                                          onMarksChange(e, parentIndex, childIndex)
                                        }
                                        onKeyDown={(evt) =>
                                          (evt.key === 'e' || evt.key === '+' || evt.key === '-' || evt.key === '.') &&
                                          evt.preventDefault()
                                        }
                                      />
                                    </td>
                                  </tr>
                                ),
                            )}
                        </tbody>
                      </table>
                      {parentIndex === 0 && component === 'W' && <hr style={{ marginTop: '40px' }} />}
                    </div>
                  </div>
                ))}
              {marksSearch && marksSearch.length > 0 && (
                <div className={cx(styles.col3, styles.ogFormGrid, styles.ogGridPadding)}>
                  <div></div>
                  <div></div>
                  <div className={styles.submitMarks}>
                    <UI.Button label={'Update Marks'} onChange={updateMarks} color="blueLine" id="updateMarks" />
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default withServiceRequest(MarksUpdate);
