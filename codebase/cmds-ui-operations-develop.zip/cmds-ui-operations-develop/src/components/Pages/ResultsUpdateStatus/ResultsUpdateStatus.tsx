import React, { useState, useEffect } from 'react';
import styles from './ResultsUpdateStatus.module.scss';
import cx from 'classnames';
import { useStateValue } from '../../../Store/helpers/UseStateValue';
import * as BreadCrumbActions from '../../../Store/Actions/BreadCrumbActions';
import ResultsStatusHeader from '../../Organisms/ResultsStatusHeader/ResultsStatusHeader';
import FormTitle from '../../Organisms/ManageUserFormHeader/ManageUserFormHeader';
import UI from 'ielts-cmds-ui-component-library';
import { useParams, useHistory, useLocation } from 'react-router-dom';
import * as ManageResultActions from '../../../Store/Actions/ManageResultActions';
import { ResultsUpdateStatusData } from '../../../services/Models/Result';
import withServiceRequest, { ServiceRequest } from '../../../services/utils/ServiceRequest';
import { languageService, formatLanguageString } from '../../../services/Language/LanguageService';
import ResultsUpdateStatusConfirmationModal from '../../Others/ResultsUpdateStatusConfirmationModal/ResultsUpdateStatusConfirmationModal';
import { updateResultStatuses } from '../../../services/API/Result/ResultUpdateStatus';
import { getBookingResults } from '../../../services/API/Result/Booking';
import { AsyncResponseStatus } from '../../../services/Models/Api';
import ResultsStatusUpdateForm from '../../Organisms/ResultStatusUpdateForm/ResultsStatusUpdateForm';
import { RouteParams } from '../../../services/Models/UIModels';

export const initialResultsUpdateStatusData: ResultsUpdateStatusData = {
  resultStatusTypeUuid: '',
  resultStatusLabelUuid: undefined,
  resultStatusCommentUuid: undefined,
  resultStatusCommentText: undefined,
};

interface ResultsUpdateStatusProps {
  serviceRequest: ServiceRequest;
  initialResultsUpdateStatusData: ResultsUpdateStatusData;
}

const ResultsUpdateStatus = (props: ResultsUpdateStatusProps) => {
  const { state, dispatch } = useStateValue();
  const history = useHistory();
  const resultLabels = languageService().result;
  const [resultsUpdateStatusData, setResultsUpdateStatusData] = useState(
    props.initialResultsUpdateStatusData || initialResultsUpdateStatusData,
  );
  const [hideTextarea, setHideTextarea] = useState(true);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const { id } = useParams<RouteParams>();
  const location = useLocation();
  const { resultsStatusData } = location.state || '';
  const [isUpdateCriteriaValid, setUpdateCriteriaValid] = useState(true);

  const fetchResultsUpdateStatusData = () => {
    if (id) {
      getBookingResults(id, props.serviceRequest).subscribe((data) => {
        if (data.status === AsyncResponseStatus.SUCCESS) {
          const resultsUpdateStatusData = {
            resultStatusTypeUuid: undefined,
            resultStatusLabelUuid:
              data.bookingResults.bookingDetails.currentResultStatus?.resultStatusLabelUuid || undefined,
            resultStatusCommentUuid:
              data.bookingResults.bookingDetails.currentResultStatus?.resultStatusCommentUuid || undefined,
            resultStatusCommentText:
              data.bookingResults.bookingDetails.currentResultStatus?.resultStatusComment || undefined,
          };
          setResultsUpdateStatusData(resultsUpdateStatusData);
        }
      });
    }
  };

  const resultsStatusHeaderData = {
    firstName: resultsStatusData.firstName,
    lastName: resultsStatusData.lastName,
    testCentre: resultsStatusData.testCentre,
    testDate: resultsStatusData.testDate,
    shortCandidateNumber: resultsStatusData.shortCandidateNumber,
    resultStatus: resultsStatusData.resultStatus,
  };

  useEffect(() => {
    dispatch({ type: BreadCrumbActions.SHOW_BACK });
    fetchResultsUpdateStatusData();
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleCancel = () => {
    history.push('/results');
  };

  const handleUpdate = () => {
    if (resultsUpdateStatusData.resultStatusTypeUuid) {
      setUpdateCriteriaValid(true);
      setShowConfirmation(true);
    } else {
      setUpdateCriteriaValid(false);
    }
  };

  const handleResultsStatusUpdateConfirmationCancel = () => {
    setShowConfirmation(false);
  };

  const handleResultsStatusUpdateConfirmation = () => {
    const testTakerName = resultsStatusHeaderData.firstName + ' ' + resultsStatusHeaderData.lastName;
    updateResultStatuses(resultsUpdateStatusData, props.serviceRequest, id).subscribe((res) => {
      if (res && res.status === AsyncResponseStatus.SUCCESS) {
        const resultStatus = state.referenceData.resultStatus?.transformedData?.find(
          (status: { resultsStatusTypeUuid: string }) =>
            status.resultsStatusTypeUuid === resultsUpdateStatusData?.resultStatusTypeUuid,
        )?.resultsStatusType;
        const userKeys = { testTakerName: testTakerName, bookingId: id, resultStatus: resultStatus };
        const updateLabel = resultLabels.resultsUpdateStatusToastMessage;
        const message = formatLanguageString(updateLabel, userKeys);
        history.push('/results');
        dispatch({ type: ManageResultActions.RESULTS_UPDATE_MESSAGE, payload: message });
      }
    });
    setShowConfirmation(false);
  };

  const handleInputChange = (key: string, value: string) => {
    if (key === 'resultStatusCommentText') {
      resultsUpdateStatusData.resultStatusCommentUuid = undefined;
      resultsUpdateStatusData[key] = value;
      setResultsUpdateStatusData({ ...resultsUpdateStatusData });
    } else if (key === 'resultStatusCommentUuid') {
      resultsUpdateStatusData.resultStatusCommentText = undefined;
      resultsUpdateStatusData[key] = value || undefined;
      setResultsUpdateStatusData({ ...resultsUpdateStatusData });
    } else if (key === 'resultStatusTypeUuid') {
      resultsUpdateStatusData.resultStatusLabelUuid = undefined;
      resultsUpdateStatusData.resultStatusCommentUuid = undefined;
      resultsUpdateStatusData[key] = value;
      setResultsUpdateStatusData({ ...resultsUpdateStatusData });
    } else {
      setResultsUpdateStatusData({ ...resultsUpdateStatusData, [key]: value || undefined });
    }
  };

  const handleClick = () => {
    setHideTextarea(!hideTextarea);
    setResultsUpdateStatusData({ ...resultsUpdateStatusData, resultStatusCommentText: '' });
  };

  const getConfirmationDialog = () => {
    return showConfirmation ? (
      <ResultsUpdateStatusConfirmationModal
        resultsStatusData={resultsUpdateStatusData}
        headerText={resultLabels.confirmationModalHeaderText}
        titleText={resultLabels.confirmationModalTitleText}
        cancelHandler={handleResultsStatusUpdateConfirmationCancel}
        confirmHandler={handleResultsStatusUpdateConfirmation}
      />
    ) : null;
  };

  return (
    <div className={cx(styles.formContainer, styles.statusFormConatainer)}>
      {!isUpdateCriteriaValid ? (
        <div className={styles.messageContainer}>
          <UI.Message
            message={resultLabels.updateCriteriaError}
            color="error"
            dismissable
            onChange={() => setUpdateCriteriaValid(true)}
          />
        </div>
      ) : null}
      {getConfirmationDialog()}
      <div className={styles.headerTitle}>
        <FormTitle title={resultLabels.resultsUpdateStatus} pageTitle showMessage={false} showOptionalMessage={false} />
      </div>
      <ResultsStatusHeader resultsStatusData={resultsStatusHeaderData} />
      <ResultsStatusUpdateForm
        handleInputChange={handleInputChange}
        resultsUpdateStatusData={resultsUpdateStatusData}
        hideTextarea={hideTextarea}
        handleClick={handleClick}
        handleCancel={handleCancel}
        handleUpdate={handleUpdate}
      />
    </div>
  );
};

export default withServiceRequest(ResultsUpdateStatus);
