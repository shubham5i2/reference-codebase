import React, { useState, useEffect } from 'react';
import styles from './MultipleResultsUpdateStatus.module.scss';
import cx from 'classnames';
import { useStateValue } from '../../../../Store/helpers/UseStateValue';
import FormTitle from '../../../Organisms/ManageUserFormHeader/ManageUserFormHeader';
import UI from 'ielts-cmds-ui-component-library';
import { useHistory } from 'react-router-dom';
import * as ManageResultActions from '../../../../Store/Actions/ManageResultActions';
import {
  ResultsUpdateStatusData,
  ResultsSearchResult,
  MultipleResultsUpdateStatusData,
} from '../../../../services/Models/Result';
import withServiceRequest, { ServiceRequest } from '../../../../services/utils/ServiceRequest';
import { languageService, formatLanguageString } from '../../../../services/Language/LanguageService';
import ResultsUpdateStatusConfirmationModal from '../../../Others/ResultsUpdateStatusConfirmationModal/ResultsUpdateStatusConfirmationModal';
import ResultsUpdateGrid from '../../../Organisms/ResultsUpdateGrid/ResultsUpdateGrid';
import { AsyncResponseStatus } from '../../../../services/Models/Api';
import { ResultsGridData } from '../../../Organisms/ResultsGrid/ResultsGrid';
import ResultsStatusUpdateForm from '../../../Organisms/ResultStatusUpdateForm/ResultsStatusUpdateForm';
import { updateResultStatuses } from '../../../../services/API/Result/ResultUpdateStatus';

export const initialResultsUpdateStatusData: ResultsUpdateStatusData = {
  resultStatusTypeUuid: '',
  resultStatusLabelUuid: undefined,
  resultStatusCommentUuid: undefined,
  resultStatusCommentText: undefined,
};

interface ResultsUpdateStatusProps {
  serviceRequest: ServiceRequest;
  initialResultsUpdateStatusData: ResultsUpdateStatusData;
}

const ResultsUpdateStatus = (props: ResultsUpdateStatusProps) => {
  const { state, dispatch } = useStateValue();
  const history = useHistory();
  const resultLabels = languageService().result;
  const [resultsUpdateStatusData, setResultsUpdateStatusData] =
    useState<ResultsUpdateStatusData>(initialResultsUpdateStatusData);

  const [hideTextarea, setHideTextarea] = useState(true);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [isUpdateCriteriaValid, setUpdateCriteriaValid] = useState(true);
  const [isDeleteSuccess, setUpdateDeleteSuccess] = useState(false);
  const [deleteSuccessMessage, setDeleteSuccessMessage] = useState('');
  const handleCancel = () => {
    history.push('/results');
  };
  useEffect(() => {
    if (state.manageResult.selectedBookings.length === 0) {
      history.push('/results');
    }
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const handleUpdate = () => {
    if (resultsUpdateStatusData.resultStatusTypeUuid) {
      setUpdateCriteriaValid(true);
      setShowConfirmation(true);
    } else {
      setUpdateCriteriaValid(false);
    }
  };

  const handleResultsStatusUpdateConfirmationCancel = () => {
    setShowConfirmation(false);
  };

  const handleResultsStatusUpdateConfirmation = () => {
    const bookingUuidList = state.manageResult.selectedBookings.map((item: ResultsGridData) => item.bookingUuid);
    const payload: MultipleResultsUpdateStatusData = {
      bookingUuidList: bookingUuidList,
      targetResultStatus: resultsUpdateStatusData,
    };
    updateResultStatuses(payload, props.serviceRequest, '').subscribe((res: any) => {
      if (res && res.status === AsyncResponseStatus.SUCCESS) {
        setShowConfirmation(false);
        history.push('/results');
        dispatch({ type: ManageResultActions.DELETE_SELECTED_BOOKING, payload: [] });
        window.scrollTo(0, 0);

        if (
          res.resultUpdateStatuses.resultStatusUpdateSummary.passCount !== 0 &&
          res.resultUpdateStatuses.resultStatusUpdateSummary.failureCount === 0
        ) {
          const resultStatus = state.referenceData.resultStatus?.transformedData?.find(
            (status: { resultsStatusTypeUuid: string }) =>
              status.resultsStatusTypeUuid === resultsUpdateStatusData?.resultStatusTypeUuid,
          )?.resultsStatusType;

          const userKeys = { status: resultStatus };
          const updateLabel = resultLabels.multipleResultsStatusUpdateSuccessText;
          const message = formatLanguageString(updateLabel, userKeys);
          dispatch({ type: ManageResultActions.RESULTS_UPDATE_MESSAGE, payload: message });
        } else {
          dispatch({
            type: ManageResultActions.RESULTS_UPDATE_ERROR_MESSAGE,
            payload: resultLabels.multipleResultsStatusUpdateErrorText,
          });
        }
      }
    });
  };

  const handleInputChange = (key: string, value: string) => {
    if (key === 'resultStatusCommentText') {
      resultsUpdateStatusData.resultStatusCommentUuid = undefined;
      resultsUpdateStatusData[key] = value;
      setResultsUpdateStatusData({ ...resultsUpdateStatusData });
    } else if (key === 'resultStatusCommentUuid') {
      resultsUpdateStatusData.resultStatusCommentText = undefined;
      resultsUpdateStatusData[key] = value || undefined;
      setResultsUpdateStatusData({ ...resultsUpdateStatusData });
    } else if (key === 'resultStatusTypeUuid') {
      resultsUpdateStatusData.resultStatusLabelUuid = undefined;
      resultsUpdateStatusData.resultStatusCommentUuid = undefined;
      resultsUpdateStatusData[key] = value;
      setResultsUpdateStatusData({ ...resultsUpdateStatusData });
    } else {
      setResultsUpdateStatusData({ ...resultsUpdateStatusData, [key]: value || undefined });
    }
  };

  // const fetchResultsUpdateStatusData = () => {
  //   setResultsUpdateStatusData({
  //     ...resultsUpdateStatusData,
  //     resultStatusTypeUuid: '',
  //   });
  // };

  const handleClick = () => {
    setHideTextarea(!hideTextarea);
    setResultsUpdateStatusData({ ...resultsUpdateStatusData, resultStatusCommentText: '' });
  };

  const onDeleteBooking = (bookingID: string) => {
    const selectedRecords: ResultsSearchResult[] = [...state.manageResult.selectedBookings];
    const selectedBookings = selectedRecords.filter((item: ResultsSearchResult) => item.bookingUuid !== bookingID);
    const deletedBooking = selectedRecords.filter((item: ResultsSearchResult) => item.bookingUuid === bookingID);
    setUpdateDeleteSuccess(true);
    const userKeys = { firstName: deletedBooking[0].firstName, lastName: deletedBooking[0].lastName };
    const updateLabel = resultLabels.deleteSuccessMessage;
    const message = formatLanguageString(updateLabel, userKeys);
    setDeleteSuccessMessage(message);
    dispatch({ type: ManageResultActions.DELETE_SELECTED_BOOKING, payload: selectedBookings });
  };

  const getConfirmationDialog = () => {
    return showConfirmation ? (
      <ResultsUpdateStatusConfirmationModal
        resultsStatusData={resultsUpdateStatusData}
        headerText={resultLabels.confirmationModalHeaderText}
        titleText={resultLabels.confirmationModalTitleText}
        cancelHandler={handleResultsStatusUpdateConfirmationCancel}
        confirmHandler={handleResultsStatusUpdateConfirmation}
      />
    ) : null;
  };

  return (
    <div className={cx(styles.formContainer, styles.statusFormConatainer)}>
      {!isUpdateCriteriaValid ? (
        <div className={styles.messageContainer}>
          <UI.Message
            message={resultLabels.updateCriteriaError}
            color="error"
            dismissable
            onChange={() => setUpdateCriteriaValid(true)}
          />
        </div>
      ) : null}
      {isDeleteSuccess ? (
        <div className={styles.messageContainer}>
          <UI.Message
            message={deleteSuccessMessage}
            color="success"
            dismissable
            onChange={() => setUpdateDeleteSuccess(false)}
          />
        </div>
      ) : null}
      {getConfirmationDialog()}
      <div className={styles.headerTitle}>
        <FormTitle title={resultLabels.resultsUpdateStatus} pageTitle showMessage={false} showOptionalMessage={false} />
      </div>
      <ResultsUpdateGrid
        isMultipleUpdate={state.manageResult.selectedBookings.length > 0}
        data={state.manageResult.selectedBookings}
        onDeleteBooking={onDeleteBooking}
      />
      <ResultsStatusUpdateForm
        handleInputChange={handleInputChange}
        resultsUpdateStatusData={resultsUpdateStatusData}
        hideTextarea={hideTextarea}
        handleClick={handleClick}
        handleCancel={handleCancel}
        handleUpdate={handleUpdate}
        selectedDataCount={state.manageResult.selectedBookings.length}
      />
    </div>
  );
};

export default withServiceRequest(ResultsUpdateStatus);
