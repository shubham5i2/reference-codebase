import React from 'react';
import { Switch } from 'react-router-dom';
import PrivateRoute from '../../../routes/PrivateRoute';
import ROOT_FEATURE from '../../../services/feature-toggle/feature-types/RootFeature';
import useFeatureToggle from '../../../services/feature-toggle/UseFeatureToggle';
import AddUpdateLocation from './addUpdateLocationPage/addUpdateLocationPage';
import LocationSearch from './LocationSearch/LocationSearch';
import ViewBuildings from './LocationSearch/ViewBuildings/ViewBuildings';
import LocationDetails from '../../Molecules/LocationDetails/LocationDetails';
import { useAuth0 } from '@auth0/auth0-react';
import { isLMPartnerOnlyUser } from './LocationManagementUtils';

//  : use the right type
export default (props: any) => {
  useFeatureToggle(ROOT_FEATURE.locationManagement);
  const { user } = useAuth0();

  console.log({ isUser: !isLMPartnerOnlyUser(user) });

  const userDependentRoutes = () => {
    if (isLMPartnerOnlyUser(user)) {
      return (
        <Switch>
          <PrivateRoute path={'/locationManagement/viewbuildings/viewDetails/:id'} component={LocationDetails} />
          <PrivateRoute path={'/locationManagement/viewbuildings/:id'} component={ViewBuildings} />
          <PrivateRoute path={'/locationManagement/viewlocation/:id'} component={LocationDetails} />
          <PrivateRoute path={currentUrl} component={LocationSearch} />
        </Switch>
      );
    }
    return (
      <Switch>
        <PrivateRoute path={'/locationManagement/viewbuildings/:id/updatelocation/:id'} component={AddUpdateLocation} />
        <PrivateRoute path={'/locationManagement/viewbuildings/viewDetails/:id'} component={LocationDetails} />
        <PrivateRoute path={'/locationManagement/viewbuildings/:id'} component={ViewBuildings} />
        <PrivateRoute path={'/locationManagement/viewlocation/:id'} component={LocationDetails} />
        <PrivateRoute path={'/locationManagement/addlocation'} component={AddUpdateLocation} />
        <PrivateRoute path={'/locationManagement/updatelocation/:id'} component={AddUpdateLocation} />
        <PrivateRoute path={currentUrl} component={LocationSearch} />
      </Switch>
    );
  };

  const currentUrl = props.match.url;
  return <div>{userDependentRoutes()}</div>;
};
