import React, { useState, useEffect, useRef } from 'react';
import UI from 'ielts-cmds-ui-component-library';
import styles from './addUpdateLocationPage.module.scss';
import LocationDeatils from '../../../Organisms/TestCenterLocation/LocationDetails/LocationDetails';
import { languageService, formatLanguageString } from '../../../../services/Language/LanguageService';
import FooterButtons from '../../../Molecules/FooterButtons/FooterButtons';
import {
  LocationDetailsData,
  AddressFormEvent,
  AddressData,
  LocationFormEvent,
  ProductAuthorization,
  AddressErrorField,
  AddressFormRule,
  LocationType,
  AddressFormElements,
  ProductSelectEvent,
  LocationFormRule,
  LocationManagementForm,
  LocationDetailControl,
  LocationStatus,
} from '../../../../services/Models/LocationManagement';
import {
  initialLocationDetailsData,
  initialAddressData,
  initialAddressErrorData,
  LocationtDataError,
  defaultOldAuthProd,
  currentdate,
} from '../../../../constants/LocationManagement/LocationConstants';
import { useStateValue } from '../../../../Store/helpers/UseStateValue';
import LocationAddressPanel from '../../../Organisms/LocationAddressPanel/LocationAddressPanel';
import withServiceRequest, { ServiceRequest } from '../../../../services/utils/ServiceRequest';
import { FormValidation } from '../../../utils/FormValidation';
import { locationAddressFormRules } from '../../../utils/ValidationRules/LocationForm';
import { showOtherDetails } from '../LocationManagementUtils';
import SelectProduct from '../../../Organisms/SelectProduct/SelectProduct';
import { Dictionary, UIButtonType, FormRule, RouteParams } from '../../../../services/Models/UIModels';
import addLocationFormRules from '../../../utils/ValidationRules/LocationAddForm';
import ToastMessage, { Mode, Position } from '../../../Organisms/ToastMessage/ToastMessage';
import { DEFAULT_TOAST_MESSAGE_TIMER } from '../../../../constants/GlobalConstants';
import GenericPopup, { TitlePosition, ButtonPosition, DialogType } from '../../../Organisms/GenericPopup/GenericPopup';
import {
  addUpdateLocationDetails,
  createAddressData,
  getProductAuth,
  getProductsAuthPayload,
} from '../../../../services/API/LocationManagement/addLocation';
import * as BreadCrumbActions from '../../../../Store/Actions/BreadCrumbActions';
import { AsyncResponseStatus } from '../../../../services/Models/Api';
import { useHistory, useParams } from 'react-router-dom';
import { useEffectUpdate } from '../../../utils/utilities';
import { getLocation } from '../../../../services/API/LocationManagement/ViewLocation';

interface LocationInfoDetailsProps {
  serviceRequest: ServiceRequest;
}

export type OldAuthProd = {
  activeProd: ProductAuthorization[];
  inActiveProd: ProductAuthorization[];
};

const AddUpdateLocation = (props: LocationInfoDetailsProps) => {
  const locationLabels = languageService().locationManagement;
  const [locationDetailsData, setLocationDetailsdata] = useState<LocationDetailsData>(initialLocationDetailsData);
  const [addressData, setAddressData] = useState<AddressData[]>(initialAddressData);
  const [selectedProducts, setSelectedProducts] = useState<ProductAuthorization[]>([]);
  const [oldSelectedProducts, setOldSelectedProducts] = useState<OldAuthProd>(defaultOldAuthProd);

  const [isSameAsPostal, setIsSameAsPostal] = useState<boolean>(false);
  const [addressFieldErrors, setAddressFieldErrors] = useState(initialAddressErrorData as AddressErrorField[]);
  const [locationFieldError, setLocationFieldError] = useState({} as LocationtDataError);
  const [showToastError, setShowToastErrorMessage] = useState(false);
  const [showConfirmationDialog, setShowConfirmationDialog] = useState(false);
  const [formType, setFormType] = useState<LocationManagementForm>(LocationManagementForm.ADD);
  const defaultApprovedDate = useRef('');
  const history = useHistory();
  const { dispatch } = useStateValue();

  const { id } = useParams<RouteParams>();

  useEffect(() => {
    if (history.location?.state) {
      dispatch({ type: BreadCrumbActions.SHOW_BACK, payload: history.location.state.testCentreNumber });
    } else {
      dispatch({ type: BreadCrumbActions.SHOW_BACK });
    }

    if (id) {
      setFormType(LocationManagementForm.UPDATE);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  useEffect(() => {
    if (id) {
      getLocationData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  useEffectUpdate(() => {
    // Clear all the state and error when the user changes the location type code
    if (formType === LocationManagementForm.ADD) {
      setLocationDetailsdata((locationDetailsData) => ({
        ...initialLocationDetailsData,
        locationTypeCode: locationDetailsData.locationTypeCode,
        partnerCode: locationDetailsData.partnerCode,
        locationTypeCodeText: locationDetailsData.locationTypeCodeText,
      }));
      setAddressData(initialAddressData);
      setSelectedProducts([]);

      setAddressFieldErrors(initialAddressErrorData);
      setLocationFieldError({});
    }
  }, [locationDetailsData.locationTypeCode]);

  const getLocationData = () => {
    getLocation(id, props.serviceRequest).subscribe((data) => {
      if (id && data.status === AsyncResponseStatus.SUCCESS && data.locationData) {
        setLocationDetailsdata(data.locationData.locationDetailsData);
        setAddressData(data.locationData.locationAddresses);
        setSelectedProducts(data.locationData.approvedProducts?.activeProd || []);
        setOldSelectedProducts(data.locationData.approvedProducts || defaultOldAuthProd);
        defaultApprovedDate.current = data.locationData.locationDetailsData?.approvedDate || '';
      }
    });
  };

  const getconfirmationMsg = () => {
    const confirmationMsg =
      locationDetailsData.locationTypeCode === LocationType.TEST_CENTRE
        ? locationLabels.addLocationConfirmationMsg
        : locationLabels.addPhysicalBuildingLocationConfirmationMsg;
    const updateConfirmationMsg =
      locationDetailsData.locationTypeCode === LocationType.PHYSICAL_BUILDING
        ? locationLabels.updatePhysicalBuildingLocationConfirmationMsg
        : locationLabels.updateTestCentreLocationConfirmationMsg;
    return formType === LocationManagementForm.UPDATE ? updateConfirmationMsg : confirmationMsg;
  };

  const handlePopupCancel = () => {
    setShowConfirmationDialog(false);
    //callign API to retain values
    formType === LocationManagementForm.UPDATE && getLocationData();
  };

  const getConfirmationModal = () => {
    //  LOCATION: Please move this to language
    const subTitle = `${locationDetailsData.locationName} (${locationDetailsData.testCentreNumber})`;

    return showConfirmationDialog ? (
      <GenericPopup
        id={'locationConfirmationDialog'}
        title={
          formType === LocationManagementForm.UPDATE
            ? locationLabels.updateLocationPopupTitle
            : locationLabels.addLocationPopupTitle
        }
        titlePosition={TitlePosition.DEFAULT}
        buttonStyle={ButtonPosition.RIGHT}
        buttonData={[
          {
            id: 'CancelButton',
            text: locationLabels.cancelButtonTitle,
            type: UIButtonType.SECONDARY,
            onChange: handlePopupCancel,
          },
          {
            id: 'ConfirmButton',
            text: locationLabels.confirmButtonTitle,
            type: UIButtonType.PRIMARY,
            onChange: hadleAddConfirmation,
          },
        ]}
        dialogType={DialogType.CUSTOM}
        modalCloseHandler={() => setShowConfirmationDialog(false)}
      >
        <div className={styles.popUpMessage}>
          {getconfirmationMsg()}
          <p>{subTitle}</p>
        </div>
      </GenericPopup>
    ) : null;
  };

  const getErrorMessage = () => {
    return showToastError ? (
      <ToastMessage
        id="toast_panel_error"
        color={Mode.ERROR}
        position={Position.DEFAULT}
        dismissable={true}
        onChange={() => {
          setShowToastErrorMessage(false);
        }}
        duration={DEFAULT_TOAST_MESSAGE_TIMER}
        message={locationLabels.addLocationValidationToastErrorMsg}
      ></ToastMessage>
    ) : null;
  };

  const handleLocationDetailChange = (event: LocationFormEvent) => {
    setLocationDetailsdata((preState: LocationDetailsData) => getUpdateLocationDetailsData(preState, event));
    setLocationFieldError((preState: LocationtDataError) => ({ ...preState, [event.name]: { isValid: true } }));
  };

  //  Move this function outside the component
  const getUpdateLocationDetailsData = (preState: LocationDetailsData, event: LocationFormEvent) => {
    const newState = {
      ...preState,
    };

    // setting date as current date when location status is ACTIVE
    if (event.name === LocationDetailControl.LOCATION_STATUS && event.value === LocationStatus.ACTIVE) {
      newState[LocationDetailControl.ACTIVATED_DATE] = currentdate;
    } else {
      newState[LocationDetailControl.ACTIVATED_DATE] = '';
    }

    if (event.name === LocationDetailControl.PARTNER_CODE) {
      newState[LocationDetailControl.PARENT_LOCATION_TEXT] = '';
      newState[LocationDetailControl.PARENT_LOCATION_UUID] = '';
    }

    // Rolledback
    //setting initial value as INACTIVE when location type is Physical building
    if (
      formType === LocationManagementForm.ADD &&
      locationDetailsData.locationTypeCode === LocationType.PHYSICAL_BUILDING &&
      event.name === LocationDetailControl.PARENT_LOCATION_UUID
    ) {
      newState[LocationDetailControl.LOCATION_STATUS] = LocationStatus.INACTIVE;
    }

    return {
      ...newState,
      [event.name]: event.value,
    };
  };

  const handleAddressChange = (inputDataEvent: AddressFormEvent) => {
    setAddressData((previousState) =>
      previousState.map((item) => {
        if (inputDataEvent.addressType === item.addressTypeUuid) {
          item = { ...item, [inputDataEvent.name]: inputDataEvent.value };
        }
        return item;
      }),
    );

    setAddressFieldErrors((previousState) =>
      previousState.map((item) => {
        if (inputDataEvent.addressType === item.addressTypeUuid) {
          item = { ...item, [inputDataEvent.name]: { isValid: true } };
        }
        return item;
      }),
    );
  };

  const handleProductSelect = ({ productUuid }: ProductSelectEvent) => {
    setSelectedProducts((prevSelectedProducts: ProductAuthorization[]) => {
      const updatedProducts = [...prevSelectedProducts];
      const idx = prevSelectedProducts.findIndex((prod) => prod.productUuid === productUuid);
      if (idx < 0) {
        updatedProducts.push(getProductAuth(productUuid));
      } else {
        updatedProducts.splice(idx, 1);
      }
      return updatedProducts;
    });
  };

  const handleCancel = () => {
    history.goBack();
  };

  const handleSubmit = () => {
    if (isLocationFormValid()) {
      setLocationFieldError({});
      setShowToastErrorMessage(false);
      setShowConfirmationDialog(true);
    }
  };

  //add API Call
  const hadleAddConfirmation = () => {
    const approvedProducts = getProductsAuthPayload(selectedProducts, oldSelectedProducts);
    const locationPayload = {
      ...locationDetailsData,
      locationAddresses: createAddressData(addressData, locationDetailsData, isSameAsPostal),
      approvedProducts,
    };
    addUpdateLocationDetails(locationPayload, props.serviceRequest).subscribe((response) => {
      if (response && response.status === AsyncResponseStatus.SUCCESS) {
        const { location } = response;

        const userKeys = {
          locName: location.locationName,
          testCenterNumber: location.testCentreNumber,
          locationtypeCode: location.locationTypeCode,
        };
        const addToastLabel =
          locationDetailsData.locationTypeCode === LocationType.TEST_CENTRE
            ? locationLabels.locAddedToastMessage
            : locationLabels.locPhysicalAddedToastMessage;
        const addUpdateLabel =
          formType === LocationManagementForm.UPDATE ? locationLabels.locUpdatedToastMessage : addToastLabel;
        history.push(`/LocationManagement`, formatLanguageString(addUpdateLabel, userKeys));
      }
    });
  };

  const isLocationFormValid = () => {
    const trandformedAddress = createAddressData(addressData, locationDetailsData, isSameAsPostal);
    const { isAddressFormValid, addressErrorData } = getAddressError(trandformedAddress, locationAddressFormRules);
    setAddressFieldErrors(addressErrorData);

    const { isFormvalid, locationError } = getLocationDetailsError(
      locationDetailsData,
      addLocationFormRules(locationDetailsData.locationTypeCode),
    );
    const isLocationFormValid = isFormvalid && isAddressFormValid;
    if (!isLocationFormValid) {
      setLocationFieldError(locationError);
      setShowToastErrorMessage(!isLocationFormValid);
    }
    return isLocationFormValid;
  };

  const getAddressError = (state: AddressData[], rules: AddressFormRule, isValid = true) => {
    let isAddressFormValid = isValid;
    //  LOCATION : PLEASE change the type from any
    const updatedErrordata: AddressErrorField[] = state.map((item: any) => {
      Object.keys(rules[item[AddressFormElements.addressTypeUuid]]).forEach((key) => {
        item = {
          ...item,
          [key]: FormValidation(item[key] || '', rules[item[AddressFormElements.addressTypeUuid]][key]),
        };
        if (!item[key].isValid) isAddressFormValid = false;
      });
      return item;
    });
    return { isAddressFormValid, addressErrorData: updatedErrordata };
  };

  const getLocationDetailsError = (
    state: Dictionary,
    rule: LocationFormRule,
    isValid = true,
    locationError: LocationtDataError = {},
  ) => {
    let isFormvalid = isValid;
    Object.keys(rule).forEach((key) => {
      const locationFormRule = rule[key] as FormRule;
      locationError[key] = FormValidation(state[key] || '', locationFormRule);
      if (!locationError[key].isValid) isFormvalid = false;
    });

    return { isFormvalid, locationError };
  };

  //Get page header
  const getHeaderLabel = () => {
    if (formType === LocationManagementForm.ADD) {
      return locationLabels.addLocation;
    } else if (
      formType === LocationManagementForm.UPDATE &&
      locationDetailsData.locationTypeCode === LocationType.PHYSICAL_BUILDING
    ) {
      return locationLabels.updateBuildingTitle;
    } else {
      return locationLabels.updateLocationTitle;
    }
  };

  return (
    <div>
      {getErrorMessage()}
      {getConfirmationModal()}
      <div className={styles.locationHeaderWrapper}>
        <div className={styles.locationHeading}>
          <div className={styles.locationHeadetext}>{getHeaderLabel()}</div>
          <div className={styles.mandatoryFields}>
            <UI.Typography
              type="normal"
              label={locationLabels.mandatoryFields}
              size={14}
              className={styles.mandatoryFields}
              id="mandatoryFieldCaption"
            />
          </div>
        </div>
        <div className={styles.locationHeaderContainer}>
          <LocationDeatils
            locationDetailsData={locationDetailsData}
            onLocationDetailChange={handleLocationDetailChange}
            error={locationFieldError}
            selectedProductCount={selectedProducts.length}
            locationFormAction={formType}
          />
        </div>
        {showOtherDetails(locationDetailsData) ? (
          <div className={styles.locationHeaderContainer}>
            <LocationAddressPanel
              handleAddressChange={handleAddressChange}
              addressData={addressData}
              isPhysicalBuilding={locationDetailsData.locationTypeCode === LocationType.PHYSICAL_BUILDING}
              onChangeSameAsPostal={setIsSameAsPostal}
              isSameAsPostal={isSameAsPostal}
              errors={addressFieldErrors}
            />
          </div>
        ) : null}
        {showOtherDetails(locationDetailsData) ? (
          <div className={styles.locationHeaderContainer}>
            <SelectProduct
              id={'productAuthorization'}
              selectedProducts={selectedProducts}
              onProductSelect={handleProductSelect}
            />
          </div>
        ) : null}
      </div>
      <div>
        {showOtherDetails(locationDetailsData) ? (
          <FooterButtons
            addOrUpdateButtonText={
              formType === LocationManagementForm.UPDATE ? locationLabels.updateLocation : locationLabels.addButtonTitle
            }
            onCancel={handleCancel}
            onSubmit={handleSubmit}
          ></FooterButtons>
        ) : null}
      </div>
    </div>
  );
};

export default withServiceRequest(AddUpdateLocation);
