import { User } from '@auth0/auth0-spa-js';
import { ROLES_KEY } from '../../../constants/GlobalConstants';
import { LOCATION_GLOBAL_GROUPS, PARTNER_USERS_GROUPS } from '../../../services/hooks/UserGroupConstant';
import { LocationDetailsData } from '../../../services/Models/LocationManagement';
import { splitDataFromKey } from '../../utils/utilities';

//To hide otherdetails
export const showOtherDetails = (locationDetailsData: LocationDetailsData) => {
  return (
    locationDetailsData.locationTypeCode && locationDetailsData.parentLocationUuid && locationDetailsData.partnerCode
  );
};

export const isLMPartnerOnlyUser = (user?: User) => {
  // The user is not global user and  partner user
  if (!isLMGlobalUser(user) && isLMPartnerUser(user)) {
    return true;
  }
  return false;
};

const isLMGlobalUser = (user?: User) => {
  const roles = (user?.[ROLES_KEY] || []).map((role: string) => splitDataFromKey(role, 'g:'));
  return LOCATION_GLOBAL_GROUPS.filter((group) => !!roles.find((role: string) => group.value === role)).length > 0;
};

const isLMPartnerUser = (user?: User) => {
  const roles = (user?.[ROLES_KEY] || []).map((role: string) => splitDataFromKey(role, 'g:'));
  return PARTNER_USERS_GROUPS.filter((group) => !!roles.find((role: string) => group.value === role)).length > 0;
};

// TO DO: Remove extra properties from nested object
// export const removeTextData = (locationDetailsData: any) => {
//   Object.keys(locationDetailsData).forEach((key) => {
//     if (key.includes('Text')) {
//       delete locationDetailsData[key];
//     }
//   });
// };
