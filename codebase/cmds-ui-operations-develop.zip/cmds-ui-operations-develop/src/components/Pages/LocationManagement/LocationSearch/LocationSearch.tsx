import React, { useState, useEffect } from 'react';
import UI from 'ielts-cmds-ui-component-library';
import styles from './LocationSearch.module.scss';
import LocationSearchPanel from '../../../Organisms/LocationSearchPanel/LocationSearchPanel';
import withServiceRequest, { ServiceRequest } from '../../../../services/utils/ServiceRequest';
import {
  LocationSearchCriteria,
  LocationSearchResult,
  SearchPanelButtonType,
  LocationType,
  LocationSearchApiResult,
} from '../../../../services/Models/LocationManagement';
import {
  initialBasicSearchData,
  pageSizeOptions,
  initialLocationSearchResultData,
  defaultSortType,
} from '../../../../constants/LocationManagement/LocationConstants';
import { languageService } from '../../../../services/Language/LanguageService';
import { RouteComponentProps, useHistory } from 'react-router-dom';
import LocationGrid from '../../../Organisms/LocationGrid/LocationGrid';
import { ColumnSort, UIButtonType, SortOptions } from '../../../../services/Models/UIModels';
import { useEffectUpdate, transformRequestValueFromString, getSortedColumnOptions } from '../../../utils/utilities';
import { searchLocation } from '../../../../services/API/LocationManagement/SearchLocation';
import { DEFAULT_TOAST_MESSAGE_TIMER } from '../../../../constants/GlobalConstants';
import { useStateValue } from '../../../../Store/helpers/UseStateValue';
import * as LocationActions from '../../../../Store/Actions/LocationManagementActions';

interface LocationSearchPanelProps extends RouteComponentProps {
  serviceRequest: ServiceRequest;
}

const LocationSearch = (props: LocationSearchPanelProps) => {
  const [searchData, setSearchData] = useState<LocationSearchCriteria>(initialBasicSearchData);
  const [locationData, setLocationData] = useState<LocationSearchResult>(initialLocationSearchResultData);
  const [isSearchLocation, setSearchLocation] = useState(false);
  const [currentSelectedPage, setCurrentSelectedPage] = useState({ page: 1 });
  const [currentSelectedPageSize, setCurrentSelectedPageSize] = useState(pageSizeOptions[0].value);
  const [selectedSortOption, setSelectedSortOption] = useState(defaultSortType as SortOptions);
  const [isLoading, setLoading] = useState(false);

  const history = useHistory();

  const { state, dispatch } = useStateValue();

  const locationLabels = languageService().locationManagement;
  const gridState = {
    totalRecords: locationData.totalCount,
    initialState: {
      pageSize: currentSelectedPageSize,
    },
    selectedPage: currentSelectedPage.page,
    selectedOptionValue: currentSelectedPageSize,
    sortOption: selectedSortOption,
  };

  useEffectUpdate(() => {
    getLocationSearchResults();
  }, [currentSelectedPage]);

  useEffect(() => {
    const { searchData, pageNumber, pageSize, sorting } = state.manageLocation || {};
    if (searchData !== null) {
      setSearchData(searchData);
      setCurrentSelectedPageSize(pageSize);
      setSelectedSortOption(sorting);
      setCurrentSelectedPage({ page: pageNumber });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleBasicInputChange = (name: string, value: string) => {
    setSearchData((preState: LocationSearchCriteria) => ({ ...preState, [name]: value }));
  };

  const onSearchClearHandler = (SearchPanelButton: SearchPanelButtonType) => {
    if (SearchPanelButton === SearchPanelButtonType.CLEAR) {
      setSearchData(initialBasicSearchData);
    } else {
      setCurrentSelectedPage(() => {
        return { page: 1 };
      });
    }
  };

  const getLocationSearchResults = () => {
    const reqBody = {
      testCentreNumber: transformRequestValueFromString(searchData.testCentreNumber),
      locationName: transformRequestValueFromString(searchData.locationName),
      partnerCode: transformRequestValueFromString(searchData.partnerCode),
      status: transformRequestValueFromString(searchData.status),
      locationTypeCode: LocationType.TEST_CENTRE,
      pageNumber: currentSelectedPage.page - 1,
      pageSize: currentSelectedPageSize,
      sorting: selectedSortOption,
    };
    setLoading(true);
    searchLocation(reqBody, props.serviceRequest).subscribe((data: LocationSearchApiResult) => {
      setLoading(false);
      dispatch({
        type: LocationActions.LOCATION_SEARCH,
        payload: {
          searchData,
          pageNumber: currentSelectedPage.page,
          pageSize: currentSelectedPageSize,
          sorting: selectedSortOption,
          totalCount: data.totalCount,
        },
      });
      const locationSearchResults: LocationSearchResult = {
        LocationGridData: data.response || [],
        totalCount: data.totalCount || 0,
      };
      setLocationData(locationSearchResults);
      setSearchLocation(true);
    });
  };

  const onPageChangeHandler = (page: number) => {
    setCurrentSelectedPage(() => {
      return { page: page + 1 };
    });
  };

  const onPageSizeChangeHandler = (value: number) => {
    setCurrentSelectedPageSize(() => value);
    setCurrentSelectedPage(() => {
      return { page: 1 };
    });
  };

  const onColumnSortHandler = (column: ColumnSort) => {
    const sortOption = getSortedColumnOptions(selectedSortOption, column);
    setSelectedSortOption(sortOption);
    setCurrentSelectedPage(() => {
      return { page: 1 };
    });
  };

  const getSuccessMessage = () => {
    const message = history.location?.state;
    return message ? (
      <div className={styles.messageContainer}>
        <UI.Message
          message={message}
          color="success"
          dismissable
          onChange={() => history.replace({})}
          visibleTill={DEFAULT_TOAST_MESSAGE_TIMER}
        />
      </div>
    ) : null;
  };

  return (
    <>
      {getSuccessMessage()}
      <div className={styles.searchPanel}>
        <LocationSearchPanel
          title={locationLabels.locationManagement}
          titleType="regular"
          titleSize={32}
          addButtonLabel={locationLabels.addButtonLabel}
          addButtonColor="blueLine"
          addButtonIcon="plus"
          searchData={searchData}
          basicSearchButtonLabel={locationLabels.searchText}
          basicSearchButtonColor={UIButtonType.PRIMARY}
          handleBasicInputChange={handleBasicInputChange}
          onSearchClearHandler={onSearchClearHandler}
        />
      </div>
      <div className={styles.searchResult}>
        <div className={styles.locationResultContainer}>
          <LocationGrid
            data={locationData.LocationGridData}
            onPageChange={onPageChangeHandler}
            onPageSizeChange={onPageSizeChangeHandler}
            gridState={gridState}
            pageSizeOptions={pageSizeOptions}
            sortOption={selectedSortOption}
            onColumnSort={onColumnSortHandler}
            displayNoResult={locationData && locationData.totalCount === 0 && isSearchLocation}
            sort={true}
            locationType={LocationType.TEST_CENTRE}
            isLoading={isLoading}
          />
        </div>
      </div>
    </>
  );
};

export default withServiceRequest(LocationSearch);
