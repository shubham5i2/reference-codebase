import React, { useState, useEffect } from 'react';
import styles from './ViewBuildings.module.scss';
import { RouteComponentProps, useParams } from 'react-router-dom';
import { searchLocation } from '../../../../../services/API/LocationManagement/SearchLocation';
import { useEffectUpdate } from '../../../../utils/utilities';
import {
  pageSizeOptions,
  initialLocationSearchResultData,
  defaultBuildingSortType,
} from '../../../../../constants/LocationManagement/LocationConstants';
import {
  LocationSearchResult,
  LocationType,
  LocationSearchApiResult,
} from '../../../../../services/Models/LocationManagement';
import withServiceRequest, { ServiceRequest } from '../../../../../services/utils/ServiceRequest';
import { languageService } from '../../../../../services/Language/LanguageService';
import LocationGrid from '../../../../Organisms/LocationGrid/LocationGrid';
import { ColumnSort, RouteParams, SortOptions, SortType } from '../../../../../services/Models/UIModels';
import UI from 'ielts-cmds-ui-component-library';
import * as BreadCrumbActions from '../../../../../Store/Actions/BreadCrumbActions';
import { useStateValue } from '../../../../../Store/helpers/UseStateValue';

interface LocationSearchPanelProps extends RouteComponentProps {
  serviceRequest: ServiceRequest;
}

const ViewBuildings = (props: LocationSearchPanelProps) => {
  const [locationData, setLocationData] = useState<LocationSearchResult>(initialLocationSearchResultData);
  const [currentSelectedPage, setCurrentSelectedPage] = useState({ page: 1 });
  const [currentSelectedPageSize, setCurrentSelectedPageSize] = useState(pageSizeOptions[0].value);
  const [selectedSortOption, setSelectedSortOption] = useState(defaultBuildingSortType as SortOptions);
  const { id } = useParams<RouteParams>();
  const { dispatch } = useStateValue();
  const [isLoading, setLoading] = useState(false);

  const locationLabels = languageService().locationManagement;
  const gridState = {
    totalRecords: locationData.totalCount,
    initialState: {
      pageSize: currentSelectedPageSize,
    },
    selectedPage: currentSelectedPage.page,
    selectedOptionValue: currentSelectedPageSize,
    sortOption: selectedSortOption,
  };

  useEffectUpdate(() => {
    getLocationSearchResults();
  }, [currentSelectedPage]);

  useEffect(() => {
    dispatch({ type: BreadCrumbActions.SHOW_BACK, payload: id });
    getLocationSearchResults();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const getLocationSearchResults = () => {
    const reqBody = {
      testCentreNumber: id,
      locationTypeCode: LocationType.PHYSICAL_BUILDING,
      pageNumber: currentSelectedPage.page - 1,
      pageSize: currentSelectedPageSize,
      sorting: selectedSortOption,
    };
    setLoading(true);
    searchLocation(reqBody, props.serviceRequest).subscribe((data: LocationSearchApiResult) => {
      setLoading(false);
      const locationSearchResults: LocationSearchResult = {
        LocationGridData: data.response || [],
        totalCount: data.totalCount || 0,
      };
      setLocationData(locationSearchResults);
    });
  };

  const onPageChangeHandler = (page: number) => {
    setCurrentSelectedPage(() => {
      return { page: page + 1 };
    });
  };

  const onPageSizeChangeHandler = (value: number) => {
    setCurrentSelectedPageSize(() => value);
    setCurrentSelectedPage(() => {
      return { page: 1 };
    });
  };

  const onColumnSortHandler = (column: ColumnSort) => {
    const sortType =
      JSON.stringify(selectedSortOption.sortBy) === JSON.stringify(column.Header.name)
        ? selectedSortOption.sortType === SortType.ASCENDING
          ? SortType.DESCENDING
          : SortType.ASCENDING
        : SortType.ASCENDING;
    const sortOption = {
      sortType,
      sortBy: column.Header.name,
    };
    setSelectedSortOption(sortOption);
    setCurrentSelectedPage(() => {
      return { page: 1 };
    });
  };

  return (
    <>
      <div className={styles.searchResult}>
        <UI.Typography type={'regular'} label={locationLabels.viewPhysicalBuildings} size={32} id="title" />
        <div className={styles.locationResultContainer}>
          <LocationGrid
            data={locationData.LocationGridData || []}
            onPageChange={onPageChangeHandler}
            onPageSizeChange={onPageSizeChangeHandler}
            gridState={gridState}
            pageSizeOptions={pageSizeOptions}
            sortOption={selectedSortOption}
            onColumnSort={onColumnSortHandler}
            displayNoResult={locationData && locationData.totalCount === 0}
            sort={true}
            locationType={LocationType.PHYSICAL_BUILDING}
            isLoading={isLoading}
          />
        </div>
      </div>
    </>
  );
};

export default withServiceRequest(ViewBuildings);
