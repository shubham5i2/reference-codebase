import React from 'react';

const Setting = () => {
  return <div>Setting works</div>;
};

export default Setting;
