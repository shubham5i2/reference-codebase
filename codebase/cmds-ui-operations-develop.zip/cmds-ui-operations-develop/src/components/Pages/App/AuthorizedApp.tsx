import React, { useState } from 'react';
import { useAuth0 } from '@auth0/auth0-react';
import RouteHandler from '../../../routes/RouteHandler';

import styles from '../../../App.module.scss';
import AppContextProvider from '../../../Store/AppContext/AppContextProvider';
import { breadCrumbRouteConfig } from '../../Organisms/BreadCrumbHandler/BreadCrumbConfig';
import BreadCrumbHandler from '../../Organisms/BreadCrumbHandler/BreadCrumbHandler';
import AppTemplate from '../../Templates/AppTemplate/AppTemplate';
import { ROLES_KEY } from '../../../constants/GlobalConstants';
import LogoutDialog from '../../Others/LogoutDialog/LogoutDialog';
import { languageService } from '../../../services/Language/LanguageService';

const commonLabels = languageService().common;

const getLogoutPopup = (popupData: { titleText: string; isOpaque: boolean; logout: () => void }) => (
  <LogoutDialog
    headerText={commonLabels.error}
    confirmText={commonLabels.ok}
    confirmHandler={() => popupData.logout()}
    {...popupData}
  />
);

const AuthorizedApp: React.FC<{ accessToken: string }> = ({ accessToken }) => {
  const { user, logout } = useAuth0();

  const [showLogoutDialog, setShowLogoutDialog] = useState(false);

  // User is authorized but does not have a valid role. Shows error screen.
  if (user && (!user[ROLES_KEY] || user[ROLES_KEY].length === 0)) {
    return getLogoutPopup({ titleText: commonLabels.noRoleErrorMessage, isOpaque: true, logout });
  }

  // Logout when the user does not have a valid connectionId
  if (showLogoutDialog) {
    return getLogoutPopup({ titleText: commonLabels.loginAgain, isOpaque: false, logout });
  }

  return (
    <AppContextProvider accessToken={accessToken} onMaxConnectionAttemptsFailure={() => setShowLogoutDialog(true)}>
      <AppTemplate>
        <div className={styles.viewContent}>
          <div className={styles.container}>
            <BreadCrumbHandler id="BreadCrumbHandler" breadCrumbRouteConfig={breadCrumbRouteConfig} />
          </div>
          <div className={styles.contentContainer}>
            <RouteHandler />
          </div>
        </div>
      </AppTemplate>
    </AppContextProvider>
  );
};

export default AuthorizedApp;
