import React from 'react';
import { useAuth0 } from '@auth0/auth0-react';

import { languageService } from '../../../services/Language/LanguageService';

const commonLabels = languageService().common;

const UnAuthorizedApp = () => {
  const { isLoading, isAuthenticated, error } = useAuth0();

  if (error) {
    return <div>{`${commonLabels.oops} ${error.message}`}</div>;
  }
  if (isLoading === undefined && !isAuthenticated) {
    return <div>{commonLabels.loading}</div>;
  }
  return <>{commonLabels.somethingWentWrong}</>;
};

export default UnAuthorizedApp;
