import * as React from 'react';
import ViewUser from '../../Templates/ViewUser/ViewUser';
import { useEffect, useContext, useState } from 'react';
import { useStateValue } from '../../../Store/helpers/UseStateValue';
import { useParams, useHistory, useLocation } from 'react-router-dom';
import UI from 'ielts-cmds-ui-component-library';
import { getUserDetails } from '../../../services/API/ManageUser/ViewUserDetails';
import { dateFormatter, getValue } from '../../utils/utilities';
import DeleteUserDialog from '../../Others/DeleteUserDialog/DeleteUserDialog';
import withServiceRequest, { ConnectorInterface, ServiceRequest } from '../../../services/utils/ServiceRequest';
import * as BreadCrumbActions from '../../../Store/Actions/BreadCrumbActions';
import { languageService } from '../../../services/Language/LanguageService';
import * as ManageUserActions from '../../../Store/Actions/ManageUserActions';
import { UserStatus } from '../../../services/Models/StaffManagement';
import { RouteParams } from '../../../services/Models/UIModels';

interface ViewUserPageProps {
  serviceRequest: ServiceRequest;
}
const ViewUserPage = (props: ViewUserPageProps) => {
  const { dispatch } = useStateValue();
  const [userDetail, setUserDetail] = useState<any>({});
  const [isDeleteUser, setisDeleteUser] = useState(false);
  const connectorContext = useContext<ConnectorInterface>(UI.ConnectorContext);
  const { id } = useParams<RouteParams>();
  const history: any = useHistory();
  const location = useLocation();
  const smLabels = languageService().staffManagement;

  //Added payload
  useEffect(() => {
    dispatch({ type: BreadCrumbActions.SHOW_BACK, payload: id });
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    getUserDetails(id, props.serviceRequest).subscribe((userDetail) => {
      userDetail && setUserDetail(userDetail);
    });
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [connectorContext.connectionId]);
  /*--------------- Profile Header -----------------------*/

  const getUserDetail = () => {
    return {
      firstName: getValue(userDetail.givenName).trim(),
      lastName: getValue(userDetail.familyName).trim(),
    };
  };

  /*---------------- LEFT PANEL ------------------------*/

  const headerText = smLabels.viewUserHeaderText;

  const getUserData = () => {
    return [
      { id: 1, title: smLabels.staffId, value: getValue(userDetail.userUuid) },
      { id: 2, title: smLabels.givenName, value: getValue(userDetail.givenName) },
      { id: 3, title: smLabels.familyName, value: getValue(userDetail.familyName) },
      { id: 4, title: smLabels.nickName, value: getValue(userDetail.nickname) },
      {
        id: 5,
        title: smLabels.emailId,
        value: getValue(userDetail.email),
        verify: userDetail.emailVerified ? smLabels.verified : smLabels.notVerified,
      },
      {
        id: 6,
        title: smLabels.phonenumber,
        value: getValue(userDetail.phoneNumber),
        verify: userDetail.phoneVerified ? smLabels.verified : smLabels.notVerified,
      },
      {
        id: 7,
        title: smLabels.organisation,
        value: getValue(userDetail.partnerCode),
      },
    ];
  };

  /*--------------- RIGHT PANEL ----------------------*/

  const getUserGroupDetails = () => {
    return userDetail?.userGroupAssignments?.map((assignment: any, index: number) => {
      return {
        id: assignment.userGroupAssignmentId,
        assignment: `${smLabels.assignment.toUpperCase()}  ${index + 1}`,
        data: [
          { id: 1, title: smLabels.userGroup, value: assignment.userGroupName },
          {
            id: 2,
            title: smLabels.duration,
            value: `${dateFormatter(assignment.effectiveFromDatetime)} - ${dateFormatter(
              assignment.effectiveToDatetime,
            )}`,
          },
          { id: 3, subText: smLabels.location, title: smLabels.location, value: assignment.locationName },
        ],
      };
    });
  };

  const getUserStatus = () => {
    return getValue(userDetail.userStatus) === UserStatus.ACTIVE ? smLabels.active : smLabels.inActive;
  };

  const deleteUserHandler = () => {
    const { selectedRow } = location.state;
    const username = getUserDetail();
    dispatch({
      type: ManageUserActions.USER_DELETED,
      payload: {
        deletedRow: selectedRow,
        deletedUserId: id,
        deletedUserName: `${username.firstName} ${username.lastName}`,
      },
    });
    setisDeleteUser(false);
    history.push('/manageuser');
  };

  const getDeleteUserModal = () => {
    return isDeleteUser ? (
      <DeleteUserDialog
        id="deleteUserDialogComponent"
        title={smLabels.deleteUserTitle}
        label={smLabels.deleteUserLabel}
        userName={`${getValue(userDetail.givenName)} ${getValue(userDetail.familyName)}`}
        modalCloseHandler={() => setisDeleteUser(false)}
        deleteUserHandler={deleteUserHandler}
        staffId={id}
        emailId={getValue(userDetail.email)}
        status={getUserStatus()}
      />
    ) : null;
  };

  const onHeaderActionChange = (selectedAction: any) => {
    switch (selectedAction.tag) {
      case 'Delete': {
        setisDeleteUser(true);
        break;
      }
      case 'Update': {
        dispatch({
          type: ManageUserActions.USER_EDIT_STATUS,
          payload: true,
        });
        history.push(`/manageuser/viewUserPage/${id}/updateuser/${id}`);
        break;
      }
      case 'Assign group': {
        dispatch({
          type: ManageUserActions.USER_EDIT_STATUS,
          payload: true,
        });
        const userGroup = getUserGroupDetails()
          .map((assignment: any) => {
            return assignment.data[0].value || '';
          })
          .join(', ');
        history.push({
          pathname: `/manageuser/viewUserPage/${id}/assigngroup/${id}`,
          state: { userGroup },
        });
        break;
      }
    }
  };

  return (
    <>
      {getDeleteUserModal()}
      <ViewUser
        user={getUserDetail()}
        headerText={headerText}
        userData={getUserData()}
        userGroupDetails={getUserGroupDetails() || []}
        onHeaderAction={onHeaderActionChange}
        status={getUserStatus()}
      />
    </>
  );
};

export default withServiceRequest(ViewUserPage);
