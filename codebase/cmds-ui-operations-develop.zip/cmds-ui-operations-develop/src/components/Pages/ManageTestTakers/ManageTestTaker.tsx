import React from 'react';
import { Switch } from 'react-router-dom';
import PrivateRoute from '../../../routes/PrivateRoute';
import ROOT_FEATURE from '../../../services/feature-toggle/feature-types/RootFeature';
import useFeatureToggle from '../../../services/feature-toggle/UseFeatureToggle';
import styles from './ManageTestTaker.module.scss';
import Search from './ManageTestTakerSearchPanel/ManageTestTakerSearchPanel';
import TestTakerDetails from '../TestTakerBookingHistoryPage/TestTakerBookingHistoryPage';
import TestTakerBookingDetails from '../TestTakerBookingDetails/TestTakerBookingDetailsPage';
import LoadReferenceData from './LoadReferenceData';

const ManageTestTakers = (props: any) => {
  const currentUrl = props.match.url;
  useFeatureToggle(ROOT_FEATURE.testtaker);
  return (
    <div className={styles.container}>
      <LoadReferenceData />
      <Switch>
        <PrivateRoute
          path={currentUrl + '/testtakerbookinghistory/:id/testtakerbookingdetails/:id'}
          component={TestTakerBookingDetails}
        />
        <PrivateRoute path={currentUrl + '/testtakerbookinghistory/:id/associateuttid'} exact component={Search} />
        <PrivateRoute path={currentUrl + '/testtakerbookinghistory/:id'} component={TestTakerDetails} />
        <PrivateRoute path={currentUrl} component={Search} />
      </Switch>
    </div>
  );
};

export default ManageTestTakers;
