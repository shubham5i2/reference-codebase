import React, { useEffect } from 'react';
import { RouteComponentProps } from 'react-router-dom';
import withServiceRequest, { ServiceRequest } from '../../../services/utils/ServiceRequest';
import { useStateValue } from '../../../Store/helpers/UseStateValue';
import { useAuth0 } from '@auth0/auth0-react';
import { ReferenceDropdownType } from '../../../services/Models/ReferenceModals';
import { useReferenceFetch } from '../../Organisms/ReferenceDropdown/UseReferenceFetch';
import { DataState } from '../../../services/Models/UIModels';
import { loadProduct, preloadLocations } from '../../../services/Preloader/usePreloader';
import { getLocationKey, LocationType } from '../../Organisms/LocationDropdown/LocationDropdownUtils';
import { getPartnerCode } from '../../utils/utilities';
import { useLocationFetch } from '../../Organisms/LocationDropdown/useLocationFetch';

interface LoadReferenceDataProps extends RouteComponentProps {
  serviceRequest: ServiceRequest;
}

const referenceDataConfig = [ReferenceDropdownType.COUNTRY];

const LoadReferenceData = (props: LoadReferenceDataProps) => {
  const { fetchReferenceData } = useReferenceFetch();

  const { state, dispatch } = useStateValue();
  const { user } = useAuth0();

  const { locationService } = useLocationFetch();

  const populateCountryRefData = () => {
    // CALL API
    const serviceRequest = props.serviceRequest;
    fetchReferenceData({ serviceData: referenceDataConfig, serviceRequest });
  };

  useEffect(() => {
    const partnerCode = getPartnerCode(user || {});
    const locationKey = getLocationKey(LocationType.TEST_CENTRE, partnerCode, 'getLocations');
    const locationsData = state.locationData?.[locationKey]?.response;
    const productsData = state.products?.response;
    const countriesResponse = state.referenceData?.country?.response;
    if (!countriesResponse?.length && countriesResponse?.dataState !== DataState.LOADING) {
      populateCountryRefData();
    }
    if (!productsData?.length && productsData?.dataState !== DataState.LOADING) {
      const serviceRequest = props.serviceRequest;
      loadProduct({ serviceRequest, dispatcher: dispatch });
    }
    if (!locationsData?.length && locationsData?.dataState !== DataState.LOADING) {
      const serviceRequest = props.serviceRequest;
      preloadLocations({ serviceRequest, user, dispatcher: dispatch }, LocationType.NONE, locationService);
    }
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return <React.Fragment></React.Fragment>;
};

export default withServiceRequest(LoadReferenceData);
