import React, { useState, useEffect, useRef, useContext } from 'react';
import { RouteComponentProps } from 'react-router-dom';
import { languageService } from '../../../../services/Language/LanguageService';
import withServiceRequest, { ConnectorInterface, ServiceRequest } from '../../../../services/utils/ServiceRequest';
import { useStateValue } from '../../../../Store/helpers/UseStateValue';
import { pageSizeOptions } from '../../../Organisms/ManageUsersGrid/ManageUsersGridConstants';
import SearchPanel from '../../../Templates/ManageTestTakerSearch/TestTakerSearch';
import * as testTakerSearchType from '../../../../constants/ManageTestTakerSearchType';
import * as BreadCrumbActions from '../../../../Store/Actions/BreadCrumbActions';
import UI from 'ielts-cmds-ui-component-library';
import styles from './ManageTestTakerSearchPanel.module.scss';
import { getValue, transformRequestValueFromString, useEffectUpdate, formatDate } from '../../../utils/utilities';
import * as ManageTestTakerActions from '../../../../Store/Actions/ManageTestTakerActions';
import { testTakerSearchResult } from '../../../../services/API/TestTaker/TestTakerSearchResult';
import ManageTestTakerGrid from '../../../Organisms/ManageTestTakerGrid/ManageTestTakerGrid';
import { ColumnSort } from '../../../../services/Models/UIModels';
import NoResultsFound from '../../../Molecules/NoResultsFound/NoResultsFound';
import { ManageTestTakerSearchPayload } from '../../../../services/Models/TestTakerManagement';
import * as BaseDropDownActions from '../../../../Store/Actions/BaseDropDownActions';
import NationalityDropDown from '../../../Organisms/BaseDropDown/NationalityDropDown/NationalityDropDown';
import { useParams, useHistory } from 'react-router';
import ManageTestTakerAddBookingGrid from '../../../Organisms/ManageTestTakerAddBookingGrid/ManageTestTakerAddBookingGrid';
import { getBanStatuses } from '../../../../services/API/Reference/BanStatus';

interface ManageTestTakerSearchPanelProps extends RouteComponentProps {
  serviceRequest: ServiceRequest;
}

interface AdvancedSearchDataType {
  givenname: string;
  familyname: string;
  email: string;
  nationality: string;
  dateofbirth: string;
  banStatus: string;
}

interface BasicSearchDataType {
  uniquetesttakerid: string;
  cmdsbookingid: string;
  identitydocumentnumber: string;
}

const ManageTestTakerSearchPanel = (props: ManageTestTakerSearchPanelProps) => {
  const isFromSearchClick = useRef(false);
  const selectedSearchType = useRef('');
  const connectorContext = useContext<ConnectorInterface>(UI.ConnectorContext);

  const testTakerLabels = languageService().testTaker;

  const initialDropDownDataSource = { text: '', value: '' };

  const [countryDropDownData, setCountryDropDownData] = useState(initialDropDownDataSource);

  const [isClearBasicSearch, setClearBasicSearch] = useState(false);

  const initialBasicSearchData = { uniquetesttakerid: '', cmdsbookingid: '', identitydocumentnumber: '' };

  const [basicSearchData, setBasicSearchData] = useState(initialBasicSearchData);

  const [isClearAdvancedSearch, setClearAdvancedSearch] = useState(false);

  const [initialOpenState, setInitialOpenState] = useState(false);

  const { state, dispatch } = useStateValue();

  const [isSearchCriteriaValid, setSearchCriteriaValid] = useState(true);

  const [isSearchResults, setSearchResults] = useState(false);

  const [searchResultsData, setSearchResultsData] = useState([]);

  const [totalSearchResult, setTotalSearchResult] = useState(0);
  const [isLoading, setLoading] = useState(false);
  const [currentSelectedPage, setCurrentSelectedPage] = useState({ page: 1 });
  const [currentSelectedPageSize, setCurrentSelectedPageSize] = useState(pageSizeOptions[0].value);
  const [selectedSortOption, setSelectedSortOption] = useState({
    sortType: 'ASC',
    sortBy: 'uniqueTestTakerId',
  });

  const initialAdvancedSearchData = {
    givenname: '',
    familyname: '',
    email: '',
    nationality: '',
    banStatus: 'ALL',
    dateofbirth: '',
  };

  const bannedDropdownOptions = getBanStatuses();

  const [advancedSearchData, setAdvancedSearchData] = useState(initialAdvancedSearchData);
  const { id } = useParams<{ id: string }>();
  const inCompleteBooking = useRef(true);
  const history = useHistory();

  useEffectUpdate(() => {
    if (!isFromSearchClick.current) {
      const { searchName } = state.manageTestTaker.searchData;
      const name = searchName || testTakerSearchType.DEFAULT;
      const reqBody = getSearchRequestBody();
      getSearchResults(name, reqBody);
    } else if (isFromSearchClick.current && selectedSearchType.current !== '') {
      const reqBody = getSearchRequestBody();
      getSearchResults(selectedSearchType.current, reqBody);
      selectedSearchType.current = '';
    }
  }, [currentSelectedPage]);

  const updateUI = (searchName: string, body: ManageTestTakerSearchPayload) => {
    const { criteria } = body;
    if (searchName === testTakerSearchType.BASIC || searchName === testTakerSearchType.DEFAULT) {
      setBasicSearchData({
        uniquetesttakerid: getValue(criteria.uniqueTestTakerId),
        cmdsbookingid: getValue(criteria.bookingUuid),
        identitydocumentnumber: getValue(criteria.identityNumber),
      });
      setClearBasicSearch(true);
    } else {
      setBasicSearchData({
        uniquetesttakerid: getValue(criteria.uniqueTestTakerId),
        cmdsbookingid: getValue(criteria.bookingUuid),
        identitydocumentnumber: getValue(criteria.identityNumber),
      });
      setAdvancedSearchData({
        givenname: getValue(criteria.firstName),
        familyname: getValue(criteria.lastName),
        email: getValue(criteria.email),
        nationality: getValue(criteria.nationalityUuid),
        banStatus: getValue(criteria.banStatus),
        dateofbirth: getValue(criteria.birthDate),
      });
      setCountryDropDownData({
        value: getValue(criteria.nationalityUuid),
        text: getValue(criteria.nationalityUuid),
      });
      setInitialOpenState(true);
      setClearAdvancedSearch(true);
    }
  };

  const getReqBody = () => {
    if (id) {
      return {
        uniqueTestTakerId: transformRequestValueFromString(basicSearchData.uniquetesttakerid),
        bookingUuid: transformRequestValueFromString(basicSearchData.cmdsbookingid),
        identityNumber: transformRequestValueFromString(basicSearchData.identitydocumentnumber),
        firstName: transformRequestValueFromString(advancedSearchData.givenname),
        lastName: transformRequestValueFromString(advancedSearchData.familyname),
        email: transformRequestValueFromString(advancedSearchData.email),
        birthDate: transformRequestValueFromString(advancedSearchData.dateofbirth),
        nationalityUuid: transformRequestValueFromString(advancedSearchData.nationality),
        banStatus: transformRequestValueFromString(advancedSearchData.banStatus),
        ignoreIncompleteBooking: inCompleteBooking.current,
      };
    } else {
      return {
        uniqueTestTakerId: transformRequestValueFromString(basicSearchData.uniquetesttakerid),
        bookingUuid: transformRequestValueFromString(basicSearchData.cmdsbookingid),
        identityNumber: transformRequestValueFromString(basicSearchData.identitydocumentnumber),
        firstName: transformRequestValueFromString(advancedSearchData.givenname),
        lastName: transformRequestValueFromString(advancedSearchData.familyname),
        email: transformRequestValueFromString(advancedSearchData.email),
        birthDate: transformRequestValueFromString(advancedSearchData.dateofbirth),
        nationalityUuid: transformRequestValueFromString(advancedSearchData.nationality),
        banStatus: transformRequestValueFromString(advancedSearchData.banStatus),
      };
    }
  };

  const getSearchRequestBody = (): ManageTestTakerSearchPayload => {
    const sorting = Array.isArray(selectedSortOption.sortBy)
      ? selectedSortOption.sortBy.map((sortBy) => getSortingElement(sortBy, selectedSortOption.sortType))
      : [getSortingElement(selectedSortOption.sortBy, selectedSortOption.sortType)];

    const reqBody: ManageTestTakerSearchPayload = {
      criteria: getReqBody(),
      pagination: {
        pageNumber: currentSelectedPage.page - 1,
        pageSize: currentSelectedPageSize,
      },
      sorting,
    };
    return reqBody;
  };
  const getSearchResults = (name: string, body: ManageTestTakerSearchPayload, shouldUpdateState = true) => {
    const selectedPageSizeIndex = pageSizeOptions.findIndex((option) => option.value === currentSelectedPageSize);
    if (shouldUpdateState) {
      dispatch({
        type: ManageTestTakerActions.MANAGE_TEST_TAKER_SEARCH,
        payload: {
          body,
          searchName: name,
          selectedPage: currentSelectedPage,
          selectedPageSizeIndex,
          sortOption: selectedSortOption,
        },
      });
    }
    testTakerSearchResult(body, props.serviceRequest).subscribe((data) => {
      if (!data) return;
      setLoading(false);
      console.log('data --> ', data);
      const gridData = data.gridData || [];
      const totalRecords = data.totalCount || 0;
      dispatch({ type: ManageTestTakerActions.SEARCH_SUCCESS, payload: { totalCount: totalRecords } });
      dispatch({
        type: ManageTestTakerActions.VIEW_BOOKING,
        payload: { selectedUniqueTestTakerUuid: '', selectedBookingUuid: '' },
      });
      setTotalSearchResult(totalRecords);
      setSearchResultsData(gridData);
      setSearchResults(totalRecords > 0);
    });
  };

  const getSearchResultsOnLoad = () => {
    const { searchName, body, selectedPage, selectedPageSizeIndex, sortOption } = state.manageTestTaker.searchData;
    setInitialOpenState(false);
    setLoading(true);
    const reqBody = getSearchRequestBody();
    if (id) {
      getSearchResults(testTakerSearchType.DEFAULT, reqBody, false);
    } else if (searchName !== '' && body) {
      isFromSearchClick.current = true;
      setCurrentSelectedPage(selectedPage);
      setCurrentSelectedPageSize(pageSizeOptions[selectedPageSizeIndex].value);
      setSelectedSortOption(sortOption);
      updateUI(searchName, body);
      getSearchResults(searchName, body, false);
    } else {
      getSearchResults(testTakerSearchType.DEFAULT, reqBody, false);
    }
  };

  useEffect(() => {
    id ? dispatch({ type: BreadCrumbActions.SHOW_BACK, payload: id }) : dispatch({ type: BreadCrumbActions.SHOW_BACK });
  }, [dispatch, id]);

  useEffect(() => {
    getSearchResultsOnLoad();
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [connectorContext.connectionId]);

  const handleBasicInputChange = (e: React.FormEvent<HTMLInputElement>) => {
    setClearBasicSearch(true);
    const target = e.target as HTMLInputElement;
    const value = target.value;
    setBasicSearchData({ ...basicSearchData, [target.name]: value });
  };

  const updateStateOnClearSearch = () => {
    dispatch({
      type: ManageTestTakerActions.CLEAR_TEST_TAKER_SEARCH,
    });
  };

  const onClearBasicSearch = (event: React.FormEvent<HTMLInputElement>) => {
    event.preventDefault();
    setBasicSearchData(initialBasicSearchData);
    setClearBasicSearch(false);
    updateStateOnClearSearch();
  };

  const basicSearchDataValidationCheck = (basicSearchDataArg: BasicSearchDataType) => {
    const { uniquetesttakerid, cmdsbookingid, identitydocumentnumber } = basicSearchDataArg;
    if (uniquetesttakerid.trim() === '' && cmdsbookingid.trim() === '' && identitydocumentnumber.trim() === '') {
      return true;
    }
    return false;
  };

  const advancedSearchDataValidationCheck = (advancedSearchDataArg: AdvancedSearchDataType) => {
    const { givenname, familyname, email, nationality, dateofbirth, banStatus } = advancedSearchDataArg;
    if (
      givenname.trim() === '' &&
      familyname.trim() === '' &&
      email.trim() === '' &&
      nationality.trim() === '' &&
      banStatus.trim() === '' &&
      dateofbirth.trim() === ''
    ) {
      return true;
    }
    return false;
  };

  const onBasicSearchHandler = () => {
    const isSearchDataEmpty = basicSearchDataValidationCheck(basicSearchData);
    if (!isClearBasicSearch || isSearchDataEmpty) {
      setSearchCriteriaValid(false);
      setSearchResults(false);
      return;
    }
    isFromSearchClick.current = true;
    selectedSearchType.current = testTakerSearchType.BASIC;
    setCurrentSelectedPage(() => {
      return { page: 1 };
    });
    setSearchCriteriaValid(true);
    setSearchResults(true);
  };

  const handleAdvancedInputChange = (e: React.FormEvent<HTMLInputElement>) => {
    setClearAdvancedSearch(true);
    const target = e.target as HTMLInputElement;
    const value = target.value;
    setAdvancedSearchData({ ...advancedSearchData, [target.name]: value });
  };

  const handleBanStatusChange = (value: string) => {
    setClearAdvancedSearch(true);
    setAdvancedSearchData({ ...advancedSearchData, banStatus: value });
  };

  const onClearAdvancedSearch = (event: React.FormEvent<HTMLInputElement>) => {
    event.preventDefault();
    setBasicSearchData(initialBasicSearchData);
    setAdvancedSearchData(initialAdvancedSearchData);
    setCountryDropDownData(initialDropDownDataSource);
    setClearBasicSearch(false);
    setClearAdvancedSearch(false);
    updateStateOnClearSearch();
  };

  const onAdvancedSearchHandler = () => {
    const isAdvancedSearchDataEmpty = advancedSearchDataValidationCheck(advancedSearchData);
    const isBasicSearchDataEmpty = basicSearchDataValidationCheck(basicSearchData);
    if ((!isClearBasicSearch && !isClearAdvancedSearch) || (isAdvancedSearchDataEmpty && isBasicSearchDataEmpty)) {
      setSearchCriteriaValid(false);
      setSearchResults(false);
      return;
    }
    isFromSearchClick.current = true;
    selectedSearchType.current = testTakerSearchType.ADVANCE;
    setCurrentSelectedPage(() => {
      return { page: 1 };
    });
    setSearchCriteriaValid(true);
    setSearchResults(true);
  };

  const getSortingElement = (sortBy: string, sortType: string) => ({ sortBy, sortType });

  const onPageChangeHandler = (page: number) => {
    isFromSearchClick.current = false;
    setCurrentSelectedPage(() => {
      return { page: page + 1 };
    });
  };

  const onPageSizeChangeHandler = (value: number) => {
    setCurrentSelectedPageSize(() => value);
    isFromSearchClick.current = false;
    setCurrentSelectedPage(() => {
      return { page: 1 };
    });
  };

  const onColumnSortHandler = (column: ColumnSort) => {
    let sortType;
    if (JSON.stringify(selectedSortOption.sortBy) === JSON.stringify(column.Header.name)) {
      sortType = selectedSortOption.sortType === 'ASC' ? 'DESC' : 'ASC';
    } else {
      sortType = 'ASC';
    }

    const sortOption = {
      sortBy: column.Header.name,
      sortType,
    };
    setSelectedSortOption(() => sortOption);
    isFromSearchClick.current = false;
    setCurrentSelectedPage(() => {
      return { page: 1 };
    });
  };

  const testTakerData = searchResultsData && searchResultsData.length > 0 ? searchResultsData : [];

  const getTestTakerGrid = () => {
    const gridState = {
      totalRecords: totalSearchResult,
      initialState: {
        pageSize: currentSelectedPageSize,
      },
      selectedPage: currentSelectedPage.page,
      selectedOptionValue: currentSelectedPageSize,
    };
    return (
      <div className={styles.searchResults}>
        {id ? (
          <ManageTestTakerAddBookingGrid
            data={testTakerData}
            onPageChange={onPageChangeHandler}
            onPageSizeChange={onPageSizeChangeHandler}
            gridState={gridState}
            pageSizeOptions={pageSizeOptions}
            onColumnSort={onColumnSortHandler}
            sortOption={selectedSortOption}
            sort={true}
            isLoading={isLoading}
            testtakerUuId={id}
            testTakerId={history.location.state.uniqueTestTakerId ? history.location.state.uniqueTestTakerId : ''}
          />
        ) : (
          <ManageTestTakerGrid
            data={testTakerData}
            onPageChange={onPageChangeHandler}
            onPageSizeChange={onPageSizeChangeHandler}
            gridState={gridState}
            pageSizeOptions={pageSizeOptions}
            onColumnSort={onColumnSortHandler}
            sortOption={selectedSortOption}
            sort={true}
            isLoading={isLoading}
          />
        )}
      </div>
    );
  };

  const handleCountryChange = (e: { name: string; value: string; text: string }) => {
    setClearAdvancedSearch(true);
    setCountryDropDownData({ text: e.text, value: e.value });
    setAdvancedSearchData({ ...advancedSearchData, [e.name]: e.value });
  };

  const handleDateChange = (selectedDate: Date) => {
    setClearAdvancedSearch(true);
    setAdvancedSearchData({
      ...advancedSearchData,
      dateofbirth: formatDate(selectedDate, testTakerLabels.inputDateFormat),
    });
  };

  return (
    <React.Fragment>
      {!isSearchCriteriaValid ? (
        <div className={styles.messageContainer}>
          <UI.Message
            message={testTakerLabels.searchCriteriaError}
            color="error"
            dismissable
            onChange={() => setSearchCriteriaValid(true)}
          />
        </div>
      ) : null}
      <SearchPanel
        title={id ? testTakerLabels.manageTestTakerRecordTitile : testTakerLabels.manageTestTakerTitle}
        titleType="regular"
        titleSize={32}
        subTitle={id ? testTakerLabels.manageTestTakerRecordSubTitile : testTakerLabels.manageTestTakerSubTitle}
        subTitleType="regular"
        subTitleSize={16}
        basicSearchData={basicSearchData}
        clearBasicSearch={
          JSON.stringify(basicSearchData) !== JSON.stringify(initialBasicSearchData) ? testTakerLabels.clearSearch : ''
        }
        basicSearchButtonLabel={testTakerLabels.searchLabel}
        basicSearchButtonColor="primary"
        onClearBasicSearch={onClearBasicSearch}
        handleBasicInputChange={handleBasicInputChange}
        onBasicSearchHandler={onBasicSearchHandler}
        clearAdvancedSearch={
          JSON.stringify(advancedSearchData) !== JSON.stringify(initialAdvancedSearchData) ||
          JSON.stringify(basicSearchData) !== JSON.stringify(initialBasicSearchData)
            ? testTakerLabels.clearSearch
            : ''
        }
        advanceSearchButtonLabel={testTakerLabels.searchLabel}
        advanceSearchButtonColor="primary"
        onClearAdvancedSearch={onClearAdvancedSearch}
        handleAdvancedInputChange={handleAdvancedInputChange}
        onAdvancedSearchHandler={onAdvancedSearchHandler}
        collapseTitle={testTakerLabels.collapseTitle}
        collapseOpenTitle=""
        collapseFooterTitle={testTakerLabels.collapseFooterTitle}
        initialOpenState={initialOpenState}
        ieltsTestTakerLabel={testTakerLabels.uniqueTestTakerId}
        cmdsBookingIdLabel={testTakerLabels.cmdsBookingId}
        identityDocumentNumberLabel={testTakerLabels.identityDocumentNumber}
      >
        <div className={styles.col3}>
          <UI.TextBox
            label={testTakerLabels.givenName}
            name={testTakerLabels.givenName.replace(/ /g, '').toLowerCase()}
            placeholder=""
            value={advancedSearchData.givenname}
            onChange={handleAdvancedInputChange}
          />
          <UI.TextBox
            label={testTakerLabels.familyName}
            name={testTakerLabels.familyName.replace(/ /g, '').toLowerCase()}
            placeholder=""
            value={advancedSearchData.familyname}
            onChange={handleAdvancedInputChange}
          />
          <UI.TextBox
            label={testTakerLabels.email}
            name={testTakerLabels.email.replace(/ /g, '').toLowerCase()}
            placeholder=""
            value={advancedSearchData.email}
            onChange={handleAdvancedInputChange}
          />
          {/*  - IMOD-16050 - Using default library as no reusable datepicker component is present.
           Date Picker component will be updated with IMOD-10650 */}
          <div className={styles.dateWrapper}>
            <div className={styles.textBoxLabel}>{testTakerLabels.dateOfBirth}</div>
            <span>
              <UI.DatePicker
                id="dateOfBirth"
                minDate="1900-01-01"
                maxDate="2100-12-31"
                value={advancedSearchData.dateofbirth}
                onChange={handleDateChange}
                resetDate={advancedSearchData.dateofbirth === ''}
              />
            </span>
          </div>
          <NationalityDropDown
            id="testTakerNationality"
            label={testTakerLabels.nationality}
            labelId="testTakerNationalityLB"
            isMandatory={false}
            textBoxPlaceHolder={testTakerLabels.pleaseSelectPlaceHolder}
            selectedNationality={countryDropDownData}
            serviceRequest={props.serviceRequest}
            isFilterEnabled={true}
            canUseStoreData
            storeDataPath="baseDropDown.nationalities"
            actionType={BaseDropDownActions.NATIONALITIES_ADDED}
            onNationalityChange={(value: string, text: string) =>
              handleCountryChange({
                name: 'nationality',
                value: value,
                text: text,
              })
            }
          />
          <UI.Dropdown
            id="bannedStatus"
            label={testTakerLabels.banStatusOption}
            selectedValue={advancedSearchData.banStatus}
            placeholder={testTakerLabels.defaultBan}
            onChange={handleBanStatusChange}
            list={bannedDropdownOptions}
          />
        </div>
      </SearchPanel>
      {isSearchResults ? (
        getTestTakerGrid()
      ) : (
        <NoResultsFound
          title={testTakerLabels.noResultsFoundTitle}
          description={id ? testTakerLabels.noResultsFoundAddBookingDesp : testTakerLabels.noResultsFoundDesp}
        />
      )}
    </React.Fragment>
  );
};

export default withServiceRequest(ManageTestTakerSearchPanel);
