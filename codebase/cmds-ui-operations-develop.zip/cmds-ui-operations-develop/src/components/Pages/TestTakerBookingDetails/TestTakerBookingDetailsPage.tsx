import React, { useEffect, useState } from 'react';
import withServiceRequest, { ServiceRequest } from '../../../services/utils/ServiceRequest';
import * as BreadCrumbActions from '../../../Store/Actions/BreadCrumbActions';
import { useStateValue } from '../../../Store/helpers/UseStateValue';
import { getTestTakerBookingDetails } from '../../../services/API/TestTaker/GetTestTakerBookingDetails';
import { useHistory, useParams } from 'react-router-dom';
import { TestTakerBookingDetailsResponse } from '../../../services/Models/TestTakerManagement';
import TestTakerBookingDetailsHeader from '../../Organisms/TestTakerBookingDetailsHeader/TestTakerBookingDetailsHeader';
import TestTakerBookingDetailsLeftPanel from '../../Organisms/TestTakerBookingDetailsLeftPanel/TestTakerBookingDetailsLeftPanel';
import TestTakerBookingDetailsRightPanel from '../../Organisms/TestTakerBookingDetailsRightPanel/TestTakerBookingDetailsRightPanel';
import { AsyncResponseStatus } from '../../../services/Models/Api';
import styles from './TestTakerBookingDetails.module.scss';
import { getResultStatuses } from '../../../services/API/TestTaker/GetTestTakerResultStatus';
import { BookingResultsResponseV2 } from '../../Pages/Results/ResultsTestTakerDetails/ResultsTestTakerDetailsConstants';
import { initialCurrentResultStatus } from '../../../constants/ManageTestTaker/BookingHistory';

interface TestTakerBookingDetailsPageProps {
  serviceRequest: ServiceRequest;
}

const initialBookingDetailsData: TestTakerBookingDetailsResponse = {
  bookingUuid: '',
  testTakerInfo: {
    testTakerUuid: '',
    firstName: '',
    lastName: '',
    birthDate: '',
    email: '',
    identityNumber: '',
    nationality: '',
    phone: '',
    mobile: '',
    identityIssuingAuthority: '',
    identityExpiryDate: '',
    identityTypeUuid: '',
    nationalityUuid: '',
    sexUuid: '',
    agentName: '',
    consentGiven: true,
    address: {
      addressLine1: '',
      addressLine2: '',
      addressLine3: '',
      addressLine4: '',
      stateTerritoryUuid: '',
      postalCode: '',
      city: '',
      countryUuid: '',
    },
  },
  marketingInfo: {
    educationLevelUuid: '',
    yearsOfStudy: 0,
    occupationSectorUuid: '',
    occupationLevelUuid: '',
    reasonForTestUuid: '',
    applyingToCountryUuid: '',
    currentEnglishStudyPlace: '',
    occupationSectorOther: '',
    occupationLevelOther: '',
    reasonForTestOther: '',
    countryApplyingToOther: '',
  },
  testBookingInfo: {
    testDate: '',
    testCentre: '',
    product: '',
    productUuid: '',
    testCentreNumber: '',
    testCentreName: '',
    testCentreUuid: '',
    locationName: '',
    locationUuid: '',
    partnerCode: '',
    identityVerificationStatus: '',
    bookingStatus: '',
    bookingDetailStatus: '',
    testPlatformUsername: '',
    testPlatformPassword: '',
    externalUniqueTestTakerUuid: '',
    compositeCandidateNumber: '',
    shortCandidateNumber: '',
    bookingLines: [
      {
        bookingLineUuid: '',
        externalBookingLineUuid: '',
        startDateTime: '',
        endDateTime: '',
        startTimeLocal: '',
        extraTimeMinutes: '',
        productUuid: '',
        bookingLineStatus: '',
        testPlatformReady: '',
      },
    ],
  },
  resultStatusInfo: {
    resultStatus: '',
    resultStatusLabel: '',
    resultStatusComment: '',
    resultStatusDate: '',
    banStatus: '',
    resultStatusUpdateDatetime: '',
    resultStatusTypeUuid: '',
    resultStatusLabelUuid: '',
    resultStatusCommentUuid: '',
  },
  bookingOtherInfo: {
    matchDate: '',
    matchEvent: '',
    notes: '',
    Notes: '',
    specialArrangementsRequired: false,
    aaCaseNumber: '',
  },
  linkedBookingDetails: {
    bookingUuid: '',
    testCentreUuid: '',
    shortCandidateNumber: '',
    locationUuid: '',
    productUuid: '',
    testDate: '',
  },
};

const TestTakerBookingDetailsPage = (props: TestTakerBookingDetailsPageProps) => {
  const { dispatch } = useStateValue();
  const history = useHistory();
  const { id } = useParams<{ id: string }>();
  const [bookingDetails, setBookingDetails] = useState<TestTakerBookingDetailsResponse>(initialBookingDetailsData);
  const [currentResultStatus, setCurrentResultStatus] = useState(initialCurrentResultStatus);

  useEffect(() => {
    dispatch({ type: BreadCrumbActions.SHOW_BACK, payload: history.location.state.selectedTestTakerUuid });
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getResultStatusData = (bookingUuid: string) => {
    console.log(bookingUuid);
    getResultStatuses(bookingUuid, props.serviceRequest).subscribe((resultStatusResponse: BookingResultsResponseV2) => {
      resultStatusResponse &&
        resultStatusResponse.bookingDetails &&
        setCurrentResultStatus(resultStatusResponse.bookingDetails.currentResultStatus);
    });
  };

  useEffect(() => {
    getTestTakerBookingDetails(id, props.serviceRequest).subscribe(
      (bookingDetailsData: { bookingData: TestTakerBookingDetailsResponse; status: AsyncResponseStatus }) => {
        bookingDetailsData.bookingData && setBookingDetails(bookingDetailsData.bookingData);
        getResultStatusData(id);
      },
    );
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  return (
    <React.Fragment>
      <TestTakerBookingDetailsHeader
        testTakerName={bookingDetails.testTakerInfo.firstName + ' ' + bookingDetails.testTakerInfo.lastName}
        bookingStatus={currentResultStatus.resultStatusType}
      ></TestTakerBookingDetailsHeader>
      <div className={styles.ttbDetailsGrid}>
        <TestTakerBookingDetailsLeftPanel
          testTakerBookingDetailsResponse={bookingDetails}
          uniqueTestTakerId={history.location.state.selectedUniqueTestTakerId}
          serviceRequest={props.serviceRequest}
          bookingUuid={history.location.state.selectedBookingUuid}
        ></TestTakerBookingDetailsLeftPanel>
        <TestTakerBookingDetailsRightPanel
          photoUrl={bookingDetails.testTakerInfo.photoUrl}
          photoCategory={bookingDetails.testTakerInfo.photoCategory}
        />
      </div>
    </React.Fragment>
  );
};

export default withServiceRequest(TestTakerBookingDetailsPage);
