import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import withServiceRequest, { ServiceRequest } from '../../../services/utils/ServiceRequest';
import { languageService } from '../../../services/Language/LanguageService';
import CloseIcon from '../../../assets/images/Close.svg';

import styles from './RemoveBookingDialog.module.scss';
import { removeBooking } from '../../../services/API/TestTaker/RemoveBooking';
import { AsyncResponseStatus } from '../../../services/Models/Api';

export interface RemoveBookingDialogProps {
  testTakerName: string;
  bookingUuid: string;
  uniqueTestTakerUuid: string;
  serviceRequest: ServiceRequest;
  modalCloseHandler: () => void;
  removeHandler: () => void;
  title: string;
  label: string;
  isExclusionAction: boolean;
}

const RemoveBookingDialog = (props: RemoveBookingDialogProps) => {
  const testTakerLabels = languageService().testTaker;

  const onRemoveBooking = () => {
    removeBooking(
      props.bookingUuid,
      props.uniqueTestTakerUuid,
      props.isExclusionAction,
      props.serviceRequest,
    ).subscribe((res) => {
      if (res && res.status === AsyncResponseStatus.SUCCESS) {
        props.modalCloseHandler();
        props.removeHandler();
      }
    });
  };

  return (
    <UI.ModalDialog>
      <div className={styles.deleteBookingDialog}>
        <div id="rbdTopContentHolder" className={styles.topContentContainer}>
          <img
            id="rbdCloseIcon"
            alt=""
            src={CloseIcon}
            className={styles.closeButton}
            onClick={props.modalCloseHandler}
          />
          <h1 id="rbdTitle">{props.title}</h1>
          <div id="bookingDetailsHolder" className={styles.bookingDetailsHolder}>
            <span id="rbdLabel">{props.label}</span>
            <span>
              {props.testTakerName} ({props.bookingUuid})
            </span>
          </div>
        </div>
        <div id="rbdActionButtonHolder" className={styles.actionButtonContainer}>
          <div>
            <UI.Button
              id="rbdCancelButton"
              color="secondary"
              label={testTakerLabels.removeModalCancelLabel}
              onChange={props.modalCloseHandler}
            />
            <UI.Button
              id="rbdDeleteButton"
              color="primary"
              label={testTakerLabels.removeModalConfirmLabel}
              onChange={onRemoveBooking}
            />
          </div>
        </div>
      </div>
    </UI.ModalDialog>
  );
};

export default withServiceRequest(RemoveBookingDialog);
