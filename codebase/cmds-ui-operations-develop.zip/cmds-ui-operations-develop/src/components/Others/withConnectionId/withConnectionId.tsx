import React, { useContext } from 'react';
import { ConnectorInterface } from '../../../services/utils/ServiceRequest';
import UI from 'ielts-cmds-ui-component-library';
import Loading from '../Loading/Loading';
import { useAuth0 } from '@auth0/auth0-react';
import { languageService } from '../../../services/Language/LanguageService';

interface WithConnectionIdProps {
  children?: React.ReactNode;
}

// : update to the actual type
const withConnectionId =
  <T extends WithConnectionIdProps>(Component: any) =>
  (props: T & WithConnectionIdProps) => {
    const commonLabels = languageService().common;
    const { isAuthenticated } = useAuth0();
    const connectorContext = useContext<ConnectorInterface>(UI.ConnectorContext);
    return isAuthenticated && !connectorContext.connectionId ? (
      <Loading render={() => <h4>{commonLabels.connecting}</h4>} />
    ) : (
      <Component {...props} />
    );
  };

export default withConnectionId;
