import React, { useState } from 'react';
import UI from 'ielts-cmds-ui-component-library';

import CloseIcon from '../../../assets/images/Close.svg';
import playIcon from '../../../assets/images/video.png';
import styles from './IncidentManagementEvidenceDialog.module.scss';
import { languageService } from '../../../services/Language/LanguageService';
import {
  AudioFileFotmat,
  DocumentFileFormat,
  ImageFormat,
  IncidentEvidence,
  VideoFileFormat,
} from '../../../services/Models/IncidentManagement';
import IncidentEvidenceContainer from '../../Organisms/IncidentEvidenceContainer/IncidentEvidenceContainer';
import AudioPlayer from '../../Organisms/AudioPlayer/AudioPlayer';
import { videoControlList } from '../../../constants/IncidentManagement/IncidentEvidenceDialogConstants';
import { initialEvidence } from '../../../constants/IncidentManagement/IncidentManagementViewPanelConstants';

export interface IncidentManagementEvidenceDialogProps {
  title: string;
  modalCloseHandler: () => void;
  audioFiles: IncidentEvidence[];
  videoFiles: IncidentEvidence[];
  documentFiles: IncidentEvidence[];
  isUpload?: boolean;
}

const IncidentManagementEvidenceDialog = (props: IncidentManagementEvidenceDialogProps) => {
  const [currentFile, setCurrentFile] = useState<IncidentEvidence>(initialEvidence);

  const evidenceFileArray: IncidentEvidence[] = [...props.audioFiles, ...props.videoFiles, ...props.documentFiles];
  const incidentManagementLabels = languageService().incidentManagement;

  const palyNext = (url: string) => {
    const index = props.audioFiles.findIndex((file) => file.evidenceUrl === url);
    if (props.audioFiles.length - 1 > index) {
      setCurrentFile(props.audioFiles[index + 1]);
    }
  };

  const playPrevious = (url: string) => {
    const index = props.audioFiles.findIndex((file) => file.evidenceUrl === url);
    if (index > 0) {
      setCurrentFile(props.audioFiles[index - 1]);
    }
  };

  const closeHandler = () => {
    setCurrentFile(initialEvidence);
    props.modalCloseHandler();
  };

  const renderEvidence = (incidentEvidence: IncidentEvidence) => {
    switch (incidentEvidence.evidenceFileExtention.toLowerCase()) {
      case '':
        return <div id="others" />;
      case VideoFileFormat.MP4:
      case VideoFileFormat.MOV:
        return (
          <div>
            {props.videoFiles.length > 0 && (
              <div key={currentFile.evidenceUrl} id="videoContainer">
                <video
                  autoPlay
                  controls
                  controlsList={videoControlList}
                  poster={playIcon}
                  src={currentFile.evidenceUrl}
                  className={styles.videoPlayer}
                  onContextMenu={(e) => e.preventDefault()}
                />
              </div>
            )}
          </div>
        );
      case AudioFileFotmat.MP3:
      case AudioFileFotmat.WAV:
        return (
          <div>
            {props.audioFiles.length > 0 && (
              <AudioPlayer
                autoPlay={true}
                currentUrl={currentFile.evidenceUrl}
                onPlayPrevious={playPrevious}
                onPlayNext={palyNext}
                audioContainer={styles.audioContainer}
                timeDuration={styles.timeDuration}
                imageContainer={styles.imageContainer}
              />
            )}
          </div>
        );
      case ImageFormat.JPEG:
      case ImageFormat.JPG:
      case ImageFormat.PNG:
      case ImageFormat.SVG:
      case ImageFormat.BMP:
        return (
          <div onContextMenu={(e) => e.preventDefault()} className={styles.evidenceImage}>
            <UI.Icon alt="evidenceImage" icon={currentFile.evidenceUrl} id="evidenceImg" />
          </div>
        );
      case DocumentFileFormat.PDF:
      case DocumentFileFormat.TXT:
      case DocumentFileFormat.DOC:
      case DocumentFileFormat.AVI:
      case DocumentFileFormat.DOCX:
      case DocumentFileFormat.WMV:
      case DocumentFileFormat.CSV:
        return (
          <div id="documentContainer">
            {props.documentFiles.length > 0 && (
              <object
                id="evidenceDocument"
                data={`${currentFile.evidenceUrl}#toolbar=0`}
                type="text/html"
                className={styles.documentViewer}
              >
                {incidentManagementLabels.playError}
              </object>
            )}
          </div>
        );
      default:
        return (
          <div className={styles.fileNotSupported} id="fileNotSupported">
            <span>{incidentManagementLabels.fileNotSupported}</span>
          </div>
        );
    }
  };

  return (
    <UI.ModalDialog>
      <div className={styles.container} id="evidenceBox">
        <div className={styles.header}>
          <div>
            <h3 id="evidenceBoxTitle">{props.title}</h3>
          </div>
          <div />
          <img id="closeIcon" alt="" src={CloseIcon} className={styles.closeButton} onClick={() => closeHandler()} />
        </div>
        <div>
          <IncidentEvidenceContainer
            files={evidenceFileArray}
            url={currentFile.evidenceUrl}
            setFile={setCurrentFile}
            containerId={'evidenceList'}
            buttonText={incidentManagementLabels.uploadDocument}
            isUploadEnable={props.isUpload}
          >
            {renderEvidence(currentFile)}
          </IncidentEvidenceContainer>
        </div>
      </div>
    </UI.ModalDialog>
  );
};

export default IncidentManagementEvidenceDialog;
