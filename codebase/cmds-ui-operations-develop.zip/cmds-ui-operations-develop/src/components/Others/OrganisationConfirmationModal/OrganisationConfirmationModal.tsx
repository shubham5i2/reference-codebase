import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import styles from './OrganisationConfirmationModal.module.scss';
import CloseIcon from '../../../assets/images/Close.svg';

export interface OrganisationConfirmationDialogProps {
  headerText: string;
  titleText: string;
  organisationName: string;
  organisationId?: string;
  cancelHandler: () => void;
  confirmHandler: () => void;
}

const OrganisationConfirmationModal = (props: OrganisationConfirmationDialogProps) => {
  const formattedOrgId = props.organisationId ? `(${props.organisationId})` : '';
  return (
    <UI.ModalDialog modalCloseHandler={props.cancelHandler}>
      <div className={styles.OrganisationConfirmationModal}>
        <div id="topContentHolder" className={styles.topContentContainer}>
          <img id="closeIcon" src={CloseIcon} alt="" className={styles.closeButton} onClick={props.cancelHandler} />
          <h1 id="headerLabel">{props.headerText}</h1>
          <p id="titleLabel">{props.titleText}</p>
          <div id="organisationDetailsHolder" className={styles.organisationDetailsHolder}>
            <UI.Typography
              id="organisationDetailLabel"
              label={`${props.organisationName} ${formattedOrgId}`}
              size={'16px'}
            />
          </div>
        </div>
        <div id="actionButtonHolder" className={styles.actionButtonContainer}>
          <div>
            <UI.Button id="cancelButton" color="secondary" label="Cancel" onChange={props.cancelHandler} />
            <UI.Button id="confirmButton" color="primary" label="Confirm" onChange={props.confirmHandler} />
          </div>
        </div>
      </div>
    </UI.ModalDialog>
  );
};
export default OrganisationConfirmationModal;
