import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import styles from './LogoutDialog.module.scss';

export interface LogoutDialogProps {
  headerText: string;
  titleText: string;
  confirmText: string;
  isOpaque: boolean;
  confirmHandler: () => void;
}

const LogoutDialog = (props: LogoutDialogProps) => {
  const { headerText, titleText, confirmText, isOpaque, confirmHandler } = props;
  return (
    <div className={styles.LogoutDialogContainer}>
      <UI.ModalDialog modalCloseHandler={null} modalholderStyle={isOpaque ? styles.opaqueModal : ''}>
        <div className={styles.LogoutDialog}>
          <div id="topContentHolder" className={styles.topContentContainer}>
            <h1 id="headerLabel">{headerText}</h1>
            <p id="titleLabel">{titleText}</p>
          </div>
          <div id="actionButtonHolder" className={styles.actionButtonContainer}>
            <div>
              <UI.Button id="confirmButton" color="primary" label={confirmText} onChange={confirmHandler} />
            </div>
          </div>
        </div>
      </UI.ModalDialog>
    </div>
  );
};
export default LogoutDialog;
