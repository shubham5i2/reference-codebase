import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import withServiceRequest, { ServiceRequest } from '../../../services/utils/ServiceRequest';
import { languageService } from '../../../services/Language/LanguageService';
import CloseIcon from '../../../assets/images/Close.svg';
import { TestTakerGrid } from '../../Organisms/ManageTestTakerGrid/FormatTestTakerData';
import { AddBookingPostData } from '../../Organisms/ManageTestTakerAddBookingGrid/FormatTestTakerAddBookingData';
import { AsyncResponseStatus } from '../../../services/Models/Api';
import { addBooking } from '../../../services/API/TestTaker/AddBooking';

import styles from './AddBookingDialog.module.scss';

export interface AddBookingDailogProps {
  title: string;
  label: string;
  serviceRequest: ServiceRequest;
  modalCloseHandler: () => void;
  addBookingHandler: () => void;
  bookingInfo: TestTakerGrid[];
  postData: AddBookingPostData;
}

const AddBookingDialog = (props: AddBookingDailogProps) => {
  const testTakerLabels = languageService().testTaker;

  const onAddBooking = () => {
    addBooking(props.postData, props.serviceRequest).subscribe((res) => {
      if (res && res.status === AsyncResponseStatus.SUCCESS) {
        props.modalCloseHandler();
        props.addBookingHandler();
      }
    });
  };

  return (
    <UI.ModalDialog>
      <div className={styles.addBookingDialog}>
        <div id="abdTopContentHolder" className={styles.topContentContainer}>
          <img
            id="abdCloseIcon"
            alt=""
            src={CloseIcon}
            className={styles.closeButton}
            onClick={props.modalCloseHandler}
          />
          <h1 id="abdTitle">{props.title}</h1>
          <div id="bookingDetailsHolder" className={styles.bookingDetailsHolder}>
            <span id="abdLabel">{props.label}</span>
            <span className={styles.bookingDetailsContent}>
              {props.bookingInfo.map((item: TestTakerGrid) => {
                return (
                  <span key={item.bookingUuid}>
                    <span>
                      {item.firstName} {item.lastName} ({item.bookingUuid})
                    </span>
                    <br />
                  </span>
                );
              })}
            </span>
          </div>
        </div>
        <div id="abdActionButtonHolder" className={styles.actionButtonContainer}>
          <div>
            <UI.Button
              id="abdCancelButton"
              color="secondary"
              label={testTakerLabels.removeModalCancelLabel}
              onChange={props.modalCloseHandler}
            />
            <UI.Button
              id="abdConfirmButton"
              color="primary"
              label={testTakerLabels.removeModalConfirmLabel}
              onChange={onAddBooking}
            />
          </div>
        </div>
      </div>
    </UI.ModalDialog>
  );
};

export default withServiceRequest(AddBookingDialog);
