import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import withServiceRequest, { ServiceRequest } from '../../../services/utils/ServiceRequest';
import { languageService } from '../../../services/Language/LanguageService';
import CloseIcon from '../../../assets/images/Close.svg';
import { PreReleaseSearchResult } from '../../../services/Models/PreReleaseManagement';
import styles from './PreReleaseDialog.module.scss';

export interface PreReleaseDailogProps {
  title: string;
  label: string;
  serviceRequest: ServiceRequest;
  modalCloseHandler: () => void;
  confirmationHandler: (id: string) => void;
  bookingInfo: PreReleaseSearchResult[];
  statusUuId: string;
}

const PreReleaseDialog = (props: PreReleaseDailogProps) => {
  const testTakerLabels = languageService().testTaker;
  const preReleaseHandler = () => {
    props.modalCloseHandler();
    props.confirmationHandler(props.statusUuId);
  };
  const bookingDataDisplayHandler = (bookingInfo: PreReleaseSearchResult[]) => {
    return bookingInfo
      .sort((first, second) =>
        first.centreId > second.centreId
          ? 1
          : first.centreId === second.centreId
          ? first.uniqueTestTakerId > second.uniqueTestTakerId
            ? 1
            : -1
          : -1,
      )
      .map((item: PreReleaseSearchResult) => {
        return (
          <span key={item.bookingUuid}>
            <span className={styles.centreIdContent}>{item.centreId}</span>
            <span className={styles.uuIdContent}>{item.uniqueTestTakerId}</span>
            <br />
          </span>
        );
      });
  };
  return (
    <UI.ModalDialog>
      <div className={styles.preReleaseDialog}>
        <div id="prdTopContentHolder" className={styles.topContentContainer}>
          <img
            id="prdCloseIcon"
            alt=""
            src={CloseIcon}
            className={styles.closeButton}
            onClick={props.modalCloseHandler}
          />
          <h1 id="prdTitle">{props.title}</h1>
          <div id="preReleaseDetailsHolder" className={styles.bookingDetailsHolder}>
            <span id="prdLabel">{props.label}</span>
            <span className={styles.bookingDetailsContent}>{bookingDataDisplayHandler(props.bookingInfo)}</span>
          </div>
        </div>
        <div id="prdActionButtonHolder" className={styles.actionButtonContainer}>
          <div>
            <UI.Button
              id="prdCancelButton"
              color="secondary"
              label={testTakerLabels.removeModalCancelLabel}
              onChange={props.modalCloseHandler}
            />
            <UI.Button
              id="prdConfirmButton"
              color="primary"
              label={testTakerLabels.removeModalConfirmLabel}
              onChange={preReleaseHandler}
            />
          </div>
        </div>
      </div>
    </UI.ModalDialog>
  );
};

export default withServiceRequest(PreReleaseDialog);
