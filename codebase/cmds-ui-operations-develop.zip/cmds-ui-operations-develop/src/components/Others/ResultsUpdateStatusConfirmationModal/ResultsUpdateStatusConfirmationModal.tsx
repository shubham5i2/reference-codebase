import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import styles from './ResultsUpdateStatusConfirmationModal.module.scss';
import CloseIcon from '../../../assets/images/Close.svg';
import { languageService } from '../../../services/Language/LanguageService';
import { useStateValue } from '../../../Store/helpers/UseStateValue';
import { ResultsUpdateStatusData } from '../../../services/Models/Result';
import { getValue, statusStyle } from '../../utils/utilities';

export interface ResultsUpdateStatusConfirmationModalProps {
  headerText: string;
  titleText: string;
  resultsStatusData: ResultsUpdateStatusData;
  cancelHandler: () => void;
  confirmHandler: () => void;
}

const ResultsUpdateStatusConfirmationModal = (props: ResultsUpdateStatusConfirmationModalProps) => {
  const { state } = useStateValue();
  const resultLabels = languageService().result;
  const resultStatus = state.referenceData.resultStatus?.transformedData?.find(
    (resultStatus: { resultsStatusTypeUuid: string }) =>
      resultStatus.resultsStatusTypeUuid === props.resultsStatusData.resultStatusTypeUuid,
  );
  const resultStatusLabel = state.referenceData.resultStatus?.transformedData
    ?.find(
      (resultStatus: { resultsStatusTypeUuid: string }) =>
        resultStatus.resultsStatusTypeUuid === props.resultsStatusData.resultStatusTypeUuid,
    )
    ?.resultStatusLabels?.find(
      (resultStatusLabel: { resultStatusLabelUuid: string }) =>
        resultStatusLabel.resultStatusLabelUuid === props.resultsStatusData.resultStatusLabelUuid,
    );
  const resultStatusComments = state.referenceData.resultStatus?.transformedData
    ?.find(
      (resultStatus: { resultsStatusTypeUuid: string }) =>
        resultStatus.resultsStatusTypeUuid === props.resultsStatusData.resultStatusTypeUuid,
    )
    ?.resultStatusLabels?.find(
      (resultStatusLabel: { resultStatusLabelUuid: string }) =>
        resultStatusLabel.resultStatusLabelUuid === props.resultsStatusData.resultStatusLabelUuid,
    )
    ?.resultStatusComments.find(
      (resultStatusComments: { resultsStatusCommentUuid: string }) =>
        resultStatusComments.resultsStatusCommentUuid === props.resultsStatusData.resultStatusCommentUuid,
    );

  return (
    <UI.ModalDialog modalCloseHandler={props.cancelHandler}>
      <div className={styles.resultsUpdateStatusConfirmationModal}>
        <div id="topContentHolder" className={styles.topContentContainer}>
          <img id="closeIcon" src={CloseIcon} alt="" className={styles.closeButton} onClick={props.cancelHandler} />
          <h1 id="headerLabel">{props.headerText}</h1>
          <p id="titleLabel">{props.titleText}</p>
          <div id="resultsUpdateStatusHolder" className={styles.organisationDetailsHolder}>
            <div className={styles.columnTwo}>
              <UI.DisplayLabelValuePair
                id="newResultsStatus"
                label={resultLabels.newResultsStatusLabel}
                value={
                  <UI.Status
                    status={statusStyle[getValue(resultStatus?.resultsStatusType).toUpperCase()]}
                    label={getValue(resultStatus?.resultsStatusType)}
                  />
                }
                type="regular"
                size={14}
              />
              <UI.DisplayLabelValuePair
                id="newResultsStatusLabel"
                label={resultLabels.newResultsStatusLabelLabel}
                value={resultStatusLabel?.resultStatusLabel}
                type="regular"
                size={14}
              />
              <UI.DisplayLabelValuePair
                id="newResultsStatusComment"
                label={resultLabels.newResultsStatusCommentLabel}
                value={resultStatusComments?.resultStatusCommentText || props.resultsStatusData.resultStatusCommentText}
                type="regular"
                size={14}
              />
            </div>
          </div>
        </div>
        <div id="actionButtonHolder" className={styles.actionButtonContainer}>
          <div>
            <UI.Button id="cancelButton" color="secondary" label="Cancel" onChange={props.cancelHandler} />
            <UI.Button id="confirmButton" color="primary" label="Confirm" onChange={props.confirmHandler} />
          </div>
        </div>
      </div>
    </UI.ModalDialog>
  );
};
export default ResultsUpdateStatusConfirmationModal;
