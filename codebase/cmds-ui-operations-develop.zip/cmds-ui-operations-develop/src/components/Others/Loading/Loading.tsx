import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import Styles from './Loading.module.scss';

interface LoadingProps {
  render: () => React.JSX.Element;
}

const Loading = (props: LoadingProps) => (
  <div className={Styles.spinner}>
    <UI.ModalDialog>{props.render()}</UI.ModalDialog>
  </div>
);

export default Loading;
