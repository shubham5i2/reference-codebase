import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import styles from './ViewOrganisationsListModal.module.scss';
import { DropDownDataSource } from '../../../services/Models/UIModels';

export interface ViewOrganisationsListModalProps {
  headerText: string;
  titleText: string;
  organisationList?: DropDownDataSource[];
  closeHandler: () => void;
  deliveryOrgSelectionHandler: (org: string) => void;
}

const ViewOrganisationsListModal = (props: ViewOrganisationsListModalProps) => {
  return (
    <UI.ModalDialog modalCloseHandler={props.closeHandler}>
      <div className={styles.additionalDeliveryModal}>
        <div id="topContentHolder" className={styles.topContentContainer}>
          <h1 id="headerLabel">{props.headerText}</h1>
          <p id="titleLabel">{props.titleText}</p>
          <div id="organisationListHolder" className={styles.additionalDeliveryHolder}>
            {(props.organisationList || []).map((deliveryOrg) => {
              return (
                <p key={deliveryOrg.value} onClick={() => props.deliveryOrgSelectionHandler(deliveryOrg.value)}>
                  <span className={styles.link}>{deliveryOrg.text}</span>
                </p>
              );
            })}
          </div>
        </div>
        <div id="actionButtonHolder" className={styles.actionButtonContainer}>
          <div>
            <UI.Button id="closeButton" color="secondary" label="Close" onChange={props.closeHandler} />
          </div>
        </div>
      </div>
    </UI.ModalDialog>
  );
};
export default ViewOrganisationsListModal;
