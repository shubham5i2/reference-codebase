import React from 'react';
import styles from './HoldOnUpdateDialog.module.scss';
import { updateOnHold } from '../../../services/API/Result/OnHoldUpdate';
import withServiceRequest, { ServiceRequest } from '../../../services/utils/ServiceRequest';
import { languageService } from '../../../services/Language/LanguageService';
import { AsyncResponseStatus, AsyncResponse } from '../../../services/Models/Api';
import { useStateValue } from '../../../Store/helpers/UseStateValue';
import * as ManageResultActions from '../../../Store/Actions/ManageResultActions';
import { ResultsSearchResult } from '../../../services/Models/Result';
import GenericPopup, { TitlePosition, ButtonPosition, DialogType } from '../../Organisms/GenericPopup/GenericPopup';
import { UIButtonType } from '../../../services/Models/UIModels';

interface HoldOnUpdateDialogProps {
  data: ResultsSearchResult[] | ResultsSearchResult;
  serviceRequest: ServiceRequest;
  title: string;
  label: string;
  modalCloseHandler: () => void;
  onRemoveOnHold: (id: number) => void;
}

const HoldOnUpdateDialog = (props: HoldOnUpdateDialogProps) => {
  const resultsLabels = languageService().result;
  const { dispatch } = useStateValue();
  const getMessage = (onHoldStatus: boolean) => {
    if (onHoldStatus) {
      return Array.isArray(props.data)
        ? resultsLabels.updateMulitpleToOnHoldSuccessMsg
        : resultsLabels.updateToOnHoldSuccessMsg;
    } else {
      return Array.isArray(props.data)
        ? resultsLabels.updateMultipleToNotOnHoldSuccessMsg
        : resultsLabels.updateToNotOnHoldSuccessMsg;
    }
  };
  const onUpdateOnHold = (onHoldStatus: boolean) => {
    const bookingUuidList = Array.isArray(props.data)
      ? props.data.map((item) => item.bookingUuid)
      : props.data.bookingUuid;
    updateOnHold(bookingUuidList, onHoldStatus, props.serviceRequest).subscribe((res: AsyncResponse) => {
      if (res && res.status === AsyncResponseStatus.SUCCESS) {
        window.scrollTo(0, 0);
        dispatch({
          type: ManageResultActions.UPDATE_ONHOLD,
          payload: {
            onHoldStatus,
            bookingUuidList: Array.isArray(bookingUuidList) ? bookingUuidList : [bookingUuidList],
          },
        });
        dispatch({
          type: ManageResultActions.RESULTS_UPDATE_MESSAGE,
          payload: getMessage(onHoldStatus),
        });
        props.modalCloseHandler();
      }
    });
  };
  const buttonData = [
    {
      id: 'addonhold',
      text: resultsLabels.addOnHoldButtonText,
      type: UIButtonType.PRIMARY,
      onChange: () => onUpdateOnHold(true),
    },
    {
      id: 'removeonhold',
      text: resultsLabels.removeOnHoldButtonText,
      type: UIButtonType.SECONDARY,
      onChange: () => onUpdateOnHold(false),
    },
  ];

  return (
    <div className={styles.holdOnUpdateDialog}>
      <GenericPopup
        id="ConfirmButton"
        title={props.title}
        className={styles.customStyle}
        titlePosition={TitlePosition.DEFAULT}
        buttonStyle={ButtonPosition.RIGHT}
        dialogType={DialogType.CUSTOM}
        label={props.label}
        buttonData={buttonData}
        modalCloseHandler={props.modalCloseHandler}
      >
        <div className={styles.modalContent}>
          <label className={styles.subHeading}>
            {resultsLabels.onHoldUpdateModalContent1 +
              (Array.isArray(props.data)
                ? props.data.length > 0
                  ? props.data.length + resultsLabels.onHoldUpdateModalContent2Plural
                  : '1' + resultsLabels.onHoldUpdateModalContent2
                : '1' + resultsLabels.onHoldUpdateModalContent2)}
          </label>
        </div>
      </GenericPopup>
    </div>
  );
};

export default withServiceRequest(HoldOnUpdateDialog);
