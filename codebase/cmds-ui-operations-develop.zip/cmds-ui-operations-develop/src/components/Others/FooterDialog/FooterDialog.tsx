import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import styles from './FooterDialog.module.scss';
import CloseIcon from '../../../assets/images/Close.svg';
import { validateEmail } from '../../utils/utilities';

export interface FooterDialogProps {
  id: string;
  headerText: string;
  pageContent: string[];
  cancelHandler: () => void;
}

const FooterDialog = (props: FooterDialogProps) => {
  return (
    <div className={styles.footerDialog}>
      <UI.ModalDialog modalCloseHandler={props.cancelHandler}>
        <div className={styles.footerDialogModal}>
          <div id={props.id + 'TopContentHolder'} className={styles.topContentContainer}>
            <img
              id={props.id + 'CloseIcon'}
              src={CloseIcon}
              alt=""
              className={styles.closeButton}
              onClick={props.cancelHandler}
            />
            <h1 id={props.id + 'HeaderLabel'}>{props.headerText}</h1>
            <div id={props.id + 'FooterDialogHolder'}>
              <span id={props.id + 'Content'}>
                {props.pageContent?.map((content, idx) =>
                  !validateEmail(content) ? (
                    <p key={`Footer_${idx}`}>{content}</p>
                  ) : (
                    <p key={`Footer_${idx}`}>
                      <a href={'mailto:' + content} target="_blank" rel="noopener noreferrer">
                        {content}
                      </a>
                    </p>
                  ),
                )}
              </span>
            </div>
          </div>
        </div>
      </UI.ModalDialog>
    </div>
  );
};
export default FooterDialog;
