import React from 'react';
import { AssignGroupData } from '../../../../services/Models/StaffManagement';
import { languageService } from '../../../../services/Language/LanguageService';
import { dateFormatter } from '../../../utils/utilities';

export interface AssignUserGroupListProps {
  userGroupListStyle: string;
  userDetailHolderStyle: string;
  userGroups: AssignGroupData[];
}

const AssignUserGroupList = (props: AssignUserGroupListProps) => {
  const smLabels = languageService().staffManagement;
  const getUserGroupList = () => {
    const usergroupCount = props.userGroups.length;
    return props.userGroups.map((usergroup: AssignGroupData, index: number) => (
      <li id="assignUserGroupListElement" key={usergroup.userGroup}>
        {usergroupCount > 1 ? (
          <label>
            {' '}
            {smLabels.assignment.toUpperCase()} {index + 1}{' '}
          </label>
        ) : null}
        <div id="userGroupHolder" className={props.userDetailHolderStyle}>
          <label id="userGroupLabel">{smLabels.userGroup}</label>
          <label id="userGroupValue">{usergroup.userGroupName}</label>
        </div>
        <div id="userDurationHolder" className={props.userDetailHolderStyle}>
          <label id="durationLabel">{smLabels.duration}</label>
          <label id="durationValue">{`${dateFormatter(usergroup.dateRange.startDate)} - ${dateFormatter(
            usergroup.dateRange.endDate,
          )}`}</label>
        </div>
        <div id="userLocationHolder" className={props.userDetailHolderStyle}>
          <label id="locationLabel">{smLabels.location}</label>
          <label id="locationValue">{usergroup.locationName}</label>
        </div>
      </li>
    ));
  };
  return (
    <ul id="assignUserGroupList" className={props.userGroupListStyle}>
      {getUserGroupList()}
    </ul>
  );
};

export default AssignUserGroupList;
