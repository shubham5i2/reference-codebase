import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import styles from './AssignUserGroupDialog.module.scss';
import CloseIcon from '../../../assets/images/Close.svg';
import AssignUserGroupList from './AssignUserGroupList/AssignUserGroupList';
import { AssignGroupData } from '../../../services/Models/StaffManagement';
import { languageService } from '../../../services/Language/LanguageService';

export interface AssignUserGroupDialogProps {
  modalCloseHandler?: () => void;
  userGroups: AssignGroupData[];
  assignUserHandler: () => void;
}

const AssignUserGroupDialog = (props: AssignUserGroupDialogProps) => {
  const smLabels = languageService().staffManagement;
  return (
    <UI.ModalDialog modalCloseHandler={props.modalCloseHandler}>
      <div className={styles.assignUserGroupDialog}>
        <div id="topContentHolder" className={styles.topContentContainer}>
          <img id="closeIcon" src={CloseIcon} alt="" className={styles.closeButton} onClick={props.modalCloseHandler} />
          <h1 id="title">{smLabels.assignGroupsTitle}</h1>
          <p id="label">{smLabels.assignGroupDialogMessage}</p>
          <AssignUserGroupList
            userGroupListStyle={styles.userGroupListStyle}
            userDetailHolderStyle={styles.userDetailHolder}
            userGroups={props.userGroups}
          />
        </div>
        <div id="actionButtonHolder" className={styles.actionButtonContainer}>
          <div>
            <UI.Button id="cancelButton" color="secondary" label={smLabels.cancel} onChange={props.modalCloseHandler} />
            <UI.Button id="assignButton" color="primary" label={smLabels.assign} onChange={props.assignUserHandler} />
          </div>
        </div>
      </div>
    </UI.ModalDialog>
  );
};
export default AssignUserGroupDialog;
