import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import styles from './DeleteUserDialog.module.scss';
import GroupIcon from '../../../assets/images/Group.svg';
import CloseIcon from '../../../assets/images/Close.svg';
import { deleteUser } from '../../../services/API/ManageUser/DeleteUser';
import withServiceRequest, { ServiceRequest } from '../../../services/utils/ServiceRequest';
import { languageService } from '../../../services/Language/LanguageService';
import { AsyncResponseStatus } from '../../../services/Models/Api';

interface DeleteUserDialogProps {
  status: string;
  staffId: string;
  serviceRequest: ServiceRequest;
  title: string;
  userName: string;
  label: string;
  userRowIdx: number;
  emailId: string;
  modalCloseHandler: () => void;
  deleteUserHandler: (userRowIdx: number, staffId: string, userName: string) => void;
}

const DeleteUserDialog = (props: DeleteUserDialogProps) => {
  const smLabels = languageService().staffManagement;
  const getStatusStyle = () => {
    return props.status.toLowerCase() === 'active' ? 'active' : 'inActive';
  };

  const onDeleteUser = () => {
    deleteUser(props.staffId, props.serviceRequest).subscribe((res) => {
      if (res && res.status === AsyncResponseStatus.SUCCESS && res.body) {
        props.modalCloseHandler();
        props.deleteUserHandler(props.userRowIdx, props.staffId, props.userName);
      }
    });
  };

  return (
    <UI.ModalDialog modalCloseHandler={props.modalCloseHandler}>
      <div className={styles.deleteUserDialog}>
        <div id="topContentHolder" className={styles.topContentContainer}>
          <img id="closeIcon" alt="" src={CloseIcon} className={styles.closeButton} onClick={props.modalCloseHandler} />
          <img id="warningIcon" alt="" src={GroupIcon} />
          <h1 id="title">{props.title}</h1>
          <p id="label">{props.label}</p>
          <div id="userNameHolder" className={styles.userDetailHolder}>
            <label id="userNameLabel">{smLabels.user}</label>
            <label id="userNameValue">{props.userName}</label>
          </div>
          <div id="staffIdHolder" className={styles.userDetailHolder}>
            <label id="staffIDLabel">{smLabels.staffId}</label>
            <label id="staffIDValue">{props.staffId}</label>
          </div>
          <div id="emailHolder" className={styles.userDetailHolder}>
            <label id="emailLabel">{smLabels.email}</label>
            <label id="emailValue">{props.emailId}</label>
          </div>
          <div id="statusHolder" className={styles.userDetailHolder}>
            <label id="statusLabel">{smLabels.status}</label>
            <div className={styles.statusContainer}>
              <UI.Status id="statusValue" status={getStatusStyle()} label={props.status} />
            </div>
          </div>
        </div>
        <div id="actionButtonHolder" className={styles.actionButtonContainer}>
          <div>
            <UI.Button id="cancelButton" color="secondary" label={smLabels.cancel} onChange={props.modalCloseHandler} />
            <UI.Button id="deleteButton" color="primary" label={smLabels.delete} onChange={onDeleteUser} />
          </div>
        </div>
      </div>
    </UI.ModalDialog>
  );
};

export default withServiceRequest(DeleteUserDialog);
