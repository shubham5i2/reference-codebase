import React from 'react';
import UI from 'ielts-cmds-ui-component-library';

import styles from './TestTakerTRFGrid.module.scss';
import { TestTakerTRFSortOption } from '../../../services/Models/TestTakerTRF';
import TestTakerTRFGridCell from '../TestTakerTRFGridCell/TestTakerTRFGridCell';
import { TestTakerTRFGridCellType } from '../TestTakerTRFGrid/TestTakerTRFGridConstants';
import testTakerTRFLabels from '../../../services/Language/en/en.testtakertrf';
import { Cell, Column } from 'react-table';
import { formatDate, formatDateAsUTC } from '../../utils/utilities';
import { ColumnSort, UIGridState } from '../../../services/Models/UIModels';

export interface TestTakerTRFGridData {
  organisationId?: string;
  organisationName?: string;
  organisationAddress?: string;
  selectionDate?: string;
  personDepartment?: string;
  caseNumber?: string;
  confirmationStatus?: string;
  confirmationStatusChangedDatetime?: string;
}

interface TestTakerTRFGridProps {
  data: TestTakerTRFGridData[];
  gridState: UIGridState;
  pageNumber: number;
  sort?: boolean;
  onColumnSort?: (column: ColumnSort) => void;
  sortOptionArray?: { sortType: string; sortBy: string }[];
}

const TestTakerTRFGrid = (props: TestTakerTRFGridProps) => {
  const formattedData = props.data;

  const getTestTakerTRFGridCellItem = (cellProps: Cell, name: string) => {
    return <TestTakerTRFGridCell id={name} cellType={name} value={cellProps.value} />;
  };

  const columns = [
    {
      Header: {
        label: testTakerTRFLabels.organisationId.toUpperCase(),
        name: TestTakerTRFSortOption.ORGANISATION_ID,
      },
      accessor: 'organisationId',
      Cell: (cellProps: Cell) => getTestTakerTRFGridCellItem(cellProps, TestTakerTRFGridCellType.ORGANISATIONUUID),
    },
    {
      Header: {
        label: testTakerTRFLabels.organisationName.toUpperCase(),
        name: TestTakerTRFSortOption.ORGANISATION_NAME,
      },
      accessor: 'organisationName',
      sortType: 'basic',
      Cell: (cellProps: Cell) => getTestTakerTRFGridCellItem(cellProps, TestTakerTRFSortOption.ORGANISATION_NAME),
    },
    {
      Header: {
        label: testTakerTRFLabels.organisationAddress.toUpperCase(),
        name: TestTakerTRFSortOption.ORGANISATION_ADDRESS,
      },
      accessor: 'organisationAddress',
      sortType: 'basic',
      Cell: (cellProps: Cell) => (
        <TestTakerTRFGridCell
          id="organisationAddress"
          cellType={TestTakerTRFGridCellType.ORGANISATIONADDRESS}
          value={cellProps.value}
        />
      ),
    },
    {
      Header: {
        label: testTakerTRFLabels.selectionDate.toUpperCase(),
        name: TestTakerTRFSortOption.SELECTION_DATE,
      },
      accessor: 'selectionDate',
      sortType: 'basic',
      Cell: (cellProps: Cell) => (
        <TestTakerTRFGridCell
          id="selectionDate"
          cellType={TestTakerTRFGridCellType.SELECTIONDATE}
          value={`${formatDateAsUTC(new Date(cellProps.value))}`}
          // value={`${cellProps.value}`}
        />
      ),
    },
    {
      Header: {
        label: `${testTakerTRFLabels.person}/${testTakerTRFLabels.department}`.toUpperCase(),
        name: TestTakerTRFSortOption.PERSON_DEPARTMENT,
      },
      accessor: 'personDepartment',
      sortType: 'basic',
      Cell: (cellProps: Cell) => getTestTakerTRFGridCellItem(cellProps, TestTakerTRFGridCellType.PERSONDEPARTMENT),
    },
    {
      Header: {
        label: testTakerTRFLabels.organisationType.toUpperCase(),
        name: TestTakerTRFSortOption.ORGANISATION_TYPE,
      },
      accessor: 'organisationType',
      sortType: 'basic',
      Cell: (cellProps: Cell) => getTestTakerTRFGridCellItem(cellProps, TestTakerTRFGridCellType.ORGANISATIONTYPE),
    },
    {
      Header: {
        label: testTakerTRFLabels.confirmationStatus.toUpperCase(),
        name: TestTakerTRFSortOption.CONFIRMATION_STATUS,
      },
      accessor: 'confirmationStatus',
      sortType: 'basic',
      Cell: (cellProps: Cell) => getTestTakerTRFGridCellItem(cellProps, TestTakerTRFGridCellType.CONFIRMATIONSTATUS),
    },
    {
      Header: {
        label: testTakerTRFLabels.confirmationStatusChangeDate.toUpperCase(),
        name: TestTakerTRFSortOption.CONFIRMATION_STATUS_CHANGED_DATE_TIME,
      },
      accessor: 'confirmationStatusChangedDatetime',
      sortType: 'basic',
      Cell: (cellProps: Cell) => (
        <TestTakerTRFGridCell
          id="confirmationStatusChangedDatetime"
          cellType={TestTakerTRFGridCellType.CONFIRMATIONSTATUSCHANGEDDATETIME}
          value={`${formatDate(new Date(cellProps.value), 'dd MMM yyyy')}`}
        />
      ),
    },
    {
      Header: {
        label: testTakerTRFLabels.printStatus.toUpperCase(),
        name: TestTakerTRFSortOption.PRINT_STATUS,
      },
      accessor: 'printStatus',
      sortType: 'basic',
      Cell: (cellProps: Cell) => getTestTakerTRFGridCellItem(cellProps, TestTakerTRFGridCellType.PRINTSTATUS),
    },
    {
      Header: {
        label: testTakerTRFLabels.printStatusDatetime.toUpperCase(),
        name: TestTakerTRFSortOption.PRINT_STATUS_DATE_TIME,
      },
      accessor: 'printStatusDatetime',
      sortType: 'basic',
      Cell: (cellProps: Cell) => (
        <TestTakerTRFGridCell
          id="printStatusDatetime"
          cellType={TestTakerTRFGridCellType.PRINTSTATUSDATETIME}
          value={`${formatDate(new Date(cellProps.value), 'dd-MM-yyyy')} ${' '} ${formatDate(
            new Date(cellProps.value),
            'HH:mm bb',
          )}`}
        />
      ),
    },
    {
      Header: {
        label: testTakerTRFLabels.caseNumber.toUpperCase(),
        name: TestTakerTRFSortOption.CASE_NUMBER,
      },
      accessor: 'caseNumber',
      sortType: 'basic',
      Cell: (cellProps: Cell) => getTestTakerTRFGridCellItem(cellProps, TestTakerTRFGridCellType.CASENUMBER),
    },
  ] as Column[];

  return (
    <React.Fragment>
      <div id="testTakerTRFGrid" className={styles.testTakerTRFGrid}>
        <UI.Grid
          id="testTakerTRFGrid"
          hidePagination={true}
          columns={columns}
          data={formattedData}
          initialState={props.gridState.initialState}
          totalRecords={props.gridState.totalRecords}
          currentPage={props.gridState.selectedPage}
          selectedOptionValue={props.gridState.selectedOptionValue}
          onColumnSort={props.onColumnSort}
          sortOption={props.sortOptionArray}
          sort={props.sort}
        />
      </div>
    </React.Fragment>
  );
};

export default TestTakerTRFGrid;
