import { TestTakerTRFGridData } from './TestTakerTRFGrid';

export const TestTakerTRFGridCellType = {
  ORGANISATIONUUID: 'ORGANISATIONUUID',
  ORGANISATIONNAME: 'ORGANISATIONNAME',
  ORGANISATIONADDRESS: 'ORGANISATIONADDRESS',
  SELECTIONDATE: 'SELECTIONDATE',
  CASENUMBER: 'CASENUMBER',
  PERSONDEPARTMENT: 'PERSONDEPARTMENT',
  CONFIRMATIONSTATUS: 'CONFIRMATIONSTATUS',
  CONFIRMATIONSTATUSCHANGEDDATETIME: 'CONFIRMATIONSTATUSCHANGEDDATETIME',
  PRINTSTATUS: 'PRINTSTATUS',
  PRINTSTATUSDATETIME: 'PRINTSTATUSDATETIME',
  ORGANISATIONTYPE: 'ORGANISATIONTYPE',
};

export const pageSizeOptions = [
  { text: '10', value: 10 },
  { text: '25', value: 25 },
  { text: '50', value: 50 },
];

const BaseTestTakerTRFGridMockData: TestTakerTRFGridData[] = [
  {
    organisationId: 'e873fca7-849b-4e3b-8dfc-b6b5108608db',
    organisationName: 'Hull College',
    organisationAddress: "6 Waterloo Pl, St. James's, London SW1Y 4AN, United Kingdom",
    selectionDate: '2022-02-04T06:03:14.643Z',
    confirmationStatus: 'CONFIRMED',
    confirmationStatusChangedDatetime: '2022-02-04T06:03:14.643Z',
    caseNumber: 'string',
    personDepartment: 'string',
  },
  {
    organisationId: 'e873fca7-849b-4e3b-8dfc-b6b5108608db',
    organisationName: 'Hull College',
    organisationAddress: "6 Waterloo Pl, St. James's, London SW1Y 4AN, United Kingdom",
    selectionDate: '2022-02-04T06:03:14.643Z',
    confirmationStatus: 'CONFIRMED',
    confirmationStatusChangedDatetime: '2022-02-04T06:03:14.643Z',
    caseNumber: 'string',
    personDepartment: 'string',
  },
  {
    organisationId: 'e873fca7-849b-4e3b-8dfc-b6b5108608db',
    organisationName: 'Hull College',
    organisationAddress: "6 Waterloo Pl, St. James's, London SW1Y 4AN, United Kingdom",
    selectionDate: '2022-02-04T06:03:14.643Z',
    confirmationStatus: 'CONFIRMED',
    confirmationStatusChangedDatetime: '2022-02-04T06:03:14.643Z',
    caseNumber: 'string',
    personDepartment: 'string',
  },
  {
    organisationId: 'e873fca7-849b-4e3b-8dfc-b6b5108608db',
    organisationName: 'Hull College',
    organisationAddress: "6 Waterloo Pl, St. James's, London SW1Y 4AN, United Kingdom",
    selectionDate: '2022-02-04T06:03:14.643Z',
    confirmationStatus: 'CONFIRMED',
    confirmationStatusChangedDatetime: '2022-02-04T06:03:14.643Z',
    caseNumber: 'string',
    personDepartment: 'string',
  },
];

export const TestTakerTRFGridMockData = [
  BaseTestTakerTRFGridMockData,
  BaseTestTakerTRFGridMockData,
  BaseTestTakerTRFGridMockData,
  BaseTestTakerTRFGridMockData,
].flat();
