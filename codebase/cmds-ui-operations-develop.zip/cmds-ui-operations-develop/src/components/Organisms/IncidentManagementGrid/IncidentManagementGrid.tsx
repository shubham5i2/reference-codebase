import React, { useState, useEffect } from 'react';
import UI from 'ielts-cmds-ui-component-library';
import { useAuth0 } from '@auth0/auth0-react';

import styles from './IncidentManagementGrid.module.scss';
import { Action } from '../../../services/Models/Api';

import { getTestCenter } from '../../utils/utilities';
import { ExpandedGridType, GridProps } from '../../../services/Models/UIModels';
import { ColumnsData, IncidentSearchResponse } from '../../../services/Models/IncidentManagement';
import { useHistory } from 'react-router-dom';
import { IncidentActionType } from '../../../constants/IncidentManagement/IncidentManagementGridConstants';
import { languageService } from '../../../services/Language/LanguageService';
import IncidentManagementExtendedRow from '../IncidentManagementExtendedRow/IncidentManagementExtendedRow';
import NoResultsFound from '../../Molecules/NoResultsFound/NoResultsFound';
import { ServiceRequest } from '../../../services/utils/ServiceRequest';
import { getColumns } from './IncidentGridColumns';
import * as IncidentManagementActions from '../../../Store/Actions/IncidentManagementActions';
import { useStateValue } from '../../../Store/helpers/UseStateValue';

interface IcidentManagementGridProps extends GridProps {
  data: IncidentSearchResponse[];
  isSearchResults: boolean;
  serviceRequest: ServiceRequest;
  isLoading: boolean;
}

const IncidentManagementGrid = (props: IcidentManagementGridProps) => {
  const [selectedToolTipIndex, setSelectedToolTipIndex] = useState<number | null>(null);
  const [toggleExpansion, setToggleExpansion] = useState<string[]>([]);

  const history = useHistory();

  const { user } = useAuth0();
  const { state, dispatch } = useStateValue();
  const { testcentersResponse } = state.incidentManagement.testCenters;

  const { data: testTakerData } = props;
  const incidentManagementLabels = languageService().incidentManagement;

  useEffect(() => {
    setToggleExpansion([]);
  }, [props.data]);

  useEffect(() => {
    getTestCenter(
      user,
      props.serviceRequest,
      'incidentManagement.testCenters.testcentersData',
      IncidentManagementActions.SAVE_TESTCENTERS,
      dispatch,
      state,
    );
    // eslint-disable-next-line
  }, []);

  const incidentActionsHandler = (action: Action, index: number) => {
    switch (action.type) {
      case IncidentActionType.VIEW_DETAILS:
        history.push(`/incidentmanagement/incidentmanagementviewdetails/${props.data[index].bookingUuid}`, {
          stateIncidentUuid: props.data[index].incidentUuid,
        });
        break;
    }
    setSelectedToolTipIndex(null);
  };

  const iconClickHandler = (index: number) => {
    const testTakerId = testTakerData[index].incidentUuid;
    const dataIndex = toggleExpansion.indexOf(testTakerId);
    if (dataIndex >= 0) {
      setToggleExpansion([...toggleExpansion.filter((item) => item !== toggleExpansion[dataIndex])]);
    } else {
      setToggleExpansion([testTakerId, ...toggleExpansion]);
    }
  };

  const columns = getColumns({
    toggleExpansion,
    iconClickHandler,
    testTakerData,
    selectedToolTipIndex,
    incidentActionsHandler,
    testcentersResponse,
  } as ColumnsData);

  const populateExpandedRow = (props: ExpandedGridType) => {
    const expandedData = testTakerData.find(
      (testTaker: IncidentSearchResponse) => testTaker.incidentUuid === props.rowData.incidentUuid,
    );
    return <IncidentManagementExtendedRow expandedData={expandedData} />;
  };

  return (
    <React.Fragment>
      {props.isSearchResults ? (
        <div id="incidentManagementGrid" className={styles.grid}>
          <UI.ExpandableGrid
            id="incidentGrid"
            columns={columns}
            data={testTakerData}
            initialState={props.gridState.initialState}
            onPageChange={props.onPageChange}
            onPageSizeChange={props.onPageSizeChange}
            totalRecords={props.gridState.totalRecords}
            currentPage={props.gridState.selectedPage}
            pageSizeOptions={props.pageSizeOptions}
            selectedOptionValue={props.gridState.selectedOptionValue}
            onColumnSort={props.onColumnSort}
            sortOption={props.sortOption}
            sort={props.sort}
            expandedGrid={populateExpandedRow}
            isLoading={props.isLoading}
          />
        </div>
      ) : (
        <NoResultsFound
          title={incidentManagementLabels.noResultsFoundTitle}
          description={incidentManagementLabels.noResultsFoundDesp}
        />
      )}
    </React.Fragment>
  );
};

export default IncidentManagementGrid;
