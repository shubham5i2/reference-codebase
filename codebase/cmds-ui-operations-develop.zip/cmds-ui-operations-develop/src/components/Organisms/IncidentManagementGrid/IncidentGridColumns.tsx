import React from 'react';
import { Cell, Column } from 'react-table';

import UI from 'ielts-cmds-ui-component-library';

import { languageService } from '../../../services/Language/LanguageService';
import { ColumnsData, IncidentManagementSortOption } from '../../../services/Models/IncidentManagement';
import { Action } from '../../../services/Models/Api';
import { formatDate } from '../../utils/utilities';
import { getIncidentCatagory, getIncidentStatus } from '../../../services/API/Reference/Incident';
import TestTakerGridCell from '../TestTakerGridCell/TestTakerGridCell';
import { TestTakerGridCellType } from '../ManageTestTakerGrid/ManageTestTakerGridConstants';
import { getLocationName } from '../../../services/API/ManageUser/Locations';
import styles from './IncidentManagementGrid.module.scss';
import ArrowDownIcon from '../../../assets/images/Chevron_Down.svg';
import ArrowUpIcon from '../../../assets/images/Chevron_Up.svg';
import MoreIcon from '../../../assets/images/More.svg';
import { incidentManagementActions } from '../../../constants/IncidentManagement/IncidentManagementGridConstants';

const incidentManagementLabels = languageService().incidentManagement;

export const getColumns = (columnsData: ColumnsData) => {
  const {
    toggleExpansion,
    iconClickHandler,
    testTakerData,
    selectedToolTipIndex,
    incidentActionsHandler,
    testcentersResponse,
  } = columnsData;
  return [
    {
      id: 'expander',
      Cell: ({ row }: any) => {
        const index = row.index;
        return (
          <span {...row.getToggleRowExpandedProps()}>
            <TestTakerGridCell
              id="expandBtn"
              disability={false}
              cellType={TestTakerGridCellType.EXPAND}
              icon={toggleExpansion.includes(testTakerData[index].incidentUuid) ? ArrowUpIcon : ArrowDownIcon}
              onChangeHandler={() => iconClickHandler(index)}
            />
          </span>
        );
      },
    },
    {
      Header: {
        label: incidentManagementLabels.uniqueTtNumber.toUpperCase(),
        name: IncidentManagementSortOption.UNIQUE_TEST_TAKER_ID,
      },
      accessor: 'uniqueTestTakerId',
      sortType: 'basic',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell
          id="uniqueTestTakerId"
          cellType={TestTakerGridCellType.UNIQUETESTTAKERID}
          value={cellProps.value}
        />
      ),
    },
    {
      Header: {
        label: incidentManagementLabels.givenName.toUpperCase(),
        name: IncidentManagementSortOption.GIVEN_NAME,
      },
      accessor: 'firstName',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell id="givenName" cellType={TestTakerGridCellType.GIVENNAME} value={cellProps.value} />
      ),
    },
    {
      Header: {
        label: incidentManagementLabels.familyName.toUpperCase(),
        name: IncidentManagementSortOption.FAMILY_NAME,
      },
      accessor: 'lastName',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell id="familyName" cellType={TestTakerGridCellType.FAMILYNAME} value={cellProps.value} />
      ),
    },
    {
      Header: {
        label: incidentManagementLabels.testDate.toUpperCase(),
        name: IncidentManagementSortOption.TEST_DATE,
      },
      accessor: 'testDate',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell
          id="testDate"
          cellType={TestTakerGridCellType.TESTDATE}
          value={formatDate(new Date(cellProps.value), incidentManagementLabels.uiDateFormat)}
        />
      ),
    },
    {
      Header: {
        label: incidentManagementLabels.testCentre.toUpperCase(),
        name: IncidentManagementSortOption.TEST_CENTRE,
      },
      accessor: 'locationUuid',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell
          id="testCentre"
          cellType={TestTakerGridCellType.TESTCENTRE}
          value={getLocationName(cellProps.value, testcentersResponse)}
        />
      ),
    },
    {
      Header: {
        label: incidentManagementLabels.testTakerNumber.toUpperCase(),
        name: IncidentManagementSortOption.SHORT_CANDIDATE_NUMBER,
      },
      accessor: 'shortCandidateNumber',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell
          id="shortCandidateNumber"
          cellType={TestTakerGridCellType.TESTTAKERNUMBER}
          value={String(cellProps.value).padStart(6, '0')}
        />
      ),
    },
    {
      Header: {
        label: incidentManagementLabels.incidentCatagory.toUpperCase(),
        name: IncidentManagementSortOption.INCIDENT_CATAGORY,
      },
      accessor: 'incidentCategoryUuid',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell
          id="incidentCategoryUuid"
          cellType={TestTakerGridCellType.INCIDENTCATAGORY}
          value={getIncidentCatagory(cellProps.value)}
        />
      ),
    },
    {
      Header: {
        label: incidentManagementLabels.incidentStatus.toUpperCase(),
        name: IncidentManagementSortOption.INCIDENT_STATUS,
      },
      accessor: 'incidentStatusTypeUuid',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell
          id="incidentStatusTypeUuid"
          cellType={TestTakerGridCellType.INCIDENTSTATUS}
          value={getIncidentStatus(cellProps.value)}
        />
      ),
    },
    {
      id: 'More',
      Cell: (cellProps: Cell) => {
        const isMoreSelected = selectedToolTipIndex === cellProps.row.index;
        const moreSelectedClass = isMoreSelected ? styles.userActionsOpened : '';
        return (
          <div id="TTActionsContainer" className={`${styles.userActionsContainer} ${moreSelectedClass}`}>
            <UI.ShowMoreButton
              id={'moreButton'}
              moreIcon={MoreIcon}
              moreActions={incidentManagementActions}
              moreActionsClickHandler={(action: Action) => incidentActionsHandler(action, cellProps.row.index)}
            />
          </div>
        );
      },
      disableSortBy: true,
    },
  ] as Column[];
};
