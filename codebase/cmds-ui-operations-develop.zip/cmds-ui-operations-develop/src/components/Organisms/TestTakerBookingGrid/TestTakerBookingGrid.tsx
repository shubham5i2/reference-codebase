import React, { useEffect } from 'react';
import styles from './TestTakerBooking.module.scss';
import TakerTRFLabels from '../../../services/Language/en/en.testtakertrf';
import UI from 'ielts-cmds-ui-component-library';
import { TestTakerGrid } from './FormatTestTakerBookingData';
import { printStatus } from '../../../services/Models/TestTakerTRF';
import { reportTypes, renditionId } from './TestTakerBookingGridConstants';
import TestTakerReportDetails from '../TestTakerReportDetails/TestTakerReportDetails';

interface TestTakerBookingGridProps {
  data?: TestTakerGrid;
  sort?: boolean;
  title?: string;
  titleType?: string;
  subTitleType?: string;
  subTitle?: string;
  subTitleSize?: number;
  titleSize?: number;
  reportType?: string;
  downloadReportHandler: (reportType: string) => void;
}

const TestTakerBookingGrid = (props: TestTakerBookingGridProps) => {
  const formattedData: TestTakerGrid = props.data as TestTakerGrid;
  const { reportType, downloadReportHandler } = props;
  const statusClassName = (formattedData && formattedData.resultStatus.toLowerCase()) || '';

  useEffect(() => {
    setDataForReport();
  });

  const setDataForReport = () => {
    if (reportType === '' && formattedData.printStatus && formattedData.printStatus.length >= 1) {
      formattedData?.printStatus.map((ps: printStatus) => {
        if (ps.renditionTypeUuid === renditionId.etrf) {
          formattedData.etrf = {
            printEventCount: ps.printEventCount,
            printedBy: ps.printedBy,
            printedDateTime: ps.printedDateTime,
            renditionTypeUuid: renditionId.etrf,
          };
        }
        if (ps.renditionTypeUuid === renditionId.trf) {
          formattedData.trf = {
            printEventCount: ps.printEventCount,
            printedBy: ps.printedBy,
            printedDateTime: ps.printedDateTime,
            renditionTypeUuid: renditionId.trf,
          };
        }
      });
    }
  };

  return (
    <div className={styles.bookingGridMain}>
      <div className={styles.Container}>
        <div className={styles.TitleContainer}>
          <div className={styles.TitleLeftSide}>
            <div className={styles.Title}>
              <UI.Typography label={props.title} size={32} id="testTakerTitle" />
            </div>
            <div className={styles.SubTitle}>
              <div className={styles.searchPanelSubTitle}>
                <UI.Typography
                  type={props.subTitleType}
                  label={props.subTitle}
                  size={props.subTitleSize}
                  id="subTitle"
                />
              </div>
            </div>
          </div>
        </div>
        <div className={styles.bookingDetails}>
          <table className={styles.testTakerBookingGrid}>
            <thead>
              <tr>
                <th>{TakerTRFLabels.givenName}</th>
                <th>{TakerTRFLabels.familyName}</th>
                <th>{TakerTRFLabels.ttbhBookingTestCentre}</th>
                <th>{TakerTRFLabels.ttbhBookingTestDate}</th>
                <th>{TakerTRFLabels.ttNumberLabel}</th>
                <th>{TakerTRFLabels.currentResultStatus}</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>{formattedData?.givenName}</td>
                <td>{formattedData?.familyName}</td>
                <td>{formattedData?.testCenterNumber}</td>
                <td>{formattedData?.testDate}</td>
                <td>{formattedData?.testTakerNumber}</td>
                <td>
                  <span className={`${styles.statusCircle} ${styles[statusClassName + 'StatusCircle']}`}></span>
                  {formattedData?.resultStatus}
                </td>
              </tr>
            </tbody>
          </table>
          <div className={styles.reportBookingDetails}>
            <TestTakerReportDetails
              downloadReportHandler={downloadReportHandler}
              reportType={reportTypes.TRF}
              data={formattedData}
            />

            <hr />
            <TestTakerReportDetails
              downloadReportHandler={downloadReportHandler}
              reportType={reportTypes.ETRF}
              data={formattedData}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default TestTakerBookingGrid;
