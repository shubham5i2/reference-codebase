import { printStatus } from '../../../services/Models/TestTakerTRF';

export interface TestTakerGrid {
  familyName: string;
  givenName: string;
  testDate: string;
  printedBy: string;
  printEventCount: number;
  printedDateTime: string;
  testTakerNumber: string;
  testCenterNumber: string;
  resultStatus: string;
  printStatus: printStatus[];
  trf: printStatus;
  etrf: printStatus;
}
