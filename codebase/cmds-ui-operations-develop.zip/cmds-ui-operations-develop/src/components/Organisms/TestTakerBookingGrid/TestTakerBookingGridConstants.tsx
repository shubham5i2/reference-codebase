import { printStatus } from '../../../services/Models/TestTakerTRF';
import { TestTakerGrid } from '../TestTakerBookingGrid/FormatTestTakerBookingData';

export const TestTakerGridCellType = {
  GIVENNAME: 'GIVEN NAME',
  FAMILYNAME: 'FAMILY NAME',
  TESTDATE: 'TESTDATE',
  TESTCENTRE: 'TESTCENTRE',
  TESTTAKERNUMBER: 'TESTTAKERNUMBER',
  CURRENTRESULTSTATUS: 'CURRENTRESULTSTATUS',
};

export const pageSizeOptions = [
  { text: '10', value: 10 },
  { text: '25', value: 25 },
  { text: '50', value: 50 },
];

export const trf: printStatus = {
  printedBy: 'admin',
  printEventCount: 1,
  printedDateTime: '2022-02-04T06:03:14.643Z',
  renditionTypeUuid: '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
};

export const etrf: printStatus = {
  printedBy: 'admin',
  printEventCount: 1,
  printedDateTime: '2022-02-04T06:03:14.643Z',
  renditionTypeUuid: '15b2e233-81a4-4263-b327-9b47ba09eb01',
};

export const testTakerTrfBookingMockData: TestTakerGrid = {
  givenName: 'Tennille',
  familyName: 'Hails',
  testCenterNumber: 'AU240',
  testDate: '2022-02-04T06:03:14.643Z',
  testTakerNumber: '018713',
  resultStatus: 'released',
  printEventCount: 0,
  printedBy: 'admin',
  printedDateTime: '2022-02-04T06:03:14.643Z',
  trf: trf,
  etrf: etrf,
  printStatus: [],
};

export enum reportTypes {
  TRF = 'trf',
  ETRF = 'etrf',
}

export enum renditionId {
  trf = '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
  etrf = '15b2e233-81a4-4263-b327-9b47ba09eb01',
}
