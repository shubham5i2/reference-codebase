import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import styles from './TestTakerBookingDetailsHeader.module.scss';
import cx from 'classnames';
import { languageService } from '../../../services/Language/LanguageService';

export interface TestTakerBookingDetailsHeaderProps {
  testTakerName: string;
  bookingStatus: string;
}

const TestTakerBookingDetailsHeader = (props: TestTakerBookingDetailsHeaderProps) => {
  const testTakerLabels = languageService().testTaker;

  const capitalizeStatus = (inputString: string) => {
    const lower = inputString.toLocaleLowerCase();
    const lowerArr = lower.split(' ');
    return lowerArr.reduce((res, arr) => res + ' ' + arr.charAt(0).toLocaleUpperCase() + arr.slice(1), '').trim();
  };

  const statusColor = (status: string) => {
    const capitalizedStatus = capitalizeStatus(status);
    switch (capitalizedStatus) {
      case testTakerLabels.resultStatusReleased:
        return styles.statusGreen;
      case testTakerLabels.resultStatusWithheld:
      case testTakerLabels.resultStatusConfirmed:
      case testTakerLabels.resultStatusPendingReview:
      case testTakerLabels.resultStatusValidated:
        return styles.statusAmber;
      case testTakerLabels.resultStatusUnconfirmed:
      case testTakerLabels.resultStatusAbsent:
        return styles.statusGrey;
      case testTakerLabels.resultStatusPWithheld:
        return styles.statusRed;
      default:
        return styles.statusAmber;
    }
  };

  return (
    <React.Fragment>
      <div className={styles.ttBookingContainer}>
        <div className={styles.ttBookingTitleContainer}>
          <div className={styles.ttBookingTitle}>{props.testTakerName}</div>
          <div className={cx(styles.statusCircle, statusColor(props.bookingStatus))}></div>
          <div className={styles.ttBookingSubTitle}>{capitalizeStatus(props.bookingStatus)}</div>
        </div>

        <UI.Tabs
          initialActiveTab={testTakerLabels.bookingDetailsLabel}
          tabBtnStyle={styles.ttBookingCnameTabBtn}
          buttonStyle={styles.ttBookingCnameBtn}
          activeBtnStyle={styles.ttBookingCnameBtnActive}
        >
          <UI.Tab label={testTakerLabels.bookingDetailsLabel} isClickable={false} />
        </UI.Tabs>
      </div>
    </React.Fragment>
  );
};

export default TestTakerBookingDetailsHeader;
