import React, { useRef, useState, useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import UI from 'ielts-cmds-ui-component-library';
import styles from './ROGrid.module.scss';
import ROGridCell from '../ROGridCell/ROGridCell';
import { ROGridCellType } from './ROGridConstants';
import ManageUsersActions from '../../Molecules/ManageUsersActions/ManageUsersActions';
import visibilityIcon from '../../../assets/images/visibility.svg';
import EditIcon from '../../../assets/images/Edit.svg';
import ArrowDownIcon from '../../../assets/images/ArrowDown.svg';
import MoreIcon from '../../../assets/images/More.svg';
import { languageService } from '../../../services/Language/LanguageService';
import { OrganisationSortOption, OrganisationType, ROGridData } from '../../../services/Models/Organisation';
import { Action } from '../../../services/Models/Api';
import { useStateValue } from '../../../Store/helpers/UseStateValue';
import * as OrganisationDataActions from '../../../Store/Actions/OrganisationDataActions';
import { getOrganisation } from '../../../services/API/Organisation/OrganisationDetails';
import withServiceRequest, { ServiceRequest } from '../../../services/utils/ServiceRequest';
import { ExpandedGridType, UIGridState } from '../../../services/Models/UIModels';
import { Cell, Column, Row } from 'react-table';
import OrganisationDetailsModal from '../../Pages/OrganisationDetailsModal/OrganisationDetailsModal';
import { getValue } from '../../utils/utilities';

export interface ColumnSort {
  Header: {
    name: string;
  };
}

interface ROGridProps {
  data: ROGridData[];
  onPageChange: (page: number) => void;
  onPageSizeChange: (value: number) => void;
  gridState: UIGridState;
  pageSizeOptions: { text: string; value: number }[];
  onColumnSort?: (column: ColumnSort) => void;
  sortOption?: { sortType: string; sortBy: string };
  sort?: boolean;
  serviceRequest: ServiceRequest;
  isLoading: boolean;
}

enum ROActionType {
  VIEW_DETAILS,
  UPDATE,
}

const ROGrid = (props: ROGridProps) => {
  const userActionsContainerRef = useRef<HTMLDivElement>();
  const [selectedToolTipIndex, setSelectedToolTipIndex] = useState<number | null>(null);
  const history = useHistory();
  const organisationLabels = languageService().organisation;
  const { dispatch } = useStateValue();
  const [toolTipID, setToolTipID] = useState(-1);
  const [selectedParent, setSelectedParent] = useState<string | undefined>();

  const roActions = [
    { label: organisationLabels.viewDetails, type: ROActionType.VIEW_DETAILS, icon: visibilityIcon },
    { label: organisationLabels.update, type: ROActionType.UPDATE, icon: EditIcon },
  ];

  useEffect(() => {
    document.addEventListener('mousedown', handleClick);

    return () => {
      document.removeEventListener('mousedown', handleClick);
    };
  }, []);

  const handleClick = (e: Event) => {
    const userActionsContainerClassName =
      userActionsContainerRef.current && userActionsContainerRef.current !== null
        ? userActionsContainerRef.current.className
        : '';
    const target = e.target as HTMLElement;
    const targetElementClassName =
      target.offsetParent && target.offsetParent !== null ? target.offsetParent.className : '';
    if (
      userActionsContainerClassName === targetElementClassName ||
      targetElementClassName.includes('ManageUsersActions_manageUsersActions')
    ) {
      return;
    }
    setSelectedToolTipIndex(null);
  };

  const moreClickHandler = (props: Row) => {
    if (selectedToolTipIndex === props.index) {
      setSelectedToolTipIndex(null);
    } else {
      setSelectedToolTipIndex(props.index);
    }
  };

  const roActionsHandler = (action: Action, index: number) => {
    const currentUrl = history.location.pathname;
    switch (+action.type) {
      case ROActionType.VIEW_DETAILS:
        history.push(`${currentUrl}/organisationDetails/${props.data[index].recognisingOrganisationUuid}`, {
          selectedRow: index + 1,
        });
        break;
      case ROActionType.UPDATE:
        getOrganisation(props.data[index].recognisingOrganisationUuid, props.serviceRequest).subscribe((orgData) => {
          if (orgData) {
            dispatch({ type: OrganisationDataActions.ORGANISATION_DATA_SUCCESS, payload: orgData });
            history.push(`${currentUrl}/update/${props.data[index].recognisingOrganisationUuid}`);
          }
        });
        break;
    }
    setSelectedToolTipIndex(null);
  };

  const getROGridItem = (cellProps: Cell, name: string) => {
    return <ROGridCell id={name} cellType={name} value={cellProps.value} />;
  };

  const getROGridItemActionContainer = (cellProps: Cell) => {
    const isMoreSelected = selectedToolTipIndex === cellProps.row.index;
    const moreSelectedClass = isMoreSelected ? styles.userActionsOpened : '';
    return (
      <div
        id="ROActionsContainer"
        ref={userActionsContainerRef as React.RefObject<HTMLDivElement>}
        className={`${styles.userActionsContainer} ${moreSelectedClass}`}
      >
        <ROGridCell
          id="moreButton"
          cellType={ROGridCellType.MORE}
          value={cellProps.value}
          icon={MoreIcon}
          onChangeHandler={() => moreClickHandler(cellProps.row)}
        />
        {isMoreSelected ? (
          <ManageUsersActions
            id={'ROActionContainer'}
            userActions={roActions}
            userActionsClickHandler={(action: Action) => roActionsHandler(action, cellProps.row.index)}
          />
        ) : null}
      </div>
    );
  };

  const columns = [
    {
      id: 'expander',
      Cell: ({ row }: any) => {
        return (
          <span {...row.getToggleRowExpandedProps()}>
            <ROGridCell id="expandBtn" cellType={ROGridCellType.EXPAND} icon={ArrowDownIcon} />
          </span>
        );
      },
    },
    {
      Header: {
        label: organisationLabels.organisationName.toUpperCase(),
        name: OrganisationSortOption.RO_NAME,
      },
      accessor: 'roName',
      sortType: 'basic',
      Cell: (cellProps: Cell) => getROGridItem(cellProps, ROGridCellType.RONAME),
    },
    {
      Header: {
        label: organisationLabels.orgId.toUpperCase(),
        name: OrganisationSortOption.RO_ID,
      },
      accessor: 'roId',
      Cell: (cellProps: Cell) => getROGridItem(cellProps, ROGridCellType.ROID),
    },

    {
      Header: {
        label: organisationLabels.country.toUpperCase(),
        name: OrganisationSortOption.COUNTRY,
      },
      accessor: 'country',
      Cell: (cellProps: Cell) => getROGridItem(cellProps, ROGridCellType.COUNTRY),
      disableSortBy: true,
    },
    {
      Header: {
        label: organisationLabels.stateTerritory.toUpperCase(),
        name: OrganisationSortOption.TERRITORY,
      },
      accessor: 'territory',
      Cell: (cellProps: Cell) => getROGridItem(cellProps, ROGridCellType.STATETERRITORY),
      disableSortBy: true,
    },

    {
      Header: {
        label: organisationLabels.organisationStatus.toUpperCase(),
        name: OrganisationSortOption.RO_STATUS,
      },
      accessor: 'activeStatus',
      Cell: (cellProps: Cell) => getROGridItem(cellProps, ROGridCellType.ACTIVESTATUS),
    },
    {
      Header: {
        label: organisationLabels.organisationType.toUpperCase(),
        name: OrganisationSortOption.ORGANISATION_TYPE,
      },
      accessor: 'organisationType',
      Cell: (cellProps: Cell) => getROGridItem(cellProps, ROGridCellType.ORGANISATION_TYPE),
    },
    {
      id: 'More',
      Cell: (cellProps: Cell) => getROGridItemActionContainer(cellProps),
      disableSortBy: true,
    },
  ] as Column[];

  const populateExpandedRow = (props: ExpandedGridType) => {
    return (
      <React.Fragment>
        <tr className={styles.expandedColor}>
          <td colSpan={props.visibleColumns} className={styles.expandedRow}>
            <div>
              <span>
                {organisationLabels.city} <b>{props.rowData.city}</b>
              </span>
              <span>
                {organisationLabels.postCode} <b>{props.rowData.postCode}</b>
              </span>
              <span>
                {organisationLabels.verificationStatus}{' '}
                <label
                  id={'verificationStatusValue'}
                  className={`${styles.verificationStatus} ${styles[props.rowData.verificationStatus.toLowerCase()]}`}
                >
                  {props.rowData.verificationStatus}
                </label>
                {/* {organisationLabels.organisationType} <b>{props.rowData.organisationType}</b> */}
              </span>
              {(props.rowData.organisationTypeUuid === OrganisationType.RO ||
                props.rowData.organisationTypeUuid === OrganisationType.VO) && (
                <span className={styles.parentId}>
                  {organisationLabels.parentOrganisationId}
                  {props.rowData.parentOrgId ? (
                    <b
                      className={styles.link}
                      onMouseOver={() => setToolTipID(props.rowData.roId)}
                      onMouseOut={() => setToolTipID(-1)}
                      onClick={() => setSelectedParent(props.rowData.parentRecognisingOrganisationUuid)}
                    >
                      {props.rowData.parentOrgId}
                    </b>
                  ) : null}
                  {props.rowData.roId === toolTipID && (
                    <span id="textBoxToolTipContainer" className={styles.textBoxToolTipContainer}>
                      <UI.ToolTip label={props.rowData.parentRecognisingOrganisationName} />
                    </span>
                  )}
                </span>
              )}
            </div>
          </td>
        </tr>
      </React.Fragment>
    );
  };

  return (
    <div id="roGridContainer" className={styles.rogrid}>
      {selectedParent && (
        <OrganisationDetailsModal parentOrgId={getValue(selectedParent)} onDialogClose={() => setSelectedParent('')} />
      )}
      <UI.ExpandableGrid
        id="roGrid"
        columns={columns}
        data={props.data}
        initialState={props.gridState.initialState}
        onPageChange={props.onPageChange}
        onPageSizeChange={props.onPageSizeChange}
        totalRecords={props.gridState.totalRecords}
        currentPage={props.gridState.selectedPage}
        pageSizeOptions={props.pageSizeOptions}
        selectedOptionValue={props.gridState.selectedOptionValue}
        onColumnSort={props.onColumnSort}
        sortOption={props.sortOption}
        sort={props.sort}
        expandedGrid={populateExpandedRow}
        isLoading={props.isLoading}
      />
    </div>
  );
};

export default withServiceRequest(ROGrid);
