import { BookingList, TestTaker } from '../../../services/Models/TestTakerManagement';
import { TestTakerGrid } from '../ManageTestTakerGrid/FormatTestTakerData';

export interface AddBookingPostData {
  uniqueTestTakerUuid: string;
  bookingList: string[];
}

export const formAddBookingGridData = (data: TestTaker[]) => {
  const dataArray: TestTakerGrid[] = [];
  let res = {} as TestTakerGrid;
  data.forEach((item: TestTaker) => {
    item.bookingList.forEach((element: BookingList) => {
      res = {
        ...element,
        uniqueTestTakerId: item.uniqueTestTakerId,
        uniqueTestTakerUuid: item.uniqueTestTakerUuid,
      };
      dataArray.push(res);
    });
  });
  return dataArray;
};

export const bookingDataGenerator = (testTakerBookingUuIds: string[], gridData: TestTakerGrid[]) => {
  return gridData.filter((item: TestTakerGrid) => testTakerBookingUuIds.includes(item.bookingUuid));
};

export const bookingPostDataFormatter = (uniqueTestTakerUuid: string, data: TestTakerGrid[]) => {
  const bookingList: string[] = data.map((item: TestTakerGrid) => item.bookingUuid);
  return {
    uniqueTestTakerUuid,
    bookingList,
  };
};
