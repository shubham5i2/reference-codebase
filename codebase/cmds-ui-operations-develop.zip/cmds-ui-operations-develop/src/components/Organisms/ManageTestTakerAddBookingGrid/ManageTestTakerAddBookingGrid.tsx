import React, { useEffect, useRef, useState } from 'react';
import styles from './ManageTestTakerAddBookingGrid.module.scss';
import { ManageTestTakerSortOption, TestTaker } from '../../../services/Models/TestTakerManagement';
import UI from 'ielts-cmds-ui-component-library';
import TestTakerGridCell from '../TestTakerGridCell/TestTakerGridCell';
import { TestTakerGridCellType } from '../ManageTestTakerGrid/ManageTestTakerGridConstants';
import testTakerLabels from '../../../services/Language/en/en.testtaker';
import MoreIcon from '../../../assets/images/More.svg';
import visibilityIcon from '../../../assets/images/visibility.svg';
import ManageUsersActions from '../../Molecules/ManageUsersActions/ManageUsersActions';
import { Action } from '../../../services/Models/Api';
import { useHistory } from 'react-router-dom';
import { Cell, Column, Row } from 'react-table';
import { formatDate, getPartnerCode } from '../../utils/utilities';
import {
  formAddBookingGridData,
  bookingDataGenerator,
  bookingPostDataFormatter,
} from './FormatTestTakerAddBookingData';
import AddBookingDailog from '../../Others/AddBookingDialog/AddBookingDailog';
import { TestTakerGrid } from '../ManageTestTakerGrid/FormatTestTakerData';
import { Location } from '../../../services/Models/StaffManagement';
import { useStateValue } from '../../../Store/helpers/UseStateValue';
import { TestTakerActionType } from '../ManageTestTakerGrid/ManageTestTakerGrid';
import { getNationalityData } from '../../../services/API/Reference/Nationality';
import { GridProps } from '../../../services/Models/UIModels';
import { useAuth0 } from '@auth0/auth0-react';
import { getLocationKey, LocationType } from '../LocationDropdown/LocationDropdownUtils';

interface AddBookingTestTakerGridProps extends GridProps {
  data: TestTaker[];
  testtakerUuId: string;
  testTakerId: string;
  isLoading: boolean;
}

const manageTestTakerActions = [
  { label: testTakerLabels.viewDetails, type: TestTakerActionType.VIEW_DETAILS, icon: visibilityIcon },
];

const ManageTestTakerAddBookingGrid = (props: AddBookingTestTakerGridProps) => {
  const userActionsContainerRef = useRef<HTMLDivElement>();
  const history = useHistory();
  const [selectedToolTipIndex, setSelectedToolTipIndex] = useState<number | null>(null);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [isModalOpened, setIsModalOpened] = useState(false);
  const formattedData = formAddBookingGridData(props.data);
  const [testTakerBookingUuIds, setTestTakerBookingUuIds] = useState<string[]>([]);
  const { state } = useStateValue();
  const { user } = useAuth0();
  let bookingData: TestTakerGrid[] = [];
  const [gridData, setGridData] = useState<TestTakerGrid[]>([]);

  useEffect(() => {
    document.addEventListener('mousedown', handleClick);

    return () => {
      document.removeEventListener('mousedown', handleClick);
    };
  }, []);

  const handleClick = (e: Event) => {
    const userActionsContainerClassName =
      userActionsContainerRef.current && userActionsContainerRef.current !== null
        ? userActionsContainerRef.current?.className
        : '';
    const target = e.target as HTMLElement;
    const targetElementClassName =
      target.offsetParent && target.offsetParent !== null ? target.offsetParent.className : '';
    if (
      userActionsContainerClassName === targetElementClassName ||
      targetElementClassName.includes('ManageUsersActions_manageUsersActions')
    ) {
      return;
    }
    setSelectedToolTipIndex(null);
  };

  const partnerCode = getPartnerCode(user || {});
  const locationKey = getLocationKey(LocationType.TEST_CENTRE, partnerCode, 'getLocations');
  const locationsResponse = state.locationData?.[locationKey]?.response || [];

  const getLocationName = (locationUuid: string) => {
    if (locationsResponse) {
      return locationsResponse.find((location: Location) => locationUuid === location.locationUuid)?.locationName || '';
    }
  };

  const addBookingConfirmationHandler = () => {
    setTestTakerBookingUuIds([]);
    bookingData = [];
    setGridData([]);
    setIsModalOpened(false);
    history.push(`/managetesttaker/testtakerbookinghistory/${props.testtakerUuId}`, {
      selectedUniqueTestTakerId: props.testTakerId,
    });
  };

  const addBookingModalHandler = () => {
    bookingData = bookingDataGenerator(testTakerBookingUuIds, gridData);
    return isModalOpened && testTakerBookingUuIds.length > 0 ? (
      <AddBookingDailog
        id="addBookingDialogComponent"
        title={testTakerLabels.ttbhAddBookingLabel}
        label={`${testTakerLabels.ttbhAddBookingSecondaryLabel} ${props.testTakerId}?`}
        addBookingHandler={addBookingConfirmationHandler}
        modalCloseHandler={() => setIsModalOpened(false)}
        bookingInfo={bookingData}
        postData={bookingPostDataFormatter(props.testtakerUuId, bookingData)}
      />
    ) : (
      isModalOpened && (
        <div className={styles.messageContainer}>
          <UI.Message
            message={testTakerLabels.addBookingCriteriaError}
            color="error"
            dismissable
            onChange={() => setIsModalOpened(false)}
          />
        </div>
      )
    );
  };

  const moreClickHandler = (props: Row) => {
    setSelectedIndex(props.index);
    if (selectedToolTipIndex === props.index) {
      setSelectedToolTipIndex(null);
    } else {
      setSelectedToolTipIndex(props.index);
    }
  };

  const testTakerActionsHandler = (action: Action, index: number) => {
    switch (action.type) {
      case TestTakerActionType.VIEW_DETAILS:
        history.push(`/managetesttaker/testtakerbookinghistory/${formattedData[index].uniqueTestTakerUuid}`, {
          selectedRow: index + 1,
          selectedBookingUuid: formattedData[index].bookingUuid,
          selectedUniqueTestTakerId: formattedData[index].uniqueTestTakerId,
        });
        break;
    }
    setSelectedToolTipIndex(null);
  };

  const bookingSelectionHandler = (index: number) => {
    const testTakerId = formattedData[index].bookingUuid;
    const idx = testTakerBookingUuIds.indexOf(testTakerId);
    const gridDataIndex = gridData.findIndex((item: TestTakerGrid) => item.bookingUuid === testTakerId);
    if (idx >= 0) {
      testTakerBookingUuIds.splice(idx, 1);
      gridDataIndex >= 0 && gridData.splice(gridDataIndex, 1);
    } else {
      setTestTakerBookingUuIds([...testTakerBookingUuIds, testTakerId]);
      gridDataIndex < 0 && setGridData((preState: TestTakerGrid[]) => [formattedData[index], ...preState]);
    }
  };

  const defaultCheckHandler = (index: number) => testTakerBookingUuIds.indexOf(formattedData[index].bookingUuid) >= 0;

  const verificationStatusFormatter = (str: string) => str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();

  const getGridItem = (cellProps: Cell, name: string) => {
    return <TestTakerGridCell id={name} cellType={name} value={cellProps.value} />;
  };

  const columns = [
    {
      id: 'expander',
      Cell: ({ row }: any) => {
        const index = row.index;
        return (
          <TestTakerGridCell
            id="checkBox"
            cellType={TestTakerGridCellType.CHECKBOX}
            defaultCheck={defaultCheckHandler(index)}
            onChangeHandler={() => bookingSelectionHandler(index)}
          />
        );
      },
    },
    {
      Header: {
        label: testTakerLabels.uniqueTestTakerId.toUpperCase(),
        name: ManageTestTakerSortOption.UNIQUE_TEST_TAKER_ID,
      },
      accessor: 'uniqueTestTakerId',
      sortType: 'basic',
      Cell: (cellProps: Cell) => getGridItem(cellProps, TestTakerGridCellType.UNIQUETESTTAKERID),
    },
    {
      Header: {
        label: testTakerLabels.cmdsBookingId.toUpperCase(),
        name: ManageTestTakerSortOption.CMDS_BOOKING_ID,
      },
      accessor: 'bookingUuid',
      Cell: (cellProps: Cell) => getGridItem(cellProps, TestTakerGridCellType.CMDSBOOKINGID),
    },
    {
      Header: {
        label: testTakerLabels.identityDocumentNumber.toUpperCase(),
        name: ManageTestTakerSortOption.IDENTITY_DOCUMENT_NUMBER,
      },
      accessor: 'identityNumber',
      Cell: (cellProps: Cell) => getGridItem(cellProps, TestTakerGridCellType.IDENTITYDOCUMENTNUMBER),
    },
    {
      Header: {
        label: testTakerLabels.givenName.toUpperCase(),
        name: ManageTestTakerSortOption.GIVEN_NAME,
      },
      accessor: 'firstName',
      Cell: (cellProps: Cell) => getGridItem(cellProps, TestTakerGridCellType.GIVENNAME),
    },
    {
      Header: {
        label: testTakerLabels.familyName.toUpperCase(),
        name: ManageTestTakerSortOption.FAMILY_NAME,
      },
      accessor: 'lastName',
      Cell: (cellProps: Cell) => getGridItem(cellProps, TestTakerGridCellType.FAMILYNAME),
    },
    {
      Header: {
        label: testTakerLabels.dateOfBirth.toUpperCase(),
      },
      accessor: 'birthDate',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell
          id="birthDate"
          cellType={TestTakerGridCellType.DATEOFBIRTH}
          value={formatDate(new Date(cellProps.value), testTakerLabels.uiDateFormat)}
        />
      ),
    },
    {
      Header: {
        label: testTakerLabels.nationality.toUpperCase(),
      },
      accessor: 'nationalityUuid',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell
          id="nationality"
          cellType={TestTakerGridCellType.NATIONALITY}
          value={getNationalityData(cellProps.value)}
        />
      ),
    },
    {
      Header: {
        label: testTakerLabels.email.toUpperCase(),
      },
      accessor: 'email',
      Cell: (cellProps: Cell) => getGridItem(cellProps, TestTakerGridCellType.EMAILID),
    },
    {
      Header: {
        label: testTakerLabels.ttbhBookingTestDate.toUpperCase(),
      },
      accessor: 'testDate',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell
          id="testDate"
          cellType={TestTakerGridCellType.TESTDATE}
          value={formatDate(new Date(cellProps.value), testTakerLabels.uiDateFormat)}
        />
      ),
    },
    {
      Header: {
        label: testTakerLabels.ttbhBookingTestCentre.toUpperCase(),
      },
      accessor: 'testCentreNumber',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell
          id="testCentreNumber"
          cellType={TestTakerGridCellType.TESTCENTRE}
          value={getLocationName(cellProps.value)}
        />
      ),
    },
    {
      Header: {
        label: testTakerLabels.ttNumberLabel.toUpperCase(),
      },
      accessor: 'shortCandidateNumber',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell
          id="shortCandidateNumber"
          cellType={TestTakerGridCellType.TESTTAKERNUMBER}
          value={String(cellProps.value).padStart(6, '0')}
        />
      ),
    },
    {
      Header: {
        label: testTakerLabels.ttbhBookingVerificationStatus.toUpperCase(),
      },
      accessor: 'identityVerificationStatus',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell
          id="identityVerificationStatus"
          cellType={TestTakerGridCellType.VERIFICATIONSTATUS}
          value={verificationStatusFormatter(cellProps.value)}
        />
      ),
    },
    {
      id: 'More',
      Cell: (cellProps: Cell) => {
        const isMoreSelected = selectedToolTipIndex === cellProps.row.index;
        const moreSelectedClass = isMoreSelected ? styles.userActionsOpened : '';
        return (
          <div
            id="TTActionsContainer"
            ref={userActionsContainerRef as React.RefObject<HTMLDivElement>}
            className={`${styles.userActionsContainer} ${moreSelectedClass}`}
          >
            <TestTakerGridCell
              id="moreButton"
              cellType={TestTakerGridCellType.MORE}
              value={cellProps.value}
              icon={MoreIcon}
              onChangeHandler={() => moreClickHandler(cellProps.row)}
            />
            {isMoreSelected ? (
              <span
                className={
                  formattedData.length - 1 === selectedToolTipIndex ? styles.actionViewLast : styles.actionViewPopUp
                }
              >
                <ManageUsersActions
                  id={'TestTakerActionContainer'}
                  userActions={manageTestTakerActions}
                  userActionsClickHandler={(action: Action) => testTakerActionsHandler(action, cellProps.row.index)}
                />
              </span>
            ) : null}
          </div>
        );
      },
      disableSortBy: true,
    },
  ] as Column[];

  return (
    <React.Fragment>
      <div id="manageTestTakerAddBookingGrid" className={styles.manageTestTakerAddBookingGrid}>
        <UI.ExpandableGrid
          id="testTakerAddBookingGrid"
          columns={columns}
          data={formattedData}
          initialState={props.gridState.initialState}
          onPageChange={props.onPageChange}
          onPageSizeChange={props.onPageSizeChange}
          totalRecords={props.gridState.totalRecords}
          currentPage={props.gridState.selectedPage}
          pageSizeOptions={props.pageSizeOptions}
          selectedOptionValue={props.gridState.selectedOptionValue}
          onColumnSort={props.onColumnSort}
          sortOption={props.sortOption}
          sort={props.sort}
          selectedIndex={selectedIndex}
          isLoading={props.isLoading}
        />
      </div>
      {addBookingModalHandler()}
      <div className={styles.addButton} onClick={() => setIsModalOpened(true)} id="addBookingModalOpener">
        <UI.Button label={testTakerLabels.ttbhAddBookingLabel} color="blueLine" icon="plus" id="addBooking" />
      </div>
    </React.Fragment>
  );
};

export default ManageTestTakerAddBookingGrid;
