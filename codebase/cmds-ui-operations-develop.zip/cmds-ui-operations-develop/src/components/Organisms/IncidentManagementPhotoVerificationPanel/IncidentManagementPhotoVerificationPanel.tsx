import React, { useState, useEffect } from 'react';
import UI from 'ielts-cmds-ui-component-library';

import TestTakerPhoto from '../TestTakerPhoto/TestTakerPhoto';
import styles from './IncidentManagementPhotoVerificationPanel.module.scss';
import checkIcon from '../../../assets/images/Icon_Check.svg';
import withServiceRequest, { ServiceRequest } from '../../../services/utils/ServiceRequest';
import * as BreadCrumbActions from '../../../Store/Actions/BreadCrumbActions';
import { useStateValue } from '../../../Store/helpers/UseStateValue';
import { useParams } from 'react-router-dom';
import { updateIdVerification } from '../../../services/API/IncidentManagement/UpdateIdVerification';
import { languageService } from '../../../services/Language/LanguageService';
import { formatDate, getTestCenter } from '../../utils/utilities';
import { getIncidentManagementIdVerificationDetails } from '../../../services/API/IncidentManagement/GetIncidentVerificationResults';
import {
  IncidentManagementIdVerificationDetails,
  IncidentManagementPhoto,
  RadioEnum,
  IncidentPhotoEnum,
} from '../../../../src/services/Models/IncidentManagement';
import { AsyncResponseStatus } from '../../../services/Models/Api';
import {
  currentIDOptions,
  idVerificationInitialData,
  initialPhotoData,
  verifyPhotoEnum,
} from '../../../constants/IncidentManagement/IncidentManagementPhotoPanelConstants';
import { getLocationName } from '../../../services/API/ManageUser/Locations';
import GenericPopup, { ButtonPosition, DialogType, TitlePosition } from '../GenericPopup/GenericPopup';
import { Dictionary, UIButtonType, UITypography } from '../../../services/Models/UIModels';
import { useAuth0 } from '@auth0/auth0-react';
import * as IncidentManagementActions from '../../../Store/Actions/IncidentManagementActions';
import DisplayLabelPatch, { LabelElements, PatchRowData } from '../DisplayLabelPatch/DisplayLabelPatch';

interface IncidentIdVerificationProps {
  serviceRequest: ServiceRequest;
}

const getCurrentIdStatus = (uuid: string) => {
  const value = currentIDOptions.find((item) => item.value === uuid);
  return value ? value.text : '';
};

export enum IDVerificationEnum {
  ID_REJECTED = 'a911b11f-c4f2-4ee9-8450-d954ed3bb9d9',
  ID_VERIFIED = 'a75ee32e-48f8-4062-bac7-41e34a5531ae',
}

const IncidentManagementPhotoVerificationPanel = (props: IncidentIdVerificationProps) => {
  const [verification, setVerification] = useState('');
  const [idVerificationStatus, setIdVerificationStatus] = useState('');
  const [verificationPhotos, setVerificationPhotos] = useState(initialPhotoData);
  const [idVerificationInfo, setIdVerificationInfo] = useState(idVerificationInitialData);
  const [enableConfirmationBox, setEnableConfirmationBox] = useState(false);

  const { user } = useAuth0();
  const { state, dispatch } = useStateValue();
  const { testcentersResponse } = state.incidentManagement.testCenters;
  const [isSuccessMessageEnable, setSuccessMessageEnable] = useState(false);
  const { id } = useParams<{ id: string }>();
  const incidentManagementLabels = languageService().incidentManagement;

  useEffect(() => {
    id && getIdVerificationData(id);
    //eslint-disable-next-line
  }, [id]);

  useEffect(() => {
    getTestCenter(
      user,
      props.serviceRequest,
      'incidentManagement.testCenters.testcentersData',
      IncidentManagementActions.SAVE_TESTCENTERS,
      dispatch,
      state,
    );
    dispatch({ type: BreadCrumbActions.SHOW_BACK, payload: id });
    // eslint-disable-next-line
  }, []);

  const setUpIncidentPhotos = (photos: IncidentManagementPhoto[]) => {
    let photoData = { ...initialPhotoData };
    photos.forEach((item) => {
      switch (item.photoTypeCode) {
        case IncidentPhotoEnum.REGISTRATION_ID:
          photoData = { ...photoData, registrationId: item.photoUrl };
          break;
        case IncidentPhotoEnum.WRITTEN_TEST_ID:
          photoData = { ...photoData, writtenTestId: item.photoUrl };
          break;
        case IncidentPhotoEnum.WRITTEN_TEST_PHOTO:
        case IncidentPhotoEnum.WRITTEN_TEST_PHOTO_IAM:
        case IncidentPhotoEnum.WRITTEN_TEST_HR_PHOTO_IAM:
          photoData = { ...photoData, writtenTestPhoto: item.photoUrl };
          break;
        case IncidentPhotoEnum.SPEAKING_TEST_PHOTO:
          photoData = { ...photoData, speakingTestPhoto: item.photoUrl };
          break;
        case IncidentPhotoEnum.SPEAKING_TEST_ID:
          photoData = { ...photoData, speakingTestId: item.photoUrl };
          break;
      }
    });
    return photoData;
  };

  const getvrificationColor = (uuid: string) => {
    const status = currentIDOptions.find((item) => item.value === uuid);
    switch (status?.text) {
      case RadioEnum.ID_VERIFIED:
        return styles.green;
      case RadioEnum.ID_REJECTED:
        return styles.orange;
      case RadioEnum.ID_FLAGGED_FOR_REVIEW:
        return styles.yellow;
      default:
        return '';
    }
  };

  const getIdVerificationData = (bookingUuid: string) => {
    getIncidentManagementIdVerificationDetails(bookingUuid, props.serviceRequest).subscribe(
      (data: { idVerificationData: IncidentManagementIdVerificationDetails; status: AsyncResponseStatus }) => {
        if (data && data.status === AsyncResponseStatus.SUCCESS) {
          setIdVerificationInfo(data.idVerificationData);
          setVerificationPhotos(setUpIncidentPhotos(data.idVerificationData.photos));
          const idVerificationData = getCurrentIdStatus(data.idVerificationData.checkOutcomeStatusUuid);
          setVerification(idVerificationData);
          setIdVerificationStatus(idVerificationData);
        }
      },
    );
  };

  const getVerificationPostData = () => {
    return {
      bookingUuid: id,
      checkOutcomeStatusUuid:
        verification === RadioEnum.ID_REJECTED ? IDVerificationEnum.ID_REJECTED : IDVerificationEnum.ID_VERIFIED,
    };
  };

  const confirmationHandler = () => {
    updateIdVerification(getVerificationPostData(), props.serviceRequest).subscribe((response) => {
      if (response && response.status === AsyncResponseStatus.SUCCESS) {
        setEnableConfirmationBox(false);
        setSuccessMessageEnable(true);
        getIdVerificationData(id);
      }
    });
  };

  const manageEditConfirmationBox = () => {
    if (enableConfirmationBox && (verification === RadioEnum.ID_REJECTED || verification === RadioEnum.ID_VERIFIED)) {
      const buttonData = [
        {
          id: 'abdCancelButton',
          text: incidentManagementLabels.cancel,
          type: UIButtonType.SECONDARY,
          onChange: () => setEnableConfirmationBox(false),
        },
        {
          id: 'abdConfirmButton',
          text: incidentManagementLabels.confirm,
          type: UIButtonType.PRIMARY,
          onChange: confirmationHandler,
        },
      ];
      return (
        <GenericPopup
          id={'incidentManagementDialog'}
          title={incidentManagementLabels.idVerification}
          titlePosition={TitlePosition.DEFAULT}
          buttonStyle={ButtonPosition.RIGHT}
          buttonData={buttonData}
          dialogType={DialogType.CUSTOM}
          modalCloseHandler={() => setEnableConfirmationBox(false)}
        >
          <div className={styles.popUpMessage}>{incidentManagementLabels.idVerifyConfimationMessage}</div>
        </GenericPopup>
      );
    }
  };

  const getLabel = (arg: verifyPhotoEnum) => {
    switch (arg) {
      case verifyPhotoEnum.registrationId:
        return incidentManagementLabels.registrationId;
      case verifyPhotoEnum.speakingTestId:
        return incidentManagementLabels.speakingTestId;
      case verifyPhotoEnum.speakingTestPhoto:
        return incidentManagementLabels.speakingTestPhoto;
      case verifyPhotoEnum.writtenTestId:
        return incidentManagementLabels.writtenTestId;
      case verifyPhotoEnum.writtenTestPhoto:
        return incidentManagementLabels.writtenTestPhoto;
    }
  };

  const generateHeaderValues = () => {
    const rowData = [
      {
        label: incidentManagementLabels.givenName,
        value: idVerificationInfo.bookingDetails.firstName,
      },
      {
        label: incidentManagementLabels.familyName,
        value: idVerificationInfo.bookingDetails.lastName,
      },
      {
        label: incidentManagementLabels.testCentre,
        value: getLocationName(idVerificationInfo.bookingDetails.locationUuid, testcentersResponse),
      },
      {
        label: incidentManagementLabels.testDate,
        value: formatDate(new Date(idVerificationInfo.bookingDetails.testDate), incidentManagementLabels.uiDateFormat),
      },
      {
        label: incidentManagementLabels.testTakerNumber,
        value: idVerificationInfo.bookingDetails.uniqueTestTakerId,
      },
      {
        label: incidentManagementLabels.currentIdVerificationStatus,
        value: (
          <div className={styles.colorDivision}>
            <p className={getvrificationColor(idVerificationInfo.checkOutcomeStatusUuid)} />{' '}
            <b>{idVerificationStatus}</b>
          </div>
        ),
      },
    ] as LabelElements[];
    return [
      {
        rowElements: rowData,
        type: UITypography.REGULAR,
        size: 16,
      },
    ] as PatchRowData[];
  };

  return (
    <div className={styles.superContainer}>
      {isSuccessMessageEnable ? (
        <div className={styles.messageContainer}>
          <UI.Message
            message={incidentManagementLabels.idPhotoSuccessMessage}
            color="success"
            dismissable
            onChange={() => setSuccessMessageEnable(false)}
          />
        </div>
      ) : null}
      <div className={styles.superHeaderContent}>
        <UI.Typography
          type={UITypography.REGULAR}
          label={incidentManagementLabels.idVerification}
          size={32}
          id="title"
        />
      </div>
      {manageEditConfirmationBox()}
      <DisplayLabelPatch rowsData={generateHeaderValues()} className={styles.detailContainer} />
      <div className={styles.ttPhotoWrapper}>
        <div className={styles.ttPhotoDetails}>
          <div className={styles.header}>
            <div className={styles.headerTitle}>
              <img alt={''} src={checkIcon} className={styles.headerIcon} />
              {incidentManagementLabels.idVerification}
            </div>
          </div>
          <div className={styles.body}>
            <div className={styles.photoGroup}>
              {Object.keys(verificationPhotos).map((item: string) => {
                const data = verificationPhotos as Dictionary;
                const url = data[item] !== '' ? data[item] : undefined;
                return (
                  <div className={styles.testTakerPhoto} key={item}>
                    <div className={styles.photoLabel}>{getLabel(item as verifyPhotoEnum)}</div>
                    <TestTakerPhoto
                      photoUrl={url}
                      photoStyle={styles.photoCard}
                      defaultPhotoStyle={styles.defaultPicture}
                      wrapperDivStyle={styles.photoCard}
                    />
                  </div>
                );
              })}
            </div>
            <div className={styles.buttonContainer}>
              <div>
                <span>
                  <input
                    id="verified"
                    type="radio"
                    name="verification"
                    value={RadioEnum.ID_VERIFIED}
                    checked={verification === RadioEnum.ID_VERIFIED}
                    onChange={(e) => setVerification(e.target.value)}
                    className={styles.inputRadio}
                  />
                </span>
                <label htmlFor="verified">{incidentManagementLabels.idVerified}</label>
              </div>
              <div>
                <span>
                  <input
                    id="rejected"
                    type="radio"
                    name="verification"
                    value={RadioEnum.ID_REJECTED}
                    checked={verification === RadioEnum.ID_REJECTED}
                    onChange={(e) => setVerification(e.target.value)}
                    className={styles.inputRadioSec}
                  />
                </span>
                <label htmlFor="rejected">{incidentManagementLabels.idRejected}</label>
              </div>
              <div className={styles.submitBtnContainer}>
                <UI.Button
                  label={incidentManagementLabels.submitLabel}
                  onChange={() => setEnableConfirmationBox(true)}
                  color={UIButtonType.PRIMARY}
                  id="idVerifiedButton"
                  disabled={!(verification === RadioEnum.ID_REJECTED || verification === RadioEnum.ID_VERIFIED)}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default withServiceRequest(IncidentManagementPhotoVerificationPanel);
