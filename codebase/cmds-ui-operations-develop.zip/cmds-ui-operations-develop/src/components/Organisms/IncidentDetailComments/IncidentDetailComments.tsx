import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import { IncidentComments, CommentUserType } from '../../../services/Models/IncidentManagement';
import styles from './IncidentDetailComments.module.scss';
import Comments from '../Comments/Comments';
import { UITypography } from '../../../services/Models/UIModels';

interface IncidentCommentsProps {
  comments: IncidentComments[];
  commentLabel: string;
}

const IncidentDetailComments = (props: IncidentCommentsProps) => {
  const reviewerComments = props.comments.filter((item) => item.userType !== CommentUserType.REPORTER);
  return (
    <div className={styles.commentSection}>
      <UI.Typography type={UITypography.REGULAR} id={'commentLabel'} label={props.commentLabel} size={16} />
      {reviewerComments.map((comment, index) => {
        return (
          <Comments
            comment={comment.comment}
            commentDateTime={comment.commentDateTime}
            commentEnteredBy={comment.commentEnteredBy}
            key={`${comment.commentDateTime}_${comment.commentEnteredBy}_${index}`}
            isLastComment={reviewerComments.length - 1 === index}
          />
        );
      })}
    </div>
  );
};

export default IncidentDetailComments;
