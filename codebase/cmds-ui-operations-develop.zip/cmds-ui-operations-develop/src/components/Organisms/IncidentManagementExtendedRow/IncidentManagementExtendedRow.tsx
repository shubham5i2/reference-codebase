import React from 'react';
import UI from 'ielts-cmds-ui-component-library';

import styles from './IncidentManagementExtendedRow.module.scss';
import { IncidentSearchResponse } from '../../../services/Models/IncidentManagement';
import { languageService } from '../../../services/Language/LanguageService';
import { getIncidentSeverity, getIncidentType } from '../../../services/API/Reference/Incident';
import { getProductValue } from '../../../services/API/Result/Product';
import { useStateValue } from '../../../Store/helpers/UseStateValue';

const IncidentManagementExtendedGrid = (props: { expandedData: IncidentSearchResponse | undefined }) => {
  const incidentManagementLabels = languageService().incidentManagement;
  const { state } = useStateValue();
  const productResponse = state.products.response;
  return (
    <React.Fragment>
      <tr id="expandedRow" className={styles.expandedRow}>
        <td colSpan={1} />
        <td colSpan={9} className={styles.expandedTd}>
          <UI.DisplayLabelValuePair
            id={'identityDocNo'}
            label={incidentManagementLabels.identityDocNo}
            value={props.expandedData?.identityNumber ? props.expandedData.identityNumber : ''}
            type="regular"
            size={15}
          />
          <UI.DisplayLabelValuePair
            id={'product'}
            label={incidentManagementLabels.product}
            value={
              props.expandedData?.productUuid ? getProductValue(props.expandedData?.productUuid, productResponse) : ''
            }
            type="regular"
            size={15}
          />
          <UI.DisplayLabelValuePair
            id={'incidentType'}
            label={incidentManagementLabels.incidentType}
            value={getIncidentType(props.expandedData?.incidentTypeUuid ? props.expandedData.incidentTypeUuid : '')}
            type="regular"
            size={15}
          />
          <UI.DisplayLabelValuePair
            id={'incidentSeverity'}
            label={incidentManagementLabels.severity}
            value={getIncidentSeverity(props.expandedData?.incidentSeverity ? props.expandedData.incidentSeverity : '')}
            type="regular"
            size={15}
          />
        </td>
      </tr>
    </React.Fragment>
  );
};

export default IncidentManagementExtendedGrid;
