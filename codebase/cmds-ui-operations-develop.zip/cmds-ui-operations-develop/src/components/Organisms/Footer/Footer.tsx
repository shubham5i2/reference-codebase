import React, { useState } from 'react';
import styles from './Footer.module.scss';
import { languageService } from '../../../services/Language/LanguageService';
import FooterDialog from '../../Others/FooterDialog/FooterDialog';
import UI from 'ielts-cmds-ui-component-library';

interface FooterProps {
  copyRightText: string;
  footerLinks: string[];
}

const Footer = (props: FooterProps) => {
  const commonLabels = languageService().common;
  const [showDisclaimerDialog, setShowDisclaimerDialog] = useState(false);
  const [showLegalDialog, setShowLegalDialog] = useState(false);

  const getFooterDialog = (footerLink: string) => {
    if (footerLink === commonLabels.disclaimer) {
      setShowDisclaimerDialog(true);
      setShowLegalDialog(false);
    } else if (footerLink === commonLabels.legal) {
      setShowLegalDialog(true);
      setShowDisclaimerDialog(false);
    } else {
      window.open(commonLabels.privacyPolicyLink, '_blank');
    }
  };

  const getDisclaimerDialog = () => {
    return showDisclaimerDialog ? (
      <FooterDialog
        id="disclaimer"
        headerText={commonLabels.disclaimer}
        pageContent={commonLabels.disclaimerContent}
        cancelHandler={() => setShowDisclaimerDialog(false)}
      />
    ) : null;
  };

  const getLegalDialog = () => {
    return showLegalDialog ? (
      <FooterDialog
        id="legal"
        headerText={commonLabels.legal}
        pageContent={commonLabels.legalContent}
        cancelHandler={() => setShowLegalDialog(false)}
      />
    ) : null;
  };
  return (
    <div className={styles.footerWrapper}>
      <div className={styles.footerWrapperContainer}>
        {getDisclaimerDialog()}
        {getLegalDialog()}
        <UI.Footer
          copyRightText={props.copyRightText}
          footerLinks={props.footerLinks}
          handleClickEvent={getFooterDialog}
        />
      </div>
    </div>
  );
};

export default Footer;
