import React from 'react';
import UI from 'ielts-cmds-ui-component-library';

import styles from './Comments.module.scss';
import clockIcon from '../../../assets/images/Clock.svg';
import commentHeadIcon from '../../../assets/images/Group.jpg';
import { manageDateTime } from '../../utils/utilities';
import { DateDivision } from '../../../services/Models/IncidentManagement';

interface CommentsProps {
  comment: string;
  commentEnteredBy: string;
  commentDateTime: string;
  isLastComment: boolean;
}

const Comments = (props: CommentsProps) => {
  const { comment, commentDateTime, commentEnteredBy, isLastComment } = props;
  const commentStyle = isLastComment ? styles.actualCommentLast : styles.actualComment;
  return (
    <div className={commentStyle}>
      <div className={styles.commentNameContainer}>
        <UI.Icon icon={commentHeadIcon} />
        <span>{commentEnteredBy}</span>
      </div>
      <div className={styles.commentDescription}>{comment}</div>
      <div className={styles.commentTime}>
        <UI.Icon icon={clockIcon} alt="clock" />
        <span>{manageDateTime(commentDateTime, DateDivision.DIVIDED)}</span>
      </div>
    </div>
  );
};

export default Comments;
