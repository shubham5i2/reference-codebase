import React from 'react';

import styles from './ManageUserFormHeader.module.scss';
import UI from 'ielts-cmds-ui-component-library';
import { languageService } from '../../../services/Language/LanguageService';

const FormTitle = (props: any) => {
  const { showMessage, title, showOptionalMessage, pageTitle } = props;
  const smLabels = languageService().staffManagement;
  return (
    <React.Fragment>
      <div className={!pageTitle && styles.formTitle}>
        <UI.Typography type="normal" id={title} label={title} size={props.size || 32} />
      </div>
      {showMessage ? (
        <div className={styles.sm_info}>
          <UI.Typography type="normal" label={smLabels.mandatoryFields} size={12} id="mandatoryFieldCaption" />
          {showOptionalMessage ? (
            <UI.Typography
              type="normal"
              label={smLabels.formFieldMandatoryMessage}
              size={12}
              id="optionalFieldCaption"
            />
          ) : (
            ''
          )}
        </div>
      ) : (
        ''
      )}
    </React.Fragment>
  );
};

export default FormTitle;
