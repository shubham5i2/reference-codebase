export enum reportTypes {
  TRF = 'trf',
  ETRF = 'etrf',
}

export enum renditionId {
  trf = '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
  etrf = '15b2e233-81a4-4263-b327-9b47ba09eb01',
}
