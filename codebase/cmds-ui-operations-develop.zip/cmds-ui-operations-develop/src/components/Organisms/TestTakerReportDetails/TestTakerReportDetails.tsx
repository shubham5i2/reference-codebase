import React from 'react';
import styles from './TestTakerReportDetails.module.scss';
import TakerTRFLabels from '../../../services/Language/en/en.testtakertrf';
import { TestTakerGrid } from '../TestTakerBookingGrid/FormatTestTakerBookingData';
import download from '../../../assets/images/download.png';
import { reportTypes } from './TestTakerReportDetailsConstants';

interface TestTakerReportProps {
  data: TestTakerGrid;
  reportType: reportTypes;
  downloadReportHandler: (reportType: string) => void;
}

const TestTakerReportDetails = (props: TestTakerReportProps) => {
  const formattedData: TestTakerGrid = props.data as TestTakerGrid;
  const { reportType, downloadReportHandler } = props;

  const height = {
    height: '15px',
  };

  const getReportButtonName = () => {
    return reportType === reportTypes.ETRF ? 'Download eTRF' : 'Download TRF';
  };

  const getReportTitle = () => {
    return reportType === reportTypes.ETRF
      ? TakerTRFLabels.donwloadEtrfEventCount
      : TakerTRFLabels.donwloadTrfEventCount;
  };

  return (
    <div className={styles.bookingGridMain}>
      <div className={styles.eventContainer}>
        <div className={styles.templateDetails}>
          {formattedData[reportType]?.printEventCount &&
          formattedData[reportType]?.printedDateTime &&
          formattedData[reportType]?.printedBy ? (
            <div className={styles.eventDetails}>
              <span>{getReportTitle()}</span>
              <p>
                {TakerTRFLabels.count}{' '}
                <span
                  className={
                    (formattedData[reportType]?.printEventCount.toString().length < 2 && styles.printCountDetails) || ''
                  }
                >
                  {formattedData[reportType]?.printEventCount}&nbsp;&nbsp;&nbsp;
                </span>
                {formattedData[reportType]?.printedDateTime}&nbsp;&nbsp; {formattedData[reportType]?.printedBy}
              </p>
            </div>
          ) : (
            <div className={styles.templateDetailsNotAvailable}></div>
          )}
        </div>
        <div>
          {/* : We need to have an option to pass svg to UI icons */}
          <div className={styles.addButton}>
            <button
              className={styles.downloadBtn}
              onClick={() => downloadReportHandler(reportType)}
              id={reportType === reportTypes.ETRF ? 'DownloadETRF' : 'DownloadTRF'}
            >
              <img src={download} alt="download icon" style={height} />
              <span className={styles.buttonText}>{getReportButtonName()}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TestTakerReportDetails;
