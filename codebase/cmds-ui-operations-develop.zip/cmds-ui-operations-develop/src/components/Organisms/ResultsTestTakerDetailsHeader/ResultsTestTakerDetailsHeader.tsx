import React from 'react';
import UI from 'ielts-cmds-ui-component-library';

import styles from './ResultsTestTakerDetailsHeader.module.scss';
import { languageService } from '../../../services/Language/LanguageService';
import BookingCalendar from '../../../assets/images/BookingCalendar.svg';
import Edit from '../../../assets/images/Edit.svg';
import Update from '../../../assets/images/Update.svg';
import { RESULTS_SUB_FEATURE } from '../../../services/feature-toggle/feature-types/sub-feature/SubFeature';
import featureConfig from '../../../services/feature-toggle/FeatureConfig';
import OnHold from '../../../assets/images/OnHold.png';
import { useHistory } from 'react-router-dom';
import { HeaderData } from '../../Pages/Results/ResultsTestTakerDetails/ResultsTestTakerDetailsConstants';
import { getValue, statusStyle } from '../../utils/utilities';
export interface ResultsTestTakerDetailsHeader {
  onTabChange?: (e: React.MouseEvent<HTMLElement>, id?: string) => void;
  testTakerTitle: string;
  resultsStatus: string | undefined;
  resultsStatusLabel: string;
  resultsOnHoldStatus?: boolean | null;
  headerData: HeaderData | null;
}

const ResultsTestTakerDetailsHeader: React.FC<ResultsTestTakerDetailsHeader> = (
  props: ResultsTestTakerDetailsHeader,
) => {
  const resultLabels = languageService().result;
  const history = useHistory();
  const testTakerRedirectHandler = () => {
    history.replace(
      `/managetesttaker/testtakerbookinghistory/${props.headerData?.bookingResults?.personalDetails?.uniqueTestTakerUuid}/testtakerbookingdetails/${props.headerData?.selectedBookingUuid}`,
      {
        selectedBookingUuid: props.headerData?.selectedBookingUuid,
        selectedTestTakerUuid: props.headerData?.bookingResults?.personalDetails.uniqueTestTakerUuid,
        selectedUniqueTestTakerId: props.headerData?.bookingResults?.personalDetails.uniqueTestTakerId,
      },
    );
  };
  const updateResultRedirectHandler = () => {
    history.push(`/results/updateresultstatus/${props.headerData?.selectedBookingUuid}`, {
      resultsStatusData: {
        firstName: props.headerData?.bookingResults?.personalDetails.givenName,
        lastName: props.headerData?.bookingResults?.personalDetails.familyName,
        testCentre: props.headerData?.bookingResults?.testBookingDetails.testCentreName,
        testDate: props.headerData?.bookingResults?.testBookingDetails.testDate,
        shortCandidateNumber: props.headerData?.bookingResults?.testBookingDetails.shortCandidateNumber,
        resultStatus: props.headerData?.bookingResults?.currentResultStatus.resultStatusType,
      },
    });
  };
  const manualMarkUpdateRedirectHandler = () => {
    history.push(`/results/updatemarks`, {
      bookingUuid: props.headerData?.selectedBookingUuid,
      candidateCompositeNumber: props.headerData?.bookingResults?.testBookingDetails.compositeCandidateNumber,
    });
  };
  return (
    <>
      <div className={styles.Container}>
        <div className={styles.TitleContainer}>
          <div className={styles.TitleLeftSide}>
            <div className={styles.Title}>
              <UI.Typography label={props.testTakerTitle} size={32} id="testTakerTitle" />
            </div>
            <div className={styles.SubTitle}>
              <div className={styles.SubTitleResultsStatus}>
                <div>{resultLabels.resultsStatusLabel}</div>
                <UI.Status
                  status={statusStyle[getValue(props.resultsStatus).toUpperCase()]}
                  label={getValue(props.resultsStatus)}
                />
              </div>
              <div className={styles.SubTitleResultsStatusLabel}>
                <div>{props.resultsStatusLabel && resultLabels.resultsStatusLabelLabel}</div>
                <div id="resultsStatusLabel">{props.resultsStatusLabel}</div>
              </div>
              <div>{props.resultsOnHoldStatus && <img src={OnHold} alt="OnHoldFlag" />}</div>
            </div>
          </div>
          <div className={styles.ActionButtons}>
            <div className={[styles.ActionButton, styles.BookingIcon].join(' ')} onClick={testTakerRedirectHandler}>
              <img src={BookingCalendar} alt="Full booking details" height="24px" />
              {resultLabels.fullBookingDetailsLabel}
            </div>
            {/* <div className={styles.ActionButton}>
              <img src={InitiateEOR} alt="Initiate EOR" height="32px" />
              {resultLabels.initiateEOR}
            </div> */}
            <div className={[styles.ActionButton, styles.updateStatus].join(' ')} onClick={updateResultRedirectHandler}>
              <img src={Edit} alt="Update status" height="32px" />
              {resultLabels.updateStatus}
            </div>
            {props.resultsStatus === 'Unconfirmed' &&
              props.headerData?.bookingResults?.currentResultStatus.resultStatusLabel === 'Manual Marks Update' && (
                <div
                  className={[styles.ActionButton, styles.manualMarkUpdate].join(' ')}
                  onClick={manualMarkUpdateRedirectHandler}
                >
                  <img src={Update} alt="Manual Mark Update" height="32px" />
                  {resultLabels.manualMarkIcontext}
                </div>
              )}
          </div>
        </div>

        <UI.Tabs
          initialActiveTab={resultLabels.bookingDetailsLabel.toUpperCase()}
          id="resultsTestTakerDetailsHeader"
          changeTabHandler={props.onTabChange}
          tabBtnStyle={styles.CnameTabBtn}
          buttonStyle={styles.CnameBtn}
          activeBtnStyle={styles.CnameBtnActive}
        >
          <UI.Tab
            label={resultLabels.bookingDetailsLabel.toUpperCase()}
            isClickable={featureConfig[RESULTS_SUB_FEATURE.bookingDetails].enable}
          />
          <UI.Tab
            label={resultLabels.statusHistoryLabel.toUpperCase()}
            isClickable={featureConfig[RESULTS_SUB_FEATURE.statusHistory].enable}
          />
          <UI.Tab label={resultLabels.scoreHistoryLabel.toUpperCase()} isClickable={true} />
          <UI.Tab label={resultLabels.testTakerPhotoLabel.toUpperCase()} isClickable={true} />
        </UI.Tabs>
      </div>
    </>
  );
};

export default ResultsTestTakerDetailsHeader;
