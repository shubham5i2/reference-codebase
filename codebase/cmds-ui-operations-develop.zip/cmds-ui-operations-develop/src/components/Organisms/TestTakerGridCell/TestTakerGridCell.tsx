import React from 'react';
import { TestTakerGridCellProps } from '../../../services/Models/TestTakerManagement';
import { TestTakerGridCellType } from '../ManageTestTakerGrid/ManageTestTakerGridConstants';
import styles from './TestTakerGridCell.module.scss';
import UI from 'ielts-cmds-ui-component-library';
import testTakerLabels from '../../../services/Language/en/en.testtaker';
import { getValue, statusStyle } from '../../utils/utilities';

const TestTakerGridCell = (props: TestTakerGridCellProps) => {
  const value = props.value || '';

  switch (props.cellType) {
    case TestTakerGridCellType.UNIQUETESTTAKERID:
    case TestTakerGridCellType.CMDSBOOKINGID:
    case TestTakerGridCellType.IDENTITYDOCUMENTNUMBER:
    case TestTakerGridCellType.GIVENNAME:
    case TestTakerGridCellType.FAMILYNAME:
    case TestTakerGridCellType.EMAILID:
    case TestTakerGridCellType.DATEOFBIRTH:
    case TestTakerGridCellType.NATIONALITY:
    case TestTakerGridCellType.TESTDATE:
    case TestTakerGridCellType.TESTCENTRE:
    case TestTakerGridCellType.TESTTAKERNUMBER:
    case TestTakerGridCellType.CENTRENUMBER:
    case TestTakerGridCellType.INCIDENTCATAGORY:
    case TestTakerGridCellType.INCIDENTSTATUS:
    case TestTakerGridCellType.INCIDENTTYPE:
    case TestTakerGridCellType.INCIDENTSEVERITY:
      return (
        <label id={props.id} className={`${styles.roLabel}`}>
          {value}
        </label>
      );
    case TestTakerGridCellType.BANNEDSTATUS:
      if (value && value === 'BANNED')
        return (
          <label id={props.id} className={`${styles.bannedlabel} ${styles.roLabel}`}>
            {testTakerLabels.banned}
          </label>
        );
      return null;
    case TestTakerGridCellType.VERIFICATIONSTATUS:
      return (
        <UI.Status
          label={value}
          status={statusStyle[getValue(value).toUpperCase()]}
          typographyProps={{ size: 12 }}
          theme={'plain'}
        />
      );
    case TestTakerGridCellType.CHECKBOX:
      return <UI.CheckBox id={props.id} checked={props.defaultCheck} onChange={props.onChangeHandler} />;
    case TestTakerGridCellType.MORE:
    case TestTakerGridCellType.EXPAND:
      return (
        <button id={props.id} className={styles.more} onClick={props.onChangeHandler} disabled={props.disability}>
          <img alt="" src={props.icon} className={props.disability ? `${styles.disableIcon}` : ''} />
        </button>
      );
    default:
      return null;
  }
};

export default TestTakerGridCell;
