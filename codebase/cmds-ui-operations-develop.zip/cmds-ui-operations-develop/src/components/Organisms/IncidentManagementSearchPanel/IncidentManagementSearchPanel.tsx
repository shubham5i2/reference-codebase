//: Search panel will refactored as part of https://btsservice.atlassian.net/browse/IMOD-33283

import React, { useState, useEffect } from 'react';
import UI from 'ielts-cmds-ui-component-library';

import styles from './IncidentManagementSearchPanel.module.scss';
import ChevronDownIcon from '../../../assets/images/Chevron_Down.svg';
import ChevronUpIcon from '../../../assets/images/Chevron_Up.svg';
import { dateRange } from '../../Pages/Results/ResultsSearchPanel/ResultsSearchPanel';
import { AdvancedSearchDataType, BasicSearchDataType } from '../../../services/Models/IncidentManagement';
import { languageService } from '../../../services/Language/LanguageService';
import { ServiceRequest } from '../../../services/utils/ServiceRequest';
import IncidentManagementAdvanceSearchPanel from '../IncidentManagementAdvanceSearchPanel/IncidentManagementAdvanceSearchPanel';
import IncidentManagementBasicSearchPanel from '../IncidentManagementBasicSearchPanel/IncidentManagementBasicSearchPanel';
import {
  initialAdvancedSearchData,
  initialBasicSearchData,
} from '../../../constants/IncidentManagement/IncidentManagementSearchPanelConstants';
import * as IncidentManagementActions from '../../../Store/Actions/IncidentManagementActions';
import { useStateValue } from '../../../Store/helpers/UseStateValue';
import { UIButtonType, UITypography } from '../../../services/Models/UIModels';

export interface IncidentManagementSearchPanelProps {
  basicSearchData: BasicSearchDataType;
  advanceSearchData: AdvancedSearchDataType;
  initialOpenState: boolean;
  isSearchCriteriaValid: boolean;
  errorMessage: string;
  serviceRequest: ServiceRequest;
  setAdvancedSearchData: (arg: AdvancedSearchDataType) => void;
  onBasicSearchHandler: () => void;
  onAdvancedSearchHandler: () => void;
  setClearBasicSearch: (arg: boolean) => void;
  setBasicSearchData: (arg: BasicSearchDataType) => void;
  setClearAdvancedSearch: (arg: boolean) => void;
  setSearchCriteriaValid: (arg: boolean) => void;
  fetchProductDataOnLoad?: boolean;
}

const IncidentManagementSearchPanel = (props: IncidentManagementSearchPanelProps) => {
  const [open, setOpen] = useState(false);
  const [currentCatagoryValue, setCurrentCatagory] = useState(props.advanceSearchData.incidentcatagory);

  const { dispatch } = useStateValue();

  const incidentManagementLabels = languageService().incidentManagement;

  useEffect(() => {
    setOpen(props.initialOpenState);
  }, [props.initialOpenState]);

  const updateStateOnClearSearch = () => {
    dispatch({
      type: IncidentManagementActions.CLEAR_SEARCH,
    });
  };

  const onClearBasicSearch = (event: React.FormEvent<HTMLInputElement> | React.FormEvent<HTMLAnchorElement>) => {
    event.preventDefault();
    props.setBasicSearchData(initialBasicSearchData);
    props.setClearBasicSearch(false);
    updateStateOnClearSearch();
  };

  const onClearAdvancedSearch = (event: React.FormEvent<HTMLInputElement> | React.FormEvent<HTMLAnchorElement>) => {
    event.preventDefault();
    props.setBasicSearchData(initialBasicSearchData);
    props.setAdvancedSearchData(initialAdvancedSearchData);
    props.setClearBasicSearch(false);
    props.setClearAdvancedSearch(false);
    updateStateOnClearSearch();
  };

  const handleBasicInputChange = (key: string, value: string | dateRange) => {
    props.setClearBasicSearch(true);
    props.setBasicSearchData({ ...props.basicSearchData, [key]: value });
  };

  const handleAdvancedInputChange = (e: React.FormEvent<HTMLInputElement>) => {
    props.setClearAdvancedSearch(true);
    const target = e.target as HTMLInputElement;
    const value = target.value;
    props.setAdvancedSearchData({ ...props.advanceSearchData, [target.name]: value });
  };

  const handleDropdownChange = (e: { name: string; value: string }) => {
    props.setClearAdvancedSearch(true);
    if (e.name === 'incidentcatagory' && e.value !== currentCatagoryValue) {
      setCurrentCatagory(e.value);
      props.setAdvancedSearchData({
        ...props.advanceSearchData,
        [e.name]: e.value,
        incidenttype: initialAdvancedSearchData.incidenttype,
      });
    } else {
      props.setAdvancedSearchData({ ...props.advanceSearchData, [e.name]: e.value });
    }
  };

  return (
    <React.Fragment>
      {!props.isSearchCriteriaValid ? (
        <div className={styles.messageContainer}>
          <UI.Message
            message={props.errorMessage}
            color="error"
            dismissable
            onChange={() => props.setSearchCriteriaValid(true)}
          />
        </div>
      ) : null}
      <div className={styles.searchPanel}>
        <div className={styles.searchPanelTitle}>
          <UI.Typography
            type={UITypography.REGULAR}
            label={incidentManagementLabels.incidentManagement}
            size={32}
            id="title"
          />
        </div>
        <div className={styles.searchPanelSubTitle}>
          <UI.Typography
            type={UITypography.REGULAR}
            label={incidentManagementLabels.incidentManagementSubTitle}
            size={16}
            id="subTitle"
          />
          <span className={styles.mandatoryLabel} />
        </div>
        <IncidentManagementBasicSearchPanel
          basicSearchData={props.basicSearchData}
          handleBasicInputChange={handleBasicInputChange}
          serviceRequest={props.serviceRequest}
          fetchProductDataOnLoad={props.fetchProductDataOnLoad}
        />
        <div>
          <div className={styles.row}>
            <div className={styles.alignSelfCenter}>
              <a
                href="#collapse"
                onClick={() => setOpen(!open)}
                className={open ? styles.hidden : styles.collapseIcon}
                id="collapseTitle"
              >
                <UI.Icon icon={ChevronDownIcon} />
                <span className={styles.collapseTitle}>{incidentManagementLabels.advancedSearch}</span>
              </a>
              <span className={!open ? styles.hidden : styles.collapseOpenTitle}>{''}</span>
            </div>
            <div className={open ? styles.hidden : styles.pushLeft}>
              <a href="#clearBasic" onClick={onClearBasicSearch} className={styles.clearSearch} id="clearBasicSearch">
                <span>
                  {JSON.stringify(props.basicSearchData) !== JSON.stringify(initialBasicSearchData)
                    ? incidentManagementLabels.clearSearch
                    : ''}
                </span>
              </a>
            </div>
            <div className={open ? styles.hidden : ''}>
              <UI.Button
                label={incidentManagementLabels.search}
                onChange={props.onBasicSearchHandler}
                color={UIButtonType.PRIMARY}
                id="basicSearchButton"
              />
            </div>
          </div>

          <div className={open ? styles.panelCollapse : [styles.panelCollapse, styles.panelClose].join(' ')}>
            <IncidentManagementAdvanceSearchPanel
              advancedSearchData={props.advanceSearchData}
              handleAdvancedInputChange={handleAdvancedInputChange}
              handleDropdownChange={handleDropdownChange}
            />
            <div className={open ? styles.gridGap : ''}>
              <div className={styles.row}>
                <div className={styles.alignSelfCenter}>
                  <a
                    href="#collapse"
                    onClick={() => setOpen(!open)}
                    className={styles.collapseIcon}
                    id="collapseFooterTitle"
                  >
                    <UI.Icon icon={ChevronUpIcon} />
                    <span className={styles.collapseFooterTitle}>{incidentManagementLabels.basicSearch}</span>
                  </a>
                </div>
                <div className={styles.pushLeft}>
                  <a
                    href="#clearAdvanced"
                    onClick={onClearAdvancedSearch}
                    className={styles.clearSearch}
                    id="clearAdvancedSearch"
                  >
                    <span>
                      {JSON.stringify(props.advanceSearchData) !== JSON.stringify(initialAdvancedSearchData) ||
                      JSON.stringify(props.basicSearchData) !== JSON.stringify(initialAdvancedSearchData)
                        ? incidentManagementLabels.clearSearch
                        : ''}
                    </span>
                  </a>
                </div>
                <div>
                  <UI.Button
                    label={incidentManagementLabels.search}
                    onChange={props.onAdvancedSearchHandler}
                    color={UIButtonType.PRIMARY}
                    id="advancedSearchButton"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};
export default IncidentManagementSearchPanel;
