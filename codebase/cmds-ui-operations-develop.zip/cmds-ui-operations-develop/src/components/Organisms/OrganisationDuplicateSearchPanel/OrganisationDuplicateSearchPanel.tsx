import React from 'react';
import styles from './OrganisationDuplicateSearchPanel.module.scss';
import UI from 'ielts-cmds-ui-component-library';
import { languageService } from '../../../services/Language/LanguageService';
import { OrganisationInputChangeEvent } from '../../../services/Models/Organisation';

export interface organisationDuplicateSearchPanelProps {
  title: string;
  titleType: string;
  titleSize: number;
  subTitle?: string;
  subTitleType?: string;
  subTitleSize?: number;
  duplicateSearchData: { organisationName: string; city: string; postCode: string; fuzzyMatch: boolean };
  clearDuplicateSearch: string;
  handleDuplicateInputChange: (e: OrganisationInputChangeEvent) => void;
  onClearDuplicateSearch: (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>) => void;
  duplicateSearchButtonLabel: string;
  onDuplicateSearchHandler: () => void;
  duplicateSearchButtonColor: string;
}

const OrganisationDuplicateSearchPanel = (props: organisationDuplicateSearchPanelProps) => {
  const organisationLabels = languageService().organisation;
  return (
    <div className={styles.searchPanel}>
      <div className={styles.searchPanelTitle}>
        <UI.Typography type={props.titleType} label={props.title} size={props.titleSize} id="title" />
      </div>
      <div className={styles.searchPanelSubTitle}>
        <UI.Typography type={props.subTitleType} label={props.subTitle} size={props.subTitleSize} id="subTitle" />
      </div>
      <div className={styles.col2}>
        <UI.TextBox
          label={organisationLabels.organisationName}
          name="organisationName"
          placeholder=""
          value={props.duplicateSearchData.organisationName}
          onChange={props.handleDuplicateInputChange}
        />
        <UI.ToggleSwitch
          checked={props.duplicateSearchData.fuzzyMatch || false}
          label={organisationLabels.useFuzzyMatchLabel}
          onChange={(event: { target: HTMLInputElement }) =>
            props.handleDuplicateInputChange({ target: { name: event.target.name, value: event.target.checked } })
          }
          name="fuzzyMatch"
          color="#4f4f4f"
          toolTipMessage={organisationLabels.fuzzyToggleInfoDuplicateSearch}
        />
      </div>
      <div className={styles.searchBox + ' ' + styles.col3}>
        <UI.TextBox
          label={organisationLabels.city}
          name="city"
          placeholder=""
          value={props.duplicateSearchData.city}
          onChange={props.handleDuplicateInputChange}
        />
        <UI.TextBox
          label={organisationLabels.postCode}
          name="postCode"
          placeholder=""
          value={props.duplicateSearchData.postCode}
          onChange={props.handleDuplicateInputChange}
        />
      </div>

      <div>
        <div className={styles.row}>
          <div className={styles.pushLeft}>
            <a
              href="#clearDuplicate"
              onClick={props.onClearDuplicateSearch}
              className={styles.clearSearch}
              id="clearDuplicateSearch"
            >
              <span>{props.clearDuplicateSearch}</span>
            </a>
          </div>
          <div>
            <UI.Button
              label={props.duplicateSearchButtonLabel}
              onChange={props.onDuplicateSearchHandler}
              color={props.duplicateSearchButtonColor}
              id="duplicateSearchButton"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
export default OrganisationDuplicateSearchPanel;
