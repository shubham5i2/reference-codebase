import React, { useEffect } from 'react';
import UI from 'ielts-cmds-ui-component-library';

import { useAuth0 } from '@auth0/auth0-react';

import styles from './IncidentManagementViewHeader.module.scss';
import { ExternalIcon, IncidentManagementBookingDetails } from '../../../services/Models/IncidentManagement';
import ResultsIcon from '../../../assets/images/ResultIcon.png';
import BookingIcon from '../../../assets/images/BookingCalendar.svg';
import banIcon from '../../../assets/images/AddBan.png';
import checkIcon from '../../../assets/images/Icon_Check.svg';
import incidentManagementLabels from '../../../services/Language/en/en.incidentmanagement';
import { formatDate, getTestCenter } from '../../utils/utilities';
import { useStateValue } from '../../../Store/helpers/UseStateValue';

import withServiceRequest, { ServiceRequest } from '../../../services/utils/ServiceRequest';
import * as IncidentManagementActions from '../../../Store/Actions/IncidentManagementActions';
import { getLocationName } from '../../../services/API/ManageUser/Locations';
import ImageButton from '../../Molecules/ImageButton/ImageButton';
import { UITypography } from '../../../services/Models/UIModels';
import DisplayLabelPatch, { LabelElements, PatchRowData } from '../DisplayLabelPatch/DisplayLabelPatch';

interface IncidentManagementViewHeaderProps {
  data: IncidentManagementBookingDetails;
  serviceRequest: ServiceRequest;
  handleVistiToExternalPages: (arg: string) => void;
}

const IncidentManagementViewHeader = (props: IncidentManagementViewHeaderProps) => {
  const { state, dispatch } = useStateValue();
  const { user } = useAuth0();
  const { testcentersResponse } = state.incidentManagement.testCenters;

  useEffect(() => {
    getTestCenter(
      user,
      props.serviceRequest,
      'incidentManagement.testCenters.testcentersData',
      IncidentManagementActions.SAVE_TESTCENTERS,
      dispatch,
      state,
    );
    // eslint-disable-next-line
  }, []);

  const generateHeaderValues = () => {
    const firstRowData: LabelElements[] = [
      {
        label: incidentManagementLabels.uniqueTtNumber,
        value: props.data.uniqueTestTakerId,
      },
      {
        label: incidentManagementLabels.givenName,
        value: props.data.firstName,
      },
      {
        label: incidentManagementLabels.familyName,
        value: props.data.lastName,
      },
      {
        label: incidentManagementLabels.testDate,
        value: formatDate(new Date(props.data.testDate), incidentManagementLabels.uiDateFormat),
      },
      {
        label: incidentManagementLabels.testCentre,
        value: getLocationName(props.data.locationUuid, testcentersResponse),
      },
      {
        label: incidentManagementLabels.testTakerNumber,
        value: String(props.data.shortCandidateNumber).padStart(6, '0'),
      },
    ];

    return [
      {
        rowElements: firstRowData,
        type: UITypography.REGULAR,
        size: 16,
      },
    ] as PatchRowData[];
  };

  return (
    <React.Fragment>
      <div className={styles.headingContainer}>
        <UI.Typography
          type={UITypography.REGULAR}
          label={incidentManagementLabels.incidentDetails}
          size={32}
          id="title"
        />
        <div className={styles.iconContainer}>
          <ImageButton
            onClickHandler={() => props.handleVistiToExternalPages(ExternalIcon.BOOKING)}
            id={'externalBookingIcon'}
            labelType={UITypography.REGULAR}
            labelSize={12}
            icon={BookingIcon}
            label={incidentManagementLabels.bookings}
            buttonStyle={styles.iconButton}
          />
          <ImageButton
            onClickHandler={() => props.handleVistiToExternalPages(ExternalIcon.RESULT)}
            id={'externalResultIcon'}
            labelSize={12}
            icon={ResultsIcon}
            label={incidentManagementLabels.result}
            buttonStyle={styles.iconButton}
            labelType={UITypography.REGULAR}
          />
          <ImageButton
            onClickHandler={() => props.handleVistiToExternalPages(ExternalIcon.ID_VERIFICATION)}
            id={'externalIdVerificationIcon'}
            labelSize={12}
            icon={checkIcon}
            label={incidentManagementLabels.idVerification}
            buttonStyle={styles.iconButton}
            labelType={UITypography.REGULAR}
          />
          <ImageButton
            onClickHandler={() => {
              props.handleVistiToExternalPages(ExternalIcon.BANNING);
            }}
            id={'externalBanIcon'}
            labelSize={12}
            icon={banIcon}
            labelType={UITypography.REGULAR}
            label={incidentManagementLabels.banning}
            buttonStyle={styles.iconButton}
          />
        </div>
      </div>
      <DisplayLabelPatch rowsData={generateHeaderValues()} className={styles.headerPatch} />
    </React.Fragment>
  );
};

export default withServiceRequest(IncidentManagementViewHeader);
