import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import { languageService } from '../../../services/Language/LanguageService';
import styles from './LocationSearchPanel.module.scss';
import {
  LocationSearchCriteria,
  SearchPanelButtonType,
  LocationSearchElements,
  SearchFormEvent,
  LocationDetailControl,
  LOCATION_STATUS,
} from '../../../services/Models/LocationManagement';
import { useHistory } from 'react-router-dom';
import SearchPanelButtonGroup from '../../Molecules/SearchPanelButtonGroup';
import LocationDropdown from '../LocationDropdown/LocationDropdown';
import { LocationType } from '../LocationDropdown/LocationDropdownUtils';
import { DropDownDataSource } from '../../../services/Models/UIModels';
import PartnerDropDown from '../BaseDropDown/PartnerDropDown/PartnerDropDown';
import withServiceRequest, { ServiceRequest } from '../../../services/utils/ServiceRequest';
import { useAuth0 } from '@auth0/auth0-react';
import { isLMPartnerOnlyUser } from '../../Pages/LocationManagement/LocationManagementUtils';
import { auth0Namespace } from '../../../services/Models/StaffManagement';

export interface LocationSearchPanel {
  serviceRequest: ServiceRequest;
  basicSearchButtonColor?: string;
  basicSearchButtonLabel: string;
  searchData: LocationSearchCriteria;
  handleBasicInputChange: (key: string, value: string) => void;
  onSearchClearHandler: (SearchPanelButton: SearchPanelButtonType) => void;
  titleType: string;
  title: string;
  titleSize: number;
  addButtonLabel?: string;
  addButtonColor?: string;
  addButtonIcon?: string;
}

const LocationSearchPanel = (props: LocationSearchPanel) => {
  const locationLabels = languageService().locationManagement;
  const history = useHistory();
  const { user } = useAuth0();

  const onAddLocationHandler = () => {
    history.push('/locationManagement/addLocation');
  };

  const dropdownChangeHandler = (e: SearchFormEvent) => {
    props.handleBasicInputChange(e.name, e.value);
  };

  const handleTextBoxChange = (e: React.FormEvent<HTMLInputElement>) => {
    const target = e.target as HTMLInputElement;
    const value = target.value;
    props.handleBasicInputChange(target.name, value);
  };

  const isFieldsEmpty = () => {
    return (
      props.searchData.testCentreUuid?.trim() === '' &&
      props.searchData.partnerCode?.trim() === '' &&
      props.searchData.locationName?.trim() === '' &&
      props.searchData.status?.trim() === ''
    );
  };

  return (
    <div className={styles.searchPanel}>
      <div className={styles.searchPanelTitle}>
        <UI.Typography type={props.titleType} label={props.title} size={props.titleSize} id="title" />
        <span className={styles.floatRight}>
          {!isLMPartnerOnlyUser(user) ? (
            <UI.Button
              label={props.addButtonLabel}
              onChange={onAddLocationHandler}
              color={props.addButtonColor}
              icon={props.addButtonIcon}
              title={props.addButtonLabel}
              id="addNew"
            />
          ) : null}
        </span>
      </div>

      <div className={styles.searchInputBoxContainer}>
        <LocationDropdown
          id={'testCentre'}
          dropdownConfig={{
            placeholderText: locationLabels.pleaseSelectPlaceHolder,
            isMandatory: false,
            isFilterEnabled: true,
            customMapper: {
              text: 'testCentreNumber',
            },
          }}
          labelText={locationLabels.testCentreNumber}
          ignoreCache
          locationType={LocationType.TEST_CENTRE}
          assignableToGroups={false}
          checkCacheOnLoad
          dataSource={'searchLocations'}
          value={props.searchData.testCentreUuid}
          onChange={({ value, text }: DropDownDataSource) => {
            dropdownChangeHandler({
              name: LocationSearchElements.TESTCENTRE_NUMBER,
              value: text,
            });
            dropdownChangeHandler({
              name: LocationSearchElements.TESTCENTRE_UUID,
              value: value,
            });
          }}
        />

        <UI.TextBox
          label={locationLabels.testCenterName}
          name={LocationDetailControl.LOCATION_NAME}
          placeholder={locationLabels.pleaseEnterPlaceHolder}
          value={props.searchData.locationName}
          onChange={handleTextBoxChange}
        />

        <PartnerDropDown
          id={LocationDetailControl.PARTNER_CODE}
          labelId={'partnerCodeLbl'}
          label={locationLabels.partnerCode}
          selectedPartner={props.searchData.partnerCode}
          textBoxPlaceHolder={locationLabels.pleaseSelectPlaceHolder}
          canUseStoreData
          serviceRequest={props.serviceRequest}
          partnerCode={user?.[auth0Namespace + 'partnerCode']}
          onPartnerChange={(value: string) => {
            dropdownChangeHandler({
              name: LocationSearchElements.PARTNER_CODE,
              value: value,
            });
          }}
        />

        <UI.Dropdown
          id={LocationDetailControl.LOCATION_STATUS}
          label={locationLabels.testCenterStatus}
          labelId="LocationStatusLbl"
          placeholder={locationLabels.pleaseSelectPlaceHolder}
          selectedValue={props.searchData.status}
          list={LOCATION_STATUS}
          onChange={(value: string) => {
            dropdownChangeHandler({
              name: LocationSearchElements.LOCATION_STATUS,
              value: value,
            });
          }}
        />
      </div>
      <SearchPanelButtonGroup
        searchButtonTitle={props.basicSearchButtonLabel}
        onButtonClicked={props.onSearchClearHandler}
        clearButtonTitle={locationLabels.clearSearch}
        isClearButtonVisible={!isFieldsEmpty()}
        id="locationSearch"
      />
    </div>
  );
};
export default withServiceRequest(LocationSearchPanel);
