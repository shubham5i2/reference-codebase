import React from 'react';
import { TestTakerTRFGridCellProps } from '../../../services/Models/TestTakerTRF';
import { TestTakerTRFGridCellType } from '../TestTakerTRFGrid/TestTakerTRFGridConstants';
import styles from './TestTakerTRFGridCell.module.scss';

const TestTakerTRFGridCell = (props: TestTakerTRFGridCellProps) => {
  const value = props.value || '';

  switch (props.cellType) {
    case TestTakerTRFGridCellType.ORGANISATIONUUID:
    case TestTakerTRFGridCellType.ORGANISATIONNAME:
    case TestTakerTRFGridCellType.ORGANISATIONADDRESS:
    case TestTakerTRFGridCellType.SELECTIONDATE:
    case TestTakerTRFGridCellType.CASENUMBER:
    case TestTakerTRFGridCellType.PERSONDEPARTMENT:
    case TestTakerTRFGridCellType.CONFIRMATIONSTATUS:
    case TestTakerTRFGridCellType.CONFIRMATIONSTATUSCHANGEDDATETIME:
    case TestTakerTRFGridCellType.PRINTSTATUS:
    case TestTakerTRFGridCellType.PRINTSTATUSDATETIME:
    case TestTakerTRFGridCellType.ORGANISATIONTYPE:
      return (
        <label id={props.id} className={`${styles.roLabel}`}>
          {value}
        </label>
      );
    default:
      return null;
  }
};

export default TestTakerTRFGridCell;
