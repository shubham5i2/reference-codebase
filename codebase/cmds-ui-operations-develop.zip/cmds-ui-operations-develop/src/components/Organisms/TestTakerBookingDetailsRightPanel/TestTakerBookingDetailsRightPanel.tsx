import React from 'react';
import TestTakerPhoto from '../../Organisms/TestTakerPhoto/TestTakerPhoto';
import styles from './TestTakerBookingDetailsRightPanel.module.scss';
import defaultPhoto from '../../../assets/images/testTakerPhoto_default.png';
import { PhotoCategory } from '../../../services/Models/TestTakerManagement';

export interface TestTakerBookingDetailsRightPanelProps {
  photoUrl?: string;
  photoCategory?: string;
}

const TestTakerBookingDetailsRightPanel = (props: TestTakerBookingDetailsRightPanelProps) => {
  console.log('s3 photo -> ' + props.photoUrl);
  console.log('s3 photo category ->' + props.photoCategory);
  return (
    <React.Fragment>
      <div className={styles.ttbRightPanelContainer}>
        {props.photoCategory === PhotoCategory.Certificate ||
        props.photoCategory === PhotoCategory.Certificate.toLowerCase() ? (
          <TestTakerPhoto
            photoUrl={props.photoUrl}
            photoStyle={styles.photoPresent}
            defaultPhotoStyle={styles.defaultPicture}
            wrapperDivStyle={styles.card}
          />
        ) : (
          <div className={styles.card} id={'testTakerPhoto'}>
            <img className={styles.defaultPicture} src={defaultPhoto} alt="Logo" />
          </div>
        )}
      </div>
    </React.Fragment>
  );
};

export default TestTakerBookingDetailsRightPanel;
