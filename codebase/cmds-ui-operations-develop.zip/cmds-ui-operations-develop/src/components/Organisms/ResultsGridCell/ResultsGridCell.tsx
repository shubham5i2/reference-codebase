import React from 'react';
import { ResultsGridCellType } from '../ResultsGrid/ResultsGridConstants';
import styles from './ResultsGridCell.module.scss';
import UI from 'ielts-cmds-ui-component-library';
import OnHold from '../../../assets/images/OnHold.png';
export interface GridCellProps {
  id?: string;
  cellType: string;
  isExpanded?: boolean;
  value?: any;
  onChangeHandler?: () => void;
  icon?: any;
  isScoreUpdated?: boolean;
  defaultCheck?: boolean;
  onHoldStatus?: boolean | null;
  isExempt?: boolean;
  isEorPending?: boolean;
  isAbsent?: boolean;
}

const ResultsGridCell = (props: GridCellProps) => {
  const { value } = props;
  const statusClassName = typeof value === 'string' ? value.replace(' ', '').toLowerCase() : '';
  switch (props.cellType) {
    case ResultsGridCellType.UTTID:
    case ResultsGridCellType.FIRST_NAME:
    case ResultsGridCellType.LAST_NAME:
    case ResultsGridCellType.TEST_DATE:
    case ResultsGridCellType.TEST_CENTRE:
    case ResultsGridCellType.TEST_TAKER_NUMBER:
      return (
        <label id={props.id} className={`${styles.label}`}>
          {value}
        </label>
      );
    // Need to move this code to UI.Status component
    case ResultsGridCellType.RESULTS_STATUS:
      return (
        <div className={styles.resultStatusContainer}>
          <div id={props.id} className={styles.status}>
            <div className={`${styles.statusCircle} ${styles[statusClassName + 'StatusCircle']}`} />
            <label id="statusLabel" className={styles[statusClassName]}>
              {value}
            </label>
          </div>
          <div>{props.onHoldStatus ? <img className={styles.onHoldImage} alt="OnHold" src={OnHold} /> : null}</div>
        </div>
      );
    case ResultsGridCellType.MORE:
      return (
        <button id={props.id} className={styles.more} onClick={props.onChangeHandler}>
          <img alt="" src={props.icon} />
        </button>
      );
    case ResultsGridCellType.EXPAND:
      return (
        <button id={props.id} className={styles.more} onClick={props.onChangeHandler}>
          <img alt="" src={props.icon} className={props.isExpanded ? styles.expandedArrow : styles.collapsedArrow} />
        </button>
      );
    case ResultsGridCellType.CHECKBOX:
      return <UI.CheckBox id={props.id} checked={props.defaultCheck} onChange={props.onChangeHandler} />;
    default:
      return null;
  }
};

export default ResultsGridCell;
