import React from 'react';
import styles from '../AssignGroup/AssignGroup.module.scss';
import UI from 'ielts-cmds-ui-component-library';
import DatePicker from '../DatePicker/DatePicker';
import Close from '../../../assets/images/Close.svg';
import withServiceRequest, { ServiceRequest } from '../../../services/utils/ServiceRequest';
import { AssignGroupData, User } from '../../../services/Models/StaffManagement';
import { languageService } from '../../../services/Language/LanguageService';
import { FormStepType, FormActionType } from '../../utils/ValidationRules/ManageUserForm';
import { DropDownDataSource, RouteParams, UserFormError } from '../../../services/Models/UIModels';
import UserGroupDropDown from '../BaseDropDown/UserGroupDropDown/UserGroupDropDown';
import LocationDropdown from '../LocationDropdown/LocationDropdown';
import { useParams } from 'react-router-dom';
import { LocationType } from '../LocationDropdown/LocationDropdownUtils';
import { getOptionsListWithId } from '../../utils/utilities';

interface AssignGroupPanelProps {
  currentIndex: number;
  onChange: (event: any) => void;
  onRemovePanel: (selectedIndex: number) => void;
  data: AssignGroupData;
  error: UserFormError;
  count: number;
  userData: User;
  serviceRequest: ServiceRequest;
  isFetchLocationOnLoad: boolean;
}

const getEmailDomain = (email = '') => email.substring(email.lastIndexOf('@') + 1);

const locationType = [
  { text: 'Global', value: 'GLOBAL' },
  { text: 'Partner', value: 'PARTNER' },
  { text: 'Region', value: 'REGION' },
  { text: 'Country', value: 'COUNTRY' },
  { text: 'Test Centre', value: 'TEST_CENTRE' },
];

const AssignGroupPanel = (props: AssignGroupPanelProps) => {
  const { onChange, currentIndex, onRemovePanel, data, error, count, userData, isFetchLocationOnLoad } = props;
  const { id } = useParams<RouteParams>();

  const filterLocationType = () => {
    if (userData.partnerCode === 'GLOBAL_IELTS') {
      return locationType.filter((item) => item.value === 'GLOBAL');
    } else {
      return locationType.filter((item) => item.value !== 'GLOBAL');
    }
  };

  console.log({ locationType: data.locationType });
  const eventType = {
    index: currentIndex - 1 || 0,
    type: FormStepType.ASSIGN_GROUP,
    action: FormActionType.UPDATE,
  };
  const smLabels = languageService().staffManagement;

  return (
    <React.Fragment>
      <div className={styles.AssignGroupContainer} id={`ASSIGNMENT_PANEL_${currentIndex}`}>
        <div className={styles.ag_panel_header}>
          {count > 1 ? (
            <UI.Typography
              id={`ASSIGNMENT_${currentIndex}`}
              type="bold"
              label={`${smLabels.assignment.toUpperCase()}  ${currentIndex}`}
              size={14}
            />
          ) : (
            ''
          )}
          {!userData.userUuid && currentIndex > 1 ? (
            <span id={`panelClose_${currentIndex}`} onClick={() => onRemovePanel(currentIndex)}>
              <UI.Icon icon={Close} />
            </span>
          ) : (
            ''
          )}
        </div>
        <div className={styles.col3}>
          {!id ? (
            <UI.Dropdown
              id={`Location_Type_${currentIndex - 1}`}
              label={smLabels.locationType}
              labelId={'locationTypeLabel'}
              selectedValue={data.locationType}
              onChange={(e: string) => {
                const event = {
                  ...eventType,
                  target: {
                    name: 'locationType',
                    value: e,
                  },
                };
                return onChange(event);
              }}
              list={filterLocationType()}
              inputFieldValidation={error.locationType}
              placeholder={smLabels.locationTypePlaceholder}
            />
          ) : null}
          <LocationDropdown
            id={`Location_${currentIndex - 1}`}
            dropdownConfig={{
              isFilterEnabled: true,
              inputFieldValidationError: error,
              placeholderText: smLabels.locationPlaceholder,
              disabled: !id && !data.locationType,
            }}
            labelText={smLabels.location}
            locationType={!id ? data.locationType : LocationType.LOCATION_AND_BELOW}
            partnerCode={userData.partnerCode}
            assignableToGroups
            value={data.location}
            dataSource={'getLocations'}
            shouldPreSelectOnlyLocation
            text={data.locationName || ''}
            getOptionsList={data.locationType === LocationType.TEST_CENTRE ? getOptionsListWithId : undefined}
            checkCacheOnLoad={!!(id && isFetchLocationOnLoad)}
            onChange={({ value, text }: DropDownDataSource) => {
              const event = {
                ...eventType,
                target: {
                  name: 'location',
                  value,
                  locationName: text,
                },
              };
              return onChange(event);
            }}
          />
          <div className={styles.dateHolder}>
            <DatePicker
              id={`dateRange_${currentIndex - 1}`}
              ranges={data.dateRange}
              onChange={(e: any) => {
                const event = {
                  ...eventType,
                  ...e,
                };
                return onChange(event);
              }}
            />
          </div>
          {id ? <div></div> : null}
          <UserGroupDropDown
            id={`UserGroup_${currentIndex - 1}`}
            label={smLabels.userGroup}
            serviceRequest={props.serviceRequest}
            selectedUserGroupValue={data.userGroup}
            text={userData.assignGroupData?.[currentIndex - 1]?.userGroupName}
            onUserGroupChange={(e: string, text: string) => {
              const event = {
                ...eventType,
                target: {
                  name: 'userGroup',
                  value: e,
                  userGroupName: text,
                },
              };
              return onChange(event);
            }}
            searchPlaceHolderText={smLabels.usergroupSearchPlaceholder}
            textBoxPlaceHolder={smLabels.userGroupPlaceholder}
            inputFieldValidationError={error}
            partnerCode={userData.partnerCode}
            isFetchDataOnLoad
            isFilterEnabled
            isDisable={data.location.trim() === ''}
            locationUUid={data.location}
            emailDomain={getEmailDomain(userData.email)}
          />
        </div>
      </div>
      <div className={styles.sm_line_seperator}></div>
    </React.Fragment>
  );
};

export default withServiceRequest(AssignGroupPanel);
