import React from 'react';
import AddressForm from '../../Molecules/AddressForm/AddressForm';
import styles from './LocationAddressPanel.module.scss';
import UI from 'ielts-cmds-ui-component-library';
import { languageService } from '../../../services/Language/LanguageService';
import { AddressData, AddressFormEvent, AddressErrorField } from '../../../services/Models/LocationManagement';
import { UICheckboxChangeEvent } from '../../../services/Models/UIModels';
import { flattenAddressValidationObj } from '../../utils/utilities';
import { AddressType } from '../../../constants/LocationManagement/LocationConstants';
import { locationAddressFormRules } from '../../utils/ValidationRules/LocationForm';

interface LocationAddressPanelProps {
  handleAddressChange: (event: AddressFormEvent) => void;
  addressData: AddressData[];
  isPhysicalBuilding: boolean;
  onChangeSameAsPostal: (e: boolean) => void;
  isSameAsPostal: boolean;
  errors: AddressErrorField[];
}

const LocationAddressPanel = (props: LocationAddressPanelProps) => {
  const locationLabels = languageService().locationManagement;
  const { isPhysicalBuilding, onChangeSameAsPostal, isSameAsPostal, addressData, handleAddressChange, errors } = props;

  return (
    <div className={styles.addressPanel}>
      {isPhysicalBuilding === false && (
        <>
          <div className={styles.locPrimaryLabel}>
            <UI.Typography id="postalAddress" type="normal" label={locationLabels.postalAddress} size={14} />
          </div>
          <AddressForm
            addressData={addressData.find((item) => item.addressTypeUuid === AddressType.POSTAL)}
            id="postal"
            handleAddressChange={handleAddressChange}
            addressType={AddressType.POSTAL}
            mandatoryField={flattenAddressValidationObj(locationAddressFormRules[AddressType.POSTAL])}
            errors={errors.find((item: AddressErrorField) => item.addressTypeUuid === AddressType.POSTAL)}
          />
          <UI.CheckBox
            checked={isSameAsPostal}
            label={locationLabels.sameAsPostalLabels}
            labelId="resultPostalAddressLB"
            id="resultPostalAddress"
            onChange={(e: UICheckboxChangeEvent) => onChangeSameAsPostal(e.checked)}
          />
        </>
      )}

      {(isSameAsPostal === false || isPhysicalBuilding) && (
        <div>
          <div className={styles.locPrimaryLabel}>
            <UI.Typography id="physicalAddress" type="normal" label={locationLabels.physicalAddress} size={14} />
          </div>
          <AddressForm
            addressData={addressData.find((item) => item.addressTypeUuid === AddressType.PHYSICAL)}
            id="physical"
            handleAddressChange={handleAddressChange}
            addressType={AddressType.PHYSICAL}
            mandatoryField={flattenAddressValidationObj(locationAddressFormRules[AddressType.PHYSICAL])}
            errors={errors.find((item: AddressErrorField) => item.addressTypeUuid === AddressType.PHYSICAL)}
          />
        </div>
      )}
    </div>
  );
};

export default LocationAddressPanel;
