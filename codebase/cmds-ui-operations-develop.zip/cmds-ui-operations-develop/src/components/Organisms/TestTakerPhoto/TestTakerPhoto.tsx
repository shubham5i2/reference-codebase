import React from 'react';
import defaultPhoto from '../../../assets/images/testTakerPhoto_default.png';

export interface TestTakerPhotoProps {
  photoUrl?: string;
  photoStyle: string;
  defaultPhotoStyle: string;
  wrapperDivStyle: string;
}

const TestTakerPhoto = (props: TestTakerPhotoProps) => {
  return (
    <div className={props.wrapperDivStyle} id={'testTakerPhoto'}>
      <img
        className={props.photoUrl ? props.photoStyle : props.defaultPhotoStyle}
        src={props.photoUrl ? props.photoUrl : defaultPhoto}
        alt="Logo"
      />
    </div>
  );
};

export default TestTakerPhoto;
