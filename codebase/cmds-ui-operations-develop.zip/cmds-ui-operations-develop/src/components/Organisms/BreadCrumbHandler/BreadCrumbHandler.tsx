import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import { useLocation, useHistory, matchPath } from 'react-router-dom';
import styles from './BreadCrumbHandler.module.scss';
import { useStateValue } from '../../../Store/helpers/UseStateValue';

export interface BreadCrumbRoute {
  path: string;
  breadCrumbLabel: string;
}

export interface BreadCrumbHandlerProps {
  breadCrumbRouteConfig: BreadCrumbRoute[];
  id?: string;
}

const BreadCrumbHandler = (props: BreadCrumbHandlerProps) => {
  const { state } = useStateValue();
  const location = useLocation();
  const history = useHistory();
  const breadCrumbRoutes = props.breadCrumbRouteConfig.filter((crubRoute: BreadCrumbRoute) =>
    matchPath(location.pathname, {
      path: crubRoute.path,
    }),
  );

  const breadCrumbChanged = (selectedBreadCrumb: BreadCrumbRoute) => {
    let selectedBreadcrumbPath = selectedBreadCrumb.path;
    if (selectedBreadcrumbPath.search(':id') > 0) {
      selectedBreadcrumbPath = selectedBreadcrumbPath.replace(':id', state.breadCrumb.id);
    }
    history.push(selectedBreadcrumbPath);
  };

  const onBackClick = () => {
    const previousBreadCrumb = breadCrumbRoutes[breadCrumbRoutes.length - 2];
    let prevPath = previousBreadCrumb.path;
    if (previousBreadCrumb.path.search(':id') > 0) {
      prevPath = prevPath.replace(':id', state.breadCrumb.id);
    }
    history.push(prevPath);
  };

  return breadCrumbRoutes.length > 1 ? (
    <UI.BreadCrumb
      id="BreadCrumb"
      className={styles.breadCrumbHandler}
      crumbsRoute={breadCrumbRoutes}
      isBackAvailable={state.breadCrumb.showBack}
      breadCrumbClicked={(index: number) => {
        breadCrumbChanged(breadCrumbRoutes[index]);
      }}
      backClicked={onBackClick}
    />
  ) : null;
};

export default BreadCrumbHandler;
