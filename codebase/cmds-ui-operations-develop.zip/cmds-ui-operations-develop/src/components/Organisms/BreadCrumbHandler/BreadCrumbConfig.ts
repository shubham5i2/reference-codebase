import { languageService } from '../../../services/Language/LanguageService';
import { BreadCrumbRoute } from './BreadCrumbHandler';
import locationBreadcrumbconfig from '../../../constants/LocationManagement/BreadCrumbConfig';
import productBreadcrumbconfig from '../../../constants/ProductManagement/BreadCrumbConfig';

const resultLabels = languageService().result;
const testTakerLabels = languageService().testTaker;
const organisationLabels = languageService().organisation;
const preReleaseLabels = languageService().preReleaseCheck;
const testTakerTRFLabels = languageService().testTakerTRF;
const marksUpdateLabels = languageService().marksUpdate;
const incidentManagementLabels = languageService().incidentManagement;
const commonLabels = languageService().common;
const aaLabels = languageService().accessArrangements;

// Add the route to this config to enable Breadcrumb for the route.
export const breadCrumbRouteConfig: BreadCrumbRoute[] = [
  // : Need to move other labels to language service
  { path: '/', breadCrumbLabel: 'Home' },
  { path: '/manageuser', breadCrumbLabel: 'Manage Users' },
  { path: '/manageuser/viewUserPage/:id', breadCrumbLabel: 'View Details' },
  { path: '/manageuser/adduser', breadCrumbLabel: 'Add New User' },
  { path: '/manageuser/updateuser/:id', breadCrumbLabel: 'Update' },
  { path: '/manageuser/viewUserPage/:id/updateuser/:id', breadCrumbLabel: 'Update' },
  { path: '/manageuser/assigngroup/:id', breadCrumbLabel: 'Assign User Group' },
  { path: '/manageuser/viewUserPage/:id/assigngroup/:id', breadCrumbLabel: 'Assign User Group' },
  { path: '/manageuser/viewUser/assigngroup/:id', breadCrumbLabel: 'Assign User Group' },
  { path: '/organisation', breadCrumbLabel: organisationLabels.organisationTitle },
  { path: '/organisation/duplicatesearch', breadCrumbLabel: organisationLabels.duplicateSearchLabel },
  { path: '/organisation/duplicatesearch/addnew', breadCrumbLabel: organisationLabels.addOrganisationLabel },
  { path: '/organisation/duplicatesearch/organisationDetails/:id', breadCrumbLabel: organisationLabels.detailsLabel },
  { path: '/organisation/duplicatesearch/update', breadCrumbLabel: organisationLabels.updateOrganisationHeader },
  { path: '/organisation/organisationDetails/:id', breadCrumbLabel: organisationLabels.detailsLabel },
  { path: '/organisation/update', breadCrumbLabel: organisationLabels.updateOrganisationHeader },
  { path: '/managetesttaker', breadCrumbLabel: testTakerLabels.manageTTBreadcrumbLabel },
  { path: '/results', breadCrumbLabel: resultLabels.resultTitle },
  { path: '/results/viewTestTakerDetails/:id', breadCrumbLabel: resultLabels.testTakerDetailsTitle },
  { path: '/managetesttaker/testtakerbookinghistory/:id', breadCrumbLabel: testTakerLabels.viewTTBHBreadcrumbLabel },
  {
    path: '/managetesttaker/testtakerbookinghistory/:id/testtakerbookingdetails/:id',
    breadCrumbLabel: testTakerLabels.viewTTDetailsBreadcrumbLabel,
  },
  { path: '/results/updateresultstatus/:id', breadCrumbLabel: resultLabels.resultsUpdateStatus },
  { path: '/results/updateresultsstatus', breadCrumbLabel: resultLabels.resultsUpdateStatus },
  {
    path: '/managetesttaker/testtakerbookinghistory/:id/associateuttid',
    breadCrumbLabel: testTakerLabels.associateUttIdLabel,
  },
  {
    path: '/manageprereleasecheck',
    breadCrumbLabel: preReleaseLabels.manageTestTakerPreReleaseTitle,
  },
  {
    path: '/results/downloadtrf/:bookingId',
    breadCrumbLabel: testTakerTRFLabels.BreadcrumbLabel,
  },
  {
    path: '/accessarrangements',
    breadCrumbLabel: commonLabels.accessArrangements,
  },
  {
    path: '/accessarrangements/viewAccessArrangementsDetails',
    breadCrumbLabel: commonLabels.viewDetails,
  },
  {
    path: '/accessarrangements/createAccessArrangement',
    breadCrumbLabel: aaLabels.createAccessArrangementTitle,
  },
  {
    path: '/incidentmanagement',
    breadCrumbLabel: incidentManagementLabels.incidentManagement,
  },
  {
    path: '/incidentmanagement/incidentmanagementviewdetails/:id',
    breadCrumbLabel: incidentManagementLabels.incidentDetails,
  },
  {
    path: '/incidentmanagement/incidentmanagementviewdetails/incidentmanagementidverification/:id',
    breadCrumbLabel: incidentManagementLabels.idVerification,
  },
  {
    path: '/results/updatemarks',
    breadCrumbLabel: marksUpdateLabels.BreadcrumbLabel,
  },
  ...locationBreadcrumbconfig,
  ...productBreadcrumbconfig,
];
