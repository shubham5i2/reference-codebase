import React, { useState, useEffect } from 'react';
import UI from 'ielts-cmds-ui-component-library';
import classnames from 'classnames';
import ChevronDownIcon from '../../../assets/images/Chevron_Down.svg';
import ChevronUpIcon from '../../../assets/images/Chevron_Up.svg';
import { languageService } from '../../../services/Language/LanguageService';
import ProductDropDown from '../BaseDropDown/ProductDropDown/ProductDropDown';
import styles from './ResultsSearchPanel.module.scss';
import { AdvancedResultSearchCriteria, BasicResultSearchCriteria } from '../../../services/Models/Result';
import { dateRange } from '../../Pages/Results/ResultsSearchPanel/ResultsSearchPanel';
import { ServiceRequest } from '../../../services/utils/ServiceRequest';
import * as ManageResultActions from '../../../Store/Actions/ManageResultActions';
import { getOptionsListWithId } from '../../utils/utilities';
import { DropDownType } from '../../../services/Models/UIModels';
import { LocationType } from '../../../services/Models/LocationManagement';
import LocationDropdown from '../LocationDropdown/LocationDropdown';

export interface IResultsSearchPanel {
  advanceSearchButtonColor: string;
  advanceSearchButtonLabel: string;
  advancedSearchData: AdvancedResultSearchCriteria;
  basicSearchButtonColor: string;
  basicSearchButtonLabel: string;
  basicSearchData: BasicResultSearchCriteria;
  children?: React.ReactNode | React.ReactNode[];
  collapseTitle: string;
  collapseOpenTitle: string;
  collapseFooterTitle: string;
  clearSearchLabel: string;
  fetchProductDataOnLoad?: boolean;
  fetchLocationDataOnLoad?: boolean;
  handleBasicInputChange: (key: string, value: string | dateRange) => void;
  handleAdvancedInputChange: (key: string, value: string) => void;
  initialOpenState: boolean;
  onBasicSearchHandler: () => void;
  onAdvancedSearchHandler: () => void;
  onClearSearch: (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>) => void;
  titleType: string;
  subTitleType: string;
  title: string;
  titleSize: number;
  serviceRequest: ServiceRequest;
  subTitle: string;
  subTitleSize: number;
}

interface ISelection {
  selection: dateRange;
}

const ResultsSearchPanel = (props: IResultsSearchPanel) => {
  const [advancedSearchOpen, setAdvancedSearchOpen] = useState(false);
  const [showCal, setVisibility] = useState(false);

  const onChangeHandler = (
    event: React.FormEvent<HTMLInputElement> | React.MouseEvent<HTMLAnchorElement, MouseEvent>,
  ) => {
    event.preventDefault();
    setAdvancedSearchOpen(!advancedSearchOpen);
  };

  const onTestCentreChange = (value: string) => {
    props.handleBasicInputChange('testCentre', value);
  };

  const onProductChange = (value: string) => {
    props.handleBasicInputChange('product', value);
  };

  const onDateChange = (startDate: Date, endDate: Date) => {
    props.handleBasicInputChange('dateRange', { startDate, endDate });
    setVisibility(false);
  };

  useEffect(() => {
    setAdvancedSearchOpen(props.initialOpenState);
  }, [props.initialOpenState]);

  const resultLabels = languageService().result;

  const clearSearchLabel = (
    <div className={styles.pushLeft}>
      <a href="#clearBasic" onClick={props.onClearSearch} className={styles.clearSearch} id="clearSearch">
        <span>{props.clearSearchLabel}</span>
      </a>
    </div>
  );

  return (
    <div className={styles.searchPanel}>
      <div className={styles.searchPanelTitle}>
        <UI.Typography type={props.titleType} label={props.title} size={props.titleSize} id="title" />
      </div>
      <div className={styles.searchPanelSubTitle}>
        <UI.Typography type={props.subTitleType} label={props.subTitle} size={props.subTitleSize} id="subTitle" />
        <span className={classnames(styles.floatRight, styles.mandatoryCriteria)}>
          {resultLabels.mandatoryCriteria}
        </span>
      </div>
      <div className={styles.row}>
        <div
          style={{ position: 'relative', minWidth: 300, height: 90, marginRight: '15px' }}
          className={styles.datePicker}
        >
          <div className={styles.textBoxLabel}>{resultLabels.dateRangeLabel}*</div>
          <UI.DateRangePicker
            onChange={({ selection: { startDate, endDate } }: ISelection) => onDateChange(startDate, endDate)}
            months={2}
            ranges={[
              {
                startDate: props.basicSearchData?.dateRange?.startDate,
                endDate: props.basicSearchData?.dateRange?.endDate,
                key: 'selection',
              },
            ]}
            direction="horizontal"
            showPreview={true}
            setCalendarVisibility={() => {
              setVisibility(!showCal);
            }}
            showCalendar={showCal}
          />
        </div>
        <div className={[styles.flexElement, styles.testCentre].join(' ')}>
          <div className={styles.textBoxLabel}>{resultLabels.testCentreLabel}</div>
          <div className={styles.dropDownContainer}>
            <LocationDropdown
              id={'testCentre'}
              dropdownConfig={{ isFilterEnabled: true }}
              labelText={''}
              locationType={LocationType.TEST_CENTRE}
              dataSource={'getLocations'}
              value={props.basicSearchData?.testCentre}
              onChange={onTestCentreChange}
              getOptionsList={getOptionsListWithId}
              dropDownType={DropDownType.MULTIPLE}
            />
          </div>
        </div>
        <div className={styles.flexElement}>
          <div className={styles.textBoxLabel}>{resultLabels.productLabel}</div>
          <div className={styles.dropDownContainer}>
            <ProductDropDown
              id="product"
              actionType={ManageResultActions.SAVE_PRODUCTS}
              isFetchDataOnLoad={props.fetchProductDataOnLoad || false}
              isFilterEnabled={true}
              label=""
              labelId="productLB"
              onChange={onProductChange}
              selectedValue={props.basicSearchData?.product}
              dropDownType={DropDownType.MULTIPLE}
              serviceRequest={props.serviceRequest}
            />
          </div>
        </div>
      </div>
      <div>
        <div className={[styles.row, styles.rowMarginTop10].join(' ')}>
          <div className={styles.alignSelfCenter}>
            <a
              href="#collapse"
              onClick={(event) => {
                onChangeHandler(event);
              }}
              className={advancedSearchOpen ? styles.hidden : styles.collapseIcon}
              id="collapseTitle"
            >
              <UI.Icon icon={ChevronDownIcon} />
              <span className={styles.collapseTitle}>{props.collapseTitle}</span>
            </a>
          </div>
          {advancedSearchOpen ? null : clearSearchLabel}
          <div className={advancedSearchOpen ? styles.hidden : ''}>
            <UI.Button
              label={props.basicSearchButtonLabel}
              onChange={props.onBasicSearchHandler}
              color={props.basicSearchButtonColor}
              id="basicSearchButton"
            />
          </div>
        </div>

        <div
          className={advancedSearchOpen ? styles.panelCollapse : [styles.panelCollapse, styles.panelClose].join(' ')}
        >
          {props.children}
          <div>
            <div className={styles.row}>
              <div className={styles.alignSelfCenter}>
                <a
                  href="#collapse"
                  onClick={(event) => {
                    onChangeHandler(event);
                  }}
                  className={styles.collapseIcon}
                  id="collapseFooterTitle"
                >
                  <UI.Icon icon={ChevronUpIcon} />
                  <span className={styles.collapseFooterTitle}>{props.collapseFooterTitle}</span>
                </a>
              </div>
              {!advancedSearchOpen ? null : clearSearchLabel}
              <div>
                <UI.Button
                  label={props.advanceSearchButtonLabel}
                  onChange={props.onAdvancedSearchHandler}
                  color={props.advanceSearchButtonColor}
                  id="advancedSearchButton"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default ResultsSearchPanel;
