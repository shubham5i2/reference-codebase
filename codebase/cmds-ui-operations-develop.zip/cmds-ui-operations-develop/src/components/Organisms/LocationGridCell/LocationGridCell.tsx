import React from 'react';
import UI from 'ielts-cmds-ui-component-library';

import styles from './LocationGridCell.module.scss';
import { LocationGridCellType } from '../../../services/Models/LocationManagement';
import { getValue, statusStyle, toCapitalise } from '../../utils/utilities';

export interface GridCellProps {
  id?: string;
  cellType: string;
  value?: string;
  onChangeHandler?: () => void;
  icon?: string;
}

const LocationsGridCell = (props: GridCellProps) => {
  const { value } = props;
  switch (props.cellType) {
    case LocationGridCellType.TESTCENTRE_NUMBER:
    case LocationGridCellType.PARTNER_CODE:
    case LocationGridCellType.LOCATION_NAME:
    case LocationGridCellType.COUNTRY:
    case LocationGridCellType.CITY:
      return (
        <label id={props.id} className={`${styles.label}`}>
          {value}
        </label>
      );
    case LocationGridCellType.LOCATION_STATUS:
      return (
        <UI.Status
          status={statusStyle[getValue(value)]}
          label={toCapitalise(getValue(value))}
          typographyProps={{
            size: 14,
          }}
          theme="none"
        />
      );
    case LocationGridCellType.MORE:
      return (
        <button id="moreButton" className={styles.more} onClick={props.onChangeHandler}>
          <img alt="" src={props.icon} />
        </button>
      );

    default:
      return null;
  }
};

export default LocationsGridCell;
