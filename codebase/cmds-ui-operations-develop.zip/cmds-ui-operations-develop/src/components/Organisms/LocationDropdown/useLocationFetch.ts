import { AsyncResponseStatus } from '../../../services/Models/Api';
import {
  LocationType,
  LocationRequest,
  LocationServiceRequest,
  LocationAPIMap,
  LocationResponse,
  getLocationKey,
} from './LocationDropdownUtils';
import { getLocations } from '../../../services/API/ManageUser/Locations';
import { searchLocation } from '../../../services/API/LocationManagement/SearchLocation';
import { DATA_LOADED, DATA_LOADING, DATA_LOAD_ERROR } from '../../../Store/Actions/LocationActions';
import { AsyncPreloaderServiceSubject } from '../../../services/Preloader/usePreloader';
import { useStateValue } from '../../../Store/helpers/UseStateValue';

const getLocationAPIMap = (dataSource: string): LocationAPIMap => {
  const serviceFunc =
    dataSource === 'searchLocations' ? searchLocation : dataSource === 'getLocations' ? getLocations : null;
  return {
    [LocationType.PARTNER]: serviceFunc,
    [LocationType.NONE]: serviceFunc,
    [LocationType.TEST_CENTRE]: serviceFunc,
    [LocationType.PHYSICAL_BUILDING]: serviceFunc,
    [LocationType.COUNTRY]: serviceFunc,
    [LocationType.REGION]: serviceFunc,
    [LocationType.GLOBAL]: serviceFunc,
    [LocationType.LOCATION_AND_BELOW]: getLocations,
  };
};

const getSearchLocationRequestBody = (
  locationTypeCode: LocationType,
  partnerCode: string,
  testCentreNumber: string,
) => {
  return {
    testCentreNumber,
    partnerCode,
    locationTypeCode,
  };
};

const handleApiResponse = (
  data: LocationResponse,
  dispatch: React.Dispatch<any>,
  payload: { locationType: string },
  subject: AsyncPreloaderServiceSubject,
) => {
  subject && subject.next({ type: 'LOCATIONS', status: data.status });

  if (data.status === AsyncResponseStatus.SUCCESS) {
    dispatch({
      type: DATA_LOADED,
      payload: { ...payload, response: data.response, transformedData: data.transformedData },
    });
  } else {
    dispatch({
      type: DATA_LOAD_ERROR,
      payload: payload,
    });
  }
};

export const useLocationFetch = () => {
  const { dispatch } = useStateValue();

  const locationService = (request: LocationRequest, { serviceRequest, subject }: LocationServiceRequest) => {
    const { userId, partnerCode, locationType, assignableToGroups, testCentreNumber, dataSource } = request;

    const locationAPI = getLocationAPIMap(dataSource);

    const payload = {
      locationType: getLocationKey(locationType, partnerCode, dataSource),
    };

    if (request.dataSource === 'getLocations' && locationAPI[request.locationType]) {
      dispatch({
        type: DATA_LOADING,
        payload: payload,
      });
      locationAPI[request.locationType](
        userId,
        partnerCode,
        locationType,
        assignableToGroups,
        serviceRequest,
      ).subscribe((data: LocationResponse) => {
        handleApiResponse(data, dispatch, payload, subject);
      });
    } else if (dataSource === 'searchLocations' && locationAPI[locationType]) {
      dispatch({
        type: DATA_LOADING,
        payload: payload,
      });
      const request = getSearchLocationRequestBody(locationType, partnerCode, testCentreNumber || '');
      locationAPI[locationType](request, serviceRequest).subscribe((data: LocationResponse) => {
        handleApiResponse(data, dispatch, payload, subject);
      });
    } else {
      console.warn('Invalid location type or datasource');
    }
  };

  return { locationService };
};
