import React, { useEffect } from 'react';
import UI from 'ielts-cmds-ui-component-library';
import withServiceRequest from '../../../services/utils/ServiceRequest';
import { useStateValue } from '../../../Store/helpers/UseStateValue';
import { getLocationKey, LocationDropdownProps, LocationType, LocationCache } from './LocationDropdownUtils';
import { useAuth0 } from '@auth0/auth0-react';
import { DataState, Dictionary, DropDownType } from '../../../services/Models/UIModels';
import { getValue, getPartner, sortValues, useEffectUpdate } from '../../utils/utilities';
import { useLocationFetch } from './useLocationFetch';

const LocationDropdown = (props: LocationDropdownProps) => {
  const {
    id,
    dropdownConfig,
    value,
    onChange,
    text,
    ignoreCache,
    serviceRequest,
    labelText,
    partnerCode,
    assignableToGroups,
    locationType,
    dataSource,
    testCentreNumber,
    dropDownType = DropDownType.SINGLE,
    getOptionsList,
    shouldPreSelectOnlyLocation,
    checkCacheOnLoad,
  } = props;

  const { isMandatory, placeholderText, disabled, inputFieldValidationError, customMapper, isFilterEnabled } =
    dropdownConfig || {};

  const { state } = useStateValue();
  const { user } = useAuth0();
  const { locationService } = useLocationFetch();
  const userId = getValue(user?.sub).split(/\|/)[1] || '';

  const partner = partnerCode || getPartner(user);
  const locationKey = getLocationKey(locationType, partner, dataSource);
  const locationData: LocationCache = state.locationData?.[locationKey] || {};

  const request = {
    userId,
    partnerCode: partner,
    locationType,
    assignableToGroups: assignableToGroups || false,
    dataSource,
    testCentreNumber: testCentreNumber || '',
  };

  useEffect(() => {
    checkCacheOnLoad && fetchData(ignoreCache);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffectUpdate(() => {
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [locationType, partnerCode]);

  const fetchData = (ignoreCacheOnLoad = false) => {
    const currentTime = +new Date();
    const lastRefreshTime = +locationData.lastRefreshTime;
    const diff = (currentTime - lastRefreshTime) / 1000;
    let refreshTime = +getRefreshTime();
    if (locationType === LocationType.NONE) {
      return;
    }
    refreshTime = refreshTime * 60;
    if (
      (!locationData.transformedData?.length && locationData.dataState !== DataState.LOADING) ||
      ignoreCacheOnLoad ||
      ((LocationType.COUNTRY === locationType || LocationType.TEST_CENTRE === locationType) && diff >= refreshTime)
    ) {
      // CALL API
      locationService(request, {
        serviceRequest,
      });
    }
  };

  const getRefreshTime = () => {
    if (LocationType.TEST_CENTRE === locationType) {
      return process.env.REACT_APP_TEST_CENTRE_LOCATION_REFRESH_TIME || 5;
    } else if (LocationType.COUNTRY === locationType) {
      return process.env.REACT_APP_COUNTRY_LOCATION_REFRESH_TIME || 60;
    }
    return 0;
  };

  const getDropdownList = () =>
    (locationData?.transformedData || []).map((location: Dictionary) => {
      const { text, value } = customMapper || {};
      return {
        text: text ? location[text] : location.text,
        value: value ? location[value] : location.value,
        locationCode: location.locationCode,
      };
    });

  const getSelectedValue = () => {
    if (shouldPreSelectOnlyLocation && !value && getDropdownList().length === 1) {
      onChange(getDropdownList()[0]);
      return getDropdownList()[0].value;
    }
    return value;
  };

  const handleDropDownOpen = () => {
    fetchData();
  };

  return dropDownType === DropDownType.SINGLE ? (
    <UI.Dropdown
      id={id}
      label={labelText}
      mandatory={isMandatory || false}
      labelId={`${id}_label`}
      disable={disabled || false}
      placeholder={placeholderText}
      inputFieldValidation={inputFieldValidationError?.location}
      selectedValue={getSelectedValue()}
      list={sortValues(getOptionsList ? getOptionsList(locationData?.transformedData || []) : getDropdownList())}
      onChange={(value: string, text: string) => onChange({ value, text })}
      showInputWithoutList
      selectedText={text || ''}
      isFilterEnabled={true}
      isLoading={locationData?.dataState === DataState.LOADING}
      onDropDownOpen={handleDropDownOpen}
      isMultiline={true}
    />
  ) : (
    // Smaple Implementation of location dropdown
    //   <LocationDropdown
    //   id="testCentree"
    //   selectedLocationValue={props.basicSearchData?.testCentre}
    //   locationType={LocationType.TEST_CENTRE}
    //   onChange={onTestCentreChange}
    //   serviceRequest={props.serviceRequest}
    //   dataSource={'getLocations'}
    //   assignableToGroups={false}
    //   // text={'locationUuid'}
    //   // value={'locationCode'}
    // />
    // <div className={styles.textBoxLabel}>Parent Location</div>
    // <LocationDropdown
    //   id="testCentree"
    //   selectedLocationValue={props.basicSearchData?.testCentre}
    //   locationType={LocationType.TEST_CENTRE}
    //   partnerCode={'BC'}
    //   onChange={onTestCentreChange}
    //   serviceRequest={props.serviceRequest}
    //   dataSource={'searchLocations'}
    //   assignableToGroups={false}
    //   text={'testCentreNumber'}
    //   value={'locationUuid'}
    // />
    <UI.MultiSelectDropDown
      id={id}
      labelId={`${id}_label`}
      label={labelText}
      onChange={onChange}
      value={value}
      placeholder={placeholderText}
      list={sortValues(getOptionsList ? getOptionsList(locationData?.transformedData || []) : getDropdownList())}
      inputFieldValidation={inputFieldValidationError}
      showInputWithoutList
      mandatory={isMandatory}
      isLoading={locationData?.dataState === DataState.LOADING}
      isFilterEnabled={isFilterEnabled}
    />
  );
};

export default withServiceRequest(LocationDropdown);
