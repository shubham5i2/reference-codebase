import { AsyncResponseStatus } from '../../../services/Models/Api';
import { LocationSearchResultEntry } from '../../../services/Models/LocationManagement';
import { DropdownCache, DropDownDataSource, UserFormError, DropDownType } from '../../../services/Models/UIModels';
import { AsyncPreloaderServiceSubject } from '../../../services/Preloader/usePreloader';
import { ServiceRequest } from '../../../services/utils/ServiceRequest';

export enum LocationType {
  PARTNER = 'PARTNER',
  TEST_CENTRE = 'TEST_CENTRE',
  PHYSICAL_BUILDING = 'PHYSICAL_BUILDING',
  NONE = 'NONE',
  COUNTRY = 'COUNTRY',
  GLOBAL = 'GLOBAL',
  REGION = 'REGION',
  LOCATION_AND_BELOW = '',
}

export interface LocationCache extends DropdownCache {
  locationType?: string;
  lastRefreshTime: any;
}

export type LocationAPIMap = {
  [key in string]: any;
};

export interface LocationRequest {
  userId: string;
  partnerCode: string;
  locationType: LocationType;
  assignableToGroups: boolean;
  testCentreNumber?: string;
  dataSource: string;
}

export interface LocationResponse {
  status: AsyncResponseStatus;
  response: Location | LocationSearchResultEntry;
  transformedData: Location | LocationSearchResultEntry;
  text: string;
  value: string;
}

export interface LocationServiceRequest {
  serviceRequest: ServiceRequest;
  subject?: AsyncPreloaderServiceSubject;
}

export interface LocationDropdownProps {
  id: string;
  dropdownConfig?: {
    placeholderText?: string;
    isFilterEnabled?: boolean;
    isMandatory?: boolean;
    disabled?: boolean;
    inputFieldValidationError?: UserFormError;
    customMapper?: { text?: string; value?: string };
  };
  labelText?: string;
  locationType: LocationType;
  dataSource: string;
  value: string;
  text?: string;
  ignoreCache?: boolean;
  refreshRate?: number;
  selectedLocationValue: string;
  partnerCode?: string;
  testCentreNumber?: string;
  locationTypeCode?: string;
  assignableToGroups?: boolean;
  shouldPreSelectOnlyLocation?: boolean;
  checkCacheOnLoad?: boolean;
  serviceRequest: ServiceRequest;
  onChange: (event: DropDownDataSource) => void;
  dropDownType?: DropDownType;
  getOptionsList?: (locationOptions: DropDownDataSource[]) => DropDownDataSource[];
}

export const getLocationKey = (locationType: LocationType, partner: string, dataSource?: string) => {
  const actualPartner = !partner ? 'GLOBAL_IELTS' : partner;
  const locationTypeKey = dataSource
    ? `${locationType}_${actualPartner}_${dataSource}`
    : `${locationType}_${actualPartner}`;
  return locationTypeKey;
};
