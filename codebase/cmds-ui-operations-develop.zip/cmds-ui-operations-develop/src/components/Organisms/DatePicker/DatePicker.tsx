import React, { useState, useEffect } from 'react';
import UI from 'ielts-cmds-ui-component-library';
import styles from './DatePicker.module.scss';

const DatePicker = (props: any) => {
  const { onChange, ranges } = props;
  const [dateRange, setdateRange] = useState({
    startDate: ranges.startDate,
    endDate: ranges.endDate,
    key: 'selection',
  });

  useEffect(() => {
    setdateRange({ ...dateRange, ...ranges });
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ranges]);

  const [showCal, setVisibility] = useState(false);

  const handleChange = (range: any) => {
    const event = {
      target: {
        name: range.name,
        value: range,
      },
    };

    onChange(event);
  };

  return (
    <div>
      <div className={styles.dp_title}>Duration</div>
      <UI.DateRangePicker
        onChange={(item: { selection: { startDate: any; endDate: any; key: string } }) => handleChange(item.selection)}
        showSelectionPreview={false}
        months={2}
        ranges={[dateRange]}
        direction="horizontal"
        showPreview={false}
        setCalendarVisibility={() => {
          setVisibility(!showCal);
        }}
        showCalendar={showCal}
        id={props.id}
        classname={styles.rangePicker}
      />
    </div>
  );
};

export default DatePicker;
