import React, { useEffect, useState } from 'react';
import UI from 'ielts-cmds-ui-component-library';
import styles from './AccessArrangementsCreatePanel.module.scss';
import { languageService } from '../../../../services/Language/LanguageService';
import { UIButtonType, UICheckboxChangeEvent } from '../../../../services/Models/UIModels';
import {
  AAComponentTypes,
  aaComponentTypes,
  ArrangementDetails,
  TestTaker,
} from '../../../Pages/AccessArrangements/AccessArrangementUtils';
import { saveAA } from '../../../../services/API/AccessArrangements/SaveAA';
import { approveAA } from '../../../../services/API/AccessArrangements/ApproveAA';
import { AsyncResponseStatus } from '../../../../services/Models/Api';
import withServiceRequest, { ServiceRequest } from '../../../../services/utils/ServiceRequest';
import FooterButtons from '../../../Molecules/FooterButtons/FooterButtons';
import ToastMessage, { Mode, Position } from '../../ToastMessage/ToastMessage';
import { DEFAULT_TOAST_MESSAGE_TIMER } from '../../../../constants/GlobalConstants';
import { RouteComponentProps, useHistory } from 'react-router-dom';
import * as BreadCrumbActions from '../../../../Store/Actions/BreadCrumbActions';
import { useStateValue } from '../../../../Store/helpers/UseStateValue';
import GenericPopup, { ButtonPosition, DialogType, TitlePosition } from '../../GenericPopup/GenericPopup';
import CommonLabels from '../../../../services/Language/en/en.common';

interface AccessArrangementsSaveProps extends RouteComponentProps {
  serviceRequest: ServiceRequest;
}

interface AASaveRequest {
  arrangementDetails: ArrangementDetails[];
  testTaker: TestTaker;
  expiryDate: string;
  externalCaseNumberId: string;
}

interface AAAproveRequest extends AASaveRequest {
  accessArrangementCaseUuid: string;
  externalCaseNumberUuid?: string;
  status?: AsyncResponseStatus;
}

interface AAInputRequest {
  firstName: string;
  lastName: string;
  externalCaseNumberId: string;
  expiryDate: string;
}

const aaLabels = languageService().accessArrangements;

const AccessArrangementsCreatePanel = (props: AccessArrangementsSaveProps) => {
  const [arrangementDetails, setArrangementDetails] = useState<ArrangementDetails[]>([]);
  const [showToastError, setShowToastErrorMessage] = useState(false);
  const [showToastSuccess, setShowToastSuccessMessage] = useState(false);
  const [showConfirmationDialog, setShowConfirmationDialog] = useState(false);
  const [errorMessage, setErrorMessage] = useState(aaLabels.saveAAValidationToastErrorMsg);
  const history = useHistory();
  const { dispatch } = useStateValue();
  const [componentTypes, setComponentTypes] = useState<AAComponentTypes[]>(aaComponentTypes);
  const [state, setState] = useState<AAInputRequest>({
    firstName: '',
    lastName: '',
    externalCaseNumberId: '',
    expiryDate: '',
  });
  const buttonData = [
    {
      id: 'confirm',
      text: CommonLabels.confirm,
      type: UIButtonType.PRIMARY,
      onChange: () => handleConfirm(),
    },
    {
      id: 'cancel',
      text: CommonLabels.cancelButtonTitle,
      type: UIButtonType.SECONDARY,
      onChange: () => setShowConfirmationDialog(false),
    },
  ];

  useEffect(() => {
    dispatch({ type: BreadCrumbActions.SHOW_BACK, payload: true });
    return () => {
      resetForm();
    };
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const resetForm = () => {
    setArrangementDetails([]);
    state.firstName = state.lastName = state.externalCaseNumberId = '';
    setState({ ...state });
    setComponentTypes((prevState) => {
      prevState.forEach((ct: AAComponentTypes) => {
        ct.componentDetails.forEach((component: ArrangementDetails) => {
          component.isChecked = false;
        });
      });
      return prevState;
    });
  };

  const handleConfirm = () => {
    const { firstName, lastName, ...caseDetails } = state;
    const saveRequest: AASaveRequest = {
      arrangementDetails,
      testTaker: {
        firstName: firstName,
        lastName: lastName,
      },
      ...caseDetails,
    };

    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const getApproveRequest = (response: AAAproveRequest) => {
      return {
        accessArrangementCaseUuid: response.accessArrangementCaseUuid,
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        arrangementDetails: response.arrangementDetails.map(({ note, ...ad }) => ad),
        testTaker: {
          firstName: response.testTaker.firstName,
          lastName: response.testTaker.lastName,
        },
        expiryDate: response.expiryDate,
        externalCaseNumberId: response.externalCaseNumberId,
        externalCaseNumberUuid: response.externalCaseNumberUuid,
      };
    };
    saveAA(saveRequest, props.serviceRequest).subscribe((response: AAAproveRequest) => {
      const approveRequest: AAAproveRequest = getApproveRequest(response);
      if (response.status === AsyncResponseStatus.SUCCESS) {
        approveAA(approveRequest, props.serviceRequest).subscribe((response) => {
          if (response.status === AsyncResponseStatus.SUCCESS) {
            setShowToastSuccessMessage(true);
            resetForm();
            setTimeout(() => {
              history.push(`/accessarrangements`);
            }, 3000);
          }
        });
      }
    });
    setShowConfirmationDialog(false);
  };

  const handleCancel = () => {
    history.goBack();
    resetForm();
  };

  const handleSave = () => {
    if ((!state.firstName && !state.lastName) || !state.externalCaseNumberId || !state.expiryDate) {
      setErrorMessage(aaLabels.saveAAValidationToastErrorMsg);
      setShowToastErrorMessage(true);
      return;
    }
    if (arrangementDetails.length === 0) {
      setErrorMessage(aaLabels.saveAATypeValidationErrorMsg);
      setShowToastErrorMessage(true);
      return;
    }
    setShowConfirmationDialog(true);
  };

  const getSuccessMessage = () => {
    return showToastSuccess ? (
      <ToastMessage
        id="toast_panel_success"
        color={Mode.SUCCESS}
        position={Position.DEFAULT}
        dismissable={true}
        onChange={() => {
          setShowToastSuccessMessage(false);
        }}
        duration={DEFAULT_TOAST_MESSAGE_TIMER}
        message={aaLabels.saveAAToastSuccessMsg}
      ></ToastMessage>
    ) : null;
  };

  const getErrorMessage = () => {
    return showToastError ? (
      <ToastMessage
        id="toast_panel_error"
        color={Mode.ERROR}
        position={Position.DEFAULT}
        dismissable={true}
        onChange={() => {
          setShowToastErrorMessage(false);
        }}
        duration={DEFAULT_TOAST_MESSAGE_TIMER}
        message={errorMessage}
      ></ToastMessage>
    ) : null;
  };

  const handleInputChange = (e: React.FormEvent<HTMLInputElement>) => {
    const target = e.target as HTMLInputElement;
    const { value, name } = target;
    setState({
      ...state,
      [name]: value,
    });
  };

  const handleDateChange = (expiryDate: Date) => {
    state.expiryDate = expiryDate.toLocaleString('en-CA').split(',')[0];
    setState({ ...state });
  };

  const modalCloseHandler = () => {
    setShowConfirmationDialog(false);
  };

  const onComponentChange = (isChecked: boolean, parentIndex: number, childIndex: number) => {
    setComponentTypes((prevState) => {
      const requestedComponent = prevState[parentIndex].componentDetails[childIndex];
      prevState[parentIndex].componentDetails[childIndex].isChecked = false;
      updateRequestedComponent(requestedComponent, isChecked);
      return prevState;
    });
  };

  const updateRequestedComponent = (component: ArrangementDetails, isChecked: boolean) => {
    setArrangementDetails((prevState) => {
      if (isChecked) {
        prevState.push({ component: component.component, arrangementTypeUuid: component.arrangementTypeUuid });
      } else {
        deSelectComponentType(component);
      }
      return prevState;
    });
  };

  const deSelectComponentType = (component: ArrangementDetails) => {
    const arrangementsToRemove = arrangementDetails.filter(
      (arrangementDetail: ArrangementDetails) =>
        arrangementDetail.component === component.component &&
        arrangementDetail.arrangementTypeUuid === component.arrangementTypeUuid,
    );
    arrangementsToRemove.forEach((atr) =>
      arrangementDetails.splice(
        arrangementDetails.findIndex((ad) => ad === atr),
        1,
      ),
    );
  };

  return (
    <div className={styles.aaCreateContainer}>
      {getSuccessMessage()}
      {getErrorMessage()}
      {showConfirmationDialog && (
        <div>
          <GenericPopup
            id="aaConfirmDialog"
            title={aaLabels.accesArrangementsTitle}
            className={styles.customStyle}
            titlePosition={TitlePosition.DEFAULT}
            buttonStyle={ButtonPosition.RIGHT}
            dialogType={DialogType.CUSTOM}
            buttonData={buttonData}
            modalCloseHandler={modalCloseHandler}
          >
            <div className={styles.modalContent}>
              <p>Are you sure you want to create new access arrangement case?</p>
            </div>
          </GenericPopup>
        </div>
      )}
      <div className={styles.aaCreatePanelInfo}>
        <div className={styles.aaCreateHeader}>
          <h1 className={styles.createAATitle}>{aaLabels.createAccessArrangementTitle}</h1>
        </div>
        <div className={styles.aaFormContainer}>
          <div className={styles.col3}>
            <div>{aaLabels.giveName}*</div>
            <UI.TextBox value={state.firstName} name={'firstName'} id={'firstName'} onChange={handleInputChange} />
          </div>
          <div className={styles.col3}>
            <div>{aaLabels.familyName}*</div>
            <UI.TextBox value={state.lastName} name={'lastName'} id={'lastName'} onChange={handleInputChange} />
          </div>
          <div className={styles.col3}>
            <div>{aaLabels.caseNumber}*</div>
            <UI.TextBox
              value={state.externalCaseNumberId}
              name={'externalCaseNumberId'}
              id={'externalCaseNumberId'}
              onChange={handleInputChange}
            />
          </div>
          <div className={styles.col1}>
            <div className={styles.mb2}>{aaLabels.expiryDate}*</div>
            <UI.DatePicker
              class={styles.expiryDateInput}
              id="expiryDate"
              minDate="1900-01-01"
              maxDate="2100-12-31"
              name="expiryDate"
              value={state.expiryDate}
              resetDate={state.expiryDate === ''}
              customYearDropDownClass={styles.customYearDropDownPosition}
              onChange={handleDateChange}
            />
            {state.expiryDate === '' && <span className={styles.expiryDatePlaceholder}>Select</span>}
          </div>
        </div>
        <div>
          <div className={styles.componentName}>
            {componentTypes.map((component: AAComponentTypes, i: number) => (
              <div key={i} className={styles.componentFormContainer}>
                <h3 className={styles.componentType}>{component.name.toString().toUpperCase()}</h3>
                {component.componentDetails.map((comp: ArrangementDetails, index: number) => (
                  <div className={styles.componentDetails} key={i + index}>
                    <div className={styles.componentCheckbox}>
                      <UI.CheckBox
                        checked={comp.isChecked}
                        label={comp.accessArrangementName}
                        labelId={comp.arrangementTypeUuid}
                        id={`${component.name}_${comp.accessArrangementName}`}
                        onChange={(e: UICheckboxChangeEvent) => onComponentChange(e.checked, i, index)}
                      />
                    </div>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
        <div className={styles.footerButtonWrapper}>
          <FooterButtons
            addOrUpdateButtonText={aaLabels.saveButtonTitle}
            onCancel={handleCancel}
            onSubmit={handleSave}
          ></FooterButtons>
        </div>
      </div>
    </div>
  );
};

export default withServiceRequest(AccessArrangementsCreatePanel);
