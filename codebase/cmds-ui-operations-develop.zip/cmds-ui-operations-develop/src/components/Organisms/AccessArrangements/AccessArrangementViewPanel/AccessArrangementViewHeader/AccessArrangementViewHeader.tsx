import React from 'react';
import { languageService } from '../../../../../services/Language/LanguageService';
import { formatDateAsGB } from '../../../../utils/utilities';
import styles from './AccessArrangementViewHeader.module.scss';

const aaLabels = languageService().accessArrangements;

type gridData = {
  testTaker: {
    firstName: string;
    lastName: string;
  };
  externalCaseNumberId: string;
  expiryDate: string;
};

interface AccessArranagemetViewProps {
  aaGridData: gridData;
}

export const AccessArranagemetViewHeader = (props: AccessArranagemetViewProps) => {
  const { firstName, lastName } = props.aaGridData.testTaker;
  const { externalCaseNumberId, expiryDate } = props.aaGridData;
  return (
    <div className={styles.viewHeaderContainer}>
      <h1 className={styles.viewAAHeaderTitle}>{aaLabels.viewAccessArrangementTitle}</h1>
      <div className={styles.viewHeaderInfo}>
        <table className={styles.aaViewTable}>
          <thead>
            <tr>
              <th>Given Name</th>
              <th>Family Name</th>
              <th>Case Number</th>
              <th>Expiry Date</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>{firstName}</td>
              <td>{lastName}</td>
              <td>{externalCaseNumberId}</td>
              <td>{formatDateAsGB(expiryDate)}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};
