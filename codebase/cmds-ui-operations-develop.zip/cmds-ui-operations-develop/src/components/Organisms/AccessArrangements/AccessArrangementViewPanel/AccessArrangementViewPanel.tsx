import React, { useEffect, useState } from 'react';
import styles from './AccessArrangementViewPanel.module.scss';
import { AccessArranagemetViewHeader } from './AccessArrangementViewHeader/AccessArrangementViewHeader';
import { useStateValue } from '../../../../Store/helpers/UseStateValue';
import * as BreadCrumbActions from '../../../../Store/Actions/BreadCrumbActions';
import {
  aaComponentTypes,
  ArrangementDetails,
  AASearch,
  AAComponentTypes,
} from '../../../Pages/AccessArrangements/AccessArrangementUtils';
import * as AccessArrangementActions from '../../../../Store/Actions/AccessArrangementActions';

const AccessArranagemetViewPanel = (props: any) => {
  const { dispatch } = useStateValue();
  const { aaGridData }: { aaGridData: AASearch } = props.location.state;

  const [components, setComponents] = useState<string[]>([]);

  useEffect(() => {
    dispatch({
      type: AccessArrangementActions.AA_SEARCH,
      payload: {
        caseNumber: aaGridData.externalCaseNumberId,
      },
    });
    return () => {
      dispatch({
        type: AccessArrangementActions.AA_CLEAR_SEARCH,
        payload: {
          caseNumber: null,
        },
      });
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getUniqueArrangementTypeDetails = () => {
    let result: ArrangementDetails[] = aaGridData?.arrangementDetails.filter(
      (e: ArrangementDetails, index: number) =>
        aaGridData?.arrangementDetails.findIndex(
          (ad: ArrangementDetails) => ad.arrangementTypeUuid === e.arrangementTypeUuid && ad.component === e.component,
        ) === index,
    );
    result = populateAANameToAATypes(result);
    return result;
  };

  const populateAANameToAATypes = (result: ArrangementDetails[]) => {
    aaComponentTypes.forEach((componentType: AAComponentTypes) =>
      componentType.componentDetails.forEach((cd: ArrangementDetails) =>
        result.forEach((aaComponent: ArrangementDetails) => {
          if (aaComponent.component === cd.component && aaComponent.arrangementTypeUuid === cd.arrangementTypeUuid) {
            aaComponent.accessArrangementName = cd.accessArrangementName;
            aaComponent.name = componentType.name;
          }
        }),
      ),
    );
    return result;
  };

  useEffect(() => {
    dispatch({ type: BreadCrumbActions.SHOW_BACK, payload: true });
    const result: ArrangementDetails[] = getUniqueArrangementTypeDetails();
    setComponents(Array.from(new Set(result.map((res: ArrangementDetails) => res.name || ''))));
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className={styles.aaViewPanel}>
      <div className={styles.viewPanelContainer}>
        <AccessArranagemetViewHeader aaGridData={aaGridData} />
      </div>
      <div className={styles.componentDetailsContainer}>
        {components &&
          components.length > 0 &&
          components.map((component: string, i: number) => (
            <div key={i} className={styles.componentFormContainer}>
              <h4>{component}</h4>
              {getUniqueArrangementTypeDetails().map(
                (componentDetails: ArrangementDetails, index: number) =>
                  component === componentDetails.name && (
                    <div className={styles.componentDetails} key={i + index}>
                      <span>{componentDetails.accessArrangementName}</span>
                    </div>
                  ),
              )}
            </div>
          ))}
      </div>
    </div>
  );
};

export default AccessArranagemetViewPanel;
