import React, { useState } from 'react';
import UI from 'ielts-cmds-ui-component-library';

import { aaGridColumns } from './AccessArrangementsGridColumns';
import { DEFAULT_MORE_IDX } from '../../../../constants/AccessArrangements';
import NoResultsFound from '../../../Molecules/NoResultsFound/NoResultsFound';
import styles from './AccessArrangementsGrid.module.scss';
import { useHistory } from 'react-router-dom';

interface AccessArrangementsProps {
  // : Added type once the API is ready
  gridState: any;
  aaGridData: any;
}

export default (props: AccessArrangementsProps) => {
  const history = useHistory();
  const [currentMoreIdx, setCurrentMoreIdx] = useState(DEFAULT_MORE_IDX);
  const { aaGridData, gridState } = props;

  const onMoreClick = (idx: number) => setCurrentMoreIdx(idx);
  const onMoreActionClick = (idx: number) => {
    history.push(`/accessarrangements/viewAccessArrangementsDetails`, {
      aaGridData: aaGridData[idx],
    });
    setCurrentMoreIdx(DEFAULT_MORE_IDX);
  };
  return (
    <>
      {(aaGridData || []).length > 0 ? (
        <div className={styles.gridContainer}>
          <UI.Grid
            id="accessArrangementsGrid"
            columns={aaGridColumns({
              onMoreClick,
              onMoreActionClick,
              selectedIdx: currentMoreIdx,
            })}
            hidePagination={true}
            data={aaGridData}
            initialState={gridState.initialState}
            totalRecords={gridState.totalRecords}
            currentPage={gridState.selectedPage}
            selectedOptionValue={gridState.selectedOptionValue}
          />
        </div>
      ) : (
        <NoResultsFound />
      )}
    </>
  );
};
