import { Column, Cell } from 'react-table';
import { languageService } from '../../../../services/Language/LanguageService';
import { AASortOption } from '../../../../services/Models/AccessArrangements';
import AccessArrangementsGridCell from '../AccessArrangementsGridCell/AccessArrangementsGridCell';
import React from 'react';
import { MORE_ACTIONS } from '../../../../constants/AccessArrangements';

type AAGridColumnOptions = {
  onMoreClick: (idx: number) => void;
  onMoreActionClick: (idx: number) => void;
  selectedIdx: number;
};
export const aaGridColumns = (columnOptions: AAGridColumnOptions) => {
  const aaLabels = languageService().accessArrangements;

  const getHeader = (name: AASortOption, label?: string) => ({
    label,
    name,
  });
  return [
    {
      Header: getHeader(AASortOption.CASE_NUMBER, aaLabels.caseNumber.toUpperCase()),
      accessor: 'externalCaseNumberId',
      Cell: AccessArrangementsGridCell,
    },
    {
      Header: getHeader(AASortOption.GIVEN_NAME, aaLabels.giveName.toUpperCase()),
      accessor: 'testTaker.firstName',
      Cell: AccessArrangementsGridCell,
    },
    {
      Header: getHeader(AASortOption.FAMILY_NAME, aaLabels.familyName.toUpperCase()),
      accessor: 'testTaker.lastName',
      Cell: AccessArrangementsGridCell,
    },
    {
      Header: getHeader(AASortOption.EXPIRY_DATE, aaLabels.expiryDate.toUpperCase()),
      accessor: 'expiryDate',
      Cell: AccessArrangementsGridCell,
    },
    {
      id: AASortOption.MORE,
      Header: getHeader(AASortOption.MORE),
      disableSortBy: true,
      Cell: (cellProps: Cell) => (
        <AccessArrangementsGridCell
          {...cellProps}
          moreCellOptions={{
            ...columnOptions,
            actions: MORE_ACTIONS,
          }}
        />
      ),
    },
  ] as Column[];
};
