import { Cell } from 'react-table';
import React, { useRef, useEffect } from 'react';
import MoreIcon from '../../../../assets/images/More.svg';
import { AASortOption } from '../../../../services/Models/AccessArrangements';
import { formatDateAsGB, getValue } from '../../../utils/utilities';
import styles from './AccessArrangementsGridCell.module.scss';
import GridMoreActions from '../../../Molecules/ManageUsersActions/ManageUsersActions';
import { Action } from '../../../../services/Models/Api';

type AAColumnHeader = { name: string; label: string };

interface AAGridCellProps extends Cell {
  moreCellOptions?: {
    onMoreClick: (idx: number) => void;
    selectedIdx: number;
    actions: Action[];
    onMoreActionClick: (idx: number) => void;
  };
}

export default (cellProps: AAGridCellProps) => {
  const header = cellProps.column.Header as AAColumnHeader;
  const moreActionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: any) => {
      if (moreActionRef.current && !moreActionRef.current.contains(event.target)) {
        cellProps.moreCellOptions?.onMoreClick(-1);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [moreActionRef]);

  const isDateBeforeToday = (date: string) => {
    console.log('date ', date);
    return new Date() > new Date(date);
  };

  switch (header.name) {
    case AASortOption.CASE_NUMBER:
    case AASortOption.GIVEN_NAME:
    case AASortOption.FAMILY_NAME:
    case AASortOption.EXPIRY_DATE:
      return (
        <div className={styles.flex}>
          <label className={styles.cellLabel}>
            {header.name === AASortOption.EXPIRY_DATE ? formatDateAsGB(cellProps.value) : getValue(cellProps.value)}
          </label>
          {header.name === AASortOption.EXPIRY_DATE && isDateBeforeToday(cellProps.value) && (
            <div className={styles.expiryDateStatus}>Expired</div>
          )}
        </div>
      );
    case AASortOption.MORE: {
      const isMoreSelected = cellProps.moreCellOptions?.selectedIdx === cellProps.row.index;
      const moreSelectedClass = isMoreSelected ? styles.userActionsOpened : '';
      return (
        <div id="ROActionsContainer" className={`${styles.userActionsContainer} ${moreSelectedClass}`}>
          <button className={styles.more} onClick={() => cellProps.moreCellOptions?.onMoreClick(cellProps.row.index)}>
            <img alt="more" src={MoreIcon} />
          </button>
          {isMoreSelected ? (
            <GridMoreActions
              id={'ROActionContainer'}
              containerRef={moreActionRef}
              userActions={cellProps.moreCellOptions?.actions}
              userActionsClickHandler={() => cellProps.moreCellOptions?.onMoreActionClick(cellProps.row.index)}
            />
          ) : null}
        </div>
      );
    }

    default:
      return <label> Hello </label>;
  }
};
