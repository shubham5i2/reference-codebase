import React from 'react';
import UI from 'ielts-cmds-ui-component-library';

import styles from './ResultsUpdateGrid.module.scss';
import { languageService } from '../../../services/Language/LanguageService';
import OnHold from '../../../assets/images/OnHold.png';
import Remove from '../../../assets/images/Remove.png';
import { ResultsGridSortType, ResultsGridCellType } from '../../Organisms/ResultsGrid/ResultsGridConstants';
import { ResultsSearchResult } from '../../../services/Models/Result';
import { Cell } from 'react-table';
import { addMinutes } from 'date-fns';
import { formatDate } from '../../../components/utils/utilities';
interface ResultUpdateGridProps {
  data: ResultsSearchResult[] & ResultsSearchResult;
  isMultipleUpdate: boolean;
  onDeleteBooking: (bookingID: string) => void;
}

const ResultUpdateGrid = (props: ResultUpdateGridProps) => {
  const resultsLabels = languageService().result;

  const getGridItemStatus = (cellProps: Cell) => {
    const statusClassName = typeof cellProps.value === 'string' ? cellProps.value.replace(' ', '').toLowerCase() : '';
    return (
      <div className={styles.resultStatus}>
        <div className={styles.resultStatusArea}>
          <div className={`${styles.statusCircle} ${styles[statusClassName + 'StatusCircle']}`} />
          <div className={styles.resultStatusText}>{cellProps.value}</div>
        </div>
        {props.data[cellProps.row.index].onHold && <img alt="OnHold" src={OnHold} />}
      </div>
    );
  };

  const getGridItem = (cellProps: Cell) => {
    return <div>{cellProps.value}</div>;
  };

  const columns = [
    {
      Header: {
        label: resultsLabels.firstNameLabel,
        name: ResultsGridSortType.FIRST_NAME,
      },
      accessor: ResultsGridCellType.FIRST_NAME,
      Cell: (cellProps: Cell) => getGridItem(cellProps),
    },
    {
      Header: {
        label: resultsLabels.lastNameLabel,
        name: ResultsGridSortType.LAST_NAME,
      },
      accessor: ResultsGridCellType.LAST_NAME,
      Cell: (cellProps: Cell) => getGridItem(cellProps),
    },
    {
      Header: {
        label: resultsLabels.testCentreLabel,
        name: ResultsGridSortType.TEST_CENTRE,
      },
      accessor: ResultsGridCellType.TEST_CENTRE,
      Cell: (cellProps: Cell) => getGridItem(cellProps),
    },
    {
      Header: {
        label: resultsLabels.testDateLabel,
        name: ResultsGridSortType.TEST_DATE,
      },
      accessor: ResultsGridCellType.TEST_DATE,
      Cell: (cellProps: Cell) => {
        let date = new Date(cellProps.value);
        date = addMinutes(date, date.getTimezoneOffset());
        return <div>{formatDate(date, 'dd MMM yyyy')}</div>;
      },
    },
    {
      Header: {
        label: resultsLabels.testTakerNumberLabel,
        name: ResultsGridSortType.TEST_TAKER_NUMBER,
      },
      accessor: ResultsGridCellType.TEST_TAKER_NUMBER,
      Cell: (cellProps: Cell) => getGridItem(cellProps),
    },
    {
      Header: {
        label: resultsLabels.currentResultStatusLabel,
        name: ResultsGridSortType.RESULTS_STATUS,
      },
      accessor: ResultsGridCellType.RESULTS_STATUS,
      Cell: (cellProps: Cell) => getGridItemStatus(cellProps),
    },
  ];

  const getGridItemDeleteBooking = (cellProps: Cell) => {
    return (
      <div>
        <img
          id="removeBooking"
          alt="Remove"
          src={Remove}
          onClick={() => props.onDeleteBooking(props.data[cellProps.row.index].bookingUuid)}
        />
      </div>
    );
  };

  const gridColumns =
    props.isMultipleUpdate && props.data.length > 0
      ? [
          ...columns,
          {
            id: 'remove',
            Header: {
              label: resultsLabels.removeLabel,
            },
            Cell: (cellProps: Cell) => getGridItemDeleteBooking(cellProps),
            disableSortBy: true,
          },
        ]
      : columns;
  const doNothing = () => null;

  return (
    <div className={styles.resultUpdateGrid}>
      <UI.ExpandableGrid
        id="resultsOnHoldGrid"
        columns={gridColumns}
        data={Array.isArray(props.data) ? props.data : [props.data]}
        initialState={{ pageSize: Array.isArray(props.data) ? props.data.length : 1 }}
        totalRecords={Array.isArray(props.data) ? props.data.length : 1}
        hideGridControls={true}
        onPageChange={doNothing}
        onPageSizeChange={doNothing}
        currentPage={0}
        pageSizeOptions={[{ text: '', value: 0 }]}
        selectedOptionValue={0}
      />
    </div>
  );
};

export default ResultUpdateGrid;
