import React, { useEffect, useState, useRef } from 'react';
import playIcon from '../../../assets/images/video.png';
import rightPlayer from '../../../assets/images/Right.png';
import loopIcon from '../../../assets/images/shufle.png';
import leftPlayer from '../../../assets/images/left.png';
import pauseIcon from '../../../assets/images/audio.png';
import styles from './AudioPlayer.module.scss';

export interface AudioPlayerProps {
  currentUrl: string;
  audioContainer: string;
  timeDuration: string;
  imageContainer: string;
  autoPlay?: boolean;
  onPlayNext: (url: string) => void;
  onPlayPrevious: (url: string) => void;
}

const AudioPlayer = (props: AudioPlayerProps) => {
  const [playToggle, setPlayToggle] = useState(props.autoPlay ? props.autoPlay : false);
  const [loopToggle, setLoopToggle] = useState(false);
  const [sliderVal, setSliderVal] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const sliderRef = useRef<HTMLInputElement | null>(null);
  const [duration, setDuration] = useState<number | string>(0.0);
  const { currentUrl, audioContainer, timeDuration, imageContainer, onPlayNext, onPlayPrevious } = props;

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.addEventListener('loadedmetadata', () => {
        let duration = 0.0;
        if (audioRef.current !== null) {
          duration = audioRef.current?.duration / 100;
        }
        setDuration(duration.toFixed(2));
      });
    }
    //eslint-disable-next-line
  }, [audioRef.current]);

  const playNextHandler = () => {
    onPlayNext(currentUrl);
    autoMeticPlay();
  };

  const playPreviousHandler = () => {
    onPlayPrevious(currentUrl);
    autoMeticPlay();
  };

  const autoMeticPlay = () => {
    audioRef.current?.addEventListener('loadedmetadata', () => {
      audioRef.current?.play();
      setPlayToggle(true);
    });
  };

  const changeDurationHandler = (event: React.FormEvent<HTMLInputElement>) => {
    const target = event.target as HTMLInputElement;
    const value = target.value;
    setSliderVal(parseInt(value));
    if (audioRef.current && sliderRef.current) {
      const sliderPosition = audioRef.current.duration * (parseInt(sliderRef.current.value) / 100);
      audioRef.current.currentTime = sliderPosition;
    }
  };

  const playAgainHandler = () => {
    setSliderVal(0);
    setLoopToggle(!loopToggle);
  };

  const timeUpdateHandler = () => {
    let time = 0.0;
    if (audioRef.current) {
      time = audioRef.current?.currentTime * (100 / audioRef.current?.duration);
    }
    setSliderVal(time);
    if (audioRef.current?.currentTime === audioRef.current?.duration) {
      setPlayToggle(false);
    }
  };

  const audioPlayerClickHandler = () => {
    if (audioRef.current?.paused) {
      audioRef.current.play();
      setPlayToggle(true);
    } else {
      audioRef.current?.pause();
      setPlayToggle(false);
    }
  };

  return (
    <div className={audioContainer} id="testTakerAudioPlayer">
      <input
        type="range"
        value={isNaN(sliderVal) ? 0 : sliderVal}
        id="durationSlider"
        ref={sliderRef}
        onChange={changeDurationHandler}
      />
      <audio
        autoPlay={props.autoPlay}
        controls
        controlsList="nodownload"
        ref={audioRef}
        loop={loopToggle}
        id="audioPlayer"
        onTimeUpdate={timeUpdateHandler}
        className={styles.audioPlayer}
        onContextMenu={(e) => e.preventDefault()}
        src={currentUrl}
      />
      <div className={timeDuration} id="timeDuration">
        <span>
          {typeof audioRef.current?.currentTime === 'undefined'
            ? parseFloat('0.0').toFixed(2)
            : parseFloat((audioRef.current?.currentTime / 100).toString()).toFixed(2)}
        </span>
        <span>{duration}</span>
      </div>
      <div className={imageContainer}>
        <img src={leftPlayer} alt="left-play" onClick={playPreviousHandler} id="left-play" />
        <img src={!playToggle ? playIcon : pauseIcon} alt="play-pause" onClick={audioPlayerClickHandler} id="play" />
        <img src={rightPlayer} alt="right-play" onClick={playNextHandler} id="right-play" />
        <span>
          <img src={loopIcon} alt="loop" onClick={playAgainHandler} id="loop-play" />
          {loopToggle && <p id="loopIcon" />}
        </span>
      </div>
    </div>
  );
};

export default AudioPlayer;
