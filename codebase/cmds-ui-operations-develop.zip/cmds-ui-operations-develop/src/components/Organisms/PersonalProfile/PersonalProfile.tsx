import React, { useEffect } from 'react';
import styles from './PersonalProfile.module.scss';
import UI from 'ielts-cmds-ui-component-library';
import { getKey } from '../../utils/utilities';
import { languageService } from '../../../services/Language/LanguageService';
import { organisationOptions, auth0Namespace, UserStatus } from '../../../services/Models/StaffManagement';
import { DropDownDataSource, RouteParams } from '../../../services/Models/UIModels';
import { useAuth0 } from '@auth0/auth0-react';
import PartnerDropDown from '../BaseDropDown/PartnerDropDown/PartnerDropDown';
import withServiceRequest from '../../../services/utils/ServiceRequest';
import { useParams } from 'react-router-dom';
import { TOGGLESWITCH, ACTIVESWITCH } from '../../../constants/UiConstants';

type ToggleEvent = {
  target: {
    name: string;
    checked: boolean;
    type?: string;
  };
};

const PersonalProfile = (props: any) => {
  const { user } = useAuth0();
  const smLabels = languageService().staffManagement;
  const partnerCode = user?.[auth0Namespace + smLabels.partnerCode]
    ? user?.[auth0Namespace + smLabels.partnerCode]
    : '';
  const { onChange, error } = props;
  const { id } = useParams<RouteParams>();

  useEffect(() => {
    const event = {
      target: {
        name: 'partnerCode',
        value: organisationOptions.find((item: DropDownDataSource) => item.value === partnerCode)?.value,
      },
    };
    if (partnerCode !== smLabels.global) {
      onChange(event);
    }
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div>
      <div className={styles.col3}>
        <UI.TextBox
          label={smLabels.givenName + smLabels.otherMandatorySymbol}
          inputFieldValidation={error.givenName}
          value={props.givenName}
          name="givenName"
          placeholder={smLabels.givenNamePlaceholder}
          onChange={(e: any) => onChange(e)}
        />
        <UI.TextBox
          label={smLabels.familyName + smLabels.otherMandatorySymbol}
          // inputFieldValidation={userNameValidation ? { ...userNameValidation, message: '' } : userNameValidation}
          inputFieldValidation={error.familyName}
          value={props.familyName}
          name="familyName"
          placeholder={smLabels.familyNamePlaceholder}
          onChange={(e: any) => onChange(e)}
        />
        <UI.TextBox
          label={smLabels.nickName}
          value={props.nickname}
          name="nickname"
          inputFieldValidation={error.nickName}
          placeholder={smLabels.nickNamePlaceholder}
          onChange={(e: any) => onChange(e)}
        />
        <UI.TextBox
          label={smLabels.email + smLabels.mandatorySymbol}
          inputFieldValidation={error.email}
          value={props.email}
          name="email"
          placeholder={smLabels.emailPlaceholder}
          onChange={(e: any) => onChange(e)}
          toolTipMessage={smLabels.emailToolTipMessage}
          inputDisabled={!!id}
        />
        <UI.ToggleSwitch
          checked={props.emailVerified}
          onChange={(e: ToggleEvent) => {
            e.target.type = 'toggle';
            onChange(e);
          }}
          label={smLabels.emailToggle}
          className={styles.sm_toggle}
          name="emailVerified"
          elementLabel={getKey(TOGGLESWITCH, !!props.emailVerified)}
        />
        <div></div>
        <UI.TextBox
          label={smLabels.phonenumber + smLabels.mandatorySymbol}
          inputFieldValidation={error.phoneNumber}
          name="phoneNumber"
          value={props.phoneNumber}
          placeholder={smLabels.phonenumberPlaceholder}
          onChange={(e: any) => onChange(e)}
          toolTipMessage={smLabels.phonenumberToolTipMessage}
        />
        <UI.ToggleSwitch
          checked={props.phoneVerified}
          onChange={(e: ToggleEvent) => {
            e.target.type = 'toggle';
            onChange(e);
          }}
          label={smLabels.phoneToggle}
          name="phoneVerified"
          elementLabel={getKey(TOGGLESWITCH, !!props.phoneVerified)}
        />
        <div></div>
        <PartnerDropDown
          id="organisation"
          labelId={'organisationLB'}
          label={smLabels.organisation + smLabels.mandatorySymbol}
          selectedPartner={partnerCode === smLabels.global ? props.partnerCode : partnerCode}
          textBoxPlaceHolder={smLabels.organisationPlaceholder}
          serviceRequest={props.serviceRequest}
          canUseStoreData
          isFetchDataOnLoad
          isFilterEnabled={false}
          inputFieldValidationError={partnerCode === smLabels.global ? error.partnerCode : { isValid: true }}
          partnerCode={partnerCode}
          isDisable={partnerCode !== smLabels.global}
          onPartnerChange={(value: string) => {
            const event = {
              target: {
                name: 'partnerCode',
                value: value,
              },
            };
            return onChange(event);
          }}
        />
        <UserStatusToggle status={props.userStatus} onChange={onChange} label={smLabels.status} />
      </div>
    </div>
  );
};

export default withServiceRequest(PersonalProfile);

const UserStatusToggle = ({ status, onChange, label }: { status: UserStatus; label: string; onChange: any }) => {
  const isChecked = status === UserStatus.ACTIVE;
  const name = 'userStatus';
  return (
    <UI.ToggleSwitch
      checked={isChecked}
      onChange={(e: ToggleEvent) => {
        onChange({
          target: {
            name,
            value: e.target.checked ? UserStatus.ACTIVE : UserStatus.INACTIVE,
          },
        });
      }}
      label={label}
      name={name}
      elementLabel={getKey(ACTIVESWITCH, isChecked)}
    />
  );
};
