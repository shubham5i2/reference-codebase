import React, { useState, useEffect } from 'react';
import UI from 'ielts-cmds-ui-component-library';

import styles from './IncidentManagementViewPanel.module.scss';
import withServiceRequest, { ServiceRequest } from '../../../services/utils/ServiceRequest';
import * as BreadCrumbActions from '../../../Store/Actions/BreadCrumbActions';
import { useStateValue } from '../../../Store/helpers/UseStateValue';
import { ExternalIcon, IncidentManagementDetailsScreenResponse } from '../../../services/Models/IncidentManagement';
import { getIncidentManagementDetails } from '../../../services/API/IncidentManagement/GetIncidentDetailsSearchResult';
import { useHistory, useParams } from 'react-router-dom';
import { AsyncResponseStatus } from '../../../services/Models/Api';
import IncidentDetailPanel from '../IncidentDetailPanel/IncidentDetailPanel';
import IncidentEditPanel from '../IncidentEditPanel/IncidentEditPanel';
import IncidentManagementViewHeader from '../IncidentManagementViewHeader/IncidentManagementViewHeader';
import { getProductValue } from '../../../services/API/Result/Product';
import { initialResultDetailsData } from '../../../constants/IncidentManagement/IncidentManagementViewPanelConstants';
import { languageService } from '../../../services/Language/LanguageService';

interface IncidentViewPanelProps {
  serviceRequest: ServiceRequest;
}

const IncidentManagementViewPanel = (props: IncidentViewPanelProps) => {
  const history = useHistory();
  const { stateIncidentUuid } = history.location.state || '';

  const [incidentInfo, setIncidentInfo] = useState<IncidentManagementDetailsScreenResponse[]>(initialResultDetailsData);
  const [selectedIncidentUuid, setSelectedIncidentUuid] = useState(stateIncidentUuid);
  const [editIndex, setEditIndex] = useState(1);
  const [isEditEnabled, setEditEnabled] = useState(false);
  const [editIncidentInfo, setEditIncidentInfo] = useState(incidentInfo[0].incidentBookingDetails.incidentDetails);
  const [isSuccessMessageOpeaned, setSuccessMessageOpener] = useState(false);

  const { id } = useParams<{ id: string }>();
  const { state, dispatch } = useStateValue();
  const productResponse = state.incidentManagement.products.productsResponse;
  const incidentManagementLabels = languageService().incidentManagement;

  useEffect(() => {
    id && getIncidentDetailsInfo(id);
    dispatch({ type: BreadCrumbActions.SHOW_BACK, payload: id });
    //eslint-disable-next-line
  }, [id]);

  const handleVistiToExternalPages = (arg: string) => {
    switch (arg) {
      case ExternalIcon.BOOKING:
        history.push(
          `/managetesttaker/testtakerbookinghistory/${incidentInfo[0].incidentBookingDetails.bookingDetails.uniqueTestTakerUuid}`,
          {
            selectedRow: 1,
            selectedBookingUuid: id,
            selectedUniqueTestTakerId: incidentInfo[0].incidentBookingDetails.bookingDetails.uniqueTestTakerId,
          },
        );
        break;
      case ExternalIcon.RESULT:
        history.push(`/results/viewTestTakerDetails/${id}`, {
          selectedRow: 1,
          selectedBookingUuid: id,
          testTakerName: `${incidentInfo[0].incidentBookingDetails.bookingDetails.firstName} ${incidentInfo[0].incidentBookingDetails.bookingDetails.lastName}`,
          resultsStatus: '',
          productName: getProductValue(
            incidentInfo[0].incidentBookingDetails.bookingDetails.productUuid,
            productResponse,
          ),
        });
        break;
      case ExternalIcon.ID_VERIFICATION:
        history.push(`/incidentmanagement/incidentmanagementviewdetails/incidentmanagementidverification/${id}`);
        break;
      case ExternalIcon.BANNING:
        break;
    } // for banning condition will be added when Banning page is developed
  };

  const pushIncidentEdit = (incdentUuid: string) => {
    const index = incidentInfo.findIndex(
      (item) => item.incidentBookingDetails.incidentDetails.incidentUuid === incdentUuid,
    );
    if (index < 0) return;
    setEditIncidentInfo(incidentInfo[index].incidentBookingDetails.incidentDetails);
    setEditIndex(index + 1);
    setEditEnabled(true);
  };

  const expansionHandler = (incidentUuid: string) => {
    const id = selectedIncidentUuid === incidentUuid ? '' : incidentUuid;
    setSelectedIncidentUuid(id);
  };

  const getIncidentDetailsInfo = (bookingUuid: string) => {
    getIncidentManagementDetails(bookingUuid, props.serviceRequest).subscribe(
      (incidentData: {
        incidentDetailsData: IncidentManagementDetailsScreenResponse[];
        status: AsyncResponseStatus;
      }) => {
        if (incidentData && incidentData.status === AsyncResponseStatus.SUCCESS) {
          setIncidentInfo(incidentData.incidentDetailsData);
        }
      },
    );
  };

  const reloadData = () => {
    setEditEnabled(false);
    getIncidentDetailsInfo(id);
  };

  return (
    <div className={styles.motherContainer}>
      {isSuccessMessageOpeaned ? (
        <div className={styles.messageContainer}>
          <UI.Message
            message={incidentManagementLabels.incidentSuccessMessage}
            color="success"
            dismissable
            onChange={() => setSuccessMessageOpener(false)}
          />
        </div>
      ) : null}
      <IncidentManagementViewHeader
        data={incidentInfo[0].incidentBookingDetails.bookingDetails}
        handleVistiToExternalPages={handleVistiToExternalPages}
        serviceRequest={props.serviceRequest}
      />
      {isEditEnabled && (
        <IncidentEditPanel
          incidentDetails={editIncidentInfo}
          index={editIndex}
          serviceRequest={props.serviceRequest}
          setEditEnabled={setEditEnabled}
          reload={reloadData}
          setSuccessMessage={setSuccessMessageOpener}
        />
      )}
      {/* - https://btsservice.atlassian.net/browse/IMOD-34008 */}
      {!isEditEnabled &&
        incidentInfo.map((item, index) => {
          const isExpanded =
            selectedIncidentUuid && selectedIncidentUuid === item.incidentBookingDetails.incidentDetails.incidentUuid;
          const props = {
            isExpanded,
            expansionHandler,
            pushIncidentEdit,
            actualIndex: index,
            displayIndex: index + 1,
            incidentDetails: item.incidentBookingDetails.incidentDetails,
          };
          return <IncidentDetailPanel {...props} key={item.incidentBookingDetails.incidentDetails.incidentUuid} />;
        })}
    </div>
  );
};

export default withServiceRequest(IncidentManagementViewPanel);
