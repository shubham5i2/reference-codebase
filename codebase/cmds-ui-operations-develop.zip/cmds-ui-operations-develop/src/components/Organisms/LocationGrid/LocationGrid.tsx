import React, { useState } from 'react';
import UI from 'ielts-cmds-ui-component-library';

import styles from './LocationGrid.module.scss';
import { languageService } from '../../../services/Language/LanguageService';
import { GridProps } from '../../../services/Models/UIModels';
import { useHistory } from 'react-router-dom';
import { LocationGridData, actionType, ColumnsData, LocationType } from '../../../services/Models/LocationManagement';
import { Action } from '../../../services/Models/Api';
import NoResultsFound from '../../Molecules/NoResultsFound/NoResultsFound';
import { getColumns } from './LocationGridColumns';
import { getBuildingsColumns } from './BuildingGridColumns';
import { useAuth0 } from '@auth0/auth0-react';

interface LocationGridProps extends GridProps {
  data: LocationGridData[];
  displayNoResult: boolean;
  locationType: LocationType;
  isLoading: boolean;
}

const LocationGrid = (props: LocationGridProps) => {
  const locationLabels = languageService().locationManagement;
  const history = useHistory();
  const [selectedToolTipIndex, setSelectedToolTipIndex] = useState<number | null>(null);
  const { displayNoResult, data, locationType } = props;

  const { user } = useAuth0();

  const actionsHandler = (action: Action, index: number) => {
    setSelectedToolTipIndex(null);
    switch (+action.type) {
      case actionType.VIEW_DETAILS:
        history.push(`/locationManagement/viewlocation/${props.data[index].locationUuid}`);
        break;
      case actionType.VIEW_PHYSICAL_BUILDING:
        history.push(`/locationManagement/viewbuildings/${props.data[index].testCentreNumber}`);
        break;
      case actionType.UPDATE:
        history.push(`/locationManagement/updateLocation/${props.data[index].locationUuid}`);
        break;
      default:
        break;
    }
  };

  const buildingActionsHandler = (action: Action, index: number) => {
    setSelectedToolTipIndex(null);
    switch (+action.type) {
      case actionType.VIEW_DETAILS:
        history.push(`/locationManagement/viewbuildings/viewDetails/${props.data[index].locationUuid}`, {
          testCentreNumber: props.data[index].testCentreNumber,
        });
        break;
      case actionType.UPDATE:
        history.push(
          `/locationManagement/viewbuildings/${props.data[index].testCentreNumber}/updateLocation/${props.data[index].locationUuid}`,
          {
            testCentreNumber: props.data[index].testCentreNumber,
          },
        );
        break;
      default:
        break;
    }
  };

  const getColumn = () => {
    return locationType === LocationType.TEST_CENTRE
      ? getColumns({
          actionsHandler,
          selectedToolTipIndex,
          user,
        } as ColumnsData)
      : getBuildingsColumns({
          actionsHandler: buildingActionsHandler,
          selectedToolTipIndex,
          user,
        } as ColumnsData);
  };

  return (
    <div id="locationGridContainer" className={styles.grid}>
      {data.length > 0 || props.isLoading ? (
        <UI.ExpandableGrid
          id="locationGrid"
          columns={getColumn()}
          data={data}
          initialState={props.gridState.initialState}
          onPageChange={props.onPageChange}
          onPageSizeChange={props.onPageSizeChange}
          totalRecords={props.gridState.totalRecords}
          currentPage={props.gridState.selectedPage}
          pageSizeOptions={props.pageSizeOptions}
          selectedOptionValue={props.gridState.selectedOptionValue}
          onColumnSort={props.onColumnSort}
          sortOption={props.sortOption}
          sort={props.sort}
          isLoading={props.isLoading}
        />
      ) : null}
      {displayNoResult && (
        <NoResultsFound title={locationLabels.noLocationsFoundTitle} description={locationLabels.noLocationFoundDesp} />
      )}
    </div>
  );
};

export default LocationGrid;
