import React from 'react';
import { Cell, Column } from 'react-table';
import styles from './LocationGrid.module.scss';
import LocationGridCell from '../LocationGridCell/LocationGridCell';
import { languageService } from '../../../services/Language/LanguageService';
import { LocationGridCellType, ColumnsData } from '../../../services/Models/LocationManagement';
import MoreIcon from '../../../assets/images/More.svg';
import { Action } from '../../../services/Models/Api';
import UI from 'ielts-cmds-ui-component-library';
import { buildingsActions } from '../../../constants/LocationManagement/LocationConstants';
import { isLMPartnerOnlyUser } from '../../Pages/LocationManagement/LocationManagementUtils';

export const getBuildingsColumns = (columnsData: ColumnsData) => {
  const { selectedToolTipIndex, actionsHandler, user } = columnsData;
  const locationLabels = languageService().locationManagement;

  return [
    {
      Header: {
        label: locationLabels.physicalBuildingName.toUpperCase(),
        name: LocationGridCellType.LOCATION_NAME,
      },
      accessor: LocationGridCellType.LOCATION_NAME,
      sortType: LocationGridCellType.LOCATION_NAME,
      Cell: (cellProps: Cell) => (
        <LocationGridCell
          id={LocationGridCellType.LOCATION_NAME}
          cellType={LocationGridCellType.LOCATION_NAME}
          value={cellProps.value}
        />
      ),
    },
    {
      Header: {
        label: locationLabels.cityLabel.toUpperCase(),
        name: LocationGridCellType.CITY,
      },
      accessor: LocationGridCellType.CITY,
      sortType: LocationGridCellType.CITY,
      Cell: (cellProps: Cell) => (
        <LocationGridCell id={LocationGridCellType.CITY} cellType={LocationGridCellType.CITY} value={cellProps.value} />
      ),
      disableSortBy: true,
    },
    {
      Header: {
        label: locationLabels.locationStatus.toUpperCase(),
        name: LocationGridCellType.LOCATION_STATUS,
      },
      accessor: LocationGridCellType.LOCATION_STATUS,
      Cell: (cellProps: Cell) => (
        <LocationGridCell
          id={LocationGridCellType.LOCATION_STATUS}
          cellType={LocationGridCellType.LOCATION_STATUS}
          value={cellProps.value}
        />
      ),
    },
    {
      Header: {
        label: locationLabels.action.toUpperCase(),
        name: LocationGridCellType.MORE,
      },
      id: 'More',
      Cell: (cellProps: Cell) => {
        const isMoreSelected = selectedToolTipIndex === cellProps.row.index;
        const moreSelectedClass = isMoreSelected ? styles.userActionsOpened : '';
        return (
          <div id="TTActionsContainer" className={`${styles.userActionsContainer} ${moreSelectedClass}`}>
            <UI.ShowMoreButton
              id={'moreButton'}
              moreIcon={MoreIcon}
              moreActions={buildingsActions(isLMPartnerOnlyUser(user))}
              moreActionsClickHandler={(action: Action) => actionsHandler(action, cellProps.row.index)}
            />
          </div>
        );
      },
      disableSortBy: true,
    },
  ] as Column[];
};
