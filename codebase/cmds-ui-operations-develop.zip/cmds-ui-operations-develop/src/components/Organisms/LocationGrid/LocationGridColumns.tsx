import React from 'react';
import { Cell, Column } from 'react-table';
import styles from './LocationGrid.module.scss';
import LocationGridCell from '../LocationGridCell/LocationGridCell';
import { languageService } from '../../../services/Language/LanguageService';
import { LocationGridCellType, ColumnsData } from '../../../services/Models/LocationManagement';
import MoreIcon from '../../../assets/images/More.svg';
import { Action } from '../../../services/Models/Api';
import UI from 'ielts-cmds-ui-component-library';
import { actions } from '../../../constants/LocationManagement/LocationConstants';
import { isLMPartnerOnlyUser } from '../../Pages/LocationManagement/LocationManagementUtils';

export const getColumns = (columnsData: ColumnsData) => {
  const { selectedToolTipIndex, actionsHandler, user } = columnsData;

  const locationLabels = languageService().locationManagement;
  return [
    {
      Header: {
        label: locationLabels.testCentreNumber.toUpperCase(),
        name: LocationGridCellType.TESTCENTRE_NUMBER,
      },
      accessor: LocationGridCellType.TESTCENTRE_NUMBER,
      sortType: LocationGridCellType.TESTCENTRE_NUMBER,
      Cell: (cellProps: Cell) => (
        <LocationGridCell
          id={LocationGridCellType.TESTCENTRE_NUMBER}
          cellType={LocationGridCellType.TESTCENTRE_NUMBER}
          value={cellProps.value}
        />
      ),
    },
    {
      Header: {
        label: locationLabels.partner.toUpperCase(),
        name: LocationGridCellType.PARTNER_CODE,
      },
      accessor: LocationGridCellType.PARTNER_CODE,
      sortType: LocationGridCellType.PARTNER_CODE,
      Cell: (cellProps: Cell) => (
        <LocationGridCell
          id={LocationGridCellType.PARTNER_CODE}
          cellType={LocationGridCellType.PARTNER_CODE}
          value={cellProps.value}
        />
      ),
    },
    {
      Header: {
        label: locationLabels.locationName.toUpperCase(),
        name: LocationGridCellType.LOCATION_NAME,
      },
      accessor: LocationGridCellType.LOCATION_NAME,
      sortType: LocationGridCellType.LOCATION_NAME,
      Cell: (cellProps: Cell) => (
        <LocationGridCell
          id={LocationGridCellType.LOCATION_NAME}
          cellType={LocationGridCellType.LOCATION_NAME}
          value={cellProps.value}
        />
      ),
    },
    {
      Header: {
        label: locationLabels.country.toUpperCase(),
        name: LocationGridCellType.COUNTRY,
      },
      accessor: LocationGridCellType.COUNTRY,
      Cell: (cellProps: Cell) => (
        <LocationGridCell
          id={LocationGridCellType.COUNTRY}
          cellType={LocationGridCellType.COUNTRY}
          value={cellProps.value}
        />
      ),
      disableSortBy: true,
    },
    {
      Header: {
        label: locationLabels.locationStatus.toUpperCase(),
        name: LocationGridCellType.LOCATION_STATUS,
      },
      accessor: LocationGridCellType.LOCATION_STATUS,
      Cell: (cellProps: Cell) => (
        <LocationGridCell
          id={LocationGridCellType.LOCATION_STATUS}
          cellType={LocationGridCellType.LOCATION_STATUS}
          value={cellProps.value}
        />
      ),
    },
    {
      Header: {
        label: locationLabels.action.toUpperCase(),
        name: LocationGridCellType.MORE,
      },
      id: 'More',
      Cell: (cellProps: Cell) => {
        const isMoreSelected = selectedToolTipIndex === cellProps.row.index;
        const moreSelectedClass = isMoreSelected ? styles.userActionsOpened : '';
        return (
          <div id="TTActionsContainer" className={`${styles.userActionsContainer} ${moreSelectedClass}`}>
            <UI.ShowMoreButton
              id={'moreButton'}
              moreIcon={MoreIcon}
              moreActions={actions(isLMPartnerOnlyUser(user))}
              moreActionsClickHandler={(action: Action) => actionsHandler(action, cellProps.row.index)}
            />
          </div>
        );
      },
      disableSortBy: true,
    },
  ] as Column[];
};
