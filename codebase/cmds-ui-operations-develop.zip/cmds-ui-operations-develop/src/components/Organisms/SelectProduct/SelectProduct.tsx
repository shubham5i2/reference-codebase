import React, { useState, useEffect } from 'react';
import UI from 'ielts-cmds-ui-component-library';
import { UICheckboxChangeEvent } from '../../../services/Models/UIModels';
import { isActiveToDate, statusStyle } from '../../utils/utilities';
import { ProductsResponse } from '../../../services/Models/Result';
import { getProducts } from '../../../services/API/Result/Product';
import { AsyncResponseStatus } from '../../../services/Models/Api';
import withServiceRequest, { ServiceRequest } from '../../../services/utils/ServiceRequest';
import styles from './SelectProduct.module.scss';
import { languageService } from '../../../services/Language/LanguageService';
import { ProductAuthorization, ProductSelectEvent } from '../../../services/Models/LocationManagement';
import { useStateValue } from '../../../Store/helpers/UseStateValue';
import { SAVE_PRODUCTS } from '../../../Store/Actions/BaseDropDownActions';

interface SelectProductProps {
  id: string;
  selectedProducts?: ProductAuthorization[];
  onProductSelect?: (event: ProductSelectEvent) => void;
  serviceRequest: ServiceRequest;
  isreadOnly: boolean;
}

const SelectProduct = (props: SelectProductProps) => {
  const { id, serviceRequest, onProductSelect, selectedProducts, isreadOnly } = props;
  const [products, setProducts] = useState<ProductsResponse[]>([]);
  const { state, dispatch } = useStateValue();
  const locationLabels = languageService().locationManagement;

  useEffect(() => {
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const fetchData = () => {
    if (state.baseDropDown?.products?.length > 0) {
      setFilterproducts(state.baseDropDown?.products);
    } else {
      getProducts(serviceRequest).subscribe((data) => {
        if (data.status === AsyncResponseStatus.SUCCESS) {
          const bookableProducts = data.products.filter((items: ProductsResponse) => items.bookable);
          dispatch({
            type: SAVE_PRODUCTS,
            payload: {
              response: bookableProducts,
            },
          });
          setFilterproducts(bookableProducts);
        }
      });
    }
  };

  const setFilterproducts = (products: ProductsResponse[]) => {
    if (!isreadOnly) {
      setProducts(products);
    } else {
      const filteredproducts = products.filter((product) =>
        selectedProducts?.find((selectedProduct) => selectedProduct.productUuid === product.productUuid),
      );
      setProducts(filteredproducts);
    }
  };

  const isProductChecked = (productUuid: string) => {
    return !!selectedProducts?.find(
      (selectedProduct: ProductAuthorization) => selectedProduct.productUuid === productUuid,
    );
  };

  const getProductStatus = (toDate: string) => {
    return isActiveToDate(toDate) ? 'Active' : 'Inactive';
  };

  return (
    <div id={id}>
      <div className={styles.locPrimaryLabel}>
        <UI.Typography
          type="normal"
          label={isreadOnly ? locationLabels.selectedAuthorizedProducts : locationLabels.authorizedProducts}
          size={14}
        />
      </div>
      <div className={isreadOnly ? styles.readOnlyContainer : styles.container}>
        {products?.map(({ productUuid, productName, effectiveToDate }: ProductsResponse) => (
          <div data-testid="product" key={productUuid} className={styles.productElement}>
            {!isreadOnly ? (
              <UI.CheckBox
                checked={isProductChecked(productUuid)}
                label={productName}
                labelId={`${id}_checkbox_label`}
                id={`${id}checkbox`}
                onChange={(e: UICheckboxChangeEvent) => {
                  onProductSelect && onProductSelect({ productUuid, isChecked: e.checked });
                }}
              />
            ) : null}
            {isreadOnly ? <span className={styles.productName}>{productName}</span> : null}
            <UI.Status
              status={statusStyle[getProductStatus(effectiveToDate).toUpperCase()]}
              label={getProductStatus(effectiveToDate)}
              typographyProps={{ size: 12 }}
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default withServiceRequest(SelectProduct);
