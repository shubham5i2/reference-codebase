import React, { useState, useEffect } from 'react';
import { DropDownDataSource, Dictionary, DataState, DropDownType } from '../../../../services/Models/UIModels';
import UI from 'ielts-cmds-ui-component-library';
import styles from './ProductDropDown.module.scss';

import { useEffectUpdate, sortValues, getAppendedURL, changeKeyName } from '../../../utils/utilities';
import { useStateValue } from '../../../../Store/helpers/UseStateValue';
import { ProductsResponse } from '../../../../services/Models/Result';
import { loadProduct } from '../../../../services/Preloader/usePreloader';
import { ServiceRequest } from '../../../../services/utils/ServiceRequest';

export interface ProductDropDownProps {
  actionType?: string;
  id: string;
  label: string;
  labelId: string;
  onChange: (value: string, text: string) => void;
  includeInactive?: boolean;
  inputFieldValidationError?: Dictionary;
  isFetchDataOnLoad?: boolean;
  isFilterEnabled: boolean;
  isMandatory?: boolean;
  options?: DropDownDataSource[] | [];
  searchPlaceHolderText?: string;
  selectedValue: string | string[] | DropDownDataSource | undefined;
  textBoxPlaceHolder?: string;
  dropDownType?: DropDownType;
  serviceRequest: ServiceRequest;
}

const ProductDropDown = ({
  actionType,
  id,
  inputFieldValidationError,
  labelId,
  isFetchDataOnLoad,
  isMandatory,
  label,
  onChange,
  selectedValue,
  textBoxPlaceHolder,
  isFilterEnabled,
  dropDownType = DropDownType.SINGLE,
  serviceRequest,
}: ProductDropDownProps) => {
  const { state, dispatch } = useStateValue();
  const [open, setOpen] = useState(false);

  const url = getAppendedURL('/cache-product/v2/products');
  const { data, status, error, fetchApi } = UI.useSyncFetch(url, {
    headers: {
      'Content-Type': 'application/json',
    },
  });

  useEffect(() => {
    isFetchDataOnLoad && fetchData();
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (status === DataState.LOADED && data?.length > 0) {
      dispatch({
        type: actionType,
        payload: changeKeyName(data, 'productName', 'name'),
      });
    }

    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data]);

  /** Calling async v1 product api when sync api is failed*/
  useEffect(() => {
    if (error !== undefined && error !== null) {
      loadProduct({ serviceRequest: serviceRequest, dispatcher: dispatch });
    }
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [error]);

  useEffectUpdate(() => {
    fetchData();
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const getBookableProduct = (res: ProductsResponse[]) => {
    return (
      res &&
      res
        .filter((items: ProductsResponse) => items.bookable)
        .map((r: ProductsResponse) => ({
          value: r.productUuid,
          text: r.productName,
        }))
    );
  };

  const fetchData = () => {
    const products = state?.products?.response || [];

    if (products && products.length === 0) {
      fetchApi();
    }
  };

  const openHandler = () => {
    setOpen(true);
  };

  return dropDownType === DropDownType.SINGLE ? (
    <UI.Dropdown
      id={id}
      className={styles.productDropdown}
      label={label}
      labelId={labelId}
      placeholder={textBoxPlaceHolder}
      mandatory={isMandatory}
      onDropDownOpen={openHandler}
      onDropDownClose={fetchData}
      selectedValue={selectedValue || ''}
      inputFieldValidation={inputFieldValidationError}
      list={getBookableProduct(state?.products?.response) || []}
      onChange={onChange}
      isLoading={status === DataState.LOADING}
    />
  ) : (
    <UI.MultiSelectDropDown
      id={id}
      labelId={labelId}
      label={label}
      onChange={onChange}
      onDropDownOpen={openHandler}
      onDropDownClose={fetchData}
      value={selectedValue || ''}
      placeholder={textBoxPlaceHolder}
      list={(state?.products?.response && sortValues(getBookableProduct(state?.products?.response))) || []}
      inputFieldValidation={inputFieldValidationError}
      showInputWithoutList
      mandatory={isMandatory}
      isFilterEnabled={isFilterEnabled}
      isLoading={status === DataState.LOADING}
    />
  );
};

export default ProductDropDown;
