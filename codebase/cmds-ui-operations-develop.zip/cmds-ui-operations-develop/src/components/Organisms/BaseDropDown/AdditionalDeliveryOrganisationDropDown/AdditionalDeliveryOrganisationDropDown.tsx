import React, { useEffect, useState, useRef } from 'react';
import UI from 'ielts-cmds-ui-component-library';
import { ServiceRequest } from '../../../../services/utils/ServiceRequest';
import { DropDownDataSource, Dictionary, MultiDropDownDataSource } from '../../../../services/Models/UIModels';
import { getAdditionalDeliveryOrganisation } from '../../../../services/API/Organisation/AdditionalDeliveryOrganisation';
import { OrganisationFormAction, OrganisationType } from '../../../../services/Models/Organisation';

export interface AdditionalDeliveryOrganisationDropDownProps {
  id: string;
  label: string;
  labelId: string;
  serviceRequest: ServiceRequest;
  selectedAdditionalDelOrg: MultiDropDownDataSource;
  onAdditionalDelOrgChange: (value: MultiDropDownDataSource) => void;
  isFilterEnabled: boolean;
  searchPlaceHolderText?: string;
  includeInactive?: boolean;
  inputFieldValidationError?: Dictionary;
  isMandatory?: boolean;
  textBoxPlaceHolder: string;
  parentOrgUuId: string;
  organisationType: DropDownDataSource;
  recognisingOrganisationUuid: string | undefined;
  formActionType: OrganisationFormAction;
}

const AdditionalDeliveryOrganisationDropDown = (props: AdditionalDeliveryOrganisationDropDownProps) => {
  const [addDelOrgOptions, setAddDelOrgOptions] = useState<DropDownDataSource[]>([]);
  const [isLoading, setLoading] = useState(false);
  const initialAddDelOrgOptionsRef = useRef<DropDownDataSource[]>([]);
  const setInitialAddDelOrgOptions = (value: DropDownDataSource[]) => (initialAddDelOrgOptionsRef.current = value);

  useEffect(() => {
    setAddDelOrgOptions([]);
    setInitialAddDelOrgOptions([]);
    if (props.formActionType === OrganisationFormAction.UPDATE || props.parentOrgUuId) {
      fetchAddDelOrgData();
    }
    // Reset the additional delivery organisation when the parent is removed in add screen
    if (props.formActionType === OrganisationFormAction.ADD && !props.parentOrgUuId) {
      props.onAdditionalDelOrgChange({});
    }
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.parentOrgUuId]);

  const fetchAddDelOrgData = () => {
    setLoading(true);
    getAdditionalDeliveryOrganisation(
      props.serviceRequest,
      props.parentOrgUuId,
      props.recognisingOrganisationUuid,
    ).subscribe((data) => {
      setLoading(false);
      const newAdditionalDelOrgs = data.additionalDeliveryOrganisationData || [];
      setAddDelOrgOptions(newAdditionalDelOrgs);
      setInitialAddDelOrgOptions(newAdditionalDelOrgs);
      const updatedSelectedAdditionalDelOrg: MultiDropDownDataSource = {};
      Object.keys(props.selectedAdditionalDelOrg).forEach((key) => {
        const filteredOrg = newAdditionalDelOrgs.filter((delOrg: DropDownDataSource) => delOrg.value === key);
        if (filteredOrg.length > 0) {
          updatedSelectedAdditionalDelOrg[key] = props.selectedAdditionalDelOrg[key];
        }
      });
      props.onAdditionalDelOrgChange(updatedSelectedAdditionalDelOrg);
    });
  };

  const getDropdownDisable = () => {
    if (props.formActionType === OrganisationFormAction.ADD) {
      return !props.parentOrgUuId;
    }
    return false;
  };

  return props.organisationType.value === OrganisationType.RO ? (
    <>
      <UI.MultiSelectDropDown
        id={props.id}
        labelId={props.labelId}
        label={props.label}
        onChange={props.onAdditionalDelOrgChange}
        value={props.selectedAdditionalDelOrg}
        placeholder={props.textBoxPlaceHolder}
        list={addDelOrgOptions?.filter((organisation) => organisation.value !== props.recognisingOrganisationUuid)}
        inputFieldValidation={props.inputFieldValidationError}
        disable={getDropdownDisable()}
        showInputWithoutList
        isLoading={isLoading}
        isFilterEnabled={props.isFilterEnabled}
      />
    </>
  ) : null;
};

export default AdditionalDeliveryOrganisationDropDown;
