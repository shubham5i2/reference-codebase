import React, { useEffect, useState } from 'react';
import UI from 'ielts-cmds-ui-component-library';
import { getUserGroups } from '../../../../services/API/Reference/UserGroups';
import { ServiceRequest } from '../../../../services/utils/ServiceRequest';
import { sortValues, useEffectUpdate } from '../../../utils/utilities';
import { useStateValue } from '../../../../Store/helpers/UseStateValue';
import { DataState, UserFormError } from '../../../../services/Models/UIModels';
import { USER_GROUPS_DATA, USER_GROUPS_DATA_LOADING } from '../../../../Store/Actions/ManageUserActions';
import { getUserGroupDataKey } from '../../../../Store/reducers/ManageUser';

export interface UserGroupDropDownProps {
  id: string;
  label: string;
  serviceRequest: ServiceRequest;
  selectedUserGroupValue: string;
  onUserGroupChange: (UserGroupValue: string, userGroupName: string) => void;
  canUseStoreData?: boolean;
  isFilterEnabled: boolean;
  searchPlaceHolderText?: string;
  isFetchDataOnLoad?: boolean;
  locationUUid?: string;
  inputFieldValidationError?: UserFormError;
  isDisable?: boolean;
  textBoxPlaceHolder?: string;
  emailDomain?: string;
  partnerCode?: string;
  text?: string;
}

const UserGroupDropDown = (props: UserGroupDropDownProps) => {
  const [isDropDownOpen, setDropDownOpen] = useState(false);
  const { state, dispatch } = useStateValue();
  const [usergroupOptions, setUsergroupOptions] = useState([]);

  useEffect(() => {
    props.isFetchDataOnLoad && !props.isDisable && fetchUserGroupData(props.isFetchDataOnLoad);
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    fetchUserGroupData(!props.isFetchDataOnLoad && isDropDownOpen);
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isDropDownOpen]);

  useEffectUpdate(() => {
    fetchUserGroupData(!!props.isFetchDataOnLoad);
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.locationUUid]);

  const getPartnerCode = () => {
    if (props.partnerCode) return props.partnerCode;
    else return '';
  };
  const partnerCode = getPartnerCode();

  const usergroupKey = getUserGroupDataKey({
    partnerCode,
    locationUuid: props.locationUUid,
    emailDomain: props.emailDomain,
  });

  const usergroupData = state?.ManageUser?.userGroupsData?.[usergroupKey] || {};
  console.log({ usergroupData });

  const fetchUserGroupData = (isLoadData: boolean) => {
    const payload = {
      locationUuid: props.locationUUid,
      emailDomain: props.emailDomain,
      partnerCode,
    };
    const usergroups = usergroupData.options || [];
    if (usergroups.length > 0 && usergroupData.dataState !== DataState.LOADING) {
      setUsergroupOptions(usergroups);
      return;
    } else if (isLoadData && !props.isDisable) {
      dispatch({
        type: USER_GROUPS_DATA_LOADING,
        payload,
      });
      getUserGroups(props.serviceRequest, props.locationUUid, props.emailDomain, partnerCode).subscribe((data) => {
        setDropDownOpen(false);
        dispatch({
          type: USER_GROUPS_DATA,
          payload: {
            userGroupData: data.userGroupData,
            ...payload,
          },
        });
        setUsergroupOptions(data.userGroupData);
      });
    }
  };

  const userGroupDropDownOpenhandler = () => {
    setDropDownOpen(true);
  };

  const isUserGroupExistInList = () => {
    return (
      props.text &&
      usergroupOptions.findIndex((item: { value: string | undefined }) => item.value === props.selectedUserGroupValue) >
        -1
    );
  };

  return (
    <>
      <UI.Dropdown
        id={props.id}
        label={props.label}
        selectedValue={props.selectedUserGroupValue}
        onChange={props.onUserGroupChange}
        list={sortValues(usergroupOptions)}
        onDropDownOpen={userGroupDropDownOpenhandler}
        inputFieldValidation={props.inputFieldValidationError?.userGroup}
        disable={props.isDisable || isUserGroupExistInList() === false}
        placeholder={props.textBoxPlaceHolder}
        isLoading={usergroupData?.dataState === DataState.LOADING}
        showInputWithoutList
        showInputNotIncludedInList={isUserGroupExistInList() === false}
        selectedText={props.text}
        isFilterEnabled={props.isFilterEnabled}
      />
    </>
  );
};

export default UserGroupDropDown;
