import React, { useState, useEffect } from 'react';
import { ServiceRequest } from '../../../../services/utils/ServiceRequest';
import { DropDownDataSource, Dictionary } from '../../../../services/Models/UIModels';
import UI from 'ielts-cmds-ui-component-library';
import styles from './ResultsStatusLabelDropDown.module.scss';
import { useStateValue } from '../../../../Store/helpers/UseStateValue';
import { useEffectUpdate } from '../../../utils/utilities';
import { ResultStatusResponse, ResultsStatusLabelResponse } from '../../../../services/Models/Result';

export interface ResultsStatusLabelDropDownProps {
  actionType?: string;
  canUseStoreData?: boolean;
  id: string;
  label: string;
  labelId: string;
  onChange: (value: string, text: string) => void;
  includeInactive?: boolean;
  inputFieldValidationError?: Dictionary;
  isFetchDataOnLoad?: boolean;
  isFilterEnabled: boolean;
  isMandatory?: boolean;
  options?: DropDownDataSource[] | [];
  searchPlaceHolderText?: string;
  selectedValue: string | DropDownDataSource;
  resultStatusTypeUuid?: string;
  serviceRequest: ServiceRequest;
  textBoxPlaceHolder?: string;
}

const ResultsStatusLabelDropDown = (props: ResultsStatusLabelDropDownProps) => {
  const {
    id,
    inputFieldValidationError,
    labelId,
    isFetchDataOnLoad,
    isMandatory,
    label,
    onChange,
    options: initialOptions,
    selectedValue,
    resultStatusTypeUuid,
    textBoxPlaceHolder,
  } = props;
  const { state } = useStateValue();
  const [options, setOptions] = useState(initialOptions);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    isFetchDataOnLoad && fetchData();
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [resultStatusTypeUuid]);

  useEffectUpdate(() => {
    fetchData();
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const fetchData = () => {
    const resultStatuses = state.referenceData?.resultStatus?.transformedData || [];
    if (resultStatuses.length > 0) {
      setOptions(
        [
          {
            value: '',
            text: 'Not applicable',
          },
        ].concat(
          resultStatuses
            .find((data: ResultStatusResponse) => resultStatusTypeUuid === data.resultsStatusTypeUuid)
            ?.resultStatusLabels?.map((r: ResultsStatusLabelResponse) => ({
              value: r.resultStatusLabelUuid,
              text: r.resultStatusLabel,
            })) || [],
        ),
      );
    }
  };

  const openHandler = () => {
    setOpen(true);
  };

  const getSelectedResultStatusText = () => {
    return options?.find((resultStatus) => resultStatus.value === selectedValue)?.text;
  };

  return (
    <UI.Dropdown
      id={id}
      className={styles.ResultsStatusLabelDropDown}
      label={label}
      labelId={labelId}
      placeholder={textBoxPlaceHolder}
      mandatory={isMandatory}
      onDropDownOpen={openHandler}
      onDropDownClose={fetchData}
      selectedValue={selectedValue || ''}
      inputFieldValidation={inputFieldValidationError}
      list={options || []}
      onChange={onChange}
      showInputWithoutList
      selectedText={getSelectedResultStatusText() || ''}
    />
  );
};

export default ResultsStatusLabelDropDown;
