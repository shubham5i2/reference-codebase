import React, { useEffect, useState } from 'react';
import UI from 'ielts-cmds-ui-component-library';
import { ServiceRequest } from '../../../../services/utils/ServiceRequest';
import { sortValues, getValue, useEffectUpdate } from '../../../utils/utilities';
import { getLocations } from '../../../../services/API/ManageUser/Locations';
import { AsyncResponseStatus } from '../../../../services/Models/Api';
import { useAuth0 } from '@auth0/auth0-react';
import { auth0Namespace } from '../../../../services/Models/StaffManagement';
import { languageService } from '../../../../services/Language/LanguageService';
import { DropDownDataSource, UserFormError } from '../../../../services/Models/UIModels';

export interface LocationDropDownProps {
  id: string;
  label: string;
  labelId?: string;
  serviceRequest: ServiceRequest;
  selectedLocationValue: string;
  onLocationChange: (UserGroupValue: string, userGroupName: string) => void;
  canUseStoreData?: boolean;
  actionType?: string;
  locationType: string;
  assignableToGroups: boolean;
  isFilterEnabled?: boolean;
  searchPlaceHolderText?: string;
  inputFieldValidationError?: UserFormError;
  isFetchDataOnLoad?: boolean;
  storeDataPath?: string;
  textBoxPlaceHolder?: string;
  partnerCode?: string;
  locationName?: string;
  isDisable?: boolean;
  isMandatory?: boolean;
  // Set this to true when we need to preselect location when the location count is one
  shouldPreSelectOnlyLocation?: boolean;
  getOptionsList?: (locationOptions: LocationData[]) => LocationData[];
}

export interface LocationData {
  locationUuid: string;
  locationType: string;
  locationCode?: string;
  locationName: string;
  text: string;
  value: string;
}

const LocationDropDown = (props: LocationDropDownProps) => {
  const { user } = useAuth0();
  const [isDropDownOpen, setDropDownOpen] = useState(false);
  const [locationOptions, setLocationOptions] = useState<LocationData[]>([]);
  const [initialLocationOptions, setInitialLocationOptions] = useState<LocationData[]>([]);
  const [selectedLocation, setSelectedLocation] = useState(props.selectedLocationValue);
  const smLabels = languageService().staffManagement;

  console.log({ locationName: props.locationName });

  useEffect(() => {
    props.isFetchDataOnLoad && fetchLocationsData();
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    setLocationOptions([]);
    setDropDownOpen(false);
  }, [props.locationType]);

  useEffect(() => {
    setSelectedLocation(props.selectedLocationValue);
  }, [props.selectedLocationValue]);

  useEffectUpdate(() => {
    isDropDownOpen && fetchLocationsData();
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isDropDownOpen]);

  const fetchLocationsData = () => {
    if (locationOptions.length > 0) {
      return;
    }
    const userId = getValue(user?.sub).split(/\|/)[1] || '';
    const partnerCode = getPartnerCode();

    getLocations(userId, partnerCode, props.locationType, props.assignableToGroups, props.serviceRequest).subscribe(
      (data) => {
        if (data.status === AsyncResponseStatus.SUCCESS) {
          setLocationOptions(data.testCentersData || []);
          setInitialLocationOptions(data.testCentersData || []);
          props.shouldPreSelectOnlyLocation &&
            data.testCentersData.length === 1 &&
            preSelectLocationValue(data.testCentersData[0]);
        }
      },
    );
  };

  const preSelectLocationValue = (location: DropDownDataSource) => {
    locationChangeHandler(location.value, location.text);
  };

  const locationChangeHandler = (value: string, text: string) => {
    props.onLocationChange(value, text);
  };

  const getPartnerCode = () => {
    if (props.partnerCode) {
      return props.partnerCode;
    } else {
      const partner = user?.[auth0Namespace + smLabels.partnerCode]
        ? user?.[auth0Namespace + smLabels.partnerCode]
        : '';
      return partner === 'GLOBAL_IELTS' ? '' : partner;
    }
  };

  const locationDropDownOpenhandler = () => {
    console.log('Dropdown Open');
    setDropDownOpen(true);
  };

  const onDropdownFilter = (value: string) => {
    const newState = value
      ? initialLocationOptions.filter(
          (item: DropDownDataSource) => item.text.toLowerCase().indexOf(value.toLowerCase()) > -1,
        )
      : initialLocationOptions;
    setLocationOptions(newState);
  };

  const restOfTheProps = () => {
    return props.isFilterEnabled
      ? {
          search: props.isFilterEnabled,
          onSearch: onDropdownFilter,
          searchIcon: 'normal',
          onDropdownClose: () => setLocationOptions(initialLocationOptions),
          searchPlaceholderText: props.searchPlaceHolderText || '',
        }
      : {};
  };

  return (
    <>
      <UI.Dropdown
        id={props.id}
        label={props.label}
        labelId={props.labelId}
        selectedValue={selectedLocation}
        disable={props.isDisable}
        mandatory={props.isMandatory}
        onChange={locationChangeHandler}
        list={sortValues(props.getOptionsList ? props.getOptionsList(locationOptions) : locationOptions)}
        onDropDownOpen={locationDropDownOpenhandler}
        inputFieldValidation={props.inputFieldValidationError?.location}
        placeholder={props.textBoxPlaceHolder}
        showInputWithoutList
        selectedText={props.locationName || ''}
        {...restOfTheProps()}
      />
    </>
  );
};

export default LocationDropDown;
