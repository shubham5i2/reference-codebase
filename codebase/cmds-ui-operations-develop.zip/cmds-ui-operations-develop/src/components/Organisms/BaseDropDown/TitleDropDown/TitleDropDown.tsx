import React, { useState, useEffect } from 'react';
import UI from 'ielts-cmds-ui-component-library';
import { useEffectUpdate } from '../../../utils/utilities';
import { languageService } from '../../../../services/Language/LanguageService';
import style from './TitleDropDown.module.scss';

export interface TitleDropDownProps {
  id: string;
  labelId: string;
  selectedTitle?: string;
  onTitleChange: (text: string) => void;
}

enum Title {
  MR = 'mr',
  MRS = 'mrs',
  MISS = 'miss',
  MS = 'ms',
  DR = 'dr',
  OTHER = 'other',
}

const titles = [
  { text: 'Mr', value: Title.MR },
  { text: 'Mrs', value: Title.MRS },
  { text: 'Miss', value: Title.MISS },
  { text: 'Ms', value: Title.MS },
  { text: 'Dr.', value: Title.DR },
  { text: 'Others', value: Title.OTHER },
];

const TitleDropDown = (props: TitleDropDownProps) => {
  const { id, labelId, selectedTitle, onTitleChange } = props;
  const organisationLabels = languageService().organisation;

  const [isTitleOthers, setIsTitleOthers] = useState(false);
  const [selectedDropDownValue, setSelectedDropDownValue] = useState('');
  const [otherValue, setOtherValue] = useState('');

  useEffect(() => {
    if (selectedTitle) {
      updateTitle(selectedTitle);
    }
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffectUpdate(() => {
    updateTitle(selectedTitle);
  }, [selectedTitle]);

  const updateTitle = (selectedTitle?: string) => {
    const title = titles.find((currentTitle) => currentTitle.text === selectedTitle);
    if (!title) {
      setIsTitleOthers(true);
      setSelectedDropDownValue(Title.OTHER);
      setOtherValue(selectedTitle || '');
    } else {
      setSelectedDropDownValue(title?.value || '');
    }
  };
  const titleDropDownChangeHandler = (value: string, text: string) => {
    if (value === Title.OTHER) {
      setIsTitleOthers(true);
      onTitleChange('');
    } else {
      onTitleChange(text);
      setIsTitleOthers(false);
    }
  };

  const otherChangeHandler = (event: React.ChangeEvent<HTMLInputElement>) => {
    onTitleChange(event.target.value);
  };

  return (
    <div className={style.titleDropDown}>
      <div className={style.dropdownContainer}>
        <UI.Dropdown
          id={id}
          labelId={labelId}
          label={organisationLabels.title}
          selectedValue={selectedDropDownValue}
          onChange={titleDropDownChangeHandler}
          list={titles}
          // onDropDownOpen={TerritoryDropDownOpenhandler}
          // inputFieldValidation={props.inputFieldValidationError}
          // placeholder={props.textBoxPlaceHolder}
        />
      </div>

      {isTitleOthers && (
        <UI.TextBox
          label={organisationLabels.other}
          labelId={id + 'otherTitleLbl'}
          value={otherValue}
          name={'title'}
          id={id + 'otherTitle'}
          placeholder=" "
          onChange={otherChangeHandler}
          maxLength={20}
        />
      )}
    </div>
  );
};

export default TitleDropDown;
