import React, { useEffect, useState } from 'react';
import { ServiceRequest } from '../../../../services/utils/ServiceRequest';
import { DropDownDataSource, Dictionary } from '../../../../services/Models/UIModels';
import UI from 'ielts-cmds-ui-component-library';
import { useStateValue } from '../../../../Store/helpers/UseStateValue';
import { getNestedProperty } from '../../../utils/utilities';
import { getNationalities } from '../../../../services/API/Reference/Nationality';

export interface NationalityDropDownProps {
  id: string;
  label: string;
  labelId: string;
  serviceRequest: ServiceRequest;
  selectedNationality: DropDownDataSource;
  onNationalityChange: (value: string, text: string) => void;
  canUseStoreData?: boolean;
  actionType?: string;
  isFilterEnabled: boolean;
  searchPlaceHolderText?: string;
  includeInactive?: boolean;
  inputFieldValidationError?: Dictionary;
  storeDataPath?: string;
  isMandatory?: boolean;
  textBoxPlaceHolder: string;
}

const NationalityDropDown = (props: NationalityDropDownProps) => {
  const { id, label, textBoxPlaceHolder } = props;

  const [isDropDownOpen, setDropDownOpen] = useState(false);
  const { state, dispatch } = useStateValue();
  const [nationalitiesOptions, setNationalitiesOptions] = useState<DropDownDataSource[]>([]);
  const [initialNationalitiesOptions, setInitialNationalitiesOptions] = useState<DropDownDataSource[]>([]);

  useEffect(() => {
    fetchNationalitiesData(isDropDownOpen);
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isDropDownOpen]);

  const fetchNationalitiesData = (isLoadData: boolean) => {
    const nationalities = getNestedProperty(state, props.storeDataPath || '') || [];
    if (props.canUseStoreData && nationalities.length > 0) {
      setNationalitiesOptions(nationalities);
      setInitialNationalitiesOptions(nationalities);
      return;
    } else if (isLoadData) {
      const { nationalitiesData } = getNationalities();
      setDropDownOpen(false);
      props.actionType &&
        dispatch({
          type: props.actionType,
          payload: { nationalities: nationalitiesData },
        });
      setNationalitiesOptions(nationalitiesData);
      setInitialNationalitiesOptions(nationalitiesData);
    }
  };

  const onDropdownFilter = (value: string) => {
    const newState = value
      ? initialNationalitiesOptions.filter(
          (item: DropDownDataSource) => item.text.toLowerCase().indexOf(value.toLowerCase()) > -1,
        )
      : initialNationalitiesOptions;
    setNationalitiesOptions(newState);
  };

  const restOfTheProps = () => {
    return props.isFilterEnabled
      ? {
          search: props.isFilterEnabled,
          onSearch: onDropdownFilter,
          searchIcon: 'normal',
          onDropdownClose: () => setNationalitiesOptions(initialNationalitiesOptions),
          searchPlaceholderText: props.searchPlaceHolderText || '',
        }
      : {};
  };

  const nationalityDropDownOpenhandler = () => {
    setDropDownOpen(true);
  };

  return (
    <UI.Dropdown
      id={id}
      label={label}
      mandatory={props.isMandatory}
      labelId={props.labelId}
      placeholder={textBoxPlaceHolder}
      selectedValue={props.selectedNationality.value || ''}
      inputFieldValidation={props.inputFieldValidationError}
      list={nationalitiesOptions}
      onChange={props.onNationalityChange}
      onDropDownOpen={nationalityDropDownOpenhandler}
      showInputWithoutList
      selectedText={props.selectedNationality.text || ''}
      {...restOfTheProps()}
    />
  );
};

export default NationalityDropDown;
