import React, { useEffect, useState } from 'react';
import { ServiceRequest } from '../../../../services/utils/ServiceRequest';
import { DropDownDataSource, Dictionary, DataState, DropDownType } from '../../../../services/Models/UIModels';
import UI from 'ielts-cmds-ui-component-library';
import { useStateValue } from '../../../../Store/helpers/UseStateValue';
import { getPartners } from '../../../../services/API/Reference/Partner';
import { ReferenceDropdownType } from '../../ReferenceDropdown/UseReferenceFetch';
import { DATA_LOADED, DATA_LOADING } from '../../../../Store/Actions/ReferenceActions';
export enum Partner {
  Global = 'GLOBAL_IELTS',
  IDP = 'IDP',
  USA = 'IELTS_USA',
  Cambridge = 'CA',
  BC = 'BC',
}

export interface PartnerDropDownProps {
  id: string;
  label: string;
  labelId: string;
  serviceRequest: ServiceRequest;
  selectedPartner: string | DropDownDataSource | undefined | string[];
  onPartnerChange: (value: string, text: string) => void;
  canUseStoreData?: boolean;
  isFilterEnabled?: boolean;
  searchPlaceHolderText?: string;
  includeInactive?: boolean;
  inputFieldValidationError?: Dictionary;
  textBoxPlaceHolder: string;
  partnerCode?: string;
  isMandatory?: boolean;
  isFetchDataOnLoad?: boolean;
  isDisable?: boolean;
  hiddenPartner?: Partner[];
  dropDownType?: DropDownType;
}

const PartnerDropDown = (props: PartnerDropDownProps) => {
  const { id, label, textBoxPlaceHolder, dropDownType = DropDownType.SINGLE, isFilterEnabled } = props;

  const [isDropDownOpen, setDropDownOpen] = useState(false);
  const { state, dispatch } = useStateValue();
  const [partnerOptions, setPartnerOptions] = useState<DropDownDataSource[]>([]);

  useEffect(() => {
    props.isFetchDataOnLoad && fetchPartnersData(props.isFetchDataOnLoad);
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    fetchPartnersData(!props.isFetchDataOnLoad && isDropDownOpen);
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isDropDownOpen]);

  const fetchPartnersData = (isLoadData: boolean) => {
    const partners = state?.referenceData?.partner?.transformedData || [];
    if (props.canUseStoreData && partners.length > 0) {
      const partnersData = fileredOrganisation(partners, props.partnerCode);
      setPartnerOptions(partnersData);
      return;
    } else if (isLoadData) {
      dispatch({
        type: DATA_LOADING,
        payload: {
          dropdownType: ReferenceDropdownType.PARTNER,
        },
      });
      getPartners(props.serviceRequest).subscribe((data) => {
        setDropDownOpen(false);
        const partnersData = fileredOrganisation(data.partnersData, props.partnerCode);
        dispatch({
          type: DATA_LOADED,
          payload: {
            dropdownType: ReferenceDropdownType.PARTNER,
            response: null,
            transformedData: data.transformedData,
          },
        });
        setPartnerOptions(partnersData);
      });
    }
  };

  const fileredOrganisation = (organisationList: DropDownDataSource[], partnerCode?: string) => {
    if (!partnerCode) {
      return organisationList;
    }
    return organisationList.filter(
      (item: DropDownDataSource) => item.value === partnerCode || partnerCode === 'GLOBAL_IELTS',
    );
  };

  const partnerDropDownOpenhandler = () => {
    setDropDownOpen(true);
  };

  const getSelectedPatnerValue = () => {
    return typeof props.selectedPartner === 'string'
      ? props.selectedPartner
      : (props.selectedPartner as DropDownDataSource)?.value;
  };

  const getSelectedPatnerText = () => {
    return typeof props.selectedPartner === 'string'
      ? props.selectedPartner
      : (props.selectedPartner as DropDownDataSource)?.text;
  };

  const getHiddenPartnerCodeList = () => {
    return partnerOptions.filter((item) => !props.hiddenPartner?.includes(item.value as Partner));
  };

  return dropDownType === DropDownType.SINGLE ? (
    <UI.Dropdown
      id={id}
      label={label}
      labelId={props.labelId}
      placeholder={textBoxPlaceHolder}
      selectedValue={getSelectedPatnerValue() || ''}
      inputFieldValidation={props.inputFieldValidationError}
      list={getHiddenPartnerCodeList()}
      onChange={props.onPartnerChange}
      onDropDownOpen={partnerDropDownOpenhandler}
      mandatory={props.isMandatory}
      disable={props.isDisable}
      showInputWithoutList
      selectedText={getSelectedPatnerText()}
      isLoading={state?.referenceData?.partner?.dataState === DataState.LOADING}
      isFilterEnabled={isFilterEnabled}
    />
  ) : (
    <UI.MultiSelectDropDown
      id={id}
      label={label}
      labelId={props.labelId}
      placeholder={textBoxPlaceHolder}
      onChange={props.onPartnerChange}
      value={props.selectedPartner}
      list={getHiddenPartnerCodeList()}
      inputFieldValidation={props.inputFieldValidationError}
      showInputWithoutList
      mandatory={props.isMandatory}
      isFilterEnabled={isFilterEnabled}
      isLoading={state?.referenceData?.partner?.dataState === DataState.LOADING}
    />
  );
};

export default PartnerDropDown;
