import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import { ServiceRequest } from '../../../../services/utils/ServiceRequest';
import { getTerritoriesState, sortValues } from '../../../utils/utilities';
import { useStateValue } from '../../../../Store/helpers/UseStateValue';
import { AsyncResponseStatus } from '../../../../services/Models/Api';
import { DropDownDataSource, Dictionary, DataState } from '../../../../services/Models/UIModels';
import { getTerritories } from '../../../../services/API/Reference/Territories';
import { DATA_LOADED, DATA_LOADING, DATA_LOAD_ERROR } from '../../../../Store/Actions/ReferenceActions';
import { ReferenceDropdownType } from '../../ReferenceDropdown/UseReferenceFetch';

export interface TerritoryDropDownProps {
  id: string;
  label: string;
  labelId: string;
  serviceRequest: ServiceRequest;
  selectedTerritory: DropDownDataSource;
  onTerritoryChange: (value: string, text: string) => void;
  canUseStoreData?: boolean;
  isFilterEnabled: boolean;
  searchPlaceHolderText?: string;
  includeInactive?: boolean;
  inputFieldValidationError?: Dictionary | string;
  isMandatory?: boolean;
  textBoxPlaceHolder: string;
  countryCode: string;
}

const TerritoryDropDown = (props: TerritoryDropDownProps) => {
  const { state, dispatch } = useStateValue();

  const fetchTerritoryData = () => {
    const payload = {
      dropdownType: ReferenceDropdownType.TERRITORY,
      subkey: props.countryCode,
    };

    if (props.canUseStoreData && getTerritoriesState(state, props.countryCode).transformedData?.length > 0) {
      return;
    } else {
      dispatch({ type: DATA_LOADING, payload });
      getTerritories(props.serviceRequest, props.countryCode).subscribe((data) => {
        if (data.status === AsyncResponseStatus.SUCCESS && data.transformedData?.length > 0) {
          dispatch({
            type: DATA_LOADED,
            payload: {
              ...payload,
              response: data.response,
              transformedData: data.transformedData,
            },
          });
        } else {
          dispatch({ type: DATA_LOAD_ERROR, payload });
        }
      });
    }
  };

  const TerritoryDropDownOpenhandler = () => {
    fetchTerritoryData();
  };

  return (
    <>
      <UI.Dropdown
        id={props.id}
        labelId={props.labelId}
        label={props.label}
        mandatory={props.isMandatory}
        selectedValue={props.selectedTerritory.value}
        onChange={props.onTerritoryChange}
        list={sortValues(getTerritoriesState(state, props.countryCode).transformedData)}
        onDropDownOpen={TerritoryDropDownOpenhandler}
        inputFieldValidation={props.inputFieldValidationError}
        placeholder={props.textBoxPlaceHolder}
        disable={!props.countryCode}
        showInputWithoutList
        selectedText={props.selectedTerritory.text || ''}
        isFilterEnabled={props.isFilterEnabled}
        isLoading={getTerritoriesState(state, props.countryCode)?.dataState === DataState.LOADING}
      />
    </>
  );
};

export default TerritoryDropDown;
