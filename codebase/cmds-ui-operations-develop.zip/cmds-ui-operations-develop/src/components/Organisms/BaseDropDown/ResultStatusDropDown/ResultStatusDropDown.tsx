import React, { useState, useEffect } from 'react';
import { ServiceRequest } from '../../../../services/utils/ServiceRequest';
import { DropDownDataSource, Dictionary } from '../../../../services/Models/UIModels';
import UI from 'ielts-cmds-ui-component-library';
import styles from './ResultStatusDropDown.module.scss';
import { useStateValue } from '../../../../Store/helpers/UseStateValue';
import { useEffectUpdate } from '../../../utils/utilities';
import { AsyncResponseStatus } from '../../../../services/Models/Api';
import { getResultStatuses } from '../../../../services/API/Result/ResultStatus';
import { ResultStatusResponse } from '../../../../services/Models/Result';
import { DATA_LOADED, DATA_LOADING, DATA_LOAD_ERROR } from '../../../../Store/Actions/ReferenceActions';
import { ReferenceDropdownType } from '../../ReferenceDropdown/UseReferenceFetch';

export interface ResultStatusDropDownProps {
  canUseStoreData?: boolean;
  id: string;
  label: string;
  labelId: string;
  onChange: (value: string, text: string) => void;
  includeInactive?: boolean;
  inputFieldValidationError?: Dictionary;
  isFetchDataOnLoad?: boolean;
  isFilterEnabled: boolean;
  isMandatory?: boolean;
  options?: DropDownDataSource[] | [];
  searchPlaceHolderText?: string;
  selectedValue: string | DropDownDataSource;
  serviceRequest: ServiceRequest;
  textBoxPlaceHolder?: string;
}

const ResultStatusDropDown = (props: ResultStatusDropDownProps) => {
  const {
    id,
    inputFieldValidationError,
    labelId,
    isFetchDataOnLoad,
    isMandatory,
    label,
    onChange,
    options: initialOptions,
    selectedValue,
    serviceRequest,
    textBoxPlaceHolder,
  } = props;
  const { state, dispatch } = useStateValue();
  const [options, setOptions] = useState(initialOptions);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    isFetchDataOnLoad && fetchData();
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffectUpdate(() => {
    fetchData();
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const fetchData = () => {
    const resultStatuses = state.referenceData?.resultStatus?.transformedData || [];
    if (resultStatuses.length > 0) {
      setOptions(
        resultStatuses.map((r: ResultStatusResponse) => ({
          value: r.resultsStatusTypeUuid,
          text: r.resultsStatusType,
        })),
      );
    } else {
      dispatch({
        type: DATA_LOADING,
        payload: {
          dropdownType: ReferenceDropdownType.RESULT_STATUS,
        },
      });
      getResultStatuses(serviceRequest).subscribe((data) => {
        if (data.status === AsyncResponseStatus.SUCCESS) {
          dispatch({
            type: DATA_LOADED,
            payload: {
              dropdownType: ReferenceDropdownType.RESULT_STATUS,
              response: null,
              transformedData: data.transformedData,
            },
          });
          setOptions(
            data.resultStatuses.map((r: ResultStatusResponse) => ({
              value: r.resultsStatusTypeUuid,
              text: r.resultsStatusType,
            })),
          );
        } else {
          dispatch({
            type: DATA_LOAD_ERROR,
            payload: {
              dropdownType: ReferenceDropdownType.RESULT_STATUS,
            },
          });
        }
      });
    }
  };

  const openHandler = () => {
    setOpen(true);
  };

  const getSelectedResultStatusText = () => {
    return options?.find((resultStatus) => resultStatus.value === selectedValue)?.text;
  };

  return (
    <UI.Dropdown
      id={id}
      className={styles.ResultStatusDropdown}
      label={label}
      labelId={labelId}
      placeholder={textBoxPlaceHolder}
      mandatory={isMandatory}
      onDropDownOpen={openHandler}
      onDropDownClose={fetchData}
      selectedValue={selectedValue || ''}
      inputFieldValidation={inputFieldValidationError}
      list={options || []}
      onChange={onChange}
      showInputWithoutList
      selectedText={getSelectedResultStatusText() || ''}
    />
  );
};

export default ResultStatusDropDown;
