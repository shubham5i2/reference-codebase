import React from 'react';
import UI from 'ielts-cmds-ui-component-library';

import { languageService } from '../../../services/Language/LanguageService';
import styles from './LinkedBookingDetails.module.scss';
import Attachment from '../../../assets/images/Attachment.svg';
import { LinkedBookingDetailsData } from '../../../services/Models/Result';
import { formatDate } from '../../utils/utilities';

interface LinkedBookingDetailsProps {
  linkedBookingDetailsData: LinkedBookingDetailsData;
  onClickViewBooking: (bookingUuid: string) => void;
  labelTextSize?: number;
}

const LinkedBookingDetails = (props: LinkedBookingDetailsProps) => {
  const resultLabels = languageService().result;
  const { linkedBookingDetailsData, onClickViewBooking, labelTextSize = 15 } = props;
  const {
    testDate,
    testCentreNumber,
    locationId,
    shortCandidateNumber,
    productName,
    testCentreName,
    locationName,
    bookingUuid,
  } = linkedBookingDetailsData;

  return (
    <>
      <div className={styles.flexLayout}>
        <div className={styles.ResultsTestTakerDetailsWrapper}>
          <div className={[styles.ResultsTestTakerDetails, styles.BookingDetails].join(' ')}>
            <div className={styles.header}>
              <div className={styles.headerTitle}>
                <UI.Icon icon={Attachment} />
                <div> {resultLabels.linkedBooking}</div>
              </div>
            </div>
            <div className={styles.body}>
              <div className={styles.sectionHeader}>{resultLabels.testBookingInfoText.toUpperCase()}</div>
              <div className={[styles.detailsContainerGrid, styles.withSeparator].join(' ')}>
                <div className={styles.leftColumn}>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="testDate"
                      label={resultLabels.testDateLabel}
                      value={linkedBookingDetailsData ? formatDate(new Date(testDate), 'dd MMM yyyy') : ''}
                      size={labelTextSize}
                    />
                  </div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="testCentreNumber"
                      label={resultLabels.testCentreNumberLabel}
                      value={linkedBookingDetailsData ? testCentreNumber : ''}
                      size={labelTextSize}
                    />
                  </div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="locationID"
                      label={resultLabels.locationIDLabel}
                      value={linkedBookingDetailsData ? locationId : ''}
                      size={labelTextSize}
                    />
                  </div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="testTakerNumber"
                      label={resultLabels.testTakerNumberLabel}
                      value={linkedBookingDetailsData ? shortCandidateNumber : ''}
                      size={labelTextSize}
                    />
                  </div>
                </div>
                <div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="productName"
                      label={resultLabels.productLabel}
                      value={linkedBookingDetailsData ? productName : ''}
                      size={labelTextSize}
                    />
                  </div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="testCentreName"
                      label={resultLabels.testCentreNameLabel}
                      value={linkedBookingDetailsData ? testCentreName : ''}
                      size={labelTextSize}
                    />
                  </div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="location"
                      label={resultLabels.locationLabel}
                      value={linkedBookingDetailsData ? locationName : ''}
                      size={labelTextSize}
                    />
                  </div>
                  <div className={styles.field}>
                    <UI.Button
                      label={resultLabels.viewBookingDetailsButtonText}
                      onChange={() => onClickViewBooking(bookingUuid)}
                      addButtonColor="blueLine"
                      color={'blueLine'}
                      title={resultLabels.viewBookingDetailsButtonText}
                      id="viewBooking"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default LinkedBookingDetails;
