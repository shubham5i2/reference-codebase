import React from 'react';
import styles from './StatusHistoryGrid.module.scss';
import { ResultStatusInfo } from '../../Pages/Results/ResultsTestTakerDetails/ResultsTestTakerDetailsConstants';
import { StatusHistoryGridItemTypes } from '../../../services/Models/Result';
import StatusHistoryGridItem from './StatusHistoryGridItem/StatusHistoryGridItem';

export interface StatusHistoryGridProps {
  statusHistory?: ResultStatusInfo[];
}

export default (props: StatusHistoryGridProps) => {
  const getType = (s: ResultStatusInfo) => {
    let listItemType: StatusHistoryGridItemTypes | undefined;
    if (s.onHold === null) {
      listItemType =
        s.resultStatusUpdatedBy === 'System User' ? StatusHistoryGridItemTypes.AUTO : StatusHistoryGridItemTypes.MANUAL;
    } else if (s.resultStatusUpdatedBy !== 'System User') {
      listItemType = s.onHold ? StatusHistoryGridItemTypes.ONHOLD : StatusHistoryGridItemTypes.NOTONHOLD;
    }

    return listItemType;
  };
  return (
    <div className={styles.grid}>
      {props.statusHistory?.map((s: ResultStatusInfo, index: number) => {
        const resultStatustype = getType(s);
        return resultStatustype && <StatusHistoryGridItem key={index} listItemType={resultStatustype} data={s} />;
      })}
    </div>
  );
};
