import React from 'react';
import user from '../../../../assets/images/user.png';
import computer from '../../../../assets/images/computer.png';
import Clock from '../../../../assets/images/Clock.svg';
import styles from './StatusHistoryGridItem.module.scss';
import { ResultStatusInfo } from '../../../Pages/Results/ResultsTestTakerDetails/ResultsTestTakerDetailsConstants';
import { StatusHistoryGridItemTypes } from '../../../../services/Models/Result';
import { formatDate } from '../../../utils/utilities';
import { languageService } from '../../../../services/Language/LanguageService';
import ResultLabels from '../../../../services/Language/en/en.result';

export interface StatusHistoryGridItemProps {
  listItemType: StatusHistoryGridItemTypes;
  data: ResultStatusInfo;
}
export type ListItemContentType = { text: string; img: string };
interface ListItemContent {
  [key: string]: ListItemContentType;
}
const StatusHistoryGridItem = (props: StatusHistoryGridItemProps) => {
  const resultLabels = languageService().result;
  const listItemContent: ListItemContent = {
    [StatusHistoryGridItemTypes.MANUAL]: { text: resultLabels.resultsStatusManualChange, img: user },
    [StatusHistoryGridItemTypes.AUTO]: { text: resultLabels.resultsStatusAutoChange, img: computer },
    [StatusHistoryGridItemTypes.ONHOLD]: { text: resultLabels.placedResult, img: user },
    [StatusHistoryGridItemTypes.NOTONHOLD]: { text: resultLabels.removed, img: user },
  };
  const { data, listItemType } = props;
  const listItemView = () => {
    return (
      <div className={[styles.row, styles.statusHistoryManualRow].join(' ')}>
        <img src={listItemContent[listItemType].img} alt="user" height="28px" />
        <div className={styles.statusChange}>
          <div id="listItemText">
            {listItemType !== StatusHistoryGridItemTypes.AUTO && (
              <b className={styles.updatedBy}>{data.resultStatusUpdatedBy}</b>
            )}
            {' ' + listItemContent[listItemType].text}{' '}
            {listItemType === StatusHistoryGridItemTypes.ONHOLD ||
            listItemType === StatusHistoryGridItemTypes.NOTONHOLD ? (
              <>
                <b>{ResultLabels.onHoldLabel}</b>
                {listItemType === StatusHistoryGridItemTypes.NOTONHOLD && ' flag'}
              </>
            ) : null}
            <b>{data.resultStatusType}</b>
          </div>
          {(listItemType === StatusHistoryGridItemTypes.MANUAL || listItemType === StatusHistoryGridItemTypes.AUTO) && (
            <>
              {data.resultStatusLabel && (
                <div>
                  <span className={styles.label}>{resultLabels.statusLabelLabel}</span>
                  {data.resultStatusLabel}
                </div>
              )}

              {data.resultStatusComment && (
                <div>
                  <span className={styles.label}>{resultLabels.statusCommentsLabel}</span>
                  {data.resultStatusComment}
                </div>
              )}
            </>
          )}
        </div>
        <div className={styles.date}>
          <img alt="" src={Clock} className={styles.clock} />
          {`${formatDate(new Date(data.resultStatusUpdateDatetime), 'dd MMM yyyy')} | ${formatDate(
            new Date(data.resultStatusUpdateDatetime),
            'HH:mm',
          )}`}
        </div>
      </div>
    );
  };
  return listItemView();
};
export default StatusHistoryGridItem;
