import React from 'react';
import UI from 'ielts-cmds-ui-component-library';

import styles from './LocationViewDetails.module.scss';
import { languageService } from '../../../services/Language/LanguageService';
import { LocationDetailControl, LocationDetailsData, LocationType } from '../../../services/Models/LocationManagement';
import { formatDate } from '../../utils/utilities';

export interface LocationViewDetailsProps {
  locationDetailsData: LocationDetailsData;
}

const LocationViewDetails = (props: LocationViewDetailsProps) => {
  const { locationDetailsData } = props;
  const locationLables = languageService().locationManagement;
  const commonLabels = languageService().common;
  const size = 14;
  const type = 'regular';

  //getting lables as per location typecode
  const locationTypeCodevalue = (locationTypeCode: string) => {
    return locationTypeCode === LocationType.TEST_CENTRE ? locationLables.testCentre : locationLables.physicalBuilding;
  };

  return (
    <div
      className={
        locationDetailsData.locationTypeCode === LocationType.TEST_CENTRE
          ? styles.viewLocationHeaderContainer
          : styles.viewBuildingHeaderContainer
      }
    >
      <UI.DisplayLabelValuePair
        id={LocationDetailControl.LOCATION_TYPE_CODE}
        label={locationLables.locationType}
        value={locationTypeCodevalue(locationDetailsData.locationTypeCode)}
        type={type}
        size={size}
      />

      <UI.DisplayLabelValuePair
        id={LocationDetailControl.PARTNER_CODE}
        label={locationLables.partnerCode}
        value={locationDetailsData.partnerCode}
        type={type}
        size={size}
      />

      <UI.DisplayLabelValuePair
        id={LocationDetailControl.PARENT_LOCATION_UUID}
        label={locationLables.parentLocation}
        value={locationDetailsData.parentLocationUuid}
        type={type}
        size={size}
      />

      <UI.DisplayLabelValuePair
        id={LocationDetailControl.EXTERNAL_LOCATION_UUID}
        label={locationLables.externalLocationUUID}
        value={locationDetailsData.externalLocationUuid}
        type={type}
        size={size}
      />

      <UI.DisplayLabelValuePair
        id={LocationDetailControl.EXTERNAL_PARTNER_LOCATION_UUID}
        label={locationLables.externalParentLocation}
        value={locationDetailsData.externalParentLocationUuid}
        type={type}
        size={size}
      />

      <UI.DisplayLabelValuePair
        id={LocationDetailControl.TESTCENTER_NUMER}
        label={locationLables.testCenterNumber}
        value={locationDetailsData.testCentreNumber}
        type={type}
        size={size}
      />

      <UI.DisplayLabelValuePair
        id={LocationDetailControl.LOCATION_NAME}
        label={locationLables.locationName}
        value={locationDetailsData.locationName}
        type={type}
        size={size}
        className={styles.locationName}
      />

      <UI.DisplayLabelValuePair
        id={LocationDetailControl.TIMEZONE_NAME}
        label={locationLables.timezoneName}
        value={locationDetailsData.timezoneName}
        type={type}
        size={size}
      />
      {locationDetailsData.locationTypeCode === LocationType.TEST_CENTRE ? (
        <UI.DisplayLabelValuePair
          id={LocationDetailControl.WEBSITE_URL}
          label={locationLables.websiteURL}
          value={locationDetailsData.websiteURL}
          type={type}
          size={size}
          className={styles.websiteURL}
          valueClickHandler={() => locationDetailsData.websiteURL && window.open(locationDetailsData.websiteURL)}
        />
      ) : null}
      <UI.DisplayLabelValuePair
        id={LocationDetailControl.ACTIVATED_DATE}
        label={locationLables.activatedDate}
        value={
          locationDetailsData.activatedDate === null
            ? formatDate(new Date(''), 'dd MMM yyyy')
            : formatDate(new Date(locationDetailsData.activatedDate), 'dd MMM yyyy')
        }
        type={type}
        size={size}
      />

      <UI.DisplayLabelValuePair
        id={LocationDetailControl.LOCATION_STATUS}
        label={locationLables.locationStatus}
        value={locationDetailsData.locationStatus?.toLowerCase()}
        type={type}
        size={size}
      />
      {locationDetailsData.locationTypeCode === LocationType.TEST_CENTRE ? (
        <UI.DisplayLabelValuePair
          id={LocationDetailControl.ELIGIBLE_FOR_OFFLINE_TESTING}
          label={locationLables.eligibleForOfflineTesting}
          value={locationDetailsData.eligibleForOfflineTesting === true ? commonLabels.yes : commonLabels.no}
          type={type}
          size={size}
        />
      ) : null}
    </div>
  );
};

export default LocationViewDetails;
