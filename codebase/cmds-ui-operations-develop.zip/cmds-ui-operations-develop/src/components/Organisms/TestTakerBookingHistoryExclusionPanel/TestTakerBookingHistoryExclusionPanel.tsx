import React from 'react';

import styles from './TestTakerBookingHistoryExclusionPanel.module.scss';
import Badge from '../../../assets/images/Ban.svg';
import { languageService } from '../../../services/Language/LanguageService';
import { ExclusionList } from '../../../services/Models/TestTakerManagement';

import MoreIcon from '../../../assets/images/More.svg';
import {
  BookingHistoryActionsProps,
  TestTakerBookingHistoryPageActionsProps,
} from '../../Pages/TestTakerBookingHistoryPage/TestTakerBookingHistoryPage';
import TestTakerBookingHistoryActionsContainer from '../TestTakerBookingHistoryActionsContainer/TestTakerBookingHistoryActionsContainer';

export interface TestTakerBookingHistoryExclusionPanelProps {
  exclusionList?: ExclusionList[];
  selectedToolTipIndex: number | null;
  exclusionPanelActions: BookingHistoryActionsProps[];
  moreClickHandler: (index: number, exclusionAction: boolean) => void;
  userActionsClickHandler: (props: TestTakerBookingHistoryPageActionsProps) => void;
  actionContainerRef: React.RefObject<HTMLSpanElement>;
  isExclusionPanelAction: boolean;
}

const TestTakerBookingHistoryExclusionPanel = (props: TestTakerBookingHistoryExclusionPanelProps) => {
  const testTakerLabels = languageService().testTaker;

  return (
    <div className={styles.ttbhExclusionPanelContainer}>
      <div className={styles.ttbhExpandableContainer}>
        <span className={styles.ttbhExclusionPanelContainerTitle}>
          <img src={Badge} alt="Exclusion List Logo" />
          {testTakerLabels.ttbhExclusionTitle}
        </span>
      </div>
      {props.exclusionList?.map((exclusionItem, index) => {
        const isMoreSelected = props.selectedToolTipIndex === index && props.isExclusionPanelAction;
        const moreSelectedClass = isMoreSelected ? styles.exclusionListActionsOpened : '';
        return (
          <div className={styles.ttbhExclusionPanelDataGrid} key={exclusionItem.exclusionDetails.bookingUuid}>
            <TestTakerBookingHistoryActionsContainer
              dataLabelClass={styles.ttbhExclusionPanelDataLabel}
              containerClass={`${styles.exclusionListActionsContainer} ${moreSelectedClass} ${styles.moreBtn}`}
              actionContainerRef={props.actionContainerRef}
              containerId="exclusionListActionsContainer"
              moreClickHandler={props.moreClickHandler}
              iconSrc={MoreIcon}
              isMoreSelected={isMoreSelected}
              panelActions={props.exclusionPanelActions}
              index={index}
              isExclusion={true}
              bookingUuid={exclusionItem.exclusionDetails.bookingUuid}
              uniqueTestTakerUuid={exclusionItem.exclusionDetails.uniqueTestTakerUuid}
              testTakerName={exclusionItem.exclusionDetails.firstName + ' ' + exclusionItem.exclusionDetails.lastName}
              userActionsClickHandler={props.userActionsClickHandler}
              ttbhDetailsTitle={testTakerLabels.ttbhExclusionSubTitle}
            />
            <span className={styles.ttbhExclusionPanelDataContent}>{exclusionItem.exclusionDetails.bookingUuid}</span>
          </div>
        );
      })}
    </div>
  );
};

export default TestTakerBookingHistoryExclusionPanel;
