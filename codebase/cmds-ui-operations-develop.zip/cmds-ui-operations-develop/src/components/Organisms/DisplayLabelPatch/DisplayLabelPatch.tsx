import React from 'react';
import UI from 'ielts-cmds-ui-component-library';

import { UITypography } from '../../../services/Models/UIModels';
import styles from './DisplayLabelPatch.module.scss';

export interface LabelElements {
  label: string;
  value: string | React.ReactNode;
  size?: number;
  type?: UITypography;
}

export interface PatchRowData {
  rowElements: LabelElements[];
  size: number;
  type: UITypography;
}

export interface DisplayLabelPatchProps {
  rowsData: PatchRowData[];
  className?: string;
}

const DisplayLabelPatch = (props: DisplayLabelPatchProps) => {
  const { rowsData } = props;

  return (
    <div className={props.className ? `${styles.superContainer} ${props.className}` : styles.superContainer}>
      {rowsData.map((item, index) => {
        const style = index !== rowsData.length - 1 ? styles.detailContainerOtherRow : styles.detailContainerLastRow;
        return (
          <div
            key={`${index}_${item.rowElements[0].value}_${item.rowElements[0].label}`}
            className={rowsData.length === 1 ? styles.detailContainerNorm : style}
          >
            {item.rowElements.map((val, idx) => {
              const type = val.type ? val.type : item.type;
              const size = val.size ? val.size : item.size;
              return (
                <UI.DisplayLabelValuePair
                  id={`${val.label}Label`}
                  label={val.label}
                  value={val.value}
                  type={type}
                  size={size}
                  key={`${idx}_${val.label}`}
                />
              );
            })}
          </div>
        );
      })}
    </div>
  );
};

export default DisplayLabelPatch;
