import React, { useState } from 'react';

import UI from 'ielts-cmds-ui-component-library';

import { useAuth0 } from '@auth0/auth0-react';

import styles from './IncidentEditPanel.module.scss';
import {
  getIncidentCatagory,
  incidentSeverityOptions,
  onDropdownFilter,
  getIncidentStatusAccordingToSeverity,
  getIncidentTypeOptionsAccordingToCatagory,
  IncidentCatagory,
  getIncidentStatus,
  getIncidentSeverity,
  IncidentSeverity,
} from '../../../../src/services/API/Reference/Incident';
import { IncidentManagementIncidentDetails } from '../../../services/Models/IncidentManagement';
import withServiceRequest, { ServiceRequest } from '../../../services/utils/ServiceRequest';
import IncidentManagementEvidenceDialog from '../../Others/IncidentManagementEvidenceDialog/IncidentManagementEvidenceDialog';
import { AsyncResponseStatus } from '../../../services/Models/Api';
import { updateIncidentDetails } from '../../../services/API/IncidentManagement/UpdateIncidentDetails';
import { createEvidences, sortEvidenceFiles } from '../IncidentDetailPanel/IncidentDetailPanelHelper';
import GenericPopup, { ButtonPosition, DialogType, TitlePosition } from '../GenericPopup/GenericPopup';
import { UIButtonType, UITypography } from '../../../services/Models/UIModels';
import { languageService } from '../../../services/Language/LanguageService';
import {
  findReportingUser,
  getDateTime,
  getIncidentDetails,
} from '../../../services/API/IncidentManagement/GetIncidentDetailsSearchResult';
import { getIdentityType } from '../../../services/API/Reference/IdentityType';

export interface IncidentDetailsProps {
  incidentDetails: IncidentManagementIncidentDetails;
  index: number;
  serviceRequest: ServiceRequest;
  reload: () => void;
  setEditEnabled: (arg: boolean) => void;
  setSuccessMessage: (arg: boolean) => void;
}

const IncidentEditPanel = (props: IncidentDetailsProps) => {
  const [incidentInfo, setIncidentInfo] = useState(props.incidentDetails);
  const [incidentTypeSearchOptions, setIncidentTypeSearchOptions] = useState(
    getIncidentTypeOptionsAccordingToCatagory(props.incidentDetails.incidentCategoryUuid),
  );
  const [isEvidenceBoxOpen, setEvidenceBox] = useState(false);
  const [confirmUpdate, setConfirmUpdate] = useState(false);
  const [comment, setComment] = useState('');
  const [currentSeverity, setSeverity] = useState(props.incidentDetails.incidentSeverity);
  const [dropdownError, setDropDownError] = useState(false);

  const { user } = useAuth0();

  const incidentManagementLabels = languageService().incidentManagement;

  const handleDropdownChange = (e: { name: string; value: string }) => {
    if (e.name === 'incidentStatusTypeUuid') {
      setDropDownError(false);
    }
    if (e.name === 'incidentSeverity' && e.value !== currentSeverity) {
      setSeverity(e.value);
      setIncidentInfo((preState) => ({ ...preState, [e.name]: e.value, incidentStatusTypeUuid: '' }));
    } else {
      setIncidentInfo((preState) => ({ ...preState, [e.name]: e.value }));
    }
  };

  const getDropDownPlaceholder = (arg: string) => {
    return arg !== '' ? arg : incidentManagementLabels.selectOption;
  };

  const updateHandler = () => {
    if (incidentInfo.incidentStatusTypeUuid === '') {
      setDropDownError(true);
      setConfirmUpdate(false);
      return;
    }
    setConfirmUpdate(true);
  };

  const confirmationHandler = () => {
    updateIncidentDetails(incidentInfo, comment, props.serviceRequest, user).subscribe((res) => {
      if (res && res.status === AsyncResponseStatus.SUCCESS) {
        setConfirmUpdate(false);
        props.setEditEnabled(false);
        props.reload();
        props.setSuccessMessage(true);
      }
    });
  };

  const manageEditConfirmationBox = () => {
    if (confirmUpdate) {
      const buttonData = [
        {
          id: 'abdCancelButton',
          text: incidentManagementLabels.cancel,
          type: UIButtonType.SECONDARY,
          onChange: () => setConfirmUpdate(false),
        },
        {
          id: 'abdConfirmButton',
          text: incidentManagementLabels.confirm,
          type: UIButtonType.PRIMARY,
          onChange: confirmationHandler,
        },
      ];
      return (
        <GenericPopup
          id={'incidentManagementDialog'}
          title={incidentManagementLabels.incidentDetails}
          titlePosition={TitlePosition.DEFAULT}
          buttonStyle={ButtonPosition.RIGHT}
          buttonData={buttonData}
          dialogType={DialogType.CUSTOM}
          modalCloseHandler={() => setConfirmUpdate(false)}
        >
          <div className={styles.popUpMessage}>{incidentManagementLabels.confirmationMessage}</div>
        </GenericPopup>
      );
    }
  };

  const manageEvidenceBox = () => {
    if (isEvidenceBoxOpen) {
      const { audioFiles, videoFiles, documentFiles } = createEvidences(props.incidentDetails.evidences);
      return (
        <IncidentManagementEvidenceDialog
          title={incidentManagementLabels.evidenceDetails}
          modalCloseHandler={() => setEvidenceBox(false)}
          audioFiles={sortEvidenceFiles(audioFiles)}
          videoFiles={videoFiles}
          documentFiles={documentFiles}
          isUpload={true}
        />
      );
    }
  };

  const categoryCheck = (incidentCategoryUuid: string) => {
    switch (incidentCategoryUuid) {
      case IncidentCatagory.MALPRACTICE:
      case IncidentCatagory.ID_CHK_FOLLOW_UP_INC:
      case IncidentCatagory.ID_CHK_REJ_INC:
        return false;
      default:
        return true;
    }
  };

  return (
    <React.Fragment>
      <div className={styles.leftPanelContainer}>
        <div className={styles.ttbhExpandableContainer}>
          <div className={styles.dataLabelClass}>
            <UI.Typography
              type={UITypography.REGULAR}
              label={`${incidentManagementLabels.incident}   ${props.index}`}
              size={20}
              id="title"
            />
          </div>
        </div>
        <div className={styles.ttbhDetailsContainer}>
          <div className={styles.col4}>
            <UI.Dropdown
              id="incidentTypeOptions"
              label={incidentManagementLabels.incidentType}
              className={styles.dropdownContainer}
              selectedValue={incidentInfo.incidentTypeUuid}
              placeholder={getDropDownPlaceholder(getIdentityType(incidentManagementLabels.selectOption))}
              onChange={(value: string) =>
                handleDropdownChange({
                  name: 'incidentTypeUuid',
                  value: value,
                })
              }
              list={incidentTypeSearchOptions}
              showInputWithoutList
              search={incidentInfo.incidentCategoryUuid === IncidentCatagory.MALPRACTICE}
              onSearch={(value: string) =>
                onDropdownFilter(value, incidentInfo.incidentCategoryUuid, setIncidentTypeSearchOptions)
              }
              searchIcon="normal"
              onDropdownClose={() =>
                setIncidentTypeSearchOptions(
                  getIncidentTypeOptionsAccordingToCatagory(incidentInfo.incidentCategoryUuid),
                )
              }
              searchPlaceholderText=""
              disable={
                incidentInfo.incidentCategoryUuid === IncidentCatagory.PRE_RELEASE_CHECK ||
                incidentInfo.incidentCategoryUuid === IncidentCatagory.PLAGIARISM
              }
            />
            <UI.Dropdown
              id="incidentStatusOptions"
              label={incidentManagementLabels.incidentStatus}
              selectedValue={incidentInfo.incidentStatusTypeUuid}
              placeholder={getDropDownPlaceholder(getIncidentStatus(incidentInfo.incidentStatusTypeUuid))}
              onChange={(value: string) =>
                handleDropdownChange({
                  name: 'incidentStatusTypeUuid',
                  value: value,
                })
              }
              list={getIncidentStatusAccordingToSeverity(
                incidentInfo.incidentSeverity,
                props.incidentDetails.incidentStatusTypeUuid,
              )}
              disable={categoryCheck(incidentInfo.incidentCategoryUuid)}
              inputFieldValidation={dropdownError}
              errorMessage={dropdownError ? incidentManagementLabels.dropDownError : undefined}
            />
            <UI.Dropdown
              id="incidentSeverityOptions"
              label={incidentManagementLabels.severity}
              selectedValue={incidentInfo.incidentSeverity}
              placeholder={getDropDownPlaceholder(getIncidentSeverity(incidentInfo.incidentSeverity))}
              onChange={(value: string) =>
                handleDropdownChange({
                  name: 'incidentSeverity',
                  value: value,
                })
              }
              list={incidentSeverityOptions.filter((item) => item.value !== IncidentSeverity.INFO)}
              disable={categoryCheck(incidentInfo.incidentCategoryUuid)}
            />
            <div className={styles.catagoryDisplay}>
              <UI.DisplayLabelValuePair
                id={'incidentCatagory'}
                label={incidentManagementLabels.incidentCatagory}
                value={getIncidentCatagory(incidentInfo.incidentCategoryUuid)}
                type={UITypography.REGULAR}
                size={16}
              />
            </div>
          </div>
          <div className={styles.ttbhDetailsContainerGrid}>
            <div className={styles.col4}>
              <div>
                <UI.DisplayLabelValuePair
                  id={'reportingUser'}
                  label={incidentManagementLabels.reportingUser}
                  value={findReportingUser(props.incidentDetails)}
                  type={UITypography.REGULAR}
                  size={16}
                  className={styles.reportingUser}
                />
              </div>
              <div className={styles.reportTime}>
                <UI.DisplayLabelValuePair
                  id={'reportTime'}
                  label={incidentManagementLabels.reportTime}
                  value={getDateTime(props.incidentDetails)}
                  type={UITypography.REGULAR}
                  size={16}
                />
              </div>
              <div className={styles.borderBox}>
                <span>{incidentManagementLabels.incidentDetails}</span>
                <span className={styles.borderBoxSpan}>{getIncidentDetails(props.incidentDetails)}</span>
              </div>
            </div>
            <UI.Button
              id="evidenceButton"
              color={UIButtonType.BLUELINE}
              label={incidentManagementLabels.viewEvidence}
              onChange={() => setEvidenceBox(true)}
            />
          </div>
          <div className={styles.commentSection}>
            <span className={styles.commentLabel}>{incidentManagementLabels.comments}</span>
            <div className={styles.actualComment}>
              <UI.TextArea
                label={''}
                labelId="comment"
                value={comment}
                name="comment"
                id="comment"
                placeholder={incidentManagementLabels.textAreaPlaceHolder}
                inputType="textArea"
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setComment(e.target.value)}
                maxLength={2000}
              />
            </div>
          </div>
          {manageEvidenceBox()}
          {manageEditConfirmationBox()}
        </div>
      </div>
      <div className={styles.buttonContainer}>
        <UI.Button
          id="editIncidentCancelButton"
          color={UIButtonType.SECONDARY}
          label={incidentManagementLabels.cancel}
          onChange={() => props.setEditEnabled(false)}
        />
        <UI.Button
          id="editIncidentConfirmButton"
          color={UIButtonType.PRIMARY}
          label={incidentManagementLabels.update}
          onChange={updateHandler}
        />
      </div>
    </React.Fragment>
  );
};

export default withServiceRequest(IncidentEditPanel);
