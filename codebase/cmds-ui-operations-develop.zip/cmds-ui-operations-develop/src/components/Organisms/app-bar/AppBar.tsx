import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import { useAuth0 } from '@auth0/auth0-react';

import styles from './AppBar.module.scss';
import profileIcon from '../../../assets/images/Avatar.svg';
import logoutIcon from '../../../assets/images/logout.svg';
import { getValue } from '../../utils/utilities';
import { languageService } from '../../../services/Language/LanguageService';

const AppBar = () => {
  const { user, logout } = useAuth0();

  const commonLabels = languageService().common;

  const getUserName = () => `${getValue(user?.given_name).trim()} ${getValue(user?.family_name).trim()}`;
  return (
    <div className={styles.headerAppComponent}>
      <UI.Header
        title={commonLabels.cmdsPortal}
        profileIcon={user?.picture ? user?.picture : profileIcon}
        userName={getUserName()}
      />
      <div onClick={() => logout()} className={`${styles.tmpButton} ${styles.tooltip}`}>
        <img src={logoutIcon} alt="logout icon" height="28px" />
        <span className={styles.tooltiptext}>{commonLabels.logout}</span>
      </div>
    </div>
  );
};

export default AppBar;
