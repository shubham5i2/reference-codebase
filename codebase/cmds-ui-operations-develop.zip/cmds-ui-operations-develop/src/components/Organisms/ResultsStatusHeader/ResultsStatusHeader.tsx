import React from 'react';
import UI from 'ielts-cmds-ui-component-library';

import styles from './ResultsStatusHeader.module.scss';
import { formatDate, getValue, statusStyle } from '../../../components/utils/utilities';
import { languageService } from '../../../services/Language/LanguageService';
import { ResultsStatusDetail } from '../../../services/Models/Result';

interface ResultsStatusHeaderProps {
  resultsStatusData: ResultsStatusDetail;
}

const ResultsStatusHeader = (props: ResultsStatusHeaderProps) => {
  const resultsStatusLabels = languageService().result;
  return (
    <div className={styles.adContainerResultStatus}>
      <div className={styles.columnHead}>
        <UI.DisplayLabelValuePair
          id="resultsStatusHeaderFirstName"
          label={resultsStatusLabels.firstNameLabel}
          value={props.resultsStatusData.firstName}
          type="regular"
          size={16}
          className={styles.DisplayLabelValuePair}
        />

        <UI.DisplayLabelValuePair
          id="resultsStatusHeaderLastName"
          label={resultsStatusLabels.lastNameLabel}
          value={props.resultsStatusData.lastName}
          type="regular"
          size={16}
          className={styles.DisplayLabelValuePair}
        />

        <UI.DisplayLabelValuePair
          id="resultsStatusHeaderTestCentre"
          label={resultsStatusLabels.testCentreLabel}
          value={props.resultsStatusData.testCentre}
          type="regular"
          size={16}
          className={styles.DisplayLabelValuePair}
        />

        <UI.DisplayLabelValuePair
          id="resultsStatusHeaderTestDate"
          label={resultsStatusLabels.testDateLabel}
          value={formatDate(new Date(props.resultsStatusData.testDate), 'dd MMM yyyy')}
          type="regular"
          size={16}
          className={styles.DisplayLabelValuePair}
        />

        <UI.DisplayLabelValuePair
          id="resultsStatusHeaderTestTakerNumber"
          label={resultsStatusLabels.testTakerNumberLabel}
          value={props.resultsStatusData.shortCandidateNumber}
          type="regular"
          size={16}
          className={styles.DisplayLabelValuePair}
        />

        <UI.DisplayLabelValuePair
          id="resultsStatusHeaderCurrentResultStatus"
          label={resultsStatusLabels.currentResultStatusLabel}
          value={
            <UI.Status
              status={statusStyle[getValue(props.resultsStatusData.resultStatus?.toUpperCase())]}
              label={props.resultsStatusData.resultStatus}
            />
          }
          type="regular"
          size={16}
          className={styles.DisplayLabelValuePair}
        />
      </div>
    </div>
  );
};

export default ResultsStatusHeader;
