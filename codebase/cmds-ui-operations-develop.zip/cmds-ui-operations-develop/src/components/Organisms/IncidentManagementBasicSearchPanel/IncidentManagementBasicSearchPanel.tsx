import React, { useState } from 'react';
import styles from './IncidentManagementSearchPanel.module.scss';
import { BasicSearchDataType } from '../../../services/Models/IncidentManagement';
import UI from 'ielts-cmds-ui-component-library';
import { dateRange } from '../../Pages/Results/ResultsSearchPanel/ResultsSearchPanel';
import * as IncidentManagementActions from '../../../Store/Actions/IncidentManagementActions';
import { languageService } from '../../../services/Language/LanguageService';
import { ServiceRequest } from '../../../services/utils/ServiceRequest';
import ProductDropDown from '../BaseDropDown/ProductDropDown/ProductDropDown';
import { getOptionsList } from '../../utils/utilities';
import { LocationType } from '../LocationDropdown/LocationDropdownUtils';
import LocationDropdown from '../LocationDropdown/LocationDropdown';
import { DropDownDataSource } from '../../../services/Models/UIModels';

interface BasicSearchPanelProps {
  basicSearchData: BasicSearchDataType;
  handleBasicInputChange: (key: string, value: string | dateRange) => void;
  serviceRequest: ServiceRequest;
  fetchProductDataOnLoad?: boolean;
}

interface ISelection {
  selection: dateRange;
}

const IncidentManagementBasicSearchPanel = (props: BasicSearchPanelProps) => {
  const [showCal, setVisibility] = useState(false);
  const incidentManagementLabels = languageService().incidentManagement;
  const onTestCentreChange = (value: DropDownDataSource) => {
    props.handleBasicInputChange('testCentre', value.value);
  };

  const onProductChange = (value: string) => {
    props.handleBasicInputChange('product', value);
  };

  const onDateChange = (startDate: Date, endDate: Date) => {
    props.handleBasicInputChange('dateRange', { startDate, endDate });
    setVisibility(false);
  };
  return (
    <div className={styles.searchBox + ' ' + styles.col3}>
      <div className={styles.dataFieldContainerSec}>
        <div style={{ position: 'relative', minWidth: 329, height: 90 }} className={styles.datePicker}>
          <div className={styles.textBoxLabelSec}>{incidentManagementLabels.dateRangeLabel}*</div>
          <UI.DateRangePicker
            onChange={({ selection: { startDate, endDate } }: ISelection) => onDateChange(startDate, endDate)}
            months={2}
            ranges={[
              {
                startDate: props.basicSearchData?.dateRange?.startDate,
                endDate: props.basicSearchData?.dateRange?.endDate,
                key: 'selection',
              },
            ]}
            direction="horizontal"
            showPreview={true}
            setCalendarVisibility={() => setVisibility(!showCal)}
            showCalendar={showCal}
          />
        </div>
      </div>
      <div className={styles.dataFieldContainer}>
        <div className={styles.textBoxLabel}>{incidentManagementLabels.testCentre}</div>
        <LocationDropdown
          id={'testCentre'}
          isFilterEnabled={true}
          labelText={''}
          locationType={LocationType.TEST_CENTRE}
          dataSource={'getLocations'}
          value={props.basicSearchData?.testCentre}
          onChange={onTestCentreChange}
          getOptionsList={getOptionsList}
        />
      </div>
      <div className={styles.dataFieldContainer}>
        <div className={styles.textBoxLabel}>{incidentManagementLabels.product}</div>
        <ProductDropDown
          id="product"
          actionType={IncidentManagementActions.SAVE_PRODUCTS}
          isFetchDataOnLoad={props.fetchProductDataOnLoad || false}
          isFilterEnabled={false}
          label=""
          labelId="productLB"
          onChange={onProductChange}
          selectedValue={props.basicSearchData?.product}
          serviceRequest={props.serviceRequest}
        />
      </div>
    </div>
  );
};

export default IncidentManagementBasicSearchPanel;
