export enum ResultsGridCellType {
  EXPAND = 'expandBtn',
  UTTID = 'uniqueTestTakerId',
  FIRST_NAME = 'firstName',
  LAST_NAME = 'lastName',
  TEST_DATE = 'testDate',
  TEST_CENTRE = 'testCentre',
  TEST_TAKER_NUMBER = 'shortCandidateNumber',
  RESULTS_STATUS = 'resultStatus',
  MORE = 'moreBtn',
  CHECKBOX = 'checkbox',
}
export enum ResultsGridSortType {
  UTTID = 'uniqueTestTakerId',
  FIRST_NAME = 'firstName',
  LAST_NAME = 'lastName',
  TEST_DATE = 'testDate',
  TEST_CENTRE = 'testCentreUuid',
  TEST_TAKER_NUMBER = 'shortCandidateNumber',
  RESULTS_STATUS = 'resultStatusUuid',
  MORE = 'moreBtn',
}

export const SelectAllInitialData = [{ page: 1, checked: false }];
