import React, { useRef, useState } from 'react';
import { Cell, Column, Row } from 'react-table';
import { addMinutes } from 'date-fns';
import UI from 'ielts-cmds-ui-component-library';

import styles from './ResultsGrid.module.scss';
import ResultsGridCell from '../ResultsGridCell/ResultsGridCell';
import { ResultsGridCellType, ResultsGridSortType } from './ResultsGridConstants';
import ManageUsersActions from '../../Molecules/ManageUsersActions/ManageUsersActions';
import visibilityIcon from '../../../assets/images/visibility.svg';
import ArrowDownIcon from '../../../assets/images/ArrowDown.svg';
import MoreIcon from '../../../assets/images/More.svg';
import EditIcon from '../../../assets/images/Edit.svg';
import TRF from '../../../assets/images/TRF.svg';
import hand from '../../../assets/images/hand.png';
import { languageService } from '../../../services/Language/LanguageService';
import { Action } from '../../../services/Models/Api';
import { UIGridState, UICheckboxChangeEvent, UIButtonType, ExpandedGridType } from '../../../services/Models/UIModels';
import {
  formatDate,
  defaultCheckHandlerForSelectAll,
  gridRowsMatchHandler,
  defaultCheckHandler,
} from '../../../components/utils/utilities';
import { useHistory } from 'react-router-dom';
import HoldOnUpdateDialog from '../../Others/HoldOnUpdateDialog/HoldOnUpdateDialog';
import Tick from '../../../assets/images/Tick.svg';
import { useStateValue } from '../../../Store/helpers/UseStateValue';

import * as ManageResultActions from '../../../Store/Actions/ManageResultActions';
import { Components } from '../../../services/Models/Result';

export interface ColumnSort {
  Header: {
    name: string;
  };
}

interface Scores {
  listening?: number;
  reading?: number;
  writing?: number;
  speaking?: number;
  overall?: number;
}

export interface ResultsGridData {
  bookingUuid?: string;
  lastName?: string;
  firstName?: string;
  identityNumber?: string;
  product?: string;
  resultStatus?: string;
  shortCandidateNumber?: string;
  testCentre?: string;
  testDate?: string;
  uniqueTestTakerId?: string;
  scores?: Scores;
  onHold?: boolean | null;
  idVerificationFlag: boolean;
  resultLineDetails: Components;
}

interface ResultsGridProps {
  data: ResultsGridData[];
  onPageChange: (page: number) => void;
  onPageSizeChange: (value: number) => void;
  gridState: UIGridState;
  pageSizeOptions: { text: string; value: number }[];
  onColumnSort?: (column: ColumnSort) => void;
  sortOption?: { sortType: string; sortBy: string };
  sort?: boolean;
  isLoading?: boolean;
}

enum actionType {
  VIEW_DETAILS,
  UPDATE,
  INITIATE_EOR,
  PRINT_TRF,
  UPDATE_ON_HOLD,
  ID_VERIFICATION,
}

const ResultsGrid = (props: ResultsGridProps) => {
  const userActionsContainerRef = useRef() as React.RefObject<HTMLDivElement>;
  const [selectedToolTipIndex, setSelectedToolTipIndex] = useState<number | null>(null);
  const resultsLabels = languageService().result;
  const history = useHistory();
  const [bookingIdx, setBookingIdx] = useState(-1);
  const { state, dispatch } = useStateValue();
  const [updateOnholdMultiple, setUpdateOnholdMultiple] = useState(-1);

  const actions = [
    { label: resultsLabels.viewDetails, type: actionType.VIEW_DETAILS, icon: visibilityIcon },
    { label: resultsLabels.updateStatus, type: actionType.UPDATE, icon: EditIcon },
    { label: resultsLabels.updateOnHold, type: actionType.UPDATE_ON_HOLD, icon: hand },
    { label: resultsLabels.viewTRF, type: actionType.PRINT_TRF, icon: TRF },
    { label: resultsLabels.idVerification, type: actionType.ID_VERIFICATION, icon: Tick },
  ];

  const getActions = (idVerificationFlag: boolean) => {
    let actionList = [...actions];
    if (!idVerificationFlag) {
      actionList = actionList.filter((item) => item.type !== actionType.ID_VERIFICATION);
    }
    return actionList;
  };

  const moreClickHandler = (props: Row) => {
    if (selectedToolTipIndex === props.index) {
      setSelectedToolTipIndex(null);
    } else {
      setSelectedToolTipIndex(props.index);
    }
  };

  const actionsHandler = (action: Action, index: number) => {
    setSelectedToolTipIndex(null);
    switch (+action.type) {
      case actionType.VIEW_DETAILS:
        history.push(`results/viewTestTakerDetails/${props.data[index].bookingUuid}`, {
          selectedBookingUuid: props.data[index].bookingUuid,
          productName: props.data[index].product,
        });
        break;
      case actionType.UPDATE:
        history.push(`results/updateresultstatus/${props.data[index].bookingUuid}`, {
          resultsStatusData: props.data[index],
        });
        break;
      case actionType.UPDATE_ON_HOLD:
        setBookingIdx(index);
        break;
      case actionType.PRINT_TRF:
        history.push(`results/downloadtrf/${props.data[index].bookingUuid}`);
        break;

      case actionType.ID_VERIFICATION:
        history.push(
          `incidentmanagement/incidentmanagementviewdetails/incidentmanagementidverification/${props.data[index].bookingUuid}`,
        );
        break;
      default:
        break;
    }
  };
  const getHoldOnUpdateModal = () => {
    return bookingIdx >= 0 || updateOnholdMultiple > 0 ? (
      <HoldOnUpdateDialog
        id="holdOnupdateDialogComponent"
        title={resultsLabels.updateOnHoldTitleText}
        label={resultsLabels.updateOnHoldLabelText}
        data={updateOnholdMultiple > 0 ? state.manageResult.selectedBookings : props.data[bookingIdx]}
        modalCloseHandler={() => (updateOnholdMultiple > 0 ? setUpdateOnholdMultiple(-1) : setBookingIdx(-1))}
      />
    ) : null;
  };
  const bookingSelectionHandler = (index: number) => {
    dispatch({ type: ManageResultActions.SET_SELECT_ALL_CHECKBOX_STATUS, payload: false });
    const idx = state.manageResult.selectedBookings.findIndex(function (item: ResultsGridData) {
      return item.bookingUuid === props.data[index].bookingUuid;
    });

    let selectedBooking = state.manageResult.selectedBookings;
    if (idx >= 0) {
      selectedBooking.splice(idx, 1);
      dispatch({ type: ManageResultActions.SELECT_BOOKING, payload: [...selectedBooking] });
    } else {
      selectedBooking = [...state.manageResult.selectedBookings, props.data[index]];
      dispatch({ type: ManageResultActions.SELECT_BOOKING, payload: [...selectedBooking] });
    }
  };

  const selectAllHandler = (e: UICheckboxChangeEvent) => {
    dispatch({ type: ManageResultActions.SELECT_ALL_BOOKING, payload: e.checked });
    dispatch({ type: ManageResultActions.SET_SELECT_ALL_CHECKBOX_STATUS, payload: e.checked });
  };

  const getResultGridItem = (cellProps: Cell, name: string) => {
    return <ResultsGridCell id={name} cellType={name} value={cellProps.value} />;
  };

  const getGridItemMore = (cellProps: Cell) => {
    const isMoreSelected = selectedToolTipIndex === cellProps.row.index;
    const moreSelectedClass = isMoreSelected ? styles.userActionsOpened : '';
    return (
      <div
        id="actionsContainer"
        ref={userActionsContainerRef}
        className={`${styles.userActionsContainer} ${moreSelectedClass}`}
      >
        <ResultsGridCell
          id={ResultsGridCellType.MORE}
          cellType={ResultsGridCellType.MORE}
          value={cellProps.value}
          icon={MoreIcon}
          onChangeHandler={() => moreClickHandler(cellProps.row)}
        />
        {isMoreSelected ? (
          <ManageUsersActions
            id={'actionsContainer'}
            userActions={getActions(props.data[cellProps.row.index].idVerificationFlag)}
            userActionsClickHandler={(action: Action) => actionsHandler(action, cellProps.row.index)}
          />
        ) : null}
      </div>
    );
  };
  const columns = [
    {
      id: 'checkbox',
      Header: {
        label: (
          <UI.CheckBox
            id={'checkBox_select_all'}
            checked={defaultCheckHandlerForSelectAll(
              state.manageResult.searchData.selectedPage.page,
              state.manageResult.selectAllStatus,
            )}
            onChange={(e: UICheckboxChangeEvent) => selectAllHandler(e)}
          />
        ),
      },
      Cell: ({ row }: any) => {
        const index = row.index;

        return (
          <ResultsGridCell
            id={'checkbox'}
            cellType={ResultsGridCellType.CHECKBOX}
            defaultCheck={defaultCheckHandler(state.manageResult.selectedBookings, props.data, 'bookingUuid', index)}
            onChangeHandler={() => bookingSelectionHandler(index)}
          />
        );
      },
      disableSortBy: true,
    },
    {
      id: 'expander',
      Cell: (
        { row }: any, // : cannot find required fields in provided type definitions..
      ) => (
        <span {...row.getToggleRowExpandedProps()}>
          {
            <ResultsGridCell
              id={ResultsGridCellType.EXPAND}
              cellType={ResultsGridCellType.EXPAND}
              icon={ArrowDownIcon}
              isExpanded={row.isExpanded}
            />
          }
        </span>
      ),
    },
    {
      Header: {
        label: resultsLabels.uniqueTestTakerIdLabel.toUpperCase(),
        name: ResultsGridSortType.UTTID,
      },
      accessor: ResultsGridCellType.UTTID,
      Cell: (cellProps: Cell) => getResultGridItem(cellProps, ResultsGridCellType.UTTID),
    },
    {
      Header: {
        label: resultsLabels.firstNameLabel.toUpperCase(),
        name: ResultsGridSortType.FIRST_NAME,
      },
      accessor: ResultsGridCellType.FIRST_NAME,
      sortType: 'basic',
      Cell: (cellProps: Cell) => getResultGridItem(cellProps, ResultsGridCellType.FIRST_NAME),
    },
    {
      Header: {
        label: resultsLabels.lastNameLabel.toUpperCase(),
        name: ResultsGridSortType.LAST_NAME,
      },
      accessor: ResultsGridCellType.LAST_NAME,
      Cell: (cellProps: Cell) => getResultGridItem(cellProps, ResultsGridCellType.LAST_NAME),
    },
    {
      Header: {
        label: resultsLabels.testDateLabel.toUpperCase(),
        name: ResultsGridSortType.TEST_DATE,
      },
      accessor: ResultsGridCellType.TEST_DATE,
      Cell: (cellProps: Cell) => {
        // Show date in UTC by compensating offset
        let date = new Date(cellProps.value);
        date = addMinutes(date, date.getTimezoneOffset());
        return (
          <ResultsGridCell
            id={ResultsGridCellType.TEST_DATE}
            cellType={ResultsGridCellType.TEST_DATE}
            value={formatDate(date, 'dd MMM yyyy')}
          />
        );
      },
    },
    {
      Header: {
        label: resultsLabels.testCentreLabel.toUpperCase(),
        name: ResultsGridSortType.TEST_CENTRE,
      },
      accessor: ResultsGridCellType.TEST_CENTRE,
      Cell: (cellProps: Cell) => getResultGridItem(cellProps, ResultsGridCellType.TEST_CENTRE),
    },
    {
      Header: {
        label: resultsLabels.testTakerNumberLabel.toUpperCase(),
        name: ResultsGridSortType.TEST_TAKER_NUMBER,
      },
      accessor: ResultsGridCellType.TEST_TAKER_NUMBER,
      Cell: (cellProps: Cell) => getResultGridItem(cellProps, ResultsGridCellType.TEST_TAKER_NUMBER),
    },
    {
      Header: {
        label: resultsLabels.resultsStatusLabel.toUpperCase(),
        name: ResultsGridSortType.RESULTS_STATUS,
      },
      accessor: ResultsGridCellType.RESULTS_STATUS,
      Cell: (cellProps: Cell) => (
        <ResultsGridCell
          id={ResultsGridCellType.RESULTS_STATUS}
          cellType={ResultsGridCellType.RESULTS_STATUS}
          value={cellProps.value}
          onHoldStatus={props.data[cellProps.row.index].onHold}
        />
      ),
    },
    {
      id: 'More',
      Cell: (cellProps: Cell) => getGridItemMore(cellProps),
      disableSortBy: true,
    },
  ] as Column[];

  const renderExpandedRowItems = (row: ExpandedGridType) => (
    <tr id="expandedRow" className={styles.expandedRow}>
      <td colSpan={2}>
        <span className={[styles.expandableCell, styles.firstCol].join(' ')}>
          <span>
            <b>{resultsLabels.idDocumentNumberLabel}</b>
          </span>
          <span>{row.rowData.identityNumber}</span>
        </span>
      </td>
      <td>
        <span className={styles.expandableCell}>
          <span>
            <b>{resultsLabels.productLabel}</b>
          </span>
          <span>{row.rowData.product}</span>
        </span>
      </td>
      <td>
        <span className={styles.expandableCell}>
          <span>
            <b>{resultsLabels.scoreOverallLabel}</b>
          </span>
          <span>{row.rowData.resultLineDetails.overall !== null ? row.rowData.resultLineDetails.overall : '-'}</span>
        </span>
      </td>
      <td>
        <span className={styles.expandableCell}>
          <span>
            <b>{resultsLabels.scoreListeningLabel}</b>
          </span>
          <span>
            {row.rowData.resultLineDetails.listening !== null ? row.rowData.resultLineDetails.listening : '-'}
          </span>
        </span>
      </td>
      <td>
        <span className={styles.expandableCell}>
          <span>
            <b>{resultsLabels.scoreReadingLabel}</b>
          </span>
          <span>{row.rowData.resultLineDetails.reading !== null ? row.rowData.resultLineDetails.reading : '-'}</span>
        </span>
      </td>
      <td>
        <span className={styles.expandableCell}>
          <span>
            <b>{resultsLabels.scoreWritingLabel}</b>
          </span>
          <span>{row.rowData.resultLineDetails.writing !== null ? row.rowData.resultLineDetails.writing : '-'}</span>
        </span>
      </td>
      <td>
        <span className={styles.expandableCell}>
          <span>
            <b>{resultsLabels.scoreSpeakingLabel}</b>
          </span>
          <span>{row.rowData.resultLineDetails.speaking !== null ? row.rowData.resultLineDetails.speaking : '-'}</span>
        </span>
      </td>
      <td></td>
    </tr>
  );
  return (
    <div id="resultsGridContainer" className={styles.grid}>
      {getHoldOnUpdateModal()}
      <UI.ExpandableGrid
        id="resultsGrid"
        columns={columns}
        data={props.data}
        initialState={props.gridState.initialState}
        onPageChange={props.onPageChange}
        onPageSizeChange={props.onPageSizeChange}
        totalRecords={props.gridState.totalRecords}
        currentPage={props.gridState.selectedPage}
        pageSizeOptions={props.pageSizeOptions}
        expandedGrid={renderExpandedRowItems}
        selectedOptionValue={props.gridState.selectedOptionValue}
        onColumnSort={props.onColumnSort}
        sortOption={props.sortOption}
        sort={props.sort}
        isLoading={props.isLoading}
      />
      <div className={styles.buttonContainer}>
        <UI.Button
          label={resultsLabels.updateOnHold}
          color={UIButtonType.PRIMARY}
          id="updateOnHoldFlag"
          disabled={state.manageResult.selectedBookings.length < 2}
          onChange={() => setUpdateOnholdMultiple(1)}
        />
        <div className={styles.updateResultStatusBtn}>
          <UI.Button
            label={resultsLabels.resultUpdateStatus}
            color="secondary"
            id="updateResultStatus"
            disabled={!gridRowsMatchHandler(state.manageResult.selectedBookings, 'resultStatus')}
            onChange={() => {
              history.push(`results/updateresultsstatus`);
            }}
          />
        </div>
      </div>
    </div>
  );
};

export default ResultsGrid;
