import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import styles from './GenericPopup.module.scss';
import CloseIcon from '../../../assets/images/Close.svg';
import { UIButtonType } from '../../../services/Models/UIModels';

export enum DialogType {
  BASIC = 'basic',
  CUSTOM = 'custom',
}

export enum ButtonPosition {
  DEFAULT = 'center',
  LEFT = 'left',
  RIGHT = 'right',
}

export enum TitlePosition {
  DEFAULT = 'left',
  CENTER = 'center',
}

// Added seperate props for dynamic buttons
export type ButtonProp = {
  id: string;
  text: string;
  type: UIButtonType;
  onChange?: () => void;
};

export interface DialogProps {
  id: string;
  title: string;
  label?: string;
  titlePosition?: TitlePosition;
  buttonStyle?: ButtonPosition;
  dialogType?: DialogType;
  buttonData: ButtonProp[];
  className?: string;
  modalCloseHandler: () => void;
  children?: React.ReactNode | React.ReactNode[];
}

const GenericPopup = (props: DialogProps) => {
  const { className = styles.defaultSize } = props;
  const getDialogHeader = () => {
    return (
      <div id={props.id} className={styles.topContentContainer}>
        <img id="closeIcon" alt="" src={CloseIcon} className={styles.closeButton} onClick={props.modalCloseHandler} />
        <h1 id="title" className={props.titlePosition ? styles[props.titlePosition] : styles.left}>
          {props.title}
        </h1>
      </div>
    );
  };

  const getDialogContent = () => {
    return (
      <div className={styles.modalContent}>
        {props.dialogType === DialogType.BASIC && <p id="label">{props.label}</p>}
        {props.dialogType === DialogType.CUSTOM && (
          <div>
            <p id="label">{props.label}</p>
            {props.children}
          </div>
        )}
      </div>
    );
  };

  const getDialogFooter = () => {
    return (
      <div
        id="actionButtonHolder"
        className={` ${styles.actionButtonContainer} ${props.buttonStyle ? styles[props.buttonStyle] : styles.center}`}
      >
        {props.buttonData.map((data) => (
          <UI.Button
            key={data.id}
            id={data.id}
            label={data.text}
            color={data.type}
            onChange={data.onChange}
          ></UI.Button>
        ))}
      </div>
    );
  };

  return (
    <UI.ModalDialog
      id={props.id}
      titlePosition={props.titlePosition}
      buttonStyle={props.buttonStyle}
      modalCloseHandler={props.modalCloseHandler}
      dialogType={props.dialogType}
    >
      <div className={`${styles.genericDialog} ${className}`}>
        {getDialogHeader()}
        {getDialogContent()}
        {getDialogFooter()}
      </div>
    </UI.ModalDialog>
  );
};

export default GenericPopup;
