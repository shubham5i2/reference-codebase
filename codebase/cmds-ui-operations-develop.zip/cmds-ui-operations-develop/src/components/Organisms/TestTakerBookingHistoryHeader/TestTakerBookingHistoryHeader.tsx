import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import Info from '../../../assets/images/Group.svg';

import styles from './TestTakerBookingHistoryHeader.module.scss';
import AddBanIcon from '../../../assets/images/AddBan.png';

export interface TestTakerBookingHistoryHeaderProps {
  uniqueTestTakerId: string;
  uniqueTestTakerUuid: string;
  ttbhSubTitle: string;
  ttbhTitle: string;
  ttbhLabel: string;
  ttbhBanDetailsLabel: string;
  changeTabHandler?: (e: React.MouseEvent<HTMLElement>, id?: string) => void;
  isTtbhClickable?: boolean;
  isTtbhBanDetailsClickable?: boolean;
  isTestTakerBanned: boolean;
  addBanClickHandler: (e: React.MouseEvent<HTMLElement>) => void;
  isAddBanClicked: boolean;
}

const TestTakerBookingHistoryHeader: React.FC<TestTakerBookingHistoryHeaderProps> = (
  props: TestTakerBookingHistoryHeaderProps,
) => {
  const getBanIcon = () => {
    return <img alt="info" src={Info} className={styles.ttbhBanIcon} />;
  };

  return (
    <React.Fragment>
      <div className={styles.ttbhContainer}>
        <div className={styles.ttbhTitleContainer}>
          <div className={styles.ttbhTitle}>
            {props.ttbhTitle} {props.uniqueTestTakerId}
            {/* Banned tag */}
            {props.isTestTakerBanned ? <div className={styles.bannedTtTag}>Banned</div> : ''}
            {/* add new ban icon */}
            <div className={styles.banContainerAddBanIcon}>
              <button id={styles.addBanBtn} onClick={(e) => props.addBanClickHandler(e)}>
                <img className={styles.addBanIcon} alt="" src={AddBanIcon} />
                <span id={styles.addBanLabel}>Add Ban</span>
              </button>
            </div>
          </div>

          <div className={styles.ttbhSubTitle}>{props.ttbhSubTitle}</div>
        </div>

        <UI.Tabs
          initialActiveTab={props.ttbhLabel}
          id={props.uniqueTestTakerUuid}
          changeTabHandler={props.changeTabHandler}
          tabBtnStyle={styles.ttbhCnameTabBtn}
          buttonStyle={styles.ttbhCnameBtn}
          activeBtnStyle={props.isAddBanClicked ? '' : styles.ttbhCnameBtnActive}
        >
          <UI.Tab label={props.ttbhLabel} isClickable={props.isTtbhClickable} />
          <UI.Tab
            label={props.ttbhBanDetailsLabel}
            isClickable={props.isTtbhBanDetailsClickable}
            icon={props.isTestTakerBanned ? getBanIcon() : ''}
          />
        </UI.Tabs>
      </div>
    </React.Fragment>
  );
};

export default TestTakerBookingHistoryHeader;
