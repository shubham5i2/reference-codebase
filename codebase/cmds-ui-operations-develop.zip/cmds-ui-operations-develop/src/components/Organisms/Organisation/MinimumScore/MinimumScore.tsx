import React from 'react';
import styles from './MinimumScore.module.scss';
import UI from 'ielts-cmds-ui-component-library';
import MinimumScoreTab from '../../../Molecules/MinimumScore/MinimumScore';
import { languageService } from '../../../../services/Language/LanguageService';
import {
  OrganisationFormType,
  OrganisationFromInputChangeEvent,
  MinimumScoreData,
  MinimumScoreProductData,
} from '../../../../services/Models/Organisation';

interface MinimumScoreProps {
  minimumScore: MinimumScoreData;
  onChange: (event: OrganisationFromInputChangeEvent) => void;
}

const MinimumScore = (props: MinimumScoreProps) => {
  const { minimumScore, onChange } = props;
  const organisationLabels = languageService().organisation;

  const handleChange = (product: MinimumScoreProductData) => {
    const event: OrganisationFromInputChangeEvent = {
      formtype: OrganisationFormType.MINIMUM_SCORE_FORM,
      target: {
        name: product.value,
        value: product,
      },
    };
    onChange(event);
  };

  const tabPanel = (productKey: string) => {
    const product = minimumScore[productKey];
    return (
      <div className={styles.tabDataContainer} title={product.tabText}>
        <div className={styles.overallScoreData}>
          <UI.Dropdown
            id={`overallScore`}
            label={organisationLabels.overAllScoreLabel}
            labelId="overallScoreLB"
            className={styles.scoreDropdown}
            selectedValue={product.overallScore.actualScore?.value}
            list={product.overallScore.scoreOptions}
            placeholder={organisationLabels.pleaseSelectPlaceHolder}
            onChange={(value: string, text: string) =>
              handleChange({
                ...product,
                overallScore: {
                  ...product.overallScore,
                  actualScore: { value, text },
                },
              })
            }
          />
        </div>
        <div className={styles.otherScoreData}>
          <div className={styles.otherScore}>
            <UI.Dropdown
              id={`listening`}
              label={organisationLabels.listeningLabel}
              labelId="listeningLB"
              className={styles.scoreDropdown}
              selectedValue={product.listening.actualScore?.value}
              list={product.listening.scoreOptions}
              placeholder={organisationLabels.pleaseSelectPlaceHolder}
              onChange={(value: string, text: string) =>
                handleChange({
                  ...product,
                  listening: {
                    ...product.listening,
                    actualScore: { value, text },
                  },
                })
              }
            />
          </div>
          <div className={styles.otherScore}>
            <UI.Dropdown
              id={`reading`}
              label={organisationLabels.readingLabel}
              className={styles.scoreDropdown}
              labelId="readingLB"
              selectedValue={product.reading.actualScore?.value}
              list={product.reading.scoreOptions}
              placeholder={organisationLabels.pleaseSelectPlaceHolder}
              onChange={(value: string, text: string) =>
                handleChange({
                  ...product,
                  reading: {
                    ...product.reading,
                    actualScore: { value, text },
                  },
                })
              }
            />
          </div>
          <div className={styles.otherScore}>
            <UI.Dropdown
              id={`writing`}
              label={organisationLabels.writingLabel}
              labelId="writingLB"
              className={styles.scoreDropdown}
              selectedValue={product.writing.actualScore?.value}
              list={product.writing.scoreOptions}
              placeholder={organisationLabels.pleaseSelectPlaceHolder}
              onChange={(value: string, text: string) =>
                handleChange({
                  ...product,
                  writing: {
                    ...product.writing,
                    actualScore: { value, text },
                  },
                })
              }
            />
          </div>
          <div className={styles.otherScore}>
            <UI.Dropdown
              id={`speaking`}
              label={organisationLabels.speakingLabel}
              labelId="speakingLB"
              className={styles.scoreDropdown}
              selectedValue={product.speaking.actualScore?.value}
              list={product.speaking.scoreOptions}
              placeholder={organisationLabels.pleaseSelectPlaceHolder}
              onChange={(value: string, text: string) =>
                handleChange({
                  ...product,
                  speaking: {
                    ...product.speaking,
                    actualScore: { value, text },
                  },
                })
              }
            />
          </div>
        </div>
      </div>
    );
  };

  const handleTabChange = (selectedIndex: number) => {
    Object.keys(minimumScore).forEach((productKey, index) => {
      handleChange({
        ...minimumScore[productKey],
        isCurrentSelectedTab: selectedIndex === index,
      });
    });
  };

  return (
    <div className={styles.tabContainer}>
      <MinimumScoreTab
        selected={0}
        tabContainerStyle={styles.minimumScoreTabContainer}
        panelHolderStyle={styles.panelHolderStyle}
        onTabIndexChange={handleTabChange}
      >
        {Object.keys(minimumScore).map((productkey: string) => tabPanel(productkey))}
      </MinimumScoreTab>
    </div>
  );
};

export default MinimumScore;
