import React, { useState, SyntheticEvent, useEffect, useRef } from 'react';
import styles from './OrganisationProfile.module.scss';
import UI from 'ielts-cmds-ui-component-library';
import DynamicTextBox from '../../../Molecules/DynamicTextBox/DynamicTextBox';
import OrganisationAddressForm from '../../../Molecules/OrganisationAddressForm/OrganisationAddressForm';
import {
  getKey,
  maxCount,
  flattenAddressValidationObj,
  useEffectUpdate,
  getTargetObject,
} from '../../../utils/utilities';
import cx from 'classnames';
import { languageService } from '../../../../services/Language/LanguageService';
import {
  UICheckboxChangeEvent,
  Dictionary,
  MultiDropDownDataSource,
  DropDownDataSource,
} from '../../../../services/Models/UIModels';
import {
  OrganisationFormType,
  OrganisationFromInputChangeEvent,
  OrganisationProfileData,
  OrganisationFromData,
  OrganisationFormAction,
  OrganisationAlternateNameResponse,
  OrganisationType,
  NOTES_TYPE_UUID,
} from '../../../../services/Models/Organisation';
import withServiceRequest, { ServiceRequest } from '../../../../services/utils/ServiceRequest';
import PartnerDropDown from '../../BaseDropDown/PartnerDropDown/PartnerDropDown';
import { OrganisationFormRule, isOrgTypeRo } from '../../../utils/ValidationRules/OrganisationAddForm';
import {
  initialDropDownDataSource,
  noOfYears,
  initialMultiDropDownDataSource,
  BASE_VERIFICATION_STATUS,
} from '../../../Templates/Organisation/OrganisationConstants';
import ParentOrganisation from './ParentOrganisation';
import AdditionalDeliveryOrganisationDropDown from '../../BaseDropDown/AdditionalDeliveryOrganisationDropDown/AdditionalDeliveryOrganisationDropDown';
import OrganisationDetailsModal from '../../../Pages/OrganisationDetailsModal/OrganisationDetailsModal';
import { getParentOrganisation } from '../../../../services/API/Organisation/ParentOrganisation';
import { AsyncResponseStatus } from '../../../../services/Models/Api';
import { TOGGLESWITCH, ACTIVESWITCH } from '../../../../constants/UiConstants';
import { EDELIVERY_MOD, POSTAL_MOD } from '../../../../constants/Organisation';
import ReferenceDropdown from '../../ReferenceDropdown/ReferenceDropdown';
import { getDefaultReferenceDropdownProps } from '../../ReferenceDropdown/ReferenceDropdownPropsHelper';
import { ReferenceDropdownType } from '../../ReferenceDropdown/UseReferenceFetch';

interface OrganisationProfileProps {
  organisationDetails: OrganisationProfileData;
  onChange: (event: OrganisationFromInputChangeEvent) => void;
  error: Dictionary;
  serviceRequest: ServiceRequest;
  orgProfileRule: OrganisationFormRule;
  orgFormAction: OrganisationFormAction;
  setOrganisationForm: (formType: OrganisationFormType, updatedState: Dictionary) => void;
}

type OrganisationProfileEvent = SyntheticEvent | { target: OrganisationFromData };
const currentFormType = OrganisationFormType.PROFILE_FORM;
const defaultParentNotFound = { text: '', isError: false };

const OrganisationProfile = (props: OrganisationProfileProps) => {
  const { organisationDetails, onChange, error, orgProfileRule, orgFormAction } = props;
  const { notes } = organisationDetails;
  const [displayDelivery, setDisplayDelivery] = useState(false);
  const isOrgTypeSelectionTriggered = useRef(false);
  const organisationLabels = languageService().organisation;

  const [showParentModal, setShowParentModal] = useState(false);
  const [parentNotFound, setParentNotFound] = useState(defaultParentNotFound);
  const [isParentLoading, setParentLoading] = useState(false);

  const acceptAC = organisationDetails.acceptAC;
  const acceptGT = organisationDetails.acceptGT;

  const linkClickHandle = () => {
    setShowParentModal(true);
  };

  const handleBlur = () => {
    setParentNotFound(defaultParentNotFound);
    setParentLoading(true);
    if (organisationDetails.parentOrganisationId) {
      getParentOrganisation(props.serviceRequest, organisationDetails.parentOrganisationId).subscribe((data) => {
        setParentLoading(false);
        const parentOrgData = data.parentOrganisationData || [];
        if (data.status === AsyncResponseStatus.SUCCESS && parentOrgData.length > 0) {
          // If the parent org type not matches with org type throw error
          if (parentOrgData[0].organisationTypeUuid !== organisationDetails.organisationType.value) {
            setParentNotFound({
              text: `Please enter a valid ${organisationDetails.organisationType.text} ID `,
              isError: true,
            });
            return;
          }
          const updatedState = {
            [currentFormType]: {
              ...organisationDetails,
              parentOrganisationUuid: parentOrgData[0].recognisingOrganisationUuid,
              parentOrganisationName: parentOrgData[0].name,
            },
          };
          props.setOrganisationForm(currentFormType, updatedState);
        } else {
          initialValueParentAddDelOrg();
          setParentNotFound({ text: organisationLabels.noResultsFoundTitle, isError: false });
        }
      });
    } else {
      initialValueParentAddDelOrg();
    }
  };

  useEffect(() => {
    setDisplayDelivery(organisationDetails.deliveryAddress.isRequired);
  }, [organisationDetails.deliveryAddress]);

  useEffectUpdate(() => {
    if (isOrgTypeSelectionTriggered.current) {
      handleChange(getTargetObject('verificationStatus', initialDropDownDataSource, ''));
      handleChange(getTargetObject('methodOfDelivery', initialDropDownDataSource, ''));
      if (
        orgFormAction === OrganisationFormAction.ADD &&
        organisationDetails.organisationType.value === OrganisationType.VO
      ) {
        initialValueParentAddDelOrg({
          additionalDeliveryOrganisation: initialMultiDropDownDataSource,
          parentOrganisationId: '',
        });
      }
      let event: OrganisationFromInputChangeEvent;

      if (organisationDetails.organisationType.value === OrganisationType.RO) {
        event = {
          formtype: currentFormType,
          target: {
            name: 'ieltsDisplayFlag',
            value: true,
          },
        };
        onChange(event);
        event = {
          formtype: OrganisationFormType.PROFILE_FORM,
          target: {
            name: 'orsDisplayFlag',
            value: true,
          },
        };
        onChange(event);
      } else if (organisationDetails.organisationType.value === OrganisationType.VO) {
        event = {
          formtype: OrganisationFormType.PROFILE_FORM,
          target: {
            name: 'orsDisplayFlag',
            value: true,
          },
        };
        onChange(event);
        event = {
          formtype: currentFormType,
          target: {
            name: 'ieltsDisplayFlag',
            value: false,
          },
        };
        onChange(event);
      }
    }
  }, [organisationDetails.organisationType]);

  // Gives the verification status list based on the organisation type selected
  const getVerificationStatusList = (orgTypeUuid: string) => {
    return BASE_VERIFICATION_STATUS.filter(({ value }) => {
      if (!isOrgTypeRo(orgTypeUuid)) {
        return value !== 'APPROVED'; // Remove approved for VO
      } else if (
        orgFormAction === OrganisationFormAction.UPDATE &&
        organisationDetails.verificationStatus.value === 'APPROVED' &&
        organisationDetails.organisationStatus
      ) {
        return value !== 'VERIFIED'; // Removes verfied when organisation is Approved and active
      }
      return true;
    });
  };

  // Gives the verification status list based on the organisation type selected
  const getMethodOfDeliveryList = (orgTypeUuid: string) => {
    const baseVerificationStatus = [POSTAL_MOD];
    isOrgTypeRo(orgTypeUuid) && baseVerificationStatus.splice(1, 0, EDELIVERY_MOD);
    return baseVerificationStatus;
  };

  const handleNoteChange = (noteChange: SyntheticEvent) => {
    const inputEvent = noteChange as SyntheticEvent;
    const inputTarget = inputEvent.target as HTMLInputElement;
    let value = undefined;
    const notes = organisationDetails.notes || [];
    if (notes.length === 0) {
      value = [
        {
          noteContent: inputTarget.value,
          noteTypeUuid: NOTES_TYPE_UUID,
        },
      ];
    } else {
      // Update the last note with the updated content
      value = notes.map((note, idx) =>
        idx === notes.length - 1
          ? {
              ...note,
              noteContent: inputTarget.value,
            }
          : note,
      );
    }
    onChange({
      formtype: currentFormType,
      target: {
        name: inputTarget.name,
        value,
      },
    });
  };

  const initialValueParentAddDelOrg = (restState = {}) => {
    const updatedState = {
      [currentFormType]: {
        ...organisationDetails,
        parentOrganisationUuid: '',
        parentOrganisationName: '',
        ...restState,
      },
    };
    props.setOrganisationForm(currentFormType, updatedState);
  };

  const handleChange = (changeEvent: OrganisationProfileEvent) => {
    const dropdownAddressEvent = changeEvent.target as OrganisationFromData;
    let event: OrganisationFromInputChangeEvent;
    if (dropdownAddressEvent.dropdownText || dropdownAddressEvent.addressName) {
      event = {
        formtype: currentFormType,
        target: dropdownAddressEvent,
      };
    } else {
      const inputEvent = changeEvent as SyntheticEvent;
      const inputTarget = inputEvent.target as HTMLInputElement;
      const value =
        inputTarget.name === 'acceptIOL' ||
        inputTarget.name === 'organisationStatus' ||
        inputTarget.name === 'orsDisplayFlag' ||
        inputTarget.name === 'ieltsDisplayFlag' ||
        inputTarget.name === 'acceptSSR' ||
        inputTarget.name === 'acceptAC' ||
        inputTarget.name === 'acceptGT'
          ? inputTarget.checked
          : inputTarget.value;
      event = {
        formtype: currentFormType,
        target: {
          name: inputTarget.name,
          value,
        },
      };
    }
    onChange(event);
  };
  return (
    <div className={styles.ogProfileContainer}>
      {showParentModal && (
        <OrganisationDetailsModal
          parentOrgId={organisationDetails.parentOrganisationUuid}
          onDialogClose={() => setShowParentModal(false)}
        />
      )}
      <div className={cx(styles.col3, styles.ogFormGrid, styles.ogGridPadding)}>
        {orgFormAction === OrganisationFormAction.UPDATE && (
          <UI.TextBox
            label="Organisation ID*"
            labelId="organisationIdLB"
            value={organisationDetails.organisationId || 12345}
            name="organisationId"
            id="organisationId"
            placeholder="Please enter organisation ID"
            onChange={handleChange}
            inputDisabled={true}
          />
        )}
        <UI.TextBox
          label={organisationLabels.organisationName}
          labelId="organisationNameLB"
          value={organisationDetails.organisationName}
          inputFieldValidation={error.organisationName}
          name="organisationName"
          id="organisationName"
          placeholder=" "
          mandatory={true}
          onChange={handleChange}
        />
        <ReferenceDropdown
          {...getDefaultReferenceDropdownProps({
            dropdownConfig: {
              inputFieldValidationError: error.organisationType,
            },
            dropdownType: ReferenceDropdownType.ORGANISATION_TYPE,
            value: organisationDetails.organisationType.value,
            onChange: ({ value, text }: DropDownDataSource) => {
              isOrgTypeSelectionTriggered.current = true;
              handleChange({
                target: {
                  name: 'organisationType',
                  value: { value, text },
                  dropdownText: text,
                },
              });
            },
          })}
        />

        <UI.Dropdown
          id={`verificationStatus`}
          label={organisationLabels.verficationStatus}
          labelId="verificationStatusLB"
          placeholder={organisationLabels.pleaseSelectPlaceHolder}
          mandatory={true}
          selectedValue={organisationDetails.verificationStatus.value}
          list={getVerificationStatusList(organisationDetails.organisationType.value)}
          disable={!organisationDetails.organisationType?.value}
          inputFieldValidation={error.verificationStatus}
          onChange={(value: string, text: string) =>
            handleChange({
              target: {
                name: 'verificationStatus',
                value: { value, text },
                dropdownText: text,
              },
            })
          }
        />
        <ParentOrganisation
          label={organisationLabels.parentOrganisationId}
          labelId="parentOrganisationIdLB"
          value={organisationDetails.parentOrganisationId}
          name="parentOrganisationId"
          id="parentOrganisationId"
          placeholder=" "
          onChange={handleChange}
          serviceRequest={props.serviceRequest}
          organisationType={organisationDetails.organisationType}
          linkClick={linkClickHandle}
          onBlur={handleBlur}
          parentOrganisationName={organisationDetails.parentOrganisationName}
          infoMesage={parentNotFound}
          isParentLoading={isParentLoading}
        />
        <AdditionalDeliveryOrganisationDropDown
          id={`additionalDeliveryOrganisation`}
          label={'Additional Delivery Organisation'}
          labelId="additionalDeliveryOrganisationLB"
          textBoxPlaceHolder={organisationLabels.pleaseSelectPlaceHolder}
          selectedAdditionalDelOrg={organisationDetails.additionalDeliveryOrganisation || {}}
          inputFieldValidationError={error.addDelOrg}
          serviceRequest={props.serviceRequest}
          isFilterEnabled={true}
          recognisingOrganisationUuid={organisationDetails.recognisingOrganisationUuid}
          parentOrgUuId={organisationDetails.parentOrganisationUuid}
          formActionType={orgFormAction}
          onAdditionalDelOrgChange={(value: MultiDropDownDataSource) => {
            handleChange({
              target: {
                name: 'additionalDeliveryOrganisation',
                value: value,
              },
            });
          }}
          organisationType={organisationDetails.organisationType}
        />
      </div>
      <div className={styles.ogPrimaryLabel}>
        <UI.Typography type="normal" label={organisationLabels.mainAddress} size={14} />
      </div>
      <div>
        <OrganisationAddressForm
          addressData={organisationDetails.mainAddress}
          error={error}
          id="main"
          handleChange={handleChange}
          addressName="mainAddress"
          mandatoryField={flattenAddressValidationObj(orgProfileRule.mainAddress)}
        />
      </div>
      <div className={styles.ogPrimaryLabel}>
        <UI.Typography type="normal" label={organisationLabels.deliveryAddressLabel} size={14} />
      </div>
      <div className={cx(styles.col1, styles.cdFormGrid, styles.cdGridPadding)}>
        <UI.CheckBox
          checked={!organisationDetails.deliveryAddress.isRequired}
          label={organisationLabels.sameAsMainLabels}
          labelId="resultMainAddressLB"
          id="resultMainAddress"
          onChange={(e: UICheckboxChangeEvent) => {
            setDisplayDelivery(!e.checked);
            handleChange({
              target: {
                name: 'isRequired',
                value: !e.checked,
                addressName: 'deliveryAddress',
              },
            });
          }}
        />
      </div>
      <div className={styles.deliveryAddress}>
        {displayDelivery && (
          <OrganisationAddressForm
            addressData={{ ...organisationDetails.deliveryAddress, isRequired: displayDelivery }}
            error={error}
            handleChange={handleChange}
            id="delivery"
            addressName="deliveryAddress"
            mandatoryField={flattenAddressValidationObj(orgProfileRule.deliveryAddress)}
          />
        )}
      </div>

      <div className={styles.ogPrimaryLabel}>
        <UI.Typography type="normal" label={organisationLabels.otherInformation} size={14} />
      </div>
      <div className={cx(styles.col3, styles.ogFormGrid)}>
        <PartnerDropDown
          id="partnerLead"
          labelId={'partnerLeadLB'}
          label={organisationLabels.partnerLead}
          selectedPartner={organisationDetails.partnerLead}
          textBoxPlaceHolder={organisationLabels.partnerLeadPlaceholder}
          serviceRequest={props.serviceRequest}
          canUseStoreData
          isFilterEnabled={false}
          isMandatory
          inputFieldValidationError={error.partnerLead}
          onPartnerChange={(value: string, text: string) => {
            handleChange({
              target: {
                name: 'partnerLead',
                value: { value, text },
                dropdownText: text,
              },
            });
          }}
        />
        <UI.TextBox
          label={organisationLabels.patnerContactLabel}
          labelId="partnerContactLB"
          value={organisationDetails.partnerContact}
          name="partnerContact"
          id="partnerContact"
          placeholder=" "
          inputFieldValidation={error.partnerContact}
          onChange={handleChange}
        />
        <UI.Dropdown
          id={`methodOfDelivery`}
          label={organisationLabels.methodOfDeliveryLabel}
          labelId="methodOfDeliveryLB"
          placeholder={organisationLabels.pleaseSelectPlaceHolder}
          mandatory={true}
          list={getMethodOfDeliveryList(organisationDetails.organisationType.value)}
          selectedValue={organisationDetails.methodOfDelivery.value}
          inputFieldValidation={error.methodOfDelivery}
          onChange={(value: string, text: string) =>
            handleChange({
              target: {
                name: 'methodOfDelivery',
                value: { value, text },
                dropdownText: text,
              },
            })
          }
        />
        {/* <UI.TextBox
          label="Parent Organisation"
          labelId="parentOrganisationLB"
          value={organisationDetails.parentOrganisation}
          name="parentOrganisation"
          id="parentOrganisation"
          placeholder=""
          onChange={(e: any) => handleChange(e)}
       /> */}

        <ReferenceDropdown
          {...getDefaultReferenceDropdownProps({
            dropdownConfig: {
              inputFieldValidationError: error.sectorType,
            },
            dropdownType: ReferenceDropdownType.SECTOR_TYPE,
            value: organisationDetails.sectorType.value,
            onChange: ({ value, text }: DropDownDataSource) => {
              handleChange({
                target: {
                  name: 'sectorType',
                  value: { value, text },
                  dropdownText: text,
                },
              });
            },
          })}
        />

        <UI.TextBox
          label={organisationLabels.websiteURLLabel}
          labelId="websiteUrlLB"
          mandatory={orgProfileRule.websiteUrl.required}
          value={organisationDetails.websiteUrl}
          inputFieldValidation={error.websiteUrl}
          name="websiteUrl"
          id="websiteUrl"
          placeholder=" "
          onChange={handleChange}
        />

        <UI.TextBox
          label={organisationLabels.crmSystem}
          labelId="crmSytemLbl"
          value={organisationDetails.crmSystem}
          name="crmSystem"
          id="crmSystem"
          inputFieldValidation={error.crmSystem}
          placeholder=""
          onChange={handleChange}
        />

        <UI.TextBox
          label={organisationLabels.codeLabel}
          labelId="codeLB"
          value={organisationDetails.code}
          name="code"
          id="code"
          inputFieldValidation={error.code}
          placeholder=""
          onChange={handleChange}
        />

        <UI.Dropdown
          id={`resultAvailableForYears`}
          label={organisationLabels.resultAvailableForYearsLabel}
          labelId="resultAvailableForYearsLB"
          placeholder={organisationLabels.pleaseSelectPlaceHolder}
          list={noOfYears}
          selectedValue={organisationDetails.resultAvailableForYears?.value}
          inputFieldValidation={error.resultAvailableForYears}
          onChange={(value: string, text: string) =>
            handleChange({
              target: {
                name: 'resultAvailableForYears',
                value: { value, text },
                dropdownText: text,
              },
            })
          }
        />

        <UI.ToggleSwitch
          elementLabel={getKey(ACTIVESWITCH, organisationDetails.organisationStatus)}
          checked={organisationDetails.organisationStatus}
          label={organisationLabels.organisationStatus}
          onChange={handleChange}
          inputFieldValidation={error.organisationSatus}
          name="organisationStatus"
          color="#4f4f4f"
        />

        <UI.ToggleSwitch
          elementLabel={getKey(TOGGLESWITCH, acceptAC)}
          checked={acceptAC}
          inputFieldValidation={error.acceptAC}
          label={'Accepts AC'}
          onChange={handleChange}
          name="acceptAC"
          color="#4f4f4f"
          disabled={!acceptGT}
        />

        <UI.ToggleSwitch
          elementLabel={getKey(TOGGLESWITCH, acceptGT)}
          checked={acceptGT}
          inputFieldValidation={error.acceptGT}
          label={'Accepts GT'}
          onChange={handleChange}
          name="acceptGT"
          color="#4f4f4f"
          disabled={!acceptAC}
        />

        <UI.ToggleSwitch
          elementLabel={getKey(TOGGLESWITCH, organisationDetails.acceptIOL)}
          checked={organisationDetails.acceptIOL}
          inputFieldValidation={error.acceptIOL}
          label={organisationLabels.acceptIolLabel}
          onChange={handleChange}
          name="acceptIOL"
          color="#4f4f4f"
        />

        <UI.ToggleSwitch
          elementLabel={getKey(TOGGLESWITCH, organisationDetails.orsDisplayFlag)}
          checked={organisationDetails.orsDisplayFlag}
          inputFieldValidation={error.orsDisplayFlag}
          label={organisationLabels.orsDisplayFlagLabel}
          onChange={handleChange}
          name="orsDisplayFlag"
          color="#4f4f4f"
        />

        <UI.ToggleSwitch
          elementLabel={getKey(TOGGLESWITCH, organisationDetails.ieltsDisplayFlag)}
          checked={organisationDetails.ieltsDisplayFlag}
          inputFieldValidation={error.ieltsDisplayFlag}
          label={organisationLabels.ieltsDisplayFlagLabel}
          onChange={handleChange}
          name="ieltsDisplayFlag"
          color="#4f4f4f"
        />

        <UI.ToggleSwitch
          elementLabel={getKey(TOGGLESWITCH, organisationDetails.acceptSSR)}
          checked={organisationDetails.acceptSSR}
          inputFieldValidation={error.acceptSSR}
          label={organisationLabels.acceptSSRLabel}
          onChange={handleChange}
          name="acceptSSR"
          color="#4f4f4f"
        />

        {/*<UI.TextBox
          label="Replaced by ID"
          labelId="replacedLB"
          value={organisationDetails.code}
          name="replaceID"
          id="replaceID"
          placeholder=""
          onChange={(e: any) => handleChange(e)}
        />*/}
      </div>
      <div className={cx(styles.ogFormGrid, styles.ogTextArea, styles.notes)}>
        <UI.TextArea
          label={organisationLabels.notesLabel}
          labelId="notesLB"
          value={notes?.length ? notes[notes.length - 1].noteContent : ''}
          name="notes"
          id="notes"
          placeholder=""
          inputType="textArea"
          onChange={handleNoteChange}
          maxLength={2000}
        />
      </div>
      <div>
        <DynamicTextBox
          label={organisationLabels.alternateNameLabel}
          name="alternateNames"
          value={organisationDetails.alternateNames?.map((altName) => ({
            id: altName.alternateNameUuid,
            text: altName.name,
          }))}
          maxCount={maxCount}
          onChange={(newDynamicValues, name) => {
            const transformedAltNames: OrganisationAlternateNameResponse[] = newDynamicValues.map((dynamicTxt) => ({
              alternateNameUuid: dynamicTxt.id,
              name: dynamicTxt.text,
            }));
            handleChange({ target: { name: name, value: transformedAltNames } });
          }}
        />
      </div>
    </div>
  );
};

export default withServiceRequest(OrganisationProfile);
