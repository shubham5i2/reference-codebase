import React, { SyntheticEvent } from 'react';
import UI from 'ielts-cmds-ui-component-library';
import styles from './OrganisationProfile.module.scss';
import { ServiceRequest } from '../../../../services/utils/ServiceRequest';
import { DropDownDataSource } from '../../../../services/Models/UIModels';
import { OrganisationFromData, OrganisationType } from '../../../../services/Models/Organisation';

type OrganisationProfileEvent = SyntheticEvent | { target: OrganisationFromData };

export interface ParentOrganisationProps {
  id: string;
  label: string;
  labelId: string;
  value: string;
  name: string;
  placeholder: string;
  onChange: (changeEvent: OrganisationProfileEvent) => void;
  serviceRequest: ServiceRequest;
  organisationType: DropDownDataSource;
  linkClick: (event: React.MouseEvent<HTMLSpanElement, MouseEvent>) => void;
  onBlur: () => void;
  parentOrganisationName: string | undefined;
  inputDisabled?: boolean;
  infoMesage: { text: string; isError: boolean };
  isParentLoading: boolean;
}

const ParentOrganisation = (props: ParentOrganisationProps) => {
  const getInputChild = () => {
    if (props.parentOrganisationName && !props.infoMesage.isError) {
      return (
        <span
          onClick={props.linkClick}
          className={`${styles.parentOrganisationName} ${styles.link}`}
          id="parentOrganisationName"
        >
          {props.parentOrganisationName}
        </span>
      );
    } else if (!props.infoMesage.isError) {
      return props.infoMesage.text;
    }
    return null;
  };

  return props.organisationType.value === OrganisationType.RO ||
    props.organisationType.value === OrganisationType.VO ? (
    <div>
      <UI.TextBox
        label={props.label}
        labelId={props.labelId}
        value={props.value}
        inputFieldValidation={{ isValid: !props.infoMesage.isError, message: props.infoMesage.text }}
        name={props.name}
        id={props.id}
        placeholder={props.placeholder}
        onChange={props.onChange}
        onBlur={props.onBlur}
        inputDisabled={props.inputDisabled}
        isLoading={props.isParentLoading}
        type="numeric"
      />
      {getInputChild()}
    </div>
  ) : null;
};

export default ParentOrganisation;
