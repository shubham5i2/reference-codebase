import React, { useState, useEffect } from 'react';
import styles from './ContactDetails.module.scss';
import UI from 'ielts-cmds-ui-component-library';
import OrganisationAddressForm from '../../../Molecules/OrganisationAddressForm/OrganisationAddressForm';
import cx from 'classnames';
import { languageService } from '../../../../services/Language/LanguageService';
import { UICheckboxChangeEvent, Dictionary } from '../../../../services/Models/UIModels';
import {
  OrganisationFormType,
  ContactDetailsData,
  OrganisationFromInputChangeEvent,
  OrganisationFromData,
} from '../../../../services/Models/Organisation';
import { flattenAddressValidationObj } from '../../../utils/utilities';
import { OrganisationFormRule } from '../../../utils/ValidationRules/OrganisationAddForm';

interface ContactDetailsProps {
  contactDetails: ContactDetailsData;
  onChange: (event: OrganisationFromInputChangeEvent) => void;
  error: Dictionary;
  contactDetailsRule: OrganisationFormRule;
}

const ContactDetails = (props: ContactDetailsProps) => {
  const { contactDetails, onChange, error, contactDetailsRule } = props;
  const [adminContact, setAdminContact] = useState(false);
  const organisationLabels = languageService().organisation;

  const handleChange = (changeEvent: { target: OrganisationFromData }) => {
    const event = {
      formtype: OrganisationFormType.CONTACT_DETAILS_FORM,
      ...changeEvent,
    };
    onChange(event);
  };

  useEffect(() => {
    setAdminContact(contactDetails.adminContactAddress.isRequired);
  }, [contactDetails]);

  return (
    <div className={styles.cdProfileContainer}>
      <div className={styles.cdPrimaryLabel}>
        <UI.Typography type="normal" label={organisationLabels.primaryContact} size={14} />
      </div>
      <div>
        <OrganisationAddressForm
          addressData={contactDetails.primaryContactAddress}
          error={error}
          handleChange={handleChange}
          id="contactDetails"
          isNameRequired
          addressName="primaryContactAddress"
          mandatoryField={flattenAddressValidationObj(contactDetailsRule.primaryContactAddress)}
        />
      </div>
      <div className={styles.cdPrimaryLabel}>
        <UI.Typography type="normal" label={organisationLabels.resultsAdminContact} size={14} />
      </div>
      <div className={cx(styles.col1, styles.cdFormGrid, styles.cdGridPadding)}>
        <UI.CheckBox
          checked={!adminContact}
          label={organisationLabels.sameAsPrimary}
          labelId="resultAdminContactLB"
          id="resultAdminContact"
          onChange={(e: UICheckboxChangeEvent) => {
            setAdminContact(!e.checked);
            handleChange({
              target: {
                name: 'isRequired',
                value: !e.checked,
                addressName: 'adminContactAddress',
              },
            });
          }}
        />
      </div>
      <div className={styles.deliveryAddress}>
        {adminContact && (
          <OrganisationAddressForm
            addressData={{ ...contactDetails.adminContactAddress, isRequired: adminContact }}
            error={error}
            handleChange={handleChange}
            id="adminContact"
            isNameRequired
            addressName="adminContactAddress"
            mandatoryField={flattenAddressValidationObj(contactDetailsRule.adminContactAddress)}
          />
        )}
      </div>
    </div>
  );
};

export default ContactDetails;
