import React from 'react';
import { IncidentEvidence } from '../../../services/Models/IncidentManagement';
import styles from './IncidentEvidenceContainer.module.scss';
import { languageService } from '../../../services/Language/LanguageService';
import { sortEvidenceFiles } from '../IncidentDetailPanel/IncidentDetailPanelHelper';

interface IncidentEvidenceContainer {
  url: string;
  containerId: string;
  children: React.JSX.Element | undefined;
  buttonText: string;
  files: IncidentEvidence[];
  setFile: (arg: IncidentEvidence) => void;
  isUploadEnable?: boolean;
}

const IncidentEvidenceContainer = (props: IncidentEvidenceContainer) => {
  const incidentManagementLabels = languageService().incidentManagement;

  return (
    <div className={styles.container} id={props.containerId}>
      <div>
        <ul>
          {sortEvidenceFiles(props.files).map((item) => {
            return (
              <li
                key={item.evidenceUrl}
                onClick={() => props.setFile(item)}
                className={item.evidenceUrl === props.url ? styles.active : ''}
              >
                {item.evidenceName}
              </li>
            );
          })}
        </ul>
        {/* {this span will be chnged with UI.Button with upload feature} */}
        {props.isUploadEnable && (
          <div className={styles.btnContainer}>
            <label
              className={props.buttonText === incidentManagementLabels.uploadDocument ? styles.btn : styles.btnSec}
            >
              {props.buttonText}
            </label>
          </div>
        )}
      </div>
      {props.children}
    </div>
  );
};

export default IncidentEvidenceContainer;
