import React, { useState, useEffect } from 'react';
import styles from './SearchPanel.module.scss';
import UI from 'ielts-cmds-ui-component-library';
import ChevronDownIcon from '../../../assets/images/Chevron_Down.svg';
import ChevronUpIcon from '../../../assets/images/Chevron_Up.svg';
import { languageService } from '../../../services/Language/LanguageService';

const SearchPanel = (props: any) => {
  const [open, setOpen] = useState(false);
  const aaLabels = languageService().accessArrangements;

  const onChangeHandler = (event: any) => {
    event.preventDefault();
    setOpen(!open);
  };

  useEffect(() => {
    setOpen(props.initialOpenState);
  }, [props.initialOpenState]);

  return (
    <div className={styles.searchPanel}>
      <div className={styles.searchPanelTitle}>
        <UI.Typography type={props.titleType} label={props.title} size={props.titleSize} id="title" />
        <span className={styles.addbutton}>
          <UI.Button
            label={props.addButtonLabel}
            onChange={props.onAddUserHandler}
            color={props.addButtonColor}
            icon={props.addButtonIcon}
            title={props.addButtonLabel}
            id="addUser"
          />
        </span>
      </div>
      <div className={styles.searchPanelSubTitle}>
        <UI.Typography type={props.subTitleType} label={props.subTitle} size={props.subTitleSize} id="subTitle" />
      </div>
      <div className={styles.searchBox}>
        <UI.SearchBox
          placeholder={props.searchBoxPlaceholder}
          searchIcon={props.searchBoxSearchIcon}
          value={props.basicSearchValue}
          onClick={props.onSearchHandler}
          onChange={props.onBasicSearchValueChange}
          id="searchBoxButton"
        />
      </div>
      {props.title !== aaLabels.accesArrangementsTitle && (
        <div>
          <div>
            <a
              href="#collapse"
              onClick={(event) => {
                onChangeHandler(event);
              }}
              className={open ? styles.hidden : styles.collapseIcon}
              id="collapseTitle"
            >
              <UI.Icon icon={ChevronDownIcon} />
              <span className={styles.collapseTitle}>{props.collapseTitle}</span>
            </a>
            <span className={!open ? styles.hidden : styles.collapseOpenTitle}>{props.collapseOpenTitle}</span>
          </div>

          <div className={open ? styles.panelCollapse : [styles.panelCollapse, styles.panelClose].join(' ')}>
            {props.children}
            <div>
              <div className={styles.row}>
                <div className={styles.alignSelfCenter}>
                  <a
                    href="#collapse"
                    onClick={(event) => {
                      onChangeHandler(event);
                    }}
                    className={styles.collapseIcon}
                    id="collapseFooterTitle"
                  >
                    <UI.Icon icon={ChevronUpIcon} />
                    <span className={styles.collapseFooterTitle}>{props.collapseFooterTitle}</span>
                  </a>
                </div>
                <div className={styles.pushLeft}>
                  <a href="#clear" onClick={props.onClearSearch} className={styles.clearSearch} id="clearSearch">
                    <span>{props.clearSearch}</span>
                  </a>
                </div>
                <div>
                  <UI.Button
                    label={props.searchButtonLabel}
                    onChange={props.onAdvancedSearchHandler}
                    color={props.searchButtonColor}
                    id="advancedSearchButton"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
export default SearchPanel;
