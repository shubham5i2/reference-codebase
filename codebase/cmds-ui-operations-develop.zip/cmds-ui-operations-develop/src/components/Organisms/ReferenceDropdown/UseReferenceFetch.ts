import { getSectorTypes } from '../../../services/API/Reference/SectorType';
import { getPartners } from '../../../services/API/Reference/Partner';
import { AsyncResponseStatus } from '../../../services/Models/Api';
import { DATA_LOADED, DATA_LOADING, DATA_LOAD_ERROR } from '../../../Store/Actions/ReferenceActions';
import { Dictionary } from '../../../services/Models/UIModels';
import { getCountries } from '../../../services/API/Reference/Country';
import { getTerritories } from '../../../services/API/Reference/Territories';
import { getOrganisationTypes } from '../../../services/API/Reference/OrganisationType';
import { ReferenceDropdownType } from '../../../services/Models/ReferenceModals';
import { ServiceRequest } from '../../../services/utils/ServiceRequest';
import { AsyncPreloaderServiceSubject } from '../../../services/Preloader/usePreloader';
import { getResultStatuses } from '../../../services/API/Result/ResultStatus';
import { useStateValue } from '../../../Store/helpers/UseStateValue';

export interface ReferenceFetchArgs {
  serviceData: ReferenceDropdownType[];
  serviceRequest: ServiceRequest;
  subject?: AsyncPreloaderServiceSubject;
  dependsOn?: boolean;
}

type RefAPIMap = {
  [key in ReferenceDropdownType]: {
    func: any;
    args?: Dictionary;
  };
};

const refAPI: RefAPIMap = {
  [ReferenceDropdownType.PARTNER]: { func: getPartners },
  [ReferenceDropdownType.SECTOR_TYPE]: { func: getSectorTypes },
  [ReferenceDropdownType.COUNTRY]: {
    func: getCountries,
    args: {
      includeInactive: false,
    },
  },
  [ReferenceDropdownType.TERRITORY]: { func: getTerritories },
  [ReferenceDropdownType.ORGANISATION_TYPE]: { func: getOrganisationTypes },
  [ReferenceDropdownType.RESULT_STATUS]: { func: getResultStatuses },
};

export const useReferenceFetch = () => {
  const { dispatch } = useStateValue();

  const fetchReferenceData = ({ serviceData, serviceRequest, subject }: ReferenceFetchArgs) => {
    serviceData.forEach((type: ReferenceDropdownType) => {
      const { func, args = {} } = refAPI[type];
      dispatch({
        type: DATA_LOADING,
        payload: {
          dropdownType: type,
        },
      });
      // const updatedArgs = { ...dependsOn, ...args };
      const updatedArgs = { ...args };
      func(serviceRequest, updatedArgs).subscribe((data: any) => {
        subject && subject.next({ type, status: data.status });
        if (data.status === AsyncResponseStatus.SUCCESS && data.transformedData?.length) {
          dispatch({
            type: DATA_LOADED,
            payload: {
              dropdownType: type,
              response: data.response,
              transformedData: data.transformedData,
            },
          });
        } else {
          dispatch({
            type: DATA_LOAD_ERROR,
            payload: {
              dropdownType: type,
            },
          });
        }
      });
    });
  };
  return { fetchReferenceData };
};
export { ReferenceDropdownType };
