import { languageService } from '../../../services/Language/LanguageService';
import { Dictionary } from '../../../services/Models/UIModels';
import { ReferenceDropdownProps } from './ReferenceDropdown';
import { ReferenceDropdownType } from './UseReferenceFetch';

const organisationLabels = languageService().organisation;

const defaultDropdownProps: Dictionary = {
  [ReferenceDropdownType.COUNTRY]: {
    id: 'countryDropdown',
    dropdownConfig: {
      labelText: organisationLabels.countryLabel,
      placeholderText: organisationLabels.pleaseSelectPlaceHolder,
      isFilterEnabled: true,
      isMandatory: false,
      disabled: false,
    },
    dropdownType: ReferenceDropdownType.COUNTRY,
  },
  [ReferenceDropdownType.ORGANISATION_TYPE]: {
    id: 'organisationType',
    dropdownConfig: {
      labelText: organisationLabels.organisationType,
      placeholderText: organisationLabels.organisationTypePlaceholder,
      isFilterEnabled: false,
      isMandatory: true,
      disabled: false,
    },
    dropdownType: ReferenceDropdownType.ORGANISATION_TYPE,
  },
  [ReferenceDropdownType.SECTOR_TYPE]: {
    id: 'sectorType',
    dropdownConfig: {
      labelText: organisationLabels.sectorLabel,
      placeholderText: organisationLabels.pleaseSelectPlaceHolder,
      isFilterEnabled: false,
      isMandatory: true,
      disabled: false,
    },
    dropdownType: ReferenceDropdownType.SECTOR_TYPE,
  },
};

export const getDefaultReferenceDropdownProps = (props: ReferenceDropdownProps) => {
  const defaultProps = defaultDropdownProps[props.dropdownType] || {};
  return {
    ...defaultProps,
    ...props,
    dropdownConfig: {
      ...defaultProps.dropdownConfig,
      ...props.dropdownConfig,
    },
  };
};
