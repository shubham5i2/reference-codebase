import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import withServiceRequest, { ServiceRequest } from '../../../services/utils/ServiceRequest';
import { DropDownDataSource, DataState, DropdownCache, FormError } from '../../../services/Models/UIModels';
import { useStateValue } from '../../../Store/helpers/UseStateValue';
import { useReferenceFetch, ReferenceDropdownType } from './UseReferenceFetch';
import { sortValues } from '../../utils/utilities';

export interface ReferenceDropdownProps {
  id?: string;
  dropdownConfig?: {
    labelText?: string;
    placeholderText?: string;
    isFilterEnabled?: boolean;
    isMandatory?: boolean;
    disabled?: boolean;
    inputFieldValidationError?: FormError;
  };
  dropdownType: ReferenceDropdownType;
  value?: string;
  text?: string;
  ignoreCache?: boolean;
  onChange: (event: DropDownDataSource) => void;
  // dependsOn?: string;
}

export interface ReferenceDropdownPropsWithServiceRequest extends ReferenceDropdownProps {
  serviceRequest: ServiceRequest;
}

const ReferenceDropdown = (props: ReferenceDropdownPropsWithServiceRequest) => {
  const {
    id = props.dropdownType,
    dropdownConfig,
    dropdownType,
    value = '',
    text,
    onChange,
    serviceRequest,
    ignoreCache,
  } = props;
  const { labelText, isMandatory, placeholderText, disabled, inputFieldValidationError, isFilterEnabled } =
    dropdownConfig || {};

  const { fetchReferenceData } = useReferenceFetch();
  const { state } = useStateValue();
  const refData: DropdownCache = state.referenceData?.[dropdownType] || {};

  const fetchData = () => {
    if (refData.dataState !== DataState.LOADING && (!getList().length || ignoreCache)) {
      // CALL API
      fetchReferenceData({ serviceRequest, serviceData: [dropdownType] });
    }
  };

  const getList = () => {
    return refData?.transformedData || [];
  };

  const handleDropDownOpen = () => {
    fetchData();
  };

  return (
    <UI.Dropdown
      id={id}
      label={labelText || dropdownType.toString()}
      mandatory={isMandatory}
      labelId={`${id}_label`}
      placeholder={placeholderText}
      selectedText={text || ''}
      showInputWithoutList
      selectedValue={value}
      disable={disabled}
      inputFieldValidation={inputFieldValidationError}
      list={sortValues(getList())}
      onChange={(value: string, text: string) => onChange({ value, text })}
      onDropDownOpen={handleDropDownOpen}
      isFilterEnabled={isFilterEnabled}
      isLoading={refData?.dataState === DataState.LOADING}
    />
  );
};

export default withServiceRequest(ReferenceDropdown);

/*
  useEffect(() => {
    if (dependsOn === undefined) {
      fetchData();
    } else if (dependsOn === '') {
      onChange({ value: '', text: '' });
    } else {
      fetchData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dependsOn]);

   const isDisabled = () => {
    if (dependsOn) {
      return !!dependsOn && !disabled;
    } else {
      return disabled;
    }
  };

  const getList = () => {
    if (dependsOn) {
      const refState = refData as Dictionary;
      return refState[dependsOn]?.transformedData || [];
    }
    return refData?.transformedData || [];
  };
  */
