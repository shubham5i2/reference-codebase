import React from 'react';
import UI from 'ielts-cmds-ui-component-library';

import { languageService } from '../../../services/Language/LanguageService';
import styles from './ResultsBookingDetails.module.scss';
import ResultDetailsBadge from '../../../assets/images/ResultDetailsBadge.svg';
import Calendar from '../../../assets/images/Calendar.svg';
import { BookingDetails } from '../../../services/Models/Result';
import { formatDate } from '../../utils/utilities';
import { ComponentRoundInfo } from '../../Pages/Results/ResultsTestTakerDetails/ResultsTestTakerDetailsConstants';
import { useHistory } from 'react-router-dom';
import cx from 'classnames';
import LinkedBookingDetails from '../LinkedBookingDetails/LinkedBookingDetails';
import get from 'lodash.get';

interface ResultsBookingDetailsProps {
  bookingDetails?: BookingDetails;
  getResultsTestTakerDetails: () => void;
}

const ResultsBookingDetails = (props: ResultsBookingDetailsProps) => {
  const resultLabels = languageService().result;
  const history = useHistory();

  const getLatestScore = (componentScore: ComponentRoundInfo | null) => {
    if (!componentScore) {
      return '-';
    }
    if (componentScore.overallResultType === 'JAGGED-1' || componentScore.overallResultType === 'JAGGED-2') {
      return (
        <span>
          {componentScore.overallFinalGrade}
          <span className={styles.jagged}>{resultLabels.jaggedLabel}</span>
        </span>
      );
    } else if (componentScore.overallFinalGrade === null || componentScore.overallFinalGrade === undefined) {
      return '-';
    }
    return componentScore.overallFinalGrade;
  };

  const getBannedText = (isBanned: boolean) => {
    return isBanned ? resultLabels.banned : resultLabels.notBanned;
  };

  const onClickViewBooking = (bookingUuid: string) => {
    history.push(`/results/viewTestTakerDetails/${bookingUuid}`, {
      selectedBookingUuid: bookingUuid,
      productName: history.location.state.product,
    });
    props.getResultsTestTakerDetails();
  };

  return (
    <>
      <div className={styles.flexLayout}>
        <div className={styles.ResultsTestTakerDetailsWrapper}>
          <div className={[styles.ResultsTestTakerDetails, styles.BookingDetails].join(' ')}>
            <div className={styles.header}>
              <div className={styles.headerTitle}>
                <img alt="" src={Calendar} className={styles.headerIcon} />
                {resultLabels.booking}
              </div>
            </div>
            <div className={styles.body}>
              <div className={styles.sectionHeader}>{resultLabels.personalInformationLabel.toUpperCase()}</div>
              <div className={[styles.detailsContainerGrid, styles.withSeparator].join(' ')}>
                <div className={styles.leftColumn}>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="firstName"
                      label={resultLabels.firstNameLabel}
                      value={get(props, 'bookingDetails.personalDetails.givenName', '')}
                      type="regular"
                      size={15}
                    />
                  </div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="uniqueTestTakerId"
                      label={resultLabels.uniqueTestTakerIdLabel}
                      value={get(props, 'bookingDetails.personalDetails.uniqueTestTakerId', '')}
                      type="regular"
                      size={15}
                    />
                  </div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="nationality"
                      label={resultLabels.nationalityLabel}
                      value={get(props, 'bookingDetails.personalDetails.nationality', '')}
                      type="regular"
                      size={15}
                    />
                  </div>
                </div>
                <div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="lastName"
                      label={resultLabels.lastNameLabel}
                      value={get(props, 'bookingDetails.personalDetails.familyName', '')}
                      type="regular"
                      size={15}
                    />
                  </div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="dateOfBirth"
                      label={resultLabels.dateOfBirthLabel}
                      value={
                        props.bookingDetails?.personalDetails.birthDate
                          ? formatDate(new Date(props.bookingDetails.personalDetails.birthDate), 'dd MMM yyyy')
                          : ''
                      }
                      type="regular"
                      size={15}
                    />
                  </div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="identityDocumentNumber"
                      label={resultLabels.identityDocumentNumberLabel}
                      value={get(props, 'bookingDetails.personalDetails.identityDocumentNumber', '')}
                      type="regular"
                      size={15}
                    />
                  </div>
                </div>
              </div>
              <div className={styles.sectionHeader}>{resultLabels.testBookingInformationLabel.toUpperCase()}</div>
              <div className={[styles.detailsContainerGrid, styles.withSeparator].join(' ')}>
                <div className={styles.leftColumn}>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="testDate"
                      label={resultLabels.testDateLabel}
                      value={
                        props.bookingDetails?.testBookingDetails.testDate
                          ? formatDate(new Date(props.bookingDetails.testBookingDetails.testDate), 'dd MMM yyyy')
                          : ''
                      }
                      type="regular"
                      size={15}
                    />
                  </div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="testCentreNumber"
                      label={resultLabels.testCentreNumberLabel}
                      value={get(props, 'bookingDetails.testBookingDetails.testCentreNumber', '')}
                      type="regular"
                      size={15}
                    />
                  </div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="locationID"
                      label={resultLabels.locationIDLabel}
                      value={get(props, 'bookingDetails.testBookingDetails.locationId', '')}
                      type="regular"
                      size={15}
                    />
                  </div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="testTakerNumber"
                      label={resultLabels.testTakerNumberLabel}
                      value={get(props, 'bookingDetails.testBookingDetails.shortCandidateNumber', '')}
                      type="regular"
                      size={15}
                    />
                  </div>
                </div>
                <div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="product"
                      label={resultLabels.productLabel}
                      value={get(props, 'bookingDetails.testBookingDetails.productName', '')}
                      type="regular"
                      size={15}
                    />
                  </div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="testCentreName"
                      label={resultLabels.testCentreNameLabel}
                      value={get(props, 'bookingDetails.testBookingDetails.testCentreName', '')}
                      type="regular"
                      size={15}
                    />
                  </div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="location"
                      label={resultLabels.locationLabel}
                      value={get(props, 'bookingDetails.testBookingDetails.locationName', '')}
                      type="regular"
                      size={15}
                    />
                  </div>
                </div>
              </div>
              <div className={styles.sectionHeader}>{resultLabels.resultInformationLabel.toUpperCase()}</div>
              <div className={styles.detailsContainerGrid}>
                <div className={styles.leftColumn}>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="resultsStatus"
                      label={resultLabels.resultsStatusLabel}
                      value={get(props, 'bookingDetails.currentResultStatus.resultStatusType', '')}
                      type="regular"
                      size={15}
                    />
                  </div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="resultsStatusComment"
                      label={resultLabels.resultsStatusComment}
                      value={get(props, 'bookingDetails.currentResultStatus.resultStatusComment', '')}
                      type="regular"
                      size={15}
                    />
                  </div>
                </div>
                <div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="resultStatusLabel"
                      label={resultLabels.resultsStatusLabelLabel}
                      value={get(props, 'bookingDetails.currentResultStatus.resultStatusLabel', '')}
                      type="regular"
                      size={15}
                    />
                  </div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="banStatus"
                      label={resultLabels.banStatusLabel}
                      value={props.bookingDetails ? getBannedText(props.bookingDetails.personalDetails.isBanned) : ''}
                      type="regular"
                      size={15}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.ResultsTestTakerDetailsWrapper}>
          <div className={[styles.ResultsTestTakerDetails, styles.scores].join(' ')}>
            <div className={styles.header}>
              <div className={styles.headerTitle}>
                <img alt="" src={ResultDetailsBadge} className={styles.headerIcon} />
                {resultLabels.resultDetails}
              </div>
            </div>
            <div className={styles.body}>
              <div className={styles.detailsContainerGrid}>
                <div className={styles.flexItem}>
                  <div className={[styles.sectionHeader, styles.sectionHeaderSpacer].join(' ')}>
                    {resultLabels.latestScoresLabel.toUpperCase()}
                  </div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="scoreOverall"
                      label={resultLabels.scoreOverallLabel}
                      value={
                        props.bookingDetails ? getLatestScore(props.bookingDetails.latestComponentScore.overall) : ''
                      }
                      type="bold"
                      size={15}
                    />
                  </div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="scoreListening"
                      label={resultLabels.scoreListeningLabel}
                      value={
                        props.bookingDetails ? getLatestScore(props.bookingDetails.latestComponentScore.listening) : ''
                      }
                      type="regular"
                      size={15}
                    />
                  </div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="scoreReading"
                      label={resultLabels.scoreReadingLabel}
                      value={
                        props.bookingDetails ? getLatestScore(props.bookingDetails.latestComponentScore.reading) : ''
                      }
                      type="regular"
                      size={15}
                    />
                  </div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="scoreWriting"
                      label={resultLabels.scoreWritingLabel}
                      value={
                        props.bookingDetails ? getLatestScore(props.bookingDetails.latestComponentScore.writing) : ''
                      }
                      type="regular"
                      size={15}
                    />
                  </div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="scoreSpeaking"
                      label={resultLabels.scoreSpeakingLabel}
                      value={
                        props.bookingDetails ? getLatestScore(props.bookingDetails.latestComponentScore.speaking) : ''
                      }
                      type="regular"
                      size={15}
                    />
                  </div>
                  <div className={cx(styles.detailsContainerGrid, styles.withSeparator)}></div>
                  <div className={styles.sectionHeaderSpacer}></div>
                  <div className={styles.field}>
                    <UI.DisplayLabelValuePair
                      id="trfNumber"
                      label={resultLabels.trfNumberLabel}
                      value={
                        props.bookingDetails?.resultDetails.trfNumber
                          ? props.bookingDetails.resultDetails.trfNumber
                          : '-'
                      }
                      type="regular"
                      size={15}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {props.bookingDetails?.linkedBookingDetails && props.bookingDetails?.linkedBookingDetails !== null && (
        <LinkedBookingDetails
          linkedBookingDetailsData={props.bookingDetails?.linkedBookingDetails}
          onClickViewBooking={onClickViewBooking}
        />
      )}
    </>
  );
};

export default ResultsBookingDetails;
