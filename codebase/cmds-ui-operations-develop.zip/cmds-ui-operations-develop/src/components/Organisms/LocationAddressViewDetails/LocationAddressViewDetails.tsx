import React from 'react';
import UI from 'ielts-cmds-ui-component-library';

import styles from './LocationAddressViewDetails.module.scss';
import { AddressFormElements, AddressData, AddressType } from '../../../services/Models/LocationManagement';
import { languageService } from '../../../services/Language/LanguageService';

interface LocationAddressViewDetailsProps {
  addressData: AddressData;
}

const LocationAddressViewDetails = (props: LocationAddressViewDetailsProps) => {
  const { addressData } = props;
  const locationLables = languageService().locationManagement;
  const size = 14;
  const type = 'regular';

  return (
    <div className={styles.viewaddresspanel}>
      <div className={styles.addressLabel}>
        <UI.Typography
          id="postalAddress"
          type="normal"
          label={
            addressData.addressTypeUuid === AddressType.POSTAL
              ? locationLables.postalAddress
              : locationLables.physicalAddress
          }
          size={size}
        />
      </div>

      <div className={styles.viewAddressConainer}>
        <UI.DisplayLabelValuePair
          id={AddressFormElements.addressLine1}
          label={locationLables.addressLabel1}
          value={addressData.addressLine1}
          type={type}
          size={size}
        />

        <UI.DisplayLabelValuePair
          id={AddressFormElements.addressLine2}
          label={locationLables.addressLabel2}
          value={addressData.addressLine2}
          type={type}
          size={size}
        />

        <UI.DisplayLabelValuePair
          id={AddressFormElements.addressLine3}
          label={locationLables.addressLabel3}
          value={addressData.addressLine3}
          type={type}
          size={size}
        />

        <UI.DisplayLabelValuePair
          id={AddressFormElements.addressLine4}
          label={locationLables.addressLabel4}
          value={addressData.addressLine4}
          type={type}
          size={size}
        />

        <UI.DisplayLabelValuePair
          id={AddressFormElements.city}
          label={locationLables.cityLabel}
          value={addressData.city}
          type={type}
          size={size}
        />

        <UI.DisplayLabelValuePair
          id={AddressFormElements.postalCode}
          label={locationLables.postalCodeLabel}
          value={addressData.postalCode}
          type={type}
          size={size}
        />

        <UI.DisplayLabelValuePair
          id={AddressFormElements.countryName}
          label={locationLables.countryLabel}
          value={addressData.countryName}
          type={type}
          size={size}
        />

        <UI.DisplayLabelValuePair
          id={AddressFormElements.territoryName}
          label={locationLables.territory}
          value={addressData.territoryName}
          type={type}
          size={size}
        />

        <UI.DisplayLabelValuePair
          id={AddressFormElements.countryIso3Code}
          label={locationLables.countryIso3Code}
          value={addressData.countryIso3Code}
          type={type}
          size={size}
        />

        <UI.DisplayLabelValuePair
          id={AddressFormElements.email}
          label={locationLables.emailLabel}
          value={addressData.email}
          type={type}
          size={size}
        />

        <UI.DisplayLabelValuePair
          id={AddressFormElements.primaryPhone}
          label={locationLables.primaryPhoneLabel}
          value={addressData.primaryPhone}
          type={type}
          size={size}
        />

        <UI.DisplayLabelValuePair
          id={AddressFormElements.secondaryPhone}
          label={locationLables.secondaryPhoneLabel}
          value={addressData.secondaryPhone}
          type={type}
          size={size}
        />
      </div>
    </div>
  );
};

export default LocationAddressViewDetails;
