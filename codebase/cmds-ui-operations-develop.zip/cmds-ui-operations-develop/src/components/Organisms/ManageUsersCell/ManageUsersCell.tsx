import React from 'react';
import UI from 'ielts-cmds-ui-component-library';

import styles from './ManageUsersCell.module.scss';
import { ManageUsersCellType } from '../ManageUsersGrid/ManageUsersGridConstants';
import MoreIcon from '../../../assets/images/More.svg';

export interface ManageUserCellProps {
  cellType: string;
  value?: string | string[];
  moreClickHandler?: (props: any) => void;
}

const ManageUsersCell = (props: ManageUserCellProps) => {
  const value = props.value || '';
  const [firstName, lastName, color] = value instanceof Array ? value : [];
  const name = `${firstName} ${lastName}`;
  const user = {
    firstName,
    lastName,
  };
  const statusClassName = typeof value === 'string' ? value.toLowerCase() : '';
  switch (props.cellType) {
    case ManageUsersCellType.NAME:
      return (
        <div id="nameContainer" className={styles.avatar}>
          <UI.Avatar id="avatar" title={user} color={color} />
          <label id="nameLabel" className={`${styles.manageUsersLabel} ${styles.name}`}>
            {name}
          </label>
        </div>
      );
    case ManageUsersCellType.STAFFID:
      return (
        <label id="staffIdLabel" className={`${styles.manageUsersLabel}`}>
          {value}
        </label>
      );
    case ManageUsersCellType.EMAILID:
      return (
        <label id="emailIdLabel" className={`${styles.manageUsersLabel}`}>
          {value}
        </label>
      );
    case ManageUsersCellType.USERGROUPS:
      return (
        <label id="userGroupsLabel" className={`${styles.manageUsersLabel}`}>
          {value}
        </label>
      );
    case ManageUsersCellType.STATUS:
      return (
        <div id="statusContainer" className={styles.status}>
          <div className={`${styles.statusCircle} ${styles[statusClassName + 'StatusCircle']}`} />
          <label id="statusLabel" className={styles[statusClassName]}>
            {value}
          </label>
        </div>
      );
    case ManageUsersCellType.MORE:
      return (
        <button id="moreButton" className={styles.more} onClick={props.moreClickHandler}>
          <img alt="" src={MoreIcon} />
        </button>
      );
    default:
      return null;
  }
};

export default ManageUsersCell;
