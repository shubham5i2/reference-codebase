import React, { useEffect, useRef } from 'react';
import UI from 'ielts-cmds-ui-component-library';

import styles from './IncidentManagementActionButtons.module.scss';
import arrowDownIcon from '../../../assets/images/ArrowDown.svg';
import arrowUpIcon from '../../../assets/images/Chevron_Up.svg';
import moreIcon from '../../../assets/images/More.svg';
import { Action } from '../../../services/Models/Api';
import {
  IncidentActionViewType,
  incidentManagementActions,
} from '../../../constants/IncidentManagement/IncidentManagementViewPanelConstants';
import ManageUsersActions from '../../Molecules/ManageUsersActions/ManageUsersActions';

interface ActionButtonsProps {
  isExpanded: boolean;
  isMoreSelected: boolean;
  moreSelectedClass: string;
  incidentUuid: string;
  onExpandClickHandler: (incidentUuid: string) => void;
  setMoreSelected: (value: boolean) => void;
  pushIncidentEdit: (arg: string) => void;
}

const IncidentManageActionButtons = (props: ActionButtonsProps) => {
  const moreDivRef = useRef<HTMLDivElement>();

  const style = props.isExpanded
    ? `${styles.actionsContainer} ${props.moreSelectedClass} ${styles.moreBtn}`
    : `${styles.actionsContainer} ${props.moreSelectedClass} ${styles.moreBtn} ${styles.actionsContainerExp}`;

  useEffect(() => {
    const handleClickOutside = (e: Event) => {
      const target = e.target as HTMLElement;
      if (moreDivRef.current && !moreDivRef.current.contains(target)) {
        props.setMoreSelected(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
    // eslint-disable-next-line
  }, []);

  const viewActionHandler = (action: Action) => {
    switch (action.type) {
      case IncidentActionViewType.EDIT_INCIDENT:
        props.pushIncidentEdit(props.incidentUuid);
        break;
    }
  };

  return (
    <div className={style} ref={moreDivRef as React.RefObject<HTMLDivElement>}>
      <small
        className={styles.arrowBtn}
        id="arrowButton"
        onClick={() => props.onExpandClickHandler(props.incidentUuid)}
      >
        {/*  ---> need to implement UI.Icon instead of img tag */}
        {props.isExpanded ? (
          <img src={arrowUpIcon} className={styles.arrowUp} alt="arrowBtn" />
        ) : (
          <img src={arrowDownIcon} alt="arrowBtn" />
        )}
      </small>
      <span onClick={() => props.setMoreSelected(!props.isMoreSelected)}>
        <UI.Icon icon={moreIcon} />
      </span>
      {props.isMoreSelected ? (
        <ManageUsersActions
          id={'actionsContainer'}
          userActions={incidentManagementActions}
          userActionsClickHandler={(action: Action) => viewActionHandler(action)}
        />
      ) : null}
    </div>
  );
};

export default IncidentManageActionButtons;
