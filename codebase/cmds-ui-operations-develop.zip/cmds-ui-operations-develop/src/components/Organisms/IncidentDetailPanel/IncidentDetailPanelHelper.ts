import { AudioFileFotmat, IncidentEvidence, VideoFileFormat } from '../../../services/Models/IncidentManagement';

export const sortEvidenceFiles = (incidentEvidence: IncidentEvidence[]) =>
  incidentEvidence.sort((a, b) => a.evidenceName.localeCompare(b.evidenceName));

export const createEvidences = (incidentEvidence: IncidentEvidence[]) => {
  const audioFiles: IncidentEvidence[] = [];
  const videoFiles: IncidentEvidence[] = [];
  const documentFiles: IncidentEvidence[] = [];
  incidentEvidence.forEach((item) => {
    switch (item.evidenceFileExtention.toLowerCase()) {
      case VideoFileFormat.MP4:
      case VideoFileFormat.OGG:
      case VideoFileFormat.WEBM:
      case VideoFileFormat.MOV:
        videoFiles.push(item);
        break;
      case AudioFileFotmat.MP3:
      case AudioFileFotmat.WAV:
        audioFiles.push(item);
        break;
      default:
        documentFiles.push(item);
        break;
    }
  });
  return { audioFiles, videoFiles, documentFiles };
};
