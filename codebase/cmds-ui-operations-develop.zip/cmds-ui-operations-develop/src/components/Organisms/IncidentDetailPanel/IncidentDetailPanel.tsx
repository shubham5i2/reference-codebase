import React, { useState } from 'react';

import UI from 'ielts-cmds-ui-component-library';

import { IncidentManagementIncidentDetails } from '../../../services/Models/IncidentManagement';
import {
  getIncidentCatagory,
  getIncidentStatus,
  getIncidentType,
  getIncidentSeverity,
} from '../../../../src/services/API/Reference/Incident';
import styles from './IncidentDetailPanel.module.scss';
import { languageService } from '../../../services/Language/LanguageService';
import IncidentManagementEvidenceDialog from '../../Others/IncidentManagementEvidenceDialog/IncidentManagementEvidenceDialog';
import IncidentManageActionButtons from '../IncidentManagementActionButtons/IncidentManagementActionButtons';
import {
  getDateTime,
  getIncidentDetails,
  findReportingUser,
} from '../../../services/API/IncidentManagement/GetIncidentDetailsSearchResult';
import IncidentDetailComments from '../IncidentDetailComments/IncidentDetailComments';
import { UIButtonType, UITypography } from '../../../services/Models/UIModels';
import { createEvidences, sortEvidenceFiles } from './IncidentDetailPanelHelper';

export interface IncidentDetailPanelProps {
  incidentDetails: IncidentManagementIncidentDetails;
  actualIndex: number;
  displayIndex: number;
  isExpanded: boolean;
  pushIncidentEdit: (incidentUuid: string) => void;
  expansionHandler: (incidentUuid: string) => void;
}

const IncidentDetailPanel = (props: IncidentDetailPanelProps) => {
  const [isEvidenceBoxOpen, setEvidenceBox] = useState(false);
  const [isMoreSelected, setMoreSelected] = useState(false);

  const exactDropDownValue = {
    incidentCatagory: getIncidentCatagory(props.incidentDetails.incidentCategoryUuid),
    incidentType: getIncidentType(props.incidentDetails.incidentTypeUuid),
    incidentStatus: getIncidentStatus(props.incidentDetails.incidentStatusTypeUuid),
    incidentSeverity: getIncidentSeverity(props.incidentDetails.incidentSeverity),
  };
  const moreSelectedClass = isMoreSelected ? styles.actionsOpened : '';
  const incidentManagementLabels = languageService().incidentManagement;

  const onExpandClickHandler = (incidentUuid: string) => {
    props.expansionHandler(incidentUuid);
  };

  const manageEvidenceBox = () => {
    if (isEvidenceBoxOpen) {
      const { audioFiles, videoFiles, documentFiles } = createEvidences(props.incidentDetails.evidences);
      return (
        <IncidentManagementEvidenceDialog
          title={incidentManagementLabels.evidenceDetails}
          modalCloseHandler={() => setEvidenceBox(false)}
          audioFiles={sortEvidenceFiles(audioFiles)}
          videoFiles={videoFiles}
          documentFiles={documentFiles}
        />
      );
    }
  };

  const manageActionButton = () => {
    return (
      <IncidentManageActionButtons
        isExpanded={props.isExpanded}
        onExpandClickHandler={onExpandClickHandler}
        setMoreSelected={setMoreSelected}
        pushIncidentEdit={props.pushIncidentEdit}
        isMoreSelected={isMoreSelected}
        moreSelectedClass={moreSelectedClass}
        incidentUuid={props.incidentDetails.incidentUuid}
      />
    );
  };
  return (
    <div className={styles.leftPanelContainer}>
      <div className={!props.isExpanded ? styles.ttbhExpandableContainer : styles.ttbhExpandableContainerEdit}>
        <div className={styles.dataLabelClass}>
          <UI.Typography
            type={UITypography.REGULAR}
            id={'dataLabel'}
            label={`${incidentManagementLabels.incident} ${props.displayIndex}`}
            size={20}
          />
        </div>
        {manageActionButton()}
      </div>
      <div className={props.isExpanded ? styles.ttbhDetailsContainer : styles.deActivate}>
        <div className={styles.ttbhDetailsContainerGrid}>
          <div>
            <div>
              <UI.DisplayLabelValuePair
                id={'incidentCatagory'}
                label={incidentManagementLabels.incidentCatagory}
                value={exactDropDownValue.incidentCatagory}
                type="regular"
                size={16}
                className={styles.displayLabel}
              />
            </div>
            <div>
              <UI.DisplayLabelValuePair
                id={'incidentType'}
                label={incidentManagementLabels.incidentType}
                value={exactDropDownValue.incidentType}
                type="regular"
                size={16}
                className={styles.displayLabel}
              />
            </div>
            <div>
              <UI.DisplayLabelValuePair
                id={'incidentStatus'}
                label={incidentManagementLabels.incidentStatus}
                value={exactDropDownValue.incidentStatus}
                type="regular"
                size={16}
                className={styles.displayLabel}
              />
            </div>
            <div>
              <UI.DisplayLabelValuePair
                id={'severity'}
                label={incidentManagementLabels.severity}
                value={exactDropDownValue.incidentSeverity}
                type="regular"
                size={16}
                className={styles.displayLabel}
              />
            </div>
          </div>
          <div>
            <div>
              <UI.DisplayLabelValuePair
                id={'reportingUser'}
                label={incidentManagementLabels.reportingUser}
                value={findReportingUser(props.incidentDetails)}
                type="regular"
                size={16}
                className={styles.displayLabelSec}
              />
            </div>
            <div>
              <UI.DisplayLabelValuePair
                id={'reportTime'}
                label={incidentManagementLabels.reportTime}
                value={getDateTime(props.incidentDetails)}
                type="regular"
                size={16}
                className={styles.displayLabelSec}
              />
            </div>
            <div className={styles.borderBox}>
              <span>{incidentManagementLabels.incidentDetails}</span>
              <span className={styles.borderBoxSpan}>{getIncidentDetails(props.incidentDetails)}</span>
            </div>
          </div>
          <UI.Button
            id="evidenceButton"
            color={UIButtonType.BLUELINE}
            label={incidentManagementLabels.viewEvidence}
            onChange={() => setEvidenceBox(true)}
            disabled={props.incidentDetails.evidences.length === 0}
          />
        </div>
        <IncidentDetailComments
          comments={props.incidentDetails.comments}
          commentLabel={incidentManagementLabels.comments}
        />
        {manageEvidenceBox()}
      </div>
    </div>
  );
};

export default IncidentDetailPanel;
