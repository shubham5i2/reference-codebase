import React from 'react';
import styles from './LocationDetails.module.scss';
import UI from 'ielts-cmds-ui-component-library';
import cx from 'classnames';
import { languageService } from '../../../../services/Language/LanguageService';
import {
  LocationDetailsData,
  LocationType,
  LOCATION_TYPES,
  TOGGLE_COLOR,
  LocationDetailControl,
  LocationFormEvent,
  LOCATION_STATUS,
  LocationManagementForm,
  LocationStatus,
} from '../../../../services/Models/LocationManagement';
import { TOGGLESWITCH } from '../../../../constants/UiConstants';
import { getKey, formatDate } from '../../../utils/utilities';
import PartnerDropDown, { Partner } from '../../BaseDropDown/PartnerDropDown/PartnerDropDown';
import withServiceRequest, { ServiceRequest } from '../../../../services/utils/ServiceRequest';
import { showOtherDetails } from '../../../Pages/LocationManagement/LocationManagementUtils';
import { Dictionary, DropDownDataSource } from '../../../../services/Models/UIModels';
import LocationDropdown from '../../LocationDropdown/LocationDropdown';
import { LocationType as LocationDropdownType } from '../../../Organisms/LocationDropdown/LocationDropdownUtils';

export interface LocationDetailsProps {
  locationDetailsData: LocationDetailsData;
  serviceRequest: ServiceRequest;
  error: Dictionary;
  onLocationDetailChange: (event: LocationFormEvent) => void;
  selectedProductCount: number;
  locationFormAction: LocationManagementForm;
}

const getTextKey = (locationTypeCode: string) => {
  return locationTypeCode === LocationType.PHYSICAL_BUILDING ? 'testCentreNumber' : 'locationName';
};

const getDropdownLocationType = (locationType: string, partnerCode: string) => {
  if (locationType === '' || partnerCode === '') {
    return LocationDropdownType.NONE;
  }
  return locationType === LocationType.TEST_CENTRE ? LocationDropdownType.COUNTRY : LocationDropdownType.TEST_CENTRE;
};

const LocationDeatils = (props: LocationDetailsProps) => {
  const { locationDetailsData, onLocationDetailChange, error } = props;
  const locationLabels = languageService().locationManagement;
  const updateLocationDetails = (name: string, value: string | boolean | Date) => {
    onLocationDetailChange({ name, value });
  };

  // Textbox Change handler
  const handleTextBoxChange = (e: React.FormEvent<HTMLInputElement>) => {
    const target = e.target as HTMLInputElement;
    const value = target.value;
    updateLocationDetails(target.name, value);
  };

  // Toggle change handler
  const handleToggleChange = (e: React.FormEvent<HTMLInputElement>) => {
    const target = e.target as HTMLInputElement;
    updateLocationDetails(target.name, target.checked);
  };

  // Dropdown Change handler
  const dropdownChangeHandler = (e: LocationFormEvent) => {
    console.log('dropdownvalue', e);
    onLocationDetailChange(e);
  };

  // approvedDate Change handler
  const activatedDateChangeHandler = (e: LocationFormEvent) => {
    onLocationDetailChange(e);
  };

  //filtering locationstatus based on locationtype
  const filterLocationStatus = () => {
    const locationStatusList = [...LOCATION_STATUS];
    const filteredList = locationStatusList.filter((item) => item.value !== 'PENDING');
    if (
      props.locationFormAction === LocationManagementForm.UPDATE &&
      locationDetailsData.locationStatus !== LocationStatus.PENDING
    ) {
      return filteredList;
    } else if (locationDetailsData.locationTypeCode === LocationType.PHYSICAL_BUILDING) {
      return filteredList;
    } else {
      return LOCATION_STATUS;
    }
  };
  const handleDateChange = (selectedDate: Date) => {
    updateLocationDetails(
      LocationDetailControl.ACTIVATED_DATE,
      formatDate(selectedDate, locationLabels.inputDateFormat),
    );
  };

  // LocationDropdown Props
  const locationDropdownvalidation = error[LocationDetailControl.PARENT_LOCATION_UUID];
  const dropdownConfig = {
    placeholderText: locationLabels.pleaseSelectPlaceHolder,
    isMandatory: true,
    isFilterEnabled: true,
    disabled: props.locationFormAction === LocationManagementForm.UPDATE || !locationDetailsData.partnerCode,
    inputFieldValidationError: locationDropdownvalidation,
    customMapper: { text: getTextKey(locationDetailsData.locationTypeCode) },
  };
  const isValidateTestCenter = (locationTypeCode: string) => locationTypeCode === LocationType.TEST_CENTRE;

  const getTopHeaderDetails = () => {
    return (
      <div id="locationDetails" className={cx(styles.col3, styles.ogFormGrid, styles.ogGridPadding)}>
        <UI.Dropdown
          id={LocationDetailControl.LOCATION_TYPE_CODE}
          label={locationLabels.locationType}
          labelId="locationTypeLB"
          placeholder={locationLabels.pleaseSelectPlaceHolder}
          mandatory
          selectedPartner={{
            value: locationDetailsData.locationTypeCode,
            text: locationDetailsData.locationTypeCodeText,
          }}
          selectedValue={locationDetailsData.locationTypeCode}
          inputFieldValidation={error[LocationDetailControl.LOCATION_TYPE_CODE]}
          list={LOCATION_TYPES}
          disable={props.locationFormAction === LocationManagementForm.UPDATE}
          onChange={(value: string, text: string) => {
            dropdownChangeHandler({
              name: LocationDetailControl.LOCATION_TYPE_CODE,
              value: value,
            });
            dropdownChangeHandler({
              name: LocationDetailControl.LOCATION_TYPE_CODE_TEXT,
              value: text,
            });
          }}
        />

        <PartnerDropDown
          id={LocationDetailControl.PARTNER_CODE}
          labelId={'partnerCodeLbl'}
          label={locationLabels.partnerCode}
          // selectedPartner={{ value: locationDetailsData.partnerCode, text: locationDetailsData.partnerCodeText }}
          selectedPartner={locationDetailsData.partnerCode}
          textBoxPlaceHolder={locationLabels.pleaseSelectPlaceHolder}
          serviceRequest={props.serviceRequest}
          canUseStoreData
          isFilterEnabled={false}
          isMandatory
          isDisable={
            props.locationFormAction === LocationManagementForm.UPDATE || !locationDetailsData.locationTypeCode
          }
          hiddenPartner={[Partner.Global]}
          onPartnerChange={(value: string, text: string) => {
            dropdownChangeHandler({
              name: LocationDetailControl.PARTNER_CODE,
              value: value,
            });
            dropdownChangeHandler({
              name: LocationDetailControl.PARTNER_CODE_TEXT,
              value: text,
            });
          }}
        />

        <LocationDropdown
          id={LocationDetailControl.PARENT_LOCATION_UUID}
          dropdownConfig={dropdownConfig}
          labelText={
            locationDetailsData.locationTypeCode === LocationType.TEST_CENTRE
              ? locationLabels.parentLocation
              : locationLabels.parentLocationUUID
          }
          value={locationDetailsData.parentLocationUuid}
          text={locationDetailsData.parentLocationName}
          locationType={getDropdownLocationType(locationDetailsData.locationTypeCode, locationDetailsData.partnerCode)}
          partnerCode={locationDetailsData.partnerCode}
          isDisable={!locationDetailsData.partnerCode}
          dataSource={'searchLocations'}
          onChange={({ value, text }: DropDownDataSource) => {
            dropdownChangeHandler({
              name: LocationDetailControl.PARENT_LOCATION_UUID,
              value: value,
            });
            dropdownChangeHandler({
              name: LocationDetailControl.PARENT_LOCATION_TEXT,
              value: text,
            });

            locationDetailsData.locationTypeCode === LocationType.PHYSICAL_BUILDING &&
              updateLocationDetails(LocationDetailControl.TESTCENTER_NUMER, text);
          }}
        />
      </div>
    );
  };

  const getOtherLocationDetails = () => {
    return (
      <div className={cx(styles.col3, styles.ogFormGrid, styles.ogGridPadding, styles.locationOtherInfo)}>
        {locationDetailsData.locationTypeCode === LocationType.PHYSICAL_BUILDING ? (
          <UI.TextBox
            label={locationLabels.locationName}
            labelId="locationNameLbl"
            value={locationDetailsData.locationName}
            name={LocationDetailControl.LOCATION_NAME}
            id={LocationDetailControl.LOCATION_NAME}
            mandatory
            placeholder={locationLabels.pleaseEnterPlaceHolder}
            onChange={handleTextBoxChange}
            inputFieldValidation={error[LocationDetailControl.LOCATION_NAME]}
          />
        ) : null}

        <UI.TextBox
          label={locationLabels.externalLocationUUID}
          labelId="externalLocationUUIDLbl"
          value={locationDetailsData.externalLocationUuid}
          name={LocationDetailControl.EXTERNAL_LOCATION_UUID}
          id={LocationDetailControl.EXTERNAL_LOCATION_UUID}
          mandatory
          placeholder={locationLabels.pleaseEnterPlaceHolder}
          onChange={handleTextBoxChange}
          inputFieldValidation={error[LocationDetailControl.EXTERNAL_LOCATION_UUID]}
        />

        <UI.TextBox
          label={locationLabels.externalParentLocation}
          labelId="externalParentLocationLbl"
          value={locationDetailsData.externalParentLocationUuid}
          name={LocationDetailControl.EXTERNAL_PARTNER_LOCATION_UUID}
          id={LocationDetailControl.EXTERNAL_PARTNER_LOCATION_UUID}
          placeholder={locationLabels.pleaseEnterPlaceHolder}
          onChange={handleTextBoxChange}
          inputFieldValidation={error[LocationDetailControl.EXTERNAL_PARTNER_LOCATION_UUID]}
        />

        <UI.TextBox
          label={locationLabels.testCenterNumber}
          labelId="testCenterNumberLbl"
          value={locationDetailsData.testCentreNumber}
          name={LocationDetailControl.TESTCENTER_NUMER}
          mandatory
          id={LocationDetailControl.TESTCENTER_NUMER}
          placeholder={locationLabels.pleaseEnterPlaceHolder}
          onChange={handleTextBoxChange}
          inputDisabled={
            locationDetailsData.locationTypeCode === LocationType.PHYSICAL_BUILDING ||
            props.locationFormAction === LocationManagementForm.UPDATE
          }
          inputFieldValidation={error[LocationDetailControl.TESTCENTER_NUMER]}
        />

        {isValidateTestCenter(locationDetailsData.locationTypeCode) ? (
          <UI.TextBox
            label={locationLabels.locationName}
            labelId="locationNameLbl"
            value={locationDetailsData.locationName}
            name={LocationDetailControl.LOCATION_NAME}
            id={LocationDetailControl.LOCATION_NAME}
            mandatory
            placeholder={locationLabels.pleaseEnterPlaceHolder}
            onChange={handleTextBoxChange}
            inputFieldValidation={error[LocationDetailControl.LOCATION_NAME]}
          />
        ) : null}

        <UI.TextBox
          label={locationLabels.timezoneName}
          labelId="timezoneNameLbl"
          value={locationDetailsData.timezoneName}
          name={LocationDetailControl.TIMEZONE_NAME}
          id={LocationDetailControl.TIMEZONE_NAME}
          mandatory
          placeholder={locationLabels.pleaseEnterPlaceHolder}
          inputFieldValidation={error[LocationDetailControl.TIMEZONE_NAME]}
          onChange={handleTextBoxChange}
        />
        {isValidateTestCenter(locationDetailsData.locationTypeCode) ? (
          <UI.TextBox
            label={locationLabels.websiteURL}
            labelId="crmSytemLbl"
            value={locationDetailsData.websiteURL}
            name={LocationDetailControl.WEBSITE_URL}
            id={LocationDetailControl.WEBSITE_URL}
            placeholder={locationLabels.pleaseEnterPlaceHolder}
            onChange={handleTextBoxChange}
            inputFieldValidation={error[LocationDetailControl.WEBSITE_URL]}
          />
        ) : null}

        <div className={styles.dateWrapper}>
          <div className={styles.dateLabel} id="activatedDateLbl">
            {locationLabels.activatedDate}
          </div>
          <span>
            <UI.DatePicker
              id={LocationDetailControl.ACTIVATED_DATE}
              minDate="1900-01-01"
              maxDate="2100-12-31"
              name={LocationDetailControl.ACTIVATED_DATE}
              value={locationDetailsData.activatedDate}
              onChange={handleDateChange}
              resetDate={
                locationDetailsData.activatedDate
                  ? activatedDateChangeHandler
                  : locationDetailsData.activatedDate === ''
              }
            />
            {/*  Need to move this to library */}
            {error[LocationDetailControl.ACTIVATED_DATE]?.isValid === false ? (
              <div>
                <p className={styles.textBoxError}>{locationLabels.approvedDateError}</p>
              </div>
            ) : null}
          </span>
        </div>
        <UI.Dropdown
          id={LocationDetailControl.LOCATION_STATUS}
          label={locationLabels.locationStatus}
          labelId="LocationStatusLbl"
          // disable={isLocationStatusDisabled(locationDetailsData)}
          placeholder={locationLabels.pleaseSelectPlaceHolder}
          selectedValue={locationDetailsData.locationStatus}
          list={filterLocationStatus()}
          inputFieldValidation={error[LocationDetailControl.LOCATION_STATUS]}
          onChange={(value: string) => {
            dropdownChangeHandler({
              name: LocationDetailControl.LOCATION_STATUS,
              value: value,
            });
          }}
        />
        {isValidateTestCenter(locationDetailsData.locationTypeCode) ? (
          <UI.ToggleSwitch
            elementLabel={getKey(TOGGLESWITCH, locationDetailsData.eligibleForOfflineTesting)}
            checked={locationDetailsData.eligibleForOfflineTesting}
            label={locationLabels.eligibleForOfflineTesting}
            name={LocationDetailControl.ELIGIBLE_FOR_OFFLINE_TESTING}
            color={TOGGLE_COLOR.LABEL_COLOR}
            onChange={handleToggleChange}
            labelId="EligibleofflineTestingLbl"
          />
        ) : null}
      </div>
    );
  };

  return (
    <div>
      <div className={styles.locationContainer}>{getTopHeaderDetails()}</div>
      {showOtherDetails(locationDetailsData) ? (
        <div className={styles.locationContainer}>{getOtherLocationDetails()}</div>
      ) : null}
    </div>
  );
};

export default withServiceRequest(LocationDeatils);
