import React from 'react';
import UI from 'ielts-cmds-ui-component-library';

import { languageService } from '../../../services/Language/LanguageService';
import MoreIcon from '../../../assets/images/More.svg';
import { BanActionsProps } from '../../Pages/TestTakerBookingHistoryPage/TestTakerBookingHistoryPage';
import styles from './BanPanel.module.scss';
import ArrowUp from '../../../assets/images/Chevron_Up.svg';
import ArrowDown from '../../../assets/images/ArrowDown.svg';
import { Action } from '../../../services/Models/Api';
import { TesttakerBanInfo } from '../../../services/Models/TestTakerManagement';
import { format } from 'date-fns';
import { getBanReasonFromUuid } from '../../../services/API/Reference/BanReason';
import ManageUsersActions from '../../Molecules/ManageUsersActions/ManageUsersActions';

export interface BanPanelProps {
  banDetails: TesttakerBanInfo;
  banPeriodUuid: string;
  banActions: BanActionsProps[];
  banActionsClickHandler: (action: Action, index: number, banPeriodUuid: string) => void;
  index: number;
  isExpanded: boolean;
  onExpandClickHandler: (banPeriodUuid: string) => void;
  currentActionType: string;
  selectedToolTipIndex: number | null;
  toolTipClickHandler: (index: number) => void;
}

const BanPanel = (props: BanPanelProps) => {
  const isToolTipSelected = props.selectedToolTipIndex === props.index;

  const moreSelectedClass = isToolTipSelected ? styles.banActionsOpened : '';

  const testTakerLabels = languageService().testTaker;

  return (
    <div className={styles.banSubContainer}>
      <div className={props.isExpanded ? styles.expandedBan : styles.notExpandedBan}>
        <div className={styles.banContainer}>
          {/* ban details label */}
          <span className={styles.banLabel}>
            {testTakerLabels.banDetailsLabel} {props.index + 1}
          </span>

          {/* expand ban icon */}
          <span className={styles.banContainerExpandIcon}>
            <button onClick={() => props.onExpandClickHandler(props.banPeriodUuid)}>
              {props.isExpanded ? <img alt="" src={ArrowUp} /> : <img alt="" src={ArrowDown} />}
            </button>
          </span>

          {/* tool tip icon */}
          <span
            className={`${styles.banActionsContainer} ${moreSelectedClass} ${styles.moreBtn}`}
            id={'banActionsContainer' + props.index}
          >
            <button onClick={() => props.toolTipClickHandler(props.index)}>
              <img alt="" src={MoreIcon} />
            </button>

            {isToolTipSelected ? (
              <ManageUsersActions
                id={'ManageBookingHistoryActionContainer'}
                userActions={props.banActions}
                currentActionType={props.currentActionType}
                userActionsClickHandler={(action: Action) =>
                  props.banActionsClickHandler(action, props.index, props.banPeriodUuid)
                }
              />
            ) : null}
          </span>
        </div>

        {/* ban details content when expanded */}
        {props.isExpanded ? (
          <div className={styles.banDetailsContainerGrid}>
            <UI.DisplayLabelValuePair
              id={'startDate' + props.index}
              label={testTakerLabels.startDate}
              value={formattedDate(props.banDetails.effectiveFromDate)}
              type="regular"
              size={15}
            />

            <UI.DisplayLabelValuePair
              id={'endDate' + props.index}
              label={testTakerLabels.endDate}
              value={formattedDate(props.banDetails.effectiveToDate)}
              type="regular"
              size={15}
            />

            <UI.DisplayLabelValuePair
              id={'duration' + props.index}
              label={testTakerLabels.duration}
              value={calculateDuration()}
              type="regular"
              size={15}
            />

            <UI.DisplayLabelValuePair
              id={'banStatus' + props.index}
              label={testTakerLabels.banStatus}
              value={props.banDetails.status}
              type="regular"
              size={15}
            />

            <UI.DisplayLabelValuePair
              id={'loggedBy' + props.index}
              label={testTakerLabels.loggedBy}
              value={props.banDetails.updatedBy}
              type="regular"
              size={15}
            />

            <UI.DisplayLabelValuePair
              id={'partnerSecondaryApprover' + props.index}
              label={testTakerLabels.partnerSecondaryApprover}
              value={props.banDetails.partnerSecondaryApprover}
              type="regular"
              size={15}
            />

            <UI.DisplayLabelValuePair
              id={'reason' + props.index}
              label={testTakerLabels.reason}
              value={getBanReasonFromUuid(props.banDetails.reasonUuid)}
              type="regular"
              size={15}
            />
          </div>
        ) : (
          ''
        )}
      </div>
    </div>
  );

  function formattedDate(dateString: string) {
    if (dateString != null && dateString !== '') {
      const date = Date.parse(dateString);
      return format(date, 'dd-MM-yyyy');
    }
  }

  function calculateDuration() {
    const dateFrom = new Date(props.banDetails.effectiveFromDate);
    const yearStart = dateFrom.getUTCFullYear();

    const dateTo = new Date(props.banDetails.effectiveToDate);
    const yearEnd = dateTo.getUTCFullYear();

    const duration = Math.abs(yearEnd - yearStart);

    if (duration === 1) {
      return duration + ' ' + testTakerLabels.year;
    }
    if (duration <= 10) {
      return duration + ' ' + testTakerLabels.years;
    }
    return testTakerLabels.lifetime;
  }
};

export default BanPanel;
