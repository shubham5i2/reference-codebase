import React, { useState, useEffect } from 'react';
import { languageService } from '../../../services/Language/LanguageService';
import styles from './AddBan.module.scss';
import UI from 'ielts-cmds-ui-component-library';
import { formatDate } from '../../utils/utilities';
import { DropDownDataSource } from '../../../services/Models/UIModels';
import { getValue } from '../../../components/utils/utilities';
import { useAuth0 } from '@auth0/auth0-react';
import CloseIcon from '../../../assets/images/Close.svg';
import { getDurationList } from '../../../services/API/Reference/BanDuration';
import { format } from 'date-fns';
import { getOtherReason } from '../../../services/API/Reference/BanReason';
import { TestTakerInfo } from '../../../services/Models/TestTakerManagement';

export interface BanDetails {
  bannedPeriodUuid?: string;
  effectiveFromDate: string;
  duration: string;
  locationUuid: string;
  reasonUuid: string;
  banComments: string;
  partnerSecondaryApprover: string;
  updatedBy: string;
}

export interface AddBanProps {
  testTakerInfo: TestTakerInfo;
  testTakerUuid: string;
  onAddBanClickHandler: (newBan: BanDetails) => void;
  onCancelBanHandler: () => void;
  errorMessage: string | null;
  onRemoveErrorMessage: () => void;
  isStartDateEmpty: boolean;
  isDurationEmpty: boolean;
  isReasonEmpty: boolean;
  isPartnerSecondaryApproverEmpty: boolean;
  isBanCommentsMoreThan100Chars: boolean;
  isBanCommentWithNonOtherReason: boolean;
  isEmptyBanCommentWithOtherReason: boolean;
  isAddBanModalOpen: boolean;
  reasonOptions: DropDownDataSource[];
  updateStartDateToNotEmpty: () => void;
  updateDurationToNotEmpty: () => void;
  updateBanReasonToNotEmpty: () => void;
  updateSecondaryPartnerApproverToNotEmpty: () => void;
  updateSecondaryPartnerApproverEmpty: () => void;
  updateBanCommentsMoreThan100Chars: (isMoreThan100chars: boolean) => void;
  updateBanCommentWithNonOtherReason: (isEnteredWithOtherReason: boolean) => void;
  updateBanCommentWithOtherReason: (isOtherReasonAndEmptyComment: boolean) => void;
  closeConfirmationModal: () => void;
  callAddNewBanAPIwithPayload: (newBan: BanDetails) => void;
}

const initialNewBanDetails = {
  startDate: '',
  duration: '',
  banLocation: '',
  reason: '',
  banComment: '',
  partnerSecondaryApprover: '',
};

const AddBan = (props: AddBanProps) => {
  const { user } = useAuth0();
  const testTakerLabels = languageService().testTaker;

  const [newBanData, setNewBanData] = useState(initialNewBanDetails);

  const [isReasonDropDownOpen, setIsReasonDropDownOpen] = useState(false);
  const [isDurationDropDownOpen, setIsDurationDropDownOpen] = useState(false);

  const [banDurationOptions, setBanDurationOptions] = useState<DropDownDataSource[]>([]);
  const [reasonOptions, setReasonOptions] = useState<DropDownDataSource[]>([]);

  /* Use effects */
  useEffect(() => {
    setBanDurationOptions(getDurationList());
  }, [isDurationDropDownOpen]);

  useEffect(() => {
    setReasonOptions(props.reasonOptions);
  }, [isReasonDropDownOpen, props.reasonOptions]);

  /* Data change handlers */

  const handleStartDateChange = (selectedDate: Date) => {
    updateBanStartDate(selectedDate);
  };

  const onDurationChange = (value: string) => {
    updateBanDuration(value);
  };

  const onReasonChange = (value: string) => {
    updateBanReason(value);
  };

  const onPartnerSecondaryApproverChange = (value: string) => {
    updatePartnerSecondaryApprover(value);
  };

  const onBanCommentsChange = (value: string) => {
    updateBanComments(value);
  };

  /* drop downs open handlers */

  const durationDropDownOpenhandler = () => {
    setIsDurationDropDownOpen(true);
  };

  const reasonDropDownOpenhandler = () => {
    setIsReasonDropDownOpen(true);
  };

  const generateNewBanPayload = () => {
    const newBanPayload: BanDetails = {
      effectiveFromDate: newBanData.startDate,
      duration: newBanData.duration,
      locationUuid: globalLocationUuid(),
      reasonUuid: newBanData.reason,
      banComments: newBanData.banComment,
      partnerSecondaryApprover: newBanData.partnerSecondaryApprover,
      updatedBy: currentLoggedUser(),
    };
    return newBanPayload;
  };

  const renderToastErrorMsg = () => (
    <div className={styles.toastMessage} id="toastError">
      <UI.Message id="toastErrorMsg" color="error" dismissable onChange={props.onRemoveErrorMessage} visibleTill={5000}>
        {<label id="toastErrorLable">{props.errorMessage}</label>}
      </UI.Message>
    </div>
  );

  const renderConfirmationBox = () => (
    <div className={styles.confirmationModalContainer}>
      <span className={styles.banLabel}>{testTakerLabels.addBan}</span>

      <button className={styles.closeModalBtn} onClick={() => props.closeConfirmationModal()}>
        <img alt="" src={CloseIcon} />
      </button>

      <div className={`${styles.textBoxLabel} ${styles.mt22}`}>
        <span>{testTakerLabels.addBanConfirmation}</span>
      </div>

      <div className={`${styles.textBoxLabel} ${styles.mt22}`}>
        <span>
          {props.testTakerInfo.firstName} {props.testTakerInfo.lastName} ({props.testTakerUuid})
        </span>
      </div>

      <div className={styles.addBanFinalConfirmation}>
        {/* final confirmation button */}
        <button id={styles.confirmAddBanBtn} onClick={() => props.callAddNewBanAPIwithPayload(generateNewBanPayload())}>
          <span className={styles.addBanLabel}>Add Ban</span>
        </button>
      </div>
    </div>
  );

  return (
    <React.Fragment>
      {props.errorMessage ? renderToastErrorMsg() : null}

      <div className={styles.addBanMainDiv}>
        <div className={styles.addBanContainer}>
          {/* ban details label */}
          <div className={styles.banDetailsContainer}>
            <span className={styles.banLabel}>{testTakerLabels.banDetailsLabel}</span>
          </div>

          <div className={styles.addBanDetailsContainerGrid}>
            {/* Ban Start date */}
            <div>
              <div className={props.isStartDateEmpty ? styles.startDateError : styles.textBoxLabel}>
                {testTakerLabels.startDate}*
              </div>

              <div className={styles.datePicker}>
                <span>
                  <UI.DatePicker
                    id="banStartDate"
                    minDate="1900-01-01"
                    maxDate="2100-12-31"
                    value={newBanData.startDate}
                    customYearDropDownClass={styles.customYearDropDownPosition}
                    onChange={handleStartDateChange}
                    resetDate={newBanData.startDate === ''}
                    inputClass={
                      props.isStartDateEmpty
                        ? `${styles.startDateBox} ${styles.addRedBorderColor}`
                        : styles.startDateBox
                    }
                  />
                </span>
              </div>

              {/* Start date error message */}
              {props.isStartDateEmpty ? (
                <div className={styles.psaErrorMsg}>
                  <p className={styles.textBoxError}>{testTakerLabels.banStartDateError}</p>
                </div>
              ) : (
                ''
              )}
            </div>

            {/* Ban end date */}
            <div>
              <div
                className={
                  props.isDurationEmpty || props.isStartDateEmpty ? styles.startDateError : styles.textBoxLabel
                }
              >
                {testTakerLabels.endDate}*
              </div>

              <span className={styles.endDate}>{newBanData.startDate && newBanData.duration ? showEndDate() : ''}</span>
            </div>

            {/* Duration dropdown */}
            <div id="durationDropDownContainer">
              <div id={props.isDurationEmpty ? styles.durationContainerError : ''}>
                <UI.Dropdown
                  id={props.isDurationEmpty ? styles.durationDropDownError : styles.durationDropDown}
                  label={testTakerLabels.duration}
                  mandatory={true}
                  labelId={props.isDurationEmpty ? styles.banDurationLBError : styles.banDurationLB}
                  placeholder=""
                  selectedValue={newBanData.duration || ''}
                  inputFieldValidation={props.isDurationEmpty}
                  errorMessage={props.isDurationEmpty ? testTakerLabels.banDurationError : null}
                  list={banDurationOptions}
                  onChange={onDurationChange}
                  onDropDownOpen={durationDropDownOpenhandler}
                  showInputWithoutList
                />
              </div>
            </div>

            {/* Partner secondary approver text box */}
            <div>
              <div
                className={
                  props.isPartnerSecondaryApproverEmpty
                    ? `${styles.psatextBoxLabel} ${styles.addRedFontColor}`
                    : styles.psatextBoxLabel
                }
              >
                {testTakerLabels.partnerSecondaryApprover}*
              </div>

              <div>
                <input
                  className={
                    props.isPartnerSecondaryApproverEmpty
                      ? `${styles.psatextBox} ${styles.addRedBorderColor}`
                      : styles.textBox
                  }
                  type="text"
                  id="psapprover"
                  defaultValue={newBanData.partnerSecondaryApprover || ''}
                  onChange={(event) => onPartnerSecondaryApproverChange(event.target.value)}
                />
              </div>

              {/* Secondary approver error message */}
              {props.isPartnerSecondaryApproverEmpty ? (
                <div className={styles.psaErrorMsg}>
                  <p id={styles.partnerSecondaryApprover} className={styles.textBoxError}>
                    {testTakerLabels.banSecondaryApproverError}
                  </p>
                </div>
              ) : (
                ''
              )}
            </div>

            {/* Reason dropdown */}
            <div id={styles.fullWidth}>
              <div id={props.isReasonEmpty ? styles.reasonContainerError : ''}>
                <div className={styles.list}>
                  <UI.Dropdown
                    id={props.isReasonEmpty ? styles.reasonDropDownError : styles.reasonDropDown}
                    dropDownInputId={styles.reasonDropDownInput}
                    label={testTakerLabels.reason}
                    mandatory={true}
                    labelId={props.isReasonEmpty ? styles.reasonLBError : styles.reasonLB}
                    placeholder=""
                    selectedValue={newBanData.reason || ''}
                    inputFieldValidation={props.isReasonEmpty}
                    errorMessage={props.isReasonEmpty ? testTakerLabels.banReasonError : null}
                    list={reasonOptions}
                    onChange={onReasonChange}
                    onDropDownOpen={reasonDropDownOpenhandler}
                    showInputWithoutList
                  />
                </div>
              </div>
            </div>

            {/* ban comments */}
            <div id={styles.banCommentContainer}>
              <span className={styles.banCommentSection}>
                {testTakerLabels.banCommentsOption} <br></br>
              </span>
              <span className={styles.banCommentSection}>{testTakerLabels.banCommentsMaxChars}</span>

              <textarea
                placeholder={testTakerLabels.banCommentsPlaceholder}
                className={styles.textBox}
                id={newBanData.banComment ? styles.banCommentFilled : styles.banComment}
                defaultValue={newBanData.banComment || ''}
                onChange={(event) => onBanCommentsChange(event.target.value)}
              />

              {props.isBanCommentsMoreThan100Chars ? (
                <div>
                  <p id="banCommentsError" className={styles.textBoxError}>
                    {testTakerLabels.banCommentsError}
                  </p>
                </div>
              ) : (
                ''
              )}

              {props.isBanCommentWithNonOtherReason ? (
                <div>
                  <p id="banCommentsWithNonOtherReasonError" className={styles.textBoxError}>
                    {testTakerLabels.banCommentsWithNonOtherReasonError}
                  </p>
                </div>
              ) : (
                ''
              )}
              {props.isEmptyBanCommentWithOtherReason ? (
                <div>
                  <p id="emptyBanCommentsWithOtherReasonError" className={styles.textBoxError}>
                    {testTakerLabels.emptyBanCommentsWithOtherReasonError}
                  </p>
                </div>
              ) : (
                ''
              )}
            </div>
          </div>
        </div>
      </div>

      <div className={styles.addBanButtons}>
        {/* cancel Add ban button */}
        <button className={styles.cancelAddBanBtn} onClick={() => props.onCancelBanHandler()}>
          <span>{testTakerLabels.cancel}</span>
        </button>

        {/* add ban button */}
        <button className={styles.addBanBtn} onClick={() => props.onAddBanClickHandler(generateNewBanPayload())}>
          <span className={styles.addBanLabel}>{testTakerLabels.addBan}</span>
        </button>
      </div>

      {/* Add ban confirmation modal */}
      {props.isAddBanModalOpen ? (
        <div>
          <UI.ModalDialog>{renderConfirmationBox()}</UI.ModalDialog>
        </div>
      ) : null}
    </React.Fragment>
  );

  function updateBanStartDate(selectedDate: Date) {
    setNewBanData({
      ...newBanData,
      startDate: formatDate(selectedDate, testTakerLabels.inputDateFormat),
    });
    props.updateStartDateToNotEmpty();
  }

  function updateBanDuration(value: string) {
    setNewBanData({ ...newBanData, duration: value });
    props.updateDurationToNotEmpty();
  }

  function updateBanReason(value: string) {
    setNewBanData({ ...newBanData, reason: value });
    props.updateBanReasonToNotEmpty();

    const isBanCommentAndNonOtherReason = newBanData.banComment !== '' && value !== getOtherReason();
    props.updateBanCommentWithNonOtherReason(isBanCommentAndNonOtherReason);

    const isOtherReasonAndEmptyComment = value === getOtherReason() && isNullOrEmpty(newBanData.banComment);
    props.updateBanCommentWithOtherReason(isOtherReasonAndEmptyComment);
  }

  function updatePartnerSecondaryApprover(value: string) {
    if (value.trim().length !== 0) {
      setNewBanData({ ...newBanData, partnerSecondaryApprover: value });
      props.updateSecondaryPartnerApproverToNotEmpty();
    } else {
      props.updateSecondaryPartnerApproverEmpty();
    }
  }

  function updateBanComments(value: string) {
    setNewBanData({ ...newBanData, banComment: value });
    props.updateBanCommentsMoreThan100Chars(value.length > 99);

    const isBanCommentAndNonOtherReason = value !== '' && newBanData.reason !== getOtherReason();
    props.updateBanCommentWithNonOtherReason(isBanCommentAndNonOtherReason);

    const isOtherReasonAndEmptyComment = newBanData.reason === getOtherReason() && isNullOrEmpty(value);
    props.updateBanCommentWithOtherReason(isOtherReasonAndEmptyComment);
  }

  function currentLoggedUser() {
    return getValue(user?.given_name).trim() + ' ' + getValue(user?.family_name).trim() || '';
  }

  function globalLocationUuid() {
    return 'c6d6b795-b20b-466c-92ef-7a53752e238c';
  }

  function showEndDate() {
    const startdate = new Date(newBanData.startDate);
    let endYear = null;

    if (newBanData.duration !== 'Lifetime') {
      endYear = startdate.getFullYear() + parseInt(newBanData.duration);
    } else {
      endYear = startdate.getFullYear() + 99;
    }
    const endDate = new Date(endYear, startdate.getMonth(), startdate.getDate());
    return format(endDate, 'dd MMM yyyy');
  }

  function isNullOrEmpty(field: string) {
    return field === null || field === '';
  }
};

export default AddBan;
