import React, { useState, useEffect } from 'react';
import { languageService } from '../../../services/Language/LanguageService';
import styles from './UpdateBan.module.scss';
import UI from 'ielts-cmds-ui-component-library';
import { DropDownDataSource } from '../../../services/Models/UIModels';
import { getValue, formatDate } from '../../utils/utilities';
import { useAuth0 } from '@auth0/auth0-react';
import CloseIcon from '../../../assets/images/Close.svg';
import { getDurationList } from '../../../services/API/Reference/BanDuration';
import { format } from 'date-fns';
import { getBanReasonFromUuid, getOtherReason } from '../../../services/API/Reference/BanReason';
import { TesttakerBanInfo, TestTakerInfo, UpdateBanDetails } from '../../../services/Models/TestTakerManagement';

export interface UpdateBanProps {
  testTakerInfo: TestTakerInfo;
  testTakerUuid: string;
  existingBanDetails: TesttakerBanInfo;
  onUpdateBanClickHandler: (updatedBan: UpdateBanDetails) => void;
  onCancelUpdateActionHandler: () => void;
  errorMessage: string | null;
  onRemoveErrorMessage: () => void;
  isStartDateEmpty: boolean;
  isDurationEmpty: boolean;
  isReasonEmpty: boolean;
  isPartnerSecondaryApproverEmpty: boolean;
  isBanCommentsMoreThan100Chars: boolean;
  isBanCommentWithNonOtherReason: boolean;
  isEmptyBanCommentWithOtherReason: boolean;
  isUpdateBanModalOpen: boolean;
  reasonOptions: DropDownDataSource[];
  updateStartDateToNotEmpty: () => void;
  updateDurationToNotEmpty: () => void;
  updateBanReasonToNotEmpty: () => void;
  updateSecondaryPartnerApproverToNotEmpty: () => void;
  updateSecondaryPartnerApproverEmpty: () => void;
  updateBanCommentsMoreThan100Chars: (isMoreThan100chars: boolean) => void;
  updateBanCommentWithNonOtherReason: (isEnteredWithOtherReason: boolean) => void;
  updateBanCommentWithOtherReason: (isOtherReasonAndEmptyComment: boolean) => void;
  closeConfirmationModal: () => void;
  callUpdateBanAPIwithPayload: (updatedBan: UpdateBanDetails) => void;
}

const UpdateBan = (props: UpdateBanProps) => {
  const initialUpdateBanDetails = {
    startDate: props.existingBanDetails.effectiveFromDate,
    duration: props.existingBanDetails.duration,
    reason: props.existingBanDetails.reasonUuid,
    banComment: props.existingBanDetails.banComments,
    partnerSecondaryApprover: props.existingBanDetails.partnerSecondaryApprover,
  };

  const { user } = useAuth0();
  const testTakerLabels = languageService().testTaker;

  const [updatedBanData, setUpdatedBanData] = useState(initialUpdateBanDetails);

  const [isReasonDropDownOpen, setIsReasonDropDownOpen] = useState(false);
  const [isDurationDropDownOpen, setIsDurationDropDownOpen] = useState(false);

  const [banDurationOptions, setBanDurationOptions] = useState<DropDownDataSource[]>([]);
  const [reasonOptions, setReasonOptions] = useState<DropDownDataSource[]>([]);

  /* Use effects */
  useEffect(() => {
    setBanDurationOptions(getDurationList());
  }, [isDurationDropDownOpen]);

  useEffect(() => {
    setReasonOptions(props.reasonOptions);
  }, [isReasonDropDownOpen, props.reasonOptions]);

  /* Data change handlers */

  const handleStartDateChange = (selectedDate: Date) => {
    updateBanStartDate(selectedDate);
  };

  const onDurationChange = (value: string) => {
    updateBanDuration(value);
  };

  const onReasonChange = (value: string) => {
    updateBanReason(value);
  };

  const onPartnerSecondaryApproverChange = (value: string) => {
    updatePartnerSecondaryApprover(value);
  };

  const onBanCommentsChange = (value: string) => {
    updateBanComments(value);
  };

  /* drop downs open handlers */

  const durationDropDownOpenhandler = () => {
    setIsDurationDropDownOpen(true);
  };

  const reasonDropDownOpenhandler = () => {
    setIsReasonDropDownOpen(true);
  };

  const generateUpdateBanPayload = () => {
    const updateBanPayload: UpdateBanDetails = {
      bannedPeriodUuid: props.existingBanDetails.bannedPeriodUuid,
      effectiveFromDate: updatedBanData.startDate,
      duration: updatedBanData.duration,
      locationUuid: globalLocationUuid(),
      reasonUuid: updatedBanData.reason,
      banComments: updatedBanData.banComment,
      partnerSecondaryApprover: updatedBanData.partnerSecondaryApprover,
      updatedBy: currentLoggedUser(),
    };
    return updateBanPayload;
  };

  const renderToastErrorMsg = () => (
    <div className={styles.toastMessage} id="toastError">
      <UI.Message id="toastErrorMsg" color="error" dismissable onChange={props.onRemoveErrorMessage} visibleTill={5000}>
        {<label id="toastErrorLable">{props.errorMessage}</label>}
      </UI.Message>
    </div>
  );

  // To update to GenericPopUp component once working correctly
  const renderConfirmationBox = () => (
    <div className={styles.confirmationModalContainer}>
      <span className={styles.banLabel}>{testTakerLabels.updateBan}</span>

      <button className={styles.closeModalBtn} onClick={() => props.closeConfirmationModal()}>
        <img alt="" src={CloseIcon} />
      </button>

      <div className={`${styles.textBoxLabel} ${styles.mt22}`}>
        <span>{testTakerLabels.updateBanConfirmation}</span>
      </div>

      <div className={`${styles.textBoxLabel} ${styles.mt22}`}>
        <span>
          {props.testTakerInfo.firstName} {props.testTakerInfo.lastName} ({props.testTakerUuid})
        </span>
      </div>

      <div className={styles.updateBanFinalConfirmation}>
        {/* final confirmation button */}
        <button
          id={styles.confirmUpdateBanBtn}
          onClick={() => props.callUpdateBanAPIwithPayload(generateUpdateBanPayload())}
        >
          <span className={styles.updateBanLabel}>Update Ban</span>
        </button>
      </div>
    </div>
  );

  return (
    <React.Fragment>
      {props.errorMessage ? renderToastErrorMsg() : null}

      <div className={styles.updateBanMainDiv}>
        <div className={styles.updateBanContainer}>
          {/* ban details label */}
          <div className={styles.banDetailsContainer}>
            <span className={styles.banLabel}>{testTakerLabels.banDetailsLabel}</span>
          </div>

          <div className={styles.updateBanDetailsContainerGrid}>
            {/* Ban Start date */}
            <div>
              <div className={props.isStartDateEmpty ? styles.startDateError : styles.textBoxLabel}>
                {testTakerLabels.startDate}*
              </div>

              <div className={styles.datePicker}>
                <span>
                  <UI.DatePicker
                    id="banStartDate"
                    minDate="1900-01-01"
                    maxDate="2100-12-31"
                    value={updatedBanData.startDate}
                    customYearDropDownClass={styles.customYearDropDownPosition}
                    onChange={handleStartDateChange}
                    resetDate={updatedBanData.startDate === ''}
                    inputClass={
                      props.isStartDateEmpty
                        ? `${styles.startDateBox} ${styles.addRedBorderColor}`
                        : styles.startDateBox
                    }
                  />
                </span>
              </div>

              {/* Start date error message */}
              {props.isStartDateEmpty ? (
                <div className={styles.psaErrorMsg}>
                  <p className={styles.textBoxError}>{testTakerLabels.banStartDateError}</p>
                </div>
              ) : (
                ''
              )}
            </div>

            {/* Ban end date */}
            <div>
              <div
                className={
                  props.isDurationEmpty || props.isStartDateEmpty ? styles.startDateError : styles.textBoxLabel
                }
              >
                {testTakerLabels.endDate}*
              </div>

              <span className={styles.endDate}>
                {updatedBanData.startDate && updatedBanData.duration ? showEndDate() : ''}
              </span>
            </div>

            {/* Duration dropdown */}
            <div id="durationDropDownContainer">
              <div id={props.isDurationEmpty ? styles.durationContainerError : ''}>
                <UI.Dropdown
                  id={props.isDurationEmpty ? styles.durationDropDownError : styles.durationDropDown}
                  label={testTakerLabels.duration}
                  mandatory={true}
                  labelId={props.isDurationEmpty ? styles.banDurationLBError : styles.banDurationLB}
                  placeholder=""
                  selectedValue={updatedBanData.duration || ''}
                  inputFieldValidation={props.isDurationEmpty}
                  errorMessage={props.isDurationEmpty ? testTakerLabels.banDurationError : null}
                  list={banDurationOptions}
                  onChange={onDurationChange}
                  onDropDownOpen={durationDropDownOpenhandler}
                  showInputWithoutList
                />
              </div>
            </div>
            <div>
              <div className={styles.psatextBoxLabel}>{testTakerLabels.banStatus}*</div>
              <span className={styles.status}>{props.existingBanDetails.status}</span>
            </div>
            <div>
              <div className={styles.psatextBoxLabel}>{testTakerLabels.loggedBy}*</div>
              <span className={styles.loggedBy}>{props.existingBanDetails.updatedBy}</span>
            </div>

            {/* Partner secondary approver text box */}
            <div>
              <div
                className={
                  props.isPartnerSecondaryApproverEmpty
                    ? `${styles.psatextBoxLabel} ${styles.addRedFontColor}`
                    : styles.psatextBoxLabel
                }
              >
                {testTakerLabels.partnerSecondaryApprover}*
              </div>

              <div>
                <input
                  className={
                    props.isPartnerSecondaryApproverEmpty
                      ? `${styles.psatextBox} ${styles.addRedBorderColor}`
                      : styles.textBox
                  }
                  type="text"
                  id="psapprover"
                  defaultValue={updatedBanData.partnerSecondaryApprover || ''}
                  onChange={(event) => onPartnerSecondaryApproverChange(event.target.value)}
                />
              </div>

              {/* Secondary approver error message */}
              {props.isPartnerSecondaryApproverEmpty ? (
                <div className={styles.psaErrorMsg}>
                  <p id={styles.partnerSecondaryApprover} className={styles.textBoxError}>
                    {testTakerLabels.banSecondaryApproverError}
                  </p>
                </div>
              ) : (
                ''
              )}
            </div>

            {/* Reason dropdown */}
            <div id={styles.fullWidth}>
              <div id={props.isReasonEmpty ? styles.reasonContainerError : ''}>
                <div className={styles.list}>
                  <UI.Dropdown
                    id={props.isReasonEmpty ? styles.reasonDropDownError : styles.reasonDropDown}
                    dropDownInputId={styles.reasonDropDownInput}
                    label={testTakerLabels.reason}
                    mandatory={true}
                    labelId={props.isReasonEmpty ? styles.reasonLBError : styles.reasonLB}
                    placeholder={getBanReasonFromUuid(props.existingBanDetails.reasonUuid) || ''}
                    selectedValue={updatedBanData.reason || ''}
                    inputFieldValidation={props.isReasonEmpty}
                    errorMessage={props.isReasonEmpty ? testTakerLabels.banReasonError : null}
                    list={reasonOptions}
                    onChange={onReasonChange}
                    onDropDownOpen={reasonDropDownOpenhandler}
                    showInputWithoutList
                  />
                </div>
              </div>
            </div>

            {/* ban comments */}
            <div id={styles.banCommentContainer}>
              <span className={styles.banCommentSection}>
                {testTakerLabels.banCommentsOption} <br></br>
              </span>
              <span className={styles.banCommentSection}>{testTakerLabels.banCommentsMaxChars}</span>

              <textarea
                placeholder={testTakerLabels.banCommentsPlaceholder}
                className={styles.textBox}
                id={updatedBanData.banComment ? styles.banCommentFilled : styles.banComment}
                defaultValue={updatedBanData.banComment || ''}
                onChange={(event) => onBanCommentsChange(event.target.value)}
              />

              {props.isBanCommentsMoreThan100Chars ? (
                <div>
                  <p id="banCommentsError" className={styles.textBoxError}>
                    {testTakerLabels.banCommentsError}
                  </p>
                </div>
              ) : (
                ''
              )}

              {props.isBanCommentWithNonOtherReason ? (
                <div>
                  <p id="banCommentsWithNonOtherReasonError" className={styles.textBoxError}>
                    {testTakerLabels.banCommentsWithNonOtherReasonError}
                  </p>
                </div>
              ) : (
                ''
              )}
              {props.isEmptyBanCommentWithOtherReason ? (
                <div>
                  <p id="emptyBanCommentsWithOtherReasonError" className={styles.textBoxError}>
                    {testTakerLabels.emptyBanCommentsWithOtherReasonError}
                  </p>
                </div>
              ) : (
                ''
              )}
            </div>
          </div>
        </div>
      </div>

      <div className={styles.updateBanButtons}>
        {/* cancel update ban button */}
        <button className={styles.cancelUpdateBanBtn} onClick={() => props.onCancelUpdateActionHandler()}>
          <span>{testTakerLabels.cancel}</span>
        </button>

        {/* update ban button */}
        <button
          className={styles.updateBanBtn}
          onClick={() => props.onUpdateBanClickHandler(generateUpdateBanPayload())}
        >
          <span className={styles.updateBanLabel}>{testTakerLabels.updateBan}</span>
        </button>
      </div>

      {/* Update ban confirmation modal */}
      {props.isUpdateBanModalOpen ? (
        <div>
          <UI.ModalDialog>{renderConfirmationBox()}</UI.ModalDialog>
        </div>
      ) : null}
    </React.Fragment>
  );

  function updateBanStartDate(selectedDate: Date) {
    setUpdatedBanData({
      ...updatedBanData,
      startDate: formatDate(selectedDate, testTakerLabels.inputDateFormat),
    });
    props.updateStartDateToNotEmpty();
  }

  function updateBanDuration(value: string) {
    setUpdatedBanData({ ...updatedBanData, duration: value });
    props.updateDurationToNotEmpty();
  }

  function updateBanReason(value: string) {
    setUpdatedBanData({ ...updatedBanData, reason: value });
    props.updateBanReasonToNotEmpty();

    const isBanCommentAndNonOtherReason = updatedBanData.banComment !== '' && value !== getOtherReason();
    props.updateBanCommentWithNonOtherReason(isBanCommentAndNonOtherReason);

    const isOtherReasonAndEmptyComment = value === getOtherReason() && isNullOrEmpty(updatedBanData.banComment);
    props.updateBanCommentWithOtherReason(isOtherReasonAndEmptyComment);
  }

  function updatePartnerSecondaryApprover(value: string) {
    setUpdatedBanData({ ...updatedBanData, partnerSecondaryApprover: value });

    if (value.trim().length !== 0) {
      props.updateSecondaryPartnerApproverToNotEmpty();
    } else {
      props.updateSecondaryPartnerApproverEmpty();
    }
  }

  function updateBanComments(value: string) {
    setUpdatedBanData({ ...updatedBanData, banComment: value });
    props.updateBanCommentsMoreThan100Chars(value.length > 99);

    const isBanCommentAndNonOtherReason = value !== '' && updatedBanData.reason !== getOtherReason();
    props.updateBanCommentWithNonOtherReason(isBanCommentAndNonOtherReason);

    const isOtherReasonAndEmptyComment = updatedBanData.reason === getOtherReason() && isNullOrEmpty(value);
    props.updateBanCommentWithOtherReason(isOtherReasonAndEmptyComment);
  }

  function currentLoggedUser() {
    return getValue(user?.given_name).trim() + ' ' + getValue(user?.family_name).trim() || '';
  }

  function globalLocationUuid() {
    return 'c6d6b795-b20b-466c-92ef-7a53752e238c';
  }

  function showEndDate() {
    const startdate = new Date(updatedBanData.startDate);
    let endYear = null;

    if (updatedBanData.duration !== 'Lifetime') {
      endYear = startdate.getFullYear() + parseInt(updatedBanData.duration);
    } else {
      endYear = startdate.getFullYear() + 99;
    }
    const endDate = new Date(endYear, startdate.getMonth(), startdate.getDate());
    return format(endDate, 'dd MMM yyyy');
  }

  function isNullOrEmpty(field: string) {
    return field === null || field === '';
  }
};

export default UpdateBan;
