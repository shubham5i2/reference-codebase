import React, { useState } from 'react';
import styles from './PreReleaseCheckGrid.module.scss';
import { PreReleaseCheckSortOption, PreReleaseSearchResult } from '../../../services/Models/PreReleaseManagement';
import TestTakerGridCell from '../TestTakerGridCell/TestTakerGridCell';
import { TestTakerGridCellType } from '../ManageTestTakerGrid/ManageTestTakerGridConstants';
import preReleaseCheckLabels from '../../../services/Language/en/en.prereleasecheck';
import { Cell, Column } from 'react-table';
import PreReleaseDialog from '../../Others/PreReleaseDialog/PreReleaseDialog';
import { formatDate } from '../../utils/utilities';
import { GridProps } from '../../../services/Models/UIModels';
import UI from 'ielts-cmds-ui-component-library';
import {
  generateCheckOutComeStatusUuId,
  CheckOutComeStatusUuIdGenerationType,
} from '../../../../src/services/API/Reference/CheckOutcomeStatus';
import { MESSAGE_TIMER } from '../../Pages/ManageTestTakerPreReleaseCheck/ManageTestTakerPreReleaseCheckSearchPanel/ManageTestTakerPreReleaseCheckSearchPanel';
import withServiceRequest, { ServiceRequest } from '../../../services/utils/ServiceRequest';
import { preReleasePost } from '../../../services/API/PreReleaseSearch/PostPreReleaseData';
import { AsyncResponseStatus } from '../../../services/Models/Api';

interface PreReleaseCheckGridProps extends GridProps {
  data: PreReleaseSearchResult[];
  reloadData: () => void;
  pageNumber: number;
  serviceRequest: ServiceRequest;
  isLoading: boolean;
}

export enum PreReleaseCheckType {
  RELEASE = 'RELEASE',
  REFER_FOR_INVESTIGATION = 'REFER_FOR_INVESTIGATION',
}

enum PreReleaseType {
  SOLO = 'SOLO',
  BULK = 'BULK',
}

const PreReleaseCheckGrid = (props: PreReleaseCheckGridProps) => {
  const formattedData = props.data;
  const [postData, setPostData] = useState<string[]>([]);
  const [checkType, setCheckType] = useState<string>('');
  const [testTakerBookingUuIds, setTestTakerBookingUuIds] = useState<string[]>([]);
  const [isModalOpened, setIsModalOpened] = useState(false);
  const [isModalSoloOpener, setModalSoloOpener] = useState(false);
  const [gridData, setGridData] = useState<PreReleaseSearchResult[]>([]);
  const [pageMap, setPageMap] = useState(new Map<number, boolean>());
  const [pageSize, setPageSize] = useState(0);

  const bookingSelectionHandler = (index: number) => {
    setPageSize(props.gridState.initialState.pageSize);
    const testTakerId = formattedData[index].bookingUuid;
    setPageMap(new Map(pageMap.set(props.pageNumber, false)));
    const idx = testTakerBookingUuIds.indexOf(testTakerId);
    const gridDataIndex = gridData.findIndex((item: PreReleaseSearchResult) => item.bookingUuid === testTakerId);
    if (idx >= 0) {
      setTestTakerBookingUuIds(testTakerBookingUuIds.filter((item: string) => item !== testTakerBookingUuIds[idx]));
      gridDataIndex >= 0 &&
        setGridData(
          gridData.filter(
            (item: PreReleaseSearchResult) => JSON.stringify(item) !== JSON.stringify(gridData[gridDataIndex]),
          ),
        );
    } else {
      setTestTakerBookingUuIds((preState) => [testTakerId, ...preState]);
      gridDataIndex < 0 && setGridData((preState: PreReleaseSearchResult[]) => [formattedData[index], ...preState]);
    }
  };

  const modalCloseHandler = () => {
    setIsModalOpened(false);
    setModalSoloOpener(false);
    setCheckType('');
  };

  const dataClearHandler = () => {
    setTestTakerBookingUuIds([]);
    setGridData([]);
    pageMap.clear();
  };

  const outcomeStatusGenerator = (type: string) => {
    if (type === PreReleaseCheckType.RELEASE) {
      return generateCheckOutComeStatusUuId(CheckOutComeStatusUuIdGenerationType.PASSED);
    } else if (type === PreReleaseCheckType.REFER_FOR_INVESTIGATION) {
      return generateCheckOutComeStatusUuId(CheckOutComeStatusUuIdGenerationType.REFER);
    }
  };

  const preReleaseConfirmationHandler = (statusId: string) => {
    preReleasePost(postData, statusId, props.serviceRequest).subscribe((res) => {
      if (res && res.status === AsyncResponseStatus.SUCCESS) {
        dataClearHandler();
        modalCloseHandler();
        props.reloadData();
      }
    });
  };

  const preReleaseDataGenerator = (testTakerBookingUuIds: string[], gridData: PreReleaseSearchResult[]) => {
    return gridData.filter((item: PreReleaseSearchResult) => testTakerBookingUuIds.includes(item.bookingUuid));
  };

  const preReleaseModalHandler = () => {
    return (isModalOpened && testTakerBookingUuIds.length > 0) || (isModalOpened && isModalSoloOpener) ? (
      <PreReleaseDialog
        id="preReleaseDialogComponent"
        title={`${preReleaseCheckLabels.preReleaseCheckLabel}`}
        label={
          checkType === PreReleaseCheckType.RELEASE
            ? preReleaseCheckLabels.proceedReleaseLabel
            : preReleaseCheckLabels.proceedReferForInvestigationLabel
        }
        confirmationHandler={preReleaseConfirmationHandler}
        modalCloseHandler={modalCloseHandler}
        bookingInfo={
          isModalSoloOpener
            ? preReleaseDataGenerator(postData, formattedData)
            : preReleaseDataGenerator(postData, gridData)
        }
        statusUuId={outcomeStatusGenerator(checkType)}
      />
    ) : (
      isModalOpened && (
        <div className={styles.messageContainer}>
          <UI.Message
            message={preReleaseCheckLabels.preReleaseCriteriaError}
            color="error"
            dismissable
            onChange={modalCloseHandler}
            visibleTill={MESSAGE_TIMER}
          />
        </div>
      )
    );
  };

  const referForInvestigationHandler = (index: number, type: string) => {
    setCheckType(PreReleaseCheckType.REFER_FOR_INVESTIGATION);
    if (type === PreReleaseType.SOLO) {
      setPostData([formattedData[index].bookingUuid]);
      setIsModalOpened(true);
      setModalSoloOpener(true);
    } else if (type === PreReleaseType.BULK) {
      setPostData(testTakerBookingUuIds);
      setIsModalOpened(true);
    }
  };

  const dataEntry = () => {
    if (pageMap.has(props.pageNumber) && pageMap.get(props.pageNumber)) {
      formattedData.forEach((item: PreReleaseSearchResult) => {
        if (testTakerBookingUuIds.indexOf(item.bookingUuid) < 0) {
          setTestTakerBookingUuIds((preState: string[]) => [item.bookingUuid, ...preState]);
          const gridDataIndex = gridData.findIndex(
            (gridVal: PreReleaseSearchResult) => gridVal.bookingUuid === item.bookingUuid,
          );
          gridDataIndex < 0 && setGridData((preState: PreReleaseSearchResult[]) => [item, ...preState]);
        }
      });
    }
  };
  const selectionAllHandler = () => {
    const sizeCheck = pageSize === props.gridState.initialState.pageSize;
    !sizeCheck && pageMap.clear();
    const selection = pageMap.has(props.pageNumber) ? !pageMap.get(props.pageNumber) : true;
    if (selection) {
      setPageMap(new Map(pageMap.set(props.pageNumber, true)));
      setPageSize(props.gridState.initialState.pageSize);
      dataEntry();
    } else {
      setPageMap(new Map(pageMap.set(props.pageNumber, false)));
      formattedData.forEach((item: PreReleaseSearchResult) => {
        const idx = testTakerBookingUuIds.indexOf(item.bookingUuid);
        idx >= 0 &&
          setTestTakerBookingUuIds((preState: string[]) =>
            preState.filter((bookingId: string) => item.bookingUuid !== bookingId),
          );
      });
    }
  };

  const releaseHandler = (index: number, type: string) => {
    setCheckType(PreReleaseCheckType.RELEASE);
    if (type === PreReleaseType.SOLO) {
      setPostData([formattedData[index].bookingUuid]);
      setIsModalOpened(true);
      setModalSoloOpener(true);
    } else if (type === PreReleaseType.BULK) {
      setPostData(testTakerBookingUuIds);
      setIsModalOpened(true);
    }
  };
  const defaultCheckHandlerForSelectAll = (index: number) =>
    gridData.findIndex((item: PreReleaseSearchResult) => item.bookingUuid === formattedData[index].bookingUuid) >= 0;
  const defaultCheckHandler = (index: number) => testTakerBookingUuIds.indexOf(formattedData[index].bookingUuid) >= 0;

  const getPreReleaseGridItem = (cellProps: Cell, name: string) => {
    return <TestTakerGridCell id={name} cellType={name} value={cellProps.value} />;
  };

  const columns = [
    {
      id: 'expander',
      Header: {
        label: (
          <TestTakerGridCell
            id="checkBox_select_all"
            cellType={TestTakerGridCellType.CHECKBOX}
            onChangeHandler={() => selectionAllHandler()}
            defaultCheck={
              pageMap.has(props.pageNumber) &&
              pageMap.get(props.pageNumber) &&
              pageSize === props.gridState.initialState.pageSize
            }
          />
        ),
      },
      Cell: (cellProps: Cell) => {
        const index = cellProps.row.index;
        return (
          <TestTakerGridCell
            id="checkBox"
            cellType={TestTakerGridCellType.CHECKBOX}
            defaultCheck={
              pageMap.has(props.pageNumber) && pageMap.get(props.pageNumber)
                ? defaultCheckHandlerForSelectAll(index)
                : defaultCheckHandler(index)
            }
            onChangeHandler={() => bookingSelectionHandler(index)}
          />
        );
      },
      disableSortBy: true,
    },
    {
      Header: {
        label: preReleaseCheckLabels.uniqueTestTakerId.toUpperCase(),
        name: PreReleaseCheckSortOption.UNIQUE_TEST_TAKER_ID,
      },
      accessor: 'uniqueTestTakerId',
      sortType: 'basic',
      Cell: (cellProps: Cell) => getPreReleaseGridItem(cellProps, TestTakerGridCellType.UNIQUETESTTAKERID),
    },
    {
      Header: {
        label: preReleaseCheckLabels.ttbhBookingTestDate.toUpperCase(),
        name: PreReleaseCheckSortOption.TEST_DATE,
      },
      accessor: 'testDate',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell
          id="testDate"
          cellType={TestTakerGridCellType.TESTDATE}
          value={formatDate(new Date(cellProps.value), preReleaseCheckLabels.uiDateFormat)}
        />
      ),
    },
    {
      Header: {
        label: preReleaseCheckLabels.ttcentreNumberLabel.toUpperCase(),
        name: PreReleaseCheckSortOption.CENTRE_ID,
      },
      accessor: 'centreId',
      Cell: (cellProps: Cell) => getPreReleaseGridItem(cellProps, TestTakerGridCellType.TESTCENTRE),
    },
    {
      Header: {
        label: preReleaseCheckLabels.ttNumberLabel.toUpperCase(),
        name: PreReleaseCheckSortOption.SHORT_CANDIDATE_NUMBER,
      },
      accessor: 'shortCandidateNumber',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell
          id="shortCandidateNumber"
          cellType={TestTakerGridCellType.TESTTAKERNUMBER}
          value={String(cellProps.value).padStart(6, '0')}
        />
      ),
    },
    {
      Header: {
        label: preReleaseCheckLabels.identityDocumentNumber.toUpperCase(),
        name: PreReleaseCheckSortOption.IDENTITY_DOCUMENT_NUMBER,
      },
      accessor: 'identityNumber',
      Cell: (cellProps: Cell) => getPreReleaseGridItem(cellProps, TestTakerGridCellType.IDENTITYDOCUMENTNUMBER),
    },
    {
      Header: {
        label: preReleaseCheckLabels.givenName.toUpperCase(),
        name: PreReleaseCheckSortOption.GIVEN_NAME,
      },
      accessor: 'firstName',
      Cell: (cellProps: Cell) => getPreReleaseGridItem(cellProps, TestTakerGridCellType.GIVENNAME),
    },
    {
      Header: {
        label: preReleaseCheckLabels.familyName.toUpperCase(),
        name: PreReleaseCheckSortOption.FAMILY_NAME,
      },
      accessor: 'lastName',
      Cell: (cellProps: Cell) => getPreReleaseGridItem(cellProps, TestTakerGridCellType.FAMILYNAME),
    },
    {
      Header: {
        label: preReleaseCheckLabels.dateOfBirth.toUpperCase(),
        name: PreReleaseCheckSortOption.DATE_OF_BIRTH,
      },
      accessor: 'birthDate',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell
          id="birthDate"
          cellType={TestTakerGridCellType.DATEOFBIRTH}
          value={formatDate(new Date(cellProps.value), preReleaseCheckLabels.uiDateFormat)}
        />
      ),
    },
    {
      Header: {
        label: preReleaseCheckLabels.decision.toUpperCase(),
      },
      id: 'solobuttons',
      Cell: (cellProps: Cell) => {
        return (
          <div className={styles.soloButton}>
            <span
              className={styles.soloButtonInv}
              id="soloButtonInvestigation"
              onClick={() => referForInvestigationHandler(cellProps.row.index, PreReleaseType.SOLO)}
            >
              <span>{preReleaseCheckLabels.ttReferForInvestigationLabel} </span>
            </span>
            <span
              className={styles.soloButtonRel}
              id="soloButtonRelease"
              onClick={() => releaseHandler(cellProps.row.index, PreReleaseType.SOLO)}
            >
              <span>{preReleaseCheckLabels.ttReleaseLabel}</span>
            </span>
          </div>
        );
      },
      disableSortBy: true,
    },
  ] as Column[];

  return (
    <React.Fragment>
      <div id="preReleaseCheckGrid" className={styles.preReleaseCheckGrid}>
        <UI.ExpandableGrid
          id="preReleaseCheckGrid"
          columns={columns}
          data={formattedData}
          initialState={props.gridState.initialState}
          onPageChange={props.onPageChange}
          onPageSizeChange={props.onPageSizeChange}
          totalRecords={props.gridState.totalRecords}
          currentPage={props.gridState.selectedPage}
          pageSizeOptions={props.pageSizeOptions}
          selectedOptionValue={props.gridState.selectedOptionValue}
          onColumnSort={props.onColumnSort}
          sortOption={props.sortOption}
          sort={props.sort}
          isLoading={props.isLoading}
        />
      </div>
      {preReleaseModalHandler()}
      <div className={styles.releaseInvestigationButton} id="preReleaseCheckModalOpener">
        <UI.Button
          label={preReleaseCheckLabels.ttReferForInvestigationLabel}
          color="blueLine"
          id="referForInvestigation"
          onChange={() => referForInvestigationHandler(-1, PreReleaseType.BULK)}
        />
        <UI.Button
          label={preReleaseCheckLabels.ttReleaseLabel}
          color="primary"
          id="release"
          onChange={() => releaseHandler(-1, PreReleaseType.BULK)}
        />
      </div>
    </React.Fragment>
  );
};

export default withServiceRequest(PreReleaseCheckGrid);
