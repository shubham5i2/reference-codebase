import React, { useState } from 'react';
import UI from 'ielts-cmds-ui-component-library';

import styles from './IncidentManagementAdvanceSearchPanel.module.scss';
import { languageService } from '../../../services/Language/LanguageService';
import { AdvancedSearchDataType } from '../../../services/Models/IncidentManagement';
import {
  incidentStatusOptions,
  incidentCatagoryOptions,
  incidentSeverityOptions,
  onDropdownFilter,
  IncidentCatagory,
  getIncidentTypeOptionsAccordingToCatagory,
} from '../../../../src/services/API/Reference/Incident';

interface AdvanceSearchPanelProps {
  advancedSearchData: AdvancedSearchDataType;
  handleAdvancedInputChange: (e: React.FormEvent<HTMLInputElement>) => void;
  handleDropdownChange: (e: { name: string; value: string }) => void;
}

const IncidentManagementAdvanceSearchPanel = (props: AdvanceSearchPanelProps) => {
  const [incidentTypeSearchOptions, setIncidentTypeSearchOptions] = useState(
    getIncidentTypeOptionsAccordingToCatagory(props.advancedSearchData.incidentcatagory),
  );

  const incidentManagementLabels = languageService().incidentManagement;

  const handleIncidentCatagory = (value: string) => {
    props.handleDropdownChange({
      name: 'incidentcatagory',
      value: value,
    });
    setIncidentTypeSearchOptions(getIncidentTypeOptionsAccordingToCatagory(value));
  };

  return (
    <div className={styles.col3}>
      <UI.TextBox
        label={incidentManagementLabels.givenName}
        name="givenname"
        placeholder=""
        value={props.advancedSearchData.givenname}
        onChange={props.handleAdvancedInputChange}
      />
      <UI.TextBox
        label={incidentManagementLabels.familyName}
        name="lastname"
        placeholder=""
        value={props.advancedSearchData.lastname}
        onChange={props.handleAdvancedInputChange}
      />
      <UI.TextBox
        label={incidentManagementLabels.testTakerNumber}
        name="shortcandidatenumber"
        placeholder=""
        value={props.advancedSearchData.shortcandidatenumber}
        onChange={props.handleAdvancedInputChange}
      />
      <UI.TextBox
        label={incidentManagementLabels.uniqueTtNumber}
        name="uniquetesttakerid"
        placeholder=""
        value={props.advancedSearchData.uniquetesttakerid}
        onChange={props.handleAdvancedInputChange}
      />
      <UI.TextBox
        label={incidentManagementLabels.identityDocNo}
        name="identitynumber"
        placeholder=""
        value={props.advancedSearchData.identitynumber}
        onChange={props.handleAdvancedInputChange}
      />
      <UI.Dropdown
        id="incidentStatusOptions"
        label={incidentManagementLabels.incidentStatus}
        selectedValue={props.advancedSearchData.incidentstatus}
        placeholder={incidentManagementLabels.selectOption}
        onChange={(value: string) =>
          props.handleDropdownChange({
            name: 'incidentstatus',
            value: value,
          })
        }
        list={incidentStatusOptions}
      />
      <UI.Dropdown
        id="incidentCatagoryOptions"
        label={incidentManagementLabels.incidentCatagory}
        selectedValue={props.advancedSearchData.incidentcatagory}
        placeholder={incidentManagementLabels.selectOption}
        onChange={(value: string) => handleIncidentCatagory(value)}
        list={incidentCatagoryOptions}
      />
      <UI.Dropdown
        id="incidentTypeOptions"
        label={incidentManagementLabels.incidentType}
        selectedValue={props.advancedSearchData.incidenttype}
        placeholder={incidentManagementLabels.selectOption}
        onChange={(value: string) =>
          props.handleDropdownChange({
            name: 'incidenttype',
            value: value,
          })
        }
        list={incidentTypeSearchOptions}
        showInputWithoutList
        search={props.advancedSearchData.incidentcatagory === IncidentCatagory.MALPRACTICE}
        onSearch={(value: string) =>
          onDropdownFilter(value, props.advancedSearchData.incidentcatagory, setIncidentTypeSearchOptions)
        }
        searchIcon="normal"
        onDropdownClose={() =>
          setIncidentTypeSearchOptions(
            getIncidentTypeOptionsAccordingToCatagory(props.advancedSearchData.incidentcatagory),
          )
        }
        searchPlaceholderText=""
        disable={props.advancedSearchData.incidentcatagory === ''}
      />
      <UI.Dropdown
        id="incidentSeverityOptions"
        label={incidentManagementLabels.severity}
        selectedValue={props.advancedSearchData.incidentseverity}
        placeholder={incidentManagementLabels.selectOption}
        onChange={(value: string) =>
          props.handleDropdownChange({
            name: 'incidentseverity',
            value: value,
          })
        }
        list={incidentSeverityOptions}
      />
    </div>
  );
};

export default IncidentManagementAdvanceSearchPanel;
