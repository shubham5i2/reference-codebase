import React from 'react';
import { Action } from '../../../services/Models/Api';
import ManageUsersActions from '../../Molecules/ManageUsersActions/ManageUsersActions';
import {
  BookingHistoryActionsProps,
  TestTakerBookingHistoryPageActionsProps,
} from '../../Pages/TestTakerBookingHistoryPage/TestTakerBookingHistoryPage';

interface TestTakerBookingHistoryActionsContainerProps {
  dataLabelClass: string;
  containerClass: string;
  containerId: string;
  iconSrc: string;
  index: number;
  bookingUuid: string;
  uniqueTestTakerUuid: string;
  testTakerName: string;
  ttbhDetailsTitle: string;
  userProfileSrc?: string;
  isMoreSelected: boolean;
  isExclusion: boolean;
  panelActions: BookingHistoryActionsProps[];
  actionContainerRef: React.RefObject<HTMLSpanElement>;
  moreClickHandler: (index: number, isExclusion: boolean) => void;
  userActionsClickHandler: (props: TestTakerBookingHistoryPageActionsProps) => void;
}

const TestTakerBookingHistoryActionsContainer = (props: TestTakerBookingHistoryActionsContainerProps) => {
  return (
    <React.Fragment>
      <span className={props.dataLabelClass}>
        {!props.isExclusion && <img src={props.userProfileSrc} alt="view booking details" />}
        {props.ttbhDetailsTitle}
      </span>
      <span className={props.containerClass} ref={props.actionContainerRef} id={props.containerId}>
        <button onClick={() => props.moreClickHandler(props.index, props.isExclusion)}>
          <img alt="" src={props.iconSrc} />
        </button>
        {props.isMoreSelected ? (
          <ManageUsersActions
            id={'ManageBookingHistoryActionContainer'}
            userActions={props.panelActions}
            userActionsClickHandler={(action: Action) =>
              props.userActionsClickHandler({
                action,
                index: props.index,
                bookingUuid: props.bookingUuid,
                uniqueTestTakerUuid: props.uniqueTestTakerUuid,
                testTakerName: props.testTakerName,
              })
            }
          />
        ) : null}
      </span>
    </React.Fragment>
  );
};

export default TestTakerBookingHistoryActionsContainer;
