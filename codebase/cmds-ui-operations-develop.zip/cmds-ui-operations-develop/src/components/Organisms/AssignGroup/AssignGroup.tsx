import React, { useState, useEffect } from 'react';
import styles from './AssignGroup.module.scss';
import UI from 'ielts-cmds-ui-component-library';

import Add from '../../../assets/images/Add.svg';
import AssignGroupPanel from '../AssignGroupPanel/AssignGroupPanel';
import { FormStepType, FormActionType } from '../../utils/ValidationRules/ManageUserForm';
import { languageService } from '../../../services/Language/LanguageService';
import { AssignGroupData, User } from '../../../services/Models/StaffManagement';
import { UserFormError } from '../../../services/Models/UIModels';

const assignGroupObject = {
  userGroup: '',
  dateRange: {
    startDate: new Date(),
    endDate: new Date(2099, 11, 31),
  },
  location: '',
  userGroupName: '',
  locationName: '',
};

const assignGroup = {
  type: FormStepType.ASSIGN_GROUP,
  action: FormActionType.ADD,
  value: assignGroupObject,
};

interface AssingGroupProps {
  onChange: (data: any) => void;
  onClose: (selectedIndex: number) => void;
  assignGroupData: AssignGroupData[];
  userData: User;
  error: UserFormError;
}

const AssignGroup = (props: AssingGroupProps) => {
  const { onChange, onClose, assignGroupData = [], userData, error } = props;
  const [count, setCount] = useState(assignGroupData.length);
  const smLabels = languageService().staffManagement;

  useEffect(
    () => {
      if (assignGroupData.length === 0) onChange(assignGroup);
      setCount(assignGroupData.length);
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [assignGroupData.length],
  );

  const handleClick = () => {
    onChange(assignGroup);
    setCount(count + 1);
  };

  const onRemovePanel = (index: number) => {
    onClose(index);
    setCount(count - 1);
  };

  return (
    <React.Fragment>
      <div>
        {assignGroupData.map((value: AssignGroupData, index: number) => {
          return (
            <AssignGroupPanel
              userData={userData}
              onChange={props.onChange}
              data={value}
              currentIndex={index + 1}
              key={index}
              count={count}
              error={error[index] || {}}
              onRemovePanel={(index: number) => onRemovePanel(index)}
              isFetchLocationOnLoad={index === 0}
            />
          );
        })}
        <div
          className={
            assignGroupData[count - 1] && assignGroupData[count - 1].userGroup.trim() === ''
              ? styles.ag_disableLink
              : ''
          }
        >
          <div className={styles.ag_linkField}>
            <span>
              <UI.Icon id="addAssignGroupIcon" icon={Add} />{' '}
            </span>
            <span id="linkField" onClick={() => handleClick()}>
              <UI.Typography
                id="addAdditionalGroup"
                type="medium"
                label={smLabels.addAdditionalGroupMessage}
                size={16}
                highlight={true}
              />
            </span>
            {/* <span className={styles.linkText}>
              Assign an additional user group</span> */}
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};
export default AssignGroup;
