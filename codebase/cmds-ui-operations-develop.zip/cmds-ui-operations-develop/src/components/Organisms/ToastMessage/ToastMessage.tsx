import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import styles from './ToastMessage.module.scss';
import { DEFAULT_TOAST_MESSAGE_TIMER } from '../../../constants/GlobalConstants';

export enum Mode {
  SUCCESS = 'success',
  INFO = 'info',
  ERROR = 'error',
  WARNING = 'warning',
}

export enum Position {
  DEFAULT = 'center',
  TOPRIGHT = 'topRight',
  BOTOMRIGHT = 'bottomRight',
  TOPLEFT = 'topLeft',
  BOTTOMLEFT = 'bottomLeft',
}

export interface Margin {
  left: number;
  right: number;
  bottom: number;
  top: number;
}

export interface ToastProps {
  onChange?: () => void;
  id?: string;
  color: Mode;
  message?: string;
  position?: Position;
  margin?: Margin;
  duration?: number;
  dismissable?: boolean;
  children?: React.ReactNode | React.ReactNode[];
}

const ToastMessage = (props: ToastProps) => {
  const { dismissable = false } = props;
  const { duration = DEFAULT_TOAST_MESSAGE_TIMER } = props;
  const { id = 'toast_panel_' + props.color } = props;
  const marginStyle = {
    margin: `${props.margin?.top}px ${props.margin?.right}px ${props.margin?.bottom}px ${props.margin?.left}px`,
  };
  const automargin = { margin: `0 auto` };
  return (
    <div
      className={` 
      ${props.position ? styles[props.position] : styles.center}      
      }`}
      id={id}
    >
      <div style={props.margin ? marginStyle : automargin}>
        <UI.Message
          id={id}
          color={props.color ? props.color : Mode.SUCCESS}
          dismissable={dismissable}
          visibleTill={duration}
          onChange={props.onChange}
        >
          {props.children ? props.children : props.message}
        </UI.Message>
      </div>
      <div></div>
    </div>
  );
};

export default ToastMessage;
