import React, { useEffect, useState } from 'react';
import get from 'lodash.get';

import { languageService } from '../../../services/Language/LanguageService';
import { BookingLine, TestTakerBookingDetailsResponse } from '../../../services/Models/TestTakerManagement';
import ArrowUp from '../../../assets/images/Chevron_Up.svg';
import ArrowDown from '../../../assets/images/ArrowDown.svg';
import TestTaker from '../../../assets/images/Users.svg';
import BookingCalendar from '../../../assets/images/BookingCalendar.svg';
import styles from './TestTakerBookingDetailsLeftPanel.module.scss';
import { getIdentityType } from '../../../services/API/Reference/IdentityType';
import { getReasonForTest } from '../../../services/API/Reference/ReasonForTest';
import { getEducationLevel } from '../../../services/API/Reference/EducationLevel';
import { getOccupationSector } from '../../../services/API/Reference/OccupationSector';
import { getOccupationLevelData } from '../../../services/API/Reference/OccupationLevel';
import {
  formatDate,
  getPartnerCode,
  getTerritoriesState,
  getValue,
  getCountryISOCode,
  getCountryName,
} from '../../utils/utilities';
import { getGenderFromUuid } from '../../../services/API/Reference/Gender';
import { useStateValue } from '../../../Store/helpers/UseStateValue';
import { ReferenceDropdownType } from '../../../services/Models/ReferenceModals';
import { AsyncResponseStatus } from '../../../services/Models/Api';
import { getTerritories } from '../../../services/API/Reference/Territories';
import { ServiceRequest } from '../../../services/utils/ServiceRequest';
import { getNationalityData } from '../../../services/API/Reference/Nationality';
import { Location } from '../../../services/Models/StaffManagement';
import { getProductValue } from '../../../services/API/Result/Product';
import { DATA_LOADED, DATA_LOADING, DATA_LOAD_ERROR } from '../../../Store/Actions/ReferenceActions';
import { getLocationKey, LocationType } from '../LocationDropdown/LocationDropdownUtils';
import { useAuth0 } from '@auth0/auth0-react';
import { useHistory } from 'react-router-dom';
import { LinkedBookingDetailsData } from '../../../services/Models/Result';
import LinkedBookingDetails from '../LinkedBookingDetails/LinkedBookingDetails';

export interface TestTakerBookingDetailsLeftPanelProps {
  testTakerBookingDetailsResponse: TestTakerBookingDetailsResponse;
  uniqueTestTakerId: string;
  bookingUuid: string;
  serviceRequest: ServiceRequest;
}

interface TerritoryData {
  text: string;
  value: string;
}

const TestTakerBookingDetailsLeftPanel = (props: TestTakerBookingDetailsLeftPanelProps) => {
  const { state, dispatch } = useStateValue();
  const testTakerLabels = languageService().testTaker;
  const [isPiTabExpanded, setPiTabExpanded] = useState<boolean>(true);
  const [isBookingTabExpanded, setBookingTabExpanded] = useState<boolean>(false);
  const [territoryOptions, setTerritoryOptions] = useState<TerritoryData[]>([]);
  const { user = {} } = useAuth0();

  const partnerCode = getPartnerCode(user);
  console.log({ partnerCode });
  const locationKey = getLocationKey(LocationType.TEST_CENTRE, partnerCode, 'getLocations');
  const locationsResponse = get(state, `locationData.${locationKey}.response`, []);
  console.log({ locationsResponse });
  const productResponse = state.products?.response;

  const fetchTerritoryData = (countryUuid: string) => {
    const countryCode = getCountryISOCode(state, countryUuid);
    const payload = {
      dropdownType: ReferenceDropdownType.TERRITORY,
      subkey: countryCode,
    };
    if (getTerritoriesState(state, countryCode).transformedData?.length > 0) {
      setTerritoryOptions(getTerritoriesState(state, countryCode).transformedData);
      return;
    } else {
      dispatch({ type: DATA_LOADING, payload });
      getTerritories(props.serviceRequest, countryCode).subscribe((data) => {
        if (data.status === AsyncResponseStatus.SUCCESS && data.transformedData?.length > 0) {
          dispatch({
            type: DATA_LOADED,
            payload: {
              ...payload,
              response: data.response,
              transformedData: data.transformedData,
            },
          });
        } else {
          dispatch({ type: DATA_LOAD_ERROR, payload });
        }
        setTerritoryOptions(data.territoriesData || []);
      });
    }
  };
  const history = useHistory();
  const countryApplying = getCountryName(props.testTakerBookingDetailsResponse.marketingInfo.applyingToCountryUuid);
  const occupationSector = getOccupationSector(
    props.testTakerBookingDetailsResponse.marketingInfo.occupationSectorUuid,
  );
  const occupationLevel = getOccupationLevelData(
    props.testTakerBookingDetailsResponse.marketingInfo.occupationLevelUuid,
  );
  const reasonForTest = getReasonForTest(props.testTakerBookingDetailsResponse.marketingInfo.reasonForTestUuid);

  const getTerritoryName = (territoryUuid: string) =>
    territoryOptions.find((data: TerritoryData) => territoryUuid === data.value)?.text || '';

  useEffect(() => {
    props.testTakerBookingDetailsResponse.testTakerInfo.address?.countryUuid &&
      fetchTerritoryData(props.testTakerBookingDetailsResponse.testTakerInfo.address?.countryUuid || '');
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.testTakerBookingDetailsResponse]);

  const onExpandClickHandler = (tab: string) => {
    const currentPiTabStatus = isPiTabExpanded;
    const currentBookingTabStatus = isBookingTabExpanded;
    if ('personalInfo' === tab) {
      setBookingTabExpanded(false);
      setPiTabExpanded(!currentPiTabStatus);
    }
    if ('bookingInfo' === tab) {
      setPiTabExpanded(false);
      setBookingTabExpanded(!currentBookingTabStatus);
    }
  };

  const onClickViewBooking = () => {
    history.push(
      `/managetesttaker/testtakerbookinghistory/${props.testTakerBookingDetailsResponse.testTakerInfo.testTakerUuid}/testtakerbookingdetails/${props.testTakerBookingDetailsResponse.linkedBookingDetails.bookingUuid}`,
      {
        selectedBookingUuid: props.bookingUuid,
        selectedTestTakerUuid: props.uniqueTestTakerId,
        selectedUniqueTestTakerId: props.uniqueTestTakerId,
      },
    );
  };

  const getProductData = (bookingLines: BookingLine[]) => {
    return (
      <table id="component_details" className={styles.component_details}>
        <tr>
          <th>{testTakerLabels.testProductName}</th>
          <th>{testTakerLabels.testStartTimeLocal}</th>
          <th>{testTakerLabels.testStartTimeUtc}</th>
        </tr>
        {bookingLines
          .sort((first: BookingLine, second: BookingLine) => (first.productUuid > second.productUuid ? 1 : -1))
          .map((bookingLine) => {
            return (
              <tr key={bookingLine.productUuid}>
                <td>{getProductValue(bookingLine.productUuid, productResponse)}</td>
                <td>
                  {formatDate(new Date(bookingLine.startTimeLocal?.slice(0, -1)), testTakerLabels.uiDateTimeInMillis)}
                </td>
                <td>
                  {formatDate(new Date(bookingLine.startDateTime.slice(0, -1)), testTakerLabels.uiDateTimeInMillis)}
                </td>
              </tr>
            );
          })}
      </table>
    );
  };

  const getLocationData = (dataType: string, locationUuid: string) => {
    if (locationsResponse && dataType === 'locationCode') {
      return locationsResponse.find((location: Location) => locationUuid === location.locationUuid)?.locationCode || '';
    }
    if (locationsResponse && dataType === 'locationName') {
      return locationsResponse.find((location: Location) => locationUuid === location.locationUuid)?.locationName || '';
    }
    return '';
  };

  const linkedBookingDetails: LinkedBookingDetailsData = {
    bookingUuid: props.bookingUuid,
    testDate: props.testTakerBookingDetailsResponse.linkedBookingDetails?.testDate,
    shortCandidateNumber: get(props, 'testTakerBookingDetailsResponse.linkedBookingDetails.shortCandidateNumber', ''),
    compositeCandidateNumber: ' ',
    testCentreNumber: getLocationData(
      'locationCode',
      props.testTakerBookingDetailsResponse.linkedBookingDetails?.testCentreUuid,
    ),
    testCentreName: getLocationData(
      'locationName',
      props.testTakerBookingDetailsResponse.linkedBookingDetails?.testCentreUuid,
    ),
    locationId: get(props, 'testTakerBookingDetailsResponse.linkedBookingDetails.locationUuid', ' '),
    locationName: props.testTakerBookingDetailsResponse.testBookingInfo.locationName,
    productName: getProductValue(
      props.testTakerBookingDetailsResponse.linkedBookingDetails?.productUuid,
      productResponse,
    ),
  };

  return (
    <React.Fragment>
      <div className={styles.leftPanel}>
        <div className={styles.ttbLeftPanelContainer}>
          <div className={styles.ttbExpandableContainer}>
            <span className={styles.ttbExpandableContainerTitle}>
              <img src={TestTaker} alt="view booking details" />
              {testTakerLabels.ttbhPITitle}
            </span>
            <span className={styles.ttbExpandableContainerExpandIcon}>
              <button onClick={() => onExpandClickHandler('personalInfo')}>
                {isPiTabExpanded ? <img alt="" src={ArrowUp} /> : <img alt="" src={ArrowDown} />}
              </button>
            </span>
          </div>
          <div
            className={
              isPiTabExpanded ? styles.ttbBookingDetailsContainerActive : styles.ttbBookingDetailsContainerInactive
            }
          >
            <div className={styles.ttbDetailsContainer}>
              <span>{testTakerLabels.ttbhPITitle.toUpperCase()}</span>
              <div className={styles.ttbDetailsContainerGrid}>
                <div>
                  <span>{testTakerLabels.givenName}</span>
                  <span>{props.testTakerBookingDetailsResponse.testTakerInfo.firstName}</span>
                </div>
                <div>
                  <span>{testTakerLabels.familyName}</span>
                  <span>{props.testTakerBookingDetailsResponse.testTakerInfo.lastName}</span>
                </div>
                <div>
                  <span>{testTakerLabels.dateOfBirth}</span>
                  <span>
                    {formatDate(
                      new Date(props.testTakerBookingDetailsResponse.testTakerInfo.birthDate),
                      testTakerLabels.uiDateFormat,
                    )}
                  </span>
                </div>
                <div>
                  <span>{testTakerLabels.sexLabel}</span>
                  <span>{getGenderFromUuid(props.testTakerBookingDetailsResponse.testTakerInfo.sexUuid)}</span>
                </div>
                <div>
                  <span>{testTakerLabels.nationality}</span>
                  <span>{getNationalityData(props.testTakerBookingDetailsResponse.testTakerInfo.nationalityUuid)}</span>
                </div>
                <div>
                  <span>{testTakerLabels.identityDocumentNumber}</span>
                  <span>{props.testTakerBookingDetailsResponse.testTakerInfo.identityNumber}</span>
                </div>
                <div>
                  <span>{testTakerLabels.identityDocumentType}</span>
                  <span>{getIdentityType(props.testTakerBookingDetailsResponse.testTakerInfo.identityTypeUuid)}</span>
                </div>
                <div>
                  <span>{testTakerLabels.issuingAuthority}</span>
                  <span>{props.testTakerBookingDetailsResponse.testTakerInfo.identityIssuingAuthority}</span>
                </div>
                <div>
                  <span>{testTakerLabels.identityExpiryDate}</span>
                  <span>
                    {formatDate(
                      new Date(get(props, 'testTakerBookingDetailsResponse.testTakerInfo.identityExpiryDate', '')),
                      testTakerLabels.uiDateFormat,
                    )}
                  </span>
                </div>
              </div>
            </div>
            <div className={styles.ttbDetailsContainer}>
              <span>{testTakerLabels.contactInformation.toUpperCase()}</span>
              <div className={styles.ttbDetailsContainerGrid}>
                <div>
                  <span>{testTakerLabels.addressLabel}</span>
                  <span>
                    {getValue(props.testTakerBookingDetailsResponse.testTakerInfo.address?.addressLine1) +
                      ' ' +
                      getValue(props.testTakerBookingDetailsResponse.testTakerInfo.address?.addressLine2) +
                      ' ' +
                      getValue(props.testTakerBookingDetailsResponse.testTakerInfo.address?.addressLine3) +
                      ' ' +
                      getValue(props.testTakerBookingDetailsResponse.testTakerInfo.address?.addressLine4)}
                  </span>
                </div>
                <div>
                  <span>{testTakerLabels.cityLabel}</span>
                  <span>{getValue(props.testTakerBookingDetailsResponse.testTakerInfo.address?.city)}</span>
                </div>
                <div>
                  <span>{testTakerLabels.postCodeLabel}</span>
                  <span>{getValue(props.testTakerBookingDetailsResponse.testTakerInfo.address?.postalCode)}</span>
                </div>
                <div>
                  <span>{testTakerLabels.regionLabel}</span>
                  <span>
                    {getTerritoryName(
                      get(props, 'testTakerBookingDetailsResponse.testTakerInfo.address.stateTerritoryUuid', ''),
                    )}
                  </span>
                </div>
                <div>
                  <span>{testTakerLabels.countryLabel}</span>
                  <span>
                    {getCountryName(state, props.testTakerBookingDetailsResponse.testTakerInfo.address?.countryUuid)}
                  </span>
                </div>
                <div>
                  <span>{testTakerLabels.email}</span>
                  <span>{props.testTakerBookingDetailsResponse.testTakerInfo.email}</span>
                </div>
                <div>
                  <span>{testTakerLabels.telephoneLable}</span>
                  <span>{props.testTakerBookingDetailsResponse.testTakerInfo.phone}</span>
                </div>
                <div>
                  <span>{testTakerLabels.mobileLabel}</span>
                  <span>{props.testTakerBookingDetailsResponse.testTakerInfo.mobile}</span>
                </div>
              </div>
            </div>
            <div className={styles.ttbDetailsContainer}>
              <span>{testTakerLabels.additionalLabelTitle.toUpperCase()}</span>
              <div className={styles.ttbDetailsContainerGrid}>
                <div>
                  <span>{testTakerLabels.reasonForTestLabel}</span>
                  <span>
                    {!isBlank(props.testTakerBookingDetailsResponse.marketingInfo.reasonForTestOther)
                      ? props.testTakerBookingDetailsResponse.marketingInfo.reasonForTestOther
                      : reasonForTest}
                  </span>
                </div>
                <div>
                  <span>{testTakerLabels.countryApplyingLabel}</span>
                  <span>
                    {!isBlank(props.testTakerBookingDetailsResponse.marketingInfo.countryApplyingToOther)
                      ? props.testTakerBookingDetailsResponse.marketingInfo.countryApplyingToOther
                      : countryApplying}
                  </span>
                </div>
                <div>
                  <span>{testTakerLabels.educationLabel}</span>
                  <span>
                    {getEducationLevel(props.testTakerBookingDetailsResponse.marketingInfo.educationLevelUuid)}
                  </span>
                </div>
                <div>
                  <span>{testTakerLabels.currentEnglishStudyLabel}</span>
                  <span>{props.testTakerBookingDetailsResponse.marketingInfo.currentEnglishStudyPlace}</span>
                </div>
                <div>
                  <span>{testTakerLabels.studyYearsLabel}</span>
                  <span>{props.testTakerBookingDetailsResponse.marketingInfo.yearsOfStudy}</span>
                </div>
                <div>
                  <span>{testTakerLabels.occupationSectorLabel}</span>
                  <span>
                    {!isBlank(props.testTakerBookingDetailsResponse.marketingInfo.occupationSectorOther)
                      ? props.testTakerBookingDetailsResponse.marketingInfo.occupationSectorOther
                      : occupationSector}
                  </span>
                </div>
                <div>
                  <span>{testTakerLabels.occupationLevelLabel}</span>
                  <span>
                    {!isBlank(props.testTakerBookingDetailsResponse.marketingInfo.occupationLevelOther)
                      ? props.testTakerBookingDetailsResponse.marketingInfo.occupationLevelOther
                      : occupationLevel}
                  </span>
                </div>
                <div>
                  <span>{testTakerLabels.consentLabel}</span>
                  <span>{props.testTakerBookingDetailsResponse.testTakerInfo.consentGiven ? 'Yes' : 'No'}</span>
                </div>
                <div>
                  <span>{testTakerLabels.agentNameLabel}</span>
                  <span>{props.testTakerBookingDetailsResponse.testTakerInfo.agentName}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/** Test Booking Panel */}
        <div className={styles.ttbLeftPanelContainer}>
          <div className={styles.ttbExpandableContainer}>
            <span className={styles.ttbExpandableContainerTitle}>
              <img src={BookingCalendar} alt="view booking details" className={styles.bookingInfoIcon} />
              {testTakerLabels.testBookingInfoTitle}
            </span>
            <span className={styles.ttbExpandableContainerExpandIcon}>
              <button onClick={() => onExpandClickHandler('bookingInfo')}>
                {isBookingTabExpanded ? <img alt="" src={ArrowUp} /> : <img alt="" src={ArrowDown} />}
              </button>
            </span>
          </div>
          <div
            className={
              isBookingTabExpanded ? styles.ttbBookingDetailsContainerActive : styles.ttbBookingDetailsContainerInactive
            }
          >
            <div className={styles.ttbDetailsContainer}>
              <span>{testTakerLabels.ieltsIdLabel}</span>
              <div className={styles.ttbDetailsContainerGrid}>
                <div>
                  <span>{testTakerLabels.uniqueTestTakerId}</span>
                  <span>{props.uniqueTestTakerId}</span>
                </div>
                <div>
                  <span>{testTakerLabels.externalTtIdLabel}</span>
                  <span>{props.testTakerBookingDetailsResponse.testBookingInfo.externalUniqueTestTakerUuid}</span>
                </div>
                <div>
                  <span>{testTakerLabels.cmdsBookingId}</span>
                  <span>{props.bookingUuid}</span>
                </div>
                <div>
                  <span>{testTakerLabels.ttNumberLabel}</span>
                  <span>{props.testTakerBookingDetailsResponse.testBookingInfo.shortCandidateNumber}</span>
                </div>
                <div>
                  <span>{testTakerLabels.compositeTtLabel}</span>
                  <span>{props.testTakerBookingDetailsResponse.testBookingInfo.compositeCandidateNumber}</span>
                </div>
              </div>
            </div>
            <div className={styles.ttbDetailsContainer}>
              <span>{testTakerLabels.testDetailsLabel.toUpperCase()}</span>
              <div className={styles.ttbDetailsContainerGrid}>
                <div>
                  <span>{testTakerLabels.productLabel}</span>
                  <span>
                    {getProductValue(
                      props.testTakerBookingDetailsResponse.testBookingInfo.productUuid,
                      productResponse,
                    )}
                  </span>
                </div>
                <div>
                  <span>{testTakerLabels.partnerLabel}</span>
                  <span>{props.testTakerBookingDetailsResponse.testBookingInfo.partnerCode}</span>
                </div>
                <div>
                  <span>{testTakerLabels.absentStatusLabel}</span>
                  <span>{''}</span>
                </div>
                <div>
                  <span>{testTakerLabels.refundStatusLabel}</span>
                  <span>{''}</span>
                </div>
                <div>
                  <span>{testTakerLabels.testDateLabel}</span>
                  <span>
                    {formatDate(
                      new Date(props.testTakerBookingDetailsResponse.testBookingInfo.testDate),
                      testTakerLabels.uiDateFormat,
                    )}
                  </span>
                </div>
                <div>
                  <span>{testTakerLabels.testCentreNumberLabel}</span>
                  <span>
                    {' '}
                    {getLocationData(
                      'locationCode',
                      props.testTakerBookingDetailsResponse.testBookingInfo.testCentreUuid,
                    )}
                  </span>
                </div>
                <div>
                  <span>{testTakerLabels.testCentreNameLabel}</span>
                  <span>
                    {' '}
                    {getLocationData(
                      'locationName',
                      props.testTakerBookingDetailsResponse.testBookingInfo.testCentreUuid,
                    )}
                  </span>
                </div>
                <div>
                  <span>{testTakerLabels.locationIdLabel}</span>
                  <span>{props.testTakerBookingDetailsResponse.testBookingInfo.locationUuid}</span>
                </div>
                <div>
                  <span>{testTakerLabels.locationNameLabel}</span>
                  <span>{props.testTakerBookingDetailsResponse.testBookingInfo.locationName}</span>
                </div>
                <div>
                  <span>{testTakerLabels.identityVerificationStatusLabel}</span>
                  <span>{props.testTakerBookingDetailsResponse.testBookingInfo.identityVerificationStatus}</span>
                </div>
                <div>
                  <span>{testTakerLabels.bookingStatusLabel}</span>
                  <span>{props.testTakerBookingDetailsResponse.testBookingInfo.bookingStatus}</span>
                </div>
                <div>
                  <span>{testTakerLabels.bookingDetailStatusLabel}</span>
                  <span>{props.testTakerBookingDetailsResponse.testBookingInfo.bookingDetailStatus}</span>
                </div>
                <div>
                  <span>{testTakerLabels.ttCredentialsLabel}</span>
                  <span>{props.testTakerBookingDetailsResponse.testBookingInfo.testPlatformUsername}</span>
                </div>
                <div>
                  <span>{testTakerLabels.sebPasswordLabel}</span>
                  <span>{props.testTakerBookingDetailsResponse.testBookingInfo.testPlatformPassword}</span>
                </div>
              </div>
            </div>
            <div className={styles.ttbDetailsContainer}>
              <span>{testTakerLabels.testComponentLabel.toUpperCase()}</span>
              <div className={styles.ttbDetailsContainerGrid}>
                {getProductData(get(props, 'testTakerBookingDetailsResponse.testBookingInfo.bookingLines', []))}
              </div>
            </div>
            <div className={styles.ttbDetailsContainer}>
              <span>{testTakerLabels.accessArrangementsLabel.toUpperCase()}</span>
              <div className={styles.ttbDetailsContainerGrid}>
                <div>
                  <span>{testTakerLabels.accessArrangementsRequiredLabel}</span>
                  <span>
                    {props.testTakerBookingDetailsResponse.bookingOtherInfo.specialArrangementsRequired ? 'Yes' : 'No'}
                  </span>
                </div>
                <div>
                  <span>{testTakerLabels.aaCaseNumberLabel}</span>
                  <span>{props.testTakerBookingDetailsResponse.bookingOtherInfo.aaCaseNumber || 'N/A'}</span>
                </div>
              </div>
            </div>
            <div className={styles.ttbDetailsContainer}>
              <span>{testTakerLabels.otherInfoLabel.toUpperCase()}</span>
              <div className={styles.ttbDetailsContainerGrid}>
                <div>
                  <span>{testTakerLabels.ttbhNotes}</span>
                  <span>
                    {!props.testTakerBookingDetailsResponse.bookingOtherInfo.notes
                      ? props.testTakerBookingDetailsResponse.bookingOtherInfo.Notes
                      : props.testTakerBookingDetailsResponse.bookingOtherInfo.notes}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* <linked booking information> */}
        {props.testTakerBookingDetailsResponse.linkedBookingDetails !== null ? (
          <div className={styles.linkedleftpanelcontainer}>
            <LinkedBookingDetails
              linkedBookingDetailsData={linkedBookingDetails}
              onClickViewBooking={onClickViewBooking}
            />
          </div>
        ) : null}
      </div>
    </React.Fragment>
  );

  function isBlank(str: string) {
    return str !== null && (str.length === 0 || !str.trim());
  }
};

export default TestTakerBookingDetailsLeftPanel;
