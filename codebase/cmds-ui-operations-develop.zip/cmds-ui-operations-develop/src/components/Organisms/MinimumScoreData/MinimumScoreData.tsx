import React from 'react';
import styles from './MinimumScoreData.module.scss';
import MinimumScore from '../../Molecules/MinimumScore/MinimumScore';
import { languageService } from '../../../services/Language/LanguageService';
import { MinimumScoreData as MinimumScoreDetails } from '../../../services/Models/Organisation';

interface minimumScoreProps {
  minimumScore: MinimumScoreDetails;
}

const MinimumScoreData = (props: minimumScoreProps) => {
  const organisationLabels = languageService().organisation;

  const tabPanel = (productKey: string) => {
    const product = props.minimumScore?.[productKey];
    return (
      <div className={styles.orgScoreWrapper} title={product?.tabText}>
        <div className={`${styles.orgScoreContainer} ${styles.orgOverallScore}`}>
          <div className={styles.orgScoreTitle} id={`overall_score_${product}`}>
            {organisationLabels.overallBandScore}
          </div>
          <div className={styles.orgScoreData}>
            <span className={styles.orgScoreBorder} id={`overall_score_data_${product}`}>
              {product?.overallScore?.actualScore?.text}
            </span>
          </div>
        </div>
        <div className={styles.orgScoreContainer}>
          <div className={styles.orgScoreTitle} id={`mst_listening_${product}`}>
            {organisationLabels.listeningLabel}
          </div>
          <div className={styles.orgScoreData} id={`mst_listening_data_${product}`}>
            {product?.listening?.actualScore?.text}
          </div>
        </div>
        <div className={styles.orgScoreContainer}>
          <div className={styles.orgScoreTitle} id={`mst_reading_${product}`}>
            {organisationLabels.readingLabel}
          </div>
          <div className={styles.orgScoreData} id={`mst_reading_data_${product}`}>
            {product?.reading?.actualScore?.text}
          </div>
        </div>

        <div className={styles.orgScoreContainer}>
          <div className={styles.orgScoreTitle} id={`mst_writing_${product}`}>
            {organisationLabels.writingLabel}
          </div>
          <div className={styles.orgScoreData} id={`mst_writing_data_${product}`}>
            {product?.writing?.actualScore?.text}
          </div>
        </div>
        <div className={styles.orgScoreContainer}>
          <div className={styles.orgScoreTitle} id={`mst_speaking_${product}`}>
            {organisationLabels.speakingLabel}
          </div>
          <div className={styles.orgScoreData} id={`mst_speaking_data_${product}`}>
            {product?.speaking?.actualScore?.text}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className={styles.orgDetailContainer}>
      <MinimumScore
        title={organisationLabels.minimumScoreRequirementTitle}
        selected={0}
        tabContainerStyle={styles.tabContainer}
      >
        {props.minimumScore ? Object.keys(props.minimumScore)?.map((productkey: string) => tabPanel(productkey)) : null}
      </MinimumScore>
    </div>
  );
};

export default MinimumScoreData;
