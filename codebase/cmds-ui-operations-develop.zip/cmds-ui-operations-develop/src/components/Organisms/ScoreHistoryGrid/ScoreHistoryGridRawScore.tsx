import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import { Cell, Column } from 'react-table';

import styles from './ScoreHistoryGridRawScore.module.scss';
import ScoreHistoryGridCell from './ScoreHistoryGridCell/ScoreHistoryGridCell';
import { ScoreHistoryGridCellType } from './ScoreHistoryGridConstants';
import { languageService } from '../../../services/Language/LanguageService';
import { formatDate } from '../../../components/utils/utilities';
import ArrowDownIcon from '../../../assets/images/ArrowDown.svg';
import ScoreCriteriaTask from './ScoreCriteriaTask/ScoreCriteriaTask';
import {
  ComponentRoundInfo,
  TaskInfo,
} from '../../Pages/Results/ResultsTestTakerDetails/ResultsTestTakerDetailsConstants';
import { ExpandedGridType } from '../../../services/Models/UIModels';
interface ScoreHistoryGridProps {
  data?: ComponentRoundInfo[];
  expandable?: boolean;
}

const ScoreHistoryGrid = (props: ScoreHistoryGridProps) => {
  const resultsLabels = languageService().result;

  const getGridItemResultType = (cellProps: Cell, name: string) => {
    return <ScoreHistoryGridCell id={name} cellType={name} value={cellProps.value} />;
  };

  const getExpandedGridItem = (row: any) => {
    return (
      <span {...row.getToggleRowExpandedProps()}>
        {props.expandable && row.original.tasks?.length > 0 ? (
          <ScoreHistoryGridCell
            id={ScoreHistoryGridCellType.EXPAND}
            cellType={ScoreHistoryGridCellType.EXPAND}
            icon={ArrowDownIcon}
            isExpanded={row.isExpanded}
          />
        ) : null}
      </span>
    );
  };

  const columns = [
    {
      id: 'expander',
      Cell: (
        { row }: any, // : cannot find required fields in provided type definitions..
      ) => getExpandedGridItem(row),
    },
    {
      Header: {
        label: resultsLabels.scoresRoundLabel,
        name: ScoreHistoryGridCellType.ROUND,
      },
      accessor: ScoreHistoryGridCellType.ROUND,
      Cell: (cellProps: Cell) => (
        <ScoreHistoryGridCell
          id={ScoreHistoryGridCellType.ROUND}
          cellType={ScoreHistoryGridCellType.ROUND}
          value={cellProps.value}
          isScoreUpdated={getData(props.data)[cellProps.row.index].isUpdated}
        />
      ),
    },
    {
      Header: {
        label: resultsLabels.scoresLabel,
        name: ScoreHistoryGridCellType.SCORE,
      },
      accessor: ScoreHistoryGridCellType.SCORE,
      sortType: 'basic',
      Cell: (cellProps: Cell) => (
        <ScoreHistoryGridCell
          id={ScoreHistoryGridCellType.SCORE}
          cellType={ScoreHistoryGridCellType.SCORE}
          value={cellProps.value}
          isEorPending={getData(props.data)[cellProps.row.index].overallResultType === 'PENDING_EOR'}
          isAbsent={getData(props.data)[cellProps.row.index].overallResultType === 'ABSENT'}
          isExempt={getData(props.data)[cellProps.row.index].overallResultType === 'EXEMPT'}
        />
      ),
    },
    {
      Header: {
        label: resultsLabels.scoreRaw,
        name: ScoreHistoryGridCellType.RAW_SCORE,
      },
      accessor: ScoreHistoryGridCellType.RAW_SCORE,
      sortType: 'basic',
      Cell: (cellProps: Cell) => (
        <ScoreHistoryGridCell
          id={ScoreHistoryGridCellType.RAW_SCORE}
          cellType={ScoreHistoryGridCellType.RAW_SCORE}
          value={cellProps.value}
          isEorPending={getData(props.data)[cellProps.row.index].overallResultType === 'PENDING_EOR'}
          isAbsent={getData(props.data)[cellProps.row.index].overallResultType === 'ABSENT'}
          isExempt={getData(props.data)[cellProps.row.index].overallResultType === 'EXEMPT'}
        />
      ),
    },
    {
      Header: {
        resultsTypeLabel: 'Results Type',
        label: resultsLabels.resultsTypeLabel,
        name: ScoreHistoryGridCellType.RESULTS_TYPE,
      },
      accessor: ScoreHistoryGridCellType.RESULTS_TYPE,
      Cell: (cellProps: Cell) => getGridItemResultType(cellProps, ScoreHistoryGridCellType.RESULTS_TYPE),
    },
    {
      Header: {
        label: resultsLabels.dateReceivedLabel,
        name: ScoreHistoryGridCellType.DATE_RECEIVED,
      },
      accessor: ScoreHistoryGridCellType.DATE_RECEIVED,
      Cell: (cellProps: Cell) => (
        <ScoreHistoryGridCell
          id={ScoreHistoryGridCellType.DATE_RECEIVED}
          cellType={cellProps.value ? ScoreHistoryGridCellType.DATE_RECEIVED : ScoreHistoryGridCellType.PENDING}
          value={
            cellProps.value
              ? `${formatDate(cellProps.value, 'dd MMM yyyy')} | ${formatDate(cellProps.value, 'HH:mm')}`
              : resultsLabels.pendingLabel
          }
        />
      ),
    },
  ] as Column[];

  const getData = (data?: ComponentRoundInfo[]) => {
    if (!data || data.length === 0) {
      return [
        {
          componentEvaluationRoundId: 1,
          dateReceived: null,
          overallFinalGrade: resultsLabels.pendingLabel,
          overallResultType: resultsLabels.pendingLabel,
          isUpdated: false,
        },
      ];
    }
    return data;
  };

  const renderExpandedRowItems = (row: ExpandedGridType) => {
    const { tasks } = row.rowData;
    return tasks?.map((task: TaskInfo) => (
      <ScoreCriteriaTask
        key={task.taskNumber}
        colSpan={columns.length}
        taskNumber={task.taskNumber}
        examinerID={task.examiner || resultsLabels.pendingLabel}
        criterias={task.criterias}
      />
    ));
  };

  const doNothing = () => null;

  return (
    <div id="scoreHistoryGridContainer" className={styles.grid}>
      <UI.ExpandableGrid
        id="scoreHistoryGrid"
        columns={columns}
        data={getData(props.data)}
        hideGridControls={true}
        initialState={{ pageSize: 4 }}
        onPageChange={doNothing}
        onPageSizeChange={doNothing}
        totalRecords={4}
        currentPage={0}
        pageSizeOptions={[{ text: '', value: 0 }]}
        expandedGrid={renderExpandedRowItems}
        selectedOptionValue={0}
      />
    </div>
  );
};

export default ScoreHistoryGrid;
