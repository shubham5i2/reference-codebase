import React from 'react';
import { languageService } from '../../../../services/Language/LanguageService';
import { Criteria } from '../../../Pages/Results/ResultsTestTakerDetails/ResultsTestTakerDetailsConstants';
import styles from './ScoreCriteriaTask.module.scss';
import { CriteriaValue } from '../ScoreHistoryGridConstants';

interface ScoreCriteriaTaskProps {
  colSpan: number;
  taskNumber?: number;
  examinerID: number | string;
  criterias: Criteria[] | undefined;
  component?: string;
}
type criteriaRowItem = { key: string; label: string; value: string | number };

const ScoreCriteriaTask = ({ colSpan, taskNumber, examinerID, criterias, component }: ScoreCriteriaTaskProps) => {
  const resultsLabels = languageService().result;
  const generateRightOrder = (criteriaRow: criteriaRowItem[] | any) => {
    const criteriaData: criteriaRowItem[] = [...criteriaRow];
    criteriaData[2] = criteriaRow.filter((item: criteriaRowItem) => item.key === CriteriaValue.FC);
    criteriaData[3] = criteriaRow.filter((item: criteriaRowItem) => item.key === CriteriaValue.P);
    criteriaData[4] = criteriaRow.filter((item: criteriaRowItem) => item.key === CriteriaValue.LR);
    criteriaData[5] = criteriaRow.filter((item: criteriaRowItem) => item.key === CriteriaValue.GRA);
    return criteriaData;
  };
  const generateCriteria = (key: string, label: string, value: string | number) => (
    <div key={key}>
      <div>{label}</div>
      <div>{value}</div>
    </div>
  );

  const criteriaRow = [generateCriteria('examiner', resultsLabels.examinerIDLabel, examinerID)];
  criterias?.forEach((crit) => {
    criteriaRow.push(
      generateCriteria(
        crit.criteriaValue,
        crit.criteriaValue,
        crit.criteriaScore !== undefined && crit.criteriaScore !== null && crit.criteriaScore >= 0
          ? crit.criteriaScore
          : resultsLabels.pendingLabel,
      ),
    );
  });

  if (taskNumber) {
    criteriaRow.unshift(
      <div key="taskNumber" className={styles.taskNumber}>{`${resultsLabels.scoresTaskLabel} ${taskNumber}`}</div>,
    );
  }
  return (
    <tr className={[styles.expandedRow, taskNumber === 1 ? styles.firstExpandedRow : null].join(' ')}>
      <td colSpan={colSpan}>
        <div className={styles.criteriaRow}>
          {component === 'speaking' ? generateRightOrder(criteriaRow) : criteriaRow}
        </div>
      </td>
    </tr>
  );
};

export default ScoreCriteriaTask;
