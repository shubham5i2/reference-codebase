import { Scores } from '../../Pages/Results/ResultsTestTakerDetails/ResultsTestTakerDetails';
import {
  bookingResultsMockData,
  componentGradeTypes,
  ResultScoreInfo,
} from '../../Pages/Results/ResultsTestTakerDetails/ResultsTestTakerDetailsConstants';

export enum ScoreHistoryGridCellType {
  EXPAND = 'expandBtn',
  ROUND = 'componentEvaluationRoundId',
  SCORE = 'overallFinalGrade',
  RAW_SCORE = 'rawScore',
  RESULTS_TYPE = 'overallResultType',
  DATE_RECEIVED = 'dateReceived',
  PENDING = 'Pending',
}

interface CriteriaDist {
  [uuid: string]: string;
}

export const criteriasDict: CriteriaDist = {
  '1182960a-e547-4e57-b06a-db499e4927ee': 'TA',
  '600bc354-b1f5-4567-b8c5-84b1a3344e65': 'TR',
  '574a9570-da1d-45c7-ad44-c56c29f4d1bc': 'CC',
  'e0dc0b2e-70fc-466c-aaf3-d90389169174': 'LR',
  'd0d2b953-7370-47e1-9508-4383fe46b3bb': 'GRA',
  '211c37da-5677-403c-aa49-606a8015e6c2': 'FC',
  '9f7e9124-5f76-48b9-9815-97b7e1573708': 'P',
};
export enum CriteriaValue {
  FC = 'FC',
  P = 'P',
  LR = 'LR',
  GRA = 'GRA',
}

export const scoreHistoryGridMockData: Scores = {
  overall: bookingResultsMockData?.resultScoreHistory?.find(
    (r: ResultScoreInfo) => r.componentGradeType === componentGradeTypes.OVERALL,
  )?.componentRounds,
  listening: bookingResultsMockData?.resultScoreHistory?.find(
    (r: ResultScoreInfo) => r.componentGradeType === componentGradeTypes.LISTENING,
  )?.componentRounds,
  reading: bookingResultsMockData?.resultScoreHistory?.find(
    (r: ResultScoreInfo) => r.componentGradeType === componentGradeTypes.READING,
  )?.componentRounds,
  speaking: bookingResultsMockData?.resultScoreHistory?.find(
    (r: ResultScoreInfo) => r.componentGradeType === componentGradeTypes.SPEAKING,
  )?.componentRounds,
  writing: bookingResultsMockData?.resultScoreHistory?.find(
    (r: ResultScoreInfo) => r.componentGradeType === componentGradeTypes.WRITING,
  )?.componentRounds,
};
