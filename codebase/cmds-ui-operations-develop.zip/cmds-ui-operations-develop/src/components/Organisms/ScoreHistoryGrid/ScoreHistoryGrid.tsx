import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import { Cell, Column } from 'react-table';

import styles from './ScoreHistoryGrid.module.scss';
import ScoreHistoryGridCell from './ScoreHistoryGridCell/ScoreHistoryGridCell';
import { ScoreHistoryGridCellType } from './ScoreHistoryGridConstants';
import { languageService } from '../../../services/Language/LanguageService';
import { formatDate } from '../../../components/utils/utilities';
import ArrowDownIcon from '../../../assets/images/ArrowDown.svg';
import ScoreCriteriaTask from './ScoreCriteriaTask/ScoreCriteriaTask';
import {
  ComponentRoundInfo,
  TaskInfo,
} from '../../Pages/Results/ResultsTestTakerDetails/ResultsTestTakerDetailsConstants';
import { ExpandedGridType } from '../../../services/Models/UIModels';
interface ScoreHistoryGridProps {
  data?: ComponentRoundInfo[];
  expandable?: boolean;
  className?: string;
  component?: string;
}

const ScoreHistoryGrid = (props: ScoreHistoryGridProps) => {
  const resultsLabels = languageService().result;

  const columns = [
    {
      id: 'expander',
      Cell: (
        { row }: any, // : cannot find required fields in provided type definitions..
      ) => (
        <span {...row.getToggleRowExpandedProps()}>
          {props.expandable && row.original.tasks?.length > 0 ? (
            <ScoreHistoryGridCell
              id={ScoreHistoryGridCellType.EXPAND}
              cellType={ScoreHistoryGridCellType.EXPAND}
              icon={ArrowDownIcon}
              isExpanded={row.isExpanded}
            />
          ) : null}
        </span>
      ),
    },
    {
      Header: {
        label: resultsLabels.scoresRoundLabel,
        name: ScoreHistoryGridCellType.ROUND,
      },
      accessor: ScoreHistoryGridCellType.ROUND,
      Cell: (cellProps: Cell) => {
        return (
          <ScoreHistoryGridCell
            id={ScoreHistoryGridCellType.ROUND}
            cellType={ScoreHistoryGridCellType.ROUND}
            value={cellProps.value}
            isScoreUpdated={getData(props.data)[cellProps.row.index].isUpdated}
          />
        );
      },
    },
    {
      Header: {
        label: resultsLabels.scoresLabel,
        name: ScoreHistoryGridCellType.SCORE,
      },
      accessor: ScoreHistoryGridCellType.SCORE,
      sortType: 'basic',
      Cell: (cellProps: Cell) => (
        <ScoreHistoryGridCell
          id={ScoreHistoryGridCellType.SCORE}
          cellType={ScoreHistoryGridCellType.SCORE}
          value={cellProps.value}
          isExempt={getData(props.data)[cellProps.row.index].overallResultType === 'EXEMPT'}
          isEorPending={getData(props.data)[cellProps.row.index].overallResultType === 'PENDING_EOR'}
          isAbsent={getData(props.data)[cellProps.row.index].overallResultType === 'ABSENT'}
        />
      ),
    },
    {
      Header: {
        resultsTypeLabel: 'Results Type',
        label: resultsLabels.resultsTypeLabel,
        name: ScoreHistoryGridCellType.RESULTS_TYPE,
      },
      accessor: ScoreHistoryGridCellType.RESULTS_TYPE,
      Cell: (cellProps: Cell) => (
        <ScoreHistoryGridCell
          id={ScoreHistoryGridCellType.RESULTS_TYPE}
          cellType={ScoreHistoryGridCellType.RESULTS_TYPE}
          value={cellProps.value}
        />
      ),
    },
    {
      Header: {
        label: resultsLabels.dateReceivedLabel,
        name: ScoreHistoryGridCellType.DATE_RECEIVED,
      },
      accessor: ScoreHistoryGridCellType.DATE_RECEIVED,
      Cell: (cellProps: Cell) => (
        <div style={{ position: 'relative' }}>
          <ScoreHistoryGridCell
            id={ScoreHistoryGridCellType.DATE_RECEIVED}
            cellType={cellProps.value ? ScoreHistoryGridCellType.DATE_RECEIVED : ScoreHistoryGridCellType.PENDING}
            value={
              cellProps.value
                ? `${formatDate(cellProps.value, 'dd MMM yyyy')} | ${formatDate(cellProps.value, 'HH:mm')}`
                : resultsLabels.pendingLabel
            }
          />
        </div>
      ),
    },
    {
      Header: {
        label: '',
        name: 'BLANK',
      },
      accessor: 'BLANK',
    },
  ] as Column[];

  const renderExpandedRowItems = (row: ExpandedGridType) => {
    const { tasks } = row.rowData;
    return tasks?.map((task: TaskInfo, index: number) => (
      <ScoreCriteriaTask
        key={task.taskNumber}
        colSpan={columns.length}
        taskNumber={index + 1}
        examinerID={task.examiner || resultsLabels.pendingLabel}
        criterias={task.criterias}
        component={props.component}
      />
    ));
  };

  const doNothing = () => null;
  const getData = (data?: ComponentRoundInfo[]) => {
    if (!data || data.length === 0) {
      return [
        {
          componentEvaluationRoundId: 1,
          dateReceived: null,
          overallFinalGrade: resultsLabels.pendingLabel,
          overallResultType: resultsLabels.pendingLabel,
          isUpdated: false,
        },
      ];
    }
    return data;
  };

  return (
    <div
      id="scoreHistoryGridContainer"
      className={props.className ? [styles.grid, styles[props.className]].join(' ') : styles.grid}
    >
      <UI.ExpandableGrid
        id="scoreHistoryGrid"
        columns={columns}
        data={getData(props.data)}
        hideGridControls={true}
        initialState={{ pageSize: getData(props.data).length }}
        onPageChange={doNothing}
        onPageSizeChange={doNothing}
        totalRecords={getData(props.data).length}
        currentPage={0}
        pageSizeOptions={[{ text: '', value: 0 }]}
        expandedGrid={renderExpandedRowItems}
        selectedOptionValue={0}
      />
    </div>
  );
};

export default ScoreHistoryGrid;
