import React from 'react';
import { ScoreHistoryGridCellType } from '../ScoreHistoryGridConstants';
import styles from './ScoreHistoryGridCell.module.scss';
import { GridCellProps } from '../../../Organisms/ResultsGridCell/ResultsGridCell';
import { languageService } from '../../../../services/Language/LanguageService';
import Clock from '../../../../assets/images/Clock.svg';

const getResultType = (value: string) => {
  switch (value) {
    case 'JAGGED-1':
      return 'Jagged 1';
    case 'JAGGED-2':
      return 'Jagged 2';
    case 'NORMAL':
      return 'Normal';
    case 'EOR':
      return 'EOR';
    case 'PENDING_EOR':
      return 'EOR Pending';
    case 'ABSENT':
      return 'Absent';
    case 'EXEMPT':
      return 'Exempt';

    default:
      return value;
  }
};

const ScoreHistoryGridCell = (props: GridCellProps) => {
  const { value, isAbsent, isEorPending, isExempt } = props;
  const resultsLabels = languageService().result;

  switch (props.cellType) {
    case ScoreHistoryGridCellType.ROUND:
      return (
        <div className={styles.scoreHistoryRoundColumn}>
          <label id={props.id} className={styles.label}>
            {`${resultsLabels.scoresRoundLabel} ${value}`}
          </label>
          {props.isScoreUpdated && <label className={styles.updatedLabel}>{resultsLabels.updated}</label>}
        </div>
      );
    case ScoreHistoryGridCellType.RESULTS_TYPE:
      return (
        <label id={props.id} className={styles.label}>
          {value ? getResultType(value) : ''}
        </label>
      );
    case ScoreHistoryGridCellType.SCORE:
      return (
        <label id={props.id} className={styles.label}>
          {isEorPending || isAbsent ? '-' : value}
        </label>
      );
    case ScoreHistoryGridCellType.RAW_SCORE:
      return (
        <label id={props.id} className={styles.label}>
          {isEorPending || isAbsent || isExempt ? '-' : value}
        </label>
      );

    case ScoreHistoryGridCellType.PENDING:
      return (
        <label id={props.id} className={styles.label}>
          {value}
        </label>
      );
    case ScoreHistoryGridCellType.DATE_RECEIVED:
      return (
        <label id={props.id} className={styles.dateReceived}>
          <img alt="" src={Clock} className={styles.clock} />
          {value}
        </label>
      );
    case ScoreHistoryGridCellType.EXPAND:
      return (
        <button id={props.id} className={styles.more} onClick={props.onChangeHandler}>
          <img alt="" src={props.icon} className={props.isExpanded ? styles.expandedArrow : styles.collapsedArrow} />
        </button>
      );
    default:
      return null;
  }
};

export default ScoreHistoryGridCell;
