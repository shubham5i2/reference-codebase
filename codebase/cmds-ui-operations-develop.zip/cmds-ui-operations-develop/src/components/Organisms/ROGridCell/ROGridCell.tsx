import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import { getValue, statusStyle } from '../../utils/utilities';
import { ROGridCellType } from '../ROGrid/ROGridConstants';
import styles from './ROGridCell.module.scss';

export interface ROGridCellProps {
  value?: string;
  cellType: string;
  id?: string;
  onChangeHandler?: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
  icon?: string;
}

const ROGridCell = (props: ROGridCellProps) => {
  const value = props.value || '';
  console.log({ props });
  switch (props.cellType) {
    case ROGridCellType.RONAME:
    case ROGridCellType.ROID:
    case ROGridCellType.ADDRESS:
    case ROGridCellType.COUNTRY:
    case ROGridCellType.STATETERRITORY:
    case ROGridCellType.ORGANISATION_TYPE:
      return (
        <label id={props.id} className={`${styles.roLabel}`}>
          {value === '' ? '-' : value}
        </label>
      );
    case ROGridCellType.ACTIVESTATUS:
      return (
        <UI.Status status={statusStyle[getValue(value).toUpperCase()]} label={value} typographyProps={{ size: 12 }} />
      );
    case ROGridCellType.MORE:
    case ROGridCellType.EXPAND:
      return (
        <button id={props.id} className={styles.more} onClick={props.onChangeHandler}>
          <img alt="" src={props.icon} />
        </button>
      );
    default:
      return null;
  }
};

export default ROGridCell;
