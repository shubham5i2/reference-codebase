import React, { useEffect, useRef } from 'react';
import { BookingDetails } from '../../../services/Models/TestTakerManagement';
import { languageService } from '../../../services/Language/LanguageService';
import styles from './TestTakerBookingHistoryLeftPanel.module.scss';
import { getProductValue } from '../../../services/API/Result/Product';
import users from '../../../assets/images/BookingCalendar.svg';
import MoreIcon from '../../../assets/images/More.svg';
import ArrowUp from '../../../assets/images/Chevron_Up.svg';
import ArrowDown from '../../../assets/images/ArrowDown.svg';
import { formatDate, getPartnerCode, getValue } from '../../utils/utilities';
import { Location } from '../../../services/Models/StaffManagement';
import { useStateValue } from '../../../Store/helpers/UseStateValue';
import { useAuth0 } from '@auth0/auth0-react';
import {
  BookingHistoryActionsProps,
  TestTakerBookingHistoryPageActionsProps,
} from '../../Pages/TestTakerBookingHistoryPage/TestTakerBookingHistoryPage';
import TestTakerBookingHistoryActionsContainer from '../TestTakerBookingHistoryActionsContainer/TestTakerBookingHistoryActionsContainer';
import { getResultData, ResultType } from '../../../services/API/Reference/ResultStatus';
import { CurrentResultStatus } from '../../../services/Models/Result';
import { getLocationKey } from '../LocationDropdown/LocationDropdownUtils';
import { LocationType } from '../../../services/Models/LocationManagement';

export interface TestTakerBookingHistoryLeftPanelProps {
  uniqueTestTakerUuid: string;
  bookingUuid: string;
  bookingDetails: BookingDetails;
  index: number;
  isExpanded: boolean;
  onExpandClickHandler: (bookingUuid: string) => void;
  selectedToolTipIndex: number | null;
  historyPanelActions: BookingHistoryActionsProps[];
  moreClickHandler: (index: number, exclusionAction: boolean) => void;
  userActionsClickHandler: (props: TestTakerBookingHistoryPageActionsProps) => void;
  actionContainerRef: React.RefObject<HTMLSpanElement>;
  isExclusionPanelAction: boolean;
  getResultStatusData: (bookingUuid: string) => void;
  resultData: CurrentResultStatus;
}
const TestTakerBookingHistoryLeftPanel = (props: TestTakerBookingHistoryLeftPanelProps) => {
  const testTakerLabels = languageService().testTaker;
  const sliderRef = useRef<null | HTMLDivElement>(null);
  const { state } = useStateValue();
  const { user } = useAuth0();

  useEffect(() => {
    props.bookingUuid && props.isExpanded && props.getResultStatusData(props.bookingUuid);
    //eslint-disable-next-line
  }, [props.bookingUuid]);

  const onExpandClickHandler = (bookingUuid: string) => {
    props.onExpandClickHandler(bookingUuid);
    sliderRef.current?.scrollIntoView();
  };

  const partnerCode = getPartnerCode(user || {});
  const locationKey = getLocationKey(LocationType.TEST_CENTRE, partnerCode, 'getLocations');
  const locationsResponse = state.locationData?.[locationKey]?.response || [];
  console.log('locationResponse', locationsResponse);
  const productResponse = state.products?.response;
  const getLocationData = (dataType: string, locationUuid: string) => {
    if (locationsResponse && dataType === 'locationCode') {
      return locationsResponse.find((location: Location) => locationUuid === location.locationUuid)?.locationCode || '';
    }
    if (locationsResponse && dataType === 'locationName') {
      return locationsResponse.find((location: Location) => locationUuid === location.locationUuid)?.locationName || '';
    }
    return '';
  };

  const isMoreSelected = props.selectedToolTipIndex === props.index && !props.isExclusionPanelAction;
  const moreSelectedClass = isMoreSelected ? styles.ttbhActionsOpened : '';

  return (
    <div className={styles.ttbhLeftPanelContainer} ref={sliderRef}>
      <div className={styles.ttbhExpandableContainer}>
        <TestTakerBookingHistoryActionsContainer
          dataLabelClass={styles.ttbhExpandableContainerTitle}
          containerClass={`${styles.ttbhActionsContainer} ${moreSelectedClass} ${styles.moreBtn}`}
          actionContainerRef={props.actionContainerRef}
          containerId="ttbhActionsContainer"
          moreClickHandler={props.moreClickHandler}
          iconSrc={MoreIcon}
          isMoreSelected={isMoreSelected}
          panelActions={props.historyPanelActions}
          index={props.index}
          isExclusion={false}
          bookingUuid={props.bookingUuid}
          uniqueTestTakerUuid={props.uniqueTestTakerUuid}
          testTakerName={
            props.bookingDetails.testTakerInfo.firstName + ' ' + props.bookingDetails.testTakerInfo.lastName
          }
          userActionsClickHandler={props.userActionsClickHandler}
          ttbhDetailsTitle={testTakerLabels.ttbhDetailsTitle + ' ' + props.index}
          userProfileSrc={users}
        />
        <span className={styles.ttbhExpandableContainerExpandIcon}>
          <button onClick={() => onExpandClickHandler(props.bookingUuid)}>
            {props.isExpanded ? <img alt="" src={ArrowUp} /> : <img alt="" src={ArrowDown} />}
          </button>
        </span>
      </div>
      <div
        className={
          props.isExpanded ? styles.ttbhBookingDetailsContainerActive : styles.ttbhBookingDetailsContainerInactive
        }
      >
        <div className={styles.ttbhDetailsContainer}>
          <span>{testTakerLabels.ttbhPITitle.toUpperCase()}</span>
          <div className={styles.ttbhDetailsContainerGrid}>
            <div>
              <span>{testTakerLabels.givenName}</span>
              <span>{props.bookingDetails.testTakerInfo.firstName}</span>
            </div>
            <div>
              <span>{testTakerLabels.familyName}</span>
              <span>{props.bookingDetails.testTakerInfo.lastName}</span>
            </div>
            <div>
              <span>{testTakerLabels.dateOfBirth}</span>
              <span>
                {formatDate(new Date(props.bookingDetails.testTakerInfo.birthDate), testTakerLabels.uiDateFormat)}
              </span>
            </div>
            <div>
              <span>{testTakerLabels.nationality}</span>
              <span>{props.bookingDetails.testTakerInfo.nationality}</span>
            </div>
            <div>
              <span>{testTakerLabels.email}</span>
              <span>{props.bookingDetails.testTakerInfo.email}</span>
            </div>
            <div>
              <span>{testTakerLabels.identityDocumentNumber}</span>
              <span>{props.bookingDetails.testTakerInfo.identityNumber}</span>
            </div>
          </div>
        </div>
        <div className={styles.ttbhDetailsContainer}>
          <span>{testTakerLabels.ttbhBookingTitle.toUpperCase()}</span>
          <div className={styles.ttbhDetailsContainerGrid}>
            <div>
              <span>{testTakerLabels.ttbhBookingTestDate}</span>
              <span>
                {formatDate(new Date(props.bookingDetails.testBookingInfo.testDate), testTakerLabels.uiDateFormat)}
              </span>
            </div>
            <div>
              <span>{testTakerLabels.ttbhBookingProduct}</span>
              <span>{getProductValue(props.bookingDetails.testBookingInfo.productUuid, productResponse)}</span>
            </div>
            <div>
              <span>{testTakerLabels.ttbhBookingTestCentreNumber}</span>
              <span>{props.bookingDetails.testBookingInfo.testCentreNumber}</span>
            </div>
            <div>
              <span>{testTakerLabels.ttbhBookingTestCentreName}</span>
              <span>{getLocationData('locationName', props.bookingDetails.testBookingInfo.testCentreUuid)}</span>
            </div>
            <div>
              <span>{testTakerLabels.ttbhBookingTestLocationId}</span>
              <span>{props.bookingDetails.testBookingInfo.locationUuid}</span>
            </div>
            <div>
              <span>{testTakerLabels.ttbhBookingTestLocation}</span>
              <span>{props.bookingDetails.testBookingInfo?.locationName}</span>
            </div>
          </div>
        </div>
        <div className={styles.ttbhDetailsContainer}>
          <span>{testTakerLabels.ttbhResultTitle.toUpperCase()}</span>
          <div className={styles.ttbhDetailsContainerGrid}>
            <div>
              <span>{testTakerLabels.ttbhResultStatus}</span>
              <span>{getResultData(props.resultData?.resultStatusTypeUuid, ResultType.STATUS)}</span>
            </div>
            <div>
              <span>{testTakerLabels.ttbhResultStatusLabel}</span>
              <span>{getResultData(props.resultData?.resultStatusLabelUuid, ResultType.LABEL)}</span>
            </div>
            <div>
              <span>{testTakerLabels.ttbhResultStatusComment}</span>
              <span id={styles.autoHeight}>{props.resultData?.resultStatusComment}</span>
            </div>
            <div>
              <span>{testTakerLabels.ttbhResultStatusDate}</span>
              <span>
                {formatDate(
                  new Date(getValue(props.resultData?.resultStatusUpdateDatetime)),
                  testTakerLabels.uiDateFormat,
                )}
              </span>
            </div>
            <div>
              <span>{testTakerLabels.ttbhResultBanStatus}</span>
              <span>{getValue(props.bookingDetails.resultStatusInfo?.banStatus)}</span>
            </div>
          </div>
        </div>
        <div className={styles.ttbhDetailsContainer}>
          <span className={styles.ttbhOther}>{testTakerLabels.ttbhOtherInfo.toUpperCase()}</span>
          <div className={styles.ttbhDetailsContainerGrid}>
            <div>
              <span>{testTakerLabels.ttbhMatchDate}</span>
              <span>
                {formatDate(new Date(props.bookingDetails.bookingOtherInfo.matchDate), testTakerLabels.uiDateFormat)}
              </span>
            </div>
            <div>
              <span>{testTakerLabels.ttbhMatchEvent}</span>
              <span>{props.bookingDetails.bookingOtherInfo.matchEvent}</span>
            </div>
            <div>
              <span>{testTakerLabels.ttbhNotes}</span>
              <span className={styles.ttbhOther}>
                {!props.bookingDetails.bookingOtherInfo.notes
                  ? props.bookingDetails.bookingOtherInfo.Notes
                  : props.bookingDetails.bookingOtherInfo.notes}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TestTakerBookingHistoryLeftPanel;
