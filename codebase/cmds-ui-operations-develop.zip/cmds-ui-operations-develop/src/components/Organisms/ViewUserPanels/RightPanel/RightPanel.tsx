import React from 'react';
import styles from './RightPanel.module.scss';

const RightPanel = (props: any) => {
  return (
    <div className={styles.rightpanelContainer}>
      <div className={styles.panelHeader} id="RightPanelHeader">
        <span>User Group(s)</span>
      </div>
      <div className={styles.panelSectionContainer} id="RightPanelSectionContainer">
        {props.userGroups.map((result: any, index: number) => {
          return (
            <div className={styles.panelSection} id={'RightPanelSection_' + index} key={result.id}>
              {result.assignment && props.userGroups.length > 1 ? (
                <div className={styles.label} id={'AssignmentLabel_' + index}>
                  {result.assignment}
                </div>
              ) : (
                ''
              )}
              {result.data.map((userdata: any, index: number) => {
                return (
                  <div className={styles.panelSectionRight} key={userdata.id} id={'RightPanelTopHolder_' + index}>
                    <div className={styles.panelTile} id={'RightPanelHolder_' + index}>
                      <p className={styles.title} id={'RightPanelTitle_' + index}>
                        {userdata.title}
                      </p>
                      <p className={styles.content} id={'RightPanelContent_' + index}>
                        {userdata.value}
                      </p>
                    </div>
                  </div>
                );
              })}
              {props.userGroups.length > 1 ? <div className={styles.userBorder}></div> : ''}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default RightPanel;
