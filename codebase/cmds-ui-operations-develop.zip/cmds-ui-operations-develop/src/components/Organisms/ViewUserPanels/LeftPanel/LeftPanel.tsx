import React, { useEffect, useState } from 'react';
import styles from './LeftPanel.module.scss';

const LeftPanel = (props: any) => {
  const [userInfo, setUserInfo] = useState([]);

  useEffect(() => {
    if (!props.userInfo || props.userInfo.length > 0) {
      console.warn('User Info Data : ', 'props - User Info not passed or received "" empty value');
    }

    setUserInfo(props.userInfo);
  }, [props.userInfo]);

  return (
    <div className={styles.panelContainer} id="panelContainer">
      <div className={styles.panelHeader} id="panelHeader">
        <span>{props.header}</span>
      </div>

      <div className={styles.panelSection} id="panelSection">
        {userInfo.map((item: any, index: number) => {
          return (
            <div className={styles.panelTile} id={'panelTile_' + index} key={index}>
              <p className={styles.title} id={'title_' + index}>
                {item.title}
              </p>
              <div>
                <p className={styles.content} id={'content_' + index}>
                  {item.value}
                </p>
                {item.verify && (
                  <span className={`${styles.phone} ${styles[item.verify.toLowerCase()]}`} id="verify">
                    {item.verify}
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default LeftPanel;
