import React, { useEffect, useRef, useState } from 'react';
import UI from 'ielts-cmds-ui-component-library';
import { BookingList, ManageTestTakerSortOption, TestTaker } from '../../../services/Models/TestTakerManagement';
import styles from './ManageTestTakerGrid.module.scss';
import TestTakerGridCell from '../TestTakerGridCell/TestTakerGridCell';
import { TestTakerGridCellType } from './ManageTestTakerGridConstants';
import testTakerLabels from '../../../services/Language/en/en.testtaker';
import ArrowDownIcon from '../../../assets/images/Chevron_Down.svg';
import ArrowUpIcon from '../../../assets/images/Chevron_Up.svg';
import MoreIcon from '../../../assets/images/More.svg';
import visibilityIcon from '../../../assets/images/visibility.svg';
import ManageUsersActions from '../../Molecules/ManageUsersActions/ManageUsersActions';
import { Action } from '../../../services/Models/Api';
import { useHistory } from 'react-router-dom';
import { Cell, Column, Row } from 'react-table';
import { formatDate } from '../../utils/utilities';
import { formGridData } from './FormatTestTakerData';
import { getNationalityData } from '../../../services/API/Reference/Nationality';
import { ExpandedGridType, GridProps } from '../../../services/Models/UIModels';

interface TestTakerGridProps extends GridProps {
  data: TestTaker[];
  isLoading: boolean;
}

export enum TestTakerActionType {
  VIEW_DETAILS = 'VIEW_DETAILS',
}

const manageTestTakerActions = [
  { label: testTakerLabels.viewDetails, type: TestTakerActionType.VIEW_DETAILS, icon: visibilityIcon },
];

const ManageTestTakerGrid = (props: TestTakerGridProps) => {
  const userActionsContainerRef = useRef<HTMLDivElement>();
  const history = useHistory();
  const [selectedToolTipIndex, setSelectedToolTipIndex] = useState<number | null>(null);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const toggleExpansion: string[] = [];
  const formattedData = formGridData(props.data);

  useEffect(() => {
    document.addEventListener('mousedown', handleClick);

    return () => {
      document.removeEventListener('mousedown', handleClick);
    };
  }, []);

  const handleClick = (e: Event) => {
    const userActionsContainerClassName =
      userActionsContainerRef.current && userActionsContainerRef.current !== null
        ? userActionsContainerRef.current?.className
        : '';
    const target = e.target as HTMLElement;
    const targetElementClassName =
      target.offsetParent && target.offsetParent !== null ? target.offsetParent.className : '';
    if (
      userActionsContainerClassName === targetElementClassName ||
      targetElementClassName.includes('ManageUsersActions_manageUsersActions')
    ) {
      return;
    }
    setSelectedToolTipIndex(null);
  };

  const testTakerData = props.data;

  const moreClickHandler = (props: Row) => {
    setSelectedIndex(props.index);
    if (selectedToolTipIndex === props.index) {
      setSelectedToolTipIndex(null);
    } else {
      setSelectedToolTipIndex(props.index);
    }
  };

  const testTakerActionsHandler = (action: Action, index: number) => {
    switch (action.type) {
      case TestTakerActionType.VIEW_DETAILS:
        history.push(`/managetesttaker/testtakerbookinghistory/${props.data[index].uniqueTestTakerUuid}`, {
          selectedRow: index + 1,
          selectedBookingUuid: props.data[index].bookingList[0].bookingUuid,
          selectedUniqueTestTakerId: props.data[index].uniqueTestTakerId,
        });
        break;
    }
    setSelectedToolTipIndex(null);
  };

  const iconClickHandler = (index: number) => {
    const testTakerId = testTakerData[index].uniqueTestTakerId;
    const dataIndex = toggleExpansion.indexOf(testTakerId);
    if (dataIndex >= 0) {
      toggleExpansion.splice(dataIndex, 1);
    } else {
      toggleExpansion.push(testTakerId);
    }
  };
  const isArrowIconDisable = (index: number) => testTakerData[index].bookingList.length <= 1;

  const columns = [
    {
      id: 'expander',
      Cell: ({ row }: any) => {
        const index = row.index;
        return (
          <span {...row.getToggleRowExpandedProps()}>
            <TestTakerGridCell
              id="expandBtn"
              disability={isArrowIconDisable(index)}
              cellType={TestTakerGridCellType.EXPAND}
              icon={toggleExpansion.includes(testTakerData[index].uniqueTestTakerId) ? ArrowUpIcon : ArrowDownIcon}
              onChangeHandler={() => iconClickHandler(index)}
            />
          </span>
        );
      },
    },
    {
      Header: {
        label: testTakerLabels.uniqueTestTakerId.toUpperCase(),
        name: ManageTestTakerSortOption.UNIQUE_TEST_TAKER_ID,
      },
      accessor: 'uniqueTestTakerId',
      sortType: 'basic',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell
          id="uniqueTestTakerId"
          cellType={TestTakerGridCellType.UNIQUETESTTAKERID}
          value={cellProps.value}
        />
      ),
    },
    {
      Header: {
        name: ManageTestTakerSortOption.BANNED_STATUS,
      },
      accessor: 'banStatus',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell id="banStatus" cellType={TestTakerGridCellType.BANNEDSTATUS} value={cellProps.value} />
      ),
    },
    {
      Header: {
        label: testTakerLabels.cmdsBookingId.toUpperCase(),
        name: ManageTestTakerSortOption.CMDS_BOOKING_ID,
      },
      accessor: 'bookingUuid',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell id="cmdsBookingId" cellType={TestTakerGridCellType.CMDSBOOKINGID} value={cellProps.value} />
      ),
      disableSortBy: true,
    },
    {
      Header: {
        label: testTakerLabels.identityDocumentNumber.toUpperCase(),
        name: ManageTestTakerSortOption.IDENTITY_DOCUMENT_NUMBER,
      },
      accessor: 'identityNumber',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell
          id="identityDocumentNumber"
          cellType={TestTakerGridCellType.IDENTITYDOCUMENTNUMBER}
          value={cellProps.value}
        />
      ),
      disableSortBy: true,
    },
    {
      Header: {
        label: testTakerLabels.givenName.toUpperCase(),
        name: ManageTestTakerSortOption.GIVEN_NAME,
      },
      accessor: 'firstName',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell id="givenName" cellType={TestTakerGridCellType.GIVENNAME} value={cellProps.value} />
      ),
      disableSortBy: true,
    },
    {
      Header: {
        label: testTakerLabels.familyName.toUpperCase(),
        name: ManageTestTakerSortOption.FAMILY_NAME,
      },
      accessor: 'lastName',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell id="familyName" cellType={TestTakerGridCellType.FAMILYNAME} value={cellProps.value} />
      ),
      disableSortBy: true,
    },
    {
      Header: {
        label: testTakerLabels.dateOfBirth.toUpperCase(),
      },
      accessor: 'birthDate',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell
          id="birthDate"
          cellType={TestTakerGridCellType.DATEOFBIRTH}
          value={formatDate(new Date(cellProps.value), testTakerLabels.uiDateFormat)}
        />
      ),
      disableSortBy: true,
    },
    {
      Header: {
        label: testTakerLabels.nationality.toUpperCase(),
      },
      accessor: 'nationalityUuid',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell
          id="nationality"
          cellType={TestTakerGridCellType.NATIONALITY}
          value={getNationalityData(cellProps.value)}
        />
      ),
      disableSortBy: true,
    },
    {
      Header: {
        label: testTakerLabels.email.toUpperCase(),
      },
      accessor: 'email',
      Cell: (cellProps: Cell) => (
        <TestTakerGridCell id="email" cellType={TestTakerGridCellType.EMAILID} value={cellProps.value} />
      ),
      disableSortBy: true,
    },
    {
      id: 'More',
      Cell: (cellProps: Cell) => {
        const isMoreSelected = selectedToolTipIndex === cellProps.row.index;
        const moreSelectedClass = isMoreSelected ? styles.userActionsOpened : '';
        return (
          <div
            id="TTActionsContainer"
            ref={userActionsContainerRef as React.RefObject<HTMLDivElement>}
            className={`${styles.userActionsContainer} ${moreSelectedClass}`}
          >
            <TestTakerGridCell
              id="moreButton"
              cellType={TestTakerGridCellType.MORE}
              value={cellProps.value}
              icon={MoreIcon}
              onChangeHandler={() => moreClickHandler(cellProps.row)}
            />
            {isMoreSelected ? (
              <span
                className={
                  formattedData.length - 1 === selectedToolTipIndex ? styles.actionViewLast : styles.actionViewPopUp
                }
              >
                <ManageUsersActions
                  id={'TestTakerActionContainer'}
                  userActions={manageTestTakerActions}
                  userActionsClickHandler={(action: Action) => testTakerActionsHandler(action, cellProps.row.index)}
                />
              </span>
            ) : null}
          </div>
        );
      },
      disableSortBy: true,
    },
  ] as Column[];

  const populateExpandedRow = (props: ExpandedGridType) => {
    const expandedRow = testTakerData
      .find((testTaker: TestTaker) => testTaker.uniqueTestTakerId === props.rowData.uniqueTestTakerId)
      ?.bookingList.slice(1);
    return (
      <React.Fragment>
        {expandedRow?.map((row: BookingList, index: number) => {
          return (
            <tr className={`${styles.expandedColorTestTaker} ${styles.expandedTd} ${styles.visibleTr}`} key={index}>
              <td />
              <td>
                <TestTakerGridCell
                  id="uniqueTestTakerId"
                  cellType={TestTakerGridCellType.UNIQUETESTTAKERID}
                  value={props.rowData.uniqueTestTakerId}
                />
              </td>
              <td>
                <TestTakerGridCell
                  id="banStatus"
                  cellType={TestTakerGridCellType.BANNEDSTATUS}
                  value={row?.banStatus}
                />
              </td>
              <td>
                <TestTakerGridCell
                  id="cmdsBookingId"
                  cellType={TestTakerGridCellType.CMDSBOOKINGID}
                  value={row?.bookingUuid}
                />
              </td>
              <td>
                <TestTakerGridCell
                  id="identityDocumentNumber"
                  cellType={TestTakerGridCellType.IDENTITYDOCUMENTNUMBER}
                  value={row?.identityNumber}
                />
              </td>
              <td>
                <TestTakerGridCell id="givenName" cellType={TestTakerGridCellType.GIVENNAME} value={row?.firstName} />
              </td>
              <td>
                <TestTakerGridCell id="familyName" cellType={TestTakerGridCellType.FAMILYNAME} value={row?.lastName} />
              </td>
              <td>
                <TestTakerGridCell
                  id="dateOfBirth"
                  cellType={TestTakerGridCellType.DATEOFBIRTH}
                  value={formatDate(new Date(row?.birthDate), testTakerLabels.uiDateFormat)}
                />
              </td>
              <td>
                <TestTakerGridCell
                  id="nationality"
                  cellType={TestTakerGridCellType.NATIONALITY}
                  value={getNationalityData(row?.nationalityUuid)}
                />
              </td>
              <td>
                <TestTakerGridCell id="email" cellType={TestTakerGridCellType.EMAILID} value={row?.email} />
              </td>
              <td></td>
            </tr>
          );
        })}
      </React.Fragment>
    );
  };

  return (
    <div id="manageTestTakerGrid" className={styles.manageTestTakersgrid}>
      <UI.ExpandableGrid
        id="testTakerGrid"
        columns={columns}
        data={formattedData}
        initialState={props.gridState.initialState}
        onPageChange={props.onPageChange}
        onPageSizeChange={props.onPageSizeChange}
        totalRecords={props.gridState.totalRecords}
        currentPage={props.gridState.selectedPage}
        pageSizeOptions={props.pageSizeOptions}
        selectedOptionValue={props.gridState.selectedOptionValue}
        onColumnSort={props.onColumnSort}
        sortOption={props.sortOption}
        sort={props.sort}
        expandedGrid={populateExpandedRow}
        selectedIndex={selectedIndex}
        isLoading={props.isLoading}
      />
    </div>
  );
};

export default ManageTestTakerGrid;
