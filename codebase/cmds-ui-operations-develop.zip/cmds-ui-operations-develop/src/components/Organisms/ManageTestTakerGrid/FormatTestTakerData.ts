import { TestTaker } from '../../../services/Models/TestTakerManagement';

export interface TestTakerGrid {
  uniqueTestTakerId: string;
  uniqueTestTakerUuid: string;
  bookingUuid: string;
  firstName: string;
  lastName: string;
  email: string;
  birthDate: string;
  identityNumber: string;
  nationalityUuid: string;
  nationality: string;
  testDate: string;
  shortCandidateNumber: string;
  testCentreNumber: string;
  identityVerificationStatus: string;
  banStatus: string;
}

export const formGridData = (data: TestTaker[]) => {
  return data.map((item: TestTaker) => {
    return {
      ...item.bookingList[0],
      uniqueTestTakerId: item.uniqueTestTakerId,
      uniqueTestTakerUuid: item.uniqueTestTakerUuid,
    };
  });
};
