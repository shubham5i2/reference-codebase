import React from 'react';
import styles from './ResultsStatusUpdateForm.module.scss';
import cx from 'classnames';
import UI from 'ielts-cmds-ui-component-library';
import ResultsStatusLabelDropDown from '../BaseDropDown/ResultsStatusLabelDropDown/ResultsStatusLabelDropDown';
import ResultStatusDropDown from '../BaseDropDown/ResultStatusDropDown/ResultStatusDropDown';
import ResultsStatusCommentsDropDown from '../BaseDropDown/ResultsStatusCommentsDropdown/ResultsStatusCommentsDropDown';
import { languageService } from '../../../services/Language/LanguageService';
import { ResultsUpdateStatusData } from '../../../services/Models/Result';
import withServiceRequest, { ServiceRequest } from '../../../services/utils/ServiceRequest';
interface FormPanelProps {
  handleInputChange: (resultStatusLabelUuid: string, value: string) => void;
  resultsUpdateStatusData: ResultsUpdateStatusData;
  serviceRequest: ServiceRequest;
  hideTextarea: boolean;
  handleClick: () => void;
  handleCancel: () => void;
  handleUpdate: () => void;
  selectedDataCount: number;
}

const ResultStatusUpdateForm = (props: FormPanelProps) => {
  const resultLabels = languageService().result;
  const {
    handleInputChange,
    resultsUpdateStatusData,
    handleClick,
    hideTextarea,
    handleCancel,
    handleUpdate,
    selectedDataCount,
  } = props;

  return (
    <>
      <div className={cx(styles.formPanel, styles.form)}>
        <div className={styles.panelContainer}>
          <div className={styles.panelTitle}>
            <UI.Typography id="panelTitle" type="bold" label={resultLabels.resultsUpdateStatusPanelTitle} size={20} />
          </div>
          <div className={styles.columnTwo}>
            <ResultStatusDropDown
              id="resultStatus"
              isFilterEnabled={false}
              label={resultLabels.resultsStatusLabel}
              textBoxPlaceHolder={resultLabels.resultsStatusDropDownPlaceholder}
              labelId="resultStatusLB"
              onChange={(value: string) => handleInputChange('resultStatusTypeUuid', value)}
              selectedValue={resultsUpdateStatusData?.resultStatusTypeUuid || ''}
              serviceRequest={props.serviceRequest}
              isFetchDataOnLoad={true}
            />
            <ResultsStatusLabelDropDown
              id="resultStatusLabel"
              isFilterEnabled={false}
              label={resultLabels.resultsStatusLabelLabel}
              textBoxPlaceHolder={resultLabels.resultsStatusLabelDropDownPlaceholder}
              labelId="resultStatusLabelLB"
              onChange={(value: string) => handleInputChange('resultStatusLabelUuid', value)}
              selectedValue={resultsUpdateStatusData?.resultStatusLabelUuid || ''}
              resultStatusTypeUuid={resultsUpdateStatusData?.resultStatusTypeUuid || ''}
              serviceRequest={props.serviceRequest}
              isFetchDataOnLoad={true}
            />
          </div>
        </div>
        <hr className={styles.lineSeperator} />
        <div className={styles.panelSubContainer}>
          <div className={styles.panelSubTitle}>
            <UI.Typography
              id="panelSubTitle"
              type="normal"
              label={resultLabels.resultsUpdateStatusSubTitle}
              size={16}
            />
          </div>
          <ResultsStatusCommentsDropDown
            id="resultStatusComment"
            isFilterEnabled={false}
            label={resultLabels.resultsStatusComments}
            labelId="resultStatusCommentLB"
            onChange={(value: string) => handleInputChange('resultStatusCommentUuid', value)}
            selectedValue={resultsUpdateStatusData?.resultStatusCommentUuid || ''}
            resultStatusTypeUuid={resultsUpdateStatusData?.resultStatusTypeUuid || ''}
            resultStatusLabelUuid={resultsUpdateStatusData?.resultStatusLabelUuid || ''}
            serviceRequest={props.serviceRequest}
            isFetchDataOnLoad={true}
          />
          <div className={styles.linkField}>
            <span id="commentLink" onClick={() => handleClick()}>
              <UI.Typography
                id="commentLink"
                type="medium"
                label={resultLabels.resultsUpdateStatusCommentLinkText}
                size={14}
                highlight={true}
              />
            </span>
          </div>
          <div
            className={
              hideTextarea && !resultsUpdateStatusData?.resultStatusCommentText ? styles.hide : styles.commentTextArea
            }
          >
            <UI.TextArea
              label=""
              labelId="resultStatusCommentText"
              value={resultsUpdateStatusData?.resultStatusCommentText || ''}
              name="resultStatusCommentText"
              id="resultStatusCommentText"
              placeholder={resultLabels.resultsUpdateStatusCommentPlaceholder}
              inputType="textArea"
              onChange={(ev: React.ChangeEvent<HTMLInputElement>) =>
                handleInputChange('resultStatusCommentText', ev.target.value)
              }
              maxLength={100}
            />
          </div>
        </div>
      </div>
      <div className={styles.formButton}>
        <UI.Button label={resultLabels.cancel} color="secondary" id={'Cancel'} onChange={handleCancel} />
        <UI.Button
          label={resultLabels.update}
          id={'Update'}
          color="primary"
          onChange={handleUpdate}
          disabled={selectedDataCount < 2}
        />
      </div>
    </>
  );
};

export default withServiceRequest(ResultStatusUpdateForm);
