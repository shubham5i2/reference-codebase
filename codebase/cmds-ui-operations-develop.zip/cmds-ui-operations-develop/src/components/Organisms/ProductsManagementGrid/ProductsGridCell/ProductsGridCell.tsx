import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
// import Status from '../../../Molecules/Status/Status';
import FooterButtons from '../../../Molecules/FooterButtons/FooterButtons';

import styles from './ProductsGridCell.module.scss';
import { getValue, statusStyle } from '../../../utils/utilities';

export enum ProductsCellType {
  ACTIONS,
  LABEL,
  STATUS,
  DATE,
}
export interface ProductGridCellProps {
  cellType: ProductsCellType;
  value?: string;
  id?: string;
  onDateChange?: (val: Date) => void;
  onSave?: () => void;
  onCancel?: () => void;
  modifiedProd?: { isStatusChanged: boolean };
}

const ProductsGridCell = ({
  id,
  cellType,
  value,
  onDateChange,
  onSave = () => {
    throw new Error('Please pass save change handler');
  },
  onCancel = () => {
    throw new Error('Please pass cancel change handler');
  },
  modifiedProd,
}: ProductGridCellProps) => {
  if (cellType === ProductsCellType.DATE) {
    return (
      <div className={styles.datepickerContainer}>
        <UI.DatePicker
          id="effectiveToDate"
          minDate="1900-01-01"
          maxDate="2100-12-31"
          value={value}
          onChange={(val: Date) => onDateChange && onDateChange(val)}
          // resetDate={basicSearchData.dateofbirth === ''}
        />
      </div>
    );
  } else if (cellType === ProductsCellType.STATUS) {
    return (
      <div className={styles.statusContainer}>
        <UI.Status status={statusStyle[getValue(value?.toUpperCase())]} label={value} />
        {modifiedProd?.isStatusChanged ? <span className={styles.warning}></span> : null}
      </div>
    );
  } else if (cellType === ProductsCellType.ACTIONS) {
    const isProdChanged = !!modifiedProd;
    return (
      <FooterButtons
        containerClass={styles.footerButtons}
        addOrUpdateButtonText={'Save'}
        disabledButtons={{ isSubmitDisabled: !isProdChanged, isCancelDisabled: !isProdChanged }}
        onCancel={onCancel}
        onSubmit={onSave}
      />
    );
  } else {
    return (
      //className={`${styles.label}`
      <label id={id}>{value}</label>
    );
  }
};

export default ProductsGridCell;
