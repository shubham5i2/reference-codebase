import React, { useEffect, useState } from 'react';
import UI from 'ielts-cmds-ui-component-library';
// import { UpdateProducts } from '../../../services/API/ProductsManagement/UpdateProducts';

import { ProductsResponse } from '../../../services/Models/Result';
import { Dictionary } from '../../../services/Models/UIModels';
import withServiceRequest, { ServiceRequest } from '../../../services/utils/ServiceRequest';
import { orderProducts } from '../../Pages/ProductsManagement/ProductsManagementsUtils';
import { ProductType } from '../../Pages/ProductsManagement/ProductsSearch/ProductsSearch';
import { getProductGridColumns } from './ProductsGridColumns';

import styles from './ProductsGrid.module.scss';
import { getValue, isActiveToDate } from '../../utils/utilities';
import { UpdateProducts } from '../../../services/API/ProductsManagement/UpdateProducts';
import { AsyncResponse, AsyncResponseStatus } from '../../../services/Models/Api';
import { isProductEditableUser } from './ProductManagementUtils';
import { useAuth0 } from '@auth0/auth0-react';
import { getProducts } from '../../../services/API/Result/Product';

export interface ProductsManagementGridProps {
  type: ProductType;
  serviceRequest: ServiceRequest;
}

const getProductFromState = (products: ProductsResponse[], product: string | ProductsResponse) => {
  const expectedProdUuid = typeof product === 'string' ? product : product.productUuid;

  return (products || []).find((prod: ProductsResponse) => prod.productUuid === expectedProdUuid);
};

const ProductsManagementGrid = ({ type, serviceRequest }: ProductsManagementGridProps) => {
  const { user } = useAuth0();

  const [iolProducts, setIOLProducts] = useState<ProductsResponse[]>([]);
  const [iocProducts, setIOCProducts] = useState<ProductsResponse[]>([]);

  const [modifiedProducts, setModifiedProducts] = useState<Dictionary>();
  console.log(modifiedProducts);

  const data = type === 'Online' ? iolProducts : iocProducts;
  const setCurrentProductsData = type === 'Online' ? setIOLProducts : setIOCProducts;

  const [productsState, setProductsState] = useState({
    data: [],
    isLoading: false,
  });

  console.log({ productsState, data, iolProducts, type });

  useEffect(() => {
    // Always load the product on page load
    loadProduts();
    // eslint-disable-next-line
  }, []);

  useEffect(() => {
    if ((productsState.data || []).length && !iocProducts.length) {
      setIOCProducts(orderProducts(productsState.data, 'on Computer'));
    }
    if ((productsState.data || []).length && !iolProducts.length) {
      setIOLProducts(orderProducts(productsState.data, 'Online'));
    }
    // eslint-disable-next-line
  }, [productsState.data]);

  const loadProduts = () => {
    setProductsState({ isLoading: true, data: [] });
    getProducts(serviceRequest).subscribe((data) => {
      console.error('Data ===> ', data);
      setProductsState({ isLoading: false, data: data?.products || [] });
    });
  };

  const handleDateChange = (val: Date, selectedIdx: number) => {
    val.setHours(val.getHours() + 15); // Added to fix the ISOString conversion issue
    setCurrentProductsData((prevState: ProductsResponse[]) =>
      prevState.map((prod, idx) => {
        if (selectedIdx === idx) {
          const currentProduct = getProductFromState(productsState.data, prod.productUuid);
          setModifiedProducts((prevState) => ({
            ...prevState,
            [prod.productUuid]: {
              // Check if the status changed
              isStatusChanged:
                isActiveToDate(getValue(currentProduct?.effectiveToDate)) !== isActiveToDate(val.toISOString()),
            },
          }));
          return {
            ...prod,
            effectiveToDate: val.toISOString(),
          };
        }
        return prod;
      }),
    );
  };

  const handleProductSave = (product: ProductsResponse) => {
    clearModifiedProducts(product);
    UpdateProducts(product, serviceRequest).subscribe((res: AsyncResponse) => {
      if (res.status === AsyncResponseStatus.SUCCESS) {
        loadProduts();
      }
    });
  };

  const handleProductCancel = (product: ProductsResponse) => {
    clearModifiedProducts(product);
    setCurrentProductsData((prevState) => {
      return prevState.map((prod) => {
        if (prod.productUuid !== product.productUuid) {
          return prod;
        }
        return getProductFromState(productsState.data, product) || prod;
      });
    });
  };

  const clearModifiedProducts = (product: ProductsResponse) => {
    setModifiedProducts((prevState) => {
      const newData = {
        ...prevState,
      };
      delete newData[product.productUuid];
      return newData;
    });
  };

  const getHighlightedRows = () => {
    const highlightedIdx: Dictionary = {};
    Object.keys(modifiedProducts || {}).forEach((key) => {
      const index = data.findIndex((prod) => prod.productUuid === key);
      highlightedIdx[`${index}`] = true;
    });
    return highlightedIdx;
  };

  return (
    <div id="productsGridContainer" className={styles.productgrid}>
      {data.length > 0 ? (
        <UI.Grid
          id="locationGrid"
          initialState={{ pageSize: 100 }}
          columns={getProductGridColumns({
            canUserUpdate: isProductEditableUser(user),
            onDateChange: handleDateChange,
            modifiedProducts,
            onProductSave: handleProductSave,
            onProductCancel: handleProductCancel,
          })}
          data={data}
          hidePagination
          isLoading={productsState.isLoading}
          selectedOptionValue={100}
          highlightedRows={getHighlightedRows()}
        />
      ) : null}
    </div>
  );
};

export default withServiceRequest(ProductsManagementGrid);
