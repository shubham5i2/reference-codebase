import React from 'react';
import { Cell, Column } from 'react-table';
import { ProductsResponse } from '../../../services/Models/Result';
import { Dictionary } from '../../../services/Models/UIModels';
import { isActiveToDate } from '../../utils/utilities';
import ProductsGridCell, { ProductsCellType } from './ProductsGridCell/ProductsGridCell';

type ColumnOptions = {
  canUserUpdate: boolean;
  modifiedProducts?: Dictionary;
  onDateChange: (val: Date, idx: number) => void;
  onProductSave: (product: ProductsResponse) => void;
  onProductCancel: (product: ProductsResponse) => void;
};

const getApprovalRequiredText = (value = '') =>
  value.toUpperCase() === 'TRUE' || value.toUpperCase() === 'YES' ? 'Yes' : 'No';

const getProductStatus = (toDate: string) => {
  return isActiveToDate(toDate) ? 'Active' : 'Inactive';
};

const getHeader = (name: string, label?: string) => ({
  label: label?.toUpperCase(),
  name,
});

export const getProductGridColumns = ({
  canUserUpdate,
  modifiedProducts,
  onDateChange,
  onProductSave,
  onProductCancel,
}: ColumnOptions) => {
  return [
    {
      Header: getHeader('productName', 'Product Name'),
      accessor: 'productName',
      Cell: (cellProps: Cell) => <ProductsGridCell cellType={ProductsCellType.LABEL} value={cellProps.value} />,
    },
    {
      Header: getHeader('approvalRequired', 'Approval Required'),
      accessor: 'approvalRequired',
      Cell: (cellProps: Cell) => (
        <ProductsGridCell
          cellType={ProductsCellType.LABEL}
          value={getApprovalRequiredText(cellProps.value?.toString())}
        />
      ),
    },
    {
      Header: getHeader('availablefromDate', 'Available From Date'),
      accessor: 'effectiveFromDate',
      Cell: (cellProps: Cell) => <ProductsGridCell cellType={ProductsCellType.LABEL} value={cellProps.value} />,
    },
    {
      Header: getHeader('availableToDate', 'Available To Date'),
      accessor: 'effectiveToDate',
      Cell: (cellProps: Cell) => (
        <ProductsGridCell
          value={cellProps.value}
          cellType={canUserUpdate ? ProductsCellType.DATE : ProductsCellType.LABEL}
          onDateChange={canUserUpdate ? (val: Date) => onDateChange(val, cellProps.row.index) : undefined}
        />
      ),
    },
    {
      Header: getHeader('productStatus', 'Product Status'),
      accessor: 'Product Status',
      Cell: (cellProps: Cell) => {
        const changedProd = cellProps.row.original as ProductsResponse;
        const modifiedProd = modifiedProducts?.[changedProd.productUuid];

        return (
          <ProductsGridCell
            cellType={ProductsCellType.STATUS}
            value={getProductStatus(changedProd.effectiveToDate)}
            modifiedProd={modifiedProd}
          />
        );
      },
    },
    {
      Header: getHeader('actions', 'Action'),
      accessor: 'action',
      Cell: (cellProps: Cell) => {
        const changedProd = cellProps.row.original as ProductsResponse;
        const modifiedProd = modifiedProducts?.[changedProd.productUuid];
        return (
          <ProductsGridCell
            cellType={ProductsCellType.ACTIONS}
            onSave={() => onProductSave(changedProd)}
            onCancel={() => onProductCancel(changedProd)}
            modifiedProd={modifiedProd}
          />
        );
      },
    },
  ] as Column[];
};
