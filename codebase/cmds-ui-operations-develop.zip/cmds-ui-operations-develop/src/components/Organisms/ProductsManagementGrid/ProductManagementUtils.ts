import { User } from '@auth0/auth0-spa-js';
import { ROLES_KEY } from '../../../constants/GlobalConstants';
import { PRODUCTS_EDIT_USER } from '../../../services/hooks/UserGroupConstant';
import { splitDataFromKey } from '../../utils/utilities';

export const isProductEditableUser = (user?: User) => {
  const roles = (user?.[ROLES_KEY] || []).map((role: string) => splitDataFromKey(role, 'g:'));
  return PRODUCTS_EDIT_USER.filter((group) => !!roles.find((role: string) => group.value === role)).length > 0;
};
