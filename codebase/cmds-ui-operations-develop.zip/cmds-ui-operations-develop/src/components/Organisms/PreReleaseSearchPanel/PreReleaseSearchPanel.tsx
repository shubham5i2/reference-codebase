import React from 'react';
import styles from './PreReleaseSearchPanel.module.scss';
import UI from 'ielts-cmds-ui-component-library';
import { PreReleaseSearchData } from '../../../services/Models/PreReleaseManagement';

interface TextBoxValidator {
  isValid: boolean;
  message: string;
}
export interface PreReleaseSearchPanelProps {
  title: string;
  titleType: string;
  titleSize: string | number;
  subTitle: string;
  subTitleType: string;
  subTitleSize: string | number;
  basicSearchData: PreReleaseSearchData;
  onClearBasicSearch(event: React.FormEvent<HTMLInputElement> | React.FormEvent<HTMLAnchorElement>): void;
  clearBasicSearch: string;
  basicSearchButtonLabel: string;
  basicSearchButtonColor: string;
  onBasicSearchHandler: () => void;
  handleBasicInputChange: (e: React.FormEvent<HTMLInputElement>) => void;
  ieltsTestTakerLabel: string;
  centreNumberLabel: string;
  identityDocumentNumberLabel: string;
  testTakerNumberLabel: string;
  givenNameLabel: string;
  familyNameLabel: string;
  children: any;
  validation: TextBoxValidator;
  isSearchResults: boolean;
}

export enum inputNames {
  GIVEN_NAME = 'givenname',
  FAMILY_NAME = 'familyname',
  IDENTITY_DOCUMENT_NUMBER = 'identitydocumentnumber',
  UNIQUE_TEST_TAKER_ID = 'uniquetesttakerid',
  CENTRE_NUMBER = 'centrenumber',
  TEST_TAKER_NUMBER = 'testtakernumber',
}

const PreReleaseSearchPanel = (props: PreReleaseSearchPanelProps) => {
  return (
    <div className={styles.searchPanel}>
      <div className={styles.searchPanelTitle}>
        <UI.Typography type={props.titleType} label={props.title} size={props.titleSize} id="title" />
      </div>
      <div className={styles.searchPanelSubTitle}>
        <UI.Typography type={props.subTitleType} label={props.subTitle} size={props.subTitleSize} id="subTitle" />
      </div>
      <div className={styles.searchBox + ' ' + styles.col3}>
        <UI.TextBox
          label={props.ieltsTestTakerLabel}
          name={inputNames.UNIQUE_TEST_TAKER_ID}
          placeholder=""
          value={props.basicSearchData.uniquetesttakerid}
          onChange={props.handleBasicInputChange}
        />
        <UI.TextBox
          label={props.centreNumberLabel}
          name={inputNames.CENTRE_NUMBER}
          placeholder=""
          value={props.basicSearchData.centrenumber}
          onChange={props.handleBasicInputChange}
        />
        <UI.TextBox
          label={props.testTakerNumberLabel}
          name={inputNames.TEST_TAKER_NUMBER}
          placeholder=""
          value={props.basicSearchData.testtakernumber}
          onChange={props.handleBasicInputChange}
          inputFieldValidation={props.validation}
        />
        <UI.TextBox
          label={props.identityDocumentNumberLabel}
          name={inputNames.IDENTITY_DOCUMENT_NUMBER}
          placeholder=""
          value={props.basicSearchData.identitydocumentnumber}
          onChange={props.handleBasicInputChange}
        />
        <UI.TextBox
          label={props.givenNameLabel}
          name={inputNames.GIVEN_NAME}
          placeholder=""
          value={props.basicSearchData.givenname}
          onChange={props.handleBasicInputChange}
        />
        <UI.TextBox
          label={props.familyNameLabel}
          name={inputNames.FAMILY_NAME}
          placeholder=""
          value={props.basicSearchData.familyname}
          onChange={props.handleBasicInputChange}
        />
        {props.children}

        <div></div>
      </div>
      <div className={styles.row}>
        <div className={styles.clearSearch}>
          <a href="#clearBasic" onClick={props.onClearBasicSearch} className={styles.clearSearch} id="clearBasicSearch">
            <span>{props.clearBasicSearch}</span>
          </a>
        </div>
        <div className={props.clearBasicSearch !== '' ? `${styles.pushLeft}` : ``}>
          <UI.Button
            label={props.basicSearchButtonLabel}
            onChange={props.onBasicSearchHandler}
            color={props.basicSearchButtonColor}
            id="basicSearchButton"
          />
        </div>
      </div>
    </div>
  );
};
export default PreReleaseSearchPanel;
