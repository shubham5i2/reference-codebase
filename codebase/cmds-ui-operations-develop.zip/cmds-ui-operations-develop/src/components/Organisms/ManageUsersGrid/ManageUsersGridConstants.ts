export const ManageUsersCellType = {
  NAME: 'NAME',
  STAFFID: 'STAFFID',
  EMAILID: 'EMAILID',
  USERGROUPS: 'USERGROUPS',
  STATUS: 'STATUS',
  MORE: 'MORE',
};

export const pageSizeOptions = [
  { text: '10', value: 10 },
  { text: '25', value: 25 },
  { text: '50', value: 50 },
];
