import React, { useState, useEffect, useRef } from 'react';
import UI from 'ielts-cmds-ui-component-library';

import styles from '../ManageUsersGrid/ManageUsersGrid.module.scss';
import ManageUsersCell from '../ManageUsersCell/ManageUsersCell';
import { ManageUsersCellType } from './ManageUsersGridConstants';
import visibilityIcon from '../../../assets/images/visibility.svg';
import userProfilesIcon from '../../../assets/images/UserProfiles.svg';
import EditIcon from '../../../assets/images/Edit.svg';
import DeleteIcon from '../../../assets/images/Delete.svg';
import ManageUsersActions from '../../Molecules/ManageUsersActions/ManageUsersActions';
import { useHistory } from 'react-router-dom';
import DeleteUserDialog from '../../Others/DeleteUserDialog/DeleteUserDialog';
import { useStateValue } from '../../../Store/helpers/UseStateValue';
import { languageService } from '../../../services/Language/LanguageService';
import { ManageUserSortOption } from '../../../services/Models/StaffManagement';
import * as ManageUserActions from '../../../Store/Actions/ManageUserActions';
import { Cell } from 'react-table';

enum UserActionType {
  VIEW_DETAILS,
  ASSIGN_GROUP,
  UPDATE,
  DELETE,
}

const ManageUsersGrid = (props: any) => {
  const userActionsContainerRef: any = useRef();
  const [selectedToolTipIndex, setSelectedToolTipIndex] = useState(null);
  const [isDeleteUserIdx, setisDeleteUserIdx] = useState(-1);
  const [selectedUserIdx, setSelectedUserIdx] = useState(-1);
  const history: any = useHistory();
  const smLabels = languageService().staffManagement;

  const userActions = [
    { label: smLabels.viewDetails, type: UserActionType.VIEW_DETAILS, icon: visibilityIcon },
    { label: smLabels.assignGroup, type: UserActionType.ASSIGN_GROUP, icon: userProfilesIcon },
    { label: smLabels.update, type: UserActionType.UPDATE, icon: EditIcon },
    { label: smLabels.delete, type: UserActionType.DELETE, icon: DeleteIcon },
  ];

  const { state, dispatch } = useStateValue();

  useEffect(() => {
    document.addEventListener('mousedown', handleClick);

    return () => {
      document.removeEventListener('mousedown', handleClick);
    };
  }, []);

  const handleClick = (e: any) => {
    const userActionsContainerClassName =
      userActionsContainerRef.current && userActionsContainerRef.current !== null
        ? userActionsContainerRef.current.className
        : '';
    const targetElementClassName =
      e.target.offsetParent && e.target.offsetParent !== null ? e.target.offsetParent.className : '';
    if (
      userActionsContainerClassName === targetElementClassName ||
      targetElementClassName.includes('ManageUsersActions_manageUsersActions')
    ) {
      return;
    }
    setSelectedToolTipIndex(null);
  };

  const moreClickHandler = (props: any) => {
    if (selectedToolTipIndex === props.cell.row.index) {
      setSelectedToolTipIndex(null);
    } else {
      setSelectedToolTipIndex(props.cell.row.index);
    }
  };

  const userActionsHandler = (action: any, index: number) => {
    const currentUrl = '/manageuser';
    setSelectedUserIdx(index);
    switch (action.type) {
      case UserActionType.VIEW_DETAILS:
        history.push(`${currentUrl}/viewUserPage/${props.data[index].staffId}`, {
          selectedRow: index + 1,
        });
        break;
      case UserActionType.ASSIGN_GROUP:
        dispatch({
          type: ManageUserActions.USER_EDIT_STATUS,
          payload: true,
        });

        history.push({
          pathname: `${currentUrl}/assigngroup/${props.data[index].staffId}`,
          state: { userGroup: props.data[index].userGroups },
        });
        break;
      case UserActionType.UPDATE:
        dispatch({
          type: ManageUserActions.USER_EDIT_STATUS,
          payload: true,
        });
        history.push(`${currentUrl}/updateuser/${props.data[index].staffId}`);
        break;
      case UserActionType.DELETE:
        setisDeleteUserIdx(index + 1);
        break;
    }
    setSelectedToolTipIndex(null);
  };

  const getUsersGridItem = (cellProps: Cell, name: string) => {
    return <ManageUsersCell cellType={name} value={cellProps.value} />;
  };

  const columns = [
    {
      Header: {
        label: smLabels.name.toUpperCase(),
        name: [ManageUserSortOption.GIVEN_NAME, ManageUserSortOption.FAMILY_NAME],
      },
      accessor: 'name',
      sortType: 'basic',
      Cell: (cellProps: Cell) => getUsersGridItem(cellProps, ManageUsersCellType.NAME),
    },
    {
      Header: {
        label: smLabels.staffId.toUpperCase(),
        name: ManageUserSortOption.STAFFID,
      },
      accessor: 'staffId',
      Cell: (cellProps: Cell) => getUsersGridItem(cellProps, ManageUsersCellType.STAFFID),
    },
    {
      Header: {
        label: smLabels.emailId.toUpperCase(),
        name: ManageUserSortOption.EMAILID,
      },
      accessor: 'emailId',
      sortType: 'basic',
      Cell: (cellProps: Cell) => getUsersGridItem(cellProps, ManageUsersCellType.EMAILID),
    },
    {
      Header: {
        label: smLabels.userGroups.toUpperCase(),
        name: ManageUserSortOption.USER_GROUP,
      },
      accessor: 'userGroups',
      Cell: (cellProps: Cell) => getUsersGridItem(cellProps, ManageUsersCellType.USERGROUPS),
    },
    {
      Header: {
        label: smLabels.status.toUpperCase(),
        name: ManageUserSortOption.STATUS,
      },
      accessor: 'status',
      Cell: (cellProps: any) => getUsersGridItem(cellProps, ManageUsersCellType.STATUS),
    },
    {
      id: 'More',
      Cell: (props: any) => {
        const isMoreSelected = selectedToolTipIndex === props.cell.row.index;
        const moreSelectedClass = isMoreSelected ? styles.userActionsOpened : '';
        return (
          <div
            id="userActionsContainer"
            ref={userActionsContainerRef}
            className={`${styles.userActionsContainer} ${moreSelectedClass}`}
          >
            <ManageUsersCell cellType={ManageUsersCellType.MORE} moreClickHandler={() => moreClickHandler(props)} />
            {isMoreSelected ? (
              <ManageUsersActions
                id={'ManageUsersActionContainer'}
                userActions={userActions}
                userActionsClickHandler={(action: any) => userActionsHandler(action, props.cell.row.index)}
              />
            ) : null}
          </div>
        );
      },
      disableSortBy: true,
    },
  ] as any;

  const deleteUserHandler = (deletedUserIndex: number, userId: string, userName: string) => {
    props.onUserDeleted(deletedUserIndex, userId, userName);
    setisDeleteUserIdx(-1);
  };

  const getDeleteUserModal = () => {
    return isDeleteUserIdx > 0 ? (
      <DeleteUserDialog
        id="deleteUserDialogComponent"
        title={smLabels.deleteUserTitle}
        label={smLabels.deleteUserLabel}
        userName={`${props.data[selectedUserIdx].name[0]} ${props.data[selectedUserIdx].name[1]}`}
        modalCloseHandler={() => setisDeleteUserIdx(-1)}
        deleteUserHandler={deleteUserHandler}
        userRowIdx={isDeleteUserIdx}
        {...props.data[selectedUserIdx]}
      />
    ) : null;
  };
  return (
    <div id="manageUserGridContainer" className={styles.manageUsersgrid}>
      {getDeleteUserModal()}
      <UI.Grid
        id="manageUsersGrid"
        columns={columns}
        data={props.data}
        initialState={props.gridState.initialState}
        onPageChange={props.onPageChange}
        onPageSizeChange={props.onPageSizeChange}
        totalRecords={props.gridState.totalRecords}
        currentPage={props.gridState.selectedPage}
        pageSizeOptions={props.pageSizeOptions}
        selectedOptionValue={props.gridState.selectedOptionValue}
        onColumnSort={props.onColumnSort}
        sortOption={props.sortOption}
        noDataText={smLabels.noUserFound}
        showNoDataView={state.globalUIState.isLoading}
        isLoading={props.isLoading}
      />
    </div>
  );
};

export default ManageUsersGrid;
