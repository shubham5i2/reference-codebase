import React, { useState, useEffect, MouseEvent } from 'react';
import styles from './TestTakerSearchPanel.module.scss';
import UI from 'ielts-cmds-ui-component-library';
import ChevronDownIcon from '../../../assets/images/Chevron_Down.svg';
import ChevronUpIcon from '../../../assets/images/Chevron_Up.svg';
import { TestTakerSearchPanelProps } from '../../Templates/ManageTestTakerSearch/TestTakerSearch';

const TestTakerSearchPanel = (props: TestTakerSearchPanelProps) => {
  const [open, setOpen] = useState(false);

  const onChangeHandler = (event: MouseEvent) => {
    event.preventDefault();
    setOpen(!open);
  };

  useEffect(() => {
    setOpen(props.initialOpenState);
  }, [props.initialOpenState]);

  return (
    <div className={styles.searchPanel}>
      <div className={styles.searchPanelTitle}>
        <UI.Typography type={props.titleType} label={props.title} size={props.titleSize} id="title" />
      </div>
      <div className={styles.searchPanelSubTitle}>
        <UI.Typography type={props.subTitleType} label={props.subTitle} size={props.subTitleSize} id="subTitle" />
        <span className={styles.mandatoryLabel}>{props.mandatoryLabel}</span>
      </div>
      <div className={styles.searchBox + ' ' + styles.col3}>
        <UI.TextBox
          label={props.ieltsTestTakerLabel}
          name={props.ieltsTestTakerLabel.replace(/ /g, '').toLowerCase()}
          placeholder=""
          value={props.basicSearchData.uniquetesttakerid}
          onChange={props.handleBasicInputChange}
        />
        <UI.TextBox
          label={props.cmdsBookingIdLabel}
          name={props.cmdsBookingIdLabel.replace(/ /g, '').toLowerCase()}
          placeholder=""
          value={props.basicSearchData.cmdsbookingid}
          onChange={props.handleBasicInputChange}
        />
        <UI.TextBox
          label={props.identityDocumentNumberLabel}
          name={props.identityDocumentNumberLabel.replace(/ /g, '').toLowerCase()}
          placeholder=""
          value={props.basicSearchData.identitydocumentnumber}
          onChange={props.handleBasicInputChange}
        />
      </div>

      <div>
        <div className={styles.row}>
          <div className={styles.alignSelfCenter}>
            <a
              href="#collapse"
              onClick={(event) => {
                onChangeHandler(event);
              }}
              className={open ? styles.hidden : styles.collapseIcon}
              id="collapseTitle"
            >
              <UI.Icon icon={ChevronDownIcon} />
              <span className={styles.collapseTitle}>{props.collapseTitle}</span>
            </a>
            <span className={!open ? styles.hidden : styles.collapseOpenTitle}>{props.collapseOpenTitle}</span>
          </div>
          <div className={open ? styles.hidden : styles.pushLeft}>
            <a
              href="#clearBasic"
              onClick={props.onClearBasicSearch}
              className={styles.clearSearch}
              id="clearBasicSearch"
            >
              <span>{props.clearBasicSearch}</span>
            </a>
          </div>
          <div className={open ? styles.hidden : ''}>
            <UI.Button
              label={props.basicSearchButtonLabel}
              onChange={props.onBasicSearchHandler}
              color={props.basicSearchButtonColor}
              id="basicSearchButton"
            />
          </div>
        </div>

        <div className={open ? styles.panelCollapse : [styles.panelCollapse, styles.panelClose].join(' ')}>
          {props.children}
          <div>
            <div className={styles.row}>
              <div className={styles.alignSelfCenter}>
                <a
                  href="#collapse"
                  onClick={(event) => {
                    onChangeHandler(event);
                  }}
                  className={styles.collapseIcon}
                  id="collapseFooterTitle"
                >
                  <UI.Icon icon={ChevronUpIcon} />
                  <span className={styles.collapseFooterTitle}>{props.collapseFooterTitle}</span>
                </a>
              </div>
              <div className={styles.pushLeft}>
                <a
                  href="#clearAdvanced"
                  onClick={props.onClearAdvancedSearch}
                  className={styles.clearSearch}
                  id="clearAdvancedSearch"
                >
                  <span>{props.clearAdvancedSearch}</span>
                </a>
              </div>
              <div>
                <UI.Button
                  label={props.advanceSearchButtonLabel}
                  onChange={props.onAdvancedSearchHandler}
                  color={props.advanceSearchButtonColor}
                  id="advancedSearchButton"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default TestTakerSearchPanel;
