import React from 'react';
import userProfile from '../../../assets/images/UserProfile.svg';
import Delete from '../../../assets/images/Delete.svg';
import Edit from '../../../assets/images/Edit.svg';
import ProfileHeaderComponent from '../../Molecules/ProfileHeaderComponents/ProfileHeaderComponent';

const ProfileHeader = (props: any) => {
  const actionElements = [
    { name: userProfile, tag: 'Assign group', class: 'phAssign', id: 'phAssign', url: '/assignProfile' },
    { name: Delete, tag: 'Delete', class: 'phDelete', id: 'phDelete', url: '/delete' },
    { name: Edit, tag: 'Update', class: 'phUpdate', id: 'phUpdate', url: '/edit' },
  ];

  const onActionElementClick = (ele: any) => {
    const selectedAction = actionElements.find((ae) => ae.url === ele.url);
    props.onHeaderAction(selectedAction);
  };

  return (
    <div>
      <ProfileHeaderComponent
        actionElements={actionElements}
        user={props.user}
        onclick={onActionElementClick}
        status={props.status}
      />
    </div>
  );
};

export default ProfileHeader;
