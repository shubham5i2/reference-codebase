import React from 'react';
import ReviewProfile from '../../Molecules/ReviewProfile/ReviewProfile';
import { getKey } from '../../utils/utilities';
import { organisationOptions, AssignGroupData } from '../../../services/Models/StaffManagement';
import { DropDownDataSource } from '../../../services/Models/UIModels';
import { languageService } from '../../../services/Language/LanguageService';
import { User } from '@auth0/auth0-spa-js';

const profileValidity = {
  Verified: true,
  'Not Verified': false,
};

interface ReviewProfilePageProps {
  userData: User;
}

const ReviewProfilePage = (props: ReviewProfilePageProps) => {
  const { userData } = props;

  const assignGroupObject = userData.assignGroupData.sort((obj1: AssignGroupData, obj2: AssignGroupData) =>
    (obj1.userGroupName ? obj1.userGroupName.toLowerCase() : '') >
    (obj2.userGroupName ? obj2.userGroupName.toLowerCase() : '')
      ? 1
      : -1,
  );
  const smLabels = languageService().staffManagement;
  const partnerCode = organisationOptions.find((item: DropDownDataSource) => item.value === userData.partnerCode)?.text;
  const personalData = [
    { title: smLabels.givenName, value: userData.givenName },
    { title: smLabels.familyName, value: userData.familyName },
    { title: smLabels.nickName, value: userData.nickname },
    { title: smLabels.emailId, value: userData.email, verify: getKey(profileValidity, userData.emailVerified) },
    {
      title: smLabels.phonenumber,
      value: userData.phoneNumber,
      verify: getKey(profileValidity, userData.phoneVerified),
    },
    { title: smLabels.organisation, value: partnerCode },
    { title: smLabels.status, value: userData.userStatus, isStatus: true },
  ];

  return (
    <div>
      <ReviewProfile
        title={smLabels.viewUserHeaderText}
        perData={personalData}
        userGrpTitle={smLabels.userGroupTitle}
        userGrp={assignGroupObject}
      />
    </div>
  );
};

export default ReviewProfilePage;
