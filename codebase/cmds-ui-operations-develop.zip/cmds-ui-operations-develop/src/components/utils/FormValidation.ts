import { DropDownDataSource, FormRule, FormError } from '../../services/Models/UIModels';
import { getValue } from './utilities';

export const FormValidation = (value: string | DropDownDataSource, rule?: FormRule, formData?: any): FormError => {
  const isValid = true;

  if (!rule) return { isValid };

  if (typeof value === 'string') {
    if (rule.required) {
      const validationObj = validateRequired(rule, value, isValid);
      if (validationObj) return validationObj;
    }
    if (rule.requiredEitherOr) {
      const validationObj = validateRequiredEitherOr(rule, value, isValid, formData);
      if (validationObj) return validationObj;
    }
    if (rule.minLength && value) {
      const validationObj = validateMinLength(rule, value, isValid);
      if (validationObj) return validationObj;
    }
    if (rule.maxLength && value) {
      const validationObj = validateMaxLength(rule, value, isValid);
      if (validationObj) return validationObj;
    }

    if (rule.isEmail && value) {
      const validationObj = validateEmail(rule, value, isValid);
      if (validationObj) return validationObj;
    }

    if (rule.isNumeric && value) {
      const validationObj = validateNumeric(rule, value, isValid);
      if (validationObj) return validationObj;
    }

    if (rule.isAlphaNumeric && value) {
      const validationObj = validateAlphaNumeric(rule, value, isValid);
      if (validationObj) return validationObj;
    }

    if (rule.phoneNumber && value) {
      const validationObj = validatePhone(rule, value, isValid);
      if (validationObj) return validationObj;
    }

    if (rule.isURL && value) {
      const validationObj = validateURL(rule, value, isValid);
      if (validationObj) return validationObj;
    }

    if (rule.isLocationURL && value) {
      const validationObj = validateLocationURL(rule, value, isValid);
      if (validationObj) return validationObj;
    }

    if (rule.isUuid && value) {
      const validationObj = validateUUid(rule, value, isValid);
      if (validationObj) return validationObj;
    }
  } else {
    if (rule.isDropDown) {
      const validationObj = isValidationObj(value?.value !== '', rule.message);
      if (validationObj) return validationObj;
    }
  }

  return {
    isValid,
  };
};

// validation rules for all the fields

const validateRequired = (rule: FormRule, value: string, prevValidityState: boolean) => {
  const isValid = value.trim() !== '' && prevValidityState;
  return isValidationObj(isValid, rule.message || rule.emptyInputmessage || '');
};

// Added either or validation on given name and first name

const validateRequiredEitherOr = (rule: FormRule, value = '', prevValidityState: boolean, formData?: any) => {
  const eitherOrKey = rule.requiredEitherOr || '';
  const isValid = (value.trim() !== '' || getValue(formData?.[eitherOrKey]).trim() !== '') && prevValidityState;
  return isValidationObj(isValid, rule.message || rule.emptyInputmessage || '');
};

const validateMinLength = (rule: FormRule, value: string, prevValidityState: boolean) => {
  const isValid = rule.minLength && value.length >= rule.minLength && prevValidityState;
  return isValidationObj(!!isValid, `The minimum field length is ${rule.minLength} characters`);
};

const validateMaxLength = (rule: FormRule, value: string, prevValidityState: boolean) => {
  const isValid = rule.maxLength && value.length <= rule.maxLength && prevValidityState;
  return isValidationObj(!!isValid, `The maximum field length is ${rule.maxLength} characters`);
};

const validateEmail = (rule: FormRule, value: string, prevValidityState: boolean) => {
  const pattern =
    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  const isValid = pattern.test(value) && prevValidityState;
  const errorMessage = value.trim() === '' ? rule.emptyInputmessage : rule.invalidInputMessage;
  return isValidationObj(isValid, errorMessage);
};

const validateNumeric = (rule: FormRule, value: string, prevValidityState: boolean) => {
  const pattern = /^(0|[1-9][0-9]*)$/;
  const isValid = pattern.test(value) && prevValidityState;
  const errorMessage = value.trim() === '' ? rule.emptyInputmessage : rule.invalidInputMessage;
  return isValidationObj(isValid, errorMessage);
};

const validateAlphaNumeric = (rule: FormRule, value: string, prevValidityState: boolean) => {
  const pattern = /^[A-Za-z0-9]+$/;
  const isValid = pattern.test(value) && prevValidityState;
  const errorMessage = value.trim() === '' ? rule.emptyInputmessage : rule.invalidInputMessage;
  return isValidationObj(isValid, errorMessage);
};

const validateUUid = (rule: FormRule, value: string, prevValidityState: boolean) => {
  const pattern = /^[a-z0-9]{8}-[a-z0-9]{4}-[a-z0-9]{4}-[a-z0-9]{4}-[a-z0-9]{12}$/;
  const isValid = pattern.test(value) && prevValidityState;
  const errorMessage = value.trim() === '' ? rule.emptyInputmessage : rule.invalidInputMessage;
  return isValidationObj(isValid, errorMessage);
};

const validatePhone = (rule: FormRule, value: string, prevValidityState: boolean) => {
  const pattern = /(^[\d\s\-+()]{7,20})$/;
  const isValid = pattern.test(value) && prevValidityState;
  const errorMessage = value.trim() === '' ? rule.emptyInputmessage : rule.invalidInputMessage;
  return isValidationObj(isValid, errorMessage);
};

const validateURL = (rule: FormRule, value: string, prevValidityState: boolean) => {
  const pattern =
    /^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([-.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/;
  const isValid = pattern.test(value.toLocaleLowerCase()) && prevValidityState;
  const errorMessage = value.trim() === '' ? rule.emptyInputmessage : rule.invalidInputMessage;
  return isValidationObj(isValid, errorMessage);
};

const validateLocationURL = (rule: FormRule, value: string, prevValidityState: boolean) => {
  const pattern =
    /^(http:\/\/www\\.|https:\/\/www\\.|http:\/\/|https:\/\/)?[-a-zA-Z0-9@:%._~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_//+.~#?&=]*)$/;
  const isValid = pattern.test(value.toLocaleLowerCase()) && prevValidityState;
  const errorMessage = value.trim() === '' ? rule.emptyInputmessage : rule.invalidInputMessage;
  return isValidationObj(isValid, errorMessage);
};

const isValidationObj = (isValid: boolean, message?: string) => {
  return !isValid
    ? {
        isValid,
        message: message,
      }
    : null;
};
