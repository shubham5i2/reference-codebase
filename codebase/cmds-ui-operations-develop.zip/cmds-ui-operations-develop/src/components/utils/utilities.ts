import { useRef, useEffect } from 'react';
import { auth0Namespace, UserGroup } from '../../services/Models/StaffManagement';
import {
  DropDownDataSource,
  Dictionary,
  FormRule,
  FormStepRule,
  GridSelectAllData,
  SortOptions,
  ColumnSort,
  SortType,
} from '../../services/Models/UIModels';
import { languageService } from '../../services/Language/LanguageService';
import { OrganisationAddressData, VerificationStatus } from '../../services/Models/Organisation';
import { User } from '@auth0/auth0-spa-js';
import { format, isValid } from 'date-fns';
import { LocationData } from '../Organisms/BaseDropDown/LocationDropDown/LocationDropDown';
import { getLocations } from '../../services/API/ManageUser/Locations';
import { ServiceRequest } from '../../services/utils/ServiceRequest';
import { DateDivision } from '../../services/Models/IncidentManagement';
import { TestTakerTRFDetailResponse } from '../../services/Models/TestTakerTRF';
import { Country, ReferenceDropdownType } from '../../services/Models/ReferenceModals';

const incidentManagementLabels = languageService().incidentManagement;
// Returns key name based on object and value provided to the getKey Function.
export const getKey = (obj: any, val: any) => Object.keys(obj).find((key) => obj[key] === val);
// Format the date
export const dateFormatter = (value: any) => {
  const date = new Date(value).toDateString();
  const [, month, day, year] = date.split(' ');
  const formattedDate = [day, month, year].join(' ');
  return formattedDate;
};

export function useEffectUpdate(effect: any, deps: any) {
  const isFirstRender = useRef(true);

  useEffect(() => {
    if (!isFirstRender.current) {
      effect();
    }
  }, deps); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    isFirstRender.current = false;
  }, []);
}

export const sortByField = (data: TestTakerTRFDetailResponse[], fieldName: string, orderBy: string) => {
  if (data && fieldName.toLowerCase().includes('date') && orderBy === 'desc') {
    data.sort((a: Dictionary, b: Dictionary) => +new Date(a[fieldName]) - +new Date(b[fieldName]));
  } else if (data && fieldName.toLowerCase().includes('date') && orderBy === 'asc') {
    data.sort((a: Dictionary, b: Dictionary) => +new Date(b[fieldName]) - +new Date(a[fieldName]));
  } else {
    data.sort((a: Dictionary, b: Dictionary) => sortData(orderBy, a, b, fieldName));
  }
  return data;
};

const sortData = (orderBy: string, a: Dictionary, b: Dictionary, fieldName: string) => {
  if (orderBy === 'desc') {
    return a[fieldName] && b[fieldName] && ('' + a[fieldName]).localeCompare(b[fieldName]);
  }
  return a[fieldName] && b[fieldName] && ('' + b[fieldName]).localeCompare(a[fieldName]);
};

export const getPageOffSet = (page: number, itemsPerPage: number) => {
  const startValue = (page - 1) * itemsPerPage + 1;
  const endValue = itemsPerPage * page;
  return {
    startValue,
    endValue,
  };
};

//Alternate Name max count
export const maxCount = 5;

export const getUserGroupAssignmentsName = (userGroupAssignments: UserGroup[] = []) => {
  return userGroupAssignments.map((userGroupAssignment) => userGroupAssignment.userGroupName).join(', ');
};

export const transformRequestValueFromString = (value: string | undefined) => value || undefined;

export const sortValues = (list: DropDownDataSource[] = []) => {
  return list.sort((obj1, obj2) =>
    (obj1.text ? obj1.text.toLowerCase() : '') > (obj2.text ? obj2.text.toLowerCase() : '') ? 1 : -1,
  );
};

export const statusStyle: Dictionary = {
  PENDING: 'unconfirmed',
  UNVERIFIED: 'cancell',
  VERIFIED: 'success',
  ACTIVE: 'active',
  RELEASED: 'active',
  INACTIVE: 'inActive',
  CONFIRMED: 'inActive',
  PENDINGREVIEW: 'inActive',
  WITHHELD: 'inActive',
  VALIDATED: 'inActive',
  UNCONFIRMED: 'unconfirmed',
  ABSENT: 'unconfirmed',
  INCOMPLETE: 'unconfirmed',
  PERMANENTLYWITHHELD: 'cancelled',
};

export const getUserStatusDictonary = (): Dictionary => {
  const smLabels = languageService().staffManagement;
  return {
    ACTIVE: smLabels.active,
    INACTIVE: smLabels.inActive,
  };
};

export const getNestedProperty = (obj: any, path: string) =>
  path
    .replace(/\[|\]\.?/g, '.')
    .split('.')
    .filter((s) => s)
    .reduce((acc, val) => acc && acc[val], obj);

// This is used to generate the madatory fileds from the rules for address Object.
export const flattenAddressValidationObj = (address: FormStepRule | FormRule) => {
  if (!address || 'required' in address) return {};
  else {
    return Object.keys(address).reduce(
      (item, key) => ({
        ...item,
        [key]: address[key]?.required,
      }),
      {},
    );
  }
};

// Added default value to numberofyears.
export const getValue = (value: string | undefined, defaultValue = '') => (value ? value : defaultValue);

export const joinAddress = (value: OrganisationAddressData | undefined) =>
  value
    ? [
        getValue(value?.addressOne),
        getValue(value?.addressTwo),
        getValue(value?.addressThree),
        getValue(value?.addressFour),
      ]
        .filter(Boolean)
        .join(', ')
    : '';

export const getVerificationStatus = (verificationStatus: DropDownDataSource) => {
  const organisationLabels = languageService().organisation;
  return getValue(verificationStatus?.value) === VerificationStatus.APPROVED
    ? organisationLabels.approved
    : getValue(verificationStatus?.value) === VerificationStatus.VERIFIED
    ? organisationLabels.verified
    : getValue(verificationStatus?.value) === VerificationStatus.PENDING
    ? organisationLabels.pending
    : organisationLabels.rejected;
};

export const getPartnerCode = (user: User) => {
  const smLabels = languageService().staffManagement;
  return user?.[auth0Namespace + smLabels.partnerCode] ? user?.[auth0Namespace + smLabels.partnerCode] : '';
};

export const getUserId = (user: User) => {
  return getValue(user?.sub).split(/\|/)[1] || '';
};

export const formatDate = (date: Date, dateFormat: string) => {
  return isValid(new Date(date)) ? format(new Date(date), dateFormat) : '';
};

export const formatDateAsGB = (inputDate: string) => {
  const date = new Date(inputDate);
  return date.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
};

export const formatDateAsUTC = (date: Date) => {
  const day = date.getUTCDate().toString();
  return `${day.length < 2 ? `0${day}` : `${day}`} ${date.toLocaleDateString('en-IN', {
    month: 'short',
  })} ${date.getFullYear()}`;
};

export const validateEmail = (email: string) => {
  return String(email)
    .toLowerCase()
    .match(
      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
    );
};

export const getTargetObject = (name = '', value: any, dropdownText?: string) => {
  return {
    target: {
      name,
      value,
      dropdownText,
    },
  };
};

export const getPartner = (user: User | undefined) => {
  const smLabels = languageService().staffManagement;
  const partner = user?.[auth0Namespace + smLabels.partnerCode] ? user?.[auth0Namespace + smLabels.partnerCode] : '';
  return partner === 'GLOBAL_IELTS' ? '' : partner;
};

export const getOptionsList = (locationOptions: LocationData[]) => {
  return locationOptions.map((option: LocationData) => {
    const newOption = { ...option };
    newOption.text = `${newOption.text} (${newOption.locationCode})`;
    return newOption;
  });
};

export const getOptionsListWithId = (locationOptions: LocationData[]) => {
  return locationOptions.map((option: LocationData) => {
    const newOption = { ...option };
    newOption.text = `${newOption.locationCode} - ${newOption.text} `;
    return newOption;
  });
};

export const getTestCenter = (
  user: User | undefined,
  serviceRequest: ServiceRequest,
  storeDataPath: string,
  actionType: string,
  dispatch: React.Dispatch<any>,
  state: any,
) => {
  const testcenters = getNestedProperty(state, storeDataPath || '') || [];
  if (testcenters.length === 0) {
    const userId = getValue(user?.sub).split(/\|/)[1] || '';
    const partnerCode = getPartner(user);
    getLocations(userId, partnerCode, 'TEST_CENTRE', false, serviceRequest).subscribe((data) => {
      dispatch({
        type: actionType,
        payload: {
          response: data.testCenter,
          formattedData: data.testCentersData,
        },
      });
    });
  }
};

export const isUndefined = (arg: any) => {
  return typeof arg === 'undefined';
};

export const manageDateTime = (date: string, division: DateDivision) => {
  if (date.trim() === '') return;
  const dateArr = date.split('T');
  const arr = dateArr[1].split(':');
  const dateVal = Number(arr[0]);
  const timeValue = dateVal > 11 ? 'PM' : 'AM';
  const time = dateVal > 12 ? dateVal - 12 : dateVal;
  switch (division) {
    case DateDivision.NORMAL:
      return `${formatDate(new Date(dateArr[0]), incidentManagementLabels.uiDateFormat)} ${time}:${
        arr[1]
      } ${timeValue}`;
    case DateDivision.DIVIDED:
      return `${formatDate(new Date(dateArr[0]), incidentManagementLabels.uiDateFormat)} | ${time}:${
        arr[1]
      } ${timeValue}`;
  }
};

export const defaultCheckHandlerForSelectAll = (page: number, selectAllStatus: GridSelectAllData[]) => {
  if (page !== undefined) {
    const currentPageData: GridSelectAllData[] = selectAllStatus.filter(
      (item: GridSelectAllData) => item.page === page,
    );
    return currentPageData.length > 0 && currentPageData[0].checked === true;
  }
};

export const gridRowsMatchHandler = (gridData: any, columnName: string) => {
  const isColumnsSameForSelectedRows: boolean =
    gridData.length > 0
      ? gridData.every((booking: any) => {
          return booking[columnName] === gridData[0][columnName];
        })
      : false;
  return isColumnsSameForSelectedRows;
};

export const defaultCheckHandler = (selectedRows: any, gridData: any, id: string, index: number) => {
  return (
    selectedRows.findIndex(function (item: any) {
      return item[id] === gridData[index][id];
    }) >= 0
  );
};

export const isActiveToDate = (dateString: string): boolean => {
  return dateString > new Date().toISOString();
};

export const getDayFromToday = (num: number) => {
  const date = new Date();
  date.setDate(new Date().getDate() + num);
  return date;
};

export const getSortedColumnOptions = (prevSortOption: SortOptions, column: ColumnSort) => {
  const sortType =
    JSON.stringify(prevSortOption.sortBy) === JSON.stringify(column.Header.name)
      ? prevSortOption.sortType === SortType.ASCENDING
        ? SortType.DESCENDING
        : SortType.ASCENDING
      : SortType.ASCENDING;
  return {
    sortBy: column.Header.name,
    sortType,
  };
};

const isNull = (v: any) => v == null || (typeof v === 'string' && getValue(v).toUpperCase() === 'NULL');

export const cleanEmpty = (obj: any): any => {
  if (Array.isArray(obj)) {
    return obj.map((v: any) => (v && typeof v === 'object' ? cleanEmpty(v) : v)).filter((v) => !isNull(v));
  } else {
    return Object.entries(obj)
      .map(([k, v]) => [k, v && typeof v === 'object' ? cleanEmpty(v) : v])
      .reduce((a: any, [k, v]) => (isNull(v) ? a : ((a[k] = v), a)), {});
  }
};

export const getCountryISOCode = (state: any = {}, countryUuid = '') =>
  (state.referenceData?.country?.response || []).find((country: Country) => countryUuid === country.countryUuid)
    ?.countryIso3Code || '';

export const splitDataFromKey = (data: string, splitterKey: string): string => {
  const splittedRole = data.split(splitterKey);
  return splittedRole.length > 1 ? splittedRole[1] : '';
};
export const getCountryName = (state: any = {}, countryUuid = '') =>
  (state.referenceData?.country?.response || []).find((country: Country) => countryUuid === country.countryUuid)
    ?.countryName || '';

export const getTerritoriesState = (state: any = {}, countryCode = '') =>
  state.referenceData?.[ReferenceDropdownType.TERRITORY]?.[countryCode] || {};

export const getAppendedURL = (pathName: string) => {
  const baseURL = process.env.REACT_APP_REST_BASE_URL;
  return `${baseURL}${pathName}`;
};

export const changeKeyName = (arrayOfObject: Record<string, unknown>[], newKey: string, oldKey: string) => {
  arrayOfObject &&
    arrayOfObject.forEach((obj: Record<string, unknown>) => {
      obj[newKey] = obj[oldKey];
      delete obj[oldKey];
    });
  return arrayOfObject;
};

export const toCapitalise = (value: string) => {
  if (value.length < 2) {
    return value.toUpperCase();
  }

  return `${value[0].toUpperCase()}${value.substring(1, value.length).toLowerCase()}`;
};
