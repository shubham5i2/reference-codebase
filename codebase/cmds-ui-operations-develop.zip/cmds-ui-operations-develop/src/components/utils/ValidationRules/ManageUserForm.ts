import { languageService } from '../../../services/Language/LanguageService';
import { FormStepRule } from '../../../services/Models/UIModels';

interface ManageUserFormRules {
  PersonalProfile: FormStepRule;
  AssignGroup: FormStepRule;
  ReviewProfile?: FormStepRule;
}

export enum FormStepType {
  PERSONAL_PROFILE = 'PersonalProfile',
  ASSIGN_GROUP = 'AssignGroup',
  REVIEW_PROFILE = 'ReviewProfile',
}

export enum FormActionType {
  ADD = 'Add',
  UPDATE = 'Update',
}

const getFormRules = (id: string) => {
  const smLabels = languageService().staffManagement;

  // Added maximum and minimum length validation for all the fields
  const rules: ManageUserFormRules = {
    PersonalProfile: {
      givenName: {
        required: false,
        message: smLabels.nameValidatorMessage,
        requiredType: 'optional',
        requiredEitherOr: 'familyName',
        maxLength: 25,
      },
      familyName: {
        required: false,
        requiredType: 'optional',
        requiredEitherOr: 'givenName',
        message: smLabels.nameValidatorMessage,
        maxLength: 25,
      },
      nickName: {
        required: false,
        message: smLabels.nickNameValidatorMessage,
        maxLength: 25,
      },
      phoneNumber: {
        required: true,
        phoneNumber: true,
        maxLength: 20,
        minLength: 7,
        emptyInputmessage: smLabels.phonenumberValidatorEmptyMessage,
        invalidInputMessage: smLabels.phonenumberValidatorInvalidMessage,
      },
      partnerCode: {
        required: true,
        message: smLabels.organisationValidatorMessage,
        maxLength: 20,
      },
      email: {
        required: true,
        isEmail: true,
        emptyInputmessage: smLabels.emailValidatorEmptyMessage,
        invalidInputMessage: smLabels.emailValidatorInvalidMessage,
        maxLength: 320,
      },
    },
    AssignGroup: {
      location: {
        required: true,
        message: smLabels.locationValidatorMessage,
      },
      userGroup: {
        required: true,
        message: smLabels.userprofileValidatorMessage,
      },
      dateRange: {
        isDateRange: true,
        required: false,
      },
    },
  };
  if (!id) {
    rules.AssignGroup = {
      ...rules.AssignGroup,
      locationType: {
        required: true,
        message: smLabels.locationTypeValidatorMessage,
      },
    };
  }

  return rules;
};

const manageUserFormRules = (formStep: string, id = ''): FormStepRule => {
  const formRules = getFormRules(id);
  switch (formStep) {
    case FormStepType.PERSONAL_PROFILE:
      return formRules.PersonalProfile;
    case FormStepType.ASSIGN_GROUP:
      return formRules.AssignGroup;
    default:
      return {};
  }
};

export default manageUserFormRules;
