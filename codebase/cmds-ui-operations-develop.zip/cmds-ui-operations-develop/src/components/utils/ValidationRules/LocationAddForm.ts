import { FormStepRule } from '../../../services/Models/UIModels';
import { languageService } from '../../../services/Language/LanguageService';
import { LocationType } from '../../../services/Models/LocationManagement';
const locationLabels = languageService().locationManagement;

// Location: insted of locType use locationType
export const islocationType = (locationType: string) => {
  switch (locationType) {
    case LocationType.TEST_CENTRE:
      return true;
    case LocationType.PHYSICAL_BUILDING:
      return false;
    default:
      return true;
  }
};

export const addLocationFormRules = (locType: string): FormStepRule => {
  const isType = islocationType(locType);

  console.log('isType', isType);
  return {
    locationTypeCode: {
      required: true,
      message: locationLabels.locTypeValidationMsg,
      isDropDown: true,
    },
    parentLocationUuid: {
      required: true,
      message: locationLabels.parentCountryValidationMsg,
      isDropDown: true,
    },
    partnerCode: {
      required: true,
      message: locationLabels.partnerCodeValidationMsg,
      isDropDown: true,
    },
    externalLocationUuid: {
      required: true,
      message: locationLabels.externalLocationValidationMsg,
      maxLength: 36,
      isUuid: true,
      invalidInputMessage: locationLabels.externalLocationInvalidValidationMsg,
    },
    externalParentLocationUuid: {
      required: false,
      maxLength: 36,
      isUuid: true,
      message: locationLabels.externalparentLocUUIDValidationMsg,
      invalidInputMessage: locationLabels.externalparentLocUUIDInvalidValidationMsg,
    },
    locationName: {
      required: true,
      message: locationLabels.locationNameValidationMsg,
      maxLength: 300,
    },
    testCentreNumber: {
      required: isType,
      emptyInputmessage: locationLabels.testCenterNumberValidationMsg,
      invalidInputMessage: locationLabels.testCenterNumberInvalidValidationMsg,
      maxLength: 5,
      isAlphaNumeric: true,
    },
    timezoneName: {
      required: true,
      message: locationLabels.timeZoneValidationMsg,
    },
    websiteURL: {
      required: false,
      invalidInputMessage: locationLabels.websiteURLInvalidValidationMsg,
      maxLength: 5000,
      isLocationURL: isType,
    },
    activatedDate: {
      required: false,
      message: locationLabels.approvedDateValidationMsg,
    },
  };
};
export default addLocationFormRules;
