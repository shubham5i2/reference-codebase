import { FormStepRule, FormRule } from '../../../services/Models/UIModels';
import { languageService } from '../../../services/Language/LanguageService';
import {
  ContactDetailsData,
  OrganisationProfileData,
  OrganisationType,
  VerificationStatus,
} from '../../../services/Models/Organisation';
import { getValue } from '../utilities';

export interface OrganisationFormRule {
  [key: string]: FormRule | FormStepRule;
}

export interface OrganisationFormRules {
  organisationProfile: OrganisationFormRule;
  contactDetails: OrganisationFormRule;
}

export const isOrgTypeRo = (orgTypeUuid: string) => {
  switch (orgTypeUuid) {
    // VO UUID
    case 'e392ae7c-016f-433a-bdfa-b79bfcdddf26':
      return false;
    // RO UUID
    case 'e496aa98-86a3-476d-8be3-21ee0aa23c93':
      return true;
    default:
      return true;
  }
};

export const adminContactDetailsValidator = ({
  organisationDetails,
  contactDetails,
}: {
  organisationDetails: OrganisationProfileData;
  contactDetails: ContactDetailsData;
}) => {
  const { organisationType, verificationStatus } = organisationDetails;
  const { givenName, familyName, emailAddress } = contactDetails.adminContactAddress;

  console.log({ givenName, familyName, emailAddress });
  if (organisationType.value === OrganisationType.VO) {
    return false;
  }
  // RO and verified
  if (verificationStatus.value === VerificationStatus.VERIFIED) {
    return (
      getValue(givenName).trim().length > 0 ||
      getValue(familyName).trim().length > 0 ||
      getValue(emailAddress).trim().length > 0
    );
  }
  return true;
};

const addOrganisationFormRules = (orgTypeUuid: string, isAdminDetails: boolean): OrganisationFormRules => {
  const isRo = isOrgTypeRo(orgTypeUuid);
  const organisationLabels = languageService().organisation;

  // Added form rules for required and non required fields

  return {
    organisationProfile: {
      organisationName: {
        required: true,
        message: organisationLabels.orgNameValidationMsg,
        maxLength: 255,
      },
      organisationType: {
        required: true,
        message: organisationLabels.orgTypeValidationMsg,
        isDropDown: true,
      },
      verificationStatus: {
        required: true,
        message: organisationLabels.orgVarificationStatusMsg,
        isDropDown: true,
      },
      mainAddress: {
        addressOne: {
          required: true,
          message: organisationLabels.mainAddressValidationMsg,
          maxLength: 100,
        },
        addressTwo: {
          required: false,
          message: organisationLabels.mainAddressValidationMsg,
          maxLength: 100,
        },
        addressThree: {
          required: false,
          message: organisationLabels.mainAddressValidationMsg,
          maxLength: 100,
        },
        addressFour: {
          required: false,
          message: organisationLabels.mainAddressValidationMsg,
          maxLength: 100,
        },
        city: {
          required: true,
          message: organisationLabels.cityValidationMsg,
          maxLength: 100,
        },
        country: {
          required: true,
          message: organisationLabels.countryValidationMsg,
          isDropDown: true,
        },
        postalCode: {
          required: false,
          message: organisationLabels.mainAddressValidationMsg,
          maxLength: 20,
        },
        emailAddress: {
          required: false,
          message: organisationLabels.orgEmailValidationMsg,
          invalidInputMessage: organisationLabels.orgEmailValidationMsg,
          maxLength: 320,
          isEmail: true,
        },
        phoneNumber: {
          required: false,
          message: organisationLabels.orgTelephoneValidatorMsg,
          invalidInputMessage: organisationLabels.orgTelephoneValidatorMsg,
          maxLength: 20,
          minLength: 7,
          phoneNumber: true,
        },
      },
      deliveryAddress: {
        addressOne: {
          required: true,
          message: organisationLabels.mainAddressValidationMsg,
          maxLength: 100,
        },
        addressTwo: {
          required: false,
          message: organisationLabels.mainAddressValidationMsg,
          maxLength: 100,
        },
        addressThree: {
          required: false,
          message: organisationLabels.mainAddressValidationMsg,
          maxLength: 100,
        },
        addressFour: {
          required: false,
          message: organisationLabels.mainAddressValidationMsg,
          maxLength: 100,
        },
        postalCode: {
          required: false,
          message: organisationLabels.mainAddressValidationMsg,
          maxLength: 20,
        },
        emailAddress: {
          required: false,
          message: organisationLabels.orgEmailValidationMsg,
          invalidInputMessage: organisationLabels.orgEmailValidationMsg,
          maxLength: 320,
          isEmail: true,
        },
        phoneNumber: {
          required: false,
          message: organisationLabels.orgTelephoneValidatorMsg,
          invalidInputMessage: organisationLabels.orgTelephoneValidatorMsg,
          maxLength: 20,
          minLength: 7,
          phoneNumber: true,
        },
        city: {
          required: true,
          message: organisationLabels.cityValidationMsg,
          maxLength: 100,
        },
        country: {
          required: true,
          message: organisationLabels.countryValidationMsg,
          isDropDown: true,
        },
      },
      partnerLead: {
        required: true,
        message: organisationLabels.patnerLeadValidationMsg,
        isDropDown: true,
      },
      partnerContact: {
        required: false,
        message: organisationLabels.partnerContactValidationMsg,
        maxLength: 50,
      },
      methodOfDelivery: {
        required: true,
        message: organisationLabels.methodOfDeliveryValidationMsg,
        isDropDown: true,
      },
      sectorType: {
        required: true,
        message: organisationLabels.sectorTypeValidationMsg,
        isDropDown: true,
      },
      websiteUrl: {
        required: isRo,
        emptyInputmessage: organisationLabels.websiteURLValidationMsg,
        invalidInputMessage: organisationLabels.websiteURLInvalidValidationMsg,
        isURL: true,
        maxLength: 250,
      },
      resultAvailableForYears: {
        required: false,
        message: organisationLabels.resultAvailableForYearsValidationMsg,
        isDropDown: true,
      },
      crmSystem: {
        required: false,
        maxLength: 50,
        message: organisationLabels.sectorTypeValidationMsg,
      },
      code: {
        required: false,
        maxLength: 20,
        message: organisationLabels.sectorTypeValidationMsg,
      },
    },
    contactDetails: {
      primaryContactAddress: {
        givenName: {
          required: isRo,
          message: organisationLabels.primaryContactGivenNameValidationMsg,
          maxLength: 50,
        },
        familyName: {
          required: isRo,
          message: organisationLabels.primaryContactFamilyNameValidationMsg,
          maxLength: 50,
        },
        emailAddress: {
          required: isRo,
          isEmail: true,
          emptyInputmessage: organisationLabels.orgEmailValidationMsg,
          invalidInputMessage: organisationLabels.orgEmailValidationMsg,
          maxLength: 320,
        },
        phoneNumber: {
          required: false,
          message: organisationLabels.orgTelephoneValidatorMsg,
          invalidInputMessage: organisationLabels.orgTelephoneValidatorMsg,
          maxLength: 20,
          minLength: 7,
          phoneNumber: true,
        },
        jobTitle: {
          required: false,
          message: organisationLabels.primaryContactFamilyNameValidationMsg,
          maxLength: 100,
        },
        addressOne: {
          required: false,
          message: organisationLabels.mainAddressValidationMsg,
          maxLength: 100,
        },
        addressTwo: {
          required: false,
          message: organisationLabels.mainAddressValidationMsg,
          maxLength: 100,
        },
        addressThree: {
          required: false,
          message: organisationLabels.mainAddressValidationMsg,
          maxLength: 100,
        },
        addressFour: {
          required: false,
          message: organisationLabels.mainAddressValidationMsg,
          maxLength: 100,
        },
        city: {
          required: false,
          message: organisationLabels.mainAddressValidationMsg,
          maxLength: 100,
        },
        postalCode: {
          required: false,
          message: organisationLabels.mainAddressValidationMsg,
          maxLength: 20,
        },
      },
      adminContactAddress: {
        givenName: {
          required: isAdminDetails,
          message: organisationLabels.adminContactGivenNameValidationMsg,
          maxLength: 50,
        },
        familyName: {
          required: isAdminDetails,
          message: organisationLabels.adminContactFamilyNameValidationMsg,
          maxLength: 50,
        },
        emailAddress: {
          required: isAdminDetails,
          isEmail: true,
          emptyInputmessage: organisationLabels.orgEmailValidationMsg,
          invalidInputMessage: organisationLabels.orgEmailValidationMsg,
          maxLength: 320,
        },
        jobTitle: {
          required: false,
          message: organisationLabels.adminContactFamilyNameValidationMsg,
          maxLength: 100,
        },
        addressOne: {
          required: false,
          message: organisationLabels.mainAddressValidationMsg,
          maxLength: 100,
        },
        addressTwo: {
          required: false,
          message: organisationLabels.mainAddressValidationMsg,
          maxLength: 100,
        },
        addressThree: {
          required: false,
          message: organisationLabels.mainAddressValidationMsg,
          maxLength: 100,
        },
        addressFour: {
          required: false,
          message: organisationLabels.mainAddressValidationMsg,
          maxLength: 100,
        },
        city: {
          required: false,
          message: organisationLabels.mainAddressValidationMsg,
          maxLength: 100,
        },
        postalCode: {
          required: false,
          message: organisationLabels.mainAddressValidationMsg,
          maxLength: 20,
        },
        phoneNumber: {
          required: false,
          message: organisationLabels.orgTelephoneValidatorMsg,
          invalidInputMessage: organisationLabels.orgTelephoneValidatorMsg,
          maxLength: 20,
          minLength: 7,
          phoneNumber: true,
        },
      },
    },
  };
};

export default addOrganisationFormRules;
