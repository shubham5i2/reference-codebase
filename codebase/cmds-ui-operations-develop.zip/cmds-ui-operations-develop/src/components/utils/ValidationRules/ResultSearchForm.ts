import { FormStepRule } from '../../../services/Models/UIModels';

export const ResultSearchRules: FormStepRule = {
  firstName: {
    required: false,
    maxLength: 100,
    requiredType: 'optional',
  },
  lastName: {
    required: false,
    maxLength: 100,
    requiredType: 'optional',
  },
  uniqueTestTakerId: {
    required: false,
    maxLength: 14,
  },
  testTakerNumber: {
    required: false,
    maxLength: 6,
  },
  identityNumber: {
    required: false,
    maxLength: 100,
  },
};
