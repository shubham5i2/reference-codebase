import { languageService } from '../../../services/Language/LanguageService';
import { AddressType, AddressFormElements } from '../../../services/Models/LocationManagement';
const LocationLabels = languageService().locationManagement;

export const locationAddressFormRules = {
  [AddressType.POSTAL]: {
    [AddressFormElements.addressLine1]: {
      required: true,
      message: LocationLabels.postalAddressValidationMsg,
      maxLength: 100,
    },
    [AddressFormElements.addressLine2]: {
      required: false,
      message: LocationLabels.postalAddressValidationMsg,
      maxLength: 100,
    },
    [AddressFormElements.addressLine3]: {
      required: false,
      message: LocationLabels.postalAddressValidationMsg,
      maxLength: 100,
    },
    [AddressFormElements.addressLine4]: {
      required: false,
      message: LocationLabels.postalAddressValidationMsg,
      maxLength: 100,
    },
    [AddressFormElements.city]: {
      required: true,
      message: LocationLabels.cityValidationMsg,
      maxLength: 100,
    },
    [AddressFormElements.countryUuid]: {
      required: true,
      message: LocationLabels.countryValidationMsg,
      isDropDown: true,
    },
    [AddressFormElements.territoryUuid]: {
      required: true,
      message: LocationLabels.terittoryValidationMsg,
      isDropDown: true,
    },
    [AddressFormElements.countryIso3Code]: {
      required: true,
      message: LocationLabels.countryValidationMsg,
    },
    [AddressFormElements.postalCode]: {
      required: false,
      message: LocationLabels.postalAddressValidationMsg,
      maxLength: 20,
    },
    [AddressFormElements.email]: {
      required: false,
      message: LocationLabels.emailEmptyMsg,
      invalidInputMessage: LocationLabels.emailValidationMsg,
      maxLength: 320,
      isEmail: true,
    },
    [AddressFormElements.primaryPhone]: {
      required: true,
      emptyInputmessage: LocationLabels.locPrimaryValidatorMsg,
      invalidInputMessage: LocationLabels.locPrimaryInvalidValidationMsg,
      maxLength: 20,
      minLength: 7,
      phoneNumber: true,
    },
    [AddressFormElements.secondaryPhone]: {
      required: false,
      emptyInputmessage: LocationLabels.locSecondaryValidatorMsg,
      invalidInputMessage: LocationLabels.locSecondaryInvalidValidationMsg,
      maxLength: 20,
      minLength: 7,
      phoneNumber: true,
    },
  },
  [AddressType.PHYSICAL]: {
    [AddressFormElements.addressLine1]: {
      required: true,
      message: LocationLabels.physicalAddressValidationMsg,
      maxLength: 100,
    },
    [AddressFormElements.addressLine2]: {
      required: false,
      message: LocationLabels.physicalAddressValidationMsg,
      maxLength: 100,
    },
    [AddressFormElements.addressLine3]: {
      required: false,
      message: LocationLabels.physicalAddressValidationMsg,
      maxLength: 100,
    },
    [AddressFormElements.addressLine4]: {
      required: false,
      message: LocationLabels.physicalAddressValidationMsg,
      maxLength: 100,
    },
    [AddressFormElements.city]: {
      required: true,
      message: LocationLabels.cityValidationMsg,
      maxLength: 100,
    },
    [AddressFormElements.countryUuid]: {
      required: true,
      message: LocationLabels.countryValidationMsg,
      isDropDown: true,
    },
    [AddressFormElements.territoryUuid]: {
      required: true,
      message: LocationLabels.terittoryValidationMsg,
      isDropDown: true,
    },
    [AddressFormElements.countryIso3Code]: {
      required: true,
      message: LocationLabels.countryValidationMsg,
    },
    [AddressFormElements.postalCode]: {
      required: false,
      message: LocationLabels.physicalAddressValidationMsg,
      maxLength: 20,
    },
    [AddressFormElements.email]: {
      required: false,
      message: LocationLabels.emailEmptyMsg,
      invalidInputMessage: LocationLabels.emailValidationMsg,
      maxLength: 320,
      isEmail: true,
    },
    [AddressFormElements.primaryPhone]: {
      required: true,
      emptyInputmessage: LocationLabels.locPrimaryValidatorMsg,
      invalidInputMessage: LocationLabels.locPrimaryInvalidValidationMsg,
      maxLength: 20,
      minLength: 7,
      phoneNumber: true,
    },
    [AddressFormElements.secondaryPhone]: {
      required: false,
      emptyInputmessage: LocationLabels.locSecondaryValidatorMsg,
      invalidInputMessage: LocationLabels.locSecondaryInvalidValidationMsg,
      maxLength: 20,
      minLength: 7,
      phoneNumber: true,
    },
  },
};
