import React from 'react';
import styles from './TestTakerSearch.module.scss';
import SearchPanel from '../../Organisms/TestTakerSearchPanel/TestTakerSearchPanel';
import { BasicSearchData } from '../../../services/Models/TestTakerManagement';

export interface TestTakerSearchPanelProps {
  title: string;
  titleType: string;
  titleSize: string | number;
  subTitle: string;
  subTitleType: string;
  subTitleSize: string | number;
  basicSearchData: BasicSearchData;
  onClearBasicSearch(event: React.FormEvent<HTMLInputElement> | React.FormEvent<HTMLAnchorElement>): void;
  clearBasicSearch: string;
  basicSearchButtonLabel: string;
  basicSearchButtonColor: string;
  onBasicSearchHandler: () => void;
  handleBasicInputChange: (e: React.FormEvent<HTMLInputElement>) => void;
  collapseTitle: string;
  collapseOpenTitle: string;
  collapseFooterTitle: string;
  advanceSearchButtonLabel: string;
  advanceSearchButtonColor: string;
  onClearAdvancedSearch(event: React.FormEvent<HTMLInputElement> | React.FormEvent<HTMLAnchorElement>): void;
  clearAdvancedSearch: string;
  handleAdvancedInputChange: (e: React.FormEvent<HTMLInputElement>) => void;
  onAdvancedSearchHandler: () => void;
  initialOpenState: boolean;
  ieltsTestTakerLabel: string;
  cmdsBookingIdLabel: string;
  identityDocumentNumberLabel: string;
  mandatoryLabel?: string;
  children: any;
}

const TestTakerSearchPanel = (props: TestTakerSearchPanelProps) => {
  return (
    <div>
      <div className={styles.searchPanel}>
        <SearchPanel
          title={props.title}
          titleType={props.titleType}
          titleSize={props.titleSize}
          subTitle={props.subTitle}
          subTitleType={props.subTitleType}
          subTitleSize={props.subTitleSize}
          basicSearchData={props.basicSearchData}
          onClearBasicSearch={props.onClearBasicSearch}
          clearBasicSearch={props.clearBasicSearch}
          basicSearchButtonLabel={props.basicSearchButtonLabel}
          basicSearchButtonColor={props.basicSearchButtonColor}
          onBasicSearchHandler={props.onBasicSearchHandler}
          handleBasicInputChange={props.handleBasicInputChange}
          collapseTitle={props.collapseTitle}
          collapseOpenTitle={props.collapseOpenTitle}
          collapseFooterTitle={props.collapseFooterTitle}
          advanceSearchButtonLabel={props.advanceSearchButtonLabel}
          advanceSearchButtonColor={props.advanceSearchButtonColor}
          onClearAdvancedSearch={props.onClearAdvancedSearch}
          clearAdvancedSearch={props.clearAdvancedSearch}
          handleAdvancedInputChange={props.handleAdvancedInputChange}
          onAdvancedSearchHandler={props.onAdvancedSearchHandler}
          initialOpenState={props.initialOpenState}
          ieltsTestTakerLabel={props.ieltsTestTakerLabel}
          cmdsBookingIdLabel={props.cmdsBookingIdLabel}
          identityDocumentNumberLabel={props.identityDocumentNumberLabel}
        >
          {props.children}
        </SearchPanel>
      </div>
    </div>
  );
};

export default TestTakerSearchPanel;
