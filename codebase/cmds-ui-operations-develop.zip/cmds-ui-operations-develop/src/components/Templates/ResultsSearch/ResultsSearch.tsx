import React from 'react';
import styles from './ResultsSearch.module.scss';
import SearchPanel, { IResultsSearchPanel } from '../../Organisms/ResultsSearchPanel/ResultsSearchPanel';

const ResultsSearchPanel = (props: IResultsSearchPanel) => {
  return (
    <div>
      <div className={styles.searchPanel}>
        <SearchPanel {...props}>{props.children}</SearchPanel>
      </div>
    </div>
  );
};

export default ResultsSearchPanel;
