import { languageService } from '../../../services/Language/LanguageService';
import {
  OrganisationProfileData,
  ContactDetailsData,
  AddressType,
  ContactType,
  MinimumScoreModuleType,
} from '../../../services/Models/Organisation';

const commonLabels = languageService().common;

const getMinimumScoreTabTitles = () => {
  const organisationLabels = languageService().organisation;
  return [organisationLabels.ieltsTraining, organisationLabels.ieltsAcademic];
};

export const initialDropDownDataSource = { text: '', value: '' };
export const initialMultiDropDownDataSource = { '': { text: '', value: '' } };

const scoreOptions = [
  { value: '1', text: '1' },
  { value: '2', text: '2' },
  { value: '3', text: '3' },
  { value: '3.5', text: '3.5' },
  { value: '4', text: '4' },
  { value: '4.5', text: '4.5' },
  { value: '5', text: '5' },
  { value: '5.5', text: '5.5' },
  { value: '6', text: '6' },
  { value: '6.5', text: '6.5' },
  { value: '7', text: '7' },
  { value: '7.5', text: '7.5' },
  { value: '8', text: '8' },
  { value: '8.5', text: '8.5' },
  { value: '9', text: '9' },
];

export const noOfYears = [
  { value: '2', text: '2' },
  { value: '3', text: '3' },
  { value: '4', text: '4' },
  { value: '5', text: '5' },
  { value: '6', text: '6' },
  { value: '7', text: '7' },
  { value: '8', text: '8' },
  { value: '9', text: '9' },
  { value: '10', text: '10' },
];

export const initialMinimumScore = {
  ieltsAcademic: {
    moduleTypeUuid: MinimumScoreModuleType.ACADEMIC,
    value: 'ieltsAcademic',
    tabText: getMinimumScoreTabTitles()[1],
    listening: {
      scoreOptions: scoreOptions,
    },
    reading: {
      scoreOptions: scoreOptions,
    },
    writing: {
      scoreOptions: scoreOptions,
    },
    speaking: {
      scoreOptions: scoreOptions,
    },
    overallScore: {
      scoreOptions: scoreOptions,
    },
    isCurrentSelectedTab: false,
  },
  ieltsTraining: {
    moduleTypeUuid: MinimumScoreModuleType.TRAINING,
    value: 'ieltsTraining',
    tabText: getMinimumScoreTabTitles()[0],
    listening: {
      scoreOptions: scoreOptions,
    },
    reading: {
      scoreOptions: scoreOptions,
    },
    writing: {
      scoreOptions: scoreOptions,
    },
    speaking: {
      scoreOptions: scoreOptions,
    },
    overallScore: {
      scoreOptions: scoreOptions,
    },
    isCurrentSelectedTab: true,
  },
};

export const initialOrganisationProfile: OrganisationProfileData = {
  organisationName: '',
  organisationStatus: false,
  organisationType: initialDropDownDataSource,
  verificationStatus: initialDropDownDataSource,
  mainAddress: { addressTypeUuid: AddressType.MAIN, isRequired: true },
  deliveryAddress: { addressTypeUuid: AddressType.DELIVERY, isRequired: false },
  partnerLead: initialDropDownDataSource,
  partnerContact: '',
  methodOfDelivery: initialDropDownDataSource,
  sectorType: initialDropDownDataSource,
  acceptIOL: false,
  orsDisplayFlag: false,
  ieltsDisplayFlag: false,
  websiteUrl: '',
  parentOrganisationId: '',
  parentOrganisationName: '',
  parentOrganisationUuid: '',
  additionalDeliveryOrganisation: initialMultiDropDownDataSource,
  resultAvailableForYears: { text: '3', value: '3' },
  acceptSSR: false,
  acceptGT: true,
  acceptAC: true,
};

export const initialContactDetails: ContactDetailsData = {
  primaryContactAddress: {
    addressTypeUuid: AddressType.MAIN,
    contactTypeUuid: ContactType.PRIMARY,
    isRequired: true,
  },
  adminContactAddress: {
    addressTypeUuid: AddressType.MAIN,
    contactTypeUuid: ContactType.RESULTADMIN,
    isRequired: false,
  },
};

export default noOfYears;

export const BASE_VERIFICATION_STATUS = [
  { value: 'PENDING', text: commonLabels.pending },
  { value: 'APPROVED', text: commonLabels.approved },
  { value: 'VERIFIED', text: commonLabels.verified },
  { value: 'REJECTED', text: commonLabels.rejected },
];
