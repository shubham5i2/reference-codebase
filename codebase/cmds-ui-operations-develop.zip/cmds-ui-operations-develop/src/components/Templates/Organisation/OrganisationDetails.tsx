import React from 'react';
import FormTitle from '../../Organisms/ManageUserFormHeader/ManageUserFormHeader';
import styles from './OrganisationDetails.module.scss';
import UI from 'ielts-cmds-ui-component-library';
import OrganisationProfile from '../../Organisms/Organisation/OrganisationDetails/OrganisationProfile';
import ContactDetails from '../../Organisms/Organisation/ContactDetails/ContactDetails';
import MinimumScore from '../../Organisms/Organisation/MinimumScore/MinimumScore';
import ToastMessage, { Mode, Position } from '../../Organisms/ToastMessage/ToastMessage';
import { DEFAULT_TOAST_MESSAGE_TIMER } from '../../../constants/GlobalConstants';
import cx from 'classnames';
import { languageService } from '../../../services/Language/LanguageService';
import {
  OrganisationProfileData,
  ContactDetailsData,
  MinimumScoreData,
  OrganisationFromInputChangeEvent,
  OrganisationFormAction,
  OrganisationFormType,
  OrganisationType,
} from '../../../services/Models/Organisation';
import { Dictionary } from '../../../services/Models/UIModels';
import OrganisationConfirmationModal from '../../Others/OrganisationConfirmationModal/OrganisationConfirmationModal';
import organisationAddFormRules, {
  adminContactDetailsValidator,
} from '../../utils/ValidationRules/OrganisationAddForm';
import OrganisationLabels from '../../../services/Language/en/en.organisation';
import { getIsParentChangedOrRemoved } from '../../../services/API/Organisation/AddUpdateOrganisation';

interface OrganisationDetailsProps {
  organisationDetails: OrganisationProfileData;
  contactDetails: ContactDetailsData;
  minimumScore: MinimumScoreData;
  handleInputChange: (event: OrganisationFromInputChangeEvent) => void;
  onSubmit: () => void;
  error: Dictionary;
  onCancel: () => void;
  showErrorMessage: boolean;
  showConfirmationDialog: boolean;
  handleAddOrgConfirmation: () => void;
  handleAddOrgConfirmationCancel: (isFromWarningDialog: boolean) => void;
  onRemoveErrorMessage: () => void;
  orgFormAction: OrganisationFormAction;
  setOrganisationForm: (formType: OrganisationFormType, updatedState: Dictionary) => void;
}

const OrganisationDetails = (props: OrganisationDetailsProps) => {
  console.log('contacterror', props.error);
  const { handleInputChange, organisationDetails, contactDetails, minimumScore, onSubmit, error, onCancel } = props;
  const organisationLabels = languageService().organisation;

  console.error('admin ', adminContactDetailsValidator);
  const orgFormRule = organisationAddFormRules(
    organisationDetails.organisationType.value,
    adminContactDetailsValidator({
      organisationDetails,
      contactDetails,
    }),
  );

  console.log('orgformrule', orgFormRule);

  const getOrganisationProfile = () => {
    return (
      <div className={cx(styles.formPanel, styles.ogForm)}>
        <OrganisationProfile
          onChange={handleInputChange}
          organisationDetails={organisationDetails}
          error={error}
          orgProfileRule={orgFormRule.organisationProfile}
          orgFormAction={props.orgFormAction}
          setOrganisationForm={props.setOrganisationForm}
        />
      </div>
    );
  };

  const getContactDetails = () => {
    return (
      <div className={cx(styles.formPanel, styles.ogForm)}>
        <div className={styles.ogFormHead}>
          <FormTitle
            title={organisationLabels.contactDetailsTitle}
            showMessage={true}
            showOptionalMessage={false}
            size={24}
          />
        </div>
        <ContactDetails
          onChange={handleInputChange}
          contactDetails={contactDetails}
          error={error}
          contactDetailsRule={orgFormRule.contactDetails}
        />
      </div>
    );
  };

  const getMinimumScore = () => (
    <div className={cx(styles.formPanel, styles.ogForm, styles.minimumScoreContainer)}>
      <div className={styles.ogFormHead}>
        <FormTitle
          title={organisationLabels.minimumScoreRequirementTitle}
          showMessage={false}
          showOptionalMessage={false}
          size={24}
        />
      </div>
      <MinimumScore onChange={handleInputChange} minimumScore={minimumScore} />
    </div>
  );

  const getFooterButton = () => (
    <div className={styles.footerButtons}>
      <div className={styles.buttonContainer}>
        <UI.Button
          color="secondary"
          label={organisationLabels.cancelButtonTitle}
          id="CancelNewOrg"
          onChange={onCancel}
        />
        <UI.Button
          color="primary"
          label={
            props.orgFormAction === OrganisationFormAction.UPDATE
              ? OrganisationLabels.updateButtonTitle
              : organisationLabels.addButtonTitle
          }
          id="AddNewOrg"
          onChange={onSubmit}
        />
      </div>
    </div>
  );

  const getErrorMessage = () => {
    // Added toastmessae here
    return props.showErrorMessage ? (
      <ToastMessage
        id="toast_panel_error"
        color={Mode.ERROR}
        position={Position.DEFAULT}
        dismissable={true}
        onChange={props.onRemoveErrorMessage}
        duration={DEFAULT_TOAST_MESSAGE_TIMER}
        message={organisationLabels.addOrgValidationToastErrorMsg}
      ></ToastMessage>
    ) : null;
  };

  const getConfirmationDialog = () => {
    return props.showConfirmationDialog ? (
      <OrganisationConfirmationModal
        organisationName={organisationDetails.organisationName}
        organisationId={organisationDetails.organisationId}
        headerText={
          props.orgFormAction === OrganisationFormAction.ADD
            ? organisationLabels.addOrgConfirmationHeader
            : organisationLabels.updateOrgConfirmationHeader
        }
        titleText={
          props.orgFormAction === OrganisationFormAction.ADD
            ? organisationLabels.addOrgConfirmationMsg
            : props.organisationDetails.organisationType.value === OrganisationType.RO &&
              getIsParentChangedOrRemoved(organisationDetails)
            ? organisationLabels.updateOrgWarninglabel
            : organisationLabels.updateOrgConfirmationMsg
        }
        cancelHandler={() => props.handleAddOrgConfirmationCancel(getIsParentChangedOrRemoved(organisationDetails))}
        confirmHandler={props.handleAddOrgConfirmation}
      />
    ) : null;
  };

  return (
    <div className={styles.formContainer}>
      {getErrorMessage()}
      {getConfirmationDialog()}
      <div className={styles.formHead}>
        <FormTitle
          title={
            props.orgFormAction === OrganisationFormAction.UPDATE
              ? organisationLabels.updateOrganisationHeader
              : organisationLabels.addOrganisationHeader
          }
          pageTitle={true}
          showMessage={true}
          size={32}
        />
      </div>
      {getOrganisationProfile()}
      {getContactDetails()}
      {getMinimumScore()}
      {getFooterButton()}
    </div>
  );
};

export default OrganisationDetails;
