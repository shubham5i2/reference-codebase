import * as React from 'react';
import Styles from './ViewUser.module.scss';
import LeftPanel from '../../Organisms/ViewUserPanels/LeftPanel/LeftPanel';
import RightPanel from '../../Organisms/ViewUserPanels/RightPanel/RightPanel';
import ProfileHeader from '../../Organisms/ProfileHeader/ProfileHeader';

const ViewUser = (props: any) => {
  return (
    <div className={Styles.viewUserComponent} id="viewUserPageContainer">
      <div className={Styles.wrapper}>
        <div className={Styles.container} id="profileHeader">
          <ProfileHeader
            user={props.user}
            showProfileHeader={true}
            showBreadCrumb={true}
            status={props.status}
            onHeaderAction={props.onHeaderAction}
          />
        </div>
      </div>

      <div className={Styles.panelContainer}>
        <div className={Styles.leftPanel}>
          <LeftPanel header={props.headerText} userInfo={props.userData} />
        </div>
        <div className={Styles.rightPanel}>
          <RightPanel userGroups={props.userGroupDetails} />
        </div>
      </div>
    </div>
  );
};

export default ViewUser;
