import React from 'react';
import styles from './OrganisationSearchResults.module.scss';
import ROGrid from '../../../Organisms/ROGrid/ROGrid';

const OrganisationSearchResults = (props: any) => {
  return (
    <div className={styles.searchResults}>
      <ROGrid {...props} />
    </div>
  );
};

export default OrganisationSearchResults;
