import React from 'react';
import styles from './OrganisationSearch.module.scss';
import SearchPanel from '../../Organisms/OrganisationSearchPanel/OrganisationSearchPanel';

const OrganisationSearchPanel = (props: any) => {
  return (
    <div>
      <div className={styles.searchPanel}>
        <SearchPanel
          title={props.title}
          titleType={props.titleType}
          titleSize={props.titleSize}
          addButtonLabel={props.addButtonLabel}
          addButtonColor={props.addButtonColor}
          addButtonIcon={props.addButtonIcon}
          subTitle={props.subTitle}
          subTitleType={props.subTitleType}
          subTitleSize={props.subTitleSize}
          basicSearchData={props.basicSearchData}
          onClearBasicSearch={props.onClearBasicSearch}
          clearBasicSearch={props.clearBasicSearch}
          basicSearchButtonLabel={props.basicSearchButtonLabel}
          basicSearchButtonColor={props.basicSearchButtonColor}
          onBasicSearchHandler={props.onBasicSearchHandler}
          handleBasicInputChange={props.handleBasicInputChange}
          onAddUserHandler={props.onAddUserHandler}
          collapseTitle={props.collapseTitle}
          collapseOpenTitle={props.collapseOpenTitle}
          collapseFooterTitle={props.collapseFooterTitle}
          advanceSearchButtonLabel={props.advanceSearchButtonLabel}
          advanceSearchButtonColor={props.advanceSearchButtonColor}
          onClearAdvancedSearch={props.onClearAdvancedSearch}
          clearAdvancedSearch={props.clearAdvancedSearch}
          handleAdvancedInputChange={props.handleAdvancedInputChange}
          onAdvancedSearchHandler={props.onAdvancedSearchHandler}
          initialOpenState={props.initialOpenState}
        >
          {props.children}
        </SearchPanel>
      </div>
    </div>
  );
};

export default OrganisationSearchPanel;
