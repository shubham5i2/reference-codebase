import React from 'react';
import styles from './ManageUser.module.scss';

import FormTitle from '../../Organisms/ManageUserFormHeader/ManageUserFormHeader';
import UI from 'ielts-cmds-ui-component-library';
import AssignGroup from '../../Organisms/AssignGroup/AssignGroup';
import PersonalProfile from '../../Organisms/PersonalProfile/PersonalProfile';
import ReviewProfile from '../../Organisms/ReviewProfile/ReviewProfile';
import { useParams, useHistory } from 'react-router-dom';
import cx from 'classnames';
import { UserFormError, RouteParams } from '../../../services/Models/UIModels';
import { User } from '@auth0/auth0-spa-js';
import { languageService } from '../../../services/Language/LanguageService';
import ToastMessage, { Mode, Position } from '../../Organisms/ToastMessage/ToastMessage';

interface IntrinsicElements {
  Component: React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>;
}

const components: any = {
  PersonalProfile: PersonalProfile,
  AssignGroup: AssignGroup,
  ReviewProfile: ReviewProfile,
};

interface ManageUserProps {
  currentStep: number;
  error: UserFormError;
  formTitle: string[];
  handleSubmit: () => boolean;
  progressSteps: string[];
  setcurrentStep: (index: number) => void;
  handleInputChange: (e: any) => void;
  userData: User;
  showError: boolean;
  onClose: (index: number) => void;
  setShowError: (error: boolean) => void;
}

const ManageUser = (props: ManageUserProps) => {
  const smLabels = languageService().staffManagement;
  const { currentStep, handleInputChange, formTitle, progressSteps, handleSubmit, setcurrentStep } = props;
  const { id } = useParams<RouteParams>();
  const history: any = useHistory();
  const renderComponent = () => {
    const key = Object.keys(components)[currentStep];
    const Component = components[key];
    return <Component {...props.userData} id onChange={handleInputChange} {...props} />;
  };

  return (
    <div className={styles.sm_FormContainer}>
      {' '}
      {props.showError ? (
        <ToastMessage
          id="toast_panel_error"
          color={Mode.ERROR}
          position={Position.DEFAULT}
          margin={{ left: 0, right: 0, top: 0, bottom: 0 }}
          dismissable={true}
          onChange={() => {
            props.setShowError(false);
          }}
          message={smLabels.addUpdateValidationMessage}
        ></ToastMessage>
      ) : (
        ''
      )}{' '}
      <div className={styles.sm_progressBar}>
        <UI.ProgressBar stepList={progressSteps} currentStep={currentStep} />
      </div>
      <div className={styles.sm_head}>
        <FormTitle title={formTitle[currentStep]} showMessage={currentStep === 0} showOptionalMessage={true} />
      </div>
      <div className={cx(styles.sm_formPanel, styles.sm_form)}>{renderComponent()}</div>
      <div className={styles.sm_form_btn}>
        <UI.Button
          label={currentStep > 0 ? smLabels.goBack : smLabels.cancel}
          color="secondary"
          onChange={() => {
            setcurrentStep(currentStep > 0 ? currentStep - 1 : currentStep);
            if (currentStep === 0) {
              history.goBack();
            }
          }}
          id={currentStep > 0 ? 'Go Back' : 'Cancel'}
        />
        <UI.Button
          label={currentStep < 2 ? smLabels.continue : id ? smLabels.update : smLabels.add}
          id={currentStep < 2 ? 'Continue' : 'Add'}
          color="primary"
          onChange={() => {
            if (handleSubmit()) {
              setcurrentStep(progressSteps.length - 1 === currentStep ? currentStep : currentStep + 1);
            }
          }}
        />
      </div>
    </div>
  );
};

export default ManageUser;
