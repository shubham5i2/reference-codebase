import React, { useEffect } from 'react';
import styles from './ManageUser.module.scss';

import FormTitle from '../../Organisms/ManageUserFormHeader/ManageUserFormHeader';
import UI from 'ielts-cmds-ui-component-library';
import AssignGroup from '../../Organisms/AssignGroup/AssignGroup';
import { useHistory, useParams } from 'react-router-dom';
import cx from 'classnames';
import { UserFormError, RouteParams } from '../../../services/Models/UIModels';
import { User, AssignGroupData } from '../../../services/Models/StaffManagement';
import { languageService } from '../../../services/Language/LanguageService';
import { useStateValue } from '../../../Store/helpers/UseStateValue';
import * as BreadCrumbActions from '../../../Store/Actions/BreadCrumbActions';
import { getUserStatusDictonary, statusStyle } from '../../utils/utilities';

interface UserAssignGroupProps {
  userData: User;
  error: UserFormError;
  handleInputChange: (e: any) => void;
  assignUserGroupHandler: () => void;
  assignGroupData: AssignGroupData[];
  size?: number;
  onClose: (index: number) => void;
}

const UserAssignGroup = (props: UserAssignGroupProps) => {
  const { dispatch } = useStateValue();

  const smLabels = languageService().staffManagement;
  const { id } = useParams<RouteParams>();

  const { handleInputChange, userData, assignUserGroupHandler } = props;
  const history = useHistory();
  const user = {
    firstName: userData.givenName,
    lastName: userData.familyName,
  };

  useEffect(() => {
    dispatch({ type: BreadCrumbActions.SHOW_BACK, payload: id });
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className={cx(styles.sm_FormContainer, styles.agFormConatainer)}>
      <div className={styles.sm_head}>
        <FormTitle title={smLabels.assignGroupsTitle} showMessage={false} showOptionalMessage={false} />
      </div>
      <div className={styles.agSubHead}>
        <UI.Typography
          type="normal"
          id="assignGroupHeader"
          label={smLabels.assignGroupHeader}
          size={props.size || 16}
        />
      </div>
      <div className={cx(styles.col2Head, styles.adContainer)}>
        <div className={styles.agAvatar} id="assignGroupHeaderAvatar">
          <UI.Avatar id="avatar" title={user} color={'green'} />
        </div>
        <div className={styles.col3Head}>
          <div className={styles.agHead}>
            <label id="assignGroupHeaderNameLabel">{smLabels.name}</label>
            <span id="assignGroupHeaderNameValue">
              {user.firstName} {user.lastName}
            </span>
          </div>
          <div>
            <label id="assignGroupHeaderEmailLabel">{smLabels.emailId}</label>
            <span id="assignGroupHeaderEmailValue">{userData.email}</span>
          </div>
          <div>
            <label id="assignGroupHeaderStatusLabel">{smLabels.status}</label>
            <span className={styles.agStatus} id="assignGroupHeaderStatusValue">
              <UI.Status
                status={statusStyle[userData.userStatus]}
                label={getUserStatusDictonary()[userData.userStatus]}
              />
            </span>
          </div>
          <div>
            <label id="assignGroupHeaderStaffIdLabel">{smLabels.staffId}</label>
            <span id="assignGroupHeaderStaffIdValue">{userData.userUuid || ''}</span>
          </div>
          <div className={styles.usergroupContainer}>
            <label id="assignGroupHeaderUserGroupLabel">{smLabels.userGroupTitle}</label>
            <span id="assignGroupHeaderUserGroupValue">{history.location.state.userGroup}</span>
          </div>
        </div>
      </div>
      <div className={cx(styles.sm_formPanel, styles.sm_form)}>
        <AssignGroup
          onChange={handleInputChange}
          {...props}
          assignGroupData={props.assignGroupData || userData.assignGroupData}
        />
      </div>
      <div className={styles.sm_form_btn}>
        <UI.Button
          label={smLabels.cancel}
          color="secondary"
          id={'Cancel'}
          onChange={() => {
            history.goBack();
          }}
        />
        <UI.Button label={smLabels.assign} id={'Assign'} color="primary" onChange={assignUserGroupHandler} />
      </div>
    </div>
  );
};

export default UserAssignGroup;
