import React, { useEffect, useState } from 'react';
import UI from 'ielts-cmds-ui-component-library';

import styles from '../../../App.module.scss';
import { languageService } from '../../../services/Language/LanguageService';
import AppBar from '../../Organisms/app-bar/AppBar';
import Footer from '../../Organisms/Footer/Footer';
import LeftNavigationList, { aaLeftNavigationMenu } from '../../../config/LeftNavigationList';
import useRBAC from '../../../services/hooks/useRBAC';
import { useHistory, useLocation } from 'react-router-dom';

const commonLabels = languageService().common;
const footerLinks = [commonLabels.disclaimer, commonLabels.legal, commonLabels.privacyPolicy];
const copyRightText = commonLabels.copyRightText;

const AppTemplate: React.FC = ({ children }) => {
  const history = useHistory();
  const location = useLocation();

  const [menuHighlightState, setMenuHighlightState] = useState(0);

  const aaUserAccess = useRBAC('accessarrangements');

  useEffect(() => {
    const idx = LeftNavigationList.findIndex(
      (data) => data.url === location.pathname || !!data.subMenu?.find((subMenu) => subMenu.url === location.pathname),
    );
    setMenuHighlightState(idx);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.pathname]);

  useEffect(() => {
    if (aaUserAccess?.isReadAccess) {
      LeftNavigationList.push(aaLeftNavigationMenu);
    }
  }, [aaUserAccess]);

  const navItemSelectionHandler = (url: string) => {
    history.push(url);
  };

  const getNavBar = () => (
    <div className={styles.leftNavComponent}>
      <UI.LeftNavigation
        navigationList={LeftNavigationList}
        onNavMenuItemSelected={navItemSelectionHandler}
        menuHighlightState={menuHighlightState}
      ></UI.LeftNavigation>
    </div>
  );
  return (
    <div className={styles.appComponent} id="appContent">
      <AppBar />
      {getNavBar()}
      {children}
      <Footer copyRightText={copyRightText} footerLinks={footerLinks} />
    </div>
  );
};

export default AppTemplate;
