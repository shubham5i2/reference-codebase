import React from 'react';
import styles from './OrganisationDuplicateSearch.module.scss';
import SearchPanel, {
  organisationDuplicateSearchPanelProps,
} from '../../Organisms/OrganisationDuplicateSearchPanel/OrganisationDuplicateSearchPanel';

const OrganisationDuplicateSearchPanel = (props: organisationDuplicateSearchPanelProps) => {
  return (
    <div>
      <div className={styles.searchPanel}>
        <SearchPanel
          title={props.title}
          titleType={props.titleType}
          titleSize={props.titleSize}
          subTitle={props.subTitle}
          subTitleType={props.subTitleType}
          subTitleSize={props.subTitleSize}
          duplicateSearchData={props.duplicateSearchData}
          onClearDuplicateSearch={props.onClearDuplicateSearch}
          clearDuplicateSearch={props.clearDuplicateSearch}
          duplicateSearchButtonLabel={props.duplicateSearchButtonLabel}
          duplicateSearchButtonColor={props.duplicateSearchButtonColor}
          onDuplicateSearchHandler={props.onDuplicateSearchHandler}
          handleDuplicateInputChange={props.handleDuplicateInputChange}
        />
      </div>
    </div>
  );
};

export default OrganisationDuplicateSearchPanel;
