import React from 'react';
import styles from './ManageSearch.module.scss';
import SearchPanel from '../../Organisms/SearchPanel/SearchPanel';

const ManageSearchPanel = (props: any) => {
  return (
    <div>
      <div className={styles.searchPanel}>
        <SearchPanel
          title={props.title}
          titleType={props.titleType}
          titleSize={props.titleSize}
          addButtonLabel={props.addButtonLabel}
          addButtonColor={props.addButtonColor}
          addButtonIcon={props.addButtonIcon}
          subTitle={props.subTitle}
          subTitleType={props.subTitleType}
          subTitleSize={props.subTitleSize}
          searchBoxPlaceholder={props.searchBoxPlaceholder}
          searchBoxSearchIcon={props.searchBoxSearchIcon}
          onSearchHandler={props.onSearchHandler}
          onAddUserHandler={props.onAddUserHandler}
          collapseTitle={props.collapseTitle}
          collapseOpenTitle={props.collapseOpenTitle}
          collapseFooterTitle={props.collapseFooterTitle}
          clearSearch={props.clearSearch}
          searchButtonLabel={props.searchButtonLabel}
          searchButtonColor={props.searchButtonColor}
          onClearSearch={props.onClearSearch}
          onAdvancedSearchHandler={props.onAdvancedSearchHandler}
          initialOpenState={props.initialOpenState}
          basicSearchValue={props.basicSearchValue}
          onBasicSearchValueChange={props.onBasicSearchValueChange}
        >
          {props.children}
        </SearchPanel>
      </div>
    </div>
  );
};

export default ManageSearchPanel;
