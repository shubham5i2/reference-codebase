import React from 'react';
import styles from './ManageSearchResults.module.scss';
import ManageUsersGrid from '../../../Organisms/ManageUsersGrid/ManageUsersGrid';

const ManageSearchResults = (props: any) => {
  return (
    <div className={styles.searchResults}>
      <ManageUsersGrid {...props} />
    </div>
  );
};

export default ManageSearchResults;
