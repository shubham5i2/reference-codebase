import React from 'react';
import styles from './ReviewProfile.module.scss';
import { dateFormatter, getUserStatusDictonary, statusStyle } from '../../utils/utilities';
import cx from 'classnames';
import UI from 'ielts-cmds-ui-component-library';
import { languageService } from '../../../services/Language/LanguageService';
import { AssignGroupData } from '../../../services/Models/StaffManagement';
import { UserDataSource } from '../../../services/Models/UIModels';

const smLabels = languageService().staffManagement;

interface ReviewProfileProps {
  title: string;
  userGrpTitle: string;
  userGrp: AssignGroupData[];
  perData: UserDataSource[];
}

const ReviewProfile = (props: ReviewProfileProps) => {
  return (
    <div className={styles.RPContainer}>
      <div className={styles.RPSection}>
        <div className={styles.RPpersonalInfo}>
          <h2 id="reviewProfile_title">{props.title}</h2>
          <div className={styles.col3}>
            {props.perData.map((result: UserDataSource, index: number) => {
              return (
                <div key={result.value}>
                  <div className={styles.labelText} id={`RP_personalInfo_title_${index}`}>
                    {result.title}
                  </div>
                  <div className={styles.labelValue}>
                    {result.isStatus ? (
                      <span id={`RP_personalInfo_value_${index}`}>
                        <UI.Status status={statusStyle[result.value]} label={getUserStatusDictonary()[result.value]} />
                      </span>
                    ) : (
                      <span className={styles.labelItem} id={`RP_personalInfo_value_${index}`}>
                        {result.value || '-'}
                      </span>
                    )}
                    {result.verify ? (
                      <div
                        className={cx(
                          styles.RPstatus,
                          `${result.verify === 'Verified' ? styles.RPverified : styles.RPnotVerified}`,
                        )}
                      >
                        <span className={styles.verifyLabel} id={`verifyLabel_${index}`}>
                          {result.verify}
                        </span>
                      </div>
                    ) : (
                      ''
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        <div className={styles.RPuserInfo}>
          <h2 id="RP_userGroup">{props.userGrpTitle}</h2>
          <div className={styles.row}>
            {props.userGrp.map((result: AssignGroupData, index: number) => {
              return (
                <React.Fragment key={result.userId}>
                  {props.userGrp.length > 1 ? (
                    <div className={styles.reviewHeader} id={`RP_Assignment_title_${index + 1}`}>
                      {smLabels.assignment.toUpperCase()} {index + 1}
                    </div>
                  ) : (
                    ''
                  )}
                  <>
                    <div className={styles.cols} key={index}>
                      <p className={styles.labelText} id={`RP_Usergroup_title_${index + 1}`}>
                        {smLabels.userGroup}
                      </p>
                      <p className={styles.labelValue} id={`RP_Usergroup_data_${index + 1}`}>
                        {result.userGroupName}
                      </p>
                    </div>
                    <div className={styles.cols} key={index}>
                      <p className={styles.labelText} id={`RP_Duration_${index + 1}`}>
                        {smLabels.duration}
                      </p>
                      <p className={styles.labelValue} id={`RP_Duration_data_${index + 1}`}>{`${dateFormatter(
                        result.dateRange.startDate,
                      )} - ${dateFormatter(result.dateRange.endDate)}`}</p>
                    </div>
                    <div className={styles.fullWidth}>
                      <p className={styles.greyTitle} id={`RP_Location_${index + 1}`}>
                        {smLabels.location}
                      </p>
                      <div className={styles.cols} key={index}>
                        <p className={styles.labelValue} id={`RP_testCenter_data_${index + 1}`}>
                          {result.locationName}
                        </p>
                      </div>
                    </div>
                  </>
                </React.Fragment>
              );
            })}
          </div>
        </div>
        <div></div>
      </div>
    </div>
  );
};

export default ReviewProfile;
