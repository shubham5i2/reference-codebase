import React from 'react';
import styles from './ProfileHeaderComponent.module.scss';

import UI from 'ielts-cmds-ui-component-library';

interface ProfileIconsProps {
  tag: string;
  name: string;
  class: string;
}

export interface ProfileHeaderComponentProps {
  user: { firstName: string; lastName: string };
  onclick: (icon: ProfileIconsProps) => void;
  status: string;
  actionElements: ProfileIconsProps[];
}

const getRandomIdx = (max: number) => {
  const array = new Uint32Array(1);
  window.crypto.getRandomValues(array);
  return array[0] % max;
};

const ProfileHeaderComponent = (props: ProfileHeaderComponentProps) => {
  const { user, onclick, actionElements } = props;
  const getStatus = () => {
    return props.status.toLowerCase() === 'active' ? 'active' : 'inActive';
  };

  const getProfileIcons = (icon: ProfileIconsProps) => {
    return (
      <div key={icon.tag} className={` ${styles.phIconElement} ${styles[icon.class]}`} onClick={() => onclick(icon)}>
        <UI.Icon icon={icon.name} />
        <span>{icon.tag}</span>
      </div>
    );
  };

  const profileColors = ['blue', 'skyBlue', 'green', 'orange'];
  const randomIdx = getRandomIdx(profileColors.length);

  const getColor = () => profileColors[randomIdx];

  return (
    <React.Fragment>
      <div className={styles.phComponent}>
        <div className={styles.phThumbnail}>
          <UI.Avatar title={user} color={getColor()} size={'big'} />
        </div>

        <div className={styles.phName}>
          <UI.Typography type="normal" label={`${user.firstName} ${user.lastName}`} size={28} />
          <div>
            <UI.Status status={getStatus()} label={props.status} theme="none" />
          </div>
        </div>
      </div>
      <div className={styles.phIcons}>
        {actionElements.map((icon: ProfileIconsProps) => {
          return getProfileIcons(icon);
        })}
      </div>
    </React.Fragment>
  );
};

export default ProfileHeaderComponent;
