import React from 'react';
import styles from './OrganisationDetailsHeader.module.scss';
import { languageService } from '../../../services/Language/LanguageService';
import { OrganisationProfileData } from '../../../services/Models/Organisation';
import { getVerificationStatus } from '../../../components/utils/utilities';

interface OrganisationHeaderProps {
  headerData: OrganisationProfileData;
  onHeaderActionHandler?: (selectedAction: string) => void;
}

const OrganisationDetailsHeader = (props: OrganisationHeaderProps) => {
  const { onHeaderActionHandler } = props;
  const organisationLabels = languageService().organisation;
  const organisationStatus =
    props.headerData?.organisationStatus === true ? organisationLabels.active : organisationLabels.inActive;
  const verificationStatus = getVerificationStatus(props.headerData?.verificationStatus);
  const statusClassName = organisationStatus?.toLowerCase() || '';
  const verificationClassName = verificationStatus?.toLowerCase() || '';
  return (
    <div className={styles.ODH_Container}>
      <div className={styles.ODH_Title_Container}>
        <div className={styles.ODH_Title} id="header_Title">
          {props.headerData?.organisationName}
        </div>
        {onHeaderActionHandler && (
          <div className={styles.ODH_Actions_Container}>
            <div id="Actions_Update" onClick={() => onHeaderActionHandler('Update')}>
              <span className={styles.ODH_Actions_Update}></span>Update
            </div>
          </div>
        )}
      </div>
      <div className={styles.ODH_Data_Container}>
        <div className={styles.ODH_Data_Wrapper}>
          <div className={styles.ODH_Data_Title} id="orgId_Title">
            {organisationLabels.orgID}
          </div>
          <div className={styles.ODH_Data_Content} id="orgID_Data">
            {props.headerData?.organisationId}
          </div>
        </div>
        <div className={styles.ODH_Data_Wrapper}>
          <div className={styles.ODH_Data_Title} id="orgType_Title">
            {organisationLabels.organisationType}
          </div>
          <div className={styles.ODH_Data_Content} id="orgType_Data">
            {props.headerData?.organisationType?.text}
          </div>
        </div>
        <div className={styles.ODH_Data_Wrapper}>
          <div className={styles.ODH_Data_Title} id="verify_Title">
            {organisationLabels.verificationStatus}
          </div>
          <div
            className={`${styles.ODH_Data_Content} ${styles.verificationStatus} ${styles[verificationClassName]}`}
            id="verify_Data"
          >
            {verificationStatus}
          </div>
        </div>
        <div className={styles.ODH_Data_Wrapper}>
          <div className={styles.ODH_Data_Title} id="active_Title">
            {organisationLabels.organisationStatus}
          </div>
          <div className={styles.ODH_Data_Content} id="active_Data">
            <span className={`${styles.statusCircle} ${styles[statusClassName + 'StatusCircle']}`}></span>
            {organisationStatus}
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrganisationDetailsHeader;
