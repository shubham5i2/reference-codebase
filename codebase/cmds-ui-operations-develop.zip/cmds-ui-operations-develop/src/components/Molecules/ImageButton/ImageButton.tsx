import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import styles from './ImageButton.module.scss';
import { UITypography } from '../../../services/Models/UIModels';

interface ImageButtonProps {
  id: string;
  label: string;
  labelSize: number;
  icon: string;
  labelType: UITypography;
  buttonStyle?: string;
  onClickHandler: () => void;
}

const ImageButton = (props: ImageButtonProps) => {
  const { id, label, icon, labelType, labelSize, onClickHandler } = props;
  return (
    <span onClick={onClickHandler} id={id} className={props.buttonStyle ? props.buttonStyle : styles.imageButton}>
      <UI.Icon icon={icon} />
      <UI.Typography type={labelType} id={props.id + 'Label'} label={label} size={labelSize} />
    </span>
  );
};

export default ImageButton;
