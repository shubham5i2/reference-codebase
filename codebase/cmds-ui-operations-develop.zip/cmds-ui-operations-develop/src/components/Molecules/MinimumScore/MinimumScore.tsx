import React, { useState } from 'react';
import styles from './MinimumScore.module.scss';
import cx from 'classnames';

// : This component needs to be refactored
const MinimumScore = (props: any) => {
  const [selected, setSelected] = useState(props.selected || 0);

  const handleChange = (index: any) => {
    setSelected(index);
    props.onTabIndexChange && props.onTabIndexChange(index);
  };
  return (
    <div className={cx(styles.orgDetailContainer, props.tabContainerStyle)}>
      <div className={styles.orgTitleContainer}>
        <div className={styles.OrgDetailTitle} id="minimum_score_title">
          {props.title}
        </div>
        <div className={styles.orgDetailDownArrowBlocked}></div>
      </div>

      <div className={styles.orgDetailInfo}>
        <span className={styles.orgDetailSubTitle} id="mst_title">
          Product
        </span>
        <div className={styles.orgDetailInfoWrapper}>
          <div className={cx(styles.orgDetailInfoContainer, props.panelHolderStyle)}>
            <ul className={styles.inline}>
              {props.children?.map((elem: { props: { title: string } }, index: number) => {
                const style = index === selected ? styles.selected : '';
                return (
                  <li
                    id={`mst_product_title_${index}`}
                    className={style + ' ' + styles.orgDetailInfoTitle}
                    onClick={() => handleChange(index)}
                    key={index}
                  >
                    {elem.props.title}
                  </li>
                );
              })}
            </ul>
            <div>{props.children?.[selected]}</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MinimumScore;
