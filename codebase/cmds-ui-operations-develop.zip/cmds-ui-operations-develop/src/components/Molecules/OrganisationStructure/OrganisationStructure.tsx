import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import styles from '../OrganisationDetails/OrganisationDetails.module.scss';
import { languageService } from '../../../services/Language/LanguageService';
import { LinkedOrganisationsResponse, OrganisationType } from '../../../services/Models/Organisation';
import { DropDownDataSource } from '../../../services/Models/UIModels';
import { getValue } from '../../utils/utilities';

const organisationLabels = languageService().organisation;

interface OrganisationLinkButtonProps {
  id: string;
  list: LinkedOrganisationsResponse[] | DropDownDataSource[];
  onButtonClickHandler: () => void;
  buttonText: string;
  title: string;
  onLinkClickHandler: (selectedOrg: string) => void;
}

const OrganisationLinkButton = (props: OrganisationLinkButtonProps) => {
  const { id, list, onButtonClickHandler, buttonText, title, onLinkClickHandler } = props;

  const onLinkHandler = () => {
    const selectedChildOrg = list?.[0] as DropDownDataSource;
    const selectedParentOrg = list?.[0] as LinkedOrganisationsResponse;
    if (selectedChildOrg?.value) {
      onLinkClickHandler(getValue(selectedChildOrg.value));
    } else if (selectedParentOrg) {
      onLinkClickHandler(getValue(selectedParentOrg.targetRecognisingOrganisationUuid));
    }
  };

  const getLinkText = () => {
    const selectedChildOrg = list?.[0] as DropDownDataSource;
    const selectedParentOrg = list?.[0] as LinkedOrganisationsResponse;
    if (selectedChildOrg?.value) {
      return getValue(selectedChildOrg.text);
    } else if (selectedParentOrg) {
      return getValue(selectedParentOrg.targetRecognisingOrganisationName);
    }
  };
  return (
    <div className={styles.orgDetailInfoContainer}>
      <div>
        <span className={styles.orgDetailInfoTitle} id={`${id}Button`}>
          {list.length > 1 || list.length === 0 ? title + 's' : title}
        </span>
        <span className={styles.linkContainer}>
          {list.length > 1 ? (
            <UI.Button label={buttonText} onChange={onButtonClickHandler} color="blueLine" id={`${id}Button`} />
          ) : (
            <span
              className={`${styles.orgDetailInfoData} ${styles.link}`}
              id={`${id}Link`}
              onClick={() => onLinkHandler()}
            >
              <span className={styles.link}>{getLinkText()}</span>
            </span>
          )}
        </span>
      </div>
    </div>
  );
};

interface OrganisationStructureProps {
  onParentClicked: () => void;
  onAdditionalDeliveryButtonClick: () => void;
  onChildButtonClick: () => void;
  parentName: string;
  additionalDeliveryOrganisations: LinkedOrganisationsResponse[];
  childOrganisations: DropDownDataSource[];
  onAdditionalDeliveryLinkClicked: (selectedOrg: string) => void;
  onChildLinkClick: (selectedOrg: string) => void;
  orgType: OrganisationType;
}

const OrganisationStructure = (props: OrganisationStructureProps) => {
  const {
    orgType,
    onParentClicked,
    parentName,
    onAdditionalDeliveryButtonClick,
    onChildButtonClick,
    childOrganisations,
    additionalDeliveryOrganisations,
    onAdditionalDeliveryLinkClicked,
    onChildLinkClick,
  } = props;
  return (
    <>
      <div className={styles.orgDetailInfoContainer}>
        <span className={styles.orgDetailInfoTitle} id="mainAddressParentOrganisationIdTitle">
          {organisationLabels.parentOrganisation}
        </span>
        <span
          className={`${styles.orgDetailInfoData} ${styles.link}`}
          id="mainAddressParentOrganisationIdData"
          onClick={onParentClicked}
        >
          {parentName}
        </span>
      </div>
      <OrganisationLinkButton
        id="childOrganisations"
        list={childOrganisations}
        buttonText={organisationLabels.viewChildOrganisations}
        title={organisationLabels.childOrganisation}
        onButtonClickHandler={onChildButtonClick}
        onLinkClickHandler={onChildLinkClick}
      />
      {/* ADO applicable only for VO  */}
      {orgType === OrganisationType.RO && (
        <OrganisationLinkButton
          id="additionalDeliveryOrganisations"
          list={additionalDeliveryOrganisations}
          buttonText={organisationLabels.viewAdditionalDeliveryOrganisations}
          title={organisationLabels.additionalDeliveryOrganisations}
          onButtonClickHandler={onAdditionalDeliveryButtonClick}
          onLinkClickHandler={onAdditionalDeliveryLinkClicked}
        />
      )}
    </>
  );
};

export default OrganisationStructure;
