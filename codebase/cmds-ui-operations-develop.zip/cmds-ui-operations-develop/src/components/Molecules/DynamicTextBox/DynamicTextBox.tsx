import React, { useState, SyntheticEvent, useEffect } from 'react';
import styles from './DynamicTextBox.module.scss';
import UI from 'ielts-cmds-ui-component-library';
import Add from '../../../assets/images/Add.svg';
import Remove from '../../../assets/images/Close.svg';

export interface DynamicTextElement {
  id?: string;
  text: string;
}

interface DynamicTextBoxProps {
  value?: DynamicTextElement[];
  label: string;
  name: string;
  maxCount: number;
  onChange: (changedList: DynamicTextElement[], name: string) => void;
  placeholder?: string;
}

const initialList = [{ text: '' }];
const DynamicTextBox = (props: DynamicTextBoxProps) => {
  const [dynamicValue, setDynamicValue] = useState<DynamicTextElement[]>(initialList);

  useEffect(() => {
    setDynamicValue(props.value || initialList);
  }, [props.value]);

  const handleDynamicNameChange = (index: number) => (evt: SyntheticEvent) => {
    const inputTarget = evt.target as HTMLInputElement;
    const newDynamicValues = dynamicValue.map((value: DynamicTextElement, currentIndex: number) => {
      if (index !== currentIndex) return value;
      return { text: inputTarget.value, id: value.id };
    });
    setDynamicValue(newDynamicValues);
    props.onChange(newDynamicValues, props.name);
  };

  const onAddHandler = () => {
    const lastItem = dynamicValue[dynamicValue.length - 1];
    if (lastItem.text !== '') {
      setDynamicValue(dynamicValue.concat(initialList));
    }
  };

  const onRemoveHandler = (currentIndex: number) => {
    setDynamicValue(dynamicValue.filter((_: DynamicTextElement, index: number) => currentIndex !== index));
  };

  return (
    <div className={styles.col3}>
      {dynamicValue.map((val: DynamicTextElement, index: number) => (
        <div key={props.name + '' + (index + 1)} className={styles.textBoxComponent}>
          <div id={props.name + '' + (index + 1)} className={styles.textBoxLabel}>
            {props.label}
          </div>
          <div className={styles.textBox}>
            <div className={styles.textBoxGroup}>
              <input
                type="text"
                maxLength={255}
                name={props.name + '' + (index + 1)}
                id={props.name + '' + (index + 1)}
                autoComplete="off"
                className={styles.textBoxInput}
                value={val.text}
                placeholder={props.placeholder || ''}
                onChange={handleDynamicNameChange(index)}
              />
              {dynamicValue.length === index + 1 &&
              dynamicValue.length < props.maxCount &&
              dynamicValue[index].text?.length > 0 ? (
                <span className={styles.addIcon} id={'addIcon' + (index + 1)} onClick={() => onAddHandler()}>
                  <UI.Icon icon={Add} />
                </span>
              ) : (
                ''
              )}
              {dynamicValue.length !== index + 1 || (dynamicValue.length === props.maxCount && props.maxCount > 1) ? (
                <span
                  className={styles.removeIcon}
                  id={'removeIcon' + (index + 1)}
                  onClick={() => onRemoveHandler(index)}
                >
                  <UI.Icon icon={Remove} />
                </span>
              ) : (
                ''
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
export default DynamicTextBox;
