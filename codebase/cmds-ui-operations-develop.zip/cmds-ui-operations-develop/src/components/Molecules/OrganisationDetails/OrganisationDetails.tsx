import React, { useState } from 'react';
import styles from './OrganisationDetails.module.scss';
import { languageService } from '../../../services/Language/LanguageService';
import {
  OrganisationProfileData,
  LinkType,
  LinkedOrganisationsResponse,
  OrganisationType,
} from '../../../services/Models/Organisation';
import { joinAddress, getValue } from '../../../components/utils/utilities';
import ViewOrganisationsListModal from '../../Others/ViewOrganisationsListModal/ViewOrganisationsListModal';
import OrganisationDetailsModal from '../../Pages/OrganisationDetailsModal/OrganisationDetailsModal';
import OrganisationStructure from '../OrganisationStructure/OrganisationStructure';
import { DropDownDataSource } from '../../../services/Models/UIModels';

enum OrganisationModalType {
  DELIVERY_ORG = 'deliveryOrg',
  CHILD_ORG = 'childOrg',
}

interface OrganisationDetailsProps {
  organisationDetail: OrganisationProfileData;
  directChildren: DropDownDataSource[];
  onParentChange?: (parentOrgID: string) => void;
}

const OrganisationDetails = (props: OrganisationDetailsProps) => {
  const [viewOrganisationModalType, setViewOrganisationModalType] = useState('');
  const [selectedOrg, setSelectedOrg] = useState('');
  const organisationLabels = languageService().organisation;
  const commonLabels = languageService().common;
  const mainAddress = joinAddress(props.organisationDetail?.mainAddress);
  const deliveryAddress = joinAddress(props.organisationDetail?.deliveryAddress);
  const alternateNames =
    props.organisationDetail?.alternateNames
      ?.map(function (elem: { name: string }) {
        return elem.name;
      })
      .filter(Boolean)
      .join(', ') || '';

  const parentOrganisation = props.organisationDetail?.linkedOrganisations?.find(
    (org) => org.linkType === LinkType.parentRo,
  );
  const additionalDeliveryOrganisations =
    props.organisationDetail?.linkedOrganisations?.filter((org) => org.linkType === LinkType.resultsDelivery) || [];

  const onCloseHandler = () => {
    setViewOrganisationModalType('');
  };

  const getViewOrganisationsListModal = () => {
    const additionalDeliveryOrgSortedList = additionalDeliveryOrganisations.sort(
      (a: LinkedOrganisationsResponse, b: LinkedOrganisationsResponse) => {
        return getValue(a.targetRecognisingOrganisationName).localeCompare(
          getValue(b.targetRecognisingOrganisationName),
        );
      },
    );

    const modalProps =
      viewOrganisationModalType === OrganisationModalType.DELIVERY_ORG
        ? {
            headerText: organisationLabels.additionalDeliveryModalTitle,
            titleText: organisationLabels.additionalDeliveryModalSubTitle,
            organisationList: additionalDeliveryOrgSortedList.map((org) => ({
              value: getValue(org.targetRecognisingOrganisationUuid),
              text: getValue(org.targetRecognisingOrganisationName),
            })),
          }
        : {
            headerText: organisationLabels.childOrganisationModalTitle,
            titleText: organisationLabels.childOrganisationModalSubTitle,
            organisationList: props.directChildren,
          };
    return viewOrganisationModalType ? (
      <ViewOrganisationsListModal
        deliveryOrgSelectionHandler={(org) => setSelectedOrg(getValue(org))}
        closeHandler={onCloseHandler}
        {...modalProps}
      />
    ) : null;
  };

  const getOrganisationDetailModal = () => {
    return (
      selectedOrg && <OrganisationDetailsModal parentOrgId={selectedOrg} onDialogClose={() => setSelectedOrg('')} />
    );
  };

  const onParentClicked = () => {
    if (props.onParentChange) {
      props.onParentChange(getValue(parentOrganisation?.targetRecognisingOrganisationUuid));
    } else {
      setSelectedOrg(getValue(parentOrganisation?.targetRecognisingOrganisationUuid));
    }
  };

  return (
    <div className={styles.orgDetailContainer}>
      {getViewOrganisationsListModal()}
      {getOrganisationDetailModal()}
      <div className={styles.orgDetailTitleContainer}>
        <div className={styles.OrgDetailTitle} id="organisation_detail_title">
          {organisationLabels.organisationDetails}
        </div>
        <div className={styles.orgDetailDownArrowBlocked}></div>
      </div>

      <div className={styles.orgDetailInfo}>
        <div className={styles.orgDetailInfoWrapper}>
          <div className={styles.orgDetailInfoContainer}>
            <span className={styles.orgDetailInfoTitle} id="orgName">
              {organisationLabels.organisationName}
            </span>
            <span className={styles.orgDetailInfoData} id="orgNameData">
              {props.organisationDetail?.organisationName}
            </span>
          </div>
        </div>
        {props.organisationDetail?.organisationType.value === OrganisationType.RO ||
        props.organisationDetail?.organisationType.value === OrganisationType.VO ? (
          <div className={styles.organisationStructureContainer}>
            <span className={styles.orgDetailSubTitle} id="organisationStructureTitle">
              {organisationLabels.organisationStructure}
            </span>
            <div className={styles.orgDetailInfoWrapper} id="organisationStructureData">
              <OrganisationStructure
                orgType={props.organisationDetail?.organisationType.value}
                onParentClicked={onParentClicked}
                parentName={getValue(parentOrganisation?.targetRecognisingOrganisationName)}
                onAdditionalDeliveryButtonClick={() => setViewOrganisationModalType(OrganisationModalType.DELIVERY_ORG)}
                onChildButtonClick={() => setViewOrganisationModalType(OrganisationModalType.CHILD_ORG)}
                childOrganisations={props.directChildren}
                additionalDeliveryOrganisations={additionalDeliveryOrganisations}
                onAdditionalDeliveryLinkClicked={setSelectedOrg}
                onChildLinkClick={setSelectedOrg}
              />
            </div>
          </div>
        ) : null}
        <span className={styles.orgDetailSubTitle} id="mainInfoTitle">
          {organisationLabels.mainAddress}
        </span>
        <div className={styles.orgDetailInfoWrapper}>
          <div className={styles.orgDetailInfoContainer}>
            <span className={styles.orgDetailInfoTitle} id="mainAddressTitle">
              {organisationLabels.address}
            </span>
            <span className={styles.orgDetailInfoData} id="mainAddressData">
              {mainAddress}
            </span>
          </div>
          <div className={styles.orgDetailInfoContainer}>
            <span className={styles.orgDetailInfoTitle} id="mainAddressCityTitle">
              {organisationLabels.city}
            </span>
            <span className={styles.orgDetailInfoData} id="mainAddressCityData">
              {props.organisationDetail?.mainAddress?.city}
            </span>
          </div>
          <div className={styles.orgDetailInfoContainer}>
            <span className={styles.orgDetailInfoTitle} id="mainAddressPostTitle">
              {organisationLabels.postCode}
            </span>
            <span className={styles.orgDetailInfoData} id="mainAddressPostData">
              {props.organisationDetail?.mainAddress?.postalCode}
            </span>
          </div>
          <div className={styles.orgDetailInfoContainer}>
            <span className={styles.orgDetailInfoTitle} id="mainAddressRegionTitle">
              {organisationLabels.regionTerritory}
            </span>
            <span className={styles.orgDetailInfoData} id="mainAddressRegionData">
              {props.organisationDetail?.mainAddress?.region?.text}
            </span>
          </div>
          <div className={styles.orgDetailInfoContainer}>
            <span className={styles.orgDetailInfoTitle} id="mainAddressCountryTitle">
              {organisationLabels.countryLabel}
            </span>
            <span className={styles.orgDetailInfoData} id="mainAddressCountryData">
              {props.organisationDetail?.mainAddress?.country?.text}
            </span>
          </div>
          <div className={styles.orgDetailInfoContainer}>
            <span className={styles.orgDetailInfoTitle} id="mainAddressEmailTitle">
              {organisationLabels.emailLabel}
            </span>
            <span className={styles.orgDetailInfoData} id="mainAddressEmailData">
              {props.organisationDetail?.mainAddress?.emailAddress}
            </span>
          </div>
          <div className={styles.orgDetailInfoContainer}>
            <span className={styles.orgDetailInfoTitle} id="mainAddressPhoneTitle">
              {organisationLabels.telephoneLabel}
            </span>
            <span className={styles.orgDetailInfoData} id="mainAddressPhoneData">
              {props.organisationDetail?.mainAddress?.phoneNumber}
            </span>
          </div>
        </div>

        <span className={styles.orgDetailSubTitle} id="deliveryInfo">
          {organisationLabels.deliveryAddressLabel}
        </span>
        <div className={styles.orgDetailInfoWrapper}>
          <div className={styles.orgDetailInfoContainer}>
            <span className={styles.orgDetailInfoTitle} id="deliveryAddressTitle">
              {organisationLabels.address}
            </span>
            <span className={styles.orgDetailInfoData} id="deliveryAddressData">
              {deliveryAddress}
            </span>
          </div>
          <div className={styles.orgDetailInfoContainer}>
            <span className={styles.orgDetailInfoTitle} id="deliveryAddressCityTitle">
              {organisationLabels.cityTownLabel}
            </span>
            <span className={styles.orgDetailInfoData} id="deliveryAddressCityData">
              {props.organisationDetail?.deliveryAddress?.city}
            </span>
          </div>
          <div className={styles.orgDetailInfoContainer}>
            <span className={styles.orgDetailInfoTitle} id="deliveryAddressPostTitle">
              {organisationLabels.postCode}
            </span>
            <span className={styles.orgDetailInfoData} id="deliveryAddressPostData">
              {props.organisationDetail?.deliveryAddress?.postalCode}
            </span>
          </div>
          <div className={styles.orgDetailInfoContainer}>
            <span className={styles.orgDetailInfoTitle} id="deliveryAddressRegionTitle">
              {organisationLabels.regionTerritory}
            </span>
            <span className={styles.orgDetailInfoData} id="deliveryAddressRegionData">
              {props.organisationDetail?.deliveryAddress?.region?.text}
            </span>
          </div>
          <div className={styles.orgDetailInfoContainer}>
            <span className={styles.orgDetailInfoTitle} id="deliveryAddressCountryTitle">
              {organisationLabels.countryLabel}
            </span>
            <span className={styles.orgDetailInfoData} id="deliveryAddressCountryData">
              {props.organisationDetail?.deliveryAddress?.country?.text}
            </span>
          </div>
          <div className={styles.orgDetailInfoContainer}>
            <span className={styles.orgDetailInfoTitle} id="deliveryAddressEmailTitle">
              {organisationLabels.emailLabel}
            </span>
            <span className={styles.orgDetailInfoData} id="deliveryAddressEmailData">
              {props.organisationDetail?.deliveryAddress?.emailAddress}
            </span>
          </div>
          <div className={styles.orgDetailInfoContainer}>
            <span className={styles.orgDetailInfoTitle} id="deliveryAddressPhoneTitle">
              {organisationLabels.telephoneLabel}
            </span>
            <span className={styles.orgDetailInfoData} id="deliveryAddressPhoneData">
              {props.organisationDetail?.deliveryAddress?.phoneNumber}
            </span>
          </div>
        </div>

        <div>
          <span className={styles.orgDetailSubTitle} id="otherInfoTitle">
            {organisationLabels.otherInformation}
          </span>
          <div className={styles.orgDetailInfoWrapper}>
            <div className={styles.orgDetailInfoContainer}>
              <span className={styles.orgDetailInfoTitle} id="otherInfo_lead">
                {organisationLabels.partnerLeadLabel}
              </span>
              <span className={styles.orgDetailInfoData} id="otherInfo_lead_data">
                {props.organisationDetail?.partnerLead?.text}
              </span>
            </div>
            <div className={styles.orgDetailInfoContainer}>
              <span className={styles.orgDetailInfoTitle} id="otherInfo_contact">
                {organisationLabels.patnerContactLabel}
              </span>
              <span className={styles.orgDetailInfoData} id="otherInfo_contact_data">
                {props.organisationDetail?.partnerContact}
              </span>
            </div>
            <div className={styles.orgDetailInfoContainer}>
              <span className={styles.orgDetailInfoTitle} id="otherInfo_delivery">
                {organisationLabels.methodOfDeliveryLabel}
              </span>
              <span className={styles.orgDetailInfoData} id="otherInfo_delivery_data">
                {props.organisationDetail?.methodOfDelivery?.text}
              </span>
            </div>
            <div className={styles.orgDetailInfoContainer}>
              <span className={styles.orgDetailInfoTitle} id="otherInfo_sector">
                {organisationLabels.sectorLabelOrgDetail}
              </span>
              <span className={styles.orgDetailInfoData} id="otherInfo_sector_data">
                {props.organisationDetail?.sectorType?.text}
              </span>
            </div>
            <div className={styles.orgDetailInfoContainer}>
              <span className={styles.orgDetailInfoTitle} id="otherInfo_website">
                {organisationLabels.websiteURLLabel}
              </span>
              <span
                className={`${styles.orgDetailInfoData} ${styles.link}`}
                id="otherInfo_website_data"
                onClick={() => props.organisationDetail?.websiteUrl && window.open(props.organisationDetail.websiteUrl)}
              >
                {props.organisationDetail?.websiteUrl}
              </span>
            </div>
            <div className={styles.orgDetailInfoContainer}>
              <span className={styles.orgDetailInfoTitle} id="otherInfo_crm_system">
                {organisationLabels.crmSystem}
              </span>
              <span className={styles.orgDetailInfoData} id="otherInfo_crm_system_data">
                {props.organisationDetail?.crmSystem}
              </span>
            </div>
            <div className={styles.orgDetailInfoContainer}>
              <span className={styles.orgDetailInfoTitle} id="otherInfo_code">
                {organisationLabels.codeLabel}
              </span>
              <span className={styles.orgDetailInfoData} id="otherInfo_code_data">
                {props.organisationDetail?.code}
              </span>
            </div>
            <div className={styles.orgDetailInfoContainer}>
              <span className={styles.orgDetailInfoTitle} id="otherInfo_AC">
                {'Accepts AC'}
              </span>
              <span className={styles.orgDetailInfoData} id="otherInfo_GT_data">
                {props.organisationDetail?.acceptAC === true ? commonLabels.yes : commonLabels.no}
              </span>
            </div>
            <div className={styles.orgDetailInfoContainer}>
              <span className={styles.orgDetailInfoTitle} id="otherInfo_GT">
                {'Accepts GT'}
              </span>
              <span className={styles.orgDetailInfoData} id="otherInfo_GT_data">
                {props.organisationDetail?.acceptGT === true ? commonLabels.yes : commonLabels.no}
              </span>
            </div>
            <div className={styles.orgDetailInfoContainer}>
              <span className={styles.orgDetailInfoTitle} id="otherInfo_iol">
                {organisationLabels.acceptIolLabel}
              </span>
              <span className={styles.orgDetailInfoData} id="otherInfo_iol_data">
                {props.organisationDetail?.acceptIOL === true ? commonLabels.yes : commonLabels.no}
              </span>
            </div>
            <div className={styles.orgDetailInfoContainer}>
              <span className={styles.orgDetailInfoTitle} id="otherInfo_ors">
                {organisationLabels.orsDisplayFlagLabel}
              </span>
              <span className={styles.orgDetailInfoData} id="otherInfo_ors_data">
                {props.organisationDetail?.orsDisplayFlag === true ? commonLabels.yes : commonLabels.no}
              </span>
            </div>
            <div className={styles.orgDetailInfoContainer}>
              <span className={styles.orgDetailInfoTitle} id="otherInfo_visible_ieltsorg">
                {organisationLabels.ieltsDisplayFlagLabel}
              </span>
              <span className={styles.orgDetailInfoData} id="otherInfo_visible_ieltsorg_data">
                {props.organisationDetail?.ieltsDisplayFlag === true ? commonLabels.yes : commonLabels.no}
              </span>
            </div>
            <div className={styles.orgDetailInfoContainer}>
              <span className={styles.orgDetailInfoTitle} id="otherInfo_ssr">
                {organisationLabels.acceptSSRLabel}
              </span>
              <span className={styles.orgDetailInfoData} id="otherInfo_ssr_data">
                {props.organisationDetail?.acceptSSR === true ? commonLabels.yes : commonLabels.no}
              </span>
            </div>

            {/* <div className={styles.orgDetailInfoContainer}>
              <span className={styles.orgDetailInfoTitle} id="otherInfo_replaceId">
                {organisationLabels.replacedByID}
              </span>
              <span className={styles.orgDetailInfoData} id="otherInfo_replaceId_data">
                {props.organisationDetail?.replaceById}
              </span>
            </div> */}
            <div className={styles.orgDetailInfoContainer}>
              <span className={styles.orgDetailInfoTitle} id="resultAvailableForYears">
                {organisationLabels.resultAvailableForYearsLabel}
              </span>
              <span className={styles.orgDetailInfoData} id="resultAvailableForYears_data">
                {props.organisationDetail?.resultAvailableForYears?.value}
              </span>
            </div>
          </div>
        </div>
        <div className={styles.orgDetailInfoContainer}>
          <span className={styles.orgDetailInfoTitle} id="otherInfo_alternateName">
            {organisationLabels.alternateNameLabel}
          </span>
          <span className={styles.orgDetailInfoData} id="otherInfo_alternateName_data">
            {alternateNames}
          </span>
        </div>
        <div className={styles.orgDetailNotesContainer}>
          <div className={styles.orgDetailInfoTitle} id="notes">
            {organisationLabels.notesLabel}
          </div>
          <div className={styles.orgDetailInfoData} id="notes_data">
            {props.organisationDetail?.notes?.[0]?.noteContent}
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrganisationDetails;
