import React from 'react';
import styles from './NoResultsFound.module.scss';
import UI from 'ielts-cmds-ui-component-library';
import Search from '../../../assets/images/Search.svg';
import { languageService } from '../../../services/Language/LanguageService';

interface NoResultsFoundProps {
  title?: string;
  description?: string;
}

const NoResultsFound = (props: NoResultsFoundProps) => {
  const labels = languageService().organisation;
  return (
    <div className={styles.noResultsFound}>
      <div className={styles.searchIcon}>
        <UI.Icon icon={Search} />
      </div>
      <div className={styles.mt10}>
        <UI.Typography
          type="bold"
          id="noResultsFoundTitle"
          label={props.title || labels.noResultsFoundTitle}
          size={24}
        />
      </div>
      <div className={styles.mt10}>
        <UI.Typography
          type="normal"
          id="noResultsFoundDescription"
          label={props.description || labels.noResultsFoundDesp}
          size={16}
        />
      </div>
    </div>
  );
};
export default NoResultsFound;
