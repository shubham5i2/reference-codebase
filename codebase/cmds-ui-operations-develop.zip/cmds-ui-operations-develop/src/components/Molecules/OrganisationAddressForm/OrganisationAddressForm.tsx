import React, { SyntheticEvent, useRef } from 'react';
import styles from './OrganisationAddressForm.module.scss';
import UI from 'ielts-cmds-ui-component-library';
import cx from 'classnames';
import { languageService } from '../../../services/Language/LanguageService';
import { getCountryISOCode, getNestedProperty, useEffectUpdate } from '../../utils/utilities';
import { OrganisationFromData, OrganisationAddressData } from '../../../services/Models/Organisation';
import { Dictionary, DropDownDataSource } from '../../../services/Models/UIModels';
import { initialDropDownDataSource } from '../../Templates/Organisation/OrganisationConstants';
import withServiceRequest, { ServiceRequest } from '../../../services/utils/ServiceRequest';
import TerritoryDropDown from '../../Organisms/BaseDropDown/TerritoryDropDown/TerritoryDropDown';
import { useStateValue } from '../../../Store/helpers/UseStateValue';
import { ReferenceDropdownType } from '../../../services/Models/ReferenceModals';
import TitleDropDown from '../../Organisms/BaseDropDown/TitleDropDown/TitleDropDown';
import ReferenceDropdown from '../../Organisms/ReferenceDropdown/ReferenceDropdown';
import { getDefaultReferenceDropdownProps } from '../../Organisms/ReferenceDropdown/ReferenceDropdownPropsHelper';

interface OrganisationAddressFormProps {
  addressData: OrganisationAddressData;
  error: Dictionary;
  handleChange: (event: { target: OrganisationFromData }) => void;
  id?: string;
  isNameRequired?: boolean;
  addressName: string;
  serviceRequest: ServiceRequest;
  mandatoryField?: {
    givenName?: boolean;
    familyName?: boolean;
    addressOne?: boolean;
    city?: boolean;
    emailAddress?: boolean;
    country?: boolean;
  };
}

const OrganisationAddressForm = (props: OrganisationAddressFormProps) => {
  const { state } = useStateValue();
  const { addressData, error, handleChange, id } = props;
  const organisationLabels = languageService().organisation;
  const inputFieldValidationObj = getNestedProperty(error, props.addressName || '') || {};
  const isCountryDropdownTouched = useRef(false);

  const onAddressFromChange = (event: SyntheticEvent | OrganisationFromData) => {
    const dropdownEvent = event as OrganisationFromData;
    let target: OrganisationFromData;
    if (dropdownEvent.dropdownText === '' || dropdownEvent.dropdownText) {
      target = dropdownEvent;
    } else {
      const inputEvent = event as SyntheticEvent;
      const inputTarget = inputEvent.target as HTMLInputElement;
      target = {
        name: inputTarget.name,
        value: inputTarget.value,
      };
    }
    handleChange({ target: { ...target, addressName: props.addressName } });
  };

  useEffectUpdate(() => {
    if (isCountryDropdownTouched.current) {
      onAddressFromChange({
        name: 'region',
        value: initialDropDownDataSource,
        dropdownText: '',
      });
    }
  }, [addressData.country?.value]);

  return (
    <div className={cx(styles.col3, styles.ogFormGrid, styles.ogGridPadding)}>
      {props.isNameRequired && (
        <TitleDropDown
          id={id + 'title'}
          labelId={id + 'titleLbl'}
          selectedTitle={addressData.title}
          onTitleChange={(title: string) =>
            handleChange({ target: { name: 'title', value: title, addressName: props.addressName } })
          }
        />
      )}
      {props.isNameRequired && (
        <UI.TextBox
          label={organisationLabels.givenNameLabel}
          mandatory={props.mandatoryField?.givenName}
          labelId={id + 'givenNameLbl'}
          value={addressData.givenName}
          inputFieldValidation={inputFieldValidationObj['givenName']}
          name={'givenName'}
          id={id + 'GivenName'}
          placeholder=" "
          onChange={onAddressFromChange}
        />
      )}

      {props.isNameRequired && (
        <UI.TextBox
          label={organisationLabels.familyNameLabel}
          mandatory={props.mandatoryField?.familyName}
          labelId={id + 'familyNameLbl'}
          value={addressData.familyName}
          inputFieldValidation={inputFieldValidationObj['familyName']}
          name={'familyName'}
          id={id + 'FamilyName'}
          placeholder=" "
          onChange={onAddressFromChange}
        />
      )}

      {props.isNameRequired && (
        <UI.TextBox
          label={organisationLabels.jobTitle}
          labelId={id + 'jobTitleLbl'}
          value={addressData.jobTitle}
          name={'jobTitle'}
          id={id + 'jobTitle'}
          inputFieldValidation={inputFieldValidationObj['jobTitle']}
          placeholder=" "
          onChange={onAddressFromChange}
        />
      )}

      <UI.TextBox
        label={organisationLabels.addressLabel1}
        mandatory={props.mandatoryField?.addressOne}
        labelId={id + 'AddressOneLB'}
        value={addressData.addressOne}
        inputFieldValidation={inputFieldValidationObj['addressOne']}
        name={'addressOne'}
        id={id + 'AddressOne'}
        placeholder=" "
        onChange={onAddressFromChange}
      />

      <UI.TextBox
        label={organisationLabels.addressLabel2}
        labelId={id + 'delAddressTwoLB'}
        value={addressData.addressTwo}
        name={'addressTwo'}
        id={id + 'DelAddressTwo'}
        inputFieldValidation={inputFieldValidationObj['addressTwo']}
        placeholder=" "
        onChange={onAddressFromChange}
      />
      <UI.TextBox
        label={organisationLabels.addressLabel3}
        labelId={id + 'delAddressThreeLB'}
        value={addressData.addressThree}
        name={'addressThree'}
        id={id + 'DelAddressThree'}
        inputFieldValidation={inputFieldValidationObj['addressThree']}
        placeholder=" "
        onChange={onAddressFromChange}
      />
      <UI.TextBox
        label={organisationLabels.addressLabel4}
        labelId={id + 'delAddressFourLB'}
        value={addressData.addressFour}
        name={'addressFour'}
        id={id + 'DelAddressFour'}
        inputFieldValidation={inputFieldValidationObj['addressFour']}
        placeholder=" "
        onChange={onAddressFromChange}
      />
      <UI.TextBox
        label={organisationLabels.cityTownLabel}
        mandatory={props.mandatoryField?.city}
        labelId={id + 'delCityLB'}
        value={addressData.city}
        inputFieldValidation={inputFieldValidationObj['city']}
        name={'city'}
        id={id + 'City'}
        placeholder=""
        onChange={onAddressFromChange}
      />
      <UI.TextBox
        label={organisationLabels.passZipCodeLabel}
        labelId="delZipCodeLB"
        value={addressData.postalCode}
        name={'postalCode'}
        id={id + 'ZipCode'}
        inputFieldValidation={inputFieldValidationObj['postalCode']}
        placeholder=""
        onChange={onAddressFromChange}
      />
      <ReferenceDropdown
        {...getDefaultReferenceDropdownProps({
          id: id + 'OrganisationCountry',
          dropdownConfig: {
            isMandatory: props.mandatoryField?.country,
            inputFieldValidationError: inputFieldValidationObj['country'],
          },
          dropdownType: ReferenceDropdownType.COUNTRY,
          value: addressData.country?.value,
          onChange: ({ value, text }: DropDownDataSource) => {
            isCountryDropdownTouched.current = true;
            onAddressFromChange({
              name: 'country',
              value: { value, text },
              dropdownText: text,
            });
          },
        })}
      />

      <TerritoryDropDown
        id={id + 'OrganisationTerritory'}
        label={organisationLabels.regionTerritory}
        labelId={id + 'OrganisationTerriroryLB'}
        textBoxPlaceHolder={organisationLabels.pleaseSelectPlaceHolder}
        selectedTerritory={addressData.region || initialDropDownDataSource}
        inputFieldValidationError={inputFieldValidationObj['region']}
        serviceRequest={props.serviceRequest}
        isFilterEnabled={true}
        canUseStoreData
        countryCode={getCountryISOCode(state, addressData.country?.value)}
        onTerritoryChange={(value: string, text: string) =>
          onAddressFromChange({
            name: 'region',
            value: { value, text },
            dropdownText: text,
          })
        }
      />

      <UI.TextBox
        label={organisationLabels.emailLabel}
        mandatory={props.mandatoryField?.emailAddress}
        labelId={id + 'delEmailAddressLB'}
        value={addressData.emailAddress}
        name={'emailAddress'}
        id={id + 'delEmailAddress'}
        inputFieldValidation={inputFieldValidationObj['emailAddress']}
        placeholder=" "
        onChange={onAddressFromChange}
      />

      <UI.TextBox
        label={organisationLabels.telephoneLabel}
        labelId={id + 'delTelephoneNumberLB'}
        value={addressData.phoneNumber}
        name={'phoneNumber'}
        id={id + 'delTelephoneNumber'}
        inputFieldValidation={inputFieldValidationObj['phoneNumber']}
        placeholder=" "
        onChange={onAddressFromChange}
      />
    </div>
  );
};

export default withServiceRequest(OrganisationAddressForm);
