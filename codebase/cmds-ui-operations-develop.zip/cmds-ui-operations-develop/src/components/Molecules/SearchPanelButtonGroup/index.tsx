import React from 'react';
import UI from 'ielts-cmds-ui-component-library';
import styles from './styles.module.scss';
import { getValue } from '../../utils/utilities';

export enum SearchPanelButtonType {
  SEARCH,
  CLEAR,
}

export enum ButtonGroupDirection {
  LEFT = 'left',
  RIGHT = 'right',
  CENTER = 'center',
}
interface SearchPanelButtonGroupProps {
  searchButtonTitle: string;
  clearButtonTitle: string;
  isClearButtonVisible: boolean;
  id: string;
  onButtonClicked: (type: SearchPanelButtonType) => void;
  styles?: string;
  buttonDirection?: ButtonGroupDirection;
}

export default (props: SearchPanelButtonGroupProps) => {
  const {
    searchButtonTitle,
    clearButtonTitle,
    id,
    onButtonClicked,
    isClearButtonVisible,
    buttonDirection = ButtonGroupDirection.RIGHT,
  } = props;
  return (
    <div className={`${styles.SearchPaneButtonGroup} ${styles[buttonDirection]} ${getValue(props.styles)}`}>
      {isClearButtonVisible && (
        <div
          onClick={() => onButtonClicked(SearchPanelButtonType.CLEAR)}
          className={styles.clearSearch}
          id={`${id}clearSearch`}
        >
          <span>{clearButtonTitle}</span>
        </div>
      )}
      <UI.Button
        label={searchButtonTitle}
        onChange={() => onButtonClicked(SearchPanelButtonType.SEARCH)}
        color="primary"
        id={`${id}SearchButton`}
      />
    </div>
  );
};
