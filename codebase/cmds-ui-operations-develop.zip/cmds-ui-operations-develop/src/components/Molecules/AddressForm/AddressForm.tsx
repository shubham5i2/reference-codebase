import React, { SyntheticEvent, useRef } from 'react';
import styles from './AddressForm.module.scss';
import UI from 'ielts-cmds-ui-component-library';
import cx from 'classnames';
import { languageService } from '../../../services/Language/LanguageService';
import { getCountryISOCode, useEffectUpdate } from '../../utils/utilities';
import { initialDropDownDataSource } from '../../Templates/Organisation/OrganisationConstants';
import withServiceRequest, { ServiceRequest } from '../../../services/utils/ServiceRequest';
import TerritoryDropDown from '../../Organisms/BaseDropDown/TerritoryDropDown/TerritoryDropDown';
import { useStateValue } from '../../../Store/helpers/UseStateValue';
import { ReferenceDropdownType } from '../../../services/Models/ReferenceModals';
import {
  AddressData,
  AddressFormEvent,
  AddressFormElements,
  AddressErrorField,
} from '../../../services/Models/LocationManagement';
import ReferenceDropdown from '../../Organisms/ReferenceDropdown/ReferenceDropdown';
import { getDefaultReferenceDropdownProps } from '../../Organisms/ReferenceDropdown/ReferenceDropdownPropsHelper';
import { DropDownDataSource, FormError } from '../../../services/Models/UIModels';

type AddressFormMandatoryField = {
  [x in AddressFormElements]: boolean;
};

type AddressFormError = {
  [x in AddressFormElements]: string;
};

interface AddressFormProps {
  addressData: AddressData;
  error: AddressFormError;
  handleAddressChange: (event: AddressFormEvent) => void;
  id?: string;
  //  Location address type should come from enum
  addressType: string;
  serviceRequest: ServiceRequest;
  mandatoryField?: AddressFormMandatoryField;
  errors: AddressErrorField;
}

const AddressForm = (props: AddressFormProps) => {
  const { state } = useStateValue();
  const { errors = {}, handleAddressChange, id, addressType, addressData, mandatoryField } = props;
  const locationLabels = languageService().locationManagement;
  const isCountryTouched = useRef(false);

  const onDropdownChange = (event: AddressFormEvent) => {
    handleAddressChange({ ...event, addressType: props.addressType });
  };

  const onInputTextChange = (event: SyntheticEvent) => {
    const inputEvent = event as SyntheticEvent;
    const inputTarget = inputEvent.target as HTMLInputElement;
    const addressFormEvent: AddressFormEvent = {
      name: inputTarget.name,
      value: inputTarget.value,
      addressType: props.addressType,
    };
    handleAddressChange(addressFormEvent);
  };

  useEffectUpdate(() => {
    if (isCountryTouched.current) {
      const territoryEvent = {
        name: AddressFormElements.territoryUuid,
        value: '',
        addressType: addressType,
      };
      const territoryTextEvent = {
        name: AddressFormElements.territoryName,
        value: '',
        addressType: addressType,
      };
      const iso3CodeTarget = {
        name: AddressFormElements.countryIso3Code,
        value: getCountryISOCode(state, addressData.countryUuid),
        addressType: addressType,
      };
      handleAddressChange(iso3CodeTarget);
      handleAddressChange(territoryEvent);
      handleAddressChange(territoryTextEvent);
    }
  }, [addressData.countryUuid]);

  return (
    <div className={cx(styles.col3, styles.ogFormGrid, styles.ogGridPadding)}>
      <UI.TextBox
        label={locationLabels.addressLabel1}
        mandatory={mandatoryField?.addressLine1}
        labelId={id + 'delAddressOneLB'}
        value={addressData.addressLine1}
        inputFieldValidation={errors[AddressFormElements.addressLine1]}
        name={AddressFormElements.addressLine1}
        id={id + AddressFormElements.addressLine1}
        placeholder={locationLabels.pleaseEnterPlaceHolder}
        onChange={onInputTextChange}
      />

      <UI.TextBox
        label={locationLabels.addressLabel2}
        labelId={id + 'delAddressTwoLB'}
        value={addressData.addressLine2}
        name={AddressFormElements.addressLine2}
        id={id + AddressFormElements.addressLine2}
        inputFieldValidation={errors[AddressFormElements.addressLine2]}
        placeholder={locationLabels.pleaseEnterPlaceHolder}
        onChange={onInputTextChange}
      />
      <UI.TextBox
        label={locationLabels.addressLabel3}
        labelId={id + 'delAddressThreeLB'}
        value={addressData.addressLine3}
        name={AddressFormElements.addressLine3}
        id={id + AddressFormElements.addressLine3}
        inputFieldValidation={errors[AddressFormElements.addressLine2]}
        placeholder={locationLabels.pleaseEnterPlaceHolder}
        onChange={onInputTextChange}
      />
      <UI.TextBox
        label={locationLabels.addressLabel4}
        labelId={id + 'delAddressFourLB'}
        value={addressData.addressLine4}
        name={AddressFormElements.addressLine4}
        id={id + AddressFormElements.addressLine4}
        inputFieldValidation={errors[AddressFormElements.addressLine4]}
        placeholder={locationLabels.pleaseEnterPlaceHolder}
        onChange={onInputTextChange}
      />
      <UI.TextBox
        label={locationLabels.cityLabel}
        mandatory={mandatoryField?.city}
        labelId={id + 'delCityLB'}
        value={addressData.city}
        inputFieldValidation={errors[AddressFormElements.city]}
        name={AddressFormElements.city}
        id={id + AddressFormElements.city}
        placeholder={locationLabels.pleaseEnterPlaceHolder}
        onChange={onInputTextChange}
        error={errors[AddressFormElements.city]}
      />
      <UI.TextBox
        label={locationLabels.postalCodeLabel}
        labelId="delZipCodeLB"
        value={addressData.postalCode}
        name={AddressFormElements.postalCode}
        id={id + AddressFormElements.postalCode}
        inputFieldValidation={errors[AddressFormElements.postalCode]}
        placeholder={locationLabels.pleaseEnterPlaceHolder}
        onChange={onInputTextChange}
      />

      <ReferenceDropdown
        {...getDefaultReferenceDropdownProps({
          id: id + AddressFormElements.countryUuid,
          dropdownConfig: {
            isMandatory: mandatoryField?.countryUuid,
            inputFieldValidationError: errors[AddressFormElements.countryUuid] as FormError,
          },
          dropdownType: ReferenceDropdownType.COUNTRY,
          value: addressData.countryUuid,
          onChange: ({ value, text }: DropDownDataSource) => {
            isCountryTouched.current = true;
            onDropdownChange({
              name: AddressFormElements.countryUuid,
              value: value,
            });
            onDropdownChange({
              name: AddressFormElements.countryName,
              value: text,
            });
          },
        })}
      />

      <TerritoryDropDown
        id={id + AddressFormElements.territoryUuid}
        label={locationLabels.territory}
        isMandatory={mandatoryField?.territoryUuid}
        labelId={id + 'TerriroryLB'}
        textBoxPlaceHolder={locationLabels.pleaseSelectPlaceHolder}
        selectedTerritory={
          { value: addressData.territoryUuid, text: addressData.territoryName } || initialDropDownDataSource
        }
        inputFieldValidationError={errors[AddressFormElements.territoryUuid]}
        serviceRequest={props.serviceRequest}
        isFilterEnabled={true}
        canUseStoreData
        countryCode={getCountryISOCode(state, addressData.countryUuid)}
        onTerritoryChange={(value: string, text: string) => {
          onDropdownChange({
            name: AddressFormElements.territoryUuid,
            value: value,
          });
          onDropdownChange({
            name: AddressFormElements.territoryName,
            value: text,
          });
        }}
      />
      <UI.TextBox
        label={locationLabels.countryIso3Code}
        labelId={id + AddressFormElements.countryIso3Code}
        value={addressData.countryIso3Code}
        name={AddressFormElements.countryIso3Code}
        id={id + AddressFormElements.countryIso3Code}
        placeholder={''}
        onChange={() => console.log('')}
        inputDisabled
        mandatory
        inputFieldValidation={errors[AddressFormElements.countryIso3Code]}
        // inputDisabled={true}
      />

      <UI.TextBox
        label={locationLabels.emailLabel}
        mandatory={mandatoryField?.email}
        labelId={id + AddressFormElements.email + 'LB'}
        value={addressData.email}
        name={AddressFormElements.email}
        id={id + AddressFormElements.email}
        inputFieldValidation={errors[AddressFormElements.email]}
        placeholder={locationLabels.pleaseEnterPlaceHolder}
        onChange={onInputTextChange}
      />

      <UI.TextBox
        label={locationLabels.primaryPhoneLabel}
        labelId={id + AddressFormElements.primaryPhone + 'LB'}
        value={addressData.primaryPhone}
        mandatory={mandatoryField?.primaryPhone}
        name={AddressFormElements.primaryPhone}
        id={id + AddressFormElements.primaryPhone}
        inputFieldValidation={errors[AddressFormElements.primaryPhone]}
        placeholder={locationLabels.pleaseEnterPlaceHolder}
        onChange={onInputTextChange}
      />
      <UI.TextBox
        label={locationLabels.secondaryPhoneLabel}
        labelId={id + AddressFormElements.secondaryPhone + 'LB'}
        value={addressData.secondaryPhone}
        name={AddressFormElements.secondaryPhone}
        id={id + AddressFormElements.secondaryPhone}
        inputFieldValidation={errors[AddressFormElements.secondaryPhone]}
        placeholder={locationLabels.pleaseEnterPlaceHolder}
        onChange={onInputTextChange}
      />
    </div>
  );
};

export default withServiceRequest(AddressForm);
