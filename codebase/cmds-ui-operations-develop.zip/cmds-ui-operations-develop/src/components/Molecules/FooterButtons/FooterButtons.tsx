import React from 'react';
import styles from './FooterButtons.module.scss';
import { languageService } from '../../../services/Language/LanguageService';
import UI from 'ielts-cmds-ui-component-library';

export interface footrButtonsProps {
  containerClass?: string;
  onSubmit: () => void;
  onCancel: () => void;
  addOrUpdateButtonText: string;
  disabledButtons?: { isSubmitDisabled?: boolean; isCancelDisabled?: boolean };
}

const FooterButtons = ({
  disabledButtons,
  addOrUpdateButtonText,
  containerClass,
  onCancel,
  onSubmit,
}: footrButtonsProps) => {
  const commonLabels = languageService().common;
  const { isSubmitDisabled = false, isCancelDisabled = false } = disabledButtons || {};
  return (
    <div className={`${styles.footerButtons} ${containerClass}`}>
      <div className={styles.buttonContainer}>
        <UI.Button
          color="secondary"
          label={commonLabels.cancelButtonTitle}
          id="CancelLocation"
          onChange={onCancel}
          disabled={isSubmitDisabled}
        />
        <UI.Button
          color="primary"
          label={addOrUpdateButtonText}
          id="AddLocation"
          onChange={onSubmit}
          disabled={isCancelDisabled}
        />
      </div>
    </div>
  );
};

export default FooterButtons;
