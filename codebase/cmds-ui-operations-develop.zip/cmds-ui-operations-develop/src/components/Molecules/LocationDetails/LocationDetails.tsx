import React, { useEffect, useState } from 'react';
import styles from './LocationDetails.module.scss';
import UI from 'ielts-cmds-ui-component-library';
import { languageService } from '../../../services/Language/LanguageService';
import LocationViewDetails from '../../Organisms/LocationViewDetails/LocationViewDetails';
import { useStateValue } from '../../../Store/helpers/UseStateValue';
import * as BreadCrumbActions from '../../../Store/Actions/BreadCrumbActions';
import { AsyncResponseStatus } from '../../../services/Models/Api';
import { LocationDetailsData, AddressData, ProductAuthorization } from '../../../services/Models/LocationManagement';
import {
  initialLocationDetailsData,
  initialAddressData,
} from '../../../constants/LocationManagement/LocationConstants';
import withServiceRequest, { ServiceRequest } from '../../../services/utils/ServiceRequest';
import { getLocation } from '../../../services/API/LocationManagement/ViewLocation';
import { RouteParams } from '../../../services/Models/UIModels';
import { useParams, useHistory } from 'react-router-dom';
import LocationAddressViewDetails from '../../Organisms/LocationAddressViewDetails/LocationAddressViewDetails';
import SelectProduct from '../../Organisms/SelectProduct/SelectProduct';

interface LocationDetailsProps {
  serviceRequest: ServiceRequest;
}

const LocationTestCentreDetails = (props: LocationDetailsProps) => {
  const { dispatch } = useStateValue();
  const [locationDetailsData, setLocationDetailsdata] = useState<LocationDetailsData>(initialLocationDetailsData);
  const [addressData, setAddressData] = useState<AddressData[]>(initialAddressData);
  const [selectedProducts, setSelectedProducts] = useState<ProductAuthorization[]>([]);
  const history = useHistory();
  const { id } = useParams<RouteParams>();

  useEffect(() => {
    if (history.location?.state) {
      dispatch({ type: BreadCrumbActions.SHOW_BACK, payload: history.location.state.testCentreNumber });
    } else {
      dispatch({ type: BreadCrumbActions.SHOW_BACK });
    }
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (id) {
      getLocationData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const getLocationData = () => {
    getLocation(id, props.serviceRequest).subscribe((data) => {
      if (data.status === AsyncResponseStatus.SUCCESS && data.locationData) {
        setLocationDetailsdata(data.locationData.locationDetailsData);
        setAddressData(data.locationData.locationAddresses);
        setSelectedProducts(data.locationData.approvedProducts?.activeProd || []);
      }
    });
  };

  const locationLables = languageService().locationManagement;
  return (
    <div className={styles.locationDetailContainer}>
      <div className={styles.locationDetailTitleContainer}>
        <div className={styles.locationDetailTitle} id="location_detail_title">
          <UI.Typography id="viewLocationTitle" type="regular" label={locationLables.viewLocation} size={32} />
        </div>
      </div>
      <LocationViewDetails locationDetailsData={locationDetailsData} />
      <div className={styles.viewAddressHeaderConainer}>
        {addressData.map((item) => (
          // eslint-disable-next-line react/jsx-key
          <LocationAddressViewDetails addressData={item} key={item.addressTypeUuid} />
        ))}
      </div>
      {selectedProducts.length > 0 && (
        <div className={styles.viewAddressHeaderConainer}>
          <div className={styles.selectedProductsPanel}>
            <SelectProduct isreadOnly id={'productAuthorization'} selectedProducts={selectedProducts} />
          </div>
        </div>
      )}
    </div>
  );
};

export default withServiceRequest(LocationTestCentreDetails);
