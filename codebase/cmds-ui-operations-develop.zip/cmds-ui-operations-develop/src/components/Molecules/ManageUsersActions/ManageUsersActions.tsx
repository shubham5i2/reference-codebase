import React from 'react';
import styles from './ManageUsersActions.module.scss';

const ManageUsersActions = (props: any) => {
  if (props.currentActionType !== 'delete') {
    return (
      <div ref={props.containerRef} className={styles.manageUsersActions} id="userActionsDropDown">
        <ul>
          {props.userActions.map((action: any, idx: number) => (
            <li key={idx} onClick={() => props.userActionsClickHandler(action)}>
              <img alt="" src={action.icon} /> <label>{action.label}</label>
            </li>
          ))}
        </ul>
      </div>
    );
  }
  return null;
};

export default ManageUsersActions;
