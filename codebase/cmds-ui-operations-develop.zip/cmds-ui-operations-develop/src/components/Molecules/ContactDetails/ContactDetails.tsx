import React from 'react';
import styles from './ContactDetails.module.scss';
import { languageService } from '../../../services/Language/LanguageService';
import { OrganisationAddressData } from '../../../services/Models/Organisation';
import { joinAddress, getValue } from '../../../components/utils/utilities';
import { Dictionary } from '../../../services/Models/UIModels';

interface ContactDetailsProps {
  primaryContactAddress: OrganisationAddressData;
  adminContactAddress: OrganisationAddressData;
}

const ContactDetails = (props: ContactDetailsProps) => {
  const organisationLabels = languageService().organisation;
  const contactDetails = [{ primary: props.primaryContactAddress }, { admin: props.adminContactAddress }];

  const getName = (addressData: OrganisationAddressData) =>
    getValue(addressData?.title) + ' ' + getValue(addressData?.givenName) + ' ' + getValue(addressData?.familyName);

  return (
    <div className={styles.orgDetailContainer}>
      <div className={styles.OrgDetailTitle} id="contact_title">
        <span>{organisationLabels.contactDetailsTitle}</span>
      </div>
      <div className={styles.orgDetailInfo}>
        {contactDetails.map((contactAddress: Dictionary, idx) => {
          const key = Object.keys(contactAddress)[0];
          const contactDetail = contactAddress[key];
          return (
            <React.Fragment key={key + idx}>
              <span className={styles.orgDetailSubTitle} id={key + '_contact_title'}>
                {idx === 0 ? organisationLabels.primaryContact : organisationLabels.resultsAdminContact}
              </span>

              <div className={styles.orgDetailInfoWrapper}>
                <div className={styles.orgDetailInfoContainer}>
                  <span className={styles.orgDetailInfoTitle} id={key + 'contact_name'}>
                    {organisationLabels.nameLabel}
                  </span>
                  <span className={styles.orgDetailInfoData} id={key + 'contact_name_data'}>
                    {getName(contactDetail)}
                  </span>
                </div>
                <div className={styles.orgDetailInfoContainer}>
                  <span className={styles.orgDetailInfoTitle} id={key + 'contact_job_title'}>
                    {organisationLabels.jobTitle}
                  </span>
                  <span className={styles.orgDetailInfoData} id={key + 'contact_job_title_data'}>
                    {contactDetail?.jobTitle}
                  </span>
                </div>
                <div className={styles.orgDetailInfoContainer}>
                  <span className={styles.orgDetailInfoTitle} id={key + 'contact_address'}>
                    {organisationLabels.address}
                  </span>
                  <span className={styles.orgDetailInfoData} id={key + 'contact_address_data'}>
                    {joinAddress(contactDetail)}
                  </span>
                </div>
                <div className={styles.orgDetailInfoContainer}>
                  <span className={styles.orgDetailInfoTitle} id={key + 'contact_city'}>
                    {organisationLabels.cityTownLabel}
                  </span>
                  <span className={styles.orgDetailInfoData} id={key + 'contact_city_data'}>
                    {contactDetail?.city}
                  </span>
                </div>
                <div className={styles.orgDetailInfoContainer}>
                  <span className={styles.orgDetailInfoTitle} id={key + 'contact_postcode'}>
                    {organisationLabels.passZipCodeLabel}
                  </span>
                  <span className={styles.orgDetailInfoData} id={key + 'contact_postcode_data'}>
                    {contactDetail?.postalCode}
                  </span>
                </div>
                <div className={styles.orgDetailInfoContainer}>
                  <span className={styles.orgDetailInfoTitle} id={key + 'contact_country'}>
                    {organisationLabels.countryLabel}
                  </span>
                  <span className={styles.orgDetailInfoData} id={key + 'contact_country_data'}>
                    {contactDetail?.country?.text}
                  </span>
                </div>
                <div className={styles.orgDetailInfoContainer}>
                  <span className={styles.orgDetailInfoTitle} id={key + 'contact_region'}>
                    {organisationLabels.regionTerritory}
                  </span>
                  <span className={styles.orgDetailInfoData} id={key + 'contact_region_data'}>
                    {contactDetail?.region?.text}
                  </span>
                </div>

                <div className={styles.orgDetailInfoContainer}>
                  <span className={styles.orgDetailInfoTitle} id={key + 'contact_email'}>
                    {organisationLabels.emailId}
                  </span>
                  <span className={styles.orgDetailInfoData} id={key + 'contact_email_data'}>
                    {contactDetail?.emailAddress}
                  </span>
                </div>
                <div className={styles.orgDetailInfoContainer}>
                  <span className={styles.orgDetailInfoTitle} id={key + 'contact_phone'}>
                    {organisationLabels.telephoneLabel}
                  </span>
                  <span className={styles.orgDetailInfoData} id={key + 'contact_phone_data'}>
                    {contactDetail?.phoneNumber}
                  </span>
                </div>
              </div>
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
};

export default ContactDetails;
