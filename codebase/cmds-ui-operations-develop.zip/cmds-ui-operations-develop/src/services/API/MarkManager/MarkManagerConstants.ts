export const BASE_URL = process.env.REACT_APP_UI_TACTICAL_BASE_URL;
export const URL_CONFIG = {
  submitEOR: '/v1/tacticalEOR/',
  searchMarks: '/v1/searchMarks',
  updateMarks: '/v1/manualMarksUpdate',
};
