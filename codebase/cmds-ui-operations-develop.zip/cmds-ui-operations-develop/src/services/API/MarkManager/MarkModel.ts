interface testInfo {
  testCentreId?: string;
  testVersionId?: string;
  testDate?: string;
  testFormat?: string;
  module?: string;
}

interface testComponentInfo {
  component?: string;
  componentTotal?: number;
  markType?: string;
}

export interface marks {
  markReference?: string;
  sharedQuestionId?: string;
  markValue?: number;
}

export interface MarkModel {
  candidateMarksStatus?: string;
  testComponentUuid?: string;
  speakingTask?: string;
  compositeCandidateNumber?: string;
  examinerId1?: string;
  examinerId2?: string;
  testInfo: testInfo;
  testComponentInfo: testComponentInfo;
  marks?: marks[];
}
