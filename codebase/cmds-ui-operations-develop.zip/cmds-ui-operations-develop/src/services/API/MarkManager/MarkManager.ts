import { HttpMethod, AsyncResponse, AsyncResponseStatus } from '../../Models/Api';
import { ServiceRequest } from '../../utils/ServiceRequest';
import { map, filter } from 'rxjs/operators';
import { BASE_URL, URL_CONFIG } from './MarkManagerConstants';

export const callServiceSearchMarks = async (request: any, token: string) => {
  const requestOptions = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      'x-access-token': `${token}`,
    },
    body: JSON.stringify(request),
  };
  return await fetch(`${BASE_URL}${URL_CONFIG.searchMarks}`, requestOptions)
    .then((response) => response.json())
    .then((data) => {
      console.log('data', data);
      return data;
    })
    .catch((error) => {
      console.log('error ', error);
      return error;
    });
};

export const callServiceUpdateMarks = async (request: any, token: string) => {
  const requestOptions = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      'x-access-token': `${token}`,
    },
    body: JSON.stringify(request),
  };
  return await fetch(`${BASE_URL}${URL_CONFIG.updateMarks}`, requestOptions)
    .then((response) => {
      console.log('response ', response);
      if (response.ok) {
        return true;
      }
    })
    .then((data) => {
      console.log('data', data);
      return true;
    })
    .catch((error) => {
      console.log('error ', error);
      return false;
    });
};

export const getSearchedMarks = (reqBody: any, serviceRequest: ServiceRequest) => {
  const servicesInfo = {
    name: 'Get Test Searched Marks Details',
    restUrl: `/v1/searchMarks`,
    config: {
      headers: {},
    },
    method: HttpMethod.POST,
    body: reqBody,
  };
  return serviceRequest(servicesInfo).pipe(
    map((data: AsyncResponse) => {
      console.log('data ', data);
      if (!data || !data.body || !data.body.response) {
        return { marks: undefined, status: AsyncResponseStatus.ERROR };
      }
      return { marks: data.body.response, status: data.status };
    }),
    filter((data: any) => data.status !== AsyncResponseStatus.LOADING),
  );
};

export const updateRequestedComponentMarks = (reqBody: any, serviceRequest: ServiceRequest) => {
  const servicesInfo = {
    name: 'Get Test Searched Marks Details',
    restUrl: `/v1/manualMarksUpdate`,
    config: {
      headers: {},
    },
    method: HttpMethod.POST,
    body: reqBody,
    displayLoader: true,
  };
  return serviceRequest(servicesInfo).pipe(
    map((data: AsyncResponse) => {
      console.log('data ', data);
      if (!data || !data.body || !data.body.response) {
        return { marks: undefined, status: AsyncResponseStatus.ERROR };
      }
      return { marks: data.body.response, status: data.status };
    }),
    filter((data: any) => data.status !== AsyncResponseStatus.LOADING),
  );
};
