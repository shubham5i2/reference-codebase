import { ServiceRequest } from '../../utils/ServiceRequest';
import { HttpMethod } from '../../Models/Api';
import { CommentUserType, IncidentComments, IncidentManagementIncidentDetails } from '../../Models/IncidentManagement';
import { User } from '@auth0/auth0-spa-js';
import { getValue } from '../../../components/utils/utilities';
import { IncidentSeverity } from '../Reference/Incident';

export interface UpdateIncidentPostData {
  incidentDetails: IncidentManagementIncidentDetails;
}

export const updateIncidentDetails = (
  data: IncidentManagementIncidentDetails,
  comment: string,
  serviceRequest: ServiceRequest,
  user?: User,
) => {
  const servicesInfo = {
    name: 'Incident Update',
    restUrl: '/v1/incident/update',
    config: {
      headers: {},
    },
    method: HttpMethod.PUT,
    displayLoader: true,
    body: formatPostIncidentData(data, comment, user),
  };
  return serviceRequest(servicesInfo);
};

const addComment = (comment: string, user?: User) => {
  return {
    comment: comment,
    commentDateTime: new Date().toISOString(),
    commentEnteredBy: getValue(`${user?.given_name} ${user?.family_name}`),
    userType: CommentUserType.REVIEWER,
  } as IncidentComments;
};

const checkIncidentSeverity = (incidentSeverity: string | null) => {
  return incidentSeverity !== null ? incidentSeverity : IncidentSeverity.INFO;
};

const formatPostIncidentData = (data: IncidentManagementIncidentDetails, comment: string, user?: User) => {
  if (comment.trim() === '') {
    return {
      incidentDetails: {
        ...data,
        comments: [],
        banReviewRequired: false,
        incidentSeverity: checkIncidentSeverity(data.incidentSeverity),
      },
    } as UpdateIncidentPostData;
  } else {
    return {
      incidentDetails: {
        ...data,
        comments: [addComment(comment, user)],
        banReviewRequired: false,
        incidentSeverity: checkIncidentSeverity(data.incidentSeverity),
      },
    } as UpdateIncidentPostData;
  }
};
