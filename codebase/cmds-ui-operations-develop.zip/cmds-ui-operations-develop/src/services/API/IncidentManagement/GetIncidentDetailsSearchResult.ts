import { map, filter } from 'rxjs/operators';

import { ServiceRequest } from '../../utils/ServiceRequest';
import { AsyncResponse, AsyncResponseStatus, HttpMethod } from '../../Models/Api';
import { CommentUserType, DateDivision, IncidentManagementIncidentDetails } from '../../Models/IncidentManagement';
import { getValue, manageDateTime } from '../../../components/utils/utilities';

export const getIncidentManagementDetails = (bookingUuid: string, serviceRequest: ServiceRequest) => {
  const servicesInfo = {
    name: 'Incident Management Details',
    restUrl: `/v1/incident/${bookingUuid}`,
    config: {
      headers: {},
    },
    method: HttpMethod.GET,
    displayLoader: true,
  };

  return serviceRequest(servicesInfo).pipe(
    map((data: AsyncResponse) => {
      //console.log('view page data:',data);
      if (!data || !data.body || !data.body.response) {
        return { incidentDetailsData: undefined, status: AsyncResponseStatus.ERROR };
      }
      const result = data.body.response.entries;

      return { incidentDetailsData: result, status: data.status };
    }),
    filter((data) => data.status !== AsyncResponseStatus.LOADING),
  );
};

export const findReportingUser = (arg: IncidentManagementIncidentDetails) => {
  const comments = arg.comments;
  const reporter = comments.find((item) => item.userType === CommentUserType.REPORTER);
  return getValue(reporter?.commentEnteredBy);
};

export const getIncidentDetails = (arg: IncidentManagementIncidentDetails) => {
  const comments = arg.comments;
  const reporter = comments.find((item) => item.userType === CommentUserType.REPORTER);
  return getValue(reporter?.comment);
};

export const getDateTime = (arg: IncidentManagementIncidentDetails) => {
  const comments = arg.comments;
  return manageDateTime(
    getValue(comments.find((item) => item.userType === CommentUserType.REPORTER)?.commentDateTime),
    DateDivision.NORMAL,
  );
};
