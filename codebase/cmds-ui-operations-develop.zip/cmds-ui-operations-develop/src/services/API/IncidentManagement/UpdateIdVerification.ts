import { ServiceRequest } from '../../utils/ServiceRequest';
import { HttpMethod } from '../../Models/Api';

interface VrificationPostBody {
  bookingUuid: string;
  checkOutcomeStatusUuid: string;
}

export const updateIdVerification = (data: VrificationPostBody, serviceRequest: ServiceRequest) => {
  const servicesInfo = {
    name: 'Update ID Verification Status',
    restUrl: '/v1/incident/submitidcheckoutcome',
    config: {
      headers: {},
    },
    method: HttpMethod.PUT,
    body: data,
  };
  return serviceRequest(servicesInfo);
};
