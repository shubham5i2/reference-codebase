import { map, filter } from 'rxjs/operators';
import { ServiceRequest } from '../../utils/ServiceRequest';
import { AsyncResponse, AsyncResponseStatus, HttpMethod } from '../../Models/Api';
import { getValue } from '../../../components/utils/utilities';
import {
  IncidentManagementSearchPayload,
  IncidentManagementDetailsScreenResponse,
} from '../../Models/IncidentManagement';

export const incidentManagementSearchResult = (
  reqBody: IncidentManagementSearchPayload,
  serviceRequest: ServiceRequest,
) => {
  const servicesInfo = {
    name: 'Manage Incident Management search',
    restUrl: '/v1/incident/search',
    config: {
      headers: {},
    },
    method: HttpMethod.POST,
    body: reqBody,
  };

  return serviceRequest(servicesInfo).pipe(
    map((data: AsyncResponse) => {
      //console.log('api incident search-data:', data);
      if (!data || !data.body || !data.body.response) {
        return { status: AsyncResponseStatus.ERROR };
      }
      const { result } = data.body?.response;
      const gridData = (result?.entries || []).map((item: IncidentManagementDetailsScreenResponse) => {
        return {
          bookingUuid: getValue(item.incidentBookingDetails.bookingDetails.bookingUuid),
          uniqueTestTakerUuid: getValue(item.incidentBookingDetails.bookingDetails.uniqueTestTakerUuid),
          uniqueTestTakerId: getValue(item.incidentBookingDetails.bookingDetails.uniqueTestTakerId),
          shortCandidateNumber: getValue(item.incidentBookingDetails.bookingDetails.shortCandidateNumber),
          firstName: getValue(item.incidentBookingDetails.bookingDetails.firstName),
          lastName: getValue(item.incidentBookingDetails.bookingDetails.lastName),
          testDate: getValue(item.incidentBookingDetails.bookingDetails.testDate),
          identityNumber: getValue(item.incidentBookingDetails.bookingDetails.identityNumber),
          locationUuid: getValue(item.incidentBookingDetails.bookingDetails.locationUuid),
          productUuid: getValue(item.incidentBookingDetails.bookingDetails.productUuid),
          incidentUuid: getValue(item.incidentBookingDetails.incidentDetails.incidentUuid),
          incidentCategoryUuid: getValue(item.incidentBookingDetails.incidentDetails.incidentCategoryUuid),
          incidentTypeUuid: getValue(item.incidentBookingDetails.incidentDetails.incidentTypeUuid),
          incidentStatusTypeUuid: getValue(item.incidentBookingDetails.incidentDetails.incidentStatusTypeUuid),
          incidentSeverity: getValue(item.incidentBookingDetails.incidentDetails.incidentSeverity),
        };
      });
      return { ...result, gridData, status: data.status };
    }),
    filter((data) => data.status !== AsyncResponseStatus.LOADING),
  );
};
