import { map, filter } from 'rxjs/operators';
import { ServiceRequest } from '../../utils/ServiceRequest';
import { AsyncResponse, AsyncResponseStatus, HttpMethod } from '../../Models/Api';

export const getIncidentManagementIdVerificationDetails = (bookingUuid: string, serviceRequest: ServiceRequest) => {
  const servicesInfo = {
    name: 'Incident Management ID Verification',
    restUrl: `/v1/incident/getidphotos/${bookingUuid}`,
    config: {
      headers: {},
    },
    method: HttpMethod.GET,
    displayLoader: true,
  };

  return serviceRequest(servicesInfo).pipe(
    map((data: AsyncResponse) => {
      console.log('ID Photo data:', data);
      if (!data || !data.body || !data.body.response) {
        return { idVerificationData: undefined, status: AsyncResponseStatus.ERROR };
      }
      const result = data.body.response;

      return { idVerificationData: result, status: data.status };
    }),
    filter((data) => data.status !== AsyncResponseStatus.LOADING),
  );
};
