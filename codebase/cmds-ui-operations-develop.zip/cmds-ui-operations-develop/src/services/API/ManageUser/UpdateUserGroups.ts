import { ServiceRequest } from '../../utils/ServiceRequest';
import { UserGroup } from '../../Models/StaffManagement';
import { HttpMethod, AsyncResponse, AsyncResponseStatus } from '../../Models/Api';
import { map, filter } from 'rxjs/operators';

export const updateUserGroups = (payLoad: UserGroup[], serviceRequest: ServiceRequest, userId: string) => {
  const servicesInfo = {
    name: 'User Group',
    restUrl: `/v1/users/${userId}/usergroups`,
    config: {
      headers: {},
    },
    method: HttpMethod.PUT,
    body: payLoad,
  };
  return serviceRequest(servicesInfo).pipe(
    map((response: AsyncResponse) => {
      if (response && response.status === AsyncResponseStatus.SUCCESS && response.body) {
        return response.body.response;
      }
    }),
    filter((user) => !!user),
  );
};
