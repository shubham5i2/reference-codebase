import { map, filter } from 'rxjs/operators';
import { ServiceRequest } from '../../utils/ServiceRequest';
import { Location } from '../../Models/StaffManagement';
import { AsyncResponse, AsyncResponseStatus, HttpMethod } from '../../Models/Api';

export const getLocations = (
  userId: string,
  partnerCode: string,
  locationType: string,
  assignableToGroups: boolean,
  serviceRequest: ServiceRequest,
) => {
  const servicesInfo = {
    name: 'get locations',
    restUrl: `/v1/users/locations?partnerCode=${partnerCode}&userUuid=${userId}&locationType=${locationType}&assignableToGroups=${assignableToGroups}`,
    config: {
      headers: {},
    },
    requestTimeOutInterval: 40000,
    method: HttpMethod.GET,
  };

  return serviceRequest(servicesInfo).pipe(
    map((locationsData: AsyncResponse) => {
      if (locationsData) {
        const testCenter = locationsData.body?.response;
        let testCentersData = [];
        if (locationsData.status === AsyncResponseStatus.SUCCESS && locationsData.body) {
          testCentersData = (locationsData.body.response || []).map((location: Location) => {
            return { ...location, value: location.locationUuid, text: location.locationName };
          });
        }
        return {
          testCenter,
          response: testCentersData,
          transformedData: testCentersData,
          testCentersData,
          status: locationsData.status,
        };
      } else {
        return { testCenter: [], response: [], testCentersData: [], status: AsyncResponseStatus.ERROR };
      }
    }),
    filter((res) => res?.status !== AsyncResponseStatus.LOADING),
  );
};

export const getLocationName = (locationUuid: string, locationsResponse?: Location[]) => {
  if (locationsResponse) {
    return locationsResponse.find((location: Location) => locationUuid === location.locationUuid)?.locationName || '';
  }
  return '';
};
