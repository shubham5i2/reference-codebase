import { map } from 'rxjs/operators';
import { ServiceRequest } from '../../utils/ServiceRequest';
import { AsyncResponse, AsyncResponseStatus, HttpMethod } from '../../Models/Api';

import { DeleteBanDetails } from '../../../services/Models/TestTakerManagement';

export const deleteBan = (
  payload: DeleteBanDetails,
  serviceRequest: ServiceRequest,
  uniqueTestTakerUuid: string,
  bannedPeriodUuid: string,
) => {
  const getApiURL = () => {
    const baseUrl = '/v1/testtaker/bannedperiod';
    return `${baseUrl}/${uniqueTestTakerUuid}/${bannedPeriodUuid}`;
  };
  const servicesInfo = {
    name: 'Delete Ban',
    restUrl: getApiURL(),
    config: {
      headers: {},
    },
    method: HttpMethod.POST,
    body: payload,
  };

  return serviceRequest(servicesInfo).pipe(
    map((data: AsyncResponse) => {
      if (!data) {
        return { status: AsyncResponseStatus.ERROR };
      }
      const response = data?.body?.response;
      return { status: data.status, response };
    }),
  );
};
