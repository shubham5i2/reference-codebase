import { map, filter } from 'rxjs/operators';
import { ServiceRequest } from '../../utils/ServiceRequest';
import { User, UserStatus, ManageUserSearchPayload } from '../../Models/StaffManagement';
import { AsyncResponse, AsyncResponseStatus, HttpMethod } from '../../Models/Api';
import { languageService } from '../../Language/LanguageService';
import { getUserGroupAssignmentsName, getValue } from '../../../components/utils/utilities';

const profileColors = ['blue', 'skyBlue', 'green', 'orange'];
export const getColor = () => profileColors[Math.floor(Math.random() * Math.floor(profileColors.length))];

export const searchResult = (reqBody: ManageUserSearchPayload, serviceRequest: ServiceRequest) => {
  const smLabels = languageService().staffManagement;

  const servicesInfo = {
    name: 'Manage user search',
    restUrl: '/v1/users/search',
    config: {
      headers: {},
    },
    method: HttpMethod.POST,
    body: reqBody,
  };

  return serviceRequest(servicesInfo).pipe(
    map((data: AsyncResponse) => {
      if (!data || !data.body || !data.body.response) {
        return { status: AsyncResponseStatus.ERROR };
      }
      const { result } = data.body.response;

      const gridData = (result?.entries || []).map((user: User) => {
        return {
          name: [getValue(user.givenName).trim(), getValue(user.familyName).trim(), getColor()],
          staffId: getValue(user.userUuid),
          emailId: getValue(user.email),
          userGroups: getUserGroupAssignmentsName(user.userGroupAssignments),
          status: getValue(user.userStatus) === UserStatus.ACTIVE ? smLabels.active : smLabels.inActive,
        };
      });
      return { ...result, gridData, status: data.status };
    }),
    filter((data) => data.status !== AsyncResponseStatus.LOADING),
  );
};
