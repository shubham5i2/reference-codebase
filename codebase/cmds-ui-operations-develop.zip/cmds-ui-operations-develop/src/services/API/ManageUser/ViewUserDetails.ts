import { map } from 'rxjs/operators';
import { ServiceRequest } from '../../utils/ServiceRequest';
import { AsyncResponse, HttpMethod } from '../../Models/Api';
import { User, UserGroup } from '../../Models/StaffManagement';

export const getUserDetails = (userId: string, serviceRequest: ServiceRequest) => {
  const getAssignGroupData = (user: User) => {
    return user.userGroupAssignments?.map((item: UserGroup) => ({
      userGroup: item.userGroupUuid,
      dateRange: {
        startDate: new Date(item.effectiveFromDatetime || ''),
        endDate: new Date(item.effectiveToDatetime || ''),
      },
      location: item.locationUuid,
      userGroupAssignmentId: item.userGroupAssignmentUuid,
      userId: user.userUuid,
      locationName: item.locationName,
      userGroupName: item.userGroupName,
    }));
  };

  const sortUserGroup = (user: User) => {
    return user.userGroupAssignments?.sort((obj1, obj2) =>
      (obj1.userGroupName ? obj1.userGroupName.toLowerCase() : '') >
      (obj2.userGroupName ? obj2.userGroupName.toLowerCase() : '')
        ? 1
        : -1,
    );
  };

  const servicesInfo = {
    name: 'get users',
    restUrl: `/v1/users/${userId}`,
    config: {
      headers: {},
    },
    method: HttpMethod.GET,
    displayLoader: true,
  };

  return serviceRequest(servicesInfo).pipe(
    map((val: AsyncResponse) => {
      let user = val?.body?.response;
      if (user) {
        delete user.homeTestCentreUuid;
        const userGroupData = sortUserGroup(user);
        user.userGroupAssignments = userGroupData || [];
        const assignGroupData = getAssignGroupData(user) || [];
        user = {
          ...user,
          assignGroupData,
        };
      }
      return user;
    }),
  );
};
