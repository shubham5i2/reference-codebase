import { ServiceRequest } from '../../utils/ServiceRequest';
import { User } from '../../Models/StaffManagement';
import { map, filter } from 'rxjs/operators';
import { AsyncResponse, AsyncResponseStatus, HttpMethod } from '../../Models/Api';

export const addUserData = (method: HttpMethod, payLoad: User, serviceRequest: ServiceRequest, userId = '') => {
  const getApiURL = () => {
    const baseUrl = '/v1/users';
    return method === HttpMethod.PUT ? `${baseUrl}/${userId}` : baseUrl;
  };

  const servicesInfo = {
    name: 'User Group',
    restUrl: getApiURL(),
    config: {
      headers: {},
    },
    method: method,
    body: payLoad,
  };
  return serviceRequest(servicesInfo).pipe(
    map((res: AsyncResponse) => {
      if (!res) {
        return { status: AsyncResponseStatus.ERROR };
      }
      const user: User = res.body?.response || {};
      return { status: res.status, user };
    }),
    filter((res) => res.status !== AsyncResponseStatus.LOADING),
  );
};
