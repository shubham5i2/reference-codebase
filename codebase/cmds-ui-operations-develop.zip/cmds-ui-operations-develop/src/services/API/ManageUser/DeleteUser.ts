import { ServiceRequest } from '../../utils/ServiceRequest';
import { HttpMethod } from '../../Models/Api';

export const deleteUser = (userId: string, serviceRequest: ServiceRequest) => {
  const servicesInfo = {
    name: 'Delete user',
    restUrl: `/v1/users/${userId}`,
    config: {
      headers: {},
    },
    method: HttpMethod.DELETE,
  };

  return serviceRequest(servicesInfo);
};
