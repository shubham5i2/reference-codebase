import { map } from 'rxjs/operators';
import { ServiceRequest } from '../../utils/ServiceRequest';
import { AsyncResponse, AsyncResponseStatus, HttpMethod } from '../../Models/Api';
import { BanDetails } from '../../../components/Organisms/Ban/AddBan';

export const addUpdateBan = (payload: BanDetails, serviceRequest: ServiceRequest, uniqueTestTakerUuid: string) => {
  const getApiURL = () => {
    const baseUrl = '/v1/testtaker/bannedperiod';
    return `${baseUrl}/${uniqueTestTakerUuid}`;
  };

  const servicesInfo = {
    name: 'Add Ban',
    restUrl: getApiURL(),
    config: {
      headers: {},
    },
    method: HttpMethod.PUT,
    body: payload,
  };

  return serviceRequest(servicesInfo).pipe(
    map((data: AsyncResponse) => {
      if (!data) {
        return { status: AsyncResponseStatus.ERROR };
      }
      const response = data?.body?.response;
      return { status: data.status, response };
    }),
  );
};
