import { ServiceRequest } from '../../utils/ServiceRequest';
import { HttpMethod, AsyncResponse, AsyncResponseStatus } from '../../Models/Api';
import { map, filter } from 'rxjs/operators';
import {
  LocationChangeRequestPayload,
  AddressData,
  AddressType,
  LocationDetailsData,
  LocationType,
  AddressFormElements,
  ProductAuthorization,
} from '../../Models/LocationManagement';
import { transformRequestValueFromString } from '../../../components/utils/utilities';
import { TODAY, LONG_FUTURE_DATE } from '../../../constants/LocationManagement/LocationConstants';
import { OldAuthProd } from '../../../components/Pages/LocationManagement/addUpdateLocationPage/addUpdateLocationPage';

export const addUpdateLocationDetails = (data: LocationChangeRequestPayload, serviceRequest: ServiceRequest) => {
  const getApiURL = () => {
    const baseURL = '/v1/locations';
    return data.locationUuid ? `${baseURL}/${data.locationUuid}` : baseURL;
  };

  const servicesInfo = {
    name: 'Get Location Details',
    restUrl: getApiURL(),
    config: {
      headers: {},
    },
    method: data.locationUuid ? HttpMethod.PUT : HttpMethod.POST,
    body: {
      ...data,
      externalParentLocationUuid: transformRequestValueFromString(data.externalParentLocationUuid),
      activatedDate: transformRequestValueFromString(data.activatedDate),
    },
    displayLoader: true,
  };

  console.log('PAYLOAD!!! ', data);

  return serviceRequest(servicesInfo).pipe(
    map((res: AsyncResponse) => {
      if (!res) {
        return { status: AsyncResponseStatus.ERROR };
      }

      const location = res.body?.response || {};
      return { status: res.status, location };
    }),
    filter((res) => res.status !== AsyncResponseStatus.LOADING),
  );
};

export const createAddressData = (
  addressData: AddressData[],
  locationDetailsData: LocationDetailsData,
  isSameAsPostal: boolean,
) => {
  const postalAddress = addressData.find((item: AddressData) => item.addressTypeUuid === AddressType.POSTAL);
  const updatedAddressData = addressData.map((item: AddressData) => {
    if (isSameAsPostal && locationDetailsData.locationTypeCode !== LocationType.PHYSICAL_BUILDING) {
      if (item.addressTypeUuid === AddressType.PHYSICAL) {
        item = {
          ...postalAddress,
          [AddressFormElements.addressTypeUuid]: item.addressTypeUuid,
          [AddressFormElements.locationAddressUuid]: item.locationAddressUuid,
        } as AddressData;
      }
    }
    return item;
  });

  return updatedAddressData.filter(
    (item) =>
      !(
        item.addressTypeUuid === AddressType.POSTAL &&
        locationDetailsData.locationTypeCode === LocationType.PHYSICAL_BUILDING
      ),
  );
};

export const getProductAuth = (productUuid: string, effectiveFromDate = TODAY, effectiveToDate = LONG_FUTURE_DATE) => {
  return {
    productUuid: productUuid,
    effectiveFromDate,
    effectiveToDate,
  };
};

export const getProductsAuthPayload = (approvedProducts: ProductAuthorization[], prevProd: OldAuthProd) => {
  const findApprovedProdIdx = (prod: ProductAuthorization) =>
    approvedProducts.findIndex((newProd) => newProd.productUuid === prod.productUuid);
  if (prevProd.activeProd.length === 0 && prevProd.inActiveProd.length === 0) {
    return approvedProducts;
  }

  const updatedActiveProdInActiveProd = prevProd.inActiveProd.map((prod) => {
    const idx = findApprovedProdIdx(prod);
    // If the product is InActivated today and activated on same date. Then use same prod don't add a new one.
    if (idx !== -1 && prod.effectiveToDate === TODAY) {
      approvedProducts.splice(idx, 1);
      return { ...prod, effectiveToDate: LONG_FUTURE_DATE };
    }
    return prod;
  });

  const updatedActiveProd: ProductAuthorization[] = [];
  prevProd.activeProd.forEach((prod) => {
    const idx = findApprovedProdIdx(prod);
    if (idx === -1) {
      // Not found in the new prod[]. Should me marked as expired
      updatedActiveProd.push({
        ...prod,
        ...getProductAuth(prod.productUuid, prod.effectiveFromDate, TODAY),
      });
    } else {
      // PevProd found in the new prod[]. use the same
      updatedActiveProd.push(prod);
      approvedProducts.splice(idx, 1);
    }
  });
  return [...updatedActiveProdInActiveProd, ...updatedActiveProd, ...approvedProducts];
};
