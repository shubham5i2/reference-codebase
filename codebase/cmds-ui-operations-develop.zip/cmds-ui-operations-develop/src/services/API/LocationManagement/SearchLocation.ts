import { map, filter } from 'rxjs/operators';
import { ServiceRequest } from '../../utils/ServiceRequest';
import { AsyncResponse, AsyncResponseStatus, HttpMethod } from '../../Models/Api';
import { LocationSearchResultEntry, LocationType } from '../../Models/LocationManagement';
import { SortOptions, SortType } from '../../Models/UIModels';

type LocationSearchRequestData = {
  testCentreNumber?: string;
  locationName?: string;
  partnerCode?: string;
  status?: string;
  locationTypeCode?: LocationType;
  pageNumber?: number;
  pageSize?: number;
  sorting?: SortOptions;
};

export const searchLocation = (reqData: LocationSearchRequestData, serviceRequest: ServiceRequest) => {
  const servicesInfo = {
    name: 'Locations search',
    restUrl: `/v1/locations/search`,
    config: {
      headers: {},
    },
    method: HttpMethod.POST,
    requestTimeOutInterval: 40000,
    body: {
      criteria: {
        locationName: reqData.locationName,
        testCentreNumber: reqData.testCentreNumber,
        partnerCode: reqData.partnerCode,
        locationTypeCode: reqData.locationTypeCode || LocationType.TEST_CENTRE,
        status: reqData.status,
      },
      ...getPagination(reqData),
      ...getSorting(reqData),
    },
  };

  return serviceRequest(servicesInfo).pipe(
    map((data: AsyncResponse) => {
      if (!data || !data.body || !data.body.response) {
        return { status: AsyncResponseStatus.ERROR };
      }
      const entries = data.body.response;
      return {
        ...data.body.response,
        totalCount: data.body.meta.totalCount,
        status: data.status,
        response: entries,
        transformedData: (entries || []).map((entry: LocationSearchResultEntry) => ({
          ...entry,
          text: entry.locationName,
          value: entry.locationUuid,
        })),
      };
    }),
    filter((data) => data.status !== AsyncResponseStatus.LOADING),
  );
};

const getSorting = ({ sorting, locationTypeCode }: LocationSearchRequestData) => {
  let sortObj = sorting;
  if (!sorting) {
    sortObj = {
      sortBy: locationTypeCode === LocationType.PHYSICAL_BUILDING ? 'locationName' : 'testCentreNumber',
      sortType: SortType.ASCENDING,
    };
  }
  return { sorting: [sortObj] };
};

const getPagination = ({ pageNumber, pageSize }: LocationSearchRequestData) => {
  if (!pageSize) {
    return undefined;
  }
  return {
    pagination: {
      pageNumber: pageNumber,
      pageSize: pageSize,
    },
  };
};
