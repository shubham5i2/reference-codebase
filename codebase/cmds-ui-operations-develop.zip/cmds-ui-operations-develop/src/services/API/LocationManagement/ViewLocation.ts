import { ServiceRequest } from '../../utils/ServiceRequest';
import { HttpMethod, AsyncResponse, AsyncResponseStatus } from '../../Models/Api';
import { map, filter } from 'rxjs/operators';
import { ProductAuthorization, LocationType, AddressData } from '../../Models/LocationManagement';
import { cleanEmpty, isActiveToDate } from '../../../components/utils/utilities';
import { AddressType, initialAddressData } from '../../../constants/LocationManagement/LocationConstants';

export const getLocation = (locationUuid: string, serviceRequest: ServiceRequest) => {
  const servicesInfo = {
    name: 'View Location Details',
    restUrl: `/v1/locations/${locationUuid}`,
    config: {
      headers: {},
    },
    method: HttpMethod.GET,
    displayLoader: true,
  };
  return serviceRequest(servicesInfo).pipe(
    map((viewLocationResponse: AsyncResponse) => {
      if (
        viewLocationResponse &&
        viewLocationResponse.status === AsyncResponseStatus.SUCCESS &&
        viewLocationResponse.body
      ) {
        const data = cleanEmpty(viewLocationResponse.body.response);
        const { locationAddresses, approvedProducts, ...locationDetailsData } = data;

        /** To be Removed in future. */
        locationAddresses.find((item: AddressData) => item.addressTypeUuid === AddressType.POSTAL) === undefined &&
          locationDetailsData.locationTypeCode === LocationType.TEST_CENTRE &&
          locationAddresses.push(initialAddressData[0]);
        locationAddresses.find((item: AddressData) => item.addressTypeUuid === AddressType.PHYSICAL) === undefined &&
          locationAddresses.push(initialAddressData[1]);
        return {
          locationData: { locationDetailsData, locationAddresses, approvedProducts: getProducts(approvedProducts) },
          status: AsyncResponseStatus.SUCCESS,
        };
      } else {
        return { locationData: {}, status: AsyncResponseStatus.ERROR };
      }
    }),
    filter((res) => res?.status !== AsyncResponseStatus.LOADING),
  );
};

const getProducts = (authProducts: ProductAuthorization[] = []) => {
  const activeProd = (authProducts || []).filter((prod) => isActiveToDate(prod.effectiveToDate));
  const inActiveProd = (authProducts || []).filter((prod) => !isActiveToDate(prod.effectiveToDate));
  return {
    activeProd,
    inActiveProd,
  };
};
