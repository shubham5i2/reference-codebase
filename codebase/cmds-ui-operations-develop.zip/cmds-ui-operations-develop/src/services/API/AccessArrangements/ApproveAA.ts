import { ServiceRequest } from '../../utils/ServiceRequest';
import { HttpMethod, AsyncResponse, AsyncResponseStatus } from '../../Models/Api';
import { map } from 'rxjs/operators';

export const approveAA = (approvedRequest: any, serviceRequest: ServiceRequest) => {
  const servicesInfo = {
    name: 'Access Arrangement',
    restUrl: `/v1/accessArrangementApproved`,
    config: {
      headers: {},
    },
    method: HttpMethod.POST,
    displayLoader: true,
    body: approvedRequest,
  };
  return serviceRequest(servicesInfo).pipe(
    map((data: AsyncResponse) => {
      if (!data || !data.body || !data.body.response) {
        return {
          status: AsyncResponseStatus.ERROR,
          gridData: [],
        };
      }
      const result = data.body.response;
      return { ...result, status: data.status };
    }),
  );
};
