import { ServiceRequest } from '../../utils/ServiceRequest';
import { HttpMethod, AsyncResponse, AsyncResponseStatus } from '../../Models/Api';
import { map, filter } from 'rxjs/operators';
import { aaSearchData } from '../../../mocks/AccessArrangement/AccessArrangement';

export const searchAA = (searchCriteria: any, serviceRequest: ServiceRequest) => {
  const servicesInfo = {
    name: 'AA search',
    restUrl: `/v1/accessArrangementDetailsRequested`,
    config: {
      headers: {},
    },
    method: HttpMethod.POST,
    body: searchCriteria,
  };

  return serviceRequest(servicesInfo).pipe(
    map((data: AsyncResponse) => {
      console.log('data.body.response ', data);
      if (!data || !data.body || !data.body.response) {
        return {
          status: AsyncResponseStatus.ERROR,
          gridData: [],
        };
      }
      const { result } = data.body.response.search;
      return { ...result, gridData: data.body.response, status: data.status };
    }),
    filter((data) => data.status !== AsyncResponseStatus.LOADING),
  );
};

export const mockSearchAA = (caseNumber: string) => {
  const gridData = aaSearchData;
  const filteredData = gridData.filter((d: any) => d.caseNumber === caseNumber);
  console.log('filteredData ', filteredData);
  return {
    status: AsyncResponseStatus.SUCCESS,
    gridData: filteredData,
  };
};
