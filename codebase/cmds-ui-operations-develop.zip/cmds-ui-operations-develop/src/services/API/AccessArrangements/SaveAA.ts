import { ServiceRequest } from '../../utils/ServiceRequest';
import { HttpMethod, AsyncResponse, AsyncResponseStatus } from '../../Models/Api';
import { map, filter } from 'rxjs/operators';

export const saveAA = (saveRequest: any, serviceRequest: ServiceRequest) => {
  const servicesInfo = {
    name: 'AA save',
    restUrl: `/v1/accessArrangementRequested`,
    config: {
      headers: {},
    },
    method: HttpMethod.POST,
    displayLoader: true,
    body: saveRequest,
  };
  return serviceRequest(servicesInfo).pipe(
    map((data: AsyncResponse) => {
      if (!data || !data.body || !data.body.response) {
        return {
          status: AsyncResponseStatus.ERROR,
          gridData: [],
        };
      }
      const result = data.body.response;
      return { ...result, status: data.status };
    }),
    filter((data) => data.status !== AsyncResponseStatus.LOADING),
  );
};
