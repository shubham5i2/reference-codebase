import { map, filter } from 'rxjs/operators';
import { ServiceRequest } from '../../utils/ServiceRequest';
import { AsyncResponse, AsyncResponseStatus, HttpMethod } from '../../Models/Api';

export const getParentOrganisation = (serviceRequest: ServiceRequest, organisationId: string) => {
  const servicesInfo = {
    name: 'ParentOrganisation',
    restUrl: `/v1/ros/orgId/${organisationId}`,
    config: {
      headers: {},
    },
    method: HttpMethod.GET,
  };

  return serviceRequest(servicesInfo).pipe(
    map((parentOrganisationResponse: AsyncResponse) => {
      if (
        parentOrganisationResponse &&
        parentOrganisationResponse.status === AsyncResponseStatus.SUCCESS &&
        parentOrganisationResponse.body
      ) {
        const parentOrganisationData = parentOrganisationResponse.body.response;

        return { parentOrganisationData, status: AsyncResponseStatus.SUCCESS };
      } else {
        return { parentOrganisationData: [], status: AsyncResponseStatus.ERROR };
      }
    }),
    filter((res) => res?.status !== AsyncResponseStatus.LOADING),
  );
};
