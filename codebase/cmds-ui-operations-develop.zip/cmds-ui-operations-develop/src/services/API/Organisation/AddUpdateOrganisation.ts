import { ServiceRequest } from '../../utils/ServiceRequest';
import { map, filter } from 'rxjs/operators';
import { AsyncResponse, AsyncResponseStatus, HttpMethod } from '../../Models/Api';
import {
  OrganisationProfileData,
  ContactDetailsData,
  MinimumScoreData,
  OrganisationAddressData,
  MinimumScoreProductData,
  ContactType,
  AddressType,
  OrganisationType,
  LinkedOrganisationsResponse,
  LinkType,
  BandScore,
} from '../../Models/Organisation';
import { transformRequestValueFromString } from '../../../components/utils/utilities';

enum LinkedOrganisationsStatus {
  NO_CHANGE,
  PARENT_CHANGED,
  INVALID,
}

export type AddUpdateOrganisationData = {
  organisationProfile: OrganisationProfileData;
  contactDetails: ContactDetailsData;
  minimumScore: MinimumScoreData;
};

type ProductRequest = { minimumScoreValue: number; moduleTypeUuid: string; component: string };

export const addUpdateOrganisation = (data: AddUpdateOrganisationData, serviceRequest: ServiceRequest, id?: string) => {
  const getApiURL = () => {
    const baseURL = '/v1/ros';
    return !id ? baseURL : `${baseURL}/${id}`;
  };

  const servicesInfo = {
    name: 'Add Update Organisation',
    restUrl: getApiURL(),
    config: {
      headers: {},
    },
    method: id ? HttpMethod.PUT : HttpMethod.POST,
    body: getAddUpdateOrganisationPayload(data),
    displayLoader: true,
  };

  return serviceRequest(servicesInfo).pipe(
    map((res: AsyncResponse) => {
      if (!res || res.status == AsyncResponseStatus.ERROR) {
        return { status: AsyncResponseStatus.ERROR };
      }
      const organisation = res.body?.response || {};
      return { status: res.status, organisation };
    }),
    filter((res) => res.status !== AsyncResponseStatus.LOADING),
  );
};

const isContactAddressValid = (contact: OrganisationAddressData) => {
  return (
    !!contact.givenName ||
    !!contact.familyName ||
    !!contact.emailAddress ||
    !!contact.country?.value ||
    !!contact.jobTitle ||
    !!contact.title ||
    !!contact.region?.value ||
    !!contact.emailAddress ||
    !!contact.postalCode ||
    !!contact.city ||
    !!contact.addressOne ||
    !!contact.addressTwo ||
    !!contact.addressThree ||
    !!contact.addressFour ||
    !!contact.phoneNumber ||
    !!contact.contactUuid
  );
};

const getAddUpdateOrganisationPayload = (orgData: AddUpdateOrganisationData) => {
  const { organisationProfile, contactDetails, minimumScore } = orgData;
  const contactDetailAddresses = transFormAddresses(
    getSameAsAddressData([contactDetails.primaryContactAddress, contactDetails.adminContactAddress]).filter(
      (contact) => organisationProfile.organisationType.value !== OrganisationType.VO || isContactAddressValid(contact),
    ),
    true,
  ); // Filter applied for VO to remove empty address
  const organisationProfileAddresses = transFormAddresses(
    getSameAsAddressData([organisationProfile.mainAddress, organisationProfile.deliveryAddress]),
  );
  return {
    recognisingOrganisationUuid: transformRequestValueFromString(organisationProfile.recognisingOrganisationUuid),
    organisationId: transformRequestValueFromString(organisationProfile.organisationId),
    organisationName: transformRequestValueFromString(organisationProfile.organisationName),
    organisationTypeUuid: transformRequestValueFromString(organisationProfile.organisationType?.value),
    verificationStatus: transformRequestValueFromString(organisationProfile.verificationStatus.value)?.toUpperCase(),
    addresses: organisationProfileAddresses,
    partnerCode: transformRequestValueFromString(organisationProfile.partnerLead.value),
    partnerContact: transformRequestValueFromString(organisationProfile.partnerContact),
    methodOfDelivery: transformRequestValueFromString(organisationProfile.methodOfDelivery.value)?.toUpperCase(),
    sectorTypeUuid: transformRequestValueFromString(organisationProfile.sectorType.value),
    organisationStatus: organisationProfile.organisationStatus ? 'ACTIVE' : 'INACTIVE',
    parentRecognisingOrganisationUuid: transformRequestValueFromString(organisationProfile.replaceById),
    websiteUrl: transformRequestValueFromString(organisationProfile.websiteUrl),
    organisationCode: transformRequestValueFromString(organisationProfile.code),
    ieltsDisplayFlag: organisationProfile.ieltsDisplayFlag,
    orsDisplayFlag: organisationProfile.orsDisplayFlag,
    resultAvailableForYears: +organisationProfile.resultAvailableForYears.value,
    linkedOrganisations: getNewLinkedOrganisations(organisationProfile).linkedOrganisations,
    crmSystem: transformRequestValueFromString(organisationProfile.crmSystem),
    notes: organisationProfile.notes,
    alternateNames: organisationProfile.alternateNames?.filter((nameObj) => !!nameObj.name),
    contacts: contactDetailAddresses,
    acceptsIOL: organisationProfile.acceptIOL,
    acceptsSSR: organisationProfile.acceptSSR,
    acceptsAC: organisationProfile.acceptAC,
    acceptsGT: organisationProfile.acceptGT,
    minimumScores: getMinimumscore(minimumScore),
  };
};

const transFormAddresses = (addressesData: OrganisationAddressData[], isContactAddress = false) => {
  return addressesData.map((addressData) => {
    const addressDetail = {
      addressTypeUuid: addressData.addressTypeUuid,
      addressUuid: transformRequestValueFromString(addressData.addressUuid),
      addressLine1: transformRequestValueFromString(addressData.addressOne),
      addressLine2: transformRequestValueFromString(addressData.addressTwo),
      addressLine3: transformRequestValueFromString(addressData.addressThree),
      addressLine4: transformRequestValueFromString(addressData.addressFour),
      city: transformRequestValueFromString(addressData.city),
      territoryUuid: transformRequestValueFromString(addressData.region?.value),
      countryUuid: transformRequestValueFromString(addressData.country?.value),
      postalCode: transformRequestValueFromString(addressData.postalCode),
      email: transformRequestValueFromString(addressData.emailAddress),
      phone: transformRequestValueFromString(addressData.phoneNumber),
    };
    if (isContactAddress) {
      return {
        firstName: transformRequestValueFromString(addressData.givenName),
        lastName: transformRequestValueFromString(addressData.familyName),
        contactTypeUuid: transformRequestValueFromString(addressData.contactTypeUuid),
        contactUuid: transformRequestValueFromString(addressData.contactUuid),
        effectiveFromDateTime: '2020-11-23T05:52:55.659Z',
        effectiveToDateTime: '2030-11-23T05:52:55.659Z',
        addresses: [addressDetail],
        jobTitle: transformRequestValueFromString(addressData.jobTitle),
        title: transformRequestValueFromString(addressData.title),
      };
    } else {
      return addressDetail;
    }
  });
};

// Helps to handle same as Main address and same as primary contact address
const getSameAsAddressData = (addressesData: OrganisationAddressData[]) => {
  const updatedAddress: OrganisationAddressData[] = [];
  let commonAddress: OrganisationAddressData | null = null;
  addressesData.forEach((address) => {
    if (address.isRequired) {
      updatedAddress.push(address);
      commonAddress = {
        ...address,
      };
      address.contactTypeUuid
        ? (commonAddress.contactTypeUuid = ContactType.RESULTADMIN)
        : (commonAddress.addressTypeUuid = AddressType.DELIVERY);
    } else if (commonAddress) {
      updatedAddress.push({
        ...commonAddress,
        addressUuid: address.addressUuid,
        contactUuid: address.contactUuid,
      });
    }
  });
  return updatedAddress;
};

const getMinimumscore = (minimumscoreData: MinimumScoreData) => {
  const getProduct = (component: string, product: MinimumScoreProductData, scoreDetail?: BandScore) => ({
    moduleTypeUuid: product.moduleTypeUuid,
    component,
    minimumScoreValue: Number(scoreDetail?.actualScore?.value),
    minimumScoreUuid: scoreDetail?.minimumScoreUuid,
  });

  let minimumScoreProducts: ProductRequest[] = [];
  Object.keys(minimumscoreData).forEach((productKey) => {
    const currentProduct = minimumscoreData[productKey];
    minimumScoreProducts = [
      ...minimumScoreProducts,
      getProduct('ALL', currentProduct, currentProduct.overallScore),
      getProduct('W', currentProduct, currentProduct.writing),
      getProduct('L', currentProduct, currentProduct.listening),
      getProduct('R', currentProduct, currentProduct.reading),
      getProduct('S', currentProduct, currentProduct.speaking),
    ];
  });
  return minimumScoreProducts.filter((product) => !!product.minimumScoreValue);
};

const getLinkedOrganisation = (
  targetRecognisingOrganisationUuid: string | undefined,
  targetRecognisingOrganisationName: string | undefined,
  linkType: LinkType,
  linkedRecognisingOrganisationUuid?: string,
  linkEffectiveFromDateTime?: string,
  linkEffectiveToDateTime?: string,
) => ({
  linkedRecognisingOrganisationUuid: linkedRecognisingOrganisationUuid,
  targetRecognisingOrganisationName: targetRecognisingOrganisationName,
  targetRecognisingOrganisationUuid: targetRecognisingOrganisationUuid,
  linkType: linkType,
  linkEffectiveFromDateTime: linkEffectiveFromDateTime || new Date().toISOString(),
  linkEffectiveToDateTime: linkEffectiveToDateTime || '2099-12-31T23:59:59.000Z',
});

const getNewLinkedOrganisations = (organisationProfile: OrganisationProfileData) => {
  let isHierarchyChanged = false; // No longer used
  let isParentChangedOrRemoved = false; // Needed to display the warning meassage when updating
  const linkedOrganisations = organisationProfile.linkedOrganisations || [];
  const additionalDeliveryOrganisations = { ...organisationProfile.additionalDeliveryOrganisation } || {};
  const updatedLinkedOrganisations = linkedOrganisations.map((linkedOrg: LinkedOrganisationsResponse) => {
    const isOrgAvailable = additionalDeliveryOrganisations[linkedOrg.targetRecognisingOrganisationUuid || ''];
    const isParent = linkedOrg.linkType === LinkType.parentRo;

    if (
      isParent &&
      organisationProfile.parentOrganisationUuid &&
      organisationProfile.parentOrganisationUuid !== linkedOrg.targetRecognisingOrganisationUuid
    ) {
      isParentChangedOrRemoved = true;
      return transformLinkedOrganisationFromStatus(
        LinkedOrganisationsStatus.PARENT_CHANGED,
        linkedOrg,
        organisationProfile.parentOrganisationUuid,
        organisationProfile.parentOrganisationName,
      );
    } else if (isParent && !organisationProfile.parentOrganisationUuid) {
      // Invalidate the linked org when parent is removed
      isParentChangedOrRemoved = true;
      return transformLinkedOrganisationFromStatus(LinkedOrganisationsStatus.INVALID, linkedOrg);
    } else if (isParent) {
      return transformLinkedOrganisationFromStatus(LinkedOrganisationsStatus.NO_CHANGE, linkedOrg);
    } else if (!isParent && isOrgAvailable) {
      delete additionalDeliveryOrganisations[linkedOrg.targetRecognisingOrganisationUuid || ''];
      return transformLinkedOrganisationFromStatus(LinkedOrganisationsStatus.NO_CHANGE, linkedOrg);
    } else {
      isHierarchyChanged = true;
      delete additionalDeliveryOrganisations[linkedOrg.targetRecognisingOrganisationUuid || ''];
      return transformLinkedOrganisationFromStatus(LinkedOrganisationsStatus.INVALID, linkedOrg);
    }
  });
  const parentLength = linkedOrganisations.filter((linkedOrg) => linkedOrg.linkType === LinkType.parentRo).length;
  if (parentLength === 0 && organisationProfile.parentOrganisationUuid) {
    // Add parent in case of parent not present
    updatedLinkedOrganisations.push(
      getLinkedOrganisation(
        organisationProfile.parentOrganisationUuid,
        organisationProfile.parentOrganisationName,
        LinkType.parentRo,
      ),
    );
  }
  Object.keys(additionalDeliveryOrganisations).forEach((newlySelectedOrgKey) => {
    // Added new addtional delv one's
    newlySelectedOrgKey &&
      updatedLinkedOrganisations.push(
        getLinkedOrganisation(
          additionalDeliveryOrganisations[newlySelectedOrgKey].value,
          additionalDeliveryOrganisations[newlySelectedOrgKey].text,
          LinkType.resultsDelivery,
        ),
      );
  });
  return { linkedOrganisations: updatedLinkedOrganisations, isHierarchyChanged, isParentChangedOrRemoved };
};

const transformLinkedOrganisationFromStatus = (
  status: LinkedOrganisationsStatus,
  linkedOrg: LinkedOrganisationsResponse,
  parentOrganisationUuid?: string,
  parentOrganisationName?: string,
) => {
  switch (status) {
    case LinkedOrganisationsStatus.NO_CHANGE: {
      return { ...linkedOrg };
    }
    case LinkedOrganisationsStatus.PARENT_CHANGED: {
      return getLinkedOrganisation(
        parentOrganisationUuid,
        parentOrganisationName,
        LinkType.parentRo,
        linkedOrg.linkedRecognisingOrganisationUuid,
      );
    }
    case LinkedOrganisationsStatus.INVALID: {
      return {
        ...linkedOrg,
        linkEffectiveToDateTime: new Date().toISOString(),
      };
    }
  }
};

export const getIsParentChangedOrRemoved = (organisationProfile: OrganisationProfileData) => {
  return getNewLinkedOrganisations(organisationProfile).isParentChangedOrRemoved;
};
