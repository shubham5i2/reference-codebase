import { map } from 'rxjs/operators';
import { ServiceRequest } from '../../utils/ServiceRequest';
import { AsyncResponse, HttpMethod } from '../../Models/Api';
import { initialMinimumScore } from '../../../components/Templates/Organisation/OrganisationConstants';
import {
  OrganisationResponseData,
  AddressType,
  OrganisationAddressData,
  OrganisationAddressResponse,
  OrganisationContactResponse,
  ContactType,
  OrganisationMinimumScoreResponse,
  MinimumScoreModuleType,
} from '../../Models/Organisation';
import { getValue } from '../../../components/utils/utilities';
import { deilveryOptions } from '../../../constants/Organisation';

export const getOrganisation = (orgId: string, serviceRequest: ServiceRequest) => {
  const servicesInfo = {
    name: 'Get Organisation',
    restUrl: `/v1/ros/${orgId}`,
    config: {
      headers: {},
    },
    method: HttpMethod.GET,
    displayLoader: true,
  };

  return serviceRequest(servicesInfo).pipe(
    map((val: AsyncResponse) => {
      let organisation = val?.body?.response;
      if (organisation) {
        organisation = getOrganisationFromResponse(organisation);
      }
      return organisation;
    }),
  );
};

const isBothACGTOff = (orgData: OrganisationResponseData) => !orgData.acceptsAC && !orgData.acceptsGT;

const getOrganisationFromResponse = (response: OrganisationResponseData) => {
  const parentOrganisationDetails = response.linkedOrganisations?.filter(
    (organisation) => organisation.linkType === 'PARENT_RO',
  );
  const additionalDeliveryOrganisationDetails =
    response.linkedOrganisations?.filter((organisation) => organisation.linkType === 'RESULTS_DELIVERY') || [];

  const additionalDeliveryOrganisation: any = {};

  const getDictonaryKeys = (obj: Record<string, any>) => Object.keys(obj);

  getDictonaryKeys(additionalDeliveryOrganisationDetails).forEach((key: any) => {
    if (additionalDeliveryOrganisationDetails[key].targetRecognisingOrganisationUuid) {
      // eslint-disable-next-line  @typescript-eslint/no-non-null-assertion
      additionalDeliveryOrganisation[additionalDeliveryOrganisationDetails[key].targetRecognisingOrganisationUuid!] = {
        text: additionalDeliveryOrganisationDetails[key].targetRecognisingOrganisationName,
        value: additionalDeliveryOrganisationDetails[key].targetRecognisingOrganisationUuid,
      };
    }
  });

  return {
    organisationDetail: {
      organisationId: getValue(response.organisationId),
      organisationName: getValue(response.organisationName),
      organisationStatus: getValue(response.organisationStatus) === 'ACTIVE',
      organisationType: {
        text: getValue(response.organisationType),
        value: getValue(response.organisationTypeUuid),
      },
      verificationStatus: {
        text: getValue(response.verificationStatus.toLowerCase()),
        value: getValue(response.verificationStatus),
      },
      mainAddress: getAddress(AddressType.MAIN, response.addresses),
      deliveryAddress: getAddress(AddressType.DELIVERY, response.addresses),
      partnerLead: { text: getValue(response.partnerName), value: getValue(response.partnerCode) },
      methodOfDelivery: deilveryOptions[getValue(response.methodOfDelivery.toUpperCase())],
      sectorType: { text: getValue(response.sectorType), value: getValue(response.sectorTypeUuid) },
      acceptIOL: response.acceptsIOL,
      acceptSSR: response.acceptsSSR,
      acceptAC: isBothACGTOff(response) ? true : response.acceptsAC,
      acceptGT: isBothACGTOff(response) ? true : response.acceptsGT,
      websiteUrl: getValue(response.websiteUrl),
      alternateNames: [...(response.alternateNames || []), { name: '' }],
      code: getValue(response.organisationCode),
      resultAvailableForYears: {
        text: getValue(response.resultAvailableForYears?.toString()),
        value: getValue(response.resultAvailableForYears?.toString(), '2'),
      },
      notes: response.notes || [],
      partnerContact: getValue(response.partnerContact),
      replaceById: getValue(response.replacedByRecognisingOrganisationUuid),
      recognisingOrganisationUuid: response.recognisingOrganisationUuid,
      crmSystem: getValue(response.crmSystem),
      ieltsDisplayFlag: response.ieltsDisplayFlag,
      orsDisplayFlag: response.orsDisplayFlag,
      linkedOrganisations: response.linkedOrganisations,
      parentOrganisationId: getValue(response.parentOrgId),
      parentOrganisationName: parentOrganisationDetails
        ? parentOrganisationDetails[0]?.targetRecognisingOrganisationName
        : '',
      parentOrganisationUuid: parentOrganisationDetails
        ? parentOrganisationDetails[0]?.targetRecognisingOrganisationUuid
        : '',
      additionalDeliveryOrganisation: additionalDeliveryOrganisation,
    },
    contactDetail: {
      primaryContactAddress: getContactAddress(ContactType.PRIMARY, response.contacts),
      adminContactAddress: getContactAddress(ContactType.RESULTADMIN, response.contacts),
    },
    minimumScore: {
      ...initialMinimumScore,
      ieltsAcademic: {
        ...initialMinimumScore.ieltsAcademic,
        ...getLRWSValues(MinimumScoreModuleType.ACADEMIC, response.minimumScores),
      },
      ieltsTraining: {
        ...initialMinimumScore.ieltsTraining,
        ...getLRWSValues(MinimumScoreModuleType.TRAINING, response.minimumScores),
      },
    },
    currentRoID: getValue(response.recognisingOrganisationUuid),
  };
};

const getLRWSValues = (
  moduleType: MinimumScoreModuleType,
  orgMinimumScoreResponse?: OrganisationMinimumScoreResponse[],
) => {
  const orgMinimumScoreRes = (orgMinimumScoreResponse || []).filter(
    (minScore) => minScore.moduleTypeUuid === moduleType,
  );
  const getMinScoreObject = (minScoreResponse?: OrganisationMinimumScoreResponse) => {
    return {
      minimumScoreUuid: minScoreResponse?.minimumScoreUuid,
      actualScore: {
        text: getValue(minScoreResponse?.minimumScoreValue.toString()),
        value: getValue(minScoreResponse?.minimumScoreValue.toString()),
      },
    };
  };
  const reading = orgMinimumScoreRes.find((minScore) => minScore.component.toUpperCase() === 'R');
  const writing = orgMinimumScoreRes.find((minScore) => minScore.component.toUpperCase() === 'W');
  const listening = orgMinimumScoreRes.find((minScore) => minScore.component.toUpperCase() === 'L');
  const speaking = orgMinimumScoreRes.find((minScore) => minScore.component.toUpperCase() === 'S');
  const overallScore = orgMinimumScoreRes.find((minScore) => minScore.component.toUpperCase() === 'ALL');
  return {
    listening: {
      ...initialMinimumScore.ieltsTraining.listening,
      ...getMinScoreObject(listening),
    },
    reading: {
      ...initialMinimumScore.ieltsTraining.reading,
      ...getMinScoreObject(reading),
    },
    writing: {
      ...initialMinimumScore.ieltsTraining.writing,
      ...getMinScoreObject(writing),
    },
    speaking: {
      ...initialMinimumScore.ieltsTraining.speaking,
      ...getMinScoreObject(speaking),
    },
    overallScore: {
      ...initialMinimumScore.ieltsTraining.overallScore,
      ...getMinScoreObject(overallScore),
    },
  };
};

const getAddress = (
  addressType: AddressType,
  addressResponse?: OrganisationAddressResponse[],
): OrganisationAddressData => {
  const address = (addressResponse || []).find((address) => address.addressTypeUuid === addressType);
  return {
    addressUuid: getValue(address?.addressUuid),
    addressTypeUuid: addressType,
    isRequired: !!address,
    addressOne: getValue(address?.addressLine1),
    addressTwo: getValue(address?.addressLine2),
    addressThree: getValue(address?.addressLine3),
    addressFour: getValue(address?.addressLine4),
    city: getValue(address?.city),
    postalCode: getValue(address?.postalCode),
    emailAddress: getValue(address?.email),
    phoneNumber: getValue(address?.phone),
    country: { value: getValue(address?.countryUuid), text: getValue(address?.country) },
    region: { value: getValue(address?.territoryUuid), text: getValue(address?.territory) },
  };
};

const getContactAddress = (contactType: ContactType, contactResponse?: OrganisationContactResponse[]) => {
  const contactAddress = (contactResponse || []).find((contact) => contact.contactTypeUuid === contactType);
  const isRequired = contactType !== ContactType.PRIMARY ? !!contactAddress : true;
  return {
    contactTypeUuid: contactType,
    givenName: getValue(contactAddress?.firstName),
    familyName: getValue(contactAddress?.lastName),
    ...getAddress(AddressType.MAIN, contactAddress?.addresses),
    isRequired,
    contactUuid: getValue(contactAddress?.contactUuid),
    title: getValue(contactAddress?.title),
    jobTitle: getValue(contactAddress?.jobTitle),
  };
};
