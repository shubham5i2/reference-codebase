import { map, filter } from 'rxjs/operators';
import { ServiceRequest } from '../../utils/ServiceRequest';
import { AsyncResponse, AsyncResponseStatus, HttpMethod } from '../../Models/Api';
import { AdditionalDeliveryOrganisationResponse } from '../../Models/ReferenceModals';
import { sortValues } from '../../../components/utils/utilities';

export const getAdditionalDeliveryOrganisation = (
  serviceRequest: ServiceRequest,
  parentRecognisingOrganisationUuid = '',
  recognisingOrganisationUuid = parentRecognisingOrganisationUuid,
  onlyImmediateChildren = false,
) => {
  const servicesInfo = {
    name: 'AdditionalDeliveryOrganisation',
    restUrl: `/v1/ros/hierarchy?recognisingOrganisationUuid=${recognisingOrganisationUuid}&parentROUuid=${parentRecognisingOrganisationUuid}&onlyImmediateChildren=${onlyImmediateChildren}`,
    config: {
      headers: {},
    },
    method: HttpMethod.GET,
  };

  return serviceRequest(servicesInfo).pipe(
    map((additionalDeliveryOrganisationResponse: AsyncResponse) => {
      if (
        additionalDeliveryOrganisationResponse &&
        additionalDeliveryOrganisationResponse.status === AsyncResponseStatus.SUCCESS &&
        additionalDeliveryOrganisationResponse.body
      ) {
        const additionalDeliveryOrganisationData = (additionalDeliveryOrganisationResponse.body.response || []).map(
          (additionalDeliveryOrganisation: AdditionalDeliveryOrganisationResponse) => {
            return {
              value: additionalDeliveryOrganisation.recognisingOrganisationUuid,
              text: additionalDeliveryOrganisation.name,
            };
          },
        );
        // using predefined sorting function
        const additionalDeliveryOrgSortedList = sortValues(additionalDeliveryOrganisationData);
        return {
          additionalDeliveryOrganisationData: additionalDeliveryOrgSortedList,
          status: AsyncResponseStatus.SUCCESS,
        };
      } else {
        return { additionalDeliveryOrganisationData: [], status: AsyncResponseStatus.ERROR };
      }
    }),
    filter((res) => res?.status !== AsyncResponseStatus.LOADING),
  );
};
