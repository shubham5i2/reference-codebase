import React, { useState, useEffect } from 'react';
import { useAuth0, withAuthenticationRequired } from '@auth0/auth0-react';

import AuthorizedApp from './components/Pages/App/AuthorizedApp';
import UnAuthorizedApp from './components/Pages/App/UnAuthorizedApp';

export function App() {
  const [accessToken, setAccessToken] = useState('');

  const { isAuthenticated, error, getAccessTokenSilently } = useAuth0();

  console.log('App started loading.....');

  useEffect(() => {
    const getAccessToken = async () => {
      if (isAuthenticated) {
        const token = await getAccessTokenSilently({ audience: process.env.REACT_APP_REST_BASE_AUDIENCE });
        token && setAccessToken(token);
      }
    };
    getAccessToken();
  }, [isAuthenticated, getAccessTokenSilently]);

  if (accessToken.length > 0 && isAuthenticated && !error) {
    return <AuthorizedApp accessToken={accessToken} />;
  }

  return <UnAuthorizedApp />;
}

export default withAuthenticationRequired(App, {});
