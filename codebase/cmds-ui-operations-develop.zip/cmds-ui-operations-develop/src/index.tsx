// @ts-nocheck
import React from 'react';
import { render } from 'react-dom';
import './index.scss';
import { Auth0Provider } from '@auth0/auth0-react';
import { createBrowserHistory } from 'history';

import App from './App';
import { BrowserRouter as Router } from 'react-router-dom';

export const history = createBrowserHistory();

const rootElement = document.getElementById('root');
render(
  <Auth0Provider
    domain={process.env.REACT_APP_DOMAIN}
    clientId={process.env.REACT_APP_ClientID}
    redirectUri={window.location.origin}
    scope={'openid profile email'}
    audience={process.env.REACT_APP_REST_BASE_AUDIENCE}
    useRefreshTokens
    onRedirectCallback={() => history.replace('')}
  >
    <Router>
      <App />
    </Router>
  </Auth0Provider>,
  rootElement,
);
