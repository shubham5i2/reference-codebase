import { CurrentResultStatus } from '../../services/Models/Result';
import { TestTakerBookingHistoryResponse } from '../../services/Models/TestTakerManagement';

export const initialCurrentResultStatus: CurrentResultStatus = {
  onHold: false,
  resultsStatusHistoryUuid: '',
  resultStatusTypeUuid: '',
  resultStatusLabelUuid: '',
  resultStatusLabel: '',
  resultStatusComment: '',
  resultStatusCommentUuid: '',
  resultStatusUpdateDatetime: '',
  resultStatusUpdatedBy: '',
  resultStatusType: '',
};

export const initialBookingHistoryData: TestTakerBookingHistoryResponse = {
  uniqueTestTakerId: '',
  uniqueTestTakerUuid: '',
  bookingHistory: [
    {
      bookingUuid: '',
      bookingDetails: {
        testTakerInfo: {
          firstName: '',
          lastName: '',
          birthDate: '',
          email: '',
          identityNumber: '',
          nationality: '',
        },
        testBookingInfo: {
          testDate: '',
          testCentre: '',
          product: '',
          productUuid: '',
          testCentreNumber: '',
          testCentreName: '',
          testCentreUuid: '',
          locationName: '',
          locationUuid: '',
        },
        resultStatusInfo: {
          resultStatus: '',
          resultStatusLabel: '',
          resultStatusComment: '',
          resultStatusDate: '',
          banStatus: '',
        },
        bookingOtherInfo: {
          matchDate: '',
          matchEvent: '',
          notes: '',
          Notes: '',
        },
      },
    },
  ],
  testtakerBanInfo: [],
  exclusionList: [],
};
