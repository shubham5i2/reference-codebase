export const BASIC = 'basicSearch';
export const ADVANCE = 'advanceSearch';
export const DUPLICATE = 'duplicateSearch';
export const DEFAULT = 'defaultSearch';
