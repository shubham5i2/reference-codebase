export const DEFAULT_TOAST_MESSAGE_TIMER = 5000;
export const DEFAULT_WEBSOCKET_TIMEOUT_INTERVAL = 40000;
export const DEFAULT_WEBSOCKET_TIMEOUT_CHECK_INTERVAL = 5000;
export const DEFAULT_WEBSOCKET_CONNECTION_ATTEMPTS = 15;

export const DEFAULT_PAGE_SIZE_OPTIONS = [
  { text: '10', value: 10 },
  { text: '25', value: 25 },
  { text: '50', value: 50 },
];

export const ROLES_KEY = 'https://cmdsiz.com/roles';
