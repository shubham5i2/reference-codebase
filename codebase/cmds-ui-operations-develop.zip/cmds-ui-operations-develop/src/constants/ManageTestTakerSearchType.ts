export const BASIC = 'basicSearch';
export const ADVANCE = 'advanceSearch';
export const DEFAULT = 'defaultSearch';
