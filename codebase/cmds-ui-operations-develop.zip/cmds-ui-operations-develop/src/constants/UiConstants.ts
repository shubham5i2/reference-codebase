import { languageService } from '../services/Language/LanguageService';

const organisationLabels = languageService().common;

export const TOGGLESWITCH = {
  [organisationLabels.yes]: true,
  [organisationLabels.no]: false,
};

export const ACTIVESWITCH = {
  [organisationLabels.active]: true,
  [organisationLabels.inActive]: false,
};
