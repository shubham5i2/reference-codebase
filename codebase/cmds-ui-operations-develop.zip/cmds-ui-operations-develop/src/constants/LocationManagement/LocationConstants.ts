import {
  AddressData,
  LocationDetailsData,
  LocationSearchCriteria,
  actionType,
  LocationSearchResult,
  LocationGridCellType,
  LocationStatus,
} from '../../services/Models/LocationManagement';
import { FormError } from '../../services/Models/UIModels';
import { languageService } from '../../services/Language/LanguageService';
import EditIcon from '../../assets/images/Edit.svg';
import visibilityIcon from '../../assets/images/visibility.svg';
import { formatDate } from '../../components/utils/utilities';

export const initialDropDownDataSource = { text: '', value: '' };
const locationLabels = languageService().locationManagement;
const commonLables = languageService().common;

export enum AddressType {
  POSTAL = 'cb3c2358-a932-4d12-90ab-e4c94fbf9fe3',
  PHYSICAL = '8b563242-dbbe-4625-b727-c3aba52a8b96',
}

const addressData = {
  territoryUuid: '',
  territoryName: '',
  countryName: '',
  countryUuid: '',
  addressLine1: '',
  addressLine2: '',
  addressLine3: '',
  addressLine4: '',
  city: '',
  postalCode: '',
  primaryPhone: '',
  secondaryPhone: '',
  email: '',
  effectiveFromDate: new Date().toISOString().substring(0, 10),
  effectiveToDate: '2099-12-31',
};

export const initialAddressData: AddressData[] = [
  {
    addressTypeUuid: AddressType.POSTAL,
    ...addressData,
  },
  {
    addressTypeUuid: AddressType.PHYSICAL,
    ...addressData,
  },
];
export const initialAddressErrorData: any = [
  {
    addressTypeUuid: AddressType.POSTAL,
    ...addressData,
  },
  {
    addressTypeUuid: AddressType.PHYSICAL,
    ...addressData,
  },
];

export const initialTerritoryDataSource = {
  territoryUuid: '',
  territoryName: '',
};
export const initialCountryDataSource = {
  countryUuid: '',
  countrName: '',
};

export interface LocationtDataError {
  [key: string]: FormError;
}

export const initialLocationDetailsData: LocationDetailsData = {
  parentLocationUuid: '',
  parentLocationName: '',
  partnerCode: '',
  partnerCodeText: '',
  locationTypeCode: '',
  locationTypeCodeText: '',
  locationName: '',
  externalLocationUuid: '',
  externalParentLocationUuid: '',
  locationStatus: LocationStatus.PENDING,
  testCentreNumber: '',
  activatedDate: '',
  eligibleForOfflineTesting: false,
  timezoneName: '',
  websiteURL: '',
};

export const initialBasicSearchData: LocationSearchCriteria = {
  testCentreNumber: '',
  testCentreUuid: '',
  locationName: '',
  partnerCode: '',
  status: '',
};

export const initialLocationSearchResultData: LocationSearchResult = {
  LocationGridData: [],
  totalCount: 0,
};

export const pageSizeOptions = [
  { text: '10', value: 10 },
  { text: '25', value: 25 },
  { text: '50', value: 50 },
];

const locationActionFilter = (option: { type: actionType }, isLMPatnerUser: boolean) =>
  isLMPatnerUser ? option.type !== actionType.UPDATE : !isLMPatnerUser;

export const actions = (isLMPatnerUser: boolean) =>
  [
    { label: commonLables.viewDetails, type: actionType.VIEW_DETAILS, icon: visibilityIcon },
    { label: locationLabels.viewPhysicalBuildings, type: actionType.VIEW_PHYSICAL_BUILDING, icon: visibilityIcon },
    { label: locationLabels.updateLocation, type: actionType.UPDATE, icon: EditIcon },
  ].filter((option) => locationActionFilter(option, isLMPatnerUser));

export const buildingsActions = (isLMPatnerUser: boolean) =>
  [
    { label: commonLables.viewDetails, type: actionType.VIEW_DETAILS, icon: visibilityIcon },
    { label: locationLabels.updateLocation, type: actionType.UPDATE, icon: EditIcon },
  ].filter((option) => locationActionFilter(option, isLMPatnerUser));

const startdate = new Date();
export const TODAY = formatDate(new Date(), 'yyyy-MM-dd');
export const LONG_FUTURE_DATE = formatDate(new Date(2099, 11, 31), 'yyyy-MM-dd');
export const currentdate = formatDate(startdate, locationLabels.inputDateFormat);

export const defaultOldAuthProd = { activeProd: [], inActiveProd: [] };

export const defaultSortType = {
  sortType: 'ASC',
  sortBy: 'testCentreNumber',
};

export const defaultBuildingSortType = {
  sortType: 'ASC',
  sortBy: LocationGridCellType.LOCATION_NAME,
};
