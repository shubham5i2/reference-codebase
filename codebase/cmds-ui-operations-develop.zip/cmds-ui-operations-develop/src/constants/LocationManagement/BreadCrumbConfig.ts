import locationmanagementLabels from '../../services/Language/en/en.locationmanagement';
import { BreadCrumbRoute } from '../../components/Organisms/BreadCrumbHandler/BreadCrumbHandler';

export default [
  {
    path: '/locationManagement',
    breadCrumbLabel: locationmanagementLabels.headerTitle,
  },
  {
    path: '/locationManagement/addlocation',
    breadCrumbLabel: locationmanagementLabels.addLocation,
  },
  {
    path: '/locationManagement/viewbuildings/:id',
    breadCrumbLabel: locationmanagementLabels.viewPhysicalBuildings,
  },
  {
    path: '/locationManagement/updatelocation/:id',
    breadCrumbLabel: locationmanagementLabels.updateLocationTitle,
  },
  {
    path: '/locationManagement/viewbuildings/:id/updatelocation/:id',
    breadCrumbLabel: locationmanagementLabels.updateBuildingTitle,
  },
  {
    path: '/locationManagement/viewlocation/:id',
    breadCrumbLabel: locationmanagementLabels.viewLocation,
  },

  {
    path: '/locationManagement/viewbuildings/viewDetails/:id',
    breadCrumbLabel: locationmanagementLabels.viewLocation,
  },
] as BreadCrumbRoute[];
