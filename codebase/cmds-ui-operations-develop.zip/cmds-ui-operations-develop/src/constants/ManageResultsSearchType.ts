import { ComponentsList } from '../services/Models/Result';

export const BASIC = 'basicSearch';
export const ADVANCE = 'advanceSearch';
export const DEFAULT = 'defaultSearch';

export const componentsList: ComponentsList = {
  L: 'listening',
  R: 'reading',
  W: 'writing',
  S: 'speaking',
};
