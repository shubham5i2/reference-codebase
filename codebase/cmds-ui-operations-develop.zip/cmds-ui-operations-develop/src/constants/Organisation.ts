import { languageService } from '../services/Language/LanguageService';

const commonLabels = languageService().common;

export const POSTAL_MOD = { value: 'POSTAL', text: commonLabels.postal };
export const EDELIVERY_MOD = { value: 'E-DELIVERY', text: commonLabels.eDelivery };

export const deilveryOptions = { [POSTAL_MOD.value]: POSTAL_MOD, [EDELIVERY_MOD.value]: EDELIVERY_MOD };
