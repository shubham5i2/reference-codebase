import { AdvancedSearchDataType, BasicSearchDataType } from '../../../src/services/Models/IncidentManagement';

export const initialBasicSearchData: BasicSearchDataType = {
  dateRange: {
    startDate: undefined,
    endDate: undefined,
  },
  testCentre: '',
  product: '',
};

export const initialAdvancedSearchData: AdvancedSearchDataType = {
  givenname: '',
  lastname: '',
  incidentcatagory: '',
  incidenttype: '',
  incidentseverity: '',
  shortcandidatenumber: '',
  uniquetesttakerid: '',
  identitynumber: '',
  incidentstatus: '',
};

export const sortConstant = {
  sortType: 'ASC',
  sortBy: 'uniqueTestTakerId',
};
