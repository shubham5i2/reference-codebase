import { languageService } from '../../services/Language/LanguageService';
import { IncidentEvidence, IncidentManagementDetailsScreenResponse } from '../../services/Models/IncidentManagement';
import editIcon from '../../assets/images/Edit.svg';

const incidentManagementLabels = languageService().incidentManagement;

export const initialEvidence: IncidentEvidence = {
  evidenceName: '',
  evidenceUrl: '',
  evidenceFileExtention: '',
};

export const initialResultDetailsData: IncidentManagementDetailsScreenResponse[] = [
  {
    incidentBookingDetails: {
      bookingDetails: {
        bookingUuid: '',
        uniqueTestTakerUuid: '',
        uniqueTestTakerId: '',
        shortCandidateNumber: '',
        locationUuid: '',
        productUuid: '',
        firstName: '',
        lastName: '',
        testDate: '',
        identityNumber: '',
      },
      incidentDetails: {
        bookingUuid: '',
        incidentUuid: '',
        incidentCategoryUuid: '',
        incidentTypeUuid: '',
        incidentStatusTypeUuid: '',
        incidentSeverity: '',
        banReviewRequired: '',
        comments: [
          {
            comment: '',
            commentDateTime: '',
            commentEnteredBy: '',
            userType: '',
          },
        ],
        evidences: [
          {
            ...initialEvidence,
          },
        ],
      },
    },
  },
];

export enum IncidentActionViewType {
  EDIT_INCIDENT = 'EDIT_INCIDENT',
}

export const incidentManagementActions = [
  { label: incidentManagementLabels.editIncident, type: IncidentActionViewType.EDIT_INCIDENT, icon: editIcon },
];
