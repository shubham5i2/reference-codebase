import { languageService } from '../../../src/services/Language/LanguageService';
import { IncidentManagementIdVerificationDetails } from '../../services/Models/IncidentManagement';

const incidentManagementLabels = languageService().incidentManagement;

export const currentIDOptions = [
  { value: 'a75ee32e-48f8-4062-bac7-41e34a5531ae', text: incidentManagementLabels.verified },
  { value: 'a911b11f-c4f2-4ee9-8450-d954ed3bb9d9', text: incidentManagementLabels.rejected },
  { value: 'ceff8c5a-ee52-489a-8803-7ae6406547ce', text: incidentManagementLabels.idCleared },
  { value: '52c9a929-724d-4e6c-aa34-d9d979ac0f48', text: incidentManagementLabels.idRefered },
  { value: '2628a41f-2a20-4dfe-ba40-5dc3a17c593e', text: incidentManagementLabels.idPending },
  { value: '7a619bec-1dbe-48d3-b295-e1a29edc5c07', text: incidentManagementLabels.idInfo },
  { value: 'd957f555-77eb-41ff-a179-902a56ae0273', text: incidentManagementLabels.idFlaggedForReview },
  { value: 'dfdf18cf-d77b-4da3-905b-e5d3438f5127', text: incidentManagementLabels.idNotStarted },
];

export const idVerificationInitialData: IncidentManagementIdVerificationDetails = {
  checkOutcomeStatusUuid: '',
  bookingDetails: {
    bookingUuid: '',
    uniqueTestTakerUuid: '',
    uniqueTestTakerId: '',
    shortCandidateNumber: '',
    locationUuid: '',
    productUuid: '',
    firstName: '',
    lastName: '',
    testDate: '',
    identityNumber: '',
  },
  photos: [
    {
      photoUuid: '',
      photoTypeUuid: '',
      photoTypeCode: '',
      photoUrl: '',
    },
  ],
};

export const initialPhotoData = {
  registrationId: '',
  writtenTestPhoto: '',
  writtenTestId: '',
  speakingTestPhoto: '',
  speakingTestId: '',
};

export enum verifyPhotoEnum {
  registrationId = 'registrationId',
  writtenTestPhoto = 'writtenTestPhoto',
  writtenTestId = 'writtenTestId',
  speakingTestPhoto = 'speakingTestPhoto',
  speakingTestId = 'speakingTestId',
}
