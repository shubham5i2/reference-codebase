export const videoControlList = 'nodownload';
export const idVideoContainer = 'videoContainer';
export const idDocumentContainer = 'documentContainer';
export const idAudioContainer = 'audioContainer';
