import { languageService } from '../../../src/services/Language/LanguageService';
import visibilityIcon from '../../assets/images/visibility.svg';

const incidentManagementLabels = languageService().incidentManagement;

export enum IncidentActionType {
  VIEW_DETAILS = 'VIEW_DETAILS',
}

export const incidentManagementActions = [
  { label: incidentManagementLabels.viewDetails, type: IncidentActionType.VIEW_DETAILS, icon: visibilityIcon },
];
