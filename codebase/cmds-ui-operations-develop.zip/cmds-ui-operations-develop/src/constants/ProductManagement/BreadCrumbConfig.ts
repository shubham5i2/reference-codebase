import commonLabels from '../../services/Language/en/en.common';
import { BreadCrumbRoute } from '../../components/Organisms/BreadCrumbHandler/BreadCrumbHandler';

export default [
  {
    path: '/productsManagement',
    breadCrumbLabel: commonLabels.productsMangement,
  },
] as BreadCrumbRoute[];
