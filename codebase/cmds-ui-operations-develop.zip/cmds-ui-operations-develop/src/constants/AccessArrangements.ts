import { AASearchFields, AAStatus } from '../services/Models/AccessArrangements';
import visibilityIcon from '../assets/images/visibility.svg';
import { languageService } from '../services/Language/LanguageService';

const aaLabels = languageService().accessArrangements;
export const DEFAULT_MORE_IDX = -1;
export const MORE_ACTIONS = [{ label: 'View Details', icon: visibilityIcon, type: 'View' }];
export const AA_SEARCH_FIELDS = [
  { text: aaLabels.giveName, value: AASearchFields.GIVEN_NAME },
  { text: aaLabels.familyName, value: AASearchFields.FAMILY_NAME },
  { text: aaLabels.externalCaseId, value: AASearchFields.EXTERNAL_CASEID },
  { text: aaLabels.testcenter, value: AASearchFields.TEST_CENTER },
  { text: aaLabels.uttid, value: AASearchFields.UTTID },
  { text: aaLabels.dateSubmitted, value: AASearchFields.DATE_SUBMITTED },
];

export const AA_STATUSES = [
  { text: aaLabels.approved, value: AAStatus.APPROVED },
  { text: aaLabels.open, value: AAStatus.OPEN },
  { text: aaLabels.rejected, value: AAStatus.REJECTED },
  { text: aaLabels.void, value: AAStatus.VOID },
];

export const MOCK_AA_SEARCH_DATA = [
  {
    accessArrangementCaseUuid: 'c7a5a597-e804-4c3c-8d65-5ba903f302de',
    externalCaseNumberUuid: '291a3806-b813-4da0-9095-ead0c38f5e47',
    externalCaseNumberId: '34564575',
    additionalNotes: null,
    arrangementDetails: [
      {
        accessArrangementUuid: 'b449045a-ab1a-4e8a-a44e-0679626c2539',
        externalAccessArrangementUuid: '14e284c5-1a53-40cf-9098-3ebe40b04644',
        arrangementTypeUuid: '5868ebc0-d026-489b-b031-086da0793927',
        component: 'L',
        note: null,
      },
      {
        accessArrangementUuid: '89ec317c-ddb2-40b4-9f45-c284ea55e0a2',
        externalAccessArrangementUuid: '9692725f-18ae-49b6-9d41-59ad0d7581b7',
        arrangementTypeUuid: '5868ebc0-d026-489b-b031-086da0793927',
        component: 'L',
        note: null,
      },
      {
        accessArrangementUuid: '3c3b0d38-da92-4562-baac-43105adcb29d',
        externalAccessArrangementUuid: '433940a5-2808-43b3-bca2-6d138bf152a0',
        arrangementTypeUuid: '33671ddf-a08b-4f8f-a600-b0837a7dacfc',
        component: 'S',
        note: null,
      },
    ],
    targetTestDate: null,
    expiryDate: '2024-04-27',
    testTaker: {
      accessArrangementCaseUuid: null,
      externalUniqueTestTakerUuid: null,
      identityNumber: null,
      identityTypeUuid: null,
      firstName: 'Ross',
      lastName: 'Taylor',
      birthDate: null,
      email: null,
      nationalityUuid: null,
    },
  },
];

export const GRID_INITIAL_STATE = {
  totalRecords: 1,
  initialState: {
    pageSize: 1,
  },
  selectedPage: 1,
  selectedOptionValue: 1,
};
