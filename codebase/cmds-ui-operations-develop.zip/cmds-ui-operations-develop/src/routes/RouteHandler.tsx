import React, { useEffect, useState } from 'react';
import { Switch, Redirect } from 'react-router-dom';

import PrivateRoute from './PrivateRoute';
import Home from '../components/Pages/Home/Home';
import Setting from '../components/Pages/Setting/Setting';
import ManageUsers from '../components/Pages/ManageUsers/ManageUser';
import ManageResults from '../components/Pages/Results/ManageResults';
import OrganisationHome from '../components/Pages/Organisation/Organisation';
import ManageTestTakers from '../components/Pages/ManageTestTakers/ManageTestTaker';
import useRBAC from '../services/hooks/useRBAC';
import withConnectionId from '../components/Others/withConnectionId/withConnectionId';
import ManageTestTakerPreReleaseCheck from '../components/Pages/ManageTestTakerPreReleaseCheck/ManageTestTakerPreReleaseCheck';
import DownloadTRF from '../components/Pages/TestTakerTRF/TestTakerTRF';
import MarksUpdate from '../components/Pages/MarksUpdate/MarksUpdate.module';
import IncidentManagement from '../components/Pages/IncidentManagement/IncidentManagement';
import LocationManagement from '../components/Pages/LocationManagement';
import { usePreloader } from '../services/Preloader/usePreloader';
import withServiceRequest from '../services/utils/ServiceRequest';
import { useStateValue } from '../Store/helpers/UseStateValue';
import { useAuth0 } from '@auth0/auth0-react';
import productsManagementPage from '../components/Pages/ProductsManagement';
import AccessArrangements from '../components/Pages/AccessArrangements';

const initialAllowedRoutes = [
  { path: '/', isAllowed: true },
  { path: '/settings', isAllowed: true },
  { path: '/manageuser', isAllowed: true },
  { path: '/organisation', isAllowed: true },
  { path: '/managetesttaker', isAllowed: true },
  { path: '/results', isAllowed: true },
  { path: '/manageprereleasecheck', isAllowed: true },
  { path: '/results/downloadtrf', isAllowed: true },
  { path: '/results/updatemarks', isAllowed: true },
  { path: '/incidentmanagement', isAllowed: true },
  { path: '/accessarrangements', isAllowed: true },
  { path: '/locationManagement', isAllowed: true },
  { path: '/productsManagement', isAllowed: true },
];

const RouteHandler = (props: any) => {
  const userAccessOrganisation = useRBAC('organisation');
  const userAccessAccessArrangements = useRBAC('accessarrangements');
  const locationManagement = useRBAC('locationManagement');
  const productsManagement = useRBAC('productsManagement');

  const [allowedRoutes, setAllowedRoutes] = useState(initialAllowedRoutes);
  const { user } = useAuth0();
  const { dispatch } = useStateValue();
  const { asyncPreloader, syncPreloader } = usePreloader({
    serviceRequest: props.serviceRequest,
    dispatcher: dispatch,
    user,
  });

  useEffect(() => {
    asyncPreloader();
    syncPreloader();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (userAccessOrganisation || userAccessAccessArrangements || locationManagement) {
      setAllowedRoutes((prevRoutes) => {
        return prevRoutes.map((route) => {
          switch (route.path) {
            case '/organisation': {
              return {
                ...route,
                isAllowed: !!userAccessOrganisation?.isReadAccess,
              };
            }
            case '/accessarrangements': {
              return {
                ...route,
                isAllowed: !!userAccessAccessArrangements?.isReadAccess,
              };
            }
            case '/locationManagement': {
              return {
                ...route,
                isAllowed: !!locationManagement?.isReadAccess,
              };
            }

            case '/productsManagement': {
              return {
                ...route,
                isAllowed: !!productsManagement?.isReadAccess,
              };
            }
            default:
              return route;
          }
        });
      });
    }
  }, [userAccessOrganisation, userAccessAccessArrangements, locationManagement, productsManagement]);

  const routes = [
    <PrivateRoute exact path="/" component={Home} key="/" />,
    <PrivateRoute path="/settings" component={Setting} key="/settings" />,
    <PrivateRoute path="/manageuser" component={ManageUsers} key="/manageuser" />,
    <PrivateRoute path="/organisation" component={OrganisationHome} key="/organisation" />,
    <PrivateRoute path="/managetesttaker" component={ManageTestTakers} key="/managetesttaker" />,
    <PrivateRoute path="/results/downloadtrf" component={DownloadTRF} key="/downloadtrf" />,
    <PrivateRoute path="/results/updatemarks" component={MarksUpdate} key="/updatemarks" />,
    <PrivateRoute path="/results" component={ManageResults} key="/results" />,
    <PrivateRoute
      path="/manageprereleasecheck"
      component={ManageTestTakerPreReleaseCheck}
      key="/manageprereleasecheck"
    />,
    <PrivateRoute path="/incidentmanagement" component={IncidentManagement} key="/incidentmanagement" />,
    <PrivateRoute path="/locationManagement" component={LocationManagement} key="/locationManagement" />,
    <PrivateRoute path="/productsManagement" component={productsManagementPage} key="/productsManagement" />,
    // This will be enabled once API is ready
    <PrivateRoute path="/accessarrangements" component={AccessArrangements} key="/accessarrangements" />,
  ];

  return (
    <Switch>
      {routes.filter(
        (route) => allowedRoutes.find((allowedRoute) => allowedRoute.path === route.props.path)?.isAllowed,
      )}
      <Redirect from="*" to="/" />,
    </Switch>
  );
};

export default withConnectionId(withServiceRequest(RouteHandler));
