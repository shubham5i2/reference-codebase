import React from 'react';
import { WithAuthenticationRequiredOptions } from '@auth0/auth0-react';
import { Route } from 'react-router-dom';

interface requiredOptions extends WithAuthenticationRequiredOptions {
  component: any;
  exact?: any;
  path: any;
}

const PrivateRoute = ({ component, ...args }: requiredOptions) => <Route component={component} {...args} />;

PrivateRoute.displayName = 'PrivateRoute_Component';

export default PrivateRoute;
