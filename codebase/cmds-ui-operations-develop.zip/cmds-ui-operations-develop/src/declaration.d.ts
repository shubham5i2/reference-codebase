declare module '*.svg' {
  const value: any;
  export default value;
}

declare module '*.png' {
  const value: any;
  export default value;
}

declare module '*.jpg' {
  const value: any;
  export default value;
}

declare module '*.scss' {
  const content: any;
  export default content;
}

declare module 'ielts-cmds-ui-component-library' {
  const content: any;
  export default content;
}
