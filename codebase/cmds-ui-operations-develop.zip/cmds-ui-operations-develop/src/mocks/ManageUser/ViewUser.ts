export const userDetailsResponse = () => {
  return {
    userUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    partnerCode: 'BC',
    homeTestCentreUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    givenName: 'Steve',
    familyName: 'Smith',
    nickname: 'Nick',
    email: 'stevesmith@gmail.com',
    phoneNumber: '+1 234566778',
    emailVerified: true,
    phoneVerified: true,
    userStatus: 'ACTIVE',
    userGroupAssignments: [
      {
        userGroupAssignmentUuid: '90d091f8-57bb-4932-b75c-963d402d8c0f',
        userGroupUuid: '90d091f8-57bb-4932-b75c-963d402d8c0f',
        userGroupName: 'Item Bank Administrator',
        locationUuid: 'b5d06bfb-1640-43e9-b4c0-2f2daf78fcbc',
        locationName: 'TC123 - Test Centre - IDP India',
        products: [
          {
            productUuid: '2b4a9be0-6f4c-4e0d-bbc5-e64d90dd1480',
            productName: 'IELTS Online',
          },
        ],
        effectiveFromDatetime: '2020-04-30T00:04:33Z',
        effectiveToDatetime: '2020-04-30T00:04:33Z',
      },
    ],
    softDeleted: false,
  };
};
