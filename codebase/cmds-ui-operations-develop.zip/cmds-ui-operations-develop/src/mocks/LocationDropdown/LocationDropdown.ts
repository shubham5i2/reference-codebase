export const testCentreData = {
  transformedData: [
    {
      text: 'test centre 1',
      value: 'test centre 1',
    },
    {
      text: 'test centre 2',
      value: 'test centre 2',
    },
  ],
};

export const partnerData = {
  transfomedData: [
    {
      text: 'test partner 1',
      value: 'test partner 1',
    },
    {
      text: 'test partner 2',
      value: 'test partner 2',
    },
  ],
};

export const physicalBuildingData = {
  transfomedData: [
    {
      text: 'physical building 1',
      value: 'physical building 1',
    },
    {
      text: 'physical building 2',
      value: 'physical building 2',
    },
  ],
};

export const physicalBuildingDataBC = {
  transfomedData: [
    {
      text: 'physical building bc 1',
      value: 'physical building bc 1',
    },
    {
      text: 'physical building bc 2',
      value: 'physical building bc 2',
    },
  ],
};

export const partnerDataBC = {
  transfomedData: [
    {
      text: 'partner bc 1',
      value: 'partner bc 1',
    },
    {
      text: 'partner bc 2',
      value: 'partner bc 2',
    },
  ],
};

export const testCentreDataBC = {
  transfomedData: [
    {
      text: 'test centre bc 1',
      value: 'test centre bc 1',
    },
    {
      text: 'test centre bc 2',
      value: 'test centre bc 2',
    },
  ],
};
