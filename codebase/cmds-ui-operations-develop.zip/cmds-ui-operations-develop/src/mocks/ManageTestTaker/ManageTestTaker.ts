export const getbookingDetails = () => {
  return {
    meta: {
      correlationId: '3e81e94b-8b6a-42b5-970c-b141f9d195a4',
      connectionId: 'e873fca7-849b-4e3b-8dfc-b6b5108608db',
    },
    response: {
      bookingUuid: 'ab032fe3-f292-4bba-8178-394c01fb254f',
      resultConcurrencyVersion: 1,
      currentResultStatus: {
        resultsStatusHistoryUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
        resultStatusTypeUuid: 'bcca33a0-693c-4dfd-824f-962784f8bf7d',
        resultStatusLabelUuid: '456a33a0-693c-4dfd-824f-962784f8bf7d',
        resultStatusComment: 'In-room identity swap',
        resultStatusCommentUuid: '123a33a0-693c-4dfd-824f-962784f8bf7d',
        resultStatusUpdateDatetime: '1995-09-07T10:40:52Z',
        resultStatusUpdatedBy: 'John Amber',
      },
      resultStatusHistory: [
        {
          resultsStatusHistoryUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
          resultStatusTypeUuid: 'bcca33a0-693c-4dfd-824f-962784f8bf7d',
          resultStatusLabelUuid: '456a33a0-693c-4dfd-824f-962784f8bf7d',
          resultStatusComment: 'In-room identity swap',
          resultStatusCommentUuid: '123a33a0-693c-4dfd-824f-962784f8bf7d',
          resultStatusUpdateDatetime: '1995-09-07T10:40:52Z',
          resultStatusUpdatedBy: 'John Amber',
        },
      ],
      resultScoreHistory: [
        {
          componentGradeType: 'Reading',
          componentRounds: [
            {
              componentEvaluationRoundId: 1,
              overallResultType: 'NORMAL',
              overallFinalGrade: 7.5,
              dateReceived: '2020-01-01T15:00:00.000Z',
              rawScore: '50',
              tasks: [
                {
                  taskNumber: 1,
                  examiner: 2382738,
                  criterias: [
                    {
                      criteriaUuid: '3e81e94b-8b6a-42b5-970c-b141f9d195a4',
                      criteriaScore: 8,
                    },
                  ],
                },
              ],
            },
          ],
        },
      ],
      latestComponentScore: {
        overall: {
          componentEvaluationRoundId: 1,
          overallResultType: 'NORMAL',
          overallFinalGrade: 7.5,
          dateReceived: '2020-01-01T15:00:00.000Z',
          rawScore: '50',
          tasks: [
            {
              taskNumber: 1,
              examiner: 2382738,
              criterias: [
                {
                  criteriaUuid: '3e81e94b-8b6a-42b5-970c-b141f9d195a4',
                  criteriaScore: 8,
                },
              ],
            },
          ],
        },
        reading: {
          componentEvaluationRoundId: 1,
          overallResultType: 'NORMAL',
          overallFinalGrade: 7.5,
          dateReceived: '2020-01-01T15:00:00.000Z',
          rawScore: '50',
          tasks: [
            {
              taskNumber: 1,
              examiner: 2382738,
              criterias: [
                {
                  criteriaUuid: '3e81e94b-8b6a-42b5-970c-b141f9d195a4',
                  criteriaScore: 8,
                },
              ],
            },
          ],
        },
        speaking: {
          componentEvaluationRoundId: 1,
          overallResultType: 'NORMAL',
          overallFinalGrade: 7.5,
          dateReceived: '2020-01-01T15:00:00.000Z',
          rawScore: '50',
          tasks: [
            {
              taskNumber: 1,
              examiner: 2382738,
              criterias: [
                {
                  criteriaUuid: '3e81e94b-8b6a-42b5-970c-b141f9d195a4',
                  criteriaScore: 8,
                },
              ],
            },
          ],
        },
        listening: {
          componentEvaluationRoundId: 1,
          overallResultType: 'NORMAL',
          overallFinalGrade: 7.5,
          dateReceived: '2020-01-01T15:00:00.000Z',
          rawScore: '50',
          tasks: [
            {
              taskNumber: 1,
              examiner: 2382738,
              criterias: [
                {
                  criteriaUuid: '3e81e94b-8b6a-42b5-970c-b141f9d195a4',
                  criteriaScore: 8,
                },
              ],
            },
          ],
        },
        writing: {
          componentEvaluationRoundId: 1,
          overallResultType: 'NORMAL',
          overallFinalGrade: 7.5,
          dateReceived: '2020-01-01T15:00:00.000Z',
          rawScore: '50',
          tasks: [
            {
              taskNumber: 1,
              examiner: 2382738,
              criterias: [
                {
                  criteriaUuid: '3e81e94b-8b6a-42b5-970c-b141f9d195a4',
                  criteriaScore: 8,
                },
              ],
            },
          ],
        },
      },
    },
    errors: {
      errorList: [
        {
          interface: 'POST/v1/users',
          type: 'VALIDATION',
          errorCode: 'V0023',
          title: 'Validation failed',
          message: 'Attribute value is not valid',
          errorTicketUuid: '3e81e94b-8b6a-42b5-970c-b141f9d195a4',
          source: {
            path: 'User.Phone',
            value: '111 111 111',
          },
        },
      ],
    },
  };
};
