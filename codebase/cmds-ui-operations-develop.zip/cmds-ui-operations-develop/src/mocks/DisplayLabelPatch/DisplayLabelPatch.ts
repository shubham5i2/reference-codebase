import { PatchRowData } from '../../components/Organisms/DisplayLabelPatch/DisplayLabelPatch';
import { UITypography } from '../../services/Models/UIModels';

export const getDisplayPatchProps = () => {
  return {
    className: 'class',
    rowsData: [
      {
        rowElements: [
          {
            label: 'ABCD',
            value: 'MNOP',
          },
        ],
        type: UITypography.REGULAR,
        size: 15,
      },
      {
        rowElements: [
          {
            label: 'PQR',
            value: 'PQR',
          },
        ],
        type: UITypography.REGULAR,
        size: 15,
      },
    ] as PatchRowData[],
  };
};
