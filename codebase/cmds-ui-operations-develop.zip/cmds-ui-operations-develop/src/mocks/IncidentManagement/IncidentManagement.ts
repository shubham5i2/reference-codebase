// IncidentManagementPhotoPanel

import { AsyncResponseStatus } from '../../services/Models/Api';

export const getBookingDetails = () => {
  return {
    bookingUuid: '0e5567b0-30ac-4518-b245-6093f3bc24b0',
    uniqueTestTakerUuid: '0e5567b0-30ac-4518-b245-6093f3bc24b0',
    uniqueTestTakerId: 'T-F8-04L0-NBIN',
    shortCandidateNumber: '000168',
    firstName: 'Alan',
    lastName: 'Davies',
    testDate: '2022-06-16',
    birthDate: '2022-06-16',
    identityNumber: 'AB12314',
    locationUuid: '42bd72e0-e09c-472b-9612-ab4c203a7b8f',
    productUuid: '4ddcb08b-c2c7-412a-9f59-f4adaf3aa131',
  };
};

export const getIncidentDetails = () => {
  return {
    bookingUuid: 'ab032fe3-f292-4bba-8178-394c01fb254f',
    incidentUuid: '0e5567b0-30ac-4518-b245-6093f3bc24b0',
    incidentCategoryUuid: '0e5567b0-30ac-4518-b245-6093f3bc24b0',
    incidentTypeUuid: '3e81e94b-8b6a-42b5-970c-b141f9d195a4',
    incidentStatusTypeUuid: 'e873fca7-849b-4e3b-8dfc-b6b5108608db',
    incidentSeverity: 'WARNING',
    banReviewRequired: 'true',
  };
};

export const getPhotoData = () => {
  return [
    {
      photoUuid: '393162d5-69e8-41ae-bb03-7b9425d0e9d2',
      photoTypeUuid: '393162d5-69e8-41ae-bb03-7b9425d0e9d2',
      photoTypeCode: 'TT_ID_HR_R',
      photoUrl: 'abc.jpg',
    },
    {
      photoUuid: '393162d5-69e8-41ae-bb03-7b9425d0e9d2',
      photoTypeUuid: '393162d5-69e8-41ae-bb03-7b9425d0e9d2',
      photoTypeCode: 'TT_P_LR_LRW_WC',
      photoUrl: 'efg.jpg',
    },
    {
      photoUuid: '393162d5-69e8-41ae-bb03-7b9425d0e9d2',
      photoTypeUuid: '393162d5-69e8-41ae-bb03-7b9425d0e9d2',
      photoTypeCode: 'TT_ID_LRW_WC',
      photoUrl: 'mno.jpg',
    },
    {
      photoUuid: '393162d5-69e8-41ae-bb03-7b9425d0e9d2',
      photoTypeUuid: '393162d5-69e8-41ae-bb03-7b9425d0e9d2',
      photoTypeCode: 'TT_P_LR_S_WC',
      photoUrl: 'pqr.jpg',
    },
    {
      photoUuid: '393162d5-69e8-41ae-bb03-7b9425d0e9d2',
      photoTypeUuid: '393162d5-69e8-41ae-bb03-7b9425d0e9d2',
      photoTypeCode: 'TT_ID_S_WC',
      photoUrl: 'xyz.jpg',
    },
  ];
};

export const idVerificationResponsesTh = () => {
  return {
    bookingUuid: '0e5567b0-30ac-4518-b245-6093f3bc24b0',
    checkOutcomeStatusUuid: 'a75ee32e-48f8-4062-bac7-41e34a5531ae',
    checkOutcomeStatus: 'Passed',
    bookingDetails: getBookingDetails(),
    photos: getPhotoData(),
  };
};

export const responsesSec = () => {
  return {
    bookingUuid: '0e5567b0-30ac-4518-b245-6093f3bc24b0',
    checkOutcomeStatusUuid: 'd957f555-77eb-41ff-a179-902a56ae0273',
    checkOutcomeStatus: 'Flagged For Review',
    bookingDetails: getBookingDetails(),
    photos: getPhotoData(),
  };
};

export const idVerificationResponses = () => {
  return {
    bookingUuid: '0e5567b0-30ac-4518-b245-6093f3bc24b0',
    checkOutcomeStatusUuid: 'a911b11f-c4f2-4ee9-8450-d954ed3bb9d9',
    checkOutcomeStatus: 'Failed',
    bookingDetails: getBookingDetails(),
    photos: getPhotoData(),
  };
};

// IncidentManagementGrid & IncidentSearchPanel

export const gridData = () => {
  return [
    {
      bookingUuid: '6e02e01c-f32f-42aa-8a21-b22f95d6d733',
      uniqueTestTakerUuid: 'a8d3a24f-726d-4ecd-a055-5b6000cc84f0',
      uniqueTestTakerId: 'T-F8-04L0-NBIN',
      shortCandidateNumber: '000167',
      firstName: 'David',
      lastName: 'Moyes',
      testDate: '2022-06-16',
      locationUuid: '1814e798-ffcd-438b-95fc-f56c130bd2a7',
      productUuid: 'cb6f4028-c2d8-48f1-8006-1343760ec905',
      identityNumber: 'AB12316',
      incidentUuid: '0b5567b0-30ac-4518-b245-6093f3bc24b0',
      incidentCategoryUuid: '0e5567b0-30ac-4518-b245-6093f3bc24b0',
      incidentTypeUuid: '93fb67cc-a5b2-48ec-bf0a-a9a3c637bb3e',
      incidentStatusTypeUuid: '6a91d649-18d7-48ae-9797-659b99cb1182',
      incidentSeverity: 'WARNING',
      banReviewRequired: 'true',
      comments: [
        {
          comment: 'Imposter',
          commentDateTime: '2017-07-21T17:32:28Z',
          commentEnteredBy: '',
        },
      ],
      evidences: [
        {
          evidenceName: 'Imposter-evidence1.mp3',
          evidenceUrl: 'url',
          evidenceFileExtention: 'mp3',
        },
      ],
    },
  ];
};

export const getLocationDropDownProps = () => {
  return {
    id: 'incidentTypeOptions',
    label: 'Incident Type',
    placeholder: 'Select Option',
    mandatory: false,
    selectedValue: '213123 adasd 123213',
    captionText: 'Caption text goes here',
    errorMessage: 'Error goes here',
    list: [
      { text: 'aaaa', value: '213123 adasd 123213' },
      { text: 'bbbb', value: '213123 adasd 123213' },
      { text: 'cccc', value: '213123 adasd 123213' },
    ],
    onChange: (value: any) => {
      console.log(value);
    },
    onDropdownClose: () => ({}),
    onDropDownOpen: () => ({}),
    search: true,
    searchIcon: 'normal',
  };
};

export const getProductResponse = () => {
  return [
    {
      productUuid: 'b5d06bfb-1640-43e9-b4c0-2f2daf78fcbc',
      productName: 'IOL Academic',
      effectiveFromDate: '2020-01-01',
      effectiveToDate: '2020-01-01',
      bookable: true,
    },
  ];
};

export const getProductDropDownResponse = () => {
  return [
    {
      productUuid: 'b5d06bfb-1640-43e9-b4c0-2f2daf78fcbc',
      productName: 'IOL Academic',
      effectiveFromDate: '2020-01-01',
      effectiveToDate: '2020-01-01',
      bookable: true,
    },
  ];
};

export const getLocations = () => {
  return [
    {
      locationUuid: 'b5d06bfb-1640-43e9-b4c0-2f2daf78fcbc',
      locationName: 'TC123 - Test Centre - IDP India',
      locationType: 'TEST_CENTRE',
      locationCode: 'TC123',
    },
    {
      locationUuid: '729dc17a-a4c5-4ced-b884-e922f4b83c05',
      locationName: 'CA',
      locationType: 'PARTNER',
      locationCode: 'CA',
    },
  ];
};

export const searchScreenResponse = () => {
  return {
    bookingUuid: '0e5567b0-30ac-4518-b245-6093f3bc24b0',
    uniqueTestTakerUuid: '0e5567b0-30ac-4518-b245-6093f3bc24b0',
    uniqueTestTakerId: 'T-F8-04L0-NBIN',
    shortCandidateNumber: '000168',
    firstName: 'Alan',
    lastName: 'Davies',
    testDate: '2022-06-16',
    identityNumber: 'AB12314',
    locationUuid: '42bd72e0-e09c-472b-9612-ab4c203a7b8f',
    productUuid: '4ddcb08b-c2c7-412a-9f59-f4adaf3aa131',
    incidentUuid: '0e5567b0-30ac-4518-b245-6093f3bc24b0',
    incidentCategoryUuid: '0e5567b0-30ac-4518-b245-6093f3bc24b0',
    incidentTypeUuid: '3e81e94b-8b6a-42b5-970c-b141f9d195a4',
    incidentStatusTypeUuid: 'e873fca7-849b-4e3b-8dfc-b6b5108608db',
    incidentSeverity: 'WARNING',
    banReviewRequired: 'true',
  };
};

export const getExpectedPayload = () => {
  return {
    criteria: {
      uniqueTestTakerId: '',
      identityNumber: '',
      firstName: 'Alan',
      lastName: '',
      testDateTo: '',
      testDateFrom: '',
      locationUuid: '',
      productUuid: '',
      incidentCategoryUuid: '',
      incidentStatusTypeUuid: '6a91d649-18d7-48ae-9797-659b99cb1182',
      incidentTypeUuid: '',
      incidentSeverity: '',
    },
    pagination: { pageSize: 10, pageNumber: 0 },
    sorting: [{ sortBy: 'uniqueTestTakerId', sortType: 'ASC' }],
  };
};

export const getStateForBasicSearch = () => {
  return {
    incidentManagement: {
      searchData: {
        searchName: 'basicSearch',
        body: {
          criteria: {
            uniqueTestTakerId: '',
            identityNumber: '',
            firstName: '',
            lastName: '',
            testDateTo: '2022-06-01',
            testDateFrom: '2022-05-01',
            locationUuid: '',
            productUuid: '',
            incidentCategoryUuid: '',
            incidentStatusTypeUuid: '',
            incidentTypeUuid: '',
            incidentSeverity: '',
          },
          pagination: {
            pageNumber: 0,
            pageSize: 10,
          },
          sorting: [{ sortBy: 'uniqueTestTakerId', sortType: 'ASC' }],
        },
        selectedPage: 1,
        selectedPageSizeIndex: 0,
        sortOption: {
          sortType: '',
          sortBy: '',
        },
      },
      searchResult: {
        totalCount: 1,
      },
      testCenters: {
        testcentersResponse: [],
        testcentersData: [],
      },
      products: {
        productsResponse: [],
      },
    },
    locationData: {},
  };
};

export const getStateForAdvanceSearch = () => {
  return {
    products: {
      response: [
        {
          productUuid: 'b5d06bfb-1640-43e9-b4c0-2f2daf78fcbc',
          productName: 'IOL Academic',
          bookable: true,
          effectiveFromDate: '2020-01-01',
          effectiveToDate: '2020-01-01',
        },
        {
          productUuid: '6147e48c-543a-433b-8013-61651658848d',
          productName: 'IELTS Online AC',
          bookable: true,
          effectiveFromDate: '2020-01-01',
          effectiveToDate: '2020-01-01',
        },
      ],
    },
    incidentManagement: {
      searchData: {
        searchName: 'advanceSearch',
        body: {
          criteria: {
            uniqueTestTakerId: 'T-F8-04L0-NBIN',
            identityNumber: '',
            firstName: 'Alan',
            lastName: '',
            testDateTo: '2022-06-16',
            testDateFrom: '2022-05-16',
            locationUuid: '',
            productUuid: '',
            incidentCategoryUuid: '',
            incidentStatusTypeUuid: '6a91d649-18d7-48ae-9797-659b99cb1182',
            incidentTypeUuid: '',
            incidentSeverity: '',
          },
          pagination: {
            pageNumber: 0,
            pageSize: 10,
          },
          sorting: [{ sortBy: 'uniqueTestTakerId', sortType: 'ASC' }],
        },
        selectedPage: 1,
        selectedPageSizeIndex: 0,
        sortOption: {
          sortType: '',
          sortBy: '',
        },
      },
      searchResult: {
        totalCount: 1,
      },
      testCenters: {
        testcentersResponse: [],
        testcentersData: [],
      },
      products: {
        productsResponse: [],
      },
    },
    locationData: {},
  };
};

export const getPageSizeOptions = () => {
  return [
    { text: '1-10', value: 10 },
    { text: '1-20', value: 20 },
    { text: '1-50', value: 50 },
  ];
};

export const getTestCenterData = () => {
  return [
    { value: 'Test1', text: 'Test' },
    { value: 'Test2', text: 'Test 2' },
  ] as any;
};

export const getGridState = () => {
  const gridState = {
    totalRecords: 1,
    initialState: {
      pageIndex: 0,
      pageSize: 2,
    },
    selectedPage: 1,
    selectedOptionValue: 20,
  };
  return gridState;
};

export const getBasicData = () => {
  return {
    basicSearchData: {
      dateRange: {
        startDate: new Date(2021, 9, 10),
        endDate: new Date(2021, 9, 10),
      },
      testCentre: '',
      product: '',
    },
  };
};

export const getBasicDataSec = () => {
  return {
    dateRange: {
      startDate: new Date(),
      endDate: new Date(),
    },
    testCentre: '',
    product: 'IOL Academic',
  };
};

export const getAdvanceSearchData = () => {
  return {
    givenname: 'Alan',
    lastname: 'Davis',
    incidentstatus: 'Plagiarism',
    incidentcatagory: 'Plagiarism',
    incidenttype: 'Cheating',
    incidentseverity: 'Plagiarism',
    shortcandidatenumber: 'ADBC',
    uniquetesttakerid: 'T-F8-04L0-NBIN',
    identitynumber: '1234',
  };
};

export const getVerificationPhotoData = () => {
  return {
    checkOutcomeStatusUuid: 'd957f555-77eb-41ff-a179-902a56ae0273',
    bookingDetails: getBookingDetails(),
    photos: getPhotoData(),
  };
};

export const incidentReducerExpectedState = () => {
  return {
    searchData: {
      searchName: 'basic',
      body: { uniqueTesTakerId: 'TT-12-3456-7890' },
      selectedPage: 1,
      selectedPageSizeIndex: 12,
      sortOption: {
        sortType: '',
        sortBy: '',
      },
    },
  };
};

export const incidentReducerExpectedStateSec = () => {
  return {
    searchData: {
      searchName: '',
      body: null,
      selectedPage: 1,
      selectedPageSizeIndex: 0,
      sortOption: {
        sortType: '',
        sortBy: '',
      },
    },
  };
};

export const getSearchCriteria = () => {
  return {
    uniqueTestTakerId: 'T-F8-04L0-NBIN',
    identityNumber: 'AB12314',
    firstName: 'Alan',
    lastName: 'Davies',
    incidentCategoryUuid: '0e5567b0-30ac-4518-b245-6093f3bc24b0',
    incidentStatusTypeUuid: '6a91d649-18d7-48ae-9797-659b99cb1182',
    incidentTypeUuid: '93fb67cc-a5b2-48ec-bf0a-a9a3c637bb3e',
    incidentSeverity: 'CONFIRMED_MALPRACTICE',
    testDateTo: '2022-01-01',
    testDateFrom: '2022-01-01',
    locationUuid: '42bd72e0-e09c-472b-9612-ab4c203a7b8f',
    productUuid: '0c6bc64c-fc66-4d5f-879d-89cdc6c3ed31',
    shortCandidateNumber: 'avbcd',
  };
};

export const getExpectedRequestForSearch = () => {
  return {
    criteria: getSearchCriteria(),
    pagination: {
      pageNumber: 1,
      pageSize: 10,
    },
    sorting: [
      {
        sortBy: 'uniqueTestTakerId',
        sortType: 'ASC',
      },
    ],
  };
};

export const getSearchMockPayload = () => {
  return {
    search: {
      criteria: getSearchCriteria(),
      pagination: {
        pageNumber: '1',
        pageSize: '50',
      },
      sorting: [
        {
          sortBy: 'uniqueTestTakerId',
          sortType: 'ASC/DSC',
        },
      ],
    },
    result: {
      totalCount: '123',
      entries: [
        {
          incidentBookingDetails: {
            bookingDetails: getBookingDetails(),
            incidentDetails: getIncidentDetails(),
          },
        },
      ],
    },
  };
};

export const getSearchTransformedPayload = () => {
  return [
    {
      bookingUuid: '0e5567b0-30ac-4518-b245-6093f3bc24b0',
      uniqueTestTakerUuid: '0e5567b0-30ac-4518-b245-6093f3bc24b0',
      uniqueTestTakerId: 'T-F8-04L0-NBIN',
      shortCandidateNumber: '000168',
      firstName: 'Alan',
      lastName: 'Davies',
      testDate: '2022-06-16',
      identityNumber: 'AB12314',
      locationUuid: '42bd72e0-e09c-472b-9612-ab4c203a7b8f',
      productUuid: '4ddcb08b-c2c7-412a-9f59-f4adaf3aa131',
      incidentUuid: '0e5567b0-30ac-4518-b245-6093f3bc24b0',
      incidentCategoryUuid: '0e5567b0-30ac-4518-b245-6093f3bc24b0',
      incidentTypeUuid: '3e81e94b-8b6a-42b5-970c-b141f9d195a4',
      incidentStatusTypeUuid: 'e873fca7-849b-4e3b-8dfc-b6b5108608db',
      incidentSeverity: 'WARNING',
    },
  ];
};

export const getDropDownInitialState = (str: string) => {
  return {
    target: {
      name: str,
      value: 'val',
      text: 'text',
    },
  };
};

export const getDropDownCapturedValue = (str: string) => {
  return {
    name: str,
    text: undefined,
    value: {
      target: {
        name: str,
        text: 'text',
        value: 'val',
      },
    },
  };
};

export const productsValues = () => {
  return {
    productUuid: '0e5567b0-30ac-4518-b245-6093f3bc24b0',
    productName: 'Product',
    effectiveFromDate: '01-01-2020',
    effectiveToDate: '01-01-2090',
    bookable: true,
  };
};

export const testCenters = (arg: boolean) => {
  const testcentersResponse = {
    locationCode: '789',
    locationName: 'CA',
    locationType: 'PARTNER',
    locationUuid: '42bd72e0-e09c-472b-9612-ab4c203a7b8f',
  };
  const testcentersData = {
    locationCode: '789',
    locationName: 'CA',
    locationType: 'PARTNER',
    locationUuid: '42bd72e0-e09c-472b-9612-ab4c203a7b8f',
    value: 'abcdef',
  };
  return arg ? testcentersData : testcentersResponse;
};

export const getExpectedStateForCenters = () => {
  return {
    testCenters: {
      testcentersResponse: [testCenters(false)],
      testcentersData: [testCenters(true)],
    },
  };
};

export const expectedStateForProducts = () => {
  return {
    products: {
      productsResponse: [productsValues()],
    },
  };
};

export const getEvidenceContainerFiles = () => {
  return [
    {
      evidenceName: 'video-1',
      evidenceUrl: 'https://url',
      evidenceFileExtention: 'mp4',
    },
    {
      evidenceName: 'video-2',
      evidenceUrl: 'https://url1',
      evidenceFileExtention: 'mp4',
    },
  ];
};

export const getEvidenceFiles = (type: string) => {
  return [
    {
      evidenceName: `${type}-1`,
      evidenceUrl: 'https://url',
      evidenceFileExtention: type,
    },
    {
      evidenceName: `${type}-2`,
      evidenceUrl: 'https://url1',
      evidenceFileExtention: type,
    },
  ];
};

export const getApiBookingDetails = () => {
  return {
    bookingUuid: '0e5567b0-30ac-4518-b245-6093f3bc24b0',
    uniqueTestTakerUuid: '0e5567b0-30ac-4518-b245-6093f3bc24b0',
    uniqueTestTakerId: 'T-F8-04L0-NBIN',
    shortCandidateNumber: '000168',
    centreId: 'IN001',
    firstName: 'Alan',
    lastName: 'Davies',
    testDate: '2022-06-16',
    birthDate: '2022-06-16',
    identityNumber: 'AB12314',
    nationalityUuid: '0e5567b0-30ac-4518-b245-6093f3bc24b0',
  };
};

export const getApiIncidentDetails = () => {
  return {
    bookingUuid: 'ab032fe3-f292-4bba-8178-394c01fb254f',
    incidentUuid: '0e5567b0-30ac-4518-b245-6093f3bc24b0',
    incidentCategoryUuid: '0e5567b0-30ac-4518-b245-6093f3bc24b0',
    incidentTypeUuid: '93fb67cc-a5b2-48ec-bf0a-a9a3c637bb3e',
    incidentStatusTypeUuid: '6a91d649-18d7-48ae-9797-659b99cb1182',
    incidentSeverity: 'WARNING',
    banReviewRequired: 'true',
    comments: [
      {
        comment: 'Imposter',
        commentDateTime: '2017-07-21T17:32:28Z',
        commentEnteredBy: 'abcd',
        userType: 'REVIEWER',
      },
    ],
    evidences: [
      {
        evidenceName: 'sample-pdf-1',
        evidenceUrl: 'http://www.pdf895.com/samples/pdf.pdf',
        evidenceFileExtention: 'pdf',
      },
    ],
  };
};

export const getDetailApiPayload = () => {
  return [
    {
      incidentBookingDetails: {
        bookingDetails: getApiBookingDetails(),
        incidentDetails: getApiIncidentDetails(),
      },
    },
  ];
};

export const getIncidentComments = () => {
  return [
    {
      comment: 'Imposter',
      commentDateTime: '2017-07-21T17:32:28Z',
      commentEnteredBy: '',
      userType: 'REPORTER',
    },
    {
      comment: 'Imposter',
      commentDateTime: '2017-07-21T17:32:28Z',
      commentEnteredBy: '',
      userType: 'REVIEWER',
    },
  ];
};

export const getIncidentPanelData = () => {
  return {
    bookingUuid: 'bb032fe3-f292-4bba-8178-394c01fb254f',
    incidentUuid: '1e5567b0-30ac-4518-b245-6093f3bc24b0',
    incidentCategoryUuid: '0e5567b0-30ac-4518-b245-6093f3bc24b0',
    incidentTypeUuid: '93fb67cc-a5b2-48ec-bf0a-a9a3c637bb3e',
    incidentStatusTypeUuid: '6a91d649-18d7-48ae-9797-659b99cb1182',
    incidentSeverity: 'CONFIRMED_MALPRACTICE',
    banReviewRequired: 'true',
    comments: [
      {
        comment:
          'element represents a self-contained composition in a document, page, application, or site, which is intended to be independently distributable or reusable (e.g., in syndication). Examples include: a forum post, a magazine or newspaper article, or a blog entry, a product card, a user-submitted comment, an interactive widget or gadget, or any other independent item of content',
        commentDateTime: '2021-07-21T17:32:28Z',
        commentEnteredBy: 'Jhon Terry',
        userType: '',
      },
      {
        comment:
          'element represents a self-contained composition in a document, page, application, or site, which is intended to be independently distributable or reusable (e.g., in syndication). Examples include: a forum post, a magazine or newspaper article, or a blog entry, a product card, a user-submitted comment, an interactive widget or gadget, or any other independent item of content',
        commentDateTime: '',
        commentEnteredBy: 'Jhon Terry',
        userType: '',
      },
      {
        comment: 'random',
        commentDateTime: '2021-08-21T17:32:28Z',
        commentEnteredBy: 'Rick Griffin',
        userType: 'REPORTER',
      },
    ],
    evidences: [
      {
        evidenceName: 'sample-audio-1',
        evidenceUrl: 'http://www.pdf995.com/samples/pdf.pdf',
        evidenceFileExtention: 'mp3',
      },
      {
        evidenceName: 'sample-video-1',
        evidenceUrl: 'http://www.pdf995.com/samples/pdf.pdf',
        evidenceFileExtention: 'mp4',
      },
      {
        evidenceName: 'sample-pdf-2',
        evidenceUrl: 'https://www.spiritualbee.com/media/gitanjali-by-tagore.pdf',
        evidenceFileExtention: 'pdf',
      },
    ],
  };
};

export const getIncidentDetailsResponse = () => {
  return [
    {
      incidentBookingDetails: {
        bookingDetails: getBookingDetails(),
        incidentDetails: getIncidentPanelData(),
      },
    },
  ];
};

export const getIncidentManagementDetailsReturnValue = () => {
  return {
    status: AsyncResponseStatus.SUCCESS,
    incidentDetailsData: getIncidentDetailsResponse(),
  };
};
