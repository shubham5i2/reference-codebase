import { TestTakerTRFDetailResponse } from '../../services/Models/TestTakerTRF';

export const getSelectionDetails = () => {
  return [
    {
      selectionDate: '2022-08-19T07:48:09.190Z',
      confirmationStatus: 'Confirmed',
      confirmationStatusChangedDatetime: '2022-08-19T07:48:30.212Z',
      minimumScoreSatisfied: 'NOT_APPLICABLE',
      caseNumber: 'WAU-12/99',
      personDepartment: 'Przemek David',
      organisationId: '187959',
      organisationName: 'ChildRO',
      organisationAddress: 'SSR, , Test',
      organisationType: 'Recognising Organisation',
    },
    {
      selectionDate: '2022-08-20T07:48:09.190Z',
      confirmationStatus: 'Confirmed',
      confirmationStatusChangedDatetime: '2022-08-17T13:11:09.618Z',
      minimumScoreSatisfied: 'NOT_APPLICABLE',
      caseNumber: 'WAU-12/99',
      personDepartment: 'Przemek David',
      organisationId: '187958',
      organisationName: 'ParentROTest',
      organisationAddress: 'SSR, test',
      organisationType: 'Recognising Organisation',
    },
  ] as TestTakerTRFDetailResponse[];
};
