import { AsyncResponseStatus } from '../../services/Models/Api';
import { getDayFromToday, formatDate } from '../../components/utils/utilities';
import {
  AddressData,
  AddressType,
  LocationDetailControl,
  AddressFormElements,
} from '../../services/Models/LocationManagement';
import { SortType, Dictionary } from '../../services/Models/UIModels';
import {
  TODAY,
  initialLocationDetailsData,
  initialAddressData,
} from '../../constants/LocationManagement/LocationConstants';
import { OldAuthProd } from '../../components/Pages/LocationManagement/addUpdateLocationPage/addUpdateLocationPage';

export const getLocationInfoDetails = () => {
  return {
    parentLocationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    partnerCode: 'IDP',
    locationTypeCode: 'TEST_CENTRE',
    locationName: 'IDP Melbourne',
    externalLocationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    externalParentLocationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    locationStatus: 'INACTIVE',
    testCentreNumber: 'AU241',
    activatedDate: '2020-04-30',
    eligibleForOfflineTesting: false,
    timezoneName: 'UTC',
    websiteURL: 'https://www.cambridgeassessment.org.uk/',
  };
};

export const LocationTypeCode: any = {
  name: LocationDetailControl.LOCATION_TYPE_CODE,
  value: 'TEST_CENTRE',
};

export const parentEvent: any = {
  name: LocationDetailControl.PARENT_LOCATION_UUID,
  value: '12345-123213-123123',
};

export const partnerEvent: any = {
  name: LocationDetailControl.PARTNER_CODE,
  value: 'IDP',
};

export const RequestStatus: any = {
  target: {
    name: 'requestStatus',
    value: 'val',
  },
};

export const ProductsResponseMock = {
  status: AsyncResponseStatus.SUCCESS,
  products: [
    {
      productUuid: '1234',
      productName: 'Product A',
      bookable: true,
      effectiveFromDate: new Date().toISOString(),
      effectiveToDate: getDayFromToday(2).toISOString(),
    },
    {
      productUuid: '1235',
      productName: 'Product B',
      bookable: true,
      effectiveFromDate: new Date().toISOString(),
      effectiveToDate: getDayFromToday(-1).toISOString(),
    },
    {
      productUuid: '1236',
      productName: 'Product C',
      bookable: true,
      effectiveFromDate: new Date().toISOString(),
      effectiveToDate: getDayFromToday(3).toISOString(),
    },
    {
      productUuid: '1236',
      productName: 'Product C',
      bookable: false,
      effectiveFromDate: new Date().toISOString(),
      effectiveToDate: getDayFromToday(3).toISOString(),
    },
  ],
};

export const mockAddressData: AddressData = {
  addressTypeUuid: AddressType.POSTAL,
  addressLine1: 'Address 1 *',
  addressLine2: 'Test address 2',
  addressLine3: 'Test address 3',
  addressLine4: 'Test address 4',
  city: 'Test city',
  postalCode: '22332123',
  countryUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
  countryName: 'test',
  territoryUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
  territoryName: 'test',
  countryIso3Code: 'AFR',
  email: 'test@test.com',
  primaryPhone: '974345675',
  secondaryPhone: '3333333',
  effectiveFromDate: '2020-06-01',
  effectiveToDate: '2020-09-02',
};

export const LocationStatus: any = {
  target: {
    name: 'locationStatus',
    value: 'val',
  },
};

export const mockLocationDetailsData: any = {
  parentLocationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
  parentLocationName: 'BC',
  partnerCode: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
  partnerCodeText: 'IDP',
  locationTypeCode: 'TEST_CENTRE',
  locationTypeCodeText: 'Test Center',
  locationName: 'IDP Melbourne',
  externalLocationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
  externalParentLocationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
  locationStatus: 'Inactive',
  testCentreNumber: 'AU241',
  activatedDate: '2020-04-30',
  eligibleForOfflineTesting: false,
  timezoneName: 'UTC',
  websiteURL: 'https://www.cambridgeassessment.org.uk/',
  countryUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
  countryName: 'India',
  locationAddresses: [
    {
      addressTypeUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
      addressLine1: 'GPO BOX 1515',
      addressLine2: 'The Triangle Building',
      addressLine3: null,
      addressLine4: null,
      city: 'Melbourne',
      territory: '',
      territoryUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
      territoryName: 'ABC',
      postalCode: '3000',
      country: 'India',
      countryUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
      countryName: 'India',
      countryIso3Code: 'AUS',
      email: 'info@cambridgeassessment.org.uk',
      primaryPhone: '+44 (0)1223 553311',
      secondaryPhone: '+44 (0)1223 553311',
      effectiveFromDate: '2020-06-01',
      effectiveToDate: '2099-12-31',
    },
  ],
  approvedProducts: [
    {
      productUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
      effectiveFromDate: '2020-06-01',
      effectiveToDate: '2020-09-02',
    },
  ],
};
export const locationSearchResultMockData = [
  {
    locationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    testCentreNumber: 'AU241',
    locationName: 'IDP Melbourne',
    locationTypeCode: 'TEST_CENTRE',
    locationStatus: 'ACTIVE',
    city: 'Melbourne',
    partnerCode: 'IDP',
    country: 'Australia',
  },
  {
    locationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    testCentreNumber: 'AU241',
    locationName: 'IDP Melbourne',
    locationTypeCode: 'TEST_CENTRE',
    locationStatus: 'ACTIVE',
    city: 'Melbourne',
    partnerCode: 'IDP',
    country: 'Australia',
  },
  {
    locationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    testCentreNumber: 'AU241',
    locationName: 'IDP Melbourne',
    locationTypeCode: 'TEST_CENTRE',
    locationStatus: 'ACTIVE',
    city: 'Melbourne',
    partnerCode: 'IDP',
    country: 'Australia',
  },
  {
    locationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    testCentreNumber: 'AU241',
    locationName: 'IDP Melbourne',
    locationTypeCode: 'TEST_CENTRE',
    locationStatus: 'ACTIVE',
    city: 'Melbourne',
    partnerCode: 'IDP',
    country: 'Australia',
  },
  {
    locationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    testCentreNumber: 'AU241',
    locationName: 'IDP Melbourne',
    locationTypeCode: 'TEST_CENTRE',
    locationStatus: 'ACTIVE',
    city: 'Melbourne',
    partnerCode: 'IDP',
    country: 'Australia',
  },
  {
    locationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    testCentreNumber: 'AU241',
    locationName: 'IDP Melbourne',
    locationTypeCode: 'TEST_CENTRE',
    locationStatus: 'ACTIVE',
    city: 'Melbourne',
    partnerCode: 'IDP',
    country: 'Australia',
  },
  {
    locationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    testCentreNumber: 'AU241',
    locationName: 'IDP Melbourne',
    locationTypeCode: 'TEST_CENTRE',
    locationStatus: 'ACTIVE',
    city: 'Melbourne',
    partnerCode: 'IDP',
    country: 'Australia',
  },
  {
    locationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    testCentreNumber: 'AU241',
    locationName: 'IDP Melbourne',
    locationTypeCode: 'TEST_CENTRE',
    locationStatus: 'ACTIVE',
    city: 'Melbourne',
    partnerCode: 'IDP',
    country: 'Australia',
  },
  {
    locationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    testCentreNumber: 'AU241',
    locationName: 'IDP Melbourne',
    locationTypeCode: 'TEST_CENTRE',
    locationStatus: 'ACTIVE',
    city: 'Melbourne',
    partnerCode: 'IDP',
    country: 'Australia',
  },
  {
    locationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    testCentreNumber: 'AU241',
    locationName: 'IDP Melbourne',
    locationTypeCode: 'TEST_CENTRE',
    locationStatus: 'ACTIVE',
    city: 'Melbourne',
    partnerCode: 'IDP',
    country: 'Australia',
  },
];

export const SearchPhysicalBuildingMockData = [
  {
    locationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    testCentreNumber: 'AU241',
    locationName: 'IDP Melbourne',
    locationTypeCode: 'PHYSICAL_BUILDING',
    locationStatus: 'ACTIVE',
    city: 'Melbourne',
    partnerCode: 'IDP',
  },
  {
    locationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    testCentreNumber: 'AU241',
    locationName: 'IDP Melbourne',
    locationTypeCode: 'PHYSICAL_BUILDING',
    locationStatus: 'ACTIVE',
    city: 'Melbourne',
    partnerCode: 'IDP',
  },
  {
    locationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    testCentreNumber: 'AU241',
    locationName: 'IDP Melbourne',
    locationTypeCode: 'PHYSICAL_BUILDING',
    locationStatus: 'ACTIVE',
    city: 'Melbourne',
    partnerCode: 'IDP',
  },
  {
    locationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    testCentreNumber: 'AU241',
    locationName: 'IDP Melbourne',
    locationTypeCode: 'PHYSICAL_BUILDING',
    locationStatus: 'ACTIVE',
    city: 'Melbourne',
    partnerCode: 'IDP',
  },
  {
    locationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    testCentreNumber: 'AU241',
    locationName: 'IDP Melbourne',
    locationTypeCode: 'PHYSICAL_BUILDING',
    locationStatus: 'ACTIVE',
    city: 'Melbourne',
    partnerCode: 'IDP',
  },
  {
    locationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    testCentreNumber: 'AU241',
    locationName: 'IDP Melbourne',
    locationTypeCode: 'PHYSICAL_BUILDING',
    locationStatus: 'ACTIVE',
    city: 'Melbourne',
    partnerCode: 'IDP',
  },
];

export const gridStateMockData = {
  totalRecords: 10,
  initialState: {
    pageSize: 10,
  },
  selectedPage: 1,
  selectedOptionValue: 10,
};

export const LocationSearchArgs: any = {
  testCentreNumber: '1234A',
  locationName: 'Test',
  pageNumber: 1,
  pageSize: 10,
  partnerCode: undefined,
  locationTypeCode: 'TEST_CENTRE',
  status: 'ACTIVE',
};

export const LocationSearchReqBody = {
  criteria: {
    locationName: LocationSearchArgs.locationName,
    partnerCode: LocationSearchArgs.partnerCode,
    testCentreNumber: LocationSearchArgs.testCentreNumber,
    locationTypeCode: LocationSearchArgs.locationTypeCode,
    status: LocationSearchArgs.status,
  },
  pagination: {
    pageNumber: LocationSearchArgs.pageNumber,
    pageSize: LocationSearchArgs.pageSize,
  },
  sorting: [
    {
      sortBy: 'testCentreNumber',
      sortType: SortType.ASCENDING,
    },
  ],
};

export const LocationSearchResponse = {
  status: 'success',
  body: {
    meta: {
      totalCount: 2,
      correlationId: '3e81e94b-8b6a-42b5-970c-b141f9d1',
      connectionId: 'e873fca7-849b-4e3b-8dfc-b6b5108608',
    },
    response: [
      {
        locationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
        testCentreNumber: 'AU241',
        locationName: 'IDP Melbourne',
        locationTypeCode: 'TEST_CENTRE',
        locationStatus: 'ACTIVE',
        city: 'Melbourne',
        partnerCode: 'IDP',
        country: 'Australia',
      },
      {
        locationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7e',
        testCentreNumber: 'AU242',
        locationName: 'IDP Melbourne 2',
        locationTypeCode: 'TEST_CENTRE',
        locationStatus: 'ACTIVE',
        city: 'Melbourne',
        partnerCode: 'IDP',
        country: 'Australia',
      },
    ],
  },
};

export const LocationSearchTransformedData = [
  {
    city: 'Melbourne',
    country: 'Australia',
    locationName: 'IDP Melbourne',
    locationStatus: 'ACTIVE',
    locationTypeCode: 'TEST_CENTRE',
    locationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    text: 'IDP Melbourne',
    partnerCode: 'IDP',
    testCentreNumber: 'AU241',
    value: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
  },
  {
    city: 'Melbourne',
    country: 'Australia',
    locationName: 'IDP Melbourne 2',
    locationStatus: 'ACTIVE',
    locationTypeCode: 'TEST_CENTRE',
    locationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7e',
    partnerCode: 'IDP',
    testCentreNumber: 'AU242',
    text: 'IDP Melbourne 2',
    value: 'b32a82a0-693c-4dfd-824f-962784f8bf7e',
  },
];

export const MOCK_STATE = {
  baseDropDown: {
    countries: [{ text: 'India', value: 'zzz' }],
    countriesResponse: [{ countryUuid: 'zzz', countryIso3Code: 'IND', countryName: 'India' }],
    territories: { IND: { text: 'Tn', value: 'yyy' } },
    sectorTypes: [{ text: 'test', value: 'test' }],
    partners: [{ text: 'Idp', value: 'IDP' }],
    organisationTypes: [{ text: 'VO', value: 'e392ae7c-016f-433a-bdfa-b79bfcdddf26' }],
  },
  locationData: {},
};

export const MOCK_LOCATION_DETAILS_EVENTS = [
  {
    name: LocationDetailControl.EXTERNAL_LOCATION_UUID,
    value: 'e392ae7c-016f-433a-bdfa-b79bfcdddf23',
  },
  {
    name: LocationDetailControl.TESTCENTER_NUMER,
    value: 'SH230',
  },
  {
    name: LocationDetailControl.LOCATION_NAME,
    value: 'new test',
  },
  {
    name: LocationDetailControl.TIMEZONE_NAME,
    value: 'ISO',
  },
  {
    name: LocationDetailControl.ACTIVATED_DATE,
    value: new Date(),
  },
];

export const MOCK_ADDRESS_EVENTS = [
  {
    name: AddressFormElements.addressLine1,
    value: 'Primary 1',
    addressType: AddressType.PHYSICAL,
  },
  {
    name: AddressFormElements.city,
    value: 'london',
    addressType: AddressType.PHYSICAL,
  },
  {
    name: AddressFormElements.countryUuid,
    value: 'e392ae7c-016f-433a-bdfa-b79bfcdddf12',
    addressType: AddressType.PHYSICAL,
  },
  {
    name: AddressFormElements.territoryUuid,
    value: 'e392ae7c-016f-433a-bdfa-b79bfcdddf22',
    addressType: AddressType.PHYSICAL,
  },
  {
    name: AddressFormElements.countryIso3Code,
    value: 'AUS',
    addressType: AddressType.PHYSICAL,
  },
  {
    name: AddressFormElements.primaryPhone,
    value: '1234567',
    addressType: AddressType.PHYSICAL,
  },
  {
    name: AddressFormElements.addressLine1,
    value: 'Postal 1',
    addressType: AddressType.POSTAL,
  },
  {
    name: AddressFormElements.city,
    value: 'chennai',
    addressType: AddressType.POSTAL,
  },
  {
    name: AddressFormElements.countryUuid,
    value: 'e392ae7c-016f-433a-bdfa-b79bfcdddf02',
    addressType: AddressType.POSTAL,
  },
  {
    name: AddressFormElements.territoryUuid,
    value: 'e392ae7c-016f-433a-bdfa-b79bfcdddf11',
    addressType: AddressType.POSTAL,
  },
  {
    name: AddressFormElements.countryIso3Code,
    value: 'IND',
    addressType: AddressType.POSTAL,
  },
  {
    name: AddressFormElements.primaryPhone,
    value: '1234566',
    addressType: AddressType.POSTAL,
  },
];

export const locationResposeMock = {
  meta: {
    correlationId: '3e81e94b-8b6a-42b5-970c-b141f9d195a4',
    connectionId: 'e873fca7-849b-4e3b-8dfc-b6b5108608db',
  },
  response: {
    locationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    parentLocationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    partnerCode: 'IDP',
    locationTypeCode: 'TEST_CENTRE',
    locationName: 'IDP Melbourne',
    externalLocationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    externalParentLocationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    locationStatus: 'ACTIVE',
    testCentreNumber: 'AU241',
    activatedDate: '2020-04-30',
    eligibleForOfflineTesting: false,

    timezoneName: 'UTC',
    websiteURL: 'https://www.cambridgeassessment.org.uk/',
    locationAddresses: [
      {
        addressTypeUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
        addressLine1: 'GPO BOX 1515',
        addressLine2: 'The Triangle Building',
        addressLine3: 'string',
        addressLine4: 'string',
        city: 'Melbourne',
        territoryUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
        postalCode: '3000',
        countryUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
        countryIso3Code: 'AUS',
        email: 'info@cambridgeassessment.org.uk',
        primaryPhone: '+44 (0)1223 553311',
        secondaryPhone: '+44 (0)1223 553311',
        effectiveFromDate: '2020-06-01',
        effectiveToDate: '2020-09-02',
        locationAddressUuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
      },
    ],
    approvedProducts: [
      {
        productUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
        effectiveFromDate: '2020-06-01',
        effectiveToDate: '2020-09-02',
        locationProductAuthorisationUuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
      },
    ],
  },
};

export const locationExpectedResposeMock = {
  locationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
  parentLocationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
  partnerCode: 'IDP',
  locationTypeCode: 'TEST_CENTRE',
  locationName: 'IDP Melbourne',
  externalLocationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
  externalParentLocationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
  locationStatus: 'ACTIVE',
  testCentreNumber: 'AU241',
  activatedDate: '2020-04-30',
  eligibleForOfflineTesting: false,
  timezoneName: 'UTC',
  websiteURL: 'https://www.cambridgeassessment.org.uk/',
  locationAddresses: [
    {
      addressTypeUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
      addressLine1: 'GPO BOX 1515',
      addressLine2: 'The Triangle Building',
      addressLine3: 'string',
      addressLine4: 'string',
      city: 'Melbourne',
      territoryUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
      postalCode: '3000',
      countryUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
      countryIso3Code: 'AUS',
      email: 'info@cambridgeassessment.org.uk',
      primaryPhone: '+44 (0)1223 553311',
      secondaryPhone: '+44 (0)1223 553311',
      effectiveFromDate: '2020-06-01',
      effectiveToDate: '2020-09-02',
      locationAddressUuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    },
  ],
  approvedProducts: [
    {
      productUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
      effectiveFromDate: '2020-06-01',
      effectiveToDate: '2020-09-02',
      locationProductAuthorisationUuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    },
  ],
};
export const MOCK_OLD_PRODUCTS: OldAuthProd = {
  activeProd: [
    {
      productUuid: 'b32a82a0-693c-4dfd-824f-962784f8bg1d',
      locationProductAuthorisationUuid: 'c32a82a0-693c-4dfd-824f-962784f8bg1d',
      effectiveFromDate: '2020-06-01',
      effectiveToDate: '2099-09-02',
    },
  ],
  inActiveProd: [
    {
      productUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
      locationProductAuthorisationUuid: 'c32a82a0-693c-4dfd-824f-962784f8bf7d',
      effectiveFromDate: '2020-06-01',
      effectiveToDate: '2020-09-02',
    },
    {
      productUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf8d',
      locationProductAuthorisationUuid: 'c42a82a0-693c-4dfd-824f-962784f8bf7d',
      effectiveFromDate: '2020-06-01',
      effectiveToDate: '2020-09-02',
    },
  ],
};

export const NEW_PROD_1 = [
  {
    productUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf9d',
    effectiveFromDate: '2020-06-01',
    effectiveToDate: '2020-09-02',
  },
  {
    productUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf6d',
    effectiveFromDate: '2020-06-01',
    effectiveToDate: '2020-09-02',
  },
];

export const NEW_PROD_2 = [
  {
    productUuid: 'b32a82a0-693c-4dfd-824f-962784f8bg1d',
    effectiveFromDate: '2020-06-01',
    effectiveToDate: '2099-09-02',
  },
];

export const NEW_PROD_3 = [
  ...MOCK_OLD_PRODUCTS.activeProd,
  {
    productUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf9d',
    effectiveFromDate: TODAY,
    effectiveToDate: '2020-09-02',
  },
  {
    productUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf6d',
    effectiveFromDate: TODAY,
    effectiveToDate: '2020-09-02',
  },
];

export const NEW_PROD_DEACTIVATED = [
  {
    productUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf6d',
    effectiveFromDate: TODAY,
    effectiveToDate: '2020-09-02',
  },
];

export const EXPECTED_PROD_DEACTIVATED = [
  ...MOCK_OLD_PRODUCTS.inActiveProd,
  {
    ...MOCK_OLD_PRODUCTS.activeProd[0],
    effectiveToDate: TODAY,
  },
  {
    productUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf6d',
    effectiveFromDate: TODAY,
    effectiveToDate: '2020-09-02',
  },
];

export const EXPECTED_OLD_NEW_PROD = [
  ...MOCK_OLD_PRODUCTS.inActiveProd,
  ...MOCK_OLD_PRODUCTS.activeProd,
  {
    productUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf9d',
    effectiveFromDate: TODAY,
    effectiveToDate: '2020-09-02',
  },
  {
    productUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf6d',
    effectiveFromDate: TODAY,
    effectiveToDate: '2020-09-02',
  },
];

export const locationResponseMock = {
  status: 'success',
  body: {
    response: {
      parentLocationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
      partnerCode: 'IDP',
      parentLocationName: 'Aruba',
      locationTypeCode: 'TEST_CENTRE',
      locationName: 'IDP Melbourne',
      externalLocationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
      externalParentLocationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
      locationStatus: 'ACTIVE',
      testCentreNumber: 'AU241',
      activatedDate: '2020-04-30',
      eligibleForOfflineTesting: false,

      timezoneName: 'UTC',
      websiteURL: 'https://www.cambridgeassessment.org.uk/',
      locationUuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
      locationAddresses: [
        {
          addressTypeUuid: AddressType.POSTAL,
          addressLine1: 'GPO BOX 1515',
          addressLine2: 'The Triangle Building',
          addressLine3: 'string',
          addressLine4: 'string',
          city: 'Melbourne',
          territoryName: 'Berat',
          territoryUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
          postalCode: '3000',
          countryName: 'Albania',
          countryUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
          countryIso3Code: 'AUS',
          email: 'info@cambridgeassessment.org.uk',
          primaryPhone: '+44 (0)1223 553311',
          secondaryPhone: '+44 (0)1223 553311',
          effectiveFromDate: '2020-06-01',
          effectiveToDate: '2020-09-02',
          locationAddressUuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
        },
        {
          addressTypeUuid: AddressType.PHYSICAL,
          addressLine1: 'GPO BOX 1515',
          addressLine2: 'The Triangle Building',
          addressLine3: 'string',
          addressLine4: 'string',
          city: 'Melbourne',
          territoryName: 'Berat',
          territoryUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
          postalCode: '3000',
          countryName: 'Albania',
          countryUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
          countryIso3Code: 'AUS',
          email: 'info@cambridgeassessment.org.uk',
          primaryPhone: '+44 (0)1223 553311',
          secondaryPhone: '+44 (0)1223 553311',
          effectiveFromDate: '2020-06-01',
          effectiveToDate: '2020-09-02',
          locationAddressUuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
        },
      ],
      approvedProducts: [
        {
          productUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
          effectiveFromDate: '2020-06-01',
          effectiveToDate: '2020-09-02',
          locationProductAuthorisationUuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
        },
        {
          productUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7e',
          effectiveFromDate: '2020-06-01',
          effectiveToDate: '2099-09-02',
          locationProductAuthorisationUuid: '3fa85f64-5717-4562-b3fc-2c963f66afa8',
        },
      ],
      softDeleted: false,
    },
  },
};

export const mockLocationData = {
  parentLocationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
  partnerCode: 'IDP',
  parentLocationName: 'Aruba',
  locationTypeCode: 'TEST_CENTRE',
  locationName: 'IDP Melbourne',
  externalLocationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
  externalParentLocationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
  locationStatus: 'ACTIVE',
  testCentreNumber: 'AU241',
  activatedDate: '2020-04-30',
  eligibleForOfflineTesting: false,
  timezoneName: 'UTC',
  websiteURL: 'https://www.cambridgeassessment.org.uk/',
  locationUuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
  locationAddresses: [
    {
      addressTypeUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
      addressLine1: 'GPO BOX 1515',
      addressLine2: 'The Triangle Building',
      addressLine3: 'string',
      addressLine4: 'string',
      city: 'Melbourne',
      territoryName: 'Berat',
      territoryUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
      postalCode: '3000',
      countryName: 'Albania',
      countryUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
      countryIso3Code: 'AUS',
      email: 'info@cambridgeassessment.org.uk',
      primaryPhone: '+44 (0)1223 553311',
      secondaryPhone: '+44 (0)1223 553311',
      effectiveFromDate: '2020-06-01',
      effectiveToDate: '2020-09-02',
      locationAddressUuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    },
  ],
  approvedProducts: [
    {
      productUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
      effectiveFromDate: '2020-06-01',
      effectiveToDate: '2020-09-02',
      locationProductAuthorisationUuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    },
  ],
};

export const MOCK_PRODUCT_EVENT = [
  {
    productUuid: 'e392ae7c-016f-433a-bdfa-b79bfcdddf36',
  },
  {
    productUuid: 'e392ae7c-016f-433a-bdfa-b79bfcdddf56',
  },
];

export const MOCK_CREATE_LOCATION = {
  status: AsyncResponseStatus.SUCCESS,
  body: {
    meta: {},
    response: {},
  },
};

export const MOCK_CREATE_PAYLOAD = () => {
  const payload: Dictionary = {
    ...initialLocationDetailsData,
    locationTypeCode: 'TEST_CENTRE',
    partnerCode: 'IDP',
    partnerCodeText: '',
    parentLocationUuid: parentEvent.value,
  };
  MOCK_LOCATION_DETAILS_EVENTS.forEach((event) => {
    payload[event.name] = event.value;
  });

  const postal: Dictionary = {
    ...initialAddressData[0],
  };
  MOCK_ADDRESS_EVENTS.filter((event) => event.addressType === AddressType.POSTAL).forEach((event) => {
    postal[event.name] = event.value;
  });

  const physical: Dictionary = {
    ...initialAddressData[1],
  };
  MOCK_ADDRESS_EVENTS.filter((event) => event.addressType === AddressType.PHYSICAL).forEach((event) => {
    physical[event.name] = event.value;
  });

  payload['locationAddresses'] = [{ ...postal }, { ...physical }];
  payload['approvedProducts'] = [];
  return payload;
};

export const EXPECTED_PRODUCT = [
  {
    effectiveFromDate: formatDate(new Date(), 'yyyy-MM-dd'),
    effectiveToDate: '2099-12-31',
    productUuid: 'e392ae7c-016f-433a-bdfa-b79bfcdddf36',
  },
  {
    effectiveFromDate: formatDate(new Date(), 'yyyy-MM-dd'),
    effectiveToDate: '2099-12-31',
    productUuid: 'e392ae7c-016f-433a-bdfa-b79bfcdddf56',
  },
];

export const locationlabelText = [
  'Location Type',
  'Partner',
  'Parent Location',
  'External Location UUID',
  'External Parent Location',
  'Test Centre Number',
  'Location Name',
  'Timezone Name',
  'Website URL',
  'Activation Date',
  'Location Status',
  'Eligible for Offline testing',
];

export const addressLabelText = [
  'Address Line 1',
  'Address Line 2',
  'Address Line 3',
  'Address Line 4',
  'City',
  'Postal Code',
  'Country',
  'Territory',
  'Country ISO Code',
  'Email',
  'Primary Phone',
  'Secondary Phone',
];
export const locationInitialStateMock = {
  searchData: null,
  pageNumber: '1',
  pageSize: {
    page: 0,
  },
  sorting: {
    sortBy: '',
    sortType: '',
  },
  totalCount: 0,
};

export const locationSearchDataMock = {
  searchData: {
    testcenterUuid: 'testcenterUuid',
    testcentreNumber: 'testcentreNumber',
    locationName: 'locationName',
    partnerCode: 'partnerCode',
    status: 'status',
  },
  pageNumber: '1',
  pageSize: {
    page: 10,
  },
  sorting: {
    sortBy: 'locationName',
    sortType: 'ASC',
  },
  totalCount: 100,
};

export const mockViewLocation: any = {
  parentLocationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
  partnerCode: 'IDP',
  parentLocationName: 'Aruba',
  locationTypeCode: 'Test Centre',
  locationName: 'IDP Melbourne',
  externalLocationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
  externalParentLocationUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
  locationStatus: 'ACTIVE',
  testCentreNumber: 'AU241',
  activatedDate: '2020-04-30',
  eligibleForOfflineTesting: 'No',
  timezoneName: 'UTC',
  websiteURL: 'https://www.cambridgeassessment.org.uk/',
  locationUuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
};

export const mockViewAddressData: AddressData = {
  addressTypeUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
  addressLine1: 'GPO BOX 1515',
  addressLine2: 'The Triangle Building',
  addressLine3: 'string',
  addressLine4: 'string',
  city: 'Melbourne',
  territoryName: 'Berat',
  territoryUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
  postalCode: '3000',
  countryName: 'Albania',
  countryUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
  countryIso3Code: 'AUS',
  email: 'info@cambridgeassessment.org.uk',
  primaryPhone: '+44 (0)1223 553311',
  secondaryPhone: '+44 (0)1223 553311',
  effectiveFromDate: '2020-06-01',
  effectiveToDate: '2020-09-02',
  locationAddressUuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
};
