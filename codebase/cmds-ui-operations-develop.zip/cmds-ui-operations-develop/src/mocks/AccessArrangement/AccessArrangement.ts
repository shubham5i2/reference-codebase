export const aaSearchData = [
  {
    caseNumber: '347488799',
    givenName: 'John',
    familyName: 'Doe',
    expiryDate: '22 May 2023',
    components: [
      {
        name: 'Listening',
        data: ['Exemption'],
      },
      {
        name: 'Reading',
        data: ['25% extra time'],
      },
      {
        name: 'Writing',
        data: ['25% extra time', 'Exemption'],
      },
      {
        name: 'Speaking',
        data: ['Exemption'],
      },
    ],
  },
  {
    caseNumber: '140474489',
    givenName: 'Steve',
    familyName: 'Smith',
    expiryDate: '22 Nov 2023',
    components: [
      {
        name: 'Listening',
        data: ['Pause Audio'],
      },
      {
        name: 'Reading',
        data: ['25% extra time'],
      },
      {
        name: 'Writing',
        data: ['25% extra time', 'Exemption'],
      },
      {
        name: 'Speaking',
        data: ['Exemption'],
      },
    ],
  },
  {
    caseNumber: '546474781',
    givenName: 'Justin Austin',
    familyName: 'Robert',
    expiryDate: '22 Jun 2023',
    components: [
      {
        name: 'Listening',
        data: ['Exemption', 'Pause Audio'],
      },
      {
        name: 'Reading',
        data: ['25% extra time', '50% extra time'],
      },
      {
        name: 'Writing',
        data: ['25% extra time', 'Exemption'],
      },
      {
        name: 'Speaking',
        data: ['Exemption'],
      },
    ],
  },
];

export const saveAARequest = {
  testTaker: {
    firstName: 'James',
    lastName: 'Anderson',
  },
  externalCaseNumberId: '123456',
  expiryDate: '2024-06-12',
  arrangementDetails: [
    {
      arrangementTypeUuid: 'c1a53e78-8023-4bc4-93f9-7b76edaab5fb',
      component: 'L',
    },
  ],
};
