export const ResultsUpdateStatusMockData = {
  resultStatusTypeUuid: '27c03460-2662-4a63-b1aa-6d158b85c0a5',
  resultConcurrencyVersion: 0,
  resultStatusLabelUuid: '27c03460-2662-4a63-b1aa-6d158b85c0a5',
  resultStatusCommentUuid: '27c03460-2662-4a63-b1aa-6d158b85c0a5',
  resultStatusCommentText: '',
};

export const ResultsStatusDropdownMockData = {
  status: 'success',
  resultStatuses: [
    {
      resultsStatusTypeUuid: '3d189282-e531-47f2-aa22-d24eef1d20b6',
      resultsStatusType: 'Unconfirmed',
      effectiveFromDate: '2020-07-01',
      effectiveToDate: '2099-12-31',
      resultStatusLabels: [
        {
          resultStatusLabelUuid: 'aee4f1ac-d11a-4423-b1b6-61cb5bb30a78',
          resultStatusLabel: 'EOR Pending',
          resultStatusLabelCode: 'EOR_PENDING',
          resultStatusCommentMandatory: false,
          resultStatusComments: [],
        },
        {
          resultStatusLabelUuid: 'b45fa3ff-3218-4671-aed7-e9bd89e407b1',
          resultStatusLabel: 'Manual Marks Update',
          resultStatusLabelCode: 'MANUAL_MARKS_UPDATE',
          resultStatusCommentMandatory: false,
          resultStatusComments: [],
        },
        {
          resultStatusLabelUuid: '12b2e233-81a4-4263-b327-9b47ba09eb53',
          resultStatusLabel: 'Post-release Grade Change',
          resultStatusLabelCode: 'POST_RELEASE_GRADE_CHANGE',
          resultStatusCommentMandatory: false,
          resultStatusComments: [],
        },
      ],
    },
  ],
};

export const multipleResultsUpdateStatusMockResponse = {
  status: 'success',
  resultUpdateStatuses: {
    onHoldUpdateSummary: {
      failureCount: 10,
      passCount: 10,
    },
  },
};
