import { BookingDetails, LinkedBookingDetailsData } from '../../../services/Models/Result';
import { LatestComponentScore } from '../../../components/Pages/Results/ResultsTestTakerDetails/ResultsTestTakerDetailsConstants';

export const latestComponentScoreMockData: LatestComponentScore = {
  overall: {
    componentEvaluationRoundId: 1,
    overallResultType: 'NORMAL',
    isUpdated: true,
    dateReceived: '2020-02-15T12:50:00.000Z',
  },
  listening: {
    componentEvaluationRoundId: 1,
    overallResultType: 'JAGGED-1',
    overallFinalGrade: 6.5,
    isUpdated: false,
    dateReceived: '2020-02-15T12:50:00.000Z',
  },
  reading: {
    componentEvaluationRoundId: 1,
    overallResultType: 'EOR',
    overallFinalGrade: 6.5,
    isUpdated: false,
    dateReceived: '2020-02-15T12:50:00.000Z',
  },
  writing: {
    componentEvaluationRoundId: 1,
    overallResultType: 'JAGGED-2',
    overallFinalGrade: 6.5,
    isUpdated: false,
    dateReceived: '2020-02-15T12:50:00.000Z',
  },
  speaking: {
    componentEvaluationRoundId: 1,
    overallResultType: 'NORMAL',
    isUpdated: false,
    dateReceived: '2020-02-15T12:50:00.000Z',
  },
};

export const latestComponentScoreEmptyMockData: LatestComponentScore = {
  overall: null,
  listening: null,
  reading: null,
  writing: null,
  speaking: null,
};

export const resultsBookingDetailsMockData: BookingDetails = {
  bookingUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
  personalDetails: {
    givenName: 'Charlie',
    familyName: 'Austing',
    uniqueTestTakerId: 'T-A9-5LE9-A6DG',
    birthDate: '1986-01-01',
    identityDocumentNumber: 'AB12314',
    nationality: 'United Kingdom',
    isBanned: false,
    uniqueTestTakerUuid: '53f94981-dbd5-46ea-b201-811bce647e88',
  },
  testBookingDetails: {
    testDate: '2021-03-31',
    shortCandidateNumber: '304323',
    testCentreNumber: 'GB501',
    testCentreName: 'London Test Centre',
    locationId: '742d0a15-6238-4be0-b893-38122603c5a8',
    locationName: 'London II',
    compositeCandidateNumber: '',
    productName: 'OSR Academic',
  },
  productDetails: {
    productUuid: '3e81e94b-8b6a-42b5-970c-b141f9d195a3',
    component: 'R',
    productName: 'IAH Academic',
    productDescription: '',
  },
  currentResultStatus: {
    resultsStatusHistoryUuid: '',
    resultStatusTypeUuid: '735d2d71-b4a9-47ec-b566-34b2d3015540',
    resultStatusType: 'Unconfirmed',
    resultStatusLabel: 'Manual Marks Update',
    resultStatusLabelUuid: '52a50291-bd70-4989-9fce-584b0aa3cc65',
    resultStatusComment: 'In-room identity swap',
    resultStatusCommentUuid: '123a33a0-693c-4dfd-824f-962784f8bf7d',
    resultStatusUpdateDatetime: '2021-12-24',
    resultStatusUpdatedBy: '',
    onHold: true,
  },
  resultDetails: {
    cefrLevel: 'C1',
    resultScore: 8,
    resultUuid: '6392e6c9-9e64-4ff9-a258-a910f9309d4e',
    trfNumber: '2220000526GAYE1IHA',
  },
  latestComponentScore: latestComponentScoreMockData,
  linkedBookingDetails: {
    bookingUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
    testDate: '2020-01-02',
    shortCandidateNumber: '000123',
    compositeCandidateNumber: '201IHA71863',
    testCentreNumber: '201IH',
    testCentreName: 'IOL BC',
    locationId: 'GBR',
    locationName: 'London',
    productName: 'OSR Academic',
  },
};

export const linkedBookingDetails: LinkedBookingDetailsData = {
  bookingUuid: 'b32a82a0-693c-4dfd-824f-962784f8bf7d',
  testDate: '2020-01-02',
  shortCandidateNumber: '000123',
  compositeCandidateNumber: '201IHA71863',
  testCentreNumber: '201IH',
  testCentreName: 'IOL BC',
  locationId: 'GBR',
  locationName: 'London',
  productName: 'OSR Academic',
};
