export const mockRoSearchPayload = {
  criteria: {
    organisationName: '3423424',
    organisationId: '13455',
    contactName: '',
    organisationStatus: 'Active',
    verificationStatus: 'Approved',
    organisationTypeUuid: '9edbc4ef-b58f-445c-bc41-1239e0168c9e',
    city: 'Cambridge',
    postalCode: 'CB2 8EA',
    contactEmail: 'alan@gmail.com',
    partnerCode: 'IDP',
    fuzzyMatch: false,
  },
  pagination: {
    pageNumber: 1,
    pageSize: 50,
  },
  sorting: [
    {
      sortBy: 'OrganisationName',
      sortType: 'ASC/DSC',
    },
  ],
};

export const mockRoSearchResponse = {
  status: 'success',
  body: {
    meta: {
      correlationId: '3e81e94b-8b6a-42b5-970c-b141f9d195a4',
      connectionId: 'e873fca7-849b-4e3b-8dfc-b6b5108608db',
    },
    response: {
      search: mockRoSearchPayload,
      result: {
        totalCount: '123',
        entries: [
          {
            recognisingOrganisationUuid: '9edbc4ef-b58f-445c-bc41-1239e0168c9e',
            organisationName: '3423424',
            organisationId: '13455',
            organisationTypeUuid: '9edbc4ef-b58f-445c-bc41-1239e0168c9e',
            organisationStatus: 'Active',
            parentRecognisingOrganisationUuid: '84312ab3-026c-4866-88b0-18d64771c16d',
            verificationStatus: 'Approved',
            addresses: [
              {
                addressUuid: 'ba0b67f6-adfc-4d47-a9cb-0da8655075ac',
                addressTypeUuid: '8088042f-c82f-418c-90a4-2e20e8ef40b3',
                addressLine1: '22 Heathfield Gardens',
                addressLine2: 'string',
                addressLine3: 'string',
                addressLine4: 'string',
                city: 'Cambridge',
                territoryUuid: 'dd858eb6-4738-479a-9bd7-3e293aa271b5',
                territoryIsoCode: 'GB-BIR',
                countryIso3Code: 'GBR',
                postalCode: 'CB2 8EA',
                email: 'alan@gmail.com',
                phone: '+1 234 234 3456',
                country: 'Afganistan',
              },
              {
                addressUuid: '4be28313-fd8e-46de-9449-d12fc1caeda8',
                addressTypeUuid: 'c96fbd08-a302-4aa2-a594-13cdb33bb380',
                addressType: 'Main',
                addressLine1: 'sit test',
                addressLine2: 'string',
                addressLine3: 'string',
                addressLine4: 'string',
                city: 'Mumbai',
                territoryUuid: 'dd858eb6-4738-479a-9bd7-3e293aa271b5',
                countryUuid: '211d70ab-8739-46dd-b846-f2d8c174c2d0',
                territoryIsoCode: 'GB-BIR',
                countryIso3Code: 'GBR',
                postalCode: 'CB2 8EA',
                email: 'alan@gmail.com',
                phone: '+1 234 234 3456',
                country: 'India',
              },
            ],
            partnerCode: 'IDP',
            partnerContact: 'string',
            organisationCode: 'UCAS231',
            softDeleted: 'false',
          },
        ],
      },
    },
    errors: {
      errorList: [
        {
          interface: 'POST/v1/users',
          type: 'VALIDATION',
          errorCode: 'V0023',
          title: 'Validation failed',
          message: 'Attribute value is not valid',
          errorTicketUuid: '3e81e94b-8b6a-42b5-970c-b141f9d195a4',
          source: {
            path: 'User.Phone',
            value: '111 111 111',
          },
        },
      ],
    },
  },
};
