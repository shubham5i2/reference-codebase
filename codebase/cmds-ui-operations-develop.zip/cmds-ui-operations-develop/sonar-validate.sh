#!/usr/bin/env sh
# $1 = sonarLoginToken $2 = sonar url for project status
# url = sonartask url
Cyan='\033[36m'
Magenta='\033[35m'
Yellow='\033[33m'
YellowBlink='\033[33;5;7m'
Green='\033[32m'
Red='\033[31m'
White='\e[0m' # No Color
COMMAND="sonar-scanner -Dsonar.host.url=$2 -Dsonar.login=$1"
eval $COMMAND
sleep 5s
ls
url=$(sed -n 's/ceTaskUrl=//p' ./.scannerwork/report-task.txt)
echo "Wait time for the report $url"
sleep 5s
curl -k -u "$1":"" $url -o ./reports/analysis.txt
sleep 5s
echo -e "${Magenta}.....Stored results in analysis.txt....."
status=$(cat ./reports/analysis.txt | underscore extract 'task.status' | sed 's/"//g')
echo -e "${Cyan}Status as ${White}$status"
analysisId=$(cat ./reports/analysis.txt | underscore extract task.analysisId | sed 's/"//g')
echo -e "${Cyan}Analysis Id ${White}$analysisId"
sleep 3s
if [ "$status" = "SUCCESS" ]; then
    echo -e "SONAR ANALYSIS SUCCESSFUL..."
    echo -e "${YellowBlink}ANALYSING RESULTS....\033[0m${Yellow}"
    sleep 5s
    curl -k -u "$1":"" $2/api/qualitygates/project_status?analysisId=$analysisId -o ./reports/result.txt
    result=$(cat ./reports/result.txt | underscore extract projectStatus.status)
    if [ "$result" = "ERROR" ]; then
        echo -e "${Red}SONAR RESULTS FAILED${White}"
        err=$(cat ./reports/result.txt | underscore extract projectStatus.conditions)
        echo -e "${Red}"$err"${White}..."
        sleep 2s
        exit 1
    else
        echo -e "${Green}SONAR RESULTS SUCCESSFUL${White}..."
        err=$(cat ./reports/result.txt | underscore extract projectStatus.conditions)
        echo -e "${Green}"$err"${White}..."
        sleep 2s
        exit 0
    fi
else
    echo -e "${Red}SONAR ANALYSIS FAILED${White}..."
    sleep 2s
    exit 1
fi
