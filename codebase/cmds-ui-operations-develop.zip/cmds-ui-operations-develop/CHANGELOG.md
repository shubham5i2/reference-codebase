### [2.1.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.1.8...v2.1.9) (2024-05-09)


### ⚠ BREAKING CHANGES

* Feature/60322 calendar_fix_PM_screen

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!813

* Merge branch 'feature/60322_calander' into 'develop' ([08713ad](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/08713ad153fd055cb3f10ece64659af856e1cad7))

### [2.1.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.1.7...v2.1.8) (2024-05-07)


### ⚠ BREAKING CHANGES

* AA Details In MTT Page

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!809

* Merge branch 'feature/Imod_60607_aa_details_display' into 'develop' ([0f7a3c2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/0f7a3c22f29d7db971dba75fd75d875d5bab4060))


### Features

* <h2> Business feature</h2> <h3> IMOD-45743 - VO Hierarchy </h3><br/> ([0331a93](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/0331a93ad825d85ad92898724a349e2dab73fbab))

### [2.1.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.1.6...v2.1.7) (2024-04-12)


### Features

* <h2> Business feature </h2> <h3> IMOD-58929 Enable users to select AC/GT product acceptance in the RO UI </h3> <br/> ([7929ff2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/7929ff2ac794f53e62cd56c8056758585a4f0a92))

### [2.1.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.1.5...v2.1.6) (2024-04-09)


### ⚠ BREAKING CHANGES

* Rolled back the pending status PB changes

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!805

* Merge branch 'feature/Panda_PI15_internal_defect' into 'develop' ([ebbab43](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/ebbab43c16296e7ce2a6cf5e0b875aba2bfe27c5))

### [2.1.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.1.4...v2.1.5) (2024-04-08)


### Features

* <h2> Business feature</h2> <h3> IMOD-60270 - Approval Required Fix </h3><br/> ([dc9074d](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/dc9074d48339ee9f6b81cfcdf208cc4c95e23a55))

### [2.1.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.1.3...v2.1.4) (2024-04-08)


### Features

* <h2> Defect fix </h2> <h3> IMOD-60030- [CUPA - SIT] View Location Page is not displayed as expected when Location name is 300 characters. </h3><br/> ([71610b0](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/71610b075d9cc87d72b12bd839f0f27960b51cec))

### [2.1.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.1.2...v2.1.3) (2024-04-08)


### Features

* <h2> Defect fix</h2> <h3> IMOD-60236 - [CMDS - BC - SIT/UAT] - At the corner of the footer, an extra semicolon is displayed. </h3><br/> ([741d75c](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/741d75c4ab8bda6e81c46137614d566dc125cd50))

### [2.1.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.1.1...v2.1.2) (2024-04-05)


### ⚠ BREAKING CHANGES

* fixed location drop down issue

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!801

* Merge branch 'feature/Panda_PI15_internal_defect' into 'develop' ([a91f4ba](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/a91f4bae4bb573fd39927719b8d9e57065b8644a))

### [2.1.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.1.0...v2.1.1) (2024-03-27)


### Features

* <h2> Business feature</h2> <h3> IMOD-42316 - Add test centre number to advanced search criteria on Manage users screen in Staff Mgmt. </h3><br/> ([9fed7a2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/9fed7a2edbbc69eb3432329fbd7f7c6ca9ecb965))

## [2.1.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.0.17...v2.1.0) (2024-03-27)

### [2.0.17](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.0.16...v2.0.17) (2024-03-27)


### ⚠ BREAKING CHANGES

* feature/IMOD_46800_Adding_new_error_code

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!795

* Merge branch 'feature/IMOD_46800' into 'develop' ([70d2cb3](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/70d2cb3890ff548ce913159a3ff191e63dda7cab))

### [2.0.16](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.0.15...v2.0.16) (2024-03-26)


### Features

* <h2>feature</h2> <h3> IMOD-59895 The button name for product activation/deactivation is displayed as "Product Management" in the CMDS Homepage</h3><br/> ([1bb15a7](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/1bb15a7156b43fe83b269c7aa4ac9a934a2bb82a))

### [2.0.15](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.0.14...v2.0.15) (2024-03-26)


### Features

* <h2>feature</h2> <h3> Imod 58420 verified ro </h3><br/> ([978a246](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/978a246f51623f77e268af921b4c05567bb91923))

### [2.0.14](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.0.13...v2.0.14) (2024-03-26)


### Features

* <h2>feature</h2> <h3>Imod 58929 enable accept ac gt toggle </h3><br/ ([cbea7f8](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/cbea7f8fbe30c9f6ec1d35490c5d04b7156de4d1))

### [2.0.13](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.0.12...v2.0.13) (2024-02-15)


### Features

* <h2> Business feature</h2> <h3> IMOD-57398 - Support a status of "Pending" for Physical Building entries in LPR UI. </h3><br/> ([b178ea8](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/b178ea8c0d5b1ad6b7afc63c4579a0527b51a8e0))

### [2.0.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.0.11...v2.0.12) (2024-01-22)


### Features

* <h2>Defect Fixes</h2> <h3> IMOD- 49902 CMDS-UI Update Result status page given name and Family name letters are getting overlapped </h3>> <h3> IMOD-35278 Result Status Drop down is showing current status by default </h3><br/> ([7bd78c9](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/7bd78c919db9d0765f2248cf80236df411b1e047))

### [2.0.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.0.10...v2.0.11) (2024-01-19)


### Features

* <h2>Defect Fixes</h2> <h3 IMOD-56160 Access arrangements UI contains placeholder text </h3><br/> ([8c9cec5](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/8c9cec5a7c5eac0520fd767267a56da8b08c98a4))

### [2.0.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.0.9...v2.0.10) (2024-01-16)


### Features

* <h2>Defect Fixes</h2> <h3> IMOD-48416 CMDS -IDP- SIT/UAT | Using Partner Operations Manager role, we are able to update the RO and VO details from CMDS UI portal</h3><br/> ([19fef6c](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/19fef6cdfcb6e525e132c544f967e6a8c4e53fd9))

### [2.0.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.0.8...v2.0.9) (2024-01-12)


### Features

* <h2>Defect fixes</h2> <h3> IMOD-57121 Product Management screens are not working </h3><br/> ([1126e8c](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/1126e8c4d8af51eba9a158b5916674068cf90aeb))

### [2.0.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.0.7...v2.0.8) (2023-12-29)


### Features

* <h2>Technical improvements</h2> <h3 IMOD- 53437 Load Products dropdown using synchronous API in CMDS UI </h3><br/> ([c61921c](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/c61921c961cf2304c744038ebc1e3ae6e0a041f3))

### [2.0.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.0.6...v2.0.7) (2023-12-22)


### Features

* <h2>Technical Improvements</h2><h3>IMOD-48249 - Refactor the APP component </h3<br/> ([28210b1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/28210b1e22682e07a79df534acb5e0b9f59b02e5))

### [2.0.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.0.5...v2.0.6) (2023-12-21)


### Features

* <h2>Technical Improvements</h2><h3>IMOD-55265 - Dropdown UI library component-Refactoring </h3<br/> ([afa7709](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/afa77091817a680e1294e45547609c6c1a6ae40d))

### [2.0.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.0.4...v2.0.5) (2023-12-12)


### Features

* <h2>Technical Improvements</h2><h3>IMOD-53361 - Refactor Reference data service helper to support synchronous HTTP APIs </h3<br/> ([fe1fd14](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/fe1fd146131b6a47fd2a231e78cbc3bb322443d4))

### [2.0.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.0.3...v2.0.4) (2023-12-12)


### Features

* <h2>Technical improvements</h2><h3>IMOD-Move profile header component out of library </h3<br/> ([ce4e310](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/ce4e31090d160da4fcd2114d8ffa6ae55cab442c))

### [2.0.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.0.2...v2.0.3) (2023-11-27)


### Features

* <h2>Technical improvements</h2> <h3> IMOD-52648 - Enhance AsyncPreloaderService to support synchronous HTTP API's </h3><br/> <h3> IMOD-53360 - Refactor Location Management service helper to support synchronous HTTP APIs </h3><br/> ([32c5541](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/32c55417b1dc5d76343ac9b7ab19e7730ad5131a))

### [2.0.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.0.1...v2.0.2) (2023-11-27)


### Features

* <h2>Technical improvements</h2> <h3 IMOD-48252 New Library component for Spinner </h3><br/>> <h3 IMOD-48253 New Library component for Tooltip </h3><br/> ([0d1fd52](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/0d1fd524475f78db87e21e99ac2c330a4573cf2f))

### [2.0.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v2.0.0...v2.0.1) (2023-11-17)


### Features

* <h2>Defect fixes</h2> <h3> IMOD-44555 Some permissions are not working as expected for Global Support Senior Admin </h3><br/> ([db53fd0](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/db53fd009ffea923bb80182c72ed1f878cf4f642))

## [2.0.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.20.2...v2.0.0) (2023-11-17)


### Features

* <h2>Technical improvements</h2> <h3>IMOD- IMOD-Fix sonar quality issues identified in cmds-ui-operations .<br/> IMOD-48433- Strongly type the cmds-ui-common-library organisms <br/> IMOD-48432 Strongly type the cmds-ui-common-library Molecules<br/> IMOD-48248- Move Status component to common library <br/> IMOD-43697 Move Grid, grid pagination and page size selection to cmds-ui-common-library and add the loader and no data view option <br/> IMOD-43699 Move DisplayLabelValuePair component to cmds-ui-common-library </h3><br/> ([0b50877](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/0b508772ada0346bb352a6edfda61bd910e8b54d))

### [1.20.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.20.1...v1.20.2) (2023-11-16)


### Features

* <h2> Defect fixes</h2> <h3>IMOD- IMOD-49826 added api error code in UI for partner code validation .</h3><br/> ([d2d1ded](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/d2d1deda2d807373aaf73a1bd4fbe05fffb2ee3d))

### [1.20.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.20.0...v1.20.1) (2023-11-10)


### ⚠ BREAKING CHANGES

* Dummy changes for release tag -imod 54522 defect fix

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!765
* IMOD-54522 Global user not able to add or delete location

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!764

* Merge branch 'feature/IMOD-54522_defect_fix' into 'develop' ([70079cd](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/70079cd452d837207849476352e2fd7fa8134474))
* Merge branch 'feature/Release-tag-IMOD-54522_defect_fix' into 'develop' ([3acf98c](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/3acf98cf919919391a4dbfaaea67d929d2cd5211))


### Features

* <h2> Defect fix</h2> <h3>IMOD-54522 Global user not able to add or delete location .</h3><br/> ([0365e7c](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/0365e7c3ce82d2963dfac57d82171dd4f4c02aeb))

## [1.20.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.19.8...v1.20.0) (2023-10-06)


### Features

* <h2> Business feature</h2> <h3> IMOD-47793 - UI to display and activate/deactivate products at the environment level.</h3><br/><h3> IMOD-47804 - Activate/deactivate products in the CMDS UI.</h3><br/><h3> IMOD-51406 - RBAC privileges for Manage Products UI - UI Part.</h3><br/> ([4aba018](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/4aba018efde31036919584dab46471cc902b5264))

### [1.19.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.19.7...v1.19.8) (2023-10-06)


### Features

* <h2> Technical improvements</h2> <h3> IMOD-48429- Strongly type the cmds-ui-common-library Atoms .</h3><br/> ([bccd755](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/bccd755865b314610be426ff8fe44c358555fda8))

### [1.19.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.19.6...v1.19.7) (2023-09-22)


### Features

* <h2> Business feature</h2> <h3>IMOD- IMOD-25864 - Apply assessed scores for exempted components .</h3><br/> ([9e41dd6](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/9e41dd6b794e26a0eb2100e27ecec8f8ae2228cd))

### [1.19.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.19.5...v1.19.6) (2023-09-15)


### Features

* <h2>Business Features</h2> <h3>IMOD-49966 Add verrified verification status to RO </h3> ([03b334f](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/03b334f708a57e36f040e501687fdb60c19992d2))

### [1.19.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.19.4...v1.19.5) (2023-09-07)


### Features

* <h2>Defect Fixes</h2> <h3>IMOD-50171 - Score History_Results type is still showing as Absent but not reset, and overall scores aren't showing, after performing 'Marked AB in error' .</h3><br/> ([52c0c8d](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/52c0c8d91dc139012cb7dd73917835f8e4edc730))

### [1.19.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.19.3...v1.19.4) (2023-09-05)


### Features

* <h2>Defect Fixes</h2> <h3>IMOD-42576 - Role assignment privileges not working as expected.</h3><br/> <h3>IMOD-47711 - Getting Blank Location and User group on the Update- Assign user group screen.</h3><br/> ([9783920](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/9783920d896444d6de0342c9064c7852cf6637b7))

### [1.19.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.19.2...v1.19.3) (2023-09-04)


### ⚠ BREAKING CHANGES

* feature/IMOD-48273-score-history-changes-eor-pending.

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!725

* Merge branch 'feature/IMOD-48273-score-history-changes-eor-pending' into 'develop' ([d2132b6](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/d2132b60e80d5949d4bd493b19d912484438cf61))

### [1.19.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.19.1...v1.19.2) (2023-09-04)


### ⚠ BREAKING CHANGES

* feature/LPR_payload_changes

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!741

* Merge branch 'feature/LPR_payload_changes' into 'develop' ([9186413](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/9186413e9fd4082c808e1aa0790b5cde82392fb9))

### [1.19.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.19.0...v1.19.1) (2023-08-28)


### ⚠ BREAKING CHANGES

* feature/IMOD-45256-search-apiIntegration

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!717

* Merge branch 'feature/IMOD-45256-search-apiIntegration' into 'develop' ([0394e7f](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/0394e7f613823a7a5f83a85ef8ba9d162d41b130))

## [1.19.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.28...v1.19.0) (2023-08-18)


### Features

* <h2>Defect Fixes</h2><h3>IMOD-48010 - CMDS BC (GLOBAL)   Unable to update user as the location is not populating.</h3><br/> ([baaad1c](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/baaad1cab4af9eeefe9edcc1934fccfed6b54767))

### [1.18.28](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.27...v1.18.28) (2023-08-16)


### Features

* </h1> <h2>Business Features</h2> <h3>IMOD-46772 Replace Verification status with Org type on RO main and duplicate search results screen </h3> <p><strong>Purpose:</strong><br /> swap the Org Type column and verification status for better usability.</p><br /> <h3>IMOD-46521 Changes to RO search results screen</h3> <p><strong>Purpose:</strong><br />Changes to Organisation search screen to improve the usability.</p><br /> <h3>IMOD-46707 Toggle between exact match and fuzzy search criteria in the main RO search screen </h3> <p><strong>Purpose:</strong><br />A toggle switch to toggle between fuzzy match and exact match for main RO search screen. </p><br /> <h3>IMOD-42710: Toggle between exact match and fuzzy search criteria in the duplicates RO search screen </h3> <p><strong>Purpose:</strong><br /> A toggle switch to toggle between fuzzy match and exact match for duplicate RO search screen. </p><br /> ([94ee4ab](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/94ee4abd934c15a5b6c7138f6e4562ecd3a7735f))

### [1.18.27](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.26...v1.18.27) (2023-08-16)


### Features

* <h2>Technical Features</h2><h3>IMOD-46593 corrected the value of product response to accept the product values and show in the product description in the Incident Management Page.</h3><p><strong>Purpose: product data was not showing in the Incident Management Page.</strong><br /></strong><br /></p> ([4079886](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/4079886f0931d27ca0f1414a78e48f6071af1063))
* <h2>Technical Features</h2><h3>IMOD-48882 UI issue - fixed the issue of location dropdown menu not being selected </h3><p><strong>Purpose: fixed the issue of location dropdown menu not being selected</strong></br></p> ([00a698e](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/00a698ef291f54b66be30bd5aac0cdcd5cb575a0))

### [1.18.26](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.25...v1.18.26) (2023-08-14)


### Features

* <h2>Technical Features</h2><h3>IMOD-49582 Results are getting Withheld in RM despite probable ban consideration removed from RI</h3><p><strong>Purpose: Checking the applicable check outcomes before sending evt-044 to RM</strong><br/></strong><br/></p> ([e8e435f](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/e8e435f2d80cb456ed0ba2c882571bff1161a764))

### [1.18.25](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.24...v1.18.25) (2023-08-10)


### Features

* <h2>Technical Features</h2> ([48201ec](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/48201ec3ec471f8fba54808c892a18977257afe8))

### [1.18.24](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.23...v1.18.24) (2023-08-09)


### Features

* <h2>Business features</h2><h3>IMOD-40459 Add new tile for Access Arrangements in CMDS portal </h3><p><strong>Purpose:</strong><br />A new tile to be added in CMDS portal to access AA User Interface. So that the authorized users can save or search for AA case/requests  </strong><br /></p> <h3>IMOD-40889 Create user interface for AA home screen</h3><p><strong>Purpose:</strong><br />Create User interface for AA home screen that provides ability to create or search for access arrangement cases/request</p><h3>IMOD-41969 View AA details for a AA case number/request</h3><p><strong>Purpose:</strong><br />AA Mx to present a screen with details of access arrangement request. So that the authorized user can view the applicable access arrangement options.<h3>IMOD-43322 Add left hand navigation icon for Access Arrangements</h3><p><strong>Purpose:</strong><br />A left hand navigation icon to be added in CMDS portal to access AA User Interface. So that the authorized users can navigate to Access Arrange UI from CMDS portal.<h3>IMOD-44322 Provide Role Based Access Control to AA left hand navigation icon in CMDS portal</h3><p><strong>Purpose:</strong>Limit access to Access Arrangement (AA) UI via the navigation icon. So that only users with the defined roles can access the AA portal and save and search AA requests<h3>IMOD-45052 User can enter First Name or Last Name or both while creating new AA case/request</h3><p><strong>Purpose:</strong><br />Allow the user to enter First Name or Last Name or both the field while creating new AA Case. So that AA case can be raised successfully.<h3>IMOD 40434 Create user interface for saving an AA request in AA Mx</h3><p><strong>Purpose:</strong><br />Create User interface for saving an access arrangement cases/request. So that the authorized users can create new access arrangement request/case.<h3>IMOD-40457 User can search for existing access arrangements cases/requests</h3><p><strong>Purpose:</strong><br />Ability to search for Access Arrangement case in AA UI (for an authorized user), so that they can view the details of the AA case/request.<h3>IMOD-40458 Provide Role Based Access Control to Access Arrangement tile in CMDS portal</h3>Limit access to Access Arrangement (AA) UI, so that only users with the defined roles can access the AA portal and save and search AA requests. ([88752d6](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/88752d6db2890083cf2dad895bd06874bdd6a2f2))

### [1.18.23](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.22...v1.18.23) (2023-08-08)


### ⚠ BREAKING CHANGES

* Feature/v57.green releasenotes trigger

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!723

* Merge branch 'feature/v57.green_releasenotes_trigger' into 'develop' ([9a4a307](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/9a4a30702ce1769b78dda239373875bbd5e11e6e))


### Features

* <h1>Features :</h1> <h2>Business Features</h2> <h3>IMOD-42780 Remove Test Centre Admin UUID from the location management screens in LPR </h3> <p><strong>Purpose:</strong><br />Removing all references to the Test Centre Manager as it is not required. </p><br /> <h3>IMOD-42789 Add a "Pending" option to the Status field for TC locations in LPR</h3> <p><strong>Purpose:</strong><br />Adding additional option of “Pending” to be available for the “LOCATION_STATUS” column so that users can manage TC locations effectively. </p><br /> <h3>IMOD-42878 Change APPROVED_DATE to ACTIVATED_DATE in LPR </h3> <p><strong>Purpose:</strong><br />changing APPROVED_DATE field to capture the date of first activation for Test Centres and PBs so that It can continue to have visibility of location creation after the Approval status is removed. </p><br /> <h3>IMOD-42784: Remove "Request status" from the location management screens in LPR </h3> <p><strong>Purpose:</strong><br /> Request status removed from the location screens in LPR so that not capturing data that is no longer required. </p><br /> <h3>IMOD-30211 RM UI: Include information on linked bookings </h3> <p><strong>Purpose:</strong><br /> Showing the linked booking details So that the users will be able to view the details of original and OSR bookings. </p><br /> <h3>IMOD-46502: Add State/Territory to search criteria for an RO/VO</h3> <p><strong>Purpose:</strong><br /> Able to search for ROs on the basis of their State/Territory so that It can be more efficient. </p><br /> <h2>Technical Features</h2> <h3>IMOD-44284 Upgrade local environment and Gitlab runner docker image with the LTS Node version. </h3> <p><strong>Purpose:</strong><br />Since the node team edded the support for node version perviously used, we migrated to latest supported version of node.</p><br /> <h2>Defect Fixes</h2> <h3>IMOD-47858 Request body should be empty for TRF/ETRF download request from CMDS UI. </h3> <h3>IMOD-48401 100 character limit in RO website data field. </h3> <h2>Additional Info</h2> <h3>IMOD-48898 [SIT Release v0.0.57.1] - DevOps Support - UI Deployment </h3> <p><strong>Purpose:</strong><br /> To define release version details for CMDS UI deployment. </p><br /> <h3>IMOD-49012 [SIT Release v0.0.57.1] - Smoke Test - UI Deployment </h3> <p><strong>Purpose:</strong><br /> To track smoke test results.</p><br /> ([750068e](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/750068eff1b3daf512dd3be4d828c5a0d36a02ea))

### [1.18.22](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.21...v1.18.22) (2023-08-04)


### ⚠ BREAKING CHANGES

* Feature/IMOD-48401_increase_websiteurl_validation

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!720

* Merge branch 'feature/IMOD-48401_increase_websiteurl_validation' into 'develop' ([9717f07](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/9717f07bc56c547ef847c6f3bf922ceb0800fd12))

### [1.18.21](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.20...v1.18.21) (2023-08-02)

### [1.18.20](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.19...v1.18.20) (2023-07-19)

### [1.18.19](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.18...v1.18.19) (2023-07-18)


### ⚠ BREAKING CHANGES

* Feature/v56.4 releasenotes trigger

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!716

* Merge branch 'feature/v56.4_releasenotes_trigger' into 'develop' ([152a060](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/152a060cb0c7f2e78c3c3b58ffe9c4231074fc91))


### Features

* <h1>Features :</h1> <h2>Business Features</h2> <h3>IMOD-39569 Add Country to search criteria for an RO/VO </h3> <p><strong>Purpose:</strong><br />To be able to search for ROs on the basis of their Country. </p><br /> <h3>IMOD-39569 RM UI: Manage Results pages UI Enhancement </h3> <p><strong>Purpose:</strong><br />To enhance the Manage results pages UI. </p><br /> <h3>IMOD-36243 Enable read-only access to LPR Test Centre data for partner users </h3> <p><strong>Purpose:</strong><br />IELTS Partner manager can access location data for their Test Centres and their buildings and rooms in read only mode. </p><br /> <h3>IMOD-39138 [B-MX] UI: Enrich Booking details view with OSR specific data </h3> <p><strong>Purpose:</strong><br />To have visibility to the OSR Booking details in CMDS UI, including a clear indicator of which component the OSR was raised against. Helps to clearly identify the OSR component. </p><br /> <h2>Technical Features</h2> <h3>IMOD-40400 CMDS UI Performance improvements screen level implementations. </h3> <p><strong>Purpose:</strong><br />To improve CMDS UI performance and user experience by reducing API calls using cache and moving away from full screen loaders to element level loaders.</p><br /> <h2>Defect Fixes</h2> <h3>IMOD-43954 [CMDS - BC - SIT] - Add new user - Option of BC China is not displayed properly in organisation list box </h3><br /> <h2>Additional Info</h2> <h3>IMOD-45363 [SIT Release v0.0.56.4] - DevOps Support - UI Deployment </h3> <p><strong>Purpose:</strong><br /> To define release version details for CMDS UI deployment. </p><br /> <h3>IMOD-48321 [SIT Release v0.0.56.4] - Smoke Test - UI Deployment </h3> <p><strong>Purpose:</strong><br /> To track smoke test results.</p><br /> <h3>IMOD-42534 [Infra] - Need to create ssm parameter for CMDS UI in SIT </h3> <p><strong>Purpose:</strong><br /> Add new SSM parameters to SIT </p><br /> ([407d95f](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/407d95fdc1bd76b0b8f3e094150fe6e8ccd8d00d))

### [1.18.18](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.17...v1.18.18) (2023-07-12)


### ⚠ BREAKING CHANGES

* feature/IMOD-48009-defect-fix

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!712

* Merge branch 'feature/IMOD-48009-defect-fix' into 'develop' ([e5d9603](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/e5d96036d4460013d715372b09bf11fd52061b54))

### [1.18.17](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.16...v1.18.17) (2023-07-07)


### ⚠ BREAKING CHANGES

* Feature/IMOD-44284_LTS_node migrate

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!697

* Merge branch 'feature/IMOD-44284_lts_node_migrate' into 'develop' ([0cf1e1a](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/0cf1e1acf13afbe21b70fab57b92623a0518e846))

### [1.18.16](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.15...v1.18.16) (2023-06-29)


### ⚠ BREAKING CHANGES

* feature/IMOD-47858-TRF-download-defect-fix

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!708

* Merge branch 'feature/IMOD-47858-TRF-download-defect-fix' into 'develop' ([92b6d0b](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/92b6d0b7b686934d142d8716031e119e3eb4b38a))

### [1.18.15](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.14...v1.18.15) (2023-06-28)


### ⚠ BREAKING CHANGES

* feature/IMOD-46502-add-territory

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!700

* Merge branch 'feature/IMOD-46502-add-territory' into 'develop' ([3296b53](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/3296b5354b45408d14e1eeb9204978cfeafdc531))

### [1.18.14](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.13...v1.18.14) (2023-06-21)


### ⚠ BREAKING CHANGES

* added styles for incomplete status

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!707

* Merge branch 'feature/IMOD-44383-incomplete-status' into 'develop' ([935fe64](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/935fe64eaf300ff0951801137bb460ee8b7a5a1c))

### [1.18.13](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.12...v1.18.13) (2023-06-14)


### ⚠ BREAKING CHANGES

* IMOD-46969_Merging back hotfix to develop

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!703

* Merge branch 'feature/PI13_panda_predevelop' into 'develop' ([d1d943c](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/d1d943cb1e7f911bf1ce3e371e1c5e217348c6e5))

### [1.18.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.11...v1.18.12) (2023-05-24)


### ⚠ BREAKING CHANGES

* Feature/linked booking details

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!669

* Merge branch 'feature/LinkedBookingDetails' into 'develop' ([28d989a](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/28d989ae61e06862f40e230e7d954126fea276b3))

### [1.18.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.10...v1.18.11) (2023-05-23)


### ⚠ BREAKING CHANGES

* Feature/location managment changes imod 42780 42789 42878 42784

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!695

* Merge branch 'feature/location-managment-changes-imod-42780-42789-42878-42784' into 'develop' ([0ef1001](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/0ef1001171f71fdf23465eef3bb51c3b65ed84c7))

### [1.18.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.9...v1.18.10) (2023-04-10)


### ⚠ BREAKING CHANGES

* Feature/osr scaling changes

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!689

* Merge branch 'feature/Osr-scaling-changes' into 'develop' ([d34b987](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/d34b987ad2b2f7281a8ea29a572901eeb9ff917a))

### [1.18.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.8...v1.18.9) (2023-04-06)


### ⚠ BREAKING CHANGES

* updated dashboard changes and added ssm parameters

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!688

* Merge branch 'feature/dashboard' into 'develop' ([9542671](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/95426714dd4f46cc0ba745e8a3f531d9a5ed618b))

### [1.18.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.7...v1.18.8) (2023-04-06)


### ⚠ BREAKING CHANGES

* updated dashboard changes and docker runner image

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!687

* Merge branch 'feature/dashboard_changes' into 'develop' ([a5cd884](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/a5cd884d24f6e47e05721a70becfc566348d55ce))

### [1.18.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.6...v1.18.7) (2023-04-05)


### ⚠ BREAKING CHANGES

* Feature/rm ui enhancements

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!649

* Merge branch 'feature/RM-UI-enhancements' into 'develop' ([c145d0b](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/c145d0b76e0a6bf78a7cf2b3c6933424efad49ca))

### [1.18.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.5...v1.18.6) (2023-04-03)


### ⚠ BREAKING CHANGES

* IMOD-36243 Read only access for test centre and Physical buildings

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!684

* Merge branch 'feature/panda_quick_fix' into 'develop' ([808ff73](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/808ff73dc830c6b6b1df69fe1cf6260c422e009b))

### [1.18.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.4...v1.18.5) (2023-04-03)


### ⚠ BREAKING CHANGES

* Feature/imod 35959 ui enhancement

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!622

* Merge branch 'feature/imod-35959-ui-enhancement' into 'develop' ([2c8abb6](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/2c8abb6cfc755674f27da2ed55bc57160fc5e4f7))

### [1.18.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.3...v1.18.4) (2023-03-31)


### ⚠ BREAKING CHANGES

* Add country in organisation advanced search

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!680

* Merge branch 'feature/IMOD-39569_Add_Country_In_Organisation_search' into 'develop' ([da5ebfd](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/da5ebfdb257cd00bf3ace0aee7a0f55f001c247b))

### [1.18.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.2...v1.18.3) (2023-03-28)


### ⚠ BREAKING CHANGES

* removed unused types..

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!683

* Merge branch 'feature/IMOD-41719-dropdown-big-fix' into 'develop' ([b362d41](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/b362d414beb8e0a4ad495481cfdf63011c949629))

### [1.18.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.1...v1.18.2) (2023-03-15)


### ⚠ BREAKING CHANGES

* uploading ui-operations hotfix zip artifacts into nexus hotfix repository

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!674

* Merge branch 'feature/IMOD-43694' into 'develop' ([ea7064f](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/ea7064f15053b046592d39150c27749bc55a4561))

### [1.18.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.18.0...v1.18.1) (2023-03-15)


### ⚠ BREAKING CHANGES

* Navigation on SM cancel button

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!673

* Merge branch 'feature/IMOD-43503_Navigation_on_cancel_button' into 'develop' ([3b4eb46](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/3b4eb46ac17edc0e4e29b811ac04c7e8332226e9))

## [1.18.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.27...v1.18.0) (2023-03-15)


### ⚠ BREAKING CHANGES

* Feature/IMOD-40400 UI performance improvements

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!671

* Merge branch 'feature/IMOD-40400_panda_performance_improvements' into 'develop' ([64e9ea8](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/64e9ea85f5938b87479f8a6a3948224581a8830c))

### [1.17.27](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.26...v1.17.27) (2023-03-13)


### ⚠ BREAKING CHANGES

* Page refresh issue

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!666

* Merge branch 'feature/IMOD-42099_Refresh_page_issue' into 'develop' ([d649363](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/d6493634c571a78549f06e807644fa9c3b6c4616))

### [1.17.26](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.25...v1.17.26) (2023-03-13)


### ⚠ BREAKING CHANGES

* Changed Accept SSR label

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!672

* Merge branch 'feature/IMOD-36331_AcceptSSR_label_change' into 'develop' ([ef66754](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/ef6675418370ed9997c8e0fc485dc48e106fe69a))

### [1.17.25](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.24...v1.17.25) (2023-03-09)


### ⚠ BREAKING CHANGES

* Updating API error

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!670

* Merge branch 'feature/IMOD-42190_Updating_API_error' into 'develop' ([2871132](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/2871132f22e3e940f65e4a97f9d2047921a2ed51))

### [1.17.24](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.23...v1.17.24) (2023-03-02)


### ⚠ BREAKING CHANGES

* Feature/IMOD-42588-Product date range issue fix

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!662

* Merge branch 'feature/panda_quick_fix' into 'develop' ([62dbd9c](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/62dbd9cb2cabb867319f12a75fa9286425fa21e2))

### [1.17.23](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.22...v1.17.23) (2023-02-27)


### ⚠ BREAKING CHANGES

* Location left navigation icon

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!661

* Merge branch 'feature/Location_leftNavigation_icon' into 'develop' ([1aba5dc](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/1aba5dcaaa0de787c8c7c04c22b88be9487277b7))

### [1.17.22](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.21...v1.17.22) (2023-02-27)


### ⚠ BREAKING CHANGES

* Updated edit physical building title

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!660

* Merge branch 'feature/IMOD-40048_UpdateScreen_Label' into 'develop' ([6919aae](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/6919aaeaa9966de0a654a51f6c718b53adefdb44))

### [1.17.21](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.20...v1.17.21) (2023-02-24)


### ⚠ BREAKING CHANGES

* Timeout Fix

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!659

* Merge branch 'feature/panda_quick_fix' into 'develop' ([c2c0253](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/c2c0253bdf76ec754bdad63b17aac6425598807d))

### [1.17.20](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.19...v1.17.20) (2023-02-23)


### ⚠ BREAKING CHANGES

* Fixed organisation permission issue for policy team manager IMOD-42233

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!657

* Merge branch 'feature/panda_quick_fix' into 'develop' ([01d16dd](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/01d16dd3478b92ec9e0059d8ee8e920f37930581))

### [1.17.19](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.18...v1.17.19) (2023-02-21)


### ⚠ BREAKING CHANGES

* View Test centre screen

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!637

* Merge branch 'feature/IMOD-41524_View_TestCentre_Screen' into 'develop' ([bdec8c2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/bdec8c294e2d4eebb90128fe0eec00ff340cbb18))

### [1.17.18](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.17...v1.17.18) (2023-02-20)


### ⚠ BREAKING CHANGES

* IMOD-42445 - location type validation fix

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!655

* Merge branch 'feature/panda_quick_fix' into 'develop' ([0025bfc](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/0025bfc3318330ad0785829faeb5187638eefdf7))

### [1.17.17](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.16...v1.17.17) (2023-02-17)


### ⚠ BREAKING CHANGES

* ban status in tt search

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!654

* Merge branch 'feature/display-ban-status' into 'develop' ([6ebb2b5](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/6ebb2b5dee28a1a9bd02d55f3ee3b9e744f81f24))

### [1.17.16](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.15...v1.17.16) (2023-02-17)


### ⚠ BREAKING CHANGES

* Refactored the async preload service to display error logs

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!653

* Merge branch 'feature/panda_quick_fix' into 'develop' ([b9bd417](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/b9bd417275c8dbfa10afb2702687ef15bd645f3b))

### [1.17.15](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.14...v1.17.15) (2023-02-16)

### [1.17.14](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.13...v1.17.14) (2023-02-16)


### ⚠ BREAKING CHANGES

* Feature/imod 42230 bug fixes

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!651

* Merge branch 'feature/imod-42230-bug-fixes' into 'develop' ([e60326a](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/e60326a09c9a22f708387ee012a19e167ce19e36))

### [1.17.13](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.12...v1.17.13) (2023-02-15)


### ⚠ BREAKING CHANGES

* update results status success message big fixes

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!650

* Merge branch 'feature/IMOD-42230-results-status-success-msg' into 'develop' ([04b669e](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/04b669e4f30d528b95a490917b4eae73cc1928d1))

### [1.17.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.11...v1.17.12) (2023-02-14)


### ⚠ BREAKING CHANGES

* Feature/imod 41860 location type filter

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!647

* Merge branch 'feature/IMOD-41860_Location_type_filter' into 'develop' ([45c8a1e](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/45c8a1e54e7f419be48cbea16baac5b6c2564487))

### [1.17.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.10...v1.17.11) (2023-02-13)

### [1.17.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.9...v1.17.10) (2023-02-10)

### [1.17.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.8...v1.17.9) (2023-02-06)


### ⚠ BREAKING CHANGES

* location state management

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!630

* Merge branch 'feature/Location_state_management' into 'develop' ([39ad242](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/39ad242aa1e55c0e70b2ee225f24d2b8fbe9d7f7))

### [1.17.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.7...v1.17.8) (2023-02-06)


### ⚠ BREAKING CHANGES

* IMOD-41903/IMOD-41902-bug fixes

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!641

* Merge branch 'feature/RM-dev-bugfixes' into 'develop' ([c3502af](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/c3502af84295e1b0ac3568c4c39f5a4cbd5c5d6f))

### [1.17.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.6...v1.17.7) (2023-02-02)


### ⚠ BREAKING CHANGES

* Updated Library version-datepicker-enhancements and defect fixes

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!636

* Merge branch 'feature/date-picker-enhancements-common-library-change' into 'develop' ([736ea5a](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/736ea5a985ae9fc9b30fe6364bc1f06380b05f3d))

### [1.17.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.5...v1.17.6) (2023-02-01)


### ⚠ BREAKING CHANGES

* IMOD-32152-year-results

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!556

* Merge branch 'feature/IMOD-32152-year-results' into 'develop' ([de17971](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/de1797167b56443be654aab4a40d2f6746502962))

### [1.17.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.4...v1.17.5) (2023-01-30)


### ⚠ BREAKING CHANGES

* Location Search screen

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!628

* Merge branch 'feature/IMOD-40041_Seach_TestCentre' into 'develop' ([a5e6aa0](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/a5e6aa0c43c966566581bae28f5666e05a30d1ac))

### [1.17.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.3...v1.17.4) (2023-01-25)


### ⚠ BREAKING CHANGES

* enable staging environement

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!634

* Merge branch 'feature/imod-staging-rollout' into 'develop' ([494aede](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/494aede96ea1e2d7ab15c57db86a2f52aedc04d9))

### [1.17.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.2...v1.17.3) (2023-01-25)


### ⚠ BREAKING CHANGES

* Defect fix IMOD-41205

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!632

* Merge branch 'feature/predevelop-panda-PI10' into 'develop' ([dfefac3](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/dfefac3a3d84538f3662ddb9a39d8b2724eed88b))

### [1.17.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.1...v1.17.2) (2023-01-24)


### ⚠ BREAKING CHANGES

* Testcentrenumber API error

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!631

* Merge branch 'feature/IMOD-38702_API_Error_Testcentrenumber' into 'develop' ([535acfe](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/535acfe6178a71a4c2c006e8e6fd738a7a70d16b))

### [1.17.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.17.0...v1.17.1) (2023-01-18)


### ⚠ BREAKING CHANGES

* Defect Fixes

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!621

* Merge branch 'feature/Website_Url_Defect_IMOD-39668' into 'develop' ([e31e882](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/e31e8826d7bf351cd0ca747f92db7cc97a5eac5f))

## [1.17.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.16.11...v1.17.0) (2023-01-16)


### ⚠ BREAKING CHANGES

* IMOD-30833_UI_performance_Improvements

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!627

* Merge branch 'feature/predevelop-panda-PI10' into 'develop' ([f25f542](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/f25f542965a3a2d218efb56e5511869083b5df3c))

### [1.16.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.16.10...v1.16.11) (2023-01-12)


### ⚠ BREAKING CHANGES

* Feature/imod 35121 onhold message bug fix

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!625

* Merge branch 'feature/IMOD-35121-onhold-message-bug-fix' into 'develop' ([137f49f](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/137f49f6ff451da5c15938cec5745e1ff418c56f))

### [1.16.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.16.9...v1.16.10) (2023-01-12)


### ⚠ BREAKING CHANGES

* imod-39907-name-format-bug-fix

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!626

* Merge branch 'feature/IMOD-39907-name-format-bug-fix' into 'develop' ([190c866](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/190c86648d70bfa48a79790782f9529df943626c))

### [1.16.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.16.8...v1.16.9) (2023-01-11)

### [1.16.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.16.7...v1.16.8) (2023-01-11)

### [1.16.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.16.6...v1.16.7) (2023-01-06)


### ⚠ BREAKING CHANGES

* RM-view-details-product-name-display

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!624

* Merge branch 'feature/IMOD-40039-rm-viewdetails-bug-fixes' into 'develop' ([59caa04](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/59caa046d40f7213da5c8612561d03cd7568b9d7))

### [1.16.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.16.5...v1.16.6) (2023-01-05)


### ⚠ BREAKING CHANGES

* Added new ug support to the LM screen

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!623

* Merge branch 'feature/predevelop-panda-PI10' into 'develop' ([0c91275](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/0c912758e6e85ad9f922cdd62f977c1620c10f6f))

### [1.16.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.16.4...v1.16.5) (2022-12-23)


### ⚠ BREAKING CHANGES

* Defect Fixes

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!620

* Merge branch 'feature/IMOD-39819_Permissions' into 'develop' ([84068be](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/84068be3df83896702b0666f26820a919c526880))

### [1.16.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.16.3...v1.16.4) (2022-12-22)


### ⚠ BREAKING CHANGES

* Feature/delete ban changes integration

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!618

* Merge branch 'feature/delete-ban-changes-integration' into 'develop' ([0b438e4](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/0b438e4c51cce39520148c1a77d3fa8d059a9706))

### [1.16.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.16.2...v1.16.3) (2022-12-20)


### ⚠ BREAKING CHANGES

* Defect Fixes IMOD-39848

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!613

* Merge branch 'feature/Defect_Fix_IMOD-39626' into 'develop' ([f5fe7d7](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/f5fe7d7adc4c6b56fc4568460166383c1b5ed7e2))

### [1.16.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.16.1...v1.16.2) (2022-12-20)


### ⚠ BREAKING CHANGES

* Feature/predevelop panda pi10

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!616

* Merge branch 'feature/predevelop-panda-PI10' into 'develop' ([39af889](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/39af889cc52edac30312d52006baf35cb0aeeb99))

### [1.16.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.16.0...v1.16.1) (2022-12-20)


### ⚠ BREAKING CHANGES

* Clear parent location on partner code selection

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!614

* Merge branch 'feature/Clear-Parent-location-on-partnercode-selection' into 'develop' ([9aae8c9](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/9aae8c9f733d3ebc19f3493b602317e3fc776084))

## [1.16.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.15.16...v1.16.0) (2022-12-20)


### ⚠ BREAKING CHANGES

* Feature/predevelop panda pi10

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!612
* Location management feature

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!611

* Merge branch 'feature/predevelop-panda-PI10' into 'develop' ([6d6a1b4](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/6d6a1b42174903e6c4b21a953213ca983014d98e))
* Merge branch 'feature/predevelop-panda-PI10' into 'develop' ([34ed48e](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/34ed48e4865464d9e21c2e7d052e5bf13e5cb1de))

### [1.15.16](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.15.15...v1.15.16) (2022-12-09)


### ⚠ BREAKING CHANGES

* IMOD-35078-displaying results status, label, TestTaker name from get API.

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!584

* Merge branch 'feature/IMOD-35078-result-status-bug-fix' into 'develop' ([565eb4f](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/565eb4f8e2110c1f4c9aea81760729da67314f9c))

### [1.15.15](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.15.14...v1.15.15) (2022-12-07)


### ⚠ BREAKING CHANGES

* Feature/imod 35156 absent data ui

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!555

* Merge branch 'feature/IMOD-35156-absentData-ui' into 'develop' ([b381553](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/b381553c9e09de618ca13c2b4c7ffa08df4e710a))

### [1.15.14](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.15.13...v1.15.14) (2022-11-24)

### [1.15.13](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.15.12...v1.15.13) (2022-11-18)

### ⚠ BREAKING CHANGES

- Feature/imod 38310

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!577

- Merge branch 'feature/imod-38310' into 'develop' ([24dc8ee](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/24dc8eedb15423a3f0796d19c8a49665ee648419))

### [1.15.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.15.11...v1.15.12) (2022-11-18)

### ⚠ BREAKING CHANGES

- IMOD-38310 inactive incident types

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!576

- Merge branch 'feature/IMOD-38310_update_incident_types' into 'develop' ([d768e83](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/d768e83342c74337025a3216c1ab29c37a835953))

### [1.15.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.15.10...v1.15.11) (2022-11-16)

### ⚠ BREAKING CHANGES

- IMOD-37575-selectall-checkbox

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!571

- Merge branch 'feature/imod-37575-selectall-checkbox' into 'develop' ([1e86143](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/1e86143877963b0456d2675c88fa9ea8b141e96f))

### [1.15.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.15.9...v1.15.10) (2022-11-15)

### ⚠ BREAKING CHANGES

- feature/IMOD-34745-EvidenceFiles

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!507

- Merge branch 'feature/IMOD-34745-EvidenceFiles' into 'develop' ([7b30f38](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/7b30f38386be4cbd0f4271b41ed921536b466ee6))

### [1.15.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.15.8...v1.15.9) (2022-11-15)

### [1.15.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.15.7...v1.15.8) (2022-11-15)

### ⚠ BREAKING CHANGES

- Feature/imod 36508 manual marks update page

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!574

- Merge branch 'feature/IMOD-36508-Manual-Marks-Update-page' into 'develop' ([da7f9dc](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/da7f9dc0d4b91166148bb077d0232980bd93618f))

### [1.15.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.15.6...v1.15.7) (2022-11-14)

### [1.15.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.15.5...v1.15.6) (2022-11-11)

### [1.15.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.15.4...v1.15.5) (2022-11-09)

### [1.15.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.15.3...v1.15.4) (2022-11-09)

### [1.15.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.15.2...v1.15.3) (2022-11-09)

### ⚠ BREAKING CHANGES

- Feature/imod 36508 manual marks update page

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!536

- Merge branch 'feature/IMOD-36508-Manual-Marks-Update-page' into 'develop' ([838fcb1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/838fcb1c5d11cdbb2690101b9ed98f7fce752032))

### [1.15.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.15.1...v1.15.2) (2022-11-09)

### [1.15.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.15.0...v1.15.1) (2022-11-08)

## [1.15.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.14.20...v1.15.0) (2022-11-03)

### ⚠ BREAKING CHANGES

- added update ban feature

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!558

- Merge branch 'feature/Incredibles-Sprint-9-3' into 'develop' ([795809d](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/795809d0cb8fb9c1ac9f6f5a7dc60351126f9e7f))

### [1.14.20](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.14.19...v1.14.20) (2022-11-03)

### ⚠ BREAKING CHANGES

- IMOD-37171_defect_fix

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!557

- Merge branch 'feature/PI9_panda_defect_fix' into 'develop' ([19eae04](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/19eae042d570a2284c4d27bb301a1eeed2b1b045))

### [1.14.19](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.14.18...v1.14.19) (2022-11-02)

### ⚠ BREAKING CHANGES

- IMOD-37781_Fixed Toggle issue

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!554

- Merge branch 'feature/PI9_panda_defect_fix' into 'develop' ([b2057fa](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/b2057fa044c8bf71d33b0cde0849e4f856005c98))

### [1.14.18](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.14.17...v1.14.18) (2022-11-01)

### ⚠ BREAKING CHANGES

- feature/IncidentSearchDataFix

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!550

- Merge branch 'feature/IncidentSearchDataFix' into 'develop' ([5b76c16](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/5b76c1651f4cdb165775d5f729db2bb248573a25))

### [1.14.17](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.14.16...v1.14.17) (2022-10-28)

### ⚠ BREAKING CHANGES

- Feature/pi9 panda defect fix and library ts migration

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!526

- Merge branch 'feature/PI9_panda_defect_fix' into 'develop' ([f792c13](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/f792c13c000f83b05e574494f240338d2dbdb860))

### [1.14.16](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.14.15...v1.14.16) (2022-10-21)

### ⚠ BREAKING CHANGES

- feature/IncidentSearchScreenApiFix

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!547

- Merge branch 'feature/IncidentSearchScreenApiFix' into 'develop' ([1b81caf](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/1b81cafa0c2767bdfa9d5ef135756a6757602eaf))

### [1.14.15](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.14.14...v1.14.15) (2022-10-18)

### [1.14.14](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.14.13...v1.14.14) (2022-10-17)

### ⚠ BREAKING CHANGES

- IMOD-36548-Multiple status update bug fixes

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!543

- Merge branch 'feature/IMOD-36548-multiple-status-update-bug-fixes' into 'develop' ([9860b95](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/9860b954142f3a6dec0145c360df6d1ba40dd81d))

### [1.14.13](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.14.12...v1.14.13) (2022-10-10)

### ⚠ BREAKING CHANGES

- feature/Imod-36259-HighResPhoto

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!538

- Merge branch 'feature/Imod-36259-HighResPhoto' into 'develop' ([02aa80d](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/02aa80d3a1243a004103c8cbc566f31a86c028ff))

### [1.14.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.14.11...v1.14.12) (2022-09-30)

### ⚠ BREAKING CHANGES

- Defect_Fix_IMOD-8962

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!535

- Merge branch 'feature/Defect_Fix_Sprint_PI9' into 'develop' ([9d8772a](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/9d8772a3e3ae1822b19a3e29543f8585b58ff782))

### [1.14.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.14.10...v1.14.11) (2022-09-30)

### ⚠ BREAKING CHANGES

- Feature/imod 32986 enable icons viewresult

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!515

- Merge branch 'feature/imod-32986-enable-icons-viewresult' into 'develop' ([3985357](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/3985357ae9d88004956637483112dd2eaeb373bb))

### [1.14.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.14.9...v1.14.10) (2022-09-30)

### ⚠ BREAKING CHANGES

- Defect Fix IMOD-8962

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!534

- Merge branch 'feature/Defect_Fix_Sprint_PI9' into 'develop' ([2379308](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/23793089cf4e885dcc355da87ec21a4f30b3ad14))

### [1.14.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.14.8...v1.14.9) (2022-09-29)

### ⚠ BREAKING CHANGES

- Feature/imod 22330 score history bug fixes

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!521

- Merge branch 'feature/imode-22330-score-history-bug-fixes' into 'develop' ([3affc77](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/3affc77c5bd9ec47bed2884bc48820d89ce7ba4d))

### [1.14.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.14.7...v1.14.8) (2022-09-29)

### ⚠ BREAKING CHANGES

- Panda defect fix PI9 sprint 8

Fixed IMOD-21116, IMOD-34665, IMOD-8962,and IMOD-34807.

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!525

- Merge branch 'feature/Defect_Fix_Sprint_PI9' into 'develop' ([69e148c](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/69e148ce772c276ce7d66d5abba3ea4430480ed5))

### [1.14.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.14.6...v1.14.7) (2022-09-26)

### ⚠ BREAKING CHANGES

- feature/IMOD-35904-Incident-Type

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!530

- Merge branch 'feature/IMOD-35904-Incident-Type' into 'develop' ([c14be0c](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/c14be0c1312730d5422c43135ad264723ffdeefe))

### [1.14.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.14.5...v1.14.6) (2022-09-26)

### ⚠ BREAKING CHANGES

- imode-29187-id-verification-url-added

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!531

- Merge branch 'feature/IMOD-29187-id-verification' into 'develop' ([d1edd2d](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/d1edd2d1c3ec337e5e1e873b4d6b43b7385303cf))

### [1.14.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.14.4...v1.14.5) (2022-09-23)

### ⚠ BREAKING CHANGES

- feature/IMOD-35245-dropdown-fix

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!529

- Merge branch 'feature/IMOD-35245-dropdown-fix' into 'develop' ([9bfbde5](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/9bfbde58647ae5a3486b5d19c82716ab5270f7ac))

### [1.14.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.14.3...v1.14.4) (2022-09-23)

### ⚠ BREAKING CHANGES

- Feature/imod 35345 emailwrap

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!527

- Merge branch 'feature/IMOD-35345-emailwrap' into 'develop' ([9f3d47f](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/9f3d47face28c70521ae2d9010265a0c48f6f3b8))

### [1.14.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.14.2...v1.14.3) (2022-09-22)

### ⚠ BREAKING CHANGES

- feature/IMOD-35245-Edit-Screen

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!517

- Merge branch 'feature/IMOD-35245-Edit-Screen' into 'develop' ([4e2bdf1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/4e2bdf112f85d87d09d62457203597b3b481a729))

### [1.14.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.14.1...v1.14.2) (2022-09-22)

### ⚠ BREAKING CHANGES

- feature/IMOD-35531-Cosmetic-Fix

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!518

- Merge branch 'feature/IMOD-35531-Cosmetic-Fix' into 'develop' ([676ced9](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/676ced904a16adfd79c4aeac2d233c47b574eb04))

### [1.14.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.14.0...v1.14.1) (2022-09-21)

## [1.14.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.13.7...v1.14.0) (2022-09-21)

### ⚠ BREAKING CHANGES

- Feature/lastest ts migration

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!522

- Merge branch 'feature/lastest-ts-migration' into 'develop' ([a7a1fef](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/a7a1fefa0acfe9413e50c473dd866ae070487c3a))

### [1.13.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.13.6...v1.13.7) (2022-09-13)

### ⚠ BREAKING CHANGES

- Feature/IMOD-34536_Display TRF Number in Result Details page

Added TRF number in the Results details page

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!508

- Merge branch 'feature/IMOD-34536' into 'develop' ([5d4146f](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/5d4146f1e23b59757dfd3dc2afbcc3f734396452))

### [1.13.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.13.5...v1.13.6) (2022-09-13)

### ⚠ BREAKING CHANGES

- Feature/add error code comment mandatory

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!516

- Merge branch 'feature/Add-Error-Code-Comment-Mandatory' into 'develop' ([b6060f8](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/b6060f8c69a341ba74463671b2ca2ce2ebbc11d6))

### [1.13.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.13.4...v1.13.5) (2022-09-12)

### ⚠ BREAKING CHANGES

- feature/Type-Dropdown

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!514

- Merge branch 'feature/Type-Dropdown' into 'develop' ([cb2dd33](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/cb2dd334161466f047761094366a4986abeb477f))

### [1.13.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.13.3...v1.13.4) (2022-09-09)

### ⚠ BREAKING CHANGES

- Incident-management-defect-fix-sprint-8

Fixes IMOD-35254, IMOD-35082, IMOD-35132, IMOD-35232 and IMOD-35234

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!509

- Merge branch 'feature/Pheonix-Defect-Fix' into 'develop' ([359ed51](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/359ed51d9a97a5d931730a01ce0097fde195ca21))

### [1.13.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.13.2...v1.13.3) (2022-09-09)

### ⚠ BREAKING CHANGES

- IMOD-33697 ,IMOD-34388 On hold update bug fixes

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!512

- Merge branch 'feature/PI9-sparta-BugFixes' into 'develop' ([24b5f3c](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/24b5f3c235e8a98b911839495ff3126298b78b08))

### [1.13.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.13.1...v1.13.2) (2022-09-09)

### ⚠ BREAKING CHANGES

- Panda sprint 6 defect fixes

Fixes IMOD-26362, IMOD-34807, IMOD-31549, IMOD-26320 and IMOD-33439.

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!500

- Merge branch 'feature/Defect_Fix_Sprint6' into 'develop' ([2dfed8d](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/2dfed8dd5566df848532447558c3b6b7b59e8389))

### [1.13.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.13.0...v1.13.1) (2022-09-05)

### ⚠ BREAKING CHANGES

- feature/DisplayLabelPatch

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!504

- Merge branch 'feature/DisplayLabelPatch' into 'develop' ([4ab1cb1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/4ab1cb17ea8875916b3e855e83722538324e34ab))

## [1.13.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.32...v1.13.0) (2022-09-05)

### ⚠ BREAKING CHANGES

- Feature/IMOD-17495_error_screen_app_refactor

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!506

- Merge branch 'feature/IMOD-17495_Error_screen_app_refactor' into 'develop' ([4c9cade](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/4c9cadee371e0a9bed88cc8e5701f84595be7433))

### [1.12.32](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.31...v1.12.32) (2022-09-05)

### [1.12.31](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.30...v1.12.31) (2022-09-05)

### ⚠ BREAKING CHANGES

- Feature/imode 31994 Results Status Update for multiple booking

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!476

- Merge branch 'feature/IMODE-31994-multiple-booking-status-update' into 'develop' ([e4e2844](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/e4e284447d3987addbf31ed61d5f5aee707f9a1a))

### [1.12.30](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.29...v1.12.30) (2022-09-02)

### ⚠ BREAKING CHANGES

- feature/IMOD-34679 -display time in 24 hr format

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!501

- Merge branch 'feature/IMOD-34679' into 'develop' ([e51625f](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/e51625f23b5fc7947fda998ce133b0146c00b48e))

### [1.12.29](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.28...v1.12.29) (2022-09-01)

### ⚠ BREAKING CHANGES

- feature/Pi-9-Defect-Fix-Pheonix

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!503

- Merge branch 'feature/Pi-9-Defect-Fix-Pheonix' into 'develop' ([20aac1f](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/20aac1ffe9bb7fce7e54ae00b3ce2a6f97249171))

### [1.12.28](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.27...v1.12.28) (2022-08-31)

### ⚠ BREAKING CHANGES

- feature/IMOD-34625-discrepancy in wording on Update On Hold Flag fixed

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!494

- Merge branch 'feature/IMOD-34625' into 'develop' ([0f14202](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/0f14202b3bd2e7d31b6b42f39346f9428abdce67))

### [1.12.27](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.26...v1.12.27) (2022-08-25)

### ⚠ BREAKING CHANGES

- feature/api-change-resultstatus

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!483

- Merge branch 'feature/api-change-resultstatus' into 'develop' ([7f11155](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/7f11155998b0c01f594b25f4f855b65cc05ac850))

### [1.12.26](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.25...v1.12.26) (2022-08-21)

### ⚠ BREAKING CHANGES

- Feature/imod 33393 error pop up

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!496

- Merge branch 'feature/IMOD-33393-error-pop-up' into 'develop' ([733556e](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/733556ea3cf2258a2fc3167896a3008ba354fbe3))

### [1.12.25](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.24...v1.12.25) (2022-08-19)

### ⚠ BREAKING CHANGES

- RO Grid address CSS fix

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!495

- Merge branch 'feature/PI9_panda_defect_fix' into 'develop' ([d3e7ee8](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/d3e7ee88e108b82fc7b61333741679e6fde5cc5b))

### [1.12.24](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.23...v1.12.24) (2022-08-19)

### [1.12.23](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.22...v1.12.23) (2022-08-17)

### ⚠ BREAKING CHANGES

- feature/Incident-Management-Shadow

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!489

- Merge branch 'feature/Incident-Management-Shadow' into 'develop' ([e1630b5](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/e1630b5bce2d595f3de69cade40ac0b2bf9e81e3))

### [1.12.22](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.21...v1.12.22) (2022-08-17)

### ⚠ BREAKING CHANGES

- Feature/pi9 panda defect fix

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!488

- Merge branch 'feature/PI9_panda_defect_fix' into 'develop' ([9ef6e2b](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/9ef6e2b9c214f3aec1abfb9c8c04bec117a9e869))

### [1.12.21](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.20...v1.12.21) (2022-08-16)

### ⚠ BREAKING CHANGES

- Feature/enable edit button

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!486

- Merge branch 'feature/enable-edit-button' into 'develop' ([5c6d1cb](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/5c6d1cb804ca12fe903f65584fd5321f3df8303d))

### [1.12.20](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.19...v1.12.20) (2022-08-12)

### ⚠ BREAKING CHANGES

- feature/Incident-Management-Intermediate-Branch

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!463

- Merge branch 'feature/Incident-Management-Intermediate-Branch' into 'develop' ([0cb0164](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/0cb0164da1508d607f4112d5b1ba3bc0bc700843))

### [1.12.19](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.18...v1.12.19) (2022-08-10)

### ⚠ BREAKING CHANGES

- Accept_SSR

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!485

- Merge branch 'feature/Accept_SSR' into 'develop' ([7640f87](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/7640f8719e92c57156b1c0fb87598aa9a65476c0))

### [1.12.18](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.17...v1.12.18) (2022-08-08)

### ⚠ BREAKING CHANGES

- Defect fixes

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!481

- Merge branch 'feature/Defect_fixes' into 'develop' ([db7173f](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/db7173f32b282509b8a61a1cc0b8ea0fe6f90278))

### [1.12.17](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.16...v1.12.17) (2022-08-05)

### ⚠ BREAKING CHANGES

- Defect fixes

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!480

- Merge branch 'feature/Defect_fixes' into 'develop' ([1554040](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/1554040925604d358de959183a640d47e94acf51))

### [1.12.16](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.15...v1.12.16) (2022-08-04)

### ⚠ BREAKING CHANGES

- Defect fixes

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!452

- Merge branch 'feature/Defect_fixes' into 'develop' ([0da7ae1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/0da7ae15713e8996eb0663702890ffc4668c4c23))

### [1.12.15](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.14...v1.12.15) (2022-08-01)

### ⚠ BREAKING CHANGES

- feature/IMOD-33262-onhold updates by system user not to be displayed on status history screen

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!471

- Merge branch 'feature/IMOD-33262' into 'develop' ([3a2ae41](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/3a2ae4111c6d9a8558162229e25f9d182859b594))

### [1.12.14](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.13...v1.12.14) (2022-07-29)

### ⚠ BREAKING CHANGES

- Feature/imod 31164 on hold update multiple booking

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!456

- Merge branch 'feature/IMOD-31164-onHoldUpdate-multiple-booking' into 'develop' ([8e7e9ee](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/8e7e9ee1a808d81d680705a40649a60d35805a7f))

### [1.12.13](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.12...v1.12.13) (2022-07-27)

### [1.12.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.11...v1.12.12) (2022-07-20)

### ⚠ BREAKING CHANGES

- Feature/pi9 panda defect fix service request toast message

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!469

- Merge branch 'feature/PI9_panda_defect_fix' into 'develop' ([de99445](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/de99445dbc32739a89414dd979ab15a2983e6f52))

### [1.12.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.10...v1.12.11) (2022-07-15)

### ⚠ BREAKING CHANGES

- Feature/single on hold update

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!466

- Merge branch 'feature/singleOnHoldUpdate' into 'develop' ([a41a7e9](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/a41a7e9073eee2fc0db3264fdc45e613cebda075))

### [1.12.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.9...v1.12.10) (2022-07-15)

### ⚠ BREAKING CHANGES

- feature/IMOD-32105 Onhold status on result status history screen

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!451

- Merge branch 'feature/UpdateOnHoldStatus' into 'develop' ([b4b2aed](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/b4b2aed2101f77ce7d3ce16464774588fce1ad17))

### [1.12.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.8...v1.12.9) (2022-07-14)

### ⚠ BREAKING CHANGES

- Feature/IMOD-30728 on hold flag single booking update

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!461

- Merge branch 'feature/IMOD-30728-on-hold-flag-singlebooking-update' into 'develop' ([a070021](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/a070021134001fe248e8556e7874b01dbc629323))

### [1.12.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.7...v1.12.8) (2022-07-14)

### ⚠ BREAKING CHANGES

- Feature/31983 on hold search criteria

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!454

- Merge branch 'feature/IMOD-31983-on-hold-search-criteria' into 'develop' ([2e0fd2d](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/2e0fd2d256eff221ab3336656b4195bd9d062233))

### [1.12.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.6...v1.12.7) (2022-07-07)

### ⚠ BREAKING CHANGES

- feature/IMODE-32523-result-status-label

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!457

- Merge branch 'feature/IMODE-32523-result-status-label' into 'develop' ([6415eb3](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/6415eb3bdb41c61154ae807499b8626420e748a5))

### [1.12.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.5...v1.12.6) (2022-07-04)

### ⚠ BREAKING CHANGES

- Load VO fixed contact address issue in update

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!453

- Merge branch 'feature/Load_VO_contact_details_issue_fix' into 'develop' ([5eebdd6](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/5eebdd663b871d0a1e3c652c3d488b63c79004d0))

### [1.12.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.4...v1.12.5) (2022-06-30)

### ⚠ BREAKING CHANGES

- Feature/pi9 panda defect fix

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!449

- Merge branch 'feature/PI9_panda_defect_fix' into 'develop' ([28e7391](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/28e73918a50adfa46e178e092cb53d57dd0f9d9c))

### [1.12.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.3...v1.12.4) (2022-06-29)

### ⚠ BREAKING CHANGES

- Feature/pi9 panda defect fix

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!448

- Merge branch 'feature/PI9_panda_defect_fix' into 'develop' ([66c8dd7](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/66c8dd7d6b6b7e263576d9a1cd6e5cc2f4750390))

### [1.12.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.2...v1.12.3) (2022-06-23)

### [1.12.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.1...v1.12.2) (2022-06-22)

### ⚠ BREAKING CHANGES

- CSS defects fix

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!443

- Merge branch 'feature/css_defects' into 'develop' ([77e073b](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/77e073b4a89f7ba3e2591a1a9a4917f3b0c6fc8d))

### [1.12.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.12.0...v1.12.1) (2022-06-22)

### ⚠ BREAKING CHANGES

- implemented logic to display ban details under ban details tab in booking...

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!441

- Merge branch 'feature/Incredibles_BanChanges_IMOD12988' into 'develop' ([b29118d](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/b29118d91f12c482249cb882625c4699a8027362))

## [1.12.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.11.12...v1.12.0) (2022-06-21)

### ⚠ BREAKING CHANGES

- Feature/IMOD_29280-change_parent

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!444

- Merge branch 'feature/IMOD-29280_change_parent' into 'develop' ([034775e](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/034775e30970e96914aa1da097cca4f1451b3573))

### [1.11.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.11.11...v1.11.12) (2022-06-16)

### ⚠ BREAKING CHANGES

- IMOD-31239 Added sort function for Additionaldeliverorg list

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!440

- Merge branch 'feature/IMOD-31239_Order_of_additional_delivery_organisation' into 'develop' ([8807ae2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/8807ae218f201c4b09e2ed1efe346d0ddd2d9394))

### [1.11.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.11.10...v1.11.11) (2022-06-16)

### ⚠ BREAKING CHANGES

- IMOD-28292_Mainaddress_search_issue_fix

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!442

- Merge branch 'feature/IMOD-28292_mainaddress_search_issue_fix' into 'develop' ([e8a94de](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/e8a94ded1143d10e48015849da19f30c9beb897f))

### [1.11.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.11.9...v1.11.10) (2022-06-14)

### ⚠ BREAKING CHANGES

- IMOD-26447 Toast message component

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!431

- Merge branch 'feature/IMOD-26447_Toast_message_component' into 'develop' ([faa4056](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/faa40561a88d48ee79674be4872e6ac986c514ee))

### [1.11.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.11.8...v1.11.9) (2022-06-13)

### ⚠ BREAKING CHANGES

- feature/IMOD-3031-Adding ID verification option in result grid

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!430

- Merge branch 'feature/IMOD-30731-Add-Option' into 'develop' ([0c30f25](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/0c30f2543ea3315164201cca8e56ee5f9ebdfd95))

### Features

- enable private runners in ui-operations ([a11f7b8](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/a11f7b8403c12535f9ca9790ae8b727393b1abc7))

### [1.11.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.11.7...v1.11.8) (2022-06-02)

### ⚠ BREAKING CHANGES

- IMOD-21179 Defect fix Identify parent org

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!415

- IMOD-30524-end-date-issue-search

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!428

- Merge branch 'feature/IMOD-21179_indetify_parent_org' into 'develop' ([f91ee28](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/f91ee2855c493fe0bb04429a22117b3a532f2ff3))
- Merge branch 'feature/IMOD-30524-end-date-issue-search' into 'develop' ([694587c](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/694587c943672d697a8a9bc3013c16352861b253))

### [1.11.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.11.6...v1.11.7) (2022-05-27)

### ⚠ BREAKING CHANGES

- Feature/imod 30387 status history fix

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!418

- Merge branch 'feature/IMOD-30387-status-history' into 'develop' ([720604c](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/720604c629dbcb580c1e76960310869966fac5b4))

### [1.11.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.11.5...v1.11.6) (2022-05-26)

### ⚠ BREAKING CHANGES

- IMOD-30408-score history tab bug fixes

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!422

- Merge branch 'feature/IMOD-30408-score-history-last-round-not-showing' into 'develop' ([fef0ee8](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/fef0ee8b5a6f3c706f76431810b9f6e710b49b15))

### [1.11.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.11.4...v1.11.5) (2022-05-25)

### ⚠ BREAKING CHANGES

- Feature/IMOD-29230_remove_parent

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!421

- Merge branch 'feature/IMOD-29230_remove_parent' into 'develop' ([ef8dca1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/ef8dca18d8b1f6c882f8e2e8fea723e997729371))

### [1.11.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.11.3...v1.11.4) (2022-05-23)

### [1.11.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.11.2...v1.11.3) (2022-05-19)

### [1.11.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.11.1...v1.11.2) (2022-05-19)

### ⚠ BREAKING CHANGES

- Feature/rm integrate booking details and status history

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!399

- Merge branch 'feature/RM_integrate_booking_details_and_status_history' into 'develop' ([e6e5075](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/e6e507592b02650d8db9034ce0d89a809c92a49e))

### [1.11.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.11.0...v1.11.1) (2022-05-18)

### ⚠ BREAKING CHANGES

- IMOD-29453 Resolved Error in RO update screen fix

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!416

- Merge branch 'feature/IMOD-29453_Error_in_RO_update' into 'develop' ([aa78dbc](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/aa78dbcfc2078c2c0a0b09bcf5794a281cb3f72d))

## [1.11.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.10.20...v1.11.0) (2022-05-16)

### [1.10.20](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.10.19...v1.10.20) (2022-05-16)

### ⚠ BREAKING CHANGES

- IMOD-28922 VO RO default flags

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!414

- Merge branch 'feature/IMOD-28922_VO_RO_default_flags' into 'develop' ([35f3d49](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/35f3d49f629c331e95886fe31aa0f83a91e9d0f4))

### [1.10.19](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.10.18...v1.10.19) (2022-05-16)

### ⚠ BREAKING CHANGES

- Feature/IMOD-28622_Autologout after 15unsuccessful attempt

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!413

- Merge branch 'feature/IMOD-28622_autologout_after_15unsuccessful_attempt' into 'develop' ([40e75bd](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/40e75bd45510c529c0f90be2399ae79b88da7b0e))

### [1.10.18](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.10.17...v1.10.18) (2022-05-16)

### ⚠ BREAKING CHANGES

- IMOD-27529 bookable products dropdown

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!397

- Merge branch 'feature/IMOD-27529-bookable-products-dropdown' into 'develop' ([4bec4fd](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/4bec4fd5729c24eed96fb1a5f899ae5019eb0aa3))

### [1.10.17](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.10.16...v1.10.17) (2022-05-11)

### ⚠ BREAKING CHANGES

- IMOD-28673_Validation_In_RO

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!407

- Merge branch 'feature/IMOD-28673_Validation_In_RO' into 'develop' ([6d66c27](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/6d66c27d1423aa5429bb081c6463648e9cffed2c))

### [1.10.16](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.10.15...v1.10.16) (2022-05-11)

### ⚠ BREAKING CHANGES

- IMOD-28673_Validation_In_RO

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!405

- Merge branch 'feature/IMOD-28673_Validation_In_RO' into 'develop' ([35f1ec6](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/35f1ec64a1cee89630127220d98db1f947b66a23))

### [1.10.15](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.10.14...v1.10.15) (2022-05-11)

### ⚠ BREAKING CHANGES

- Feature/imod 28496 Data input validation

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!389

- Merge branch 'feature/IMOD-28496-validation' into 'develop' ([8f7c83e](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/8f7c83ede20141be7cbb4c3c4e022a067390ac88))

### [1.10.14](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.10.13...v1.10.14) (2022-05-10)

### ⚠ BREAKING CHANGES

- add search to test centre dropdown

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!404

- Merge branch 'feature/IMOD-22368_RM_UI_Test_Centre_Locations_for_search_UI' into 'develop' ([cb86d5a](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/cb86d5a35bf9f03843580785f2aeb9493baaea93))

### [1.10.13](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.10.12...v1.10.13) (2022-05-09)

### ⚠ BREAKING CHANGES

- Feature/IMOD-21179_Indentify_parent

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!403

- Merge branch 'feature/IMOD-21179_indetify_parent_org' into 'develop' ([b78942e](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/b78942e355efb0c28e26549aaaa0a15e4e065e76))

### [1.10.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.10.11...v1.10.12) (2022-05-05)

### ⚠ BREAKING CHANGES

- Validation in RO

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!402

- Merge branch 'feature/IMOD-28673_Validation_In_RO' into 'develop' ([5dff189](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/5dff189e8e3cdbd029209a624b314e38254940a0))

### [1.10.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.10.10...v1.10.11) (2022-05-04)

### ⚠ BREAKING CHANGES

- Input validation in organisation module

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!401

- Merge branch 'feature/IMOD-28673_Input_validation_in_organisation_module' into 'develop' ([9332d7e](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/9332d7e56b3b99a7bad7d29063e96d51d2790858))

### [1.10.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.10.9...v1.10.10) (2022-05-04)

### ⚠ BREAKING CHANGES

- Input validation on all SM fields

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!400

- Merge branch 'feature/Input_validation_on_all_fields' into 'develop' ([9c07328](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/9c07328501a3bda793f02126e03c14dde7dfe278))

### [1.10.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.10.8...v1.10.9) (2022-05-02)

### [1.10.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.10.7...v1.10.8) (2022-05-02)

### ⚠ BREAKING CHANGES

- Input validation in organisation module

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!396

### Bug Fixes

- ssm parameters value existence will be evaluated before deployment ([d944b34](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/d944b34640def93b9f5a3220b043f9d6730ce5f7))

- Merge branch 'feature/IMOD-28673_Input_validation_in_organisation_module' into 'develop' ([0351ae5](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/0351ae5f4a62ee7ffe90820dc7bd23380758343d))

### [1.10.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.10.6...v1.10.7) (2022-04-27)

### ⚠ BREAKING CHANGES

- IMOD-28016_recognized_product_defect_fix

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!394

- Merge branch 'feature/panda_defect_fix_PI8' into 'develop' ([008b17c](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/008b17c6fea1a9a2b75f2a4d689b045e7795d5bb))

### [1.10.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.10.5...v1.10.6) (2022-04-26)

### ⚠ BREAKING CHANGES

- Adding_parameter_for_additional_delivery_organisation

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!390

- Merge branch 'feature/Adding_Parameter_for_AdditionalDeliveryOrganisation' into 'develop' ([bc1a760](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/bc1a7609964d16b7d202af03d2a6aa36617070e9))

### [1.10.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.10.4...v1.10.5) (2022-04-26)

### ⚠ BREAKING CHANGES

- Input validation on all SM fields

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!392

- Merge branch 'feature/Input_validation_on_all_fields' into 'develop' ([f6c80c2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/f6c80c2a0b9af066aa5646460897faa6e15582ff))

### [1.10.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.10.3...v1.10.4) (2022-04-22)

### ⚠ BREAKING CHANGES

- IMOD-26980_number_of_years_dropdown

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!391

- Merge branch 'feature/IMOD-26980_number_of-\_years_dropdown' into 'develop' ([ba72708](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/ba727083595b6edc8bf8752f7813324287d1574f))

### [1.10.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.10.2...v1.10.3) (2022-04-22)

### ⚠ BREAKING CHANGES

- IMOD-27363_defect_fix

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!373

- Merge branch 'feature/panda_defect_fix_PI8' into 'develop' ([3c806c8](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/3c806c8a4f5919f83d64df73b3de0a2ca594e434))

### [1.10.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.10.1...v1.10.2) (2022-04-19)

### [1.10.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.10.0...v1.10.1) (2022-04-14)

### ⚠ BREAKING CHANGES

- Feature/imod 28574 rm writing marks showing pending status while completed in inspera

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!386

- Merge branch 'feature/IMOD-28574_RM_Writing_marks_showing_pending_status_while_completed_in_Inspera' into 'develop' ([018933d](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/018933d93daab9be74299852abad666fb512cb38))

## [1.10.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.9.5...v1.10.0) (2022-04-12)

### ⚠ BREAKING CHANGES

- Feature/imod 28164_Fixed_multiple_api_calls_performance_issue

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!383

- Merge branch 'feature/IMOD-28164' into 'develop' ([68591cb](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/68591cbe75128eb640d1f3d11a99b47d21ea14ad))

### [1.9.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.9.4...v1.9.5) (2022-04-12)

### ⚠ BREAKING CHANGES

- pipeline failure fix

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!385

- Merge branch 'feature/PI8_pipleine_failure' into 'develop' ([7f05f37](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/7f05f37eef781b1e7377c2086b2e9252da2628f2))

### [1.9.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.9.3...v1.9.4) (2022-04-08)

### ⚠ BREAKING CHANGES

- feature/Usergroup Partnercode parameter added

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!382

- Merge branch 'feature/IMOD-12228_Usergroup_partnercode_parametere' into 'develop' ([aad2be3](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/aad2be31a46edb68e6c24e69fbf5d55bd2bf5442))

### [1.9.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.9.2...v1.9.3) (2022-04-05)

### ⚠ BREAKING CHANGES

- Feature/imod 24660 modify trf link

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!378

- Merge branch 'feature/IMOD-24660_modify_TRF_link' into 'develop' ([8377d8e](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/8377d8e8d6b39dced64a449e00d740ee6662395f))

### [1.9.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.9.1...v1.9.2) (2022-04-05)

### ⚠ BREAKING CHANGES

- Feature/matrix pi7 develop

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!379

- Merge branch 'feature/Matrix-PI7-develop' into 'develop' ([a6058c3](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/a6058c3920cf0dad0fbf7c965b3db179f1a4957a))

### [1.9.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.9.0...v1.9.1) (2022-04-04)

### ⚠ BREAKING CHANGES

- Feature/imod 27921 added websocketresponse timeout

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!377

- Merge branch 'feature/IMOD-27921_Added_Websocketresponse_Timeout' into 'develop' ([85a42fc](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/85a42fc60c5fb63fe9dc36c322a7dd2fa104aa73))

## [1.9.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.8.0...v1.9.0) (2022-04-01)

## [1.8.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.7.0...v1.8.0) (2022-03-31)

## [1.7.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.6.2...v1.7.0) (2022-03-31)

### [1.6.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.6.1...v1.6.2) (2022-03-29)

### ⚠ BREAKING CHANGES

- Feature/panda defect fix pi8

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!365

- Merge branch 'feature/panda_defect_fix_PI8' into 'develop' ([578245e](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/578245e32babf7c8777bdd420711ff11bd14f2e5))

### [1.6.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.6.0...v1.6.1) (2022-03-29)

### ⚠ BREAKING CHANGES

- Feature/imod 26747 present tt photos in cmds ui

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!360

- Feature/imod 27786 rm go back link no present in some pages

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!367

### Bug Fixes

- **UI:** Feature/imod 27841 org incorrect add org link on left navigation ([f993af5](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/f993af5734a6711b56d6667edecb02ed00a84206))

- Merge branch 'feature/IMOD-26747_present_TT_photos_in_CMDS_UI' into 'develop' ([29afdeb](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/29afdebd03d06a72f9df020424d36de4fae16a7e))
- Merge branch 'feature/IMOD-27786_RM_go_back_link_no_present_in_some_pages' into 'develop' ([b7013b3](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/b7013b3e82265aafbc04db31431e884039dfb0c7))

## [1.6.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.31...v1.6.0) (2022-03-25)

### [1.5.31](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.30...v1.5.31) (2022-03-23)

### ⚠ BREAKING CHANGES

- Removed IOL GT bookable product

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!364

- Merge branch 'feature/IMOD-26143_fix' into 'develop' ([f6be1e9](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/f6be1e9ee1068188a6b6a14a6640b6954bc56b77))

### [1.5.30](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.29...v1.5.30) (2022-03-22)

### ⚠ BREAKING CHANGES

- fixed the defect 26143

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!363

- Merge branch 'feature/IMOD-26143_fix' into 'develop' ([449d42e](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/449d42e32dc48460fa8ec03469a642cc6731f87d))

### [1.5.29](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.28...v1.5.29) (2022-03-21)

### ⚠ BREAKING CHANGES

- Incorrect order of tasks and label name for writing component

See merge request ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations!357

- Merge branch 'feature/IMOD-21452_RM_Screen_Incorrect_order_of_tasks_and_label_name_for_writing_component' into 'develop' ([56238ee](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/56238ee31c9f3f65e1d97ae9f9f1ed563572ca29))

### Features

- Feature/test upload release ([12dbcb5](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/12dbcb5787d26af8883a81bf6a974d76965fdcce))
- Feature/test upload release ([21cdfd1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/21cdfd1f0346da1a5beec9139c974f349a170bd0))

### [1.5.28](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.27...v1.5.28) (2022-03-01)

### [1.5.27](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.26...v1.5.27) (2022-02-23)

### [1.5.26](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.25...v1.5.26) (2022-02-23)

### [1.5.25](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.24...v1.5.25) (2022-02-23)

### [1.5.24](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.23...v1.5.24) (2022-02-22)

### [1.5.23](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.22...v1.5.23) (2022-02-22)

### [1.5.22](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.21...v1.5.22) (2022-02-21)

### [1.5.21](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.20...v1.5.21) (2022-02-18)

### [1.5.20](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.19...v1.5.20) (2022-02-16)

### [1.5.19](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.18...v1.5.19) (2022-02-16)

### [1.5.18](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.17...v1.5.18) (2022-02-15)

### [1.5.17](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.16...v1.5.17) (2022-02-15)

### [1.5.16](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.15...v1.5.16) (2022-02-10)

### [1.5.15](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.14...v1.5.15) (2022-02-07)

### [1.5.14](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.13...v1.5.14) (2022-02-04)

### [1.5.13](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.12...v1.5.13) (2022-02-01)

### [1.5.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.11...v1.5.12) (2022-01-28)

### [1.5.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.10...v1.5.11) (2022-01-25)

### [1.5.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.9...v1.5.10) (2022-01-21)

### [1.5.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.8...v1.5.9) (2022-01-21)

### [1.5.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.7...v1.5.8) (2022-01-19)

### [1.5.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.6...v1.5.7) (2022-01-19)

### [1.5.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.5...v1.5.6) (2022-01-19)

### [1.5.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.4...v1.5.5) (2022-01-18)

### [1.5.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.3...v1.5.4) (2022-01-17)

### [1.5.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.2...v1.5.3) (2022-01-12)

### [1.5.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.1...v1.5.2) (2022-01-12)

### [1.5.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.5.0...v1.5.1) (2022-01-12)

## [1.5.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.4.21...v1.5.0) (2022-01-07)

### [1.4.21](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.4.20...v1.4.21) (2022-01-04)

### [1.4.20](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.4.19...v1.4.20) (2021-12-27)

### [1.4.19](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.4.18...v1.4.19) (2021-12-24)

### [1.4.18](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.4.17...v1.4.18) (2021-12-23)

### [1.4.17](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.4.16...v1.4.17) (2021-12-15)

### [1.4.16](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.4.15...v1.4.16) (2021-12-07)

### [1.4.15](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.4.14...v1.4.15) (2021-11-29)

### Bug Fixes

- view details screen scores with value 0 is displaying incorrectly ([9cdb56a](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/9cdb56a7c99b85c36b438531a37a7cb24f337e70))

### [1.4.14](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.4.13...v1.4.14) (2021-11-26)

### [1.4.13](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.4.12...v1.4.13) (2021-11-25)

### [1.4.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.4.11...v1.4.12) (2021-11-24)

### [1.4.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.4.10...v1.4.11) (2021-11-23)

### Bug Fixes

- resultStatusComment textarea not displaying anything ([f742d10](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/f742d10f665556abf383a952b6b768dc01cf933e))

### [1.4.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.4.9...v1.4.10) (2021-11-23)

### [1.4.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.4.8...v1.4.9) (2021-11-19)

### [1.4.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.4.7...v1.4.8) (2021-11-18)

### [1.4.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.4.6...v1.4.7) (2021-11-18)

### [1.4.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.4.5...v1.4.6) (2021-11-17)

### [1.4.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.4.4...v1.4.5) (2021-11-15)

### Bug Fixes

- test taker field error after executing an advanced search and going back to search page ([efb34da](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/efb34dac45821d2743ca437f152701bedd034752))

### [1.4.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.4.3...v1.4.4) (2021-11-12)

### [1.4.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.4.2...v1.4.3) (2021-11-09)

### [1.4.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.4.1...v1.4.2) (2021-11-08)

### [1.4.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.4.0...v1.4.1) (2021-11-05)

### Bug Fixes

- non-specific error message in response to API calls ([3d85e2a](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/3d85e2aa9260720a5dddf6ad76116584e25c149a))

## [1.4.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.3.13...v1.4.0) (2021-11-04)

### Bug Fixes

- view test taker details not displaying component scores ([cc947b7](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/cc947b727825897a2a09e992fdf9c7ea96dd9d16))

### [1.3.13](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.3.12...v1.3.13) (2021-11-03)

### Bug Fixes

- resultConcurrencyVersion sends null by default ([f6c75cd](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/f6c75cd811b48bc86b38ecccf8da1097ec520c48))

### [1.3.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.3.11...v1.3.12) (2021-11-02)

### Bug Fixes

- use consistent UTC times for date range criteria ([a1b8547](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/a1b8547c4e3b31054e85383c061a2f21d72a6bfe))

### [1.3.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.3.10...v1.3.11) (2021-10-29)

### [1.3.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.3.9...v1.3.10) (2021-10-27)

### [1.3.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.3.8...v1.3.9) (2021-10-26)

### [1.3.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.3.7...v1.3.8) (2021-10-26)

### [1.3.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.3.6...v1.3.7) (2021-10-26)

### [1.3.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.3.5...v1.3.6) (2021-10-25)

### [1.3.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.3.4...v1.3.5) (2021-10-22)

### Bug Fixes

- null component scores are not correctly managed ([b45684d](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/b45684d06934c758a1c73227bf86691163b423be))

### [1.3.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.3.3...v1.3.4) (2021-10-22)

### Bug Fixes

- wrong initiate eor icon in menu ([ff5b4c1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/ff5b4c11ac8b000f8ef20b0f8fee266fff2a27e2))

### [1.3.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.3.2...v1.3.3) (2021-10-22)

### [1.3.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.3.1...v1.3.2) (2021-10-21)

### [1.3.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.3.0...v1.3.1) (2021-10-20)

## [1.3.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.2.0...v1.3.0) (2021-10-20)

### [1.2.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.2.0...v1.2.1-hotfix.1) (2021-10-19)

### [1.1.27-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.27-hotfix.1...v1.1.27-hotfix.2) (2021-10-11)

### [1.1.27-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.26...v1.1.27-hotfix.1) (2021-10-11)

## [1.2.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.28...v1.2.0) (2021-10-18)

### Features

- Individual TT header for result pages ([59d2f9f](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/59d2f9faaf999f44fc488b6279276c53d3ff7df9))

### [1.1.28](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.27...v1.1.28) (2021-10-18)

### Bug Fixes

- search results showing mock data ([2ed3860](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/2ed38601759afb5a20923779c23626ead0bc51f1))

### [1.1.27](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.26...v1.1.27) (2021-10-15)

### Bug Fixes

- RM blank response fields make the UI crash ([e228653](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/commit/e228653a76e454ad7987286a665a6d889dc3b621))

### [1.1.26](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.25...v1.1.26) (2021-10-08)

### [1.1.25](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.24...v1.1.25) (2021-10-08)

### [1.1.24](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.23...v1.1.24) (2021-09-28)

### [1.1.23](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.22...v1.1.23) (2021-09-24)

### [1.1.22](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.21...v1.1.22) (2021-09-24)

### [1.1.21](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.20...v1.1.21) (2021-09-16)

### [1.1.20](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.19...v1.1.20) (2021-09-14)

### [1.1.19](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.18...v1.1.19) (2021-09-14)

### [1.1.18](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.17...v1.1.18) (2021-09-09)

### [1.1.17](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.16...v1.1.17) (2021-09-08)

### [1.1.16](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.15...v1.1.16) (2021-09-08)

### [1.1.15](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.14...v1.1.15) (2021-08-31)

### [1.1.14](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.13...v1.1.14) (2021-08-23)

### [1.1.13](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.12...v1.1.13) (2021-08-23)

### [1.1.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.11...v1.1.12) (2021-08-16)

### [1.1.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.10...v1.1.11) (2021-08-13)

### [1.1.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.9...v1.1.10) (2021-08-11)

### [1.1.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.8...v1.1.9) (2021-08-09)

### [1.1.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.7...v1.1.8) (2021-08-05)

### [1.1.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.6...v1.1.7) (2021-08-02)

### [1.1.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.5...v1.1.6) (2021-08-02)

### [1.1.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.4...v1.1.5) (2021-08-02)

### [1.1.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.3...v1.1.4) (2021-07-29)

### [1.1.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.2...v1.1.3) (2021-07-29)

### [1.1.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.1...v1.1.2) (2021-07-23)

### [1.1.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.1.0...v1.1.1) (2021-07-19)

## [1.1.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.0.5...v1.1.0) (2021-07-19)

### [1.0.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.0.4...v1.0.5) (2021-07-16)

### [1.0.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.0.3...v1.0.4) (2021-07-16)

### [1.0.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.0.2...v1.0.3) (2021-07-15)

### [1.0.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.0.1...v1.0.2) (2021-07-14)

### [1.0.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-ui-grp/cmds-ui-operations/compare/v1.0.0...v1.0.1) (2021-07-14)

## 1.0.0 (2021-07-07)

## 1.0.0 (2021-07-05)

## 1.0.0 (2021-07-05)
