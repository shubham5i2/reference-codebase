package com.ielts.cmds.integration.mapper;

import java.util.Objects;

import javax.validation.Valid;

import com.ielts.cmds.api.evt020.ResultStatus;
import com.ielts.cmds.api.evt020.ResultStatusContext;
import com.ielts.cmds.ors.common.integration.int263.EorCompletedV2;
import com.ielts.cmds.ors.common.integration.int263.EorCompletedV2.EorProcessResultEnum;


/** This class is used to map incoming event to appropriate API request body */
public class EventMapper {

    /**
     * Maps input event to booking response specific to request api body
     *
     * @param resultStatusEventV1
     * @return
     */
    public com.ielts.cmds.ors.common.integration.int263.ResultStatus mapResultStatusResponse(@Valid final ResultStatus resultStatusEventV1) {
        final com.ielts.cmds.ors.common.integration.int263.ResultStatus orsResultStatusResponseV1 = new com.ielts.cmds.ors.common.integration.int263.ResultStatus();
        orsResultStatusResponseV1.setExternalBookingUuid(resultStatusEventV1.getBooking().getExternalBookingUuid());
        orsResultStatusResponseV1.setResultUuid(resultStatusEventV1.getResultUuid());
        orsResultStatusResponseV1.setResultStatusTypeUuid(resultStatusEventV1.getResultStatus().getResultStatusTypeUuid());
        orsResultStatusResponseV1.setResultStatusChangedDateTime(resultStatusEventV1.getStatusDateTime());
        orsResultStatusResponseV1.setOnHold(resultStatusEventV1.getOnHold());
        if(Objects.nonNull(resultStatusEventV1.getContext()) && 
        		Objects.nonNull(resultStatusEventV1.getContext().getEorResult())) {
        	orsResultStatusResponseV1.setContext(populateResultStatusContext(resultStatusEventV1.getContext()));
        }
        return orsResultStatusResponseV1;
    }


    com.ielts.cmds.ors.common.integration.int263.ResultStatusContext populateResultStatusContext(ResultStatusContext context){
    	com.ielts.cmds.ors.common.integration.int263.ResultStatusContext resultStatusContext = 
    			new com.ielts.cmds.ors.common.integration.int263.ResultStatusContext();
		EorCompletedV2 eorResult =new EorCompletedV2();
		eorResult.setEorUuid(context.getEorResult().getEorUuid());
		eorResult.setExternalEorId(context.getEorResult().getExternalEorId());
		eorResult.setExternalBookingUuid(context.getEorResult().getExternalBookingUuid());
		eorResult.setExternalEorUuid(context.getEorResult().getExternalEorUuid());
		eorResult.setEorProcessResult(getEnum(context.getEorResult().getEorProcessResult()));;
		resultStatusContext.setEorResult(eorResult);
        return resultStatusContext;
    }


	EorProcessResultEnum getEnum(com.ielts.cmds.api.evt020.EorCompleted.EorProcessResultEnum eorProcessResult) {
		if(eorProcessResult != null) {
			return EorProcessResultEnum.fromValue(eorProcessResult.getValue());
		} else {
			return null;
		}
	}

}
