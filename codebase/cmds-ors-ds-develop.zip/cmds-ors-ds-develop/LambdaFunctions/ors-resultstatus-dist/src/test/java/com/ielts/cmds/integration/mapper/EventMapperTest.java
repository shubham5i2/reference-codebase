package com.ielts.cmds.integration.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import javax.validation.Valid;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.api.evt020.ResultStatus;
import com.ielts.cmds.integration.SQSEventBodySetup;
import com.ielts.cmds.ors.common.integration.int263.ResultStatusContext;


@ExtendWith(MockitoExtension.class)
class EventMapperTest {

	@InjectMocks EventMapper eventMapper;

	@Test
	void whenResultStatsuProvided_ThenValidatedResponse() {
		ResultStatus expected = SQSEventBodySetup.getResultStatusChangedEventV1();
		com.ielts.cmds.ors.common.integration.int263.ResultStatus actual = eventMapper.mapResultStatusResponse(expected);
		assertEquals(expected.getBooking().getExternalBookingUuid(), actual.getExternalBookingUuid());
		assertEquals(expected.getOnHold(), actual.getOnHold());
		assertEquals(expected.getStatusDateTime(), actual.getResultStatusChangedDateTime());
		assertEquals(expected.getResultStatus().getResultStatusTypeUuid(), actual.getResultStatusTypeUuid());
		assertEquals(expected.getResultUuid(), actual.getResultUuid());
		
	}


	@Test
	void whenResultStatsuProvidedWithNullContext_ThenValidatedResponse() {
		ResultStatus expected = SQSEventBodySetup.getResultStatusChangedEventV1();
		expected.setContext(null);
		com.ielts.cmds.ors.common.integration.int263.ResultStatus actual = eventMapper.mapResultStatusResponse(expected);
		assertNull(actual.getContext());

	}
	
	@Test
	void whenResultStatsuProvidedWithEmptyContext_ThenValidatedResponse() {
		ResultStatus expected = SQSEventBodySetup.getResultStatusChangedEventV1();
		expected.getContext().setEorResult(null);
		com.ielts.cmds.ors.common.integration.int263.ResultStatus actual = eventMapper.mapResultStatusResponse(expected);
		assertNull(actual.getContext());

	}
	
	@Test
	void whenContext_ThenValidatedResponse() {
		com.ielts.cmds.api.evt020.@Valid ResultStatusContext expected = SQSEventBodySetup.getResultStatusChangedEventV1().getContext();
		ResultStatusContext actual = eventMapper.populateResultStatusContext(expected);
		assertEquals(expected.getEorResult().getEorUuid(), actual.getEorResult().getEorUuid());
		assertEquals(expected.getEorResult().getExternalEorUuid(), actual.getEorResult().getExternalEorUuid());
		assertEquals(expected.getEorResult().getExternalBookingUuid(), actual.getEorResult().getExternalBookingUuid());
		assertEquals(expected.getEorResult().getExternalEorId(), actual.getEorResult().getExternalEorId());
		assertEquals(expected.getEorResult().getEorProcessResult().toString(), actual.getEorResult().getEorProcessResult().toString());

	}

}
