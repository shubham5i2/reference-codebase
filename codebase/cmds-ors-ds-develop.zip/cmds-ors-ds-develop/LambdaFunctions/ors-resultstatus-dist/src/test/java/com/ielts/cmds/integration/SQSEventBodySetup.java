package com.ielts.cmds.integration;

import static com.ielts.cmds.api.evt020.ResultStatusResultStatus.ResultStatusTypeEnum.CONFIRMED;

import java.time.OffsetDateTime;
import java.util.UUID;

import org.springframework.http.HttpHeaders;

import com.ielts.cmds.api.evt020.EorCompleted;
import com.ielts.cmds.api.evt020.EorCompleted.EorProcessResultEnum;
import com.ielts.cmds.api.evt020.ResultStatus;
import com.ielts.cmds.api.evt020.ResultStatusBooking;
import com.ielts.cmds.api.evt020.ResultStatusContext;
import com.ielts.cmds.api.evt020.ResultStatusResultStatus;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

public class SQSEventBodySetup {
	
	public static void setHeaderContext() {
		HeaderContext context = new HeaderContext();
		context.setCorrelationId(UUID.randomUUID());
		context.setTransactionId(UUID.randomUUID());
		context.setPartnerCode("test");
		ThreadLocalHeaderContext.setContext(context);

	}
	
	public static HttpHeaders getHttpHeaders() {
		HttpHeaders httpHeaders = new HttpHeaders();
		return httpHeaders;

	}

  public static ResultStatus getResultStatusChangedEventV1() {
    ResultStatus resultStatusChangedEventV1 = new ResultStatus();
    ResultStatusBooking booking = new ResultStatusBooking();
    booking.setBookingUuid(UUID.fromString("f4d582a0-693c-4dfd-824f-962784f8bf7d"));
    resultStatusChangedEventV1.setBooking(booking);
    ResultStatusContext resultStatusContext = new ResultStatusContext();
    resultStatusChangedEventV1.setResultUuid(UUID.fromString("f4d582a0-693c-4dfd-824f-962784f8bf7d"));
    ResultStatusResultStatus resultStatusResultStatus = new ResultStatusResultStatus();
    resultStatusResultStatus.setResultStatusType(CONFIRMED);
    resultStatusResultStatus.setResultStatusTypeUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
    resultStatusChangedEventV1.setResultStatus(resultStatusResultStatus);
    resultStatusChangedEventV1.setStatusDateTime(OffsetDateTime.now());
    resultStatusChangedEventV1.setOnHold(false);
    resultStatusChangedEventV1.setUndergoingEor(true);
    EorCompleted eorCompleted = new EorCompleted();
    eorCompleted.setEorProcessResult(EorProcessResultEnum.POSITIVE);
    eorCompleted.setExternalEorId("TO_BE_DEFINED");
    eorCompleted.setExternalEorUuid(UUID.fromString("e8958327-9917-4af2-91ce-7c6cd0c19837"));
    eorCompleted.setExternalBookingUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775565"));
    eorCompleted.setEorUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775789"));
    resultStatusContext.setEorResult(eorCompleted);
    resultStatusChangedEventV1.setContext(resultStatusContext);
    return resultStatusChangedEventV1;
  }
}
