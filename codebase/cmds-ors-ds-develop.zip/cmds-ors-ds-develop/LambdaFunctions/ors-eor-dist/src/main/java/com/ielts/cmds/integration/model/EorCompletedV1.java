package com.ielts.cmds.integration.model;

import lombok.Data;

import java.util.UUID;
@Data
public class EorCompletedV1 {
    private UUID eorUuid;
    private UUID externalEorUuid;
    private String externalEorId;
    private UUID externalBookingUuid;
    private UUID resultUuid;
}
