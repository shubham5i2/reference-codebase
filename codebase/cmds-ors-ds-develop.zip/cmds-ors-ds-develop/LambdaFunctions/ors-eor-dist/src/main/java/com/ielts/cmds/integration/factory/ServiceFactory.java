package com.ielts.cmds.integration.factory;

import static com.ielts.cmds.integration.constants.DistORSConstants.EOR_CHANGE_FAILED;
import static com.ielts.cmds.integration.constants.DistORSConstants.EOR_COMPLETED;
import static com.ielts.cmds.integration.constants.DistORSConstants.EOR_REQUEST_CHANGED;

import java.util.HashMap;
import java.util.Map;

import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.mapper.EorCompletedEventMapping;
import com.ielts.cmds.integration.mapper.EorRequestChangedEventMapping;

public class ServiceFactory {

  final Map<String, IService> initServices = new HashMap<>();

  public ServiceFactory() {
    initServices.put(EOR_REQUEST_CHANGED, new EorRequestChangedEventMapping());
    initServices.put(EOR_COMPLETED, new EorCompletedEventMapping());
    initServices.put(EOR_CHANGE_FAILED, new EorRequestChangedEventMapping());
  }

  public IService getService(final BaseHeader header) {
    return initServices.get(header.getEventName());
  }
}
