package com.ielts.cmds.integration.model;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class ExtORSResponse extends CMDSResponseBody {
  private Object response;
  public ExtORSResponse(final Object response, final BaseEventErrors errors) {
    super(errors);
    this.response = response;
  }
}