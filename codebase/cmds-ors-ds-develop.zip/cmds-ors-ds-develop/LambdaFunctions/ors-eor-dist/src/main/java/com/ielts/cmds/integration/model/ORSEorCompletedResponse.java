package com.ielts.cmds.integration.model;

import lombok.Data;

import java.util.UUID;
@Data
public class ORSEorCompletedResponse {
    private UUID eorUuid;
    private UUID externalEorUuid;
    private String externalEorId;
    private UUID externalBookingUuid;
}
