package com.ielts.cmds.integration;


import com.ielts.cmds.integration.constants.DistORSConstants;

public class ORSEorDistBCCHN extends AbstractORSEorDist {

  @Override
  protected String getPartnerCodeConstants() {
    return DistORSConstants.BC_CHN;
  }

  @Override
  protected String getApplicationName() {
    return DistORSConstants.ORS_EOR_DIST_BCCHN;
  }
}