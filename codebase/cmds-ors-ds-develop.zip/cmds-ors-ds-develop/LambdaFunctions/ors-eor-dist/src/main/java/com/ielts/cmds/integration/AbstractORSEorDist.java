package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.constants.DistORSConstants.BC;
import static com.ielts.cmds.integration.constants.DistORSConstants.CALLBACK_URL;
import static com.ielts.cmds.integration.constants.DistORSConstants.CORRELATIONID;
import static com.ielts.cmds.integration.constants.DistORSConstants.EOR_CHANGE_FAILED;
import static com.ielts.cmds.integration.constants.DistORSConstants.EVENT_DATE_TIME;
import static com.ielts.cmds.integration.constants.DistORSConstants.PARTNER_CODE;
import static com.ielts.cmds.integration.constants.DistORSConstants.TRANSACTIONID;
import static com.ielts.cmds.integration.constants.DistORSConstants.USER_AGENT;
import static com.ielts.cmds.integration.constants.DistORSConstants.USER_AGENT_KEY;

import java.security.KeyStoreException;
import java.security.cert.CertificateException;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.ielts.cmds.common.logger.util.CMDSLambdaLoggerUtil;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.factory.IService;
import com.ielts.cmds.integration.factory.ServiceFactory;
import com.ielts.cmds.integration.mapper.EventMapper;
import com.ielts.cmds.integration.model.CMDSResponseBody;
import com.ielts.cmds.integration.model.ExtORSResponse;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.exception.InvalidClientException;
import com.ielts.cmds.security.exception.TokenNotReceivedException;

import lombok.extern.slf4j.Slf4j;

/**
 * This class serves the purpose of handling EOR response to External system(ORS - British
 * Council) It reads RI EOR events specific to british council and post it back on callbackURL
 */
@Slf4j
public abstract class AbstractORSEorDist extends EventMapper {

	private final List<String> rejectedEvents = Arrays.asList(EOR_CHANGE_FAILED);
	private AuthenticationClient authenticationClient;

	/**
	 * This method will be triggered on events published to ORS queue. It reads SQS records,validate
	 * it and post to external system(ORS)
	 *
	 * @param input
	 * @param context
	 */
	public void handleRequest(final SQSEvent input, final Context context) throws Exception {

		for (SQSEvent.SQSMessage message : input.getRecords()) {
			final String sqsMessage = message.getBody();
			try{
				log.info("Event received in ORS DS : ors-eor-dist with metadata as {}",
						objectMapper.readValue(sqsMessage, BaseEvent.class).getEventHeader());
				log.debug("event received is {}",objectMapper.readValue(sqsMessage, BaseEvent.class));
				validateAndSendEventRequest(sqsMessage, context);
			}
			catch(HttpClientErrorException | JsonProcessingException| CertificateException| KeyStoreException| TokenNotReceivedException | InvalidClientException e){
				log.warn("Client Exception on processing event :", e);
			}
		}
	}

	/**
	 * Validates and sends the received sqs message body for further processing
	 *
	 * @param sqsMessage
	 * @param context
	 * @throws JsonProcessingException
	 */
	private void validateAndSendEventRequest(final String sqsMessage, final Context context) throws Exception {
		final BaseEvent<BaseHeader> event = objectMapper.readValue(sqsMessage, new TypeReference<BaseEvent<BaseHeader>>() {});
		final BaseHeader eventHeader = event.getEventHeader();
		final String eventName = eventHeader.getEventName();
		final UUID transactionId = eventHeader.getTransactionId();
		final String partnerCode = eventHeader.getPartnerCode();
		initializeLogger(transactionId, context);

		if (Objects.nonNull(getPartnerCodeConstants()) && getPartnerCodeConstants().equalsIgnoreCase(partnerCode)) {
			mapAndSendExternalEvent(event, eventHeader);
		} else {
			log.debug("Not processing incoming message as partnerCode:{} does not match expected partner code:{}"
					+ " TransactionId:{} Event:{} CorrelationId:{}",
					partnerCode, getPartnerCodeConstants(), transactionId, eventName, eventHeader.getCorrelationId());
		}
	}

	/**
	 * It processes and sends event body to appropriate external api resource based on EventType
	 *
	 * @param event
	 * @param headers
	 * @throws JsonProcessingException
	 */
	private void mapAndSendExternalEvent(final BaseEvent<BaseHeader> event, final BaseHeader headers)
			throws Exception {
		String extCallbackUrl = System.getenv(CALLBACK_URL);

		ExtORSResponse response=null;
		ServiceFactory serviceFactory = new ServiceFactory();
		final IService service = serviceFactory.getService(event.getEventHeader());
		log.debug("serivce {}",service);
		if (Objects.nonNull(service)) {
			response = service.mapToResponse(event);
		}
		if(Objects.nonNull(service) || rejectedEvents.contains(headers.getEventName())){
			postRequestToExternalAPI(response, headers, extCallbackUrl);
		} else {
			log.warn("Due to invalid event name:{}. Remove subscription", event);
		}
	}

	/**
	 * This method posts event body related to ORS events to external systems.
	 *
	 * @param resBody
	 * @param eventHeader
	 * @param externalUrl
	 * @throws InvalidClientException 
	 * @throws KeyStoreException 
	 * @throws CertificateException 
	 * @throws JsonProcessingException
	 * @throws TokenNotReceivedException 
	 */
	public void postRequestToExternalAPI(
			final CMDSResponseBody resBody, final BaseHeader eventHeader, final String externalUrl) throws JsonProcessingException, CertificateException, KeyStoreException, InvalidClientException, TokenNotReceivedException {
		final UUID txtID = eventHeader.getTransactionId();
		getAuthenticationClient(eventHeader.getPartnerCode());
		final HttpHeaders eventHeaders = getHttpHeaders(eventHeader);
		final HttpEntity<CMDSResponseBody> eventEntity = new HttpEntity<>(resBody, eventHeaders);
		log.debug("ExternalUrl : {} ; eventEntity : {} ; eventHeader : {}", externalUrl, eventEntity, eventHeaders);
		final ResponseEntity<String> response = authenticationClient.getRestTemplate().postForEntity(externalUrl, eventEntity, String.class);

		log.info(
				"Request success with StatusCode: {} . TransactionId: {} ",
				response.getStatusCode(), txtID);

	}

	/**
	 * constructs http header based on provided event header
	 *
	 * @param eventHeader
	 * @return
	 * @throws InvalidClientException 
	 * @throws KeyStoreException 
	 * @throws CertificateException 
	 * @throws JsonProcessingException 
	 * @throws TokenNotReceivedException 
	 */
	HttpHeaders getHttpHeaders(final BaseHeader eventHeader) throws JsonProcessingException, CertificateException, KeyStoreException, InvalidClientException, TokenNotReceivedException {
		final HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		httpHeaders.set(TRANSACTIONID, eventHeader.getTransactionId().toString());
		httpHeaders.set(CORRELATIONID, eventHeader.getCorrelationId().toString());
		httpHeaders.set(PARTNER_CODE, eventHeader.getPartnerCode());
		if(eventHeader.getPartnerCode()!= null && eventHeader.getPartnerCode().equalsIgnoreCase(BC)   &&
				System.getenv(USER_AGENT) != null && !System.getenv(USER_AGENT).equals("")){
			log.info("Inside user- agent");
			httpHeaders.set(USER_AGENT_KEY, System.getenv(USER_AGENT));
		}
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		httpHeaders.set(
				EVENT_DATE_TIME,
				Objects.isNull(eventHeader.getEventDateTime())
				? ""
						: eventHeader.getEventDateTime().format(formatter));


		getAuthenticationClient(eventHeader.getPartnerCode());
		httpHeaders.set(authenticationClient.getAuthorizationHeaderName(), authenticationClient.getAccessToken());
		return httpHeaders;
	}

	private void getAuthenticationClient(String partnerCode) throws InvalidClientException, CertificateException, KeyStoreException, JsonProcessingException {
		if (authenticationClient == null) {
			authenticationClient = authenticationClientFactory.getAuthenticationClient(partnerCode);
		}
	}

	protected abstract String getPartnerCodeConstants();

	protected abstract String getApplicationName();

	/**
	 * Method to initialize Logger Context for ORS lambda
	 *
	 * @param transactionId
	 * @param context
	 */
	protected void initializeLogger(final UUID transactionId, final Context context) {
		final CMDSLambdaLoggerUtil loggerUtil = new CMDSLambdaLoggerUtil();
		loggerUtil.initializeThreadContextMap(
				transactionId.toString(), getApplicationName(), context.getAwsRequestId());
	}
}
