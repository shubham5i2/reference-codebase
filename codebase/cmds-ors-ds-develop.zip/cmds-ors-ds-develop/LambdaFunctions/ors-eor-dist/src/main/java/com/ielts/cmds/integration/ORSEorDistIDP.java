package com.ielts.cmds.integration;

import com.ielts.cmds.integration.constants.DistORSConstants;

public class ORSEorDistIDP extends AbstractORSEorDist {

  @Override
  protected String getPartnerCodeConstants() {
    return DistORSConstants.IDP;
  }

  @Override
  protected String getApplicationName() {
    return DistORSConstants.ORS_EOR_DIST_IDP;
  }
}