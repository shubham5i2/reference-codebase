package com.ielts.cmds.integration.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.factory.IService;
import com.ielts.cmds.integration.model.EorCompletedV1;
import com.ielts.cmds.integration.model.ExtORSResponse;
import com.ielts.cmds.integration.model.ORSEorCompletedResponse;

public class EorCompletedEventMapping extends EventMapper implements IService {

    @Override
    public ExtORSResponse mapToResponse(BaseEvent<BaseHeader> event) throws JsonProcessingException {
        ORSEorCompletedResponse responseBody = null;
        if(event.getEventBody()!=null){
            final  EorCompletedV1 eventBody = getEventBodyBasedOnEventName(event);
            responseBody = mapRequestEventBodyToResponseBody(eventBody);
        }
        final BaseEventErrors responseErrors = event.getEventErrors();

        return new ExtORSResponse(responseBody, responseErrors);
    }

    public ORSEorCompletedResponse mapRequestEventBodyToResponseBody(EorCompletedV1 eventBody){
        ORSEorCompletedResponse response = new ORSEorCompletedResponse();
        response.setEorUuid(eventBody.getEorUuid());
        response.setExternalEorId(eventBody.getExternalEorId());
        response.setExternalEorUuid(eventBody.getExternalEorUuid());
        response.setExternalBookingUuid(eventBody.getExternalBookingUuid());
        return response;
    }

    public EorCompletedV1 getEventBodyBasedOnEventName(final BaseEvent<BaseHeader> event)
            throws JsonProcessingException {
        return objectMapper.readValue(event.getEventBody(), EorCompletedV1.class);
    }
}
