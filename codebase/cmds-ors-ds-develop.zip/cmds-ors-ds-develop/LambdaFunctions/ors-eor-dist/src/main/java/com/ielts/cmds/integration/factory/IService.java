package com.ielts.cmds.integration.factory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.model.ExtORSResponse;


public interface IService {

	ExtORSResponse mapToResponse(BaseEvent<BaseHeader> cmdsEvent) throws JsonProcessingException;
}
