package com.ielts.cmds.integration.model;

import lombok.Data;

import java.util.UUID;

@Data
public class ORSEorChangedResponse {
    private UUID eorUuid;
    private UUID externalEorUuid;
    private String externalEorId;
}