package com.ielts.cmds.integration.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.factory.IService;
import com.ielts.cmds.integration.model.ExtORSResponse;
import com.ielts.cmds.integration.model.ORSEorChangedResponse;
import com.ielts.cmds.rm.common.out.model.EorRequestChangedV1;

public class EorRequestChangedEventMapping extends EventMapper implements IService {

    @Override
    public ExtORSResponse mapToResponse(BaseEvent<BaseHeader> event) throws JsonProcessingException {
        ORSEorChangedResponse responseBody = null;
        if(event.getEventBody()!=null){
            final EorRequestChangedV1 eventBody = getEventBodyBasedOnEventName(event);
            responseBody = mapRequestEventBodyToResponseBody(eventBody);
        }
        final BaseEventErrors responseErrors = event.getEventErrors();
        return new ExtORSResponse(responseBody, responseErrors);

    }

    public ORSEorChangedResponse mapRequestEventBodyToResponseBody(EorRequestChangedV1 eventBody){
        ORSEorChangedResponse response = new ORSEorChangedResponse();
        response.setEorUuid(eventBody.getEorUuid());
        response.setExternalEorId(eventBody.getExternalEorId());
        response.setExternalEorUuid(eventBody.getExternalEorUuid());
        return response;
    }

    public EorRequestChangedV1 getEventBodyBasedOnEventName(final BaseEvent<BaseHeader> event)
            throws JsonProcessingException {
        return objectMapper.readValue(event.getEventBody(), EorRequestChangedV1.class);
    }
}
