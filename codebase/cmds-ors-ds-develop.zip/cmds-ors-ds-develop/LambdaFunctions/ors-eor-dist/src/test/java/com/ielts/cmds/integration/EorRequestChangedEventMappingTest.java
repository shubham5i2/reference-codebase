package com.ielts.cmds.integration;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.mapper.EorRequestChangedEventMapping;
import com.ielts.cmds.integration.model.ExtORSResponse;
import com.ielts.cmds.integration.model.ORSEorChangedResponse;

@ExtendWith(MockitoExtension.class)
 class EorRequestChangedEventMappingTest {
    @Spy
    private ObjectMapper objectMapper;

    @Mock
    private Context context;

    @Spy private AbstractORSEorDist orsEorDist;

    @Spy private SQSEventBodySetup sqsEventSetup;

    @Spy
    SQSEvent sqsEvent;

    @Spy private EorRequestChangedEventMapping eorRequestChangedEventMapping;



    @Spy private Map<String, String> envVariable;


    @Mock private TypeReference<BaseEvent<BaseHeader>> typeRef;

    private String sqsMessage;

    /**
     * Sets up.
     *
     * @throws JsonProcessingException the json processing exception
     */
    @BeforeEach
    public void setUp() throws JsonProcessingException {
        objectMapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
        objectMapper.registerModule(new JavaTimeModule());
        typeRef = new TypeReference<BaseEvent<BaseHeader>>() {
        };
        sqsEvent = sqsEventSetup.populateSQSEventEorRequestChanged();
        envVariable = sqsEventSetup.getEnvironmentVariablesStub();
        sqsMessage = sqsEventSetup.getEorCompletedEventBody();
    }

    /**
     * Handle request with expection.
     *
     * @throws JsonProcessingException the json processing exception
     */
    @Test
    void handleRequest_WithException_thenIfVerifyCallToAPI() throws Exception {

        sqsEvent.getRecords().get(0).setBody("{test:");
        AbstractORSEorDist orsEorDistSpy =spy(orsEorDist);

        orsEorDistSpy.handleRequest(sqsEvent, context);
        verify(orsEorDistSpy, times(0)).postRequestToExternalAPI(
                ArgumentMatchers.any(),ArgumentMatchers.any(),ArgumentMatchers.anyString());
    }

    /**
     * Handle request with other expection.
     *
     * @throws JsonProcessingException the json processing exception
     */
    @Test
    void handleRequest_ExpectNoException() throws Exception {

        BaseEvent<BaseHeader> eorEvent = objectMapper.readValue(sqsMessage, typeRef);
        eorEvent.getEventHeader().setPartnerCode("IDP");
        ExtORSResponse response = eorRequestChangedEventMapping.mapToResponse(eorEvent);

        Executable executable= () -> orsEorDist.handleRequest(sqsEvent, context);
        assertDoesNotThrow(executable);
    }

    @Test
    void mapToResponse_thenReturnResponnse() throws Exception {
        BaseEvent<BaseHeader> eorEvent = objectMapper.readValue(sqsMessage, typeRef);
        eorEvent.getEventHeader().setPartnerCode("IDP");
        ExtORSResponse response = eorRequestChangedEventMapping.mapToResponse(eorEvent);
        ORSEorChangedResponse response1;

        response1 = (ORSEorChangedResponse)response.getResponse();
        assertNotNull(response.toString());
        assertEquals(UUID.fromString("827d15b9-0164-4ecc-ac38-9f9c8f97f28b"), response1.getExternalEorUuid());
        assertEquals("mockid",response1.getExternalEorId());
        assertEquals(UUID.fromString("e8958327-9917-4af2-91ce-7c6cd0c19837"),response1.getEorUuid());
    }
}
