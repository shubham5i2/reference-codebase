package com.ielts.cmds.integration;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.ielts.cmds.integration.constants.DistORSConstants;

@RunWith(MockitoJUnitRunner.class)
public class ORSEorDistIDPTest {

  @InjectMocks private ORSEorDistIDP orseorDistIDP;

  @Test
  public void getPartnerCodeConstants_whenGetPartnerCodeConstants_thenReturnIDP() {
    String partnerCodeConstants = orseorDistIDP.getPartnerCodeConstants();
    //Then
    assertEquals(DistORSConstants.IDP, partnerCodeConstants);
  }
}
