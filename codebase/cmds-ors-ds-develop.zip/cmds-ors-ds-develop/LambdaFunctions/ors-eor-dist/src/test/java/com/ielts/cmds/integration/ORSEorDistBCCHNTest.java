package com.ielts.cmds.integration;

import com.ielts.cmds.integration.constants.DistORSConstants;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class ORSEorDistBCCHNTest {

  @InjectMocks private ORSEorDistBCCHN orseorDistBCCHN;

  @Test
  public void getPartnerCodeConstants_whenGetPartnerCodeConstants_thenReturnBCCHN() {
    String partnerCodeConstants = orseorDistBCCHN.getPartnerCodeConstants();
    //Then
    assertEquals(DistORSConstants.BC_CHN, partnerCodeConstants);
  }
}
