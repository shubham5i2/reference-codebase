package com.ielts.cmds.integration;

import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.amazonaws.services.lambda.runtime.events.SQSEvent.SQSMessage;
import com.amazonaws.services.lambda.runtime.events.SQSEvent.MessageAttribute;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.integration.model.EorCompletedV1;
import com.ielts.cmds.rm.common.out.model.EorRequestChangedV1;

import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;

import java.lang.reflect.Field;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.Map;
import java.util.HashMap;

import static com.ielts.cmds.integration.constants.DistORSConstants.*;

public class SQSEventBodySetup {
  private static final ObjectMapper mapper = getMapper();

  public SQSEvent populateSQSEventEorCompleted() throws JsonProcessingException {
    final String event = getEorCompletedEventBody();
    final SQSMessage sqsMessage = new SQSMessage();
    final SQSEvent sqsEvent = new SQSEvent();
    final List<SQSMessage> records = new ArrayList<SQSMessage>();
    final MessageAttribute messageAttributes = new MessageAttribute();
    messageAttributes.setDataType("String");
    messageAttributes.setStringValue("3e81e94b-8b6a-42b5-970c-b141f9d195a4");
    final Map<String, MessageAttribute> messageAttributeMap = new HashMap<String, MessageAttribute>();
    messageAttributeMap.put("transactionUuid", messageAttributes);
    sqsMessage.setAwsRegion("eu-west-2");
    sqsMessage.setMessageAttributes(messageAttributeMap);
    sqsMessage.setBody(event);
    records.add(sqsMessage);
    sqsEvent.setRecords(records);
    return sqsEvent;
  }

  public SQSEvent populateSQSEventEorRequestChanged() throws JsonProcessingException {
    final String event = getEorRequestChangedEventBody();
    final SQSMessage sqsMessage = new SQSMessage();
    final SQSEvent sqsEvent = new SQSEvent();
    final List<SQSMessage> records = new ArrayList<SQSMessage>();
    final MessageAttribute messageAttributes = new MessageAttribute();
    messageAttributes.setDataType("String");
    messageAttributes.setStringValue("3e81e94b-8b6a-42b5-970c-b141f9d195a4");
    final Map<String, MessageAttribute> messageAttributeMap = new HashMap<String, MessageAttribute>();
    messageAttributeMap.put("transactionUuid", messageAttributes);
    sqsMessage.setAwsRegion("eu-west-2");
    sqsMessage.setMessageAttributes(messageAttributeMap);
    sqsMessage.setBody(event);
    records.add(sqsMessage);
    sqsEvent.setRecords(records);
    return sqsEvent;
  }

  public static String getEorRequestChangedEventBody() throws JsonProcessingException {
    BaseHeader eventHeader = getEventHeader();
    eventHeader.setPartnerCode("BC");
    eventHeader.setEventName(EOR_REQUEST_CHANGED);

    EorRequestChangedV1 eorDetials = getEorRequestChangedV1();
    String eventBody = mapper.writeValueAsString(eorDetials);

    List<ErrorDescription> errorList = new ArrayList<>();
    ErrorDescription description = new ErrorDescription();
    description.setInterfaceName("Booking");
    description.setType(ErrorTypeEnum.VALIDATION);
    description.setErrorCode("1234");
    Source source = Source.builder().value("").path("product_uuid").build();
    description.setSource(source);
    errorList.add(description);
    BaseEventErrors errorResponse = new BaseEventErrors(errorList);

    BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
    cmdsEvent.setEventHeader(eventHeader);
    cmdsEvent.setEventBody(eventBody);
    cmdsEvent.setEventErrors(errorResponse);
    return mapper.writeValueAsString(cmdsEvent);
  }
  public static BaseEventErrors getCMDSErrorResponse() throws JsonProcessingException {
    List<ErrorDescription> errorList = new ArrayList<>();
    ErrorDescription description = new ErrorDescription();
    description.setInterfaceName("mock");
    description.setType(ErrorTypeEnum.VALIDATION);
    description.setErrorCode("1234");
    Source source = Source.builder().value("").path("booking_uuid").build();
    description.setSource(source);
    errorList.add(description);

      BaseEventErrors errorResponse = new BaseEventErrors(errorList);
    return errorResponse;
  }

  public static EorRequestChangedV1 getEorRequestChangedV1() {
    EorRequestChangedV1 eorChangedDetials = new EorRequestChangedV1();
    eorChangedDetials.setExternalBookingUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775565"));
    eorChangedDetials.setEorUuid(UUID.fromString("e8958327-9917-4af2-91ce-7c6cd0c19837"));
    eorChangedDetials.setExternalEorId("mockid");
    eorChangedDetials.setExternalEorUuid(UUID.fromString("827d15b9-0164-4ecc-ac38-9f9c8f97f28b"));
    return eorChangedDetials;
  }

  public static String getEorCompletedEventBody() throws JsonProcessingException {
    BaseHeader eventHeader = getEventHeader();
    eventHeader.setEventName("EorCompleted");

    EorCompletedV1 eorDetials = getEorCompletedV1();
    String eventBody = mapper.writeValueAsString(eorDetials);

    List<ErrorDescription> errorList = new ArrayList<>();
    ErrorDescription description = new ErrorDescription();
    description.setInterfaceName("mockInterface");
    description.setType(ErrorTypeEnum.VALIDATION);
    description.setErrorCode("1234");
    Source source = Source.builder().value("").path("booking_uuid").build();
    description.setSource(source);
    errorList.add(description);
    BaseEventErrors errorResponse = new BaseEventErrors(errorList);

    BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
    cmdsEvent.setEventHeader(eventHeader);
    cmdsEvent.setEventBody(eventBody);
    cmdsEvent.setEventErrors(errorResponse);
    return mapper.writeValueAsString(cmdsEvent);
  }

  public static EorCompletedV1 getEorCompletedV1() {
    EorCompletedV1 eorCompletedDetials = new EorCompletedV1();
    eorCompletedDetials.setExternalBookingUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775565"));
    eorCompletedDetials.setEorUuid(UUID.fromString("e8958327-9917-4af2-91ce-7c6cd0c19837"));
    eorCompletedDetials.setExternalEorId("mockid");
    eorCompletedDetials.setExternalEorUuid(UUID.fromString("827d15b9-0164-4ecc-ac38-9f9c8f97f28b"));
    eorCompletedDetials.setResultUuid(UUID.fromString("0424dc6c-2b94-4848-848b-18556b906a0e"));
    return eorCompletedDetials;
  }

  protected static ObjectMapper getMapper() {
    ObjectMapper mapper = new ObjectMapper();
    mapper.registerModule(new JavaTimeModule());
    mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
    mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
    mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    return mapper;
  }

  public static BaseHeader getEventHeader() {
    BaseHeader eventHeader = new BaseHeader();
    eventHeader.setTransactionId(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
    eventHeader.setCallbackURL("http://35.178.179.164:8105/booking/eor");
    eventHeader.setCorrelationId(UUID.fromString("779187f5-38ed-4e86-b311-050ffe394f81"));
    LocalDateTime eventDateTime =
            LocalDateTime.parse(
                    "2020-09-29T21:00:35.723Z",
                    DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
    eventHeader.setEventDateTime(eventDateTime);
    return eventHeader;
  }
  public static BaseHeader getRequestChangedRejectEventHeader() {
    BaseHeader eventHeader = getEventHeader();
    eventHeader.setPartnerCode("BC");
    eventHeader.setEventName("EorRequestChangeFailed");
    return eventHeader;
  }



  public static String getIDPEventBody() throws JsonProcessingException {
    BaseHeader eventHeader = getEventHeader();
    eventHeader.setEventName("BookingCompleted");
    eventHeader.setPartnerCode("IDP");

    EorCompletedV1 eorDetials = getEorCompletedV1();
    String eventBody = mapper.writeValueAsString(eorDetials);

    List<ErrorDescription> errorList = new ArrayList<>();
    ErrorDescription description = new ErrorDescription();
    description.setInterfaceName("EOR");
    description.setType(ErrorTypeEnum.VALIDATION);
    description.setErrorCode("1234");
    Source source = Source.builder().value("").path("booking_uuid").build();
    description.setSource(source);
    errorList.add(description);

    BaseEventErrors errorResponse = new BaseEventErrors(errorList);

    BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
    cmdsEvent.setEventHeader(eventHeader);
    cmdsEvent.setEventBody(eventBody);
    cmdsEvent.setEventErrors(errorResponse);
    return mapper.writeValueAsString(cmdsEvent);
  }

  public static String getBCCHNEventBody() throws JsonProcessingException {
    BaseHeader eventHeader = getEventHeader();
    eventHeader.setEventName("BookingCompleted");
    eventHeader.setPartnerCode("BC_CHN");

    EorCompletedV1 eorDetials = getEorCompletedV1();
    String eventBody = mapper.writeValueAsString(eorDetials);

    List<ErrorDescription> errorList = new ArrayList<>();
    ErrorDescription description = new ErrorDescription();
    description.setInterfaceName("EOR");
    description.setType(ErrorTypeEnum.VALIDATION);
    description.setErrorCode("1234");
    Source source = Source.builder().value("").path("booking_uuid").build();
    description.setSource(source);
    errorList.add(description);

    BaseEventErrors errorResponse = new BaseEventErrors(errorList);

    BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
    cmdsEvent.setEventHeader(eventHeader);
    cmdsEvent.setEventBody(eventBody);
    cmdsEvent.setEventErrors(errorResponse);
    return mapper.writeValueAsString(cmdsEvent);
  }


  public static Map<String, String> getEnvironmentVariables(final String partnerCode)
          throws JsonProcessingException {
    final Map<String, String> map = new HashMap<>();

    if (System.getenv(CLIENT_ID) != null || System.getenv(CLIENT_SECRET) != null) {
      map.put(CLIENT_ID, System.getenv(CLIENT_ID) != null ? System.getenv(CLIENT_ID) : null);
      map.put(
              CLIENT_SECRET,
              System.getenv(CLIENT_SECRET) != null ? System.getenv(CLIENT_SECRET) : null);
    } else {
      Map<String, String> envVar = getEnvironmentVariablesStub();
      map.put(CLIENT_ID, envVar.get(CLIENT_ID));
      map.put(CLIENT_SECRET, envVar.get(CLIENT_SECRET));
    }
    return map;
  }
  public static Map<String, String> getEnvironmentVariablesStub() {
    Map<String, String> map = new HashMap<>();
    map.put(CLIENT_ID, "cmds-id");
    map.put(CLIENT_SECRET, "cmds-secret");
    map.put(ACCESS_TOKEN, "access-token");
    map.put("bc_auth_token_url", "BC_AUTH_URL");
    map.put(CALLBACK_URL, "https://wiremock.shared.cmdsiz.com/ors/invoke/v1/booking/eor");
    return map;
  }
  protected static void setEnvironment(Map<String, String> newenv) throws Exception {
    try {
      Class<?> processEnvironmentClass = Class.forName("java.lang.ProcessEnvironment");
      Field theEnvironmentField = processEnvironmentClass.getDeclaredField("theEnvironment");
      theEnvironmentField.setAccessible(true);
      Map<String, String> env = (Map<String, String>) theEnvironmentField.get(null);
      env.putAll(newenv);
      Field theCaseInsensitiveEnvironmentField = processEnvironmentClass.getDeclaredField("theCaseInsensitiveEnvironment");
      theCaseInsensitiveEnvironmentField.setAccessible(true);
      Map<String, String> cienv = (Map<String, String>)     theCaseInsensitiveEnvironmentField.get(null);
      cienv.putAll(newenv);
    } catch (NoSuchFieldException e) {
      Class[] classes = Collections.class.getDeclaredClasses();
      Map<String, String> env = System.getenv();
      for(Class cl : classes) {
        if("java.util.Collections$UnmodifiableMap".equals(cl.getName())) {
          Field field = cl.getDeclaredField("m");
          field.setAccessible(true);
          Object obj = field.get(env);
          Map<String, String> map = (Map<String, String>) obj;
          map.clear();
          map.putAll(newenv);
        }
      }
    }
  }

}
