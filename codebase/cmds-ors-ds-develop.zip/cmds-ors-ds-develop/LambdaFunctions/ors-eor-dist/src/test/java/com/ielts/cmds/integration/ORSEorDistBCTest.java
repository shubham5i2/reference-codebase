package com.ielts.cmds.integration;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.ielts.cmds.integration.constants.DistORSConstants;

@RunWith(MockitoJUnitRunner.class)
public class ORSEorDistBCTest {

  @InjectMocks private ORSEorDistBC  orseorDistBC;
  @Test
  public void getPartnerCodeConstants_whenGetPartnerCodeConstants_thenReturnBC() {
    String partnerCodeConstants = orseorDistBC.getPartnerCodeConstants();
    //Then
    assertEquals(DistORSConstants.BC, partnerCodeConstants);
  }
}
