package com.ielts.cmds.integration;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.mapper.EorCompletedEventMapping;
import com.ielts.cmds.integration.model.ExtORSResponse;
import com.ielts.cmds.integration.model.ORSEorCompletedResponse;


@ExtendWith(MockitoExtension.class)
 class EorCompletedEventMappingTest {

    @Spy private ObjectMapper objectMapper;

    @Mock private Context context;

    @Spy private AbstractORSEorDist orsEorDist;

    @Spy private SQSEventBodySetup sqsEventSetup;

    @Spy SQSEvent sqsEvent;

    @Spy private EorCompletedEventMapping eorCompletedEventMapping;



    @Spy private Map<String, String> envVariable;

    @Mock private TypeReference<BaseEvent<BaseHeader>> typeRef;

    private String sqsMessage;

    /**
     * Sets up.
     *
     * @throws JsonProcessingException the json processing exception
     */
    @BeforeEach
    public void setUp() throws JsonProcessingException {
        objectMapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
        objectMapper.registerModule(new JavaTimeModule());
        typeRef = new TypeReference<BaseEvent<BaseHeader>>() {
        };
        sqsEvent = sqsEventSetup.populateSQSEventEorCompleted();
        envVariable = sqsEventSetup.getEnvironmentVariablesStub();
        sqsMessage = sqsEventSetup.getEorCompletedEventBody();
    }

    @Test
    void handleRequest_ExpectNoException() throws Exception {

        BaseEvent<BaseHeader> eorEvent = objectMapper.readValue(sqsMessage, typeRef);
        eorEvent.getEventHeader().setPartnerCode("IDP");
        ExtORSResponse response = eorCompletedEventMapping.mapToResponse(eorEvent);

        Executable executable= () -> orsEorDist.handleRequest(sqsEvent, context);
        assertDoesNotThrow(executable);
    }

    /**
     * Handle request with expection.
     *
     * @throws JsonProcessingException the json processing exception
     */
    @Test
    void handleRequest_thenVerifyCallToAPI() throws Exception {

        sqsEvent.getRecords().get(0).setBody("{test:");
        AbstractORSEorDist orsEorDistSpy =spy(orsEorDist);

        orsEorDistSpy.handleRequest(sqsEvent, context);
        verify(orsEorDistSpy, times(0)).postRequestToExternalAPI(
                ArgumentMatchers.any(),ArgumentMatchers.any(),ArgumentMatchers.anyString());
    }

    @Test
    void mapToResponse_thenReturnResponse() throws Exception {
        BaseEvent<BaseHeader> eorEvent = objectMapper.readValue(sqsMessage, typeRef);
        eorEvent.getEventHeader().setPartnerCode("IDP");
        ExtORSResponse response = eorCompletedEventMapping.mapToResponse(eorEvent);
        ORSEorCompletedResponse response1;
        response1 = (ORSEorCompletedResponse)response.getResponse();
        assertNotNull(response.getResponse());
        assertEquals(UUID.fromString("827d15b9-0164-4ecc-ac38-9f9c8f97f28b"), response1.getExternalEorUuid());
        assertEquals("mockid",response1.getExternalEorId());
        assertEquals(UUID.fromString("e8958327-9917-4af2-91ce-7c6cd0c19837"),response1.getEorUuid());
        assertEquals(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775565"), response1.getExternalBookingUuid());
    }

}
