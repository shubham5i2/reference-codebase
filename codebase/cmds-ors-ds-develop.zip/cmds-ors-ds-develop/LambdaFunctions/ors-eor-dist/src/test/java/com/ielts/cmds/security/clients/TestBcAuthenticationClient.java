package com.ielts.cmds.security.clients;

import com.ielts.cmds.security.model.BCCommonSecurityModel;

public class TestBcAuthenticationClient extends BCAuthenticationCommonClient{


  protected TestBcAuthenticationClient(BCCommonSecurityModel bcModel){
    super(bcModel);
  }

  @Override
  String getSystemName(){
    this.createBCAuthTokenRequest(new BCCommonSecurityModel());
    return null;
  }



}
