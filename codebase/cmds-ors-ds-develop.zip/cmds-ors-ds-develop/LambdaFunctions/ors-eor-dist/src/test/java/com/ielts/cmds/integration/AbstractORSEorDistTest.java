package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.constants.DistORSConstants.ACCESS_TOKEN;
import static com.ielts.cmds.integration.constants.DistORSConstants.AUTH_HEADER;
import static com.ielts.cmds.integration.constants.DistORSConstants.CALLBACK_URL;
import static com.ielts.cmds.integration.constants.DistORSConstants.CORRELATIONID;
import static com.ielts.cmds.integration.constants.DistORSConstants.EOR_CHANGE_FAILED;
import static com.ielts.cmds.integration.constants.DistORSConstants.EVENT_DATE_TIME;
import static com.ielts.cmds.integration.constants.DistORSConstants.ORS_EOR_DIST_BCCHN;
import static com.ielts.cmds.integration.constants.DistORSConstants.ORS_EOR_DIST_IDP;
import static com.ielts.cmds.integration.constants.DistORSConstants.PARTNER_CODE;
import static com.ielts.cmds.integration.constants.DistORSConstants.TRANSACTIONID;
import static com.ielts.cmds.integration.constants.DistORSConstants.USER_AGENT;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.amazonaws.services.lambda.runtime.events.SQSEvent.SQSMessage;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.constants.DistORSConstants;
import com.ielts.cmds.integration.model.CMDSResponseBody;
import com.ielts.cmds.integration.model.ExtORSResponse;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.clients.BritishCouncilAuthenticationClient;
import com.ielts.cmds.security.clients.IDPAuthenticationClient;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;
import com.ielts.cmds.security.utils.SecurityUtility;

@RunWith(MockitoJUnitRunner.Silent.class)
public class AbstractORSEorDistTest {
  @InjectMocks private ORSEorDistBC orseorDistbc;
  @InjectMocks private ORSEorDistIDP orseorDistIDP;
  @InjectMocks private ORSEorDistBCCHN orseorDistBCCHN;
  @Mock private Context context;
  @Mock private RestTemplate restTemplate;
  private final ObjectMapper mapper = SQSEventBodySetup.getMapper();
  @Mock private EnvironmentAwareAuthenticationClientFactory authenticationFactory;
  @Mock BritishCouncilAuthenticationClient britishCouncilAuthenticationClient;
  @Mock private AuthenticationClient client;
  @Mock private SQSEventBodySetup sqsEventBodySetup;
  @Mock private IDPAuthenticationClient idpClient;
  @Mock private IDPAuthenticationClient bcchnClient;
  @Spy private SQSEvent event;
  @Spy private SQSEvent eventIdp;
  @Spy private SQSEvent eventBcchn;
  @Spy private SQSMessage message;
  @Spy private SQSMessage messageIdp;
  @Spy private SQSMessage messageBcchn;
  @Mock private List<String> rejectedEvents;
  @InjectMocks
  @Rule public final ExpectedException exceptionRule = ExpectedException.none();
  static MockedStatic<SecurityUtility> lambdaUtilityMockedStatic;
  @BeforeClass
  public static void beforeClass() throws Exception {
    Map<String, String> envVar = SQSEventBodySetup.getEnvironmentVariablesStub();
  }

  @AfterClass
  public static void afterClass() throws Exception {
    Mockito.framework().clearInlineMocks();
  }

  @Before
  public void setUp() throws JsonProcessingException {
    mapper.registerModule(new JavaTimeModule());
    mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
    mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
    String eventBody = sqsEventBodySetup.getEorRequestChangedEventBody();
    message.setBody(eventBody);
    messageIdp.setBody(SQSEventBodySetup.getIDPEventBody());
    messageBcchn.setBody(SQSEventBodySetup.getBCCHNEventBody());
    List<SQSMessage> records = new ArrayList<>();
    records.add(message);
    event.setRecords(records);
    List<SQSMessage> recordIdps = new ArrayList<>();
    recordIdps.add(messageIdp);
    eventIdp.setRecords(recordIdps);
    List<SQSMessage> recordBcchns = new ArrayList<>();
    recordBcchns.add(messageBcchn);
    eventBcchn.setRecords(recordBcchns);
    rejectedEvents.add(EOR_CHANGE_FAILED);
  }


  @Test
  public void whenRejectEventWithBodyEmpty_thenIfVerifyCallToAPI() throws Exception {
    // Given
    String expectedExceptionMsg = "No event body to publish for sqs message";
    BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
    cmdsEvent.setEventHeader(sqsEventBodySetup.getRequestChangedRejectEventHeader());
    cmdsEvent.setEventErrors(null);
    cmdsEvent.setEventBody("");
    String eventBody = mapper.writeValueAsString(cmdsEvent);
    message.setBody(eventBody);
    ORSEorDistBC orsEorDistBCSpy =spy(orseorDistbc);

    orsEorDistBCSpy.handleRequest(event, context);
    verify(orsEorDistBCSpy, times(0)).postRequestToExternalAPI(
            ArgumentMatchers.any(),ArgumentMatchers.any(),ArgumentMatchers.anyString());
  }
  @Test
  public void whenRejectEventWithBody_thenIfVerifyCallToAPI() throws Exception {
    // Given
    String expectedExceptionMsg = "No event errors to publish for sqs message";
    BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
    cmdsEvent.setEventHeader(SQSEventBodySetup.getEventHeader());
    cmdsEvent.getEventHeader().setEventName(null);
    cmdsEvent.setEventErrors(null);
    cmdsEvent.setEventBody(message.getBody());
    String eventBody = mapper.writeValueAsString(cmdsEvent);
    message.setBody(eventBody);

    ORSEorDistBC orsEorDistBCSpy =spy(orseorDistbc);

    orsEorDistBCSpy.handleRequest(event, context);
    verify(orsEorDistBCSpy, times(0)).postRequestToExternalAPI(
            ArgumentMatchers.any(),ArgumentMatchers.any(),ArgumentMatchers.anyString());
  }


  /*
   * When EventType is null or empty then Throw exception ORSDistException("EventType does not exist")
   */
  @Test
  public void whenEventTypeIsNull_thenIfVerifyCallToAPI() throws Exception {
    // Given
    String expectedExceptionMsg = "EventName can't be null or empty";
    BaseEvent<BaseHeader> cmdsEvent = mapper.readValue(message.getBody(), BaseEvent.class);
    cmdsEvent.getEventHeader().setEventName(null);
    cmdsEvent.setEventErrors(null);
    String eventBody = mapper.writeValueAsString(cmdsEvent);
    message.setBody(eventBody);

    ORSEorDistBC orsEorDistBCSpy =spy(orseorDistbc);

    orsEorDistBCSpy.handleRequest(event, context);
    verify(orsEorDistBCSpy, times(0)).postRequestToExternalAPI(
            ArgumentMatchers.any(),ArgumentMatchers.any(),ArgumentMatchers.anyString());
  }


  @Test
  public void testExtORSResponseModel_ValidateNull() throws JsonProcessingException {
    ExtORSResponse extResponse = new ExtORSResponse(null, null);
    assertNull(extResponse.getResponse());
    assertNull(extResponse.getErrors());
  }

  /*
   * clean up resources
   */
  @After
  public void tearDown() {
    message = null;
    event = null;
  }
  /**
   * constructs httpheader based on provided eventheader
   *
   * @param eventHeader
   * @return
   */
  private HttpHeaders getHttpHeaders(BaseHeader eventHeader) {
    HttpHeaders httpHeaders = new HttpHeaders();
    httpHeaders.setContentType(MediaType.APPLICATION_JSON);
    httpHeaders.set(TRANSACTIONID, eventHeader.getTransactionId().toString());
    httpHeaders.set(CORRELATIONID, eventHeader.getCorrelationId().toString());

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
    httpHeaders.set(
            EVENT_DATE_TIME,
            Objects.isNull(eventHeader.getEventDateTime())
                    ? ""
                    : eventHeader.getEventDateTime().format(formatter));
    return httpHeaders;
  }

  @Test
  public void whenBCRequestHasValidAuthenticationHeader_ThenVerifyIfCallToRestTemplate() throws Exception {
    //Prepare test data
    BaseEvent<BaseHeader> baseEvent = mapper.readValue(message.getBody(), BaseEvent.class);
    baseEvent.getEventHeader().setPartnerCode("BC");
    Map<String, String> map = new HashMap<>();
    map.put(CALLBACK_URL, SQSEventBodySetup.getEnvironmentVariablesStub().get(CALLBACK_URL));
    map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
    map.put(AUTH_HEADER, "Authorization");
    map.put(USER_AGENT, "CMDS");
    ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.OK);
    HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
    eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));

    //Define mock variables behaviour
    when(authenticationFactory.getAuthenticationClient(baseEvent.getEventHeader().getPartnerCode())).thenReturn(britishCouncilAuthenticationClient);
    ReflectionTestUtils.setField(orseorDistbc, "authenticationClientFactory", authenticationFactory);
    doReturn("authHeaderName").when(britishCouncilAuthenticationClient).getAuthorizationHeaderName();
    doReturn("accessToken").when(britishCouncilAuthenticationClient).getAccessToken();
    doReturn(restTemplate).when(britishCouncilAuthenticationClient).getRestTemplate();
    when(restTemplate.postForEntity(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.any(Class.class)))
            .thenReturn(response2);


    SQSEventBodySetup.setEnvironment(map);
    //Execute and assert test
    assertDoesNotThrow(() -> orseorDistbc.handleRequest(event, context));
  }

  private HttpHeaders getHttpHeaders(BaseEvent<BaseHeader> eventHeader) {
    HttpHeaders httpHeaders = new HttpHeaders();
    httpHeaders.setContentType(MediaType.APPLICATION_JSON);
    httpHeaders.set(TRANSACTIONID, eventHeader.getEventHeader().getTransactionId().toString());
    httpHeaders.set(CORRELATIONID, eventHeader.getEventHeader().getCorrelationId().toString());
    httpHeaders.set(PARTNER_CODE, eventHeader.getEventHeader().getPartnerCode());
    return httpHeaders;
  }

  @Test
  public void whenBCRequestDoesNotHaveAcceptedStatusCode_ThenThrowsException() throws Exception {
    //Prepare test data
    BaseEvent<?>  baseEvent =mapper.readValue(message.getBody(), BaseEvent.class);
    Map<String, String> map = new HashMap<>();
    map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
    map.put(AUTH_HEADER, "Authorization");
    baseEvent.getEventHeader().setPartnerCode("IDP");
    ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
    eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));
    CMDSResponseBody responseBody = new CMDSResponseBody(baseEvent.getEventErrors());
    //Define mock variables behaviour
    BaseHeader eventHeader = baseEvent.getEventHeader();
      when(authenticationFactory.getAuthenticationClient(baseEvent.getEventHeader().getPartnerCode())).thenReturn(britishCouncilAuthenticationClient);
      ReflectionTestUtils.setField(orseorDistbc, "authenticationClientFactory", authenticationFactory);
      doReturn("authHeaderName").when(britishCouncilAuthenticationClient).getAuthorizationHeaderName();
      doReturn("accessToken").when(britishCouncilAuthenticationClient).getAccessToken();
      doReturn(restTemplate).when(britishCouncilAuthenticationClient).getRestTemplate();
      when(restTemplate.postForEntity(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.any(Class.class))).thenReturn(response2);
//    //Execute and assert test
    assertDoesNotThrow(() -> orseorDistbc.postRequestToExternalAPI(responseBody,eventHeader,"mockString"));
  }



  @Test
  public void whenBCRequestHasInValidAuthenticationHeader_thenExceptionIsCaught() throws Exception {
    //Prepare test data
    BaseEvent<?>  baseEvent =mapper.readValue(message.getBody(), BaseEvent.class);
   Map<String, String> map = new HashMap<>();
    map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
    map.put(AUTH_HEADER, "Authorization");

    ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
    eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));

    //Define mock variables behaviour
    when(authenticationFactory.getAuthenticationClient(baseEvent.getEventHeader().getPartnerCode())).thenReturn(britishCouncilAuthenticationClient);
    ReflectionTestUtils.setField(orseorDistbc, "authenticationClientFactory", authenticationFactory);
    doReturn("authHeaderName").when(britishCouncilAuthenticationClient).getAuthorizationHeaderName();
    doReturn("accessToken").when(britishCouncilAuthenticationClient).getAccessToken();
    doReturn(restTemplate).when(britishCouncilAuthenticationClient).getRestTemplate();
    when(restTemplate.postForEntity(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.any(Class.class))).thenReturn(response2);
    //Execute and assert test
    assertDoesNotThrow( () -> orseorDistbc.handleRequest(event, context));
  }

  @Test
  public void whenBCRequestHasInvalidAuthenticationHeader_ThenDoesNotThrowException() throws Exception {
    //Prepare test data
    BaseEvent<BaseHeader> baseEvent = mapper.readValue(message.getBody(), BaseEvent.class);
    baseEvent.getEventHeader().setPartnerCode("BC");
    Map<String, String> map = new HashMap<>();
    map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
    map.put(CALLBACK_URL, SQSEventBodySetup.getEnvironmentVariablesStub().get(CALLBACK_URL));
    map.put(AUTH_HEADER, "Authorization");
    SQSEventBodySetup.setEnvironment(map);
    ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.OK);
    HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
    eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));
    //Define mock variables behaviour
    when(authenticationFactory.getAuthenticationClient(baseEvent.getEventHeader().getPartnerCode())).thenReturn(britishCouncilAuthenticationClient);
    ReflectionTestUtils.setField(orseorDistbc, "authenticationClientFactory", authenticationFactory);
    doReturn("authHeaderName").when(britishCouncilAuthenticationClient).getAuthorizationHeaderName();
    doReturn("accessToken").when(britishCouncilAuthenticationClient).getAccessToken();
    doReturn(restTemplate).when(britishCouncilAuthenticationClient).getRestTemplate();
    when(restTemplate.postForEntity(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.any(Class.class))).thenReturn(response2);
    //Execute and assert test
    assertDoesNotThrow(() -> orseorDistbc.handleRequest(event, context));
  }

  @Test
  public void whenIDPRequestHasInvalidAuthenticationHeader_ThenDoesNotThrowException() throws Exception {
    //Prepare test data
    BaseEvent<?> baseEvent = mapper.readValue(message.getBody(), BaseEvent.class);
    baseEvent.getEventHeader().setPartnerCode("IDP");
    Map<String, String> map = new HashMap<>();
    map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
    map.put(AUTH_HEADER, "Authorization");
    ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.OK);
    HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
    eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));
    //Define mock variables behaviour
    when(authenticationFactory.getAuthenticationClient(baseEvent.getEventHeader().getPartnerCode())).thenReturn(idpClient);
    ReflectionTestUtils.setField(orseorDistIDP, "authenticationClientFactory", authenticationFactory);
    doReturn("authHeaderName").when(idpClient).getAuthorizationHeaderName();
    doReturn("accessToken").when(idpClient).getAccessToken();
    doReturn(restTemplate).when(idpClient).getRestTemplate();
    when(restTemplate.postForEntity(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.any(Class.class))).thenReturn(response2);
    //Execute and assert test
    assertDoesNotThrow(() -> orseorDistIDP.handleRequest(event, context));
  }

  @Test
  public void whenIDPRequestHasInValidAuthenticationHeader_ThenExceptionIsCaught() throws Exception {
    BaseEvent<?> baseEvent = mapper.readValue(messageIdp.getBody(), BaseEvent.class);
    baseEvent.getEventHeader().setPartnerCode("IDP");
    Map<String, String> map = new HashMap<>();
    map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
    map.put(AUTH_HEADER, "Authorization");
    ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.BAD_GATEWAY);
    HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
    eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));
    //Define mock variables behaviour
    when(authenticationFactory.getAuthenticationClient(baseEvent.getEventHeader().getPartnerCode())).thenReturn(idpClient);
    ReflectionTestUtils.setField(orseorDistIDP, "authenticationClientFactory", authenticationFactory);
    doReturn("authHeaderName").when(idpClient).getAuthorizationHeaderName();
    doReturn("accessToken").when(idpClient).getAccessToken();
    doReturn(restTemplate).when(idpClient).getRestTemplate();
    when(restTemplate.postForEntity(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpEntity.class),
            ArgumentMatchers.any(Class.class))).thenReturn(response2);
    //Execute and assert test
    assertDoesNotThrow(() -> orseorDistIDP.handleRequest(eventIdp, context) );
  }

  @Test
  public void whenBCCHNRequestHasInvalidAuthenticationHeader_ThenDoesNotThrowException() throws Exception {
    //Prepare test data
    BaseEvent<?> baseEvent = mapper.readValue(message.getBody(), BaseEvent.class);
    baseEvent.getEventHeader().setPartnerCode("BC_CHN");
    Map<String, String> map = new HashMap<>();
    map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
    map.put(AUTH_HEADER, "Authorization");
    ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.OK);
    HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
    eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));
    //Define mock variables behaviour
    when(authenticationFactory.getAuthenticationClient(baseEvent.getEventHeader().getPartnerCode())).thenReturn(bcchnClient);
    ReflectionTestUtils.setField(orseorDistBCCHN, "authenticationClientFactory", authenticationFactory);
    doReturn("authHeaderName").when(bcchnClient).getAuthorizationHeaderName();
    doReturn("accessToken").when(bcchnClient).getAccessToken();
    doReturn(restTemplate).when(bcchnClient).getRestTemplate();
    when(restTemplate.postForEntity(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.any(Class.class))).thenReturn(response2);
    //Execute and assert test
    assertDoesNotThrow(() -> orseorDistBCCHN.handleRequest(event, context));
  }

  @Test
  public void whenBCCHNRequestHasInValidAuthenticationHeader_ThenExceptionIsCaught() throws Exception {
    BaseEvent<?> baseEvent = mapper.readValue(messageBcchn.getBody(), BaseEvent.class);
    baseEvent.getEventHeader().setPartnerCode("BC_CHN");
    Map<String, String> map = new HashMap<>();
    map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
    map.put(AUTH_HEADER, "Authorization");
    ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.BAD_GATEWAY);
    HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
    eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));
    //Define mock variables behaviour
    when(authenticationFactory.getAuthenticationClient(baseEvent.getEventHeader().getPartnerCode())).thenReturn(bcchnClient);
    ReflectionTestUtils.setField(orseorDistBCCHN, "authenticationClientFactory", authenticationFactory);
    doReturn("authHeaderName").when(bcchnClient).getAuthorizationHeaderName();
    doReturn("accessToken").when(bcchnClient).getAccessToken();
    doReturn(restTemplate).when(bcchnClient).getRestTemplate();
    when(restTemplate.postForEntity(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpEntity.class),
            ArgumentMatchers.any(Class.class))).thenReturn(response2);
    //Execute and assert test
    assertDoesNotThrow(() -> orseorDistBCCHN.handleRequest(eventBcchn, context) );
  }

  @Test
  public void getApplicationName_whenGetApplicationName_thenReturnInvalidApplicationNameForBC() {
    String applicationName = orseorDistbc.getApplicationName();
    // Then
    assertEquals(DistORSConstants.ORS_EOR_DIST_BC, applicationName);
  }

  @Test
  public void getApplicationName_whenGetApplicationName_thenReturnInvalidApplicationNameForIDP() {
    String applicationName = orseorDistIDP.getApplicationName();
    // Then
    assertEquals(ORS_EOR_DIST_IDP, applicationName);
  }

  @Test
  public void getApplicationName_whenGetApplicationName_thenReturnInvalidApplicationNameForBCCHN() {
    String applicationName = orseorDistBCCHN.getApplicationName();
    // Then
    assertEquals(ORS_EOR_DIST_BCCHN, applicationName);
  }
  @Test
  public void getPartnerCodeConstants_whenGetPartnerCodeConstants_thenReturnBC() {
    String partnerCodeConstants = orseorDistbc.getPartnerCodeConstants();
    // Then
    assertEquals(DistORSConstants.BC, partnerCodeConstants);
  }
  @Test
  public void getPartnerCodeConstants_whenGetPartnerCodeConstants_thenReturnIDP() {
    String partnerCodeConstants = orseorDistIDP.getPartnerCodeConstants();
    // Then
    assertEquals(DistORSConstants.IDP, partnerCodeConstants);
  }

  @Test
  public void getPartnerCodeConstants_whenGetPartnerCodeConstants_thenReturnBCCHN() {
    String partnerCodeConstants = orseorDistBCCHN.getPartnerCodeConstants();
    // Then
    assertEquals(DistORSConstants.BC_CHN, partnerCodeConstants);
  }

}
