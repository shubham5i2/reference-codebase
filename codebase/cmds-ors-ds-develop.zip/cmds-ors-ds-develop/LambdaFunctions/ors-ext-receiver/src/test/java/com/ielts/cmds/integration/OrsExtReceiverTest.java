package com.ielts.cmds.integration;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.InvalidParameterException;
import com.amazonaws.services.sns.model.NotFoundException;
import com.amazonaws.services.sns.model.PublishRequest;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.utils.CMDSCommonUtils;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.config.SNSClientConfig;
import com.ielts.cmds.integration.helper.EventReceiverTestHelper;
import com.ielts.cmds.integration.request.RequestBodyToSNS;
import com.ielts.cmds.integration.response.GateWayResponseEntity;
import org.apache.http.HttpStatus;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.Spy;
import org.mockito.MockedStatic;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatchers;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.org.webcompere.systemstubs.environment.EnvironmentVariables;
import uk.org.webcompere.systemstubs.jupiter.SystemStub;
import uk.org.webcompere.systemstubs.jupiter.SystemStubsExtension;

import java.util.Map;
import java.util.UUID;

import static com.ielts.cmds.integration.constants.ReceiverConstants.AWS_ACCOUNT_ID;
import static com.ielts.cmds.integration.constants.ReceiverConstants.AWS_ENV;
import static com.ielts.cmds.integration.constants.ReceiverConstants.AWS_REGION;
import static com.ielts.cmds.integration.constants.ReceiverConstants.PARTNER_CODE;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


/** Test class to validate the Ors-Ext-Receiver */
@ExtendWith(MockitoExtension.class)
@ExtendWith(SystemStubsExtension.class)
class OrsExtReceiverTest {


    @Spy
    private OrsExtReceiver eventReceiver;

    @Mock
    private ObjectMapper objectMapper;

    @Spy private SNSClientConfig snsClientConfig;

    @Mock private Context context;

    @Mock private AmazonSNS orsTopicSNSClient;

    @Mock private GateWayResponseEntity gateWayResponseEntity;

    private String transactionId;

    private BaseEvent<BaseHeader> orsRequestEvent;

    private BaseEvent<BaseHeader> incidentRequestEvent;

    private BaseEvent<BaseHeader> refundRequestedEvent;

    private BaseEvent<BaseHeader> recognisingOrganisationSelectionChangedEvent;

    private BaseEvent<BaseHeader> organisationSelectionWithdrawRequestedEvent;

    private MockedStatic<SNSClientConfig> snsClientStatic;

    private MockedStatic<CMDSCommonUtils> mockStatic;

    private UUID defaultUuid;

    @SystemStub
    private EnvironmentVariables env;

    @BeforeEach
    void setUp() throws Exception {
        transactionId = "70d2d81f-bb68-4987-892a-4069a526ab94";
        orsRequestEvent = EventReceiverTestHelper.getRequestEvent();
        incidentRequestEvent = EventReceiverTestHelper.getIncidentRequestEvent();
        refundRequestedEvent = EventReceiverTestHelper.getRefundRequestedEvent();
        recognisingOrganisationSelectionChangedEvent = EventReceiverTestHelper.getRecognisingOrganisationSelectionChangedEvent();
        organisationSelectionWithdrawRequestedEvent = EventReceiverTestHelper.getOrganisationSelectionWithdrawRequestedEvent();
        mockStatic = Mockito.mockStatic(CMDSCommonUtils.class);
        snsClientStatic = Mockito.mockStatic(SNSClientConfig.class);
        defaultUuid = UUID.fromString("70d2d81f-bb68-4987-892a-4069a526ab93");
    }

    @Test
    void handleRequest_ExtractRequest_JsonParsingExceptionTest()
            throws JsonProcessingException
    {
        try (MockedStatic<UUID> mockedStaticUUID = Mockito.mockStatic(UUID.class)) {
            mockedStaticUUID.when(UUID::randomUUID).thenReturn(defaultUuid);

            GateWayResponseEntity responseEntity =eventReceiver.handleRequest(getMapper().writeValueAsString(orsRequestEvent),
                    context);
            Assertions.assertNotNull(responseEntity);
            assertEquals(HttpStatus.SC_BAD_REQUEST, responseEntity.getStatusCode());

        }
    }

    @Test
    void handleRequest_ExtractRequest_Test() throws JsonProcessingException {
        mockStatic.when(() -> CMDSCommonUtils.getDataFromClaims("token", PARTNER_CODE)).thenReturn("IDP");

        BaseEvent<BaseHeader> requestEvent = incidentRequestEvent;

        final RequestBodyToSNS snsRequest = eventReceiver.extractRequestFrom(
                requestEvent,
                transactionId,
                getMapper()
        );

        Assertions.assertNotNull(snsRequest);
        assertEquals("/v1/incident/receivespeakingincident", snsRequest.getEventHeader().getResource());
        assertEquals("IDP", snsRequest.getEventHeader().getPartnerCode());
        Assertions.assertNotNull(snsRequest.getEventHeader().getEventContext());
        assertEquals(
                UUID.fromString("70d2d81f-bb68-4987-892a-4069a526ab94"),
                snsRequest.getEventHeader().getTransactionId()
        );
    }

    @Test
    void handleRequest_ExtractRequest_RefundCRequested_Test() throws JsonProcessingException {
        mockStatic.when(() -> CMDSCommonUtils.getDataFromClaims("token", PARTNER_CODE)).thenReturn("IDP");

        BaseEvent<BaseHeader> requestEvent = refundRequestedEvent;

        final RequestBodyToSNS snsRequest = eventReceiver.extractRequestFrom(requestEvent, transactionId, getMapper());

        Assertions.assertNotNull(snsRequest);
        assertEquals("IDP", snsRequest.getEventHeader().getPartnerCode());
        Assertions.assertNotNull(snsRequest.getEventHeader().getEventContext());
        assertEquals(UUID.fromString("70d2d81f-bb68-4987-892a-4069a526ab94"), snsRequest.getEventHeader().getTransactionId()
        );
    }

    @Test
    void handleRequest_ExtractRequest_RecognisingOrganisationSelectionChanged_Test() throws JsonProcessingException {
        mockStatic.when(() -> CMDSCommonUtils.getDataFromClaims("token", PARTNER_CODE)).thenReturn("IDP");

        BaseEvent<BaseHeader> requestEvent = recognisingOrganisationSelectionChangedEvent;

        final RequestBodyToSNS snsRequest = eventReceiver.extractRequestFrom(requestEvent, transactionId, getMapper());

        Assertions.assertNotNull(snsRequest);
        assertEquals("IDP", snsRequest.getEventHeader().getPartnerCode());
        Assertions.assertNotNull(snsRequest.getEventHeader().getEventContext());
        assertEquals(UUID.fromString("70d2d81f-bb68-4987-892a-4069a526ab94"), snsRequest.getEventHeader().getTransactionId()
        );
    }

    @Test
    void handleRequest_ExtractRequest_RecognisingOrganisationSelectionWithdrawRequestedEvent_Test() throws JsonProcessingException {
        mockStatic.when(() -> CMDSCommonUtils.getDataFromClaims("token", PARTNER_CODE)).thenReturn("IDP");

        BaseEvent<BaseHeader> requestEvent = organisationSelectionWithdrawRequestedEvent;

        final RequestBodyToSNS snsRequest = eventReceiver.extractRequestFrom(requestEvent, transactionId, getMapper());

        Assertions.assertNotNull(snsRequest);
        assertEquals("IDP", snsRequest.getEventHeader().getPartnerCode());
        Assertions.assertNotNull(snsRequest.getEventHeader().getEventContext());
        assertEquals(UUID.fromString("70d2d81f-bb68-4987-892a-4069a526ab94"), snsRequest.getEventHeader().getTransactionId()
        );
    }

    @Test
    void handleRequest_ExtractEORRequest() throws JsonProcessingException {
        mockStatic.when(() -> CMDSCommonUtils.getDataFromClaims("token", PARTNER_CODE)).thenReturn("IDP");

        BaseEvent<BaseHeader> requestEvent = orsRequestEvent;

        final RequestBodyToSNS snsRequest = eventReceiver.extractRequestFrom(
                requestEvent,
                transactionId,
                getMapper()
        );

        Assertions.assertNotNull(snsRequest);
        assertEquals("/v1/booking/eor", snsRequest.getEventHeader().getResource());
        assertEquals("IDP", snsRequest.getEventHeader().getPartnerCode());
        Assertions.assertNotNull(snsRequest.getEventHeader().getEventContext());
        assertEquals(
                UUID.fromString("70d2d81f-bb68-4987-892a-4069a526ab94"),
                snsRequest.getEventHeader().getTransactionId()
        );
    }


    @Test
    void handleRequest_ExtractRequest_Test_throw_IllegalParameterException()
            throws JsonProcessingException
    {
        BaseEvent<BaseHeader> requestEvent = orsRequestEvent;
        requestEvent.getEventHeader().setXaccessToken(null);

        Executable executable = () -> eventReceiver.extractRequestFrom(
                requestEvent,
                transactionId,
                getMapper()
        );
        assertThrows(InvalidParameterException.class, executable);
    }

    @Test
    void handleRequest_ExtractRequest_InvalidParameterExceptionTest()
            throws JsonProcessingException
    {
        try (MockedStatic<UUID> mockedStaticUUID = Mockito.mockStatic(UUID.class)) {
            mockedStaticUUID.when(UUID::randomUUID).thenReturn(defaultUuid);

            BaseEvent<BaseHeader> event = orsRequestEvent;
            event.getEventHeader().setCorrelationId(UUID.randomUUID());

            mockStatic.when(() -> CMDSCommonUtils.getDataFromClaims("TOKEN", PARTNER_CODE)).thenReturn("");
            GateWayResponseEntity responseEntity = eventReceiver.handleRequest(event,context);
            assertEquals(HttpStatus.SC_FORBIDDEN , responseEntity.getStatusCode());

        }
    }

    @Test
    void handleRequest_ExpectStatusToBeAccepted() throws JsonProcessingException {
        doReturn("IDP").when(eventReceiver).getPartnerCode(any());

        snsClientStatic.when(SNSClientConfig::getSNSClient).thenReturn(mock(AmazonSNS.class));

        final GateWayResponseEntity response = eventReceiver.handleRequest(
                orsRequestEvent,
                context
        );
        Assertions.assertNotNull(response);
        assertEquals(HttpStatus.SC_ACCEPTED, response.getStatusCode());
        Map<String,String> header=null;
        assertEquals(header, response.getHeaders());
    }


    @Test
    void RequestBodyToSNS_PublishMessage_SuccessfulTest() throws JsonProcessingException {
        BaseEvent<BaseHeader> requestEvent = orsRequestEvent;

        snsClientStatic.when(SNSClientConfig::getSNSClient).thenReturn(orsTopicSNSClient);

        RequestBodyToSNS snsRequest = new RequestBodyToSNS(
                requestEvent.getEventHeader(),
                requestEvent.getEventBody(),
                null
        );

        final GateWayResponseEntity response = eventReceiver.publishRequestBodyToSNS(
                incidentRequestEvent,
                snsRequest,
                "123",
                getMapper(),
                "234"
        );
        Assertions.assertNotNull(response);
        assertEquals(HttpStatus.SC_ACCEPTED, response.getStatusCode());
    }

    @Test
    void RequestBodyToSNS_PublishMessage_InvalidParameterExceptionTest()
            throws JsonProcessingException, InvalidParameterException
    {
        BaseEvent<BaseHeader> requestEvent = orsRequestEvent;

        snsClientStatic.when(SNSClientConfig::getSNSClient).thenReturn(orsTopicSNSClient);

        final RequestBodyToSNS snsRequest = new RequestBodyToSNS(
                requestEvent.getEventHeader(),
                requestEvent.getEventBody(),
                null
        );

        final String externalTransactionId = requestEvent.getEventHeader().getCorrelationId().toString();

        ObjectMapper mapper = getMapper();

        doThrow(InvalidParameterException.class)
                .when(eventReceiver)
                .buildAndPublishRequest(snsRequest, transactionId, externalTransactionId, mapper ,requestEvent);

        final GateWayResponseEntity response = eventReceiver.publishRequestBodyToSNS(
                requestEvent,
                snsRequest,
                transactionId,
                mapper,
                externalTransactionId
        );
        Assertions.assertNotNull(response);
        assertEquals(HttpStatus.SC_FORBIDDEN, response.getStatusCode());
    }

    @Test
    void RequestBodyToSNS_PublishMessage_JSonProcessingExceptionTest()
            throws JsonProcessingException
    {
        when(eventReceiver.getTopic()).thenReturn("test value");
        BaseEvent<BaseHeader> requestEvent = orsRequestEvent;

        snsClientStatic.when(SNSClientConfig::getSNSClient).thenReturn(orsTopicSNSClient);

        final RequestBodyToSNS snsRequest = new RequestBodyToSNS(
                requestEvent.getEventHeader(),
                requestEvent.getEventBody(),
                null
        );

        doThrow(JsonProcessingException.class).when(eventReceiver).generateResponse(any(), any());

        final GateWayResponseEntity response = eventReceiver.publishRequestBodyToSNS(
                requestEvent,
                snsRequest,
                transactionId,
                getMapper(),
                requestEvent.getEventHeader().getCorrelationId().toString()
        );
        Assertions.assertNotNull(response);
        assertEquals(HttpStatus.SC_BAD_REQUEST, response.getStatusCode());
    }

    @Test
    void generateErrorResponse_Test() throws JsonProcessingException {
        BaseEvent<BaseHeader> eorRequestEvent = orsRequestEvent;
        final Exception exception = new Exception();
        final GateWayResponseEntity response = eventReceiver.generateErrorResponse(
                eorRequestEvent,
                exception,
                getMapper(),
                ErrorTypeEnum.VALIDATION
        );
        Assertions.assertNotNull(response);
        assertEquals(HttpStatus.SC_BAD_REQUEST, response.getStatusCode());
        assertEquals(false, response.isBase64Encoded());
    }


    @Test
    void generateResponse_Success() throws JsonProcessingException {
        final GateWayResponseEntity response = eventReceiver.generateResponse(transactionId, getMapper());
        Assertions.assertNotNull(response.getBody());
        assertEquals(
                "{\"transactionId\":\"70d2d81f-bb68-4987-892a-4069a526ab94\"}", response.getBody());
    }


    @Test
    void whenBuildTopicArnIsCalledThenReturnWrongTopicArn() {
        String expectedTopicArn = "arn:aws:sns:null:null:ielts-cmds-null-sns-RecognisingOrganisationSelectionChangedByTestTakerV1-topic-out";
        String actualTopicArn = eventReceiver.buildTopicArn("RecognisingOrganisationSelectionChangedByTestTaker");
        assertEquals(expectedTopicArn, actualTopicArn);
    }

    @Test
    void whenBuildTopicArnIsCalledThenReturnTopicArn() {
        env.set(AWS_REGION, "eu-west-2");
        env.set(AWS_ACCOUNT_ID, "036220108529");
        env.set(AWS_ENV, "sandbox");
        String expectedTopicArn = "arn:aws:sns:eu-west-2:036220108529:ielts-cmds-sandbox-sns-RecognisingOrganisationSelectionChangedByTestTakerV1-topic-out";
        String actualTopicArn = eventReceiver.buildTopicArn("RecognisingOrganisationSelectionChangedByTestTaker");
        assertEquals(expectedTopicArn, actualTopicArn);
    }

    @Test
    void whenBuildTopicArnIsCalledThenReturnValidTopicArn() {
        env.set(AWS_REGION, "eu-west-2");
        env.set(AWS_ACCOUNT_ID, "036220108529");
        env.set(AWS_ENV, "sandbox");
        String expectedTopicArn = "arn:aws:sns:eu-west-2:036220108529:ielts-cmds-sandbox-sns-RecognisingOrganisationSelectionChangedByTestTakerV1-topic-out";
        String actualTopicArn = eventReceiver.buildTopicArn("RecognisingOrganisationSelectionChangedByTestTakerV1");
        assertEquals(expectedTopicArn, actualTopicArn);
    }

    @Test
    void whenGetEnvVarByKeyIsCalledThenReturnEnvVarValue() {
        env.set(AWS_ACCOUNT_ID, "036220108529");
        String expectedAwsAccountId = "036220108529";
        String actualAwsAccountId = eventReceiver.getEnvVarByKey(AWS_ACCOUNT_ID);
        assertEquals(expectedAwsAccountId, actualAwsAccountId);
    }

    @Test
    void whenBuildAndPublishRequestIsCalledThenShouldCallPublishToCommonTopic() throws JsonProcessingException {
        final BaseEvent<BaseHeader> requestEvent = orsRequestEvent;
        final String transactionId = UUID.randomUUID().toString();
        final String correlationId = UUID.randomUUID().toString();
        final ArgumentCaptor<PublishRequest> publishRequestArgumentCaptor = ArgumentCaptor.forClass(PublishRequest.class);
        final ArgumentCaptor<String> transactionIdCaptor = ArgumentCaptor.forClass(String.class);
        final ArgumentCaptor<String> correlationIdCaptor = ArgumentCaptor.forClass(String.class);
        final RequestBodyToSNS snsRequest = new RequestBodyToSNS(
                requestEvent.getEventHeader(),
                requestEvent.getEventBody(),
                null
        );
        PublishRequest expectedPublishRequest = new PublishRequest();
        expectedPublishRequest.setMessage(getMapper().writeValueAsString(snsRequest));
        expectedPublishRequest.setMessageAttributes(eventReceiver.getMessageAttributes(requestEvent));
        expectedPublishRequest.setTargetArn("test value");

        snsClientStatic.when(SNSClientConfig::getSNSClient).thenReturn(orsTopicSNSClient);

        eventReceiver.buildAndPublishRequest(snsRequest, transactionId, correlationId,getMapper(), requestEvent);

        verify(eventReceiver, times(1)).publishToCommonTopic(publishRequestArgumentCaptor.capture(), transactionIdCaptor.capture(), correlationIdCaptor.capture());
        assertEquals(expectedPublishRequest, publishRequestArgumentCaptor.getValue());
        assertEquals(transactionId, transactionIdCaptor.getValue());
        assertEquals(correlationId, correlationIdCaptor.getValue());
    }

    @Test
    void whenGetPublishRequestIsCalledThenShouldReturnPublishRequest() throws JsonProcessingException {
        BaseEvent<BaseHeader> requestEvent = orsRequestEvent;

        final RequestBodyToSNS snsRequest = new RequestBodyToSNS(
                requestEvent.getEventHeader(),
                requestEvent.getEventBody(),
                null
        );
        PublishRequest expectedPublishRequest = new PublishRequest();
        expectedPublishRequest.setMessage(getMapper().writeValueAsString(snsRequest));
        expectedPublishRequest.setTargetArn("test");
        expectedPublishRequest.setMessageAttributes(eventReceiver.getMessageAttributes(requestEvent));
        PublishRequest actualPublishRequest = eventReceiver.getPublishRequest(snsRequest, getMapper(), requestEvent, "test");
        assertEquals(expectedPublishRequest, actualPublishRequest);
    }

    @Test
    void WhenDedicatedTopicIsNotAvailableThenShouldPublishEventToCommonTopic() throws JsonProcessingException {
        PublishRequest publishRequest = new PublishRequest();
        when(eventReceiver.getTopic()).thenReturn("test value");
        BaseEvent<BaseHeader> requestEvent = orsRequestEvent;
        ArgumentCaptor<PublishRequest> publishRequestArgumentCaptor = ArgumentCaptor.forClass(PublishRequest.class);

        snsClientStatic.when(SNSClientConfig::getSNSClient).thenReturn(orsTopicSNSClient);

        final RequestBodyToSNS snsRequest = new RequestBodyToSNS(
                requestEvent.getEventHeader(),
                requestEvent.getEventBody(),
                null
        );
        doThrow(NotFoundException.class).when(eventReceiver).publishToDedicatedTopic(ArgumentMatchers.any());
        final GateWayResponseEntity response = eventReceiver.publishRequestBodyToSNS(
                requestEvent,
                snsRequest,
                transactionId,
                getMapper(),
                requestEvent.getEventHeader().getCorrelationId().toString()
        );
        Executable executable = () -> eventReceiver.publishToDedicatedTopic(publishRequest);
        Assertions.assertNotNull(response);
        assertThrows(NotFoundException.class, executable);
        assertEquals(HttpStatus.SC_ACCEPTED, response.getStatusCode());
        verify(eventReceiver, times(1)).publishToCommonTopic(publishRequestArgumentCaptor.capture(), ArgumentMatchers.any(), ArgumentMatchers.any());
    }

    @Test
    void WhenDedicatedTopicIsAvailableThenShouldPublishEventToCommonAndDedicatedTopic() throws JsonProcessingException {
        when(eventReceiver.getTopic()).thenReturn("test value");
        BaseEvent<BaseHeader> requestEvent = orsRequestEvent;
        ArgumentCaptor<PublishRequest> publishRequestArgumentCaptor = ArgumentCaptor.forClass(PublishRequest.class);
        snsClientStatic.when(SNSClientConfig::getSNSClient).thenReturn(orsTopicSNSClient);

        final RequestBodyToSNS snsRequest = new RequestBodyToSNS(
                requestEvent.getEventHeader(),
                requestEvent.getEventBody(),
                null
        );
        final GateWayResponseEntity response = eventReceiver.publishRequestBodyToSNS(
                requestEvent,
                snsRequest,
                transactionId,
                getMapper(),
                requestEvent.getEventHeader().getCorrelationId().toString()
        );
        Assertions.assertNotNull(response);
        assertEquals(HttpStatus.SC_ACCEPTED, response.getStatusCode());
        verify(eventReceiver, times(1)).publishToCommonTopic(publishRequestArgumentCaptor.capture(), ArgumentMatchers.any(), ArgumentMatchers.any());
        verify(eventReceiver, times(1)).publishToDedicatedTopic(publishRequestArgumentCaptor.capture());
    }

    @AfterEach
    void cleanUp() {
        mockStatic.close();
        snsClientStatic.close();
    }

    private ObjectMapper getMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
        objectMapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        objectMapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        objectMapper.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
        objectMapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
        objectMapper
                .registerModule(new ParameterNamesModule())
                .registerModule(new Jdk8Module())
                .registerModule(new JavaTimeModule());
        objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        return objectMapper;
    }

}
