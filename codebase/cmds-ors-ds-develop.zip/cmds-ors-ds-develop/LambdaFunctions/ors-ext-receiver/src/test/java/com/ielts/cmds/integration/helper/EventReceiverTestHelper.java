package com.ielts.cmds.integration.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.ors.common.enums.BookingDetailStatusEnum;
import com.ielts.cmds.ors.common.enums.ConfirmationStatusEnum;
import com.ielts.cmds.ors.common.enums.ExternalIncidentStatusEnum;
import com.ielts.cmds.ors.common.enums.IdentityVerificationStatusEnum;
import com.ielts.cmds.ors.common.in.model.booking.*;
import com.ielts.cmds.ors.common.in.model.ri.CommentDetailsV1;
import com.ielts.cmds.ors.common.in.model.ri.CommentsV1;
import com.ielts.cmds.ors.common.in.model.ri.IncidentDetailsV1;
import com.ielts.cmds.ors.common.in.model.ri.IncidentV1;
import com.ielts.cmds.ors.common.in.model.rm.EorLine;
import com.ielts.cmds.ors.common.in.model.rm.EorRequest;
import com.ielts.cmds.ors.common.out.model.OrganisationNodeV1ORS;
import com.ielts.cmds.ors.common.out.model.OrganisationSelectionNodeV1ORS;
import com.ielts.cmds.ors.common.out.model.OrganisationSelectionORS;
import com.ielts.cmds.ors.common.out.model.SelectionNodeV1ORS;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import static com.ielts.cmds.integration.constants.ReceiverConstants.*;
import static com.ielts.cmds.ors.common.enums.BookingLineStatusEnum.ACTIVE;
import static com.ielts.cmds.ors.common.enums.BookingStatusEnum.PAID;

public class EventReceiverTestHelper {
    public static BaseEvent<BaseHeader> getRequestEvent() throws JsonProcessingException {
        final BaseEvent<BaseHeader> rmRequestEvent = new BaseEvent<>();

        final BaseHeader eventHeader = getCMDSCustomHeader();

        final  EorRequest rmRequestBody = getORSRequestEventBody();

        setORSRequestEvent(rmRequestEvent, eventHeader, rmRequestBody);
        return rmRequestEvent;
    }

    private static void setORSRequestEvent(
            final BaseEvent<BaseHeader> orsRequestEvent,
            final BaseHeader eventHeader,
            final EorRequest orsEventBody
    ) throws JsonProcessingException
    {
        final ObjectMapper objectMapper = new ObjectMapper();
        final String jsonString = objectMapper.writeValueAsString(orsEventBody);
        orsRequestEvent.setEventBody(jsonString);
        orsRequestEvent.setEventHeader(eventHeader);
        orsRequestEvent.getEventHeader().setResource("/v1/booking/eor");
        orsRequestEvent.getEventHeader().setEventName("EorRequestedByOrs");

    }

    public static EorRequest getORSRequestEventBody() {
        final EorRequest details = new EorRequest();
        details.setExternalBookingUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46598"));
        details.setExternalEorId("externaleorid123");
        details.setExternalEorUuid(UUID.fromString("64078ad4-7233-49de-b0dd-1e30bb2fc343"));
        List<EorLine> eorlinelist= new ArrayList<>();
        EorLine eorLine=new EorLine();
        eorLine.setExternalBookingLineUuid(UUID.fromString("8a0d5e13-472a-4e22-8d97-fbebccaecdad"));
        eorLine.setExternalEorLineUuid(UUID.fromString("f685406d-d660-47d5-a1ad-5aa68f7957e6"));
        eorlinelist.add(eorLine);
        details.setEorLines(eorlinelist);
        return details;
    }

    private static BaseHeader getBaseHeader() {
        final BaseHeader eventHeader = new BaseHeader();
        eventHeader.setCallbackURL("callbackURL");
        eventHeader.setCorrelationId(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
        eventHeader.setXaccessToken("token");
        eventHeader.setPartnerCode("IDP");
        LocalDateTime eventDateTime = LocalDateTime.parse(
                "2020-09-04T08:45:32.987Z",
                DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
        );
        eventHeader.setEventDateTime(eventDateTime);
        eventHeader.setEventContext(new HashMap<>());
        return eventHeader;
    }

    private static BaseHeader getCMDSCustomHeader() {
        final BaseHeader eventHeader = new BaseHeader();
        eventHeader.setCallbackURL("callbackURL");
        eventHeader.setOperationType("PUT");
        eventHeader.setResource("/v1/booking/eor");
        eventHeader.setCorrelationId(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
        eventHeader.setXaccessToken("token");
        LocalDateTime eventDateTime = LocalDateTime.parse(
                "2020-09-04T08:45:32.987Z",
                DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
        );
        eventHeader.setEventDateTime(eventDateTime);
        eventHeader.setEventContext(new HashMap<>());
        return eventHeader;
    }

    public static BaseEvent<BaseHeader> getIncidentRequestEvent() throws JsonProcessingException {
        final BaseEvent<BaseHeader> incidentRequestEvent = new BaseEvent<>();

        final BaseHeader eventHeader = getCMDSCustomHeader();

        final  IncidentV1 incidentRequestBody = getIncidentRequestEventBody();
        setIncidentRequestEvent(incidentRequestEvent, eventHeader, incidentRequestBody);
        return incidentRequestEvent;
    }

    public static BaseEvent<BaseHeader> getRefundRequestedEvent() throws JsonProcessingException {
        final BaseEvent<BaseHeader> refundRequestedEvent = new BaseEvent<>();
        final BaseHeader eventHeader = getCMDSCustomHeader();
        eventHeader.getEventContext().put("externalBookingUuid", "a6aec3ef-fd32-4aa0-b3dd-6e6ede139b43");
        final RegistrationDetails bookingBody = getBookingChangeRequestBody();
        bookingBody.setAgentName("new name");
        setRefundRequestedEvent(refundRequestedEvent, eventHeader, bookingBody);
        return refundRequestedEvent;
    }

    public static BaseEvent<BaseHeader> getRecognisingOrganisationSelectionChangedEvent() throws JsonProcessingException {
        final BaseEvent<BaseHeader> organisationSelectionEvent = new BaseEvent<>();
        final BaseHeader eventHeader = getBaseHeader();
        final OrganisationSelectionNodeV1ORS organisationSelection = getOrganisationSelectionBody();
        setOrganisationSelectionEvent(organisationSelectionEvent, eventHeader, organisationSelection);
        return organisationSelectionEvent;
    }

    public static BaseEvent<BaseHeader> getOrganisationSelectionWithdrawRequestedEvent() throws JsonProcessingException {
        final BaseEvent<BaseHeader> organisationSelectionWithdrawEvent = new BaseEvent<>();
        final BaseHeader eventHeader = getBaseHeader();
        final OrganisationSelectionORS organisationSelection = getOrganisationSelectionWithdrawBody();
        setOrganisationSelectionWithdrawEvent(organisationSelectionWithdrawEvent, eventHeader, organisationSelection);
        return organisationSelectionWithdrawEvent;
    }

    private static void setIncidentRequestEvent(
            final BaseEvent<BaseHeader> orsRequestEvent,
            final BaseHeader eventHeader,
            final IncidentV1 orsEventBody
    ) throws JsonProcessingException
    {
        final ObjectMapper objectMapper = new ObjectMapper();
        final String jsonString = objectMapper.writeValueAsString(orsEventBody);
        orsRequestEvent.setEventBody(jsonString);
        orsRequestEvent.setEventHeader(eventHeader);
        orsRequestEvent.getEventHeader().setResource("/v1/incident/receivespeakingincident");
        orsRequestEvent.getEventHeader().setEventName("SpeakingIncidentRequestedByOrs");
    }

    private static void setRefundRequestedEvent(
            final BaseEvent<BaseHeader> refundRequestedEvent,
            final BaseHeader header,
            final RegistrationDetails details
    ) throws JsonProcessingException {
        final ObjectMapper mapper = new ObjectMapper();
        final String jsonString = mapper.writeValueAsString(details);
        refundRequestedEvent.setEventBody(jsonString);
        refundRequestedEvent.setEventHeader(header);
        refundRequestedEvent.getEventHeader().setEventName(REFUND_REQUESTED_FROM_ORS);
    }

    private static void setOrganisationSelectionEvent(
            final BaseEvent<BaseHeader> organisationSelectionEvent,
            final BaseHeader header,
            final OrganisationSelectionNodeV1ORS details
    ) throws JsonProcessingException {
        final ObjectMapper mapper = new ObjectMapper();
        final String jsonString = mapper.writeValueAsString(details);
        organisationSelectionEvent.setEventBody(jsonString);
        organisationSelectionEvent.setEventHeader(header);
        organisationSelectionEvent.getEventHeader().setEventName(ORGANISATION_SELECTION_CHANGED_FROM_ORS);
    }

    private static void setOrganisationSelectionWithdrawEvent(
            final BaseEvent<BaseHeader> organisationSelectionEvent,
            final BaseHeader header,
            final OrganisationSelectionORS details
    ) throws JsonProcessingException {
        final ObjectMapper mapper = new ObjectMapper();
        final String jsonString = mapper.writeValueAsString(details);
        organisationSelectionEvent.setEventBody(jsonString);
        organisationSelectionEvent.setEventHeader(header);
        organisationSelectionEvent.getEventHeader().setEventName(ORGANISATION_SELECTION_WITHDRAW_REQUESTED_FROM_ORS);
    }

    public static IncidentV1 getIncidentRequestEventBody() {
        final IncidentV1 details = new IncidentV1();
        IncidentDetailsV1 incidentDetails = new IncidentDetailsV1();
        incidentDetails.setExternalIncidentStatus(ExternalIncidentStatusEnum.CLEARED);
        details.setIncidentDetails(incidentDetails);
        CommentsV1 comments= new CommentsV1();

        CommentDetailsV1 commentDetails=new CommentDetailsV1();
        commentDetails.setComment("mockcomment");
        commentDetails.setCommentEnteredBy("mockname");
        comments.add(commentDetails);
        incidentDetails.setComments(comments);
        details.setIncidentDetails(incidentDetails);

        return details;
    }

    public static OrganisationSelectionNodeV1ORS getOrganisationSelectionBody() {
        OrganisationSelectionNodeV1ORS organisationSelectionNodeV1ORS = new OrganisationSelectionNodeV1ORS();
        organisationSelectionNodeV1ORS.setExternalBookingUuid(UUID.fromString("d17cffde-dc33-4ae3-a6ae-180390f38b79"));
        organisationSelectionNodeV1ORS.setExternalBookingReference("external booking reference");

        SelectionNodeV1ORS selectionNodeV1ORS = new SelectionNodeV1ORS();
        selectionNodeV1ORS.setSelectionUuid(UUID.fromString("d17cffde-dc33-4ae3-a6ae-180390f38b79"));
        selectionNodeV1ORS.setCaseNumber("case number");
        selectionNodeV1ORS.setConfirmationStatus(ConfirmationStatusEnum.CONFIRMED);
        selectionNodeV1ORS.setExternalSelectionUuid(UUID.fromString("d17cffde-dc33-4ae3-a6ae-180390f38b79"));
        selectionNodeV1ORS.setPersonDepartment("person department");
        OrganisationNodeV1ORS organisationNodeV1ORS = new OrganisationNodeV1ORS();
        organisationNodeV1ORS.setOrganisationUuid(UUID.fromString("d17cffde-dc33-4ae3-a6ae-180390f38b79"));

        selectionNodeV1ORS.setOrganisation(organisationNodeV1ORS);

        organisationSelectionNodeV1ORS.selection(selectionNodeV1ORS);

        return organisationSelectionNodeV1ORS;
    }

    public static OrganisationSelectionORS getOrganisationSelectionWithdrawBody() {
        OrganisationSelectionORS organisationSelectionORS = new OrganisationSelectionORS();

        organisationSelectionORS.setExternalSelectionUuid(UUID.fromString("d17cffde-dc33-4ae3-a6ae-180390f38b79"));

        return organisationSelectionORS;
    }

    public static RegistrationDetails getBookingChangeRequestBody() {
        RegistrationDetails details = new RegistrationDetails();
        details.setAgentName("TestCheck");
        details.setExternalBookingUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46598"));
        details.setBookingDetailStatus(BookingDetailStatusEnum.COMPLETE);
        details.setProductUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
        details.setConsentGiven(true);
        details.setPartnerCode("IDP");
        details.setLocationUuid(UUID.fromString("742d0a15-6238-4be0-b893-38122603c5a8"));
        LocalDate testDate = LocalDate.parse("2020-09-29", DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        details.setTestDate(testDate);
        details.setBookingStatus(PAID);

        MarketingInfo info = getMarketingInfo();
        details.setMarketingInfo(info);

        TestTakerDetails ttDetails = getTestTakerDetails();

        TestTakerAddress ttAddress = getTestTakerAddress();
        ttDetails.setAddress(ttAddress);
        details.setTestTaker(ttDetails);

        List<BookingLine> bookingLineList = getBookingLines();
        details.setBookingLines(bookingLineList);

        return details;
    }

    private static MarketingInfo getMarketingInfo() {
        MarketingInfo info = new MarketingInfo();
        info.setApplyingToCountryUuid(UUID.fromString("d17cffde-dc33-4ae3-a6ae-180390f38b79"));
        info.setApplyingToCountryIso3code("AUS");
        info.setCountryApplyingToOther("GBR");
        info.setEducationLevelUuid(UUID.fromString("ba7e70a1-030f-4ed2-9e4c-97e1fe3bb43a"));
        info.setOccupationSectorUuid(UUID.fromString("5ad0193f-69b0-45bd-9e8a-ce53e6f8bd24"));
        info.setReasonForTestUuid(UUID.fromString("5db03c10-7c33-4ebb-b8ec-aa634236307a"));
        info.setOccupationLevelOther("4faad5f5-97e1-4d64-bec5-7d50bc0acf49");
        info.setReasonForTestOther("other");
        info.setYearsOfStudy(4);
        info.setOccupationSectorOther("");
        info.setCurrentEnglishStudyPlace("");
        info.setOccupationLevelUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
        return info;
    }

    private static TestTakerDetails getTestTakerDetails() {
        TestTakerDetails details = new TestTakerDetails();
        details.setExternalTestTakerUuid(
                UUID.fromString("5432081f-453f-4a45-adf9-824531d8e2dc"));
        details.setLastName("Davies");
        LocalDate expiryDate = LocalDate.parse("2020-09-29", DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        details.setIdentityExpiryDate(expiryDate);
        details.setNotes("string");
        details.setIdentityVerificationStatus(IdentityVerificationStatusEnum.INCOMPLETE);
        details.setSex("M");
        details.setSexUuid(UUID.fromString("8b66a4df-c7cd-423f-b7d5-981139f4dfeb"));
        details.setNationalityUuid(UUID.fromString("0d9dbdd5-f1e6-4753-b7a9-573a898cd11c"));
        details.setMobile("1234567890");
        details.setLanguageUuid(UUID.fromString("1ef783e4-c4a0-4e0c-95ed-9ea35dca30f3"));
        details.setPhone("+1234566778");
        details.setTitle("cef4fcb1-2bd2-51f3-889d-abd47d775668");
        details.setFirstName("Alan");
        details.setIdentityNumber("AB12314");
        details.setIdentityTypeUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
        LocalDate dob = LocalDate.parse("2020-09-29", DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        details.setBirthDate(dob);
        details.setIdentityIssuingAuthority("string");
        details.setEmail("alan@gmail.com");
        return details;
    }

    private static TestTakerAddress getTestTakerAddress() {
        TestTakerAddress ttAddress = new TestTakerAddress();
        ttAddress.setCity("Melbourne");
        ttAddress.setPostalCode("1234");
        ttAddress.setAddressLine1("15");
        ttAddress.setAddressLine1("King Street");
        ttAddress.setAddressLine3("");
        ttAddress.setAddressLine4("");
        ttAddress.setStateTerritoryUuid(UUID.fromString("5432081f-453f-4a45-adf9-824531d8e2dc"));
        ttAddress.setCountryUuid(UUID.fromString("d711ad75-3917-4b3a-8f7a-929a1fb1ad6f"));
        ttAddress.setCountryIso3Code("AND");
        return ttAddress;
    }

    private static List<BookingLine> getBookingLines() {
        BookingLine bookingLines = new BookingLine();

        bookingLines.setExternalBookingLineUuid(
                UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672")
        );
        bookingLines.setExtraTimeMinutes(15);
        bookingLines.setProductUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
        LocalDateTime startTimeLocal = LocalDateTime.parse(
            "2020-09-29T21:00:35.723Z",
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
        );
        bookingLines.setStartDateTime(startTimeLocal);
        LocalDateTime startTimeUTC = LocalDateTime.parse(
            "2020-09-29T15:30:35.723Z",
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
        );
        bookingLines.setStartDateTime(startTimeUTC);
        bookingLines.setBookingLineStatus(ACTIVE);
        List<BookingLine> bookingLineList = new ArrayList<>();
        bookingLineList.add(bookingLines);
        return bookingLineList;
    }
}
