package com.ielts.cmds.integration.config;

import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.AmazonSNSClient;

public class SNSClientConfig {

    public static AmazonSNS getSNSClient() {
        return AmazonSNSClient.builder().withRegion(System.getenv("AWS_REGION")).build();
    }
    private  SNSClientConfig() {}
}
