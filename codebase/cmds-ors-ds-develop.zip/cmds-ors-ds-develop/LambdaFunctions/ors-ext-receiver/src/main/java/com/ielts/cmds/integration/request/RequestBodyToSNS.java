package com.ielts.cmds.integration.request;

import com.ielts.cmds.infrastructure.event.BaseHeader;
import lombok.AllArgsConstructor;
import lombok.Getter;
import javax.validation.Valid;

@Getter
@AllArgsConstructor
public class RequestBodyToSNS {

    @Valid private final BaseHeader eventHeader;
    private final String eventBody;
    private final String eventErrors;

}
