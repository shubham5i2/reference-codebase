package com.ielts.cmds.integration;


import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.InvalidParameterException;
import com.amazonaws.services.sns.model.MessageAttributeValue;
import com.amazonaws.services.sns.model.NotFoundException;
import com.amazonaws.services.sns.model.PublishRequest;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.CMDSExceptionUtils;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.logger.util.CMDSLambdaLoggerUtil;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.config.SNSClientConfig;
import com.ielts.cmds.integration.request.RequestBodyToSNS;
import com.ielts.cmds.integration.response.AcceptedResponse;
import com.ielts.cmds.integration.response.GateWayResponseEntity;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import static com.ielts.cmds.common.utils.CMDSCommonUtils.getDataFromClaims;
import static com.ielts.cmds.integration.constants.ReceiverConstants.*;

/**
 * This class serves the purpose fo handling ORS API Gateway requests and provide response to
 * Organisation API Gateway  and publish messages to Organisation inbound SNS topic
 */
@Slf4j
public class OrsExtReceiver {

    /**
     * @param eventReceived: request being received
     * @param context:       params of request
     * @return GatewayResponseEntity
     * @throws JsonProcessingException : exception
     */
    public GateWayResponseEntity handleRequest(
            final Object eventReceived,
            final Context context
    ) throws JsonProcessingException {
        final ObjectMapper objectMapper = getObjectMapper();
        GateWayResponseEntity gateWayResponseEntity;

        final String transactionId = UUID.randomUUID().toString();

        initializeLogger(transactionId, context);

        String correlationId = "";
        BaseEvent<BaseHeader> event = null;

        try {
            event = convertValue(objectMapper, eventReceived);

            if (event.getEventHeader().getCorrelationId() != null) {
                correlationId = event.getEventHeader().getCorrelationId().toString();
            }

            log.info("Event received in ORS-DS Mx : Ors-ext-receiver with metadata as {}",
                    objectMapper.writeValueAsString(event.getEventHeader()));

            final RequestBodyToSNS snsRequest = extractRequestFrom(event, transactionId, objectMapper);
            gateWayResponseEntity = publishRequestBodyToSNS(event, snsRequest, transactionId, objectMapper, correlationId);
        } catch (JsonProcessingException | IllegalArgumentException parsingException) {
            log.error("Parsing exception occurred: {} for correlationId: {} and transactionId: {}",
                    parsingException, correlationId, transactionId);

            gateWayResponseEntity = generateParsingErrorResponse(parsingException.getMessage(), objectMapper);
            return gateWayResponseEntity;
        } catch (InvalidParameterException invalidParameterException) {
            log.error("InvalidParameterException exception occurred: {} for correlationId: {} and transactionId: {}",
                    invalidParameterException, correlationId, transactionId);

            gateWayResponseEntity = generateErrorResponse(
                    Objects.requireNonNull(event),
                    invalidParameterException,
                    objectMapper,
                    ErrorTypeEnum.VALIDATION
            );

            gateWayResponseEntity.setStatusCode(HttpStatus.SC_FORBIDDEN);
            return gateWayResponseEntity;
        }

        log.info("Event being published from ORS-DS Mx : Ors-ext-receiver with metadata as {}",
                objectMapper.writeValueAsString(event.getEventHeader()));
        return gateWayResponseEntity;
    }

    /**
     * Method to extract request and perform JSON mapping
     *
     * @param event:
     * @param transactionId:
     * @return RequestBodyToSNS
     */
    protected RequestBodyToSNS extractRequestFrom(
            @Valid final BaseEvent<BaseHeader> event,
            final String transactionId,
            final ObjectMapper objectMapper
    )
            throws JsonProcessingException {
        final BaseHeader outHeaders = event.getEventHeader();

        final String partnerCode = getPartnerCode(event.getEventHeader().getXaccessToken());

        if (Objects.isNull(partnerCode)) {
            log.info("Partner code is null after extracting from JWT Token for a metadata {}",
                    objectMapper.writeValueAsString(event.getEventHeader()));
            throw new InvalidParameterException("Invalid access token");
        }
        outHeaders.setPartnerCode(partnerCode);

        log.debug("PartnerCode after extract:{} and transactionId {}",
                event.getEventHeader().getPartnerCode(), transactionId);

        switch (outHeaders.getEventName()) {
            case EVENTNAME_EOR_FROM_ORS:
                outHeaders.setEventName(EVENTNAME_EOR);
                break;
            case EVENTNAME_INCIDENT_FROM_ORS:
                outHeaders.setEventName(EVENTNAME_INCIDENT);
                break;
            case ORS_PHOTO_PROVIDED:
                outHeaders.setEventName(ORS_PHOTO_REQUESTED);
                break;
            case REFUND_REQUESTED_FROM_ORS:
                outHeaders.setEventName(REFUND_REQUESTED);
                break;
            case ORGANISATION_SELECTION_CHANGED_FROM_ORS:
                outHeaders.setEventName(RECOGNISING_ORGANISATION_SELECTION_CHANGED);
                break;
            case ORGANISATION_SELECTION_WITHDRAW_REQUESTED_FROM_ORS:
                outHeaders.setEventName(RECOGNISING_ORGANISATION_SELECTION_WITHDRAW_REQUESTED);
                break;
            default:
                log.debug("Invalid EventName: EventName does not exist");
                break;

        }

        outHeaders.setTransactionId(UUID.fromString(transactionId));

        final String eventBody = event.getEventBody();

        return new RequestBodyToSNS(outHeaders, eventBody, null);
    }

    /**
     * Method to publish message to SNS Topic
     *
     * @param event:
     * @param requestBodyToSNS:
     * @param transactionId:
     * @return gateWayResponseEntity
     */
    protected GateWayResponseEntity publishRequestBodyToSNS(
            @Valid final BaseEvent<BaseHeader> event,
            final RequestBodyToSNS requestBodyToSNS,
            final String transactionId,
            final ObjectMapper objectMapper,
            final String correlationId
    )
            throws JsonProcessingException {
        GateWayResponseEntity gateWayResponseEntity;

        try {
            buildAndPublishRequest(requestBodyToSNS, transactionId, correlationId, objectMapper, event);
            buildAndPublishDedicatedTopicRequest(requestBodyToSNS, objectMapper, event);
            gateWayResponseEntity = generateResponse(transactionId, objectMapper);
        } catch (InvalidParameterException invalidParameterException) {
            log.error("Invalid parameter exception occurred: {} for correlationId: {} and transactionId: {}",
                    invalidParameterException, correlationId, transactionId);
            log.info("Event being published from ORS-DS Mx : ors-ext-receiver with metadata as {} with error - Invalid parameter exception",
                    objectMapper.writeValueAsString(event.getEventHeader()));

            gateWayResponseEntity = generateErrorResponse(
                    event,
                    invalidParameterException,
                    objectMapper,
                    ErrorTypeEnum.ERROR
            );
            gateWayResponseEntity.setStatusCode(HttpStatus.SC_FORBIDDEN);
        } catch (JsonProcessingException jsonProcessingException) {
            log.error("Parsing exception occurred: {} for correlationId: {} and transactionId: {}",
                    jsonProcessingException, correlationId, transactionId);
            log.info("Event being published from ORS-DS Mx : ors-ext-receiver with metadata as {} with error - Json Processing exception",
                    objectMapper.writeValueAsString(event.getEventHeader()));
            gateWayResponseEntity = generateErrorResponse(event, jsonProcessingException, objectMapper, ErrorTypeEnum.VALIDATION);
        }
        return gateWayResponseEntity;
    }

    protected void buildAndPublishDedicatedTopicRequest(final RequestBodyToSNS requestBodyToSNS,
                                                        final ObjectMapper objectMapper,
                                                        @Valid final BaseEvent<BaseHeader> event) {
        final String constructedTopicArn = buildTopicArn(event.getEventHeader().getEventName());
        try {
            PublishRequest publishRequest = getPublishRequest(requestBodyToSNS, objectMapper, event, constructedTopicArn);
            publishToDedicatedTopic(publishRequest);
            log.info("Event {} being published successfully on dedicated topic {}", event.getEventHeader().getEventName(), constructedTopicArn);
        } catch (NotFoundException exception) {
            log.warn("Exception occurred while publishing event {}, dedicated topic not found {} ", event.getEventHeader().getEventName(), constructedTopicArn, exception.getMessage());
        } catch (JsonProcessingException e) {
            log.error("Exception occurred while publishing event {}", e.getMessage());
        }
    }

    protected void buildAndPublishRequest(final RequestBodyToSNS requestBodyToSNS,
                                          final String transactionId,
                                          final String correlationId,
                                          final ObjectMapper objectMapper,
                                          @Valid final BaseEvent<BaseHeader> event) throws JsonProcessingException {
        final String orsTopicArn = getTopic();
        PublishRequest publishRequest = getPublishRequest(requestBodyToSNS, objectMapper, event, orsTopicArn);
        publishToCommonTopic(publishRequest, transactionId, correlationId);
    }

    /**
     * @param requestBodyToSNS:
     * @param objectMapper:
     * @param event:
     * @param orsTopicArn:
     * @throws JsonProcessingException:
     */
    protected PublishRequest getPublishRequest(final RequestBodyToSNS requestBodyToSNS,
                                               final ObjectMapper objectMapper,
                                               @Valid final BaseEvent<BaseHeader> event,
                                               final String orsTopicArn) throws JsonProcessingException {

        final PublishRequest snsPublishRequest = new PublishRequest();
        final Map<String, MessageAttributeValue> messageAttributes = getMessageAttributes(event);
        final String stringRequestBodyToSNS = objectMapper.writeValueAsString(requestBodyToSNS);
        snsPublishRequest.setTargetArn(orsTopicArn);
        snsPublishRequest.setMessageAttributes(messageAttributes);
        snsPublishRequest.setMessage(stringRequestBodyToSNS);

        return snsPublishRequest;
    }

    /**
     * @param snsPublishRequest:
     **/
    protected void publishToDedicatedTopic(final PublishRequest snsPublishRequest) {
        final AmazonSNS orsTopicSNSClient = SNSClientConfig.getSNSClient();
        orsTopicSNSClient.publish(snsPublishRequest);
    }

    /**
     * @param snsPublishRequest:
     * @param transactionId:
     * @param correlationId:
     */
    protected void publishToCommonTopic(final PublishRequest snsPublishRequest,
                                        final String transactionId,
                                        final String correlationId) {
        final AmazonSNS orsTopicSNSClient = SNSClientConfig.getSNSClient();
        orsTopicSNSClient.publish(snsPublishRequest);

        log.debug("MESSAGE PUBLISHED for correlationId: {} ,transaction id: {} stringRequestBodyToSNS: {}",
                correlationId, transactionId, snsPublishRequest.getMessage());

        log.info("SNS complete MESSAGE PUBLISHED for transactionId : {} : {}", transactionId, snsPublishRequest);
    }

    protected Map<String, MessageAttributeValue> getMessageAttributes(
            final BaseEvent<? extends BaseHeader> baseEvent) {
        final Map<String, MessageAttributeValue> messageAttributes = new HashMap<>();

        messageAttributes.put(
                EVENTNAME,
                new MessageAttributeValue()
                        .withDataType(MSG_ATTR_DATA_TYPE)
                        .withStringValue(baseEvent.getEventHeader().getEventName()));
        return messageAttributes;
    }


    /**
     * Generate Response for API Gateway
     *
     * @param transactionId:
     */
    protected GateWayResponseEntity generateResponse(
            final String transactionId,
            final ObjectMapper objectMapper
    )
            throws JsonProcessingException {
        final GateWayResponseEntity gateWayResponseEntity = new GateWayResponseEntity();

        final AcceptedResponse responseBody = new AcceptedResponse(transactionId);

        gateWayResponseEntity.setStatusCode(HttpStatus.SC_ACCEPTED);
        gateWayResponseEntity.setBase64Encoded(Boolean.TRUE);
        gateWayResponseEntity.setBody(objectMapper.writeValueAsString(responseBody));
        return gateWayResponseEntity;
    }

    /**
     * Generate Error Response for API Gateway
     *
     * @param event:     event body
     * @param exception:
     */
    protected GateWayResponseEntity generateErrorResponse(
            @Valid final BaseEvent<BaseHeader> event,
            Exception exception,
            final ObjectMapper objectMapper,
            ErrorTypeEnum errorTypeEnum
    ) {
        final GateWayResponseEntity gateWayResponseEntity = new GateWayResponseEntity();
        gateWayResponseEntity.setStatusCode(HttpStatus.SC_BAD_REQUEST);

        ErrorDescription errorDescription = new ErrorDescription();
        errorDescription.setInterfaceName(ORS_EXT_RECEIVER);
        errorDescription.setType(errorTypeEnum);
        errorDescription.setErrorCode("");

        CMDSExceptionUtils.populateSourceInformation(
                errorDescription,
                exception.getMessage(),
                event.getEventHeader().getResource()
        );

        setBodyGateWayResponseEntity(gateWayResponseEntity, errorDescription, objectMapper);
        return gateWayResponseEntity;
    }


    /**
     * @param gateWayResponseEntity:
     * @param errorResponse:
     */
    protected void setBodyGateWayResponseEntity(
            final GateWayResponseEntity gateWayResponseEntity,
            final ErrorDescription errorResponse,
            final ObjectMapper objectMapper
    ) {
        try {
            gateWayResponseEntity.setBody(objectMapper.writeValueAsString(errorResponse));
        } catch (JsonProcessingException jsonProcessingException) {
            log.error("Parsing exception occurred in framing ErrorResponse: ", jsonProcessingException);
        }
    }

    protected ObjectMapper getObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
        objectMapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        objectMapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        objectMapper.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
        objectMapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
        objectMapper
                .registerModule(new ParameterNamesModule())
                .registerModule(new Jdk8Module())
                .registerModule(new JavaTimeModule());
        objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        return objectMapper;
    }

    protected void initializeLogger(final String transactionId, final Context context) {
        final CMDSLambdaLoggerUtil loggerUtil = new CMDSLambdaLoggerUtil();
        loggerUtil.initializeThreadContextMap(transactionId, ORS_LAMBDA, context.getAwsRequestId());
    }

    protected BaseEvent<BaseHeader> convertValue(ObjectMapper objectMapper, Object eventReceived) {
        return objectMapper.convertValue(eventReceived, new TypeReference<BaseEvent<BaseHeader>>() {
        });
    }

    private GateWayResponseEntity generateParsingErrorResponse(String exception, ObjectMapper objectMapper) {
        final GateWayResponseEntity gateWayResponseEntity = new GateWayResponseEntity();
        gateWayResponseEntity.setStatusCode(HttpStatus.SC_BAD_REQUEST);

        ErrorDescription errorDescription = new ErrorDescription();
        errorDescription.setInterfaceName(ORS_EXT_RECEIVER);
        errorDescription.setType(ErrorTypeEnum.ERROR);
        errorDescription.setErrorCode("");
        errorDescription.setMessage(exception);
        errorDescription.setTitle(PARSING_ERROR_EXCEPTION);

        setBodyGateWayResponseEntity(gateWayResponseEntity, errorDescription, objectMapper);
        return gateWayResponseEntity;
    }

    protected String getPartnerCode(String xaccessToken) {
        return getDataFromClaims(
                xaccessToken,
                PARTNER_CODE
        );
    }

    public String buildTopicArn(String eventName) {
        /*
         * Sample Arn:
         * arn:aws:sns:eu-west-2:xxxxxx:ielts-cmds-sandbox-sns-{eventName}Vx-topic-out
         **/
        String topicArn = String.join(COLON, TOPIC_ARN_PREFIX, getEnvVarByKey(AWS_REGION), getEnvVarByKey(AWS_ACCOUNT_ID), IELTS_CMDS) + HYPHEN +
                String.join(HYPHEN, getEnvVarByKey(AWS_ENV), SNS, eventName.concat(getVersion(eventName)), TOPIC_ARN_SUFFIX);
        log.debug("Constructed topic arn: {}", topicArn);

        return topicArn;
    }

    protected String getVersion(final String eventName) {
        if (eventName.matches(String.valueOf(CHECKS))) {
            return "";
        }
        return "V1";
    }

    protected String getEnvVarByKey(String key) {
        return System.getenv(key);
    }

    protected String getTopic() {
        return System.getenv(ORS_TOPIC_IN);
    }
}


