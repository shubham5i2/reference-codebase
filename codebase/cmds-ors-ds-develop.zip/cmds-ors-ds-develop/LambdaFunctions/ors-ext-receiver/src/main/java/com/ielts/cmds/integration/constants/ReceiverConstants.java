package com.ielts.cmds.integration.constants;

import java.util.regex.Pattern;

public class ReceiverConstants {
    private ReceiverConstants() {
    }

    public static final String ORS_TOPIC_IN = "ors_ext_topic_in_arn";
    public static final String ORS_LAMBDA = "ORS Lambda";
    public static final String ORS_EXT_RECEIVER = "ors-ext-receiver";
    public static final String PARTNER_CODE = "partnerCode";
    public static final String PARSING_ERROR_EXCEPTION = "Parsing error exception";
    public static final String EVENTNAME = "eventName";
    public static final String MSG_ATTR_DATA_TYPE = "String";
    public static final String EVENTNAME_EOR_FROM_ORS = "EorRequestedByOrs";
    public static final String EVENTNAME_INCIDENT_FROM_ORS = "SpeakingIncidentRequestedByOrs";
    public static final String EVENTNAME_EOR = "EorRequested";
    public static final String EVENTNAME_INCIDENT = "SpeakingIdandIncidentRaised";
    public static final String REFUND_REQUESTED_FROM_ORS = "RefundRequestedByOrs";
    public static final String REFUND_REQUESTED = "RefundRequested";
    public static final String ORS_PHOTO_PROVIDED = "OrsPhotoProvided";
    public static final String ORS_PHOTO_REQUESTED = "OrsPhotoRequested";
    public static final String ORGANISATION_SELECTION_CHANGED_FROM_ORS = "OrganisationSelectionChangedByTestTaker";
    public static final String RECOGNISING_ORGANISATION_SELECTION_CHANGED = "RecognisingOrganisationSelectionChangedByTestTaker";
    public static final String ORGANISATION_SELECTION_WITHDRAW_REQUESTED_FROM_ORS = "OrganisationSelectionWithdrawRequestedByTestTaker";
    public static final String RECOGNISING_ORGANISATION_SELECTION_WITHDRAW_REQUESTED = "RecognisingOrganisationSelectionWithdrawRequestedByTestTaker";

    public static final String AWS_REGION = "aws_region";
    public static final String AWS_ACCOUNT_ID = "aws_account_id";
    public static final String AWS_ENV = "aws_env";

    public static final String TOPIC_ARN_PREFIX = "arn:aws:sns";
    public static final String IELTS_CMDS = "ielts-cmds";
    public static final String TOPIC_ARN_SUFFIX = "topic-out";
    public static final String SNS = "sns";
    public static final String COLON = ":";
    public static final String HYPHEN = "-";

    public static final Pattern CHECKS = Pattern.compile(".*V\\d+$");

}
