package com.ielts.cmds.integration.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Map;


@Getter
@Setter
@NoArgsConstructor
public class GateWayResponseEntity {
    private int statusCode;
    private boolean isBase64Encoded;
    private Map<String, String> headers;
    private Object body;
}
