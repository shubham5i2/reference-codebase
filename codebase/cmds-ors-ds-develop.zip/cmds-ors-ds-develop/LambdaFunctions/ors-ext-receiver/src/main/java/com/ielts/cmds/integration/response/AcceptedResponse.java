package com.ielts.cmds.integration.response;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class AcceptedResponse {

    private final String transactionId;

}
