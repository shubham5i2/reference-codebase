package com.ielts.cmds.integration.model.withdraw;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ielts.cmds.rd.domain.model.enums.ConfirmationStatusEnum;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@NoArgsConstructor
public class Selection {

 private UUID externalSelectionUuid;

 private ConfirmationStatusEnum confirmationStatus;

 @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
 private String confirmationStatusChangedDateTime;

}