package com.ielts.cmds.integration.mapper;

import com.ielts.cmds.integration.model.withdraw.OrganisationSelectionWithdrawal;
import com.ielts.cmds.integration.model.withdraw.Selection;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;

public class EventMapper {

    public OrganisationSelectionWithdrawal mapRequest(
        OrganisationSelectionNodeV1 request
    ) {
        OrganisationSelectionWithdrawal event = new OrganisationSelectionWithdrawal();
        event.setExternalBookingUuid(request.getBookingDetails().getExternalBookingUuid());

        
        Selection selection = new Selection();
        selection.setConfirmationStatus(request.getSelection().getConfirmationStatus());
        selection.setExternalSelectionUuid(request.getSelection().getExternalSelectionUuid());
        selection.setConfirmationStatusChangedDateTime(
            request.getSelection().getConfirmationStatusChangedDatetime().toString()
        );

        event.setSelection(selection);


        return event;
    }
}