package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.constants.DistORSConstants.BC;
import static com.ielts.cmds.integration.constants.DistORSConstants.ORGANISATION_SELECTION_WITHDRAWN_BC;
import static com.ielts.cmds.integration.constants.DistORSConstants.USER_AGENT;
import static com.ielts.cmds.integration.constants.DistORSConstants.USER_AGENT_KEY;

import org.springframework.http.HttpHeaders;

public class ORSSelectionWithdrawnDistBC extends AbstractORSSelectionWithdrawnDist {


	@Override
	protected void setAdditionalHttpHeaders(HttpHeaders httpHeaders) {
		httpHeaders.set(USER_AGENT_KEY, System.getenv(USER_AGENT));

	}

	@Override
	protected String getPartnerCodeConstants() {
		return BC;
	}

	@Override
	protected String getApplicationName() {
		return ORGANISATION_SELECTION_WITHDRAWN_BC;
	}
}