package com.ielts.cmds.integration.model.withdraw;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@NoArgsConstructor
public class OrganisationSelectionWithdrawal {

    private UUID externalBookingUuid;

    private Selection selection;
}