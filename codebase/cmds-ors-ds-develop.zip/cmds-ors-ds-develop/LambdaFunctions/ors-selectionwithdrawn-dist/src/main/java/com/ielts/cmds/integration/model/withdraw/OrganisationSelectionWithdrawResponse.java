
package com.ielts.cmds.integration.model.withdraw;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class OrganisationSelectionWithdrawResponse {

  private OrganisationSelectionWithdrawal response;
  private BaseEventErrors errors;
}