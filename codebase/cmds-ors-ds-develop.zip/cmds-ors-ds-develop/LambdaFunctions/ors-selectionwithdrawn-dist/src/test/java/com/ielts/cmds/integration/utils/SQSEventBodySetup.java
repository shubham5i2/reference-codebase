package com.ielts.cmds.integration.utils;

import static com.ielts.cmds.integration.constants.DistORSConstants.ORGANISATION_SELECTION_WITHDRAWN;
import static com.ielts.cmds.security.constants.DistORSConstants.ACCESS_TOKEN;
import static com.ielts.cmds.security.constants.DistORSConstants.CLIENT_ID;
import static com.ielts.cmds.security.constants.DistORSConstants.CLIENT_SECRET;
import static java.time.LocalDateTime.parse;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.model.withdraw.OrganisationSelectionWithdrawResponse;
import com.ielts.cmds.integration.model.withdraw.OrganisationSelectionWithdrawal;
import com.ielts.cmds.rd.domain.model.enums.ConfirmationStatusEnum;
import com.ielts.cmds.rd.domain.model.out.BookingNodeV1;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;
import com.ielts.cmds.rd.domain.model.out.SelectionNodeV1;

public class SQSEventBodySetup {

    private static final ObjectMapper mapper = mockMapper();


    public static String mockOrganisationSelectionWithdrawnEvent()
        throws JsonProcessingException {
        BaseHeader header = mockEventHeader();
        header.setEventName(ORGANISATION_SELECTION_WITHDRAWN);

        String body = mapper.writeValueAsString(eventBody());

        BaseEventErrors errors = new BaseEventErrors(mockErrors());

        return mapper.writeValueAsString(baseEvent(header, body, errors));
    }

    public static OrganisationSelectionWithdrawal mockPayload() {
    	OrganisationSelectionWithdrawal entity = new OrganisationSelectionWithdrawal();
		entity.setExternalBookingUuid(UUID.randomUUID());
		return entity;
	}
	
	public static OrganisationSelectionWithdrawResponse mockEntityPayload() {
		OrganisationSelectionWithdrawResponse entity = new OrganisationSelectionWithdrawResponse();
		OrganisationSelectionWithdrawal response = mockPayload();
		entity.setResponse(response);
		return entity;
	}
    public static ObjectMapper mockMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        return mapper;
    }

    public static Map<String, String> mockEnvironmentVariables() {
        Map<String, String> map = new HashMap<>();
        map.put(CLIENT_ID, "cmds-id");
        map.put(CLIENT_SECRET, "cmds-secret");
        map.put(ACCESS_TOKEN, "access-token");
        map.put("bc_auth_token_url", "BC_AUTH_URL");
        return map;
    }


    private static BaseHeader mockEventHeader() {
        BaseHeader eventHeader = new BaseHeader();
        eventHeader.setTransactionId(UUID.randomUUID());
        eventHeader.setCallbackURL("test");
        eventHeader.setCorrelationId(UUID.randomUUID());
        eventHeader.setPartnerCode("test");
        eventHeader.setEventName("test");
        eventHeader.setEventDateTime(parse(
            "2020-09-29T21:00:35.723Z",
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"))
        );
        return eventHeader;
    }


    private static List<ErrorDescription> mockErrors() {
        List<ErrorDescription> errorList = new ArrayList<>();
        ErrorDescription description = new ErrorDescription();
        description.setInterfaceName("SelectionNodeV1");
        description.setType(ErrorTypeEnum.VALIDATION);
        description.setErrorCode("1234");
        Source source = Source.builder().value("").path("product_uuid").build();
        description.setSource(source);
        errorList.add(description);
        return errorList;
    }

    private static BaseEvent<BaseHeader> baseEvent(
        final BaseHeader header,
        final String body,
        final BaseEventErrors error
    ) {
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        baseEvent.setEventHeader(header);
        baseEvent.setEventBody(body);
        baseEvent.setEventErrors(error);
        return baseEvent;
    }

    public static OrganisationSelectionNodeV1 eventBody() {
        OrganisationSelectionNodeV1 event = new OrganisationSelectionNodeV1();
        BookingNodeV1 booking = new BookingNodeV1();
        booking.setExternalBookingUuid(UUID.randomUUID());
        booking.setBookingUuid(UUID.randomUUID());
        event.setBookingDetails(booking);

        SelectionNodeV1 selectionNodeV1 = new SelectionNodeV1();
        selectionNodeV1.setSelectionUuid(UUID.randomUUID());
        selectionNodeV1.setExternalSelectionUuid(UUID.randomUUID());
        selectionNodeV1.setConfirmationStatus(ConfirmationStatusEnum.WITHDRAWN);
        selectionNodeV1.setConfirmationStatusChangedDatetime(OffsetDateTime.MAX);
        event.setSelection(selectionNodeV1);

        return event;
    }
}