package com.ielts.cmds.integration.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.integration.model.withdraw.OrganisationSelectionWithdrawal;
import com.ielts.cmds.integration.utils.SQSEventBodySetup;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;

@ExtendWith(MockitoExtension.class)
class EventMapperTest {
	
	@InjectMocks private EventMapper eventMapper;
	
	@Test
	void mapRequest_ExpectRequestToBeMapped() {
		OrganisationSelectionNodeV1 request = SQSEventBodySetup.eventBody();
		OrganisationSelectionWithdrawal actual = eventMapper.mapRequest(request);
		assertEquals(request.getBookingDetails().getExternalBookingUuid(), actual.getExternalBookingUuid());
		assertEquals(request.getSelection().getConfirmationStatus(), actual.getSelection().getConfirmationStatus());
		assertEquals(request.getSelection().getExternalSelectionUuid(), actual.getSelection().getExternalSelectionUuid());
		assertEquals(request.getSelection().getConfirmationStatusChangedDatetime().toString(), actual.getSelection().getConfirmationStatusChangedDateTime());
	}
	

}
