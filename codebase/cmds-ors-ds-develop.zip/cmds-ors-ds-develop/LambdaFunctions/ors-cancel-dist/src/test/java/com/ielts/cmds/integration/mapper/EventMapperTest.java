package com.ielts.cmds.integration.mapper;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.api.evt_019.BaseEventErrors;
import com.ielts.cmds.api.evt_019.BookingDetailsV1;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.SQSEventBodySetup;
import com.ielts.cmds.integration.model.BookingResponse;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.ielts.cmds.integration.SQSEventBodySetup.getCMDSErrorResponse019Null;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(MockitoExtension.class)
public class EventMapperTest {
  @InjectMocks EventMapper eventMapper;

  @Mock
  BookingDetailsV1 bookingDetails;

  @Mock
  BaseEventErrors baseEventErrors;

  @Spy private ObjectMapper mapper;

  @BeforeEach
  public void setUp() throws Exception {
    mapper = getMapper();
    mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
    mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);

    String sqsMsg = SQSEventBodySetup.getEventBody();
    BaseEvent<BaseHeader> cmdsEvent = mapper.readValue(sqsMsg, new TypeReference<BaseEvent<BaseHeader>>() {
    });
    bookingDetails = mapper.readValue(cmdsEvent.getEventBody(), BookingDetailsV1.class);
    baseEventErrors= SQSEventBodySetup.getCMDSErrorResponse019();
  }

  /*
   * test to validate the bookingResponse against bookingdetails
   * and check booking details populated correctly
   */
  @Test
  public void whenBookingDetailsProvided_ThenValidatedBookingResponse() {
    // when
    BookingResponse bookingResponse = eventMapper.mapBookingResponse(bookingDetails);

    // then

    assertEquals(bookingDetails.getBookingUuid(), bookingResponse.getBookingUuid());
    assertEquals(bookingDetails.getExternalBookingUuid(), bookingResponse.getExternalBookingUuid());
    assertEquals(bookingDetails.getExternalBookingReference(), bookingResponse.getExternalBookingReference());
    assertEquals(bookingDetails.getBookingStatus(), bookingResponse.getBookingStatus());
  }



  /*
   * when there are null values within bookingdetails then verify those null values in bookingResponse
   */
  @Test
  public void whenBookingDetailsIsPassedWithNullValues_ThenVerifyBookingResponseForNullValues() {
    // Given
    bookingDetails.setBookingUuid(null);
    bookingDetails.setExternalBookingUuid(null);
    bookingDetails.setExternalBookingReference(null);
    bookingDetails.setBookingStatus(null);
    // when
    BookingResponse bookingResponse = eventMapper.mapBookingResponse(bookingDetails);

    // then
    assertNull(bookingResponse.getBookingUuid());
    assertNull(bookingResponse.getExternalBookingUuid());
    assertNull(bookingResponse.getBookingStatus());
    assertNull(bookingResponse.getExternalBookingReference());
  }

  /*
   * test to check all ErrorMapperResponse fields are provided when errors in BookingChangedV1 is not null
   */
  @Test
  public void whenErrorIsProvided_ThenCheckForFieldsInErrorMapperResponse() {
    // when
    com.ielts.cmds.infrastructure.event.BaseEventErrors errorResponse = eventMapper.mapBookingErrorResponse(baseEventErrors);

    // then
    assertEquals(errorResponse.getErrorList().get(0).getType(), ErrorTypeEnum.valueOf(baseEventErrors.getErrorList().get(0).getType().toString()));
    assertEquals(errorResponse.getErrorList().get(0).getMessage(),baseEventErrors.getErrorList().get(0).getMessage());
    assertEquals(errorResponse.getErrorList().get(0).getErrorCode(),baseEventErrors.getErrorList().get(0).getErrorCode());
    assertEquals(errorResponse.getErrorList().get(0).getErrorTicketUuid(),baseEventErrors.getErrorList().get(0).getErrorTicketUuid());
    assertEquals(errorResponse.getErrorList().get(0).getInterfaceName(),baseEventErrors.getErrorList().get(0).getInterfaceName());
    assertEquals(errorResponse.getErrorList().get(0).getTitle(),baseEventErrors.getErrorList().get(0).getTitle());
    assertEquals(errorResponse.getErrorList().get(0).getSource().getPath(),baseEventErrors.getErrorList().get(0).getSource().getPath());
    assertEquals(errorResponse.getErrorList().get(0).getSource().getValue(),baseEventErrors.getErrorList().get(0).getSource().getValue());
  }

  /*
   * test to check all ErrorMapperResponse fields are provided when errors in BookingChangedV1 is not null
   * Non-mandatory fields are null
   */
  @Test
  public void whenNonMandatoryErrorFieldsAreNull_ThenCheckForFieldsInErrorMapperResponse() {
    //given
    baseEventErrors = getCMDSErrorResponse019Null();
    // when
    com.ielts.cmds.infrastructure.event.BaseEventErrors errorResponse = eventMapper.mapBookingErrorResponse(baseEventErrors);

    // then
    assertNull(errorResponse.getErrorList().get(0).getMessage());
    assertNull(errorResponse.getErrorList().get(0).getSource());
  }

  /*
   * clean up the resources
   */
  @AfterEach
  public void tearDown() {
    bookingDetails = null;
    baseEventErrors = null;
  }

  protected ObjectMapper getMapper() {
    ObjectMapper mapper = new ObjectMapper();
    mapper.registerModule(new JavaTimeModule());
    mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
    mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
    mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    return mapper;
  }
}
