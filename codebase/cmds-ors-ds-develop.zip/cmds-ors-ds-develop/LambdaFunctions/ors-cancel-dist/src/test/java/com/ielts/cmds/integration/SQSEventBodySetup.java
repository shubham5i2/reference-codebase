package com.ielts.cmds.integration;

import static com.ielts.cmds.common.enums.ErrorTypeEnum.VALIDATION;
import static com.ielts.cmds.integration.constants.DistORSConstants.ACCESS_TOKEN;
import static com.ielts.cmds.integration.constants.DistORSConstants.CALLBACK_URL;
import static com.ielts.cmds.integration.constants.DistORSConstants.CLIENT_ID;
import static com.ielts.cmds.integration.constants.DistORSConstants.CLIENT_SECRET;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.http.HttpHeaders;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.api.evt_019.BookingDetailsV1;
import com.ielts.cmds.api.evt_019.ErrorDescriptionSource;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

public class SQSEventBodySetup {

  private static final ObjectMapper mapper = getMapper();
  public static void setHeaderContext() {
    HeaderContext context = new HeaderContext();
    context.setCorrelationId(UUID.randomUUID());
    context.setTransactionId(UUID.randomUUID());
    context.setPartnerCode("test");
    ThreadLocalHeaderContext.setContext(context);

  }

  public static HttpHeaders getHttpHeaders() {
    HttpHeaders httpHeaders = new HttpHeaders();
    return httpHeaders;

  }

  public static String getEventBody() throws JsonProcessingException {
    BaseHeader eventHeader = getEventHeader();

    BookingDetailsV1 bookingDetails = getBookingDetails();
    String eventBody = mapper.writeValueAsString(bookingDetails);

    List<ErrorDescription> errorList = new ArrayList<>();
    ErrorDescription description = new ErrorDescription();
    description.setInterfaceName("Booking");
    description.setType(VALIDATION);
    description.setErrorCode("1234");
    Source source = Source.builder().value("").path("product_uuid").build();
    description.setSource(source);
    errorList.add(description);
    BaseEventErrors errorResponse = new BaseEventErrors(errorList);

    BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
    cmdsEvent.setEventHeader(eventHeader);
    cmdsEvent.setEventBody(eventBody);
    cmdsEvent.setEventErrors(errorResponse);
    return mapper.writeValueAsString(cmdsEvent);
  }
  public static BaseEventErrors getCMDSErrorResponse() {
    List<ErrorDescription> errorList = new ArrayList<>();
    ErrorDescription description = new ErrorDescription();
    description.setInterfaceName("Booking");
    description.setType(VALIDATION);
    description.setErrorCode("1234");
    Source source = new Source("path","value");
    description.setSource(source);
    errorList.add(description);

    return new BaseEventErrors(errorList);
  }

  public static com.ielts.cmds.api.evt_019.BaseEventErrors getCMDSErrorResponse019(){
    List<com.ielts.cmds.api.evt_019.ErrorDescription> errorList = new ArrayList<>();
    com.ielts.cmds.api.evt_019.ErrorDescription description = new com.ielts.cmds.api.evt_019.ErrorDescription();
    description.setInterfaceName("Booking");
    description.setType(com.ielts.cmds.api.evt_019.ErrorDescription.TypeEnum.VALIDATION);
    description.setErrorCode("1234");
    description.setTitle("Error");
    description.setMessage("Error Catched");
    description.setErrorTicketUuid(UUID.fromString("7686bc2e-cd9a-4a8f-8474-82f964e4c85f"));
    ErrorDescriptionSource source = new ErrorDescriptionSource();
    source.setPath("testing");
    source.setValue("value");
    description.setSource(source);
    errorList.add(description);

    com.ielts.cmds.api.evt_019.BaseEventErrors errorResponse = new com.ielts.cmds.api.evt_019.BaseEventErrors();
    errorResponse.setErrorList(errorList);
    return errorResponse;
  }

  public static com.ielts.cmds.api.evt_019.BaseEventErrors getCMDSErrorResponse019Null(){
    List<com.ielts.cmds.api.evt_019.ErrorDescription> errorList = new ArrayList<>();
    com.ielts.cmds.api.evt_019.ErrorDescription description = new com.ielts.cmds.api.evt_019.ErrorDescription();
    description.setInterfaceName("Booking");
    description.setType(com.ielts.cmds.api.evt_019.ErrorDescription.TypeEnum.VALIDATION);
    description.setErrorCode("1234");
    description.setTitle("Error");
    description.setMessage(null);
    description.setErrorTicketUuid(UUID.fromString("7686bc2e-cd9a-4a8f-8474-82f964e4c85f"));
    description.setSource(null);
    errorList.add(description);

    com.ielts.cmds.api.evt_019.BaseEventErrors errorResponse = new com.ielts.cmds.api.evt_019.BaseEventErrors();
    errorResponse.setErrorList(errorList);
    return errorResponse;
  }
  public static BookingDetailsV1 getBookingDetails() {
    BookingDetailsV1 bookingDetails = new BookingDetailsV1();
    bookingDetails.setExternalBookingUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775565"));
    bookingDetails.setBookingUuid(UUID.fromString("e8958327-9917-4af2-91ce-7c6cd0c19837"));
    bookingDetails.setIsVoid(false);
    bookingDetails.setBookingStatus(BookingDetailsV1.BookingStatusEnum.PAID);
    return bookingDetails;
  }

  protected static ObjectMapper getMapper() {
    ObjectMapper mapper = new ObjectMapper();
    mapper.registerModule(new JavaTimeModule());
    mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
    mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
    mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    return mapper;
  }

  public static BaseHeader getEventHeader() {
    BaseHeader eventHeader = new BaseHeader();
    eventHeader.setTransactionId(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
    eventHeader.setCallbackURL("http://35.178.179.164:8105/booking");
    eventHeader.setCorrelationId(UUID.fromString("779187f5-38ed-4e86-b311-050ffe394f81"));
    eventHeader.setPartnerCode("BC");
    eventHeader.setEventName("BookingCancelled");
    LocalDateTime eventDateTime =
            LocalDateTime.parse(
                    "2020-09-29T21:00:35.723Z",
                    DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
    eventHeader.setEventDateTime(eventDateTime);
    return eventHeader;
  }

  public static Map<String, String> getEnvironmentVariablesStub() {
    Map<String, String> map = new HashMap<>();
    map.put(CLIENT_ID, "cmds-id");
    map.put(CLIENT_SECRET, "cmds-secret");
    map.put(ACCESS_TOKEN, "access-token");
    map.put("bc_auth_token_url", "BC_AUTH_URL");
    map.put(CALLBACK_URL, "https://wiremock.shared.cmdsiz.com/ors/invoke/v1/booking");
    return map;
  }

}
