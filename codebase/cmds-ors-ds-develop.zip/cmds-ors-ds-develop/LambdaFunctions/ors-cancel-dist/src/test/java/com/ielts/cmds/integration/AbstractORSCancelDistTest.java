package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.constants.DistORSConstants.CORRELATIONID;
import static com.ielts.cmds.integration.constants.DistORSConstants.EVENT_DATE_TIME;
import static com.ielts.cmds.integration.constants.DistORSConstants.PARTNER_CODE;
import static com.ielts.cmds.integration.constants.DistORSConstants.TRANSACTIONID;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;

import java.security.KeyStoreException;
import java.security.cert.CertificateException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.UUID;
import java.util.stream.Stream;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatchers;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.services.sns.AmazonSNS;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.evt_019.BookingChangedEventV1;
import com.ielts.cmds.api.evt_019.BookingDetailsV1;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.integration.mapper.EventMapper;
import com.ielts.cmds.integration.model.BookingResponse;
import com.ielts.cmds.integration.model.CMDSResponseBody;
import com.ielts.cmds.integration.model.ExtBookingResponse;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.exception.InvalidClientException;
import com.ielts.cmds.security.exception.TokenNotReceivedException;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;
import com.ielts.cmds.serialization.lambda.config.SNSClientConfig;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import uk.org.webcompere.systemstubs.environment.EnvironmentVariables;
import uk.org.webcompere.systemstubs.jupiter.SystemStub;
import uk.org.webcompere.systemstubs.jupiter.SystemStubsExtension;

@ExtendWith(MockitoExtension.class)
@ExtendWith(SystemStubsExtension.class)
class AbstractORSCancelDistTest {

  private AbstractORSCancelDist orsCancelDist;
  @Mock private RestTemplate restTemplate;
  @Mock private EventMapper eventMapper;
  @Mock private EnvironmentAwareAuthenticationClientFactory authenticationFactory;

  @Mock private AuthenticationClient authenticationClient;

  @Mock private AmazonSNS snsClient;

  private BookingChangedEventV1 bookingChangedEventV1;
  private BookingDetailsV1 bookingDetailsV1;
  private BaseEventErrors baseEventErrors;
  private CMDSResponseBody cmdsResponseBody;
  private BookingResponse bookingResponse;

  private static MockedStatic<SNSClientConfig> snsClientConfig;

  private String externalUrl = "test.url";

  private HttpHeaders httpHeaders;

  @Captor private ArgumentCaptor<HttpEntity<CMDSResponseBody>> entity;

  @SystemStub private EnvironmentVariables environmentVariables;

  @BeforeAll
  static void beforeClass() {
    snsClientConfig = Mockito.mockStatic(SNSClientConfig.class);
  }

  @AfterAll
  static void afterClass() {
    Mockito.framework().clearInlineMocks();
  }

  @BeforeEach
  void setUp() {
    SQSEventBodySetup.setHeaderContext();
    httpHeaders = SQSEventBodySetup.getHttpHeaders();
    environmentVariables.set("callback_url", externalUrl);
    AbstractORSCancelDist orsCancelDistMock =  new AbstractORSCancelDist() {
      @Override
      protected String getPartnerCodeConstants() {
        return "test";
      }

      @Override
      protected String getApplicationName() {
        return "bookingbanned-dist";
      }

      @Override
      protected void setAdditionalHttpHeaders(HttpHeaders httpHeaders) {
      }
    };
    snsClientConfig.when(SNSClientConfig::getSNSClient).thenReturn(snsClient);
    ReflectionTestUtils.setField(orsCancelDistMock,"authenticationClientFactory",authenticationFactory);
    ReflectionTestUtils.setField(orsCancelDistMock,"authenticationClient",authenticationClient);
    bookingDetailsV1 = SQSEventBodySetup.getBookingDetails();
    bookingChangedEventV1 = new BookingChangedEventV1();
    bookingChangedEventV1.setBookingDetails(bookingDetailsV1);
    orsCancelDist = spy(orsCancelDistMock);
  }

  @Test
  void processIsCalled_ExpectNoException() {
    doReturn(eventMapper).when(orsCancelDist).getEventMapper();
    doReturn(bookingResponse).when(eventMapper).mapBookingResponse(bookingDetailsV1);
    cmdsResponseBody = new ExtBookingResponse(bookingResponse, baseEventErrors);
    doNothing().when(orsCancelDist).postRequestToExternalAPI(cmdsResponseBody,externalUrl );
    assertDoesNotThrow(()-> orsCancelDist.processRequest(bookingChangedEventV1));
  }

  @Test
  void processIsCalledWithInvalidPartnerCode_ExpectNoException() {
    ThreadLocalHeaderContext.getContext().setPartnerCode("invalid");
    assertDoesNotThrow(()-> orsCancelDist.processRequest(bookingChangedEventV1));
    verify(orsCancelDist, never()).postRequestToExternalAPI(cmdsResponseBody, externalUrl);
    verify(orsCancelDist, never()).getEventMapper();
    verify(eventMapper, never()).mapBookingResponse(bookingDetailsV1);
  }

  @Test
  void getEventMapper_ExpectNonNullObject() {
    assertNotNull(orsCancelDist.getEventMapper());
  }

  @Test
  void postRequestToExternalAPIIsCalledOk_ExpectRestCallWithOk() throws JsonProcessingException, CertificateException, KeyStoreException, InvalidClientException, TokenNotReceivedException {
    doNothing().when(orsCancelDist).getAuthenticationClient();
    doReturn(restTemplate).when(authenticationClient).getRestTemplate();
    doReturn(httpHeaders).when(orsCancelDist).getHttpHeaders();
    ResponseEntity<String> response = new ResponseEntity<>(HttpStatus.OK);
    doReturn(response).when(restTemplate).exchange(ArgumentMatchers.eq(externalUrl),ArgumentMatchers.eq(HttpMethod.POST),
            ArgumentMatchers.any(), ArgumentMatchers.eq(String.class));
    assertDoesNotThrow(()-> orsCancelDist.postRequestToExternalAPI(cmdsResponseBody, externalUrl));
    verify(restTemplate).exchange(ArgumentMatchers.eq(externalUrl),ArgumentMatchers.eq(HttpMethod.POST),
            entity.capture(), ArgumentMatchers.eq(String.class));
    HttpEntity<CMDSResponseBody> actual = entity.getValue();
    assertEquals(httpHeaders, actual.getHeaders());
    assertEquals(cmdsResponseBody, actual.getBody());
  }

  @Test
  void postRequestToExternalAPIIsCalledServerError_ExpectRestCallWithException()
          throws JsonProcessingException, CertificateException, KeyStoreException,
          InvalidClientException, TokenNotReceivedException {
    doNothing().when(orsCancelDist).getAuthenticationClient();
    doReturn(restTemplate).when(authenticationClient).getRestTemplate();
    doReturn(httpHeaders).when(orsCancelDist).getHttpHeaders();
    doThrow(HttpServerErrorException.class).when(restTemplate).exchange(ArgumentMatchers.eq(externalUrl),ArgumentMatchers.eq(HttpMethod.POST),
            ArgumentMatchers.any(), ArgumentMatchers.eq(String.class));
    assertThrows(HttpServerErrorException.class, ()-> orsCancelDist.postRequestToExternalAPI(cmdsResponseBody, externalUrl));
    verify(restTemplate).exchange(ArgumentMatchers.eq(externalUrl),ArgumentMatchers.eq(HttpMethod.POST),
            entity.capture(), ArgumentMatchers.eq(String.class));
    HttpEntity<CMDSResponseBody> actual = entity.getValue();
    assertEquals(httpHeaders, actual.getHeaders());
    assertEquals(cmdsResponseBody, actual.getBody());
  }

  @Test
  void postRequestToExternalAPIIsCalledBadRequest_ExpectRestCallWithNoException()
          throws JsonProcessingException, CertificateException, KeyStoreException,
          InvalidClientException, TokenNotReceivedException {
    doNothing().when(orsCancelDist).getAuthenticationClient();
    doReturn(restTemplate).when(authenticationClient).getRestTemplate();
    doReturn(httpHeaders).when(orsCancelDist).getHttpHeaders();
    doThrow(HttpClientErrorException.class).when(restTemplate).exchange(ArgumentMatchers.eq(externalUrl),ArgumentMatchers.eq(HttpMethod.POST),
            ArgumentMatchers.any(), ArgumentMatchers.eq(String.class));
    assertDoesNotThrow(()-> orsCancelDist.postRequestToExternalAPI(cmdsResponseBody, externalUrl));
    verify(restTemplate).exchange(ArgumentMatchers.eq(externalUrl),ArgumentMatchers.eq(HttpMethod.POST),
            entity.capture(), ArgumentMatchers.eq(String.class));
    HttpEntity<CMDSResponseBody> actual = entity.getValue();
    assertEquals(httpHeaders, actual.getHeaders());
    assertEquals(cmdsResponseBody, actual.getBody());
  }

  @ParameterizedTest
  @MethodSource("getTestDataForAuthenticationClientFactoryException")
  void postRequestToExternalAPIIsCalledWithException_ExpectNoRestCallAndNoException(Class<Exception> exception) throws JsonProcessingException, CertificateException, KeyStoreException, InvalidClientException {
    doThrow(exception).when(orsCancelDist).getAuthenticationClient();
    assertDoesNotThrow(()-> orsCancelDist.postRequestToExternalAPI(cmdsResponseBody, externalUrl));
    verify(restTemplate, never()).exchange(ArgumentMatchers.eq(externalUrl),ArgumentMatchers.eq(HttpMethod.POST),
            entity.capture(), ArgumentMatchers.eq(String.class));

  }

  @ParameterizedTest
  @MethodSource("getTestDataForAuthenticationClientAccessTokenException")
  void postRequestToExternalAPIIsCalledWithAuthenticationClientAccessTokenException_ExpectNoRestCallAndNoException(
          Class<Exception> exception)
          throws JsonProcessingException, CertificateException, KeyStoreException,
          InvalidClientException, TokenNotReceivedException {
    doNothing().when(orsCancelDist).getAuthenticationClient();
    doThrow(exception).when(orsCancelDist).getHttpHeaders();
    assertDoesNotThrow(()-> orsCancelDist.postRequestToExternalAPI(cmdsResponseBody, externalUrl));
    verify(restTemplate, never()).exchange(ArgumentMatchers.eq(externalUrl),ArgumentMatchers.eq(HttpMethod.POST),
            entity.capture(), ArgumentMatchers.eq(String.class));
  }

  @Test
  void getAuthenticationClientWithObjectSet_DoNotExpectCall() throws JsonProcessingException, CertificateException, KeyStoreException, InvalidClientException {
    ReflectionTestUtils.setField(orsCancelDist,"authenticationClient",authenticationClient);
    orsCancelDist.getAuthenticationClient();
    verify(authenticationFactory, never()).getAuthenticationClient("test");
  }

  @Test
  void getAuthenticationClientWithoutObjectSet_DoNotExpectCall() throws JsonProcessingException, CertificateException, KeyStoreException, InvalidClientException {
    ReflectionTestUtils.setField(orsCancelDist,"authenticationClient",null);
    orsCancelDist.getAuthenticationClient();
    verify(authenticationFactory).getAuthenticationClient("test");
  }

  @Test
  void getNonNullUuidStringWithNullUuid_ExpectEmptyString() {
    assertEquals("", orsCancelDist.getNonNullUuidString(null));
  }

  @Test
  void getNonNullUuidStringWithNonNullUuid_ExpectUUIDString() {
    UUID uuid = UUID.randomUUID();
    assertEquals(uuid.toString(), orsCancelDist.getNonNullUuidString(uuid));
  }

  @Test
  void getNonNullDateTimeStringWithNullDateTime_ExpectEmptyString() {
    assertEquals("", orsCancelDist.getNonNullDateTimeString(null));
  }

  @Test
  void getNonNullDateTimeStringWithNullDateTime_ExpectDateTimeString() {
    LocalDateTime dateTime = LocalDateTime.now(ZoneOffset.UTC);
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
    assertEquals(dateTime.format(formatter), orsCancelDist.getNonNullDateTimeString(dateTime));
  }

  @Test
  void getTopicName_ExpectNull() {
    assertNull(orsCancelDist.getTopicName());
  }

  @Test
  void getHttpHeaders_ExpectHeadersToBeSet() throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException {
    doReturn("token").when(authenticationClient).getAccessToken();
    doReturn("Authorization").when(authenticationClient).getAuthorizationHeaderName();
    HttpHeaders actual = orsCancelDist.getHttpHeaders();
    assertEquals(ThreadLocalHeaderContext.getContext().getTransactionId().toString(), actual.get(TRANSACTIONID).get(0));
    assertEquals(ThreadLocalHeaderContext.getContext().getCorrelationId().toString(), actual.get(CORRELATIONID).get(0));
    assertEquals(ThreadLocalHeaderContext.getContext().getPartnerCode(), actual.get(PARTNER_CODE).get(0));
    assertEquals("", actual.get(EVENT_DATE_TIME).get(0));
    assertEquals("token", actual.get("Authorization").get(0));
  }



  static Stream<Arguments> getTestDataForAuthenticationClientFactoryException() {
    return Stream.of(
            Arguments.of(JsonProcessingException.class),
            Arguments.of(InvalidClientException.class),
            Arguments.of(CertificateException.class),
            Arguments.of(KeyStoreException.class));
  }


  static Stream<Arguments> getTestDataForAuthenticationClientAccessTokenException() {
    return Stream.of(
            Arguments.of(JsonProcessingException.class),
            Arguments.of(CertificateException.class),
            Arguments.of(KeyStoreException.class),
            Arguments.of(TokenNotReceivedException.class));
  }



}

