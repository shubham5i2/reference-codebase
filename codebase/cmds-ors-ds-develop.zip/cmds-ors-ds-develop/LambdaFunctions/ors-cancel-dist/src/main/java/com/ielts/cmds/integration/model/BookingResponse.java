package com.ielts.cmds.integration.model;

import com.ielts.cmds.api.evt_019.BookingDetailsV1;
import lombok.Data;

import java.util.UUID;

@Data
public class BookingResponse {
    private UUID bookingUuid;
    private UUID externalBookingUuid;
    private String externalBookingReference;
    private BookingDetailsV1.BookingStatusEnum bookingStatus;
}
