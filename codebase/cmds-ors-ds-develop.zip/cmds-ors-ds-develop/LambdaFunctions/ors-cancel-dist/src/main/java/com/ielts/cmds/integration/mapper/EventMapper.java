package com.ielts.cmds.integration.mapper;

import com.ielts.cmds.api.evt_019.BookingDetailsV1;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.integration.model.BookingResponse;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;
/** This class is used to map incoming event to appropriate API request body */
public class EventMapper {

  /**
   * Maps input event to booking response specific to request api body
   */
  public BookingResponse mapBookingResponse(@Valid final BookingDetailsV1 details) {
    if(details != null) {
      final BookingResponse bookingResponse = new BookingResponse();
      bookingResponse.setBookingUuid(details.getBookingUuid());
      bookingResponse.setExternalBookingUuid(details.getExternalBookingUuid());
      bookingResponse.setExternalBookingReference(details.getExternalBookingReference());
      bookingResponse.setBookingStatus(details.getBookingStatus());
      return bookingResponse;
    }
    return null;
  }

  public BaseEventErrors mapBookingErrorResponse(com.ielts.cmds.api.evt_019.BaseEventErrors eventErrors) {
    if(eventErrors != null) {
      List<ErrorDescription> errorDescriptions = eventErrorMapper(eventErrors.getErrorList());
      return new BaseEventErrors(errorDescriptions);
    }
    return null;
  }

  List<ErrorDescription> eventErrorMapper(@Valid List<com.ielts.cmds.api.evt_019.ErrorDescription> errorDescription) {
    List<ErrorDescription> errorDescriptionList = new ArrayList<>();
    for(com.ielts.cmds.api.evt_019.ErrorDescription e : errorDescription){
      ErrorDescription description = new ErrorDescription();
      description.setInterfaceName(e.getInterfaceName());
      description.setTitle(e.getTitle());
      description.setType(ErrorTypeEnum.valueOf(e.getType().toString()));
      description.setErrorCode(e.getErrorCode());

      description.setErrorTicketUuid(e.getErrorTicketUuid());

      if(Objects.nonNull(e.getMessage())) {
        description.setMessage(e.getMessage());
      }
      if(Objects.nonNull(e.getSource())) {
        Source source = new Source(e.getSource().getPath(),e.getSource().getValue());
        description.setSource(source);
      }
      errorDescriptionList.add(description);
    }
    return errorDescriptionList;
  }
}
