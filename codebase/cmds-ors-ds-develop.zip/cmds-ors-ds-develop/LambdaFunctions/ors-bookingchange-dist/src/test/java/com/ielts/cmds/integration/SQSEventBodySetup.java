package com.ielts.cmds.integration;

import static com.ielts.cmds.common.enums.ErrorTypeEnum.VALIDATION;
import static com.ielts.cmds.integration.constants.DistORSConstants.ACCESS_TOKEN;
import static com.ielts.cmds.integration.constants.DistORSConstants.BOOKING_REJECTED;
import static com.ielts.cmds.integration.constants.DistORSConstants.CALLBACK_URL;
import static com.ielts.cmds.integration.constants.DistORSConstants.CLIENT_ID;
import static com.ielts.cmds.integration.constants.DistORSConstants.CLIENT_SECRET;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.http.HttpHeaders;

import com.amazonaws.regions.Regions;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.api.evt_019.BookingDetailsV1;
import com.ielts.cmds.api.evt_019.BookingLineV1;
import com.ielts.cmds.api.evt_019.ErrorDescriptionSource;
import com.ielts.cmds.api.evt_019.MarketingInfoV1;
import com.ielts.cmds.api.evt_019.TestTakerAddressV1;
import com.ielts.cmds.api.evt_019.TestTakerDetailsV1;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

public class SQSEventBodySetup {
  private static final ObjectMapper mapper = getMapper();
  public static void setHeaderContext() {
    HeaderContext context = new HeaderContext();
    context.setCorrelationId(UUID.randomUUID());
    context.setTransactionId(UUID.randomUUID());
    context.setPartnerCode("test");
    ThreadLocalHeaderContext.setContext(context);

  }

  
  public static HttpHeaders getHttpHeaders() {
    HttpHeaders httpHeaders = new HttpHeaders();
    return httpHeaders;

  }


  public static String getEventBody() throws JsonProcessingException {
    BaseHeader eventHeader = getEventHeader();

    BookingDetailsV1 bookingChangedEventV1 = getBookingDetails();
    String eventBody = mapper.writeValueAsString(bookingChangedEventV1);

    List<ErrorDescription> errorList = new ArrayList<>();
    ErrorDescription description = new ErrorDescription();
    description.setInterfaceName("Booking");
    description.setType(VALIDATION);
    description.setErrorCode("1234");
    Source source = Source.builder().value("").path("product_uuid").build();
    description.setSource(source);
    errorList.add(description);

    com.ielts.cmds.infrastructure.event.BaseEventErrors errorResponse = new com.ielts.cmds.infrastructure.event.BaseEventErrors();
    BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
    cmdsEvent.setEventHeader(eventHeader);
    cmdsEvent.setEventBody(eventBody);
    cmdsEvent.setEventErrors(errorResponse);
    return mapper.writeValueAsString(cmdsEvent);
  }

  public static BaseEventErrors getCMDSErrorResponse() {
    List<ErrorDescription> errorList = new ArrayList<>();
    ErrorDescription description = new ErrorDescription();
    description.setInterfaceName("Booking");
    description.setType(VALIDATION);
    description.setErrorCode("1234");
    Source source = new Source("path","value");
    description.setSource(source);
    errorList.add(description);

    return new BaseEventErrors(errorList);
  }

  public static com.ielts.cmds.api.evt_019.BaseEventErrors getCMDSErrorResponse019(){
    List<com.ielts.cmds.api.evt_019.ErrorDescription> errorList = new ArrayList<>();
    com.ielts.cmds.api.evt_019.ErrorDescription description = new com.ielts.cmds.api.evt_019.ErrorDescription();
    description.setInterfaceName("Booking");
    description.setType(com.ielts.cmds.api.evt_019.ErrorDescription.TypeEnum.VALIDATION);
    description.setErrorCode("1234");
    description.setTitle("Error");
    description.setMessage("Error Catched");
    description.setErrorTicketUuid(UUID.fromString("7686bc2e-cd9a-4a8f-8474-82f964e4c85f"));
    ErrorDescriptionSource source = new ErrorDescriptionSource();
    source.setPath("testing");
    source.setValue("value");
    description.setSource(source);
    errorList.add(description);

    com.ielts.cmds.api.evt_019.BaseEventErrors errorResponse = new com.ielts.cmds.api.evt_019.BaseEventErrors();
    errorResponse.setErrorList(errorList);
    return errorResponse;
  }

  public static com.ielts.cmds.api.evt_019.BaseEventErrors getCMDSErrorResponse019Null(){
    List<com.ielts.cmds.api.evt_019.ErrorDescription> errorList = new ArrayList<>();
    com.ielts.cmds.api.evt_019.ErrorDescription description = new com.ielts.cmds.api.evt_019.ErrorDescription();
    description.setInterfaceName("Booking");
    description.setType(com.ielts.cmds.api.evt_019.ErrorDescription.TypeEnum.VALIDATION);
    description.setErrorCode("1234");
    description.setTitle("Error");
    description.setMessage(null);
    description.setErrorTicketUuid(UUID.fromString("7686bc2e-cd9a-4a8f-8474-82f964e4c85f"));
    description.setSource(null);
    errorList.add(description);

    com.ielts.cmds.api.evt_019.BaseEventErrors errorResponse = new com.ielts.cmds.api.evt_019.BaseEventErrors();
    errorResponse.setErrorList(errorList);
    return errorResponse;
  }

  public static BookingDetailsV1 getBookingDetails() {
    BookingDetailsV1 bookingDetails = new BookingDetailsV1();
    bookingDetails.setExternalBookingUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775565"));
    bookingDetails.setBookingUuid(UUID.fromString("e8958327-9917-4af2-91ce-7c6cd0c19837"));
    bookingDetails.setPartnerCode(null);
    bookingDetails.setLocationUuid(UUID.fromString("8ef3da3a-2360-4bd9-bbb5-bb5f72457f83"));
    bookingDetails.setProductUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
    bookingDetails.setTestDate(OffsetDateTime.now());
    bookingDetails.setBookingStatus(BookingDetailsV1.BookingStatusEnum.PAID);
    bookingDetails.setBookingDetailStatus(BookingDetailsV1.BookingDetailStatusEnum.INCOMPLETE);
    bookingDetails.setConsentGiven(true);
    bookingDetails.setAgentName("The Agency Inc.");
    MarketingInfoV1 info = new MarketingInfoV1();
    info.setEducationLevelUuid(UUID.fromString("ba7e70a1-030f-4ed2-9e4c-97e1fe3bb43a"));
    info.setYearsOfStudy(BigDecimal.valueOf(4));
    info.setOccupationSectorOther("5ad0193f-69b0-45bd-9e8a-ce53e6f8bd24");
    info.setOccupationLevelUuid(UUID.fromString("4faad5f5-97e1-4d64-bec5-7d50bc0acf49"));
    info.setReasonForTestUuid(UUID.fromString("5db03c10-7c33-4ebb-b8ec-aa634236307a"));
    info.setCurrentEnglishStudyPlace("DJ Uni.");
    info.setOccupationSectorOther("string");
    info.setOccupationLevelOther("string");
    info.setReasonForTestOther("string");
    info.setCountryApplyingToOther("GRB");
    bookingDetails.setMarketingInfo(info);
    TestTakerDetailsV1 testTaker = new TestTakerDetailsV1();
    testTaker.setBannedStatus(TestTakerDetailsV1.BannedStatusEnum.UNKNOWN);
    testTaker.setUniqueTestTakerUuid(null);
    testTaker.setShortCandidateNumber("000013");
    testTaker.setReasonForMatch("CHECK1");
    testTaker.setCompositeCandidateNumber("UK24620000013");
    testTaker.setExternalUniqueTestTakerUuid(
        UUID.fromString("5db03c10-7c33-4ebb-b8ec-aa634236307a"));
    testTaker.setIdentityNumber("AB12314");
    testTaker.setIdentityTypeUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
    testTaker.setIdentityVerificationStatus(TestTakerDetailsV1.IdentityVerificationStatusEnum.INCOMPLETE);
    testTaker.setIdentityIssuingAuthority("string");
    testTaker.setIdentityExpiryDate(
        LocalDate.parse("2022-06-01", DateTimeFormatter.ofPattern("yyyy-MM-dd")));
    testTaker.setFirstName("Alan");
    testTaker.setLastName("Davies");
    testTaker.setBirthDate(
        LocalDate.parse("1990-06-01", DateTimeFormatter.ofPattern("yyyy-MM-dd")));
    testTaker.setSexUuid(UUID.fromString("0d9dbdd5-f1e6-4753-b7a9-573a898cd11c"));
    testTaker.setEmail("alan@gmail.com");
    testTaker.setTitle("cef4fcb1-2bd2-51f3-889d-abd47d775668");
    testTaker.setPhone("");
    testTaker.setMobile("");
    testTaker.setLanguageUuid(UUID.fromString("1ef783e4-c4a0-4e0c-95ed-9ea35dca30f3"));
    testTaker.setNationalityUuid(UUID.fromString("0d9dbdd5-f1e6-4753-b7a9-573a898cd11c"));
    testTaker.setNotes("string");
    TestTakerAddressV1 ttaddress = new TestTakerAddressV1();
    ttaddress.setCity("Melbourne");
    ttaddress.setPostalCode("1234");
    ttaddress.setAddressLine1("15");
    ttaddress.setAddressLine2("King Street");
    ttaddress.setAddressLine3("");
    ttaddress.setAddressLine4("");
    ttaddress.setStateTerritoryUuid(UUID.fromString("5432081f-453f-4a45-adf9-824531d8e2dc"));
    testTaker.setAddress(ttaddress);
    bookingDetails.setTestTaker(testTaker);

    BookingLineV1 bookingline = new BookingLineV1();
    bookingline.setBookingLineUuid(UUID.fromString("fc7663b9-b4cd-458a-bc1e-59e601888046"));
    bookingline.setExternalBookingLineUuid(UUID.fromString("fc7663b9-b4cd-458a-bc1e-59e601888046"));
    bookingline.setProductUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
    bookingline.setStartTimeLocal(OffsetDateTime.now());
    bookingline.setStartDateTime(OffsetDateTime.now());
    bookingline.setBookingLineStatus(BookingLineV1.BookingLineStatusEnum.ACTIVE);
    List<BookingLineV1> bookingLineList = new ArrayList<>();
    bookingLineList.add(bookingline);
    bookingDetails.setBookingLines(bookingLineList);
    return bookingDetails;
  }

  protected static ObjectMapper getMapper() {
    ObjectMapper mapper = new ObjectMapper();
    mapper.registerModule(new JavaTimeModule());
    mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
    mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
    mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    return mapper;
  }

  public static BaseHeader getEventHeader() {
    BaseHeader eventHeader = new BaseHeader();
    eventHeader.setTransactionId(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
    eventHeader.setCallbackURL("https://wiremock.shared.cmdsiz.com/ors/invoke/v1/booking");
    eventHeader.setCorrelationId(UUID.fromString("779187f5-38ed-4e86-b311-050ffe394f81"));
    eventHeader.setPartnerCode("BC");
    eventHeader.setEventName("BookingCancelled");
    LocalDateTime eventDateTime =
        LocalDateTime.parse(
            "2020-09-29T21:00:35.723Z",
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
    eventHeader.setEventDateTime(eventDateTime);
    return eventHeader;
  }

  public static BaseHeader getBCEventHeader() {
    BaseHeader eventHeader = new BaseHeader();
    eventHeader.setTransactionId(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
    eventHeader.setCallbackURL("https://wiremock.shared.cmdsiz.com/ors/invoke/v1/booking");
    eventHeader.setCorrelationId(UUID.fromString("779187f5-38ed-4e86-b311-050ffe394f81"));
    eventHeader.setPartnerCode("BC");
    eventHeader.setEventName("BookingCreated");
    LocalDateTime eventDateTime =
        LocalDateTime.parse(
            "2020-09-29T21:00:35.723Z",
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
    eventHeader.setEventDateTime(eventDateTime);
    return eventHeader;
  }

  public static BaseHeader getIDPEventHeader() {
    BaseHeader eventHeader = new BaseHeader();
    eventHeader.setTransactionId(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
    eventHeader.setCallbackURL("https://wiremock.shared.cmdsiz.com/ors/invoke/v1/booking");
    eventHeader.setCorrelationId(UUID.fromString("779187f5-38ed-4e86-b311-050ffe394f81"));
    eventHeader.setPartnerCode("IDP");
    eventHeader.setEventName("BookingCreated");
    LocalDateTime eventDateTime =
        LocalDateTime.parse(
            "2020-09-29T21:00:35.723Z",
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
    eventHeader.setEventDateTime(eventDateTime);
    return eventHeader;
  }

  public static BaseHeader getBCCHNEventHeader() {
    BaseHeader eventHeader = new BaseHeader();
    eventHeader.setTransactionId(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
    eventHeader.setCallbackURL("https://wiremock.shared.cmdsiz.com/ors/invoke/v1/booking");
    eventHeader.setCorrelationId(UUID.fromString("779187f5-38ed-4e86-b311-050ffe394f81"));
    eventHeader.setPartnerCode("BC_CHN");
    eventHeader.setEventName("BookingCreated");
    LocalDateTime eventDateTime =
            LocalDateTime.parse(
                    "2020-09-29T21:00:35.723Z",
                    DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
    eventHeader.setEventDateTime(eventDateTime);
    return eventHeader;
  }
  public static BaseHeader getBookingRejectEventHeader() {
    BaseHeader eventHeader = new BaseHeader();
    eventHeader.setTransactionId(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
    eventHeader.setCallbackURL("https://wiremock.shared.cmdsiz.com/ors/invoke/v1/booking");
    eventHeader.setCorrelationId(UUID.fromString("779187f5-38ed-4e86-b311-050ffe394f81"));
    eventHeader.setPartnerCode("BC");
    eventHeader.setEventName("BookingRejected");
    LocalDateTime eventDateTime =
        LocalDateTime.parse(
            "2020-09-29T21:00:35.723Z",
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
    eventHeader.setEventDateTime(eventDateTime);
    return eventHeader;
  }

  public static BaseHeader getEmptyEventEventHeader() {
    BaseHeader eventHeader = new BaseHeader();
    eventHeader.setTransactionId(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
    eventHeader.setCallbackURL("https://wiremock.shared.cmdsiz.com/ors/invoke/v1/booking");
    eventHeader.setCorrelationId(UUID.fromString("779187f5-38ed-4e86-b311-050ffe394f81"));
    eventHeader.setPartnerCode("BC");
    eventHeader.setEventName(BOOKING_REJECTED);
    LocalDateTime eventDateTime =
        LocalDateTime.parse(
            "2020-09-29T21:00:35.723Z",
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
    eventHeader.setEventDateTime(eventDateTime);
    return eventHeader;
  }

  public static String getIDPEventBody() throws JsonProcessingException {
    BaseHeader eventHeader = getIDPEventHeader();

    BookingDetailsV1 bookingDetails = getIDPBookingDetails();
    String eventBody = mapper.writeValueAsString(bookingDetails);

    List<ErrorDescription> errorList = new ArrayList<>();
    ErrorDescription description = new ErrorDescription();
    description.setInterfaceName("Booking");
    description.setType(VALIDATION);
    description.setErrorCode("1234");
    Source source = Source.builder().value("").path("product_uuid").build();
    description.setSource(source);
    errorList.add(description);

    com.ielts.cmds.infrastructure.event.BaseEventErrors errorResponse = new com.ielts.cmds.infrastructure.event.BaseEventErrors(errorList);

    BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
    cmdsEvent.setEventHeader(eventHeader);
    cmdsEvent.setEventBody(eventBody);
    cmdsEvent.setEventErrors(errorResponse);
    return mapper.writeValueAsString(cmdsEvent);
  }
  public static String getBCCHNEventBody() throws JsonProcessingException {
    BaseHeader eventHeader = getBCCHNEventHeader();

    BookingDetailsV1 bookingDetails = getBCCHNBookingDetails();
    String eventBody = mapper.writeValueAsString(bookingDetails);

    List<ErrorDescription> errorList = new ArrayList<>();
    ErrorDescription description = new ErrorDescription();
    description.setInterfaceName("Booking");
    description.setType(VALIDATION);
    description.setErrorCode("1234");
    Source source = Source.builder().value("").path("product_uuid").build();
    description.setSource(source);
    errorList.add(description);

    com.ielts.cmds.infrastructure.event.BaseEventErrors errorResponse = new com.ielts.cmds.infrastructure.event.BaseEventErrors();

    BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
    cmdsEvent.setEventHeader(eventHeader);
    cmdsEvent.setEventBody(eventBody);
    cmdsEvent.setEventErrors(errorResponse);
    return mapper.writeValueAsString(cmdsEvent);
  }

  public static BookingDetailsV1 getBCBookingDetails() {
    BookingDetailsV1 bookingDetails = new BookingDetailsV1();
    bookingDetails.setExternalBookingUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775565"));
    bookingDetails.setBookingUuid(UUID.fromString("e8958327-9917-4af2-91ce-7c6cd0c19837"));
    bookingDetails.setIsVoid(true);
    return bookingDetails;
  }

  public static BookingDetailsV1 getIDPBookingDetails() {
    BookingDetailsV1 bookingDetails = new BookingDetailsV1();
    bookingDetails.setExternalBookingUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775565"));
    bookingDetails.setBookingUuid(UUID.fromString("e8958327-9917-4af2-91ce-7c6cd0c19837"));
    bookingDetails.setIsVoid(true);
    return bookingDetails;
  }
  public static BookingDetailsV1 getBCCHNBookingDetails() {
    BookingDetailsV1 bookingDetails = new BookingDetailsV1();
    bookingDetails.setExternalBookingUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775565"));
    bookingDetails.setBookingUuid(UUID.fromString("e8958327-9917-4af2-91ce-7c6cd0c19837"));
    bookingDetails.setIsVoid(true);
    return bookingDetails;
  }

  public static Map<String, String> getEnvironmentVariables(final String partnerCode)
      throws JsonProcessingException {
    final Map<String, String> map = new HashMap<>();

    if (System.getenv(CLIENT_ID) != null || System.getenv(CLIENT_SECRET) != null) {
      map.put(CLIENT_ID, System.getenv(CLIENT_ID) != null ? System.getenv(CLIENT_ID) : null);
      map.put(
          CLIENT_SECRET,
          System.getenv(CLIENT_SECRET) != null ? System.getenv(CLIENT_SECRET) : null);
    } else {
      Map<String, String> envVar = getEnvironmentVariablesStub();
      map.put(CLIENT_ID, envVar.get(CLIENT_ID));
      map.put("AWS_REGION", Regions.EU_WEST_2.getName());
      map.put(CLIENT_SECRET, envVar.get(CLIENT_SECRET));
    }
    return map;
  }

  public static Map<String, String> getEnvironmentVariablesStub() {
    Map<String, String> map = new HashMap<>();
    map.put(CLIENT_ID, "cmds-id");
    map.put(CLIENT_SECRET, "cmds-secret");
    map.put(ACCESS_TOKEN, "access-token");
    map.put("bc_auth_url", "BC_AUTH_URL");
    map.put(CALLBACK_URL, "https://wiremock.shared.cmdsiz.com/ors/invoke/v1/booking");
    return map;
  }

}