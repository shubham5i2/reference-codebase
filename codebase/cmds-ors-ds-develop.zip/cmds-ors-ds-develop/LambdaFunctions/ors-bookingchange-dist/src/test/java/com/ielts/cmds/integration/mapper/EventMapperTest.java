package com.ielts.cmds.integration.mapper;

import static com.ielts.cmds.integration.SQSEventBodySetup.getBookingDetails;
import static com.ielts.cmds.integration.SQSEventBodySetup.getCMDSErrorResponse019;
import static com.ielts.cmds.integration.SQSEventBodySetup.getCMDSErrorResponse019Null;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.stream.Stream;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.api.evt_019.BaseEventErrors;
import com.ielts.cmds.api.evt_019.BookingDetailsV1;
import com.ielts.cmds.api.evt_019.BookingLineV1;
import com.ielts.cmds.api.evt_019.TestTakerDetailsV1;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.integration.model.BookingLineResponse;
import com.ielts.cmds.integration.model.ExtORSResponse;
import com.ielts.cmds.integration.model.ORSBookingChangeResponse;
import com.ielts.cmds.integration.model.TestTakerResponse;

@ExtendWith(MockitoExtension.class)
public class EventMapperTest {

  @Spy @InjectMocks EventMapper eventMapper;

  @Mock
  BookingDetailsV1 bookingDetails;

  @Mock
  BaseEventErrors baseEventErrors;

  @Spy private ObjectMapper mapper;

  @BeforeEach
  public void setUp() throws Exception {
    mapper = getMapper();
    mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
    mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);

    bookingDetails = getBookingDetails();
    baseEventErrors = getCMDSErrorResponse019();
  }

  @Test
  void whenMapOrsExtResponseCalledWithNullDetailsAndNullErrors_ReturnExtResponse(){
    ExtORSResponse extORSResponse = eventMapper.mapExtOrsResponse(null,null);
    assertNull(extORSResponse.getResponse());
    assertNull(extORSResponse.getErrors());
    verify(eventMapper,times(1)).mapBookingResponse(null);
    verify(eventMapper,times(1)).mapBookingErrorResponse(null);
  }

  @Test
  void whenMapOrsExtResponseCalledWithDetailsAndNullErrors_ReturnExtResponse(){
    ExtORSResponse extORSResponse = eventMapper.mapExtOrsResponse(bookingDetails,null);
    assertEquals(bookingDetails.getBookingUuid(),extORSResponse.getResponse().getBookingUuid());
    assertEquals(bookingDetails.getExternalBookingUuid(),extORSResponse.getResponse().getExternalBookingUuid());
    assertEquals(bookingDetails.getBookingStatus(),extORSResponse.getResponse().getBookingStatus());
    assertEquals(bookingDetails.getTestTaker().getExternalUniqueTestTakerUuid(),extORSResponse.getResponse().getTestTaker().getExternalUniqueTestTakerUuid());
    assertEquals(bookingDetails.getTestTaker().getUniqueTestTakerUuid(),extORSResponse.getResponse().getTestTaker().getUniqueTestTakerUuid());
    assertEquals(bookingDetails.getTestTaker().getUniqueTestTakerId(),extORSResponse.getResponse().getTestTaker().getUniqueTestTakerId());
    assertEquals(bookingDetails.getTestTaker().getShortCandidateNumber(),extORSResponse.getResponse().getTestTaker().getShortCandidateNumber());
    assertEquals(bookingDetails.getTestTaker().getCompositeCandidateNumber(),extORSResponse.getResponse().getTestTaker().getCompositeCandidateNumber());
    assertEquals(bookingDetails.getTestTaker().getSebPassword(),extORSResponse.getResponse().getTestTaker().getSebPassword());
    assertEquals(bookingDetails.getTestTaker().getTestPlatformUsername(),extORSResponse.getResponse().getTestTaker().getTestPlatformUsername());
    assertEquals(bookingDetails.getTestTaker().getTestPlatformPassword(),extORSResponse.getResponse().getTestTaker().getTestPlatformPassword());
    assertEquals(bookingDetails.getTestTaker().getBannedStatus(),extORSResponse.getResponse().getTestTaker().getBannedStatus());
    assertEquals(bookingDetails.getBookingLines().get(0).getBookingLineUuid(),extORSResponse.getResponse().getBookingLines().get(0).getBookingLineUuid());
    assertEquals(bookingDetails.getBookingLines().get(0).getExternalBookingLineUuid(),extORSResponse.getResponse().getBookingLines().get(0).getExternalBookingLineUuid());
    assertNull(extORSResponse.getErrors());
    verify(eventMapper,times(1)).mapBookingResponse(bookingDetails);
    verify(eventMapper,times(1)).mapBookingErrorResponse(null);
  }

  @Test
  void whenMapOrsExtResponseCalledWithNullDetailsAndErrors_ReturnExtResponse(){
    ExtORSResponse extORSResponse = eventMapper.mapExtOrsResponse(null,baseEventErrors);
    assertEquals(baseEventErrors.getErrorList().get(0).getInterfaceName(),extORSResponse.getErrors().getErrorList().get(0).getInterfaceName());
    assertEquals(baseEventErrors.getErrorList().get(0).getType().toString(),extORSResponse.getErrors().getErrorList().get(0).getType().toString());
    assertEquals(baseEventErrors.getErrorList().get(0).getErrorCode(),extORSResponse.getErrors().getErrorList().get(0).getErrorCode());
    assertEquals(baseEventErrors.getErrorList().get(0).getErrorTicketUuid(),extORSResponse.getErrors().getErrorList().get(0).getErrorTicketUuid());
    assertEquals(baseEventErrors.getErrorList().get(0).getSource().getValue(),extORSResponse.getErrors().getErrorList().get(0).getSource().getValue());
    assertEquals(baseEventErrors.getErrorList().get(0).getSource().getPath(),extORSResponse.getErrors().getErrorList().get(0).getSource().getPath());
    assertEquals(baseEventErrors.getErrorList().get(0).getTitle(),extORSResponse.getErrors().getErrorList().get(0).getTitle());
    assertEquals(baseEventErrors.getErrorList().get(0).getMessage(),extORSResponse.getErrors().getErrorList().get(0).getMessage());
    verify(eventMapper,times(1)).mapBookingResponse(null);
    verify(eventMapper,times(1)).mapBookingErrorResponse(baseEventErrors);
  }
  @Test
  void whenMapOrsExtResponseCalledWithDetailsAndErrors_ReturnExtResponse(){
    ExtORSResponse extORSResponse = eventMapper.mapExtOrsResponse(bookingDetails,baseEventErrors);
    assertEquals(bookingDetails.getBookingUuid(),extORSResponse.getResponse().getBookingUuid());
    assertEquals(bookingDetails.getExternalBookingUuid(),extORSResponse.getResponse().getExternalBookingUuid());
    assertEquals(bookingDetails.getBookingStatus(),extORSResponse.getResponse().getBookingStatus());
    assertEquals(bookingDetails.getTestTaker().getExternalUniqueTestTakerUuid(),extORSResponse.getResponse().getTestTaker().getExternalUniqueTestTakerUuid());
    assertEquals(bookingDetails.getTestTaker().getUniqueTestTakerUuid(),extORSResponse.getResponse().getTestTaker().getUniqueTestTakerUuid());
    assertEquals(bookingDetails.getTestTaker().getUniqueTestTakerId(),extORSResponse.getResponse().getTestTaker().getUniqueTestTakerId());
    assertEquals(bookingDetails.getTestTaker().getShortCandidateNumber(),extORSResponse.getResponse().getTestTaker().getShortCandidateNumber());
    assertEquals(bookingDetails.getTestTaker().getCompositeCandidateNumber(),extORSResponse.getResponse().getTestTaker().getCompositeCandidateNumber());
    assertEquals(bookingDetails.getTestTaker().getSebPassword(),extORSResponse.getResponse().getTestTaker().getSebPassword());
    assertEquals(bookingDetails.getTestTaker().getTestPlatformUsername(),extORSResponse.getResponse().getTestTaker().getTestPlatformUsername());
    assertEquals(bookingDetails.getTestTaker().getTestPlatformPassword(),extORSResponse.getResponse().getTestTaker().getTestPlatformPassword());
    assertEquals(bookingDetails.getTestTaker().getBannedStatus(),extORSResponse.getResponse().getTestTaker().getBannedStatus());
    assertEquals(bookingDetails.getBookingLines().get(0).getBookingLineUuid(),extORSResponse.getResponse().getBookingLines().get(0).getBookingLineUuid());
    assertEquals(bookingDetails.getBookingLines().get(0).getExternalBookingLineUuid(),extORSResponse.getResponse().getBookingLines().get(0).getExternalBookingLineUuid());

    assertEquals(baseEventErrors.getErrorList().get(0).getInterfaceName(),extORSResponse.getErrors().getErrorList().get(0).getInterfaceName());
    assertEquals(baseEventErrors.getErrorList().get(0).getType().toString(),extORSResponse.getErrors().getErrorList().get(0).getType().toString());
    assertEquals(baseEventErrors.getErrorList().get(0).getErrorCode(),extORSResponse.getErrors().getErrorList().get(0).getErrorCode());
    assertEquals(baseEventErrors.getErrorList().get(0).getErrorTicketUuid(),extORSResponse.getErrors().getErrorList().get(0).getErrorTicketUuid());
    assertEquals(baseEventErrors.getErrorList().get(0).getSource().getValue(),extORSResponse.getErrors().getErrorList().get(0).getSource().getValue());
    assertEquals(baseEventErrors.getErrorList().get(0).getSource().getPath(),extORSResponse.getErrors().getErrorList().get(0).getSource().getPath());
    assertEquals(baseEventErrors.getErrorList().get(0).getTitle(),extORSResponse.getErrors().getErrorList().get(0).getTitle());
    assertEquals(baseEventErrors.getErrorList().get(0).getMessage(),extORSResponse.getErrors().getErrorList().get(0).getMessage());
    verify(eventMapper,times(1)).mapBookingResponse(bookingDetails);
    verify(eventMapper,times(1)).mapBookingErrorResponse(baseEventErrors);
  }

  /*
   * test to validate the bookingResponse against bookingdetails
   * and check booking details populated correctly
   */
  @Test
  public void whenBookingDetailsProvided_ThenValidatedBookingResponse() {
    // when
    ORSBookingChangeResponse ORSBookingChangeResponse = eventMapper.mapBookingResponse(bookingDetails);

    // then
    assertEquals(bookingDetails.getBookingUuid(), ORSBookingChangeResponse.getBookingUuid());
    assertEquals(bookingDetails.getExternalBookingUuid(), ORSBookingChangeResponse.getExternalBookingUuid());
    assertEquals(bookingDetails.getBookingStatus(), ORSBookingChangeResponse.getBookingStatus());
  }

  /*
   * test to validate the TestTakerResponse against Testtaker of bookingdetails
   * and check test taker details populated correctly
   */
  @Test
  public void whenBookingDetailsProvided_ThenValidatedTestTakerResponse() {
    // Given
    TestTakerDetailsV1 expectedTestTaker = bookingDetails.getTestTaker();

    // when
    ORSBookingChangeResponse ORSBookingChangeResponse = eventMapper.mapBookingResponse(bookingDetails);
    TestTakerResponse actualTestTaker = ORSBookingChangeResponse.getTestTaker();

    // then
    assertEquals(
            expectedTestTaker.getExternalUniqueTestTakerUuid(),
            actualTestTaker.getExternalUniqueTestTakerUuid());
    assertEquals(
            expectedTestTaker.getUniqueTestTakerUuid(), actualTestTaker.getUniqueTestTakerUuid());
    assertEquals(
            expectedTestTaker.getShortCandidateNumber(), actualTestTaker.getShortCandidateNumber());
    assertEquals(
            expectedTestTaker.getCompositeCandidateNumber(),
            actualTestTaker.getCompositeCandidateNumber());
    assertEquals(expectedTestTaker.getBannedStatus(), actualTestTaker.getBannedStatus());
  }
  /*
   * test to validate the TestTakerResponse against Testtaker of bookingdetails
   * and check test taker details fo reason for match null
   */
  @ParameterizedTest
  @MethodSource("argumentsForReasonForMatch")
  public void whenBookingDetailsProvided_ThenValidatedTestTakerResponseWithReasonForMatchNull(String reasonForMatch, String outcome) {
    // Given
    TestTakerDetailsV1 expectedTestTaker = bookingDetails.getTestTaker();
    expectedTestTaker.setReasonForMatch(reasonForMatch);
    expectedTestTaker.setUniqueTestTakerUuid(null);
    // when
    ORSBookingChangeResponse ORSBookingChangeResponse = eventMapper.mapBookingResponse(bookingDetails);
    TestTakerResponse actualTestTaker = ORSBookingChangeResponse.getTestTaker();
    // then

    assertNull(actualTestTaker.getUniqueTestTakerUuid());
    assertEquals(outcome, actualTestTaker.getMatchConfidenceLevel());
  }
  
  static Stream<Arguments> argumentsForReasonForMatch() {
	  return Stream.of(
			  Arguments.of(null, "MEDIUM"),
			  Arguments.of("NEW", "MEDIUM"),
			  Arguments.of("CHECK1", "HIGH"),
			  Arguments.of("MANUAL", "HIGH"),
			  Arguments.of("CHECK2", "MEDIUM"),
			  Arguments.of("CHECK3", "LOW"),
			  Arguments.of("INVALID", null));
  }

 
  /*
   * test to validate the BookingLineResponse against bookingline of bookingdetails
   * and check booking line details populated correctly
   */
  @Test
  public void whenBookingDetailsProvided_ThenValidatedBookingLineResponse() {
    // Given
    BookingLineV1 expectedBookingLine = bookingDetails.getBookingLines().get(0);

    // When
    ORSBookingChangeResponse ORSBookingChangeResponse = eventMapper.mapBookingResponse(bookingDetails);
    BookingLineResponse actualBookingLine = ORSBookingChangeResponse.getBookingLines().get(0);

    // then
    assertEquals(expectedBookingLine.getBookingLineUuid(), actualBookingLine.getBookingLineUuid());
    assertEquals(
            expectedBookingLine.getExternalBookingLineUuid(),
            actualBookingLine.getExternalBookingLineUuid());
  }

  /*
   * when there are null values within bookingdetails then verify those null values in bookingResponse
   */
  @Test
  public void whenBookingDetailsIsPassedWithNullValues_ThenVerifyBookingResponseForNullValues() {
    // Given
    bookingDetails.setBookingUuid(null);
    bookingDetails.setExternalBookingUuid(null);
    bookingDetails.setBookingStatus(null);
    bookingDetails.getTestTaker().setExternalUniqueTestTakerUuid(null);
    bookingDetails.getTestTaker().setShortCandidateNumber(null);
    bookingDetails.getTestTaker().setCompositeCandidateNumber(null);
    bookingDetails.getBookingLines().get(0).setBookingLineUuid(null);
    bookingDetails.getBookingLines().get(0).setExternalBookingLineUuid(null);
    bookingDetails.getBookingLines().get(0).setStartDateTime(null);

    // when
    ORSBookingChangeResponse ORSBookingChangeResponse = eventMapper.mapBookingResponse(bookingDetails);

    // then
    assertNull(ORSBookingChangeResponse.getBookingUuid());
    assertNull(ORSBookingChangeResponse.getExternalBookingUuid());
    assertNull(ORSBookingChangeResponse.getBookingStatus());
    assertNull(ORSBookingChangeResponse.getTestTaker().getExternalUniqueTestTakerUuid());
    assertNull(ORSBookingChangeResponse.getTestTaker().getShortCandidateNumber());
    assertNull(ORSBookingChangeResponse.getTestTaker().getCompositeCandidateNumber());
    assertNull(ORSBookingChangeResponse.getBookingLines().get(0).getBookingLineUuid());
    assertNull(ORSBookingChangeResponse.getBookingLines().get(0).getExternalBookingLineUuid());
  }

  /*
   * When booking lines in bookingDetails is null the booking lines in booking response is empty
   */
  @Test
  public void whenBookingLinesIsNull_ThenBookingResponseBookingLinesIsEmpty() {
    // given
    bookingDetails.setBookingLines(null);

    // when
    ORSBookingChangeResponse ORSBookingChangeResponse = eventMapper.mapBookingResponse(bookingDetails);

    // then
    assertTrue(ORSBookingChangeResponse.getBookingLines().isEmpty());
  }

  /*
   * test to check all TestTakerResponse fields are null when TestTaker in bookingDetails is null
   */
  @Test
  public void whenTestTakerIsNull_ThenCheckForNullFieldsInTestTakerResponse() {
    // Given
    bookingDetails.setTestTaker(null);

    // when
    ORSBookingChangeResponse ORSBookingChangeResponse = eventMapper.mapBookingResponse(bookingDetails);
    TestTakerResponse actualTestTaker = ORSBookingChangeResponse.getTestTaker();

    // then
    assertNull(actualTestTaker.getExternalUniqueTestTakerUuid());
    assertNull(actualTestTaker.getUniqueTestTakerUuid());
    assertNull(actualTestTaker.getShortCandidateNumber());
    assertNull(actualTestTaker.getCompositeCandidateNumber());
    assertNull(actualTestTaker.getBannedStatus());
  }



  /*
   * test to check all ErrorMapperResponse fields are provided when errors in BookingChangedV1 is not null
   */
  @Test
  public void whenErrorIsProvided_ThenCheckForFieldsInErrorMapperResponse() {
    // when
    com.ielts.cmds.infrastructure.event.BaseEventErrors errorResponse = eventMapper.mapBookingErrorResponse(baseEventErrors);

    // then
    assertEquals(errorResponse.getErrorList().get(0).getType(), ErrorTypeEnum.valueOf(baseEventErrors.getErrorList().get(0).getType().toString()));
    assertEquals(errorResponse.getErrorList().get(0).getMessage(),baseEventErrors.getErrorList().get(0).getMessage());
    assertEquals(errorResponse.getErrorList().get(0).getErrorCode(),baseEventErrors.getErrorList().get(0).getErrorCode());
    assertEquals(errorResponse.getErrorList().get(0).getErrorTicketUuid(),baseEventErrors.getErrorList().get(0).getErrorTicketUuid());
    assertEquals(errorResponse.getErrorList().get(0).getInterfaceName(),baseEventErrors.getErrorList().get(0).getInterfaceName());
    assertEquals(errorResponse.getErrorList().get(0).getTitle(),baseEventErrors.getErrorList().get(0).getTitle());
    assertEquals(errorResponse.getErrorList().get(0).getSource().getPath(),baseEventErrors.getErrorList().get(0).getSource().getPath());
    assertEquals(errorResponse.getErrorList().get(0).getSource().getValue(),baseEventErrors.getErrorList().get(0).getSource().getValue());
  }

  /*
   * test to check all ErrorMapperResponse fields are provided when errors in BookingChangedV1 is not null
   * Non-mandatory fields are null
   */
  @Test
  public void whenNonMandatoryErrorFieldsAreNull_ThenCheckForFieldsInErrorMapperResponse() {
    //given
    baseEventErrors = getCMDSErrorResponse019Null();
    // when
    com.ielts.cmds.infrastructure.event.BaseEventErrors errorResponse = eventMapper.mapBookingErrorResponse(baseEventErrors);

    // then
    assertNull(errorResponse.getErrorList().get(0).getMessage());
    assertNull(errorResponse.getErrorList().get(0).getSource());
  }

  /*
   * clean up the resources
   */
  @AfterEach
  public void tearDown() {
    bookingDetails = null;
    baseEventErrors = null;
  }

  protected ObjectMapper getMapper() {
    ObjectMapper mapper = new ObjectMapper();
    mapper.registerModule(new JavaTimeModule());
    mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
    mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
    mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    return mapper;
  }
}
