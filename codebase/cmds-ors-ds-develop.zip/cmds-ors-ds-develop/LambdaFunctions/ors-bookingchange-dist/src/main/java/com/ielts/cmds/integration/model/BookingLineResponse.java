package com.ielts.cmds.integration.model;

import java.util.UUID;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Getter
@Setter
@ToString
@EqualsAndHashCode
@NoArgsConstructor
public class BookingLineResponse {
  private UUID bookingLineUuid;
  private UUID externalBookingLineUuid;
}
