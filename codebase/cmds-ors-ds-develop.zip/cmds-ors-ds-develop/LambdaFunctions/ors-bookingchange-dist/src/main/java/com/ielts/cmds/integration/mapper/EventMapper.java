package com.ielts.cmds.integration.mapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import com.ielts.cmds.api.evt_019.BookingDetailsV1;
import com.ielts.cmds.api.evt_019.BookingLineV1;
import com.ielts.cmds.api.evt_019.TestTakerDetailsV1;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.integration.model.BookingLineResponse;
import com.ielts.cmds.integration.model.ExtORSResponse;
import com.ielts.cmds.integration.model.ORSBookingChangeResponse;
import com.ielts.cmds.integration.model.TestTakerResponse;

/** This class is used to map incoming event to appropriate API request body */
public class EventMapper {

    public ExtORSResponse mapExtOrsResponse(final BookingDetailsV1 bookingDetailsV1,final com.ielts.cmds.api.evt_019.BaseEventErrors baseEventErrors){
        return new ExtORSResponse(mapBookingResponse(bookingDetailsV1),mapBookingErrorResponse(baseEventErrors));
    }


    /**
     * Maps input event to booking response specific to request api body
     *
     * @param details
     * @return
     */
    public ORSBookingChangeResponse mapBookingResponse(final BookingDetailsV1 details) {
        if(details == null){
            return null;
        }
        final ORSBookingChangeResponse orsBookingChangeResponse = new ORSBookingChangeResponse();
        orsBookingChangeResponse.setBookingUuid(details.getBookingUuid());
        orsBookingChangeResponse.setExternalBookingUuid(details.getExternalBookingUuid());
        orsBookingChangeResponse.setBookingStatus(details.getBookingStatus());
        final TestTakerResponse testTakerResponse = populateTestTakerDetails(details);
        orsBookingChangeResponse.setTestTaker(testTakerResponse);
        final List<BookingLineResponse> bookingLinesResponse = populateBookingLines(details);
        orsBookingChangeResponse.setBookingLines(bookingLinesResponse);
        return orsBookingChangeResponse;
    }

    /*
     * creates test-taker response
     */
    private TestTakerResponse populateTestTakerDetails(final BookingDetailsV1 details) {
        final TestTakerResponse testTakerResponse = new TestTakerResponse();
        final Optional<TestTakerDetailsV1> optTestTaker = Optional.ofNullable(details.getTestTaker());
        optTestTaker.ifPresent(
                testTaker -> {
                    testTakerResponse.setExternalUniqueTestTakerUuid(
                            testTaker.getExternalUniqueTestTakerUuid());
                    if(Objects.nonNull(testTaker.getUniqueTestTakerUuid())){
                        testTakerResponse.setUniqueTestTakerUuid(testTaker.getUniqueTestTakerUuid());
                    }
                    testTakerResponse.setUniqueTestTakerId(testTaker.getUniqueTestTakerId());
                    if(Objects.nonNull(testTaker.getReasonForMatch())){
                        testTakerResponse.setMatchConfidenceLevel(getMatchConfidenceLevel(testTaker.getReasonForMatch()));
                    }else{
                        testTakerResponse.setMatchConfidenceLevel("MEDIUM");
                    }
                    testTakerResponse.setShortCandidateNumber(testTaker.getShortCandidateNumber());
                    testTakerResponse.setCompositeCandidateNumber(testTaker.getCompositeCandidateNumber());
                    testTakerResponse.setSebPassword(testTaker.getSebPassword());
                    testTakerResponse.setTestPlatformUsername(testTaker.getTestPlatformUsername());
                    testTakerResponse.setTestPlatformPassword(testTaker.getTestPlatformPassword());
                    testTakerResponse.setBannedStatus(testTaker.getBannedStatus());
                });
        return testTakerResponse;
    }

  private String getMatchConfidenceLevel(String reasonForMatch){
      String result=null;
      switch (reasonForMatch) {
        case "CHECK1":
        case "MANUAL":
          result = "HIGH";
          break;
        case "CHECK2":
        case "NEW":
          result = "MEDIUM";
          break;
        case "CHECK3":
          result = "LOW";
          break;
        default:
        	result = null;
    };
    return result;
  }

  /*
     * creates bookinglines response
     */
    private List<BookingLineResponse> populateBookingLines(final BookingDetailsV1 details) {
        final List<BookingLineResponse> bookingLinesResponse = new ArrayList<>();
        final Optional<List<BookingLineV1>> optBookingLines =
                Optional.ofNullable(details.getBookingLines());
        optBookingLines.ifPresent(
                bookingLines ->
                        bookingLines
                                .stream()
                                .forEach(
                                        bookingLine -> {
                                            final BookingLineResponse bookingLineResponse = new BookingLineResponse();
                                            bookingLineResponse.setBookingLineUuid(bookingLine.getBookingLineUuid());
                                            bookingLineResponse.setExternalBookingLineUuid(
                                                    bookingLine.getExternalBookingLineUuid());
                                            bookingLinesResponse.add(bookingLineResponse);
                                        })
        );
        return bookingLinesResponse;
    }

    public BaseEventErrors mapBookingErrorResponse(com.ielts.cmds.api.evt_019.BaseEventErrors eventErrors) {
        if(eventErrors == null){
            return null;
        }
        List<ErrorDescription> errorDescriptions;
        errorDescriptions = eventErrorMapper(eventErrors.getErrorList());
        return new BaseEventErrors(errorDescriptions);
    }

    List<ErrorDescription> eventErrorMapper(List<com.ielts.cmds.api.evt_019.ErrorDescription> errorDescription) {
        List<ErrorDescription> errorDescriptionList = new ArrayList<>();
        for(com.ielts.cmds.api.evt_019.ErrorDescription e : errorDescription){
            ErrorDescription description = new ErrorDescription();
            description.setInterfaceName(e.getInterfaceName());
            description.setTitle(e.getTitle());
            description.setType(ErrorTypeEnum.valueOf(e.getType().toString()));
            description.setErrorCode(e.getErrorCode());

            description.setErrorTicketUuid(e.getErrorTicketUuid());

            if(Objects.nonNull(e.getMessage())) {
                description.setMessage(e.getMessage());
            }
            if(Objects.nonNull(e.getSource())) {
                Source source = new Source(e.getSource().getPath(),e.getSource().getValue());
                description.setSource(source);
            }
            errorDescriptionList.add(description);
        }
        return errorDescriptionList;
    }
}
