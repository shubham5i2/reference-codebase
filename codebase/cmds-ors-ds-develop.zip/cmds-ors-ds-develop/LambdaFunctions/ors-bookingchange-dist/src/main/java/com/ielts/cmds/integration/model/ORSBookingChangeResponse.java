package com.ielts.cmds.integration.model;

import java.util.List;
import java.util.UUID;

import com.ielts.cmds.api.evt_019.BookingDetailsV1;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Getter
@Setter
@ToString
@EqualsAndHashCode
@NoArgsConstructor
public class ORSBookingChangeResponse {
    private UUID bookingUuid;
    private UUID externalBookingUuid;
    private BookingDetailsV1.BookingStatusEnum bookingStatus;
    private TestTakerResponse testTaker;
    private List<BookingLineResponse> bookingLines;
}
