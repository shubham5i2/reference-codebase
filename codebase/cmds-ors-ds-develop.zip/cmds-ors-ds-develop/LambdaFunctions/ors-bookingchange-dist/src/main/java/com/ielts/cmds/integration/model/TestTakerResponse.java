package com.ielts.cmds.integration.model;

import java.util.UUID;


import com.ielts.cmds.api.evt_019.TestTakerDetailsV1;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Getter
@Setter
@ToString
@EqualsAndHashCode
@NoArgsConstructor
public class TestTakerResponse {
  private UUID externalUniqueTestTakerUuid;
  private UUID uniqueTestTakerUuid;
  private String uniqueTestTakerId;
  private String matchConfidenceLevel;
  private String shortCandidateNumber;
  private String compositeCandidateNumber;
  private String sebPassword;
  private String testPlatformUsername;
  private String testPlatformPassword;
  private TestTakerDetailsV1.BannedStatusEnum bannedStatus;
}
