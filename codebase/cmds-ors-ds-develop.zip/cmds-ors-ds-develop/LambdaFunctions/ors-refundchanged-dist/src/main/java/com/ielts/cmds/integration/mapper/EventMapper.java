package com.ielts.cmds.integration.mapper;

import com.ielts.cmds.finance.common.out.model.RefundChangedV1;
import com.ielts.cmds.integration.model.CMDSResponseBody;
import com.ielts.cmds.integration.model.RefundRequestV1;

/**
 * This class is used to map incoming event to appropriate API request body
 */
public class EventMapper {

    public CMDSResponseBody mapRefundResponse(final RefundChangedV1 refundChangedV1) {
        final CMDSResponseBody refundV1 = new CMDSResponseBody();

        refundV1.setExternalBookingUuid(refundChangedV1.getExternalBookingUuid());

        final RefundRequestV1 refundRequestV1 = new RefundRequestV1();
        refundRequestV1.setExternalRefundRequestUuid(refundChangedV1.getExternalRefundRequestUuid());
        refundRequestV1.setRefundRequestUuid(refundChangedV1.getRefundRequestUuid());
        refundRequestV1.setRefundRequestStatus(refundChangedV1.getRefundRequestStatus());

        refundV1.setRefundRequest(refundRequestV1);
        return refundV1;
    }
}
