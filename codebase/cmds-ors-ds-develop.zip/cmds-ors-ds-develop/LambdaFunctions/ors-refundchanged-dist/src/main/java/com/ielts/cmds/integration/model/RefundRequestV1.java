package com.ielts.cmds.integration.model;

import java.util.UUID;

import com.ielts.cmds.finance.common.enums.RefundRequestStatusEnum;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode
@NoArgsConstructor
public class RefundRequestV1 {
    private UUID refundRequestUuid;

    private UUID externalRefundRequestUuid;

    private RefundRequestStatusEnum refundRequestStatus;
}
