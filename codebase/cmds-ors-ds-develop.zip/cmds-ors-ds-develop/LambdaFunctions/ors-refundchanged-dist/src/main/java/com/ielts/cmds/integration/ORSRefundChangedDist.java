package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.constants.DistORSConstants.BC;
import static com.ielts.cmds.integration.constants.DistORSConstants.CALLBACK_URL;
import static com.ielts.cmds.integration.constants.DistORSConstants.CORRELATIONID;
import static com.ielts.cmds.integration.constants.DistORSConstants.EVENT_DATE_TIME;
import static com.ielts.cmds.integration.constants.DistORSConstants.PARTNER_CODE;
import static com.ielts.cmds.integration.constants.DistORSConstants.TRANSACTIONID;
import static com.ielts.cmds.integration.constants.DistORSConstants.USER_AGENT;
import static com.ielts.cmds.integration.constants.DistORSConstants.USER_AGENT_KEY;
import static java.lang.String.format;

import java.security.KeyStoreException;
import java.security.cert.CertificateException;
import java.time.format.DateTimeFormatter;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validation;
import javax.validation.Validator;

import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.common.logger.util.CMDSLambdaLoggerUtil;
import com.ielts.cmds.finance.common.out.model.RefundChangedV1;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.exception.ORSDistException;
import com.ielts.cmds.integration.mapper.EventMapper;
import com.ielts.cmds.integration.model.CMDSResponseBody;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.exception.InvalidClientException;
import com.ielts.cmds.security.exception.TokenNotReceivedException;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

/**
 * This class serves the purpose of handling ors ds response to External system
 */

@Slf4j
public abstract class ORSRefundChangedDist {

    private final ObjectMapper mapper = new ObjectMapper();

    private final EnvironmentAwareAuthenticationClientFactory authenticationClientFactory;

    private AuthenticationClient authenticationClient;

    protected ORSRefundChangedDist() {
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
        this.authenticationClientFactory = new EnvironmentAwareAuthenticationClientFactory();
    }

    /**
     * This method will be triggered on events published to ORS queue. It reads SQS records,validate
     * it and post to external system(ORS)
     *
     * @param input
     * @param context
     */
    @SneakyThrows
    public void handleRequest(final SQSEvent input, final Context context) {
        for (SQSEvent.SQSMessage message : input.getRecords()) {
            final String sqsMessage = message.getBody();
            validateAndSendEventRequest(sqsMessage, context);
        }
    }

    /**
     * Validates and sends the received sqs message body for further processing
     *
     * @param sqsMessage
     * @param context
     */
    @SneakyThrows
    void validateAndSendEventRequest(final String sqsMessage, final Context context) {
        final BaseEvent<BaseHeader> cmdsEvent = validateHeadersAndBody(sqsMessage);
        final BaseHeader eventHeader = cmdsEvent.getEventHeader();
        final String eventName = eventHeader.getEventName();
        final UUID transactionId = eventHeader.getTransactionId();
        final String partnerCode = eventHeader.getPartnerCode();
        initializeLogger(transactionId, context);
        log.info("Event received in ORS DS : ors-refundchanged-dist with metadata as: {}",eventHeader);
        if (getPartnerCodeConstants().equalsIgnoreCase(partnerCode)) {
            mapAndSendExternalEvent(cmdsEvent, eventHeader);
        } else {
            log.trace("Not processing incoming message as partnerCode:{} does not match expected partnerCode:{} | TransactionId:{} | Event:{} | CorrelationId:{}", partnerCode, getPartnerCodeConstants(), transactionId, eventName, eventHeader.getCorrelationId());
        }
    }

    /**
     * This method validates event headers and event body.
     *
     * @param sqsMsg
     * @return
     * @throws JsonProcessingException
     */
    BaseEvent<BaseHeader> validateHeadersAndBody(final String sqsMsg) throws JsonProcessingException {

    	TypeReference<BaseEvent<BaseHeader>> typeRef = new TypeReference<BaseEvent<BaseHeader>>() {};
        BaseEvent<BaseHeader> cmdsEvent = mapper.readValue(sqsMsg, typeRef);
        final Validator cmdsEventValidator = Validation.buildDefaultValidatorFactory().getValidator();

        final Set<ConstraintViolation<BaseEvent<BaseHeader>>> eventViolations = cmdsEventValidator.validate(cmdsEvent);

        if (!CollectionUtils.isEmpty(eventViolations)) {

            final Set<String> errorMessageSet = eventViolations.stream()
                    .map(ConstraintViolation<BaseEvent<BaseHeader>>::getMessage)
                    .collect(Collectors.toSet());

            final String errorMessage = String.join(", ", errorMessageSet);
            log.warn("CMDS Event Validation failed- [%s] for the request %s", errorMessage, sqsMsg);
        }
        validateEventBody(cmdsEvent);
        return cmdsEvent;
    }

    /*
     * This method validates event body and eventErrors
     */
    void validateEventBody(final BaseEvent<BaseHeader> event) {
        if (StringUtils.isEmpty(event.getEventBody()) && event.getEventErrors() == null) {
            log.warn("Not a valid event. No event body and no event error: %s", event);
        }
    }

    /**
     * It processes and sends event body to appropriate external api resource based on EventType
     *
     * @param event
     * @param headers
     * @throws JsonProcessingException
     */
    void mapAndSendExternalEvent(@Valid final BaseEvent<BaseHeader> event, @Valid final BaseHeader headers) throws JsonProcessingException, JsonProcessingException {
        String extCallbackUrl = System.getenv(CALLBACK_URL);

        final EventMapper eventMapper = new EventMapper();

        CMDSResponseBody refundV1 = null;


        if (event.getEventBody() != null) {
            final com.ielts.cmds.finance.common.out.model.RefundChangedV1 refundDetails = mapper.readValue(event.getEventBody(), RefundChangedV1.class);
            refundV1 = eventMapper.mapRefundResponse(refundDetails);
        }

        postRequestToExternalAPI(refundV1, headers, extCallbackUrl);
    }

    /**
     * This method posts eventbody related to refund change events to external systems.
     *
     * @param cmdsResponseBody
     * @param eventHeader
     * @param externalUrl
     * @throws ORSDistException
     */
    void postRequestToExternalAPI(final CMDSResponseBody cmdsResponseBody, final BaseHeader eventHeader, final String externalUrl) {
        final UUID transactionId = eventHeader.getTransactionId();
        try {
            getAuthenticationClient(eventHeader.getPartnerCode());
            final HttpHeaders eventHeaders = getHttpHeaders(eventHeader);
            final HttpEntity<CMDSResponseBody> eventEntity = new HttpEntity<>(cmdsResponseBody, eventHeaders);
            final ResponseEntity<String> response = authenticationClient.getRestTemplate().exchange(externalUrl,HttpMethod.PUT, eventEntity, String.class);
            log.debug("Request success with StatusCode: {} and TransactionId: {} ", response.getStatusCode(), transactionId);
        } catch (Exception exception) {
            log.warn("TransactionId:%s - Exception on posting requestBody: %s", transactionId, exception);
        }
    }

    /**
     * constructs httpheader based on provided eventheader
     *
     * @param eventHeader
     * @return
     * @throws TokenNotReceivedException 
     * @throws KeyStoreException 
     * @throws CertificateException 
     * @throws JsonProcessingException 
     * @throws Exception
     */
    HttpHeaders getHttpHeaders(@Valid final BaseHeader eventHeader) throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException {
        final HttpHeaders httpHeaders = new HttpHeaders();

        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.set(TRANSACTIONID, eventHeader.getTransactionId().toString());
        if (eventHeader.getCorrelationId() != null) {
            httpHeaders.set(CORRELATIONID, eventHeader.getCorrelationId().toString());
        }
        httpHeaders.set(PARTNER_CODE, eventHeader.getPartnerCode());
        if (eventHeader.getPartnerCode() != null && eventHeader.getPartnerCode().equalsIgnoreCase(BC) &&
                System.getenv(USER_AGENT) != null && !System.getenv(USER_AGENT).equals("")) {
            httpHeaders.set(USER_AGENT_KEY, System.getenv(USER_AGENT));
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        httpHeaders.set(EVENT_DATE_TIME, Objects.isNull(eventHeader.getEventDateTime()) ? "" : eventHeader.getEventDateTime().format(formatter));

        httpHeaders.set(authenticationClient.getAuthorizationHeaderName(), authenticationClient.getAccessToken());
        return httpHeaders;
    }

    void getAuthenticationClient(String partnerCode) throws InvalidClientException, CertificateException, KeyStoreException, JsonProcessingException {
        if (authenticationClient == null) {
            authenticationClient = authenticationClientFactory.getAuthenticationClient(partnerCode);
        }
    }

    protected abstract String getPartnerCodeConstants();

    protected abstract String getApplicationName();

    /**
     * Method to initialize Logger Context for ors ds lambda
     *
     * @param transactionId
     * @param context
     */
    protected void initializeLogger(final UUID transactionId, final Context context) {
        final CMDSLambdaLoggerUtil loggerUtil = new CMDSLambdaLoggerUtil();
        loggerUtil.initializeThreadContextMap(transactionId.toString(), getApplicationName(), context.getAwsRequestId());
    }
}
