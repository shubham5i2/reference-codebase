package com.ielts.cmds.integration;

import com.ielts.cmds.integration.constants.DistORSConstants;

public class ORSRefundChangedDistBC extends ORSRefundChangedDist {


    @Override
    protected String getPartnerCodeConstants() {
        return DistORSConstants.BC;
    }

    @Override
    protected String getApplicationName() {
        return DistORSConstants.ORS_REFUNDCHANGED_DIST_BC;
    }
}
