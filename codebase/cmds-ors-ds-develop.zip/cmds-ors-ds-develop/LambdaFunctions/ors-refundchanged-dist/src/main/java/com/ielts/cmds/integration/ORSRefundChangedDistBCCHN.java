package com.ielts.cmds.integration;

import com.ielts.cmds.integration.constants.DistORSConstants;

public class ORSRefundChangedDistBCCHN extends ORSRefundChangedDist {

  @Override
  protected String getPartnerCodeConstants() {
    return DistORSConstants.BC_CHN;
  }

  @Override
  protected String getApplicationName() {
    return DistORSConstants.ORS_REFUNDCHANGED_DIST_BCCHN;
  }
}
