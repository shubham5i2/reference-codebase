package com.ielts.cmds.integration.model;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Getter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class CMDSResponseBody {
    private UUID externalBookingUuid;
    private RefundRequestV1 refundRequest;
}
