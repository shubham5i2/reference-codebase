package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.constants.DistORSConstants.ACCESS_TOKEN;
import static com.ielts.cmds.integration.constants.DistORSConstants.AUTH_HEADER;
import static com.ielts.cmds.integration.constants.DistORSConstants.CALLBACK_URL;
import static com.ielts.cmds.integration.constants.DistORSConstants.CORRELATIONID;
import static com.ielts.cmds.integration.constants.DistORSConstants.EVENT_DATE_TIME;
import static com.ielts.cmds.integration.constants.DistORSConstants.ORS_REFUNDCHANGED_DIST_BC;
import static com.ielts.cmds.integration.constants.DistORSConstants.REFUND_CHANGE_REJECTED;
import static com.ielts.cmds.integration.constants.DistORSConstants.TRANSACTIONID;
import static com.ielts.cmds.integration.constants.DistORSConstants.USER_AGENT;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.security.KeyStoreException;
import java.security.cert.CertificateException;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.amazonaws.services.lambda.runtime.events.SQSEvent.SQSMessage;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.finance.common.out.model.RefundChangedV1;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.constants.DistORSConstants;
import com.ielts.cmds.integration.exception.ORSDistException;
import com.ielts.cmds.integration.mapper.EventMapper;
import com.ielts.cmds.integration.model.CMDSResponseBody;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.clients.BritishCouncilAuthenticationClient;
import com.ielts.cmds.security.clients.BritishCouncilChinaAuthenticationClient;
import com.ielts.cmds.security.clients.IDPAuthenticationClient;
import com.ielts.cmds.security.exception.InvalidClientException;
import com.ielts.cmds.security.exception.TokenNotReceivedException;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;

@ExtendWith(MockitoExtension.class)
class ORSRefundChangedDistTest {
    @Spy
    private ORSRefundChangedDistBC refundRequestChangedDistBc;

    @Spy
    private ORSRefundChangedDistIDP refundRequestChangedDistIdp;

    @Spy
    private ORSRefundChangedDistBCCHN refundRequestChangedDistBcchn;

    @Mock
    private Context context;

    @Mock
    private RestTemplate restTemplate;
    private final ObjectMapper mapper = SQSEventBodySetup.getMapper();

    @Mock
    private EnvironmentAwareAuthenticationClientFactory authenticationFactory;

    @Mock
    BritishCouncilAuthenticationClient britishCouncilAuthenticationClient;

    @Mock
    private AuthenticationClient client;

    @Mock
    private IDPAuthenticationClient idpClient;

    @Mock
    private BritishCouncilChinaAuthenticationClient bcchnClient;

    private SQSEvent event;

    private SQSEvent eventIdp;

    private SQSEvent eventBcchn;

    private SQSMessage message;

    private SQSMessage messageIdp;

    private SQSMessage messageBcchn;

    @BeforeEach
    void setUp() throws JsonProcessingException {
    	event = new SQSEvent();
    	eventBcchn = new SQSEvent();
    	eventIdp = new SQSEvent();
    	message = new SQSMessage();
    	messageBcchn = new SQSMessage();
    	messageIdp = new SQSMessage();
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
        String eventBody = SQSEventBodySetup.getEventBody();
        message.setBody(eventBody);
        messageIdp.setBody(SQSEventBodySetup.getIDPEventBody());
        messageBcchn.setBody(SQSEventBodySetup.getBCCHNEventBody());
        List<SQSMessage> records = new ArrayList<>();
        records.add(message);
        event.setRecords(records);
        List<SQSMessage> recordIdps = new ArrayList<>();
        recordIdps.add(messageIdp);
        eventIdp.setRecords(recordIdps);
        List<SQSMessage> recordBcchns = new ArrayList<>();
        recordBcchns.add(messageBcchn);
        eventBcchn.setRecords(recordBcchns);
        ReflectionTestUtils.setField(refundRequestChangedDistBc, "authenticationClientFactory", authenticationFactory);
        ReflectionTestUtils.setField(refundRequestChangedDistBcchn, "authenticationClientFactory", authenticationFactory);
        ReflectionTestUtils.setField(refundRequestChangedDistIdp, "authenticationClientFactory", authenticationFactory);
    }

    /*
     * When event header is null then Throw exception ORSDistException("Event header does not exist")
     */
    @Test
    void whenEventHeaderIsNull_ThenThrowBookingDistException() throws JsonProcessingException {
        // Given
        String expectedExceptionMsg = "EventHeaders does not exist";
        TypeReference<BaseEvent<BaseHeader>> typeRef = new TypeReference<BaseEvent<BaseHeader>>() {};
        BaseEvent<BaseHeader> cmdsEvent = mapper.readValue(message.getBody(), typeRef);
        cmdsEvent.setEventHeader(null);
        cmdsEvent.setEventErrors(null);
        String eventBody = mapper.writeValueAsString(cmdsEvent);
        message.setBody(eventBody);
        // when
        assertThrows(NullPointerException.class, ()->refundRequestChangedDistBc.handleRequest(event, context));
    }

    /*
     * When event body is null then Throw exception ORSDistException("Event headers does not exist")
     */
    @Test
    void whenEventBodyIsNull_ThenThrowBookingDistException() throws JsonProcessingException {
        // Given
        String expectedExceptionMsg = "EventHeaders does not exist";
        TypeReference<BaseEvent<BaseHeader>> typeRef = new TypeReference<BaseEvent<BaseHeader>>() {};
        BaseEvent<BaseHeader> cmdsEvent = mapper.readValue(message.getBody(), typeRef);
        cmdsEvent.setEventHeader(null);
        cmdsEvent.setEventErrors(null);
        cmdsEvent.setEventBody("");
        String eventBody = mapper.writeValueAsString(cmdsEvent);
        message.setBody(eventBody);
        // when
        assertThrows(NullPointerException.class,()->refundRequestChangedDistBc.handleRequest(event, context));
    }

    /*
     * When transactionId is null or empty then Throw exception ORSDistException("Transaction id does not exist")
     */

    @Test
    void whenTransactionIdIsNull_ThenThrowBookingDistException() throws JsonProcessingException {
        // Given
        String expectedExceptionMsg = "Transaction ID can't be null";
        TypeReference<BaseEvent<BaseHeader>> typeRef = new TypeReference<BaseEvent<BaseHeader>>() {};
        BaseEvent<BaseHeader> cmdsEvent = mapper.readValue(message.getBody(), typeRef);
        cmdsEvent.getEventHeader().setTransactionId(null);
        cmdsEvent.setEventErrors(null);
        String eventBody = mapper.writeValueAsString(cmdsEvent);
        message.setBody(eventBody);

        // when
        assertThrows(NullPointerException.class, ()->refundRequestChangedDistBc.handleRequest(event, context));
    }

    /*
     * When EventType is null or empty then Throw exception ORSDistException("EventType does not exist")
     */
    @Test
    void whenEventTypeIsNull_ThenThrowBookingDistException() throws JsonProcessingException {
        // Given
        String expectedExceptionMsg = "EventName can't be null or empty";
        TypeReference<BaseEvent<BaseHeader>> typeRef = new TypeReference<BaseEvent<BaseHeader>>() {};
        BaseEvent<BaseHeader> cmdsEvent = mapper.readValue(message.getBody(), typeRef);
        cmdsEvent.getEventHeader().setEventName("");
        cmdsEvent.setEventErrors(null);
        String eventBody = mapper.writeValueAsString(cmdsEvent);
        message.setBody(eventBody);

        // when
        		assertDoesNotThrow( ()->refundRequestChangedDistBc.handleRequest(event, context));
    }


    @Test
    void testExtBookingResponseModel_ValidateNull() throws JsonProcessingException {
        CMDSResponseBody extResponse = new CMDSResponseBody(null, null);
        assertNull(extResponse.getRefundRequest());
        assertNull(extResponse.getExternalBookingUuid());
    }

    @Test
    void testExtBookingResponseModel_ValidateNotNull() throws JsonProcessingException {
        final EventMapper eventMapper = new EventMapper();

        final RefundChangedV1 refundRequestedDetails =
                mapper.readValue(SQSEventBodySetup.getEventBody(), RefundChangedV1.class);
        CMDSResponseBody responseBody = eventMapper.mapRefundResponse(refundRequestedDetails);
        assertNotNull(responseBody);
    }

    /*
     * clean up resources
     */
    @AfterEach
    void tearDown() {
        message = null;
        event = null;
    }


    /**
     * constructs httpheader based on provided eventheader
     *
     * @param eventHeader
     * @return
     */
    private HttpHeaders getHttpHeaders(BaseHeader eventHeader) {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.set(TRANSACTIONID, eventHeader.getTransactionId().toString());
        httpHeaders.set(CORRELATIONID, eventHeader.getCorrelationId().toString());

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        httpHeaders.set(
                EVENT_DATE_TIME,
                Objects.isNull(eventHeader.getEventDateTime())
                        ? ""
                        : eventHeader.getEventDateTime().format(formatter));
        return httpHeaders;
    }

    @Test
    void whenBCRequestHasValidAuthenticationHeader_ThenVerifyCallToRestTemplate() throws Exception {
        //Prepare test data
    	TypeReference<BaseEvent<BaseHeader>> typeRef = new TypeReference<BaseEvent<BaseHeader>>() {};
        BaseEvent<BaseHeader> baseEvent = mapper.readValue(message.getBody(), typeRef);
        Map<String, String> map = new HashMap<>();
        map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
        map.put(CALLBACK_URL, SQSEventBodySetup.getEnvironmentVariablesStub().get(CALLBACK_URL));
        map.put(AUTH_HEADER, "Authorization");
        map.put(USER_AGENT, "CMDS");
        ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.OK);
        HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
        eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));
        //Define mock variables behaviour
        when(authenticationFactory.getAuthenticationClient(baseEvent.getEventHeader().getPartnerCode())).thenReturn(britishCouncilAuthenticationClient);
        ReflectionTestUtils.setField(refundRequestChangedDistBc, "authenticationClientFactory", authenticationFactory);
        doReturn("authHeaderName").when(britishCouncilAuthenticationClient).getAuthorizationHeaderName();
        doReturn("accessToken").when(britishCouncilAuthenticationClient).getAccessToken();
        doReturn(restTemplate).when(britishCouncilAuthenticationClient).getRestTemplate();
        when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.eq(HttpMethod.PUT), ArgumentMatchers.<HttpEntity<CMDSResponseBody>>any(), ArgumentMatchers.<Class<String>>any())).thenReturn(response2);


        SQSEventBodySetup.setEnviornment(map);
        
        assertDoesNotThrow(() -> refundRequestChangedDistBc.handleRequest(event, context));
    }

    @Test
    void whenBCRequestHasInValidAuthenticationHeader_ThenThrowsException() throws JsonProcessingException, CertificateException, KeyStoreException, InvalidClientException, TokenNotReceivedException {
        //Prepare test data
    	TypeReference<BaseEvent<BaseHeader>> typeRef = new TypeReference<BaseEvent<BaseHeader>>() {};
        BaseEvent<BaseHeader> baseEvent = mapper.readValue(message.getBody(), typeRef);
        Map<String, String> map = new HashMap<>();
        map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
        map.put(AUTH_HEADER, "Authorization");
        ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
        eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));
        //Define mock variables behaviour
        when(authenticationFactory.getAuthenticationClient(baseEvent.getEventHeader().getPartnerCode())).thenReturn(britishCouncilAuthenticationClient);
        ReflectionTestUtils.setField(refundRequestChangedDistBc, "authenticationClientFactory", authenticationFactory);
        doReturn("authHeaderName").when(britishCouncilAuthenticationClient).getAuthorizationHeaderName();
        doReturn("accessToken").when(britishCouncilAuthenticationClient).getAccessToken();
        doReturn(restTemplate).when(britishCouncilAuthenticationClient).getRestTemplate();
        when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.eq(HttpMethod.PUT), ArgumentMatchers.<HttpEntity<CMDSResponseBody>>any(), ArgumentMatchers.<Class<String>>any())).thenReturn(response2);
        //Execute and assert test
        assertDoesNotThrow( () -> refundRequestChangedDistBc.handleRequest(event, context));
    }

    @Test
    void whenBCRequestHasInvalidAuthenticationHeader_ThenDoesNotThrowException() throws Exception {
        //Prepare test data
    	TypeReference<BaseEvent<BaseHeader>> typeRef = new TypeReference<BaseEvent<BaseHeader>>() {};
        BaseEvent<BaseHeader> baseEvent = mapper.readValue(message.getBody(), typeRef);
        Map<String, String> map = new HashMap<>();
        map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
        map.put(CALLBACK_URL, SQSEventBodySetup.getEnvironmentVariablesStub().get(CALLBACK_URL));
        map.put(AUTH_HEADER, "Authorization");
        SQSEventBodySetup.setEnviornment(map);
        ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.OK);
        HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
        eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));
        //Define mock variables behaviour
        when(authenticationFactory.getAuthenticationClient(baseEvent.getEventHeader().getPartnerCode())).thenReturn(britishCouncilAuthenticationClient);
        ReflectionTestUtils.setField(refundRequestChangedDistBc, "authenticationClientFactory", authenticationFactory);
        doReturn("authHeaderName").when(britishCouncilAuthenticationClient).getAuthorizationHeaderName();
        doReturn("accessToken").when(britishCouncilAuthenticationClient).getAccessToken();
        doReturn(restTemplate).when(britishCouncilAuthenticationClient).getRestTemplate();
        when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.eq(HttpMethod.PUT), ArgumentMatchers.<HttpEntity<CMDSResponseBody>>any(), ArgumentMatchers.<Class<String>>any())).thenReturn(response2);

        assertDoesNotThrow(() -> refundRequestChangedDistBc.handleRequest(event, context));
    }


    @Test
    void whenIDPRequestHasInValidAuthenticationHeader_ThenThrowsException() throws JsonProcessingException, CertificateException, KeyStoreException, InvalidClientException, TokenNotReceivedException {
    	TypeReference<BaseEvent<BaseHeader>> typeRef = new TypeReference<BaseEvent<BaseHeader>>() {};
        BaseEvent<BaseHeader> baseEvent = mapper.readValue(message.getBody(), typeRef);
        Map<String, String> map = new HashMap<>();
        map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
        //map.put(ACCESS_TOKEN, com.ielts.cmds.integration.utils.SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
        map.put(AUTH_HEADER, "Authorization");
        ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.BAD_GATEWAY);
        HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
        eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));
        //Define mock variables behaviour
        when(authenticationFactory.getAuthenticationClient(baseEvent.getEventHeader().getPartnerCode())).thenReturn(idpClient);
        ReflectionTestUtils.setField(refundRequestChangedDistIdp, "authenticationClientFactory", authenticationFactory);
        doReturn("authHeaderName").when(idpClient).getAuthorizationHeaderName();
        doReturn("accessToken").when(idpClient).getAccessToken();
        doReturn(restTemplate).when(idpClient).getRestTemplate();
        when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.eq(HttpMethod.PUT), ArgumentMatchers.<HttpEntity<CMDSResponseBody>>any(), ArgumentMatchers.<Class<String>>any())).thenReturn(response2);


        //Execute and assert test
        assertDoesNotThrow( () -> refundRequestChangedDistIdp.handleRequest(eventIdp, context));
    }

    @Test
    void whenBCCHNRequestHasInValidAuthenticationHeader_ThenThrowsException() throws JsonProcessingException, CertificateException, KeyStoreException, InvalidClientException, TokenNotReceivedException {
    	TypeReference<BaseEvent<BaseHeader>> typeRef = new TypeReference<BaseEvent<BaseHeader>>() {};
        BaseEvent<BaseHeader> baseEvent = mapper.readValue(message.getBody(), typeRef);
        Map<String, String> map = new HashMap<>();
        map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
        //map.put(ACCESS_TOKEN, com.ielts.cmds.integration.utils.SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
        map.put(AUTH_HEADER, "Authorization");
        ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.BAD_GATEWAY);
        HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
        eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));
        //Define mock variables behaviour
        when(authenticationFactory.getAuthenticationClient(baseEvent.getEventHeader().getPartnerCode())).thenReturn(bcchnClient);
        doReturn("authHeaderName").when(bcchnClient).getAuthorizationHeaderName();
        doReturn("accessToken").when(bcchnClient).getAccessToken();
        doReturn(restTemplate).when(bcchnClient).getRestTemplate();
        when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.eq(HttpMethod.PUT), ArgumentMatchers.<HttpEntity<CMDSResponseBody>>any(), ArgumentMatchers.<Class<String>>any())).thenReturn(response2);

        //Execute and assert test
        assertDoesNotThrow(() -> refundRequestChangedDistBcchn.handleRequest(eventBcchn, context));
    }

    @Test
    void getApplicationName_whenGetApplicationName_thenReturnInvalidApplicationNameForBC() {
        String applicationName = refundRequestChangedDistBc.getApplicationName();
        // Then
        assertEquals(ORS_REFUNDCHANGED_DIST_BC, applicationName);
    }

    @Test
    void getApplicationName_whenGetApplicationName_thenReturnInvalidApplicationNameForIDP() {
        String applicationName = refundRequestChangedDistIdp.getApplicationName();
        // Then
        assertEquals(DistORSConstants.ORS_REFUNDCHANGED_DIST_IDP, applicationName);
    }

    @Test
    void getApplicationName_whenGetApplicationName_thenReturnInvalidApplicationNameForBCCHN() {
        String applicationName = refundRequestChangedDistBcchn.getApplicationName();
        // Then
        assertEquals(DistORSConstants.ORS_REFUNDCHANGED_DIST_BCCHN, applicationName);
    }

    @Test
    void getPartnerCodeConstants_whenGetPartnerCodeConstants_thenReturnBC() {
        String partnerCodeConstants = refundRequestChangedDistBc.getPartnerCodeConstants();
        // Then
        assertEquals(DistORSConstants.BC, partnerCodeConstants);
    }

    @Test
    void getPartnerCodeConstants_whenGetPartnerCodeConstants_thenReturnIDP() {
        String partnerCodeConstants = refundRequestChangedDistIdp.getPartnerCodeConstants();
        // Then
        assertEquals(DistORSConstants.IDP, partnerCodeConstants);
    }

    @Test
    void getPartnerCodeConstants_whenGetPartnerCodeConstants_thenReturnBCCHN() {
        String partnerCodeConstants = refundRequestChangedDistBcchn.getPartnerCodeConstants();
        // Then
        assertEquals(DistORSConstants.BC_CHN, partnerCodeConstants);
    }

    @Test
    void whenNotNullEventErrorsAndEventTypeContainsRejected_ThenThrowBookingDistException()
            throws Exception {
    	TypeReference<BaseEvent<BaseHeader>> typeRef = new TypeReference<BaseEvent<BaseHeader>>() {};
        BaseEvent<BaseHeader> cmdsEvent = mapper.readValue(message.getBody(), typeRef);
        cmdsEvent.getEventHeader().setEventName(REFUND_CHANGE_REJECTED);

        cmdsEvent.setEventErrors(SQSEventBodySetup.getCMDSErrorResponse());
        String eventBody = mapper.writeValueAsString(cmdsEvent);
        message.setBody(eventBody);
        cmdsEvent.setEventBody(eventBody);

        Map<String, String> map = new HashMap<>();
        map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
        map.put(AUTH_HEADER, "Authorization");
        HttpHeaders eventHeaders = getHttpHeaders(cmdsEvent.getEventHeader());
        eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));

        // then
        assertDoesNotThrow( ()->refundRequestChangedDistBc.handleRequest(event, context));

    }
    
    @Test
    void validateAndSendEventRequest_ExpectError() throws Exception {
    	TypeReference<BaseEvent<BaseHeader>> typeRef = new TypeReference<BaseEvent<BaseHeader>>() {};
        BaseEvent<BaseHeader> cmdsEvent = mapper.readValue(message.getBody(), typeRef);
        cmdsEvent.getEventHeader().setPartnerCode("IDP");
    	doReturn(cmdsEvent).when(refundRequestChangedDistBc).validateHeadersAndBody(message.getBody());
    	doNothing().when(refundRequestChangedDistBc).initializeLogger(cmdsEvent.getEventHeader().getTransactionId(), context);
    	refundRequestChangedDistBc.validateAndSendEventRequest(message.getBody(), context);
    	verify(refundRequestChangedDistBc, never()).mapAndSendExternalEvent(ArgumentMatchers.any(), ArgumentMatchers.any());
    }
    
    @Test
    void validateEventBody_ExpectException() throws JsonProcessingException {
    	TypeReference<BaseEvent<BaseHeader>> typeRef = new TypeReference<BaseEvent<BaseHeader>>() {};
        BaseEvent<BaseHeader> cmdsEvent = mapper.readValue(message.getBody(), typeRef);
        cmdsEvent.setEventBody(null);
        cmdsEvent.setEventErrors(null);
        assertDoesNotThrow( ()->refundRequestChangedDistBc.validateEventBody(cmdsEvent));
    }
    
}
