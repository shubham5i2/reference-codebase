package com.ielts.cmds.integration;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.ielts.cmds.integration.constants.DistORSConstants;

@ExtendWith(MockitoExtension.class)
class ORSRefundChangedDistIDPTest {

    @InjectMocks
    private ORSRefundChangedDistIDP orsRefundChangedDistIDP;
    @Mock
    private Context context;
    @Mock
    private SQSEvent event;
    @Mock
    private LambdaLogger lambdaLogger;

    @Test
    void getPartnerCodeConstants_whengetPartnerCodeConstants_thenReturnIDP() {
        String partnerCodeConstants = orsRefundChangedDistIDP.getPartnerCodeConstants();
        // Then
        assertEquals(DistORSConstants.IDP, partnerCodeConstants);
    }
}
