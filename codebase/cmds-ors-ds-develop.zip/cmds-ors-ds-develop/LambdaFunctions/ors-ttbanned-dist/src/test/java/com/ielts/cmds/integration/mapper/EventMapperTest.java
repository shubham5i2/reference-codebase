package com.ielts.cmds.integration.mapper;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.booking.common.out.model.BanDetailsV1;
import com.ielts.cmds.booking.common.out.model.TestTakerBanV1;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.SQSEventBodySetup;
import com.ielts.cmds.integration.model.ORSTtBannedResponse;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

@RunWith(MockitoJUnitRunner.class)
public class EventMapperTest {

    @InjectMocks
    EventMapper eventMapper;

    @Mock
    TestTakerBanV1 details;

    @Spy
    private ObjectMapper mapper;

    @Before
    public void setUp() throws Exception {
        mapper = getMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);

        String sqsMsg = SQSEventBodySetup.getEventBody();
        BaseEvent<BaseHeader> cmdsEvent = mapper.readValue(sqsMsg, new TypeReference<BaseEvent<BaseHeader>>() {
        });
        details = mapper.readValue(cmdsEvent.getEventBody(), TestTakerBanV1.class);
    }

    /*
     * test to validate the ORSTtBannedResponse against BannedCandidateDetails
     * and check booking details populated correctly
     */
    @Test
    public void whenBannedCandidateDetailsProvided_ThenValidatedORSTtBannedResponse() {
        // when
        ORSTtBannedResponse response = eventMapper.mapBannedResponse(details);

        // then
        assertEquals(details.getUniqueTestTakerUuid(), response.getUniqueTestTakerUuid());
        assertEquals(details.getUniqueTestTakerId(), response.getUniqueTestTakerId());
//    assertEquals(details.getUniqueTestTakerUuid(),response.getUniqueTestTakerUuid());
    }

    /*
     * when there are null values within BannedCandidateDetails then verify those null values in ORSTtBannedResponse
     */
    @Test
    public void whenBannedCandidateDetailsIsPassedWithNullValues_ThenVerifyORSTtBannedResponseForNullValues() {
        // Given
        details.setDetails(BanDetailsV1.builder()
                .banUuid(null)
                .banReasonUuid(null)
                .locations(null)
                .startDate(null)
                .endDate(null)
                .comment(null)
                .build());
        details.setUniqueTestTakerUuid(null);
        details.setUniqueTestTakerId(null);

        // when
        ORSTtBannedResponse response = eventMapper.mapBannedResponse(details);

        // then
        assertNull(response.getUniqueTestTakerUuid());
        assertNull(response.getUniqueTestTakerId());
        assertNull(response.getDetails().getBanReasonUuid());
        assertNull(response.getDetails().getBanUuid());
        assertNull(response.getDetails().getComment());
        assertNull(response.getDetails().getLocations());
        assertNull(response.getDetails().getStartDate());
        assertNull(response.getDetails().getEndDate());
    }


    /*
     * clean up the resources
     */
    @After
    public void tearDown() {
        details = null;
    }

    protected ObjectMapper getMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        return mapper;
    }
}
