package com.ielts.cmds.integration;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.ielts.cmds.integration.constants.DistORSConstants;

@RunWith(MockitoJUnitRunner.class)
public class ORSTtBannedDistIDPTest {

  @InjectMocks private ORSTtBannedDistIDP bookingTtBannedDistIDP;
  @Mock private Context context;
  @Mock private SQSEvent event;
  @Mock private LambdaLogger lambdaLogger;

  @Test
  public void getPartnerCodeConstants_whenGetPartnerCodeConstants_thenReturnBC() {
    String partnerCodeConstants = bookingTtBannedDistIDP.getPartnerCodeConstants();
    //Then
    assertEquals(DistORSConstants.IDP, partnerCodeConstants);
  }
}
