package com.ielts.cmds.integration;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.amazonaws.services.lambda.runtime.events.SQSEvent.SQSMessage;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.constants.DistORSConstants;
import com.ielts.cmds.integration.exception.ORSDistException;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.clients.BritishCouncilAuthenticationClient;
import com.ielts.cmds.security.clients.BritishCouncilChinaAuthenticationClient;
import com.ielts.cmds.security.clients.IDPAuthenticationClient;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;
import com.ielts.cmds.security.utils.SecurityUtility;
import org.junit.*;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.*;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.time.format.DateTimeFormatter;
import java.util.*;

import static com.ielts.cmds.integration.constants.DistORSConstants.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ORSTtBannedDistTest {
    @InjectMocks
    private ORSTtBannedDistBC orsDistbc;
    @InjectMocks
    private ORSTtBannedDistIDP orsDistIdp;
    @InjectMocks
    private ORSTtBannedDistBCCHN orsDIstBcchn;
    @Mock
    private Context context;
    @Mock
    private RestTemplate restTemplate;
    private final ObjectMapper mapper = SQSEventBodySetup.getMapper();
    @Mock
    private EnvironmentAwareAuthenticationClientFactory authenticationFactory;
    @Mock
    BritishCouncilAuthenticationClient britishCouncilAuthenticationClient;
    @Mock
    private AuthenticationClient client;
    @Mock
    private IDPAuthenticationClient idpClient;
    @Mock
    private BritishCouncilChinaAuthenticationClient bcchnClient;
    @Spy
    private SQSEvent event;
    @Spy
    private SQSEvent eventIdp;
    @Spy
    private SQSEvent eventBcchn;
    @Spy
    private SQSMessage message;
    @Spy
    private SQSMessage messageIdp;
    @Spy
    private SQSMessage messageBcchn;
    @Mock
    private List<String> rejectedEvents;
    @InjectMocks
    @Rule
    public final ExpectedException exceptionRule = ExpectedException.none();
    static MockedStatic<SecurityUtility> lambdaUtilityMockedStatic;

    @BeforeClass
    public static void beforeClass() throws Exception {
        Map<String, String> envVar = SQSEventBodySetup.getEnvironmentVariablesStub();
    }

    @AfterClass
    public static void afterClass() throws Exception {
        Mockito.framework().clearInlineMocks();
    }

    @Before
    public void setUp() throws JsonProcessingException {
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);

        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
        String eventBody = SQSEventBodySetup.getEventBody();
        message.setBody(eventBody);
        messageIdp.setBody(SQSEventBodySetup.getIDPEventBody());
        List<SQSMessage> records = new ArrayList<>();
        records.add(message);
        event.setRecords(records);
        List<SQSMessage> recordIdps = new ArrayList<>();
        recordIdps.add(messageIdp);
        eventIdp.setRecords(recordIdps);
    }

    /*
     * When event header is null then Throw exception ORSDistException("Event headers does not exist")
     */
    @Test
    public void whenEventHeaderIsNull_ThenThrowORSDistException() throws Exception {
        // Given/
        String expectedExceptionMsg = "EventHeaders does not exist";
        BaseEvent<BaseHeader> cmdsEvent = mapper.readValue(message.getBody(), BaseEvent.class);
        cmdsEvent.setEventHeader(null);
        cmdsEvent.setEventErrors(null);
        String eventBody = mapper.writeValueAsString(cmdsEvent);
        message.setBody(eventBody);

        // then
        exceptionRule.expect(ORSDistException.class);
        exceptionRule.expectMessage(expectedExceptionMsg);

        // when
        orsDistbc.handleRequest(event, context);
    }

    /*
     * When event body is null then Throw exception ORSDistException("Event headers does not exist")
     */
    @Test
    public void whenEventBodyIsNull_ThenThrowORSDistException() throws Exception {
        // Given
        String expectedExceptionMsg = "EventHeaders does not exist";
        BaseEvent<BaseHeader> cmdsEvent = mapper.readValue(message.getBody(), BaseEvent.class);
        cmdsEvent.setEventHeader(null);
        cmdsEvent.setEventErrors(null);
        cmdsEvent.setEventBody("");
        String eventBody = mapper.writeValueAsString(cmdsEvent);
        message.setBody(eventBody);

        // then
        exceptionRule.expect(ORSDistException.class);
        exceptionRule.expectMessage(expectedExceptionMsg);

        // when
        orsDistbc.handleRequest(event, context);
    }

    @Test
    public void whenRejectEventWithBodyEmpty_ThenThrowORSDistException() throws Exception {
        // Given
        String expectedExceptionMsg = "No event body to publish for sqs message";
        BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
        cmdsEvent.setEventHeader(SQSEventBodySetup.getBookingRejectEventHeader());
        cmdsEvent.setEventErrors(null);
        cmdsEvent.setEventBody("");
        String eventBody = mapper.writeValueAsString(cmdsEvent);
        message.setBody(eventBody);

        // then
        exceptionRule.expect(ORSDistException.class);

        // when
        orsDistbc.handleRequest(event, context);
    }

    @Test
    public void whenRejectEventWithBody_ThenThrowORSDistException() throws Exception {
        // Given
        String expectedExceptionMsg = "No event errors to publish for sqs message";
        BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
        cmdsEvent.setEventHeader(SQSEventBodySetup.getEmptyEventEventHeader());
        cmdsEvent.setEventErrors(null);
        cmdsEvent.setEventBody(message.getBody());
        String eventBody = mapper.writeValueAsString(cmdsEvent);
        message.setBody(eventBody);

        // then
        exceptionRule.expect(ORSDistException.class);
        //exceptionRule.expectMessage(expectedExceptionMsg);

        // when
        orsDistbc.handleRequest(event, context);
    }

    /*
     * When transactionId is null or empty then Throw exception ORSDistException("Transaction id does not exist")
     */
    @Test
    public void whenTransactionIdIsNull_ThenThrowORSDistException() throws Exception {
        // Given
        String expectedExceptionMsg = "Transaction ID can't be null";
        BaseEvent<BaseHeader> cmdsEvent = mapper.readValue(message.getBody(), BaseEvent.class);
        cmdsEvent.getEventHeader().setTransactionId(null);
        cmdsEvent.setEventErrors(null);
        String eventBody = mapper.writeValueAsString(cmdsEvent);
        message.setBody(eventBody);

        // then
        exceptionRule.expect(ORSDistException.class);
        exceptionRule.expectMessage(expectedExceptionMsg);

        // when
        orsDistbc.handleRequest(event, context);
    }


    /*
     * When EventType is null or empty then Throw exception ORSDistException("EventType does not exist")
     */
    @Test
    public void whenEventTypeIsNull_ThenThrowORSDistException() throws Exception {
        // Given
        String expectedExceptionMsg = "EventName can't be null or empty";
        BaseEvent<BaseHeader> cmdsEvent = mapper.readValue(message.getBody(), BaseEvent.class);
        cmdsEvent.getEventHeader().setEventName(null);
        cmdsEvent.setEventErrors(null);
        String eventBody = mapper.writeValueAsString(cmdsEvent);
        message.setBody(eventBody);

        // then
        exceptionRule.expect(ORSDistException.class);
        exceptionRule.expectMessage(expectedExceptionMsg);

        // when
        orsDistbc.handleRequest(event, context);
    }

    /*
     * When event body is null and eventType does not contain rejected then Throw exception ORSDistException("No event body to publish")
     */
    @Test
    public void whenNullEventBodyAndEventTypeNotContainRejected_ThenThrowORSDistException()
            throws Exception {
        // Given
        String expectedExceptionMsg = "No event body to publish for sqs message";
        BaseEvent<BaseHeader> cmdsEvent = mapper.readValue(message.getBody(), BaseEvent.class);
        cmdsEvent.setEventBody(null);
        String eventBody = mapper.writeValueAsString(cmdsEvent);
        message.setBody(eventBody);

        // then
        exceptionRule.expect(ORSDistException.class);
        exceptionRule.expectMessage(expectedExceptionMsg);

        // when
        orsDistbc.handleRequest(event, context);
    }

    /*
     * When event errors is null and eventType contains rejected then Throw exception ORSDistException("No event body to publish")
     */
    @Test
    public void whenNullEventErrorsAndEventTypeContainsRejected_ThenThrowORSDistException()
            throws Exception {
        // Given
        String expectedExceptionMsg = "No event errors to publish for sqs message";
        BaseEvent<BaseHeader> cmdsEvent = mapper.readValue(message.getBody(), BaseEvent.class);
        cmdsEvent.getEventHeader().setEventName("TtBannedReject");
        cmdsEvent.setEventErrors(null);
        String eventBody = mapper.writeValueAsString(cmdsEvent);
        message.setBody(eventBody);
        when(rejectedEvents.contains(BAN_REJECTED)).thenReturn(true);

        // then
        exceptionRule.expect(ORSDistException.class);
        exceptionRule.expectMessage(expectedExceptionMsg);

        // when
        orsDistbc.handleRequest(event, context);
    }

    /*
     * clean up resources
     */
    @After
    public void tearDown() {
        message = null;
        event = null;
    }

    /**
     * constructs httpheader based on provided eventheader
     *
     * @param eventHeader
     * @return
     */
    private HttpHeaders getHttpHeaders(BaseHeader eventHeader) {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.set(TRANSACTIONID, eventHeader.getTransactionId().toString());
        httpHeaders.set(CORRELATIONID, eventHeader.getCorrelationId().toString());

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        httpHeaders.set(
                EVENT_DATE_TIME,
                Objects.isNull(eventHeader.getEventDateTime())
                        ? ""
                        : eventHeader.getEventDateTime().format(formatter));
        return httpHeaders;
    }

    @Test
    public void whenBCRequestHasValidAuthenticationHeader_ThenVerifyCallToRestTemplate() throws Exception {
        //Prepare test data
        BaseEvent<BaseHeader> baseEvent = mapper.readValue(message.getBody(), BaseEvent.class);
        //CMDSEvent baseEvent = mapper.readValue(message.getBody(), CMDSEvent.class);
        Map<String, String> map = new HashMap<>();
        map.put(CALLBACK_URL, SQSEventBodySetup.getEnvironmentVariablesStub().get(CALLBACK_URL));
        map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
        map.put(AUTH_HEADER, "Authorization");
        map.put(USER_AGENT, "CMDS");
        ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.OK);
        HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
        eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));

        //Define mock variables behaviour
        when(authenticationFactory.getAuthenticationClient(baseEvent.getEventHeader().getPartnerCode())).thenReturn(britishCouncilAuthenticationClient);
        ReflectionTestUtils.setField(orsDistbc, "authenticationClientFactory", authenticationFactory);
        doReturn("authHeaderName").when(britishCouncilAuthenticationClient).getAuthorizationHeaderName();
        doReturn("accessToken").when(britishCouncilAuthenticationClient).getAccessToken();
        doReturn(restTemplate).when(britishCouncilAuthenticationClient).getRestTemplate();
        when(restTemplate.postForEntity(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.any(Class.class)))
                .thenReturn(response2);


        SQSEventBodySetup.setEnviornment(map);
        //Execute and assert test
        assertDoesNotThrow(() -> orsDistbc.handleRequest(event, context));
    }

    private HttpHeaders getHttpHeaders(BaseEvent<BaseHeader> eventHeader) {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.set(TRANSACTIONID, eventHeader.getEventHeader().getTransactionId().toString());
        httpHeaders.set(CORRELATIONID, eventHeader.getEventHeader().getCorrelationId().toString());
        httpHeaders.set(PARTNER_CODE, eventHeader.getEventHeader().getPartnerCode());
        return httpHeaders;
    }

    @Test
    public void whenBCCHNRequestHasInValidAuthenticationHeader_ThenThrowsException() throws Exception {
        //Prepare test data
        BaseEvent<?> baseEvent = mapper.readValue(message.getBody(), BaseEvent.class);
        baseEvent.getEventHeader().setPartnerCode("BC_CHN");
        Map<String, String> map = new HashMap<>();
        map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
        map.put(AUTH_HEADER, "Authorization");

        ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
        eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));

        //Define mock variables behaviour
        when(authenticationFactory.getAuthenticationClient(baseEvent.getEventHeader().getPartnerCode())).thenReturn(bcchnClient);
        ReflectionTestUtils.setField(orsDIstBcchn, "authenticationClientFactory", authenticationFactory);
        doReturn("authHeaderName").when(bcchnClient).getAuthorizationHeaderName();
        doReturn("accessToken").when(bcchnClient).getAccessToken();
        doReturn(restTemplate).when(bcchnClient).getRestTemplate();
        when(restTemplate.postForEntity(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.any(Class.class))).thenReturn(response2);
        //Execute and assert test
        assertThrows(ORSDistException.class, () -> orsDIstBcchn.handleRequest(event, context));
    }
    @Test
    public void whenBCRequestHasInValidAuthenticationHeader_ThenThrowsException() throws Exception {
        //Prepare test data
        BaseEvent<?> baseEvent = mapper.readValue(message.getBody(), BaseEvent.class);
        baseEvent.getEventHeader().setPartnerCode("BC");
        Map<String, String> map = new HashMap<>();
        map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
        map.put(AUTH_HEADER, "Authorization");

        ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
        eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));

        //Define mock variables behaviour
        when(authenticationFactory.getAuthenticationClient(baseEvent.getEventHeader().getPartnerCode())).thenReturn(britishCouncilAuthenticationClient);
        ReflectionTestUtils.setField(orsDistbc, "authenticationClientFactory", authenticationFactory);
        doReturn("authHeaderName").when(britishCouncilAuthenticationClient).getAuthorizationHeaderName();
        doReturn("accessToken").when(britishCouncilAuthenticationClient).getAccessToken();
        doReturn(restTemplate).when(britishCouncilAuthenticationClient).getRestTemplate();
        when(restTemplate.postForEntity(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.any(Class.class))).thenReturn(response2);
        //Execute and assert test
        assertThrows(ORSDistException.class, () -> orsDistbc.handleRequest(event, context));
    }

    @Test
    public void whenBCRequestHasInvalidAuthenticationHeader_ThenDoesNotThrowException() throws Exception {
        //Prepare test data
        //CMDSEvent baseEvent = mapper.readValue(message.getBody(), CMDSEvent.class);
        BaseEvent<BaseHeader> baseEvent = mapper.readValue(message.getBody(), BaseEvent.class);
        Map<String, String> map = new HashMap<>();
        map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
        map.put(CALLBACK_URL, SQSEventBodySetup.getEnvironmentVariablesStub().get(CALLBACK_URL));
        map.put(AUTH_HEADER, "Authorization");
        SQSEventBodySetup.setEnviornment(map);
        ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.OK);
        HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
        eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));
        //Define mock variables behaviour
        when(authenticationFactory.getAuthenticationClient(baseEvent.getEventHeader().getPartnerCode())).thenReturn(britishCouncilAuthenticationClient);
        ReflectionTestUtils.setField(orsDistbc, "authenticationClientFactory", authenticationFactory);
        doReturn("authHeaderName").when(britishCouncilAuthenticationClient).getAuthorizationHeaderName();
        doReturn("accessToken").when(britishCouncilAuthenticationClient).getAccessToken();
        doReturn(restTemplate).when(britishCouncilAuthenticationClient).getRestTemplate();
        when(restTemplate.postForEntity(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.any(Class.class))).thenReturn(response2);
        //Execute and assert test
        assertDoesNotThrow(() -> orsDistbc.handleRequest(event, context));
    }

    @Test
    public void whenIDPRequestHasInValidAuthenticationHeader_ThenThrowsException() throws Exception {
        //CMDSEvent baseEvent = mapper.readValue(messageIdp.getBody(), CMDSEvent.class);
        BaseEvent<?> baseEvent = mapper.readValue(messageIdp.getBody(), BaseEvent.class);
        Map<String, String> map = new HashMap<>();
        map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
        map.put(AUTH_HEADER, "Authorization");
        ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.BAD_GATEWAY);
        HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
        eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));
        //Define mock variables behaviour
        when(authenticationFactory.getAuthenticationClient(baseEvent.getEventHeader().getPartnerCode())).thenReturn(idpClient);
        ReflectionTestUtils.setField(orsDistIdp, "authenticationClientFactory", authenticationFactory);
        doReturn("authHeaderName").when(idpClient).getAuthorizationHeaderName();
        doReturn("accessToken").when(idpClient).getAccessToken();
        doReturn(restTemplate).when(idpClient).getRestTemplate();
        when(restTemplate.postForEntity(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpEntity.class),
                ArgumentMatchers.any(Class.class))).thenReturn(response2);
        //Execute and assert test
        assertThrows(ORSDistException.class, () -> orsDistIdp.handleRequest(eventIdp, context));
    }

    @Test
    public void getApplicationName_whenGetApplicationName_thenReturnInvalidApplicationNameForBC() {
        String applicationName = orsDistbc.getApplicationName();
        // Then
        assertEquals(DistORSConstants.ORS_TTBANNED_DIST_BC, applicationName);
    }

    @Test
    public void getApplicationName_whenGetApplicationName_thenReturnInvalidApplicationNameForIDP() {
        String applicationName = orsDistIdp.getApplicationName();
        // Then
        assertEquals(ORS_TTBANNED_DIST_IDP, applicationName);
    }

    @Test
    public void getApplicationName_whenGetApplicationName_thenReturnInvalidApplicationNameForBCCHN() {
        String applicationName = orsDIstBcchn.getApplicationName();
        // Then
        assertEquals(DistORSConstants.ORS_TTBANNED_DIST_BCCHN, applicationName);
    }

    @Test
    public void getPartnerCodeConstants_whenGetPartnerCodeConstants_thenReturnBC() {
        String partnerCodeConstants = orsDistbc.getPartnerCodeConstants();
        // Then
        assertEquals(DistORSConstants.BC, partnerCodeConstants);
    }

    @Test
    public void getPartnerCodeConstants_whenGetPartnerCodeConstants_thenReturnIDP() {
        String partnerCodeConstants = orsDistIdp.getPartnerCodeConstants();
        // Then
        assertEquals(DistORSConstants.IDP, partnerCodeConstants);
    }

    @Test
    public void getPartnerCodeConstants_whenGetPartnerCodeConstants_thenReturnBCCHN() {
        String partnerCodeConstants = orsDIstBcchn.getPartnerCodeConstants();
        // Then
        assertEquals(DistORSConstants.BC_CHN, partnerCodeConstants);
    }
}
