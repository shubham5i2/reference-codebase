package com.ielts.cmds.integration.mapper;

import com.ielts.cmds.booking.common.out.model.TestTakerBanV1;
import com.ielts.cmds.integration.model.BanDetailsV1;
import com.ielts.cmds.integration.model.ORSTtBannedResponse;


/**
 * This class is used to map incoming event to appropriate API request body
 */
public class EventMapper {

    /**
     * Maps input event to booking response specific to request api body
     */
    public ORSTtBannedResponse mapBannedResponse(final TestTakerBanV1 details) {
        final ORSTtBannedResponse orsResponse = new ORSTtBannedResponse();
        orsResponse.setUniqueTestTakerUuid(details.getUniqueTestTakerUuid());
        orsResponse.setUniqueTestTakerId(details.getUniqueTestTakerId());

        BanDetailsV1 banDetailsV1 = new BanDetailsV1();
        banDetailsV1.setBanReasonUuid(details.getDetails().getBanReasonUuid());
        banDetailsV1.setBanUuid(details.getDetails().getBanUuid());
        banDetailsV1.setComment(details.getDetails().getComment());
        banDetailsV1.setLocations(details.getDetails().getLocations());
        banDetailsV1.setStartDate(details.getDetails().getStartDate());
        banDetailsV1.setEndDate(details.getDetails().getEndDate());

        orsResponse.setDetails(banDetailsV1);

        return orsResponse;
    }

}
