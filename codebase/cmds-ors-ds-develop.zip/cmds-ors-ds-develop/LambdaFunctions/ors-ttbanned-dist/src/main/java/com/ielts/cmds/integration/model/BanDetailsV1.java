package com.ielts.cmds.integration.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.google.gson.annotations.SerializedName;
import lombok.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class BanDetailsV1 {

    @SerializedName("banUuid")
    private UUID banUuid = null;

    @SerializedName("banReasonUuid")
    private UUID banReasonUuid = null;

    @SerializedName("locations")
    private List<UUID> locations = new ArrayList();

    @SerializedName("startDate")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate startDate = null;

    @SerializedName("endDate")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate endDate = null;

    @SerializedName("comment")
    private String comment = null;
}
