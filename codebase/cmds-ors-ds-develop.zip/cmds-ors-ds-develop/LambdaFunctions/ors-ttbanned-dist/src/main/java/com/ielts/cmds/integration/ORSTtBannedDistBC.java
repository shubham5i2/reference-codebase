package com.ielts.cmds.integration;


import com.ielts.cmds.integration.constants.DistORSConstants;

public class ORSTtBannedDistBC extends ORSTtBannedDist {

  @Override
  protected String getPartnerCodeConstants() {
    return DistORSConstants.BC;
  }

  @Override
  protected String getApplicationName() {
    return DistORSConstants.ORS_TTBANNED_DIST_BC;
  }
}