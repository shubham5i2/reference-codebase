package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.constants.DistORSConstants.BAN_REJECTED;
import static com.ielts.cmds.integration.constants.DistORSConstants.BC;
import static com.ielts.cmds.integration.constants.DistORSConstants.CALLBACK_URL;
import static com.ielts.cmds.integration.constants.DistORSConstants.CORRELATIONID;
import static com.ielts.cmds.integration.constants.DistORSConstants.EVENT_DATE_TIME;
import static com.ielts.cmds.integration.constants.DistORSConstants.PARTNER_CODE;
import static com.ielts.cmds.integration.constants.DistORSConstants.TRANSACTIONID;
import static com.ielts.cmds.integration.constants.DistORSConstants.USER_AGENT;
import static com.ielts.cmds.integration.constants.DistORSConstants.USER_AGENT_KEY;
import static java.lang.String.format;

import java.security.KeyStoreException;
import java.security.cert.CertificateException;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.booking.common.out.model.TestTakerBanV1;
import com.ielts.cmds.common.logger.util.CMDSLambdaLoggerUtil;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.exception.ORSDistException;
import com.ielts.cmds.integration.mapper.EventMapper;
import com.ielts.cmds.integration.model.ORSTtBannedResponse;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.exception.InvalidClientException;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;

import lombok.extern.slf4j.Slf4j;

/**
 * This class serves the purpose of handling Banned response to External system(ORS - British
 * Council) It reads booking events specific to british council and post it back on callbackURL
 */

@Slf4j
public abstract class ORSTtBannedDist {

    private ObjectMapper mapper = new ObjectMapper();
    private final EnvironmentAwareAuthenticationClientFactory authenticationClientFactory;

    private final List<String> rejectedEvents = Arrays.asList(BAN_REJECTED);
    private AuthenticationClient authenticationClient;

    protected ORSTtBannedDist() {
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
        this.authenticationClientFactory = new EnvironmentAwareAuthenticationClientFactory();
    }

    /**
     * This method will be triggered on events published to ORS queue. It reads SQS records,validate
     * it and post to external system(ORS)
     *
     * @param input
     * @param context
     */
    public void handleRequest(final SQSEvent input, final Context context) throws Exception {
        for (SQSEvent.SQSMessage message : input.getRecords()) {
            final String sqsMessage = message.getBody();
            log.info("Event received in ORS DS mx : ors-ttbanned-dist with metadata as {}",
                    mapper.readValue(sqsMessage, BaseEvent.class).getEventHeader());
            validateAndSendEventRequest(sqsMessage, context);
        }
    }

    /**
     * Validates and sends the received sqs message body for further processing
     *
     * @param sqsMessage
     * @param context
     * @throws JsonProcessingException
     */
    private void validateAndSendEventRequest(final String sqsMessage, final Context context) throws Exception {
        final BaseEvent<BaseHeader> event = validateHeadersAndBody(sqsMessage);
        final BaseHeader eventHeader = event.getEventHeader();
        final UUID transactionId = eventHeader.getTransactionId();

        event.getEventHeader().setPartnerCode(getPartnerCodeConstants());

        initializeLogger(transactionId, context);

        mapAndSendExternalEvent(event, eventHeader);

        log.info("Event being published from ORS DS : ors-ttbanned-dist with metadata as {}", mapper.writeValueAsString(eventHeader));
    }

    /**
     * This method validates event headers and event body.
     *
     * @param sqsMsg
     * @return
     * @throws JsonProcessingException
     */
    private BaseEvent<BaseHeader> validateHeadersAndBody(final String sqsMsg) throws JsonProcessingException {

        final BaseEvent<BaseHeader> cmdsEvent = mapper.readValue(sqsMsg, new TypeReference<BaseEvent<BaseHeader>>() {

        });
        final Validator cmdsEventValidator = Validation.buildDefaultValidatorFactory().getValidator();

        final Set<ConstraintViolation<BaseEvent<BaseHeader>>> eventViolations =
                cmdsEventValidator.validate(cmdsEvent);

        if (!CollectionUtils.isEmpty(eventViolations)) {

            final Set<String> errorMessageSet =
                    eventViolations.stream()
                            .map(ConstraintViolation::getMessage)
                            .collect(Collectors.toSet());

            final String errorMessage = String.join(", ", errorMessageSet);
            log.error("Validation failed for CMDSEvent - {} :", errorMessage);
            log.info("Event being published from ORS DS : ors-ttbanned-dist with metadata as {} and error {}",
                    mapper.writeValueAsString(cmdsEvent.getEventHeader()), errorMessage);
            throw new ORSDistException(
                    format("CMDS Event Validation failed- [%s] for the request %s", errorMessage, sqsMsg));
        }
        validateEventBody(cmdsEvent, sqsMsg);
        return cmdsEvent;
    }

    /*
     * This method validates event body and event errors
     */
    private void validateEventBody(final BaseEvent<BaseHeader> event, final String sqsMsg) throws JsonProcessingException {
        final String eventName = event.getEventHeader().getEventName();
        if (!StringUtils.hasText(event.getEventBody()) && !rejectedEvents.contains(eventName)) {
            log.info("Event being published from ORS DS : ors-ttbanned-dist with metadata as {} and error - No event body to publish for sqs message",
                    mapper.writeValueAsString(event.getEventHeader()));
            throw new ORSDistException(
                    format("No event body to publish for sqs message: %s", sqsMsg));
        } else if (Objects.isNull(event.getEventErrors()) && rejectedEvents.contains(eventName)) {
            log.info("Event being published from ORS DS : ors-ttbanned-dist with metadata as {} and error - No event errors attribute to publish for sqs message",
                    mapper.writeValueAsString(event.getEventHeader()));
            throw new ORSDistException(
                    format("No event errors to publish for sqs message: %s", sqsMsg));
        }
    }

    /**
     * It processes and sends event body to appropriate external api resource based on EventType
     *
     * @param event
     * @param headers
     * @throws JsonProcessingException
     */
    void mapAndSendExternalEvent(final BaseEvent<BaseHeader> event, final BaseHeader headers)
            throws Exception {
        log.info("Callback removal starts !!! ");
        String extCallbackUrl = System.getenv(CALLBACK_URL);

        log.debug("Callback url {} ", extCallbackUrl);
        log.info("Callback removal ends !!! ");

        final EventMapper eventMapper = new EventMapper();
        ORSTtBannedResponse banResponse = null;
        if (!rejectedEvents.contains(headers.getEventName())) {
            final TestTakerBanV1 details =
                    mapper.readValue(event.getEventBody(), TestTakerBanV1.class);
            banResponse = eventMapper.mapBannedResponse(details);
        }

        log.debug("banResponse before RestTemplate call: {} ", banResponse);

        postRequestToExternalAPI(banResponse, headers, extCallbackUrl);
    }

    /**
     * This method posts event body related to TTbanned events to external systems.
     *
     * @param resBody
     * @param eventHeader
     * @param externalUrl
     * @throws JsonProcessingException
     */
    private void postRequestToExternalAPI(
            final ORSTtBannedResponse resBody, final BaseHeader eventHeader, final String externalUrl)
            throws Exception {
        final UUID txtID = eventHeader.getTransactionId();
        try {
            getAuthenticationClient(eventHeader.getPartnerCode());
            final HttpHeaders eventHeaders = getHttpHeaders(eventHeader);
            final HttpEntity<ORSTtBannedResponse> eventEntity = new HttpEntity<>(resBody, eventHeaders);
            final ResponseEntity<String> response = authenticationClient.getRestTemplate().postForEntity(externalUrl, eventEntity, String.class);

            if (!(response.getStatusCode() == HttpStatus.OK || response.getStatusCode() == HttpStatus.ACCEPTED)) {

                throw new ORSDistException(
                        format(
                                "Request Failed with StatusCode:%s. TransactionId:%s",
                                response.getStatusCode(), txtID));
            }
            log.debug(
                    "Request success with StatusCode: {} . TransactionId: {} ",
                    response.getStatusCode(),
                    txtID);
        } catch (Exception ex) {
            throw new ORSDistException(
                    format("TransactionId:%s - Exception on posting requestBody: %s", txtID, ex));
        }

    }

    /**
     * constructs http header based on provided event header
     *
     * @param eventHeader
     * @return
     */
    HttpHeaders getHttpHeaders(final BaseHeader eventHeader) throws Exception {
        final HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.set(TRANSACTIONID, eventHeader.getTransactionId().toString());
        httpHeaders.set(CORRELATIONID, eventHeader.getCorrelationId().toString());
        httpHeaders.set(PARTNER_CODE, eventHeader.getPartnerCode());
        if (eventHeader.getPartnerCode() != null && eventHeader.getPartnerCode().equalsIgnoreCase(BC) &&
                System.getenv(USER_AGENT) != null && !System.getenv(USER_AGENT).equals("")) {
            log.info("Inside user- agent");
            httpHeaders.set(USER_AGENT_KEY, System.getenv(USER_AGENT));
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        httpHeaders.set(
                EVENT_DATE_TIME,
                Objects.isNull(eventHeader.getEventDateTime())
                        ? ""
                        : eventHeader.getEventDateTime().format(formatter));


        getAuthenticationClient(eventHeader.getPartnerCode());
        httpHeaders.set(authenticationClient.getAuthorizationHeaderName(), authenticationClient.getAccessToken());
        return httpHeaders;
    }

    private void getAuthenticationClient(String partnerCode) throws InvalidClientException, CertificateException, KeyStoreException, JsonProcessingException {
        if (authenticationClient == null) {
            authenticationClient = authenticationClientFactory.getAuthenticationClient(partnerCode);
        }
    }

    protected abstract String getPartnerCodeConstants();

    protected abstract String getApplicationName();

    /**
     * Method to initialize Logger Context for ors lambda
     *
     * @param transactionId
     * @param context
     */
    protected void initializeLogger(final UUID transactionId, final Context context) {
        final CMDSLambdaLoggerUtil loggerUtil = new CMDSLambdaLoggerUtil();
        loggerUtil.initializeThreadContextMap(
                transactionId.toString(), getApplicationName(), context.getAwsRequestId());
    }
}
