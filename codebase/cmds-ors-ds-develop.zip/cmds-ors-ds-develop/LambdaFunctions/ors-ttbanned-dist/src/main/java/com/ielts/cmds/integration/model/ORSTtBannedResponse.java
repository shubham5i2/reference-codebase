package com.ielts.cmds.integration.model;

import lombok.Data;

import java.util.UUID;

@Data
public class ORSTtBannedResponse {

    UUID uniqueTestTakerUuid = null;

    String uniqueTestTakerId = null;

    BanDetailsV1 details = null;
}