package com.ielts.cmds.integration.model;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.ToString;

@Data
@Getter
@ToString
@AllArgsConstructor
public class CMDSResponseBody {
  private BaseEventErrors errors;
}
