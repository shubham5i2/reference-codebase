package com.ielts.cmds.integration;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;

import java.security.KeyStoreException;
import java.security.cert.CertificateException;
import java.time.format.DateTimeFormatter;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.common.logger.util.CMDSLambdaLoggerUtil;
import com.ielts.cmds.finance.common.out.model.RefundChangedV1;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.exception.ORSDistException;
import com.ielts.cmds.integration.mapper.EventMapper;
import com.ielts.cmds.integration.model.ORSRefundRequestResponse;
import com.ielts.cmds.integration.model.CMDSResponseBody;
import com.ielts.cmds.integration.model.ExtORSResponse;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.exception.InvalidClientException;
import com.ielts.cmds.security.exception.TokenNotReceivedException;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.Valid;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import static com.ielts.cmds.integration.constants.DistORSConstants.*;
import static java.lang.String.format;

/**
 * This class serves the purpose of handling ors ds response to External system(ORS - British
 * Council) It reads booking events specific to british council and posts it back on callbackURL
 */

@Slf4j
public abstract class ORSRefundRequestChangedDist {

  private final ObjectMapper mapper = new ObjectMapper();
  private final EnvironmentAwareAuthenticationClientFactory authenticationClientFactory;


  private final List<String> rejectedEvents = Arrays.asList(REFUND_REQUEST_CHANGED_REJECTED);
  private AuthenticationClient authenticationClient;
  protected ORSRefundRequestChangedDist() {
    mapper.registerModule(new JavaTimeModule());
    mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
    mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
    this.authenticationClientFactory = new EnvironmentAwareAuthenticationClientFactory();
  }

  /**
   * This method will be triggered on events published to ORS queue. It reads SQS records,validate
   * it and post to external system(ORS)
   * @param input
   * @param context
   * @throws Exception
   */
  public void handleRequest(final SQSEvent input, final Context context) throws Exception {
    for (SQSEvent.SQSMessage message : input.getRecords()) {
      final String sqsMessage = message.getBody();
      validateAndSendEventRequest(sqsMessage, context);
    }
  }

  /**
   * Validates and sends the received sqs message body for further processing
   * @param sqsMessage
   * @param context
   * @throws Exception
   */
  private void validateAndSendEventRequest(final String sqsMessage, final Context context) throws Exception {
    final BaseEvent<BaseHeader> cmdsEvent = validateHeadersAndBody(sqsMessage);
    final BaseHeader eventHeader = cmdsEvent.getEventHeader();
    final String eventName = eventHeader.getEventName();
    final UUID transactionId = eventHeader.getTransactionId();
    final String partnerCode = eventHeader.getPartnerCode();
    initializeLogger(transactionId, context);
    log.info("Event received in ORS DS : ors-refundRequestChange-dist with metadata as {}",eventHeader);

    log.trace(
            "Start: TransactionId:{} Event:{} CorrelationId:{}",
            transactionId,
            eventName,
            eventHeader.getCorrelationId(),
            sqsMessage);

    if (getPartnerCodeConstants().equalsIgnoreCase(partnerCode)) {
      mapAndSendExternalEvent(cmdsEvent, eventHeader);
    } else {
      log.debug(
              "Not processing incoming message as partnerCode:{} does not match expected partner code:{}"
                      + " TransactionId:{} Event:{} CorrelationId:{}",
              partnerCode,
              getPartnerCodeConstants(),
              transactionId,
              eventName,
              eventHeader.getCorrelationId());
    }

    log.debug(
            "End: TransactionId:{} Event:{} CorrelationId:{}",
            transactionId,
            eventName,
            eventHeader.getCorrelationId());

  }

  /**
   * This method validates event headers and event body.
   *
   * @param sqsMsg
   * @return
   * @throws JsonProcessingException
   */
  private BaseEvent<BaseHeader> validateHeadersAndBody(final String sqsMsg) throws JsonProcessingException  {

    final BaseEvent<BaseHeader> cmdsEvent = mapper.readValue(sqsMsg, BaseEvent.class);
    final Validator cmdsEventValidator = Validation.buildDefaultValidatorFactory().getValidator();

    final Set<ConstraintViolation<BaseEvent<BaseHeader>>> eventViolations =
            cmdsEventValidator.validate(cmdsEvent);

    if (!CollectionUtils.isEmpty(eventViolations)) {

      final Set<String> errorMessageSet =
              eventViolations.stream()
                      .map(ConstraintViolation<BaseEvent<BaseHeader>>::getMessage)
                      .collect(Collectors.toSet());

      final String errorMessage = String.join(", ", errorMessageSet);
      log.warn("CMDS Event Validation failed- [%s] for the request %s", errorMessage, sqsMsg);
    }
    validateEventBody(cmdsEvent, sqsMsg);
    return cmdsEvent;
  }

  /*
   * This method validates event body and eventErrors
   */
  private void validateEventBody(final BaseEvent<BaseHeader> event, final String sqsMsg) {
    final String eventName = event.getEventHeader().getEventName();
    if (!Objects.isNull(event.getEventErrors()) && rejectedEvents.contains(eventName)) {
      log.debug("Error in ORS DS : ors-refundRequestChange-dist with metadata as {} and error - No eventErrors attribute to publish for sqs message",
              Objects.toString(event.getEventHeader(), ""));
      log.warn("No event errors to publish for sqs message: %s", sqsMsg);
    }
    if (Objects.isNull(event.getEventBody()) && !rejectedEvents.contains(eventName)) {
      log.debug("Error in ORS DS : ors-refundRequestChange-dist with metadata as {} and error - No eventbody attribute to publish for sqs message",
              Objects.toString(event.getEventHeader(), ""));
      log.warn("No event body to publish for sqs message: %s", sqsMsg);
    }
  }

  /**
   * It processes and sends event body to appropriate external api resource based on EventType
   *
   * @param event
   * @param headers
   * @throws JsonProcessingException
   */
  void mapAndSendExternalEvent(@Valid final BaseEvent<BaseHeader> event,@Valid final BaseHeader headers)
          throws Exception {
    String extCallbackUrl = System.getenv(CALLBACK_URL);

    log.debug("Callback url {} ", extCallbackUrl);
    

    final EventMapper eventMapper = new EventMapper();
    ORSRefundRequestResponse ORSRefundRequestResponse = null;
    final ExtORSResponse response;
    if (event.getEventBody()!=null) {
      final RefundChangedV1 refundDetails =
              mapper.readValue(event.getEventBody(), RefundChangedV1.class);
      ORSRefundRequestResponse = eventMapper.mapRefundResponse(refundDetails);
    }
    response = new ExtORSResponse(ORSRefundRequestResponse, event.getEventErrors());


    log.debug("ORSRefundRequestResponse before RestTemplate call: {} ", response);

    postRequestToExternalAPI(response, headers, extCallbackUrl);

  }

  /**
   * This method posts eventbody related to refund change events to external systems.
   * @param resBody
   * @param eventHeader
   * @param externalUrl
   * @throws ORSDistException
   */
  private void postRequestToExternalAPI(
          final CMDSResponseBody resBody, final BaseHeader eventHeader, final String externalUrl) {
    final UUID txtID = eventHeader.getTransactionId();
    try {
      getAuthenticationClient(eventHeader.getPartnerCode());
      final HttpHeaders eventHeaders = getHttpHeaders(eventHeader);
      final HttpEntity<CMDSResponseBody> eventEntity = new HttpEntity<>(resBody, eventHeaders);
      log.debug("ExternalUrl : {} ; eventEntity : {} ; eventHeader : {}", externalUrl, eventEntity, eventHeaders);
      final ResponseEntity<String> response = authenticationClient.getRestTemplate().postForEntity(externalUrl, eventEntity, String.class);
      log.debug(
              "Request success with StatusCode: {} . TransactionId: {} ", response.getStatusCode(), txtID);
    } catch (Exception ex) {
     log.warn("TransactionId:%s - Exception on posting requestBody: %s", txtID, ex);
    }
  }

  /**
   * constructs httpheader based on provided eventheader
   * @param eventHeader
   * @return
   * @throws Exception
   */
  HttpHeaders getHttpHeaders(@Valid final BaseHeader eventHeader)
          throws Exception {
    final HttpHeaders httpHeaders = new HttpHeaders();
    httpHeaders.setContentType(MediaType.APPLICATION_JSON);
    httpHeaders.set(TRANSACTIONID, eventHeader.getTransactionId().toString());
    if(eventHeader.getCorrelationId() != null) {
      httpHeaders.set(CORRELATIONID, eventHeader.getCorrelationId().toString());
    }
    httpHeaders.set(PARTNER_CODE, eventHeader.getPartnerCode());
    if(eventHeader.getPartnerCode()!= null && eventHeader.getPartnerCode().equalsIgnoreCase(BC)   &&
            System.getenv(USER_AGENT) != null && !System.getenv(USER_AGENT).equals("")){
      log.info("Inside user- agent");
      httpHeaders.set(USER_AGENT_KEY, System.getenv(USER_AGENT));
    }
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
    httpHeaders.set(
            EVENT_DATE_TIME,
            Objects.isNull(eventHeader.getEventDateTime())
                    ? ""
                    : eventHeader.getEventDateTime().format(formatter));

    httpHeaders.set(authenticationClient.getAuthorizationHeaderName(), authenticationClient.getAccessToken());
    return httpHeaders;
  }
  private void getAuthenticationClient(String partnerCode) throws InvalidClientException, CertificateException, KeyStoreException, JsonProcessingException {
    if (authenticationClient == null) {
      authenticationClient = authenticationClientFactory.getAuthenticationClient(partnerCode);
    }

  }


  protected abstract String getPartnerCodeConstants();

  protected abstract String getApplicationName();

  /**
   * Method to initialize Logger Context for ors ds lambda
   *
   * @param transactionId
   * @param context
   */
  protected void initializeLogger(final UUID transactionId, final Context context) {
    final CMDSLambdaLoggerUtil loggerUtil = new CMDSLambdaLoggerUtil();
    loggerUtil.initializeThreadContextMap(
            transactionId.toString(), getApplicationName(), context.getAwsRequestId());
  }
}