package com.ielts.cmds.integration;

import com.ielts.cmds.integration.constants.DistORSConstants;

public class ORSRefundRequestChangedDistBC extends ORSRefundRequestChangedDist {


  @Override
  protected String getPartnerCodeConstants() {
    return DistORSConstants.BC;
  }

  @Override
  protected String getApplicationName() {
    return DistORSConstants.ORS_REFUNDREQUESTCHANGED_DIST_BC;
  }
}
