package com.ielts.cmds.integration.model;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


import java.util.UUID;
@Data
@Getter
@Setter
@ToString
@EqualsAndHashCode
@NoArgsConstructor
public class RefundRequest {
  private UUID refundRequestUuid;
  private UUID externalRefundRequestUuid;
}
