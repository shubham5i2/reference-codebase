package com.ielts.cmds.integration.mapper;

import com.ielts.cmds.finance.common.out.model.RefundChangedV1;
import com.ielts.cmds.integration.model.RefundRequest;
import com.ielts.cmds.integration.model.ORSRefundRequestResponse;


import java.util.List;

/** This class is used to map incoming event to appropriate API request body */
public class EventMapper {

    /**
     * Maps input event to booking response specific to request api body
     *
     * @param details
     * @return
     */
    public ORSRefundRequestResponse mapRefundResponse(final RefundChangedV1 details) {
        final ORSRefundRequestResponse ORSRefundRequestResponse = new ORSRefundRequestResponse();
        ORSRefundRequestResponse.setExternalBookingUuid(details.getExternalBookingUuid());
        final RefundRequest refundRequest = new RefundRequest();
        refundRequest.setExternalRefundRequestUuid(details.getExternalRefundRequestUuid());
        refundRequest.setRefundRequestUuid(details.getRefundRequestUuid());
        ORSRefundRequestResponse.setRefundRequest(refundRequest);
        return ORSRefundRequestResponse;
    }


}
