package com.ielts.cmds.integration.model;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class ExtORSResponse extends CMDSResponseBody {
  private ORSRefundRequestResponse response;

  public ExtORSResponse(final ORSRefundRequestResponse response, final BaseEventErrors errors) {
    super(errors);
    this.response = response;
  }
}
