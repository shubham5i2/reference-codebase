package com.ielts.cmds.integration.mapper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;


import com.ielts.cmds.finance.common.out.model.RefundChangedV1;
import com.ielts.cmds.integration.model.ORSRefundRequestResponse;
import com.ielts.cmds.integration.model.RefundRequest;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.booking.common.CMDSEvent;
import com.ielts.cmds.integration.SQSEventBodySetup;


@RunWith(MockitoJUnitRunner.class)
public class EventMapperTest {

  @InjectMocks
  EventMapper eventMapper;

  @Mock
  RefundChangedV1 details;

  @Spy
  private ObjectMapper mapper;

  @Before
  public void setUp() throws Exception{
    mapper=getMapper();
    mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
    mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);

    String sqsMsg=SQSEventBodySetup.getEventBody();
    CMDSEvent cmdsEvent=mapper.readValue(sqsMsg, CMDSEvent.class);
    details=mapper.readValue(cmdsEvent.getEventBody(), RefundChangedV1.class);
  }

  /*
   * test to validate the refundResponse against refundDetails
   * and check refund details populated correctly
   */
  @Test
  public void whenBookingDetailsProvided_ThenValidatedBookingResponse(){
    // when
    ORSRefundRequestResponse ORSRefundRequestResponse=eventMapper.mapRefundResponse(details);
    RefundRequest refundRequest=new RefundRequest();
    refundRequest.setRefundRequestUuid(details.getRefundRequestUuid());
    refundRequest.setExternalRefundRequestUuid(details.getExternalRefundRequestUuid());
    // then

    assertEquals(details.getExternalBookingUuid(), ORSRefundRequestResponse.getExternalBookingUuid());
    assertEquals(refundRequest, ORSRefundRequestResponse.getRefundRequest());
  }

/*
   * when there are null values within refundDetails then verify those null values in refundResponse
   */

  @Test
  public void whenRefundRequestIsPassedWithNullValues_ThenVerifyRefundResponseForNullValues() {
    // Given
    details.setExternalBookingUuid(null);

    details.setRefundRequestStatus(null);
    details.setRefundPercentageValue(null);
    details.setExternalRefundRequestUuid(null);

    // when
    ORSRefundRequestResponse ORSRefundRequestResponse = eventMapper.mapRefundResponse(details);
    ORSRefundRequestResponse.setRefundRequest(null);

    // then

    assertNull(ORSRefundRequestResponse.getExternalBookingUuid());
    assertNull(ORSRefundRequestResponse.getRefundRequest());
  }


  /* * clean up the resources

*/
  @After
  public void tearDown() {
    details = null;
  }

  protected ObjectMapper getMapper() {
    ObjectMapper mapper = new ObjectMapper();
    mapper.registerModule(new JavaTimeModule());
    mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
    mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
    mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    return mapper;
  }

}