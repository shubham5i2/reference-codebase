package com.ielts.cmds.integration;

import com.amazonaws.regions.Regions;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.booking.common.CMDSAddress;
import com.ielts.cmds.booking.common.CMDSCommonHeader;
import com.ielts.cmds.booking.common.CMDSEvent;
import com.ielts.cmds.booking.common.enums.*;
import com.ielts.cmds.booking.common.out.model.BookingDetails;
import com.ielts.cmds.booking.common.out.model.BookingLine;
import com.ielts.cmds.booking.common.out.model.MarketingInfo;
import com.ielts.cmds.booking.common.out.model.TestTakerDetails;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;

import java.lang.reflect.Field;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.Map;
import java.util.HashMap;

import static com.ielts.cmds.integration.constants.DistORSConstants.*;
import static com.ielts.cmds.integration.constants.DistORSConstants.CALLBACK_URL;

public class SQSEventBodySetup {
  private static final ObjectMapper mapper = getMapper();

  public static String getEventBody() throws JsonProcessingException {
    BaseHeader eventHeader = getEventHeader();

    BookingDetails bookingDetails = getBookingDetails();
    String eventBody = mapper.writeValueAsString(bookingDetails);

    List<ErrorDescription> errorList = new ArrayList<>();
    ErrorDescription description = new ErrorDescription();
    description.setInterfaceName("Booking");
    description.setType(ErrorTypeEnum.VALIDATION);
    description.setErrorCode("1234");
    Source source = Source.builder().value("").path("product_uuid").build();
    description.setSource(source);
    errorList.add(description);

    BaseEventErrors errorResponse = new BaseEventErrors(errorList);
    BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
    cmdsEvent.setEventHeader(eventHeader);
    cmdsEvent.setEventBody(eventBody);
    cmdsEvent.setEventErrors(errorResponse);
    return mapper.writeValueAsString(cmdsEvent);
  }

  public static BaseEventErrors getCMDSErrorResponse() throws JsonProcessingException {
    List<ErrorDescription> errorList = new ArrayList<>();
    ErrorDescription description = new ErrorDescription();
    description.setInterfaceName("Booking");
    description.setType(ErrorTypeEnum.VALIDATION);
    description.setErrorCode("1234");
    Source source = Source.builder().value("").path("product_uuid").build();
    description.setSource(source);
    errorList.add(description);

    BaseEventErrors errorResponse = new BaseEventErrors(errorList);
    return errorResponse;
  }

  public static BookingDetails getBookingDetails() {
    BookingDetails bookingDetails = new BookingDetails();
    bookingDetails.setExternalBookingUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775565"));
    bookingDetails.setBookingUuid(UUID.fromString("e8958327-9917-4af2-91ce-7c6cd0c19837"));
    bookingDetails.setPartnerCode(null);
    bookingDetails.setIsVoid(new Boolean("false"));
    bookingDetails.setLocationUuid(UUID.fromString("8ef3da3a-2360-4bd9-bbb5-bb5f72457f83"));
    bookingDetails.setProductUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
    bookingDetails.setTestDate(
        LocalDate.parse("2020-06-01", DateTimeFormatter.ofPattern("yyyy-MM-dd")));
    bookingDetails.setBookingStatus(BookingStatusEnum.PAID);
    bookingDetails.setBookingDetailStatus(BookingDetailStatusEnum.INCOMPLETE);
    bookingDetails.setConsentGiven(true);
    bookingDetails.setAgentName("The Agency Inc.");
    MarketingInfo info = new MarketingInfo();
    info.setEducationLevelUuid(UUID.fromString("ba7e70a1-030f-4ed2-9e4c-97e1fe3bb43a"));
    info.setYearsOfStudy(4);
    info.setOccupationSectorOther("5ad0193f-69b0-45bd-9e8a-ce53e6f8bd24");
    info.setOccupationLevelUuid(UUID.fromString("4faad5f5-97e1-4d64-bec5-7d50bc0acf49"));
    info.setReasonForTestUuid(UUID.fromString("5db03c10-7c33-4ebb-b8ec-aa634236307a"));
    info.setApplyingToCountry3code("AUS");
    info.setCurrentEnglishStudyPlace("DJ Uni.");
    info.setOccupationSectorOther("string");
    info.setOccupationLevelOther("string");
    info.setReasonForTestOther("string");
    info.setCountryApplyingToOther("GRB");
    bookingDetails.setMarketingInfo(info);
    TestTakerDetails testTaker = new TestTakerDetails();
    testTaker.setBannedStatus(BannedStatusEnum.UNKNOWN);
    testTaker.setUniqueTestTakerUuid(null);
    testTaker.setShortCandidateNumber("000013");
    testTaker.setCompositeCandidateNumber("UK24620000013");
    testTaker.setExternalUniqueTestTakerUuid(
        UUID.fromString("5db03c10-7c33-4ebb-b8ec-aa634236307a"));
    testTaker.setIdentityNumber("AB12314");
    testTaker.setIdentityTypeUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
    testTaker.setIdentityVerificationStatus(IdentityVerificationStatusEnum.INCOMPLETE);
    testTaker.setIdentityIssuingAuthority("string");
    testTaker.setIdentityExpiryDate(
        LocalDate.parse("2022-06-01", DateTimeFormatter.ofPattern("yyyy-MM-dd")));
    testTaker.setFirstName("Alan");
    testTaker.setLastName("Davies");
    testTaker.setBirthDate(
        LocalDate.parse("1990-06-01", DateTimeFormatter.ofPattern("yyyy-MM-dd")));
    testTaker.setSex("M");
    testTaker.setEmail("alan@gmail.com");
    testTaker.setTitle("cef4fcb1-2bd2-51f3-889d-abd47d775668");
    testTaker.setPhone("");
    testTaker.setMobile("");
    testTaker.setLanguageUuid(UUID.fromString("1ef783e4-c4a0-4e0c-95ed-9ea35dca30f3"));
    testTaker.setNationalityUuid(UUID.fromString("0d9dbdd5-f1e6-4753-b7a9-573a898cd11c"));
    testTaker.setNotes("string");
    CMDSAddress ttaddress = new CMDSAddress();
    ttaddress.setCity("Melbourne");
    ttaddress.setPostalCode("1234");
    ttaddress.setAddressLine1("15");
    ttaddress.setAddressLine2("King Street");
    ttaddress.setAddressLine3("");
    ttaddress.setAddressLine4("");
    ttaddress.setStateTerritoryUuid(UUID.fromString("5432081f-453f-4a45-adf9-824531d8e2dc"));
    ttaddress.setCountryIso3Code("AND");
    testTaker.setAddress(ttaddress);
    bookingDetails.setTestTaker(testTaker);

    BookingLine bookingline = new BookingLine();
    bookingline.setBookingLineUuid(UUID.fromString("fc7663b9-b4cd-458a-bc1e-59e601888046"));
    bookingline.setExternalBookingLineUuid(UUID.fromString("fc7663b9-b4cd-458a-bc1e-59e601888046"));
    bookingline.setExtraTimeMinutes(0);
    bookingline.setProductUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
    LocalDateTime startTimeLocal =
        LocalDateTime.parse(
            "2020-08-14T15:20:35.723Z",
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
    bookingline.setStartTimeLocal(startTimeLocal);

    bookingline.setStartDatetime(
        Optional.ofNullable(OffsetDateTime.parse("2020-08-14T15:20:35.723Z"))
            .map(OffsetDateTime::toInstant)
            .orElse(null));

    bookingline.setBookingLineStatus(BookingLineStatusEnum.ACTIVE);
    List<BookingLine> bookingLineList = new ArrayList<>();
    bookingLineList.add(bookingline);
    bookingDetails.setBookingLines(bookingLineList);
    return bookingDetails;
  }

  protected static ObjectMapper getMapper() {
    ObjectMapper mapper = new ObjectMapper();
    mapper.registerModule(new JavaTimeModule());
    mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
    mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
    mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    return mapper;
  }

  public static BaseHeader getEventHeader() {
    BaseHeader eventHeader = new BaseHeader();
    eventHeader.setTransactionId(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
    eventHeader.setCallbackURL("https://wiremock.shared.cmdsiz.com/ors/invoke/v1/booking");
    eventHeader.setCorrelationId(UUID.fromString("779187f5-38ed-4e86-b311-050ffe394f81"));
    eventHeader.setPartnerCode("BC");
    eventHeader.setEventName("BookingCancelled");
    LocalDateTime eventDateTime =
        LocalDateTime.parse(
            "2020-09-29T21:00:35.723Z",
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
    eventHeader.setEventDateTime(eventDateTime);
    return eventHeader;
  }

  public static BaseHeader getBCEventHeader() {
    BaseHeader eventHeader = new BaseHeader();
    eventHeader.setTransactionId(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
    eventHeader.setCallbackURL("https://wiremock.shared.cmdsiz.com/ors/invoke/v1/booking");
    eventHeader.setCorrelationId(UUID.fromString("779187f5-38ed-4e86-b311-050ffe394f81"));
    eventHeader.setPartnerCode("BC");
    eventHeader.setEventName("BookingCreated");
    LocalDateTime eventDateTime =
        LocalDateTime.parse(
            "2020-09-29T21:00:35.723Z",
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
    eventHeader.setEventDateTime(eventDateTime);
    return eventHeader;
  }

  public static BaseHeader getIDPEventHeader() {
    BaseHeader eventHeader = new BaseHeader();
    eventHeader.setTransactionId(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
    eventHeader.setCallbackURL("https://wiremock.shared.cmdsiz.com/ors/invoke/v1/booking");
    eventHeader.setCorrelationId(UUID.fromString("779187f5-38ed-4e86-b311-050ffe394f81"));
    eventHeader.setPartnerCode("IDP");
    eventHeader.setEventName("BookingCreated");
    LocalDateTime eventDateTime =
        LocalDateTime.parse(
            "2020-09-29T21:00:35.723Z",
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
    eventHeader.setEventDateTime(eventDateTime);
    return eventHeader;
  }

  public static BaseHeader getBCCHNEventHeader() {
    BaseHeader eventHeader = new BaseHeader();
    eventHeader.setTransactionId(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
    eventHeader.setCallbackURL("https://wiremock.shared.cmdsiz.com/ors/invoke/v1/booking");
    eventHeader.setCorrelationId(UUID.fromString("779187f5-38ed-4e86-b311-050ffe394f81"));
    eventHeader.setPartnerCode("BC_CHN");
    eventHeader.setEventName("BookingCreated");
    LocalDateTime eventDateTime =
            LocalDateTime.parse(
                    "2020-09-29T21:00:35.723Z",
                    DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
    eventHeader.setEventDateTime(eventDateTime);
    return eventHeader;
  }

  public static BaseHeader getBookingRejectEventHeader() {
    BaseHeader eventHeader = new BaseHeader();
    eventHeader.setTransactionId(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
    eventHeader.setCallbackURL("https://wiremock.shared.cmdsiz.com/ors/invoke/v1/booking");
    eventHeader.setCorrelationId(UUID.fromString("779187f5-38ed-4e86-b311-050ffe394f81"));
    eventHeader.setPartnerCode("BC");
    eventHeader.setEventName(REFUND_REQUEST_CHANGED_REJECTED);
    LocalDateTime eventDateTime =
        LocalDateTime.parse(
            "2020-09-29T21:00:35.723Z",
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
    eventHeader.setEventDateTime(eventDateTime);
    return eventHeader;
  }

  public static BaseHeader getEmptyEventEventHeader() {
    BaseHeader eventHeader = new BaseHeader();
    eventHeader.setTransactionId(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
    eventHeader.setCallbackURL("https://wiremock.shared.cmdsiz.com/ors/invoke/v1/booking");
    eventHeader.setCorrelationId(UUID.fromString("779187f5-38ed-4e86-b311-050ffe394f81"));
    eventHeader.setPartnerCode("BC");
    eventHeader.setEventName(REFUND_REQUEST_CHANGED_REJECTED);
    LocalDateTime eventDateTime =
        LocalDateTime.parse(
            "2020-09-29T21:00:35.723Z",
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
    eventHeader.setEventDateTime(eventDateTime);
    return eventHeader;
  }

  public static String getIDPEventBody() throws JsonProcessingException {
    BaseHeader eventHeader = getIDPEventHeader();

    BookingDetails bookingDetails = getIDPBookingDetails();
    String eventBody = mapper.writeValueAsString(bookingDetails);

    List<ErrorDescription> errorList = new ArrayList<>();
    ErrorDescription description = new ErrorDescription();
    description.setInterfaceName("Booking");
    description.setType(ErrorTypeEnum.VALIDATION);
    description.setErrorCode("1234");
    Source source = Source.builder().value("").path("product_uuid").build();
    description.setSource(source);
    errorList.add(description);

    BaseEventErrors errorResponse = new BaseEventErrors(errorList);

    BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
    cmdsEvent.setEventHeader(eventHeader);
    cmdsEvent.setEventBody(eventBody);
    cmdsEvent.setEventErrors(errorResponse);
    return mapper.writeValueAsString(cmdsEvent);
  }

  public static String getBCCHNEventBody() throws JsonProcessingException {
    BaseHeader eventHeader = getBCCHNEventHeader();

    BookingDetails bookingDetails = getBCCHNBookingDetails();
    String eventBody = mapper.writeValueAsString(bookingDetails);

    List<ErrorDescription> errorList = new ArrayList<>();
    ErrorDescription description = new ErrorDescription();
    description.setInterfaceName("Booking");
    description.setType(ErrorTypeEnum.VALIDATION);
    description.setErrorCode("1234");
    Source source = Source.builder().value("").path("product_uuid").build();
    description.setSource(source);
    errorList.add(description);

    BaseEventErrors errorResponse = new BaseEventErrors(errorList);

    BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
    cmdsEvent.setEventHeader(eventHeader);
    cmdsEvent.setEventBody(eventBody);
    cmdsEvent.setEventErrors(errorResponse);
    return mapper.writeValueAsString(cmdsEvent);
  }

  public static BookingDetails getBCBookingDetails() {
    BookingDetails bookingDetails = new BookingDetails();
    bookingDetails.setExternalBookingUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775565"));
    bookingDetails.setBookingUuid(UUID.fromString("e8958327-9917-4af2-91ce-7c6cd0c19837"));
    bookingDetails.setIsVoid(true);
    return bookingDetails;
  }

  public static BookingDetails getIDPBookingDetails() {
    BookingDetails bookingDetails = new BookingDetails();
    bookingDetails.setExternalBookingUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775565"));
    bookingDetails.setBookingUuid(UUID.fromString("e8958327-9917-4af2-91ce-7c6cd0c19837"));
    bookingDetails.setIsVoid(true);
    return bookingDetails;
  }

  public static BookingDetails getBCCHNBookingDetails() {
    BookingDetails bookingDetails = new BookingDetails();
    bookingDetails.setExternalBookingUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775565"));
    bookingDetails.setBookingUuid(UUID.fromString("e8958327-9917-4af2-91ce-7c6cd0c19837"));
    bookingDetails.setIsVoid(true);
    return bookingDetails;
  }

  public static Map<String, String> getEnvironmentVariables(final String partnerCode)
      throws JsonProcessingException {
    final Map<String, String> map = new HashMap<>();

    if (System.getenv(CLIENT_ID) != null || System.getenv(CLIENT_SECRET) != null) {
      map.put(CLIENT_ID, System.getenv(CLIENT_ID) != null ? System.getenv(CLIENT_ID) : null);
      map.put(
          CLIENT_SECRET,
          System.getenv(CLIENT_SECRET) != null ? System.getenv(CLIENT_SECRET) : null);
    } else {
      Map<String, String> envVar = getEnvironmentVariablesStub();
      map.put(CLIENT_ID, envVar.get(CLIENT_ID));
      map.put("AWS_REGION", Regions.EU_WEST_2.getName());
      map.put(CLIENT_SECRET, envVar.get(CLIENT_SECRET));
    }
    return map;
  }

  public static Map<String, String> getEnvironmentVariablesStub() {
    Map<String, String> map = new HashMap<>();
    map.put(CLIENT_ID, "cmds-id");
    map.put(CLIENT_SECRET, "cmds-secret");
    map.put(ACCESS_TOKEN, "access-token");
    map.put("bc_auth_url", "BC_AUTH_URL");
    map.put(CALLBACK_URL, "https://wiremock.shared.cmdsiz.com/ors/invoke/v1/booking");
    return map;
  }

  protected static void setEnviornment(Map<String, String> newenv) throws Exception {
    try {
      Class<?> processEnvironmentClass = Class.forName("java.lang.ProcessEnvironment");
      Field theEnvironmentField = processEnvironmentClass.getDeclaredField("theEnvironment");
      theEnvironmentField.setAccessible(true);
      Map<String, String> env = (Map<String, String>) theEnvironmentField.get(null);
      env.putAll(newenv);
      Field theCaseInsensitiveEnvironmentField =
          processEnvironmentClass.getDeclaredField("theCaseInsensitiveEnvironment");
      theCaseInsensitiveEnvironmentField.setAccessible(true);
      Map<String, String> cienv =
          (Map<String, String>) theCaseInsensitiveEnvironmentField.get(null);
      cienv.putAll(newenv);
    } catch (NoSuchFieldException e) {
      Class[] classes = Collections.class.getDeclaredClasses();
      Map<String, String> env = System.getenv();
      for (Class cl : classes) {
        if ("java.util.Collections$UnmodifiableMap".equals(cl.getName())) {
          Field field = cl.getDeclaredField("m");
          field.setAccessible(true);
          Object obj = field.get(env);
          Map<String, String> map = (Map<String, String>) obj;
          map.clear();
          map.putAll(newenv);
        }
      }
    }
  }
}
