package com.ielts.cmds.security.clients;

import com.ielts.cmds.security.model.BCModel;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.util.MultiValueMap;

import static org.junit.jupiter.api.Assertions.*;

@RunWith(MockitoJUnitRunner.Silent.class)
public class TestBcAuthenticationContentType {


  @InjectMocks
  private TestBcAuthenticationClient testBcAuthenticationClient;
  @Mock
  private BCModel bcModel;

  private String authHeaderName;

  private String authUrl;


  @BeforeEach
  void init(){
    bcModel=new BCModel();
    testBcAuthenticationClient = new TestBcAuthenticationClient(bcModel);
    authHeaderName=bcModel.getAuthHeaderName();
    authUrl=bcModel.getAuthUrl();
  }

  @Test
  public void TestBC_authenticationClientForContentType_VerifyMediaType(){

    HttpEntity<MultiValueMap<String, String>> response=testBcAuthenticationClient.createBCAuthTokenRequest(bcModel);
    response.getHeaders().getContentType();
    assertNotNull(response);
    assertNotEquals("multipart/form-data",response.getHeaders().getContentType().toString());
    assertEquals("application/x-www-form-urlencoded",response.getHeaders().getContentType().toString());
  }


}