package com.ielts.cmds.integration;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.amazonaws.services.lambda.runtime.events.SQSEvent.SQSMessage;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.finance.common.out.model.RefundChangedV1;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.constants.DistORSConstants;
import com.ielts.cmds.integration.exception.ORSDistException;
import com.ielts.cmds.integration.mapper.EventMapper;
import com.ielts.cmds.integration.model.CMDSResponseBody;
import com.ielts.cmds.integration.model.ExtORSResponse;
import com.ielts.cmds.integration.model.ORSRefundRequestResponse;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.clients.BritishCouncilAuthenticationClient;
import com.ielts.cmds.security.clients.BritishCouncilChinaAuthenticationClient;
import com.ielts.cmds.security.clients.IDPAuthenticationClient;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;
import org.junit.*;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static com.ielts.cmds.integration.constants.DistORSConstants.*;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ORSRefundRequestedChangedChangedDistTest {
  @InjectMocks private ORSRefundRequestChangedDistBC refundRequestChangedDistBc;
  @InjectMocks private ORSRefundRequestChangedDistIDP refundRequestChangedDistIdp;
  @InjectMocks private ORSRefundRequestChangedDistBCCHN refundRequestChangedDistBcchn;
  @Mock private Context context;

  @Mock private RestTemplate restTemplate;
  private final ObjectMapper mapper = SQSEventBodySetup.getMapper();
  @Mock private EnvironmentAwareAuthenticationClientFactory authenticationFactory;
  @Mock BritishCouncilAuthenticationClient britishCouncilAuthenticationClient;


  @Mock private AuthenticationClient client;

  @Mock private IDPAuthenticationClient idpClient;
  @Mock private BritishCouncilChinaAuthenticationClient bcchnClient;

  @Spy private SQSEvent event;
  @Spy private SQSEvent eventIdp;
  @Spy private SQSEvent eventBcchn;
  @Spy private SQSMessage message;
  @Spy private SQSMessage messageIdp;
  @Spy private SQSMessage messageBcchn;
  @Mock private List<String> rejectedEvents;
  @InjectMocks
  @Rule public final ExpectedException exceptionRule = ExpectedException.none();
  @BeforeClass
  public static void beforeClass() throws Exception {
    Map<String, String> envVar = SQSEventBodySetup.getEnvironmentVariablesStub();
  }

  @AfterClass
  public static void afterClass() throws Exception {
    Mockito.framework().clearInlineMocks();
  }

  @Before
  public void setUp() throws JsonProcessingException {
    mapper.registerModule(new JavaTimeModule());
    mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);

    mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
    mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
    String eventBody = SQSEventBodySetup.getEventBody();
    message.setBody(eventBody);
    messageIdp.setBody(SQSEventBodySetup.getIDPEventBody());
    messageBcchn.setBody(SQSEventBodySetup.getBCCHNEventBody());
    List<SQSMessage> records = new ArrayList<>();
    records.add(message);
    event.setRecords(records);
    List<SQSMessage> recordIdps = new ArrayList<>();
    recordIdps.add(messageIdp);
    eventIdp.setRecords(recordIdps);
    List<SQSMessage> recordBcchns = new ArrayList<>();
    recordBcchns.add(messageBcchn);
    eventBcchn.setRecords(recordBcchns);
  }

  /*
   * When event header is null then Throw exception ORSDistException("Event header does not exist")
   */
  @Test
  public void whenEventHeaderIsNull_ThenThrowBookingDistException() throws Exception {
    // Given
    String expectedExceptionMsg = "EventHeaders does not exist";
    BaseEvent<BaseHeader> cmdsEvent = mapper.readValue(message.getBody(), BaseEvent.class);
    cmdsEvent.setEventHeader(null);
    cmdsEvent.setEventErrors(null);
    String eventBody = mapper.writeValueAsString(cmdsEvent);
    message.setBody(eventBody);
    assertThrows(NullPointerException.class,()->refundRequestChangedDistBc.handleRequest(event, context));

  }

  /*
   * When event body is null then Throw exception ORSDistException("Event headers does not exist")
   */
  @Test
  public void whenEventBodyIsNull_ThenThrowBookingDistException() throws Exception {
    // Given
    String expectedExceptionMsg = "EventHeaders does not exist";
    BaseEvent<BaseHeader> cmdsEvent = mapper.readValue(message.getBody(), BaseEvent.class);
    cmdsEvent.setEventHeader(null);
    cmdsEvent.setEventErrors(null);
    cmdsEvent.setEventBody("");
    String eventBody = mapper.writeValueAsString(cmdsEvent);
    message.setBody(eventBody);

    assertThrows(NullPointerException.class,()->refundRequestChangedDistBc.handleRequest(event, context));

  }

  @Test
  public void whenRejectEventWithBodyEmpty_ThenThrowBookingDistException() throws Exception {
    // Given
    String expectedExceptionMsg = "No event body to publish for sqs message";
    BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
    cmdsEvent.setEventHeader(SQSEventBodySetup.getBookingRejectEventHeader());
    cmdsEvent.setEventErrors(null);
    cmdsEvent.setEventBody(null);
    String eventBody = mapper.writeValueAsString(cmdsEvent);
    message.setBody(eventBody);
    assertDoesNotThrow(()->refundRequestChangedDistBc.handleRequest(event, context));

  }

  @Test
  public void whenRejectEventWithBody_ThenThrowBookingDistException() throws Exception {
    // Given
    String expectedExceptionMsg = "region must not be null";
    BaseEvent<BaseHeader>cmdsEvent = new BaseEvent<BaseHeader> ();
    cmdsEvent.setEventHeader(SQSEventBodySetup.getEmptyEventEventHeader());
    cmdsEvent.setEventErrors(null);
    cmdsEvent.setEventBody(message.getBody());
    message.setBody(SQSEventBodySetup.getEventBody());
    assertDoesNotThrow(()->refundRequestChangedDistBc.handleRequest(event, context));

  }

  /*
   * When transactionId is null or empty then Throw exception ORSDistException("Transaction id does not exist")
   */

  @Test
  public void whenTransactionIdIsNull_ThenThrowBookingDistException() throws Exception {
    // Given
    String expectedExceptionMsg = "Transaction ID can't be null";
    BaseEvent<BaseHeader>  cmdsEvent = mapper.readValue(message.getBody(), BaseEvent.class);
    cmdsEvent.getEventHeader().setTransactionId(null);
    cmdsEvent.setEventErrors(null);
    String eventBody = mapper.writeValueAsString(cmdsEvent);
    message.setBody(eventBody);
    assertThrows(NullPointerException.class,()->refundRequestChangedDistBc.handleRequest(event, context));

  }

  /*
   * When EventType is null or empty then Throw exception ORSDistException("EventType does not exist")
   */
  @Test
  public void whenEventTypeIsNull_ThenThrowBookingDistException() throws Exception {
    // Given
    String expectedExceptionMsg = "EventName can't be null or empty";
    BaseEvent<BaseHeader> cmdsEvent = mapper.readValue(message.getBody(),BaseEvent.class);
    cmdsEvent.getEventHeader().setEventName("");
    cmdsEvent.setEventErrors(null);
    String eventBody = mapper.writeValueAsString(cmdsEvent);
    message.setBody(eventBody);
    assertDoesNotThrow(()->refundRequestChangedDistBc.handleRequest(event, context));

  }

  /*
   * When event errors is null and eventType contains rejected then Throw exception ORSDistException("No event body to publish")
   */

  @Test
  public void whenNullEventErrorsAndEventTypeContainsRejected_ThenThrowBookingDistException()
          throws Exception {
    String expectedExceptionMsg = "No event errors to publish for sqs message";
    BaseEvent<BaseHeader>  cmdsEvent = mapper.readValue(message.getBody(), BaseEvent.class);
    cmdsEvent.getEventHeader().setEventName("REFUND_REQUEST_CHANGED_REJECTED");
    cmdsEvent.setEventBody(null);
    String eventBody = mapper.writeValueAsString(cmdsEvent);
    message.setBody(eventBody);
    when(rejectedEvents.contains(REFUND_REQUEST_CHANGED_REJECTED)).thenReturn(true);
    assertDoesNotThrow(()->refundRequestChangedDistBc.handleRequest(event, context));

  }

  @Test
  public void testExtBookingResponseModel_ValidateNull() throws JsonProcessingException {
    ExtORSResponse extResponse = new ExtORSResponse(null, null);
    assertNull(extResponse.getResponse());
    assertNull(extResponse.getErrors());
  }

  @Test
  public void testExtBookingResponseModel_ValidateNotNull() throws JsonProcessingException {
    final EventMapper eventMapper = new EventMapper();

    final RefundChangedV1 refundRequestedDetails =
            mapper.readValue(SQSEventBodySetup.getEventBody(), RefundChangedV1.class);
    ORSRefundRequestResponse ORSRefundRequestResponse = eventMapper.mapRefundResponse(refundRequestedDetails);
    ExtORSResponse extResponse = new ExtORSResponse(ORSRefundRequestResponse, SQSEventBodySetup.getCMDSErrorResponse());
    assertNotNull(extResponse.getResponse());
    assertNotNull(extResponse.getErrors());
  }

  /*
   * clean up resources
   */
  @After
  public void tearDown() {
    message = null;
    event = null;
  }

  /*
   * used to return expected api request body
   */
  private CMDSResponseBody getAPIRequestBody(BaseEvent<BaseHeader> cmdsEvent) throws Exception {
    List<String> rejectedEvents = Arrays.asList(REFUND_REQUEST_CHANGED_REJECTED);
    EventMapper eventMapper = new EventMapper();
    ORSRefundRequestResponse ORSRefundRequestResponse = null;
    if (!rejectedEvents.contains(cmdsEvent.getEventHeader().getEventName())) {
      RefundChangedV1  refundRequestedDetails =
              mapper.readValue(cmdsEvent.getEventBody().toString(), RefundChangedV1.class);
      ORSRefundRequestResponse = eventMapper.mapRefundResponse(refundRequestedDetails);
    }
    CMDSResponseBody resBody = new ExtORSResponse(ORSRefundRequestResponse, cmdsEvent.getEventErrors());
    return resBody;
  }

  /**
   * constructs httpheader based on provided eventheader
   *
   * @param eventHeader
   * @return
   */
  private HttpHeaders getHttpHeaders(BaseHeader eventHeader) {
    HttpHeaders httpHeaders = new HttpHeaders();
    httpHeaders.setContentType(MediaType.APPLICATION_JSON);
    httpHeaders.set(TRANSACTIONID, eventHeader.getTransactionId().toString());
    httpHeaders.set(CORRELATIONID, eventHeader.getCorrelationId().toString());

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
    httpHeaders.set(
            EVENT_DATE_TIME,
            Objects.isNull(eventHeader.getEventDateTime())
                    ? ""
                    : eventHeader.getEventDateTime().format(formatter));
    return httpHeaders;
  }

  @Test
  public void whenBCRequestHasValidAuthenticationHeader_ThenVerifyCallToRestTemplate() throws Exception {
    //Prepare test data
    BaseEvent<BaseHeader> baseEvent = mapper.readValue(message.getBody(), BaseEvent.class);
    Map<String, String> map = new HashMap<>();
    map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
    map.put(CALLBACK_URL, SQSEventBodySetup.getEnvironmentVariablesStub().get(CALLBACK_URL));
    map.put(AUTH_HEADER, "Authorization");
    map.put(USER_AGENT, "CMDS");
    ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.OK);
    HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
    eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));
    //Define mock variables behaviour
    when(authenticationFactory.getAuthenticationClient(baseEvent.getEventHeader().getPartnerCode())).thenReturn(britishCouncilAuthenticationClient);
    ReflectionTestUtils.setField(refundRequestChangedDistBc, "authenticationClientFactory", authenticationFactory);
    doReturn("authHeaderName").when(britishCouncilAuthenticationClient).getAuthorizationHeaderName();
    doReturn("accessToken").when(britishCouncilAuthenticationClient).getAccessToken();
    doReturn(restTemplate).when(britishCouncilAuthenticationClient).getRestTemplate();
    when(restTemplate.postForEntity(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.any(Class.class)))
            .thenReturn(response2);

    SQSEventBodySetup.setEnviornment(map);
    //Execute and assert test
    assertDoesNotThrow(() -> refundRequestChangedDistBc.handleRequest(event, context));
  }

  private HttpHeaders getHttpHeaders(BaseEvent<BaseHeader> eventHeader) {
    HttpHeaders httpHeaders = new HttpHeaders();
    httpHeaders.setContentType(MediaType.APPLICATION_JSON);
    httpHeaders.set(TRANSACTIONID, eventHeader.getEventHeader().getTransactionId().toString());
    httpHeaders.set(CORRELATIONID, eventHeader.getEventHeader().getCorrelationId().toString());
    httpHeaders.set(PARTNER_CODE, eventHeader.getEventHeader().getPartnerCode());
    return httpHeaders;
  }



  @Test
  public void whenBCRequestHasInValidAuthenticationHeader_ThenThrowsException() throws Exception {
    //Prepare test data
    BaseEvent<BaseHeader>  baseEvent = mapper.readValue(message.getBody(), BaseEvent.class);
    Map<String, String> map = new HashMap<>();
    map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
    //map.put(ACCESS_TOKEN, com.ielts.cmds.integration.utils.SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
    map.put(AUTH_HEADER, "Authorization");
    ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
    eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));
    //Define mock variables behaviour
    when(authenticationFactory.getAuthenticationClient(baseEvent.getEventHeader().getPartnerCode())).thenReturn(britishCouncilAuthenticationClient);
    ReflectionTestUtils.setField(refundRequestChangedDistBc, "authenticationClientFactory", authenticationFactory);
    doReturn("authHeaderName").when(britishCouncilAuthenticationClient).getAuthorizationHeaderName();
    doReturn("accessToken").when(britishCouncilAuthenticationClient).getAccessToken();
    doReturn(restTemplate).when(britishCouncilAuthenticationClient).getRestTemplate();
    when(restTemplate.postForEntity(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.any(Class.class))).thenReturn(response2);
    //Execute and assert test
    assertDoesNotThrow(() -> refundRequestChangedDistBc.handleRequest(event, context));
  }

  @Test
  public void whenBCRequestHasInvalidAuthenticationHeader_ThenDoesNotThrowException() throws Exception {
    //Prepare test data
    BaseEvent<BaseHeader>  baseEvent = mapper.readValue(message.getBody(), BaseEvent.class);
    Map<String, String> map = new HashMap<>();
    map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
    map.put(CALLBACK_URL, SQSEventBodySetup.getEnvironmentVariablesStub().get(CALLBACK_URL));
    map.put(AUTH_HEADER, "Authorization");
    SQSEventBodySetup.setEnviornment(map);
    ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.OK);
    HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
    eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));
    //Define mock variables behaviour
    when(authenticationFactory.getAuthenticationClient(baseEvent.getEventHeader().getPartnerCode())).thenReturn(britishCouncilAuthenticationClient);
    ReflectionTestUtils.setField(refundRequestChangedDistBc, "authenticationClientFactory", authenticationFactory);
    doReturn("authHeaderName").when(britishCouncilAuthenticationClient).getAuthorizationHeaderName();
    doReturn("accessToken").when(britishCouncilAuthenticationClient).getAccessToken();
    doReturn(restTemplate).when(britishCouncilAuthenticationClient).getRestTemplate();
    when(restTemplate.postForEntity(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.any(Class.class))).thenReturn(response2);

    /* Execute and assert test */
    assertDoesNotThrow(() -> refundRequestChangedDistBc.handleRequest(event, context));
  }

  @Test
  public void whenIDPRequestHasInvalidAuthenticationHeader_ThenDoesNotThrowException() throws Exception {
    //Prepare test data
    BaseEvent<BaseHeader>  baseEvent = mapper.readValue(message.getBody(), BaseEvent.class);
    Map<String, String> map = new HashMap<>();
    map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
    map.put(AUTH_HEADER, "Authorization");
    ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.OK);
    HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
    eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));
    //Define mock variables behaviour
    when(authenticationFactory.getAuthenticationClient(baseEvent.getEventHeader().getPartnerCode())).thenReturn(idpClient);
    ReflectionTestUtils.setField(refundRequestChangedDistIdp, "authenticationClientFactory", authenticationFactory);
    doReturn("authHeaderName").when(idpClient).getAuthorizationHeaderName();
    doReturn("accessToken").when(idpClient).getAccessToken();
    doReturn(restTemplate).when(idpClient).getRestTemplate();
    when(restTemplate.postForEntity(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.any(Class.class))).thenReturn(response2);
    //Execute and assert test
    assertDoesNotThrow(() -> refundRequestChangedDistIdp.handleRequest(event, context));
  }

  @Test
  public void whenIDPRequestHasInValidAuthenticationHeader_ThenThrowsException() throws Exception {
    BaseEvent<BaseHeader>  baseEvent = mapper.readValue(messageIdp.getBody(), BaseEvent.class);
    Map<String, String> map = new HashMap<>();
    map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
    //map.put(ACCESS_TOKEN, com.ielts.cmds.integration.utils.SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
    map.put(AUTH_HEADER, "Authorization");
    ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.BAD_GATEWAY);
    HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
    eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));
    //Define mock variables behaviour
    when(authenticationFactory.getAuthenticationClient(baseEvent.getEventHeader().getPartnerCode())).thenReturn(idpClient);
    ReflectionTestUtils.setField(refundRequestChangedDistIdp, "authenticationClientFactory", authenticationFactory);
    doReturn("authHeaderName").when(idpClient).getAuthorizationHeaderName();
    doReturn("accessToken").when(idpClient).getAccessToken();
    doReturn(restTemplate).when(idpClient).getRestTemplate();
    when(restTemplate.postForEntity(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpEntity.class),
            ArgumentMatchers.any(Class.class))).thenReturn(response2);

    //Execute and assert test
    assertDoesNotThrow( () -> refundRequestChangedDistIdp.handleRequest(eventIdp, context));
  }

  @Test
  public void whenBCCHNRequestHasInvalidAuthenticationHeader_ThenDoesNotThrowException() throws Exception {
    //Prepare test data
    BaseEvent<BaseHeader>  baseEvent = mapper.readValue(message.getBody(), BaseEvent.class);
    Map<String, String> map = new HashMap<>();
    map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
    map.put(AUTH_HEADER, "Authorization");
    ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.OK);
    HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
    eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));
    //Define mock variables behaviour
    when(authenticationFactory.getAuthenticationClient(baseEvent.getEventHeader().getPartnerCode())).thenReturn(bcchnClient);
    ReflectionTestUtils.setField(refundRequestChangedDistBcchn, "authenticationClientFactory", authenticationFactory);
    doReturn("authHeaderName").when(bcchnClient).getAuthorizationHeaderName();
    doReturn("accessToken").when(bcchnClient).getAccessToken();
    doReturn(restTemplate).when(bcchnClient).getRestTemplate();
    when(restTemplate.postForEntity(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.any(Class.class))).thenReturn(response2);
    //Execute and assert test
    assertDoesNotThrow(() -> refundRequestChangedDistBcchn.handleRequest(event, context));
  }

  @Test
  public void whenBCCHNRequestHasInValidAuthenticationHeader_ThenThrowsException() throws Exception {
    BaseEvent<BaseHeader>  baseEvent = mapper.readValue(messageBcchn.getBody(), BaseEvent.class);
    Map<String, String> map = new HashMap<>();
    map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
    //map.put(ACCESS_TOKEN, com.ielts.cmds.integration.utils.SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
    map.put(AUTH_HEADER, "Authorization");
    ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.BAD_GATEWAY);
    HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
    eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));
    //Define mock variables behaviour
    when(authenticationFactory.getAuthenticationClient(baseEvent.getEventHeader().getPartnerCode())).thenReturn(bcchnClient);
    ReflectionTestUtils.setField(refundRequestChangedDistBcchn, "authenticationClientFactory", authenticationFactory);
    doReturn("authHeaderName").when(bcchnClient).getAuthorizationHeaderName();
    doReturn("accessToken").when(bcchnClient).getAccessToken();
    doReturn(restTemplate).when(bcchnClient).getRestTemplate();
    when(restTemplate.postForEntity(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpEntity.class),
            ArgumentMatchers.any(Class.class))).thenReturn(response2);

    //Execute and assert test
    assertDoesNotThrow( () -> refundRequestChangedDistBcchn.handleRequest(eventBcchn, context));
  }

  @Test
  public void getApplicationName_whenGetApplicationName_thenReturnInvalidApplicationNameForBC() {
    String applicationName = refundRequestChangedDistBc.getApplicationName();
    // Then
    assertEquals(ORS_REFUNDREQUESTCHANGED_DIST_BC, applicationName);
  }

  @Test
  public void getApplicationName_whenGetApplicationName_thenReturnInvalidApplicationNameForIDP() {
    String applicationName = refundRequestChangedDistIdp.getApplicationName();
    // Then
    assertEquals(DistORSConstants.ORS_REFUNDREQUESTCHANGED_DIST_IDP, applicationName);
  }

  @Test
  public void getApplicationName_whenGetApplicationName_thenReturnInvalidApplicationNameForBCCHN() {
    String applicationName = refundRequestChangedDistBcchn.getApplicationName();
    // Then
    assertEquals(DistORSConstants.ORS_REFUNDREQUESTCHANGED_DIST_BCCHN, applicationName);
  }
  @Test
  public void getPartnerCodeConstants_whenGetPartnerCodeConstants_thenReturnBC() {
    String partnerCodeConstants = refundRequestChangedDistBc.getPartnerCodeConstants();
    // Then
    assertEquals(DistORSConstants.BC, partnerCodeConstants);
  }
  @Test
  public void getPartnerCodeConstants_whenGetPartnerCodeConstants_thenReturnIDP() {
    String partnerCodeConstants = refundRequestChangedDistIdp.getPartnerCodeConstants();
    // Then
    assertEquals(DistORSConstants.IDP, partnerCodeConstants);
  }
  @Test
  public void getPartnerCodeConstants_whenGetPartnerCodeConstants_thenReturnBCCHN() {
    String partnerCodeConstants = refundRequestChangedDistBcchn.getPartnerCodeConstants();
    // Then
    assertEquals(DistORSConstants.BC_CHN, partnerCodeConstants);
  }

  private HttpEntity<CMDSResponseBody> setAuthClientComponents() throws Exception {
    String eventBody = SQSEventBodySetup.getIDPEventBody();
    message.setBody(eventBody);
    List<SQSMessage> records = new ArrayList<>();
    records.add(message);
    event.setRecords(records);
    BaseEvent<BaseHeader> cmdsEvent = mapper.readValue(message.getBody(), BaseEvent.class);
    cmdsEvent.setEventErrors(null);
    String sqsBody = mapper.writeValueAsString(cmdsEvent);
    message.setBody(sqsBody);
    // setup data for api request body to post
    CMDSResponseBody expectedAPIReqBody = getAPIRequestBody(cmdsEvent);
    HttpHeaders eventHeaders = getHttpHeaders(cmdsEvent.getEventHeader());
    eventHeaders.set("Authorization", SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
    HttpEntity<CMDSResponseBody> eventEntity = new HttpEntity<>(expectedAPIReqBody, eventHeaders);
    return eventEntity;
  }

  @Test
  public void whenNotNullEventErrorsAndEventTypeContainsRejected_ThenThrowBookingDistException()
          throws Exception {
    BaseEvent<BaseHeader>  cmdsEvent = mapper.readValue(message.getBody(), BaseEvent.class);
    cmdsEvent.getEventHeader().setEventName(REFUND_REQUEST_CHANGED_REJECTED);

    cmdsEvent.setEventErrors(SQSEventBodySetup.getCMDSErrorResponse());
    String eventBody = mapper.writeValueAsString(cmdsEvent);
    message.setBody(eventBody);
    cmdsEvent.setEventBody(eventBody);

    Map<String, String> map = new HashMap<>();
    map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
    map.put(AUTH_HEADER, "Authorization");
    HttpHeaders eventHeaders = getHttpHeaders(cmdsEvent.getEventHeader());
    eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));

    assertDoesNotThrow(()->refundRequestChangedDistBc.handleRequest(event, context));

  }
}
