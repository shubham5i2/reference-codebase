package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.constants.DistORSConstants.BC;
import static com.ielts.cmds.integration.constants.DistORSConstants.CORRELATIONID;
import static com.ielts.cmds.integration.constants.DistORSConstants.EVENT_DATETIME;
import static com.ielts.cmds.integration.constants.DistORSConstants.USER_AGENT;
import static com.ielts.cmds.integration.constants.DistORSConstants.USER_AGENT_HEADER;

import java.math.BigDecimal;
import java.security.KeyStoreException;
import java.security.cert.CertificateException;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.client.HttpClientErrorException;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.common.logger.util.CMDSLambdaLoggerUtil;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.constants.DistORSConstants;
import com.ielts.cmds.integration.enums.PartnerCodeEnum;
import com.ielts.cmds.integration.models.Address;
import com.ielts.cmds.integration.models.AlternateName;
import com.ielts.cmds.integration.models.ComponentMinimumScores;
import com.ielts.cmds.integration.models.Contact;
import com.ielts.cmds.integration.models.MinimumScore;
import com.ielts.cmds.integration.models.Note;
import com.ielts.cmds.integration.models.RecognisedProduct;
import com.ielts.cmds.integration.models.RecognisingOrganisation;
import com.ielts.cmds.organisation.common.enums.ComponentEnum;
import com.ielts.cmds.organisation.common.enums.LinkTypeEnum;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Address;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Addresses;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1AlternateName;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1AlternateNames;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Contact;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Contacts;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1LinkedOrganisation;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1MinimumScore;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1MinimumScores;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Note;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Notes;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1RecognisedProduct;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1RecognisedProducts;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.exception.InvalidClientException;
import com.ielts.cmds.security.exception.TokenNotReceivedException;

import lombok.extern.slf4j.Slf4j;

/**
 * This class serves the purpose of handling RO response to External system(ORS - British Council,
 * IDP) It reads ro events specific to BC, IDP and post it back on callbackURL
 */
@Slf4j
public abstract class ORSROChangedDist {

	private final ObjectMapper mapper;

	protected ORSROChangedDist() {
		this.mapper = new ObjectMapper();
		mapper.registerModule(new JavaTimeModule());
		mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
		mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
		mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
		mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
	}

	/**
	 * This method will be triggered on events published to ORS queue. It reads SQS records,validate
	 * it and post to external system(ORS)
	 *
	 * <p>// * @param SQSEvent // * @param Context
	 * @throws InvalidClientException 
	 * @throws TokenNotReceivedException 
	 * @throws KeyStoreException 
	 * @throws CertificateException 
	 */
	public void handleRequest(final SQSEvent input, final Context context) throws CertificateException, KeyStoreException, TokenNotReceivedException, InvalidClientException {

		for (SQSEvent.SQSMessage message : input.getRecords()) {
			final String sqsMessage = message.getBody();
			log.trace("Incoming request for ORS:{}", sqsMessage);
			BaseEvent<? extends BaseHeader> event = null;
			try {
				event = validateHeadersAndBody(sqsMessage);
				final BaseHeader eventHeader = event.getEventHeader();
				final String eventName = eventHeader.getEventName();
				final UUID transactionId = eventHeader.getTransactionId();
				initializeLogger(eventHeader, context);
				log.debug(
						"Event Received in {}:{} with metadata as {} and error as {}",
						DistORSConstants.RO,
						getApplicationName(),
						event.getEventHeader(),
						event.getEventErrors());

				log.debug(
						"Start: TransactionId:{} Event:{} CorrelationId:{} SQSMessage:{}",
						transactionId,
						eventName,
						eventHeader.getCorrelationId(),
						sqsMessage);
				mapAndSendExternalEvent(event);

				log.debug(
						"End: TransactionId:{} Event:{} CorrelationId:{}",
						transactionId,
						eventName,
						eventHeader.getCorrelationId());

			} catch(HttpClientErrorException | JsonProcessingException| CertificateException| KeyStoreException| TokenNotReceivedException | InvalidClientException e){
			      log.warn("Client Exception on processing event :", e);
		    }

		}
	}


	private void mapAndSendExternalEvent(BaseEvent<? extends BaseHeader> cmdsEvent) throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException, InvalidClientException {

		RoChangedEventV1 roChangedEvent =
				mapper.readValue(cmdsEvent.getEventBody(), RoChangedEventV1.class);
		RecognisingOrganisation orgDetailsTobeSentToOrs = new RecognisingOrganisation();
		orgDetailsTobeSentToOrs =
				setAllIndividualOrgDetails(orgDetailsTobeSentToOrs, roChangedEvent);
		log.debug(
				"Posting the following Request to ExternalAPI : {}",
				mapper.writeValueAsString(orgDetailsTobeSentToOrs));
		postRequestToExternalAPI(orgDetailsTobeSentToOrs, cmdsEvent);
	}

	protected RecognisingOrganisation setAllIndividualOrgDetails(
			RecognisingOrganisation orgDetailsTobeSentToOrs, RoChangedEventV1 roChangedEvent) {
		orgDetailsTobeSentToOrs.setRecognisingOrganisationUuid(
				roChangedEvent.getRecognisingOrganisationUuid());
		orgDetailsTobeSentToOrs.setOrganisationId(roChangedEvent.getOrganisationId());
		orgDetailsTobeSentToOrs.setOrganisationName(roChangedEvent.getOrganisationName());
		orgDetailsTobeSentToOrs.setOrganisationTypeUuid(roChangedEvent.getOrganisationTypeUuid());
		orgDetailsTobeSentToOrs.setVerificationStatus(roChangedEvent.getVerificationStatus());
		orgDetailsTobeSentToOrs.setAddresses(getAddressList(roChangedEvent.getAddresses()));
		orgDetailsTobeSentToOrs.setPartnerCode(
				PartnerCodeEnum.valueOf(roChangedEvent.getPartnerCode()));
		orgDetailsTobeSentToOrs.setPartnerContact(roChangedEvent.getPartnerContact());
		orgDetailsTobeSentToOrs.setMethodOfDelivery(roChangedEvent.getMethodOfDelivery());
		orgDetailsTobeSentToOrs.setSectorTypeUuid(roChangedEvent.getSectorTypeUuid());
		orgDetailsTobeSentToOrs.setOrganisationStatus(roChangedEvent.getOrganisationStatus());
		orgDetailsTobeSentToOrs.setIeltsDisplayFlag(roChangedEvent.getIeltsDisplayFlag());
		orgDetailsTobeSentToOrs.setSelectForResultsDelivery(roChangedEvent.getOrsDisplayFlag());
		UUID targetUuid =
				roChangedEvent.getLinkedOrganisations().stream()
				.filter(
						linkedOrganisation ->
						LinkTypeEnum.PARENT_RO == linkedOrganisation.getLinkType())
				.map(
						RoChangedEventV1LinkedOrganisation
						::getTargetRecognisingOrganisationUuid)
				.findAny()
				.orElse(null);
		orgDetailsTobeSentToOrs.setParentRecognisingOrganisationUuid(targetUuid);
		if (roChangedEvent.getWebsiteUrl() != null
				&& roChangedEvent.getWebsiteUrl().length() > 100) {
			orgDetailsTobeSentToOrs.setWebsiteUrl(roChangedEvent.getWebsiteUrl().substring(0, 100));
		} else {
			orgDetailsTobeSentToOrs.setWebsiteUrl(roChangedEvent.getWebsiteUrl());
		}
		orgDetailsTobeSentToOrs.setOrganisationCode(roChangedEvent.getOrganisationCode());
		UUID replaceById =
				roChangedEvent.getLinkedOrganisations().stream()
				.filter(
						linkedOrganisation ->
						LinkTypeEnum.REPLACED_BY == linkedOrganisation.getLinkType())
				.map(
						RoChangedEventV1LinkedOrganisation
						::getTargetRecognisingOrganisationUuid)
				.findAny()
				.orElse(null);
		orgDetailsTobeSentToOrs.setReplacedByRecognisingOrganisationUuid(replaceById);
		orgDetailsTobeSentToOrs.setNotes(getNotesList(roChangedEvent.getNotes()));
		orgDetailsTobeSentToOrs.setAlternateNames(
				getAlternateNamesList(roChangedEvent.getAlternateNames()));
		orgDetailsTobeSentToOrs.setContacts(getContactsList(roChangedEvent.getContacts()));
		orgDetailsTobeSentToOrs.setMinimumScore(
				getMinimumScoresList(roChangedEvent.getMinimumScores()));
		orgDetailsTobeSentToOrs.setRecognisedProducts(
				getRecognisedProductsList(roChangedEvent.getRecognisedProducts()));
		return orgDetailsTobeSentToOrs;
	}

	protected List<Address> getAddressList(RoChangedEventV1Addresses eventAddresses) {
		List<Address> addressList = new ArrayList<>();
		if (!eventAddresses.isEmpty()) {
			for (RoChangedEventV1Address eventAddress : eventAddresses) {
				Address address = new Address();
				address.setAddressUuid(eventAddress.getAddressUuid());
				address.setAddressTypeUuid(eventAddress.getAddressTypeUuid());
				address.setAddressLine1(eventAddress.getAddressLine1());
				address.setAddressLine2(eventAddress.getAddressLine2());
				address.setAddressLine3(eventAddress.getAddressLine3());
				address.setAddressLine4(eventAddress.getAddressLine4());
				address.setCity(eventAddress.getCity());
				address.setTerritoryUuid(eventAddress.getTerritoryUuid());
				address.setPostalCode(eventAddress.getPostalCode());
				address.setCountryUuid(eventAddress.getCountryUuid());
				address.setEmail(eventAddress.getEmail());
				address.setPhone(eventAddress.getPhone());
				addressList.add(address);
			}
		}
		return addressList;
	}

	protected List<Contact> getContactsList(RoChangedEventV1Contacts cmdsContacts) {
		List<Contact> contactList = new ArrayList<>();
		if (!cmdsContacts.isEmpty()) {
			for (RoChangedEventV1Contact cmdsContact : cmdsContacts) {
				Contact contact = new Contact();
				contact.setContactUuid(cmdsContact.getContactUuid());
				contact.setFirstName(cmdsContact.getFirstName());
				contact.setLastName(cmdsContact.getLastName());
				contact.setContactTypeUuid(cmdsContact.getContactTypeUuid());
				contact.setKnownName(cmdsContact.getFirstName() + " " + cmdsContact.getLastName());
				contact.setEffectiveFromDateTime(cmdsContact.getEffectiveFromDateTime());
				contact.setEffectiveToDateTime(cmdsContact.getEffectiveToDateTime());
				contact.setAddresses(getAddressList(cmdsContact.getAddresses()));
				contactList.add(contact);
			}
		}
		return contactList;
	}

	protected List<Note> getNotesList(RoChangedEventV1Notes eventNotes) {
		List<Note> notesList = new ArrayList<>();
		if (!eventNotes.isEmpty()) {
			for (RoChangedEventV1Note eventNote : eventNotes) {
				Note note = new Note();
				note.setNoteUuid(eventNote.getNoteUuid());
				note.setNoteTypeUuid(eventNote.getNoteTypeUuid());
				note.setNoteContent(eventNote.getNoteContent());
				note.setUpdatedDatetime(eventNote.getUpdatedDatetime());
				notesList.add(note);
			}
		}
		return notesList;
	}

	protected List<AlternateName> getAlternateNamesList(
			RoChangedEventV1AlternateNames eventAltNames) {
		List<AlternateName> altNamesList = new ArrayList<>();
		if (!eventAltNames.isEmpty()) {
			for (RoChangedEventV1AlternateName eventAltName : eventAltNames) {
				AlternateName altName = new AlternateName();
				altName.setAlternateNameUuid(eventAltName.getAlternateNameUuid());
				altName.setName(eventAltName.getName());
				altNamesList.add(altName);
			}
		}
		return altNamesList;
	}

	protected List<RecognisedProduct> getRecognisedProductsList(
			RoChangedEventV1RecognisedProducts cmdsRecognisedProducts) {
		List<RecognisedProduct> recognisedProductsList = new ArrayList<>();
		if (!cmdsRecognisedProducts.isEmpty()) {
			for (RoChangedEventV1RecognisedProduct cmdsRecognisedProduct : cmdsRecognisedProducts) {
				RecognisedProduct recognisedProduct = new RecognisedProduct();
				recognisedProduct.setRecognisedProductUuid(
						cmdsRecognisedProduct.getRecognisedProductUuid());
				recognisedProduct.setProductUuid(cmdsRecognisedProduct.getProductUuid());
				recognisedProduct.setEffectiveFromDateTime(
						cmdsRecognisedProduct.getEffectiveFromDateTime());
				recognisedProduct.setEffectiveToDateTime(
						cmdsRecognisedProduct.getEffectiveToDateTime());
				recognisedProductsList.add(recognisedProduct);
			}
		}
		return recognisedProductsList;
	}

	protected List<MinimumScore> getMinimumScoresList(
			RoChangedEventV1MinimumScores cmdsMinimumScores) {
		List<MinimumScore> minimumScoresList = new ArrayList<>();
		if (!cmdsMinimumScores.isEmpty()) {
			Map<UUID, EnumMap<ComponentEnum, BigDecimal>> moduleTypeMap = new HashMap<>();

			for (RoChangedEventV1MinimumScore cmdsMinimumScore : cmdsMinimumScores) {
				if (moduleTypeMap.containsKey(cmdsMinimumScore.getModuleTypeUuid())) {
					EnumMap<ComponentEnum, BigDecimal> currentModuleValue =
							moduleTypeMap.get(cmdsMinimumScore.getModuleTypeUuid());
					currentModuleValue.put(
							cmdsMinimumScore.getComponent(),
							cmdsMinimumScore.getMinimumScoreValue());
				} else {
					EnumMap<ComponentEnum, BigDecimal> componentMinScore =
							new EnumMap<>(ComponentEnum.class);
					componentMinScore.put(
							cmdsMinimumScore.getComponent(),
							cmdsMinimumScore.getMinimumScoreValue());
					moduleTypeMap.put(cmdsMinimumScore.getModuleTypeUuid(), componentMinScore);
				}
			}
			moduleTypeMap.forEach(
					(moduleType, minimumScoreValues) -> {
						MinimumScore minimumScore = new MinimumScore();
						minimumScore.setModuleTypeUuid(moduleType);
						List<ComponentMinimumScores> componentMinScoresList = new ArrayList<>();
						minimumScoreValues.forEach(
								(component, minScore) -> {
									if (ComponentEnum.ALL == component) {
										minimumScore.setOverallMinimumScore(minScore.floatValue());
									} else {
										ComponentMinimumScores componentMinimumScores =
												new ComponentMinimumScores();
										componentMinimumScores.setComponent(component);
										componentMinimumScores.setMinimumScore(
												minScore.floatValue());
										componentMinScoresList.add(componentMinimumScores);
									}
									minimumScore.setComponentMinimumScores(componentMinScoresList);
								});
						minimumScoresList.add(minimumScore);
					});
		}
		return minimumScoresList;
	}

	private BaseEvent<? extends BaseHeader> validateHeadersAndBody(String sqsMessage)
			throws JsonProcessingException {
		final BaseEvent<BaseHeader> event =
				mapper.readValue(sqsMessage, new TypeReference<BaseEvent<BaseHeader>>() {});
		return event;
	}

	private void postRequestToExternalAPI(
			final RecognisingOrganisation requestBodyToOrs,
			BaseEvent<? extends BaseHeader> cmdsEvent) 
					throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException, InvalidClientException
	{

		AuthenticationClient authenticationClient = getAuthenticationClient();
		final HttpHeaders eventHeaders =
				getHttpHeaders(cmdsEvent.getEventHeader(), authenticationClient);
		final HttpEntity<?> eventEntity = new HttpEntity<>(requestBodyToOrs, eventHeaders);
		log.debug("EventEntity : {} ;", eventEntity);
		String extCallBackUrl = getORSEndpointUrlBasedOnPartnerCode();
		authenticationClient
		.getRestTemplate()
		.exchange(extCallBackUrl, HttpMethod.PUT, eventEntity, String.class);

	}

	public String getORSEndpointUrlBasedOnPartnerCode() {
		return System.getenv(DistORSConstants.CALLBACK_URL);
	}

	public String getUserAgentHeader() {
		return System.getenv(USER_AGENT);
	}

	HttpHeaders getHttpHeaders(@Valid
			final BaseHeader eventHeader, AuthenticationClient authenticationClient) throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException
	{
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		httpHeaders.set(CORRELATIONID, eventHeader.getCorrelationId().toString());
		if (eventHeader.getPartnerCode() != null && eventHeader.getPartnerCode().equalsIgnoreCase(BC)) {
			httpHeaders.set(USER_AGENT_HEADER, getUserAgentHeader());
		}
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		httpHeaders.set(EVENT_DATETIME, eventHeader.getEventDateTime().format(formatter));

		httpHeaders.set(
				authenticationClient.getAuthorizationHeaderName(),
				authenticationClient.getAccessToken());
		return httpHeaders;
	}

	protected abstract String getPartnerCodeConstants();

	protected abstract String getApplicationName();

	protected abstract AuthenticationClient getAuthenticationClient() throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException, InvalidClientException;

	protected void initializeLogger(@Valid final BaseHeader eventHeader, final Context context) {
		final CMDSLambdaLoggerUtil loggerUtil = new CMDSLambdaLoggerUtil();
		loggerUtil.initializeThreadContextMap(
				eventHeader.getTransactionId().toString(),
				getApplicationName(),
				context.getAwsRequestId(),
				eventHeader.getEventContext());
	}

}
