package com.ielts.cmds.integration.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.ielts.cmds.integration.enums.PartnerCodeEnum;
import com.ielts.cmds.organisation.common.enums.MethodOfDeliveryEnum;
import com.ielts.cmds.organisation.common.enums.OrganisationStatusEnum;
import com.ielts.cmds.organisation.common.enums.VerificationStatusEnum;
import java.util.List;
import java.util.UUID;
import lombok.Data;

/** RecognisingOrganisation */
@Data
@JsonInclude(value = Include.NON_NULL)
public class RecognisingOrganisation {

    private UUID recognisingOrganisationUuid;

    private Integer organisationId;

    private String organisationName;

    private UUID organisationTypeUuid;

    private VerificationStatusEnum verificationStatus;

    private List<Address> addresses;

    private PartnerCodeEnum partnerCode;

    private String partnerContact;

    private MethodOfDeliveryEnum methodOfDelivery;

    private UUID sectorTypeUuid;

    private OrganisationStatusEnum organisationStatus;

    private UUID parentRecognisingOrganisationUuid;

    private String websiteUrl;

    private String organisationCode;

    private UUID replacedByRecognisingOrganisationUuid;

    private List<Note> notes;

    private List<AlternateName> alternateNames;

    private List<Contact> contacts;

    private List<RecognisedProduct> recognisedProducts;

    private List<MinimumScore> minimumScore;

    private Boolean ieltsDisplayFlag;

    private Boolean selectForResultsDelivery;
}
