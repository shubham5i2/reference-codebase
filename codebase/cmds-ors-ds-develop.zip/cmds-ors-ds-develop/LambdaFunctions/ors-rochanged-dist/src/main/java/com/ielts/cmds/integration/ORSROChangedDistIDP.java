package com.ielts.cmds.integration;

import java.security.KeyStoreException;
import java.security.cert.CertificateException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.constants.DistORSConstants;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.exception.InvalidClientException;
import com.ielts.cmds.security.exception.TokenNotReceivedException;
import com.ielts.cmds.security.factory.AuthenticationClientFactory;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;

public class ORSROChangedDistIDP extends ORSROChangedDist {

	private final AuthenticationClientFactory securityAuthenticationFactory = new EnvironmentAwareAuthenticationClientFactory();
	
    @Override
    protected String getPartnerCodeConstants() {
        return DistORSConstants.IDP;
    }

    @Override
    protected String getApplicationName() {
        return DistORSConstants.IDP_APPLICATION_NAME;
    }
    
    @Override
    protected AuthenticationClient getAuthenticationClient() throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException, InvalidClientException {
        return securityAuthenticationFactory.getAuthenticationClient(DistORSConstants.IDP);
    }
}
