package com.ielts.cmds.integration.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.util.UUID;
import lombok.Data;

/** Address */
@Data
@JsonInclude(value = Include.NON_NULL)
public class Address {

    private UUID addressUuid;

    private UUID addressTypeUuid;

    private String addressLine1;

    private String addressLine2;

    private String addressLine3;

    private String addressLine4;

    private String city;

    private UUID territoryUuid;

    private String postalCode;

    private UUID countryUuid;

    private String email;

    private String phone;
}
