package com.ielts.cmds.integration.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.util.List;
import java.util.UUID;
import lombok.Data;

/** MinimumScore */
@Data
@JsonInclude(value = Include.NON_NULL)
public class MinimumScore {

    private UUID moduleTypeUuid;

    private Float overallMinimumScore;

    private List<ComponentMinimumScores> componentMinimumScores;
}
