package com.ielts.cmds.integration.enums;

public enum PartnerCodeEnum {
    IDP("IDP"),
    BC("BC"),
    GLOBAL_IELTS("GLOBAL_IELTS"),
	CA("CA"),
    BC_CHN("BC_CHN"),
	IELTS_USA("IELTS_USA");

    private String value;

    PartnerCodeEnum(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }
}
