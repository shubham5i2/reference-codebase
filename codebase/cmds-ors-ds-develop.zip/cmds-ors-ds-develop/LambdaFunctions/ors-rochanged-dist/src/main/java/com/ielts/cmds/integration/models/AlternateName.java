package com.ielts.cmds.integration.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.util.UUID;
import lombok.Data;

/** AlternateName */
@Data
@JsonInclude(value = Include.NON_NULL)
public class AlternateName {

    private UUID alternateNameUuid;

    private String name;
}
