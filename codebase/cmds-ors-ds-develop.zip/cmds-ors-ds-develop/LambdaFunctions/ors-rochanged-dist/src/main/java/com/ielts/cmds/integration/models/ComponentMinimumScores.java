package com.ielts.cmds.integration.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.ielts.cmds.organisation.common.enums.ComponentEnum;
import lombok.Data;

/** ComponentMinimumScores */
@Data
@JsonInclude(value = Include.NON_NULL)
public class ComponentMinimumScores {

    private Float minimumScore;

    private ComponentEnum component;
}
