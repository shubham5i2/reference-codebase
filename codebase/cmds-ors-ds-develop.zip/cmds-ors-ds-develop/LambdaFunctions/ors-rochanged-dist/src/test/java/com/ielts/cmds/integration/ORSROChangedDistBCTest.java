package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.constants.DistORSConstants.BC;
import static com.ielts.cmds.integration.constants.DistORSConstants.EVENT_DATETIME;
import static com.ielts.cmds.integration.constants.DistORSConstants.USER_AGENT;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.integration.constants.DistORSConstants;
import com.ielts.cmds.integration.enums.PartnerCodeEnum;
import com.ielts.cmds.integration.models.RecognisingOrganisation;
import com.ielts.cmds.security.clients.BritishCouncilAuthenticationClient;
import com.ielts.cmds.security.exception.TokenNotReceivedException;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;

@ExtendWith(MockitoExtension.class)
class ORSROChangedDistBCTest {

    @Spy private ORSROChangedDistBC roChangedDistBc;
    @Mock private BritishCouncilAuthenticationClient bcAuthenticationClient;
    @Spy ObjectMapper mapper;
    @Mock private Context context;
    @Spy private SQSEvent event;
    @Spy private SQSEvent.SQSMessage sqsMessage;
    @Mock private TypeReference<BaseEvent<UiHeader>> typeRef;
    @Mock private EnvironmentAwareAuthenticationClientFactory securityAuthenticationFactory;
    @Mock private RestTemplate restTemplate;
    @Mock ResponseEntity<String> response;

    @BeforeEach
    public void setUp() throws Exception {
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
        String eventBody = SQSEventDataSetup.getEventRequestForBC();
        sqsMessage.setBody(eventBody);
        List<SQSEvent.SQSMessage> records = new ArrayList<>();
        records.add(sqsMessage);
        event.setRecords(records);
        typeRef = new TypeReference<BaseEvent<UiHeader>>() {};
    }

    @Test
    void getPartnerCodeConstants_whenGetPartnerCodeConstants_thenReturnBC() {
        String partnerCodeConstants = roChangedDistBc.getPartnerCodeConstants();
        assertEquals(DistORSConstants.BC, partnerCodeConstants);
        assertEquals(DistORSConstants.BC, PartnerCodeEnum.BC.toString());
    }

    @Test
    void getApplicationName_whenGetApplicationName_thenReturnInvalidApplicationNameForBC() {
        String applicationName = roChangedDistBc.getApplicationName();
        assertEquals(DistORSConstants.BC_APPLICATION_NAME, applicationName);
    }

    @Test
    void whenBCRequestHasValidAuthenticationHeader_ThenVerifyCallToRestTemplate() throws Exception {
        String msg = event.getRecords().get(0).getBody();
        BaseEvent<UiHeader> baseEvent = mapper.readValue(msg, typeRef);
        Map<String, String> map = new HashMap<>();
        map.put(
                DistORSConstants.ACCESS_TOKEN,
                SQSEventDataSetup.getEnvironmentVariablesStub().get(DistORSConstants.ACCESS_TOKEN));
        map.put(DistORSConstants.AUTH_HEADER, DistORSConstants.AUTH_HEADER_NAME);
        ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.ACCEPTED);
        baseEvent.getEventHeader().setPartnerCode("BC");
        HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
        eventHeaders.set(
                map.get(DistORSConstants.AUTH_HEADER), map.get(DistORSConstants.ACCESS_TOKEN));
        // Define mock variables behaviour
        when(securityAuthenticationFactory.getAuthenticationClient(
                        baseEvent.getEventHeader().getPartnerCode()))
                .thenReturn(bcAuthenticationClient);
        ReflectionTestUtils.setField(
                roChangedDistBc, "securityAuthenticationFactory", securityAuthenticationFactory);
        doReturn(DistORSConstants.AUTH_HEADER_NAME)
                .when(bcAuthenticationClient)
                .getAuthorizationHeaderName();
        doReturn("access-token").when(bcAuthenticationClient).getAccessToken();
        doReturn(restTemplate).when(bcAuthenticationClient).getRestTemplate();
        String url = "http://35.178.179.164:8105/romaster";
        doReturn(url).when(roChangedDistBc).getORSEndpointUrlBasedOnPartnerCode();
        RecognisingOrganisation organisation = SQSEventDataSetup.mockCMDSMessage();
        organisation.setPartnerCode(PartnerCodeEnum.valueOf("BC"));
        HttpEntity<?> eventEntity = new HttpEntity<>(organisation, eventHeaders);

        doReturn(response2)
                .when(restTemplate)
                .exchange(url, HttpMethod.PUT, eventEntity, String.class);
        // Execute and assert test
        assertDoesNotThrow(() -> roChangedDistBc.handleRequest(event, context));
        assertEquals(
                "1f50ca55-3800-48c7-8f30-0723f5fac264",
                String.valueOf(organisation.getParentRecognisingOrganisationUuid()));
        assertEquals(
                "f54b165c-a342-4a26-8232-f452f491f409",
                String.valueOf(organisation.getReplacedByRecognisingOrganisationUuid()));
    }

    @Test
    void whenBCRequestHasValidAuthenticationHeaderWithLongWebsiteUrl_ThenVerifyCallToRestTemplate()
            throws Exception {
        String eventBody = SQSEventDataSetup.getEventRequestWithLengthyWebsiteUrl();
        sqsMessage.setBody(eventBody);
        List<SQSEvent.SQSMessage> records = new ArrayList<>();
        records.add(sqsMessage);
        event.setRecords(records);
        typeRef = new TypeReference<BaseEvent<UiHeader>>() {};
        String msg = event.getRecords().get(0).getBody();
        BaseEvent<UiHeader> baseEvent = mapper.readValue(msg, typeRef);
        Map<String, String> map = new HashMap<>();
        map.put(
                DistORSConstants.ACCESS_TOKEN,
                SQSEventDataSetup.getEnvironmentVariablesStub().get(DistORSConstants.ACCESS_TOKEN));
        map.put(DistORSConstants.AUTH_HEADER, DistORSConstants.AUTH_HEADER_NAME);
        ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.ACCEPTED);
        HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
        eventHeaders.set(
                map.get(DistORSConstants.AUTH_HEADER), map.get(DistORSConstants.ACCESS_TOKEN));
        // Define mock variables behaviour
        when(securityAuthenticationFactory.getAuthenticationClient(
                        baseEvent.getEventHeader().getPartnerCode()))
                .thenReturn(bcAuthenticationClient);
        ReflectionTestUtils.setField(
                roChangedDistBc, "securityAuthenticationFactory", securityAuthenticationFactory);
        doReturn(DistORSConstants.AUTH_HEADER_NAME)
                .when(bcAuthenticationClient)
                .getAuthorizationHeaderName();
        doReturn("access-token").when(bcAuthenticationClient).getAccessToken();
        doReturn(restTemplate).when(bcAuthenticationClient).getRestTemplate();
        String url = "http://35.178.179.164:8105/romaster";
        doReturn(url).when(roChangedDistBc).getORSEndpointUrlBasedOnPartnerCode();
        RecognisingOrganisation organisation = SQSEventDataSetup.mockCMDSMessage();
        organisation.setPartnerCode(PartnerCodeEnum.valueOf("BC"));
        organisation.setWebsiteUrl(
                "www.thisisaverybigwebsiteurl.com/tryingtofill/stillnotfilling/outofoptions/idontknow/filler/bigbelly");
        HttpEntity<?> eventEntity = new HttpEntity<>(organisation, eventHeaders);

        doReturn(response2)
                .when(restTemplate)
                .exchange(url, HttpMethod.PUT, eventEntity, String.class);
        // Execute and assert test
        assertDoesNotThrow(() -> roChangedDistBc.handleRequest(event, context));
    }

    @Test
    void whenBCInvalidRequest_ThenVerifyThrownException() throws Exception {
        // Prepare test data
        String msg = event.getRecords().get(0).getBody();
        BaseEvent<UiHeader> baseEvent = mapper.readValue(msg, typeRef);
        Map<String, String> map = new HashMap<>();
        map.put(
                DistORSConstants.ACCESS_TOKEN,
                SQSEventDataSetup.getEnvironmentVariablesStub().get(DistORSConstants.ACCESS_TOKEN));
        map.put(DistORSConstants.AUTH_HEADER, DistORSConstants.AUTH_HEADER_NAME);
        HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
        eventHeaders.set(
                map.get(DistORSConstants.AUTH_HEADER), map.get(DistORSConstants.ACCESS_TOKEN));
        // Define mock variables behaviour
        when(securityAuthenticationFactory.getAuthenticationClient(
                        baseEvent.getEventHeader().getPartnerCode()))
                .thenReturn(bcAuthenticationClient);
        ReflectionTestUtils.setField(
                roChangedDistBc, "securityAuthenticationFactory", securityAuthenticationFactory);
        doReturn(DistORSConstants.AUTH_HEADER_NAME)
                .when(bcAuthenticationClient)
                .getAuthorizationHeaderName();
        doReturn("access-token").when(bcAuthenticationClient).getAccessToken();
        doReturn(restTemplate).when(bcAuthenticationClient).getRestTemplate();
        String url = "http://35.178.179.164:8105/romaster";
        doReturn(url).when(roChangedDistBc).getORSEndpointUrlBasedOnPartnerCode();
        RecognisingOrganisation organisation = SQSEventDataSetup.mockCMDSMessage();
        organisation.setPartnerCode(PartnerCodeEnum.valueOf("BC"));
        HttpEntity<?> eventEntity = new HttpEntity<>(organisation, eventHeaders);

        doThrow(HttpClientErrorException.class)
		.when(restTemplate)
		.exchange(url, HttpMethod.PUT, eventEntity, String.class);
        // Execute and assert test
        assertDoesNotThrow(
                () -> roChangedDistBc.handleRequest(event, context));
    }

    private HttpHeaders getHttpHeaders(BaseHeader eventHeader) {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.set(DistORSConstants.CORRELATIONID, eventHeader.getCorrelationId().toString());
        if (eventHeader.getPartnerCode() != null && eventHeader.getPartnerCode().equalsIgnoreCase(BC)) {
            httpHeaders.set(DistORSConstants.USER_AGENT_HEADER, System.getenv(USER_AGENT));
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        httpHeaders.set(EVENT_DATETIME, eventHeader.getEventDateTime().format(formatter));
        return httpHeaders;
    }

    @Test
    void whenBCRequestWithoutToken_ThenVerifyThrownException() throws Exception {
        // Prepare test data
        String msg = event.getRecords().get(0).getBody();
        BaseEvent<UiHeader> baseEvent = mapper.readValue(msg, typeRef);
        Map<String, String> map = new HashMap<>();
        map.put(DistORSConstants.AUTH_HEADER, DistORSConstants.AUTH_HEADER_NAME);
        // Define mock variables behaviour
        when(securityAuthenticationFactory.getAuthenticationClient(
                        baseEvent.getEventHeader().getPartnerCode()))
                .thenReturn(bcAuthenticationClient);
        ReflectionTestUtils.setField(
                roChangedDistBc, "securityAuthenticationFactory", securityAuthenticationFactory);
        doReturn(DistORSConstants.AUTH_HEADER_NAME)
                .when(bcAuthenticationClient)
                .getAuthorizationHeaderName();
		doThrow(TokenNotReceivedException.class).when(bcAuthenticationClient).getAccessToken();
        // Execute and assert test
        assertDoesNotThrow(
                () -> roChangedDistBc.handleRequest(event, context));
    }

}
