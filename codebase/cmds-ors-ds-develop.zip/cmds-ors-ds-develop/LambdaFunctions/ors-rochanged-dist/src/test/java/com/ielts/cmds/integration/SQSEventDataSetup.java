package com.ielts.cmds.integration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.integration.constants.DistORSConstants;
import com.ielts.cmds.integration.enums.PartnerCodeEnum;
import com.ielts.cmds.integration.models.Address;
import com.ielts.cmds.integration.models.AlternateName;
import com.ielts.cmds.integration.models.ComponentMinimumScores;
import com.ielts.cmds.integration.models.Contact;
import com.ielts.cmds.integration.models.MinimumScore;
import com.ielts.cmds.integration.models.Note;
import com.ielts.cmds.integration.models.RecognisedProduct;
import com.ielts.cmds.integration.models.RecognisingOrganisation;
import com.ielts.cmds.organisation.common.enums.ComponentEnum;
import com.ielts.cmds.organisation.common.enums.LinkTypeEnum;
import com.ielts.cmds.organisation.common.enums.MethodOfDeliveryEnum;
import com.ielts.cmds.organisation.common.enums.OrganisationStatusEnum;
import com.ielts.cmds.organisation.common.enums.VerificationStatusEnum;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Address;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Addresses;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1AlternateName;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1AlternateNames;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Contact;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Contacts;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1LinkedOrganisation;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1LinkedOrganisations;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1MinimumScore;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1MinimumScores;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Note;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Notes;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1RecognisedProduct;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1RecognisedProducts;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class SQSEventDataSetup {

    static final ObjectMapper mapper = new ObjectMapper();

    public static String getEventRequest() throws JsonProcessingException {

        final UiHeader header = populateEventHeader();
        final RoChangedEventV1 bodyList = populateEventBody();
        final String body = mapper.writeValueAsString(bodyList);
        final BaseEventErrors errors = null;
        final BaseEvent<UiHeader> event = new BaseEvent<>(header, body, errors, null);
        return mapper.writeValueAsString(event);
    }

    public static String getEventRequestBCCHN() throws JsonProcessingException {

        final UiHeader header = populateEventHeaderBCCHN();
        final RoChangedEventV1 bodyList = populateEventBodyBCCHN();
        final String body = mapper.writeValueAsString(bodyList);
        final BaseEventErrors errors = null;
        final BaseEvent<UiHeader> event = new BaseEvent<>(header, body, errors, null);
        return mapper.writeValueAsString(event);
    }

    public static String getEventRequestForBC() throws JsonProcessingException {

        final UiHeader header = populateEventHeader();
        header.setPartnerCode("BC");
        final RoChangedEventV1 bodyList = populateEventBody();
        bodyList.setPartnerCode("BC");
        final String body = mapper.writeValueAsString(bodyList);
        final BaseEventErrors errors = null;
        final BaseEvent<UiHeader> event = new BaseEvent<>(header, body, errors, null);
        return mapper.writeValueAsString(event);
    }

    public static String getEventRequestWithLengthyWebsiteUrl() throws JsonProcessingException {

        final UiHeader header = populateEventHeader();
        header.setPartnerCode("BC");
        final RoChangedEventV1 bodyList = populateEventBody();
        bodyList.setPartnerCode("BC");
        bodyList.setWebsiteUrl(
                "www.thisisaverybigwebsiteurl.com/tryingtofill/stillnotfilling/outofoptions/idontknow/filler/bigbelly/fruits/index.html");

        final String body = mapper.writeValueAsString(bodyList);
        final BaseEventErrors errors = null;
        final BaseEvent<UiHeader> event = new BaseEvent<>(header, body, errors, null);
        return mapper.writeValueAsString(event);
    }

    public static String getInvalidEventRequest() throws JsonProcessingException {

        final UiHeader header = populateEventHeader();
        List<ErrorDescription> errorList = new ArrayList<>();
        ErrorDescription description = new ErrorDescription();
        description.setInterfaceName("RoChangedEvent");
        description.setType(ErrorTypeEnum.VALIDATION);
        description.setErrorCode("1234");
        Source source = Source.builder().value("").path("product_uuid").build();
        description.setSource(source);
        errorList.add(description);

        BaseEventErrors errorResponse = new BaseEventErrors(errorList);
        final BaseEvent<UiHeader> event = new BaseEvent<>(header, null, errorResponse, null);
        return mapper.writeValueAsString(event);
    }

    public static UiHeader populateEventHeader() {
        UiHeader uiHeader = new UiHeader();
        uiHeader.setConnectionId("WPl56dCALPECGwg=");
        uiHeader.setTransactionId(UUID.fromString("3e81e94b-8b6a-42b5-970c-b141f9d195a4"));
        uiHeader.setCorrelationId(UUID.fromString("123e4567-e89b-12d3-a456-426614174000"));
        uiHeader.setPartnerCode("IDP");
        uiHeader.setEventName("RoChanged");
        uiHeader.setEventDateTime(LocalDateTime.of(2021, Month.SEPTEMBER, 23, 05, 52, 55));
        uiHeader.setEventDiscriminator("ROApproved");
        return uiHeader;
    }

    public static UiHeader populateEventHeaderBCCHN() {
        UiHeader uiHeader = new UiHeader();
        uiHeader.setConnectionId("WPl56dCALPECGwg=");
        uiHeader.setTransactionId(UUID.fromString("3e81e94b-8b6a-42b5-970c-b141f9d195a4"));
        uiHeader.setCorrelationId(UUID.fromString("123e4567-e89b-12d3-a456-426614174000"));
        uiHeader.setPartnerCode("BC_CHN");
        uiHeader.setEventName("RoChanged");
        uiHeader.setEventDateTime(LocalDateTime.of(2021, Month.SEPTEMBER, 23, 05, 52, 55));
        uiHeader.setEventDiscriminator("ROApproved");
        return uiHeader;
    }

    public static Map<String, String> getEnvironmentVariablesStub() {
        Map<String, String> map = new HashMap<>();
        map.put(DistORSConstants.CLIENT_ID, "cmds-id");
        map.put(DistORSConstants.CLIENT_SECRET, "cmds-secret");
        map.put(DistORSConstants.ACCESS_TOKEN, "access-token");
        map.put("bc_auth_token_url", "BC_AUTH_URL");
        return map;
    }

    private static RoChangedEventV1 populateEventBody() {

        RoChangedEventV1 roChangedEvent = new RoChangedEventV1();
        roChangedEvent.setRecognisingOrganisationUuid(
                UUID.fromString("1afbf4b7-a534-40f6-9714-d5d97e10bed4"));
        roChangedEvent.setOrganisationName("Montreal University");
        roChangedEvent.setOrganisationId(124);
        roChangedEvent.setOrganisationType("Recognising Organisation");
        roChangedEvent.setOrganisationTypeUuid(
                UUID.fromString("e496aa98-86a3-476d-8be3-21ee0aa23c93"));
        roChangedEvent.setOrganisationStatus(OrganisationStatusEnum.ACTIVE);
        roChangedEvent.setVerificationStatus(VerificationStatusEnum.APPROVED);
        roChangedEvent.setPartnerCode("IDP");
        roChangedEvent.setPartnerContact("partner contact");
        roChangedEvent.setMethodOfDelivery(MethodOfDeliveryEnum.POSTAL);
        roChangedEvent.setSectorType("College / University");
        roChangedEvent.setSectorTypeUuid(UUID.fromString("48270c84-4cc8-489e-8eac-2af59898175a"));
        roChangedEvent.setWebsiteUrl("www.university.com");
        roChangedEvent.setOrganisationCode("UIDNJN");
        roChangedEvent.setSoftDeleted(false);
        roChangedEvent.setAddresses(setAddressData());
        roChangedEvent.setNotes(setRoNotesData());
        roChangedEvent.setAlternateNames(setAlternateNamesData());
        roChangedEvent.setContacts(setContactsData());
        roChangedEvent.setMinimumScores(setMinimumScoresData());
        roChangedEvent.setRecognisedProducts(setRecognisedProductsData());
        roChangedEvent.setLinkedOrganisations(setLinkedOrganisationsData());
        return roChangedEvent;
    }

    private static RoChangedEventV1 populateEventBodyBCCHN() {

        RoChangedEventV1 roChangedEvent = new RoChangedEventV1();
        roChangedEvent.setRecognisingOrganisationUuid(
                UUID.fromString("1afbf4b7-a534-40f6-9714-d5d97e10bed4"));
        roChangedEvent.setOrganisationName("Montreal University");
        roChangedEvent.setOrganisationId(124);
        roChangedEvent.setOrganisationType("Recognising Organisation");
        roChangedEvent.setOrganisationTypeUuid(
                UUID.fromString("e496aa98-86a3-476d-8be3-21ee0aa23c93"));
        roChangedEvent.setOrganisationStatus(OrganisationStatusEnum.ACTIVE);
        roChangedEvent.setVerificationStatus(VerificationStatusEnum.APPROVED);
        roChangedEvent.setPartnerCode("BC_CHN");
        roChangedEvent.setPartnerContact("partner contact");
        roChangedEvent.setMethodOfDelivery(MethodOfDeliveryEnum.POSTAL);
        roChangedEvent.setSectorType("College / University");
        roChangedEvent.setSectorTypeUuid(UUID.fromString("48270c84-4cc8-489e-8eac-2af59898175a"));
        roChangedEvent.setWebsiteUrl("www.university.com");
        roChangedEvent.setOrganisationCode("UIDNJN");
        roChangedEvent.setSoftDeleted(false);
        roChangedEvent.setAddresses(setAddressData());
        roChangedEvent.setNotes(setRoNotesData());
        roChangedEvent.setAlternateNames(setAlternateNamesData());
        roChangedEvent.setContacts(setContactsData());
        roChangedEvent.setMinimumScores(setMinimumScoresData());
        roChangedEvent.setRecognisedProducts(setRecognisedProductsData());
        roChangedEvent.setLinkedOrganisations(setLinkedOrganisationsData());
        return roChangedEvent;
    }

    private static RoChangedEventV1LinkedOrganisations setLinkedOrganisationsData() {
        RoChangedEventV1LinkedOrganisations likedOrganisationList =
                new RoChangedEventV1LinkedOrganisations();
        RoChangedEventV1LinkedOrganisation linkedOrganisation =
                new RoChangedEventV1LinkedOrganisation();
        linkedOrganisation.setLinkedRecognisingOrganisationUuid(
                UUID.fromString("41dfca9e-5308-40a7-a3db-7c9b1ae78bc5"));
        linkedOrganisation.setTargetRecognisingOrganisationUuid(
                UUID.fromString("1f50ca55-3800-48c7-8f30-0723f5fac264"));
        linkedOrganisation.setLinkType(LinkTypeEnum.PARENT_RO);
        linkedOrganisation.setLinkEffectiveFromDateTime(
                LocalDateTime.of(2020, Month.NOVEMBER, 23, 05, 52, 55));
        linkedOrganisation.setLinkEffectiveToDateTime(
                LocalDateTime.of(2020, Month.DECEMBER, 23, 05, 52, 55));
        likedOrganisationList.add(linkedOrganisation);
        RoChangedEventV1LinkedOrganisation linkedOrganisation1 =
                new RoChangedEventV1LinkedOrganisation();
        linkedOrganisation1.setLinkedRecognisingOrganisationUuid(
                UUID.fromString("6797fa33-4b8f-414b-bc1e-a9589430dbc5"));
        linkedOrganisation1.setTargetRecognisingOrganisationUuid(
                UUID.fromString("f54b165c-a342-4a26-8232-f452f491f409"));
        linkedOrganisation1.setLinkType(LinkTypeEnum.REPLACED_BY);
        linkedOrganisation1.setLinkEffectiveFromDateTime(
                LocalDateTime.of(2020, Month.NOVEMBER, 23, 05, 52, 55));
        linkedOrganisation1.setLinkEffectiveToDateTime(
                LocalDateTime.of(2020, Month.DECEMBER, 23, 05, 52, 55));
        likedOrganisationList.add(linkedOrganisation1);
        return likedOrganisationList;
    }

    private static RoChangedEventV1Addresses setAddressData() {
        RoChangedEventV1Addresses addresses = new RoChangedEventV1Addresses();
        RoChangedEventV1Address address = new RoChangedEventV1Address();
        address.setAddressUuid(UUID.fromString("9e5146b0-0fd1-4da7-aa2f-ebfd65405e9f"));
        address.setAddressTypeUuid(UUID.fromString("c96fbd08-a302-4aa2-a594-13cdb33bb380"));
        address.setAddressType("Main");
        address.setAddressLine1("strt 57");
        address.setAddressLine2("dsd");
        address.setAddressLine3(null);
        address.setAddressLine4(null);
        address.setCity("Hyd");
        address.setCountry("INDIA");
        address.setCountryIso3Code("IND");
        address.setCountryUuid(UUID.fromString("4b8dac87-d2dd-4599-b055-2f73a5f0a01a"));
        address.setEmail("mainAddress@gmail.com");
        address.setPhone(null);
        address.setPostalCode(null);
        address.setTerritory(null);
        address.setTerritoryIsoCode(null);
        address.setTerritoryUuid(null);
        addresses.add(address);
        RoChangedEventV1Address address1 = new RoChangedEventV1Address();
        address1.setAddressUuid(UUID.fromString("cba8cb7d-bffb-4af3-ad2a-0342e1773b1c"));
        address1.setAddressTypeUuid(UUID.fromString("d13761e9-c134-4f80-a0a8-239a683a9c00"));
        address1.setAddressType("Delivery");
        address1.setAddressLine1("street 1");
        address1.setAddressLine2(null);
        address1.setAddressLine3(null);
        address1.setAddressLine4(null);
        address1.setCity("Hyderabad");
        address1.setCountry("INDIA");
        address1.setCountryIso3Code("IND");
        address1.setCountryUuid(UUID.fromString("4b8dac87-d2dd-4599-b055-2f73a5f0a01a"));
        address1.setEmail("deliveryAddress@email.com");
        address1.setPhone("1234567");
        address1.setPostalCode("INFD");
        address1.setTerritory(null);
        address1.setTerritoryIsoCode(null);
        address1.setTerritoryUuid(null);
        addresses.add(address1);
        return addresses;
    }

    private static RoChangedEventV1Contacts setContactsData() {
        RoChangedEventV1Contacts contacts = new RoChangedEventV1Contacts();
        RoChangedEventV1Contact primaryContact = new RoChangedEventV1Contact();
        primaryContact.setContactUuid(UUID.fromString("a1ec3711-f81d-426a-a0eb-e2c67ff5a257"));
        primaryContact.setContactTypeUuid(UUID.fromString("c3397312-8ea3-453d-871b-68a1ef8c9184"));
        primaryContact.setContactType("Primary");
        primaryContact.setFirstName("Chris");
        primaryContact.setLastName("John");
        primaryContact.setEffectiveFromDateTime(
                LocalDateTime.of(2020, Month.NOVEMBER, 23, 05, 52, 55));
        primaryContact.setEffectiveToDateTime(
                LocalDateTime.of(2020, Month.NOVEMBER, 23, 05, 52, 55));
        primaryContact.setAddresses(setContactsAddressData());
        contacts.add(primaryContact);
        RoChangedEventV1Contact resultsAdminContact = new RoChangedEventV1Contact();
        resultsAdminContact.setContactUuid(UUID.fromString("bf1c7e10-9cca-46de-9c13-c2627ea02aad"));
        resultsAdminContact.setContactTypeUuid(
                UUID.fromString("457a494b-64ca-497f-868f-cc0e5f30a97f"));
        resultsAdminContact.setContactType("Results Admin");
        resultsAdminContact.setFirstName("Chris");
        resultsAdminContact.setLastName("John");
        resultsAdminContact.setEffectiveFromDateTime(
                LocalDateTime.of(2020, Month.NOVEMBER, 23, 05, 52, 55));
        resultsAdminContact.setEffectiveToDateTime(
                LocalDateTime.of(2020, Month.NOVEMBER, 23, 05, 52, 55));
        resultsAdminContact.setAddresses(setContactsAddressData());
        contacts.add(resultsAdminContact);
        return contacts;
    }

    private static RoChangedEventV1Addresses setContactsAddressData() {
        RoChangedEventV1Addresses addresses = new RoChangedEventV1Addresses();
        RoChangedEventV1Address address = new RoChangedEventV1Address();
        address.setAddressUuid(UUID.fromString("4ca62415-61e0-4d4a-ab0d-67776fb2638a"));
        address.setAddressTypeUuid(UUID.fromString("c96fbd08-a302-4aa2-a594-13cdb33bb380"));
        address.setAddressType("Main");
        address.setAddressLine1("street");
        address.setAddressLine2("dfe");
        address.setAddressLine3(null);
        address.setAddressLine4(null);
        address.setCity("Hyderabad");
        address.setCountry("INDIA");
        address.setCountryIso3Code("IND");
        address.setCountryUuid(UUID.fromString("4b8dac87-d2dd-4599-b055-2f73a5f0a01a"));
        address.setEmail("email@email.com");
        address.setPhone("1234567");
        address.setPostalCode("UIOP");
        address.setTerritory(null);
        address.setTerritoryIsoCode(null);
        address.setTerritoryUuid(null);
        addresses.add(address);
        return addresses;
    }

    private static RoChangedEventV1Notes setRoNotesData() {
        RoChangedEventV1Notes notes = new RoChangedEventV1Notes();
        RoChangedEventV1Note note = new RoChangedEventV1Note();
        note.setNoteUuid(UUID.fromString("6230b520-e96b-4b66-a146-b66a2ad60d6b"));
        note.setNoteTypeUuid(UUID.fromString("f9aa5ac1-da99-40f2-82e7-a5fea9e45979"));
        note.setNoteContent("note 1");
        note.setUpdatedDatetime(LocalDateTime.of(2020, Month.NOVEMBER, 23, 05, 52, 55));
        notes.add(note);
        RoChangedEventV1Note note1 = new RoChangedEventV1Note();
        note1.setNoteUuid(UUID.fromString("20c73561-d2f9-4b41-9146-69293c95d563"));
        note1.setNoteTypeUuid(UUID.fromString("f9aa5ac1-da99-40f2-82e7-a5fea9e45979"));
        note1.setNoteContent("note 2");
        note1.setUpdatedDatetime(LocalDateTime.of(2020, Month.NOVEMBER, 23, 05, 52, 55));
        notes.add(note1);
        return notes;
    }

    private static RoChangedEventV1AlternateNames setAlternateNamesData() {
        RoChangedEventV1AlternateNames altNames = new RoChangedEventV1AlternateNames();
        RoChangedEventV1AlternateName altName = new RoChangedEventV1AlternateName();
        altName.setAlternateNameUuid(UUID.fromString("42efb8ed-1b0c-4155-8743-7d2303cd0a32"));
        altName.setName("alt name 1");
        altNames.add(altName);
        RoChangedEventV1AlternateName altName1 = new RoChangedEventV1AlternateName();
        altName1.setAlternateNameUuid(UUID.fromString("b05fbf74-ca30-489c-9f23-9f8f5a9b3c89"));
        altName1.setName("alt name 2");
        altNames.add(altName1);
        return altNames;
    }

    private static RoChangedEventV1RecognisedProducts setRecognisedProductsData() {
        RoChangedEventV1RecognisedProducts recProducts = new RoChangedEventV1RecognisedProducts();
        RoChangedEventV1RecognisedProduct recProduct = new RoChangedEventV1RecognisedProduct();
        recProduct.setProductUuid(UUID.fromString("9df93b78-1321-448b-965d-3b60b8f85058"));
        recProduct.setRecognisedProductUuid(
                UUID.fromString("22fb3c78-f7bb-429b-bddd-5d9373c9a879"));
        recProduct.setEffectiveFromDateTime(LocalDateTime.of(2020, Month.NOVEMBER, 23, 05, 52, 55));
        recProduct.setEffectiveToDateTime(LocalDateTime.of(2020, Month.NOVEMBER, 23, 05, 52, 55));
        recProducts.add(recProduct);
        return recProducts;
    }

    private static RoChangedEventV1MinimumScores setMinimumScoresData() {
        RoChangedEventV1MinimumScores minimumScoreList = new RoChangedEventV1MinimumScores();
        RoChangedEventV1MinimumScore minimumScore = new RoChangedEventV1MinimumScore();
        minimumScore.setMinimumScoreUuid(UUID.fromString("5b5b0ba1-0e7b-41e9-ad19-9ebdad8de876"));
        minimumScore.setModuleTypeUuid(UUID.fromString("ca47e634-d820-4703-a6a8-45867fc5a78d"));
        minimumScore.setComponent(ComponentEnum.W);
        minimumScore.setMinimumScoreValue(BigDecimal.TEN);
        minimumScoreList.add(minimumScore);
        RoChangedEventV1MinimumScore minimumScore1 = new RoChangedEventV1MinimumScore();
        minimumScore1.setMinimumScoreUuid(UUID.fromString("a39f15ac-e48d-4263-be14-fbc8dd25f201"));
        minimumScore1.setModuleTypeUuid(UUID.fromString("ca47e634-d820-4703-a6a8-45867fc5a78d"));
        minimumScore1.setComponent(ComponentEnum.L);
        minimumScore1.setMinimumScoreValue(BigDecimal.TEN);
        minimumScoreList.add(minimumScore1);
        RoChangedEventV1MinimumScore minimumScore2 = new RoChangedEventV1MinimumScore();
        minimumScore2.setMinimumScoreUuid(UUID.fromString("a0c23562-4e76-436a-b687-e49e5cba9832"));
        minimumScore2.setModuleTypeUuid(UUID.fromString("e38f8d24-5fe1-49eb-ba62-48d90dd99a14"));
        minimumScore2.setComponent(ComponentEnum.W);
        minimumScore2.setMinimumScoreValue(BigDecimal.TEN);
        minimumScoreList.add(minimumScore2);
        RoChangedEventV1MinimumScore minimumScore3 = new RoChangedEventV1MinimumScore();
        minimumScore3.setMinimumScoreUuid(UUID.fromString("5dca6a5f-9e6c-418d-a0d9-c2d033456d63"));
        minimumScore3.setModuleTypeUuid(UUID.fromString("e38f8d24-5fe1-49eb-ba62-48d90dd99a14"));
        minimumScore3.setComponent(ComponentEnum.L);
        minimumScore3.setMinimumScoreValue(BigDecimal.TEN);
        minimumScoreList.add(minimumScore3);
        RoChangedEventV1MinimumScore minimumScore4 = new RoChangedEventV1MinimumScore();
        minimumScore4.setMinimumScoreUuid(UUID.fromString("52c83db8-81a1-48a3-978f-27e1c8e2ef8b"));
        minimumScore4.setModuleTypeUuid(UUID.fromString("ca47e634-d820-4703-a6a8-45867fc5a78d"));
        minimumScore4.setComponent(ComponentEnum.ALL);
        minimumScore4.setMinimumScoreValue(BigDecimal.TEN);
        minimumScoreList.add(minimumScore4);
        return minimumScoreList;
    }

    public static RecognisingOrganisation mockCMDSMessage() {
        RoChangedEventV1 roChangedEvent = populateEventBody();
        RecognisingOrganisation orgDetailsTobeSentToOrs = new RecognisingOrganisation();
        orgDetailsTobeSentToOrs.setRecognisingOrganisationUuid(
                roChangedEvent.getRecognisingOrganisationUuid());
        orgDetailsTobeSentToOrs.setOrganisationId(roChangedEvent.getOrganisationId());
        orgDetailsTobeSentToOrs.setOrganisationName(roChangedEvent.getOrganisationName());
        orgDetailsTobeSentToOrs.setOrganisationTypeUuid(roChangedEvent.getOrganisationTypeUuid());
        orgDetailsTobeSentToOrs.setVerificationStatus(roChangedEvent.getVerificationStatus());
        orgDetailsTobeSentToOrs.setAddresses(getAddressList(roChangedEvent.getAddresses()));
        orgDetailsTobeSentToOrs.setPartnerCode(
                PartnerCodeEnum.valueOf(roChangedEvent.getPartnerCode()));
        orgDetailsTobeSentToOrs.setPartnerContact(roChangedEvent.getPartnerContact());
        orgDetailsTobeSentToOrs.setMethodOfDelivery(roChangedEvent.getMethodOfDelivery());
        orgDetailsTobeSentToOrs.setSectorTypeUuid(roChangedEvent.getSectorTypeUuid());
        orgDetailsTobeSentToOrs.setOrganisationStatus(roChangedEvent.getOrganisationStatus());
        UUID targetUuid =
                roChangedEvent.getLinkedOrganisations().stream()
                        .filter(
                                linkedOrganisation ->
                                        LinkTypeEnum.PARENT_RO.equals(
                                                linkedOrganisation.getLinkType()))
                        .map(
                                RoChangedEventV1LinkedOrganisation
                                        ::getTargetRecognisingOrganisationUuid)
                        .findAny()
                        .orElse(null);
        orgDetailsTobeSentToOrs.setParentRecognisingOrganisationUuid(targetUuid);
        orgDetailsTobeSentToOrs.setOrganisationCode(roChangedEvent.getOrganisationCode());
        orgDetailsTobeSentToOrs.setWebsiteUrl(roChangedEvent.getWebsiteUrl());
        UUID replaceById =
                roChangedEvent.getLinkedOrganisations().stream()
                        .filter(
                                linkedOrganisation ->
                                        LinkTypeEnum.REPLACED_BY.equals(
                                                linkedOrganisation.getLinkType()))
                        .map(
                                RoChangedEventV1LinkedOrganisation
                                        ::getTargetRecognisingOrganisationUuid)
                        .findAny()
                        .orElse(null);
        orgDetailsTobeSentToOrs.setReplacedByRecognisingOrganisationUuid(replaceById);
        orgDetailsTobeSentToOrs.setAlternateNames(
                getAlternateNamesList(roChangedEvent.getAlternateNames()));
        orgDetailsTobeSentToOrs.setContacts(getContactsList(roChangedEvent.getContacts()));
        orgDetailsTobeSentToOrs.setMinimumScore(
                getMinimumScoresList(roChangedEvent.getMinimumScores()));
        orgDetailsTobeSentToOrs.setNotes(getNotesList(roChangedEvent.getNotes()));
        orgDetailsTobeSentToOrs.setRecognisedProducts(
                getRecognisedProductsList(roChangedEvent.getRecognisedProducts()));
        return orgDetailsTobeSentToOrs;
    }

    protected static List<Address> getAddressList(RoChangedEventV1Addresses eventAddresses) {
        List<Address> addressList = new ArrayList<>();

        for (RoChangedEventV1Address eventAddress : eventAddresses) {
            Address address = new Address();
            address.setAddressUuid(eventAddress.getAddressUuid());
            address.setAddressTypeUuid(eventAddress.getAddressTypeUuid());
            address.setAddressLine1(eventAddress.getAddressLine1());
            address.setAddressLine2(eventAddress.getAddressLine2());
            address.setAddressLine3(eventAddress.getAddressLine3());
            address.setAddressLine4(eventAddress.getAddressLine4());
            address.setCity(eventAddress.getCity());
            address.setTerritoryUuid(eventAddress.getTerritoryUuid());
            address.setPostalCode(eventAddress.getPostalCode());
            address.setCountryUuid(eventAddress.getCountryUuid());
            address.setEmail(eventAddress.getEmail());
            address.setPhone(eventAddress.getPhone());
            addressList.add(address);
        }
        return addressList;
    }

    protected static List<Contact> getContactsList(RoChangedEventV1Contacts cmdsContacts) {
        List<Contact> contactList = new ArrayList<>();
        if (!cmdsContacts.isEmpty()) {
            for (RoChangedEventV1Contact cmdsContact : cmdsContacts) {
                Contact contact = new Contact();
                contact.setContactUuid(cmdsContact.getContactUuid());
                contact.setFirstName(cmdsContact.getFirstName());
                contact.setLastName(cmdsContact.getLastName());
                contact.setContactTypeUuid(cmdsContact.getContactTypeUuid());
                contact.setKnownName(cmdsContact.getFirstName() + " " + cmdsContact.getLastName());
                contact.setEffectiveFromDateTime(cmdsContact.getEffectiveFromDateTime());
                contact.setEffectiveToDateTime(cmdsContact.getEffectiveToDateTime());
                contact.setAddresses(getAddressList(cmdsContact.getAddresses()));
                contactList.add(contact);
            }
        }
        return contactList;
    }

    protected static List<Note> getNotesList(RoChangedEventV1Notes eventNotes) {
        List<Note> notesList = new ArrayList<>();
        if (!eventNotes.isEmpty()) {
            for (RoChangedEventV1Note eventNote : eventNotes) {
                Note note = new Note();
                note.setNoteUuid(eventNote.getNoteUuid());
                note.setNoteTypeUuid(eventNote.getNoteTypeUuid());
                note.setNoteContent(eventNote.getNoteContent());
                note.setUpdatedDatetime(eventNote.getUpdatedDatetime());
                notesList.add(note);
            }
        }
        return notesList;
    }

    protected static List<AlternateName> getAlternateNamesList(
            RoChangedEventV1AlternateNames eventAltNames) {
        List<AlternateName> altNamesList = new ArrayList<>();
        if (!eventAltNames.isEmpty()) {
            for (RoChangedEventV1AlternateName eventAltName : eventAltNames) {
                AlternateName altName = new AlternateName();
                altName.setAlternateNameUuid(eventAltName.getAlternateNameUuid());
                altName.setName(eventAltName.getName());
                altNamesList.add(altName);
            }
        }
        return altNamesList;
    }

    protected static List<RecognisedProduct> getRecognisedProductsList(
            RoChangedEventV1RecognisedProducts cmdsRecognisedProducts) {
        List<RecognisedProduct> recognisedProductsList = new ArrayList<>();
        if (!cmdsRecognisedProducts.isEmpty()) {
            for (RoChangedEventV1RecognisedProduct cmdsRecognisedProduct : cmdsRecognisedProducts) {
                RecognisedProduct recognisedProduct = new RecognisedProduct();
                recognisedProduct.setRecognisedProductUuid(
                        cmdsRecognisedProduct.getRecognisedProductUuid());
                recognisedProduct.setProductUuid(cmdsRecognisedProduct.getProductUuid());
                recognisedProduct.setEffectiveFromDateTime(
                        cmdsRecognisedProduct.getEffectiveFromDateTime());
                recognisedProduct.setEffectiveToDateTime(
                        cmdsRecognisedProduct.getEffectiveToDateTime());
                recognisedProductsList.add(recognisedProduct);
            }
        }
        return recognisedProductsList;
    }

    protected static List<MinimumScore> getMinimumScoresList(
            RoChangedEventV1MinimumScores cmdsMinimumScores) {
        List<MinimumScore> minimumScoresList = new ArrayList<>();
        if (!cmdsMinimumScores.isEmpty()) {
            Map<UUID, EnumMap<ComponentEnum, BigDecimal>> moduleTypeMap = new HashMap<>();

            for (RoChangedEventV1MinimumScore cmdsMinimumScore : cmdsMinimumScores) {
                if (moduleTypeMap.containsKey(cmdsMinimumScore.getModuleTypeUuid())) {
                    EnumMap<ComponentEnum, BigDecimal> currentModuleValue =
                            moduleTypeMap.get(cmdsMinimumScore.getModuleTypeUuid());
                    currentModuleValue.put(
                            cmdsMinimumScore.getComponent(),
                            cmdsMinimumScore.getMinimumScoreValue());
                } else {
                    EnumMap<ComponentEnum, BigDecimal> componentMinScore =
                            new EnumMap<>(ComponentEnum.class);
                    componentMinScore.put(
                            cmdsMinimumScore.getComponent(),
                            cmdsMinimumScore.getMinimumScoreValue());
                    moduleTypeMap.put(cmdsMinimumScore.getModuleTypeUuid(), componentMinScore);
                }
            }
            moduleTypeMap.forEach(
                    (moduleType, minimumScoreValues) -> {
                        MinimumScore minimumScore = new MinimumScore();
                        minimumScore.setModuleTypeUuid(moduleType);
                        List<ComponentMinimumScores> componentMinScoresList = new ArrayList<>();
                        minimumScoreValues.forEach(
                                (component, minScore) -> {
                                    if (ComponentEnum.ALL.equals(component)) {
                                        minimumScore.setOverallMinimumScore(minScore.floatValue());
                                    } else {
                                        ComponentMinimumScores componentMinimumScores =
                                                new ComponentMinimumScores();
                                        componentMinimumScores.setComponent(component);
                                        componentMinimumScores.setMinimumScore(
                                                minScore.floatValue());
                                        componentMinScoresList.add(componentMinimumScores);
                                    }
                                    minimumScore.setComponentMinimumScores(componentMinScoresList);
                                });
                        minimumScoresList.add(minimumScore);
                    });
        }
        return minimumScoresList;
    }
}
