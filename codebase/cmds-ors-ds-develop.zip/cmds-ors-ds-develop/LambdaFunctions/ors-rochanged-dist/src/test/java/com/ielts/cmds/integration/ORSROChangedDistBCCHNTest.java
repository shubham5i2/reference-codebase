package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.constants.DistORSConstants.EVENT_DATETIME;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.amazonaws.services.lambda.runtime.events.SQSEvent.SQSMessage;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.integration.constants.DistORSConstants;
import com.ielts.cmds.integration.enums.PartnerCodeEnum;
import com.ielts.cmds.integration.models.RecognisingOrganisation;
import com.ielts.cmds.security.clients.BritishCouncilChinaAuthenticationClient;
import com.ielts.cmds.security.exception.TokenNotReceivedException;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;

@ExtendWith(MockitoExtension.class)
class ORSROChangedDistBCCHNTest {

    @Spy private ORSROChangedDistBCCHN roChangedDistBcchn;
    @Mock BritishCouncilChinaAuthenticationClient bcchnAuthenticationClient;
    @Spy ObjectMapper mapper;
    @Mock private Context context;
    private SQSEvent event = new SQSEvent();
    private SQSEvent.SQSMessage sqsMessage = new SQSMessage();
    private TypeReference<BaseEvent<UiHeader>> typeRef;
    @Mock private EnvironmentAwareAuthenticationClientFactory securityAuthenticationFactory;
    @Mock private RestTemplate restTemplate;
    @Mock ResponseEntity<String> response;

    @BeforeEach
    public void setUp() throws Exception {
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
        String eventBody = SQSEventDataSetup.getEventRequestBCCHN();
        sqsMessage.setBody(eventBody);
        List<SQSEvent.SQSMessage> records = new ArrayList<>();
        records.add(sqsMessage);
        event.setRecords(records);
        typeRef = new TypeReference<BaseEvent<UiHeader>>() {};
    }

    @Test
    void getPartnerCodeConstants_whengetPartnerCodeConstants_thenReturnBCCHN() {

        String partnerCodeConstants = roChangedDistBcchn.getPartnerCodeConstants();
        assertEquals(DistORSConstants.BC_CHN, partnerCodeConstants);
    }

    @Test
    void getApplicationName_whengetApplicationName_thenReturnApplicationNameForBCCHN() {

        String applicationName = roChangedDistBcchn.getApplicationName();
        assertEquals(DistORSConstants.BCCHN_APPLICATION_NAME, applicationName);
    }

    @Test
    void whenBCCHNRequestHasValidAuthenticationHeader_ThenVerifyCallToRestTemplate()
            throws Exception {
        // Prepare test data
        String msg = event.getRecords().get(0).getBody();
        BaseEvent<UiHeader> baseEvent = mapper.readValue(msg, typeRef);
        Map<String, String> map = new HashMap<>();
        map.put(
                DistORSConstants.ACCESS_TOKEN,
                SQSEventDataSetup.getEnvironmentVariablesStub().get(DistORSConstants.ACCESS_TOKEN));
        map.put(DistORSConstants.AUTH_HEADER, DistORSConstants.AUTH_HEADER_NAME);
        ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.ACCEPTED);
        HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
        eventHeaders.set(
                map.get(DistORSConstants.AUTH_HEADER), map.get(DistORSConstants.ACCESS_TOKEN));
        // Define mock variables behaviour
        when(securityAuthenticationFactory.getAuthenticationClient(
                baseEvent.getEventHeader().getPartnerCode()))
                .thenReturn(bcchnAuthenticationClient);
        ReflectionTestUtils.setField(
                roChangedDistBcchn, "securityAuthenticationFactory", securityAuthenticationFactory);
        doReturn(DistORSConstants.AUTH_HEADER_NAME)
                .when(bcchnAuthenticationClient)
                .getAuthorizationHeaderName();
        doReturn("access-token").when(bcchnAuthenticationClient).getAccessToken();
        doReturn(restTemplate).when(bcchnAuthenticationClient).getRestTemplate();
        String url = "http://35.178.179.164:8105/romaster";
        doReturn(url).when(roChangedDistBcchn).getORSEndpointUrlBasedOnPartnerCode();
        RecognisingOrganisation organisation = SQSEventDataSetup.mockCMDSMessage();
        organisation.setPartnerCode(PartnerCodeEnum.valueOf("BC_CHN"));
        HttpEntity<?> eventEntity = new HttpEntity<>(organisation, eventHeaders);

        doReturn(response2)
                .when(restTemplate)
                .exchange(url, HttpMethod.PUT, eventEntity, String.class);
        // Execute and assert test
        assertDoesNotThrow(() -> roChangedDistBcchn.handleRequest(event, context));
        assertEquals(
                "1f50ca55-3800-48c7-8f30-0723f5fac264",
                String.valueOf(organisation.getParentRecognisingOrganisationUuid()));
        assertEquals(
                "f54b165c-a342-4a26-8232-f452f491f409",
                String.valueOf(organisation.getReplacedByRecognisingOrganisationUuid()));
    }

    @Test
    void whenBadRequest_VerifyExceptionThrown() throws Exception {
        // Prepare test data
        String msg = event.getRecords().get(0).getBody();
        BaseEvent<UiHeader> baseEvent = mapper.readValue(msg, typeRef);
        Map<String, String> map = new HashMap<>();
        map.put(
                DistORSConstants.ACCESS_TOKEN,
                SQSEventDataSetup.getEnvironmentVariablesStub().get(DistORSConstants.ACCESS_TOKEN));
        map.put(DistORSConstants.AUTH_HEADER, DistORSConstants.AUTH_HEADER_NAME);
        HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
        eventHeaders.set(
                map.get(DistORSConstants.AUTH_HEADER), map.get(DistORSConstants.ACCESS_TOKEN));
        // Define mock variables behaviour
        when(securityAuthenticationFactory.getAuthenticationClient(
                baseEvent.getEventHeader().getPartnerCode()))
                .thenReturn(bcchnAuthenticationClient);
        ReflectionTestUtils.setField(
                roChangedDistBcchn, "securityAuthenticationFactory", securityAuthenticationFactory);
        doReturn(DistORSConstants.AUTH_HEADER_NAME)
                .when(bcchnAuthenticationClient)
                .getAuthorizationHeaderName();
        doReturn("access-token").when(bcchnAuthenticationClient).getAccessToken();
        doReturn(restTemplate).when(bcchnAuthenticationClient).getRestTemplate();
        String url = "http://35.178.179.164:8105/romaster";
        doReturn(url).when(roChangedDistBcchn).getORSEndpointUrlBasedOnPartnerCode();
        RecognisingOrganisation organisation = SQSEventDataSetup.mockCMDSMessage();
        organisation.setPartnerCode(PartnerCodeEnum.valueOf("BC_CHN"));
        HttpEntity<?> eventEntity = new HttpEntity<>(organisation, eventHeaders);

        doThrow(HttpClientErrorException.class)
                .when(restTemplate)
                .exchange(url, HttpMethod.PUT, eventEntity, String.class);
        // Execute and assert test
        assertDoesNotThrow(
                () -> roChangedDistBcchn.handleRequest(event, context));
    }

    private HttpHeaders getHttpHeaders(BaseHeader eventHeader) {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.set(DistORSConstants.CORRELATIONID, eventHeader.getCorrelationId().toString());
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        httpHeaders.set(EVENT_DATETIME, eventHeader.getEventDateTime().format(formatter));
        return httpHeaders;
    }
    
    @Test
    void whenBCCHNRequestWithoutToken_ThenVerifyThrownException() throws Exception {
        // Prepare test data
        String msg = event.getRecords().get(0).getBody();
        BaseEvent<UiHeader> baseEvent = mapper.readValue(msg, typeRef);
        Map<String, String> map = new HashMap<>();
        map.put(DistORSConstants.AUTH_HEADER, DistORSConstants.AUTH_HEADER_NAME);
        // Define mock variables behaviour
        when(securityAuthenticationFactory.getAuthenticationClient(
                baseEvent.getEventHeader().getPartnerCode()))
                .thenReturn(bcchnAuthenticationClient);
        ReflectionTestUtils.setField(
                roChangedDistBcchn, "securityAuthenticationFactory", securityAuthenticationFactory);
        doReturn(DistORSConstants.AUTH_HEADER_NAME)
                .when(bcchnAuthenticationClient)
                .getAuthorizationHeaderName();
		doThrow(TokenNotReceivedException.class).when(bcchnAuthenticationClient).getAccessToken();
        // Execute and assert test
        assertDoesNotThrow(
                () -> roChangedDistBcchn.handleRequest(event, context));
    }

}
