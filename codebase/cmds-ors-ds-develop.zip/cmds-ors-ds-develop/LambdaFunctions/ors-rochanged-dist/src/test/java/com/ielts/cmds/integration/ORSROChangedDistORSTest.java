package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.constants.DistORSConstants.USER_AGENT_HEADER;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.integration.constants.DistORSConstants;
import com.ielts.cmds.security.clients.BritishCouncilAuthenticationClient;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;

@ExtendWith(MockitoExtension.class)
class ORSROChangedDistORSTest {

    @Spy private ORSROChangedDist roChangedDistOrs;
    @Mock private BritishCouncilAuthenticationClient bcAuthenticationClient;
    @Spy ObjectMapper mapper;
    @Spy private SQSEvent event;
    @Spy private SQSEvent.SQSMessage sqsMessage;
    @Mock private TypeReference<BaseEvent<UiHeader>> typeRef;

    @BeforeEach
    public void setUp() throws Exception {
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
        String eventBody = SQSEventDataSetup.getEventRequestForBC();
        sqsMessage.setBody(eventBody);
        List<SQSEvent.SQSMessage> records = new ArrayList<>();
        records.add(sqsMessage);
        event.setRecords(records);
        typeRef = new TypeReference<BaseEvent<UiHeader>>() {};
    }

    @Test
    void whenHttpsHeadersAreCalled_verifyUserAgentValue() throws Exception {
        String msg = event.getRecords().get(0).getBody();
        BaseEvent<UiHeader> baseEvent = mapper.readValue(msg, typeRef);
        doReturn(DistORSConstants.AUTH_HEADER_NAME)
                .when(bcAuthenticationClient)
                .getAuthorizationHeaderName();
        doReturn("access-token").when(bcAuthenticationClient).getAccessToken();
        when(roChangedDistOrs.getUserAgentHeader()).thenReturn("CMDS");
        baseEvent.getEventHeader().setPartnerCode("BC");
        HttpHeaders httpHeaders =
                roChangedDistOrs.getHttpHeaders(baseEvent.getEventHeader(), bcAuthenticationClient);
        assertEquals("CMDS", httpHeaders.get(USER_AGENT_HEADER).get(0));
    }
}
