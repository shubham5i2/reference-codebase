package com.ielts.cmds.integration.mapper;

import com.ielts.cmds.api.evt109.DocumentPublished;
import com.ielts.cmds.ors.common.integration.int262.Document;
import com.ielts.cmds.ors.common.integration.int262.DocumentRendition;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.presigner.S3Presigner;
import software.amazon.awssdk.services.s3.presigner.model.GetObjectPresignRequest;
import software.amazon.awssdk.services.s3.presigner.model.PresignedGetObjectRequest;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.ielts.cmds.integration.constants.DistORSConstants.*;

@Slf4j

/** This class is used to map incoming event to appropriate API request body */
public class EventMapper {

    /**
     * Maps input event to booking response specific to request api body
     *
     * @param documentPublished
     * @return
     */
    public Document mapDocumentResponse(final DocumentPublished documentPublished) {
        final Document orsDocumentResponse = new Document();
        orsDocumentResponse.setIssueDate(documentPublished.getDocument().getIssueDate());
        orsDocumentResponse.setTypeCode(documentPublished.getDocument().getDocumentType().getTypeCode());
        orsDocumentResponse.setExternalBookingUuid(documentPublished.getBooking().getExternalBookingUuid());
        List<DocumentRendition> renditionList = new ArrayList<>();
        if(Objects.nonNull(documentPublished.getDocument().getRenditions())) {
            documentPublished.getDocument().getRenditions().forEach(documentRendition -> {
                DocumentRendition rendition = new DocumentRendition();
                rendition.setRenditionUrl(generatePresignedUrl(documentRendition.getRenditionKey()));
                rendition.setRenditionType(documentRendition.getRenditionType());
                rendition.setContentType(documentRendition.getContentType());
                renditionList.add(rendition);
            });
            orsDocumentResponse.setRenditions(renditionList);
        }

        return orsDocumentResponse;
    }

    String generatePresignedUrl(String file) {
        String bucketName = System.getenv(EOR_LETTER_BUCKET);
        String timeout = System.getenv(PRESIGN_TIMEOUT);

        GetObjectRequest getObjectRequest =
                GetObjectRequest.builder()
                        .bucket(bucketName)
                        .key(file)
                        .build();

        GetObjectPresignRequest getObjectPresignRequest = GetObjectPresignRequest.builder()
                .signatureDuration(Duration.ofSeconds(Long.parseLong(timeout)))
                .getObjectRequest(getObjectRequest)
                .build();

        // Generate the presigned request
        PresignedGetObjectRequest presignedGetObjectRequest =
                getPresigner().presignGetObject(getObjectPresignRequest);
        log.debug("PresignUrl Generated:{}", presignedGetObjectRequest.url());
        return presignedGetObjectRequest.url().toString();
    }

    S3Presigner getPresigner(){
        return S3Presigner.builder()
                .region(Region.of(System.getenv(REGION)))
                .build();
    }
}
