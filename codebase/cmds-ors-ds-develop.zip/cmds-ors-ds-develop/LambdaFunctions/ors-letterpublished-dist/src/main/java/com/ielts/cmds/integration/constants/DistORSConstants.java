package com.ielts.cmds.integration.constants;

public class DistORSConstants {

  private DistORSConstants() {}
  public static final String TRANSACTIONID = "transactionId";

  public static final String CORRELATIONID = "correlationId";
  public static final String PARTNER_CODE = "partnerCode";
  public static final String BC = "BC";
  public static final String BC_CHN = "BC_CHN";
  public static final String REGION = "AWS_REGION";
  public static final String PRESIGN_TIMEOUT = "presigned_url_timeout_second";
  public static final String EOR_LETTER_BUCKET = "letter_bucket_name";

  public static final String ORS_LETTERPUBLISHED_DIST_BC = "ors-letterpublished-dist-bc";
  public static final String ORS_LETTERPUBLISHED_DIST_BCCHN = "ors-letterpublished-dist-bcchn";

  public static final String CALLBACK_URL = "callback_url";
  public static final String EVENT_DATE_TIME = "eventDateTime";
  public static final String USER_AGENT="user_agent";
  public static final String USER_AGENT_KEY="User-Agent";
}
