package com.ielts.cmds.integration.mapper;

import static com.ielts.cmds.integration.constants.DistORSConstants.*;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

import java.net.URL;
import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.api.evt109.DocumentPublished;
import com.ielts.cmds.integration.SQSEventBodySetup;
import com.ielts.cmds.ors.common.integration.int262.Document;

import software.amazon.awssdk.services.s3.presigner.S3Presigner;
import software.amazon.awssdk.services.s3.presigner.model.GetObjectPresignRequest;
import software.amazon.awssdk.services.s3.presigner.model.PresignedGetObjectRequest;
import uk.org.webcompere.systemstubs.environment.EnvironmentVariables;
import uk.org.webcompere.systemstubs.jupiter.SystemStub;
import uk.org.webcompere.systemstubs.jupiter.SystemStubsExtension;


@ExtendWith(MockitoExtension.class)
@ExtendWith(SystemStubsExtension.class)
class EventMapperTest {

  @Spy @InjectMocks private EventMapper eventMapper;

  private DocumentPublished documentPublished;
  
  @SystemStub private EnvironmentVariables env;

  @Mock private URL url;
  @Mock private S3Presigner presigner;

  @Mock private PresignedGetObjectRequest presignedGetObjectRequest;
  
  @BeforeEach
  void setUp() {
    env.set(PRESIGN_TIMEOUT,"200");
    env.set(EOR_LETTER_BUCKET,"eor_letter");
    env.set(REGION, "eu-west-2");
    documentPublished = SQSEventBodySetup.getEventBody();
  }
  
  @Test
  void mapDocumentResponse_ExpectDocumentObjectToBeSet() {
	  doReturn("url.com").when(eventMapper).generatePresignedUrl(documentPublished.getDocument().getRenditions().get(0).getRenditionKey());
	  Document actual = eventMapper.mapDocumentResponse(documentPublished);
	  assertEquals(documentPublished.getBooking().getExternalBookingUuid(), actual.getExternalBookingUuid());
	  assertEquals(documentPublished.getDocument().getIssueDate(), actual.getIssueDate());
	  assertEquals(documentPublished.getDocument().getDocumentType().getTypeCode(), actual.getTypeCode());
	  assertEquals(documentPublished.getDocument().getRenditions().size(), actual.getRenditions().size());
	  assertEquals(documentPublished.getDocument().getRenditions().get(0).getContentType(), actual.getRenditions().get(0).getContentType());
	  assertEquals(documentPublished.getDocument().getRenditions().get(0).getRenditionType(), actual.getRenditions().get(0).getRenditionType());
	  assertEquals("url.com", actual.getRenditions().get(0).getRenditionUrl());
  }
  
  @Test
  void mapDocumentResponseWhenRenditionsAreNull_ExpectDocumentObjectToBeSet() {
	  documentPublished.getDocument().setRenditions(null);
	  Document actual = eventMapper.mapDocumentResponse(documentPublished);
	  assertEquals(documentPublished.getBooking().getExternalBookingUuid(), actual.getExternalBookingUuid());
	  assertEquals(documentPublished.getDocument().getIssueDate(), actual.getIssueDate());
	  assertEquals(documentPublished.getDocument().getDocumentType().getTypeCode(), actual.getTypeCode());
	  assertNull(actual.getRenditions());
  }
  
  @Test
  void mapDocumentResponseWhenRenditionsAreEmpty_ExpectDocumentObjectToBeSet() {
	  documentPublished.getDocument().setRenditions(new ArrayList<>());
	  Document actual = eventMapper.mapDocumentResponse(documentPublished);
	  assertEquals(documentPublished.getBooking().getExternalBookingUuid(), actual.getExternalBookingUuid());
	  assertEquals(documentPublished.getDocument().getIssueDate(), actual.getIssueDate());
	  assertEquals(documentPublished.getDocument().getDocumentType().getTypeCode(), actual.getTypeCode());
	  assertTrue(actual.getRenditions().isEmpty());
  }
  
  @Test
  void generatePresignedUrl_ExpectUrl() {
	  doReturn(presigner).when(eventMapper).getPresigner();
	  doReturn(presignedGetObjectRequest).when(presigner).presignGetObject(ArgumentMatchers.any(GetObjectPresignRequest.class));
	  doReturn(url).when(presignedGetObjectRequest).url();
	  doReturn("url.com").when(url).toString();
	  assertEquals("url.com", eventMapper.generatePresignedUrl("file.pdf"));
  }

  @Test
  void getPresigner_ExpectObject() {
	  assertNotNull(eventMapper.getPresigner());
  }

}
