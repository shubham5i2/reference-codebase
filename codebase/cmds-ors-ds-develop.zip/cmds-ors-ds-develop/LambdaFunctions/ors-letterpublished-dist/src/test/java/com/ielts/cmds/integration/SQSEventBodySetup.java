package com.ielts.cmds.integration;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.springframework.http.HttpHeaders;

import com.ielts.cmds.api.evt109.Booking;
import com.ielts.cmds.api.evt109.Document;
import com.ielts.cmds.api.evt109.DocumentPublished;
import com.ielts.cmds.api.evt109.DocumentRendition;
import com.ielts.cmds.api.evt109.DocumentType;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

public class SQSEventBodySetup {

	public static DocumentPublished getEventBody() {

		DocumentPublished documentPublished = new DocumentPublished();
		Booking booking = new Booking();
		booking.setBookingUuid(UUID.randomUUID());
		booking.setExternalBookingUuid(UUID.randomUUID());
		documentPublished.setBooking(booking);
		Document document = new Document();
		document.setDocumentType(new DocumentType());
		document.getDocumentType().setTypeVersion("test");
		document.getDocumentType().setTypeCode("EORLETTER");
		document.setIssueDate(OffsetDateTime.parse("2024-03-08T12:59:47.289Z"));
		DocumentRendition rendition = new DocumentRendition();
		rendition.setRenditionType("Type");
		rendition.setRenditionKey("testfile");

		document.setRenditions(Collections.singletonList(rendition));
		documentPublished.setDocument(document);
		return documentPublished;
	}

	public static com.ielts.cmds.ors.common.integration.int262.Document getDocumentBody() {
		com.ielts.cmds.ors.common.integration.int262.Document document = new com.ielts.cmds.ors.common.integration.int262.Document();
		List<com.ielts.cmds.ors.common.integration.int262.DocumentRendition> renditions = new ArrayList<>();
		com.ielts.cmds.ors.common.integration.int262.DocumentRendition rendition = 
				new com.ielts.cmds.ors.common.integration.int262.DocumentRendition();
		rendition.setRenditionType("Type");
		rendition.setRenditionUrl("testurl.com");
		renditions.add(rendition);
		document.setRenditions(renditions);
		document.setTypeCode("EORLETTER");
		document.setIssueDate(OffsetDateTime.parse("2024-03-08T12:59:47.289Z"));

		return document;
	}

	public static void setHeaderContext() {
		HeaderContext context = new HeaderContext();
		context.setCorrelationId(UUID.randomUUID());
		context.setTransactionId(UUID.randomUUID());
		context.setPartnerCode("test");
		ThreadLocalHeaderContext.setContext(context);

	}
	
	public static HttpHeaders getHttpHeaders() {
		HttpHeaders httpHeaders = new HttpHeaders();
		return httpHeaders;

	}

}
