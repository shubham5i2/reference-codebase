package com.ielts.cmds.integration.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.ielts.cmds.api.evt_019.BookingDetailsV1;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Data
public class ORSTransferResponse {
    private UUID bookingUuid;
    private UUID externalBookingUuid;

    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate testDate;
    private BookingDetailsV1.BookingStatusEnum bookingStatus;

    private TestTakerResponse testTaker;
    private List<BookingLineResponse> bookingLines;
}
