package com.ielts.cmds.integration.model;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import lombok.*;

@Getter
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class ExtORSResponse extends CMDSResponseBody {
  private ORSTransferResponse response;
  public ExtORSResponse(final ORSTransferResponse response, final BaseEventErrors errors) {
    super(errors);
    this.response = response;
  }
}
