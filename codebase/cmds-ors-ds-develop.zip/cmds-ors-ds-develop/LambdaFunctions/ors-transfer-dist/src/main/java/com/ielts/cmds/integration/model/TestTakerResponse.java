package com.ielts.cmds.integration.model;

import com.ielts.cmds.api.evt_019.TestTakerDetailsV1;
import lombok.Data;

import java.util.UUID;

@Data
public class TestTakerResponse {
    private UUID externalUniqueTestTakerUuid;
    private UUID uniqueTestTakerUuid;
    private String shortCandidateNumber;
    private String compositeCandidateNumber;
    private String sebPassword;
    private TestTakerDetailsV1.BannedStatusEnum bannedStatus;

}
