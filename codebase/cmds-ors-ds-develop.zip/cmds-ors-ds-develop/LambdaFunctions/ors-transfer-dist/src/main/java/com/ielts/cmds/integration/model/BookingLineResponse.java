package com.ielts.cmds.integration.model;

import lombok.Data;

import java.util.UUID;

@Data
public class BookingLineResponse {
  private UUID bookingLineUuid;
  private UUID externalBookingLineUuid;
}
