package com.ielts.cmds.integration.constants;

public class DistORSConstants {

  private DistORSConstants() {}

  public static final String TRANSACTIONID = "transactionId";
  public static final String TRANSFER_BOOKING_REJECTED = "BookingTransferRejected";
  public static final String CORRELATIONID = "correlationId";
  public static final String PARTNER_CODE = "partnerCode";
  public static final String IDP = "IDP";
  public static final String BC = "BC";
  public static final String BC_CHN = "BC_CHN";
  public static final String ORS_TRANSFER_DIST_BC = "ors-transfer-dist-bc";
  public static final String ORS_TRANSFER_DIST_IDP = "ors-transfer-dist-idp";
  public static final String ORS_TRANSFER_DIST_BCCHN = "ors-transfer-dist-bcchn";
  public static final String CALLBACK_URL = "callback_url";
  public static final String IDP_AUTH_URL = "idp_auth_url";
  public static final String CLIENT_ID = "client_id";
  public static final String CLIENT_SECRET = "client_secret";
  public static final String AUTH_HEADER = "auth_header";
  public static final String AUTH_HEADER_NAME = "Authorization";
  public static final String ACCESS_TOKEN = "access_token";
  public static final String GRANT_TYPE = "grant_type";
  public static final String SCOPE = "scope";
  public static final String CLIENT_CREDENTIALS = "client_credentials";
  public static final String CMDS_WRITE_SCOPE = "CMDS/write";
  public static final String CMDS_BC_SCOPE = "cil.api";
  public static final String BC_AUTH_URL = "bc_auth_url";
  public static final String ENVIRONMENT = "environment";
  public static final String DEFAULT_BUCKET_NAME = "certificatepoc";
  public static final String BUCKET_NAME = "bucket_name";
  public static final String CERT_OBJECT_KEY = "cert_object_key";
  public static final String SSL_ENABLED = "ssl_enabled";
  public static final String CERTIFICATE_PASSWORD = "cert_password";
  public static final String CONNECTION_TIMEOUT = "connection_timeout";
  public static final String READ_TIMEOUT = "read_timeout";
  public static final String DEFAULT_READ_TIMEOUT = "10000";
  public static final String DEFAULT_CONNECTION_TIMEOUT = "10000";
  public static final String KEYSTORE_INSTANCE = "PKCS12";
  public static final String EVENT_DATE_TIME = "eventDateTime";
  public static final String USER_AGENT="user_agent";
  public static final String USER_AGENT_KEY="User-Agent";
}
