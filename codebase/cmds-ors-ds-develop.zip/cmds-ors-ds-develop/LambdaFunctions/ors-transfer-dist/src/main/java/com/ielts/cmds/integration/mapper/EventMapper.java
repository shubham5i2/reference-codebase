package com.ielts.cmds.integration.mapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import com.ielts.cmds.api.evt_019.BookingDetailsV1;
import com.ielts.cmds.api.evt_019.BookingLineV1;
import com.ielts.cmds.api.evt_019.TestTakerDetailsV1;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.integration.model.BookingLineResponse;
import com.ielts.cmds.integration.model.ORSTransferResponse;
import com.ielts.cmds.integration.model.TestTakerResponse;


/**
 * This class is used to map incoming event to appropriate API request body
 */
public class EventMapper {
    /**
     * Maps input event to booking response specific to request api body
     */
    public ORSTransferResponse mapORSTransferResponse(final BookingDetailsV1 transferBookingDetails) {
    	if(transferBookingDetails != null) {
    		final ORSTransferResponse transferORSTransferResponse = new ORSTransferResponse();
            transferORSTransferResponse.setBookingUuid(transferBookingDetails.getBookingUuid());
            transferORSTransferResponse.setExternalBookingUuid(transferBookingDetails.getExternalBookingUuid());
            transferORSTransferResponse.setTestDate(transferBookingDetails.getTestDate().toLocalDate());
            transferORSTransferResponse.setBookingStatus(transferBookingDetails.getBookingStatus());
            final TestTakerResponse testTakerResponse = populateTestTakerDetails(transferBookingDetails);
            transferORSTransferResponse.setTestTaker(testTakerResponse);
            final List<BookingLineResponse> bookingLinesResponse = populateBookingLines(transferBookingDetails);
            transferORSTransferResponse.setBookingLines(bookingLinesResponse);
            return transferORSTransferResponse;
    	}
        return null;
    }

    /*
     * creates testtaker response
     */
    private TestTakerResponse populateTestTakerDetails(final BookingDetailsV1 transferBookingDetails) {
        final TestTakerResponse testTakerResponse = new TestTakerResponse();
        final Optional<TestTakerDetailsV1> optTestTaker = Optional.ofNullable(transferBookingDetails.getTestTaker());
        optTestTaker.ifPresent(
                testTaker -> {
                    testTakerResponse.setExternalUniqueTestTakerUuid(
                            testTaker.getExternalUniqueTestTakerUuid());
                    testTakerResponse.setUniqueTestTakerUuid(testTaker.getUniqueTestTakerUuid());
                    testTakerResponse.setShortCandidateNumber(testTaker.getShortCandidateNumber());
                    testTakerResponse.setCompositeCandidateNumber(testTaker.getCompositeCandidateNumber());
                    testTakerResponse.setSebPassword(testTaker.getSebPassword());
                    testTakerResponse.setBannedStatus(transferBookingDetails.getTestTaker().getBannedStatus());
                });
        return testTakerResponse;
    }


    /*
     * creates bookinglines response
     */
    private List<BookingLineResponse> populateBookingLines(final BookingDetailsV1 transferBookingDetails) {
        final List<BookingLineResponse> bookingLinesResponse = new ArrayList<>();
        final Optional<List<BookingLineV1>> optBookingLines =
                Optional.ofNullable(transferBookingDetails.getBookingLines());
        optBookingLines.ifPresent(
                bookingLines ->
                        bookingLines
                                .stream()
                                .forEach(
                                        bookingLine -> {
                                            final BookingLineResponse bookingLineResponse = new BookingLineResponse();
                                            bookingLineResponse.setBookingLineUuid(bookingLine.getBookingLineUuid());
                                            bookingLineResponse.setExternalBookingLineUuid(
                                                    bookingLine.getExternalBookingLineUuid());
                                            bookingLinesResponse.add(bookingLineResponse);
                                        })
        );
        return bookingLinesResponse;
    }

    public BaseEventErrors mapBookingErrorResponse(com.ielts.cmds.api.evt_019.BaseEventErrors eventErrors) {
        List<ErrorDescription> errorDescriptions;
        errorDescriptions = eventErrorMapper(eventErrors.getErrorList());
        return new BaseEventErrors(errorDescriptions);
    }

    List<ErrorDescription> eventErrorMapper(List<com.ielts.cmds.api.evt_019.ErrorDescription> errorDescription) {
        List<ErrorDescription> errorDescriptionList = new ArrayList<>();
        for(com.ielts.cmds.api.evt_019.ErrorDescription e : errorDescription){
            ErrorDescription description = new ErrorDescription();
            description.setInterfaceName(e.getInterfaceName());
            description.setTitle(e.getTitle());
            description.setType(ErrorTypeEnum.valueOf(e.getType().toString()));
            description.setErrorCode(e.getErrorCode());

            description.setErrorTicketUuid(e.getErrorTicketUuid());

            if(Objects.nonNull(e.getMessage())) {
                description.setMessage(e.getMessage());
            }
            if(Objects.nonNull(e.getSource())) {
                Source source = new Source(e.getSource().getPath(),e.getSource().getValue());
                description.setSource(source);
            }
            errorDescriptionList.add(description);
        }
        return errorDescriptionList;
    }
}
