package com.ielts.cmds.integration.mapper;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.api.evt_019.BaseEventErrors;
import com.ielts.cmds.api.evt_019.BookingDetailsV1;
import com.ielts.cmds.api.evt_019.BookingLineV1;
import com.ielts.cmds.api.evt_019.TestTakerDetailsV1;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.SQSEventBodySetup;
import com.ielts.cmds.integration.model.BookingLineResponse;
import com.ielts.cmds.integration.model.ORSTransferResponse;
import com.ielts.cmds.integration.model.TestTakerResponse;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.ielts.cmds.integration.SQSEventBodySetup.getBookingDetails;
import static com.ielts.cmds.integration.SQSEventBodySetup.getCMDSErrorResponse019Null;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class EventMapperTest {
    @InjectMocks
    EventMapper eventMapper;

    @Mock
    BookingDetailsV1 bookingDetailsV1;

    @Mock
    BaseEventErrors baseEventErrors;

    @Spy
    private ObjectMapper mapper;

    @BeforeEach
    public void setUp() throws Exception {
        mapper = getMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);


        bookingDetailsV1 = getBookingDetails();
        baseEventErrors = SQSEventBodySetup.getCMDSErrorResponse019();
    }

    /*
     * test to validate the bookingResponse against bookingdetails
     * and check booking details populated correctly
     */
    @Test
    public void whenBookingDetailsProvided_ThenValidatedBookingResponse() {
        // when
        ORSTransferResponse ORSTransferResponse = eventMapper.mapORSTransferResponse(bookingDetailsV1);

        // then

        assertEquals(bookingDetailsV1.getBookingUuid(), ORSTransferResponse.getBookingUuid());
        assertEquals(bookingDetailsV1.getExternalBookingUuid(), ORSTransferResponse.getExternalBookingUuid());
        assertEquals(bookingDetailsV1.getBookingStatus(), ORSTransferResponse.getBookingStatus());
    }

    /*
     * test to validate the TestTakerResponse against Testtaker of bookingdetails
     * and check test taker details populated correctly
     */
    @Test
    public void whenBookingDetailsProvided_ThenValidatedTestTakerResponse() {
        // Given
        TestTakerDetailsV1 expectedTestTaker = bookingDetailsV1.getTestTaker();

        // when
        ORSTransferResponse ORSTransferResponse = eventMapper.mapORSTransferResponse(bookingDetailsV1);
        TestTakerResponse actualTestTaker = ORSTransferResponse.getTestTaker();

        // then
        assertEquals(
                expectedTestTaker.getExternalUniqueTestTakerUuid(),
                actualTestTaker.getExternalUniqueTestTakerUuid());
        assertEquals(
                expectedTestTaker.getUniqueTestTakerUuid(), actualTestTaker.getUniqueTestTakerUuid());
        assertEquals(
                expectedTestTaker.getShortCandidateNumber(), actualTestTaker.getShortCandidateNumber());
        assertEquals(
                expectedTestTaker.getCompositeCandidateNumber(),
                actualTestTaker.getCompositeCandidateNumber());
        assertEquals(expectedTestTaker.getBannedStatus(), actualTestTaker.getBannedStatus());
    }

    /*
     * test to validate the BookingLineResponse against bookingline of bookingdetails
     * and check booking line details populated correctly
     */
    @Test
    public void whenBookingDetailsProvided_ThenValidatedBookingLineResponse() {
        // Given
        BookingLineV1 expectedBookingLine = bookingDetailsV1.getBookingLines().get(0);

        // When
        ORSTransferResponse ORSTransferResponse = eventMapper.mapORSTransferResponse(bookingDetailsV1);
        BookingLineResponse actaulBookingLine = ORSTransferResponse.getBookingLines().get(0);

        // then
        assertEquals(expectedBookingLine.getBookingLineUuid(), actaulBookingLine.getBookingLineUuid());
        assertEquals(
                expectedBookingLine.getExternalBookingLineUuid(),
                actaulBookingLine.getExternalBookingLineUuid());
    }

    /*
     * when there are null values within bookingdetails then verify those null values in bookingResponse
     */
    @Test
    public void whenBookingDetailsIsPassedWithNullValues_ThenVerifyBookingResponseForNullValues() {
        // Given
        bookingDetailsV1.setBookingUuid(null);
        bookingDetailsV1.setExternalBookingUuid(null);
        bookingDetailsV1.setIsVoid(false);
        bookingDetailsV1.setBookingStatus(null);
        bookingDetailsV1.getTestTaker().setExternalUniqueTestTakerUuid(null);
        bookingDetailsV1.getTestTaker().setShortCandidateNumber(null);
        bookingDetailsV1.getTestTaker().setCompositeCandidateNumber(null);
        bookingDetailsV1.getBookingLines().get(0).setBookingLineUuid(null);
        bookingDetailsV1.getBookingLines().get(0).setExternalBookingLineUuid(null);
        bookingDetailsV1.getBookingLines().get(0).setStartDateTime(null);

        // when
        ORSTransferResponse ORSTransferResponse = eventMapper.mapORSTransferResponse(bookingDetailsV1);

        // then
        assertNull(ORSTransferResponse.getBookingUuid());
        assertNull(ORSTransferResponse.getExternalBookingUuid());
        assertNull(ORSTransferResponse.getBookingStatus());
        assertNull(ORSTransferResponse.getTestTaker().getExternalUniqueTestTakerUuid());
        assertNull(ORSTransferResponse.getTestTaker().getShortCandidateNumber());
        assertNull(ORSTransferResponse.getTestTaker().getCompositeCandidateNumber());
        assertNull(ORSTransferResponse.getBookingLines().get(0).getBookingLineUuid());
        assertNull(ORSTransferResponse.getBookingLines().get(0).getExternalBookingLineUuid());
    }

    /*
     * When booking lines in bookingDetails is null the booking lines in booking response is empty
     */
    @Test
    public void whenBookingLinesIsNull_ThenBookingResponseBookingLinesIsEmpty() {
        // given
        bookingDetailsV1.setBookingLines(null);

        // when
        ORSTransferResponse ORSTransferResponse = eventMapper.mapORSTransferResponse(bookingDetailsV1);

        // then
        assertTrue(ORSTransferResponse.getBookingLines().isEmpty());
    }

    /*
     * test to check all TestTakerResponse fields are null when TestTaker in bookingDetails is null
     */
    @Test
    public void whenTestTakerIsNull_ThenCheckForNullFieldsInTestTakerResponse() {
        // Given
        bookingDetailsV1.setTestTaker(null);

        // when
        ORSTransferResponse ORSTransferResponse = eventMapper.mapORSTransferResponse(bookingDetailsV1);
        TestTakerResponse actualTestTaker = ORSTransferResponse.getTestTaker();

        // then
        assertNull(actualTestTaker.getExternalUniqueTestTakerUuid());
        assertNull(actualTestTaker.getUniqueTestTakerUuid());
        assertNull(actualTestTaker.getShortCandidateNumber());
        assertNull(actualTestTaker.getCompositeCandidateNumber());
        assertNull(actualTestTaker.getBannedStatus());
    }

    @Test
    public void whenErrorIsProvided_ThenCheckForFieldsInErrorMapperResponse() {
        // when
        com.ielts.cmds.infrastructure.event.BaseEventErrors errorResponse = eventMapper.mapBookingErrorResponse(baseEventErrors);

        // then
        assertEquals(errorResponse.getErrorList().get(0).getType(), ErrorTypeEnum.valueOf(baseEventErrors.getErrorList().get(0).getType().toString()));
        assertEquals(errorResponse.getErrorList().get(0).getMessage(),baseEventErrors.getErrorList().get(0).getMessage());
        assertEquals(errorResponse.getErrorList().get(0).getErrorCode(),baseEventErrors.getErrorList().get(0).getErrorCode());
        assertEquals(errorResponse.getErrorList().get(0).getErrorTicketUuid(),baseEventErrors.getErrorList().get(0).getErrorTicketUuid());
        assertEquals(errorResponse.getErrorList().get(0).getInterfaceName(),baseEventErrors.getErrorList().get(0).getInterfaceName());
        assertEquals(errorResponse.getErrorList().get(0).getTitle(),baseEventErrors.getErrorList().get(0).getTitle());
        assertEquals(errorResponse.getErrorList().get(0).getSource().getPath(),baseEventErrors.getErrorList().get(0).getSource().getPath());
        assertEquals(errorResponse.getErrorList().get(0).getSource().getValue(),baseEventErrors.getErrorList().get(0).getSource().getValue());
    }

    /*
     * test to check all ErrorMapperResponse fields are provided when errors in BookingChangedV1 is not null
     * Non-mandatory fields are null
     */
    @Test
    public void whenNonMandatoryErrorFieldsAreNull_ThenCheckForFieldsInErrorMapperResponse() {
        //given
        baseEventErrors = getCMDSErrorResponse019Null();
        // when
        com.ielts.cmds.infrastructure.event.BaseEventErrors errorResponse = eventMapper.mapBookingErrorResponse(baseEventErrors);

        // then
        assertNull(errorResponse.getErrorList().get(0).getMessage());
        assertNull(errorResponse.getErrorList().get(0).getSource());
    }

    /*
     * test to validate the bookingResponse against bookingdetails
     * and check test date mapping as LocalDate format
     */
    @Test
    public void whenBookingDetailsProvided_ThenValidatedTestDateMappedAsLocalDate() {
        // when
        ORSTransferResponse ORSTransferResponse = eventMapper.mapORSTransferResponse(bookingDetailsV1);
        // then
        assertEquals(ORSTransferResponse.getTestDate(),bookingDetailsV1.getTestDate().toLocalDate());
        assertEquals(ORSTransferResponse.getTestDate().getMonth(),bookingDetailsV1.getTestDate().getMonth());
        assertEquals(ORSTransferResponse.getTestDate().getDayOfMonth(),bookingDetailsV1.getTestDate().getDayOfMonth());
        assertEquals(ORSTransferResponse.getTestDate().getYear(),bookingDetailsV1.getTestDate().getYear());
    }

    /*
     * clean up the resources
     */
    @AfterEach
    public void tearDown() {
        bookingDetailsV1 = null;
        baseEventErrors=null;
    }

    protected ObjectMapper getMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        return mapper;
    }
}
