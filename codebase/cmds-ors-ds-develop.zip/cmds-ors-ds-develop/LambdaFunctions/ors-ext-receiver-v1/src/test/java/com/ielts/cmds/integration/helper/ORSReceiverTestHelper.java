package com.ielts.cmds.integration.helper;

import com.ielts.cmds.api.common.external_client.*;
import com.ielts.cmds.api.evt_038.CancelRequestedV1;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.*;

public class ORSReceiverTestHelper {

    public static UpdateRegistrationDetailsV2 getBookingChangeRequestedV2() {
        UpdateRegistrationDetailsV2 updateRegistrationDetailsV2 = new UpdateRegistrationDetailsV2();
        updateRegistrationDetailsV2.setAgentName("agent name");
        updateRegistrationDetailsV2.setConsentGiven(true);
        updateRegistrationDetailsV2.setTestDate(String.valueOf(LocalDate.now()));
        updateRegistrationDetailsV2.setBookingDetailStatus(UpdateRegistrationDetailsV2.BookingDetailStatusEnum.COMPLETE);
        updateRegistrationDetailsV2.setBookingStatus(UpdateRegistrationDetailsV2.BookingStatusEnum.PAID);
        SpecialArrangementsV1 specialArrangementsV1 = new SpecialArrangementsV1();
        specialArrangementsV1.setArrangementToken("UJ23J34");
        updateRegistrationDetailsV2.setSpecialArrangements(specialArrangementsV1);
        MarketingInfo marketingInfo = new MarketingInfo();
        marketingInfo.setApplyingToCountryUuid(UUID.randomUUID());
        marketingInfo.setCountryApplyingToOther("UK");
        marketingInfo.setYearsOfStudy(2);
        marketingInfo.setOccupationLevelOther("MS");
        updateRegistrationDetailsV2.setMarketingInfo(marketingInfo);
        TestTakerDetails testTakerDetails = new TestTakerDetails();
        testTakerDetails.setFirstName("John");
        testTakerDetails.setLastName("Doe");
        testTakerDetails.setIdentityVerificationStatus(TestTakerDetails.IdentityVerificationStatusEnum.VERIFIED);
        CMDSAddress address = new CMDSAddress();
        address.setAddressLine1("address line 1");
        address.setAddressLine2("address line 2");
        address.setAddressLine3("address line 3");
        address.setAddressLine4("address line 4");
        address.setCity("Manchester");
        address.setCountryUuid(UUID.randomUUID());
        testTakerDetails.setAddress(address);
        updateRegistrationDetailsV2.setTestTaker(testTakerDetails);
        Set<UpdateBookingLineV2> bookingLines = new HashSet<>();
        UpdateBookingLineV2 bookingLine = new UpdateBookingLineV2();
        bookingLine.setBookingLineStatus(UpdateBookingLineV2.BookingLineStatusEnum.valueOf(BookingLine.BookingLineStatusEnum.ACTIVE.getValue()));
        bookingLine.setExternalBookingLineUuid(UUID.randomUUID());
        bookingLine.setStartDateTime(OffsetDateTime.now());
        bookingLines.add(bookingLine);
        updateRegistrationDetailsV2.setBookingLines(bookingLines);
        List<BookingLink> bookingLinks = new ArrayList<>();
        BookingLink bookingLink = new BookingLink();
        bookingLink.setRole(BookingLink.RoleEnum.SSRORIGINAL);
        BookingLinkLinkedBooking bookingLinkLinkedBooking = new BookingLinkLinkedBooking();
        bookingLinkLinkedBooking.setExternalBookingUuid(UUID.randomUUID());
        bookingLinkLinkedBooking.setProductUuid(UUID.randomUUID());
        bookingLink.setLinkedBooking(bookingLinkLinkedBooking);
        bookingLinks.add(bookingLink);
        updateRegistrationDetailsV2.setLinkedBookings(bookingLinks);
        return updateRegistrationDetailsV2;
    }

    public static TransferRequestedV2 getTransferRequest() {
        TransferRequestedV2 transferRequestedV2 = new TransferRequestedV2();
        transferRequestedV2.setTestDate(String.valueOf(LocalDate.now()));
        transferRequestedV2.setProductUuid(UUID.randomUUID());
        transferRequestedV2.setLocationUuid(UUID.randomUUID());
        List<UpdateBookingLineV2> bookingLines = new ArrayList<>();
        UpdateBookingLineV2 bookingLine = new UpdateBookingLineV2();
        bookingLine.setBookingLineStatus(UpdateBookingLineV2.BookingLineStatusEnum.valueOf(UpdateBookingLineV2.BookingLineStatusEnum.ACTIVE.getValue()));
        bookingLine.setExternalBookingLineUuid(UUID.randomUUID());
        bookingLine.setStartDateTime(OffsetDateTime.now());
        bookingLines.add(bookingLine);
        transferRequestedV2.setBookingLines(bookingLines);
        return transferRequestedV2;
    }

    public static CancelRequestedV1 getCancelRequestedV1() {
        CancelRequestedV1 cancelRequestedV1 = new CancelRequestedV1();
        cancelRequestedV1.setExternalBookingUuid(UUID.fromString("c22cd1d6-5db0-44e3-b5c8-6ad35ce50672"));
        return cancelRequestedV1;
    }

    public static String getXAccessToken() {
        return "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkJTT3YxZ21Zam1vSWNUZFpFcGN3XyJ9.eyJodHRwczovL2NtZHNpei5jb20vcGFydG5lckNvZGUiOiJHTE9CQUxfSUVMVFMiLCJodHRwczovL2NtZHNpei5jb20vaWQiOiJhdXRoMHxkZDc2MDM1Zi0xZjgxLTQ5M2ItYjY3Yi03ZGVlMTliNTIzYTQiLCJodHRwczovL2NtZHNpei5jb20vcm9sZXMiOlsibDpjNmQ2Yjc5NS1iMjBiLTQ2NmMtOTJlZi03YTUzNzUyZTIzOGMvZzo4ZjQwZDlkOS00ZmQ0LTQ3YTYtOTcyMi1kOWI5ZmM1ZTgxYWQiXSwiaHR0cHM6Ly9jbWRzaXouY29tL2VtYWlsIjoic2hhcm1hLnM1QGNhbWJyaWRnZWFzc2Vzc21lbnQub3JnLnVrIiwiaHR0cHM6Ly9jbWRzaXouY29tL2ZpcnN0TmFtZSI6IlNoaXZhbmsiLCJodHRwczovL2NtZHNpei5jb20vbGFzdE5hbWUiOiJTaGFybWEiLCJpc3MiOiJodHRwczovL2NtZHMtc2FuZGJveC5ldS5hdXRoMC5jb20vIiwic3ViIjoiYXV0aDB8ZGQ3NjAzNWYtMWY4MS00OTNiLWI2N2ItN2RlZTE5YjUyM2E0IiwiYXVkIjpbImNtZHMtc2FuZGJveC11aS1hcGkiLCJodHRwczovL2NtZHMtc2FuZGJveC5ldS5hdXRoMC5jb20vdXNlcmluZm8iXSwiaWF0IjoxNjgwMjY3MTg0LCJleHAiOjE2ODAyODE1ODQsImF6cCI6IjZucEpIS0tKaUdaSGtMSVBONWFCVzNuYUUwbEFtT25ZIiwic2NvcGUiOiJvcGVuaWQgcHJvZmlsZSBlbWFpbCJ9.mho84Bjz97Ort6e1I3_7dmSqoHAM7GnF-q3jNATTk7djYBR9tLMB3CK7woHQ1nWVTrL6ltFvF0cMNJH8fVTxc4wDhoT9H3opemAs7Ssbf8--by4SXV6bxICYLSN6RVPvrJ9mqJj1MI-V__fB63gTGcfaLUQQIlGpST9AuSYtfSkqzDtGjVFEv1OTm0Obx-c0wFUZFfngzJx8pgy1VHR5qIZBJ1s_z-23RNYeRqjdIjKvTViAC1sk-7oI7-jGTpQFx_K2pVwpNmxJvZoR4GmwbKaAdNGM7_uBPSl7cUb6C19zuCuGpa9vtvpEUTRnPRaSy-xiX3ihPucoZUlSyKH4pQ";
    }
}
