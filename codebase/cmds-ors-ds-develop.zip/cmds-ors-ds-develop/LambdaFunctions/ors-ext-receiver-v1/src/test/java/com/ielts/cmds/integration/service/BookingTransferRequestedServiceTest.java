package com.ielts.cmds.integration.service;

import com.ielts.cmds.api.common.external_client.TransferRequestedV2;
import com.ielts.cmds.api.evt_023.TransferRequested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;

import static com.ielts.cmds.integration.helper.ORSReceiverTestHelper.getTransferRequest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class BookingTransferRequestedServiceTest {

    @InjectMocks
    private BookingTransferRequestedService bookingTransferRequestedService;

    @Test
    void when_processIsCalled_WithValidData() {
        TransferRequestedV2 transferRequest = getTransferRequest();
        TransferRequested process = bookingTransferRequestedService.process(transferRequest);
        assertNotNull(process);
        assertNotNull(process.getBookingLines());
    }

    @Test
    void when_processIsCalled_WithNullBookingLineData() {
        TransferRequestedV2 transferRequest = getTransferRequest();
        transferRequest.setBookingLines(Collections.emptyList());
        TransferRequested process = bookingTransferRequestedService.process(transferRequest);
        assertNotNull(process);
        assertEquals(0, process.getBookingLines().size());
    }

    @Test
    void when_getOutgoingEventNameIsCalled_ThenReturnEventName() {
        assertNotNull(bookingTransferRequestedService.getOutgoingEventName());
    }
}