package com.ielts.cmds.integration.factory;

import com.ielts.cmds.api.common.external_client.UpdateRegistrationDetailsV2;
import com.ielts.cmds.api.evt_038.CancelRequestedV1;
import com.ielts.cmds.api.evt_040.BookingChangeRequested;
import com.ielts.cmds.integration.service.BookingCancelRequestedService;
import com.ielts.cmds.integration.service.BookingChangeRequestedService;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.ielts.cmds.integration.constants.ReceiverConstants.BOOKING_CANCEL_REQUESTED;
import static com.ielts.cmds.integration.constants.ReceiverConstants.BOOKING_CHANGE_REQUESTED;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class ORSReceiverServiceFactoryTest {

    @InjectMocks
    private ORSReceiverServiceFactory orsReceiverServiceFactory;

    /*@Test
    void when_getServiceIsCalled_ThenExpectInstanceOfBookingChangeRequestedService() {
        IReceiverService<UpdateRegistrationDetailsV2, BookingChangeRequested> expected = orsReceiverServiceFactory.getService(BOOKING_CHANGE_REQUESTED);
        assertNull(orsReceiverServiceFactory.getService("testEvent"));
        assertTrue(expected instanceof UpdateRegistrationDetailsV2);
    }*/

    @Test
    void when_getServiceIsCalled_ThenExpectInstanceOfBookingCancelRequestedService() {
        IReceiverService<CancelRequestedV1, CancelRequestedV1> expected = orsReceiverServiceFactory.getService(BOOKING_CANCEL_REQUESTED);
        assertNull(orsReceiverServiceFactory.getService("testEvent"));
        assertTrue(expected instanceof BookingCancelRequestedService);
    }
}