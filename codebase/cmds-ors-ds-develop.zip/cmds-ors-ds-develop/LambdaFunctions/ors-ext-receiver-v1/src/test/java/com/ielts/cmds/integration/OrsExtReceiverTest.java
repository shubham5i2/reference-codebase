package com.ielts.cmds.integration;

import com.auth0.jwt.exceptions.JWTDecodeException;
import com.ielts.cmds.integration.factory.ORSReceiverServiceFactory;
import com.ielts.cmds.integration.helper.ORSReceiverTestHelper;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.org.webcompere.systemstubs.environment.EnvironmentVariables;
import uk.org.webcompere.systemstubs.jupiter.SystemStub;
import uk.org.webcompere.systemstubs.jupiter.SystemStubsExtension;

import static com.ielts.cmds.integration.constants.ReceiverConstants.ORS_TOPIC_IN;
import static org.junit.jupiter.api.Assertions.*;


/**
 * Test class to validate the Ors-Ext-Receiver
 */
@ExtendWith(MockitoExtension.class)
@ExtendWith(SystemStubsExtension.class)
class OrsExtReceiverTest {

    @SystemStub
    private EnvironmentVariables environmentVariables;

    @Mock
    private OrsExtReceiverV1 orsExtReceiverV1;

    @BeforeEach
    void init() {
        environmentVariables.set(ORS_TOPIC_IN, "ors-topic-url");
        orsExtReceiverV1 = Mockito.spy(orsExtReceiverV1);
    }

    @Test
    void whenTokenIsNotNull_thenGetPartnerCode() {
        HeaderContext headerContext = new HeaderContext();
        headerContext.setXaccessToken(ORSReceiverTestHelper.getXAccessToken());
        ThreadLocalHeaderContext.setContext(headerContext);
        String expectedPartnerCode = "GLOBAL_IELTS";
        String actualPartnerCode = orsExtReceiverV1.getPartnerCode();
        assertEquals(expectedPartnerCode, actualPartnerCode);
    }

    @Test
    void whenCallingGetPartnerCodeAndTokenIsNull_thenThrowException() {
        HeaderContext headerContext = new HeaderContext();
        headerContext.setXaccessToken("token");
        ThreadLocalHeaderContext.setContext(headerContext);
        assertThrows(JWTDecodeException.class, () -> orsExtReceiverV1.getPartnerCode());
    }

    @Test
    void whenCallingGetTopicArn_thenReturnTopicArn() {
        String expectedTopicUrl = "ors-topic-url";
        assertEquals(expectedTopicUrl, orsExtReceiverV1.getTopicArn());
    }

    @Test
    void test_getServiceFactory() {
        assertAll(
                "receiverServiceFactory",
                () ->
                        assertTrue(
                                orsExtReceiverV1.getServiceFactory()
                                        instanceof ORSReceiverServiceFactory));
    }

}
