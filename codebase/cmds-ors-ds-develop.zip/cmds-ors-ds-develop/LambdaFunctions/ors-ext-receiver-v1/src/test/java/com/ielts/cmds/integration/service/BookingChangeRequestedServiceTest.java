package com.ielts.cmds.integration.service;

import com.ielts.cmds.api.common.external_client.UpdateRegistrationDetailsV2;
import com.ielts.cmds.api.evt_040.BookingChangeRequested;
import com.ielts.cmds.integration.helper.ORSReceiverTestHelper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class BookingChangeRequestedServiceTest {

    @InjectMocks
    private BookingChangeRequestedService bookingChangeRequestedService;

    @Test
    void when_processIsCalled_WithValidData() {
        UpdateRegistrationDetailsV2 updateRegistrationDetailsV2 = ORSReceiverTestHelper.getBookingChangeRequestedV2();
        BookingChangeRequested bookingChangeRequested = bookingChangeRequestedService.process(updateRegistrationDetailsV2);
        assertNotNull(bookingChangeRequested);
        assertNotNull(bookingChangeRequested.getBookingLines());
        assertNotNull(bookingChangeRequested.getLinkedBookings());
    }

    @Test
    void when_processIsCalled_WithNullBookingLineAndLinkData() {
        UpdateRegistrationDetailsV2 bookingChangeRequestedV2 = ORSReceiverTestHelper.getBookingChangeRequestedV2();
        bookingChangeRequestedV2.setBookingLines(Collections.emptySet());
        bookingChangeRequestedV2.setLinkedBookings(Collections.emptyList());
        BookingChangeRequested bookingChangeRequested = bookingChangeRequestedService.process(bookingChangeRequestedV2);
        assertNotNull(bookingChangeRequested);
        assertEquals(0, bookingChangeRequested.getBookingLines().size());
        assertEquals(0, bookingChangeRequested.getLinkedBookings().size());
    }

    @Test
    void when_getOutgoingEventNameIsCalled_ThenReturnEventName() {
        assertNotNull(bookingChangeRequestedService.getOutgoingEventName());
    }
}