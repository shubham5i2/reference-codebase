package com.ielts.cmds.integration.service;

import com.ielts.cmds.api.evt_038.CancelRequestedV1;
import com.ielts.cmds.integration.helper.ORSReceiverTestHelper;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static com.ielts.cmds.integration.constants.ReceiverConstants.EXTERNAL_BOOKING_UUID;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class BookingCancelRequestedServiceTest {

    @InjectMocks
    private BookingCancelRequestedService bookingCancelRequestedService;

    @Test
    void when_processIsCalled_ThenReturnEventBody() {
        CancelRequestedV1 cancelRequestedV1 = ORSReceiverTestHelper.getCancelRequestedV1();
        HeaderContext context = new HeaderContext();
        Map<String,String> eventContext = new HashMap<>();
        eventContext.put(EXTERNAL_BOOKING_UUID, "c22cd1d6-5db0-44e3-b5c8-6ad35ce50672");
        context.setEventContext(eventContext);
        ThreadLocalHeaderContext.setContext(context);
        assertNotNull(bookingCancelRequestedService.process(cancelRequestedV1));
    }

    @Test
    void when_getOutgoingEventNameIsCalled_ThenReturnEventName() {
        assertNotNull(bookingCancelRequestedService.getOutgoingEventName());
    }
}