package com.ielts.cmds.integration;

import com.ielts.cmds.common.utils.CMDSCommonUtils;
import com.ielts.cmds.integration.factory.ORSReceiverServiceFactory;
import com.ielts.cmds.serialization.lambda.AbstractReceiverLambda;
import com.ielts.cmds.serialization.lambda.config.DisablePublishToDedicatedEventTopic;
import com.ielts.cmds.serialization.lambda.receiver.service.AbstractServiceFactory;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import static com.ielts.cmds.integration.constants.ReceiverConstants.ORS_TOPIC_IN;
import static com.ielts.cmds.integration.constants.ReceiverConstants.PARTNER_CODE;
@DisablePublishToDedicatedEventTopic
public class OrsExtReceiverV1 extends AbstractReceiverLambda {

    @Override
    public AbstractServiceFactory getServiceFactory() {
        return new ORSReceiverServiceFactory();
    }

    @Override
    public String getTopicArn() {
        return System.getenv(ORS_TOPIC_IN);
    }

    @Override
    protected String getPartnerCode() {
        return CMDSCommonUtils.getDataFromClaims(
                ThreadLocalHeaderContext.getContext().getXaccessToken(),
                PARTNER_CODE);
    }
}
