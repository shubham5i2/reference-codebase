package com.ielts.cmds.integration.service;

import com.ielts.cmds.api.common.external_client.CMDSAddress;
import com.ielts.cmds.api.common.external_client.BookingLinkLinkedBooking;
import com.ielts.cmds.api.common.external_client.SpecialArrangementsV1;
import com.ielts.cmds.api.common.external_client.UpdateBookingLineV2;
import com.ielts.cmds.api.common.external_client.UpdateRegistrationDetailsV2;
import com.ielts.cmds.api.evt_040.BookingChangeRequested;
import com.ielts.cmds.api.evt_040.LinkedBooking;
import com.ielts.cmds.api.evt_040.SpecialArrangements;
import com.ielts.cmds.api.evt_040.TestTakerAddress;
import com.ielts.cmds.api.evt_040.BookingLine;
import com.ielts.cmds.api.evt_040.BookingLink;
import com.ielts.cmds.api.evt_040.MarketingInfo;
import com.ielts.cmds.api.evt_040.TestTakerDetails;
import com.ielts.cmds.integration.deserializer.CMDSOffsetDateTimeDeserializer;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import static com.ielts.cmds.integration.constants.ReceiverConstants.BOOKING_CHANGE_REQUESTED;

public class BookingChangeRequestedService implements IReceiverService<UpdateRegistrationDetailsV2, BookingChangeRequested> {

    @Override
    public BookingChangeRequested process(@Valid UpdateRegistrationDetailsV2 eventBody) {
        BookingChangeRequested requested = new BookingChangeRequested();
        requested.setProductUuid(eventBody.getProductUuid());
        requested.setLocationUuid(eventBody.getLocationUuid());
        requested.setTestDate(CMDSOffsetDateTimeDeserializer.deserializeToOffsetDateTime(eventBody.getTestDate()));
        requested.setExternalBookingUuid(eventBody.getExternalBookingUuid());
        requested.setExternalBookingReference(eventBody.getExternalBookingReference());
        requested.setBookingDetailStatus(BookingChangeRequested.BookingDetailStatusEnum.valueOf(eventBody.getBookingDetailStatus().getValue()));
        requested.setBookingStatus(BookingChangeRequested.BookingStatusEnum.valueOf(eventBody.getBookingStatus().getValue()));
        requested.setAgentName(eventBody.getAgentName());
        requested.setConsentGiven(eventBody.getConsentGiven());
        if(eventBody.getSpecialArrangements() != null) {
            requested.setSpecialArrangements(getSpecialArrangements(eventBody.getSpecialArrangements()));
        }
        requested.setMarketingInfo(getMarketingInfo(eventBody.getMarketingInfo()));
        requested.setTestTaker(getTestTaker(eventBody.getTestTaker()));
        requested.setBookingLines(getBookingLines(eventBody.getBookingLines()));
        requested.setLinkedBookings(getLinkedBooking(eventBody.getLinkedBookings()));
        return requested;
    }

    private SpecialArrangements getSpecialArrangements(SpecialArrangementsV1 specialArrangementsV1) {
        SpecialArrangements specialArrangements = new SpecialArrangements();
        specialArrangements.setArrangementToken(specialArrangementsV1.getArrangementToken());
        return specialArrangements;
    }

    private List<BookingLink> getLinkedBooking(List<com.ielts.cmds.api.common.external_client.BookingLink> linkedBookings) {
        List<BookingLink> bookingLinksResponse = new ArrayList<>();
        if (Objects.nonNull(linkedBookings) && !linkedBookings.isEmpty()) {
            linkedBookings.forEach(linkedBooking -> {
                BookingLink bookingLinkResponse = new BookingLink();
                bookingLinkResponse.setRole(BookingLink.RoleEnum.valueOf(linkedBooking.getRole().getValue()));
                bookingLinkResponse.setLinkedBooking(getBookingLink(linkedBooking.getLinkedBooking()));
                bookingLinksResponse.add(bookingLinkResponse);
            });
        }
        return bookingLinksResponse;
    }

    private LinkedBooking getBookingLink(BookingLinkLinkedBooking linkedBooking) {
        LinkedBooking booking = new LinkedBooking();
        booking.setExternalBookingUuid(linkedBooking.getExternalBookingUuid());
        booking.setProductUuid(linkedBooking.getProductUuid());
        return booking;
    }

    private List<BookingLine> getBookingLines(Set<UpdateBookingLineV2> bookingLines) {
        List<BookingLine> bookingLinesResponse = new ArrayList<>();
        if (!bookingLines.isEmpty()) {
            bookingLines.forEach(bookingLine -> {
                        BookingLine bookingLineResponse = new BookingLine();
                        bookingLineResponse.setExternalBookingLineUuid(bookingLine.getExternalBookingLineUuid());
                        bookingLineResponse.setProductUuid(bookingLine.getProductUuid());
                        bookingLineResponse.setStartDateTime(bookingLine.getStartDateTime());
                        bookingLineResponse.setStartDateTimeLocal(bookingLine.getStartDateTimeLocal());
                        bookingLineResponse.setBookingLineStatus(BookingLine.BookingLineStatusEnum.valueOf(bookingLine.getBookingLineStatus().getValue()));
                        bookingLinesResponse.add(bookingLineResponse);
                    }
            );
        }
        return bookingLinesResponse;
    }

    private TestTakerDetails getTestTaker(com.ielts.cmds.api.common.external_client.TestTakerDetails testTaker) {
        TestTakerDetails testTakerResponse = new TestTakerDetails();
        testTakerResponse.setExternalUniqueTestTakerUuid(testTaker.getExternalUniqueTestTakerUuid());
        testTakerResponse.setIdentityNumber(testTaker.getIdentityNumber());
        testTakerResponse.setIdentityTypeUuid(testTaker.getIdentityTypeUuid());
        testTakerResponse.setIdentityVerificationStatus(TestTakerDetails.IdentityVerificationStatusEnum.valueOf(testTaker.getIdentityVerificationStatus().getValue()));
        testTakerResponse.setIdentityIssuingAuthority(testTaker.getIdentityIssuingAuthority());
        testTakerResponse.setIdentityExpiryDate(testTaker.getIdentityExpiryDate());
        testTakerResponse.setFirstName(testTaker.getFirstName());
        testTakerResponse.setLastName(testTaker.getLastName());
        testTakerResponse.setBirthDate(testTaker.getBirthDate());
        testTakerResponse.setSexUuid(testTaker.getSexUuid());
        testTakerResponse.setEmail(testTaker.getEmail());
        testTakerResponse.setTitle(testTaker.getTitle());
        testTakerResponse.setPhone(testTaker.getPhone());
        testTakerResponse.setMobile(testTaker.getMobile());
        testTakerResponse.setLanguageUuid(testTaker.getLanguageUuid());
        testTakerResponse.setNationalityUuid(testTaker.getNationalityUuid());
        testTakerResponse.setNotes(testTaker.getNotes());
        testTakerResponse.setLanguageOther(testTaker.getLanguageOther());
        testTakerResponse.setNationalityOther(testTaker.getNationalityOther());
        testTakerResponse.setAddress(populateTestTakerAddress(testTaker.getAddress()));
        return testTakerResponse;
    }

    private TestTakerAddress populateTestTakerAddress(CMDSAddress cmdsAddress) {
        TestTakerAddress testTakerAddress = new TestTakerAddress();
        testTakerAddress.setAddressLine1(cmdsAddress.getAddressLine1());
        testTakerAddress.setAddressLine2(cmdsAddress.getAddressLine2());
        testTakerAddress.setAddressLine3(cmdsAddress.getAddressLine3());
        testTakerAddress.setAddressLine4(cmdsAddress.getAddressLine4());
        testTakerAddress.setStateTerritoryUuid(cmdsAddress.getStateTerritoryUuid());
        testTakerAddress.setPostalCode(cmdsAddress.getPostalCode());
        testTakerAddress.setCity(cmdsAddress.getCity());
        testTakerAddress.setCountryUuid(cmdsAddress.getCountryUuid());
        return testTakerAddress;
    }

    private MarketingInfo getMarketingInfo(com.ielts.cmds.api.common.external_client.MarketingInfo marketingInfoOrs) {
        MarketingInfo marketingInfo = new MarketingInfo();
        marketingInfo.setEducationLevelUuid(marketingInfoOrs.getEducationLevelUuid());
        marketingInfo.setYearsOfStudy(marketingInfoOrs.getYearsOfStudy());
        marketingInfo.setOccupationSectorUuid(marketingInfoOrs.getOccupationSectorUuid());
        marketingInfo.setOccupationLevelUuid(marketingInfoOrs.getOccupationLevelUuid());
        marketingInfo.setReasonForTestUuid(marketingInfoOrs.getReasonForTestUuid());
        marketingInfo.setApplyingToCountryUuid(marketingInfoOrs.getApplyingToCountryUuid());
        marketingInfo.setCurrentEnglishStudyPlace(marketingInfoOrs.getCurrentEnglishStudyPlace());
        marketingInfo.setOccupationSectorOther(marketingInfoOrs.getOccupationSectorOther());
        marketingInfo.setOccupationLevelOther(marketingInfoOrs.getOccupationLevelOther());
        marketingInfo.setReasonForTestOther(marketingInfoOrs.getReasonForTestOther());
        marketingInfo.setCountryApplyingToOther(marketingInfoOrs.getCountryApplyingToOther());
        return marketingInfo;
    }

    @Override
    public String getOutgoingEventName() {
        return BOOKING_CHANGE_REQUESTED;
    }
}
