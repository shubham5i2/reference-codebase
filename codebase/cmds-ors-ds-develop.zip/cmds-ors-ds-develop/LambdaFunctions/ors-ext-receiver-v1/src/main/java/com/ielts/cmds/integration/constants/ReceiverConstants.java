package com.ielts.cmds.integration.constants;

public class ReceiverConstants {
    private ReceiverConstants() {
    }

    public static final String ORS_TOPIC_IN = "ors_ext_topic_in_arn";
    public static final String PARTNER_CODE = "partnerCode";

    public static final String EXTERNAL_BOOKING_UUID = "externalBookingUuid";
    public static final String BOOKING_CHANGE_REQUESTED = "BookingChangeRequested";
    public static final String BOOKING_CANCEL_REQUESTED = "BookingCancelRequested";
    public static final String BOOKING_TRANSFER_REQUESTED = "BookingTransferRequested";
    public static final String TRANSFER_BOOKING = "BookingTransferredByOrs";
}
