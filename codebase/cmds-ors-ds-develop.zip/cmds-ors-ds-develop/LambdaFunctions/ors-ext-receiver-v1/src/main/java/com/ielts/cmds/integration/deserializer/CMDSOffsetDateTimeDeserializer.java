package com.ielts.cmds.integration.deserializer;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoField;

import com.ielts.cmds.integration.exception.CustomDateTimeParseException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CMDSOffsetDateTimeDeserializer {

    private static String[] OFFSET_DATE_TIME_SUPPORTED_PATTERNS = new String[]{
            "yyyy-MM-dd",
            "yyyy-MM-ddX",
            "yyyy-MM-ddxx",
            "yyyy-MM-ddxxx"
    };

    private CMDSOffsetDateTimeDeserializer(){
    }
    public static OffsetDateTime deserializeToOffsetDateTime(String serializedDate) {
        for (String pattern : OFFSET_DATE_TIME_SUPPORTED_PATTERNS) {
            try {
                DateTimeFormatter fmt = new DateTimeFormatterBuilder().append(DateTimeFormatter.ofPattern(pattern))
                        .parseDefaulting(ChronoField.HOUR_OF_DAY, 0)
                        .parseDefaulting(ChronoField.MINUTE_OF_HOUR, 0)
                        .parseDefaulting(ChronoField.SECOND_OF_MINUTE, 0)
                        .parseDefaulting(ChronoField.OFFSET_SECONDS, 0)
                        .toFormatter();
                return OffsetDateTime.parse(serializedDate, fmt);
            } catch (DateTimeParseException ignored) {
                log.warn("Ignoring Exception: ", ignored);
            }
        }
        throw new CustomDateTimeParseException("Failed to deserialize OffsetDateTime from the provided serialized date: " + serializedDate);
    }
}
