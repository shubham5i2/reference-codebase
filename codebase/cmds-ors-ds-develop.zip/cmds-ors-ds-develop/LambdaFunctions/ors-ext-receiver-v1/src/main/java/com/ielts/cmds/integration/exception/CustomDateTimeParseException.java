package com.ielts.cmds.integration.exception;

/** Created for handling ors distribution business exceptions. */
public class CustomDateTimeParseException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public CustomDateTimeParseException(final String message) {
        super(message);
    }
}
