package com.ielts.cmds.integration.factory;

import com.ielts.cmds.integration.service.BookingCancelRequestedService;
import com.ielts.cmds.integration.service.BookingChangeRequestedService;
import com.ielts.cmds.integration.service.BookingTransferRequestedService;
import com.ielts.cmds.serialization.lambda.receiver.service.AbstractServiceFactory;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;

import java.util.HashMap;
import java.util.Map;

import static com.ielts.cmds.integration.constants.ReceiverConstants.*;
import static com.ielts.cmds.integration.constants.ReceiverConstants.TRANSFER_BOOKING;

public class ORSReceiverServiceFactory extends AbstractServiceFactory {

    @SuppressWarnings("rawtypes")
    private static final Map<String, IReceiverService> initServices = new HashMap<>();

    static {
        initServices.put(BOOKING_CHANGE_REQUESTED, new BookingChangeRequestedService());
        initServices.put(BOOKING_CANCEL_REQUESTED, new BookingCancelRequestedService());
        initServices.put(BOOKING_TRANSFER_REQUESTED, new BookingTransferRequestedService());
        initServices.put(TRANSFER_BOOKING,new BookingTransferRequestedService());
    }

    public ORSReceiverServiceFactory() {
        super(initServices);
    }
}
