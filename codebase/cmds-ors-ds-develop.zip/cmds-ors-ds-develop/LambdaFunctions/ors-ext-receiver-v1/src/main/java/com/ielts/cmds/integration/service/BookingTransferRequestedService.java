package com.ielts.cmds.integration.service;

import com.ielts.cmds.api.common.external_client.TransferRequestedV2;
import com.ielts.cmds.api.common.external_client.UpdateBookingLineV2;
import com.ielts.cmds.api.evt_023.BookingLine;
import com.ielts.cmds.api.evt_023.TransferRequested;
import com.ielts.cmds.integration.deserializer.CMDSOffsetDateTimeDeserializer;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import javax.validation.Valid;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import static com.ielts.cmds.integration.constants.ReceiverConstants.BOOKING_TRANSFER_REQUESTED;
import static com.ielts.cmds.integration.constants.ReceiverConstants.EXTERNAL_BOOKING_UUID;

public class BookingTransferRequestedService implements IReceiverService<TransferRequestedV2, TransferRequested> {

    @Override
    public TransferRequested process(@Valid TransferRequestedV2 eventBody) {
        TransferRequested transferRequested = new TransferRequested();
        transferRequested.setProductUuid(eventBody.getProductUuid());
        transferRequested.setExternalBookingUuid(
                UUID.fromString(ThreadLocalHeaderContext.getContext().getEventContext().get(EXTERNAL_BOOKING_UUID)));
        transferRequested.setTestDate(CMDSOffsetDateTimeDeserializer.deserializeToOffsetDateTime(eventBody.getTestDate()));
        transferRequested.setLocationUuid(eventBody.getLocationUuid());
        transferRequested.setBookingLines(getBookingLine(eventBody.getBookingLines()));
        return transferRequested;
    }

    private Set<BookingLine> getBookingLine(List<com.ielts.cmds.api.common.external_client.UpdateBookingLineV2> bookingLines) {
        Set<BookingLine> bookingLineSet = new HashSet<>();
        if (!bookingLines.isEmpty()) {
            bookingLines.forEach(bookingLine -> {
                        BookingLine bookingLineResponse = new BookingLine();
                        bookingLineResponse.setExternalBookingLineUuid(bookingLine.getExternalBookingLineUuid());
                        bookingLineResponse.setProductUuid(bookingLine.getProductUuid());
                        bookingLineResponse.setBookingLineStatus(
                                bookingLine.getBookingLineStatus().getValue().equals(UpdateBookingLineV2.BookingLineStatusEnum.EXEMPT.getValue()) ?
                                        BookingLine.BookingLineStatusEnum.INACTIVE :
                                        BookingLine.BookingLineStatusEnum.valueOf(bookingLine.getBookingLineStatus().getValue()));
                        bookingLineResponse.setStartDateTime(bookingLine.getStartDateTime());
                        bookingLineResponse.setStartDateTimeLocal(bookingLine.getStartDateTimeLocal());
                        bookingLineSet.add(bookingLineResponse);
                    }
            );
        }
        return bookingLineSet;
    }

    @Override
    public String getOutgoingEventName() {
        return BOOKING_TRANSFER_REQUESTED;
    }
}
