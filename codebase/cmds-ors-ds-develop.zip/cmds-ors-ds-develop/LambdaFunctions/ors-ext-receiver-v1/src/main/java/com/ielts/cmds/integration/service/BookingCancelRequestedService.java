package com.ielts.cmds.integration.service;

import com.ielts.cmds.api.evt_038.CancelRequestedV1;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import javax.validation.Valid;
import java.util.UUID;

import static com.ielts.cmds.integration.constants.ReceiverConstants.BOOKING_CANCEL_REQUESTED;
import static com.ielts.cmds.integration.constants.ReceiverConstants.EXTERNAL_BOOKING_UUID;

public class BookingCancelRequestedService implements IReceiverService<CancelRequestedV1, CancelRequestedV1> {

    @Override
    public CancelRequestedV1 process(@Valid CancelRequestedV1 eventBody) {
        CancelRequestedV1 cancelRequested = new CancelRequestedV1();
        cancelRequested.setExternalBookingUuid(
                UUID.fromString(ThreadLocalHeaderContext.getContext().getEventContext().get(EXTERNAL_BOOKING_UUID)));
        return cancelRequested;
    }

    @Override
    public String getOutgoingEventName() {
        return BOOKING_CANCEL_REQUESTED;
    }
}
