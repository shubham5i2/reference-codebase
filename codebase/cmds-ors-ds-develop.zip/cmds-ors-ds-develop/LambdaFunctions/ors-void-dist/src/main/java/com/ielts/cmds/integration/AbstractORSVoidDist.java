package com.ielts.cmds.integration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.evt_019.BookingChangedEventV1;
import com.ielts.cmds.integration.mapper.EventMapper;
import com.ielts.cmds.integration.model.CMDSResponseBody;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.exception.InvalidClientException;
import com.ielts.cmds.security.exception.TokenNotReceivedException;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;
import com.ielts.cmds.serialization.lambda.AbstractLambda;
import com.ielts.cmds.serialization.lambda.config.DisablePublishToTopic;
import com.ielts.cmds.serialization.lambda.config.ExternalOutputType;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.http.MediaType;
import org.springframework.http.HttpMethod;
import org.springframework.web.client.HttpClientErrorException;

import java.security.KeyStoreException;
import java.security.cert.CertificateException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

import static com.ielts.cmds.integration.constants.DistORSConstants.TRANSACTIONID;
import static com.ielts.cmds.integration.constants.DistORSConstants.CORRELATIONID;
import static com.ielts.cmds.integration.constants.DistORSConstants.CALLBACK_URL;
import static com.ielts.cmds.integration.constants.DistORSConstants.PARTNER_CODE;
import static com.ielts.cmds.integration.constants.DistORSConstants.EVENT_DATE_TIME;



/**
 * This class serves the purpose of handling Booking response to External system(ORS - British
 * Council) It reads booking events specific to british council and post it back on callbackURL
 */
@Slf4j
@DisablePublishToTopic
public abstract class AbstractORSVoidDist extends AbstractLambda<BookingChangedEventV1, ExternalOutputType> {

    private final EnvironmentAwareAuthenticationClientFactory authenticationClientFactory;

    private AuthenticationClient authenticationClient;



    protected AbstractORSVoidDist() {
        this.authenticationClientFactory = new EnvironmentAwareAuthenticationClientFactory();


    }
    @Override
    protected ExternalOutputType processRequest(BookingChangedEventV1 bookingChangedEventV1) {
        if (ThreadLocalHeaderContext.getContext().getPartnerCode().equals(getPartnerCodeConstants())) {
            final EventMapper eventMapper = getEventMapper();
            CMDSResponseBody requestBody = eventMapper.mapBookingResponse(bookingChangedEventV1.getBookingDetails());
            log.debug("Request Body before RestTemplate call: {} ", requestBody);
            postRequestToExternalAPI(requestBody,System.getenv(CALLBACK_URL));
        } else {
            log.warn("Incoming partnerCode:{} does not match expected partner code:{}",
                    ThreadLocalHeaderContext.getContext().getPartnerCode(), getPartnerCodeConstants());
        }
        return null;
    }
    @Override
    protected String getTopicName() {
        return null;
    }
    void postRequestToExternalAPI(final CMDSResponseBody requestBody, final String externalUrl) {
        try {
            getAuthenticationClient();
            final HttpHeaders eventHeaders = getHttpHeaders();
            final HttpEntity<CMDSResponseBody> eventEntity = new HttpEntity<>(requestBody, eventHeaders);
            log.debug("ExternalUrl : {} ; eventEntity : {} ; eventHeader : {}", externalUrl, eventEntity, eventHeaders);
            final ResponseEntity<String> response = authenticationClient.getRestTemplate().exchange(externalUrl, HttpMethod.POST, eventEntity, String.class);
            log.trace("Response Code: {}" ,response.getStatusCode());

        } catch(HttpClientErrorException | JsonProcessingException| CertificateException| KeyStoreException| TokenNotReceivedException | InvalidClientException e){
            log.warn("Client Exception on processing event :", e);
        }
    }
    EventMapper getEventMapper() {
        return new EventMapper();
    }
    /**
     * constructs httpheader based on provided eventheader
     *
     * @return
     * @throws Exception
     */
    HttpHeaders getHttpHeaders() throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException {
        final HeaderContext eventHeader = ThreadLocalHeaderContext.getContext();
        final HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.set(TRANSACTIONID, getNonNullUuidString(eventHeader.getTransactionId()));
        httpHeaders.set(CORRELATIONID, getNonNullUuidString(eventHeader.getCorrelationId()));
        httpHeaders.set(PARTNER_CODE, eventHeader.getPartnerCode());
        httpHeaders.set(
                EVENT_DATE_TIME, getNonNullDateTimeString(eventHeader.getEventDateTime()));
        httpHeaders.set(authenticationClient.getAuthorizationHeaderName(), authenticationClient.getAccessToken());
        setAdditionalHttpHeaders(httpHeaders);
        return httpHeaders;
    }
    public void getAuthenticationClient() throws InvalidClientException, CertificateException, KeyStoreException, JsonProcessingException {
        if (authenticationClient == null) {
            authenticationClient = authenticationClientFactory.getAuthenticationClient(ThreadLocalHeaderContext.getContext().getPartnerCode());
        }
    }


    String getNonNullUuidString(UUID uuid) {
        if(uuid != null) {
            return uuid.toString();
        }
        else {
            return "";
        }
    }

    String getNonNullDateTimeString(LocalDateTime dateTime) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        if(dateTime != null) {
            return dateTime.format(formatter);
        } else {
            return "";
        }
    }

    protected abstract void setAdditionalHttpHeaders(HttpHeaders httpHeaders);

    protected abstract String getPartnerCodeConstants();

    protected abstract String getApplicationName();

}
