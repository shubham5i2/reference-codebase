package com.ielts.cmds.integration.mapper;

import com.ielts.cmds.api.evt_019.BookingDetailsV1;
import com.ielts.cmds.integration.model.CMDSResponseBody;

import javax.validation.Valid;
/** This class is used to map incoming event to appropriate API request body */
public class EventMapper {

  /**
   * Maps input event to booking response specific to request api body
   *
   */
  public CMDSResponseBody mapBookingResponse(@Valid final BookingDetailsV1 details) {
    final CMDSResponseBody bookingResponse = new CMDSResponseBody();
    bookingResponse.setExternalBookingUuid(details.getExternalBookingUuid());
    bookingResponse.setCompositeCandidateNumber(details.getTestTaker().getCompositeCandidateNumber());
    return bookingResponse;
  }

}
