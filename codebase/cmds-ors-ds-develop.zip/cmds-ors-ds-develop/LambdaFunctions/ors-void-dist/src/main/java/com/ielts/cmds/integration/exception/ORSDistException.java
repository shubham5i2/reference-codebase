package com.ielts.cmds.integration.exception;

/** Created for handling booking distribution business exceptions. */
public class ORSDistException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public ORSDistException(final String message) {
    super(message);
  }
}