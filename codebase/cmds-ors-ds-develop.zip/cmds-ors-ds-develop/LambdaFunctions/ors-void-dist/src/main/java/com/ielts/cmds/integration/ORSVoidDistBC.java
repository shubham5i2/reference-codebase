package com.ielts.cmds.integration;


import com.ielts.cmds.integration.constants.DistORSConstants;
import org.springframework.http.HttpHeaders;

import static com.ielts.cmds.integration.constants.DistORSConstants.USER_AGENT;
import static com.ielts.cmds.security.constants.DistORSConstants.USER_AGENT_KEY;

public class ORSVoidDistBC extends AbstractORSVoidDist {
  @Override
  protected String getPartnerCodeConstants() {
    return DistORSConstants.BC;
  }

  @Override
  protected String getApplicationName() {
    return DistORSConstants.ORS_VOID_DIST_BC;
  }
  @Override
  protected void setAdditionalHttpHeaders(HttpHeaders httpHeaders) {
    httpHeaders.set(USER_AGENT_KEY, System.getenv(USER_AGENT));
  }
}