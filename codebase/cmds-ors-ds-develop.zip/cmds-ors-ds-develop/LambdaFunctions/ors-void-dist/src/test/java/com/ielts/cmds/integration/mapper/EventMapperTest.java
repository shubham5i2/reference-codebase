package com.ielts.cmds.integration.mapper;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.api.evt_019.BookingDetailsV1;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.SQSEventBodySetup;
import com.ielts.cmds.integration.model.CMDSResponseBody;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.aspectj.lang.annotation.After;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;


@ExtendWith(MockitoExtension.class)
public class EventMapperTest {

  @InjectMocks EventMapper eventMapper;

  @Mock
  BookingDetailsV1 bookingDetails;

  @Spy private ObjectMapper mapper;
  @BeforeEach
  void setUp() {
    bookingDetails = SQSEventBodySetup.getBookingDetails();
  }


  /*
   * test to validate the bookingResponse against bookingdetails
   * and check booking details populated correctly
   */
  @Test
  public void whenBookingDetailsProvided_ThenValidatedBookingResponse() {
    // when
    CMDSResponseBody bookingResponse = eventMapper.mapBookingResponse(bookingDetails);

    // then

    assertEquals(bookingDetails.getExternalBookingUuid(), bookingResponse.getExternalBookingUuid());
    assertEquals(bookingDetails.getTestTaker().getCompositeCandidateNumber(), bookingResponse.getCompositeCandidateNumber());
  }



  /*
   * when there are null values within bookingdetails then verify those null values in bookingResponse
   */
  @Test
  public void whenBookingDetailsIsPassedWithNullValues_ThenVerifyBookingResponseForNullValues() {
    // Given
    bookingDetails.setExternalBookingUuid(null);
    bookingDetails.getTestTaker().setCompositeCandidateNumber(null);
    // when
    CMDSResponseBody bookingResponse = eventMapper.mapBookingResponse(bookingDetails);

    // then
    assertNull(bookingResponse.getExternalBookingUuid());
    assertNull(bookingResponse.getCompositeCandidateNumber());
  }


  /*
   * clean up the resources
   */
  @AfterEach
  public void tearDown() {
    bookingDetails = null;
  }

  protected ObjectMapper getMapper() {
    ObjectMapper mapper = new ObjectMapper();
    mapper.registerModule(new JavaTimeModule());
    mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
    mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
    mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    return mapper;
  }
}
