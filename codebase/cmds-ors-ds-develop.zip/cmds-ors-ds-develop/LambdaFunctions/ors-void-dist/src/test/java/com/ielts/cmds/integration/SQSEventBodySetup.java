package com.ielts.cmds.integration;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.api.evt_019.BookingDetailsV1;
import com.ielts.cmds.api.evt_019.TestTakerDetailsV1;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;


import java.lang.reflect.Field;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import org.springframework.http.HttpHeaders;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.Map;
import java.util.HashMap;

import static com.ielts.cmds.integration.constants.DistORSConstants.CALLBACK_URL;
import static com.ielts.cmds.integration.constants.DistORSConstants.CLIENT_ID;
import static com.ielts.cmds.integration.constants.DistORSConstants.CLIENT_SECRET;
import static com.ielts.cmds.integration.constants.DistORSConstants.ACCESS_TOKEN;

public class SQSEventBodySetup {
  private static final ObjectMapper mapper = getMapper();



  public static BookingDetailsV1 getBookingDetails() {
    BookingDetailsV1 bookingDetails = new BookingDetailsV1();
    bookingDetails.setExternalBookingUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775565"));
    TestTakerDetailsV1 testTakerDetails = new TestTakerDetailsV1();
    testTakerDetails.setCompositeCandidateNumber("compcannumber");
    bookingDetails.setTestTaker(testTakerDetails);
    return bookingDetails;
  }
  public static void setHeaderContext() {
    HeaderContext context = new HeaderContext();
    context.setCorrelationId(UUID.randomUUID());
    context.setTransactionId(UUID.randomUUID());
    context.setPartnerCode("test");
    ThreadLocalHeaderContext.setContext(context);

  }

  public static HttpHeaders getHttpHeaders() {
    HttpHeaders httpHeaders = new HttpHeaders();
    return httpHeaders;

  }


  protected static ObjectMapper getMapper() {
    ObjectMapper mapper = new ObjectMapper();
    mapper.registerModule(new JavaTimeModule());
    mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
    mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
    mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    return mapper;
  }

  public static BaseHeader getEventHeader() {
    BaseHeader eventHeader = new BaseHeader();
    eventHeader.setTransactionId(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
    eventHeader.setCallbackURL("http://35.178.179.164:8105/booking");
    eventHeader.setCorrelationId(UUID.fromString("779187f5-38ed-4e86-b311-050ffe394f81"));
    eventHeader.setPartnerCode("BC");
    eventHeader.setEventName("BookingVoid");
    LocalDateTime eventDateTime =
            LocalDateTime.parse(
                    "2020-09-29T21:00:35.723Z",
                    DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
    eventHeader.setEventDateTime(eventDateTime);
    return eventHeader;
  }
  public static BaseHeader getIDPEventHeader() {
    BaseHeader eventHeader = new BaseHeader();
    eventHeader.setTransactionId(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
    eventHeader.setCallbackURL("http://35.178.179.164:8105/booking");
    eventHeader.setCorrelationId(UUID.fromString("779187f5-38ed-4e86-b311-050ffe394f81"));
    eventHeader.setPartnerCode("IDP");
    eventHeader.setEventName("BookingVoid");
    LocalDateTime eventDateTime =
            LocalDateTime.parse(
                    "2020-09-29T21:00:35.723Z",
                    DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
    eventHeader.setEventDateTime(eventDateTime);
    return eventHeader;
  }
  public static BaseHeader getBCCHNEventHeader() {
    BaseHeader eventHeader = new BaseHeader();
    eventHeader.setTransactionId(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
    eventHeader.setCallbackURL("http://35.178.179.164:8105/booking");
    eventHeader.setCorrelationId(UUID.fromString("779187f5-38ed-4e86-b311-050ffe394f81"));
    eventHeader.setPartnerCode("BC_CHN");
    eventHeader.setEventName("BookingVoid");
    LocalDateTime eventDateTime =
            LocalDateTime.parse(
                    "2020-09-29T21:00:35.723Z",
                    DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
    eventHeader.setEventDateTime(eventDateTime);
    return eventHeader;
  }

  public static String getIDPEventBody() throws JsonProcessingException {
    BaseHeader eventHeader = getIDPEventHeader();

    BookingDetailsV1 bookingDetails = getBookingDetails();
    String eventBody = mapper.writeValueAsString(bookingDetails);

    List<ErrorDescription> errorList = new ArrayList<>();
    ErrorDescription description = new ErrorDescription();
    description.setInterfaceName("Booking");
    description.setType(ErrorTypeEnum.VALIDATION);
    description.setErrorCode("1234");
    Source source = Source.builder().value("").path("product_uuid").build();
    description.setSource(source);
    errorList.add(description);

    BaseEventErrors errorResponse = new BaseEventErrors(errorList);

    BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
    cmdsEvent.setEventHeader(eventHeader);
    cmdsEvent.setEventBody(eventBody);
    cmdsEvent.setEventErrors(errorResponse);
    return mapper.writeValueAsString(cmdsEvent);
  }
  public static String getBCCHNEventBody() throws JsonProcessingException {
    BaseHeader eventHeader = getBCCHNEventHeader();

    BookingDetailsV1 bookingDetails = getBookingDetails();
    String eventBody = mapper.writeValueAsString(bookingDetails);

    List<ErrorDescription> errorList = new ArrayList<>();
    ErrorDescription description = new ErrorDescription();
    description.setInterfaceName("Booking");
    description.setType(ErrorTypeEnum.VALIDATION);
    description.setErrorCode("1234");
    Source source = Source.builder().value("").path("product_uuid").build();
    description.setSource(source);
    errorList.add(description);

    BaseEventErrors errorResponse = new BaseEventErrors(errorList);

    BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
    cmdsEvent.setEventHeader(eventHeader);
    cmdsEvent.setEventBody(eventBody);
    cmdsEvent.setEventErrors(errorResponse);
    return mapper.writeValueAsString(cmdsEvent);
  }

  public static Map<String, String> getEnvironmentVariablesStub() {
    Map<String, String> map = new HashMap<>();
    map.put(CLIENT_ID, "cmds-id");
    map.put(CLIENT_SECRET, "cmds-secret");
    map.put(ACCESS_TOKEN, "access-token");
    map.put("bc_auth_token_url", "BC_AUTH_URL");
    map.put(CALLBACK_URL, "https://wiremock.shared.cmdsiz.com/ors/invoke/v1/booking");
    return map;
  }
  protected static void setEnviornment(Map<String, String> newenv) throws Exception {
    try {
      Class<?> processEnvironmentClass = Class.forName("java.lang.ProcessEnvironment");
      Field theEnvironmentField = processEnvironmentClass.getDeclaredField("theEnvironment");
      theEnvironmentField.setAccessible(true);
      Map<String, String> env = (Map<String, String>) theEnvironmentField.get(null);
      env.putAll(newenv);
      Field theCaseInsensitiveEnvironmentField = processEnvironmentClass.getDeclaredField("theCaseInsensitiveEnvironment");
      theCaseInsensitiveEnvironmentField.setAccessible(true);
      Map<String, String> cienv = (Map<String, String>)     theCaseInsensitiveEnvironmentField.get(null);
      cienv.putAll(newenv);
    } catch (NoSuchFieldException e) {
      Class[] classes = Collections.class.getDeclaredClasses();
      Map<String, String> env = System.getenv();
      for(Class cl : classes) {
        if("java.util.Collections$UnmodifiableMap".equals(cl.getName())) {
          Field field = cl.getDeclaredField("m");
          field.setAccessible(true);
          Object obj = field.get(env);
          Map<String, String> map = (Map<String, String>) obj;
          map.clear();
          map.putAll(newenv);
        }
      }
    }
  }

}
