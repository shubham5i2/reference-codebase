package com.ielts.cmds.integration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;

import com.amazonaws.services.sns.AmazonSNS;
import com.ielts.cmds.integration.constants.DistORSConstants;
import com.ielts.cmds.serialization.lambda.config.SNSClientConfig;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
class ORSBookingBannedDistIDPTest {

	@InjectMocks private ORSBookingBannedDistIDP bookingBannedDistIDP;

	private static MockedStatic<SNSClientConfig> snsClientConfig;

	@Mock private AmazonSNS snsClient;

	@BeforeAll
	static void beforeClass() {
		snsClientConfig = Mockito.mockStatic(SNSClientConfig.class);
	}

	@AfterAll
	static void afterClass() {
		Mockito.framework().clearInlineMocks();
	}

	@BeforeEach
	void setup() {
		snsClientConfig.when(SNSClientConfig::getSNSClient).thenReturn(snsClient);
	}


	@Test
	void getPartnerCodeConstants_thenReturnIDP() {
		assertEquals(DistORSConstants.IDP, bookingBannedDistIDP.getPartnerCodeConstants());
	}

	@Test
	void getApplicationName_thenReturnIDP() {
		assertEquals(DistORSConstants.ORS_BOOKINGBANNED_DIST_IDP, bookingBannedDistIDP.getApplicationName());
	}
	
	@Test
	@SneakyThrows
	void setAdditionalHttpHeaders() {
		HttpHeaders httpHeaders = new HttpHeaders();
		bookingBannedDistIDP.setAdditionalHttpHeaders(httpHeaders);
		assertNull(httpHeaders.get(DistORSConstants.USER_AGENT_KEY));
	}
}
