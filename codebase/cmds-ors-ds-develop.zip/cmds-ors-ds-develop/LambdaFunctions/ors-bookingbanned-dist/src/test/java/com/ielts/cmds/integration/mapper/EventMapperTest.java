package com.ielts.cmds.integration.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.booking.common.out.model.BookingBanV1;
import com.ielts.cmds.integration.SQSEventBodySetup;
import com.ielts.cmds.ors.common.integration.int474.BookingBan;
import com.ielts.cmds.ors.common.integration.int474.BookingBanDetails;

@ExtendWith(MockitoExtension.class)
class EventMapperTest {

	@Spy @InjectMocks private EventMapper eventMapper;

	private BookingBanV1 bookingBanV1;

	@BeforeEach
	void setUp() {
		bookingBanV1 = SQSEventBodySetup.getBookingBannedDetails();
	}
	
	@Test
	void mapBannedResponse_ExpectMappedResponse() {
		BookingBan actual = eventMapper.mapBookingBannedResponse(bookingBanV1);
		assertEquals(bookingBanV1.getExternalBookingUuid().toString(), actual.getExternalBookingUuid());
		assertEquals(bookingBanV1.getUniqueTestTakerUuid().toString(), actual.getUniqueTestTakerUuid());
		assertEquals(bookingBanV1.getTestDate(), actual.getTestDate());
	}
	
	@Test
	void mapBannedDetailsResponse_ExpectMappedResponse() {
		BookingBanDetails actual = eventMapper.mapBookingBanDetails(bookingBanV1.getDetails());
		assertEquals(bookingBanV1.getDetails().getBanUuid().toString(), actual.getBanUuid());
		assertEquals(bookingBanV1.getDetails().getBanReasonUuid().toString(), actual.getBanReasonUuid());
		assertEquals(bookingBanV1.getDetails().getComment(), actual.getComment());
		
	}
	
	@Test
	void mapBannedDetailsResponseNull_ExpectMappedResponse() {
		assertNull(eventMapper.mapBookingBanDetails(null));
		
	}
}