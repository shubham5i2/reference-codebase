package com.ielts.cmds.integration.mapper;

import com.ielts.cmds.booking.common.out.model.BookingBanDetailsV1;
import com.ielts.cmds.booking.common.out.model.BookingBanV1;
import com.ielts.cmds.ors.common.integration.int474.BookingBan;
import com.ielts.cmds.ors.common.integration.int474.BookingBanDetails;

/**
 * This class is used to map incoming event to appropriate API request body
 */
public class EventMapper {

    public BookingBan mapBookingBannedResponse(final BookingBanV1 bookingBanV1) {
        final BookingBan bookingBan = new BookingBan();
        bookingBan.setExternalBookingUuid(bookingBanV1.getExternalBookingUuid().toString());
        bookingBan.setUniqueTestTakerUuid(bookingBanV1.getUniqueTestTakerUuid().toString());
        bookingBan.setTestDate(bookingBanV1.getTestDate());
        bookingBan.setDetails(mapBookingBanDetails(bookingBanV1.getDetails()));
        return bookingBan;
    }

	public BookingBanDetails mapBookingBanDetails(BookingBanDetailsV1 details) {
		if(details != null) {
			BookingBanDetails bookingBanDetails = new BookingBanDetails();
	        bookingBanDetails.setBanUuid(details.getBanUuid().toString());
	        bookingBanDetails.setBanReasonUuid(details.getBanReasonUuid().toString());
	        bookingBanDetails.setComment(details.getComment());
	        return bookingBanDetails;
		} else {
			return null;
		}
		
	}
}
