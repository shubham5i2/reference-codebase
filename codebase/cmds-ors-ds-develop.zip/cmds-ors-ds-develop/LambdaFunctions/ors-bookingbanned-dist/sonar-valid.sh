#!/usr/bin/env sh
LC_CTYPE=en_US.utf8
# $1 = sonarLoginToken $2 = sonar url for project status $3=path
# url = sonartask url
Cyan='\033[36m'
Magenta='\033[35m'
Yellow='\033[33m'
YellowBlink='\033[33;5;7m'
Green='\033[32m'
Red='\033[31m'
White='\e[0m' # No Color
sleep 5s
url=$(sed -n 's/ceTaskUrl=//p' ./$3/sonar/report-task.txt)
echo "Wait time for the report $url"
sleep 5s
curl -k -u "$1":"" $url -o ./$3/sonar/analysis.txt
sleep 5s
echo -e "${Magenta}.....Stored results in analysis.txt....."
status=$(grep -Po '"status": *"[^"]*"' ./$3/sonar/analysis.txt | grep -o '"[^"]*"$' | sed 's/"//g')
echo -e "${Cyan}Status as ${White}$status"
analysisId=$(grep -Po '"analysisId": *"[^"]*"' ./$3/sonar/analysis.txt | grep -o '"[^"]*"$' | sed 's/"//g')
echo -e "${Cyan}Analysis Id ${White}$analysisId"
sleep 3s
if [ "$status" = "SUCCESS" ]; then
    echo -e "SONAR ANALYSIS SUCCESSFUL..."
    echo -e "${YellowBlink}ANALYSING RESULTS....\033[0m${Yellow}"
    sleep 5s
    curl -k -u "$1":"" $2/api/qualitygates/project_status?analysisId=$analysisId -o ./$3/sonar/result.txt
    result=$(grep -Po '"status": *"[^"]*"'  ./$3/sonar/result.txt | grep -o '"[^"]*"$' | sed 's/"//g')
    if [ "$result" = "ERROR" ]; then
        echo -e "${Red}SONAR RESULTS FAILED${White}"
        err=$(grep -Po '"conditions": *"[^"]*"' ./$3/sonar/result.txt | grep -o '"[^"]*"$' | sed 's/"//g')
        echo -e "${Red}"$err"${White}..."
        sleep 2s
        exit 1
    else
        echo -e "${Green}SONAR RESULTS SUCCESSFUL${White}..."
        err=$(grep -Po '"conditions": *"[^"]*"' ./$3/sonar/result.txt | grep -o '"[^"]*"$' | sed 's/"//g')
        echo -e "${Green}"$err"${White}..."
        sleep 2s
        exit 0
    fi
else
    echo -e "${Red}SONAR ANALYSIS FAILED${White}..."
    sleep 2s
    exit 1
fi

