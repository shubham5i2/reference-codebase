package com.ielts.cmds.integration.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.integration.SQSEventBodySetup;
import com.ielts.cmds.ors.common.integration.int259.ReceivingOrganisationSelectionDeliveryStatus;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;

@ExtendWith(MockitoExtension.class)
class EventMapperTest {

	@Spy @InjectMocks private EventMapper eventMapper;

	private OrganisationSelectionNodeV1 request;

	@BeforeEach
	void setUp() {
		request = SQSEventBodySetup.getRequest();
	}
	
	@Test
	void mapRequest_ExpectMappedResponse() {
		ReceivingOrganisationSelectionDeliveryStatus actual = eventMapper.mapRequest(request);
		assertEquals(request.getBookingDetails().getExternalBookingUuid().toString(), actual.getExternalBookingUuid());
		assertEquals(request.getBookingDetails().getExternalBookingReference(), actual.getExternalBookingReference());
		assertEquals(request.getSelection().getTrfNumber(), actual.getTrfNumber());
		assertEquals(request.getSelection().getSelectionUuid().toString(), actual.getSelection().getSelectionUuid());
		assertEquals(request.getSelection().getExternalSelectionUuid().toString(), actual.getSelection().getExternalSelectionUuid());
		assertEquals(request.getSelection().getSelectionUuid().toString(), actual.getSelection().getSelectionUuid());
		assertEquals(request.getSelection().getDeliveryStatus().toString(), actual.getSelection().getDeliveryStatus().toString());
		assertEquals(request.getSelection().getDeliveryStatusChangedDatetime(), actual.getSelection().getDeliveryStatusChangedDateTime());
	}

}
