package com.ielts.cmds.integration;

import java.time.OffsetDateTime;
import java.util.UUID;

import org.springframework.http.HttpHeaders;

import com.ielts.cmds.rd.domain.model.enums.DeliveryStatusEnum;
import com.ielts.cmds.rd.domain.model.out.BookingNodeV1;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;
import com.ielts.cmds.rd.domain.model.out.SelectionNodeV1;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

public class SQSEventBodySetup {

    public static OrganisationSelectionNodeV1 getRequest(){
        OrganisationSelectionNodeV1 event = new OrganisationSelectionNodeV1();
        BookingNodeV1 booking = new BookingNodeV1();
        booking.setExternalBookingUuid(UUID.randomUUID());
        booking.setExternalBookingReference("ExternalReference");
        event.setBookingDetails(booking);

        SelectionNodeV1 selectionNodeV1 = new SelectionNodeV1();
        selectionNodeV1.setTrfNumber("TRF09861");
        selectionNodeV1.setSelectionUuid(UUID.randomUUID());
        selectionNodeV1.setExternalSelectionUuid(UUID.randomUUID());
        selectionNodeV1.setDeliveryStatus(DeliveryStatusEnum.DELIVERED);
        selectionNodeV1.setDeliveryStatusChangedDatetime(OffsetDateTime.MAX);
        event.setSelection(selectionNodeV1);

        return  event;
    }
    
    public static void setHeaderContext() {
		HeaderContext context = new HeaderContext();
		context.setCorrelationId(UUID.randomUUID());
		context.setTransactionId(UUID.randomUUID());
		context.setPartnerCode("test");
		ThreadLocalHeaderContext.setContext(context);

	}
	
	public static HttpHeaders getHttpHeaders() {
		HttpHeaders httpHeaders = new HttpHeaders();
		return httpHeaders;

	}
}