package com.ielts.cmds.integration.mapper;

import com.ielts.cmds.ors.common.integration.int259.ReceivingOrganisationSelectionDeliveryStatus;
import com.ielts.cmds.ors.common.integration.int259.ReceivingOrganisationSelectionDeliveryStatusSelection;
import com.ielts.cmds.ors.common.integration.int259.ReceivingOrganisationSelectionDeliveryStatusSelection.DeliveryStatusEnum;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;

public class EventMapper {

    public ReceivingOrganisationSelectionDeliveryStatus mapRequest(OrganisationSelectionNodeV1 request) {
        ReceivingOrganisationSelectionDeliveryStatus event = new ReceivingOrganisationSelectionDeliveryStatus();
        event.setExternalBookingUuid(request.getBookingDetails().getExternalBookingUuid().toString());
        event.setExternalBookingReference(request.getBookingDetails().getExternalBookingReference());
        event.setTrfNumber(request.getSelection().getTrfNumber());

        ReceivingOrganisationSelectionDeliveryStatusSelection selection = new ReceivingOrganisationSelectionDeliveryStatusSelection();
        selection.setSelectionUuid(request.getSelection().getSelectionUuid().toString());
        selection.setExternalSelectionUuid(request.getSelection().getExternalSelectionUuid().toString());
        selection.setDeliveryStatus(DeliveryStatusEnum.valueOf(request.getSelection().getDeliveryStatus().toString()));
        selection.setDeliveryStatusChangedDateTime(request.getSelection().getDeliveryStatusChangedDatetime());
        event.setSelection(selection);

        return event;
    }
}