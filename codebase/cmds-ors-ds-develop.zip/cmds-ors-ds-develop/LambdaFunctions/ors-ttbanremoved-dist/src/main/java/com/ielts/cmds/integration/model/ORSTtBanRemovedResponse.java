package com.ielts.cmds.integration.model;

import lombok.Data;

import java.util.UUID;

@Data
public class ORSTtBanRemovedResponse {
    private UUID banUuid;

    private UUID uniqueTestTakerUuid;

    private String uniqueTestTakerId;
}