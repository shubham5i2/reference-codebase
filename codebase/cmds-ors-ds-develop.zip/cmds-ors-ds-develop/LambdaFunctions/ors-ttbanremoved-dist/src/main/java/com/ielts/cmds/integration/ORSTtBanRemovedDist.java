package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.constants.DistORSConstants.BC;
import static com.ielts.cmds.integration.constants.DistORSConstants.CALLBACK_URL;
import static com.ielts.cmds.integration.constants.DistORSConstants.CORRELATIONID;
import static com.ielts.cmds.integration.constants.DistORSConstants.EVENT_DATE_TIME;
import static com.ielts.cmds.integration.constants.DistORSConstants.PARTNER_CODE;
import static com.ielts.cmds.integration.constants.DistORSConstants.TRANSACTIONID;
import static com.ielts.cmds.integration.constants.DistORSConstants.USER_AGENT;
import static com.ielts.cmds.integration.constants.DistORSConstants.USER_AGENT_KEY;
import static java.lang.String.format;

import java.security.KeyStoreException;
import java.security.cert.CertificateException;
import java.time.format.DateTimeFormatter;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.booking.common.out.model.TestTakerBanRemovedV1;
import com.ielts.cmds.common.logger.util.CMDSLambdaLoggerUtil;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.exception.ORSDistException;
import com.ielts.cmds.integration.mapper.EventMapper;
import com.ielts.cmds.integration.model.ORSTtBanRemovedResponse;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.exception.InvalidClientException;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class ORSTtBanRemovedDist {

    private final ObjectMapper mapper;

    private final String extCallbackUrl;

    private final String userAgent;

    private final EnvironmentAwareAuthenticationClientFactory authenticationClientFactory;

    private AuthenticationClient authenticationClient;

    protected ORSTtBanRemovedDist() {
        this.mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
        this.authenticationClientFactory = new EnvironmentAwareAuthenticationClientFactory();
        this.extCallbackUrl = System.getenv(CALLBACK_URL);
        this.userAgent = System.getenv(USER_AGENT);
    }

    /**
     * This method will be triggered on events published to ORS queue. It reads SQS records,validate
     * it and post to external system(ORS)
     *
     * @param input
     * @param context
     */
    public void handleRequest(final SQSEvent input, final Context context) throws Exception {
        for (SQSEvent.SQSMessage message : input.getRecords()) {
            final String sqsMessage = message.getBody();
            validateAndSendEventRequest(sqsMessage, context);
        }
    }

    /**
     * Validates and sends the received sqs message body for further processing
     *
     * @param sqsMessage
     * @param context
     * @throws JsonProcessingException
     */
    private void validateAndSendEventRequest(final String sqsMessage, final Context context) throws Exception {
        try {
            final BaseEvent<BaseHeader> event = validateHeadersAndBody(sqsMessage);
            final BaseHeader eventHeader = event.getEventHeader();
            final UUID transactionId = eventHeader.getTransactionId();

            event.getEventHeader().setPartnerCode(getPartnerCodeConstants());

            initializeLogger(transactionId, context);
            log.info("Event received in ORS-DS : ors-ttbanremoved-dist with metadata as {}",
                    mapper.readValue(sqsMessage, BaseEvent.class).getEventHeader());

            mapAndSendExternalEvent(event, eventHeader);
            log.info("Event being published from ORS DS : ors-ttbanremoved-dist with metadata as {}", mapper.writeValueAsString(eventHeader));
        } catch (JsonProcessingException ex) {
            log.error("Exception on processing jsonBody: ", ex);
            throw new ORSDistException(format("Exception on processing jsonBody :%s", ex));
        }
    }

    /**
     * This method validates event headers and event body.
     *
     * @param sqsMsg
     * @return
     * @throws JsonProcessingException
     */
    private BaseEvent<BaseHeader> validateHeadersAndBody(final String sqsMsg) throws JsonProcessingException {

        final BaseEvent<BaseHeader> cmdsEvent = mapper.readValue(sqsMsg, new TypeReference<BaseEvent<BaseHeader>>() {
        });
        final Validator cmdsEventValidator = Validation.buildDefaultValidatorFactory().getValidator();

        final Set<ConstraintViolation<BaseEvent<BaseHeader>>> eventViolations =
                cmdsEventValidator.validate(cmdsEvent);

        if (!CollectionUtils.isEmpty(eventViolations)) {

            final Set<String> errorMessageSet =
                    eventViolations.stream()
                            .map(ConstraintViolation::getMessage)
                            .collect(Collectors.toSet());

            final String errorMessage = String.join(", ", errorMessageSet);
            log.error("Validation failed for CMDSEvent - {} :", errorMessage);
            log.info("Event being published from ORS-DS : ors-ttbanremoved-dist with metadata as {} and error {}",
                    mapper.writeValueAsString(cmdsEvent.getEventHeader()), errorMessage);
            throw new ORSDistException(format("CMDS Event Validation failed- [%s] for the request %s", errorMessage, sqsMsg));
        }
        validateEventBody(cmdsEvent);
        return cmdsEvent;
    }

    /*
     * This method validates event body and event errors
     */
    private void validateEventBody(BaseEvent<BaseHeader> event) {
        if (StringUtils.isEmpty(event.getEventBody())) {
            throw new ORSDistException(format("Not a valid event. No event body and no event error: %s", event));
        }
    }

    /**
     * It processes and sends event body to appropriate external api resource based on EventType
     *
     * @param event
     * @param headers
     * @throws JsonProcessingException
     */
    void mapAndSendExternalEvent(final BaseEvent<BaseHeader> event, final BaseHeader headers) throws Exception {

        final EventMapper eventMapper = new EventMapper();
        ORSTtBanRemovedResponse ttBanRemovedResponse = null;

        final TestTakerBanRemovedV1 details = mapper.readValue(event.getEventBody(), TestTakerBanRemovedV1.class);
        ttBanRemovedResponse = eventMapper.mapBanRemovedResponse(details);

        postRequestToExternalAPI(ttBanRemovedResponse, headers, extCallbackUrl);
    }

    /**
     * This method posts event body related to TtBanRemoved events to external systems.
     *
     * @param resBody
     * @param eventHeader
     * @param externalUrl
     * @throws JsonProcessingException
     */
    private void postRequestToExternalAPI(final ORSTtBanRemovedResponse resBody, final BaseHeader eventHeader, final String externalUrl) {
        final UUID transactionId = eventHeader.getTransactionId();
        try {
            getAuthenticationClient(eventHeader.getPartnerCode());
            final HttpHeaders eventHeaders = getHttpHeaders(eventHeader);
            final HttpEntity<ORSTtBanRemovedResponse> eventEntity = new HttpEntity<>(resBody, eventHeaders);
            final ResponseEntity<String> response = authenticationClient.getRestTemplate().postForEntity(externalUrl, eventEntity, String.class);

            if (!(response.getStatusCode() == HttpStatus.OK || response.getStatusCode() == HttpStatus.ACCEPTED)) {

                throw new ORSDistException(
                        format(
                                "Request Failed with StatusCode:%s. TransactionId:%s",
                                response.getStatusCode(), transactionId));
            }
            log.info(
                    "Request success with status code: {} . TransactionId: {} ",
                    response.getStatusCode(),
                    transactionId);
        } catch (Exception ex) {
            throw new ORSDistException(
                    format("TransactionId:%s - Exception on posting requestBody: %s", transactionId, ex));
        }
    }

    /**
     * constructs http header based on provided event header
     *
     * @param eventHeader
     * @return
     */
    HttpHeaders getHttpHeaders(final BaseHeader eventHeader) throws Exception {
        final HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.set(TRANSACTIONID, eventHeader.getTransactionId().toString());
        httpHeaders.set(CORRELATIONID, eventHeader.getCorrelationId().toString());
        httpHeaders.set(PARTNER_CODE, eventHeader.getPartnerCode());
        if (eventHeader.getPartnerCode() != null && eventHeader.getPartnerCode().equalsIgnoreCase(BC) &&
                userAgent != null && !userAgent.equals("")) {
            log.info("Inside user- agent");
            httpHeaders.set(USER_AGENT_KEY, userAgent);
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        httpHeaders.set(
                EVENT_DATE_TIME,
                Objects.isNull(eventHeader.getEventDateTime())
                        ? ""
                        : eventHeader.getEventDateTime().format(formatter));


        getAuthenticationClient(eventHeader.getPartnerCode());
        httpHeaders.set(authenticationClient.getAuthorizationHeaderName(), authenticationClient.getAccessToken());
        return httpHeaders;
    }

    private void getAuthenticationClient(String partnerCode) throws InvalidClientException, CertificateException, KeyStoreException, JsonProcessingException {
        if (authenticationClient == null) {
            authenticationClient = authenticationClientFactory.getAuthenticationClient(partnerCode);
        }
    }

    protected abstract String getPartnerCodeConstants();

    protected abstract String getApplicationName();

    /**
     * Method to initialize Logger Context for ors lambda
     *
     * @param transactionId
     * @param context
     */
    protected void initializeLogger(final UUID transactionId, final Context context) {
        final CMDSLambdaLoggerUtil loggerUtil = new CMDSLambdaLoggerUtil();
        loggerUtil.initializeThreadContextMap(
                transactionId.toString(), getApplicationName(), context.getAwsRequestId());
    }
}
