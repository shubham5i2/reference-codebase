package com.ielts.cmds.integration.mapper;

import com.ielts.cmds.booking.common.out.model.TestTakerBanRemovedV1;
import com.ielts.cmds.integration.model.ORSTtBanRemovedResponse;

/**
 * This class is used to map incoming event to appropriate API request body
 */
public class EventMapper {

    public ORSTtBanRemovedResponse mapBanRemovedResponse(final TestTakerBanRemovedV1 testTakerBanRemovedV1) {
        final ORSTtBanRemovedResponse orsResponse = new ORSTtBanRemovedResponse();

        orsResponse.setBanUuid(testTakerBanRemovedV1.getBanUuid());
        orsResponse.setUniqueTestTakerUuid(testTakerBanRemovedV1.getUniqueTestTakerUuid());
        orsResponse.setUniqueTestTakerId(testTakerBanRemovedV1.getUniqueTestTakerId());

        return orsResponse;
    }
}
