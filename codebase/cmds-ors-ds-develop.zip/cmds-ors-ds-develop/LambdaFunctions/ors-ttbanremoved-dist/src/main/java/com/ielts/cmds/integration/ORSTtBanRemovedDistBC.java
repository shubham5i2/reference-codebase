package com.ielts.cmds.integration;


import com.ielts.cmds.integration.constants.DistORSConstants;

public class ORSTtBanRemovedDistBC extends ORSTtBanRemovedDist {

    @Override
    protected String getPartnerCodeConstants() {
        return DistORSConstants.BC;
    }

    @Override
    protected String getApplicationName() {
        return DistORSConstants.ORS_TTBANREMOVED_DIST_BC;
    }
}