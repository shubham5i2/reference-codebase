package com.ielts.cmds.integration;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.constants.DistORSConstants;
import com.ielts.cmds.integration.exception.ORSDistException;
import com.ielts.cmds.security.clients.BritishCouncilAuthenticationClient;
import com.ielts.cmds.security.clients.BritishCouncilChinaAuthenticationClient;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;
import org.junit.Rule;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.rules.ExpectedException;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.*;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ORSTtBanRemovedDistBCCHNTest {

    @Rule
    public final ExpectedException exceptionRule = ExpectedException.none();
    private final ObjectMapper objectMapper = SQSEventBodySetup.getMapper();

    @Mock private BritishCouncilChinaAuthenticationClient bcchnClient;

    @InjectMocks
    @Spy
    private ORSTtBanRemovedDistBCCHN orsTtBanRemovedDistBCCHN;

    @Mock
    private ObjectMapper mapper = new ObjectMapper();

    @Mock
    private EnvironmentAwareAuthenticationClientFactory authenticationClientFactory;

    @Spy
    private SQSEvent.SQSMessage message, messageInvalid, messageNull, messageInvalidPartner, headerNull;

    @Spy
    private SQSEvent event, eventInvalid, eventBodyNull, eventInvalidPartner, eventHeaderNull;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private Context context;

    @BeforeEach
    public void setUp() throws Exception {
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
        ReflectionTestUtils.setField(orsTtBanRemovedDistBCCHN, "authenticationClientFactory", authenticationClientFactory);
        ReflectionTestUtils.setField(orsTtBanRemovedDistBCCHN, "extCallbackUrl", "https://withdrawendpoint.orsdomain.com");
        ReflectionTestUtils.setField(orsTtBanRemovedDistBCCHN, "userAgent", "userAgent");

        String eventBody = SQSEventBodySetup.getEventBodyForBCCHN();
        message.setBody(eventBody);
        List<SQSEvent.SQSMessage> records = new ArrayList<>();
        records.add(message);
        event.setRecords(records);

        String eventBody2 = SQSEventBodySetup.getInvalidEventBodyForBCCHN();
        messageInvalid.setBody(eventBody2);
        List<SQSEvent.SQSMessage> records2 = new ArrayList<>();
        records2.add(messageInvalid);
        eventInvalid.setRecords(records2);

        String eventBody3 = SQSEventBodySetup.getEventBodyNullForBCCHN();
        messageNull.setBody(eventBody3);
        List<SQSEvent.SQSMessage> records3 = new ArrayList<>();
        records3.add(messageNull);
        eventBodyNull.setRecords(records3);

        String eventBody4 = SQSEventBodySetup.getEventBodyForIDP();
        messageInvalidPartner.setBody(eventBody4);
        List<SQSEvent.SQSMessage> records4 = new ArrayList<>();
        records4.add(messageInvalidPartner);
        eventInvalidPartner.setRecords(records4);

        String eventBody5 = SQSEventBodySetup.getEventHeaderNullForBCCHN();
        headerNull.setBody(eventBody5);
        List<SQSEvent.SQSMessage> records5 = new ArrayList<>();
        records5.add(headerNull);
        eventHeaderNull.setRecords(records5);

        String eventBody6 = SQSEventBodySetup.getEventBodyForBC();
        messageInvalidPartner.setBody(eventBody6);
        List<SQSEvent.SQSMessage> records6 = new ArrayList<>();
        records6.add(messageInvalidPartner);
        eventInvalidPartner.setRecords(records6);
    }

    @Test
    void getPartnerCodeConstants_whenGetPartnerCodeConstants_thenReturnBCCHN() {
        String partnerCodeConstants = orsTtBanRemovedDistBCCHN.getPartnerCodeConstants();
        assertEquals(DistORSConstants.BC_CHN, partnerCodeConstants);
    }

    @Test
    void getApplicationName_whenGetApplicationName_thenReturnInvalidApplicationNameForBCCHN() {
        String applicationName = orsTtBanRemovedDistBCCHN.getApplicationName();
        assertEquals(DistORSConstants.ORS_TTBANREMOVED_DIST_BCCHN, applicationName);
    }

    @Test
    void whenBCCHNRequestHasValidAuthenticationHeader_ThenVerifyCallToRestTemplate() throws Exception {
        // Prepare test data
        BaseEvent<?> baseEvent = objectMapper.readValue(message.getBody(), BaseEvent.class);
        Map<String, String> map = new HashMap<>();
        map.put(DistORSConstants.ACCESS_TOKEN,
                SQSEventBodySetup.getEnvironmentVariablesStub().get(DistORSConstants.ACCESS_TOKEN));
        map.put(DistORSConstants.AUTH_HEADER, DistORSConstants.AUTH_HEADER_NAME);

        ResponseEntity<String> orsResponse = new ResponseEntity<>(HttpStatus.ACCEPTED);
        HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
        eventHeaders.set(map.get(DistORSConstants.AUTH_HEADER), map.get(DistORSConstants.ACCESS_TOKEN));

        doReturn("authHeaderName").when(bcchnClient).getAuthorizationHeaderName();
        doReturn("accessToken").when(bcchnClient).getAccessToken();
        doReturn(restTemplate).when(bcchnClient).getRestTemplate();

        when(restTemplate.postForEntity(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpEntity.class),
                ArgumentMatchers.any(Class.class))).thenReturn(orsResponse);

        // Execute and assert test
        assertDoesNotThrow(() -> orsTtBanRemovedDistBCCHN.handleRequest(event, context));
    }

    @Test
    void whenBCCHNRequestHasInValidAuthenticationHeaderId_ThenThrowsException() {
        assertThrows(ORSDistException.class, () -> orsTtBanRemovedDistBCCHN.handleRequest(eventInvalid, context));
    }

    @Test
    void whenBCCHNRequestHasNullEventBody_ThenThrowException() throws Exception {
        assertThrows(ORSDistException.class, () -> orsTtBanRemovedDistBCCHN.handleRequest(eventBodyNull, context));
    }

    @Test
    void whenRequestIsInvalid_ThenThrowException() throws Exception {
        assertThrows(ORSDistException.class, () -> orsTtBanRemovedDistBCCHN.handleRequest(eventHeaderNull, context));
    }

    @Test
    void whenBCCHNRequestHasInValidAuthenticationHeader_ThenVerifyCallToRestTemplate() throws Exception {
        // Prepare test data
        BaseEvent<?> baseEvent = objectMapper.readValue(message.getBody(), BaseEvent.class);
        Map<String, String> map = new HashMap<>();
        map.put(DistORSConstants.ACCESS_TOKEN,
                SQSEventBodySetup.getEnvironmentVariablesStub().get(DistORSConstants.ACCESS_TOKEN));
        map.put(DistORSConstants.AUTH_HEADER, DistORSConstants.AUTH_HEADER_NAME);

        ResponseEntity<String> orsResponse = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        HttpHeaders eventHeaders = getHttpHeaders(baseEvent.getEventHeader());
        eventHeaders.set(map.get(DistORSConstants.AUTH_HEADER), map.get(DistORSConstants.ACCESS_TOKEN));

        doReturn("authHeaderName").when(bcchnClient).getAuthorizationHeaderName();
        doReturn("accessToken").when(bcchnClient).getAccessToken();
        doReturn(restTemplate).when(bcchnClient).getRestTemplate();

        when(restTemplate.postForEntity(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpEntity.class),
                ArgumentMatchers.any(Class.class))).thenReturn(orsResponse);

        // Execute and assert test
        assertThrows(ORSDistException.class, () -> orsTtBanRemovedDistBCCHN.handleRequest(event, context));
    }

    private HttpHeaders getHttpHeaders(BaseHeader eventHeader) {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.set(DistORSConstants.TRANSACTIONID, eventHeader.getTransactionId().toString());
        httpHeaders.set(DistORSConstants.CORRELATIONID, eventHeader.getCorrelationId().toString());
        httpHeaders.set(DistORSConstants.PARTNER_CODE, eventHeader.getPartnerCode());
        httpHeaders.set(com.ielts.cmds.security.constants.DistORSConstants.USER_AGENT_KEY, com.ielts.cmds.security.constants.DistORSConstants.USER_AGENT);
        return httpHeaders;
    }
}
