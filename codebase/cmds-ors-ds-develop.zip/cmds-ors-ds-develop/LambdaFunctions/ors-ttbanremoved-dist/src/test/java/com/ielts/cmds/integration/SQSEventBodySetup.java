package com.ielts.cmds.integration;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.booking.common.out.model.TestTakerBanRemovedV1;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static com.ielts.cmds.integration.constants.DistORSConstants.*;

public class SQSEventBodySetup {
    private static final ObjectMapper mapper = getMapper();

    public static String getEventBodyForBC() throws JsonProcessingException {
        BaseHeader eventHeader = getEventHeaderForBC();

        TestTakerBanRemovedV1 bannedDetails = getTtBanRemovedDetails();

        String eventBody = mapper.writeValueAsString(bannedDetails);

        BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
        cmdsEvent.setEventHeader(eventHeader);
        cmdsEvent.setEventBody(eventBody);
        cmdsEvent.setEventErrors(null);
        return mapper.writeValueAsString(cmdsEvent);
    }

    public static String getInvalidEventBodyForBC() {
        return "eventBody";
    }

    public static String getEventBodyNullForBC() throws JsonProcessingException {
        BaseHeader eventHeader = getEventHeaderForBC();

        BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
        cmdsEvent.setEventHeader(eventHeader);
        cmdsEvent.setEventBody(null);
        cmdsEvent.setEventErrors(null);
        return mapper.writeValueAsString(cmdsEvent);
    }

    public static String getEventHeaderNullForBC() throws JsonProcessingException {

        BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
        cmdsEvent.setEventHeader(null);
        cmdsEvent.setEventBody(null);
        cmdsEvent.setEventErrors(null);
        return mapper.writeValueAsString(cmdsEvent);
    }

    public static String getEventBodyForIDP() throws JsonProcessingException {
        BaseHeader eventHeader = getEventHeaderForIDP();

        TestTakerBanRemovedV1 bannedDetails = getTtBanRemovedDetails();

        String eventBody = mapper.writeValueAsString(bannedDetails);

        BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
        cmdsEvent.setEventHeader(eventHeader);
        cmdsEvent.setEventBody(eventBody);
        cmdsEvent.setEventErrors(null);
        return mapper.writeValueAsString(cmdsEvent);
    }

    public static String getInvalidEventBodyForIDP() {
        return "eventBody";
    }

    public static String getEventBodyNullForIDP() throws JsonProcessingException {
        BaseHeader eventHeader = getEventHeaderForIDP();

        TestTakerBanRemovedV1 bannedDetails = getTtBanRemovedDetails();

        BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
        cmdsEvent.setEventHeader(eventHeader);
        cmdsEvent.setEventBody(null);
        cmdsEvent.setEventErrors(null);
        return mapper.writeValueAsString(cmdsEvent);
    }
    public static String getEventBodyForBCCHN() throws JsonProcessingException {
        BaseHeader eventHeader = getEventHeaderForBCCHN();

        TestTakerBanRemovedV1 bannedDetails = getTtBanRemovedDetails();

        String eventBody = mapper.writeValueAsString(bannedDetails);

        BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
        cmdsEvent.setEventHeader(eventHeader);
        cmdsEvent.setEventBody(eventBody);
        cmdsEvent.setEventErrors(null);
        return mapper.writeValueAsString(cmdsEvent);
    }

    public static String getInvalidEventBodyForBCCHN() {
        return "eventBody";
    }

    public static String getEventBodyNullForBCCHN() throws JsonProcessingException {
        BaseHeader eventHeader = getEventHeaderForBCCHN();

        BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
        cmdsEvent.setEventHeader(eventHeader);
        cmdsEvent.setEventBody(null);
        cmdsEvent.setEventErrors(null);
        return mapper.writeValueAsString(cmdsEvent);
    }

    public static String getEventHeaderNullForBCCHN() throws JsonProcessingException {

        BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<BaseHeader>();
        cmdsEvent.setEventHeader(null);
        cmdsEvent.setEventBody(null);
        cmdsEvent.setEventErrors(null);
        return mapper.writeValueAsString(cmdsEvent);
    }

    protected static ObjectMapper getMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        return mapper;
    }

    public static BaseHeader getEventHeaderForBC() {
        BaseHeader eventHeader = new BaseHeader();
        eventHeader.setTransactionId(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
        eventHeader.setCallbackURL("http://35.178.179.164:8105/booking");
        eventHeader.setCorrelationId(UUID.fromString("779187f5-38ed-4e86-b311-050ffe394f81"));
        eventHeader.setPartnerCode("BC");
        eventHeader.setEventName("CMDSTtBanned");
//        eventHeader
        LocalDateTime eventDateTime =
                LocalDateTime.parse(
                        "2020-09-29T21:00:35.723Z",
                        DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
        eventHeader.setEventDateTime(eventDateTime);
        return eventHeader;
    }

    public static BaseHeader getEventHeaderForIDP() {
        BaseHeader eventHeader = new BaseHeader();
        eventHeader.setTransactionId(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
        eventHeader.setCallbackURL("http://35.178.179.164:8105/booking");
        eventHeader.setCorrelationId(UUID.fromString("779187f5-38ed-4e86-b311-050ffe394f81"));
        eventHeader.setPartnerCode("IDP");
        eventHeader.setEventName("CMDSTtBanned");
        LocalDateTime eventDateTime =
                LocalDateTime.parse(
                        "2020-09-29T21:00:35.723Z",
                        DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
        eventHeader.setEventDateTime(eventDateTime);
        return eventHeader;
    }
    public static BaseHeader getEventHeaderForBCCHN() {
        BaseHeader eventHeader = new BaseHeader();
        eventHeader.setTransactionId(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
        eventHeader.setCallbackURL("http://35.178.179.164:8105/booking");
        eventHeader.setCorrelationId(UUID.fromString("779187f5-38ed-4e86-b311-050ffe394f81"));
        eventHeader.setPartnerCode("BC_CHN");
        eventHeader.setEventName("CMDSTtBanned");
//        eventHeader
        LocalDateTime eventDateTime =
                LocalDateTime.parse(
                        "2020-09-29T21:00:35.723Z",
                        DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
        eventHeader.setEventDateTime(eventDateTime);
        return eventHeader;
    }

    public static Map<String, String> getEnvironmentVariablesStub() {
        Map<String, String> map = new HashMap<>();
        map.put(CLIENT_ID, "cmds-id");
        map.put(CLIENT_SECRET, "cmds-secret");
        map.put(ACCESS_TOKEN, "access-token");
        map.put("bc_auth_token_url", "BC_AUTH_URL");
        map.put(CALLBACK_URL, "https://wiremock.shared.cmdsiz.com/ors/invoke/booking");
        return map;
    }

    public static TestTakerBanRemovedV1 getTtBanRemovedDetails() {
        TestTakerBanRemovedV1 details = new TestTakerBanRemovedV1();
        details.setUniqueTestTakerUuid(UUID.fromString("9085badb-bb33-4032-8c4f-e8271406b235"));
        details.setBanUuid(UUID.fromString("9085badb-bb33-4032-8c4f-e8271406b236"));
        details.setUniqueTestTakerId("4TBJ23");
        return details;
    }
}
