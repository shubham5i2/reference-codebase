package com.ielts.cmds.integration.mapper;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.booking.common.out.model.TestTakerBanRemovedV1;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.SQSEventBodySetup;
import com.ielts.cmds.integration.model.ORSTtBanRemovedResponse;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

@RunWith(MockitoJUnitRunner.class)
public class EventMapperTest {

    @InjectMocks
    EventMapper eventMapper;

    @Mock
    TestTakerBanRemovedV1 details;

    @Spy
    private ObjectMapper mapper;

    @Before
    public void setUp() throws Exception {
        mapper = getMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);

        String sqsMsg = SQSEventBodySetup.getEventBodyForBC();
        BaseEvent<BaseHeader> cmdsEvent = mapper.readValue(sqsMsg, new TypeReference<BaseEvent<BaseHeader>>() {
        });
        details = mapper.readValue(cmdsEvent.getEventBody(), TestTakerBanRemovedV1.class);
    }

    @Test
    public void whenBannedCandidateDetailsProvided_ThenValidatedORSTtBannedResponse() {
        // when
        ORSTtBanRemovedResponse response = eventMapper.mapBanRemovedResponse(details);

        // then
        assertEquals(details.getBanUuid(), response.getBanUuid());
        assertEquals(details.getUniqueTestTakerId(), response.getUniqueTestTakerId());
        assertEquals(details.getUniqueTestTakerUuid(), response.getUniqueTestTakerUuid());
    }

    @Test
    public void whenBannedCandidateDetailsIsPassedWithNullValues_ThenVerifyORSTtBannedResponseForNullValues() {
        // Given
        details.setUniqueTestTakerUuid(null);
        details.setBanUuid(null);
        details.setUniqueTestTakerId(null);

        // when
        ORSTtBanRemovedResponse response = eventMapper.mapBanRemovedResponse(details);

        // then
        assertNull(response.getUniqueTestTakerUuid());
        assertNull(response.getBanUuid());
        assertNull(response.getUniqueTestTakerId());


    }

    @After
    public void tearDown() {
        details = null;
    }

    protected ObjectMapper getMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        return mapper;
    }
}
