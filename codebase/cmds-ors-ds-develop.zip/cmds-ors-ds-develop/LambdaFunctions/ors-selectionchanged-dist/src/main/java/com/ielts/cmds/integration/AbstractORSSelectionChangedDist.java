package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.constants.DistORSConstants.CORRELATION_ID;
import static com.ielts.cmds.integration.constants.DistORSConstants.EVENT_DATETIME;
import static com.ielts.cmds.integration.constants.DistORSConstants.EVENT_RECEIVED_IN_ORS;
import static com.ielts.cmds.integration.constants.DistORSConstants.EXCEPTION_WHILE_POSTING;
import static com.ielts.cmds.integration.constants.DistORSConstants.ORS_ENDPOINT_URL;
import static com.ielts.cmds.integration.constants.DistORSConstants.PARTNER_CODE;
import static com.ielts.cmds.integration.constants.DistORSConstants.PARTNER_CODE_MISMATCH;
import static com.ielts.cmds.integration.constants.DistORSConstants.TRANSACTION_ID;

import java.security.KeyStoreException;
import java.security.cert.CertificateException;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestClientException;

import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.common.logger.util.CMDSLambdaLoggerUtil;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.mapper.EventMapper;
import com.ielts.cmds.integration.model.OrganisationSelectionResponse;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.exception.InvalidClientException;
import com.ielts.cmds.security.exception.TokenNotReceivedException;
import com.ielts.cmds.security.factory.AuthenticationClientFactory;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class AbstractORSSelectionChangedDist {

    private final ObjectMapper mapper;
    private final AuthenticationClientFactory authenticationFactory;
    private final String externalCallbackUrl;
	private final EventMapper eventMapper;
	private final CMDSLambdaLoggerUtil loggerUtil;

    protected AbstractORSSelectionChangedDist() {
        this.eventMapper = new EventMapper();
		this.loggerUtil = new CMDSLambdaLoggerUtil();
		this.mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
        this.authenticationFactory = new EnvironmentAwareAuthenticationClientFactory();
        this.externalCallbackUrl = System.getenv(ORS_ENDPOINT_URL);
    }

    public void handleRequest(final SQSEvent input) {
        for (SQSEvent.SQSMessage message : input.getRecords()) {
            try {
                final BaseEvent<BaseHeader> event = getEvent(message.getBody());

                initializeLogger(event);

                log.info(
                    EVENT_RECEIVED_IN_ORS,
                    getApplicationName(),
                    event.getEventHeader(),
                    event.getEventErrors()
                );

                if (samePartnerCodeIn(event.getEventHeader().getPartnerCode())) {
                    publish(event);
                } else {
                	log.warn(
                            PARTNER_CODE_MISMATCH,
                            event.getEventHeader().getPartnerCode(),
                            getPartnerCodeConstants(),
                            event.getEventHeader().getTransactionId(),
                            event.getEventHeader().getEventName(),
                            event.getEventHeader().getCorrelationId()
                        );
                }
            } catch (
					RestClientException |
					TokenNotReceivedException |
					InvalidClientException |
					JsonProcessingException | CertificateException | KeyStoreException ex
					) {
				log.warn(EXCEPTION_WHILE_POSTING, ex);
			}
        }
    }


    boolean samePartnerCodeIn(final String partnerCode) {
		return getPartnerCodeConstants().equalsIgnoreCase(
				partnerCode
				);
	}

    BaseEvent<BaseHeader> getEvent(
			final String sqsMessage
			) throws JsonProcessingException {

		final TypeReference<BaseEvent<BaseHeader>> typeRef = new TypeReference<BaseEvent<BaseHeader>>() {
		};
		return mapper.readValue(sqsMessage, typeRef);
	}

    void publish(BaseEvent<BaseHeader> event) throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException, InvalidClientException {

    	OrganisationSelectionResponse response = new OrganisationSelectionResponse();

		if (event.getEventBody() != null) {
			final OrganisationSelectionNodeV1 request = mapper.readValue(
					event.getEventBody(),
					OrganisationSelectionNodeV1.class
					);
			response.setResponse(eventMapper.mapRequest(request));
		}

		response.setErrors(event.getEventErrors());

		postRequestToExternalAPI(event.getEventHeader(), response);
	}


	void postRequestToExternalAPI(
			final BaseHeader eventHeader,
			final OrganisationSelectionResponse payload) throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException, InvalidClientException {
		AuthenticationClient authentication = getAuthenticationClient(eventHeader.getPartnerCode());
		
		final HttpEntity<OrganisationSelectionResponse> entity = new HttpEntity<>(
				payload,
				getHttpHeaders(eventHeader, authentication)
				);
		authentication
				.getRestTemplate()
				.postForEntity(externalCallbackUrl, entity, String.class);
		log.info("Request completed by external endpoint with no exception for External Booking Uuid :{}", payload.getResponse().getExternalBookingUuid());


	}


	HttpHeaders getHttpHeaders(
			final BaseHeader eventHeader, final AuthenticationClient authentication
			) throws TokenNotReceivedException, InvalidClientException, CertificateException, KeyStoreException, JsonProcessingException {
		final HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		httpHeaders.set(TRANSACTION_ID, eventHeader.getTransactionId().toString());
		httpHeaders.set(CORRELATION_ID, eventHeader.getCorrelationId().toString());
		httpHeaders.set(PARTNER_CODE, eventHeader.getPartnerCode());
		httpHeaders.set(EVENT_DATETIME, eventHeader.getEventDateTimeAsString());
		httpHeaders.set(
				authentication.getAuthorizationHeaderName(),
				authentication.getAccessToken()
				);
		setAdditionalHttpHeaders(httpHeaders);
		return httpHeaders;
	}

	AuthenticationClient getAuthenticationClient(
			final String partnerCode
			) throws TokenNotReceivedException, InvalidClientException, CertificateException, KeyStoreException, JsonProcessingException {
		return authenticationFactory.getAuthenticationClient(partnerCode);
	}

	void initializeLogger(final BaseEvent<BaseHeader> event) {
		loggerUtil.initializeThreadContextMap(
				event.getEventHeader().getTransactionId().toString(),
				getApplicationName(),
				event.getEventHeader().getCorrelationId().toString(),
				event.getEventHeader().getEventContext()
				);
	}

	protected abstract void setAdditionalHttpHeaders(HttpHeaders httpHeaders);
	
    protected abstract String getPartnerCodeConstants();

    protected abstract String getApplicationName();

    
}