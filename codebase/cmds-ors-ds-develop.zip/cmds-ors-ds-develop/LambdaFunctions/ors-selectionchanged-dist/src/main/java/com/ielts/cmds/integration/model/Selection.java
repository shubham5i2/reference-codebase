package com.ielts.cmds.integration.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@NoArgsConstructor

public class Selection {

    private UUID selectionUuid;
    private UUID externalSelectionUuid;
}