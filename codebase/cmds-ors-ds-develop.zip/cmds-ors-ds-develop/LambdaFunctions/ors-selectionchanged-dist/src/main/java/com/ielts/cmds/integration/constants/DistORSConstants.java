package com.ielts.cmds.integration.constants;

public class DistORSConstants {

  private DistORSConstants() {}

  public static final String TRANSACTION_ID = "transactionId";
  public static final String CORRELATION_ID = "correlationId";
  public static final String PARTNER_CODE = "partnerCode";
  public static final String IDP = "IDP";
  public static final String BC = "BC";
  public static final String BC_CHN = "BC_CHN";

  public static final String ORS_ENDPOINT_URL= "endpoint_url";
  public static final String ORGANISATION_SELECTION_CHANGED = "OrganisationSelectionChanged";
  public static final String ORGANISATION_SELECTION_CHANGED_IDP = "ORSDSSelectionChangedDistIDP";
  public static final String ORGANISATION_SELECTION_CHANGED_BC = "ORSDSSelectionChangedDistBC";
  public static final String ORGANISATION_SELECTION_CHANGED_BCCHN = "ORSDSSelectionChangedDistBCCHN";

  public static final String EVENT_DATETIME = "eventDateTime";
  public static final String EVENT_RECEIVED_IN_ORS = "Event Received in ORS DS: {} with metadata as {} and error as {}";
  public static final String PARTNER_CODE_MISMATCH = "Not processing incoming message as partnerCode:{} does not match expected partner code:{} TransactionId:{} EventName:{} CorrelationId:{}";
  
  public static final String EXCEPTION_WHILE_POSTING = "Exception on posting requestBody: ";
  
  public static final String USER_AGENT = "user_agent";
  public static final String USER_AGENT_KEY = "User-Agent";
}