package com.ielts.cmds.integration.model;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class OrganisationSelectionResponse {

	private OrganisationSelection response;
	private BaseEventErrors errors;
}