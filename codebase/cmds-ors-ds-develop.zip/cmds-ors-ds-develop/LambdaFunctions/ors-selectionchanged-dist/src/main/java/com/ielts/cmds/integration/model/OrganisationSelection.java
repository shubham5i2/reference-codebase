package com.ielts.cmds.integration.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@NoArgsConstructor

public class OrganisationSelection {

    private UUID externalBookingUuid;
    private Selection selection;
}