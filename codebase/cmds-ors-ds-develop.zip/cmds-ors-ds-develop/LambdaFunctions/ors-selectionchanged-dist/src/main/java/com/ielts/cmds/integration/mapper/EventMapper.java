package com.ielts.cmds.integration.mapper;

import com.ielts.cmds.integration.model.OrganisationSelection;
import com.ielts.cmds.integration.model.Selection;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;

public class EventMapper {

    public OrganisationSelection mapRequest(
        final OrganisationSelectionNodeV1 request
    ) {
        OrganisationSelection event = new OrganisationSelection();
        event.setExternalBookingUuid(request.getBookingDetails().getExternalBookingUuid());

        Selection selection = new Selection();
        selection.setSelectionUuid(request.getSelection().getSelectionUuid());
        selection.setExternalSelectionUuid(request.getSelection().getExternalSelectionUuid());

        event.setSelection(selection);

        return event;
    }
}