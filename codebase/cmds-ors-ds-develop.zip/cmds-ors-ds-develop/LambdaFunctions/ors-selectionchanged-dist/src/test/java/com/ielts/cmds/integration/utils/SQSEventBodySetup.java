package com.ielts.cmds.integration.utils;

import static com.ielts.cmds.common.enums.ErrorTypeEnum.VALIDATION;
import static java.time.LocalDateTime.parse;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.model.OrganisationSelection;
import com.ielts.cmds.integration.model.OrganisationSelectionResponse;
import com.ielts.cmds.rd.domain.model.out.BookingNodeV1;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;
import com.ielts.cmds.rd.domain.model.out.SelectionNodeV1;

public class SQSEventBodySetup {

	private static final ObjectMapper mapper = mockMapper();


	public static ObjectMapper mockMapper() {
		ObjectMapper mapper = new ObjectMapper();
		mapper.registerModule(new JavaTimeModule());
		mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
		mapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
		mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
		mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
		mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		return mapper;
	}

	public static String mockEvent()
		throws JsonProcessingException {
		BaseHeader header = mockEventHeader();

		String body = mapper.writeValueAsString(eventBody());

		BaseEventErrors error = new BaseEventErrors(mockErrors());

		return mapper.writeValueAsString(baseEvent(header, body, error));
	}

	public static OrganisationSelection mockPayload() {
		OrganisationSelection entity = new OrganisationSelection();
		entity.setExternalBookingUuid(UUID.randomUUID());
		return entity;
	}
	
	public static OrganisationSelectionResponse mockEntityPayload() {
		OrganisationSelectionResponse entity = new OrganisationSelectionResponse();
		OrganisationSelection response = mockPayload();
		entity.setResponse(response);
		return entity;
	}

	private static BaseHeader mockEventHeader() {
		BaseHeader eventHeader = new BaseHeader();
		eventHeader.setTransactionId(UUID.randomUUID());
		eventHeader.setCallbackURL("test");
		eventHeader.setCorrelationId(UUID.randomUUID());
		eventHeader.setPartnerCode("test");
		eventHeader.setEventName("test");
		eventHeader.setEventDateTime(parse(
				"2020-09-29T21:00:35.723Z",
				DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
		));
		return eventHeader;
	}


	public static List<ErrorDescription> mockErrors() {
		List<ErrorDescription> errorList = new ArrayList<>();
		ErrorDescription description = new ErrorDescription();
		description.setInterfaceName("SelectionNodeV1");
		description.setType(VALIDATION);
		description.setErrorCode("1234");
		Source source = Source.builder().value("").path("product_uuid").build();
		description.setSource(source);
		errorList.add(description);
		return errorList;
	}

	public static BaseEvent<BaseHeader> baseEvent(
		BaseHeader header,
		String body,
		BaseEventErrors error
	) {
		BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
		baseEvent.setEventHeader(header);
		baseEvent.setEventBody(body);
		baseEvent.setEventErrors(error);
		return baseEvent;
	}

	public static OrganisationSelectionNodeV1 eventBody() {
		OrganisationSelectionNodeV1 event = new OrganisationSelectionNodeV1();
		BookingNodeV1 booking = new BookingNodeV1();
		booking.setExternalBookingUuid(UUID.randomUUID());
		booking.setBookingUuid(UUID.randomUUID());

		SelectionNodeV1 selectionNodeV1 = new SelectionNodeV1();
		selectionNodeV1.setSelectionUuid(UUID.randomUUID());
		selectionNodeV1.setExternalSelectionUuid(UUID.randomUUID());

		event.setSelection(selectionNodeV1);
		event.setBookingDetails(booking);
		return event;
	}
}