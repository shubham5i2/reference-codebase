package com.ielts.cmds.integration.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.integration.model.OrganisationSelection;
import com.ielts.cmds.integration.utils.SQSEventBodySetup;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;

@ExtendWith(MockitoExtension.class)
class EventMapperTest {
	
	@InjectMocks private EventMapper mapper;
	
	@Test
	void mapRequest_ExpectResponse() {
		OrganisationSelectionNodeV1 request = SQSEventBodySetup.eventBody();
		OrganisationSelection actual = mapper.mapRequest(request);
		assertEquals(request.getBookingDetails().getExternalBookingUuid(), actual.getExternalBookingUuid());
		assertEquals(request.getSelection().getExternalSelectionUuid(), actual.getSelection().getExternalSelectionUuid());
		assertEquals(request.getSelection().getSelectionUuid(), actual.getSelection().getSelectionUuid());
	}

}
