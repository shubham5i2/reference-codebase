package com.ielts.cmds.integration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;

import com.ielts.cmds.integration.constants.DistORSConstants;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
class ORSSelectionChangedDistBCTest {
	
@InjectMocks private ORSSelectionChangedDistBC orsSelectionChangedDistBC;
	
	@Test
	void getPartnerCodeConstants_thenReturnBCCHN() {
		assertEquals(DistORSConstants.BC, orsSelectionChangedDistBC.getPartnerCodeConstants());
	}

	@Test
	void getApplicationName_thenReturnBCCHN() {
		assertEquals(DistORSConstants.ORGANISATION_SELECTION_CHANGED_BC, orsSelectionChangedDistBC.getApplicationName());
	}
	
	@Test
	@SneakyThrows
	void setAdditionalHttpHeaders() {
		HttpHeaders httpHeaders = new HttpHeaders();
		orsSelectionChangedDistBC.setAdditionalHttpHeaders(httpHeaders);
		assertNotNull(httpHeaders.get(DistORSConstants.USER_AGENT_KEY));
	}

}
