package com.ielts.cmds.integration;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;

import java.security.KeyStoreException;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.amazonaws.services.lambda.runtime.events.SQSEvent.SQSMessage;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.logger.util.CMDSLambdaLoggerUtil;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.constants.DistORSConstants;
import com.ielts.cmds.integration.mapper.EventMapper;
import com.ielts.cmds.integration.model.OrganisationSelection;
import com.ielts.cmds.integration.model.OrganisationSelectionResponse;
import com.ielts.cmds.integration.utils.SQSEventBodySetup;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.exception.InvalidClientException;
import com.ielts.cmds.security.exception.TokenNotReceivedException;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;

@ExtendWith(MockitoExtension.class)
class AbstractORSSelectionChangedDistTest {
	
	private AbstractORSSelectionChangedDist orsSelectionChangedDist;

	@Mock private RestTemplate restTemplate;
	@Mock private EventMapper eventMapper;
	@Mock private EnvironmentAwareAuthenticationClientFactory authenticationFactory;

	@Mock private AuthenticationClient authenticationClient;

	@Mock private CMDSLambdaLoggerUtil loggerUtil;

	@Captor private ArgumentCaptor<OrganisationSelectionResponse> responseCaptor;

	@Captor private ArgumentCaptor<BaseHeader> headerCaptor;
	
	@Captor private ArgumentCaptor<String> urlCaptor;
	
	@Captor private ArgumentCaptor<HttpEntity<OrganisationSelectionResponse>> httpEntityCaptor;
	
	@Captor private ArgumentCaptor<Class<?>> responseTypeCaptor;
	
	private SQSEvent input;
	
	private ObjectMapper mapper;
	
	private BaseEvent<BaseHeader> event;
	
	private String messageBody;

	private OrganisationSelectionNodeV1 request;

	private OrganisationSelection payload;

	private OrganisationSelectionResponse entityPayload;

	private HttpHeaders httpHeaders;

	private ResponseEntity<String> httpResponse;

	private String externalCallbackUrl;

	@BeforeEach
	void setup() throws JsonProcessingException {
		AbstractORSSelectionChangedDist orsSelectionWithdrawnDistMock = new AbstractORSSelectionChangedDist() {
			
			@Override
			protected void setAdditionalHttpHeaders(HttpHeaders httpHeaders) {
				
				
			}
			
			@Override
			protected String getPartnerCodeConstants() {
				return "test";
			}
			
			@Override
			protected String getApplicationName() {
				return "test";
			}
		};
		orsSelectionChangedDist = spy(orsSelectionWithdrawnDistMock);
		input = new SQSEvent();
				
		List<SQSMessage> records = new ArrayList<>();
		SQSMessage message = new SQSMessage();
		messageBody = SQSEventBodySetup.mockEvent();
		message.setBody(messageBody);
		records.add(message);
        input.setRecords(records);
        mapper = SQSEventBodySetup.mockMapper();
        final TypeReference<BaseEvent<BaseHeader>> typeRef = new TypeReference<BaseEvent<BaseHeader>>() {
        };
        
        externalCallbackUrl = "url";

        event = mapper.readValue(messageBody, typeRef);
        entityPayload = SQSEventBodySetup.mockEntityPayload();
        
        payload = entityPayload.getResponse();
        
        entityPayload = SQSEventBodySetup.mockEntityPayload();
        
        httpHeaders = new HttpHeaders();
        
        httpResponse = new ResponseEntity<>(HttpStatus.OK);
        request = mapper.readValue(event.getEventBody(), OrganisationSelectionNodeV1.class);

	}
	
	@Test
	void handleRequest_ExpectPublishMethodToBeCalled() throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException, InvalidClientException {
		doReturn(event).when(orsSelectionChangedDist).getEvent(messageBody);
		doNothing().when(orsSelectionChangedDist).initializeLogger(event);
		doReturn(true).when(orsSelectionChangedDist).samePartnerCodeIn("test");
		doNothing().when(orsSelectionChangedDist).publish(event);
		assertDoesNotThrow(()->orsSelectionChangedDist.handleRequest(input));
		verify(orsSelectionChangedDist).publish(event);
		verify(orsSelectionChangedDist).initializeLogger(event);
		
	}
	
	@Test
	void handleRequestWithDifferentPartnerCode_ExpectPostRequestMethodToBeCalled() throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException, InvalidClientException {
		doReturn(event).when(orsSelectionChangedDist).getEvent(messageBody);
		doNothing().when(orsSelectionChangedDist).initializeLogger(event);
		doReturn(false).when(orsSelectionChangedDist).samePartnerCodeIn("test");
		assertDoesNotThrow(()->orsSelectionChangedDist.handleRequest(input));
		verify(orsSelectionChangedDist, never()).publish(event);
		verify(orsSelectionChangedDist).initializeLogger(event);
		
	}
	
	@ParameterizedTest
	@MethodSource("getTestDataException")
	void handleRequestThrowsException_ExpectNoException(Class<Exception> exception) throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException, InvalidClientException {
		doReturn(event).when(orsSelectionChangedDist).getEvent(messageBody);
		doNothing().when(orsSelectionChangedDist).initializeLogger(event);
		doReturn(true).when(orsSelectionChangedDist).samePartnerCodeIn("test");
		doThrow(exception).when(orsSelectionChangedDist).publish(event);
		assertDoesNotThrow(()->orsSelectionChangedDist.handleRequest(input));
		verify(orsSelectionChangedDist).publish(event);
		verify(orsSelectionChangedDist).initializeLogger(event);
	}
	
	@Test
	void samePartnerCodeIn_ExpectTrue() {
		assertTrue(orsSelectionChangedDist.samePartnerCodeIn("test"));
	}
	
	@Test
	void samePartnerCodeIn_ExpectFalse() {
		assertFalse(orsSelectionChangedDist.samePartnerCodeIn("IDDD"));
	}
	
	@Test
	void getEvent_ExpectEventToBeReturned() throws JsonProcessingException {
		assertEquals(event, orsSelectionChangedDist.getEvent(messageBody));
	}
	
	@Test
	void publish_ExpectPostRequestMethodToBeCalled() throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException, InvalidClientException {
		ReflectionTestUtils.setField(orsSelectionChangedDist, "eventMapper", eventMapper);
		doReturn(payload).when(eventMapper).mapRequest(request);
		doNothing().when(orsSelectionChangedDist).postRequestToExternalAPI(eq(event.getEventHeader()), any());
		assertDoesNotThrow(()->orsSelectionChangedDist.publish(event));
		verify(orsSelectionChangedDist).postRequestToExternalAPI(headerCaptor.capture(), responseCaptor.capture());
		OrganisationSelectionResponse actual = responseCaptor.getValue();
		assertEquals(payload, actual.getResponse());
		assertEquals(event.getEventErrors(), actual.getErrors());
		assertEquals(event.getEventHeader(), headerCaptor.getValue());
	}
	
	@Test
	void publishWithNullBody_ExpectPostRequestMethodToBeCalled() throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException, InvalidClientException {
		ReflectionTestUtils.setField(orsSelectionChangedDist, "eventMapper", eventMapper);
		event.setEventBody(null);
		doNothing().when(orsSelectionChangedDist).postRequestToExternalAPI(eq(event.getEventHeader()), any());
		assertDoesNotThrow(()->orsSelectionChangedDist.publish(event));
		verify(orsSelectionChangedDist).postRequestToExternalAPI(headerCaptor.capture(), responseCaptor.capture());
		OrganisationSelectionResponse actual = responseCaptor.getValue();
		assertNull(actual.getResponse());
		assertEquals(event.getEventErrors(), actual.getErrors());
		assertEquals(event.getEventHeader(), headerCaptor.getValue());
	}
	
	@Test
	void postRequestToExternalAPI_ExpectRestTemplateCall() throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException, InvalidClientException {
		ReflectionTestUtils.setField(orsSelectionChangedDist, "externalCallbackUrl", externalCallbackUrl);
		doReturn(authenticationClient).when(orsSelectionChangedDist).getAuthenticationClient("test");
		doReturn(httpHeaders).when(orsSelectionChangedDist).getHttpHeaders(event.getEventHeader(), authenticationClient);
		doReturn(restTemplate).when(authenticationClient).getRestTemplate();
		doReturn(httpResponse).when(restTemplate).postForEntity(eq(externalCallbackUrl), any(HttpEntity.class), eq(String.class));
		assertDoesNotThrow(()->orsSelectionChangedDist.postRequestToExternalAPI(event.getEventHeader(), entityPayload));
		verify(restTemplate).postForEntity(urlCaptor.capture(), httpEntityCaptor.capture(), responseTypeCaptor.capture());
		assertEquals(externalCallbackUrl, urlCaptor.getValue());
		assertEquals(entityPayload, httpEntityCaptor.getValue().getBody());
		assertEquals(String.class, responseTypeCaptor.getValue());
	}
	
	@Test
	void getAuthenticationClient_ExpectObject() throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException, InvalidClientException {
		ReflectionTestUtils.setField(orsSelectionChangedDist, "authenticationFactory", authenticationFactory);
		doReturn(authenticationClient).when(authenticationFactory).getAuthenticationClient("test");
		assertEquals(authenticationClient, orsSelectionChangedDist.getAuthenticationClient("test"));
	}
	
	@Test
	void initializeLogger_ExpectLoggerToBeSet() {
		ReflectionTestUtils.setField(orsSelectionChangedDist, "loggerUtil", loggerUtil);
		assertDoesNotThrow(()->orsSelectionChangedDist.initializeLogger(event));
		verify(loggerUtil).initializeThreadContextMap(event.getEventHeader().getTransactionId().toString(), 
				"test", event.getEventHeader().getCorrelationId().toString(), 
				event.getEventHeader().getEventContext());
	}
	
	@Test
	void setHttpHeaders_ExpectHeadersToBeSet() throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException, InvalidClientException {
		doReturn("testHeaderName").when(authenticationClient).getAuthorizationHeaderName();
		doReturn("token").when(authenticationClient).getAccessToken();
		HttpHeaders actual = orsSelectionChangedDist.getHttpHeaders(event.getEventHeader(), authenticationClient);
		assertEquals(event.getEventHeader().getTransactionId().toString(), actual.get(DistORSConstants.TRANSACTION_ID).get(0));
		assertEquals(event.getEventHeader().getCorrelationId().toString(), actual.get(DistORSConstants.CORRELATION_ID).get(0));
		assertEquals("token", actual.get("testHeaderName").get(0));
	}
	
	static Stream<Arguments> getTestDataException() {
		return Stream.of(
				Arguments.of(JsonProcessingException.class),
				Arguments.of(CertificateException.class),
				Arguments.of(KeyStoreException.class),
				Arguments.of(TokenNotReceivedException.class));
	}
	

}
