package com.ielts.cmds.integration.mapper;

import com.ielts.cmds.booking.common.out.model.BookingUnbanV1;
import com.ielts.cmds.ors.common.integration.int475.BookingUnban;

/**
 * This class is used to map incoming event to appropriate API request body
 */
public class EventMapper {

    public BookingUnban mapBookingUnbannedResponse(final BookingUnbanV1 bookingUnbanV1) {
        final BookingUnban orsResponse = new BookingUnban();

        orsResponse.setExternalBookingUuid(bookingUnbanV1.getExternalBookingUuid().toString());
        orsResponse.setTestDate(bookingUnbanV1.getTestDate());
        orsResponse.setUniqueTestTakerUuid(bookingUnbanV1.getUniqueTestTakerUuid().toString());
        orsResponse.setBanUuid(bookingUnbanV1.getBanUuid().toString());

        return orsResponse;
    }
}
