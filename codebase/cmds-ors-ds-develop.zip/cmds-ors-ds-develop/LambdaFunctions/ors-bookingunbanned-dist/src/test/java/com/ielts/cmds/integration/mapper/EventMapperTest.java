package com.ielts.cmds.integration.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.booking.common.out.model.BookingUnbanV1;
import com.ielts.cmds.integration.SQSEventBodySetup;
import com.ielts.cmds.ors.common.integration.int475.BookingUnban;

@ExtendWith(MockitoExtension.class)
class EventMapperTest {

	@Spy @InjectMocks private EventMapper eventMapper;

	private BookingUnbanV1 bookingUnBanV1;

	@BeforeEach
	void setUp() {
		bookingUnBanV1 = SQSEventBodySetup.getBookingUnbannedDetails();
	}
	
	@Test
	void mapBannedResponse_ExpectMappedResponse() {
		BookingUnban actual = eventMapper.mapBookingUnbannedResponse(bookingUnBanV1);
		assertEquals(bookingUnBanV1.getExternalBookingUuid().toString(), actual.getExternalBookingUuid());
		assertEquals(bookingUnBanV1.getUniqueTestTakerUuid().toString(), actual.getUniqueTestTakerUuid());
		assertEquals(bookingUnBanV1.getBanUuid().toString(), actual.getBanUuid());
		assertEquals(bookingUnBanV1.getTestDate(), actual.getTestDate());
	}
	
}