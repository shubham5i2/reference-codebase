package com.ielts.cmds.integration;

import java.time.LocalDate;
import java.util.UUID;

import org.springframework.http.HttpHeaders;

import com.ielts.cmds.booking.common.out.model.BookingUnbanV1;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

public class SQSEventBodySetup {
	public static void setHeaderContext() {
		HeaderContext context = new HeaderContext();
		context.setCorrelationId(UUID.randomUUID());
		context.setTransactionId(UUID.randomUUID());
		context.setPartnerCode("test");
		ThreadLocalHeaderContext.setContext(context);

	}
	
	public static HttpHeaders getHttpHeaders() {
		HttpHeaders httpHeaders = new HttpHeaders();
		return httpHeaders;

	}

    public static BookingUnbanV1 getBookingUnbannedDetails() {
        BookingUnbanV1 details = new BookingUnbanV1();
        details.setUniqueTestTakerUuid(UUID.fromString("9085badb-bb33-4032-8c4f-e8271406b235"));
        details.setPartnerCode("IDP");
        details.setTestDate(LocalDate.now());
        details.setBookingUuid(UUID.fromString("9085badb-bb33-4032-8c4f-e8271406b235"));
        details.setExternalBookingUuid(UUID.fromString("9085badb-bb33-4032-8c4f-e8271406b235"));
        details.setBanUuid(UUID.fromString("9085badb-bb33-4032-8c4f-e8271406b235"));
        return details;
    }
}
