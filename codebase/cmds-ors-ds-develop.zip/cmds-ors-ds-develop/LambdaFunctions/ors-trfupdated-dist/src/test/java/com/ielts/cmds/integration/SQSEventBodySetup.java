package com.ielts.cmds.integration;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.http.HttpHeaders;

import com.ielts.cmds.api.evt004.ResultDeliveryBookingLineNodeV1;
import com.ielts.cmds.api.evt004.ResultDeliveryBookingNodeV1;
import com.ielts.cmds.api.evt004.ResultLineNodeV1;
import com.ielts.cmds.api.evt004.ResultNodeV1;
import com.ielts.cmds.api.evt004.ResultReleasedNodeV1;
import com.ielts.cmds.api.evt004.ResultRenditionNodeV1;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

public class SQSEventBodySetup {
	
	public static void setHeaderContext() {
		HeaderContext context = new HeaderContext();
		context.setCorrelationId(UUID.randomUUID());
		context.setTransactionId(UUID.randomUUID());
		context.setPartnerCode("test");
		ThreadLocalHeaderContext.setContext(context);

	}
	
	public static HttpHeaders getHttpHeaders() {
		HttpHeaders httpHeaders = new HttpHeaders();
		return httpHeaders;

	}
	
	public static ResultReleasedNodeV1 getResultReleasedNodeV1() {
        ResultReleasedNodeV1 resultReleasedNodeV1 = new ResultReleasedNodeV1();

        ResultDeliveryBookingNodeV1 booking = new ResultDeliveryBookingNodeV1();
        booking.setExternalBookingUuid(UUID.randomUUID());

        ResultNodeV1 results = new ResultNodeV1();
        results.setResultUuid(UUID.randomUUID());
        results.setResultTypeUuid(UUID.randomUUID());
        results.setTrfNumber("TRF001");
        results.setResultScore(6.5F);
        results.setAbsence(false);
        results.setAdministratorComments("admin comment");
        results.setCefrLevel("B1");

        List<ResultLineNodeV1> resultLines = new ArrayList<>();
        List<ResultDeliveryBookingLineNodeV1> bookingLines = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            ResultLineNodeV1 resultLine = new ResultLineNodeV1();
            resultLine.setResultLineUuid(UUID.randomUUID());
            resultLine.setBookingLineUuid(UUID.randomUUID());
            resultLine.setResultLineScore(8.5F);
            resultLine.setAbsence(false);
            resultLines.add(resultLine);

            ResultDeliveryBookingLineNodeV1 bookingLine = new ResultDeliveryBookingLineNodeV1();
            bookingLine.setComponentName("L");
            bookingLine.setBookingLineUuid(resultLine.getBookingLineUuid());
            bookingLine.setExternalBookingLineUuid(UUID.randomUUID());
            bookingLines.add(bookingLine);
        }
        List<ResultRenditionNodeV1> resultRenditions = new ArrayList<>();
        ResultRenditionNodeV1 resultRendition = new ResultRenditionNodeV1();
        resultRendition.setResultsRenditionUuid(UUID.randomUUID());
        resultRendition.setRenditionTypeUuid(UUID.randomUUID());
        resultRendition.setRenditionFilePath("index.html");
        resultRenditions.add(resultRendition);
        results.setResultRenditions(resultRenditions);
        results.setResultLines(resultLines);
        booking.setBookingLines(bookingLines);
        resultReleasedNodeV1.setBookingDetails(booking);
        resultReleasedNodeV1.setResultDetails(results);

        return resultReleasedNodeV1;
    }

    
}
