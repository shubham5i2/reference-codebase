package com.ielts.cmds.integration.mapper;

import static com.ielts.cmds.integration.constants.DistORSConstants.PRESIGN_TIMEOUT;
import static com.ielts.cmds.integration.constants.DistORSConstants.TRF_BUCKET;
import static com.ielts.cmds.integration.constants.DistORSConstants.REGION;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doReturn;

import java.net.URL;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.api.evt004.ResultDeliveryBookingLineNodeV1;
import com.ielts.cmds.api.evt004.ResultLineNodeV1;
import com.ielts.cmds.api.evt004.ResultReleasedNodeV1;
import com.ielts.cmds.api.evt004.ResultRenditionNodeV1;
import com.ielts.cmds.integration.SQSEventBodySetup;
import com.ielts.cmds.ors.common.integration.int261.ResultLine;
import com.ielts.cmds.ors.common.integration.int261.ResultRendition;
import com.ielts.cmds.ors.common.integration.int261.ResultsUpdate;

import software.amazon.awssdk.services.s3.presigner.S3Presigner;
import software.amazon.awssdk.services.s3.presigner.model.GetObjectPresignRequest;
import software.amazon.awssdk.services.s3.presigner.model.PresignedGetObjectRequest;
import uk.org.webcompere.systemstubs.environment.EnvironmentVariables;
import uk.org.webcompere.systemstubs.jupiter.SystemStub;
import uk.org.webcompere.systemstubs.jupiter.SystemStubsExtension;

@ExtendWith(MockitoExtension.class)
@ExtendWith(SystemStubsExtension.class)
class EventMapperTest {

	@Spy @InjectMocks private EventMapper eventMapper;

	private ResultReleasedNodeV1 releasedNodeV1;

	@SystemStub private EnvironmentVariables env;

	@Mock private URL url;
	@Mock private S3Presigner presigner;

	@Mock private PresignedGetObjectRequest presignedGetObjectRequest;

	@BeforeEach
	void setUp() {
		env.set(PRESIGN_TIMEOUT,"200");
		env.set(TRF_BUCKET,"test");
		env.set(REGION, "eu-west-2");
		releasedNodeV1 = SQSEventBodySetup.getResultReleasedNodeV1();
	}

	@Test
	void mapResponse_ExpectObject() {
		doReturn("test.com").when(eventMapper).generatePresignedUrl(releasedNodeV1.getResultDetails().getResultRenditions().get(0).getRenditionFilePath());
		ResultsUpdate actual = eventMapper.mapResponse(releasedNodeV1);
		assertEquals(releasedNodeV1.getBookingDetails().getExternalBookingUuid().toString(), actual.getExternalBookingUuid());
		assertEquals(releasedNodeV1.getResultDetails().getTrfNumber(), actual.getTrfNumber());
		assertEquals(releasedNodeV1.getResultDetails().getCefrLevel(), actual.getCefrLevel().getValue());
		assertEquals(releasedNodeV1.getResultDetails().getResultUuid().toString(), actual.getResultUuid());
		assertEquals(releasedNodeV1.getResultDetails().getResultTypeUuid().toString(), actual.getResultTypeUuid());
		assertEquals(releasedNodeV1.getResultDetails().getResultScore().toString(), actual.getResultOverallScore());
		assertEquals(releasedNodeV1.getResultDetails().getAbsence(), actual.getAbsence());
		assertEquals(releasedNodeV1.getResultDetails().getAdministratorComments(), actual.getAdministratorComments());
		assertFalse(actual.getResultLines().isEmpty());
		assertFalse(actual.getResultRenditions().isEmpty());
	}
	
	@Test
	void mapResponseWithNullRendition_ExpectObject() {
		releasedNodeV1.getResultDetails().setResultRenditions(null);
		ResultsUpdate actual = eventMapper.mapResponse(releasedNodeV1);
		assertEquals(releasedNodeV1.getBookingDetails().getExternalBookingUuid().toString(), actual.getExternalBookingUuid());
		assertEquals(releasedNodeV1.getResultDetails().getTrfNumber(), actual.getTrfNumber());
		assertEquals(releasedNodeV1.getResultDetails().getCefrLevel(), actual.getCefrLevel().getValue());
		assertEquals(releasedNodeV1.getResultDetails().getResultUuid().toString(), actual.getResultUuid());
		assertEquals(releasedNodeV1.getResultDetails().getResultTypeUuid().toString(), actual.getResultTypeUuid());
		assertEquals(releasedNodeV1.getResultDetails().getResultScore().toString(), actual.getResultOverallScore());
		assertEquals(releasedNodeV1.getResultDetails().getAbsence(), actual.getAbsence());
		assertEquals(releasedNodeV1.getResultDetails().getAdministratorComments(), actual.getAdministratorComments());
		assertFalse(actual.getResultLines().isEmpty());
		assertEquals(releasedNodeV1.getResultDetails().getPublishedTime(), actual.getPublicationRequestedDateTime());
		assertTrue(actual.getResultRenditions().isEmpty());
	}
	
	@Test
	void mapLines_ExpectObject() {
		List<ResultLine> actual = eventMapper.setResultLines(releasedNodeV1.getResultDetails().getResultLines(), releasedNodeV1.getBookingDetails().getBookingLines());
		ResultLineNodeV1 expectedResultLine = releasedNodeV1.getResultDetails().getResultLines().get(0);
		ResultDeliveryBookingLineNodeV1 expectedBookingLine = releasedNodeV1.getBookingDetails().getBookingLines().get(0);
		assertFalse(actual.isEmpty());
		ResultLine actualResultLine = actual.get(0);
		assertEquals(expectedResultLine.getAbsence(), actualResultLine.getAbsence());
		assertEquals(expectedResultLine.getResultLineScore(), actualResultLine.getResultLineScore());
		assertEquals(expectedResultLine.getResultLineUuid().toString(), actualResultLine.getResultLineUuid());
		assertEquals(ResultLine.ComponentEnum.L, actualResultLine.getComponent());
		assertEquals(expectedBookingLine.getExternalBookingLineUuid().toString(), actualResultLine.getExternalBookingLineUuid());
		
	}
	
	@Test
	void mapRenditions_ExpectObject() {
		doReturn("test.com").when(eventMapper).generatePresignedUrl(releasedNodeV1.getResultDetails().getResultRenditions().get(0).getRenditionFilePath());
		List<ResultRendition> actual = eventMapper.setResultRenditionList(releasedNodeV1.getResultDetails().getResultRenditions());
		ResultRenditionNodeV1 expectedRendition = releasedNodeV1.getResultDetails().getResultRenditions().get(0);
		assertFalse(actual.isEmpty());
		ResultRendition actualRendition = actual.get(0);
		assertEquals(expectedRendition.getResultsRenditionUuid().toString(), actualRendition.getResultsRenditionUuid());
		assertEquals(expectedRendition.getRenditionFileVersion(), actualRendition.getRenditionVersion());
		assertEquals(expectedRendition.getRenditionTypeUuid().toString(), actualRendition.getRenditionTypeUuid());
		assertEquals(expectedRendition.getRenditionDescription(), actualRendition.getRenditionDescription());
		assertEquals("test.com", actualRendition.getRenditionUrl());
		
	}

	@Test
	void generatePresignedUrl_ExpectUrl() {
		doReturn(presigner).when(eventMapper).getPresigner();
		doReturn(presignedGetObjectRequest).when(presigner).presignGetObject(ArgumentMatchers.any(GetObjectPresignRequest.class));
		doReturn(url).when(presignedGetObjectRequest).url();
		doReturn("url.com").when(url).toString();
		assertEquals("url.com", eventMapper.generatePresignedUrl("file.pdf"));
	}

	@Test
	void getPresigner_ExpectObject() {
		assertNotNull(eventMapper.getPresigner());
	}

}
