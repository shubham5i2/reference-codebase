package com.ielts.cmds.integration.mapper;

import static com.ielts.cmds.integration.constants.DistORSConstants.*;

import java.time.Duration;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import com.ielts.cmds.api.evt004.ResultDeliveryBookingLineNodeV1;
import com.ielts.cmds.api.evt004.ResultLineNodeV1;
import com.ielts.cmds.api.evt004.ResultReleasedNodeV1;
import com.ielts.cmds.api.evt004.ResultRenditionNodeV1;
import com.ielts.cmds.ors.common.integration.int261.ResultLine;
import com.ielts.cmds.ors.common.integration.int261.ResultRendition;
import com.ielts.cmds.ors.common.integration.int261.ResultsUpdate;

import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.presigner.S3Presigner;
import software.amazon.awssdk.services.s3.presigner.model.GetObjectPresignRequest;
import software.amazon.awssdk.services.s3.presigner.model.PresignedGetObjectRequest;

/**
 * This class is used to map incoming event to appropriate API request body
 */
@Slf4j
public class EventMapper {


    public ResultsUpdate mapResponse(ResultReleasedNodeV1 request) {

    	ResultsUpdate event = new ResultsUpdate();
        event.setExternalBookingUuid(request.getBookingDetails().getExternalBookingUuid().toString());
        event.setTrfNumber(request.getResultDetails().getTrfNumber());
        event.setResultUuid(request.getResultDetails().getResultUuid().toString());
        event.setResultTypeUuid(request.getResultDetails().getResultTypeUuid().toString());
        event.setCefrLevel(ResultsUpdate.CefrLevelEnum.fromValue(request.getResultDetails().getCefrLevel()));
        event.setResultOverallScore(request.getResultDetails().getResultScore().toString());
        event.setAbsence(request.getResultDetails().getAbsence());
        event.setPublicationRequestedDateTime(request.getResultDetails().getPublishedTime());
        event.setAdministratorComments(request.getResultDetails().getAdministratorComments());
        event.setResultLines(setResultLines(request.getResultDetails().getResultLines(), request.getBookingDetails().getBookingLines()));
        if (Objects.nonNull(request.getResultDetails().getResultRenditions())) {
            event.setResultRenditions(setResultRenditionList(request.getResultDetails().getResultRenditions()));
        } else {
            event.setResultRenditions(Collections.emptyList());
        }
        return event;
    }
    
    List<ResultLine> setResultLines(List<ResultLineNodeV1> resultLineNodeV1, List<ResultDeliveryBookingLineNodeV1> bookingLines) {
    	return resultLineNodeV1.stream()
        .map(inputResultLine -> {
            ResultLine resultLine = new ResultLine();
            resultLine.setResultLineUuid(inputResultLine.getResultLineUuid().toString());
            resultLine.setResultLineScore(inputResultLine.getResultLineScore());

            for (ResultDeliveryBookingLineNodeV1 inputBookingLine : bookingLines) {
                if (Objects.nonNull(inputResultLine.getBookingLineUuid()) &&
                        inputResultLine.getBookingLineUuid().equals(inputBookingLine.getBookingLineUuid())) {

                    resultLine.setComponent(ResultLine.ComponentEnum.fromValue(inputBookingLine.getComponentName()));
                    resultLine.setExternalBookingLineUuid(inputBookingLine.getExternalBookingLineUuid().toString());
                }
            }
            resultLine.setAbsence(inputResultLine.getAbsence());
            return resultLine;
        }).collect(Collectors.toList());
    }

    List<ResultRendition> setResultRenditionList(List<ResultRenditionNodeV1> resultRenditionNodeV1List) {

        return resultRenditionNodeV1List.stream().map(e -> {
            ResultRendition resultRendition = new ResultRendition();
            resultRendition.setResultsRenditionUuid(e.getResultsRenditionUuid().toString());
            resultRendition.setRenditionTypeUuid(e.getRenditionTypeUuid().toString());
            resultRendition.setRenditionVersion(e.getRenditionFileVersion());
            resultRendition.setRenditionDescription(e.getRenditionDescription());
            //presign URL
            resultRendition.setRenditionUrl(generatePresignedUrl(e.getRenditionFilePath()));
            return resultRendition;
        }).collect(Collectors.toList());

    }
    
    String generatePresignedUrl(String file) {
        String bucketName = System.getenv(TRF_BUCKET);
        String timeout = System.getenv(PRESIGN_TIMEOUT);

        GetObjectRequest getObjectRequest =
                GetObjectRequest.builder()
                        .bucket(bucketName)
                        .key(file)
                        .build();

        GetObjectPresignRequest getObjectPresignRequest = GetObjectPresignRequest.builder()
                .signatureDuration(Duration.ofSeconds(Long.parseLong(timeout)))
                .getObjectRequest(getObjectRequest)
                .build();

        // Generate the presigned request
        PresignedGetObjectRequest presignedGetObjectRequest =
                getPresigner().presignGetObject(getObjectPresignRequest);
        log.debug("PresignUrl Generated:{}", presignedGetObjectRequest.url());
        return presignedGetObjectRequest.url().toString();
    }

    S3Presigner getPresigner(){
        return S3Presigner.builder()
                .region(Region.of(System.getenv(REGION)))
                .build();
    }

}
