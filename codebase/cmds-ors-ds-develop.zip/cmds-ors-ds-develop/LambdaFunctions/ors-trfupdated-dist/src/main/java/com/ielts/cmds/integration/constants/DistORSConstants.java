package com.ielts.cmds.integration.constants;

public class DistORSConstants {

  private DistORSConstants() {}

  public static final String TRANSACTIONID = "transactionId";
  public static final String CORRELATIONID = "correlationId";
  public static final String PARTNER_CODE = "partnerCode";
  public static final String EVENT_DATETIME = "eventDateTime";
  public static final String IDP = "IDP";
  public static final String BC = "BC";
  public static final String BC_CHN = "BC_CHN";

  public static final String CALLBACK_URL= "endpoint_url";
  public static final String ORS_TRFUPDATED_DIST_IDP = "ors-trfupdated-dist-idp";
  public static final String ORS_TRFUPDATED_DIST_BC = "ors-trfupdated-dist-bc";  
  public static final String ORS_TRFUPDATED_DIST_BCCHN = "ors-trfupdated-dist-bcchn";

  public static final String REGION = "AWS_REGION";
  public static final String TRF_BUCKET = "trf_bucket_name";
  public static final String PRESIGN_TIMEOUT = "presigned_url_timeout_second";

  public static final String USER_AGENT="user_agent";
  public static final String USER_AGENT_KEY="User-Agent";
}