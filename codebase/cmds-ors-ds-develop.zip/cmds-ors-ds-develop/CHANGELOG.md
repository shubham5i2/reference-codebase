### [1.13.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.13.8...v1.13.9) (2024-05-14)


### ⚠ BREAKING CHANGES

* int431 change

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!171

* Merge branch 'feature/access-arrangement-events-change' into 'develop' ([1b4859f](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/1b4859f68f12cb479039f933fa9e1a1d1547ce29))

### [1.13.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.13.7...v1.13.8) (2024-05-13)

### [1.13.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.13.6...v1.13.7) (2024-05-08)

### [1.13.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.13.5...v1.13.6) (2024-05-03)


### ⚠ BREAKING CHANGES

* ors-event library change

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!168

* Merge branch 'feature/imod-61414-code-changes' into 'develop' ([6ae4b3d](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/6ae4b3db7361a04294fd26f898a5bbf8af79bdf9))

### [1.13.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.13.4...v1.13.5) (2024-05-02)


### ⚠ BREAKING CHANGES

* Feature/event change

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!167

* Merge branch 'feature/event-change' into 'develop' ([45555ad](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/45555ad96a1b0875d364d9bd462f08e4b815e25f))

### [1.13.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.13.3...v1.13.4) (2024-04-16)


### ⚠ BREAKING CHANGES

* Feature/cancel lambda change

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!163

* Merge branch 'feature/cancel-lambda-change' into 'develop' ([e8ae474](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/e8ae47434c31a137194973754a2902116387eb0a))

### [1.13.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.13.2...v1.13.3) (2024-04-16)


### ⚠ BREAKING CHANGES

* Feature/generate tag dummy

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!162

* Merge branch 'feature/generate-tag-dummy' into 'develop' ([63b7287](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/63b7287d89f7288522e28e3fa8af72f70807bb80))

### [1.13.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.13.1...v1.13.2) (2024-04-11)

### [1.13.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.13.0...v1.13.1) (2024-04-11)


### ⚠ BREAKING CHANGES

* details null check

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!157

* Merge branch 'feature/booking_details_null_check' into 'develop' ([daf693d](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/daf693d5efdefaa7fd8d510f5ed6a3cd61a503e7))

## [1.13.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.12.9...v1.13.0) (2024-04-10)


### Features

* <h1>Features :</h1><h2>Technical Features</h2> <h3>IMOD-58981 [Technical] ORS-DS Update the Snapshot to release version in all lambdas</h3> <p><strong>Purpose:</strong><br />Update the Snapshot versions  to release versions in dependency</p><h3>IMOD-58720 [Technical] SNS Event Re-Testing in Dev[ORSDS]</h3> <p><strong>Purpose:</strong><br />Retested SNS Events for Booking Flows</p><h3>IMOD-58719 [Technical] SNS Event Re-Testing in Sandbox [ORSDS]</h3> <p><strong>Purpose:</strong><br />Retested SNS Events for Booking Flows</p><h3>IMOD-52447 [Technical] [QA][SNS][ORS-DS] Changes for separation of topics per Business Event - BookingCancelRequested</h3> <p><strong>Purpose:</strong><br />As part of the User Story, following task has to be performed for BookingCancelRequested Business event:Test Script modification to see event is published to default topic + event specific topic, Regression execution with additional topics, Execution in Sandbox1/Sandbox2/Sandbox3, Execution in DEV</p><h3>IMOD-52445 [Technical] [QA][SNS][ORS-DS] Changes for separation of topics per Business Event - BookingTransferRequested</h3> <p><strong>Purpose:</strong><br />As part of the User Story, following task has to be performed for BookingTransferRequested Business event:Test Script modification to see event is published to default topic + event specific topic, Regression execution with additional topics, Execution in Sandbox1/Sandbox2/Sandbox3, Execution in DEV</p> ([fb5db94](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/fb5db94b46418b6d605df7efa24bea17e33a9151))

### [1.12.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.12.8...v1.12.9) (2024-04-08)

### [1.12.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.12.7...v1.12.8) (2024-04-03)

### [1.12.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.12.6...v1.12.7) (2024-03-27)

### [1.12.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.12.5...v1.12.6) (2024-03-26)


### ⚠ BREAKING CHANGES

* Defect Fix (Transaction ID not returned for offset)

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!149

* Merge branch 'feature/test-offset-date-withoutvalid' into 'develop' ([6486496](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/64864961738517cf15b7b7e2419e7b8e9976147c))

### [1.12.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.12.4...v1.12.5) (2024-03-14)

### [1.12.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.12.3...v1.12.4) (2024-03-13)


### ⚠ BREAKING CHANGES

* IMOD-58981 snapshot release

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!147

* Merge branch 'feature/IMOD-58981_snapshot_release' into 'develop' ([d989178](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/d989178cc2f91744b9355a4674f05799c7e46da7))

### [1.12.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.12.2...v1.12.3) (2024-03-11)


### ⚠ BREAKING CHANGES

* Feature/report fixing

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!141

* Merge branch 'feature/reportFixing' into 'develop' ([c9a1648](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/c9a16481f2902432ca36b98e510ebb6fe65ec386))

### [1.12.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.12.1...v1.12.2) (2024-03-07)


### ⚠ BREAKING CHANGES

* Release Notes V63.1

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!146

* Merge branch 'feature/release_RN' into 'develop' ([c169195](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/c169195c276f1787ec634c7740c70fcaa052b623))


### Features

* <h2>Bug Fixes</h2> <ol> <li>IMOD-59206 CMDS_BigBang_SmokeTest_SIT: Getting 404 error while sending EOR letter Response (INT-262) response to BC and BC-CHN callback URL</li></ol> ([4c6be2e](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/4c6be2e8e9aa7106d9da93f0ff8a85f4a1179193))

### [1.12.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.12.0...v1.12.1) (2024-03-06)


### ⚠ BREAKING CHANGES

* upgrade letter INT

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!143

* Merge branch 'feature/letter_response_version' into 'develop' ([ce5555c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/ce5555ca040248dbc559d6aa1a4c8faf51051e98))

## [1.12.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.11.0...v1.12.0) (2024-02-08)


### ⚠ BREAKING CHANGES

* Release Notes for V60

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!140

* Merge branch 'feature/release_RN' into 'develop' ([3384600](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/33846004a91f2e354a40452cdaf838302124b19e))


### Features

* <h1>Features :</h1><h2>Technical Features</h2> <h3>IMOD-51114 ORS DS changes for separation of topics per business event</h3> <p><strong>Purpose:</strong><br />As part of this ticket, acceleration of delivery of new features, quicker testing, elimination of single point of failure, independence of business workflows and to improve observability</p> <h3>IMOD-56021 Location Changed Lambda Swagger 2.0 Changes</h3> <p><strong>Purpose:</strong><br />As part of this task ors-locationchanged-dist lambda need to upgrade evt-112.</p> <h3>IMOD-52558 Remove excessive logging for Receiver Lambda</h3> <p><strong>Purpose:</strong><br />As part of this ticket, remove excessive logging to improve observability in receiver lambdas</p> <h3>IMOD-52559 Remove excessive logging for Dist lambda</h3> <p><strong>Purpose:</strong><br />As part of this ticket, remove excessive logging to improve observability in receiver lambdas</p> <h2>Business Features</h2> <h3>IMOD-48478 Inform ORS about matching UTTID in case of 2 bookings of a single TT on the same test date</h3> <p><strong>Purpose:</strong><br />As part of this task we're informing ORS about probable UTTID misallocation resulting from UTTID check [#3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/issues/3), to ensure that probable UTTID misallocation is recorded in ORS for operations purposes.</p> <h3>IMOD-48479 Inform ORS about UTTID match confidence level each time UTTID checks are performed</h3> <p><strong>Purpose:</strong><br />As part of this Business story informing ORS about match confidence level each time any UTTID check has a match, to ensure ORS OPS will have enough information to investigate and resolve probable UTTID match misalignment.</strong></p><h3>IMOD-39744 B-MX: Ensure OSR bookings are not accepted in CMDS when relevant component in original booking is marked as EXEMPT</h3> <p><strong>Purpose:</strong><br />As part of this we're ensuring that OSR bookings cannot be booked against original booking, if OSR component is marked as EXEMPT in original booking,to ensure OSR product policy is met.</p><h2>Bug Fixes</h2> <ol> <li>IMOD-36735 CMDS-IDP-SIT: isVoid should be removed in the response sent to ORS  (INT-303)</li></ol> ([68ad43d](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/68ad43df0662d68f02d45046f2c7bc3e97ea1627))

## [1.11.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.10.0...v1.11.0) (2024-01-10)


### ⚠ BREAKING CHANGES

* Release Tag/Notes for v60

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!138

* Merge branch 'feature/releaseNotesRN' into 'develop' ([d79d406](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/d79d40649397b9aa77caf2186fa2bca05bff81c0))


### Features

* <h1>Features :</h1><h2>Technical Features</h2> <h3>IMOD-51114 ORS DS changes for separation of topics per business event</h3> <p><strong>Purpose:</strong><br />As part of this ticket, acceleration of delivery of new features, quicker testing, elimination of single point of failure, independence of business workflows and to improve observability</p> <h2>Business Features</h2> <h3>IMOD-48478 Inform ORS about matching UTTID in case of 2 bookings of a single TT on the same test date</h3> <p><strong>Purpose:</strong><br />As part of this task we're informing ORS about probable UTTID misallocation resulting from UTTID check [#3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/issues/3), to ensure that probable UTTID misallocation is recorded in ORS for operations purposes.</p> <h3>IMOD-48479 Inform ORS about UTTID match confidence level each time UTTID checks are performed</h3> <p><strong>Purpose:</strong><br />As part of this Business story informing ORS about match confidence level each time any UTTID check has a match, to ensure ORS OPS will have enough information to investigate and resolve probable UTTID match misalignment.</strong></p><h3>IMOD-39744 B-MX: Ensure OSR bookings are not accepted in CMDS when relevant component in original booking is marked as EXEMPT</h3> <p><strong>Purpose:</strong><br />As part of this we're ensuring that OSR bookings cannot be booked against original booking, if OSR component is marked as EXEMPT in original booking,to ensure OSR product policy is met.</p><h2>Bug Fixes</h2> <ol> <li>IMOD-36735 CMDS-IDP-SIT: isVoid should be removed in the response sent to ORS  (INT-303)</li></ol> ([ae5b676](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/ae5b67674ae078d7159c42115f5d363b6dc348fb))

## [1.10.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.9.0...v1.10.0) (2023-12-21)

## [1.9.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.8.0...v1.9.0) (2023-12-12)

## [1.8.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.7.1...v1.8.0) (2023-11-27)

### [1.7.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.7.0...v1.7.1) (2023-11-08)

## [1.7.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.6.2...v1.7.0) (2023-11-07)

### [1.6.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.6.1...v1.6.2) (2023-11-07)


### ⚠ BREAKING CHANGES

* IMOD-51603-Transferv1 fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!128

* Merge branch 'feature/Incredibles-PI13-ors-stable-branch' into 'develop' ([e35c092](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/e35c09205ad59b825758a6bb26f8f78b2663f26d))

### [1.6.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.6.0...v1.6.1) (2023-11-01)


### ⚠ BREAKING CHANGES

* Map Null Reason for Match

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!127

* Merge branch 'feature/IMOD_54444_Reason_for_match_null' into 'develop' ([1eca0d4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/1eca0d4ce9df0b7ff4d648c7c8e66e5ae00e0395))

## [1.6.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.5.1...v1.6.0) (2023-10-26)


### ⚠ BREAKING CHANGES

* Feature/uttid mapping changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!125

* Merge branch 'feature/Uttid-mapping-changes' into 'develop' ([60cded4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/60cded4a734a41b00595bdee7c2078b98268fb8a))

### [1.5.2-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.5.1...v1.5.2-hotfix.1) (2023-10-25)

### [1.4.1-hotfix.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.4.1-hotfix.3...v1.4.1-hotfix.4) (2023-10-20)

### [1.4.1-hotfix.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.4.1-hotfix.2...v1.4.1-hotfix.3) (2023-09-28)

### [1.4.1-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.4.1-hotfix.1...v1.4.1-hotfix.2) (2023-09-14)

### [1.4.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.4.0...v1.4.1-hotfix.1) (2023-09-13)

### [1.4.1-hotfix.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.4.1-hotfix.2...v1.4.1-hotfix.3) (2023-09-28)

### [1.4.1-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.4.1-hotfix.1...v1.4.1-hotfix.2) (2023-09-14)

### [1.4.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.4.0...v1.4.1-hotfix.1) (2023-09-13)

### [1.5.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.5.0...v1.5.1) (2023-09-19)

## [1.5.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.4.3...v1.5.0) (2023-09-19)

### [1.4.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.4.2...v1.4.3) (2023-09-15)


### ⚠ BREAKING CHANGES

* Release Notes for v59

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!118

* Merge branch 'feature/releaseNotesRN' into 'develop' ([f3cff0b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/f3cff0bb6b2ea43af8a1e107c6d2089126f7d9a6))


### Features

* <h1>Features:</h1><h2>Business Features</h2><h3>IMOD-36467 [EOR] Letter notification from ORS DS to ORS</h3><p><strong>Purpose:</strong><br />As part of this story we had  built a new lambda 'ors-letterpublished-dist' so that EOR letter can be sent to TT by ORS OPS to communicate EOR outcome.</p> ([3e5ed68](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/3e5ed68ef30005f13048aa1b777fe42dd400f1d1))

### [1.4.1-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.4.1-hotfix.1...v1.4.1-hotfix.2) (2023-09-14)

### [1.4.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.4.0...v1.4.1-hotfix.1) (2023-09-13)

### [1.4.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.4.0...v1.4.1-hotfix.1) (2023-09-13)

### [1.4.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.4.1...v1.4.2) (2023-09-11)


### ⚠ BREAKING CHANGES

* EOR letter changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!112

* Merge branch 'feature/46643-eorletter' into 'develop' ([316a60f](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/316a60f7c58ba65ad71cf0414f2fda1d53ebe3a1))

### [1.4.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.4.0...v1.4.1) (2023-08-25)


### ⚠ BREAKING CHANGES

* multi lambda deploy

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!100

* Merge branch 'feature/IMOD-48937_transfer_evt_ser_changes' into 'develop' ([8d6750c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/8d6750c455bb92d89ed3f3dbc4d96371e960fa0c))

## [1.4.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.3.2...v1.4.0) (2023-08-22)


### Features

* <h1>Features :</h1><h2>Technical Features for ORS DS MX</h2><h3>IMOD-49054 Upgrade from SNAPSHOT to Release Versions of all common CMDS libs</h3><p><strong>Purpose:</strong><br />As part of this technical story, Booking MX is upgraded from SNAPSHOT version to release version for all the common library.</p><h3>IMOD-47310 [Technical] Reduce the Library size for Pending lambda</h3><p><strong>Purpose:</strong><br />As part of this technical story, library cleanup of distribution lambda is done to ensure smooth deployment and remove unused dependency</p><h2> ([18898ae](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/18898ae9b6415d1ed69b531fb9237268fbc72b73))

### [1.3.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.3.1...v1.3.2) (2023-08-18)

### [1.3.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.3.0...v1.3.1) (2023-08-18)


### ⚠ BREAKING CHANGES

* Fix error response in transfer lambda

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!104

* Merge branch 'feature/Tt_details_bug_transfer' into 'develop' ([979eb6a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/979eb6aa1d44d49746505ab064f546dd3a4b85ef))

## [1.3.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.2.0...v1.3.0) (2023-08-16)

## [1.2.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.1.10...v1.2.0) (2023-08-08)


### ⚠ BREAKING CHANGES

* Update all jobs as manual jobs for runner overload

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!94

* Merge branch 'feature/manual_job' into 'develop' ([20b4e3f](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/20b4e3fc485bbf10a82ec055f816cc6915f82b0e))

### [1.1.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.1.9...v1.1.10) (2023-07-29)


### ⚠ BREAKING CHANGES

* Release Tag for v57

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!96

* Merge branch 'feature/releaseNotes' into 'develop' ([64f39af](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/64f39af83182dc289b1054b9c468f9e7e0dc04d7))


### Features

* <h1>Features :</h1><h2>Technical Features</h2> <h3>IMOD-43804 Update the BC security identifier integration code to use contentType = application/x-www-form-urlencoded</h3> <p><strong>Purpose:</strong><br />This user story is to update the security infrastructure for British Council</p><h3>IMOD-46640 [Technical] Security change for All BC / BCCHN dist Lambda</h3> <p><strong>Purpose:</strong><br />This user story is to update their security infrastructure for British Council</p><h3>IMOD-46642 [Technical] Token Caching change for all BC/BCCHN/IDP Dist lambda </h3> <p><strong>Purpose:</strong><br />This Token Caching feature will enable library to store the token until the expiry time and reduce the number of times new token is requested by utilizing the stored token until it is expired. </p><h2>Bug Fixes</h2> <ol> <li>IMOD-36735 CMDS-IDP-SIT: isVoid should be removed in the response sent to ORS (INT-303)</li> </ol> ([fd89cdf](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/fd89cdf2e94d8d4bc8c9cacf5a0aa421b5c17b42))

### [1.1.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.1.8...v1.1.9) (2023-07-28)


### ⚠ BREAKING CHANGES

* v57 Release Tag

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!93

* Merge branch 'feature/yml_changes' into 'develop' ([bfa8a4c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/bfa8a4cb814e24e06e06fd3341cb47c0e92ae75f))

### [1.1.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.1.7...v1.1.8) (2023-07-26)


### ⚠ BREAKING CHANGES

* version changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!92

* Merge branch 'feature/update-gradle-version' into 'develop' ([3faa5e6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/3faa5e6d36c141b5a20eff4902a6fed46165a791))

### [1.1.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.1.6...v1.1.7) (2023-07-18)


### ⚠ BREAKING CHANGES

* Feature/bc auth void removal

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!91

* Merge branch 'feature/BC-auth-void-removal' into 'develop' ([bf07e85](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/bf07e85798d3b3c2856975316cafe5510b45a7fe))

### [1.1.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.1.5...v1.1.6) (2023-07-17)


### ⚠ BREAKING CHANGES

* auth for BC

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!90

* Merge branch 'feature/BC-auth-void-removal' into 'develop' ([8e08295](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/8e08295b38467291bd8f73569cec61529d5a9e8f))

### [1.1.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.1.4...v1.1.5) (2023-02-24)

### [1.1.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.1.3...v1.1.4) (2023-02-17)


### ⚠ BREAKING CHANGES

* bookingbanned bcchn lambda

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!81

* Merge branch 'feature/IMOD-38513_BC_CHN_newLambdas' into 'develop' ([2ae2ff6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/2ae2ff6f380be652661a897b250f4225a7c2b085))

### [1.1.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.1.2...v1.1.3) (2023-02-17)


### ⚠ BREAKING CHANGES

* IMOD-38513 BC_CHN new lambdas

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!80

* Merge branch 'feature/IMOD-38513_BC_CHN_newLambdas' into 'develop' ([941e93b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/941e93bba3cf28237e19de7b78893314e700b067))

### [1.1.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.1.1...v1.1.2) (2023-02-08)


### ⚠ BREAKING CHANGES

* Feature/adding ban rd lambdas

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!79

* Merge branch 'feature/adding-ban-rd-lambdas' into 'develop' ([0f2cb21](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/0f2cb212932a926e9741d686a4b7948f056a6852))

### [1.1.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.1.0...v1.1.1) (2023-02-03)


### ⚠ BREAKING CHANGES

* Feature/feature eor flag

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!78

* Merge branch 'feature/feature-eor-flag' into 'develop' ([3cd8a95](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/3cd8a9533a8d9ee7a0924af2d82a33d64403ec2f))

## [1.1.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.25...v1.1.0) (2023-01-31)

### [1.0.25](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.24...v1.0.25) (2023-01-30)

### [1.0.24](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.23...v1.0.24) (2023-01-18)


### ⚠ BREAKING CHANGES

* Feature/resultstatus payload change

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!74
* removed ors-eorresult-complete-dist lambda

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!73

* Merge branch 'feature/ors-eorresult-complete-dist_Removed' into 'develop' ([65676c4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/65676c45753118f319b5cba7c962c86bba174540))
* Merge branch 'feature/resultstatus-payload-change' into 'develop' ([347a593](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/347a593842a484351a08ec02e4182278aed47e4c))

### [1.0.23](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.22...v1.0.23) (2023-01-16)


### ⚠ BREAKING CHANGES

* Feature/imod 39650 minor fixes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!72

* Merge branch 'feature/IMOD-39650_minor_fixes' into 'develop' ([b9d3188](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/b9d31889039eb1826e709cc0a9334ac2e75e93aa))

### [1.0.22](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.21...v1.0.22) (2023-01-13)


### ⚠ BREAKING CHANGES

* merge of incredibles sprint 10-1 to develop

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!69

* Merge branch 'feature/Incredibles-Sprint-10-1' into 'develop' ([0c18603](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/0c18603c51bd89aa5f1cc1d9119968205a72ae72))

### [1.0.21](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.20...v1.0.21) (2023-01-06)


### ⚠ BREAKING CHANGES

* start-date-time-changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!68

* Merge branch 'feature/start-date-time-change' into 'develop' ([055acbd](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/055acbd4c49ad604e322b4468d85297402801612))

### [1.0.20](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.19...v1.0.20) (2022-12-26)


### ⚠ BREAKING CHANGES

* Feature/rm lambda changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!62

* Merge branch 'feature/RM-lambda-changes' into 'develop' ([ec8d987](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/ec8d9878a552ed1690b4c6c58e961c8346e27567))

### [1.0.19](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.18...v1.0.19) (2022-12-22)


### ⚠ BREAKING CHANGES

* Feature/imod 39650 minor fixes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!61
* Revert "Merge branch 'feature/RM-lambda-changes' into 'develop'"

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!60

* Merge branch 'feature/IMOD-39650_minor_fixes' into 'develop' ([460a715](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/460a715766f65d9790ef507cd2ea05293660728f))
* Merge branch 'revert-5769cb7e' into 'develop' ([270df73](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/270df7395e8d65e37b46d01c1d9d38cdcb13f5fe))

### [1.0.18](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.17...v1.0.18) (2022-12-15)


### ⚠ BREAKING CHANGES

* Feature/rm lambda changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!59

* Merge branch 'feature/RM-lambda-changes' into 'develop' ([5769cb7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/5769cb7ef966b50216f228622622555be10509f4))

### [1.0.17](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.16...v1.0.17) (2022-12-14)


### ⚠ BREAKING CHANGES

* Feature/location lambda

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!57

* Merge branch 'feature/location-lambda' into 'develop' ([3faa35d](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/3faa35d7d3d7653e5dee534b48ae4dabe38d114a))

### [1.0.16](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.15...v1.0.16) (2022-12-12)


### ⚠ BREAKING CHANGES

* Feature/revert location lambda

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!56
* removing location lambda

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!55

* Merge branch 'feature/revert-location-lambda' into 'develop' ([31bb571](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/31bb571d152a3cbc51f315c0fb7b40fbc188d0f5))
* Merge branch 'feature/revert-location-lambda' into 'develop' ([b052e92](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/b052e92268020d9cfc43d08d0b00c9c2cf7dcbab))

### [1.0.15](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.14...v1.0.15) (2022-12-09)


### ⚠ BREAKING CHANGES

* Feature/release changes lambda

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!54

* Merge branch 'feature/release-changes-lambda' into 'develop' ([194d2cb](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/194d2cb0229e97e49d01138d341dcc978e5d8449))

### [1.0.14](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.13...v1.0.14) (2022-12-08)


### ⚠ BREAKING CHANGES

* IMOD-38979 enhanced circuit breaker

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!52

* Merge branch 'feature/IMOD-38979_Enhanced_Circuit_Breaker' into 'develop' ([cbcf122](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/cbcf12211ac8dc3de62fbc87d70f1eac8ea53334))

### [1.0.13](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.12...v1.0.13) (2022-12-07)


### ⚠ BREAKING CHANGES

* Feature/release changes lambda

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!51

* Merge branch 'feature/release-changes-lambda' into 'develop' ([446d70a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/446d70a0718b8b792c499363a50af24a68449e10))

### [1.0.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.11...v1.0.12) (2022-12-06)


### ⚠ BREAKING CHANGES

* finance lambdas addition

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!50

* Merge branch 'feature/dummy-change' into 'develop' ([ba8ec31](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/ba8ec31596591cd4b7ed8317b082466f8c08ddf2))

### [1.0.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.10...v1.0.11) (2022-11-29)


### ⚠ BREAKING CHANGES

* IMOD 36464 Location Changed lambda

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!44

* Merge branch 'feature/IMOD-36464-LocationChangedLambda' into 'develop' ([0b114f1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/0b114f1f68d69f4ba958f2647738294b390e6f8a))

### [1.0.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.9...v1.0.10) (2022-10-18)


### ⚠ BREAKING CHANGES

* dummy change to generate tag

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!40
* Feature/updating version in ors events

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!39

* Merge branch 'feature/dummy_changes' into 'develop' ([75ed3f6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/75ed3f692fa2369aeeeba17bd5730ab1a9d894a0))
* Merge branch 'feature/updating_version_in_ors_events' into 'develop' ([56d19c1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/56d19c1fefc72271ce428e4bb557da3fbb114f49))

### [1.0.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.8...v1.0.9) (2022-09-23)


### ⚠ BREAKING CHANGES

* Revert "Merge branch 'feature/localdate-event-changes' into 'develop'"

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!38

* Merge branch 'revert-7ebd06bb' into 'develop' ([9d9f6aa](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/9d9f6aa6dbb119cebf7054d9d2a60823b233f38f))

### [1.0.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.7...v1.0.8) (2022-09-23)


### ⚠ BREAKING CHANGES

* featute/IMOD-30426_moving_existing_lambda_functions_to_ORS

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!35

* Merge branch 'feature/IMOD-30426_moving_exsisting_lambda_functions_to_ORS' into 'develop' ([83d5479](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/83d5479cd5b07879dbf0fd05a276d00b30deb492))

### [1.0.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.6...v1.0.7) (2022-09-21)


### ⚠ BREAKING CHANGES

* IMOD-35907 add timezone offset

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!37
* IMOD-35384 bug fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!36

* Merge branch 'feature/IMOD-35384_bug_fix' into 'develop' ([d92a3e4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/d92a3e4f34215119c793d05928882fdaf4de4b0d))
* Merge branch 'feature/localdate-event-changes' into 'develop' ([7ebd06b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/7ebd06bbb4a1202350a719fd38a6722c38b06c9b))

### [1.0.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.5...v1.0.6) (2022-08-28)


### ⚠ BREAKING CHANGES

* increasing versions for booking events

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!34

* Merge branch 'feature/booking-events-update' into 'develop' ([20df555](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/20df5554d7b07ab7d3b929e6032e94fe4f80ddf5))

### [1.0.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.4...v1.0.5) (2022-08-21)


### ⚠ BREAKING CHANGES

* common utils version changes in all lambda's

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!33

* Merge branch 'feature/commonUtils_version_changes' into 'develop' ([1af7157](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/1af7157abc78fc521f25145d3674194e054d1f9d))

### [1.0.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.3...v1.0.4) (2022-08-01)


### ⚠ BREAKING CHANGES

* int 420 changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!29

* Merge branch 'feature/INT-420_changes' into 'develop' ([a64c0fd](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/a64c0fd93724876d3c95b890ac9364b27c8758ce))

### [1.0.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.2...v1.0.3) (2022-07-28)


### ⚠ BREAKING CHANGES

* Feature/incredibles sprint 9 3

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!32

* Merge branch 'feature/Incredibles-Sprint-9-3' into 'develop' ([935a740](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/935a740130d81bb884f287d0392e53337a5364c2))

### [1.0.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.1...v1.0.2) (2022-06-30)


### ⚠ BREAKING CHANGES

* Feature/incredibles sprint 9 1

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!26

* Merge branch 'feature/Incredibles-Sprint-9-1' into 'develop' ([8b6d22a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/8b6d22a12f24939b997613adc4a04cd292893541))

### [1.0.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/compare/v1.0.0...v1.0.1) (2022-05-19)


### ⚠ BREAKING CHANGES

* reduced security auth version

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!15
* Feature/incredibles sprint 8 3

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!14
* added externalBooking id to response

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!11

* Merge branch 'feature/imod-29589-bug-fix' into 'develop' ([6a90232](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/6a902321eede719cba5f2b44f958417132ca20c4))
* Merge branch 'feature/Incredibles-Sprint-8-3' into 'develop' ([93c2ab3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/93c2ab3105ed76a7641d690f8a680c3a55eaec3f))
* Merge branch 'feature/Incredibles-Sprint-8-3' into 'develop' ([807c630](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/807c63023f124251f191085c9e137ad0d3b4ab7d))

## 1.0.0 (2022-04-13)


### ⚠ BREAKING CHANGES

* Feature/incredibles sprint 8 1

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds!7

* Merge branch 'feature/Incredibles-Sprint-8-1' into 'develop' ([cccb1b0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-ors-ds/commit/cccb1b09d271f8ab080c76178ea36c05f37866ad))
