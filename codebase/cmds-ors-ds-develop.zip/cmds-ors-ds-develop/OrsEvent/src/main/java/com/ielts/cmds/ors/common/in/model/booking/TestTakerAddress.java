package com.ielts.cmds.ors.common.in.model.booking;

import lombok.Data;

import java.util.UUID;

@Data
public class TestTakerAddress {

  private String addressLine1;

  private String addressLine2;

  private String addressLine3;

  private String addressLine4;

  private UUID stateTerritoryUuid;

  private String postalCode;

  private String city;

  private UUID countryUuid;

  private String countryIso3Code;
}
