package com.ielts.cmds.ors.common.in.model.ri;

import lombok.Data;

import java.util.ArrayList;

@Data
public class DocumentsAttachedV1 extends ArrayList<DocumentsDetailsV1> {
}
