package com.ielts.cmds.ors.common.in.model.booking;

import lombok.Data;

import java.util.UUID;

@Data
public class MarketingInfo {

  private UUID educationLevelUuid;

  private Integer yearsOfStudy;

  private UUID occupationSectorUuid;

  private UUID occupationLevelUuid;

  private UUID reasonForTestUuid;

  private UUID  applyingToCountryUuid;

  private String applyingToCountryIso3code;

  private String currentEnglishStudyPlace;

  private String occupationSectorOther;

  private String occupationLevelOther;

  private String reasonForTestOther;

  private String countryApplyingToOther;
}
