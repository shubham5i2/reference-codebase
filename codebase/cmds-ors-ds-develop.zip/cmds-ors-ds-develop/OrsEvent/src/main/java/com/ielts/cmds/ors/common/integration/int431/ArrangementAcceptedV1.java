package com.ielts.cmds.ors.common.integration.int431;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.UUID;

@Data
@ToString
@EqualsAndHashCode
public class ArrangementAcceptedV1 {
  @ToString.Exclude
  private String arrangementToken;
  private UUID externalCaseNumberUuid;
}
