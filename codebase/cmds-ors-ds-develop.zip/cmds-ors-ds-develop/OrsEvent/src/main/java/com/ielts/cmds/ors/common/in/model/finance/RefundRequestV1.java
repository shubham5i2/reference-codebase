package com.ielts.cmds.ors.common.in.model.finance;

import com.google.gson.annotations.SerializedName;
import lombok.Data;

@Data
public class RefundRequestV1 {
    @SerializedName("externalBookingUuid")
    private String externalBookingUuid = null;

    @SerializedName("externalRefundRequestUuid")
    private String externalRefundRequestUuid = null;

}