package com.ielts.cmds.ors.common.in.model.booking;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.google.gson.annotations.SerializedName;
import com.ielts.cmds.ors.common.enums.IdentityVerificationStatusEnum;
import lombok.Data;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.UUID;

@Data
public class TestTakerDetails {

  @NotNull(message = "{booking.externalTestTakerId.null}")
  private UUID externalTestTakerUuid;

  private String identityNumber;

  private UUID identityTypeUuid;

  private IdentityVerificationStatusEnum identityVerificationStatus = IdentityVerificationStatusEnum.INCOMPLETE;

  private String identityIssuingAuthority;

  @JsonDeserialize(using = LocalDateDeserializer.class)
  @JsonSerialize(using = LocalDateSerializer.class)
  @SerializedName("identityExpiryDate")
  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate identityExpiryDate = null;

  private String firstName;

  private String lastName;

  @JsonDeserialize(using = LocalDateDeserializer.class)
  @JsonSerialize(using = LocalDateSerializer.class)
  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate birthDate = null;

  private UUID sexUuid;

  private String sex;

  @Email(regexp = ".+@.+\\..+")
  private String email;

  private String title;

  private String phone;

  private String mobile;

  private UUID languageUuid;

  private UUID nationalityUuid;

  private String notes;

  private String languageOther;
  private String nationalityOther;

  private TestTakerAddress address;
}
