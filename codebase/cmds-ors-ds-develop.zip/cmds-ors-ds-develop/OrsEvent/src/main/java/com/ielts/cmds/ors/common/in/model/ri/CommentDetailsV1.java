package com.ielts.cmds.ors.common.in.model.ri;

import com.ielts.cmds.ors.common.enums.CommentEnteredByUserTypeEnum;
import lombok.Data;

import java.time.OffsetDateTime;

@Data
public class CommentDetailsV1 {

    private String comment;

    private OffsetDateTime commentDateTime;

    private String commentEnteredBy;

    private CommentEnteredByUserTypeEnum commentEnteredByUserType;
}
