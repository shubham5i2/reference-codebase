package com.ielts.cmds.ors.common.enums;

import java.io.IOException;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;


@JsonAdapter(ConfirmationStatusEnum.Adapter.class)
public enum ConfirmationStatusEnum {

    CONFIRMED("CONFIRMED"),
    CONDITIONAL("CONDITIONAL"),
    WITHDRAWN("WITHDRAWN"),
    INVALID("INVALID");

    private final String value;

    ConfirmationStatusEnum(String value) {
        this.value = value;
    }

    public static ConfirmationStatusEnum fromValue(String text) {
        for (ConfirmationStatusEnum confirmationStatus : ConfirmationStatusEnum.values()) {
            if (String.valueOf(confirmationStatus.value).equals(text)) {
                return confirmationStatus;
            }
        }
        return null;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static class Adapter extends TypeAdapter<ConfirmationStatusEnum> {
        @Override
        public void write(final JsonWriter jsonWriter, final ConfirmationStatusEnum enumeration)
                throws IOException {
            jsonWriter.value(enumeration.getValue());
        }

        @Override
        public ConfirmationStatusEnum read(final JsonReader jsonReader) throws IOException {
            String value = jsonReader.nextString();
            return ConfirmationStatusEnum.fromValue(String.valueOf(value));
        }
    }


}
