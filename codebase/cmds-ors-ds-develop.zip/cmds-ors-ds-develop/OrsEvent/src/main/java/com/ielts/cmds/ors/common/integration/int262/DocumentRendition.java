package com.ielts.cmds.ors.common.integration.int262;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DocumentRendition
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class DocumentRendition {
  @JsonProperty("renditionType")
  private String renditionType;

  @JsonProperty("contentType")
  private String contentType;

  @JsonProperty("renditionUrl")
  private String renditionUrl;

}
