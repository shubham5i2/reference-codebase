package com.ielts.cmds.ors.common.in.model.rm;

import com.google.gson.annotations.SerializedName;
import lombok.Data;

import java.util.UUID;

@Data
public class EorLine {
    @SerializedName("externalEorLineUuid")
    private UUID externalEorLineUuid;

    @SerializedName("externalBookingLineUuid")
    private UUID externalBookingLineUuid;


}
