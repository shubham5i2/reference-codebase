package com.ielts.cmds.ors.common.in.model.ri;

import lombok.Data;

@Data
public class DocumentsDetailsV1 {

    private String documentName;

    private String documentURL;
}
