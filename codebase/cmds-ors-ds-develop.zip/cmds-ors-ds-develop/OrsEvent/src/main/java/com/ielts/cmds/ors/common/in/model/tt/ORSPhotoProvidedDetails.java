package com.ielts.cmds.ors.common.in.model.tt;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.google.gson.annotations.SerializedName;
import com.ielts.cmds.custom.serializer.CMDSLocalDateTimeDeserializer;
import lombok.Data;

import java.io.InputStream;
import java.time.LocalDateTime;
import java.util.UUID;


@Data
public class ORSPhotoProvidedDetails {

    private UUID photoTypeUuid;

    private String photoUrl;

    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = CMDSLocalDateTimeDeserializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    private LocalDateTime photoTimestamp;

    private UUID photoExternalUuid;
}
