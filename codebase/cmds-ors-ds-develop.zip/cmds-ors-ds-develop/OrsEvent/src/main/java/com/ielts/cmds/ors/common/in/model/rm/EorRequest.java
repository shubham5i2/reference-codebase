package com.ielts.cmds.ors.common.in.model.rm;

import com.google.gson.annotations.SerializedName;
import com.ielts.cmds.ors.common.in.model.rm.EorLine;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Data
public class EorRequest {
    @SerializedName("externalEorUuid")
    private UUID externalEorUuid;

    @SerializedName("externalEorId")
    private String externalEorId;

    @SerializedName("externalBookingUuid")
    private UUID externalBookingUuid;

    @SerializedName("eorLines")
    private List<EorLine> eorLines = new ArrayList<>();
}
