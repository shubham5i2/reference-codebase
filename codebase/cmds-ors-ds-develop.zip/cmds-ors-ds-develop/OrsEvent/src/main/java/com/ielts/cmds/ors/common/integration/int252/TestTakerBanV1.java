package com.ielts.cmds.ors.common.integration.int252;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.UUID;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaClientCodegen", date = "2024-05-10T13:53:22.690339878Z[GMT]")
@Data
@ToString
@EqualsAndHashCode
public class TestTakerBanV1 {
    @JsonProperty("uniqueTestTakerUuid")
    private UUID uniqueTestTakerUuid = null;

    @JsonProperty("uniqueTestTakerId")
    private String uniqueTestTakerId = null;

    @JsonProperty("details")
    private BanDetailsV1 details = null;
}
