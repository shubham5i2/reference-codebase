package com.ielts.cmds.ors.common.enums;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;

@JsonAdapter(IdentityVerificationStatusEnum.Adapter.class)
public enum IdentityVerificationStatusEnum {
  INCOMPLETE("INCOMPLETE"),
  UNVERIFIED("UNVERIFIED"),
  VERIFIED("VERIFIED");

  private final String value;

  IdentityVerificationStatusEnum(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }

  @Override
  public String toString() {
    return String.valueOf(value);
  }

  public static IdentityVerificationStatusEnum fromValue(String text) {
    for (IdentityVerificationStatusEnum b : IdentityVerificationStatusEnum.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }

  public static class Adapter extends TypeAdapter<IdentityVerificationStatusEnum> {
    @Override
    public void write(final JsonWriter jsonWriter, final IdentityVerificationStatusEnum enumeration)
        throws IOException {
      jsonWriter.value(enumeration.getValue());
    }

    @Override
    public IdentityVerificationStatusEnum read(final JsonReader jsonReader) throws IOException {
      String value = jsonReader.nextString();
      return IdentityVerificationStatusEnum.fromValue(String.valueOf(value));
    }
  }
}
