package com.ielts.cmds.ors.common.enums;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;

@JsonAdapter(ExternalIncidentStatusEnum.Adapter.class)
public enum ExternalIncidentStatusEnum {
    FLAGGED("FLAGGED"),
    CLEARED("CLEARED"),
    CONFIRMED("CONFIRMED");

    private String value;

    ExternalIncidentStatusEnum(String value) {
        this.value = value;
    }
    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }
    public static ExternalIncidentStatusEnum fromValue(String input) {
        for (ExternalIncidentStatusEnum b : ExternalIncidentStatusEnum.values()) {
            if (b.value.equals(input)) {
                return b;
            }
        }
        return null;
    }
    public static class Adapter extends TypeAdapter<ExternalIncidentStatusEnum> {
        @Override
        public void write(final JsonWriter jsonWriter, final ExternalIncidentStatusEnum enumeration) throws IOException {
            jsonWriter.value(String.valueOf(enumeration.getValue()));
        }

        @Override
        public ExternalIncidentStatusEnum read(final JsonReader jsonReader) throws IOException {
            Object value = jsonReader.nextString();
            return ExternalIncidentStatusEnum.fromValue((String)(value));
        }
    }
}
