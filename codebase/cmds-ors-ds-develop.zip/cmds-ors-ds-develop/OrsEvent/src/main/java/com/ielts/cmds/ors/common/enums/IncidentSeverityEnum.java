package com.ielts.cmds.ors.common.enums;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;

@JsonAdapter(IncidentSeverityEnum.Adapter.class)
public enum IncidentSeverityEnum {
    INFO("INFO"),
    WARNING("WARNING"),
    CONFIRMED_MALPRACTICE("CONFIRMED_MALPRACTICE");

    private String value;

    IncidentSeverityEnum(String value) {
        this.value = value;
    }
    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }
    public static IncidentSeverityEnum fromValue(String input) {
        for (IncidentSeverityEnum b : IncidentSeverityEnum.values()) {
            if (b.value.equals(input)) {
                return b;
            }
        }
        return null;
    }
    public static class Adapter extends TypeAdapter<IncidentSeverityEnum> {
        @Override
        public void write(final JsonWriter jsonWriter, final IncidentSeverityEnum enumeration) throws IOException {
            jsonWriter.value(String.valueOf(enumeration.getValue()));
        }

        @Override
        public IncidentSeverityEnum read(final JsonReader jsonReader) throws IOException {
            Object value = jsonReader.nextString();
            return IncidentSeverityEnum.fromValue((String)(value));
        }
    }
}