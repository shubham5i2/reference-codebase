package com.ielts.cmds.ors.common.integration.int262;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Document
 */



@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class Document {
  @JsonProperty("externalBookingUuid")
  private UUID externalBookingUuid;

  @JsonProperty("issueDate")
  @JsonFormat(pattern="yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
  private OffsetDateTime issueDate;

  @JsonProperty("typeCode")
  private String typeCode;

  @JsonProperty("renditions")
  private List<DocumentRendition> renditions;
}
