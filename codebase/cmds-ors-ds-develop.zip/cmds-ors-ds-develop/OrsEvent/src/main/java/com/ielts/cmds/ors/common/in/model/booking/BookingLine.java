package com.ielts.cmds.ors.common.in.model.booking;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.ielts.cmds.custom.serializer.CMDSLocalDateTimeDeserializer;
import com.ielts.cmds.ors.common.enums.BookingLineStatusEnum;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.UUID;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BookingLine {

  private UUID externalBookingLineUuid;

  private UUID bookingLineUuid;

  @JsonSerialize(using = LocalDateTimeSerializer.class)
  @JsonDeserialize(using = CMDSLocalDateTimeDeserializer.class)
  @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
  @NotNull(message = "{booking.startDateTime.null}")
  private LocalDateTime startDateTime;

  @JsonSerialize(using = LocalDateTimeSerializer.class)
  @JsonDeserialize(using = CMDSLocalDateTimeDeserializer.class)
  @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
  @NotNull(message = "{booking.startTimeLocal.null}")
  private LocalDateTime startDateTimeLocal;

  @Range(min = 0, max = 0)
  private Integer extraTimeMinutes;

  private BookingLineStatusEnum bookingLineStatus;

  private UUID productUuid;
}
