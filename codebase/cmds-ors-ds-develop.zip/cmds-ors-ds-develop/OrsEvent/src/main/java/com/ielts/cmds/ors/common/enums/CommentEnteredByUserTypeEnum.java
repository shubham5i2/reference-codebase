package com.ielts.cmds.ors.common.enums;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;

@JsonAdapter(CommentEnteredByUserTypeEnum.Adapter.class)
public enum CommentEnteredByUserTypeEnum {
    REVIEWER("REVIEWER"),
    REPORTER("REPORTER");

    private String value;

    CommentEnteredByUserTypeEnum(String value) {
        this.value = value;
    }
    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }
    public static CommentEnteredByUserTypeEnum fromValue(String input) {
        for (CommentEnteredByUserTypeEnum b : CommentEnteredByUserTypeEnum.values()) {
            if (b.value.equals(input)) {
                return b;
            }
        }
        return null;
    }
    public static class Adapter extends TypeAdapter<CommentEnteredByUserTypeEnum> {
        @Override
        public void write(final JsonWriter jsonWriter, final CommentEnteredByUserTypeEnum enumeration) throws IOException {
            jsonWriter.value(String.valueOf(enumeration.getValue()));
        }

        @Override
        public CommentEnteredByUserTypeEnum read(final JsonReader jsonReader) throws IOException {
            Object value = jsonReader.nextString();
            return CommentEnteredByUserTypeEnum.fromValue((String)(value));
        }
    }
}