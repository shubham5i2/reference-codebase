package com.ielts.cmds.ors.common.in.model.ri;

import lombok.Data;

@Data
public class IncidentV1 {

    private IncidentDetailsV1 incidentDetails;
}
