/**
 * 
 */
package com.ielts.cmds.ors.common.enums;

/**
 * @author vedire
 *
 */

import java.io.IOException;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

@JsonAdapter(DeliveryStatusEnum.Adapter.class)
public enum DeliveryStatusEnum {
  UNDELIVERED("UNDELIVERED"),
  DELIVERED("DELIVERED"),
  DELIVERY_PENDING("DELIVERY_PENDING"),
  REDELIVERED("REDELIVERED"),
  REDELIVERY_REQUEST_PENDING("REDELIVERY_REQUEST_PENDING"),
  REDELIVERY_REQUESTED("REDELIVERY_REQUESTED"),
  DELIVERY_REQUESTED("DELIVERY_REQUESTED"),
  NOT_APPLICABLE_FOR_UA("NOT_APPLICABLE_FOR_UA");
	
  private String value;

  DeliveryStatusEnum(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }

  @Override
  public String toString() {
    return String.valueOf(value);
  }

  public static DeliveryStatusEnum fromValue(String text) {
    for (DeliveryStatusEnum b : DeliveryStatusEnum.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }

  public static class Adapter extends TypeAdapter<DeliveryStatusEnum> {
    @Override
    public void write(final JsonWriter jsonWriter, final DeliveryStatusEnum enumeration)
        throws IOException {
      jsonWriter.value(enumeration.getValue());
    }

    @Override
    public DeliveryStatusEnum read(final JsonReader jsonReader) throws IOException {
      String value = jsonReader.nextString();
      return DeliveryStatusEnum.fromValue(String.valueOf(value));
    }
  }
}

