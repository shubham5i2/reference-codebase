package com.ielts.cmds.ors.common.in.model.ri;

import lombok.Data;

import java.util.ArrayList;

@Data
public class CommentsV1 extends ArrayList<CommentDetailsV1> {

}
