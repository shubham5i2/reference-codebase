package com.ielts.cmds.ors.common.enums;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;

@JsonAdapter(BookingStatusEnum.Adapter.class)
public enum BookingStatusEnum {
  PAID("PAID"),
  CANCELLED("CANCELLED"),
  REFUNDED("REFUNDED");

  private final String value;

  BookingStatusEnum(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }

  @Override
  public String toString() {
    return String.valueOf(value);
  }

  public static BookingStatusEnum fromValue(String text) {
    for (BookingStatusEnum b : BookingStatusEnum.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }

  public static class Adapter extends TypeAdapter<BookingStatusEnum> {
    @Override
    public void write(final JsonWriter jsonWriter, final BookingStatusEnum enumeration)
        throws IOException {
      jsonWriter.value(enumeration.getValue());
    }

    @Override
    public BookingStatusEnum read(final JsonReader jsonReader) throws IOException {
      String value = jsonReader.nextString();
      return BookingStatusEnum.fromValue(String.valueOf(value));
    }
  }
}
