package com.ielts.cmds.ors.common.in.model.booking;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.google.gson.annotations.SerializedName;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import com.ielts.cmds.ors.common.enums.BookingDetailStatusEnum;
import com.ielts.cmds.ors.common.enums.BookingStatusEnum;
import lombok.Data;

@Data
public class RegistrationDetails {

    private UUID bookingUuid;

    private UUID productUuid;

    private UUID locationUuid;

    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd")
    @SerializedName("testDate")
    private LocalDate testDate;

    private UUID externalBookingUuid;

    private String externalBookingReference;

    private BookingDetailStatusEnum bookingDetailStatus;

    private BookingStatusEnum bookingStatus;

    private String agentName;

    private boolean consentGiven;

    private String partnerCode;

    private Boolean specialArrangementsRequired;

    private MarketingInfo marketingInfo;

    private TestTakerDetails testTaker;

    private List<BookingLine> bookingLines;

    private String testCentreName;

    private UUID testCentreId;

    private String operationType;
}


