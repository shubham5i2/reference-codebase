package com.ielts.cmds.ors.common.in.model.ri;

import com.ielts.cmds.ors.common.enums.ExternalIncidentStatusEnum;
import com.ielts.cmds.ors.common.enums.IncidentSeverityEnum;
import lombok.Data;

import java.time.OffsetDateTime;
import java.util.UUID;

@Data
public class IncidentDetailsV1 {

    private String externalIncidentId;

    private IncidentSeverityEnum incidentSeverity;

    private UUID incidentTypeUuid;

    private ExternalIncidentStatusEnum externalIncidentStatus;

    private OffsetDateTime externalIncidentChangedDateTime;

    private UUID externalBookingUuid;

    private UUID externalBookingLineUuid;

    private CommentsV1 comments;

    private DocumentsAttachedV1 documentsAttached;

}
