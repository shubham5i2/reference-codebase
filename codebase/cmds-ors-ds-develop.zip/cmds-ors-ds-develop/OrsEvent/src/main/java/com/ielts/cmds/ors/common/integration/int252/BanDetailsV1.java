package com.ielts.cmds.ors.common.integration.int252;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.time.LocalDate;
import java.util.UUID;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaClientCodegen", date = "2024-05-10T13:53:22.690339878Z[GMT]")
@Data
@ToString
@EqualsAndHashCode
public class BanDetailsV1 {
    @JsonProperty("banUuid")
    private UUID banUuid = null;

    @JsonProperty("banReasonUuid")
    private UUID banReasonUuid = null;

    @JsonProperty("startDate")
    private LocalDate startDate = null;

    @JsonProperty("endDate")
    private LocalDate endDate = null;

    @JsonProperty("comment")
    private String comment = null;
}