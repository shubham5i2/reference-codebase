$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("OrstoCmdsBookingcall01.feature");
formatter.feature({
  "line": 1,
  "name": "ORS to CMDS Registraion Booking",
  "description": "",
  "id": "ors-to-cmds-registraion-booking",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 3,
  "name": "Post the booking registration details to CMDS from ORS",
  "description": "",
  "id": "ors-to-cmds-registraion-booking;post-the-booking-registration-details-to-cmds-from-ors",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 4,
  "name": "Booking Registrations from MongoDB \"\u003cHostname\u003e\",\"\u003cPortname\u003e\",\"\u003cDbname\u003e\",\"\u003cCollection\u003e\" wiremock",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "User able to POST the booking details to cmds \"\u003cBaseurl\u003e\",\"\u003cPath\u003e\" wiremock",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "User able to verify the POST details from ors \"\u003cActurl\u003e\",\"\u003cActpath\u003e\" wirmock",
  "keyword": "Then "
});
formatter.examples({
  "line": 7,
  "name": "",
  "description": "",
  "id": "ors-to-cmds-registraion-booking;post-the-booking-registration-details-to-cmds-from-ors;",
  "rows": [
    {
      "cells": [
        "Hostname",
        "Portname",
        "Dbname",
        "Collection",
        "Baseurl",
        "Path",
        "Acturl",
        "Actpath"
      ],
      "line": 8,
      "id": "ors-to-cmds-registraion-booking;post-the-booking-registration-details-to-cmds-from-ors;;1"
    },
    {
      "cells": [
        "localhost",
        "27017",
        "orsdb",
        "input",
        "http://localhost:8085/__admin",
        "mappings",
        "http://localhost:8085",
        "bookings"
      ],
      "line": 9,
      "id": "ors-to-cmds-registraion-booking;post-the-booking-registration-details-to-cmds-from-ors;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 9,
  "name": "Post the booking registration details to CMDS from ORS",
  "description": "",
  "id": "ors-to-cmds-registraion-booking;post-the-booking-registration-details-to-cmds-from-ors;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 4,
  "name": "Booking Registrations from MongoDB \"localhost\",\"27017\",\"orsdb\",\"input\" wiremock",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "User able to POST the booking details to cmds \"http://localhost:8085/__admin\",\"mappings\" wiremock",
  "matchedColumns": [
    4,
    5
  ],
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "User able to verify the POST details from ors \"http://localhost:8085\",\"bookings\" wirmock",
  "matchedColumns": [
    6,
    7
  ],
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
});