package utilities.lprtocmdssetup.runner;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = {"src/test/java/utilities/lprtocmdssetup/features/LprtoCmdsSetup.feature"},
		glue= {"utilities/lprtocmdssetup/stepdefinitions"},
		format = { "pretty", "html:target/results" },
		monochrome = true,
		strict = true,
		dryRun=false)
	//tags={"@SanityTest, @RegressionTest"})


public class Step3TestRunnerLprtoCmdsSetup
{
	
}
