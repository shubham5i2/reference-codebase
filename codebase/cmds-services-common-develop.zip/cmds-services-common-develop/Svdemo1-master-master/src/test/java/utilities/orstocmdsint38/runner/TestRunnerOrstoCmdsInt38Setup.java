package utilities.orstocmdsint38.runner;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"src/test/java/utilities/orstocmdsint38/features/OrstoCmdsbookclean01.feature"},
        glue= {"utilities/orstocmdsint38/stepdefinitions"},
        format = { "pretty", "html:target/results" },
        monochrome = true,
        strict = true,
        dryRun=false)
//tags={"@SanityTest, @RegressionTest"})
public class TestRunnerOrstoCmdsInt38Setup {
}
