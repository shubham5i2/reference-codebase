package utilities.cmdstoinsperaint30.runner;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = {"src/test/java/utilities/cmdstoinsperasetup/features/CmdstoInsperaSetup.feature"},
		glue= {"utilities/cmdstoinsperaint30/stepdefinitions"},
		format = { "pretty", "html:target/results" },
		monochrome = true,
		strict = true,
		dryRun=false)
	//tags={"@SanityTest, @RegressionTest"})


public class Step3TestRunnerCmdstoInsperaSetup
{
	
}
