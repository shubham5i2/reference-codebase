package utilities.orstocmdssetup.runner;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"src/test/java/utilities/orstocmdssetup/features/OrstoCmdsBookingclean01.feature"},
        glue= {"utilities/orstocmdssetup/stepdefinitions"},
        format = { "pretty", "html:target/results" },
        monochrome = true,
        strict = true,
        dryRun=false)
//tags={"@SanityTest, @RegressionTest"})
public class Step1TestRuunerOrsdbclean {
}
