package utilities.lprtocmdsint92.stepdefinitions;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Lprdbclean01 {
    @Given("^Clean the lprserver reference database in MongoDB \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" wiremock$")
    public void Clean_the_lprserver_reference_database_in_MongoDB(String arg1, Integer arg2, String arg3, String arg4) {
        MongoClient mongoclient = new MongoClient(arg1, arg2);
        DB db = mongoclient.getDB(arg3);
        System.out.println("Mondb connected");
        DBCollection coll = db.getCollection(arg4);
        coll.remove(new BasicDBObject());

    }
    @When("^Clean the lprrequest reference database in MongoDB \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" wiremock$")
    public void Connect_the_lprrequest_database_in_MongoDB(String arg1, Integer arg2, String arg3, String arg4) {
        MongoClient mongoclient = new MongoClient(arg1, arg2);
        DB db = mongoclient.getDB(arg3);
        System.out.println("Mondb connected");
        DBCollection coll = db.getCollection(arg4);
        coll.remove(new BasicDBObject());


    }
    @Then("^Clean the lprresponse reference database in MongoDB \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" wiremock$")
    public void Connect_the_lprresponse_database_in_MongoDB(String arg1, Integer arg2, String arg3, String arg4) {
        MongoClient mongoclient = new MongoClient(arg1, arg2);
        DB db = mongoclient.getDB(arg3);
        System.out.println("Mondb connected");
        DBCollection coll = db.getCollection(arg4);
        coll.remove(new BasicDBObject());

    }

}
