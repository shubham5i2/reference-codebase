package utilities.orstocmdssetup.stepdefinitions;

import com.mongodb.*;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertEquals;

public class OrstoCmdsbookingSetup {

    String str = "";
    String postbody = "";
    String inputjson[]= new String[2];
    String actinputjson[]= new String[2];
    int removehead = 51;
    int count=0;
    int totalindex = 0;

    @Given("^Setup Booking Registrations from MongoDB \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" wiremock$")
    public void Booking_Registrations_from_MongoDB(String hostname, Integer portnum, String dbname,String collectionname,String productid)

    {
        MongoClient mongoclient = new MongoClient(hostname,portnum);
        DB db = mongoclient.getDB(dbname);
        DBCollection coll = db.getCollection(collectionname);
        DBCursor cursor = coll.find();
        int i=0;
        while(cursor.hasNext()) {

            DBObject result= cursor.next();
            str = new String(String.valueOf(result));
            Integer length = str.length();
            String subpostbody = str.substring(removehead,length);
            postbody = "{" + subpostbody;
            inputjson[i] = postbody;
            i++;
            totalindex = i ;
        }
    }

    @When("^User able to setup the booking details to cmds \"([^\"]*)\",\"([^\"]*)\" wiremock$")
    public void User_able_to_POST_the_booking_details_to_cmds(String BaseUrl, String Basepath) {
        while (count < totalindex) {
            postbody= inputjson[count];
            RestAssured.baseURI = BaseUrl;
            RestAssured.basePath = "";
            Response response = given().contentType(ContentType.TEXT).log().all().body(postbody).post(Basepath);
            response.prettyPrint();
            count++;
        }
    }


}





//            System.out.println("jsosn oject const:" + expectedjson);
//            String ExpectStr  = response.asString();
//            String ExpectStr1 = String.valueOf(actpostbody);
//            String ExpectStr = ExpectStr1.trim();
//              ResponseBody bodynew = response.getBody();

//    JSONParser parser = new JSONParser();
//    JSONObject expectedjson = (JSONObject) parser.parse(actpostbody);

//
//            JsonPath jsonPathEvaluator = response.jsonPath();
//            System.out.println("jsonPathEvaluator" + jsonPathEvaluator);
//            String externalBookingId = jsonPathEvaluator.get("externalBookingId");
//            String externalTestTakerId = jsonPathEvaluator.get("testTaker.externalTestTakerId");
//            System.out.println("externalBookingId: " + externalBookingId);
//            System.out.println("externalTestTakerId : " + externalTestTakerId);
//            List<String> cnexternalBookingLineId = jsonPathEvaluator.getList("bookingLines.externalBookingLineId");
//            for (String externalBookingLineId : cnexternalBookingLineId) {
//                System.out.println("externalBookingLineId: " + externalBookingLineId);
//            }
//            String Var1 = "{\"request\":{\"method\":\"POST\",\"url\":\"/bookings\"},\"response\":{\"status\":200,\"jsonBody\":{\"externalBookingId\":\"";
//            String Var2 = "\",\"testTaker\":{\"testTakerId\":0,\"externalTestTakerId\":\"";
//            String Var3 = "\"},\"bookingLines\":[{\"externalBookingLineId\":\"";
//            String Var4 = "\",\"bookingLineId\":1234}],\"bookingId\":1234,\"candidateNumber\": \"213232\",\"compositeCandidateId\":\"AU24020123456\"}}}";
//            String Var5 = Var1 + externalBookingId + Var2 + externalTestTakerId + Var3 + externalBookingId + Var4;
//            MongoClient mongoclient = new MongoClient("localhost", 27017);
//            DB db = mongoclient.getDB("cmdsdb");
//            DBCollection collstr = db.getCollection("output");
//            System.out.println("Mondb connected");
//            DBObject object = (DBObject) JSON.parse(Var5);
//            collstr.insert(object);

