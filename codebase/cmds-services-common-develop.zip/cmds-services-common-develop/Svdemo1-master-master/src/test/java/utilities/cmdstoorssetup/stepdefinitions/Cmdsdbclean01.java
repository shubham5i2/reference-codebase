package utilities.cmdstoorssetup.stepdefinitions;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Cmdsdbclean01 {
    @Given("^Connect the cmdsinput database in MongoDB \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" wiremock$")
    public void Connect_the_orsinput_database_in_MongoDB(String arg1, Integer arg2, String arg3, String arg4) {
        MongoClient mongoclient = new MongoClient(arg1, arg2);
        DB db = mongoclient.getDB(arg3);
        System.out.println("Mondb connected");
        DBCollection coll = db.getCollection(arg4);
        coll.remove(new BasicDBObject());

    }
    @When("^Connect the cmdsbooking database in MongoDB \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" wiremock$")
    public void Connect_the_orsbooking_database_in_MongoDB(String arg1, Integer arg2, String arg3, String arg4) {
        MongoClient mongoclient = new MongoClient(arg1, arg2);
        DB db = mongoclient.getDB(arg3);
        System.out.println("Mondb connected");
        DBCollection coll = db.getCollection(arg4);
        coll.remove(new BasicDBObject());


    }
    @Then("^Connect the cmdsbookres database in MongoDB \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" wiremock$")
    public void Connect_the_orsbookres_database_in_MongoDB(String arg1, Integer arg2, String arg3, String arg4) {
        MongoClient mongoclient = new MongoClient(arg1, arg2);
        DB db = mongoclient.getDB(arg3);
        System.out.println("Mondb connected");
        DBCollection coll = db.getCollection(arg4);
        coll.remove(new BasicDBObject());

    }

}
