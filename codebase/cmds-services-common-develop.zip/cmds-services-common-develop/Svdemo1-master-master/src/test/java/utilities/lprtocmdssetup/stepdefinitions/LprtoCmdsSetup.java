package utilities.lprtocmdssetup.stepdefinitions;

import com.mongodb.*;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertEquals;

public class LprtoCmdsSetup {

    String str = "";
    String postbody = "";
    String inputjson[]= new String[2];
    String actinputjson[]= new String[2];
    int removehead = 51;
    int count=0;
    int totalindex = 0;

    @Given("^Setup Lpr product hierarchy from MongoDB \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" wiremock$")
    public void inspera_testevent_from_MongoDB(String hostname, Integer portnum, String dbname,String collectionname,String productid)

    {
        MongoClient mongoclient = new MongoClient(hostname,portnum);
        DB db = mongoclient.getDB(dbname);
        DBCollection coll = db.getCollection(collectionname);
        DBCursor cursor = coll.find();
        int i=0;
        while(cursor.hasNext()) {

            DBObject result= cursor.next();
            str = new String(String.valueOf(result));
            Integer length = str.length();
            String subpostbody = str.substring(removehead,length);
            postbody = "{" + subpostbody;
            inputjson[i] = postbody;
            i++;
            totalindex = i ;
        }
    }

    @When("^User able to setup the product hierarchy details to Lpr \"([^\"]*)\",\"([^\"]*)\" wiremock$")
    public void User_able_to_POST_the_Insperatest_details_to_inspera(String BaseUrl, String Basepath) {
        while (count < totalindex) {
            postbody= inputjson[count];
            RestAssured.baseURI = BaseUrl;
            RestAssured.basePath = "";
            Response response = given().contentType(ContentType.TEXT).log().all().body(postbody).post(Basepath);
            response.prettyPrint();
            count++;
        }
    }


}



