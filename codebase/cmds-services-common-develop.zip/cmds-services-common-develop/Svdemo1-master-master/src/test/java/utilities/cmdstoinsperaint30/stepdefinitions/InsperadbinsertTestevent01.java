package utilities.cmdstoinsperaint30.stepdefinitions;

import com.mongodb.*;
import com.mongodb.util.JSON;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.FileReader;

public class InsperadbinsertTestevent01 {
    int cnt = 0;

    @Given("^Connect and insert Inspera Server in MongoDB \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" wiremock$")
    public void Connect_and_insert_Insperaser_in_MongoDB(String arg1, Integer arg2, String arg3, String arg4) {
        MongoClient mongoclient = new MongoClient(arg1, arg2);
        DB db = mongoclient.getDB(arg3);
        System.out.println("Mondb connected");
        DBCollection collstr = db.getCollection(arg4);
        String Var1 = "./src/test/java/testdata/cmdstoinspera/TesteventResponse";
        String Var3 = ".json";
        int count = 1;
        while (cnt < 2) {
            int Var2 = count;
            String pathstr = Var1 + Var2 + Var3;
            System.out.println("pathstr :" + pathstr);
            JSONParser parser = new JSONParser();
            try {
                //   Object obj = parser.parse(new FileReader("E:/selenium/projects/ServiseVirtualisation/src/test/java/testdata/Jsontest1.json"));
                Object obj = parser.parse(new FileReader(pathstr));
                JSONObject jsonObject = (JSONObject) obj;
                System.out.println("Json : " + jsonObject);
                DBObject object = (DBObject) JSON.parse(jsonObject.toString());
                collstr.insert(object);
                cnt++;
                count++;

            } catch (Exception e) {
                e.printStackTrace();
            }


        }

    }

    int counter = 0;

    @Given("^Connect and insert Inspera Request in MongoDB \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" wiremock$")
    public void Connect_and_insert_Insperareq_in_MongoDB(String arg1, Integer arg2, String arg3, String arg4) {
        MongoClient mongoclient = new MongoClient(arg1, arg2);
        DB db = mongoclient.getDB(arg3);
        System.out.println("Mondb connected");
        DBCollection collstr = db.getCollection(arg4);
        String Var1 = "./src/test/java/testdata/cmdstoinspera/TesteventRequest";
        String Var3 = ".json";
        int cntx = 1;
        while (counter < 2) {
            int Var2 = cntx;
            String pathstr = Var1 + Var2 + Var3;
            System.out.println("pathstr :" + pathstr);
            JSONParser parser = new JSONParser();
            try {
                //   Object obj = parser.parse(new FileReader("E:/selenium/projects/ServiseVirtualisation/src/test/java/testdata/Jsontest1.json"));
                Object obj = parser.parse(new FileReader(pathstr));
                JSONObject jsonObject = (JSONObject) obj;
                System.out.println("Json : " + jsonObject);
                DBObject object = (DBObject) JSON.parse(jsonObject.toString());
                collstr.insert(object);
                counter++;
                cntx++;

            } catch (Exception e) {
                e.printStackTrace();
            }
        }


    }

    int Counter2 = 0;

    @Then("^Connect and insert Inspera Response in MongoDB \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" wiremock$")
    public void Connect_and_insert_Insperares_in_MongoDB(String arg1, Integer arg2, String arg3, String arg4) {
        MongoClient mongoclient = new MongoClient(arg1, arg2);
        DB db = mongoclient.getDB(arg3);
        System.out.println("Mondb connected");
        DBCollection collstr = db.getCollection(arg4);
        String Var1 = "./src/test/java/testdata/cmdstoinspera/ExpectedResponse";
        String Var3 = ".json";
        int cntx = 1;
        while (Counter2 < 2) {
            int Var2 = cntx;
            String pathstr = Var1 + Var2 + Var3;
            System.out.println("pathstr :" + pathstr);
            JSONParser parser = new JSONParser();
            try {
                //   Object obj = parser.parse(new FileReader("E:/selenium/projects/ServiseVirtualisation/src/test/java/testdata/Jsontest1.json"));
                Object obj = parser.parse(new FileReader(pathstr));
                JSONObject jsonObject = (JSONObject) obj;
                System.out.println("Json : " + jsonObject);
                DBObject object = (DBObject) JSON.parse(jsonObject.toString());
                collstr.insert(object);
                Counter2++;
                cntx++;

            } catch (Exception e) {
                e.printStackTrace();
            }


        }

    }
}
