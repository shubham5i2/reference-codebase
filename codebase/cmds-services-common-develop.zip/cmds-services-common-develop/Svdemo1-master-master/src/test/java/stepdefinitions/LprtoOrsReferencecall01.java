package stepdefinitions;

import com.mongodb.*;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertEquals;



public class LprtoOrsReferencecall01 {

    String str = "";
    String verifybody = "";
    String postbody = "";
    String actpostbody = "";
    String ExpResponse_200 ="";
    String Response_200 = "200";
    String Response_400 = "400";
    String ExpResponse_400 ="";
    int removehead = 51 ;
    int removeheadplus = 51;
    int cnt=0;
    int totalindex = 0;
    int RESPONSE_CODE_200 = 200;
    int RESPONSE_CODE_400 = 400;
    int RESPONSE_CODE_404 = 404;
    int StartPosition = 13;
    int Responselength = 16;
    int startpos = 19;
    //String ActTranid = "{\"transactionId\":\"Tran123ABC\"}";
    String ExpTranid  ="";

    @Given("^User able to get ors reference request from MongoDB \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" wiremock$")
    public void User_able_to_get_ors_reference_request_from_MongoDB(String hostname, Integer portnum, String dbname,String collectionname,Integer referenceid)

    {
        MongoClient mongoclient = new MongoClient(hostname,portnum);
        DB db = mongoclient.getDB(dbname);
        DBCollection coll = db.getCollection(collectionname);
        DBObject query = new BasicDBObject("language.referenceId",new BasicDBObject("$eq", referenceid));
        DBObject result = coll.findOne(query);
        System.out.println("result: "+result);
        str = new String(String.valueOf(result));
        Integer length = str.length();
        String subpostbody = str.substring(removehead,length);
        postbody = "{" + subpostbody;
        System.out.println("postbody:"+postbody);
    }

    @When("^User able to get ors reference Expected result from MongoDB \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" wiremock$")
    public void User_able_to_get_ors_reference_Expected_result_from_MongoDB(String hostname, Integer portnum, String dbname,String collectionname,String productid) throws ParseException
    {
        MongoClient mongoclient = new MongoClient(hostname,portnum);
        DB db = mongoclient.getDB(dbname);
        DBCollection coll = db.getCollection(collectionname);
        DBCursor cursor = coll.find();
        int i=0;
        while(cursor.hasNext()) {
            DBObject result= cursor.next();
            str = new String(String.valueOf(result));
            Integer length = str.length();
            String subpostbody = str.substring(removeheadplus,length);
            System.out.println("subpostbody : " + subpostbody );
            verifybody = "{" + subpostbody;
            System.out.println("verifybody :"+ verifybody );
            String TranResponseCode = verifybody.substring(StartPosition,Responselength);
            System.out.println("TranResponseCode:" + TranResponseCode);
            Integer bodylength = verifybody.length();
            String Subverifybody = "{" + verifybody.substring(startpos,bodylength);
            System.out.println("Subverifybody:"+Subverifybody );

            JSONParser parser = new JSONParser();
            JSONObject ExpResponseconvert = (JSONObject) parser.parse(Subverifybody);
            System.out.println("ExpResponseconvert:"+ExpResponseconvert);
//            String TranResponseCode = verifybody.substring(StartPosition,Responselength);
//            System.out.println("TranResponseCode:" + TranResponseCode);

            if (TranResponseCode.equals(Response_200))
            {
                ExpResponse_200 = ExpResponseconvert.toString();
                System.out.println("ExpResponse_200:"+ExpResponse_200 );

            }
            if (TranResponseCode.equals(Response_400))
            {
                ExpResponse_400 = ExpResponseconvert.toString();
            }

            System.out.println("ExpResponse_200 :" + ExpResponse_200);
            System.out.println("ExpResponse_400 :" + ExpResponse_400);
            i++;

        }
    }

    @Then("^User able to verify the ors reference details from LPR to ORS \"([^\"]*)\",\"([^\"]*)\" wirmock$")
    public void User_able_to_verify_the_ors_reference_details_from_LPR_to_ORS(String ActUrl, String Actpath) throws ParseException {

        RestAssured.baseURI = ActUrl;
        RestAssured.basePath = "";
        Response response = given().contentType(ContentType.TEXT).log().all().body(postbody).post(Actpath);
        System.out.println("Response :" + response.asString());
        int ActResponseCode = response.getStatusCode();

        //   assertEquals(response.getStatusCode(),RESPONSE_CODE_200);
        String ActResponse = response.asString();
        System.out.println("expectedtran: "+ ExpResponse_200);
        System.out.println("Actualtran :  "+ ActResponse);
        if (ActResponseCode == RESPONSE_CODE_200)
        {
            assertEquals(ExpResponse_200, ActResponse);
        }

        if (ActResponseCode == RESPONSE_CODE_400)
        {
            assertEquals(ExpResponse_400, ActResponse);
        }
        response.prettyPrint();

    }

}


