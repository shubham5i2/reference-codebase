package stepdefinitions;

import com.mongodb.*;
import com.mongodb.util.JSON;
import com.sun.tools.xjc.reader.xmlschema.bindinfo.BIConversion;
import io.restassured.path.json.JsonPath;
import com.mongodb.util.JSON;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Assert;

import javax.management.Query;
import java.security.PrivateKey;
import java.util.List;

import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertEquals;

public class CmdstoOrsbookingcall01 {

    String str = "";
    String verifybody = "";
    String postbody = "";
    String actpostbody = "";
    String ExpResponse_200 ="";
    String Response_200 = "200";
    String Response_400 = "400";
    String ExpResponse_400 ="";
    int removehead = 51 ;
    int removeheadplus = 51;
    int cnt=0;
    int totalindex = 0;
    int RESPONSE_CODE_200 = 200;
    int RESPONSE_CODE_400 = 400;
    int RESPONSE_CODE_404 = 404;
    int StartPosition = 13;
    int Responselength = 16;
    int startpos = 19;
    //String ActTranid = "{\"transactionId\":\"Tran123ABC\"}";
    String ExpTranid  ="";

    @Given("^Booking Registrations Response from MongoDB \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" wiremock$")
    public void Booking_Registrations_from_MongoDB(String hostname, Integer portnum, String dbname,String collectionname,int productid)

    {
        MongoClient mongoclient = new MongoClient(hostname,portnum);
        DB db = mongoclient.getDB(dbname);
        DBCollection coll = db.getCollection(collectionname);
        DBObject query = new BasicDBObject("externalBookingId",new BasicDBObject("$eq", productid));
        DBObject result = coll.findOne(query);
        System.out.println("result: "+result);
        str = new String(String.valueOf(result));
        Integer length = str.length();
        String subpostbody = str.substring(removehead,length);
        postbody = "{" + subpostbody;
        System.out.println("postbody:"+postbody);
    }

    @When("^Booking Expected result from MongoDB \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" wiremock$")
    public void Booking_Expected_result_from_MongoDB(String hostname, Integer portnum, String dbname,String collectionname,String productid) throws ParseException
    {
        MongoClient mongoclient = new MongoClient(hostname,portnum);
        DB db = mongoclient.getDB(dbname);
        DBCollection coll = db.getCollection(collectionname);
        DBCursor cursor = coll.find();
        int i=0;
        while(cursor.hasNext()) {
            DBObject result= cursor.next();
            str = new String(String.valueOf(result));
            Integer length = str.length();
            String subpostbody = str.substring(removeheadplus,length);
            System.out.println("subpostbody : " + subpostbody );
            verifybody = "{" + subpostbody;
            System.out.println("verifybody :"+ verifybody );
            String TranResponseCode = verifybody.substring(StartPosition,Responselength);
            System.out.println("TranResponseCode:" + TranResponseCode);
            Integer bodylength = verifybody.length();
            String Subverifybody = "{" + verifybody.substring(startpos,bodylength);
            System.out.println("Subverifybody:"+Subverifybody );

            JSONParser parser = new JSONParser();
            JSONObject ExpResponseconvert = (JSONObject) parser.parse(Subverifybody);
            System.out.println("ExpResponseconvert:"+ExpResponseconvert);
//            String TranResponseCode = verifybody.substring(StartPosition,Responselength);
//            System.out.println("TranResponseCode:" + TranResponseCode);

            if (TranResponseCode.equals(Response_200))
            {
                ExpResponse_200 = ExpResponseconvert.toString();
                System.out.println("ExpResponse_200:"+ExpResponse_200 );

            }
            if (TranResponseCode.equals(Response_400))
            {
                ExpResponse_400 = ExpResponseconvert.toString();
            }

            System.out.println("ExpResponse_200 :" + ExpResponse_200);
            System.out.println("ExpResponse_400 :" + ExpResponse_400);
            i++;

        }
    }

    @Then("^User able to verify the POST details from cmds \"([^\"]*)\",\"([^\"]*)\" wirmock$")
    public void User_able_to_verify_the_POST_details_from_cmds(String ActUrl, String Actpath) throws ParseException {

        RestAssured.baseURI = ActUrl;
        RestAssured.basePath = "";
        Response response = given().contentType(ContentType.TEXT).log().all().body(postbody).post(Actpath);
        System.out.println("Response :" + response.asString());
        int ActResponseCode = response.getStatusCode();

        //   assertEquals(response.getStatusCode(),RESPONSE_CODE_200);
        String ActResponse = response.asString();
        System.out.println("expectedtran: "+ ExpResponse_200);
        System.out.println("Actualtran :  "+ ActResponse);
        if (ActResponseCode == RESPONSE_CODE_200)
        {
            assertEquals(ExpResponse_200, ActResponse);
        }

        if (ActResponseCode == RESPONSE_CODE_400)
        {
            assertEquals(ExpResponse_400, ActResponse);
        }
        response.prettyPrint();

    }

}





//            System.out.println("jsosn oject const:" + expectedjson);
//            String ExpectStr  = response.asString();
//            String ExpectStr1 = String.valueOf(actpostbody);
//            String ExpectStr = ExpectStr1.trim();
//              ResponseBody bodynew = response.getBody();

//    JSONParser parser = new JSONParser();
//    JSONObject expectedjson = (JSONObject) parser.parse(actpostbody);

//
//            JsonPath jsonPathEvaluator = response.jsonPath();
//            System.out.println("jsonPathEvaluator" + jsonPathEvaluator);
//            String externalBookingId = jsonPathEvaluator.get("externalBookingId");
//            String externalTestTakerId = jsonPathEvaluator.get("testTaker.externalTestTakerId");
//            System.out.println("externalBookingId: " + externalBookingId);
//            System.out.println("externalTestTakerId : " + externalTestTakerId);
//            List<String> cnexternalBookingLineId = jsonPathEvaluator.getList("bookingLines.externalBookingLineId");
//            for (String externalBookingLineId : cnexternalBookingLineId) {
//                System.out.println("externalBookingLineId: " + externalBookingLineId);
//            }
//            String Var1 = "{\"request\":{\"method\":\"POST\",\"url\":\"/bookings\"},\"response\":{\"status\":200,\"jsonBody\":{\"externalBookingId\":\"";
//            String Var2 = "\",\"testTaker\":{\"testTakerId\":0,\"externalTestTakerId\":\"";
//            String Var3 = "\"},\"bookingLines\":[{\"externalBookingLineId\":\"";
//            String Var4 = "\",\"bookingLineId\":1234}],\"bookingId\":1234,\"candidateNumber\": \"213232\",\"compositeCandidateId\":\"AU24020123456\"}}}";
//            String Var5 = Var1 + externalBookingId + Var2 + externalTestTakerId + Var3 + externalBookingId + Var4;
//            MongoClient mongoclient = new MongoClient("localhost", 27017);
//            DB db = mongoclient.getDB("cmdsdb");
//            DBCollection collstr = db.getCollection("output");
//            System.out.println("Mondb connected");
//            DBObject object = (DBObject) JSON.parse(Var5);
//            collstr.insert(object);

//mongo db cursor logic:
//======================
//        {
//        MongoClient mongoclient = new MongoClient(hostname,portnum);
//        DB db = mongoclient.getDB(dbname);
//        DBCollection coll = db.getCollection(collectionname);
//        DBCursor cursor = coll.find();
//        int i=0;
//        while(cursor.hasNext()) {
//
//        DBObject result= cursor.next();
//        str = new String(String.valueOf(result));
//        Integer length = str.length();
//        String subpostbody = str.substring(removehead,length);
//        postbody = "{" + subpostbody;
//        i++;
//        totalindex = i ;
//        }
//        }
//Read from mongo DB and convertion:

//    public void Booking_Expectedresult_from_MongoDB(String hostname, Integer portnum, String dbname,String collectionname,String productid) throws ParseException
//    {
//        MongoClient mongoclient = new MongoClient(hostname,portnum);
//        DB db = mongoclient.getDB(dbname);
//        DBCollection coll = db.getCollection(collectionname);
//        DBCursor cursor = coll.find();
//        int i=0;
//        while(cursor.hasNext()) {
//            DBObject result= cursor.next();
//            str = new String(String.valueOf(result));
//            Integer length = str.length();
//            String subpostbody = str.substring(removehead,length);
//            verifybody = "{" + subpostbody;
//            JSONParser parser = new JSONParser();
//            JSONObject ActTranidconvert = (JSONObject) parser.parse(verifybody);
//            ExpTranid = ActTranidconvert.toString();
//            System.out.println("expected :" + ExpTranid);
//            i++;
//
//        }
//    }
