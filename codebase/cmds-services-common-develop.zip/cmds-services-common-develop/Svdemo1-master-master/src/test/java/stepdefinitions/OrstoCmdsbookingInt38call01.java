package stepdefinitions;

import com.mongodb.*;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertEquals;

public class OrstoCmdsbookingInt38call01 {

    String str = "";
    String verifybody = "";
    String postbody = "";
    String actpostbody = "";
    String ExpResponse_200 ="";
    String ExpResponse_202 ="";
    String ExpResponse_403 ="";
    String Response_200 = "200";
    String Response_202 = "202";
    String Response_400 = "400";
    String Response_403 = "403";
    String ExpResponse_400 ="";
    int removehead = 51 ;
    int removeheadplus = 51;
    Integer ExpectedTranLength_202 = 62;
    Integer ExpectedTranLength_403 = 42;
    int cnt=0;
    int totalindex = 0;
    int RESPONSE_CODE_200 = 200;
    int RESPONSE_CODE_202 = 202;
    int RESPONSE_CODE_400 = 400;
    int RESPONSE_CODE_403 = 403;
    int RESPONSE_CODE_404 = 404;
    int StartPosition = 13;
    int Responselength = 16;
    int startpos = 19;
    //String ActTranid = "{\"transactionId\":\"Tran123ABC\"}";
    String ExpTranid  ="";

    @Given("^Booking Registrations for Int38 from MongoDB \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" wiremock$")
    public void Booking_Registrations_for_Int38_from_MongoDB(String hostname, Integer portnum, String dbname,String collectionname,int productid)

    {
        MongoClient mongoclient = new MongoClient(hostname,portnum);
        DB db = mongoclient.getDB(dbname);
        DBCollection coll = db.getCollection(collectionname);
        DBObject query = new BasicDBObject("productId",new BasicDBObject("$eq", productid));
        DBObject result = coll.findOne(query);
        System.out.println("result: "+result);
        str = new String(String.valueOf(result));
        Integer length = str.length();
        String subpostbody = str.substring(removehead,length);
        postbody = "{" + subpostbody;
    }

    @When("^Booking Expected result for Int38 from MongoDB \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" wiremock$")
    public void Booking_Expected_result_for_Int38_from_MongoDB(String hostname, Integer portnum, String dbname,String collectionname,String productid) throws ParseException
    {
        MongoClient mongoclient = new MongoClient(hostname,portnum);
        DB db = mongoclient.getDB(dbname);
        DBCollection coll = db.getCollection(collectionname);
        DBCursor cursor = coll.find();
        int i=0;
        while(cursor.hasNext()) {
            DBObject result= cursor.next();
            str = new String(String.valueOf(result));
            Integer length = str.length();
            String subpostbody = str.substring(removeheadplus,length);
            verifybody = "{" + subpostbody;
            Integer bodylength = verifybody.length();
            String Subverifybody = "{" + verifybody.substring(startpos,bodylength);
            JSONParser parser = new JSONParser();
            JSONObject ExpResponseconvert = (JSONObject) parser.parse(Subverifybody);
            String TranResponseCode = verifybody.substring(StartPosition,Responselength);
            System.out.println("TranResponseCode:" + TranResponseCode);

            if (TranResponseCode.equals(Response_200))
            {
                ExpResponse_200 = ExpResponseconvert.toString();
                System.out.println("ExpResponse_200:"+ExpResponse_200 );
            }


            if (TranResponseCode.equals(Response_202))
            {
                ExpResponse_202 = ExpResponseconvert.toString();
                System.out.println("ExpResponse_202:"+ExpResponse_202 );
            }
            if (TranResponseCode.equals(Response_403))
            {
                ExpResponse_403 = ExpResponseconvert.toString();
                System.out.println("ExpResponse_403:"+ExpResponse_403 );
            }
            if (TranResponseCode.equals(Response_400))
            {
                ExpResponse_400 = ExpResponseconvert.toString();
            }

            i++;

        }
    }

    @Then("^User able to verify the POST details for Int38 from ors \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" wirmock$")
    public void User_able_to_verify_the_POST_details_for_Int38_from_ors(String ActUrl, String Actpath, String callbackurl) throws ParseException {

        RestAssured.baseURI = ActUrl;
        RestAssured.basePath = "";
        Response response = given().headers("callbackUrl", callbackurl)
                .contentType(ContentType.TEXT).log().all().body(postbody).post(Actpath);
        System.out.println("Response :" + response.asString());
        int ActResponseCode = response.getStatusCode();
        String ActResponse = response.asString();
        System.out.println("Actualtran :  "+ ActResponse);
        Integer ActualResponselen = ActResponse.length();
        System.out.println("ActualResponselen :  "+ ActualResponselen);

        if (ActResponseCode == RESPONSE_CODE_200)
        {
            assertEquals(RESPONSE_CODE_200, ActResponseCode);
            assertEquals(ExpResponse_200, ActResponse);
        }

        if (ActResponseCode == RESPONSE_CODE_202)
        {
            assertEquals(RESPONSE_CODE_202, ActResponseCode);
            assertEquals(ExpectedTranLength_202 , ActualResponselen);
        }

        if (ActResponseCode == RESPONSE_CODE_400)
        {
            assertEquals(RESPONSE_CODE_400, ActResponseCode);
            assertEquals(ExpResponse_400, ActResponse);
        }
        if (ActResponseCode == RESPONSE_CODE_403)
        {
            assertEquals(RESPONSE_CODE_403, ActResponseCode);
            assertEquals(ExpectedTranLength_403 , ActualResponselen);
        }
        response.prettyPrint();

    }

}



