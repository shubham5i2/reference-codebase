function (user, context, callback) {
  const namespace = 'https://cmdsiz.com/';
  const assignedRoles = (context.authorization || {}).roles;
  const permissions = (context.authorization || {}).permissions;
 	
  const userAppMeta = user.app_metadata || {};
  let roles=[];
  
  let idTokenClaims = context.idToken || {};
  let accessTokenClaims = context.accessToken || {};
  
  if(Object.keys(userAppMeta).length === 0 && userAppMeta.constructor === Object){
  	roles=null;
    idTokenClaims[`${namespace}roles`] = roles;
    accessTokenClaims[`${namespace}roles`] = roles;
  }else{
    userAppMeta.custom_roles.cmds.roles.forEach(cmdsRole=>{
      roles.push(`l:${cmdsRole.location_uuid ? cmdsRole.location_uuid : ''}/g:${cmdsRole.group_uuid?cmdsRole.group_uuid:''}`);    
    });   
  idTokenClaims[`${namespace}partnerCode`] = userAppMeta.partner_code;
  idTokenClaims[`${namespace}nickname`] = user.nickname;
  idTokenClaims[`${namespace}id`] = user.user_id;
  idTokenClaims[`${namespace}roles`] = roles;
  idTokenClaims[`${namespace}clientId`]=context.clientID;
  idTokenClaims[`${namespace}email`] = user.email;
    
  accessTokenClaims[`${namespace}partnerCode`] = userAppMeta.partner_code;
  accessTokenClaims[`${namespace}nickname`] = user.nickname;
  accessTokenClaims[`${namespace}id`] = user.user_id;
  accessTokenClaims[`${namespace}roles`] = roles; 
  accessTokenClaims[`${namespace}email`] = user.email;
  accessTokenClaims[`${namespace}firstName`] = user.given_name;
  accessTokenClaims[`${namespace}lastName`] = user.family_name;
  } 

  context.idToken = idTokenClaims;
  context.accessToken = accessTokenClaims;
 
  callback(null, user, context);
}
