package com.cmds.auth0.validation.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.security.interfaces.RSAPublicKey;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.GrantedAuthority;

import com.auth0.jwk.InvalidPublicKeyException;
import com.auth0.jwk.Jwk;
import com.auth0.jwk.JwkException;
import com.auth0.jwk.JwkProvider;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.api.service.model.ClaimDetails;
import com.ielts.cmds.rbac.api.service.model.CmdsAuthentication;
import com.ielts.cmds.rbac.api.service.model.UserDetails;

@ExtendWith(MockitoExtension.class)
class JWTDecoderImplTest {

  String decodingExceptionToken =
      "syJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkJTT3YxZ21Zam1vSWNUZFpFcGN3XyJ9.eyJpc3MiOiJodHRwczovL2NtZHMtc2FuZGJveC5ldS5hdXRoMC5jb20vIiwic3ViIjoibGhCUXMzUmdFOFZ4ZkJLNVpuYUNwU0JhdENFQTdiazJAY2xpZW50cyIsImF1ZCI6Imh0dHBzOi8vY21kcy1zYW5kYm94LmV1LmF1dGgwLmNvbS9hcGkvdjIvIiwiaWF0IjoxNTkzNDQzNTY2LCJleHAiOjE1OTM1Mjk5NjYsImF6cCI6ImxoQlFzM1JnRThWeGZCSzVabmFDcFNCYXRDRUE3YmsyIiwic2NvcGUiOiJyZWFkOmNsaWVudF9ncmFudHMgY3JlYXRlOmNsaWVudF9ncmFudHMgZGVsZXRlOmNsaWVudF9ncmFudHMgdXBkYXRlOmNsaWVudF9ncmFudHMgcmVhZDp1c2VycyB1cGRhdGU6dXNlcnMgZGVsZXRlOnVzZXJzIGNyZWF0ZTp1c2VycyByZWFkOnVzZXJzX2FwcF9tZXRhZGF0YSB1cGRhdGU6dXNlcnNfYXBwX21ldGFkYXRhIGRlbGV0ZTp1c2Vyc19hcHBfbWV0YWRhdGEgY3JlYXRlOnVzZXJzX2FwcF9tZXRhZGF0YSByZWFkOnVzZXJfY3VzdG9tX2Jsb2NrcyBjcmVhdGU6dXNlcl9jdXN0b21fYmxvY2tzIGRlbGV0ZTp1c2VyX2N1c3RvbV9ibG9ja3MgY3JlYXRlOnVzZXJfdGlja2V0cyByZWFkOmNsaWVudHMgdXBkYXRlOmNsaWVudHMgZGVsZXRlOmNsaWVudHMgY3JlYXRlOmNsaWVudHMgcmVhZDpjbGllbnRfa2V5cyB1cGRhdGU6Y2xpZW50X2tleXMgZGVsZXRlOmNsaWVudF9rZXlzIGNyZWF0ZTpjbGllbnRfa2V5cyByZWFkOmNvbm5lY3Rpb25zIHVwZGF0ZTpjb25uZWN0aW9ucyBkZWxldGU6Y29ubmVjdGlvbnMgY3JlYXRlOmNvbm5lY3Rpb25zIHJlYWQ6cmVzb3VyY2Vfc2VydmVycyB1cGRhdGU6cmVzb3VyY2Vfc2VydmVycyBkZWxldGU6cmVzb3VyY2Vfc2VydmVycyBjcmVhdGU6cmVzb3VyY2Vfc2VydmVycyByZWFkOmRldmljZV9jcmVkZW50aWFscyB1cGRhdGU6ZGV2aWNlX2NyZWRlbnRpYWxzIGRlbGV0ZTpkZXZpY2VfY3JlZGVudGlhbHMgY3JlYXRlOmRldmljZV9jcmVkZW50aWFscyByZWFkOnJ1bGVzIHVwZGF0ZTpydWxlcyBkZWxldGU6cnVsZXMgY3JlYXRlOnJ1bGVzIHJlYWQ6cnVsZXNfY29uZmlncyB1cGRhdGU6cnVsZXNfY29uZmlncyBkZWxldGU6cnVsZXNfY29uZmlncyByZWFkOmhvb2tzIHVwZGF0ZTpob29rcyBkZWxldGU6aG9va3MgY3JlYXRlOmhvb2tzIHJlYWQ6YWN0aW9ucyB1cGRhdGU6YWN0aW9ucyBkZWxldGU6YWN0aW9ucyBjcmVhdGU6YWN0aW9ucyByZWFkOmVtYWlsX3Byb3ZpZGVyIHVwZGF0ZTplbWFpbF9wcm92aWRlciBkZWxldGU6ZW1haWxfcHJvdmlkZXIgY3JlYXRlOmVtYWlsX3Byb3ZpZGVyIGJsYWNrbGlzdDp0b2tlbnMgcmVhZDpzdGF0cyByZWFkOnRlbmFudF9zZXR0aW5ncyB1cGRhdGU6dGVuYW50X3NldHRpbmdzIHJlYWQ6bG9ncyByZWFkOnNoaWVsZHMgY3JlYXRlOnNoaWVsZHMgdXBkYXRlOnNoaWVsZHMgZGVsZXRlOnNoaWVsZHMgcmVhZDphbm9tYWx5X2Jsb2NrcyBkZWxldGU6YW5vbWFseV9ibG9ja3MgdXBkYXRlOnRyaWdnZXJzIHJlYWQ6dHJpZ2dlcnMgcmVhZDpncmFudHMgZGVsZXRlOmdyYW50cyByZWFkOmd1YXJkaWFuX2ZhY3RvcnMgdXBkYXRlOmd1YXJkaWFuX2ZhY3RvcnMgcmVhZDpndWFyZGlhbl9lbnJvbGxtZW50cyBkZWxldGU6Z3VhcmRpYW5fZW5yb2xsbWVudHMgY3JlYXRlOmd1YXJkaWFuX2Vucm9sbG1lbnRfdGlja2V0cyByZWFkOnVzZXJfaWRwX3Rva2VucyBjcmVhdGU6cGFzc3dvcmRzX2NoZWNraW5nX2pvYiBkZWxldGU6cGFzc3dvcmRzX2NoZWNraW5nX2pvYiByZWFkOmN1c3RvbV9kb21haW5zIGRlbGV0ZTpjdXN0b21fZG9tYWlucyBjcmVhdGU6Y3VzdG9tX2RvbWFpbnMgdXBkYXRlOmN1c3RvbV9kb21haW5zIHJlYWQ6ZW1haWxfdGVtcGxhdGVzIGNyZWF0ZTplbWFpbF90ZW1wbGF0ZXMgdXBkYXRlOmVtYWlsX3RlbXBsYXRlcyByZWFkOm1mYV9wb2xpY2llcyB1cGRhdGU6bWZhX3BvbGljaWVzIHJlYWQ6cm9sZXMgY3JlYXRlOnJvbGVzIGRlbGV0ZTpyb2xlcyB1cGRhdGU6cm9sZXMgcmVhZDpwcm9tcHRzIHVwZGF0ZTpwcm9tcHRzIHJlYWQ6YnJhbmRpbmcgdXBkYXRlOmJyYW5kaW5nIGRlbGV0ZTpicmFuZGluZyByZWFkOmxvZ19zdHJlYW1zIGNyZWF0ZTpsb2dfc3RyZWFtcyBkZWxldGU6bG9nX3N0cmVhbXMgdXBkYXRlOmxvZ19zdHJlYW1zIGNyZWF0ZTpzaWduaW5nX2tleXMgcmVhZDpzaWduaW5nX2tleXMgdXBkYXRlOnNpZ25pbmdfa2V5cyByZWFkOmxpbWl0cyB1cGRhdGU6bGltaXRzIiwiZ3R5IjoiY2xpZW50LWNyZWRlbnRpYWxzIn0.ixapKEQPKCUM24-Bzh4UHZNyPUiCI09SJZMJ2rE8UvoYuKn3mMKoqXu9qie2XOHkRqByAgbAtoWq1bk-sq0PgzF4wEb85El6LOJhZ5RqFXRUGJMi4RxWWL0j0GGP6J5PRqPiBbcZQkJibPstRL-bSynI8eJteN8CiruxY-oH4h5MTqXSbSd_Xd1PhWdBXkbtinjjFVmNAToqN4rTjIO4D5RQD_RXvJsGLhMLTreuVm6IcYY-IlHigYpTQb-jjBjHl7XpAGvSnohyuvOIKjLCM7Y-MM_RtaoniSjaEscI6k-7yrCt5Zo77O9ES23_pukNDWHweADy5OqA4OBTjXkpag";
  String jwkExceptionToken =
      "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJWaWduZXNoIE93biBLZXkiLCJpYXQiOjE1OTM2MjMyODIsImV4cCI6MTYyNTE1OTI4MiwiYXVkIjoid3d3LmV4YW1wbGUuY29tIiwic3ViIjoianJvY2tldEBleGFtcGxlLmNvbSIsIkdpdmVuTmFtZSI6IlZpZ25lc2giLCJTdXJuYW1lIjoiUHVzaGthcmFuIn0.UwEIdC0h02X83-g3-zupo3rzt5J2VswrDNAAgtoHQJY";
  String illegaArgExceptionToken = "";
  String validToken =
      "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkJTT3YxZ21Zam1vSWNUZFpFcGN3XyJ9.eyJodHRwczovL2NtZHNpei5jb20vcGFydG5lckNvZGUiOiJJRFAiLCJodHRwczovL2NtZHNpei5jb20vbmlja25hbWUiOiJzb21zZXR3YXIubSIsImh0dHBzOi8vY21kc2l6LmNvbS9pZCI6ImF1dGgwfDVmNGY5NWJjMTljMGM1MDA2OGM2NWQ3MyIsImh0dHBzOi8vY21kc2l6LmNvbS9yb2xlcyI6WyJsOmI1ZDA2YmZiLTE2NDAtNDNlOS1iNGMwLTJmMmRhZjc4ZmNiYy9nOjkwZDA5MWY4LTU3YmItNDkzMi1iNzVjLTk2M2Q0MDJkOGMwZiIsImw6NWQzZmNhNDAtMWU1Yi00OTFlLThjODUtYjJiOTAyYzI0NmJhL2c6NGFhNTIzMjgtNzgzYS00ZDhkLWFiNGMtY2JiNDFjM2I4ZjVlIl0sImlzcyI6Imh0dHBzOi8vY21kcy1zYW5kYm94LmV1LmF1dGgwLmNvbS8iLCJzdWIiOiJhdXRoMHw1ZjRmOTViYzE5YzBjNTAwNjhjNjVkNzMiLCJhdWQiOlsiY21kcy1zYW5kYm94LXVpLWFwaSIsImh0dHBzOi8vY21kcy1zYW5kYm94LmV1LmF1dGgwLmNvbS91c2VyaW5mbyJdLCJpYXQiOjE2MTM3MTY0MTMsImV4cCI6MTYxMzgwMjgxMywiYXpwIjoiNm5wSkhLS0ppR1pIa0xJUE41YUJXM25hRTBsQW1PblkiLCJzY29wZSI6Im9wZW5pZCBwcm9maWxlIGVtYWlsIn0.aY-iggm0jmN_KBxXkyqAKFULPg3XVrnef1DYln73sFkezslYpqR_jwonkh2LBw5uNsosg7rIxkmXWlX_zv3HL1BlpyOKN83-SJ1kUQWpA5V3PvrVY5gHK1LLUEbUC2Vog4IcbApIMXQD6gO-Ovwvsaxt6nyHH38paWQnjX76WCS0ylEfH9437DO3Z-FyUv8HvlTBumm9O_Dc7wanJCZuYQch4X4ISK2SlzUKLY-ZVQuargDCfj6JoITur4Bb0IBoqkBPEWWB7xec5ObYxl9MQxsOoLONi9bTRLOtqGaTl26yCyZrSSAh2peekDksMalTdBk1dkQdDZ_CNt8y849wTQ";

  static long cacheAndBucketSize = 10;
  static long leewayInSecond = 300000000;
  static long expiresInHours = 1;
  static long refillRateInMinutes = 1;
  static String auth0PublicEndpoint = "https://cmds-sandbox.eu.auth0.com/";
  static String auth0NamespaceRoles = "https://cmdsiz.com/roles";
  static String auth0NamespacePartnerCode = "https://cmdsiz.com/partnerCode";
  static String auth0NamespaceNickname = "https://cmdsiz.com/nickname";
  static String auth0NamespaceId = "https://cmdsiz.com/id";
  static String auth0NamespaceEmail = "https://cmdsiz.com/email";
  static String auth0NamespaceFirstName = "https://cmdsiz.com/firstName";
  static String auth0NamespaceLastName = "https://cmdsiz.com/lastName";

  @InjectMocks public static JWTDecoderImpl jwtValidation;

  @Mock DecodedJWT decodedJWTMock;
  @Mock private JwkProvider provider;
  @Mock private Jwk jwk;
  @Mock RSAPublicKey publicKey;
  @Mock Algorithm algorithm;

  @Spy
  public JWTDecoderImpl jwtValidationSpy =
      new JWTDecoderImpl(
          auth0PublicEndpoint,
          cacheAndBucketSize,
          expiresInHours,
          refillRateInMinutes,
          auth0NamespaceRoles,
          auth0NamespacePartnerCode,
          auth0NamespaceNickname,
          auth0NamespaceId,
          auth0NamespaceEmail,
          auth0NamespaceFirstName,
          auth0NamespaceLastName,
          leewayInSecond);

  @BeforeAll
  public static void initJwt() {

    jwtValidation =
        new JWTDecoderImpl(
            auth0PublicEndpoint,
            cacheAndBucketSize,
            expiresInHours,
            refillRateInMinutes,
            auth0NamespaceRoles,
            auth0NamespacePartnerCode,
            auth0NamespaceNickname,
            auth0NamespaceId,
            auth0NamespaceEmail,
            auth0NamespaceFirstName,
            auth0NamespaceLastName,
            leewayInSecond) {
          void verifyTokenUsingAlgorithmInst(final DecodedJWT jwt) {};
        };
  }

  @Test
  void Validate_decodeAccessTokenWhenInValidJWTTokenPassThenThrowsException()
      throws InvalidPublicKeyException, JwkException {

    doReturn(decodedJWTMock).when(jwtValidationSpy).decodedJWT(jwkExceptionToken);
    doThrow(JwkException.class)
        .when(jwtValidationSpy)
        .verifyTokenUsingAlgorithmInst(decodedJWTMock);

    assertThrows(
        RbacValidationException.class, () -> jwtValidationSpy.decodeAccessToken(jwkExceptionToken));
  }

  @Test
  void Validate_decodeAccessTokenWhenInValidJWTTokenPassThenThrowsExceptionForInvalidPublicKey()
      throws InvalidPublicKeyException, JwkException {

    doReturn(decodedJWTMock).when(jwtValidationSpy).decodedJWT(jwkExceptionToken);
    doThrow(InvalidPublicKeyException.class)
        .when(jwtValidationSpy)
        .verifyTokenUsingAlgorithmInst(decodedJWTMock);

    assertThrows(
        RbacValidationException.class, () -> jwtValidationSpy.decodeAccessToken(jwkExceptionToken));
  }

  @Test
  void Validate_decodeAccessToken() throws RbacValidationException {
    CmdsAuthentication decodeAccessToken = jwtValidation.decodeAccessToken(validToken);

    Collection<GrantedAuthority> authorities = decodeAccessToken.getAuthorities();

    List<ClaimDetails> actualClaimList =
        authorities.stream().map(claim -> (ClaimDetails) claim).collect(Collectors.toList());

    List<String> expectedAuths =
        Arrays.asList(
            new String[] {
              "l:b5d06bfb-1640-43e9-b4c0-2f2daf78fcbc/g:90d091f8-57bb-4932-b75c-963d402d8c0f",
              "l:5d3fca40-1e5b-491e-8c85-b2b902c246ba/g:4aa52328-783a-4d8d-ab4c-cbb41c3b8f5e"
            });

    assertTrue(
        actualClaimList.stream().allMatch(claim -> expectedAuths.contains(claim.getAuthority())));

    String id = (String) decodeAccessToken.getPrincipal();
    UserDetails userDetails = decodeAccessToken.getUserDetails();

    assertEquals("IDP", userDetails.getPartnerCode());
    assertEquals("somsetwar.m", userDetails.getNickName());
    assertEquals("auth0|5f4f95bc19c0c50068c65d73", id);
  }

  @Test
  void inValidate_decodeAccessToken() throws RbacValidationException {
    String invalidRoleToken =
        "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkJTT3YxZ21Zam1vSWNUZFpFcGN3XyJ9.eyJpc3MiOiJodHRwczovL2NtZHMtc2FuZGJveC5ldS5hdXRoMC5jb20vIiwic3ViIjoiYXV0aDB8NWY0Zjk1YmMxOWMwYzUwMDY4YzY1ZDczIiwiYXVkIjpbImNtZHMtc2FuZGJveC11aS1hcGkiLCJodHRwczovL2NtZHMtc2FuZGJveC5ldS5hdXRoMC5jb20vdXNlcmluZm8iXSwiaWF0IjoxNjExOTM2ODc3LCJleHAiOjE2MTIwMjMyNzcsImF6cCI6IjZucEpIS0tKaUdaSGtMSVBONWFCVzNuYUUwbEFtT25ZIiwic2NvcGUiOiJvcGVuaWQgcHJvZmlsZSBlbWFpbCJ9.Uircny8leDmmLJsMENfysTq_P6WuYdxwLk8Wntmri1FCciA8he3rsUherGkeH41-Dl9n0TWWN7CmgcsQgnfJpvKsGEk0mGROhpY5PRV1noZFW1P-0F3DTyNT8b-k_SSPHr3EJXoi20TTPkxeWcNVK2lTn7GC4GALpMBxQ1SLQfGIdx7deazmiBJYMGVKmTiVGaQp06U_sLWPLx-izCmEYJ7F2zX0eOdl10QvN-Y8C0mETNqNx0b6CWjcDmWxH24LkuetG7BO8yQ2VY_5oOv04pMXSdCVNqhkbWff_jGEOhle9ZqrUw8H_ywxcYUR1i2rpG7pP6HrAIrP1gn0rXKGpA";

    CmdsAuthentication decodeAccessToken = jwtValidation.decodeAccessToken(invalidRoleToken);

    String nickname = (String) decodeAccessToken.getPrincipal();
    UserDetails userDetails = decodeAccessToken.getUserDetails();

    assertEquals("", userDetails.getPartnerCode());
    assertEquals("", nickname);
  }

  @Test
  void Validate_publicKeyPassThenReturnPublicKey() throws JwkException {
    when(jwk.getPublicKey()).thenReturn(publicKey);

    RSAPublicKey publicKey1 = jwtValidation.publicKey(jwk);
    assertNotNull(publicKey1);
  }

  @Test
  void validate_jwtVerifierMethodPassThenReturnJWTVerifier() throws JwkException {
    JWTVerifier jwtVerifier = jwtValidation.jwtVerifier(algorithm);
    assertNotNull(jwtVerifier);
  }
}
