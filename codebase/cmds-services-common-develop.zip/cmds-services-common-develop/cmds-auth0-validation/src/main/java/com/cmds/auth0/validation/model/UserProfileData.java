package com.cmds.auth0.validation.model;

import java.util.List;

import com.ielts.cmds.rbac.api.service.model.ClaimDetails;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class UserProfileData {
  private String partnerCode;
  private String nickName;
  private String id;
  private String email;
  private String firstName;
  private String lastName;
  private List<ClaimDetails> claimDetails;
}