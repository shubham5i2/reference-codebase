package com.cmds.auth0.validation.service;

import java.security.interfaces.RSAPublicKey;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.auth0.jwk.InvalidPublicKeyException;
import com.auth0.jwk.Jwk;
import com.auth0.jwk.JwkException;
import com.auth0.jwk.JwkProvider;
import com.auth0.jwk.JwkProviderBuilder;
import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.exceptions.SignatureVerificationException;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.cmds.auth0.validation.model.UserProfileData;
import com.ielts.cmds.rbac.api.service.JWTDecoder;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.api.service.model.ClaimDetails;
import com.ielts.cmds.rbac.api.service.model.CmdsAuthentication;
import com.ielts.cmds.rbac.api.service.model.UserDetails;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class JWTDecoderImpl implements JWTDecoder {

  private JwkProvider provider;

  private String auth0Endpoint;

  private String auth0NamespaceRoles;

  private String auth0NamespacePartnerCode;

  private String auth0NamespaceNickname;

  private String auth0NamespaceId;
  
  private String auth0NamespaceEmail;
  
  private String auth0NamespaceFirstName;
  
  private String auth0NamespaceLastName;

  private long leewayInSecond;

  static final String regexLocationUuid = "[l]:([A-Za-z0-9+-]+[^\\/])";
  final Pattern patternLocationUuid = Pattern.compile(regexLocationUuid, Pattern.MULTILINE);

  static final String regexUserGroupUuid = "[g]:([A-Za-z0-9+-]+[^\\/])";
  final Pattern patternuserGroupUuid = Pattern.compile(regexUserGroupUuid, Pattern.MULTILINE);

  /**
   * @param auth0PublicEndpoint
   * @param cacheAndBucketSize: cacheSize number of jwk to cache,<br>
   *     bucketSize max number of jwks to deliver in the given rate.
   * @param expiresInHours : expiresIn amount of time the jwk will be cached
   * @param refillRateInMinutes : refillRate amount of time to wait before a jwk can the jwk will be
   *     cached
   * @param auth0NamespaceRoles2
   * @param auth0NamespacePartnerCode2
   * @param auth0NamespaceNickname2
   * @param leewayInSecond
   */
  public JWTDecoderImpl(
      final String auth0PublicEndpoint,
      final long cacheAndBucketSize,
      final long expiresInHours,
      final long refillRateInMinutes,
      final String auth0NamespaceRoles,
      final String auth0NamespacePartnerCode,
      final String auth0NamespaceNickname,
      final String auth0NamespaceId,
      final String auth0NamespaceEmail,
      final String auth0NamespaceFirstName,
      final String auth0NamespaceLastName,
      final long leewayInSecond) {

    this.auth0Endpoint = auth0PublicEndpoint;
    this.leewayInSecond = leewayInSecond;
    this.auth0NamespaceRoles = auth0NamespaceRoles;
    this.auth0NamespacePartnerCode = auth0NamespacePartnerCode;
    this.auth0NamespaceNickname = auth0NamespaceNickname;
    this.auth0NamespaceId = auth0NamespaceId;
    this.auth0NamespaceEmail = auth0NamespaceEmail;
    this.auth0NamespaceFirstName = auth0NamespaceFirstName;
    this.auth0NamespaceLastName = auth0NamespaceLastName;
    provider =
        new JwkProviderBuilder(auth0PublicEndpoint)
            .cached(cacheAndBucketSize, expiresInHours, TimeUnit.HOURS)
            .rateLimited(cacheAndBucketSize, refillRateInMinutes, TimeUnit.MINUTES)
            .build();
  }

  /**
   * This method aim's to convert jwtToken to DecodedJWT
   *
   * @param jwtToken
   * @return
   * @throws JWTDecodeException
   */
  DecodedJWT decodedJWT(final String jwtToken) throws JWTDecodeException {
    final DecodedJWT decodedJWT = JWT.decode(jwtToken);
    return decodedJWT;
  }

  /**
   * This method aim's to convert DecodedJwt to JWK
   *
   * @param jwt
   * @return
   * @throws SignatureVerificationException
   * @throws JwkException
   */
  private Jwk jwk(final DecodedJWT jwt) throws SignatureVerificationException, JwkException {
    final Jwk jwk = provider.get(jwt.getKeyId());
    return jwk;
  }

  /**
   * This method aim's to get RSAPublicKey from jwk object
   *
   * @param jwk
   * @return
   * @throws InvalidPublicKeyException
   */
  RSAPublicKey publicKey(final Jwk jwk) throws InvalidPublicKeyException {
    final RSAPublicKey publicKey = (RSAPublicKey) jwk.getPublicKey();
    return publicKey;
  }

  /**
   * This method aim's to return JWTVerifier object using Algorithm obj
   *
   * @param algorithm
   * @return
   */
  JWTVerifier jwtVerifier(final Algorithm algorithm) {
    final JWTVerifier verifier =
        JWT.require(algorithm)
            .withIssuer(auth0Endpoint)
            .acceptExpiresAt(leewayInSecond)
            .build(); // Reusable verifier instance
    return verifier;
  }

  /**
   * This method aim's to extract locationUuid from string locationUuid =
   * "l:08c4d741-31a5-48a7-a73a-1e019078f959/g:84c53648-98a4-4f69-8000-2893b62fd39a";
   *
   * @param locationUuid
   * @return
   */
  private UUID extractLocationUuid(final String locationUuid) {

    final Matcher matcherLocation = patternLocationUuid.matcher(locationUuid);
    UUID extractedLocationUuid = null;
    while (matcherLocation.find()) {
      extractedLocationUuid = UUID.fromString(matcherLocation.group(1));
      break;
    }
    return extractedLocationUuid;
  }

  /**
   * This method aim's to extract Product from string
   *
   * @param userGroupUuid
   * @return
   */
  private UUID extractGroupUuid(final String userGroupUuid) {
    // final String role = "l:building1/r:EXAMINER/p:CB-L";
    final Matcher matcherProduct = patternuserGroupUuid.matcher(userGroupUuid);
    UUID extractedGroupUuid = null;
    while (matcherProduct.find()) {
      extractedGroupUuid = UUID.fromString(matcherProduct.group(1));
      break;
    }
    return extractedGroupUuid;
  }

  /**
   * This method convert List of string to List of claims object
   *
   * @param claims
   * @return
   */
  private List<ClaimDetails> convertClaimStringToClaimDetails(final List<String> claims) {
    final List<ClaimDetails> claimDetails =
        claims
            .stream()
            .map(
                claim -> {
                  return new ClaimDetails(extractLocationUuid(claim), extractGroupUuid(claim));
                })
            .collect(Collectors.toList());
    return claimDetails;
  }

  /**
   * @param jwt
   * @throws JwkException
   * @throws InvalidPublicKeyException
   */
  void verifyTokenUsingAlgorithmInst(final DecodedJWT jwt)
      throws JwkException, InvalidPublicKeyException {
    final Jwk jwk = jwk(jwt);
    final RSAPublicKey publicKey = publicKey(jwk);
    final Algorithm algorithm = Algorithm.RSA256(publicKey, null);
    algorithm.verify(jwt);

    // Validate JTW signature
    final JWTVerifier jwtVerifier = jwtVerifier(algorithm);
    jwtVerifier.verify(jwt);
  }

  private Map<String, Claim> getClaims(final String jwtToken) throws RbacValidationException {
    Map<String, Claim> claims = null;

    try {
      final DecodedJWT jwt = decodedJWT(jwtToken);
      verifyTokenUsingAlgorithmInst(jwt);
      claims = jwt.getClaims(); // Key is the Claim name
    } catch (InvalidPublicKeyException e) {
      log.error(" InvalidPublicKeyException: " + e);
      throw new RbacValidationException(e.getMessage(), e);
    } catch (JwkException e) {
      log.error(" JwkException: " + e);
      throw new RbacValidationException(e.getMessage(), e);
    }
    return claims;
  }

  private UserProfileData getUserData(final String jwtToken) throws RbacValidationException {

    final Map<String, Claim> claims = getClaims(jwtToken);

    final List<String> claimList =
        Objects.nonNull(claims.get(auth0NamespaceRoles))
            ? claims.get(auth0NamespaceRoles).asList(String.class)
            : Collections.emptyList();

    final String partnerCode =
        Objects.nonNull(claims.get(auth0NamespacePartnerCode))
            ? claims.get(auth0NamespacePartnerCode).asString()
            : "";

    final String nickName =
        Objects.nonNull(claims.get(auth0NamespaceNickname))
            ? claims.get(auth0NamespaceNickname).asString()
            : "";

    final String id =
        Objects.nonNull(claims.get(auth0NamespaceId))
            ? claims.get(auth0NamespaceId).asString()
            : "";
            
    final String email =
        Objects.nonNull(claims.get(auth0NamespaceEmail))
                        ? claims.get(auth0NamespaceEmail).asString()
                        : "";

    final String firstName =
         Objects.nonNull(claims.get(auth0NamespaceFirstName))
                        ? claims.get(auth0NamespaceFirstName).asString()
                        : "";

    final String lastName =
         Objects.nonNull(claims.get(auth0NamespaceLastName))
                        ? claims.get(auth0NamespaceLastName).asString()
                        : "";
                                               
                        

    return UserProfileData.builder()
        .claimDetails(convertClaimStringToClaimDetails(claimList))
        .partnerCode(partnerCode)
        .nickName(nickName)
        .id(id)
        .email(email)
        .firstName(firstName)
        .lastName(lastName)
        .build();
  }

  @Override
  public CmdsAuthentication decodeAccessToken(final String jwtToken)
      throws RbacValidationException {

    final UserProfileData userProfileDetails = getUserData(jwtToken);
    final List<ClaimDetails> claimDetails = userProfileDetails.getClaimDetails();

    final UserDetails userDetails =
        UserDetails.builder()
            .partnerCode(userProfileDetails.getPartnerCode())
            .nickName(userProfileDetails.getNickName())
            .id(userProfileDetails.getId())
            .email(userProfileDetails.getEmail())
            .firstName(userProfileDetails.getFirstName())
            .lastName(userProfileDetails.getLastName())
            .build();

    return new CmdsAuthentication(userProfileDetails.getId(), "", claimDetails, userDetails);
  }
}
