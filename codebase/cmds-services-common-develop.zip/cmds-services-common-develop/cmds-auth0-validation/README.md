# Introduction  
This is a spring boot custom library project which used in other project as a dependency to validate **auth0 JWT signature**.  
It depends on two library recommended by auth0 1) [java-jwt](https://github.com/auth0/java-jwt) 2) [jwks-rsa-java](https://github.com/auth0/jwks-rsa-java), inorder to poll public key and cache the key in the application.

> This documentation is only for how to use library in the mx not for mainataining library.  
# Why need this library?
Our Mx needs to validate the signature of auth0 jwt token on each message received at (JMS listener) from SQS.To check token is **not tampered**. To achieve this, we need a signature verification library to avoid redundant code in all MX and to apply indsutry standards.

#How to use in the MX?
The **jwtSignatureValidation** has been implemented in JwtValidation class which returns as a boolean value on passing String argument. i.e JWT token.  

>Any message received by jmslistener should validate token signature first to proceed business logic implemenation.

This project is been configured with pipeline to publish to [Nexus artefact](https://nexus.shared.cmdsiz.com/#browse/browse:ielts-cmds-snap:com%2Fielts%2Fcmds%2Fcommon%2Fcmds-auth0-validation) as a maven module. 

We can add in the **pom.xml** of the repective MX like this
```
<dependency>  
  <groupId>com.ielts.cmds.common</groupId>  
  <artifactId>cmds-auth0-validation</artifactId>  
  <version>0.0.1-SNAPSHOT</version>  
</dependency
```
>Note: on version changes, please do change the version in pom.xml

In MX, Inside any configuration class. i.e(@Configuration/@Component),Whatever you find relevant to your requirement, add below snippet to it.  We are leveraging the use of bean annotation.

```
	@Value("${auth0.publicEndpoint}")
	private String auth0PublicEndpoint;

	@Bean
	public JwtValidation jwtSignatureValidation() {
		JwtValidation jwtValidation = new JwtValidation(auth0PublicEndpoint);
		return jwtValidation;
	}
```

Next, use the bean configured by initializing in the JmsListener class(where messages are read from SQS) and call the validation method which returns boolean value by using the below the snippet.

```	
@Autowired
JwtValidation jwtSignatureValidation;

	public boolean jwtSignatureValidation(String token) {
		return jwtSignatureValidation.jwtSignatureValidation(token);	 
	}

	@JmsListener(destination = "BookingEventQueueWithAuth0")
	public void onMessage(Message sqsMessage) {
		/*
		parsethe messaage and get jwt token.
		Call the below function to check the signature validation
		*/
		Boolean valid = jwtSignatureValidation(<token from message>);
		if(!valid){
			return "any" or throw error on your requirement
		}
		.... continue business logic
	}

```

# Pipeline

As mentioned earlier, the library is deployed to nexus with CI/CD. refer file *cmdsAuth0Validation-ci.yml*  

## Change Log

### 0.0.8 (Baseline Release)




