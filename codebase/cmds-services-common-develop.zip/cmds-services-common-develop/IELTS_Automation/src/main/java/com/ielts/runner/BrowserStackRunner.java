package com.ielts.runner;
import com.browserstack.BrowserStackSerenityTest;
import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;

import java.util.stream.Stream;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
		 features = {"src/main/resources/features/UI_Automation/Booking/organisation_Search.feature","src/main/resources/features/UI_Automation/Booking/organisation_Searchorg.feature"}
		 ,glue="com/ielts/ui/stepdefinition",
		monochrome = true,
		strict = true,
		dryRun=false,
		tags={"@srchscore,@srchorg,@all"}
		 
		 )



public final class BrowserStackRunner extends BrowserStackSerenityTest {
	private static String[] defaultOptions = {
			"--glue", "com/ielts/ui/stepdefinition",
			"--plugin", "pretty",
			"--plugin", "json:cucumber.json"
	};

	public static void main(String[] args) throws Throwable {
		Stream<String> cucumberOptions = Stream.concat(Stream.of(defaultOptions), Stream.of(args));
		cucumber.api.cli.Main.main(cucumberOptions.toArray(String[]::new));
	}
}

		








	

	
	
		
	
	
		
	
	
		

	
