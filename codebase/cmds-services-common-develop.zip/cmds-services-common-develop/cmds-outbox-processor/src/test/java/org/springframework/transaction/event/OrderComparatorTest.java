package org.springframework.transaction.event;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEvent;
import org.springframework.core.OrderComparator;
import org.springframework.transaction.support.TransactionSynchronization;

import lombok.extern.slf4j.Slf4j;


@ExtendWith(MockitoExtension.class)
@Slf4j
public class OrderComparatorTest {
	
	@Test
	void wheOrderComparator_SortMethodIsCalledWithoutExplicitPriorityFor200_OrderOfEventPublisherShouldNotChange() {
		final List<TransactionSynchronization> input = getData(200);
		final List<TransactionSynchronization> originalData = getData(input);
		OrderComparator.sort(input);
		for(int i=0; i< input.size(); i++) {
			assertEquals(originalData.get(i), input.get(i));
		}
		
	}
	
	@Test
	void wheOrderComparator_SortMethodIsCalledWithoutExplicitPriorityFor300_OrderOfEventPublisherShouldNotChange() {
		final List<TransactionSynchronization> input = getData(300);
		final List<TransactionSynchronization> originalData = getData(input);
		OrderComparator.sort(input);
		for(int i=0; i< input.size(); i++) {
			assertEquals(originalData.get(i), input.get(i));
		}
		
	}
	
	@Test
	void wheOrderComparator_SortMethodIsCalledWithoutExplicitPriorityFor400_OrderOfEventPublisherShouldNotChange() {
		final List<TransactionSynchronization> input = getData(400);
		final List<TransactionSynchronization> originalData = getData(input);
		OrderComparator.sort(input);
		for(int i=0; i< input.size(); i++) {
			assertEquals(originalData.get(i), input.get(i));
		}
		
	}
	
	@Test
	void wheOrderComparator_SortMethodIsCalledWithoutExplicitPriorityFor500_OrderOfEventPublisherShouldNotChange() {
		final List<TransactionSynchronization> input = getData(500);
		final List<TransactionSynchronization> originalData = getData(input);
		OrderComparator.sort(input);
		for(int i=0; i< input.size(); i++) {
			assertEquals(originalData.get(i), input.get(i));
		}
		
	}
	
	private List<TransactionSynchronization> getData(List<TransactionSynchronization> inputList) {
		final List<TransactionSynchronization> sortedSynchs = new ArrayList<>();
		inputList.forEach(input->sortedSynchs.add(input));
		return sortedSynchs;
	}

	private static List<TransactionSynchronization> getData(final int size) {
		final List<TransactionSynchronization> sortedSynchs = new ArrayList<>();
		for(int i=1; i<=size; i++) {
			TransactionalApplicationListener<ApplicationEvent> listener = new TransactionalApplicationListener<ApplicationEvent>() {
				
				@Override
				public void onApplicationEvent(ApplicationEvent event) {
					log.info("On Application Event :{}", event);
				}
				
				@Override
				public void processEvent(ApplicationEvent event) {
					log.info("On Process Event :{}", event);
				}
				
				@Override
				public void addCallback(SynchronizationCallback callback) {
					log.info("Add Callback :{}", callback);
				}
			};
			List<TransactionalApplicationListener.SynchronizationCallback> callbacks = new ArrayList<>();
			TransactionalApplicationListener.SynchronizationCallback callback = new TransactionalApplicationListener.SynchronizationCallback() {
			};
			callbacks.add(callback);
			ApplicationEvent event = new ApplicationEvent("s") {
				private static final long serialVersionUID = 1L;
			};
			TransactionSynchronization e = 
					new TransactionalApplicationListenerSynchronization<ApplicationEvent>(event, listener, callbacks);
			sortedSynchs.add(e);
		}
		return sortedSynchs;
	}

}
