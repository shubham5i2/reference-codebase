package com.ielts.cmds.outbox.processor.v2.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.outbox.event.model.OutboxEventAttribute;
import com.ielts.cmds.outbox.event.model.OutboxEventV1;
import com.ielts.cmds.outbox.infra.entity.PublishState;
import com.ielts.cmds.infrastructure.event.context.CMDSAuditContext;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.*;

public class OutboxProcessorV2Helper {

    public static CMDSHeaderContext getHeaderContext() {

        CMDSHeaderContext headerContext = new CMDSHeaderContext();
        headerContext.setCorrelationId(UUID.fromString("ba247244-182c-4b31-b3d7-8a9d4647bfa2"));
        headerContext.setTransactionId(UUID.fromString("4e85b0ab-4216-42b9-91f6-830627385b47"));
        headerContext.setEventName("eventName");
        headerContext.setEventDateTime(LocalDateTime.now());
        Map<String, String> eventContext = new HashMap<String, String>();
        eventContext.put("bookingUuid", "70ab7e18-fc75-4b00-9f7c-dccb7cb1bf12");
        headerContext.setEventContext(eventContext);
        headerContext.setConnectionId("connection Id");
        headerContext.setPartnerCode("IDP");

        ThreadLocalHeaderContext.setContext(headerContext);

        return ThreadLocalHeaderContext.getContext();
    }

    public static CMDSAuditContext getAuditContext() {

        CMDSAuditContext auditContext = new CMDSAuditContext();
        auditContext.setPrincipalId("principal Id");
        auditContext.setPrincipalName("principal name");
        auditContext.setPermission("allowed");
        auditContext.setCausedByCorrelationId(UUID.fromString("70ab7e18-fc75-4b00-9f7c-dccb7cb1bf12"));
        auditContext.setCausedByTransactionId(UUID.fromString("70ab7e18-fc75-4b00-9f7c-dccb7cb1bf12"));
        auditContext.setCausedByEventDateTime(LocalDateTime.now());
        auditContext.setCausedByEventName("event name");

        ThreadLocalAuditContext.setContext(auditContext);

        return ThreadLocalAuditContext.getContext();
    }

    public static OutboxEventV1 getOutboxEventV1() throws JsonProcessingException {
        LocationNodeHelper helper = new LocationNodeHelper();
        helper.setLocationUuid(UUID.randomUUID());
        helper.setLocationStatus("ACTIVE");
        String payload = new ObjectMapper().writeValueAsString(helper);
        final List<OutboxEventAttribute> outboxEventAttributes = new ArrayList<>();

        OutboxEventV1 outboxEventV1 = OutboxEventV1.builder()
                .outboxEventUuid(UUID.fromString("77e17c45-d47e-4087-8e91-7fe2c2b9e0e0"))
                .transactionUuid(getHeaderContext().getTransactionId())
                .eventName("eventIgnore")
                .eventDatetime(getHeaderContext().getEventDateTime().atOffset(ZoneOffset.UTC))
                .payload(payload)
                .publishState(PublishState.PUBLISH_PENDING)
                .retryCount(0)
                .eventAttributes(outboxEventAttributes)
                .build();
        return outboxEventV1;
    }
}
