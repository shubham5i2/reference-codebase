package com.ielts.cmds.outbox.processor;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;

import com.ielts.cmds.outbox.event.model.OutboxEvent;
import com.ielts.cmds.outbox.event.model.OutboxEventV1;
import com.ielts.cmds.outbox.infra.entity.PublishState;
import java.time.OffsetDateTime;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;

@ExtendWith(MockitoExtension.class)
class ApplicationInternalEventPublisherTest {

    @Mock private ApplicationEventPublisher applicationEventPublisher;

    @InjectMocks private ApplicationInternalEventPublisher applicationInternalEventPublisher;

    @Test
    void callPublish_ExpectOutboxEventToBePublished() {
        final OutboxEvent event =
                OutboxEventV1.builder()
                        .eventName("ResultBookingChanged")
                        .outboxEventUuid(UUID.randomUUID())
                        .eventDatetime(OffsetDateTime.now())
                        .retryCount(0)
                        .payload("{\"test\": \"testJson\"}")
                        .publishState(PublishState.PUBLISH_SUCCEED)
                        .build();
        doNothing().when(applicationEventPublisher).publishEvent(event);
        applicationInternalEventPublisher.publish(event);
        verify(applicationEventPublisher).publishEvent(event);
    }
}
