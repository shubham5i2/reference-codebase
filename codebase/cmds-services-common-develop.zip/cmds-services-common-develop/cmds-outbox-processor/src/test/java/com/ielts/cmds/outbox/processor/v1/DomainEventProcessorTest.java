package com.ielts.cmds.outbox.processor.v1;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.outbox.event.model.OutboxEventAttribute;
import com.ielts.cmds.outbox.event.model.OutboxEventV1;
import com.ielts.cmds.outbox.event.v1.EventAttributeExtractor;
import com.ielts.cmds.outbox.event.v1.EventTransformer;
import com.ielts.cmds.outbox.infra.EventPersistenceService;
import com.ielts.cmds.outbox.infra.entity.OutboxEvent;
import com.ielts.cmds.outbox.infra.entity.PublishState;
import com.ielts.cmds.outbox.processor.ApplicationInternalEventPublisher;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DomainEventProcessorTest {

    @Mock
    private EventTransformer eventTransformer;

    @Mock
    private EventAttributeExtractor eventAttributeExtractor;

    @Mock
    private EventPersistenceService eventPersistenceService;

    @Mock
    private ApplicationInternalEventPublisher eventPublisher;

    @InjectMocks
    private DomainEventProcessor domainEventProcessor;

    @Captor
    private ArgumentCaptor<OutboxEventV1> outboxEventV1Captor;

    @Test
    void callProcessEvent_EventPersistenceRequired_ExpectSnsEventPublisherToBeCalled() throws JsonProcessingException {
        final BaseHeader eventHeader = new BaseHeader();
        eventHeader.setEventName("ResultBookingChanged");
        eventHeader.setEventDateTime(LocalDateTime.now());
        final String eventBody = "{\"test\": \"testJson\"}";
        final BaseEvent<BaseHeader> event =
                new BaseEvent<BaseHeader>(eventHeader, eventBody, null, null);

        String payload = new ObjectMapper().writeValueAsString(event);
        final List<OutboxEventAttribute> outboxEventAttributes = new ArrayList<>();
        doReturn(new ObjectMapper().writeValueAsString(event)).when(eventTransformer).apply(event);
        doReturn(outboxEventAttributes).when(eventAttributeExtractor).apply(event);
        final OutboxEventV1 outboxEventV1 =
                OutboxEventV1.builder()
                        .outboxEventUuid(UUID.randomUUID())
                        .transactionUuid(event.getEventHeader().getTransactionId())
                        .eventName(event.getEventHeader().getEventName())
                        .eventDatetime(
                                event.getEventHeader().getEventDateTime().atOffset(ZoneOffset.UTC))
                        .payload(payload)
                        .publishState(PublishState.PUBLISH_PENDING)
                        .retryCount(0)
                        .eventAttributes(outboxEventAttributes)
                        .build();
        final OutboxEvent outboxEvent = new OutboxEvent();
        outboxEvent.setOutboxEventUuid(outboxEventV1.getOutboxEventUuid());
        outboxEvent.setTransactionUuid(outboxEventV1.getTransactionUuid());
        outboxEvent.setEventName(outboxEventV1.getEventName());
        outboxEvent.setEventDatetime(outboxEventV1.getEventDatetime());
        outboxEvent.setPayload(outboxEventV1.getPayload());
        outboxEvent.setPublishState(outboxEventV1.getPublishState());
        outboxEvent.setRetryCount(0);
        outboxEvent.setCreatedDatetime(OffsetDateTime.now());
        outboxEvent.setUpdatedDatetime(OffsetDateTime.now());
        doReturn(outboxEvent).when(eventPersistenceService).save(any(OutboxEventV1.class));
        doNothing().when(eventPublisher).publish(any(OutboxEventV1.class));
        assertDoesNotThrow(() -> domainEventProcessor.process(event));
        verify(eventPersistenceService).save(outboxEventV1Captor.capture());
        OutboxEventV1 actual = outboxEventV1Captor.getValue();
        assertEquals(event.getEventHeader().getEventName(), actual.getEventName());
        assertEquals(payload, actual.getPayload());
        assertEquals(PublishState.PUBLISH_PENDING, actual.getPublishState());
    }

    @Test
    void callProcessEvent_EventPersistenceNotRequired_ExpectSnsEventPublisherToBeCalled() throws JsonProcessingException {
        final BaseHeader eventHeader = new BaseHeader();
        eventHeader.setEventName("ResultBookingChanged");
        eventHeader.setEventDateTime(LocalDateTime.now());
        final String eventBody = "{\"test\": \"testJson\"}";
        final BaseEvent<BaseHeader> event =
                new BaseEvent<BaseHeader>(eventHeader, eventBody, null, null);
        String payload = new ObjectMapper().writeValueAsString(event);
        final List<OutboxEventAttribute> outboxEventAttributes = new ArrayList<>();
        doReturn(new ObjectMapper().writeValueAsString(event)).when(eventTransformer).apply(event);
        doReturn(outboxEventAttributes).when(eventAttributeExtractor).apply(event);
        final OutboxEventV1 outboxEventV1 =
                OutboxEventV1.builder()
                        .outboxEventUuid(UUID.randomUUID())
                        .transactionUuid(event.getEventHeader().getTransactionId())
                        .eventName(event.getEventHeader().getEventName())
                        .eventDatetime(
                                event
                                        .getEventHeader()
                                        .getEventDateTime()
                                        .atOffset(ZoneOffset.UTC))
                        .payload(payload)
                        .publishState(PublishState.PUBLISH_PENDING)
                        .retryCount(0)
                        .eventAttributes(outboxEventAttributes)
                        .build();
        final OutboxEvent outboxEvent = new OutboxEvent();
        outboxEvent.setOutboxEventUuid(outboxEventV1.getOutboxEventUuid());
        outboxEvent.setTransactionUuid(outboxEventV1.getTransactionUuid());
        outboxEvent.setEventName(outboxEventV1.getEventName());
        outboxEvent.setEventDatetime(outboxEventV1.getEventDatetime());
        outboxEvent.setPayload(outboxEventV1.getPayload());
        outboxEvent.setPublishState(outboxEventV1.getPublishState());
        outboxEvent.setRetryCount(0);
        outboxEvent.setCreatedDatetime(OffsetDateTime.now());
        outboxEvent.setUpdatedDatetime(OffsetDateTime.now());
        doNothing().when(eventPublisher).publish(any(OutboxEventV1.class));
        assertDoesNotThrow(() -> domainEventProcessor.process(event));
        verify(eventPublisher).publish(outboxEventV1Captor.capture());
        OutboxEventV1 actual = outboxEventV1Captor.getValue();
        assertEquals(event.getEventHeader().getEventName(), actual.getEventName());
        assertEquals(payload, actual.getPayload());
    }
}
