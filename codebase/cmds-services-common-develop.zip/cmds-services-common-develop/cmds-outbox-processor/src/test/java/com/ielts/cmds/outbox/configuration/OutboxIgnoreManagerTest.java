package com.ielts.cmds.outbox.configuration;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.apache.commons.lang.reflect.FieldUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static com.ielts.cmds.outbox.processor.v2.helper.OutboxProcessorV2Helper.getOutboxEventV1;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class OutboxIgnoreManagerTest {

    @InjectMocks
    private OutboxIgnoreManager outboxIgnoreManager;

    @Test
    void when_isOutboxIgnoreMethodCalled_ReturnTrue() throws JsonProcessingException, IllegalAccessException {
        Map<String, String> ignoredEvents = new HashMap<>();
        ignoredEvents.put("eventIgnore", "true");
        ignoredEvents.put("testEvent", "false");
        FieldUtils.writeField(outboxIgnoreManager, "ignore", ignoredEvents, true);
        assertTrue(outboxIgnoreManager.isOutboxIgnore(getOutboxEventV1()));
    }

    @Test
    void when_isOutboxIgnoreMethodCalled_ReturnFalse() throws JsonProcessingException, IllegalAccessException {
        Map<String, String> ignoredEvents = new HashMap<>();
        ignoredEvents.put("eventIgnore", "false");
        ignoredEvents.put("testEvent", "false");
        FieldUtils.writeField(outboxIgnoreManager, "ignore", ignoredEvents, true);
        assertFalse(outboxIgnoreManager.isOutboxIgnore(getOutboxEventV1()));
    }

    @Test
    void when_isOutboxIgnoreMethodCalled_WithEmptyIgnoreList_ReturnFalse() throws JsonProcessingException, IllegalAccessException {
        FieldUtils.writeField(outboxIgnoreManager, "ignore", Collections.emptyMap(), true);
        assertFalse(outboxIgnoreManager.isOutboxIgnore(getOutboxEventV1()));
    }
}
