package com.ielts.cmds.outbox.configuration;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.amazonaws.services.sns.AmazonSNS;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.outbox.event.v1.EventAttributeExtractor;
import com.ielts.cmds.outbox.event.v1.EventTransformer;
import com.ielts.cmds.outbox.event.v2.EventAttributeExtractorV2;
import com.ielts.cmds.outbox.event.v2.EventTransformerV2;
import com.ielts.cmds.outbox.processor.v1.BasicEventListener;
import com.ielts.cmds.outbox.processor.v1.BasicEventProcessor;
import com.ielts.cmds.outbox.utils.OutboxTopicValidator;
import com.ielts.cmds.outbox.processor.SNSEventPublisher;
import lombok.SneakyThrows;
import org.apache.commons.lang.reflect.FieldUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class BasicEventPublisherConfigurationTest {

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private EventAttributeExtractor eventAttributeExtractor;

    @Mock
    private EventAttributeExtractorV2 eventAttributeExtractorV2;

    @Mock
    private EventTransformer eventTransformer;

    @Mock
    private EventTransformerV2 eventTransformerV2;

    @Mock
    private AmazonSNS snsClient;

    @Mock
    private SNSEventPublisher snsEventPublisher;

    @Mock
    private BasicEventProcessor basicEventProcessor;
    
    @Mock
    private OutboxTopicValidator outboxTopicValidator;

    @InjectMocks
    private BasicEventPublisherConfiguration basicEventPublisherConfiguration;

    @BeforeEach
    @SneakyThrows
    void setup() {
        FieldUtils.writeField(basicEventPublisherConfiguration, "outBoundTopicArn", "test", true);
    }

    @Test
    void basicEventListener_ExpectBasicEventListenerToBeReturned() {
        final BasicEventListener actual =
                basicEventPublisherConfiguration.basicEventListener(basicEventProcessor);
        assertNotNull(actual);
    }

    @Test
    void basicEventProcessor_ExpectBasicEventProcessorToBeReturned() {
        final BasicEventProcessor actual =
                basicEventPublisherConfiguration.basicEventProcessor(
                        eventTransformer, eventAttributeExtractor, snsEventPublisher);
        assertNotNull(actual);
    }

    @Test
    void snsEventPublisher_ExpectSnsEventPublisherToBeReturned() {
        final SNSEventPublisher actual =
                basicEventPublisherConfiguration.snsEventPublisher(snsClient, outboxTopicValidator);
        assertNotNull(actual);
    }

    @Test
    void eventAttributeExtractor_ExpectEventAttributeExtractorToBeReturned() {
        final EventAttributeExtractor actual =
                basicEventPublisherConfiguration.eventAttributeExtractor();
        assertNotNull(actual);
    }

    @Test
    void eventAttributeExtractorV2_ExpectEventAttributeExtractorToBeReturned() {
        final EventAttributeExtractorV2 actual =
                basicEventPublisherConfiguration.eventAttributeExtractorV2(objectMapper);
        assertNotNull(actual);
    }

    @Test
    void eventTransformer_ExpectEventTransformerToBeReturned() {
        final EventTransformer actual =
                basicEventPublisherConfiguration.eventTransformer(objectMapper);
        assertNotNull(actual);
    }

    @Test
    void eventTransformerV2_ExpectEventTransformerToBeReturned() {
        final EventTransformerV2 actual =
                basicEventPublisherConfiguration.eventTransformerV2(objectMapper);
        assertNotNull(actual);
    }
}
