package com.ielts.cmds.outbox.processor;

import static com.ielts.cmds.outbox.constant.OutboxConfigConstants.HOUSEKEEPING_EVENT_NAME;
import static com.ielts.cmds.outbox.constant.OutboxConfigConstants.HOUSEKEEPING_OUT_EVENT_NAME;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;

import org.apache.commons.lang.reflect.FieldUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.BeanUtils;
import org.springframework.context.ApplicationEventPublisher;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.outbox.constant.OutboxConfigConstants;
import com.ielts.cmds.outbox.event.OutboxEventBuilder;
import com.ielts.cmds.outbox.event.model.OutboxDeleteEventRequestedNodeV1;
import com.ielts.cmds.outbox.event.model.OutboxDeletionCompletedNodeV1;
import com.ielts.cmds.outbox.event.model.OutboxEvent;
import com.ielts.cmds.outbox.event.model.OutboxTransientEvent;
import com.ielts.cmds.outbox.infra.EventPersistenceService;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
class OutboxHousekeepingServiceTest {

	@Mock private EventPersistenceService eventPersistenceService;

	@Mock private ApplicationEventPublisher eventPublisher;

	@Mock private ObjectMapper objectMapper;
	
	@Mock private OutboxEventBuilder outboxEventBuilder;

	@InjectMocks private OutboxHousekeepingService outboxHousekeepingService;
	
	@BeforeEach
	@SneakyThrows
	void setup() {
		FieldUtils.writeField(outboxHousekeepingService, "isHousekeepingEnabled", "true", true);
		FieldUtils.writeField(outboxHousekeepingService, "housekeepingEventLimit", "500", true);
		FieldUtils.writeField(outboxHousekeepingService, "housekeepingTimeLimitInMinutes", "2880", true);
		FieldUtils.writeField(outboxHousekeepingService, "housekeepingThresholdTimeInMinutes", "1440", true);
	}

	@Test
	@SneakyThrows
	void process_WithHousekeepingFeatureDisabled_ExpectEventToBePublished() {
		FieldUtils.writeField(outboxHousekeepingService, "isHousekeepingEnabled", "false", true);
		final BaseHeader eventHeader = new BaseHeader();
		eventHeader.setEventName(OutboxConfigConstants.HOUSEKEEPING_EVENT_NAME);
		eventHeader.setEventDateTime(LocalDateTime.now());
		final OutboxDeleteEventRequestedNodeV1 deleteEventRequestedNodeV1 =
				new OutboxDeleteEventRequestedNodeV1();
		deleteEventRequestedNodeV1.setEventNumberLimit(100);;
		deleteEventRequestedNodeV1.setTimeLimitInMinutes(2880);

		final String eventBody = new ObjectMapper().writeValueAsString(deleteEventRequestedNodeV1);
		final BaseEvent<BaseHeader> event =
				new BaseEvent<BaseHeader>(eventHeader, eventBody, null, null);
		
		outboxHousekeepingService.process(event);
		verify(objectMapper, never()).readValue(eventBody, OutboxDeleteEventRequestedNodeV1.class);
	}
	
	@Test
	@SneakyThrows
	void process_WithHousekeepingFeatureEnabled_ExpectEventToBePublished() {
		final BaseHeader eventHeader = new BaseHeader();
		eventHeader.setEventName(OutboxConfigConstants.HOUSEKEEPING_EVENT_NAME);
		eventHeader.setEventDateTime(LocalDateTime.now());
		final OutboxDeleteEventRequestedNodeV1 deleteEventRequestedNodeV1 =
				new OutboxDeleteEventRequestedNodeV1();
		deleteEventRequestedNodeV1.setEventNumberLimit(100);;
		deleteEventRequestedNodeV1.setTimeLimitInMinutes(2880);

		final String eventBody = new ObjectMapper().writeValueAsString(deleteEventRequestedNodeV1);
		final BaseEvent<BaseHeader> event =
				new BaseEvent<BaseHeader>(eventHeader, eventBody, null, null);
		final OutboxEvent outboxDeleteEventCompleted = OutboxDeletionCompletedNodeV1.builder()
					.fromTimeStamp(OffsetDateTime.now().minusHours(10))
					.toTimeStamp(OffsetDateTime.now().plusHours(10))
					.numberOfElementsDeleted(33L)
					.build();
		when(objectMapper.readValue(eventBody, OutboxDeleteEventRequestedNodeV1.class))
		.thenReturn(deleteEventRequestedNodeV1);

		when(eventPersistenceService.deleteOldEvents(any(), eq(100), eq(0)))
		.thenReturn(outboxDeleteEventCompleted);
		
		final BaseHeader outEventHeader = new BaseHeader();
    	BeanUtils.copyProperties(eventHeader, outEventHeader);
    	eventHeader.setEventName(HOUSEKEEPING_OUT_EVENT_NAME);
    	eventHeader.setEventDateTime(LocalDateTime.now());
		final BaseEvent<BaseHeader> outEvent = 
				new BaseEvent<BaseHeader>(outEventHeader, 
						objectMapper.writeValueAsString(outboxDeleteEventCompleted),
						null, null);
		final BaseEvent<? extends BaseHeader> outboxTransientEvent = buildAsPersistenceIgnored(outEvent);
        
         
		doReturn(outboxTransientEvent).
        when(outboxEventBuilder).buildAsPersistenceIgnored(any());
        
        doNothing().when(eventPublisher).publishEvent(outboxTransientEvent);
		outboxHousekeepingService.process(event);
		
		verify(eventPublisher).publishEvent(outboxTransientEvent);	
	}
	
	@Test
	@SneakyThrows
	void process_WithHousekeepingFeatureEnabled_JsonProcessingException_WhileBuildingOutEvent_ExpectEventNotToBePublished() {
		final BaseHeader eventHeader = new BaseHeader();
		eventHeader.setEventName(OutboxConfigConstants.HOUSEKEEPING_EVENT_NAME);
		eventHeader.setEventDateTime(LocalDateTime.now());
		final OutboxDeleteEventRequestedNodeV1 deleteEventRequestedNodeV1 =
				new OutboxDeleteEventRequestedNodeV1();
		deleteEventRequestedNodeV1.setEventNumberLimit(100);;
		deleteEventRequestedNodeV1.setTimeLimitInMinutes(2880);

		final String eventBody = new ObjectMapper().writeValueAsString(deleteEventRequestedNodeV1);
		final BaseEvent<BaseHeader> event =
				new BaseEvent<BaseHeader>(eventHeader, eventBody, null, null);
		final OutboxEvent outboxDeleteEventCompleted = OutboxDeletionCompletedNodeV1.builder()
					.fromTimeStamp(OffsetDateTime.now().minusHours(10))
					.toTimeStamp(OffsetDateTime.now().plusHours(10))
					.numberOfElementsDeleted(33L)
					.build();
		when(objectMapper.readValue(eventBody, OutboxDeleteEventRequestedNodeV1.class))
		.thenReturn(deleteEventRequestedNodeV1);

		when(eventPersistenceService.deleteOldEvents(any(), eq(100), eq(0)))
		.thenReturn(outboxDeleteEventCompleted);
		doThrow(JsonProcessingException.class)
		.when(objectMapper).writeValueAsString(outboxDeleteEventCompleted);
		final BaseHeader outEventHeader = new BaseHeader();
    	BeanUtils.copyProperties(eventHeader, outEventHeader);
    	eventHeader.setEventName(HOUSEKEEPING_OUT_EVENT_NAME);
    	eventHeader.setEventDateTime(LocalDateTime.now());
		assertThrows(JsonProcessingException.class, () -> outboxHousekeepingService.process(event));
		
		verify(eventPublisher, never()).publishEvent(any());	
	}
	
	@Test
	@SneakyThrows
	void process_WithHousekeepingFeatureEnabled_JsonProcessingException_WhileFramingEvent_ExpectEventPersistenceServiceNotToBeCalled() {
		final BaseHeader eventHeader = new BaseHeader();
		eventHeader.setEventName(OutboxConfigConstants.HOUSEKEEPING_EVENT_NAME);
		eventHeader.setEventDateTime(LocalDateTime.now());
		final OutboxDeleteEventRequestedNodeV1 deleteEventRequestedNodeV1 =
				new OutboxDeleteEventRequestedNodeV1();
		deleteEventRequestedNodeV1.setEventNumberLimit(100);;
		deleteEventRequestedNodeV1.setTimeLimitInMinutes(2880);

		final String eventBody = new ObjectMapper().writeValueAsString(deleteEventRequestedNodeV1);
		final BaseEvent<BaseHeader> event =
				new BaseEvent<BaseHeader>(eventHeader, eventBody, null, null);
		
		doThrow(JsonProcessingException.class)
		.when(objectMapper).readValue(eventBody, OutboxDeleteEventRequestedNodeV1.class);
		assertThrows(JsonProcessingException.class, () -> outboxHousekeepingService.process(event));
		verify(eventPersistenceService, never()).deleteOldEvents(any(), any(), any());
		verify(eventPublisher, never()).publishEvent(any());	
	}
	
	@Test
	void getServiceIdentifier_ExpectEventNameToBeHouseKeepingEvent() {
		assertEquals(HOUSEKEEPING_EVENT_NAME, outboxHousekeepingService.getServiceIdentifier());
	}
	
	@Test
	void getEventNumberLimit_NoValuePassed_ExpectDefaultConfig() {
		final OutboxDeleteEventRequestedNodeV1 houseKeepingConfig = new OutboxDeleteEventRequestedNodeV1();
		final Integer actual = outboxHousekeepingService.getEventNumberLimit(houseKeepingConfig);
		assertEquals(500, actual);
	}
	
	@Test
	void getEventNumberLimit_ValuePassed_ExpectProvidedConfig() {
		final OutboxDeleteEventRequestedNodeV1 houseKeepingConfig = new OutboxDeleteEventRequestedNodeV1();
		houseKeepingConfig.setEventNumberLimit(1000);
		final Integer actual = outboxHousekeepingService.getEventNumberLimit(houseKeepingConfig);
		assertEquals(1000, actual);
	}
	
	@Test
	void getTimestampFromConfig_NoValuePassed_ExpectDefaultConfig() {
		final OutboxDeleteEventRequestedNodeV1 houseKeepingConfig = new OutboxDeleteEventRequestedNodeV1();
		final OffsetDateTime actual = outboxHousekeepingService.getTimestampForDeletion(houseKeepingConfig);
		final OffsetDateTime expected = OffsetDateTime.now().minusMinutes(2880);
		assertEquals(expected.getMinute(), actual.getMinute());
		assertEquals(expected.getHour(), actual.getHour());
		assertEquals(expected.getDayOfMonth(), actual.getDayOfMonth());
		assertEquals(expected.getMonth(), actual.getMonth());
		assertEquals(expected.getYear(), actual.getYear());
	}
	
	@Test
	void getTimestampFromConfig_ValuePassedLessThanThreshold_ExpectDefaultConfig() {
		final OutboxDeleteEventRequestedNodeV1 houseKeepingConfig = new OutboxDeleteEventRequestedNodeV1();
		houseKeepingConfig.setTimeLimitInMinutes(2);
		final OffsetDateTime actual = outboxHousekeepingService.getTimestampForDeletion(houseKeepingConfig);
		final OffsetDateTime expected = OffsetDateTime.now().minusMinutes(2880);
		assertEquals(expected.getMinute(), actual.getMinute());
		assertEquals(expected.getHour(), actual.getHour());
		assertEquals(expected.getDayOfMonth(), actual.getDayOfMonth());
		assertEquals(expected.getMonth(), actual.getMonth());
		assertEquals(expected.getYear(), actual.getYear());
	}
	
	@Test
	void getTimestampFromConfig_ValuePassedMoreThanThreshold_ExpectProvidedConfig() {
		final OutboxDeleteEventRequestedNodeV1 houseKeepingConfig = new OutboxDeleteEventRequestedNodeV1();
		houseKeepingConfig.setTimeLimitInMinutes(2000);
		final OffsetDateTime actual = outboxHousekeepingService.getTimestampForDeletion(houseKeepingConfig);
		final OffsetDateTime expected = OffsetDateTime.now().minusMinutes(2000);
		assertEquals(expected.getMinute(), actual.getMinute());
		assertEquals(expected.getHour(), actual.getHour());
		assertEquals(expected.getDayOfMonth(), actual.getDayOfMonth());
		assertEquals(expected.getMonth(), actual.getMonth());
		assertEquals(expected.getYear(), actual.getYear());
	}
	
	public static BaseEvent<? extends BaseHeader> buildAsPersistenceIgnored(final BaseEvent<? extends BaseHeader> event) {
        OutboxTransientEvent<BaseHeader> outboxIgnoredEvent = new OutboxTransientEvent<>();
        outboxIgnoredEvent.setOutboxIgnore(true);
        outboxIgnoredEvent.setEventHeader(event.getEventHeader());
        outboxIgnoredEvent.setEventBody(event.getEventBody());
        outboxIgnoredEvent.setEventErrors(event.getEventErrors());
        outboxIgnoredEvent.setAudit(event.getAudit());

        return outboxIgnoredEvent;
    }

}


