package com.ielts.cmds.outbox.processor.v2;

import com.ielts.cmds.outbox.processor.v2.helper.LocationNodeHelper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BasicEventListenerV2Test {

    @Mock
    private BasicEventProcessorV2 basicEventProcessor;

    @InjectMocks
    private BasicEventListenerV2 basicEventListener;

    @Test
    void onEvent_WithNoException_ExpectProcessingToBeSuccessful() {
        LocationNodeHelper helper = new LocationNodeHelper();
        helper.setLocationUuid(UUID.randomUUID());
        helper.setLocationStatus("ACTIVE");
        doNothing().when(basicEventProcessor).process(helper);
        assertDoesNotThrow(() -> basicEventListener.onEvent(helper));
        verify(basicEventProcessor).process(helper);
    }

    @Test
    void onEvent_WithException_ExpectRuntimeException() {
        LocationNodeHelper helper = new LocationNodeHelper();
        helper.setLocationUuid(UUID.randomUUID());
        helper.setLocationStatus("ACTIVE");
        doThrow(RuntimeException.class).when(basicEventProcessor).process(helper);
        assertThrows(RuntimeException.class, () -> basicEventListener.onEvent(helper));
        verify(basicEventProcessor).process(helper);
    }
}
