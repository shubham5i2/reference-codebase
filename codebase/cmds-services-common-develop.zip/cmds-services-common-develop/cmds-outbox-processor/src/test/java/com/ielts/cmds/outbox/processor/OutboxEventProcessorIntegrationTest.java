package com.ielts.cmds.outbox.processor;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import javax.transaction.Transactional;

import org.apache.commons.lang.reflect.FieldUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.InvalidParameterException;
import com.amazonaws.services.sns.model.MessageAttributeValue;
import com.amazonaws.services.sns.model.PublishRequest;
import com.amazonaws.services.sns.model.PublishResult;
import com.ielts.cmds.outbox.configuration.IntegrationTestConfig;
import com.ielts.cmds.outbox.configuration.OutboxIgnoreManager;
import com.ielts.cmds.outbox.event.model.OutboxEventAttribute;
import com.ielts.cmds.outbox.event.model.OutboxEventV1;
import com.ielts.cmds.outbox.infra.EventPersistenceService;
import com.ielts.cmds.outbox.infra.entity.OutboxEvent;
import com.ielts.cmds.outbox.infra.entity.PublishState;
import com.ielts.cmds.outbox.infra.repository.OutboxEventRepository;
import com.ielts.cmds.outbox.utils.OutboxTopicValidator;

import lombok.SneakyThrows;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = IntegrationTestConfig.class)
@ActiveProfiles("test")
class OutboxEventProcessorIntegrationTest {

	private OutboxEventV1 event;

	private Set<String> allTopics;

	private SNSEventPublisher snsEventPublisher;

	@Autowired
	private OutboxEventRepository outboxEventRepository;

	@Mock
	private AmazonSNS snsClient;

	@Mock
	private OutboxTopicValidator outboxTopicValidator;

	@Mock
	private PublishRequest publishRequest;

	@Mock
	private PublishRequest publishRequest2;

	@Mock
	private Map<String, MessageAttributeValue> mesageAttributes;

	private String outBoundTopicArn = "Outbox Topic ARN";

	private String businessEventTopicArn = "Business Event Topic ARN";

	@InjectMocks
	private OutboxEventProcessor outboxEventProcessor;

	@BeforeEach
	@SneakyThrows
	void setup() {
		final OutboxEventAttribute eventAttribute = OutboxEventAttribute.builder().attributeKey("eventName")
				.attributeValue("TestEvent").build();
		final List<OutboxEventAttribute> eventAttributes = new ArrayList<>();
		eventAttributes.add(eventAttribute);
		event = OutboxEventV1.builder().eventName("TestEvent").outboxEventUuid(UUID.randomUUID())
				.payload("Dummy Payload").transactionUuid(UUID.randomUUID()).publishState(PublishState.PUBLISH_PENDING)
				.eventDatetime(OffsetDateTime.now()).eventAttributes(eventAttributes).retryCount(0).build();

		allTopics = new HashSet<>();
		allTopics.add(outBoundTopicArn);
		allTopics.add(businessEventTopicArn);

		snsEventPublisher = new SNSEventPublisher(outBoundTopicArn, snsClient, outboxTopicValidator);
		snsEventPublisher = Mockito.spy(snsEventPublisher);

		FieldUtils.writeField(outboxEventProcessor, "snsEventPublisher", snsEventPublisher, true);
		FieldUtils.writeField(outboxEventProcessor, "eventPersistenceService",
				new EventPersistenceService(outboxEventRepository, new OutboxIgnoreManager()), true);
	}

	@Test
	@Transactional
	void whenBothEventsPublishIsSuccessful_RecordIsDeletedSuccessfully() {

		when(outboxTopicValidator.getValidTopicsToPublish(event.getEventName())).thenReturn(allTopics);
		when(snsClient.publish(Mockito.any())).thenReturn(new PublishResult());

		//Test setup for outbox data
		OutboxEvent outboxEvent = new OutboxEvent();
		outboxEvent.setOutboxEventUuid(event.getOutboxEventUuid());
		outboxEventRepository.save(outboxEvent);

		assertDoesNotThrow(() -> outboxEventProcessor.process(event));

		final Optional<OutboxEvent> outboxEventOptional = outboxEventRepository.findById(event.getOutboxEventUuid());

		assertFalse(outboxEventOptional.isPresent());
	}

	@Test
	@Transactional
	void whenAnyOneEventPublishIsFailed_RecordIsUpdatedWithPublishFailure() {

		when(outboxTopicValidator.getValidTopicsToPublish(event.getEventName())).thenReturn(allTopics);
		when(snsClient.publish(Mockito.any())).thenThrow(InvalidParameterException.class);

		assertDoesNotThrow(() -> outboxEventProcessor.process(event));

		final Optional<OutboxEvent> outboxEventOptional = outboxEventRepository.findById(event.getOutboxEventUuid());
		final OutboxEvent outboxEvent = outboxEventOptional.get();

		assertTrue(outboxEventOptional.isPresent());
		assertNotNull(outboxEvent);
		assertEquals(event.getOutboxEventUuid(), outboxEvent.getOutboxEventUuid());
		assertEquals(event.getEventDatetime(), outboxEvent.getEventDatetime());
		assertEquals(event.getEventName(), outboxEvent.getEventName());
		assertEquals(event.getPayload(), outboxEvent.getPayload());
		assertEquals(event.getTransactionUuid(), outboxEvent.getTransactionUuid());
		assertEquals(PublishState.PUBLISH_FAILURE, outboxEvent.getPublishState());

		outboxEventRepository.deleteAll();
	}

	@Test
	@Transactional
	void whenInternalEventPublishIsSucceed_BusinessEventPublishIsFailed_RecordIsUpdatedWithPublishFailure() {

		when(outboxTopicValidator.getValidTopicsToPublish(event.getEventName())).thenReturn(allTopics);
		doReturn(mesageAttributes).when(snsEventPublisher).getMessageAttributes(event.getEventAttributes());
		doReturn(publishRequest).when(snsEventPublisher).createPublishRequestInstance(event, mesageAttributes,
				outBoundTopicArn);
		doReturn(publishRequest2).when(snsEventPublisher).createPublishRequestInstance(event, mesageAttributes,
				businessEventTopicArn);
		when(snsClient.publish(publishRequest)).thenReturn(new PublishResult());
		when(snsClient.publish(publishRequest2)).thenThrow(InvalidParameterException.class);

		assertDoesNotThrow(() -> outboxEventProcessor.process(event));

		final Optional<OutboxEvent> outboxEventOptional = outboxEventRepository.findById(event.getOutboxEventUuid());
		final OutboxEvent outboxEvent = outboxEventOptional.get();

		assertTrue(outboxEventOptional.isPresent());
		assertNotNull(outboxEvent);
		assertEquals(event.getOutboxEventUuid(), outboxEvent.getOutboxEventUuid());
		assertEquals(event.getEventDatetime(), outboxEvent.getEventDatetime());
		assertEquals(event.getEventName(), outboxEvent.getEventName());
		assertEquals(event.getPayload(), outboxEvent.getPayload());
		assertEquals(event.getTransactionUuid(), outboxEvent.getTransactionUuid());
		assertEquals(PublishState.PUBLISH_FAILURE, outboxEvent.getPublishState());

		outboxEventRepository.deleteAll();
	}

}
