package com.ielts.cmds.outbox.configuration;

import com.amazonaws.services.sns.AmazonSNS;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.outbox.event.v1.DefaultEventTransformer;
import com.ielts.cmds.outbox.event.v1.EventAttributeExtractor;
import com.ielts.cmds.outbox.event.OutboxEventBuilder;
import com.ielts.cmds.outbox.event.v2.DefaultEventTransformerV2;
import com.ielts.cmds.outbox.event.v2.EventAttributeExtractorV2;
import com.ielts.cmds.outbox.infra.EventPersistenceService;
import com.ielts.cmds.outbox.infra.repository.OutboxEventRepository;
import com.ielts.cmds.outbox.processor.ApplicationInternalEventPublisher;
import com.ielts.cmds.outbox.processor.OutboxBootstrapService;
import com.ielts.cmds.outbox.processor.v1.DomainEventProcessor;
import com.ielts.cmds.outbox.processor.OutboxEventProcessor;
import com.ielts.cmds.outbox.processor.SNSEventPublisher;
import com.ielts.cmds.outbox.processor.v2.DomainEventProcessorV2;
import com.ielts.cmds.outbox.utils.OutboxTopicValidator;

import lombok.SneakyThrows;
import org.apache.commons.lang.reflect.FieldUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class OutboxConfigurationTest {

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private OutboxEventRepository outboxEventRepository;

    @Mock
    private AmazonSNS snsClient;

    @Mock
    private ApplicationEventPublisher applicationEventPublisher;

    @Mock
    private EventPersistenceService eventPersistenceService;

    @Mock
    private DomainEventProcessor domainEventProcessor;

    @Mock
    private DomainEventProcessorV2 domainEventProcessorV2;

    @Mock
    private SNSEventPublisher eventPublisher;

    @Mock
    private ApplicationInternalEventPublisher applicationInternalEventPublisher;

    @Mock
    private EventAttributeExtractor eventAttributeExtractor;

    @Mock
    private EventAttributeExtractorV2 eventAttributeExtractorV2;

    @Mock
    private OutboxIgnoreManager outboxIgnoreManager;

    @Mock
    private DefaultEventTransformer eventTransformer;

    private DefaultEventTransformerV2 eventTransformerV2;

    @Mock
    private OutboxEventProcessor outboxEventProcessor;

    @Mock
    private OutboxEventBuilder outboxEventBuilder;
    
    @Mock
    private OutboxTopicValidator outboxTopicValidator;
    
    @Mock
    private OutboxBootstrapService outboxBootstrapService;

    @InjectMocks
    private OutboxConfiguration outboxConfiguration;

    @BeforeEach
    @SneakyThrows
    void setup() {
        FieldUtils.writeField(outboxConfiguration, "housekeepingEventLimit", "500", true);
        FieldUtils.writeField(outboxConfiguration, "housekeepingTimeLimit", "2880", true);
        FieldUtils.writeField(outboxConfiguration, "housekeepingThresholdTimeLimit", "1440", true);
        FieldUtils.writeField(outboxConfiguration, "outBoundTopicArn", "test", true);
    }

    @Test
    void outboxEventBuilder_ExpectOutboxEventBuilder() {
        assertNotNull(outboxConfiguration.outboxEventBuilder());
    }

    @Test
    void eventAttributeExtractor_ExpectEventAttributeExtractor() {
        assertNotNull(outboxConfiguration.eventAttributeExtractor());
    }

    @Test
    void eventAttributeExtractorV2_ExpectEventAttributeExtractorV2() {
        assertNotNull(outboxConfiguration.eventAttributeExtractorV2(objectMapper));
    }

    @Test
    void eventTransformer_ExpectEventTransformer() {
        assertNotNull(outboxConfiguration.eventTransformer(objectMapper));
    }

    @Test
    void eventTransformerV2_ExpectEventTransformerV2() {
        assertNotNull(outboxConfiguration.eventTransformerV2(objectMapper));
    }

    @Test
    void eventPersistenceService_ExpectEventPersistenceService() {
        assertNotNull(outboxConfiguration.eventPersistenceService(outboxEventRepository, outboxIgnoreManager));
    }

    @Test
    void applicationInternalEventPublisher_ExpectApplicationInternalEventPublisher() {
        assertNotNull(
                outboxConfiguration.applicationInternalEventPublisher(applicationEventPublisher));
    }

    @Test
    void snsEventPublisher_ExpectSnsEventPublisher() {
        assertNotNull(outboxConfiguration.snsEventPublisher(snsClient, outboxTopicValidator));
    }

    @Test
    void outboxEventProcessor_ExpectOutboxEventProcessor() {
        assertNotNull(
                outboxConfiguration.outboxEventProcessor(eventPublisher, eventPersistenceService));
    }

    @Test
    void domainEventProcessor_ExpectDomainEventProcessor() {
        assertNotNull(
                outboxConfiguration.domainEventProcessor(
                        eventTransformer,
                        eventPersistenceService,
                        eventAttributeExtractor,
                        applicationInternalEventPublisher));
    }

    @Test
    void domainEventProcessorV2_ExpectDomainEventProcessorV2() {
        assertNotNull(
                outboxConfiguration.domainEventProcessorV2(
                        eventTransformerV2,
                        eventPersistenceService,
                        eventAttributeExtractorV2,
                        applicationInternalEventPublisher));
    }

    @Test
    void outboxEventListener_ExpectOutboxEventListener() {
        assertNotNull(outboxConfiguration.outboxEventListener(outboxEventProcessor));
    }

    @Test
    void domainEventListener_ExpectDomainEventListener() {
        assertNotNull(outboxConfiguration.domainEventListener(domainEventProcessor));
    }

    @Test
    void domainEventListenerV2_ExpectDomainEventListenerV2() {
        assertNotNull(outboxConfiguration.domainEventListenerV2(domainEventProcessorV2));
    }

    @Test
    void outboxReplayService_ExpectOutboxReplayService() {
        assertNotNull(
                outboxConfiguration.outboxReplayService(
                        eventPersistenceService, applicationInternalEventPublisher, objectMapper));
    }

    @Test
    void outboxHousekeepingService_ExpectOutboxHouseKeepingService() {
        assertNotNull(
                outboxConfiguration.outboxHousekeepingService(
                        eventPersistenceService, applicationEventPublisher, objectMapper, outboxEventBuilder));
    }
    
	@Test
	void outboxBootstrapService_ExpectOutboxBootstrapService() {
		assertNotNull(outboxConfiguration.outboxBootstrapService(snsClient));
	}

	@Test
	void outboxTopicValidator_ExpectOutboxTopicValidator() {
		assertNotNull(outboxConfiguration.outboxTopicValidator(outboxBootstrapService));
	}
}
