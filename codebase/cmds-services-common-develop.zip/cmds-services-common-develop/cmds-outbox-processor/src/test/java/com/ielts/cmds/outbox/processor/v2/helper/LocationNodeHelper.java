package com.ielts.cmds.outbox.processor.v2.helper;

import lombok.Getter;
import lombok.Setter;

import java.util.UUID;

@Getter
@Setter
public class LocationNodeHelper {
    private UUID locationUuid;

    private String locationStatus;
}
