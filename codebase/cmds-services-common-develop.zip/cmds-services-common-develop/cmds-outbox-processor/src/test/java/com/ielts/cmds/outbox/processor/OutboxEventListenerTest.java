package com.ielts.cmds.outbox.processor;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.outbox.event.model.OutboxEventAttribute;
import com.ielts.cmds.outbox.event.model.OutboxEventV1;
import com.ielts.cmds.outbox.infra.entity.PublishState;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class OutboxEventListenerTest {

    @Mock private OutboxEventProcessor outboxEventProcessor;

    @InjectMocks private OutboxEventListener outboxEventListener;

    @Test
    @SneakyThrows
    void onEvent_WithNoException_ExpectProcessingToBeSuccessful() {
        final BaseHeader eventHeader = new BaseHeader();
        eventHeader.setEventName("ResultBookingChanged");
        eventHeader.setEventDateTime(LocalDateTime.now());
        final String eventBody = "{\"test\": \"testJson\"}";
        final BaseEvent<BaseHeader> event =
                new BaseEvent<BaseHeader>(eventHeader, eventBody, null, null);
        String payload = new ObjectMapper().writeValueAsString(event);
        final List<OutboxEventAttribute> outboxEventAttributes = new ArrayList<>();
        final OutboxEventV1 outboxEventV1 =
                OutboxEventV1.builder()
                        .outboxEventUuid(UUID.randomUUID())
                        .transactionUuid(event.getEventHeader().getTransactionId())
                        .eventName(event.getEventHeader().getEventName())
                        .eventDatetime(
                                event.getEventHeader().getEventDateTime().atOffset(ZoneOffset.UTC))
                        .payload(payload)
                        .publishState(PublishState.PUBLISH_PENDING)
                        .retryCount(0)
                        .eventAttributes(outboxEventAttributes)
                        .build();
        doNothing().when(outboxEventProcessor).process(outboxEventV1);
        assertDoesNotThrow(() -> outboxEventListener.onEvent(outboxEventV1));
        verify(outboxEventProcessor).process(outboxEventV1);
    }

    @Test
    @SneakyThrows
    void onEvent_WithException_ExpectNoException() {
        final BaseHeader eventHeader = new BaseHeader();
        eventHeader.setEventName("ResultBookingChanged");
        eventHeader.setEventDateTime(LocalDateTime.now());
        final String eventBody = "{\"test\": \"testJson\"}";
        final BaseEvent<BaseHeader> event =
                new BaseEvent<BaseHeader>(eventHeader, eventBody, null, null);
        String payload = new ObjectMapper().writeValueAsString(event);
        final List<OutboxEventAttribute> outboxEventAttributes = new ArrayList<>();
        final OutboxEventV1 outboxEventV1 =
                OutboxEventV1.builder()
                        .outboxEventUuid(UUID.randomUUID())
                        .transactionUuid(event.getEventHeader().getTransactionId())
                        .eventName(event.getEventHeader().getEventName())
                        .eventDatetime(
                                event.getEventHeader().getEventDateTime().atOffset(ZoneOffset.UTC))
                        .payload(payload)
                        .publishState(PublishState.PUBLISH_PENDING)
                        .retryCount(0)
                        .eventAttributes(outboxEventAttributes)
                        .build();
        doThrow(RuntimeException.class).when(outboxEventProcessor).process(outboxEventV1);
        assertDoesNotThrow(() -> outboxEventListener.onEvent(outboxEventV1));
        verify(outboxEventProcessor).process(outboxEventV1);
    }
}
