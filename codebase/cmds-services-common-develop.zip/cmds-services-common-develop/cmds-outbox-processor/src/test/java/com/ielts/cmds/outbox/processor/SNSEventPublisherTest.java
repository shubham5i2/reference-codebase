package com.ielts.cmds.outbox.processor;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.amazonaws.services.sns.AmazonSNSClient;
import com.amazonaws.services.sns.model.MessageAttributeValue;
import com.amazonaws.services.sns.model.PublishRequest;
import com.amazonaws.services.sns.model.PublishResult;
import com.ielts.cmds.outbox.event.model.OutboxEventAttribute;
import com.ielts.cmds.outbox.event.model.OutboxEventV1;
import com.ielts.cmds.outbox.utils.OutboxTopicValidator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import lombok.SneakyThrows;
import org.apache.commons.lang.reflect.FieldUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class SNSEventPublisherTest {

    @Mock private AmazonSNSClient snsClient;

    @InjectMocks private SNSEventPublisher snsEventPublisher;
    
    @Mock private OutboxTopicValidator outboxTopicValidator;

    @BeforeEach
    @SneakyThrows
    void setup() {
        FieldUtils.writeField(snsEventPublisher, "outBoundTopicArn", "test", true);
        FieldUtils.writeField(snsEventPublisher, "outboxTopicValidator", outboxTopicValidator, true);
    }

    @Test
    void publish_ExpectEventToBePublished() {
        final List<OutboxEventAttribute> eventAttributes = new ArrayList<>();
        final OutboxEventAttribute outboxEventAttribute =
                OutboxEventAttribute.builder()
                        .attributeKey("partnercode")
                        .attributeValue("BC")
                        .build();
        eventAttributes.add(outboxEventAttribute);
        final OutboxEventV1 event =
                OutboxEventV1.builder().payload("test").eventAttributes(eventAttributes).build();
        final Map<String, MessageAttributeValue> messageAttributeMap = new HashMap<>();
        messageAttributeMap.put(
                "partnercode",
                new MessageAttributeValue().withDataType("String").withStringValue("BC"));
        final PublishRequest publishRequest = new PublishRequest();
        publishRequest.setMessageAttributes(messageAttributeMap);
        publishRequest.setMessage("test");
        publishRequest.setTopicArn("test");
        final Set<String> topicArns = new HashSet<>();
        topicArns.add("test");
        when(outboxTopicValidator.getValidTopicsToPublish(event.getEventName())).thenReturn(topicArns);
        doReturn(new PublishResult()).when(snsClient).publish(publishRequest);
        assertDoesNotThrow(() -> snsEventPublisher.publish(event));
    }
    
    @Test
    void publish_BusinessEvent_ExpectEventToBePublishedTwice() {
        final List<OutboxEventAttribute> eventAttributes = new ArrayList<>();
        final OutboxEventAttribute outboxEventAttribute =
                OutboxEventAttribute.builder()
                        .attributeKey("partnercode")
                        .attributeValue("BC")
                        .build();
        eventAttributes.add(outboxEventAttribute);
        final OutboxEventV1 event =
                OutboxEventV1.builder().payload("test").eventAttributes(eventAttributes).build();
        final Map<String, MessageAttributeValue> messageAttributeMap = new HashMap<>();
        messageAttributeMap.put(
                "partnercode",
                new MessageAttributeValue().withDataType("String").withStringValue("BC"));
        final PublishRequest publishRequest = new PublishRequest();
        publishRequest.setMessageAttributes(messageAttributeMap);
        publishRequest.setMessage("test");
        publishRequest.setTopicArn("test");
        final PublishRequest publishRequest2 = new PublishRequest();
        publishRequest2.setMessageAttributes(messageAttributeMap);
        publishRequest2.setMessage("test2");
        publishRequest2.setTopicArn("test2");
        final Set<String> topicArns = new HashSet<>();
        topicArns.add("test");
        topicArns.add("test2");
        when(outboxTopicValidator.getValidTopicsToPublish(event.getEventName())).thenReturn(topicArns);
        doReturn(new PublishResult()).when(snsClient).publish(Mockito.any());
        assertDoesNotThrow(() -> snsEventPublisher.publish(event));
        verify(snsClient, times(2)).publish(Mockito.any());
    }
}
