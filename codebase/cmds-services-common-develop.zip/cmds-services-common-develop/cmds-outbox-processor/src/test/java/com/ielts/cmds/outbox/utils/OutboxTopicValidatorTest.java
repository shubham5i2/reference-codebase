package com.ielts.cmds.outbox.utils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.reflect.FieldUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.outbox.processor.OutboxBootstrapService;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
class OutboxTopicValidatorTest {

	private String region = "eu-west-2";

	private String accountId = "036220108529";

	private String awsEnv = "sandbox";

	private String outBoundTopicArn = "arn:aws:sns:eu-west-2:036220108529:ielts-cmds-sandbox-sns-TestEvent-topic-out";

	@Mock
	private OutboxBootstrapService outboxBootstrapService;

	@InjectMocks
	@Spy
	private OutboxTopicValidator outboxTopicValidator;

	@BeforeEach
	@SneakyThrows
	void init() {
		FieldUtils.writeField(outboxTopicValidator, "region", region, true);
		FieldUtils.writeField(outboxTopicValidator, "accountId", accountId, true);
		FieldUtils.writeField(outboxTopicValidator, "awsEnv", awsEnv, true);
		FieldUtils.writeField(outboxTopicValidator, "outBoundTopicArn", outBoundTopicArn, true);
		FieldUtils.writeField(outboxTopicValidator, "outboxBootstrapService", outboxBootstrapService, true);
	}

	@Test
	void getValidTopicsToPublish_NoBusinessEventFoundInValidEventsList_SetContainsSingleTopic() {

		when(outboxBootstrapService.getAllTopics()).thenReturn(new HashSet<>());
		Set<String> validTopics = outboxTopicValidator.getValidTopicsToPublish("ValidEvent");

		assertEquals(1, validTopics.size());
		assertTrue(validTopics.contains(outBoundTopicArn));
	}

	@Test
	void getValidTopicsToPublish_NoBusinessEventFoundInValidEventsList_InvalidARN_SetContainsSingleTopics() {

		String invalidArn = "arn:aws:sns:eu-west-2:036220108529:ielts-cmds-sandbox-sns-InvalidEvent-topic-out";
		Set<String> allTopics = new HashSet<>();
		allTopics.add(invalidArn);

		when(outboxBootstrapService.getAllTopics()).thenReturn(allTopics);
		Set<String> validTopics = outboxTopicValidator.getValidTopicsToPublish("ValidEvent");

		assertEquals(1, validTopics.size());
		assertTrue(validTopics.contains(outBoundTopicArn));
		assertFalse(validTopics.contains(invalidArn));
	}

	@Test
	void getValidTopicsToPublish_BusinessEventFoundInValidEventsList_ValidARN_SetContainsTwoTopics() {

		String validArn = "arn:aws:sns:eu-west-2:036220108529:ielts-cmds-sandbox-sns-ValidEventV1-topic-out";
		String invalidArn = "arn:aws:sns:eu-west-2:036220108529:ielts-cmds-sandbox-sns-InvalidEvent-topic-out";
		Set<String> allTopics = new HashSet<>();
		allTopics.add(validArn);
		allTopics.add(invalidArn);

		when(outboxBootstrapService.getAllTopics()).thenReturn(allTopics);
		validArn = outboxTopicValidator.frameTopicArn(region, accountId, awsEnv, "ValidEvent");

		Set<String> validTopics = outboxTopicValidator.getValidTopicsToPublish("ValidEvent");

		assertEquals(2, validTopics.size());
		assertTrue(validTopics.contains(outBoundTopicArn));
		assertTrue(validTopics.contains(validArn));
	}

	@Test
	void when_eventNameWithoutVxSuffix_expect_topicWithV1Suffix() {
		String expectedTopicArn = "arn:aws:sns:eu-west-2:036220108529:ielts-cmds-sandbox-sns-SimpleEventV1-topic-out";
		String actualTopicArn = outboxTopicValidator.frameTopicArn(region, accountId, awsEnv, "SimpleEvent");
		assertEquals(expectedTopicArn,actualTopicArn);
	}

	@Test
	void when_eventNameWithVxSuffix_expect_topicWithVxSuffix() {
		String expectedTopicArn = "arn:aws:sns:eu-west-2:036220108529:ielts-cmds-sandbox-sns-ComplexEventV333-topic-out";
		String actualTopicArn = outboxTopicValidator.frameTopicArn(region, accountId, awsEnv, "ComplexEventV333");
		assertEquals(expectedTopicArn,actualTopicArn);
	}
}
