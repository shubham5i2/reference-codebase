package com.ielts.cmds.outbox.processor.v2;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.outbox.configuration.OutboxIgnoreManager;
import com.ielts.cmds.outbox.event.model.OutboxEventAttribute;
import com.ielts.cmds.outbox.event.model.OutboxEventV1;
import com.ielts.cmds.outbox.event.v2.EventAttributeExtractorV2;
import com.ielts.cmds.outbox.event.v2.EventTransformerV2;
import com.ielts.cmds.outbox.infra.EventPersistenceService;
import com.ielts.cmds.outbox.infra.entity.OutboxEvent;
import com.ielts.cmds.outbox.infra.entity.PublishState;
import com.ielts.cmds.outbox.processor.ApplicationInternalEventPublisher;
import com.ielts.cmds.outbox.processor.v2.helper.LocationNodeHelper;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditQueue;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderQueue;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static com.ielts.cmds.outbox.processor.v2.helper.OutboxProcessorV2Helper.getAuditContext;
import static com.ielts.cmds.outbox.processor.v2.helper.OutboxProcessorV2Helper.getHeaderContext;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DomainEventProcessorV2Test {

    @Mock
    private EventTransformerV2 eventTransformer;

    @Mock
    private EventAttributeExtractorV2 eventAttributeExtractor;

    @Mock
    private EventPersistenceService eventPersistenceService;

    @Mock
    private ApplicationInternalEventPublisher eventPublisher;

    @Mock
    private OutboxIgnoreManager outboxIgnoreManager;

    @InjectMocks
    private DomainEventProcessorV2 domainEventProcessor;

    @Captor
    private ArgumentCaptor<OutboxEventV1> outboxEventV1Captor;

    @Test
    void callProcessEvent_EventPersistenceRequired_ExpectSnsEventPublisherToBeCalled() throws JsonProcessingException {
        LocationNodeHelper helper = new LocationNodeHelper();
        helper.setLocationUuid(UUID.randomUUID());
        helper.setLocationStatus("ACTIVE");

        ThreadLocalHeaderQueue.add(getHeaderContext());
        ThreadLocalAuditQueue.add(getAuditContext());

        String payload = new ObjectMapper().writeValueAsString(helper);
        final List<OutboxEventAttribute> outboxEventAttributes = new ArrayList<>();
        doReturn(new ObjectMapper().writeValueAsString(helper)).when(eventTransformer).apply(helper);
        doReturn(outboxEventAttributes).when(eventAttributeExtractor).apply(helper);
        final OutboxEventV1 outboxEventV1 =
                OutboxEventV1.builder()
                        .outboxEventUuid(UUID.fromString("77e17c45-d47e-4087-8e91-7fe2c2b9e0e0"))
                        .transactionUuid(getHeaderContext().getTransactionId())
                        .eventName(getHeaderContext().getEventName())
                        .eventDatetime(getHeaderContext().getEventDateTime().atOffset(ZoneOffset.UTC))
                        .payload(payload)
                        .publishState(PublishState.PUBLISH_PENDING)
                        .retryCount(0)
                        .eventAttributes(outboxEventAttributes)
                        .build();
        final OutboxEvent outboxEvent = new OutboxEvent();
        outboxEvent.setOutboxEventUuid(outboxEventV1.getOutboxEventUuid());
        outboxEvent.setTransactionUuid(outboxEventV1.getTransactionUuid());
        outboxEvent.setEventName(outboxEventV1.getEventName());
        outboxEvent.setEventDatetime(outboxEventV1.getEventDatetime());
        outboxEvent.setPayload(outboxEventV1.getPayload());
        outboxEvent.setPublishState(outboxEventV1.getPublishState());
        outboxEvent.setRetryCount(0);
        outboxEvent.setCreatedDatetime(OffsetDateTime.now());
        outboxEvent.setUpdatedDatetime(OffsetDateTime.now());
        doReturn(outboxEvent).when(eventPersistenceService).save(any(OutboxEventV1.class));
        doNothing().when(eventPublisher).publish(any(OutboxEventV1.class));
        assertDoesNotThrow(() -> domainEventProcessor.process(helper));
        verify(eventPersistenceService).save(outboxEventV1Captor.capture());
        OutboxEventV1 actual = outboxEventV1Captor.getValue();
        assertEquals(payload, actual.getPayload());
        assertEquals(PublishState.PUBLISH_PENDING, actual.getPublishState());
    }

    @Test
    void callProcessEvent_EventPersistenceNotRequired_ExpectSnsEventPublisherToBeCalled() throws JsonProcessingException {
        LocationNodeHelper helper = new LocationNodeHelper();
        helper.setLocationUuid(UUID.randomUUID());
        helper.setLocationStatus("ACTIVE");

        ThreadLocalHeaderQueue.add(getHeaderContext());
        ThreadLocalAuditQueue.add(getAuditContext());

        String payload = new ObjectMapper().writeValueAsString(helper);
        final List<OutboxEventAttribute> outboxEventAttributes = new ArrayList<>();
        doReturn(new ObjectMapper().writeValueAsString(helper)).when(eventTransformer).apply(helper);
        doReturn(outboxEventAttributes).when(eventAttributeExtractor).apply(helper);
        final OutboxEventV1 outboxEventV1 =
                OutboxEventV1.builder()
                        .outboxEventUuid(UUID.randomUUID())
                        .transactionUuid(getHeaderContext().getTransactionId())
                        .eventName(getHeaderContext().getEventName())
                        .eventDatetime(
                                getHeaderContext()
                                        .getEventDateTime()
                                        .atOffset(ZoneOffset.UTC))
                        .payload(payload)
                        .publishState(PublishState.PUBLISH_PENDING)
                        .retryCount(0)
                        .eventAttributes(outboxEventAttributes)
                        .build();
        final OutboxEvent outboxEvent = new OutboxEvent();
        outboxEvent.setOutboxEventUuid(outboxEventV1.getOutboxEventUuid());
        outboxEvent.setTransactionUuid(outboxEventV1.getTransactionUuid());
        outboxEvent.setEventName(outboxEventV1.getEventName());
        outboxEvent.setEventDatetime(outboxEventV1.getEventDatetime());
        outboxEvent.setPayload(outboxEventV1.getPayload());
        outboxEvent.setPublishState(outboxEventV1.getPublishState());
        outboxEvent.setRetryCount(0);
        outboxEvent.setCreatedDatetime(OffsetDateTime.now());
        outboxEvent.setUpdatedDatetime(OffsetDateTime.now());
        doNothing().when(eventPublisher).publish(any(OutboxEventV1.class));
        assertDoesNotThrow(() -> domainEventProcessor.process(helper));
        verify(eventPublisher).publish(outboxEventV1Captor.capture());
        OutboxEventV1 actual = outboxEventV1Captor.getValue();
        assertEquals(payload, actual.getPayload());
    }
}