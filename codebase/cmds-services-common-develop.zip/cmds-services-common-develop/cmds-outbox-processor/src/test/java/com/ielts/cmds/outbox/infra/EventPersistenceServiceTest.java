package com.ielts.cmds.outbox.infra;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.ielts.cmds.outbox.configuration.OutboxIgnoreManager;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;

import com.ielts.cmds.outbox.event.model.OutboxDeletionCompletedNodeV1;
import com.ielts.cmds.outbox.event.model.OutboxEvent;
import com.ielts.cmds.outbox.event.model.OutboxEventPage;
import com.ielts.cmds.outbox.event.model.OutboxEventV1;
import com.ielts.cmds.outbox.event.model.ReplayEventNodeV1;
import com.ielts.cmds.outbox.infra.entity.OutboxEventAttribute;
import com.ielts.cmds.outbox.infra.entity.OutboxEventUuid;
import com.ielts.cmds.outbox.infra.entity.PublishState;
import com.ielts.cmds.outbox.infra.repository.OutboxEventRepository;

@ExtendWith(MockitoExtension.class)
class EventPersistenceServiceTest {

    @Mock private OutboxEventRepository outboxEventRepository;
    
    @Mock private OutboxEventUuid outboxEventUuidOne;
    
    @Mock private OutboxEventUuid outboxEventUuidTwo;

    @Mock private OutboxIgnoreManager outboxIgnoreManager;

    @InjectMocks private EventPersistenceService eventPersistenceService;

    @Test
    void findByTransactionIdAndEventNameAndOutboxUuid_ExpectDataToBeFetched() {
        final List<ReplayEventNodeV1> replayEvents = new ArrayList<>();
        final ReplayEventNodeV1 replayEventNodeV1 = new ReplayEventNodeV1();
        replayEventNodeV1.setEventName("ResultBookingChanged");
        replayEventNodeV1.setOutboxUuid(UUID.randomUUID());
        replayEventNodeV1.setTransactionUuid(UUID.randomUUID());
        replayEvents.add(replayEventNodeV1);
        List<UUID> transactionIds = new ArrayList<>();
        transactionIds.add(replayEventNodeV1.getTransactionUuid());
        List<UUID> outboxUuids = new ArrayList<>();
        outboxUuids.add(replayEventNodeV1.getOutboxUuid());
        List<String> eventNames = new ArrayList<>();
        eventNames.add(replayEventNodeV1.getEventName());

        final List<com.ielts.cmds.outbox.infra.entity.OutboxEvent> outboxEventEntityList =
                new ArrayList<>();
        com.ielts.cmds.outbox.infra.entity.OutboxEvent outboxEventEntity =
                new com.ielts.cmds.outbox.infra.entity.OutboxEvent();
        outboxEventEntity.setOutboxEventUuid(replayEventNodeV1.getOutboxUuid());
        outboxEventEntity.setEventName(replayEventNodeV1.getEventName());
        outboxEventEntity.setTransactionUuid(replayEventNodeV1.getTransactionUuid());
        final List<OutboxEventAttribute> outboxEventAttributes = new ArrayList<>();
        final OutboxEventAttribute outboxEventAttribute =
                new OutboxEventAttribute(
                        UUID.randomUUID(),
                        outboxEventEntity,
                        "partnercode",
                        "BC",
                        OffsetDateTime.now());
        outboxEventAttributes.add(outboxEventAttribute);
        outboxEventEntity.setOutboxEventAttributes(outboxEventAttributes);
        outboxEventEntityList.add(outboxEventEntity);
        doReturn(outboxEventEntityList)
                .when(outboxEventRepository)
                .findByTransactionUuidInAndEventNameInAndOutboxEventUuidIn(
                        transactionIds, eventNames, outboxUuids);
        final List<OutboxEvent> actual =
                eventPersistenceService.findByTransactionIdAndEventNameAndOutboxUuid(replayEvents);
        assertEquals(1, actual.size());
        assertEquals(
                replayEventNodeV1.getEventName(), ((OutboxEventV1) actual.get(0)).getEventName());
        assertEquals(
                replayEventNodeV1.getTransactionUuid(),
                ((OutboxEventV1) actual.get(0)).getTransactionUuid());
        assertEquals(
                replayEventNodeV1.getOutboxUuid(),
                ((OutboxEventV1) actual.get(0)).getOutboxEventUuid());
    }

    @Test
    void findByPublishStateInAndUpdatedDatetimeAfter_ExpectDataToBeFetched() {
        final List<ReplayEventNodeV1> replayEvents = new ArrayList<>();
        final ReplayEventNodeV1 replayEventNodeV1 = new ReplayEventNodeV1();
        replayEventNodeV1.setEventName("ResultBookingChanged");
        replayEventNodeV1.setOutboxUuid(UUID.randomUUID());
        replayEventNodeV1.setTransactionUuid(UUID.randomUUID());
        replayEvents.add(replayEventNodeV1);
        List<UUID> transactionIds = new ArrayList<>();
        transactionIds.add(replayEventNodeV1.getTransactionUuid());
        List<UUID> outboxUuids = new ArrayList<>();
        outboxUuids.add(replayEventNodeV1.getOutboxUuid());
        List<String> eventNames = new ArrayList<>();
        eventNames.add(replayEventNodeV1.getEventName());

        final List<com.ielts.cmds.outbox.infra.entity.OutboxEvent> outboxEventEntityList =
                new ArrayList<>();
        com.ielts.cmds.outbox.infra.entity.OutboxEvent outboxEventEntity =
                new com.ielts.cmds.outbox.infra.entity.OutboxEvent();
        outboxEventEntity.setOutboxEventUuid(replayEventNodeV1.getOutboxUuid());
        outboxEventEntity.setEventName(replayEventNodeV1.getEventName());
        outboxEventEntity.setTransactionUuid(replayEventNodeV1.getTransactionUuid());
        final List<OutboxEventAttribute> outboxEventAttributes = new ArrayList<>();
        final OutboxEventAttribute outboxEventAttribute =
                new OutboxEventAttribute(
                        UUID.randomUUID(),
                        outboxEventEntity,
                        "partnercode",
                        "BC",
                        OffsetDateTime.now());
        outboxEventAttributes.add(outboxEventAttribute);
        outboxEventEntity.setOutboxEventAttributes(outboxEventAttributes);
        outboxEventEntityList.add(outboxEventEntity);
        final Page<com.ielts.cmds.outbox.infra.entity.OutboxEvent> outboxEventPage =
                new PageImpl<com.ielts.cmds.outbox.infra.entity.OutboxEvent>(
                        outboxEventEntityList, PageRequest.of(0, 10), outboxEventEntityList.size());
        final OffsetDateTime pastLimit = OffsetDateTime.now();
        doReturn(outboxEventPage)
                .when(outboxEventRepository)
                .findByPublishStateInAndUpdatedDatetimeAfter(
                        Arrays.asList(PublishState.PUBLISH_PENDING, PublishState.PUBLISH_FAILURE),
                        pastLimit,
                        PageRequest.of(0, 10));
        final OutboxEventPage actual =
                eventPersistenceService.findPendingAndFailedEvents(0, 10, pastLimit, 1);
        assertEquals(1, actual.getOutboxEvents().size());
        assertEquals(
                replayEventNodeV1.getEventName(),
                ((OutboxEventV1) actual.getOutboxEvents().get(0)).getEventName());
        assertEquals(
                replayEventNodeV1.getTransactionUuid(),
                ((OutboxEventV1) actual.getOutboxEvents().get(0)).getTransactionUuid());
        assertEquals(
                replayEventNodeV1.getOutboxUuid(),
                ((OutboxEventV1) actual.getOutboxEvents().get(0)).getOutboxEventUuid());
    }

    @Test
    void save_DataPresentAlready_ExpectDataToBeSaved() {
        final List<OutboxEventAttribute> outboxEventAttributesEntity = new ArrayList<>();
        com.ielts.cmds.outbox.infra.entity.OutboxEvent outboxEventEntity =
                new com.ielts.cmds.outbox.infra.entity.OutboxEvent();
        outboxEventEntity.setOutboxEventUuid(UUID.randomUUID());
        outboxEventEntity.setEventName("ResultBookingChanged");
        outboxEventEntity.setTransactionUuid(UUID.randomUUID());
        outboxEventEntity.setEventDatetime(OffsetDateTime.now());
        final OutboxEventAttribute outboxEventAttributeEntity =
                new OutboxEventAttribute(
                        UUID.randomUUID(),
                        outboxEventEntity,
                        "partnercode",
                        "BC",
                        OffsetDateTime.now());
        outboxEventAttributesEntity.add(outboxEventAttributeEntity);

        List<com.ielts.cmds.outbox.event.model.OutboxEventAttribute> eventAttributes =
                new ArrayList<>();
        com.ielts.cmds.outbox.event.model.OutboxEventAttribute outboxEventAttribute =
                com.ielts.cmds.outbox.event.model.OutboxEventAttribute.builder()
                        .attributeKey("partnercode")
                        .attributeValue("BC")
                        .build();
        eventAttributes.add(outboxEventAttribute);
        final OutboxEventV1 event =
                OutboxEventV1.builder()
                        .eventName("ResultBookingChanged")
                        .outboxEventUuid(outboxEventEntity.getOutboxEventUuid())
                        .transactionUuid(outboxEventEntity.getTransactionUuid())
                        .eventDatetime(outboxEventEntity.getEventDatetime())
                        .eventAttributes(eventAttributes)
                        .build();
        when(outboxEventRepository.findById(outboxEventEntity.getOutboxEventUuid()))
                .thenReturn(Optional.of(outboxEventEntity));
        when(outboxIgnoreManager.isOutboxIgnore(event)).thenReturn(false);
        assertDoesNotThrow(() -> eventPersistenceService.save(event));
    }

    @Test
    void save_DataNotPresentAlready_PersistanceRequired_ExpectDataToBeSaved() {
        final List<OutboxEventAttribute> outboxEventAttributesEntity = new ArrayList<>();
        com.ielts.cmds.outbox.infra.entity.OutboxEvent outboxEventEntity =
                new com.ielts.cmds.outbox.infra.entity.OutboxEvent();
        outboxEventEntity.setOutboxEventUuid(UUID.randomUUID());
        outboxEventEntity.setEventName("ResultBookingChanged");
        outboxEventEntity.setTransactionUuid(UUID.randomUUID());
        outboxEventEntity.setEventDatetime(OffsetDateTime.now());
        final OutboxEventAttribute outboxEventAttributeEntity =
                new OutboxEventAttribute(
                        UUID.randomUUID(),
                        outboxEventEntity,
                        "partnercode",
                        "BC",
                        OffsetDateTime.now());
        outboxEventAttributesEntity.add(outboxEventAttributeEntity);

        List<com.ielts.cmds.outbox.event.model.OutboxEventAttribute> eventAttributes =
                new ArrayList<>();
        com.ielts.cmds.outbox.event.model.OutboxEventAttribute outboxEventAttribute =
                com.ielts.cmds.outbox.event.model.OutboxEventAttribute.builder()
                        .attributeKey("partnercode")
                        .attributeValue("BC")
                        .build();
        eventAttributes.add(outboxEventAttribute);
        final OutboxEventV1 event =
                OutboxEventV1.builder()
                        .eventName("ResultBookingChanged")
                        .outboxEventUuid(outboxEventEntity.getOutboxEventUuid())

                        .transactionUuid(outboxEventEntity.getTransactionUuid())
                        .eventDatetime(outboxEventEntity.getEventDatetime())
                        .eventAttributes(eventAttributes)
                        .build();
        when(outboxEventRepository.findById(outboxEventEntity.getOutboxEventUuid()))
                .thenReturn(Optional.empty());
        when(outboxIgnoreManager.isOutboxIgnore(event)).thenReturn(false);
        assertDoesNotThrow(() -> eventPersistenceService.save(event));
    }

    @Test
    void save_DataNotPresentAlready_PersistanceIgnored_ExpectDataDoNotSave(){
        final List<OutboxEventAttribute> outboxEventAttributesEntity = new ArrayList<>();
        com.ielts.cmds.outbox.infra.entity.OutboxEvent outboxEventEntity =
                new com.ielts.cmds.outbox.infra.entity.OutboxEvent();
        outboxEventEntity.setOutboxEventUuid(UUID.randomUUID());
        outboxEventEntity.setEventName("ResultBookingChanged");
        outboxEventEntity.setTransactionUuid(UUID.randomUUID());
        outboxEventEntity.setEventDatetime(OffsetDateTime.now());
        final OutboxEventAttribute outboxEventAttributeEntity =
                new OutboxEventAttribute(
                        UUID.randomUUID(),
                        outboxEventEntity,
                        "partnercode",
                        "BC",
                        OffsetDateTime.now());
        outboxEventAttributesEntity.add(outboxEventAttributeEntity);

        List<com.ielts.cmds.outbox.event.model.OutboxEventAttribute> eventAttributes =
                new ArrayList<>();
        com.ielts.cmds.outbox.event.model.OutboxEventAttribute outboxEventAttribute =
                com.ielts.cmds.outbox.event.model.OutboxEventAttribute.builder()
                        .attributeKey("partnercode")
                        .attributeValue("BC")
                        .build();
        eventAttributes.add(outboxEventAttribute);
        final OutboxEventV1 event =
                OutboxEventV1.builder()
                        .eventName("ResultBookingChanged")
                        .outboxEventUuid(outboxEventEntity.getOutboxEventUuid())

                        .transactionUuid(outboxEventEntity.getTransactionUuid())
                        .eventDatetime(outboxEventEntity.getEventDatetime())
                        .eventAttributes(eventAttributes)
                        .build();
        when(outboxIgnoreManager.isOutboxIgnore(event)).thenReturn(true);
        assertDoesNotThrow(() -> eventPersistenceService.save(event));
    }

    @Test
    void deleteOldEvents_ExpectOutboxEventWithOneDeletedElements() {
    	final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");    
    	final LocalDateTime dateTime = LocalDateTime.parse("2022-01-28T14:29:10.212", formatter);
    	final OffsetDateTime beforeTime = OffsetDateTime.of(dateTime, ZoneOffset.UTC);
    	final Sort sort = Sort.by(Direction.ASC, "updatedDatetime");
		final PageRequest pageable = PageRequest.of(0, 100, sort);
    	
		final List<OutboxEventUuid> outboxEventUuidList = new ArrayList<>();
		outboxEventUuidList.add(outboxEventUuidOne);
		outboxEventUuidList.add(outboxEventUuidTwo);
		final Page<OutboxEventUuid> outboxEventUuidPage = new PageImpl<>(outboxEventUuidList);
    	when(outboxEventRepository.findOutboxEventUuidByPublishStateAndUpdatedDatetimeBefore(PublishState.PUBLISH_SUCCEED, beforeTime, pageable))
    	.thenReturn(outboxEventUuidPage);
    	final List<UUID> outboxEventUuids = new ArrayList<>();
    	final UUID outboxEventUuidToBeDeletedOne = UUID.randomUUID();
    	final UUID outboxEventUuidToBeDeletedTwo = UUID.randomUUID();
    	when(outboxEventUuidOne.getOutboxEventUuid()).thenReturn(outboxEventUuidToBeDeletedOne);
    	when(outboxEventUuidTwo.getOutboxEventUuid()).thenReturn(outboxEventUuidToBeDeletedTwo);
    	outboxEventUuids.add(outboxEventUuidToBeDeletedOne);
    	outboxEventUuids.add(outboxEventUuidToBeDeletedTwo);
    	doReturn(2L)
    	.when(outboxEventRepository)
    	.deleteByOutboxEventUuidIn(outboxEventUuids);

    	final OutboxEvent actual = eventPersistenceService.deleteOldEvents(beforeTime, 100, 0);
    	assertEquals(2, ((OutboxDeletionCompletedNodeV1)actual).getNumberOfElementsDeleted());
    	assertEquals(beforeTime, ((OutboxDeletionCompletedNodeV1)actual).getToTimeStamp());
    }
    
    @Test
    void deleteOldEvents_ExpectOutboxEventWithZeroDeletedElements() {
    	final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");    
    	final LocalDateTime dateTime = LocalDateTime.parse("2022-01-28T14:29:10.212", formatter);
    	final OffsetDateTime beforeTime = OffsetDateTime.of(dateTime, ZoneOffset.UTC);
    	final Sort sort = Sort.by(Direction.ASC, "updatedDatetime");
		final PageRequest pageable = PageRequest.of(0, 100, sort);
		
		final List<OutboxEventUuid> outboxEventUuidList = new ArrayList<>();
		final Page<OutboxEventUuid> outboxEventUuidPage = new PageImpl<>(outboxEventUuidList);
    	when(outboxEventRepository.findOutboxEventUuidByPublishStateAndUpdatedDatetimeBefore(PublishState.PUBLISH_SUCCEED, beforeTime, pageable))
    	.thenReturn(outboxEventUuidPage);
    	final List<UUID> outboxEventUuids = new ArrayList<>();
		doReturn(0L)
    	.when(outboxEventRepository)
    	.deleteByOutboxEventUuidIn(outboxEventUuids);

    	final OutboxEvent actual = eventPersistenceService.deleteOldEvents(beforeTime, 100, 0);
    	assertEquals(0, ((OutboxDeletionCompletedNodeV1)actual).getNumberOfElementsDeleted());
    	assertEquals(null, ((OutboxDeletionCompletedNodeV1)actual).getFromTimeStamp());
    	assertEquals(beforeTime, ((OutboxDeletionCompletedNodeV1)actual).getToTimeStamp());
    }

    @Test
    void delete_PersistanceRequired_ExpectDataToBeDeleted(){
        final List<OutboxEventAttribute> outboxEventAttributesEntity = new ArrayList<>();
        com.ielts.cmds.outbox.infra.entity.OutboxEvent outboxEventEntity =
                new com.ielts.cmds.outbox.infra.entity.OutboxEvent();
        outboxEventEntity.setOutboxEventUuid(UUID.randomUUID());
        outboxEventEntity.setEventName("ResultBookingChanged");
        outboxEventEntity.setTransactionUuid(UUID.randomUUID());
        outboxEventEntity.setEventDatetime(OffsetDateTime.now());
        final OutboxEventAttribute outboxEventAttributeEntity =
                new OutboxEventAttribute(
                        UUID.randomUUID(),
                        outboxEventEntity,
                        "partnercode",
                        "BC",
                        OffsetDateTime.now());
        outboxEventAttributesEntity.add(outboxEventAttributeEntity);

        List<com.ielts.cmds.outbox.event.model.OutboxEventAttribute> eventAttributes =
                new ArrayList<>();
        com.ielts.cmds.outbox.event.model.OutboxEventAttribute outboxEventAttribute =
                com.ielts.cmds.outbox.event.model.OutboxEventAttribute.builder()
                        .attributeKey("partnercode")
                        .attributeValue("BC")
                        .build();
        eventAttributes.add(outboxEventAttribute);
        final OutboxEventV1 event =
                OutboxEventV1.builder()
                        .eventName("ResultBookingChanged")
                        .outboxEventUuid(outboxEventEntity.getOutboxEventUuid())
                        .transactionUuid(outboxEventEntity.getTransactionUuid())
                        .eventDatetime(outboxEventEntity.getEventDatetime())
                        .eventAttributes(eventAttributes)
                        .build();
        when(outboxIgnoreManager.isOutboxIgnore(event)).thenReturn(false);
        assertDoesNotThrow(() -> eventPersistenceService.delete(event));
        verify(outboxEventRepository, times(1)).deleteById(event.getOutboxEventUuid());
    }
}

