package com.ielts.cmds.outbox.event.v1;

import static org.junit.jupiter.api.Assertions.assertTrue;

import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;

import java.time.LocalDateTime;

import com.ielts.cmds.outbox.event.v1.DefaultEventAttributeExtractor;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class DefaultEventAttributeExtractorTest {

    @InjectMocks private DefaultEventAttributeExtractor defaultEventAttributeExtractor;

    @Test
    void apply_WithBaseHeader_ExpectEmptyList() {
        final BaseHeader eventHeader = new BaseHeader();
        eventHeader.setEventName("ResultBookingChanged");
        eventHeader.setEventDateTime(LocalDateTime.now());
        final String eventBody = "{\"test\": \"testJson\"}";
        final BaseEvent<BaseHeader> event =
                new BaseEvent<BaseHeader>(eventHeader, eventBody, null, null);
        assertTrue(defaultEventAttributeExtractor.apply(event).isEmpty());
    }
    
    @Test
    void apply_WithUiHeader_ExpectEmptyList() {
        final UiHeader eventHeader = new UiHeader();
        eventHeader.setConnectionId("jsfsdFsdf");
        eventHeader.setEventName("ResultBookingChanged");
        eventHeader.setEventDateTime(LocalDateTime.now());
        final String eventBody = "{\"test\": \"testJson\"}";
        final BaseEvent<UiHeader> event =
                new BaseEvent<UiHeader>(eventHeader, eventBody, null, null);
        assertTrue(defaultEventAttributeExtractor.apply(event).isEmpty());
    }
}
