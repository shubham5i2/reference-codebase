package com.ielts.cmds.outbox.processor;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.ListTopicsResult;
import com.amazonaws.services.sns.model.Topic;

@ExtendWith(MockitoExtension.class)
class OutboxBootstrapServiceTest {

	@Mock
	private AmazonSNS snsClient;

	@Mock
	private ListTopicsResult listTopicsResult;

	@Mock
	private ListTopicsResult listTopicsResult2;

	@InjectMocks
	private OutboxBootstrapService outboxBootstrapService;

	@Test
	void fetchAndBootstrapAllTopicsFromAws_NoTopicsFound_ZeroTopicReturned() {

		when(snsClient.listTopics()).thenReturn(listTopicsResult);
		when(listTopicsResult.getTopics()).thenReturn(new ArrayList<>());
		when(listTopicsResult.getNextToken()).thenReturn(null);

		assertDoesNotThrow(() -> outboxBootstrapService.fetchAndBootstrapAllTopicsFromAws());
		assertEquals(0, outboxBootstrapService.getAllTopics().size());
	}

	@Test
	void fetchAndBootstrapAllTopicsFromAws_10TopicsFound_10TopicsReturned() {

		final String token = "Token";
		final List<Topic> topicList1 = new ArrayList<>();
		Topic topic1 = new Topic();
		topic1.setTopicArn("Topic ARN 1");
		topicList1.add(topic1);
		Topic topic2 = new Topic();
		topic2.setTopicArn("Topic ARN 2");
		topicList1.add(topic2);
		Topic topic3 = new Topic();
		topic3.setTopicArn("Topic ARN 3");
		topicList1.add(topic3);
		Topic topic4 = new Topic();
		topic4.setTopicArn("Topic ARN 4");
		topicList1.add(topic4);
		Topic topic5 = new Topic();
		topic5.setTopicArn("Topic ARN 5");
		topicList1.add(topic5);

		final List<Topic> topicList2 = new ArrayList<>();
		Topic topic6 = new Topic();
		topic6.setTopicArn("Topic ARN 6");
		topicList2.add(topic6);
		Topic topic7 = new Topic();
		topic7.setTopicArn("Topic ARN 7");
		topicList2.add(topic7);
		Topic topic8 = new Topic();
		topic8.setTopicArn("Topic ARN 8");
		topicList2.add(topic8);
		Topic topic9 = new Topic();
		topic9.setTopicArn("Topic ARN 9");
		topicList2.add(topic9);
		Topic topic10 = new Topic();
		topic10.setTopicArn("Topic ARN 10");
		topicList2.add(topic10);

		when(snsClient.listTopics()).thenReturn(listTopicsResult);
		when(listTopicsResult.getTopics()).thenReturn(topicList1);
		when(listTopicsResult.getNextToken()).thenReturn(token);
		when(snsClient.listTopics(token)).thenReturn(listTopicsResult2);
		when(listTopicsResult2.getTopics()).thenReturn(topicList2);
		when(listTopicsResult2.getNextToken()).thenReturn(null);

		assertDoesNotThrow(() -> outboxBootstrapService.fetchAndBootstrapAllTopicsFromAws());
		Set<String> actualTopics = outboxBootstrapService.getAllTopics();
		assertEquals(10, actualTopics.size());
		assertTrue(actualTopics.contains(topic1.getTopicArn()));
		assertTrue(actualTopics.contains(topic2.getTopicArn()));
		assertTrue(actualTopics.contains(topic3.getTopicArn()));
		assertTrue(actualTopics.contains(topic4.getTopicArn()));
		assertTrue(actualTopics.contains(topic5.getTopicArn()));
		assertTrue(actualTopics.contains(topic6.getTopicArn()));
		assertTrue(actualTopics.contains(topic7.getTopicArn()));
		assertTrue(actualTopics.contains(topic8.getTopicArn()));
		assertTrue(actualTopics.contains(topic9.getTopicArn()));
		assertTrue(actualTopics.contains(topic10.getTopicArn()));
	}

}
