package com.ielts.cmds.outbox.processor;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang.reflect.FieldUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.outbox.constant.OutboxConfigConstants;
import com.ielts.cmds.outbox.event.model.OutboxEvent;
import com.ielts.cmds.outbox.event.model.OutboxEventPage;
import com.ielts.cmds.outbox.event.model.OutboxEventReplayRequestedNodeV1;
import com.ielts.cmds.outbox.event.model.OutboxEventV1;
import com.ielts.cmds.outbox.event.model.ReplayEventNodeV1;
import com.ielts.cmds.outbox.infra.EventPersistenceService;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
class OutboxReplayServiceTest {

    @Mock private EventPersistenceService eventPersistenceService;

    @Mock private ApplicationInternalEventPublisher applicationInternalEventPublisher;

    @Mock private ObjectMapper objectMapper;

    @InjectMocks private OutboxReplayService outboxReplayService;
    
    @BeforeEach
	@SneakyThrows
	void setup() {
    	FieldUtils.writeField(outboxReplayService, "isReplayEnabled", "true", true);
		FieldUtils.writeField(outboxReplayService, "replayRetryCountThreshold", "3", true);
		FieldUtils.writeField(outboxReplayService, "replayTimeLimitInSeconds", "2880", true);
		FieldUtils.writeField(outboxReplayService, "replayPageSize", "1440", true);
	}

    @Test
    @SneakyThrows
    void process_WithReplayFeatureEnabled_ExpectEventsToBePublished() {
        final BaseHeader eventHeader = new BaseHeader();
        eventHeader.setEventName(OutboxConfigConstants.SCHEDULER_EVENT_NAME);
        eventHeader.setEventDateTime(LocalDateTime.now());
        final OutboxEventReplayRequestedNodeV1 replayRequestedNodeV1 =
                new OutboxEventReplayRequestedNodeV1();
        replayRequestedNodeV1.setEventNumberLimit(10);
        replayRequestedNodeV1.setRetryCountThreshold(1);
        replayRequestedNodeV1.setTimeLimitInSecond(4);
        final List<ReplayEventNodeV1> replayEvents = new ArrayList<>();
        final ReplayEventNodeV1 replayEventNode = new ReplayEventNodeV1();
        replayEventNode.setEventName("ResultBookingChanged");
        replayEventNode.setOutboxUuid(UUID.randomUUID());
        replayEventNode.setTransactionUuid(UUID.randomUUID());
        replayEvents.add(replayEventNode);
        replayRequestedNodeV1.setReplayEvents(replayEvents);
        final String eventBody = new ObjectMapper().writeValueAsString(replayRequestedNodeV1);
        final BaseEvent<BaseHeader> event =
                new BaseEvent<BaseHeader>(eventHeader, eventBody, null, null);
        final OutboxEvent outboxEvent = OutboxEventV1.builder().build();
        final List<OutboxEvent> outboxEvents = new ArrayList<>();
        outboxEvents.add(outboxEvent);
        when(objectMapper.readValue(eventBody, OutboxEventReplayRequestedNodeV1.class))
                .thenReturn(replayRequestedNodeV1);
        when(eventPersistenceService.findByTransactionIdAndEventNameAndOutboxUuid(replayEvents))
                .thenReturn(new ArrayList<>());
        when(eventPersistenceService.findPendingAndFailedEvents(eq(0), eq(10), any(), eq(1)))
                .thenReturn(
                        OutboxEventPage.builder()
                                .pageNumber(0)
                                .pageSize(0)
                                .totalEventCount(0)
                                .outboxEvents(outboxEvents)
                                .build());
        outboxReplayService.process(event);
        verify(applicationInternalEventPublisher, times(1)).publish(outboxEvent);
    }

    @Test
    @SneakyThrows
    void process_WithReplayFeatureEnabled_NoReplayConfigEvent_ExpectEventsToBePublished() {
        final BaseHeader eventHeader = new BaseHeader();
        eventHeader.setEventName(OutboxConfigConstants.SCHEDULER_EVENT_NAME);
        eventHeader.setEventDateTime(LocalDateTime.now());
        final OutboxEventReplayRequestedNodeV1 replayRequestedNodeV1 =
                new OutboxEventReplayRequestedNodeV1();
        replayRequestedNodeV1.setEventNumberLimit(10);
        replayRequestedNodeV1.setRetryCountThreshold(1);
        replayRequestedNodeV1.setTimeLimitInSecond(4);
        replayRequestedNodeV1.setReplayEvents(null);
        final String eventBody = new ObjectMapper().writeValueAsString(replayRequestedNodeV1);
        final BaseEvent<BaseHeader> event =
                new BaseEvent<BaseHeader>(eventHeader, eventBody, null, null);
        when(objectMapper.readValue(eventBody, OutboxEventReplayRequestedNodeV1.class))
                .thenReturn(replayRequestedNodeV1);
        when(eventPersistenceService.findPendingAndFailedEvents(eq(0), eq(10), any(), eq(1)))
                .thenReturn(
                        OutboxEventPage.builder()
                                .pageNumber(0)
                                .pageSize(0)
                                .totalEventCount(0)
                                .outboxEvents(new ArrayList<>())
                                .build());
        outboxReplayService.process(event);
        verify(eventPersistenceService, never())
                .findByTransactionIdAndEventNameAndOutboxUuid(any());
    }

    @Test
    @SneakyThrows
    void process_WithReplayFeatureEnabled_JsonProcessingException_ExpectException() {
        final BaseHeader eventHeader = new BaseHeader();
        eventHeader.setEventName(OutboxConfigConstants.SCHEDULER_EVENT_NAME);
        eventHeader.setEventDateTime(LocalDateTime.now());
        final OutboxEventReplayRequestedNodeV1 replayRequestedNodeV1 =
                new OutboxEventReplayRequestedNodeV1();
        replayRequestedNodeV1.setEventNumberLimit(10);
        replayRequestedNodeV1.setRetryCountThreshold(1);
        replayRequestedNodeV1.setTimeLimitInSecond(4);
        final List<ReplayEventNodeV1> replayEvents = new ArrayList<>();
        final ReplayEventNodeV1 replayEventNode = new ReplayEventNodeV1();
        replayEventNode.setEventName("ResultBookingChanged");
        replayEventNode.setOutboxUuid(UUID.randomUUID());
        replayEventNode.setTransactionUuid(UUID.randomUUID());
        replayEvents.add(replayEventNode);
        replayRequestedNodeV1.setReplayEvents(replayEvents);
        final String eventBody = new ObjectMapper().writeValueAsString(replayRequestedNodeV1);
        final BaseEvent<BaseHeader> event =
                new BaseEvent<BaseHeader>(eventHeader, eventBody, null, null);
        final OutboxEvent outboxEvent = OutboxEventV1.builder().build();
        final List<OutboxEvent> outboxEvents = new ArrayList<>();
        outboxEvents.add(outboxEvent);
        doThrow(JsonProcessingException.class)
                .when(objectMapper)
                .readValue(eventBody, OutboxEventReplayRequestedNodeV1.class);
        assertThrows(JsonProcessingException.class, () -> outboxReplayService.process(event));
    }
    
    @Test
    @SneakyThrows
    void process_WithReplayFeatureDisabled_ExpectNoCalls() {
    	FieldUtils.writeField(outboxReplayService, "isReplayEnabled", "false", true);
    	final BaseHeader eventHeader = new BaseHeader();
        eventHeader.setEventName(OutboxConfigConstants.SCHEDULER_EVENT_NAME);
        eventHeader.setEventDateTime(LocalDateTime.now());
        final OutboxEventReplayRequestedNodeV1 replayRequestedNodeV1 =
                new OutboxEventReplayRequestedNodeV1();
        replayRequestedNodeV1.setEventNumberLimit(10);
        replayRequestedNodeV1.setRetryCountThreshold(1);
        replayRequestedNodeV1.setTimeLimitInSecond(4);
        final List<ReplayEventNodeV1> replayEvents = new ArrayList<>();
        final ReplayEventNodeV1 replayEventNode = new ReplayEventNodeV1();
        replayEventNode.setEventName("ResultBookingChanged");
        replayEventNode.setOutboxUuid(UUID.randomUUID());
        replayEventNode.setTransactionUuid(UUID.randomUUID());
        replayEvents.add(replayEventNode);
        replayRequestedNodeV1.setReplayEvents(replayEvents);
        final String eventBody = new ObjectMapper().writeValueAsString(replayRequestedNodeV1);
        final BaseEvent<BaseHeader> event =
                new BaseEvent<BaseHeader>(eventHeader, eventBody, null, null);
        outboxReplayService.process(event);
        verify(objectMapper, never()).readValue(eventBody, OutboxEventReplayRequestedNodeV1.class);
    }
}
