package com.ielts.cmds.outbox.processor.v2;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielt.cmds.BookingNodeHelper;
import com.ielts.cmds.outbox.processor.v2.helper.LocationNodeHelper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.env.Environment;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;

@ExtendWith(MockitoExtension.class)
class DomainEventListenerV2Test {

    @Mock
    private DomainEventProcessorV2 domainEventProcessor;

    @Mock
    private Environment environment;

    @InjectMocks
    private DomainEventListenerV2 domainEventListener;

    @Test
    void onEvent_WithCMDSEventCall_ExpectDomainEventProcessorToBeCalled() throws JsonProcessingException, InterruptedException {
        LocationNodeHelper helper = new LocationNodeHelper();
        helper.setLocationUuid(UUID.randomUUID());
        helper.setLocationStatus("ACTIVE");
        assertDoesNotThrow(() -> domainEventListener.onEvent(helper));
        verify(domainEventProcessor, times(1)).process(helper);
    }

    @Test
    void onEvent_WithNonCMDSEventCall_ExpectDomainEventProcessorToBeCalled() throws JsonProcessingException, InterruptedException {
        BookingNodeHelper helper = new BookingNodeHelper();
        helper.setBookingUuid(UUID.randomUUID());
        assertDoesNotThrow(() -> domainEventListener.onEvent(helper));
        verify(domainEventProcessor, times(0)).process(helper);
    }

    @Test
    void onEvent_WithException_ExpectRuntimeException() throws JsonProcessingException, InterruptedException {
        LocationNodeHelper helper = new LocationNodeHelper();
        helper.setLocationUuid(UUID.randomUUID());
        helper.setLocationStatus("ACTIVE");
        doThrow(RuntimeException.class).when(domainEventProcessor).process(helper);
        assertThrows(RuntimeException.class, () -> domainEventListener.onEvent(helper));
        verify(domainEventProcessor).process(helper);
    }
}