package com.ielts.cmds.outbox.processor.v1;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;

import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import java.time.LocalDateTime;

import com.ielts.cmds.outbox.processor.v1.BasicEventListener;
import com.ielts.cmds.outbox.processor.v1.BasicEventProcessor;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class BasicEventListenerTest {

    @Mock private BasicEventProcessor basicEventProcessor;

    @InjectMocks private BasicEventListener basicEventListener;

    @Test
    void onEvent_WithNoException_ExpectProcessingToBeSuccessful() {
        final BaseHeader eventHeader = new BaseHeader();
        eventHeader.setEventName("ResultBookingChanged");
        eventHeader.setEventDateTime(LocalDateTime.now());
        final String eventBody = "{\"test\": \"testJson\"}";
        final BaseEvent<BaseHeader> event =
                new BaseEvent<BaseHeader>(eventHeader, eventBody, null, null);
        doNothing().when(basicEventProcessor).process(event);
        assertDoesNotThrow(() -> basicEventListener.onEvent(event));
        verify(basicEventProcessor).process(event);
    }

    @Test
    void onEvent_WithException_ExpectRuntimeException() {
        BaseHeader eventHeader = new BaseHeader();
        eventHeader.setEventName("ResultBookingChanged");
        eventHeader.setEventDateTime(LocalDateTime.now());
        final String eventBody = "{\"test\": \"testJson\"}";
        final BaseEvent<BaseHeader> event =
                new BaseEvent<BaseHeader>(eventHeader, eventBody, null, null);
        doThrow(RuntimeException.class).when(basicEventProcessor).process(event);
        assertThrows(RuntimeException.class, () -> basicEventListener.onEvent(event));
        verify(basicEventProcessor).process(event);
    }
}
