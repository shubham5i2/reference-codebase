package com.ielts.cmds.outbox.event.v2;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.outbox.processor.v2.helper.LocationNodeHelper;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

@ExtendWith(MockitoExtension.class)
class DefaultEventTransformerV2Test {

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private DefaultEventTransformerV2 defaultEventTransformer;

    @Test
    @SneakyThrows
    void applyWithEventBody_ExpectEventToBeSerialised() {
        LocationNodeHelper helper = new LocationNodeHelper();
        helper.setLocationUuid(UUID.randomUUID());
        helper.setLocationStatus("ACTIVE");
        final String expected = new ObjectMapper().writeValueAsString(helper);
        doReturn(expected).when(objectMapper).writeValueAsString(helper);
        final String actual = defaultEventTransformer.apply(helper);
        assertEquals(expected, actual);
    }

    @Test
    @SneakyThrows
    void applyWithEventBody_JsonProcessingException_ExpectException() {
        LocationNodeHelper helper = new LocationNodeHelper();
        helper.setLocationUuid(UUID.randomUUID());
        helper.setLocationStatus("ACTIVE");
        final String expected = new ObjectMapper().writeValueAsString(helper);
        doThrow(JsonProcessingException.class).when(objectMapper).writeValueAsString(helper);
        assertThrows(JsonProcessingException.class, () -> defaultEventTransformer.apply(helper));
    }
}