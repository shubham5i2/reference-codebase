package com.ielts.cmds.outbox.processor.v1;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;

import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import java.time.LocalDateTime;

import com.ielts.cmds.outbox.processor.v1.DomainEventListener;
import com.ielts.cmds.outbox.processor.v1.DomainEventProcessor;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class DomainEventListenerTest {

    @Mock private DomainEventProcessor domainEventProcessor;

    @InjectMocks private DomainEventListener domainEventListener;

    @Test
    void onEvent_WithNoException_ExpectDomainEventProcessorToBeCalled() {
        final BaseHeader eventHeader = new BaseHeader();
        eventHeader.setEventName("ResultBookingChanged");
        eventHeader.setEventDateTime(LocalDateTime.now());
        final String eventBody = "{\"test\": \"testJson\"}";
        final BaseEvent<BaseHeader> event =
                new BaseEvent<BaseHeader>(eventHeader, eventBody, null, null);
        doNothing().when(domainEventProcessor).process(event);
        assertDoesNotThrow(() -> domainEventListener.onEvent(event));
        verify(domainEventProcessor).process(event);
    }

    @Test
    void onEvent_WithException_ExpectRuntimeException() {
        final BaseHeader eventHeader = new BaseHeader();
        eventHeader.setEventName("ResultBookingChanged");
        eventHeader.setEventDateTime(LocalDateTime.now());
        final String eventBody = "{\"test\": \"testJson\"}";
        final BaseEvent<BaseHeader> event =
                new BaseEvent<BaseHeader>(eventHeader, eventBody, null, null);
        doThrow(RuntimeException.class).when(domainEventProcessor).process(event);
        assertThrows(RuntimeException.class, () -> domainEventListener.onEvent(event));
        verify(domainEventProcessor).process(event);
    }
}
