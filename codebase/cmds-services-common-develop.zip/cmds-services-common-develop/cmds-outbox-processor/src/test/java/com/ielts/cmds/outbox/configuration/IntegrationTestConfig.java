package com.ielts.cmds.outbox.configuration;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Profile;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/** @author cts */
@TestPropertySource("classpath:outbox-application.properties")
@EntityScan({"com.ielts.cmds.outbox.infra.entity"})
@EnableJpaRepositories(basePackages = {"com.ielts.cmds.outbox.infra.repository"})
@DataJpaTest
@EnableTransactionManagement
@Profile("test")
public class IntegrationTestConfig {

}
