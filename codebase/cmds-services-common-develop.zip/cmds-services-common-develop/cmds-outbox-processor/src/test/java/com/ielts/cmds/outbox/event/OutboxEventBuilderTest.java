package com.ielts.cmds.outbox.event;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.outbox.event.model.OutboxTransientEvent;

@ExtendWith(MockitoExtension.class)
class OutboxEventBuilderTest {

    @InjectMocks private OutboxEventBuilder outboxEventBuilder;

    @Test
    void buildAsPersistenceIgnored_ExpectOutboxEventIgnoreToBeSetTrue() {
        final UiHeader eventHeader = new UiHeader();
        eventHeader.setEventName("RoChanged");
        eventHeader.setEventDateTime(LocalDateTime.now());
        final String eventBody = "{\"test\": \"testJson\"}";
        final BaseEvent<UiHeader> event =
                new BaseEvent<UiHeader>(eventHeader, eventBody, null, null);
        final OutboxTransientEvent<? extends BaseHeader> outboxTransientEvent =
                (OutboxTransientEvent<? extends BaseHeader>)
                        outboxEventBuilder.buildAsPersistenceIgnored(event);
        assertTrue(outboxTransientEvent.isOutboxIgnore());
        assertEquals(eventHeader, outboxTransientEvent.getEventHeader());
        assertEquals(eventBody, outboxTransientEvent.getEventBody());
    }
}
