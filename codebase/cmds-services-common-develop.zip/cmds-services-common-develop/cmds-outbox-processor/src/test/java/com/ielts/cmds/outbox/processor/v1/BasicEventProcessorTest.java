package com.ielts.cmds.outbox.processor.v1;

import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.outbox.event.v1.EventAttributeExtractor;
import com.ielts.cmds.outbox.event.v1.EventTransformer;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

import java.time.LocalDateTime;

import com.ielts.cmds.outbox.processor.SNSEventPublisher;
import com.ielts.cmds.outbox.processor.v1.BasicEventProcessor;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class BasicEventProcessorTest {

    @Mock private EventTransformer eventTransformer;

    @Mock private EventAttributeExtractor eventAttributeExtractor;

    @Mock private SNSEventPublisher snsEventPublisher;

    @InjectMocks private BasicEventProcessor basicEventProcessor;

    @Test
    void callProcessEvent_ExpectSnsEventPublisherToBeCalled() {
        final BaseHeader eventHeader = new BaseHeader();
        eventHeader.setEventName("ResultBookingChanged");
        eventHeader.setEventDateTime(LocalDateTime.now());
        final String eventBody = "{\"test\": \"testJson\"}";
        final BaseEvent<BaseHeader> event =
                new BaseEvent<BaseHeader>(eventHeader, eventBody, null, null);
        assertDoesNotThrow(() -> basicEventProcessor.process(event));
    }
}
