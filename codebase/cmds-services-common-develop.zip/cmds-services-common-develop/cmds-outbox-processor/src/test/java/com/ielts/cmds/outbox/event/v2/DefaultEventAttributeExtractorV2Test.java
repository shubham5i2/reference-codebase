package com.ielts.cmds.outbox.event.v2;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.outbox.event.model.OutboxEventAttribute;
import com.ielts.cmds.outbox.processor.v2.helper.LocationNodeHelper;
import com.ielts.cmds.outbox.processor.v2.helper.OutboxProcessorV2Helper;
import com.ielts.cmds.infrastructure.event.context.CMDSAuditContext;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DefaultEventAttributeExtractorV2Test {

    @InjectMocks
    private DefaultEventAttributeExtractorV2 defaultEventAttributeExtractor;

    @Spy
    private ObjectMapper mapper;

    @BeforeEach
    void setUp() {
        mapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE, false);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    }

    @Test
    void whenEventAttributesArePresent() {
        LocationNodeHelper helper = new LocationNodeHelper();
        helper.setLocationUuid(UUID.randomUUID());
        helper.setLocationStatus("ACTIVE");

        OutboxProcessorV2Helper.getHeaderContext();
        OutboxProcessorV2Helper.getAuditContext();
        List<OutboxEventAttribute> expected = defaultEventAttributeExtractor.apply(helper);

        assertNotNull(expected);
    }

    @Test
    void when_CMDSHeaderContextIsNotBlank() throws JsonProcessingException {
        LocationNodeHelper helper = new LocationNodeHelper();
        helper.setLocationUuid(UUID.randomUUID());
        helper.setLocationStatus("ACTIVE");

        CMDSHeaderContext headerContext = OutboxProcessorV2Helper.getHeaderContext();
        headerContext.setConnectionId(null);
        headerContext.setEventName(null);
        headerContext.setPartnerCode(null);

        String payload = mapper.writeValueAsString(headerContext);
       
        when(mapper.writeValueAsString(headerContext)).thenReturn(payload);

        List<OutboxEventAttribute> actual = defaultEventAttributeExtractor.apply(helper);

        assertEquals("eventHeaders", actual.get(0).getAttributeKey());
        assertEquals(payload, actual.get(0).getAttributeValue());
    }

    @Test
    void when_ConnectionIdIsNotBlank() throws JsonProcessingException {
        LocationNodeHelper helper = new LocationNodeHelper();
        helper.setLocationUuid(UUID.randomUUID());
        helper.setLocationStatus("ACTIVE");

        CMDSHeaderContext expected = OutboxProcessorV2Helper.getHeaderContext();
        String payload = mapper.writeValueAsString(expected);
        expected.setEventName(null);
        expected.setPartnerCode(null);

        when(mapper.writeValueAsString(ArgumentMatchers.any())).thenReturn(payload);

        List<OutboxEventAttribute> actual = defaultEventAttributeExtractor.apply(helper);

        assertEquals("eventHeaders", actual.get(0).getAttributeKey());
        assertEquals("connectionId", actual.get(1).getAttributeKey());
        assertEquals(payload, actual.get(0).getAttributeValue());
        assertEquals(expected.getConnectionId(), actual.get(1).getAttributeValue());
    }

    @Test
    void when_EventNameIsNotBlank() throws JsonProcessingException {
        LocationNodeHelper helper = new LocationNodeHelper();
        helper.setLocationUuid(UUID.randomUUID());
        helper.setLocationStatus("ACTIVE");

        CMDSHeaderContext expected = OutboxProcessorV2Helper.getHeaderContext();
        String payload = mapper.writeValueAsString(expected);
        expected.setConnectionId(null);
        expected.setPartnerCode(null);

        when(mapper.writeValueAsString(ArgumentMatchers.any())).thenReturn(payload);

        List<OutboxEventAttribute> actual = defaultEventAttributeExtractor.apply(helper);

        assertEquals("eventHeaders", actual.get(0).getAttributeKey());
        assertEquals("eventName", actual.get(1).getAttributeKey());
        assertEquals(payload, actual.get(0).getAttributeValue());
        assertEquals(expected.getEventName(), actual.get(1).getAttributeValue());
    }

    @Test
    void when_PartnerCodeIsNotBlank() throws JsonProcessingException {
        LocationNodeHelper helper = new LocationNodeHelper();
        helper.setLocationUuid(UUID.randomUUID());
        helper.setLocationStatus("ACTIVE");

        CMDSHeaderContext expected = OutboxProcessorV2Helper.getHeaderContext();
        String payload = mapper.writeValueAsString(expected);
        expected.setConnectionId(null);
        expected.setEventName(null);

        when(mapper.writeValueAsString(ArgumentMatchers.any())).thenReturn(payload);

        List<OutboxEventAttribute> actual = defaultEventAttributeExtractor.apply(helper);

        assertEquals("eventHeaders", actual.get(0).getAttributeKey());
        assertEquals("partnerCode", actual.get(1).getAttributeKey());
        assertEquals(payload, actual.get(0).getAttributeValue());
        assertEquals(expected.getPartnerCode(), actual.get(1).getAttributeValue());
    }

    @Test
    void when_AuditIsNotBlank() throws JsonProcessingException {
        LocationNodeHelper helper = new LocationNodeHelper();
        helper.setLocationUuid(UUID.randomUUID());
        helper.setLocationStatus("ACTIVE");

        CMDSHeaderContext expectedHeader = OutboxProcessorV2Helper.getHeaderContext();
        String headerPayload = mapper.writeValueAsString(expectedHeader);
        expectedHeader.setConnectionId(null);
        expectedHeader.setPartnerCode(null);
        expectedHeader.setEventName(null);
        CMDSAuditContext expectedAudit = OutboxProcessorV2Helper.getAuditContext();
        String auditPayload = mapper.writeValueAsString(expectedAudit);

        
        when(mapper.writeValueAsString(expectedHeader)).thenReturn(headerPayload);
        when(mapper.writeValueAsString(expectedAudit)).thenReturn(auditPayload);

        List<OutboxEventAttribute> actual = defaultEventAttributeExtractor.apply(helper);

        assertEquals("audit", actual.get(1).getAttributeKey());
        assertEquals(auditPayload, actual.get(1).getAttributeValue());
    }
}