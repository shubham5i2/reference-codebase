package com.ielts.cmds.outbox.event.v1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import java.time.LocalDateTime;

import com.ielts.cmds.outbox.event.v1.DefaultEventTransformer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
class DefaultEventTransformerTest {

    @Mock private ObjectMapper objectMapper;

    @InjectMocks private DefaultEventTransformer defaultEventTransformer;

    @Test
    @SneakyThrows
    void applyWithBaseHeader_ExpectEventToBeSerialised() {
        final BaseHeader eventHeader = new BaseHeader();
        eventHeader.setEventName("ResultBookingChanged");
        eventHeader.setEventDateTime(LocalDateTime.now());
        final String eventBody = "{\"test\": \"testJson\"}";
        final BaseEvent<BaseHeader> event =
                new BaseEvent<BaseHeader>(eventHeader, eventBody, null, null);
        final String expected = new ObjectMapper().writeValueAsString(event);
        doReturn(expected).when(objectMapper).writeValueAsString(event);
        final String actual = defaultEventTransformer.apply(event);
        assertEquals(expected, actual);
    }
    
    @Test
    @SneakyThrows
    void applyWithUiHeader_ExpectEventToBeSerialised() {
        final UiHeader eventHeader = new UiHeader();
        eventHeader.setConnectionId("sdfdsfsd");
        eventHeader.setEventName("ResultBookingChanged");
        eventHeader.setEventDateTime(LocalDateTime.now());
        final String eventBody = "{\"test\": \"testJson\"}";
        final BaseEvent<UiHeader> event =
                new BaseEvent<UiHeader>(eventHeader, eventBody, null, null);
        final String expected = new ObjectMapper().writeValueAsString(event);
        doReturn(expected).when(objectMapper).writeValueAsString(event);
        final String actual = defaultEventTransformer.apply(event);
        assertEquals(expected, actual);
    }

    @Test
    @SneakyThrows
    void applyWithBaseHeader_JsonProcessingException_ExpectException() {
        final BaseHeader eventHeader = new BaseHeader();
        eventHeader.setEventName("ResultBookingChanged");
        eventHeader.setEventDateTime(LocalDateTime.now());
        final String eventBody = "{\"test\": \"testJson\"}";
        final BaseEvent<BaseHeader> event =
                new BaseEvent<BaseHeader>(eventHeader, eventBody, null, null);
        doThrow(JsonProcessingException.class).when(objectMapper).writeValueAsString(event);
        assertThrows(JsonProcessingException.class, () -> defaultEventTransformer.apply(event));
    }
    
    @Test
    @SneakyThrows
    void applyWithUiHeader_JsonProcessingException_ExpectException() {
        final UiHeader eventHeader = new UiHeader();
        eventHeader.setConnectionId("");
        eventHeader.setEventName("ResultBookingChanged");
        eventHeader.setEventDateTime(LocalDateTime.now());
        final String eventBody = "{\"test\": \"testJson\"}";
        final BaseEvent<UiHeader> event =
                new BaseEvent<UiHeader>(eventHeader, eventBody, null, null);
        doThrow(JsonProcessingException.class).when(objectMapper).writeValueAsString(event);
        assertThrows(JsonProcessingException.class, () -> defaultEventTransformer.apply(event));
    }
}
