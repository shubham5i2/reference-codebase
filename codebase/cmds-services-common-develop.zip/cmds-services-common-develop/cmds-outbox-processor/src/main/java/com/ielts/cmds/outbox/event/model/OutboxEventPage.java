package com.ielts.cmds.outbox.event.model;

import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class OutboxEventPage {

    private int pageSize;

    private int pageNumber;

    private int totalNoOfPage;

    private int totalEventCount;

    private List<OutboxEvent> outboxEvents;
}
