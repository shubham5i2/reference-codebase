package com.ielts.cmds.outbox.event.model;

import com.ielts.cmds.outbox.infra.entity.PublishState;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@Builder(toBuilder = true)
@ToString
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class OutboxEventV1 implements OutboxEvent {

    @EqualsAndHashCode.Include private UUID outboxEventUuid;

    private UUID transactionUuid;

    private String eventName;

    private OffsetDateTime eventDatetime;

    @ToString.Exclude private String payload;

    private PublishState publishState;

    private int retryCount;

    private OffsetDateTime updatedDatetime;

    private List<OutboxEventAttribute> eventAttributes;
}
