package com.ielts.cmds.outbox.infra.entity;

import java.util.UUID;

public interface OutboxEventUuid {
	UUID getOutboxEventUuid();
	
}
