package com.ielts.cmds.outbox.event.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder(toBuilder = true)
public class OutboxEventAttribute {

    private String attributeKey;

    private String attributeValue;
}
