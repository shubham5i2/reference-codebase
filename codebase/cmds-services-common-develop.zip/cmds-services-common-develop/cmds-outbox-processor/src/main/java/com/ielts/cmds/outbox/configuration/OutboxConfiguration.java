package com.ielts.cmds.outbox.configuration;

import com.amazonaws.services.sns.AmazonSNS;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.outbox.event.*;
import com.ielts.cmds.outbox.event.v1.DefaultEventAttributeExtractor;
import com.ielts.cmds.outbox.event.v1.DefaultEventTransformer;
import com.ielts.cmds.outbox.event.v1.EventAttributeExtractor;
import com.ielts.cmds.outbox.event.v1.EventTransformer;
import com.ielts.cmds.outbox.event.v2.DefaultEventAttributeExtractorV2;
import com.ielts.cmds.outbox.event.v2.DefaultEventTransformerV2;
import com.ielts.cmds.outbox.event.v2.EventAttributeExtractorV2;
import com.ielts.cmds.outbox.event.v2.EventTransformerV2;
import com.ielts.cmds.outbox.infra.EventPersistenceService;
import com.ielts.cmds.outbox.infra.repository.OutboxEventRepository;
import com.ielts.cmds.outbox.processor.*;
import com.ielts.cmds.outbox.processor.v1.DomainEventListener;
import com.ielts.cmds.outbox.processor.v1.DomainEventProcessor;
import com.ielts.cmds.outbox.processor.v2.*;
import com.ielts.cmds.outbox.utils.OutboxTopicValidator;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@RequiredArgsConstructor
@Slf4j
@Configuration
public class OutboxConfiguration {

    @Value("${outbox.aws.sns.topic-out.arn}")
    private String outBoundTopicArn;
    
    @Value("${outbox.housekeeping.event-limit}")
    private String housekeepingEventLimit;

    @Value("${outbox.housekeeping.time-limit-in-minutes}")
    private String housekeepingTimeLimit;

    @Value("${outbox.housekeeping.threshold.time-limit-in-minutes}")
    private String housekeepingThresholdTimeLimit;

    @Value("${outbox.replay.threshold.retry-count}")
    private String replayRetryLimit;

    @Value("${outbox.replay.time-limit-in-seconds}")
    private String replayTimeLimit;

    @Value("${outbox.replay.page-size}")
    private String replayPageSize;

    @Value("${outbox.replay.feature.active}")
    private String isReplayEnabled;

    @Value("${outbox.housekeeping.feature.active}")
    private String isHousekeepingEnabled;
    
    @Value("${aws.region}")
    private String region;

    @Value("${aws.accountId}")
    private String accountId;

    @Value("${aws.env}")
    private String awsEnv;

    @Bean
    @ConditionalOnMissingBean
    public EventTransformer eventTransformer(ObjectMapper objectMapper) {
        log.trace(
                "No instance found for EventTransformer. Creating DefaultEventTransformer instance.");
        return new DefaultEventTransformer(objectMapper);
    }

    @Bean
    @ConditionalOnMissingBean
    public EventTransformerV2 eventTransformerV2(ObjectMapper objectMapper) {
        log.trace(
                "No instance found for EventTransformerV2. Creating DefaultEventTransformerV2 instance.");
        return new DefaultEventTransformerV2(objectMapper);
    }

    @Bean
    @ConditionalOnMissingBean
    public EventAttributeExtractor eventAttributeExtractor() {
        log.trace(
                "No instance found for EventAttributeExtractor. Creating DefaultEventAttributeExtractor instance.");
        return new DefaultEventAttributeExtractor();
    }

    @Bean
    @ConditionalOnMissingBean
    public EventAttributeExtractorV2 eventAttributeExtractorV2(ObjectMapper objectMapper) {
        log.trace(
                "No instance found for EventAttributeExtractorV2. Creating DefaultEventAttributeExtractorV2 instance.");
        return new DefaultEventAttributeExtractorV2(objectMapper);
    }

    @Bean
    public EventPersistenceService eventPersistenceService(
            OutboxEventRepository outboxEventRepository,
            OutboxIgnoreManager outboxIgnoreManager) {
        return new EventPersistenceService(outboxEventRepository, outboxIgnoreManager);
    }

    @Bean
    public ApplicationInternalEventPublisher applicationInternalEventPublisher(
            ApplicationEventPublisher applicationEventPublisher) {
        return new ApplicationInternalEventPublisher(applicationEventPublisher);
    }
    
	@Bean
	public SNSEventPublisher snsEventPublisher(final AmazonSNS snsClient,
			final OutboxTopicValidator outboxTopicValidator) {
		return new SNSEventPublisher(outBoundTopicArn, snsClient, outboxTopicValidator);
	}

    @Bean
    public OutboxEventProcessor outboxEventProcessor(
            final SNSEventPublisher eventPublisher,
            final EventPersistenceService eventPersistenceService) {
        return new OutboxEventProcessor(eventPublisher, eventPersistenceService);
    }

    @Bean
    public DomainEventProcessor domainEventProcessor(
            final DefaultEventTransformer eventTransformer,
            final EventPersistenceService eventPersistenceService,
            final EventAttributeExtractor eventAttributeExtractor,
            final ApplicationInternalEventPublisher applicationInternalEventPublisher) {
        return new DomainEventProcessor(
                eventTransformer,
                eventAttributeExtractor,
                eventPersistenceService,
                applicationInternalEventPublisher);
    }

    @Bean
    public DomainEventProcessorV2 domainEventProcessorV2(
            final DefaultEventTransformerV2 eventTransformer,
            final EventPersistenceService eventPersistenceService,
            final EventAttributeExtractorV2 eventAttributeExtractor,
            final ApplicationInternalEventPublisher applicationInternalEventPublisher) {
        return new DomainEventProcessorV2(
                eventTransformer,
                eventAttributeExtractor,
                eventPersistenceService,
                applicationInternalEventPublisher);
    }

    @Bean
    public OutboxEventListener outboxEventListener(
            final OutboxEventProcessor outboxEventProcessor) {
        return new OutboxEventListener(outboxEventProcessor);
    }

    @Bean
    public DomainEventListener domainEventListener(
            final DomainEventProcessor domainEventProcessor) {
        return new DomainEventListener(domainEventProcessor);
    }

    @Bean
    public DomainEventListenerV2 domainEventListenerV2(
            final DomainEventProcessorV2 domainEventProcessorV2) {
        return new DomainEventListenerV2(domainEventProcessorV2);
    }

    @Bean
    public OutboxReplayService outboxReplayService(
            final EventPersistenceService eventPersistenceService,
            final ApplicationInternalEventPublisher applicationInternalEventPublisher,
            final ObjectMapper objectMapper) {
        return new OutboxReplayService(
                isReplayEnabled,
                replayRetryLimit,
                replayTimeLimit,
                replayPageSize,
                eventPersistenceService,
                applicationInternalEventPublisher,
                objectMapper);
    }

    @Bean
    public OutboxHousekeepingService outboxHousekeepingService(
            final EventPersistenceService eventPersistenceService,
            final ApplicationEventPublisher applicationEventPublisher,
            final ObjectMapper objectMapper,
            final OutboxEventBuilder outboxEventBuilder) {
        return new OutboxHousekeepingService(
                isHousekeepingEnabled,
                housekeepingEventLimit,
                housekeepingTimeLimit,
                housekeepingThresholdTimeLimit,
                eventPersistenceService,
                applicationEventPublisher,
                objectMapper,
                outboxEventBuilder);
    }


    @Bean
    public OutboxEventBuilder outboxEventBuilder() {
        return new OutboxEventBuilder();
    }
    
	@Bean
	public OutboxBootstrapService outboxBootstrapService(final AmazonSNS snsClient) {
		return new OutboxBootstrapService(snsClient);
	}

	@Bean
	public OutboxTopicValidator outboxTopicValidator(final OutboxBootstrapService outboxBootstrapService) {
		return new OutboxTopicValidator(region, accountId, awsEnv, outBoundTopicArn, outboxBootstrapService);
	}
}
