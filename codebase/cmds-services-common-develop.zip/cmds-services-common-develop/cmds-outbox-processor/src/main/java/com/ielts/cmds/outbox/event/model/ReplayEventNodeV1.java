package com.ielts.cmds.outbox.event.model;

import java.util.UUID;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ReplayEventNodeV1 {

    private UUID transactionUuid;

    private String eventName;

    private UUID outboxUuid;
}
