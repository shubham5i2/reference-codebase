package com.ielts.cmds.outbox.processor.v2;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.infrastructure.event.context.*;
import com.ielts.cmds.outbox.event.model.OutboxEventAttribute;
import com.ielts.cmds.outbox.event.model.OutboxEventV1;
import com.ielts.cmds.outbox.event.v2.EventAttributeExtractorV2;
import com.ielts.cmds.outbox.event.v2.EventTransformerV2;
import com.ielts.cmds.outbox.infra.EventPersistenceService;
import com.ielts.cmds.outbox.infra.entity.PublishState;
import com.ielts.cmds.outbox.processor.ApplicationInternalEventPublisher;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZoneOffset;
import java.util.List;
import java.util.Queue;
import java.util.UUID;

@Slf4j
@RequiredArgsConstructor
public class DomainEventProcessorV2 {

    @SuppressWarnings("rawtypes")
    private final EventTransformerV2 eventTransformerV2;

    @SuppressWarnings({"rawtypes", "rawtypes"})
    private final EventAttributeExtractorV2 eventAttributeExtractorV2;

    private final EventPersistenceService eventPersistenceService;

    private final ApplicationInternalEventPublisher eventPublisher;

    @Transactional(propagation = Propagation.REQUIRED)
    public <T> void process(final T event) throws JsonProcessingException, InterruptedException {

        log.debug("Domain V2 event processor invoked with meta data: {}", ThreadLocalHeaderContext.getContext());

        OutboxEventV1 outboxEvent = buildOutboxEvent(event);

        eventPersistenceService.save(outboxEvent);

        eventPublisher.publish(outboxEvent);

        log.debug("Domain V2 event processor finished with meta data: {}", ThreadLocalHeaderContext.getContext());
    }

    @SuppressWarnings("unchecked")
    private <T> OutboxEventV1 buildOutboxEvent(final T event) {

        Queue<CMDSHeaderContext> headerQueue = ThreadLocalHeaderQueue.getHeaderQueue();
        CMDSHeaderContext headerContext = headerQueue.poll();
        ThreadLocalHeaderContext.setContext(headerContext);

        Queue<CMDSAuditContext> auditQueue = ThreadLocalAuditQueue.getAuditQueue();
        CMDSAuditContext auditContext = auditQueue.poll();
        ThreadLocalAuditContext.setContext(auditContext);

        final String payload = eventTransformerV2.apply(event);
        final List<OutboxEventAttribute> outboxEventAttributes =
                eventAttributeExtractorV2.apply(event);

        return OutboxEventV1.builder()
                .outboxEventUuid(UUID.randomUUID())
                .transactionUuid(ThreadLocalHeaderContext.getContext().getTransactionId())
                .eventName(ThreadLocalHeaderContext.getContext().getEventName())
                .eventDatetime(ThreadLocalHeaderContext.getContext().getEventDateTime().atOffset(ZoneOffset.UTC))
                .payload(payload)
                .publishState(PublishState.PUBLISH_PENDING)
                .retryCount(0)
                .eventAttributes(outboxEventAttributes)
                .build();
    }
}
