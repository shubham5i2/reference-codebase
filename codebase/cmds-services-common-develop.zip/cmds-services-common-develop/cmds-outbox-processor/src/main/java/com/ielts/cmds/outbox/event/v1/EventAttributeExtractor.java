package com.ielts.cmds.outbox.event.v1;

import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.outbox.event.model.OutboxEventAttribute;
import java.util.List;
import java.util.function.Function;

public interface EventAttributeExtractor
        extends Function<BaseEvent<? extends BaseHeader>, List<OutboxEventAttribute>> {}
