package com.ielts.cmds.outbox.event;

import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.outbox.event.model.OutboxTransientEvent;

public class OutboxEventBuilder {

    public BaseEvent<BaseHeader> buildAsPersistenceIgnored(final BaseEvent<? extends BaseHeader> event) {
        OutboxTransientEvent outboxIgnoredEvent = new OutboxTransientEvent<>();
        outboxIgnoredEvent.setOutboxIgnore(true);
        outboxIgnoredEvent.setEventHeader(event.getEventHeader());
        outboxIgnoredEvent.setEventBody(event.getEventBody());
        outboxIgnoredEvent.setEventErrors(event.getEventErrors());
        outboxIgnoredEvent.setAudit(event.getAudit());

        return outboxIgnoredEvent;
    }
}
