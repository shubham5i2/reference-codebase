package com.ielts.cmds.outbox.infra.entity;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.UUID;
import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "outbox_event_attribute")
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@Getter
public class OutboxEventAttribute implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 4392023579040883618L;

	@Id
    @Column(name = "outbox_event_attribute_uuid")
    private UUID outboxEventAttributeUuid;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "outbox_event_uuid")
    private OutboxEvent outboxEvent;

    @Column(name = "attribute_key")
    private String attributeKey;

    @Column(name = "attribute_value")
    private String attributeValue;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;
}
