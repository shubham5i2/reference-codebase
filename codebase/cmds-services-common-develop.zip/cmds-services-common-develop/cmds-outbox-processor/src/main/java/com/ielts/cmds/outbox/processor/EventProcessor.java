package com.ielts.cmds.outbox.processor;

public interface EventProcessor<T> {

    void process(T event);
}
