package com.ielts.cmds.outbox.processor;

import com.ielts.cmds.outbox.event.model.OutboxEventV1;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

@RequiredArgsConstructor
@Slf4j
public class OutboxEventListener implements EventListener<OutboxEventV1> {

    private final OutboxEventProcessor outboxEventProcessor;

    @Override
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT, fallbackExecution = true)
    public void onEvent(final OutboxEventV1 event) {
        log.debug("Received event for outbox event processing with data as {}", event);

        try {
            outboxEventProcessor.process(event);
        } catch (Exception e) {
            log.error("Outbox event processing failed for event {} with clause", event, e);
        }
    }
}
