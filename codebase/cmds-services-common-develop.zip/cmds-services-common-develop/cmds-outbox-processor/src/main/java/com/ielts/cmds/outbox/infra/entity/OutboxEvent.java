package com.ielts.cmds.outbox.infra.entity;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Version;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "outbox_event")
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class OutboxEvent implements Serializable {

    /** */
    private static final long serialVersionUID = 6164658724612884173L;

    @Id
    @Column(name = "outbox_event_uuid")
    private UUID outboxEventUuid;

    @Column(name = "transaction_uuid")
    private UUID transactionUuid;

    @Column(name = "event_name")
    private String eventName;

    @Column(name = "event_datetime")
    private OffsetDateTime eventDatetime;

    @Column(name = "payload")
    @ToString.Exclude
    private String payload;

    @Enumerated(EnumType.STRING)
    @Column(name = "publish_state")
    private PublishState publishState;

    @Column(name = "retry_count")
    private int retryCount;

    @Column(name = "created_datetime")
    private OffsetDateTime createdDatetime;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;

    @OneToMany(mappedBy = "outboxEvent", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @ToString.Exclude
    private List<OutboxEventAttribute> outboxEventAttributes;

    @Version
    @Column(name = "concurrency_version")
    private int concurrencyVersion;
}
