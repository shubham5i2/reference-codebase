package com.ielts.cmds.outbox.event.v2;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Slf4j
public class DefaultEventTransformerV2 implements EventTransformerV2<Object> {

    private final ObjectMapper objectMapper;

    @SneakyThrows
    @Override
    public String apply(Object event) {
        log.debug("Invoking DefaultEventTransformerV2 with meta data: {}", ThreadLocalHeaderContext.getContext());
        return objectMapper.writeValueAsString(event);
    }
}
