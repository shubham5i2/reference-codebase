package com.ielts.cmds.outbox.processor;

import com.ielts.cmds.outbox.event.model.OutboxEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;

@RequiredArgsConstructor
@Slf4j
public class ApplicationInternalEventPublisher implements EventPublisher<OutboxEvent> {

    private final ApplicationEventPublisher applicationEventPublisher;

    @Override
    public void publish(OutboxEvent event) {
        log.debug("Publishing outbox event in application internal with event data {}", event);
        applicationEventPublisher.publishEvent(event);
    }
}
