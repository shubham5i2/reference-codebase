package com.ielts.cmds.outbox.processor.v2;

import com.ielts.cmds.outbox.processor.EventListener;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Slf4j
public class BasicEventListenerV2<T> implements EventListener<T> {

    @SuppressWarnings("rawtypes")
	private final BasicEventProcessorV2 eventProcessor;

    @SuppressWarnings("unchecked")
	@Override
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void onEvent(T event) {
        log.debug(
                "Received V2 event for basic event processing with data as {}",
                ThreadLocalHeaderContext.getContext());

        try {
            eventProcessor.process(event);
        } catch (RuntimeException e) {
            log.error(
                    "Domain V2 event processing failed for event {} with clause",
                    ThreadLocalHeaderContext.getContext(), e);
            throw e;
        }
    }
}
