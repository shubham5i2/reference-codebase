package com.ielts.cmds.outbox.infra.entity;

public enum PublishState {
    PUBLISH_PENDING,
    PUBLISH_SUCCEED,
    PUBLISH_FAILURE
}
