package com.ielts.cmds.outbox.processor.v2;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.outbox.event.model.OutboxEvent;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

import static com.ielts.cmds.outbox.constant.OutboxConfigConstants.COM_IELTS_CMDS;

@RequiredArgsConstructor
@Slf4j
public class DomainEventListenerV2 {

    private final DomainEventProcessorV2 domainEventProcessorV2;

    @TransactionalEventListener(phase = TransactionPhase.BEFORE_COMMIT, fallbackExecution = true)
    public <T> void onEvent(final T event) throws JsonProcessingException, InterruptedException {
        try {
            log.debug("Domain event listener onEvent called for event: {}", event);
            if ((event.getClass().getPackage().getName().startsWith(COM_IELTS_CMDS)) && !(event instanceof BaseEvent)
                    && !(event instanceof OutboxEvent)) {
                log.debug("Event accepted {}", event);
                log.debug("Received V2 event for domain event processing with meta data: {}", ThreadLocalHeaderContext.getContext());
                domainEventProcessorV2.process(event);
            } else {
                log.debug("Event ignored {}", event);
            }
        } catch (Exception e) {
            log.error(
                    "Domain event processing failed for event {} with clause",
                    ThreadLocalHeaderContext.getContext(),
                    e);
            throw e;
        }
    }
}
