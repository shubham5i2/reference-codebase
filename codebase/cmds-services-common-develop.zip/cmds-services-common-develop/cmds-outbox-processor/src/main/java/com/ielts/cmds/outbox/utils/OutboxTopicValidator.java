package com.ielts.cmds.outbox.utils;

import java.util.HashSet;
import java.util.Set;
import java.util.StringJoiner;

import com.ielts.cmds.outbox.processor.OutboxBootstrapService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import static com.ielts.cmds.outbox.constant.OutboxConfigConstants.*;

@RequiredArgsConstructor
@Slf4j
public class OutboxTopicValidator {

	private final String region;

	private final String accountId;

	private final String awsEnv;

	private final String outBoundTopicArn;

	private final OutboxBootstrapService outboxBootstrapService;

	public Set<String> getValidTopicsToPublish(final String eventName) {

		final Set<String> allTopics = outboxBootstrapService.getAllTopics();
		log.info("Fetched {} topics from OutboxBootstrapService", allTopics.size());

		final String genratedBusinessTopicArn = frameTopicArn(region, accountId, awsEnv, eventName);
		final Set<String> validTopicArnSet = new HashSet<>();
		validTopicArnSet.add(outBoundTopicArn);

		if (allTopics.contains(genratedBusinessTopicArn)) {
			validTopicArnSet.add(genratedBusinessTopicArn);
		}
		log.debug("Matching topic ARNs: {}", validTopicArnSet);
		return validTopicArnSet;
	}

	String frameTopicArn(String region, String accountId, String awsEnv, String eventName) {
		/*
		 * Sample Arn:
		 * arn:aws:sns:eu-west-2:xxxxxx:ielts-cmds-{env}-sns-LocationChanged-topic-out
		 **/
		eventName = eventName.matches(".*V\\d*$")?eventName:eventName.concat(V1);
		StringJoiner topicName = new StringJoiner(HYPHEN);
		topicName.add(IELTS_CMDS)
				.add(awsEnv)
				.add(SNS)
				.add(eventName)
				.add(TOPIC_OUT);

		StringJoiner topicArn = new StringJoiner(COLON);
		topicArn.add(SNS_ARN_PREFIX)
				.add(region)
				.add(accountId)
				.add(topicName.toString());

		log.debug("Constructed Topic ARN - {}", topicArn.toString());
		return topicArn.toString();
	}
}
