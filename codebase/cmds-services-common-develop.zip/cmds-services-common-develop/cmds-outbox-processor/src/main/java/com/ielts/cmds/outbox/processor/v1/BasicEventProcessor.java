package com.ielts.cmds.outbox.processor.v1;

import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.outbox.event.v1.EventAttributeExtractor;
import com.ielts.cmds.outbox.event.v1.EventTransformer;
import com.ielts.cmds.outbox.event.model.OutboxEventAttribute;
import com.ielts.cmds.outbox.event.model.OutboxEventV1;
import java.time.ZoneOffset;
import java.util.List;
import java.util.UUID;

import com.ielts.cmds.outbox.processor.EventProcessor;
import com.ielts.cmds.outbox.processor.SNSEventPublisher;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Slf4j
public class BasicEventProcessor implements EventProcessor<BaseEvent<BaseHeader>> {

    private final EventTransformer eventTransformer;

    private final EventAttributeExtractor eventAttributeExtractor;

    private final SNSEventPublisher snsEventPublisher;

    @Override
    public void process(final BaseEvent<BaseHeader> event) {
        log.debug("Basic event processor starting with data {}", event);

        final String payload = eventTransformer.apply(event);
        final List<OutboxEventAttribute> eventAttributes = eventAttributeExtractor.apply(event);

        OutboxEventV1 transformedEvent =
                OutboxEventV1.builder()
                        .outboxEventUuid(UUID.randomUUID())
                        .eventName(event.getEventHeader().getEventName())
                        .eventDatetime(
                                event.getEventHeader().getEventDateTime().atOffset(ZoneOffset.UTC))
                        .transactionUuid(event.getEventHeader().getTransactionId())
                        .payload(payload)
                        .eventAttributes(eventAttributes)
                        .build();

        snsEventPublisher.publish(transformedEvent);
        log.debug("Event being published from MX with event header as {}", event.getEventHeader());
    }
}
