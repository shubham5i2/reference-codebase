package com.ielts.cmds.outbox.configuration;

import com.amazonaws.services.sns.AmazonSNS;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.outbox.event.v1.DefaultEventAttributeExtractor;
import com.ielts.cmds.outbox.event.v1.DefaultEventTransformer;
import com.ielts.cmds.outbox.event.v1.EventAttributeExtractor;
import com.ielts.cmds.outbox.event.v1.EventTransformer;
import com.ielts.cmds.outbox.event.v2.DefaultEventAttributeExtractorV2;
import com.ielts.cmds.outbox.event.v2.DefaultEventTransformerV2;
import com.ielts.cmds.outbox.event.v2.EventAttributeExtractorV2;
import com.ielts.cmds.outbox.event.v2.EventTransformerV2;
import com.ielts.cmds.outbox.processor.v1.BasicEventListener;
import com.ielts.cmds.outbox.processor.v1.BasicEventProcessor;
import com.ielts.cmds.outbox.utils.OutboxTopicValidator;
import com.ielts.cmds.outbox.processor.SNSEventPublisher;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;

@RequiredArgsConstructor
@Slf4j
public class BasicEventPublisherConfiguration {

    @Value("${outbox.aws.sns.topic-out.arn}")
    private String outBoundTopicArn;

    @Bean
    @ConditionalOnMissingBean
    public EventTransformer eventTransformer(ObjectMapper objectMapper) {
        log.info(
                "No instance found for EventTransformer. Creating DefaultEventTransformer instance.");
        return new DefaultEventTransformer(objectMapper);
    }

    @Bean
    @ConditionalOnMissingBean
    public EventTransformerV2 eventTransformerV2(ObjectMapper objectMapper) {
        log.info(
                "No instance found for EventTransformerV2. Creating DefaultEventTransformerV2 instance.");
        return new DefaultEventTransformerV2(objectMapper);
    }

    @Bean
    @ConditionalOnMissingBean
    public EventAttributeExtractor eventAttributeExtractor() {
        log.info(
                "No instance found for EventAttributeExtractor. Creating DefaultEventAttributeExtractor instance.");
        return new DefaultEventAttributeExtractor();
    }

    @Bean
    @ConditionalOnMissingBean
    public EventAttributeExtractorV2 eventAttributeExtractorV2(ObjectMapper objectMapper) {
        log.info(
                "No instance found for EventAttributeExtractorV2. Creating DefaultEventAttributeExtractorV2 instance.");
        return new DefaultEventAttributeExtractorV2(objectMapper);
    }

	@Bean
	public SNSEventPublisher snsEventPublisher(final AmazonSNS snsClient,
			final OutboxTopicValidator outboxTopicValidator) {
		return new SNSEventPublisher(outBoundTopicArn, snsClient, outboxTopicValidator);
	}

    @Bean
    public BasicEventProcessor basicEventProcessor(
            final EventTransformer eventTransformer,
            final EventAttributeExtractor eventAttributeExtractor,
            final SNSEventPublisher snsEventPublisher) {
        return new BasicEventProcessor(
                eventTransformer, eventAttributeExtractor, snsEventPublisher);
    }

    @Bean
    public BasicEventListener basicEventListener(final BasicEventProcessor basicEventProcessor) {
        return new BasicEventListener(basicEventProcessor);
    }
}
