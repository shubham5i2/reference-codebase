package com.ielts.cmds.outbox.processor;

public interface EventListener<T> {

    void onEvent(T event);
}
