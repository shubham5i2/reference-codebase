package com.ielts.cmds.outbox.event.v1;

import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.outbox.event.model.OutboxEventAttribute;
import java.util.Collections;
import java.util.List;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DefaultEventAttributeExtractor implements EventAttributeExtractor {

    @Override
    public List<OutboxEventAttribute> apply(final BaseEvent<? extends BaseHeader> event) {
        log.debug(
                "Invoking DefaultEventAttributeExtractor with event meta data as {}",
                event.getEventHeader());
        return Collections.emptyList();
    }
}
