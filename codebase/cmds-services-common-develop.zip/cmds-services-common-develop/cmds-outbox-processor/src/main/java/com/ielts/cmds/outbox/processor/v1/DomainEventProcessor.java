package com.ielts.cmds.outbox.processor.v1;

import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.outbox.event.model.OutboxEventAttribute;
import com.ielts.cmds.outbox.event.model.OutboxEventV1;
import com.ielts.cmds.outbox.event.v1.EventAttributeExtractor;
import com.ielts.cmds.outbox.event.v1.EventTransformer;
import com.ielts.cmds.outbox.infra.EventPersistenceService;
import com.ielts.cmds.outbox.infra.entity.PublishState;
import com.ielts.cmds.outbox.processor.ApplicationInternalEventPublisher;
import com.ielts.cmds.outbox.processor.EventProcessor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZoneOffset;
import java.util.List;
import java.util.UUID;

@Slf4j
@RequiredArgsConstructor
public class DomainEventProcessor implements EventProcessor<BaseEvent<? extends BaseHeader>> {

    private final EventTransformer eventTransformer;

    private final EventAttributeExtractor eventAttributeExtractor;

    private final EventPersistenceService eventPersistenceService;

    private final ApplicationInternalEventPublisher eventPublisher;

    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public void process(BaseEvent<? extends BaseHeader> event) {
        log.debug("Domain event processor starting with data {}", event.getEventHeader());

        OutboxEventV1 outboxEvent = buildOutboxEvent(event);

        eventPersistenceService.save(outboxEvent);

        eventPublisher.publish(outboxEvent);

        log.debug("Domain event processor finished with data {}", event.getEventHeader());
    }

    private OutboxEventV1 buildOutboxEvent(final BaseEvent<? extends BaseHeader> event) {

        final String payload = eventTransformer.apply(event);
        final List<OutboxEventAttribute> outboxEventAttributes =
                eventAttributeExtractor.apply(event);

        return OutboxEventV1.builder()
                .outboxEventUuid(UUID.randomUUID())
                .transactionUuid(event.getEventHeader().getTransactionId())
                .eventName(event.getEventHeader().getEventName())
                .eventDatetime(event.getEventHeader().getEventDateTime().atOffset(ZoneOffset.UTC))
                .payload(payload)
                .publishState(PublishState.PUBLISH_PENDING)
                .retryCount(0)
                .eventAttributes(outboxEventAttributes)
                .build();
    }
}
