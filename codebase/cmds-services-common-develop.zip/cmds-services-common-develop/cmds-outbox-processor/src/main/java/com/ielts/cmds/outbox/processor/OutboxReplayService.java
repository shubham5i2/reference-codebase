package com.ielts.cmds.outbox.processor;

import static com.ielts.cmds.outbox.constant.OutboxConfigConstants.SCHEDULER_EVENT_NAME;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.config.IApplicationService;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.outbox.event.model.OutboxEvent;
import com.ielts.cmds.outbox.event.model.OutboxEventPage;
import com.ielts.cmds.outbox.event.model.OutboxEventReplayRequestedNodeV1;
import com.ielts.cmds.outbox.event.model.OutboxEventV1;
import com.ielts.cmds.outbox.infra.EventPersistenceService;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Slf4j
public class OutboxReplayService implements IApplicationService {
	
	private final String isReplayEnabled;
	
	private final String replayRetryCountThreshold;
	
	private final String replayTimeLimitInSeconds;
	
	private final String replayPageSize;
	
    private final EventPersistenceService eventPersistenceService;

    private final ApplicationInternalEventPublisher applicationInternalEventPublisher;

    private final ObjectMapper objectMapper;

    @SneakyThrows
    @Override
    @Transactional(readOnly = true)
    public void process(final BaseEvent<? extends BaseHeader> baseEvent) {
    	Boolean isReplayFeatureEnabled = Boolean.parseBoolean(isReplayEnabled);
    	log.info("Replay Feature Flag: {}. Replay {} happen.", isReplayFeatureEnabled, 
    			isReplayFeatureEnabled ? "will": "will not");
    	if(isReplayFeatureEnabled) {
    		log.info(
                    "Starting Event replay process with meta data as {} and processing configuration as {}",
                    baseEvent.getEventHeader(),
                    baseEvent.getEventBody());

            final OutboxEventReplayRequestedNodeV1 replayConfig =
                    objectMapper.readValue(
                            baseEvent.getEventBody(), OutboxEventReplayRequestedNodeV1.class);

            final List<OutboxEvent> pendingAndFailedEvents = getPendingAndFailedEvents(replayConfig);

            final List<OutboxEvent> requestedEvents = getRequestedEvents(replayConfig);

            List<OutboxEvent> eventsSortedByTime =
                    Stream.concat(pendingAndFailedEvents.stream(), requestedEvents.stream())
                            .map(OutboxEventV1.class::cast)
                            .distinct()
                            .sorted(Comparator.comparing(OutboxEventV1::getUpdatedDatetime))
                            .collect(Collectors.toList());

            eventsSortedByTime.forEach(applicationInternalEventPublisher::publish);

            log.info("Event replay processor finished publishing {} events", eventsSortedByTime.size());
    	}
        
    }

    private List<OutboxEvent> getRequestedEvents(
            final OutboxEventReplayRequestedNodeV1 replayConfig) {
        List<OutboxEvent> requestedEvents =
                Objects.nonNull(replayConfig.getReplayEvents())
                        ? eventPersistenceService.findByTransactionIdAndEventNameAndOutboxUuid(
                                replayConfig.getReplayEvents())
                        : new ArrayList<>();

        log.debug(
                "{} requested event received with received replay config", requestedEvents.size());

        return requestedEvents;
    }

    private List<OutboxEvent> getPendingAndFailedEvents(
            final OutboxEventReplayRequestedNodeV1 replayConfig) {
        int retryCountThreshold =
                Optional.ofNullable(replayConfig.getRetryCountThreshold())
                        .orElse(Integer.valueOf(replayRetryCountThreshold));

        int timeLimitInSecond =
                Optional.ofNullable(replayConfig.getTimeLimitInSecond())
                        .orElse(Integer.valueOf(replayTimeLimitInSeconds));

        int pageSize = Optional.ofNullable(replayConfig.getEventNumberLimit())
        		.orElse(Integer.valueOf(replayPageSize));

        final OutboxEventPage pendingAndFailedEvents =
                eventPersistenceService.findPendingAndFailedEvents(
                        0,
                        pageSize,
                        OffsetDateTime.now().minusSeconds(timeLimitInSecond),
                        retryCountThreshold);

        log.debug(
                "{} pending and failed events fetched out of {} events with configuration: PAGE_SIZE[{}] RETRY_COUNT_THRESHOLD[{}] TIME_LIMIT_IN_SECOND[{}]",
                pendingAndFailedEvents.getOutboxEvents().size(),
                pendingAndFailedEvents.getTotalEventCount(),
                pageSize,
                retryCountThreshold,
                timeLimitInSecond);

        return pendingAndFailedEvents.getOutboxEvents();
    }

    @Override
    public String getServiceIdentifier() {
        return SCHEDULER_EVENT_NAME;
    }
}
