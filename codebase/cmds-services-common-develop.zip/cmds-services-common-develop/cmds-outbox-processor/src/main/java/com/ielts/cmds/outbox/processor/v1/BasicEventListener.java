package com.ielts.cmds.outbox.processor.v1;

import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.outbox.processor.EventListener;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

@RequiredArgsConstructor
@Slf4j
public class BasicEventListener implements EventListener<BaseEvent<BaseHeader>> {

    private final BasicEventProcessor eventProcessor;

    @Override
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void onEvent(BaseEvent<BaseHeader> event) {
        log.debug(
                "Received event for basic event processing with data as {}",
                event.getEventHeader());

        try {
            eventProcessor.process(event);
        } catch (RuntimeException e) {
            log.error(
                    "Domain event processing failed for event {} with clause",
                    event.getEventHeader(),
                    e);
            throw e;
        }
    }
}
