package com.ielts.cmds.outbox.processor.v1;

import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.outbox.processor.EventListener;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

@RequiredArgsConstructor
@Slf4j
public class DomainEventListener implements EventListener<BaseEvent<? extends BaseHeader>> {

    private final DomainEventProcessor domainEventProcessor;

    @Override
    @TransactionalEventListener(phase = TransactionPhase.BEFORE_COMMIT, fallbackExecution = true)
    public void onEvent(BaseEvent<? extends BaseHeader> event) {
        log.debug(
                "Received event for domain event processing with data as {}",
                event.getEventHeader());

        try {
            domainEventProcessor.process(event);
        } catch (RuntimeException e) {
            log.error(
                    "Domain event processing failed for event {} with clause",
                    event.getEventHeader(),
                    e);
            throw e;
        }
    }
}
