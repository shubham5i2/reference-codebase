package com.ielts.cmds.outbox.constant;

public class OutboxConfigConstants {
	
    public static final String SCHEDULER_EVENT_NAME = "OutboxEventReplayRequested";
    public static final String HOUSEKEEPING_EVENT_NAME = "OutboxDeleteEventRequested";
    public static final String HOUSEKEEPING_OUT_EVENT_NAME = "OutboxDeletionCompleted";
    
    public static final String EVENT_NAME = "eventName";
    public static final String PARTNER_CODE = "partnerCode";
    public static final String CONNECTION_ID = "connectionId";
    public static final String EVENT_HEADERS = "eventHeaders";
    public static final String AUDIT = "audit";
    public static final String COM_IELTS_CMDS = "com.ielts.cmds";
    public static final String OUTBOX_AWS_SNS = "outbox.aws.sns";
    public static final String SNS_ARN_PREFIX = "arn:aws:sns";
    public static final String IELTS_CMDS = "ielts-cmds";
    public static final String TOPIC_OUT = "topic-out";
    public static final String ARN = "arn";
    public static final String SNS = "sns";
    public static final String COLON = ":";
    public static final String HYPHEN = "-";
    public static final String PERIOD = ".";
    public static final String V1 = "V1";

    private OutboxConfigConstants() {}
}
