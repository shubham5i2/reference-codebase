package com.ielts.cmds.outbox.processor;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ielts.cmds.outbox.event.model.OutboxEventV1;
import com.ielts.cmds.outbox.infra.EventPersistenceService;
import com.ielts.cmds.outbox.infra.entity.PublishState;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Slf4j
public class OutboxEventProcessor implements EventProcessor<OutboxEventV1> {

  private final SNSEventPublisher snsEventPublisher;

  private final EventPersistenceService eventPersistenceService;

  @Override
  @Transactional(propagation = Propagation.REQUIRES_NEW)
  public void process(final OutboxEventV1 event) {
    log.debug("Outbox event processor starting with data {}", event);

    try {
      snsEventPublisher.publish(event);
      eventPersistenceService.delete(event);
      log.info(
          "Outbox event processor published event with event name[{}] and event id[{}] to SNS successfully and deleted event from outbox table.",
          event.getEventName(),
          event.getOutboxEventUuid());
    } catch (Exception e) {
      event.setPublishState(PublishState.PUBLISH_FAILURE);
      event.setRetryCount(event.getRetryCount() + 1);
      eventPersistenceService.save(event);
      log.error(
          "Outbox event processor event publishing failed for event with event name[{}] and event id[{}] with clause",
          event.getEventName(),
          event.getOutboxEventUuid(),
          e);
    }
  }
}
