package com.ielts.cmds.outbox.event.v2;

import java.util.List;

import com.ielts.cmds.outbox.event.model.OutboxEventAttribute;

public interface EventAttributeExtractorV2<T> {

    List<OutboxEventAttribute> apply(T event);
}
