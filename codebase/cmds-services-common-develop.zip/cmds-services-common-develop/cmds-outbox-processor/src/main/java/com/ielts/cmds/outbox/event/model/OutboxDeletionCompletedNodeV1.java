package com.ielts.cmds.outbox.event.model;

import java.time.OffsetDateTime;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@Builder(toBuilder = true)
@ToString
@EqualsAndHashCode
public class OutboxDeletionCompletedNodeV1 implements OutboxEvent {

    private OffsetDateTime fromTimeStamp;

    private OffsetDateTime toTimeStamp;

    private Long numberOfElementsDeleted;

}
