package com.ielts.cmds.outbox.event.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class OutboxDeleteEventRequestedNodeV1 {

    private Integer timeLimitInMinutes;

    private Integer eventNumberLimit;
}
