package com.ielts.cmds.outbox.infra;

import java.time.OffsetDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import com.ielts.cmds.outbox.configuration.OutboxIgnoreManager;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;

import com.ielts.cmds.outbox.event.model.OutboxDeletionCompletedNodeV1;
import com.ielts.cmds.outbox.event.model.OutboxEvent;
import com.ielts.cmds.outbox.event.model.OutboxEventPage;
import com.ielts.cmds.outbox.event.model.OutboxEventV1;
import com.ielts.cmds.outbox.event.model.ReplayEventNodeV1;
import com.ielts.cmds.outbox.infra.entity.OutboxEventAttribute;
import com.ielts.cmds.outbox.infra.entity.OutboxEventUuid;
import com.ielts.cmds.outbox.infra.entity.PublishState;
import com.ielts.cmds.outbox.infra.repository.OutboxEventRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Slf4j
public class EventPersistenceService {

    private final OutboxEventRepository outboxEventRepository;

    private final OutboxIgnoreManager outboxIgnoreManager;
    
    public OutboxEvent deleteOldEvents(final OffsetDateTime beforeTime, 
    		final Integer eventNumberLimit,
    		final Integer page) {
    	final Sort sort = Sort.by(Direction.ASC, "updatedDatetime");
		final PageRequest pageRequest = PageRequest.of(page, eventNumberLimit, sort );
		final Page<OutboxEventUuid> outboxEventUuids = outboxEventRepository
				.findOutboxEventUuidByPublishStateAndUpdatedDatetimeBefore(
				PublishState.PUBLISH_SUCCEED, beforeTime, pageRequest);
		final List<UUID> outboxEventUuidList = outboxEventUuids.stream()
				.map(OutboxEventUuid::getOutboxEventUuid)
				.collect(Collectors.toList());
		
		final long numberOfEventsDeleted = 
				outboxEventRepository.deleteByOutboxEventUuidIn(outboxEventUuidList);
		final OutboxDeletionCompletedNodeV1 eventToBePublished = 
				buildOutboxDeletionCompletedNode(beforeTime, numberOfEventsDeleted);

		return eventToBePublished;
    }

    private OutboxDeletionCompletedNodeV1 buildOutboxDeletionCompletedNode(OffsetDateTime toTimeStamp, long numberOfEventsDeleted) {
    	OutboxDeletionCompletedNodeV1 outboxDeletionCompletedNodeV1 = 
    			OutboxDeletionCompletedNodeV1.builder()
    			.toTimeStamp(toTimeStamp)
    			.numberOfElementsDeleted(Long.valueOf(numberOfEventsDeleted))
    			.build();
    	return outboxDeletionCompletedNodeV1;
		
	}

	public List<OutboxEvent> findByTransactionIdAndEventNameAndOutboxUuid(
            final List<ReplayEventNodeV1> arg) {
        final List<UUID> transactionUuids =
                arg.stream()
                        .map(ReplayEventNodeV1::getTransactionUuid)
                        .collect(Collectors.toList());

        final List<String> eventNames =
                arg.stream().map(ReplayEventNodeV1::getEventName).collect(Collectors.toList());

        final List<UUID> outboxUuids =
                arg.stream().map(ReplayEventNodeV1::getOutboxUuid).collect(Collectors.toList());

        final List<com.ielts.cmds.outbox.infra.entity.OutboxEvent> events =
                outboxEventRepository.findByTransactionUuidInAndEventNameInAndOutboxEventUuidIn(
                        transactionUuids, eventNames, outboxUuids);
        return events.stream()
                .filter(e -> filterByNode(e, arg))
                .map(this::mapFromEntityToModel)
                .collect(Collectors.toList());
    }

    boolean filterByNode(
            final com.ielts.cmds.outbox.infra.entity.OutboxEvent event,
            final List<ReplayEventNodeV1> arg) {
        return arg.stream()
                .anyMatch(
                        e ->
                                event.getTransactionUuid().equals(e.getTransactionUuid())
                                        && event.getEventName().equals(e.getEventName()));
    }

    public OutboxEventPage findPendingAndFailedEvents(
            final int pageNumber,
            final int pageSize,
            final OffsetDateTime pastLimit,
            final int retryCountThreshold) {
        final Page<com.ielts.cmds.outbox.infra.entity.OutboxEvent> events =
                outboxEventRepository.findByPublishStateInAndUpdatedDatetimeAfter(
                        Arrays.asList(PublishState.PUBLISH_PENDING, PublishState.PUBLISH_FAILURE),
                        pastLimit,
                        PageRequest.of(pageNumber, pageSize));

        final List<OutboxEvent> outboxEvents =
                events.stream()
                        .filter(e -> e.getRetryCount() < retryCountThreshold)
                        .map(this::mapFromEntityToModel)
                        .collect(Collectors.toList());

        return OutboxEventPage.builder()
                .outboxEvents(outboxEvents)
                .pageNumber(events.getNumber())
                .pageSize(events.getSize())
                .totalNoOfPage(events.getTotalPages())
                .totalEventCount((int) events.getTotalElements())
                .build();
    }

    public com.ielts.cmds.outbox.infra.entity.OutboxEvent save(final OutboxEventV1 event) {
        // Event will not be persisted if this event is marked as outbox ignored
        if (!outboxIgnoreManager.isOutboxIgnore(event)) {
            final Optional<com.ielts.cmds.outbox.infra.entity.OutboxEvent> optionalOutboxEvent =
                    outboxEventRepository.findById(event.getOutboxEventUuid());

            final com.ielts.cmds.outbox.infra.entity.OutboxEvent outboxEvent =
                    optionalOutboxEvent.orElseGet(
                            () -> com.ielts.cmds.outbox.infra.entity.OutboxEvent.builder().build());

            if (optionalOutboxEvent.isPresent()) {
                outboxEvent.setPublishState(event.getPublishState());
                outboxEvent.setRetryCount(event.getRetryCount());
                outboxEvent.setUpdatedDatetime(OffsetDateTime.now());
            } else {
                outboxEvent.setOutboxEventUuid(event.getOutboxEventUuid());
                outboxEvent.setTransactionUuid(event.getTransactionUuid());
                outboxEvent.setEventName(event.getEventName());
                outboxEvent.setEventDatetime(event.getEventDatetime());
                outboxEvent.setPayload(event.getPayload());
                outboxEvent.setPublishState(event.getPublishState());
                outboxEvent.setRetryCount(0);
                outboxEvent.setCreatedDatetime(OffsetDateTime.now());
                outboxEvent.setUpdatedDatetime(OffsetDateTime.now());

                final List<OutboxEventAttribute> outboxEventAttributes =
                        event.getEventAttributes().stream()
                                .map(
                                        e ->
                                                OutboxEventAttribute.builder()
                                                        .outboxEventAttributeUuid(UUID.randomUUID())
                                                        .outboxEvent(outboxEvent)
                                                        .attributeKey(e.getAttributeKey())
                                                        .attributeValue(e.getAttributeValue())
                                                        .updatedDatetime(OffsetDateTime.now())
                                                        .build())
                                .collect(Collectors.toList());

                outboxEvent.setOutboxEventAttributes(outboxEventAttributes);
            }

            log.debug("Starting persisting event with data {}", outboxEvent);
            return outboxEventRepository.save(outboxEvent);
        } else {
            log.debug("Ignoring event : {} for persistence", event.getEventName());
            return new com.ielts.cmds.outbox.infra.entity.OutboxEvent();
        }

    }

    private OutboxEvent mapFromEntityToModel(com.ielts.cmds.outbox.infra.entity.OutboxEvent event) {
        final List<com.ielts.cmds.outbox.event.model.OutboxEventAttribute> eventAttributes =
                event.getOutboxEventAttributes().stream()
                        .map(
                                e ->
                                        com.ielts.cmds.outbox.event.model.OutboxEventAttribute
                                                .builder()
                                                .attributeKey(e.getAttributeKey())
                                                .attributeValue(e.getAttributeValue())
                                                .build())
                        .collect(Collectors.toList());

        return OutboxEventV1.builder()
                .outboxEventUuid(event.getOutboxEventUuid())
                .transactionUuid(event.getTransactionUuid())
                .eventName(event.getEventName())
                .eventDatetime(event.getEventDatetime())
                .payload(event.getPayload())
                .publishState(event.getPublishState())
                .retryCount(event.getRetryCount())
                .updatedDatetime(event.getUpdatedDatetime())
                .eventAttributes(eventAttributes)
                .build();
    }

    public void delete(final OutboxEventV1 event) {
        // Event will not be deleted if this event is marked as outbox ignored - because it doesn't get persisted in first place
        if (!outboxIgnoreManager.isOutboxIgnore(event)) {
            log.info("Event name:{} not ignored, deleting event with outbox_event_uuid:{}", event.getEventName(), event.getOutboxEventUuid());
            outboxEventRepository.deleteById(event.getOutboxEventUuid());
        }
    }
}
