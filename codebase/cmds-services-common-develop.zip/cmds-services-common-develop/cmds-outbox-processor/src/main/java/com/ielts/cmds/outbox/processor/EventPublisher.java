package com.ielts.cmds.outbox.processor;

public interface EventPublisher<T> {

    void publish(T event);
}
