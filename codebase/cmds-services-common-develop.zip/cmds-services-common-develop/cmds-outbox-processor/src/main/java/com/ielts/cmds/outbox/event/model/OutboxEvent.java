package com.ielts.cmds.outbox.event.model;

public interface OutboxEvent {}
