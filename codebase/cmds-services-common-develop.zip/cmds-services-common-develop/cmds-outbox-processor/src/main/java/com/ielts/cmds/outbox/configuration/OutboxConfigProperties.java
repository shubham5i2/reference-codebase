package com.ielts.cmds.outbox.configuration;

import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.ielts.cmds.outbox.processor.OutboxHousekeepingService;

@Configuration
@ConditionalOnBean(OutboxHousekeepingService.class)
@PropertySource(value = {"classpath:outbox-application.properties", "classpath:application.properties"})
public class OutboxConfigProperties {

}
