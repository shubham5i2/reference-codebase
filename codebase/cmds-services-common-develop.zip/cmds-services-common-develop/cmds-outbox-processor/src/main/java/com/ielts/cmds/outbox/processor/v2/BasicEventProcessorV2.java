package com.ielts.cmds.outbox.processor.v2;

import java.time.ZoneOffset;
import java.util.List;
import java.util.UUID;

import com.ielts.cmds.outbox.event.model.OutboxEventAttribute;
import com.ielts.cmds.outbox.event.model.OutboxEventV1;
import com.ielts.cmds.outbox.event.v2.EventAttributeExtractorV2;
import com.ielts.cmds.outbox.event.v2.EventTransformerV2;
import com.ielts.cmds.outbox.processor.EventProcessor;
import com.ielts.cmds.outbox.processor.SNSEventPublisher;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Slf4j
public class BasicEventProcessorV2<T> implements EventProcessor<T> {

    @SuppressWarnings("rawtypes")
	private final EventTransformerV2 eventTransformer;

    @SuppressWarnings("rawtypes")
	private final EventAttributeExtractorV2 eventAttributeExtractor;

    private final SNSEventPublisher snsEventPublisher;

    @SuppressWarnings("unchecked")
	@Override
    public void process(T event) {
        log.debug("Basic V2 event processor starting with data {}", event);

        final String payload = eventTransformer.apply(event);
        final List<OutboxEventAttribute> eventAttributes = eventAttributeExtractor.apply(event);

        OutboxEventV1 transformedEvent =
                OutboxEventV1.builder()
                        .outboxEventUuid(UUID.randomUUID())
                        .eventName(ThreadLocalHeaderContext.getContext().getEventName())
                        .eventDatetime(
                                ThreadLocalHeaderContext.getContext().getEventDateTime().atOffset(ZoneOffset.UTC))
                        .transactionUuid(ThreadLocalHeaderContext.getContext().getTransactionId())
                        .payload(payload)
                        .eventAttributes(eventAttributes)
                        .build();

        snsEventPublisher.publish(transformedEvent);
        log.debug("Event V2 being published from MX with event header as {}", ThreadLocalHeaderContext.getContext());
    }
}
