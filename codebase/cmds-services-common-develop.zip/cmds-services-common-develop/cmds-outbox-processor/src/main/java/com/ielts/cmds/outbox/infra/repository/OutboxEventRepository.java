package com.ielts.cmds.outbox.infra.repository;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ielts.cmds.outbox.infra.entity.OutboxEvent;
import com.ielts.cmds.outbox.infra.entity.OutboxEventUuid;
import com.ielts.cmds.outbox.infra.entity.PublishState;

@Repository
public interface OutboxEventRepository extends JpaRepository<OutboxEvent, UUID> {

    Page<OutboxEvent> findByPublishStateInAndUpdatedDatetimeAfter(
            List<PublishState> publishStates, OffsetDateTime updatedDatetime, Pageable pageable);

    List<OutboxEvent> findByTransactionUuidInAndEventNameInAndOutboxEventUuidIn(
            List<UUID> transactionUuids, List<String> eventNames, List<UUID> outboxUuids);
    
   Page<OutboxEventUuid> findOutboxEventUuidByPublishStateAndUpdatedDatetimeBefore(
    		PublishState publishState, OffsetDateTime updatedDatetime, Pageable pageable);
    
    long deleteByOutboxEventUuidIn(final Iterable<UUID> outboxEventUuidList);
    
}
