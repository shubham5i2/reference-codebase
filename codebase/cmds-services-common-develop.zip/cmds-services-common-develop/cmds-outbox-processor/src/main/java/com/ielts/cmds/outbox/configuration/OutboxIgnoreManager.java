package com.ielts.cmds.outbox.configuration;

import com.ielts.cmds.outbox.event.model.OutboxEventV1;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Getter
@Setter
@Component
@ConfigurationProperties(prefix = "outbox")
public class OutboxIgnoreManager {

    private Map<String, String> ignore = new HashMap<>();

    public boolean isOutboxIgnore(OutboxEventV1 outboxEventV1) {
        return Boolean.parseBoolean(ignore.get(outboxEventV1.getEventName()));
    }
}
