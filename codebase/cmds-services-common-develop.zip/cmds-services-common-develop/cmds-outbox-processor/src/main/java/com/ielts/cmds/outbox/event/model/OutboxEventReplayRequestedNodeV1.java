package com.ielts.cmds.outbox.event.model;

import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class OutboxEventReplayRequestedNodeV1 {

    private Integer retryCountThreshold;

    private Integer timeLimitInSecond;

    private Integer eventNumberLimit;

    private List<ReplayEventNodeV1> replayEvents = new ArrayList<>();
}
