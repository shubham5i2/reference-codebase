package com.ielts.cmds.outbox.event.v1;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Slf4j
public class DefaultEventTransformer implements EventTransformer {

    private final ObjectMapper objectMapper;

    @SneakyThrows
    @Override
    public String apply(final BaseEvent<? extends BaseHeader> event) {
        log.debug(
                "Invoking DefaultEventTransformer with event meta data as {}",
                event.getEventHeader());
        return objectMapper.writeValueAsString(event);
    }
}
