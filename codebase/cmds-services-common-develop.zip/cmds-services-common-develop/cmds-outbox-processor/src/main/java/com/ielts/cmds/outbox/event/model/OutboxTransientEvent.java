package com.ielts.cmds.outbox.event.model;

import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class OutboxTransientEvent<T extends BaseHeader> extends BaseEvent<T> {

    /** */
    private static final long serialVersionUID = -3259007921879221075L;

    private boolean outboxIgnore;

    public OutboxTransientEvent() {
        super();
    }


}
