package com.ielts.cmds.outbox.event.v1;

import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import java.util.function.Function;

public interface EventTransformer extends Function<BaseEvent<? extends BaseHeader>, String> {}
