package com.ielts.cmds.outbox.processor;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.MessageAttributeValue;
import com.amazonaws.services.sns.model.PublishRequest;
import com.ielts.cmds.outbox.event.model.OutboxEventAttribute;
import com.ielts.cmds.outbox.event.model.OutboxEventV1;
import com.ielts.cmds.outbox.utils.OutboxTopicValidator;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Slf4j
public class SNSEventPublisher implements EventPublisher<OutboxEventV1> {

    private final String outBoundTopicArn;

    private final AmazonSNS snsClient;
    
    private final OutboxTopicValidator outboxTopicValidator;

    @Override
    public void publish(final OutboxEventV1 event) {
        log.debug(
                "Publishing event to SNS. EventName:{} TransactionId:{} TargetSNS:{}",
                event.getEventName(),
                event.getTransactionUuid(),
                outBoundTopicArn);
        final Map<String, MessageAttributeValue> messageAttributes =
                getMessageAttributes(event.getEventAttributes());
        
        Set<String> validTopicArnSet = outboxTopicValidator.getValidTopicsToPublish(event.getEventName());
        for(final String topicArn : validTopicArnSet) {

			final PublishRequest publishRequest = createPublishRequestInstance(event, messageAttributes, topicArn);
	
	        log.debug("Event published from outbox {} to topic {}", publishRequest, topicArn);
	
	        snsClient.publish(publishRequest);
        
        }

        log.info("Event with EventName: {} published to topic(s): {}", event.getEventName(), validTopicArnSet);
    }

	PublishRequest createPublishRequestInstance(final OutboxEventV1 event,
			final Map<String, MessageAttributeValue> messageAttributes, final String topicArn) {
		return new PublishRequest().withMessageAttributes(messageAttributes).withTopicArn(topicArn)
				.withMessage(event.getPayload());
	}

    Map<String, MessageAttributeValue> getMessageAttributes(
            final List<OutboxEventAttribute> outboxEventAttributes) {
        final Map<String, MessageAttributeValue> messageAttributes = new HashMap<>();

        final Set<String> jsonAttributes = new HashSet<>();
        jsonAttributes.add("eventHeaders");
        jsonAttributes.add("audit");
        outboxEventAttributes.forEach(
                e -> {
                	if(jsonAttributes.contains(e.getAttributeKey())) {
                		messageAttributes.put(
                                e.getAttributeKey(),
                                new MessageAttributeValue()
                                        .withDataType("String.Array")
                                        .withStringValue(e.getAttributeValue()));
                	} else {
                		messageAttributes.put(
                                e.getAttributeKey(),
                                new MessageAttributeValue()
                                        .withDataType("String")
                                        .withStringValue(e.getAttributeValue()));
                	}
                	
                });

        return messageAttributes;
    }
}
