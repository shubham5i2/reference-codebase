package com.ielts.cmds.outbox.event.v2;

public interface EventTransformerV2<T> {

    String apply(T event);
}
