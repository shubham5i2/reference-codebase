package com.ielts.cmds.outbox.processor;

import static com.ielts.cmds.outbox.constant.OutboxConfigConstants.HOUSEKEEPING_EVENT_NAME;
import static com.ielts.cmds.outbox.constant.OutboxConfigConstants.HOUSEKEEPING_OUT_EVENT_NAME;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.config.IApplicationService;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.outbox.event.OutboxEventBuilder;
import com.ielts.cmds.outbox.event.model.OutboxDeleteEventRequestedNodeV1;
import com.ielts.cmds.outbox.event.model.OutboxEvent;
import com.ielts.cmds.outbox.infra.EventPersistenceService;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Slf4j
public class OutboxHousekeepingService implements IApplicationService {
	
	private final String isHousekeepingEnabled;

	private final String housekeepingEventLimit;
	
	private final String housekeepingTimeLimitInMinutes;
	
	private final String housekeepingThresholdTimeInMinutes;
	
    private final EventPersistenceService eventPersistenceService;

    private final ApplicationEventPublisher eventPublisher;

    private final ObjectMapper objectMapper;
    
    private final OutboxEventBuilder outboxEventBuilder;

    @SneakyThrows
    @Override
    @Transactional
    public void process(final BaseEvent<? extends BaseHeader> baseEvent) {
    	Boolean isHousekeepingFeatureEnabled = Boolean.parseBoolean(isHousekeepingEnabled);
    	log.info("Housekeeping Feature Flag: {}. Housekeeping {} happen.", isHousekeepingFeatureEnabled, 
    			isHousekeepingFeatureEnabled ? "will": "will not");
    	if(isHousekeepingFeatureEnabled) {
    		log.info(
    				"Starting Housekeeping process with meta data as {} and processing configuration as {}",
    				baseEvent.getEventHeader(),
    				baseEvent.getEventBody());

    		final OutboxDeleteEventRequestedNodeV1 houseKeepingConfig =
    				objectMapper.readValue(
    						baseEvent.getEventBody(), OutboxDeleteEventRequestedNodeV1.class);

    		final OffsetDateTime beforeTime = getTimestampForDeletion(houseKeepingConfig);
    		final Integer eventNumberLimit = getEventNumberLimit(houseKeepingConfig);
    		log.info("Events before {} will be deleted and Event Number Limit: {}", beforeTime, eventNumberLimit);
    		final OutboxEvent outboxDeleteEventCompleted = 
    				eventPersistenceService.deleteOldEvents(beforeTime, eventNumberLimit, 0);

    		final BaseEvent<BaseHeader> event = buildBaseEvent(baseEvent.getEventHeader(), outboxDeleteEventCompleted);
    		log.debug("Event to be published: {}", event);
    		eventPublisher.publishEvent(outboxEventBuilder.buildAsPersistenceIgnored(event));
    	}
    }

    @SneakyThrows
    private BaseEvent<BaseHeader> buildBaseEvent(final BaseHeader baseHeader,
			final OutboxEvent outboxDeleteEventCompleted) {
    	final BaseHeader eventHeader = new BaseHeader();
    	BeanUtils.copyProperties(baseHeader, eventHeader);
    	eventHeader.setEventName(HOUSEKEEPING_OUT_EVENT_NAME);
    	eventHeader.setEventDateTime(LocalDateTime.now());
		final BaseEvent<BaseHeader> event = 
				new BaseEvent<BaseHeader>(eventHeader, 
						objectMapper.writeValueAsString(outboxDeleteEventCompleted),
						null, null);
		return event;
	}

	@Override
    public String getServiceIdentifier() {
        return HOUSEKEEPING_EVENT_NAME;
    }
	
	/**
	 * Method to return timeStampForDeletion from configuration 
	 * @param houseKeepingConfig
	 * @return {@link OffsetDateTime} timeStampForDeletion
	 */
	OffsetDateTime getTimestampForDeletion(final OutboxDeleteEventRequestedNodeV1 houseKeepingConfig) {
		final Integer timeLimitInMinutes = Optional.ofNullable(houseKeepingConfig.getTimeLimitInMinutes())
				.filter(timeLimit -> timeLimit.longValue() > Integer.valueOf(housekeepingThresholdTimeInMinutes).intValue())
				.orElse(Integer.valueOf(housekeepingTimeLimitInMinutes));
		log.info("Time Limit (in minutes) Picked Up: {}", timeLimitInMinutes);
		return OffsetDateTime.now().minusMinutes(timeLimitInMinutes.longValue());
				
	}
	
	/**
	 * Method to return eventNumberLimit from configuration
	 * @param houseKeepingConfig
	 * @return {@link Integer} eventNumberLimit
	 */
	Integer getEventNumberLimit(final OutboxDeleteEventRequestedNodeV1 houseKeepingConfig) {
		return Optional.ofNullable(houseKeepingConfig.getEventNumberLimit())
				.orElse(Integer.valueOf(housekeepingEventLimit));
		
	}
}

