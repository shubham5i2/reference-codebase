package com.ielts.cmds.outbox.processor;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.ListTopicsResult;
import com.amazonaws.services.sns.model.Topic;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Slf4j
public class OutboxBootstrapService {

	private final AmazonSNS snsClient;

	private static Set<String> outboxTopics = new HashSet<>();

	@PostConstruct
	void fetchAndBootstrapAllTopicsFromAws() {
		ListTopicsResult listTopicsResult = snsClient.listTopics();
		fetchAndAddTopicsToSet(listTopicsResult.getTopics());

		/*
		 * ListTopicResult contains only 100 topics hence use next token to get next 100
		 * topics.
		 */
		String nextToken = listTopicsResult.getNextToken();
		while (nextToken != null) {
			listTopicsResult = snsClient.listTopics(nextToken);
			fetchAndAddTopicsToSet(listTopicsResult.getTopics());

			nextToken = listTopicsResult.getNextToken();
		}

		log.info("Successfully added {} Topic ARNs from AWS to OutboxTopics", outboxTopics.size());
		log.debug("Fetched Topic ARNs: {}", outboxTopics);
	}

	void fetchAndAddTopicsToSet(List<Topic> topics) {
		List<String> topicArns = fetchTopicArnListFromTopics(topics);
		outboxTopics.addAll(topicArns);
		log.info("Fetched {} topics from AWS and added their ARNs to OutboxTopics", topics.size());
	}

	List<String> fetchTopicArnListFromTopics(List<Topic> topics) {
		return topics.stream().map(Topic::getTopicArn).collect(Collectors.toList());
	}

	public Set<String> getAllTopics() {
		return outboxTopics;
	}
}
