package com.ielts.cmds.outbox.event.v2;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.ielts.cmds.outbox.event.model.OutboxEventAttribute;
import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.outbox.constant.OutboxConfigConstants;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
public class DefaultEventAttributeExtractorV2 implements EventAttributeExtractorV2<Object> {

    private final ObjectMapper mapper;

    @SneakyThrows
    @Override
    public List<OutboxEventAttribute> apply(Object event) {
        log.debug("Invoking DefaultEventAttributeExtractorV2 with meta data: {}", ThreadLocalHeaderContext.getContext());

        List<OutboxEventAttribute> outboxEventAttributes = new ArrayList<>();

        if (Objects.nonNull(ThreadLocalHeaderContext.getContext())) {
            outboxEventAttributes.add(OutboxEventAttribute.builder()
                    .attributeKey(OutboxConfigConstants.EVENT_HEADERS)
                    .attributeValue(mapper.writeValueAsString(ThreadLocalHeaderContext.getContext()))
                    .build());
        }

        if (StringUtils.isNotBlank(ThreadLocalHeaderContext.getContext().getConnectionId())) {
            outboxEventAttributes.add(OutboxEventAttribute.builder()
                    .attributeKey(OutboxConfigConstants.CONNECTION_ID)
                    .attributeValue(ThreadLocalHeaderContext.getContext().getConnectionId())
                    .build());
        }

        if (StringUtils.isNotBlank(ThreadLocalHeaderContext.getContext().getEventName())) {
            outboxEventAttributes.add(OutboxEventAttribute.builder()
                    .attributeKey(OutboxConfigConstants.EVENT_NAME)
                    .attributeValue(ThreadLocalHeaderContext.getContext().getEventName())
                    .build());
        }

        if (StringUtils.isNotBlank(ThreadLocalHeaderContext.getContext().getPartnerCode())) {
            outboxEventAttributes.add(OutboxEventAttribute.builder()
                    .attributeKey(OutboxConfigConstants.PARTNER_CODE)
                    .attributeValue(ThreadLocalHeaderContext.getContext().getPartnerCode())
                    .build());
        }

        if (Objects.nonNull(ThreadLocalAuditContext.getContext())) {
            outboxEventAttributes.add(OutboxEventAttribute.builder()
                    .attributeKey(OutboxConfigConstants.AUDIT)
                    .attributeValue(mapper.writeValueAsString(ThreadLocalAuditContext.getContext()))
                    .build());
        }

        return outboxEventAttributes;
    }
}
