# Outbox Library 

[[_TOC_]]

## Overview
Outbox Library helps CMDS Microservices to have a reliable mechanism to deliver message without loosing any events information. 

In the real time event publishing design, there are 2 major components Domain Service and Outbox Event Process is participating in 2 different sets of transactions called primary and secondary. 

The Primary transaction is around the domain layer and synchronous event process whereas the secondary transactions are participating in asynchronous outbox event publishing operation.

**Design Link:** https://confluence.britishcouncil.org/display/IMPS/Guaranteed+Message+Delivery%3A+Outbox+Design

## Pre-requisites
- Mx should use BaseEvent/BaseHeader (anything that exetnds BaseHeader) for consuming and publishing 
- Mx should use common IApplicationService

## Implementation Guidelines

### Microservice Changes

#### Changes to pom.xml

Add below dependency to `pom.xml` and replace `REPLACE_LATEST_VERSION_FROM_CHANGELOG` to the latest version as per the changelog in the below example code

**Example:**

```
<dependency>
  <groupId>com.ielts.cmds.common</groupId>
  <artifactId>cmds-outbox-processor</artifactId>
  <version>REPLACE_LATEST_VERSION_FROM_CHANGELOG</version>
</dependency>
```

#### Enable Outbox in Spring Boot Starter configuration

To Enable Outbox MX need to add `@EnableOutbox` annotation in the MX root starter class and remove `@TransactionalEventListener` from your existing Publisher class. Here is a example show from RD Mx on how to configure outbox processor. By annotating the starter class with `@EnableOutbox` it will initiate all of the necessary configurations and bean definition. Beside enabling outbox MX also need to enable Jpa Repositories and Entity scan

**Example:**

```
package com.ielts.cmds.rd;

import com.ielts.cmds.outbox.configuration.EnableOutbox;

@SpringBootApplication
@ComponentScan("com.ielts.cmds")
@EnableCaching
@EnableJpaRepositories(basePackages = {"com.ielts.cmds.rd.infrastructure.repositories", "com.ielts.cmds.outbox.infra.repository"})
@EntityScan(basePackages = {"com.ielts.cmds.rd.infrastructure.entity", "com.ielts.cmds.outbox.infra.entity"})
@EnableOutbox
public class ResultDeliveryServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResultDeliveryServiceApplication.class, args);
	}

}
```

#### Changes in the application.properties configuration

Every MX need to include outbox.aws.sns.topic-out.arn Properties key to identify their target output topic

```
outbox.aws.sns.topic-out.arn=<microservice topic arn>
```

#### Flyway/SQL changes
Each of the MX needs to implement outbox_event and outbox_event_attribute tables in order to enable outbox processing. We also need to provide delete grant to mx application user for housekeeping

```
DO $$ BEGIN
	CREATE TYPE <SCHEMA_NAME_TO_BE_REPLACED>.publishStateType AS ENUM
    ('PUBLISH_PENDING', 'PUBLISH_SUCCEED', 'PUBLISH_FAILURE');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;


-- Create Table for outbox_event

CREATE TABLE IF NOT EXISTS <SCHEMA_NAME_TO_BE_REPLACED>.outbox_event (
    outbox_event_uuid UUID NOT NULL,
    transaction_uuid UUID NOT NULL,
	event_name VARCHAR(256) NOT NULL,
	event_datetime TIMESTAMPTZ NOT NULL,
	payload TEXT NOt NULL,
	publish_state <SCHEMA_NAME_TO_BE_REPLACED>.publishStateType NOT NULL,
	retry_count INTEGER NOT NULL,
	created_datetime TIMESTAMPTZ NOT NULL,
	updated_datetime TIMESTAMPTZ NOT NULL,
    concurrency_version INTEGER NOT NULL,
    CONSTRAINT pk_outbox_event PRIMARY KEY (outbox_event_uuid)
);


-- Create Table for outbox_event_attribute

CREATE TABLE IF NOT EXISTS <SCHEMA_NAME_TO_BE_REPLACED>.outbox_event_attribute (
    outbox_event_attribute_uuid UUID NOT NULL,
    outbox_event_uuid UUID NOT NULL,
	attribute_key VARCHAR(256) NOT NULL,
	attribute_value TEXT,
	updated_datetime TIMESTAMPTZ NOT NULL,
    CONSTRAINT pk_outbox_event_attribute PRIMARY KEY (outbox_event_attribute_uuid),
	CONSTRAINT fk_01_outbox_event_attribute FOREIGN KEY (outbox_event_uuid) References <SCHEMA_NAME_TO_BE_REPLACED>.outbox_event(outbox_event_uuid),
	CONSTRAINT uk_01_outbox_event_attribute UNIQUE (outbox_event_uuid, attribute_key)
);

GRANT DELETE 
ON  <SCHEMA_NAME_TO_BE_REPLACED>.outbox_event, <SCHEMA_NAME_TO_BE_REPLACED>.outbox_event_attribute
TO  <MX_APPLICATION_USER>;

-- Create index on foreign key column 

CREATE INDEX IF NOT EXISTS idx_01_outbox_event_attribute_outbox_event_uuid 
ON <SCHEMA_NAME_TO_BE_REPLACED>.outbox_event_attribute(outbox_event_uuid);

-- Create index on columns which are commonly used in select statements

CREATE INDEX IF NOT EXISTS idx_01_outbox_event_publish_state 
ON <SCHEMA_NAME_TO_BE_REPLACED>.outbox_event (publish_state);

CREATE INDEX IF NOT EXISTS idx_02_outbox_event_updated_datetime 
ON <SCHEMA_NAME_TO_BE_REPLACED>.outbox_event (updated_datetime);

```
### Infrastructure Changes

#### MX Subscription

Each of the mx will subscribe to this outbox topic (ielts-cmds-\<ENV\>-sns-outbox-topic-out) to receive scheduled event for replay/housekeeping support with no subscription filter policy.

### Optional Configuration

#### Implementing MX specific EventAttributeExtractor

If a MX wants to to put some of the event attributes(e.g. even name, partner code) into SNS attributes during  publishing then the that MX should  provide their own implementation of EventAttributeExtractor where logic can be implemented to extracts the attributes from the events.

Here is an example implementation used in RD microservice. This class should implement `EventAttributeExtractor` class and managed as a spring bean. Here it is annotated with `@Component`. 

**Example:**

```
@Component
public class RDEventAttributeExtractor implements EventAttributeExtractor {

    @Override
    public List<OutboxEventAttribute> apply(final BaseEvent<? extends BaseHeader> event) {
        List<OutboxEventAttribute> eventAttributes = new ArrayList<>();

        eventAttributes.add(OutboxEventAttribute.builder()
                .attributeKey(RDConstants.GenericConstants.EVENT_NAME)
                .attributeValue(event.getEventHeader().getEventName())
                .build());

        if (StringUtils.isNotBlank(event.getEventHeader().getPartnerCode())) {
            eventAttributes.add(OutboxEventAttribute.builder()
                    .attributeKey(RDConstants.GenericConstants.PARTNER_CODE)
                    .attributeValue(event.getEventHeader().getPartnerCode())
                    .build());
        }

        return eventAttributes;
}
```

#### Implementing MX specific EventTransformer

Depending on the MX need basic, EventTransformer can be implemented by the MX to provide a more customize serialize json payload. This payload will be published to SNS.

**Example:**

```
@Component
@RequiredArgsConstructor
public class CustomEventTransformer implements EventTransformer {

    private final ObjectMapper objectMapper;

    @Override
    public String apply(final BaseEvent<BaseHeader> event) {
		// Custom serialization code will go here
        return objectMapper.writeValueAsString(event);
    }

}
```

#### Exclude Event from Outbox Persistence

Also based on cases basis MX can exclude event persisting into outbox table and can be published directly into the SNS.

Please add properties in below format in mx properties file if you want
to exclude event from outbox persistence
```json
outbox.ignore.<<eventName>>=true/false
```
**Note:** eventName is case-sensitive

**Example:**
```json
outbox.ignore.BookingCreated=true
```
In this example **BookingCreated** event will not be persisted in outbox table

#### Disable Outbox and use Basic Event Processor

Outbox process can be disabled and MX can use basic event publisher by adding `@EnableBasicEventPublisher`

```
package com.ielts.cmds.rd;

import com.ielts.cmds.outbox.configuration.EnableBasicEventPublisher;

@SpringBootApplication
@ComponentScan("com.ielts.cmds")
@EnableCaching
@EnableJpaRepositories(basePackages = {"com.ielts.cmds.rd.infrastructure.repositories"})
@EntityScan(basePackages = {"com.ielts.cmds.rd.infrastructure.entity"})
@EnableBasicEventPublisher
public class ResultDeliveryServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResultDeliveryServiceApplication.class, args);
	}

}
```

#### Change in application.properties

##### Feature Flags

By default, outbox will have all features enabled(configured in library's property file - outbox-application.properties)
1. outbox.replay.feature.active=true
2. outbox.housekeeping.feature.active=true

If a Microservice wants to override any of these value, they can do so, by providing the value as false to all/any features in SSM parameter store

##### Feature Configuration

By default, outbox will work with following configuration parameters (configured in library's property file - outbox-application.properties)
1. outbox.housekeeping.time-limit-in-minutes=2880
2. outbox.housekeeping.threshold.time-limit-in-minutes=1440
3. outbox.housekeeping.event-limit=500
4. outbox.replay.threshold.retry-count=3
5. outbox.replay.time-limit-in-seconds=1800
6. outbox.replay.page-size=1000

If a Microservice wants to override any of these value, they can do so, by providing their custom value to all/any of the above properties in SSM parameter store.

##### Parameters

| Parameter Name | Allowed Values | Default Value | Description |
| ---            | ---            | ---           | ---         |
| outbox.housekeeping.time-limit-in-minutes | Any integer value         | 2880        | Housekeeping will delete only the events for which the updated_datetime is before (current time - time limit parameter) if time limit > threshold        |
| outbox.housekeeping.threshold.time-limit-in-minutes         | Any integer value | 1440 | Housekeeping will delete only the events for which the updated_datetime is before (current time - threshold parameter) if time limit <= threshold |
| outbox.housekeeping.event-limit         | Any integer value | 1440 | Maximum number of events which will be deleted for each housekeeping message |
| outbox.replay.threshold.retry-count        | Any integer value | 1440 | Replay will trigger only those events for which retry count is lesser than this threshold parameter |
| outbox.replay.time-limit-in-seconds       | Any integer value | 1440 | Replay will trigger only the events for which the updated_datetime is after (current time - time limit parameter)  |
| outbox.replay.page-size        | Any integer value | 1440 | Maximum number of events which will be replayed for each replay message |
| outbox.replay.feature.active         | true, false | true | Feature flag for Outbox Replay which decides whether replay can be done |
| outbox.housekeeping.feature.active         | true, false | true | Feature flag for Outbox Housekeeping which decides whether housekeeping can be done |

## Change Log

### 1.0.2 (Prevent x-Access Token to be printed in loggers(Update CMDSEventHeader version to 0.0.21))

### 1.0.0 (Upgrade to major version)

### 0.0.16 
- Upgrade common-connection-factory dependency version

### 0.0.15 (Dedicated SNS Topic Publish Update - [IMOD-55106](https://btsservice.atlassian.net/browse/IMOD-55106))
- Publish the event to the explicit V1 topic if the event name does not have version suffix in its name

### 0.0.14 (Deletion of Events once the publishing of event is successful)
- Once the publish of event is successful in secondary transaction, that event will not be persisted in the DB instead it will be deleted.
- Improvement of save method in EventPersistence class - Instead of checking the isOutboxIgnore everywhere where save method is called, we have moved that condition check to save method of EventPersistence class.

### 0.0.13 (Logging Enhancements)
- Changed log level of logs in OutboxConfiguration class
- Bootstrapped all topics from AWS
- Validating and publishing to Business topic along with outbound topic

### 0.0.11 (Baseline Release Version)


### 0.0.10-SNAPSHOT
- Outbox ignore(IMOD-42366)
- Optimized packaging structure 
- Improved logging level 
- Removed unwanted(duplicate coded) classes
- Support **String.Array** SQS message attribute for header and audit fields

### 0.0.9-SNAPSHOT
- Removed @EventBody annotation filter from DomainEventListenerV2 class (IMOD-44814)

### 0.0.8-SNAPSHOT(Bug Fix)
- Event Serialization - Header and Audit is not populating in correct format for V2 publish(IMOD-43410)

### 0.0.7-SNAPSHOT 
- Reduce Info level log statements

### 0.0.6-SNAPSHOT (Feature Enhancement)
- Support to publish V2 event under EventBody Serialization

### 0.0.5-SNAPSHOT (Feature Enhancement)
- Outbox Feature Flag Support

### 0.0.4-SNAPSHOT (Minor Feature)
- Outbox Housekeeping Support

### 0.0.3-SNAPSHOT (Bug Fix)
- Fixed bug identified in outbox persistence in case of UiHeader, while SM/RO was integrating with Outbox Library (0.0.2-SNAPSHOT)

### 0.0.2-SNAPSHOT (Bug Fix)
- Fixed bug which was identied in one of the JPA Query, while IDS was integrating with Outbox Library (0.0.1-SNAPSHOT)

### 0.0.1-SNAPSHOT (Major Feature)
- Base Implementation of Outbox Library	
