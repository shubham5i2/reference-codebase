package com.ielts.cmds.cre.constants;

public class ApacheReportEngineConstants {

    public static final String CEFR_LEVEL = "cefrLevel";
    public static final String TRF = "TRF";
    public static final String ETRF = "ETRF";
    public static final String EOR = "EOR";
    public static final String BELOW = "Below";
    public static final String TT_PHOTO_JPEG = "ttPhoto.JPEG";
    public static final String TT_PHOTO = "ttPhoto";
    public static final String FIELD = "FIELD";
    public static final String MULTILINE = "MULTILINE";
    public static final String SINGLELINE = "SINGLELINE";
    public static final String PDF_EXTENSION = ".pdf";
    public static final String JSON_EXTENSION = ".json";
    public static final String TEMP_FOLDER_EXTENSION = "/tmp/";
    public static final String FIELDS = "FIELDS";
    public static final String PRODUCT_MODULE = "productModule";
    public static final String GENERAL_TRAINING = "GENERAL TRAINING";
    public static final String ACADEMIC = "ACADEMIC";
    public static final String RESOURCES_LOCATION = "src/main/resources/";

    private ApacheReportEngineConstants() {
    }

    public static final class TtfFileNames {

        public static final String OPEN_SANS_REG_TTF = "OpenSans-Regular.ttf";
        public static final String OPEN_SANS_BOLD_TTF = "OpenSans-Bold.ttf";
        public static final String OPEN_SANS_ITALIC_TTF = "OpenSans-Italic.ttf";
        public static final String OPEN_SANS_BOLD_ITALIC_TTF = "OpenSans-BoldItalic.ttf";
        public static final String OPEN_SANS_MEDIUM_ITALIC_TTF = "OpenSans-MediumItalic.ttf";
    }

    public static final class fontNames {

        public static final String OPEN_SANS_REG = "OPEN_SANS";
        public static final String OPEN_SANS_BOLD = "OPEN_SANS_BOLD";
        public static final String OPEN_SANS_ITALIC = "OPEN_SANS_ITALIC";
        public static final String OPEN_SANS_BOLD_ITALIC = "OPEN_SANS_BOLD_ITALIC";
        public static final String OPEN_SANS_MEDIUM_ITALIC = "OPEN_SANS_MEDIUM_ITALIC";

    }
}
