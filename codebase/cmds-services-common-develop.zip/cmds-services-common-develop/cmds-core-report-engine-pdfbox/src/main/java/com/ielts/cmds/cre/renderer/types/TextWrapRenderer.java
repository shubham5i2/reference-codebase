package com.ielts.cmds.cre.renderer.types;

import com.ielts.cmds.cre.exception.ReportGenerationException;
import com.ielts.cmds.cre.model.*;
import com.ielts.cmds.cre.model.enums.TypeEnum;
import com.ielts.cmds.cre.renderer.RendererFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDFont;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;


@Slf4j
public class TextWrapRenderer implements CMDSRenderer {

    @Override
    public void render(Field field, PDPageContentStream contentStream, PDDocument document, GeneratorData data, FontResolver fontResolver) throws IOException, InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        List<String> wrappedText = new ArrayList<>();
        String value = null;
        try {
            value = BeanUtils.getProperty(data, field.getFieldPath());
            if(Objects.nonNull(value)) {
                wrappedText = wrapText(field, value, fontResolver);
            }
        } catch (InvocationTargetException | IllegalAccessException | NoSuchMethodException ex) {
            log.info("Exception occurred while retrieving value : ", ex);
        }
        //PDType1Font.HELVETICA
        if (!StringUtils.isEmpty(value)) {
            populateFieldData(field, contentStream, wrappedText,document, fontResolver);
        } else if (StringUtils.isEmpty(value) && field.isMandatory()) {
            log.error("Field is mandatory : {}", field.getName());
            throw new ReportGenerationException("Field cannot be blank");
        }
    }


    void populateFieldData(Field field, PDPageContentStream contentStream, List<String> wrappedText, PDDocument document, FontResolver fontResolver) throws IOException, InvocationTargetException, IllegalAccessException, NoSuchMethodException
    {
        float startX = field.getXPos();
        float startY = field.getYPos();

        int accommodatedLengthOfText = 0;
        int actualLengthOfText = 0;


        for (String line : wrappedText) {
            //to restrict printing lines out of the box
            if(field.getHeight() > startY - field.getYPos()) {

                Field fieldForEachLine = Field.builder()
                        .name(field.getName())
                        .xPos(startX)
                        .yPos(startY)
                        .height((float) 0)
                        .width((float) 0)
                        .mandatory(true)
                        .type(TypeEnum.TEXT)
                        .font(field.getFont())
                        .fontSize(field.getFontSize())
                        .fieldPath("textLine")
                        .build();

            GeneratorData generatorData = TempTextData.builder()
                    .textLine(line)
                    .build();

                new RendererFactory().getRenderer(fieldForEachLine).render(fieldForEachLine, contentStream, document, generatorData, fontResolver);

                startY += field.getYPosIncrement();
                accommodatedLengthOfText += line.length();
            }
            actualLengthOfText += line.length();
        }
        log.info("Total length of the text is {}. Length of string accommodated in the text box is {}", actualLengthOfText,accommodatedLengthOfText);
    }


    public List<String> wrapText(Field field, String comment, FontResolver fontResolver) throws IOException {

        List<String> wrappedText = new ArrayList<>();
        //get page of size equal to textBox
        PDPage page = getTextBoxSizedPage(field);

        //get list of Strings after removing \n
        List<String> commentWithNewLine = getCommentWithNewLines(comment);
        for(String line: commentWithNewLine)
        {
            line = removeUnsupportedCharacters(line);
            wrappedText.addAll(getWrappedText(line,field,page, fontResolver));
        }
        return wrappedText;
    }

    protected List<String> getCommentWithNewLines(String comment) {

        return Arrays.asList(comment.replaceAll("\r","\n").split("\n"));
    }

    private PDPage getTextBoxSizedPage(Field field) {
        PDRectangle rec = new PDRectangle(field.getWidth(), field.getHeight());
        return new PDPage(rec);
    }

    private List<String> getWrappedText(String comment, Field field, PDPage page, FontResolver fontResolver) throws IOException {

        PDFont pdfFont = fontResolver.getFont(field.getFont());
        float fontSize = field.getFontSize();

        PDRectangle mediaBox = page.getMediaBox();
        float width = mediaBox.getWidth();

        List<String> lines = new ArrayList<>();
        int lastSpace = -1;
        while (Objects.nonNull(comment) && comment.length() > 0) {
            int spaceIndex = comment.indexOf(' ', lastSpace + 1);
            if (spaceIndex < 0)
                spaceIndex = comment.length();
            String subString = comment.substring(0, spaceIndex);
            float size = fontSize * pdfFont.getStringWidth(subString) / 1000;
            if (size > width) {
                if (lastSpace < 0)
                    lastSpace = spaceIndex;
                subString = comment.substring(0, lastSpace);
                lines.add(subString);
                comment = comment.substring(lastSpace).trim();
                lastSpace = -1;
            } else if (spaceIndex == comment.length()) {
                lines.add(comment);
                comment = "";
            } else {
                lastSpace = spaceIndex;
            }
        }
        return lines;
    }

}
