package com.ielts.cmds.cre.model;

public interface GeneratorData {
}
