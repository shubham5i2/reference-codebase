package com.ielts.cmds.cre.generator.validator;

import com.ielts.cmds.cre.exception.ReportGenerationException;
import com.ielts.cmds.cre.model.GeneratorData;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;

import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;

import static com.ielts.cmds.cre.constants.ApacheReportEngineConstants.*;

@Slf4j
@NoArgsConstructor
public class MultiLineValidator {
    public String checkIfMultilineTRFNeeded(GeneratorData data) throws InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        String key = BeanUtils.getProperty(data, CEFR_LEVEL);
        if (!StringUtils.isEmpty(key)) {
            String[] strArr = key.split(" ");
            if (strArr.length == 2 && Arrays.stream(strArr).anyMatch(e -> e.contains(BELOW))) {
                BeanUtils.setProperty(data, "below", BELOW);
                BeanUtils.setProperty(data, CEFR_LEVEL, strArr[1]);
                return MULTILINE;
            } else {
                return SINGLELINE;
            }
        } else {
            throw new ReportGenerationException("CEFR Level cannot be blank");
        }
    }
}
