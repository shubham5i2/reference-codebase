package com.ielts.cmds.cre.renderer.types;

import com.ielts.cmds.cre.exception.ReportGenerationException;
import com.ielts.cmds.cre.model.Field;
import com.ielts.cmds.cre.model.FontResolver;
import com.ielts.cmds.cre.model.GeneratorData;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.graphics.image.JPEGFactory;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Base64;
import java.util.Objects;

@Slf4j
public class ImageRenderer implements CMDSRenderer {

    private static BufferedImage cropImageSquare(BufferedImage originalImage) {

        int height = originalImage.getHeight();
        int width = originalImage.getWidth();
        int targetImageSize = (Math.min(height, width));
        // Coordinates of the image's middle
        int xc = (width - targetImageSize) / 2;
        int yc = (height - targetImageSize) / 2;

        // Crop
        return originalImage.getSubimage(xc, yc, targetImageSize, targetImageSize);

    }

    @Override
    public void render(Field field, PDPageContentStream contentStream, PDDocument pdDocument, GeneratorData data, FontResolver fontResolver) throws IOException {
        String text = null;
        try {
            text = BeanUtils.getProperty(data, field.getFieldPath());
        } catch (InvocationTargetException | IllegalAccessException | NoSuchMethodException ex) {
            log.info("Exception occurred while retrieving value : ", ex);
        }
        if (!StringUtils.isEmpty(text)) {
            drawImage(field, contentStream, pdDocument, text);
        } else if (StringUtils.isEmpty(text) && field.isMandatory()) {
            log.error("Field is mandatory : {}", field.getName());
            throw new ReportGenerationException("Field cannot be blank");
        }
    }

    void drawImage(Field field, PDPageContentStream contentStream, PDDocument pdDocument, String text) throws IOException {
        PDImageXObject pdImageXObject = JPEGFactory.createFromImage(pdDocument, fixImageSize(text));
        if (checkFieldHeightWidth(field)) {
            contentStream.drawImage(pdImageXObject, field.getXPos(), PDRectangle.A4.getHeight() - field.getYPos(), field.getWidth(), field.getHeight());
        } else {
            throw new ReportGenerationException("Height or Width cannot be null or 0");
        }
    }

    boolean checkFieldHeightWidth(Field field) {
        return Objects.nonNull(field.getWidth()) && Objects.nonNull(field.getHeight()) && !(field.getWidth() == 0 && field.getHeight() == 0);
    }

    BufferedImage fixImageSize(String encodedImageString) throws IOException {
        byte[] byteImage = Base64.getDecoder().decode(encodedImageString);
        return cropImageSquare(ImageIO.read(new ByteArrayInputStream(byteImage)));
    }
}
