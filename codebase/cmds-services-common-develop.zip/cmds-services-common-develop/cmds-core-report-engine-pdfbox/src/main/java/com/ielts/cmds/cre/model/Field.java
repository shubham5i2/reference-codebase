package com.ielts.cmds.cre.model;

import com.ielts.cmds.cre.model.enums.TypeEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Field {

    private String name;

    private Float xPos;

    private Float yPos;

    private Float width;

    private Float height;

    private boolean mandatory;

    private Float yPosIncrement;

    private TypeEnum type;

    private String font;

    private Float fontSize;

    private String fieldPath;


}
