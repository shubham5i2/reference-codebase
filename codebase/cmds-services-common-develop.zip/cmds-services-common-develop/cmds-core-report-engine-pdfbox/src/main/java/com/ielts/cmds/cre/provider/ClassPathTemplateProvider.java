package com.ielts.cmds.cre.provider;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

@Slf4j
public class ClassPathTemplateProvider implements TemplateProvider {

    @Override
    public byte[] getTemplate(String templateName) throws IOException {

        final ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();

        log.debug("Looking for [{}] file in classpath", templateName);
        final InputStream inputStream = contextClassLoader.getResourceAsStream(templateName);

        Objects.requireNonNull(inputStream, String.format("Can not find [%s] file in classpath", templateName));

        final byte[] bytes = IOUtils.toByteArray(inputStream);
        inputStream.close();

        log.debug("Template file byte size {}", bytes.length);

        return bytes;
    }
}

