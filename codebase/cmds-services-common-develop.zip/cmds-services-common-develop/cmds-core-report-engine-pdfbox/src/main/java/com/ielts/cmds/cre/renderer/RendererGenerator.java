package com.ielts.cmds.cre.renderer;

import com.ielts.cmds.cre.model.Field;
import com.ielts.cmds.cre.renderer.types.CMDSRenderer;

public interface RendererGenerator {

    CMDSRenderer getRenderer(Field field);
}
