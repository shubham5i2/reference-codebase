package com.ielts.cmds.cre.renderer.types;

import com.ielts.cmds.cre.exception.ReportGenerationException;
import com.ielts.cmds.cre.model.Field;
import com.ielts.cmds.cre.model.FontResolver;
import com.ielts.cmds.cre.model.GeneratorData;
import com.ielts.cmds.cre.model.TempTextData;
import com.ielts.cmds.cre.model.enums.TypeEnum;
import com.ielts.cmds.cre.renderer.RendererFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDFont;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

@Slf4j
public class CentreAlignTextRenderer implements CMDSRenderer {

    @Override
    public void render(Field field, PDPageContentStream contentStream, PDDocument document, GeneratorData data, FontResolver fontResolver) throws IOException, InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        String centreAlignText = null;
        float xPos = 0;
        try {
            centreAlignText = BeanUtils.getProperty(data, field.getFieldPath());
            PDPage page = getTextBoxSizedPage(field);
            xPos = getXPosForCentreAlignment(field, page, centreAlignText, fontResolver);
        } catch (InvocationTargetException | IllegalAccessException | NoSuchMethodException ex) {
            log.error("Exception occurred while retrieving value : ", ex);
        }

        if (!StringUtils.isEmpty(centreAlignText)) {
            populateFieldData(field, contentStream, xPos, document, data, fontResolver);
        } else if (StringUtils.isEmpty(centreAlignText) && field.isMandatory()) {
            log.error("Field is mandatory : {}", field.getName());
            throw new ReportGenerationException("Field cannot be blank");
        }
    }


    void populateFieldData(Field field, PDPageContentStream contentStream, float xPos, PDDocument document, GeneratorData data, FontResolver fontResolver) throws IOException, InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        Field fieldForEachLine = Field.builder()
                .name(field.getName())
                .xPos(xPos)
                .yPos(field.getYPos())
                .height((float) 0)
                .width((float) 0)
                .mandatory(true)
                .type(TypeEnum.TEXT)
                .font(field.getFont())
                .fontSize(field.getFontSize())
                .fieldPath("textLine")
                .build();

        GeneratorData generatorData = TempTextData.builder()
                .textLine(BeanUtils.getProperty(data, field.getFieldPath()))
                .build();

        new RendererFactory().getRenderer(fieldForEachLine).render(fieldForEachLine, contentStream, document, generatorData, fontResolver);
    }


    private PDPage getTextBoxSizedPage(Field field) {
        PDRectangle rec = new PDRectangle(field.getWidth(), field.getHeight());

        return new PDPage(rec);
    }

    private float getXPosForCentreAlignment(Field field, PDPage page, String fieldData, FontResolver fontResolver) throws IOException {

        PDFont pdfFont = fontResolver.getFont(field.getFont());
        float fontSize = field.getFontSize();

        PDRectangle mediaBox = page.getMediaBox();
        float width = mediaBox.getWidth();
        float size = fontSize * pdfFont.getStringWidth(fieldData) / 1000;

        return field.getXPos() + (width - size) / 2;

    }

}

