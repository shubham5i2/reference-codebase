package com.ielts.cmds.cre;

import com.ielts.cmds.cre.generator.PDFGenerator;

public interface ApacheReportEngine {

    PDFGenerator getPDFType();
}
