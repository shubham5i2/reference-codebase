package com.ielts.cmds.cre.renderer.types;

import com.ielts.cmds.cre.model.Field;
import com.ielts.cmds.cre.model.FontResolver;
import com.ielts.cmds.cre.model.GeneratorData;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.encoding.WinAnsiEncoding;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public interface CMDSRenderer {
    void render(Field field, PDPageContentStream contentStream, PDDocument pdDocument, GeneratorData data, FontResolver fontResolver) throws IOException, InvocationTargetException, IllegalAccessException, NoSuchMethodException;

    default String removeUnsupportedCharacters(String value) {

        StringBuilder finalValue = new StringBuilder();
        for (int i = 0; i < value.length(); i++) {
            if (WinAnsiEncoding.INSTANCE.contains(value.charAt(i))) {
                finalValue.append(value.charAt(i));
            }
        }
        return finalValue.toString();
    }
}
