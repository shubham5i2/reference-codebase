package com.ielts.cmds.cre.builder;

import com.google.gson.Gson;
import com.ielts.cmds.cre.exception.ReportGenerationException;
import com.ielts.cmds.cre.model.Field;
import com.ielts.cmds.cre.model.Fields;
import com.ielts.cmds.cre.model.FontResolver;
import com.ielts.cmds.cre.model.GeneratorData;
import com.ielts.cmds.cre.provider.ClassPathTemplateProvider;
import com.ielts.cmds.cre.provider.TemplateProvider;
import com.ielts.cmds.cre.renderer.RendererFactory;
import com.ielts.cmds.cre.renderer.RendererGenerator;
import com.ielts.cmds.cre.renderer.types.CMDSRenderer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPageContentStream;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import static com.ielts.cmds.cre.constants.ApacheReportEngineConstants.PDF_EXTENSION;
import static com.ielts.cmds.cre.constants.ApacheReportEngineConstants.TEMP_FOLDER_EXTENSION;

@Slf4j
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CommonPDFBuilder implements PDFBuilder {

    @Builder.Default
    TemplateProvider templateProvider = new ClassPathTemplateProvider();

    GeneratorData data;

    String templateName;

    String fieldJsonName;

    @Builder.Default
    String tempPDFName = TEMP_FOLDER_EXTENSION + RandomStringUtils.randomAlphanumeric(15) +
            System.currentTimeMillis() + PDF_EXTENSION;

    @Override
    public byte[] buildPDF() throws IOException {
        byte[] template = templateProvider.getTemplate(templateName);
        Gson gson = new Gson();
        Fields fields = gson.fromJson(new InputStreamReader(new ByteArrayInputStream(templateProvider.getTemplate(fieldJsonName))), Fields.class);

        File file = generateAndSavePDF(template, data, fields.getFieldsList());
        return fileToByteArray(file);
    }

    byte[] fileToByteArray(File file) throws IOException {
        try (InputStream inputStream = new FileInputStream(file)) {
            if (file.exists()) {
                byte[] arr = new byte[(int) file.length()];
                int bytesRead = inputStream.read(arr);
                log.info("Bytes Read : {} ", bytesRead);
                return arr;
            } else {
                throw new ReportGenerationException("File not found");
            }
        } catch (IOException ioException) {
            log.error("Exception occurred while processing : ", ioException);
            throw new ReportGenerationException("PDF Process Aborted");
        } finally {
            boolean fileDeleted = Files.deleteIfExists(Paths.get(file.getAbsolutePath()));
            if (fileDeleted) {
                log.info("File successfully deleted");
            } else {
                log.warn("Error in deleting file");
            }
        }
    }

    File generateAndSavePDF(byte[] template, GeneratorData data, List<Field> fieldsList) throws IOException {
        File file = createTemporaryPDFDocument(template);
        PDDocument document = getPdDocument(file);
        FontResolver fontResolver = new FontResolver(document);
        PDPageContentStream contentStream = getPdPageContentStream(document);
        fieldsList.forEach(field -> {
            try {
                renderPDFFields(contentStream, field, document, data, fontResolver);
            } catch (IOException | InvocationTargetException | IllegalAccessException | NoSuchMethodException exception) {
                log.error("Exception Occurred due to : ", exception);
                throw new ReportGenerationException(exception);
            }
        });
        contentStream.close();
        document.save(tempPDFName);
        document.close();
        return file;
    }

    PDPageContentStream getPdPageContentStream(PDDocument document) throws IOException {
        return new PDPageContentStream(document, document.getPage(0), PDPageContentStream.AppendMode.APPEND, true, true);
    }

    PDDocument getPdDocument(File file) throws IOException {
        return PDDocument.load(file);
    }

    void renderPDFFields(PDPageContentStream contentStream, Field field, PDDocument document, GeneratorData data, FontResolver fontResolver) throws IOException, InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        RendererGenerator rendererGenerator = new RendererFactory();
        CMDSRenderer cmdsRenderer = rendererGenerator.getRenderer(field);
        cmdsRenderer.render(field, contentStream, document, data, fontResolver);
    }


    File createTemporaryPDFDocument(byte[] template) throws IOException {
        File file = new File(tempPDFName);
        FileUtils.writeByteArrayToFile(file, template);
        return file;
    }
}
