package com.ielts.cmds.cre.model;

import static com.ielts.cmds.cre.constants.ApacheReportEngineConstants.TtfFileNames.OPEN_SANS_BOLD_ITALIC_TTF;
import static com.ielts.cmds.cre.constants.ApacheReportEngineConstants.TtfFileNames.OPEN_SANS_BOLD_TTF;
import static com.ielts.cmds.cre.constants.ApacheReportEngineConstants.TtfFileNames.OPEN_SANS_ITALIC_TTF;
import static com.ielts.cmds.cre.constants.ApacheReportEngineConstants.TtfFileNames.OPEN_SANS_MEDIUM_ITALIC_TTF;
import static com.ielts.cmds.cre.constants.ApacheReportEngineConstants.TtfFileNames.OPEN_SANS_REG_TTF;
import static com.ielts.cmds.cre.constants.ApacheReportEngineConstants.fontNames.OPEN_SANS_BOLD;
import static com.ielts.cmds.cre.constants.ApacheReportEngineConstants.fontNames.OPEN_SANS_BOLD_ITALIC;
import static com.ielts.cmds.cre.constants.ApacheReportEngineConstants.fontNames.OPEN_SANS_ITALIC;
import static com.ielts.cmds.cre.constants.ApacheReportEngineConstants.fontNames.OPEN_SANS_MEDIUM_ITALIC;
import static com.ielts.cmds.cre.constants.ApacheReportEngineConstants.fontNames.OPEN_SANS_REG;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

import com.ielts.cmds.cre.exception.ReportGenerationException;

import lombok.Generated;

@Generated
public class FontResolver {

    private final Map<String, PDFont> fontMap;

    public FontResolver(PDDocument document) {
        fontMap = new HashMap<>();
        fontMap.put("TIMES_ROMAN", PDType1Font.TIMES_ROMAN);
        fontMap.put("TIMES_BOLD", PDType1Font.TIMES_BOLD);
        fontMap.put("TIMES_ITALIC", PDType1Font.TIMES_ITALIC);
        fontMap.put("TIMES_BOLD_ITALIC", PDType1Font.TIMES_BOLD_ITALIC);
        fontMap.put("HELVETICA", PDType1Font.HELVETICA);
        fontMap.put("HELVETICA_BOLD", PDType1Font.HELVETICA_BOLD);
        fontMap.put("HELVETICA_OBLIQUE", PDType1Font.HELVETICA_OBLIQUE);
        fontMap.put("HELVETICA_BOLD_OBLIQUE", PDType1Font.HELVETICA_BOLD_OBLIQUE);
        fontMap.put("COURIER", PDType1Font.COURIER);
        fontMap.put("COURIER_BOLD", PDType1Font.COURIER_BOLD);
        fontMap.put("COURIER_OBLIQUE", PDType1Font.COURIER_OBLIQUE);
        fontMap.put("COURIER_BOLD_OBLIQUE", PDType1Font.COURIER_BOLD_OBLIQUE);
        fontMap.put("SYMBOL", PDType1Font.SYMBOL);
        fontMap.put("ZAPF_DINGBATS", PDType1Font.ZAPF_DINGBATS);
        loadFontsFromFiles(document);
    }

    public PDFont getFont(String font) {
        if (fontMap.containsKey(font)) {
            return fontMap.get(font);
        } else {
            throw new ReportGenerationException("Font Does Not Exist");
        }

    }

    public void loadFontsFromFiles(PDDocument document) {
        try{
            final ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();

            PDFont openSansRegular = PDType0Font.load(document, contextClassLoader.getResourceAsStream(OPEN_SANS_REG_TTF));
            PDFont openSansBold = PDType0Font.load(document, contextClassLoader.getResourceAsStream(OPEN_SANS_BOLD_TTF));
            PDFont openSansItalic = PDType0Font.load(document, contextClassLoader.getResourceAsStream(OPEN_SANS_ITALIC_TTF));
            PDFont openSansBoldItalic = PDType0Font.load(document, contextClassLoader.getResourceAsStream(OPEN_SANS_BOLD_ITALIC_TTF));
            PDFont openSansMedium = PDType0Font.load(document, contextClassLoader.getResourceAsStream(OPEN_SANS_MEDIUM_ITALIC_TTF));

            fontMap.put(OPEN_SANS_REG, openSansRegular);
            fontMap.put(OPEN_SANS_BOLD,openSansBold);
            fontMap.put(OPEN_SANS_ITALIC,openSansItalic);
            fontMap.put(OPEN_SANS_BOLD_ITALIC,openSansBoldItalic);
            fontMap.put(OPEN_SANS_MEDIUM_ITALIC, openSansMedium);

        }
        catch (IOException e) {
            throw new ReportGenerationException("Unable to load font due to " + e);
        }
    }

}
