package com.ielts.cmds.cre.generator;

import com.ielts.cmds.cre.model.GeneratorData;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public interface PDFGenerator {
    byte[] generatePDF(GeneratorData data) throws IOException, InvocationTargetException, IllegalAccessException, NoSuchMethodException;
}
