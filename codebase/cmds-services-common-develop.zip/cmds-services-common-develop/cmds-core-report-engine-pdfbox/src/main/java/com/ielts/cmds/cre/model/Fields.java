package com.ielts.cmds.cre.model;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class Fields {

    private List<Field> fieldsList;

}

