package com.ielts.cmds.cre.exception;

public class ReportGenerationException extends RuntimeException {

    public ReportGenerationException(String message) {
        super(message);
    }

    public ReportGenerationException(Throwable cause) {
        super(cause);
    }

}
