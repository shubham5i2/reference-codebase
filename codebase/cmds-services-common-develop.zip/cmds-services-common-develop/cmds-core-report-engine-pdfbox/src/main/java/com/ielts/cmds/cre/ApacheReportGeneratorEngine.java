package com.ielts.cmds.cre;

import com.ielts.cmds.cre.generator.PDFGenerator;
import com.ielts.cmds.cre.generator.trf.ReportGenerator;
import com.ielts.cmds.cre.generator.validator.MultiLineValidator;

public class ApacheReportGeneratorEngine implements ApacheReportEngine {

    @Override
    public PDFGenerator getPDFType() {

            return ReportGenerator.builder()
                    .multiLineValidator(new MultiLineValidator())
                    .build();

    }
}
