package com.ielts.cmds.cre.model;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class TempTextData implements GeneratorData{

    private String textLine;

}
