package com.ielts.cmds.cre.builder;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public interface PDFBuilder {

    byte[] buildPDF() throws IOException, InvocationTargetException, IllegalAccessException, NoSuchMethodException;

}
