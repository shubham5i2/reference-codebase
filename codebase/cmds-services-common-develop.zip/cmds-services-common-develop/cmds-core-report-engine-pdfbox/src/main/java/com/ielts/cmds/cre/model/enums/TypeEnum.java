package com.ielts.cmds.cre.model.enums;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;

@JsonAdapter(TypeEnum.Adapter.class)
public enum TypeEnum {

    TEXT("TEXT"),
    IMAGE("IMAGE"),
    WRAPTEXT("WRAPTEXT"),
    CENTRETEXT("CENTRETEXT");

    private final String value;

    TypeEnum(String value) {
        this.value = value;
    }

    public static TypeEnum fromValue(String text) {
        for (TypeEnum typeEnum : TypeEnum.values()) {
            if (String.valueOf(typeEnum.value).equals(text)) {
                return typeEnum;
            }
        }
        return null;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static class Adapter extends TypeAdapter<TypeEnum> {
        @Override
        public void write(final JsonWriter jsonWriter, final TypeEnum enumeration)
                throws IOException {
            jsonWriter.value(enumeration.getValue());
        }

        @Override
        public TypeEnum read(final JsonReader jsonReader) throws IOException {
            String value = jsonReader.nextString();
            return TypeEnum.fromValue(String.valueOf(value));
        }
    }

}
