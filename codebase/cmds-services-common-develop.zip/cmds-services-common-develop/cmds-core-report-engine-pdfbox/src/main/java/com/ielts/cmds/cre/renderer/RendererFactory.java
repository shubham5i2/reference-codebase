package com.ielts.cmds.cre.renderer;

import com.ielts.cmds.cre.exception.ReportGenerationException;
import com.ielts.cmds.cre.model.Field;
import com.ielts.cmds.cre.model.enums.TypeEnum;
import com.ielts.cmds.cre.renderer.types.*;

import java.util.HashMap;
import java.util.Objects;

public class RendererFactory implements RendererGenerator {

    static final HashMap<TypeEnum, CMDSRenderer> enumToClassMap = new HashMap<>();

    static{
        enumToClassMap.put(TypeEnum.TEXT,new SimpleTextRenderer());
        enumToClassMap.put(TypeEnum.IMAGE,new ImageRenderer());
        enumToClassMap.put(TypeEnum.WRAPTEXT,new TextWrapRenderer());
        enumToClassMap.put(TypeEnum.CENTRETEXT,new CentreAlignTextRenderer());
    }

    @Override
    public CMDSRenderer getRenderer(Field field) {
        if (Objects.nonNull(field.getType())) {
            return enumToClassMap.get(field.getType());
        }
        throw new ReportGenerationException("Field type for field "+field.getName() +"is null");
    }
}
