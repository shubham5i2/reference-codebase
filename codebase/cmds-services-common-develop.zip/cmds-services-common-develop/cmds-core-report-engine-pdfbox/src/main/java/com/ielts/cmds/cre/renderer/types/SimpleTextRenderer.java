package com.ielts.cmds.cre.renderer.types;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;

import com.ielts.cmds.cre.exception.ReportGenerationException;
import com.ielts.cmds.cre.model.Field;
import com.ielts.cmds.cre.model.FontResolver;
import com.ielts.cmds.cre.model.GeneratorData;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SimpleTextRenderer implements CMDSRenderer {
    @Override
    public void render(Field field, PDPageContentStream contentStream, PDDocument document, GeneratorData data, FontResolver fontResolver) throws IOException {
        String value = null;
        try {
            value = BeanUtils.getProperty(data, field.getFieldPath());

        } catch (InvocationTargetException | IllegalAccessException | NoSuchMethodException ex) {
            log.info("Exception occurred while retrieving value : ", ex);
        }
        //PDType1Font.HELVETICA
        if (!StringUtils.isEmpty(value)) {
            populateFieldData(field, contentStream, value, fontResolver);
        } else if (StringUtils.isEmpty(value) && field.isMandatory()) {
            log.error("Field is mandatory : {}", field.getName());
            throw new ReportGenerationException("Field cannot be blank");
        }
    }


    void populateFieldData(Field field, PDPageContentStream contentStream, String value, FontResolver fontResolver) throws IOException {
        contentStream.beginText();
        contentStream.newLineAtOffset(field.getXPos(), PDRectangle.A4.getHeight() - field.getYPos());
        contentStream.setFont(fontResolver.getFont(field.getFont()), field.getFontSize());
        contentStream.showText(value);
        contentStream.endText();
    }
}
