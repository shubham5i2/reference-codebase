package com.ielts.cmds.cre.generator.trf;

import com.ielts.cmds.cre.builder.CommonPDFBuilder;
import com.ielts.cmds.cre.builder.PDFBuilder;
import com.ielts.cmds.cre.exception.ReportGenerationException;
import com.ielts.cmds.cre.generator.PDFGenerator;
import com.ielts.cmds.cre.generator.validator.MultiLineValidator;
import com.ielts.cmds.cre.model.GeneratorData;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import static com.ielts.cmds.cre.constants.ApacheReportEngineConstants.*;

@Slf4j
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReportGenerator implements PDFGenerator {

    MultiLineValidator multiLineValidator;

    @Override
    public byte[] generatePDF(GeneratorData data) {
        try {
            String templateType = multiLineValidator.checkIfMultilineTRFNeeded(data);
            String templateName = BeanUtils.getProperty(data, "templateName");
            PDFBuilder pdfBuilder = getBuilder(data, templateType,templateName);

            return pdfBuilder.buildPDF();
        } catch (IOException | InvocationTargetException | IllegalAccessException | NoSuchMethodException ex) {
            log.error("Exception Occurred While Generating PDF ", ex);
            throw new ReportGenerationException("PDF could not be generated");
        }
    }

    CommonPDFBuilder getBuilder(GeneratorData data, String templateType, String templateName) {
        return CommonPDFBuilder.builder()
                //ETRF_FIELD_MULTILINE
                .fieldJsonName(buildFileName(templateName, templateType) + JSON_EXTENSION)
                .templateName(templateName+ PDF_EXTENSION)
                .data(data)
                .build();
    }

    private String buildFileName(String... strArray) {
        return String.join("_", strArray);
    }

}
