package com.ielts.cmds.cre.analysis;

import com.ielts.cmds.cre.ApacheReportEngine;
import com.ielts.cmds.cre.ApacheReportGeneratorEngine;
import com.ielts.cmds.cre.generator.PDFGenerator;
import com.ielts.cmds.cre.model.GeneratorData;
import com.ielts.cmds.cre.provider.ClassPathTemplateProvider;
import com.ielts.cmds.cre.provider.TemplateProvider;
import org.apache.pdfbox.io.IOUtils;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.util.Base64;

public class CheckFlow {

    public static void main(String[] args) throws InvocationTargetException, IllegalAccessException, NoSuchMethodException, IOException {
        TemplateProvider templateProvider = new ClassPathTemplateProvider();
        InputStream inputStream = new FileInputStream("src/test/resources/photo6.jpg");
        byte[] photo = IOUtils.toByteArray(inputStream);

        String encodedImage = Base64.getEncoder().encodeToString(photo);

        GeneratorData tempModel = TempModel.builder().name("Pulkit")
                .lastName("Arora")
                .ttPhoto(encodedImage)
                .cefrLevel("BELOW B1")
                .build();

        ApacheReportEngine apacheReportEngine = new ApacheReportGeneratorEngine();
        PDFGenerator pdfGenerator = apacheReportEngine.getPDFType();
        pdfGenerator.generatePDF(tempModel);


    }
}
