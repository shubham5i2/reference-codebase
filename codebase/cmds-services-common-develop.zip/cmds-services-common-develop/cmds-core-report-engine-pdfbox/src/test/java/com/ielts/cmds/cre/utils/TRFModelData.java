package com.ielts.cmds.cre.utils;

import com.ielts.cmds.cre.model.GeneratorData;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TRFModelData implements GeneratorData {

    private String name = "Pulkit";

    private String lastName = "Arora";

    private String cefrLevel = "B1";

    private String trfNumber = "trfNumber";

    private String bookingTestDate = "12/05/2022";

    private String ttPhoto;

    private String productModule;

    private String comments;

    private String commentLine1;

    private String commentLine2;

    private String commentLine3;

    private String commentLine4;

    private String commentLine5;

    private String commentLine6;

    private String commentLine7;


    private String templateName;

    private String reportType;
}
