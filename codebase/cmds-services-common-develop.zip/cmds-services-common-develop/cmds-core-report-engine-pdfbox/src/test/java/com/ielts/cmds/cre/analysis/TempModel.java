package com.ielts.cmds.cre.analysis;

import com.ielts.cmds.cre.model.GeneratorData;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class TempModel implements GeneratorData {

    private String name;

    private String lastName;

    private String cefrLevel = "B1";

    private String ttPhoto;

}
