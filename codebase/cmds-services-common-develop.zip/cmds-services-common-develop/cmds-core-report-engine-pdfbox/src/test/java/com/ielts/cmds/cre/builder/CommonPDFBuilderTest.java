package com.ielts.cmds.cre.builder;

import com.ielts.cmds.cre.exception.ReportGenerationException;
import com.ielts.cmds.cre.provider.TemplateProvider;
import com.ielts.cmds.cre.renderer.RendererGenerator;
import com.ielts.cmds.cre.renderer.types.SimpleTextRenderer;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CommonPDFBuilderTest {

    @InjectMocks
    private CommonPDFBuilder commonPDFBuilder;

    @Mock
    TemplateProvider templateProvider;
    @Mock
    PDDocument pdDocument;
    @InjectMocks
    PDDocument pdDocument1;
    @Mock
    PDPageContentStream pdPageContentStream;
    @Spy
    private CommonPDFBuilder spyCommonPDFBuilder;
    @Mock
    private SimpleTextRenderer simpleTextRenderer;

    @Mock
    private RendererGenerator rendererGenerator;


    @Test
    void checkPositiveFlow() throws IOException, InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        spyCommonPDFBuilder.templateProvider = templateProvider;
        when(templateProvider.getTemplate(ArgumentMatchers.any())).thenReturn(getByteArrayOfTempPDF());
        when(templateProvider.getTemplate(ArgumentMatchers.any())).thenReturn(getByteArrayOfFieldJson());
        ReflectionTestUtils.setField(spyCommonPDFBuilder, "templateName", "TRF.pdf");
        ReflectionTestUtils.setField(spyCommonPDFBuilder, "templateName", "TRF_FIELDS_MULTILINE_GT.json");
        doReturn(pdDocument).when(spyCommonPDFBuilder).getPdDocument(ArgumentMatchers.any());
        doReturn(pdPageContentStream).when(spyCommonPDFBuilder).getPdPageContentStream(ArgumentMatchers.any());
        doNothing().when(spyCommonPDFBuilder).renderPDFFields(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), any());
        spyCommonPDFBuilder.buildPDF();
        verify(spyCommonPDFBuilder, times(1)).buildPDF();
        verify(spyCommonPDFBuilder, times(1)).getPdPageContentStream(ArgumentMatchers.any());
        verify(spyCommonPDFBuilder, times(1)).getPdDocument(ArgumentMatchers.any());
        verify(spyCommonPDFBuilder, times(3)).renderPDFFields(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), any());


    }

    @Test
    void throwExceptionWhileRenderingFields() throws IOException, InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        spyCommonPDFBuilder.templateProvider = templateProvider;
        when(templateProvider.getTemplate(ArgumentMatchers.any())).thenReturn(getByteArrayOfTempPDF());
        when(templateProvider.getTemplate(ArgumentMatchers.any())).thenReturn(getByteArrayOfFieldJson());
        ReflectionTestUtils.setField(spyCommonPDFBuilder, "templateName", "TRF.pdf");
        ReflectionTestUtils.setField(spyCommonPDFBuilder, "templateName", "TRF_FIELDS_MULTILINE_GT.json");
        doReturn(pdDocument).when(spyCommonPDFBuilder).getPdDocument(ArgumentMatchers.any());
        doReturn(pdPageContentStream).when(spyCommonPDFBuilder).getPdPageContentStream(ArgumentMatchers.any());
        doThrow(new IllegalAccessException()).when(spyCommonPDFBuilder).renderPDFFields(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), any());
        assertThrows(ReportGenerationException.class, () -> spyCommonPDFBuilder.buildPDF());
        verify(spyCommonPDFBuilder, times(1)).getPdPageContentStream(ArgumentMatchers.any());
        verify(spyCommonPDFBuilder, times(1)).getPdDocument(ArgumentMatchers.any());
        verify(spyCommonPDFBuilder, times(1)).renderPDFFields(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), any());

    }

    @Test
    void throwExceptionWhileRenderFields() throws IOException, InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        spyCommonPDFBuilder.templateProvider = templateProvider;
        when(templateProvider.getTemplate(ArgumentMatchers.any())).thenReturn(getByteArrayOfTempPDF());
        when(templateProvider.getTemplate(ArgumentMatchers.any())).thenReturn(getByteArrayOfFieldJson());
        ReflectionTestUtils.setField(spyCommonPDFBuilder, "templateName", "TRF.pdf");
        ReflectionTestUtils.setField(spyCommonPDFBuilder, "templateName", "TRF_FIELDS_MULTILINE_GT.json");
        doReturn(pdDocument).when(spyCommonPDFBuilder).getPdDocument(ArgumentMatchers.any());
        doReturn(pdPageContentStream).when(spyCommonPDFBuilder).getPdPageContentStream(ArgumentMatchers.any());
        assertThrows(IllegalArgumentException.class, () -> spyCommonPDFBuilder.buildPDF());
        verify(spyCommonPDFBuilder, times(1)).getPdPageContentStream(ArgumentMatchers.any());
        verify(spyCommonPDFBuilder, times(1)).getPdDocument(ArgumentMatchers.any());
        verify(spyCommonPDFBuilder, times(1)).renderPDFFields(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), any());

    }

    private byte[] getByteArrayOfTempPDF() throws IOException {
        File file = new File("src/test/resources/BlankTestPDF.pdf");
        InputStream inputStream = new FileInputStream(file);
        byte[] arr = new byte[(int) file.length()];
        inputStream.read(arr);
        return arr;
    }

    private byte[] getByteArrayOfFieldJson() throws IOException {
        File file = new File("src/test/resources/fields.json");
        InputStream inputStream = new FileInputStream(file);
        byte[] arr = new byte[(int) file.length()];
        inputStream.read(arr);
        return arr;
    }
}
