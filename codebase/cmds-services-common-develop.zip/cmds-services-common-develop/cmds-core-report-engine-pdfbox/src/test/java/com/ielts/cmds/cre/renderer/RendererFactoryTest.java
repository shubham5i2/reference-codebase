package com.ielts.cmds.cre.renderer;

import com.ielts.cmds.cre.exception.ReportGenerationException;
import com.ielts.cmds.cre.model.Field;
import com.ielts.cmds.cre.model.enums.TypeEnum;
import com.ielts.cmds.cre.renderer.types.ImageRenderer;
import com.ielts.cmds.cre.renderer.types.SimpleTextRenderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class RendererFactoryTest {

    @InjectMocks
    RendererFactory rendererFactory;

    @Test
    void getImageRendererInstance() {
        Field field = Field.builder()
                .type(TypeEnum.IMAGE)
                .build();
        assertTrue(rendererFactory.getRenderer(field) instanceof ImageRenderer);
    }

    @Test
    void getSimpleTextRendererInstance() {
        Field field = Field.builder()
                .type(TypeEnum.TEXT)
                .build();
        assertTrue(rendererFactory.getRenderer(field) instanceof SimpleTextRenderer);
    }

    @Test
    void whenEmptyThrowsException() {
        Field field = Field.builder()
                .height(5f)
                .width(4f)
                .build();
        assertThrows(ReportGenerationException.class, () -> rendererFactory.getRenderer(field));
    }
}