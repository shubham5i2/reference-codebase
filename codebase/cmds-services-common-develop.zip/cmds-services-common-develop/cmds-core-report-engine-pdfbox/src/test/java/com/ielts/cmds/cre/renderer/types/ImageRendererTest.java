package com.ielts.cmds.cre.renderer.types;

import com.ielts.cmds.cre.exception.ReportGenerationException;
import com.ielts.cmds.cre.model.Field;
import com.ielts.cmds.cre.model.FontResolver;
import com.ielts.cmds.cre.model.GeneratorData;
import com.ielts.cmds.cre.model.enums.TypeEnum;
import com.ielts.cmds.cre.utils.TRFModelData;
import org.apache.commons.io.FileUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.io.IOException;
import java.util.Base64;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class ImageRendererTest {

    @InjectMocks
    ImageRenderer imageRenderer;

    @Spy
    ImageRenderer spyImageRenderer;

    @Test
    void checkForPositiveFlow() throws IOException {
        Field field = Field.builder()
                .fieldPath("ttPhoto")
                .name("Image")
                .height(10f)
                .width(20f)
                .xPos(120f)
                .yPos(360f)
                .mandatory(true)
                .type(TypeEnum.IMAGE)
                .build();
        File file = new File("src/test/resources/photo6.jpg");
        byte[] fileContent = FileUtils.readFileToByteArray(file);
        String encodedString = Base64.getEncoder().encodeToString(fileContent);
        GeneratorData generatorData = TRFModelData.builder()
                .lastName("Arora")
                .name("Pulkit")
                .ttPhoto(encodedString)
                .build();

        PDDocument pdDocument = PDDocument.load(new File("src/test/resources/BlankTestPDF.pdf"));
        PDPageContentStream pdPageContentStream = new PDPageContentStream(pdDocument, pdDocument.getPage(0));
        spyImageRenderer.render(field, pdPageContentStream, pdDocument, generatorData, new FontResolver(pdDocument));
        verify(spyImageRenderer, times(1)).render(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), any());
        verify(spyImageRenderer, times(1)).drawImage(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any());
        verify(spyImageRenderer, times(1)).fixImageSize(ArgumentMatchers.any());
        verify(spyImageRenderer, times(1)).checkFieldHeightWidth(ArgumentMatchers.any());
    }


    @Test
    void throwExceptionWhenHeightOrWidthIsNull() throws IOException {
        Field field = Field.builder()
                .fieldPath("ttPhoto")
                .name("Image")
                .height(0f)
                .width(0f)
                .xPos(120f)
                .yPos(360f)
                .mandatory(true)
                .type(TypeEnum.IMAGE)
                .build();
        File file = new File("src/test/resources/photo6.jpg");
        byte[] fileContent = FileUtils.readFileToByteArray(file);
        String encodedString = Base64.getEncoder().encodeToString(fileContent);
        GeneratorData generatorData = TRFModelData.builder()
                .lastName("Arora")
                .name("Pulkit")
                .ttPhoto(encodedString)
                .build();

        PDDocument pdDocument = PDDocument.load(new File("src/test/resources/BlankTestPDF.pdf"));
        PDPageContentStream pdPageContentStream = new PDPageContentStream(pdDocument, pdDocument.getPage(0));
        assertThrows(ReportGenerationException.class, () -> spyImageRenderer.render(field, pdPageContentStream, pdDocument, generatorData, new FontResolver(pdDocument)));
        verify(spyImageRenderer, times(1)).render(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), any());
        verify(spyImageRenderer, times(1)).checkFieldHeightWidth(ArgumentMatchers.any());
    }

    @Test
    void throwExceptionWhenImageIsNull() throws IOException {
        Field field = Field.builder()
                .fieldPath("ttPhoto")
                .name("Image")
                .height(0f)
                .width(0f)
                .xPos(120f)
                .yPos(360f)
                .mandatory(true)
                .type(TypeEnum.IMAGE)
                .build();
        GeneratorData generatorData = TRFModelData.builder()
                .lastName("Arora")
                .name("Pulkit")
                .ttPhoto(null)
                .build();

        PDDocument pdDocument = PDDocument.load(new File("src/test/resources/BlankTestPDF.pdf"));
        PDPageContentStream pdPageContentStream = new PDPageContentStream(pdDocument, pdDocument.getPage(0));
        assertThrows(ReportGenerationException.class, () -> spyImageRenderer.render(field, pdPageContentStream, pdDocument, generatorData, new FontResolver(pdDocument)));
        verify(spyImageRenderer, times(1)).render(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), any());
        verify(spyImageRenderer, times(0)).drawImage(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any());
    }


    @Test
    void throwExceptionWhenImageNotPresent() throws IOException {
        Field field = Field.builder()
                .fieldPath("ttPhoto1")
                .name("Image")
                .height(0f)
                .width(0f)
                .xPos(120f)
                .yPos(360f)
                .mandatory(true)
                .type(TypeEnum.IMAGE)
                .build();
        File file = new File("src/test/resources/photo6.jpg");
        byte[] fileContent = FileUtils.readFileToByteArray(file);
        String encodedString = Base64.getEncoder().encodeToString(fileContent);
        GeneratorData generatorData = TRFModelData.builder()
                .lastName("Arora")
                .name("Pulkit")
                .ttPhoto(encodedString)
                .build();

        PDDocument pdDocument = PDDocument.load(new File("src/test/resources/BlankTestPDF.pdf"));
        PDPageContentStream pdPageContentStream = new PDPageContentStream(pdDocument, pdDocument.getPage(0));
        assertThrows(ReportGenerationException.class, () -> spyImageRenderer.render(field, pdPageContentStream, pdDocument, generatorData, new FontResolver(pdDocument)));
        verify(spyImageRenderer, times(1)).render(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), any());
        verify(spyImageRenderer, times(0)).drawImage(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any());
    }

}