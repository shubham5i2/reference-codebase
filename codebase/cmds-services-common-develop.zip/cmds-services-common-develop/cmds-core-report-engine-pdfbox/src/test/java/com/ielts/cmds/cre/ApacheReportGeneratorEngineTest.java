package com.ielts.cmds.cre;

import com.ielts.cmds.cre.generator.PDFGenerator;
import com.ielts.cmds.cre.generator.trf.ReportGenerator;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class ApacheReportGeneratorEngineTest {

    @InjectMocks
    ApacheReportGeneratorEngine apacheReportGeneratorEngine;

    @Spy
    ApacheReportGeneratorEngine spyApacheReportEngine;


    @Test
    void checkForETRFInstance() {
        PDFGenerator pdfGenerator = spyApacheReportEngine.getPDFType();
        verify(spyApacheReportEngine, times(1)).getPDFType();
        assertTrue(pdfGenerator instanceof ReportGenerator);
    }

}