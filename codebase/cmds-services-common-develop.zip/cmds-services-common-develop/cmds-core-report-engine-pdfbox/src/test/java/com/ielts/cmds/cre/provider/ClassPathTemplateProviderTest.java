package com.ielts.cmds.cre.provider;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
class ClassPathTemplateProviderTest {

    @InjectMocks
    private ClassPathTemplateProvider classPathTemplateProvider;


    @Test
    void checkPositiveFlow() {
        assertDoesNotThrow(() -> classPathTemplateProvider.getTemplate("photo6.jpg"));
    }

    @Test
    void throwExceptionForFileNotFound() throws IOException {
        assertThrows(NullPointerException.class, () -> classPathTemplateProvider.getTemplate("photo66.jpg"));
    }

}