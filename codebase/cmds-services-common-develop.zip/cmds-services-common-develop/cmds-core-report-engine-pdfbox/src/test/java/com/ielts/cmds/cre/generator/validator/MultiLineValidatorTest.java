package com.ielts.cmds.cre.generator.validator;

import com.ielts.cmds.cre.exception.ReportGenerationException;
import com.ielts.cmds.cre.model.GeneratorData;
import com.ielts.cmds.cre.utils.TRFModelData;
import org.apache.commons.beanutils.BeanUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.InvocationTargetException;

import static com.ielts.cmds.cre.constants.ApacheReportEngineConstants.MULTILINE;
import static com.ielts.cmds.cre.constants.ApacheReportEngineConstants.SINGLELINE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
class MultiLineValidatorTest {

    @InjectMocks
    private MultiLineValidator multiLineValidator;

    @Test
    void checkForSingleLine() throws InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        GeneratorData generatorData = new TRFModelData();
        assertEquals(SINGLELINE, multiLineValidator.checkIfMultilineTRFNeeded(generatorData));
    }

    @Test
    void checkForMultiLineLine() throws InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        GeneratorData generatorData = new TRFModelData();
        BeanUtils.setProperty(generatorData, "cefrLevel", "Below B1");
        assertEquals(MULTILINE, multiLineValidator.checkIfMultilineTRFNeeded(generatorData));
    }

    @Test
    void whenCalledThrowsException() throws InvocationTargetException, IllegalAccessException {
        GeneratorData generatorData = new TRFModelData();
        BeanUtils.setProperty(generatorData, "cefrLevel", null);
        assertThrows(ReportGenerationException.class, () -> multiLineValidator.checkIfMultilineTRFNeeded(generatorData));
    }
}
