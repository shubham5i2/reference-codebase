package com.ielts.cmds.cre.generator.trf;


import com.ielts.cmds.cre.builder.CommonPDFBuilder;
import com.ielts.cmds.cre.exception.ReportGenerationException;
import com.ielts.cmds.cre.generator.validator.MultiLineValidator;
import com.ielts.cmds.cre.model.GeneratorData;
import com.ielts.cmds.cre.utils.TRFModelData;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.InvocationTargetException;

import static com.ielts.cmds.cre.constants.ApacheReportEngineConstants.SINGLELINE;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;

@ExtendWith(MockitoExtension.class)
class ReportGeneratorTest {

    @Mock
    CommonPDFBuilder pdfBuilder;
    @InjectMocks
    private ReportGenerator reportGenerator;
    @Mock
    private MultiLineValidator multiLineValidator;
    @Mock
    private ReportGenerator mockReportGenerator;
    @Spy
    private ReportGenerator spyReportGenerator;

    @Test
    void checkPositiveFlow() throws InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        spyReportGenerator.multiLineValidator = multiLineValidator;

        when(multiLineValidator.checkIfMultilineTRFNeeded(ArgumentMatchers.any())).thenReturn(SINGLELINE);

        GeneratorData generatorData = new TRFModelData();
        when(spyReportGenerator.getBuilder(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any() )).thenReturn(pdfBuilder);
        spyReportGenerator.generatePDF(generatorData);
        verify(spyReportGenerator, times(1)).generatePDF(ArgumentMatchers.any());
        verify(spyReportGenerator, times(1)).getBuilder(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any());
    }

    @Test
    void returnExceptionFromMethod() throws InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        spyReportGenerator.multiLineValidator = multiLineValidator;
        when(multiLineValidator.checkIfMultilineTRFNeeded(ArgumentMatchers.any())).thenThrow(new IllegalAccessException());
        GeneratorData generatorData = new TRFModelData();
        assertThrows(ReportGenerationException.class, () -> spyReportGenerator.generatePDF(generatorData));
        verify(spyReportGenerator, times(1)).generatePDF(ArgumentMatchers.any());
        verify(spyReportGenerator, times(0)).getBuilder(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any());
    }

}
