package com.ielts.cmds.cre.renderer.types;


import com.ielts.cmds.cre.exception.ReportGenerationException;
import com.ielts.cmds.cre.model.Field;
import com.ielts.cmds.cre.model.FontResolver;
import com.ielts.cmds.cre.model.GeneratorData;
import com.ielts.cmds.cre.model.enums.TypeEnum;
import com.ielts.cmds.cre.utils.TRFModelData;
import org.apache.commons.io.FileUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Base64;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class CentreAlignTextRendererTest {

    @Spy
    private CentreAlignTextRenderer centreAlignTextRenderer;

    @Spy
    private SimpleTextRenderer spyTextWrapRenderer;

    @Mock
    private PDDocument pdDocument;

    @Test
    void checkForPositiveFlow() throws IOException, InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        Field field = Field.builder()
                .fieldPath("name")
                .name("Text")
                .xPos(120f)
                .yPos(360f)
                .width(305.0f)
                .height(75.0f)
                .yPosIncrement(11.52f)
                .mandatory(true)
                .font("HELVETICA")
                .fontSize(10f)
                .type(TypeEnum.CENTRETEXT)
                .build();
        File file = new File("src/test/resources/photo6.jpg");
        byte[] fileContent = FileUtils.readFileToByteArray(file);
        String encodedString = Base64.getEncoder().encodeToString(fileContent);
        GeneratorData generatorData = TRFModelData.builder()
                .lastName("Jasti")
                .name("Lalitha")
                .ttPhoto(encodedString)
                .comments("comments for Junits")
                .build();
        PDDocument document = PDDocument.load(new File("src/test/resources/BlankTestPDF.pdf"));
        PDPageContentStream pdPageContentStream = new PDPageContentStream(document, document.getPage(0), PDPageContentStream.AppendMode.APPEND, true, true);
        centreAlignTextRenderer.render(field, pdPageContentStream, document, generatorData, new FontResolver(document));
        verify(centreAlignTextRenderer, times(1)).render(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), any());
    }

    @Test
    void throwExceptionIfFieldNotPresent() throws IOException, InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        Field field = Field.builder()
                .fieldPath("text")
                .name("Text")
                .xPos(120f)
                .yPos(360f)
                .mandatory(true)
                .font("HELVETICA")
                .fontSize(10f)
                .type(TypeEnum.CENTRETEXT)
                .build();
        File file = new File("src/test/resources/photo6.jpg");
        byte[] fileContent = FileUtils.readFileToByteArray(file);
        String encodedString = Base64.getEncoder().encodeToString(fileContent);
        GeneratorData generatorData = TRFModelData.builder()
                .lastName("Arora")
                .name("Pulkit")
                .ttPhoto(encodedString)
                .build();
        PDDocument document = PDDocument.load(new File("src/test/resources/BlankTestPDF.pdf"));
        PDPageContentStream pdPageContentStream = new PDPageContentStream(document, document.getPage(0), PDPageContentStream.AppendMode.APPEND, true, true);
        assertThrows(ReportGenerationException.class, () -> centreAlignTextRenderer.render(field, pdPageContentStream, document, generatorData, new FontResolver(document)));
        verify(centreAlignTextRenderer, times(1)).render(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), any());


    }

}
