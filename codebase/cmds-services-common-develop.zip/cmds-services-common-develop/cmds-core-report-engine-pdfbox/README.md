# PDF Box Library 

## Overview
PDF Box Library helps to create new PDF documents 
and to manipulate existing PDF documents. 
It is an easy way to create PDF templates.


**PDF Box Implementation Details Link:** https://confluence.britishcouncil.org/display/IMPS/PDF+Library+Implementation+Details

## Implementation Guidelines

### Microservice Changes

#### Add pdf box library dependency in the **pom.xml** of the respective MX 
```
	<dependency>
            <groupId>com.ielts.cmds.common</groupId>
            <artifactId>cmds-core-report-engine-pdfbox</artifactId>
            <version>latest-version</version>
    </dependency>

```
**Note:** Please do change ***latest-version*** to actual version in pom.xml

****Steps to Generate a PDF File:****

Please follow below steps to generate a PDF file

**Step-1**: Please make sure that template file(for which you want
to generate PDF) and their respective json file is present in the
resources folder

https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-services-common/-/tree/develop/cmds-core-report-engine-pdfbox/src/main/resources

Example json format:
```
{
  "fieldsList": [
    {
      "name": "Product Module",
      "xPos": 441.36,
      "yPos": 82.08,
      "width": 0,
      "height": 0,
      "mandatory": true,
      "type": "TEXT",
      "font": "HELVETICA",
      "fontSize": 12,
      "fieldPath": "productModule"
    },
    ...
    ...
    ...
    {
      "name": "TestTaker Photo",
      "xPos": 449.28,
      "yPos": 295.8,
      "width": 127,
      "height": 121.68,
      "mandatory": true,
      "type": "IMAGE",
      "fieldPath": "ttPhoto"
    }
  ]
}
```
**FieldName** | **Description** | 
--- | --- |
name | Indicates name of the field |
xPos | Indicates x-axis cordinate of the field. This is used to place the specific field on the template file |
yPos |Indicates y-axis cordinate of the field. This is used to place the specific field on the template file |
width | Indicates width of the field in the template |
height | Indicates height of the field in the template |
mandatory | Indicates if the field is mandatory or not |
type | Indicates the field type. Ex: TEXT, WRAPTEXT and IMAGE |
fieldPath | Indicates the field name from generation model |

**Step-2**: Add below dependency in POM.xml file
```
<dependency>
    <groupId>com.ielts.cmds.common</groupId>
    <artifactId>cmds-core-report-engine-pdfbox</artifactId>
    <version>latest-version</version>
</dependency>

```
**Step-3**: Build *ReportGenerationModel* data in mx as shown below

```
GeneratorData generatorData = ReportGenerationModel.builder()
                .productModule("ACADEMIC")
                .centreNumber("101IH")
                .bookingTestDate("27/APR/2022")
                .candidateNumber("000200")
                .familyName("SHARAD")
                .firstName("ANKUR")
                .candidateId("AB12314")
                ...
                ...
                ...
                .build();
```
**Step-4**: Once template data is build and stored in
*generatorData* then the generated PDF file is stored in byte array
format(generatorOutput[ ])

```
ApacheReportEngine apacheReportEngine = new ApacheReportGeneratorEngine();

PDFGenerator pdfGenerator = apacheReportEngine.getPDFType();

final byte[] generatorOutput = pdfGenerator.generatePDF(generatorData);
```
**NOTE:** There are some mandatory fields in json file which needs to 
be populated in order to generate a PDF file. These mandatory
fields are as follows:
```
Product Module
TRF Number
Booking Date
Centre Number
Date of Birth
Candidate Number
Candidate ID
Sex
Scheme Code
Country
Nationality
First Language
Overall Band Score
Listening
Reading
Writing
Speaking
CEFR Level
Issue Date
TestTaker Photo
```

## Features supported

Currently PDFBox Library is supporting 3 types of renders and they
are as follows:

- TEXT render - This type is used to render text field on PDF template
- WRAPTEXT render - This type is used to render multiline wrapped text on PDF template
- IMAGE render - This type is used to render image on PDF template

## Limitations
- Currently \n and \t kind of special characters are not supported by HELVITICA font and will be implemented in future.

- Below are characters supported by PDFBox Library
```
! " # $ % & ' ( ) * + , - . / 0 1 2 3 4 5 6 7 8 9 : ; < = > ? @ A B C D E F G H I J K L M N
O P Q R S T U V W X Y Z [ \ ] ^ _ ` a b c d e f g h i j k l m n o p q r s t u v w x y z { | }
~ • ¡ ¢ £ ¤ ¥ ¦ § ¨ © ª « ¬ ® ¯ ° ± ² ³ ´ µ ¶ · ¸ ¹ º » ¼ ½ ¾ ¿ À Á Â Ã Ä Å Æ Ç È É Ê Ë Ì Í
Î Ï Ð Ñ Ò Ó Ô Õ Ö × Ø Ù Ú Û Ü Ý Þ ß à á â ã ä å æ ç è é ê ë ì í î ï ð ñ ò ó ô õ ö ÷ ø ù ú û ü ý þ
```
- Currently PDFBox Library has support for following templates https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-services-common/-/tree/develop/cmds-core-report-engine-pdfbox/src/main/resources. To generate other templates, then required templates and their respective json files has to be added.

## Change Log

### 0.0.17
- Templates updated(UKVI_TRF_CD, UKVI_SSR_TRF_CD).
- Alignments changes for UKVI_CD templates.

### 0.0.16
- Change to use a new instance of FontResolver for each report generated.

### 0.0.15
- PDFBoc cmap failure issue resolved

### 0.0.14
- Templates updated

### 0.0.13
- Templates updated(ETRF_CD, TRF_IOL,UKVI_TRF_IOL, UKVI_ETRF_IOL)

### 0.0.12-SNAPSHOT
- UKVI OSR IOC templates implementation
- Stamp Correction

### 0.0.11-SNAPSHOT
- Support for Open Sans Font

### 0.0.9-SNAPSHOT
- Multiple admin comment support

- OSR IOL templates implementation
### 0.0.8-SNAPSHOT
- Changed nationality field to non-mandatory for China Partner Code

- UKVI TRF/ETRF templates implementation

- Multiple Admin Comments (Reduced font size)
### 0.0.7-SNAPSHOT
- Centre Alignment support included

- Changed countryOrRegion field to non-mandatory

### 0.0.6-SNAPSHOT
- SSR Templates changes to OSR

### 0.0.5-SNAPSHOT
- UKVI IOL TRF/ETRF templates implementation

- New Line Character support included

- Ignore Unsupported characters

### 0.0.4-SNAPSHOT
- TRF CD Templates added with Administrator Signature

### 0.0.3-SNAPSHOT
- SSR TRF/eTRF templates implementation

### 0.0.2-SNAPSHOT
- Code refactoring is done to have generic implementation for both TRF and ETRF report generation
 
- Text wrapping functionality is included

### 0.0.1-SNAPSHOT
- Base Implementation of PDF report engine
