import au.com.dius.pact.consumer.ConsumerPactTestMk2;
import au.com.dius.pact.consumer.Pact;
import au.com.dius.pact.consumer.PactProviderRuleMk2;
import au.com.dius.pact.consumer.PactVerification;
import au.com.dius.pact.consumer.dsl.DslPart;
import au.com.dius.pact.consumer.dsl.PactDslJsonBody;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.model.RequestResponsePact;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class OrsToLpr_58PostTest {

    public static final String consumerServiceName = "ORS_Client_58_Post";
    public static final String providerServiceName = "LPR_Server_58_Post";
    public static int providerServicePort = 8110;
    public static String providerUrl = "http://localhost:" + providerServicePort + "/lpr/location";

    public String postbody = new String(Files.readAllBytes(Paths.get("src/Resources/Input_OrsToLpr_58Post.txt")), StandardCharsets.UTF_8);
    // Start the Provider Mock Service
    @Rule
    public PactProviderRuleMk2 provider = new PactProviderRuleMk2(providerServiceName, "localhost", providerServicePort, this);

    public OrsToLpr_58PostTest() throws IOException {
    }


    @Pact(consumer = consumerServiceName)
    public RequestResponsePact createPact(PactDslWithProvider builder) {
        Map<String, String> headers = new HashMap();
        headers.put("Content-Type", "application/json");

        DslPart reqBody = new PactDslJsonBody()

                .array("locationNodes")
                .object()
                .numberType("locationId", 79817239)
                .stringType("testCentreId", "1")
                .stringType("locationType", "Jennings")
                .stringType("locationName", "invigilator")
                .stringType("externalLocationId", "2321312")
                .stringType("parentExternalLocationId", "string")
                .stringType("parentLocationId", "string")
                .stringType("action", "CHG")
                .stringType("requestNotes", "string")
                .array("addresses")
                .object()
                .stringType("addressType", "Postal")
                .stringType("address1Line", "GPO BOX 1515")
                .stringType("address2Line", "string")
                .stringType("address3Line", "string")
                .stringType("address4Line", "string")
                .stringType("city", "Melbourne")
                .stringType("stateProvince", "VIC")
                .stringType("zipPostcode", "3000")
                .stringType("country3Code", "AUS")
                .stringType("action", "CHG")
                .closeObject()
                .closeArray()
                .array("contacts")
                .object()
                .stringType("contactType", "Test Centre Administrator")
                .stringType("firstName", "Alan")
                .stringType("lastName", "Davies")
                .stringType("telephone", "6128288282")
                .stringType("email", "SupportAu241@idp.com")
                .stringType("action", "CHG")
                .closeObject()
                .closeArray()
                .array("approvedProducts")
                .object()
                .stringType("productId", "1234567")
                .stringType("authorisedStartDate", "2020-06-01T00:00:00.000Z")
                .stringType("suspendedDate", "2020-09-02T00:00:00.000Z")
                .stringType("authorisedBy", "pmitchel@ielts.com")
                .stringType("action", "CHG")
                .closeObject()
                .closeArray()
                .closeObject()
                .closeArray()
                .asBody();

        DslPart resBody = new PactDslJsonBody()
                .stringType("transactionId", "string")
                .asBody();


        return builder
                .given("There is a location details")
                .uponReceiving("A request for adding location details")
                .method("POST")
                .headers(headers)
                .body(reqBody)
                .path("/lpr/location")
                .willRespondWith()
                .status(202)
                .headers(headers)
                .body(resBody)
                .toPact();
    }

    @Test
    @Category(Int58Post.class)
    @PactVerification()
    public void doTest() throws IOException {
      //  System.setProperty("pact.rootDir","../pacts");
        HttpPost httpPost = null;
        HttpClient httpClient = new DefaultHttpClient();
        //   String url=String.format("http://localhost:%d/%s", 8110 , "booking");
        String url=String.format(providerUrl);
        System.out.println("using url: "+url);
        HttpEntity httpEntity = new StringEntity((postbody), "utf-8");
        httpPost = new HttpPost(url);
        httpPost.setHeader("Content-type", "application/json; charset=utf-8");
        httpPost.setEntity(httpEntity);
        System.out.println("postbody :" + postbody);
        HttpResponse httpResponse = httpClient.execute(httpPost);
        System.out.println("r===="+httpResponse);
        System.out.println("Post===="+httpPost);
    }

}