public class Int92Post {
}
