public class Int30Get {
}
