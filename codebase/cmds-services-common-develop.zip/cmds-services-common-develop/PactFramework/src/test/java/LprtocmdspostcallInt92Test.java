import au.com.dius.pact.consumer.Pact;
import au.com.dius.pact.consumer.PactProviderRuleMk2;
import au.com.dius.pact.consumer.PactVerification;
import au.com.dius.pact.consumer.dsl.DslPart;
import au.com.dius.pact.consumer.dsl.PactDslJsonBody;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.model.RequestResponsePact;

import cucumber.deps.difflib.DiffRow;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;


public class LprtocmdspostcallInt92Test {

    public static final String providerServiceName = "CMDS-provider-Int92-POST";
    public static final String consumerServiceName = "LPR-consumer-Int92-POST";
    public static int providerServicePort = 8110;
    public static String providerUrl_POST_Reference = "http://localhost:" + providerServicePort + "/lpr/reference";
    String INT92_POST_INPUT = System.getenv("INT92_POST");
    public String postbody = new String(Files.readAllBytes(Paths.get(INT92_POST_INPUT )), StandardCharsets.UTF_8);
    public LprtocmdspostcallInt92Test() throws IOException {   }
    @Rule
    public PactProviderRuleMk2 provider = new PactProviderRuleMk2(providerServiceName, "localhost", providerServicePort, this);

    @Pact(consumer = consumerServiceName)
    public RequestResponsePact createPact(PactDslWithProvider builder) {
        Map<String, String> headers = new HashMap();
        headers.put("Content-Type", "application/json; charset=utf-8");

        DslPart reqBody = new PactDslJsonBody()
                .array("language")
                .object()
                .stringType("legacyReferenceId", "45")
                .stringType("iso2Code", "IT")
                .stringType("iso3Code", "ITA")
                .stringType("referenceName", "Italian")
                .stringType("effectiveFromDate", "2020-06-17")
                .stringType("effectiveToDate", "2020-06-16")
                .closeObject()
                .closeArray()
                .array("country")
                .object()
                .stringType("referenceId", "123456")
                .stringType("legacyReferenceId", "45")
                .stringType("iso2Code", "AU")
                .stringType("iso3Code", "AUS")
                .stringType("referenceName", "Australia")
                .stringType("effectiveFromDate", "2020-06-16")
                .stringType("effectiveToDate", "2020-06-16")
                .closeObject()
                .closeArray()
                .array("nationality")
                .object()
                .stringType("referenceId", "123456")
                .stringType("legacyReferenceId", "45")
                .stringType("iso2Code", "IT")
                .stringType("iso3Code", "ITA")
                .stringType("referenceName", "Italian")
                .stringType("effectiveFromDate", "2020-06-16")
                .stringType("effectiveToDate", "2020-06-16")
                .closeObject()
                .closeArray()
                .array("educationLevel")
                .object()
                .stringType("referenceId", "CMDS_ID")
                .numberType("legacyReferenceId", 0)
                .stringType("referenceName", "Secondary up to 16 years")
                .stringType("effectiveFromDate", "2020-06-16")
                .stringType("efectiveToDate", "2020-06-16")
                .closeObject()
                .closeArray()
                .array("occupationSector")
                .object()
                .stringType("referenceId", "CMDS_ID")
                .numberType("legacyReferenceId", 0)
                .stringType("referenceName", "Administrative services")
                .stringType("effectiveFromDate", "2020-06-16")
                .stringType("efectiveToDate", "2020-06-16")
                .closeObject()
                .closeArray()
                .array("occupationLevel")
                .object()
                .stringType("referenceId", "string")
                .stringType("legacyReferenceId", "string")
                .stringType("referenceName", "string")
                .stringType("effectiveFromDate", "string")
                .stringType("efectiveToDate", "string")
                .closeObject()
                .closeArray()
                .array("reasonForTest")
                .object()
                .stringType("referenceId", "CMDS_ID")
                .numberType("legacyReferenceId", 0)
                .stringType("referenceName", "other")
                .stringType("effectiveFromDate", "2020-06-16")
                .stringType("effectiveToDate", "2020-06-16")
                .closeObject()
                .closeArray()
                .array("identityType")
                .object()
                .stringType("referenceId", "CMDS_ID")
                .stringType("legacyReferenceId", "B")
                .stringType("referenceName", "Biometric Residence Permit")
                .stringType("effectiveFromDate", "2020-06-16")
                .stringType("efectiveToDate", "2020-06-16")
                .closeObject()
                .closeArray()
                .asBody();


        return builder
                .given("Reference details posted from LPR to CMDS")
                .uponReceiving("A request to update the Reference details at CMDS")
                .method("POST")
                .headers(headers)
                .body(reqBody)
                .path("/lpr/reference")
                .willRespondWith()
                .status(202)
                .headers(headers)
                .toPact();
    }


    @Test
    @Category(Int92Post.class)
    @PactVerification()
    public void doTest() throws IOException {
     //   System.setProperty("pact.rootDir","../target/pacts");
        HttpPost httpPost = null;
        HttpClient httpClient = new DefaultHttpClient();
        String url=String.format(providerUrl_POST_Reference );
        System.out.println("using url: "+url);
        HttpEntity httpEntity = new StringEntity((postbody), "utf-8");
        httpPost = new HttpPost(url);
        httpPost.setHeader("Content-type", "application/json; charset=utf-8");
        httpPost.setEntity(httpEntity);
        System.out.println("postbody :" + postbody);
        HttpResponse httpResponse = httpClient.execute(httpPost);
        System.out.println("Response : "+httpResponse);
        System.out.println("Post : "+httpPost);
    }
}
