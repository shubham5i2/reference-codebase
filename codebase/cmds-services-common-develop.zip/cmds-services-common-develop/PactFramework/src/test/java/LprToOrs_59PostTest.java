import au.com.dius.pact.consumer.Pact;
import au.com.dius.pact.consumer.PactProviderRuleMk2;
import au.com.dius.pact.consumer.PactVerification;
import au.com.dius.pact.consumer.dsl.DslPart;
import au.com.dius.pact.consumer.dsl.PactDslJsonBody;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.model.RequestResponsePact;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class LprToOrs_59PostTest {

    public static final String providerServiceName = "ORS_Server_59_Post";
    public static final String consumerServiceName = "LPR_Client_59_Post";
    public static int providerServicePort = 8110;
    public static String providerUrl_POST_Booking = "http://localhost:" + providerServicePort + "/lpr/reference";
    public String postbody = new String(Files.readAllBytes(Paths.get("src/Resources/Input_LprToOrs_59Post.txt")), StandardCharsets.UTF_8);
    public LprToOrs_59PostTest() throws IOException {   }
    @Rule
    public PactProviderRuleMk2 provider = new PactProviderRuleMk2(providerServiceName, "localhost", providerServicePort, this);

    @Pact(consumer = consumerServiceName)
    public RequestResponsePact createPact(PactDslWithProvider builder) {
        Map<String, String> headers = new HashMap();
        headers.put("Content-Type", "application/json; charset=utf-8");

        DslPart reqBody = new PactDslJsonBody()
                .array("language")
                .object()
                .numberType("referenceId", 453452)
                .stringType("legacyReferenceId", "012")
                .stringType("referenceName", "Polish")
                .stringType("effectiveFromDate", "2020-01-01")
                .stringType("efectiveToDate", "2020-01-01")
                .stringType("iso3Code", "string")
                .closeObject()
                .closeArray()
                .array("country")
                .object()
                .numberType("referenceId", 453452)
                .stringType("legacyReferenceId", "012")
                .stringType("referenceName", "Australia")
                .stringType("effectiveFromDate", "2020-01-01")
                .stringType("efectiveToDate", "2020-01-01")
                .stringType("iso3Code", "string")
                .closeObject()
                .closeArray()
                .array("nationality")
                .object()
                .numberType("referenceId", 453452)
                .stringType("legacyReferenceId", "012")
                .stringType("referenceName", "Chinese")
                .stringType("effectiveFromDate", "2020-01-01")
                .stringType("efectiveToDate", "2020-01-01")
                .stringType("iso3Code", "string")
                .closeObject()
                .closeArray()
                .array("educationLevel")
                .object()
                .numberType("referenceId", 453452)
                .stringType("legacyReferenceId", "012")
                .stringType("referenceName", "Student")
                .stringType("efectiveToDate", "2020-01-01")
                .stringType("effectiveFromDate", "2020-01-01")
                .closeObject()
                .closeArray()
                .array("occupationSector")
                .object()
                .numberType("referenceId", 453452)
                .stringType("legacyReferenceId", "012")
                .stringType("referenceName", "Finance")
                .stringType("efectiveToDate", "2020-01-01")
                .stringType("effectiveFromDate", "2020-01-01")
                .closeObject()
                .closeArray()
                .array("occupationLevel")
                .object()
                .numberType("referenceId", 453452)
                .stringType("legacyReferenceId", "007")
                .stringType("referenceName", "Student")
                .stringType("efectiveToDate", "2020-01-01")
                .stringType("effectiveFromDate", "2020-01-01")
                .closeObject()
                .closeArray()
                .array("reasonForTest")
                .object()
                .numberType("referenceId", 453452)
                .stringType("legacyReferenceId", "012")
                .stringType("referenceName", "For other education purposes")
                .stringType("efectiveToDate", "2020-01-01")
                .stringType("effectiveFromDate", "2020-01-01")
                .closeObject()
                .closeArray()
                .array("identityType")
                .object()
                .numberType("referenceId", 453452)
                .stringType("legacyReferenceId", "B")
                .stringType("referenceName", "Biometric Residence Permit")
                .stringType("efectiveToDate", "2020-01-01")
                .stringType("effectiveFromDate", "2020-01-01")
                .closeObject()
                .closeArray()
                .array("accessArrangement")
                .object()
                .numberType("referenceId", 453452)
                .stringType("legacyReferenceId", "012")
                .stringType("referenceName", "Wheelchair access")
                .stringType("efectiveToDate", "2020-01-01")
                .stringType("effectiveFromDate", "2020-01-01")
                .closeObject()
                .closeArray()
                .array("territory")
                .object()
                .numberType("referenceId", 453452)
                .stringType("legacyReferenceId", "012")
                .stringType("referenceName", "New York")
                .stringType("effectiveFromDate", "2020-01-01")
                .stringType("efectiveToDate", "2020-01-01")
                .stringType("iso3Code", "string")
                .stringType("countryIso3Code", "string")
                .closeObject()
                .closeArray()
                .array("testCentreType")
                .object()
                .numberType("referenceId", 453452)
                .stringType("legacyReferenceId", "C")
                .stringType("referenceName", "CEII")
                .stringType("efectiveToDate", "2020-01-01")
                .stringType("effectiveFromDate", "2020-01-01")
                .closeObject()
                .closeArray()
                .asBody();
        DslPart resBody = new PactDslJsonBody()
                .asBody();

        return builder
                .given("Reference details requested from LPR to ORS")
                .uponReceiving("A request to provide the reference details to ORS")
                .method("POST")
                .headers(headers)
                .body(reqBody)
                .path("/lpr/reference")
                .willRespondWith()
                .status(202)
                .headers(headers)
            
                .toPact();
    }


    @Test
    @Category(Int59Post.class)
    @PactVerification()
    public void doTest() throws IOException {
        //System.setProperty("pact.rootDir","../pacts");
        HttpPost httpPost = null;
        HttpClient httpClient = new DefaultHttpClient();
        String url=String.format(providerUrl_POST_Booking);
        System.out.println("using url: "+url);
        HttpEntity httpEntity = new StringEntity((postbody), "utf-8");
        httpPost = new HttpPost(url);
        httpPost.setHeader("Content-type", "application/json; charset=utf-8");
        httpPost.setEntity(httpEntity);
        System.out.println("postbody :" + postbody);
        HttpResponse httpResponse = httpClient.execute(httpPost);
        System.out.println("Response : "+httpResponse);
        System.out.println("Post : "+httpPost);
    }

}
