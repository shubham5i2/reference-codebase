import au.com.dius.pact.consumer.Pact;
import au.com.dius.pact.consumer.PactProviderRuleMk2;
import au.com.dius.pact.consumer.PactVerification;
import au.com.dius.pact.consumer.dsl.DslPart;
import au.com.dius.pact.consumer.dsl.PactDslJsonBody;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.model.RequestResponsePact;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class orsToCmds_38PostTest {

    public static final String consumerServiceName = "ORS_Client_38_Post";
    public static final String providerServiceName = "CMDS_Server_38_Post";
    public static int providerServicePort = 8110;
    public static String providerUrl = "http://localhost:" + providerServicePort + "/booking";

    public String postbody = new String(Files.readAllBytes(Paths.get("src/Resources/Input_orsToCmds_38Post.txt")), StandardCharsets.UTF_8);
    // Start the Provider Mock Service
    @Rule
    public PactProviderRuleMk2 provider = new PactProviderRuleMk2(providerServiceName, "localhost", providerServicePort, this);

    public orsToCmds_38PostTest() throws IOException {
    }


    @Pact(consumer = consumerServiceName)
    public RequestResponsePact createPact(PactDslWithProvider builder) {
        Map<String, String> headers = new HashMap();
        headers.put("Content-Type", "application/json; charset=utf-8");

        DslPart reqBody = new PactDslJsonBody()
                .integerType("productId", 500010)
                .integerType("locationId", 0)
                .stringType("testDate", "2020-01-01")
                .stringType("externalBookingId", "string")
                .stringType("bookingDetailStatus", "INCOMPLETE")
                .stringType("agentName", "The Agency Inc.")
                .booleanType("orsConsentGiven", true)
                .object("marketingInfo")
                .stringType("educationLevel", "Bachelors Degree")
                .integerType("yearsOfStudy", 4)
                .stringType("occupationSector", "string")
                .stringType("occupationLevel", "string")
                .stringType("reasonForTest", "Applying for Masters")
                .stringType("applyingToCountry3code", "AUS")
                .stringType("currentEnglishStudyPlace", "DJ Uni.")
                .stringType("occupationSectorOther", "string")
                .stringType("occupationLevelOther", "string")
                .stringType("reasonForTestOther", "string")
                .stringType("countryApplyingToOther", "GBR")
                .closeObject()
                .object("testTaker")
                .stringType("externalTestTakerId", "1234")
                .stringType("identityNumber", "AB12314")
                .stringType("identityType", "Passport")
                .stringType("identityVerificationStatus", "INCOMPLETE")
                .stringType("identityIssuingAuthority", "string")
                .stringType("identityExpiryDate", "2020-01-0")
                .stringType("firstName", "Alan")
                .stringType("lastName", "Davies")
                .stringType("dob", "1900-01-01")
                .stringType("sex", "M")
                .stringType("email", "alan@gmail.com")
                .stringType("title", "Mr.")
                .stringType("telephone", "+1 234566778")
                .stringType("mobile", "1234567890")
                .stringType("languageId", "4")
                .stringType("nationalityId", "8")
                .stringType("notes", "string")
                .object("address")
                .stringType("streetAddress1", "15")
                .stringType("streetAddress2", "King Street")
                .stringType("streetAddress3", "")
                .stringType("streetAddress4", "")
                .stringType("state", "VIC")
                .stringType("postalCode", "1234")
                .stringType("city", "Melbourne")
                .stringType("countryId", "AUS")
                .closeObject()
                .closeObject()
                .array("bookingLines")
                .object()
                .stringType("externalBookingLineId", "1233")
                .stringType("startTimeUTC", "2020-05-28T09:21:24.325Z")
                .stringType("startTimeLocal", "2020-05-28T09:21:24.325Z")
                .stringType("endTimeUTC", "2020-05-28T09:21:24.325Z")
                .stringType("endTimeLocal", "2020-05-28T09:21:24.325Z")
                .integerType("extraTimeMinutes", 15)
                .stringType("productId", "CD-IELTS-GT-R")
                .numberType("locationId", 1234)
                .stringType("status", "ACTIVE")
                .closeObject()
                .closeArray()
                .asBody();


        DslPart resBody = new PactDslJsonBody()
                .stringType("transactionId", "string")
                .asBody();


        return builder
                .given("There is a booking details")
                .uponReceiving("A request for booking details")
                .method("POST")
                .headers(headers)
                .body(reqBody)
                .path("/booking")
                .willRespondWith()
                .status(202)
                .headers(headers)
                .body(resBody)
                .toPact();
    }


    @Test
    @Category(Int38Post.class)
    @PactVerification()
    public void doTest() throws IOException {
    //    System.setProperty("pact.rootDir","../pacts");
        HttpPost httpPost = null;
        HttpClient httpClient = new DefaultHttpClient();
        //   String url=String.format("http://localhost:%d/%s", 8110 , "booking");
        String url=String.format(providerUrl);
        System.out.println("using url: "+url);
        HttpEntity httpEntity = new StringEntity((postbody), "utf-8");
        httpPost = new HttpPost(url);
        httpPost.setHeader("Content-type", "application/json; charset=utf-8");
        httpPost.setEntity(httpEntity);
        System.out.println("postbody :" + postbody);
        HttpResponse httpResponse = httpClient.execute(httpPost);
        System.out.println("r===="+httpResponse);
        System.out.println("Post===="+httpPost);
    }

}