import au.com.dius.pact.consumer.Pact;
import au.com.dius.pact.consumer.PactProviderRuleMk2;
import au.com.dius.pact.consumer.PactVerification;
import au.com.dius.pact.consumer.dsl.DslPart;
import au.com.dius.pact.consumer.dsl.PactDslJsonBody;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.model.RequestResponsePact;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
 
@SuppressWarnings("deprecation")
public class StaffToIdentity_67PostTest  {
 
public static final String providerServiceName = "IDENTITY_Server_67_Post";
public static final String consumerServiceName = "STAFF_Client_67_Post";
public static int providerServicePort = 8100;
public static String providerUrl_POST_IDENTITY = "http://localhost:" + providerServicePort + "/v1/internal/identity";
public String postbody = new String(Files.readAllBytes(Paths.get("src/Resources/Input_StaffToIdentity_67Post.txt")), StandardCharsets.UTF_8);
public StaffToIdentity_67PostTest() throws IOException {   }
    @Rule
    public PactProviderRuleMk2 provider = new PactProviderRuleMk2(providerServiceName, "localhost", providerServicePort, this);

    @Pact(consumer = consumerServiceName)
    public RequestResponsePact createPact(PactDslWithProvider builder) {
        Map<String, String> headers = new HashMap();
        headers.put("Content-Type", "application/json;charset=UTF-8");

        DslPart reqBody = new PactDslJsonBody()
          .stringType("user_id", "abc")
          .stringType("given_name", "John")
          .stringType("family_name", "Doe")
          .stringType("nickname", "Johnny")
          .stringType("email", "john.doe@gmail.com")
          .booleanType("email_verified", false)
          .stringType("phone_number", "+199999999999999")
          .booleanType("phone_verified", false)
          .stringType("user_status", "Active")
          .booleanType("verify_email", false)
          .object("app_metadata")
          .object("custom_roles")
          .object("cmds")
          .array("roles")
          .object()
          .stringType("location", "IN123")
          .stringType("role", "TestCentreAdmin")
          .stringType("product", "IELTSHOME")
          .closeObject()
          .closeArray()
          .closeObject()
          .object("inspera")
          .array("roles")
          .object()
          .stringType("location", "IN123")
          .stringType("role", "Invigilator")
          .stringType("product", "IELTSHOME")
          .closeObject()
          .closeArray()
          .closeObject()
          .closeObject()
          .closeObject()
          .object("user_metadata")
          .closeObject()
          .asBody();
  DslPart resBody = new PactDslJsonBody()
          .stringType("transactionId", "string")
          .asBody();
  
    return builder
             .given("Staff Management Internal Event publish to Internal CMDS System (Identity Service)")
             .uponReceiving("Response from Identity Service to Staff Management Internal")
             .method("POST")
             .headers(headers)
             .body(reqBody)
             .path("/v1/internal/identity")
             .willRespondWith()
             .status(202)
             .headers(headers)
             .body(resBody)
             .toPact();
            }


    @SuppressWarnings("resource")
	@Test
    @Category(Int67Post.class)
    @PactVerification()
    public void doTest() throws IOException {
        //System.setProperty("pact.rootDir","../pacts");
        HttpPost httpPost = null;
        HttpClient httpClient = new DefaultHttpClient();
        String url=String.format(providerUrl_POST_IDENTITY);
        System.out.println("using url: "+url);
        HttpEntity httpEntity = new StringEntity((postbody), "UTF-8");
        httpPost = new HttpPost(url);
        httpPost.setHeader("Content-type", "application/json;charset=UTF-8");
        httpPost.setEntity(httpEntity);
        System.out.println("postbody :" + postbody);
        HttpResponse httpResponse = httpClient.execute(httpPost);
        System.out.println("Response : "+httpResponse);
        System.out.println("Post : "+httpPost);
    }

}
