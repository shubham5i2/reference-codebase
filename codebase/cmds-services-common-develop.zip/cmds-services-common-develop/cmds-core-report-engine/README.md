
# ⛔️Deprecated

cmds-core-report-engine library is deprecated ⛔️. 

Please use PDFBox
core report engine library to generate PDFs.

[cmds-core-report-engine-pdfbox](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-services-common/-/tree/develop/cmds-core-report-engine-pdfbox)




