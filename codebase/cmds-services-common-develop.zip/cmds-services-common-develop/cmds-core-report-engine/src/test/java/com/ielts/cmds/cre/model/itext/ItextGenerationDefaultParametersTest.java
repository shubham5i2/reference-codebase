package com.ielts.cmds.cre.model.itext;

import com.ielts.cmds.cre.model.GenerationParameters;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ItextGenerationDefaultParametersTest {

    private final String jsonData = "{\"key1\" : \"value1\"}";

    @Test
    void when_build_using_builder_then_verify_all_attributes() {
        GenerationParameters parameters = ItextGenerationDefaultParameters.builder()
                .jsonData(jsonData)
                .configuration("key1", "value1")
                .configuration("key2", "value2")
                .build();

        assertEquals(jsonData, parameters.getOperationData().toString());

        assertTrue(parameters.getAdditionConfiguration().containsKey("key1"));
        assertTrue(parameters.getAdditionConfiguration().containsKey("key2"));

        assertEquals("value1", parameters.getAdditionConfiguration().get("key1"));
        assertEquals("value2", parameters.getAdditionConfiguration().get("key2"));
    }

    @Test
    void when_build_using_builder_then_verify_all_additional_configurations() {
        Map<String, Object> inputConfigurations = new HashMap<>();
        inputConfigurations.put("key1", "value1");
        inputConfigurations.put("key2", "value2");

        GenerationParameters parameters = ItextGenerationDefaultParameters.builder()
                .jsonData(jsonData)
                .configurations(inputConfigurations)
                .build();

        assertEquals(jsonData, parameters.getOperationData().toString());

        assertEquals(inputConfigurations, parameters.getAdditionConfiguration());
    }

}