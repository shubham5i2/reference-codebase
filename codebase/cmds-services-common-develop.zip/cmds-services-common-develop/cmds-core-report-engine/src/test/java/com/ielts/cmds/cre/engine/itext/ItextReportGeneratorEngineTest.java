package com.ielts.cmds.cre.engine.itext;

import com.ielts.cmds.cre.engine.ReportGeneratorEngine;
import com.ielts.cmds.cre.model.GenerationParameters;
import com.ielts.cmds.cre.model.itext.ItextGenerationDefaultParameters;
import com.ielts.cmds.cre.provider.itext.ItextLicenseProvider;
import com.ielts.cmds.cre.provider.itext.ItextTemplateProvider;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
class ItextReportGeneratorEngineTest {

    @Mock
    private ItextLicenseProvider itextLicenseProvider;

    @Mock
    private ItextTemplateProvider itextTemplateProvider;

    ReportGeneratorEngine initializeEngine() {
        return ItextReportGeneratorEngine.builder()
                .itextLicenseProvider(itextLicenseProvider)
                .itextTemplateProvider(itextTemplateProvider)
                .build();
    }

    @Test
    void when_product_key_not_given_then_throw_validation() {
        ReportGeneratorEngine reportGeneratorEngine = initializeEngine();
        GenerationParameters parameters = ItextGenerationDefaultParameters.builder()
                .jsonData("")
                .build();

        assertThrows(IllegalArgumentException.class, () -> reportGeneratorEngine.generate(parameters));
    }

    @Test
    void when_product_value_not_given_then_throw_validation() {
        ReportGeneratorEngine reportGeneratorEngine = initializeEngine();
        GenerationParameters parameters = ItextGenerationDefaultParameters.builder()
                .jsonData("")
                .configuration("product", " ")
                .build();

        assertThrows(IllegalArgumentException.class, () -> reportGeneratorEngine.generate(parameters));
    }

}