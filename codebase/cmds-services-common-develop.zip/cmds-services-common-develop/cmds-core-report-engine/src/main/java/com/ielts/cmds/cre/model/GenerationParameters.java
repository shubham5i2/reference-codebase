package com.ielts.cmds.cre.model;

import java.io.Serializable;
import java.util.Map;

public interface GenerationParameters extends Serializable {

    Object getOperationData();

    Map<String, Object> getAdditionConfiguration();

}
