package com.ielts.cmds.cre.model;

import lombok.Builder;
import lombok.Value;

import java.util.Base64;

@Value
@Builder
public class ByteArrayGeneratorOutput implements GeneratorOutput<byte[]> {

    byte[] data;

    int pageCount;

    @Override
    public byte[] getOutput() {
        return data;
    }

    @Override
    public String getBase64EncodedOutputString() {
        return Base64.getEncoder()
                .encodeToString(data);
    }

    @Override
    public int getSize() {
        return data.length;
    }

    @Override
    public String getMD5Checksum() {
        return null;
    }

}
