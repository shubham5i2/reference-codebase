package com.ielts.cmds.cre.constant;

public class ItextEngineConstant {

    public static final String TEMPLATE_NAME = "templateName";
    public static final String PRODUCT_KEY = "product";

    private ItextEngineConstant() {
    }

}
