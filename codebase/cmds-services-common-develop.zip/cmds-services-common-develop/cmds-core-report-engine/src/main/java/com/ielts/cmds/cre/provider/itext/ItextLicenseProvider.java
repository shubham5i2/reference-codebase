package com.ielts.cmds.cre.provider.itext;

public interface ItextLicenseProvider {

    byte[] getLicense();

}
