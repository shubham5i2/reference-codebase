package com.ielts.cmds.cre.model;

public interface GeneratorOutput<T> {

    T getOutput();

    String getBase64EncodedOutputString();

    int getSize();

    String getMD5Checksum();

}
