package com.ielts.cmds.cre.engine;

import com.ielts.cmds.cre.model.GenerationParameters;
import com.ielts.cmds.cre.model.GeneratorOutput;

public interface ReportGeneratorEngine {
    GeneratorOutput generate(GenerationParameters parameters);
}
