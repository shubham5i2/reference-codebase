package com.ielts.cmds.cre.provider.itext;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import lombok.Builder;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.http.urlconnection.UrlConnectionHttpClient;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.secretsmanager.SecretsManagerClient;
import software.amazon.lambda.powertools.parameters.ParamManager;
import software.amazon.lambda.powertools.parameters.SecretsProvider;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

@Builder
@Slf4j
public class SecreteManagerBasedItextLicenseProvider implements ItextLicenseProvider {

    private final ObjectMapper objectMapper;

    private final String licenseSecreteProviderName;

    private final String licenseSecreteProviderKey;

    public static SecreteManagerBasedItextLicenseProviderBuilder builder() {
        return new CustomSecreteManagerBasedItextLicenseProvider();
    }

    @Override
    public byte[] getLicense() {
        final Map<String, String> parameters = getKeyValuePairFromSecretManager(licenseSecreteProviderName);

        log.info("Parameters {}", parameters);

//        final String itextDitoLicense = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><dito-license><key>e4e8f742401c86a26e22313b4ac0eaa169ba312f4ba152ceb85c440317dfb230</key><version>2.1.0</version><token>MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCRlAjHyAP6xRlN2l5Fgko8Gi+Pm3fKkk9CywKihLZHsX38jd3dteOAZT/MtiImLGsaWh9mlEU3h0+N3hc9/xQW0fM1E9SU9O1SonmzM2OGGybyW5Z1fsTOvzcFX3eiFtLnzTKhIme4mQsZeGYq1K7an05aUb1vxu1oe86fsu3wbzyklChZ4WsanOrKR7JopUhvlXrHZ82mMqexwoEPERg79vB8W+w9555SL7tRwCEQYANAutvqIYLa8KJBFpOcCBm72aK42sz45Ap4tkhU6f/DiRuHRQU4l5SQ5cDRRybH0x6XxGWjOa7HRyV4XwOL8rqowha5/NyByzwVtLArmIrZAgMBAAECggEAGX+bVhrTj53sQ7Wm43fhtstDX1z0y3d7CJD0YjDqmH4fOhhDLy1HrtqNJTcVnigTjmcQru/ze7lolsm6unIuO50Eg1x41Kpd0yaAOIIcwYWJ+dNO9D+DC090vK0vECX9RPqtDoovLqcnyYtMId5kzggvOiStEKIAPVfKJjC5+m3NBuVRev/sNDiZTkEfI+GEeBmH/X6zcG2fqgELsZm5IXFLI52tq6OxYQZoqpDtRFsU7eN+iHxTGrojeI/Q5pTCmiETLhBmNXNuJjUy1x6ymDV+CV61Lso0UHW19EJuYUGwCE9MXInPteo3CWEq4WwlB6SeJ7owhX7+tkm7Rzw3vQKBgQDgReI8ZwuOKyDbnrMdvsOfeB8NtXjbzHPBuHF8vekXsqzuTRaD+en2XgSujDswQ0XETjDgGaVf8e+596jjJlmcyRE3W9KOWvz5ZAWWCJvTREauizIh9VYB7lwNwv/nUTGxHJMfMp8pL7B4EOBVvffsLWqb/G0VJv/ZMlt32wNDmwKBgQCmLDJNtjA5e+CmZo7/G+rLvk25QHBoLhEOK29DunSAp75dgv7Q/J4dmdn32mzKrnPNf/ddEnTJNkXtJ78ljndavX1BkS7Gkhc/QNE7wgu4r+AA2OjtFi0NkZxEdnwteRUOEzcPAHHtaYPg0YjMTM7t4x5vvPOpekAhZ390X6uUmwKBgQCTOY0QddzCEVHamk2fAzHMJ8DK8QxLzeVXkEr/xnOT2Plo3jYfoRmTX5jXNLtOLXtJKMMw+eT0HRBwFkJKC0zcfanNm3uXc+eJl72LBk+02qdDwaDBZhp13hGT/ySap1Rlngp+em69TM8dooaCAtkTs6S+jXDWZ+mgnUwqXB3CbQKBgBlzCV03etlC7JvvdxUA/IupoJOvl8eMzpXh9w9jXfZaOmBt8IKnPbwA1Q4NiL3dy+R8JbE+Y15xjnIMtUyWLhdaj/Vbu9MzipXoYmMJi+wEG4Vlsv6kd8/tLgaaMthwA9Z9AOCuS8R1dXoX/SB03vg14XJxeMvK6klzZWS4RjnjAoGBALavZvhd1FL5dX8b/MsuKaqYXNlN1JagLIZXd60gdSppBg/TGswFUgDjO7OBbPLmgTak7o08i8JFaECYV5d0K8JFY65jdnQ7xEnWJLqZe0JQ/Kn1nnEe+fjVzCunWPaq+y9Cr8aFRB+hcRwRGk44xHLpQn/HkGED+UOjHaKrVsUC</token><expire>2022-10-01</expire><limits><produce>10000</produce></limits><type>trial</type><name>Rory Clark</name><company>International English Language Testing System (IELTS)</company><email>rory.clark@ielts.org.uk</email><signature>dT0TB0dBWqGVCWdCaCtf3QUAbGV3gcfR3xFHvIsq2uX62GhSIVo7cH90/awnQANnsZNjO629uH0rZMNlMah0NycEcpfUGDUB83POqe2yiwM8sQ9S21hfJPYPAI4VedhK+BLrxVFp5MlatpW4Qs8bCmy5xuGBT+OeA0DlZ4kIsq3h+3vk0+XoPS4whJIa8oGi5rz1EbJL/JknkLeNNOE6lFr4rDmxUnU0ruWxdIxH5ksViAGt74tCzXpIy5g2WPQqXXrl+QIB237PccqvPi5AtEP5ssjmlTXOWPAK7SFpD5Yi6SIa1Cuqhdxw7tTqx6rK/KDIYzhOQ7euQS4TDhS8xHiSY8cwB4XvG7M2XiaOfNTNzknLjJ5OFqNPr+9cfkPrhwqAhwean3zw8dzX2HWQ6lnQ/w68SU5q0d1gDdd4rR8IXHVGqRpicMynwacu5MLYnYwO3kd7WrMky0VATCt7PRiJbYUTCfo+Ksf0e9dA0jJyYACkcudBkUf2+MW4zTjGzeYMKQ2cj01phD6RoFfX/atHWSeoc6/6divIo3CW2YhdXtPCyWTQcv9IzF0FMx1jYzUcvMefN3uKctL87l7BPiL5EXjnylyI3qDEy0nrYpq+MWQIgnW7zixipt7T55tqYf7iRS+HTRpK0/9pxhTGwyzKXznjEGWcPUqYMBIQb8E=</signature></dito-license>";
        final String itextDitoLicense = parameters.get(licenseSecreteProviderKey);

        return itextDitoLicense.getBytes(StandardCharsets.UTF_8);
    }

    private static class CustomSecreteManagerBasedItextLicenseProvider extends SecreteManagerBasedItextLicenseProviderBuilder {
        @Override
        public SecreteManagerBasedItextLicenseProvider build() {
            super.objectMapper = getObjectMapper();
            return super.build();
        }

        private ObjectMapper getObjectMapper() {
            //Object Mapper configuration
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule());
            objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            objectMapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
            objectMapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
            objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
            objectMapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);

            return objectMapper;
        }
    }

    @SneakyThrows
    private Map<String, String> getKeyValuePairFromSecretManager(final String secretsProviderName) {
        //Configure SecretsManager Client
        final SecretsManagerClient client = SecretsManagerClient.builder()
                .region(Region.EU_WEST_2) //TODO: Need to make region dynamic. Will pick from application properties/environment variable(env variable is the priority)
                .httpClient(UrlConnectionHttpClient.builder().build())
                .build();

        //Get the target secrete provider
        final SecretsProvider secretsProvider = ParamManager.getSecretsProvider(client);

        //Get the parameter on the target secret provider
        final String secretString = secretsProvider.get(secretsProviderName);

        final TypeReference<HashMap<String, String>> typeReference = new TypeReference<HashMap<String, String>>() {
        };

        //Convert the parameters into key/value pair and return
        return objectMapper.readValue(secretString, typeReference);
    }

}
