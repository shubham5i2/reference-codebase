package com.ielts.cmds.cre.engine.itext;

import com.ielts.cmds.cre.engine.ReportGeneratorEngine;
import com.ielts.cmds.cre.exception.ReportGenerationException;
import com.ielts.cmds.cre.model.ByteArrayGeneratorOutput;
import com.ielts.cmds.cre.model.GenerationParameters;
import com.ielts.cmds.cre.provider.itext.ClassPathItextTemplateProvider;
import com.ielts.cmds.cre.provider.itext.ItextLicenseProvider;
import com.ielts.cmds.cre.provider.itext.ItextTemplateProvider;
import com.itextpdf.dito.sdk.core.data.JsonData;
import com.itextpdf.dito.sdk.license.DitoLicense;
import com.itextpdf.dito.sdk.output.PdfProducer;
import com.itextpdf.dito.sdk.output.PdfProductionResult;
import lombok.Builder;
import lombok.NonNull;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;

import static com.ielts.cmds.cre.constant.ItextEngineConstant.PRODUCT_KEY;
import static com.ielts.cmds.cre.constant.ItextEngineConstant.TEMPLATE_NAME;

@Builder
@Slf4j
public class ItextReportGeneratorEngine implements ReportGeneratorEngine {

    @Builder.Default
    private final ItextTemplateProvider itextTemplateProvider = new ClassPathItextTemplateProvider();

    private final ItextLicenseProvider itextLicenseProvider;

    private final Map<String, File> templateFileMap = new ConcurrentHashMap<>();

    private final Map<String, Object> itextEngineConfiguration = new ConcurrentHashMap<>();

    @Override
    public ByteArrayGeneratorOutput generate(@NonNull final GenerationParameters parameters) {
        //Check if parameters met with the minimum requirements
        validateGenerationParameters(parameters);

        //Initialize the Itext DITO license if not done before
        itextEngineConfiguration.computeIfAbsent("license_initialized", key -> initializeDitoLicense(itextLicenseProvider));

        //Remaining page count checks
//        final Long remainingProducePagesEvents = PdfProducer.getRemainingProducePagesEvents();

        //Keep the remaining page count for early warning
//        itextEngineConfiguration.put("remaining_page_count", remainingProducePagesEvents);

        //If there are no pages left in the license then throw a ReportGenerationException
//        if (remainingProducePagesEvents < 1)
//            throw new ReportGenerationException("Report Can not be produced. Itext page limit exhausted.");

        //Prepare the input template file
        final File templateFile = templateFileMap.computeIfAbsent(parameters.getAdditionConfiguration().get(PRODUCT_KEY).toString(), this::getTemplateFile);

        //Prepare the output report stream with auto closable block
        try (final ByteArrayOutputStream outputReportStream = new ByteArrayOutputStream()) {
            //Execute the PDF Production process
            final PdfProductionResult pdfProductionResult = PdfProducer
                    .convertTemplateFromPackage(
                            templateFile,
                            getTemplateName(parameters),
                            outputReportStream,
                            new JsonData(parameters.getOperationData().toString())
                    );

            return ByteArrayGeneratorOutput.builder()
                    .pageCount((int) pdfProductionResult.getPageCount())
                    .data(outputReportStream.toByteArray())
                    .build();
        } catch (IOException e) {
            log.error("Report generation failed. ", e);
            throw new ReportGenerationException(e);
        }
    }

    private String getTemplateName(final GenerationParameters parameters) {
        return parameters.getAdditionConfiguration().containsKey(TEMPLATE_NAME)
                ? parameters.getAdditionConfiguration().get(TEMPLATE_NAME).toString()
                : "output";
    }

    @SneakyThrows
    private boolean initializeDitoLicense(ItextLicenseProvider licenseProvider) {
        //Initialize jvm temp file for license access
        File licenseFile = File.createTempFile("itext-dito-license", ".xml");
        log.debug("Itext license file created [{}]", licenseFile.toPath());

        //Write actual license data onto temp file
        FileUtils.writeByteArrayToFile(licenseFile, licenseProvider.getLicense());
        log.debug("Itext license file write  completed [{}]", licenseFile.toPath());

        //initialize DITO License
        DitoLicense.loadLicenseFile(licenseFile);
        log.debug("Itext license load completed [{}]", licenseFile.toPath());

        //Delete the license file
        Files.delete(licenseFile.toPath());
        log.debug("Itext license file deleted [{}]", licenseFile.toPath());

        return true;
    }

    private void validateGenerationParameters(final GenerationParameters parameters) {
        //parameters must have product key in additional config
        validate(parameters,
                arg -> arg.getAdditionConfiguration().containsKey(PRODUCT_KEY),
                "Parameter Addition Configuration must contain a 'product key'");

        //parameters must have product value in additional config
        validate(parameters,
                arg -> StringUtils.isNotBlank((CharSequence) arg.getAdditionConfiguration().get(PRODUCT_KEY)),
                "Parameter Addition Configuration must contain valid 'product value'");
    }

    private void validate(final GenerationParameters parameters,
                          final Predicate<GenerationParameters> condition,
                          final String message) {
        if (condition.negate().test(parameters))
            throw new ReportGenerationException(message);
    }

    @SneakyThrows
    private File getTemplateFile(String product) {
        File file = File.createTempFile(product, ".dito");
        file.deleteOnExit();
        log.debug("Itext Dito temp file created at[{}]", file.toPath());

        final byte[] template = itextTemplateProvider.getTemplate(product);

        FileUtils.copyToFile(new ByteArrayInputStream(template), file);
        log.debug("Itext Dito temp file write completed[{}]", file.toPath());

        return file;
    }

}
