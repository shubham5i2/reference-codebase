package com.ielts.cmds.cre.provider.itext;

public interface ItextTemplateProvider {

    byte[] getTemplate(String input);

}
