package com.ielts.cmds.cre.model.itext;

import com.ielts.cmds.cre.model.GenerationParameters;
import lombok.Builder;
import lombok.Singular;

import java.util.Map;

@Builder
public class ItextGenerationDefaultParameters implements GenerationParameters {

    private final String jsonData;

    @Singular("configuration")
    private final Map<String, Object> configurations;

    @Override
    public Object getOperationData() {
        return jsonData;
    }

    @Override
    public Map<String, Object> getAdditionConfiguration() {
        return configurations;
    }

}
