package com.ielts.cmds.cre.provider.itext;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;

import java.io.InputStream;
import java.util.Objects;

@Slf4j
public class ClassPathItextTemplateProvider implements ItextTemplateProvider {

    @Override
    @SneakyThrows
    public byte[] getTemplate(String input) {
        final ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();

        log.debug("Looking for [{}.dito] file in classpath", input);
        final InputStream inputStream = contextClassLoader.getResourceAsStream(input + ".dito");

        Objects.requireNonNull(inputStream, String.format("Can not find [%s.dito] file in classpath", input));

        final byte[] bytes = IOUtils.toByteArray(inputStream);
        inputStream.close();

        log.debug("Template file byte size {}", bytes.length);

        return bytes;
    }

}
