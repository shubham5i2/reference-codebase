package com.ielts.cmds.eor.generator;

import com.ielts.cmds.eor.model.GeneratorData;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public interface PDFGenerator {
    byte[] generatePDF(GeneratorData data) throws IOException, InvocationTargetException, IllegalAccessException, NoSuchMethodException;
}
