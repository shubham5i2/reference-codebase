package com.ielts.cmds.eor.constants;

public class LetterGenerationEngineConstants {

    public static final String TEMPLATE_NAME= "templateName";
    public static final String PDF_EXTENSION = ".pdf";
    public static final String HTML_EXTENSION = ".html";
    public static final String TEMP_FOLDER_EXTENSION = "/tmp/";
    public static final String SLASH = "/";
    public static final String UTF_8 = "UTF-8";


    private LetterGenerationEngineConstants() {
    }
}
