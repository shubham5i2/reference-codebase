package com.ielts.cmds.eor;

import com.ielts.cmds.eor.generator.PDFGenerator;

public interface ApacheLetterEngine {

    PDFGenerator getPDFType();
}
