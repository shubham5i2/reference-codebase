package com.ielts.cmds.eor.model;

public interface GeneratorData {
}
