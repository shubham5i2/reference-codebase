package com.ielts.cmds.eor.provider;

import java.io.IOException;

public interface TemplateProvider {

    byte[] getTemplate(String templateName) throws IOException;
}
