package com.ielts.cmds.eor;

import com.ielts.cmds.eor.generator.PDFGenerator;
import com.ielts.cmds.eor.generator.letter.EorLetterGenerator;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ApacheLetterGeneratorEngine implements ApacheLetterEngine {

    @Override
    public PDFGenerator getPDFType() {
            return new EorLetterGenerator();
    }
}
