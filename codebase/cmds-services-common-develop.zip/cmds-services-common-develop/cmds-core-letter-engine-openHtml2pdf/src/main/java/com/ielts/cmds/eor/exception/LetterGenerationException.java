package com.ielts.cmds.eor.exception;

public class LetterGenerationException extends RuntimeException {

    public LetterGenerationException(String message) {
        super(message);
    }

}
