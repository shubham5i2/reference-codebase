package com.ielts.cmds.eor.generator.letter;


import com.ielts.cmds.eor.builder.CommonPDFBuilder;
import com.ielts.cmds.eor.builder.PDFBuilder;
import com.ielts.cmds.eor.exception.LetterGenerationException;
import com.ielts.cmds.eor.generator.PDFGenerator;
import com.ielts.cmds.eor.model.GeneratorData;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import static com.ielts.cmds.eor.constants.LetterGenerationEngineConstants.TEMPLATE_NAME;

@Slf4j
@Builder
@NoArgsConstructor
public class EorLetterGenerator implements PDFGenerator {

    @Override
    public byte[] generatePDF(com.ielts.cmds.eor.model.GeneratorData data) {
        try {

            String templateName = BeanUtils.getProperty(data, TEMPLATE_NAME);
            PDFBuilder pdfBuilder = getBuilder(data,templateName);

            return pdfBuilder.buildPDF();
        } catch (IOException | InvocationTargetException | IllegalAccessException | NoSuchMethodException ex) {
            log.error("Exception Occurred While Generating PDF ", ex);
            throw new LetterGenerationException("PDF could not be generated");
        }
    }

    CommonPDFBuilder getBuilder(GeneratorData data, String templateName) {
        return CommonPDFBuilder.builder()
                .templateName(templateName)
                .data(data)
                .build();
    }

}
