package com.ielts.cmds.eor.builder;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public interface PDFBuilder {

    byte[] buildPDF() throws IOException, InvocationTargetException, IllegalAccessException, NoSuchMethodException;

}
