package com.ielts.cmds.eor.builder;

import com.github.jknack.handlebars.Handlebars;
import com.github.jknack.handlebars.Template;
import com.github.jknack.handlebars.io.ClassPathTemplateLoader;
import com.github.jknack.handlebars.io.TemplateLoader;
import com.ielts.cmds.eor.exception.LetterGenerationException;
import com.ielts.cmds.eor.model.GeneratorData;
import com.openhtmltopdf.pdfboxout.PdfRendererBuilder;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.jsoup.Jsoup;
import org.jsoup.helper.W3CDom;
import org.jsoup.nodes.Document;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.SecureRandom;
import java.util.Objects;

import static com.ielts.cmds.eor.constants.LetterGenerationEngineConstants.HTML_EXTENSION;
import static com.ielts.cmds.eor.constants.LetterGenerationEngineConstants.PDF_EXTENSION;
import static com.ielts.cmds.eor.constants.LetterGenerationEngineConstants.SLASH;
import static com.ielts.cmds.eor.constants.LetterGenerationEngineConstants.TEMP_FOLDER_EXTENSION;
import static com.ielts.cmds.eor.constants.LetterGenerationEngineConstants.UTF_8;

@Slf4j
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CommonPDFBuilder implements PDFBuilder {

    private static final String BASE_URL = Objects.requireNonNull(CommonPDFBuilder.class.getClassLoader().getResource("")).toString();

    GeneratorData data;

    String templateName;

    @Builder.Default
    String tempHTMLName = TEMP_FOLDER_EXTENSION + RandomStringUtils.random(5, 0, 0, true, true, null, new SecureRandom()) +
            System.currentTimeMillis() + HTML_EXTENSION;


    @Builder.Default
    String tempPDFName = TEMP_FOLDER_EXTENSION + RandomStringUtils.random(10, 0, 0, true, true, null, new SecureRandom()) +
            System.currentTimeMillis() + PDF_EXTENSION;

    @Override
    public byte[] buildPDF() throws IOException {
        File inputHtml = buildTestTakerSpecificHTML(templateName,data);
        Document document = convertHTMLtoXHTML(inputHtml);
        File file = convertXHTMLtoPDF(document);
        return fileToByteArray(file);
    }

    public File buildTestTakerSpecificHTML(String htmlFileName, GeneratorData data) throws IOException {
        String dynamicContent = getDynamicTemplateStringWithHandleBars(htmlFileName, data);
        File file = new File(tempHTMLName);
        try(FileWriter writer = new FileWriter(file)) {
            writer.write(dynamicContent);
        }
        return file;
    }

    public String getDynamicTemplateStringWithHandleBars(String htmlFileName, GeneratorData data) throws IOException {
        TemplateLoader loader = new ClassPathTemplateLoader(SLASH, HTML_EXTENSION);
        Handlebars handlebars = new Handlebars(loader);
        Template template = handlebars.compile(htmlFileName);
        return template.apply(data);
    }

    public Document convertHTMLtoXHTML(File inputHTML) throws IOException {
        Document document = Jsoup.parse(inputHTML, UTF_8);
        document.outputSettings().syntax(Document.OutputSettings.Syntax.xml);
        return document;
    }

    public File convertXHTMLtoPDF(Document document) {
        File outputPdf = new File(tempPDFName);
        log.debug("baseURL {}", BASE_URL );
        try (OutputStream os = Files.newOutputStream(outputPdf.toPath())) {
            PdfRendererBuilder builder = new PdfRendererBuilder();
            builder.withUri(tempPDFName);
            builder.toStream(os);
            builder.withW3cDocument(new W3CDom().fromJsoup(document), BASE_URL);
            builder.run();
        } catch (IOException e) {
            log.error("Document Generation failed due to "+e);
        }
        return outputPdf;
    }

    byte[] fileToByteArray(File file) throws IOException {
        try (InputStream inputStream = Files.newInputStream(file.toPath())) {
            if (file.exists()) {
                byte[] arr = new byte[(int) file.length()];
                int bytesRead = inputStream.read(arr);
                log.info("Bytes Read : {} ", bytesRead);
                return arr;
            } else {
                throw new LetterGenerationException("File not found");
            }
        } catch (IOException ioException) {
            log.error("Exception occurred while processing : ", ioException);
            throw new LetterGenerationException("PDF Process Aborted");
        } finally {
            boolean fileDeleted = Files.deleteIfExists(Paths.get(file.getAbsolutePath()));
            if (fileDeleted) {
                log.info("PDF File successfully deleted");
            } else {
                log.warn("Error in deleting PDF file");
            }
            deleteTempHtmlFile();
        }
    }

    public void deleteTempHtmlFile() throws IOException {
        boolean fileDeleted = Files.deleteIfExists(Paths.get(tempHTMLName));
        if (fileDeleted) {
            log.info("HTML File successfully deleted");
        } else {
            log.warn("Error in deleting HTML file");
        }
    }

}
