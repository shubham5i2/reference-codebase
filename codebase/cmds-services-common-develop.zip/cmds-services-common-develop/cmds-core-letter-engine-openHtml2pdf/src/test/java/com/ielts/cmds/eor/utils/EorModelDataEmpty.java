package com.ielts.cmds.eor.utils;

import com.ielts.cmds.eor.model.GeneratorData;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EorModelDataEmpty implements GeneratorData {

    private String name;

}
