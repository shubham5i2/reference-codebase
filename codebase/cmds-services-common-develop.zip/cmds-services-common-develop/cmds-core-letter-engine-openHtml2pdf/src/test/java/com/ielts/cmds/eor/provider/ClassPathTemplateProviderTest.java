package com.ielts.cmds.eor.provider;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
class ClassPathTemplateProviderTest {

    @InjectMocks
    private ClassPathTemplateProvider classPathTemplateProvider;


    @Test
    void checkPositiveFlow() {
        assertDoesNotThrow(() -> classPathTemplateProvider.getTemplate("EOR_BC_Positive.html"));
    }

    @Test
    void throwExceptionForFileNotFound() {
        assertThrows(NullPointerException.class, () -> classPathTemplateProvider.getTemplate("EOR_BC.html"));
    }

}
