package com.ielts.cmds.eor.builder;

import com.ielts.cmds.eor.model.GeneratorData;
import com.ielts.cmds.eor.provider.TemplateProvider;
import com.ielts.cmds.eor.utils.EorModelData;
import org.jsoup.nodes.Document;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.File;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class CommonPDFBuilderTest {

    @InjectMocks
    private CommonPDFBuilder commonPDFBuilder;

    @Mock
    TemplateProvider templateProvider;

    @BeforeEach
    void init(){
        ReflectionTestUtils.setField(commonPDFBuilder, "tempHTMLName", "/tmp/tempHtml.html");
        ReflectionTestUtils.setField(commonPDFBuilder,"tempPDFName","/tmp/tempPdf.pdf");
    }

    @Test
    void buildPDF_test() throws IOException {
        commonPDFBuilder = CommonPDFBuilder.builder().data(new EorModelData()).templateName("EOR_BC_Positive").build();
        byte[] pdfByte = commonPDFBuilder.buildPDF();
        assertNotNull(pdfByte);
    }

    @Test
    void buildTestTakerSpecificHTML_test() throws IOException {
        String templateName = "EOR_BC_Positive";
        GeneratorData generatorData = new EorModelData();
        File specificHtml = commonPDFBuilder.buildTestTakerSpecificHTML(templateName, generatorData);
        assertNotNull(specificHtml);
        assertEquals("tempHtml.html", specificHtml.getName());
    }

    @Test
    void getDynamicTemplateStringWithHandleBars_test() throws IOException {
        String htmlFileName = "EOR_BC_Positive";
        String expectedHtmlText = "<html><body><img src=\"avengers.jpg\"><h1> IELTS Enquiry on Results </h1><p>Name: Lalitha Jasti</br></br></p></body></html>";
        GeneratorData generatorData = new EorModelData();
        String testTakerSpecificHtmlText = commonPDFBuilder.getDynamicTemplateStringWithHandleBars(htmlFileName, generatorData);
        assertEquals(expectedHtmlText,testTakerSpecificHtmlText);
    }

    @Test
    void convertHTMLtoXHTML_test() throws IOException {
        final ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
        File htmlFile = new File(contextClassLoader.getResource("TestTakerSpecific.html").getFile());
        Document document = commonPDFBuilder.convertHTMLtoXHTML(htmlFile);
        assertNotNull(document);
        assertEquals("html",document.childNodes().get(0).nodeName());
    }

    @Test
    void convertXHTMLtoPDF_test() throws IOException {
        File htmlFile = new File("src/test/resources/TestTakerSpecific.html");
        Document document = commonPDFBuilder.convertHTMLtoXHTML(htmlFile);
        File pdf = commonPDFBuilder.convertXHTMLtoPDF(document);
        assertNotNull(pdf);
        assertEquals("tempPdf.pdf",pdf.getName());
    }

}
