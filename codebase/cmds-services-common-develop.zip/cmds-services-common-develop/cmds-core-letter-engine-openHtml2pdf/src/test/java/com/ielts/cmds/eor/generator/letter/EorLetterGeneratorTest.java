package com.ielts.cmds.eor.generator.letter;

import com.ielts.cmds.eor.exception.LetterGenerationException;
import com.ielts.cmds.eor.model.GeneratorData;
import com.ielts.cmds.eor.utils.EorModelData;
import com.ielts.cmds.eor.utils.EorModelDataEmpty;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class EorLetterGeneratorTest {

    @Spy
    @InjectMocks
    private EorLetterGenerator eorLetterGenerator;

    @Test
    void checkPositiveFlow() {

        GeneratorData generatorData = new EorModelData();
        eorLetterGenerator.generatePDF(generatorData);
        verify(eorLetterGenerator, times(1)).generatePDF(ArgumentMatchers.any());
        verify(eorLetterGenerator, times(1)).getBuilder(ArgumentMatchers.any(), ArgumentMatchers.any());
    }

    @Test
    void returnExceptionFromMethod() {
        GeneratorData generatorData = new EorModelDataEmpty();
        assertThrows(LetterGenerationException.class, () -> eorLetterGenerator.generatePDF(generatorData));
        verify(eorLetterGenerator, times(1)).generatePDF(ArgumentMatchers.any());
        verify(eorLetterGenerator, times(0)).getBuilder(ArgumentMatchers.any(), ArgumentMatchers.any());
    }

}
