package com.ielts.cmds.eor.utils;

import com.ielts.cmds.eor.model.GeneratorData;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EorModelData implements GeneratorData {

    private String name = "Lalitha Jasti";

    private String candidateNumber = "000200";

    private String testDate = "10-03-2023";

    private String testCentre = "101IH";

    private String overallScore = "8.5";

    private String templateName = "EOR_POSITIVE_BC";
}
