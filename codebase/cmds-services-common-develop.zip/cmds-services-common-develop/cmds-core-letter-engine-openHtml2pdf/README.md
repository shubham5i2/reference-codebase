# OpenHTML2PDF Library 

## Overview
OpenHTML2PDF Library helps to create new PDF documents using HTML templates

## Implementation Guidelines

### Microservice Changes

#### Add pdf box library dependency in the **pom.xml** of the respective MX 
```
	<dependency>
            <groupId>com.ielts.cmds.common</groupId>
            <artifactId>cmds-core-report-engine-oprnHtml2pdf</artifactId>
            <version>latest-version</version>
    </dependency>

```
**Note:** Please do change ***latest-version*** to actual version in pom.xml

****Steps to Generate a PDF File:****

Please follow below steps to generate a PDF file

**Step-1**: Please make sure that template file(for which you want
to generate PDF) is present in the resources folder

https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-services-common/-/tree/develop/cmds-core-report-engine-pdfbox/src/main/resources


**Step-2**: Add below dependency in POM.xml file
```
<dependency>
    <groupId>com.ielts.cmds.common</groupId>
    <artifactId>cmds-core-report-engine-openHtml2pdf</artifactId>
    <version>latest-version</version>
</dependency>

```
**Step-3**: Build *DocumentGenerationModel* data in mx as shown below

```
GeneratorData generatorData = DocumentGenerationModel.builder()
                .candidateNumber("000200")
                .familyName("SHARAD")
                .firstName("ANKUR")
                .candidateId("AB12314")
                ...
                ...
                ...
                .build();
```
**Step-4**: Once template data is build and stored in
*generatorData* then the generated PDF file is stored in byte array
format(generatorOutput[ ])

```
ApacheLetterEngine apacheLetterEngine = new ApacheLetterGeneratorEngine();

PDFGenerator pdfGenerator = apacheLetterEngine.getPDFType();

final byte[] generatorOutput = pdfGenerator.generatePDF(generatorData);
```

## Change Log

### 0.0.4
- Field name corrected

### 0.0.3
- EOR HTML templates alignment changes

### 0.0.2
- EOR HTML template discrepancies addressed

### 0.0.1
- Base Implementation of PDF document engine
