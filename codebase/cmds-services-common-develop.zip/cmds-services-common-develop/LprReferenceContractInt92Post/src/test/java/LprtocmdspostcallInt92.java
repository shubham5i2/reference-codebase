import au.com.dius.pact.consumer.Pact;
import au.com.dius.pact.consumer.PactProviderRuleMk2;
import au.com.dius.pact.consumer.PactVerification;
import au.com.dius.pact.consumer.dsl.DslPart;
import au.com.dius.pact.consumer.dsl.PactDslJsonBody;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.model.RequestResponsePact;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.junit.Rule;
import org.junit.Test;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class LprtocmdspostcallInt92  {

    public static final String providerServiceName = "CMDS-provider-Int92-POST";
    public static final String consumerServiceName = "LPR-consumer-Int92-POST";
    public static int providerServicePort = 8110;
    public static String providerUrl_POST_Reference = "http://localhost:" + providerServicePort + "/lpr/reference";
    String INT92_POST_INPUT = System.getenv("INT92_POST");
    public String postbody = new String(Files.readAllBytes(Paths.get(INT92_POST_INPUT )), StandardCharsets.UTF_8);
    public LprtocmdspostcallInt92() throws IOException {   }
    @Rule
    public PactProviderRuleMk2 provider = new PactProviderRuleMk2(providerServiceName, "localhost", providerServicePort, this);

    @Pact(consumer = consumerServiceName)
    public RequestResponsePact createPact(PactDslWithProvider builder) {
        Map<String, String> headers = new HashMap();
        headers.put("Content-Type", "application/json; charset=utf-8");

        DslPart reqBody = new PactDslJsonBody()
                .array("language")
                .object()
                .stringType("referenceId", "CMDS_ID")
                .stringType("legacyReferenceId", "45")
                .stringType("iso2Code", "IT")
                .stringType("iso3Code", "ITA")
                .stringType("referenceName", "Italian")
                .stringType("effectiveFromDate", "2020-06-16")
                .stringType("effectiveToDate", "2020-06-16")
                .closeObject()
                .closeArray()
                .array("country")
                .object()
                .stringType("referenceId", "123456")
                .stringType("legacyReferenceId", "45")
                .stringType("iso2Code", "AU")
                .stringType("iso3Code", "AUS")
                .stringType("referenceName", "Australia")
                .stringType("effectiveFromDate", "2020-06-16")
                .stringType("effectiveToDate", "2020-06-16")
                .closeObject()
                .closeArray()
                .array("nationality")
                .object()
                .stringType("referenceId", "123456")
                .stringType("legacyReferenceId", "45")
                .stringType("iso2Code", "IT")
                .stringType("iso3Code", "ITA")
                .stringType("referenceName", "Italian")
                .stringType("effectiveFromDate", "2020-06-16")
                .stringType("effectiveToDate", "2020-06-16")
                .closeObject()
                .closeArray()
                .array("educationLevel")
                .object()
                .stringType("referenceId", "CMDS_ID")
                .numberType("legacyReferenceId", 0)
                .stringType("referenceName", "Secondary up to 16 years")
                .stringType("effectiveFromDate", "2020-06-16")
                .stringType("efectiveToDate", "2020-06-16")
                .closeObject()
                .closeArray()
                .array("occupationSector")
                .object()
                .stringType("referenceId", "CMDS_ID")
                .numberType("legacyReferenceId", 0)
                .stringType("referenceName", "Administrative services")
                .stringType("effectiveFromDate", "2020-06-16")
                .stringType("efectiveToDate", "2020-06-16")
                .closeObject()
                .closeArray()
                .array("occupationLevel")
                .object()
                .stringType("referenceId", "string")
                .stringType("legacyReferenceId", "string")
                .stringType("referenceName", "string")
                .stringType("effectiveFromDate", "string")
                .stringType("efectiveToDate", "string")
                .closeObject()
                .closeArray()
                .array("reasonForTest")
                .object()
                .stringType("referenceId", "CMDS_ID")
                .numberType("legacyReferenceId", 0)
                .stringType("referenceName", "other")
                .stringType("effectiveFromDate", "2020-06-16")
                .stringType("effectiveToDate", "2020-06-16")
                .closeObject()
                .closeArray()
                .array("identityType")
                .object()
                .stringType("referenceId", "CMDS_ID")
                .stringType("legacyReferenceId", "B")
                .stringType("referenceName", "Biometric Residence Permit")
                .stringType("effectiveFromDate", "2020-06-16")
                .stringType("efectiveToDate", "2020-06-16")
                .closeObject()
                .closeArray()
                .asBody();
        DslPart resBody = new PactDslJsonBody()
                .object("locationNodes")
                .numberType("locationId", 79817239)
                .stringType("testCentreId", "AU241")
                .stringType("locationType", "Test Centre")
                .stringType("locationName", "IDP Melbourne")
                .stringType("externalLocationId", "2321312")
                .stringType("parentExternalLocationId", "string")
                .stringType("parentLocationId", "string")
                .stringType("action", "CHG")
                .stringType("requestNotes", "string")
                .object("approvedProducts")
                .stringType("authorisedBy", "pmitchel@ielts.com")
                .stringType("productId", "1234567")
                .stringType("authorisedStartDate", "2020 06 01T00,00,00.000Z")
                .stringType("suspendedDate", "2020 09 02T00,00,00.000Z")
                .stringType("action", "CHG")
                .closeObject()
                .object("contacts")
                .stringType("email", "SupportAu241@idp.com")
                .stringType("lastName", "Davies")
                .stringType("firstName", "Alan")
                .stringType("telephone", "6128288282")
                .stringType("contactType", "Test Centre Administrator")
                .stringType("action", "CHG")
                .closeObject()
                .object("addresses")
                .stringType("city", "Melbourne")
                .stringType("zipPostcode", "3000")
                .stringType("address1Line", "GPO BOX 1515")
                .stringType("stateProvince", "VIC")
                .stringType("address3Line", "string")
                .stringType("addressType", "Postal")
                .stringType("address4Line", "string")
                .stringType("address2Line", "string")
                .stringType("country3Code", "AUS")
                .stringType("action", "CHG")
                .closeObject()
                .closeObject()
                .asBody();

        return builder
                .given("Reference details posted from LPR to CMDS")
                .uponReceiving("A request to update the Reference details at CMDS")
                .method("POST")
                .headers(headers)
                .body(reqBody)
                .path("/lpr/reference")
                .willRespondWith()
                .status(202)
                .headers(headers)
                .toPact();
    }


    @Test
    @PactVerification()
    public void doTest() throws IOException {
     //   System.setProperty("pact.rootDir","../target/pacts");
        HttpPost httpPost = null;
        HttpClient httpClient = new DefaultHttpClient();
        String url=String.format(providerUrl_POST_Reference );
        System.out.println("using url: "+url);
        HttpEntity httpEntity = new StringEntity((postbody), "utf-8");
        httpPost = new HttpPost(url);
        httpPost.setHeader("Content-type", "application/json; charset=utf-8");
        httpPost.setEntity(httpEntity);
        System.out.println("postbody :" + postbody);
        HttpResponse httpResponse = httpClient.execute(httpPost);
        System.out.println("Response : "+httpResponse);
        System.out.println("Post : "+httpPost);
    }
}
