package com.ielts.cmds.common.error.reporter;

import com.ielts.cmds.common.error.categorizer.StructuredError;

public interface IErrorReporter {

	public boolean report(StructuredError error) ;
}
