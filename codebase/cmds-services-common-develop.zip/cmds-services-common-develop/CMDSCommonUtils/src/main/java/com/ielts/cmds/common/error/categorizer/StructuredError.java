package com.ielts.cmds.common.error.categorizer;

public class StructuredError {
	private ErrorCategory category; 
	private String errorMessage;
	private String rootErrorMessage;
	private String errorOwner;
	private String healthcheckUrl;
	private Throwable thrownException;
	private String rootExceptionClass;
	private ErrorNature errorNature;
	private int errorCountThreshold;
    private int openDuration;
    
    
	public int getErrorCountThreshold() {
		return errorCountThreshold;
	}
	public StructuredError errorCountThreshold(int errorCountThreshold) {
		this.errorCountThreshold = errorCountThreshold;		
		return this;
	}
	public int getOpenDuration() {
		return openDuration;
	}
	public StructuredError openDuration(int openDuration) {
		this.openDuration = openDuration;		
		return this;
	}
	public ErrorCategory getCategory() {
		return category;
	}
	public StructuredError category(ErrorCategory category) {
		this.category = category;
		return this;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public StructuredError errorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
		return this;
	}
	public String getErrorOwner() {
		return errorOwner;
	}
	public StructuredError errorOwner(String errorOwner) {
		this.errorOwner = errorOwner;
		return this;
	}
	public Throwable getThrownException() {
		return thrownException;
	}
	public StructuredError thrownException(Throwable thrownException) {
		this.thrownException = thrownException;
		return this;
	}
	public String getRootExceptionClass() {
		return rootExceptionClass;
	}
	public StructuredError rootExceptionClass(String rootExceptionClass) {
		this.rootExceptionClass = rootExceptionClass;
		return this;
	}
	public ErrorNature getErrorNature() {
		return errorNature;
	}
	public StructuredError errorNature(ErrorNature errorNature) {
		this.errorNature = errorNature;
		return this;
	}
	
	@Override
	public String toString() {
		return "StructuredError [category=" + category + ", errorMessage=" + errorMessage + ", rootErrorMessage="
				+ rootErrorMessage + ", errorOwner=" + errorOwner + ", thrownException=" + thrownException
				+ ", rootExceptionClass=" + rootExceptionClass + ", errorNature=" + errorNature
				+ ", errorCountThreshold=" + errorCountThreshold + ", openDuration=" + openDuration + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((category == null) ? 0 : category.hashCode());
		result = prime * result + ((errorMessage == null) ? 0 : errorMessage.hashCode());
		result = prime * result + ((errorNature == null) ? 0 : errorNature.hashCode());
		result = prime * result + ((rootExceptionClass == null) ? 0 : rootExceptionClass.hashCode());
		result = prime * result + ((thrownException == null) ? 0 : thrownException.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StructuredError other = (StructuredError) obj;
		if (category != other.category)
			return false;
		if (errorMessage == null) {
			if (other.errorMessage != null)
				return false;
		} else if (!errorMessage.equals(other.errorMessage))
			return false;
		if (errorNature != other.errorNature)
			return false;
		if (rootExceptionClass == null) {
			if (other.rootExceptionClass != null)
				return false;
		} else if (!rootExceptionClass.equals(other.rootExceptionClass))
			return false;
		if (thrownException == null) {
			if (other.thrownException != null)
				return false;
		} else if (!thrownException.equals(other.thrownException))
			return false;
		return true;
	}
	public String getRootErrorMessage() {
		return rootErrorMessage;
	}
	public StructuredError rootErrorMessage(String rootErrorMessage) {
		this.rootErrorMessage = rootErrorMessage;
		return this;
	}
	public String getHealthcheckUrl() {
		return healthcheckUrl;
	}
	public StructuredError healthcheckUrl(String healthcheckUrl) {
		this.healthcheckUrl = healthcheckUrl;
		return this;
	}
	
	
}
