package com.ielts.cmds.common.persistence.utils;

import static com.ielts.cmds.common.constants.CMDSConstants.ISO_DATE_TIME;
import static com.ielts.cmds.common.constants.CMDSConstants.LOCAL_DATE;
import static com.ielts.cmds.common.constants.CMDSConstants.LOCAL_OFFSET;
import static com.ielts.cmds.common.constants.CMDSConstants.UTC_DATE_TIME;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Date;
import java.util.Objects;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.type.DateType;
import org.hibernate.type.StringType;
import org.hibernate.type.TimestampType;
import org.hibernate.type.Type;
import org.hibernate.usertype.CompositeUserType;

public class CMDSOffsetDatetimeType implements CompositeUserType {

  @Override
  public String[] getPropertyNames() {
    return new String[] {ISO_DATE_TIME, LOCAL_DATE, LOCAL_OFFSET, UTC_DATE_TIME};
  }

  @Override
  public Type[] getPropertyTypes() {
    return new Type[] {
      StringType.INSTANCE, DateType.INSTANCE, StringType.INSTANCE, TimestampType.INSTANCE
    };
  }

  @Override
  public Object getPropertyValue(Object component, int property) throws HibernateException {
    if (component == null) {
      return null;
    }

    final CMDSOffsetDatetime cmdsOffsetDatetime = (CMDSOffsetDatetime) component;
    switch (property) {
      case 0:
        {
          return cmdsOffsetDatetime.getIsoDateTime();
        }
      case 1:
        {
          return cmdsOffsetDatetime.getLocalDate();
        }
      case 2:
        {
          return cmdsOffsetDatetime.getLocalOffset();
        }
      case 3:
        {
          return cmdsOffsetDatetime.getUtcDateTime();
        }
      default:
        {
          throw new HibernateException("Invalid property index [" + property + "]");
        }
    }
  }

  @Override
  public void setPropertyValue(Object component, int property, Object value)
      throws HibernateException {
    if (component == null) {
      return;
    }

    final CMDSOffsetDatetime cmdsOffsetDatetime = (CMDSOffsetDatetime) component;
    switch (property) {
      case 0:
        {
          cmdsOffsetDatetime.setIsoDateTime((String) value);
          break;
        }
      case 1:
        {
          cmdsOffsetDatetime.setLocalDate((LocalDate) value);
          break;
        }
      case 2:
        {
          cmdsOffsetDatetime.setLocalOffset((String) value);
          break;
        }
      case 3:
        {
          cmdsOffsetDatetime.setUtcDateTime((OffsetDateTime) value);
          break;
        }
      default:
        {
          throw new HibernateException("Invalid property index [" + property + "]");
        }
    }
  }

  @Override
  public Class returnedClass() {
    return CMDSOffsetDatetime.class;
  }

  @Override
  public Object nullSafeGet(
      ResultSet rs, String[] names, SharedSessionContractImplementor session, Object owner)
      throws HibernateException, SQLException {
    assert names.length == 4;
    String isoDateTime =
        (String) StringType.INSTANCE.get(rs, names[0], session); // already handles null check
    LocalDate localDate =
        (LocalDate) StringType.INSTANCE.get(rs, names[1], session); // already handles null check
    String localOffset =
        (String) StringType.INSTANCE.get(rs, names[2], session); // already handles null check
    OffsetDateTime utcDatetime =
        (OffsetDateTime)
            StringType.INSTANCE.get(rs, names[3], session); // already handles null check
    return isoDateTime == null && localDate == null && localOffset == null && utcDatetime == null
        ? new CMDSOffsetDatetime(null)
        : new CMDSOffsetDatetime(isoDateTime, localDate, localOffset, utcDatetime);
  }

  @Override
  public void nullSafeSet(
      PreparedStatement st, Object value, int index, SharedSessionContractImplementor session)
      throws HibernateException, SQLException {
    if (value == null) {
      StringType.INSTANCE.set(st, null, index, session);
      DateType.INSTANCE.set(st, null, index + 1, session);
      StringType.INSTANCE.set(st, null, index + 2, session);
      TimestampType.INSTANCE.set(st, null, index + 3, session);
    } else {
      final CMDSOffsetDatetime cmdsOffsetDatetime = (CMDSOffsetDatetime) value;
      StringType.INSTANCE.set(st, cmdsOffsetDatetime.getIsoDateTime(), index, session);
      DateType.INSTANCE.set(
          st,
          new Date(
              cmdsOffsetDatetime
                  .getLocalDate()
                  .atStartOfDay(ZoneOffset.of(cmdsOffsetDatetime.getLocalOffset()))
                  .toInstant()
                  .toEpochMilli()),
          index + 1,
          session);
      StringType.INSTANCE.set(st, cmdsOffsetDatetime.getLocalOffset(), index + 2, session);
      TimestampType.INSTANCE.set(
          st,
          new Date(cmdsOffsetDatetime.getUtcDateTime().toInstant().toEpochMilli()),
          index + 3,
          session);
    }
  }

  @Override
  public boolean equals(Object x, Object y) throws HibernateException {
    final CMDSOffsetDatetime cmdsOffsetDatetime1 = (CMDSOffsetDatetime) x;
    final CMDSOffsetDatetime cmdsOffsetDatetime2 = (CMDSOffsetDatetime) y;
    if (Objects.nonNull(cmdsOffsetDatetime1) && Objects.nonNull(cmdsOffsetDatetime2)) {
      return cmdsOffsetDatetime1.equals(cmdsOffsetDatetime2);
    } else {
      return false;
    }
  }

  @Override
  public int hashCode(Object x) throws HibernateException {
    return super.hashCode();
  }

  @Override
  public Object deepCopy(Object value) throws HibernateException {
    final CMDSOffsetDatetime cmdsOffsetDatetime = (CMDSOffsetDatetime) value;
    CMDSOffsetDatetime newCmdsOffsetDatetime =
        new CMDSOffsetDatetime(cmdsOffsetDatetime.getOffsetDatetime());
    return newCmdsOffsetDatetime;
  }

  @Override
  public boolean isMutable() {
    return false;
  }

  @Override
  public Serializable disassemble(Object value, SharedSessionContractImplementor session)
      throws HibernateException {
    return null;
  }

  @Override
  public Object assemble(
      Serializable cached, SharedSessionContractImplementor session, Object owner)
      throws HibernateException {
    return null;
  }

  @Override
  public Object replace(
      Object original, Object target, SharedSessionContractImplementor session, Object owner)
      throws HibernateException {
    return original;
  }
}
