package com.ielts.cmds.common.config.s3;


import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.ielts.cmds.common.constants.CMDSConstants;

public class DefaultS3ClientConfiguration implements S3ClientConfiguration {

    private final String region= System.getenv(CMDSConstants.REGION);

    @Override
    public AmazonS3 getS3Client() {
        return AmazonS3ClientBuilder.standard()
                .withCredentials(new DefaultAWSCredentialsProviderChain())
                .withRegion(region)
                .build();
    }

}
