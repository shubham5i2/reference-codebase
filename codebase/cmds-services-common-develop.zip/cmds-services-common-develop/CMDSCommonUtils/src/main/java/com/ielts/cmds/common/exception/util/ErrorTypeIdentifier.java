package com.ielts.cmds.common.exception.util;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.ielts.cmds.common.constants.CMDSConstants;
import com.ielts.cmds.common.enums.ErrorTypeEnum;

public class ErrorTypeIdentifier {

  private ErrorTypeIdentifier() {}

  private static final Map<Character, ErrorTypeEnum> errorTypeMap;

  static {
    Map<Character, ErrorTypeEnum> errorTypeIdentifierMap = new HashMap<>();
    errorTypeIdentifierMap.put(CMDSConstants.CHAR_V, ErrorTypeEnum.VALIDATION);
    errorTypeIdentifierMap.put(CMDSConstants.CHAR_W, ErrorTypeEnum.WARNING);
    errorTypeIdentifierMap.put(CMDSConstants.CHAR_E, ErrorTypeEnum.ERROR);
    errorTypeMap = Collections.unmodifiableMap(errorTypeIdentifierMap);
  }

  public static ErrorTypeEnum getErrorTypeFromErrorCode(char code) {
    return errorTypeMap.get(code);
  }
}
