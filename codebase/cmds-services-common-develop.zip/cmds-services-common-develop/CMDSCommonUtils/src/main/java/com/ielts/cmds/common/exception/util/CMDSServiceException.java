package com.ielts.cmds.common.exception.util;

/**
 * 
 * Custom CDMS Service exception that will be 
 * extended by other custom exceptions in the CMDS services
 *  
 */
public class CMDSServiceException extends Exception{

	private static final long serialVersionUID = 1L;

	public CMDSServiceException() {
		super();
	}

	public CMDSServiceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public CMDSServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	public CMDSServiceException(String message) {
		super(message);
	}

	public CMDSServiceException(Throwable cause) {
		super(cause);
	}

}
