package com.ielts.cmds.common.config.s3;

import software.amazon.awssdk.services.s3.presigner.S3Presigner;

public interface S3PresignerConfiguration {

    S3Presigner getS3Presigner();

}
