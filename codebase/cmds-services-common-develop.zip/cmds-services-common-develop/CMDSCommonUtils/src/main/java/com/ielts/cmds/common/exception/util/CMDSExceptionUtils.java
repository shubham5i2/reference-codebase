package com.ielts.cmds.common.exception.util;

import java.util.List;

/** Common utility class used for populating error response */
public class CMDSExceptionUtils {

  private CMDSExceptionUtils() {}
  /**
   * Method to be called from services to populate CMDS Error Description in case of exceptions
   *
   * @param errorDescription
   * @param pointer
   * @param model
   * @return
   */
  public static ErrorDescription populateSourceInformation(
      final ErrorDescription errorDescription, final String pathValue, final String value) {

    final Source source = Source.builder().path(pathValue).value(value).build();

    errorDescription.setSource(source);

    return errorDescription;
  }

  /**
   * Method to populate Error Response from error list
   *
   * @param errorDescList
   * @return
   */
  public static CMDSErrorResponse populateCMDSErrorResponse(
      final List<ErrorDescription> errorDescList) {
    return CMDSErrorResponse.builder().errorList(errorDescList).build();
  }
}
