package com.ielts.cmds.common.logger.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CMDSLambdaLoggerPrefixLevel {
	private String loggerPrefix;
	private String logLevel;
}
