package com.ielts.cmds.common.logger.util;

import java.util.Map;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.ThreadContext;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.config.AppenderRef;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.config.LoggerConfig;

import com.ielts.cmds.common.constants.CMDSConstants;
import com.ielts.cmds.common.logger.model.CMDSLambdaLoggerConfig;
import com.ielts.cmds.common.logger.model.CMDSLambdaLoggerPrefixLevel;

import lombok.extern.slf4j.Slf4j;

/**
 * Common utility class for logger that is used to initialise and clean up Thread context field
 * values
 */
public class CMDSLambdaLoggerUtil {

  /**
   * Common method used to initialise Thread context parameters for logger
   *
   * @param transactionId
   * @param appName
   * @param reqId
   */
  public void initializeThreadContextMap(String transactionId, String appName, String reqId) {
    clearThreadContextMap();
    ThreadContext.put(CMDSConstants.TRANSACTION_ID, transactionId);
    ThreadContext.put(CMDSConstants.REQUEST_ID, reqId);
    ThreadContext.put(CMDSConstants.APPLICATION_NAME, appName);
  }
  /**
   * Common method used to initialise MDC context parameters for logger
   *
   * @param transactionId
   * @param appName
   * @param reqId
   */
  public void initializeThreadContextMap(
      String transactionId, String appName, String reqId, Map<String, String> eventContext) {
    clearThreadContextMap();
    ThreadContext.put(CMDSConstants.TRANSACTION_ID, transactionId);
    ThreadContext.put(CMDSConstants.REQUEST_ID, reqId);
    ThreadContext.put(CMDSConstants.APPLICATION_NAME, appName);
    ThreadContext.put(CMDSConstants.EVENT_CONTEXT, String.valueOf(eventContext));
  }

  /** Method used for clearing the Thread context parameters */
  public void clearThreadContextMap() {
    ThreadContext.clearMap();
  }

  /**
   * Method to programmatically configure loggers for lambda
   *
   * @param cmdsLambdaLoggerConfigList (List of Logger Prefix/Log Level)
   */
  public void configureLogger(final CMDSLambdaLoggerConfig cmdsLambdaLoggerConfig) {
		LoggerContext ctx = (LoggerContext) LogManager.getContext(false);
		Configuration config = ctx.getConfiguration();
    cmdsLambdaLoggerConfig
        .getLoggerPrefixLevel()
        .forEach(loggerConfig -> setLogger(config, loggerConfig));
	ctx.updateLoggers(config);
  }

  /**
   * Method to set log level based on prefix, level
   *
   * @param config
   * @param prefix
   * @param level
   */
  private void setLogger(
      final Configuration config, final CMDSLambdaLoggerPrefixLevel loggerPrefixLevel) {
	AppenderRef ref = AppenderRef.createAppenderRef("STDOUT", null, null);
    AppenderRef[] refs = new AppenderRef[] {ref};
    LoggerConfig loggerConfig =
        LoggerConfig.createLogger(
            false,
            Level.getLevel(loggerPrefixLevel.getLogLevel()),
            loggerPrefixLevel.getLoggerPrefix(),
            "true",
            refs,
            null,
            config,
            null);
    loggerConfig.addAppender(
        config.getAppenders().get("STDOUT"), Level.getLevel(loggerPrefixLevel.getLogLevel().toUpperCase()), null);
    config.addLogger(loggerPrefixLevel.getLoggerPrefix(), loggerConfig);
  }
}
