package com.ielts.cmds.common.logger.model;

import static com.ielts.cmds.common.constants.CMDSConstants.LOGGER_PREFIX;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import lombok.Data;

/**
 * Extracting all the logging env. variables.
 *	Replacing _ with . all the logging env. variables.
 */
@Data
public class CMDSLambdaLoggerConfig {

	private List<CMDSLambdaLoggerPrefixLevel> loggerPrefixLevel;

	public void setLoggerPrefixLevel(Map<String, String> envVariables) {
		final List<CMDSLambdaLoggerPrefixLevel> cmdsLambdaLoggerPrefixLevels = new ArrayList<>();
		envVariables.forEach((envKey, envValue) -> {
			if(envKey.startsWith(LOGGER_PREFIX)) {
				final String logPrefix = envKey.replaceFirst(LOGGER_PREFIX, "");
				final String logPrefixInRequiredFormat = logPrefix.replaceAll("_", ".");
				final CMDSLambdaLoggerPrefixLevel loggerPrefixLevel = CMDSLambdaLoggerPrefixLevel.builder()
						.loggerPrefix(logPrefixInRequiredFormat)
						.logLevel(envValue)
						.build();
				cmdsLambdaLoggerPrefixLevels.add(loggerPrefixLevel);
			}
		});
		this.loggerPrefixLevel = cmdsLambdaLoggerPrefixLevels;
	}
}