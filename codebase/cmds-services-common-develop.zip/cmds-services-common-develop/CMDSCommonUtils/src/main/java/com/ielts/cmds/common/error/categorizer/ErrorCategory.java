package com.ielts.cmds.common.error.categorizer;

public enum ErrorCategory {
	TRANSIENT("TRANSIENT"),INTRANSIENT("INTRANSIENT");
	
	private String value;
	
	ErrorCategory(String value) {
	    this.value = value;
	  }

	  public String getValue() {
	    return value;
	  }

	  @Override
	  public String toString() {
	    return String.valueOf(value);
	  }
}
