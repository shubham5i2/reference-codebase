package com.ielts.cmds.common.utils.s3;

import java.io.File;
import java.net.URL;

import com.amazonaws.services.s3.model.DeleteObjectsResult;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.services.s3.model.S3Object;

public interface CMDSS3Client {

  S3Object getObject(final String bucketName, final String objectName);

  PutObjectResult uploadObject(
      final String bucketName, final String objectName, final File fileContent);

  boolean doesObjectExist(final String bucketName, final String objectName);

  URL getPresignUrl(final String bucketName, final String objectName, final int timeOutInSecond);

  DeleteObjectsResult deleteAllObjects(final String bucketName, final String prefix);

  void deleteObject(final String bucketName, final String objectName);

  boolean doesBucketExist(String bucketName);
}
