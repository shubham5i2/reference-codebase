package com.ielts.cmds.common.error.categorizer;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.configuration2.Configuration;
import org.apache.commons.configuration2.FileBasedConfiguration;
import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.FileBasedConfigurationBuilder;
import org.apache.commons.configuration2.builder.fluent.Parameters;
import org.apache.commons.configuration2.ex.ConfigurationException;

public class ErrorConfigLoader {
	
	private final static String TRANSIENT_ERRORS= "transientErrors";
	private final static String INTRANSIENT_ERRORS= "intransientErrors";
	private final static String DEFAULT_CATEGORY= "defaultErrorCategory";
	private final static String DEFAULT_THRESHOLD= "defaultThreshold";
	private final static String DEFAULT_CB_TIMEOUT= "defaultCBTimeout";
	
	private static Configuration config = null;
	static {
		Parameters params = new Parameters();
		FileBasedConfigurationBuilder<FileBasedConfiguration> builder =
		    new FileBasedConfigurationBuilder<FileBasedConfiguration>(PropertiesConfiguration.class)
		    .configure(params.properties().setFileName("errorConfig.properties"));
		
		try {
			config = builder.getConfiguration();
		} catch (ConfigurationException e) {
			e.printStackTrace();
		}
	
	}
	
	public static List<String> getTransientErrors() {
		return Arrays.asList(config.getStringArray(TRANSIENT_ERRORS));
	}
	
	public static List<String> getIntransientErrors() {
		return Arrays.asList(config.getStringArray(INTRANSIENT_ERRORS));
	}
	
	public static String getDefaultErrorCategory() {
		return config.getString(DEFAULT_CATEGORY);
	}
	
	public static String getDefaultThreshold() {
		return config.getString(DEFAULT_THRESHOLD);
	}
	
	public static String getDefaultCBTimeout() {
		return config.getString(DEFAULT_CB_TIMEOUT);
	}
}
