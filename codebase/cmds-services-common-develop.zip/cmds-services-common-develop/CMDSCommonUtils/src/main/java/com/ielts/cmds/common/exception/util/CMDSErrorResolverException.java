package com.ielts.cmds.common.exception.util;

/**
 * Custom CDMS Service exception that will be extended by other custom exceptions in the CMDS
 * services
 */
public class CMDSErrorResolverException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public CMDSErrorResolverException() {
    super();
  }

  public CMDSErrorResolverException(
      String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }

  public CMDSErrorResolverException(String message, Throwable cause) {
    super(message, cause);
  }

  public CMDSErrorResolverException(String message) {
    super(message);
  }

  public CMDSErrorResolverException(Throwable cause) {
    super(cause);
  }
}
