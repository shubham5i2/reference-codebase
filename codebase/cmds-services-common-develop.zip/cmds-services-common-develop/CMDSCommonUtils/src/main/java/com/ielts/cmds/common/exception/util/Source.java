package com.ielts.cmds.common.exception.util;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

/** POJO class to populate source fields and parameters in the CMDS Error response */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode
@Builder
@ToString
public class Source {
  private String path;
  private String value;
}
