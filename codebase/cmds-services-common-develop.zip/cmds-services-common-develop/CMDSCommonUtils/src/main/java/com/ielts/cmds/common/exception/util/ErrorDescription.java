package com.ielts.cmds.common.exception.util;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ielts.cmds.common.enums.ErrorTypeEnum;

import lombok.Data;

/** POJO class used to populate description of Error response */
@Data
public class ErrorDescription {

  @JsonProperty("interface")
  private String interfaceName;

  private ErrorTypeEnum type;
  private String errorCode;
  private UUID errorTicketUuid;
  private Source source;
  private String title;
  private String message;

  public ErrorDescription() {
    this.errorTicketUuid = UUID.randomUUID();
  }
}
