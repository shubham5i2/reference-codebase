package com.ielts.cmds.common.error.categorizer;

import com.ielts.cmds.common.enums.ErrorTypeEnum;

public enum ErrorNature {
	NETWORK("NETWORK"),
	  AVAILABILITY("AVAILABILITY"), PERMISSION("PERMISSION"),
	  TIMEOUT("TIMEOUT"),
	  CLIENT("CLIENT"),
	  SERVER("SERVER"),
	  BUSINESS("BUSINESS");

	  private String value;

	  ErrorNature(String value) {
	    this.value = value;
	  }

	  public String getValue() {
	    return value;
	  }

	  @Override
	  public String toString() {
	    return String.valueOf(value);
	  }

	  public static ErrorNature fromValue(String text) {
	    for (ErrorNature f : ErrorNature.values()) {
	      if (String.valueOf(f.value).equals(text)) {
	        return f;
	      }
	    }
	    return null;
	  }
}
