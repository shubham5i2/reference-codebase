package com.ielts.cmds.common.exception.util;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.validation.ConstraintViolation;

import org.apache.commons.beanutils.BeanUtils;

import com.ielts.cmds.common.constants.CMDSConstants;
import com.ielts.cmds.common.enums.ErrorTypeEnum;

import lombok.Getter;

@Getter
public class CMDSErrorResolver<T> {

  private Map<String, String> errorCodeMapper;

  public CMDSErrorResolver(Map<String, String> errorCodeMapper) {
    this.errorCodeMapper = Collections.unmodifiableMap(errorCodeMapper);
  }

  public CMDSErrorResponse populatErrorResponse(
      final Set<ConstraintViolation<T>> cmdsViolations, final String interfaceName) {
    final List<ErrorDescription> errorDescList = new ArrayList<>();
    cmdsViolations.forEach(
        violation -> errorDescList.add(getErrorDescription(violation, interfaceName)));
    return CMDSExceptionUtils.populateCMDSErrorResponse(errorDescList);
  }

  private ErrorDescription getErrorDescription(
      final ConstraintViolation<T> violation, final String interfaceName) {

    final String errorCode = violation.getMessage();
    String fieldValue = "";
    final ErrorTypeEnum type = ErrorTypeIdentifier.getErrorTypeFromErrorCode(errorCode.charAt(0));
    final String propertyPath = violation.getPropertyPath().toString();
    final String titleKey = errorCode + CMDSConstants.TITLE;

    ErrorDescription errorDescription = new ErrorDescription();
    errorDescription.setInterfaceName(interfaceName);
    errorDescription.setErrorCode(errorCode);
    errorDescription.setType(type);
    errorDescription.setMessage(errorCodeMapper.get(errorCode));
    errorDescription.setTitle(errorCodeMapper.get(titleKey));

    if (Objects.nonNull(violation.getRootBean())
        && null != propertyPath
        && !propertyPath.contains(CMDSConstants.COMMA_SEPARATED)) {
      try {
        fieldValue = BeanUtils.getNestedProperty(violation.getRootBean(), propertyPath);
      } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException exp) {
        throw new CMDSErrorResolverException(
            String.format("Exception occurred while populating error response : %s", exp));
      }
    }
    errorDescription =
        CMDSExceptionUtils.populateSourceInformation(errorDescription, propertyPath, fieldValue);
    return errorDescription;
  }
}
