package com.ielts.cmds.common.config.s3;

import com.amazonaws.services.s3.AmazonS3;

public interface S3ClientConfiguration {

    AmazonS3 getS3Client();

}
