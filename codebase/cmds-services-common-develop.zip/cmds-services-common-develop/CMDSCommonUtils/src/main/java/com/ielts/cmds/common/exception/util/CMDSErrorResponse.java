package com.ielts.cmds.common.exception.util;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

/** Class used to return list of errors and its description to other application */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode
@Builder
@ToString
public class CMDSErrorResponse {

  private List<ErrorDescription> errorList;
}
