package com.ielts.cmds.common.config.s3;

import com.ielts.cmds.common.constants.CMDSConstants;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.presigner.S3Presigner;

public class DefaultS3PresignerConfiguration implements S3PresignerConfiguration {

    private final String region= System.getenv(CMDSConstants.REGION);

    @Override
    public S3Presigner getS3Presigner() {

        return S3Presigner.builder()
                .region(Region.of(region))
                .build();
    }

}
