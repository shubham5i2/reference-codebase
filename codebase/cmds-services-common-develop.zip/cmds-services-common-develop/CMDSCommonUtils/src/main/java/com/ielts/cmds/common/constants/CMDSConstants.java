package com.ielts.cmds.common.constants;

/** Class used to declare Common CMDS constants */
public class CMDSConstants {

  public static final String PROCESS_ID = "Process id";
  public static final String EVENT_CONTEXT = "Event Context";

  private CMDSConstants() {}

  public static final String APPLICATION_NAME = "Application name";
  public static final String REQUEST_ID = "Request id";
  public static final String TRANSACTION_ID = "Transaction id";

  public static final char CHAR_V = 'V';
  public static final char CHAR_W = 'W';
  public static final char CHAR_E = 'E';
  public static final String COMMA_SEPARATED = ",";
  public static final String TITLE = ".title";
  public static final String TOKEN_BEARER = "Bearer ";
  public static final String LOGGER_PREFIX = "logging_";

  public static final String REGION = "AWS_REGION";

  // Circuit Breaker Related constants
  public static final String CB_ENV_VAR_THRESHOLD = "cb_threshold";
  public static final String CB_ENV_VAR_LAMBDA_ARN = "lambda_name";
  public static final String CB_ENV_VAR_TIMEOUT = "cb_timeout";
  public static final String CB_ENV_VAR_ENVIRONMENT = "environment";
  public static final String CB_ENV_PROP_LAMBDA = "lambda.function.name";
  public static final String CB_ENV_HEALTHCHECK_URL = "server_healthcheck_url";

  // Persistence Related constants
  public static final String ISO_DATE_TIME = "iso_date_time";
  public static final String LOCAL_DATE = "local_date";
  public static final String LOCAL_OFFSET = "local_offset";
  public static final String UTC_DATE_TIME = "utc_date_time";
}
