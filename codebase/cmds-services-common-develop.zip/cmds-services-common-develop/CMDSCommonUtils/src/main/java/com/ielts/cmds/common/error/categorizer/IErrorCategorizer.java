package com.ielts.cmds.common.error.categorizer;

public interface IErrorCategorizer {

	public StructuredError categorize(Throwable e) ;
}
