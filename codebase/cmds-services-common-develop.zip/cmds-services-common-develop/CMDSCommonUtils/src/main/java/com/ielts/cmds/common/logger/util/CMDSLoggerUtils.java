package com.ielts.cmds.common.logger.util;

import java.util.Map;
import java.util.UUID;

import org.slf4j.MDC;

import com.ielts.cmds.common.constants.CMDSConstants;

/**
 * 
 * Common utility class for logger that is used to initialise and clean up MDC context field values
 *
 */
public class CMDSLoggerUtils {
	
	/**
	 * Common method used to initialise MDC context parameters for logger
	 * @param transactionId
	 * @param appName
	 * @param reqId
	 */
	public void initializeMDCContext(String transactionId, String appName, String reqId) {
		clearMDCContext();
		MDC.put(CMDSConstants.TRANSACTION_ID,transactionId );
		MDC.put(CMDSConstants.REQUEST_ID,reqId);
		MDC.put(CMDSConstants.APPLICATION_NAME, appName);
		MDC.put(CMDSConstants.PROCESS_ID, UUID.randomUUID().toString());
	}

	/**
	 * Common method used to initialise MDC context parameters for logger
	 * @param transactionId
	 * @param appName
	 * @param reqId
	 */

	public void initializeMDCContext(String transactionId, String appName, String reqId, Map<String, String> eventContext) {
		clearMDCContext();
		MDC.put(CMDSConstants.TRANSACTION_ID,transactionId );
		MDC.put(CMDSConstants.REQUEST_ID,reqId);
		MDC.put(CMDSConstants.APPLICATION_NAME, appName);
		MDC.put(CMDSConstants.PROCESS_ID, UUID.randomUUID().toString());
		if(eventContext != null) {
			for (Object key : eventContext.keySet()) {
				MDC.put(key.toString(), String.valueOf(eventContext.get(key)));
			}
		}
	}
	
	/**
	 * Method used for clearing the MDC context parameters
	 */
	public void clearMDCContext() {
		MDC.clear();
	}

}
