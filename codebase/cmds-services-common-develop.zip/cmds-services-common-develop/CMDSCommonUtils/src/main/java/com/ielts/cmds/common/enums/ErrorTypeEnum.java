package com.ielts.cmds.common.enums;

public enum ErrorTypeEnum {
  VALIDATION("VALIDATION"),
  WARNING("WARNING"),
  ERROR("ERROR");

  private String value;

  ErrorTypeEnum(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }

  @Override
  public String toString() {
    return String.valueOf(value);
  }

  public static ErrorTypeEnum fromValue(String text) {
    for (ErrorTypeEnum f : ErrorTypeEnum.values()) {
      if (String.valueOf(f.value).equals(text)) {
        return f;
      }
    }
    return null;
  }
}
