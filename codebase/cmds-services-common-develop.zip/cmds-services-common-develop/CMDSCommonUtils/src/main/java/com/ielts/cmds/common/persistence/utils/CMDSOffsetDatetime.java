package com.ielts.cmds.common.persistence.utils;

import static com.ielts.cmds.common.constants.CMDSConstants.ISO_DATE_TIME;
import static com.ielts.cmds.common.constants.CMDSConstants.LOCAL_DATE;
import static com.ielts.cmds.common.constants.CMDSConstants.LOCAL_OFFSET;
import static com.ielts.cmds.common.constants.CMDSConstants.UTC_DATE_TIME;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class CMDSOffsetDatetime {

  public CMDSOffsetDatetime(OffsetDateTime datetime) {
    setOffsetDateTime(datetime);
  }

  @Column(name = ISO_DATE_TIME)
  String isoDateTime;

  @Column(name = LOCAL_DATE)
  LocalDate localDate;

  @Column(name = LOCAL_OFFSET)
  String localOffset;

  @Column(name = UTC_DATE_TIME)
  OffsetDateTime utcDateTime;

  public OffsetDateTime getOffsetDatetime() {
    return utcDateTime;
  }

  private void setOffsetDateTime(OffsetDateTime datetime) {
    if (Objects.nonNull(datetime)) {
      setIsoDateTime(datetime.format(DateTimeFormatter.ISO_DATE_TIME));
      setLocalDate(datetime.toLocalDate());
      setLocalOffset(datetime.getOffset().toString());
      setUtcDateTime(datetime);
    }
  }
}
