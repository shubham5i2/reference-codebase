package com.ielts.cmds.common.utils.s3;

import java.io.File;
import java.net.URL;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Objects;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.DeleteObjectsRequest;
import com.amazonaws.services.s3.model.DeleteObjectsRequest.KeyVersion;
import com.amazonaws.services.s3.model.DeleteObjectsResult;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.ielts.cmds.common.config.s3.S3ClientConfiguration;
import com.ielts.cmds.common.config.s3.S3PresignerConfiguration;

import lombok.Builder;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.presigner.model.GetObjectPresignRequest;
import software.amazon.awssdk.services.s3.presigner.model.PresignedGetObjectRequest;

@Slf4j
@Builder
public class DefaultCMDSS3Client implements CMDSS3Client {

  S3ClientConfiguration s3ClientConfiguration;

  S3PresignerConfiguration s3PresignerConfiguration;

  public DefaultCMDSS3Client(
      final S3ClientConfiguration s3ClientConfiguration,
      final S3PresignerConfiguration s3PresignerConfiguration) {
    this.s3ClientConfiguration = s3ClientConfiguration;
    this.s3PresignerConfiguration = s3PresignerConfiguration;
  }

  // method to get object 'objectName' from S3 bucket 'bucketName'
  @Override
  public S3Object getObject(final String bucketName, final String objectName) {
    if (Objects.isNull(bucketName) || Objects.isNull(objectName))
      throw new AmazonServiceException(
          "Parameters cannot be empty while getting object from S3 bucket");

    AmazonS3 amazonS3 = s3ClientConfiguration.getS3Client();
    return amazonS3.getObject(bucketName, objectName);
  }

  // method to upload file name 'fileName' into bucket 'bucketName'
  @Override
  public PutObjectResult uploadObject(
      final String bucketName, final String objectName, final File fileContent) {
    if (Objects.isNull(bucketName) || Objects.isNull(objectName) || Objects.isNull(fileContent))
      throw new AmazonServiceException(
          "Parameters cannot be empty while uploading file into S3 bucket");

    AmazonS3 amazonS3 = s3ClientConfiguration.getS3Client();
    return amazonS3.putObject(new PutObjectRequest(bucketName, objectName, fileContent));
  }

  // method to check if the given object exists in the bucket or not
  @Override
  public boolean doesObjectExist(final String bucketName, final String objectName) {
    if (Objects.isNull(bucketName) || Objects.isNull(objectName))
      throw new AmazonServiceException("Parameters cannot be empty for does object exist");

    AmazonS3 amazonS3 = s3ClientConfiguration.getS3Client();
    return amazonS3.doesObjectExist(bucketName, objectName);
  }

  // method to get pre-sign url
  @Override
  public URL getPresignUrl(
      final String bucketName, final String objectName, final int timeOutInSecond) {
    if (Objects.isNull(bucketName) || Objects.isNull(objectName))
      throw new AmazonServiceException("Parameters cannot be empty to fetch presign url");

    GetObjectRequest getObjectRequest =
        GetObjectRequest.builder().bucket(bucketName).key(objectName).build();

    GetObjectPresignRequest getObjectPresignRequest =
        GetObjectPresignRequest.builder()
            .signatureDuration(Duration.ofSeconds(timeOutInSecond))
            .getObjectRequest(getObjectRequest)
            .build();

    // Generate the presigned request
    PresignedGetObjectRequest presignedGetObjectRequest =
        s3PresignerConfiguration.getS3Presigner().presignGetObject(getObjectPresignRequest);

    log.info(
        "PresignedUrl generated successfully for the object: {} under bucket: {}",
        objectName,
        bucketName);

    return presignedGetObjectRequest.url();
  }

  @Override
  public DeleteObjectsResult deleteAllObjects(final String bucketName, final String prefix) {
    if (Objects.isNull(bucketName))
      throw new AmazonServiceException("bucket name cannot be empty to delete folder and content");
    if (Objects.isNull(prefix))
      throw new AmazonServiceException("prefix cannot be empty to delete folder and content");

    AmazonS3 amazonS3 = s3ClientConfiguration.getS3Client();

    ListObjectsRequest listObjectsRequest =
        new ListObjectsRequest().withBucketName(bucketName).withPrefix(prefix);

    final ArrayList<KeyVersion> keys = new ArrayList<>();
    ObjectListing objectListing = amazonS3.listObjects(listObjectsRequest);
    while (true) {
      for (final S3ObjectSummary objectSummary : objectListing.getObjectSummaries()) {
        keys.add(new KeyVersion(objectSummary.getKey()));
      }
      if (objectListing.isTruncated()) {
        objectListing = amazonS3.listNextBatchOfObjects(objectListing);
      } else {
        break;
      }
    }
    final DeleteObjectsRequest deleteObjectsRequest =
        new DeleteObjectsRequest(bucketName).withKeys(keys).withQuiet(false);

    log.info("all objects deleted for the prefix: {} under bucket: {}", prefix, bucketName);
    return amazonS3.deleteObjects(deleteObjectsRequest);
  }

  @Override
  public void deleteObject(String bucketName, String objectName) {

    if (Objects.isNull(bucketName))
      throw new AmazonServiceException(
          "bucket name cannot be empty while deleting object from S3 bucket");
    if (Objects.isNull(objectName))
      throw new AmazonServiceException(
          "object name cannot be empty while deleting object from S3 bucket");

    AmazonS3 amazonS3 = s3ClientConfiguration.getS3Client();

    amazonS3.deleteObject(bucketName, objectName);
    log.info("object deleted for the object name: {} under bucket: {}", objectName, bucketName);
  }

   // method to check if the given bucket exists in s3 or not
   @Override
   public boolean doesBucketExist(final String bucketName) {
     if (Objects.isNull(bucketName) )
       throw new AmazonServiceException("bucket name cannot be empty while checking if bucket exist in S3");
 
     AmazonS3 amazonS3 = s3ClientConfiguration.getS3Client();
     return amazonS3.doesBucketExistV2(bucketName);
   }
}
