package com.ielts.cmds.common.utils;

import static com.ielts.cmds.common.constants.CMDSConstants.TOKEN_BEARER;

import java.util.Map;
import java.util.Objects;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.Claim;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CMDSCommonUtils {
  private CMDSCommonUtils() {}

  public static String getDataFromClaims(final String jwtToken, final String keyEndingWith) {
    if (Objects.isNull(jwtToken) || Objects.isNull(keyEndingWith)) {
      log.info("Please pass valid jwtToken and key");
      return null;
    }
    final Map<String, Claim> claims = JWT.decode(jwtToken.replace(TOKEN_BEARER, "")).getClaims();
    if (Objects.nonNull(claims)) {
      final Claim claimValue =
          claims
              .entrySet()
              .stream()
              .filter(e -> e.getKey().endsWith("/" + keyEndingWith))
              .map(Map.Entry::getValue)
              .findFirst()
              .orElse(null);
      return Objects.nonNull(claimValue) ? claimValue.asString() : null;
    }
    return null;
  }

  public static String removeAllNonAlphaNumeric(String identityNumber) {
    if (identityNumber == null) {
      return null;
    }
    return identityNumber.replaceAll("[^\\p{Alnum}]", "").toUpperCase();
  }
}
