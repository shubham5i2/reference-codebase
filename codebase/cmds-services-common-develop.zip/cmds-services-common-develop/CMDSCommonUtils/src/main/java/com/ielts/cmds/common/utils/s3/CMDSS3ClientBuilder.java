package com.ielts.cmds.common.utils.s3;

import com.ielts.cmds.common.config.s3.DefaultS3ClientConfiguration;
import com.ielts.cmds.common.config.s3.DefaultS3PresignerConfiguration;
import com.ielts.cmds.common.config.s3.S3ClientConfiguration;
import com.ielts.cmds.common.config.s3.S3PresignerConfiguration;

public class CMDSS3ClientBuilder {

    public CMDSS3Client buildDefaultCMDSS3Client() {
        S3ClientConfiguration s3ClientConfiguration = new DefaultS3ClientConfiguration();
        S3PresignerConfiguration s3PresignerConfiguration = new DefaultS3PresignerConfiguration();
        return new DefaultCMDSS3Client(s3ClientConfiguration, s3PresignerConfiguration);
    }
}
