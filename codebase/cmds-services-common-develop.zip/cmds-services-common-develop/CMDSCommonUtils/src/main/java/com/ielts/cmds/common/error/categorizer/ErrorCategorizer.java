package com.ielts.cmds.common.error.categorizer;

import java.util.List;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.math.NumberUtils;

import com.amazonaws.util.StringUtils;
import com.ielts.cmds.common.constants.CMDSConstants;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ErrorCategorizer implements IErrorCategorizer {

	List<String> transients = null;
	List<String> intransients = null;
	String defaultCategory = null;
	int defaultThreshold = 0;
	int defaultCBTimeout = 0;
	
	public ErrorCategorizer() {
		super();
		transients = ErrorConfigLoader.getTransientErrors();
		intransients = ErrorConfigLoader.getIntransientErrors();
		defaultCategory = ErrorConfigLoader.getDefaultErrorCategory();
		defaultThreshold = NumberUtils.toInt(ErrorConfigLoader.getDefaultThreshold());
		defaultCBTimeout = NumberUtils.toInt(ErrorConfigLoader.getDefaultCBTimeout());
	}

	@Override
	public StructuredError categorize(final Throwable e) {
		if (e==null) {
			return null;
		}
		
		StructuredError error = new StructuredError()
				.rootErrorMessage(ExceptionUtils.getRootCauseMessage(e))
				.errorMessage(ExceptionUtils.getMessage(e))
				.thrownException(e)
				.rootExceptionClass(ExceptionUtils.getRootCause(e).getClass().getName())
				.category(findCategory(e))
				.errorOwner(getErrorOwner())
				.healthcheckUrl(findHealthcheckUrl())
				.openDuration(findTimeout())
				.errorCountThreshold(findThreshold())
				.errorNature(ErrorNature.BUSINESS); // TODO??
		
		log.info("Error Object structured {}",error);

		
		return error;
	}

	private int findThreshold() {
		String thresholdFromEnv = System.getenv(CMDSConstants.CB_ENV_VAR_THRESHOLD);	
		return NumberUtils.toInt(thresholdFromEnv, defaultThreshold);
	}
	
	private String findHealthcheckUrl() {
		String healthUrlFromEnv = System.getenv(CMDSConstants.CB_ENV_HEALTHCHECK_URL);	
		return healthUrlFromEnv;
	}

	private int findTimeout() {
		String timeoutFromEnv = System.getenv(CMDSConstants.CB_ENV_VAR_TIMEOUT);		
		return NumberUtils.toInt(timeoutFromEnv, defaultCBTimeout);
	}

	private String getErrorOwner() {
		String ownerNameFromEnv = System.getenv(CMDSConstants.CB_ENV_VAR_LAMBDA_ARN);
		log.info("Error Owner name {}",ownerNameFromEnv);

		if(StringUtils.isNullOrEmpty(ownerNameFromEnv)) {
			return "UNKNOWN";
		} else {
			return ownerNameFromEnv;
		}
		
	}

	private ErrorCategory findCategory(final Throwable e) {
		boolean isTransient = transients.stream().anyMatch(s-> {
			String exceptionClass = e.getClass().getName();
			return exceptionClass.equalsIgnoreCase(s) || exceptionClass.endsWith(s) || exceptionClass.contains(s);
		});
		
		if (isTransient) return ErrorCategory.TRANSIENT;
		
		boolean isIntransient = intransients.stream().anyMatch(s-> {
			String exceptionClass = e.getClass().getName();
			return exceptionClass.equalsIgnoreCase(s) || exceptionClass.endsWith(s) || exceptionClass.contains(s);
		});
		
		if (isIntransient) return ErrorCategory.INTRANSIENT;
		
		return ErrorCategory.TRANSIENT.name().equalsIgnoreCase(defaultCategory)?ErrorCategory.TRANSIENT:ErrorCategory.INTRANSIENT;
		
	}

}
