package com.ielts.cmds.common.error.reporter;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.AttributeUpdate;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.UpdateItemOutcome;
import com.amazonaws.services.dynamodbv2.document.spec.UpdateItemSpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.dynamodbv2.model.ReturnValue;
import com.ielts.cmds.common.constants.CMDSConstants;
import com.ielts.cmds.common.error.categorizer.StructuredError;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DynamoDBErrorReporter implements IErrorReporter {

	@Override
	public boolean report(StructuredError error) {
		log.info("Going to report in dyanamodb {} ", error);
		AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard().withRegion("eu-west-2").build();

		DynamoDB dynamoDB = new DynamoDB(client);

		String cbTableName = "ielts-cmds-" + System.getenv(CMDSConstants.CB_ENV_VAR_ENVIRONMENT) + "-dynamodb-cb";
		Table table = dynamoDB.getTable(cbTableName);

		UpdateItemSpec updateItemSpec = new UpdateItemSpec()
				.withPrimaryKey("lambda", error.getErrorOwner())
				.withUpdateExpression("set errorcount = if_not_exists( errorcount , :initial ) + :val, "
						+ "threshold = :errorthreshold, timeout = :errortimeout, healthcheckurl = :healthurl")
				.withValueMap(new ValueMap()
						.withNumber(":val", 1)
						.withNumber(":initial", 0)
						.withNumber(":errorthreshold", error.getErrorCountThreshold())
						.withString(":healthurl", error.getHealthcheckUrl())
						.withNumber(":errortimeout", error.getOpenDuration()))								
				.withReturnValues(ReturnValue.UPDATED_NEW);

		try {
			UpdateItemOutcome outcome = table.updateItem(updateItemSpec);
			log.info("Updated dynamoDB table ");
			log.debug("DynamoDB update outcome atts=" + outcome.getUpdateItemResult().getAttributes());

		} catch (Exception e) {
			log.info(e.getMessage());
		}
		return false;
	}

}
