package com.ielts.cmds.common.persistence.utils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class CMDSOffsetDatetimeTest {

  private OffsetDateTime currentDatetime;

  private LocalDate localDate;
  private String localOffset;
  private OffsetDateTime utcDatetime;
  private String isoDatetime;

  @BeforeEach
  void init() {
    currentDatetime = OffsetDateTime.now();

    localDate = currentDatetime.toLocalDate();
    localOffset = currentDatetime.getOffset().toString();
    utcDatetime = currentDatetime;
    isoDatetime = currentDatetime.format(DateTimeFormatter.ISO_DATE_TIME);
  }

  @Test
  void testFor_CMDSOffsetDatetime() {
    CMDSOffsetDatetime cmdsOffsetDatetime = new CMDSOffsetDatetime(currentDatetime);

    assertNotNull(cmdsOffsetDatetime);
    assertEquals(currentDatetime, cmdsOffsetDatetime.getOffsetDatetime());
    assertEquals(utcDatetime, cmdsOffsetDatetime.getUtcDateTime());
    assertEquals(localDate, cmdsOffsetDatetime.getLocalDate());
    assertEquals(localOffset, cmdsOffsetDatetime.getLocalOffset());
    assertEquals(isoDatetime, cmdsOffsetDatetime.getIsoDateTime());
  }
}
