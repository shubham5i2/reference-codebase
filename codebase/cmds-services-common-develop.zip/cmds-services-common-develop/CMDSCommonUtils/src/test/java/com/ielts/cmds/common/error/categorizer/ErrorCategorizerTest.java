package com.ielts.cmds.common.error.categorizer;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.doReturn;

import java.util.ArrayList;

import javax.management.RuntimeOperationsException;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.mockito.Mock;

import com.ielts.cmds.common.error.helper.TestInfraException;
import com.ielts.cmds.common.error.helper.TestRandomException;
import com.ielts.cmds.common.error.helper.TestServiceException;

class ErrorCategorizerTest {
	
	private final ErrorCategorizer categorizer = new ErrorCategorizer();
	
	//private ErrorConfigLoader errorConfigLoader;

	@Test
	void whenNullExceptionIsReceived_ThenExceptionIsThrown() {
				
		final Executable executable =
		        () -> categorizer.categorize(null);
		assertDoesNotThrow(executable);
	}
	
	@Test
	void whenCategorizeCalled_ThenValidTransientStructuredErrorReturned() throws Exception {
		
		NullPointerException npe = new NullPointerException("Test nullpointer exception msg!!");
		RuntimeOperationsException re = 
				new RuntimeOperationsException(npe, "Test RuntimeOperationsException Exception ");
		TestServiceException testException = new TestServiceException("Wrapper outer Service exception ",re);
		
		StructuredError error = categorizer.categorize(testException);
		assertNotNull(error);
		assertEquals(error.getCategory(), ErrorCategory.TRANSIENT);
		assertEquals(error.getThrownException(), testException);
		assertEquals(error.getRootExceptionClass(), "java.lang.NullPointerException");
		assertEquals(error.getRootErrorMessage(), "NullPointerException: Test nullpointer exception msg!!");
		assertEquals(error.getErrorMessage(), "TestServiceException: Wrapper outer Service exception ");
		assertEquals(error.getErrorNature(), ErrorNature.BUSINESS);
	}
	
	@Test
	void whenCategorizeCalled_ThenValidIntransientStructuredErrorReturned() throws Exception {
		
		ArrayIndexOutOfBoundsException abe = new ArrayIndexOutOfBoundsException("Something broke the boundary!!");
		RuntimeOperationsException re = 
				new RuntimeOperationsException(abe, "Test RuntimeOperationsException Exception ");
		TestInfraException testException = new TestInfraException("Wrapper outer Infrastructure exception ",re);
		
		StructuredError error = categorizer.categorize(testException);
		assertNotNull(error);
		assertEquals(error.getCategory(), ErrorCategory.INTRANSIENT);
		assertEquals(error.getThrownException(), testException);
		assertEquals(error.getRootExceptionClass(), "java.lang.ArrayIndexOutOfBoundsException");
		assertEquals(error.getRootErrorMessage(), "ArrayIndexOutOfBoundsException: Something broke the boundary!!");
		assertEquals(error.getErrorMessage(), "TestInfraException: Wrapper outer Infrastructure exception ");
		assertEquals(error.getErrorNature(), ErrorNature.BUSINESS);
	}
	
	@Test
	void whenCategorizeCalled_ThenDefaultCategoryStructuredErrorReturned() throws Exception {
		
		ArrayIndexOutOfBoundsException abe = new ArrayIndexOutOfBoundsException("Something broke the boundary!!");
		RuntimeOperationsException re = 
				new RuntimeOperationsException(abe, "Test RuntimeOperationsException Exception ");
		TestRandomException testException = new TestRandomException("Wrapper outer TestRandomException exception ",re);
		
		StructuredError error = categorizer.categorize(testException);
		assertNotNull(error);
		assertEquals(error.getCategory(), ErrorCategory.TRANSIENT);
		assertEquals(error.getThrownException(), testException);
		assertEquals(error.getRootExceptionClass(), "java.lang.ArrayIndexOutOfBoundsException");
		assertEquals(error.getRootErrorMessage(), "ArrayIndexOutOfBoundsException: Something broke the boundary!!");
		assertEquals(error.getErrorMessage(), "TestRandomException: Wrapper outer TestRandomException exception ");
		assertEquals(error.getErrorNature(), ErrorNature.BUSINESS);
	}
	
	@Test
	void whenNonNullExceptionIsReceived_ThenNoExceptionIsThrown() {
				
		final Executable executable =
		        () -> categorizer.categorize(new RuntimeException());
		assertDoesNotThrow(executable);
	}

}
