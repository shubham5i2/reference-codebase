package com.ielts.cmds.common.CMDSCommonUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorTypeIdentifier;

class ErrorTypeIdentifierTest {

  @Test
  void whenErrorCode_thenReturnCorrectErrorType() {
    assertEquals(ErrorTypeEnum.VALIDATION, ErrorTypeIdentifier.getErrorTypeFromErrorCode('V'));
    assertEquals(ErrorTypeEnum.WARNING, ErrorTypeIdentifier.getErrorTypeFromErrorCode('W'));
    assertEquals(ErrorTypeEnum.ERROR, ErrorTypeIdentifier.getErrorTypeFromErrorCode('E'));
    assertEquals(null, ErrorTypeIdentifier.getErrorTypeFromErrorCode('A'));
  }
}
