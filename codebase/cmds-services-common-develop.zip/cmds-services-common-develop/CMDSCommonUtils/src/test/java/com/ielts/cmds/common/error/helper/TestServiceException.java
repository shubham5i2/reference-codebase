package com.ielts.cmds.common.error.helper;

public class TestServiceException extends RuntimeException {

	
	private static final long serialVersionUID = 1L;

	public TestServiceException() {
		// TODO Auto-generated constructor stub
	}

	public TestServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public TestServiceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public TestServiceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public TestServiceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
