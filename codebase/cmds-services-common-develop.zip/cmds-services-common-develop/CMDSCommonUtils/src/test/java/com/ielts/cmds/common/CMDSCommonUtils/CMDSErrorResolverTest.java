package com.ielts.cmds.common.CMDSCommonUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.validation.ConstraintViolation;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.common.exception.util.ErrorDescription;

class CMDSErrorResolverTest<T> {

  private Map<String, String> errorCodeMapper = new HashMap<>();

  @BeforeEach
  void setup() throws IOException {
    errorCodeMapper = CMDSCommonTestSetup.getErrorCodeMap();
  }

  @Test
  void whenCMDSErrorResolverObjectCreated_ErrorMapInitializedCorrectly() {
    CMDSErrorResolver<T> resolver = new CMDSErrorResolver<T>(errorCodeMapper);
    assertNotNull(resolver.getErrorCodeMapper());
    assertFalse(resolver.getErrorCodeMapper().isEmpty());
    assertEquals(8, resolver.getErrorCodeMapper().size());
  }

  @Test
  void whenCMDSErrorResolverObjectCreated_ErrorMapInitializedIsUnmodifiable() {
    CMDSErrorResolver<T> resolver = new CMDSErrorResolver<T>(errorCodeMapper);
    Map<String, String> errorMap = resolver.getErrorCodeMapper();
    assertThrows(UnsupportedOperationException.class, () -> errorMap.clear());
  }

  @Test
  void whenPopulatErrorResponseInvoked_ValidErrorResponseReturned() {
    CMDSErrorResolver<T> resolver = new CMDSErrorResolver<T>(errorCodeMapper);
    Set<ConstraintViolation<T>> volations = CMDSCommonTestSetup.getCreateBookingViolations();

    CMDSErrorResponse errorResponse = resolver.populatErrorResponse(volations, "Booking");

    ErrorDescription error1 = errorResponse.getErrorList().get(0);
    ErrorDescription error2 = errorResponse.getErrorList().get(1);

    assertNotNull(errorResponse);
    assertNotNull(errorResponse.getErrorList());
    assertEquals(2, errorResponse.getErrorList().size());

    assertEquals("V1001", error1.getErrorCode());
    assertEquals("Location id can't be null or empty", error1.getMessage());
    assertEquals("Mandatory Field Validation Failure - LocationUuid", error1.getTitle());
    assertEquals(ErrorTypeEnum.VALIDATION, error1.getType());
    assertNotNull(error1.getErrorTicketUuid());
    assertEquals("locationUuid", error1.getSource().getPath());
    assertEquals("Booking", error1.getInterfaceName());

    assertEquals("V1003", error2.getErrorCode());
    assertEquals(ErrorTypeEnum.VALIDATION, error2.getType());
    assertNotNull(error2.getErrorTicketUuid());
    assertEquals("Product id can't be null or Empty", error2.getMessage());
    assertEquals("Mandatory Field Validation Failure - ProductUuid", error2.getTitle());
    assertEquals("productUuid", error2.getSource().getPath());
    assertEquals("Booking", error2.getInterfaceName());
  }
}
