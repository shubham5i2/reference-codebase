package com.ielts.cmds.common.persistence.entity;

import java.util.UUID;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import com.ielts.cmds.common.persistence.utils.CMDSOffsetDatetime;
import com.ielts.cmds.common.persistence.utils.CMDSOffsetDatetimeType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@TypeDefs({
  @TypeDef(defaultForType = CMDSOffsetDatetime.class, typeClass = CMDSOffsetDatetimeType.class)
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "local_date_time")
public class LocalDateTimeEntity {

  @Id
  @Column(name = "local_date_time_uuid")
  private UUID localDateTimeUuid;

  @Embedded private CMDSOffsetDatetime testDate;

  @AttributeOverrides({
    @AttributeOverride(name = "isoDateTime", column = @Column(name = "start_iso_date_time")),
    @AttributeOverride(name = "localDate", column = @Column(name = "start_local_date")),
    @AttributeOverride(name = "localOffset", column = @Column(name = "start_local_offset")),
    @AttributeOverride(name = "utcDateTime", column = @Column(name = "start_utc_date_time"))
  })
  @Embedded
  private CMDSOffsetDatetime startTestdate;
}
