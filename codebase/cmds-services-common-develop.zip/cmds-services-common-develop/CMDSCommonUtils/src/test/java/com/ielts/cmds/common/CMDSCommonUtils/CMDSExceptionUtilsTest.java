package com.ielts.cmds.common.CMDSCommonUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.Test;

import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.common.exception.util.CMDSExceptionUtils;
import com.ielts.cmds.common.exception.util.ErrorDescription;

class CMDSExceptionUtilsTest {

  @Test
  void whenpopulateCMDSErrorDescriptionInvoked_verifyCorrectValuesPopulated() {

    List<ErrorDescription> erroList = new ArrayList<ErrorDescription>();

    UUID ticketId = UUID.randomUUID();

    ErrorDescription errorDescription = new ErrorDescription();
    errorDescription.setInterfaceName("Booking");
    errorDescription.setType(ErrorTypeEnum.VALIDATION);
    errorDescription.setErrorCode("V1008");
    errorDescription.setErrorTicketUuid(ticketId);

    CMDSExceptionUtils.populateSourceInformation(errorDescription, "bookingId", "123456789");

    erroList.add(errorDescription);

    CMDSErrorResponse errResponse = CMDSExceptionUtils.populateCMDSErrorResponse(erroList);

    assertNotNull(errResponse);

    assertEquals(1, errResponse.getErrorList().size());

    ErrorDescription actualError1 = errResponse.getErrorList().get(0);
    assertNotNull(actualError1);
    assertEquals(errorDescription.getInterfaceName(), actualError1.getInterfaceName());
    assertEquals(errorDescription.getType(), actualError1.getType());
    assertEquals(errorDescription.getErrorCode(), actualError1.getErrorCode());

    assertNotNull(actualError1.getSource());
    assertEquals(errorDescription.getSource().getPath(), actualError1.getSource().getPath());
    assertEquals(errorDescription.getSource().getValue(), actualError1.getSource().getValue());
  }
}
