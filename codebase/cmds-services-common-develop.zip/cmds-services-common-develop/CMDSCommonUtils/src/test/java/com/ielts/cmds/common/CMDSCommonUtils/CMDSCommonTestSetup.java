package com.ielts.cmds.common.CMDSCommonUtils;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Path;
import javax.validation.metadata.ConstraintDescriptor;

import org.hibernate.validator.internal.engine.ConstraintViolationImpl;
import org.hibernate.validator.internal.engine.path.PathImpl;

public class CMDSCommonTestSetup {

  public static <T> Set<ConstraintViolation<T>> getCreateBookingViolations() {

    Set<ConstraintViolation<T>> violationSet = new LinkedHashSet<>();
    final String messageTemplate = null;
    final String interpolatedMessage1 = "V1001";
    final String interpolatedMessage2 = "V1003";
    final Class<T> rootBeanClass = null;
    final T rootBean = null;
    final T leafBeanInstance = null;
    final T value = null;
    final Path propertyPath1 = PathImpl.createPathFromString("locationUuid");
    final Path propertyPath2 = PathImpl.createPathFromString("productUuid");
    final ConstraintDescriptor<?> constraintDescriptor = null;
    final Map<String, Object> messageParameters = new HashMap<>();
    final Map<String, Object> expressionVariables = new HashMap<>();
    ConstraintViolation<T> constraintViolationImpl1 =
        (ConstraintViolationImpl<T>)
            ConstraintViolationImpl.forBeanValidation(
                messageTemplate,
                messageParameters,
                expressionVariables,
                interpolatedMessage1,
                rootBeanClass,
                rootBean,
                leafBeanInstance,
                value,
                propertyPath1,
                constraintDescriptor,
                null);

    ConstraintViolation<T> constraintViolationImpl2 =
        (ConstraintViolationImpl<T>)
            ConstraintViolationImpl.forBeanValidation(
                messageTemplate,
                messageParameters,
                expressionVariables,
                interpolatedMessage2,
                rootBeanClass,
                rootBean,
                leafBeanInstance,
                value,
                propertyPath2,
                constraintDescriptor,
                null);

    violationSet.add(constraintViolationImpl1);
    violationSet.add(constraintViolationImpl2);
    return violationSet;
  }

  public static Map<String, String> getErrorCodeMap() {

    Map<String, String> errorCodeMapper = new HashMap<>();

    errorCodeMapper.put("V1001", "Location id can't be null or empty");
    errorCodeMapper.put("V1001.title", "Mandatory Field Validation Failure - LocationUuid");

    errorCodeMapper.put("V1002", "Invalid Location id given in request");
    errorCodeMapper.put("V1002.title", "LocationUuid Validation Failure");

    errorCodeMapper.put("V1003", "Product id can't be null or Empty");
    errorCodeMapper.put("V1003.title", "Mandatory Field Validation Failure - ProductUuid");

    errorCodeMapper.put("V1004", "Invalid Product Id given in request");
    errorCodeMapper.put("V1004.title", "ProductUuid Validation Failure");

    return errorCodeMapper;
  }
}
