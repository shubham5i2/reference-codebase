package com.ielts.cmds.common.utils.s3;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.DeleteObjectsRequest;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.ielts.cmds.common.config.s3.S3ClientConfiguration;
import com.ielts.cmds.common.config.s3.S3PresignerConfiguration;

import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.services.s3.presigner.S3Presigner;
import software.amazon.awssdk.services.s3.presigner.model.GetObjectPresignRequest;
import software.amazon.awssdk.services.s3.presigner.model.PresignedGetObjectRequest;

@Slf4j
@ExtendWith(MockitoExtension.class)
class DefaultCMDSS3ClientTest {

  DefaultCMDSS3Client defaultCMDSS3Client;

  @Mock S3ClientConfiguration s3ClientConfiguration;

  @Mock S3PresignerConfiguration s3PresignerConfiguration;

  @Mock private ObjectListing objectListing;

  @BeforeEach
  void init() {
    defaultCMDSS3Client = new DefaultCMDSS3Client(s3ClientConfiguration, s3PresignerConfiguration);
  }

  @DisplayName("Test case for getObject method when bucketName and objectName is provided")
  @Test
  void testFor_getObject_method_success() {
    AmazonS3 mockedAmazonS3 = DefaultCMDSS3ClientTestDataSetup.getAmazonS3DataForTest();
    when(s3ClientConfiguration.getS3Client()).thenReturn(mockedAmazonS3);

    S3Object expectedS3Object = new S3Object();
    when(mockedAmazonS3.getObject("bucket_name", "object_name")).thenReturn(expectedS3Object);

    S3Object actualS3Object = defaultCMDSS3Client.getObject("bucket_name", "object_name");
    assertEquals(expectedS3Object, actualS3Object);
  }

  @DisplayName("Test case for getObject method when bucketName and objectName is not provided")
  @Test
  void testFor_getObject_method_fail() {
    assertThrows(AmazonServiceException.class, () -> defaultCMDSS3Client.getObject(null, null));
  }

  @DisplayName(
      "Test case for uploadObject method when bucketName, objectName and fileContent is provided")
  @Test
  void testFor_uploadObject_method_success() {
    File file = Mockito.mock(File.class);
    AmazonS3 mockedAmazonS3 = DefaultCMDSS3ClientTestDataSetup.getAmazonS3DataForTest();
    PutObjectResult expectedPutObjectResult = new PutObjectResult();
    lenient().when(s3ClientConfiguration.getS3Client()).thenReturn(mockedAmazonS3);
    lenient()
        .when(mockedAmazonS3.putObject(new PutObjectRequest("bucket_name", "object_name", file)))
        .thenReturn(expectedPutObjectResult);
    PutObjectResult actualPutObjectResult =
        defaultCMDSS3Client.uploadObject("bucket_name", "object_name", file);
  }

  @DisplayName(
      "Test case for uploadObject method when bucketName, objectName and fileContent not is provided")
  @Test
  void testFor_uploadObject_method_fail() {
    File file = Mockito.mock(File.class);
    assertThrows(
        AmazonServiceException.class, () -> defaultCMDSS3Client.uploadObject(null, null, file));
  }

  @DisplayName("Test case for doesObjectExist method when bucketName and objectName is provided")
  @Test
  void testFor_doesObjectExist_method_success() {
    AmazonS3 mockedAmazonS3 = DefaultCMDSS3ClientTestDataSetup.getAmazonS3DataForTest();
    when(s3ClientConfiguration.getS3Client()).thenReturn(mockedAmazonS3);
    when(mockedAmazonS3.doesObjectExist("bucket_name", "object_name")).thenReturn(true);
    boolean actualPutObjectResult =
        defaultCMDSS3Client.doesObjectExist("bucket_name", "object_name");
    assertTrue(actualPutObjectResult);
  }

  @DisplayName(
      "Test case for doesObjectExist method when bucketName and objectName is not provided")
  @Test
  void testFor_doesObjectExist_method_fail() {
    assertThrows(
        AmazonServiceException.class, () -> defaultCMDSS3Client.doesObjectExist(null, null));
  }

  @Test
  void testFor_getPresignURL_method() throws MalformedURLException {
    S3Presigner mockedS3Presigner = DefaultCMDSS3ClientTestDataSetup.getS3PresignerDataForTest();
    PresignedGetObjectRequest request =
        DefaultCMDSS3ClientTestDataSetup.getPresignedGetObjectRequestForTest();
    URL expected = new URL("https://xyz.com");
    when(s3PresignerConfiguration.getS3Presigner()).thenReturn(mockedS3Presigner);
    when(mockedS3Presigner.presignGetObject(ArgumentMatchers.any(GetObjectPresignRequest.class)))
        .thenReturn(request);
    when(request.url()).thenReturn(expected);
    URL actual = defaultCMDSS3Client.getPresignUrl("bucket_name", "object_name", 900);
    assertEquals(expected, actual);
  }

  @DisplayName("Test case for deleteObject method when bucketName and objectName is provided")
  @Test
  void testFor_deleteObject_method_success() {
    AmazonS3 mockedAmazonS3 = DefaultCMDSS3ClientTestDataSetup.getAmazonS3DataForTest();
    when(s3ClientConfiguration.getS3Client()).thenReturn(mockedAmazonS3);

    final Executable executable =
        () -> defaultCMDSS3Client.deleteObject("bucket_name", "object_name");

    // Then
    assertDoesNotThrow(executable);
  }

  @DisplayName("Test case for deleteObject method when bucketName and objectName is not provided")
  @Test
  void testFor_deleteObject_method_fail() {
    assertThrows(AmazonServiceException.class, () -> defaultCMDSS3Client.deleteObject(null, null));
  }

  @DisplayName("Test case for deleteAllObjects method when bucketName, prefix is provided")
  @Test
  void testFor_deleteAllObjects_method_success() {

    AmazonS3 mockedAmazonS3 = DefaultCMDSS3ClientTestDataSetup.getAmazonS3DataForTest();
    when(s3ClientConfiguration.getS3Client()).thenReturn(mockedAmazonS3);

    // Mocks
    when(mockedAmazonS3.listObjects(ArgumentMatchers.any(ListObjectsRequest.class)))
        .thenReturn(objectListing);

    List<S3ObjectSummary> objectSummaries = new ArrayList<>();
    final S3ObjectSummary objectSummary = new S3ObjectSummary();
    objectSummary.setKey("test");
    objectSummaries.add(objectSummary);
    when(objectListing.getObjectSummaries()).thenReturn(objectSummaries);

    // When
    final Executable executable =
        () ->
            defaultCMDSS3Client.deleteAllObjects(
                "bucket_name", "testday-materials/Extracted_test.zip");

    // Then
    assertDoesNotThrow(executable);
    verify(mockedAmazonS3, times(1))
        .deleteObjects(ArgumentMatchers.any(DeleteObjectsRequest.class));
  }

  @DisplayName("Test case for deleteAllObjects method when bucketName is provided")
  @Test
  void testFor_deleteAllObjects_method_emptyBucketName_fail() {
    assertThrows(
        AmazonServiceException.class,
        () -> defaultCMDSS3Client.deleteAllObjects(null, "testday-materials/Extracted_test.zip"));
  }

  @DisplayName("Test case for deleteAllObjects method when bucketName is provided")
  @Test
  void testFor_deleteAllObjects_method_emptyPrefix_fail() {
    assertThrows(
        AmazonServiceException.class,
        () -> defaultCMDSS3Client.deleteAllObjects("bucket_name", null));
  }

  @DisplayName("Test case for doesBucketExist method when bucketName is provided")
  @Test
  void testFor_doesBucketExist_method_success() {
    AmazonS3 mockedAmazonS3 = DefaultCMDSS3ClientTestDataSetup.getAmazonS3DataForTest();
    when(s3ClientConfiguration.getS3Client()).thenReturn(mockedAmazonS3);
    when(mockedAmazonS3.doesBucketExistV2("bucket_name")).thenReturn(true);
    boolean actualPutObjectResult = defaultCMDSS3Client.doesBucketExist("bucket_name");
    assertTrue(actualPutObjectResult);
  }

  @DisplayName("Test case for doesBucketExist method when bucketName is not provided")
  @Test
  void testFor_doesBucketExistExist_method_fail() {
    assertThrows(AmazonServiceException.class, () -> defaultCMDSS3Client.doesBucketExist(null));
  }
}
