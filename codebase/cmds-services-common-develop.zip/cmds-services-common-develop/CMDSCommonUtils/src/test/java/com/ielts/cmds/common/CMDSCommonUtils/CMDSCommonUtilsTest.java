package com.ielts.cmds.common.CMDSCommonUtils;

import static com.ielts.cmds.common.utils.CMDSCommonUtils.removeAllNonAlphaNumeric;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.ielts.cmds.common.utils.CMDSCommonUtils;

class CMDSCommonUtilsTest {

  @Test
  void whenGetDataFromClaimsInvoked_ThenClaimsDataPopulate() {

    final String jwtToken =
        "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkJTT3YxZ21Zam1vSWNUZFpFcGN3XyJ9.eyJodHRwczovL2NtZHNpei5jb20vcGFydG5lckNvZGUiOiJJRFAiLCJodHRwczovL2NtZHNpei5jb20vbmlja25hbWUiOiJzb21zZXR3YXIubSIsImh0dHBzOi8vY21kc2l6LmNvbS9pZCI6ImF1dGgwfDVmNGY5NWJjMTljMGM1MDA2OGM2NWQ3MyIsImh0dHBzOi8vY21kc2l6LmNvbS9yb2xlcyI6WyJsOmI1ZDA2YmZiLTE2NDAtNDNlOS1iNGMwLTJmMmRhZjc4ZmNiYy9nOjkwZDA5MWY4LTU3YmItNDkzMi1iNzVjLTk2M2Q0MDJkOGMwZiIsImw6NWQzZmNhNDAtMWU1Yi00OTFlLThjODUtYjJiOTAyYzI0NmJhL2c6NGFhNTIzMjgtNzgzYS00ZDhkLWFiNGMtY2JiNDFjM2I4ZjVlIl0sImlzcyI6Imh0dHBzOi8vY21kcy1zYW5kYm94LmV1LmF1dGgwLmNvbS8iLCJzdWIiOiJhdXRoMHw1ZjRmOTViYzE5YzBjNTAwNjhjNjVkNzMiLCJhdWQiOlsiY21kcy1zYW5kYm94LXVpLWFwaSIsImh0dHBzOi8vY21kcy1zYW5kYm94LmV1LmF1dGgwLmNvbS91c2VyaW5mbyJdLCJpYXQiOjE2MTk0MjI5MDIsImV4cCI6MTYxOTQzNzMwMiwiYXpwIjoiNm5wSkhLS0ppR1pIa0xJUE41YUJXM25hRTBsQW1PblkiLCJzY29wZSI6Im9wZW5pZCBwcm9maWxlIGVtYWlsIn0.m0bQbBAdETltdB_4QbSkUZGYgK9pfspXOs2H7b-tmdVz-5vU50TInyqLRlvcDA8hqNqJ_zShCAWQASVO0EbB2HrwDPwBCWcooLlINNi5WcFPcpblVsIIvAKRcyyKAk0KQfzcq8D-SosX7NIwrdKsE5NfXTo3XCSzGQYcuC6NsNlWWs7BhhjFSreICqEFN_hshrEpW2dVv6J4O9rxlZOcoX3xOI0D_0pfUs2z9qX8_EUdRNaYyqBOIddLGug93uws-53hitKH1Mh43tvut1geLNpt6ZgYfVjfUDXw_HoXXnUqmLWJNe40WWnTn0pwiJd5vXwkyzWiN99WyR7Aoqcziw";
    final String keyEndingWith = "partnerCode";
    String dataFromClaims = CMDSCommonUtils.getDataFromClaims(jwtToken, keyEndingWith);

    assertEquals("IDP", dataFromClaims);
  }

  @Test
  void itNormalizesAnIdentityNumber() {
    String identityNum1 = "784-1989-8069328-1";
    String expectedNormalizedId = "784198980693281";

    String identityNum2 = "N888& 7*^$%!¬_+-@~}{><?/|997";
    String expectedNormalizedId2 = "N8887997";

    String identityNum3 = " N888  nhoe97";
    String expectedNormalizedId3 = "N888NHOE97";

    Assertions.assertEquals(
            expectedNormalizedId,
            removeAllNonAlphaNumeric(identityNum1)
    );

    Assertions.assertEquals(
            expectedNormalizedId2,
            removeAllNonAlphaNumeric(identityNum2)
    );

    Assertions.assertEquals(
            expectedNormalizedId3,
            removeAllNonAlphaNumeric(identityNum3)
    );

    Assertions.assertNull(removeAllNonAlphaNumeric(null));

  }
}
