package com.ielts.cmds.common.error.helper;

public class TestInfraException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TestInfraException() {
		// TODO Auto-generated constructor stub
	}

	public TestInfraException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public TestInfraException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public TestInfraException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public TestInfraException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
