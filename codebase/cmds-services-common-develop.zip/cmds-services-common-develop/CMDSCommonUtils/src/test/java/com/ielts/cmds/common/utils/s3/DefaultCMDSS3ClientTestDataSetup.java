package com.ielts.cmds.common.utils.s3;

import com.amazonaws.services.s3.AmazonS3;
import org.mockito.Mockito;
import software.amazon.awssdk.services.s3.presigner.S3Presigner;
import software.amazon.awssdk.services.s3.presigner.model.PresignedGetObjectRequest;

public class DefaultCMDSS3ClientTestDataSetup {

    public static AmazonS3 getAmazonS3DataForTest() {
        return Mockito.mock(AmazonS3.class);
    }

    public static S3Presigner getS3PresignerDataForTest() {
        return Mockito.mock(S3Presigner.class);
    }

    public static PresignedGetObjectRequest getPresignedGetObjectRequestForTest() {
        return Mockito.mock(PresignedGetObjectRequest.class);
    }
}
