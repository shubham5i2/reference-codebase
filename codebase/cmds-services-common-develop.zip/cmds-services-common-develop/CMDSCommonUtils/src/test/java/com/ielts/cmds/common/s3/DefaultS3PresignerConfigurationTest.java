/*
package com.ielts.cmds.common.s3;


import com.ielts.cmds.common.config.s3.DefaultS3PresignerConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.presigner.S3Presigner;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@Slf4j
@ExtendWith(MockitoExtension.class)
public class DefaultS3PresignerConfigurationTest {

    @Spy
    DefaultS3PresignerConfiguration defaultS3PresignerConfiguration;

    @BeforeEach
    void init()
    {
        ReflectionTestUtils.setField(defaultS3PresignerConfiguration, "region", Region.EU_WEST_2.toString());
    }

    @Test
    void testFor_getS3Client()
    {
        S3Presigner actual = defaultS3PresignerConfiguration.getS3Presigner();
        assertNotNull(actual);
    }
}
*/
