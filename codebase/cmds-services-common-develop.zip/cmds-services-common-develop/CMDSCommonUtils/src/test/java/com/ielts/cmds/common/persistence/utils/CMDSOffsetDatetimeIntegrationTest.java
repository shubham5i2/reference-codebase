package com.ielts.cmds.common.persistence.utils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ielts.cmds.common.config.IntegrationTestConfig;
import com.ielts.cmds.common.persistence.entity.LocalDateTimeEntity;
import com.ielts.cmds.common.persistence.repository.LocalDateTimeRepository;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = IntegrationTestConfig.class)
@ActiveProfiles("test")
public class CMDSOffsetDatetimeIntegrationTest {

  @Autowired private LocalDateTimeRepository localDatetimeRepository;

  private OffsetDateTime offsetDatetime = OffsetDateTime.now();

  @BeforeEach
  void setup() {}

  @Test
  void whenCMDSOffsetDatetimeIsSet_ThenAllValuesAreSaved() {

    // Setting up and saving data to database
    final UUID localDatetimeUuid = UUID.randomUUID();
    final LocalDateTimeEntity localDatetimeEntity = new LocalDateTimeEntity();
    localDatetimeEntity.setLocalDateTimeUuid(localDatetimeUuid);
    localDatetimeEntity.setTestDate(new CMDSOffsetDatetime(offsetDatetime));
    localDatetimeRepository.save(localDatetimeEntity);

    // Fetching data from database
    Optional<LocalDateTimeEntity> localDatetimeOptional =
        localDatetimeRepository.findById(localDatetimeUuid);

    assertTrue(localDatetimeOptional.isPresent());
    assertEquals(localDatetimeUuid, localDatetimeOptional.get().getLocalDateTimeUuid());
    assertNotNull(localDatetimeOptional.get().getTestDate());
    assertEquals(offsetDatetime, localDatetimeOptional.get().getTestDate().getOffsetDatetime());
    assertEquals(offsetDatetime, localDatetimeOptional.get().getTestDate().getUtcDateTime());
    assertEquals(
        offsetDatetime.toLocalDate(), localDatetimeOptional.get().getTestDate().getLocalDate());
    assertEquals(
        offsetDatetime.getOffset().toString(),
        localDatetimeOptional.get().getTestDate().getLocalOffset());
    assertEquals(
        offsetDatetime.format(DateTimeFormatter.ISO_DATE_TIME),
        localDatetimeOptional.get().getTestDate().getIsoDateTime());

    localDatetimeRepository.deleteAll();
  }

  @Test
  void whenCMDSOffsetDatetimeIsInitialized_NullValues_ThenNullValuesAreSaved() {

    // Setting up and saving data to database
    final UUID localDatetimeUuid = UUID.randomUUID();
    final LocalDateTimeEntity localDatetimeEntity = new LocalDateTimeEntity();
    localDatetimeEntity.setLocalDateTimeUuid(localDatetimeUuid);
    localDatetimeEntity.setTestDate(new CMDSOffsetDatetime(null));
    localDatetimeRepository.save(localDatetimeEntity);

    // Fetching data from database
    Optional<LocalDateTimeEntity> localDatetimeOptional =
        localDatetimeRepository.findById(localDatetimeUuid);

    assertTrue(localDatetimeOptional.isPresent());
    assertEquals(localDatetimeUuid, localDatetimeOptional.get().getLocalDateTimeUuid());
    assertNull(localDatetimeOptional.get().getTestDate());

    localDatetimeRepository.deleteAll();
  }

  @Test
  void whenCMDSOffsetDatetimeIsNull_ThenNullValuesAreSaved() {

    // Setting up and saving data to database
    final UUID localDatetimeUuid = UUID.randomUUID();
    final LocalDateTimeEntity localDatetimeEntity = new LocalDateTimeEntity();
    localDatetimeEntity.setLocalDateTimeUuid(localDatetimeUuid);
    localDatetimeEntity.setTestDate(new CMDSOffsetDatetime(null));
    localDatetimeRepository.save(localDatetimeEntity);

    // Fetching data from database
    Optional<LocalDateTimeEntity> localDatetimeOptional =
        localDatetimeRepository.findById(localDatetimeUuid);

    assertTrue(localDatetimeOptional.isPresent());
    assertEquals(localDatetimeUuid, localDatetimeOptional.get().getLocalDateTimeUuid());
    assertNull(localDatetimeOptional.get().getTestDate());

    localDatetimeRepository.deleteAll();
  }

  @Test
  void whenFindByLocalOffset_ThenRecordsAreFetched() {

    // Setting up and saving data to database
    final UUID localDatetimeUuid = UUID.randomUUID();
    offsetDatetime = offsetDatetime.withOffsetSameInstant(ZoneOffset.of("+01:00"));
    final LocalDateTimeEntity localDatetimeEntity = new LocalDateTimeEntity();
    localDatetimeEntity.setLocalDateTimeUuid(localDatetimeUuid);
    localDatetimeEntity.setTestDate(new CMDSOffsetDatetime(offsetDatetime));
    localDatetimeRepository.save(localDatetimeEntity);

    final UUID localDatetimeUuid2 = UUID.randomUUID();
    offsetDatetime = offsetDatetime.withOffsetSameInstant(ZoneOffset.of("+05:30"));
    final LocalDateTimeEntity localDatetimeEntity2 = new LocalDateTimeEntity();
    localDatetimeEntity2.setLocalDateTimeUuid(localDatetimeUuid2);
    localDatetimeEntity2.setTestDate(new CMDSOffsetDatetime(offsetDatetime));
    localDatetimeRepository.save(localDatetimeEntity2);

    final UUID localDatetimeUuid3 = UUID.randomUUID();
    offsetDatetime = offsetDatetime.withOffsetSameInstant(ZoneOffset.of("+05:30"));
    final LocalDateTimeEntity localDatetimeEntity3 = new LocalDateTimeEntity();
    localDatetimeEntity3.setLocalDateTimeUuid(localDatetimeUuid3);
    localDatetimeEntity3.setTestDate(new CMDSOffsetDatetime(offsetDatetime));
    localDatetimeRepository.save(localDatetimeEntity3);

    // Fetching data from database
    List<LocalDateTimeEntity> localDatetimesList1 =
        localDatetimeRepository.findByTestDateLocalOffset("+01:00");
    List<LocalDateTimeEntity> localDatetimesList2 =
        localDatetimeRepository.findByTestDateLocalOffset("+05:30");
    List<LocalDateTimeEntity> localDatetimesList3 =
        localDatetimeRepository.findByTestDateLocalOffset("+10:00");

    assertEquals(1, localDatetimesList1.size());
    assertEquals(2, localDatetimesList2.size());
    assertEquals(0, localDatetimesList3.size());

    localDatetimeRepository.deleteAll();
  }

  @Test
  void whenFindByLocalOffset_CriteriaAPI_ThenRecordsAreFetched() {

    // Setting up and saving data to database
    final UUID localDatetimeUuid = UUID.randomUUID();
    offsetDatetime = offsetDatetime.withOffsetSameInstant(ZoneOffset.of("+01:00"));
    final LocalDateTimeEntity localDatetimeEntity = new LocalDateTimeEntity();
    localDatetimeEntity.setLocalDateTimeUuid(localDatetimeUuid);
    localDatetimeEntity.setTestDate(new CMDSOffsetDatetime(offsetDatetime));
    localDatetimeRepository.save(localDatetimeEntity);

    final UUID localDatetimeUuid2 = UUID.randomUUID();
    offsetDatetime = offsetDatetime.withOffsetSameInstant(ZoneOffset.of("+05:30"));
    final LocalDateTimeEntity localDatetimeEntity2 = new LocalDateTimeEntity();
    localDatetimeEntity2.setLocalDateTimeUuid(localDatetimeUuid2);
    localDatetimeEntity2.setTestDate(new CMDSOffsetDatetime(offsetDatetime));
    localDatetimeRepository.save(localDatetimeEntity2);

    final UUID localDatetimeUuid3 = UUID.randomUUID();
    offsetDatetime = offsetDatetime.withOffsetSameInstant(ZoneOffset.of("+05:30"));
    final LocalDateTimeEntity localDatetimeEntity3 = new LocalDateTimeEntity();
    localDatetimeEntity3.setLocalDateTimeUuid(localDatetimeUuid3);
    localDatetimeEntity3.setTestDate(new CMDSOffsetDatetime(offsetDatetime));
    localDatetimeRepository.save(localDatetimeEntity3);

    // Fetching data from database
    Specification<LocalDateTimeEntity> timezoneSpecification1 =
        (localDatetime, criteriaQuery, criteriaBuilder) -> {
          return criteriaBuilder.equal(localDatetime.get("testDate").get("localOffset"), "+01:00");
        };
    List<LocalDateTimeEntity> localDatetimesList1 =
        localDatetimeRepository.findAll(timezoneSpecification1);

    Specification<LocalDateTimeEntity> timezoneSpecification2 =
        (localDatetime, criteriaQuery, criteriaBuilder) -> {
          return criteriaBuilder.equal(localDatetime.get("testDate").get("localOffset"), "+05:30");
        };
    List<LocalDateTimeEntity> localDatetimesList2 =
        localDatetimeRepository.findAll(timezoneSpecification2);

    Specification<LocalDateTimeEntity> timezoneSpecification3 =
        (localDatetime, criteriaQuery, criteriaBuilder) -> {
          return criteriaBuilder.equal(localDatetime.get("testDate").get("localOffset"), "+10:00");
        };
    List<LocalDateTimeEntity> localDatetimesList3 =
        localDatetimeRepository.findAll(timezoneSpecification3);

    assertEquals(1, localDatetimesList1.size());
    assertEquals(2, localDatetimesList2.size());
    assertEquals(0, localDatetimesList3.size());

    localDatetimeRepository.deleteAll();
  }

  @Test
  void whenFindByLocalOffset_AttributeOverrideField_CriteriaAPI_ThenRecordsAreFetched() {

    // Setting up and saving data to database
    final UUID localDatetimeUuid = UUID.randomUUID();
    offsetDatetime = offsetDatetime.withOffsetSameInstant(ZoneOffset.of("+01:00"));
    final LocalDateTimeEntity localDatetimeEntity = new LocalDateTimeEntity();
    localDatetimeEntity.setLocalDateTimeUuid(localDatetimeUuid);
    localDatetimeEntity.setStartTestdate(new CMDSOffsetDatetime(offsetDatetime));
    localDatetimeRepository.save(localDatetimeEntity);

    final UUID localDatetimeUuid2 = UUID.randomUUID();
    offsetDatetime = offsetDatetime.withOffsetSameInstant(ZoneOffset.of("+05:30"));
    final LocalDateTimeEntity localDatetimeEntity2 = new LocalDateTimeEntity();
    localDatetimeEntity2.setLocalDateTimeUuid(localDatetimeUuid2);
    localDatetimeEntity2.setStartTestdate(new CMDSOffsetDatetime(offsetDatetime));
    localDatetimeRepository.save(localDatetimeEntity2);

    final UUID localDatetimeUuid3 = UUID.randomUUID();
    offsetDatetime = offsetDatetime.withOffsetSameInstant(ZoneOffset.of("+05:30"));
    final LocalDateTimeEntity localDatetimeEntity3 = new LocalDateTimeEntity();
    localDatetimeEntity3.setLocalDateTimeUuid(localDatetimeUuid3);
    localDatetimeEntity3.setStartTestdate(new CMDSOffsetDatetime(offsetDatetime));
    localDatetimeRepository.save(localDatetimeEntity3);

    // Fetching data from database
    Specification<LocalDateTimeEntity> timezoneSpecification1 =
        (localDatetime, criteriaQuery, criteriaBuilder) -> {
          return criteriaBuilder.equal(
              localDatetime.get("startTestdate").get("localOffset"), "+01:00");
        };
    List<LocalDateTimeEntity> localDatetimesList1 =
        localDatetimeRepository.findAll(timezoneSpecification1);

    Specification<LocalDateTimeEntity> timezoneSpecification2 =
        (localDatetime, criteriaQuery, criteriaBuilder) -> {
          return criteriaBuilder.equal(
              localDatetime.get("startTestdate").get("localOffset"), "+05:30");
        };
    List<LocalDateTimeEntity> localDatetimesList2 =
        localDatetimeRepository.findAll(timezoneSpecification2);

    Specification<LocalDateTimeEntity> timezoneSpecification3 =
        (localDatetime, criteriaQuery, criteriaBuilder) -> {
          return criteriaBuilder.equal(
              localDatetime.get("startTestdate").get("localOffset"), "+10:00");
        };
    List<LocalDateTimeEntity> localDatetimesList3 =
        localDatetimeRepository.findAll(timezoneSpecification3);

    assertEquals(1, localDatetimesList1.size());
    assertEquals(2, localDatetimesList2.size());
    assertEquals(0, localDatetimesList3.size());

    localDatetimeRepository.deleteAll();
  }
}
