package com.ielts.cmds.common.utils.s3;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertTrue;

@Slf4j
@ExtendWith(MockitoExtension.class)
class CMDSS3ClientBuilderTest {

    CMDSS3ClientBuilder cmdss3ClientBuilder;

    @BeforeEach
    void init()
    {
        cmdss3ClientBuilder= new CMDSS3ClientBuilder();
    }

    @Test
    void testFor_buildDefaultCMDSS3Client()
    {
        CMDSS3Client cmdss3Client = cmdss3ClientBuilder.buildDefaultCMDSS3Client();
        assertTrue(cmdss3Client instanceof DefaultCMDSS3Client);
    }
}
