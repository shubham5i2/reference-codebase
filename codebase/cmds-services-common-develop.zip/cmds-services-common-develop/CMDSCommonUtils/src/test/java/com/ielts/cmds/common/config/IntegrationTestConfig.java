/** */
package com.ielts.cmds.common.config;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Profile;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/** @author cts */
@TestPropertySource("classpath:application-test.properties")
@EntityScan({"com.ielts.cmds.common.persistence.entity"})
@EnableJpaRepositories(basePackages = {"com.ielts.cmds.common.persistence.repository"})
@DataJpaTest
@EnableTransactionManagement
@Profile("test")
public class IntegrationTestConfig {}
