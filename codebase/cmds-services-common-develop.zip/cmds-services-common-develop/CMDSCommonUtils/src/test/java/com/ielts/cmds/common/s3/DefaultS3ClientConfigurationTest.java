package com.ielts.cmds.common.s3;


import com.amazonaws.services.s3.AmazonS3;
import com.ielts.cmds.common.config.s3.DefaultS3ClientConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import software.amazon.awssdk.regions.Region;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@Slf4j
@ExtendWith(MockitoExtension.class)
public class DefaultS3ClientConfigurationTest {

    @Spy
    DefaultS3ClientConfiguration defaultS3ClientConfiguration;

    @BeforeEach
    void init()
    {
        ReflectionTestUtils.setField(defaultS3ClientConfiguration, "region", Region.EU_WEST_2.toString());
    }

    @Test
    void testFor_getS3Client()
    {
        AmazonS3 actual = defaultS3ClientConfiguration.getS3Client();
        assertNotNull(actual);
        assertEquals(Region.EU_WEST_2.toString(),actual.getRegion().toString());
    }
}
