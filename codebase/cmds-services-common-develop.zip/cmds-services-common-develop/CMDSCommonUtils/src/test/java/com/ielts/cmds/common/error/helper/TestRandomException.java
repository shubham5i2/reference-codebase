package com.ielts.cmds.common.error.helper;

public class TestRandomException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TestRandomException() {
		// TODO Auto-generated constructor stub
	}

	public TestRandomException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public TestRandomException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public TestRandomException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public TestRandomException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
