package com.ielts.cmds.common.logger.util;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.config.LoggerConfig;
import org.junit.jupiter.api.Test;

import com.ielts.cmds.common.logger.model.CMDSLambdaLoggerConfig;

class CMDSLambdaLoggerUtilTest {
	
	@Test
	void when_configureLogger_IsCalled_ExpectPassedConfigurationToBeSet() {
		CMDSLambdaLoggerUtil lambdaLoggerUtil = new CMDSLambdaLoggerUtil();
		LoggerContext ctx = (LoggerContext) LogManager.getContext(false);
    	Configuration config = ctx.getConfiguration();
    	LoggerConfig loggerConfig = new LoggerConfig("com.ielts.cmds.root", Level.DEBUG, false);
		config.addLogger("com.ielts.cmds.root", loggerConfig);
    	assertEquals(Level.DEBUG, loggerConfig.getLevel());
    	Map<String, String> envVariables = new HashMap<>();
    	envVariables.put("logging_com_test_something", "FATAL");
    	envVariables.put("logging_com_ielts_cmds", "INFO");
    	envVariables.put("logging_org_test_something", "WARN");
    	CMDSLambdaLoggerConfig lambdaLoggerConfig = new CMDSLambdaLoggerConfig();
    	lambdaLoggerConfig.setLoggerPrefixLevel(envVariables);
    	lambdaLoggerUtil.configureLogger(lambdaLoggerConfig);
    	assertEquals(Level.INFO, config.getLoggerConfig("com.ielts.cmds").getLevel());
    	assertEquals(Level.FATAL, config.getLoggerConfig("com.test.something").getLevel());
    	assertEquals(Level.WARN, config.getLoggerConfig("org.test.something").getLevel());
	}

}
