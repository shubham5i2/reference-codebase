package com.ielts.cmds.common.error.categorizer;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ErrorConfigLoaderTest {

	//@Test
	void testGetTransientErrors() {
		fail("Not yet implemented"); // TODO
	}

	//@Test
	void testGetIntransientErrors() {
		fail("Not yet implemented"); // TODO
	}

}
