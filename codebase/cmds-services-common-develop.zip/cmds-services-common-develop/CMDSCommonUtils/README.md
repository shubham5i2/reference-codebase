# Amazon S3 Common Component

## Overview:

Main purpose of Amazon S3 common component library
is to perform different operations
on S3 bucket like
- getting an object from S3 bucket
- upload file to S3 bucket
- generate presignedUrl
- check the presence of an object in S3 bucket
- delete object from S3 bucket
- delete all object with prefix from S3 bucket
- check the presence of an s3 bucket in S3

## How to include in your project






Use below maven dependency to include in your project
```
  <dependency>
			<groupId>com.ielts.cmds.common</groupId>
			<artifactId>CMDSCommonUtils</artifactId>
			<version>latest-CMDSCommonUtils-version</version>
  </dependency>

```
## Usage
- getObject method returns S3Object by taking S3 bucket name and S3 object name as parameters.
```
S3Object getObject(final String bucketName, final String objectName);
```

- uploadObject method is used to upload a file to a given S3 bucket
```
PutObjectResult uploadObject(final String bucketName, final String objectName, final File fileContent);
```

- doesObjectExist method checks if required object is present in the given S3 bucket
```
boolean doesObjectExist(final String bucketName, final String objectName);
```

- getPresignUrl method generates PresignedUrl for a given file which is present in the S3 bucket
```
URL getPresignUrl(final String bucketName, final String objectName, final int timeOutInSecond);
```
   
- deleteObject method delete object by taking S3 bucket name and S3 object name as parameters.
```
  void deleteObject(final String bucketName, final String objectName);
```


- deleteAllObjects method delete all objects by taking S3 bucket name and prefix as parameters.
```
  DeleteObjectsResult deleteAllObjects(final String bucketName, final String prefix);
```

- doesBucketExist method checks if bucket exist in s3 bucket by taking bucketName as parameters
```
  boolean doesBucketExist(String bucketName);
```


## Change Log
### 0.0.28 (Feature Release)
- Dynamic Logging for lambdas.

### 0.0.25 (CI file update)
- Release version of CommonUtils: CI file baselined

### 0.0.24 (Baseline Release)
- Baseline release version of CommonUtils

### 0.0.20-SNAPSHOT (Feature Enhancement)
- Removed aws sdk v1 dependency
- Updated aws sdk v2 version

### 0.0.18-SNAPSHOT (Feature Enhancement)
- added deleteObject, deleteAllObjects and doesBucketExist methods in s3 utils
