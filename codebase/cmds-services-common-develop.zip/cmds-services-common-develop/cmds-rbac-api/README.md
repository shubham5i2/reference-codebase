
# RBAC API Library 

## Overview

RBAC library is a java implementation of RBAC services that aims to unify common functions that would be required by all MXs that needs to validate RBAC. In order to use these common functions MX supplies as arguments JWT and criteria for product(s), location(s) and permission(s) required. RBAC library evaluates access according to the criteria.
RBAC service is a mediator service that encapsulates the algorithm for interaction between Location Hierarchy, Product Hierarchy and User groups configurations. All services should be injected as dependencies into the RBAC service bean to provide seamless integration.
This library mainly contains RBACService Interface, a reference implementation of service, an RBAC Utility class and other supporting classes which helps different CMDS microservices to check access control for a user for an operation.

**Design Link:** 
https://confluence.britishcouncil.org/display/IMPS/AF072+Auth0+infrastructure+and+application+integration
https://confluence.britishcouncil.org/display/IMPS/MX+RBAC+using+JWT+claims


## Pre-requisites
- For using RBAC Service a Microservice needs to have location , product, user group related data inside its database which RBAC Service Implementation uses for making decisions on access/authorization.

##  RBACService Interface Contract

    // Basic validation for simple authorisation which requires permission but it not restricted by location or product
      boolean isAuthorised(String accessToken, String permissionId) throws RbacValidationException; 
      
    // Authorisation which requires permission to be granted for a specific location (irrespective of location status)
      boolean isAuthorisedInLocation(String accessToken, String permissionId, UUID locationUuid) throws RbacValidationException;
      
    // Authorisation which requires permission to be granted for a specific partner
      boolean isAuthorisedForPartner(String accessToken, String permissionId, String partnerCode) throws RbacValidationException;
      
    //Authorisation which requires permission to be granted for a specific product
      boolean isAuthorisedForProduct(String accessToken, String permissionId, UUID productUuid) throws RbacValidationException;
      
    // Authorisation which requires permission to be granted for a specific location (irrespective of location status) for a specific product
    boolean isAuthorisedInLocationForProduct(
      String accessToken, String permissionId, UUID locationUuid, UUID productUuid) throws RbacValidationException;
      
    // Execute code in callback which requires permission to be granted for a specific location (irrespective of location status) for a specific product
    <T> T executeWithAuthorisation(String accessToken,String permissionId, UUID locationUuid,UUID productUuid,     RBACCallback<T> cb)  throws RbacValidationException;

    // Get CmdsAuthentication by decoding accessToken
    CmdsAuthentication getCmdsAuthentication(final String accessToken) throws RbacValidationException;

    //Authorisation which requires permission to be granted for a specific location (either with Active status or with all statuses - Active/Inactive/Suspended based on isActiveLocation flag value)
      boolean isAuthorisedInLocation(String accessToken, String permissionId, UUID locationUuid, boolean isActiveLocation) throws RbacValidationException;

    // Execute code in callback which requires permission to be granted for a specific location(either with Active status or with all statuses - Active/Inactive/Suspended based on isActiveLocation flag value) 
       for a specific product
    <T> T executeWithAuthorisation(String accessToken,String permissionId, UUID locationUuid,UUID productUuid, boolean isActiveLocation, RBACCallback<T> cb)  throws RbacValidationException;   

    // Authorisation which requires permission to be granted for a specific location (either with Active status or with all statuses - Active/Inactive/Suspended based on isActiveLocation flag value) 
       for a specific product
    boolean isAuthorisedInLocationForProduct(
    String accessToken, String permissionId, UUID locationUuid, UUID productUuid, boolean isActiveLocation)   throws RbacValidationException;

    //Get all available permission for a specific token 
       Set<String> getAvailablePermissions(final String accessToken) throws RbacValidationException;

 
##  LocationHierarchyService Interface Contract 
    //Get location root node
      LocationNode getRoot();

    //The method aim's at to get branch hierarchy just by passing locationUuid as parameter <br>
      and it will return location node<br>
      eg. If you have pass locationUuid for test centre it will return location node<br>
      with contain parent as well as set of child node
      LocationNode getLocationBranchByLocationUuid(UUID locationUuid) throws RbacValidationException;

    //The method aim's at to get set of child locationUuid's and given locationUuid by passing 
      locationUuid and temporal instance (LocalDate instance). We are checking all locations irrespective of location status   
      Set<UUID> getUuidsOfLocationBranchByLocationUuid(UUID locationUuid, Temporal now) throws RbacValidationException;

    //The method aim's at to get set of child locationUuid's and given locationUuid by passing 
      locationUuid and temporal instance (LocalDate instance). We are checking either ACTIVE locations
      or for all locations irrespective of the status - ACTIVE/INACTIVE/SUSPENDED based on isActiveLocation flag value.    
     Set<UUID> getUuidsOfLocationBranchByLocationUuid(UUID locationUuid, Temporal now, boolean isActiveLocation) throws RbacValidationException;

    //When you pass the list of locationUuid's for testCenter then it will return test centre
      locationUuid and its child locationUuid's inside a set
     Set<UUID> getUuidsOfLocationBranchByLocationUuidList(final List<UUID> locationUuidList, final Temporal now) throws RbacValidationException;


## RBAC Utility Classes
### RBACServiceUtil

    public static List<ClaimDetails> getClaimList(final CmdsAuthentication decodeAccessToken) 
    public static List<UUID> getLocationUuids(final List<ClaimDetails> claims) 
    public static List<UUID> getLocationUuids(final CmdsAuthentication decodeAccessToken) 
    public static List<UUID> getGroupUuids(final List<ClaimDetails> claims) 
    public static List<UUID> getGroupUuids(final CmdsAuthentication decodeAccessToken)

### AuditDataUtils
This class provides methods for populating CMDS [BaseEvent's](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-services-common/-/blob/develop/CMDSEventHeader/src/main/java/com/ielts/cmds/infrastructure/event/BaseEvent.java) [BaseAudit](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-services-common/-/blob/develop/CMDSEventHeader/src/main/java/com/ielts/cmds/infrastructure/event/BaseAudit.java) section

    // Method to set the authentication in Security Context and populate audit fields  
    public void withSecurityContext(
			final BaseEvent<? extends BaseHeader> cmdsEvent,
			final AuditCallback auditCallback) throws RbacValidationException 
	 // Default method to populate screen action and permission in base audit
	 public BaseAudit populateAuditContext(BaseAudit audit, String permission, String screen, String action) 
	 public BaseAudit populateAuditContext(BaseAudit audit, String permission)

## Implementation Guidelines

### Microservice Changes

#### Changes to pom.xml

Add below dependency to `pom.xml` and replace `REPLACE_LATEST_VERSION_FROM_CHANGELOG` to the latest version as per the changelog in the below example code

**Example:**

```
        <dependency>
            <groupId>com.ielts.cmds.common</groupId>
            <artifactId>cmds-rbac-implementation</artifactId>
            <version>0.0.8-SNAPSHOT</version>
            <exclusions>
            	<exclusion>
            		<groupId>com.ielts.cmds.common</groupId>
            		<artifactId>cmds-auth0-validation</artifactId>             
            	</exclusion>
            </exclusions>
        </dependency>
        
        <dependency>
            <groupId>com.ielts.cmds.common</groupId>
            <artifactId>cmds-auth0-validation</artifactId>
            <version>0.0.7-SNAPSHOT</version>
        </dependency>
```

#### Usage of RBAC Service in CMDS Microservice

To use RBAC features in a CMDS microservice, the class needs to autowire RBACService and call different public methods exposed.

**Example:**

```
@Autowired private RBACService rbacService;
    
     if (rbacService.isAuthorisedInLocation(xAccessToken, permissionId, locationUuid)) {
                System.out.println("User is authorized");
     } else {
                System.out.println("User is NOT authorized");
     }
```



## Change Log

### 0.0.16 (Prevent x-Access Token to be printed in loggers(Update CMDSEventHeader version to 0.0.21))

### 0.0.15 (Release for Libs Upgrade)
- Added new method inside LocationHierarchyService Interface Contract which will accept list of locationUuid's and return unique set of location uuid's for each test centre and it's childs

### 0.0.14 (Release for Libs Upgrade)

### 0.0.13 (Baseline Release)
- Baseline release version of cmds-rbac-api

### 0.0.12-SNAPSHOT 
- Added conditional BAseAudit population based on rbacService existence  


### 0.0.11-SNAPSHOT 
- Location specific new methods are added to support either only Active locations or all locations irrespective of its status (Active, Inactive and Suspended) based on isActiveLocation flag value.  
 
### 0.0.10-SNAPSHOT (Feature Enhancement)
- Base Implementation of RBAC API


