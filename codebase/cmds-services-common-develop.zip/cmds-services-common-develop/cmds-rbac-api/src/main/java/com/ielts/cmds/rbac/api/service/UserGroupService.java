package com.ielts.cmds.rbac.api.service;

import java.util.Set;
import java.util.UUID;

import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;

public interface UserGroupService {
  /**
   * Retrieve all permissions' IDs available to this user group
   *
   * @throws RbacValidationException
   */
  Set<String> getAvailablePermissions(UUID userGroupUuid) throws RbacValidationException;

  /**
   * Retrieve all products' UUIDs available to this user group
   *
   * @throws RbacValidationException
   */
  Set<UUID> getAvailableProducts(UUID userGroupUuid) throws RbacValidationException;
}
