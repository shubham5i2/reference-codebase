package com.ielts.cmds.rbac.api.service.model;

import java.util.Collection;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

import lombok.Getter;

@Getter
public class CmdsAuthentication extends UsernamePasswordAuthenticationToken {

  private static final long serialVersionUID = 8085058782416276074L;
  private UserDetails userDetails;

  public CmdsAuthentication(
      Object principal,
      Object credentials,
      Collection<? extends GrantedAuthority> authorities,
      UserDetails userDetails) {
    super(principal, credentials, authorities);
    this.userDetails = userDetails;
  }
}
