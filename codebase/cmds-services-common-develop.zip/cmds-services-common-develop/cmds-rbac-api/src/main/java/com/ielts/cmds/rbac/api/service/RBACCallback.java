package com.ielts.cmds.rbac.api.service;

import java.util.Set;
import java.util.UUID;

import com.ielts.cmds.rbac.api.service.model.CmdsAuthentication;

public interface RBACCallback<T> {

  T executeWith(
      CmdsAuthentication auth,
      boolean isAuthorised,
      Set<UUID> locationUuids,
      Set<UUID> productUuids,
      Set<UUID> groupUuids);
}
