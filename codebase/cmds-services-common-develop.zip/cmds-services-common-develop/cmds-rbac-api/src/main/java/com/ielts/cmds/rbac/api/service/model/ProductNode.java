package com.ielts.cmds.rbac.api.service.model;

import java.time.LocalDate;
import java.time.temporal.Temporal;
import java.util.Set;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.google.gson.annotations.SerializedName;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductNode {
  private UUID productUuid;
  private String productName;

  @JsonDeserialize(using = LocalDateDeserializer.class)
  @JsonSerialize(using = LocalDateSerializer.class)
  @JsonFormat(pattern = "yyyy-MM-dd")
  @SerializedName("availableFromDate")
  private LocalDate availableFromDate;

  @JsonDeserialize(using = LocalDateDeserializer.class)
  @JsonSerialize(using = LocalDateSerializer.class)
  @JsonFormat(pattern = "yyyy-MM-dd")
  @SerializedName("availableToDate")
  private LocalDate availableToDate;

  @JsonBackReference private ProductNode parent;
  @JsonManagedReference private Set<ProductNode> children;

  /** Method that will respond with true or false depending on whether the node is active or not */
  public boolean isActive(Temporal now) {
    final LocalDate currentDate = LocalDate.from(now);
    return (currentDate.compareTo(availableFromDate) >= 0
        && currentDate.compareTo(availableToDate) <= 0);
  }
}
