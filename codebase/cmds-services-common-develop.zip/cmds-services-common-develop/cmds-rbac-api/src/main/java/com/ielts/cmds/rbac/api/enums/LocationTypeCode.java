package com.ielts.cmds.rbac.api.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum LocationTypeCode {
  GLOBAL("GLOBAL"),
  PARTNER("PARTNER"),
  REGION("REGION"),
  COUNTRY("COUNTRY"),
  TEST_CENTRE("TEST_CENTRE"),
  VIRTUAL_BUILDING("VIRTUAL_BUILDING"),
  PHYSICAL_BUILDING("PHYSICAL_BUILDING"),
  ROOM("ROOM");

  private String value;
}
