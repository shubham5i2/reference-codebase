package com.ielts.cmds.rbac.api.utils;

import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import org.springframework.security.core.context.SecurityContextHolder;

import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rbac.api.service.AuditCallback;
import com.ielts.cmds.rbac.api.service.RBACService;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.api.service.model.CmdsAuthentication;

import lombok.AllArgsConstructor;

/**
 * Utility Service Class to perform audit related actions
 * 
 * @author nshrir
 *
 */
@AllArgsConstructor
public class AuditDataUtils {

	private RBACService rbacService;

	/**
	 * Method to set the authentication in Security Context and populate audit fields
	 * 
	 * @param cmdsEvent
	 * @param auditCallback
	 * @throws RbacValidationException 
	 */
	public void withSecurityContext(
			final BaseEvent<? extends BaseHeader> cmdsEvent,
			final AuditCallback auditCallback) throws RbacValidationException {
		try {
			if (Objects.nonNull(rbacService)) {
				final CmdsAuthentication authentication = 
						rbacService.getCmdsAuthentication(cmdsEvent.getEventHeader().getXaccessToken());
				SecurityContextHolder.getContext().setAuthentication(authentication);
				populateAuditFields(cmdsEvent, authentication);
			}
			populateAuditFields(cmdsEvent);
			auditCallback.executeWithAudit(cmdsEvent);
		} finally {
			SecurityContextHolder.clearContext();
		}
	}
	
	/**
	 * Method to populate audit fields without RBAC authentication data
	 * 
	 * @param cmdsEvent
	 * @param authentication
	 */
	private void populateAuditFields(BaseEvent<? extends BaseHeader> cmdsEvent) {
		final BaseAudit audit = Optional.ofNullable(cmdsEvent.getAudit()).orElseGet(BaseAudit::new);
		audit.setCausedByCorrelationId(cmdsEvent.getEventHeader().getCorrelationId());
		audit.setCausedByTransactionId(cmdsEvent.getEventHeader().getTransactionId());
		audit.setCausedByEventName(cmdsEvent.getEventHeader().getEventName());
		audit.setCausedByEventDateTime(cmdsEvent.getEventHeader().getEventDateTime().atOffset(ZoneOffset.UTC));
		
		cmdsEvent.setAudit(audit);
		
	}

	/**
	 * Method to populate audit fields
	 * 
	 * @param cmdsEvent
	 * @param authentication
	 */
	private void populateAuditFields(BaseEvent<? extends BaseHeader> cmdsEvent, CmdsAuthentication authentication) {
		final BaseAudit audit = Optional.ofNullable(cmdsEvent.getAudit()).orElseGet(BaseAudit::new);
		audit.setCausedByCorrelationId(cmdsEvent.getEventHeader().getCorrelationId());
		audit.setCausedByTransactionId(cmdsEvent.getEventHeader().getTransactionId());
		audit.setCausedByEventName(cmdsEvent.getEventHeader().getEventName());
		audit.setCausedByEventDateTime(cmdsEvent.getEventHeader().getEventDateTime().atOffset(ZoneOffset.UTC));
		audit.setPrincipalId(authentication.getName());
		Optional.ofNullable(
				authentication.getUserDetails()).ifPresent(
						userDetails -> audit.setPrincipalName(userDetails.getEmail()));
		cmdsEvent.setAudit(audit);
	}

	/**
	 * Method to set the authentication in Security Context and populate audit fields
	 *
	 * @param cmdsEvent
	 * @param auditCallback
	 * @throws RbacValidationException
	 */
	public void withSecurityContext(
			final BaseEvent<? extends BaseHeader> cmdsEvent,
			String principalId, String principalName, String permission, final AuditCallback auditCallback) throws RbacValidationException {
		populateAuditFields(cmdsEvent, principalId,principalName,permission);
		auditCallback.executeWithAudit(cmdsEvent);
	}

	private void populateAuditFields(BaseEvent<? extends BaseHeader> cmdsEvent, String principalId, String principalName, String permission) {
		BaseAudit audit = Optional.ofNullable(cmdsEvent.getAudit()).orElseGet(BaseAudit::new);
		audit.setPrincipalId(principalId);
		audit.setPrincipalName(principalName);
		audit.setPermission(permission);
		audit.setCausedByEventName(cmdsEvent.getEventHeader().getEventName());
		audit.setCausedByEventDateTime(cmdsEvent.getEventHeader().getEventDateTime().atOffset(ZoneOffset.UTC));
		audit.setCausedByCorrelationId(cmdsEvent.getEventHeader().getCorrelationId());
		audit.setCausedByTransactionId(cmdsEvent.getEventHeader().getTransactionId());
		audit.setAuditContext(new HashMap<>());
		cmdsEvent.setAudit(audit);
	}

	/**
	 * Default method to populate screen action and permission in base audit
	 *
	 * @param audit
	 */
	public BaseAudit populateAuditContext(BaseAudit audit, String permission, String screen, String action) {
		audit.setPermission(permission);
		Map<String, String> auditContext = Optional.ofNullable(audit.getAuditContext()).orElseGet(HashMap<String, String>::new);
		auditContext.put("screen", screen);
		auditContext.put("action", action);
		audit.setAuditContext(auditContext);
		return audit;
	}
	/**
	 * Default method to populate screen action and permission in base audit
	 *
	 * @param audit
	 */
	public BaseAudit populateAuditContext(BaseAudit audit, String permission) {
		audit.setPermission(permission);
		Map<String, String> auditContext = Optional.ofNullable(audit.getAuditContext()).orElseGet(HashMap<String, String>::new);
		audit.setAuditContext(auditContext);
		return audit;
	}
}
