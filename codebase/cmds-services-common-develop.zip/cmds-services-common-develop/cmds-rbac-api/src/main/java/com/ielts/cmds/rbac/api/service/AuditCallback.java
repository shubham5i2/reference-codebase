package com.ielts.cmds.rbac.api.service;

import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;

/**
 * Callback Functional interface for audit
 * 
 * @author nshrir
 *
 */
@FunctionalInterface
public interface AuditCallback {
	
	/**
	 * Set Spring Security Security Context and populate audit fields
	 * 
	 * @param cmdsEvent
	 */
	void executeWithAudit(BaseEvent<? extends BaseHeader> cmdsEvent);
}
