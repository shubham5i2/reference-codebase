package com.ielts.cmds.rbac.api.service.model;

import java.util.UUID;

import org.springframework.security.core.GrantedAuthority;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class ClaimDetails implements GrantedAuthority {
  /** */
  private static final long serialVersionUID = 7076479953524684042L;
  /** */
  private UUID locationUuid;

  private UUID groupUuid;

  @Override
  public String getAuthority() {
    return "l:" + locationUuid + "/g:" + groupUuid;
  }
}
