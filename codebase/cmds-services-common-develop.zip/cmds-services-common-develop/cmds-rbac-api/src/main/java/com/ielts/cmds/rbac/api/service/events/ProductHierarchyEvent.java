package com.ielts.cmds.rbac.api.service.events;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductHierarchyEvent {

  private String message;
}
