package com.ielts.cmds.rbac.api.service.events;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserGroupHierarchyEvent {
  private String message;
}
