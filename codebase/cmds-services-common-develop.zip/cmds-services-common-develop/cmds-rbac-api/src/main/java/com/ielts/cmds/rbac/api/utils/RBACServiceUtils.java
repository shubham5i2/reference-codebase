package com.ielts.cmds.rbac.api.utils;

import java.util.Collection;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.security.core.GrantedAuthority;

import com.ielts.cmds.rbac.api.service.model.ClaimDetails;
import com.ielts.cmds.rbac.api.service.model.CmdsAuthentication;

public final class RBACServiceUtils {

  /**
   * This method aims at to retrieve all claimDetail list using Authentication object
   *
   * @param decodeAccessToken
   * @return
   */
  public static List<ClaimDetails> getClaimList(final CmdsAuthentication decodeAccessToken) {
    final Collection<GrantedAuthority> authorities = decodeAccessToken.getAuthorities();
    return authorities.stream().map(claim -> (ClaimDetails) claim).collect(Collectors.toList());
  }

  public static List<UUID> getLocationUuids(final List<ClaimDetails> claims) {
    return claims.stream().map(ClaimDetails::getLocationUuid).collect(Collectors.toList());
  }

  public static List<UUID> getLocationUuids(final CmdsAuthentication decodeAccessToken) {
    return getClaimList(decodeAccessToken)
        .stream()
        .map(ClaimDetails::getLocationUuid)
        .collect(Collectors.toList());
  }

  public static List<UUID> getGroupUuids(final List<ClaimDetails> claims) {
    return claims.stream().map(ClaimDetails::getGroupUuid).collect(Collectors.toList());
  }

  public static List<UUID> getGroupUuids(final CmdsAuthentication decodeAccessToken) {
    return getClaimList(decodeAccessToken)
        .stream()
        .map(ClaimDetails::getGroupUuid)
        .collect(Collectors.toList());
  }
}
