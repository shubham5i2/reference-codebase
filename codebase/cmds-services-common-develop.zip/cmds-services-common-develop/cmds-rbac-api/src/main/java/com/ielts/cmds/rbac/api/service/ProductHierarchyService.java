package com.ielts.cmds.rbac.api.service;

import java.time.temporal.Temporal;
import java.util.Set;
import java.util.UUID;

import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.api.service.model.ProductNode;

public interface ProductHierarchyService {
  /**
   * The method aim's at to get branch of hierarchy just by passing productUuid as parameter <br>
   * and it will return product node<br>
   * eg. If you have pass productUuid for product it will return product node<br>
   * with contain parent as well as set of child node
   *
   * @throws RbacValidationException
   */
  ProductNode getProductBranchByProductUuid(UUID productUuid) throws RbacValidationException;

  /**
   * The method aim's at to get set of child productUuid's and given productUuid by passing <br>
   * productUuid and temporal instance (LocalDate instance) <br>
   * eg. If you are passing productUuid for product then it will return <br>
   * given productUuid and its child productUuid's
   *
   * @throws RbacValidationException
   */
  Set<UUID> getUuidsOfProductBranchByProductUuid(UUID productUuid, Temporal now)
      throws RbacValidationException;
}
