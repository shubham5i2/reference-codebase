package com.ielts.cmds.rbac.api.service.model;

import java.time.temporal.Temporal;
import java.util.Set;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.ielts.cmds.rbac.api.enums.LocationStatus;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class LocationNode {
  private UUID locationUuid;
  private String partnerCode;
  private String locationName;
  private String locationType;
  private String locationCode;
  private String status;

  @JsonBackReference private LocationNode parent;
  @JsonManagedReference private Set<LocationNode> children;

  /** Method that will respond with true or false depending on whether the node is active or not */
  public boolean isActive(final Temporal now) {
    return LocationStatus.ACTIVE.getValue().equalsIgnoreCase(status);
  }
}
