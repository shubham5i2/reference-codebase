package com.ielts.cmds.rbac.api.service;

import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.api.service.model.CmdsAuthentication;

public interface JWTDecoder {
  /**
   * Decodes access token (JWT) into a Spring security Authentication object transforming claims
   * into GrantedAuthority objects
   *
   * @param accessToken
   * @return
   * @throws RbacValidationException
   */
  CmdsAuthentication decodeAccessToken(String accessToken) throws RbacValidationException;
}
