package com.ielts.cmds.rbac.api.service;

import java.util.Set;
import java.util.UUID;

import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.api.service.model.CmdsAuthentication;

public interface RBACService {

  /**
   * Basic validation for simple authorisation which requires permission but it not restricted by
   * location or product
   *
   * @throws RbacValidationException
   */
  boolean isAuthorised(String accessToken, String permissionId) throws RbacValidationException;

  /**
   * Authorisation which requires permission to be granted for a specific location (irrespctive of
   * status)
   *
   * @throws RbacValidationException
   */
  boolean isAuthorisedInLocation(String accessToken, String permissionId, UUID locationUuid)
      throws RbacValidationException;

  /**
   * Authorisation which requires permission to be granted for a specific location. Based on
   * isActiveLocation flag value , it will consider only Active locations (for flag value true) or
   * all locations (for flag value false) irrespective of the status
   *
   * @throws RbacValidationException
   */
  boolean isAuthorisedInLocation(
      String accessToken, String permissionId, UUID locationUuid, boolean isActiveLocation)
      throws RbacValidationException;

  /**
   * Authorisation which requires permission to be granted for a specific partner
   *
   * @throws RbacValidationException
   */
  boolean isAuthorisedForPartner(String accessToken, String permissionId, String partnerCode)
      throws RbacValidationException;

  /**
   * Authorisation which requires permission to be granted for a specific product
   *
   * @throws RbacValidationException
   */
  boolean isAuthorisedForProduct(String accessToken, String permissionId, UUID productUuid)
      throws RbacValidationException;

  /**
   * Authorisation which requires permission to be granted for a specific location (irrespective of
   * its status) for a specific product
   *
   * @throws RbacValidationException
   */
  boolean isAuthorisedInLocationForProduct(
      String accessToken, String permissionId, UUID locationUuid, UUID productUuid)
      throws RbacValidationException;

  /**
   * Authorisation which requires permission to be granted for a specific location for a specific
   * product. Based on isActiveLocation flag value , it will consider only Active locations (for
   * flag value true) or all locations (for flag value false) irrespective of the status
   *
   * @throws RbacValidationException
   */
  boolean isAuthorisedInLocationForProduct(
      String accessToken,
      String permissionId,
      UUID locationUuid,
      UUID productUuid,
      boolean isActiveLocation)
      throws RbacValidationException;

  /**
   * Execute code in callback which requires permission to be granted for a specific location
   * (irrespective of status) for a specific product
   *
   * @throws RbacValidationException
   */
  <T> T executeWithAuthorisation(
      String accessToken,
      String permissionId,
      UUID locationUuid,
      UUID productUuid,
      RBACCallback<T> cb)
      throws RbacValidationException;

  /**
   * Execute code in callback which requires permission to be granted for a specific location for a
   * specific product. Based on isActiveLocation flag value , it will consider only Active locations
   * (for flag value true) or all locations (for flag value false) irrespective of the status
   *
   * @throws RbacValidationException
   */
  <T> T executeWithAuthorisation(
      String accessToken,
      String permissionId,
      UUID locationUuid,
      UUID productUuid,
      boolean isActiveLocation,
      RBACCallback<T> cb)
      throws RbacValidationException;

  /**
   * Get {@link CmdsAuthentication} by decoding accessToken
   *
   * @param accessToken
   * @return {@link CmdsAuthentication}
   * @throws RbacValidationException
   */
  CmdsAuthentication getCmdsAuthentication(final String accessToken) throws RbacValidationException;

  /**
   * Get all available permission for a specific token
   *
   * @param accessToken
   * @return
   * @throws RbacValidationException
   */
  Set<String> getAvailablePermissions(final String accessToken) throws RbacValidationException;
}
