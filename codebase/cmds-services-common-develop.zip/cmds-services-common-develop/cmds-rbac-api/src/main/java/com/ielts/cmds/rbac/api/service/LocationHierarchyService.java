package com.ielts.cmds.rbac.api.service;

import java.time.temporal.Temporal;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.api.service.model.LocationNode;

public interface LocationHierarchyService {
  /**
   * The method aim's at to get location root node just by calling getRoot()<br>
   * eg. In location hierarchy root node will be Global and global node having its children
   */
  LocationNode getRoot();

  /**
   * The method aim's at to get branch hierarchy just by passing locationUuid as parameter <br>
   * and it will return location node<br>
   * eg. If you have pass locationUuid for test centre it will return location node<br>
   * with contain parent as well as set of child node
   *
   * @throws RbacValidationException
   */
  LocationNode getLocationBranchByLocationUuid(UUID locationUuid) throws RbacValidationException;

  /**
   * The method aim's at to get set of child locationUuid's and given locationUuid by passing <br>
   * locationUuid and temporal instance (LocalDate instance) but currently we are checking ACTIVE
   * location only <br>
   * eg. If you are passing locationUuid for testCenter then it will return test<br>
   * centre locationUuid and its child locationUuid's
   *
   * @throws RbacValidationException
   */
  Set<UUID> getUuidsOfLocationBranchByLocationUuid(UUID locationUuid, Temporal now)
      throws RbacValidationException;

  /**
   * The method aim's at to get set of child locationUuids and given locationUuid by passing <br>
   * locationUuid and temporal instance (LocalDate instance). we are checking either ACTIVE
   * locations or all locations (with the status - ACTIVE/INACTIVE/SUSPENDED) based on flag value
   * <br>
   * eg. If you are passing locationUuid for testCenter then it will return test<br>
   * centre locationUuid and its child locationUuids If you are passing isActiveLocation flag value
   * as true, then it will check only for ACTIVE <br>
   * locations else for all locations irrespective of the status.
   *
   * @throws RbacValidationException
   */
  Set<UUID> getUuidsOfLocationBranchByLocationUuid(
      UUID locationUuid, Temporal now, boolean isActiveLocation) throws RbacValidationException;

  /**
   * When you pass the list of locationUuid's for testCenter then it will return test centre
   * locationUuid and its child locationUuid's inside a set
   *
   * @throws RbacValidationException
   */
  public Set<UUID> getUuidsOfLocationBranchByLocationUuidList(
      final List<UUID> locationUuidList, final Temporal now) throws RbacValidationException;
}
