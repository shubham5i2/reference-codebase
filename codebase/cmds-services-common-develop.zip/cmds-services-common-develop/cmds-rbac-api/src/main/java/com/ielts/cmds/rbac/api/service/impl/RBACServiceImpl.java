package com.ielts.cmds.rbac.api.service.impl;

import java.time.LocalDate;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.ielts.cmds.rbac.api.service.JWTDecoder;
import com.ielts.cmds.rbac.api.service.LocationHierarchyService;
import com.ielts.cmds.rbac.api.service.ProductHierarchyService;
import com.ielts.cmds.rbac.api.service.RBACCallback;
import com.ielts.cmds.rbac.api.service.RBACService;
import com.ielts.cmds.rbac.api.service.UserGroupService;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.api.service.model.ClaimDetails;
import com.ielts.cmds.rbac.api.service.model.CmdsAuthentication;
import com.ielts.cmds.rbac.api.service.model.LocationNode;
import com.ielts.cmds.rbac.api.service.model.ProductNode;
import com.ielts.cmds.rbac.api.service.model.UserDetails;
import com.ielts.cmds.rbac.api.utils.RBACServiceUtils;

@Service
public class RBACServiceImpl implements RBACService {

  private JWTDecoder jwtDecoder;
  private UserGroupService userGroupService;
  private LocationHierarchyService locationHierarchyService;
  private ProductHierarchyService productHierarchyService;

  @Autowired
  public RBACServiceImpl(
      JWTDecoder jwtDecoder,
      UserGroupService userGroupService,
      LocationHierarchyService locationHierarchyService,
      ProductHierarchyService productHierarchyService) {
    super();
    this.jwtDecoder = jwtDecoder;
    this.userGroupService = userGroupService;
    this.locationHierarchyService = locationHierarchyService;
    this.productHierarchyService = productHierarchyService;
  }

  /** This method aims at to validate user is authorised or not against permissionID */
  @Override
  public boolean isAuthorised(final String accessToken, final String permissionId)
      throws RbacValidationException {
    return isAuthorised(jwtDecoder.decodeAccessToken(accessToken), permissionId);
  }

  @Override
  public Set<String> getAvailablePermissions(final String accessToken)
      throws RbacValidationException {
    return getAllAvailablePermissions(jwtDecoder.decodeAccessToken(accessToken));
  }

  /**
   * This method aims at to retrieved all permissionIds validate with given permisionId
   *
   * @param decodeAccessToken
   * @param permissionId
   * @return
   * @throws RbacValidationException
   */
  private boolean isAuthorised(
      final CmdsAuthentication decodeAccessToken, final String permissionId)
      throws RbacValidationException {
    return getAllAvailablePermissions(decodeAccessToken).contains(permissionId);
  }

  /**
   * This method aims at to retrieved all permissionIds
   *
   * @param decodeAccessToken
   * @return
   * @throws RbacValidationException
   */
  private Set<String> getAllAvailablePermissions(final CmdsAuthentication decodeAccessToken)
      throws RbacValidationException {
    final List<ClaimDetails> claimList = RBACServiceUtils.getClaimList(decodeAccessToken);
    final Set<String> allAvailablePermissions = new HashSet<>();

    if (!CollectionUtils.isEmpty(claimList)) {
      for (ClaimDetails claim : claimList) {
        allAvailablePermissions.addAll(getAvailablePermissions(claim.getGroupUuid()));
      }
    }
    return allAvailablePermissions;
  }

  /**
   * This method aims at to retrieve permissionIds against groupId
   *
   * @param groupUuid
   * @return
   * @throws RbacValidationException
   */
  private Set<String> getAvailablePermissions(UUID groupUuid) throws RbacValidationException {
    return userGroupService.getAvailablePermissions(groupUuid);
  }

  /**
   * Authorisation which requires permission to be granted for a specific location It will check for
   * all locations irrespective their location status
   */
  @Override
  public boolean isAuthorisedInLocation(
      final String accessToken, final String permissionId, final UUID locationUuid)
      throws RbacValidationException {
    return isAuthorisedInLocationWithStatus(accessToken, permissionId, locationUuid, false);
  }

  /**
   * Authorisation which requires permission to be granted for a specific location Based on
   * isActiveLocation flag value, It will check for only active locations or all locations
   * irrespective their location status
   */
  @Override
  public boolean isAuthorisedInLocation(
      final String accessToken,
      final String permissionId,
      final UUID locationUuid,
      boolean isActiveLocation)
      throws RbacValidationException {
    return isAuthorisedInLocationWithStatus(
        accessToken, permissionId, locationUuid, isActiveLocation);
  }

  private boolean isAuthorisedInLocationWithStatus(
      final String accessToken,
      final String permissionId,
      final UUID locationUuid,
      final boolean isActiveLocation)
      throws RbacValidationException {
    final LocalDate now = LocalDate.now();
    final LocationNode desiredLocation =
        locationHierarchyService.getLocationBranchByLocationUuid(locationUuid);
    if (isActiveLocation) {
      if (Objects.nonNull(desiredLocation) && !desiredLocation.isActive(now)) {
        return false;
      }
    }
    if (Objects.nonNull(desiredLocation)) {

      final CmdsAuthentication decodeAccessToken = jwtDecoder.decodeAccessToken(accessToken);
      final List<ClaimDetails> claimList = RBACServiceUtils.getClaimList(decodeAccessToken);

      if (!CollectionUtils.isEmpty(claimList)) {

        for (ClaimDetails claim : claimList) {

          final Set<UUID> claimVisibleLocations =
              locationHierarchyService.getUuidsOfLocationBranchByLocationUuid(
                  claim.getLocationUuid(), now, isActiveLocation);

          if (claimVisibleLocations.contains(desiredLocation.getLocationUuid())) {
            // Here we are checking permission (if permissionId is null then we want all access
            // information)
            if (permissionId == null
                || getAvailablePermissions(claim.getGroupUuid()).contains(permissionId)) {
              return true;
            }
          }
        }
      }
    }

    return false;
  }

  /** Authorisation which requires permission to be granted for a specific partner */
  @Override
  public boolean isAuthorisedForPartner(
      final String accessToken, final String permissionId, final String partnerCode)
      throws RbacValidationException {

    final CmdsAuthentication decodeAccessToken = jwtDecoder.decodeAccessToken(accessToken);
    final UserDetails userDetails = decodeAccessToken.getUserDetails();
    if (Objects.nonNull(userDetails) && StringUtils.hasText(userDetails.getPartnerCode())) {
      final String userPartnerCode = userDetails.getPartnerCode();
      final Set<String> allAvailablePermission = getAllAvailablePermissions(decodeAccessToken);
      if (partnerCode.equalsIgnoreCase(userPartnerCode)
          && !CollectionUtils.isEmpty(allAvailablePermission)
          && allAvailablePermission.contains(permissionId)) {
        return true;
      }
    }
    return false;
  }

  /** Authorisation which requires permission to be granted for a specific product */
  @Override
  public boolean isAuthorisedForProduct(
      final String accessToken, final String permissionId, final UUID productUuid)
      throws RbacValidationException {

    final LocalDate now = LocalDate.now();
    final ProductNode desiredProduct =
        productHierarchyService.getProductBranchByProductUuid(productUuid);

    if (Objects.nonNull(desiredProduct) && desiredProduct.isActive(now)) {
      final CmdsAuthentication decodeAccessToken = jwtDecoder.decodeAccessToken(accessToken);
      final List<ClaimDetails> claimList = RBACServiceUtils.getClaimList(decodeAccessToken);

      if (!CollectionUtils.isEmpty(claimList)) {

        for (ClaimDetails claim : claimList) {
          // Here we are checking permission (if permissionId is null then we want all access
          // information)
          if (permissionId == null
              || getAvailablePermissions(claim.getGroupUuid()).contains(permissionId)) {

            final Set<UUID> productUuids =
                userGroupService.getAvailableProducts(claim.getGroupUuid());
            for (UUID claimVisibleProductUuid : productUuids) {
              final Set<UUID> claimVisibleProducts =
                  productHierarchyService.getUuidsOfProductBranchByProductUuid(
                      claimVisibleProductUuid, now);
              if (claimVisibleProducts.contains(desiredProduct.getProductUuid())) {
                return true;
              }
            }
          }
        }
      }
    }
    return false;
  }

  /**
   * Authorisation which requires permission to be granted for a specific location (irrespective of
   * location status) for a specific product
   */
  @Override
  public boolean isAuthorisedInLocationForProduct(
      final String accessToken,
      final String permissionId,
      final UUID locationUuid,
      final UUID productUuid)
      throws RbacValidationException {
    return isAuthorisedInLocationWithStatusForProduct(
        accessToken, permissionId, locationUuid, productUuid, false);
  }

  /**
   * Authorisation which requires permission to be granted for a specific location for a specific
   * product. Based on isActiveLocation flag value, it will check for active locations or all
   * locations irrespective of status
   */
  @Override
  public boolean isAuthorisedInLocationForProduct(
      final String accessToken,
      final String permissionId,
      final UUID locationUuid,
      final UUID productUuid,
      final boolean isActiveLocation)
      throws RbacValidationException {
    return isAuthorisedInLocationWithStatusForProduct(
        accessToken, permissionId, locationUuid, productUuid, isActiveLocation);
  }

  private boolean isAuthorisedInLocationWithStatusForProduct(
      final String accessToken,
      final String permissionId,
      final UUID locationUuid,
      final UUID productUuid,
      final boolean isActiveLocation)
      throws RbacValidationException {

    final LocalDate now = LocalDate.now();
    final LocationNode desiredLocation =
        locationHierarchyService.getLocationBranchByLocationUuid(locationUuid);
    if (isActiveLocation) {
      if (Objects.nonNull(desiredLocation) && !desiredLocation.isActive(now)) {
        return false;
      }
    }
    if (Objects.nonNull(desiredLocation)) {

      final ProductNode desiredProduct =
          productHierarchyService.getProductBranchByProductUuid(productUuid);

      if (Objects.nonNull(desiredProduct) && desiredProduct.isActive(now)) {

        final CmdsAuthentication decodeAccessToken = jwtDecoder.decodeAccessToken(accessToken);

        return isAuthorisedInLocationForProduct(
            decodeAccessToken,
            permissionId,
            desiredLocation.getLocationUuid(),
            desiredProduct.getProductUuid(),
            now,
            isActiveLocation);
      }
    }

    return false;
  }

  /**
   * @param decodeAccessToken
   * @param permissionId
   * @param locationUuid
   * @param productUuid
   * @param now
   * @return
   * @throws RbacValidationException
   */
  private boolean isAuthorisedInLocationForProduct(
      final CmdsAuthentication decodeAccessToken,
      final String permissionId,
      final UUID locationUuid,
      final UUID productUuid,
      final LocalDate now,
      final boolean isActiveLocation)
      throws RbacValidationException {
    final List<ClaimDetails> claimList = RBACServiceUtils.getClaimList(decodeAccessToken);

    if (!CollectionUtils.isEmpty(claimList)) {

      for (ClaimDetails claim : claimList) {
        // Here we are checking permission (if permissionId is null then we want all access
        // information)
        if (permissionId == null
            || getAvailablePermissions(claim.getGroupUuid()).contains(permissionId)) {

          final Set<UUID> claimVisibleLocations =
              locationHierarchyService.getUuidsOfLocationBranchByLocationUuid(
                  claim.getLocationUuid(), now, isActiveLocation);

          // Here we are checking valid location
          if (claimVisibleLocations.contains(locationUuid)) {

            // Here we are checking valid product
            final Set<UUID> productUuids =
                userGroupService.getAvailableProducts(claim.getGroupUuid());

            for (UUID claimVisibleProductUuid : productUuids) {
              final Set<UUID> claimVisibleProducts =
                  productHierarchyService.getUuidsOfProductBranchByProductUuid(
                      claimVisibleProductUuid, now);
              if (claimVisibleProducts.contains(productUuid)) {
                return true;
              }
            }
          }
        }
      }
    }
    return false;
  }

  private Set<UUID> getUserGroupsForAuthorisedInLocationForProduct(
      final CmdsAuthentication decodeAccessToken,
      final String permissionId,
      final UUID locationUuid,
      final UUID productUuid,
      final LocalDate now,
      final boolean isActiveLocation)
      throws RbacValidationException {
    final List<ClaimDetails> claimList = RBACServiceUtils.getClaimList(decodeAccessToken);

    final Set<UUID> claimVisibleGroups = new HashSet<>();
    if (!CollectionUtils.isEmpty(claimList)) {
      for (ClaimDetails claim : claimList) {
        // Here we are checking permission (if permissionId is null then we want all access
        // information)
        if (permissionId == null
            || getAvailablePermissions(claim.getGroupUuid()).contains(permissionId)) {

          final Set<UUID> claimVisibleLocations =
              locationHierarchyService.getUuidsOfLocationBranchByLocationUuid(
                  claim.getLocationUuid(), now, isActiveLocation);

          // Here we are checking valid location
          if (claimVisibleLocations.contains(locationUuid)) {

            // Here we are checking valid product
            final Set<UUID> productUuids =
                userGroupService.getAvailableProducts(claim.getGroupUuid());

            for (UUID claimVisibleProductUuid : productUuids) {
              final Set<UUID> claimVisibleProducts =
                  productHierarchyService.getUuidsOfProductBranchByProductUuid(
                      claimVisibleProductUuid, now);
              if (claimVisibleProducts.contains(productUuid)) {
                claimVisibleGroups.add(claim.getGroupUuid());
              }
            }
          }
        }
      }
    }
    return claimVisibleGroups;
  }

  /**
   * Execute code in callback which requires permission to be granted for a specific location
   * irrespective of location status for a specific product
   */
  @Override
  public <T> T executeWithAuthorisation(
      final String accessToken,
      final String permissionId,
      final UUID locationUuid,
      final UUID productUuid,
      final RBACCallback<T> cb)
      throws RbacValidationException {

    return executeWithAuthorisationAndLocationStatus(
        accessToken, permissionId, locationUuid, productUuid, false, cb);
  }

  /**
   * Execute code in callback which requires permission to be granted for a specific location for a
   * specific product. Based on isActiveLocation flag value, it will check for active locations or
   * all locations irrespective of status
   */
  @Override
  public <T> T executeWithAuthorisation(
      final String accessToken,
      final String permissionId,
      final UUID locationUuid,
      final UUID productUuid,
      final boolean isActiveLocation,
      final RBACCallback<T> cb)
      throws RbacValidationException {

    return executeWithAuthorisationAndLocationStatus(
        accessToken, permissionId, locationUuid, productUuid, isActiveLocation, cb);
  }

  private <T> T executeWithAuthorisationAndLocationStatus(
      final String accessToken,
      final String permissionId,
      final UUID locationUuid,
      final UUID productUuid,
      final boolean isActiveLocation,
      final RBACCallback<T> cb)
      throws RbacValidationException {

    final CmdsAuthentication decodeAccessToken = jwtDecoder.decodeAccessToken(accessToken);

    // if (StringUtils.hasText(permissionId)) {
    if (Objects.nonNull(locationUuid) && Objects.nonNull(productUuid)) {

      return executeWithAuthorizationForLocationAndProduct(
          permissionId, locationUuid, productUuid, cb, decodeAccessToken, isActiveLocation);

    } else if (Objects.nonNull(locationUuid)) {

      return executeWithAuthorizationForLocation(
          permissionId, locationUuid, cb, decodeAccessToken, isActiveLocation);

    } else if (Objects.nonNull(productUuid)) {

      return executeWithAuthorizationForProduct(
          permissionId, productUuid, cb, decodeAccessToken, isActiveLocation);

    } else {
      if (permissionId == null || isAuthorised(decodeAccessToken, permissionId)) {
        // for all claims check groups that have this permission
        // collection of locations - visible branches only from groups that have the permission
        // collection of product - visible branches only from groups that have the permission
        return executeWithAuthorizationIfAuthorized(
            permissionId, cb, decodeAccessToken, isActiveLocation);
      }
    }
    // }
    return cb.executeWith(
        decodeAccessToken,
        false,
        Collections.emptySet(),
        Collections.emptySet(),
        Collections.emptySet());
  }

  private <T> T executeWithAuthorizationIfAuthorized(
      final String permissionId,
      final RBACCallback<T> cb,
      final CmdsAuthentication decodeAccessToken,
      final boolean isActiveLocation)
      throws RbacValidationException {

    final List<ClaimDetails> claimList = RBACServiceUtils.getClaimList(decodeAccessToken);

    final Set<UUID> allVisibleLocations = new HashSet<>();
    final Set<UUID> allVisibleProduct = new HashSet<>();
    final Set<UUID> claimVisibleUserGroups = new HashSet<>();
    final LocalDate now = LocalDate.now();
    if (!CollectionUtils.isEmpty(claimList)) {
      for (ClaimDetails claim : claimList) {
        // Here we are checking permission (if permissionId is null then we want all access
        // information)
        if (permissionId == null
            || getAvailablePermissions(claim.getGroupUuid()).contains(permissionId)) {
          final Set<UUID> claimVisibleLocations =
              locationHierarchyService.getUuidsOfLocationBranchByLocationUuid(
                  claim.getLocationUuid(), now, isActiveLocation);

          allVisibleLocations.addAll(claimVisibleLocations);

          final Set<UUID> productUuids =
              userGroupService.getAvailableProducts(claim.getGroupUuid());
          if (!CollectionUtils.isEmpty(productUuids)) {
            claimVisibleUserGroups.add(claim.getGroupUuid());
            for (UUID claimVisibleProductUuid : productUuids) {
              allVisibleProduct.addAll(
                  productHierarchyService.getUuidsOfProductBranchByProductUuid(
                      claimVisibleProductUuid, now));
            }
          }
        }
      }
    }
    return cb.executeWith(
        decodeAccessToken, true, allVisibleLocations, allVisibleProduct, claimVisibleUserGroups);
  }

  private <T> T executeWithAuthorizationForLocationAndProduct(
      final String permissionId,
      final UUID locationUuid,
      final UUID productUuid,
      final RBACCallback<T> cb,
      final CmdsAuthentication decodeAccessToken,
      final boolean isActiveLocation)
      throws RbacValidationException {

    final LocalDate now = LocalDate.now();
    final LocationNode desiredLocation =
        locationHierarchyService.getLocationBranchByLocationUuid(locationUuid);
    if (isActiveLocation) {
      if (Objects.nonNull(desiredLocation) && !desiredLocation.isActive(now)) {
        return cb.executeWith(
            decodeAccessToken,
            false,
            Collections.emptySet(),
            Collections.emptySet(),
            Collections.emptySet());
      }
    }

    if (Objects.nonNull(desiredLocation)) {

      final ProductNode desiredProduct =
          productHierarchyService.getProductBranchByProductUuid(productUuid);

      if (Objects.nonNull(desiredProduct) && desiredProduct.isActive(now)) {

        final Set<UUID> userGroups =
            getUserGroupsForAuthorisedInLocationForProduct(
                decodeAccessToken,
                permissionId,
                desiredLocation.getLocationUuid(),
                desiredProduct.getProductUuid(),
                now,
                isActiveLocation);

        if (!userGroups.isEmpty()) {
          /*, isActiveLocation*/
          final Set<UUID> locationUuids =
              locationHierarchyService.getUuidsOfLocationBranchByLocationUuid(
                  locationUuid, now, isActiveLocation);
          final Set<UUID> productUuids =
              productHierarchyService.getUuidsOfProductBranchByProductUuid(productUuid, now);
          return cb.executeWith(decodeAccessToken, true, locationUuids, productUuids, userGroups);
        }
      }
    }

    return cb.executeWith(
        decodeAccessToken,
        false,
        Collections.emptySet(),
        Collections.emptySet(),
        Collections.emptySet());
  }

  private <T> T executeWithAuthorizationForProduct(
      final String permissionId,
      final UUID productUuid,
      final RBACCallback<T> cb,
      final CmdsAuthentication decodeAccessToken,
      final boolean isActiveLocation)
      throws RbacValidationException {

    // for all claims check group with matching productUUID
    // collection of location - is the locationUUid branches from assignments (claims)
    // products collection - is product hierarchy for productUUid

    final LocalDate now = LocalDate.now();
    final ProductNode desiredProduct =
        productHierarchyService.getProductBranchByProductUuid(productUuid);

    if (Objects.nonNull(desiredProduct) && desiredProduct.isActive(now)) {

      final List<ClaimDetails> claimList = RBACServiceUtils.getClaimList(decodeAccessToken);

      if (!CollectionUtils.isEmpty(claimList)) {
        final Set<UUID> claimVisibleLocations = new HashSet<>();
        boolean isValidProduct = false;
        final Set<UUID> claimVisibleUserGroups = new HashSet<>();

        for (ClaimDetails claim : claimList) {

          // Here we are checking permission (if permissionId is null then we want all access
          // information)
          if (permissionId == null
              || getAvailablePermissions(claim.getGroupUuid()).contains(permissionId)) {
            final Set<UUID> locationUuids =
                locationHierarchyService.getUuidsOfLocationBranchByLocationUuid(
                    claim.getLocationUuid(), now, isActiveLocation);

            claimVisibleLocations.addAll(locationUuids);

            final Set<UUID> productUuids =
                userGroupService.getAvailableProducts(claim.getGroupUuid());
            for (UUID claimVisibleProductUuid : productUuids) {
              final Set<UUID> claimVisibleProducts =
                  productHierarchyService.getUuidsOfProductBranchByProductUuid(
                      claimVisibleProductUuid, now);
              if (claimVisibleProducts.contains(desiredProduct.getProductUuid())) {
                isValidProduct = true;
                claimVisibleUserGroups.add(claim.getGroupUuid());
              }
            }
          }
        }

        if (isValidProduct) {
          final Set<UUID> uuidsOfProductBranchByProductUuid =
              productHierarchyService.getUuidsOfProductBranchByProductUuid(productUuid, now);
          return cb.executeWith(
              decodeAccessToken,
              true,
              claimVisibleLocations,
              uuidsOfProductBranchByProductUuid,
              claimVisibleUserGroups);
        }
      }
    }
    return cb.executeWith(
        decodeAccessToken,
        false,
        Collections.emptySet(),
        Collections.emptySet(),
        Collections.emptySet());
  }

  private <T> T executeWithAuthorizationForLocation(
      final String permissionId,
      final UUID locationUuid,
      final RBACCallback<T> cb,
      final CmdsAuthentication decodeAccessToken,
      final boolean isActiveLocation)
      throws RbacValidationException {

    // for all claims check the visible branches for locationUUid
    // collection of locations - is a branch of that search
    // collection of products - is the one from the matching group

    final LocalDate now = LocalDate.now();
    final LocationNode desiredLocation =
        locationHierarchyService.getLocationBranchByLocationUuid(locationUuid);
    if (isActiveLocation) {
      if (Objects.nonNull(desiredLocation) && !desiredLocation.isActive(now)) {
        return cb.executeWith(
            decodeAccessToken,
            false,
            Collections.emptySet(),
            Collections.emptySet(),
            Collections.emptySet());
      }
    }
    if (Objects.nonNull(desiredLocation)) {

      final List<ClaimDetails> claimList = RBACServiceUtils.getClaimList(decodeAccessToken);

      if (!CollectionUtils.isEmpty(claimList)) {

        final Set<UUID> claimVisibleLocations = new HashSet<>();
        final Set<UUID> claimVisibleProducts = new HashSet<>();
        final Set<UUID> claimVisibleUserGroups = new HashSet<>();
        for (ClaimDetails claim : claimList) {
          // Here we are checking permission (if permissionId is null then we want all access
          // information)
          if (permissionId == null
              || getAvailablePermissions(claim.getGroupUuid()).contains(permissionId)) {

            final Set<UUID> locationUuids =
                locationHierarchyService.getUuidsOfLocationBranchByLocationUuid(
                    claim.getLocationUuid(), now, isActiveLocation);
            if (locationUuids.contains(desiredLocation.getLocationUuid())) {
              claimVisibleUserGroups.add(claim.getGroupUuid());
              claimVisibleProducts.addAll(
                  userGroupService.getAvailableProducts(claim.getGroupUuid()));
            }
            claimVisibleLocations.addAll(locationUuids);
          }
        }

        // Here we are checking given locationUuid with all VisibleLocations form claims
        if (claimVisibleLocations.contains(desiredLocation.getLocationUuid())) {
          // Here we are getting all underneath locationUuids for given location
          final Set<UUID> locationUuids =
              locationHierarchyService.getUuidsOfLocationBranchByLocationUuid(
                  locationUuid, now, isActiveLocation);

          return cb.executeWith(
              decodeAccessToken, true, locationUuids, claimVisibleProducts, claimVisibleUserGroups);
        }
      }
    }

    return cb.executeWith(
        decodeAccessToken,
        false,
        Collections.emptySet(),
        Collections.emptySet(),
        Collections.emptySet());
  }

  /**
   * Method to return {@link CmdsAuthentication} from accessToken
   *
   * @return {@link CmdsAuthentication}
   */
  @Override
  public CmdsAuthentication getCmdsAuthentication(final String accessToken)
      throws RbacValidationException {

    return jwtDecoder.decodeAccessToken(accessToken);
  }

}
