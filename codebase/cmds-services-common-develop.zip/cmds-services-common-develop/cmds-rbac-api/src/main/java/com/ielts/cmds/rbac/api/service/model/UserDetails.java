package com.ielts.cmds.rbac.api.service.model;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class UserDetails {
  private String partnerCode;
  private String nickName;
  private String id;
  private String email;
  private String firstName;
  private String lastName;
}
