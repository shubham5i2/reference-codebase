package com.ielts.cmds.rbac.api.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/** Enum for LocationStatus */
@Getter
@AllArgsConstructor
public enum LocationStatus {
  ACTIVE("ACTIVE"),
  SUSPENDED("SUSPENDED"),
  INACTIVE("INACTIVE");

  private String value;
}
