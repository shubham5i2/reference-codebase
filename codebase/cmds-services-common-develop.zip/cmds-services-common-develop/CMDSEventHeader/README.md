# Overview:

The intent of this commons library is to standardize message structure that is used by queues across the platform.
It provides basic structure in the form of BaseEvent and supporting classes.

Additionally it provides BaseCommand class that should be used when receiving BaseEvent object from the queue and 
translate them into a command object with specific payload.

# Example usage:

## Read from Queue:

This example shows how a message from the UI is passed through to the MX.

```
// Parse incoming queue message
TypeReference<BaseEvent<UiCMDSHeader>> typeRef = new TypeReference<BaseEvent<UiCMDSHeader>>() {};
BaseEvent<UiCMDSHeader> event = objectMapper.readValue(<Message from Queue in String format>, typeRef);
...

// build command
CreateUserV1 payload = objectMapper.readValue(event.getBody(), CreateUserV1.class);
final CreateUserCommand createUser = CreateUserCommand.builder().eventHeaders(event.getEventHeader())
.eventBody(payload).eventErrors(eventErrors).build();
				
```
## Publishing event to topic:

This is an example of how event is published to "topic out" after it has been processed by MX
```
UserUpdatedEventV1 userUpdateEvent = entityToEventMapper(publishStaff);
BaseEvent<UiCMDSHeader> event = new BaseEvent<UiCMDSHeader>(header, objectMapper.writeValueAsString(userUpdateEvent), null);
publishStaff.registerEvent(event);
		
```
# How to include this libabry in your project:
```
		<dependency>
			<groupId>com.ielts.cmds.common</groupId>
			<artifactId>CMDSEventHeader</artifactId>
			<version>0.0.1-SNAPSHOT</version>
		</dependency>
```		

## Change Log

### 0.0.21 (Feature Release)
Prevent x-Access token to be printed in loggers.

### 0.0.20 (Feature Release)
Dynamic Logging for Lmabdas

### 0.0.18 (Feature Release)
Upgrade libs

### 0.0.17 (Feature Release)
- Added Event Context Classes introduced in Event Serialization Work(moved from event-adapter-spring)

### 0.0.16 (Baseline Release)
- Baseline release version of CMDSEventHeader
