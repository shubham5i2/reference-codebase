package com.ielts.cmds.custom.deserializer;


import java.io.IOException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;


public class CustomZonedDateTimeDeserializer  extends JsonDeserializer<ZonedDateTime> {

    @Override
    public ZonedDateTime deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        return deserializeToLocalDateTime(p.getValueAsString());
    }

    /**
     * List of supported date time pattern
     */
    private static final String[] LOCAL_DATE_TIME_SUPPORTED_PATTERNS = new String[]{
            "yyyy-MM-dd'T'HH:mm:ss.SSSXXX"};


    
    /**
     * Convert serialized data time in to deserialized {@link LocalDateTime} object
     *
     * @param serializedDate Input serialized date that needs conversion
     * @return Return date time as a LocalDateTime object
     */
    public static ZonedDateTime deserializeToLocalDateTime(String serializedDate) {
        for (String PATTERN : LOCAL_DATE_TIME_SUPPORTED_PATTERNS) {
            try {
                DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(PATTERN);
                return ZonedDateTime.parse(serializedDate, dateTimeFormatter);
            } catch (Exception ignored) {
            	ignored.toString();
            }
        }

        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(LOCAL_DATE_TIME_SUPPORTED_PATTERNS[0]);
        ZonedDateTime zonedDT = ZonedDateTime.parse(serializedDate, dateTimeFormatter);
        return ZonedDateTime.ofInstant(Instant.parse(dateTimeFormatter.format(zonedDT)), zonedDT.getZone());
    }

}