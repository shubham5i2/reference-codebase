package com.ielts.cmds.infrastructure.event.context;

public class ThreadLocalErrorContext {

    private static final ThreadLocal<CMDSErrorContext> threadLocal = new ThreadLocal<>();

    private ThreadLocalErrorContext() {
    }

    public static void setContext(final CMDSErrorContext errorContext) {
        threadLocal.set(errorContext);
    }

    public static CMDSErrorContext getContext() {
        return threadLocal.get();
    }

    public static void clearContext() {
        threadLocal.remove();
    }
}
