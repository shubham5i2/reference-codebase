package com.ielts.cmds.infrastructure.event.context;

public class ThreadLocalHeaderContext {

    private static final ThreadLocal<CMDSHeaderContext> threadLocal = new ThreadLocal<>();

    private ThreadLocalHeaderContext() {
    }

    public static void setContext(final CMDSHeaderContext headerContext) {
        threadLocal.set(headerContext);
    }

    public static CMDSHeaderContext getContext() {
        return threadLocal.get();
    }

    public static void clearContext() {
        threadLocal.remove();
    }
}
