package com.ielts.cmds.common;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

/**
 * Utility class to convert serialized data time in to deserialized {@link LocalDateTime} object
 */
public class DateTimeDeserializerUtil {

    /**
     * List of supported date time pattern
     */
    private static final String[] LOCAL_DATE_TIME_SUPPORTED_PATTERNS = new String[]{
            "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
            "yyyy-MM-dd'T'HH:mm:ss.SS'Z'",
            "yyyy-MM-dd'T'HH:mm:ss.S'Z'",
            "yyyy-MM-dd'T'HH:mm:ss'Z'",
            "yyyy-MM-dd'T'HH:mm'Z'",
            "yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'",
            "yyyy-MM-dd'T'HH:mm:ss.SSSS'Z'"};

    private DateTimeDeserializerUtil() {
    }

    /**
     * Convert serialized data time in to deserialized {@link LocalDateTime} object
     *
     * @param serializedDate Input serialized date that needs conversion
     * @return Return date time as a LocalDateTime object
     */
    public static LocalDateTime deserializeToLocalDateTime(String serializedDate) {
        for (String PATTERN : LOCAL_DATE_TIME_SUPPORTED_PATTERNS) {
            try {
                DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(PATTERN);
                return LocalDateTime.parse(serializedDate, dateTimeFormatter);
            } catch (Exception ignored) {
            }
        }

        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(LOCAL_DATE_TIME_SUPPORTED_PATTERNS[0]);
        LocalDateTime localDT = LocalDateTime.parse(serializedDate, dateTimeFormatter);
        return LocalDateTime.ofInstant(Instant.parse(dateTimeFormatter.format(localDT)), ZoneOffset.UTC);
    }

}
