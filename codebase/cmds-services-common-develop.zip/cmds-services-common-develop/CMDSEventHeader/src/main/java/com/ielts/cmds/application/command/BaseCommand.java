package com.ielts.cmds.application.command;

import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * @author cts
 * @param <T>
 *
 */
@Data
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
public class BaseCommand<H extends BaseHeader,T> {
	private H eventHeaders;
	private T eventBody;
	private BaseEventErrors eventErrors;
	private BaseAudit audit;
	
}