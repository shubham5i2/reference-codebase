package com.ielts.cmds.infrastructure.event;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.core.ResolvableType;
import org.springframework.core.ResolvableTypeProvider;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * BaseEvent represents basic message envelope structure that is used by all
 * events passed within the platform through queues.
 * 
 * It contains 3 parts: generic header object which is a BaseHeader or a
 * subclass thereof, body which is a string representation of the JSON payload
 * object (actual event) and errors section where processors are able to add
 * additional messaging to describe any errors or warnings that occurred.
 * 
 * Headers object is generic as it may contain extra attributes in some cases.
 * e.g. UI events will contain an extra mandatory parameter "connectionId" which
 * is required to provide response via web socket.
 */

@Data
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BaseEventV2<T extends BaseHeader> implements Serializable, ResolvableTypeProvider {

	/**
	 * Generated Serial Version Id
	 */
	private static final long serialVersionUID = 1346959473817183946L;

	@Valid
	@NotNull(message = "{cmds.baseHeader.null}")
	private T eventHeader;
	private Object eventBody;
	private BaseEventErrors eventErrors;
	private BaseAudit audit;

	/**
	 * ResolvableType provider will cater for determining the generic type, so that
	 * spring data event publisher correctly resolves the event.
	 */
	@JsonIgnore
	@Override
	public ResolvableType getResolvableType() {
		return ResolvableType.forClassWithGenerics(getClass(), ResolvableType.forInstance(eventHeader));
	}

}
