package com.ielts.cmds.infrastructure.event.context;

import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import lombok.EqualsAndHashCode;
import lombok.Generated;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;

@Generated
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@ToString(callSuper = true)
public class CMDSErrorContext extends CMDSErrorResponse implements Serializable {

    private static final long serialVersionUID = -5318505574720847927L;

    public CMDSErrorContext(final List<ErrorDescription> eventErrors) {
        super(eventErrors);
    }
}
