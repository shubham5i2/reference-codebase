package com.ielts.cmds.infrastructure.event.context;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Objects;
import java.util.Queue;

public class ThreadLocalHeaderQueue {

    private static final ThreadLocal<Queue<CMDSHeaderContext>> threadLocal = new ThreadLocal<>();

    private ThreadLocalHeaderQueue() {
    }

    public static void add(final CMDSHeaderContext cmdsHeaderContext) {
        CMDSHeaderContext headerContext = new CMDSHeaderContext();
        headerContext.setPartnerCode(cmdsHeaderContext.getPartnerCode());
        headerContext.setEventName(cmdsHeaderContext.getEventName());
        headerContext.setCorrelationId(cmdsHeaderContext.getCorrelationId());
        headerContext.setEventDateTime(cmdsHeaderContext.getEventDateTime());
        headerContext.setEventDiscriminator(cmdsHeaderContext.getEventDiscriminator());
        headerContext.setCallbackURL(cmdsHeaderContext.getCallbackURL());
        headerContext.setEventDateTimeAsString(cmdsHeaderContext.getEventDateTimeAsString());
        headerContext.setTransactionId(cmdsHeaderContext.getTransactionId());
        headerContext.setXaccessToken(cmdsHeaderContext.getXaccessToken());
        headerContext.setEventContext(new HashMap<>(cmdsHeaderContext.getEventContext()));
        headerContext.setConnectionId(cmdsHeaderContext.getConnectionId());
        Queue<CMDSHeaderContext> queue = threadLocal.get();
        if (Objects.isNull(queue)) {
            queue = new LinkedList<>();
        }
        queue.add(headerContext);
        threadLocal.set(queue);
    }

    public static Queue<CMDSHeaderContext> getHeaderQueue() {
        return threadLocal.get();
    }

    public static void clearHeaderQueue() {
        threadLocal.remove();
    }
}
