package com.ielts.cmds.infrastructure.event;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.ielts.cmds.common.DateTimeDeserializerUtil;
import com.ielts.cmds.custom.serializer.CMDSLocalDateTimeDeserializer;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** @author CTS */
@Data
@EqualsAndHashCode
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString(exclude = "xaccessToken")
public class BaseHeader implements Serializable {

  private static final long serialVersionUID = 438144242340551057L;

  private static final DateTimeFormatter AWS_DT_FORMATTER =
      DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

  @NotNull(message = "{cmds.baseHeader.transactionId.null}")
  private UUID transactionId;

  private String callbackURL;

  private UUID correlationId;

  private String partnerCode;

  @JsonSerialize(using = LocalDateTimeSerializer.class)
  @JsonDeserialize(using = CMDSLocalDateTimeDeserializer.class)
  @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
  @NotNull(message = "{cmds.baseHeader.eventDateTime.null}")
  private LocalDateTime eventDateTime;

  @NotEmpty(message = "{cmds.baseHeader.eventName.null}")
  private String eventName;

  private Map<String, String> eventContext = new HashMap<>();

  private String eventDiscriminator;

  private String xaccessToken;

  /** @deprecated please use event Name which is combination of http.method+http.uri */
  @Deprecated private String operationType;

  /** @deprecated please use event Name which is combination of http.method+http.uri */
  @Deprecated private String resource;

  /**
   * AWS lambda is not parsing string representation of dates to the java.time counterparts. This
   * method is a proxy setter for eventDateTime that does the conversion manually.
   *
   * @param eventDateTimeISO ISO date time "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
   */
  public void setEventDateTimeAsString(final String eventDateTimeISO) {
    this.eventDateTime = DateTimeDeserializerUtil.deserializeToLocalDateTime(eventDateTimeISO);
  }

  /**
   * Getter proxy to get the ISO date time.
   *
   * @return ISO date time as tring
   */
  public String getEventDateTimeAsString() {
    return this.eventDateTime != null ? this.eventDateTime.format(AWS_DT_FORMATTER) : null;
  }
}
