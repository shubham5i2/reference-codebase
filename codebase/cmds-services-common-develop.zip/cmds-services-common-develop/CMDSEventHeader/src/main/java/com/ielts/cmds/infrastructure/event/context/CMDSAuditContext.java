package com.ielts.cmds.infrastructure.event.context;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.ielts.cmds.custom.serializer.CMDSLocalDateTimeDeserializer;
import lombok.Generated;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Generated
@Getter
@Setter
@ToString
public class CMDSAuditContext {

    private String principalId;

    private String principalName;

    private String permission;

    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = CMDSLocalDateTimeDeserializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    private LocalDateTime causedByEventDateTime;

    private String causedByEventName;

    private UUID causedByTransactionId;

    private UUID causedByCorrelationId;

    private Map<String, String> auditContext = new HashMap<>();
}
