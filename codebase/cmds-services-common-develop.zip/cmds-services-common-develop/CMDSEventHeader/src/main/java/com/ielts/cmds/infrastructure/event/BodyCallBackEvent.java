/**
 * 
 */
package com.ielts.cmds.infrastructure.event;

import lombok.EqualsAndHashCode;

/**
 * Specialized version of event that allows postponing the generation of event
 * body until later time when getEventBody() method is invoked. This solves use
 * case for newly created domain objects that have not yet been assigned a
 * primary key to delay the JSON stringify till the persistence layer
 * completed s the transaction and the object is issued with UUID.
 *
 */
@EqualsAndHashCode(callSuper = true)
public class BodyCallBackEvent<T extends BaseHeader> extends BaseEvent<T> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4237616400812204924L;

	private BodyCallBack eventBody;

	/**
	 * @param eventHeader
	 * @param eventBody
	 * @param eventErrors
	 */
	public BodyCallBackEvent(T eventHeader, BodyCallBack eventBody, BaseEventErrors eventErrors, BaseAudit audit) {
		super(eventHeader, null, eventErrors, audit);
		this.eventBody = eventBody;
	}

	@Override
	public String getEventBody() {
		return eventBody.getEventBody();
	}

}
