package com.ielts.cmds.infrastructure.event.context;

public class ThreadLocalAuditContext {

    private static final ThreadLocal<CMDSAuditContext> threadLocal = new ThreadLocal<>();

    private ThreadLocalAuditContext() {
    }

    public static void setContext(final CMDSAuditContext auditContext) {
        threadLocal.set(auditContext);
    }

    public static CMDSAuditContext getContext() {
        return threadLocal.get();
    }

    public static void clearContext() {
        threadLocal.remove();
    }
}
