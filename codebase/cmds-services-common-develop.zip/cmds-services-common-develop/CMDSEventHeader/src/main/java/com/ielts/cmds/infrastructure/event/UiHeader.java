package com.ielts.cmds.infrastructure.event;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@EqualsAndHashCode(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@ToString(callSuper = true)
public class UiHeader extends BaseHeader implements Serializable{
	
	private static final long serialVersionUID = -7691520416682498955L;
	
	@NotEmpty(message = "{cmds.baseHeader.ConnectionId.null}")
	private String connectionId;
}
