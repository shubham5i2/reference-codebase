package com.ielts.cmds.infrastructure.event;

public interface BodyCallBack{
	String getEventBody();
}
