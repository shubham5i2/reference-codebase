package com.ielts.cmds.infrastructure.event.context;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Objects;
import java.util.Queue;

public class ThreadLocalAuditQueue {

    private static final ThreadLocal<Queue<CMDSAuditContext>> threadLocal = new ThreadLocal<>();

    private ThreadLocalAuditQueue() {
    }

    public static void add(final CMDSAuditContext cmdsAuditContext) {
        CMDSAuditContext auditContext = new CMDSAuditContext();
        auditContext.setPrincipalId(cmdsAuditContext.getPrincipalId());
        auditContext.setPrincipalName(cmdsAuditContext.getPrincipalName());
        auditContext.setCausedByCorrelationId(cmdsAuditContext.getCausedByCorrelationId());
        auditContext.setPermission(cmdsAuditContext.getPermission());
        auditContext.setCausedByTransactionId(cmdsAuditContext.getCausedByTransactionId());
        auditContext.setCausedByEventName(cmdsAuditContext.getCausedByEventName());
        auditContext.setCausedByEventDateTime(cmdsAuditContext.getCausedByEventDateTime());
        auditContext.setAuditContext(new HashMap<>(cmdsAuditContext.getAuditContext()));
        Queue<CMDSAuditContext> queue = threadLocal.get();
        if (Objects.isNull(queue)) {
            queue = new LinkedList<>();
        }
        queue.add(auditContext);
        threadLocal.set(queue);
    }

    public static Queue<CMDSAuditContext> getAuditQueue() {
        return threadLocal.get();
    }

    public static void clearAuditQueue() {
        threadLocal.remove();
    }
}
