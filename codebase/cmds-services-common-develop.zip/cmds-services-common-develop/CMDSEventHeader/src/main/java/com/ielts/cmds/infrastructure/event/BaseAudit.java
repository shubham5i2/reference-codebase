package com.ielts.cmds.infrastructure.event;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.Map;
import java.util.UUID;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode
@ToString
public class BaseAudit implements Serializable{

	private static final long serialVersionUID = 705551778442096908L;

	private String principalId;

	private String principalName;

	private String permission;

	private OffsetDateTime causedByEventDateTime;

	private String causedByEventName;

	private UUID causedByTransactionId;

	private UUID causedByCorrelationId;

	private Map<String, String> auditContext;

}
