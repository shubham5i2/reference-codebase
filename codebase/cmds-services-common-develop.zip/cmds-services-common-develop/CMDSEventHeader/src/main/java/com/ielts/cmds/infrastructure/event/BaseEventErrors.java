/**
 * 
 */
package com.ielts.cmds.infrastructure.event;

import java.io.Serializable;
import java.util.List;

import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.common.exception.util.ErrorDescription;

import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author cts
 *
 */
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@ToString(callSuper = true)
public class BaseEventErrors extends CMDSErrorResponse implements Serializable {

	private static final long serialVersionUID = -5318505574720847927L;

	public BaseEventErrors(final List<ErrorDescription> eventErrors) {
		super(eventErrors);
	}
}
