package com.ielts.cmds.custom.serializer;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class CMDSLocalDateTimeDeserializerTest {

    private final CMDSLocalDateTimeDeserializer cmdsLocalDateTimeDeserializer = new CMDSLocalDateTimeDeserializer();

    private final ObjectMapper objectMapper = new ObjectMapper();

    public static void main(String[] args) throws IOException {
        CMDSLocalDateTimeDeserializerTest cmdsLocalDateTimeDeserializerTest = new CMDSLocalDateTimeDeserializerTest();

        cmdsLocalDateTimeDeserializerTest.when_having_millisecond_then_parse_millisecond1();
        cmdsLocalDateTimeDeserializerTest.when_having_millisecond_then_parse_millisecond2();
        cmdsLocalDateTimeDeserializerTest.when_having_millisecond_then_parse_millisecond3();
        cmdsLocalDateTimeDeserializerTest.when_not_having_millisecond_then_do_not_parse_millisecond();
        cmdsLocalDateTimeDeserializerTest.when_not_having_second_then_do_not_parse_second();

    }

    @Test
    void when_having_millisecond_then_parse_millisecond1() throws IOException {
        String inputDateString = "2021-11-30T10:01:23.800";
        JsonParser parser = getParser(inputDateString);

        LocalDateTime localDateTime = cmdsLocalDateTimeDeserializer.deserialize(parser, objectMapper.getDeserializationContext());

        assertNotNull(localDateTime);
        assertEquals(localDateTime.toString(), inputDateString);
    }

    @Test
    void when_having_millisecond_then_parse_millisecond2() throws IOException {
        String inputDateString = "2021-11-30T10:01:23.850";
        JsonParser parser = getParser(inputDateString);

        LocalDateTime localDateTime = cmdsLocalDateTimeDeserializer.deserialize(parser, objectMapper.getDeserializationContext());

        assertNotNull(localDateTime);
        assertEquals(localDateTime.toString(), inputDateString);
    }

    @Test
    void when_having_millisecond_then_parse_millisecond3() throws IOException {
        String inputDateString = "2021-11-30T10:01:23.859";
        JsonParser parser = getParser(inputDateString);

        LocalDateTime localDateTime = cmdsLocalDateTimeDeserializer.deserialize(parser, objectMapper.getDeserializationContext());

        assertNotNull(localDateTime);
        assertEquals(localDateTime.toString(), inputDateString);
    }

    @Test
    void when_not_having_millisecond_then_do_not_parse_millisecond() throws IOException {
        String inputDateString = "2021-11-30T10:01:23";
        JsonParser parser = getParser(inputDateString);

        LocalDateTime localDateTime = cmdsLocalDateTimeDeserializer.deserialize(parser, objectMapper.getDeserializationContext());

        assertNotNull(localDateTime);
        assertEquals(localDateTime.toString(), inputDateString);
    }

    @Test
    void when_not_having_second_then_do_not_parse_second() throws IOException {
        String inputDateString = "2021-11-30T10:01";
        JsonParser parser = getParser(inputDateString);

        LocalDateTime localDateTime = cmdsLocalDateTimeDeserializer.deserialize(parser, objectMapper.getDeserializationContext());

        assertNotNull(localDateTime);
        assertEquals(localDateTime.toString(), inputDateString);
    }

    private JsonParser getParser(String inputDateString) throws IOException {
        String json = String.format("{\"value\":\"%sZ\"}", inputDateString);
        InputStream stream = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));
        JsonParser parser = objectMapper.getFactory().createParser(stream);
        parser.nextToken();
        parser.nextToken();
        parser.nextToken();

        return parser;
    }

}