package com.ielts.cmds.custom.deserializer;


import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class CustomDeserializerTest {

    @Spy
    private ObjectMapper objectMapper;

    @InjectMocks
    private CustomDateDeserializer customDateDeserializer;

    @Test
    void whenValidEvent_ThenReturnLocalDateTimeWithMills() throws IOException {
        String json = String.format("{\"value\":%s}", "\"2021-11-30T10:01:23.9Z\"");
        InputStream stream = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));
        JsonParser parser = objectMapper.getFactory().createParser(stream);
        DeserializationContext ctxt = objectMapper.getDeserializationContext();
        parser.nextToken();
        parser.nextToken();
        parser.nextToken();
        LocalDateTime localDateTime = customDateDeserializer.deserialize(parser, ctxt);
        assertNotNull(localDateTime);
        assertEquals(localDateTime.toString(), "2021-11-30T10:01:23.009");
    }

    @Test
    void whenValidEvent_ThenReturnLocalDateTimeWithoutMills() throws IOException {
        String json = String.format("{\"value\":%s}", "\"2021-11-30T10:01:23Z\"");
        InputStream stream = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));
        JsonParser parser = objectMapper.getFactory().createParser(stream);
        DeserializationContext ctxt = objectMapper.getDeserializationContext();
        parser.nextToken();
        parser.nextToken();
        parser.nextToken();
        LocalDateTime localDateTime = customDateDeserializer.deserialize(parser, ctxt);
        assertNotNull(localDateTime);
        assertEquals(localDateTime.toString(), "2021-11-30T10:01:23");
    }

    @Test
    void whenValidEvent_ThenReturnLocalDateTimeWithout2Mills() throws IOException {
        String json = String.format("{\"value\":%s}", "\"2021-11-30T10:01:23.98Z\"");
        InputStream stream = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));
        JsonParser parser = objectMapper.getFactory().createParser(stream);
        DeserializationContext ctxt = objectMapper.getDeserializationContext();
        parser.nextToken();
        parser.nextToken();
        parser.nextToken();
        LocalDateTime localDateTime = customDateDeserializer.deserialize(parser, ctxt);
        assertNotNull(localDateTime);
        assertEquals(localDateTime.toString(), "2021-11-30T10:01:23.098");
    }

    @Test
    void whenValidEvent_ThenReturnLocalDateTimeWithout3Mills() throws IOException {
        String json = String.format("{\"value\":%s}", "\"2021-11-30T10:01:23.978Z\"");
        InputStream stream = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));
        JsonParser parser = objectMapper.getFactory().createParser(stream);
        DeserializationContext ctxt = objectMapper.getDeserializationContext();
        parser.nextToken();
        parser.nextToken();
        parser.nextToken();
        LocalDateTime localDateTime = customDateDeserializer.deserialize(parser, ctxt);
        assertNotNull(localDateTime);
        assertEquals(localDateTime.toString(), "2021-11-30T10:01:23.978");
    }

    @Test
    void whenInValidEvent_ThenThrowException() throws IOException {
        String json = String.format("{\"value\":%s}", "\"021-11-30T10:01\"");
        InputStream stream = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));
        JsonParser parser = objectMapper.getFactory().createParser(stream);
        DeserializationContext ctxt = objectMapper.getDeserializationContext();
        parser.nextToken();
        parser.nextToken();
        parser.nextToken();
        assertThrows(Exception.class, () -> customDateDeserializer
                .deserialize(parser, ctxt));
    }
}
