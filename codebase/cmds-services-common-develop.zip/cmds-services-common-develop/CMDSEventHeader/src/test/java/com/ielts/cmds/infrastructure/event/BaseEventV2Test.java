/** */
package com.ielts.cmds.infrastructure.event;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.core.io.ClassPathResource;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/** @author cts */
class BaseEventV2Test {

    private ObjectMapper objectMapper = null;
    /** @throws java.lang.Exception */
    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        objectMapper = new ObjectMapper();
    }

    @Test
    void testBaseEvent() throws JsonParseException, JsonMappingException, IOException {

        TypeReference<BaseEvent<UiHeader>> typeRef = new TypeReference<BaseEvent<UiHeader>>() {};
        BaseEvent<UiHeader> event =
                objectMapper.readValue(new ClassPathResource("/json/eventPayload.json").getFile(), typeRef);
        assertNotNull(event);
        assertNotNull(event.getEventHeader());
        assertNotNull(event.getEventBody());
        assertNotNull(event.getEventErrors());
        assertEquals("QuxlPfBNLPECGog=", event.getEventHeader().getConnectionId());
        assertEquals(
                "acf214e0-cc57-4c1c-aad1-bfe37b73c548",
                event.getEventHeader().getTransactionId().toString());
        assertEquals("POST/v1/users/search", event.getEventHeader().getEventName());
        assertTrue(event.getEventBody().contains("userName"));
        assertEquals("WARNING", event.getEventErrors().getErrorList().get(0).getType().getValue());
        assertNotNull(event.getEventHeader().getEventDateTime());
        assertEquals(2015, event.getEventHeader().getEventDateTime().getYear());
    }

    @Test
    void testBaseEventAWS() throws JsonParseException, JsonMappingException, IOException {

        TypeReference<BaseEvent<UiHeader>> typeRef = new TypeReference<BaseEvent<UiHeader>>() {};
        BaseEvent<UiHeader> event =
                objectMapper.readValue(
                        new ClassPathResource("/json/eventPayloadAWS.json").getFile(), typeRef);
        assertNotNull(event);
        assertNotNull(event.getEventHeader());
        assertNotNull(event.getEventBody());
        assertNotNull(event.getEventErrors());
        assertEquals("QuxlPfBNLPECGo2=", event.getEventHeader().getConnectionId());
        assertEquals(
                "acf214e0-cc57-4c1c-aad1-bfe37b73c542",
                event.getEventHeader().getTransactionId().toString());
        assertEquals("POST/v1/users/search", event.getEventHeader().getEventName());
        assertTrue(event.getEventBody().contains("userName"));
        assertEquals("WARNING", event.getEventErrors().getErrorList().get(0).getType().getValue());
        assertNotNull(event.getEventHeader().getEventDateTime());
        assertEquals(2016, event.getEventHeader().getEventDateTime().getYear());
    }
}
