import au.com.dius.pact.consumer.Pact;
import au.com.dius.pact.consumer.PactProviderRuleMk2;
import au.com.dius.pact.consumer.PactVerification;
import au.com.dius.pact.consumer.dsl.DslPart;
import au.com.dius.pact.consumer.dsl.PactDslJsonBody;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.model.RequestResponsePact;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class StudentDetailProviderMock 
{    
    public static final String providerServiceName = "student-server";
    public static final String clientServiceName = "studentdetails-client";
    public static int providerServicePort = 8110;
    public static String providerUrl_GET_1 = "http://localhost:" + StudentDetailProviderMock.providerServicePort + "/1"; 

    // Start the Provider Mock Service
    @Rule
    public PactProviderRuleMk2 provider = new PactProviderRuleMk2(StudentDetailProviderMock.providerServiceName, "localhost", StudentDetailProviderMock.providerServicePort, this);

    // Define expected response for PACT to be received from the server
    @Pact(consumer = StudentDetailProviderMock.clientServiceName)
    public RequestResponsePact createPact_GET_1(PactDslWithProvider builder) 
    {
        Map<String, String> headers = new HashMap();
        System.out.println("Creating Pact ...");
        headers.put("Content-Type", "application/json");

        DslPart StuResults = new PactDslJsonBody()
                .stringType("externalTestTakerId","1")
                .stringType("identityNumber","121")
                .stringType("identityType","NationalId")
                .stringType("identityIssuingAuthority","UIT")
                .stringType("firstName","Alan")
                .stringType("lastName","Davis")
                .stringType("dob","11-01-1996")
                .stringType("sex","M")
                .stringType("email","1716@gmail.com")
                .stringType("title","Mr")
                .stringType("telephone","+41 767 221 8765")
                .stringType("mobile","+12 2123 232")
                .stringType("languageId","123")
                .stringType("nationalityId","101")
                .asBody();

        return builder
                .given("There is a Test taker details")
                .uponReceiving("A request for Test taker details")
                .path("/1")
                .method("GET")
                .willRespondWith()
                .status(200)
                .headers(headers)
                .body(StuResults).toPact();

    }
}