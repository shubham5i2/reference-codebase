import au.com.dius.pact.consumer.Pact;
import au.com.dius.pact.consumer.PactProviderRuleMk2;
import au.com.dius.pact.consumer.PactVerification;
import au.com.dius.pact.consumer.dsl.DslPart;
import au.com.dius.pact.consumer.dsl.PactDslJsonBody;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.model.RequestResponsePact;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.apache.http.HttpResponse;
import org.apache.http.client.fluent.Request;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;

public class StudentIdentityMockTest extends StudentDetailProviderMock 
{
    // Run a test on the mock provider and generate a PACT contract
    @Test
    @PactVerification(StudentDetailProviderMock.providerServiceName)
    public void testIdentity() 
    {
        try {
                System.out.println("--- Executing test identity ---");

                HttpResponse resp = Request.Get(StudentDetailProviderMock.providerUrl_GET_1).execute().returnResponse();

                System.out.println("Response: " +resp);

                String json = EntityUtils.toString(resp.getEntity());
                System.out.println("JSON = " +json);

                JSONObject jsonObject = new JSONObject(json);
                String identityNumber = jsonObject.get("identityNumber").toString();
                String identityType = jsonObject.get("identityType").toString();

                System.out.println("identityNumber: " + identityNumber);
                System.out.println("identityType: " + identityType);

                System.out.println("--- Executing test identity ---");
            }
            catch (Exception e) {
                System.out.println("Exception: Unable to get response from mock service: "+e);
            }
    }
}
    

