import au.com.dius.pact.provider.junit.PactRunner;
import au.com.dius.pact.provider.junit.Provider;
import au.com.dius.pact.provider.junit.State;
import au.com.dius.pact.provider.junit.loader.PactFolder;
import org.junit.runner.RunWith;



@RunWith(PactRunner.class) // Say JUnit to run tests with custom Runner
@Provider("CMDS-provider-Int92-POST") // Set up name of tested provider
@PactFolder("./pacts") // Point where to find pacts (See also section Pacts source in documentation)
public class Lprtocmdspostcall92verify {

    @State("Reference details posted from LPR to CMDS") //This is set as a state in the mock service
    public void verifyState() {
        System.out.println("Reference details posted from LPR to CMDS" );
    }
}
