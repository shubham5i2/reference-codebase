Below are the steps to include custom/common service Jar

1. Include below configuration in pom.xml
	
	```xml
	<repositories>
		<repository>
			<id>nexus-group</id>
			<url>https://nexus.shared.cmdsiz.com/repository/nexus-group/</url>
			<releases>
				<enabled>false</enabled>
			</releases>
		</repository>
		<repository>
			<id>ielts-cmds-snap</id>
			<url>https://nexus.shared.cmdsiz.com/repository/ielts-cmds-snap/</url>
			<releases>
				<enabled>false</enabled>
			</releases>
		</repository>
	</repositories>```

```xml
<pluginRepositories>
		<pluginRepository>
			<id>nexus-group</id>
			<url>https://nexus.shared.cmdsiz.com/repository/nexus-group/</url>
			<releases>
				<enabled>true</enabled>
			</releases>
			<snapshots>
				<enabled>true</enabled>
			</snapshots>
		</pluginRepository>
</pluginRepositories>```
	
2. Include the Common Service Dependancy
		```xml
		<dependency>
			<groupId>com.ielts.cmds.ms</groupId>
			<artifactId>cmds-common-connectionfactory</artifactId>
			<version>0.0.10-SNAPSHOT</version>
		</dependency>```
		
3. Import the classes for JMSListener/AwsConfig for AWSLogin and Queue Connection.Create one AppConfig.java and include below lines (Optional step)
``` Code 
@Configuration
@EnableAutoConfiguration
@Import({JmsListnerConfig.class,DataBaseConfiguration.class})
public class AppConfig{

} ```

4. Remove Existing code for DB/JMS/AWS connection.Above class will handle the connection as per import of configuration.

5. If you want to add any another configuration, then include it in Appconfig by using @Bean.

6. Add the below properties in application.properties. Use the DatabaseURL as per microservice application

```Poperties
spring.datasource.platform=h2
spring.datasource.driverClassName=org.h2.Driver
spring.datasource.url=jdbc:h2:mem:testspring;MODE=PostgreSQL
spring.datasource.username=sa
spring.datasource.password=
spring.h2.console.enabled=true
spring.datasource.initialization-mode=embedded
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.format_sql=true
```

7. Run MVN Clean install.

## What's new in 0.0.10-SNAPSHOT?
- Common connection factory now provides spring beans for AmazonSQS, AmazonSNS and AmazonS3 objects to be used anywhere in the microservices for working with SQS, SNS and S3 buckets. Microservices does NOT need to create objects of these types instead they can simply autowire or get the bean from context and use that for further API invocations. 
This will be supported in both local VDI/machine as well as Mx running in AWS ECS in any environment. On locally running microservices , the objects will be created using the STS token whereas for microservices running in ECS instances(sandbox, dev, SIT, UAT, prod envs) the objects would be created using  default credential provider chain 
Local - applicaton.properties file should have a property specifying the spring profile as local.
Example :  ``` spring.profiles.active=local ```

ECS - The parameter store should have corresponding property set as anything non-local.
Example: ``` spring.profiles.active=sandbox ``` 
OR  ``` spring.profiles.active=dev ```


## What's new in 0.0.8-SNAPSHOT?
- Removed credentials provider while building SNS Client

## What does this do?
- Fixes **Too many Requests** error while publishing the message to topic in ECS

## How to integrate?

### Maven

```
<dependency>
	<groupId>com.ielts.cmds.common</groupId>
	<artifactId>cmds-common-connectionfactory</artifactId>
	<version>0.0.8-SNAPSHOT</version>
</dependency>
```
### Gradle

```
dependencies {
	compile group: 'com.ielts.cmds.common', name: 'cmds-common-connectionfactory', version: '0.0.8-SNAPSHOT'
}
```

## Changelog

### 1.0.0 (Upgrade to major version)


### 0.0.20 
- Removed ConditionalOnMissingBean annotation from DefaultMessageListenerContainerFactory Bean to support the SQSConnectionFactoryV2 Lib

### 0.0.19 (Baseline Release Version)


### 0.0.17-SNAPSHOT
- Added support for delay in retries based on the visibilityTimeout parameter set on SQS

### 0.0.16-SNAPSHOT
- Added support for deserializing to jsonnullable fields in ObjectMapperBean

### 0.0.15-SNAPSHOT
- Enum deserialization issue(IMOD-43401)

### 0.0.14-SNAPSHOT
- Marked ObjectMapper bean as Primary bean

### 0.0.13-SNAPSHOT
- Added support for IBaseAudit to support existing audit implementation for v1
- Removed unused dependencies

#### How to Integrate

```
public class BookingCreatedService implements IApplicationServiceV2<BookingDetails>, IBaseAuditService {

	@Override
	void process(final BookingDetails bookingDetails) {
		populateAuditFields();
		bookingDomainService.onCommand(bookingDetails);
	}
	
	// Override getScreen, getPermission, getAction methods in application service layer
	@Override
	private String getScreen() {
		return "";
	}
	@Override
	private String getPermission() {
		return "";
	}
	@Override
	private String getAction() {
		return "";
	}
}
```

#### How to Test
- Run Regression to ensure the audit changes are working
- Run Regression to ensure that the removal of dependencies did not affect the Mx in runtime
 
