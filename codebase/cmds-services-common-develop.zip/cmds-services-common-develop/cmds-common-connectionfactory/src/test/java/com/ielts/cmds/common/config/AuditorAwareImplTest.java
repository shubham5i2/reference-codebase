package com.ielts.cmds.common.config;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ielts.cmds.common.ConnectionFactoryConstants;

@ExtendWith(SpringExtension.class)
@ContextConfiguration
class AuditorAwareImplTest {
	
	@InjectMocks private AuditorAwareImpl auditorAwareImpl;
	
	@Test
	@WithMockUser(username = "auth0|09d43b09-c0ed-4568-98d0-a47829f93acb")
	void when_getCurrentAuditor_ExpectCurrentAuditorValue() {
		String actual = auditorAwareImpl.getCurrentAuditor().orElse(null);
		assertNotNull(actual);
		assertEquals("09d43b09-c0ed-4568-98d0-a47829f93acb", actual);
	}
	
	@Test
	@WithMockUser(username = "")
	void when_getCurrentAuditor_ExpectCurrentAuditorValueToBeDefaultUser() {
		String actual = auditorAwareImpl.getCurrentAuditor().orElse(null);
		assertNotNull(actual);
		assertEquals(ConnectionFactoryConstants.OPERATIONS_USER, actual);
	}
}
