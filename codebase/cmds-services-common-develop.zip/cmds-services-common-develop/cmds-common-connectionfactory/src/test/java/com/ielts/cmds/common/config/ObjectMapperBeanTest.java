/**
 * 
 */
package com.ielts.cmds.common.config;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.InputMismatchException;
import java.util.UUID;

import org.apache.http.annotation.Experimental;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.exc.MismatchedInputException;
import com.ielts.cmds.common.test.helper.ClassWithJacksonAnnotatedEnum;
import com.ielts.cmds.common.test.helper.ClassWithJacksonAnnotatedEnum.BookingLineStatusEnum;

/**
 * @author vedire
 *
 */
class ObjectMapperBeanTest {
	
	@InjectMocks
	private ObjectMapperBean objectMapperBean;
	
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test method for {@link com.ielts.cmds.sm.infrastructure.config.ObjectMapperBean#objectMapper()}.
	 */
	@Test
	void testObjectMapper() {
		//doReturn(objectMapper).when(objectMapperBean).objectMapper();
		Executable exec = ()->objectMapperBean.objectMapper();
		assertDoesNotThrow(exec);
	}
	
	@Test
	void secondaryObjectMapper_should_process_jackson_enum() throws JsonProcessingException {
		ObjectMapper mapper = objectMapperBean.objectMapperWithoutVisibilityConfig();
		
		ClassWithJacksonAnnotatedEnum helperClass = new ClassWithJacksonAnnotatedEnum();
		helperClass.setBookingLineUuid(UUID.fromString("efefcc84-516c-4fb1-9487-65634b284ec4"));
		helperClass.setBookingLineStatus(ClassWithJacksonAnnotatedEnum.BookingLineStatusEnum.ACTIVE);
		helperClass.setExtraTimeMinutes(BigDecimal.TEN);
		
		String str = mapper.writeValueAsString(helperClass);
		
		ClassWithJacksonAnnotatedEnum helperDeser = mapper.readValue(str, ClassWithJacksonAnnotatedEnum.class);
		
		assertEquals(UUID.fromString("efefcc84-516c-4fb1-9487-65634b284ec4"), helperDeser.getBookingLineUuid());
		assertEquals(ClassWithJacksonAnnotatedEnum.BookingLineStatusEnum.ACTIVE, helperDeser.getBookingLineStatus());
		assertEquals(BigDecimal.TEN, helperDeser.getExtraTimeMinutes());
		
	}
	
	@Test
	void primaryObjectMapper_should_not_process_jackson_enum() throws JsonProcessingException {
		ObjectMapper mapper = objectMapperBean.objectMapper();
		
		ClassWithJacksonAnnotatedEnum helperClass = new ClassWithJacksonAnnotatedEnum();
		helperClass.setBookingLineUuid(UUID.fromString("efefcc84-516c-4fb1-9487-65634b284ec4"));
		helperClass.setBookingLineStatus(ClassWithJacksonAnnotatedEnum.BookingLineStatusEnum.ACTIVE);
		helperClass.setExtraTimeMinutes(BigDecimal.TEN);
		
		String str = mapper.writeValueAsString(helperClass);
		
		Executable exec = ()-> { 
			ClassWithJacksonAnnotatedEnum helperDeser = mapper.readValue(str, ClassWithJacksonAnnotatedEnum.class);
			};
		
			assertThrows(MismatchedInputException.class, exec);
		
	}

	@Test
	void primaryObjectMapper_should_not_convert_OffsetDateTime_to_utc() throws JsonProcessingException {
		ObjectMapper mapper = objectMapperBean.objectMapper();

		String offsetDatetime = "2023-01-01T08:00:00.000+11:00";
		ClassWithJacksonAnnotatedEnum helperClass = new ClassWithJacksonAnnotatedEnum();
		helperClass.setStartDateTime(OffsetDateTime.parse(offsetDatetime));

		String str = mapper.writeValueAsString(helperClass);

		ClassWithJacksonAnnotatedEnum helperDeser = mapper.readValue(str, ClassWithJacksonAnnotatedEnum.class);

		assertEquals(OffsetDateTime.parse(offsetDatetime), helperDeser.getStartDateTime());
	}

	@Test
	void secondaryObjectMapper_should_not_convert_OffsetDateTime_to_utc() throws JsonProcessingException {
		ObjectMapper mapper = objectMapperBean.objectMapperWithoutVisibilityConfig();

		String offsetDatetime = "2023-01-01T08:00:00.000+11:00";
		ClassWithJacksonAnnotatedEnum helperClass = new ClassWithJacksonAnnotatedEnum();
		helperClass.setStartDateTime(OffsetDateTime.parse(offsetDatetime));

		String str = mapper.writeValueAsString(helperClass);

		ClassWithJacksonAnnotatedEnum helperDeser = mapper.readValue(str, ClassWithJacksonAnnotatedEnum.class);

		assertEquals(OffsetDateTime.parse(offsetDatetime), helperDeser.getStartDateTime());
	}


}
