package com.ielts.cmds.common.test.helper;

import static com.ielts.cmds.common.ConnectionFactoryConstants.VISIBILITY_TIMEOUT;

import java.util.ArrayList;
import java.util.Collection;

import com.amazonaws.services.sqs.model.ChangeMessageVisibilityBatchRequest;
import com.amazonaws.services.sqs.model.ChangeMessageVisibilityBatchRequestEntry;
import com.amazonaws.services.sqs.model.GetQueueAttributesResult;

public class TestSetup {

  public static ChangeMessageVisibilityBatchRequest createChangeMessageVisibilityBatchRequest() {

    final String mockUrl = "https:mockUrl.com";

    final ChangeMessageVisibilityBatchRequest request = new ChangeMessageVisibilityBatchRequest();
    request.setQueueUrl(mockUrl);

    request.setSdkClientExecutionTimeout(20);
    request.setSdkRequestTimeout(20);

    final ChangeMessageVisibilityBatchRequestEntry entry =
        new ChangeMessageVisibilityBatchRequestEntry();
    entry.setId("id");
    entry.setVisibilityTimeout(5);
    final Collection<ChangeMessageVisibilityBatchRequestEntry> entries = new ArrayList<>();
    entries.add(entry);
    request.setEntries(entries);
    return request;
  }

  public static GetQueueAttributesResult generateGetQueueAttributesResult() {
    final GetQueueAttributesResult getQueueAttributesResult = new GetQueueAttributesResult();
    return getQueueAttributesResult.addAttributesEntry(VISIBILITY_TIMEOUT, "100");
  }
}
