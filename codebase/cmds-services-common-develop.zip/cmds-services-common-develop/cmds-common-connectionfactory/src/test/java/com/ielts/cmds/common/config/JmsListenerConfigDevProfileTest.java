package com.ielts.cmds.common.config;

import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles({"dev"})
public class JmsListenerConfigDevProfileTest extends JmsListenerConfigTest{

}
