/** */
package com.ielts.cmds.common.config;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.support.destination.DestinationResolver;
import org.springframework.test.context.ContextConfiguration;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.model.ChangeMessageVisibilityBatchRequest;
import com.ielts.cmds.common.test.helper.TestSetup;

/** @author vedire */
@PropertySource("classpath:application-test.properties")
@SpringBootTest
@ContextConfiguration(classes = {JmsListnerConfig.class, AWSCredentialsProviderFactory.class})
class JmsListenerConfigTest {

  @Autowired private Environment environment;

  @Autowired private DestinationResolver destinationResolver;

  @Autowired private DefaultJmsListenerContainerFactory jmsListenerContainerFactory;

  @Autowired private JmsTemplate defaultJmsTemplate;

  @Mock private AmazonSNS mockAmazonSNS;

  @Mock private JmsListnerConfig jmsListnerConfig;

  @Autowired private AmazonSNS amazonSNS;

  @Autowired private AmazonS3 amazonS3;

  @Mock DestinationResolver resolver;

  @Mock DefaultJmsListenerContainerFactory factory;

  @Mock AmazonSQS sqs;

  private String activeProfileVal = null;

  private String mockProfile = null;

  @Value("${spring.profiles.active:}")
  private String activeProfiles;

  @Value("${sqs.visibility.timeout}")
  private String visibilityTimeout;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.initMocks(this);
    for (String profileName : activeProfiles.split(",")) {
      activeProfileVal = profileName;
    }
    mockProfile = "deploy";
  }

  /** @throws Exception */
  @AfterEach
  void tearDown() throws Exception {
    activeProfileVal = null;
    mockProfile = null;
  }

  /**
   * Test method for {@link com.ielts.cmds.common.config.JmsListnerConfig#destinationResolver()}.
   */
  @Test
  void testDestinationResolver() {

    assertNotNull(destinationResolver, "DynamicDestinationResolver Class Loaded");
  }

  /**
   * Test method for {@link
   * com.ielts.cmds.common.config.JmsListnerConfig#jmsListenerContainerFactory(com.ielts.cmds.ms.util.SqsErrorHandler)}.
   */
  @Test
  void testJmsListenerContainerFactory() {
    assertNotNull(jmsListenerContainerFactory, "Factory Class Loaded");
  }

  /** Test method for {@link com.ielts.cmds.common.config.JmsListnerConfig#defaultJmsTemplate()}. */
  @Test
  void testDefaultJmsTemplate() {
    assertNotNull(defaultJmsTemplate, "Template Bean Loaded");
  }

  /** Test method for {@link com.ielts.cmds.common.config.JmsListnerConfig#snsClient()}. */
  @Test
  void testSnsClient() {
    when(jmsListnerConfig.snsClient()).thenReturn(mockAmazonSNS);
    assertEquals(mockAmazonSNS, jmsListnerConfig.snsClient());
  }

  /** Test method for {@link com.ielts.cmds.common.config.JmsListnerConfig#s3Client()}. */
  @Test
  void testS3Client_configLoadTest() {
    assertNotNull(amazonS3, "AmazonS3 Bean Loaded");
  }

  /** @Test */
  @Test
  void testSnsClient_configLoadTest() {
    assertNotNull(amazonSNS, "AmazonSNS Bean Loaded");
  }

  /** @Test */
  @Test
  void test_mock_DestinationResolver() {
    when(jmsListnerConfig.destinationResolver()).thenReturn(resolver);
    assertEquals(resolver, jmsListnerConfig.destinationResolver());
  }

  /** @Test */
  @Test
  void test_mock_JmsListenerContainerFactory() {
    when(jmsListnerConfig.jmsListenerContainerFactory()).thenReturn(factory);
    assertEquals(factory, jmsListnerConfig.jmsListenerContainerFactory());
  }

  /** @Test */
  @Test
  void test_mock_JmsListenerContainerFactory_iam() {
    when(jmsListnerConfig.jmsListenerContainerFactoryIamRole()).thenReturn(factory);
    assertEquals(factory, jmsListnerConfig.jmsListenerContainerFactoryIamRole());
  }

  /** By Default profile value will be active */
  @Test
  void check_jmsListenerContainerFactory_instance_for_local_profile() {
    assertAll(
        "local",
        () -> {
          assertEquals(environment.getProperty("spring.profiles.active"), activeProfileVal);
          if (activeProfileVal.equalsIgnoreCase("local"))
            assertTrue(
                DefaultJmsListenerContainerFactory.class.isInstance(jmsListenerContainerFactory));
        });
  }

  /**
   * Test method for {@link
   * com.ielts.cmds.common.config.JmsListnerConfig#jmsListenerContainerFactoryIamRole()}.
   */
  @Test
  void check_Aws_Dev_jmsConnectionFactory() {
    assertAll(
        "!local",
        () -> {
          assertEquals(environment.getProperty("spring.profiles.active"), activeProfileVal);
          activeProfileVal = environment.getProperty("spring.profiles.active");
          if (activeProfileVal.equalsIgnoreCase("dev"))
            assertTrue(
                DefaultJmsListenerContainerFactory.class.isInstance(jmsListenerContainerFactory));
        });
  }

  /**
   * Test method for {@link
   * com.ielts.cmds.common.config.JmsListnerConfig#jmsListenerContainerFactoryIamRole()}.
   */
  @Test
  void check_Aws_mock_jmsConnectionFactory() {
    assertAll(
        "!local",
        () -> {
          assertNotEquals(environment.getProperty("spring.profiles.active"), mockProfile);
          activeProfileVal = environment.getProperty("spring.profiles.active");
          if (activeProfileVal.equalsIgnoreCase("dev"))
            assertTrue(
                DefaultJmsListenerContainerFactory.class.isInstance(jmsListenerContainerFactory));
        });
  }

  @Test
  void test_mock_getCustomHandler() {

    final JmsListnerConfig jmsConfigMock = Mockito.spy(JmsListnerConfig.class);

    final ChangeMessageVisibilityBatchRequest request =
        TestSetup.createChangeMessageVisibilityBatchRequest();

    doReturn(TestSetup.generateGetQueueAttributesResult())
        .when(jmsConfigMock)
        .getQueueVisibilityTimeoutAttribute(request.getQueueUrl());

    ChangeMessageVisibilityBatchRequest response =
        (ChangeMessageVisibilityBatchRequest)
            jmsConfigMock.getCustomHandler().beforeExecution(request);
    assertNotNull(response);
    assertEquals(100, response.getEntries().get(0).getVisibilityTimeout());
  }
}
