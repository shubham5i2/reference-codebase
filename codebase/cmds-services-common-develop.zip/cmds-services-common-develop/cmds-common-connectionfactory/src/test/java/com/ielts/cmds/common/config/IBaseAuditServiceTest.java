package com.ielts.cmds.common.config;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;

@ExtendWith(MockitoExtension.class)
class IBaseAuditServiceTest {
	
	@Spy private IBaseAuditService baseAuditService;
	
	@Test
	void populateAuditFieldsForV2ServiceTest() {
		doReturn("screen").when(baseAuditService).getScreen();
		doReturn("action").when(baseAuditService).getAction();
		doReturn("permission").when(baseAuditService).getPermission();
		baseAuditService.populateAuditFields();
		assertEquals("permission", ThreadLocalAuditContext.getContext().getPermission());
		assertEquals("screen", ThreadLocalAuditContext.getContext().getAuditContext().get("screen"));
		assertEquals("action", ThreadLocalAuditContext.getContext().getAuditContext().get("action"));
		
	}
	
	@Test
	void populateAuditFieldsForExistingV1ServiceTest() {
		doReturn("screen").when(baseAuditService).getScreen();
		doReturn("action").when(baseAuditService).getAction();
		doReturn("permission").when(baseAuditService).getPermission();
		BaseAudit audit = new BaseAudit();
		baseAuditService.populateAuditFields(audit);
		assertEquals("permission", audit.getPermission());
		assertEquals("screen", ThreadLocalAuditContext.getContext().getAuditContext().get("screen"));
		assertEquals("action", ThreadLocalAuditContext.getContext().getAuditContext().get("action"));
		
	}
	
	

}
