package com.ielts.cmds.common.config;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.data.domain.AuditorAware;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@ContextConfiguration
class JpaAuditingConfigurationTest {
	
	@InjectMocks private JpaAuditingConfiguration jpaAuditingConfiguration;
	
	@Test
	@WithMockUser(username = "auth0|09d43b09-c0ed-4568-98d0-a47829f93acb")
	void when_auditorProvider_ExpectAuditor() {
		AuditorAware<String> actual = jpaAuditingConfiguration.auditorProvider();
		assertNotNull(actual);
		assertEquals("09d43b09-c0ed-4568-98d0-a47829f93acb", actual.getCurrentAuditor().orElse(null));
	}
}
