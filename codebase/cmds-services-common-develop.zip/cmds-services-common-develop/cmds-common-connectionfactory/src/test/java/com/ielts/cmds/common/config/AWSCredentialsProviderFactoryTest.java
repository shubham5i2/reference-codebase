package com.ielts.cmds.common.config;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
//import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;

import com.amazonaws.RequestConfig;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.auth.STSAssumeRoleSessionCredentialsProvider;
import com.amazonaws.services.securitytoken.AWSSecurityTokenService;
import com.amazonaws.services.securitytoken.AWSSecurityTokenServiceClientBuilder;
import com.amazonaws.util.CredentialUtils;

@PropertySource("classpath:application-test.properties")
@SpringBootTest
@ContextConfiguration(classes = {AWSCredentialsProviderFactory.class})
@ComponentScan(basePackages = {"com.amazonaws","com.ielts.cmds"})
class AWSCredentialsProviderFactoryTest {
	
	@Value("${aws.region}")
	private String awsRegion;
	
	@Value("${spring.profiles.active:}")
    private String activeProfiles;
	
	@Autowired
	private AWSCredentialsProvider awsCredentialsProvider;
	
    @Spy private AWSCredentialsProvider awsMockCredentialsProvider  ;
    
    @Mock
    private AWSCredentials awsCredentials;
    
    @Mock
	AWSCredentialsProvider credProvider;
    
    @Mock
    AWSCredentialsProviderFactory awsCredentialsProviderFactory;
		
	@Autowired
	private Environment environment;
	
	private String activeProfileVal = null;
	
	private String mockProfile = null;
	
	private static final AWSCredentialsProvider CLIENT_CREDENTIALS = new DefaultAWSCredentialsProviderChain();
	
	
	/**
	 * @throws Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
		
		MockitoAnnotations.initMocks(this);
		for (String profileName : activeProfiles.split(",")) {
			activeProfileVal  = profileName;
        }
		mockProfile = "deploy";
		DefaultAWSCredentialsProviderChain defaultAWSCredentialsProviderChain = new DefaultAWSCredentialsProviderChain();
		awsCredentials = defaultAWSCredentialsProviderChain.getCredentials();
	}

	/**
	 * @throws Exception
	 */
	@AfterEach
	void tearDown() throws Exception {
		activeProfileVal = null;
		mockProfile = null;
		awsCredentials = null;
	}
	
	/**
	 * By Default profile value will be active
	 */
	@Test
	void check_awsCredentials_instance_for_local_profile() {
		assertAll("local", ()->{
			assertEquals(environment.getProperty("spring.profiles.active"),activeProfileVal);
			if(activeProfileVal.equalsIgnoreCase("local"))
				assertTrue(
					STSAssumeRoleSessionCredentialsProvider.class.isInstance(awsCredentialsProvider));
			
		});
	
	}
	
	/**
	 * @DefaultAWSCredentialsProviderChain
	 */
	@Test
	void check_default_AWSCredentials_ProviderChain() {
		DefaultAWSCredentialsProviderChain defaultAWSCredentialsProviderChain = spy(DefaultAWSCredentialsProviderChain.class);
		assertAll("deploy", ()->{
			
			assertNotEquals(environment.getProperty("spring.profiles.active"),mockProfile);
			assertNotNull(awsMockCredentialsProvider);
			when(defaultAWSCredentialsProviderChain.getCredentials()).thenReturn(awsCredentials);
		});
	}

	/**
	 * @throws Exception
	 */
	@Test
	void check_credentials_in_RequestConfig() throws Exception {
		 AWSCredentialsProvider requestCredentials = mock(AWSCredentialsProvider.class);
	        RequestConfig requestConfig = mock(RequestConfig.class);
	        when(requestConfig.getCredentialsProvider()).thenReturn(requestCredentials);
	        AWSCredentialsProvider actual = CredentialUtils
	                .getCredentialsProvider(requestConfig, CLIENT_CREDENTIALS);
	        assertEquals(requestCredentials, actual);
	}
	
	/**
	 * Check credentials against actual one
	 */
	@Test
    void check_credentials_in_awsCredentialsProvider() {
        RequestConfig requestConfig = mock(RequestConfig.class);
        AWSCredentialsProvider actual = CredentialUtils
                .getCredentialsProvider(requestConfig, CLIENT_CREDENTIALS);
        assertEquals(CLIENT_CREDENTIALS, actual);
    }
	
	/**
	 * Test method for {@link com.ielts.cmds.common.config.JmsListnerConfig#awsCredentialsProvider()}.
	 */
	@Test
	void testAwsCredentialsProvider() {
		
		 assertThrows(ClassCastException.class, new Executable() {
             
	            @Override
	            public void execute() throws Throwable {
	            	AWSSecurityTokenService stsClient = AWSSecurityTokenServiceClientBuilder.standard().withRegion("test")
							.withCredentials((AWSCredentialsProvider) new BasicAWSCredentials("", "")).build();
			
					new STSAssumeRoleSessionCredentialsProvider.Builder("test", "")
							.withStsClient(stsClient).build();
	            }
	        });
			
	}
}
