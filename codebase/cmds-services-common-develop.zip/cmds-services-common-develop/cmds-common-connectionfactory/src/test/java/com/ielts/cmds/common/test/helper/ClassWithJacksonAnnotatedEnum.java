package com.ielts.cmds.common.test.helper;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;

public class ClassWithJacksonAnnotatedEnum {
	
	@JsonProperty("booking_line_uuid")
	  private UUID bookingLineUuid;

	  @JsonProperty("externalBookingLineUuid")
	  private UUID externalBookingLineUuid;

	  @JsonProperty("startDateTime")
	  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
	  private OffsetDateTime startDateTime;

	  @JsonProperty("startTimeLocal")
	  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
	  private OffsetDateTime startTimeLocal;

	  @JsonProperty("extraTimeMinutes")
	  private BigDecimal extraTimeMinutes;

	  @JsonProperty("productUuid")
	  private UUID productUuid;

	  /**
	   * Exempt is deprecated. Active is used for active booking lines and regular booking is supposed to have all booking lines marked as active. Inactive is going to be used in SSRs to mark booking lines components that are not resited.
	   */
	  public enum BookingLineStatusEnum {
	    ACTIVE("ACTIVE");

	    private String value;

	    BookingLineStatusEnum(String value) {
	      this.value = value;
	    }

	    @JsonValue
	    public String getValue() {
	      return value;
	    }

	    @Override
	    public String toString() {
	      return String.valueOf(value);
	    }

	    @JsonCreator
	    public static BookingLineStatusEnum fromValue(String value) {
	      for (BookingLineStatusEnum b : BookingLineStatusEnum.values()) {
	        if (b.value.equals(value)) {
	          return b;
	        }
	      }
	      throw new IllegalArgumentException("Unexpected value '" + value + "'");
	    }
	  }

	  @JsonProperty("bookingLineStatus")
	  private BookingLineStatusEnum bookingLineStatus;
	  
	  
		  /**
		   * Get bookingLineUuid
		   * @return bookingLineUuid
		  */
		  @Valid 
		  public UUID getBookingLineUuid() {
		    return bookingLineUuid;
		  }

		  public void setBookingLineUuid(UUID bookingLineUuid) {
		    this.bookingLineUuid = bookingLineUuid;
		  }

		  
		  /**
		   * Get externalBookingLineUuid
		   * @return externalBookingLineUuid
		  */
		  @NotNull @Valid 
		  public UUID getExternalBookingLineUuid() {
		    return externalBookingLineUuid;
		  }

		  public void setExternalBookingLineUuid(UUID externalBookingLineUuid) {
		    this.externalBookingLineUuid = externalBookingLineUuid;
		  }

		  

		  /**
		   * Get startDateTime
		   * @return startDateTime
		  */
		  @NotNull @Valid 
		  public OffsetDateTime getStartDateTime() {
		    return startDateTime;
		  }

		  public void setStartDateTime(OffsetDateTime startDateTime) {
		    this.startDateTime = startDateTime;
		  }


		  /**
		   * Get startTimeLocal
		   * @return startTimeLocal
		  */
		  @NotNull @Valid 
		  public OffsetDateTime getStartTimeLocal() {
		    return startTimeLocal;
		  }

		  public void setStartTimeLocal(OffsetDateTime startTimeLocal) {
		    this.startTimeLocal = startTimeLocal;
		  }

		  /**
		   * Get extraTimeMinutes
		   * @return extraTimeMinutes
		  */
		  @Valid 
		  public BigDecimal getExtraTimeMinutes() {
		    return extraTimeMinutes;
		  }

		  public void setExtraTimeMinutes(BigDecimal extraTimeMinutes) {
		    this.extraTimeMinutes = extraTimeMinutes;
		  }


		  /**
		   * Get productUuid
		   * @return productUuid
		  */
		  @NotNull @Valid 
		  public UUID getProductUuid() {
		    return productUuid;
		  }

		  public void setProductUuid(UUID productUuid) {
		    this.productUuid = productUuid;
		  }

		  /**
		   * Exempt is deprecated. Active is used for active booking lines and regular booking is supposed to have all booking lines marked as active. Inactive is going to be used in SSRs to mark booking lines components that are not resited.
		   * @return bookingLineStatus
		  */
		  @NotNull 
		  public BookingLineStatusEnum getBookingLineStatus() {
		    return bookingLineStatus;
		  }

		  public void setBookingLineStatus(BookingLineStatusEnum bookingLineStatus) {
		    this.bookingLineStatus = bookingLineStatus;
		  }
}

