package com.ielts.cmds.common.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.auth.STSAssumeRoleSessionCredentialsProvider;
import com.amazonaws.services.securitytoken.AWSSecurityTokenService;
import com.amazonaws.services.securitytoken.AWSSecurityTokenServiceClientBuilder;

/**
 * @author cts
 *
 */

@Configuration
public class AWSCredentialsProviderFactory {

	@Value("${aws.region:}")
	private String awsRegion;

	@Value("${aws.assumeRoleARN:}")
	private String roleArn;

	@Value("${aws.assumeRoleSessionName:}")
	private String sessionName;
	
	/**
	 * @return
	 */
	@Bean
	public AWSCredentialsProvider awsStsCredentialsProvider() {
		
			AWSSecurityTokenService stsClient = AWSSecurityTokenServiceClientBuilder.standard().withRegion(awsRegion)
					.withCredentials(new DefaultAWSCredentialsProviderChain()).build();

			return new STSAssumeRoleSessionCredentialsProvider.Builder(roleArn, sessionName)
					.withStsClient(stsClient).build();
		
	}
}
