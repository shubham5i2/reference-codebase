package com.ielts.cmds.common;

public class ConnectionFactoryConstants {

  private ConnectionFactoryConstants() {}

  public static final String OPERATIONS_USER = "Operations User";
  public static final String LOCAL_PROFILE = "local";
  public static final String VISIBILITY_TIMEOUT = "VisibilityTimeout";
}
