/**
 * 
 */
package com.ielts.cmds.common.config;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;

/**
 * @author vedire
 *
 */
public interface IApplicationService {

	/**
	 * Process the event.
	 * 
	 * @param baseEvent event that comes from SQS
	 * 
	 * @throws JsonProcessingException in case of body of the event cannot be parsed
	 */
	void process(final BaseEvent<? extends BaseHeader> baseEvent) throws ProcessingException;
	
	/**
	 * Service identifier reflects the event name in the event header envelope. The service is applicable only 
	 * to handle events of that name.
	 * 
	 * @return
	 */
	String getServiceIdentifier();

}
