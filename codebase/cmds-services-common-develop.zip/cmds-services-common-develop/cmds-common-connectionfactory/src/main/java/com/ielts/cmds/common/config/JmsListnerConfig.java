package com.ielts.cmds.common.config;

import static com.ielts.cmds.common.ConnectionFactoryConstants.VISIBILITY_TIMEOUT;

import java.util.Arrays;
import java.util.Objects;

import javax.jms.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.support.destination.DestinationResolver;
import org.springframework.jms.support.destination.DynamicDestinationResolver;

import com.amazon.sqs.javamessaging.ProviderConfiguration;
import com.amazon.sqs.javamessaging.SQSConnectionFactory;
import com.amazonaws.AmazonWebServiceRequest;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.handlers.RequestHandler2;
import com.amazonaws.services.databasemigrationservice.AWSDatabaseMigrationService;
import com.amazonaws.services.databasemigrationservice.AWSDatabaseMigrationServiceClientBuilder;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.AmazonSNSClientBuilder;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSAsyncClientBuilder;
import com.amazonaws.services.sqs.model.ChangeMessageVisibilityBatchRequest;
import com.amazonaws.services.sqs.model.GetQueueAttributesResult;
import com.ielts.cmds.common.ConnectionFactoryConstants;

import lombok.extern.slf4j.Slf4j;

/**
 * @author cts
 *     <p>Configure Listener Properties
 */
@Configuration
@EnableJms
@Slf4j
public class JmsListnerConfig {

  @Value("${aws.region}")
  private String awsRegion;

  @Value("${aws.queue.concurrency}")
  private String queueConcurrency;

  @Value("${aws.queue.prefetchMessages:1}")
  private int numberOfMessagesToPrefetch;

  @Value("${spring.profiles.active}")
  private String activeProfile;

  @Autowired private AWSCredentialsProvider awsCredentialsProvider;

  private SQSConnectionFactory connectionFactory;

  private AmazonSQS sqs;

  /** @return */
  @Bean
  @Primary
  @Profile("!local")
  public AmazonSNS snsClient() {
    return AmazonSNSClientBuilder.standard().withRegion(awsRegion).build();
  }

  /** @return */
  @Bean("snsClient")
  @Profile("local")
  public AmazonSNS snsClientLocal() {
    return AmazonSNSClientBuilder.standard()
        .withRegion(awsRegion)
        .withCredentials(awsCredentialsProvider)
        .build();
  }

  /** @return */
  @Bean
  @Primary
  @Profile("!local")
  public AmazonS3 s3Client() {
    return AmazonS3ClientBuilder.standard().withRegion(awsRegion).build();
  }

  /** @return */
  @Bean("s3Client")
  @Profile("local")
  public AmazonS3 s3ClientLocal() {
    return AmazonS3ClientBuilder.standard()
        .withRegion(awsRegion)
        .withCredentials(awsCredentialsProvider)
        .build();
  }

  /** @return AWSDatabaseMigrationService */
  @Bean
  @Primary
  @Profile("!local")
  public AWSDatabaseMigrationService awsDmsClient() {
    return AWSDatabaseMigrationServiceClientBuilder.standard().withRegion(awsRegion).build();
  }

  /** @return AWSDatabaseMigrationService */
  @Bean("awsDmsClient")
  @Profile("local")
  public AWSDatabaseMigrationService awsDmsClientLocal() {
    return AWSDatabaseMigrationServiceClientBuilder.standard()
        .withRegion(awsRegion)
        .withCredentials(awsCredentialsProvider)
        .build();
  }

  /** @return */
  @Bean
  public DestinationResolver destinationResolver() {
    return new DynamicDestinationResolver();
  }

  /** @return */
  @Bean
  @Profile("local")
  public DefaultJmsListenerContainerFactory jmsListenerContainerFactory() {
    log.info("active profile is local");
    sqs = buildSqs(activeProfile);
    connectionFactory =
        new SQSConnectionFactory(
            new ProviderConfiguration().withNumberOfMessagesToPrefetch(numberOfMessagesToPrefetch),
            sqs);
    DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
    factory.setConnectionFactory(connectionFactory);
    factory.setDestinationResolver(new DynamicDestinationResolver());
    factory.setConcurrency(queueConcurrency);
    factory.setErrorHandler(error -> log.error("Error in listener!", error));
    factory.setSessionAcknowledgeMode(Session.CLIENT_ACKNOWLEDGE);
    return factory;
  }

  public AmazonSQS buildSqs(final String profile) {

    final AmazonSQSAsyncClientBuilder sqsBuilder =
        AmazonSQSAsyncClientBuilder.standard().withRequestHandlers(getCustomHandler());

    if (ConnectionFactoryConstants.LOCAL_PROFILE.equals(profile)) {
      sqsBuilder.withRegion(awsRegion).withCredentials(awsCredentialsProvider);
    }

    return sqsBuilder.build();
  }

  public RequestHandler2 getCustomHandler() {

    // NegativeAcknowledger

    return new RequestHandler2() {

      @Override
      public AmazonWebServiceRequest beforeExecution(AmazonWebServiceRequest request) {

        if (request instanceof ChangeMessageVisibilityBatchRequest) {

          ChangeMessageVisibilityBatchRequest visibilityRequest =
              ((ChangeMessageVisibilityBatchRequest) request);

          final GetQueueAttributesResult getQueueAttributesResult =
              getQueueVisibilityTimeoutAttribute(visibilityRequest.getQueueUrl());

          final String visibilityTimeOutvalue =
              getQueueAttributesResult.getAttributes().get(VISIBILITY_TIMEOUT);

          final Integer visibilityTimeOut =
              Objects.nonNull(visibilityTimeOutvalue)
                  ? Integer.parseInt(visibilityTimeOutvalue)
                  : 0;

          visibilityRequest
              .getEntries()
              .forEach(
                  changeMessageVisibilityBatchRequestEntry ->
                      changeMessageVisibilityBatchRequestEntry.setVisibilityTimeout(
                          visibilityTimeOut));
        }
        return request;
      }
    };
  }

  GetQueueAttributesResult getQueueVisibilityTimeoutAttribute(String queueUrl) {

    return sqs.getQueueAttributes(queueUrl, Arrays.asList(VISIBILITY_TIMEOUT));
  }

  /** @return */
  @Bean("jmsListenerContainerFactory")
  @Primary
  @Profile("!local")
  public DefaultJmsListenerContainerFactory jmsListenerContainerFactoryIamRole() {
    log.info("active profile is non-local");
    sqs = buildSqs(activeProfile);
    connectionFactory =
        new SQSConnectionFactory(
            new ProviderConfiguration().withNumberOfMessagesToPrefetch(numberOfMessagesToPrefetch),
            sqs);
    DefaultJmsListenerContainerFactory defaultJmsListenerContainerFactory =
        new DefaultJmsListenerContainerFactory();
    defaultJmsListenerContainerFactory.setConnectionFactory(connectionFactory);
    defaultJmsListenerContainerFactory.setDestinationResolver(new DynamicDestinationResolver());
    defaultJmsListenerContainerFactory.setConcurrency(queueConcurrency);
    defaultJmsListenerContainerFactory.setErrorHandler(
        error -> log.error("Error in listener!", error));
    defaultJmsListenerContainerFactory.setSessionAcknowledgeMode(Session.CLIENT_ACKNOWLEDGE);
    return defaultJmsListenerContainerFactory;
  }

  /** @return */
  @Bean
  public JmsTemplate defaultJmsTemplate() {
    return new JmsTemplate(connectionFactory);
  }
}
