package com.ielts.cmds.common.exception;

public class ProcessingException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ProcessingException(String message, Throwable cause) {
        super(message, cause);
    }
}
