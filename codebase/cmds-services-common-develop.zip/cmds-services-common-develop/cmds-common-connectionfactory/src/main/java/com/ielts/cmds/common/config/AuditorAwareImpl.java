package com.ielts.cmds.common.config;

import java.util.Optional;

import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.context.SecurityContextHolder;

import com.ielts.cmds.common.ConnectionFactoryConstants;

/**
 * Class that implements AuditowAware interface
 * 
 * @author nshrir
 *
 */
public class AuditorAwareImpl implements AuditorAware<String> {

	/**
	 * Method which returns the user who performs the operation
	 * 
	 * @return {@link Optional} {@link String}
	 */
	@Override
	public Optional<String> getCurrentAuditor() {
		if(SecurityContextHolder.getContext().getAuthentication()!=null 
				&& SecurityContextHolder.getContext().getAuthentication().getName() != null 
				&& SecurityContextHolder.getContext().getAuthentication().getName().startsWith("auth0|")) {
			// returns the uuid part of the current user
			return Optional.ofNullable(SecurityContextHolder.getContext().getAuthentication().getName().substring(6));
		}
		else {
			return Optional.of(getDefaultUser());
		}
			
	}
	
	/**
	 * Method to return the default user
	 * @return
	 */
	protected String getDefaultUser() {
		return ConnectionFactoryConstants.OPERATIONS_USER;
	}
}
