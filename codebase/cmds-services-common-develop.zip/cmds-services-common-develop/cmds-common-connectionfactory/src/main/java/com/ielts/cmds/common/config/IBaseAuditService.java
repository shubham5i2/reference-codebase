/**
 * 
 */
package com.ielts.cmds.common.config;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.context.CMDSAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;

/**
 * Interface which can be implemented to populate BaseAudit fields
 * 
 * @author nshrir
 *
 */
public interface IBaseAuditService {
	
	/**
	 * Default method to populate screen action and permission in base audit
	 * 
	 * @param audit
	 */
	default void populateAuditFields(BaseAudit audit) {
		audit.setPermission(getPermission());
		Map<String, String> auditContext = Optional.ofNullable(audit.getAuditContext()).orElseGet(HashMap::new);
		auditContext.put("screen", getScreen());
		auditContext.put("action", getAction());
		audit.setAuditContext(auditContext);
	}
	
	default void populateAuditFields() {
		final CMDSAuditContext audit = Optional.ofNullable(ThreadLocalAuditContext.getContext())
				.orElse(new CMDSAuditContext());
		audit.setPermission(getPermission());
		Map<String, String> auditContext = Optional.ofNullable(audit.getAuditContext()).orElseGet(HashMap::new);
		auditContext.put("screen", getScreen());
		auditContext.put("action", getAction());
		audit.setAuditContext(auditContext);
		ThreadLocalAuditContext.setContext(audit);
	}
	
	/**
	 * Returns the permission used for this action
	 * 
	 * @return {@link String}
	 */
	String getPermission();
	
	/**
	 * Returns the screen from which the request originated
	 * 
	 * @return {@link String}
	 */
	String getScreen();
	
	/**
	 * Returns the name of the command object used to process this request
	 * 
	 * @return {@link String}
	 */
	String getAction();

}
