
\ir reference_dml//insert_country.sql
update lpr_owner.country set legacy_reference='SUN' where country_uuid='018a95fe-fb24-43f9-a972-2cadce41e822';
update lpr_owner.country set legacy_reference='MAR' where country_uuid='9a8a63bc-2d9f-4289-b31c-b093204bb834';

--select count(*) from lpr_owner.country-255
--select legacy_reference from lpr_owner.country where country_uuid='018a95fe-fb24-43f9-a972-2cadce41e822';
--select legacy_reference from lpr_owner.country where country_uuid='9a8a63bc-2d9f-4289-b31c-b093204bb834';

\ir  reference_dml//insert_identification_type.sql

--select effective_to_date from lpr_owner.identification_type where identification_type_uuid='8b271679-ecf6-4fed-b3d3-e102f49a55b5';

\ir  reference_dml//insert_sector_type.sql

--select count(*) from lpr_owner.sector_type-17