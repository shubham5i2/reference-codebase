#!/bin/bash
config_file="$1"
pass_count=0
fail_count=0
node_type=""
output_file_name=""

if [ ! -f "${config_file}" ]; then
	echo "File does not exist in the given path"
	exit 1
fi

function print_count(){
	echo -e "\nLocation Type:\t$node_type"
	echo -e "Passed Entries:\t$pass_count"
	echo -e "Failures:\t$fail_count \n"
}

function execute(){
	dos2unix $header
	pass_count=0
	fail_count=0
	
	#Iterating Location type directory
	for file in "$subDirectory"/*; do
		dos2unix $file
		
		create_log
		
		echo "URL: $url" >> "response/${output_file_name}"
		echo "Method: $method" >> "response/${output_file_name}"
		echo "Header:" >> "response/${output_file_name}"
		cat $header >> "response/${output_file_name}"
		echo -e "\nRequest JSON:" >> "response/${output_file_name}"
		cat $file >> "response/${output_file_name}"
		echo -e "\nResponse JSON:" >> "response/${output_file_name}"

		#New correlationId generation for each request
		correlationId=$(uuidgen)
		echo -e "\ncorrelationId :\t$correlationId"
		eventDateTime=$(date +"%FT%T.%3NZ")
		echo -e "\neventDateTime :\t$eventDateTime"
		#cURL execution
		response_json=$( curl -X $method --url "$url" -d @$file -H @$header -H "eventDateTime:$eventDateTime" -H "correlationId:$correlationId")
		
		if [[ "$response_json" == *"transactionId"* ]]; then
			pass_count=$((pass_count+1))
		else 
			fail_count=$((fail_count+1))
			print_count
			echo "STOPPED: Stopping further execution due to ${file} failure with location type ${node_type}"
			echo "$response_json" >> "response/${output_file_name}"
			exit 1
		fi
		echo "$response_json" >> "response/${output_file_name}"
	done
}

function create_log(){
	mkdir -p response
		echo "Writing log output to file..."
		output=$( echo "$file" | sed -r "s/.+\/(.+)\..+/\1/" )
		timestamp=`date "+%Y%m%d-%H%M%S%3N"`
		output_file_name="${node_type}_${output}_response_${timestamp}.log"
}


function read_config(){
	while IFS= read -r line || [ -n "$line" ]; do
		count=`grep -o "=" <<< "$line" | wc -l`
		if [ ! "$count" = "1" ]; then
			echo "Property should be in the form of 'key=value' format. Make sure there are no empty lines in the config file"
			exit 1
		fi
		key=$(echo -e $line | cut -f1 -d= | tr -d '[:space:]')
		val=$(echo -e $line | cut -f2 -d= | tr -d '[:space:]')
		if [ -z "${key}" ] || [ -z "${val}" ] || [ "$key" = "" ] || [ "$val" = "" ]; then
			echo "Key/Value cannot be empty. Make sure there are no empty lines in the config file"
			exit 1
		fi
		if [ "$key" = "header_path" ] && [ -f "$val" ]; then
			header=$val
		elif [ "$key" = "url" ]; then
			url=$val
		elif [ "$key" = "json_directory" ] && [ -d "$val" ]; then
			directory=$val
		elif [ "$key" = "env" ]; then
			env=$val
		elif [ "$key" = "method" ] && [ "$val" = "POST" ]; then
			method=$val
		else
			echo "Invalid Configuration Property: $key : $val"
			exit 1
		fi
	done < "$config_file"
	
	if [ -z "${header}" ] || [ -z "${url}" ] || [ -z "${directory}" ] || [ -z "${method}" ] || [ -z "${env}" ]; then
		echo "Missing Mandatory Configuration Property. You may get this if your path to header file or json directory does not exist or invalid. You may also get this if method is not one of POST/PUT/DELETE"
		exit 1
	fi
}

#Read config files
read_config
location_hierarchy_files=( "partner" "region" "country" )
location_hierarchy_enum=( "PARTNER" "REGION" "COUNTRY" )

for ((i=0; i<${#location_hierarchy_files[@]}; i++))
do
	subDirectory="${directory}/${env}/${location_hierarchy_files[i]}"
	node_type=${location_hierarchy_enum[i]}
	execute ${subDirectory}
	print_count 
done




