**Instructions to execute cURL scripts**

**Pre requisites**

`uuidgen` 
- For debian, `sudo apt-get install uuid-runtime`
- For alpine, `apk add util-linux`
- For centOS, `yum install util-linux`
- For Windows 10: Windows 10 SDK comes with inbuilt `uuidgen`. 
It can be found in the following path `C:\Program Files (x86)\Windows Kits\10\bin\10.0.17763.0\x64`. Add this path to your environment variables so that the script can be executed from anywhere. If this is not present in the above folder, please search for `uuidgen.exe` in Program Files and Program Files (x86) folders.

**Execution Steps**
- Download the entire directory from git as .zip
- Extract the zip and go inside the cURLScripts directory.
- Add proper parameters in config.properties as per environment (url,env) .
- env in config.properties will have values "OTHER" for any environment lower than PROD.It will be "PROD" for PROD environment.
- Trigger request to auth0 url to get the access token and add it to `lprHeaders` file
- Open your cmd or git bash and go to the location where `curlScript.sh` is present.
- Execute using `./curlScript.sh config.properties`.

**Execution Steps For BC_CHN Locations File**
- Download the entire directory from git as .zip
- Data **should not** be truncated before the execution.
- Extract the zip and go inside the cURLScripts directory.
- Add proper parameters in config.properties as per environment (url,env) .
- For executing curlscript for BC_CHN locations, specify env value as 'BC_CHN' in config.properties file.
- Trigger request to auth0 url to get the access token and add it to `lprHeaders` file
- Open your cmd or git bash and go to the location where `curlScript_BC_CHN.sh` is present.
- Execute using `./curlScript_BC_CHN.sh config.properties`.

**Post Execution Checks**
- All requests were triggered 
- Log files got generated inside `response` folder for each request

