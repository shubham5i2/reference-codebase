-- IELTS LPR Microservice SQL scripts

\c lpr
\i set_client_encoding.sql
\i create_user_schema_ddl.sql
\i add_uuid_extension.sql

--Reference DDL scripts
\ir  reference_ddl//create_access_arrangement.sql
\ir  reference_ddl//create_address_type.sql
\ir  reference_ddl//create_allocation_group.sql
\ir  reference_ddl//create_country.sql
\ir  reference_ddl//create_contact_type.sql
\ir  reference_ddl//create_education_level.sql
\ir  reference_ddl//create_gender.sql
\ir  reference_ddl//create_identification_type.sql
\ir  reference_ddl//create_language.sql
\ir  reference_ddl//create_mark_criteria.sql
\ir  reference_ddl//create_module_type.sql
\ir  reference_ddl//create_nationality.sql
\ir  reference_ddl//create_note_type.sql
\ir  reference_ddl//create_occupation_level.sql
\ir  reference_ddl//create_occupation_sector.sql
\ir  reference_ddl//create_organisation_type.sql
\ir  reference_ddl//create_partner.sql
\ir  reference_ddl//create_reason_for_test.sql
\ir  reference_ddl//create_sector_type.sql
\ir  reference_ddl//create_territory.sql
\ir  reference_ddl//create_results_status_type.sql
\ir  reference_ddl//create_results_status_label.sql
\ir  reference_ddl//create_results_status_comment.sql
\ir  reference_ddl//create_results_type.sql
\ir  reference_ddl//create_outcome_status_type.sql
\ir  reference_ddl//create_check_outcome_status.sql
\ir  reference_ddl//create_check_outcome_type.sql
\ir  reference_ddl//create_incident_category.sql
\ir  reference_ddl//create_incident_type.sql
\ir  reference_ddl//create_incident_status_type.sql
\ir  reference_ddl//create_photo_type.sql

-- Product DDL scripts
\ir  product_ddl//create_product.sql

-- Location DDL scripts
\ir  location_ddl//create_location.sql
\ir  location_ddl//create_location_address.sql
\ir  location_ddl//create_location_product_authorisation.sql

--Reference DML scripts
\ir  reference_dml//insert_address_type.sql
\ir  reference_dml//insert_contact_type.sql
\ir  reference_dml//insert_country.sql
\ir  reference_dml//insert_education_level.sql
\ir  reference_dml//insert_gender.sql
\ir  reference_dml//insert_identification_type.sql
\ir  reference_dml//insert_language.sql
\ir  reference_dml//insert_mark_criteria.sql
\ir  reference_dml//insert_module_type.sql
\ir  reference_dml//insert_nationality.sql
\ir  reference_dml//insert_note_type.sql
\ir  reference_dml//insert_occupation_level.sql
\ir  reference_dml//insert_occupation_sector.sql
\ir  reference_dml//insert_organisation_type.sql
\ir  reference_dml//insert_partner.sql
\ir  reference_dml//insert_reason_for_test.sql
\ir  reference_dml//insert_sector_type.sql
\ir  reference_dml//insert_territory.sql
\ir  reference_dml//insert_results_status_type.sql
\ir  reference_dml//insert_results_status_label.sql
\ir  reference_dml//insert_results_status_comment.sql
\ir  reference_dml//insert_results_type.sql
\ir  reference_dml//insert_outcome_status_type.sql
\ir  reference_dml//insert_check_outcome_status.sql
\ir  reference_dml//insert_check_outcome_type.sql
\ir  reference_dml//insert_incident_category.sql
\ir  reference_dml//insert_incident_type.sql
\ir  reference_dml//insert_incident_status_type.sql
\ir  reference_dml//insert_photo_type.sql

--Product DML scripts**//
\ir  product_dml//insert_product.sql
