--DML scripts for results type
INSERT INTO lpr_owner.results_type(results_type_uuid, results_type,  results_type_code, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('385eb1aa-d205-481e-af0c-cd5afab98402',
		'Incomplete',
        'INCOMPLETE',
		'2023-05-08',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_type_uuid) DO NOTHING;

