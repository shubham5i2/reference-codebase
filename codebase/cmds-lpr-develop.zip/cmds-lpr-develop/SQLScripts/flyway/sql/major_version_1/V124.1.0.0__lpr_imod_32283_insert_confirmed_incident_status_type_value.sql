insert into lpr_owner.incident_status_type 
(incident_status_type_uuid, incident_status_type, incident_status_type_code, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
values('b64a0e01-90f7-4545-9f9d-22ab6d88e873','Confirmed',
'INC_STATUS_CONFIRMED','2020-07-01','2099-12-31','Operations User',
'2021-09-23 14:42:50.111 +0530',null,null,0)ON CONFLICT(incident_status_type_uuid) DO NOTHING;