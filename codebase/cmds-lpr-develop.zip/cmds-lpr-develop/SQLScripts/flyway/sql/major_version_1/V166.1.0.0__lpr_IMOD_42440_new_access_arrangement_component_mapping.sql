INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('3b3cf72c-ec6c-4040-9ff0-c3d90780a0b9',
			'36919201-eb3c-46a3-8f44-9b2730fae3b8',
			'5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
			'L',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;
		
INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('09570f73-c048-4d48-976f-bfeb59ade1e0',
			'52b87476-5fb2-4eca-8af7-5e914c6ab72a',
			'637f8e1b-0931-4184-9fed-37bc9fdb53d5',
			'L',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;
		
