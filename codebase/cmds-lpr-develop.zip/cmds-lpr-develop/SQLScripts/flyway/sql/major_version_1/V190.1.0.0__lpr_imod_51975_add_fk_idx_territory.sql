CREATE INDEX idx_t_country_uuid ON lpr_owner.territory(country_uuid);
