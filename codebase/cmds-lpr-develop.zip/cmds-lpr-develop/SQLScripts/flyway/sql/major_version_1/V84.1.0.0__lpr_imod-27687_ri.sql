INSERT INTO lpr_owner.check_outcome_status
(check_outcome_status_uuid, check_outcome_status, check_outcome_status_code, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('2628a41f-2a20-4dfe-ba40-5dc3a17c593e'::uuid, 'Investigation in progress', 'CHK_OUT_INVESTIGATION_IN_PROGRESS', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0);
