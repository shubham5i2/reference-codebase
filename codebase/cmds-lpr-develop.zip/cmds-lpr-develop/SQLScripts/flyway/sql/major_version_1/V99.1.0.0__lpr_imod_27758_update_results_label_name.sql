
		
UPDATE lpr_owner.results_status_label SET results_status_label='Post-release Grade Change' WHERE results_status_label_uuid='12b2e233-81a4-4263-b327-9b47ba09eb53' AND results_status_label_code='POST_RELEASE_GRADE_CHANGE';