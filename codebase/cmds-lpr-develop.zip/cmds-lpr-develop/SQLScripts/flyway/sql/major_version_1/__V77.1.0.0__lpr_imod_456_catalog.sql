CREATE TABLE catalog(
    id SERIAL PRIMARY KEY,
    name VARCHAR(45) NOT NULL,
    product_name VARCHAR(45) NOT NULL,
    serial_number VARCHAR(30),
    price VARCHAR(100) NOT NULL 
);

