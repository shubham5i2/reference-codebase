UPDATE lpr_owner.identification_type SET characteristics='{"characteristics" : ["IOC", "IOP", "IOL", "SSR", "SELT","OSR"]}' where identification_type_uuid ='b0344576-5cf2-4822-9f99-4d4afb03667a';

UPDATE lpr_owner.identification_type SET characteristics='{"characteristics" : ["IOC", "IOP", "IOL", "SSR", "SELT","OSR"]}' where identification_type_uuid ='c59ffdcd-5795-4376-8f15-34a6bf249df5';
