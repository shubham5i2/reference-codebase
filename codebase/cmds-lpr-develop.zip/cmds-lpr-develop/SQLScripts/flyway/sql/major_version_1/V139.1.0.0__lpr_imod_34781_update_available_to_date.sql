UPDATE lpr_owner.product SET available_to_date='2022-03-28' where product_uuid='7b1d8d96-c314-40cd-a61c-2b681086a458';

UPDATE lpr_owner.product SET available_to_date='2022-03-28' where product_uuid='a489fddd-9bb5-4ed4-9678-0a88bde4778c';

UPDATE lpr_owner.product SET available_to_date='2022-03-28' where product_uuid='c5524e22-ec61-4705-b7d1-5818826b7cd1';

UPDATE lpr_owner.product SET available_to_date='2022-03-28' where product_uuid='d5d4392d-b3c7-4a99-b039-98a281c0104d';

UPDATE lpr_owner.product SET available_to_date='2022-03-28' where product_uuid='304d2fa4-642d-4ec7-8600-ae21eb8b4dd8';