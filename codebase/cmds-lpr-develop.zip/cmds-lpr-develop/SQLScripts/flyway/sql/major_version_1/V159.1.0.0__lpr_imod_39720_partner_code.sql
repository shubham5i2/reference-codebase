INSERT INTO lpr_owner.partner (partner_uuid, partner_code, partner_name, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('e28e8ca3-0545-43cd-9678-aae1c9eb0171',
        'BC_CHN',
        'British Council China',
        '2023-01-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(partner_uuid) DO NOTHING;


