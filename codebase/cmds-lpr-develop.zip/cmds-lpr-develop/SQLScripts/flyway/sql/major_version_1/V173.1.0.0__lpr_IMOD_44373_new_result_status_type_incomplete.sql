INSERT INTO lpr_owner.results_status_type(results_status_type_uuid, results_status, results_status_code, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('c9a8aecc-b4c6-418c-84d8-1fa32e47387c',
		'Incomplete',
		'INCOMPLETE',
		'2023-05-08',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_type_uuid) DO NOTHING;