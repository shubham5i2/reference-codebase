DELETE FROM lpr_owner.results_status_comment WHERE results_status_comment_uuid='531801cc-286d-4e96-bff5-cb4b463639ad';

DELETE FROM lpr_owner.results_status_comment WHERE results_status_comment_uuid='2d132b7e-3880-42f6-831a-e79d5ead9059';
