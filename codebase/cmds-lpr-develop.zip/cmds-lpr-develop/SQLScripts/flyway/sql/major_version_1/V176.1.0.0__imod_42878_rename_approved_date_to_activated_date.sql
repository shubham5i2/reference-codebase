ALTER TABLE lpr_owner.location RENAME COLUMN approved_date TO activated_date;
