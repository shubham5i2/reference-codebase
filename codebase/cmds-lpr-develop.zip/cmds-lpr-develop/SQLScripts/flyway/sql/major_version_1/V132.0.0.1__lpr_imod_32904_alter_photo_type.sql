ALTER TABLE lpr_owner.photo_type ALTER COLUMN photo_type_code TYPE character varying(50)
