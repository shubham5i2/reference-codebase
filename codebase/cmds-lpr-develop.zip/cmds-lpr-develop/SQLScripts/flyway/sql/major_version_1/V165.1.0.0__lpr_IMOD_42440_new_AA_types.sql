INSERT INTO lpr_owner.access_arrangement_type(access_arrangement_type_uuid, access_arrangement_code, access_arrangement_name, ca_approval_required, modified_material_required, endorsement_required, created_by, updated_by, updated_datetime, concurrency_version)
	VALUES ('52b87476-5fb2-4eca-8af7-5e914c6ab72a',
			'REP',
			'Replay audio',
			false,
			false,
			false,
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_type_uuid) DO NOTHING;

INSERT INTO lpr_owner.access_arrangement_type(access_arrangement_type_uuid, access_arrangement_code, access_arrangement_name, ca_approval_required, modified_material_required, endorsement_required, created_by, updated_by, updated_datetime, concurrency_version)
	VALUES ('36919201-eb3c-46a3-8f44-9b2730fae3b8',
			'PAU',
			'Pause audio',
			false,
			false,
			false,
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_type_uuid) DO NOTHING;
