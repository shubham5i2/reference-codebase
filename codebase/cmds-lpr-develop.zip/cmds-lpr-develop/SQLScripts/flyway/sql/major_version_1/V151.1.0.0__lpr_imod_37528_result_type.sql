INSERT INTO lpr_owner.results_type(results_type_uuid, results_type,  results_type_code, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('40304906-b30d-4b0f-b910-e5769f916d77',
		'Absent',
        'ABSENT',
		'2022-10-27',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_type_uuid) DO NOTHING;
