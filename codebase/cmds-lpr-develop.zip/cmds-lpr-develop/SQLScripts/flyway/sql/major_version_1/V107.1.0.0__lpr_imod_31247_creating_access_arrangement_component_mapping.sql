-- access_arrangement_component_mapping Table Creation
CREATE TABLE IF NOT EXISTS lpr_owner.access_arrangement_component_mapping (
	access_arrangement_component_mapping_uuid UUID NOT NULL,
	access_arrangement_type_uuid UUID NOT NULL,
	delivery_method_uuid UUID NOT NULL,
	component lpr_owner.component_type NOT NULL,
	effective_from_date DATE NOT NULL DEFAULT '2020-07-01',
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
	created_by varchar(36) NOT NULL,
	created_datetime timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_by varchar(36) NULL,
	updated_datetime timestamptz NULL,
	concurrency_version INTEGER NOT NULL,
	CONSTRAINT pk_access_arrangement_component_mapping_uuid PRIMARY KEY (access_arrangement_component_mapping_uuid),
	CONSTRAINT fk_01_access_arrangement_component_mapping_access_arrangement FOREIGN KEY (access_arrangement_type_uuid) REFERENCES lpr_owner.access_arrangement_type (access_arrangement_type_uuid),
	CONSTRAINT fk_02_access_arrangement_component_mapping_product FOREIGN KEY (delivery_method_uuid) REFERENCES lpr_owner.product (product_uuid)
);

