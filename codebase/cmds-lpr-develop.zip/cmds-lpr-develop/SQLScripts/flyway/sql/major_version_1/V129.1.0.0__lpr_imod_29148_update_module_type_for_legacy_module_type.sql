UPDATE lpr_owner.module_type
SET legacy_module_type='A'
WHERE module_type_uuid='7a28a632-8728-4f74-882e-72e9d3649763';


UPDATE lpr_owner.module_type
SET legacy_module_type='G'
WHERE module_type_uuid='0ae29abe-5862-4c48-92e4-00d7eba376a2';


