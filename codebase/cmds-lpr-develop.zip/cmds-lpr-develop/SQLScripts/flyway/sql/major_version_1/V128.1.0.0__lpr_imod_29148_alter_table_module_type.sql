ALTER TABLE lpr_owner.module_type ADD COLUMN if not exists legacy_module_type VARCHAR(20);



