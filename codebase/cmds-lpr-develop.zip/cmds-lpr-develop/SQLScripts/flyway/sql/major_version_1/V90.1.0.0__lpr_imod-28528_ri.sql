UPDATE lpr_owner.check_outcome_status set check_outcome_status = 'Pending'
WHERE check_outcome_status_uuid = '2628a41f-2a20-4dfe-ba40-5dc3a17c593e';