GRANT DELETE 
ON  lpr_owner.outbox_event, lpr_owner.outbox_event_attribute
TO  lpr_user;
