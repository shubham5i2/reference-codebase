update lpr_owner.product set product_characteristics = '{"characteristics": ["IOL"],"RoAutoAccepted": ["FALSE"]}' where product_uuid = '3e81e94b-8b6a-42b5-970c-b141f9d195a3';

update lpr_owner.product set product_characteristics = '{"characteristics": ["IOL", "SELT"],"RoAutoAccepted": ["FALSE"]}' where product_uuid = '4ca26fd2-5216-4e9a-ba08-89bb94599778';