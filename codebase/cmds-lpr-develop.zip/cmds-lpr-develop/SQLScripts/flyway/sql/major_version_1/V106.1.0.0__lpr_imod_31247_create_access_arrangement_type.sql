DROP TABLE IF EXISTS lpr_owner.access_arrangement_component_mapping;

DROP TABLE IF EXISTS lpr_owner.access_arrangement_type;

-- access_arrangement Table Creation
CREATE TABLE IF NOT EXISTS lpr_owner.access_arrangement_type(
	access_arrangement_type_uuid uuid NOT NULL,
    access_arrangement_code character varying(10) NOT NULL,
	access_arrangement_name character varying(100) NOT NULL,
	ca_approval_required BOOLEAN NOT NULL,
	modified_material_required BOOLEAN NOT NULL,
	endorsement_required BOOLEAN NOT NULL,
	effective_from_date DATE NOT NULL DEFAULT '2020-07-01',
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
	created_by varchar(36) NOT NULL,
	created_datetime timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_by varchar(36) NULL,
	updated_datetime timestamptz NULL,
	concurrency_version INTEGER NOT NULL,
    CONSTRAINT pk_access_arrangement PRIMARY KEY (access_arrangement_type_uuid)
);