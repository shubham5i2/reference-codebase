-- Update description of TT_P_HR_IAM_ADD
UPDATE lpr_owner.photo_type SET effective_from_date='2023-10-06' where photo_type_uuid = 'd03a1dbc-d00b-4e7d-89da-859248fbf7de';

-- Update description of TT_P_ORIGINAL_BOOKING_ADD
UPDATE lpr_owner.photo_type SET effective_from_date='2023-10-06' where photo_type_uuid = 'af60ef99-86bb-4c52-a9a6-3a38bd7e4b0b';

