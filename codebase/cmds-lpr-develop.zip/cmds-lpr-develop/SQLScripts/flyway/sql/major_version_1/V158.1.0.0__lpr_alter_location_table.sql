ALTER TABLE lpr_owner.location RENAME COLUMN location_type_code TO location_type;

ALTER TABLE lpr_owner.location RENAME COLUMN location_status TO status;