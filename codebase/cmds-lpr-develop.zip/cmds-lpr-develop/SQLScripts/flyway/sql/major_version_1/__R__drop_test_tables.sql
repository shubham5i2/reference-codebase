DROP TABLE prime_student;
DROP TABLE catalog;
-- DROP TABLE teacher;

