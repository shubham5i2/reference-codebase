ALTER TABLE lpr_owner.identification_type ADD COLUMN IF NOT EXISTS characteristics VARCHAR(500);
