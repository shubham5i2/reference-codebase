CREATE INDEX idx_la_location_uuid ON lpr_owner.location_address(location_uuid);

CREATE INDEX idx_la_address_type_uuid ON lpr_owner.location_address(address_type_uuid);

CREATE INDEX idx_la_country_iso3_code ON lpr_owner.location_address(country_iso3_code);

CREATE INDEX idx_la_territory_uuid ON lpr_owner.location_address(territory_uuid);