INSERT INTO lpr_owner.ban_reason(
	ban_reason_uuid, ban_description, created_by, updated_datetime, concurrency_version)
	VALUES ('ff7180e1-cf86-4998-ab86-556899183dc0', 'Accessing test materials before/during the test', 'Operations User', NULL, '0')ON CONFLICT(ban_reason_uuid) DO NOTHING;

INSERT INTO lpr_owner.ban_reason(
	ban_reason_uuid, ban_description, created_by, updated_datetime, concurrency_version)
	VALUES ('91f10c54-633e-4659-a5eb-58defdede27b', 'Accessing test materials for different test versions before/during the test', 'Operations User', NULL, '0')ON CONFLICT(ban_reason_uuid) DO NOTHING;

INSERT INTO lpr_owner.ban_reason(
	ban_reason_uuid, ban_description, created_by, updated_datetime, concurrency_version)
	VALUES ('72283e19-6122-4389-b55f-2f3080ca37e7', 'Receiving/providing active assistance in the form of written L/R/W answers during the test', 'Operations User', NULL, '0')ON CONFLICT(ban_reason_uuid) DO NOTHING;

INSERT INTO lpr_owner.ban_reason(
	ban_reason_uuid, ban_description, created_by, updated_datetime, concurrency_version)
	VALUES ('a3fb4d29-7e7b-41ce-afd3-1b7976403dec', 'Use/provision of impersonation service (Using/Acting as an imposter)', 'Operations User', NULL, '0')ON CONFLICT(ban_reason_uuid) DO NOTHING;

INSERT INTO lpr_owner.ban_reason(
	ban_reason_uuid, ban_description, created_by, updated_datetime, concurrency_version)
	VALUES ('7f225f95-b1e2-4978-a2de-d4fc1a75b979', 'In-room identity swap', 'Operations User', NULL, '0')ON CONFLICT(ban_reason_uuid) DO NOTHING;

INSERT INTO lpr_owner.ban_reason(
	ban_reason_uuid, ban_description, created_by, updated_datetime, concurrency_version)
	VALUES ('585bcda7-de7c-483b-ba71-97bebad9d811', 'Mobile/Cell phone or other electronic device used during test', 'Operations User', NULL, '0')ON CONFLICT(ban_reason_uuid) DO NOTHING;

INSERT INTO lpr_owner.ban_reason(
	ban_reason_uuid, ban_description, created_by, updated_datetime, concurrency_version)
	VALUES ('7c70c41d-66a1-48f5-9791-8127f4a9dd69', 'Falsification of Test Report Form', 'Operations User', NULL, '0')ON CONFLICT(ban_reason_uuid) DO NOTHING;

INSERT INTO lpr_owner.ban_reason(
	ban_reason_uuid, ban_description, created_by, updated_datetime, concurrency_version)
	VALUES ('3d3df303-9da6-43b6-a71d-541335dafb1f', 'Disclosing test content after the test is administered', 'Operations User', NULL, '0')ON CONFLICT(ban_reason_uuid) DO NOTHING;

INSERT INTO lpr_owner.ban_reason(
	ban_reason_uuid, ban_description, created_by, updated_datetime, concurrency_version)
	VALUES ('056b90b9-2a5a-4ab8-9feb-3f0d5042d4b5', 'Attempting to gain an IELTS result through financial fraud, bribery or other means', 'Operations User', NULL, '0')ON CONFLICT(ban_reason_uuid) DO NOTHING;

INSERT INTO lpr_owner.ban_reason(
	ban_reason_uuid, ban_description, created_by, updated_datetime, concurrency_version)
	VALUES ('166cdc1f-9dc7-4414-9dc2-a70355ccde13', 'Participating in any other kind of malpractice, fraud, deception or behaviour deemed by the Test Partners to adversely affect the delivery, validity or reputation of IELTS tests or results', 'Operations User', NULL, '0')ON CONFLICT(ban_reason_uuid) DO NOTHING;

INSERT INTO lpr_owner.ban_reason(
	ban_reason_uuid, ban_description, created_by, updated_datetime, concurrency_version)
	VALUES ('ffabe98d-6b8f-4b5d-b477-0b71b90ef7a7', 'Other', 'Operations User', NULL, '0')ON CONFLICT(ban_reason_uuid) DO NOTHING;
