UPDATE lpr_owner.incident_status_type 
SET visible_in_ui = false WHERE incident_status_type_uuid='8356a550-bbdc-461b-a5e7-49c5f1cd58c9'::uuid;

UPDATE lpr_owner.incident_status_type 
SET visible_in_ui = false WHERE incident_status_type_uuid='f9dc2a18-2f98-4579-92b2-1568d0858a6a'::uuid;

UPDATE lpr_owner.incident_status_type 
SET visible_in_ui = true  WHERE incident_status_type_uuid='6a91d649-18d7-48ae-9797-659b99cb1182'::uuid;

UPDATE lpr_owner.incident_status_type 
SET visible_in_ui = true  WHERE incident_status_type_uuid='36f8d68f-7f68-4755-9420-cec4168179b0'::uuid;

UPDATE lpr_owner.incident_status_type 
SET visible_in_ui = true  WHERE incident_status_type_uuid='89347a43-2cf9-47a7-b22a-a0ff0514c51a'::uuid;

UPDATE lpr_owner.incident_status_type 
SET visible_in_ui = true  WHERE incident_status_type_uuid='936b7d75-39a2-4a23-b936-402f91cc4f40'::uuid;

UPDATE lpr_owner.incident_status_type 
SET visible_in_ui = true  WHERE incident_status_type_uuid='b64a0e01-90f7-4545-9f9d-22ab6d88e873'::uuid;
