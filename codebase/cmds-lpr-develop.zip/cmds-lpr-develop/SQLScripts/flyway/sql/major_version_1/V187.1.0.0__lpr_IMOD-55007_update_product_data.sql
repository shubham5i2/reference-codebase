update lpr_owner.product set product_characteristics = '{"characteristics": ["IOC"],"RoAutoAccepted": ["TRUE"]}' where product_uuid = 'fdbacec5-e80a-4710-b3de-7d5f310b1466';

update lpr_owner.product set product_characteristics = '{"characteristics": ["IOC"],"RoAutoAccepted": ["TRUE"]}' where product_uuid = 'de58e8e0-39c6-4c54-b62e-40cacbc6c56d';