-- activation of SELT IOC OSR AC

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='de58e8e0-39c6-4c54-b62e-40cacbc6c56d';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='d8f6415d-c36f-4a2c-9c44-bbf0e4c65530';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='edd31fef-dd28-4c0a-a593-3cd3b1b74838';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='c3e46fcc-b54f-49ae-8675-e373db8e6dc2';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='7768ff79-1c44-4b7d-818f-a935afcb9d94';

-- activation of SELT IOC OSR GT

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='e73dbfad-a961-4c7e-9fba-e196a2703bb8';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='42c488cc-2230-4842-b2aa-fe103f006aa7';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='b6e7b55e-c21e-4002-8c0b-a9f66f8bce61';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='a6bf0168-7ed0-49b9-959b-d526ff1087fa';
