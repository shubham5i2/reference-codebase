update lpr_owner.check_outcome_type set eligible_for_integrity_check = true where
check_outcome_type_uuid IN ('005ef982-3749-4a59-98c9-5da13fed6017','51c94a9d-c563-4f4d-8544-f90e59592463',
'760ecebb-cad3-449c-927a-507033989b91','c6eebce9-d53e-430b-ad36-44ed9ce2872a','98760142-bace-4bb0-b2a9-d90b9b393553');