INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('af369a52-6b25-4249-a3f4-15768a0f5ac8', '211d70ab-8739-46dd-b846-f2d8c174c2d0', 'AF-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('ab629772-7d70-4b3c-b02f-0859d59cccb4', '49aeddf8-bb4e-45c0-8720-728c093280e3', 'AL-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('dfb7aaef-9e7e-4fd5-bfba-0158525b9b0b', 'ec4837e4-4430-423b-abfd-fe811c7dc40f', 'DZ-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('c3e05a86-d23e-4b36-afcb-f4759ba82764', '4fa2adbd-771f-41e4-aedd-0c89d2ee1966', 'AS-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('ba723d36-02df-428e-bb1e-a71b12bafe14', 'becc53c3-953e-4242-8fea-e6608de8e4f4', 'AD-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('375c9112-5823-470a-b442-29f63e1110dc', '2a75c834-778c-4ea5-85ca-1bdd9fa0ecb7', 'AO-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('1d513168-8726-43b4-801a-196433056c00', '72dd959b-6b96-4821-ac32-114cf7853468', 'AI-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('fb9c437a-9f3b-4957-abba-faf3faf19eb7', '19e2e144-a1c9-402b-9661-c4fb2374a9a6', 'AQ-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('987fad9a-a800-47f7-8eb2-4747ec2ec7b2', '415b5e6b-a31b-4187-8b9b-783c483c40ba', 'AG-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('b5368e3d-7e2e-4ba4-89ad-d5cffc3abd8c', 'e5a29b3f-d276-40cb-82d4-edb6df9ecf60', 'AR-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('bc2e923b-3351-4f39-acc6-fb746f7c6ff8', 'ffb87177-ff8e-48f1-a843-4beea49a148f', 'AM-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('cbc25687-c991-4b89-9253-0ac6d57e4c6d', '0a44303f-6c27-4d66-93f0-775a8ac586f1', 'AW-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('5139add4-604a-40f7-ad43-2ec80b9ed536', '74a4f195-60e0-419e-9b04-c1a0c1b8febe', 'AU-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('64e34cf7-3b7c-4378-b6a8-2055a8b4535c', 'f744f5a3-37d3-4637-b797-4ffb7bcd04ba', 'AT-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('ecf1e003-8d46-4a4e-8ac8-5bbee8da8a9b', 'a58e615a-45c1-42e3-8565-4a024c4ef38d', 'AZ-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('57af8eab-40eb-4f35-a685-68dfce9d09da', 'd3cf6759-069b-459d-b0c7-f8f6e0f84b95', 'BH-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('ba3b0e7b-baf5-4a18-9f9f-f716f65ab248', '69553347-9953-4ea0-a09d-7e5cd9a51b03', 'BD-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('d865970c-6a8f-4940-a0da-befb49d69ddd', 'ea809bf6-d3d4-4a93-ab8d-3468faf95d64', 'BB-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('a78fc844-41af-4522-8370-fa1eb1e434f7', '9505d299-8958-4489-aad6-2aca702d8e2a', 'BY-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('cca563bc-8e52-42c5-b4f4-c6f76a8526ec', '8fb17ebc-b118-4249-b3e6-e0b423210a0c', 'BE-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('1607e702-6499-4a0b-b0fc-b5e7e6a99a3b', 'debce9ff-dad6-43d2-84eb-0015b3f3f999', 'BZ-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('a9590c7a-03ab-48dd-a641-d21b2230dd7e', 'adff8703-2dab-442c-9259-baa81df6abf6', 'BJ-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('bb51d549-4a91-4e20-af66-ff14616b7537', '69dfcbbf-1fac-496c-972a-b20919b39d51', 'BM-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('a8564bc9-52d7-4833-bf20-7b9c64eb05e6', 'a8a36663-c8e3-428a-aece-633b97877ec9', 'AX-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('cb8edcb4-f90c-442f-87c1-3c6e4dc32555', '9166bfb5-e9e6-4e05-b658-c2150e963b12', 'BT-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('b6ff70c2-afd5-42a3-a8d4-44e14b3eb085', '7bc450cf-1260-428d-b500-af11b73938e1', 'BO-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('954e44d5-2d3f-48b9-8b28-73020fec311b', '79e71395-5ce1-434b-a073-8145ac502ce2', 'BQ-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('453ca3b7-8dc6-4e45-b88e-0d705ba6cc3b', '5c180bd5-4cc1-41a6-980e-e02dc572b0f5', 'BA-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('676bfdd8-e3c8-43cc-a5cd-623a66f5c372', '505777ae-1b0f-4a16-9e87-a8771357a1ae', 'BW-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('7ffb16a0-bc63-4695-948b-1914eb330b6c', 'e0d4e03b-6c96-48ce-8e49-976db5c8a21f', 'BV-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('e46046f0-9d79-44c9-a7ba-fcd579a486dc', '3813d4c0-4eeb-4131-a0ee-5785141087e5', 'BR-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('9a8b30c8-7f62-4c65-8e44-65215985dd12', 'a4f3b613-51cf-41d4-a1c5-0606f5906ec7', 'IO-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('0f631233-7673-4193-9965-8dedd09c4cb9', 'a8d157b7-aac0-4f03-beb4-3619343cb6ac', 'BN-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('920ec710-e01b-42c6-be1a-470ad93a7287', 'c0675c06-d5b3-478c-9995-b5737a68e816', 'BG-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('0078b537-f87a-4291-b092-6e1ef9bcb03c', '378bd7d1-8f01-492c-b4ad-91c8e3574285', 'BF-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('e405ba6a-acc5-4d6f-8192-22a4c8272d47', '7e74157b-d8d4-4e99-af88-c42a143de8c1', 'BI-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('47538d78-6689-4966-ae84-e277b9bd4fbf', 'ea114a6f-c054-4dda-8128-99b02da02390', 'CV-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('c1de5f92-b81d-4680-973e-0657e161d60f', '4c094c23-510c-4f3d-9aa4-c3c393064ae4', 'KH-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('d153f310-0323-44ba-8970-05a8bce9d401', 'a1983af2-9ceb-49e9-919e-f7dd546a1888', 'CM-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('5d992c27-03d2-4b66-ae99-7bff385147a8', '8bb206ec-cdc2-4179-80ba-a9f1a53aee49', 'CA-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('6ef22a00-e64f-4781-b13a-0974432e6f57', 'df2e849b-4d09-4fd4-a792-00f1a1cf5f3b', 'KY-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('b3a6b8da-ea0c-4028-826c-1ba403a42953', '0ecacbec-f061-4f2b-ad46-f6451e32220d', 'CF-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('2a1d4b1f-9edb-4977-ae26-c3595fb031c4', '8dd39292-2f5c-4748-80e2-f13590f54fbb', 'TD-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('0784dace-9714-49bc-abef-269e15bf6429', 'e5b3ce5f-aa1c-4d88-9709-3645313be5d2', 'CL-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('4512c74d-a635-485e-bd7b-0cb31ad0bf5b', 'fa328170-6289-4a3d-bac1-2c1c87081719', 'CN-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('7d46d65a-41b1-4e8c-b3fe-919b575148c9', '4eaef528-c7fb-45ce-bc46-568700e6e92e', 'CX-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('46ffd501-b6f8-4aff-a90a-cb7e61cfb937', 'be61814c-0c3d-4ea6-8ce7-329b99947f77', 'CC-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('4c358371-1e87-47ba-bffe-fcc89f703bd4', 'eff601b6-01dd-4ba8-8de3-1e98e63ea7c5', 'CO-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('8b528f76-116b-480a-88cc-4694a56260be', '225b8ebb-1976-4082-964d-805c3825f59b', 'KM-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('dee9be16-eeea-4e56-854a-35525b6152fa', '5f1cecee-6027-4bee-94c7-e66473ad9523', 'CD-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('b81ca556-5dcd-4b53-93d1-f89fe20b4c2d', '7498e44c-475e-4d44-a15b-c4bb36b5f160', 'CG-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('ea9172c1-88fd-41f3-a733-59de637c9ae5', '90550ef5-27a2-467c-8e19-08690a76990a', 'CK-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('179dac34-bd3a-484b-93dc-dc9ed59737e5', 'b44c89e1-0d5e-489d-a7b8-59c6b49434ba', 'CR-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('6122e05b-b25a-47cf-a661-83da09880ef1', 'f6585010-900c-448b-9b51-eda77f1d2626', 'HR-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('5afe6e15-4af9-491c-8f5e-2fa6781dc172', 'fd9717c3-708a-40c4-9755-c9c41052349e', 'CU-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('fcefd74c-eac9-44d1-912a-4918559dbffa', '142c59aa-ec6c-4f1c-8099-db5dc43a16f2', 'CW-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('da20d9cd-cdd5-4e6c-96a3-7548e064cd08', '553cd677-3c9d-472d-becd-740621449a2f', 'CY-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('8d3b4dda-86fd-4b7c-818b-d63ab91ad57c', 'ee1115c4-a067-4bf2-b2f2-9a9b5ecfbcdf', 'CZ-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('de30f119-e2f9-4d41-895f-90044543512d', '72fc97b6-dabf-43a7-9af7-6e945d980801', 'CI-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('e7031820-2dd3-4a6e-bf9e-cf8abf9dfb74', 'dc90f18c-5235-4d28-89a2-195530882f0c', 'DK-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('44e4b4a5-d703-42bb-b978-8e930cd5ac00', '321546b6-cbaf-49d6-9da6-c5a80101aadf', 'DJ-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('024373e8-9bd8-49b4-b872-eb97bbb77bc2', 'f8aa68a7-3d77-4df5-9285-996273516d4a', 'DM-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('98ba1425-6a6e-41ce-aa5f-6f6965808578', 'd6947ee9-7cad-44a1-8d6c-44571596a086', 'DO-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('19419f42-4370-4b02-807f-942b91909e38', '8314847f-9e8e-43ec-a16c-590b64da6307', 'EC-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('8a3f05be-a62b-40c2-9090-051811010826', '28e14ff5-3368-45b5-bd86-504533db5121', 'EG-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('3d3dd99a-cc8f-4700-a938-a64f71bd3ca9', 'cf6a4544-3fa0-48d0-8958-1ea33508e802', 'SV-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('c013a33d-83f2-404d-ab0b-936df104a0ca', '82e063ee-585f-4ffe-b44d-2b22ccce1c5a', 'GQ-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('18324ab9-8181-4889-997d-09f67006df69', 'e44fa6ae-8891-4f90-88f5-03677d922913', 'ER-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('511207cb-115e-45a3-bbed-5e844a97d177', 'eac22140-5138-4607-954f-175249fe1380', 'EE-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('cd3249c4-fecd-43ba-9382-cdb1fc8ea777', 'c25d29f7-507e-45af-83d6-624058a29a55', 'SZ-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('dcd560f8-1fa0-422d-974d-d90c12b07e5d', '1bd65587-6174-4af3-a14d-535ac09fff16', 'ET-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('5e5ce0a8-eee4-48df-b855-b4bd26d58535', '6ee147f1-b7dd-485b-932c-6a6e516463ce', 'FK-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('4926dcdf-b1c7-4b22-80f6-8c182b0633c7', 'd5fc03b2-9475-44fe-b876-51b9a1c9717e', 'FO-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('2644e917-f1f5-4de9-b252-f375012f5244', '0fea3958-6d01-4c17-bcc6-acbab6dd941e', 'FJ-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('70ec172d-2503-4297-894e-5c52913df639', '9c0c0dbd-8baf-455d-bda6-8ebf13797675', 'FI-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('508d92eb-842b-4823-a0c8-3cf638512888', 'edc58430-6013-41b6-a91a-ddd2ec59bc5f', 'FR-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('24071f65-1603-461d-877b-85893d37fd35', 'ee6ecd95-ea0a-4ef3-a7d4-1f3e25a4b7d7', 'GF-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('27da5845-265d-4336-bd41-7bdb89323bb1', '08528e84-6e15-4c67-b0b9-0c7c77bc1b2d', 'PF-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('847b75d6-44c0-4320-b97e-b7af5cbfa1a7', '69295f1c-8d02-414d-bebe-dea94eadb505', 'TF-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('f4ee5618-aa7d-4ddf-a30c-17d38b2c569d', '1d59063d-e525-4dde-8ea9-9a09f62c51b9', 'GA-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('a6794153-9019-4678-99f1-634d7bf6dd8e', '6dcce438-2d9e-478b-9d6b-cac8cb9a7bc8', 'GM-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('8a442ded-ed82-4c96-a292-e25771529aa0', 'ef6cd030-ca84-46ba-bd22-eb0671335acc', 'GE-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('8f1432c5-7a8e-436a-ad49-395cc88d6e5c', '902e9304-ebb0-4d28-82bd-b8caf90db915', 'DE-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('adf28d26-0023-4547-a593-2e7d28a1f13a', '08283301-6826-466c-bebd-4b882181473b', 'GH-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('6a593f63-b1b9-4de5-9ae4-166161ac99f9', '9e3d3e08-d09c-457c-b99f-6dc9d59fac4a', 'GI-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('9f33720e-d9e5-43ec-bc2c-6db5a015a74b', '61e90cbe-8fec-4103-afb2-3136c40cfaf2', 'GR-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('14cdaf84-b9cc-4566-bf8a-21352beeacef', '9cf0caf4-8427-48ba-bd9e-d75c65ce6a86', 'GL-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('17e56254-93ab-45fd-9df3-398f144b88c4', '22e1d34a-f9c2-4e65-90f0-ff249465e06f', 'GD-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('5f6c76c1-0a15-4d03-b315-80ecee33f1e1', '43c25feb-6afe-4ffe-9515-42551e487730', 'GP-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('5e2568c8-d03e-4264-97a0-338699155aa8', 'a57932b6-9390-426a-8b13-1f19f5661875', 'GU-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('c956b7f8-49d6-433a-8c10-728f53607941', 'bbc2fd7b-9239-4ca8-9da5-e1357b261b04', 'GT-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('f484f049-2df4-470f-a43f-4940c0aeec28', '5cc1267f-5d3a-4eed-b9a3-b9c96a2257f1', 'GG-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('56f52f86-b24c-42ca-983e-e5f2d4d7c617', '19f80662-0476-43c7-847f-e77a739352e2', 'GN-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('d06236e3-1f48-482b-a588-6057c0643127', '3f46e167-f6fd-4556-8bce-164c25632793', 'GW-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('e5340e18-357d-4a46-ab4e-3a9facbdfa22', '070635e4-612f-4bc4-bc2c-fb86c7b41a23', 'GY-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('6721675f-a37b-4e18-ab26-ed00aba360b4', '08f1a260-a676-4d42-9574-2434e3f53357', 'HT-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('c12edab9-b2da-4b5a-a38a-37dda3fdb4d7', '20659e45-6ee9-452a-b49f-909a5349e253', 'HM-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('4e8fb2cc-cccf-485c-a1a1-4f9fc5351c35', '68f0b8ef-bd61-4964-a517-dd749a8c13d8', 'VA-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('eec9346c-eb81-450a-8bcc-57c892bebcb7', '984f2e27-8124-4055-9d8c-509c8fadb5fb', 'BS-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('fc65598a-cb31-440a-ad67-ccfb3aa23321', '1e4c026e-c6d0-49a1-8979-966553554aba', 'HN-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('1d0d74c7-b30a-4c6b-a29a-5f17d99f3132', '932e9d84-44a9-4e67-b3b8-55a4ad4013c7', 'HK-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('2d479197-d216-414d-a12c-0ba0519085a9', '31b8b478-8772-4c09-96d2-15406a780195', 'HU-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('6c362ff6-aa5a-4a23-80a9-c43d9c87ce5c', '31c98c4b-b2e5-4670-b6ee-80153dc8a5df', 'IS-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('729d8920-bc0e-4eda-8d7f-343116fabec6', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'IN-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('9c2499c2-2c1b-47f6-8acd-97ee47c78d74', '2998dc96-e507-4c95-b067-51d19bee8319', 'ID-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('d4b8228b-4931-412d-b2ae-ac119bf0065e', '0166e4b4-42cd-41ca-9685-187d357ed8bc', 'IR-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('e0b81905-ed2d-4ed9-83ab-c8328c49abef', '4a0834d0-3d1f-4ac1-89a4-aab7b1ef78b8', 'IQ-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('92df02ad-d433-406a-8062-00222672184b', 'a74b9941-3971-4075-9902-6f5fdcdfec4b', 'IE-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('84addd58-5c20-41fa-9bb4-61916379f53c', '1acac64e-25a4-4aa1-875b-99bed3af24ff', 'IM-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('2f4a2914-c842-4b65-a26e-52f05efc5b88', 'ce4889d8-ae35-467c-ae2e-5a59846932ac', 'IL-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('b51fad17-09ba-4101-81d4-841becb22009', '0000108a-d774-4e0b-b3da-415b07bd77a1', 'IT-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('5572985f-857e-4d1a-8691-8f0f65c1e0ed', '51d1438d-0720-48a2-b326-3f2e159b34c4', 'JM-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('8f2f045f-4667-442f-8c68-de64d6a9422e', '0b9bfed2-ae52-435c-9719-15854637cd18', 'JP-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('437810d9-7990-4766-8c15-1535baa90774', '3fe52c8b-613e-43bb-825a-c8526d203b22', 'JE-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('bbb51724-d150-4900-be2e-a8d5332464fa', '209e325f-52ec-4769-a3f7-eab17a803695', 'JO-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('f7a876a0-d6ba-4943-aff8-3884327322c6', '02d45f67-cdf7-4b66-b782-e31255ff08a8', 'KZ-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('3473637d-3689-4026-a038-40c32f4edbdd', 'dd83f749-5dc3-462f-827c-e9a109b3f91d', 'KE-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('9f606efc-44ac-43de-a66a-b8bbc32ef1b3', 'f4b6dca3-0592-46e9-b83c-89b9269894f7', 'KI-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('8de91fb8-88e1-45c6-b41e-6c5d75953257', 'f54b49e5-cad6-49cc-9d62-175fdafaaeca', 'KP-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('1b9ced8a-9bfd-46d1-a730-b3c6142ee665', 'c947082b-0d2f-4a85-9c64-592ad0a4dfa4', 'KR-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('68f82945-478a-4c37-969d-553ab69321a1', '2ff75e65-d39b-428e-bc40-12e0955b1dd7', 'KW-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('11a8834c-08f7-458f-8e4c-3f0effa0c0d0', '54a2a395-fb6f-41a2-9be4-0b0e0914e52a', 'KG-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('8197e264-6d6e-46e6-8c30-79e0850c158c', 'ff9b2078-3f68-4350-92ea-853f5a476eff', 'LA-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('c5794721-de4b-4303-8c5b-2d82dd60efb4', 'bb915e83-9f70-474b-adb7-c992334330a0', 'LV-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('9adfa2b9-a305-4651-ad13-08a56554b801', '4c669be3-0768-4536-ad21-7ba41083d210', 'LB-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('7dd89ca9-8ed9-46a5-8a4c-30570d02079b', 'f9abc255-1e49-4199-8b0b-3293070deb1c', 'LS-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('f7a12f81-b01b-43a6-a3cb-bd4510cc9ef2', '17324c02-a920-4d8b-a59d-bff2398e1fcf', 'LR-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('7a29aad0-2ea5-4d24-8559-700a4c61574d', '462cf2e1-f1d6-497b-ab1a-a51d09ac6bb8', 'LY-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('72749451-d5aa-44b7-be58-8399226c651a', '4007175e-c39d-421f-854d-2ab92affe48d', 'LI-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('64d87e0d-a938-4c32-89ce-596445e94e47', '4d247639-930b-4bd7-a071-9127e7041ee0', 'LT-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('35847424-fdd4-4ff4-a45c-f931ab296699', '619b8b6f-7032-47e6-8dc9-5ca3ab4b1c0b', 'LU-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('bd61f138-2df0-464d-a562-e1f4ab1d049b', 'fb243970-ddf2-49cc-a593-503f2fdaa0bc', 'MO-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('f024150d-2fae-4b66-a843-3e366a4cb302', '6586050e-c99a-4540-881b-868d38167aef', 'MG-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('f79abf23-2b5e-4ecb-9186-a9c618244c88', '19fa7f93-7f25-41a4-bd1a-76fe927c9ef3', 'MW-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('3bb8f3d8-fb45-4e09-81dc-1439b28649a0', '53df568c-3d08-4bbe-9ca1-dce0c14dfe88', 'MY-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('c517b267-a8e5-4e6c-9ca6-6f46695374dc', 'a61f50af-37e3-4e81-806d-29859d6eddb2', 'MV-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('dbd00412-18b5-4bf1-84ed-7418e567b440', 'a940f5c5-0ecc-4345-8844-71a44cd8fadb', 'ML-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('73b9469b-d992-461f-b52d-bc8c4fa4f5e4', '819c9279-53e0-4e28-b766-a4c8fad793ec', 'MT-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('c34012ee-bba7-4138-bb00-17ecfa154c43', '12dc453d-6f2e-4227-a5ca-2f84e0b23e48', 'MQ-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('bee54e56-36b0-4b1e-a9cd-638d926f4ce0', 'ebc0f617-a473-459d-85df-c6abc774b3fe', 'MR-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('5806a041-bb66-41e4-8cbd-c4c01965a2f9', 'bade52bb-ab24-4561-bbf9-251a0b0769c9', 'MU-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('91b02ad1-e216-4a65-a6d2-00f061bf5b86', 'f6cdd01b-efcb-48be-ae3c-ca07a0dcd2e1', 'YT-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('6169cdc1-9aa8-4bd2-84b0-1bb612894072', 'b5a9774c-5473-4d05-b995-883b4a97406b', 'MX-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('0293ce3f-9913-4d18-b6fc-01f7fc62b469', 'd21069e1-1c00-4fe6-845c-8684cb7a4dcb', 'FM-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('eff58cf0-409f-4988-b2eb-1fc8790b31fe', 'e16929eb-b6a8-4792-b650-fba2139d000c', 'MD-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('c4dc4e98-eb7c-4770-a170-9738f6934624', '87d74e28-347e-470e-8bc9-0c2fb87328e9', 'MC-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('eb12873c-26a1-4bfb-9e3c-8a043bd4af63', '0e57c829-cdbd-4447-aaf5-dae29a53668a', 'MN-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('3907c583-2afe-4de1-9314-60928ea97bfb', '40bb735d-b165-400f-b378-ff40d085ccfe', 'ME-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('f2db96f8-65bb-40ed-abde-d9f9041ba9a1', '9a28a10b-35b7-4e4e-9274-591f178d898f', 'MS-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('9de59337-4b4b-4d5d-9d85-1128029d73a5', '9a8a63bc-2d9f-4289-b31c-b093204bb834', 'MA-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('dc200025-c43f-4764-9fd7-b0d0fd4243ce', '6924d070-742c-46a7-a111-e8e540ec76e4', 'MZ-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('f9d38f74-461a-4612-a42b-afa3c31ab05a', 'aa0a4ebb-4574-45be-8287-d4dd74160c51', 'MM-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('69d69785-f59c-4935-850c-fd1c6ed679e8', '0a092b0a-6d18-4e42-97b7-1d3600045562', 'NA-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('0a72b5dd-bec5-4b21-a76c-7eb8f5414c59', '05cc78fe-4d87-4678-9544-f2a534264195', 'NR-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('41fcaea4-8c49-4dc2-927a-e70c71b28561', '7bb7f4b4-54be-4a61-addf-2eb06d833e8c', 'NP-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('445816c2-cc94-4406-b98f-fa8d7d374a7b', '89ca7ab5-ac3a-44bd-8035-6bf72d3d3a4b', 'NL-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('3bcd0d4f-1cdf-4121-b6ae-1350d57fd171', 'cd542abb-1dc4-4cd5-a578-cde159d3520d', 'NC-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('bbb4072f-a6a4-42fd-9135-05c7d7f1a790', '0db40418-3cb3-4aae-afcc-329c3ca677a3', 'NZ-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('a7bdbe6f-06ab-4c68-8c3e-3bc15ccf706d', '849de61a-f808-4e04-913a-b7ca5d4c44e8', 'MH-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('754d52ef-2ca2-49bf-b994-999dd7019aa4', '9a04b342-417d-4c56-af08-57e0f35ddf29', 'NI-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('6d39765a-b4db-4fec-837d-13c7b4cbb532', 'a1d47606-5f2b-42e9-aea1-c8081971cc7d', 'NE-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('47d09eb2-4ae1-4cdc-a959-780b4eabe67c', '3c986cd3-b55d-4e1f-b0c5-9955dd7dd2c1', 'NG-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('12766114-949a-430e-87b6-fda5732bb622', '2096270f-f469-4ddc-b008-4638ea925ac1', 'NU-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('f54ac55e-b22b-4d9f-8820-e6373237fb58', 'f9812ccf-537e-4e39-8bbd-49660443435e', 'NF-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('43f04428-b34e-4397-8f87-10a1e46f5edd', '255aeef7-dc4c-4179-9351-8f047c1f764a', 'MK-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('155ddcf8-142b-44d6-94e7-7c28ab5b628b', 'b2288fc2-a146-4d9d-a8b6-58a4e17ec278', 'MP-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('11e25472-25bf-40c4-9c1a-f5110a08fca0', '06b9fa4e-ba5d-4fc3-9002-72a58868e4d7', 'NO-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('6b8f510f-33e4-4db4-8f01-33c8d245824e', '960f14d2-b656-4aee-90ac-66e2a1895974', 'OM-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('3d45826b-f8f4-4c4d-9499-c324510f81ca', '5946b53b-73c9-4767-82b2-1c8449a1b09f', 'PK-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('77969884-7636-4c65-b9aa-9eb232641ad9', '6c61d94b-5112-40c6-b4f8-ab885a3e1891', 'PW-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('42a44407-12e0-479d-a3f6-6ec10ccc2b07', '7ea874fb-d7fb-4086-a8db-538d9c39ddb0', 'PS-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('8c59ab15-c1f4-4b30-b720-cad8cb4b0d0e', 'fae16a5d-07b2-47cb-ae8b-43c74b31bab4', 'PA-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('825cb2c3-e790-4a7c-8c5f-8eabe16228ec', 'f847712d-6ae4-49b3-be3c-d51fccaeae72', 'PG-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('86e365fb-1707-4571-873a-aa632cd3c60e', '1cfc81fd-975a-4524-ae8d-9308196bd3c2', 'PY-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('9e88d18e-14e9-424b-8fb1-e60f742423e0', 'b0e8700a-52d5-4940-bc76-443e6bcdd6fa', 'PE-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('0d6cd5c7-a282-4e16-bcce-63f94c35e071', '7e682041-3309-410e-a152-04dd5ffcaaf7', 'PH-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('a55d33dd-3e4e-4f1c-ab70-dd26146ad363', 'fcb27c5d-3396-4016-ae4b-68a191ab2f5e', 'PN-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('2179103b-5b88-4931-a120-88f5ef7e2bfd', '9c3330f2-b32c-4a6c-9bd7-31320e9d75ad', 'PL-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('7b532882-e33e-4825-b595-0ceac6ff1462', 'e1dae6d8-f66a-44e8-a87b-c70ab492dcc6', 'PT-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('d740de67-e7db-46be-b75a-2a989116f7b1', '1a1516d0-a435-45d3-9ef0-2d2dff867f7f', 'PR-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('44cc6dfa-fe73-443b-aa3f-f9941054c179', 'a05ad2f5-186b-4a8d-92e3-13c5769549ce', 'QA-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('6f335d8f-16cf-46ac-b343-22ed01dcfe91', '6420d400-4917-4e08-abd2-48589930aa24', 'RO-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('ec931876-0650-47de-a43e-8bd131e248fe', '018a95fe-fb24-43f9-a972-2cadce41e822', 'RU-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('bc771474-ce19-4b6c-9dd4-65cfb74aa229', '2b75b482-128e-4c7c-9e9e-a9d0ff639f9a', 'RW-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('5de6c463-da62-460f-8895-3b35f3c4a2f0', 'b984e7a2-8ef9-4d4f-b985-a849ca6fa0c6', 'RE-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('a222fde9-69bb-4582-9bcc-d49fc687c0ce', '3cc511a8-f946-46b0-b1b1-ed0b9857d55f', 'BL-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('0bbc1977-6384-4d9b-b7b4-ad09dae722ec', '79ded6ec-b30d-4786-a27d-a55bed9492c1', 'SH-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('a0fbccd2-501a-4e3e-92f8-c825efcc9ab2', '7d36c834-4da2-4e73-8b08-8f09d5d18d37', 'KN-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('cd432f9a-2612-4ae9-9829-0b5c3ad5fe47', '011d57a1-50fe-4bfc-8947-df1ca0b44b1e', 'LC-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('0d33568f-81d7-42d8-bb34-fd13991213b7', '19be48f2-10fc-4124-b438-d18e97113c90', 'MF-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('d9de7723-6045-4c28-aa98-3c9e76d6237e', '5dd7f90a-88cf-403b-af5c-5a29b5fa272b', 'PM-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('7936667e-f78b-454f-869a-4f11a2161201', '6945081a-27a7-4ee4-8592-a49c1c1bcd60', 'VC-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('d1d3e2c1-1fa5-4a7b-a0ae-7fbd912cc8d7', 'f0fcfc0d-4017-4aea-a2a1-a98b4bc30a81', 'WS-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('946f7856-5047-4243-b900-3e946df1884a', 'cccdcd10-7e59-414c-b779-a779ebd102dc', 'SM-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('059752f4-d116-49e2-80c9-3d8bffec0786', 'fdfad402-0f6e-4133-b46a-c1c1fba8bc03', 'ST-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('871f4c5a-9096-40c8-9688-9d8fe95129b1', '7d9ffad1-a1b5-49d1-98cc-0f1b1ed5fcb4', 'SA-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('d568a418-6b90-49e4-9cbb-7694391e55f6', 'aca23ec9-90b0-47ef-baca-52635d6a4f42', 'SN-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('a9e3efda-5af9-4d12-86e6-96641318561b', '96955224-8f44-44c4-a9a2-68b0a7a58ac5', 'RS-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('43a47145-df88-4930-b9a8-15236cee6a19', '06c6da42-b9b6-4e1a-a767-ceaef5f7e091', 'SC-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('62783fc6-6b96-4e45-a54f-c8931b8b4b70', 'c85d453a-213e-46ad-b9a0-3d9b7dba026b', 'SL-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('a202a0fc-fe53-4b44-af93-bdd7db53ab8b', '418d69e3-6ace-4008-932c-6ef710d58faf', 'SG-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('5190248d-25fc-45eb-9642-8eb7a5ff253a', '338fccce-9376-487f-bd52-5d70d757e8cf', 'SX-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('e28ae9f6-8d2b-4191-95b3-a5a39fa8248a', 'c5107dd8-745d-4421-8835-97d1fd57aef1', 'SK-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('c988bbef-8620-4014-8062-af86ff2b070b', 'b15ffa6f-d2b0-41b3-86ee-8f470c051080', 'SI-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('64a43329-f51e-4d92-9990-9a2f6b244d6f', '06e815dd-eea6-4092-bbfd-405479d7c618', 'SB-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('49a92b27-697c-42d3-a2b7-eb93e7c3ecee', 'dc8a8054-fdc8-4bd8-a80a-8a28af1a4b44', 'SO-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('d398aff4-e83b-40ce-9dca-bc3c08c9fc4b', '3a3aa277-8a59-4061-a6ed-e9a9dacc4808', 'ZA-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('7476001b-b9a1-458e-b670-9a9215cfc74d', '6770a5a2-38ab-4928-9475-ff75489fd0a9', 'GS-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('a2e7f812-19b6-438c-9738-d7edfff6faa1', 'ed70286b-6802-4a95-a0f7-9f1deb00037a', 'SS-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('2009358f-3f86-4e4d-9ca9-9365594b403f', '85ad033e-360b-44eb-a117-2af7fe0bfc01', 'ES-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('3683a701-70e3-417c-b206-a36a30370a77', '059d9adb-3e83-4f1d-825c-03c301557a7a', 'LK-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('ba5a23da-4d7d-4390-998d-0d442c7f0d22', '793034d7-1bac-4c2e-90a3-3373b43a77c8', 'SD-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('ae067cef-34fc-45fc-a8c0-4832a5e2596c', '9be3af1f-25f3-4f73-88f1-c4237cfdbed9', 'SR-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('a6b6dadd-5a3a-42e1-97b7-125ac930e271', '3fcaa812-426b-4cc2-938d-af17831bfbbc', 'SJ-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('6c5c9552-c273-4b7a-aeb6-4ffe339d5e0a', 'd5c91f11-29c6-447d-8afa-a006202fdd5f', 'SE-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('c079fe92-bebb-4fff-bfc7-e01c7696d270', '7f9b0db1-3414-4a9c-b050-fb810e48e679', 'CH-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('9897d7ba-e100-4a8c-97aa-4a3120c68cd8', '876ddbb6-5019-4043-886d-f928d6b830cb', 'SY-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('33d14a0a-0deb-4937-9826-1df9073ded58', '41e21aff-5441-4bc0-94c6-825adab59e2c', 'TW-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('fddc23cd-b4f4-4753-bc58-aec61d31d529', '30a01674-a19b-4fdb-b1d2-21149451cca2', 'TJ-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('58a3e0c9-c12f-4601-b787-9fa99011c5a7', 'c3e037af-f62c-4039-8cb5-841d48a2b442', 'TZ-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('4cd4c14b-ef57-47ee-9fa9-1ff1175e29c2', '638845dd-d24c-4a80-ab4b-1d0fc2115f55', 'TH-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('63e2545a-f4d4-4f27-88f7-cd08a55f2926', '0c170c66-44da-47d2-97e0-00706156c70b', 'TL-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('d351fd75-7292-4a1a-ae7f-303b5c9ee45e', '11232776-7c0d-46f2-814b-86caadba61cc', 'TG-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('80068c85-ae0c-4adc-b3e1-2ac30a291264', '8f05c3df-381c-4457-b82a-066e36a5334d', 'TK-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('e5dc78e9-6ff6-4eba-bc66-f0b628004d44', 'bc56de3c-4281-4cd8-a61c-20dc284d3485', 'TO-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('44b9797c-5cda-4372-a51b-511ba018bcde', '790bbd64-613e-4205-bbf6-0731d48e9869', 'TT-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('363c2718-ffd5-4369-a4ad-c2d864d44863', '5e6d4c18-8478-4ad0-80d3-75c6933026e8', 'TN-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('61409313-a02d-43a4-bbad-10be0257a784', 'c94d0596-9ab1-4da9-8b8f-e01c231f0c62', 'TM-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('5be3c65f-2806-430f-ae5c-f163f964c871', '485e9cc3-7f13-45ad-9984-9b077c17fcc3', 'TC-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('d3df9e83-b51c-413c-b4dc-8473ea5f3abf', '7f97748b-c02d-4107-9c8a-d303e8414325', 'TV-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('903e4470-7d17-4482-8367-5310e4a7d351', 'ccc7bd66-d434-4e33-8a5d-c347f0a1fc0b', 'TR-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('89f7ce9f-b3d6-451b-aad0-0213db8539b4', '90024512-5230-44eb-839f-f1594d07b2d9', 'UG-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('7c2013cb-fa64-4aa6-9c1b-5fd9640dbb0b', '132c30d9-3a47-4986-8829-cb519464b4fa', 'UA-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('104710ed-c352-488e-a0fb-70d4a2f17333', '1777e131-b5ca-4f6c-90fd-802d1097b7f4', 'AE-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('f39e88f3-208b-44bd-bd89-75dff1e1f692', '029fd27d-b39a-48b4-87e7-131a063bea2d', 'GB-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('390e1396-8b48-499e-aed0-ee6b8c8819f1', 'c429af8b-f357-4ff5-b4a2-a7b7453cb664', 'UM-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('b4d7f2ca-b836-4b9c-8c32-b4a5f18e389a', '185f8b77-9e53-4a5c-8a79-51a8ad7961aa', 'US-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('0fa85650-7002-42f6-bbb1-0af8846cdd03', 'b620debf-3a44-4ae8-b356-0cadb261f309', 'UY-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('8cce3b90-7c1c-432e-97f6-57bd4ee4ba09', '66dacbfd-b488-470c-9c9d-e1193ade7790', 'UZ-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('fdea8c4d-4bd9-4419-9cdf-28ff239addcb', 'ce37fcda-c5de-437e-9dc1-e4fbaec86a7f', 'VU-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('4760fba1-56cb-4537-b022-3f5fec2b4049', '7ce7c29a-2e7f-41b9-a153-27819329d80e', 'VE-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('6dff1d8e-4524-4416-a94b-ee29637d5833', '5e9c2e3a-fc9b-4ecc-ab30-3bdbb7c2abe5', 'VN-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('c32fcdd7-ae1c-40db-88a1-9f811ee0f1d9', 'a99e3727-c0d3-4eac-935e-717a5a33f918', 'VG-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('8354fd08-ac24-4d5a-8ee7-48cd79faa653', 'c8b0e5a6-ba54-4d40-aa94-c019ce14c651', 'VI-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('44e39e17-3d3a-41e3-9eed-7d501b0fd8b0', '5d97640f-7767-44f8-8e1e-403e7346c38c', 'WF-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('6ba934ec-6874-4cbe-82e2-231a4f6f2002', 'de8d0c02-3a73-4da6-b79a-5cc756c90bc3', 'EH-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('0fa4e8cd-bc83-4056-b68f-3381a200ebe2', '1ecb1c51-23d4-4bc8-990c-95fc17a15ca1', 'YE-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('6f44f491-3331-4695-b6c1-802705de1b19', '11c26d50-249e-48e2-8024-cee55ed51c35', 'ZM-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('267e5ee3-9162-43f6-ad07-9ee7ee40e7cc', '77d6a91f-1447-4dc5-be27-c3199e6df6fa', 'ZW-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;

INSERT INTO lpr_owner.territory (territory_uuid, country_uuid, territory_iso_code, territory_name, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime) VALUES 
('47909987-0867-4f95-98bf-1a46d40204e1', 'ef910575-3a48-4139-b944-2dd0da584e64', 'XK-999', 'Other', NULL, '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(territory_uuid) DO NOTHING;
