ALTER TABLE lpr_owner.location ALTER COLUMN eligible_for_offline_testing SET DEFAULT FALSE;

ALTER TABLE lpr_owner.location ALTER COLUMN website_url TYPE varchar(5000);