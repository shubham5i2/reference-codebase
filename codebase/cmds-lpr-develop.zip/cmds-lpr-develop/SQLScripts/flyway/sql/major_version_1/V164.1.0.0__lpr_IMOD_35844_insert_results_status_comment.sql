/**Insert command for results status comment**/

INSERT INTO lpr_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('bdee4c63-b9a2-4afe-a1ed-6dbcc6b3ed8c',
		'52a50291-bd70-4989-9fce-584b0aa3cc65',
		'Probable Banned Test Taker',
		'PROBABLE_BANNED_TEST_TAKER',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;
