-- Create user_group_hierarchy table

	CREATE TABLE IF NOT EXISTS lpr_owner.user_group_hierarchy(
	 user_group_uuid UUID ,
	 user_group_data jsonb NOT NULL,
	 concurrency_version INTEGER,
	 created_by VARCHAR(36) NOT NULL,
	 created_time timestamptz NOT NULL,
	 updated_by VARCHAR(36) NULL,
	 updated_time timestamptz NULL,
	 CONSTRAINT pk_user_group_hierarchy PRIMARY KEY (user_group_uuid));

	