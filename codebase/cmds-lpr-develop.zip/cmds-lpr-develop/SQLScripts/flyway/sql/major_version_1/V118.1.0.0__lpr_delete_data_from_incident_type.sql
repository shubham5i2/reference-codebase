DELETE FROM lpr_owner.incident_type
WHERE incident_type_uuid='e0122c50-d9ed-4950-978d-5dbc5246256e';
DELETE FROM lpr_owner.incident_type
WHERE incident_type_uuid='b807f404-b175-43ce-9168-3d2c36589800';
DELETE FROM lpr_owner.incident_type
WHERE incident_type_uuid='4776f091-01a7-4d4b-89bf-bcc45c79a522';
DELETE FROM lpr_owner.incident_type
WHERE incident_type_uuid='97540655-b27e-4fa5-85a1-9e0483dc9096';
DELETE FROM lpr_owner.incident_type
WHERE incident_type_uuid='a7e4feb3-86e6-4cc2-8dd4-c39f342f55d7';