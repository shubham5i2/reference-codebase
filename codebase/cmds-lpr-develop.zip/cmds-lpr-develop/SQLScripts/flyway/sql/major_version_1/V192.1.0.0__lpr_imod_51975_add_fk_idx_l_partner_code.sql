CREATE INDEX idx_l_partner_code ON lpr_owner.location(partner_code);
