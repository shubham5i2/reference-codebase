INSERT INTO lpr_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('c067503a-4653-4eae-9114-15bc1c2f160b',
		'50324a6c-4fb5-464d-a063-7a146ffb96bc',
		'Plagiarism detected',
		'PLAGIARISM_DETECTED',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

INSERT INTO lpr_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('212937d5-2fb4-4228-88ca-de78296537c4',
		'50324a6c-4fb5-464d-a063-7a146ffb96bc',
		'Plagiarism Check Failed',
		'PLAGIARISM_CHECK_FAILED',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

INSERT INTO lpr_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('523100f3-8de0-4070-9548-a65653175c89',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Accessing prohibited programs/applications',
		'ACCESSING_PROHIBITED_PROGRAMS',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

INSERT INTO lpr_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('d2b1e0e2-f191-4cbb-ab61-016f66608ce9',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Hiding face',
		'HIDING_FACE',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;
INSERT INTO lpr_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('0a44baa6-cc0d-40ef-9c3c-1aaed91a53c1',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Participating in any other kind of malpractice, fraud, deception or behaviour deemed by the Test Partners to adversely affect the delivery, validity or reputation of IELTS tests or results',
		'PARTICIPATING_IN_MALPRACTICE_TO_AFFECT_REPUTATION_OF_IELTS_RESULTS',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;
INSERT INTO lpr_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('dc938cf7-8b68-4bd5-93d2-e6c6f88b0df7',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Possessing a Bluetooth device or camera/recording device',
		'POSSESSING_A_BLUETOOTH_OR_RECORDING_DEVICE',
        '2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

INSERT INTO lpr_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('c839cbed-6a87-4a50-8a17-e6eba60d8c06',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Refusing to comply with reasonable requests to inspect personal items',
		'REFUSAL_TO_INSPECT_PERSONAL_ITEMS',
        '2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;
INSERT INTO lpr_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('e0d32b65-9d59-463e-8aa3-ac7789caa373',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Using unauthorised computer device, i.e. a second keyboard/ mouse/monitor',
		'USING_UNAUTHORISED_COMPUTER_DEVICE',
        '2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

INSERT INTO lpr_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('881ec503-e97e-4f98-b38c-2b856287cfa7',
		'5728a79a-5785-4bd2-858a-3202236eb4e8',
		'Falsification of test report form',
		'FALSIFICATION_OF_REPORT_FORM',
        '2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

INSERT INTO lpr_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('501db80f-2a59-4e81-aac2-d1c0a253d81f',
		'5728a79a-5785-4bd2-858a-3202236eb4e8',
		'Disclosing test content after the test is administered',
		'DISCLOSING_TEST_CONTENT_AFTER_TEST_ADMINISTERED',
        '2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

INSERT INTO lpr_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('47017e27-0252-4760-900d-08f2c3257a65',
		'5728a79a-5785-4bd2-858a-3202236eb4e8',
		'Attempting to gain an IELTS result through financial fraud',
		'ATTEMPT_TO_GAIN_RESULT_THROUGH_FINANCIAL_FRAUD',
        '2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

INSERT INTO lpr_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('8adfb1d2-36ba-4e4f-a8ff-ffa410fec964',
		'5728a79a-5785-4bd2-858a-3202236eb4e8',
		'Obtaining fraudulent results through internal fraud at Test Centre',
		'OBTAIN_FRAUD_RESULTS_THROUGH_INTERNAL_FRAUD_AT_TC',
        '2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

INSERT INTO lpr_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('23abda44-3ab6-4799-be58-4fc58dfb6a11',
		'5728a79a-5785-4bd2-858a-3202236eb4e8',
		'Hiding face in multiple test sessions',
		'HIDING_FACE_IN_MULTIPLE_TEST_SESSIONS',
        '2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

INSERT INTO lpr_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('464b6859-b121-4c61-b43c-bf93b6625c56',
		'5728a79a-5785-4bd2-858a-3202236eb4e8',
		'Interfering with device (e.g. camera/audio) in multiple test sessions',
		'INTERFERING_WITH_DEVICE_CAMERA_AUDIO_MULTIPLE_TEST_SESSIONS',
        '2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

INSERT INTO lpr_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('338dfb10-c335-411d-9797-203c8e311133',
		'5728a79a-5785-4bd2-858a-3202236eb4e8',
		'Possessing a mobile phone/watch (or other electronic device not designed to make illicit communications) in the test room in multiple test sessions',
		'POSSESSING_ELECTRONIC_DEVICE_NOT_DESIGNED_FOR_ILLICIT_COMMS',
        '2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

INSERT INTO lpr_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('372a224c-cfec-4729-8d4e-9218dc355569',
		'5728a79a-5785-4bd2-858a-3202236eb4e8',
		'Taking ‘emergency’ toilet breaks during a component in three or more test sessions',
		'TAKING_EMERGENCY_TOILET_BREAKS_MORE_THAN_THRESHOLD',
        '2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

INSERT INTO lpr_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('6aada862-bf56-4e20-9d11-77ddd517db4d',
		'5728a79a-5785-4bd2-858a-3202236eb4e8',
		'Plagiarism value on ACW Task 2 = 90% or more',
		'PLAGIARISM_VALUE_ACW_TASK_2_THRESHOLD',
        '2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;
		