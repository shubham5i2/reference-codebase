UPDATE lpr_owner.incident_type
SET  incident_description='Participating in any other kind of malpractice or behaviour'
WHERE incident_type_uuid='e0a6002a-99f8-4e92-8504-69ac78b8f61a';