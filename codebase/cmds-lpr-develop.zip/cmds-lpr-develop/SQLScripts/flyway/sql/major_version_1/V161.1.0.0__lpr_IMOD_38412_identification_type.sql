UPDATE lpr_owner.identification_type SET effective_to_date='2099-12-31' where identification_type_uuid='d794b2ec-3dca-4bd5-a30d-fc9e66ca6918';

UPDATE lpr_owner.identification_type SET effective_to_date='2099-12-31' where identification_type_uuid='09bc0a7b-d3bd-4b35-8383-90d6dea357f3';

UPDATE lpr_owner.identification_type SET effective_to_date='2099-12-31' where identification_type_uuid='e1b0f83e-d441-4578-ac04-fcde7395284b';

UPDATE lpr_owner.identification_type SET effective_to_date='2099-12-31' where identification_type_uuid='1fc4024a-4c28-4e29-ae39-de2348f1affd';

UPDATE lpr_owner.identification_type SET effective_to_date='2099-12-31' where identification_type_uuid='1ce62a44-a533-41ec-a733-861a773efb3f';

UPDATE lpr_owner.identification_type SET effective_to_date='2099-12-31' where identification_type_uuid='1358214c-7fdc-4af4-930a-c14aa0429629';

UPDATE lpr_owner.identification_type SET effective_to_date='2099-12-31' where identification_type_uuid='8e219996-e9cf-45a5-84ce-4acb4feff462';

UPDATE lpr_owner.identification_type SET effective_to_date='2099-12-31' where identification_type_uuid='139cb1bc-e131-4495-bc26-9a142c7370bc';

UPDATE lpr_owner.identification_type SET effective_to_date='2099-12-31' where identification_type_uuid='fd2abd9f-339b-4713-a88e-30969ae70979';

UPDATE lpr_owner.identification_type SET effective_to_date='2099-12-31' where identification_type_uuid='ac708aa9-a364-410f-bf0d-f58d8e72ff64';

UPDATE lpr_owner.identification_type SET effective_to_date='2099-12-31' where identification_type_uuid='8b271679-ecf6-4fed-b3d3-e102f49a55b5';

