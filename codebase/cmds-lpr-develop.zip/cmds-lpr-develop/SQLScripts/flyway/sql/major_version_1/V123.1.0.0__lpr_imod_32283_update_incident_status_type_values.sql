update lpr_owner.incident_status_type 
set incident_status_type = 'Pending'
WHERE incident_status_type_uuid='8356a550-bbdc-461b-a5e7-49c5f1cd58c9'::uuid;

update lpr_owner.incident_status_type 
set incident_status_type = 'Referred'
WHERE incident_status_type_uuid='89347a43-2cf9-47a7-b22a-a0ff0514c51a'::uuid;

update lpr_owner.incident_status_type 
set incident_status_type = 'Dismissed'
WHERE incident_status_type_uuid='36f8d68f-7f68-4755-9420-cec4168179b0'::uuid;