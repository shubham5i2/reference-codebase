--DML scripts for gender

INSERT INTO lpr_owner.gender (gender_uuid, gender_code, gender_description, legacy_reference, effective_from_date,  effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('936338a0-5a3d-447b-83f5-af43ae909ceb',
        'X',
        'Other',
        'X',
        '2020-07-01',
		'2022-03-21',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(gender_uuid) DO NOTHING;
