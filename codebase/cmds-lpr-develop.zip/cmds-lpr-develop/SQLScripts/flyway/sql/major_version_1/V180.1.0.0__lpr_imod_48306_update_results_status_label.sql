UPDATE lpr_owner.results_status_label SET results_status_label = 'Manual Reset', results_status_label_code = 'MANUAL RESET' WHERE results_status_label_uuid='a69a26d1-2ef5-48d9-9088-1da741337cbf';

