INSERT INTO lpr_owner.nationality (nationality_uuid, nationality_code, nationality_name, legacy_reference,effective_to_date, created_by, updated_by, updated_datetime) VALUES ('e407ac0b-bc82-41da-8d68-c623fb0087c5','BUR','Burma','30','2022-03-20','Operations User',NULL,NULL)  ON CONFLICT(nationality_uuid) DO NOTHING;

INSERT INTO lpr_owner.nationality (nationality_uuid, nationality_code, nationality_name, legacy_reference,effective_to_date, created_by, updated_by, updated_datetime) VALUES ('376af44f-8581-4946-8ea3-f17e0ae8648d','CTE','Canton and Enderburys Phoenix Is','35','2022-03-20', 'Operations User',NULL,NULL)  ON CONFLICT(nationality_uuid) DO NOTHING;

INSERT INTO lpr_owner.nationality (nationality_uuid, nationality_code, nationality_name, legacy_reference, effective_to_date, created_by, updated_by, updated_datetime) VALUES ('04594b03-c038-4dd1-b70d-b051f9c92d36','127','Midway Islands','127','2022-03-20', 'Operations User',NULL,NULL)  ON CONFLICT(nationality_uuid) DO NOTHING;

INSERT INTO lpr_owner.nationality (nationality_uuid, nationality_code, nationality_name, legacy_reference, effective_to_date,created_by, updated_by, updated_datetime) VALUES ('6b33cd55-92fc-475d-9b3b-ce4af9f22e78','ANT','Netherlands Antilles','140','2022-03-20','Operations User',NULL,NULL)  ON CONFLICT(nationality_uuid) DO NOTHING;

INSERT INTO lpr_owner.nationality (nationality_uuid, nationality_code, nationality_name, legacy_reference,effective_to_date, created_by, updated_by, updated_datetime) VALUES ('7f05cb39-a59f-4b66-b502-7063a480364c','191','Tahiti','191','2022-03-20', 'Operations User',NULL,NULL)  ON CONFLICT(nationality_uuid) DO NOTHING;

INSERT INTO lpr_owner.nationality (nationality_uuid, nationality_code, nationality_name, legacy_reference,effective_to_date, created_by, updated_by, updated_datetime) VALUES ('8afbadd2-a178-4358-b8b6-692c5bf0c516','37','Caroline Islands','37','2022-03-20', 'Operations User',NULL,NULL)  ON CONFLICT(nationality_uuid) DO NOTHING;