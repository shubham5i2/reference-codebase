UPDATE lpr_owner.product SET product_characteristics ='{"characteristics": ["IOL"],"RoAutoAccepted": ["FALSE"]}' WHERE product_uuid ='3e81e94b-8b6a-42b5-970c-b141f9d195a3';

UPDATE lpr_owner.product SET product_characteristics ='{"characteristics": ["IOL"],"RoAutoAccepted": ["FALSE"]}' WHERE product_uuid ='d96eece2-1d7c-495a-a754-6b523b710a82';

UPDATE lpr_owner.product SET product_characteristics ='{"characteristics": ["IOL", "SSR"],"RoAutoAccepted": ["FALSE"]}' WHERE product_uuid ='6d28d524-472d-4d53-8fd9-dc7c4bb5325d';

UPDATE lpr_owner.product SET product_characteristics ='{"characteristics": ["IOL", "SSR"],"RoAutoAccepted": ["FALSE"]}' WHERE product_uuid ='7b1d8d96-c314-40cd-a61c-2b681086a458';

UPDATE lpr_owner.product SET product_characteristics ='{"characteristics": ["IOC"],"RoAutoAccepted": ["TRUE"]}' WHERE product_uuid ='fdbacec5-e80a-4710-b3de-7d5f310b1466';

UPDATE lpr_owner.product SET product_characteristics ='{"characteristics": ["IOC"],"RoAutoAccepted": ["TRUE"]}' WHERE product_uuid ='cf9a05e9-2679-42da-b7d2-b34ea3e0724e';

UPDATE lpr_owner.product SET product_characteristics ='{"characteristics": ["IOC", "SSR"],"RoAutoAccepted": ["FALSE"]}' WHERE product_uuid ='cb7cd48c-5e79-4a28-8104-e0bcd8e39999';

UPDATE lpr_owner.product SET product_characteristics ='{"characteristics": ["IOC", "SSR"],"RoAutoAccepted": ["FALSE"]}' WHERE product_uuid ='c37e2fab-898d-46d4-a61b-17f24bb29e83';

