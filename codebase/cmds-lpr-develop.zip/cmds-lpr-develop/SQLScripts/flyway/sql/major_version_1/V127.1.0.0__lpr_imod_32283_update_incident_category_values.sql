update lpr_owner.incident_category
set incident_category = 'PRC'
WHERE incident_category_uuid='ffc3db8f-6a8e-4923-8e52-d5dabc51328a'::uuid;

update lpr_owner.incident_category 
set incident_category = 'Technical'
WHERE incident_category_uuid='fe29aad2-6971-4f04-8321-d800eac26c6f'::uuid;

update lpr_owner.incident_category 
set incident_category = 'Other'
WHERE incident_category_uuid='1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9'::uuid;

update lpr_owner.incident_category 
set incident_category = 'Malpractice'
WHERE incident_category_uuid='3109484a-af84-40eb-a244-fe15d4649104'::uuid;