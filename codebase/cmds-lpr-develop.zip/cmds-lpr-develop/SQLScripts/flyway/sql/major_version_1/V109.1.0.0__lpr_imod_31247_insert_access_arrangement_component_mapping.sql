INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('19627dde-7e61-4ec2-8c4e-f557bdc65d00',
			'4c345957-2d0d-4fc2-812f-d62a2553f169',
			'5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
			'R',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;
			
INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('41cb2f86-4700-4050-bb7d-82be726f4be5',
			'4c345957-2d0d-4fc2-812f-d62a2553f169',
			'637f8e1b-0931-4184-9fed-37bc9fdb53d5',
			'R',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;

INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('f67d20b1-f547-4618-93e1-f5bc9022f4f5',
			'4c345957-2d0d-4fc2-812f-d62a2553f169',
			'5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
			'W',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;
			
INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('8c8b7ee8-2d3a-47f2-b136-cb27bd731dce',
			'4c345957-2d0d-4fc2-812f-d62a2553f169',
			'637f8e1b-0931-4184-9fed-37bc9fdb53d5',
			'W',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;

INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('91914caf-5ee0-42dc-8f89-643414d8731a',
			'eca2cff4-a6af-40ca-ab9f-f0aecf3746c7',
			'5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
			'R',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;
			
INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('3f537e59-ce98-4099-a448-39ac81bec976',
			'eca2cff4-a6af-40ca-ab9f-f0aecf3746c7',
			'637f8e1b-0931-4184-9fed-37bc9fdb53d5',
			'R',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;

INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('6bcde1fc-7f56-4d0b-9443-d87690c32e39',
			'eca2cff4-a6af-40ca-ab9f-f0aecf3746c7',
			'5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
			'W',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;
			
INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('1a456186-0884-4c55-b75a-55db7cec9834',
			'eca2cff4-a6af-40ca-ab9f-f0aecf3746c7',
			'637f8e1b-0931-4184-9fed-37bc9fdb53d5',
			'W',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;

INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('c52696b1-5c92-47a6-89d2-ccc06be86eae',
			'c1a53e78-8023-4bc4-93f9-7b76edaab5fb',
			'5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
			'L',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;
			
INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('4f4500bf-a11b-4b9e-b0cc-404b40a3a533',
			'c1a53e78-8023-4bc4-93f9-7b76edaab5fb',
			'637f8e1b-0931-4184-9fed-37bc9fdb53d5',
			'L',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;

INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('85ca2612-1296-423d-9553-e8151811c907',
			'c1a53e78-8023-4bc4-93f9-7b76edaab5fb',
			'5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
			'S',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;
			
INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('953235b4-5bf9-486b-be48-5edd1ae4d958',
			'c1a53e78-8023-4bc4-93f9-7b76edaab5fb',
			'637f8e1b-0931-4184-9fed-37bc9fdb53d5',
			'S',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;

INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('421ab365-65ff-4872-aca1-f1bacb21deb5',
			'5868ebc0-d026-489b-b031-086da0793927',
			'637f8e1b-0931-4184-9fed-37bc9fdb53d5',
			'L',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;

INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('ea1804e8-aaf5-4779-b7f1-c6f9b4c12684',
			'5868ebc0-d026-489b-b031-086da0793927',
			'5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
			'L',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;

INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('c57b01d1-07cd-42e2-98cb-21c2bff75deb',
			'5868ebc0-d026-489b-b031-086da0793927',
			'637f8e1b-0931-4184-9fed-37bc9fdb53d5',
			'R',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;

INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('1167be0b-ecff-43ac-b6f0-fc5adf19a84a',
			'5868ebc0-d026-489b-b031-086da0793927',
			'5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
			'R',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;

INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('6dd11fc8-579c-47b4-9176-325dfef244d1',
			'5868ebc0-d026-489b-b031-086da0793927',
			'637f8e1b-0931-4184-9fed-37bc9fdb53d5',
			'W',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;

INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('800a5113-a407-4074-a8a4-8403f7642d98',
			'5868ebc0-d026-489b-b031-086da0793927',
			'5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
			'W',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;

INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('a60e6651-373b-4da9-81cc-2372a5159087',
			'5868ebc0-d026-489b-b031-086da0793927',
			'637f8e1b-0931-4184-9fed-37bc9fdb53d5',
			'S',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;

INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('ddccba67-577b-406d-a186-46b3e9caa9cd',
			'5868ebc0-d026-489b-b031-086da0793927',
			'5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
			'S',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;

INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('eec2fc57-a636-4dee-9646-b17d5766e5a4',
			'b8fc563a-d5c3-495d-aba1-bf95307b8ccf',
			'5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
			'L',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;

INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('e1ed13df-e4f9-418f-aee4-0f98c62115e5',
			'b8fc563a-d5c3-495d-aba1-bf95307b8ccf',
			'5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
			'R',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;

INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('ebab843b-4f66-4502-ab85-db2d07843482',
			'b8fc563a-d5c3-495d-aba1-bf95307b8ccf',
			'5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
			'W',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;

INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('37782341-98ba-4756-83c7-ef0f8ae76a6b',
			'33671ddf-a08b-4f8f-a600-b0837a7dacfc',
			'5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
			'L',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;

INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('dc305059-d2b5-4d53-af14-4ed70c7df49b',
			'33671ddf-a08b-4f8f-a600-b0837a7dacfc',
			'5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
			'R',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;

INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('5ec48815-af6c-41b2-ad79-e7fb7d90c175',
			'33671ddf-a08b-4f8f-a600-b0837a7dacfc',
			'5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
			'W',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;

INSERT INTO lpr_owner.access_arrangement_component_mapping (access_arrangement_component_mapping_uuid, access_arrangement_type_uuid, delivery_method_uuid, component, created_by, updated_by, updated_datetime, concurrency_version)
    VALUES ('a302e4a8-2cbe-4e6e-88b4-cab6595e8112',
			'33671ddf-a08b-4f8f-a600-b0837a7dacfc',
			'5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
			'S',
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_component_mapping_uuid) DO NOTHING;
