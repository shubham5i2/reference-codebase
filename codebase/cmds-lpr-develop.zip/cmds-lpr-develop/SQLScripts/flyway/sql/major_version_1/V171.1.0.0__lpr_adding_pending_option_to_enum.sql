ALTER TYPE lpr_owner.location_status ADD VALUE 'PENDING';
