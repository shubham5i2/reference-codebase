/**Update commands for results status comment**/
UPDATE lpr_owner.results_status_comment SET results_status_comment_text='Assisting another test taker', results_status_comment_code='ASSISTING_ANOTHER_TT' WHERE results_status_comment_uuid='28ac69c7-88d2-4946-b9dd-465d26cebd02';

UPDATE lpr_owner.results_status_comment SET results_status_comment_text='Attempting to enter the test room with an electronic cheating device ', results_status_comment_code='ATTEMPT_TO_ENTER_ROOM_WITH_ELECTRONIC_CHEATING_DEVICE' WHERE results_status_comment_uuid='268ff3f8-6441-4e68-a1f1-3ac470708527';

UPDATE lpr_owner.results_status_comment SET results_status_comment_text='Copying from another test taker', results_status_comment_code='COPYING_FROM_TEST_TAKER' WHERE results_status_comment_uuid='aeeb67b7-2a22-4219-bc70-f15cc4737dc8';

UPDATE lpr_owner.results_status_comment SET results_status_comment_text='Copying test data/copying test data and removing from the test room ', results_status_comment_code='COPYING_TEST_DATA_REMOVING_FROM_TEST_ROOM' WHERE results_status_comment_uuid='875d47d5-e9ef-4e6e-b1d7-68265efbb2cb';

UPDATE lpr_owner.results_status_comment SET results_status_comment_text='Interfering with device (e.g. camera/audio)', results_status_comment_code='INTERFERING_WITH_DEVICE_CAMERA_AUDIO' WHERE results_status_comment_uuid='092487c5-b672-4ec5-9721-bc8b87c7630c';

UPDATE lpr_owner.results_status_comment SET results_status_comment_text='Leaving the test room/terminating the test before the end of the test', results_status_comment_code='LEAVING_TEST ROOM_BEFORE_END_OF_THE_TEST' WHERE results_status_comment_uuid='b8b59705-adfe-4a0c-8140-eb6050871fa8';

UPDATE lpr_owner.results_status_comment SET results_status_comment_text='Possessing an electronic device (mobile phone, watch)', results_status_comment_code='POSSESSING_AN_ELECTRONIC_DEVICE' WHERE results_status_comment_uuid='7ae811ce-02fa-4766-8d8e-0c733a4c9a3e';

UPDATE lpr_owner.results_status_comment SET results_status_comment_text='Threatening/abusive behaviour to invigilator/test-centre staff', results_status_comment_code='THREATENING_ABUSIVE_CENTRE_STAFF' WHERE results_status_comment_uuid='680cb282-3381-4391-923e-ca67937f503e';

UPDATE lpr_owner.results_status_comment SET results_status_comment_text='Using an electronic device (e.g. camera, phone, bluetooth device)' ,results_status_comment_code='USING_AN_ELECTRONIC_DEVICE' WHERE results_status_comment_uuid='4a3d2877-9905-4e2c-a04c-9de97194ed19';

UPDATE lpr_owner.results_status_comment SET results_status_comment_text='Using an imposter', results_status_comment_code='USING_AN_IMPOSTER' WHERE results_status_comment_uuid='66f7f581-49dc-4077-a65d-fd780c5d1c7a';

UPDATE lpr_owner.results_status_comment SET results_status_comment_text='Using counterfeit/tampered ID', results_status_comment_code='USING_COUNTERFEIT_TAMPERED_ID' WHERE results_status_comment_uuid='2df4d29d-bfae-4096-97cc-a125529b7af3';

UPDATE lpr_owner.results_status_comment SET results_status_comment_text='Using incorrect ID', results_status_comment_code='USING_INCORRECT_ID' WHERE results_status_comment_uuid='05a9daa6-c5be-49fe-9d45-d5be5e5cde54';

UPDATE lpr_owner.results_status_comment SET results_status_comment_code='ATTEMPTED_BRIBERY_BLACKMAIL' WHERE results_status_comment_uuid='5964a833-ead0-4fe6-9f3b-3639c984ba76';


UPDATE lpr_owner.results_status_comment SET results_status_comment_code='IGNORING_INVIGILATOR_S_INSTRUCTIONS' WHERE results_status_comment_uuid='92eb618a-e8b4-4f35-8ac6-9efc3e97bcd5';

UPDATE lpr_owner.results_status_comment SET results_status_comment_code='RECEIVING_ASSISTANCE_FROM_ANOTHER_PERSON' WHERE results_status_comment_uuid='1dcbf354-c20c-4c89-a0c2-25398248107e';

UPDATE lpr_owner.results_status_comment SET results_status_comment_code='USING_A_PROGRAM_OTHER_THAN_INSPERA_PORTAL' WHERE results_status_comment_uuid='b946184e-eaa2-45b0-bc7b-96eac6a1a3ea';

UPDATE lpr_owner.results_status_comment SET results_status_comment_code='USING_PREPARED_NOTES_UNKNOWN_IF_VERSION_SPECIFIC' WHERE results_status_comment_uuid='eb4654bb-c8cf-4e6e-96e5-a19f049d534a';

UPDATE lpr_owner.results_status_comment SET results_status_comment_code='USING_PREPARED_VERSION_SPECIFIC' WHERE results_status_comment_uuid='97ab8adc-e76c-4d62-a4f5-cd4d761e1bb0';
