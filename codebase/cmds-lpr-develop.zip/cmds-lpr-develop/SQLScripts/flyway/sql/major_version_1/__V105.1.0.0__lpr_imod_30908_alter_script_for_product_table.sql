ALTER TABLE lpr_owner.product ADD COLUMN selt_status BOOLEAN;
UPDATE lpr_owner.product SET selt_status = FALSE;
