/**Update command for results status comment**/

UPDATE lpr_owner.results_status_comment SET effective_to_date='2023-01-04' WHERE results_status_comment_uuid='212937d5-2fb4-4228-88ca-de78296537c4';

