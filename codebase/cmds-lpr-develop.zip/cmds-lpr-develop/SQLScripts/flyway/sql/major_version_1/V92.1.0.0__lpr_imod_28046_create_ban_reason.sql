CREATE TABLE IF NOT EXISTS lpr_owner.ban_reason (
    ban_reason_uuid UUID NOT NULL,
	ban_description VARCHAR(1000) NOT NULL,
    effective_from_date DATE NOT NULL DEFAULT '2022-04-01',
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
    created_by VARCHAR(36) NOT NULL,
    created_datetime TIMESTAMPTZ NOT NULL DEFAULT current_timestamp,
    updated_by VARCHAR(36),
    updated_datetime TIMESTAMPTZ,
    concurrency_version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT pk_ban_reason PRIMARY KEY (ban_reason_uuid)
);