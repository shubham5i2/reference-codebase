ALTER TABLE lpr_owner.location DROP COLUMN IF EXISTS test_centre_administrator_uuid;

ALTER TABLE lpr_owner.location DROP COLUMN IF EXISTS request_status;
