alter table lpr_owner.incident_type 
alter column ban_review_required drop not null;