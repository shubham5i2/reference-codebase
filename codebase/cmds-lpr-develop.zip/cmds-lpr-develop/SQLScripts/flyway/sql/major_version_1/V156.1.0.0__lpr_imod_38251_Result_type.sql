INSERT INTO lpr_owner.results_type(results_type_uuid, results_type,  results_type_code, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('fc04c69b-ab6b-4a3a-bad0-a9ca13e8bb0a',
		'Linked EOR',
		'LINKED_EOR',
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_type_uuid) DO NOTHING;

