INSERT INTO lpr_owner.access_arrangement_type(access_arrangement_type_uuid, access_arrangement_code, access_arrangement_name, ca_approval_required, modified_material_required, endorsement_required, created_by, updated_by, updated_datetime, concurrency_version)
	VALUES ('4c345957-2d0d-4fc2-812f-d62a2553f169',
			'ET25',
			'25% extra time',
			false,
			false,
			false,
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_type_uuid) DO NOTHING;

INSERT INTO lpr_owner.access_arrangement_type(access_arrangement_type_uuid, access_arrangement_code, access_arrangement_name, ca_approval_required, modified_material_required, endorsement_required, created_by, updated_by, updated_datetime, concurrency_version)
	VALUES ('eca2cff4-a6af-40ca-ab9f-f0aecf3746c7',
			'ET50',
			'50% extra time',
			true,
			false,
			false,
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_type_uuid) DO NOTHING;

INSERT INTO lpr_owner.access_arrangement_type(access_arrangement_type_uuid, access_arrangement_code, access_arrangement_name, ca_approval_required, modified_material_required, endorsement_required, created_by, updated_by, updated_datetime, concurrency_version)
	VALUES ('c1a53e78-8023-4bc4-93f9-7b76edaab5fb',
			'ETAA',
			'Extra time (as appropriate)',
			true,
			false,
			false,
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_type_uuid) DO NOTHING;

INSERT INTO lpr_owner.access_arrangement_type(access_arrangement_type_uuid, access_arrangement_code, access_arrangement_name, ca_approval_required, modified_material_required, endorsement_required, created_by, updated_by, updated_datetime, concurrency_version)
	VALUES ('5868ebc0-d026-489b-b031-086da0793927',
			'EX',
			'Exemption',
			true,
			false,
			true,
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_type_uuid) DO NOTHING;

INSERT INTO lpr_owner.access_arrangement_type(access_arrangement_type_uuid, access_arrangement_code, access_arrangement_name, ca_approval_required, modified_material_required, endorsement_required, created_by, updated_by, updated_datetime, concurrency_version)
	VALUES ('b8fc563a-d5c3-495d-aba1-bf95307b8ccf',
			'SI',
			'Separate invigilation',
			false,
			false,
			false,
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_type_uuid) DO NOTHING;
		
INSERT INTO lpr_owner.access_arrangement_type(access_arrangement_type_uuid, access_arrangement_code, access_arrangement_name, ca_approval_required, modified_material_required, endorsement_required, created_by, updated_by, updated_datetime, concurrency_version)
	VALUES ('33671ddf-a08b-4f8f-a600-b0837a7dacfc',
			'SB',
			'Supervised breaks',
			false,
			false,
			false,
			'Operations User',
			NULL,NULL,0)ON CONFLICT(access_arrangement_type_uuid) DO NOTHING;
		
			