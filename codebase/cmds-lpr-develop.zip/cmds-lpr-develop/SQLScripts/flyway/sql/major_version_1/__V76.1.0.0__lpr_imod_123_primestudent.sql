CREATE TABLE prime_student(
    student_id SERIAL PRIMARY KEY,
    first_name VARCHAR(45) NOT NULL,
    last_name VARCHAR(45) NOT NULL,
    address_line_1 VARCHAR(30),
    email VARCHAR(100) NOT NULL UNIQUE
);

