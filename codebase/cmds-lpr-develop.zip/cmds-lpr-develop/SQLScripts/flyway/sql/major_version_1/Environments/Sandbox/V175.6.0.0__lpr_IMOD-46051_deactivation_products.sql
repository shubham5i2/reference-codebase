-- Deactivation of IOL GT

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='d96eece2-1d7c-495a-a754-6b523b710a82';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='18c94472-35e8-4d89-93da-f6d9caa7f003';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='f21e2e7f-02e8-4bd7-9602-c247e8a02a5a';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='d8c32eff-1112-467b-a881-9e52f5acc796';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='48b0643a-11eb-4eff-b4e3-3f930c6fcdd3';

-- Deactivation of IOL OSR AC

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='6d28d524-472d-4d53-8fd9-dc7c4bb5325d';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='95fa3301-e17c-4467-bab5-f4754765ad4d';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='9cdec6ab-7886-476a-a586-13dfda9a52a9';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='deea53e9-886b-4dee-b0b2-9ab29c70a82e';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='bb71c4bb-ba26-4569-99fa-fb3d2aec1120';

-- Deactivation of IOL OSR GT

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='7b1d8d96-c314-40cd-a61c-2b681086a458';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='304d2fa4-642d-4ec7-8600-ae21eb8b4dd8';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='d5d4392d-b3c7-4a99-b039-98a281c0104d';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='c5524e22-ec61-4705-b7d1-5818826b7cd1';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='a489fddd-9bb5-4ed4-9678-0a88bde4778c';

-- Deactivation of IOC SELT AC

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='6d04f596-22f2-49c4-9d47-85b167b8ca6f';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='15d0e10b-9046-40ba-a9d5-a5fdacbdf29d';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='76f5c60e-4ea1-451c-89c5-8ad2adad6ea3';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='ae943abe-3d6b-48d3-a841-064515f13db1';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='d9caf654-789a-4b50-a5e3-7123c365b92d';

-- Deactivation of IOC SELT GT

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='54b9d8df-c07a-4cb4-b397-adc4faa87c3f';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='9e8b80f8-c697-4c88-959d-4875b265b927';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='a9610d1d-124d-4d58-8468-b921202ca1ee';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='7cc8a727-4671-4b5a-b0fd-60c08b3a023b';

UPDATE lpr_owner.product SET available_to_date='2099-12-31' where product_uuid='169ba597-2638-4ddf-b245-15f390397d9a';