UPDATE lpr_owner.product SET bookable =true WHERE product_uuid ='3e81e94b-8b6a-42b5-970c-b141f9d195a3';
