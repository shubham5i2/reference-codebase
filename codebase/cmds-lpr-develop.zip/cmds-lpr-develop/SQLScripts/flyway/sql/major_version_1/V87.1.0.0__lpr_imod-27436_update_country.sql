
UPDATE lpr_owner.country SET country_name='Serbia and Montenegro' WHERE country_uuid='40bd389f-857d-4ade-8eb4-ce8d7b2d9928';