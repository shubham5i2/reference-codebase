-- Inactive Types
update lpr_owner.incident_type set effective_to_date = current_date where incident_type_uuid in
('7236364c-e324-4aaa-aeff-e30b416b26a5',
'bd12131e-f411-4441-a23b-be51f9572062',
'21eddabd-cc94-4878-a41e-963a00d5b00d',
'85ce3a9a-b643-4193-820e-06f9a6a4914e',
'7d954353-bb83-49ec-9998-16084e15509b',
'0bc9f8c3-63c3-4577-beac-6ef87447308a',
'5d0de0c9-24bf-4d2f-bf97-ca5b15c20ca1',
'77d33791-2847-4c9e-997e-1e6da53fb9e5',
'b27426fb-432d-4ad6-bd0b-90a2a0b767aa',
'be08a4cd-de9f-4616-8dd4-7468cdb015ca',
'b2879700-978f-4638-9845-7a831a5be550',
'c2293419-a5bf-481e-847b-4cefb7639b24',
'27411eaa-7c59-4355-94b5-065d3b6d9772');

-- Update description
update lpr_owner.incident_type set incident_description  = 'Ignoring invigilator''s instructions' where incident_type_uuid = '0c1898b6-cedd-4e1a-88aa-491f88fbdddb';
update lpr_owner.incident_type set incident_description  = 'Interfering with device (e.g. camera/audio)' where incident_type_uuid = '09260095-a1d0-46c1-a46e-aa67b6b9bcfe';

-- Removal of prefixes
update lpr_owner.incident_type set external_incident_type  = 'id_not_verified' where incident_type_uuid = '869311b9-d77f-450d-af85-84243d1c91ea';
update lpr_owner.incident_type set external_incident_type  = 'id_require_follow_up' where incident_type_uuid = '447c1c5a-1b10-44c4-852f-e2e6e59c4724';
update lpr_owner.incident_type set external_incident_type  = 'major_video_issues' where incident_type_uuid = '4f349bac-972f-4799-a36e-c28114c4c1ca';
update lpr_owner.incident_type set external_incident_type  = 'major_audio_issues' where incident_type_uuid = 'e45dadb3-cf95-4156-8db6-5345bce8caf8';
