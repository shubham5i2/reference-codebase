UPDATE lpr_owner.incident_type SET external_incident_type = 'counterfeit_tampered_id' WHERE incident_type_uuid = '5cf0fd2f-3f50-4237-9b36-b6207bc10564';

UPDATE lpr_owner.incident_type SET external_incident_type = 'remote_assistance' WHERE incident_type_uuid = '06d16b48-7697-4701-998b-2e7ed5cc6a78';

UPDATE lpr_owner.incident_type SET external_incident_type = 'abusive_behaviour' WHERE incident_type_uuid = '5db24e51-515e-4f3b-b0cb-f77c33f7d63a';

UPDATE lpr_owner.incident_type SET external_incident_type = 'do_not_use_iep' WHERE incident_type_uuid = '514f6342-37c5-433e-b328-abefce804508';

UPDATE lpr_owner.incident_type SET external_incident_type = 'id_require_follow_up' WHERE incident_type_uuid = '586ba13d-4a60-4a80-8d1d-81c6b5701fb6';
