--DML scripts for occupation level
INSERT INTO lpr_owner.occupation_level (occupation_level_uuid, occupation_level, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('4faad5f5-97e1-4d64-bec5-7d50bc0acf49',
        'Other',
        '0',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_level_uuid) DO NOTHING;


INSERT INTO lpr_owner.occupation_level (occupation_level_uuid, occupation_level, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('f2e986a8-fd14-4f89-a43b-d385eb2c3f98',
        'Self-employed',
        '1',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_level_uuid) DO NOTHING;


INSERT INTO lpr_owner.occupation_level (occupation_level_uuid, occupation_level, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('12f9cbe7-1dfc-4a41-842f-6e495708e9a7',
        'Employer/Partner',
        '2',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_level_uuid) DO NOTHING;


INSERT INTO lpr_owner.occupation_level (occupation_level_uuid, occupation_level, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('e89cb017-196f-4ffd-a0af-e8b9a29e7774',
        'Employee (Senior level)',
        '3',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_level_uuid) DO NOTHING;


INSERT INTO lpr_owner.occupation_level (occupation_level_uuid, occupation_level, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('225758f0-bbf7-444e-ab2e-e371fe59d5f6',
        'Employee (Middle or Junior)',
        '4',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_level_uuid) DO NOTHING;


INSERT INTO lpr_owner.occupation_level (occupation_level_uuid, occupation_level, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('056a6fd6-5103-4015-8c3c-b04f2dad920c',
        'Worker in the home',
        '5',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_level_uuid) DO NOTHING;


INSERT INTO lpr_owner.occupation_level (occupation_level_uuid, occupation_level, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('ffbaf562-eade-43af-ae74-5559a3dbc656',
        'Retired',
        '6',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_level_uuid) DO NOTHING;


INSERT INTO lpr_owner.occupation_level (occupation_level_uuid, occupation_level, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('f40f301f-6605-45a0-b2eb-7336477f1b75',
        'Student',
        '7',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_level_uuid) DO NOTHING;

