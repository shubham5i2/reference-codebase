INSERT INTO lpr_owner.check_outcome_type
(check_outcome_type_uuid, check_outcome_type, check_outcome_type_code, effective_from_date, created_by,updated_by,updated_datetime)
VALUES('c6eebce9-d53e-430b-ad36-44ed9ce2872a', 'Speaking Incident Check', 'SPK_INC_CHK', '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(check_outcome_type_uuid) DO NOTHING;

INSERT INTO lpr_owner.check_outcome_type
(check_outcome_type_uuid, check_outcome_type,check_outcome_type_code, effective_from_date, created_by,updated_by,updated_datetime)
VALUES('51c94a9d-c563-4f4d-8544-f90e59592463', 'LRW Incident Check', 'LRW_INC_CHK', '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(check_outcome_type_uuid) DO NOTHING;

INSERT INTO lpr_owner.check_outcome_type
(check_outcome_type_uuid, check_outcome_type,check_outcome_type_code, effective_from_date, created_by,updated_by,updated_datetime)
VALUES('cfda45c8-efe6-44b4-b051-85b49ad96100', 'Proctoring Check', 'PROC_INC_CHK', '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(check_outcome_type_uuid) DO NOTHING;

INSERT INTO lpr_owner.check_outcome_type
(check_outcome_type_uuid, check_outcome_type,check_outcome_type_code, effective_from_date, created_by,updated_by,updated_datetime)
VALUES('98760142-bace-4bb0-b2a9-d90b9b393553', 'Plagiarism Check', 'PLG_INC_CHK', '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(check_outcome_type_uuid) DO NOTHING;

INSERT INTO lpr_owner.check_outcome_type
(check_outcome_type_uuid, check_outcome_type,check_outcome_type_code, effective_from_date, created_by,updated_by,updated_datetime)
VALUES('760ecebb-cad3-449c-927a-507033989b91', 'LRW ID Check', 'LRW_ID_INC_CHK', '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(check_outcome_type_uuid) DO NOTHING;

INSERT INTO lpr_owner.check_outcome_type
(check_outcome_type_uuid, check_outcome_type,check_outcome_type_code, effective_from_date, created_by,updated_by,updated_datetime)
VALUES('79a8caec-2129-4f31-9b52-b299ea0e7eab', 'Speaking ID Check', 'SPK_ID_INC_CHK', '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(check_outcome_type_uuid) DO NOTHING;

INSERT INTO lpr_owner.check_outcome_type
(check_outcome_type_uuid, check_outcome_type,check_outcome_type_code, effective_from_date, created_by,updated_by,updated_datetime)
VALUES('005ef982-3749-4a59-98c9-5da13fed6017', 'Pre-Release Check', 'PRC_INC_CHK', '2020-07-01', 'Operations User', NULL, NULL) ON CONFLICT(check_outcome_type_uuid) DO NOTHING;
