--DML scripts for education level
INSERT INTO lpr_owner.education_level (education_level_uuid, education_level, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('ba7e70a1-030f-4ed2-9e4c-97e1fe3bb43a',
        'Secondary up to 16 years',
        '0',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(education_level_uuid) DO NOTHING;


INSERT INTO lpr_owner.education_level (education_level_uuid, education_level, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('f682ce0b-4246-41cb-90e5-fb8a58af1f8d',
        'Secondary 16 to 19 years',
        '1',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(education_level_uuid) DO NOTHING;


INSERT INTO lpr_owner.education_level (education_level_uuid, education_level, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('33e2bdc6-461f-45fb-b3bb-2c8458cce805',
        'Degree or equivalent',
        '2',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(education_level_uuid) DO NOTHING;


INSERT INTO lpr_owner.education_level (education_level_uuid, education_level, legacy_reference, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('7b340b48-2cdb-4f39-b262-2a91dc42e931',
        'Post graduate',
        '3',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(education_level_uuid) DO NOTHING;

