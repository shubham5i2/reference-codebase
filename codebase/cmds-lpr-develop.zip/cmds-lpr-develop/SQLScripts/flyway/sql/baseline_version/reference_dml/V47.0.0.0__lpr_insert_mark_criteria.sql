INSERT INTO lpr_owner.mark_criteria( mark_criteria_uuid,
                                     mark_criteria_code,
                                     mark_criteria,
                                     description,
                                     created_by,
                                     updated_by,
                                     updated_datetime)
VALUES ('1182960a-e547-4e57-b06a-db499e4927ee',
		'TA',
		'criteria_ta',
		'Task Achievement (Writing Task 1)',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(mark_criteria_uuid) DO NOTHING;

INSERT INTO lpr_owner.mark_criteria( mark_criteria_uuid,
                                     mark_criteria_code,
                                     mark_criteria,
                                     description,
                                     created_by,
                                     updated_by,
                                     updated_datetime)
VALUES ('600bc354-b1f5-4567-b8c5-84b1a3344e65',
		'TR',
		'criteria_tr',
		'Task Response (Writing Task 2)',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(mark_criteria_uuid) DO NOTHING;

INSERT INTO lpr_owner.mark_criteria( mark_criteria_uuid,
                                     mark_criteria_code,
                                     mark_criteria,
                                     description,
                                     created_by,
                                     updated_by,
                                     updated_datetime)
VALUES ('574a9570-da1d-45c7-ad44-c56c29f4d1bc',
		'CC',
		'criteria_cc',
		'Coherence and Cohesion (Writing Tasks 1 & 2)',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(mark_criteria_uuid) DO NOTHING;

INSERT INTO lpr_owner.mark_criteria( mark_criteria_uuid,
                                     mark_criteria_code,
                                     mark_criteria,
                                     description,
                                     created_by,
                                     updated_by,
                                     updated_datetime)
VALUES ('e0dc0b2e-70fc-466c-aaf3-d90389169174',
		'LR',
		'criteria_lr',
		'Lexical Resource (Writing Tasks 1 & 2 and Speaking)',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(mark_criteria_uuid) DO NOTHING;

INSERT INTO lpr_owner.mark_criteria( mark_criteria_uuid,
                                     mark_criteria_code,
                                     mark_criteria,
                                     description,
                                     created_by,
                                     updated_by,
                                     updated_datetime)
VALUES ('d0d2b953-7370-47e1-9508-4383fe46b3bb',
		'GRA',
		'criteria_gra',
		'Grammatical Range and Accuracy (Writing Tasks 1 & 2 and Speaking)',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(mark_criteria_uuid) DO NOTHING;

INSERT INTO lpr_owner.mark_criteria( mark_criteria_uuid,
                                     mark_criteria_code,
                                     mark_criteria,
                                     description,
                                     created_by,
                                     updated_by,
                                     updated_datetime)
VALUES ('211c37da-5677-403c-aa49-606a8015e6c2',
		'FC',
		'criteria_fc',
		'Fluency and Coherence (Speaking)',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(mark_criteria_uuid) DO NOTHING;

INSERT INTO lpr_owner.mark_criteria( mark_criteria_uuid,
                                     mark_criteria_code,
                                     mark_criteria,
                                     description,
                                     created_by,
                                     updated_by,
                                     updated_datetime)
VALUES ('9f7e9124-5f76-48b9-9815-97b7e1573708',
		'P',
		'criteria_p',
		'Pronunciation (Speaking)',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(mark_criteria_uuid) DO NOTHING;
