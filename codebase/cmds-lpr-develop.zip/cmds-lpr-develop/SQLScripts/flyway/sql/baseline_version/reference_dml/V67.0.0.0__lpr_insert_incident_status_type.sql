INSERT INTO lpr_owner.incident_status_type
(incident_status_type_uuid, incident_status_type, incident_status_type_code, effective_from_date, created_by, updated_by, updated_datetime)
VALUES('6a91d649-18d7-48ae-9797-659b99cb1182', 'Flagged', 'INC_STATUS_FLAGGED','2020-07-01','Operations User', NULL, NULL) ON CONFLICT(incident_status_type_uuid) DO NOTHING;

INSERT INTO lpr_owner.incident_status_type
(incident_status_type_uuid, incident_status_type, incident_status_type_code, effective_from_date, created_by, updated_by, updated_datetime)
VALUES('f9dc2a18-2f98-4579-92b2-1568d0858a6a', 'Passed', 'INC_STATUS_PASSED','2020-07-01','Operations User', NULL, NULL) ON CONFLICT(incident_status_type_uuid) DO NOTHING;

INSERT INTO lpr_owner.incident_status_type
(incident_status_type_uuid, incident_status_type, incident_status_type_code, effective_from_date, created_by, updated_by, updated_datetime)
VALUES('36f8d68f-7f68-4755-9420-cec4168179b0', 'Cleared', 'INC_STATUS_CLEARED','2020-07-01','Operations User', NULL, NULL) ON CONFLICT(incident_status_type_uuid) DO NOTHING;
