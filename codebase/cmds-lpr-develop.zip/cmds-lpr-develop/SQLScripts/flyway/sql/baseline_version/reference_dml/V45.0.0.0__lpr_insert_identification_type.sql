--DML scripts for identification type
INSERT INTO lpr_owner.identification_type (identification_type_uuid, identification_type, description, legacy_reference, effective_from_date,created_by,updated_by,updated_datetime)
VALUES ('b0344576-5cf2-4822-9f99-4d4afb03667a',
        'I',
        'National Identity',
        'I',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(identification_type_uuid) DO NOTHING;

INSERT INTO lpr_owner.identification_type (identification_type_uuid, identification_type, description, legacy_reference, effective_from_date,created_by,updated_by,updated_datetime)
VALUES ('c59ffdcd-5795-4376-8f15-34a6bf249df5',
        'P',
        'Passport',
        'P',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(identification_type_uuid) DO NOTHING;

INSERT INTO lpr_owner.identification_type (identification_type_uuid, identification_type, description, legacy_reference, effective_from_date,effective_to_date, created_by,updated_by,updated_datetime)
VALUES ('d794b2ec-3dca-4bd5-a30d-fc9e66ca6918',
        'B',
        'Biometric Residence Permit',
        'B',
        '2013-01-01',
		'2021-09-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(identification_type_uuid) DO NOTHING;


INSERT INTO lpr_owner.identification_type (identification_type_uuid, identification_type, description, legacy_reference, effective_from_date,effective_to_date, created_by,updated_by,updated_datetime)
VALUES ('09bc0a7b-d3bd-4b35-8383-90d6dea357f3',
        'C',
        'Certificate of Identity',
        'C',
        '2013-01-01',
		'2021-09-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(identification_type_uuid) DO NOTHING;


INSERT INTO lpr_owner.identification_type (identification_type_uuid, identification_type, description, legacy_reference, effective_from_date,effective_to_date, created_by,updated_by,updated_datetime)
VALUES ('e1b0f83e-d441-4578-ac04-fcde7395284b',
        'D',
        'Immigration Status Document, and UKRP with photo',
        'D',
        '2013-01-01',
		'2021-09-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(identification_type_uuid) DO NOTHING;


INSERT INTO lpr_owner.identification_type (identification_type_uuid, identification_type, description, legacy_reference, effective_from_date,effective_to_date, created_by,updated_by,updated_datetime)
VALUES ('1fc4024a-4c28-4e29-ae39-de2348f1affd',
        'E',
        'Emergency travel document',
        'E',
       '2013-01-01',
		'2021-09-01',
        'Operations User',
        NULL,
         NULL)  ON CONFLICT(identification_type_uuid) DO NOTHING;


INSERT INTO lpr_owner.identification_type (identification_type_uuid, identification_type, description, legacy_reference, effective_from_date,effective_to_date,created_by,updated_by,updated_datetime)
VALUES ('8b271679-ecf6-4fed-b3d3-e102f49a55b5',
        'G',
        'Valid photographic Government issued identity card',
        'G',
        '2013-01-01',
		'2021-09-01',
        'Operations User',
        NULL,
         NULL)  ON CONFLICT(identification_type_uuid) DO NOTHING;

INSERT INTO lpr_owner.identification_type (identification_type_uuid, identification_type, description, legacy_reference, effective_from_date,effective_to_date, created_by,updated_by,updated_datetime)
VALUES ('1ce62a44-a533-41ec-a733-861a773efb3f',
        'N',
        'Identity card of EEA nationals or Swiss national',
        'N',
       '2013-01-01',
		'2021-09-01',
        'Operations User',
        NULL,
         NULL)  ON CONFLICT(identification_type_uuid) DO NOTHING;
		 
INSERT INTO lpr_owner.identification_type (identification_type_uuid, identification_type, description, legacy_reference, effective_from_date,effective_to_date, created_by,updated_by,updated_datetime)
VALUES ('1358214c-7fdc-4af4-930a-c14aa0429629',
        'R',
        'Travel doc issued by the International Red Cross',
        'R',
        '2013-01-01',
		'2021-09-01',
        'Operations User',
        NULL,
         NULL)  ON CONFLICT(identification_type_uuid) DO NOTHING;


INSERT INTO lpr_owner.identification_type (identification_type_uuid, identification_type, description, legacy_reference, effective_from_date,effective_to_date, created_by,updated_by,updated_datetime)
VALUES ('8e219996-e9cf-45a5-84ce-4acb4feff462',
        'S',
        'Stateless persons travel document',
        'S',
        '2013-01-01',
		'2021-09-01',
        'Operations User',
        NULL,
         NULL)  ON CONFLICT(identification_type_uuid) DO NOTHING;


INSERT INTO lpr_owner.identification_type (identification_type_uuid, identification_type, description, legacy_reference, effective_from_date,effective_to_date, created_by,updated_by,updated_datetime)
VALUES ('139cb1bc-e131-4495-bc26-9a142c7370bc',
        'T',
        'Convention travel document',
        'T',
        '2013-01-01',
		'2021-09-01',
        'Operations User',
        NULL,
         NULL)  ON CONFLICT(identification_type_uuid) DO NOTHING;


INSERT INTO lpr_owner.identification_type (identification_type_uuid, identification_type, description, legacy_reference, effective_from_date,effective_to_date,created_by,updated_by,updated_datetime)
VALUES ('fd2abd9f-339b-4713-a88e-30969ae70979',
        'U',
        'Travel document issued by the United Nations',
        'U',
        '2013-01-01',
		'2021-09-01',
        'Operations User',
        NULL,
         NULL)  ON CONFLICT(identification_type_uuid) DO NOTHING;

INSERT INTO lpr_owner.identification_type (identification_type_uuid, identification_type, description, legacy_reference, effective_from_date,effective_to_date,created_by,updated_by,updated_datetime)
VALUES ('ac708aa9-a364-410f-bf0d-f58d8e72ff64',
        'V',
        'GV3, with Entry Clearance vignette/Visa with photo',
        'V',
        '2013-01-01',
		'2021-09-01',
        'Operations User',
        NULL,
         NULL)  ON CONFLICT(identification_type_uuid) DO NOTHING;

