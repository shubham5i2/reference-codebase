--DML scripts for sector type
INSERT INTO lpr_owner.sector_type(sector_type_uuid, sector_type, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('48270c84-4cc8-489e-8eac-2af59898175a',
		'College / University',
		NULL,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(sector_type_uuid) DO NOTHING;


INSERT INTO lpr_owner.sector_type(sector_type_uuid, sector_type, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('8cd04009-00db-443d-ab87-4177da05f890',
		'Further or Continuing Education',
		NULL,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(sector_type_uuid) DO NOTHING;


INSERT INTO lpr_owner.sector_type(sector_type_uuid, sector_type, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('f3d1b2fe-0862-416c-b6c2-3eab0ebb56b5',
		'Government body',
		NULL,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(sector_type_uuid) DO NOTHING;


INSERT INTO lpr_owner.sector_type(sector_type_uuid, sector_type, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('498d69e3-40e6-4d6d-b178-16a475455f07',
		'Professional body',
		NULL,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(sector_type_uuid) DO NOTHING;


INSERT INTO lpr_owner.sector_type(sector_type_uuid, sector_type, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('6fa5c4bc-e033-41d4-992c-cbed3dffed06',
		'Secondary / Boarding school',
		NULL,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(sector_type_uuid) DO NOTHING;


INSERT INTO lpr_owner.sector_type(sector_type_uuid, sector_type, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('714feb22-b5a2-40bd-af48-b2239b2b133c',
		'Visa / Immigration agent',
		NULL,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(sector_type_uuid) DO NOTHING;


INSERT INTO lpr_owner.sector_type(sector_type_uuid, sector_type, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('e8795152-efb4-494d-807e-dfd4893133fa',
		'Test taker',
		NULL,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(sector_type_uuid) DO NOTHING;


INSERT INTO lpr_owner.sector_type(sector_type_uuid, sector_type, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('25d6cc76-0507-4517-89ba-4ce8a49a0e9f',
		'Employer / HR department',
		NULL,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(sector_type_uuid) DO NOTHING;


INSERT INTO lpr_owner.sector_type(sector_type_uuid, sector_type, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('f3192aae-9979-4c5d-bf57-4126d4fbfad7',
		'Recruiter or Education agent',
		NULL,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(sector_type_uuid) DO NOTHING;


INSERT INTO lpr_owner.sector_type(sector_type_uuid, sector_type, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('ddbe045d-081a-4695-95f9-460ab2964a6e',
		'Education sector business',
		NULL,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(sector_type_uuid) DO NOTHING;


INSERT INTO lpr_owner.sector_type(sector_type_uuid, sector_type, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('c4dd65e0-ca6d-433f-9460-7838e7664640',
		'Agent',
		NULL,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(sector_type_uuid) DO NOTHING;


INSERT INTO lpr_owner.sector_type(sector_type_uuid, sector_type, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('1d25057d-c557-4b3e-961a-0e4c74a5f288',
		'Clearing house',
		NULL,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(sector_type_uuid) DO NOTHING;


INSERT INTO lpr_owner.sector_type(sector_type_uuid, sector_type, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('05f90739-4bd6-40fb-8f2e-556b69e1514f',
		'Pathway provider',
		NULL,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(sector_type_uuid) DO NOTHING;

INSERT INTO lpr_owner.sector_type(sector_type_uuid, sector_type, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('7000e02a-0bfc-44f0-af55-84dc72c12cac',
		'Regulator',
		NULL,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(sector_type_uuid) DO NOTHING;

INSERT INTO lpr_owner.sector_type(sector_type_uuid, sector_type, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('d82b6817-62ff-4528-9783-1ed323c2e29a',
		'Regulatory Authority',
		NULL,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(sector_type_uuid) DO NOTHING;

INSERT INTO lpr_owner.sector_type(sector_type_uuid, sector_type, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('6bab326c-9f11-4183-9b30-04f88fa845ef',
		'English Language School',
		NULL,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(sector_type_uuid) DO NOTHING;

INSERT INTO lpr_owner.sector_type(sector_type_uuid, sector_type, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('7c3d162e-a023-4c6e-8d42-27f60efff700',
		'Other',
		NULL,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(sector_type_uuid) DO NOTHING;

