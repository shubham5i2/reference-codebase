--DML scripts for results type
INSERT INTO lpr_owner.results_type(results_type_uuid, results_type,  results_type_code, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('76a3e4f0-2a7b-4aec-8389-2255726a31ef',
		'Normal',
        'NORMAL',
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_type_uuid) DO NOTHING;


INSERT INTO lpr_owner.results_type(results_type_uuid, results_type,  results_type_code, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('d28fec9b-752f-477a-a124-2a726d247098',
		'Jagged 1',
        'JAGGED_1',
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_type_uuid) DO NOTHING;


INSERT INTO lpr_owner.results_type(results_type_uuid, results_type,  results_type_code, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('399b45a9-9c32-4889-a44e-cdc595f8a6f7',
		'EOR',
		'EOR',
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_type_uuid) DO NOTHING;




INSERT INTO lpr_owner.results_type(results_type_uuid, results_type,  results_type_code, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('63b2b641-9cfc-4870-936d-9639a8069ecb',
		'Jagged 2',
		'JAGGED_2',
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_type_uuid) DO NOTHING;
