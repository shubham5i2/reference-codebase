--DML scripts for results status label

TRUNCATE TABLE lpr_owner.results_status_label CASCADE;

INSERT INTO lpr_owner.results_status_label(results_status_label_uuid, results_status_type_uuid, results_status_label,  results_status_label_code, results_status_comment_mandatory, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('aee4f1ac-d11a-4423-b1b6-61cb5bb30a78',
		'3d189282-e531-47f2-aa22-d24eef1d20b6',
		'EOR Pending',
		'EOR_PENDING',
		false,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_label_uuid) DO NOTHING;


INSERT INTO lpr_owner.results_status_label(results_status_label_uuid,  results_status_type_uuid, results_status_label, results_status_label_code, results_status_comment_mandatory, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('b45fa3ff-3218-4671-aed7-e9bd89e407b1',
		'3d189282-e531-47f2-aa22-d24eef1d20b6',
		'Manual Marks Update',
		'MANUAL_MARKS_UPDATE',
		false,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_label_uuid) DO NOTHING;


INSERT INTO lpr_owner.results_status_label(results_status_label_uuid,  results_status_type_uuid, results_status_label, results_status_label_code, results_status_comment_mandatory, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('12b2e233-81a4-4263-b327-9b47ba09eb53',
		'3d189282-e531-47f2-aa22-d24eef1d20b6',
		'Post-relase Grade Change',
		'POST_RELEASE_GRADE_CHANGE',
		false,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_label_uuid) DO NOTHING;


INSERT INTO lpr_owner.results_status_label(results_status_label_uuid,  results_status_type_uuid, results_status_label, results_status_label_code, results_status_comment_mandatory, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('52a50291-bd70-4989-9fce-584b0aa3cc65',
		'735d2d71-b4a9-47ec-b566-34b2d3015540',
		'Pre-release Check Investigation',
		'PRE_RELEASE_CHECK_INVESTIGATION',
		false,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_label_uuid) DO NOTHING;


INSERT INTO lpr_owner.results_status_label(results_status_label_uuid,  results_status_type_uuid, results_status_label, results_status_label_code, results_status_comment_mandatory, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('50324a6c-4fb5-464d-a063-7a146ffb96bc',
		'57d416a1-57b3-4b72-b24c-d511f1749a79',
		'Pre-release Check Investigation',
		'PRE_RELEASE_CHECK_INVESTIGATION',
		true,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_label_uuid) DO NOTHING;


INSERT INTO lpr_owner.results_status_label(results_status_label_uuid,  results_status_type_uuid, results_status_label, results_status_label_code, results_status_comment_mandatory, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('d00d4331-f798-429a-9c18-49893bdcba59',
		'57d416a1-57b3-4b72-b24c-d511f1749a79',
		'Test Day Malpractice',
		'TEST_DAY_MALPRACTICE',
		true,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_label_uuid) DO NOTHING;


INSERT INTO lpr_owner.results_status_label(results_status_label_uuid,  results_status_type_uuid, results_status_label, results_status_label_code, results_status_comment_mandatory, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('5728a79a-5785-4bd2-858a-3202236eb4e8',
		'57d416a1-57b3-4b72-b24c-d511f1749a79',
		'Post-release Cancellation',
		'POST_RELEASE_CANCELATION',
		true,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_label_uuid) DO NOTHING;


