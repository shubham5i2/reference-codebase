-- Create Database
DROP DATABASE IF EXISTS lpr;
DROP ROLE IF EXISTS lpr_rw_role;
DROP USER IF EXISTS lpr_user;

CREATE DATABASE lpr
    WITH
    OWNER = postgres
    ENCODING = 'UTF8'
    CONNECTION LIMIT = -1;