CREATE TABLE IF NOT EXISTS lpr_owner.results_status_type (
    results_status_type_uuid UUID NOT NULL,
    results_status VARCHAR(50) NOT NULL,
    results_status_code VARCHAR(50) NOT NULL,
    effective_from_date DATE NOT NULL,
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
    created_by VARCHAR(36) NOT NULL,
    created_datetime TIMESTAMPTZ NOT NULL DEFAULT current_timestamp,
    updated_by VARCHAR(36),
    updated_datetime TIMESTAMPTZ,
    concurrency_version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT pk_results_status_type PRIMARY KEY (results_status_type_uuid)
);
