CREATE TABLE IF NOT EXISTS lpr_owner.language (
    language_uuid UUID NOT NULL,
    language_code VARCHAR(3) NOT NULL UNIQUE,
    language_name VARCHAR(20) NOT NULL,
    legacy_reference VARCHAR(3),
    effective_from_date DATE NOT NULL DEFAULT '2020-07-01',
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
    created_by VARCHAR(36) NOT NULL,
    created_datetime TIMESTAMPTZ NOT NULL DEFAULT current_timestamp,
    updated_by VARCHAR(36),
    updated_datetime TIMESTAMPTZ,
    concurrency_version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT pk_language PRIMARY KEY (language_uuid)
);