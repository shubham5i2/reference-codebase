--Type Creation for Format Type
DO $$ BEGIN
	CREATE TYPE lpr_owner.format_type AS ENUM
   	('CD', 'PB');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Type Creation for Product Status Type
DO $$ BEGIN
	CREATE TYPE lpr_owner.product_status_type AS ENUM
   	('DRAFT', 'PUBLISHED');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

--Type Creation for Component Type
DO $$ BEGIN
	CREATE TYPE lpr_owner.component_type AS ENUM
   	 ('R', 'L','W','S');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Product Table Creation
CREATE TABLE IF NOT EXISTS lpr_owner.product (
	product_uuid UUID ,
	parent_product_uuid UUID NULL,
	legacy_product_id varchar(24) NULL,
	product_name VARCHAR(100) NOT NULL,
	product_description varchar(1000) NULL,
	module_type_uuid UUID NULL,
	bookable BOOLEAN NOT NULL,
	component lpr_owner.component_type NULL,
	duration INTEGER NULL,
	format lpr_owner.format_type NULL,
	approval_required BOOLEAN NOT NULL,
	available_from_date DATE NOT NULL,
	available_to_date DATE NOT NULL,
	product_status lpr_owner.product_status_type NOT NULL,
	created_by varchar(36) NOT NULL,
	created_datetime timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_by varchar(36) NULL,
	updated_datetime timestamptz NULL,
	concurrency_version INTEGER NOT NULL,
	CONSTRAINT pk_product PRIMARY KEY (product_uuid),
	CONSTRAINT fk_01_product_product FOREIGN KEY (parent_product_uuid) REFERENCES lpr_owner.product (product_uuid),
	CONSTRAINT fk_02_product_module_type FOREIGN KEY (module_type_uuid) REFERENCES lpr_owner.module_type (module_type_uuid)
);
