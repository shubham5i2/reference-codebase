-- Create ENUM Type for location types
DO $$ BEGIN
	CREATE TYPE lpr_owner.location_type AS ENUM
    ('GLOBAL', 'PARTNER', 'REGION', 'COUNTRY', 'TEST_CENTRE', 'VIRTUAL_BUILDING', 'PHYSICAL_BUILDING', 'ROOM');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Create ENUM Type for request types
DO $$ BEGIN
	CREATE TYPE lpr_owner.status_of_request AS ENUM
    ('PENDING', 'APPROVED', 'REJECTED');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Create ENUM Type for location status
DO $$ BEGIN
	CREATE TYPE lpr_owner.location_status AS ENUM
    ('ACTIVE', 'SUSPENDED', 'INACTIVE');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Create Table for location
CREATE TABLE IF NOT EXISTS lpr_owner.location(
    location_uuid UUID,
    parent_location_uuid UUID NULL,
    partner_code VARCHAR(20) NOT NULL,
    test_centre_administrator_uuid UUID NULL,
    external_location_uuid UUID NULL,
    external_parent_location_uuid UUID NULL,
    location_name VARCHAR(300) NOT NULL,
    location_type_code lpr_owner.location_type NOT NULL,
    location_status lpr_owner.location_status NOT NULL,
    location_status_datetime TIMESTAMPTZ NULL,
    eligible_for_offline_testing BOOLEAN NULL,
    test_centre_number VARCHAR(5) NULL,
    request_status lpr_owner.status_of_request NOT NULL,
    timezone_name VARCHAR(100) NULL,
    website_url VARCHAR(100) NULL,
    approved_date DATE NULL,
    created_by varchar(36) NOT NULL,
    created_datetime timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_by varchar(36) NULL,
    updated_datetime timestamptz NULL,
    concurrency_version INTEGER NOT NULL,
    CONSTRAINT pk_location PRIMARY KEY (location_uuid),
    CONSTRAINT fk01_location_location FOREIGN KEY (parent_location_uuid) REFERENCES lpr_owner.location (location_uuid),
    CONSTRAINT fk02_location_partner FOREIGN KEY (partner_code) REFERENCES lpr_owner.partner (partner_code)
);

