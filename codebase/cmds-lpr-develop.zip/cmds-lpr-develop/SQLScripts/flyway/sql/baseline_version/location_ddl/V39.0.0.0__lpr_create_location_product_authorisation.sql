CREATE TABLE IF NOT EXISTS lpr_owner.location_product_authorisation(
    loc_prod_authorisation_uuid UUID,	
    location_uuid UUID NOT NULL,
    product_uuid UUID NOT NULL,
    available_from_date DATE NOT NULL,
    available_to_date DATE NOT NULL DEFAULT '2099-12-31',
    created_by varchar(36) NOT NULL,
    created_datetime timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_by varchar(36) NULL,
    updated_datetime timestamptz NULL,
    concurrency_version INTEGER NOT NULL,
    CONSTRAINT pk_location_product_authorisation PRIMARY KEY (loc_prod_authorisation_uuid),
    CONSTRAINT fk_01_loc_prod_auth_location FOREIGN KEY (location_uuid) REFERENCES lpr_owner.location (location_uuid),
    CONSTRAINT fk_02_loc_prod_auth_product FOREIGN KEY (product_uuid) REFERENCES lpr_owner.product (product_uuid)
);

