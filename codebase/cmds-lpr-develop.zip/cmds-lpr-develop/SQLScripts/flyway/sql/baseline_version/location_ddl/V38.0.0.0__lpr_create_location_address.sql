-- Create Table for location address
CREATE TABLE IF NOT EXISTS lpr_owner.location_address (
    location_address_uuid UUID,
    location_uuid UUID NOT NULL,
    address_type_uuid UUID NOT NULL,
    territory_uuid UUID NOT NULL,
    country_iso3_code VARCHAR(3) NOT NULL,
    address_line_1 VARCHAR(200) NULL,
    address_line_2 VARCHAR(200) NULL,
    address_line_3 VARCHAR(200) NULL,
    address_line_4 VARCHAR(200) NULL,
    city VARCHAR(100) NULL,
    postal_code VARCHAR(25) NULL,
    email VARCHAR(320) NULL,
    primary_phone VARCHAR(15) NULL,
    secondary_phone VARCHAR(15) NULL,
    created_by varchar(36) NOT NULL,
    created_datetime timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_by varchar(36) NULL,
    updated_datetime timestamptz NULL,
    concurrency_version INTEGER NOT NULL,
    CONSTRAINT pk_location_address PRIMARY KEY (location_address_uuid),
    CONSTRAINT fk_01_loc_address_location FOREIGN KEY (location_uuid) REFERENCES lpr_owner.location (location_uuid),
    CONSTRAINT fk_03_loc_address_territory FOREIGN KEY (territory_uuid) REFERENCES lpr_owner.territory (territory_uuid),
    CONSTRAINT fk_02_loc_address_address_type FOREIGN KEY (address_type_uuid) REFERENCES lpr_owner.address_type (address_type_uuid),
    CONSTRAINT fk_04_loc_address_country FOREIGN KEY (country_iso3_code) REFERENCES lpr_owner.country (country_iso3_code)	
);

