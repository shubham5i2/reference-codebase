-- Create Schema for lpr database
CREATE SCHEMA IF NOT EXISTS lpr_owner AUTHORIZATION postgres;

-- Revoke privileges from 'public' role
REVOKE CREATE ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON DATABASE lpr FROM PUBLIC;

-- Read/write role
DO $$
BEGIN
  CREATE ROLE lpr_rw_role
  NOLOGIN
  NOSUPERUSER
  INHERIT
  NOCREATEDB
  NOCREATEROLE
  NOREPLICATION;
  EXCEPTION WHEN DUPLICATE_OBJECT THEN
  RAISE NOTICE 'not creating role lpr_rw_role -- it already exists';
END $$;

GRANT CONNECT ON DATABASE lpr TO lpr_rw_role;
GRANT USAGE ON SCHEMA lpr_owner TO lpr_rw_role;
GRANT SELECT, INSERT, UPDATE  ON ALL TABLES IN SCHEMA lpr_owner TO lpr_rw_role;
ALTER DEFAULT PRIVILEGES IN SCHEMA lpr_owner GRANT SELECT, INSERT, UPDATE ON TABLES TO lpr_rw_role;

-- Create User with login
DO $$
BEGIN
  CREATE USER lpr_user WITH LOGIN PASSWORD 'lpr_user' ;
  EXCEPTION WHEN DUPLICATE_OBJECT THEN
  RAISE NOTICE 'not creating user lpr_user -- it already exists';
END
$$;

-- Grant privileges to users
GRANT lpr_rw_role TO lpr_user;

