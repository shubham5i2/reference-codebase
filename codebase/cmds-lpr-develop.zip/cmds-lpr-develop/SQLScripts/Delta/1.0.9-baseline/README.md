- The script IMOD-23586_insert_results_status_references.sql is related to update the reference data of Results Status, Labels and Comments.
    1. Run the script IMOD-23586_insert_results_status_references.sql.
	
* Validation:
	- In the results_status_label the PENDING_REVIEW relation with UUID: "19bdb4b7-74bc-4f3d-b846-eb4a4e8022e6" should be deleted. 
	- In the results_status_comment table, the count of rows should be 31.
