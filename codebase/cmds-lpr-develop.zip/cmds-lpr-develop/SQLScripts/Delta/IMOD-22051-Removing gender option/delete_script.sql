		
DELETE from lpr_owner.gender where gender_uuid='936338a0-5a3d-447b-83f5-af43ae909ceb';
