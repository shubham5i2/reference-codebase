**Pre-requisites:**


1) The DB/role/user/schema should not be present already so that this will create everything from scratch

**Steps to execute LPR DB Scripts:**

1) Go to cmds-lpr repository in develop branch (https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/-/tree/develop/)

2) Go to SQLScripts folder and download the entire folder (https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/-/tree/develop/SQLScripts)

3) Connect to LPR DB Instance using below command (Provide password when prompted)

    `psql -h <<HOST>> -U postgres`

4) Executing file create_database_ddl.sql will drop existing lpr database and recreate it.This should be one time run.
Please consult Suresh Kanna (kanna.s@cambridgeassessment.org.uk) before executing this script.

    `\i create_database_ddl.sql`

5) Execute ielts_master.sql . This will connect to lpr database and recreate all tables and data if they do not already exist.

    `\i ielts_master.sql`

**Post execution checks:**

1) All 23 tables are created in lpr DB with lpr_owner as schema
2) lpr_user and lpr_rw_role are created
