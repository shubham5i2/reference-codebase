package com.ielts.cmds.integration.factory;

import static com.ielts.cmds.integration.constants.ResultStatusDataWriteCacheConstants.IS_CLUSTER_MODE_ENABLED;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisPooled;
import redis.clients.jedis.UnifiedJedis;
import redis.clients.jedis.exceptions.JedisClusterOperationException;
import redis.clients.jedis.exceptions.JedisConnectionException;
import uk.org.webcompere.systemstubs.environment.EnvironmentVariables;
import uk.org.webcompere.systemstubs.jupiter.SystemStub;
import uk.org.webcompere.systemstubs.jupiter.SystemStubsExtension;


@ExtendWith(MockitoExtension.class)
@ExtendWith(SystemStubsExtension.class)
class JedisFactoryTest {

  @Spy
  @InjectMocks
  private JedisFactory jedisFactory;

  @Mock
  private JedisCluster jedisCluster;

  @Mock
  private UnifiedJedis unifiedJedis;

  @Mock
  private JedisPooled jedisPooled;

  @SystemStub
  private EnvironmentVariables env;

  @Test
  void testGetJedisClusterInstance(){
    doReturn(jedisCluster).when(jedisFactory).getJedisClusterInstance();
    JedisCluster jedisClusterInstance=jedisFactory.getJedisClusterInstance();
    assertNotNull(jedisClusterInstance);
    assertTrue(JedisCluster.class.isAssignableFrom(jedisClusterInstance.getClass()));
  }

  @Test
  void testGetJedisPooledInstance(){
    JedisFactory jedisFactory =new JedisFactory();
    JedisPooled jedisPooledInstance=jedisFactory.getJedisPooledInstance();
    assertNotNull(jedisPooledInstance);
    assertTrue(JedisPooled.class.isAssignableFrom(jedisPooledInstance.getClass()));
  }

  @Test
  void testJedisConnectionExceptionIsThrown_whenGetJedisClusterInstance(){
    doReturn("127.0.0.1").when(jedisFactory).getRedisCacheHost();
    doReturn("7000").when(jedisFactory).getRedisCachePort();
    Executable executable=() -> jedisFactory.getJedisClusterInstance();
    assertThrows(JedisClusterOperationException.class, executable);
  }

  @Test
  void test_whenGetJedisReader_thenReturnJedisClusterCacheWriterInstance() throws JedisConnectionException{
    env.set(IS_CLUSTER_MODE_ENABLED, true);
    doNothing().when(jedisFactory).pingJedisServer(jedisCluster);
    doReturn(jedisCluster).when(jedisFactory).getJedisClusterInstance();
    UnifiedJedis jedisClusterCacheReaderInstance=jedisFactory.getJedisInstance();
    assertTrue(JedisCluster.class.isAssignableFrom(jedisClusterCacheReaderInstance.getClass()));
  }

  @Test
  void test_whenGetJedisReader_thenReturnJedisCacheWriterInstance() throws JedisConnectionException{
    env.set(IS_CLUSTER_MODE_ENABLED, false);
    doNothing().when(jedisFactory).pingJedisServer(jedisPooled);
    doReturn(jedisPooled).when(jedisFactory).getJedisPooledInstance();
    UnifiedJedis jedisCacheReaderInstance=jedisFactory.getJedisInstance();
    assertTrue(JedisPooled.class.isAssignableFrom(jedisCacheReaderInstance.getClass()));
  }

  @Test
  void test_whenGetJedisReader_thenThrowException() throws JedisConnectionException {
    env.set(IS_CLUSTER_MODE_ENABLED, false);
    doThrow(JedisConnectionException.class).when(jedisFactory).pingJedisServer(ArgumentMatchers.any());
    Executable executable = () -> jedisFactory.getJedisInstance();
    // Then
    assertThrows(JedisConnectionException.class, executable);
  }
  @Test
  void test_whenPingJedisServer_thenSuccess() throws JedisConnectionException {
    when(unifiedJedis.ping()).thenReturn("PONG");
    jedisFactory.pingJedisServer(unifiedJedis);
    verify(unifiedJedis).ping();
  }
  @Test
  void test_whenPingJedisServer_thenThrowException() throws JedisConnectionException {
    when(unifiedJedis.ping()).thenReturn("NOT_PONG");
    Executable executable = () ->jedisFactory.pingJedisServer(unifiedJedis);
    assertThrows(JedisConnectionException.class, executable);
  }
}

