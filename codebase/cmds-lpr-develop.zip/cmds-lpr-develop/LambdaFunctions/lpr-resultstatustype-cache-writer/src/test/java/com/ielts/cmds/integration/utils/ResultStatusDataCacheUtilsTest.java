package com.ielts.cmds.integration.utils;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.integration.SQSEventSetup;
import com.ielts.cmds.integration.model.ResultStatusTypeChanged;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

@ExtendWith(MockitoExtension.class)
class ResultStatusDataCacheUtilsTest {

  @InjectMocks
  ResultStatusDataWriteCacheUtils resultStatusDataWriteCacheUtils;

  @BeforeEach
  void setup(){
    HeaderContext headerContext=new HeaderContext();
    headerContext.setEventName("EventName");
    headerContext.setEventDateTime(LocalDateTime.now());
    ThreadLocalHeaderContext.setContext(headerContext);
  }


    @Test
    void whenMapRequestToResultStatusTypeModel_thenResultStatusTypeChanged() {
      ResultStatusTypeChanged expectedResultStatus=SQSEventSetup.getResultStatusTypeChangedModel();
      com.ielts.cmds.api.evt_180.ResultStatusTypeChanged resultStatusTypeChanged=SQSEventSetup.getResultStatusTypeChanged();
      ResultStatusTypeChanged actualResultStatus=resultStatusDataWriteCacheUtils.mapRequestTypeModel(resultStatusTypeChanged);
      Assertions.assertEquals(expectedResultStatus.getResultStatusTypeUuid(), actualResultStatus.getResultStatusTypeUuid());
      Assertions.assertEquals(expectedResultStatus.getName(), actualResultStatus.getName());
      Assertions.assertEquals(expectedResultStatus.getCode(), actualResultStatus.getCode());
      Assertions.assertEquals(expectedResultStatus.getEffectiveToDate(), actualResultStatus.getEffectiveToDate());
      Assertions.assertEquals(expectedResultStatus.getEffectiveFromDate(), actualResultStatus.getEffectiveFromDate());
      for (int i=0; i < expectedResultStatus.getLabels().size(); i++) {
        Assertions.assertEquals(expectedResultStatus.getLabels().get(i).getName(), actualResultStatus.getLabels().get(i).getName());
        Assertions.assertEquals(expectedResultStatus.getLabels().get(i).getCode(), actualResultStatus.getLabels().get(i).getCode());
        Assertions.assertEquals(expectedResultStatus.getLabels().get(i).getLabelUuid(), actualResultStatus.getLabels().get(i).getLabelUuid());
        Assertions.assertEquals(expectedResultStatus.getLabels().get(i).getIsCommentMandatory(), actualResultStatus.getLabels().get(i).getIsCommentMandatory());
        Assertions.assertEquals(expectedResultStatus.getLabels().get(i).getEffectiveToDate(), actualResultStatus.getLabels().get(i).getEffectiveToDate());
        Assertions.assertEquals(expectedResultStatus.getLabels().get(i).getEffectiveFromDate(), actualResultStatus.getLabels().get(i).getEffectiveFromDate());

      }
    }
  }





