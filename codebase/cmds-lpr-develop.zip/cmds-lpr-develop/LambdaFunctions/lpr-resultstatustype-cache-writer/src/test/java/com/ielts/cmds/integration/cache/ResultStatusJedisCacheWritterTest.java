package com.ielts.cmds.integration.cache;

import static com.ielts.cmds.integration.constants.ResultStatusDataWriteCacheConstants.SUCCESS;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.UUID;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.lpr008resultstatustypecachechanged.ResultStatusTypeCacheProcessed;
import com.ielts.cmds.integration.SQSEventSetup;
import com.ielts.cmds.integration.model.ResultStatusTypeChanged;
import com.ielts.cmds.integration.utils.ResultStatusDataWriteCacheUtils;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import redis.clients.jedis.UnifiedJedis;
import redis.clients.jedis.json.Path2;


@ExtendWith(MockitoExtension.class)
class ResultStatusJedisCacheWritterTest {


  @InjectMocks
  private ResultStatusJedisCacheWriter resultStatusJedisCacheWriter;

  @Mock
  private UnifiedJedis unifiedJedis;

  @Mock
  private ResultStatusTypeChanged resultStatusTypeChanged;

  @Mock
  private ResultStatusDataWriteCacheUtils resultStatusDataWriteCacheUtils;

  @BeforeEach
  public void setUp(){
    resultStatusTypeChanged=SQSEventSetup.getResultStatusTypeChangedModel();
    resultStatusJedisCacheWriter=Mockito.spy(new ResultStatusJedisCacheWriter(unifiedJedis, resultStatusDataWriteCacheUtils));
    HeaderContext headerContext=new HeaderContext();
    headerContext.setEventDateTime(LocalDateTime.parse("2024-03-21T21:51:25.628"));
    ThreadLocalHeaderContext.setContext(headerContext);
  }

  @Test
  void whenWriteStatusDataCacheCalled_processCreateDataRefIntoCache() throws JsonProcessingException{
    String refKey=SQSEventSetup.getResultStatusBuildkey();
    when(resultStatusJedisCacheWriter.buildResultDataCacheKey()).thenReturn(refKey);
    resultStatusJedisCacheWriter.writeResultStatusDataToCache(resultStatusTypeChanged);
    verify(resultStatusJedisCacheWriter).processResultStatusCacheRequest(resultStatusTypeChanged);
  }


  @Test
  void whenProcessResultStatusCalled_processUpdateResultCacheIntoRedisCache() throws JsonProcessingException{
     String refKey=SQSEventSetup.getResultStatusBuildkey();
     JSONArray array = new JSONArray();
     array.put(resultStatusTypeChanged.getResultStatusTypeUuid());
     JSONObject jsonObject = new JSONObject();
     jsonObject.put("resultStatusTypeUuid",array);
     String refGetKey = SQSEventSetup.getReferenceDatakey(resultStatusTypeChanged.getResultStatusTypeUuid().toString());
     when(resultStatusJedisCacheWriter.buildResultDataSearchPattern(resultStatusTypeChanged.getResultStatusTypeUuid().toString()))
             .thenReturn(refGetKey);
     when(resultStatusJedisCacheWriter.isResultDataIsUpdatable(any())).thenReturn(true);
     doReturn(jsonObject).when(resultStatusJedisCacheWriter).fetchReferenceDataFromCache(resultStatusTypeChanged,refKey);
     resultStatusJedisCacheWriter.performCacheOperation(refKey, resultStatusTypeChanged);
     verify(resultStatusJedisCacheWriter).updateResultDataIntoCache( resultStatusTypeChanged,refKey);
   }

  @Test
  void whenUpdateResultCacheStatusCalled_processUpdateResultCacheIntoRedisCache() throws JsonProcessingException{
    String refKey=SQSEventSetup.getResultStatusBuildkey();
    JSONArray array = new JSONArray();
    array.put(SQSEventSetup.createJson());
    String refGetKey = SQSEventSetup.getReferenceDatakey(resultStatusTypeChanged.getResultStatusTypeUuid().toString());
    when(resultStatusJedisCacheWriter.buildResultDataSearchPattern(resultStatusTypeChanged.getResultStatusTypeUuid().toString()))
            .thenReturn(refGetKey);
    when(unifiedJedis.jsonGet(anyString(), any(Path2.class))).thenReturn(array);
    when(resultStatusDataWriteCacheUtils.createResultStatusCacheChanged(array)).thenReturn(SQSEventSetup.getResultStatusTypeCacheChanged());
    ResultStatusTypeCacheProcessed resultStatusTypeCacheProcessed= resultStatusJedisCacheWriter.updateResultDataIntoCache( resultStatusTypeChanged,refKey);
    verify(resultStatusJedisCacheWriter).updateResultDataIntoCache( resultStatusTypeChanged,refKey);
    assertEquals(resultStatusTypeCacheProcessed.getCacheData().get(0).getResultStatusTypeUuid(),resultStatusTypeChanged.getResultStatusTypeUuid());
    assertEquals(resultStatusTypeCacheProcessed.getCacheData().get(0).getCode(),resultStatusTypeChanged.getCode());
    assertEquals(resultStatusTypeCacheProcessed.getCacheData().get(0).getEffectiveToDate(),resultStatusTypeChanged.getEffectiveToDate());
    assertEquals(resultStatusTypeCacheProcessed.getCacheData().get(0).getEffectiveFromDate(),resultStatusTypeChanged.getEffectiveFromDate());

  }

  @Test
  void whenInsertRequestResultCacheStatusCalled_processCacheIntoRedisCache() throws JsonProcessingException{
    String refKey=SQSEventSetup.getResultStatusBuildkey();
    JSONArray array = new JSONArray();
    array.put(SQSEventSetup.createJson());
    when(unifiedJedis.jsonGet(anyString(), any(Path2.class))).thenReturn(array);
    when(resultStatusDataWriteCacheUtils.createResultStatusCacheChanged(array)).thenReturn(SQSEventSetup.getResultStatusTypeCacheChanged());
    ResultStatusTypeCacheProcessed resultStatusTypeCacheProcessed= resultStatusJedisCacheWriter.insertResultStatusTypeDataIntoCache( resultStatusTypeChanged,refKey);
    verify(resultStatusJedisCacheWriter).insertResultStatusTypeDataIntoCache( resultStatusTypeChanged,refKey);
    assertEquals(resultStatusTypeCacheProcessed.getCacheData().get(0).getResultStatusTypeUuid(),resultStatusTypeChanged.getResultStatusTypeUuid());
    assertEquals(resultStatusTypeCacheProcessed.getCacheData().get(0).getCode(),resultStatusTypeChanged.getCode());
    assertEquals(resultStatusTypeCacheProcessed.getCacheData().get(0).getEffectiveToDate(),resultStatusTypeChanged.getEffectiveToDate());
    assertEquals(resultStatusTypeCacheProcessed.getCacheData().get(0).getEffectiveFromDate(),resultStatusTypeChanged.getEffectiveFromDate());
  }

  @Test
  void whenProcessResultStatusCalled_processInsertResultStatusTypeIntoRedisCache() throws JsonProcessingException{
    String refKey=SQSEventSetup.getResultStatusBuildkey();
    doReturn(null).when(resultStatusJedisCacheWriter).fetchReferenceDataFromCache(resultStatusTypeChanged,refKey);
    resultStatusJedisCacheWriter.performCacheOperation(refKey, resultStatusTypeChanged);
    verify(resultStatusJedisCacheWriter).insertResultStatusTypeDataIntoCache( resultStatusTypeChanged,refKey);
  }

  @Test
  void whenProcessResultStatusCalled_WithLessEventDateTime_ThenRejectStatusWithIgnored() throws JsonProcessingException{
    String refKey=SQSEventSetup.getResultStatusBuildkey();
    JSONArray array = new JSONArray();
    array.put(resultStatusTypeChanged.getResultStatusTypeUuid());
    JSONObject jsonObject = new JSONObject();
    jsonObject.put("resultStatusTypeUuid",array);
    when(resultStatusJedisCacheWriter.isResultDataIsUpdatable(any())).thenReturn(false);
    doReturn(jsonObject).when(resultStatusJedisCacheWriter).fetchReferenceDataFromCache(resultStatusTypeChanged,refKey);
    when(unifiedJedis.jsonGet(anyString(), any(Path2.class))).thenReturn(array);
    when(resultStatusDataWriteCacheUtils.createResultStatusCacheChanged(array)).thenReturn(SQSEventSetup.getResultStatusTypeCacheChanged());
    ResultStatusTypeCacheProcessed resultStatusTypeCacheProcessed = resultStatusJedisCacheWriter.performCacheOperation(refKey, resultStatusTypeChanged);
    assertEquals("IGNORED", resultStatusTypeCacheProcessed.getStatus());
    assertEquals(resultStatusTypeCacheProcessed.getCacheData().get(0).getResultStatusTypeUuid(),resultStatusTypeChanged.getResultStatusTypeUuid());
    assertEquals(resultStatusTypeCacheProcessed.getCacheData().get(0).getCode(),resultStatusTypeChanged.getCode());
    assertEquals(resultStatusTypeCacheProcessed.getCacheData().get(0).getEffectiveToDate(),resultStatusTypeChanged.getEffectiveToDate());
    assertEquals(resultStatusTypeCacheProcessed.getCacheData().get(0).getEffectiveFromDate(),resultStatusTypeChanged.getEffectiveFromDate());
  }
  @Test
  void createNewReference_dataIntoCache_isCalled_thenReturnResultStatusCacheProcessedEvent() throws JsonProcessingException{
    String refKey=SQSEventSetup.getResultStatusBuildkey();
    ResultStatusTypeCacheProcessed resultStatusTypeCache = new ResultStatusTypeCacheProcessed();
    resultStatusTypeCache.setStatus(SUCCESS);
    resultStatusJedisCacheWriter.getMapperWithProperties().writeValueAsString(resultStatusTypeChanged);
    JSONArray array = new JSONArray();
      array.put(resultStatusTypeChanged.getResultStatusTypeUuid());
      JSONObject jsonObject = new JSONObject();
      jsonObject.put("resultStatusTypeUuid",array);
    when(unifiedJedis.jsonGet(anyString(), any(Path2.class))).thenReturn(array);
    resultStatusJedisCacheWriter.createNewRefDataIntoCache(resultStatusTypeChanged,refKey);
    verify(resultStatusDataWriteCacheUtils).createResultStatusCacheChanged(array);
  }

  @Test
  void when_fetchReferenceData_isCalled_ReturnJsonObject(){
     String refKey=SQSEventSetup.getResultStatusBuildkey();
     JSONArray array = new JSONArray();
     array.put(new JSONObject().put(refKey, resultStatusTypeChanged));
     String searchKey = SQSEventSetup.getReferenceDatakey(resultStatusTypeChanged.getResultStatusTypeUuid().toString());
     when(resultStatusJedisCacheWriter.buildResultDataSearchPattern(resultStatusTypeChanged.getResultStatusTypeUuid().toString())).thenReturn(searchKey);
     when(unifiedJedis.jsonGet(refKey,Path2.of(searchKey))).thenReturn(array);
     JSONObject jsonObject= resultStatusJedisCacheWriter.fetchReferenceDataFromCache(resultStatusTypeChanged,refKey);
     verify(unifiedJedis).jsonGet(refKey,Path2.of(searchKey));
     assertNotNull(jsonObject);
  }

  @Test
  void when_fetchReferenceData_isCalledWithEmpty_ReturnJsonObjectAsNull(){
    String refKey=SQSEventSetup.getResultStatusBuildkey();
    JSONArray array = new JSONArray();
    String searchKey = SQSEventSetup.getReferenceDatakey(resultStatusTypeChanged.getResultStatusTypeUuid().toString());
    when(resultStatusJedisCacheWriter.buildResultDataSearchPattern(resultStatusTypeChanged.getResultStatusTypeUuid().toString())).thenReturn(searchKey);
    when(unifiedJedis.jsonGet(refKey,Path2.of(searchKey))).thenReturn(array);
    JSONObject jsonObject= resultStatusJedisCacheWriter.fetchReferenceDataFromCache(resultStatusTypeChanged,refKey);
    verify(unifiedJedis).jsonGet(refKey,Path2.of(searchKey));
    assertNull(jsonObject);
  }

  @Test
  void isBuildResultStatusDataSearchPatternCalled(){
    String expectedPattern =  SQSEventSetup.getReferenceDatakey(resultStatusTypeChanged.getResultStatusTypeUuid().toString());
    String actualPattern = resultStatusJedisCacheWriter.buildResultDataSearchPattern(resultStatusTypeChanged.getResultStatusTypeUuid().toString());
    assertEquals(expectedPattern,actualPattern);
  }

  @Test
  void isBuildResultDataCacheKeyCalled(){
    String expected = SQSEventSetup.getResultStatusBuildkey();
    String actual =resultStatusJedisCacheWriter.buildResultDataCacheKey();
    assertEquals(expected,actual);
  }

  @Test
  void isResultTableUpdatableIsCalledWhenLastUpdatedDateIsGreater_thenReturnFalse()throws JsonProcessingException{
    JSONObject jsonObject = new JSONObject();
    jsonObject.put("referenceUuid", UUID.randomUUID());
    jsonObject.put("lastUpdatedDatetime", OffsetDateTime.parse("2024-03-23T21:51:25.628Z"));
    boolean refDataRequestUpdatable = resultStatusJedisCacheWriter.isResultDataIsUpdatable(jsonObject);
    assertFalse(refDataRequestUpdatable);
  }
  @Test
  void isResultTableUpdatableIsCalledWhenLastUpdatedDateIsSmaller_thenReturnTrue()throws JsonProcessingException{
    JSONObject jsonObject = new JSONObject();
    jsonObject.put("referenceUuid", UUID.randomUUID());
    jsonObject.put("lastUpdatedDatetime", OffsetDateTime.parse("2024-02-21T22:51:25.628Z"));
    boolean refDataRequestUpdatable = resultStatusJedisCacheWriter.isResultDataIsUpdatable(jsonObject);
    assertTrue(refDataRequestUpdatable);
  }




}
