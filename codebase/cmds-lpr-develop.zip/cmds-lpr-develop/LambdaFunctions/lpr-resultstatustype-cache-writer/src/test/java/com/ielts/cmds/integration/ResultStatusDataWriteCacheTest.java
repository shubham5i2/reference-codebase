package com.ielts.cmds.integration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;

import org.json.JSONArray;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.lpr008resultstatustypecachechanged.ResultStatusTypeCacheProcessed;
import com.ielts.cmds.integration.cache.ResultStatusJedisCacheWriter;
import com.ielts.cmds.integration.model.ResultStatusTypeChanged;
import com.ielts.cmds.integration.utils.ResultStatusDataWriteCacheUtils;
import com.ielts.cmds.serialization.lambda.config.SNSClientConfig;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import redis.clients.jedis.UnifiedJedis;
import redis.clients.jedis.json.Path2;

@ExtendWith(MockitoExtension.class)
class ResultStatusDataWriteCacheTest {

  @InjectMocks
  ResultStatusDataWriteCache resultStatusDataWriteCache;

  @Mock
  ResultStatusJedisCacheWriter resultStatusJedisCacheWriter;

  @Mock
  private ResultStatusDataWriteCacheUtils resultStatusDataWriteCacheUtils;

  @Mock
  private UnifiedJedis jedisInstance;

  private static MockedStatic<SNSClientConfig> snsClientConfig;

  @Mock
  private ResultStatusTypeChanged resultStatusTypeChanged;

  @BeforeAll
  static void init() {
    snsClientConfig = Mockito.mockStatic(SNSClientConfig.class);
  }

  @AfterAll
  static void clear() {
    snsClientConfig.close();
  }


  @BeforeEach
  public void setup() {
    HeaderContext headerContext = new HeaderContext();
    headerContext.setEventDateTime(LocalDateTime.now());
    ThreadLocalHeaderContext.setContext(headerContext);
    resultStatusTypeChanged = SQSEventSetup.getResultStatusTypeChangedModel();
    resultStatusJedisCacheWriter = Mockito.spy(new ResultStatusJedisCacheWriter(jedisInstance,resultStatusDataWriteCacheUtils));
  }

  @Test
  void whenValidateAndProcessResultStatusChangedEventIsCalled_thenReturnResultStatusWithSuccessTypeCacheResponse() throws JsonProcessingException{
    com.ielts.cmds.api.evt_180.ResultStatusTypeChanged resultStatusType = SQSEventSetup.getResultStatusTypeChanged();
    ResultStatusTypeCacheProcessed expectedResultStatusTypeCacheProcessed= SQSEventSetup.getResultStatusTypeCacheChanged();
    ResultStatusTypeCacheProcessed actualResponse = resultStatusDataWriteCache.validateAndProcessResultStatusChangedEvent(resultStatusType);
    assertEquals(actualResponse.getStatus(),expectedResultStatusTypeCacheProcessed.getStatus());
  }

  @Test
  void whenValidateAndProcessResultStatusChangedEventIsCalled_thenReturnResultStatusTypeCacheResponse() throws JsonProcessingException{
    com.ielts.cmds.api.evt_180.ResultStatusTypeChanged resultStatusType = SQSEventSetup.getResultStatusTypeChanged();
    ResultStatusTypeCacheProcessed expectedResultStatusTypeCacheProcessed= SQSEventSetup.getResultStatusTypeCacheChanged();
    when(jedisInstance.exists(SQSEventSetup.getResultStatusBuildkey())).thenReturn(true);
    JSONArray array = new JSONArray();
    array.put(SQSEventSetup.createJson());
    when(jedisInstance.jsonGet(anyString(), any(Path2.class))).thenReturn(array);
    ResultStatusTypeCacheProcessed actualResponse = resultStatusDataWriteCache.processRequest(resultStatusType);
    assertEquals(actualResponse.getStatus(),expectedResultStatusTypeCacheProcessed.getStatus());
    assertEquals(actualResponse.getCacheData().get(0).getResultStatusTypeUuid(),expectedResultStatusTypeCacheProcessed.getCacheData().get(0).getResultStatusTypeUuid());
    assertEquals(actualResponse.getCacheData().get(0).getCode(),expectedResultStatusTypeCacheProcessed.getCacheData().get(0).getCode());
    assertEquals(actualResponse.getCacheData().get(0).getEffectiveFromDate(),expectedResultStatusTypeCacheProcessed.getCacheData().get(0).getEffectiveFromDate());
    assertEquals(actualResponse.getCacheData().get(0).getEffectiveToDate(),expectedResultStatusTypeCacheProcessed.getCacheData().get(0).getEffectiveToDate());
  }




}
