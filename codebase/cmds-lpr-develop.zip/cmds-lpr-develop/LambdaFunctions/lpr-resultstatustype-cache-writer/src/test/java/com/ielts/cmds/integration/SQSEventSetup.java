package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.constants.ResultStatusDataWriteCacheConstants.ALL;
import static com.ielts.cmds.integration.constants.ResultStatusDataWriteCacheConstants.COLON;
import static com.ielts.cmds.integration.constants.ResultStatusDataWriteCacheConstants.REFERENCE;
import static com.ielts.cmds.integration.constants.ResultStatusDataWriteCacheConstants.RESULTSTATUSTYPES;
import static com.ielts.cmds.integration.constants.ResultStatusDataWriteCacheConstants.V1;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.ielts.cmds.api.evt_180.ResultStatusComment;
import com.ielts.cmds.api.evt_180.ResultStatusLabel;
import com.ielts.cmds.api.evt_180.ResultStatusTypeChanged;
import com.ielts.cmds.api.lpr008resultstatustypecachechanged.ResultStatusCommentInner;
import com.ielts.cmds.api.lpr008resultstatustypecachechanged.ResultStatusLabelInner;
import com.ielts.cmds.api.lpr008resultstatustypecachechanged.ResultStatusResponseInner;
import com.ielts.cmds.api.lpr008resultstatustypecachechanged.ResultStatusTypeCacheProcessed;


public class SQSEventSetup {


 public static ResultStatusTypeChanged getResultStatusTypeChanged(){
      ResultStatusTypeChanged resultStatusTypeChanged = new ResultStatusTypeChanged();
      resultStatusTypeChanged.setResultStatusTypeUuid(UUID.fromString("075c25f9-57c7-499c-8c21-43e8d6ae9870"));
      resultStatusTypeChanged.setCode("PENDING_REVIEW");
      resultStatusTypeChanged.setName("Pending Review");
      resultStatusTypeChanged.setEffectiveFromDate(LocalDate.parse("2020-01-01"));
      resultStatusTypeChanged.setEffectiveToDate(LocalDate.parse("2099-12-31"));
      List<ResultStatusLabel> resultStatusLabels = new ArrayList<>();
      ResultStatusLabel resultStatusLabel = new ResultStatusLabel();
      resultStatusLabel.setLabelUuid(UUID.fromString("e1e4808f-3347-4c7e-873e-527002054f2a"));
      resultStatusLabel.setCode("PRE-RELEASE_CHECK_INVESTIGATION");
      resultStatusLabel.setName("Pre-release Check Investigation");
      resultStatusLabel.setEffectiveFromDate(LocalDate.parse("2020-01-01"));
      resultStatusLabel.setEffectiveToDate(LocalDate.parse("2099-12-31"));
      resultStatusLabel.setIsCommentMandatory(true);
      List<ResultStatusComment> resultStatusCommentList = new ArrayList<>();
      ResultStatusComment resultStatusComment = new ResultStatusComment();
      resultStatusComment.setCommentUuid(UUID.fromString("eb63af0b-32af-4fbf-a309-c33873793b32"));
      resultStatusComment.setCode("HIGH_GAINS_REPEARTER_L");
      resultStatusComment.setName("High gains repeater (L)");
      resultStatusComment.setEffectiveFromDate(LocalDate.parse("2020-01-01"));
      resultStatusComment.setEffectiveToDate(LocalDate.parse("2099-12-31"));
      resultStatusCommentList.add(resultStatusComment);
      resultStatusLabel.setComments(resultStatusCommentList);
      resultStatusLabels.add(resultStatusLabel);
      resultStatusTypeChanged.setLabels(resultStatusLabels);
      return resultStatusTypeChanged;
 }

     public static com.ielts.cmds.integration.model.ResultStatusTypeChanged getResultStatusTypeChangedModel(){
          com.ielts.cmds.integration.model.ResultStatusTypeChanged resultStatusTypeChanged = new com.ielts.cmds.integration.model.ResultStatusTypeChanged();
          resultStatusTypeChanged.setResultStatusTypeUuid(UUID.fromString("075c25f9-57c7-499c-8c21-43e8d6ae9870"));
          resultStatusTypeChanged.setCode("PENDING_REVIEW");
          resultStatusTypeChanged.setName("Pending Review");
          resultStatusTypeChanged.setEffectiveFromDate(LocalDate.parse("2020-01-01"));
          resultStatusTypeChanged.setEffectiveToDate(LocalDate.parse("2099-12-31"));
          resultStatusTypeChanged.setLastUpdatedDatetime(OffsetDateTime.now());
          List<com.ielts.cmds.integration.model.ResultStatusLabel> resultStatusLabels = new ArrayList<>();
          com.ielts.cmds.integration.model.ResultStatusLabel resultStatusLabel = new com.ielts.cmds.integration.model.ResultStatusLabel();
          resultStatusLabel.setLabelUuid(UUID.fromString("e1e4808f-3347-4c7e-873e-527002054f2a"));
          resultStatusLabel.setCode("PRE-RELEASE_CHECK_INVESTIGATION");
          resultStatusLabel.setName("Pre-release Check Investigation");
          resultStatusLabel.setEffectiveFromDate(LocalDate.parse("2020-01-01"));
          resultStatusLabel.setEffectiveToDate(LocalDate.parse("2099-12-31"));
          resultStatusLabel.setIsCommentMandatory(true);
          List<com.ielts.cmds.integration.model.ResultStatusComment> resultStatusCommentList = new ArrayList<>();
          com.ielts.cmds.integration.model.ResultStatusComment resultStatusComment = new com.ielts.cmds.integration.model.ResultStatusComment();
          resultStatusComment.setCommentUuid(UUID.fromString("eb63af0b-32af-4fbf-a309-c33873793b32"));
          resultStatusComment.setCode("HIGH_GAINS_REPEARTER_L");
          resultStatusComment.setName("High gains repeater (L)");
          resultStatusComment.setEffectiveFromDate(LocalDate.parse("2020-01-01"));
          resultStatusComment.setEffectiveToDate(LocalDate.parse("2099-12-31"));
          resultStatusCommentList.add(resultStatusComment);
          resultStatusLabel.setComments(resultStatusCommentList);
          resultStatusLabels.add(resultStatusLabel);
          resultStatusTypeChanged.setLabels(resultStatusLabels);
          return resultStatusTypeChanged;
     }

     public static String createJson(){

          return  "[\n" +
                  "    {\n" +
                  "      \"resultStatusTypeUuid\": \"075c25f9-57c7-499c-8c21-43e8d6ae9870\",\n" +
                  "      \"name\": \"Pending Review\",\n" +
                  "      \"code\": \"PENDING_REVIEW\",\n" +
                  "      \"effectiveFromDate\": \"2020-01-01\",\n" +
                  "      \"effectiveToDate\": \"2099-12-31\",\n" +
                  "      \"labels\": [\n" +
                  "        {\n" +
                  "          \"lelUuid\": \"cef4fcb1-2bd2-51f3-889d-abd47d775533\",\n" +
                  "          \"name\": \"PRE-RELEASE_CHECK_INVESTIGATION\",\n" +
                  "          \"code\": \"Pre-release Check Investigation\",\n" +
                  "          \"isCommentMandatory\": true,\n" +
                  "          \"effectiveFromDate\": \"2020-01-01\",\n" +
                  "          \"effectiveToDate\": \"2099-12-31\",\n" +
                  "          \"comments\": [\n" +
                  "            {\n" +
                  "              \"commentUuid\": \"eb63af0b-32af-4fbf-a309-c33873793b32\",\n" +
                  "              \"name\": \"High gains repeater (L)\",\n" +
                  "              \"code\": \"HIGH_GAINS_REPEARTER_L\",\n" +
                  "              \"effectiveFromDate\": \"2020-01-01\",\n" +
                  "              \"effectiveToDate\": \"2099-12-31\"\n" +
                  "            }\n" +
                  "          ]\n" +
                  "        }\n" +
                  "      ]\n" +
                  "    }\n" +
                  "  ]";
     }


     public static ResultStatusTypeCacheProcessed getResultStatusTypeCacheChanged(){
          ResultStatusTypeCacheProcessed resultStatusTypeChanged = new ResultStatusTypeCacheProcessed();
           List<ResultStatusResponseInner> resultStatusResponseInnerList = new ArrayList<>();
          ResultStatusResponseInner resultStatusResponseInner = new ResultStatusResponseInner();
          resultStatusResponseInner.setResultStatusTypeUuid(UUID.fromString("075c25f9-57c7-499c-8c21-43e8d6ae9870"));
          resultStatusResponseInner.setResultStatusTypeUuid(UUID.fromString("075c25f9-57c7-499c-8c21-43e8d6ae9870"));
          resultStatusResponseInner.setCode("PENDING_REVIEW");
          resultStatusResponseInner.setName("Pending Review");
          resultStatusResponseInner.setEffectiveFromDate(LocalDate.parse("2020-01-01"));
          resultStatusResponseInner.setEffectiveToDate(LocalDate.parse("2099-12-31"));
          List<ResultStatusLabelInner> resultStatusLabels = new ArrayList<>();
          ResultStatusLabelInner resultStatusLabel = new ResultStatusLabelInner();
          resultStatusLabel.setLabelUuid(UUID.fromString("e1e4808f-3347-4c7e-873e-527002054f2a"));
          resultStatusLabel.setCode("PRE-RELEASE_CHECK_INVESTIGATION");
          resultStatusLabel.setName("Pre-release Check Investigation");
          resultStatusLabel.setEffectiveFromDate(LocalDate.parse("2020-01-01"));
          resultStatusLabel.setEffectiveToDate(LocalDate.parse("2099-12-31"));
          resultStatusLabel.setIsCommentMandatory(true);
          List<ResultStatusCommentInner> resultStatusCommentList = new ArrayList<>();
          ResultStatusCommentInner resultStatusComment = new ResultStatusCommentInner();
          resultStatusComment.setCommentUuid(UUID.fromString("eb63af0b-32af-4fbf-a309-c33873793b32"));
          resultStatusComment.setCode("HIGH_GAINS_REPEARTER_L");
          resultStatusComment.setName("High gains repeater (L)");
          resultStatusComment.setEffectiveFromDate(LocalDate.parse("2020-01-01"));
          resultStatusComment.setEffectiveToDate(LocalDate.parse("2099-12-31"));
          resultStatusCommentList.add(resultStatusComment);
          resultStatusLabel.setComments(resultStatusCommentList);
          resultStatusLabels.add(resultStatusLabel);
          resultStatusResponseInner.setLabels(resultStatusLabels);
          resultStatusResponseInnerList.add(resultStatusResponseInner);
          resultStatusTypeChanged.setCacheData(resultStatusResponseInnerList);
          resultStatusTypeChanged.setStatus("SUCCESS");
          return resultStatusTypeChanged;
     }

     public static String getResultStatusBuildkey(){
          return String.join(COLON, REFERENCE, RESULTSTATUSTYPES, V1, ALL);
     }

     public static String getReferenceDatakey(String refUuid) {
          return "$.[?(@." + "resultStatusTypeUuid" + "==" + "'" + refUuid + "'" + ")" + "]";
     }
}