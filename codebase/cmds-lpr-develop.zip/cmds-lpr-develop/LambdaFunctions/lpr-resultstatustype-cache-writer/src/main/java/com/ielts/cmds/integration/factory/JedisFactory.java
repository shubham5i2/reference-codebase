package com.ielts.cmds.integration.factory;

import static com.ielts.cmds.integration.constants.ResultStatusDataWriteCacheConstants.PONG;

import java.net.URI;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import com.ielts.cmds.integration.constants.ResultStatusDataWriteCacheConstants;

import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.DefaultJedisClientConfig;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisPooled;
import redis.clients.jedis.UnifiedJedis;
import redis.clients.jedis.exceptions.JedisConnectionException;
@Slf4j
public class JedisFactory {

	public String getRedisCacheHost() {
		return System.getenv(ResultStatusDataWriteCacheConstants.REDIS_ELASTICACHE_HOST);
	}

	public String getRedisCachePort() {
		return Optional.ofNullable(System.getenv(ResultStatusDataWriteCacheConstants.REDIS_ELASTICACHE_PORT))
				.orElse(ResultStatusDataWriteCacheConstants.DEFAULT_REDIS_ELASTIC_CACHE_PORT);
	}
	
	public boolean isClusterModeEnabled() {
		String isClusterModeEnabled = System.getenv(ResultStatusDataWriteCacheConstants.IS_CLUSTER_MODE_ENABLED);
		return Boolean.valueOf(isClusterModeEnabled);
	}

	public JedisCluster getJedisClusterInstance() {
		Set<HostAndPort> jedisClusterNodes = new HashSet<>();
		jedisClusterNodes.add(new HostAndPort(getRedisCacheHost(), Integer.parseInt(getRedisCachePort())));
		return new JedisCluster(jedisClusterNodes, DefaultJedisClientConfig.builder().ssl(true).build());
	}

	public JedisPooled getJedisPooledInstance() {
		String redisEndpointUrl = getRedisCacheHost() + ":" + getRedisCachePort();
		return new JedisPooled(URI.create("rediss://" + redisEndpointUrl));
	}

	public UnifiedJedis getJedisInstance() throws JedisConnectionException {
		boolean isClusterModeEnabled = isClusterModeEnabled();
		UnifiedJedis jedisInstance;
		if (isClusterModeEnabled) {
			jedisInstance = getJedisClusterInstance();
		} else {
			jedisInstance = getJedisPooledInstance();
		}
		pingJedisServer(jedisInstance);
		return jedisInstance;
	}

	public void pingJedisServer(UnifiedJedis jedisInstance) throws JedisConnectionException {
		String pingResult=jedisInstance.ping();
		if (pingResult.equalsIgnoreCase(PONG)) {
			log.debug("Elasticache Redis reachable");
		} else {
			log.error("Elasticache Redis Unreachable");
			throw new JedisConnectionException("Elasticache Redis Unreachable");
		}
	}
}
