package com.ielts.cmds.integration.utils;

import static com.ielts.cmds.integration.constants.ResultStatusDataWriteCacheConstants.SUCCESS;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.json.JSONArray;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.ielts.cmds.api.evt_180.ResultStatusTypeChanged;
import com.ielts.cmds.api.lpr008resultstatustypecachechanged.ResultStatusResponseInner;
import com.ielts.cmds.api.lpr008resultstatustypecachechanged.ResultStatusTypeCacheProcessed;
import com.ielts.cmds.serialization.lambda.mapper.IObjectMapper;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ResultStatusDataWriteCacheUtils implements IObjectMapper {


	public com.ielts.cmds.integration.model.ResultStatusTypeChanged mapRequestTypeModel(ResultStatusTypeChanged resultStatusTypeChanged){
		com.ielts.cmds.integration.model.ResultStatusTypeChanged resultStatusTypeChanged1 = ResultStatusTypeMapper.INSTANCE.convertToModel(resultStatusTypeChanged);
		resultStatusTypeChanged1.setLastUpdatedDatetime(OffsetDateTime.of(ThreadLocalHeaderContext.getContext().getEventDateTime(), ZoneOffset.UTC));
		return resultStatusTypeChanged1;
	}


	public void buildHeader(String eventName) {
		HeaderContext headerContext = ThreadLocalHeaderContext.getContext();
		headerContext.setEventDateTime(LocalDateTime.now());
		headerContext.setEventName(eventName);
		ThreadLocalHeaderContext.setContext(headerContext);
	}

	public ResultStatusTypeCacheProcessed createResultStatusCacheChanged(JSONArray resultsData) throws JsonProcessingException{
		ResultStatusTypeCacheProcessed resultStatusTypeCacheChanged = new ResultStatusTypeCacheProcessed();
		List<ResultStatusResponseInner> resultStatusResponseInners = convertTheDataToCacheFormat(resultsData);
		resultStatusTypeCacheChanged.setCacheData(resultStatusResponseInners);
		resultStatusTypeCacheChanged.setStatus(SUCCESS);
		return resultStatusTypeCacheChanged;
	}

   public List<ResultStatusResponseInner> convertTheDataToCacheFormat(JSONArray cacheResponse) throws JsonProcessingException {
	    if(Objects.nonNull(cacheResponse)) {
		  log.debug("Cache Response: {}", cacheResponse);
		  log.debug("Cache Response Size: {}", cacheResponse.length());
			CollectionType typReference =
							TypeFactory.defaultInstance()
											.constructCollectionType(List.class, ResultStatusResponseInner.class);

			return getMapperWithProperties().readValue(cacheResponse.get(0).toString(), typReference);
	}
	 return new ArrayList<>();
   }


}
