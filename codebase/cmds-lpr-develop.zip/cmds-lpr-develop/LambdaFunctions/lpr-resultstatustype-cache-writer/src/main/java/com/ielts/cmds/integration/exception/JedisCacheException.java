package com.ielts.cmds.integration.exception;

public class JedisCacheException extends Exception{

  public JedisCacheException(String message) {
    super(message);
  }
}
