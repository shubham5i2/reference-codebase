package com.ielts.cmds.integration.constants;

public class ResultStatusDataWriteCacheConstants {

	private ResultStatusDataWriteCacheConstants() {
	}

	public static final String RESULTSTATUSTYPE_CACHE_CHANGED_EVENT_NAME = "ResultStatusTypeCacheProcessed";
	public static final String REDIS_ELASTICACHE_HOST = "redis_elasticache_host";
	public static final String REDIS_ELASTICACHE_PORT = "redis_elasticache_port";
	public static final String IS_CLUSTER_MODE_ENABLED = "is_cluster_mode_enabled";
	public static final String DEFAULT_REDIS_ELASTIC_CACHE_PORT = "6379";
	public static final String LPR_TOPIC_OUT_ARN = "ResultStatusTypeCacheProcessedV1_topic_out_arn";
	public static final String PONG = "pong";
	public static final String COLON = ":";
	public static final String V1 = "v1";
	public static final String ALL = "all";
	public static final String EQUALSTO= "=";
	public static final String REFERENCE ="reference";

	public  static final String RESULTSTATUSTYPES = "resultStatusType";

	public static final String JEDIS_SEARCH_PREFIX_PATTERN = "$.[?(@.";

	public static final String RESULT_STATUS_TYPE_DATA_UUID = "resultStatusTypeUuid";

	public static final String DOLLAR = "$";

	public static final String IGNORED = "IGNORED";

	public static final String SUCCESS = "SUCCESS";


}
