package com.ielts.cmds.integration.cache;

import static com.ielts.cmds.integration.constants.ResultStatusDataWriteCacheConstants.ALL;
import static com.ielts.cmds.integration.constants.ResultStatusDataWriteCacheConstants.COLON;
import static com.ielts.cmds.integration.constants.ResultStatusDataWriteCacheConstants.DOLLAR;
import static com.ielts.cmds.integration.constants.ResultStatusDataWriteCacheConstants.EQUALSTO;
import static com.ielts.cmds.integration.constants.ResultStatusDataWriteCacheConstants.IGNORED;
import static com.ielts.cmds.integration.constants.ResultStatusDataWriteCacheConstants.JEDIS_SEARCH_PREFIX_PATTERN;
import static com.ielts.cmds.integration.constants.ResultStatusDataWriteCacheConstants.REFERENCE;
import static com.ielts.cmds.integration.constants.ResultStatusDataWriteCacheConstants.RESULTSTATUSTYPES;
import static com.ielts.cmds.integration.constants.ResultStatusDataWriteCacheConstants.RESULT_STATUS_TYPE_DATA_UUID;
import static com.ielts.cmds.integration.constants.ResultStatusDataWriteCacheConstants.V1;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.lpr008resultstatustypecachechanged.ResultStatusTypeCacheProcessed;
import com.ielts.cmds.integration.model.ResultStatusTypeChanged;
import com.ielts.cmds.integration.utils.ResultStatusDataWriteCacheUtils;
import com.ielts.cmds.serialization.lambda.mapper.IObjectMapper;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.UnifiedJedis;
import redis.clients.jedis.json.Path2;
@Slf4j
public class ResultStatusJedisCacheWriter implements IObjectMapper {


  private UnifiedJedis jedisInstance;

  private final ResultStatusDataWriteCacheUtils resultStatusDataWriteCacheUtils;

  public ResultStatusJedisCacheWriter(UnifiedJedis jedisInstance, ResultStatusDataWriteCacheUtils resultStatusDataWriteCacheUtils){
    this.jedisInstance=jedisInstance;
    this.resultStatusDataWriteCacheUtils=resultStatusDataWriteCacheUtils;
  }

  public ResultStatusTypeCacheProcessed writeResultStatusDataToCache(ResultStatusTypeChanged resultStatusTypeChanged) throws JsonProcessingException{
    return processResultStatusCacheRequest(resultStatusTypeChanged);
  }

  protected ResultStatusTypeCacheProcessed processResultStatusCacheRequest(ResultStatusTypeChanged resultStatusTypeChanged) throws  JsonProcessingException{
    //example of key : reference:resultStatusTypes:v1:all
    String refKey=buildResultDataCacheKey();
    boolean isRefKeyExists=jedisInstance.exists(refKey);
    if (isRefKeyExists) {
      return performCacheOperation(refKey, resultStatusTypeChanged);
    } else {
      return createNewRefDataIntoCache(resultStatusTypeChanged, refKey);
    }
  }

  protected ResultStatusTypeCacheProcessed performCacheOperation(final String refKey, final ResultStatusTypeChanged resultStatusTypeChanged) throws JsonProcessingException{
    JSONObject resultStatusObject=fetchReferenceDataFromCache(resultStatusTypeChanged, refKey);
    boolean isResultStatusDataRequestUpdatable=Objects.nonNull(resultStatusObject)&& isResultDataIsUpdatable(resultStatusObject);
    log.debug("isResultDataRequestUpdatable {}", isResultStatusDataRequestUpdatable);
    if (!Objects.nonNull(resultStatusObject)) {
      return insertResultStatusTypeDataIntoCache(resultStatusTypeChanged, refKey);
    } else if (isResultStatusDataRequestUpdatable) {
      return updateResultDataIntoCache(resultStatusTypeChanged, refKey);
    } else {
      JSONArray entireData=(JSONArray) jedisInstance.jsonGet(buildResultDataCacheKey(), Path2.of("$"));
      ResultStatusTypeCacheProcessed resultStatusTypeCacheChanged = resultStatusDataWriteCacheUtils.createResultStatusCacheChanged(entireData);
      resultStatusTypeCacheChanged.setStatus(IGNORED);
      return resultStatusTypeCacheChanged;
    }

  }

  protected ResultStatusTypeCacheProcessed createNewRefDataIntoCache(ResultStatusTypeChanged resultStatusTypeChanged, String refDataCacheKey) throws JsonProcessingException{
    log.debug("creating ref data first time in cache....");
    List<ResultStatusTypeChanged> resultStatusTypeCacheList=new ArrayList<>();
    resultStatusTypeCacheList.add(resultStatusTypeChanged);
    String resultStatusTypeCacheListStr=getMapperWithProperties().writeValueAsString(resultStatusTypeCacheList);
    jedisInstance.jsonSet(refDataCacheKey, resultStatusTypeCacheListStr);
    JSONArray entireData=(JSONArray) jedisInstance.jsonGet(buildResultDataCacheKey(), Path2.of("$"));
    return resultStatusDataWriteCacheUtils.createResultStatusCacheChanged(entireData);
  }

  protected JSONObject fetchReferenceDataFromCache(ResultStatusTypeChanged resultStatusTypeChanged, String refDataCacheKey){
    //  Sample search pattern $.[?(@.attributeKey=='value')]
    String searchPattern=buildResultDataSearchPattern(resultStatusTypeChanged.getResultStatusTypeUuid().toString());
//	casting cache response as it is stored in array
    JSONArray refData=(JSONArray) jedisInstance.jsonGet(refDataCacheKey, Path2.of(searchPattern));
    return refData.optJSONObject(0);
  }

  public String buildResultDataCacheKey(){
    return String.join(COLON, REFERENCE, RESULTSTATUSTYPES, V1, ALL);
  }

  public boolean isResultDataIsUpdatable(final JSONObject refData) throws JsonProcessingException{
    if(refData!= null) {
      OffsetDateTime eventDateTime=OffsetDateTime.of(ThreadLocalHeaderContext.getContext().getEventDateTime(), ZoneOffset.UTC);
      ResultStatusTypeChanged resultStatusTypeChanged=getMapperWithProperties().readValue(refData.toString(), ResultStatusTypeChanged.class);
      return resultStatusTypeChanged.getLastUpdatedDatetime().isBefore(eventDateTime);
    }else {
      return false;
    }
  }

  public String buildResultDataSearchPattern(String resultStatusTypeUuid){
    ///Sample search pattern $.[?(@.attributeKey=='value')]
    return JEDIS_SEARCH_PREFIX_PATTERN.concat(RESULT_STATUS_TYPE_DATA_UUID).concat(EQUALSTO).concat(EQUALSTO).concat("'").concat(resultStatusTypeUuid).concat("'").concat(")").concat("]");
  }

  protected ResultStatusTypeCacheProcessed insertResultStatusTypeDataIntoCache(final ResultStatusTypeChanged resultStatusTypeCacheChanged, String refKey) throws JsonProcessingException{
    log.debug("inserting new record into existing result status type....");
    String referenceDataStr=getMapperWithProperties().writeValueAsString(resultStatusTypeCacheChanged);
    jedisInstance.jsonArrAppend(refKey, Path2.of(DOLLAR), referenceDataStr);
    JSONArray entireData=(JSONArray) jedisInstance.jsonGet(buildResultDataCacheKey(), Path2.of("$"));
    return resultStatusDataWriteCacheUtils.createResultStatusCacheChanged(entireData);
  }


  protected ResultStatusTypeCacheProcessed updateResultDataIntoCache(final ResultStatusTypeChanged resultStatusTypeCacheChanged, String refKey) throws JsonProcessingException{
    log.debug("update existing record into existing result status type....");
    String refDataSearchPattern=buildResultDataSearchPattern(resultStatusTypeCacheChanged.getResultStatusTypeUuid().toString());
    String referenceDataCacheStr=getMapperWithProperties().writeValueAsString(resultStatusTypeCacheChanged);
    jedisInstance.jsonSet(refKey, Path2.of(refDataSearchPattern), referenceDataCacheStr);
    JSONArray entireData=(JSONArray) jedisInstance.jsonGet(buildResultDataCacheKey(), Path2.of("$"));
    return resultStatusDataWriteCacheUtils.createResultStatusCacheChanged(entireData);
  }

}

