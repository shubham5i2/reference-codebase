package com.ielts.cmds.integration.model;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
public class ResultStatusLabel {
  private UUID labelUuid;
  private String code;
  private String name;
  private Boolean isCommentMandatory;
  private LocalDate effectiveFromDate;
  private LocalDate effectiveToDate;
  private List<ResultStatusComment> comments = null;
}
