package com.ielts.cmds.integration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.evt_180.ResultStatusTypeChanged;
import com.ielts.cmds.api.lpr008resultstatustypecachechanged.ResultStatusTypeCacheProcessed;
import com.ielts.cmds.integration.cache.ResultStatusJedisCacheWriter;
import com.ielts.cmds.integration.constants.ResultStatusDataWriteCacheConstants;
import com.ielts.cmds.integration.factory.JedisFactory;
import com.ielts.cmds.integration.utils.ResultStatusDataWriteCacheUtils;
import com.ielts.cmds.serialization.lambda.AbstractLambda;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.UnifiedJedis;
/**
 * @author cts
 */
@Slf4j
public class ResultStatusDataWriteCache extends AbstractLambda<ResultStatusTypeChanged, ResultStatusTypeCacheProcessed> {

  private ResultStatusDataWriteCacheUtils resultStatusDataWriteCacheUtils=getInstanceOfUtils();

  private UnifiedJedis jedisInstance;

  private JedisFactory jedisFactory=new JedisFactory();

  public ResultStatusDataWriteCache(){
    jedisInstance=jedisFactory.getJedisInstance();
  }

  public ResultStatusDataWriteCache(UnifiedJedis jedisInstance){
    this.jedisInstance=jedisInstance;
  }

  private ResultStatusDataWriteCacheUtils getInstanceOfUtils(){
    return new ResultStatusDataWriteCacheUtils();
  }

  /**
   * Process Request is default method of lambda class.This method will get
   * invoked when distributor queue message and process the message.
   *
   * @param resultStatusTypeChanged
   */
  @SneakyThrows
  @Override
  protected ResultStatusTypeCacheProcessed processRequest(ResultStatusTypeChanged resultStatusTypeChanged){
    return validateAndProcessResultStatusChangedEvent(resultStatusTypeChanged);
  }

  public ResultStatusTypeCacheProcessed validateAndProcessResultStatusChangedEvent(ResultStatusTypeChanged resultStatusTypeChanged) throws JsonProcessingException{
    com.ielts.cmds.integration.model.ResultStatusTypeChanged modelResultStatusTypeChanged=resultStatusDataWriteCacheUtils.mapRequestTypeModel(resultStatusTypeChanged);
    ResultStatusJedisCacheWriter resultStatusJedisCacheWriter=getResultCacheWriterInstance(jedisInstance);
    ResultStatusTypeCacheProcessed response= resultStatusJedisCacheWriter.writeResultStatusDataToCache(modelResultStatusTypeChanged);
    resultStatusDataWriteCacheUtils.buildHeader(ResultStatusDataWriteCacheConstants.RESULTSTATUSTYPE_CACHE_CHANGED_EVENT_NAME);

    log.info("Write Operation Done for {} {} and Published Event", ResultStatusDataWriteCacheConstants.RESULTSTATUSTYPE_CACHE_CHANGED_EVENT_NAME, resultStatusTypeChanged.getResultStatusTypeUuid());
    return response;
  }

  public ResultStatusJedisCacheWriter getResultCacheWriterInstance(UnifiedJedis jedisInstance){
    return new ResultStatusJedisCacheWriter(jedisInstance, resultStatusDataWriteCacheUtils);
  }


  @Override
  protected String getTopicName(){
    return System.getenv(ResultStatusDataWriteCacheConstants.LPR_TOPIC_OUT_ARN);
  }

}
