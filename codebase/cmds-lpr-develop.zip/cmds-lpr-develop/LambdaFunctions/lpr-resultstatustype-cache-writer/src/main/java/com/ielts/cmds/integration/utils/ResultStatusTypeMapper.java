package com.ielts.cmds.integration.utils;

import com.ielts.cmds.api.evt_180.ResultStatusTypeChanged;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ResultStatusTypeMapper {
    ResultStatusTypeMapper INSTANCE = Mappers.getMapper(ResultStatusTypeMapper.class);

    @Mapping(target = "lastUpdatedDatetime", ignore = true)
    com.ielts.cmds.integration.model.ResultStatusTypeChanged convertToModel(ResultStatusTypeChanged source);

}


