package com.ielts.cmds.integration.model;


import java.time.LocalDate;
import java.util.UUID;

import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
public class ResultStatusComment {
    private UUID commentUuid;

    private String code;

    private String name;

    private LocalDate effectiveFromDate;

    private LocalDate effectiveToDate;
}
