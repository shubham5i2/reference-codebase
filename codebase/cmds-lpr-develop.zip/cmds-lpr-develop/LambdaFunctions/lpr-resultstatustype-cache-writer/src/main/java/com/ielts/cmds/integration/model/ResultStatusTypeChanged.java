package com.ielts.cmds.integration.model;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
public class ResultStatusTypeChanged {
        private UUID resultStatusTypeUuid;
        private String code;
        private String name;
        private LocalDate effectiveFromDate;
        private LocalDate effectiveToDate;
        //this needs to be added in the cache store to validate the lastUpdatedDatetime
        private OffsetDateTime lastUpdatedDatetime;
        private List<ResultStatusLabel> labels = null;
}
