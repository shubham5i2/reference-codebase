package com.ielts.cmds.integration.utils;

import com.ielts.cmds.api.lpr001countryterritorycachechanged.CountryTerritoryCacheV1;
import com.ielts.cmds.integration.model.CountryV1;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;

import static com.ielts.cmds.integration.SQSEventSetup.getCountryV1DataForTest;
import static com.ielts.cmds.integration.SQSEventSetup.getEvt184CountryV1DataForTest;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class CountryTerritoryCacheWriterUtilsTest {

    @InjectMocks
    private CountryTerritoryCacheWriterUtils countryTerritoryCacheWriterUtils;

    @BeforeEach
    void setup() {
        HeaderContext headerContext = new HeaderContext();
        headerContext.setEventDateTime(LocalDateTime.now());
        ThreadLocalHeaderContext.setContext(headerContext);
    }

    @Test
    void whenMapInComingRequestToCountryModel_thenReturnCountryChangedDto() {
        CountryV1 expected = getCountryV1DataForTest();
        com.ielts.cmds.api.evt_184.CountryV1 evt184CountryV1DataEventForTest = getEvt184CountryV1DataForTest();
        CountryV1 actual = countryTerritoryCacheWriterUtils.mapIncomingRequestToDto(evt184CountryV1DataEventForTest);
        assertEquals(expected.getCountryUuid(), actual.getCountryUuid());
        assertEquals(expected.getName(), actual.getName());
        assertEquals(expected.getIso3Code(), actual.getIso3Code());
        assertEquals(expected.getEffectiveFromDate(), actual.getEffectiveFromDate());
        assertEquals(expected.getEffectiveToDate(), actual.getEffectiveToDate());
    }

    @Test
    void whenIncomingCountryTerritoryCacheReceived_ThenReturnCountryTerritoryCacheChangedResponse() {
        CountryV1 expected = getCountryV1DataForTest();
        CountryTerritoryCacheV1 actual = countryTerritoryCacheWriterUtils.buildCountryTerritoryCacheChangedResponse(expected);
        assertEquals(expected.getCountryUuid(), actual.getCountry().getCountryUuid());
        assertEquals(expected.getName(), actual.getCountry().getName());
        assertEquals(expected.getEffectiveFromDate(), actual.getCountry().getEffectiveFromDate());
        assertEquals(expected.getEffectiveToDate(), actual.getCountry().getEffectiveToDate());
        assertEquals(expected.getTerritories().get(0).getTerritoryUuid(), actual.getTerritories().get(0).getTerritoryUuid());
        assertEquals(expected.getTerritories().get(0).getName(), actual.getTerritories().get(0).getName());
        assertEquals(expected.getTerritories().get(0).getEffectiveFromDate(), actual.getTerritories().get(0).getEffectiveFromDate());
        assertEquals(expected.getTerritories().get(0).getEffectiveToDate(), actual.getTerritories().get(0).getEffectiveToDate());
    }
}
