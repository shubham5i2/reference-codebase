package com.ielts.cmds.integration;

import com.ielts.cmds.api.evt_184.CountryV1;
import com.ielts.cmds.api.lpr001countryterritorycachechanged.CountryTerritoryCacheV1;
import com.ielts.cmds.integration.cache.CountryTerritoryJedisWriter;
import com.ielts.cmds.integration.utils.CountryTerritoryCacheWriterUtils;
import com.ielts.cmds.serialization.lambda.config.SNSClientConfig;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.Mock;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import redis.clients.jedis.UnifiedJedis;

import java.time.LocalDateTime;

import static com.ielts.cmds.integration.SQSEventSetup.getEvt184CountryV1DataForTest;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class CountryTerritoryCacheWriterTest {

    @InjectMocks
    private CountryTerritoryCacheWriter countryTerritoryCacheWriter;

    @Mock
    private CountryTerritoryJedisWriter jedisCacheWriter;

    @Spy
    private CountryTerritoryCacheWriterUtils countryTerritoryCacheWriterUtils;

    @Mock
    private UnifiedJedis jedisInstance;

    private static MockedStatic<SNSClientConfig> snsClientConfig;

    @BeforeAll
    static void init() {
        snsClientConfig = Mockito.mockStatic(SNSClientConfig.class);
    }

    @AfterAll
    static void clear() {
        snsClientConfig.close();
    }

    @BeforeEach
    public void setup() {
        HeaderContext headerContext = new HeaderContext();
        headerContext.setEventDateTime(LocalDateTime.now());
        ThreadLocalHeaderContext.setContext(headerContext);
        jedisCacheWriter = Mockito.spy(new CountryTerritoryJedisWriter(jedisInstance));
        countryTerritoryCacheWriter = Mockito.spy(new CountryTerritoryCacheWriter(jedisInstance));
    }

    @Test
    void whenSectorTypeRefRequestedThenVerifyWriteCallToCache() {
        CountryV1 expected = getEvt184CountryV1DataForTest();
        CountryTerritoryCacheV1 actual = countryTerritoryCacheWriter.processRequest(expected);
        assertEquals(expected.getName(), actual.getCountry().getName());
        assertEquals(expected.getEffectiveFromDate(), actual.getCountry().getEffectiveFromDate());
        assertEquals(expected.getEffectiveToDate(), actual.getCountry().getEffectiveToDate());
        assertEquals(expected.getTerritories().get(0).getTerritoryUuid(), actual.getTerritories().get(0).getTerritoryUuid());
        assertEquals(expected.getTerritories().get(0).getName(), actual.getTerritories().get(0).getName());
        assertEquals(expected.getTerritories().get(0).getEffectiveFromDate(), actual.getTerritories().get(0).getEffectiveFromDate());
        assertEquals(expected.getTerritories().get(0).getEffectiveToDate(), actual.getTerritories().get(0).getEffectiveToDate());
    }
}
