package com.ielts.cmds.integration.cache;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.SQSEventSetup;
import com.ielts.cmds.integration.exception.InvalidCacheDataException;
import com.ielts.cmds.integration.model.CountryV1;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import redis.clients.jedis.UnifiedJedis;
import redis.clients.jedis.json.Path2;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.UUID;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class CountryTerritoryJedisWriterTest {

    @InjectMocks
    private CountryTerritoryJedisWriter jedisCacheWriter;

    @Mock
    private UnifiedJedis jedisInstance;

    private CountryV1 event;

    @BeforeEach
    public void setUp() {
        event = SQSEventSetup.getCountryV1DataForTest();
        jedisCacheWriter = Mockito.spy(new CountryTerritoryJedisWriter(jedisInstance));
        HeaderContext headerContext = new HeaderContext();
        headerContext.setEventDateTime(LocalDateTime.parse("2024-02-21T21:51:25"));
        ThreadLocalHeaderContext.setContext(headerContext);
    }

    @Test
    void whenCountryTerritoryKeyDoesNotExistsInCache_thenCreateNewDataInCache() throws JsonProcessingException, InvalidCacheDataException {
        jedisCacheWriter.writeCountryTerritoryDataToCache(event);
        verify(jedisCacheWriter, times(1)).createNewCountryDataIntoCache(ArgumentMatchers.any(), ArgumentMatchers.any());
        verify(jedisCacheWriter, times(1)).createNewTerritoryDataIntoCache(ArgumentMatchers.any(), ArgumentMatchers.any());
    }

    @Test
    void whenCountryAndTerritoryKeyExistsInCache_AndJsonArrayIsNull_thenPerformInsertOperationOnCountryTerritoryData() throws JsonProcessingException, InvalidCacheDataException {
        JSONArray jsonArray = new JSONArray();

        when(jedisInstance.exists(ArgumentMatchers.anyString())).thenReturn(true);
        when(jedisInstance.jsonGet(ArgumentMatchers.anyString(), ArgumentMatchers.any(Path2.class))).thenReturn(jsonArray);

        jedisCacheWriter.writeCountryTerritoryDataToCache(event);
        verify(jedisCacheWriter, times(0)).createNewCountryDataIntoCache(ArgumentMatchers.any(), ArgumentMatchers.any());
        verify(jedisCacheWriter, times(1)).insertCountryDataIntoCache(ArgumentMatchers.any(), ArgumentMatchers.any());
        verify(jedisCacheWriter, times(1)).performCacheOperationOnCountryData(ArgumentMatchers.any(), ArgumentMatchers.any());
        verify(jedisCacheWriter, times(0)).updateTerritoryDataIntoCache(ArgumentMatchers.any(), ArgumentMatchers.any());
        verify(jedisCacheWriter, times(0)).createNewTerritoryDataIntoCache(ArgumentMatchers.any(), ArgumentMatchers.any());
        verify(jedisCacheWriter, times(2)).insertTerritoryDataIntoCache(ArgumentMatchers.any(), ArgumentMatchers.any());
        verify(jedisCacheWriter, times(2)).performCacheOperationOnTerritoryData(ArgumentMatchers.any(), ArgumentMatchers.any());
        verify(jedisCacheWriter, times(0)).updateCountryDataIntoCache(ArgumentMatchers.any(), ArgumentMatchers.any());
    }

    @Test
    void whenCountryAndTerritoryKeyExistsInCache_AndJsonArrayIsNotNull_thenPerformUpdateOperationOnCountryTerritoryData() throws JsonProcessingException, InvalidCacheDataException {
        JSONArray jsonArray = new JSONArray();
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("countryUuid", UUID.randomUUID());
        jsonObject.put("updatedDateTime", OffsetDateTime.parse("2024-02-20T21:51:25.628Z"));
        jsonArray.put(jsonObject);

        when(jedisInstance.exists(ArgumentMatchers.anyString())).thenReturn(true);
        when(jedisInstance.jsonGet(ArgumentMatchers.anyString(), ArgumentMatchers.any(Path2.class))).thenReturn(jsonArray);

        jedisCacheWriter.writeCountryTerritoryDataToCache(event);
        verify(jedisCacheWriter, times(0)).createNewCountryDataIntoCache(ArgumentMatchers.any(), ArgumentMatchers.any());
        verify(jedisCacheWriter, times(0)).insertCountryDataIntoCache(ArgumentMatchers.any(), ArgumentMatchers.any());
        verify(jedisCacheWriter, times(1)).performCacheOperationOnCountryData(ArgumentMatchers.any(), ArgumentMatchers.any());
        verify(jedisCacheWriter, times(2)).updateTerritoryDataIntoCache(ArgumentMatchers.any(), ArgumentMatchers.any());
        verify(jedisCacheWriter, times(0)).createNewTerritoryDataIntoCache(ArgumentMatchers.any(), ArgumentMatchers.any());
        verify(jedisCacheWriter, times(0)).insertTerritoryDataIntoCache(ArgumentMatchers.any(), ArgumentMatchers.any());
        verify(jedisCacheWriter, times(2)).performCacheOperationOnTerritoryData(ArgumentMatchers.any(), ArgumentMatchers.any());
        verify(jedisCacheWriter, times(1)).updateCountryDataIntoCache(ArgumentMatchers.any(), ArgumentMatchers.any());
    }

    @Test
    void whenCountryAndTerritoryKeyExistsInCache_AndJsonArrayIsNotNull_AndNotUpdatable_thenIgnoreRequest() throws JsonProcessingException, InvalidCacheDataException {
        JSONArray jsonArray = new JSONArray();
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("countryUuid", UUID.randomUUID());
        jsonObject.put("updatedDateTime", OffsetDateTime.parse("2024-02-22T21:51:25.628Z"));
        jsonArray.put(jsonObject);

        when(jedisInstance.exists(ArgumentMatchers.anyString())).thenReturn(true);
        when(jedisInstance.jsonGet(ArgumentMatchers.anyString(), ArgumentMatchers.any(Path2.class))).thenReturn(jsonArray);

        jedisCacheWriter.writeCountryTerritoryDataToCache(event);
        verify(jedisCacheWriter, times(0)).createNewCountryDataIntoCache(ArgumentMatchers.any(), ArgumentMatchers.any());
        verify(jedisCacheWriter, times(0)).insertCountryDataIntoCache(ArgumentMatchers.any(), ArgumentMatchers.any());
        verify(jedisCacheWriter, times(1)).performCacheOperationOnCountryData(ArgumentMatchers.any(), ArgumentMatchers.any());
        verify(jedisCacheWriter, times(0)).updateTerritoryDataIntoCache(ArgumentMatchers.any(), ArgumentMatchers.any());
        verify(jedisCacheWriter, times(0)).createNewTerritoryDataIntoCache(ArgumentMatchers.any(), ArgumentMatchers.any());
        verify(jedisCacheWriter, times(0)).insertTerritoryDataIntoCache(ArgumentMatchers.any(), ArgumentMatchers.any());
        verify(jedisCacheWriter, times(2)).performCacheOperationOnTerritoryData(ArgumentMatchers.any(), ArgumentMatchers.any());
        verify(jedisCacheWriter, times(0)).updateCountryDataIntoCache(ArgumentMatchers.any(), ArgumentMatchers.any());
    }
}
