package com.ielts.cmds.integration;

import com.ielts.cmds.integration.model.AdditionalDetailsV1;
import com.ielts.cmds.integration.model.CountryV1;
import com.ielts.cmds.integration.model.TerritoryV1;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class SQSEventSetup {

    public static CountryV1 getCountryV1DataForTest() {
        CountryV1 countryV1 = new CountryV1();
        countryV1.setCountryUuid(UUID.fromString("c9234ed3-de6a-4196-bba2-a78d1e38e8bc"));
        countryV1.setName("India");
        countryV1.setIso3Code("IND");
        countryV1.setUpdatedDateTime(OffsetDateTime.now());
        countryV1.setEffectiveFromDate(LocalDate.parse("2020-01-01"));
        countryV1.setEffectiveToDate(LocalDate.parse("2099-12-31"));
        countryV1.setTerritories(getTerritoriesForTest());
        countryV1.setAdditionalDetails(getAdditionalDetails());
        return countryV1;
    }

    private static List<TerritoryV1> getTerritoriesForTest() {
        List<TerritoryV1> territoryV1List = new ArrayList<>();
        TerritoryV1 territoryV11 = new TerritoryV1();
        territoryV11.setTerritoryUuid(UUID.fromString("a9234ed3-de6a-4196-bba2-a78d1e38e8bc"));
        territoryV11.setName("Territory Name-1");
        territoryV11.setTerritoryIsoCode("Territory Code-1");
        territoryV11.setUpdatedDateTime(OffsetDateTime.now());
        territoryV11.setEffectiveFromDate(LocalDate.parse("2020-01-01"));
        territoryV11.setEffectiveToDate(LocalDate.parse("2099-12-31"));
        territoryV11.setAdditionalDetails(getAdditionalDetails());
        territoryV1List.add(territoryV11);

        TerritoryV1 territoryV12 = new TerritoryV1();
        territoryV12.setTerritoryUuid(UUID.fromString("b9234ed3-de6a-4196-bba2-a78d1e38e8bc"));
        territoryV12.setName("Territory Name-2");
        territoryV12.setTerritoryIsoCode("Territory Code-2");
        territoryV12.setUpdatedDateTime(OffsetDateTime.now());
        territoryV12.setEffectiveFromDate(LocalDate.parse("2020-01-01"));
        territoryV12.setEffectiveToDate(LocalDate.parse("2099-12-31"));
        territoryV12.setAdditionalDetails(getAdditionalDetails());
        territoryV1List.add(territoryV12);

        return territoryV1List;
    }

    private static List<AdditionalDetailsV1> getAdditionalDetails() {
        List<AdditionalDetailsV1> additionalDetailsV1List = new ArrayList<>();
        AdditionalDetailsV1 additionalDetailsV1 = new AdditionalDetailsV1();
        additionalDetailsV1.setKey("key");
        additionalDetailsV1.setValue("value");
        additionalDetailsV1List.add(additionalDetailsV1);
        return additionalDetailsV1List;
    }

    public static com.ielts.cmds.api.evt_184.CountryV1 getEvt184CountryV1DataForTest() {
        com.ielts.cmds.api.evt_184.CountryV1 countryV1 = new com.ielts.cmds.api.evt_184.CountryV1();
        countryV1.setCountryUuid(UUID.fromString("c9234ed3-de6a-4196-bba2-a78d1e38e8bc"));
        countryV1.setName("India");
        countryV1.setIso3Code("IND");
        countryV1.setEffectiveFromDate(LocalDate.parse("2020-01-01"));
        countryV1.setEffectiveToDate(LocalDate.parse("2099-12-31"));
        countryV1.setTerritories(getEvt184TerritoriesForTest());
        countryV1.setAdditionalDetails(getEvt184AdditionalDetails());
        return countryV1;
    }

    private static List<com.ielts.cmds.api.evt_184.AdditionalDetailsV1> getEvt184AdditionalDetails() {
        List<com.ielts.cmds.api.evt_184.AdditionalDetailsV1> additionalDetailsV1List = new ArrayList<>();
        com.ielts.cmds.api.evt_184.AdditionalDetailsV1 additionalDetailsV1 = new com.ielts.cmds.api.evt_184.AdditionalDetailsV1();
        additionalDetailsV1.setKey("key");
        additionalDetailsV1.setValue("value");
        additionalDetailsV1List.add(additionalDetailsV1);
        return additionalDetailsV1List;
    }

    private static List<com.ielts.cmds.api.evt_184.TerritoryV1> getEvt184TerritoriesForTest() {
        List<com.ielts.cmds.api.evt_184.TerritoryV1> territoryV1List = new ArrayList<>();
        com.ielts.cmds.api.evt_184.TerritoryV1 territoryV11 = new com.ielts.cmds.api.evt_184.TerritoryV1();
        territoryV11.setTerritoryUuid(UUID.fromString("a9234ed3-de6a-4196-bba2-a78d1e38e8bc"));
        territoryV11.setName("Territory Name-1");
        territoryV11.setCode("Territory Code-1");
        territoryV11.setEffectiveFromDate(LocalDate.parse("2020-01-01"));
        territoryV11.setEffectiveToDate(LocalDate.parse("2099-12-31"));
        territoryV11.setAdditionalDetails(getEvt184AdditionalDetails());
        territoryV1List.add(territoryV11);

        com.ielts.cmds.api.evt_184.TerritoryV1 territoryV12 = new com.ielts.cmds.api.evt_184.TerritoryV1();
        territoryV12.setTerritoryUuid(UUID.fromString("b9234ed3-de6a-4196-bba2-a78d1e38e8bc"));
        territoryV12.setName("Territory Name-2");
        territoryV12.setCode("Territory Code-2");
        territoryV12.setEffectiveFromDate(LocalDate.parse("2020-01-01"));
        territoryV12.setEffectiveToDate(LocalDate.parse("2099-12-31"));
        territoryV12.setAdditionalDetails(getEvt184AdditionalDetails());
        territoryV1List.add(territoryV12);

        return territoryV1List;
    }
}
