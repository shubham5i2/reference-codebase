package com.ielts.cmds.integration.constants;

public class CountryTerritoryCacheWriterConstants {

    private CountryTerritoryCacheWriterConstants() {
    }

    public static final String COUNTRY_TERRITORY_CACHE_TOPIC_OUT = "CountryTerritoryCacheChangedV1_topic_out_arn";
    public static final String REFERENCE = "reference";
    public static final String COUNTRY = "country";
    public static final String TERRITORY = "territory";

    public static final String COLON = ":";
    public static final String ALL = "all";
    public static final String EQUALS_TO = "=";
    public static final String JEDIS_SEARCH_PREFIX_PATTERN = "$.[?(@.";
    public static final String COUNTRY_UUID = "countryUuid";
    public static final String TERRITORY_UUID = "territoryUuid";
    public static final String DOLLAR = "$";

    public static final String COUNTRY_TERRITORY_CACHE_CHANGED = "CountryTerritoryCacheChanged";

}
