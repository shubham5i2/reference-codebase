package com.ielts.cmds.integration.exception;

public class InvalidCacheDataException extends Exception {
    /**
     *
     */
    private static final long serialVersionUID = 8658892483810093309L;

    public InvalidCacheDataException(String message) {
        super(message);
    }
}
