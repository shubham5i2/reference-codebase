package com.ielts.cmds.integration.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CountryV1 {

    private UUID countryUuid;

    private String name;

    private String iso3Code;

    private List<TerritoryV1> territories = new ArrayList<>();

    private LocalDate effectiveFromDate;

    private LocalDate effectiveToDate;

    private List<AdditionalDetailsV1> additionalDetails = new ArrayList<>();

    private OffsetDateTime updatedDateTime;
}
