package com.ielts.cmds.integration;

import com.ielts.cmds.api.evt_184.CountryV1;
import com.ielts.cmds.api.lpr001countryterritorycachechanged.CountryTerritoryCacheV1;
import com.ielts.cmds.integration.cache.CountryTerritoryJedisWriter;
import com.ielts.cmds.integration.constants.CountryTerritoryCacheWriterConstants;
import com.ielts.cmds.integration.factory.JedisFactory;
import com.ielts.cmds.integration.utils.CountryTerritoryCacheWriterUtils;
import com.ielts.cmds.serialization.lambda.AbstractLambda;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.UnifiedJedis;
import redis.clients.jedis.exceptions.JedisConnectionException;

import static com.ielts.cmds.integration.constants.CountryTerritoryCacheWriterConstants.COUNTRY_TERRITORY_CACHE_CHANGED;

@Slf4j
public class CountryTerritoryCacheWriter extends AbstractLambda<CountryV1, CountryTerritoryCacheV1> {

    private UnifiedJedis jedisInstance;

    private JedisFactory jedisFactory = new JedisFactory();

    public CountryTerritoryCacheWriter() throws JedisConnectionException {
        jedisInstance = jedisFactory.getJedisInstance();
    }

    public CountryTerritoryCacheWriter(UnifiedJedis jedisInstance) {
        this.jedisInstance = jedisInstance;
    }

    @SneakyThrows
    @Override
    protected CountryTerritoryCacheV1 processRequest(CountryV1 countryV1) {
        CountryTerritoryCacheWriterUtils countryTerritoryCacheWriterUtils = new CountryTerritoryCacheWriterUtils();
        com.ielts.cmds.integration.model.CountryV1 modelCountryTerritoryChanged = countryTerritoryCacheWriterUtils.mapIncomingRequestToDto(countryV1);
        CountryTerritoryJedisWriter countryTerritoryJedisWriter = getRefCacheWriterInstance(jedisInstance);
        countryTerritoryJedisWriter.writeCountryTerritoryDataToCache(modelCountryTerritoryChanged);
        ThreadLocalHeaderContext.getContext().setEventName(COUNTRY_TERRITORY_CACHE_CHANGED);
        return countryTerritoryCacheWriterUtils.buildCountryTerritoryCacheChangedResponse(modelCountryTerritoryChanged);
    }

    public CountryTerritoryJedisWriter getRefCacheWriterInstance(UnifiedJedis jedisInstance) {
        return new CountryTerritoryJedisWriter(jedisInstance);
    }

    @Override
    protected String getTopicName() {
        return System.getenv(CountryTerritoryCacheWriterConstants.COUNTRY_TERRITORY_CACHE_TOPIC_OUT);
    }
}

