package com.ielts.cmds.integration.cache;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.exception.InvalidCacheDataException;
import com.ielts.cmds.integration.model.CountryCache;
import com.ielts.cmds.integration.model.CountryV1;
import com.ielts.cmds.integration.model.TerritoryV1;
import com.ielts.cmds.serialization.lambda.mapper.IObjectMapper;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import redis.clients.jedis.UnifiedJedis;
import redis.clients.jedis.json.Path2;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Optional;
import java.util.List;
import java.util.ArrayList;
import java.util.UUID;

import static com.ielts.cmds.integration.constants.CountryTerritoryCacheWriterConstants.COUNTRY;
import static com.ielts.cmds.integration.constants.CountryTerritoryCacheWriterConstants.COUNTRY_UUID;
import static com.ielts.cmds.integration.constants.CountryTerritoryCacheWriterConstants.TERRITORY;
import static com.ielts.cmds.integration.constants.CountryTerritoryCacheWriterConstants.TERRITORY_UUID;
import static com.ielts.cmds.integration.constants.CountryTerritoryCacheWriterConstants.DOLLAR;
import static com.ielts.cmds.integration.constants.CountryTerritoryCacheWriterConstants.EQUALS_TO;
import static com.ielts.cmds.integration.constants.CountryTerritoryCacheWriterConstants.COLON;
import static com.ielts.cmds.integration.constants.CountryTerritoryCacheWriterConstants.REFERENCE;
import static com.ielts.cmds.integration.constants.CountryTerritoryCacheWriterConstants.JEDIS_SEARCH_PREFIX_PATTERN;
import static com.ielts.cmds.integration.constants.CountryTerritoryCacheWriterConstants.ALL;

@Slf4j
public class CountryTerritoryJedisWriter implements IObjectMapper {

    private UnifiedJedis jedisInstance;

    public CountryTerritoryJedisWriter(UnifiedJedis jedisInstance) {
        this.jedisInstance = jedisInstance;
    }

    public void writeCountryTerritoryDataToCache(CountryV1 countryV1) throws InvalidCacheDataException, JsonProcessingException {
        log.debug("Connected to Jedis");
        //processing country data into cache
        String countryCacheKey = buildCountryDataCacheKey();
        processCountryDataCacheRequest(countryCacheKey, countryV1);

        //processing territory data into cache
        String territoryCacheKey = buildTerritoryDataCacheKey();
        processTerritoryDataCacheRequest(territoryCacheKey, countryV1.getTerritories());
    }

    private void processCountryDataCacheRequest(String countryCacheKey, CountryV1 countryV1) throws JsonProcessingException, InvalidCacheDataException {
        if (jedisInstance.exists(countryCacheKey)) {
            performCacheOperationOnCountryData(countryCacheKey, countryV1);
        } else {
            createNewCountryDataIntoCache(countryV1, countryCacheKey);
        }
    }

    /********* PERFORM CACHE OPERATIONS ON COUNTRY DATA *********/
    void performCacheOperationOnCountryData(String countryCacheKey, CountryV1 countryV1) throws JsonProcessingException, InvalidCacheDataException {
        Optional<JSONObject> optionalCountryJsonObject = fetchCountryDataFromCache(countryV1, countryCacheKey);
        boolean isCountryDataRequestUpdatable = optionalCountryJsonObject.isPresent() && isCountryDataIsUpdatable(optionalCountryJsonObject.get());
        if (!optionalCountryJsonObject.isPresent()) {
            insertCountryDataIntoCache(countryV1, countryCacheKey);
        } else if (isCountryDataRequestUpdatable) {
            updateCountryDataIntoCache(countryV1, countryCacheKey);
        } else {
            log.info("cache update request is ignored as the data present in cache is up to date for country uuid {}", countryV1.getCountryUuid());
        }
    }

    void updateCountryDataIntoCache(CountryV1 countryV1, String countryCacheKey) throws JsonProcessingException {
        CountryCache countryCache = new CountryCache();
        countryCache.setCountryUuid(countryV1.getCountryUuid());
        countryCache.setName(countryV1.getName());
        countryCache.setIso3Code(countryV1.getIso3Code());
        countryCache.setEffectiveFromDate(countryV1.getEffectiveFromDate());
        countryCache.setEffectiveToDate(countryV1.getEffectiveToDate());
        countryCache.setAdditionalDetails(countryV1.getAdditionalDetails());
        countryCache.setUpdatedDateTime(countryV1.getUpdatedDateTime());
        String refDataSearchPattern = buildCountryDataSearchPattern(countryV1.getCountryUuid().toString());
        String referenceDataCacheStr = getMapperWithProperties().writeValueAsString(countryCache);
        jedisInstance.jsonSet(countryCacheKey, Path2.of(refDataSearchPattern), referenceDataCacheStr);
    }

    void insertCountryDataIntoCache(CountryV1 countryV1, String countryCacheKey) throws JsonProcessingException {
        CountryCache countryCache = new CountryCache();
        countryCache.setCountryUuid(countryV1.getCountryUuid());
        countryCache.setName(countryV1.getName());
        countryCache.setIso3Code(countryV1.getIso3Code());
        countryCache.setEffectiveFromDate(countryV1.getEffectiveFromDate());
        countryCache.setEffectiveToDate(countryV1.getEffectiveToDate());
        countryCache.setAdditionalDetails(countryV1.getAdditionalDetails());
        countryCache.setUpdatedDateTime(countryV1.getUpdatedDateTime());
        String referenceDataStr = getMapperWithProperties().writeValueAsString(countryCache);
        jedisInstance.jsonArrAppend(countryCacheKey, Path2.of(DOLLAR), referenceDataStr);
    }

    private boolean isCountryDataIsUpdatable(JSONObject countryJsonObject) throws JsonProcessingException {
        if (!countryJsonObject.isEmpty()) {
            LocalDateTime eventDateTime = ThreadLocalHeaderContext.getContext().getEventDateTime();
            CountryV1 countryV1 = getMapperWithProperties().readValue(countryJsonObject.toString(), CountryV1.class);
            return countryV1.getUpdatedDateTime().isBefore(OffsetDateTime.of(eventDateTime, ZoneOffset.UTC));
        } else {
            return false;
        }
    }

    private Optional<JSONObject> fetchCountryDataFromCache(CountryV1 countryV1, String countryCacheKey) throws InvalidCacheDataException {
        // sample search pattern $.[?(@.attributeKey=='value')]
        String searchPattern = buildCountryDataSearchPattern(countryV1.getCountryUuid().toString());
        // casting cache response as it is stored in array
        JSONArray countryData = (JSONArray) jedisInstance.jsonGet(countryCacheKey, Path2.of(searchPattern));
        return validateAndReturnCountryJsonObjectData(countryData, countryV1.getCountryUuid());
    }

    private Optional<JSONObject> validateAndReturnCountryJsonObjectData(JSONArray countryData, UUID countryUuid) throws InvalidCacheDataException {
        if (countryData.length() == 0) {
            return Optional.empty();
        } else if (countryData.length() > 1) {
            throw new InvalidCacheDataException("Invalid cache data found for country uuid -" + countryUuid);
        } else {
            return Optional.ofNullable(countryData.getJSONObject(0));
        }
    }

    void createNewCountryDataIntoCache(CountryV1 countryV1, String countryCacheKey) throws JsonProcessingException {
        List<CountryCache> countryCacheList = new ArrayList<>();
        CountryCache countryCache = new CountryCache();
        countryCache.setCountryUuid(countryV1.getCountryUuid());
        countryCache.setName(countryV1.getName());
        countryCache.setIso3Code(countryV1.getIso3Code());
        countryCache.setEffectiveFromDate(countryV1.getEffectiveFromDate());
        countryCache.setEffectiveToDate(countryV1.getEffectiveToDate());
        countryCache.setAdditionalDetails(countryV1.getAdditionalDetails());
        countryCache.setUpdatedDateTime(countryV1.getUpdatedDateTime());
        countryCacheList.add(countryCache);
        String countryCacheListStr = getMapperWithProperties().writeValueAsString(countryCacheList);
        jedisInstance.jsonSet(countryCacheKey, countryCacheListStr);
        JSONArray entireData = (JSONArray) jedisInstance.jsonGet(buildCountryDataCacheKey(), Path2.of(DOLLAR));
        log.info("Entire country data after initial insertion {}", entireData);
    }

    void processTerritoryDataCacheRequest(String territoryCacheKey, List<TerritoryV1> territoryV1List) throws InvalidCacheDataException, JsonProcessingException {
        if (jedisInstance.exists(territoryCacheKey)) {
            for (TerritoryV1 territoryV1 : territoryV1List) {
                performCacheOperationOnTerritoryData(territoryCacheKey, territoryV1);
            }
        } else {
            createNewTerritoryDataIntoCache(territoryV1List, territoryCacheKey);
        }
    }

    String buildCountryDataSearchPattern(String countryUuid) {
        //example:- $.[?(@.countryUuid=='2f2f0641-f19f-4840-8d1f-bbf6d1faa13e')]
        return JEDIS_SEARCH_PREFIX_PATTERN.concat(COUNTRY_UUID).concat(EQUALS_TO)
                .concat(EQUALS_TO).concat("'").concat(countryUuid).concat("'").concat(")").concat("]");
    }

    public String buildCountryDataCacheKey() {
        //example:- reference:country:all
        return String.join(COLON, REFERENCE, COUNTRY, ALL);
    }

    /********* PERFORM CACHE OPERATIONS ON TERRITORY DATA *********/
    void performCacheOperationOnTerritoryData(String territoryCacheKey, TerritoryV1 territoryV1) throws JsonProcessingException, InvalidCacheDataException {
        Optional<JSONObject> optionalTerritoryJsonObject = fetchTerritoryDataFromCache(territoryV1, territoryCacheKey);
        boolean isTerritoryDataRequestUpdatable = optionalTerritoryJsonObject.isPresent() && isTerritoryDataIsUpdatable(optionalTerritoryJsonObject.get());
        if (!optionalTerritoryJsonObject.isPresent()) {
            insertTerritoryDataIntoCache(territoryV1, territoryCacheKey);
        } else if (isTerritoryDataRequestUpdatable) {
            updateTerritoryDataIntoCache(territoryV1, territoryCacheKey);
        } else {
            log.info("cache update request is ignored as the data present in cache is up to date for territory uuid {}", territoryV1.getTerritoryUuid());
        }
    }

    void updateTerritoryDataIntoCache(TerritoryV1 territoryV1, String territoryCacheKey) throws JsonProcessingException {
        String refDataSearchPattern = buildTerritoryDataSearchPattern(territoryV1.getTerritoryUuid().toString());
        String referenceDataCacheStr = getMapperWithProperties().writeValueAsString(territoryV1);
        jedisInstance.jsonSet(territoryCacheKey, Path2.of(refDataSearchPattern), referenceDataCacheStr);
    }

    void insertTerritoryDataIntoCache(TerritoryV1 territoryV1, String territoryCacheKey) throws JsonProcessingException {
        String referenceDataStr = getMapperWithProperties().writeValueAsString(territoryV1);
        jedisInstance.jsonArrAppend(territoryCacheKey, Path2.of(DOLLAR), referenceDataStr);
    }

    private boolean isTerritoryDataIsUpdatable(JSONObject territoryJsonObject) throws JsonProcessingException {
        if (territoryJsonObject != null) {
            LocalDateTime eventDateTime = ThreadLocalHeaderContext.getContext().getEventDateTime();
            TerritoryV1 territoryV1 = getMapperWithProperties().readValue(territoryJsonObject.toString(), TerritoryV1.class);
            return territoryV1.getUpdatedDateTime().isBefore(OffsetDateTime.of(eventDateTime, ZoneOffset.UTC));
        } else {
            return false;
        }
    }

    private Optional<JSONObject> fetchTerritoryDataFromCache(TerritoryV1 territoryV1, String territoryCacheKey) throws InvalidCacheDataException {
        // sample search pattern $.[?(@.attributeKey=='value')]
        String searchPattern = buildTerritoryDataSearchPattern(territoryV1.getTerritoryUuid().toString());
        // casting cache response as it is stored in array
        JSONArray territoryData = (JSONArray) jedisInstance.jsonGet(territoryCacheKey, Path2.of(searchPattern));
        return validateAndReturnTerritoryJsonObjectData(territoryData, territoryV1.getTerritoryUuid());
    }

    private Optional<JSONObject> validateAndReturnTerritoryJsonObjectData(JSONArray territoryData, UUID territoryUuid) throws InvalidCacheDataException {
        if (territoryData.length() == 0) {
            return Optional.empty();
        } else if (territoryData.length() > 1) {
            throw new InvalidCacheDataException("Invalid cache data found for territory uuid -" + territoryUuid);
        } else {
            return Optional.ofNullable(territoryData.getJSONObject(0));
        }
    }

    void createNewTerritoryDataIntoCache(List<TerritoryV1> territoryV1List, String territoryCacheKey) throws JsonProcessingException {
        String territoryCacheListStr = getMapperWithProperties().writeValueAsString(territoryV1List);
        jedisInstance.jsonSet(territoryCacheKey, territoryCacheListStr);
    }

    String buildTerritoryDataSearchPattern(String territoryUuid) {
        //example:- $.[?(@.territoryUuid=='1f2f0641-f19f-4840-8d1f-abf6d1faa13e')]
        return JEDIS_SEARCH_PREFIX_PATTERN.concat(TERRITORY_UUID).concat(EQUALS_TO)
                .concat(EQUALS_TO).concat("'").concat(territoryUuid).concat("'").concat(")").concat("]");
    }

    public String buildTerritoryDataCacheKey() {
        //example:- reference:territory:all
        return String.join(COLON, REFERENCE, TERRITORY, ALL);
    }
}
