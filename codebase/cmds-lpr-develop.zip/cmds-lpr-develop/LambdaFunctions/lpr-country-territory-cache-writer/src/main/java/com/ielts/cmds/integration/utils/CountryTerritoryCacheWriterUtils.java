package com.ielts.cmds.integration.utils;

import com.ielts.cmds.api.evt_184.CountryV1;
import com.ielts.cmds.api.lpr001countryterritorycachechanged.AdditionalDetailsV1;
import com.ielts.cmds.api.lpr001countryterritorycachechanged.CountryCacheV1;
import com.ielts.cmds.api.lpr001countryterritorycachechanged.CountryTerritoryCacheV1;
import com.ielts.cmds.api.lpr001countryterritorycachechanged.TerritoryCacheV1;
import com.ielts.cmds.integration.model.TerritoryV1;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import lombok.extern.slf4j.Slf4j;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public class CountryTerritoryCacheWriterUtils {

    public com.ielts.cmds.integration.model.CountryV1 mapIncomingRequestToDto(CountryV1 countryV1Request) {
        com.ielts.cmds.integration.model.CountryV1 countryV1 = new com.ielts.cmds.integration.model.CountryV1();
        countryV1.setCountryUuid(countryV1Request.getCountryUuid());
        countryV1.setName(countryV1Request.getName());
        countryV1.setIso3Code(countryV1Request.getIso3Code());
        countryV1.setEffectiveFromDate(countryV1Request.getEffectiveFromDate());
        countryV1.setEffectiveToDate(countryV1Request.getEffectiveToDate());
        countryV1.setUpdatedDateTime(OffsetDateTime.of(ThreadLocalHeaderContext.getContext().getEventDateTime(), ZoneOffset.UTC));
        countryV1.setTerritories(getTerritories(countryV1Request));
        countryV1.setAdditionalDetails(getAdditionalDetails(countryV1Request.getAdditionalDetails()));
        return countryV1;
    }

    private List<TerritoryV1> getTerritories(CountryV1 countryV1) {
        List<TerritoryV1> territoryV1List = new ArrayList<>();
        countryV1.getTerritories().forEach(territory -> {
            TerritoryV1 territoryV1 = new TerritoryV1();
            territoryV1.setTerritoryUuid(territory.getTerritoryUuid());
            territoryV1.setCountryUuid(countryV1.getCountryUuid());
            territoryV1.setTerritoryIsoCode(territory.getCode());
            territoryV1.setName(territory.getName());
            territoryV1.setEffectiveFromDate(territory.getEffectiveFromDate());
            territoryV1.setEffectiveToDate(territory.getEffectiveToDate());
            territoryV1.setUpdatedDateTime(OffsetDateTime.of(ThreadLocalHeaderContext.getContext().getEventDateTime(), ZoneOffset.UTC));
            territoryV1.setAdditionalDetails(getAdditionalDetails(territory.getAdditionalDetails()));
            territoryV1List.add(territoryV1);
        });
        return territoryV1List;
    }

    private List<com.ielts.cmds.integration.model.AdditionalDetailsV1> getAdditionalDetails(List<com.ielts.cmds.api.evt_184.AdditionalDetailsV1> additionalDetails) {
        List<com.ielts.cmds.integration.model.AdditionalDetailsV1> additionalDetailsV1List = new ArrayList<>();
        additionalDetails.forEach(additionalDetail -> {
            com.ielts.cmds.integration.model.AdditionalDetailsV1 additionalDetailsV1 = new com.ielts.cmds.integration.model.AdditionalDetailsV1();
            additionalDetailsV1.setKey(additionalDetail.getKey());
            additionalDetailsV1.setValue(additionalDetail.getValue());
            additionalDetailsV1List.add(additionalDetailsV1);
        });
        return additionalDetailsV1List;
    }

    public CountryTerritoryCacheV1 buildCountryTerritoryCacheChangedResponse(com.ielts.cmds.integration.model.CountryV1 countryV1Request) {
        CountryTerritoryCacheV1 countryTerritoryCacheV1 = new CountryTerritoryCacheV1();
        CountryCacheV1 countryCacheV1 = new CountryCacheV1();
        countryCacheV1.setCountryUuid(countryV1Request.getCountryUuid());
        countryCacheV1.setName(countryV1Request.getName());
        countryCacheV1.setIso3Code(countryV1Request.getIso3Code());
        countryCacheV1.setEffectiveFromDate(countryV1Request.getEffectiveFromDate());
        countryCacheV1.setEffectiveToDate(countryV1Request.getEffectiveToDate());
        countryCacheV1.setUpdatedDateTime(OffsetDateTime.of(ThreadLocalHeaderContext.getContext().getEventDateTime(), ZoneOffset.UTC));
        List<AdditionalDetailsV1> additionalDetailsV1List = countryV1Request.getAdditionalDetails().stream()
                .map(this::mapAdditionalDetailsToCountryCache).collect(Collectors.toList());
        countryCacheV1.setAdditionalDetails(additionalDetailsV1List);

        List<TerritoryCacheV1> territoryCacheV1List = countryV1Request.getTerritories().stream()
                .map(territoryV1 -> mapTerritoriesToTerritoryCache(territoryV1, countryV1Request)).collect(Collectors.toList());

        countryTerritoryCacheV1.setCountry(countryCacheV1);
        countryTerritoryCacheV1.setTerritories(territoryCacheV1List);

        return countryTerritoryCacheV1;
    }

    private TerritoryCacheV1 mapTerritoriesToTerritoryCache(TerritoryV1 territoryV1, com.ielts.cmds.integration.model.CountryV1 countryV1Request) {
        TerritoryCacheV1 territoryCacheV1 = new TerritoryCacheV1();
        territoryCacheV1.setTerritoryUuid(territoryV1.getTerritoryUuid());
        territoryCacheV1.setCountryUuid(countryV1Request.getCountryUuid());
        territoryCacheV1.setName(territoryV1.getName());
        territoryCacheV1.setTerritoryIsoCode(territoryV1.getTerritoryIsoCode());
        territoryCacheV1.setEffectiveFromDate(territoryV1.getEffectiveFromDate());
        territoryCacheV1.setEffectiveToDate(territoryV1.getEffectiveToDate());
        territoryCacheV1.setUpdatedDateTime(OffsetDateTime.of(ThreadLocalHeaderContext.getContext().getEventDateTime(), ZoneOffset.UTC));
        List<AdditionalDetailsV1> additionalDetailsV1List = territoryV1.getAdditionalDetails().stream()
                .map(this::mapAdditionalDetailsToTerritoryCache).collect(Collectors.toList());
        territoryCacheV1.setAdditionalDetails(additionalDetailsV1List);
        return territoryCacheV1;
    }

    private AdditionalDetailsV1 mapAdditionalDetailsToTerritoryCache(com.ielts.cmds.integration.model.AdditionalDetailsV1 additionalDetailsV1Request) {
        AdditionalDetailsV1 additionalDetailsV1ForCountry = new AdditionalDetailsV1();
        additionalDetailsV1ForCountry.setKey(additionalDetailsV1Request.getKey());
        additionalDetailsV1ForCountry.setValue(additionalDetailsV1Request.getValue());
        return additionalDetailsV1ForCountry;
    }

    private AdditionalDetailsV1 mapAdditionalDetailsToCountryCache(com.ielts.cmds.integration.model.AdditionalDetailsV1 additionalDetailsV1Request) {
        AdditionalDetailsV1 additionalDetailsV1ForTerritory = new AdditionalDetailsV1();
        additionalDetailsV1ForTerritory.setKey(additionalDetailsV1Request.getKey());
        additionalDetailsV1ForTerritory.setValue(additionalDetailsV1Request.getValue());
        return additionalDetailsV1ForTerritory;
    }
}
