package com.ielts.cmds.integration.mapping;


import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyRequestEvent;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.common.product_ui_client.SingleProduct;
import com.ielts.cmds.integration.TestDataSetup;
import com.ielts.cmds.integration.cache.JedisCacheReader;
import com.ielts.cmds.integration.cache.factory.JedisFactory;
import com.ielts.cmds.integration.cache.mapping.SingleProductResponseMapping;
import com.ielts.cmds.integration.response.GatewayResponseEntity;
import org.apache.http.HttpStatus;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static com.ielts.cmds.integration.TestDataSetup.getMapperWithProperties;
import static com.ielts.cmds.integration.TestDataSetup.getProductForTest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SingleProductResponseMappingTest {

    @InjectMocks
    @Spy
    private SingleProductResponseMapping singleProductResponseMapping;

    @Mock
    private JedisCacheReader jedisCacheReader;

    @Mock
    private JedisFactory jedisFactory;


    @Test
    void whenSingleProductRequested_thenReturnProduct() throws JsonProcessingException {
        // Given
        APIGatewayProxyRequestEvent singleProductEventForTest = TestDataSetup.getProductEventForTest();
        Optional<SingleProduct> optionalProduct = Optional.of(getProductForTest());
        String expectedResponseBody = getMapperWithProperties().writeValueAsString(getProductForTest());
        when(jedisFactory.getJedisReader()).thenReturn(jedisCacheReader);
        doReturn(optionalProduct).when(jedisCacheReader).retrieveSingleProductDataFromRedisCache(ArgumentMatchers.any());
        // When
        GatewayResponseEntity actualGatewayResponseEntity = singleProductResponseMapping.process(singleProductEventForTest);
        // Then
        assertEquals(expectedResponseBody, actualGatewayResponseEntity.getBody());
        assertEquals(HttpStatus.SC_OK, actualGatewayResponseEntity.getStatusCode());
    }

    @Test
    void whenSingleProductIsRequestedAndProductNotAvailable_thenReturnResponseWithNoContent() throws JsonProcessingException {
        // Given
        APIGatewayProxyRequestEvent singleProductEventForTest = TestDataSetup.getProductEventForTest();
        when(jedisFactory.getJedisReader()).thenReturn(jedisCacheReader);
        doReturn(Optional.empty()).when(jedisCacheReader).retrieveSingleProductDataFromRedisCache(ArgumentMatchers.any());
        // When
        GatewayResponseEntity actualGatewayResponseEntity = singleProductResponseMapping.process(singleProductEventForTest);

        // Then
        assertEquals(HttpStatus.SC_NO_CONTENT, actualGatewayResponseEntity.getStatusCode());
    }
}
