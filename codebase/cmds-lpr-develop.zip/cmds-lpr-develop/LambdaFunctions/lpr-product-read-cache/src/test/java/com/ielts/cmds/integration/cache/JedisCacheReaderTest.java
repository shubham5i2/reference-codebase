package com.ielts.cmds.integration.cache;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import com.ielts.cmds.api.common.product_ui_client.SingleProduct;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.integration.TestDataSetup;
import com.ielts.cmds.integration.cache.constants.ProductDataReadCacheConstants;
import com.ielts.cmds.api.common.product_ui_client.Module;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

@ExtendWith(MockitoExtension.class)
class JedisCacheReaderTest {

	JedisCacheReader jedisCacheReader;

	@Mock
	Jedis jedisMock;

	@Mock
	JedisPool jedisPool;

	@Spy
    JedisReaderHelper jedisReaderHelper;

	@BeforeEach
	public void setUp() {
		when(jedisPool.getResource()).thenReturn(jedisMock);
		jedisCacheReader = new JedisCacheReader(jedisReaderHelper, jedisPool);
	}

	@Test
	void testRetrieveSingleProductDataFromRedisCacheHashMap() throws JsonProcessingException {
		Map<String, String> productDataSetUpInCache = TestDataSetup.getProductDataInHashMap();
		when(jedisMock.hgetAll("product-81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498")).thenReturn(productDataSetUpInCache);
		Optional<SingleProduct> productDataOpt = jedisCacheReader
				.retrieveSingleProductDataFromRedisCache("81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");
		SingleProduct productData = productDataOpt.get();
		verify(jedisMock, times(1)).hgetAll("product-81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");
		assertEquals(UUID.fromString(productDataSetUpInCache.get(ProductDataReadCacheConstants.PRODUCT_UUID)),
				productData.getProductUuid());
		assertEquals(UUID.fromString(productDataSetUpInCache.get(ProductDataReadCacheConstants.PARENT_PRODUCT_UUID)),
				productData.getParentProductUuid());
		assertEquals(new ObjectMapper().readValue(productDataSetUpInCache.get(ProductDataReadCacheConstants.MODULE),
				Module.class), productData.getModule());
		assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.LEGACY_PRODUCT_ID),
				productData.getLegacyProductId());
		assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.NAME), productData.getName());
		assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.DESCRIPTION),
				productData.getDescription());
		assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.PRODUCT_CHARACTERISTICS),
				productData.getProductCharacteristics());
		assertEquals(Boolean.valueOf(productDataSetUpInCache.get(ProductDataReadCacheConstants.BOOKABLE)),
				productData.getBookable());
		assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.COMPONENT), productData.getComponent().toString());
		assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.DURATION),
				String.valueOf(productData.getDuration()));
		assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.FORMAT), productData.getFormat());
		assertEquals(Boolean.valueOf(productDataSetUpInCache.get(ProductDataReadCacheConstants.APPROVAL_REQUIRED)),
				productData.getApprovalRequired());
		assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.AVAILABLE_FROM_DATE),
				productData.getAvailableFrom().toString());
		assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.AVAILABLE_TO_DATE),
				productData.getAvailableTo().toString());
	}

	@Test
	void whenRequestedProductDataIsNotPresentInCache_verifyEmptyProductIsReturned() throws JsonProcessingException {
		Optional<SingleProduct> productData = jedisCacheReader
				.retrieveSingleProductDataFromRedisCache("81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");
		verify(jedisMock, times(1)).hgetAll("product-81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");
		assertEquals(Optional.empty(), productData);
	}

	@Test
	void testRetrieveAllBookableProductsDataFromRedisCache() throws JsonProcessingException {
		Set<String> bookableProductKeys = new HashSet<String>();
		bookableProductKeys.add("product-81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");
		Map<String, String> productDataSetUpInCache = TestDataSetup.getProductDataInHashMap();
		when(jedisMock.smembers(ProductDataReadCacheConstants.KEY_OF_ALL_BOOKABLE_PRODUCTS)).thenReturn(bookableProductKeys);
		when(jedisMock.hgetAll("product-81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498")).thenReturn(productDataSetUpInCache);
		List<SingleProduct> bookableProductList = jedisCacheReader.retrieveAllBookableProductsDataFromRedisCache();
		verify(jedisMock, times(1)).smembers(ProductDataReadCacheConstants.KEY_OF_ALL_BOOKABLE_PRODUCTS);
		assertEquals(1, bookableProductList.size());
		assertEquals(true, bookableProductList.get(0).getBookable());
	}

	@Test
	void whenBookableProductsAreNotPresentInCache_verifyEmptyListIsReturned() throws JsonProcessingException {
		List<SingleProduct> bookableProductList = jedisCacheReader.retrieveAllBookableProductsDataFromRedisCache();
		verify(jedisMock, times(1)).smembers(ProductDataReadCacheConstants.KEY_OF_ALL_BOOKABLE_PRODUCTS);
		assertTrue(bookableProductList.isEmpty());
	}

	@Test
	void testRetrieveAllProductsDataFromRedisCache() throws JsonProcessingException {
		Set<String> allProductKeys = new HashSet<String>();
		allProductKeys.add("product-81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");
		Map<String, String> productDataSetUpInCache = TestDataSetup.getProductDataInHashMap();
		when(jedisMock.smembers(ProductDataReadCacheConstants.KEY_OF_ALL_PRODUCTS)).thenReturn(allProductKeys);
		when(jedisMock.hgetAll("product-81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498")).thenReturn(productDataSetUpInCache);
		List<SingleProduct> allProductList = jedisCacheReader.retrieveAllProductsDataFromRedisCache();
		verify(jedisMock, times(1)).smembers(ProductDataReadCacheConstants.KEY_OF_ALL_PRODUCTS);
		verify(jedisMock, times(1)).hgetAll("product-81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");
		assertEquals(1, allProductList.size());
		assertEquals(true, allProductList.get(0).getBookable());
	}

	@Test
	void whenProductsAreNotPresentInCache_verifyEmptyListIsReturned() throws JsonProcessingException {
		List<SingleProduct> allProductList = jedisCacheReader.retrieveAllProductsDataFromRedisCache();
		verify(jedisMock, times(1)).smembers(ProductDataReadCacheConstants.KEY_OF_ALL_PRODUCTS);
		assertTrue(allProductList.isEmpty());
	}

}
