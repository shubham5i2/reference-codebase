package com.ielts.cmds.integration;

import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyRequestEvent;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.cache.mapping.AllProductsResponseMapping;
import com.ielts.cmds.integration.cache.mapping.BookableProductsResponseMapping;
import com.ielts.cmds.integration.cache.mapping.SingleProductResponseMapping;
import com.ielts.cmds.integration.response.GatewayResponseEntity;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.org.webcompere.systemstubs.environment.EnvironmentVariables;
import uk.org.webcompere.systemstubs.jupiter.SystemStub;
import uk.org.webcompere.systemstubs.jupiter.SystemStubsExtension;

import java.util.HashMap;
import java.util.Map;

import static com.ielts.cmds.integration.cache.constants.ProductDataReadCacheConstants.UI_DOMAIN;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
@ExtendWith(SystemStubsExtension.class)
class ProductDataReadCacheTest {

    @Spy
    private ProductDataReadCache productDataReadCache;

    @SystemStub
    private EnvironmentVariables env;

    @Test
    void whenSingleProductRequested_thenShouldCallSingleProductResponseMapping() {
        APIGatewayProxyRequestEvent singleProductEventForTest = TestDataSetup.getProductEventForTest();
        productDataReadCache.handleRequest(singleProductEventForTest);
        IServiceV2 actual = productDataReadCache.getServiceFactory().getService(singleProductEventForTest.getResource());
        assertTrue(actual instanceof SingleProductResponseMapping);
    }

    @Test
    void whenAllProductsRequested_thenShouldCallAllProductsResponseMapping() {
        APIGatewayProxyRequestEvent allProductsEventForTest = TestDataSetup.getAllProductsEventForTest();
        productDataReadCache.handleRequest(allProductsEventForTest);
        IServiceV2 actual = productDataReadCache.getServiceFactory().getService(allProductsEventForTest.getResource());
        assertTrue(actual instanceof AllProductsResponseMapping);
    }

    @Test
    void whenBookableProductsRequested_thenShouldCallAllBookableProductsResponseMapping() {
        APIGatewayProxyRequestEvent allBookableProductsEvent = TestDataSetup.getAllBookableProductsEventForTest();
        productDataReadCache.handleRequest(allBookableProductsEvent);
        IServiceV2 actual = productDataReadCache.getServiceFactory().getService(allBookableProductsEvent.getResource());
        assertTrue(actual instanceof BookableProductsResponseMapping);
    }

    @Test
    void whenAllProductsRequested_thenReturnAllProductsWithCorsHeader() throws JsonProcessingException {
        // Given
        APIGatewayProxyRequestEvent allProductsEventForTest = TestDataSetup.getAllProductsEventForTest();
        Map<String, String> expectedResponseHeaders = new HashMap<>();
        expectedResponseHeaders.put("Access-Control-Allow-Origin", "https://ui.sandbox.cmdsiz.com");
        env.set(UI_DOMAIN, "https://ui.sandbox.cmdsiz.com");
        // When
        GatewayResponseEntity actualGatewayResponseEntity = productDataReadCache.handleRequest(allProductsEventForTest);

        // Then
        assertEquals(expectedResponseHeaders.get("Access-Control-Allow-Origin"), actualGatewayResponseEntity.getHeaders().get("Access-Control-Allow-Origin"));
    }

    @Test
    void whenSingleProductsRequested_thenReturnAllProductsWithCorsHeader() throws JsonProcessingException {
        // Given
        APIGatewayProxyRequestEvent allProductsEventForTest = TestDataSetup.getProductEventForTest();
        Map<String, String> expectedResponseHeaders = new HashMap<>();
        expectedResponseHeaders.put("Access-Control-Allow-Origin", "https://ui.sandbox.cmdsiz.com");
        env.set(UI_DOMAIN, "https://ui.sandbox.cmdsiz.com");
        // When
        GatewayResponseEntity actualGatewayResponseEntity = productDataReadCache.handleRequest(allProductsEventForTest);

        // Then
        assertEquals(expectedResponseHeaders.get("Access-Control-Allow-Origin"), actualGatewayResponseEntity.getHeaders().get("Access-Control-Allow-Origin"));
    }
}
