package com.ielts.cmds.integration.factory;

import static com.ielts.cmds.integration.cache.constants.ProductDataReadCacheConstants.IS_CLUSTER_MODE_ENABLED;
import static com.ielts.cmds.integration.cache.constants.ProductDataReadCacheConstants.UI_DOMAIN;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.integration.cache.JedisCacheReader;
import com.ielts.cmds.integration.cache.JedisClusterCacheReader;
import com.ielts.cmds.integration.cache.JedisGenericReader;
import com.ielts.cmds.integration.cache.factory.JedisFactory;

import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.exceptions.JedisClusterOperationException;
import uk.org.webcompere.systemstubs.environment.EnvironmentVariables;
import uk.org.webcompere.systemstubs.jupiter.SystemStub;
import uk.org.webcompere.systemstubs.jupiter.SystemStubsExtension;

@ExtendWith(MockitoExtension.class)
@ExtendWith(SystemStubsExtension.class)
class JedisFactoryTest {

	@Spy
	@InjectMocks
	private JedisFactory jedisFactory;

	@Mock
	private JedisCluster jedisCluster;

	@Mock
	private JedisPool jedisPool;

	@SystemStub
	private EnvironmentVariables env;

	@Test
	void testGetJedisPoolInstance() {
		JedisPoolConfig poolConfig = new JedisPoolConfig();
		poolConfig.setMaxTotal(20);
		poolConfig.setMaxIdle(20);
		poolConfig.setMinIdle(10);
		when(jedisFactory.buildPoolConfig()).thenReturn(poolConfig);
		when(jedisFactory.getRedisCacheHost()).thenReturn("hostname");
		when(jedisFactory.getRedisCachePort()).thenReturn("6873");
		JedisPool jedisPoolReturned = jedisFactory.getJedisPoolInstance();
		assertTrue(jedisPoolReturned instanceof JedisPool);
	}

	@Test
	void testGetJedisClusterInstance() {
		doReturn(jedisCluster).when(jedisFactory).getJedisClusterInstance();
		JedisCluster jedisClusterInstance = jedisFactory.getJedisClusterInstance();
		assertNotNull(jedisClusterInstance);
		assertTrue(jedisClusterInstance instanceof JedisCluster);
	}

	@Test
	void testJedisConnectionExceptionIsThrown_whenGetJedisClusterInstance() {
		doReturn("127.0.0.1").when(jedisFactory).getRedisCacheHost();
		doReturn("7000").when(jedisFactory).getRedisCachePort();
		Executable executable = () -> jedisFactory.getJedisClusterInstance();
		Assertions.assertThrows(JedisClusterOperationException.class, executable);
	}

	@Test
	void test_whenGetJedisReader_thenReturnJedisClusterCacheWriterInstance() {
		env.set(IS_CLUSTER_MODE_ENABLED, true);
		doReturn(jedisCluster).when(jedisFactory).getJedisClusterInstance();
		JedisGenericReader jedisClusterCacheReaderInstance = jedisFactory.getJedisReader();
		assertTrue(jedisClusterCacheReaderInstance instanceof JedisClusterCacheReader);
	}

	@Test
	void test_whenGetJedisReader_thenReturnJedisCacheWriterInstance() {
		env.set(IS_CLUSTER_MODE_ENABLED, false);
		doReturn(jedisPool).when(jedisFactory).getJedisPoolInstance();
		JedisGenericReader jedisCacheReaderInstance = jedisFactory.getJedisReader();
		assertTrue(jedisCacheReaderInstance instanceof JedisCacheReader);
	}

}
