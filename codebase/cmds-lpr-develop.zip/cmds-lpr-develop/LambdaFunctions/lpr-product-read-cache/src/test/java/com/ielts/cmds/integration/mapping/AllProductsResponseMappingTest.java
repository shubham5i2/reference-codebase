package com.ielts.cmds.integration.mapping;


import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyRequestEvent;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.common.product_ui_client.SingleProduct;
import com.ielts.cmds.integration.TestDataSetup;
import com.ielts.cmds.integration.cache.JedisCacheReader;
import com.ielts.cmds.integration.cache.factory.JedisFactory;
import com.ielts.cmds.integration.cache.mapping.AllProductsResponseMapping;
import com.ielts.cmds.integration.response.GatewayResponseEntity;
import org.apache.http.HttpStatus;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.ielts.cmds.integration.TestDataSetup.getAllProductsForTest;
import static com.ielts.cmds.integration.TestDataSetup.getMapperWithProperties;
import static com.ielts.cmds.integration.cache.constants.ProductDataReadCacheConstants.GET_ALL_PRODUCTS;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AllProductsResponseMappingTest {

    @InjectMocks
    @Spy
    private AllProductsResponseMapping allProductsResponseMapping;

    @Mock
    private JedisCacheReader jedisCacheReader;

    @Mock
    private JedisFactory jedisFactory;

    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(allProductsResponseMapping, "jedisFactory", jedisFactory);
    }


    @Test
    void whenAllProductsRequested_thenReturnAllProducts() throws JsonProcessingException {
        // Given
        List<SingleProduct> productList = getAllProductsForTest();
        APIGatewayProxyRequestEvent allProductsEventForTest = TestDataSetup.getProductEventForTest();
        allProductsEventForTest.setPath(GET_ALL_PRODUCTS);
        allProductsEventForTest.setQueryStringParameters(null);
        String expectedResponseBody = getMapperWithProperties().writeValueAsString(productList);
        when(jedisFactory.getJedisReader()).thenReturn(jedisCacheReader);
        doReturn(productList).when(jedisCacheReader).retrieveAllProductsDataFromRedisCache();

        allProductsEventForTest.setPathParameters(Collections.EMPTY_MAP);
        // When
        GatewayResponseEntity actualGatewayResponseEntity = allProductsResponseMapping.process(allProductsEventForTest);

        // Then
        assertEquals(expectedResponseBody, actualGatewayResponseEntity.getBody());
        assertEquals(HttpStatus.SC_OK, actualGatewayResponseEntity.getStatusCode());
    }

    @Test
    void whenAllProductsRequestedAndProductsNotAvailable_thenReturnResponseWithNoContent() throws JsonProcessingException {
        // Given
        List<SingleProduct> productList = new ArrayList<>();
        APIGatewayProxyRequestEvent allProductsEventForTest = TestDataSetup.getProductEventForTest();
        allProductsEventForTest.setPath(GET_ALL_PRODUCTS);
        allProductsEventForTest.setQueryStringParameters(null);
        when(jedisFactory.getJedisReader()).thenReturn(jedisCacheReader);
        doReturn(productList).when(jedisCacheReader).retrieveAllProductsDataFromRedisCache();

        allProductsEventForTest.setPathParameters(Collections.EMPTY_MAP);

        // When
        GatewayResponseEntity actualGatewayResponseEntity = allProductsResponseMapping.process(allProductsEventForTest);

        // Then
        assertEquals(HttpStatus.SC_NO_CONTENT, actualGatewayResponseEntity.getStatusCode());
    }
}
