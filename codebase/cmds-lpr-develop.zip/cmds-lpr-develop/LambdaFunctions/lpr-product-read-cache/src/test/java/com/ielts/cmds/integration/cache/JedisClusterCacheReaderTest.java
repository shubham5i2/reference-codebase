package com.ielts.cmds.integration.cache;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import com.ielts.cmds.api.common.product_ui_client.SingleProduct;
import com.ielts.cmds.api.common.product_ui_client.Module;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.integration.TestDataSetup;
import com.ielts.cmds.integration.cache.constants.ProductDataReadCacheConstants;

import redis.clients.jedis.JedisCluster;

@ExtendWith(MockitoExtension.class)
class JedisClusterCacheReaderTest {

	JedisClusterCacheReader jedisClusterCacheReader;

	@Mock
	JedisCluster jedisClusterMock;

	@Spy
    JedisReaderHelper jedisReaderHelper;

	@BeforeEach
	public void setUp() {
		jedisClusterCacheReader = new JedisClusterCacheReader(jedisReaderHelper, jedisClusterMock);
	}

	@Test
	void testRetrieveSingleProductDataFromRedisCacheHashMap() throws JsonProcessingException {
		Map<String, String> productDataSetUpInCache = TestDataSetup.getProductDataInHashMap();
		when(jedisClusterMock.hgetAll("product-81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498"))
				.thenReturn(productDataSetUpInCache);
		Optional<SingleProduct> productDataOpt = jedisClusterCacheReader
				.retrieveSingleProductDataFromRedisCache("81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");
		SingleProduct productData = productDataOpt.get();
		verify(jedisClusterMock, times(1)).hgetAll("product-81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");
		assertEquals(UUID.fromString(productDataSetUpInCache.get(ProductDataReadCacheConstants.PRODUCT_UUID)),
				productData.getProductUuid());
		assertEquals(UUID.fromString(productDataSetUpInCache.get(ProductDataReadCacheConstants.PARENT_PRODUCT_UUID)),
				productData.getParentProductUuid());
		assertEquals(new ObjectMapper().readValue(productDataSetUpInCache.get(ProductDataReadCacheConstants.MODULE),
				Module.class), productData.getModule());
		assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.LEGACY_PRODUCT_ID),
				productData.getLegacyProductId());
		assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.NAME), productData.getName());
		assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.DESCRIPTION),
				productData.getDescription());
		assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.PRODUCT_CHARACTERISTICS),
				productData.getProductCharacteristics());
		assertEquals(Boolean.valueOf(productDataSetUpInCache.get(ProductDataReadCacheConstants.BOOKABLE)),
				productData.getBookable());
		assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.COMPONENT), productData.getComponent().toString());
		assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.DURATION),
				String.valueOf(productData.getDuration()));
		assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.FORMAT), productData.getFormat());
		assertEquals(Boolean.valueOf(productDataSetUpInCache.get(ProductDataReadCacheConstants.APPROVAL_REQUIRED)),
				productData.getApprovalRequired());
		assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.AVAILABLE_FROM_DATE),
				productData.getAvailableFrom().toString());
		assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.AVAILABLE_TO_DATE),
				productData.getAvailableTo().toString());
	}

	@Test
	void testRetrieveSingleProductDataFromRedisCacheHashMap_negetiveScenario() throws JsonProcessingException {
		Optional<SingleProduct> productData = jedisClusterCacheReader
				.retrieveSingleProductDataFromRedisCache("81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");
		verify(jedisClusterMock, times(1)).hgetAll("product-81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");
		assertEquals(Optional.empty(), productData);
	}

	@Test
	void testRetrieveAllBookableProductsDataFromRedisCache() throws JsonProcessingException {
		Set<String> bookableProductKeys = new HashSet<String>();
		bookableProductKeys.add("product-81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");
		Map<String, String> productDataSetUpInCache = TestDataSetup.getProductDataInHashMap();
		when(jedisClusterMock.smembers(ProductDataReadCacheConstants.KEY_OF_ALL_BOOKABLE_PRODUCTS)).thenReturn(bookableProductKeys);
		when(jedisClusterMock.hgetAll("product-81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498"))
				.thenReturn(productDataSetUpInCache);
		List<SingleProduct> bookableProductList = jedisClusterCacheReader.retrieveAllBookableProductsDataFromRedisCache();
		verify(jedisClusterMock, times(1)).smembers(ProductDataReadCacheConstants.KEY_OF_ALL_BOOKABLE_PRODUCTS);
		assertEquals(1, bookableProductList.size());
		assertEquals(true, bookableProductList.get(0).getBookable());
	}

	@Test
	void testRetrieveAllBookableProductsDataFromRedisCache_negetiveScenario() throws JsonProcessingException {
		List<SingleProduct> bookableProductList = jedisClusterCacheReader.retrieveAllBookableProductsDataFromRedisCache();
		verify(jedisClusterMock, times(1)).smembers(ProductDataReadCacheConstants.KEY_OF_ALL_BOOKABLE_PRODUCTS);
		assertTrue(bookableProductList.isEmpty());
	}

	@Test
	void testRetrieveAllProductsDataFromRedisCache() throws JsonProcessingException {
		Set<String> allProductKeys = new HashSet<String>();
		allProductKeys.add("product-81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");
		Map<String, String> productDataSetUpInCache = TestDataSetup.getProductDataInHashMap();
		when(jedisClusterMock.smembers(ProductDataReadCacheConstants.KEY_OF_ALL_PRODUCTS)).thenReturn(allProductKeys);
		when(jedisClusterMock.hgetAll("product-81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498"))
				.thenReturn(productDataSetUpInCache);
		List<SingleProduct> allProductList = jedisClusterCacheReader.retrieveAllProductsDataFromRedisCache();
		verify(jedisClusterMock, times(1)).smembers(ProductDataReadCacheConstants.KEY_OF_ALL_PRODUCTS);
		verify(jedisClusterMock, times(1)).hgetAll("product-81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");
		assertEquals(1, allProductList.size());
		assertEquals(true, allProductList.get(0).getBookable());
	}

	@Test
	void testRetrieveAllProductsDataFromRedisCache_negetiveScenario() throws JsonProcessingException {
		List<SingleProduct> allProductList = jedisClusterCacheReader.retrieveAllProductsDataFromRedisCache();
		verify(jedisClusterMock, times(1)).smembers(ProductDataReadCacheConstants.KEY_OF_ALL_PRODUCTS);
		assertTrue(allProductList.isEmpty());
	}
}
