package com.ielts.cmds.integration;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyRequestEvent;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.api.common.product_ui_client.SingleProduct;
import com.ielts.cmds.api.common.product_ui_client.Module;
import com.ielts.cmds.integration.cache.constants.ProductDataReadCacheConstants;
import com.ielts.cmds.integration.response.GatewayResponseEntity;
import org.apache.http.HttpStatus;

import static com.ielts.cmds.integration.cache.constants.ProductDataReadCacheConstants.GET_ALL_PRODUCTS;
import static com.ielts.cmds.integration.cache.constants.ProductDataReadCacheConstants.GET_BOOKABLE_ALL_PRODUCTS;
import static com.ielts.cmds.integration.cache.constants.ProductDataReadCacheConstants.GET_SINGLE_PRODUCT;

public class TestDataSetup {

	public static Map<String, String> getProductDataInHashMap() throws JsonProcessingException {
		Map<String, String> hash = new HashMap<>();
		hash.put(ProductDataReadCacheConstants.PRODUCT_UUID, "81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");
		hash.put(ProductDataReadCacheConstants.PARENT_PRODUCT_UUID, "c007e869-7e35-4209-b0f1-ee5760d7c6fd");
		hash.put(ProductDataReadCacheConstants.LEGACY_PRODUCT_ID, "D901");
		hash.put(ProductDataReadCacheConstants.MODULE,
				"{\"moduleType\":\"AC\",\"moduleTypeUuid\":\"98728fc7-fa65-4757-85e4-90aa022f2816\",\"description\":\"Academic\"}");
		hash.put(ProductDataReadCacheConstants.NAME, "IELTS Online AC W");
		hash.put(ProductDataReadCacheConstants.DESCRIPTION, "string");
		hash.put(ProductDataReadCacheConstants.BOOKABLE, "true");
		hash.put(ProductDataReadCacheConstants.DURATION, "60");
		hash.put(ProductDataReadCacheConstants.PRODUCT_CHARACTERISTICS, "{\"characteristics\":[\"IOL\",\"IOC\"]}");
		hash.put(ProductDataReadCacheConstants.FORMAT, "CD");
		hash.put(ProductDataReadCacheConstants.COMPONENT, "W");
		hash.put(ProductDataReadCacheConstants.APPROVAL_REQUIRED, "false");
		hash.put(ProductDataReadCacheConstants.AVAILABLE_FROM_DATE, "2022-01-01");
		hash.put(ProductDataReadCacheConstants.AVAILABLE_TO_DATE, "2099-12-31");
		return hash;
	}

	public SingleProduct mapHashMapToProductResponse(Map<String, String> productDataFromCache)
			throws JsonProcessingException {

		SingleProduct product = new SingleProduct();
		product.setProductUuid(UUID.fromString(productDataFromCache.get(ProductDataReadCacheConstants.PRODUCT_UUID)));
		product.setParentProductUuid(
				UUID.fromString(productDataFromCache.get(ProductDataReadCacheConstants.PARENT_PRODUCT_UUID)));
		product.setLegacyProductId(productDataFromCache.get(ProductDataReadCacheConstants.LEGACY_PRODUCT_ID));
		product.setName(productDataFromCache.get(ProductDataReadCacheConstants.NAME));
		product.setDescription(productDataFromCache.get(ProductDataReadCacheConstants.DESCRIPTION));
		product.setProductCharacteristics(
				productDataFromCache.get(ProductDataReadCacheConstants.PRODUCT_CHARACTERISTICS));
		product.setBookable(Boolean.valueOf(productDataFromCache.get(ProductDataReadCacheConstants.BOOKABLE)));
		product.setComponent(SingleProduct.ComponentEnum.valueOf(productDataFromCache.get(ProductDataReadCacheConstants.COMPONENT)));
		product.setDuration(productDataFromCache.get(ProductDataReadCacheConstants.DURATION));
		product.setFormat(productDataFromCache.get(ProductDataReadCacheConstants.FORMAT));
		product.setApprovalRequired(
				Boolean.valueOf(productDataFromCache.get(ProductDataReadCacheConstants.APPROVAL_REQUIRED)));
		product.setAvailableFrom(
				LocalDate.parse(productDataFromCache.get(ProductDataReadCacheConstants.AVAILABLE_FROM_DATE)));
		product.setAvailableTo(
				LocalDate.parse(productDataFromCache.get(ProductDataReadCacheConstants.AVAILABLE_TO_DATE)));

		Module module = new ObjectMapper().readValue(productDataFromCache.get(ProductDataReadCacheConstants.MODULE),
				Module.class);
		product.setModule(module);
		return product;
	}

	public static APIGatewayProxyRequestEvent getProductEventForTest() {
		APIGatewayProxyRequestEvent singleProductEvent = new APIGatewayProxyRequestEvent();

		Map<String, String> headers = new HashMap<>();
		Map<String, String> productUuidMap = new HashMap<>();
		productUuidMap.put("productUuid", "81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");

		headers.put("transactionId", String.valueOf(UUID.randomUUID()));
		headers.put("correlationId", String.valueOf(UUID.randomUUID()));
		headers.put("xaccessToken", "token");

		singleProductEvent.setPath(GET_SINGLE_PRODUCT);
		singleProductEvent.setHeaders(headers);
		singleProductEvent.setPathParameters(productUuidMap);
		singleProductEvent.setResource(GET_SINGLE_PRODUCT);

		return singleProductEvent;
	}

	public static APIGatewayProxyRequestEvent getAllProductsEventForTest() {
		APIGatewayProxyRequestEvent singleProductEvent = new APIGatewayProxyRequestEvent();

		Map<String, String> headers = new HashMap<>();

		headers.put("transactionId", String.valueOf(UUID.randomUUID()));
		headers.put("correlationId", String.valueOf(UUID.randomUUID()));
		headers.put("xaccessToken", "token");

		singleProductEvent.setPath(GET_ALL_PRODUCTS);
		singleProductEvent.setHeaders(headers);
		singleProductEvent.setResource(GET_ALL_PRODUCTS);

		return singleProductEvent;
	}

	public static APIGatewayProxyRequestEvent getAllBookableProductsEventForTest() {
		APIGatewayProxyRequestEvent singleProductEvent = new APIGatewayProxyRequestEvent();

		Map<String, String> headers = new HashMap<>();

		headers.put("transactionId", String.valueOf(UUID.randomUUID()));
		headers.put("correlationId", String.valueOf(UUID.randomUUID()));
		headers.put("xaccessToken", "token");

		singleProductEvent.setPath(GET_BOOKABLE_ALL_PRODUCTS);
		singleProductEvent.setHeaders(headers);
		singleProductEvent.setResource(GET_BOOKABLE_ALL_PRODUCTS);

		return singleProductEvent;
	}

	public static APIGatewayProxyRequestEvent getBookableProductEventForTest() {
		APIGatewayProxyRequestEvent allProductsEventForTest = getProductEventForTest();
		allProductsEventForTest.setPath(GET_ALL_PRODUCTS);
		Map<String, String> eventContext = new HashMap<>();
		eventContext.put("bookable", "true");
		allProductsEventForTest.setQueryStringParameters(eventContext);
		return allProductsEventForTest;
	}

	public static GatewayResponseEntity getSingleProductGatewayResponseEntityForTest() {
		GatewayResponseEntity gatewayResponseEntity = new GatewayResponseEntity();
		gatewayResponseEntity.setBody(getProductForTest());
		gatewayResponseEntity.setStatusCode(HttpStatus.SC_OK);

		return gatewayResponseEntity;
	}

	public static SingleProduct getProductForTest() {
		SingleProduct product = new SingleProduct();
		Module module = new Module();
		product.setProductUuid(UUID.fromString("81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498"));
		product.setLegacyProductId("D901");
		product.setApprovalRequired(true);
		product.setComponent(SingleProduct.ComponentEnum.valueOf("W"));
		product.setDescription("product description");
		product.setName("IELTS Online AC");

		module.setDescription("Academic");
		module.setModuleType("AC");
		module.setModuleTypeUuid(UUID.fromString("98728fc7-fa65-4757-85e4-90aa022f2816"));

		product.setModule(module);
		product.setProductCharacteristics("{\\\"characteristics\\\":[\\\"IOL\\\",\\\"IOC\\\"]}");
		product.setDuration(String.valueOf(60));
		product.setAvailableFrom(LocalDate.parse("2022-01-01"));
		product.setAvailableTo(LocalDate.parse("2099-12-31"));
		product.setBookable(true);
		product.setFormat("CD");

		return product;
	}

	public static List<SingleProduct> getAllProductsForTest() {
		List<SingleProduct> productList = new ArrayList<>();
		SingleProduct product = getProductForTest();
		product.setBookable(false);
		productList.add(getProductForTest());
		return productList;
	}

	public static List<SingleProduct> getAllBookableProductsForTest() {
		List<SingleProduct> productList = new ArrayList<>();
		productList.add(getProductForTest());
		return productList;
	}

	public static ObjectMapper getMapperWithProperties() {
		final ObjectMapper mapper = new ObjectMapper();
		mapper.registerModule(new JavaTimeModule());
		mapper.configure(DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE, false);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
		mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
		mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
		return mapper;
	}
}
