package com.ielts.cmds.integration.cache.constants;

public class ProductDataReadCacheConstants {

	private ProductDataReadCacheConstants() {
	}

	public static final String PRODUCT_DATA_READ_CACHE_LAMBDA = "ProductDataReadCache Lambda";

	public static final String REDIS_ELASTIC_CACHE_HOST = "redis_elasticache_host";
	public static final String REDIS_ELASTIC_CACHE_PORT = "redis_elasticache_port";
	public static final String IS_CLUSTER_MODE_ENABLED = "is_cluster_mode_enabled";
	public static final String DEFAULT_REDIS_ELASTIC_CACHE_PORT = "6379";
	public static final String UI_DOMAIN = "ui_domain";

	public static final String KEY_OF_ALL_PRODUCTS = "reference:products:v1:all-products";
	public static final String KEY_OF_ALL_BOOKABLE_PRODUCTS = "reference:products:v1:bookable-products";

	public static final String PRODUCT_UUID = "productUuid";
	public static final String PARENT_PRODUCT_UUID = "parentProductUuid";
	public static final String LEGACY_PRODUCT_ID = "legacyProductId";
	public static final String MODULE = "module";
	public static final String NAME = "name";
	public static final String DESCRIPTION = "description";
	public static final String BOOKABLE = "bookable";
	public static final String DURATION = "duration";
	public static final String PRODUCT_CHARACTERISTICS = "productCharacteristics";
	public static final String FORMAT = "format";
	public static final String COMPONENT = "component";
	public static final String APPROVAL_REQUIRED = "approvalRequired";
	public static final String AVAILABLE_FROM_DATE = "availableFromDate";
	public static final String AVAILABLE_TO_DATE = "availableToDate";
	public static final String GET = "GET";

	//	API Endpoints
	public static final String GET_SINGLE_PRODUCT = "/v2/products/{productUuid}";
	public static final String GET_ALL_PRODUCTS = "/v2/products";
	public static final String GET_BOOKABLE_ALL_PRODUCTS = "/v2/products?bookable";


	// Error Codes
	public static final String V1001 = "V1001";
	public static final String V1001_ERROR_MSG = "Product read operation failed due to technical failure";
}
