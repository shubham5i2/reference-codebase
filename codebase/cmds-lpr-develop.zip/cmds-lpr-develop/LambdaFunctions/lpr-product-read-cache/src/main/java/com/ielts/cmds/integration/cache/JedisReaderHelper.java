package com.ielts.cmds.integration.cache;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.common.product_ui_client.Module;
import com.ielts.cmds.api.common.product_ui_client.SingleProduct;
import com.ielts.cmds.integration.cache.constants.ProductDataReadCacheConstants;
import org.apache.commons.lang.StringUtils;

import java.time.LocalDate;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

public class JedisReaderHelper {

    public SingleProduct mapHashMapToProductResponse(Map<String, String> productDataFromCache)
            throws JsonProcessingException {

        SingleProduct product = new SingleProduct();
        Optional.ofNullable(productDataFromCache.get(ProductDataReadCacheConstants.PRODUCT_UUID))
                .ifPresent(productUuid -> product.setProductUuid(UUID.fromString(productUuid)));
        Optional.ofNullable(productDataFromCache.get(ProductDataReadCacheConstants.PARENT_PRODUCT_UUID))
                .ifPresent(parentProductUuid -> product.setParentProductUuid(UUID.fromString(parentProductUuid)));
        String legacyProductId = productDataFromCache.get(
				ProductDataReadCacheConstants.LEGACY_PRODUCT_ID);
        product.setLegacyProductId(
                StringUtils
                        .isNotBlank(legacyProductId) ? legacyProductId : null);
        product.setName(productDataFromCache.get(ProductDataReadCacheConstants.NAME));
        String description = productDataFromCache.get(ProductDataReadCacheConstants.DESCRIPTION);
        product.setDescription(StringUtils
				.isNotBlank(description) ? description : null);
        String productCharacteristics = productDataFromCache.get(ProductDataReadCacheConstants.PRODUCT_CHARACTERISTICS);
        product.setProductCharacteristics(StringUtils
                .isNotBlank(productCharacteristics) ? productCharacteristics : null);
        Optional.ofNullable(productDataFromCache.get(ProductDataReadCacheConstants.BOOKABLE))
                .ifPresent(bookable -> product.setBookable(Boolean.valueOf(bookable)));
        String component = productDataFromCache.get(ProductDataReadCacheConstants.COMPONENT);
        if (Objects.nonNull(component) && StringUtils.isNotBlank(component)) {
            product.setComponent(SingleProduct.ComponentEnum.valueOf(component));
        }
        Optional.ofNullable(productDataFromCache.get(ProductDataReadCacheConstants.DURATION))
                .ifPresent(product::setDuration);
        product.setFormat(productDataFromCache.get(ProductDataReadCacheConstants.FORMAT));
        Optional.ofNullable(productDataFromCache.get(ProductDataReadCacheConstants.APPROVAL_REQUIRED))
                .ifPresent(approvalRequired -> product.setApprovalRequired(Boolean.valueOf(approvalRequired)));
        Optional.ofNullable(productDataFromCache.get(ProductDataReadCacheConstants.AVAILABLE_FROM_DATE))
                .ifPresent(availableFromDate -> product.setAvailableFrom(LocalDate.parse(availableFromDate)));
        Optional.ofNullable(productDataFromCache.get(ProductDataReadCacheConstants.AVAILABLE_TO_DATE))
                .ifPresent(availableToDate -> product.setAvailableTo(LocalDate.parse(availableToDate)));

        if (productDataFromCache.get(ProductDataReadCacheConstants.MODULE) != null) {
            Module module = new ObjectMapper().readValue(productDataFromCache.get(ProductDataReadCacheConstants.MODULE),
                    Module.class);
            product.setModule(module);
        }

        return product;
    }
}
