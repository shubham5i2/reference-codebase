package com.ielts.cmds.integration.cache;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.common.product_ui_client.SingleProduct;
import com.ielts.cmds.integration.cache.constants.ProductDataReadCacheConstants;

import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.JedisCluster;

@Slf4j
public class JedisClusterCacheReader implements JedisGenericReader {

	private JedisCluster jedisCluster;

	private JedisReaderHelper readerHelper;

	public JedisClusterCacheReader(JedisReaderHelper readerHelper, JedisCluster jedisCluster) {
		this.jedisCluster = jedisCluster;
		this.readerHelper = readerHelper;
	}

	@Override
	public Optional<SingleProduct> retrieveSingleProductDataFromRedisCache(String key) throws JsonProcessingException {
		String productKey = String.join("-", "product", key);
		log.debug("product key in cluster {}", productKey);
		return retrieveProductDataFromHashMap(productKey);
	}

	@Override
	public List<SingleProduct> retrieveAllBookableProductsDataFromRedisCache() throws JsonProcessingException {
		return getProductDataByKeyOfSet(ProductDataReadCacheConstants.KEY_OF_ALL_BOOKABLE_PRODUCTS);
	}

	@Override
	public List<SingleProduct> retrieveAllProductsDataFromRedisCache() throws JsonProcessingException {
		return getProductDataByKeyOfSet(ProductDataReadCacheConstants.KEY_OF_ALL_PRODUCTS);
	}

	private List<SingleProduct> getProductDataByKeyOfSet(String keyOfSet) throws JsonProcessingException {
		Set<String> allProductsKeys = jedisCluster.smembers(keyOfSet);
		if (allProductsKeys.isEmpty()) {
			return new ArrayList<>();
		} else {
			log.debug("Products keys :{} from Set :{} ", allProductsKeys, keyOfSet);
			List<SingleProduct> listOfAllProducts = new ArrayList<>();
			for (String productKey : allProductsKeys) {
				Optional<SingleProduct> productData = retrieveProductDataFromHashMap(productKey);
				productData.ifPresent(listOfAllProducts::add);
			}
			return listOfAllProducts;
		}
	}

	private Optional<SingleProduct> retrieveProductDataFromHashMap(String productKey) throws JsonProcessingException {
		Map<String, String> productDataFromCache = jedisCluster.hgetAll(productKey);
		if (productDataFromCache.isEmpty()) {
			return Optional.empty();
		} else {
			return Optional.ofNullable(readerHelper.mapHashMapToProductResponse(productDataFromCache));
		}
	}
}
