package com.ielts.cmds.integration.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.Map;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class GatewayResponseEntity {

	private int statusCode;
	private boolean isBase64Encoded;
	private Map<String, String> headers;
	private GatewayErrorEntity error;
	private Object body;

}