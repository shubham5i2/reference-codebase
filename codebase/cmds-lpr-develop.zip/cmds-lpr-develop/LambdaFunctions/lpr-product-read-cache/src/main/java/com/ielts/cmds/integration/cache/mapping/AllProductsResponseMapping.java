package com.ielts.cmds.integration.cache.mapping;

import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyRequestEvent;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.common.product_ui_client.SingleProduct;
import com.ielts.cmds.integration.cache.JedisGenericReader;
import com.ielts.cmds.integration.cache.factory.JedisFactory;
import com.ielts.cmds.integration.response.GatewayResponseEntity;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;

import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;

import java.util.List;


@Slf4j
@NoArgsConstructor
public class AllProductsResponseMapping implements IServiceV2<APIGatewayProxyRequestEvent, GatewayResponseEntity>,Mapper {

    private JedisGenericReader jedisReader;

    private final JedisFactory jedisFactory = new JedisFactory();


    @Override
    public GatewayResponseEntity process(APIGatewayProxyRequestEvent requestEvent) {
        log.info("inside all products response mapping...");
        GatewayResponseEntity gatewayResponseEntity = new GatewayResponseEntity();
        try {
            jedisReader = jedisFactory.getJedisReader();
            mapAllProductsResponseBody(gatewayResponseEntity);
        } catch (Exception exception) {
            log.error("Exception occurred while doing product read operation {}", exception);
            buildGatewayErrorResponse(gatewayResponseEntity);
        }
        log.debug("gatewayResponseEntity {}", gatewayResponseEntity);
        return gatewayResponseEntity;
    }

    protected void mapAllProductsResponseBody(final GatewayResponseEntity gateWayResponseEntity) throws JsonProcessingException {
        List<SingleProduct> products = jedisReader.retrieveAllProductsDataFromRedisCache();
        if (products.isEmpty()) {
            gateWayResponseEntity.setStatusCode(HttpStatus.SC_NO_CONTENT);
        } else {
            gateWayResponseEntity.setStatusCode(HttpStatus.SC_OK);
            gateWayResponseEntity.setBody(getMapperWithProperties().writeValueAsString(products));
        }
    }
}
