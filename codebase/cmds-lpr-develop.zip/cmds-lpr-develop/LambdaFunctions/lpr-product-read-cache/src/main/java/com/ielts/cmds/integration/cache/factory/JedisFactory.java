package com.ielts.cmds.integration.cache.factory;

import java.net.URI;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import com.ielts.cmds.integration.cache.JedisCacheReader;
import com.ielts.cmds.integration.cache.JedisClusterCacheReader;
import com.ielts.cmds.integration.cache.JedisGenericReader;
import com.ielts.cmds.integration.cache.JedisReaderHelper;
import com.ielts.cmds.integration.cache.constants.ProductDataReadCacheConstants;

import redis.clients.jedis.DefaultJedisClientConfig;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

public class JedisFactory {

	public String getRedisCacheHost() {
		return System.getenv(ProductDataReadCacheConstants.REDIS_ELASTIC_CACHE_HOST);
	}

	public String getRedisCachePort() {
		return Optional.ofNullable(System.getenv(ProductDataReadCacheConstants.REDIS_ELASTIC_CACHE_PORT))
				.orElse(ProductDataReadCacheConstants.DEFAULT_REDIS_ELASTIC_CACHE_PORT);
	}

	public boolean isClusterModeEnabled() {
		String isClusterModeEnabled = System.getenv(ProductDataReadCacheConstants.IS_CLUSTER_MODE_ENABLED);
		return Boolean.valueOf(isClusterModeEnabled);
	}

	public JedisCluster getJedisClusterInstance() {
		Set<HostAndPort> jedisClusterNodes = new HashSet<>();
		jedisClusterNodes.add(new HostAndPort(getRedisCacheHost(), Integer.parseInt(getRedisCachePort())));
		return new JedisCluster(jedisClusterNodes, DefaultJedisClientConfig.builder().ssl(true).build());
	}

	public JedisPool getJedisPoolInstance() {
		final JedisPoolConfig poolConfig = buildPoolConfig();
		String redisEndpointUrl = getRedisCacheHost() + ":" + getRedisCachePort();
		return new JedisPool(poolConfig, URI.create("rediss://" + redisEndpointUrl));
	}

	public JedisPoolConfig buildPoolConfig() {
		final JedisPoolConfig poolConfig = new JedisPoolConfig();
		poolConfig.setMaxTotal(2);
		poolConfig.setMaxIdle(1);
		return poolConfig;
	}

	public JedisGenericReader getJedisReader() {
		boolean isClusterModeEnabled = isClusterModeEnabled();
		if (isClusterModeEnabled) {
			return new JedisClusterCacheReader(new JedisReaderHelper(), getJedisClusterInstance());
		} else {
			return new JedisCacheReader(new JedisReaderHelper(), getJedisPoolInstance());
		}
	}
}
