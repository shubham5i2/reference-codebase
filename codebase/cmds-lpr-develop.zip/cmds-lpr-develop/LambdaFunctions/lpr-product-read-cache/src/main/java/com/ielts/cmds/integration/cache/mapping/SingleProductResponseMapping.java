package com.ielts.cmds.integration.cache.mapping;

import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyRequestEvent;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.common.product_ui_client.SingleProduct;
import com.ielts.cmds.integration.cache.JedisGenericReader;
import com.ielts.cmds.integration.cache.factory.JedisFactory;
import com.ielts.cmds.integration.response.GatewayResponseEntity;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;

import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;

import java.util.Optional;


@Slf4j
@NoArgsConstructor
public class SingleProductResponseMapping implements IServiceV2<APIGatewayProxyRequestEvent, GatewayResponseEntity>, Mapper {

    private JedisFactory jedisFactory = new JedisFactory();

    private JedisGenericReader jedisReader;


    @Override
    public GatewayResponseEntity process(APIGatewayProxyRequestEvent requestEvent) {
        log.info("inside individual product response mapping...");
        GatewayResponseEntity gatewayResponseEntity = new GatewayResponseEntity();
        try {
            jedisReader = jedisFactory.getJedisReader();
            mapSingleProductResponseBody(requestEvent, gatewayResponseEntity);
        } catch (Exception exception) {
            log.error("Exception occurred while doing product read operation {}", exception);
            buildGatewayErrorResponse(gatewayResponseEntity);
        }
        log.debug("gatewayResponseEntity {}", gatewayResponseEntity);
        return gatewayResponseEntity;
    }

    protected void mapSingleProductResponseBody(final APIGatewayProxyRequestEvent requestEvent, final GatewayResponseEntity gatewayResponseEntity) throws JsonProcessingException {
        Optional<SingleProduct> singleProductResponse = jedisReader.retrieveSingleProductDataFromRedisCache(requestEvent.getPathParameters().get("productUuid"));
        if (singleProductResponse.isPresent()) {
            gatewayResponseEntity.setStatusCode(HttpStatus.SC_OK);
            gatewayResponseEntity.setBody(getMapperWithProperties().writeValueAsString(singleProductResponse.get()));
        } else {
            gatewayResponseEntity.setStatusCode(HttpStatus.SC_NO_CONTENT);
        }
    }
}
