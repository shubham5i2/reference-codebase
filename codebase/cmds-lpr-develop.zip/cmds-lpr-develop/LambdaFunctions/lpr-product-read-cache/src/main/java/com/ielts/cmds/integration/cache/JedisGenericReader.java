package com.ielts.cmds.integration.cache;

import java.util.List;
import java.util.Optional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.common.product_ui_client.SingleProduct;

public interface JedisGenericReader {

	Optional<SingleProduct> retrieveSingleProductDataFromRedisCache(String productKey) throws JsonProcessingException;

	List<SingleProduct> retrieveAllBookableProductsDataFromRedisCache() throws JsonProcessingException;

	List<SingleProduct> retrieveAllProductsDataFromRedisCache() throws JsonProcessingException;
}