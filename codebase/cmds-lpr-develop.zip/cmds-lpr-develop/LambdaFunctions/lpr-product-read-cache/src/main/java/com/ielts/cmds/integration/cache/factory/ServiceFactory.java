package com.ielts.cmds.integration.cache.factory;

import com.ielts.cmds.integration.cache.mapping.AllProductsResponseMapping;
import com.ielts.cmds.integration.cache.mapping.BookableProductsResponseMapping;
import com.ielts.cmds.integration.cache.mapping.SingleProductResponseMapping;
import com.ielts.cmds.serialization.lambda.dist.ui.service.AbstractServiceFactoryV2;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;

import java.util.HashMap;
import java.util.Map;

import static com.ielts.cmds.integration.cache.constants.ProductDataReadCacheConstants.GET_ALL_PRODUCTS;
import static com.ielts.cmds.integration.cache.constants.ProductDataReadCacheConstants.GET_BOOKABLE_ALL_PRODUCTS;
import static com.ielts.cmds.integration.cache.constants.ProductDataReadCacheConstants.GET_SINGLE_PRODUCT;

public class ServiceFactory extends AbstractServiceFactoryV2 {

	@SuppressWarnings("rawtypes")
    private static final Map<String, IServiceV2> mapServices = new HashMap<>();

    static {
    mapServices.put(GET_SINGLE_PRODUCT, new SingleProductResponseMapping());
    mapServices.put(GET_ALL_PRODUCTS, new AllProductsResponseMapping());
    mapServices.put(GET_BOOKABLE_ALL_PRODUCTS, new BookableProductsResponseMapping());
    }

    public ServiceFactory() {
        super(mapServices);
    }

    @Override
    public <InputType, OutputType> IServiceV2<InputType, OutputType> getService(String eventIdentifier) {
        return mapServices.get(eventIdentifier);
    }

}
