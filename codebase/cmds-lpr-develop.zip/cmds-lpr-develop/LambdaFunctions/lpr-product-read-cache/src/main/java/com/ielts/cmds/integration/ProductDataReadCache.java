package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.cache.constants.ProductDataReadCacheConstants.GET_ALL_PRODUCTS;
import static com.ielts.cmds.integration.cache.constants.ProductDataReadCacheConstants.UI_DOMAIN;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyRequestEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.cache.factory.ServiceFactory;
import com.ielts.cmds.serialization.lambda.dist.ui.service.AbstractServiceFactoryV2;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;

import com.ielts.cmds.integration.cache.constants.ProductDataReadCacheConstants;
import com.ielts.cmds.integration.response.GatewayResponseEntity;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ProductDataReadCache  {


    public GatewayResponseEntity handleRequest(final APIGatewayProxyRequestEvent requestEvent) {
        log.info("request event {}", requestEvent);
        BaseHeader header = new BaseHeader();
        final UUID transactionId = UUID.randomUUID();
        Map<String, String> responseHeaders = new HashMap<>();
        log.debug("request resource {}", buildResource(requestEvent));
        IServiceV2<Object, Object> service = getServiceFactory().getService(buildResource(requestEvent));
        GatewayResponseEntity gatewayResponseEntity = (GatewayResponseEntity) service.process(requestEvent);
        responseHeaders.put("Access-Control-Allow-Origin", System.getenv(UI_DOMAIN));
        gatewayResponseEntity.setHeaders(responseHeaders);
        header.setTransactionId(transactionId);
        log.info(
                "Event Received in {} with metadata as {}", ProductDataReadCacheConstants.PRODUCT_DATA_READ_CACHE_LAMBDA, header);
        return gatewayResponseEntity;
    }

    private String buildResource(final APIGatewayProxyRequestEvent requestEvent) {
        log.debug("request event {}", requestEvent.getResource());
        String resource = GET_ALL_PRODUCTS;
        if (Objects.nonNull(requestEvent.getPathParameters()) && requestEvent.getPathParameters().containsKey("productUuid")) {
            resource = requestEvent.getResource();
        } else if (requestEvent.getResource().equalsIgnoreCase(GET_ALL_PRODUCTS) && Objects.nonNull(requestEvent.getQueryStringParameters())) {
            resource = requestEvent.getResource() + "?bookable";
        } else {
        	return resource;
        }
        return resource;
    }

    public AbstractServiceFactoryV2 getServiceFactory() {
        return new ServiceFactory();
    }
}
