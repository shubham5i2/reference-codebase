package com.ielts.cmds.integration.mapping;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.reference.common.out.event.ResultStatusCommentSearchGeneratedEventV1ResultStatus;
import com.ielts.cmds.reference.common.out.event.ResultStatusLabelSearchGeneratedEventV1ResultStatus;
import com.ielts.cmds.reference.common.out.event.ResultStatusSearchGeneratedEventV1;
import com.ielts.cmds.reference.common.out.socketresponse.ResultStatusCommentDataOutV1;
import com.ielts.cmds.reference.common.out.socketresponse.ResultStatusDataOutV1;
import com.ielts.cmds.reference.common.out.socketresponse.ResultStatusDataOutV1EnvelopeV1;
import com.ielts.cmds.reference.common.out.socketresponse.ResultStatusDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.ResultStatusLabelDataOutV1;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ResultStatusSearchGeneratedEventMapping extends Mapper
    implements IServiceV2<ResultStatusSearchGeneratedEventV1, ResultStatusDataOutV1EnvelopeV1> {

  public ResultStatusDataOutV1List mapRequestEventBodyToResponseBody(
      final ResultStatusSearchGeneratedEventV1 eventBody) {

    return eventBody
        .stream()
        .map(
            resultsStatusType ->
                ResultStatusDataOutV1.builder()
                    .resultsStatusTypeUuid(resultsStatusType.getResultsStatusTypeUuid())
                    .resultsStatusType(resultsStatusType.getResultsStatusType())
                    .effectiveFromDate(resultsStatusType.getEffectiveFromDate())
                    .effectiveToDate(resultsStatusType.getEffectiveToDate())
                    .resultStatusLabels(
                        buildResultStatusLabels(resultsStatusType.getResultStatusLabels()))
                    .build())
        .collect(Collectors.toCollection(ResultStatusDataOutV1List::new));
  }

  public List<ResultStatusLabelDataOutV1> buildResultStatusLabels(
      List<ResultStatusLabelSearchGeneratedEventV1ResultStatus> resultStatusLabels) {
    if (resultStatusLabels == null) {
    	return new ArrayList<>();
    }
    return resultStatusLabels
        .stream()
        .map(
            resultStatusLabel ->
                ResultStatusLabelDataOutV1.builder()
                    .resultStatusLabelUuid(resultStatusLabel.getResultStatusLabelUuid())
                    .resultStatusLabel(resultStatusLabel.getResultStatusLabel())
                    .resultStatusLabelCode(resultStatusLabel.getResultStatusLabelCode())
                    .resultStatusCommentMandatory(
                        resultStatusLabel.getResultStatusCommentMandatory())
                    .resultStatusComments(
                        buildResultStatusComment(resultStatusLabel.getResultStatusComment()))
                    .build())
        .collect(Collectors.toList());
  }

  public List<ResultStatusCommentDataOutV1> buildResultStatusComment(
      List<ResultStatusCommentSearchGeneratedEventV1ResultStatus> resultStatusComments) {
    if (resultStatusComments == null) {
    	return new ArrayList<>();
    }

    return resultStatusComments
        .stream()
        .map(
            resultStatusComment ->
                ResultStatusCommentDataOutV1.builder()
                    .resultsStatusCommentUuid(resultStatusComment.getResultsStatusCommentUuid())
                    .resultStatusCommentCode(resultStatusComment.getResultStatusCommentCode())
                    .resultStatusCommentText(resultStatusComment.getResultStatusCommentText())
                    .build())
        .collect(Collectors.toList());
  }

  @Override
  public ResultStatusDataOutV1EnvelopeV1 process(ResultStatusSearchGeneratedEventV1 eventBody) {
    ResultStatusDataOutV1EnvelopeV1 response = new ResultStatusDataOutV1EnvelopeV1();
    final BaseEventErrors errors = ThreadLocalErrorContext.getContext();
    final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
    if (eventBody != null) {
      final ResultStatusDataOutV1List responseBody = mapRequestEventBodyToResponseBody(eventBody);
      response.setResponse(responseBody);
    }
    response.setMeta(responseHeaders);
    response.setErrors(errors);
    return response;
  }
}
