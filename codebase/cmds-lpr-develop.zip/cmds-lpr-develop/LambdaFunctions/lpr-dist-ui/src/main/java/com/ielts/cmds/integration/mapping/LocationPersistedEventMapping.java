package com.ielts.cmds.integration.mapping;

import java.util.Objects;

import com.ielts.cmds.api.lpr142locationpersisted.LocationPersisted;
import com.ielts.cmds.api.lprws142locationpersisted.LocationPersistResponseV1;
import com.ielts.cmds.api.lprws142locationpersisted.LocationPersistResponseV1Envelope;
import com.ielts.cmds.api.lprws142locationpersisted.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LocationPersistedEventMapping
		implements IServiceV2<LocationPersisted, LocationPersistResponseV1Envelope> {

	public LocationPersistResponseV1 mapRequestEventBodyToResponseBody(LocationPersisted eventBody) {
		LocationPersistResponseV1 locationPersistedResponse = new LocationPersistResponseV1();
		locationPersistedResponse.setLocationUuid(eventBody.getLocationUuid());
		locationPersistedResponse.setLocationName(eventBody.getLocationName());
		locationPersistedResponse.setTestCentreNumber(eventBody.getTestCentreNumber());

		return locationPersistedResponse;
	}

	private SocketResponseMetaDataV1 mapRequestEventHeaderToSocketResponseHeader() {
		final SocketResponseMetaDataV1 responseHeaders = new SocketResponseMetaDataV1();
		if (Objects.nonNull(ThreadLocalHeaderContext.getContext())) {
			responseHeaders.setCorrelationId(ThreadLocalHeaderContext.getContext().getCorrelationId().toString());
			responseHeaders.setConnectionId(ThreadLocalHeaderContext.getContext().getConnectionId());
		}
		return responseHeaders;
	}

	@Override
	public LocationPersistResponseV1Envelope process(LocationPersisted eventBody) {

		LocationPersistResponseV1Envelope response = new LocationPersistResponseV1Envelope();
		if (eventBody != null) {
			final LocationPersistResponseV1 responseBody = mapRequestEventBodyToResponseBody(eventBody);
			response.setResponse(responseBody);
		}
		response.setMeta(mapRequestEventHeaderToSocketResponseHeader());
		return response;
	}
}
