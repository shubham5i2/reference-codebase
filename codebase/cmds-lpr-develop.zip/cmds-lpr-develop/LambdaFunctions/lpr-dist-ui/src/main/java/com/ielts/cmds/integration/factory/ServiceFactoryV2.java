package com.ielts.cmds.integration.factory;

import java.util.HashMap;
import java.util.Map;

import com.ielts.cmds.integration.mapping.AddressTypesSearchResultsGeneratedEventMapping;
import com.ielts.cmds.integration.mapping.ContactTypesSearchResultsGeneratedEventMapping;
import com.ielts.cmds.integration.mapping.CountriesSearchResultsGeneratedEventMapping;
import com.ielts.cmds.integration.mapping.LocationPersistedEventMapping;
import com.ielts.cmds.integration.mapping.LocationRejectedEventMapping;
import com.ielts.cmds.integration.mapping.LocationRetrievedEventMapping;
import com.ielts.cmds.integration.mapping.LocationSearchResultGeneratedEventMapping;
import com.ielts.cmds.integration.mapping.ModuleTypesSearchResultsGeneratedEventMapping;
import com.ielts.cmds.integration.mapping.NoteTypesSearchResultsGeneratedEventMapping;
import com.ielts.cmds.integration.mapping.OrganisationTypesSearchResultsGeneratedEventMapping;
import com.ielts.cmds.integration.mapping.PartnerCodesSearchResultsGeneratedEventMapping;
import com.ielts.cmds.integration.mapping.ProductChangeRejectedEventMapping;
import com.ielts.cmds.integration.mapping.ProductChangedEventMapping;
import com.ielts.cmds.integration.mapping.ProductsSearchResultsGeneratedEventMapping;
import com.ielts.cmds.integration.mapping.ResultStatusSearchGeneratedEventMapping;
import com.ielts.cmds.integration.mapping.SectorTypesSearchResultsGeneratedEventMapping;
import com.ielts.cmds.integration.mapping.TerritoriesSearchResultsGeneratedEventMapping;
import com.ielts.cmds.serialization.lambda.dist.ui.service.AbstractServiceFactoryV2;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;

public class ServiceFactoryV2 extends AbstractServiceFactoryV2 {

	 @SuppressWarnings("rawtypes")
	    private static final Map<String, IServiceV2> mapServices = new HashMap<>();

    static {
    	mapServices.put(
                "CountriesSearchResultsGenerated",
                new CountriesSearchResultsGeneratedEventMapping());
        mapServices.put(
                "TerritoriesSearchResultsGenerated",
                new TerritoriesSearchResultsGeneratedEventMapping());
        mapServices.put(
                "NoteTypesSearchResultsGenerated",
                new NoteTypesSearchResultsGeneratedEventMapping());
        mapServices.put(
                "PartnerCodesSearchResultsGenerated",
                new PartnerCodesSearchResultsGeneratedEventMapping());
        mapServices.put(
                "SectorTypesSearchResultsGenerated",
                new SectorTypesSearchResultsGeneratedEventMapping());
        mapServices.put(
                "OrganisationTypesSearchResultsGenerated",
                new OrganisationTypesSearchResultsGeneratedEventMapping());
        mapServices.put(
                "ModuleTypesSearchResultsGenerated",
                new ModuleTypesSearchResultsGeneratedEventMapping());
        mapServices.put(
                "ContactTypesSearchResultsGenerated",
                new ContactTypesSearchResultsGeneratedEventMapping());
        mapServices.put(
                "AddressTypesSearchResultsGenerated",
                new AddressTypesSearchResultsGeneratedEventMapping());
        mapServices.put(
                "ProductsSearchResultsGenerated", new ProductsSearchResultsGeneratedEventMapping());
        mapServices.put(
                "ResultStatusSearchGenerated", new ResultStatusSearchGeneratedEventMapping());
        mapServices.put(
                "LocationSearchResultGenerated", new LocationSearchResultGeneratedEventMapping());
        mapServices.put("LocationRetrieved", new LocationRetrievedEventMapping());
       mapServices.put("LocationRetrievalFailed", new LocationRetrievedEventMapping());
       mapServices.put("LocationPersisted", new LocationPersistedEventMapping());
       mapServices.put("LocationRejected", new LocationRejectedEventMapping());
       mapServices.put("ProductChanged", new ProductChangedEventMapping());
       mapServices.put("ProductChangeRejected", new ProductChangeRejectedEventMapping());
       mapServices.put("ProductPersisted", new ProductChangedEventMapping());
    }

    public ServiceFactoryV2() {
        super(mapServices);
    }

	@SuppressWarnings("unchecked")
	@Override
	public <InputType, OutputType> IServiceV2<InputType, OutputType> getService(String eventIdentifier) {
		return mapServices.get(eventIdentifier);
	}

}
