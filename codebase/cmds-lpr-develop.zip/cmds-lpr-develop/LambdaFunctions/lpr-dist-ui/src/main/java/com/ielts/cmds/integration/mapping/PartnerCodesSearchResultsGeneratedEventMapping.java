package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.reference.common.out.event.PartnerCodesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.event.PartnerCodesSearchResultsGeneratedEventV1EnvelopePartnerCode;
import com.ielts.cmds.reference.common.out.socketresponse.PartnersDataOutV1;
import com.ielts.cmds.reference.common.out.socketresponse.PartnersDataOutV1Envelope;
import com.ielts.cmds.reference.common.out.socketresponse.PartnersDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

public class PartnerCodesSearchResultsGeneratedEventMapping extends Mapper
    implements IServiceV2<PartnerCodesSearchResultsGeneratedEventV1, PartnersDataOutV1Envelope> {

  public PartnersDataOutV1List mapRequestEventBodyToResponseBody(
      final PartnerCodesSearchResultsGeneratedEventV1 eventBody) {
    PartnersDataOutV1List partnersDataOutList = new PartnersDataOutV1List();
    for (PartnerCodesSearchResultsGeneratedEventV1EnvelopePartnerCode partnerCode : eventBody) {
      PartnersDataOutV1 partnerCodesDataOut = new PartnersDataOutV1();
      partnerCodesDataOut.setPartnerUuid(partnerCode.getPartnerUuid());
      partnerCodesDataOut.setPartnerCode(partnerCode.getPartnerCode());
      partnerCodesDataOut.setPartnerName(partnerCode.getPartnerName());
      partnerCodesDataOut.setEffectiveFromDate(partnerCode.getEffectiveFromDate());
      partnerCodesDataOut.setEffectiveToDate(partnerCode.getEffectiveToDate());
      partnersDataOutList.add(partnerCodesDataOut);
    }
    return partnersDataOutList;
  }

  @Override
  public PartnersDataOutV1Envelope process(PartnerCodesSearchResultsGeneratedEventV1 eventBody) {
    PartnersDataOutV1Envelope response = new PartnersDataOutV1Envelope();
    final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
    final BaseEventErrors errors = ThreadLocalErrorContext.getContext();
    if (eventBody != null) {
      final PartnersDataOutV1List responseBody = mapRequestEventBodyToResponseBody(eventBody);
      response.setResponse(responseBody);
    }
    response.setMeta(responseHeaders);
    response.setErrors(errors);
    return response;
  }
}
