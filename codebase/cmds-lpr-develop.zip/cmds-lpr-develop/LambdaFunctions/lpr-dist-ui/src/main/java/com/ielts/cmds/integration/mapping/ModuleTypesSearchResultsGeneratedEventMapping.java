package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.reference.common.out.event.ModuleTypesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.event.ModuleTypesSearchResultsGeneratedEventV1ModuleType;
import com.ielts.cmds.reference.common.out.socketresponse.ModuleTypesDataOutV1;
import com.ielts.cmds.reference.common.out.socketresponse.ModuleTypesDataOutV1Envelope;
import com.ielts.cmds.reference.common.out.socketresponse.ModuleTypesDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

public class ModuleTypesSearchResultsGeneratedEventMapping extends Mapper
    implements IServiceV2<ModuleTypesSearchResultsGeneratedEventV1, ModuleTypesDataOutV1Envelope> {

  public ModuleTypesDataOutV1List mapRequestEventBodyToResponseBody(
      final ModuleTypesSearchResultsGeneratedEventV1 eventBody) {
    ModuleTypesDataOutV1List moduleTypesDataOutList = new ModuleTypesDataOutV1List();
    for (ModuleTypesSearchResultsGeneratedEventV1ModuleType moduleType : eventBody) {
      ModuleTypesDataOutV1 moduleTypeDataOut = new ModuleTypesDataOutV1();
      moduleTypeDataOut.setModuleTypeUuid(moduleType.getModuleTypeUuid());
      moduleTypeDataOut.setModuleType(moduleType.getModuleType());
      moduleTypeDataOut.setDescription(moduleType.getDescription());
      moduleTypeDataOut.setEffectiveFromDate(moduleType.getEffectiveFromDate());
      moduleTypeDataOut.setEffectiveToDate(moduleType.getEffectiveToDate());
      moduleTypesDataOutList.add(moduleTypeDataOut);
    }
    return moduleTypesDataOutList;
  }

  @Override
  public ModuleTypesDataOutV1Envelope process(ModuleTypesSearchResultsGeneratedEventV1 eventBody) {
    ModuleTypesDataOutV1Envelope response = new ModuleTypesDataOutV1Envelope();
    final BaseEventErrors errors = ThreadLocalErrorContext.getContext();
    final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
    if (eventBody != null) {
      final ModuleTypesDataOutV1List responseBody = mapRequestEventBodyToResponseBody(eventBody);
      response.setResponse(responseBody);
    }
    response.setMeta(responseHeaders);
    response.setErrors(errors);
    return response;
  }
}
