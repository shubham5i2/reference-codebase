package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.api.lprws154productchangerejected.BaseEventErrors;
import com.ielts.cmds.api.lprws154productchangerejected.BaseEventErrorsErrorListInner;
import com.ielts.cmds.api.lprws154productchangerejected.ProductChangeRejectedV1Envelope;
import com.ielts.cmds.api.lprws154productchangerejected.SocketResponseMetaDataV1;
import com.ielts.cmds.api.lpr154productchangerejected.ProductChangeRejected;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;

@Slf4j
public class ProductChangeRejectedEventMapping
    implements IServiceV2<ProductChangeRejected, ProductChangeRejectedV1Envelope> {
  @Override
  public ProductChangeRejectedV1Envelope process(ProductChangeRejected productChangeRejected) {
    ProductChangeRejectedV1Envelope response = new ProductChangeRejectedV1Envelope();
    final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
    response.setMeta(responseHeaders);
    response.setErrors(getBaseEventErrors(productChangeRejected));
    return response;
  }

  private BaseEventErrors getBaseEventErrors(final ProductChangeRejected productChangeRejected) {
    BaseEventErrors baseEventErrorsOutput = new BaseEventErrors();
    List<BaseEventErrorsErrorListInner> errorList = new ArrayList<>();
    productChangeRejected
        .getErrors()
        .getErrorList()
        .forEach(
            errorDescriptionInput -> {
              BaseEventErrorsErrorListInner errorDescription = new BaseEventErrorsErrorListInner();
              errorDescription.setMessage(errorDescriptionInput.getMessage());
              errorDescription.setInterface(errorDescriptionInput.getInterface());
              errorDescription.setType(BaseEventErrorsErrorListInner.TypeEnum.ERROR);
              errorDescription.setErrorCode(errorDescriptionInput.getErrorCode());
              errorDescription.setTitle(errorDescriptionInput.getTitle());
              errorDescription.setErrorTicketUuid(errorDescriptionInput.getErrorTicketUuid());
              errorDescription.setSource(errorDescription.getSource());
              errorList.add(errorDescription);
            });
    baseEventErrorsOutput.setErrorList(errorList);
    return baseEventErrorsOutput;
  }

  private SocketResponseMetaDataV1 mapRequestEventHeaderToSocketResponseHeader() {
    final SocketResponseMetaDataV1 socketResponseMetaData = new SocketResponseMetaDataV1();
    socketResponseMetaData.setCorrelationId(
        String.valueOf(ThreadLocalHeaderContext.getContext().getCorrelationId()));
    socketResponseMetaData.setConnectionId(ThreadLocalHeaderContext.getContext().getConnectionId());
    return socketResponseMetaData;
  }
}
