package com.ielts.cmds.integration.model;

import com.ielts.cmds.lpr.common.out.model.LocationSearchV1;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
public class LocationSearchResultGeneratedEventV2 {

    private LocationSearchV1 search;
    private List<UUID> response;
    private Integer totalCount;

}
