package com.ielts.cmds.integration.mapping;

import java.util.List;
import java.util.Objects;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.lpr.common.out.model.LocationRetrievedEventV1;
import com.ielts.cmds.lpr.common.out.model.ViewLocationAddressV1;
import com.ielts.cmds.lpr.common.out.model.ViewLocationProductV1;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationDataOutV1;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationDataOutV1Address;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationDataOutV1Addresses;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationDataOutV1ApprovedProduct;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationDataOutV1ApprovedProducts;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationDataOutV1Envelope;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationSocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LocationRetrievedEventMapping extends Mapper
    implements IServiceV2<LocationRetrievedEventV1, LocationDataOutV1Envelope> {

  public LocationDataOutV1 mapRequestEventBodyToResponseBody(LocationRetrievedEventV1 eventBody) {

    LocationDataOutV1 locationRequestData = new LocationDataOutV1();

    locationRequestData.setLocationTypeCode(eventBody.getLocationTypeCode());
    locationRequestData.setLocationName(eventBody.getLocationName());
    locationRequestData.setLocationUuid(eventBody.getLocationUuid());
    locationRequestData.setParentLocationUuid(eventBody.getParentLocationUuid());
    locationRequestData.setParentLocationName(eventBody.getParentLocationName());
    locationRequestData.setPartnerCode(eventBody.getPartnerCode());
    locationRequestData.setExternalLocationUuid(eventBody.getExternalLocationUuid());
    locationRequestData.setExternalParentLocationUuid(eventBody.getExternalParentLocationUuid());
    locationRequestData.setTestCentreNumber(eventBody.getTestCentreNumber());
    locationRequestData.setTimezoneName(eventBody.getTimezoneName());
    locationRequestData.setWebsiteURL(eventBody.getWebsiteURL());
    locationRequestData.setActivatedDate(eventBody.getActivatedDate());
    locationRequestData.setEligibleForOfflineTesting(eventBody.getEligibleForOfflineTesting());
    locationRequestData.setLocationStatus(eventBody.getStatus());
    locationRequestData.setLocationAddresses(getLocationAddress(eventBody.getAddresses()));
    locationRequestData.setApprovedProducts(getLocationProducts(eventBody.getApprovedProducts()));
    log.info("location data out : {}", locationRequestData);
    return locationRequestData;
  }

  private LocationDataOutV1ApprovedProducts getLocationProducts(
      List<ViewLocationProductV1> approvedProductsList) {

    LocationDataOutV1ApprovedProducts products = new LocationDataOutV1ApprovedProducts();

    approvedProductsList
        .stream()
        .forEach(
            approvedProducts -> {
              LocationDataOutV1ApprovedProduct product = new LocationDataOutV1ApprovedProduct();

              product.setLocationProductAuthorisationUuid(
                  approvedProducts.getLocationProductUuid());
              product.setProductUuid(approvedProducts.getProductUuid());
              product.setProductName(approvedProducts.getProductName());
              product.setEffectiveFromDate(approvedProducts.getEffectiveFromDate());
              product.setEffectiveToDate(approvedProducts.getEffectiveToDate());
              products.add(product);
            });

    return products;
  }

  public LocationDataOutV1Addresses getLocationAddress(
      List<ViewLocationAddressV1> locationAddressesList) {

    LocationDataOutV1Addresses locationAddresses = new LocationDataOutV1Addresses();

    locationAddressesList
        .stream()
        .forEach(
            address -> {
              LocationDataOutV1Address locationAddress = new LocationDataOutV1Address();

              locationAddress.setLocationAddressUuid(address.getLocationAddressUuid());
              locationAddress.setAddressTypeUuid(address.getAddressTypeUuid());
              locationAddress.setAddressTypeName(address.getAddressTypeName());
              locationAddress.setAddressLine1(address.getAddressLine1());
              locationAddress.setAddressLine2(address.getAddressLine2());
              locationAddress.setAddressLine3(address.getAddressLine3());
              locationAddress.setAddressLine4(address.getAddressLine4());
              locationAddress.setCity(address.getCity());
              locationAddress.setTerritoryUuid(address.getTerritoryUuid());
              locationAddress.setTerritoryName(address.getTerritoryName());
              locationAddress.setPostalCode(address.getPostalCode());
              locationAddress.setCountryUuid(address.getCountryUuid());
              locationAddress.setCountryName(address.getCountryName());
              locationAddress.setCountryIso3Code(address.getCountryIso3Code());
              locationAddress.setEmail(address.getEmail());
              locationAddress.setPrimaryPhone(address.getPrimaryPhone());
              locationAddress.setSecondaryPhone(address.getSecondaryPhone());
              locationAddress.setEffectiveFromDate(address.getEffectiveFromDate());
              locationAddress.setEffectiveToDate(address.getEffectiveToDate());
              locationAddresses.add(locationAddress);
            });
    return locationAddresses;
  }

  @Override
  public LocationDataOutV1Envelope process(LocationRetrievedEventV1 eventBody) {
    LocationDataOutV1Envelope response = new LocationDataOutV1Envelope();
    final LocationSocketResponseMetaDataV1 responseHeaders =
        locationMapRequestEventHeaderToSocketResponseHeader();
    final BaseEventErrors errors = ThreadLocalErrorContext.getContext();
    LocationDataOutV1 responseBody = new LocationDataOutV1();
    if (Objects.isNull(errors)) {
      responseBody = mapRequestEventBodyToResponseBody(eventBody);
    }
    response.setMeta(responseHeaders);
    response.setResponse(responseBody);
    response.setErrors(errors);
    return response;
  }
}
