package com.ielts.cmds.integration.mapping;

import com.amazonaws.services.s3.model.S3Object;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.ielts.cmds.common.config.s3.DefaultS3ClientConfiguration;
import com.ielts.cmds.common.config.s3.DefaultS3PresignerConfiguration;
import com.ielts.cmds.common.utils.s3.CMDSS3Client;
import com.ielts.cmds.common.utils.s3.DefaultCMDSS3Client;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.integration.model.LocationSearchResultGeneratedEventV2;
import com.ielts.cmds.integration.model.LocationSearchResultsV2Envelope;
import com.ielts.cmds.integration.model.LocationSocketResponseMetaDataV2;
import com.ielts.cmds.lpr.common.out.model.LocationSearchResultGeneratedEventV1Basic;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationBasicDataOutV1;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationSearchResultsV1List;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.mapper.IObjectMapper;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

import static com.ielts.cmds.integration.constants.LPRDistConstants.LOCATION_S3_BUCKET;
import static com.ielts.cmds.integration.constants.LPRDistConstants.LOCATION_S3_FILE_NAME;

/** The type Location search results generated event mapping. */
@Slf4j
public class LocationSearchResultGeneratedEventMapping extends Mapper
    implements IObjectMapper,
        IServiceV2<LocationSearchResultGeneratedEventV2, LocationSearchResultsV2Envelope> {

  @Override
  public LocationSearchResultsV2Envelope process(LocationSearchResultGeneratedEventV2 eventBody) {
    LocationSearchResultsV2Envelope response = new LocationSearchResultsV2Envelope();
    log.info("eventBody {}", eventBody.getResponse());
    try {
      final BaseEventErrors errors = ThreadLocalErrorContext.getContext();
      log.debug("errors {}", errors);
      if (Objects.isNull(errors)
          && Objects.nonNull(eventBody.getResponse())
          && !eventBody.getResponse().isEmpty()) {
        List<LocationSearchResultGeneratedEventV1Basic> filteredLocations =
            getFilteredLocations(fetchLocationsFromS3(), eventBody.getResponse());
        final LocationSearchResultsV1List responseBody =
            mapRequestEventBodyToResponseBody(filteredLocations);
        response.setMeta(buildResponseHeader(eventBody));
        response.setResponse(responseBody);
      } else {
        response.setResponse(Collections.emptyList());
        response.setErrors(errors);
        response.setMeta(buildResponseHeader(eventBody));
      }
    } catch (IOException exception) {
      log.info(
          "Exception occurred while processing LocationSearchResultGenerated event {}",
          exception.getMessage());
    }
    return response;
  }

  /**
   * fetching locations from s3 bucket.
   *
   * @return the location search results
   */
  public List<LocationSearchResultGeneratedEventV1Basic> fetchLocationsFromS3() throws IOException {
    final CMDSS3Client s3Client = getCmdsS3Client();
    S3Object locationsObject =
        s3Client.getObject(System.getenv(LOCATION_S3_BUCKET), System.getenv(LOCATION_S3_FILE_NAME));
    InputStream locationsObjectContent = locationsObject.getObjectContent();
    CollectionType typReference =
        TypeFactory.defaultInstance()
            .constructCollectionType(List.class, LocationSearchResultGeneratedEventV1Basic.class);
    List<LocationSearchResultGeneratedEventV1Basic> locations =
        getMapperWithProperties().readValue(locationsObjectContent, typReference);
    locationsObject.close();
    return locations;
  }

  /**
   * filtering locations from s3 locations based on location uuid from input.
   *
   * @param locations the event body
   * @param locationUuids the event body
   * @return the filtered locations
   */
  public List<LocationSearchResultGeneratedEventV1Basic> getFilteredLocations(
      final List<LocationSearchResultGeneratedEventV1Basic> locations,
      final List<UUID> locationUuids) {
    return locations
        .stream()
        .filter(location -> locationUuids.contains(location.getLocationUuid()))
        .collect(Collectors.toList());
  }

  /**
   * Map request event body to response body location search results v 1.
   *
   * @param eventBody the event body
   * @return the location search results v2
   */
  public LocationSearchResultsV1List mapRequestEventBodyToResponseBody(
      final List<LocationSearchResultGeneratedEventV1Basic> eventBody) {
    LocationSearchResultsV1List resultsList = new LocationSearchResultsV1List();
    for (LocationSearchResultGeneratedEventV1Basic eventV1ResultBasic : eventBody) {
      LocationBasicDataOutV1 locationBasicDataOutV1 = new LocationBasicDataOutV1();
      locationBasicDataOutV1.setLocationName(eventV1ResultBasic.getLocationName());
      locationBasicDataOutV1.setLocationUuid(eventV1ResultBasic.getLocationUuid());
      locationBasicDataOutV1.setLocationStatus(eventV1ResultBasic.getLocationStatus());
      locationBasicDataOutV1.setTestCentreNumber(eventV1ResultBasic.getTestCentreNumber());
      locationBasicDataOutV1.setLocationTypeCode(eventV1ResultBasic.getLocationTypeCode());
      locationBasicDataOutV1.setCity(eventV1ResultBasic.getCity());
      locationBasicDataOutV1.setCountry(eventV1ResultBasic.getCountry());
      locationBasicDataOutV1.setPartnerCode(eventV1ResultBasic.getPartnerCode());
      resultsList.add(locationBasicDataOutV1);
    }
    return resultsList;
  }

  public LocationSocketResponseMetaDataV2 buildResponseHeader(
      final LocationSearchResultGeneratedEventV2 eventBody) {
    final LocationSocketResponseMetaDataV2 responseHeaders = new LocationSocketResponseMetaDataV2();
    responseHeaders.setConnectionId(ThreadLocalHeaderContext.getContext().getConnectionId());
    responseHeaders.setCorrelationId(
        String.valueOf(ThreadLocalHeaderContext.getContext().getCorrelationId()));
    responseHeaders.setTotalCount(eventBody.getTotalCount());
    return responseHeaders;
  }

  public CMDSS3Client getCmdsS3Client() {
    return new DefaultCMDSS3Client(
        new DefaultS3ClientConfiguration(), new DefaultS3PresignerConfiguration());
  }
}
