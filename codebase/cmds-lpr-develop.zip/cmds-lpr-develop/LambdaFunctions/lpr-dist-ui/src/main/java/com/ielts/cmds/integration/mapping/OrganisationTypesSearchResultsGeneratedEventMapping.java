package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.reference.common.out.event.OrganisationTypesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.event.OrganisationTypesSearchResultsGeneratedEventV1OrganisationType;
import com.ielts.cmds.reference.common.out.socketresponse.OrganisationTypesDataOutV1;
import com.ielts.cmds.reference.common.out.socketresponse.OrganisationTypesDataOutV1Envelope;
import com.ielts.cmds.reference.common.out.socketresponse.OrganisationTypesDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

public class OrganisationTypesSearchResultsGeneratedEventMapping extends Mapper
    implements IServiceV2<
        OrganisationTypesSearchResultsGeneratedEventV1, OrganisationTypesDataOutV1Envelope> {

  public OrganisationTypesDataOutV1List mapRequestEventBodyToResponseBody(
      final OrganisationTypesSearchResultsGeneratedEventV1 eventBody) {
    OrganisationTypesDataOutV1List organisationDataOutList = new OrganisationTypesDataOutV1List();
    for (OrganisationTypesSearchResultsGeneratedEventV1OrganisationType organisation : eventBody) {
      OrganisationTypesDataOutV1 organisationDataOut = new OrganisationTypesDataOutV1();
      organisationDataOut.setOrganisationTypeUuid(organisation.getOrganisationTypeUuid());
      organisationDataOut.setOrganisationType(organisation.getOrganisationType());
      organisationDataOut.setDescription(organisation.getDescription());
      organisationDataOut.setEffectiveFromDate(organisation.getEffectiveFromDate());
      organisationDataOut.setEffectiveToDate(organisation.getEffectiveToDate());
      organisationDataOutList.add(organisationDataOut);
    }
    return organisationDataOutList;
  }

  @Override
  public OrganisationTypesDataOutV1Envelope process(
      OrganisationTypesSearchResultsGeneratedEventV1 eventBody) {
    OrganisationTypesDataOutV1Envelope response = new OrganisationTypesDataOutV1Envelope();
    final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
    final BaseEventErrors errors = ThreadLocalErrorContext.getContext();
    if (eventBody != null) {
      final OrganisationTypesDataOutV1List responseBody =
          mapRequestEventBodyToResponseBody(eventBody);
      response.setResponse(responseBody);
    }
    response.setMeta(responseHeaders);
    response.setErrors(errors);
    return response;
  }
}
