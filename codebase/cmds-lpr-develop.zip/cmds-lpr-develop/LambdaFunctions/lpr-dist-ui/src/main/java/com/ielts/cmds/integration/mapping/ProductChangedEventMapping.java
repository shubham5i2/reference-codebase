package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.api.evt_059.ProductChanged;
import com.ielts.cmds.api.lprws153productchanged.ProductChangeResponseV1;
import com.ielts.cmds.api.lprws153productchanged.ProductChangeResponseV1Envelope;
import com.ielts.cmds.api.lprws153productchanged.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Slf4j
public class ProductChangedEventMapping
    implements IServiceV2<ProductChanged, ProductChangeResponseV1Envelope> {

  private SocketResponseMetaDataV1 mapRequestEventHeaderToSocketResponseHeaders() {
    SocketResponseMetaDataV1 responseHeaders = new SocketResponseMetaDataV1();
    responseHeaders.setConnectionId(ThreadLocalHeaderContext.getContext().getConnectionId());
    responseHeaders.setCorrelationId(
        String.valueOf(ThreadLocalHeaderContext.getContext().getCorrelationId()));
    return responseHeaders;
  }

  private List<ProductChangeResponseV1> mapRequestEventBodyToResponseBody(
      ProductChanged eventBody) {
    List<ProductChangeResponseV1> productChangeResponseV1List = new ArrayList<>();
    ProductChangeResponseV1 productChangeResponseV1 = new ProductChangeResponseV1();
    productChangeResponseV1.setProductUuid(eventBody.getProductUuid());
    productChangeResponseV1.setName(eventBody.getName());
    productChangeResponseV1List.add(productChangeResponseV1);
    return productChangeResponseV1List;
  }

  @Override
  public ProductChangeResponseV1Envelope process(ProductChanged eventBody) {
    ProductChangeResponseV1Envelope response = new ProductChangeResponseV1Envelope();
    final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeaders();
    response.setMeta(responseHeaders);
    if (Objects.nonNull(eventBody)) {
      final List<ProductChangeResponseV1> responseBody =
          mapRequestEventBodyToResponseBody(eventBody);
      response.setResponse(responseBody);
    }
    return response;
  }
}
