package com.ielts.cmds.integration.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class FragmentsRequest {

    private int fragmentsNumber;
    private int totalFragments;
}
