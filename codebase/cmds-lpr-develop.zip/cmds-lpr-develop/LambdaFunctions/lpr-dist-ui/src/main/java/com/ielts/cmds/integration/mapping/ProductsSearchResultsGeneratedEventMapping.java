package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.reference.common.out.event.ProductsSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.event.ProductsSearchResultsGeneratedEventV1Product;
import com.ielts.cmds.reference.common.out.socketresponse.ProductsDataOutV1;
import com.ielts.cmds.reference.common.out.socketresponse.ProductsDataOutV1Envelope;
import com.ielts.cmds.reference.common.out.socketresponse.ProductsDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

public class ProductsSearchResultsGeneratedEventMapping extends Mapper
    implements IServiceV2<ProductsSearchResultsGeneratedEventV1, ProductsDataOutV1Envelope> {

  public ProductsDataOutV1List mapRequestEventBodyToResponseBody(
      final ProductsSearchResultsGeneratedEventV1 eventBody) {
    ProductsDataOutV1List productsDataOutList = new ProductsDataOutV1List();
    for (ProductsSearchResultsGeneratedEventV1Product product : eventBody) {
      ProductsDataOutV1 productsDataOut = new ProductsDataOutV1();
      productsDataOut.setProductUuid(product.getProductUuid());
      productsDataOut.setProductName(product.getProductName());
      productsDataOut.setBookable(product.isBookable());
      productsDataOut.setApprovalRequired(product.isApprovalRequired());
      productsDataOut.setProductStatus(product.getProductStatus());
      productsDataOut.setProductCharacteristics(product.getProductCharacteristics());
      productsDataOut.setEffectiveFromDate(product.getEffectiveFromDate());
      productsDataOut.setEffectiveToDate(product.getEffectiveToDate());
      productsDataOutList.add(productsDataOut);
    }
    return productsDataOutList;
  }

  @Override
  public ProductsDataOutV1Envelope process(ProductsSearchResultsGeneratedEventV1 eventBody) {

    ProductsDataOutV1Envelope response = new ProductsDataOutV1Envelope();
    final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
    final BaseEventErrors errors = ThreadLocalErrorContext.getContext();
    if (eventBody != null) {
      final ProductsDataOutV1List responseBody = mapRequestEventBodyToResponseBody(eventBody);
      response.setResponse(responseBody);
    }
    response.setMeta(responseHeaders);
    response.setErrors(errors);
    return response;
  }
}
