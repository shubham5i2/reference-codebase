package com.ielts.cmds.integration.constants;

/**
 * Constants class for LPR Distributor Lambda
 */

public class LPRDistConstants {

	private LPRDistConstants() {}

	public static final String APPLICATION_NAME = "LPR-DIST-UI-LAMBDA";
	public static final String LOCATIONS_FRAGMENT_SIZE = "locations_fragment_size";
	public static final String LOCATION_S3_BUCKET = "location_s3_bucket";
	public static final String LOCATION_S3_FILE_NAME = "location_s3_file_name";
	public static final String LPR = "LPR";
}
