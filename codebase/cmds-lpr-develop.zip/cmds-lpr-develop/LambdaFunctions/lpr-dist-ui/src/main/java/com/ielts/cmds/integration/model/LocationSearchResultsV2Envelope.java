package com.ielts.cmds.integration.model;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationBasicDataOutV1;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class LocationSearchResultsV2Envelope {

    private LocationSocketResponseMetaDataV2 meta;
    private List<LocationBasicDataOutV1> response;
    private BaseEventErrors errors;
    private FragmentsRequest fragments;

}
