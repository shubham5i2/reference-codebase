package com.ielts.cmds.integration.mapping;

import java.util.ArrayList;
import java.util.List;

import com.ielts.cmds.api.lpr143locationrejected.LocationRejected;
import com.ielts.cmds.api.lprws143locationrejected.BaseEventErrors;
import com.ielts.cmds.api.lprws143locationrejected.BaseEventErrorsErrorListInner;
import com.ielts.cmds.api.lprws143locationrejected.LocationRejectedV1Envelope;
import com.ielts.cmds.api.lprws143locationrejected.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

public class LocationRejectedEventMapping implements IServiceV2<LocationRejected, LocationRejectedV1Envelope> {
	
	@Override
	public LocationRejectedV1Envelope process(LocationRejected locationRejected) {
		LocationRejectedV1Envelope response = new LocationRejectedV1Envelope();
		final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
		response.setMeta(responseHeaders);
		response.setErrors(getBaseEventErrors(locationRejected));
		return response;
	}

	private BaseEventErrors getBaseEventErrors(final LocationRejected locationRejected) {
		BaseEventErrors baseEventErrorsOutput = new BaseEventErrors();
		List<BaseEventErrorsErrorListInner> errorList = new ArrayList<>();
		locationRejected.getErrors().getErrorList().forEach(errorDescriptionInput -> {
			BaseEventErrorsErrorListInner errorDescription = new BaseEventErrorsErrorListInner();
			errorDescription.setMessage(errorDescriptionInput.getMessage());
			errorDescription.setInterface(errorDescriptionInput.getInterface());
			errorDescription.setType(BaseEventErrorsErrorListInner.TypeEnum.ERROR);
			errorDescription.setErrorCode(errorDescriptionInput.getErrorCode());
			errorDescription.setTitle(errorDescriptionInput.getTitle());
			errorDescription.setErrorTicketUuid(errorDescriptionInput.getErrorTicketUuid());
			errorDescription.setSource(errorDescription.getSource());
			errorList.add(errorDescription);
		});
		baseEventErrorsOutput.setErrorList(errorList);
		return baseEventErrorsOutput;
	}

	private SocketResponseMetaDataV1 mapRequestEventHeaderToSocketResponseHeader() {
		final SocketResponseMetaDataV1 socketResponseMetaData = new SocketResponseMetaDataV1();
		socketResponseMetaData
				.setCorrelationId(String.valueOf(ThreadLocalHeaderContext.getContext().getCorrelationId()));
		socketResponseMetaData.setConnectionId(ThreadLocalHeaderContext.getContext().getConnectionId());
		return socketResponseMetaData;
	}
}
