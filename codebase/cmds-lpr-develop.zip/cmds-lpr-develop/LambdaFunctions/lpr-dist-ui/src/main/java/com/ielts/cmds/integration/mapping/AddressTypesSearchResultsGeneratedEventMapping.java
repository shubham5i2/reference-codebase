package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.reference.common.out.event.AddressTypesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.event.AddressTypesSearchResultsGeneratedEventV1AddressType;
import com.ielts.cmds.reference.common.out.socketresponse.AddressTypesDataOutV1;
import com.ielts.cmds.reference.common.out.socketresponse.AddressTypesDataOutV1Envelope;
import com.ielts.cmds.reference.common.out.socketresponse.AddressTypesDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

public class AddressTypesSearchResultsGeneratedEventMapping extends Mapper
    implements IServiceV2<
        AddressTypesSearchResultsGeneratedEventV1, AddressTypesDataOutV1Envelope> {

  public AddressTypesDataOutV1List mapRequestEventBodyToResponseBody(
      final AddressTypesSearchResultsGeneratedEventV1 eventBody) {
    AddressTypesDataOutV1List addressTypesDataOutList = new AddressTypesDataOutV1List();
    for (AddressTypesSearchResultsGeneratedEventV1AddressType addressType : eventBody) {
      AddressTypesDataOutV1 addressTypesDataOut = new AddressTypesDataOutV1();
      addressTypesDataOut.setAddressTypeUuid(addressType.getAddressTypeUuid());
      addressTypesDataOut.setAddressType(addressType.getAddressType());
      addressTypesDataOut.setDescription(addressType.getDescription());
      addressTypesDataOut.setEffectiveFromDate(addressType.getEffectiveFromDate());
      addressTypesDataOut.setEffectiveToDate(addressType.getEffectiveToDate());
      addressTypesDataOutList.add(addressTypesDataOut);
    }
    return addressTypesDataOutList;
  }

  @Override
  public AddressTypesDataOutV1Envelope process(
      AddressTypesSearchResultsGeneratedEventV1 eventBody) {
    AddressTypesDataOutV1Envelope response = new AddressTypesDataOutV1Envelope();
    final BaseEventErrors errors = ThreadLocalErrorContext.getContext();
    final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
    if (eventBody != null) {
      final AddressTypesDataOutV1List responseBody = mapRequestEventBodyToResponseBody(eventBody);
      response.setResponse(responseBody);
    }
    response.setMeta(responseHeaders);
    response.setErrors(errors);
    return response;
  }
}
