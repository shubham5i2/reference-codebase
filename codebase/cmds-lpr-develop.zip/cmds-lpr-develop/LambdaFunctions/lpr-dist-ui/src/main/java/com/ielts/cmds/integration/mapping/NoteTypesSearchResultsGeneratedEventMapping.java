package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.reference.common.out.event.NoteTypesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.event.NoteTypesSearchResultsGeneratedEventV1NoteType;
import com.ielts.cmds.reference.common.out.socketresponse.NoteTypesDataOutV1;
import com.ielts.cmds.reference.common.out.socketresponse.NoteTypesDataOutV1Envelope;
import com.ielts.cmds.reference.common.out.socketresponse.NoteTypesDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

public class NoteTypesSearchResultsGeneratedEventMapping extends Mapper
    implements IServiceV2<NoteTypesSearchResultsGeneratedEventV1, NoteTypesDataOutV1Envelope> {

  public NoteTypesDataOutV1List mapRequestEventBodyToResponseBody(
      final NoteTypesSearchResultsGeneratedEventV1 eventBody) {
    NoteTypesDataOutV1List noteTypeDataOutList = new NoteTypesDataOutV1List();
    for (NoteTypesSearchResultsGeneratedEventV1NoteType noteType : eventBody) {
      NoteTypesDataOutV1 noteTypeDataOut = new NoteTypesDataOutV1();
      noteTypeDataOut.setNoteTypeUuid(noteType.getNoteTypeUuid());
      noteTypeDataOut.setNoteType(noteType.getNoteType());
      noteTypeDataOut.setDescription(noteType.getDescription());
      noteTypeDataOut.setEffectiveFromDate(noteType.getEffectiveFromDate());
      noteTypeDataOut.setEffectiveToDate(noteType.getEffectiveToDate());
      noteTypeDataOutList.add(noteTypeDataOut);
    }
    return noteTypeDataOutList;
  }

  @Override
  public NoteTypesDataOutV1Envelope process(NoteTypesSearchResultsGeneratedEventV1 eventBody) {
    NoteTypesDataOutV1Envelope response = new NoteTypesDataOutV1Envelope();
    final BaseEventErrors errors = ThreadLocalErrorContext.getContext();
    final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
    if (eventBody != null) {
      final NoteTypesDataOutV1List responseBody = mapRequestEventBodyToResponseBody(eventBody);
      response.setResponse(responseBody);
    }
    response.setMeta(responseHeaders);
    response.setErrors(errors);
    return response;
  }
}
