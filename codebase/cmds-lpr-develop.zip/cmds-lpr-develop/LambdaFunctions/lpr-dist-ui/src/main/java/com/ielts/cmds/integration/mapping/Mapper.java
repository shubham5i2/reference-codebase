package com.ielts.cmds.integration.mapping;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.common.logger.util.CMDSLambdaLoggerUtil;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationSocketResponseMetaDataV1;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

public abstract class Mapper {

  protected final ObjectMapper objectMapper = new ObjectMapper();

  protected final CMDSLambdaLoggerUtil loggerUtil = new CMDSLambdaLoggerUtil();

  protected Mapper() {
    objectMapper.registerModule(new JavaTimeModule());
    objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    objectMapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
    objectMapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
  }

  /**
   * Maps Request EventHeader to Socket Response EventHeader.
   *
   * @param uiCMDSEvent
   */
  public LocationSocketResponseMetaDataV1 locationMapRequestEventHeaderToSocketResponseHeader() {
    final LocationSocketResponseMetaDataV1 responseHeaders = new LocationSocketResponseMetaDataV1();
    responseHeaders.setCorrelationId(
        String.valueOf(ThreadLocalHeaderContext.getContext().getCorrelationId()));
    responseHeaders.setConnectionId(ThreadLocalHeaderContext.getContext().getConnectionId());
    return responseHeaders;
  }

  public SocketResponseMetaDataV1 mapRequestEventHeaderToSocketResponseHeader() {
    final SocketResponseMetaDataV1 responseHeaders = new SocketResponseMetaDataV1();
    responseHeaders.setCorrelationId(ThreadLocalHeaderContext.getContext().getCorrelationId());
    responseHeaders.setConnectionId(ThreadLocalHeaderContext.getContext().getConnectionId());
    return responseHeaders;
  }
}
