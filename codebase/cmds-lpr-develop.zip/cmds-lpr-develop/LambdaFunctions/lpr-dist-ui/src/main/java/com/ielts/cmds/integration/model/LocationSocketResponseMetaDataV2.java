package com.ielts.cmds.integration.model;

import com.ielts.cmds.lpr.common.out.socketresponse.LocationSocketResponseMetaDataV1;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
@NoArgsConstructor
public class LocationSocketResponseMetaDataV2 extends LocationSocketResponseMetaDataV1 {

    private Integer totalCount;
}
