package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.reference.common.out.event.TerritoriesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.event.TerritoriesSearchResultsGeneratedEventV1Territory;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.reference.common.out.socketresponse.TerritoriesDataOutV1;
import com.ielts.cmds.reference.common.out.socketresponse.TerritoriesDataOutV1Envelope;
import com.ielts.cmds.reference.common.out.socketresponse.TerritoriesDataOutV1List;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

public class TerritoriesSearchResultsGeneratedEventMapping extends Mapper
    implements IServiceV2<TerritoriesSearchResultsGeneratedEventV1, TerritoriesDataOutV1Envelope> {

  public TerritoriesDataOutV1List mapRequestEventBodyToResponseBody(
      final TerritoriesSearchResultsGeneratedEventV1 eventBody) {
    TerritoriesDataOutV1List territoriesDataOutList = new TerritoriesDataOutV1List();
    for (TerritoriesSearchResultsGeneratedEventV1Territory territory : eventBody) {
      TerritoriesDataOutV1 territoriesDataOut = new TerritoriesDataOutV1();
      territoriesDataOut.setTerritoryUuid(territory.getTerritoryUuid());
      territoriesDataOut.setTerritoryIsoCode(territory.getTerritoryIsoCode());
      territoriesDataOut.setTerritoryName(territory.getTerritoryName());
      territoriesDataOut.setCountryUuid(territory.getCountryUuid());
      territoriesDataOut.setCountryIso3Code(territory.getCountryIso3Code());
      territoriesDataOut.setCountryName(territory.getCountryName());
      territoriesDataOut.setLegacyReference(territory.getLegacyReference());
      territoriesDataOut.setEffectiveFromDate(territory.getEffectiveFromDate());
      territoriesDataOut.setEffectiveToDate(territory.getEffectiveToDate());
      territoriesDataOutList.add(territoriesDataOut);
    }
    return territoriesDataOutList;
  }

  @Override
  public TerritoriesDataOutV1Envelope process(TerritoriesSearchResultsGeneratedEventV1 eventBody) {

    TerritoriesDataOutV1Envelope response = new TerritoriesDataOutV1Envelope();
    final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
    final BaseEventErrors errors = ThreadLocalErrorContext.getContext();
    if (eventBody != null) {
      final TerritoriesDataOutV1List responseBody = mapRequestEventBodyToResponseBody(eventBody);
      response.setResponse(responseBody);
    }
    response.setMeta(responseHeaders);
    response.setErrors(errors);
    return response;
  }
}
