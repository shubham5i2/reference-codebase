package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.reference.common.out.event.CountriesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.event.CountriesSearchResultsGeneratedEventV1Country;
import com.ielts.cmds.reference.common.out.socketresponse.CountriesDataOutV1;
import com.ielts.cmds.reference.common.out.socketresponse.CountriesDataOutV1Envelope;
import com.ielts.cmds.reference.common.out.socketresponse.CountriesDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

public class CountriesSearchResultsGeneratedEventMapping extends Mapper
    implements IServiceV2<CountriesSearchResultsGeneratedEventV1, CountriesDataOutV1Envelope> {

  public CountriesDataOutV1List mapRequestEventBodyToResponseBody(
      final CountriesSearchResultsGeneratedEventV1 eventBody) {
    CountriesDataOutV1List countriesDataOutList = new CountriesDataOutV1List();
    for (CountriesSearchResultsGeneratedEventV1Country country : eventBody) {
      CountriesDataOutV1 countriesDataOut = new CountriesDataOutV1();
      countriesDataOut.setCountryUuid(country.getCountryUuid());
      countriesDataOut.setCountryIso3Code(country.getCountryIso3Code());
      countriesDataOut.setCountryName(country.getCountryName());
      countriesDataOut.setLegacyReference(country.getLegacyReference());
      countriesDataOut.setEffectiveFromDate(country.getEffectiveFromDate());
      countriesDataOut.setEffectiveToDate(country.getEffectiveToDate());
      countriesDataOutList.add(countriesDataOut);
    }
    return countriesDataOutList;
  }

  @Override
  public CountriesDataOutV1Envelope process(CountriesSearchResultsGeneratedEventV1 eventBody) {

    CountriesDataOutV1Envelope response = new CountriesDataOutV1Envelope();
    final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
    final BaseEventErrors errors = ThreadLocalErrorContext.getContext();
    if (eventBody != null) {
      final CountriesDataOutV1List responseBody = mapRequestEventBodyToResponseBody(eventBody);
      response.setResponse(responseBody);
    }
    response.setMeta(responseHeaders);
    response.setErrors(errors);
    return response;
  }
}
