package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.reference.common.out.event.ContactTypesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.event.ContactTypesSearchResultsGeneratedEventV1ContactType;
import com.ielts.cmds.reference.common.out.socketresponse.ContactTypesDataOutV1;
import com.ielts.cmds.reference.common.out.socketresponse.ContactTypesDataOutV1Envelope;
import com.ielts.cmds.reference.common.out.socketresponse.ContactTypesDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

public class ContactTypesSearchResultsGeneratedEventMapping extends Mapper
    implements IServiceV2<
        ContactTypesSearchResultsGeneratedEventV1, ContactTypesDataOutV1Envelope> {

  public ContactTypesDataOutV1List mapRequestEventBodyToResponseBody(
      final ContactTypesSearchResultsGeneratedEventV1 eventBody) {
    ContactTypesDataOutV1List contactTypeDataOutList = new ContactTypesDataOutV1List();
    for (ContactTypesSearchResultsGeneratedEventV1ContactType contactType : eventBody) {
      ContactTypesDataOutV1 contactTypeDataOut = new ContactTypesDataOutV1();
      contactTypeDataOut.setContactTypeUuid(contactType.getContactTypeUuid());
      contactTypeDataOut.setContactType(contactType.getContactType());
      contactTypeDataOut.setDescription(contactType.getDescription());
      contactTypeDataOut.setEffectiveFromDate(contactType.getEffectiveFromDate());
      contactTypeDataOut.setEffectiveToDate(contactType.getEffectiveToDate());
      contactTypeDataOutList.add(contactTypeDataOut);
    }
    return contactTypeDataOutList;
  }

  @Override
  public ContactTypesDataOutV1Envelope process(
      ContactTypesSearchResultsGeneratedEventV1 eventBody) {

    ContactTypesDataOutV1Envelope response = new ContactTypesDataOutV1Envelope();
    final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
    final BaseEventErrors errors = ThreadLocalErrorContext.getContext();
    if (eventBody != null) {
      final ContactTypesDataOutV1List responseBody = mapRequestEventBodyToResponseBody(eventBody);
      response.setResponse(responseBody);
    }
    response.setMeta(responseHeaders);
    response.setErrors(errors);
    return response;
  }
}
