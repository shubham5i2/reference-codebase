package com.ielts.cmds.integration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.factory.ServiceFactoryV2;
import com.ielts.cmds.integration.model.FragmentsRequest;
import com.ielts.cmds.integration.model.LocationSearchResultsV2Envelope;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationBasicDataOutV1;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationSearchResultsV1List;
import com.ielts.cmds.serialization.lambda.AbstractDistUiLambda;
import com.ielts.cmds.serialization.lambda.dist.ui.service.AbstractServiceFactoryV2;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;

import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.ielts.cmds.integration.constants.LPRDistConstants.LOCATIONS_FRAGMENT_SIZE;

@Slf4j
public class LPRDistUI extends AbstractDistUiLambda {

	@Override
	public AbstractServiceFactoryV2 getServiceFactory() {
		return new ServiceFactoryV2();
	}

	/**
	 * Method to send response to client
	 *
	 * @param response
	 * @return {@link ByteBuffer}
	 * @throws JsonProcessingException
	 */
	@Override
	public <T2> void sendResponseToClient(
			final T2 response)
			throws JsonProcessingException {
		final boolean isResponseLocationSearchResults = response instanceof LocationSearchResultsV2Envelope;
		if (isResponseLocationSearchResults) {
			final List<LocationSearchResultsV2Envelope> responseList = processLocationsResponse((LocationSearchResultsV2Envelope) response);
			for (LocationSearchResultsV2Envelope singleLocationSearchResponse : responseList) {
				invokeSendResponseToClient(singleLocationSearchResponse);
			}
		} else {
			invokeSendResponseToClient(response);
		}
	}

	protected <T2> void invokeSendResponseToClient(T2 response) throws JsonProcessingException {
		super.sendResponseToClient(response);
	}

	/**
	 * Method to process user locations response
	 *
	 * @param locationSearchResultsV2Envelope
	 * @return {@link List<LocationSearchResultsV2Envelope>}
	 * @throws JsonProcessingException
	 * @throws CharacterCodingException
	 */

	protected List<LocationSearchResultsV2Envelope> processLocationsResponse(final LocationSearchResultsV2Envelope locationSearchResultsV2Envelope) throws JsonProcessingException {
		if (locationSearchResultsV2Envelope.getResponse().isEmpty()) {
			return Collections.singletonList(locationSearchResultsV2Envelope);
		} else {
			final List<List<LocationBasicDataOutV1>> partitions = doLocationPartitioning(locationSearchResultsV2Envelope.getResponse());
			return buildUserLocationsResponses(partitions, locationSearchResultsV2Envelope);
		}
	}

	/**
	 * Method to build User Locations Responses
	 *
	 * @param partitions
	 * @param locationSearchResultsV2Envelope
	 * @return {@link List<LocationSearchResultsV2Envelope>}
	 * @throws JsonProcessingException
	 * @throws CharacterCodingException
	 */
	protected List<LocationSearchResultsV2Envelope> buildUserLocationsResponses(final List<List<LocationBasicDataOutV1>> partitions, final LocationSearchResultsV2Envelope locationSearchResultsV2Envelope) throws JsonProcessingException {
		final List<LocationSearchResultsV2Envelope> userLocationsResponseListOut = new ArrayList<>();
		for (int partitionIndex = 0; partitionIndex < partitions.size(); partitionIndex++) {
			LocationSearchResultsV2Envelope userLocationsResponseOut = mapLocationPartitionToResponse(partitions.get(partitionIndex), locationSearchResultsV2Envelope, partitionIndex, partitions.size());
			userLocationsResponseListOut.add(userLocationsResponseOut);
		}
		return userLocationsResponseListOut;
	}

	/**
	 * Method to determine and print the payload size
	 *
	 * @param locationSearchResultsV2Envelope
	 */
	protected void determineAndLogPayloadSize(final LocationSearchResultsV2Envelope locationSearchResultsV2Envelope) throws JsonProcessingException {
		final String websocketResponse = getMapperWithProperties().writeValueAsString(locationSearchResultsV2Envelope);
		final byte[] bytes = getMapperWithProperties().writeValueAsBytes(websocketResponse);
		if (bytes.length > 125000) {
			logWarn(bytes);
		}
	}

	/**
	 * Method to print the payload size
	 *
	 * @param bytes
	 */

	protected void logWarn(final byte[] bytes) {
		log.warn("websocket payload size is {}, it may exceeds the max size which is 128 KB ", bytes.length);
	}

	/**
	 * Method to do location partitioning
	 *
	 * @param locationsList
	 * @return {@link List<List<LocationBasicDataOutV1>>}
	 */
	protected List<List<LocationBasicDataOutV1>> doLocationPartitioning(final List<LocationBasicDataOutV1> locationsList) {
		final int partitionSize = getPartitionSize();

		final List<List<LocationBasicDataOutV1>> partitions = new ArrayList<>();

		for (int locationCount = 0; locationCount < locationsList.size(); locationCount += partitionSize) {
        /*
            partitionSize(eg: 500) will be added to locationCount so that the starting index will be the next partition size{eg: 501}, and it is treated as start index of sublist
            small number from (locationCount + partitionSize) and locationList.size() will be treated as end index of sublist
        */
			partitions.add(locationsList.subList(locationCount, Math.min(locationCount + partitionSize,
					locationsList.size())));
		}
		return partitions;
	}

	/**
	 * Method to do map location partition data to response
	 *
	 * @param partitionedLocations
	 * @param locationSearchResultsV2Envelope
	 * @param partitionIndex
	 * @param numberOfPartitions
	 * @return {@link LocationSearchResultsV1List}
	 */
	protected LocationSearchResultsV2Envelope mapLocationPartitionToResponse(final List<LocationBasicDataOutV1> partitionedLocations,
																					final LocationSearchResultsV2Envelope locationSearchResultsV2Envelope,
																					final int partitionIndex, final int numberOfPartitions) throws JsonProcessingException {
		final LocationSearchResultsV2Envelope locationsResponse = new LocationSearchResultsV2Envelope();
		final FragmentsRequest fragmentsRequest = new FragmentsRequest();
		locationsResponse.setResponse(partitionedLocations);
		locationsResponse.setMeta(locationSearchResultsV2Envelope.getMeta());
		locationsResponse.setErrors(locationSearchResultsV2Envelope.getErrors());
		fragmentsRequest.setFragmentsNumber(partitionIndex + 1);
		fragmentsRequest.setTotalFragments(numberOfPartitions);
		locationsResponse.setFragments(fragmentsRequest);
		determineAndLogPayloadSize(locationsResponse);
		return locationsResponse;
	}


	/**
	 * Method to get partition size
	 * @return {@link partitionSize}
	 */
	protected int getPartitionSize() {
		final String fragmentSize = System.getenv(LOCATIONS_FRAGMENT_SIZE);
		return (StringUtils.isEmpty(fragmentSize)) ? 500 : Integer.parseInt(fragmentSize);
	}
}
