package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.reference.common.out.event.SectorTypesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.event.SectorTypesSearchResultsGeneratedEventV1SectorType;
import com.ielts.cmds.reference.common.out.socketresponse.SectorTypesDataOutV1;
import com.ielts.cmds.reference.common.out.socketresponse.SectorTypesDataOutV1Envelope;
import com.ielts.cmds.reference.common.out.socketresponse.SectorTypesDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

public class SectorTypesSearchResultsGeneratedEventMapping extends Mapper
    implements IServiceV2<SectorTypesSearchResultsGeneratedEventV1, SectorTypesDataOutV1Envelope> {

  public SectorTypesDataOutV1List mapRequestEventBodyToResponseBody(
      final SectorTypesSearchResultsGeneratedEventV1 eventBody) {
    SectorTypesDataOutV1List sectorTypesDataOutList = new SectorTypesDataOutV1List();
    for (SectorTypesSearchResultsGeneratedEventV1SectorType sectorType : eventBody) {
      SectorTypesDataOutV1 sectorTypesDataOut = new SectorTypesDataOutV1();
      sectorTypesDataOut.setSectorTypeUuid(sectorType.getSectorTypeUuid());
      sectorTypesDataOut.setSectorType(sectorType.getSectorType());
      sectorTypesDataOut.setDescription(sectorType.getDescription());
      sectorTypesDataOut.setEffectiveFromDate(sectorType.getEffectiveFromDate());
      sectorTypesDataOut.setEffectiveToDate(sectorType.getEffectiveToDate());
      sectorTypesDataOutList.add(sectorTypesDataOut);
    }
    return sectorTypesDataOutList;
  }

  @Override
  public SectorTypesDataOutV1Envelope process(SectorTypesSearchResultsGeneratedEventV1 eventBody) {
    SectorTypesDataOutV1Envelope response = new SectorTypesDataOutV1Envelope();
    final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
    final BaseEventErrors errors = ThreadLocalErrorContext.getContext();
    if (eventBody != null) {
      final SectorTypesDataOutV1List responseBody = mapRequestEventBodyToResponseBody(eventBody);
      response.setResponse(responseBody);
    }
    response.setMeta(responseHeaders);
    response.setErrors(errors);
    return response;
  }
}
