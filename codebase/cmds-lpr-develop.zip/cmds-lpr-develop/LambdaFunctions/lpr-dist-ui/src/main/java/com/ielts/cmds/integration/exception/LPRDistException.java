package com.ielts.cmds.integration.exception;

public class LPRDistException extends RuntimeException {

	/**
	 * Generated SerialVersionId
	 */
	private static final long serialVersionUID = -1072689593330250590L;

	public LPRDistException(final String message) {
		super(message);
	}

}
