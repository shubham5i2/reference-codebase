package com.ielts.cmds.integration.datasetup;

import com.ielts.cmds.api.evt_059.Module;
import com.ielts.cmds.api.evt_059.ProductChanged;
import com.ielts.cmds.api.lprws153productchanged.SocketResponseMetaDataV1;

import java.time.LocalDate;
import java.util.UUID;

public class ProductChangedEventDataSetup {
    public static ProductChanged getProductChangedDetails(){
        ProductChanged productChanged = new ProductChanged();
        productChanged.setProductUuid(UUID.fromString("05ea51d0-4617-4b3f-8b01-3e4331efdbf1"));
        productChanged.setName("Online Test1");
        productChanged.setParentProductUuid(UUID.fromString("c8437ba8-cb0e-46ee-b960-9577dce30ef8"));
        productChanged.setApprovalRequired(Boolean.TRUE);
        productChanged.setBookable(Boolean.TRUE);
        productChanged.setAvailableFrom(LocalDate.now());
        productChanged.setAvailableTo(LocalDate.of(2098, 12, 31));
        productChanged.setLegacyProductId("D901");
        productChanged.setBookable(Boolean.TRUE);
        productChanged.setFormat("CD");
        productChanged.setComponent("S");
        productChanged.setDuration(20);
        productChanged.setModule(getModuleTypeDetails());
        productChanged.setProductCharacterisitics("{\"characteristics\": [\"IOC\"]}");
        return productChanged;
    }
    public static Module getModuleTypeDetails(){
        Module moduleType = new Module();
        moduleType.setModuleTypeUuid(UUID.fromString("7a28a632-8728-4f74-882e-72e9d3649763"));
        moduleType.setModuleType("AC");
        moduleType.setDescription("Academic");
        return moduleType;
    }
    public static SocketResponseMetaDataV1 mapRequestEventHeaderToSocketResponseHeader() {
        final SocketResponseMetaDataV1 socketResponseMetaData = new SocketResponseMetaDataV1();
        socketResponseMetaData.setCorrelationId("BxCQGcAkLPECJJw=");
        socketResponseMetaData.setConnectionId("00462c07-e63a-4367-a5ac-98d5bf50fa16");
        return socketResponseMetaData;
    }


}
