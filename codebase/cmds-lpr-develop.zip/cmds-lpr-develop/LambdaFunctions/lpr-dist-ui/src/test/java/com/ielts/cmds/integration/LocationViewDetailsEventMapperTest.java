package com.ielts.cmds.integration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.integration.datasetup.MapperHeaderSetUp;
import com.ielts.cmds.integration.datasetup.ViewLocationEventdataSetup;
import com.ielts.cmds.integration.mapping.LocationRetrievedEventMapping;
import com.ielts.cmds.lpr.common.out.model.LocationRetrievedEventV1;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationDataOutV1;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationDataOutV1Envelope;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationSocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

@ExtendWith(MockitoExtension.class)
class LocationViewDetailsEventMapperTest {

	@Spy
	private ViewLocationEventdataSetup viewLocationEventdataSetup;

	@Spy
	private LocationRetrievedEventMapping locationRetrievedEventMapping;

	/**
	 * Test to validate the Response Event Body when Request Event Body is passed.
	 *
	 * @throws JsonProcessingException
	 */
	@Test
	void whenRequestEventBodyProvided_ThenValidateSocketResponseEventBody() throws JsonProcessingException {
		LocationRetrievedEventV1 eventBody = ViewLocationEventdataSetup.populateLocationViewDetailsEventBody();
		final LocationSocketResponseMetaDataV1 responseHeaders = MapperHeaderSetUp
				.locationMapRequestEventHeaderToSocketResponseHeader();
		doReturn(responseHeaders).when(locationRetrievedEventMapping)
				.locationMapRequestEventHeaderToSocketResponseHeader();
		LocationDataOutV1Envelope response = locationRetrievedEventMapping.process(eventBody);
		final LocationDataOutV1 responseBody = response.getResponse();
		assertEquals(eventBody.getLocationName(), responseBody.getLocationName());
		assertEquals(eventBody.getAddresses().get(0).getAddressTypeName(),
				responseBody.getLocationAddresses().get(0).getAddressTypeName());
		assertEquals(eventBody.getApprovedProducts().get(0).getProductName(),
				responseBody.getApprovedProducts().get(0).getProductName());
	}

	@Test
	void whenRequestEventBodyNull_ThenValidateSocketResponseEventBody() throws JsonProcessingException {
		BaseEventErrors baseErrors = MapperHeaderSetUp.buildEventError("LocationRetrievalFailed", ErrorTypeEnum.WARNING,
				"You do not have permission to view Location", "Location Authorisation Validation Failure", "V3050");
		ThreadLocalErrorContext.setContext(baseErrors);
		LocationRetrievedEventV1 eventBody = new LocationRetrievedEventV1();
		final LocationSocketResponseMetaDataV1 responseHeaders = MapperHeaderSetUp
				.locationMapRequestEventHeaderToSocketResponseHeader();
		doReturn(responseHeaders).when(locationRetrievedEventMapping)
				.locationMapRequestEventHeaderToSocketResponseHeader();
//		doReturn(null).when(locationRetrievedEventMapping).mapRequestEventBodyToResponseBody(eventBody);
		LocationDataOutV1Envelope response = locationRetrievedEventMapping.process(eventBody);
		BaseEventErrors responseErrors = response.getErrors();
		assertEquals(baseErrors.getErrorList().get(0).getErrorCode(),
				responseErrors.getErrorList().get(0).getErrorCode());
		assertEquals(baseErrors.getErrorList().get(0).getTitle(), responseErrors.getErrorList().get(0).getTitle());
	}

}
