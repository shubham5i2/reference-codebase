package com.ielts.cmds.integration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.datasetup.MapperHeaderSetUp;
import com.ielts.cmds.integration.datasetup.ProductsEventDataSetup;
import com.ielts.cmds.integration.mapping.ProductsSearchResultsGeneratedEventMapping;
import com.ielts.cmds.reference.common.out.event.ProductsSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.socketresponse.ProductsDataOutV1Envelope;
import com.ielts.cmds.reference.common.out.socketresponse.ProductsDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;

@ExtendWith(MockitoExtension.class)
class ProductsSearchResultsGeneratedEventMappingTest {

	@Spy
	private ProductsEventDataSetup productsEventSetup;

	@Spy
	private ProductsSearchResultsGeneratedEventMapping productsEventMapping;

	
	/**
	 * Test to validate the Response Event Body when Request Event Body is passed.
	 *
	 * @throws JsonProcessingException
	 */
	@Test
	void whenRequestEventBodyProvided_ThenValidateSocketResponseEventBody() throws JsonProcessingException {
		final ProductsSearchResultsGeneratedEventV1 eventBody = ProductsEventDataSetup.populateEventBody();
		final SocketResponseMetaDataV1 responseHeaders = MapperHeaderSetUp
				.mapRequestEventHeaderToSocketResponseHeader();
		doReturn(responseHeaders).when(productsEventMapping).mapRequestEventHeaderToSocketResponseHeader();
		ProductsDataOutV1Envelope response = productsEventMapping.process(eventBody);
		final ProductsDataOutV1List responseBody = response.getResponse();
		assertEquals(eventBody.get(0).getProductUuid(), responseBody.get(0).getProductUuid());
		assertEquals(eventBody.get(0).getProductName(), responseBody.get(0).getProductName());
	}
	
}
