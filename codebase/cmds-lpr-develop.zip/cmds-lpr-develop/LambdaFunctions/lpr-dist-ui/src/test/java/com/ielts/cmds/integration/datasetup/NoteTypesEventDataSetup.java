package com.ielts.cmds.integration.datasetup;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.reference.common.out.event.NoteTypesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.event.NoteTypesSearchResultsGeneratedEventV1NoteType;
import com.ielts.cmds.reference.common.out.socketresponse.NoteTypesDataOutV1;
import com.ielts.cmds.reference.common.out.socketresponse.NoteTypesDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;

public class NoteTypesEventDataSetup {

	final static ObjectMapper mapper = new ObjectMapper();

	public static NoteTypesSearchResultsGeneratedEventV1 populateEventBody() {

		NoteTypesSearchResultsGeneratedEventV1 notesEventBody = new NoteTypesSearchResultsGeneratedEventV1();

		NoteTypesSearchResultsGeneratedEventV1NoteType noteTypeOne = new NoteTypesSearchResultsGeneratedEventV1NoteType();
		noteTypeOne.setNoteTypeUuid(UUID.randomUUID());
		noteTypeOne.setNoteType("ABC");
		noteTypeOne.setDescription("ABCDescription");
		noteTypeOne.setEffectiveFromDate(LocalDate.now());
		noteTypeOne.setEffectiveToDate(LocalDate.now());
		notesEventBody.add(noteTypeOne);

		NoteTypesSearchResultsGeneratedEventV1NoteType noteTypeTwo = new NoteTypesSearchResultsGeneratedEventV1NoteType();
		noteTypeTwo.setNoteTypeUuid(UUID.randomUUID());
		noteTypeTwo.setNoteType("XYZ");
		noteTypeTwo.setDescription("XYZDescription");
		noteTypeTwo.setEffectiveFromDate(LocalDate.now());
		noteTypeTwo.setEffectiveToDate(LocalDate.now());
		notesEventBody.add(noteTypeTwo);
		return notesEventBody;
	}
}
