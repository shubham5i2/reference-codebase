package com.ielts.cmds.integration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.integration.datasetup.MapperHeaderSetUp;
import com.ielts.cmds.integration.datasetup.ResultsStatusTypesEventDataSetup;
import com.ielts.cmds.integration.mapping.ResultStatusSearchGeneratedEventMapping;
import com.ielts.cmds.reference.common.out.event.ResultStatusSearchGeneratedEventV1;
import com.ielts.cmds.reference.common.out.socketresponse.ResultStatusDataOutV1EnvelopeV1;
import com.ielts.cmds.reference.common.out.socketresponse.ResultStatusDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;

@ExtendWith(MockitoExtension.class)
class ResultStatusSearchGeneratedEventMappingTest {


	@Spy
	private ResultStatusSearchGeneratedEventMapping resultyTypeEventMapping;
	
	/**
	 * Test to validate the Response Event Body when Request Event Body is passed.
	 *
	 * @throws JsonProcessingException
	 */
	@Test
	void whenRequestEventBodyProvided_ThenValidateSocketResponseEventBody() throws JsonProcessingException {
	
		ResultStatusSearchGeneratedEventV1 eventBody = ResultsStatusTypesEventDataSetup.populateEventBodyWithNonEmptyStatus();
		final SocketResponseMetaDataV1 responseHeaders =
				MapperHeaderSetUp.mapRequestEventHeaderToSocketResponseHeader();
		doReturn(responseHeaders).when(resultyTypeEventMapping).mapRequestEventHeaderToSocketResponseHeader();
		ResultStatusDataOutV1EnvelopeV1 response = resultyTypeEventMapping.process(eventBody);
        final ResultStatusDataOutV1List responseBody = response.getResponse();
       assertEquals(eventBody.get(0).getResultsStatusTypeUuid(), responseBody.get(0).getResultsStatusTypeUuid());
       assertEquals(eventBody.get(0).getResultsStatusType(), responseBody.get(0).getResultsStatusType());
       assertEquals(eventBody.get(0).getResultStatusLabels().get(0).getResultStatusLabel(), responseBody.get(0).getResultStatusLabels().get(0).getResultStatusLabel());
       assertEquals(eventBody.get(0).getResultStatusLabels().get(0).getResultStatusLabelCode(), responseBody.get(0).getResultStatusLabels().get(0).getResultStatusLabelCode());
       assertEquals(eventBody.get(0).getResultStatusLabels().get(0).getResultStatusComment().get(0).getResultStatusCommentCode(), responseBody.get(0).getResultStatusLabels().get(0).getResultStatusComments().get(0).getResultStatusCommentCode());
	}
}
