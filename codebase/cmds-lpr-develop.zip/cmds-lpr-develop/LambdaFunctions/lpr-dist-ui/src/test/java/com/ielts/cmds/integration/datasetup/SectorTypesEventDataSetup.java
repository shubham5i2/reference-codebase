package com.ielts.cmds.integration.datasetup;

import java.time.LocalDate;
import java.util.UUID;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.reference.common.out.event.SectorTypesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.event.SectorTypesSearchResultsGeneratedEventV1SectorType;
import com.ielts.cmds.reference.common.out.socketresponse.SectorTypesDataOutV1;
import com.ielts.cmds.reference.common.out.socketresponse.SectorTypesDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;

public class SectorTypesEventDataSetup {

	final static ObjectMapper mapper = new ObjectMapper();

	

	public static SectorTypesSearchResultsGeneratedEventV1 populateEventBody() {

		SectorTypesSearchResultsGeneratedEventV1 sectorsEventBody = new SectorTypesSearchResultsGeneratedEventV1();

		SectorTypesSearchResultsGeneratedEventV1SectorType sectorTypeOne = new SectorTypesSearchResultsGeneratedEventV1SectorType();
		sectorTypeOne.setSectorTypeUuid(UUID.randomUUID());
		sectorTypeOne.setSectorType("College / University");
		sectorTypeOne.setDescription("");
		sectorTypeOne.setEffectiveFromDate(LocalDate.now());
		sectorTypeOne.setEffectiveToDate(LocalDate.now());
		sectorsEventBody.add(sectorTypeOne);

		SectorTypesSearchResultsGeneratedEventV1SectorType sectorTypeTwo = new SectorTypesSearchResultsGeneratedEventV1SectorType();
		sectorTypeTwo.setSectorTypeUuid(UUID.randomUUID());
		sectorTypeTwo.setSectorType("Further or Continuing Education");
		sectorTypeTwo.setDescription("");
		sectorTypeTwo.setEffectiveFromDate(LocalDate.now());
		sectorTypeTwo.setEffectiveToDate(LocalDate.now());
		sectorsEventBody.add(sectorTypeTwo);
		return sectorsEventBody;
	}
}
