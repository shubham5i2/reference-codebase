package com.ielts.cmds.integration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.evt_059.ProductChanged;
import com.ielts.cmds.api.lprws153productchanged.ProductChangeResponseV1;
import com.ielts.cmds.api.lprws153productchanged.ProductChangeResponseV1Envelope;
import com.ielts.cmds.integration.datasetup.ProductChangedEventDataSetup;
import com.ielts.cmds.integration.mapping.ProductChangedEventMapping;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.UUID;

import static org.junit.Assert.assertEquals;

@ExtendWith(MockitoExtension.class)
class ProductChangedEventMappingTest {

    @InjectMocks
    ProductChangedEventMapping productChangedEventMapping;

    final HeaderContext context = new HeaderContext();
    @BeforeEach
    public void setUp() {
        context.setConnectionId("BxCQGcAkLPECJJw=");
        context.setCorrelationId(UUID.fromString("00462c07-e63a-4367-a5ac-98d5bf50fa16"));
        ThreadLocalHeaderContext.setContext(context);
    }
    /**
     * Test to validate the Response Event Body when Request Event Body is passed.
     *
     * @throws JsonProcessingException
     */
    @Test
    void whenRequestEventBodyProvided_ThenValidateSocketResponseEventBody() throws JsonProcessingException {
        ProductChanged eventBody = ProductChangedEventDataSetup.getProductChangedDetails();
        final ProductChangeResponseV1Envelope response = productChangedEventMapping.process(eventBody);
        List<ProductChangeResponseV1> responseList = response.getResponse();
        assertEquals(eventBody.getProductUuid(), responseList.get(0).getProductUuid());
        assertEquals(eventBody.getName(), responseList.get(0).getName());
        assertEquals(context.getConnectionId(), response.getMeta().getConnectionId());
    }

}
