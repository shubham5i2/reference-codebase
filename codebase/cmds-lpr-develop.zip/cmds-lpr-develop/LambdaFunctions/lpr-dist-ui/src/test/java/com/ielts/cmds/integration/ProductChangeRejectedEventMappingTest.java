package com.ielts.cmds.integration;

import com.ielts.cmds.api.lpr154productchangerejected.ProductChangeRejected;
import com.ielts.cmds.api.lprws154productchangerejected.ProductChangeRejectedV1Envelope;
import com.ielts.cmds.integration.datasetup.ProductChangedEventDataSetup;
import com.ielts.cmds.integration.mapping.ProductChangeRejectedEventMapping;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.UUID;

import static org.junit.Assert.assertEquals;

@ExtendWith(MockitoExtension.class)
class ProductChangeRejectedEventMappingTest {
    @InjectMocks
    ProductChangeRejectedEventMapping productChangeRejectedEventMapping;
    final HeaderContext context = new HeaderContext();

    @BeforeEach
    public void setUp() {
        context.setConnectionId("BxCQGcAkLPECJJw=");
        context.setCorrelationId(UUID.fromString("00462c07-e63a-4367-a5ac-98d5bf50fa16"));
        ThreadLocalHeaderContext.setContext(context);
    }
    @Test
    void when_productNotFoundAndResponseIsNull_thenAddErrorInResponse() {
        ProductChangeRejected expectedResult = ProductChangeRejectedEventDataSetup.getPayload();
        String expectedErrorMessage = "Product not found";
        String expectedErrorCode = "V3069";
        ProductChangeRejectedV1Envelope actualResult = productChangeRejectedEventMapping.process(expectedResult);
        assertEquals(expectedErrorMessage, actualResult.getErrors().getErrorList().get(0).getMessage());
        assertEquals(expectedErrorCode, actualResult.getErrors().getErrorList().get(0).getErrorCode());
        assertEquals(context.getConnectionId(), actualResult.getMeta().getConnectionId());
        assertEquals(context.getCorrelationId(), UUID.fromString(actualResult.getMeta().getCorrelationId()));

    }

}
