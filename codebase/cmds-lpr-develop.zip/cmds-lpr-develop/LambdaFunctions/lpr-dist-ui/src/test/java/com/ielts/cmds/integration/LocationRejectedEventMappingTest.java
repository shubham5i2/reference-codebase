package com.ielts.cmds.integration;

import static org.junit.Assert.assertEquals;

import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.api.lpr143locationrejected.LocationRejected;
import com.ielts.cmds.api.lprws143locationrejected.LocationRejectedV1Envelope;
import com.ielts.cmds.integration.mapping.LocationRejectedEventMapping;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

@ExtendWith(MockitoExtension.class)
class LocationRejectedEventMappingTest {

	@InjectMocks
	LocationRejectedEventMapping locationRejectedEventMapping;
	
	final HeaderContext context = new HeaderContext();

    @BeforeEach
    public void setUp() {
        context.setConnectionId("BxCQGcAkLPECJJw=");
        context.setCorrelationId(UUID.fromString("00462c07-e63a-4367-a5ac-98d5bf50fa16"));
        ThreadLocalHeaderContext.setContext(context);
    }
    
    @Test
    void when_productNotFoundAndResponseIsNull_thenAddErrorInResponse() {
        LocationRejected expectedResult = LocationRejectedEventDataSetup.getPayload();
        String expectedErrorMessage = "Must have at least one Bookable Product entered to activate a location";
        String expectedErrorCode = "V3014";
        LocationRejectedV1Envelope actualResult = locationRejectedEventMapping.process(expectedResult);
        assertEquals(expectedErrorMessage, actualResult.getErrors().getErrorList().get(0).getMessage());
        assertEquals(expectedErrorCode, actualResult.getErrors().getErrorList().get(0).getErrorCode());
        assertEquals(context.getConnectionId(), actualResult.getMeta().getConnectionId());
        assertEquals(context.getCorrelationId(), UUID.fromString(actualResult.getMeta().getCorrelationId()));

    }
}
