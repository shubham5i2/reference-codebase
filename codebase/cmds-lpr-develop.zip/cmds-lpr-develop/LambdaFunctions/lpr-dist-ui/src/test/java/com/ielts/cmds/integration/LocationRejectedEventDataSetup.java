package com.ielts.cmds.integration;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.ielts.cmds.api.lpr143locationrejected.BaseEventErrors;
import com.ielts.cmds.api.lpr143locationrejected.BaseEventErrorsErrorListInner;
import com.ielts.cmds.api.lpr143locationrejected.LocationChanged;
import com.ielts.cmds.api.lpr143locationrejected.LocationRejected;

public class LocationRejectedEventDataSetup {

	public static LocationRejected getPayload() {
		LocationRejected locationRejected = new LocationRejected();

		LocationChanged locationChanged = new LocationChanged();
		locationChanged.setLocationUuid(UUID.fromString("05ea51d0-4617-4b3f-8b01-3e4331efdbf1"));
		locationChanged.setLocationName("Test");
		locationChanged.setLocationTypeCode("GLOBAL");
		locationChanged.setPartnerCode("BC");
		locationChanged.setApprovedDate(null);
		locationChanged.setStatus("Active");
		locationChanged.setTestCentreNumber("AG5700");
		locationRejected.setPayload(locationChanged);
		locationRejected.setErrors(getBaseEventErrors());
		return locationRejected;
	}

	public static BaseEventErrors getBaseEventErrors() {
		BaseEventErrors errors = new BaseEventErrors();
		List<BaseEventErrorsErrorListInner> errorList = new ArrayList<>();
		BaseEventErrorsErrorListInner errorDescription = new BaseEventErrorsErrorListInner();
		errorDescription.setErrorCode("V3014");
		errorDescription.setMessage("Must have at least one Bookable Product entered to activate a location");
		errorList.add(errorDescription);
		errors.setErrorList(errorList);
		return errors;
	}
}
