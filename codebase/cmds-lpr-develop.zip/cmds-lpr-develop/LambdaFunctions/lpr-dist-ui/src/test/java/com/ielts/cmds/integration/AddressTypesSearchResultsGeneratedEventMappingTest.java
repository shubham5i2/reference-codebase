package com.ielts.cmds.integration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.integration.datasetup.AddressTypesEventDataSetup;
import com.ielts.cmds.integration.datasetup.MapperHeaderSetUp;
import com.ielts.cmds.integration.mapping.AddressTypesSearchResultsGeneratedEventMapping;
import com.ielts.cmds.reference.common.out.event.AddressTypesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.socketresponse.AddressTypesDataOutV1Envelope;
import com.ielts.cmds.reference.common.out.socketresponse.AddressTypesDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;

@ExtendWith(MockitoExtension.class)
class AddressTypesSearchResultsGeneratedEventMappingTest {

	@Spy
	private AddressTypesSearchResultsGeneratedEventMapping addressTypeEventMapping;


	/**
	 * Test to validate the Response Event Body when Request Event Body is passed.
	 *
	 * @throws JsonProcessingException
	 */
	@Test
	void whenRequestEventBodyProvided_ThenValidateSocketResponseEventBody() throws JsonProcessingException {
		AddressTypesSearchResultsGeneratedEventV1 eventBody = AddressTypesEventDataSetup.populateEventBody();
		final SocketResponseMetaDataV1 responseHeaders = MapperHeaderSetUp
				.mapRequestEventHeaderToSocketResponseHeader();
		doReturn(responseHeaders).when(addressTypeEventMapping).mapRequestEventHeaderToSocketResponseHeader();
		final AddressTypesDataOutV1Envelope response = addressTypeEventMapping.process(eventBody);
		AddressTypesDataOutV1List  responseBody = response.getResponse();
		assertEquals(eventBody.get(0).getAddressTypeUuid(), responseBody.get(0).getAddressTypeUuid());
		assertEquals(eventBody.get(0).getAddressType(), responseBody.get(0).getAddressType());
	}
}
