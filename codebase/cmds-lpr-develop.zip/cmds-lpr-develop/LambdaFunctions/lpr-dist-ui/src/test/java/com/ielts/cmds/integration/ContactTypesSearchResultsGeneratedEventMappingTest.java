package com.ielts.cmds.integration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.datasetup.ContactTypesEventDataSetup;
import com.ielts.cmds.integration.datasetup.MapperHeaderSetUp;
import com.ielts.cmds.integration.mapping.ContactTypesSearchResultsGeneratedEventMapping;
import com.ielts.cmds.reference.common.out.event.ContactTypesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.socketresponse.ContactTypesDataOutV1Envelope;
import com.ielts.cmds.reference.common.out.socketresponse.ContactTypesDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;

@ExtendWith(MockitoExtension.class)
class ContactTypesSearchResultsGeneratedEventMappingTest {

	

	@Spy
	private ContactTypesSearchResultsGeneratedEventMapping contactTypeEventMapping;

	/**
	 * Test to validate the Response Event Body when Request Event Body is passed.
	 *
	 * @throws JsonProcessingException
	 */
	@Test
	void whenRequestEventBodyProvided_ThenValidateSocketResponseEventBody() throws JsonProcessingException {
		ContactTypesSearchResultsGeneratedEventV1 eventBody = ContactTypesEventDataSetup.populateEventBody();
		final SocketResponseMetaDataV1 responseHeaders = MapperHeaderSetUp
				.mapRequestEventHeaderToSocketResponseHeader();
		doReturn(responseHeaders).when(contactTypeEventMapping).mapRequestEventHeaderToSocketResponseHeader();
		ContactTypesDataOutV1Envelope response = contactTypeEventMapping.process(eventBody);
		final ContactTypesDataOutV1List responseBody = response.getResponse();
		assertEquals(eventBody.get(0).getContactTypeUuid(), responseBody.get(0).getContactTypeUuid());
		assertEquals(eventBody.get(0).getContactType(), responseBody.get(0).getContactType());
	}
}
