package com.ielts.cmds.integration.datasetup;

import java.time.LocalDate;
import java.util.UUID;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.reference.common.out.event.ProductsSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.event.ProductsSearchResultsGeneratedEventV1Product;
import com.ielts.cmds.reference.common.out.socketresponse.ProductsDataOutV1;
import com.ielts.cmds.reference.common.out.socketresponse.ProductsDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;

public class ProductsEventDataSetup {

    static final ObjectMapper mapper = new ObjectMapper();
    public static ProductsSearchResultsGeneratedEventV1 populateEventBody() {
        ProductsSearchResultsGeneratedEventV1 productsEventBody =
                new ProductsSearchResultsGeneratedEventV1();

        ProductsSearchResultsGeneratedEventV1Product productOne =
                new ProductsSearchResultsGeneratedEventV1Product();
        productOne.setProductUuid(UUID.randomUUID());
        productOne.setProductName("IELTS at Home GT L");
        productOne.setProductDescription("Description 1");
        productOne.setProductStatus("PUBLISHED");
        productOne.setEffectiveFromDate(LocalDate.now());
        productOne.setEffectiveToDate(LocalDate.now());
        productsEventBody.add(productOne);

        ProductsSearchResultsGeneratedEventV1Product productTwo =
                new ProductsSearchResultsGeneratedEventV1Product();
        productTwo.setProductUuid(UUID.randomUUID());
        productTwo.setProductName("IELTS at Home GT R");
        productTwo.setProductDescription("Description 2");
        productTwo.setProductStatus("PUBLISHED");
        productTwo.setEffectiveFromDate(LocalDate.now());
        productTwo.setEffectiveToDate(LocalDate.now());
        productsEventBody.add(productTwo);

        return productsEventBody;
    }
}
