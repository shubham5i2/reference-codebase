package com.ielts.cmds.integration.datasetup;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import com.ielts.cmds.integration.model.FragmentsRequest;
import com.ielts.cmds.integration.model.LocationSearchResultGeneratedEventV2;
import com.ielts.cmds.integration.model.LocationSearchResultsV2Envelope;
import com.ielts.cmds.integration.model.LocationSocketResponseMetaDataV2;
import com.ielts.cmds.lpr.common.enums.LocationStatus;
import com.ielts.cmds.lpr.common.enums.PartnerCode;
import com.ielts.cmds.lpr.common.out.model.LocationSearchResultGeneratedEventV1Basic;
import com.ielts.cmds.lpr.common.out.model.LocationSearchV1;
import com.ielts.cmds.lpr.common.out.model.LocationSearchV1Criteria;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationBasicDataOutV1;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationSearchResultsV1List;

public class SearchLocationEventDataSetup {

	public static LocationSearchResultGeneratedEventV2 populateLocationSearchEventBody() {
		LocationSearchV1 locationSearchV1 = new LocationSearchV1();
		LocationSearchV1Criteria locationSearchV1Criteria = new LocationSearchV1Criteria();
		LocationSearchResultGeneratedEventV2 locationSearchResultGeneratedEventV2 = new LocationSearchResultGeneratedEventV2();
		List<UUID> locationUuids = new ArrayList<>();
		UUID locationUUid = UUID.fromString("6d89ac13-0027-4393-a8eb-a19e960f567b");
		locationUuids.add(locationUUid);
		locationSearchResultGeneratedEventV2.setResponse(locationUuids);
		locationSearchV1Criteria.setLocationName("testLocation");
		locationSearchV1Criteria.setPartnerCode("BC");
		locationSearchV1.setCriteria(locationSearchV1Criteria);
		locationSearchResultGeneratedEventV2.setSearch(locationSearchV1);
		locationSearchResultGeneratedEventV2.setTotalCount(10);
		return locationSearchResultGeneratedEventV2;
	}

	public static LocationSearchResultGeneratedEventV2 populateEmptyLocationSearchEvent() {
		LocationSearchV1 locationSearchV1 = new LocationSearchV1();
		LocationSearchResultGeneratedEventV2 locationSearchResultGeneratedEventV2 = new LocationSearchResultGeneratedEventV2();
		LocationSearchV1Criteria locationSearchV1Criteria = new LocationSearchV1Criteria();

		locationSearchV1Criteria.setLocationName("testLocation");
		locationSearchV1Criteria.setPartnerCode("BC");
		locationSearchV1.setCriteria(locationSearchV1Criteria);

		locationSearchResultGeneratedEventV2.setSearch(locationSearchV1);
		locationSearchResultGeneratedEventV2.setResponse(Collections.emptyList());

		return locationSearchResultGeneratedEventV2;
	}

	public static List<LocationSearchResultGeneratedEventV1Basic> getLocationSearchResultForTest() {
		List<LocationSearchResultGeneratedEventV1Basic> locations = new ArrayList<>();
		LocationSearchResultGeneratedEventV1Basic locationSearchResultGeneratedEventV1Basic = new LocationSearchResultGeneratedEventV1Basic();
		LocationSearchResultGeneratedEventV1Basic locationSearchResultGeneratedEventV1Basic1 = new LocationSearchResultGeneratedEventV1Basic();

		locationSearchResultGeneratedEventV1Basic.setLocationUuid(UUID.fromString("6d89ac13-0027-4393-a8eb-a19e960f567b"));
		locationSearchResultGeneratedEventV1Basic.setLocationStatus(LocationStatus.ACTIVE);
		locationSearchResultGeneratedEventV1Basic.setPartnerCode(PartnerCode.BC);
		locationSearchResultGeneratedEventV1Basic.setTestCentreNumber("test11");
		locationSearchResultGeneratedEventV1Basic.setCountry("India");
		locationSearchResultGeneratedEventV1Basic.setCity("Pune");

		locationSearchResultGeneratedEventV1Basic1.setLocationUuid(UUID.fromString("7e664903-2413-4cf6-8f86-b1b4400d6762"));
		locationSearchResultGeneratedEventV1Basic1.setLocationStatus(LocationStatus.ACTIVE);
		locationSearchResultGeneratedEventV1Basic1.setPartnerCode(PartnerCode.BC);
		locationSearchResultGeneratedEventV1Basic1.setTestCentreNumber("test12");
		locationSearchResultGeneratedEventV1Basic1.setCountry("India");
		locationSearchResultGeneratedEventV1Basic1.setCity("Banaras");

		locations.add(locationSearchResultGeneratedEventV1Basic);
		locations.add(locationSearchResultGeneratedEventV1Basic1);

		return locations;
	}

	public static List<UUID> getLocationUuids() {
		List<UUID> locationUuids = new ArrayList<>();

		locationUuids.add(UUID.fromString("45d04b66-4d2e-457b-8be9-c9d524e12ef2"));
		locationUuids.add(UUID.fromString("7724c502-e301-412a-b1ed-e4abb34fd1e4"));
		locationUuids.add(UUID.fromString("e61ead6e-c2fa-4eb8-8399-1a4d61ea5928"));
		locationUuids.add(UUID.fromString("7e664903-2413-4cf6-8f86-b1b4400d6762"));
		locationUuids.add(UUID.fromString("6d89ac13-0027-4393-a8eb-a19e960f567b"));

		return locationUuids;
	}

	public static LocationSocketResponseMetaDataV2 searchLocationMapRequestEventHeaderToSocketResponseHeader() {
		final LocationSocketResponseMetaDataV2 responseHeaders = new LocationSocketResponseMetaDataV2();
		responseHeaders.setCorrelationId("a6d58192-dd39-4953-a619-26b8b43cf2ad");
		responseHeaders.setConnectionId("a6d58192-dd39-4953-a619-26b8b43cf2ad");
		return responseHeaders;
	}

	public static LocationSearchResultsV1List getLocationSearchResultsV1List() {
		LocationSearchResultsV1List locationSearchResultsV1List = new LocationSearchResultsV1List();

		LocationBasicDataOutV1 locationBasicDataOutV1 = new LocationBasicDataOutV1();
		locationBasicDataOutV1.setLocationUuid(UUID.fromString("6d89ac13-0027-4393-a8eb-a19e960f567b"));
		locationBasicDataOutV1.setLocationStatus(LocationStatus.ACTIVE);
		locationBasicDataOutV1.setPartnerCode(PartnerCode.BC);
		locationBasicDataOutV1.setTestCentreNumber("test11");
		locationBasicDataOutV1.setCountry("India");
		locationBasicDataOutV1.setCity("Pune");

		LocationBasicDataOutV1 locationBasicDataOutV11 = new LocationBasicDataOutV1();
		locationBasicDataOutV11.setLocationUuid(UUID.fromString("7e664903-2413-4cf6-8f86-b1b4400d6762"));
		locationBasicDataOutV11.setLocationStatus(LocationStatus.ACTIVE);
		locationBasicDataOutV11.setPartnerCode(PartnerCode.BC);
		locationBasicDataOutV11.setTestCentreNumber("test12");
		locationBasicDataOutV11.setCountry("India");
		locationBasicDataOutV11.setCity("Banaras");

		locationSearchResultsV1List.add(locationBasicDataOutV1);
		locationSearchResultsV1List.add(locationBasicDataOutV11);

		return locationSearchResultsV1List;
	}

	public static LocationSocketResponseMetaDataV2 buildResponseHeaderForTest() {
		LocationSocketResponseMetaDataV2 locationSocketResponseMetaDataV2 = new LocationSocketResponseMetaDataV2();
		locationSocketResponseMetaDataV2.setConnectionId("test");
		locationSocketResponseMetaDataV2.setCorrelationId("7e664903-2413-4cf6-8f86-b1b4400d6762");
		locationSocketResponseMetaDataV2.setTotalCount(10);
		return locationSocketResponseMetaDataV2;
	}

	public static LocationSearchResultsV2Envelope buildLocationSearchResultResponseForTest() {
		LocationSearchResultsV2Envelope response = new LocationSearchResultsV2Envelope();
		FragmentsRequest fragmentsRequest = new FragmentsRequest();

		fragmentsRequest.setFragmentsNumber(1);
		fragmentsRequest.setFragmentsNumber(1);

		response.setResponse(getLocationSearchResultsV1List());
		response.setMeta(buildResponseHeaderForTest());
		response.setFragments(fragmentsRequest);

		return response;
	}
}
