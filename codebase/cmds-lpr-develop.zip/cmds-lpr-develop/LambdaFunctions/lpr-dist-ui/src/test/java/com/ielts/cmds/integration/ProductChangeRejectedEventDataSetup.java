package com.ielts.cmds.integration;

import com.ielts.cmds.api.lpr154productchangerejected.ProductChanged;
import com.ielts.cmds.api.lpr154productchangerejected.Module;
import com.ielts.cmds.api.lpr154productchangerejected.BaseEventErrors;
import com.ielts.cmds.api.lpr154productchangerejected.BaseEventErrorsErrorListInner;
import com.ielts.cmds.api.lpr154productchangerejected.ProductChangeRejected;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

class ProductChangeRejectedEventDataSetup {
    public static ProductChangeRejected getPayload() {
        ProductChangeRejected productChangeRejected = new ProductChangeRejected();
        ProductChanged productChanged = new ProductChanged();
        productChanged.setProductUuid(UUID.fromString("05ea51d0-4617-4b3f-8b01-3e4331efdbf1"));
        productChanged.setName("Online Test1");
        productChanged.setParentProductUuid(UUID.fromString("c8437ba8-cb0e-46ee-b960-9577dce30ef8"));
        productChanged.setApprovalRequired(Boolean.TRUE);
        productChanged.setBookable(Boolean.TRUE);
        productChanged.setAvailableFrom(LocalDate.now());
        productChanged.setAvailableTo(LocalDate.of(2098, 12, 31));
        productChanged.setLegacyProductId("D901");
        productChanged.setBookable(Boolean.TRUE);
        productChanged.setFormat("CD");
        productChanged.setComponent("S");
        productChanged.setDuration(BigDecimal.valueOf(20));
        productChanged.setModule(getModuleTypeDetails());
        productChanged.setProductCharacterisitics("{\"characteristics\": [\"IOC\"]}");
        productChangeRejected.setPayload(productChanged);
        productChangeRejected.setErrors(getBaseEventErrors());
        return productChangeRejected;
    }
    public static Module getModuleTypeDetails(){
        Module moduleType = new Module();
        moduleType.setModuleTypeUuid(UUID.fromString("7a28a632-8728-4f74-882e-72e9d3649763"));
        moduleType.setModuleType("AC");
        moduleType.setDescription("Academic");
        return moduleType;
    }
    public static BaseEventErrors getBaseEventErrors(){
        BaseEventErrors errors = new BaseEventErrors();
        List<BaseEventErrorsErrorListInner> errorList = new ArrayList<>();
        BaseEventErrorsErrorListInner errorDescription = new BaseEventErrorsErrorListInner();
        errorDescription.setErrorCode("V3069");
        errorDescription.setMessage("Product not found");
        errorList.add(errorDescription);

        errors.setErrorList(errorList);
        return errors;
    }
}
