package com.ielts.cmds.integration.datasetup;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.mockito.internal.matchers.Any;

import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationSocketResponseMetaDataV1;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

public class MapperHeaderSetUp {

	
	public static SocketResponseMetaDataV1 mapRequestEventHeaderToSocketResponseHeader() {
		final SocketResponseMetaDataV1 responseHeaders = new SocketResponseMetaDataV1();
		responseHeaders.setCorrelationId(UUID.fromString("a6d58192-dd39-4953-a619-26b8b43cf2ad"));
		responseHeaders.setConnectionId("a6d58192-dd39-4953-a619-26b8b43cf2ad");
		return responseHeaders;
	}
	 public static LocationSocketResponseMetaDataV1 locationMapRequestEventHeaderToSocketResponseHeader() {
			final LocationSocketResponseMetaDataV1 responseHeaders = new LocationSocketResponseMetaDataV1();
			responseHeaders.setCorrelationId("a6d58192-dd39-4953-a619-26b8b43cf2ad");
			responseHeaders.setConnectionId("a6d58192-dd39-4953-a619-26b8b43cf2ad");
			return responseHeaders;
		}
	 public static BaseEventErrors buildEventError(String eventName,
				ErrorTypeEnum errorTypeEnum, String message, String Title, String errorCode) {
			BaseEventErrors baseEventErrors;
			List<ErrorDescription> errorDescriptions = new ArrayList<>();
			ErrorDescription errorDescription = new ErrorDescription();
			Source source = new Source(eventName,"");
			errorDescription.setMessage(message);
			errorDescription.setType(errorTypeEnum);
			errorDescription.setInterfaceName("LPR_MX");
			errorDescription.setSource(source);
			errorDescription.setTitle(Title);
			errorDescription.setErrorCode(errorCode);
			errorDescriptions.add(errorDescription);
			baseEventErrors = new BaseEventErrors(errorDescriptions);
			return baseEventErrors;
		}
}
