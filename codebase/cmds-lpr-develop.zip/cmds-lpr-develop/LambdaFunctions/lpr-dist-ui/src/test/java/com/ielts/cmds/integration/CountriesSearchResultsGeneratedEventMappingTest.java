package com.ielts.cmds.integration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.datasetup.CountriesEventDataSetup;
import com.ielts.cmds.integration.datasetup.MapperHeaderSetUp;
import com.ielts.cmds.integration.mapping.CountriesSearchResultsGeneratedEventMapping;
import com.ielts.cmds.reference.common.out.event.CountriesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.socketresponse.CountriesDataOutV1Envelope;
import com.ielts.cmds.reference.common.out.socketresponse.CountriesDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;

@ExtendWith(MockitoExtension.class)
class CountriesSearchResultsGeneratedEventMappingTest {


	@Spy
	private CountriesEventDataSetup countriesEventSetup;

	@Spy
	private CountriesSearchResultsGeneratedEventMapping countriesEventMapping;

	

	/**
	 * Test to validate the Response Event Body when Request Event Body is passed.
	 *
	 * @throws JsonProcessingException
	 */
	@Test
	void whenRequestEventBodyProvided_ThenValidateSocketResponseEventBody() throws JsonProcessingException {

		CountriesSearchResultsGeneratedEventV1 eventBody = CountriesEventDataSetup.populateEventBody();
		final SocketResponseMetaDataV1 responseHeaders = MapperHeaderSetUp
				.mapRequestEventHeaderToSocketResponseHeader();
		doReturn(responseHeaders).when(countriesEventMapping).mapRequestEventHeaderToSocketResponseHeader();
		CountriesDataOutV1Envelope response = countriesEventMapping.process(eventBody);
		final CountriesDataOutV1List responseBody = response.getResponse();
		assertEquals(eventBody.get(0).getCountryUuid(), responseBody.get(0).getCountryUuid());
		assertEquals(eventBody.get(0).getCountryIso3Code(), responseBody.get(0).getCountryIso3Code());
		assertEquals(eventBody.get(0).getCountryName(), responseBody.get(0).getCountryName());
	}
}
