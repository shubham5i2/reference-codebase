package com.ielts.cmds.integration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.datasetup.MapperHeaderSetUp;
import com.ielts.cmds.integration.datasetup.PartnerCodesEventDataSetup;
import com.ielts.cmds.integration.mapping.PartnerCodesSearchResultsGeneratedEventMapping;
import com.ielts.cmds.reference.common.out.event.PartnerCodesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.socketresponse.PartnersDataOutV1Envelope;
import com.ielts.cmds.reference.common.out.socketresponse.PartnersDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;

@ExtendWith(MockitoExtension.class)
class PartnerCodesSearchResultsGeneratedEventMappingTest {

	@Spy
	private PartnerCodesSearchResultsGeneratedEventMapping partnersEventMapping;

	

	/**
	 *Test to validate the Response Event Body when Request Event Body is passed.
	 *
	 * @throws JsonProcessingException
	 */
	@Test
	void whenRequestEventBodyProvided_ThenValidateSocketResponseEventBody() throws JsonProcessingException {
		final PartnerCodesSearchResultsGeneratedEventV1 eventBody = PartnerCodesEventDataSetup.populateEventBody();
		final SocketResponseMetaDataV1 responseHeaders = MapperHeaderSetUp
				.mapRequestEventHeaderToSocketResponseHeader();
		doReturn(responseHeaders).when(partnersEventMapping).mapRequestEventHeaderToSocketResponseHeader();
		PartnersDataOutV1Envelope response = partnersEventMapping.process(eventBody);
		final PartnersDataOutV1List responseBody = response.getResponse();
		assertEquals(eventBody.get(0).getPartnerUuid(), responseBody.get(0).getPartnerUuid());
		assertEquals(eventBody.get(0).getPartnerName(), responseBody.get(0).getPartnerName());
		assertEquals(eventBody.get(0).getPartnerCode(), responseBody.get(0).getPartnerCode());
	}
}
