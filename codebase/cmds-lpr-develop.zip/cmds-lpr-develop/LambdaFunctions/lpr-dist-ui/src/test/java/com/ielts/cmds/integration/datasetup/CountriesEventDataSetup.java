package com.ielts.cmds.integration.datasetup;

import java.time.LocalDate;
import java.util.UUID;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.reference.common.out.event.CountriesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.event.CountriesSearchResultsGeneratedEventV1Country;
import com.ielts.cmds.reference.common.out.socketresponse.CountriesDataOutV1;
import com.ielts.cmds.reference.common.out.socketresponse.CountriesDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;

public class CountriesEventDataSetup {

	final static ObjectMapper mapper = new ObjectMapper();
	public static CountriesSearchResultsGeneratedEventV1 populateEventBody() {
		CountriesSearchResultsGeneratedEventV1 countriesEventBody = new CountriesSearchResultsGeneratedEventV1();

		CountriesSearchResultsGeneratedEventV1Country countryOne = new CountriesSearchResultsGeneratedEventV1Country();
		countryOne.setCountryUuid(UUID.randomUUID());
		countryOne.setCountryIso3Code("IND");
		countryOne.setCountryName("India");
		countryOne.setLegacyReference("");
		countryOne.setEffectiveFromDate(LocalDate.now());
		countryOne.setEffectiveToDate(LocalDate.now());
		countriesEventBody.add(countryOne);

		CountriesSearchResultsGeneratedEventV1Country countryTwo = new CountriesSearchResultsGeneratedEventV1Country();
		countryTwo.setCountryUuid(UUID.randomUUID());
		countryTwo.setCountryIso3Code("GBR");
		countryTwo.setCountryName("United Kingdom");
		countryTwo.setLegacyReference("");
		countryTwo.setEffectiveFromDate(LocalDate.now());
		countryTwo.setEffectiveToDate(LocalDate.now());
		countriesEventBody.add(countryTwo);

		return countriesEventBody;
	}

}
