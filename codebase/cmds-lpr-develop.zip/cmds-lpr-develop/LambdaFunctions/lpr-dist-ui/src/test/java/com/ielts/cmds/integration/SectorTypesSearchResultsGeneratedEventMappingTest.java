package com.ielts.cmds.integration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.datasetup.MapperHeaderSetUp;
import com.ielts.cmds.integration.datasetup.SectorTypesEventDataSetup;
import com.ielts.cmds.integration.mapping.SectorTypesSearchResultsGeneratedEventMapping;
import com.ielts.cmds.reference.common.out.event.SectorTypesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.socketresponse.SectorTypesDataOutV1Envelope;
import com.ielts.cmds.reference.common.out.socketresponse.SectorTypesDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;

@ExtendWith(MockitoExtension.class)
class SectorTypesSearchResultsGeneratedEventMappingTest {

	@Spy
	private SectorTypesSearchResultsGeneratedEventMapping sectorTypesEventMapping;

	
	/**
	 * Test to validate the Response Event Body when Request Event Body is passed.
	 *
	 * @throws JsonProcessingException
	 */
	@Test
	void whenRequestEventBodyProvided_ThenValidateSocketResponseEventBody() throws JsonProcessingException {
		final SectorTypesSearchResultsGeneratedEventV1 eventBody = SectorTypesEventDataSetup.populateEventBody();
		final SocketResponseMetaDataV1 responseHeaders = MapperHeaderSetUp
				.mapRequestEventHeaderToSocketResponseHeader();
		doReturn(responseHeaders).when(sectorTypesEventMapping).mapRequestEventHeaderToSocketResponseHeader();
		SectorTypesDataOutV1Envelope response = sectorTypesEventMapping.process(eventBody);
		final SectorTypesDataOutV1List responseBody = response.getResponse();
		assertEquals(eventBody.get(0).getSectorTypeUuid(), responseBody.get(0).getSectorTypeUuid());
		assertEquals(eventBody.get(0).getSectorType(), responseBody.get(0).getSectorType());
	}
}
