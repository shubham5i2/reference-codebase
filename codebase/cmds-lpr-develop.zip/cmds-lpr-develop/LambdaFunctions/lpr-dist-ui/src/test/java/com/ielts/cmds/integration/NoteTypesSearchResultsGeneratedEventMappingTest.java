package com.ielts.cmds.integration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.datasetup.MapperHeaderSetUp;
import com.ielts.cmds.integration.datasetup.NoteTypesEventDataSetup;
import com.ielts.cmds.integration.mapping.NoteTypesSearchResultsGeneratedEventMapping;
import com.ielts.cmds.reference.common.out.event.NoteTypesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.socketresponse.NoteTypesDataOutV1Envelope;
import com.ielts.cmds.reference.common.out.socketresponse.NoteTypesDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;

@ExtendWith(MockitoExtension.class)
class NoteTypesSearchResultsGeneratedEventMappingTest {


	
	@Spy
	private NoteTypesSearchResultsGeneratedEventMapping noteTypesEventMapping;

	
	/**
	 * Test to validate the Response Event Body when Request Event Body is passed.
	 *
	 * @throws JsonProcessingException
	 */
	@Test
	void whenRequestEventBodyProvided_ThenValidateSocketResponseEventBody() throws JsonProcessingException {
		NoteTypesSearchResultsGeneratedEventV1 eventBody = NoteTypesEventDataSetup.populateEventBody();
		final SocketResponseMetaDataV1 responseHeaders = MapperHeaderSetUp
				.mapRequestEventHeaderToSocketResponseHeader();
		doReturn(responseHeaders).when(noteTypesEventMapping).mapRequestEventHeaderToSocketResponseHeader();
		NoteTypesDataOutV1Envelope response = noteTypesEventMapping.process(eventBody);
		final NoteTypesDataOutV1List responseBody = response.getResponse();
		assertEquals(eventBody.get(0).getNoteTypeUuid(), responseBody.get(0).getNoteTypeUuid());
		assertEquals(eventBody.get(0).getNoteType(), responseBody.get(0).getNoteType());
	}
}
