package com.ielts.cmds.integration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.datasetup.MapperHeaderSetUp;
import com.ielts.cmds.integration.datasetup.OrganisationTypesEventDataSetup;
import com.ielts.cmds.integration.mapping.OrganisationTypesSearchResultsGeneratedEventMapping;
import com.ielts.cmds.reference.common.out.event.OrganisationTypesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.socketresponse.OrganisationTypesDataOutV1Envelope;
import com.ielts.cmds.reference.common.out.socketresponse.OrganisationTypesDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;

/**
 * 
 * @author cts
 *
 */
@ExtendWith(MockitoExtension.class)
class OrganisationTypesSearchResultsGeneratedEventMappingTest {

	
	@Spy
	private OrganisationTypesSearchResultsGeneratedEventMapping organisationTypeEventMapping;

	
	/**
	 * Test to validate the Response Event Body when Request Event Body is passed.
	 *
	 * @throws JsonProcessingException
	 */
	@Test
	void whenRequestEventBodyProvided_ThenValidateSocketResponseEventBody() throws JsonProcessingException {
		OrganisationTypesSearchResultsGeneratedEventV1 eventBody = OrganisationTypesEventDataSetup.populateEventBody();
		final SocketResponseMetaDataV1 responseHeaders = MapperHeaderSetUp
				.mapRequestEventHeaderToSocketResponseHeader();
		doReturn(responseHeaders).when(organisationTypeEventMapping).mapRequestEventHeaderToSocketResponseHeader();
		OrganisationTypesDataOutV1Envelope response = organisationTypeEventMapping.process(eventBody);
		final OrganisationTypesDataOutV1List responseBody = response.getResponse();
		assertEquals(eventBody.get(0).getOrganisationTypeUuid(), responseBody.get(0).getOrganisationTypeUuid());
		assertEquals(eventBody.get(0).getOrganisationType(), responseBody.get(0).getOrganisationType());
	}
	
}
