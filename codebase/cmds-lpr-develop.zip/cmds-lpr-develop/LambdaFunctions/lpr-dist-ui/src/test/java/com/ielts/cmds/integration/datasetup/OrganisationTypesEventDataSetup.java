package com.ielts.cmds.integration.datasetup;

import java.time.LocalDate;
import java.util.UUID;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.reference.common.out.event.OrganisationTypesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.event.OrganisationTypesSearchResultsGeneratedEventV1OrganisationType;
import com.ielts.cmds.reference.common.out.socketresponse.OrganisationTypesDataOutV1;
import com.ielts.cmds.reference.common.out.socketresponse.OrganisationTypesDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;

public class OrganisationTypesEventDataSetup {

	final static ObjectMapper mapper = new ObjectMapper();

	public static OrganisationTypesSearchResultsGeneratedEventV1 populateEventBody() {
		OrganisationTypesSearchResultsGeneratedEventV1 organisationTypesEventBody = new OrganisationTypesSearchResultsGeneratedEventV1();
		OrganisationTypesSearchResultsGeneratedEventV1OrganisationType organisationTypeOne = new OrganisationTypesSearchResultsGeneratedEventV1OrganisationType();
		organisationTypeOne.setOrganisationTypeUuid(UUID.randomUUID());
		organisationTypeOne.setOrganisationType("RO");
		organisationTypeOne.setDescription("Recognising Organisation");
		organisationTypeOne.setEffectiveFromDate(LocalDate.now());
		organisationTypeOne.setEffectiveToDate(LocalDate.now());
		organisationTypesEventBody.add(organisationTypeOne);

		OrganisationTypesSearchResultsGeneratedEventV1OrganisationType organisationTypeTwo = new OrganisationTypesSearchResultsGeneratedEventV1OrganisationType();
		organisationTypeTwo.setOrganisationTypeUuid(UUID.randomUUID());
		organisationTypeTwo.setOrganisationType("VO");
		organisationTypeTwo.setDescription("Verified Organisation");
		organisationTypeTwo.setEffectiveFromDate(LocalDate.now());
		organisationTypeTwo.setEffectiveToDate(LocalDate.now());
		organisationTypesEventBody.add(organisationTypeTwo);
		return organisationTypesEventBody;
	}
}
