package com.ielts.cmds.integration.datasetup;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.lpr.common.enums.LocationStatus;
import com.ielts.cmds.lpr.common.enums.LocationTypeCode;
import com.ielts.cmds.lpr.common.enums.PartnerCode;
import com.ielts.cmds.lpr.common.enums.RequestStatus;
import com.ielts.cmds.lpr.common.out.model.LocationRetrievedEventV1;
import com.ielts.cmds.lpr.common.out.model.ViewLocationAddressV1;
import com.ielts.cmds.lpr.common.out.model.ViewLocationProductV1;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationDataOutV1;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationDataOutV1Address;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationDataOutV1Addresses;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationDataOutV1ApprovedProduct;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationDataOutV1ApprovedProducts;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationSocketResponseMetaDataV1;

public class ViewLocationEventdataSetup {

	final ObjectMapper mapper = new ObjectMapper();

	

	public static LocationRetrievedEventV1 populateLocationViewDetailsEventBody() {

		LocationRetrievedEventV1 LocationRetrieved = new LocationRetrievedEventV1();

		LocationRetrieved.setLocationTypeCode(LocationTypeCode.TEST_CENTRE);
		LocationRetrieved.setLocationUuid(UUID.fromString("3f034e1d-a4db-49d5-b39a-816121b10afb"));
		LocationRetrieved.setParentLocationUuid(UUID.fromString("a6ee9644-4a0b-4408-953b-9eb5c9400e4d"));
		LocationRetrieved.setParentLocationName("IDP Melbourne");
		LocationRetrieved.setPartnerCode(PartnerCode.IDP);
		LocationRetrieved.setExternalLocationUuid(UUID.fromString("a40e4b6b-bc8e-47c0-95d8-bff8a9c21cf8"));
		LocationRetrieved.setExternalParentLocationUuid(UUID.fromString("6881bf15-9945-47b6-bbda-d7f2e0b034e3"));
		LocationRetrieved.setLocationName("IDP Test Center");
		LocationRetrieved.setTestCentreNumber("AU241");
		LocationRetrieved.setTimezoneName("UTC");
		LocationRetrieved.setWebsiteURL("https://www.cambridgeassment.org.uk/");
		LocationRetrieved.setActivatedDate("2020-04-30");
		LocationRetrieved.setEligibleForOfflineTesting(true);
		LocationRetrieved.setStatus(LocationStatus.ACTIVE);

		List<ViewLocationAddressV1> addresses = new ArrayList<>();

		ViewLocationAddressV1 address = new ViewLocationAddressV1();

		address.setLocationAddressUuid(UUID.fromString("8ccad795-670f-463c-b1ca-f8fabe503710"));
		address.setAddressTypeUuid(UUID.fromString("3479deac-5a36-490c-8587-2ba401735aa2"));
		address.setAddressLine1("GPO BOX 1515");
		address.setAddressLine2("The Triangle Building");
		address.setAddressLine3("Main road");
		address.setAddressLine4("ending");
		address.setCity("Melbourne");
		address.setTerritoryUuid(UUID.fromString("a0f38a45-618e-44fe-9beb-30816119ae60"));
		address.setPostalCode("30000");
		address.setCountryIso3Code("AUS");
		address.setCountryUuid(UUID.fromString("57d4a518-3599-4de6-a09e-b7b5f63fd71e"));
		address.setEmail("info@cambridgeassessment.org.uk");
		address.setPrimaryPhone("+44 (0) 1223 553311");
		address.setSecondaryPhone("+44 (0) 1223 553311");
		address.setEffectiveFromDate(LocalDate.now());
		address.setEffectiveToDate(LocalDate.now());
		address.setCountryName("Australia");
		address.setTerritoryName("cambridgeshire");
		address.setAddressTypeName("Postal");

		addresses.add(address);

		ViewLocationAddressV1 addressTwo = new ViewLocationAddressV1();

		addressTwo.setLocationAddressUuid(UUID.fromString("fa5347f6-d5f6-4c06-9add-a5806bd330f8"));
		addressTwo.setAddressTypeUuid(UUID.fromString("bbf2022f-0433-4107-93a0-f5fb9ec813a2"));
		addressTwo.setAddressLine1("GPO BOX 1515");
		addressTwo.setAddressLine2("The Triangle Building");
		addressTwo.setAddressLine3("Main road");
		addressTwo.setAddressLine4("ending");
		addressTwo.setCity("Melbourne");
		addressTwo.setTerritoryUuid(UUID.fromString("a0f38a45-618e-44fe-9beb-30816119ae60"));
		addressTwo.setPostalCode("30000");
		addressTwo.setCountryIso3Code("AUS");
		addressTwo.setCountryUuid(UUID.fromString("57d4a518-3599-4de6-a09e-b7b5f63fd71e"));
		addressTwo.setEmail("info@cambridgeassessment.org.uk");
		addressTwo.setPrimaryPhone("+44 (0) 1223 553311");
		addressTwo.setSecondaryPhone("+44 (0) 1223 553311");
		addressTwo.setEffectiveFromDate(LocalDate.now());
		addressTwo.setEffectiveToDate(LocalDate.now());
		addressTwo.setCountryName("Australia");
		addressTwo.setTerritoryName("cambridgeshire");
		addressTwo.setAddressTypeName("Postal");

		addresses.add(addressTwo);

		LocationRetrieved.setAddresses(addresses);

		List<ViewLocationProductV1> products = new ArrayList<>();

		ViewLocationProductV1 product = new ViewLocationProductV1();

		product.setLocationProductUuid(UUID.fromString("a4c8171f-ae1f-4640-95f2-458692564b04"));
		product.setProductUuid(UUID.fromString("802dbd00-8439-4388-9ef0-8e38455ced34"));
		product.setEffectiveFromDate(LocalDate.now());
		product.setEffectiveToDate(LocalDate.now());
		product.setProductName("IELTS GT");

		products.add(product);

		ViewLocationProductV1 productTwo = new ViewLocationProductV1();

		productTwo.setLocationProductUuid(UUID.fromString("a4c8171f-ae1f-4640-95f2-458692564b04"));
		productTwo.setProductUuid(UUID.fromString("802dbd00-8439-4388-9ef0-8e38455ced34"));
		productTwo.setEffectiveFromDate(LocalDate.now());
		productTwo.setEffectiveToDate(LocalDate.now());
		productTwo.setProductName("IELTS AC");

		products.add(productTwo);

		LocationRetrieved.setApprovedProducts(products);

		return LocationRetrieved;
	}
	
}
