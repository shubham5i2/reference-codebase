package com.ielts.cmds.integration.datasetup;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.reference.common.out.event.ModuleTypesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.event.ModuleTypesSearchResultsGeneratedEventV1ModuleType;
import com.ielts.cmds.reference.common.out.socketresponse.ModuleTypesDataOutV1;
import com.ielts.cmds.reference.common.out.socketresponse.ModuleTypesDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;

public class ModuleTypesEventDataSetup {

	final static ObjectMapper mapper = new ObjectMapper();

	public static ModuleTypesSearchResultsGeneratedEventV1 populateEventBody() {
		ModuleTypesSearchResultsGeneratedEventV1 moduleTypesEventBody = new ModuleTypesSearchResultsGeneratedEventV1();

		ModuleTypesSearchResultsGeneratedEventV1ModuleType moduleTypeOne = new ModuleTypesSearchResultsGeneratedEventV1ModuleType();
		moduleTypeOne.setModuleTypeUuid(UUID.randomUUID());
		moduleTypeOne.setModuleType("AC");
		moduleTypeOne.setDescription("Academic");
		moduleTypeOne.setEffectiveFromDate(LocalDate.now());
		moduleTypeOne.setEffectiveToDate(LocalDate.now());
		moduleTypesEventBody.add(moduleTypeOne);

		ModuleTypesSearchResultsGeneratedEventV1ModuleType moduleTypeTwo = new ModuleTypesSearchResultsGeneratedEventV1ModuleType();
		moduleTypeTwo.setModuleTypeUuid(UUID.randomUUID());
		moduleTypeTwo.setModuleType("GT");
		moduleTypeTwo.setDescription("General Training");
		moduleTypeTwo.setEffectiveFromDate(LocalDate.now());
		moduleTypeTwo.setEffectiveToDate(LocalDate.now());
		moduleTypesEventBody.add(moduleTypeTwo);
		return moduleTypesEventBody;
	}
}
