package com.ielts.cmds.integration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

import javax.validation.Valid;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.lpr142locationpersisted.LocationPersisted;
import com.ielts.cmds.api.lprws142locationpersisted.LocationPersistResponseV1;
import com.ielts.cmds.api.lprws142locationpersisted.LocationPersistResponseV1Envelope;
import com.ielts.cmds.integration.datasetup.LocationPersistedEventDataSetup;
import com.ielts.cmds.integration.datasetup.MapperHeaderSetUp;
import com.ielts.cmds.integration.mapping.LocationPersistedEventMapping;

@ExtendWith(MockitoExtension.class)
class LocationPersistedEventMappingTest {


	@Spy
	private LocationPersistedEventDataSetup locationPersistDataSetup;

	@Spy
	private LocationPersistedEventMapping locationPersistEventMapping;

		/**
	 * Test to validate the Response Event Body when Request Event Body is passed.
	 *
	 * @throws JsonProcessingException
	 */
	@Test
	void whenRequestEventBodyProvided_ThenValidateSocketResponseEventBody() throws JsonProcessingException {
		LocationPersisted eventBody = locationPersistDataSetup.populateLocationPersistedEventBody();
		final LocationPersistResponseV1Envelope response = locationPersistEventMapping.process(eventBody);
		LocationPersistResponseV1 responseBody = response.getResponse();
		assertEquals(eventBody.getLocationName(), responseBody.getLocationName());
		assertEquals(eventBody.getLocationUuid(), responseBody.getLocationUuid());
		assertEquals(eventBody.getTestCentreNumber(), responseBody.getTestCentreNumber());
	}
	
}
