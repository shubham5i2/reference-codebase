package com.ielts.cmds.integration.datasetup;

import java.time.LocalDate;
import java.util.UUID;

import com.ielts.cmds.reference.common.out.event.TerritoriesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.event.TerritoriesSearchResultsGeneratedEventV1Territory;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.reference.common.out.socketresponse.TerritoriesDataOutV1;
import com.ielts.cmds.reference.common.out.socketresponse.TerritoriesDataOutV1List;

public class TerritoriesEventDataSetup {

	
	public static TerritoriesSearchResultsGeneratedEventV1 populateEventBody() {
		TerritoriesSearchResultsGeneratedEventV1 territoriesEventBody = new TerritoriesSearchResultsGeneratedEventV1();

		TerritoriesSearchResultsGeneratedEventV1Territory territoryOne = new TerritoriesSearchResultsGeneratedEventV1Territory();
		territoryOne.setTerritoryUuid(UUID.randomUUID());
		territoryOne.setTerritoryIsoCode("XYZ");
		territoryOne.setTerritoryName("XYZ");
		territoryOne.setCountryUuid(UUID.randomUUID());
		territoryOne.setCountryIso3Code("IND");
		territoryOne.setCountryName("India");
		territoryOne.setLegacyReference("");
		territoryOne.setEffectiveFromDate(LocalDate.now());
		territoryOne.setEffectiveToDate(LocalDate.now());
		territoriesEventBody.add(territoryOne);

		TerritoriesSearchResultsGeneratedEventV1Territory territoryTwo = new TerritoriesSearchResultsGeneratedEventV1Territory();
		territoryTwo.setTerritoryUuid(UUID.randomUUID());
		territoryTwo.setTerritoryIsoCode("ABC");
		territoryTwo.setTerritoryName("ABC");
		territoryTwo.setCountryUuid(UUID.randomUUID());
		territoryTwo.setCountryIso3Code("GBR");
		territoryTwo.setCountryName("United Kingdom");
		territoryTwo.setLegacyReference("");
		territoryTwo.setEffectiveFromDate(LocalDate.now());
		territoryTwo.setEffectiveToDate(LocalDate.now());
		territoriesEventBody.add(territoryTwo);

		return territoriesEventBody;
	}
}
