package com.ielts.cmds.integration.datasetup;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.integration.model.FragmentsRequest;
import com.ielts.cmds.integration.model.LocationSearchResultsV2Envelope;
import com.ielts.cmds.integration.model.LocationSocketResponseMetaDataV2;
import com.ielts.cmds.lpr.common.enums.LocationStatus;
import com.ielts.cmds.lpr.common.enums.LocationTypeCode;
import com.ielts.cmds.lpr.common.enums.PartnerCode;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationBasicDataOutV1;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationSearchResultsV1List;

import java.util.UUID;

public class LPRDistUISetup {

    public static LocationSearchResultsV2Envelope buildUserLocationsResponseForTest(LocationSearchResultsV1List locationSearchResultsV1List) {
        LocationSearchResultsV2Envelope locationSearchResultsV2Envelope = new LocationSearchResultsV2Envelope();
        LocationSocketResponseMetaDataV2 locationSocketResponseMetaDataV2 = new LocationSocketResponseMetaDataV2();
        BaseEventErrors baseEventErrors = new BaseEventErrors();
        locationSocketResponseMetaDataV2.setConnectionId("test");
        locationSocketResponseMetaDataV2.setTotalCount(100);

        FragmentsRequest fragmentsRequest = new FragmentsRequest();
        fragmentsRequest.setTotalFragments(1);
        fragmentsRequest.setFragmentsNumber(1);

        locationSearchResultsV2Envelope.setMeta(locationSocketResponseMetaDataV2);
        locationSearchResultsV2Envelope.setFragments(fragmentsRequest);
        locationSearchResultsV2Envelope.setResponse(locationSearchResultsV1List);
        locationSearchResultsV2Envelope.setErrors(baseEventErrors);

        return  locationSearchResultsV2Envelope;
    }

    public static LocationSearchResultsV1List getLocationsForTest(int LocationSize) {
        LocationSearchResultsV1List locationSearchResultsV1List = new LocationSearchResultsV1List();
        for (int searchLocationsCount = 0; searchLocationsCount < LocationSize; searchLocationsCount++) {
            LocationBasicDataOutV1 location = new LocationBasicDataOutV1();
            location.setLocationStatus(LocationStatus.ACTIVE);
            location.setLocationName("name" + searchLocationsCount);
            location.setCity("city" + searchLocationsCount);
            location.setLocationUuid(UUID.randomUUID());
            location.setTestCentreNumber("testcentre" + searchLocationsCount);
            location.setPartnerCode(PartnerCode.BC);
            location.setCountry("India");
            location.setLocationTypeCode(LocationTypeCode.TEST_CENTRE);
            locationSearchResultsV1List.add(location);
        }
        return locationSearchResultsV1List;
    }

    public static LocationSearchResultsV2Envelope getEmptyLocationsResponse() {
        LocationSearchResultsV2Envelope locationSearchResultsV2Envelope = new LocationSearchResultsV2Envelope();
        LocationSearchResultsV1List locationSearchResultsV1List = new LocationSearchResultsV1List();
        LocationSocketResponseMetaDataV2 socketResponseMetaDataV2 = new LocationSocketResponseMetaDataV2();
        socketResponseMetaDataV2.setConnectionId("test");
        socketResponseMetaDataV2.setCorrelationId(String.valueOf(UUID.randomUUID()));
        locationSearchResultsV2Envelope.setResponse(locationSearchResultsV1List);
        locationSearchResultsV2Envelope.setMeta(socketResponseMetaDataV2);

        return locationSearchResultsV2Envelope;
    }
}
