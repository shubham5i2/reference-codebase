package com.ielts.cmds.integration.datasetup;

import java.util.UUID;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.lpr142locationpersisted.LocationPersisted;

public class LocationPersistedEventDataSetup {

    final ObjectMapper mapper = new ObjectMapper();

       public LocationPersisted populateLocationPersistedEventBody() {
    	   LocationPersisted locationPersistedEventData = new LocationPersisted();

        locationPersistedEventData.setLocationUuid(
                UUID.fromString("13132c0e-5938-41d3-98f6-ebee42bd7f97"));
        locationPersistedEventData.setLocationName("IDP Melbourne");
        locationPersistedEventData.setTestCentreNumber("AU241");

        return locationPersistedEventData;
    }
   
}
