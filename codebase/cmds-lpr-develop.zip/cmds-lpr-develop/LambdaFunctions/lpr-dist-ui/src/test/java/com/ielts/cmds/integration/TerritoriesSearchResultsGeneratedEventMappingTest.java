package com.ielts.cmds.integration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.datasetup.MapperHeaderSetUp;
import com.ielts.cmds.integration.datasetup.TerritoriesEventDataSetup;
import com.ielts.cmds.integration.mapping.TerritoriesSearchResultsGeneratedEventMapping;
import com.ielts.cmds.reference.common.out.event.TerritoriesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.reference.common.out.socketresponse.TerritoriesDataOutV1Envelope;
import com.ielts.cmds.reference.common.out.socketresponse.TerritoriesDataOutV1List;

@ExtendWith(MockitoExtension.class)
class TerritoriesSearchResultsGeneratedEventMappingTest {


	@Spy
	private TerritoriesSearchResultsGeneratedEventMapping territoriesEventMapping;

	
	/**
	 * Test to validate the Response Event Body when Request Event Body is passed.
	 *
	 * @throws JsonProcessingException
	 */
	@Test
	void whenRequestEventBodyProvided_ThenValidateSocketResponseEventBody() throws JsonProcessingException {
		final TerritoriesSearchResultsGeneratedEventV1 eventBody = TerritoriesEventDataSetup.populateEventBody();
		final SocketResponseMetaDataV1 responseHeaders = MapperHeaderSetUp
				.mapRequestEventHeaderToSocketResponseHeader();
		doReturn(responseHeaders).when(territoriesEventMapping).mapRequestEventHeaderToSocketResponseHeader();
		TerritoriesDataOutV1Envelope response = territoriesEventMapping.process(eventBody);
		final TerritoriesDataOutV1List responseBody = response.getResponse();
		assertEquals(eventBody.get(0).getCountryIso3Code(), responseBody.get(0).getCountryIso3Code());
		assertEquals(eventBody.get(0).getCountryName(), responseBody.get(0).getCountryName());
		assertEquals(eventBody.get(0).getTerritoryName(), responseBody.get(0).getTerritoryName());
		assertEquals(eventBody.get(0).getTerritoryIsoCode(), responseBody.get(0).getTerritoryIsoCode());
		
	}
}
