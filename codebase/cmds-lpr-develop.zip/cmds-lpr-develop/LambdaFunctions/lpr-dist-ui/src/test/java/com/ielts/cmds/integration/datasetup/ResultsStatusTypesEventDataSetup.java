package com.ielts.cmds.integration.datasetup;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.reference.common.out.event.ResultStatusCommentSearchGeneratedEventV1ResultStatus;
import com.ielts.cmds.reference.common.out.event.ResultStatusLabelSearchGeneratedEventV1ResultStatus;
import com.ielts.cmds.reference.common.out.event.ResultStatusSearchGeneratedEventV1;
import com.ielts.cmds.reference.common.out.event.ResultStatusSearchGeneratedEventV1ResultStatus;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;

public class ResultsStatusTypesEventDataSetup {

    static final ObjectMapper mapper = new ObjectMapper();

   

    public static ResultStatusSearchGeneratedEventV1 populateEventBodyWithNonEmptyStatus() {
        return Stream.of("Confirmed", "Unconfirmed")
                .map(
                        t ->
                                ResultStatusSearchGeneratedEventV1ResultStatus.builder()
                                        .resultsStatusTypeUuid(UUID.randomUUID())
                                        .resultsStatusType(t)
                                        .resultsStatusCode(t.toUpperCase())
                                        .effectiveFromDate(LocalDate.now())
                                        .effectiveToDate(LocalDate.now().plusYears(1))
                                        .resultStatusLabels(populateResultStatusLabel())
                                        .build())
                .collect(Collectors.toCollection(ResultStatusSearchGeneratedEventV1::new));
    }

    private static List<ResultStatusLabelSearchGeneratedEventV1ResultStatus> populateResultStatusLabel() {
        return Stream.of("Label1","Label2")
                .map(label -> ResultStatusLabelSearchGeneratedEventV1ResultStatus
                                .builder()
                                .resultStatusLabelUuid(UUID.randomUUID())
                                .resultStatusLabel(label)
                                .resultStatusLabelCode(label+"_Code")
                                .resultStatusCommentMandatory(false)
                                .resultStatusComment(populateResultStatusComment())
                                .build()
                        ).collect(Collectors.toList());
    }

    private static List<ResultStatusCommentSearchGeneratedEventV1ResultStatus> populateResultStatusComment() {
        return Stream.of("Comment1","Comment2")
                .map(comment -> ResultStatusCommentSearchGeneratedEventV1ResultStatus.builder()
                        .resultsStatusCommentUuid(UUID.randomUUID())
                        .resultStatusCommentText(comment)
                        .resultStatusCommentCode(comment+"_Code")
                        .build()
                ).collect(Collectors.toList());
    }
}
