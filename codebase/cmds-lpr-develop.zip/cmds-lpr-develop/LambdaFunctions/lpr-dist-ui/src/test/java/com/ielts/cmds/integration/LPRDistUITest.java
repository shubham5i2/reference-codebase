package com.ielts.cmds.integration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.model.LocationSearchResultsV2Envelope;
import com.ielts.cmds.integration.model.LocationSocketResponseMetaDataV2;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationBasicDataOutV1;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationSearchResultsV1List;
import com.ielts.cmds.reference.common.out.socketresponse.AddressTypesDataOutV1;
import com.ielts.cmds.reference.common.out.socketresponse.AddressTypesDataOutV1Envelope;
import com.ielts.cmds.reference.common.out.socketresponse.AddressTypesDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.org.webcompere.systemstubs.environment.EnvironmentVariables;
import uk.org.webcompere.systemstubs.jupiter.SystemStub;
import uk.org.webcompere.systemstubs.jupiter.SystemStubsExtension;

import java.nio.charset.CharacterCodingException;
import java.util.List;
import java.util.UUID;

import static com.ielts.cmds.integration.constants.LPRDistConstants.LOCATIONS_FRAGMENT_SIZE;
import static com.ielts.cmds.integration.datasetup.LPRDistUISetup.buildUserLocationsResponseForTest;
import static com.ielts.cmds.integration.datasetup.LPRDistUISetup.getLocationsForTest;
import static com.ielts.cmds.integration.datasetup.LPRDistUISetup.getEmptyLocationsResponse;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
@ExtendWith(SystemStubsExtension.class)
class LPRDistUITest {

    @Spy
    @InjectMocks
    private LPRDistUI lprDistUI;

    @SystemStub
    private EnvironmentVariables env;

    @BeforeEach
    void setUp() {
        final HeaderContext headerContext = new HeaderContext();
        headerContext.setConnectionId("test");
        headerContext.setCorrelationId(UUID.randomUUID());
        ThreadLocalHeaderContext.setContext(headerContext);
    }

    /**
     * Method to test process search locations response
     */
    @Test
    void whenResponseIsLocationSearchResults_thenShouldCallSendResponseToClientWithLocationsResponse() throws JsonProcessingException {
        // Given
        LocationSearchResultsV2Envelope locationSearchResultsV2Envelope = buildUserLocationsResponseForTest(getLocationsForTest(100));
        final List<List<LocationBasicDataOutV1>> locations = lprDistUI.doLocationPartitioning(getLocationsForTest(100));

        Mockito.doNothing().when(lprDistUI).invokeSendResponseToClient(ArgumentMatchers.any());

        // When
        lprDistUI.sendResponseToClient(locationSearchResultsV2Envelope);
        ArgumentCaptor<LocationSearchResultsV2Envelope> locationSearchResultsV2EnvelopeArgumentCaptor = ArgumentCaptor.forClass(LocationSearchResultsV2Envelope.class);

        try {
            // Then
            verify(lprDistUI, times(locations.size())).invokeSendResponseToClient(locationSearchResultsV2EnvelopeArgumentCaptor.capture());
            assertEquals(locationSearchResultsV2Envelope.getResponse().get(0), locationSearchResultsV2EnvelopeArgumentCaptor.getValue().getResponse().get(0));
            assertEquals(locationSearchResultsV2Envelope.getFragments().getFragmentsNumber(), locationSearchResultsV2EnvelopeArgumentCaptor.getValue().getFragments().getFragmentsNumber());
            assertEquals(locationSearchResultsV2Envelope.getFragments().getTotalFragments(), locationSearchResultsV2EnvelopeArgumentCaptor.getValue().getFragments().getTotalFragments());
            assertEquals(locationSearchResultsV2Envelope.getMeta(), locationSearchResultsV2EnvelopeArgumentCaptor.getValue().getMeta());
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }

    @Test
    void whensLocationsResponseIsEmpty_thenShouldCallSendResponseToClientWithEmptyResponse() throws JsonProcessingException {
        // Given
        LocationSearchResultsV2Envelope locationSearchResultsV2Envelope = getEmptyLocationsResponse();

        Mockito.doNothing().when(lprDistUI).invokeSendResponseToClient(ArgumentMatchers.any());

        // When
        lprDistUI.sendResponseToClient(locationSearchResultsV2Envelope);
        ArgumentCaptor<LocationSearchResultsV2Envelope> locationSearchResultsV2EnvelopeArgumentCaptor = ArgumentCaptor.forClass(LocationSearchResultsV2Envelope.class);

        try {
            // Then
            verify(lprDistUI, times(1)).invokeSendResponseToClient(locationSearchResultsV2EnvelopeArgumentCaptor.capture());
            assertEquals(locationSearchResultsV2Envelope, locationSearchResultsV2EnvelopeArgumentCaptor.getValue());
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to test send response to client when response is not user locations
     */

    @Test
    void whenResponseIsNotLocationSearchResults_thenShouldNotCallProcessUserLocationsResponse() throws JsonProcessingException {

        //  Given
        AddressTypesDataOutV1Envelope addressTypesDataOutV1Envelope = new AddressTypesDataOutV1Envelope();
        AddressTypesDataOutV1List addressTypesDataOutV1List = new AddressTypesDataOutV1List();
        AddressTypesDataOutV1 addressTypesDataOutV1 = new AddressTypesDataOutV1();

        SocketResponseMetaDataV1 socketResponseMetaDataV1 = new SocketResponseMetaDataV1();
        socketResponseMetaDataV1.setCorrelationId(UUID.randomUUID());
        socketResponseMetaDataV1.setConnectionId("test");

        addressTypesDataOutV1List.add(addressTypesDataOutV1);

        addressTypesDataOutV1Envelope.setMeta(socketResponseMetaDataV1);
        addressTypesDataOutV1Envelope.setResponse(addressTypesDataOutV1List);

        Mockito.doNothing().when(lprDistUI).invokeSendResponseToClient(ArgumentMatchers.any());

        lprDistUI.sendResponseToClient(addressTypesDataOutV1Envelope);

        //  When Then
        verify(lprDistUI, times(0)).processLocationsResponse(ArgumentMatchers.any());
        verify(lprDistUI, times(1)).invokeSendResponseToClient(addressTypesDataOutV1Envelope);
    }



    /**
     * Method to test build user location response with mapping
     */
    @Test
    void whenBuildUserLocationsResponse_thenReturnUserLocationsData() throws CharacterCodingException, JsonProcessingException {

        // Given
        LocationSearchResultsV1List locationSearchResultsV1List = getLocationsForTest(500);
        LocationSearchResultsV2Envelope userLocationsDataOutV1EnvelopeResponse = buildUserLocationsResponseForTest(locationSearchResultsV1List);
        List<List<LocationBasicDataOutV1>> partitionedLocationsList = lprDistUI.doLocationPartitioning(locationSearchResultsV1List);

        // When
        List<LocationSearchResultsV2Envelope> actualLocationsResponse = lprDistUI.buildUserLocationsResponses(partitionedLocationsList, userLocationsDataOutV1EnvelopeResponse);

        for(int locationCount = 0; locationCount < actualLocationsResponse.size(); locationCount++) {
            //  Then
            Assertions.assertEquals(userLocationsDataOutV1EnvelopeResponse.getResponse().get(locationCount).getLocationUuid(), actualLocationsResponse.get(locationCount).getResponse().get(locationCount).getLocationUuid());
            Assertions.assertEquals(userLocationsDataOutV1EnvelopeResponse.getResponse().get(locationCount).getCountry(), actualLocationsResponse.get(locationCount).getResponse().get(locationCount).getCountry());
            Assertions.assertEquals(userLocationsDataOutV1EnvelopeResponse.getResponse().get(locationCount).getPartnerCode(), actualLocationsResponse.get(locationCount).getResponse().get(locationCount).getPartnerCode());
            Assertions.assertEquals(userLocationsDataOutV1EnvelopeResponse.getResponse().get(locationCount).getTestCentreNumber(), actualLocationsResponse.get(locationCount).getResponse().get(locationCount).getTestCentreNumber());
        }
    }

    /**
     * Method to test map location partitions response
     */

    @Test
    void whenMapLocationPartitionToResponse_thenReturnMappedResponse() throws JsonProcessingException {
        // Given
        LocationSearchResultsV1List locationSearchResultsV1List = getLocationsForTest(500);
        LocationSearchResultsV2Envelope expectedResponse = buildUserLocationsResponseForTest(locationSearchResultsV1List);

        // When
        LocationSearchResultsV2Envelope actualLocationResponse = lprDistUI.mapLocationPartitionToResponse(locationSearchResultsV1List, expectedResponse, 0, 1);

        // Then
        assertEquals(expectedResponse.getFragments().getTotalFragments(), actualLocationResponse.getFragments().getTotalFragments());
        assertEquals(expectedResponse.getFragments().getFragmentsNumber(), actualLocationResponse.getFragments().getFragmentsNumber());
        assertEquals(expectedResponse.getResponse(), actualLocationResponse.getResponse());
        assertEquals(expectedResponse.getMeta(), actualLocationResponse.getMeta());
    }

    @Test
    void whenDoPartitioningCalled_thenReturnPartitionedLocations() {
        // Given
        LocationSearchResultsV1List expectedLocations = getLocationsForTest(1840);
        // When
        List<List<LocationBasicDataOutV1>> partitionedLocationsList = lprDistUI.doLocationPartitioning(expectedLocations);
        for (int partitionedLocationsCount = 0; partitionedLocationsCount < partitionedLocationsList.size(); partitionedLocationsCount++) {
            List<LocationBasicDataOutV1> actualLocations = partitionedLocationsList.get(partitionedLocationsCount);
            for (int locationCount = partitionedLocationsCount > 0 ? actualLocations.size() : 0; locationCount < actualLocations.size(); locationCount++) {
                // Then
                assertEquals(expectedLocations.get(locationCount), actualLocations.get(locationCount));
            }
        }
        // Then
        assertEquals(4, partitionedLocationsList.size());
    }

    /**
     * Method to test getPartitionSize as default size 500
     */
    @Test
    void whenPartitionSizeIsNotAvailable_thenGetDefaultPartition() {
        // Given
        int expectedFragmentSize = 500;
        // When
        int actualPartitionSize = lprDistUI.getPartitionSize();
        // Then
        assertEquals(expectedFragmentSize, actualPartitionSize);
    }

    /**
     * Method to test getPartitionSize from env variable
     */
    @Test
    void whenPartitionSizeIsAvailable_thenReturnItFromEnv() {
        // Given
        env.set(LOCATIONS_FRAGMENT_SIZE, 600);
        // When
        int actualPartitionSize = lprDistUI.getPartitionSize();
        // Then
        assertEquals(600, actualPartitionSize);
    }

    @Test
    void determinePayloadSize_thenLogWarning() throws  JsonProcessingException {
        // Given
        LocationSearchResultsV1List locationSearchResultsV1List = getLocationsForTest(3000);
        LocationSocketResponseMetaDataV2 socketResponseMetaDataV1 = new LocationSocketResponseMetaDataV2();
        socketResponseMetaDataV1.setConnectionId("test");
        socketResponseMetaDataV1.setCorrelationId(String.valueOf(UUID.randomUUID()));

        LocationSearchResultsV2Envelope userLocationsDataOutV1EnvelopeResponse = new LocationSearchResultsV2Envelope();
        userLocationsDataOutV1EnvelopeResponse.setResponse(locationSearchResultsV1List);
        userLocationsDataOutV1EnvelopeResponse.setMeta(socketResponseMetaDataV1);

        ArgumentCaptor<byte[]> argumentCaptor = ArgumentCaptor.forClass(byte[].class);

        // When
        lprDistUI.determineAndLogPayloadSize(userLocationsDataOutV1EnvelopeResponse);

        // Then
        Mockito.verify(lprDistUI, times(1)).logWarn(argumentCaptor.capture());
    }
}
