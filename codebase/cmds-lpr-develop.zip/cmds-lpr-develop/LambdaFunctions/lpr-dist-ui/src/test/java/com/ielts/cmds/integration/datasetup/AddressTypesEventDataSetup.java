package com.ielts.cmds.integration.datasetup;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.reference.common.out.event.AddressTypesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.event.AddressTypesSearchResultsGeneratedEventV1AddressType;
import com.ielts.cmds.reference.common.out.socketresponse.AddressTypesDataOutV1;
import com.ielts.cmds.reference.common.out.socketresponse.AddressTypesDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

public class AddressTypesEventDataSetup {

	final static ObjectMapper mapper = new ObjectMapper();

	public static AddressTypesSearchResultsGeneratedEventV1 populateEventBody() {

		AddressTypesSearchResultsGeneratedEventV1 addressEventBody = new AddressTypesSearchResultsGeneratedEventV1();

		AddressTypesSearchResultsGeneratedEventV1AddressType addressTypeOne = new AddressTypesSearchResultsGeneratedEventV1AddressType();
		addressTypeOne.setAddressTypeUuid(UUID.randomUUID());
		addressTypeOne.setAddressType("Main");
		addressTypeOne.setDescription("");
		addressTypeOne.setEffectiveFromDate(LocalDate.now());
		addressTypeOne.setEffectiveToDate(LocalDate.now());
		addressEventBody.add(addressTypeOne);

		AddressTypesSearchResultsGeneratedEventV1AddressType addressTypeTwo = new AddressTypesSearchResultsGeneratedEventV1AddressType();
		addressTypeTwo.setAddressTypeUuid(UUID.randomUUID());
		addressTypeTwo.setAddressType("Delivery");
		addressTypeTwo.setDescription("");
		addressTypeTwo.setEffectiveFromDate(LocalDate.now());
		addressTypeTwo.setEffectiveToDate(LocalDate.now());
		addressEventBody.add(addressTypeTwo);
		return addressEventBody;
	}
}
