package com.ielts.cmds.integration.datasetup;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.reference.common.out.event.ContactTypesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.event.ContactTypesSearchResultsGeneratedEventV1ContactType;
import com.ielts.cmds.reference.common.out.socketresponse.ContactTypesDataOutV1;
import com.ielts.cmds.reference.common.out.socketresponse.ContactTypesDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;

public class ContactTypesEventDataSetup {

	final static ObjectMapper mapper = new ObjectMapper();

	public static ContactTypesSearchResultsGeneratedEventV1 populateEventBody() {

		ContactTypesSearchResultsGeneratedEventV1 contactsEventBody = new ContactTypesSearchResultsGeneratedEventV1();

		ContactTypesSearchResultsGeneratedEventV1ContactType contactTypeOne = new ContactTypesSearchResultsGeneratedEventV1ContactType();
		contactTypeOne.setContactTypeUuid(UUID.randomUUID());
		contactTypeOne.setContactType("Primary");
		contactTypeOne.setDescription("");
		contactTypeOne.setEffectiveFromDate(LocalDate.now());
		contactTypeOne.setEffectiveToDate(LocalDate.now());
		contactsEventBody.add(contactTypeOne);

		ContactTypesSearchResultsGeneratedEventV1ContactType contactTypeTwo = new ContactTypesSearchResultsGeneratedEventV1ContactType();
		contactTypeTwo.setContactTypeUuid(UUID.randomUUID());
		contactTypeTwo.setContactType("Results Admin");
		contactTypeTwo.setDescription("");
		contactTypeTwo.setEffectiveFromDate(LocalDate.now());
		contactTypeTwo.setEffectiveToDate(LocalDate.now());
		contactsEventBody.add(contactTypeTwo);
		return contactsEventBody;
	}
}
