package com.ielts.cmds.integration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.datasetup.MapperHeaderSetUp;
import com.ielts.cmds.integration.datasetup.ModuleTypesEventDataSetup;
import com.ielts.cmds.integration.mapping.ModuleTypesSearchResultsGeneratedEventMapping;
import com.ielts.cmds.reference.common.out.event.ModuleTypesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.socketresponse.ModuleTypesDataOutV1Envelope;
import com.ielts.cmds.reference.common.out.socketresponse.ModuleTypesDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;

@ExtendWith(MockitoExtension.class)
class ModuleTypesSearchResultsGeneratedEventMappingTest {

	
	
	@Spy
	private ModuleTypesSearchResultsGeneratedEventMapping moduleTypesEventMapping;

	

	/**
	 * Test to validate the Response Event Body when Request Event Body is passed.
	 *
	 * @throws JsonProcessingException
	 */
	@Test
	void whenRequestEventBodyProvided_ThenValidateSocketResponseEventBody() throws JsonProcessingException {
		ModuleTypesSearchResultsGeneratedEventV1 eventBody = ModuleTypesEventDataSetup.populateEventBody();
		final SocketResponseMetaDataV1 responseHeaders = MapperHeaderSetUp
				.mapRequestEventHeaderToSocketResponseHeader();
		doReturn(responseHeaders).when(moduleTypesEventMapping).mapRequestEventHeaderToSocketResponseHeader();
		ModuleTypesDataOutV1Envelope response = moduleTypesEventMapping.process(eventBody);
		final ModuleTypesDataOutV1List responseBody = response.getResponse();
		assertEquals(eventBody.get(0).getModuleType(), responseBody.get(0).getModuleType());
		assertEquals(eventBody.get(0).getModuleTypeUuid(), responseBody.get(0).getModuleTypeUuid());
	}
	
}

