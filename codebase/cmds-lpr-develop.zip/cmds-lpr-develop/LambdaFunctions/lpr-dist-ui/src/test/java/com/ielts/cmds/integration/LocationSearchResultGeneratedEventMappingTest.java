package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.datasetup.SearchLocationEventDataSetup.getLocationSearchResultForTest;
import static com.ielts.cmds.integration.datasetup.SearchLocationEventDataSetup.getLocationSearchResultsV1List;
import static com.ielts.cmds.integration.datasetup.SearchLocationEventDataSetup.buildResponseHeaderForTest;
import static com.ielts.cmds.integration.datasetup.SearchLocationEventDataSetup.searchLocationMapRequestEventHeaderToSocketResponseHeader;
import static com.ielts.cmds.integration.datasetup.SearchLocationEventDataSetup.getLocationUuids;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.doReturn;

import com.amazonaws.services.s3.model.S3Object;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.utils.s3.CMDSS3Client;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.integration.model.LocationSearchResultGeneratedEventV2;
import com.ielts.cmds.integration.model.LocationSearchResultsV2Envelope;
import com.ielts.cmds.integration.model.LocationSocketResponseMetaDataV2;
import com.ielts.cmds.lpr.common.out.model.LocationSearchResultGeneratedEventV1Basic;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationBasicDataOutV1;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationSearchResultsV1List;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.datasetup.SearchLocationEventDataSetup;
import com.ielts.cmds.integration.mapping.LocationSearchResultGeneratedEventMapping;
import com.ielts.cmds.lpr.common.out.socketresponse.LocationSocketResponseMetaDataV1;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@ExtendWith(MockitoExtension.class)
class LocationSearchResultGeneratedEventMappingTest {

	@Spy
	private LocationSearchResultGeneratedEventMapping locationSearchResultGeneratedEventMapping;

	@Mock
	private CMDSS3Client cmdss3Client;

	@Mock
	private S3Object s3Object;


	@BeforeEach
	void setup() {
		final HeaderContext headerContext = new HeaderContext();
		headerContext.setConnectionId("test");
		headerContext.setCorrelationId(UUID.fromString("7e664903-2413-4cf6-8f86-b1b4400d6762"));
		ThreadLocalHeaderContext.setContext(headerContext);
	}

	/**
	 * Test to validate the process method when Request Event Body is passed.
	 *
	 * @throws JsonProcessingException
	 */
	@Test
	void whenRequestEventBodyProvidedThenValidateSocketResponseEventBody() throws IOException {
		// Given
		LocationSearchResultGeneratedEventV2 locationSearchResultGeneratedEventV2 = SearchLocationEventDataSetup.populateLocationSearchEventBody();
		final LocationSocketResponseMetaDataV1 responseHeaders = searchLocationMapRequestEventHeaderToSocketResponseHeader();
		doReturn(responseHeaders).when(locationSearchResultGeneratedEventMapping).buildResponseHeader(locationSearchResultGeneratedEventV2);
		doReturn(getLocationSearchResultForTest()).when(locationSearchResultGeneratedEventMapping).fetchLocationsFromS3();
		ThreadLocalErrorContext.setContext(null);
		// When
		LocationSearchResultsV2Envelope locationSearchResultsV2Envelope = locationSearchResultGeneratedEventMapping.process(locationSearchResultGeneratedEventV2);
		List<LocationBasicDataOutV1> responseBody = locationSearchResultsV2Envelope.getResponse();
		// Then
		assertEquals(locationSearchResultGeneratedEventV2.getResponse().get(0), responseBody.get(0).getLocationUuid());

	}

	@Test
	void whenRequestEventBodyIsEmptyThenReturnEmptyResponse() {
		LocationSearchResultGeneratedEventV2 locationSearchResultGeneratedEventV2 = SearchLocationEventDataSetup.populateEmptyLocationSearchEvent();

		// When
		LocationSearchResultsV2Envelope locationSearchResultsV2Envelope = locationSearchResultGeneratedEventMapping.process(locationSearchResultGeneratedEventV2);

		// Then
		assertTrue(locationSearchResultsV2Envelope.getResponse().isEmpty());
	}

	@Test
	void whenRequestEventBodyIsNullThenReturnEmptyResponse() {
		LocationSearchResultGeneratedEventV2 locationSearchResultGeneratedEventV2 = SearchLocationEventDataSetup.populateEmptyLocationSearchEvent();
		locationSearchResultGeneratedEventV2.setResponse(null);

		// When
		LocationSearchResultsV2Envelope locationSearchResultsV2Envelope = locationSearchResultGeneratedEventMapping.process(locationSearchResultGeneratedEventV2);

		// Then
		assertTrue(locationSearchResultsV2Envelope.getResponse().isEmpty());
	}

	@Test
	void whenGetFilteredLocationsIsCalledThenReturnFilteredLocations() {
		// Given
		List<LocationSearchResultGeneratedEventV1Basic> locations = getLocationSearchResultForTest();
		List<UUID> locationUuids = getLocationUuids();
		// When
		List<LocationSearchResultGeneratedEventV1Basic> filteredLocations = locationSearchResultGeneratedEventMapping.getFilteredLocations(locations, locationUuids);
		// Then
		Assertions.assertEquals(locations,filteredLocations);
	}

	@Test
	void whenMapRequestEventBodyIsCalledToResponseBodyThenReturnMappedEventBody() {
		// Given
		LocationSearchResultsV1List actualResponse = getLocationSearchResultsV1List();
		// When
		LocationSearchResultsV1List expectedResponse = locationSearchResultGeneratedEventMapping.mapRequestEventBodyToResponseBody(getLocationSearchResultForTest());
		// Then
		assertEquals(actualResponse, expectedResponse);
	}

	@Test
	void whenBuildResponseHeaderIsCalledThenReturnHeader() {
		// Given
		LocationSearchResultGeneratedEventV2 locationSearchResultGeneratedEventV2 = SearchLocationEventDataSetup.populateLocationSearchEventBody();
		LocationSocketResponseMetaDataV2 expectedResponseHeader = buildResponseHeaderForTest();
		// When
		LocationSocketResponseMetaDataV2 actualResponseHeader = locationSearchResultGeneratedEventMapping.buildResponseHeader(locationSearchResultGeneratedEventV2);
		// Then
		assertEquals(expectedResponseHeader, actualResponseHeader);
	}

	@Test
	void whenRequestEventBodyIsEmptyWithErrorsThenReturnEmptyResponseWithErrors() {
		// Given
		LocationSearchResultGeneratedEventV2 locationSearchResultGeneratedEventV2 = SearchLocationEventDataSetup.populateEmptyLocationSearchEvent();
		List<ErrorDescription> eventErrors = new ArrayList<>();

		ErrorDescription errorDescription = new ErrorDescription();
		errorDescription.setMessage("test error");
		errorDescription.setErrorCode("001");

		eventErrors.add(errorDescription);
		BaseEventErrors expectedErrors = new BaseEventErrors(eventErrors);

		ThreadLocalErrorContext.setContext(expectedErrors);

		// When
		LocationSearchResultsV2Envelope locationSearchResultsV2Envelope = locationSearchResultGeneratedEventMapping.process(locationSearchResultGeneratedEventV2);

		// Then
		assertTrue(locationSearchResultsV2Envelope.getResponse().isEmpty());
		assertEquals(expectedErrors, locationSearchResultsV2Envelope.getErrors());

	}

	@Test
	void whenGetCmdsS3ClientIsCalledThenReturnCmdsS3Client() {
		assertAll(
				"cmdsS3Client",
				() ->
						assertTrue(
								locationSearchResultGeneratedEventMapping.getCmdsS3Client()
										instanceof CMDSS3Client));
	}
}
