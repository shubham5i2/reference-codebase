package com.ielts.cmds.integration.datasetup;

import java.time.LocalDate;
import java.util.UUID;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.reference.common.out.event.PartnerCodesSearchResultsGeneratedEventV1;
import com.ielts.cmds.reference.common.out.event.PartnerCodesSearchResultsGeneratedEventV1EnvelopePartnerCode;
import com.ielts.cmds.reference.common.out.socketresponse.PartnersDataOutV1;
import com.ielts.cmds.reference.common.out.socketresponse.PartnersDataOutV1List;
import com.ielts.cmds.reference.common.out.socketresponse.SocketResponseMetaDataV1;

public class PartnerCodesEventDataSetup {

	final static ObjectMapper mapper = new ObjectMapper();

	public final static PartnerCodesSearchResultsGeneratedEventV1 populateEventBody() {
		PartnerCodesSearchResultsGeneratedEventV1 partnerCodesResponseList = new PartnerCodesSearchResultsGeneratedEventV1();
		
		PartnerCodesSearchResultsGeneratedEventV1EnvelopePartnerCode partnerOne = new PartnerCodesSearchResultsGeneratedEventV1EnvelopePartnerCode();
		partnerOne.setPartnerUuid(UUID.randomUUID());
		partnerOne.setPartnerCode("BC");
		partnerOne.setPartnerName("British Council");
		partnerOne.setEffectiveFromDate(LocalDate.now());
		partnerOne.setEffectiveToDate(LocalDate.now());
		partnerCodesResponseList.add(partnerOne);

		PartnerCodesSearchResultsGeneratedEventV1EnvelopePartnerCode partnerTwo = new PartnerCodesSearchResultsGeneratedEventV1EnvelopePartnerCode();
		partnerTwo.setPartnerUuid(UUID.randomUUID());
		partnerTwo.setPartnerCode("IDP");
		partnerTwo.setPartnerName("IDP");
		partnerTwo.setEffectiveFromDate(LocalDate.now());
		partnerTwo.setEffectiveToDate(LocalDate.now());
		partnerCodesResponseList.add(partnerTwo);
		return partnerCodesResponseList;
	}
}
