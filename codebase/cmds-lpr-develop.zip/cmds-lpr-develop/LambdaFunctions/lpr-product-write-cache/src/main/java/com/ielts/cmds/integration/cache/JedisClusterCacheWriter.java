package com.ielts.cmds.integration.cache;

import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.evt_059.ProductChanged;
import com.ielts.cmds.api.lpr005productcachechanged.ProductCacheChanged;
import com.ielts.cmds.integration.constants.ProductDataWriteCacheConstants;

import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.JedisCluster;

@Slf4j
public class JedisClusterCacheWriter implements JedisGenericWriter {

	private JedisCluster jedisCluster;
	
	private JedisCacheWriterHelper jedisWriterHelper;

	public JedisClusterCacheWriter(JedisCacheWriterHelper jedisWriterHelper, JedisCluster jedisCluster) {
		this.jedisWriterHelper = jedisWriterHelper;
		this.jedisCluster = jedisCluster;
	}

	@Override
	public ProductCacheChanged writeProductDataToCache(ProductChanged productChanged, String key,
			Map<String, String> productDataToBeStoredInHash) throws JsonProcessingException {
		storeHashMapDataInRedisCluster(key, productDataToBeStoredInHash);
		storeAllProductsDataInRedisCluster(ProductDataWriteCacheConstants.KEY_OF_ALL_PRODUCTS, key);
		storeAllBookableProductsDataInRedisCluster(productChanged.getBookable(),
				ProductDataWriteCacheConstants.KEY_OF_ALL_BOOKABLE_PRODUCTS, key);
		return jedisWriterHelper.createProductCacheChanged(productChanged);

	}

	protected void storeHashMapDataInRedisCluster(String key, Map<String, String> productDataToBeStoredInHash) {
		jedisCluster.hset(key, productDataToBeStoredInHash);
		log.info("Write to Cache in HashMap Done:{} ", key);
	}

	protected void storeAllBookableProductsDataInRedisCluster(boolean isBookable, String keyOfAllBookableProducts,
			String productKey) {
		if (isBookable) {
			jedisCluster.sadd(keyOfAllBookableProducts, productKey);
			log.info("Write to Cache of All Bookable Products Done:{} ", keyOfAllBookableProducts);
		}
	}

	protected void storeAllProductsDataInRedisCluster(String keyOfAllProducts, String productKey) {
		jedisCluster.sadd(keyOfAllProducts, productKey);
		log.info("Write to Cache of All Products Done:{} ", keyOfAllProducts);
	}
}
