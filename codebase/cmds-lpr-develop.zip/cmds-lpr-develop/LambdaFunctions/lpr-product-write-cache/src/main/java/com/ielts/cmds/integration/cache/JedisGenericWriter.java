package com.ielts.cmds.integration.cache;

import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.evt_059.ProductChanged;
import com.ielts.cmds.api.lpr005productcachechanged.ProductCacheChanged;

public interface JedisGenericWriter {

	ProductCacheChanged writeProductDataToCache(ProductChanged productChanged, String key,
			Map<String, String> productDataToBeStoredInHash) throws JsonProcessingException;
}
