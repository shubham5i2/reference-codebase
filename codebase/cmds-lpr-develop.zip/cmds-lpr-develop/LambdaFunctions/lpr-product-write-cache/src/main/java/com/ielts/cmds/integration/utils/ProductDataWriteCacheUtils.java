package com.ielts.cmds.integration.utils;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.evt_059.Module;
import com.ielts.cmds.api.evt_059.ProductChanged;
import com.ielts.cmds.integration.constants.ProductDataWriteCacheConstants;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

public class ProductDataWriteCacheUtils {

    private ObjectMapper objectMapper;

    public ProductDataWriteCacheUtils(ObjectMapper mapper) {
        this.objectMapper = mapper;
    }

    public Set<ConstraintViolation<ProductChanged>> validateProductChangedEvent(ProductChanged productChanged) {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        return validator.validate(productChanged);
    }

    public Map<String, String> mapProductChangedToHashMap(ProductChanged productChanged)
            throws JsonProcessingException {
        Map<String, String> productHashMap = new HashMap<>();
        Optional.ofNullable(productChanged.getProductUuid()).ifPresent(
                productUuid -> productHashMap.put(ProductDataWriteCacheConstants.PRODUCT_UUID, productUuid.toString()));
        Optional.ofNullable(productChanged.getParentProductUuid()).ifPresent(parentProductUuid -> productHashMap
                .put(ProductDataWriteCacheConstants.PARENT_PRODUCT_UUID, parentProductUuid.toString()));
        productHashMap
                .put(ProductDataWriteCacheConstants.LEGACY_PRODUCT_ID,
                        Optional.ofNullable(productChanged.getLegacyProductId())
                                .orElse(""));
        setModuleAsString(productChanged.getModule(), productHashMap);
        Optional.ofNullable(productChanged.getName())
                .ifPresent(name -> productHashMap.put(ProductDataWriteCacheConstants.NAME, name));
        productHashMap.put(
                ProductDataWriteCacheConstants.DESCRIPTION,
                Optional.ofNullable(productChanged.getDescription()).orElse(""));
        Optional.ofNullable(productChanged.getBookable()).ifPresent(
                bookable -> productHashMap.put(ProductDataWriteCacheConstants.BOOKABLE, Boolean.toString(bookable)));
        productHashMap.put(
                ProductDataWriteCacheConstants.DURATION,
                Optional.ofNullable(productChanged.getDuration()).orElse(0).toString());
        productHashMap
                .put(ProductDataWriteCacheConstants.PRODUCT_CHARACTERISTICS, Optional.ofNullable(productChanged.getProductCharacterisitics()).orElse(""));
        Optional.ofNullable(productChanged.getFormat())
                .ifPresent(format -> productHashMap.put(ProductDataWriteCacheConstants.FORMAT, format));
        productHashMap.put(
                ProductDataWriteCacheConstants.COMPONENT,
                Optional.ofNullable(productChanged.getComponent()).orElse(""));
        Optional.ofNullable(productChanged.getApprovalRequired()).ifPresent(approvalRequired -> productHashMap
                .put(ProductDataWriteCacheConstants.APPROVAL_REQUIRED, Boolean.toString(approvalRequired)));
        Optional.ofNullable(productChanged.getAvailableFrom()).ifPresent(availableFromDate -> productHashMap
                .put(ProductDataWriteCacheConstants.AVAILABLE_FROM_DATE, availableFromDate.toString()));
        Optional.ofNullable(productChanged.getAvailableTo()).ifPresent(availableToDate -> productHashMap
                .put(ProductDataWriteCacheConstants.AVAILABLE_TO_DATE, availableToDate.toString()));

        return productHashMap;
    }

    private void setModuleAsString(Module module, Map<String, String> productHashMap)
            throws JsonProcessingException {
        if (module != null) {
            productHashMap.put(ProductDataWriteCacheConstants.MODULE, objectMapper.writeValueAsString(module));
        }
    }

    public void buildHeader(String eventName) {
        HeaderContext headerContext = ThreadLocalHeaderContext.getContext();
        headerContext.setEventDateTime(LocalDateTime.now());
        headerContext.setEventName(eventName);
        ThreadLocalHeaderContext.setContext(headerContext);
    }
}
