package com.ielts.cmds.integration.exception;

public class ProductDataWriteCacheCustomException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5658892483810093309L;

	public ProductDataWriteCacheCustomException(String message) {
		super(message);
	}
}
