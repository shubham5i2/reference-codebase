package com.ielts.cmds.integration.factory;

import java.net.URI;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import com.ielts.cmds.integration.cache.JedisCacheWriter;
import com.ielts.cmds.integration.cache.JedisCacheWriterHelper;
import com.ielts.cmds.integration.cache.JedisClusterCacheWriter;
import com.ielts.cmds.integration.cache.JedisGenericWriter;
import com.ielts.cmds.integration.constants.ProductDataWriteCacheConstants;

import redis.clients.jedis.DefaultJedisClientConfig;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

public class JedisFactory {

	public String getRedisCacheHost() {
		return System.getenv(ProductDataWriteCacheConstants.REDIS_ELASTICACHE_HOST);
	}

	public String getRedisCachePort() {
		return Optional.ofNullable(System.getenv(ProductDataWriteCacheConstants.REDIS_ELASTICACHE_PORT))
				.orElse(ProductDataWriteCacheConstants.DEFAULT_REDIS_ELASTIC_CACHE_PORT);
	}
	
	public boolean isClusterModeEnabled() {
		String isClusterModeEnabled = System.getenv(ProductDataWriteCacheConstants.IS_CLUSTER_MODE_ENABLED);
		return Boolean.valueOf(isClusterModeEnabled);
	}
	
	public JedisCluster getJedisClusterInstance() {
		Set<HostAndPort> jedisClusterNodes = new HashSet<>();
		jedisClusterNodes.add(new HostAndPort(getRedisCacheHost(),
				Integer.parseInt(getRedisCachePort())));
		return new JedisCluster(jedisClusterNodes, DefaultJedisClientConfig.builder().ssl(true).build());
	}
	
	public JedisPool getJedisPoolInstance() {
		final JedisPoolConfig poolConfig = buildPoolConfig();
		String redisEndpointUrl = getRedisCacheHost() + ":"
				+ getRedisCachePort();
		return new JedisPool(poolConfig, URI.create("rediss://" + redisEndpointUrl));
	}
	
	public JedisPoolConfig buildPoolConfig() {
		final JedisPoolConfig poolConfig = new JedisPoolConfig();
		poolConfig.setMaxTotal(2);
		poolConfig.setMaxIdle(1);
		return poolConfig;
	}
	
	public JedisGenericWriter getJedisWriter() {
		boolean isClusterModeEnabled = isClusterModeEnabled();
		if (isClusterModeEnabled) {
			return new JedisClusterCacheWriter(new JedisCacheWriterHelper(), getJedisClusterInstance());
		} else {
			return new JedisCacheWriter(new JedisCacheWriterHelper(), getJedisPoolInstance());
		}
	}
}
