package com.ielts.cmds.integration.cache;

import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.evt_059.ProductChanged;
import com.ielts.cmds.api.lpr005productcachechanged.ProductCacheChanged;
import com.ielts.cmds.integration.constants.ProductDataWriteCacheConstants;

import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

@Slf4j
public class JedisCacheWriter implements JedisGenericWriter {
	
	private Jedis jedis;

	private JedisCacheWriterHelper jedisWriterHelper;

	public JedisCacheWriter(JedisCacheWriterHelper jedisWriterHelper, JedisPool jedisPool) {
		this.jedisWriterHelper = jedisWriterHelper;
		this.jedis = jedisPool.getResource();
	}

	@Override
	public ProductCacheChanged writeProductDataToCache(ProductChanged productChanged, String key,
			Map<String, String> productDataToBeStoredInHash) throws JsonProcessingException {

		log.debug("Connected to Jedis");
		storeHashMapDataInCache(key, productDataToBeStoredInHash);
		storeAllProductsDataInCache(ProductDataWriteCacheConstants.KEY_OF_ALL_PRODUCTS, key);
		storeAllBookableProductsDataInCache(productChanged.getBookable(),
				ProductDataWriteCacheConstants.KEY_OF_ALL_BOOKABLE_PRODUCTS, key);
		return jedisWriterHelper.createProductCacheChanged(productChanged);
	}

	protected void storeHashMapDataInCache(String key,
			Map<String, String> productDataToBeStoredInHash) {
		jedis.hset(key, productDataToBeStoredInHash);
		log.info("Write to Cache in HashMap Done:{} ", key);
	}

	protected void storeAllBookableProductsDataInCache(boolean isBookable, String keyOfAllBookableProducts,
			String productKey) {
		if (isBookable) {
			jedis.sadd(keyOfAllBookableProducts, productKey);
			log.info("Write to Cache of All Bookable Products Done:{} ", keyOfAllBookableProducts);
		}
	}

	protected void storeAllProductsDataInCache(String keyOfAllProducts, String productKey) {
		jedis.sadd(keyOfAllProducts, productKey);
		log.info("Write to Cache of All Products Done:{} ", keyOfAllProducts);
	}
}
