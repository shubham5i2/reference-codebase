package com.ielts.cmds.integration;

import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;

import org.apache.commons.lang3.exception.ExceptionUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.evt_059.ProductChanged;
import com.ielts.cmds.api.lpr005productcachechanged.ProductCacheChanged;
import com.ielts.cmds.common.logger.util.CMDSLambdaLoggerUtil;
import com.ielts.cmds.integration.cache.JedisGenericWriter;
import com.ielts.cmds.integration.constants.ProductDataWriteCacheConstants;
import com.ielts.cmds.integration.exception.ProductDataWriteCacheCustomException;
import com.ielts.cmds.integration.factory.JedisFactory;
import com.ielts.cmds.integration.utils.ProductDataWriteCacheUtils;
import com.ielts.cmds.serialization.lambda.AbstractLambda;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

/** @author cts */
@Slf4j
public class ProductDataWriteCache extends AbstractLambda<ProductChanged, ProductCacheChanged> {

	private ObjectMapper mapper = getMapperWithProperties();

	private ProductDataWriteCacheUtils productDataWriteCacheUtils = getInstanceOfUtils(mapper);

	private JedisGenericWriter jedisWriter;

	private JedisFactory jedisFactory = new JedisFactory();

	protected final CMDSLambdaLoggerUtil loggerUtil = new CMDSLambdaLoggerUtil();

	public ProductDataWriteCache() {
		jedisWriter = jedisFactory.getJedisWriter();
	}

	public ProductDataWriteCache(JedisGenericWriter jedisWriter) {
		this.jedisWriter = jedisWriter;
	}

	private ProductDataWriteCacheUtils getInstanceOfUtils(ObjectMapper mapper) {
		return new ProductDataWriteCacheUtils(mapper);
	}

	/**
	 * Process Request is default method of lambda class.This method will get
	 * invoked when distributor queue message and process the message.
	 *
	 * @param productChanged
	 */
	@SneakyThrows
	@Override
	protected ProductCacheChanged processRequest(ProductChanged productChanged) {

		ProductCacheChanged response = null;
		log.debug("Event received with productUuid :{}", productChanged.getProductUuid());
		try {
			response = validateAndProcessProductChangedEvent(productChanged);
		} catch (ProductDataWriteCacheCustomException e) {
			log.error("Exception in Product Write Lambda: {} ", ExceptionUtils.getStackTrace(e));
			throw e;
		}
		return response;
	}

	public ProductCacheChanged validateAndProcessProductChangedEvent(ProductChanged productChanged) throws JsonProcessingException, ProductDataWriteCacheCustomException {

		ProductCacheChanged response = null;
		Set<ConstraintViolation<ProductChanged>> constraintViolation = productDataWriteCacheUtils
				.validateProductChangedEvent(productChanged);
		String violationMessage = "Mandatory Field Violation";
		
		String propertyViolation = constraintViolation.stream().map(violation -> String.join(" ", violation.getPropertyPath().toString(), violation.getMessage())).collect(Collectors.joining(","));
		violationMessage = String.join(":", violationMessage, propertyViolation);
		if (!constraintViolation.isEmpty()) {
			throw new ProductDataWriteCacheCustomException(violationMessage);
		} else {
			Map<String, String> productDataToBeStoredInHash = productDataWriteCacheUtils
					.mapProductChangedToHashMap(productChanged);
			String key = "product-" + productDataToBeStoredInHash.get(ProductDataWriteCacheConstants.PRODUCT_UUID);

			 response = jedisWriter.writeProductDataToCache(productChanged, key, productDataToBeStoredInHash);

			productDataWriteCacheUtils.buildHeader(ProductDataWriteCacheConstants.PRODUCT_CACHE_CHANGED_EVENT_NAME);

			log.info("Write Operation Done for {} and Published Event", key);
			log.info("Published Event : {}", mapper.writeValueAsString(response));
		}
		return response;
	}

	@Override
	protected String getTopicName() {
		return System.getenv(ProductDataWriteCacheConstants.LPR_TOPIC_OUT_ARN);
	}

}
