package com.ielts.cmds.integration.cache;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.evt_059.Module;
import com.ielts.cmds.api.evt_059.ProductChanged;
import com.ielts.cmds.api.lpr005productcachechanged.ProductCacheChanged;
import com.ielts.cmds.serialization.lambda.mapper.IObjectMapper;

public class JedisCacheWriterHelper implements IObjectMapper {

	public ProductCacheChanged createProductCacheChanged(ProductChanged productChanged) throws JsonProcessingException {
		ProductCacheChanged productCacheChanged = new ProductCacheChanged();
		productCacheChanged.setProductUuid(productChanged.getProductUuid());
		productCacheChanged.setParentProductUuid(productChanged.getParentProductUuid());
		productCacheChanged.setLegacyProductId(productChanged.getLegacyProductId());
		setModuleInProductCacheChanged(productChanged.getModule(), productCacheChanged);
		productCacheChanged.setName(productChanged.getName());
		productCacheChanged.setDescription(productChanged.getDescription());
		productCacheChanged.setBookable(productChanged.getBookable());
		productCacheChanged.setDuration(productChanged.getDuration());
		productCacheChanged.setProductCharacterisitics(productChanged.getProductCharacterisitics());
		productCacheChanged.setFormat(productChanged.getFormat());
		productCacheChanged.setComponent(productChanged.getComponent());
		productCacheChanged.setAvailableFromDate(productChanged.getAvailableFrom());
		productCacheChanged.setAvailableToDate(productChanged.getAvailableTo());
		productCacheChanged.setApprovalRequired(productChanged.getApprovalRequired());
		return productCacheChanged;
	}
	
	private void setModuleInProductCacheChanged(Module module, ProductCacheChanged productCacheChanged) throws JsonProcessingException {
		if(module != null) {
			productCacheChanged.setModule(getMapperWithProperties().writeValueAsString(module));
		} else {
			productCacheChanged.setModule(null);
		}
	}
}
