package com.ielts.cmds.integration.cache;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.evt_059.ProductChanged;
import com.ielts.cmds.api.lpr005productcachechanged.ProductCacheChanged;
import com.ielts.cmds.integration.SQSEventSetup;

@ExtendWith(MockitoExtension.class)
class JedisCacheWriterHelperTest {

	@InjectMocks
	private JedisCacheWriterHelper jedisWriterHelper;
	
	@Mock private ProductChanged event;
	
	@BeforeEach
	public void setUp() throws JsonProcessingException {
		event = SQSEventSetup.populateSQSEvent();
	}
	
	@Test
	void testGenerateProductCacheChagedEvent() throws JsonProcessingException {
		ProductCacheChanged actualProductChangedEvent = jedisWriterHelper.createProductCacheChanged(event);
		assertEquals(event.getProductUuid(), actualProductChangedEvent.getProductUuid());
		assertEquals(event.getParentProductUuid(), actualProductChangedEvent.getParentProductUuid());
		assertEquals(event.getLegacyProductId(), actualProductChangedEvent.getLegacyProductId());
		assertEquals(event.getName(), actualProductChangedEvent.getName());
		assertEquals(event.getDescription(), actualProductChangedEvent.getDescription());
		assertEquals(event.getBookable(), actualProductChangedEvent.getBookable());
		assertEquals(event.getDuration(), actualProductChangedEvent.getDuration());
		assertEquals(event.getProductCharacterisitics(), actualProductChangedEvent.getProductCharacterisitics());
		assertEquals(event.getFormat(), actualProductChangedEvent.getFormat());
		assertEquals(event.getComponent(), actualProductChangedEvent.getComponent());
		assertEquals(event.getApprovalRequired(), actualProductChangedEvent.getApprovalRequired());
		assertEquals(event.getAvailableFrom(), actualProductChangedEvent.getAvailableFromDate());
		assertEquals(event.getAvailableTo(), actualProductChangedEvent.getAvailableToDate());
		event.setModule(null);
	}
	
	@Test
	void testProductCacheChangedEvent_ifModuleIsNull() throws JsonProcessingException {
		event.setModule(null);
		ProductCacheChanged actualProductChangedEvent = jedisWriterHelper.createProductCacheChanged(event);
		assertEquals(null, actualProductChangedEvent.getModule());
	}
}
