package com.ielts.cmds.integration.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;

import org.apache.commons.lang.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.evt_059.ProductChanged;
import com.ielts.cmds.integration.SQSEventSetup;
import com.ielts.cmds.integration.constants.ProductDataWriteCacheConstants;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

@ExtendWith(MockitoExtension.class)
class ProductDataWriteCacheUtilsTest {

	ProductDataWriteCacheUtils productDataUtils;
	
	@Mock Validator validation;
	
	@Mock private ProductChanged event;
	
	@Mock
	private Validator validator;
	
	@Mock
	private ObjectMapper objectMapper;
	
	@BeforeEach
	public void setUp() throws JsonProcessingException {
		event = SQSEventSetup.populateSQSEvent();
		productDataUtils = new ProductDataWriteCacheUtils(objectMapper);
		validator = Validation.buildDefaultValidatorFactory().getValidator();
		final HeaderContext headerContext = new HeaderContext();
		headerContext.setConnectionId("test");
		headerContext.setCorrelationId(UUID.randomUUID());
		headerContext.setEventDateTime(LocalDateTime.now());
		ThreadLocalHeaderContext.setContext(headerContext);
	}
	
	@Test
	void testValidationWithNullValuesOfProductChangedEvent() {
		event.setName(null);
		event.format(null);
		Set<ConstraintViolation<ProductChanged>> violations = productDataUtils.validateProductChangedEvent(event);
		assertFalse(violations.isEmpty());
	}
	
	@Test
	void testValidationWithNonNullValuesOfProductChangedEvent() {
		Set<ConstraintViolation<ProductChanged>> violations = productDataUtils.validateProductChangedEvent(event);
		assertTrue(violations.isEmpty());
	}
	
	@Test
	void testBuildHeader_forSuccessEvent() {
		productDataUtils.buildHeader(ProductDataWriteCacheConstants.PRODUCT_CACHE_CHANGED_EVENT_NAME);
		assertEquals(ProductDataWriteCacheConstants.PRODUCT_CACHE_CHANGED_EVENT_NAME, ThreadLocalHeaderContext.getContext().getEventName());
	}
	
	@Test
	void testMapProductChangedToHashMap() throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		String module = mapper.writeValueAsString(event.getModule());
		when(objectMapper.writeValueAsString(event.getModule())).thenReturn(module);
		Map<String, String> actualProductHashMap = productDataUtils.mapProductChangedToHashMap(event);
		assertEquals(event.getProductUuid().toString(), actualProductHashMap.get(ProductDataWriteCacheConstants.PRODUCT_UUID));
		assertEquals(event.getParentProductUuid().toString(), actualProductHashMap.get(ProductDataWriteCacheConstants.PARENT_PRODUCT_UUID));
		assertEquals(event.getLegacyProductId(), actualProductHashMap.get(ProductDataWriteCacheConstants.LEGACY_PRODUCT_ID));
		assertEquals(module, actualProductHashMap.get(ProductDataWriteCacheConstants.MODULE));
		assertEquals(event.getName(), actualProductHashMap.get(ProductDataWriteCacheConstants.NAME));
		assertEquals(event.getDescription(), actualProductHashMap.get(ProductDataWriteCacheConstants.DESCRIPTION));
		assertEquals(Boolean.toString(event.getBookable()), actualProductHashMap.get(ProductDataWriteCacheConstants.BOOKABLE));
		assertEquals(event.getDuration().toString(), actualProductHashMap.get(ProductDataWriteCacheConstants.DURATION));
		assertEquals(event.getProductCharacterisitics(), actualProductHashMap.get(ProductDataWriteCacheConstants.PRODUCT_CHARACTERISTICS));
		assertEquals(event.getFormat(), actualProductHashMap.get(ProductDataWriteCacheConstants.FORMAT));
		assertEquals(event.getComponent(), actualProductHashMap.get(ProductDataWriteCacheConstants.COMPONENT));
		assertEquals(Boolean.toString(event.getApprovalRequired()), actualProductHashMap.get(ProductDataWriteCacheConstants.APPROVAL_REQUIRED));
		assertEquals(event.getAvailableFrom().toString(), actualProductHashMap.get(ProductDataWriteCacheConstants.AVAILABLE_FROM_DATE));
		assertEquals(event.getAvailableTo().toString(), actualProductHashMap.get(ProductDataWriteCacheConstants.AVAILABLE_TO_DATE));
	}
	
	@Test
	void testMap_productChangedEventWithNullForOptionalValues_verifyHashMap() throws JsonProcessingException {
		event.setComponent(null);
		event.setDescription(null);
		event.setDuration(null);
		event.setModule(null);
		Map<String, String> actualProductHashMap = productDataUtils.mapProductChangedToHashMap(event);
		assertTrue(StringUtils.isBlank(actualProductHashMap.get(ProductDataWriteCacheConstants.COMPONENT)));
		assertTrue(StringUtils.isBlank(actualProductHashMap.get(ProductDataWriteCacheConstants.DESCRIPTION)));
		assertEquals(0, Integer.parseInt(actualProductHashMap.get(ProductDataWriteCacheConstants.DURATION)));
		assertTrue(StringUtils.isBlank(actualProductHashMap.get(ProductDataWriteCacheConstants.MODULE)));
	}
}
