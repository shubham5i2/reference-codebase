package com.ielts.cmds.integration.cache;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.amazonaws.services.lambda.runtime.Context;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.evt_059.ProductChanged;
import com.ielts.cmds.integration.SQSEventSetup;
import com.ielts.cmds.integration.constants.ProductDataWriteCacheConstants;
import com.ielts.cmds.integration.utils.ProductDataWriteCacheUtils;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

@ExtendWith(MockitoExtension.class)
class JedisCacheTest {

	JedisCacheWriter jedisCacheWriter;
	
	@Mock
	ProductDataWriteCacheUtils productDataUtils;

	@Mock
	private ProductChanged event;

	@Mock
	private Context context;
	
	@Mock Jedis jedisMock;
	
	@Mock JedisPool jedisPool;
	
	@Mock
	JedisCacheWriterHelper jedisWriterHelper;


	
	@BeforeEach
	public void setUp() throws JsonProcessingException {
		event = SQSEventSetup.populateSQSEvent();
		when(jedisPool.getResource()).thenReturn(jedisMock);
		jedisCacheWriter = new JedisCacheWriter(jedisWriterHelper, jedisPool);

	}

	@Test
	void testStoreData() throws JsonProcessingException {
		Map<String, String> data = SQSEventSetup.getProductDataInHashMap(event);
		jedisCacheWriter.storeHashMapDataInCache("product-" + event.getProductUuid(), data);
		verify(jedisMock).hset("product-" + event.getProductUuid(), data);
	}

	@Test
	void testStoreAllProductsData() {
		jedisCacheWriter.storeAllProductsDataInCache(ProductDataWriteCacheConstants.KEY_OF_ALL_PRODUCTS,
				"product-" + event.getProductUuid());
		verify(jedisMock).sadd(ProductDataWriteCacheConstants.KEY_OF_ALL_PRODUCTS,
				"product-" + event.getProductUuid());
	}

	@Test
	void testStoreAllBookableProductData_whenProductIsBookableTrue() {
		jedisCacheWriter.storeAllBookableProductsDataInCache(
				Boolean.TRUE,
				ProductDataWriteCacheConstants.KEY_OF_ALL_BOOKABLE_PRODUCTS,
				"product-" + event.getProductUuid());
		verify(jedisMock, times(1)).sadd(ProductDataWriteCacheConstants.KEY_OF_ALL_BOOKABLE_PRODUCTS,
				"product-" + event.getProductUuid());
	}
	
	@Test
	void verifyNoCallToRedisCluster_whenProductIsNonBookable() {
		jedisCacheWriter.storeAllBookableProductsDataInCache(
				Boolean.FALSE,
				ProductDataWriteCacheConstants.KEY_OF_ALL_BOOKABLE_PRODUCTS,
				"product-" + event.getProductUuid());
		verify(jedisMock, times(0)).sadd(ProductDataWriteCacheConstants.KEY_OF_ALL_BOOKABLE_PRODUCTS,
				"product-" + event.getProductUuid());
	}

	@Test
	void test_nonBookableProductData_WriteToRedisCluster() throws JsonProcessingException {
		Map<String, String> data = SQSEventSetup.getProductDataInHashMap(event);
		jedisCacheWriter.writeProductDataToCache(event, "product-" + event.getProductUuid(), data);
		verify(jedisMock).hset("product-" + event.getProductUuid(), data);
		verify(jedisMock).sadd(ProductDataWriteCacheConstants.KEY_OF_ALL_PRODUCTS,
				"product-" + event.getProductUuid());
		verify(jedisMock, times(0)).sadd(ProductDataWriteCacheConstants.KEY_OF_ALL_BOOKABLE_PRODUCTS,
				"product-" + event.getProductUuid());
	}
	
	@Test
	void test_bookableProductData_WriteToRedisCluster() throws JsonProcessingException {
		event.setBookable(Boolean.TRUE);
		Map<String, String> data = SQSEventSetup.getProductDataInHashMap(event);
		jedisCacheWriter.writeProductDataToCache(event, "product-" + event.getProductUuid(), data);
		verify(jedisMock).hset("product-" + event.getProductUuid(), data);
		verify(jedisMock).sadd(ProductDataWriteCacheConstants.KEY_OF_ALL_PRODUCTS,
				"product-" + event.getProductUuid());
		verify(jedisMock, times(1)).sadd(ProductDataWriteCacheConstants.KEY_OF_ALL_BOOKABLE_PRODUCTS,
				"product-" + event.getProductUuid());
	}
}
