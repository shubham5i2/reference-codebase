package com.ielts.cmds.integration.cache;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.amazonaws.services.lambda.runtime.Context;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.evt_059.ProductChanged;
import com.ielts.cmds.integration.SQSEventSetup;
import com.ielts.cmds.integration.constants.ProductDataWriteCacheConstants;
import com.ielts.cmds.integration.utils.ProductDataWriteCacheUtils;

import redis.clients.jedis.JedisCluster;

@ExtendWith(MockitoExtension.class)
class JedisClusterCacheTest {

	JedisClusterCacheWriter jedisClusterCacheWriter;

	@Mock
	ProductDataWriteCacheUtils productDataUtils;

	@Mock
	private ProductChanged event;

	@Mock
	private Context context;

	@Mock
	private JedisCluster jedisClusterMock;
	
	@Mock
	JedisCacheWriterHelper jedisWriterHelper;

	@BeforeEach
	public void setUp() throws JsonProcessingException {
		event = SQSEventSetup.populateSQSEvent();
		jedisClusterCacheWriter = new JedisClusterCacheWriter(jedisWriterHelper, jedisClusterMock);

	}

	@Test
	void testStoreData() throws JsonProcessingException {
		Map<String, String> data = SQSEventSetup.getProductDataInHashMap(event);
		jedisClusterCacheWriter.storeHashMapDataInRedisCluster("product-" + event.getProductUuid(), data);
		verify(jedisClusterMock).hset("product-" + event.getProductUuid(), data);
	}

	@Test
	void testStoreAllProductsData() {
		jedisClusterCacheWriter.storeAllProductsDataInRedisCluster(ProductDataWriteCacheConstants.KEY_OF_ALL_PRODUCTS,
				"product-" + event.getProductUuid());
		verify(jedisClusterMock).sadd(ProductDataWriteCacheConstants.KEY_OF_ALL_PRODUCTS,
				"product-" + event.getProductUuid());
	}

	@Test
	void testStoreAllBookableProductData_whenProductIsBookableTrue() {
		jedisClusterCacheWriter.storeAllBookableProductsDataInRedisCluster(
				Boolean.TRUE,
				ProductDataWriteCacheConstants.KEY_OF_ALL_BOOKABLE_PRODUCTS,
				"product-" + event.getProductUuid());
		verify(jedisClusterMock, times(1)).sadd(ProductDataWriteCacheConstants.KEY_OF_ALL_BOOKABLE_PRODUCTS,
				"product-" + event.getProductUuid());
	}
	
	@Test
	void verifyNoCallToRedisCluster_whenProductIsNonBookable() {
		jedisClusterCacheWriter.storeAllBookableProductsDataInRedisCluster(
				Boolean.FALSE,
				ProductDataWriteCacheConstants.KEY_OF_ALL_BOOKABLE_PRODUCTS,
				"product-" + event.getProductUuid());
		verify(jedisClusterMock, times(0)).sadd(ProductDataWriteCacheConstants.KEY_OF_ALL_BOOKABLE_PRODUCTS,
				"product-" + event.getProductUuid());
	}

	@Test
	void test_nonBookableProductData_WriteToRedisCluster() throws JsonProcessingException {
		Map<String, String> data = SQSEventSetup.getProductDataInHashMap(event);
		jedisClusterCacheWriter.writeProductDataToCache(event, "product-" + event.getProductUuid(), data);
		verify(jedisClusterMock).hset("product-" + event.getProductUuid(), data);
		verify(jedisClusterMock).sadd(ProductDataWriteCacheConstants.KEY_OF_ALL_PRODUCTS,
				"product-" + event.getProductUuid());
		verify(jedisClusterMock, times(0)).sadd(ProductDataWriteCacheConstants.KEY_OF_ALL_BOOKABLE_PRODUCTS,
				"product-" + event.getProductUuid());
	}
	
	@Test
	void test_bookableProductData_WriteToRedisCluster() throws JsonProcessingException {
		event.setBookable(Boolean.TRUE);
		Map<String, String> data = SQSEventSetup.getProductDataInHashMap(event);
		jedisClusterCacheWriter.writeProductDataToCache(event, "product-" + event.getProductUuid(), data);
		verify(jedisClusterMock).hset("product-" + event.getProductUuid(), data);
		verify(jedisClusterMock).sadd(ProductDataWriteCacheConstants.KEY_OF_ALL_PRODUCTS,
				"product-" + event.getProductUuid());
		verify(jedisClusterMock, times(1)).sadd(ProductDataWriteCacheConstants.KEY_OF_ALL_BOOKABLE_PRODUCTS,
				"product-" + event.getProductUuid());
	}
}
