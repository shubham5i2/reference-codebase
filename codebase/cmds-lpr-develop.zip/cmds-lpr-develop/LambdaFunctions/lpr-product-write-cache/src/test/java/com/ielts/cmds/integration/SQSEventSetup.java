package com.ielts.cmds.integration;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.evt_059.Module;
import com.ielts.cmds.api.evt_059.ProductChanged;
import com.ielts.cmds.api.lpr005productcachechanged.ProductCacheChanged;
import com.ielts.cmds.integration.constants.ProductDataWriteCacheConstants;

public class SQSEventSetup {

  public static ProductChanged populateSQSEvent() throws JsonProcessingException {
	  ProductChanged productChanged = new ProductChanged();
	  productChanged.setProductUuid(UUID.fromString("cb6f4028-c2d8-48f1-8006-1343760ec905"));
	  productChanged.setName("IELTS Online AC W");
	  productChanged.setParentProductUuid(UUID.randomUUID());
	  productChanged.setApprovalRequired(true);
	  productChanged.setAvailableFrom(LocalDate.of(2020, 07, 01));
	  productChanged.setAvailableTo(LocalDate.of(2099, 12, 31));
	  productChanged.setBookable(false);
	  productChanged.setComponent("W");
	  productChanged.setDescription("fr");
	  productChanged.setFormat("rg");
	  productChanged.setDuration(1);
	  productChanged.setLegacyProductId("de");
	  productChanged.setProductCharacterisitics("vdf");
	  Module module = new Module();
	  module.setModuleType("AC");
	  module.setModuleTypeUuid(UUID.randomUUID());
	  module.setDescription("Academic");
	  productChanged.setModule(module);
    return productChanged;
  }
  
  public static Map<String, String> getProductDataInHashMap(ProductChanged productChanged) throws JsonProcessingException{
	  Map<String, String> hash = new HashMap<>();
		hash.put(ProductDataWriteCacheConstants.PRODUCT_UUID, productChanged.getProductUuid().toString());
		hash.put(ProductDataWriteCacheConstants.PARENT_PRODUCT_UUID, productChanged.getParentProductUuid().toString());
		hash.put(ProductDataWriteCacheConstants.LEGACY_PRODUCT_ID, productChanged.getLegacyProductId());
		hash.put(ProductDataWriteCacheConstants.MODULE, new ObjectMapper().writeValueAsString(productChanged.getModule()));
		hash.put(ProductDataWriteCacheConstants.NAME, productChanged.getName());
		hash.put(ProductDataWriteCacheConstants.DESCRIPTION, productChanged.getDescription());
		hash.put(ProductDataWriteCacheConstants.BOOKABLE, productChanged.getBookable().toString());
		hash.put(ProductDataWriteCacheConstants.DURATION, productChanged.getDuration().toString());
		hash.put(ProductDataWriteCacheConstants.PRODUCT_CHARACTERISTICS, productChanged.getProductCharacterisitics());
		hash.put(ProductDataWriteCacheConstants.FORMAT, productChanged.getFormat());
		hash.put(ProductDataWriteCacheConstants.COMPONENT, productChanged.getComponent());
		hash.put(ProductDataWriteCacheConstants.APPROVAL_REQUIRED, productChanged.getApprovalRequired().toString());
		hash.put(ProductDataWriteCacheConstants.AVAILABLE_FROM_DATE, productChanged.getAvailableFrom().toString());
		hash.put(ProductDataWriteCacheConstants.AVAILABLE_TO_DATE, productChanged.getAvailableTo().toString());
		return hash;
  }
  
  public static ProductCacheChanged generateProductCacheChangedEvent(ProductChanged productChanged) {
		ProductCacheChanged productCacheChanged = new ProductCacheChanged();
		productCacheChanged.setProductUuid(productChanged.getProductUuid());
		productCacheChanged.setParentProductUuid(productChanged.getParentProductUuid());
		productCacheChanged.setLegacyProductId(productChanged.getLegacyProductId());
		productCacheChanged.setModule(Objects.toString(productChanged.getModule(), null));
		productCacheChanged.setName(productChanged.getName());
		productCacheChanged.setDescription(productChanged.getDescription());
		productCacheChanged.setBookable(productChanged.getBookable());
		productCacheChanged.setDuration(productChanged.getDuration());
		productCacheChanged.setProductCharacterisitics(productChanged.getProductCharacterisitics());
		productCacheChanged.setFormat(productChanged.getFormat());
		productCacheChanged.setComponent(productChanged.getComponent());
		productCacheChanged.setAvailableFromDate(productChanged.getAvailableFrom());
		productCacheChanged.setAvailableToDate(productChanged.getAvailableTo());
		productCacheChanged.setApprovalRequired(productChanged.getApprovalRequired());
		return productCacheChanged;
	}
  
}