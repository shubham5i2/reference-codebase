package com.ielts.cmds.integration;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

import javax.validation.Validation;
import javax.validation.Validator;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.amazonaws.services.lambda.runtime.Context;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.evt_059.ProductChanged;
import com.ielts.cmds.api.lpr005productcachechanged.ProductCacheChanged;
import com.ielts.cmds.integration.cache.JedisCacheWriter;
import com.ielts.cmds.integration.cache.JedisClusterCacheWriter;
import com.ielts.cmds.integration.exception.ProductDataWriteCacheCustomException;
import com.ielts.cmds.integration.factory.JedisFactory;
import com.ielts.cmds.integration.utils.ProductDataWriteCacheUtils;
import com.ielts.cmds.serialization.lambda.config.SNSClientConfig;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisPool;

@ExtendWith(MockitoExtension.class)
class ProductDataWriteCacheTest {

	@Mock
	private ProductDataWriteCache productDataWriteCache;

	@Mock
	private ProductChanged event;

	@Mock
	private Context context;

	@Mock
	private JedisCluster jedisClusterMock;

	@Mock
	private JedisPool jedisPoolMock;

	@Mock
	private Jedis jedisMock;

	@Mock
	private Validator validator;

	@Mock
	private JedisClusterCacheWriter jedisClusterCacheWriter;

	@Mock
	private JedisCacheWriter jedisCacheWriter;

	@Spy
	@InjectMocks
	private ProductDataWriteCacheUtils productDataWriteCacheUtils;
	
	@Mock
	private JedisFactory jedisFactory;
	
	private static MockedStatic<SNSClientConfig> snsClientConfig;

	@BeforeAll
	static void init() {
		snsClientConfig = Mockito.mockStatic(SNSClientConfig.class);
	}

	@AfterAll
	static void clear() {
		snsClientConfig.close();
	}

	@BeforeEach
	public void setUp() throws JsonProcessingException, IllegalArgumentException, IllegalAccessException {
		event = SQSEventSetup.populateSQSEvent();
		validator = Validation.buildDefaultValidatorFactory().getValidator();
		productDataWriteCache = new ProductDataWriteCache(jedisClusterCacheWriter);
		final HeaderContext headerContext = new HeaderContext();
		headerContext.setConnectionId("test");
		headerContext.setCorrelationId(UUID.randomUUID());
		headerContext.setEventDateTime(LocalDateTime.now());
		ThreadLocalHeaderContext.setContext(headerContext);

	}
	
	@Test
	void whenProcessRequestIsCalled_verifyCallToWriteJedisCluster() throws JsonProcessingException {
		Map<String, String> data = SQSEventSetup.getProductDataInHashMap(event);
		ProductCacheChanged expectedResponse = SQSEventSetup.generateProductCacheChangedEvent(event);
		when(jedisClusterCacheWriter.writeProductDataToCache(event, "product-" + event.getProductUuid(),
				data)).thenReturn(expectedResponse);
		ProductCacheChanged actualResponse = (ProductCacheChanged) productDataWriteCache.processRequest(event);
		verify(jedisClusterCacheWriter, times(1)).writeProductDataToCache(event, "product-" + event.getProductUuid(),
				data);
		assertEquals(event.getProductUuid(), actualResponse.getProductUuid());
		assertEquals(event.getParentProductUuid(), actualResponse.getParentProductUuid());
		assertEquals(event.getLegacyProductId(), actualResponse.getLegacyProductId());
		assertEquals(event.getName(), actualResponse.getName());
		assertEquals(event.getDescription(), actualResponse.getDescription());
		assertEquals(event.getBookable(), actualResponse.getBookable());
		assertEquals(event.getDuration(), actualResponse.getDuration());
		assertEquals(event.getProductCharacterisitics(), actualResponse.getProductCharacterisitics());
		assertEquals(event.getFormat(), actualResponse.getFormat());
		assertEquals(event.getComponent(), actualResponse.getComponent());
		assertEquals(event.getApprovalRequired(), actualResponse.getApprovalRequired());
		assertEquals(event.getAvailableFrom(), actualResponse.getAvailableFromDate());
		assertEquals(event.getAvailableTo(), actualResponse.getAvailableToDate());
	}

	@Test
	void whenProcessRequestIsCalled_verifyCallToWriteJedisCache() throws JsonProcessingException {
		productDataWriteCache = new ProductDataWriteCache(jedisCacheWriter);
		Map<String, String> data = SQSEventSetup.getProductDataInHashMap(event);
		ProductCacheChanged expectedResponse = SQSEventSetup.generateProductCacheChangedEvent(event);
		when(jedisCacheWriter.writeProductDataToCache(event, "product-" + event.getProductUuid(),
				data)).thenReturn(expectedResponse);
		ProductCacheChanged actualResponse = (ProductCacheChanged) productDataWriteCache.processRequest(event);
		verify(jedisCacheWriter, times(1)).writeProductDataToCache(event, "product-" + event.getProductUuid(), data);
		assertEquals(event.getProductUuid(), actualResponse.getProductUuid());
		assertEquals(event.getParentProductUuid(), actualResponse.getParentProductUuid());
		assertEquals(event.getLegacyProductId(), actualResponse.getLegacyProductId());
		assertEquals(event.getName(), actualResponse.getName());
		assertEquals(event.getDescription(), actualResponse.getDescription());
		assertEquals(event.getBookable(), actualResponse.getBookable());
		assertEquals(event.getDuration(), actualResponse.getDuration());
		assertEquals(event.getProductCharacterisitics(), actualResponse.getProductCharacterisitics());
		assertEquals(event.getFormat(), actualResponse.getFormat());
		assertEquals(event.getComponent(), actualResponse.getComponent());
		assertEquals(event.getApprovalRequired(), actualResponse.getApprovalRequired());
		assertEquals(event.getAvailableFrom(), actualResponse.getAvailableFromDate());
		assertEquals(event.getAvailableTo(), actualResponse.getAvailableToDate());
	}

	@Test
	void verifyExceptionIsThrownIfAnyValidationFails() throws JsonProcessingException {
		event.setName(null);
		event.format(null);
		Executable executable = (() -> productDataWriteCache.processRequest(event));
        Assertions.assertThrows(ProductDataWriteCacheCustomException.class, executable);
	}

}
