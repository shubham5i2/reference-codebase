package com.ielts.cmds.integration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.cache.constants.RefDataCacheReaderConstants;
import com.ielts.cmds.integration.cache.factory.IService;
import com.ielts.cmds.integration.cache.factory.JedisFactory;
import com.ielts.cmds.integration.cache.factory.ServiceFactory;
import com.ielts.cmds.integration.event.GenericReferenceEvent;
import com.ielts.cmds.integration.response.GatewayResponseEntity;
import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.UnifiedJedis;
import redis.clients.jedis.exceptions.JedisConnectionException;

import java.util.HashMap;
import java.util.Map;

import static com.ielts.cmds.integration.cache.constants.RefDataCacheReaderConstants.ACCESS_CONTROL_ALLOW_ORIGIN;
import static com.ielts.cmds.integration.cache.constants.RefDataCacheReaderConstants.UI_DOMAIN;

@Slf4j
public class RefDataCacheReader {

    private UnifiedJedis jedisInstance;

    private final JedisFactory jedisFactory = new JedisFactory();

    private final ServiceFactory serviceFactory = new ServiceFactory();

    public RefDataCacheReader() throws JedisConnectionException {
        jedisInstance = jedisFactory.getJedisInstance();
    }

    public RefDataCacheReader(UnifiedJedis jedisInstance) {
        this.jedisInstance = jedisInstance;
    }

    public GatewayResponseEntity handleRequest(final GenericReferenceEvent requestEvent) throws JsonProcessingException {
        log.debug("Headers {}", requestEvent.getEventHeader());
        Map<String, String> responseHeaders = new HashMap<>();
        log.debug("request resource {}", buildResource(requestEvent));
        log.info(
                "Event Received in {} with metadata as {}", RefDataCacheReaderConstants.REFERENCE_DATA_CACHE_READER_LAMBDA, requestEvent.getEventHeader());
        IService service = serviceFactory.getService(buildResource(requestEvent));
        GatewayResponseEntity gatewayResponseEntity = (GatewayResponseEntity) service.process(requestEvent, jedisInstance);
        responseHeaders.put(ACCESS_CONTROL_ALLOW_ORIGIN, System.getenv(UI_DOMAIN));
        gatewayResponseEntity.setHeaders(responseHeaders);
        log.info(
                "Response being Sent from {} with metadata as {}", RefDataCacheReaderConstants.REFERENCE_DATA_CACHE_READER_LAMBDA, gatewayResponseEntity);
        return gatewayResponseEntity;
    }
	
	private String buildResource(final GenericReferenceEvent requestEvent) {
        return requestEvent.getEventHeader().getEventName();
    }
}
