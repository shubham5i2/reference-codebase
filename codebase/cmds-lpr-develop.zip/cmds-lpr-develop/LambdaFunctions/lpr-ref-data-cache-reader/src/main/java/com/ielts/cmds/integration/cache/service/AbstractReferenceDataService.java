package com.ielts.cmds.integration.cache.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.ielts.cmds.api.common.generic_reference_ui_client.FieldAttribute;
import com.ielts.cmds.api.common.generic_reference_ui_client.ReferenceNode;
import com.ielts.cmds.integration.cache.client.RedisClient;
import com.ielts.cmds.integration.cache.factory.IService;
import com.ielts.cmds.integration.event.GenericReferenceEvent;
import com.ielts.cmds.integration.event.GenericReferenceEventHeader;
import com.ielts.cmds.lpr.common.model.AdditionalAttributeV1;
import com.ielts.cmds.lpr.common.model.ReferenceDataCacheV1;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static com.ielts.cmds.integration.cache.constants.RefDataCacheReaderConstants.*;

@Slf4j
public abstract class AbstractReferenceDataService extends RedisClient implements IService,Mapper {
	
	public List<ReferenceNode> mapAllReferenceDataToCacheResponse(List<ReferenceDataCacheV1> cacheResponse) {
		log.debug("Result in String:{}", cacheResponse.toString());
		List<ReferenceNode> referenceNodeList = new ArrayList<>();
		for(ReferenceDataCacheV1 referenceData : cacheResponse) {
			referenceNodeList.add(createReferenceNodeResponse(referenceData));
		}
		return referenceNodeList;
	}
	
	public ReferenceNode mapCacheResponseForSingleReferenceData(JSONArray cacheResponse) throws JsonProcessingException {
		log.debug("Result in String:{}", cacheResponse.get(0).toString());
		ReferenceDataCacheV1 referenceDataCacheV1 = getMapperWithProperties().readValue(cacheResponse.get(0).toString(), ReferenceDataCacheV1.class);
		log.debug("Result in ReferenceDataCachev1:{}", referenceDataCacheV1);
		return createReferenceNodeResponse(referenceDataCacheV1);
	}
	
	public List<ReferenceNode>  mapActiveReferenceDataToCacheResponse(List<ReferenceDataCacheV1> cacheResponse) {
		List<ReferenceNode>  referenceNodeList = new ArrayList<>();
		for(ReferenceDataCacheV1 referenceData : cacheResponse) {
			if((Objects.nonNull(referenceData.getEffectiveFromDate()) && referenceData.getEffectiveFromDate().isBefore(LocalDate.now()))
					&& (Objects.nonNull(referenceData.getEffectiveToDate()) && referenceData.getEffectiveToDate().isAfter(LocalDate.now()))) {
				referenceNodeList.add(createReferenceNodeResponse(referenceData));
			}
		}
		return referenceNodeList;
	}
	
	public ReferenceNode createReferenceNodeResponse(ReferenceDataCacheV1 referenceDataCacheV1) {
		ReferenceNode referenceNode = new ReferenceNode();
		referenceNode.setReferenceUuid(referenceDataCacheV1.getReferenceUuid());
		referenceNode.setReferenceValue(referenceDataCacheV1.getName());
		List<FieldAttribute> listOfFieldAttributes = new ArrayList<>();
		FieldAttribute fieldAttribute2 = new FieldAttribute();
		fieldAttribute2.setName(CODE);
		fieldAttribute2.setValue(referenceDataCacheV1.getCode());
		listOfFieldAttributes.add(fieldAttribute2);
		FieldAttribute fieldAttribute3 = new FieldAttribute();
		fieldAttribute3.setName(EFFECTIVE_FROM_DATE);
		if (Objects.nonNull(referenceDataCacheV1.getEffectiveFromDate())) {
			fieldAttribute3.setValue(referenceDataCacheV1.getEffectiveFromDate().toString());
		}
		listOfFieldAttributes.add(fieldAttribute3);
		FieldAttribute fieldAttribute4 = new FieldAttribute();
		fieldAttribute4.setName(EFFECTIVE_TO_DATE);
		if (Objects.nonNull(referenceDataCacheV1.getEffectiveToDate())) {
			fieldAttribute4.setValue(referenceDataCacheV1.getEffectiveToDate().toString());
		}
		listOfFieldAttributes.add(fieldAttribute4);
		FieldAttribute fieldAttribute5 = new FieldAttribute();
		fieldAttribute5.setName(DESCRIPTION);
		fieldAttribute5.setValue(referenceDataCacheV1.getDescription());
		listOfFieldAttributes.add(fieldAttribute5);
		if(Objects.nonNull(referenceDataCacheV1.getAdditionalDetails())){
			for(AdditionalAttributeV1 additionalAttribute : referenceDataCacheV1.getAdditionalDetails()) {
				FieldAttribute fieldAttribute = new FieldAttribute();
				fieldAttribute.setName(additionalAttribute.getName());
				fieldAttribute.setValue(additionalAttribute.getValue());
				listOfFieldAttributes.add(fieldAttribute);
			}
		}
		referenceNode.setFieldDetails(listOfFieldAttributes);
		return referenceNode;
	}
	
	public List<ReferenceDataCacheV1> convertTheDataToCacheFormat(JSONArray cacheResponse) throws JsonProcessingException {
		List<ReferenceDataCacheV1> referenceDataCacheV1List = new ArrayList<>();
		if(Objects.nonNull(cacheResponse)) {
			log.debug("Cache Response: {}", cacheResponse);
			log.debug("Cache Response Size: {}", cacheResponse.length());
			CollectionType typReference =
					TypeFactory.defaultInstance()
							.constructCollectionType(List.class, ReferenceDataCacheV1.class);
			referenceDataCacheV1List = getMapperWithProperties().readValue(cacheResponse.get(0).toString(), typReference);
		}
		return referenceDataCacheV1List;
	}

	public List<ReferenceNode> buildResponseForAllRefDataBasedOnRequest(JSONArray cacheResult, String includeInactive) throws JsonProcessingException {
		List<ReferenceDataCacheV1> cacheFormatData = convertTheDataToCacheFormat(cacheResult);
		log.debug("cacheFormatData {}", cacheFormatData.toString());
		List<ReferenceNode> response;
		if(Boolean.parseBoolean(includeInactive)) {
			response = mapAllReferenceDataToCacheResponse(cacheFormatData);
		} else {
			response = mapActiveReferenceDataToCacheResponse(cacheFormatData);
		}
		return response;
	}

	public String buildKeyForFetchingRefData(GenericReferenceEvent requestEvent) {
		GenericReferenceEventHeader header = requestEvent.getEventHeader();
		String referenceDataType = null;
		if(!header.getEventContext().isEmpty()
				&& Objects.nonNull(header.getEventContext().get(REFERENCE_TYPE))) {
			referenceDataType = header.getEventContext().get(REFERENCE_TYPE);
			referenceDataType =  REFERENCE+referenceDataType+V1_ALL;
		}
		return referenceDataType;
	}

	public String getQueryStringParametersFromRequest(GenericReferenceEvent requestEvent) {
		String includeInactive = FALSE;
		GenericReferenceEventHeader header = requestEvent.getEventHeader();
		if(!header.getEventContext().isEmpty()) {
			Map<String, String> eventContext = header.getEventContext();
			includeInactive = eventContext.get(INCLUDE_INACTIVE);
		}
		return includeInactive;
	}

}
