package com.ielts.cmds.integration.cache.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.common.generic_reference_ui_client.ReferenceNode;
import com.ielts.cmds.integration.cache.constants.RefDataCacheReaderConstants;
import com.ielts.cmds.integration.event.GenericReferenceEvent;
import com.ielts.cmds.integration.event.GenericReferenceEventHeader;
import com.ielts.cmds.integration.response.GatewayResponseEntity;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.json.JSONArray;
import redis.clients.jedis.UnifiedJedis;

import java.util.Objects;

import static com.ielts.cmds.integration.cache.constants.RefDataCacheReaderConstants.END_OF_PATH;
import static com.ielts.cmds.integration.cache.constants.RefDataCacheReaderConstants.PATH_OF_REFERENCE_UUID;

@Slf4j
public class SingleReferenceDataService extends AbstractReferenceDataService {

    
	@Override
	public GatewayResponseEntity process(GenericReferenceEvent requestEvent, UnifiedJedis jedisInstance) {
		log.info("inside single product response mapping...");
        GatewayResponseEntity gatewayResponseEntity = new GatewayResponseEntity();
        try {
            mapSingleReferenceDataResponseBody(gatewayResponseEntity, requestEvent, jedisInstance);
        } catch (Exception exception) {
            log.error("Exception occurred while doing single reference data read operation {}", exception);
            buildGatewayErrorResponse(gatewayResponseEntity);
        }
        log.debug("gatewayResponseEntity {}", gatewayResponseEntity);
        return gatewayResponseEntity;
	}
	
	protected void mapSingleReferenceDataResponseBody(final GatewayResponseEntity gateWayResponseEntity, GenericReferenceEvent requestEvent, UnifiedJedis jedisInstance) throws JsonProcessingException {
        String key = buildKeyForFetchingRefData(requestEvent);
        String path = buildPathForFetchingSingleData(requestEvent);
	    ReferenceNode referenceNode = retrieveSingleReferenceDataFromRedisCache(key, path, jedisInstance);
        if (referenceNode == null) {
            gateWayResponseEntity.setStatusCode(HttpStatus.SC_NOT_FOUND);
        } else {
            gateWayResponseEntity.setStatusCode(HttpStatus.SC_OK);
            gateWayResponseEntity.setBody(getMapperWithProperties().writeValueAsString(referenceNode));
        }
    }

    public ReferenceNode retrieveSingleReferenceDataFromRedisCache(String key, String path, UnifiedJedis jedisInstance) throws JsonProcessingException {
        ReferenceNode response = null;
        log.debug("Key: {}", key);
        log.debug("Path: {}", path);
        if(Objects.nonNull(key) && Objects.nonNull(path)) {
            JSONArray cacheResult = jsonGetFromCache(key, path, jedisInstance);
            log.debug("Cache Result: {}", cacheResult);
            if(Objects.nonNull(cacheResult) && !cacheResult.isEmpty()) {
                response = mapCacheResponseForSingleReferenceData(cacheResult);
            }
        }
        return response;
    }

    String buildPathForFetchingSingleData(GenericReferenceEvent requestEvent) {
        GenericReferenceEventHeader header = requestEvent.getEventHeader();
        String referenceUuid = null;
        if(!header.getEventContext().isEmpty()
                && Objects.nonNull(header.getEventContext().get(RefDataCacheReaderConstants.REFERENCE_UUID))) {
            referenceUuid = header.getEventContext().get(RefDataCacheReaderConstants.REFERENCE_UUID);
            return PATH_OF_REFERENCE_UUID + referenceUuid+ END_OF_PATH;
        }
        return null;
    }

}
