package com.ielts.cmds.integration.cache.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.common.generic_reference_ui_client.ReferenceNode;
import com.ielts.cmds.integration.event.GenericReferenceEvent;
import com.ielts.cmds.integration.response.GatewayResponseEntity;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.json.JSONArray;
import redis.clients.jedis.UnifiedJedis;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.ielts.cmds.integration.cache.constants.RefDataCacheReaderConstants.DOLLAR;

@Slf4j
public class AllReferenceDataService extends AbstractReferenceDataService {

    @Override
    public GatewayResponseEntity process(GenericReferenceEvent requestEvent, UnifiedJedis jedisInstance) {
        log.info("inside all products response mapping...");
        GatewayResponseEntity gatewayResponseEntity = new GatewayResponseEntity();
        try {
            gatewayResponseEntity = mapAllReferenceDataResponseBody(gatewayResponseEntity, requestEvent, jedisInstance);
        } catch (Exception exception) {
            log.error("Exception occurred while doing reference data read operation {}", exception);
            buildGatewayErrorResponse(gatewayResponseEntity);
        }
        log.debug("gatewayResponseEntity {}", gatewayResponseEntity);
        return gatewayResponseEntity;
    }

    protected GatewayResponseEntity mapAllReferenceDataResponseBody(final GatewayResponseEntity gateWayResponseEntity, GenericReferenceEvent requestEvent, UnifiedJedis jedisInstance) throws JsonProcessingException {
        String key = buildKeyForFetchingRefData(requestEvent);
        String includeInactiveQueryParameterValue = getQueryStringParametersFromRequest(requestEvent);
        List<ReferenceNode> referenceNodeLists = retrieveAllReferenceDataFromRedisCache(key, includeInactiveQueryParameterValue, jedisInstance);
        if (referenceNodeLists.isEmpty()) {
            gateWayResponseEntity.setStatusCode(HttpStatus.SC_NOT_FOUND);
        } else {
            gateWayResponseEntity.setStatusCode(HttpStatus.SC_OK);
            gateWayResponseEntity.setBody(getMapperWithProperties().writeValueAsString(referenceNodeLists));
        }
        return gateWayResponseEntity;
    }

    public List<ReferenceNode> retrieveAllReferenceDataFromRedisCache(String key, String includeInactive, UnifiedJedis jedisInstance) throws JsonProcessingException {
        List<ReferenceNode> referenceNodeList = new ArrayList<>();
        log.debug("Key: {}", key);
        if(Objects.nonNull(key)) {
            JSONArray cacheResult = jsonGetFromCache(key, DOLLAR, jedisInstance);
            if(Objects.nonNull(cacheResult) && !cacheResult.isEmpty()) {
                referenceNodeList = buildResponseForAllRefDataBasedOnRequest(cacheResult, includeInactive);
            }
        }
        return referenceNodeList;
    }
}
