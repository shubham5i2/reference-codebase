package com.ielts.cmds.integration.cache.factory;

import com.ielts.cmds.integration.cache.service.AllReferenceDataService;
import com.ielts.cmds.integration.cache.service.SingleReferenceDataService;

import java.util.HashMap;
import java.util.Map;

import static com.ielts.cmds.integration.cache.constants.RefDataCacheReaderConstants.*;

public class ServiceFactory {

	private static final Map<String, IService> mapServices = new HashMap<>();

	static {
		mapServices.put(GET_ALL_ACTIVE_ADDRESS_TYPES, new AllReferenceDataService());
		mapServices.put(GET_ALL_ACTIVE_SECTOR_TYPES, new AllReferenceDataService());
		mapServices.put(GET_ALL_ACTIVE_CONTACT_TYPES, new AllReferenceDataService());
		mapServices.put(GET_ALL_ACTIVE_ACCESS_ARRANGEMENT_TYPES, new AllReferenceDataService());
		mapServices.put(GET_ALL_ACTIVE_BAN_REASON, new AllReferenceDataService());
		mapServices.put(GET_ALL_ACTIVE_CHECK_OUTCOME_STATUS_TYPES, new AllReferenceDataService());
		mapServices.put(GET_ALL_ACTIVE_CHECK_OUTCOME_TYPES, new AllReferenceDataService());
		mapServices.put(GET_ALL_ACTIVE_EDUCATION_LEVEL, new AllReferenceDataService());
		mapServices.put(GET_ALL_ACTIVE_GENDER, new AllReferenceDataService());
		mapServices.put(GET_ALL_ACTIVE_IDENTIFICATION_TYPES, new AllReferenceDataService());
		mapServices.put(GET_ALL_ACTIVE_INCIDENT_STATUS_TYPES, new AllReferenceDataService());
		mapServices.put(GET_ALL_ACTIVE_LANGUAGE, new AllReferenceDataService());
		mapServices.put(GET_ALL_ACTIVE_MARK_CRITERIA, new AllReferenceDataService());
		mapServices.put(GET_ALL_ACTIVE_MODULE_TYPES, new AllReferenceDataService());
		mapServices.put(GET_ALL_ACTIVE_NATIONALITY, new AllReferenceDataService());
		mapServices.put(GET_ALL_ACTIVE_NOTE_TYPES, new AllReferenceDataService());
		mapServices.put(GET_ALL_ACTIVE_OCCUPATION_LEVELS, new AllReferenceDataService());
		mapServices.put(GET_ALL_ACTIVE_OCCUPATION_SECTORS, new AllReferenceDataService());
		mapServices.put(GET_ALL_ACTIVE_ORGANISATION_TYPES, new AllReferenceDataService());
		mapServices.put(GET_ALL_ACTIVE_OUTCOME_STATUS_TYPES, new AllReferenceDataService());
		mapServices.put(GET_ALL_ACTIVE_PARTNER, new AllReferenceDataService());
		mapServices.put(GET_ALL_ACTIVE_PHOTO_TYPE, new AllReferenceDataService());
		mapServices.put(GET_ALL_ACTIVE_REASON_FOR_TEST, new AllReferenceDataService());
		mapServices.put(GET_ALL_ACTIVE_RESULTS_TYPE, new AllReferenceDataService());
		
		mapServices.put(GET_ALL_ADDRESS_TYPES, new AllReferenceDataService());
		mapServices.put(GET_ALL_SECTOR_TYPES, new AllReferenceDataService());
		mapServices.put(GET_ALL_CONTACT_TYPES, new AllReferenceDataService());
		mapServices.put(GET_ALL_ACCESS_ARRANGEMENT_TYPES, new AllReferenceDataService());
		mapServices.put(GET_ALL_BAN_REASON, new AllReferenceDataService());
		mapServices.put(GET_ALL_CHECK_OUTCOME_STATUS_TYPES, new AllReferenceDataService());
		mapServices.put(GET_ALL_CHECK_OUTCOME_TYPES, new AllReferenceDataService());
		mapServices.put(GET_ALL_EDUCATION_LEVEL, new AllReferenceDataService());
		mapServices.put(GET_ALL_GENDER, new AllReferenceDataService());
		mapServices.put(GET_ALL_IDENTIFICATION_TYPES, new AllReferenceDataService());
		mapServices.put(GET_ALL_INCIDENT_STATUS_TYPES, new AllReferenceDataService());
		mapServices.put(GET_ALL_LANGUAGE, new AllReferenceDataService());
		mapServices.put(GET_ALL_MARK_CRITERIA, new AllReferenceDataService());
		mapServices.put(GET_ALL_MODULE_TYPES, new AllReferenceDataService());
		mapServices.put(GET_ALL_NATIONALITY, new AllReferenceDataService());
		mapServices.put(GET_ALL_NOTE_TYPES, new AllReferenceDataService());
		mapServices.put(GET_ALL_OCCUPATION_LEVELS, new AllReferenceDataService());
		mapServices.put(GET_ALL_OCCUPATION_SECTORS, new AllReferenceDataService());
		mapServices.put(GET_ALL_ORGANISATION_TYPES, new AllReferenceDataService());
		mapServices.put(GET_ALL_OUTCOME_STATUS_TYPES, new AllReferenceDataService());
		mapServices.put(GET_ALL_PARTNER, new AllReferenceDataService());
		mapServices.put(GET_ALL_PHOTO_TYPE, new AllReferenceDataService());
		mapServices.put(GET_ALL_REASON_FOR_TEST, new AllReferenceDataService());
		mapServices.put(GET_ALL_RESULTS_TYPE, new AllReferenceDataService());

		mapServices.put(GET_CONTACT_TYPE, new SingleReferenceDataService());
		mapServices.put(GET_ADDRESS_TYPE, new SingleReferenceDataService());
		mapServices.put(GET_SECTOR_TYPE, new SingleReferenceDataService());
		mapServices.put(GET_ACCESS_ARRANGEMENT_TYPE, new SingleReferenceDataService());
		mapServices.put(GET_BAN_REASON, new SingleReferenceDataService());
		mapServices.put(GET_CHECK_OUTCOME_STATUS_TYPE, new SingleReferenceDataService());
		mapServices.put(GET_CHECK_OUTCOME_TYPE, new SingleReferenceDataService());
		mapServices.put(GET_GENDER, new SingleReferenceDataService());
		mapServices.put(GET_EDUCATION_LEVEL, new SingleReferenceDataService());
		mapServices.put(GET_IDENTIFICATION_TYPE, new SingleReferenceDataService());
		mapServices.put(GET_INCIDENT_STATUS_TYPE, new SingleReferenceDataService());
		mapServices.put(GET_LANGUAGE, new SingleReferenceDataService());
		mapServices.put(GET_MARK_CRITERIA, new SingleReferenceDataService());
		mapServices.put(GET_MODULE_TYPE, new SingleReferenceDataService());
		mapServices.put(GET_NATIONALITY, new SingleReferenceDataService());
		mapServices.put(GET_NOTE_TYPE, new SingleReferenceDataService());
		mapServices.put(GET_OCCUPATION_LEVEL, new SingleReferenceDataService());
		mapServices.put(GET_OCCUPATION_SECTOR, new SingleReferenceDataService());
		mapServices.put(GET_ORGANISATION_TYPE, new SingleReferenceDataService());
		mapServices.put(GET_OUTCOME_STATUS_TYPE, new SingleReferenceDataService());
		mapServices.put(GET_PARTNER, new SingleReferenceDataService());
		mapServices.put(GET_PHOTO_TYPE, new SingleReferenceDataService());
		mapServices.put(GET_REASON_FOR_TEST, new SingleReferenceDataService());
		mapServices.put(GET_RESULTS_TYPE, new SingleReferenceDataService());


	}

	public IService getService(final String eventName) {
		return mapServices.get(eventName);
	}


}
