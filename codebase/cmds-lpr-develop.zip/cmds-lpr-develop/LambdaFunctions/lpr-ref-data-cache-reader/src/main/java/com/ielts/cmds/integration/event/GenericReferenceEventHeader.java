package com.ielts.cmds.integration.event;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Map;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString(exclude = "xaccessToken")
public class GenericReferenceEventHeader implements Serializable {

    private static final long serialVersionUID = 7768307846528535813L;

    @NotNull(message = "{cmds.genericReferenceEventHeader.transactionId.null}")
    private UUID transactionId;

    @NotEmpty(message = "{cmds.genericReferenceEventHeader.eventName.null}")
    private String eventName;

    private Map<String, String> eventContext;

    private String xaccessToken;

}
