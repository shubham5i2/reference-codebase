package com.ielts.cmds.integration.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GatewayErrorEntity {
    private String message;
    private String code;
}