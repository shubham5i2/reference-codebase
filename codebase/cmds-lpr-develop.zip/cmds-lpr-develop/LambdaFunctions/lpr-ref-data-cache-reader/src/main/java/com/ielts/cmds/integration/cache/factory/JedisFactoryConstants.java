package com.ielts.cmds.integration.cache.factory;

public class JedisFactoryConstants {

    private JedisFactoryConstants() {
    }

    public static final String REDIS_ELASTIC_CACHE_HOST = "redis_elasticache_host";
    public static final String REDIS_ELASTIC_CACHE_PORT = "redis_elasticache_port";
    public static final String IS_CLUSTER_MODE_ENABLED = "is_cluster_mode_enabled";
    public static final String DEFAULT_REDIS_ELASTIC_CACHE_PORT = "6379";
    public static final String PONG = "pong";

}
