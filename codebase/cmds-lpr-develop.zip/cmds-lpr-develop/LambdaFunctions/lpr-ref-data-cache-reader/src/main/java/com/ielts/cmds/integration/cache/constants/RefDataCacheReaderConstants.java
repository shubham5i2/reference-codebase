package com.ielts.cmds.integration.cache.constants;

public class RefDataCacheReaderConstants {

	private RefDataCacheReaderConstants() {
	}

	public static final String REFERENCE_DATA_CACHE_READER_LAMBDA = "ReferenceDataCacheReader Lambda";

	public static final String UI_DOMAIN = "ui_domain";
	public static final String DOLLAR = "$";

	//	API Endpoints
	public static final String GET_ALL_ACTIVE_ADDRESS_TYPES = "GET/v2/reference/address_type";
	public static final String GET_ALL_ACTIVE_SECTOR_TYPES= "GET/v2/reference/sector_type";
	public static final String GET_ALL_ACTIVE_CONTACT_TYPES = "GET/v2/reference/contact_type";
	public static final String GET_ALL_ACTIVE_ACCESS_ARRANGEMENT_TYPES = "GET/v2/reference/access_arrangement_type";
	public static final String GET_ALL_ACTIVE_BAN_REASON = "GET/v2/reference/ban_reason";
	public static final String GET_ALL_ACTIVE_CHECK_OUTCOME_STATUS_TYPES = "GET/v2/reference/check_outcome_status";
	public static final String GET_ALL_ACTIVE_CHECK_OUTCOME_TYPES = "GET/v2/reference/check_outcome_type";
	public static final String GET_ALL_ACTIVE_EDUCATION_LEVEL = "GET/v2/reference/education_level";
	public static final String GET_ALL_ACTIVE_GENDER = "GET/v2/reference/gender";
	public static final String GET_ALL_ACTIVE_IDENTIFICATION_TYPES = "GET/v2/reference/identification_type";
	public static final String GET_ALL_ACTIVE_INCIDENT_STATUS_TYPES = "GET/v2/reference/incident_status_type";
	public static final String GET_ALL_ACTIVE_LANGUAGE = "GET/v2/reference/language";
	public static final String GET_ALL_ACTIVE_MARK_CRITERIA = "GET/v2/reference/mark_criteria";
	public static final String GET_ALL_ACTIVE_MODULE_TYPES = "GET/v2/reference/module_type";
	public static final String GET_ALL_ACTIVE_NATIONALITY = "GET/v2/reference/nationality";
	public static final String GET_ALL_ACTIVE_NOTE_TYPES = "GET/v2/reference/note_type";
	public static final String GET_ALL_ACTIVE_OCCUPATION_LEVELS = "GET/v2/reference/occupation_level";
	public static final String GET_ALL_ACTIVE_OCCUPATION_SECTORS = "GET/v2/reference/occupation_sector";
	public static final String GET_ALL_ACTIVE_ORGANISATION_TYPES = "GET/v2/reference/organisation_type";
	public static final String GET_ALL_ACTIVE_OUTCOME_STATUS_TYPES = "GET/v2/reference/outcome_status_type";
	public static final String GET_ALL_ACTIVE_PARTNER = "GET/v2/reference/partner";
	public static final String GET_ALL_ACTIVE_PHOTO_TYPE = "GET/v2/reference/photo_type";
	public static final String GET_ALL_ACTIVE_REASON_FOR_TEST = "GET/v2/reference/reason_for_test";
	public static final String GET_ALL_ACTIVE_RESULTS_TYPE = "GET/v2/reference/results_type";
	
	public static final String GET_ALL_ADDRESS_TYPES = "GET/v2/reference/address_type?includeInactive";
	public static final String GET_ALL_SECTOR_TYPES= "GET/v2/reference/sector_type?includeInactive";
	public static final String GET_ALL_CONTACT_TYPES = "GET/v2/reference/contact_type?includeInactive";
	public static final String GET_ALL_ACCESS_ARRANGEMENT_TYPES = "GET/v2/reference/access_arrangement_type?includeInactive";
	public static final String GET_ALL_BAN_REASON = "GET/v2/reference/ban_reason?includeInactive";
	public static final String GET_ALL_CHECK_OUTCOME_STATUS_TYPES = "GET/v2/reference/check_outcome_status?includeInactive";
	public static final String GET_ALL_CHECK_OUTCOME_TYPES = "GET/v2/reference/check_outcome_type?includeInactive";
	public static final String GET_ALL_EDUCATION_LEVEL = "GET/v2/reference/education_level?includeInactive";
	public static final String GET_ALL_GENDER = "GET/v2/reference/gender?includeInactive";
	public static final String GET_ALL_IDENTIFICATION_TYPES = "GET/v2/reference/identification_type?includeInactive";
	public static final String GET_ALL_INCIDENT_STATUS_TYPES = "GET/v2/reference/incident_status_type?includeInactive";
	public static final String GET_ALL_LANGUAGE = "GET/v2/reference/language?includeInactive";
	public static final String GET_ALL_MARK_CRITERIA = "GET/v2/reference/mark_criteria?includeInactive";
	public static final String GET_ALL_MODULE_TYPES = "GET/v2/reference/module_type?includeInactive";
	public static final String GET_ALL_NATIONALITY = "GET/v2/reference/nationality?includeInactive";
	public static final String GET_ALL_NOTE_TYPES = "GET/v2/reference/note_type?includeInactive";
	public static final String GET_ALL_OCCUPATION_LEVELS = "GET/v2/reference/occupation_level?includeInactive";
	public static final String GET_ALL_OCCUPATION_SECTORS = "GET/v2/reference/occupation_sector?includeInactive";
	public static final String GET_ALL_ORGANISATION_TYPES = "GET/v2/reference/organisation_type?includeInactive";
	public static final String GET_ALL_OUTCOME_STATUS_TYPES = "GET/v2/reference/outcome_status_type?includeInactive";
	public static final String GET_ALL_PARTNER = "GET/v2/reference/partner?includeInactive";
	public static final String GET_ALL_PHOTO_TYPE = "GET/v2/reference/photo_type?includeInactive";
	public static final String GET_ALL_REASON_FOR_TEST = "GET/v2/reference/reason_for_test?includeInactive";
	public static final String GET_ALL_RESULTS_TYPE = "GET/v2/reference/results_type?includeInactive";
	
	public static final String GET_ADDRESS_TYPE = "GET/v2/reference/address_type/{addressTypeUuid}";
	public static final String GET_SECTOR_TYPE = "GET/v2/reference/sector_type/{sectorTypeUuid}";
	public static final String GET_CONTACT_TYPE = "GET/v2/reference/contact_type/{contactTypeUuid}";
	public static final String GET_ACCESS_ARRANGEMENT_TYPE = "GET/v2/reference/access_arrangement_type/{accessArrangementTypeUuid}";
	public static final String GET_BAN_REASON = "GET/v2/reference/ban_reason/{banReasonUuid}";
	public static final String GET_CHECK_OUTCOME_STATUS_TYPE = "GET/v2/reference/check_outcome_status/{checkOutcomeStatusUuid}";
	public static final String GET_CHECK_OUTCOME_TYPE = "GET/v2/reference/check_outcome_type/{checkOutcomeTypeUuid}";
	public static final String GET_EDUCATION_LEVEL = "GET/v2/reference/education_level/{educationLevelUuid}";
	public static final String GET_GENDER = "GET/v2/reference/gender/{genderUuid}";
	public static final String GET_IDENTIFICATION_TYPE = "GET/v2/reference/identification_type/{identificationTypeUuid}";
	public static final String GET_INCIDENT_STATUS_TYPE = "GET/v2/reference/incident_status_type/{incidentStatusUuid}";
	public static final String GET_LANGUAGE = "GET/v2/reference/language/{languageUuid}";
	public static final String GET_MARK_CRITERIA = "GET/v2/reference/mark_criteria/{markCriteriaUuid}";
	public static final String GET_MODULE_TYPE = "GET/v2/reference/module_type/{moduleTypeUuid}";
	public static final String GET_NATIONALITY = "GET/v2/reference/nationality/{nationalityUuid}";
	public static final String GET_NOTE_TYPE = "GET/v2/reference/note_type/{noteTypeUuid}";
	public static final String GET_OCCUPATION_LEVEL = "GET/v2/reference/occupation_level/{occupationLevelUuid}";
	public static final String GET_OCCUPATION_SECTOR = "GET/v2/reference/occupation_sector/{occupationSectorUuid}";
	public static final String GET_ORGANISATION_TYPE = "GET/v2/reference/organisation_type/{organisationTypeUuid}";
	public static final String GET_OUTCOME_STATUS_TYPE = "GET/v2/reference/outcome_status_type/{outcomeStatusTypeUuid}";
	public static final String GET_PARTNER = "GET/v2/reference/partner/{partnerUuid}";
	public static final String GET_PHOTO_TYPE = "GET/v2/reference/photo_type/{photoTypeUuid}";
	public static final String GET_REASON_FOR_TEST = "GET/v2/reference/reason_for_test/{reasonForTestUuid}";
	public static final String GET_RESULTS_TYPE = "GET/v2/reference/results_type/{resultsTypeUuid}";


	public static final String ADDRESS_TYPE = "address_type";

	public static final String REFERENCE_TYPE = "reference_type";
	public static final String REFERENCE_UUID = "referenceUuid";
	public static final String INCLUDE_INACTIVE = "includeInactive";
	public static final String REFERENCE = "reference:";
	public static final String V1_ALL = ":v1:all";
	public static final String FALSE = "false";
	public static final String PATH_OF_REFERENCE_UUID = "$.[?(@.referenceUuid=='";
	public static final String END_OF_PATH = "')]";
	public static final String ACCESS_CONTROL_ALLOW_ORIGIN = "Access-Control-Allow-Origin";

	public static final String CODE = "code";
	public static final String DESCRIPTION = "description";
	public static final String EFFECTIVE_FROM_DATE = "effectiveFromDate";
	public static final String EFFECTIVE_TO_DATE = "effectiveToDate";

	// Error Codes
	public static final String V1001 = "V1001";
	public static final String V1001_ERROR_MSG = "Reference data read operation failed due to technical failure";
}
