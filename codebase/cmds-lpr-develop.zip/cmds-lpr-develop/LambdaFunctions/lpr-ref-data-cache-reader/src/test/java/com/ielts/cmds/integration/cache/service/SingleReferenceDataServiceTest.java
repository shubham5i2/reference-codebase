package com.ielts.cmds.integration.cache.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.common.generic_reference_ui_client.ReferenceNode;
import com.ielts.cmds.integration.TestDataSetup;
import com.ielts.cmds.integration.event.GenericReferenceEvent;
import com.ielts.cmds.integration.response.GatewayResponseEntity;
import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import redis.clients.jedis.UnifiedJedis;
import redis.clients.jedis.json.Path2;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SingleReferenceDataServiceTest {

    @InjectMocks
    @Spy
    private SingleReferenceDataService singleReferenceDataService;

    @Mock
    private UnifiedJedis jedisInstance;

    @Spy
    private AbstractReferenceDataService jedisReaderHelper;

    @Test
    void whenSingleReferenceDataRequested_thenReturnReferenceData() throws JsonProcessingException {
        // Given
        GenericReferenceEvent singleReferenceDataEventForTest = TestDataSetup.getReferenceDataEventForTest();
        ReferenceNode response = TestDataSetup.getReferenceDataForTest();
        String expectedResponse = new ObjectMapper().writeValueAsString(response);
        doReturn(response).
        when(singleReferenceDataService).retrieveSingleReferenceDataFromRedisCache(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any());
        // When
        GatewayResponseEntity actualGatewayResponseEntity = singleReferenceDataService.process(singleReferenceDataEventForTest, jedisInstance);
        // Then
        assertEquals(expectedResponse, actualGatewayResponseEntity.getBody());
        assertEquals(HttpStatus.SC_OK, actualGatewayResponseEntity.getStatusCode());
    }

    @Test
    void whenSingleReferenceDataRequested_withNullKey_exceptDataNotFound() throws JsonProcessingException {
        // Given
        GenericReferenceEvent singleReferenceDataEventForTest = TestDataSetup.getReferenceDataEventForTest();
        ReferenceNode response = TestDataSetup.getReferenceDataForTest();
        doReturn(null).
                when(singleReferenceDataService).retrieveSingleReferenceDataFromRedisCache(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any());
        // When
        GatewayResponseEntity actualGatewayResponseEntity = singleReferenceDataService.process(singleReferenceDataEventForTest, jedisInstance);
        // Then
        assertEquals(HttpStatus.SC_NOT_FOUND, actualGatewayResponseEntity.getStatusCode());
    }

    @Test
    void whenSingleReferenceDataIsRequestedAndDataNotAvailable_thenReturnResponseWithNotFound() throws JsonProcessingException {
        // Given
        GenericReferenceEvent singleReferenceDataEventForTest = TestDataSetup.getReferenceDataEventForTest();
        when(singleReferenceDataService.retrieveSingleReferenceDataFromRedisCache(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(null);
        // When
        GatewayResponseEntity actualGatewayResponseEntity = singleReferenceDataService.process(singleReferenceDataEventForTest, jedisInstance);
        // Then
        assertEquals(HttpStatus.SC_NOT_FOUND, actualGatewayResponseEntity.getStatusCode());
    }

    @Test
    void testRetrieveSingleReferenceDataFromRedisCache() throws JsonProcessingException {
        GenericReferenceEvent requestEvent = TestDataSetup.getReferenceDataEventForTest();
        JSONArray dataInCache = TestDataSetup.getSingleReferenceDataResponseInCacheFormat();
        String key = "reference:address_type:v1:all";
        String path = "$.[?(@.referenceUuid=='" + requestEvent.getEventHeader().getEventContext().get("referenceUuid") + "')]";
        when(jedisInstance.jsonGet(key,
                Path2.of(path)))
                .thenReturn(dataInCache);
        ReferenceNode referenceNode = singleReferenceDataService.retrieveSingleReferenceDataFromRedisCache(key, path, jedisInstance);
        assertNotNull(referenceNode);
    }

    @Test
    void whenExceptionIsEncountered_ifSingleReferenceDataIsRequested_verifyResponse() throws JsonProcessingException {
        GenericReferenceEvent singleReferenceDataEventForTest = TestDataSetup.getReferenceDataEventForTest();
        doThrow(JsonProcessingException.class).when(singleReferenceDataService).mapSingleReferenceDataResponseBody(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any());
        // When
        GatewayResponseEntity actualGatewayResponseEntity = singleReferenceDataService.process(singleReferenceDataEventForTest, jedisInstance);
        // Then
        assertEquals(HttpStatus.SC_INTERNAL_SERVER_ERROR, actualGatewayResponseEntity.getStatusCode());
    }

    @Test
    void testBuildPathForFetchingSingleData_withEmptyEventContext() throws JsonProcessingException {
        GenericReferenceEvent singleReferenceDataEventForTest = TestDataSetup.getReferenceDataEventForTest();
        singleReferenceDataEventForTest.getEventHeader().setEventContext(new HashMap<>());
        String path = singleReferenceDataService.buildPathForFetchingSingleData(singleReferenceDataEventForTest);
        assertNull(path);
    }

    @Test
    void testBuildPathForFetchingSingleData_ifRequiredHeaderIsNotPresent() throws JsonProcessingException {
        GenericReferenceEvent singleReferenceDataEventForTest = TestDataSetup.getReferenceDataEventForTest();
        Map<String, String> eventContext = singleReferenceDataEventForTest.getEventHeader().getEventContext();
        eventContext.remove("referenceUuid");
        String path = singleReferenceDataService.buildPathForFetchingSingleData(singleReferenceDataEventForTest);
        assertNull(path);
    }

    @Test
    void testIfKeyIsNullInSingleReferenceDataRequest_verifyNullResponse() throws JsonProcessingException {
        ReferenceNode referenceNode = singleReferenceDataService.retrieveSingleReferenceDataFromRedisCache(null, "path", jedisInstance);
        assertNull(referenceNode);
    }

    @Test
    void testIfPathIsNullInSingleReferenceDataRequest_verifyNullResponse() throws JsonProcessingException {
        ReferenceNode referenceNode = singleReferenceDataService.retrieveSingleReferenceDataFromRedisCache("reference:address_type:v1:all", null, jedisInstance);
        assertNull(referenceNode);
    }

}
