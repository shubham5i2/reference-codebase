package com.ielts.cmds.integration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.api.common.generic_reference_ui_client.FieldAttribute;
import com.ielts.cmds.api.common.generic_reference_ui_client.ReferenceNode;
import com.ielts.cmds.integration.event.GenericReferenceEvent;
import com.ielts.cmds.integration.event.GenericReferenceEventHeader;
import com.ielts.cmds.integration.response.GatewayResponseEntity;
import com.ielts.cmds.lpr.common.model.AdditionalAttributeV1;
import com.ielts.cmds.lpr.common.model.ReferenceDataCacheV1;
import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

import static com.ielts.cmds.integration.cache.constants.RefDataCacheReaderConstants.*;

public class TestDataSetup {


	public static GenericReferenceEvent getReferenceDataEventForTest() {
		GenericReferenceEvent singleProductEvent = new GenericReferenceEvent();

		GenericReferenceEventHeader header = new GenericReferenceEventHeader();
		header.setEventName(GET_ADDRESS_TYPE);
		Map<String, String> eventContext = new HashMap<>();
		eventContext.put("reference_type", "address_type");
		eventContext.put("referenceUuid",  "21cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");
		header.setEventContext(eventContext);
		header.setTransactionId(UUID.randomUUID());
		header.setXaccessToken("token");
		singleProductEvent.setEventHeader(header);

		return singleProductEvent;
	}

	public static GenericReferenceEvent retriveAllReferenceDataEventForTest() {
		GenericReferenceEvent event = new GenericReferenceEvent();

		GenericReferenceEventHeader header = new GenericReferenceEventHeader();
		header.setEventName(GET_ALL_ADDRESS_TYPES);
		Map<String, String> eventContext = new HashMap<>();
		eventContext.put("reference_type", "address_type");
		eventContext.put("includeInactive",  "true");
		header.setEventContext(eventContext);
		header.setTransactionId(UUID.randomUUID());
		header.setXaccessToken("token");
		event.setEventHeader(header);

		return event;
	}

	public static GenericReferenceEvent getAllActiveReferenceDataEventForTest() {
		GenericReferenceEvent event = new GenericReferenceEvent();

		GenericReferenceEventHeader header = new GenericReferenceEventHeader();
		header.setEventName(GET_ALL_ACTIVE_ADDRESS_TYPES);
		Map<String, String> eventContext = new HashMap<>();
		eventContext.put("reference_type", "address_type");
		header.setEventContext(eventContext);
		header.setTransactionId(UUID.randomUUID());
		header.setXaccessToken("token");
		event.setEventHeader(header);

		return event;
	}

	public static GatewayResponseEntity getSingleReferenceDataGatewayResponseEntityForTest() {
		GatewayResponseEntity gatewayResponseEntity = new GatewayResponseEntity();
		gatewayResponseEntity.setBody(getReferenceDataForTest());
		gatewayResponseEntity.setStatusCode(HttpStatus.SC_OK);

		return gatewayResponseEntity;
	}

	public static ReferenceNode getReferenceDataForTest() {
		ReferenceNode referenceNode = new ReferenceNode();
		referenceNode.setReferenceUuid(UUID.randomUUID());
		referenceNode.setReferenceValue("Postal");
		return referenceNode;
	}

	public static List<ReferenceNode> getAllReferenceDataForTest() {
		List<ReferenceNode> referenceNodeList = new ArrayList<>();
		referenceNodeList.add(getReferenceDataForTest());
		ReferenceNode referenceNode2 = getReferenceDataForTest();
		referenceNode2.setReferenceUuid(UUID.randomUUID());
		referenceNode2.setReferenceValue("Main");
		referenceNodeList.add(referenceNode2);
		return referenceNodeList;
	}
	
	public static JSONArray getSingleReferenceDataResponseInCacheFormat() {
		JSONArray jsonArr = new JSONArray();
		JSONObject obj = new JSONObject();
		obj.put("referenceUuid", UUID.randomUUID());
		obj.put("code", "code");
		obj.put("lastUpdatedDatetime", LocalDateTime.now());
		obj.put("referenceDiscriminator", "address_type");
		obj.put("name", "Postal");
		obj.put("description", "Address Type description");
		obj.put("effectiveFromDate", LocalDate.of(2022, 01, 01));
		obj.put("effectiveToDate", LocalDate.of(2099, 12, 31));

		jsonArr.put(obj);
		return jsonArr;
	}

	public static JSONArray getSingleReferenceDataResponseInCacheFormat_withAdditionalDetails() {
		JSONArray jsonArr = new JSONArray();
		JSONObject obj = new JSONObject();
		obj.put("referenceUuid", UUID.randomUUID());
		obj.put("code", "code");
		obj.put("lastUpdatedDatetime", LocalDateTime.now());
		obj.put("referenceDiscriminator", "address_type");
		obj.put("name", "Postal");
		obj.put("description", "Address Type description");
		obj.put("effectiveFromDate", LocalDate.of(2022, 01, 01));
		obj.put("effectiveToDate", LocalDate.of(2099, 12, 31));
		List<JSONObject> listObj = new ArrayList<>();
		JSONObject obj1 = new JSONObject();
		obj1.put("name", "legacyReferenceId");
		obj1.put("value", "ReferenceId");
		listObj.add(obj1);
		obj.put("additionalDetails", listObj);
		jsonArr.put(obj);
		return jsonArr;
	}

	public static ReferenceDataCacheV1 getSingleReferenceDataResponse() {
		ReferenceDataCacheV1 referenceDataCacheV1 = new ReferenceDataCacheV1();
		referenceDataCacheV1.setReferenceUuid(UUID.randomUUID());
		referenceDataCacheV1.setReferenceDiscriminator("address_type");
		referenceDataCacheV1.setName("Postal");
		referenceDataCacheV1.setLastUpdatedDatetime(LocalDateTime.now());
		referenceDataCacheV1.setCode(null);
		referenceDataCacheV1.setDescription("Address Type description");
		referenceDataCacheV1.setEffectiveFromDate(LocalDate.of(2022, 01, 01));
		referenceDataCacheV1.setEffectiveToDate(LocalDate.of(2099, 12, 31));
		List<AdditionalAttributeV1> list = new ArrayList<>();
		AdditionalAttributeV1 additionalAttribute = new AdditionalAttributeV1();
		additionalAttribute.setName("legacyReferenceId");
		additionalAttribute.setValue("ReferenceId");
		list.add(additionalAttribute);
		referenceDataCacheV1.setAdditionalDetails(list);
		return referenceDataCacheV1;
	}
	
	public static List<ReferenceDataCacheV1> getAllReferenceDataResponseInCacheFormat() {
		List<ReferenceDataCacheV1> list = new ArrayList<>();
		ReferenceDataCacheV1 referenceDataCache0 = getSingleReferenceDataResponse();
		list.add(referenceDataCache0);
		ReferenceDataCacheV1 referenceDataCache1 = getSingleReferenceDataResponse();
		referenceDataCache1.setName("Physical");
		list.add(referenceDataCache1);
		ReferenceDataCacheV1 referenceDataCache2 = getSingleReferenceDataResponse();
		referenceDataCache2.setName("Main");
		referenceDataCache2.setEffectiveToDate(LocalDate.of(2023, 12, 31));
		list.add(referenceDataCache2);
		return list;
	}

	public static JSONArray getAllReferenceDataResponse() {
		JSONArray array = new JSONArray();
		array.put(getSingleReferenceDataResponse());
		ReferenceDataCacheV1 referenceDataCache1 = getSingleReferenceDataResponse();
		referenceDataCache1.setName("Physical");
		array.put(referenceDataCache1);
		ReferenceDataCacheV1 referenceDataCache2 = getSingleReferenceDataResponse();
		referenceDataCache2.setName("Main");
		referenceDataCache2.setEffectiveToDate(LocalDate.of(2023, 12, 31));
		array.put(referenceDataCache2);
		return array;
	}
	
	public static ReferenceNode getSingleReferenceDataResponse(JSONArray jsonArr) throws JsonProcessingException {
		Object s = jsonArr.get(0);
		String objString = getMapperWithProperties().writeValueAsString(s);
		ReferenceDataCacheV1 referenceDataCacheV1 = getMapperWithProperties().readValue(objString, ReferenceDataCacheV1.class);
		ReferenceNode referenceNode = new ReferenceNode();
		referenceNode.setReferenceUuid(referenceDataCacheV1.getReferenceUuid());
		referenceNode.setReferenceValue(referenceDataCacheV1.getName());
		List<FieldAttribute> list = new ArrayList<>();

		
		return referenceNode;
	}
	
	public static List<ReferenceNode> getAllActiveReferenceDataResponse(List<ReferenceDataCacheV1> cacheResponse) {
		List<ReferenceNode> referenceNodeList = new ArrayList<>();
		for(ReferenceDataCacheV1 referenceDataCache : cacheResponse) {
			if(referenceDataCache.getEffectiveFromDate().isBefore(LocalDate.now()) && referenceDataCache.getEffectiveToDate().isAfter(LocalDate.now())) {
				ReferenceNode referenceNode = new ReferenceNode();
				referenceNode.setReferenceUuid(referenceDataCache.getReferenceUuid());
				referenceNode.setReferenceValue(referenceDataCache.getName());
				List<FieldAttribute> list = new ArrayList<>();

				referenceNodeList.add(referenceNode);
			}
		}
		return referenceNodeList;
	}
	
	public static List<ReferenceNode> getAllReferenceDataResponse(List<ReferenceDataCacheV1> referenceDataListFromCache) {
		List<ReferenceNode> referenceNodeList = new ArrayList<>();
		for(ReferenceDataCacheV1 referenceDataCache : referenceDataListFromCache) {
			ReferenceNode referenceNode = new ReferenceNode();
			referenceNode.setReferenceUuid(referenceDataCache.getReferenceUuid());
			referenceNode.setReferenceValue(referenceDataCache.getName());
			List<FieldAttribute> list = new ArrayList<>();

			referenceNodeList.add(referenceNode);
		}
		return referenceNodeList;
	}

	public static ObjectMapper getMapperWithProperties() {
		final ObjectMapper mapper = new ObjectMapper();
		mapper.registerModule(new JavaTimeModule());
		mapper.configure(DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE, false);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
		mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
		mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
		return mapper;
	}

	
}
