package com.ielts.cmds.integration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.cache.factory.IService;
import com.ielts.cmds.integration.cache.factory.ServiceFactory;
import com.ielts.cmds.integration.cache.service.AllReferenceDataService;
import com.ielts.cmds.integration.cache.service.SingleReferenceDataService;
import com.ielts.cmds.integration.event.GenericReferenceEvent;
import com.ielts.cmds.integration.response.GatewayResponseEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import redis.clients.jedis.UnifiedJedis;
import uk.org.webcompere.systemstubs.environment.EnvironmentVariables;
import uk.org.webcompere.systemstubs.jupiter.SystemStub;
import uk.org.webcompere.systemstubs.jupiter.SystemStubsExtension;

import java.util.HashMap;
import java.util.Map;

import static com.ielts.cmds.integration.cache.constants.RefDataCacheReaderConstants.UI_DOMAIN;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
@ExtendWith(SystemStubsExtension.class)
class RefDataCacheReaderTest {

    @Mock
	private RefDataCacheReader refDataCacheReader;

	@SystemStub
    private EnvironmentVariables env;

    @Spy
    private ServiceFactory serviceFactory;

	@Mock
    private UnifiedJedis jedisInstance;

    @BeforeEach
    public void setUp() {
        refDataCacheReader = new RefDataCacheReader(jedisInstance);
    }

    @Test
    void whenSingleRefereneDataRequested_thenShouldCallSingleReferenceDataResponseMapping() throws JsonProcessingException {
        GenericReferenceEvent singleRefDataEventForTest = TestDataSetup.getReferenceDataEventForTest();
        refDataCacheReader.handleRequest(singleRefDataEventForTest);
        IService actual = serviceFactory.getService(singleRefDataEventForTest.getEventHeader().getEventName());
        assertNotNull(singleRefDataEventForTest.getEventHeader());
        assertTrue(actual instanceof SingleReferenceDataService);
    }

	@Test
    void whenAllReferenceDataRequested_thenShouldCallAllReferenceDataResponseMapping() throws JsonProcessingException {
        GenericReferenceEvent allReferenceDataEventForTest = TestDataSetup.retriveAllReferenceDataEventForTest();
        refDataCacheReader.handleRequest(allReferenceDataEventForTest);
        IService actual = serviceFactory.getService(allReferenceDataEventForTest.getEventHeader().getEventName());
        assertTrue(actual instanceof AllReferenceDataService);
    }

	@Test
    void whenAllActiveReferenceDataRequested_thenShouldCallAllReferenceDataResponseMapping() throws JsonProcessingException {
        GenericReferenceEvent allReferenceDataEvent = TestDataSetup.getAllActiveReferenceDataEventForTest();
        refDataCacheReader.handleRequest(allReferenceDataEvent);
        IService actual = serviceFactory.getService(allReferenceDataEvent.getEventHeader().getEventName());
        assertTrue(actual instanceof AllReferenceDataService);
    }

	@Test
    void whenAllReferenceDataRequested_thenReturnAllReferenceDataWithCorsHeader() throws JsonProcessingException {
        // Given
        GenericReferenceEvent allReferenceDataEventForTest = TestDataSetup.retriveAllReferenceDataEventForTest();
        Map<String, String> expectedResponseHeaders = new HashMap<>();
        expectedResponseHeaders.put("Access-Control-Allow-Origin", "https://ui.sandbox.cmdsiz.com");
        env.set(UI_DOMAIN, "https://ui.sandbox.cmdsiz.com");
        // When
        GatewayResponseEntity actualGatewayResponseEntity = refDataCacheReader.handleRequest(allReferenceDataEventForTest);

        // Then
        assertEquals(expectedResponseHeaders.get("Access-Control-Allow-Origin"), actualGatewayResponseEntity.getHeaders().get("Access-Control-Allow-Origin"));
    }

	@Test
    void whenSingleReferenceDataRequested_thenReturnAllReferenceDataWithCorsHeader() throws JsonProcessingException {
        // Given
        GenericReferenceEvent allReferenceDataEventForTest = TestDataSetup.getReferenceDataEventForTest();
        Map<String, String> expectedResponseHeaders = new HashMap<>();
        expectedResponseHeaders.put("Access-Control-Allow-Origin", "https://ui.sandbox.cmdsiz.com");
        env.set(UI_DOMAIN, "https://ui.sandbox.cmdsiz.com");
        // When
        GatewayResponseEntity actualGatewayResponseEntity = refDataCacheReader.handleRequest(allReferenceDataEventForTest);

        // Then
        assertEquals(expectedResponseHeaders.get("Access-Control-Allow-Origin"), actualGatewayResponseEntity.getHeaders().get("Access-Control-Allow-Origin"));
    }

}