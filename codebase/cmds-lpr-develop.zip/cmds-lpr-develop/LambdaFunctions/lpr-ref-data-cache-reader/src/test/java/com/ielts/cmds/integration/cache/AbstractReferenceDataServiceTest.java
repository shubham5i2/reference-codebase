package com.ielts.cmds.integration.cache;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.common.generic_reference_ui_client.ReferenceNode;
import com.ielts.cmds.integration.cache.service.AbstractReferenceDataService;
import com.ielts.cmds.integration.event.GenericReferenceEvent;
import org.json.JSONArray;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.TestDataSetup;
import com.ielts.cmds.lpr.common.model.ReferenceDataCacheV1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class AbstractReferenceDataServiceTest {

    @Spy
    AbstractReferenceDataService abstractReferenceDataService;

    @Test
    void testMapAllReferenceDataToCacheResponse()  {
        List<ReferenceDataCacheV1> cacheData = TestDataSetup.getAllReferenceDataResponseInCacheFormat();
        List<ReferenceNode> referenceNodes = abstractReferenceDataService.mapAllReferenceDataToCacheResponse(cacheData);
        assertNotNull(referenceNodes);
        assertEquals(cacheData.stream().count(), referenceNodes.stream().count());
        assertEquals(cacheData.get(0).getReferenceUuid(), referenceNodes.get(0).getReferenceUuid());
        assertEquals(cacheData.get(0).getName(), referenceNodes.get(0).getReferenceValue());
        assertEquals(cacheData.get(0).getCode(), referenceNodes.get(0).getFieldDetails().stream().filter(f->f.getName().equals("code")).findAny().get().getValue());
        assertEquals(cacheData.get(0).getEffectiveFromDate().toString(), referenceNodes.get(0).getFieldDetails().stream().filter(f->f.getName().equals("effectiveFromDate")).findAny().get().getValue());
        assertEquals(cacheData.get(0).getEffectiveToDate().toString(), referenceNodes.get(0).getFieldDetails().stream().filter(f->f.getName().equals("effectiveToDate")).findAny().get().getValue());
        assertEquals(cacheData.get(0).getAdditionalDetails().get(0).getName(), referenceNodes.get(0).getFieldDetails().stream().filter(f->f.getName().equals("legacyReferenceId")).findAny().get().getName());
        assertEquals(cacheData.get(0).getAdditionalDetails().get(0).getValue(), referenceNodes.get(0).getFieldDetails().stream().filter(f->f.getName().equals("legacyReferenceId")).findAny().get().getValue());

        assertEquals(cacheData.get(1).getReferenceUuid(), referenceNodes.get(1).getReferenceUuid());
        assertEquals(cacheData.get(1).getName(), referenceNodes.get(1).getReferenceValue());
        assertEquals(cacheData.get(1).getCode(), referenceNodes.get(1).getFieldDetails().stream().filter(f->f.getName().equals("code")).findAny().get().getValue());
        assertEquals(cacheData.get(1).getEffectiveFromDate().toString(), referenceNodes.get(1).getFieldDetails().stream().filter(f->f.getName().equals("effectiveFromDate")).findAny().get().getValue());
        assertEquals(cacheData.get(1).getEffectiveToDate().toString(), referenceNodes.get(1).getFieldDetails().stream().filter(f->f.getName().equals("effectiveToDate")).findAny().get().getValue());
        assertEquals(cacheData.get(1).getAdditionalDetails().get(0).getName(), referenceNodes.get(1).getFieldDetails().stream().filter(f->f.getName().equals("legacyReferenceId")).findAny().get().getName());
        assertEquals(cacheData.get(1).getAdditionalDetails().get(0).getValue(), referenceNodes.get(1).getFieldDetails().stream().filter(f->f.getName().equals("legacyReferenceId")).findAny().get().getValue());
    }

    @Test
    void testMapActiveReferenceDataToCacheResponse(){
        List<ReferenceDataCacheV1> cacheData = TestDataSetup.getAllReferenceDataResponseInCacheFormat();
        List<ReferenceNode> referenceNodes = abstractReferenceDataService.mapActiveReferenceDataToCacheResponse(cacheData);
        assertNotNull(referenceNodes);
        assertEquals(cacheData.stream().filter(k-> k.getEffectiveToDate().isAfter(LocalDate.now())).count(), referenceNodes.stream().count());
        assertEquals(cacheData.get(0).getReferenceUuid(), referenceNodes.get(0).getReferenceUuid());
        assertEquals(cacheData.get(0).getName(), referenceNodes.get(0).getReferenceValue());
        assertEquals(cacheData.get(0).getCode(), referenceNodes.get(0).getFieldDetails().stream().filter(f->f.getName().equals("code")).findAny().get().getValue());
        assertEquals(cacheData.get(0).getEffectiveFromDate().toString(), referenceNodes.get(0).getFieldDetails().stream().filter(f->f.getName().equals("effectiveFromDate")).findAny().get().getValue());
        assertTrue(cacheData.get(0).getEffectiveToDate().isAfter(LocalDate.now()));
        assertEquals(cacheData.get(0).getEffectiveToDate().toString(), referenceNodes.get(0).getFieldDetails().stream().filter(f->f.getName().equals("effectiveToDate")).findAny().get().getValue());
        assertEquals(cacheData.get(0).getAdditionalDetails().get(0).getName(), referenceNodes.get(0).getFieldDetails().stream().filter(f->f.getName().equals("legacyReferenceId")).findAny().get().getName());
        assertEquals(cacheData.get(0).getAdditionalDetails().get(0).getValue(), referenceNodes.get(0).getFieldDetails().stream().filter(f->f.getName().equals("legacyReferenceId")).findAny().get().getValue());

        assertEquals(cacheData.get(1).getReferenceUuid(), referenceNodes.get(1).getReferenceUuid());
        assertEquals(cacheData.get(1).getName(), referenceNodes.get(1).getReferenceValue());
        assertEquals(cacheData.get(1).getCode(), referenceNodes.get(1).getFieldDetails().stream().filter(f->f.getName().equals("code")).findAny().get().getValue());
        assertEquals(cacheData.get(1).getEffectiveFromDate().toString(), referenceNodes.get(1).getFieldDetails().stream().filter(f->f.getName().equals("effectiveFromDate")).findAny().get().getValue());
        assertTrue(cacheData.get(1).getEffectiveToDate().isAfter(LocalDate.now()));
        assertEquals(cacheData.get(1).getEffectiveToDate().toString(), referenceNodes.get(1).getFieldDetails().stream().filter(f->f.getName().equals("effectiveToDate")).findAny().get().getValue());
        assertEquals(cacheData.get(1).getAdditionalDetails().get(0).getName(), referenceNodes.get(1).getFieldDetails().stream().filter(f->f.getName().equals("legacyReferenceId")).findAny().get().getName());
        assertEquals(cacheData.get(1).getAdditionalDetails().get(0).getValue(), referenceNodes.get(1).getFieldDetails().stream().filter(f->f.getName().equals("legacyReferenceId")).findAny().get().getValue());
    }

    @Test
    void testMapCacheResponseForSingleReferenceData_NotHavingAdditionalDetails() throws JsonProcessingException {
        JSONArray obj = TestDataSetup.getSingleReferenceDataResponseInCacheFormat();
        ObjectMapper objectMapper = TestDataSetup.getMapperWithProperties();
        ReferenceDataCacheV1 referenceDataCacheV1 = TestDataSetup.getMapperWithProperties().readValue(obj.get(0).toString(), ReferenceDataCacheV1.class);
        ReferenceNode referenceNode = abstractReferenceDataService.mapCacheResponseForSingleReferenceData(obj);
        assertEquals(referenceDataCacheV1.getReferenceUuid(), referenceNode.getReferenceUuid());
        assertEquals(referenceDataCacheV1.getName(), referenceNode.getReferenceValue());
    }

    @Test
    void testBuildKeyForFetchingRefData_ifRequiredHeadersArePresent()  {
        GenericReferenceEvent event = TestDataSetup.getReferenceDataEventForTest();
        String reference_data = abstractReferenceDataService.buildKeyForFetchingRefData(event);
        assertEquals("reference:address_type:v1:all", reference_data);
    }

    @Test
    void testBuildKeyForFetchingRefData_ifEvenContextIsNotPresent()  {
        GenericReferenceEvent event = TestDataSetup.getReferenceDataEventForTest();
        event.getEventHeader().setEventContext(new HashMap<>());
        String reference_data = abstractReferenceDataService.buildKeyForFetchingRefData(event);
        assertNull(reference_data);
    }

    @Test
    void testBuildKeyForFetchingRefData_ifRequiredHeadersAreNotPresent()  {
        GenericReferenceEvent event = TestDataSetup.getReferenceDataEventForTest();
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put("referenceUuid", "");
        event.getEventHeader().setEventContext(eventContext);
        String reference_data = abstractReferenceDataService.buildKeyForFetchingRefData(event);
        assertNull(reference_data);
    }

    @Test
    void test_buildResponseForAllRefDataBasedOnRequest() throws JsonProcessingException {
        GenericReferenceEvent event = TestDataSetup.getReferenceDataEventForTest();
        ReferenceDataCacheV1 referenceDataCacheV1  = new ReferenceDataCacheV1();

        referenceDataCacheV1.setReferenceDiscriminator("address_type");
        referenceDataCacheV1.setCode("code");
        referenceDataCacheV1.setReferenceUuid(UUID.randomUUID());
        referenceDataCacheV1.setDescription("desc");
        referenceDataCacheV1.setName("test");
        referenceDataCacheV1.setEffectiveFromDate(LocalDate.now());
        referenceDataCacheV1.setEffectiveToDate(LocalDate.now());
        referenceDataCacheV1.setLastUpdatedDatetime(LocalDateTime.now());

        List<ReferenceDataCacheV1> referenceDataCacheV1List = new ArrayList<>();
        referenceDataCacheV1List.add(referenceDataCacheV1);
        Map<String, String> eventContext = new HashMap<>();
        JSONArray jsonArray = new JSONArray();
        jsonArray.put(referenceDataCacheV1List);
        eventContext.put("referenceUuid", "");
        event.getEventHeader().setEventContext(eventContext);
        List<ReferenceNode> referenceNodes = abstractReferenceDataService.buildResponseForAllRefDataBasedOnRequest(jsonArray, String.valueOf(true));
        assertNotNull(referenceNodes);
    }

    @Test
    void testGetQueryStringParametersFromRequest_ifRequiredHeadersArePresent()  {
        GenericReferenceEvent event = TestDataSetup.retriveAllReferenceDataEventForTest();
        String includeInactive = abstractReferenceDataService.getQueryStringParametersFromRequest(event);
        assertEquals("true", includeInactive);
    }

    @Test
    void testGetQueryStringParametersFromRequest_ifRequiredHeadersAreNotPresent()  {
        GenericReferenceEvent event = TestDataSetup.getReferenceDataEventForTest();
        event.getEventHeader().setEventContext(new HashMap<>());
        String includeInactive = abstractReferenceDataService.getQueryStringParametersFromRequest(event);
        assertEquals("false", includeInactive);
    }


}
