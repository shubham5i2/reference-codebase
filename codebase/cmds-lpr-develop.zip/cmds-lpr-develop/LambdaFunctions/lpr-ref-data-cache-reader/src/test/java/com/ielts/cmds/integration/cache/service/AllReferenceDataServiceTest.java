package com.ielts.cmds.integration.cache.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.common.generic_reference_ui_client.ReferenceNode;
import com.ielts.cmds.integration.TestDataSetup;
import com.ielts.cmds.integration.event.GenericReferenceEvent;
import com.ielts.cmds.integration.response.GatewayResponseEntity;
import com.ielts.cmds.lpr.common.model.ReferenceDataCacheV1;
import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import redis.clients.jedis.UnifiedJedis;
import redis.clients.jedis.json.Path2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
class AllReferenceDataServiceTest {

    @InjectMocks
    @Spy
    private AllReferenceDataService allReferenceDataService;

    @Mock
    private UnifiedJedis jedisInstance;

    @Mock
    private AbstractReferenceDataService abstractReferenceDataService;

    @Test
    void testRetrieveAllReferenceDataFromRedisCache_withValidKey() throws JsonProcessingException {
        GenericReferenceEvent allReferenceDataEventForTest = TestDataSetup.retriveAllReferenceDataEventForTest();
        List<ReferenceNode> response = TestDataSetup.getAllReferenceDataForTest();
        String expectedResponse = new ObjectMapper().writeValueAsString(response);
        doReturn(response).
                when(allReferenceDataService).retrieveAllReferenceDataFromRedisCache("reference:address_type:v1:all", "true", jedisInstance);
        // When
        GatewayResponseEntity actualGatewayResponseEntity = allReferenceDataService.process(allReferenceDataEventForTest, jedisInstance);
        // Then
        assertEquals(expectedResponse, actualGatewayResponseEntity.getBody());
        assertEquals(HttpStatus.SC_OK, actualGatewayResponseEntity.getStatusCode());
    }

    @Test
    void testRetrieveAllReferenceDataFromRedisCache_ifKeyIsNull() throws JsonProcessingException {
        GenericReferenceEvent allReferenceDataEventForTest = TestDataSetup.retriveAllReferenceDataEventForTest();
        allReferenceDataEventForTest.getEventHeader().setEventContext(new HashMap<>());
        List<ReferenceNode> response = TestDataSetup.getAllReferenceDataForTest();
        doReturn(new ArrayList<>()).
                when(allReferenceDataService).retrieveAllReferenceDataFromRedisCache(null, "false", jedisInstance);
        // When
        GatewayResponseEntity actualGatewayResponseEntity = allReferenceDataService.process(allReferenceDataEventForTest, jedisInstance);
        // Then
        assertEquals(HttpStatus.SC_NOT_FOUND, actualGatewayResponseEntity.getStatusCode());
    }

    @Test
    void whenAllReferenceDataIsRequestedAndDataNotAvailable_thenReturnResponseWithNotFound() throws JsonProcessingException {
        // Given
        GenericReferenceEvent allReferenceDataEventForTest = TestDataSetup.retriveAllReferenceDataEventForTest();
        // When
        GatewayResponseEntity actualGatewayResponseEntity = allReferenceDataService.process(allReferenceDataEventForTest, jedisInstance);
        // Then
        assertEquals(HttpStatus.SC_NOT_FOUND, actualGatewayResponseEntity.getStatusCode());
    }

    @Test
	void testRetrieveAllReferenceDataFromRedisCache_whenActiveDataIsRequested() throws JsonProcessingException {
		JSONArray referenceDataListFromCache = TestDataSetup
				.getAllReferenceDataResponse();
		List<ReferenceDataCacheV1> list = TestDataSetup.getAllReferenceDataResponseInCacheFormat();
		when(jedisInstance.jsonGet("reference:address_type:v1:all", Path2.of("$"))).thenReturn(referenceDataListFromCache);
		doReturn(TestDataSetup.getAllActiveReferenceDataResponse(list)).when(allReferenceDataService)
				.buildResponseForAllRefDataBasedOnRequest(ArgumentMatchers.any(), ArgumentMatchers.any());
		List<ReferenceNode> referenceNodeList = allReferenceDataService.retrieveAllReferenceDataFromRedisCache("reference:address_type:v1:all", "$", jedisInstance);
		assertNotNull(referenceNodeList);
		assertEquals(3, referenceDataListFromCache.length());
		assertEquals(2, referenceNodeList.stream().count());
	}

	@Test
	void testRetrieveAllReferenceDataFromRedisCache_whenAllDataIsRequested() throws JsonProcessingException {
		JSONArray referenceDataListFromCache = TestDataSetup
				.getAllReferenceDataResponse();
		List<ReferenceDataCacheV1> list = TestDataSetup.getAllReferenceDataResponseInCacheFormat();
		when(jedisInstance.jsonGet("reference:address_type:v1:all", Path2.of("$"))).thenReturn(referenceDataListFromCache);
		doReturn(TestDataSetup.getAllReferenceDataResponse(list)).when(allReferenceDataService)
				.buildResponseForAllRefDataBasedOnRequest(ArgumentMatchers.any(), ArgumentMatchers.any());
		List<ReferenceNode> referenceNodeList = allReferenceDataService.retrieveAllReferenceDataFromRedisCache("reference:address_type:v1:all", "true", jedisInstance);
		assertNotNull(referenceNodeList);
		assertEquals(3, referenceDataListFromCache.length());
		assertEquals(3, referenceNodeList.stream().count());
	}

    @Test
    void whenExceptionIsEncountered_ifAllReferenceDataIsRequested_verifyResponse() throws JsonProcessingException {
        GenericReferenceEvent allReferenceDataEventForTest = TestDataSetup.retriveAllReferenceDataEventForTest();
        doThrow(JsonProcessingException.class).when(allReferenceDataService).mapAllReferenceDataResponseBody(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any());
        // When
        GatewayResponseEntity actualGatewayResponseEntity = allReferenceDataService.process(allReferenceDataEventForTest, jedisInstance);
        // Then
        assertEquals(HttpStatus.SC_INTERNAL_SERVER_ERROR, actualGatewayResponseEntity.getStatusCode());
    }

    @Test
	void testIfKeyNotPresent_verifyCacheMiss() throws JsonProcessingException {
		when(jedisInstance.jsonGet("reference:address_type:v1:all", Path2.of("$"))).thenReturn(null);
		List<ReferenceNode> referenceNodeList = allReferenceDataService.retrieveAllReferenceDataFromRedisCache("reference:address_type:v1:all", "true", jedisInstance);
		assertTrue(referenceNodeList.isEmpty());
	}

	@Test
	void testIfKeyIsNullInAllReferenceDataRequest_verifyEmptyResponse() throws JsonProcessingException {
		List<ReferenceNode> referenceNodeList = allReferenceDataService.retrieveAllReferenceDataFromRedisCache(null, "true", jedisInstance);
		assertTrue(referenceNodeList.isEmpty());
	}
}
