package com.ielts.cmds.integration;


import com.amazonaws.services.sns.AmazonSNS;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.integration.factory.ReceiverServiceFactory;
import com.ielts.cmds.integration.service.LocationUploadRequestedService;
import com.ielts.cmds.serialization.lambda.config.SNSClientConfig;
import com.ielts.cmds.serialization.lambda.receiver.service.AbstractServiceFactory;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.org.webcompere.systemstubs.environment.EnvironmentVariables;
import uk.org.webcompere.systemstubs.jupiter.SystemStub;
import uk.org.webcompere.systemstubs.jupiter.SystemStubsExtension;

import java.util.HashMap;
import java.util.Map;

import static com.ielts.cmds.integration.constants.LPRReceiverConstants.LOCATION_UPLOAD_REQUESTED_EVENT_NAME;
import static com.ielts.cmds.integration.constants.LPRReceiverConstants.LOCATION_UPLOAD_REQUESTED_OUTGOING_EVENT_NAME;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.spy;

@ExtendWith(MockitoExtension.class)
@ExtendWith(SystemStubsExtension.class)
class LPRExtReceiverTest {

    private LPRExtReceiver lprExtReceiver;

    @Mock
    private AmazonSNS snsClient;

    private static MockedStatic<SNSClientConfig> snsClientConfig;

    @Mock
    private ObjectMapper mapper;

    private AbstractServiceFactory serviceFactory;


    @SystemStub
    private EnvironmentVariables env;

    @BeforeAll
    static void init() {
        snsClientConfig = Mockito.mockStatic(SNSClientConfig.class);
    }

    @BeforeEach
    void setup() {
        snsClientConfig.when(SNSClientConfig::getSNSClient).thenReturn(snsClient);
        LPRExtReceiver receiverLambdaObject = new LPRExtReceiver() ;
        lprExtReceiver = spy(receiverLambdaObject);
        final Map<String, IReceiverService> initServices = new HashMap<>();
        initServices.put(LOCATION_UPLOAD_REQUESTED_EVENT_NAME, new LocationUploadRequestedService());
        serviceFactory = spy(new ReceiverServiceFactory(initServices));
    }

    @AfterAll
    static void clear() {
        snsClientConfig.close();
    }

    @Test
    void WhenGetTopicArn_ExpectUITopic() {
        env.set("lpr_ext_topic_in_arn", "lpr_ext_topic_in");
        assertEquals( "lpr_ext_topic_in", lprExtReceiver.getTopicArn());
    }

    @Test
    void WhenUserSearchRequest_ExpectCorrectServiceCalled(){
        IReceiverService service = serviceFactory.getService(LOCATION_UPLOAD_REQUESTED_EVENT_NAME);
        assertEquals(LocationUploadRequestedService.class,service.getClass());
        assertEquals(LOCATION_UPLOAD_REQUESTED_OUTGOING_EVENT_NAME,service.getOutgoingEventName());
    }
}
