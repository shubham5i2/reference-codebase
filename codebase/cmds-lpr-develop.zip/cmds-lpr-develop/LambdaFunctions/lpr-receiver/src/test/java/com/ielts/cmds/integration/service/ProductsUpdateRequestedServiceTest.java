package com.ielts.cmds.integration.service;

import com.ielts.cmds.api.common.ui_client.ProductUpdateNodeV1;
import com.ielts.cmds.api.lprui030productupdaterequested.ProductUpdateNode;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ReceiverLambdaHeaderContext;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static com.ielts.cmds.integration.constants.LPRReceiverConstants.PRODUCTS_UPDATE_REQUESTED_OUTGOING_EVENT_NAME;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class ProductsUpdateRequestedServiceTest {

    @InjectMocks ProductsUpdateRequestedService productsUpdateRequestedService;

    @Test
    void when_callingGetOutgoingEventName_thenReturnEvent() {

        String actualEventName = productsUpdateRequestedService.getOutgoingEventName();
        assertEquals(PRODUCTS_UPDATE_REQUESTED_OUTGOING_EVENT_NAME, actualEventName);
    }
    @Test
    void whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEvent(){
        final ReceiverLambdaHeaderContext headerContext = new ReceiverLambdaHeaderContext();
        Map<String , String> eventContext = new HashMap<>();
        eventContext.put("productUuid", "05ea51d0-4617-4b3f-8b01-3e4331efdbf1");
        headerContext.setEventContext(eventContext);
        ThreadLocalHeaderContext.setContext(headerContext);
        ProductUpdateNodeV1 incomingEvent = UpdateProductDataSetUp.getProductUpdateNodeV1();
        ProductUpdateNode outGoingEvent = productsUpdateRequestedService.process(incomingEvent);
        assertEquals(incomingEvent.getProductName(), outGoingEvent.getProductName());
        assertEquals(UUID.fromString("05ea51d0-4617-4b3f-8b01-3e4331efdbf1") , outGoingEvent.getProductUuid());
    }

}
