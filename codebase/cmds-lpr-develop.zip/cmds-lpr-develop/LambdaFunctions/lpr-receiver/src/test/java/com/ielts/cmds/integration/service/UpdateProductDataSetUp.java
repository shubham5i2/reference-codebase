package com.ielts.cmds.integration.service;

import com.ielts.cmds.api.common.ui_client.ProductUpdateNodeV1;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

class UpdateProductDataSetUp {

    public static ProductUpdateNodeV1 getProductUpdateNodeV1(){
        ProductUpdateNodeV1 product = new ProductUpdateNodeV1();
        product.setProductName("Online Test");
        product.setProductStatus(ProductUpdateNodeV1.ProductStatusEnum.valueOf("PUBLISHED"));
        product.setParentProductUuid(UUID.fromString("c8437ba8-cb0e-46ee-b960-9577dce30ef8"));
        product.setProductApprovalRequired(Boolean.TRUE);
        product.setBookable(Boolean.TRUE);
        product.setAvailableFromDate(LocalDate.now());
        product.setAvailableToDate(LocalDate.of(2099, 12, 31));
        product.setLegacyProductId("D901");
        product.setBookable(Boolean.TRUE);
        product.setFormatType("CD");
        product.setComponent("S");
        product.setDuration(BigDecimal.valueOf(20));
        product.setModuleTypeUuid(UUID.fromString("0ae29abe-5862-4c48-92e4-00d7eba376a2"));
        product.setProductCharacteristics("{\"characteristics\": [\"IOC\"]}");
        return product;
    }


}
