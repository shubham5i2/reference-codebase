package com.ielts.cmds.integration;

import com.amazonaws.services.sns.AmazonSNS;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.integration.factory.ReceiverServiceFactory;
import com.ielts.cmds.integration.service.*;
import com.ielts.cmds.serialization.lambda.config.SNSClientConfig;
import com.ielts.cmds.serialization.lambda.receiver.service.AbstractServiceFactory;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.org.webcompere.systemstubs.environment.EnvironmentVariables;
import uk.org.webcompere.systemstubs.jupiter.SystemStub;
import uk.org.webcompere.systemstubs.jupiter.SystemStubsExtension;

import java.util.HashMap;
import java.util.Map;

import static com.ielts.cmds.integration.constants.LPRReceiverConstants.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.spy;

@ExtendWith(MockitoExtension.class)
@ExtendWith(SystemStubsExtension.class)
class LPRUIReceiverTest {

    private LPRUIReceiver lpruiReceiver;

    private AbstractServiceFactory serviceFactory;

    @Mock
    private ObjectMapper mapper;

    @Mock private AmazonSNS snsClient;

    private static MockedStatic<SNSClientConfig> snsClientConfig;

    @SystemStub
    private EnvironmentVariables env;

    @BeforeAll
    static void init() {
        snsClientConfig = Mockito.mockStatic(SNSClientConfig.class);
    }


    @BeforeEach
    void setup() {
        env.set("AWS_REGION", "eu-west-2");
        snsClientConfig.when(SNSClientConfig::getSNSClient).thenReturn(snsClient);
        LPRUIReceiver receiver = new LPRUIReceiver();
        lpruiReceiver = spy(receiver);
        final Map<String, IReceiverService> initServices = new HashMap<>();
        initServices.put(NOTE_TYPES_REQUESTED_EVENT_NAME, new NoteTypesRequestedService());
        initServices.put(PARTNERS_REQUESTED_EVENT_NAME, new PartnersRequestedService());
        initServices.put(ORGANISATION_TYPES_REQUESTED_EVENT_NAME, new OrganisationTypesRequestedService());
        initServices.put(MODULE_TYPES_REQUESTED_EVENT_NAME, new ModuleTypesRequestedService());
        initServices.put(CONTACT_TYPES_REQUESTED_EVENT_NAME, new ContactTypesRequestedService());
        initServices.put(ADDRESS_TYPES_REQUESTED_EVENT_NAME, new AddressTypesRequestedService());
        initServices.put(SECTOR_TYPES_REQUESTED_EVENT_NAME, new SectorTypesRequestedService());
        initServices.put(COUNTRIES_REQUESTED_EVENT_NAME, new CountriesRequestedService());
        initServices.put(RESULT_STATUS_REQUESTED_EVENT_NAME, new ResultsStatusRequestedService());
        initServices.put(PRODUCTS_REQUESTED_EVENT_NAME, new ProductsRequestedService());
        initServices.put(COUNTRY_TERRITORIES_REQUESTED_EVENT_NAME, new CountryTerritoriesRequestedService(this.mapper));
        initServices.put(LOCATION_SEARCH_REQUESTED_EVENT_NAME, new LocationSearchRequestedService());
        initServices.put(LOCATION_CREATE_REQUESTED_EVENT_NAME, new LocationCreateRequestedService());
        initServices.put(LOCATION_UPDATE_REQUESTED_EVENT_NAME, new LocationUpdateRequestedService());
        initServices.put(LOCATIONS_REQUESTED_EVENT_NAME, new LocationsRequestedService(this.mapper));
        initServices.put(PRODUCTS_UPDATE_REQUESTED_EVENT_NAME, new ProductsUpdateRequestedService());

        serviceFactory = spy(new ReceiverServiceFactory(initServices));
    }

    @Test
    void WhenGetTopicArn_ExpectUITopic() {
        env.set(LPR_UI_TOPIC_IN_ARN, LPR_UI_TOPIC_IN_ARN);
        assertEquals( LPR_UI_TOPIC_IN_ARN, lpruiReceiver.getTopicArn());
    }

    @Test
    void WhenNoteTypesRequested_thenCallNoteTypesRequestedService(){
        IReceiverService<Object, Object> service = serviceFactory.getService(NOTE_TYPES_REQUESTED_EVENT_NAME);
        assertEquals(NoteTypesRequestedService.class,service.getClass());
    }

    @Test
    void WhenPartnersRequested_thenCallPartnersRequestedService(){
        IReceiverService<Object, Object> service = serviceFactory.getService(PARTNERS_REQUESTED_EVENT_NAME);
        assertEquals(PartnersRequestedService.class,service.getClass());
    }

    @Test
    void WhenOrganisationTypesRequested_thenCallOrganisationTypesRequestedService(){
        IReceiverService<Object, Object> service = serviceFactory.getService(ORGANISATION_TYPES_REQUESTED_EVENT_NAME);
        assertEquals(OrganisationTypesRequestedService.class,service.getClass());
    }

    @Test
    void WhenModuleTypesRequested_thenCallModuleTypesRequestedService(){
        IReceiverService<Object, Object> service = serviceFactory.getService(MODULE_TYPES_REQUESTED_EVENT_NAME);
        assertEquals(ModuleTypesRequestedService.class,service.getClass());
    }

    @Test
    void WhenContactTypesRequested_thenCallContactTypesRequestedService(){
        IReceiverService<Object, Object> service = serviceFactory.getService(CONTACT_TYPES_REQUESTED_EVENT_NAME);
        assertEquals(ContactTypesRequestedService.class,service.getClass());
    }

    @Test
    void WhenAddressTypesRequested_thenCallContactTypesRequestedService(){
        IReceiverService<Object, Object> service = serviceFactory.getService(ADDRESS_TYPES_REQUESTED_EVENT_NAME);
        assertEquals(AddressTypesRequestedService.class,service.getClass());
    }

    @Test
    void WhenSectorTypesRequested_thenCallSectorTypesRequestedService(){
        IReceiverService<Object, Object> service = serviceFactory.getService(SECTOR_TYPES_REQUESTED_EVENT_NAME);
        assertEquals(SectorTypesRequestedService.class,service.getClass());
    }

    @Test
    void WhenCountriesRequested_thenCallCountriesRequestedService(){
        IReceiverService<Object, Object> service = serviceFactory.getService(COUNTRIES_REQUESTED_EVENT_NAME);
        assertEquals(CountriesRequestedService.class,service.getClass());
    }

    @Test
    void WhenResultsStatusRequested_thenCallResultsStatusRequestedService(){
        IReceiverService<Object, Object> service = serviceFactory.getService(RESULT_STATUS_REQUESTED_EVENT_NAME);
        assertEquals(ResultsStatusRequestedService.class,service.getClass());
    }

    @Test
    void WhenProductsRequested_thenCallProductsRequestedService(){
        IReceiverService<Object, Object> service = serviceFactory.getService(PRODUCTS_REQUESTED_EVENT_NAME);
        assertEquals(ProductsRequestedService.class,service.getClass());
    }

    @Test
    void WhenCountryTerritoriesRequested_thenCallCountryTerritoriesRequestedService(){
        IReceiverService<Object, Object> service = serviceFactory.getService(COUNTRY_TERRITORIES_REQUESTED_EVENT_NAME);
        assertEquals(CountryTerritoriesRequestedService.class,service.getClass());
    }

    @Test
    void WhenLocationSearchRequested_thenCallCountryLocationSearchRequestedService(){
        IReceiverService<Object, Object> service = serviceFactory.getService(LOCATION_SEARCH_REQUESTED_EVENT_NAME);
        assertEquals(LocationSearchRequestedService.class,service.getClass());
    }

    @Test
    void WhenLocationCreateRequestedService_thenCallLocationSearchRequestedService(){
        IReceiverService<Object, Object> service = serviceFactory.getService(LOCATION_CREATE_REQUESTED_EVENT_NAME);
        assertEquals(LocationCreateRequestedService.class,service.getClass());
    }

    @Test
    void WhenLocationUpdateRequestedService_thenCallLocationUpdateRequestedService(){
        IReceiverService<Object, Object> service = serviceFactory.getService(LOCATION_UPDATE_REQUESTED_EVENT_NAME);
        assertEquals(LocationUpdateRequestedService.class,service.getClass());
    }

    @Test
    void WhenLocationsRequested_thenCallLocationsRequestedService(){
        IReceiverService<Object, Object> service = serviceFactory.getService(LOCATIONS_REQUESTED_EVENT_NAME);
        assertEquals(LocationsRequestedService.class,service.getClass());
    }

    @Test
    void WhenProductUpdateRequestedService_thenCallProductUpdateRequestedService(){
        IReceiverService<Object, Object> service = serviceFactory.getService(PRODUCTS_UPDATE_REQUESTED_EVENT_NAME);
        assertEquals(ProductsUpdateRequestedService.class, service.getClass());
    }
}
