package com.ielts.cmds.integration.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.ielts.cmds.integration.constants.LPRReceiverConstants.ADDRESS_TYPES_REQUESTED_OUTGOING_EVENT_NAME;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class AddressTypesRequestedServiceTest {

    @InjectMocks
    private AddressTypesRequestedService addressTypesRequestedService;

    @Test
    void when_callingGetOutgoingEventName_thenReturnEvent() {
        String actualEventName = addressTypesRequestedService.getOutgoingEventName();
        assertEquals(ADDRESS_TYPES_REQUESTED_OUTGOING_EVENT_NAME, actualEventName);
    }
}
