package com.ielts.cmds.integration.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import static com.ielts.cmds.integration.constants.LPRReceiverConstants.RESULT_STATUS_REQUESTED_OUTGOING_EVENT_NAME;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class ResultsStatusRequestedServiceTest {

    @InjectMocks
    private ResultsStatusRequestedService resultsStatusRequestedService;

    @Test
    void when_callingGetOutgoingEventName_thenReturnEvent() {
        String actualEventName = resultsStatusRequestedService.getOutgoingEventName();
        assertEquals(RESULT_STATUS_REQUESTED_OUTGOING_EVENT_NAME, actualEventName);
    }
}
