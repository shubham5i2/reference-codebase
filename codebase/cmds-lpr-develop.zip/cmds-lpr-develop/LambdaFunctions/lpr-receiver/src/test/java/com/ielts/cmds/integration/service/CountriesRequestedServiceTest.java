package com.ielts.cmds.integration.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.ielts.cmds.integration.constants.LPRReceiverConstants.COUNTRIES_REQUESTED_OUTGOING_EVENT_NAME;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class CountriesRequestedServiceTest {

    @InjectMocks
    private CountriesRequestedService countriesRequestedService;

    @Test
    void when_callingGetOutgoingEventName_thenReturnEvent() {
        String actualEventName = countriesRequestedService.getOutgoingEventName();
        assertEquals(COUNTRIES_REQUESTED_OUTGOING_EVENT_NAME, actualEventName);
    }
}
