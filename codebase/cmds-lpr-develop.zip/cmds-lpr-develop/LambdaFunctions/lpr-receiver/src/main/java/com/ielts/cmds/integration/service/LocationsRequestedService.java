package com.ielts.cmds.integration.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.lprui470locationsrequested.LocationDetailsParams;
import com.ielts.cmds.serialization.lambda.receiver.service.RequestWithParamsReceiverService;

import static com.ielts.cmds.integration.constants.LPRReceiverConstants.LOCATIONS_REQUESTED_OUTGOING_EVENT_NAME;


public class LocationsRequestedService extends RequestWithParamsReceiverService<LocationDetailsParams> {


    public LocationsRequestedService(ObjectMapper mapper) {
        super(mapper);
    }

    @Override
    public String getOutgoingEventName() {
        return LOCATIONS_REQUESTED_OUTGOING_EVENT_NAME;
    }
}
