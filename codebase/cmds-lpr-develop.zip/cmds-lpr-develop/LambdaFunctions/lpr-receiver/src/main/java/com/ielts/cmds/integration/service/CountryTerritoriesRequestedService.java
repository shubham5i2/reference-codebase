package com.ielts.cmds.integration.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.lprui301countryterritoriesrequested.CountryTerritoriesParams;
import com.ielts.cmds.serialization.lambda.receiver.service.RequestWithParamsReceiverService;

import static com.ielts.cmds.integration.constants.LPRReceiverConstants.COUNTRY_TERRITORIES_REQUESTED_OUTGOING_EVENT_NAME;


public class CountryTerritoriesRequestedService extends RequestWithParamsReceiverService<CountryTerritoriesParams> {


    public CountryTerritoriesRequestedService(ObjectMapper mapper) {
        super(mapper);
    }

    @Override
    public String getOutgoingEventName() {
        return COUNTRY_TERRITORIES_REQUESTED_OUTGOING_EVENT_NAME;
    }
}
