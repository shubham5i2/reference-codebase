package com.ielts.cmds.integration.service;

import com.ielts.cmds.serialization.lambda.receiver.service.RequestWithoutBodyReceiverService;

import static com.ielts.cmds.integration.constants.LPRReceiverConstants.MODULE_TYPES_REQUESTED_OUTGOING_EVENT_NAME;

public class ModuleTypesRequestedService extends RequestWithoutBodyReceiverService {

    @Override
    public String getOutgoingEventName() {
        return MODULE_TYPES_REQUESTED_OUTGOING_EVENT_NAME;
    }
}
