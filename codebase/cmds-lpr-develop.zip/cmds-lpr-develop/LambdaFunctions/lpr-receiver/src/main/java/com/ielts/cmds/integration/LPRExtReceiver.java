package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.constants.LPRReceiverConstants.LOCATION_UPLOAD_REQUESTED_EVENT_NAME;

import java.util.HashMap;
import java.util.Map;

import com.ielts.cmds.common.utils.CMDSCommonUtils;
import com.ielts.cmds.integration.constants.LPRReceiverConstants;
import com.ielts.cmds.integration.factory.ReceiverServiceFactory;
import com.ielts.cmds.integration.service.LocationUploadRequestedService;
import com.ielts.cmds.serialization.lambda.AbstractReceiverLambda;
import com.ielts.cmds.serialization.lambda.mapper.IObjectMapper;
import com.ielts.cmds.serialization.lambda.receiver.service.AbstractServiceFactory;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

public class LPRExtReceiver extends AbstractReceiverLambda implements IObjectMapper {


	@Override
	public AbstractServiceFactory getServiceFactory() {

		@SuppressWarnings("rawtypes")
		final Map<String, IReceiverService> initServices = new HashMap<>();
		initServices.put(LOCATION_UPLOAD_REQUESTED_EVENT_NAME, new LocationUploadRequestedService());
		return new ReceiverServiceFactory(initServices);
	}

	@Override
	public String getTopicArn() {
		return System.getenv(LPRReceiverConstants.LPR_EXT_TOPIC_IN_ARN);
	}

	@Override
	protected String getPartnerCode() {
		return CMDSCommonUtils.getDataFromClaims(
				ThreadLocalHeaderContext.getContext().getXaccessToken(),
				LPRReceiverConstants.PARTNER_CODE);
	}
}
