package com.ielts.cmds.integration.service;

import com.ielts.cmds.api.common.ui_client.ProductUpdateNodeV1;
import com.ielts.cmds.api.lprui030productupdaterequested.ProductUpdateNode;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import java.util.Map;
import java.util.UUID;

import static com.ielts.cmds.integration.constants.LPRReceiverConstants.PRODUCTS_UPDATE_REQUESTED_OUTGOING_EVENT_NAME;
public class ProductsUpdateRequestedService implements IReceiverService<ProductUpdateNodeV1, ProductUpdateNode> {
    @Override
    public ProductUpdateNode process(ProductUpdateNodeV1 eventBody) {
        final Map<String, String> eventContext =
                ThreadLocalHeaderContext.getContext().getEventContext();
        String productUuid = eventContext.get("productUuid");
        ProductUpdateNode productUpdateNode = new ProductUpdateNode();
        productUpdateNode.setProductName(eventBody.getProductName());
        productUpdateNode.setProductUuid(UUID.fromString(productUuid));
        productUpdateNode.setParentProductUuid(eventBody.getParentProductUuid());
        productUpdateNode.setProductApprovalRequired(eventBody.getProductApprovalRequired());
        productUpdateNode.setAvailableFromDate(eventBody.getAvailableFromDate());
        productUpdateNode.setAvailableToDate(eventBody.getAvailableToDate());
        productUpdateNode.setLegacyProductId(eventBody.getLegacyProductId());
        productUpdateNode.setBookable(eventBody.getBookable());
        productUpdateNode.setFormatType(eventBody.getFormatType());
        productUpdateNode.setComponent(eventBody.getComponent());
        productUpdateNode.setProductStatus(ProductUpdateNode.ProductStatusEnum.valueOf(eventBody.getProductStatus().toString()));
        productUpdateNode.setDuration(eventBody.getDuration());
        productUpdateNode.setModuleTypeUuid(eventBody.getModuleTypeUuid());
        productUpdateNode.setProductCharacteristics(eventBody.getProductCharacteristics());
        return productUpdateNode;
    }

    @Override
    public String getOutgoingEventName() {
        return PRODUCTS_UPDATE_REQUESTED_OUTGOING_EVENT_NAME;
    }
}
