package com.ielts.cmds.integration.service;

import com.ielts.cmds.serialization.lambda.receiver.service.RequestWithoutBodyReceiverService;

import static com.ielts.cmds.integration.constants.LPRReceiverConstants.COUNTRIES_REQUESTED_OUTGOING_EVENT_NAME;


public class CountriesRequestedService extends RequestWithoutBodyReceiverService {

    @Override
    public String getOutgoingEventName() {
        return COUNTRIES_REQUESTED_OUTGOING_EVENT_NAME;
    }
}
