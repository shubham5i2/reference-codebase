package com.ielts.cmds.integration.service;

import com.ielts.cmds.serialization.lambda.receiver.service.RequestWithoutBodyReceiverService;

import static com.ielts.cmds.integration.constants.LPRReceiverConstants.SECTOR_TYPES_REQUESTED_OUTGOING_EVENT_NAME;


public class SectorTypesRequestedService extends RequestWithoutBodyReceiverService {

    @Override
    public String getOutgoingEventName() {
        return SECTOR_TYPES_REQUESTED_OUTGOING_EVENT_NAME;
    }
}
