package com.ielts.cmds.integration.factory;

import java.util.Map;

import com.ielts.cmds.serialization.lambda.receiver.service.AbstractServiceFactory;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;

public class ReceiverServiceFactory extends AbstractServiceFactory {

    @SuppressWarnings("rawtypes")
    public ReceiverServiceFactory(final Map<String, IReceiverService> initServices) {
        super(initServices);
    }
}
