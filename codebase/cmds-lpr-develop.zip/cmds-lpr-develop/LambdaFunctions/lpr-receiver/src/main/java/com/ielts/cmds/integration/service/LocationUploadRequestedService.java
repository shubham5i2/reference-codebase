package com.ielts.cmds.integration.service;

import com.ielts.cmds.api.common.external_client.LocationNode;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;

import static com.ielts.cmds.integration.constants.LPRReceiverConstants.LOCATION_UPLOAD_REQUESTED_OUTGOING_EVENT_NAME;

public class LocationUploadRequestedService implements IReceiverService<LocationNode, LocationNode> {
    @Override
    public LocationNode process(LocationNode eventBody) {
        return eventBody;
    }

    @Override
    public String getOutgoingEventName() {
        return LOCATION_UPLOAD_REQUESTED_OUTGOING_EVENT_NAME;
    }
}
