package com.ielts.cmds.integration.constants;

public class LPRReceiverConstants {

	private LPRReceiverConstants() {}
	
	public static final String LPR_UI_RECEIVER_LAMBDA = "LPR-UI-RECEIVER-LAMBDA";
	public static final String LPR_EXT_RECEIVER_LAMBDA = "LPR-EXT-RECEIVER-LAMBDA";
	public static final String LPR = "LPR";
	public static final String LPR_UI_TOPIC_IN_ARN = "lpr_ui_topic_in_arn";
	public static final String LPR_EXT_TOPIC_IN_ARN = "lpr_ext_topic_in_arn";

//	Incoming Events

	public static final String NOTE_TYPES_REQUESTED_EVENT_NAME = "GET/v1/notetypes";
	public static final String PARTNERS_REQUESTED_EVENT_NAME = "GET/v1/partners";
	public static final String ORGANISATION_TYPES_REQUESTED_EVENT_NAME = "GET/v1/organisationtypes";
	public static final String MODULE_TYPES_REQUESTED_EVENT_NAME = "GET/v1/moduletypes";
	public static final String CONTACT_TYPES_REQUESTED_EVENT_NAME = "GET/v1/contacttypes";
	public static final String ADDRESS_TYPES_REQUESTED_EVENT_NAME = "GET/v1/addresstypes";
	public static final String SECTOR_TYPES_REQUESTED_EVENT_NAME = "GET/v1/sectortypes";
	public static final String COUNTRIES_REQUESTED_EVENT_NAME = "GET/v1/countries";
	public static final String RESULT_STATUS_REQUESTED_EVENT_NAME = "GET/v1/resultstatus";
	public static final String PRODUCTS_REQUESTED_EVENT_NAME = "GET/v1/products";
	public static final String COUNTRY_TERRITORIES_REQUESTED_EVENT_NAME = "GET/v1/countries/{countryCode}/territories";
	public static final String LOCATION_SEARCH_REQUESTED_EVENT_NAME = "POST/v1/locations/search";
	public static final String LOCATION_UPDATE_REQUESTED_EVENT_NAME = "PUT/v1/locations/{locationUuid}";
	public static final String LOCATION_CREATE_REQUESTED_EVENT_NAME = "POST/v1/locations";
	public static final String LOCATIONS_REQUESTED_EVENT_NAME = "GET/v1/locations/{locationUuid}";
	public static final String LOCATION_UPLOAD_REQUESTED_EVENT_NAME = "POST/v1/uploadlocation";
	public static final String PRODUCTS_UPDATE_REQUESTED_EVENT_NAME = "PUT/v1/products/{productUuid}";


//	Outgoing Events

	public static final String NOTE_TYPES_REQUESTED_OUTGOING_EVENT_NAME = "NoteTypesRequested";
	public static final String PARTNERS_REQUESTED_OUTGOING_EVENT_NAME = "PartnersRequested";
	public static final String ORGANISATION_TYPES_REQUESTED_OUTGOING_EVENT_NAME = "OrganisationTypesRequested";
	public static final String MODULE_TYPES_REQUESTED_OUTGOING_EVENT_NAME = "ModuleTypesRequested";
	public static final String CONTACT_TYPES_REQUESTED_OUTGOING_EVENT_NAME = "ContactTypesRequested";
	public static final String ADDRESS_TYPES_REQUESTED_OUTGOING_EVENT_NAME = "AddressTypesRequested";
	public static final String SECTOR_TYPES_REQUESTED_OUTGOING_EVENT_NAME = "SectorTypesRequested";
	public static final String COUNTRIES_REQUESTED_OUTGOING_EVENT_NAME = "CountriesRequested";
	public static final String RESULT_STATUS_REQUESTED_OUTGOING_EVENT_NAME = "ResultStatusRequested";
	public static final String PARTNER_CODE = "partnerCode";
	public static final String PRODUCTS_REQUESTED_OUTGOING_EVENT_NAME = "ProductsRequested";
	public static final String COUNTRY_TERRITORIES_REQUESTED_OUTGOING_EVENT_NAME = "CountryTerritoriesRequested";
	public static final String LOCATION_SEARCH_REQUESTED_OUTGOING_EVENT_NAME = "LocationSearchRequested";

	public static final String LOCATION_UPDATE_REQUESTED_OUTGOING_EVENT_NAME = "LocationUpdateRequested";
	public static final String LOCATION_CREATE_REQUESTED_OUTGOING_EVENT_NAME = "LocationCreateRequested";
	public static final String LOCATIONS_REQUESTED_OUTGOING_EVENT_NAME = "LocationsRequested";
	public static final String LOCATION_UPLOAD_REQUESTED_OUTGOING_EVENT_NAME = "LocationUploadRequested";
	public static final String PRODUCTS_UPDATE_REQUESTED_OUTGOING_EVENT_NAME = "ProductsUpdateRequested";

}
