package com.ielts.cmds.integration.service;

import com.ielts.cmds.serialization.lambda.receiver.service.RequestWithoutBodyReceiverService;

import static com.ielts.cmds.integration.constants.LPRReceiverConstants.PRODUCTS_REQUESTED_OUTGOING_EVENT_NAME;


public class ProductsRequestedService extends RequestWithoutBodyReceiverService {

    @Override
    public String getOutgoingEventName() {
        return PRODUCTS_REQUESTED_OUTGOING_EVENT_NAME;
    }
}
