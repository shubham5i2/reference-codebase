package com.ielts.cmds.integration.service;

import com.ielts.cmds.api.common.ui_client.LocationSearchV1;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;

import static com.ielts.cmds.integration.constants.LPRReceiverConstants.LOCATION_SEARCH_REQUESTED_OUTGOING_EVENT_NAME;

public class LocationSearchRequestedService implements IReceiverService<LocationSearchV1, LocationSearchV1> {

    @Override
    public LocationSearchV1 process(LocationSearchV1 eventBody) {
        return eventBody;
    }

    @Override
    public String getOutgoingEventName() {
        return LOCATION_SEARCH_REQUESTED_OUTGOING_EVENT_NAME;
    }
}
