package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.constants.LPRReceiverConstants.ADDRESS_TYPES_REQUESTED_EVENT_NAME;
import static com.ielts.cmds.integration.constants.LPRReceiverConstants.CONTACT_TYPES_REQUESTED_EVENT_NAME;
import static com.ielts.cmds.integration.constants.LPRReceiverConstants.COUNTRIES_REQUESTED_EVENT_NAME;
import static com.ielts.cmds.integration.constants.LPRReceiverConstants.COUNTRY_TERRITORIES_REQUESTED_EVENT_NAME;
import static com.ielts.cmds.integration.constants.LPRReceiverConstants.LOCATIONS_REQUESTED_EVENT_NAME;
import static com.ielts.cmds.integration.constants.LPRReceiverConstants.LOCATION_CREATE_REQUESTED_EVENT_NAME;
import static com.ielts.cmds.integration.constants.LPRReceiverConstants.LOCATION_SEARCH_REQUESTED_EVENT_NAME;
import static com.ielts.cmds.integration.constants.LPRReceiverConstants.LOCATION_UPDATE_REQUESTED_EVENT_NAME;
import static com.ielts.cmds.integration.constants.LPRReceiverConstants.LPR_UI_TOPIC_IN_ARN;
import static com.ielts.cmds.integration.constants.LPRReceiverConstants.MODULE_TYPES_REQUESTED_EVENT_NAME;
import static com.ielts.cmds.integration.constants.LPRReceiverConstants.NOTE_TYPES_REQUESTED_EVENT_NAME;
import static com.ielts.cmds.integration.constants.LPRReceiverConstants.ORGANISATION_TYPES_REQUESTED_EVENT_NAME;
import static com.ielts.cmds.integration.constants.LPRReceiverConstants.PARTNERS_REQUESTED_EVENT_NAME;
import static com.ielts.cmds.integration.constants.LPRReceiverConstants.PRODUCTS_REQUESTED_EVENT_NAME;
import static com.ielts.cmds.integration.constants.LPRReceiverConstants.PRODUCTS_UPDATE_REQUESTED_EVENT_NAME;
import static com.ielts.cmds.integration.constants.LPRReceiverConstants.RESULT_STATUS_REQUESTED_EVENT_NAME;
import static com.ielts.cmds.integration.constants.LPRReceiverConstants.SECTOR_TYPES_REQUESTED_EVENT_NAME;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.integration.factory.ReceiverServiceFactory;
import com.ielts.cmds.integration.service.AddressTypesRequestedService;
import com.ielts.cmds.integration.service.ContactTypesRequestedService;
import com.ielts.cmds.integration.service.CountriesRequestedService;
import com.ielts.cmds.integration.service.CountryTerritoriesRequestedService;
import com.ielts.cmds.integration.service.LocationCreateRequestedService;
import com.ielts.cmds.integration.service.LocationSearchRequestedService;
import com.ielts.cmds.integration.service.LocationUpdateRequestedService;
import com.ielts.cmds.integration.service.LocationsRequestedService;
import com.ielts.cmds.integration.service.ModuleTypesRequestedService;
import com.ielts.cmds.integration.service.NoteTypesRequestedService;
import com.ielts.cmds.integration.service.OrganisationTypesRequestedService;
import com.ielts.cmds.integration.service.PartnersRequestedService;
import com.ielts.cmds.integration.service.ProductsRequestedService;
import com.ielts.cmds.integration.service.ProductsUpdateRequestedService;
import com.ielts.cmds.integration.service.ResultsStatusRequestedService;
import com.ielts.cmds.integration.service.SectorTypesRequestedService;
import com.ielts.cmds.serialization.lambda.AbstractReceiverLambda;
import com.ielts.cmds.serialization.lambda.mapper.IObjectMapper;
import com.ielts.cmds.serialization.lambda.receiver.service.AbstractServiceFactory;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;

public class LPRUIReceiver extends AbstractReceiverLambda implements IObjectMapper {


	@Override
	public AbstractServiceFactory getServiceFactory() {
		@SuppressWarnings("rawtypes")
		final Map<String, IReceiverService> initServices = new HashMap<>();
		ObjectMapper mapper =getMapperWithProperties();
		initServices.put(NOTE_TYPES_REQUESTED_EVENT_NAME, new NoteTypesRequestedService());
		initServices.put(PARTNERS_REQUESTED_EVENT_NAME, new PartnersRequestedService());
		initServices.put(ORGANISATION_TYPES_REQUESTED_EVENT_NAME, new OrganisationTypesRequestedService());
		initServices.put(MODULE_TYPES_REQUESTED_EVENT_NAME, new ModuleTypesRequestedService());
		initServices.put(CONTACT_TYPES_REQUESTED_EVENT_NAME, new ContactTypesRequestedService());
		initServices.put(ADDRESS_TYPES_REQUESTED_EVENT_NAME, new AddressTypesRequestedService());
		initServices.put(SECTOR_TYPES_REQUESTED_EVENT_NAME, new SectorTypesRequestedService());
		initServices.put(COUNTRIES_REQUESTED_EVENT_NAME, new CountriesRequestedService());
		initServices.put(RESULT_STATUS_REQUESTED_EVENT_NAME, new ResultsStatusRequestedService());
		initServices.put(PRODUCTS_REQUESTED_EVENT_NAME, new ProductsRequestedService());
		initServices.put(COUNTRY_TERRITORIES_REQUESTED_EVENT_NAME, new CountryTerritoriesRequestedService(mapper));
		initServices.put(LOCATION_SEARCH_REQUESTED_EVENT_NAME, new LocationSearchRequestedService());
		initServices.put(LOCATION_CREATE_REQUESTED_EVENT_NAME, new LocationCreateRequestedService());
		initServices.put(LOCATION_UPDATE_REQUESTED_EVENT_NAME, new LocationUpdateRequestedService());
		initServices.put(LOCATIONS_REQUESTED_EVENT_NAME, new LocationsRequestedService(mapper));
		initServices.put(PRODUCTS_UPDATE_REQUESTED_EVENT_NAME, new ProductsUpdateRequestedService());
		return new ReceiverServiceFactory(initServices);
	}

	@Override
	public String getTopicArn() {
		return System.getenv(LPR_UI_TOPIC_IN_ARN);
	}
}
