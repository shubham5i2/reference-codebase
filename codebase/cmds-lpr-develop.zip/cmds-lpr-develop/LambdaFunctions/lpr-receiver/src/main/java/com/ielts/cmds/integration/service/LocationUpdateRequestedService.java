package com.ielts.cmds.integration.service;

import com.ielts.cmds.api.common.ui_client.LocationUpdateNodeV1;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;

import static com.ielts.cmds.integration.constants.LPRReceiverConstants.LOCATION_UPDATE_REQUESTED_OUTGOING_EVENT_NAME;

public class LocationUpdateRequestedService implements IReceiverService<LocationUpdateNodeV1, LocationUpdateNodeV1> {

    @Override
    public LocationUpdateNodeV1 process(LocationUpdateNodeV1 eventBody) {
        return eventBody;
    }

    @Override
    public String getOutgoingEventName() {
        return LOCATION_UPDATE_REQUESTED_OUTGOING_EVENT_NAME;
    }
}
