package com.ielts.cmds.integration.service;

import com.ielts.cmds.serialization.lambda.receiver.service.RequestWithoutBodyReceiverService;

import static com.ielts.cmds.integration.constants.LPRReceiverConstants.PARTNERS_REQUESTED_OUTGOING_EVENT_NAME;

public class PartnersRequestedService extends RequestWithoutBodyReceiverService {

    @Override
    public String getOutgoingEventName() {
        return PARTNERS_REQUESTED_OUTGOING_EVENT_NAME;
    }
}
