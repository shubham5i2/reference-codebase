package com.ielts.cmds.integration.service;

import com.ielts.cmds.serialization.lambda.receiver.service.RequestWithoutBodyReceiverService;

import static com.ielts.cmds.integration.constants.LPRReceiverConstants.RESULT_STATUS_REQUESTED_OUTGOING_EVENT_NAME;

public class ResultsStatusRequestedService extends RequestWithoutBodyReceiverService {

    @Override
    public String getOutgoingEventName() {
        return RESULT_STATUS_REQUESTED_OUTGOING_EVENT_NAME;
    }
}
