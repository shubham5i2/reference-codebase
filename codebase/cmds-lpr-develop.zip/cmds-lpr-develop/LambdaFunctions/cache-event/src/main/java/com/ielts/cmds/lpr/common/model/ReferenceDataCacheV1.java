package com.ielts.cmds.lpr.common.model;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Getter
@Setter
public class ReferenceDataCacheV1 {

    private LocalDateTime lastUpdatedDatetime;

    private String referenceDiscriminator;

    private UUID referenceUuid;

    private String code;

    private String name;

    private String description;

    private LocalDate effectiveFromDate;

    private LocalDate effectiveToDate;

    private List<AdditionalAttributeV1> additionalDetails;

}
