package com.ielts.cmds.lpr.common.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdditionalAttributeV1 {

    private String name;

    private String value;
}
