package com.ielts.cmds.integration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.evt_181.ReferenceDataChangedV1;
import com.ielts.cmds.api.lpr007referencedatacachechanged.ReferenceDataCacheChanged;
import com.ielts.cmds.api.lpr007referencedatacachechanged.ReferenceDataCacheChanged.ResultEnum;
import com.ielts.cmds.integration.cache.RefCacheWriter;
import com.ielts.cmds.integration.constants.RefDataWriteCacheConstants;
import com.ielts.cmds.integration.exception.InvalidCacheDataException;
import com.ielts.cmds.integration.factory.JedisFactory;
import com.ielts.cmds.integration.utils.RefDataWriterCacheUtils;
import com.ielts.cmds.lpr.common.model.ReferenceDataCacheV1;
import com.ielts.cmds.serialization.lambda.AbstractLambda;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.UnifiedJedis;
import redis.clients.jedis.exceptions.JedisConnectionException;

import static com.ielts.cmds.integration.constants.RefDataWriteCacheConstants.REFERENCE_DATA_CACHE_CHANGED;

@Slf4j
public class RefDataCacheWriter extends AbstractLambda<ReferenceDataChangedV1, ReferenceDataCacheChanged> {

    private RefCacheWriter jedisWriter;

    private UnifiedJedis jedisInstance;

    private JedisFactory jedisFactory = new JedisFactory();

    public RefDataCacheWriter() throws JedisConnectionException {
        jedisInstance = jedisFactory.getJedisInstance();
    }

    public RefDataCacheWriter(UnifiedJedis jedisInstance) {
        this.jedisInstance = jedisInstance;
    }


    @Override
    protected ReferenceDataCacheChanged processRequest(ReferenceDataChangedV1 referenceDataChangedV1) {
        ReferenceDataCacheChanged response = null;
        try {
            RefDataWriterCacheUtils refDataWriterCacheUtils = new RefDataWriterCacheUtils();
            ReferenceDataCacheV1 referenceDataCache = refDataWriterCacheUtils.mapRequestToReferenceDataCache(referenceDataChangedV1);
            jedisWriter = getRefCacheWriterInstance(jedisInstance);
            ResultEnum responseStatus = jedisWriter.writeRefDataToCache(referenceDataCache);
            ThreadLocalHeaderContext.getContext().setEventName(REFERENCE_DATA_CACHE_CHANGED);
            response = refDataWriterCacheUtils.buildReferenceDataChangedResponse(referenceDataCache, responseStatus);
            log.debug("response {}", responseStatus);
        } catch (JsonProcessingException | InvalidCacheDataException e) {
            log.error("exception occurred while processing writer request {}", e.getMessage());
        }
        return response;
    }

    public RefCacheWriter getRefCacheWriterInstance(UnifiedJedis jedisInstance) {
        return new RefCacheWriter(jedisInstance);
    }

    @Override
    protected String getTopicName() {
        return System.getenv(RefDataWriteCacheConstants.REF_DATA_CACHE_TOPIC_OUT);
    }
}
