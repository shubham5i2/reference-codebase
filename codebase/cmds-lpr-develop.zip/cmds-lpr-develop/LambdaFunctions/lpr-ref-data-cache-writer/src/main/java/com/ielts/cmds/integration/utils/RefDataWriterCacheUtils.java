package com.ielts.cmds.integration.utils;

import com.ielts.cmds.api.evt_181.ReferenceDataChangedV1;
import com.ielts.cmds.api.lpr007referencedatacachechanged.ReferenceDataCacheChanged;
import com.ielts.cmds.lpr.common.model.AdditionalAttributeV1;
import com.ielts.cmds.lpr.common.model.ReferenceDataCacheV1;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

@Slf4j
public class RefDataWriterCacheUtils {

    public ReferenceDataCacheV1 mapRequestToReferenceDataCache(ReferenceDataChangedV1 referenceDataChangedV1Request) {
        ReferenceDataCacheV1 referenceDataCacheV1 = new ReferenceDataCacheV1();
        List<AdditionalAttributeV1> additionalAttributeV1List = new ArrayList<>();
        if (Objects.nonNull(referenceDataChangedV1Request.getAdditionalDetails())) {
            additionalAttributeV1List = referenceDataChangedV1Request.getAdditionalDetails()
                    .stream().map(this::mapAdditionalDetailsToReferenceCache).collect(Collectors.toList());
        }
        referenceDataCacheV1.setReferenceUuid(referenceDataChangedV1Request.getReferenceUuid());
        if (!StringUtils.isEmpty(referenceDataChangedV1Request.getDescription())) {
            referenceDataCacheV1.setDescription(referenceDataChangedV1Request.getDescription());
        }
        if (!StringUtils.isEmpty(referenceDataChangedV1Request.getCode())) {
            referenceDataCacheV1.setCode(referenceDataChangedV1Request.getCode());
        }
        if (!StringUtils.isEmpty(referenceDataChangedV1Request.getName())) {
            referenceDataCacheV1.setName(referenceDataChangedV1Request.getName());
        }
        referenceDataCacheV1.setReferenceDiscriminator(referenceDataChangedV1Request.getReferenceDiscriminator());
        referenceDataCacheV1.setEffectiveFromDate(referenceDataChangedV1Request.getEffectiveFromDate());
        referenceDataCacheV1.setEffectiveToDate(referenceDataChangedV1Request.getEffectiveToDate());
        referenceDataCacheV1.setAdditionalDetails(additionalAttributeV1List);
        referenceDataCacheV1.setLastUpdatedDatetime(ThreadLocalHeaderContext.getContext().getEventDateTime());
        return referenceDataCacheV1;
    }

    private com.ielts.cmds.lpr.common.model.AdditionalAttributeV1 mapAdditionalDetailsToReferenceCache(com.ielts.cmds.api.evt_181.AdditionalAttributeV1 additionalAttributeV1Request) {
        com.ielts.cmds.lpr.common.model.AdditionalAttributeV1 additionalAttributeV1 = new com.ielts.cmds.lpr.common.model.AdditionalAttributeV1();

        additionalAttributeV1.setName(additionalAttributeV1Request.getName());
        additionalAttributeV1.setValue(additionalAttributeV1Request.getValue());

        return additionalAttributeV1;
    }

    public ReferenceDataCacheChanged buildReferenceDataChangedResponse(ReferenceDataCacheV1 referenceDataCacheV1, ReferenceDataCacheChanged.ResultEnum resultEnum) {
        ReferenceDataCacheChanged referenceDataCacheChanged = new ReferenceDataCacheChanged();
        referenceDataCacheChanged.setReferenceDiscriminator(referenceDataCacheV1.getReferenceDiscriminator());
        referenceDataCacheChanged.setResult(resultEnum);
        referenceDataCacheChanged.setReferenceDataUuid(referenceDataCacheV1.getReferenceUuid());
        return referenceDataCacheChanged;
    }
}
