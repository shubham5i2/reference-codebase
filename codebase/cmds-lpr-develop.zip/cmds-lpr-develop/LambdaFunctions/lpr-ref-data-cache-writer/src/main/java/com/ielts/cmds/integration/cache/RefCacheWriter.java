package com.ielts.cmds.integration.cache;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.lpr007referencedatacachechanged.ReferenceDataCacheChanged.ResultEnum;
import com.ielts.cmds.integration.exception.InvalidCacheDataException;
import com.ielts.cmds.lpr.common.model.ReferenceDataCacheV1;
import com.ielts.cmds.serialization.lambda.mapper.IObjectMapper;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import redis.clients.jedis.UnifiedJedis;
import redis.clients.jedis.json.Path2;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.ielts.cmds.integration.constants.RefDataWriteCacheConstants.ALL;
import static com.ielts.cmds.integration.constants.RefDataWriteCacheConstants.COLON;
import static com.ielts.cmds.integration.constants.RefDataWriteCacheConstants.DOLLAR;
import static com.ielts.cmds.integration.constants.RefDataWriteCacheConstants.EQUALS_SIGN;
import static com.ielts.cmds.integration.constants.RefDataWriteCacheConstants.JEDIS_SEARCH_PREFIX_PATTERN;
import static com.ielts.cmds.integration.constants.RefDataWriteCacheConstants.REFERENCE;
import static com.ielts.cmds.integration.constants.RefDataWriteCacheConstants.REFERENCE_DATA_UUID;
import static com.ielts.cmds.integration.constants.RefDataWriteCacheConstants.V1;


@Slf4j
public class RefCacheWriter implements IObjectMapper {

	private UnifiedJedis jedisInstance;

	public RefCacheWriter(UnifiedJedis jedisInstance) {
		this.jedisInstance = jedisInstance;
	}


	public ResultEnum writeRefDataToCache(ReferenceDataCacheV1 referenceDataCacheV1) throws JsonProcessingException, InvalidCacheDataException {
		log.debug("Connected to Jedis");
		return processRefDataRequest(referenceDataCacheV1);
	}

	protected ResultEnum processRefDataRequest(final ReferenceDataCacheV1 referenceDataCacheV1) throws JsonProcessingException, InvalidCacheDataException {
		LocalDateTime eventDateTime = ThreadLocalHeaderContext.getContext().getEventDateTime();
		String refKey = buildRefDataCacheKey(referenceDataCacheV1);
		boolean isRefKeyExists = jedisInstance.exists(refKey);
		log.debug("checkIfRefTypeExists {}", isRefKeyExists);
		if (isRefKeyExists) {
			return performCacheOperation(refKey, referenceDataCacheV1, eventDateTime);
		} else {
			return createNewRefDataIntoCache(referenceDataCacheV1, refKey);
		}
	}

	protected ResultEnum performCacheOperation(final String refKey, final ReferenceDataCacheV1 referenceDataCache,
															  final LocalDateTime eventDateTime) throws JsonProcessingException, InvalidCacheDataException {
		JSONObject refDataByUuid = fetchReferenceDataFromCache(referenceDataCache, refKey);
		boolean isReferenceUuidExists = Objects.nonNull(refDataByUuid);
		boolean isRefDataRequestUpdatable = isReferenceUuidExists && isRefDataRequestUpdatable(refDataByUuid, eventDateTime);
		log.debug("isRefDataRequestUpdatable {}", isRefDataRequestUpdatable);
		if (!isReferenceUuidExists) {
			return insertRefDataIntoCache(referenceDataCache, refKey);
		} else if (isRefDataRequestUpdatable) {
			return updateRefDataIntoCache(referenceDataCache, refKey);
		} else {
			log.info("cache update request is ignored as the data present in cache is up to date for reference type {} and reference uuid {}", referenceDataCache.getReferenceDiscriminator(), referenceDataCache.getReferenceUuid());
			return ResultEnum.IGNORED;
		}
	}

	protected JSONObject fetchReferenceDataFromCache(ReferenceDataCacheV1 referenceDataCacheV1, String refDataCacheKey) throws InvalidCacheDataException {
		//  Sample search pattern $.[?(@.attributeKey=='value')]
		String searchPattern = buildRefDataSearchPattern(referenceDataCacheV1.getReferenceUuid().toString());
//		casting cache response as it is stored in array`
		JSONArray refData = (JSONArray) jedisInstance.jsonGet(refDataCacheKey, Path2.of(searchPattern));
		return validateReferenceData(refData, referenceDataCacheV1.getReferenceDiscriminator(), referenceDataCacheV1.getReferenceUuid().toString());
	}

	protected ResultEnum insertRefDataIntoCache(final ReferenceDataCacheV1 referenceDataCacheV1, String refKey) throws JsonProcessingException {
		log.debug("inserting new record into existing reference type....");
		String referenceDataStr = getMapperWithProperties().writeValueAsString(referenceDataCacheV1);
		jedisInstance.jsonArrAppend(refKey, Path2.of(DOLLAR), referenceDataStr);
		log.info("reference data inserted successfully into cache for reference type {} and reference uuid {}", referenceDataCacheV1.getReferenceDiscriminator(), referenceDataCacheV1.getReferenceUuid());
		return ResultEnum.SUCCESS;
	}

	protected ResultEnum updateRefDataIntoCache(ReferenceDataCacheV1 referenceDataCacheV1, String refKey) throws JsonProcessingException {
		log.debug("update existing record into existing reference type....");
		String refDataSearchPattern = buildRefDataSearchPattern(referenceDataCacheV1.getReferenceUuid().toString());
		String referenceDataCacheStr = getMapperWithProperties().writeValueAsString(referenceDataCacheV1);
		jedisInstance.jsonSet(refKey, Path2.of(refDataSearchPattern), referenceDataCacheStr);
		log.info("reference data updated successfully into cache for reference type {} and reference uuid {}", referenceDataCacheV1.getReferenceDiscriminator(), referenceDataCacheV1.getReferenceUuid());
		return ResultEnum.SUCCESS;
	}

	protected ResultEnum createNewRefDataIntoCache(ReferenceDataCacheV1 referenceDataCacheV1, String refDataCacheKey) throws JsonProcessingException {
		log.debug("creating ref data first time in cache....");
		List<ReferenceDataCacheV1> referenceDataCacheV1List = new ArrayList<>();
		referenceDataCacheV1List.add(referenceDataCacheV1);
		String referenceDataCacheV1ListStr = getMapperWithProperties().writeValueAsString(referenceDataCacheV1List);
		jedisInstance.jsonSet(refDataCacheKey, referenceDataCacheV1ListStr);
		log.info("reference data created successfully into cache for reference type {} and reference uuid {}", referenceDataCacheV1.getReferenceDiscriminator(), referenceDataCacheV1.getReferenceUuid());
		return ResultEnum.SUCCESS;
	}

	public boolean isRefDataRequestUpdatable(final JSONObject refData, final LocalDateTime eventDateTime) throws JsonProcessingException {
		ReferenceDataCacheV1 referenceDataCacheV1 = getMapperWithProperties().readValue(refData.toString(), ReferenceDataCacheV1.class);
		return referenceDataCacheV1.getLastUpdatedDatetime().isBefore(eventDateTime);
	}

	public String buildRefDataCacheKey(final ReferenceDataCacheV1 referenceDataCache) {
		return String.join(COLON, REFERENCE, referenceDataCache.getReferenceDiscriminator(),V1, ALL);
	}

	public String buildRefDataSearchPattern(String referenceUuid) {
		return JEDIS_SEARCH_PREFIX_PATTERN.concat(REFERENCE_DATA_UUID).concat(EQUALS_SIGN)
				.concat(EQUALS_SIGN).concat("'").concat(referenceUuid).concat("'").concat(")").concat("]");
	}

	public JSONObject validateReferenceData(JSONArray refData, String referenceDiscriminator, String referenceUuid) throws InvalidCacheDataException {
		String invalidCacheDataMsg =  "Invalid cache data found for reference -" + referenceDiscriminator  + "and referenceUuid -" + referenceUuid;
		log.info("ref data {}", refData);
		if (refData.length() == 0) {
			return null;
		} else if (refData.length() > 1) {
			throw new InvalidCacheDataException(invalidCacheDataMsg);
		} else {
			return refData.getJSONObject(0);
		}
	}
}
