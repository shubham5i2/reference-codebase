package com.ielts.cmds.integration.constants;

public class RefDataWriteCacheConstants {

    private RefDataWriteCacheConstants() {}

    public static final String REF_DATA_CACHE_TOPIC_OUT = "lpr_ref_data_cache_topic_out";
    public static final String REDIS_ELASTICACHE_HOST = "redis_elasticache_host";
    public static final String REDIS_ELASTICACHE_PORT = "redis_elasticache_port";

    public static final String DEFAULT_REDIS_ELASTIC_CACHE_PORT = "6379";

    public static final String IS_CLUSTER_MODE_ENABLED = "is_cluster_mode_enabled";

    public static final String REFERENCE = "reference";

    public static final String KEY_OF_SECTOR_TYPES = "reference:sector-types";

    public static final String COLON = ":";
    public static final String V1 = "v1";
    public static final String ALL = "all";
    public static final String EQUALS_SIGN = "=";
    public static final String JEDIS_SEARCH_PREFIX_PATTERN = "$.[?(@.";
    public static final String REFERENCE_DATA_UUID = "referenceUuid";
    public static final String DOLLAR = "$";
    public static final String PONG = "pong";

    public static final String REFERENCE_DATA_CACHE_CHANGED = "ReferenceDataCacheChanged";

}
