package com.ielts.cmds.integration.cache;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.lpr007referencedatacachechanged.ReferenceDataCacheChanged.ResultEnum;
import com.ielts.cmds.integration.SQSEventSetup;
import com.ielts.cmds.integration.exception.InvalidCacheDataException;
import com.ielts.cmds.lpr.common.model.ReferenceDataCacheV1;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import redis.clients.jedis.UnifiedJedis;
import redis.clients.jedis.json.Path2;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class RefCacheWriterTest {

    @InjectMocks
    private RefCacheWriter jedisCacheWriter;

    @Mock
    private ReferenceDataCacheV1 event;

    @Mock
    private UnifiedJedis jedisInstance;


    @BeforeEach
    public void setUp()  {
        event = SQSEventSetup.getReferenceDataEventForTest("address_type");
        jedisCacheWriter = Mockito.spy(new RefCacheWriter(jedisInstance));
        HeaderContext headerContext = new HeaderContext();
        headerContext.setEventDateTime(LocalDateTime.parse(String.valueOf(LocalDateTime.parse("2024-02-21T21:51:25.628"))));
        ThreadLocalHeaderContext.setContext(headerContext);
    }

    @Test
    void whenProcessRefDataCalledForCreate_thenShouldCallCreateRefData() throws JsonProcessingException, InvalidCacheDataException {
        // Given
        String refKey = SQSEventSetup.getRefDataKeyForTest("address_type");
        ReferenceDataCacheV1 refData = SQSEventSetup.getReferenceDataEventForTest("address_type");
        doReturn(refKey).when(jedisCacheWriter).buildRefDataCacheKey(ArgumentMatchers.any());
        doReturn(false).when(jedisInstance).exists(refKey);

        // When
        jedisCacheWriter.processRefDataRequest(refData);

        // Then
        verify(jedisCacheWriter).createNewRefDataIntoCache(refData, refKey);
    }

    @Test
    void whenProcessRefDataCalledForUpdate_thenShouldCallUpdateRefData() throws JsonProcessingException, InvalidCacheDataException {
        // Given
        String referenceUuid = event.getReferenceUuid().toString();
        JSONArray jsonArray = new JSONArray();
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("referenceUuid", referenceUuid);
        String refKey = SQSEventSetup.getRefDataKeyForTest("address_type");
        String searchPattern = SQSEventSetup.buildRefDataSearchPatternForTest(referenceUuid);

        doReturn(jsonObject).when(jedisCacheWriter).validateReferenceData(jsonArray, "address_type", referenceUuid);
        doReturn(refKey).when(jedisCacheWriter).buildRefDataCacheKey(ArgumentMatchers.any());
        doReturn(searchPattern).when(jedisCacheWriter).buildRefDataSearchPattern(referenceUuid);
        doReturn(true).when(jedisInstance).exists(refKey);
        doReturn(true).when(jedisCacheWriter).isRefDataRequestUpdatable(jsonObject, LocalDateTime.parse(String.valueOf(LocalDateTime.parse("2024-02-21T21:51:25.628"))));
        doReturn(jsonArray).when(jedisInstance).jsonGet(refKey, Path2.of(searchPattern));

        // When
        jedisCacheWriter.processRefDataRequest(event);

        // Then
        verify(jedisCacheWriter).updateRefDataIntoCache(event, refKey);
    }

    @Test
    void whenPerformCacheOperationCalledForUpdate_thenShouldCallUpdateRefData() throws InvalidCacheDataException, JsonProcessingException {
        // Given
        String referenceUuid = event.getReferenceUuid().toString();
        String searchPattern = SQSEventSetup.buildRefDataSearchPatternForTest(referenceUuid);
        String refKey = SQSEventSetup.getRefDataKeyForTest("address_type");
        LocalDateTime eventDateTime = LocalDateTime.parse("2024-02-21T21:51:25.628");
        event.setReferenceDiscriminator("reference:address_type:v1:all");
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("referenceUuid", UUID.randomUUID().toString());

        doReturn(searchPattern).when(jedisCacheWriter).buildRefDataSearchPattern(referenceUuid);
        doReturn(true).when(jedisCacheWriter).isRefDataRequestUpdatable(jsonObject, LocalDateTime.parse(String.valueOf(LocalDateTime.parse("2024-02-21T21:51:25.628"))));
        doReturn(jsonObject).when(jedisCacheWriter).fetchReferenceDataFromCache(event, event.getReferenceDiscriminator());

        // When
        jedisCacheWriter.performCacheOperation(refKey, event, eventDateTime);

        // Then
        verify(jedisCacheWriter).updateRefDataIntoCache(event, refKey);
    }

    @Test
    void whenPerformCacheOperationCalledForInsert_thenShouldCallInsertRefData() throws InvalidCacheDataException, JsonProcessingException {
        // Given
        String refKey = SQSEventSetup.getRefDataKeyForTest("address_type");
        LocalDateTime eventDateTime = LocalDateTime.parse("2024-02-21T21:51:25.628");
        event.setReferenceDiscriminator("reference:address_type:v1:all");

        doReturn(null).when(jedisCacheWriter).fetchReferenceDataFromCache(event, event.getReferenceDiscriminator());

        // When
        jedisCacheWriter.performCacheOperation(refKey, event, eventDateTime);

        // Then
        verify(jedisCacheWriter).insertRefDataIntoCache(event, refKey);
    }

    @Test
    void whenPerformCacheOperationCalledForInsert_thenShouldCallUpdateRefData() throws InvalidCacheDataException, JsonProcessingException {
        // Given
        String refKey = SQSEventSetup.getRefDataKeyForTest("address_type");
        LocalDateTime eventDateTime = LocalDateTime.parse("2024-02-21T21:51:25.628");
        event.setReferenceDiscriminator("reference:address_type:v1:all");
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("referenceUuid", UUID.randomUUID());

        doReturn(true).when(jedisCacheWriter).isRefDataRequestUpdatable(jsonObject, eventDateTime);
        doReturn(jsonObject).when(jedisCacheWriter).fetchReferenceDataFromCache(event, event.getReferenceDiscriminator());

        // When
        jedisCacheWriter.performCacheOperation(refKey, event, eventDateTime);

        // Then
        verify(jedisCacheWriter).updateRefDataIntoCache(event, refKey);
    }

    @Test
    void whenPerformCacheOperationCalledForInsert_thenShouldReturnIgnored() throws InvalidCacheDataException, JsonProcessingException {
        // Given
        String refKey = SQSEventSetup.getRefDataKeyForTest("address_type");
        LocalDateTime eventDateTime = LocalDateTime.parse("2024-02-21T21:51:25.628");
        event.setReferenceDiscriminator("reference:address_type:v1:all");
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("referenceUuid", UUID.randomUUID());

        doReturn(false).when(jedisCacheWriter).isRefDataRequestUpdatable(jsonObject, eventDateTime);
        doReturn(jsonObject).when(jedisCacheWriter).fetchReferenceDataFromCache(event, event.getReferenceDiscriminator());

        // When
        ResultEnum actualResult = jedisCacheWriter.performCacheOperation(refKey, event, eventDateTime);

        // Then
        Assertions.assertEquals(ResultEnum.IGNORED, actualResult);
    }

    @Test
    void test_fetchReferenceDataFromCacheWithEmptyArray() throws InvalidCacheDataException {
        // Given
        String referenceUuid = event.getReferenceUuid().toString();
        event.setReferenceDiscriminator("reference:address_type:v1:all");
        JSONArray jsonArray = new JSONArray();
        JSONObject jsonObject = new JSONObject();
        String refKey = SQSEventSetup.getRefDataKeyForTest("address_type");
        String searchPattern = SQSEventSetup.buildRefDataSearchPatternForTest(referenceUuid);

        doReturn(jsonArray).when(jedisInstance).jsonGet(refKey, Path2.of(searchPattern));
        doReturn(searchPattern).when(jedisCacheWriter).buildRefDataSearchPattern(referenceUuid);
        doReturn(jsonObject).when(jedisCacheWriter).validateReferenceData(jsonArray, event.getReferenceDiscriminator(), event.getReferenceUuid().toString());

        // When
        jedisCacheWriter.fetchReferenceDataFromCache(event, event.getReferenceDiscriminator());

        // Then
        verify(jedisInstance).jsonGet(refKey, Path2.of(searchPattern));
    }

    @Test
    void testInsertRefDataIntoCache() throws JsonProcessingException {
        String eventStr = jedisCacheWriter.getMapperWithProperties().writeValueAsString(event);
        String refKey = SQSEventSetup.getRefDataKeyForTest("address_type");
        ResultEnum actualResult = jedisCacheWriter.insertRefDataIntoCache(event, refKey);
        verify(jedisInstance).jsonArrAppend(refKey, Path2.of("$"),eventStr);
        Assertions.assertEquals(ResultEnum.SUCCESS, actualResult);
    }

    @Test
    void testUpdateRefDataIntoCache() throws JsonProcessingException {
        // Given
        String referenceUuid = event.getReferenceUuid().toString();
        String eventStr = jedisCacheWriter.getMapperWithProperties().writeValueAsString(event);
        String refKey = SQSEventSetup.getRefDataKeyForTest("address_type");
        String searchPattern = SQSEventSetup.buildRefDataSearchPatternForTest(referenceUuid);

        // When
        ResultEnum actualResult = jedisCacheWriter.updateRefDataIntoCache(event, refKey);

        // Then
        verify(jedisInstance).jsonSet(refKey, Path2.of(searchPattern),eventStr);
        Assertions.assertEquals(ResultEnum.SUCCESS, actualResult);
    }

    @Test
    void testCreateNewRefDataIntoCache() throws JsonProcessingException {
        // Given
        List<ReferenceDataCacheV1> referenceDataCacheV1List = new ArrayList<>();
        referenceDataCacheV1List.add(event);
        String eventStr = jedisCacheWriter.getMapperWithProperties().writeValueAsString(referenceDataCacheV1List);
        String refKey = SQSEventSetup.getRefDataKeyForTest("address_type");

        // When
        ResultEnum actualResult = jedisCacheWriter.createNewRefDataIntoCache(event, refKey);

        // Then
        verify(jedisInstance).jsonSet(refKey, eventStr);
        Assertions.assertEquals(ResultEnum.SUCCESS, actualResult);
    }

    @Test
    void whenValidateReferenceDataIsCalledWithEmptyRefData_thenShouldReturnNull() throws InvalidCacheDataException {
        JSONArray jsonArray = new JSONArray();
        String referenceUuid = event.getReferenceUuid().toString();
        JSONObject jsonObject = jedisCacheWriter.validateReferenceData(jsonArray, event.getReferenceDiscriminator(), referenceUuid);
        Assertions.assertNull(jsonObject);
    }

    @Test
    void whenValidateReferenceDataIsCalledWithSingleRefData_thenShouldReturnSingleObject() throws InvalidCacheDataException {
        JSONArray jsonArray = new JSONArray();
        JSONObject expectedJson = new JSONObject();
        expectedJson.put("referenceUuid", UUID.randomUUID());
        jsonArray.put(expectedJson);
        String referenceUuid = event.getReferenceUuid().toString();
        JSONObject actualJson = jedisCacheWriter.validateReferenceData(jsonArray, event.getReferenceDiscriminator(), referenceUuid);
        Assertions.assertEquals(expectedJson, actualJson);
    }

    @Test
    void whenValidateReferenceDataIsCalledWithInvalidData_thenShouldThrowInvalidCacheException() throws InvalidCacheDataException {
        JSONArray jsonArray = new JSONArray();
        JSONObject jsonObject = new JSONObject();
        JSONObject jsonObject2 = new JSONObject();
        jsonObject.put("referenceUuid", UUID.randomUUID());
        jsonObject2.put("referenceUuid", UUID.randomUUID());
        jsonArray.put(jsonObject);
        jsonArray.put(jsonObject2);
        String referenceUuid = event.getReferenceUuid().toString();

        Executable executable = () -> jedisCacheWriter.validateReferenceData(jsonArray, event.getReferenceDiscriminator(), referenceUuid);
        assertThrows(InvalidCacheDataException.class, executable);
    }

    @Test
    void test_isRefDataRequestUpdatable() throws JsonProcessingException {
        LocalDateTime eventDateTime = LocalDateTime.parse("2024-02-21T21:51:25.628");
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("referenceUuid", UUID.randomUUID());
        jsonObject.put("lastUpdatedDatetime", LocalDateTime.parse("2024-02-21T22:51:25.628"));
        boolean refDataRequestUpdatable = jedisCacheWriter.isRefDataRequestUpdatable(jsonObject, eventDateTime);
        assertFalse(refDataRequestUpdatable);
    }

    @Test
    void test_buildRefDataCacheKey() {
        String refDataCacheKey = jedisCacheWriter.buildRefDataCacheKey(event);
        String expectedCacheKey = SQSEventSetup.getRefDataKeyForTest("address_type");
        assertEquals(expectedCacheKey, refDataCacheKey);
    }
}
