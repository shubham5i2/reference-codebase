package com.ielts.cmds.integration.factory;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisPooled;
import redis.clients.jedis.UnifiedJedis;
import redis.clients.jedis.exceptions.JedisClusterOperationException;
import redis.clients.jedis.exceptions.JedisConnectionException;
import uk.org.webcompere.systemstubs.environment.EnvironmentVariables;
import uk.org.webcompere.systemstubs.jupiter.SystemStub;
import uk.org.webcompere.systemstubs.jupiter.SystemStubsExtension;

import static com.ielts.cmds.integration.factory.JedisFactoryConstants.IS_CLUSTER_MODE_ENABLED;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;


@ExtendWith(MockitoExtension.class)
@ExtendWith(SystemStubsExtension.class)
class JedisFactoryTest {

	@Spy
	@InjectMocks
	private JedisFactory jedisFactory;

	@Mock
	private JedisCluster jedisCluster;

	@Mock
	private JedisPooled jedisPooled;

	@SystemStub
	private EnvironmentVariables env;

	@Mock
	private UnifiedJedis jedisInstance;

	@Test
	void testGetJedisClusterInstance() {
		doReturn(jedisCluster).when(jedisFactory).getJedisClusterInstance();
		JedisCluster jedisClusterInstance = jedisFactory.getJedisClusterInstance();
		assertNotNull(jedisClusterInstance);
		assertTrue(jedisClusterInstance instanceof JedisCluster);
	}

	@Test
	void testGetJedisPooledInstance() {
		JedisPooled jedisPooledInstance = jedisFactory.getJedisPooledInstance();
		assertNotNull(jedisPooledInstance);
		assertTrue(jedisPooledInstance instanceof JedisPooled);
	}

	@Test
	void testJedisConnectionExceptionIsThrown_whenGetJedisClusterInstance() {
		doReturn("127.0.0.1").when(jedisFactory).getRedisCacheHost();
		doReturn("7000").when(jedisFactory).getRedisCachePort();
		Executable executable = () -> jedisFactory.getJedisClusterInstance();
		Assertions.assertThrows(JedisClusterOperationException.class, executable);
	}

	@Test
	void test_whenGetJedisReader_thenReturnJedisClusterCacheWriterInstance() throws JedisConnectionException {
		env.set(IS_CLUSTER_MODE_ENABLED, true);
		doNothing().when(jedisFactory).pingJedisServer(jedisCluster);
		doReturn(jedisCluster).when(jedisFactory).getJedisClusterInstance();
		UnifiedJedis jedisClusterCacheReaderInstance = jedisFactory.getJedisInstance();
		assertTrue(jedisClusterCacheReaderInstance instanceof JedisCluster);
	}

	@Test
	void test_whenGetJedisReader_thenReturnJedisCacheWriterInstance() throws JedisConnectionException {
		env.set(IS_CLUSTER_MODE_ENABLED, false);
		doNothing().when(jedisFactory).pingJedisServer(jedisPooled);
		doReturn(jedisPooled).when(jedisFactory).getJedisPooledInstance();
		UnifiedJedis jedisCacheReaderInstance = jedisFactory.getJedisInstance();
		assertTrue(jedisCacheReaderInstance instanceof JedisPooled);
	}

	@Test
	void test_whenGetJedisReader_thenThrowException() throws JedisConnectionException {
		env.set(IS_CLUSTER_MODE_ENABLED, false);
		Executable executable = () -> jedisFactory.getJedisInstance();
		assertThrows(redis.clients.jedis.exceptions.JedisConnectionException.class, executable);
	}

}
