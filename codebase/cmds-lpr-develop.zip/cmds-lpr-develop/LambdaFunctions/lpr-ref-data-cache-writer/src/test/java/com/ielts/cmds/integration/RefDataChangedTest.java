package com.ielts.cmds.integration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.evt_181.ReferenceDataChangedV1;
import com.ielts.cmds.api.lpr007referencedatacachechanged.ReferenceDataCacheChanged;
import com.ielts.cmds.api.lpr007referencedatacachechanged.ReferenceDataCacheChanged.ResultEnum;
import com.ielts.cmds.integration.cache.RefCacheWriter;
import com.ielts.cmds.integration.exception.InvalidCacheDataException;
import com.ielts.cmds.integration.factory.JedisFactory;
import com.ielts.cmds.integration.utils.RefDataWriterCacheUtils;
import com.ielts.cmds.serialization.lambda.config.SNSClientConfig;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import org.joda.time.LocalDateTime;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.UnifiedJedis;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class RefDataChangedTest {

    private RefDataCacheWriter refDataCacheWriter;

    @Mock
    private JedisFactory jedisFactory;

    @Mock
    private Jedis jedisMock;

    @Mock
    private UnifiedJedis jedisInstance;

    @Mock
    private RefCacheWriter jedisCacheWriter;

    @Spy
    private RefDataWriterCacheUtils refDataWriterCacheUtils;

    private static MockedStatic<SNSClientConfig> snsClientConfig;

    @BeforeAll
    static void init() {
        snsClientConfig = Mockito.mockStatic(SNSClientConfig.class);
    }

    @AfterAll
    static void clear() {
        snsClientConfig.close();
    }

    @BeforeEach
    public void setup() {
        HeaderContext headerContext = new HeaderContext();
        headerContext.setEventName(String.valueOf(LocalDateTime.now()));
        ThreadLocalHeaderContext.setContext(headerContext);
        jedisCacheWriter = Mockito.spy(new RefCacheWriter(jedisInstance));
        refDataCacheWriter = Mockito.spy(new RefDataCacheWriter(jedisInstance));

    }

    @Test
    void whenSectorTypeRefRequestedThenVerifyWriteCallToCache() throws JsonProcessingException, InvalidCacheDataException {
        ReferenceDataChangedV1 referenceDataChanged = SQSEventSetup.getReferenceDataChangedEventForTest("sector_type");
        ReferenceDataCacheChanged expectedResponse = SQSEventSetup.getReferenceDataCacheChangedSuccessResponse("sector_type", ReferenceDataCacheChanged.ResultEnum.SUCCESS);
        when(refDataCacheWriter.getRefCacheWriterInstance(jedisInstance)).thenReturn(jedisCacheWriter);
        doReturn(ResultEnum.SUCCESS).when(jedisCacheWriter).writeRefDataToCache(ArgumentMatchers.any());
        ReferenceDataCacheChanged actualResponse = refDataCacheWriter.processRequest(referenceDataChanged);
        verify(jedisCacheWriter, times(1)).writeRefDataToCache(ArgumentMatchers.any());
        assertEquals(expectedResponse.getReferenceDataUuid(), actualResponse.getReferenceDataUuid());
        assertEquals(expectedResponse.getReferenceDiscriminator(), actualResponse.getReferenceDiscriminator());
        assertEquals(expectedResponse.getResult(), actualResponse.getResult());
    }

    @Test
    void whenAddressTypeRefRequestedThenVerifyWriteCallToCache() throws JsonProcessingException, InvalidCacheDataException {
        ReferenceDataChangedV1 referenceDataChanged = SQSEventSetup.getReferenceDataChangedEventForTest("address_type");
        ReferenceDataCacheChanged expectedResponse = SQSEventSetup.getReferenceDataCacheChangedSuccessResponse("address_type", ReferenceDataCacheChanged.ResultEnum.SUCCESS);
        when(refDataCacheWriter.getRefCacheWriterInstance(jedisInstance)).thenReturn(jedisCacheWriter);
        doReturn(ResultEnum.SUCCESS).when(jedisCacheWriter).writeRefDataToCache(ArgumentMatchers.any());
        ReferenceDataCacheChanged actualResponse = refDataCacheWriter.processRequest(referenceDataChanged);
        verify(jedisCacheWriter, times(1)).writeRefDataToCache(ArgumentMatchers.any());
        assertEquals(expectedResponse.getReferenceDataUuid(), actualResponse.getReferenceDataUuid());
        assertEquals(expectedResponse.getReferenceDiscriminator(), actualResponse.getReferenceDiscriminator());
        assertEquals(expectedResponse.getResult(), actualResponse.getResult());
    }
}
