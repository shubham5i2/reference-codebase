package com.ielts.cmds.integration.utils;

import com.ielts.cmds.api.evt_181.ReferenceDataChangedV1;
import com.ielts.cmds.integration.SQSEventSetup;
import com.ielts.cmds.lpr.common.model.ReferenceDataCacheV1;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import org.joda.time.LocalDateTime;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

@ExtendWith(MockitoExtension.class)
class RefDataWriterCacheUtilsTest {

    @InjectMocks
    private RefDataWriterCacheUtils refDataWriterCacheUtils;

    @BeforeEach
    void setup() {
        HeaderContext headerContext = new HeaderContext();
        headerContext.setEventName(String.valueOf(LocalDateTime.now()));
        ThreadLocalHeaderContext.setContext(headerContext);
    }

    @Test
    void whenMapReferenceDataCacheCalled_thenReturnReferenceDataCacheV1() {
        ReferenceDataChangedV1 expectedReferenceDataChangedV1 = SQSEventSetup.getReferenceDataChangedEventForTest("address_type");
        ReferenceDataCacheV1 actualReferenceDataCacheV1 = refDataWriterCacheUtils.mapRequestToReferenceDataCache(expectedReferenceDataChangedV1);
        Assertions.assertEquals(expectedReferenceDataChangedV1.getReferenceUuid(), actualReferenceDataCacheV1.getReferenceUuid());
        Assertions.assertEquals(expectedReferenceDataChangedV1.getReferenceDiscriminator(), actualReferenceDataCacheV1.getReferenceDiscriminator());
        Assertions.assertEquals(expectedReferenceDataChangedV1.getCode(), actualReferenceDataCacheV1.getCode());
        Assertions.assertEquals(expectedReferenceDataChangedV1.getName(), actualReferenceDataCacheV1.getName());
        Assertions.assertEquals(expectedReferenceDataChangedV1.getDescription(), actualReferenceDataCacheV1.getDescription());
        Assertions.assertEquals(expectedReferenceDataChangedV1.getEffectiveFromDate(), actualReferenceDataCacheV1.getEffectiveFromDate());
        Assertions.assertEquals(expectedReferenceDataChangedV1.getEffectiveToDate(), actualReferenceDataCacheV1.getEffectiveToDate());
        for (int i = 0; i < expectedReferenceDataChangedV1.getAdditionalDetails().size(); i++) {
            Assertions.assertEquals(expectedReferenceDataChangedV1.getAdditionalDetails().get(i).getName(), actualReferenceDataCacheV1.getAdditionalDetails().get(i).getName());
            Assertions.assertEquals(expectedReferenceDataChangedV1.getAdditionalDetails().get(i).getValue(), actualReferenceDataCacheV1.getAdditionalDetails().get(i).getValue());
        }
    }

    @Test
    void whenMapReferenceDataCacheCalledWithNullDesc_thenShouldNotThrowNullPointerException() {
        ReferenceDataChangedV1 expectedReferenceDataChangedV1 = SQSEventSetup.getReferenceDataChangedEventForTest("address_type");
        expectedReferenceDataChangedV1.setDescription(null);
        assertDoesNotThrow(() -> refDataWriterCacheUtils.mapRequestToReferenceDataCache(expectedReferenceDataChangedV1));
    }

    @Test
    void whenMapReferenceDataCacheCalledWithNullCode_thenShouldNotThrowNullPointerException() {
        ReferenceDataChangedV1 expectedReferenceDataChangedV1 = SQSEventSetup.getReferenceDataChangedEventForTest("address_type");
        expectedReferenceDataChangedV1.setCode(null);
        assertDoesNotThrow(() -> refDataWriterCacheUtils.mapRequestToReferenceDataCache(expectedReferenceDataChangedV1));
    }

    @Test
    void whenMapReferenceDataCacheCalledWithNullName_thenShouldNotThrowNullPointerException() {
        ReferenceDataChangedV1 expectedReferenceDataChangedV1 = SQSEventSetup.getReferenceDataChangedEventForTest("address_type");
        expectedReferenceDataChangedV1.setName(null);
        assertDoesNotThrow(() -> refDataWriterCacheUtils.mapRequestToReferenceDataCache(expectedReferenceDataChangedV1));
    }

    @Test
    void whenMapReferenceDataCacheCalledWithEmptyAdditionalAttributes_thenShouldNotThrowNullPointerException() {
        ReferenceDataChangedV1 expectedReferenceDataChangedV1 = SQSEventSetup.getReferenceDataChangedEventForTest("address_type");
        expectedReferenceDataChangedV1.setAdditionalDetails(Collections.emptyList());
        assertDoesNotThrow(() -> refDataWriterCacheUtils.mapRequestToReferenceDataCache(expectedReferenceDataChangedV1));
    }

    @Test
    void whenMapAdditionalDetailsCalled_thenReturnAdditionalAttribute() {
        ReferenceDataChangedV1 expectedReferenceDataChangedV1 = SQSEventSetup.getReferenceDataChangedEventForTest("address_type");
        ReferenceDataCacheV1 actualReferenceDataCacheV1 = refDataWriterCacheUtils.mapRequestToReferenceDataCache(expectedReferenceDataChangedV1);
        for (int i = 0; i < expectedReferenceDataChangedV1.getAdditionalDetails().size(); i++) {
            Assertions.assertEquals(expectedReferenceDataChangedV1.getAdditionalDetails().get(i).getName(), actualReferenceDataCacheV1.getAdditionalDetails().get(i).getName());
            Assertions.assertEquals(expectedReferenceDataChangedV1.getAdditionalDetails().get(i).getValue(), actualReferenceDataCacheV1.getAdditionalDetails().get(i).getValue());
        }
    }
}
