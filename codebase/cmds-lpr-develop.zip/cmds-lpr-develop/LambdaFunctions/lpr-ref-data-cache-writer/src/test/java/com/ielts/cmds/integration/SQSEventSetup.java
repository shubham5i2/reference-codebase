package com.ielts.cmds.integration;

import com.ielts.cmds.api.evt_181.ReferenceDataChangedV1;
import com.ielts.cmds.api.lpr007referencedatacachechanged.ReferenceDataCacheChanged;
import com.ielts.cmds.lpr.common.model.ReferenceDataCacheV1;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static com.ielts.cmds.integration.constants.RefDataWriteCacheConstants.ALL;
import static com.ielts.cmds.integration.constants.RefDataWriteCacheConstants.COLON;
import static com.ielts.cmds.integration.constants.RefDataWriteCacheConstants.EQUALS_SIGN;
import static com.ielts.cmds.integration.constants.RefDataWriteCacheConstants.JEDIS_SEARCH_PREFIX_PATTERN;
import static com.ielts.cmds.integration.constants.RefDataWriteCacheConstants.REFERENCE;
import static com.ielts.cmds.integration.constants.RefDataWriteCacheConstants.REFERENCE_DATA_UUID;
import static com.ielts.cmds.integration.constants.RefDataWriteCacheConstants.V1;

public class SQSEventSetup {

    public static ReferenceDataCacheV1 getReferenceDataEventForTest(String referenceDiscriminator) {
        ReferenceDataCacheV1 referenceDataCacheV1 = new ReferenceDataCacheV1();
        List<com.ielts.cmds.lpr.common.model.AdditionalAttributeV1> additionalAttributeV1List = new ArrayList<>();
        com.ielts.cmds.lpr.common.model.AdditionalAttributeV1 additionalAttributeV1 = new com.ielts.cmds.lpr.common.model.AdditionalAttributeV1();

        additionalAttributeV1.setName("testattr1");
        additionalAttributeV1.setValue("testattr2");

        referenceDataCacheV1.setReferenceUuid(UUID.randomUUID());
        referenceDataCacheV1.setCode("test_ref_code");
        referenceDataCacheV1.setName("test_ref_name");
        referenceDataCacheV1.setDescription("test_ref_desc");
        referenceDataCacheV1.setReferenceDiscriminator(referenceDiscriminator);
        referenceDataCacheV1.setEffectiveFromDate(LocalDate.now());
        referenceDataCacheV1.setEffectiveToDate(LocalDate.now());

        additionalAttributeV1List.add(additionalAttributeV1);
        referenceDataCacheV1.setAdditionalDetails(additionalAttributeV1List);

        return referenceDataCacheV1;
    }

    public static ReferenceDataChangedV1 getReferenceDataChangedEventForTest(String referenceDiscriminator) {
        ReferenceDataChangedV1 referenceDataCacheV1 = new ReferenceDataChangedV1();
        List<com.ielts.cmds.api.evt_181.AdditionalAttributeV1> additionalAttributeV1List = new ArrayList<>();
        com.ielts.cmds.api.evt_181.AdditionalAttributeV1 additionalAttributeV1 = new com.ielts.cmds.api.evt_181.AdditionalAttributeV1();

        additionalAttributeV1.setName("testattr1");
        additionalAttributeV1.setValue("testattr2");

        referenceDataCacheV1.setReferenceUuid(UUID.fromString("3bd9b4a7-2283-420b-bd23-a27edca90057"));
        referenceDataCacheV1.setCode("test_ref_code");
        referenceDataCacheV1.setName("test_ref_name");
        referenceDataCacheV1.setDescription("test_ref_desc");
        referenceDataCacheV1.setReferenceDiscriminator(referenceDiscriminator);
        referenceDataCacheV1.setEffectiveFromDate(LocalDate.now());
        referenceDataCacheV1.setEffectiveToDate(LocalDate.now());

        additionalAttributeV1List.add(additionalAttributeV1);

        referenceDataCacheV1.setAdditionalDetails(additionalAttributeV1List);

        return referenceDataCacheV1;
    }

    public static ReferenceDataCacheChanged getReferenceDataCacheChangedSuccessResponse(String referenceDiscriminator, ReferenceDataCacheChanged.ResultEnum resultEnum) {
        ReferenceDataCacheChanged referenceDataCacheChanged = new ReferenceDataCacheChanged();
        referenceDataCacheChanged.setReferenceDataUuid(UUID.fromString("3bd9b4a7-2283-420b-bd23-a27edca90057"));
        referenceDataCacheChanged.setReferenceDiscriminator(referenceDiscriminator);
        referenceDataCacheChanged.setResult(resultEnum);

        return referenceDataCacheChanged;
    }

    public static String buildRefDataSearchPatternForTest(String refUuid) {
        return "$.[?(@." + "referenceUuid" + "==" + "'" + refUuid + "'" + ")" + "]";
    }

    public static String getRefDataKeyForTest(String refDesc) {
        return String.join(COLON, REFERENCE, refDesc, V1, ALL);
    }

    public static String getRefDataSearchPatternForTest(String referenceUuid) {
        return JEDIS_SEARCH_PREFIX_PATTERN.concat(REFERENCE_DATA_UUID).concat(EQUALS_SIGN)
                .concat(EQUALS_SIGN).concat("'").concat(referenceUuid).concat("'").concat(")").concat("]");
    }
}
