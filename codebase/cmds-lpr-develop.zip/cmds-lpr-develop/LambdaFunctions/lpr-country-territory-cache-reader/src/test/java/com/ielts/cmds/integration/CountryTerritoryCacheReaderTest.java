package com.ielts.cmds.integration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.cache.factory.IService;
import com.ielts.cmds.integration.cache.factory.ServiceFactory;
import com.ielts.cmds.integration.cache.service.AllCountryTerritoryService;
import com.ielts.cmds.integration.cache.service.AllTerritoryUnderCountryService;
import com.ielts.cmds.integration.event.CountryTerritoryEvent;
import com.ielts.cmds.integration.response.GatewayErrorEntity;
import com.ielts.cmds.integration.response.GatewayResponseEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import redis.clients.jedis.UnifiedJedis;
import uk.org.webcompere.systemstubs.environment.EnvironmentVariables;
import uk.org.webcompere.systemstubs.jupiter.SystemStub;
import uk.org.webcompere.systemstubs.jupiter.SystemStubsExtension;

import java.util.HashMap;
import java.util.Map;

import static com.ielts.cmds.integration.cache.constants.CountryTerritoryCacheReaderConstants.UI_DOMAIN;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
@ExtendWith(SystemStubsExtension.class)
class CountryTerritoryCacheReaderTest {

    @InjectMocks
    private CountryTerritoryCacheReader countryTerritoryCacheReader;

    @SystemStub
    private EnvironmentVariables env;

    @Spy
    private ServiceFactory serviceFactory;

    @Mock
    private UnifiedJedis jedisInstance;

    @BeforeEach
    public void setUp() {
    	countryTerritoryCacheReader = new CountryTerritoryCacheReader(jedisInstance);
    }

    @Test
    void whenSingleCountryTerritoryRequested_thenShouldCallSingleCountryTerritoryResponseMapping() throws JsonProcessingException {
        CountryTerritoryEvent singleCountryTerritoryEventForTest = TestDataSetup.getCountryTerritoryEventForTest();
        countryTerritoryCacheReader.handleRequest(singleCountryTerritoryEventForTest);
        IService actual = serviceFactory.getService(singleCountryTerritoryEventForTest.getEventHeader().getEventName());
        assertNotNull(singleCountryTerritoryEventForTest.getEventHeader());
        assertTrue(actual instanceof AllTerritoryUnderCountryService);
    }

    @Test
    void whenAllCountryTerritoryRequested_thenShouldCallAllCountryTerritoryResponseMapping() throws JsonProcessingException {
    	CountryTerritoryEvent allCountryTerritoryEventForTest = TestDataSetup.retriveAllCountryTerritoryEventForTest();
    	countryTerritoryCacheReader.handleRequest(allCountryTerritoryEventForTest);
        IService actual = serviceFactory.getService(allCountryTerritoryEventForTest.getEventHeader().getEventName());
        assertTrue(actual instanceof AllCountryTerritoryService);
    }

    @Test
    void whenAllActiveCountryTerritoryRequested_thenShouldCallAllCountryTerritoryResponseMapping() throws JsonProcessingException {
    	CountryTerritoryEvent allCountryTerritoryEvent = TestDataSetup.getAllActiveCountryTerritoryEventForTest();
    	countryTerritoryCacheReader.handleRequest(allCountryTerritoryEvent);
        IService actual = serviceFactory.getService(allCountryTerritoryEvent.getEventHeader().getEventName());
        assertTrue(actual instanceof AllCountryTerritoryService);
    }

    @Test
    void whenAllCountryTerritoryRequested_thenReturnAllCountryTerritoryWithCorsHeader() throws JsonProcessingException {
        // Given
    	CountryTerritoryEvent allCountryTerritoryEventForTest = TestDataSetup.retriveAllCountryTerritoryEventForTest();
        Map<String, String> expectedResponseHeaders = new HashMap<>();
        expectedResponseHeaders.put("Access-Control-Allow-Origin", "https://ui.sandbox.cmdsiz.com");
        env.set(UI_DOMAIN, "https://ui.sandbox.cmdsiz.com");
        // When
        GatewayResponseEntity actualGatewayResponseEntity = countryTerritoryCacheReader.handleRequest(allCountryTerritoryEventForTest);

        // Then
        assertEquals(expectedResponseHeaders.get("Access-Control-Allow-Origin"), actualGatewayResponseEntity.getHeaders().get("Access-Control-Allow-Origin"));
    }

    @Test
    void whenSingleCountryTerritoryRequested_thenReturnAllCountryTerritoryWithCorsHeader() throws JsonProcessingException {
        // Given
    	CountryTerritoryEvent allCountryTerritoryEventForTest = TestDataSetup.getCountryTerritoryEventForTest();
        Map<String, String> expectedResponseHeaders = new HashMap<>();
        expectedResponseHeaders.put("Access-Control-Allow-Origin", "https://ui.sandbox.cmdsiz.com");
        env.set(UI_DOMAIN, "https://ui.sandbox.cmdsiz.com");
        // When
        GatewayResponseEntity actualGatewayResponseEntity = countryTerritoryCacheReader.handleRequest(allCountryTerritoryEventForTest);

        // Then
        assertEquals(expectedResponseHeaders.get("Access-Control-Allow-Origin"), actualGatewayResponseEntity.getHeaders().get("Access-Control-Allow-Origin"));
    }

    @Test
    void testGatewayErrorEntity_StatusCode() {
		GatewayErrorEntity error = new GatewayErrorEntity();
		GatewayResponseEntity gatewayResponseEntity = new GatewayResponseEntity();
		error.setCode("404");
		error.setMessage("Not Found");
		gatewayResponseEntity.setError(error);
		gatewayResponseEntity.setStatusCode(200);
		assertEquals(200, gatewayResponseEntity.getStatusCode());
		assertEquals("404", gatewayResponseEntity.getError().getCode());
		assertEquals("Not Found", gatewayResponseEntity.getError().getMessage());
    }
}