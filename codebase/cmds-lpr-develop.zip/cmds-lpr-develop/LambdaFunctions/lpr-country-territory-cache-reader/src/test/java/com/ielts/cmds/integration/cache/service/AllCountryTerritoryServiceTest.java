package com.ielts.cmds.integration.cache.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.common.country_territory_ui_client.CountryCacheV1;
import com.ielts.cmds.integration.TestDataSetup;
import com.ielts.cmds.integration.event.CountryTerritoryEvent;
import com.ielts.cmds.integration.response.GatewayResponseEntity;

import redis.clients.jedis.UnifiedJedis;
import redis.clients.jedis.json.Path2;

@ExtendWith(MockitoExtension.class)
class AllCountryTerritoryServiceTest {

    @InjectMocks
    @Spy
    private AllCountryTerritoryService allCountryTerritoryService;

    @Mock
    private UnifiedJedis jedisInstance;
    
    @Test
    void testRetrieveAllCountryTerritoryFromRedisCache_withValidKey() throws JsonProcessingException {
    	CountryTerritoryEvent allCountryTerritoryEventForTest = TestDataSetup.retriveAllCountryTerritoryEventForTest();
        List<CountryCacheV1> response = TestDataSetup.getAllCountryTerritoryForTest();
        String expectedResponse = new ObjectMapper().writeValueAsString(response);
        doReturn(response).
                when(allCountryTerritoryService).retrieveAllCountryDataFromRedisCache("reference:country:all", "true", jedisInstance);
        // When
        GatewayResponseEntity actualGatewayResponseEntity = allCountryTerritoryService.process(allCountryTerritoryEventForTest, jedisInstance);
        // Then
        assertEquals(expectedResponse, actualGatewayResponseEntity.getBody());
        assertEquals(HttpStatus.SC_OK, actualGatewayResponseEntity.getStatusCode());
    }

    @Test
    void whenAllCountryTerritoryIsRequestedAndDataNotAvailable_thenReturnResponseWithNotFound() throws JsonProcessingException {
        // Given
    	CountryTerritoryEvent allCountryTerritoryEventForTest = TestDataSetup.retriveAllCountryTerritoryEventForTest();
        // When
        GatewayResponseEntity actualGatewayResponseEntity = allCountryTerritoryService.process(allCountryTerritoryEventForTest, jedisInstance);
        // Then
        assertEquals(HttpStatus.SC_NOT_FOUND, actualGatewayResponseEntity.getStatusCode());
    }
    
    @Test
    void testRetrieveAllCountryDataFromRedisCache_whenActiveDataIsRequested() throws JsonProcessingException {
	JSONArray countryTerritoryListFromCache = TestDataSetup
		.getAllCountryDataResponse();
	List<CountryCacheV1> list = TestDataSetup.getAllCountryDataResponseInCacheFormat();
	when(jedisInstance.jsonGet("countries:v1:all", Path2.of("$"))).thenReturn(countryTerritoryListFromCache);
	doReturn(TestDataSetup.getAllActiveCountryDataResponse(list)).when(allCountryTerritoryService)
		.buildResponseForAllCountryDataBasedOnRequest(ArgumentMatchers.any(), ArgumentMatchers.any());
	List<CountryCacheV1> countryTerritoryList = allCountryTerritoryService.retrieveAllCountryDataFromRedisCache("countries:v1:all", "$", jedisInstance);
	assertNotNull(countryTerritoryList);
	assertEquals(3, countryTerritoryListFromCache.length());
	assertEquals(2, countryTerritoryList.size());
    }

    @Test
    void testRetrieveAllCountryDataFromRedisCache_whenAllDataIsRequested() throws JsonProcessingException {
	JSONArray countryTerritoryListFromCache = TestDataSetup
		.getAllCountryDataResponse();
	List<CountryCacheV1> list = TestDataSetup.getAllCountryDataResponseInCacheFormat();
	when(jedisInstance.jsonGet("countries:v1:all", Path2.of("$"))).thenReturn(countryTerritoryListFromCache);
	doReturn(TestDataSetup.getAllCountryDataResponse(list)).when(allCountryTerritoryService)
		.buildResponseForAllCountryDataBasedOnRequest(ArgumentMatchers.any(), ArgumentMatchers.any());
	List<CountryCacheV1> countryTerritoryList = allCountryTerritoryService.retrieveAllCountryDataFromRedisCache("countries:v1:all", "true", jedisInstance);
	assertNotNull(countryTerritoryList);
	assertEquals(3, countryTerritoryListFromCache.length());
	assertEquals(3, countryTerritoryList.size());
    }


    @Test
    void whenExceptionIsEncountered_ifAllCountryTerritoryIsRequested_verifyResponse() throws JsonProcessingException {
    	CountryTerritoryEvent allCountryTerritoryEventForTest = TestDataSetup.retriveAllCountryTerritoryEventForTest();
        doThrow(JsonProcessingException.class).when(allCountryTerritoryService).mapAllCountryDataResponseBody(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any());
        // When
        GatewayResponseEntity actualGatewayResponseEntity = allCountryTerritoryService.process(allCountryTerritoryEventForTest, jedisInstance);
        // Then
        assertEquals(HttpStatus.SC_INTERNAL_SERVER_ERROR, actualGatewayResponseEntity.getStatusCode());
    }

    @Test
    void testIfKeyNotPresent_verifyCacheMiss() throws JsonProcessingException {
	when(jedisInstance.jsonGet("countries:v1:all", Path2.of("$"))).thenReturn(null);
	List<CountryCacheV1> countryTerritoryList = allCountryTerritoryService.retrieveAllCountryDataFromRedisCache("countries:v1:all", "true", jedisInstance);
	assertTrue(countryTerritoryList.isEmpty());
    }

    @Test
    void testIfKeyIsNullInAllCountryTerritoryRequest_verifyEmptyResponse() throws JsonProcessingException {
	List<CountryCacheV1> countryTerritoryList = allCountryTerritoryService.retrieveAllCountryDataFromRedisCache(null, "true", jedisInstance);
	assertTrue(countryTerritoryList.isEmpty());
    }

    @Test
    void testConvertTheDataToCacheFormat_withNullCacheResponse() throws JsonProcessingException {
	List<CountryCacheV1> countryDataCacheV1List = allCountryTerritoryService.convertTheDataToCacheFormat(null);
	assertTrue(countryDataCacheV1List.isEmpty());	
    }
	
    @Test
    void testGetQueryStringParametersFromRequest_ifRequiredHeadersArePresent()  {
        CountryTerritoryEvent event = TestDataSetup.retriveAllCountryTerritoryEventForTest();
        String includeInactive = allCountryTerritoryService.getQueryStringParametersFromRequest(event);
        assertEquals("true", includeInactive);
    }

    @Test
    void testGetQueryStringParametersFromRequest_ifRequiredHeadersAreNotPresent()  {
    	CountryTerritoryEvent event = TestDataSetup.getCountryTerritoryEventForTest();
        event.getEventHeader().setEventContext(new HashMap<>());
        String includeInactive = allCountryTerritoryService.getQueryStringParametersFromRequest(event);
        assertEquals("false", includeInactive);
    }
	
    @Test
    void testBuildResponseForAllCountryDataBasedOnRequest_includeInactiveFalse_EffectiveFromDateInThePast() throws JsonProcessingException {
        CountryTerritoryEvent event = TestDataSetup.retriveAllCountryTerritoryEventForTest();
        CountryCacheV1 countryDataCacheV1  = new CountryCacheV1();
        countryDataCacheV1.setCountryUuid(UUID.randomUUID());
        countryDataCacheV1.setIso3Code("INGD");
        countryDataCacheV1.setName("test");
        countryDataCacheV1.setEffectiveToDate(LocalDate.now().plusDays(5)); //EffectiveToDate is set to future
        countryDataCacheV1.setEffectiveFromDate(LocalDate.now().minusDays(5)); //EffectiveFromDate is set to past
        
        List<CountryCacheV1> countryDataCacheV1List = new ArrayList<>();
        countryDataCacheV1List.add(countryDataCacheV1);
        Map<String, String> eventContext = new HashMap<>();
        JSONArray jsonArray = new JSONArray();
        jsonArray.put(countryDataCacheV1List);
        eventContext.put("countryUuid", "");
        event.getEventHeader().setEventContext(eventContext);
        List<CountryCacheV1> countryNodes = allCountryTerritoryService.buildResponseForAllCountryDataBasedOnRequest(jsonArray, String.valueOf(false));
        assertNotNull(countryNodes);
        assertEquals(1, countryNodes.size()); // Expecting one country as the EffectiveFromDate is in the past
    }
	
    @Test
    void testBuildResponseForAllCountryDataBasedOnRequest_includeInactiveFalse_EffectiveFromDateInTheFuture() throws JsonProcessingException {
    	CountryTerritoryEvent event = TestDataSetup.getCountryTerritoryEventForTest();
        CountryCacheV1 countryDataCacheV1 = new CountryCacheV1();
        countryDataCacheV1.setCountryUuid(UUID.randomUUID());
        countryDataCacheV1.setIso3Code("INGD");
        countryDataCacheV1.setName("test");
        countryDataCacheV1.setEffectiveToDate(LocalDate.now().plusDays(1)); // EffectiveToDate is set to tomorrow
        countryDataCacheV1.setEffectiveFromDate(LocalDate.now().plusDays(2)); // EffectiveFromDate is set to day after tomorrow

        List<CountryCacheV1> countryDataCacheV1List = new ArrayList<>();
        countryDataCacheV1List.add(countryDataCacheV1);
        Map<String, String> eventContext = new HashMap<>();
        JSONArray jsonArray = new JSONArray();
        jsonArray.put(countryDataCacheV1List);
        eventContext.put("countryUuid", "");
        event.getEventHeader().setEventContext(eventContext);
        List<CountryCacheV1> countryNodes = allCountryTerritoryService.buildResponseForAllCountryDataBasedOnRequest(jsonArray, String.valueOf(false));
        assertNotNull(countryNodes);
        assertEquals(0, countryNodes.size()); // Expecting no country as the EffectiveFromDate is in the future
    }
	
    @Test
    void testBuildResponseForAllCountryDataBasedOnRequest_includeInactiveFalse_EffectiveToDateInThePast() throws JsonProcessingException {
	CountryTerritoryEvent event = TestDataSetup.getCountryTerritoryEventForTest();
        CountryCacheV1 countryDataCacheV1 = new CountryCacheV1();
        countryDataCacheV1.setCountryUuid(UUID.randomUUID());
        countryDataCacheV1.setIso3Code("INGD");
        countryDataCacheV1.setName("test");
        countryDataCacheV1.setEffectiveToDate(LocalDate.now().minusDays(1)); // EffectiveToDate is set to yesterday
        countryDataCacheV1.setEffectiveFromDate(LocalDate.now().minusDays(2)); // EffectiveFromDate is set to two days ago

        List<CountryCacheV1> countryDataCacheV1List = new ArrayList<>();
        countryDataCacheV1List.add(countryDataCacheV1);
        Map<String, String> eventContext = new HashMap<>();
        JSONArray jsonArray = new JSONArray();
        jsonArray.put(countryDataCacheV1List);
        event.getEventHeader().setEventContext(eventContext);
        List<CountryCacheV1> countryNodes = allCountryTerritoryService.buildResponseForAllCountryDataBasedOnRequest(jsonArray, String.valueOf(false));
        assertNotNull(countryNodes);
        assertEquals(0, countryNodes.size()); // Expecting no country as the EffectiveToDate is in the past
    }
	
    @Test
    void testBuildResponseForAllCountryDataBasedOnRequest_includeInactiveFalse_EffectiveToDateInTheFuture() throws JsonProcessingException {
        CountryTerritoryEvent event = TestDataSetup.getCountryTerritoryEventForTest();
        CountryCacheV1 countryDataCacheV1  = new CountryCacheV1();
        countryDataCacheV1.setCountryUuid(UUID.randomUUID());
        countryDataCacheV1.setIso3Code("AFG");
        countryDataCacheV1.setName("RCB");
        countryDataCacheV1.setEffectiveFromDate(LocalDate.now().minusDays(6)); 
        countryDataCacheV1.setEffectiveToDate(LocalDate.now().plusDays(6)); //EffectiveToDate is set future
        List<CountryCacheV1> countryDataCacheV1List = new ArrayList<>();
        countryDataCacheV1List.add(countryDataCacheV1);
        Map<String, String> eventContext = new HashMap<>();
        JSONArray jsonArray = new JSONArray();
        jsonArray.put(countryDataCacheV1List);
        eventContext.put("countryUuid", "");
        event.getEventHeader().setEventContext(eventContext);
        List<CountryCacheV1> countryNodes = allCountryTerritoryService.buildResponseForAllCountryDataBasedOnRequest(jsonArray, String.valueOf(false));
        assertNotNull(countryNodes);
        assertEquals(1, countryNodes.size()); // Expecting one country as the EffectiveToDate is in the future
    }
	
    @Test
    void testBuildResponseForAllCountryDataBasedOnRequest_includeInactiveTrue_EffectiveDatesToCurrentDate() throws JsonProcessingException {
       	CountryTerritoryEvent event = TestDataSetup.retriveAllCountryTerritoryEventForTest();
        CountryCacheV1 countryDataCacheV1  = new CountryCacheV1();
        countryDataCacheV1.setCountryUuid(UUID.randomUUID());
        countryDataCacheV1.setIso3Code("INGD");
        countryDataCacheV1.setName("Hello");
        countryDataCacheV1.setEffectiveToDate(LocalDate.now()); //EffectiveToDate is set current date
        countryDataCacheV1.setEffectiveFromDate(LocalDate.now()); //EffectiveFromDate is set current date
        
        List<CountryCacheV1> countryDataCacheV1List = new ArrayList<>();
        countryDataCacheV1List.add(countryDataCacheV1);
        Map<String, String> eventContext = new HashMap<>();
        JSONArray jsonArray = new JSONArray();
        jsonArray.put(countryDataCacheV1List);
        eventContext.put("countryUuid", "");
        event.getEventHeader().setEventContext(eventContext);
        List<CountryCacheV1> countryNodes = allCountryTerritoryService.buildResponseForAllCountryDataBasedOnRequest(jsonArray, String.valueOf(true));
        assertNotNull(countryNodes);
        assertEquals(1, countryNodes.size()); //Expecting one country as the EffectiveDates are equal to current date
    }
    
}