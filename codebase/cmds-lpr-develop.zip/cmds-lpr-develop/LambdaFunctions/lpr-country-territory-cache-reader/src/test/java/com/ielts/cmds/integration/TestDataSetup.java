package com.ielts.cmds.integration;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.api.common.country_territory_ui_client.AdditionalDetailsV1;
import com.ielts.cmds.api.common.country_territory_ui_client.CountryCacheV1;
import com.ielts.cmds.api.common.country_territory_ui_client.TerritoryCacheV1;
import com.ielts.cmds.integration.event.CountryTerritoryEvent;
import com.ielts.cmds.integration.event.CountryTerritoryEventHeader;

import com.ielts.cmds.integration.response.GatewayResponseEntity;

import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONObject;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.ielts.cmds.integration.cache.constants.CountryTerritoryCacheReaderConstants.GET_ALL_TERRITORY_COUNTRY_CODE;
import static com.ielts.cmds.integration.cache.constants.CountryTerritoryCacheReaderConstants.GET_ALL_ACTIVE_COUNTRIES;

public class TestDataSetup {

	public static CountryTerritoryEvent getCountryTerritoryEventForTest() {
		CountryTerritoryEvent singleProductEvent = new CountryTerritoryEvent();

		CountryTerritoryEventHeader header = new CountryTerritoryEventHeader();
		header.setEventName(GET_ALL_TERRITORY_COUNTRY_CODE);
		Map<String, String> eventContext = new HashMap<>();
		eventContext.put("country", "countries");
		eventContext.put("countryUuid",  "21cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");
		header.setEventContext(eventContext);
		header.setTransactionId(UUID.randomUUID());
		header.setXaccessToken("token");
		singleProductEvent.setEventHeader(header);

		return singleProductEvent;
	}

	public static CountryTerritoryEvent retriveAllCountryTerritoryEventForTest() {
		CountryTerritoryEvent event = new CountryTerritoryEvent();

		CountryTerritoryEventHeader header = new CountryTerritoryEventHeader();
		header.setEventName(GET_ALL_ACTIVE_COUNTRIES);
		Map<String, String> eventContext = new HashMap<>();
		eventContext.put("country", "countries");
		eventContext.put("includeInactive",  "true");
		header.setEventContext(eventContext);
		header.setTransactionId(UUID.randomUUID());
		header.setXaccessToken("token");
		event.setEventHeader(header);

		return event;
	}

	public static CountryTerritoryEvent getAllActiveCountryTerritoryEventForTest() {
		CountryTerritoryEvent event = new CountryTerritoryEvent();
		CountryTerritoryEventHeader header = new CountryTerritoryEventHeader();
		header.setEventName(GET_ALL_ACTIVE_COUNTRIES);
		Map<String, String> eventContext = new HashMap<>();
		eventContext.put("country", "countries");
		header.setEventContext(eventContext);
		header.setTransactionId(UUID.randomUUID());
		header.setXaccessToken("token");
		event.setEventHeader(header);

		return event;
	}

	public static GatewayResponseEntity getSingleCountryTerritoryGatewayResponseEntityForTest() {
		GatewayResponseEntity gatewayResponseEntity = new GatewayResponseEntity();
		gatewayResponseEntity.setBody(getCountryDataForTest());
		gatewayResponseEntity.setStatusCode(HttpStatus.SC_OK);

		return gatewayResponseEntity;
	}

	public static CountryCacheV1 getCountryDataForTest() {
		CountryCacheV1 countryNode = new CountryCacheV1();
		countryNode.setCountryUuid(UUID.randomUUID());
		countryNode.setName("Postal");
		return countryNode;
	}
	
	public static TerritoryCacheV1 getTerritoryDataForTest() {
		TerritoryCacheV1 countryNode = new TerritoryCacheV1();
		countryNode.setTerritoryUuid(UUID.randomUUID());
		countryNode.setCountryUuid(UUID.randomUUID());
		countryNode.setName("Postal");
		return countryNode;
	}
	
	public static GatewayResponseEntity getSingleTerritoryGatewayResponseEntityForTest() {
		GatewayResponseEntity gatewayResponseEntity = new GatewayResponseEntity();
		gatewayResponseEntity.setBody(getTerritoryDataForTest());
		gatewayResponseEntity.setStatusCode(HttpStatus.SC_OK);

		return gatewayResponseEntity;
	}
	
	public static List<TerritoryCacheV1> getTerritoryListForTest() {
		List<TerritoryCacheV1> territoryCacheV1 = new ArrayList<>();
		territoryCacheV1.add(getTerritoryDataForTest());
		TerritoryCacheV1 territoryCacheV12 = getTerritoryDataForTest();
		territoryCacheV12.setCountryUuid(UUID.randomUUID());
		territoryCacheV12.setTerritoryUuid(UUID.randomUUID());
		territoryCacheV12.setName("Postal");
		return territoryCacheV1;
	}
	
	public static List<CountryCacheV1> getAllCountryTerritoryForTest() {
		List<CountryCacheV1> countryCacheV1 = new ArrayList<>();
		countryCacheV1.add(getCountryDataForTest());
		CountryCacheV1 countryCacheV12 = getCountryDataForTest();
		countryCacheV12.setCountryUuid(UUID.randomUUID());
		countryCacheV12.setName("Main");
		countryCacheV1.add(countryCacheV12);
		return countryCacheV1;
	}
	
	public static JSONArray getSingleCountryDataResponseInCacheFormat() {
		JSONArray cacheResult = new JSONArray();
		JSONObject country1 = new JSONObject();
		country1.put("countryUuid", UUID.randomUUID());
		country1.put("name", "Country1");
		country1.put("iso3Code", "C1");
		country1.put("effectiveFromDate", "2024-01-01");
		country1.put("effectiveToDate", "2024-12-31");
		List<JSONObject> listObj = new ArrayList<>();
		JSONObject obj1 = new JSONObject();
		obj1.put("Key", "key");
		obj1.put("value", "value");
		listObj.add(obj1);
        	cacheResult.put(country1);
        	return cacheResult;
	}

	public static CountryCacheV1 getSingleCountryDataResponse() {
		CountryCacheV1 CountryDataCacheV1 = new CountryCacheV1();
		CountryDataCacheV1.setCountryUuid(UUID.randomUUID());
		CountryDataCacheV1.setName("Postal");
		CountryDataCacheV1.iso3Code(null);
		CountryDataCacheV1.setEffectiveFromDate(LocalDate.of(2022, 01, 01));
		CountryDataCacheV1.setEffectiveToDate(LocalDate.of(2099, 12, 31));
		List<AdditionalDetailsV1> list = new ArrayList<>();
		AdditionalDetailsV1 additionalAttribute = new AdditionalDetailsV1();
		additionalAttribute.setKey("Key");
		additionalAttribute.setValue("CountryId");
		list.add(additionalAttribute);
		CountryDataCacheV1.setAdditionalDetails(list);
		return CountryDataCacheV1;
	}
	
	public static List<CountryCacheV1> getAllCountryDataResponseInCacheFormat() {
		List<CountryCacheV1> list = new ArrayList<>();
		CountryCacheV1 CountryDataCache0 = getSingleCountryDataResponse();
		list.add(CountryDataCache0);
		CountryCacheV1 CountryDataCache1 = getSingleCountryDataResponse();
		CountryDataCache1.setName("Physical");
		list.add(CountryDataCache1);
		CountryCacheV1 CountryDataCache2 = getSingleCountryDataResponse();
		CountryDataCache2.setName("Main");
		CountryDataCache2.setEffectiveToDate(LocalDate.of(2023, 12, 31));
		list.add(CountryDataCache2);
		return list;
	}

	public static JSONArray getAllCountryDataResponse() {
		JSONArray array = new JSONArray();
		array.put(getSingleCountryDataResponse());
		CountryCacheV1 CountryDataCache1 = getSingleCountryDataResponse();
		CountryDataCache1.setName("Physical");
		array.put(CountryDataCache1);
		CountryCacheV1 CountryDataCache2 = getSingleCountryDataResponse();
		CountryDataCache2.setName("Main");
		CountryDataCache2.setEffectiveToDate(LocalDate.of(2023, 12, 31));
		array.put(CountryDataCache2);
		return array;
	}
	
	public static List<CountryCacheV1> getAllActiveCountryDataResponse(List<CountryCacheV1> cacheResponse) {
		List<CountryCacheV1> CountryNodeList = new ArrayList<>();
		for(CountryCacheV1 CountryDataCache : cacheResponse) {
			if(CountryDataCache.getEffectiveFromDate().isBefore(LocalDate.now()) && CountryDataCache.getEffectiveToDate().isAfter(LocalDate.now())) {
				CountryCacheV1 CountryNode = new CountryCacheV1();
				CountryNode.setCountryUuid(CountryDataCache.getCountryUuid());
				CountryNode.setName(CountryDataCache.getName());

				CountryNodeList.add(CountryNode);
			}
		}
		return CountryNodeList;
	}
	
	public static List<CountryCacheV1> getAllCountryDataResponse(List<CountryCacheV1> CountryDataListFromCache) {
		List<CountryCacheV1> CountryNodeList = new ArrayList<>();
		for(CountryCacheV1 CountryDataCache : CountryDataListFromCache) {
			CountryCacheV1 CountryNode = new CountryCacheV1();
			CountryNode.setCountryUuid(CountryDataCache.getCountryUuid());
			CountryNode.setName(CountryDataCache.getName());

			CountryNodeList.add(CountryNode);
		}
		return CountryNodeList;
	}

	public static ObjectMapper getMapperWithProperties() {
		final ObjectMapper mapper = new ObjectMapper();
		mapper.registerModule(new JavaTimeModule());
		mapper.configure(DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE, false);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
		mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
		mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
		return mapper;
	}   
}
