package com.ielts.cmds.integration.cache.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.common.country_territory_ui_client.TerritoryCacheV1;
import com.ielts.cmds.integration.TestDataSetup;
import com.ielts.cmds.integration.event.CountryTerritoryEvent;
import com.ielts.cmds.integration.response.GatewayResponseEntity;

import redis.clients.jedis.UnifiedJedis;
import redis.clients.jedis.json.Path2;

@ExtendWith(MockitoExtension.class)
class AllTerritoryUnderCountryServiceTest {

    @InjectMocks
    @Spy
    private AllTerritoryUnderCountryService allTerritoryUnderCountryService;

    @Mock
    private UnifiedJedis jedisInstance;


    @Test
    void whenSingleCountryTerritoryRequested_thenReturnCountryTerritory() throws JsonProcessingException {
        // Given
    	CountryTerritoryEvent singleCountryTerritoryEventForTest = TestDataSetup.getCountryTerritoryEventForTest();
    	List<TerritoryCacheV1> response = TestDataSetup.getTerritoryListForTest();
        String expectedResponse = new ObjectMapper().writeValueAsString(response);
        doReturn(response).
        when(allTerritoryUnderCountryService).retrieveSingleCountryTerritoryFromRedisCache(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any());
        // When
        GatewayResponseEntity actualGatewayResponseEntity = allTerritoryUnderCountryService.process(singleCountryTerritoryEventForTest, jedisInstance);
        // Then
        assertEquals(expectedResponse, actualGatewayResponseEntity.getBody());
        assertEquals(HttpStatus.SC_OK, actualGatewayResponseEntity.getStatusCode());
    }


    @Test
    void whenSingleCountryTerritoryRequested_withNullKey_exceptDataNotFound() throws JsonProcessingException {
        // Given
    	CountryTerritoryEvent singleCountryTerritoryEventForTest = TestDataSetup.getCountryTerritoryEventForTest();
        doReturn(null).
                when(allTerritoryUnderCountryService).retrieveSingleCountryTerritoryFromRedisCache(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any());
        // When
        GatewayResponseEntity actualGatewayResponseEntity = allTerritoryUnderCountryService.process(singleCountryTerritoryEventForTest, jedisInstance);
        // Then
        assertEquals(HttpStatus.SC_NOT_FOUND, actualGatewayResponseEntity.getStatusCode());
    }

    @Test
    void whenSingleCountryTerritoryIsRequestedAndDataNotAvailable_thenReturnResponseWithNotFound() throws JsonProcessingException {
        // Given
    	CountryTerritoryEvent singleCountryTerritoryEventForTest = TestDataSetup.getCountryTerritoryEventForTest();
        when(allTerritoryUnderCountryService.retrieveSingleCountryTerritoryFromRedisCache(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(null);
        // When
        GatewayResponseEntity actualGatewayResponseEntity = allTerritoryUnderCountryService.process(singleCountryTerritoryEventForTest, jedisInstance);
        // Then
        assertEquals(HttpStatus.SC_NOT_FOUND, actualGatewayResponseEntity.getStatusCode());
    }

   @Test
   void testRetrieveSingleCountryTerritoryFromRedisCache() throws JsonProcessingException {
       CountryTerritoryEvent requestEvent = TestDataSetup.getCountryTerritoryEventForTest();
       JSONArray dataInCache = TestDataSetup.getSingleCountryDataResponseInCacheFormat();
       String key = "country:v1:all";
       String path = "$.[?(@.countryUuid=='" + requestEvent.getEventHeader().getEventContext().get("countryUuid") + "')]";
       when(jedisInstance.jsonGet(key,
               Path2.of(path)))
               .thenReturn(dataInCache);
        
       List<TerritoryCacheV1> countryNode = allTerritoryUnderCountryService.retrieveSingleCountryTerritoryFromRedisCache(key, path, jedisInstance);
       assertNotNull(countryNode);
   }

    @Test
    void whenExceptionIsEncountered_ifSingleCountryTerritoryIsRequested_verifyResponse() throws JsonProcessingException {
    	CountryTerritoryEvent singleCountryTerritoryEventForTest = TestDataSetup.getCountryTerritoryEventForTest();
        doThrow(JsonProcessingException.class).when(allTerritoryUnderCountryService).mapSingleCountryTerritoryResponseBody(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any());
        // When
        GatewayResponseEntity actualGatewayResponseEntity = allTerritoryUnderCountryService.process(singleCountryTerritoryEventForTest, jedisInstance);
        // Then
        assertEquals(HttpStatus.SC_INTERNAL_SERVER_ERROR, actualGatewayResponseEntity.getStatusCode());
    }

    @Test
    void testBuildPathForFetchingSingleData_withEmptyEventContext() throws JsonProcessingException {
        CountryTerritoryEvent singleCountryTerritoryEventForTest = TestDataSetup.getCountryTerritoryEventForTest();
        singleCountryTerritoryEventForTest.getEventHeader().setEventContext(new HashMap<>());
        String path = allTerritoryUnderCountryService.buildPathForFetchingSingleData(singleCountryTerritoryEventForTest);
        assertNull(path);
    }


    @Test
    void testBuildPathForFetchingSingleData_ifRequiredHeaderIsNotPresent() throws JsonProcessingException {
    	CountryTerritoryEvent singleCountryTerritoryEventForTest = TestDataSetup.getCountryTerritoryEventForTest();
        Map<String, String> eventContext = singleCountryTerritoryEventForTest.getEventHeader().getEventContext();
        eventContext.remove("countryUuid");
        String path = allTerritoryUnderCountryService.buildPathForFetchingSingleData(singleCountryTerritoryEventForTest);
        assertNull(path);
    }

    @Test
    void testIfKeyIsNullInSingleCountryTerritoryRequest_verifyNullResponse() throws JsonProcessingException {
    	List<TerritoryCacheV1> countryNode = allTerritoryUnderCountryService.retrieveSingleCountryTerritoryFromRedisCache(null, "path", jedisInstance);
        assertNull(countryNode);
    }

    @Test
    void testIfPathIsNullInSingleCountryTerritoryRequest_verifyNullResponse() throws JsonProcessingException {
    	List<TerritoryCacheV1> countryNode = allTerritoryUnderCountryService.retrieveSingleCountryTerritoryFromRedisCache("countries/{countryUuid}/territories:v1:all", null, jedisInstance);
        assertNull(countryNode);
    }
}
