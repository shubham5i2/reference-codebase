package com.ielts.cmds.integration;

import com.ielts.cmds.integration.cache.constants.CountryTerritoryCacheReaderConstants;
import com.ielts.cmds.integration.cache.factory.IService;
import com.ielts.cmds.integration.cache.factory.JedisFactory;
import com.ielts.cmds.integration.cache.factory.ServiceFactory;
import com.ielts.cmds.integration.event.CountryTerritoryEvent;
import com.ielts.cmds.integration.response.GatewayResponseEntity;
import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.UnifiedJedis;
import redis.clients.jedis.exceptions.JedisConnectionException;

import java.util.HashMap;
import java.util.Map;

import static com.ielts.cmds.integration.cache.constants.CountryTerritoryCacheReaderConstants.ACCESS_CONTROL_ALLOW_ORIGIN;
import static com.ielts.cmds.integration.cache.constants.CountryTerritoryCacheReaderConstants.UI_DOMAIN;

@Slf4j
public class CountryTerritoryCacheReader {

    private UnifiedJedis jedisInstance;

    private final JedisFactory jedisFactory = new JedisFactory();

    private final ServiceFactory serviceFactory = new ServiceFactory();

    public CountryTerritoryCacheReader() throws JedisConnectionException {
        jedisInstance = jedisFactory.getJedisInstance();
    }

    public CountryTerritoryCacheReader(UnifiedJedis jedisInstance) {
        this.jedisInstance = jedisInstance;
    }

    public GatewayResponseEntity handleRequest(final CountryTerritoryEvent requestEvent) {
        log.debug("Headers {}", requestEvent.getEventHeader());
        Map<String, String> responseHeaders = new HashMap<>();
        log.debug("request resource {}", buildResource(requestEvent));
        IService service = serviceFactory.getService(buildResource(requestEvent));
        GatewayResponseEntity gatewayResponseEntity = (GatewayResponseEntity) service.process(requestEvent, jedisInstance);
        responseHeaders.put(ACCESS_CONTROL_ALLOW_ORIGIN, System.getenv(UI_DOMAIN));
        gatewayResponseEntity.setHeaders(responseHeaders);
        log.info("Event Received in {} with metadata as {}",
                CountryTerritoryCacheReaderConstants.COUNTRY_TERRITORY_CACHE_READER_LAMBDA, requestEvent.getEventHeader());
        return gatewayResponseEntity;
    }

    private String buildResource(final CountryTerritoryEvent requestEvent) {
        return requestEvent.getEventHeader().getEventName();
    }
}
