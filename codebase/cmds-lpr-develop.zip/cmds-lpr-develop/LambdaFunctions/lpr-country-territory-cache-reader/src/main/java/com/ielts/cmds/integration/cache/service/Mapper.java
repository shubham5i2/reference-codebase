package com.ielts.cmds.integration.cache.service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.integration.response.GatewayErrorEntity;
import com.ielts.cmds.integration.response.GatewayResponseEntity;
import org.apache.http.HttpStatus;

import static com.ielts.cmds.integration.cache.constants.CountryTerritoryCacheReaderConstants.V1001;
import static com.ielts.cmds.integration.cache.constants.CountryTerritoryCacheReaderConstants.V1001_ERROR_MSG;

public interface Mapper {

    default ObjectMapper getMapperWithProperties() {
        final ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE, false);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        return mapper;
    }

    default void buildGatewayErrorResponse(GatewayResponseEntity gatewayResponseEntity) {
        GatewayErrorEntity gatewayErrorEntity = new GatewayErrorEntity();
        gatewayErrorEntity.setMessage(V1001_ERROR_MSG);
        gatewayErrorEntity.setCode(V1001);
        gatewayResponseEntity.setStatusCode(HttpStatus.SC_INTERNAL_SERVER_ERROR);
        gatewayResponseEntity.setError(gatewayErrorEntity);
    }
}
