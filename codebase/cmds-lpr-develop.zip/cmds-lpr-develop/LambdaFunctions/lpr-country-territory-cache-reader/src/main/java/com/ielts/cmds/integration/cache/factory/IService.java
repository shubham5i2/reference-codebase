package com.ielts.cmds.integration.cache.factory;

import com.ielts.cmds.integration.event.CountryTerritoryEvent;
import redis.clients.jedis.UnifiedJedis;

public interface IService {

    Object process(CountryTerritoryEvent countryTerritoryEvent, UnifiedJedis jedisInstance);
}