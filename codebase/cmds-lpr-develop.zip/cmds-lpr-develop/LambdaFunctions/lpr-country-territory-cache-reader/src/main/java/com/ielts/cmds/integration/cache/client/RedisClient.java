package com.ielts.cmds.integration.cache.client;

import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import redis.clients.jedis.UnifiedJedis;
import redis.clients.jedis.json.Path2;

import java.util.Objects;

@Slf4j
public class RedisClient {

    public JSONArray jsonGetFromCache(String key, String path, UnifiedJedis jedisInstance) {
        JSONArray cacheResult = (JSONArray) jedisInstance.jsonGet(key, Path2.of(path));
        if (Objects.isNull(cacheResult)) {
            log.info("CACHE MISS: Country Territory data for key: {}, and path :{}", key, path);
        }
        return cacheResult;
    }
}
