package com.ielts.cmds.integration.cache.factory;

import com.ielts.cmds.integration.cache.service.AllCountryTerritoryService;
import com.ielts.cmds.integration.cache.service.AllTerritoryUnderCountryService;

import java.util.HashMap;
import java.util.Map;

import static com.ielts.cmds.integration.cache.constants.CountryTerritoryCacheReaderConstants.GET_ALL_ACTIVE_COUNTRIES;
import static com.ielts.cmds.integration.cache.constants.CountryTerritoryCacheReaderConstants.GET_ALL_TERRITORY_COUNTRY_CODE;

public class ServiceFactory {

    private static final Map<String, IService> mapServices = new HashMap<>();

    static {
        mapServices.put(GET_ALL_ACTIVE_COUNTRIES, new AllCountryTerritoryService());
        mapServices.put(GET_ALL_TERRITORY_COUNTRY_CODE, new AllTerritoryUnderCountryService());
    }

    public IService getService(String eventIdentifier) {
        return mapServices.get(eventIdentifier);
    }
}
