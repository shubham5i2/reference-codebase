package com.ielts.cmds.integration.cache.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.ielts.cmds.api.common.country_territory_ui_client.CountryCacheV1;
import com.ielts.cmds.integration.cache.client.RedisClient;
import com.ielts.cmds.integration.cache.factory.IService;
import com.ielts.cmds.integration.event.CountryTerritoryEvent;
import com.ielts.cmds.integration.event.CountryTerritoryEventHeader;
import com.ielts.cmds.integration.response.GatewayResponseEntity;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.json.JSONArray;
import redis.clients.jedis.UnifiedJedis;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.ielts.cmds.integration.cache.constants.CountryTerritoryCacheReaderConstants.KEY_OF_ALL_COUNTRIES;
import static com.ielts.cmds.integration.cache.constants.CountryTerritoryCacheReaderConstants.INCLUDE_INACTIVE;
import static com.ielts.cmds.integration.cache.constants.CountryTerritoryCacheReaderConstants.DOLLAR;

@Slf4j
public class AllCountryTerritoryService extends RedisClient implements IService, Mapper {

    @Override
    public GatewayResponseEntity process(CountryTerritoryEvent countryTerritoryEvent, UnifiedJedis jedisInstance) {
        log.info("Inside all countries response mapping...");
        GatewayResponseEntity gatewayResponseEntity = new GatewayResponseEntity();
        try {
            gatewayResponseEntity = mapAllCountryDataResponseBody(gatewayResponseEntity, countryTerritoryEvent, jedisInstance);
        } catch (Exception exception) {
            log.error("Exception occurred ", exception);
            buildGatewayErrorResponse(gatewayResponseEntity);
        }
        return gatewayResponseEntity;
    }

    protected GatewayResponseEntity mapAllCountryDataResponseBody(final GatewayResponseEntity gateWayResponseEntity, CountryTerritoryEvent requestEvent, UnifiedJedis jedisInstance) throws JsonProcessingException {
        String includeInactiveQueryParameterValue = getQueryStringParametersFromRequest(requestEvent);
        List<CountryCacheV1> countriesList = retrieveAllCountryDataFromRedisCache(KEY_OF_ALL_COUNTRIES, includeInactiveQueryParameterValue, jedisInstance);
        if (countriesList.isEmpty()) {
            log.info("No country data found in cache");
            gateWayResponseEntity.setStatusCode(HttpStatus.SC_NOT_FOUND);
            log.info("Status code {}", HttpStatus.SC_NOT_FOUND);
        } else {
            gateWayResponseEntity.setStatusCode(HttpStatus.SC_OK);
            gateWayResponseEntity.setBody(getMapperWithProperties().writeValueAsString(countriesList));
            log.info("Status code {}", HttpStatus.SC_OK);
        }
        return gateWayResponseEntity;
    }

    public String getQueryStringParametersFromRequest(CountryTerritoryEvent requestEvent) {
        String includeInactive = "false";
        CountryTerritoryEventHeader header = requestEvent.getEventHeader();
        if (!header.getEventContext().isEmpty()) {
            Map<String, String> eventContext = header.getEventContext();
            includeInactive = eventContext.getOrDefault(INCLUDE_INACTIVE, "false");
        }
        return includeInactive;
    }

    public List<CountryCacheV1> retrieveAllCountryDataFromRedisCache(String key, String includeInactive, UnifiedJedis jedisInstance) throws JsonProcessingException {
        List<CountryCacheV1> countriesList = new ArrayList<>();
        log.debug("Key: {}", key);
        if (Objects.nonNull(key)) {
            JSONArray cacheResult = jsonGetFromCache(key, DOLLAR, jedisInstance);
            if (Objects.nonNull(cacheResult) && !cacheResult.isEmpty()) {
                countriesList = buildResponseForAllCountryDataBasedOnRequest(cacheResult, includeInactive);
            }
        }
        return countriesList;
    }

    public List<CountryCacheV1> buildResponseForAllCountryDataBasedOnRequest(JSONArray cacheResult, String includeInactive) throws JsonProcessingException {
        List<CountryCacheV1> cacheFormatData = convertTheDataToCacheFormat(cacheResult);
        List<CountryCacheV1> response;
        if (Boolean.parseBoolean(includeInactive)) {
            // When includeInactive is true, return all countries
            response = cacheFormatData;
        } else {
            // When includeInactive is false, return only active countries
            response = cacheFormatData.stream()
                    .filter(cacheData -> {
                    	LocalDate now = LocalDate.now();
                    	LocalDate effectiveFromDate = cacheData.getEffectiveFromDate();
                    	LocalDate effectiveToDate = cacheData.getEffectiveToDate();
                    	return	(effectiveFromDate != null && effectiveToDate != null) && 
                    		(now.isAfter(effectiveFromDate) || now.isEqual(effectiveFromDate)) && 
                    		now.isBefore(effectiveToDate);
                    })
                    .collect(Collectors.toList());
        }
        return response;
    }

    public List<CountryCacheV1> convertTheDataToCacheFormat(JSONArray cacheResponse) throws JsonProcessingException {
        List<CountryCacheV1> countryDataCacheV1List = new ArrayList<>();
        if (Objects.nonNull(cacheResponse)) {
            log.debug("Cache Response: {}", cacheResponse);
            log.debug("Cache Response Size: {}", cacheResponse.length());
            CollectionType typReference =
                    TypeFactory.defaultInstance()
                            .constructCollectionType(List.class, CountryCacheV1.class);
            countryDataCacheV1List = getMapperWithProperties().readValue(cacheResponse.get(0).toString(), typReference);
        }
        return countryDataCacheV1List;
    }
}
