package com.ielts.cmds.integration.cache.service;
 
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.ielts.cmds.api.common.country_territory_ui_client.TerritoryCacheV1;
import com.ielts.cmds.integration.cache.client.RedisClient;
import com.ielts.cmds.integration.cache.constants.CountryTerritoryCacheReaderConstants;
import com.ielts.cmds.integration.cache.factory.IService;
import com.ielts.cmds.integration.event.CountryTerritoryEvent;
import com.ielts.cmds.integration.event.CountryTerritoryEventHeader;
import com.ielts.cmds.integration.response.GatewayResponseEntity;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.json.JSONArray;
import redis.clients.jedis.UnifiedJedis;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
 
import static com.ielts.cmds.integration.cache.constants.CountryTerritoryCacheReaderConstants.*;
 
@Slf4j
public class AllTerritoryUnderCountryService extends RedisClient implements IService, Mapper {
 
    @Override
    public GatewayResponseEntity process(CountryTerritoryEvent requestEvent, UnifiedJedis jedisInstance) {
        log.info("Inside all territory for a country response mapping...");
        GatewayResponseEntity gatewayResponseEntity = new GatewayResponseEntity();
        try {
            mapSingleCountryTerritoryResponseBody(gatewayResponseEntity, requestEvent, jedisInstance);
        } catch (Exception exception) {
            log.error("Exception occurred ", exception);
            buildGatewayErrorResponse(gatewayResponseEntity);
        }
        return gatewayResponseEntity;
    }
 
    protected void mapSingleCountryTerritoryResponseBody(final GatewayResponseEntity gateWayResponseEntity, CountryTerritoryEvent requestEvent, UnifiedJedis jedisInstance) throws JsonProcessingException {
        String path = buildPathForFetchingSingleData(requestEvent);
        List<TerritoryCacheV1> territoryCacheV1 = retrieveSingleCountryTerritoryFromRedisCache(KEY_OF_ALL_TERRITORIES, path, jedisInstance);
        if (territoryCacheV1 == null) {
            log.info("No territory data found for this country in cache");
            gateWayResponseEntity.setStatusCode(HttpStatus.SC_NOT_FOUND);
            log.info("Status code {}", HttpStatus.SC_NOT_FOUND);
        } else {
            gateWayResponseEntity.setStatusCode(HttpStatus.SC_OK);
            gateWayResponseEntity.setBody(getMapperWithProperties().writeValueAsString(territoryCacheV1));
            log.info("Status code {}", HttpStatus.SC_OK);
        }
    }
 
    public List<TerritoryCacheV1> retrieveSingleCountryTerritoryFromRedisCache(String key, String path, UnifiedJedis jedisInstance) throws JsonProcessingException {
        List<TerritoryCacheV1> response = null;
        log.debug("Key: {}", key);
        log.debug("Path: {}", path);
        if (Objects.nonNull(key) && Objects.nonNull(path)) {
            JSONArray cacheResult = jsonGetFromCache(key, path, jedisInstance);
            log.debug("Cache Result: {}", cacheResult);
            if (Objects.nonNull(cacheResult) && !cacheResult.isEmpty()) {
                response = mapCacheResponseForAllTerritoryUnderCountry(cacheResult);
            }
        }
        return response;
    }
 
    public List<TerritoryCacheV1> mapCacheResponseForAllTerritoryUnderCountry(JSONArray cacheResponse) throws JsonProcessingException {
    	if(cacheResponse != null) {
            log.debug("Result in String: {}", cacheResponse.toString());
            CollectionType typReference =
                    TypeFactory.defaultInstance()
                            .constructCollectionType(List.class, TerritoryCacheV1.class);
            List<TerritoryCacheV1> territoryCacheV1 = getMapperWithProperties().readValue(cacheResponse.toString(), typReference);
            log.debug("Result in TerritoryUnderCountryDataCacheV1: {}", territoryCacheV1);
            return territoryCacheV1;
        } else {
            return Collections.emptyList();
        }
    }
 
    String buildPathForFetchingSingleData(CountryTerritoryEvent requestEvent) {
        CountryTerritoryEventHeader header = requestEvent.getEventHeader();
        String countryUuid;
        if (!header.getEventContext().isEmpty()
        		&& Objects.nonNull(header.getEventContext().get(CountryTerritoryCacheReaderConstants.COUNTRY_UUID))) {
            countryUuid = header.getEventContext().get(CountryTerritoryCacheReaderConstants.COUNTRY_UUID);
            return PATH_OF_COUNTRY_UUID + countryUuid + END_OF_PATH;
        }
        return null;
    }
}