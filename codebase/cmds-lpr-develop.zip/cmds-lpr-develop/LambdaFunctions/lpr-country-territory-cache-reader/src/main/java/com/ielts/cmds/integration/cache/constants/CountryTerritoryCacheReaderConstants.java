package com.ielts.cmds.integration.cache.constants;

public final class CountryTerritoryCacheReaderConstants {

    private CountryTerritoryCacheReaderConstants() {
    }

    public static final String COUNTRY_TERRITORY_CACHE_READER_LAMBDA = "CountryTerritoryCacheReader Lambda";
    public static final String UI_DOMAIN = "ui_domain";

    public static final String KEY_OF_ALL_COUNTRIES = "reference:country:all";
    public static final String KEY_OF_ALL_TERRITORIES = "reference:territory:all";

    //API Endpoints
    public static final String GET_ALL_ACTIVE_COUNTRIES = "GET/v2/countries";
    public static final String GET_ALL_TERRITORY_COUNTRY_CODE = "GET/v2/countries/{countryUuid}/territories";

    public static final String DOLLAR = "$";

    public static final String COUNTRY_UUID = "countryUuid";
    public static final String INCLUDE_INACTIVE = "includeInactive";
    public static final String PATH_OF_COUNTRY_UUID = "$.[?(@.countryUuid=='";
    public static final String END_OF_PATH = "')]";
    public static final String ACCESS_CONTROL_ALLOW_ORIGIN = "Access-Control-Allow-Origin";

    public static final String V1001 = "V1001";
    public static final String V1001_ERROR_MSG = "Country territory read operation failed due to technical failure";
}