SET CLIENT_ENCODING TO 'UTF8';
\pset format unaligned
\pset tuples_only on
\o access_arrangement_component_mapping.json
----ACCESS ARRANGMENT COMPONENT MAPPING----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', access_arrangement_component_mapping_uuid,
'accessArrangementTypeUuid',access_arrangement_type_uuid,
'deliveryMethodUuid', delivery_method_uuid,
'component',component,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date)
)))
FROM lpr_owner.access_arrangement_component_mapping;

\o access_arrangement_type.json
----ACCESS ARRANGMENT TYPE----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', access_arrangement_type_uuid,
'code',access_arrangement_code,
'name',access_arrangement_name,
'caApprovalRequired', ca_approval_required,
'modifiedMaterialRequired',modified_material_required,
'endorsementRequired',endorsement_required,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date)
)))
FROM lpr_owner.access_arrangement_type;

\o address_type.json
----ADDRESS TYPE----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', address_type_uuid,
'name', address_type_name,
'description',description,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date)
)))
FROM lpr_owner.address_type;

\o ban_reason.json
----BAN REASON----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', ban_reason_uuid,
'name',ban_description,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date)
)))
FROM lpr_owner.ban_reason;

\o check_outcome_status.json
----CHECK OUTCOME STATUS----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', check_outcome_status_uuid,
'code', check_outcome_status_code,
'name', check_outcome_status,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date)
)))
FROM lpr_owner.check_outcome_status;

\o check_outcome_type.json
----CHECK OUTCOME TYPE----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', check_outcome_type_uuid,
'code', check_outcome_type_code,
'name', check_outcome_type,
'eligibleForIntegrityCheck',eligible_for_integrity_check,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date)
)))
FROM lpr_owner.check_outcome_type;

\o contact_type.json
----CONTACT TYPE----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', contact_type_uuid,
'name', contact_type,
'description',description,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date)
)))
FROM lpr_owner.contact_type;

\o country_territory.json
----COUNTRY AND TERRITORY----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', country_uuid,
'code', country_iso3_code,
'name', country_name,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date),
'legacyReferenceId', legacy_reference,
'territories', (SELECT JSONB_AGG(JSONB_BUILD_OBJECT(
    'uuid', territory_uuid,
    'code', territory_iso_code,
    'name', territory_name,
    'effectiveToDate', DATE(effective_to_date),
    'effectiveFromDate', DATE(effective_from_date),
    'legacyReferenceId', legacy_reference
))
FROM lpr_owner.territory WHERE country_uuid=country.country_uuid)
)))
FROM lpr_owner.country;

\o education_level.json
----EDUCATION LEVEL----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', education_level_uuid,
'name', education_level,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date),
'legacyReferenceId', legacy_reference
)))
FROM lpr_owner.education_level;

\o gender.json
----GENDER----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', gender_uuid,
'code', gender_code,
'name', gender_description,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date),
'legacyReferenceId', legacy_reference
)))
FROM lpr_owner.gender;

\o identification_type.json
----IDENTIFICATION TYPE----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', identification_type_uuid,
'code', identification_type,
'name', description,
'characteristics',characteristics,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date),
'legacyReferenceId', legacy_reference
)))
FROM lpr_owner.identification_type;

\o incident_category.json
----INCIDENT CATEGORY----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', incident_category_uuid,
'code', incident_category_code,
'name', incident_category,
'eligibleForIntegrityCheck',eligible_for_integrity_check,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date)
)))
FROM lpr_owner.incident_category;

\o incident_status_type.json
----INCIDENT STATUS TYPE----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', incident_status_type_uuid,
'code', incident_status_type_code,
'name', incident_status_type,
'visibleInUi',visible_in_ui,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date)
)))
FROM lpr_owner.incident_status_type;

\o incident_type.json
----INCIDENT TYPE----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', incident_type_uuid,
'categoryUuid', incident_category_uuid,
'incident_description', incident_description,
'external_incident_category', external_incident_category,
'external_incident_type',external_incident_type,
'banReviewRequired',ban_review_required,
'externalIncidentType',external_incident_type,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date)
)))
FROM lpr_owner.incident_type;

\o language.json
----LANGUAGE----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', language_uuid,
'code', language_code,
'name', language_name,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date),
'legacyReferenceId', legacy_reference
)))
FROM lpr_owner.language;

\o mark_criteria.json
----MARK CRITERIA----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', mark_criteria_uuid,
'code', mark_criteria_code,
'name', mark_criteria,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date)
)))
FROM lpr_owner.mark_criteria;

\o module_type.json
----MODULE TYPE----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', module_type_uuid,
'code', module_type,
'name', description,
'legacyModuleType',legacy_module_type
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date)
)))
FROM lpr_owner.module_type;

\o nationality.json
----NATIONALITY----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', nationality_uuid,
'code',nationality_code,
'name', nationality_name,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date),
'legacyReferenceId', legacy_reference
)))
FROM lpr_owner.nationality;

\o note_type.json
----NOTE TYPE----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', note_type_uuid,
'name', note_type,
'description',description,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date)
)))
FROM lpr_owner.note_type;

\o occupation_level.json
----OCCUPATION LEVEL----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', occupation_level_uuid,
'name', occupation_level,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date),
'legacyReferenceId', legacy_reference
)))
FROM lpr_owner.occupation_level;

\o occupation_sector.json
----OCCUPATION SECTOR----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', occupation_sector_uuid,
'name', occupation_sector,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date),
'legacyReferenceId', legacy_reference
)))
FROM lpr_owner.occupation_sector;

\o organisation_type.json
----ORGANISATION TYPE----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', organisation_type_uuid,
'code', organisation_type,
'name', description,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date)
)))
FROM lpr_owner.organisation_type;

\o outcome_status_type.json
----OUTCOME STATUS TYPE----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', outcome_status_type_uuid,
'code', outcome_status_type_code,
'name', outcome_status_type,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date)
)))
FROM lpr_owner.outcome_status_type;

\o partner.json
-----PARTNER----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', partner_uuid,
'code', partner_code,
'name', partner_name,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date)
)))
FROM lpr_owner.partner;

\o photo_type.json
----PHOTO TYPE----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', photo_type_uuid,
'code', photo_type_code,
'name', photo_type_description,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date)
)))
FROM lpr_owner.photo_type;

\o reason_for_test.json
----REASON FOR TEST----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', reason_code_uuid,
'name', reason,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date),
'legacyReferenceId', legacy_reference
)))
FROM lpr_owner.reason_for_test;

\o results_status_type.json
----RESULTS STATUS TYPE----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', results_status_type_uuid,
'code', results_status_code,
'name', results_status,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date)
)))
FROM lpr_owner.results_status_type;

\o results_type.json
----RESULTS TYPE----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', results_type_uuid,
'code', results_type_code,
'name', results_type,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date)
)))
FROM lpr_owner.results_type;

\o sector_type.json
----SECTOR TYPE----
select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'uuid', sector_type_uuid,
'name', sector_type,
'description',description,
'effectiveToDate', DATE(effective_to_date),
'effectiveFromDate', DATE(effective_from_date)
)))
FROM lpr_owner.sector_type;