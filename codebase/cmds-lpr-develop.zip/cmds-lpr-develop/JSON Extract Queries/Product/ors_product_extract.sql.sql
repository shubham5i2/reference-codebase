SET CLIENT_ENCODING TO 'UTF8';
\pset format unaligned
\pset tuples_only on
\o product.json
(select jsonb_pretty(jsonb_agg(JSONB_BUILD_OBJECT(
'productUuid', product_uuid,
'parentProductUuid', parent_product_uuid,
'legacyProductId', legacy_product_id,
'productName', trim(product_name),
'productDescription', trim(product_description),
'moduleType', (
    SELECT JSON_BUILD_OBJECT(
		'moduleTypeUuid',module_type_uuid,
		'moduleType', module_type,
		'description', description,
		'effectiveFromDate', date(effective_from_date),
		'effectiveToDate', date(effective_to_date)
	)
    FROM lpr_owner.module_type
    WHERE module_type_uuid = product.module_type_uuid
    ),
'bookable', bookable,
'component', component,
'duration', duration,
'format', format,
'productStatus',product_status,
'productCharacteristics',product_characteristics,
'approvalRequired', approval_required,
'availableFromDate', date(available_from_date),
'availableToDate', date(available_to_date)
)))
FROM lpr_owner.product where product_status='PUBLISHED');