SET CLIENT_ENCODING TO 'UTF8';

--Function that returns true if location status is active
CREATE OR REPLACE FUNCTION lpr_owner.locationStatusFunction(location_status lpr_owner.location_status)
RETURNS BOOLEAN AS $$ 
BEGIN 
	IF (location_status = 'ACTIVE')
	THEN RETURN TRUE;
	ELSE 
	RETURN FALSE;
	END IF;
END;
$$
 LANGUAGE plpgsql;

--Function that returns location type code in Title Case
CREATE OR REPLACE FUNCTION lpr_owner.locationTypeCodeFunction(location_type_code lpr_owner.location_type)
RETURNS VARCHAR AS $$
BEGIN
	IF (location_type_code = 'GLOBAL')
	THEN RETURN 'Global';
	ELSIF (location_type_code = 'PARTNER')
	THEN RETURN 'Partner';
	ELSIF (location_type_code = 'REGION')
	THEN RETURN 'Region' ;
	ELSIF (location_type_code = 'COUNTRY')
	THEN RETURN 'Country';
	ELSIF (location_type_code = 'TEST_CENTRE')
	THEN RETURN 'Test Centre';
	ELSIF (location_type_code = 'PHYSICAL_BUILDING')
	THEN RETURN 'Physical Building';
	ELSIF (location_type_code = 'VIRTUAL_BUILDING')
	THEN RETURN 'Virtual Building';
	ELSE RETURN 'Physical Room';
	END IF;
END;
$$ LANGUAGE plpgsql;

--QUERY FOR LOCATION JSON

\pset format unaligned
\pset tuples_only on
\o location_hierarchy_json.json
SELECT jsonb_pretty(JSONB_AGG(JSONB_BUILD_OBJECT(
	'organizationalUnits', (SELECT JSONB_AGG(JSONB_BUILD_OBJECT(
'orgUnitId', location.location_uuid,
'orgUnitParentId', location.parent_location_uuid,
'orgUnitType', lpr_owner.locationTypeCodeFunction(location.location_type_code),
'orgUnitCode', location.test_centre_number,
'orgUnitName', location.location_name,
'orgUnitIsVisible', lpr_owner.locationStatusFunction(location.location_status),
'note', null ))							
FROM lpr_owner.location))));