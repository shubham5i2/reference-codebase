SET CLIENT_ENCODING TO 'UTF8';
\pset format unaligned
\pset tuples_only on
\o location_hierarchy_ors.json
(SELECT jsonb_pretty(jsonb_agg( JSONB_BUILD_OBJECT(
'locationUuid', loc.location_uuid,
'parentLocationUuid', loc.parent_location_uuid,
'locationName', loc.location_name,
'locationTypeCode', loc.location_type_code,
'locationStatus', loc.status,
'partnerCode', loc.partner_code,
'externalLocationUuid', loc.external_location_uuid,
'externalParentLocationUuid', loc.external_parent_location_uuid,
'locationStatusDatetime', timezone('UTC',loc.location_status_datetime),
'eligibleForOfflineTesting', loc.eligible_for_offline_testing,
'testCentreNumber', loc.test_centre_number,
'timezoneName', loc.timezone_name,
'websiteURL', loc.website_url,
'activatedDate', loc.activated_date,
'locationAddresses', (select JSONB_AGG(JSONB_BUILD_OBJECT(
'addressTypeUuid', loc_addr.address_type_uuid,
'territoryUuid', loc_addr.territory_uuid,
'countryIso3Code', loc_addr.country_iso3_code,
'addressLine1', loc_addr.address_line_1,
'addressLine2', loc_addr.address_line_2,
'addressLine3', loc_addr.address_line_3,
'addressLine4', loc_addr.address_line_4,
'city', loc_addr.city,
'postalCode', loc_addr.postal_code,
'email', loc_addr.email,
'primaryPhone', loc_addr.primary_phone,
'secondaryPhone', loc_addr.secondary_phone
))FROM lpr_owner.location_address loc_addr
WHERE loc_addr.location_uuid=loc.location_uuid),
'approvedProducts', (select JSONB_AGG(JSONB_BUILD_OBJECT(
'productUuid', loc_prod.product_uuid,
'effectiveFromDate', loc_prod.available_from_date,
'effectiveToDate', loc_prod.available_to_date
)) FROM lpr_owner.location_product_authorisation loc_prod
WHERE loc_prod.location_uuid=loc.location_uuid)
)))
FROM lpr_owner.location loc WHERE loc.partner_code = 'BC');