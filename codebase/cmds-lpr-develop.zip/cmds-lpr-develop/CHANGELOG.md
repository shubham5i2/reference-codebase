## [1.13.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.12.10...v1.13.0) (2024-05-20)


### ⚠ BREAKING CHANGES

* Feature/lpr008 result status changed

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!506
* feature/Adding_cache_pipeline

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!503

* Merge branch 'feature/Adding_cache_pipeline' into 'develop' ([5fe5702](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/5fe5702c23fca7e7ef256425a322e28c862ee013))
* Merge branch 'feature/lpr008-result-status-changed' into 'develop' ([d8bfbf4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/d8bfbf4e43381a652f096e98ac9a550df196a01d))

### [1.12.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.12.9...v1.12.10) (2024-05-16)


### Features

* <h2> Defect </h2> <h3> IMOD-60073 - [CUPA - SIT] Updated by field is not reflecting the user ID of the user who made the change to the product via CMDS UI </h3> <br/> <h3> IMOD-60327 - CMDS-IDP-SIT - Available To Date field of the Products table in LPR for each component (LRWS) is not updated </h3> <br/> ([d4ce056](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/d4ce056aa7d7d90eda66ecb622c0542c870bfd27))

### [1.12.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.12.8...v1.12.9) (2024-05-16)


### Features

* <h2> Defect </h2> <h3> IMOD-60073 - [CUPA - SIT] Updated by field is not reflecting the user ID of the user who made the change to the product via CMDS UI </h3> <br/> <h3> IMOD-60327 - CMDS-IDP-SIT - Available To Date field of the Products table in LPR for each component (LRWS) is not updated </h3> <br/> ([8dab35a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/8dab35a50fca00223c662256e2fc18025c037f13))
* <h2> Defect </h2> <h3> IMOD-60073 - [CUPA - SIT] Updated by field is not reflecting the user ID of the user who made the change to the product via CMDS UI </h3> <br/> <h3> IMOD-60327- CMDS-IDP-SIT - Available To Date field of the Products table in LPR for each component (LRWS) is not updated </h3> <br/> ([9ffe880](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/9ffe880c34c5f23d440b0232768381ea62652484))

### [1.12.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.12.7...v1.12.8) (2024-05-10)


### ⚠ BREAKING CHANGES

* feature/IMOD_61695_delete_test_data_location

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!497

* Merge branch 'feature/IMOD_61695_delete_test_data_location' into 'develop' ([631b107](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/631b1071012ced3387501ce75946d6e8d3446b44))

### [1.12.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.12.6...v1.12.7) (2024-05-08)


### ⚠ BREAKING CHANGES

* Feature/imod 60073 updatedby product issue fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!496

* Merge branch 'feature/IMOD-60073_updatedby_product_issue_fix' into 'develop' ([1f1eb3b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/1f1eb3bb301e5088a89392f7d6c8faa514df9e62))

### [1.12.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.12.5...v1.12.6) (2024-05-08)


### ⚠ BREAKING CHANGES

* event-adapter-java version revert

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!495

* Merge branch 'feature/ui-receiver-changes' into 'develop' ([b69412a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/b69412acc1e740e7c138461932a15d7d7daae24d))

### [1.12.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.12.4...v1.12.5) (2024-05-07)


### ⚠ BREAKING CHANGES

* feature/reduce_LPR_UI_Receiver_size

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!493

* Merge branch 'feature/reduce_LPR_UI_Receiver_size' into 'develop' ([21272a3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/21272a33fe594181cd9dcff798bbe63948d58a14))

### [1.12.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.12.3...v1.12.4) (2024-05-07)


### ⚠ BREAKING CHANGES

* Feature/imod 60073 updatedby product issue fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!492
* feature/gitlab.ci_file_changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!491

* Merge branch 'feature/gitlab.ci_file_changes' into 'develop' ([38a8d2a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/38a8d2aad914afc4f0e31e22c9196e6cd8d56742))
* Merge branch 'feature/IMOD-60073_updatedby_product_issue_fix' into 'develop' ([a40f5fc](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/a40f5fce46fa4de2b5967cf6b5ded10072834a03))

### [1.12.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.12.2...v1.12.3) (2024-05-07)


### ⚠ BREAKING CHANGES

* event-adapter release version update

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!487

* Merge branch 'feature/imod-60805-changing-to-release-version' into 'develop' ([6d44932](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/6d44932d5af9c15ae500a3c8799eb3cb817e6d5e))


### Features

* <h2> Defect  </h2> <h3> IMOD-60073 - [CUPA - SIT] Updated by field is not reflecting the user ID of the user who made the change to the product via CMDS UI</h3> <br/> ([6f3f907](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/6f3f907af3b532c8b76d27c97d004bcde4a05c95))

### [1.12.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.12.1...v1.12.2) (2024-05-07)


### Features

* <h2> Defect </h2> <h3> IMOD-60327 - CMDS-IDP-SIT - Available To Date field of the Products table in LPR for each component (LRWS) is not updated</h3> <br/> ([687d177](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/687d177939bd0195d768e5083a9689c5e63e09e3))

### [1.12.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.12.0...v1.12.1) (2024-04-24)


### ⚠ BREAKING CHANGES

* changing to bookable product

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!484

* Merge branch 'feature/update-product-data-bookable' into 'develop' ([7028060](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/7028060ffcff3c497124013fd5adb48ce7938e56))

## [1.12.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.11.0...v1.12.0) (2024-04-09)

## [1.11.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.10.7...v1.11.0) (2024-04-09)

### [1.10.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.10.6...v1.10.7) (2024-04-04)

### [1.10.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.10.5...v1.10.6) (2024-04-04)

### [1.10.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.10.4...v1.10.5) (2024-04-04)


### ⚠ BREAKING CHANGES

* logs added for reference data reader lambda

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!476

* Merge branch 'feature/cache-defect-test' into 'develop' ([46db84a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/46db84a11c414a93ff6a1d70e83472c1bd914831))

### [1.10.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.10.3...v1.10.4) (2024-04-01)


### ⚠ BREAKING CHANGES

* feature/LPR_sonar_code_smells

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!459
* adding LPR-001-CountryTerritoryCacheChanged

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!473

* Merge branch 'feature/LPR_sonar_code_smells' into 'develop' ([5e22970](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/5e22970dccb758871d43ac28bdb97297e5662926))
* Merge branch 'feature/releaase_version_for_country_territory_cache_changed' into 'develop' ([1fea95b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/1fea95b2cf7ae40ec2019d05e9da04a0e4cdc8d7))

### [1.10.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.10.2...v1.10.3) (2024-03-22)

### [1.10.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.10.1...v1.10.2) (2024-03-21)


### ⚠ BREAKING CHANGES

* IMOD-59256-update-AC-and-GT-product-characteristics

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!469

* Merge branch 'feature/IMOD-59256-AC-GT-Product-Characteristics' into 'develop' ([fabd0fb](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/fabd0fb3a5dac9ab7ffdd65fc620cfac17c87b3f))

### [1.10.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.10.0...v1.10.1) (2024-03-19)


### ⚠ BREAKING CHANGES

* feature/IMOD_48374_using_jars_in_lambdas

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!460

* Merge branch 'feature/IMOD_48374_using_jars_in_lambdas' into 'develop' ([d78576b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/d78576bd0ad99cdb8e5d04fe372586c18198affb))

## [1.10.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.9.0...v1.10.0) (2024-03-19)


### ⚠ BREAKING CHANGES

* Feature/imod 52438 ref data reader lambda

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!458

* Merge branch 'feature/IMOD-52438-Ref-Data-Reader-Lambda' into 'develop' ([bbbaf79](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/bbbaf795f9aa4a5ab133bb1dabe97c33c0b919db))

## [1.9.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.8.2...v1.9.0) (2024-03-19)

### [1.8.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.8.1...v1.8.2) (2024-02-26)


### ⚠ BREAKING CHANGES

* imod-57976-LPR-Publish-release-version

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!453

* Merge branch 'feature/imod-57976-LPR-Publish-release-version' into 'develop' ([104bfb5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/104bfb5ba3b4cf231860c5363d8e356f25e6560b))

### [1.8.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.8.0...v1.8.1) (2024-02-14)


### Features

* <h2> Business feature</h2> <h3> IMOD-57397 - Support a status of "Pending" for Physical Building entries in LPR. </h3><br/> ([cb65e7e](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/cb65e7ec0634cfb684c99c2bb411f402b649e457))

## [1.8.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.7.2...v1.8.0) (2024-02-02)

### [1.7.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.7.1...v1.7.2) (2024-01-12)

### [1.7.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.7.0...v1.7.1) (2024-01-10)


### ⚠ BREAKING CHANGES

* feature/IMOD_56922_Fixing_Error_message

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!444

* Merge branch 'feature/IMOD_56922_Fixing_Error_message' into 'develop' ([0ee0f5d](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/0ee0f5dc1690337aa8e04c11e0c4419f107284b9))


### Features

* <p>IMOD-55678		SNS	: LPR MX changes for separation of topics per business event - LocationChanged and ProductChanged</p> ([f2fe3f2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/f2fe3f27316d880d7fee810f00e2ac117179a2a8))
* Dummy MR for release notes ([7f8cfdb](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/7f8cfdbdc427199d09c6c0f5f7115a8db75d76b4))

## [1.7.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.6.1...v1.7.0) (2024-01-09)


### ⚠ BREAKING CHANGES

* Feature/IMOD-56121 defect fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!443

* Merge branch 'feature/IMOD-56121-defect-fix' into 'develop' ([e8b8ae6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/e8b8ae60c8bb3249655e7fc176a3663dc953d8e7))

### [1.6.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.6.0...v1.6.1) (2024-01-04)


### ⚠ BREAKING CHANGES

* feature/sonar_vulnerability_fix for IMOD-56294

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!441

* Merge branch 'feature/sonar_vulnerability_fix' into 'develop' ([645bee5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/645bee55108cbc4d3de2a58ab668692fb9e03672))

## [1.6.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.5.2...v1.6.0) (2024-01-03)

### [1.5.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.5.1...v1.5.2) (2023-12-20)


### ⚠ BREAKING CHANGES

* Feature/imod 56291 product read lambda refactoring

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!439

* Merge branch 'feature/IMOD-56291_product-read-lambda-refactoring' into 'develop' ([ae6293a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/ae6293a79c3a770528c3200c638cb91237de9637))

### [1.5.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.5.0...v1.5.1) (2023-12-12)

## [1.5.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.4.0...v1.5.0) (2023-12-12)


### ⚠ BREAKING CHANGES

* foregin key indexes sql script added

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!434

* Merge branch 'feature/IMOD-51975_db-performance' into 'develop' ([8ea64d2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/8ea64d239e9fc76c09a031069ed64ae227d702da))

## [1.4.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.90...v1.4.0) (2023-12-12)


### ⚠ BREAKING CHANGES

* Feature/imod 52390 move actual products data to cache

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!422

* Merge branch 'feature/IMOD-52390_move-actual-data-to-cache' into 'develop' ([a5af5fb](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/a5af5fbac355192154c8abd727be6e13b021018c))

### [1.3.90](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.89...v1.3.90) (2023-12-12)


### ⚠ BREAKING CHANGES

* Update .gitlab-ci.yml

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!436
* Product Write Lambda code

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!406

* Merge branch 'feature/IMOD-48442-WriteLambda' into 'develop' ([c3b7c4e](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/c3b7c4e0017289e0c82aae9b5ae7b6fdded554c0))
* Merge branch 'feature/semver-stage-changes' into 'develop' ([214ae0e](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/214ae0efd5e81b05be73400cff4e341dbf3cd59c))

### [1.3.89](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.88...v1.3.89) (2023-12-11)


### ⚠ BREAKING CHANGES

* Feature/imod-55678-dedicated-sns

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!435

* Merge branch 'feature/IMOD-55678-dedicated-sns' into 'develop' ([2aaebb4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/2aaebb4edff3a6890990e702d8c7061afd1b1153))

### [1.3.88](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.87...v1.3.88) (2023-12-07)

### [1.3.87](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.86...v1.3.87) (2023-11-28)


### ⚠ BREAKING CHANGES

* IMOD-53657-Outbox version upgrade for Deletion of events on successful publishing

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!431

* Merge branch 'feature/IMOD-53657-OutboxVersionUpgrade' into 'develop' ([de32006](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/de320060c5d69f0492ef7779d67b43e997f85b1b))

### [1.3.86](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.85...v1.3.86) (2023-11-28)


### ⚠ BREAKING CHANGES

* feature/IMOD_55003_And_55232_bug_fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!430

* Merge branch 'feature/IMOD_55003_And_55232_bug_fix' into 'develop' ([088a36c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/088a36cc44094581c471d241093b81d3a8fd1d69))

### [1.3.85](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.84...v1.3.85) (2023-11-28)

### [1.3.84](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.83...v1.3.84) (2023-11-27)

### [1.3.83](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.82...v1.3.83) (2023-11-23)


### ⚠ BREAKING CHANGES

* IMOD-51123-specific-sns-topics-for-business-events

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!427

* Merge branch 'feature/IMOD-51123-specific-sns-topics-for-business-events' into 'develop' ([304f655](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/304f655ecb170715c9622d412baa32f830b134fa))

### [1.3.82](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.81...v1.3.82) (2023-11-16)


### ⚠ BREAKING CHANGES

* feature/IMOD_49826_PartnerCode_validation_for_location

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!424

* Merge branch 'feature/IMOD_49826_PartnerCode_validation_for_location' into 'develop' ([4cfe84d](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/4cfe84d681d766ee968c405b27cf19a45002b9b7))

### [1.3.81](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.80...v1.3.81) (2023-10-25)


### ⚠ BREAKING CHANGES

* Feature/IMOD-53398-update-event-adapter-spring-version

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!421

* Merge branch 'feature/IMOD-53398-update-event-adapter-spring-version' into 'develop' ([22ed5f7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/22ed5f766bd499e0b38d3d73f82ac5809f682424))

### [1.3.80](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.79...v1.3.80) (2023-10-10)


### ⚠ BREAKING CHANGES

* feature/SQL-script-change

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!420

* Merge branch 'feature/SQL-script-change' into 'develop' ([6a597b8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/6a597b80ddffdbe5e1229c056d89b404b4b6f621))

### [1.3.79](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.78...v1.3.79) (2023-10-09)


### ⚠ BREAKING CHANGES

* Feature/IMOD-47804-activate-deactivate-products

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!418

* Merge branch 'feature/IMOD-47804-activate-deactivate-products' into 'develop' ([a5dd651](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/a5dd6519db9f195c37e6b0be577cee7bb56a7a4b))

### [1.3.78](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.77...v1.3.78) (2023-10-06)

### [1.3.77](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.76...v1.3.77) (2023-09-25)


### ⚠ BREAKING CHANGES

* Feature/IMOD-47793 Adding extra product attributes to /v1/products API response

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!414

* Merge branch 'feature/IMOD-47793' into 'develop' ([0a9b99f](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/0a9b99f8893bfa22c41d22412f3cd9cda4adcf5a))

### [1.3.76](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.75...v1.3.76) (2023-09-20)


### Features

* <h1>Features :</h1><h2>Business Features</h2><h3>IMOD-49089 LPR TECH: Create new Result Status Labels - 'Cancelled' and 'Manual Reset'</h3><p><strong>Purpose:</strong><br />To have result status labels reference data - Cancelled and Manual Reset </p><br /><h3>IMOD-48904 - Add New Status Type to Handle Interim Results</h3><p><strong>Purpose:</strong><br />To have new result type PENDING_EOR </p> ([44e69c2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/44e69c25e1b32b1c611d23b5f92c08a34e22115b))

### [1.3.75](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.74...v1.3.75) (2023-09-11)

### [1.3.74](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.73...v1.3.74) (2023-09-06)

### [1.3.68-hotfix.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.68-hotfix.3...v1.3.68-hotfix.4) (2023-09-05)
### [1.3.74-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.73...v1.3.74-hotfix.1) (2023-09-05)

### [1.3.73](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.72...v1.3.73) (2023-09-01)

### [1.3.72](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.71...v1.3.72) (2023-08-22)


### ⚠ BREAKING CHANGES

* Feature/49507-sonar-fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!401

* Merge branch 'feature/49507-sonar-fix' into 'develop' ([304fbc5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/304fbc54ac593ee856a2141b76a6f64b9527e6fe))

### [1.3.71](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.70...v1.3.71) (2023-08-22)


### ⚠ BREAKING CHANGES

* Fixing external api gateway related lib changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!403

* Merge branch 'feature/sandbox3-deploy' into 'develop' ([575c988](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/575c98841479460f65557a6501ce612eeb229cd7))

### [1.3.70](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.69...v1.3.70) (2023-08-11)


### ⚠ BREAKING CHANGES

* feature/IMOD-48904_Pending_EOR_result_type

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!402

* Merge branch 'feature/IMOD-48904_Pending_EOR_result_type' into 'develop' ([eb1a76f](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/eb1a76f248032867c0428e9bcc7d9405287bec7b))


### Features

* <h3>IMOD-48306-New Result Status labels Added for Rebook OSR</h3> ([3a4b4b4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/3a4b4b45a0bcbce8d45fedbf0b550d391d50878f))
* <p><b>Purpose:</b><br/>Add new Results status label to support rebook OSR</p> ([812f717](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/812f717442303f99e1994bc23bf993f1edec1d18))

### [1.3.70-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.69...v1.3.70-hotfix.1) (2023-08-08)


### Features

* <h3>IMOD-48306-New Result Status labels Added for Rebook OSR</h3> ([3a4b4b4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/3a4b4b45a0bcbce8d45fedbf0b550d391d50878f))
* <p><b>Purpose:</b><br/>Add new Results status label to support rebook OSR</p> ([812f717](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/812f717442303f99e1994bc23bf993f1edec1d18))

### [1.3.68-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.67...v1.3.68-hotfix.1) (2023-08-04)

### [1.3.68-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.67...v1.3.68-hotfix.1) (2023-08-04)

### [1.3.69](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.68...v1.3.69) (2023-08-07)


### Features

* <h1>Features :</h1><h2>Business Features</h2><h3>IMOD-42780  Remove Test Centre Admin UUID from the location management screens in LPR </h3><p><strong>Purpose:</strong><br />To remove test centre admin uuid in LPR </p><br /><h3>IMOD-42784  Remove "Request status" from the location management screens in LPR </h3><p><strong>Purpose:</strong><br />To remove request status field in LPR </p><br /><h3>IMOD-42691 Add "Other" as a territory option in LPR </h3><p><strong>Purpose:</strong><br />To add Other territory reference data in LPR </p><br /><h3>IMOD-39845 Enable read-only access to LPR Physical Building data for partner users </h3><p><strong>Purpose:</strong><br />To add read only access to locations for partner users </p><br /><h3>IMOD-36243 Enable read-only access to LPR Test Centre data for partner users </h3><p><strong>Purpose:</strong><br />To add read only access to locations for partner users </p><br /></h3><h3>IMOD-42440 [LPR] Add new AA types to LPR </h3><p><strong>Purpose:</strong><br />To add Access Arrangements reference data in LPR </p><br /><h3>IMOD-45404 Update sector categories in LPR Mx </h3><p><strong>Purpose:</strong><br />To add sector types reference data in LPR </p><br /><h3>IMOD-42786 Panda[SM-MX] - Update permission mapping for Location Management screens </h3><p><strong>Purpose:</strong><br />To update permissions in SM for location </p><br /><h3>IMOD-42782 Remove Test Centre Manager from the location table in LPR </h3><p><strong>Purpose:</strong><br />To remove test centre manager from LPR </p><br /><h3>IMOD-42787 - Remove Request Status data from existing locations in LPR </h3><p><strong>Purpose:</strong><br />To remove request status from LPR </p><br /><h3>IMOD-48872 - Panda[LPR Mx] - Create user group for Inspera Help Desk users </h3><p><strong>Purpose:</strong><br />To update user group hierarchy table data in LPR DB same in SM DB</p><br /><h3>IMOD-48846 - Panda[LPR MX] - Create user group for Inspera Development Superuser </h3><p><strong>Purpose:</strong><br />To update user group hierarchy table data in LPR DB same in SM DB</p><br /><h3>IMOD-44373 - LPR: Add new results status 'Incomplete' for Incomplete bookings </h3><p><strong>Purpose:</strong><br />To add result status reference data in LPR</p><br /><h3>IMOD-44372 - LPR: Add new results type 'Incomplete' for Incomplete bookings  </h3><p><strong>Purpose:</strong><br />To add result type reference data in LPR</p><br /><h3>IMOD-42608 - RM: Add new results status label in RM to enable resolution of results marked Absent in error  </h3><p><strong>Purpose:</strong><br />To add result status lable reference data in LPR</p><br /><h3>IMOD-44732 - Database Script Changes in SM (Description: New permission has to be added in user_group_hierarchy table for View Ban (VIEW_TT_BAN_EVENT) w.r.t [IMOD-28044] implementation and added new permissions to Business Assurance Manager and Business Assurance Admin support for View TT History (UTT_BOOKING_HISTORY_VIEW) w.r.t [IMOD-41396]) </h3><p><strong>Purpose:</strong><br />To update user group hierarchy table data in LPR DB same in SM DB</p><br /><h3>IMOD-48991 - Panda[LPR MX] - Activate UKVI IOC OSR products </h3><p><strong>Purpose:</strong><br />To activate SELT IOC OSR AC and GT products</p><br /><h3>IMOD-42789 Add a "Pending" option to the Status field for TC locations in LPR </h3><p><strong>Purpose:</strong><br />To add additional location status to test centre </p><br /><h3>IMOD-42878 Change APPROVED_DATE to ACTIVATED_DATE in LPR </h3><p><strong>Purpose:</strong><br />To rename approved date to activated date in LPR </p><br /><h2>Technical Features</h2><h3>IMOD-47301 [LPR MX] Upgrade from SNAPSHOT to Release Versions of all common CMDS libs </h3><p><strong>Purpose:</strong><br />To have latest version of artefacts  </p><br /><h2>Defects</h2><h3>IMOD-44282 - CUPA UAT - CMDS - Locations not reaching LA as CMDS sending the optional email address field as empty instead of null </h3><br /><h2>Additional Info</h2><h3>IMOD-48755 - [SIT Release V0.0.57.Green] DevOps support ticket for LPR MX </h3><p><strong>Purpose:</strong><br /> to have code release version and pipeline details </p><br /><h3>IMOD-48757 - [SIT Release v0.0.57.Green] - Smoke Test for LPR Mx </h3><p><strong>Purpose:</strong><br />To track smoke test results </p><br /> ([b74508f](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/b74508fc2f6991433ce3fccc16b5d099510f4b58))

### [1.3.68](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.67...v1.3.68) (2023-07-04)


### ⚠ BREAKING CHANGES

* IMOD_46051_deactivating_products

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!387

* Merge branch 'hotfix' into 'develop' ([2372739](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/2372739d4e206d26e4171863de36b378df960bd5))

### [1.3.68-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.67...v1.3.68-hotfix.1) (2023-06-21)

### [1.3.68-hotfix.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.68-hotfix.2...v1.3.68-hotfix.3) (2023-08-30)

### [1.3.68-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.68-hotfix.1...v1.3.68-hotfix.2) (2023-08-30)

### [1.3.68-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.67...v1.3.68-hotfix.1) (2023-08-04)

### [1.3.68-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.67...v1.3.68-hotfix.1) (2023-08-04)

### [1.3.67](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.66...v1.3.67) (2023-06-20)

### [1.3.66](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.65...v1.3.66) (2023-06-07)

### [1.3.65](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.64...v1.3.65) (2023-05-23)


### ⚠ BREAKING CHANGES

* feature/common_branch_for_pending_and_rename

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!379

* Merge branch 'feature/common_branch_for_pending_and_rename' into 'develop' ([0454824](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/0454824619c1fdad7d7abfdad8d127197641a6c3))

### [1.3.64](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.63...v1.3.64) (2023-05-17)

### [1.3.63](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.62...v1.3.63) (2023-05-10)

### [1.3.62](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.61...v1.3.62) (2023-05-09)

### [1.3.61](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.60...v1.3.61) (2023-04-25)

### [1.3.60](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.59...v1.3.60) (2023-04-13)


### ⚠ BREAKING CHANGES

* feature/IMOD_43700_and_43708_user_group_hierarchy

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!369

* Merge branch 'feature/IMOD_43700_and_43708_user_group_hierarchy' into 'develop' ([0a248a2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/0a248a2da5f97b02a04b57ec05839c9fd0fe5aba))

### [1.3.59](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.58...v1.3.59) (2023-04-10)


### ⚠ BREAKING CHANGES

* feature/IMOD_42782_and_42787_remove_TEST_CENTRE_ADMINISTRATOR_UUID_and_request_satus

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!361

* Merge branch 'feature/IMOD_42782_remove_TEST_CENTRE_ADMINISTRATOR_UUID' into 'develop' ([afa37d9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/afa37d9dd723767db56854696cafe0d9f95128bb))

### [1.3.58](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.57...v1.3.58) (2023-04-05)


### ⚠ BREAKING CHANGES

* feature/branch_for_event_serialization_of_lpr_dist_ui

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!346

* Merge branch 'feature/branch_for_event_serialization_of_lpr_dist_ui' into 'develop' ([c99ca7f](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/c99ca7fdd923610cb3a855b8d3cff78db4210583))

### [1.3.57](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.56...v1.3.57) (2023-03-29)

### [1.3.56](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.55...v1.3.56) (2023-03-24)

### [1.3.55](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.54...v1.3.55) (2023-03-15)

### [1.3.54](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.53...v1.3.54) (2023-03-13)

### [1.3.53](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.52...v1.3.53) (2023-03-10)

### [1.3.52](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.51...v1.3.52) (2023-03-08)


### ⚠ BREAKING CHANGES

* feature/IMOD_42440_New_AA_types

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!354

* Merge branch 'feature/IMOD_42440_New_AA_types' into 'develop' ([116153d](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/116153d39aa76144507e53192085bc1b85eeec2b))

### [1.3.51](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.50...v1.3.51) (2023-03-08)


### ⚠ BREAKING CHANGES

* feature/IMOD_38419_update_sector_type

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!355

* Merge branch 'feature/IMOD_38419_update_sector_type' into 'develop' ([2b31414](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/2b31414c403422cb8a302218c45b8f4c97eaf3b1))

### [1.3.50](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.49...v1.3.50) (2023-03-08)

### [1.3.49](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.48...v1.3.49) (2023-02-28)

### [1.3.48](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.47...v1.3.48) (2023-02-21)

### [1.3.47](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.46...v1.3.47) (2023-02-17)


### ⚠ BREAKING CHANGES

* Release for RM DB script changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!351
* Imod-35844 results labels and comments update

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!347

* Merge branch 'feature/create-release' into 'develop' ([a57e4ca](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/a57e4ca612d4028c68c5e42bf079d5105b419ffc))
* Merge branch 'feature/IMOD-35844-results-labels-and-comments-update' into 'develop' ([d409201](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/d409201bd9ffb2a8327b478bc608e32d19fd7562))

### [1.3.46](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.45...v1.3.46) (2023-02-08)


### ⚠ BREAKING CHANGES

* feature/IMOD_39712_IOC_China_locations

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!332

* Merge branch 'feature/IMOD_39712_IOC_China_locations' into 'develop' ([1ae5a8c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/1ae5a8cdeb74eba363782390d6a56ec56b4e20eb))

### [1.3.45](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.44...v1.3.45) (2023-02-02)

### [1.3.44](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.43...v1.3.44) (2023-02-01)


### ⚠ BREAKING CHANGES

* feature/IMOD-40797_update_yaml_files

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!344

* Merge branch 'feature/IMOD-40797_update_yaml_files' into 'develop' ([4478fe8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/4478fe8ea8302640de3f7fe7f4d79c54742e8eab))

### [1.3.43](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.42...v1.3.43) (2023-01-30)


### ⚠ BREAKING CHANGES

* Feature/imod-36242 Adding status search parameter

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!334

* Merge branch 'feature/IMOD-36242' into 'develop' ([d330cca](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/d330cca15271833795599a88652d0e4a8c3fb63f))

### [1.3.42](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.41...v1.3.42) (2023-01-23)

### [1.3.41](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.40...v1.3.41) (2023-01-20)

### [1.3.40](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.39...v1.3.40) (2023-01-20)

### [1.3.39](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.38...v1.3.39) (2023-01-19)

### [1.3.38](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.37...v1.3.38) (2023-01-11)


### ⚠ BREAKING CHANGES

* dummy changes for release creation

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!331

* Merge branch 'feature/imod-dummy' into 'develop' ([9ef4e9a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/9ef4e9aa3f93f1a7fa07bd8e912a86bf79b6996d))

### [1.3.37](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.36...v1.3.37) (2023-01-05)

### [1.3.36](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.35...v1.3.36) (2023-01-04)

### [1.3.35](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.34...v1.3.35) (2022-12-29)

### [1.3.34](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.33...v1.3.34) (2022-12-22)


### ⚠ BREAKING CHANGES

* Added LocationRejected Event in lambda-dist

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!323

* Merge branch 'feature/defect-fixes' into 'develop' ([fe7f028](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/fe7f028d1dfcd40affb9964ef7f9322449738717))

### [1.3.33](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.32...v1.3.33) (2022-12-22)

### [1.3.32](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.31...v1.3.32) (2022-12-21)

### [1.3.31](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.30...v1.3.31) (2022-12-21)

### [1.3.30](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.29...v1.3.30) (2022-12-21)

### [1.3.29](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.28...v1.3.29) (2022-12-20)

### [1.3.28](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.27...v1.3.28) (2022-12-12)

### [1.3.27](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.26...v1.3.27) (2022-12-09)

### [1.3.26](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.25...v1.3.26) (2022-12-09)

### [1.3.25](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.24...v1.3.25) (2022-12-07)

### [1.3.24](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.23...v1.3.24) (2022-12-01)

### [1.3.23](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.22...v1.3.23) (2022-11-24)

### [1.3.22](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.21...v1.3.22) (2022-11-18)


### ⚠ BREAKING CHANGES

* IMOD-38310 script to update incident types

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!305

* Merge branch 'feature/IMOD-38310_updated_incident_types' into 'develop' ([8bcfd9a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/8bcfd9a32ced6db219091b6ebadf7391f5248c60))

### [1.3.21](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.20...v1.3.21) (2022-11-17)


### ⚠ BREAKING CHANGES

* Feature/branch_for_event_changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!297

* Merge branch 'feature/branch_for_event_changes' into 'develop' ([4027945](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/40279455e9d3964637924ea261a185d0b779fb6d))

### [1.3.20](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.19...v1.3.20) (2022-11-15)


### ⚠ BREAKING CHANGES

* feature/imod_37783_insert_incident_and_checkoutcome_type_for_probable_ban_candidate

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!304

* Merge branch 'feature/imod_37783_insert_incident_and_checkoutcome_type_for_probable_ban_candidate' into 'develop' ([d541ce5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/d541ce58973862cf858391e0ec201634aa628b5d))

### [1.3.19](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.18...v1.3.19) (2022-11-08)

### [1.3.18](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.17...v1.3.18) (2022-10-27)


### ⚠ BREAKING CHANGES

* changes-to-fix-region-issue

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!298

* Merge branch 'feature/fix-region-issue' into 'develop' ([49f2bd3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/49f2bd3e2300a8f66076d70cde66933b71282dea))

### [1.3.17](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.16...v1.3.17) (2022-10-23)


### ⚠ BREAKING CHANGES

* imod_35258_updating the incident description

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!299

* Merge branch 'feature/imod35258' into 'develop' ([78d09f1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/78d09f16fdf267ea544f21ad6f03f3f543865f07))

### [1.3.16](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.15...v1.3.16) (2022-10-12)


### ⚠ BREAKING CHANGES

* IMOD-35260: deleted duplicate incident from incident_type table

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!296

* Merge branch 'feature/IMOD-35260_Duplicate_entries_in_incident' into 'develop' ([26e7090](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/26e7090c4fd2be412dfad4ec6af204b93e8c454a))

### [1.3.15](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.14...v1.3.15) (2022-10-11)

### [1.3.14](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.13...v1.3.14) (2022-10-03)


### ⚠ BREAKING CHANGES

* Feature/prod deployment

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!290

### Bug Fixes

* Data fix for IMOD-35858 adding physical building ([980e497](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/980e497a49d31bd4095e706382ce45aabf1af455))


* Merge branch 'feature/prod-deployment' into 'develop' ([c82a836](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/c82a83611d921f95222d3bfbf3fbe3be3bf098dc))


### Features

* IMOD-35830 Add IDP test centres for Adelaide, Perth and Sydney to LPR, IMOD-35858 Duplicate AU241 as AU240 in LPR ([4480e31](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/4480e31800de263eaba834ae0200553043560b7f))

### [1.3.13](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.12...v1.3.13) (2022-09-19)

### [1.3.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.11...v1.3.12) (2022-09-16)


### ⚠ BREAKING CHANGES

* feature/Incident-Type

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!280

### Bug Fixes

* IMOD-35493 CMDS-IDP-SIT: Unable to Create IOL bookings from ORS as the location is only authorized for SSR products not for IOL Product ,  IMOD-35476 BC - CMDS - SIT - When we tried to create any IOL booking from BC ORS then getting error message from CMDS ([f2d5008](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/f2d5008e54bdcda872a404ccb2fef908859cce05))


* Merge branch 'feature/Incident-Type' into 'develop' ([35b2a2f](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/35b2a2f0ff03f41d497c00c92acb75d6069e8b80))

### [1.3.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.10...v1.3.11) (2022-09-09)

### [1.3.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.9...v1.3.10) (2022-09-07)

### [1.3.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.8...v1.3.9) (2022-09-07)


### ⚠ BREAKING CHANGES

* Feature/imod 35196 insert new categories

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!275

* Merge branch 'feature/imod_35196_insert_new_categories' into 'develop' ([e6b2c73](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/e6b2c73c7c03dc863d6ce614fa09cc8b615193ab))

### [1.3.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.7...v1.3.8) (2022-08-25)


### Bug Fixes

* IMOD-33915 - Location addresses updated for TEST CENTRES and PHYSICAL BUILDINGS ([339e90f](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/339e90f0da0bde8e1aa8dd9f3be52abacedb32eb))
* IMOD-34781  - CMDS-IDP-SIT: IELTS SSR Online General Training products 'available_to_date' is showing in the future where it should be a past date ([42d3a94](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/42d3a944210cd9e767c140784b6c696c3d759d4c))

### [1.3.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.6...v1.3.7) (2022-08-23)


### ⚠ BREAKING CHANGES

* Feature/speaking incident script

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!269

* Merge branch 'feature/speaking-incident-script' into 'develop' ([3ed1664](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/3ed16644032532b8132fd579e435943924a4e426))

### [1.3.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.5...v1.3.6) (2022-08-19)

### [1.3.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.4...v1.3.5) (2022-08-18)

### [1.3.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.3...v1.3.4) (2022-08-05)

### [1.3.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.2...v1.3.3) (2022-08-03)

### [1.3.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.1...v1.3.2) (2022-07-28)


### ⚠ BREAKING CHANGES

* Minor changes for creating semver version

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!257

* Merge branch 'feature/IMOD-30397-release-version' into 'develop' ([5a8931b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/5a8931b35574fa30029b6be91aad40da3d85e3e8))

### [1.3.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.3.0...v1.3.1) (2022-07-21)

## [1.3.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.2.18...v1.3.0) (2022-07-18)

### [1.2.18](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.2.17...v1.2.18) (2022-07-12)


### ⚠ BREAKING CHANGES

* Feature/checkoutcome and incident type changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!247

* Merge branch 'feature/checkoutcome-and-incident-type-changes' into 'develop' ([a17aabb](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/a17aabb180fd75456b4f7681eedcc5df8aa9e8c9))

### [1.2.17](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.2.16...v1.2.17) (2022-07-12)


### ⚠ BREAKING CHANGES

* Feature/imod 32283 incident status and category reference data update

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!249
* Feature/adding test centre numbers

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!251

* Merge branch 'feature/adding-test-centre-numbers' into 'develop' ([86908d8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/86908d81f0f8d4f8e5d09807586137d85cf0e34d))
* Merge branch 'feature/imod-32283_incident_status_and_category_reference_data_update' into 'develop' ([1a056ad](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/1a056ad003aff5f5e5714f732a85ca5284af4380))

### [1.2.16](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.2.15...v1.2.16) (2022-07-04)


### ⚠ BREAKING CHANGES

* Feature/imod 30462 lpr script incident type

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!243

* Merge branch 'feature/IMOD-30462_lpr_script_incident_type' into 'develop' ([269ea4b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/269ea4babae6e21a88b9c824c05133e4a25bfb45))

### [1.2.15](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.2.14...v1.2.15) (2022-06-27)

### [1.2.14](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.2.13...v1.2.14) (2022-06-24)

### [1.2.13](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.2.12...v1.2.13) (2022-06-23)


### ⚠ BREAKING CHANGES

* Feature/imod-30908_selt_status_flag

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!234

* Merge branch 'feature/IMOD-30908_SELT_status_flag' into 'develop' ([5d0f648](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/5d0f648d656e9e37b42ab94f7cc6a17b0f2f0f94))

### [1.2.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.2.11...v1.2.12) (2022-06-21)

### [1.2.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.2.10...v1.2.11) (2022-06-15)

### [1.2.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.2.9...v1.2.10) (2022-06-09)

### [1.2.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.2.8...v1.2.9) (2022-06-07)

### [1.2.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.2.7...v1.2.8) (2022-05-11)


### ⚠ BREAKING CHANGES

* Feature/imod-26310_guaranteed_delivery

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!225

* Merge branch 'feature/IMOD-26310_guaranteed_delivery' into 'develop' ([f165f96](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/f165f96be559bde36b20ab0a9c98b473d124c9d7))

### [1.2.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.2.6...v1.2.7) (2022-05-09)


### ⚠ BREAKING CHANGES

* Feature/imod 26411 incident type plagiarism

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!222

* Merge branch 'feature/imod-26411-incident-type-plagiarism' into 'develop' ([312e5f4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/312e5f4dc6a1128f6cebbc3a645c377ff870ce2c))

### [1.2.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.2.5...v1.2.6) (2022-04-26)


### ⚠ BREAKING CHANGES

* Feature/sonar-coverage-changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!218

* Merge branch 'feature/sonar_coverage_changes' into 'develop' ([1e29812](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/1e2981234aeb30fa502cb48d1485c41294ff0f4e))

### [1.2.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.2.4...v1.2.5) (2022-04-11)


### ⚠ BREAKING CHANGES

* update check outcome status

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!215

* Merge branch 'feature/imod-28528_ri' into 'develop' ([b655dae](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/b655daec105bcec97dcaf530a16fd3df2ae4a208))

### [1.2.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.2.3...v1.2.4) (2022-04-05)

### [1.2.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.2.2...v1.2.3) (2022-04-01)

### [1.2.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.2.1...v1.2.2) (2022-03-25)

### [1.2.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.2.0...v1.2.1) (2022-03-25)


### ⚠ BREAKING CHANGES

* imod-27687 incident lpr data

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!209

* Merge branch 'feature/imod-27687_ri' into 'develop' ([d6636b1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/d6636b15f260df1c68ab43f08712ebf71acecaab))

## [1.2.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.1.9...v1.2.0) (2022-03-24)


### Bug Fixes

* **database:** IMOD-27564 , country, nationality and gender data added back with effective to dates in past ([14d762b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/14d762bfaefa38e7b7c757a7dea163bb442bbe5d))

### [1.1.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.1.8...v1.1.9) (2022-03-17)


### ⚠ BREAKING CHANGES

* Feature/imod 26510 lpr scripts

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr!204

* Merge branch 'feature/imod-26510_lpr_scripts' into 'develop' ([76f787b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/commit/76f787bbe8de0cec42e36d47e8fb23f67ada1131))

### [1.1.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.1.7...v1.1.8) (2022-03-13)

### [1.1.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.1.6...v1.1.7) (2022-03-13)

### [1.1.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.1.5...v1.1.6) (2022-03-11)

### [1.1.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.1.4...v1.1.5) (2022-03-11)

### [1.1.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.1.3...v1.1.4) (2022-03-11)

### [1.1.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.1.2...v1.1.3) (2022-03-10)

### [1.1.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.1.1...v1.1.2) (2022-03-10)

### [1.1.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.1.0...v1.1.1) (2022-02-28)

## [1.1.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.0.9...v1.1.0) (2022-02-21)

### [1.0.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.0.8...v1.0.9) (2021-12-31)

### [1.0.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.0.7...v1.0.8) (2021-11-25)

### [1.0.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.0.6...v1.0.7) (2021-11-16)

### [1.0.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.0.5...v1.0.6) (2021-10-26)

### [1.0.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.0.4...v1.0.5) (2021-10-11)

### [1.0.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.0.3...v1.0.4) (2021-10-07)

### [1.0.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.0.2...v1.0.3) (2021-10-07)

### [1.0.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.0.1...v1.0.2) (2021-09-24)

### [1.0.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-lpr/compare/v1.0.0...v1.0.1) (2021-08-10)

## 1.0.0 (2021-07-07)
