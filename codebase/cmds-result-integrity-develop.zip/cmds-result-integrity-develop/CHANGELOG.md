## [1.25.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.24.1...v1.25.0) (2024-05-16)


### Features

* <h2>Technical Features</h2><h3>IMOD-61780 update to latest outbox processor version</h3><p><ol><li>DevOps Ticket: IMOD-61955</li></ol> ([eac3f0c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/eac3f0cc00379779d6deed33e2132e61e21490ad))

### [1.24.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.24.0...v1.24.1) (2024-05-10)


### ⚠ BREAKING CHANGES

* IMOD-61780 update to latest outbox processor version

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!377

* Merge branch 'feature/IMOD-61780-update_outbox_library' into 'develop' ([dfe7851](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/dfe785165cad94af8af4642651e18c4cfde007b0))

## [1.24.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.23.1...v1.24.0) (2024-05-10)

### [1.20.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.20.0...v1.20.1-hotfix.1) (2024-05-03)

### [1.23.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.23.0...v1.23.1) (2024-05-06)

## [1.23.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.22.0...v1.23.0) (2024-04-30)

## [1.22.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.21.0...v1.22.0) (2024-04-12)

## [1.21.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.20.0...v1.21.0) (2024-04-09)

## [1.20.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.19.0...v1.20.0) (2024-04-03)


### ⚠ BREAKING CHANGES

* IMOD-59860 fix region from SSM  and existing UTTID from DB.

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!369

* Merge branch 'feature/IMOD-59860-Fix-region-from-SSM' into 'develop' ([d9c44b6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/d9c44b68ef283a39cf7516b59ba5687cc9fec174))

## [1.19.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.18.0...v1.19.0) (2024-03-25)


### ⚠ BREAKING CHANGES

* Feature/imod 59940 enable retry

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!367

* Merge branch 'feature/IMOD-59940-enableRetry' into 'develop' ([cbe7a90](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/cbe7a90ed8d8c82a8f8b32d9b1c3640d723aced7))

## [1.18.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.17.0...v1.18.0) (2024-03-19)

## [1.17.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.16.0...v1.17.0) (2024-02-22)

## [1.16.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.15.0...v1.16.0) (2024-02-22)

## [1.15.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.14.0...v1.15.0) (2024-02-20)


### ⚠ BREAKING CHANGES

* Feature/riRevertChanges

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!362

* Merge branch 'feature/riRevertChanges' into 'develop' ([6d46629](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/6d466291d420d8589707128e67bbdff6994c94f8))

## [1.14.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.13.0...v1.14.0) (2024-02-16)

## [1.13.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.12.0...v1.13.0) (2024-02-16)

## [1.12.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.11.0...v1.12.0) (2024-02-16)

## [1.11.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.10.0...v1.11.0) (2024-02-15)

## [1.10.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.9.0...v1.10.0) (2024-02-15)

## [1.9.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.8.0...v1.9.0) (2024-02-15)

## [1.8.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.7.0...v1.8.0) (2024-02-14)


### ⚠ BREAKING CHANGES

* Feature/eventual consistency rebased

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!351

* Merge branch 'feature/Eventual-consistency-rebased' into 'develop' ([8e63dd2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/8e63dd22f515260c15da86b74837bf10870fbcd3))

## [1.7.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.6.0...v1.7.0) (2024-01-08)

## [1.6.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.5.1...v1.6.0) (2024-01-02)

### [1.5.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.5.0...v1.5.1) (2023-12-21)

## [1.5.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.4.0...v1.5.0) (2023-12-18)

## [1.4.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.3.0...v1.4.0) (2023-12-14)

## [1.3.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.2.1...v1.3.0) (2023-12-06)

### [1.2.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.2.0...v1.2.1) (2023-11-30)

## [1.2.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.26...v1.2.0) (2023-11-28)

### [1.1.26](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.25...v1.1.26) (2023-11-16)


### ⚠ BREAKING CHANGES

* dummy change

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!333

* Merge branch 'feature/dummychange' into 'develop' ([bac6e87](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/bac6e87806d8b5c085149894448042c9d97db699))

### [1.1.17-hotfix.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.17-hotfix.9...v1.1.17-hotfix.10) (2023-11-02)


### Features

* <h2>Business Features</h2><strong>Hotfix: </strong><strong> IMOD-54498</strong><br /><p>CMDS-IDP-SIT - Malpractice - Warning Incidents are not reaching CMDS for IOL Candidates</p> ([d581e46](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/d581e4611255d2ec39a14f07eb494feeb071756c))

### [1.1.17-hotfix.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.17-hotfix.8...v1.1.17-hotfix.9) (2023-11-02)


### Features

* <h2>Business Features</h2><strong>Hotfix: </strong><strong> IMOD-51746</strong><br /><p>[CUPA-SIT-Reg] Inspera Test events are not synced with PRC DB </p> ([bb723e9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/bb723e9fe781a2c52c0c0d943e40663caeec695a))

### [1.1.17-hotfix.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.17-hotfix.7...v1.1.17-hotfix.8) (2023-10-26)


### Features

* <h2>Business Features</h2><h3>Defect Fix </h3><p><strong> IMOD-54011: Ignore ID Check outcome from Inspera for IOC Test Takers<strong/><br /><br /></p> ([99b0796](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/99b0796953793241d79b62fcc30d735aebb32846))

### [1.1.17-hotfix.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.17-hotfix.6...v1.1.17-hotfix.7) (2023-10-20)

### [1.1.17-hotfix.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.17-hotfix.5...v1.1.17-hotfix.6) (2023-10-17)

### [1.1.17-hotfix.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.17-hotfix.4...v1.1.17-hotfix.5) (2023-10-11)

### [1.1.17-hotfix.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.17-hotfix.3...v1.1.17-hotfix.4) (2023-09-12)


### Features

* <h2>Retrofit</h2><h3>IMOD-50465 Retrofit: Disable PBC check in RI</h3><p><strong>Purpose: IMOD-50465: Disable PBC check in RI to decouple PBC from v57.Pink, retrofitted to v58</strong><br /></strong><br /></p> ([80a68db](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/80a68dbbfaf4da1d6ba45e848265d9507419c756))

### [1.1.17-hotfix.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.17-hotfix.2...v1.1.17-hotfix.3) (2023-09-08)


### Features

* <h2>Hotfix</h2><h3>IMOD-50565 ,IMOD-50747 </h3><p><strong>Business Stories:</strong><br />IMOD-50565: [CUPA- SIT] Newly created BC China Test Centres are not reflecting in RI. Location table<br />IMOD-50757: CMDS-IDP-SIT - UKVI OSR (only) bookings are stuck in 'Confirmed' and Overall outcome is 'In-Progress' even though all the individual outcomes are passed </p> ([b9a3fe5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/b9a3fe5200174dc49741ee222cc3e54fe20eb48e))

### [1.1.17-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.17-hotfix.1...v1.1.17-hotfix.2) (2023-09-08)


### Features

* <h2>Hotfix</h2><h3>IMOD-50565 ,IMOD-50747 </h3><p><strong>Business Stories:</strong><br />IMOD-50565: [CUPA- SIT] Newly created BC China Test Centres are not reflecting in RI. Location table<br />IMOD-50757: CMDS-IDP-SIT - UKVI OSR (only) bookings are stuck in 'Confirmed' and Overall outcome is 'In-Progress' even though all the individual outcomes are passed </p> ([8357fa1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/8357fa150fac8e4fa95c86b0c7f4c87e4f05e1f6))

### [1.1.17-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.16...v1.1.17-hotfix.1) (2023-09-08)


### Features

* <h2>Hotfix</h2><h3>IMOD-50565 ,IMOD-50747 </h3><p><strong>Business Stories:</strong><br />IMOD-50565: [CUPA- SIT] Newly created BC China Test Centres are not reflecting in RI. Location table<br />IMOD-50757: CMDS-IDP-SIT - UKVI OSR (only) bookings are stuck in 'Confirmed' and Overall outcome is 'In-Progress' even though all the individual outcomes are passed </p> ([b53bba4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/b53bba4b6acdfe468f2fdef44109a8f2ed87b3e1))

### [1.1.25](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.24...v1.1.25) (2023-11-09)

### [1.1.24](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.23...v1.1.24) (2023-09-18)


### Features

* <h2>Defect Fix </h2><p>IMOD-49892 : Incidents are not saved in database if evidence is not accessible<br/></p> ([a76c470](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/a76c470a1ea4f8b212cfc5cc1550d626a427d7f0))

### [1.1.23](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.22...v1.1.23) (2023-09-14)


### Features

* <h2>Business Stories </h2><h3>LocalTestdate changes</h3><p>IMOD-45080 : Incident Management: Show local test date on ID Verification page<br/>IMOD-45081 : Incident Management: Show local test date on Incident Details page<br/>IMOD-45082 : Incident Management: Show local test date on Incident Search page<br/>IMOD-45083 : PRC: Show test date in local time zone on Manage PRC page (Search and Results sections)<br/></p> ([9ace4f7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/9ace4f7aa7b4d48f0ac49ed0f39c7b8210d1c26d))

### [1.1.22](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.21...v1.1.22) (2023-09-13)


### Features

* <h2>Business Story </h2><h3>IMOD-47774 :save-local-test-date-over-tt-update-changes</p> ([f86096f](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/f86096f10d15904e6e2cac63debbbcb14812b798))

### [1.1.21](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.20...v1.1.21) (2023-09-12)


### Features

* <h2>Defect fixes</h2><h3>IMOD-47698 ,IMOD-50607 </h3><p><strong>Business Stories:</strong><br />IMOD-47698: CMDS-IDP-SIT - Results stuck in Validated for an OSR Candidate as "Probable Banned Candidate Check" is not yet received in RI MX<br /><br />IMOD-50607: SYS-RI-Overall outcome Status is passed when only probable banned checkoutcome is published for the candidate</p> ([ed367b0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/ed367b01d66cf089ea6b5676f3f99afa22c766b9))

### [1.1.20](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.19...v1.1.20) (2023-09-12)


### Features

* <h2>Retrofit of the Defects</h2><h3>IMOD-50565 ,IMOD-50757 </h3><p><strong>Business Stories:</strong><br />IMOD-50565: [CUPA- SIT] Newly created BC China Test Centres are not reflecting in RI. Location table<br />IMOD-50757: CMDS-IDP-SIT - UKVI OSR (only) bookings are stuck in 'Confirmed' and Overall outcome is 'In-Progress' even though all the individual outcomes are passed <br />IMOD-50465 : CMDS -IDP- SIT |  Inflight bookings results are stuck in 'Confirmed' and Overall outcome is 'In-Progress', due to PBC outcome</p> ([8bf4c84](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/8bf4c848d277da27674de84bce11f0e4ac6aa121))

### [1.1.19](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.18...v1.1.19) (2023-08-31)


### Features

* <h2>Technical Features</h2><h3>IMOD-47698 </h3><p><strong>Business Stories:</strong><br />CMDS-IDP-SIT - Results stuck in Validated for an OSR Candidate as "Probable Banned Candidate Check" is not yet received in RI MX<br /></p> ([df31748](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/df3174863ac5901a88188982c747c78087988bfa))

### [1.1.18](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.17...v1.1.18) (2023-08-28)


### Features

* <h2>Technical Features</h2><h3>TTUpdate </h3><p><strong>Business Stories:</strong><br />CMDS-IDP-SIT - Results stuck in Validated for an OSR Candidate as "Probable Banned Candidate Check" is not yet received in RI MX<br /></p> ([cc515da](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/cc515dae570c20ec81c193ac63cad2eb530dba82))

### [1.1.17](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.16...v1.1.17) (2023-08-18)


### Features

* <h2>Technical Features</h2><h3></h3><p><strong>Business Stories:</strong><br />IMOD-49066 [RI MX] Update location name column length to 300<br /></p> ([b755588](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/b755588d60b3d624c054c88280d178fa4a337847))
* <h2>Technical Features</h2><p><strong>Business Stories:</strong><br />IMOD-47961 CMDS PRD - Result released got delay. <br /></p> ([4b1621c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/4b1621c53c78d18f92322b7772a7f77d5e1126ac))

### [1.1.16](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.15...v1.1.16) (2023-08-16)

### [1.1.15](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.14...v1.1.15) (2023-08-14)


### ⚠ BREAKING CHANGES

* IMOD-49582 fix changes retrofitted to develop

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!301

* Merge branch 'feature/IMOD-49582-retrofit_to_develop' into 'develop' ([10f0b8a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/10f0b8a91dea8cd97b480cd4092d79604aff81d4))

### [1.1.14](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.13...v1.1.14) (2023-08-10)


### Features

* <h2>Technical Features</h2><h3>TTUpdate </h3><p><strong>Purpose:</strong><br />Updating the EVT lib versions for below TTupdate stories</p><p><strong>Business Stories:</strong><br />IMOD-40317 RI Mx - Receive EVT019 with version number included.<br />IMOD-40318 RI Mx: Save booking with version number in RI.<br />IMOD-40327 RI Mx- Receive probable banned outcome for every booking version. <br />IMOD-41160 RI Mx: Receive and save ID check outcome.<br />IMOD-41670 RI Mx: Enable the ID check outcome in determining overall check outcome.<br />IMOD-40320 RI Mx: If UTTID changed, void the old PRC outcome.<br />IMOD-40328 RI Mx: Publish the latest version of overall check outcome.<br />IMOD-42825 Refactoring of Cancel and Transfer Booking services.<br />IMOD-43646 RI - Receive new PRC outcome for the new UTTID and log error if Version mismatch.<br /></p> ([6b6bb75](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/6b6bb7525dfd29908379c719d91320dd55d2d55c))

### [1.1.13](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.12...v1.1.13) (2023-08-08)


### Features

* <h2>Technical Features</h2><h3>TTUpdate </h3><p><strong>Business Stories:</strong><br />IMOD-40317 RI Mx - Receive EVT019 with version number included.<br />IMOD-40318 RI Mx: Save booking with version number in RI.<br />IMOD-40327 RI Mx- Receive probable banned outcome for every booking version. <br />IMOD-41160 RI Mx: Receive and save ID check outcome.<br />IMOD-41670 RI Mx: Enable the ID check outcome in determining overall check outcome.<br />IMOD-40320 RI Mx: If UTTID changed, void the old PRC outcome.<br />IMOD-40328 RI Mx: Publish the latest version of overall check outcome.<br />IMOD-42825 Refactoring of Cancel and Transfer Booking services.<br />IMOD-43646 RI - Receive new PRC outcome for the new UTTID and log error if Version mismatch.<br /></p> ([109027c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/109027cd139b7849183d1dc36311571fd6c96b08))

### [1.1.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.11...v1.1.12) (2023-08-08)


### ⚠ BREAKING CHANGES

* commented sandbox3 spec files

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!293

* Merge branch 'feature/imod-comment-sandbox3-spec-files' into 'develop' ([b7d04f3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/b7d04f3d2189983b8f004bbb24242280478a4698))

### [1.1.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.10...v1.1.11) (2023-08-04)


### ⚠ BREAKING CHANGES

* feature/corrected-53-version-script

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!290

* Merge branch 'feature/stage_correction' into 'develop' ([567c83e](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/567c83e05bee4429aef83f66c36072542a1f36c0))

### [1.1.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.9...v1.1.10) (2023-08-02)


### Features

* <h2>Technical Features</h2><h3>TTUpdate </h3><p><strong>Business Stories:</strong><br />IMOD-40317 RI Mx - Receive EVT019 with version number included.<br />IMOD-40318 RI Mx: Save booking with version number in RI.<br />IMOD-40327 RI Mx- Receive probable banned outcome for every booking version. <br />IMOD-41160 RI Mx: Receive and save ID check outcome.<br />IMOD-41670 RI Mx: Enable the ID check outcome in determining overall check outcome.<br />IMOD-40320 RI Mx: If UTTID changed, void the old PRC outcome.<br />IMOD-40328 RI Mx: Publish the latest version of overall check outcome.<br />IMOD-42825 Refactoring of Cancel and Transfer Booking services.<br />IMOD-43646 RI - Receive new PRC outcome for the new UTTID and log error if Version mismatch.<br /></p> ([519839c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/519839c02eff109edb383d8ceb62d462e9178489))

### [1.1.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.8...v1.1.9) (2023-08-02)


### Features

* <h2>Technical Features</h2><h3>TTUpdate </h3><p><strong>Business Stories:</strong><br />IMOD-40317 RI Mx - Receive EVT019 with version number included.<br />IMOD-40318 RI Mx: Save booking with version number in RI.<br />IMOD-40327 RI Mx- Receive probable banned outcome for every booking version.<br />IMOD-41160 RI Mx: Receive and save ID check outcome.<br />IMOD-41670 RI Mx: Enable the ID check outcome in determining overall check outcome.<br />IMOD-40320 RI Mx: If UTTID changed, void the old PRC outcome.<br />IMOD-40328 RI Mx: Publish the latest version of overall check outcome.<br />IMOD-42825 Refactoring of Cancel and Transfer Booking services.<br />IMOD-43646 RI - Receive new PRC outcome for the new UTTID and log error if Version mismatch.<br /></p> ([ea2aed0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/ea2aed06f0dd015d0d7cf87d6fce54a7da09313b))

### [1.1.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.7...v1.1.8) (2023-07-27)


### ⚠ BREAKING CHANGES

* feature/IMOD-49005_retrofit-connection-factory-version-upgraded

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!285

* Merge branch 'feature/IMOD-49005_retrofit' into 'develop' ([81a9be2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/81a9be245ff77645406ffc4fbdb4f0848b5c0eb1))

### [1.1.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.6...v1.1.7) (2023-07-27)


### Features

* <h2>Bugfix</h2><h3>IMOD-44307-duplicate-check-outcome-fix</h3><p><strong>Purpose:</strong><br /> LRW and speaking check outcomes are recorded twice in RI for each TT (IOC only). So to remove the duplicates for the checkoutcomes IMOD-44307 and Infra task IMOD-48781 were executed</p><br /></p> ([b147c63](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/b147c6319b99122720ee27ae6354f87634b725ce))

### [1.1.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.5...v1.1.6) (2023-07-25)


### Features

* <h2>Business Features</h2><h3> ([10c5078](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/10c50780f8c5921accc8c7bf88faf31bb927c667))
* <h2>Business Features</h2><h3> ([bf964ab](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/bf964ab6660b3a1e2c42119239a3b23dbacd748f))
* <h2>Business Features</h2><h3> ([4976042](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/497604243ed9eddf7303f9c25a8ffddec3417ac8))

### [1.1.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.4...v1.1.5) (2023-07-24)


### Features

* <h2>Technical Features</h2><h3>IMOD-45826 RI consumes ukvi ioc osr product data from lpr</h3><p><strong>Purpose:</strong><br />added script for updating available-to-date for ukvi ioc osr poducts</strong><br /></p> ([1472c2a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/1472c2af90f0c33734239f80dffe4a13514158ce))

### [1.1.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.3...v1.1.4) (2023-07-21)


### Features

* <h2>Technical Features</h2><h3>IMOD-45828 Updating Product Configurations for UKVI IOC OSR</h3><p><strong>Purpose:</strong><br />added config scripts in ri for ukvi ioc osr</strong><br /></p> ([fe94f82](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/fe94f82261b627d0dada04617b2c83eebc1212d1))

### [1.1.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.2...v1.1.3) (2023-07-18)


### Features

* <h2>Technical Features</h2><h3>EVT-112 Negative Flow</h3><p><strong>Purpose:</strong><br />added rejected event for evt-112</strong><br /></p> ([81a387f](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/81a387fdb8d4478385989c1d5638f4839d181813))

### [1.1.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.1...v1.1.2) (2023-07-07)


### Features

* <h2>Retrofit</h2><h3>IMOD-47871 RI MX increase of heap size to 1 GB </h3><p><strong>Purpose:</strong><br />To fix RI mx going down due to heap space issue</strong><br /></p> ([afa1619](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/afa16191288ccea887622c9e0415ded39cb46774))

### [1.1.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.1.0...v1.1.1) (2023-06-27)


### ⚠ BREAKING CHANGES

* feature/imod-45828-updating-product-config

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!245

* Merge branch 'feature/imod-45828-updating-product-config' into 'develop' ([33a243c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/33a243c208dab5258b03a832920a93cef3b578c5))

## [1.1.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.117...v1.1.0) (2023-06-12)


### Features

* <h2>Technical Features</h2><ol><li><h3>IMOD-46918 RI DB Performance Improvement : Query Statistics to compare against outbox </h3><p><strong>Purpose:</strong><br />Adding missing foreign key indexes</strong></li><br /><li><h3>IMOD-45825 RI Common Tech Items - Part II - Sprint 12.2 (Common Library change - connectionfactory lib upgrade to 0.0.18) - Both changes and Testing</h3><p><strong>Purpose:</strong><br />upgrade cmds-common-connectionfactory version to 0.0.18-SNAPSHOT</strong></li><ol><br /></p> ([e1fc8df](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/e1fc8dfc732184a01e83033ed06c2eea5c60440c))

### [1.0.117](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.116...v1.0.117) (2023-06-06)


### ⚠ BREAKING CHANGES

* feature/reverting-44907-fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!246

* Merge branch 'feature/reverting-44907-fix' into 'develop' ([e7bbfcb](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/e7bbfcbd6b9643c3e6b763bb031e5b8ca495bacf))

### [1.0.116](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.115...v1.0.116) (2023-06-05)


### ⚠ BREAKING CHANGES

* feature/evt-112-ri-mx

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!244

* Merge branch 'feature/IMOD-46848' into 'develop' ([d3b3a7e](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/d3b3a7e6a6b8361429e535377266f1a3bbc23ef3))

### [1.0.115](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.114...v1.0.115) (2023-05-29)


### ⚠ BREAKING CHANGES

* feature/resolve_retrofit_conflict

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!241

* Merge branch 'feature/resolve_retrofit_conflict' into 'develop' ([47a8d86](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/47a8d86c144def95b2ddb4ffe1a7ec1c6337ec9c))

### [1.0.114](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.113...v1.0.114) (2023-05-29)


### ⚠ BREAKING CHANGES

* feature/imod-45184-evt-112-consumption

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!228

* Merge branch 'feature/IMOD-45184-evt-112-rimx' into 'develop' ([6007db2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/6007db237ffa510efe50370d4cb93001d7b0adc6))

### [1.0.113](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.112...v1.0.113) (2023-05-29)


### ⚠ BREAKING CHANGES

* Index creations

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!238

* Merge branch 'feature/IMOD-46307_index_creation' into 'develop' ([85a53ee](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/85a53ee592855431a8a155aa38ef2879f6f88445))

### [1.0.112](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.111...v1.0.112) (2023-05-23)


### ⚠ BREAKING CHANGES

* feature/retrofit-44941-fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!235

* Merge branch 'feature/retrofit-44941-fix' into 'develop' ([6d4955e](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/6d4955e2826e7e46a325e847d858a6b2f5fbedc2))

### [1.0.111](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.110...v1.0.111) (2023-05-05)


### ⚠ BREAKING CHANGES

* feature/45192-defect-44907

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!227

* Merge branch 'feature/4512-defect-44907' into 'develop' ([93d31da](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/93d31dad7ac57438626cf65422be50b33286404f))

### [1.0.110](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.109...v1.0.110) (2023-04-26)


### ⚠ BREAKING CHANGES

* pbc_handling_on_failures

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!226

* Merge branch 'feature/pbc_handling_on_failures' into 'develop' ([d1255ac](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/d1255ac718c32f53cd7d2e7a220256fca8c1f324))

### [1.0.109](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.108...v1.0.109) (2023-04-26)


### ⚠ BREAKING CHANGES

* logger_issue

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!225

* Merge branch 'feature/logger_issue' into 'develop' ([b67d67a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/b67d67a59703de4bde70996eccaee8f3a5b171f0))

### [1.0.108](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.107...v1.0.108) (2023-04-26)


### ⚠ BREAKING CHANGES

* logger_issue

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!224

* Merge branch 'feature/logger_issue' into 'develop' ([527aa46](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/527aa4668f0e7ecbc4e1d25f6f69a65782eea8ea))

### [1.0.107](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.106...v1.0.107) (2023-04-13)


### ⚠ BREAKING CHANGES

* feature/imod-44087-defect

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!223

* Merge branch 'feature/imod-44087-defect' into 'develop' ([a51d7cb](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/a51d7cb34cc5bbd2c669931476f45e8bcd7d90f0))

### [1.0.106](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.105...v1.0.106) (2023-04-10)


### ⚠ BREAKING CHANGES

* feature/defect-fix-imod-43610

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!221

* Merge branch 'feature/defect-fix-imod-43610' into 'develop' ([bbf865f](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/bbf865fd0e61815abe58b2a3a9868dce50fab67a))

### [1.0.105](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.104...v1.0.105) (2023-04-04)


### ⚠ BREAKING CHANGES

* Fine tuned booking line outcome view to exclude SPK and LRM incident combinations

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!220

* Merge branch 'feature/IMOD-44279' into 'develop' ([b44b77e](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/b44b77e9009f3a7bfd77ff0f71eca8aad63acff1))

### [1.0.104](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.103...v1.0.104) (2023-03-08)


### ⚠ BREAKING CHANGES

* feature/imod-43262_probable_ban_event_serialization

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!214

* Merge branch 'feature/imod-43262_probable_ban_event_serialization' into 'develop' ([ff9ea29](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/ff9ea294751608fb378298873c4c18e8a6f98edb))

### [1.0.103](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.102...v1.0.103) (2023-03-06)


### ⚠ BREAKING CHANGES

* feature/defect-fix-imod-41313

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!213

* Merge branch 'feature/41313-defect-fix' into 'develop' ([a34a90c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/a34a90c047a710e31065e88159e7177f8993a17e))

### [1.0.102](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.101...v1.0.102) (2023-03-02)


### ⚠ BREAKING CHANGES

* Feature/imod 40281 event serialization

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!212

* Merge branch 'feature/IMOD-40281_event_serialization' into 'develop' ([6e09255](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/6e09255f8d42a7145838e9dc2c7ffda94f30384d))

### [1.0.101](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.100...v1.0.101) (2023-03-01)


### ⚠ BREAKING CHANGES

* feature/defect-fix-38486

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!211

* Merge branch 'feature/defect-fix-38486' into 'develop' ([4e7e642](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/4e7e642b897d869bc66054ec17fe7e0963057d93))

### [1.0.100](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.99...v1.0.100) (2023-02-20)


### ⚠ BREAKING CHANGES

* Event Serialisation changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!207

* Merge branch 'feature/IMOD-40291' into 'develop' ([7fb65b8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/7fb65b8625411e374dc6e4610969ca0ca456b3fc))

### [1.0.99](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.98...v1.0.99) (2023-02-17)


### ⚠ BREAKING CHANGES

* feature/imod-42284_null_point_exception_for_technical_and_other

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!205

* Merge branch 'feature/imod-42284_null_point_exception_for_technical_and_other' into 'develop' ([4c0a0e9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/4c0a0e9b7db045c7e0a053710a5beb7c4b1bd87f))

### [1.0.98](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.97...v1.0.98) (2023-02-13)


### ⚠ BREAKING CHANGES

* feature/IMOD-40281_booking_created_v2

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!201

* Merge branch 'feature/IMOD-40281_booking_created_v2' into 'develop' ([97c0115](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/97c011572f2264b470e36df1c489337cffefbe27))

### [1.0.97](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.96...v1.0.97) (2023-02-08)


### ⚠ BREAKING CHANGES

* feature/imod42014-lpr-event-update-ioc-china

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!202

* Merge branch 'feature/lpr-event-update' into 'develop' ([819a56b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/819a56b51e51cccff9a17edd4a49cf4bdffb5ec2))

### [1.0.96](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.95...v1.0.96) (2023-01-31)


### ⚠ BREAKING CHANGES

* feature/imod-40723_40694_40686_product_activation

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!197
* feature/imod-40723_40694_40686_product activation for IOL GT, UKVI and OSR

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!192

* Merge branch 'feature/imod-40723_40694_40686' into 'develop' ([d5f5925](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/d5f59259dae0afa4dd5640eb062a2fd7d45b00be))
* Merge branch 'feature/imod-40723_40694_40686' into 'develop' ([0e1784c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/0e1784cc829967a8bcf040a08977b341d7667530))

### [1.0.95](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.94...v1.0.95) (2023-01-30)


### ⚠ BREAKING CHANGES

* feature/imod-37782_probable_banned_candidate_event_consumption

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!171

* Merge branch 'feature/imod-37782_probable_banned_candidate_event_consumption' into 'develop' ([02ab5ad](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/02ab5ad59b7884c24467459e4aa03d34311df6b0))

### [1.0.94](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.93...v1.0.94) (2023-01-30)


### ⚠ BREAKING CHANGES

* feature/imod-40726_UKVI_IOC

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!196

* Merge branch 'feature/imod-40726_UKVI_IOC' into 'develop' ([feefc0d](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/feefc0d0048421e6d24904cc407cfb4f0dd6cf5c))

### [1.0.93](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.92...v1.0.93) (2023-01-27)


### ⚠ BREAKING CHANGES

* feature/ri_updating_staging_changes_in_yml_file

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!194

* Merge branch 'feature/ri_updating_staging_changes_in_yml_file' into 'develop' ([25a7980](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/25a7980bf3bbbe801af81a1b2d2780e0c49b4c80))

### [1.0.92](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.91...v1.0.92) (2023-01-27)


### ⚠ BREAKING CHANGES

* feature/imod36756

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!189

* Merge branch 'feature/imod36756' into 'develop' ([992d681](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/992d6816064ed6749a878a9b59a8c11704cdfdd7))

### [1.0.91](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.90...v1.0.91) (2023-01-24)


### ⚠ BREAKING CHANGES

* feature/imod-40314_event_race_condition

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!191

* Merge branch 'feature/imod-40314_event_race_condition' into 'develop' ([10ee8b7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/10ee8b7fbf0be58b2aa33c674fd8762a13c31d54))

### [1.0.90](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.89...v1.0.90) (2023-01-24)


### ⚠ BREAKING CHANGES

* feature/imod 38690 defect fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!190

* Merge branch 'feature/IMOD-38690-defect_fix' into 'develop' ([a4b457f](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/a4b457fade9c682302a7388ffdfb0de09d250028))

### [1.0.89](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.88...v1.0.89) (2023-01-11)


### ⚠ BREAKING CHANGES

* Feature/dummy

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!188

* Merge branch 'feature/dummy' into 'develop' ([07eb0d0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/07eb0d07ec7a6c39a76a3e67884db9e9d80a414e))

### [1.0.88](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.87...v1.0.88) (2022-12-28)


### ⚠ BREAKING CHANGES

* IMOD-39444: Change in docker file to point to custom java image

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!184

* Merge branch 'feature/imod-39444_update_docker_file' into 'develop' ([17175bf](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/17175bfffcebb6d73b96ae029aad50e285e9f933))

### [1.0.87](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.86...v1.0.87) (2022-12-16)


### ⚠ BREAKING CHANGES

* feature/dummy-for-retrofit-version

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!183

* Merge branch 'feature/dummy-for-retrofit-version' into 'develop' ([258547c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/258547ca8e3de621a5e1df063d331d0577da8332))

### [1.0.87-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.86...v1.0.87-hotfix.1) (2022-12-15)


### Bug Fixes

* added lrw and speaking checkoutcome test in outcome status ([672767a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/672767a5d58047d36f03d275940a3e556cf81571))

### [1.0.86](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.85...v1.0.86) (2022-12-12)


### ⚠ BREAKING CHANGES

* feature/imod-35686_reopened

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!177

* Merge branch 'feature/imod-35686_reopened' into 'develop' ([f7499a8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/f7499a83ee3ea521fb0339650774054840cfc9ce))

### [1.0.85](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.84...v1.0.85) (2022-12-05)


### ⚠ BREAKING CHANGES

* feature/imod-38689_speaking_checkoutcome_passed_issue

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!174

* Merge branch 'feature/imod-38689_speaking_checkoutcome_passed_issue' into 'develop' ([3830234](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/3830234f09912977a6c6f7123277c22536b74ef0))

### [1.0.84](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.83...v1.0.84) (2022-11-22)


### ⚠ BREAKING CHANGES

* feature/product_checkOutcome_script_deletion

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!169

* Merge branch 'feature/product_checkOutcome_script_deletion' into 'develop' ([5c0784f](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/5c0784fa54ffbfaab3463fc289ac7bb5a74ee5a1))

### [1.0.83](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.82...v1.0.83) (2022-11-21)


### ⚠ BREAKING CHANGES

* feature/cmdsCommonUtil_version_change_in_event_pom

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!168
* Hotfix changes to dev

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!166

* Merge branch 'feature/cmdsCommonUtil_version_change_in_event_pom' into 'develop' ([b8deacb](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/b8deacb7f71ab3deaa353bbbe94d5caee9df648f))
* Merge branch 'hotfix' into 'develop' ([37eb40a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/37eb40a0bd7506958619c5a964e6c1bb50439b45))

### [1.0.82](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.81...v1.0.82) (2022-11-18)


### ⚠ BREAKING CHANGES

* IMOD-38310 scripts to update incident types

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!161

* Merge branch 'feature/IMOD-38310_updated_incident_types' into 'develop' ([3e28355](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/3e283550e292f37dd750a2e4db6a7161fd14de2f))

### [1.0.81](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.80...v1.0.81) (2022-11-16)


### ⚠ BREAKING CHANGES

* feature/imod 37785 script changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!159

* Merge branch 'feature/imod_37785_script_changes' into 'develop' ([4c905af](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/4c905af4fe6aa5fd2fa51ab585ecc5aa322159fd))

### [1.0.80](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.79...v1.0.80) (2022-11-15)


### ⚠ BREAKING CHANGES

* feature/imod_37783_insert_incident_and_checkoutcome_type_for_probable_ban_candidate

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!150

* Merge branch 'feature/imod_37783_insert_incident_and_checkoutcome_type_for_probable_ban_candidate' into 'develop' ([58188f9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/58188f93fb2fd6fce7b9a6042495315a5db785a3))

### [1.0.79](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.78...v1.0.79) (2022-11-14)


### ⚠ BREAKING CHANGES

* feature/imod_37784_product_incident_mapping into develop

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!156

* Merge branch 'feature/imod_37784_product_incident_mapping' into 'develop' ([0164635](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/016463518db1ff15828bdca3136a5fa7700fa22b))

### [1.0.78](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.77...v1.0.78) (2022-11-14)


### ⚠ BREAKING CHANGES

* feature/imod 37785 product checkoutcome script

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!157

* Merge branch 'feature/imod_37785_product_checkoutcome_script' into 'develop' ([106c85a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/106c85af5af2f3a5a831bbd9c3a4c789b727779a))

### [1.0.77](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.76...v1.0.77) (2022-11-14)


### ⚠ BREAKING CHANGES

* feature/imod-37936_imod-38026

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!158

* Merge branch 'feature/imod-37936_imod-38026' into 'develop' ([e9c4adc](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/e9c4adcb03e6615e9004aacb10d34f3ed9622968))

### [1.0.76](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.75...v1.0.76) (2022-11-07)


### ⚠ BREAKING CHANGES

* feature/imod-37936_alter_booking_line_outocome_view

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!149

* Merge branch 'feature/imod-37936_alter_booking_line_outocome_view' into 'develop' ([c93cbe9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/c93cbe9b3e68977f720d1bdabcb9c4b810519bad))

### [1.0.75](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.74...v1.0.75) (2022-11-03)


### ⚠ BREAKING CHANGES

* feature/imod-37696_outcome_status_fix_for_plagiarism

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!148

* Merge branch 'feature/imod-37696_outcome_status_fix_for_plagiarism' into 'develop' ([c8dd7d0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/c8dd7d04c228abe8dbf90fe31a5fdfa0c585e735))

### [1.0.74](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.73...v1.0.74) (2022-10-25)


### ⚠ BREAKING CHANGES

* feature/imod 36976

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!147

* Merge branch 'feature/IMOD-36976' into 'develop' ([bc6c4d9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/bc6c4d9bef440f07434046fe614c325ea848f87c))

### [1.0.73](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.72...v1.0.73) (2022-10-25)


### ⚠ BREAKING CHANGES

* feature/imod-35666_CheckOutcome_Status_changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!139

* Merge branch 'feature/imod-35666_CheckOutcome_Status_changes' into 'develop' ([49172ae](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/49172ae393bd7df1523a8a9c8fb0ca44841e5a53))

### [1.0.72](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.71...v1.0.72) (2022-10-21)


### ⚠ BREAKING CHANGES

* feature/IMOD-36327-CheckoutcomeStatus

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!143

* Merge branch 'feature/IMOD-36327-CheckoutcomeStatus' into 'develop' ([2a0dc9b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/2a0dc9bbaf5d499b41ce5020021b05a140572e9f))

### [1.0.71](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.70...v1.0.71) (2022-10-21)


### ⚠ BREAKING CHANGES

* feature/imod35258_updating_incident_description

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!144

* Merge branch 'feature/imod35258_updating_incident_description' into 'develop' ([995ac77](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/995ac77972b57daff49a1b330c005610e5e85c55))

### [1.0.70](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.69...v1.0.70) (2022-10-19)


### ⚠ BREAKING CHANGES

* removed unused import for version creation

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!142

* Merge branch 'feature/36288_booking_consumed_update' into 'develop' ([d92684f](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/d92684f4a48a4aed697a1bfc948bdd3024806e1f))

### [1.0.69](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.68...v1.0.69) (2022-10-17)


### ⚠ BREAKING CHANGES

* feature/IMOD-36952-IncidentComment

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!137

* Merge branch 'feature/IMOD-36952-IncidentComment' into 'develop' ([b76f0f7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/b76f0f72efe5440d26551763c174c6e75c930922))

### [1.0.68](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.67...v1.0.68) (2022-10-14)


### ⚠ BREAKING CHANGES

* feature/IMOD-35829-Content-Type

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!134

* Merge branch 'feature/IMOD-35829-Content-Type' into 'develop' ([379198a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/379198a1a0600dd51057ba31d01803bd4738a764))

### [1.0.67](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.66...v1.0.67) (2022-10-13)


### ⚠ BREAKING CHANGES

* IMOD-35260: deleted duplicate incident from incident_type table

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!136

* Merge branch 'feature/IMOD-35260_Duplicate_entries_in_incident' into 'develop' ([fc42bd9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/fc42bd9a439822614736db84a998d76d158304e5))

### [1.0.66](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.65...v1.0.66) (2022-10-12)


### ⚠ BREAKING CHANGES

* imod36924_product_name_change update query

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!135

* Merge branch 'feature/imod36924_product_name_changes' into 'develop' ([9f1f1b6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/9f1f1b686146f37ae57107b7c135080b063ee3ea))

### [1.0.65](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.64...v1.0.65) (2022-10-11)


### ⚠ BREAKING CHANGES

* feature/imod-36677_update_product_check_outcome_configuration_to_accommodate_UKVI_product

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!133

* Merge branch 'feature/imod-36677_update_product_check_outcome_configuration_to_accommodate_UKVI_product' into 'develop' ([afd06e8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/afd06e8ee8838baa60e59bf075e28ee9eccb769d))

### [1.0.64](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.63...v1.0.64) (2022-10-11)


### ⚠ BREAKING CHANGES

* Feature/imod36634 adding ukvi data to products

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!132

* Merge branch 'feature/imod36634_Adding_UKVI_data_to_products' into 'develop' ([d60c70b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/d60c70bf47ee7f7c0a4ba32912c063fb8e42c499))

### [1.0.63](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.62...v1.0.63) (2022-10-10)


### ⚠ BREAKING CHANGES

* feature/dummy_change_for_version_genration

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!131
* Feature/comment enhancement on speaking incident

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!129

* Merge branch 'feature/comment_enhancement_on_SpeakingIncident' into 'develop' ([4a840de](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/4a840dedfbe393be2454699eefd66930eb6a3aee))
* Merge branch 'feature/dummy_change_for_version_genration' into 'develop' ([94224eb](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/94224eb7b33dc63e827c955ae5615ddeb6ab27c8))

### [1.0.62](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.61...v1.0.62) (2022-10-06)


### ⚠ BREAKING CHANGES

* feature/overall_integrity_SSR

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!130

* Merge branch 'feature/overall_integrity_SSR' into 'develop' ([64b6992](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/64b69929b2f1fa7c8769ada25c99753a94c5c5a5))

### [1.0.61](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.60...v1.0.61) (2022-09-29)


### ⚠ BREAKING CHANGES

* Imod-35687_Adding the Incident passed condition and TC

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!127

* Merge branch 'feature/imod_35687_Incident_status_for_Passed' into 'develop' ([3b96882](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/3b96882901a6d1c6699d677483dab07376edf1ee))

### [1.0.60](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.59...v1.0.60) (2022-09-29)


### ⚠ BREAKING CHANGES

* Feature/imod 30453 overall integrity for ssr

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!124

* Merge branch 'feature/imod-30453_overall_integrity_for_ssr' into 'develop' ([1ee9d0a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/1ee9d0a10673e51a567160460d9377f80a5c0086))

### [1.0.59](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.58...v1.0.59) (2022-09-27)


### ⚠ BREAKING CHANGES

* Feature/test centre changes for view and id verification

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!122
* feature/IMOD-35947

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!126

* Merge branch 'feature/IMOD-35947' into 'develop' ([17851fe](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/17851fed28bc048c990a3413ec94d9334181b6af))
* Merge branch 'feature/testCentre_changes_for_ViewAndIdVerification' into 'develop' ([b672b0f](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/b672b0f3195bf977ff451e2ddcd9ba07cab79471))

### [1.0.58](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.57...v1.0.58) (2022-09-22)


### ⚠ BREAKING CHANGES

* feature/IMOD-35531-Edit-Incident

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!119

* Merge branch 'feature/IMOD-35531-Edit-Incident' into 'develop' ([4586677](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/4586677d469616467547e08b3c69943282822a09))

### [1.0.57](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.56...v1.0.57) (2022-09-21)


### ⚠ BREAKING CHANGES

* feature/enhance_SSR_Booking

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!121

* Merge branch 'feature/enhance_SSR_Booking' into 'develop' ([52a97c8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/52a97c8b6d8b554955b89ea5a1c1cc6c847f062a))

### [1.0.57-hotfix.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.57-hotfix.2...v1.0.57-hotfix.3) (2022-11-18)

### [1.0.57-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.57-hotfix.1...v1.0.57-hotfix.2) (2022-11-17)

### [1.0.57-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.56...v1.0.57-hotfix.1) (2022-11-17)

### [1.0.56](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.55...v1.0.56) (2022-09-21)


### ⚠ BREAKING CHANGES

* feature/imod-36047_IOC_AC_script_changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!120

* Merge branch 'feature/imod-36047_IOC_AC_script_changes' into 'develop' ([784d729](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/784d729da3c7608a20aefcfc029b06e1fcb269e9))

### [1.0.55](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.54...v1.0.55) (2022-09-19)


### ⚠ BREAKING CHANGES

* imod_33718_update-testTaker-photo-category

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!117

* Merge branch 'feature/imod_33718_update_testTaker_photo_category' into 'develop' ([294d41f](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/294d41fc55fc8ab968548836fa09262241ef9f53))

### [1.0.54](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.53...v1.0.54) (2022-09-19)


### ⚠ BREAKING CHANGES

* feature/IMOD-35721-IncidentType

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!114

* Merge branch 'feature/IMOD-35721-IncidentType' into 'develop' ([70d6058](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/70d60580f020a0a83d1b33ad7d5654b215671b40))

### [1.0.53](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.52...v1.0.53) (2022-09-16)


### ⚠ BREAKING CHANGES

* deleted plagiarism type from configuration

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!116

* Merge branch 'feature/imod-35194_remove_plagiarism_for_IOC' into 'develop' ([59e6151](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/59e61518d962fc5237761a8bb0b8ffc63ec60d3c))

### [1.0.52](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.51...v1.0.52) (2022-09-15)


### ⚠ BREAKING CHANGES

* Feature/imod 35655 edit fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!115

* Merge branch 'feature/IMOD-35655_EditFix' into 'develop' ([49c35dc](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/49c35dcc4f3d2917a5b7a6cd2043883b5d06b05c))

### [1.0.51](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.50...v1.0.51) (2022-09-15)


### ⚠ BREAKING CHANGES

* Feature/search defect fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!104

* Merge branch 'feature/search_defect_fix' into 'develop' ([7c01f8b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/7c01f8b766b62bed7063491692161a9c8c4d20f4))

### [1.0.50](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.49...v1.0.50) (2022-09-15)


### ⚠ BREAKING CHANGES

* feature/SpeakingComment

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!111

* Merge branch 'feature/SpeakingComment' into 'develop' ([d63144e](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/d63144e04fb728871d1272a63d274ae4e2b81143))

### [1.0.49](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.48...v1.0.49) (2022-09-14)


### ⚠ BREAKING CHANGES

* feature/objectMapperBean_changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!110

* Merge branch 'feature/objectMapperBean_changes' into 'develop' ([063a772](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/063a772856f52d7a7e5c7319a8464aa32bddcc83))

### [1.0.48](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.47...v1.0.48) (2022-09-13)


### ⚠ BREAKING CHANGES

* feature/imod-35537_INT420_is_not_visible_in_ui

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!109

* Merge branch 'feature/imod-35537_INT420_is_not_visible_in_ui' into 'develop' ([f48c716](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/f48c7162a0c1878623a267a76a806b4bbc82f6df))

### [1.0.47](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.46...v1.0.47) (2022-09-13)


### ⚠ BREAKING CHANGES

* feature/imod-35392_incident_order_bug

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!107

* Merge branch 'feature/imod-35392_incident_order_bug' into 'develop' ([2232c84](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/2232c846f43d536be8a794efbce0e63941cf9a71))

### [1.0.46](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.45...v1.0.46) (2022-09-12)


### ⚠ BREAKING CHANGES

* IMOD_35196 Inserting the product incident mappings

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!108

* Merge branch 'feature/imod_35196_inserting_product_incident_mappings' into 'develop' ([867f746](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/867f7469aa7e4c7b1d6c0e99076e308ac9f7de25))

### [1.0.45](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.44...v1.0.45) (2022-09-08)


### ⚠ BREAKING CHANGES

* Feature/update ri with ssr product details

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!99

* Merge branch 'feature/UpdateRI_With_SSR_ProductDetails' into 'develop' ([9368831](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/9368831d1f3a21d5912700381f79793aa09a7c9a))

### [1.0.45-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.44...v1.0.45-hotfix.1) (2022-09-06)

### [1.0.44](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.43...v1.0.44) (2022-09-05)


### ⚠ BREAKING CHANGES

* Feature/imod 35196 insert new incident categories

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!102

* Merge branch 'feature/imod_35196_insert_new_incident_categories' into 'develop' ([43abd29](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/43abd2992621855802aa6912d4dd4d45118e0efe))

### [1.0.43](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.42...v1.0.43) (2022-09-05)


### ⚠ BREAKING CHANGES

* Feature/external speaking incident status enhancement

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!100

* Merge branch 'feature/ExternalSpeakingIncidentStatus_Enhancement' into 'develop' ([9012257](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/90122573a1b2e8d864cf8817b2860ccbe0abace5))

### [1.0.42](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.41...v1.0.42) (2022-09-05)


### ⚠ BREAKING CHANGES

* Feature/imod 35196 insert new categories

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!98

* Merge branch 'feature/IMOD-35196_insert_new_categories' into 'develop' ([71284a9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/71284a9dd799ec55cfcd62d40f62546e9f809c29))

### [1.0.41](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.40...v1.0.41) (2022-09-05)


### ⚠ BREAKING CHANGES

* rbac scripts

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!101

* Merge branch 'feature/IMOD-25114_rbac_scripts' into 'develop' ([2481169](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/2481169873c95ba7b068101f99499b4e331f4d5e))

### [1.0.40](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.39...v1.0.40) (2022-09-01)


### ⚠ BREAKING CHANGES

* Feature/imod 33056 consuming the updated photo published event

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!92

* Merge branch 'feature/imod-33056_consuming_the_updated_photo_published_event' into 'develop' ([62f5cda](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/62f5cdab25a1c50821bd98cc3aedbe60b9175684))

### [1.0.39](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.38...v1.0.39) (2022-08-29)


### ⚠ BREAKING CHANGES

* Feature/imod 33398 incident status update

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!93

* Merge branch 'feature/imod-33398_Incident_status_update' into 'develop' ([75328a9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/75328a9d652a21ff52d0d276addb164827ea4769))

### [1.0.38](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.37...v1.0.38) (2022-08-29)


### ⚠ BREAKING CHANGES

* Feature/imod 34789 lrw speaking severity fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!95

* Merge branch 'feature/imod-34789_lrw_speaking_severity_fix' into 'develop' ([09b95aa](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/09b95aacce76ec1826d06aeb48dd1fb7707a1bb7))

### [1.0.37](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.36...v1.0.37) (2022-08-29)


### ⚠ BREAKING CHANGES

* product checkoutcome delete script

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!97

* Merge branch 'feature/add-delete-script' into 'develop' ([983ab2c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/983ab2c1b9eedaf4671ac9b055d063e3fcc22de1))

### [1.0.36](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.35...v1.0.36) (2022-08-25)


### ⚠ BREAKING CHANGES

* Feature/product integrity changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!94

* Merge branch 'feature/product-integrity-changes' into 'develop' ([bc3d040](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/bc3d040322b374d01e093de03721ef6bfaea74fe))

### [1.0.35](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.34...v1.0.35) (2022-08-19)


### ⚠ BREAKING CHANGES

* Feature/prc evidence fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!91

* Merge branch 'feature/prc_evidence_fix' into 'develop' ([5b5bfbd](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/5b5bfbdc20cc4e4e158e9233f3a824f3dbc383f5))

### [1.0.34](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.33...v1.0.34) (2022-08-18)


### ⚠ BREAKING CHANGES

* Feature/imod 34099 lrw incident not getting saved

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!90

* Merge branch 'feature/imod-34099_LRW_incident_not_getting_saved' into 'develop' ([f3d41a6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/f3d41a6d0c20d654e733fd428f41ba2d491988e6))

### [1.0.33](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.32...v1.0.33) (2022-08-17)


### ⚠ BREAKING CHANGES

* Feature/revert product check changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!89

* Merge branch 'feature/revert-product-check-changes' into 'develop' ([cbb7e3e](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/cbb7e3ece8f52184a48b70368bcc0e4801c58156))

### [1.0.32](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.31...v1.0.32) (2022-08-15)


### ⚠ BREAKING CHANGES

* Feature/bug fix incident

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!88

* Merge branch 'feature/bug-fix-incident' into 'develop' ([4091bc1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/4091bc15cf4e6c62e69864903e7e1203775a1571))

### [1.0.31](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.30...v1.0.31) (2022-08-12)


### ⚠ BREAKING CHANGES

* Feature/speaking incident type script

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!87

* Merge branch 'feature/Speaking-incident-type-script' into 'develop' ([ca28498](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/ca28498772dc454ada8af34e038a345741b24c7f))

### [1.0.30](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.29...v1.0.30) (2022-08-12)


### ⚠ BREAKING CHANGES

* feature/Edit_And_Update_Incident

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!84

* Merge branch 'feature/Edit_And_Update_Incident' into 'develop' ([08135eb](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/08135eb07de892036b28f1c1cdaaa628249b91d5))

### [1.0.29](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.28...v1.0.29) (2022-08-11)


### ⚠ BREAKING CHANGES

* added ri outbox housekeeping code

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!72

* Merge branch 'feature/IMOD-30577_ri_outbox_housekeeping' into 'develop' ([3fc8ac6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/3fc8ac6f0d7b8e6745cc9fd1478d7c8f2d2fd992))

### [1.0.28](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.27...v1.0.28) (2022-08-11)


### ⚠ BREAKING CHANGES

* Feature/pi 9 all sprints

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!86

* Merge branch 'feature/PI_9_AllSprints' into 'develop' ([85a15cb](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/85a15cb3570275c6b90b87d3aa8e69b76e038306))

### [1.0.27](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.26...v1.0.27) (2022-08-02)


### ⚠ BREAKING CHANGES

* Feature/imod 32833 rbac scripts

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!78

* Merge branch 'feature/IMOD-32833_RBAC_scripts' into 'develop' ([814c260](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/814c260d77cef3396e0173d180ececd7fd938db7))

### [1.0.26](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.25...v1.0.26) (2022-08-01)


### ⚠ BREAKING CHANGES

* Feature/imod 33357 bug fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!80

* Merge branch 'feature/IMOD-33357_bug_fix' into 'develop' ([b331224](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/b331224365ba360445e1dfa4e9b5fe3e4fb8045e))

### [1.0.25](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.24...v1.0.25) (2022-07-20)


### ⚠ BREAKING CHANGES

* updated DB Template version

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!76

* Merge branch 'feature/IMOD-32130_db_private_runner_enablement' into 'develop' ([3ca5e8d](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/3ca5e8d15110ee642f5ba25db1d5512f42d0dcb8))

### [1.0.24](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.23...v1.0.24) (2022-07-18)


### ⚠ BREAKING CHANGES

* Feature/incident type entity changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!75

* Merge branch 'feature/IncidentTypeEntity_Changes' into 'develop' ([0dfc9c7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/0dfc9c76b38072ea5dc9cfcb00cdf4886ceacf6d))

### [1.0.23](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.22...v1.0.23) (2022-07-11)


### ⚠ BREAKING CHANGES

* Fixed script Issue

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!73

* Merge branch 'feature/IMOD-32283_SQL_script_code_changes' into 'develop' ([087c00d](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/087c00dd5c70880f169b3a991ed2232df02a5c0d))

### [1.0.22](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.21...v1.0.22) (2022-07-07)


### ⚠ BREAKING CHANGES

* feature/imod-32283_incident_status_and_category_reference_data_update

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!71

* Merge branch 'feature/IMOD-32283_incident_status_and_category_reference_data_update' into 'develop' ([363bf00](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/363bf00ded3b822de6563740a3cc203a27ef88a4))

### [1.0.21](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.20...v1.0.21) (2022-07-06)


### ⚠ BREAKING CHANGES

* incident_type scripts changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!69

* Merge branch 'feature/incident_type_checkoutcome_scipt_changes' into 'develop' ([22a997c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/22a997c70823d024d2707e648386e3d1e08aa78b))

### [1.0.20](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.19...v1.0.20) (2022-07-04)


### ⚠ BREAKING CHANGES

* Imod-30462_incident_type script

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!57

* Merge branch 'feature/IMOD-30462_incident_script' into 'develop' ([86db51f](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/86db51fd34205d130960756f503b0af87677070f))

### [1.0.19](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.18...v1.0.19) (2022-07-01)


### ⚠ BREAKING CHANGES

* Feature/imod 22869 consume photo test event

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!67

* Merge branch 'feature/IMOD-22869_consume_photo_test_event' into 'develop' ([adf3fa9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/adf3fa91d345a732c569c3a56d3a2b6b2d593d4a))

### [1.0.18](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.17...v1.0.18) (2022-06-30)


### ⚠ BREAKING CHANGES

* feature/Plagiarism_changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!68

* Merge branch 'feature/Plagiarism_Fix' into 'develop' ([d259e1b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/d259e1b8c02fa7e3b170a3c65a6cdd81157c937d))

### [1.0.17](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.16...v1.0.17) (2022-06-28)


### ⚠ BREAKING CHANGES

* Merge

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!66

* Merge branch 'feature/PI8_Merge' into 'develop' ([7b04dd2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/7b04dd2fdb25fd8137c5c601d6c6267e87c36ea0))

### [1.0.16](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.15...v1.0.16) (2022-06-22)


### ⚠ BREAKING CHANGES

* DB CI CD Implementation

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!63

* Merge branch 'feature/IMOD-31515_db_pipeline_implentation' into 'develop' ([bfcec5d](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/bfcec5d681dd871457bacf396ab5cec95c72f9d1))

### [1.0.15](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.14...v1.0.15) (2022-06-21)


### ⚠ BREAKING CHANGES

* incident-type not null script

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!58

* Merge branch 'feature/incidentType_script' into 'develop' ([3e9a13b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/3e9a13b03e6af83f632a4cb9a89090c132a39b72))

### [1.0.14](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.13...v1.0.14) (2022-06-06)


### ⚠ BREAKING CHANGES

* Feature/phoenix pi8 sprints

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!55
* revert imod 27686

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!44
* imod-26431-CD products

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!40
* imod-27687 scripts

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!36

* Merge branch 'feature/imod-25828_lpr_data' into 'develop' ([8cc8ef5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/8cc8ef5fca41f784ecd26c49d142c4bd8f175673))
* Merge branch 'feature/imod-26431' into 'develop' ([c25ea4c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/c25ea4ca6eec49ad8ff7b7dad6dc870ab96c9116))
* Merge branch 'feature/imod-27687' into 'develop' ([5824781](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/58247811a43d63dd398d7bf38aa91eeeb61d83c8))
* Merge branch 'feature/Phoenix_PI8_sprints' into 'develop' ([33d30aa](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/33d30aaeaccaa83c7f7c4cde069627cf1d2abd49))

### [1.0.13](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.12...v1.0.13) (2022-03-21)


### ⚠ BREAKING CHANGES

* Feature/phoenix 8 1

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity!30

* Merge branch 'feature/Phoenix-8-1' into 'develop' ([e69da08](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/commit/e69da08b64696c2e1aa33d168b148a54000c0ace))

### [1.0.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.11...v1.0.12) (2022-03-21)

### [1.0.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.10...v1.0.11) (2022-02-24)

### [1.0.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.9...v1.0.10) (2022-02-23)

### [1.0.10-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.9...v1.0.10-hotfix.1) (2022-02-23)

### [1.0.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.8...v1.0.9) (2022-02-21)

### [1.0.5-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.5-hotfix.1...v1.0.5-hotfix.2) (2022-02-18)

### [1.0.5-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.4...v1.0.5-hotfix.1) (2022-02-15)

### [1.0.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.7...v1.0.8) (2022-02-08)

### [1.0.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.6...v1.0.7) (2022-02-01)

### [1.0.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.5...v1.0.6) (2022-01-24)

### [1.0.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.4...v1.0.5) (2022-01-24)

### [1.0.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.3...v1.0.4) (2021-12-30)

### [1.0.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.2...v1.0.3) (2021-11-19)

### [1.0.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.1...v1.0.2) (2021-11-09)

### [1.0.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-integrity/compare/v1.0.0...v1.0.1) (2021-10-18)

## 1.0.0 (2021-09-27)

### [1.0.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-staff-management/compare/v1.0.0...v1.0.1) (2021-07-29)

## 1.0.0 (2021-07-07)
