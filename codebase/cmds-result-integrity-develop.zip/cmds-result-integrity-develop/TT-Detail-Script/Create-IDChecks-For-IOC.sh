#!/bin/bash
getHost(){
env=$2
database=$1
db_dev=${database}-db.dev.cmdsiz.com
db_sandbox=${database}-db.sandbox.cmdsiz.com
db_sandbox2=${database}-db2.sandbox.cmdsiz.com
db_sandbox3=${database}-db3.sandbox.cmdsiz.com
db_sit=${database}-db.sit.cmdsiz.com
db_sit2=${database}-db2.sit.cmdsiz.com
db_uat=${database}-db.uat.cmdsiz.com
db_perf=${database}-db.perf.cmdsiz.com
db_staging=${database}-db.staging.cmdsiz.com
db_prod=${database}-db.cmdsiz.com
db_host_key=db_$env
host=$(eval "echo \$$db_host_key")
echo "Host name is: $host"
}
environment_name=$1
source_database="booking"
target_database="ri"
getHost ${source_database} ${environment_name}
if [ "$host" == "" ]; then
  echo "Please enter correct environment name. Allowed values are sandbox, sandbox2, sandbox3, dev, sit, sit2, uat, perf, staging, prod"
  exit 1
fi
psql --host ${host} --port 5432 -U postgres -d booking <<EOF
\copy (SELECT b.booking_uuid FROM booking_owner.booking b join booking_owner.booking_release_status brs on b.booking_uuid = brs.booking_uuid where identity_verification_status = 'VERIFIED' and product_uuid in ('6d04f596-22f2-49c4-9d47-85b167b8ca6f','15d0e10b-9046-40ba-a9d5-a5fdacbdf29d','76f5c60e-4ea1-451c-89c5-8ad2adad6ea3','ae943abe-3d6b-48d3-a841-064515f13db1','d9caf654-789a-4b50-a5e3-7123c365b92d','a9610d1d-124d-4d58-8468-b921202ca1ee','7cc8a727-4671-4b5a-b0fd-60c08b3a023b','fdbacec5-e80a-4710-b3de-7d5f310b1466','6ccd6696-0660-409c-8a66-85d79c42f84d','d40d2104-a610-42dc-936b-263fb4ba120a','f0ea4e6f-d550-4687-a231-1032a7987441','43215312-a604-4cbf-8b97-c3695b03e396','cf9a05e9-2679-42da-b7d2-b34ea3e0724e','df2c8f7e-e485-441b-88a5-34b640bff6a5','4871fd4e-0c92-40be-9ca1-2707ab1b4a3f','b034eca1-0e06-4384-8ae5-e71af4d66bcb','be5f16d3-be46-4a6f-a3a5-268d5e1721cc','169ba597-2638-4ddf-b245-15f390397d9a','e1d9b3fb-d428-4342-9656-50470cde4c39','54b9d8df-c07a-4cb4-b397-adc4faa87c3f','9e8b80f8-c697-4c88-959d-4875b265b927','cb7cd48c-5e79-4a28-8104-e0bcd8e39999','6b2c8f4a-e94f-44c8-8575-22987e5aef17','bb1895b0-f302-4e4c-8bc9-07265f0eadd7','ff045df4-8c11-4bd8-b2d3-a94aa56a7877','17e0db26-7f58-40ae-b5a8-999fb68dca96','c37e2fab-898d-46d4-a61b-17f24bb29e83','74193427-ccae-4227-8577-9950c9f79d47','64ada755-5cb3-46ed-b90c-69bd88230402','4acd484a-958c-42f1-9cdd-fc5f8e12d5da','7768ff79-1c44-4b7d-818f-a935afcb9d94','de58e8e0-39c6-4c54-b62e-40cacbc6c56d','d8f6415d-c36f-4a2c-9c44-bbf0e4c65530','edd31fef-dd28-4c0a-a593-3cd3b1b74838','c3e46fcc-b54f-49ae-8675-e373db8e6dc2','fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db','42c488cc-2230-4842-b2aa-fe103f006aa7','b6e7b55e-c21e-4002-8c0b-a9f66f8bce61','a6bf0168-7ed0-49b9-959b-d526ff1087fa','e73dbfad-a961-4c7e-9fba-e196a2703bb8') and results_status_type_uuid not in ('1aef5721-71fc-434b-8e42-c2f077753826','57d416a1-57b3-4b72-b24c-d511f1749a79','c9a8aecc-b4c6-418c-84d8-1fa32e47387c','e0ae368e-2cfd-4dad-8b6e-2e0809e0ea87')) TO 'booking_extract.csv' WITH delimiter ',' csv header;
EOF
if [ ! -f "booking_extract.csv" ]; then
  echo "Extract File not created. Re-run the script with correct password"
  echo "self destructing script"
  rm -rf $0
  echo "self destruction complete"
  exit 1
fi
getHost ${target_database} ${environment_name}
echo "Enter Password for RI DB"
execution_output=$( psql --host ${host} --port 5432 -U postgres -d ri <<EOF
CREATE TEMP TABLE tmp_booking(booking_uuid uuid);
\copy tmp_booking FROM 'booking_extract.csv' WITH delimiter ',' csv header;
INSERT INTO ri_owner.check_outcome (check_outcome_uuid, check_outcome_status_uuid, check_outcome_type_uuid, booking_uuid, "comment", updated_datetime, created_datetime, concurrency_version, booking_version) select ri_owner.uuid_generate_v4(), 'a75ee32e-48f8-4062-bac7-41e34a5531ae'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, tmp_booking.booking_uuid, 'ID Check created for IOC', current_timestamp, current_timestamp, 0, null from tmp_booking ON CONFLICT(booking_uuid, check_outcome_type_uuid) DO NOTHING;
EOF
)

echo $execution_output
echo "self destructing script and extract"
rm -rf booking_extract.csv $0
echo "self destruction complete"
