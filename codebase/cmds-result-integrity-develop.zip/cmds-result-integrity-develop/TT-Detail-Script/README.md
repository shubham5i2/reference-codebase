1. Open WinScp and provide shared bastion host details (PFB) and click Login
File Protocol: SFTP
Host Name: bastion.shared.cmdsiz.com
Port: 22
Username: cognizant
Password: <PROVIDE_PASSWORD>

2. Copy the provided shell script into the remote bastion host. Provide execution rights to the copied file.

3. Go to Commands menu and then click Open in PuTTY

4. Run the script by passing the environment name. Allowed ENV_NAME in the below command are sandbox, sandbox2, sandbox3, dev, sit, sit2, uat, perf, prod. All names are case sensitive.
`sh ./Create-IDChecks-For-IOC.sh <ENV_NAME>`
For example, to run this script in sit 2, use the following command
`sh ./Create-IDChecks-For-IOC.sh sit2`

5. Now, the script prompts to provide Booking Mx postgres details (in the environment name you provided). Provide the Password

6. Then the prompt asks to provide RI Mx postgres details (in the environment name you provided). Provide the Password

7. Once the script execution is successful, UPDATE count would be displayed in the session terminal.

**Note: If there is any error in between, steps 2-7 will have to be repeated as the copied script will be deleted from the bastion host.**
