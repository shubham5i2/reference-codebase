#!/usr/bin/env sh
if [ ! -f build.gradle ]; then
    echo "maven project"
    mvn clean verify sonar:sonar
    echo "mvn end"
    ./sonar-valid.sh f2e35b69f9d53100763aa9a1463c623ed8462d0a http://ae7b7c1dc6ad211ea90a80a80ccaa951-1881914575.eu-west-2.elb.amazonaws.com target
    if [[ "$?" -ne 0 ]]; then
        echo 'could not perform tests'
        exit 1
    fi
else
    echo "Gradle project"
    gradle sonarqube
    echo "Gradle end"
    ./sonar-valid.sh f2e35b69f9d53100763aa9a1463c623ed8462d0a http://ae7b7c1dc6ad211ea90a80a80ccaa951-1881914575.eu-west-2.elb.amazonaws.com build
    if [[ "$?" -ne 0 ]]; then
        echo 'could not perform tests'
        exit 1
    fi
fi
