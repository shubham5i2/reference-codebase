package com.ielts.cmds.integration.factory;


import com.ielts.cmds.integration.constants.RIDistUiConstants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(MockitoExtension.class)
class ServiceFactoryV2Test {

    @InjectMocks private ServiceFactoryV2 serviceFactoryV2;

    @Test
    void getServiceTest() {
        assertNotNull(
                serviceFactoryV2.getService(RIDistUiConstants.ID_PHOTOS_RESPONSE_GENERATED_EVENT));
        assertNull(serviceFactoryV2.getService("SomeRandomEvent"));
    }
}

