package com.ielts.cmds.integration.mapping;

import com.amazonaws.services.apigatewaymanagementapi.AmazonApiGatewayManagementApi;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.integration.RIDistUI;
import com.ielts.cmds.integration.datasetup.SQSEventSetup;
import com.ielts.cmds.ri.common.socketresponse.BookingSearchResultV1;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class BookingSearchResponseGeneratedEventMappingTest
{
    @Spy
    private ObjectMapper objectMapper;

    @Mock
    private Context context;

    @Spy
    private RIDistUI riDist;

    @Spy
    private SQSEventSetup sqsEventSetup;

    @Spy
    private BookingSearchResponseGeneratedEventMapping bookingSearchResponseGeneratedEventMapping;

    @Spy
    private SQSEvent event;

    @Mock
    private TypeReference<BaseEvent<UiHeader>> typeRef;

    @Mock
    private AmazonApiGatewayManagementApi mockclient;

    /**
     * Sets up.
     *
     * @throws JsonProcessingException the json processing exception
     */
    @BeforeEach
    public void setUp() throws JsonProcessingException {
        objectMapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
        objectMapper.registerModule(new JavaTimeModule());
        typeRef = new TypeReference<BaseEvent<UiHeader>>() {
        };
        final HeaderContext headerContext = new HeaderContext();
        headerContext.setConnectionId("test");
        headerContext.setCorrelationId(UUID.fromString("7e664903-2413-4cf6-8f86-b1b4400d6762"));
        ThreadLocalHeaderContext.setContext(headerContext);
        event = sqsEventSetup.populateSQSEventIncidentViewResponseGenerated();
    }

    @Test
    void whenMapRequestEventBodyToResponseIsCalledThenReturnResponse() {
        BookingSearchResultV1 eventBody = sqsEventSetup.getBookingSearchResultV1ForTest();
        Object searchUserResponse = bookingSearchResponseGeneratedEventMapping.mapRequestEventBodyToResponseBody(eventBody);
        assertDoesNotThrow(() -> bookingSearchResponseGeneratedEventMapping.process(eventBody));
        assertNotNull(searchUserResponse);
    }
}
