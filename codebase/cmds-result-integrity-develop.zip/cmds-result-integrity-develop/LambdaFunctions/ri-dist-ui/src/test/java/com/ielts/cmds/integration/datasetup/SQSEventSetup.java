package com.ielts.cmds.integration.datasetup;

import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.amazonaws.services.lambda.runtime.events.SQSEvent.MessageAttribute;
import com.amazonaws.services.lambda.runtime.events.SQSEvent.SQSMessage;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JSR310Module;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.ri.common.socketresponse.BookingDetailsV1;
import com.ielts.cmds.ri.common.socketresponse.BookingIdPhotoDetailsV1;
import com.ielts.cmds.ri.common.socketresponse.BookingSearchCriteriaV1;
import com.ielts.cmds.ri.common.socketresponse.BookingSearchResultListV1;
import com.ielts.cmds.ri.common.socketresponse.BookingSearchResultListV1Inner;
import com.ielts.cmds.ri.common.socketresponse.BookingSearchResultV1;
import com.ielts.cmds.ri.common.socketresponse.BookingSearchResultV1Result;
import com.ielts.cmds.ri.common.socketresponse.CheckOutcomeV1;
import com.ielts.cmds.ri.common.socketresponse.CommentsV1;
import com.ielts.cmds.ri.common.socketresponse.IncidentEvidenceV1;
import com.ielts.cmds.ri.common.socketresponse.IncidentSearchResultDetailsV1;
import com.ielts.cmds.ri.common.socketresponse.IncidentSearchResultV1;
import com.ielts.cmds.ri.common.socketresponse.IncidentSearchResultV1Result;
import com.ielts.cmds.ri.common.socketresponse.PhotosV1;
import com.ielts.cmds.ri.common.socketresponse.ResultIntegrityIncidentDetailsV1;
import com.ielts.cmds.ri.common.socketresponse.SearchBookingRequestV1;
import com.ielts.cmds.ri.common.socketresponse.SearchIncidentRequestV1;
import com.ielts.cmds.ri.common.socketresponse.SearchPaginationV1;
import com.ielts.cmds.ri.common.socketresponse.SearchSortV1;
import com.ielts.cmds.ri.common.socketresponse.SearchSortV1Item;
import com.ielts.cmds.ri.common.socketresponse.ViewIncidentDetailsListV1;
import com.ielts.cmds.ri.common.socketresponse.ViewIncidentDetailsV1;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * The type Sqs event setup.
 */
public class SQSEventSetup {

    /**
     * The Mapper.
     */
    final ObjectMapper mapper = new ObjectMapper().registerModule(new JSR310Module());

    /**
     * Gets event request.
     *
     * @return the event request
     * @throws JsonProcessingException the json processing exception
     */
    public String getEventRequest() throws JsonProcessingException {
        final UiHeader header = populateEventHeader();
        final BookingSearchResultV1 bodyList = populateEventBody();
        final String body = mapper.writeValueAsString(bodyList);
        final BaseEventErrors errors = populateError();
        final BaseEvent<UiHeader> event = new BaseEvent<>();
        event.setEventErrors(errors);
        event.setEventHeader(header);
        event.setEventBody(body);
        return mapper.writeValueAsString(event);
    }

    /**
     * Populate event header ui header.
     *
     * @return the ui header
     */
    public UiHeader populateEventHeader() {
        final UiHeader header = new UiHeader();
        header.setConnectionId("WPl56dCALPECGwg=");
        header.setTransactionId(UUID.fromString("3e81e94b-8b6a-42b5-970c-b141f9d195a4"));
        header.setCorrelationId(UUID.fromString("123e4567-e89b-12d3-a456-426614174000"));
        header.setPartnerCode(null);
        header.setEventName("BookingSearchResponseGenerated");
        header.setEventDateTime(LocalDateTime.of(2020, Month.NOVEMBER, 23, 5, 52, 55));
        header.setEventDiscriminator("RI-UI");
        return header;
    }


    /**
     * Populate event body search result response generated event v 1.
     *
     * @return the search result response generated event v 1
     */
    public BookingSearchResultV1 populateEventBody() {
        final BookingSearchResultV1 bookingSearchResultV1 = new BookingSearchResultV1();
        final SearchBookingRequestV1 search = new SearchBookingRequestV1();
        final BookingSearchResultV1Result result = new BookingSearchResultV1Result();
        final BookingSearchCriteriaV1 criteria = new BookingSearchCriteriaV1();
        final CheckOutcomeV1 checkOutcome = new CheckOutcomeV1();

        SearchPaginationV1 searchPaginationV1 = SearchPaginationV1.builder()
                .pageNumber("12")
                .pageSize("1").build();
        SearchSortV1Item searchSortV1Item = SearchSortV1Item.builder().sortBy("ASC")
                .sortType("testSortType").build();

        SearchSortV1 searchSortV1 = new SearchSortV1();
        searchSortV1.add(searchSortV1Item);
        search.setCriteria(null);
        search.setPagination(searchPaginationV1);
        search.setSorting(searchSortV1);

        bookingSearchResultV1.setResult(result);
        bookingSearchResultV1.setSearch(search);

        return bookingSearchResultV1;
    }

    /**
     * Populate sqs event sqs event.
     *
     * @return the sqs event
     * @throws JsonProcessingException the json processing exception
     */
    public SQSEvent populateSQSEvent() throws JsonProcessingException {
        final String event = getEventRequest();
        final SQSMessage sqsMessage = new SQSMessage();
        final SQSEvent sqsEvent = new SQSEvent();
        final List<SQSMessage> records = new ArrayList<>();
        final MessageAttribute messageAttributes = new MessageAttribute();
        messageAttributes.setDataType("String");
        messageAttributes.setStringValue("3e81e94b-8b6a-42b5-970c-b141f9d195a4");
        final Map<String, MessageAttribute> messageAttributeMap = new HashMap<>();
        messageAttributeMap.put("transactionUuid", messageAttributes);
        MessageAttribute messageAttributesApp = new MessageAttribute();
        messageAttributesApp.setDataType("String");
        messageAttributesApp.setStringValue("e873fca7-849b-4e3b-8dfc-b6b5108608db");
        messageAttributeMap.put("connectionId", messageAttributesApp);
        sqsMessage.setAwsRegion("eu-west-2");
        sqsMessage.setMessageAttributes(messageAttributeMap);
        sqsMessage.setBody(event);
        records.add(sqsMessage);
        sqsEvent.setRecords(records);
        return sqsEvent;

    }

    public SQSEvent populateSQSEventPrcOutcomeReceived() throws JsonProcessingException {
        final String event = getEventRequestForRemoveUttidAssociation();
        final SQSMessage sqsMessage = new SQSMessage();
        final SQSEvent sqsEvent = new SQSEvent();
        final List<SQSMessage> records = new ArrayList<>();
        final MessageAttribute messageAttributes = new MessageAttribute();
        messageAttributes.setDataType("String");
        messageAttributes.setStringValue("3e81e94b-8b6a-42b5-970c-b141f9d195a4");
        final Map<String, MessageAttribute> messageAttributeMap = new HashMap<>();
        messageAttributeMap.put("transactionUuid", messageAttributes);
        MessageAttribute messageAttributesApp = new MessageAttribute();
        messageAttributesApp.setDataType("String");
        messageAttributesApp.setStringValue("e873fca7-849b-4e3b-8dfc-b6b5108608db");
        messageAttributeMap.put("connectionId", messageAttributesApp);
        sqsMessage.setAwsRegion("eu-west-2");
        sqsMessage.setMessageAttributes(messageAttributeMap);
        sqsMessage.setBody(event);
        records.add(sqsMessage);
        sqsEvent.setRecords(records);
        return sqsEvent;

    }

    public String getEventRequestForRemoveUttidAssociation() throws JsonProcessingException {
        final UiHeader header = populateEventHeaderPrcOutcomeReceived();
        final String body = null;
        final BaseEventErrors errors = null;
        final BaseEvent<UiHeader> event = new BaseEvent<>();
        event.setEventBody(body);
        event.setEventErrors(errors);
        event.setEventHeader(header);
        return mapper.writeValueAsString(event);
    }

    public UiHeader populateEventHeaderPrcOutcomeReceived() {
        final UiHeader header = new UiHeader();
        header.setConnectionId("WPl56dCALPECGwg=");
        header.setTransactionId(UUID.fromString("3e81e94b-8b6a-42b5-970c-b141f9d195a4"));
        header.setCorrelationId(UUID.fromString("123e4567-e89b-12d3-a456-426614174000"));
        header.setPartnerCode(null);
        header.setEventName("POST/v1/incident/submitprcoutcome");
        header.setEventDateTime(LocalDateTime.of(2020, Month.NOVEMBER, 23, 5, 52, 55));
        header.setEventDiscriminator("RI-UI");
        return header;
    }

    public SQSEvent populateSQSEventIncidentResponseGenerated() throws JsonProcessingException {
        final String event = getEventRequestForIncidentResponseGenerated();
        final SQSMessage sqsMessage = new SQSMessage();
        final SQSEvent sqsEvent = new SQSEvent();
        final List<SQSMessage> records = new ArrayList<>();
        final MessageAttribute messageAttributes = new MessageAttribute();
        messageAttributes.setDataType("String");
        messageAttributes.setStringValue("3e81e94b-8b6a-42b5-970c-b141f9d195a4");
        final Map<String, MessageAttribute> messageAttributeMap = new HashMap<>();
        messageAttributeMap.put("transactionUuid", messageAttributes);
        MessageAttribute messageAttributesApp = new MessageAttribute();
        messageAttributesApp.setDataType("String");
        messageAttributesApp.setStringValue("e873fca7-849b-4e3b-8dfc-b6b5108608db");
        messageAttributeMap.put("connectionId", messageAttributesApp);
        sqsMessage.setAwsRegion("eu-west-2");
        sqsMessage.setMessageAttributes(messageAttributeMap);
        sqsMessage.setBody(event);
        records.add(sqsMessage);
        sqsEvent.setRecords(records);
        return sqsEvent;

    }

    public String getEventRequestForIncidentResponseGenerated() throws JsonProcessingException {
        final UiHeader header = populateEventHeaderIncidentResponseGenerated();
        final IncidentSearchResultV1 bodyList = populateEventBodyForIncidentSearchResponse();
        final String body = mapper.writeValueAsString(bodyList);
        final BaseEventErrors errors = populateError();
        final BaseEvent<UiHeader> event = new BaseEvent<>();
        event.setEventHeader(header);
        event.setEventBody(body);
        event.setEventErrors(errors);
        return mapper.writeValueAsString(event);
    }

    public UiHeader populateEventHeaderIncidentResponseGenerated() {
        final UiHeader header = new UiHeader();
        header.setConnectionId("WPl56dCALPECGwg=");
        header.setTransactionId(UUID.fromString("3e81e94b-8b6a-42b5-970c-b141f9d195a4"));
        header.setCorrelationId(UUID.fromString("123e4567-e89b-12d3-a456-426614174000"));
        header.setPartnerCode(null);
        header.setEventName("IncidentSearchResponseGenerated");
        header.setEventDateTime(LocalDateTime.of(2020, Month.NOVEMBER, 23, 5, 52, 55));
        header.setEventDiscriminator("RI-UI");
        return header;
    }

    public IncidentSearchResultV1 populateEventBodyForIncidentSearchResponse() {
        final IncidentSearchResultV1 incidentSearchResultV1 = new IncidentSearchResultV1();
        final SearchIncidentRequestV1 search = new SearchIncidentRequestV1();
        final IncidentSearchResultV1Result result = new IncidentSearchResultV1Result();


        SearchPaginationV1 searchPaginationV1 = SearchPaginationV1.builder()
                .pageNumber("12")
                .pageSize("1").build();
        SearchSortV1Item searchSortV1Item = SearchSortV1Item.builder().sortBy("ASC")
                .sortType("testSortType").build();

        SearchSortV1 searchSortV1 = new SearchSortV1();
        searchSortV1.add(searchSortV1Item);
        search.setCriteria(null);
        search.setPagination(searchPaginationV1);
        search.setSorting(searchSortV1);

        incidentSearchResultV1.setResult(result);
        incidentSearchResultV1.setSearch(search);

        return incidentSearchResultV1;
    }

    private BaseEventErrors populateError() {
        List<ErrorDescription> errorDescriptionList = new ArrayList<>();
        ErrorDescription errorDescription = new ErrorDescription();
        errorDescription.setInterfaceName("interface");
        errorDescription.setErrorCode("RM001");
        errorDescription.setMessage("Error Message");
        errorDescription.setType(ErrorTypeEnum.ERROR);
        errorDescription.setSource(Source.builder()
                .path("path")
                .value("val")
                .build());
        errorDescriptionList.add(errorDescription);
        BaseEventErrors baseEvenErrors = new BaseEventErrors(errorDescriptionList);
        return baseEvenErrors;
    }


    public SQSEvent populateSQSEventViewIdPhotosResponseGenerated() throws JsonProcessingException {
        final String event = getEventRequestForViewIdPhotosResponse();
        final SQSMessage sqsMessage = new SQSMessage();
        final SQSEvent sqsEvent = new SQSEvent();
        final List<SQSMessage> records = new ArrayList<>();
        final MessageAttribute messageAttributes = new MessageAttribute();
        messageAttributes.setDataType("String");
        messageAttributes.setStringValue("3e81e94b-8b6a-42b5-970c-b141f9d195a4");
        final Map<String, MessageAttribute> messageAttributeMap = new HashMap<>();
        messageAttributeMap.put("transactionUuid", messageAttributes);
        MessageAttribute messageAttributesApp = new MessageAttribute();
        messageAttributesApp.setDataType("String");
        messageAttributesApp.setStringValue("e873fca7-849b-4e3b-8dfc-b6b5108608db");
        messageAttributeMap.put("connectionId", messageAttributesApp);
        sqsMessage.setAwsRegion("eu-west-2");
        sqsMessage.setMessageAttributes(messageAttributeMap);
        sqsMessage.setBody(event);
        records.add(sqsMessage);
        sqsEvent.setRecords(records);
        return sqsEvent;
    }

    public String getEventRequestForViewIdPhotosResponse() throws JsonProcessingException {
        final UiHeader header = populateEventHeaderViewIdPhotosResponseGenerated();
        final BookingIdPhotoDetailsV1 bodyList = populateEventBodyForViewIdPhotosResponse();
        final String body = mapper.writeValueAsString(bodyList);
        final BaseEventErrors errors = populateError();
        final BaseEvent<UiHeader> event = new BaseEvent<>();
        event.setEventErrors(errors);
        event.setEventHeader(header);
        event.setEventBody(body);
        return mapper.writeValueAsString(event);
    }

    public UiHeader populateEventHeaderViewIdPhotosResponseGenerated() {
        final UiHeader header = new UiHeader();
        header.setConnectionId("WPl56dCALPECGwg=");
        header.setTransactionId(UUID.fromString("3e81e94b-8b6a-42b5-970c-b141f9d195a4"));
        header.setCorrelationId(UUID.fromString("123e4567-e89b-12d3-a456-426614174000"));
        header.setPartnerCode(null);
        header.setEventName("IdPhotosResponseGenerated");
        header.setEventDateTime(LocalDateTime.of(2020, Month.NOVEMBER, 23, 5, 52, 55));
        header.setEventDiscriminator("RI-UI");
        return header;
    }

    public BookingIdPhotoDetailsV1 populateEventBodyForViewIdPhotosResponse() {
        final PhotosV1 photosV1 = new PhotosV1();
        return BookingIdPhotoDetailsV1
                .builder()
                .checkOutcomeStatusUuid("0b07b3ee-7c85-408f-9695-916a15f46598")
                .bookingDetails(BookingDetailsV1.builder()
                        .bookingUuid("0b07b3ee-7c85-408f-9695-916a15f46598")
                        .uniqueTestTakerUuid("0b07b3ee-7c85-408f-9695-916a15f46598")
                        .uniqueTestTakerId("uttid")
                        .shortCandidateNumber("IN001")
                        .locationUuid("0b07b3ee-7c85-408f-9695-916a15f46598")
                        .productUuid("0b07b3ee-7c85-408f-9695-916a15f46598")
                        .firstName("Joey")
                        .lastName("Chandler")
                        .testDate(LocalDate.now())
                        .identityNumber("IN001")
                        .build())
                .photos(photosV1)
                .build();
    }

    public SQSEvent populateSQSEventCheckOutcomeUpdate() throws JsonProcessingException {
        final String event = getEventRequestForCheckOutcome();
        final SQSMessage sqsMessage = new SQSMessage();
        final SQSEvent sqsEvent = new SQSEvent();
        final List<SQSMessage> records = new ArrayList<>();
        final MessageAttribute messageAttributes = new MessageAttribute();
        messageAttributes.setDataType("String");
        messageAttributes.setStringValue("3e81e94b-8b6a-42b5-970c-b141f9d195a4");
        final Map<String, MessageAttribute> messageAttributeMap = new HashMap<>();
        messageAttributeMap.put("transactionUuid", messageAttributes);
        MessageAttribute messageAttributesApp = new MessageAttribute();
        messageAttributesApp.setDataType("String");
        messageAttributesApp.setStringValue("e873fca7-849b-4e3b-8dfc-b6b5108608db");
        messageAttributeMap.put("connectionId", messageAttributesApp);
        sqsMessage.setAwsRegion("eu-west-2");
        sqsMessage.setMessageAttributes(messageAttributeMap);
        sqsMessage.setBody(event);
        records.add(sqsMessage);
        sqsEvent.setRecords(records);

        return sqsEvent;
    }

    public String getEventRequestForCheckOutcome() throws JsonProcessingException {
        final UiHeader header = populateEventHeaderCheckOutcome();
        final String eventBody = "Success";
        final BaseEventErrors errors = null;
        final BaseEvent<UiHeader> event = new BaseEvent<>();
        event.setEventBody(eventBody);
        event.setEventErrors(errors);
        event.setEventHeader(header);
        return mapper.writeValueAsString(event);
    }

    public UiHeader populateEventHeaderCheckOutcome() {
        final UiHeader header = new UiHeader();
        header.setConnectionId("WPl56dCALPECGwg=");
        header.setTransactionId(UUID.fromString("3e81e94b-8b6a-42b5-970c-b141f9d195a4"));
        header.setCorrelationId(UUID.fromString("123e4567-e89b-12d3-a456-426614174000"));
        header.setPartnerCode(null);
        header.setEventName("PUT/v1/incident/submitidcheckoutcome");
        header.setEventDateTime(LocalDateTime.of(2020, Month.NOVEMBER, 23, 5, 52, 55));
        header.setEventDiscriminator("RI-UI");
        return header;
    }

    public SQSEvent populateSQSEventCheckOutcomeUpdateWithNull() throws JsonProcessingException {
        final String event = getEventRequestForCheckOutcomeWithNull();
        final SQSMessage sqsMessage = new SQSMessage();
        final SQSEvent sqsEvent = new SQSEvent();
        final List<SQSMessage> records = new ArrayList<>();
        final MessageAttribute messageAttributes = new MessageAttribute();
        messageAttributes.setDataType("String");
        messageAttributes.setStringValue("3e81e94b-8b6a-42b5-970c-b141f9d195a4");
        final Map<String, MessageAttribute> messageAttributeMap = new HashMap<>();
        messageAttributeMap.put("transactionUuid", messageAttributes);
        MessageAttribute messageAttributesApp = new MessageAttribute();
        messageAttributesApp.setDataType("String");
        messageAttributesApp.setStringValue("e873fca7-849b-4e3b-8dfc-b6b5108608db");
        messageAttributeMap.put("connectionId", messageAttributesApp);
        sqsMessage.setAwsRegion("eu-west-2");
        sqsMessage.setMessageAttributes(messageAttributeMap);
        sqsMessage.setBody(event);
        records.add(sqsMessage);
        sqsEvent.setRecords(records);
        return sqsEvent;

    }

    public SQSEvent populateSQSEventIncidentViewResponseGenerated() throws JsonProcessingException {
        final String event = getEventRequestForIncidentViewResponse();
        final SQSMessage sqsMessage = new SQSMessage();
        final SQSEvent sqsEvent = new SQSEvent();
        final List<SQSMessage> records = new ArrayList<>();
        final MessageAttribute messageAttributes = new MessageAttribute();
        messageAttributes.setDataType("String");
        messageAttributes.setStringValue("3e81e94b-8b6a-42b5-970c-b141f9d195a4");
        final Map<String, MessageAttribute> messageAttributeMap = new HashMap<>();
        messageAttributeMap.put("transactionUuid", messageAttributes);
        MessageAttribute messageAttributesApp = new MessageAttribute();
        messageAttributesApp.setDataType("String");
        messageAttributesApp.setStringValue("e873fca7-849b-4e3b-8dfc-b6b5108608db");
        messageAttributeMap.put("connectionId", messageAttributesApp);
        sqsMessage.setAwsRegion("eu-west-2");
        sqsMessage.setMessageAttributes(messageAttributeMap);
        sqsMessage.setBody(event);
        records.add(sqsMessage);
        sqsEvent.setRecords(records);
        return sqsEvent;
    }

    public String getEventRequestForIncidentViewResponse() throws JsonProcessingException {
        final UiHeader header = populateEventHeaderIncidentViewResponseGenerated();
        final ViewIncidentDetailsListV1 bodyList = populateEventBodyForIncidentViewResponse();
        final String body = mapper.writeValueAsString(bodyList);
        final BaseEventErrors errors = populateError();
        final BaseEvent<UiHeader> event = new BaseEvent<>();
        event.setEventHeader(header);
        event.setEventErrors(errors);
        event.setEventBody(body);
        return mapper.writeValueAsString(event);
    }

    public UiHeader populateEventHeaderIncidentViewResponseGenerated() {
        final UiHeader header = new UiHeader();
        header.setConnectionId("WPl56dCALPECGwg=");
        header.setTransactionId(UUID.fromString("3e81e94b-8b6a-42b5-970c-b141f9d195a4"));
        header.setCorrelationId(UUID.fromString("123e4567-e89b-12d3-a456-426614174000"));
        header.setPartnerCode(null);
        header.setEventName("IncidentViewResponseDetailsGenerated");
        header.setEventDateTime(LocalDateTime.of(2020, Month.NOVEMBER, 23, 5, 52, 55));
        header.setEventDiscriminator("RI-UI");
        return header;
    }

    public ViewIncidentDetailsListV1 populateEventBodyForIncidentViewResponse() {
        final CommentsV1 incidentComments = new CommentsV1();
        final IncidentEvidenceV1 incidentEvidence = new IncidentEvidenceV1();

        List<ViewIncidentDetailsV1> viewIncidentDetailsV1List = new ArrayList<>();

        ViewIncidentDetailsV1 viewIncidentDetailsV1 = ViewIncidentDetailsV1.builder()
                .incidentBookingDetails(IncidentSearchResultDetailsV1
                        .builder()
                        .bookingDetails(BookingDetailsV1.builder()
                                .bookingUuid("0b07b3ee-7c85-408f-9695-916a15f46598")
                                .uniqueTestTakerUuid("0b07b3ee-7c85-408f-9695-916a15f46598")
                                .uniqueTestTakerId("uttid")
                                .shortCandidateNumber("IN001")
                                .firstName("Joey")
                                .lastName("Chandler")
                                .testDate(LocalDate.now())
                                .identityNumber("IN001")
                                .locationUuid("0b07b3ee-7c85-408f-9695-916a15f46598")
                                .productUuid("0b07b3ee-7c85-408f-9695-916a15f46598")
                                .build())
                        .incidentDetails(ResultIntegrityIncidentDetailsV1
                                .builder()
                                .bookingUuid("0b07b3ee-7c85-408f-9695-916a15f46598")
                                .incidentUuid("0b04b3ee-7c85-408f-9695-916a15f46509")
                                .incidentCategoryUuid("0b07b3ee-7c85-408f-9695-916a15f46111")
                                .incidentTypeUuid("0b07b3ee-7c85-408f-9695-916a15f46598")
                                .incidentStatusTypeUuid("0b07b3ee-7c85-408f-9695-916a15f46582")
                                .incidentSeverity("CONFIRMED_MALPRACTICE")
                                .banReviewRequired(true)
                                .comments(incidentComments)
                                .evidences(incidentEvidence)
                                .build())
                        .build()).build();

        viewIncidentDetailsV1List.add(viewIncidentDetailsV1);

        return ViewIncidentDetailsListV1
                .builder()
                .entries(viewIncidentDetailsV1List)
                .build();
    }

    public SQSEvent populateSQSEventPrcOutcomeReceivedWithValue() throws JsonProcessingException {
        final String event = getEventRequestForRemoveUttidAssociationWithValue();
        final SQSMessage sqsMessage = new SQSMessage();
        final SQSEvent sqsEvent = new SQSEvent();
        final List<SQSMessage> records = new ArrayList<>();
        final MessageAttribute messageAttributes = new MessageAttribute();
        messageAttributes.setDataType("String");
        messageAttributes.setStringValue("3e81e94b-8b6a-42b5-970c-b141f9d195a4");
        final Map<String, MessageAttribute> messageAttributeMap = new HashMap<>();
        messageAttributeMap.put("transactionUuid", messageAttributes);
        MessageAttribute messageAttributesApp = new MessageAttribute();
        messageAttributesApp.setDataType("String");
        messageAttributesApp.setStringValue("e873fca7-849b-4e3b-8dfc-b6b5108608db");
        messageAttributeMap.put("connectionId", messageAttributesApp);
        sqsMessage.setAwsRegion("eu-west-2");
        sqsMessage.setMessageAttributes(messageAttributeMap);
        sqsMessage.setBody(event);
        records.add(sqsMessage);
        sqsEvent.setRecords(records);
        return sqsEvent;

    }

    public String getEventRequestForRemoveUttidAssociationWithValue() throws JsonProcessingException {
        final UiHeader header = populateEventHeaderPrcOutcomeReceived();
        final String body = "success";
        final BaseEventErrors errors = null;
        final BaseEvent<UiHeader> event = new BaseEvent<>();
        event.setEventErrors(errors);
        event.setEventHeader(header);
        event.setEventBody(body);
        return mapper.writeValueAsString(event);
    }

    public String getEventRequestForCheckOutcomeWithNull() throws JsonProcessingException {
        final UiHeader header = populateEventHeaderCheckOutcome();
        final String eventBody = null;
        final BaseEventErrors errors = null;
        final BaseEvent<UiHeader> event = new BaseEvent<>();
        event.setEventHeader(header);
        event.setEventErrors(errors);
        event.setEventBody(eventBody);
        return mapper.writeValueAsString(event);
    }

    public SQSEvent populateSQSEventIncidentUpdate() throws JsonProcessingException {
        final String event = getEventRequestForIncident();
        final SQSMessage sqsMessage = new SQSMessage();
        final SQSEvent sqsEvent = new SQSEvent();
        final List<SQSMessage> records = new ArrayList<>();
        final MessageAttribute messageAttributes = new MessageAttribute();
        messageAttributes.setDataType("String");
        messageAttributes.setStringValue("3e81e94b-8b6a-42b5-970c-b141f9d195a4");
        final Map<String, MessageAttribute> messageAttributeMap = new HashMap<>();
        messageAttributeMap.put("transactionUuid", messageAttributes);
        MessageAttribute messageAttributesApp = new MessageAttribute();
        messageAttributesApp.setDataType("String");
        messageAttributesApp.setStringValue("e873fca7-849b-4e3b-8dfc-b6b5108608db");
        messageAttributeMap.put("connectionId", messageAttributesApp);
        sqsMessage.setAwsRegion("eu-west-2");
        sqsMessage.setMessageAttributes(messageAttributeMap);
        sqsMessage.setBody(event);
        records.add(sqsMessage);
        sqsEvent.setRecords(records);


        return sqsEvent;
    }


    public String getEventRequestForIncident() throws JsonProcessingException {
        final UiHeader header = populateEventHeaderIncident();
        final String eventBody = "Success";
        final BaseEventErrors errors = null;
        final BaseEvent<UiHeader> event = new BaseEvent<>();
        event.setEventBody(eventBody);
        event.setEventHeader(header);
        event.setEventErrors(errors);
        return mapper.writeValueAsString(event);
    }


    public UiHeader populateEventHeaderIncident() {
        final UiHeader header = new UiHeader();
        header.setConnectionId("WPl56dCALPECGwg=");
        header.setTransactionId(UUID.fromString("3e81e94b-8b6a-42b5-970c-b141f9d195a4"));
        header.setCorrelationId(UUID.fromString("123e4567-e89b-12d3-a456-426614174000"));
        header.setPartnerCode(null);
        header.setEventName("PUT/v1/incident/update");
        header.setEventDateTime(LocalDateTime.of(2020, Month.NOVEMBER, 23, 5, 52, 55));
        header.setEventDiscriminator("RI-UI");
        return header;
    }


    public SQSEvent populateSQSEventIncidentUpdateWithNull() throws JsonProcessingException {
        final String event = getEventRequestForIncidentWithNull();
        final SQSMessage sqsMessage = new SQSMessage();
        final SQSEvent sqsEvent = new SQSEvent();
        final List<SQSMessage> records = new ArrayList<>();
        final MessageAttribute messageAttributes = new MessageAttribute();
        messageAttributes.setDataType("String");
        messageAttributes.setStringValue("3e81e94b-8b6a-42b5-970c-b141f9d195a4");
        final Map<String, MessageAttribute> messageAttributeMap = new HashMap<>();
        messageAttributeMap.put("transactionUuid", messageAttributes);
        MessageAttribute messageAttributesApp = new MessageAttribute();
        messageAttributesApp.setDataType("String");
        messageAttributesApp.setStringValue("e873fca7-849b-4e3b-8dfc-b6b5108608db");
        messageAttributeMap.put("connectionId", messageAttributesApp);
        sqsMessage.setAwsRegion("eu-west-2");
        sqsMessage.setMessageAttributes(messageAttributeMap);
        sqsMessage.setBody(event);
        records.add(sqsMessage);
        sqsEvent.setRecords(records);
        return sqsEvent;


    }


    public String getEventRequestForIncidentWithNull() throws JsonProcessingException {
        final UiHeader header = populateEventHeaderIncident();
        final String eventBody = null;
        final BaseEventErrors errors = null;
        final BaseEvent<UiHeader> event = new BaseEvent<>();
        event.setEventBody(eventBody);
        event.setEventErrors(errors);
        event.setEventHeader(header);
        return mapper.writeValueAsString(event);
    }

    public BookingSearchResultV1 getBookingSearchResultV1ForTest() {
        BookingSearchResultV1 eventBody = new BookingSearchResultV1();
        SearchBookingRequestV1 searchBookingRequestV1 = new SearchBookingRequestV1();
        SearchPaginationV1 searchPaginationV1 = new SearchPaginationV1();
        BookingSearchCriteriaV1 bookingSearchCriteriaV1 = new BookingSearchCriteriaV1();
        BookingSearchResultV1Result bookingSearchResultV1Result = new BookingSearchResultV1Result();
        BookingSearchResultListV1 bookingSearchResultListV1 = new BookingSearchResultListV1();
        BookingSearchResultListV1Inner bookingSearchResultListV1Inner = new BookingSearchResultListV1Inner();
        SearchSortV1 searchSortV1 = new SearchSortV1();
        SearchSortV1Item searchSortV1Item = new SearchSortV1Item();
        searchSortV1Item.setSortBy("test");
        searchSortV1Item.setSortType("test");
        searchSortV1.add(searchSortV1Item);

        searchPaginationV1.setPageSize("1");
        searchPaginationV1.setPageSize("10");

        bookingSearchCriteriaV1.setTestDate(LocalDate.now());
        bookingSearchCriteriaV1.setUniqueTestTakerId("test");

        bookingSearchResultListV1Inner.setBookingUuid(String.valueOf(UUID.randomUUID()));
        bookingSearchResultListV1Inner.setTestDate(LocalDate.now());
        bookingSearchResultListV1Inner.setFirstName("test");
        bookingSearchResultListV1Inner.setLastName("test");
        bookingSearchResultListV1.add(bookingSearchResultListV1Inner);

        bookingSearchResultV1Result.setTotalCount("1");
        bookingSearchResultV1Result.setEntries(bookingSearchResultListV1);

        searchBookingRequestV1.setSorting(searchSortV1);
        searchBookingRequestV1.setPagination(searchPaginationV1);
        searchBookingRequestV1.setCriteria(bookingSearchCriteriaV1);


        eventBody.setSearch(searchBookingRequestV1);
        eventBody.setResult(bookingSearchResultV1Result);

        return eventBody;
    }
}
