package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

@ExtendWith(MockitoExtension.class)
class MapperTest {

    private Mapper mapper;

    @BeforeEach
    void setup() {
        mapper = Mockito.spy(Mapper.class);
    }


    @Test
    void whenMapRequestEventErrorsToSocketResponseErrorIsCalled_thenReturnEventErrors() {
        List<ErrorDescription> eventErrors = new ArrayList<>();
        ErrorDescription errorDescription = new ErrorDescription();
        Source source = new Source("sourcepath", "sourceval");
        errorDescription.setMessage("test error");
        errorDescription.setErrorCode("001");
        errorDescription.setSource(source);
        errorDescription.setType(ErrorTypeEnum.ERROR);

        eventErrors.add(errorDescription);

        BaseEventErrors expectedErrors = new BaseEventErrors(eventErrors);

        ThreadLocalErrorContext.setContext(expectedErrors);

        com.ielts.cmds.ri.common.socketresponse.BaseEventErrors actualEventErrors = mapper.mapRequestEventErrorsToSocketResponseError();
        Assertions.assertEquals(expectedErrors.getErrorList().get(0).getErrorCode(), actualEventErrors.getErrorList().get(0).getErrorCode());
        Assertions.assertEquals(expectedErrors.getErrorList().get(0).getMessage(), actualEventErrors.getErrorList().get(0).getMessage());
        Assertions.assertEquals(expectedErrors.getErrorList().get(0).getTitle(), actualEventErrors.getErrorList().get(0).getTitle());
        Assertions.assertEquals(expectedErrors.getErrorList().get(0).getSource().getPath(), actualEventErrors.getErrorList().get(0).getSource().getPath());
        Assertions.assertEquals(expectedErrors.getErrorList().get(0).getSource().getValue(), actualEventErrors.getErrorList().get(0).getSource().getValue());
    }

    @Test
    void whenMapRequestEventErrorsToSocketResponseErrorIsCalledWithNullSource_thenReturnEventErrors() {
        List<ErrorDescription> eventErrors = new ArrayList<>();
        ErrorDescription errorDescription = new ErrorDescription();
        Source source = new Source();
        errorDescription.setMessage("test error");
        errorDescription.setErrorCode("001");

        eventErrors.add(errorDescription);

        BaseEventErrors expectedErrors = new BaseEventErrors(eventErrors);

        ThreadLocalErrorContext.setContext(expectedErrors);

        com.ielts.cmds.ri.common.socketresponse.BaseEventErrors actualEventErrors = mapper.mapRequestEventErrorsToSocketResponseError();
        Assertions.assertEquals(expectedErrors.getErrorList().get(0).getErrorCode(), actualEventErrors.getErrorList().get(0).getErrorCode());
        Assertions.assertEquals(expectedErrors.getErrorList().get(0).getMessage(), actualEventErrors.getErrorList().get(0).getMessage());
        Assertions.assertEquals(expectedErrors.getErrorList().get(0).getTitle(), actualEventErrors.getErrorList().get(0).getTitle());
        Assertions.assertEquals(source.getPath(), actualEventErrors.getErrorList().get(0).getSource().getPath());
        Assertions.assertEquals(source.getValue(), actualEventErrors.getErrorList().get(0).getSource().getValue());
    }

}
