package com.ielts.cmds.integration;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.integration.factory.ServiceFactoryV2;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
public class RIDistUITest {

    @InjectMocks @Spy private RIDistUI riDistUI;

    @SuppressWarnings("rawtypes")
    @Mock
    private IServiceV2 service;

    @Test
    void processRequestTest() {
        assertTrue(riDistUI.getServiceFactory() instanceof ServiceFactoryV2);
    }
}

