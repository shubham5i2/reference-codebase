package com.ielts.cmds.integration.mapping;

import com.amazonaws.services.apigatewaymanagementapi.AmazonApiGatewayManagementApi;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.integration.RIDistUI;
import com.ielts.cmds.integration.datasetup.SQSEventSetup;
import com.ielts.cmds.ri.common.socketresponse.PrcOutcomeReceivedEnvelopeV1;
import com.ielts.cmds.ri.common.socketresponse.SocketResponseMetaDataV1;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.doReturn;

@ExtendWith(MockitoExtension.class)
class PrcOutcomeReceivedEventMappingTest {
    @Spy
    private ObjectMapper objectMapper;

    @Mock
    private Context context;

    @Spy
    private RIDistUI riDist;

    @Spy
    private SQSEventSetup sqsEventSetup;

    @Spy
    private PrcOutcomeReceivedEventMapping prcOutcomeReceivedEventMapping;

    @Spy
    private SQSEvent event;

    @Mock
    private TypeReference<BaseEvent<UiHeader>> typeRef;

    @Mock
    private AmazonApiGatewayManagementApi mockclient;

    /**
     * Sets up.
     *
     * @throws JsonProcessingException the json processing exception
     */
    @BeforeEach
    public void setUp() throws JsonProcessingException {
        objectMapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
        objectMapper.registerModule(new JavaTimeModule());
        typeRef = new TypeReference<BaseEvent<UiHeader>>() {
        };
        event = sqsEventSetup.populateSQSEventPrcOutcomeReceived();
    }

    @Test
    void whenMapRequestEventBodyToResponseIsCalledThenReturnResponse() throws JsonProcessingException {

        event = sqsEventSetup.populateSQSEventPrcOutcomeReceivedWithValue();
        String sqsMessage = event.getRecords().get(0).getBody();
        BaseEvent<UiHeader> uiCmdsEvent = objectMapper.readValue(sqsMessage, typeRef);
        Object eventBody = objectMapper.readValue(sqsMessage, Object.class);
        SocketResponseMetaDataV1 socketResponseMetaDataV1 = new SocketResponseMetaDataV1();
        socketResponseMetaDataV1.setConnectionId(uiCmdsEvent.getEventHeader().getConnectionId());
        socketResponseMetaDataV1.setCorrelationId(String.valueOf(uiCmdsEvent.getEventHeader().getCorrelationId()));

        doReturn(socketResponseMetaDataV1).when(prcOutcomeReceivedEventMapping).mapRequestEventHeaderToSocketResponseHeader();
        PrcOutcomeReceivedEnvelopeV1 response = prcOutcomeReceivedEventMapping.process(eventBody);

        assertNotNull(response);
    }

    @Test
    void whenMapRequestEventBodyToResponseIsCalledWithNullEventBodyThenReturnNullResponse() throws JsonProcessingException {

        event = sqsEventSetup.populateSQSEventPrcOutcomeReceivedWithValue();
        String sqsMessage = event.getRecords().get(0).getBody();
        BaseEvent<UiHeader> uiCmdsEvent = objectMapper.readValue(sqsMessage, typeRef);
        SocketResponseMetaDataV1 socketResponseMetaDataV1 = new SocketResponseMetaDataV1();
        socketResponseMetaDataV1.setConnectionId(uiCmdsEvent.getEventHeader().getConnectionId());
        socketResponseMetaDataV1.setCorrelationId(String.valueOf(uiCmdsEvent.getEventHeader().getCorrelationId()));

        doReturn(socketResponseMetaDataV1).when(prcOutcomeReceivedEventMapping).mapRequestEventHeaderToSocketResponseHeader();
        PrcOutcomeReceivedEnvelopeV1 prcOutcomeReceivedEnvelopeV1 = prcOutcomeReceivedEventMapping.process(null);

        assertNull(prcOutcomeReceivedEnvelopeV1.getResponse());
    }
}
