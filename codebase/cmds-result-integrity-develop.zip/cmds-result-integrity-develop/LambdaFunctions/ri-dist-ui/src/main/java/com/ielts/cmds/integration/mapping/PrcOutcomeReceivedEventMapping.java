package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.ri.common.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.ri.common.socketresponse.PrcOutcomeReceivedEnvelopeV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;

import java.util.Objects;

public class PrcOutcomeReceivedEventMapping extends Mapper implements IServiceV2<Object, PrcOutcomeReceivedEnvelopeV1> {

    @Override
    public PrcOutcomeReceivedEnvelopeV1 process(Object cmdsEventBody) {
        final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
        final BaseEventErrors responseErrors = new BaseEventErrors();
        if(Objects.nonNull(cmdsEventBody)) {
            return new PrcOutcomeReceivedEnvelopeV1(responseHeaders, cmdsEventBody , responseErrors);
        } else {
            return new PrcOutcomeReceivedEnvelopeV1(responseHeaders, null, responseErrors);
        }
    }
}

