package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.ri.common.socketresponse.BaseEventErrors;
import com.ielts.cmds.ri.common.socketresponse.BookingIdPhotoDetailsV1;
import com.ielts.cmds.ri.common.socketresponse.IdPhotosResponseEnvelopeV1;
import com.ielts.cmds.ri.common.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;

import java.util.Objects;

public class ViewIdPhotosResponseGeneratedEventMapping extends Mapper implements IServiceV2<BookingIdPhotoDetailsV1, IdPhotosResponseEnvelopeV1> {

  @Override
  public IdPhotosResponseEnvelopeV1 process(BookingIdPhotoDetailsV1 cmdsEventBody) {
    BookingIdPhotoDetailsV1 responseBody = null;
    if (Objects.nonNull(cmdsEventBody)) {
      responseBody = mapRequestEventBodyToResponseBody(cmdsEventBody);
    }
    final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
    final BaseEventErrors responseErrors = mapRequestEventErrorsToSocketResponseError();

    return new IdPhotosResponseEnvelopeV1(responseHeaders, responseBody, responseErrors);
  }

  public BookingIdPhotoDetailsV1 mapRequestEventBodyToResponseBody(BookingIdPhotoDetailsV1 cmdsEventBody) {
    BookingIdPhotoDetailsV1 bookingIdPhotoDetailsV1 = new BookingIdPhotoDetailsV1();

    bookingIdPhotoDetailsV1.setBookingDetails(cmdsEventBody.getBookingDetails());
    bookingIdPhotoDetailsV1.setPhotos(cmdsEventBody.getPhotos());
    bookingIdPhotoDetailsV1.setCheckOutcomeStatusUuid(cmdsEventBody.getCheckOutcomeStatusUuid());

    return bookingIdPhotoDetailsV1;
  }
}
