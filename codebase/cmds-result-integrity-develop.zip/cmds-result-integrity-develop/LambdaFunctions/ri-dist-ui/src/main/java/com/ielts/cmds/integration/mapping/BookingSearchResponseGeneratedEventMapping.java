package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.ri.common.socketresponse.BaseEventErrors;
import com.ielts.cmds.ri.common.socketresponse.BookingSearchCriteriaV1;
import com.ielts.cmds.ri.common.socketresponse.BookingSearchResultV1;
import com.ielts.cmds.ri.common.socketresponse.BookingSearchResultV1Result;
import com.ielts.cmds.ri.common.socketresponse.SearchBookingEnvelopeV1;
import com.ielts.cmds.ri.common.socketresponse.SearchBookingRequestV1;
import com.ielts.cmds.ri.common.socketresponse.SearchPaginationV1;
import com.ielts.cmds.ri.common.socketresponse.SearchSortV1;
import com.ielts.cmds.ri.common.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;

import java.util.Objects;

public class BookingSearchResponseGeneratedEventMapping extends Mapper implements IServiceV2<BookingSearchResultV1, SearchBookingEnvelopeV1> {


  @Override
  public SearchBookingEnvelopeV1 process(BookingSearchResultV1 eventBody) {
    BookingSearchResultV1 responseBody = null;

    if (Objects.nonNull(eventBody)) {
      responseBody = mapRequestEventBodyToResponseBody(eventBody);
    }
    final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
    final BaseEventErrors responseErrors = mapRequestEventErrorsToSocketResponseError();
    return new SearchBookingEnvelopeV1(responseHeaders, responseBody, responseErrors);
  }

  public BookingSearchResultV1 mapRequestEventBodyToResponseBody(BookingSearchResultV1 eventBody) {
    BookingSearchResultV1 bookingSearchResultV1 = new BookingSearchResultV1();
    SearchBookingRequestV1 searchBookingRequestV1 = new SearchBookingRequestV1();
    BookingSearchCriteriaV1 bookingSearchCriteriaV1 = new BookingSearchCriteriaV1();
    SearchPaginationV1 searchPaginationV1 = new SearchPaginationV1();
    SearchSortV1 searchSortV1 = new SearchSortV1();
    BookingSearchResultV1Result bookingSearchResultV1Result = new BookingSearchResultV1Result();

    bookingSearchCriteriaV1.setBirthDate(eventBody.getSearch().getCriteria().getBirthDate());
    bookingSearchCriteriaV1.setCentreId(eventBody.getSearch().getCriteria().getCentreId());
    bookingSearchCriteriaV1.setCheckOutcome(eventBody.getSearch().getCriteria().getCheckOutcome());
    bookingSearchCriteriaV1.setFirstName(eventBody.getSearch().getCriteria().getFirstName());
    bookingSearchCriteriaV1.setLastName(eventBody.getSearch().getCriteria().getLastName());
    bookingSearchCriteriaV1.setIdentityNumber(eventBody.getSearch().getCriteria().getIdentityNumber());
    bookingSearchCriteriaV1.setUniqueTestTakerId(eventBody.getSearch().getCriteria().getUniqueTestTakerId());
    bookingSearchCriteriaV1.setShortCandidateNumber(eventBody.getSearch().getCriteria().getShortCandidateNumber());
    bookingSearchCriteriaV1.setTestDate(eventBody.getSearch().getCriteria().getTestDate());

    searchPaginationV1.setPageNumber(eventBody.getSearch().getPagination().getPageNumber());
    searchPaginationV1.setPageSize(eventBody.getSearch().getPagination().getPageSize());

    bookingSearchResultV1Result.setEntries(eventBody.getResult().getEntries());
    bookingSearchResultV1Result.setTotalCount(eventBody.getResult().getTotalCount());

    searchSortV1.addAll(eventBody.getSearch().getSorting());
    searchBookingRequestV1.setPagination(searchPaginationV1);
    searchBookingRequestV1.setSorting(searchSortV1);
    searchBookingRequestV1.setCriteria(bookingSearchCriteriaV1);

    bookingSearchResultV1.setSearch(searchBookingRequestV1);
    bookingSearchResultV1.setResult(bookingSearchResultV1Result);

    return bookingSearchResultV1;
  }
}
