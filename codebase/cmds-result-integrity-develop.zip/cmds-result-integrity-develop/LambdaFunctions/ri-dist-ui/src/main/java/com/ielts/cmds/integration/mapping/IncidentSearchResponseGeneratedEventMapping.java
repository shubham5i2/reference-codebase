package com.ielts.cmds.integration.mapping;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.ri.common.socketresponse.BaseEventErrors;
import com.ielts.cmds.ri.common.socketresponse.IncidentSearchResultEnvelopeV1;
import com.ielts.cmds.ri.common.socketresponse.IncidentSearchResultV1;
import com.ielts.cmds.ri.common.socketresponse.IncidentSearchResultV1Result;
import com.ielts.cmds.ri.common.socketresponse.SearchIncidentRequestV1;
import com.ielts.cmds.ri.common.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import lombok.extern.slf4j.Slf4j;

import java.util.Objects;

@Slf4j
public class IncidentSearchResponseGeneratedEventMapping extends Mapper implements IServiceV2<IncidentSearchResultV1, IncidentSearchResultEnvelopeV1> {

    @Override
    public IncidentSearchResultEnvelopeV1 process(IncidentSearchResultV1 cmdsEventBody) {
        IncidentSearchResultV1 responseBody = null;

        if (Objects.nonNull(cmdsEventBody)) {
            responseBody = mapRequestEventBodyToResponseBody(cmdsEventBody);
        }
        log.info("responseBody for lambda {}");
        final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
        final BaseEventErrors responseErrors = mapRequestEventErrorsToSocketResponseError();

        return new IncidentSearchResultEnvelopeV1(responseHeaders, responseBody, responseErrors);
    }

    public IncidentSearchResultV1 mapRequestEventBodyToResponseBody(IncidentSearchResultV1 cmdsEventBody) {
        IncidentSearchResultV1 incidentSearchResultV1 = new IncidentSearchResultV1();
        SearchIncidentRequestV1 searchIncidentRequestV1 = new SearchIncidentRequestV1();

        searchIncidentRequestV1.setCriteria(cmdsEventBody.getSearch().getCriteria());
        searchIncidentRequestV1.setPagination(cmdsEventBody.getSearch().getPagination());
        searchIncidentRequestV1.setSorting(cmdsEventBody.getSearch().getSorting());

        incidentSearchResultV1.setSearch(searchIncidentRequestV1);
        incidentSearchResultV1.setResult(cmdsEventBody.getResult());

        return incidentSearchResultV1;
    }
}
