package com.ielts.cmds.integration.mapping;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.ri.common.socketresponse.BaseEventErrors;
import com.ielts.cmds.ri.common.socketresponse.BaseEventErrorsErrorList;
import com.ielts.cmds.ri.common.socketresponse.BaseEventErrorsSource;
import com.ielts.cmds.ri.common.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.common.logger.util.CMDSLambdaLoggerUtil;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public abstract class Mapper {

	protected final ObjectMapper objectMapper = new ObjectMapper();
	
	protected final CMDSLambdaLoggerUtil loggerUtil = new CMDSLambdaLoggerUtil();
	
	protected Mapper(){
		objectMapper.registerModule(new JavaTimeModule());
		objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
		objectMapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
		objectMapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
		objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
	}
	
	public SocketResponseMetaDataV1 mapRequestEventHeaderToSocketResponseHeader() {
		final SocketResponseMetaDataV1 responseHeaders = new SocketResponseMetaDataV1();
		responseHeaders.setCorrelationId(String.valueOf(ThreadLocalHeaderContext.getContext().getCorrelationId()));
		responseHeaders.setConnectionId(ThreadLocalHeaderContext.getContext().getConnectionId());
		return responseHeaders;
	}

	public BaseEventErrors mapRequestEventErrorsToSocketResponseError() {
		BaseEventErrors baseEventErrors = new BaseEventErrors();
		com.ielts.cmds.infrastructure.event.BaseEventErrors context = ThreadLocalErrorContext.getContext();
		if (Objects.nonNull(context) && !context.getErrorList().isEmpty()) {
			List<BaseEventErrorsErrorList> baseEventErrorsErrorListList = new ArrayList<>();
			context.getErrorList().forEach(errorDescription -> {
				BaseEventErrorsSource source = new BaseEventErrorsSource();
				BaseEventErrorsErrorList baseEventErrorsErrorList = new BaseEventErrorsErrorList();
				if (Objects.nonNull(errorDescription.getSource())) {
					source.setPath(errorDescription.getSource().getPath());
					source.setValue(errorDescription.getSource().getValue());
				}
				baseEventErrorsErrorList.setErrorCode(errorDescription.getErrorCode());
				baseEventErrorsErrorList.setErrorTicketUuid(String.valueOf(errorDescription.getErrorTicketUuid()));
				baseEventErrorsErrorList.setInterface(errorDescription.getInterfaceName());
				baseEventErrorsErrorList.setTitle(errorDescription.getTitle());
				baseEventErrorsErrorList.setSource(source);
				baseEventErrorsErrorList.setMessage(errorDescription.getMessage());
				if (Objects.nonNull(errorDescription.getType())) {
					baseEventErrorsErrorList.setType(BaseEventErrorsErrorList.TypeEnum.valueOf(errorDescription.getType().getValue()));
				}
				baseEventErrorsErrorListList.add(baseEventErrorsErrorList);
			});
			baseEventErrors.setErrorList(baseEventErrorsErrorListList);
		}
		return baseEventErrors;
	}

	public com.ielts.cmds.infrastructure.event.BaseEventErrors mapRequestEventErrorsToSocketResponseErrorV2() {
		com.ielts.cmds.infrastructure.event.BaseEventErrors baseEventErrors = ThreadLocalErrorContext.getContext();
		return baseEventErrors;
	}
}
