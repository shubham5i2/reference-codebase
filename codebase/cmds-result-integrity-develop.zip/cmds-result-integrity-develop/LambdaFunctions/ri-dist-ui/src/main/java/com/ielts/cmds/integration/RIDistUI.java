package com.ielts.cmds.integration;

import com.ielts.cmds.integration.factory.ServiceFactoryV2;
import com.ielts.cmds.serialization.lambda.AbstractDistUiLambda;
import com.ielts.cmds.serialization.lambda.dist.ui.service.AbstractServiceFactoryV2;

public class RIDistUI extends AbstractDistUiLambda {
    @Override
    public AbstractServiceFactoryV2 getServiceFactory() {
        return new ServiceFactoryV2();
    }
}
