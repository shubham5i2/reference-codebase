package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.ri.common.socketresponse.BaseEventErrors;
import com.ielts.cmds.ri.common.socketresponse.IncidentViewResponseEnvelopeV1;
import com.ielts.cmds.ri.common.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.ri.common.socketresponse.ViewIncidentDetailsListV1;
import com.ielts.cmds.ri.common.socketresponse.ViewIncidentDetailsV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@Slf4j
public class IncidentViewResponseGeneratedEventMapping extends Mapper implements IServiceV2<ViewIncidentDetailsListV1, IncidentViewResponseEnvelopeV1> {

  @Override
  public IncidentViewResponseEnvelopeV1 process(ViewIncidentDetailsListV1 cmdsEventBody) {
    ViewIncidentDetailsListV1 responseBody = null;

    if (cmdsEventBody != null) {
      responseBody = mapRequestEventBodyToResponseBody(cmdsEventBody);
    }
    final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
    final BaseEventErrors responseErrors = mapRequestEventErrorsToSocketResponseError();

    return new IncidentViewResponseEnvelopeV1(responseHeaders, responseBody, responseErrors);
  }

  public ViewIncidentDetailsListV1 mapRequestEventBodyToResponseBody(ViewIncidentDetailsListV1 eventBody) {
    ViewIncidentDetailsListV1 viewIncidentDetailsListV1 = new ViewIncidentDetailsListV1();
    List<ViewIncidentDetailsV1>  viewIncidentDetailsV1List = eventBody.getEntries();
    viewIncidentDetailsListV1.setEntries(viewIncidentDetailsV1List);
    return viewIncidentDetailsListV1;
  }
}
