package com.ielts.cmds.integration.factory;

import com.ielts.cmds.integration.mapping.BookingSearchResponseGeneratedEventMapping;
import com.ielts.cmds.integration.mapping.CheckOutcomeUpdateResponseEventMapping;
import com.ielts.cmds.integration.mapping.IncidentSearchResponseGeneratedEventMapping;
import com.ielts.cmds.integration.mapping.IncidentUpdateResponseEventMapping;
import com.ielts.cmds.integration.mapping.IncidentViewResponseGeneratedEventMapping;
import com.ielts.cmds.integration.mapping.PrcOutcomeReceivedEventMapping;
import com.ielts.cmds.integration.mapping.ViewIdPhotosResponseGeneratedEventMapping;
import com.ielts.cmds.serialization.lambda.dist.ui.service.AbstractServiceFactoryV2;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;

import java.util.HashMap;
import java.util.Map;

import static com.ielts.cmds.integration.constants.RIDistUiConstants.BOOKING_SEARCH_RESPONSE_GENERATED;
import static com.ielts.cmds.integration.constants.RIDistUiConstants.ID_PHOTOS_RESPONSE_GENERATED_EVENT;
import static com.ielts.cmds.integration.constants.RIDistUiConstants.INCIDENT_SEARCH_RESPONSE_GENERATED;
import static com.ielts.cmds.integration.constants.RIDistUiConstants.INCIDENT_VIEW_RESPONSE_DETAILS_GENERATED_EVENT;
import static com.ielts.cmds.integration.constants.RIDistUiConstants.POST_V_1_INCIDENT_SUBMITPRCOUTCOME;
import static com.ielts.cmds.integration.constants.RIDistUiConstants.PUT_V1_INCIDENT_UPDATE;
import static com.ielts.cmds.integration.constants.RIDistUiConstants.PUT_V1_SUBMIT_ID_CHECKOUTCOME;

@SuppressWarnings("rawtypes")
public class ServiceFactoryV2 extends AbstractServiceFactoryV2 {

    private static final Map<String, IServiceV2> initServices = new HashMap<>();

    static {
        initServices.put(BOOKING_SEARCH_RESPONSE_GENERATED, new BookingSearchResponseGeneratedEventMapping());
        initServices.put(POST_V_1_INCIDENT_SUBMITPRCOUTCOME, new PrcOutcomeReceivedEventMapping());
        initServices.put(INCIDENT_VIEW_RESPONSE_DETAILS_GENERATED_EVENT, new IncidentViewResponseGeneratedEventMapping());
        initServices.put(ID_PHOTOS_RESPONSE_GENERATED_EVENT, new ViewIdPhotosResponseGeneratedEventMapping());
        initServices.put(INCIDENT_SEARCH_RESPONSE_GENERATED, new IncidentSearchResponseGeneratedEventMapping());
        initServices.put(PUT_V1_SUBMIT_ID_CHECKOUTCOME, new CheckOutcomeUpdateResponseEventMapping());
        initServices.put(PUT_V1_INCIDENT_UPDATE, new IncidentUpdateResponseEventMapping());
    }

    public ServiceFactoryV2() {
        super(initServices);
    }

    @Override
    public <InputType, OutputType> IServiceV2<InputType, OutputType> getService(String eventIdentifier) {
        return initServices.get(eventIdentifier);
    }

}
