package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;

import com.ielts.cmds.ri.common.socketresponse.IncidentUpdateResponseEnvelopeV1;
import com.ielts.cmds.ri.common.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;

import java.util.Objects;

public class IncidentUpdateResponseEventMapping extends Mapper implements IServiceV2<Object, IncidentUpdateResponseEnvelopeV1> {

    @Override
    public IncidentUpdateResponseEnvelopeV1 process(Object cmdsEventBody) {
        final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
        final BaseEventErrors responseErrors = mapRequestEventErrorsToSocketResponseErrorV2();
        if (Objects.nonNull(cmdsEventBody)) {
            return new IncidentUpdateResponseEnvelopeV1(responseHeaders, cmdsEventBody, responseErrors);
        } else {
            return new IncidentUpdateResponseEnvelopeV1(responseHeaders, null, responseErrors);
        }
    }
}