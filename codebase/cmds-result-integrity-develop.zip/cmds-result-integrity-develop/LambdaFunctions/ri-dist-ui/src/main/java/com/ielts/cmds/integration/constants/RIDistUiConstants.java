package com.ielts.cmds.integration.constants;

/**
 * Constants class for SM Distributor Lambda
 */
public class RIDistUiConstants {
	private RIDistUiConstants() {
		throw new IllegalStateException("Constants class RIDistUiConstants");
	}
	public static final String APPLICATION_NAME = "RI-DIST-UI-LAMBDA";
	public static final String WEBSOCKET_API_GATEWAY_ENDPOINT = "websocket_apigateway_endpoint";
	public static final String BOOKING_SEARCH_RESPONSE_GENERATED = "BookingSearchResponseGenerated";
	public static final String INCIDENT_SEARCH_RESPONSE_GENERATED = "IncidentSearchResponseGenerated";
	public static final String POST_V_1_INCIDENT_SUBMITPRCOUTCOME = "POST/v1/incident/submitprcoutcome";
	public static final String ID_PHOTOS_RESPONSE_GENERATED_EVENT = "IdPhotosResponseGenerated";
	public static final String INCIDENT_VIEW_RESPONSE_DETAILS_GENERATED_EVENT = "IncidentViewResponseDetailsGenerated";
	public static final String PUT_V1_SUBMIT_ID_CHECKOUTCOME = "IntegrityCheckInitiated";
	public static final String PUT_V1_INCIDENT_UPDATE = "PUT/v1/incident/update";
}
