package com.ielts.cmds.integration;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.PublishResult;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.helper.EventReceiverTestHelper;
import com.ielts.cmds.integration.request.UiEvent;
import com.ielts.cmds.integration.response.GateWayResponseEntity;
import org.apache.http.HttpStatus;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/** The type RI ui receiver test. */
@ExtendWith(MockitoExtension.class)
public class RIUIReceiverTest {

  @Spy private RIUIReceiver RIUIReceiver;
  @Mock private Context context;

  @Mock private ObjectMapper objectMapper;

  @Mock private AmazonSNS amazonSNS;

  @Mock private GateWayResponseEntity<BaseHeader> gateWayResponseEntity;

  @Mock private UiEvent uiEvent;

  @Mock private PublishResult publishResult;

  /**
   * Sets up.
   *
   * @throws Exception the exception
   */
  @BeforeEach
  void setUp() throws Exception {
    uiEvent = EventReceiverTestHelper.getRequestEvent();
  }

  /**
   * Handle request positive expect no exception.
   *
   * @throws JsonProcessingException the json processing exception
   */
  @Test
  void handleRequest_Positive_ExpectNoException() throws JsonProcessingException {
    when(RIUIReceiver.getEnvironmnetVariable(ArgumentMatchers.anyString()))
        .thenReturn("topicArn");
    when(RIUIReceiver.createClient()).thenReturn(amazonSNS);
    when(amazonSNS.publish(ArgumentMatchers.any())).thenReturn(publishResult);
    gateWayResponseEntity = RIUIReceiver.handleRequest(uiEvent, context);
    Assertions.assertEquals("BC", gateWayResponseEntity.getHeaders().getPartnerCode());
  }

  /**
   * Handle request positive expect invalid parameter exception.
   *
   * @throws JsonProcessingException the json processing exception
   */
  @Test
  void handleRequest_Positive_ExpectInvalidParameterException() throws JsonProcessingException {
    when(RIUIReceiver.getEnvironmnetVariable(ArgumentMatchers.anyString()))
        .thenReturn("topicArn");
    final GateWayResponseEntity<BaseHeader> response =
        RIUIReceiver.handleRequest(uiEvent, context);
    Assertions.assertNotNull(response);
    assertEquals(HttpStatus.SC_FORBIDDEN, response.getStatusCode());
  }

  /**
   * Publish request body to sns expect json processing exception.
   *
   * @throws JsonProcessingException the json processing exception
   */
  @Test
  void publishRequestBodyToSNS_ExpectJsonProcessingException() throws JsonProcessingException {
    when(RIUIReceiver.getMapperWithProperties()).thenReturn(objectMapper);
    doThrow(JsonProcessingException.class).when(objectMapper).writeValueAsString(uiEvent);
    final GateWayResponseEntity<BaseHeader> response =
        RIUIReceiver.publishRequestBodyToSNS(uiEvent, context);
    Assertions.assertNotNull(response);
    assertEquals(HttpStatus.SC_BAD_REQUEST, response.getStatusCode());
  }
}
