package com.ielts.cmds.integration.response;

import com.ielts.cmds.infrastructure.event.BaseHeader;
import lombok.NoArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class GateWayResponseEntity<T extends BaseHeader> {
	private int statusCode;
	private boolean isBase64Encoded;
	private T headers;
	private String body;
	public GateWayResponseEntity(int statusCode, boolean isBase64Encoded, T headers, String body) {
		this.statusCode = statusCode;
		this.isBase64Encoded = isBase64Encoded;
		this.headers = headers;
		this.body = body;
	}
}
