package com.ielts.cmds.integration.config;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.AmazonSNSClient;

public class SNSClientConfig {
	/**
	 * Generate Response for API Gateway
	 * 
	 * @return AmazonSNS
	 */
	public AmazonSNS getSNSClient() {
		return AmazonSNSClient.builder().withRegion(Regions.EU_WEST_2).build();
	}

}
