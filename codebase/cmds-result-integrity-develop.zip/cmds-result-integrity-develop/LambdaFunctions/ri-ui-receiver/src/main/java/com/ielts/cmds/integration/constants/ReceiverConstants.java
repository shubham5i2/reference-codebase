package com.ielts.cmds.integration.constants;

public class ReceiverConstants {
  private ReceiverConstants() {}

  public static final String RI_UI_TOPIC_IN_ARN = "ri_ui_topic_in_arn";
  public static final String RI_UI_LAMBDA = "RIUiReceiverLambda";
  public static final String PARTNER_CODE = "partnerCode";
}
