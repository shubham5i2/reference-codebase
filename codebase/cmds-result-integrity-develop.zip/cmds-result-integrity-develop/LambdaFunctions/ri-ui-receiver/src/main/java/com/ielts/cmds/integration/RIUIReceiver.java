package com.ielts.cmds.integration;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.InvalidParameterException;
import com.amazonaws.services.sns.model.PublishRequest;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;
import com.ielts.cmds.common.logger.util.CMDSLambdaLoggerUtil;
import com.ielts.cmds.common.utils.CMDSCommonUtils;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.config.SNSClientConfig;
import com.ielts.cmds.integration.request.UiEvent;
import com.ielts.cmds.integration.response.GateWayResponseEntity;
import com.ielts.cmds.integration.response.ProxyResponseBody;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.http.HttpStatus;

import java.util.UUID;

import static com.ielts.cmds.integration.constants.ReceiverConstants.PARTNER_CODE;
import static com.ielts.cmds.integration.constants.ReceiverConstants.RI_UI_LAMBDA;
import static com.ielts.cmds.integration.constants.ReceiverConstants.RI_UI_TOPIC_IN_ARN;

/** The type ri ui receiver. */
@Slf4j
public class RIUIReceiver {

  /**
   * Handle request gate way response entity.
   *
   * @param event the event
   * @param context the context
   * @return the gate way response entity
   * @throws JsonProcessingException the json processing exception
   */
  public GateWayResponseEntity<BaseHeader> handleRequest(final UiEvent event, final Context context)
      throws JsonProcessingException {
    final UUID transactionId = UUID.randomUUID();
    final ObjectMapper objectMapper = getMapperWithProperties();
    log.info(
        "Event received in RI Lambda : ri-ui-receiver with metadata as {}",
        objectMapper.writeValueAsString(event.getEventHeader()));
    log.debug("Transaction uuid : {}", transactionId);
    event.getEventHeader().setTransactionId(transactionId);
    initializeLogger(transactionId, event.getEventHeader().getCorrelationId());
    log.debug("Request Event: {} ", objectMapper.writeValueAsString(event));
    return publishRequestBodyToSNS(event, context);
  }

  /**
   * Publish request body to sns gate way response entity.
   *
   * @param eventToSNS the event to sns
   * @param context the context
   * @return the gate way response entity
   * @throws JsonProcessingException the json processing exception
   */
  protected GateWayResponseEntity<BaseHeader> publishRequestBodyToSNS(
      final BaseEvent<? extends BaseHeader> eventToSNS, final Context context)
      throws JsonProcessingException {
    log.info("START:publishRequestBodyToSNS");
    try {
      ObjectMapper mapper = getMapperWithProperties();
      final String partnerCode =
          CMDSCommonUtils.getDataFromClaims(
              eventToSNS.getEventHeader().getXaccessToken(), PARTNER_CODE);
      eventToSNS.getEventHeader().setPartnerCode(partnerCode);

      String stringRequestBodyToSNS = mapper.writeValueAsString(eventToSNS);
      publishRequest(
          stringRequestBodyToSNS,
          eventToSNS.getEventHeader().getTransactionId().toString(),
          eventToSNS.getEventHeader().getCorrelationId().toString());
      log.info(
          "Request has been successfully published to SNS: {}, Published meassage:{}",
          eventToSNS.getEventHeader(),
          stringRequestBodyToSNS);
      log.info(
          "Event being published from RI Lambda : ri-ui-receiver with metadata as {} ",
          mapper.writeValueAsString(eventToSNS.getEventHeader()));
      return generateResponse(eventToSNS);
    } catch (JsonProcessingException jsonProcessingException) {
      log.error(
          "Bad Request Exception - Check for valid Parameters: {}",
          ExceptionUtils.getStackTrace(jsonProcessingException));
      return generateErrorResponse(
          eventToSNS,
          jsonProcessingException,
          "Unable to publish message - Bad Request",
          HttpStatus.SC_BAD_REQUEST);
    } catch (InvalidParameterException invalidParameterException) {
      log.error(
          "Bad Request Exception - Check for valid Parameters: {}",
          ExceptionUtils.getStackTrace(invalidParameterException));
      return generateErrorResponse(
          eventToSNS,
          invalidParameterException,
          "Unable to publish message - Configuration Error",
          HttpStatus.SC_FORBIDDEN);
    }
  }

  /**
   * Publish request.
   *
   * @param requestBodyToSNS the request body to sns
   * @param transactionId the transaction id
   * @param correlationId the correlation id
   */
  protected void publishRequest(
      final String requestBodyToSNS, final String transactionId, final String correlationId) {
    final String riTopicArn = getEnvironmnetVariable(RI_UI_TOPIC_IN_ARN);
    final AmazonSNS riTopicSNSClient = createClient();
    final PublishRequest snsPublishRequest = new PublishRequest();
    snsPublishRequest.withTopicArn(riTopicArn);
    snsPublishRequest.withMessage(requestBodyToSNS);
    riTopicSNSClient.publish(snsPublishRequest);
    log.info(
        "MESSAGE PUBLISHED for correlationId: {} ,transaction id: {} stringRequestBodyToSNS: {}",
        correlationId,
        transactionId,
        requestBodyToSNS);
  }

  /**
   * Generate response gate way response entity.
   *
   * @param event the event
   * @return the gate way response entity
   * @throws JsonProcessingException the json processing exception
   */
  protected GateWayResponseEntity<BaseHeader> generateResponse(
      final BaseEvent<? extends BaseHeader> event) throws JsonProcessingException {
    ProxyResponseBody responseBody =
        new ProxyResponseBody(event.getEventHeader().getTransactionId());
    final GateWayResponseEntity<BaseHeader> gateWayResponseEntity = new GateWayResponseEntity<>();
    final ObjectMapper mapper = getMapperWithProperties();
    gateWayResponseEntity.setStatusCode(HttpStatus.SC_ACCEPTED);
    gateWayResponseEntity.setBase64Encoded(Boolean.TRUE);
    gateWayResponseEntity.setHeaders(event.getEventHeader());
    gateWayResponseEntity.setBody(mapper.writeValueAsString(responseBody));
    return gateWayResponseEntity;
  }

  /**
   * Generate error response gate way response entity.
   *
   * @param event the event
   * @param exception the exception
   * @param title the title
   * @param httpStatus the http status
   * @return the gate way response entity
   * @throws JsonProcessingException the json processing exception
   */
  protected GateWayResponseEntity<BaseHeader> generateErrorResponse(
      final BaseEvent<? extends BaseHeader> event,
      final Exception exception,
      final String title,
      final int httpStatus)
      throws JsonProcessingException {
    final Source source = new Source(exception.getMessage(), event.getEventHeader().getEventName());
    final GateWayResponseEntity<BaseHeader> gateWayResponseEntity = new GateWayResponseEntity<>();
    final ErrorDescription errorDescription = new ErrorDescription();
    final ObjectMapper mapper = getMapperWithProperties();
    gateWayResponseEntity.setStatusCode(httpStatus);
    errorDescription.setInterfaceName(RI_UI_LAMBDA);
    errorDescription.setType(ErrorTypeEnum.ERROR);
    errorDescription.setErrorCode("");
    errorDescription.setSource(source);
    errorDescription.setErrorTicketUuid(event.getEventHeader().getCorrelationId());
    errorDescription.setTitle(title);
    errorDescription.setMessage(exception.getMessage());
    gateWayResponseEntity.setHeaders(event.getEventHeader());
    gateWayResponseEntity.setBody(mapper.writeValueAsString(errorDescription));
    log.info(
        "Event being published from Ri Lambda : ri-ui-receiver with metadata as {} and error {}",
        mapper.writeValueAsString(event.getEventHeader()),
        exception.getMessage());
    return gateWayResponseEntity;
  }

  /**
   * Gets mapper with properties.
   *
   * @return the mapper with properties
   */
  public ObjectMapper getMapperWithProperties() {
    final ObjectMapper mapper = new ObjectMapper();
    mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
    mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    mapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
    return mapper;
  }

  /**
   * Initialize logger.
   *
   * @param transactionId the transaction id
   * @param correlationId the correlation id
   */
  protected void initializeLogger(final UUID transactionId, final UUID correlationId) {
    final CMDSLambdaLoggerUtil loggerUtil = new CMDSLambdaLoggerUtil();
    loggerUtil.initializeThreadContextMap(
        transactionId.toString(), RI_UI_LAMBDA, correlationId.toString());
  }

  /**
   * Create client amazon sns.
   *
   * @return the amazon sns
   */
  protected AmazonSNS createClient() {
    SNSClientConfig snsClientConfig = new SNSClientConfig();
    return snsClientConfig.getSNSClient();
  }

  /**
   * Get environmnet variable string.
   *
   * @param name the name
   * @return the string
   */
  protected String getEnvironmnetVariable(String name) {
    return System.getenv(name);
  }
}
