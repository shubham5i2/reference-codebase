package com.ielts.cmds.integration.request;

import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.UiHeader;

public class UiEvent extends BaseEvent<UiHeader> {

	private static final long serialVersionUID = 1L;
}
