package com.ielts.cmds.integration.response;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.UUID;

@AllArgsConstructor
@Getter
public class ProxyResponseBody {
	private UUID transactionId;

}
