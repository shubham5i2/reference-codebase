ALTER TABLE ri_owner.incident_comment
ALTER COLUMN incident_comment_entered_by TYPE varchar(100);

ALTER TABLE ri_owner.incident_evidence
ALTER COLUMN incident_evidence_url TYPE varchar(500);

