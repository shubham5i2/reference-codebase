ALTER TABLE ri_owner."location" ALTER COLUMN test_centre_number TYPE varchar(20) USING test_centre_number::varchar;

ALTER TABLE ri_owner.booking ADD COLUMN test_date date NOT NULL,
ADD COLUMN birth_date date NULL, ADD COLUMN first_name varchar(100) NULL, ADD COLUMN last_name varchar(100) NULL,
ADD COLUMN identity_number varchar(100) NULL, ADD COLUMN  short_candidate_number int4 NOT NULL;

ALTER TABLE ri_owner.booking DROP CONSTRAINT fk_01_booking_utt;

ALTER TABLE ri_owner.booking ALTER COLUMN unique_test_taker_uuid DROP NOT NULL;

ALTER TABLE ri_owner.product ADD COLUMN effective_from_date date NOT NULL,
	ADD COLUMN effective_to_date date NOT NULL DEFAULT '2099-12-31'::date,
	ADD COLUMN created_by varchar(36) NOT NULL,
	ADD COLUMN updated_by varchar(36) NULL;


ALTER TABLE ri_owner.product ALTER COLUMN created_datetime SET DEFAULT current_timestamp;

ALTER TABLE ri_owner.product ALTER COLUMN updated_datetime DROP NOT NULL;

ALTER TABLE ri_owner.incident ALTER COLUMN booking_line_uuid DROP NOT NULL;

DELETE FROM ri_owner.incident_type;

ALTER TABLE ri_owner.incident_type ADD COLUMN incident_type_code varchar(30) NOT NULL;

ALTER TABLE ri_owner.prc_outcome_details ALTER COLUMN inspera_external_test_id DROP NOT NULL;

ALTER TABLE ri_owner.prc_probability_analysis ADD l_band_score_flag varchar(30) null;
ALTER TABLE ri_owner.prc_probability_analysis ALTER COLUMN r_band_score_flag TYPE varchar(30) USING r_band_score_flag::varchar;

ALTER TABLE ri_owner.prc_probability_analysis ALTER COLUMN r_band_score_country_reg TYPE numeric(50, 20) USING r_band_score_country_reg::numeric;
ALTER TABLE ri_owner.prc_probability_analysis ALTER COLUMN r_band_score_res TYPE numeric(50, 20) USING r_band_score_res::numeric;
ALTER TABLE ri_owner.prc_probability_analysis ALTER COLUMN r_band_score_std_res TYPE numeric(50, 20) USING r_band_score_std_res::numeric;
ALTER TABLE ri_owner.prc_probability_analysis ALTER COLUMN l_band_score_country_reg TYPE numeric(50, 20) USING l_band_score_country_reg::numeric;
ALTER TABLE ri_owner.prc_probability_analysis ALTER COLUMN l_band_score_res TYPE numeric(50, 20) USING l_band_score_res::numeric;
ALTER TABLE ri_owner.prc_probability_analysis ALTER COLUMN l_band_score_std_res TYPE numeric(50, 20) USING l_band_score_std_res::numeric;
ALTER TABLE ri_owner.prc_probability_analysis ALTER COLUMN mean_judgemental TYPE numeric(50, 20) USING mean_judgemental::numeric;

ALTER TABLE ri_owner.prc_repeater_analysis ALTER COLUMN overall_band_score_jump TYPE numeric(50, 20) USING overall_band_score_jump::numeric;

ALTER TABLE ri_owner.product RENAME COLUMN effective_from_date TO available_from_date;

ALTER TABLE ri_owner.product RENAME COLUMN effective_to_date TO available_to_date;

ALTER TABLE ri_owner.product ADD product_name varchar(20) NULL;

ALTER TABLE ri_owner.product ADD product_description varchar(20) NULL;

ALTER TABLE ri_owner."location" RENAME COLUMN location_status TO status;

ALTER TABLE ri_owner."location" RENAME COLUMN location_type_code TO location_type;


ALTER TABLE ri_owner.booking ADD COLUMN booking_status varchar(10) null;

CREATE OR REPLACE VIEW ri_owner.booking_check_outcome_view
AS SELECT b.booking_uuid,
b.short_candidate_number ,
    b.first_name,
    b.last_name,
    b.test_date ,
    b.birth_date,
    b.identity_number,
    u.unique_test_taker ,
    co.check_outcome_status_uuid ,
    co.check_outcome_type_uuid ,
    l.test_centre_number as centre_id,
    ri_owner.uuid_generate_v4() AS id
   FROM ri_owner.booking b join
    ri_owner.unique_test_taker u on b.unique_test_taker_uuid = u.unique_test_taker_uuid
    join ri_owner.check_outcome co on b.booking_uuid = co.booking_uuid join ri_owner."location" l on b.location_uuid = l.location_uuid ;