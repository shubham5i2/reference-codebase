INSERT INTO ri_owner.product
(product_uuid, parent_product_uuid, updated_datetime,  concurrency_version, available_from_date, created_by, updated_by)
VALUES('637f8e1b-0931-4184-9fed-37bc9fdb53d5', NULL, NULL, 0, '2020-07-01', 'Operations User', NULL) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product
(product_uuid, parent_product_uuid, updated_datetime,  concurrency_version, available_from_date, created_by, updated_by)
VALUES('3e81e94b-8b6a-42b5-970c-b141f9d195a3', '637f8e1b-0931-4184-9fed-37bc9fdb53d5', NULL, 0, '2020-07-01', 'Operations User', NULL) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product
(product_uuid, parent_product_uuid, updated_datetime,  concurrency_version, available_from_date, created_by, updated_by)
VALUES('4ddcb08b-c2c7-412a-9f59-f4adaf3aa131', '3e81e94b-8b6a-42b5-970c-b141f9d195a3', NULL, 0, '2020-07-01', 'Operations User', NULL) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product
(product_uuid, parent_product_uuid, updated_datetime,  concurrency_version, available_from_date, created_by, updated_by)
VALUES('cb6f4028-c2d8-48f1-8006-1343760ec905', '3e81e94b-8b6a-42b5-970c-b141f9d195a3', NULL, 0, '2020-07-01', 'Operations User', NULL) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product
(product_uuid, parent_product_uuid, updated_datetime,  concurrency_version, available_from_date, created_by, updated_by)
VALUES('fd01b36e-bb07-4229-81c2-483308787e9f', '3e81e94b-8b6a-42b5-970c-b141f9d195a3', NULL, 0, '2020-07-01', 'Operations User', NULL) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product
(product_uuid, parent_product_uuid, updated_datetime,  concurrency_version, available_from_date, created_by, updated_by)
VALUES('d96eece2-1d7c-495a-a754-6b523b710a82', '637f8e1b-0931-4184-9fed-37bc9fdb53d5', NULL, 0, '2020-07-01', 'Operations User', NULL) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product
(product_uuid, parent_product_uuid, updated_datetime,  concurrency_version, available_from_date, created_by, updated_by)
VALUES('18c94472-35e8-4d89-93da-f6d9caa7f003', 'd96eece2-1d7c-495a-a754-6b523b710a82', NULL, 0, '2020-07-01', 'Operations User', NULL) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product
(product_uuid, parent_product_uuid, updated_datetime,  concurrency_version, available_from_date, created_by, updated_by)
VALUES('f21e2e7f-02e8-4bd7-9602-c247e8a02a5a', 'd96eece2-1d7c-495a-a754-6b523b710a82', NULL, 0, '2020-07-01', 'Operations User', NULL) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product
(product_uuid, parent_product_uuid, updated_datetime,  concurrency_version, available_from_date, created_by, updated_by)
VALUES('d8c32eff-1112-467b-a881-9e52f5acc796', 'd96eece2-1d7c-495a-a754-6b523b710a82', NULL, 0, '2020-07-01', 'Operations User', NULL) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product
(product_uuid, parent_product_uuid, updated_datetime,  concurrency_version, available_from_date, created_by, updated_by)
VALUES('48b0643a-11eb-4eff-b4e3-3f930c6fcdd3', 'd96eece2-1d7c-495a-a754-6b523b710a82', NULL, 0, '2020-07-01', 'Operations User', NULL) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product
(product_uuid, parent_product_uuid, updated_datetime,  concurrency_version, available_from_date, created_by, updated_by)
VALUES('0c6bc64c-fc66-4d5f-879d-89cdc6c3ed31', '3e81e94b-8b6a-42b5-970c-b141f9d195a3', NULL, 0, '2020-07-01', 'Operations User', NULL) ON CONFLICT(product_uuid) DO NOTHING;


