INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('4ca26fd2-5216-4e9a-ba08-89bb94599778',
       '637f8e1b-0931-4184-9fed-37bc9fdb53d5',
	   NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SELT Online Academic',
	   NULL,
       '{"characteristics": ["IOL", "SELT"]} {"RoAutoAccepted": ["FALSE"]}'
       ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('6d79a787-f2aa-4937-ad65-6e6fc8c7b9ab',
       '4ca26fd2-5216-4e9a-ba08-89bb94599778',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SELT Online Academic R',
	   NULL,
       '{"characteristics": ["IOL", "SELT"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('b0a52175-dc8d-43c0-a5ce-01daa3a3e460',
       '4ca26fd2-5216-4e9a-ba08-89bb94599778',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SELT Online Academic W',
	   NULL,
       '{"characteristics": ["IOL", "SELT"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('71e8956f-eb04-4390-aaa5-7f0fb1b5f1ac',
       '4ca26fd2-5216-4e9a-ba08-89bb94599778',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SELT Online Academic S',
	   NULL,
       '{"characteristics": ["IOL", "SELT"]}'
       ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('04ffa164-b36c-4cb8-a949-e1a20d5e38b3',
       '4ca26fd2-5216-4e9a-ba08-89bb94599778',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SELT Online Academic L',
	   NULL,
       '{"characteristics": ["IOL", "SELT"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('0b0e3eb3-7929-4e38-bc63-dea6ffe6def8',
       '637f8e1b-0931-4184-9fed-37bc9fdb53d5',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SELT Online General Training',
	   NULL,
       '{"characteristics": ["IOL", "SELT"]} {"RoAutoAccepted": ["FALSE"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('f828ebe4-e0dd-4060-8cf7-6afbfc47b326',
       '0b0e3eb3-7929-4e38-bc63-dea6ffe6def8',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SELT Online General Training L',
	   NULL,
       '{"characteristics": ["IOL", "SELT"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('91f1dbd5-e455-4067-b7fb-3fdbaac0107f',
       '0b0e3eb3-7929-4e38-bc63-dea6ffe6def8',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SELT Online General Training R',
	   NULL,
       '{"characteristics": ["IOL", "SELT"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('d2e559ef-859c-465d-ba90-f85b1cbf3f02',
       '0b0e3eb3-7929-4e38-bc63-dea6ffe6def8',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SELT Online General Training W',
	   NULL,
       '{"characteristics": ["IOL", "SELT"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('d0fa4932-4aa0-45fc-8234-24bb967b49e5',
       '0b0e3eb3-7929-4e38-bc63-dea6ffe6def8',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SELT Online General Training S',
	   NULL,
       '{"characteristics": ["IOL", "SELT"]}'
       ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('2948e48b-519b-484e-aed9-93a30a8a9485',
       '637f8e1b-0931-4184-9fed-37bc9fdb53d5',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SSR SELT Online Academic',
	   NULL,
       '{"characteristics": ["IOL", "SELT","SSR"]} {"RoAutoAccepted": ["FALSE"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('29689961-a480-4860-b6e2-d1e2bafaacc2',
       '2948e48b-519b-484e-aed9-93a30a8a9485',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SSR SELT Online Academic R',
	   NULL,
       '{"characteristics": ["IOL", "SELT","SSR"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('6fa5a6a4-7b2a-44fd-a7d2-b5dd280c3804',
       '2948e48b-519b-484e-aed9-93a30a8a9485',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SSR SELT Online Academic W',
	   NULL,
       '{"characteristics": ["IOL", "SELT","SSR"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('b41a4d86-9f98-43e7-ad13-0dbedf9c9a18',
       '2948e48b-519b-484e-aed9-93a30a8a9485',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SSR SELT Online Academic S',
	   NULL,
       '{"characteristics": ["IOL", "SELT","SSR"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('2aef48a5-b42a-47bd-9a7a-19a99bb64dde',
       '2948e48b-519b-484e-aed9-93a30a8a9485',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SSR SELT Online Academic L',
	   NULL,
       '{"characteristics": ["IOL", "SELT","SSR"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('58c171e7-6789-498c-9e2e-e26f4bf8c90c',
       '637f8e1b-0931-4184-9fed-37bc9fdb53d5',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SSR SELT Online General Training',
	   NULL,
       '{"characteristics": ["IOL", "SELT","SSR"]} {"RoAutoAccepted": ["FALSE"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('2352424a-1806-4c81-8a4e-3a674d12eed9',
       '58c171e7-6789-498c-9e2e-e26f4bf8c90c',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SSR SELT Online General Training L',
	   NULL,
       '{"characteristics": ["IOL", "SELT","SSR"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('11f076ba-a9af-4d7a-81de-fb910f45339e',
       '58c171e7-6789-498c-9e2e-e26f4bf8c90c',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SSR SELT Online General Training R',
	   NULL,
       '{"characteristics": ["IOL", "SELT","SSR"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('9fa3a10f-0e6f-4b4d-9ea9-35fafa4cf665',
       '58c171e7-6789-498c-9e2e-e26f4bf8c90c',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SSR SELT Online General Training W',
	   NULL,
       '{"characteristics": ["IOL", "SELT","SSR"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('a4dd69cc-65ce-423a-a3ee-331228c8e97b',
       '58c171e7-6789-498c-9e2e-e26f4bf8c90c',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SSR SELT Online General Training S',
	   NULL,
       '{"characteristics": ["IOL", "SELT","SSR"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('6d04f596-22f2-49c4-9d47-85b167b8ca6f',
       '5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SELT on Computer Academic',
	   NULL,
       '{"characteristics": ["IOC", "SELT"]} {"RoAutoAccepted": ["FALSE"]}') ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('15d0e10b-9046-40ba-a9d5-a5fdacbdf29d',
       '6d04f596-22f2-49c4-9d47-85b167b8ca6f',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SELT on Computer Academic R',
	   NULL,
       '{"characteristics": ["IOC", "SELT"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('76f5c60e-4ea1-451c-89c5-8ad2adad6ea3',
       '6d04f596-22f2-49c4-9d47-85b167b8ca6f',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SELT on Computer Academic W',
	   NULL,
       '{"characteristics": ["IOC", "SELT"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('ae943abe-3d6b-48d3-a841-064515f13db1',
       '6d04f596-22f2-49c4-9d47-85b167b8ca6f',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SELT on Computer Academic S',
	   NULL,
       '{"characteristics": ["IOC", "SELT"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('d9caf654-789a-4b50-a5e3-7123c365b92d',
       '6d04f596-22f2-49c4-9d47-85b167b8ca6f',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SELT on Computer Academic L',
	   NULL,
       '{"characteristics": ["IOC", "SELT"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('54b9d8df-c07a-4cb4-b397-adc4faa87c3f',
       '5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SELT on Computer General Training',
	   NULL,
       '{"characteristics": ["IOC", "SELT"]} {"RoAutoAccepted": ["FALSE"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('9e8b80f8-c697-4c88-959d-4875b265b927',
       '54b9d8df-c07a-4cb4-b397-adc4faa87c3f',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SELT on Computer General Training L',
	   NULL,
       '{"characteristics": ["IOC", "SELT"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('a9610d1d-124d-4d58-8468-b921202ca1ee',
       '54b9d8df-c07a-4cb4-b397-adc4faa87c3f',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SELT on Computer General Training R',
	   NULL,
       '{"characteristics": ["IOC", "SELT"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('7cc8a727-4671-4b5a-b0fd-60c08b3a023b',
       '54b9d8df-c07a-4cb4-b397-adc4faa87c3f',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SELT on Computer General Training W',
	   NULL,
       '{"characteristics": ["IOC", "SELT"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('169ba597-2638-4ddf-b245-15f390397d9a',
       '54b9d8df-c07a-4cb4-b397-adc4faa87c3f',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SELT on Computer General Training S',
	   NULL,
       '{"characteristics": ["IOC", "SELT"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('de58e8e0-39c6-4c54-b62e-40cacbc6c56d',
       '5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SSR SELT on Computer Academic',
	   NULL,
       '{"characteristics": ["IOC", "SELT","SSR"]} {"RoAutoAccepted": ["FALSE"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('d8f6415d-c36f-4a2c-9c44-bbf0e4c65530',
       'de58e8e0-39c6-4c54-b62e-40cacbc6c56d',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SSR SELT on Computer Academic R',
	   NULL,
       '{"characteristics": ["IOC", "SELT","SSR"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('edd31fef-dd28-4c0a-a593-3cd3b1b74838',
       'de58e8e0-39c6-4c54-b62e-40cacbc6c56d',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SSR SELT on Computer Academic W',
	   NULL,
       '{"characteristics": ["IOC", "SELT","SSR"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('c3e46fcc-b54f-49ae-8675-e373db8e6dc2',
       'de58e8e0-39c6-4c54-b62e-40cacbc6c56d',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SSR SELT on Computer Academic S',
	   NULL,
       '{"characteristics": ["IOC", "SELT","SSR"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('7768ff79-1c44-4b7d-818f-a935afcb9d94',
       'de58e8e0-39c6-4c54-b62e-40cacbc6c56d',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SSR SELT on Computer Academic L',
	   NULL,
       '{"characteristics": ["IOC", "SELT","SSR"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db',
       '5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SSR SELT on Computer General Training',
	   NULL,
       '{"characteristics": ["IOC", "SELT","SSR"]} {"RoAutoAccepted": ["FALSE"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('42c488cc-2230-4842-b2aa-fe103f006aa7',
       'fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SSR SELT on Computer General Training L',
	   NULL,
       '{"characteristics": ["IOC", "SELT","SSR"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('b6e7b55e-c21e-4002-8c0b-a9f66f8bce61',
       'fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SSR SELT on Computer General Training R',
	   NULL,
       '{"characteristics": ["IOC", "SELT","SSR"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('a6bf0168-7ed0-49b9-959b-d526ff1087fa',
       'fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SSR SELT on Computer General Training W',
	   NULL,
       '{"characteristics": ["IOC", "SELT","SSR"]}'
	   ) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description, product_characteristics)
VALUES('e73dbfad-a961-4c7e-9fba-e196a2703bb8',
       'fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db',
       NULL,
	   '2022-08-17 04:30:00.000',
	   0,
	   '2020-07-01',
       '2099-12-31',
	   'Operations User',
	   NULL,
       'IELTS SSR SELT on Computer General Training S',
	   NULL,
       '{"characteristics": ["IOC", "SELT","SSR"]}'
) ON CONFLICT(product_uuid) DO NOTHING;



