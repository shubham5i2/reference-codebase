UPDATE ri_owner.product SET product_characteristics ='{"characteristics": ["IOL"]}' WHERE product_uuid ='3e81e94b-8b6a-42b5-970c-b141f9d195a3';

UPDATE ri_owner.product SET product_characteristics ='{"characteristics": ["IOL"]}' WHERE product_uuid ='4ddcb08b-c2c7-412a-9f59-f4adaf3aa131';

UPDATE ri_owner.product SET product_characteristics ='{"characteristics": ["IOL"]}' WHERE product_uuid ='cb6f4028-c2d8-48f1-8006-1343760ec905';

UPDATE ri_owner.product SET product_characteristics ='{"characteristics": ["IOL"]}' WHERE product_uuid ='fd01b36e-bb07-4229-81c2-483308787e9f';

UPDATE ri_owner.product SET product_characteristics ='{"characteristics": ["IOL"]}' WHERE product_uuid ='0c6bc64c-fc66-4d5f-879d-89cdc6c3ed31';

UPDATE ri_owner.product SET product_characteristics ='{"characteristics": ["IOL"]}' WHERE product_uuid ='d96eece2-1d7c-495a-a754-6b523b710a82';

UPDATE ri_owner.product SET product_characteristics ='{"characteristics": ["IOL"]}' WHERE product_uuid ='18c94472-35e8-4d89-93da-f6d9caa7f003';

UPDATE ri_owner.product SET product_characteristics ='{"characteristics": ["IOL"]}' WHERE product_uuid ='f21e2e7f-02e8-4bd7-9602-c247e8a02a5a';

UPDATE ri_owner.product SET product_characteristics ='{"characteristics": ["IOL"]}' WHERE product_uuid ='d8c32eff-1112-467b-a881-9e52f5acc796';

UPDATE ri_owner.product SET product_characteristics ='{"characteristics": ["IOL"]}' WHERE product_uuid ='48b0643a-11eb-4eff-b4e3-3f930c6fcdd3';

UPDATE ri_owner.product SET product_characteristics ='{"characteristics": ["IOC"]}' WHERE product_uuid ='fdbacec5-e80a-4710-b3de-7d5f310b1466';

UPDATE ri_owner.product SET product_characteristics ='{"characteristics": ["IOC"]}' WHERE product_uuid ='6ccd6696-0660-409c-8a66-85d79c42f84d';

UPDATE ri_owner.product SET product_characteristics ='{"characteristics": ["IOC"]}' WHERE product_uuid ='d40d2104-a610-42dc-936b-263fb4ba120a';

UPDATE ri_owner.product SET product_characteristics ='{"characteristics": ["IOC"]}' WHERE product_uuid ='f0ea4e6f-d550-4687-a231-1032a7987441';

UPDATE ri_owner.product SET product_characteristics ='{"characteristics": ["IOC"]}' WHERE product_uuid ='43215312-a604-4cbf-8b97-c3695b03e396';

UPDATE ri_owner.product SET product_characteristics ='{"characteristics": ["IOC"]}' WHERE product_uuid ='cf9a05e9-2679-42da-b7d2-b34ea3e0724e';

UPDATE ri_owner.product SET product_characteristics ='{"characteristics": ["IOC"]}' WHERE product_uuid ='df2c8f7e-e485-441b-88a5-34b640bff6a5';

UPDATE ri_owner.product SET product_characteristics ='{"characteristics": ["IOC"]}' WHERE product_uuid ='4871fd4e-0c92-40be-9ca1-2707ab1b4a3f';

UPDATE ri_owner.product SET product_characteristics ='{"characteristics": ["IOC"]}' WHERE product_uuid ='b034eca1-0e06-4384-8ae5-e71af4d66bcb';

UPDATE ri_owner.product SET product_characteristics ='{"characteristics": ["IOC"]}' WHERE product_uuid ='be5f16d3-be46-4a6f-a3a5-268d5e1721cc';