
INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, product_characteristics, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('6d28d524-472d-4d53-8fd9-dc7c4bb5325d',
       '637f8e1b-0931-4184-9fed-37bc9fdb53d5',
       'IELTS SSR Online Academic',
       NULL,
       '2020-07-01',
       '2099-12-31',
       '{"characteristics": ["SSR","IOL"]}',
       'Operations User',
	   '2022-06-30 04:30:00.000',
       NULL,
       NULL,
	0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, product_characteristics, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('95fa3301-e17c-4467-bab5-f4754765ad4d',
       '6d28d524-472d-4d53-8fd9-dc7c4bb5325d',
       'IELTS SSR Online Academic R',
       NULL,
       '2020-07-01',
       '2099-12-31',
       '{"characteristics": ["SSR","IOL"]}',
       'Operations User',
	   '2022-06-30 04:30:00.000',
       NULL,
       NULL,
	0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, product_characteristics, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('9cdec6ab-7886-476a-a586-13dfda9a52a9',
       '6d28d524-472d-4d53-8fd9-dc7c4bb5325d',
       'IELTS SSR Online Academic W',
       NULL,
       '2020-07-01',
       '2099-12-31',
       '{"characteristics": ["SSR","IOL"]}',
       'Operations User',
	   '2022-06-30 04:30:00.000',
       NULL,
       NULL,
	0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, product_characteristics, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('deea53e9-886b-4dee-b0b2-9ab29c70a82e',
       '6d28d524-472d-4d53-8fd9-dc7c4bb5325d',
       'IELTS SSR Online Academic S',
       NULL,
       '2020-07-01',
       '2099-12-31',
       '{"characteristics": ["SSR","IOL"]}',
       'Operations User',
	   '2022-06-30 04:30:00.000',
       NULL,
       NULL,
	0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, product_characteristics, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('bb71c4bb-ba26-4569-99fa-fb3d2aec1120',
       '6d28d524-472d-4d53-8fd9-dc7c4bb5325d',
       'IELTS SSR Online Academic L',
       NULL,
       '2020-07-01',
       '2099-12-31',
       '{"characteristics": ["SSR","IOL"]}',
       'Operations User',
	   '2022-06-30 04:30:00.000',
       NULL,
       NULL,
	0) ON CONFLICT(product_uuid) DO NOTHING;


INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, product_characteristics, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('7b1d8d96-c314-40cd-a61c-2b681086a458',
       '637f8e1b-0931-4184-9fed-37bc9fdb53d5',
       'IELTS SSR Online General Training',
       NULL,
       '2020-07-01',
       '2099-12-31',
       '{"characteristics": ["SSR","IOL"]}',
       'Operations User',
	   '2022-06-30 04:30:00.000',
       NULL,
       NULL,
	0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, product_characteristics, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('304d2fa4-642d-4ec7-8600-ae21eb8b4dd8',
       '7b1d8d96-c314-40cd-a61c-2b681086a458',
       'IELTS SSR Online General Training L',
       NULL,
       '2020-07-01',
       '2099-12-31',
       '{"characteristics": ["SSR","IOL"]}',
       'Operations User',
	   '2022-06-30 04:30:00.000',
       NULL,
       NULL,
	0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, product_characteristics, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('d5d4392d-b3c7-4a99-b039-98a281c0104d',
       '7b1d8d96-c314-40cd-a61c-2b681086a458',
       'IELTS SSR Online General Training R',
       NULL,
       '2020-07-01',
       '2099-12-31',
       '{"characteristics": ["SSR","IOL"]}',
       'Operations User',
	   '2022-06-30 04:30:00.000',
       NULL,
       NULL,
	0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, product_characteristics, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('c5524e22-ec61-4705-b7d1-5818826b7cd1',
       '7b1d8d96-c314-40cd-a61c-2b681086a458',
       'IELTS SSR Online General Training W',
       NULL,
       '2020-07-01',
       '2099-12-31',
       '{"characteristics": ["SSR","IOL"]}',
       'Operations User',
	   '2022-06-30 04:30:00.000',
       NULL,
       NULL,
	0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, product_characteristics, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('a489fddd-9bb5-4ed4-9678-0a88bde4778c',
       '7b1d8d96-c314-40cd-a61c-2b681086a458',
       'IELTS SSR Online General Training S',
       NULL,
       '2020-07-01',
       '2099-12-31',
       '{"characteristics": ["SSR","IOL"]}',
       'Operations User',
	   '2022-06-30 04:30:00.000',
       NULL,
       NULL,
	0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, product_characteristics, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('cb7cd48c-5e79-4a28-8104-e0bcd8e39999',
       '5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
       'IELTS SSR on Computer Academic',
       NULL,
       '2020-07-01',
       '2099-12-31',
       '{"characteristics": ["IOC", "SSR"]}',
       'Operations User',
	   '2022-06-30 04:30:00.000',
       NULL,
       NULL,
	0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, product_characteristics, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('6b2c8f4a-e94f-44c8-8575-22987e5aef17',
       'cb7cd48c-5e79-4a28-8104-e0bcd8e39999',
       'IELTS SSR on Computer Academic R',
       NULL,
       '2020-07-01',
       '2099-12-31',
       '{"characteristics": ["IOC", "SSR"]}',
       'Operations User',
	   '2022-06-30 04:30:00.000',
       NULL,
       NULL,
	0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, product_characteristics, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('bb1895b0-f302-4e4c-8bc9-07265f0eadd7',
       'cb7cd48c-5e79-4a28-8104-e0bcd8e39999',
       'IELTS SSR on Computer Academic W',
       NULL,
       '2020-07-01',
       '2099-12-31',
       '{"characteristics": ["IOC", "SSR"]}',
       'Operations User',
	   '2022-06-30 04:30:00.000',
       NULL,
       NULL,
	0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, product_characteristics, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('ff045df4-8c11-4bd8-b2d3-a94aa56a7877',
       'cb7cd48c-5e79-4a28-8104-e0bcd8e39999',
       'IELTS SSR on Computer Academic S',
       NULL,
       '2020-07-01',
       '2099-12-31',
       '{"characteristics": ["IOC", "SSR"]}',
       'Operations User',
	   '2022-06-30 04:30:00.000',
       NULL,
       NULL,
	0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, product_characteristics, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('17e0db26-7f58-40ae-b5a8-999fb68dca96',
       'cb7cd48c-5e79-4a28-8104-e0bcd8e39999',
       'IELTS SSR on Computer Academic L',
       NULL,
       '2020-07-01',
       '2099-12-31',
       '{"characteristics": ["IOC", "SSR"]}',
       'Operations User',
	   '2022-06-30 04:30:00.000',
       NULL,
       NULL,
	0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, product_characteristics, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('c37e2fab-898d-46d4-a61b-17f24bb29e83',
       '5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
       'IELTS SSR on Computer General Training',
       NULL,
       '2020-07-01',
       '2099-12-31',
       '{"characteristics": ["IOC", "SSR"]}',
       'Operations User',
	   '2022-06-30 04:30:00.000',
       NULL,
       NULL,
	0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, product_characteristics, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('74193427-ccae-4227-8577-9950c9f79d47',
       'c37e2fab-898d-46d4-a61b-17f24bb29e83',
       'IELTS SSR on Computer General Training R',
       NULL,
       '2020-07-01',
       '2099-12-31',
       '{"characteristics": ["IOC", "SSR"]}',
       'Operations User',
	   '2022-06-30 04:30:00.000',
       NULL,
       NULL,
	0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, product_characteristics, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('64ada755-5cb3-46ed-b90c-69bd88230402',
       'c37e2fab-898d-46d4-a61b-17f24bb29e83',
       'IELTS SSR on Computer General Training W',
       NULL,
       '2020-07-01',
       '2099-12-31',
       '{"characteristics": ["IOC", "SSR"]}',
       'Operations User',
	   '2022-06-30 04:30:00.000',
       NULL,
       NULL,
	0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, product_characteristics, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('4acd484a-958c-42f1-9cdd-fc5f8e12d5da',
       'c37e2fab-898d-46d4-a61b-17f24bb29e83',
       'IELTS SSR on Computer General Training S',
       NULL,
       '2020-07-01',
       '2099-12-31',
       '{"characteristics": ["IOC", "SSR"]}',
       'Operations User',
	   '2022-06-30 04:30:00.000',
       NULL,
       NULL,
	0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, product_characteristics, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('e1d9b3fb-d428-4342-9656-50470cde4c39',
       'c37e2fab-898d-46d4-a61b-17f24bb29e83',
       'IELTS SSR on Computer General Training L',
       NULL,
       '2020-07-01',
       '2099-12-31',
       '{"characteristics": ["IOC", "SSR"]}',
       'Operations User',
	   '2022-06-30 04:30:00.000',
       NULL,
       NULL,
	0) ON CONFLICT(product_uuid) DO NOTHING;