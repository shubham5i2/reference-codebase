INSERT INTO ri_owner.check_outcome_type
(check_outcome_type_uuid, check_outcome_type, check_outcome_type_code, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, eligible_for_integrity_check)
VALUES('b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, 'Probable Banned Candidate Check', 'PROB_BANNED_INC_CHK', '2020-07-01', '2099-12-31', 'Operations User', '2022-11-04 14:44:59.232', NULL, NULL, 0, true)
ON CONFLICT(check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, external_incident_category, ban_review_required, external_incident_type)
VALUES('f4e74b88-3267-405e-b310-bd78ac1c959a'::uuid, '29b6aa56-8316-44d9-80d0-d5010a0a8518'::uuid, 'Probable Ban Check', '2020-07-01', '2099-12-31', 'Operations User', '2021-11-07 14:43:02.979', NULL, NULL, 0, 'PROB_BAN_INC', 'probable_ban_check', true, 'probable_ban_check')
ON CONFLICT(incident_type_uuid) DO NOTHING;