
UPDATE ri_owner.incident_category
SET incident_category='Pre-release Check'
WHERE incident_category_uuid='ffc3db8f-6a8e-4923-8e52-d5dabc51328a';

DELETE FROM ri_owner.incident_category
WHERE incident_category_uuid='612b3bb0-0524-4e80-85bc-c4e28d4867cd'::uuid;


INSERT INTO ri_owner.incident_category
(incident_category_uuid, incident_category_code, incident_category, effective_from_date, effective_to_date,
created_by, created_datetime, updated_by, updated_datetime, concurrency_version,
eligible_for_integrity_check)
VALUES('ea8998a1-4571-406e-801e-4f708dba786d', 'ID_CHK_REJ_INC', 'ID Rejected', '2020-07-01'::date,
'2099-12-31'::date, 'Operations User', CURRENT_TIMESTAMP, NULL,NULL, 0, true) ON CONFLICT(incident_category_uuid) DO NOTHING;

INSERT INTO ri_owner.incident_category
(incident_category_uuid, incident_category_code, incident_category, effective_from_date, effective_to_date,
created_by, created_datetime, updated_by, updated_datetime, concurrency_version,
eligible_for_integrity_check)
VALUES('0dc60213-86dc-442f-b435-59bed8243bf4', 'ID_CHK_FOLLOW_UP_INC', 'ID Requires Follow up', '2020-07-01'::date,
'2099-12-31'::date, 'Operations User', CURRENT_TIMESTAMP, NULL,NULL, 0, true) ON CONFLICT(incident_category_uuid) DO NOTHING;