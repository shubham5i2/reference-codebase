
UPDATE ri_owner.incident_type
SET external_incident_type=null
WHERE incident_type_uuid='bf81b6d7-41ee-4c19-bdf3-78d3cf4b4749';

--set external incident category values
UPDATE ri_owner.incident_type SET external_incident_category = 'malpractice' WHERE incident_type_uuid= 'a5f6e973-851e-4e33-8bcf-9c97bb269686';
UPDATE ri_owner.incident_type SET external_incident_category = 'malpractice' WHERE incident_type_uuid= '1b208818-2ff0-4338-9f41-d2a9a80c23af';
UPDATE ri_owner.incident_type SET external_incident_category = 'malpractice' WHERE incident_type_uuid= 'd1dc09d8-f729-44e3-9f91-5866382ed5f2';
UPDATE ri_owner.incident_type SET external_incident_category = 'malpractice' WHERE incident_type_uuid= 'bd12131e-f411-4441-a23b-be51f9572062';
UPDATE ri_owner.incident_type SET external_incident_category = 'malpractice' WHERE incident_type_uuid= '7236364c-e324-4aaa-aeff-e30b416b26a5';
UPDATE ri_owner.incident_type SET external_incident_category = 'malpractice' WHERE incident_type_uuid= 'b2879700-978f-4638-9845-7a831a5be550';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid = 'b27426fb-432d-4ad6-bd0b-90a2a0b767aa';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= 'be08a4cd-de9f-4616-8dd4-7468cdb015ca';
UPDATE ri_owner.incident_type set external_incident_category = 'prc' WHERE incident_type_uuid= '0a896faa-cb43-43ce-8295-48b20373be7a';
UPDATE ri_owner.incident_type set external_incident_category = 'prc' WHERE incident_type_uuid= '2db1fbe1-ae17-4a9b-b821-fd94cccc32e7';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= '508d3493-b169-4f6f-bc20-f1714cd8a294';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= '64211b7d-9ae3-4508-b9c0-cb9f995be703';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= 'edd3a415-5c0f-4350-bc0d-7b3a8ae27d55';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= '5cf0fd2f-3f50-4237-9b36-b6207bc10564';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= 'ddb2686d-59b0-42d0-8acc-2a4a06a0de4c';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= '0c1898b6-cedd-4e1a-88aa-491f88fbdddb';
UPDATE ri_owner.incident_type set external_incident_category = 'other' WHERE incident_type_uuid= 'd6ba52ee-7c44-4212-a38d-76eafbccd98e';
UPDATE ri_owner.incident_type set external_incident_category = 'other' WHERE incident_type_uuid= '203bdd45-aaab-4724-8623-6f364cc3fac0';
UPDATE ri_owner.incident_type set external_incident_category = 'other' WHERE incident_type_uuid= 'b93ae42d-0d97-4147-b2df-b47996c2973a';
UPDATE ri_owner.incident_type set external_incident_category = 'other' WHERE incident_type_uuid= 'bf81b6d7-41ee-4c19-bdf3-78d3cf4b4749';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= 'b4a2217e-8064-4f71-9fb7-ca1cf164d423';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= 'c673ea84-7182-47b3-8cd9-efc723f67d58';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= 'e0a6002a-99f8-4e92-8504-69ac78b8f61a';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= 'ff707183-dea9-4c48-93ba-b0b064203153';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= '778a2ed2-482f-4887-bc52-52a6a1d7cc9c';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= '00d2c608-9216-456a-85ec-db40d33f6a3a';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= '5db24e51-515e-4f3b-b0cb-f77c33f7d63a';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= 'f9f4089e-9e7f-4a34-9629-527ebf136c65';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= 'e782348e-bedf-403a-9f28-7ba5ce60952c';
UPDATE ri_owner.incident_type set external_incident_category = 'plagiarism' WHERE incident_type_uuid= '93fb67cc-a5b2-48ec-bf0a-a9a3c637bb3e';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= 'bac5745b-91a1-423e-ac91-5265bbbe4d65';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= '27ee2fd0-fd09-40c2-96b6-c5ddd098f8e7';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= '43cae917-4d5b-4122-b53f-4f80d1d2915d';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= '09260095-a1d0-46c1-a46e-aa67b6b9bcfe';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= 'e5b53c68-4268-428a-a751-f2264aac4a5b';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= '6272eebc-b48b-4124-bf3a-bf11805642bd';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= 'f2d27561-0d7b-419c-ad66-fd6573baa1f1';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= '06d16b48-7697-4701-998b-2e7ed5cc6a78';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= '81f28ffc-e1dc-451c-8ce9-0deeb48ae7dc';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= '586ba13d-4a60-4a80-8d1d-81c6b5701fb6';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= '514f6342-37c5-433e-b328-abefce804508';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= '89f21d65-6a24-4254-be08-800805f16346';
UPDATE ri_owner.incident_type set external_incident_category = 'technical' WHERE incident_type_uuid= '8b8e8654-b778-4d92-962e-b174a2d5ec07';
UPDATE ri_owner.incident_type set external_incident_category = 'technical' WHERE incident_type_uuid= '97540655-b27e-4fa5-85a1-9e0483dc9098';
UPDATE ri_owner.incident_type set external_incident_category = 'technical' WHERE incident_type_uuid= '1d62ccfb-7d66-4999-b4d3-20d2a4f0b202';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= '97540655-b27e-4fa5-85a1-9e0483dc9099';
UPDATE ri_owner.incident_type set external_incident_category = 'technical' WHERE incident_type_uuid= '97540655-b27e-4fa5-85a1-9e0483dc9097';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= '91a92488-47b5-4cad-bc41-f2a953acb48b';
UPDATE ri_owner.incident_type set external_incident_category = 'malpractice' WHERE incident_type_uuid= '7bb39e96-3687-486c-8649-bba4f9ceb9f0';
