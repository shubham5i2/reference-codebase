
CREATE TABLE if not exists ri_owner.external_incident_status_mapping (
    external_incident_status_mapping_uuid uuid NOT NULL,
    product_uuid uuid NOT NULL,
    incident_category_uuid uuid NOT NULL,
    incident_severity ri_owner."incident_severity_enum",
    external_incident_status ri_owner."external_incident_status_enum",
    incident_status_type_code varchar(50) NOT NULL,
    CONSTRAINT pk_01_external_incident_id PRIMARY KEY (external_incident_status_mapping_uuid)
);




INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('c91b139a-8de8-4ea7-83b5-e3432d4b08ae','3e81e94b-8b6a-42b5-970c-b141f9d195a3' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('cc493ce0-ff9f-4f49-8add-61f8da4a0d5d','3e81e94b-8b6a-42b5-970c-b141f9d195a3' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CONFIRMED', 'INC_STATUS_CONFIRMED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('fc74c6eb-8822-4fe9-a2da-b660ff9f5090','3e81e94b-8b6a-42b5-970c-b141f9d195a3' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('a58b3995-b8d3-47ce-869a-be0b9247714a','3e81e94b-8b6a-42b5-970c-b141f9d195a3' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('ab6d37cd-2f17-4eb8-82f1-caa48c87fd4a','3e81e94b-8b6a-42b5-970c-b141f9d195a3' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CONFIRMED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('e8411407-c01e-40b4-a2be-cb6a0d8fb096','3e81e94b-8b6a-42b5-970c-b141f9d195a3' ,'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('4b3e3e5a-cd5a-43b0-8f54-f8de0b6e5e9b','3e81e94b-8b6a-42b5-970c-b141f9d195a3' ,'fe29aad2-6971-4f04-8321-d800eac26c6f', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('b0d331c7-4712-47c3-a35d-3ca288f3bf8f','3e81e94b-8b6a-42b5-970c-b141f9d195a3' ,'1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('b3a81384-3894-445f-a1ec-713a9dab8306','3e81e94b-8b6a-42b5-970c-b141f9d195a3' ,'0e5567b0-30ac-4518-b245-6093f3bc24b0', null, null, 'INC_STATUS_CONFIRMED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('eb88e264-e6fd-467c-b535-841770fd8c70','3e81e94b-8b6a-42b5-970c-b141f9d195a3' ,'ffc3db8f-6a8e-4923-8e52-d5dabc51328a', null, null, 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;







INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('964ce585-7c76-4e07-a1b0-a5190a33061d','d96eece2-1d7c-495a-a754-6b523b710a82' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('0407b4be-6c71-42c4-aeb7-849372ca2f06','d96eece2-1d7c-495a-a754-6b523b710a82' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CONFIRMED', 'INC_STATUS_CONFIRMED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('31952118-f36c-46cb-8e74-71cbdca9524d','d96eece2-1d7c-495a-a754-6b523b710a82' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('85b0d353-fcb5-40c5-bdcc-72fd64465285','d96eece2-1d7c-495a-a754-6b523b710a82' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('b39812f2-4f91-4df8-bed7-28decf24ec70','d96eece2-1d7c-495a-a754-6b523b710a82' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CONFIRMED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('38ffb885-c6f5-45e8-b9c9-86f3ddfdaae3','d96eece2-1d7c-495a-a754-6b523b710a82' ,'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('015a9dd7-f40e-4b27-97a0-6b6542c6c744','d96eece2-1d7c-495a-a754-6b523b710a82' ,'fe29aad2-6971-4f04-8321-d800eac26c6f', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('7c226829-f4e6-442c-a7cb-da1a7536f3c6','d96eece2-1d7c-495a-a754-6b523b710a82' ,'1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('98b244d6-caeb-4cb0-91f3-dec2a5590da5','d96eece2-1d7c-495a-a754-6b523b710a82' ,'0e5567b0-30ac-4518-b245-6093f3bc24b0', null, null, 'INC_STATUS_CONFIRMED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('c3ecbc6e-90a9-48b4-a3b3-1a90199e6686','d96eece2-1d7c-495a-a754-6b523b710a82' ,'ffc3db8f-6a8e-4923-8e52-d5dabc51328a', null, null, 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;







INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('0adef5c5-b8ef-4a61-aa6c-2b7100342274','fdbacec5-e80a-4710-b3de-7d5f310b1466' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('e0649312-8c58-44e7-973d-4ec0d16c0036','fdbacec5-e80a-4710-b3de-7d5f310b1466' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CONFIRMED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('6ed90ba5-4388-4a30-8b86-59383a4ead1d','fdbacec5-e80a-4710-b3de-7d5f310b1466' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('babd4ccb-103d-4c48-a4ff-21db93328f40','fdbacec5-e80a-4710-b3de-7d5f310b1466' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('c907f273-3143-463e-bffa-49739d8d2b48','fdbacec5-e80a-4710-b3de-7d5f310b1466' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CONFIRMED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('8bba5828-27f5-4c91-be39-9f420426f67e','fdbacec5-e80a-4710-b3de-7d5f310b1466' ,'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('ec9413b8-7346-4e80-baf7-4d4f0a5e0958','fdbacec5-e80a-4710-b3de-7d5f310b1466' ,'fe29aad2-6971-4f04-8321-d800eac26c6f', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('5ba77780-9978-40d2-8b35-49d6b164af0c','fdbacec5-e80a-4710-b3de-7d5f310b1466' ,'1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('e0d7d29e-07c4-4877-99d2-a7b37da216dc','fdbacec5-e80a-4710-b3de-7d5f310b1466' ,'0e5567b0-30ac-4518-b245-6093f3bc24b0', null, null, 'INC_STATUS_CONFIRMED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('74e6e5fb-4af1-4dd0-a1e9-5f89c55a03e5','fdbacec5-e80a-4710-b3de-7d5f310b1466' ,'ffc3db8f-6a8e-4923-8e52-d5dabc51328a', null, null, 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;







INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('64951109-996f-438b-8bcc-4d7eb98a219d','cf9a05e9-2679-42da-b7d2-b34ea3e0724e' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('266c3b7d-fd12-4ce3-afa1-74e0e7c2cecd','cf9a05e9-2679-42da-b7d2-b34ea3e0724e' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CONFIRMED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('088979b3-4af3-4397-ad4e-453d1a0c34e5','cf9a05e9-2679-42da-b7d2-b34ea3e0724e' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('7ced3c97-67e4-4c42-bba8-fc37709327f8','cf9a05e9-2679-42da-b7d2-b34ea3e0724e' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('fadf0304-5049-4d90-988a-5735577f241f','cf9a05e9-2679-42da-b7d2-b34ea3e0724e' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CONFIRMED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('e072d159-d6d3-4d44-9116-353a33127f03','cf9a05e9-2679-42da-b7d2-b34ea3e0724e' ,'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('27a0ccc6-69a3-4ac6-aa91-e7d7b775023c','cf9a05e9-2679-42da-b7d2-b34ea3e0724e' ,'fe29aad2-6971-4f04-8321-d800eac26c6f', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('bc01d80a-8e7a-403e-9c7c-c12c46462dca','cf9a05e9-2679-42da-b7d2-b34ea3e0724e' ,'1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('bb485809-b3d2-4672-bd42-4d7c838532f6','cf9a05e9-2679-42da-b7d2-b34ea3e0724e' ,'0e5567b0-30ac-4518-b245-6093f3bc24b0', null, null, 'INC_STATUS_CONFIRMED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('0c753676-1a4d-4986-bbb5-392ea05c6a75','cf9a05e9-2679-42da-b7d2-b34ea3e0724e' ,'ffc3db8f-6a8e-4923-8e52-d5dabc51328a', null, null, 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;