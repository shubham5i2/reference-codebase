UPDATE ri_owner.test_taker_photo
SET photo_category='Certificate' where
(photo_type_uuid='a101702b-d8dd-4bcd-bcc5-a39cc6cf6fc5' or
photo_type_uuid='f6c594bb-6dc3-438b-8e94-c87edaa47cd6') and  photo_category=null;



UPDATE ri_owner.test_taker_photo
SET photo_category='Other' where
(photo_type_uuid !='a101702b-d8dd-4bcd-bcc5-a39cc6cf6fc5' and
photo_type_uuid !='f6c594bb-6dc3-438b-8e94-c87edaa47cd6') and  photo_category=null;