DELETE FROM ri_owner.incident_type
WHERE incident_type_uuid='8d3d365a-3af9-4acf-aab6-1e4dd6f2153c'::uuid;
DELETE FROM ri_owner.incident_type
WHERE incident_type_uuid='647f049c-7232-4e22-81b3-71bff0f110cf'::uuid;
DELETE FROM ri_owner.incident_type
WHERE incident_type_uuid='20a5be21-5548-4b72-9860-453c645cc14e'::uuid;
DELETE FROM ri_owner.incident_type
WHERE incident_type_uuid='639920b7-d5c5-4ccb-9dc4-e7088658fd11'::uuid;
DELETE FROM ri_owner.incident_type
WHERE incident_type_uuid='91d44f0a-44d2-442e-a1a8-e0943c6d3aaa'::uuid;
DELETE FROM ri_owner.incident_type
WHERE incident_type_uuid='a11aa7ed-9f3b-437f-ad6c-768dc6b212b6'::uuid;
DELETE FROM ri_owner.incident_type
WHERE incident_type_uuid='e32e0115-6bb8-4900-a59a-e4ac34279e32'::uuid;



INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date,
effective_to_date, created_by, created_datetime, updated_by, updated_datetime,
concurrency_version, incident_type_code, external_incident_category,
ban_review_required, external_incident_type)
VALUES('8d3d365a-3af9-4acf-aab6-1e4dd6f2153c', 'ea8998a1-4571-406e-801e-4f708dba786d',
'ID Photo Mismatch Personal', '2020-07-01'::date, '2099-12-31'::date, 'Operations User',
CURRENT_TIMESTAMP, NULL,NULL, 0, 'ID_REJ_INC', 'id_not_verified', false, 'id_photo_mismatch_personal')
ON CONFLICT(incident_type_uuid) DO NOTHING;


INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date,
effective_to_date, created_by, created_datetime, updated_by, updated_datetime,
concurrency_version, incident_type_code, external_incident_category,
ban_review_required, external_incident_type)
VALUES('647f049c-7232-4e22-81b3-71bff0f110cf', 'ea8998a1-4571-406e-801e-4f708dba786d',
'ID Document Mismatch', '2020-07-01'::date, '2099-12-31'::date, 'Operations User',
CURRENT_TIMESTAMP, NULL,NULL, 0, 'ID_REJ_INC', 'id_not_verified', false, 'id_document_mismatch')
ON CONFLICT(incident_type_uuid) DO NOTHING;

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date,
effective_to_date, created_by, created_datetime, updated_by, updated_datetime,
concurrency_version, incident_type_code, external_incident_category,
ban_review_required, external_incident_type)
VALUES('20a5be21-5548-4b72-9860-453c645cc14e', 'ea8998a1-4571-406e-801e-4f708dba786d',
'Other', '2020-07-01'::date, '2099-12-31'::date, 'Operations User',
CURRENT_TIMESTAMP, NULL,NULL, 0, 'ID_REJ_INC', 'id_not_verified', false, 'other')
ON CONFLICT(incident_type_uuid) DO NOTHING;


INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date,
effective_to_date, created_by, created_datetime, updated_by, updated_datetime,
concurrency_version, incident_type_code, external_incident_category,
ban_review_required, external_incident_type)
VALUES('639920b7-d5c5-4ccb-9dc4-e7088658fd11', '0dc60213-86dc-442f-b435-59bed8243bf4',
'Unsure TT Photo match', '2020-07-01'::date, '2099-12-31'::date, 'Operations User',
CURRENT_TIMESTAMP, NULL,NULL, 0, 'ID_FOLLOW_UP_INC', 'id_require_follow_up', false, 'unsure_tt_photo_match')
ON CONFLICT(incident_type_uuid) DO NOTHING;


INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date,
effective_to_date, created_by, created_datetime, updated_by, updated_datetime,
concurrency_version, incident_type_code, external_incident_category,
ban_review_required, external_incident_type)
VALUES('91d44f0a-44d2-442e-a1a8-e0943c6d3aaa', '0dc60213-86dc-442f-b435-59bed8243bf4',
'Unsure ID Document match', '2020-07-01'::date, '2099-12-31'::date, 'Operations User',
CURRENT_TIMESTAMP, NULL,NULL, 0, 'ID_FOLLOW_UP_INC', 'id_require_follow_up', false, 'unsure_id_document_match')
ON CONFLICT(incident_type_uuid) DO NOTHING;


INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date,
effective_to_date, created_by, created_datetime, updated_by, updated_datetime,
concurrency_version, incident_type_code, external_incident_category,
ban_review_required, external_incident_type)
VALUES('a11aa7ed-9f3b-437f-ad6c-768dc6b212b6', '0dc60213-86dc-442f-b435-59bed8243bf4',
'Unsure ID Photo match TT', '2020-07-01'::date, '2099-12-31'::date, 'Operations User',
CURRENT_TIMESTAMP,NULL,NULL, 0, 'ID_FOLLOW_UP_INC', 'id_require_follow_up', false, 'unsure_id_photo_match_tt')
ON CONFLICT(incident_type_uuid) DO NOTHING;


INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date,
effective_to_date, created_by, created_datetime, updated_by, updated_datetime,
concurrency_version, incident_type_code, external_incident_category,
ban_review_required, external_incident_type)
VALUES('e32e0115-6bb8-4900-a59a-e4ac34279e32', '0dc60213-86dc-442f-b435-59bed8243bf4',
'Other', '2020-07-01'::date, '2099-12-31'::date, 'Operations User',
CURRENT_TIMESTAMP, NULL,NULL, 0, 'ID_FOLLOW_UP_INC', 'id_require_follow_up', false, 'other')
ON CONFLICT(incident_type_uuid) DO NOTHING;


