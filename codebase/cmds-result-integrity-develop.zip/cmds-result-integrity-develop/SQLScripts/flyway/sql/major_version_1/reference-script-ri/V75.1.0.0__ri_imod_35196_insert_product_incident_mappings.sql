INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid,
incident_severity, incident_status_type_code)
VALUES('7b844922-918e-472e-b4f5-94d8d296c1e2', '3e81e94b-8b6a-42b5-970c-b141f9d195a3',
'ea8998a1-4571-406e-801e-4f708dba786d',
NULL, 'INC_STATUS_CONFIRMED') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid,
incident_severity, incident_status_type_code)
VALUES('6b123bca-a8b1-4954-8523-426831d299f1', 'd96eece2-1d7c-495a-a754-6b523b710a82',
'ea8998a1-4571-406e-801e-4f708dba786d',
NULL, 'INC_STATUS_CONFIRMED') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid,
incident_severity, incident_status_type_code)
VALUES('bfe1dca7-ac15-463f-8dba-4a105063c740', '3e81e94b-8b6a-42b5-970c-b141f9d195a3',
'0dc60213-86dc-442f-b435-59bed8243bf4',
NULL, 'INC_STATUS_FLAGGED') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid,
incident_severity, incident_status_type_code)
VALUES('cd4a6820-9699-4ade-8a07-0f4791dce186', 'd96eece2-1d7c-495a-a754-6b523b710a82',
'0dc60213-86dc-442f-b435-59bed8243bf4',
NULL, 'INC_STATUS_FLAGGED') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;;
