--UKVI IOC AC

INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('fe00a61d-ed19-4fc2-adc7-99c9db797a04','6d04f596-22f2-49c4-9d47-85b167b8ca6f' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('8be34e24-6f70-4914-83eb-5aa18c90675e','6d04f596-22f2-49c4-9d47-85b167b8ca6f' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CONFIRMED', 'INC_STATUS_CONFIRMED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('58e5be92-2741-41ce-a5a9-95947d828578','6d04f596-22f2-49c4-9d47-85b167b8ca6f' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('4a4eedba-492c-4d4b-86d1-21e2b785f63f','6d04f596-22f2-49c4-9d47-85b167b8ca6f' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('d31bfb2d-941c-4cc9-8b27-79e0e3a8a982','6d04f596-22f2-49c4-9d47-85b167b8ca6f' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CONFIRMED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('c8f91a67-83cf-4a6f-a292-5361faac133a','6d04f596-22f2-49c4-9d47-85b167b8ca6f' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('d9694c28-0800-458e-9ac3-16da1f6d1742','6d04f596-22f2-49c4-9d47-85b167b8ca6f' ,
'fe29aad2-6971-4f04-8321-d800eac26c6f', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('b6fb1ce2-700a-475f-881b-efda72d42337','6d04f596-22f2-49c4-9d47-85b167b8ca6f' ,
'1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('7b8ea789-7d40-4d35-9c38-1a4d44b807dd','6d04f596-22f2-49c4-9d47-85b167b8ca6f' ,
'0e5567b0-30ac-4518-b245-6093f3bc24b0', null, null, 'INC_STATUS_CONFIRMED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('4c238779-faee-4873-b3de-acbffcce743e','6d04f596-22f2-49c4-9d47-85b167b8ca6f' ,
'ffc3db8f-6a8e-4923-8e52-d5dabc51328a', null, null, 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;







--UKVI IOC GT

INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('0eb11c7b-4b02-48ee-81f3-d23c111e2cdb','54b9d8df-c07a-4cb4-b397-adc4faa87c3f' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('b34a2077-797a-4dfe-8d7e-25b0612c8405','54b9d8df-c07a-4cb4-b397-adc4faa87c3f' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CONFIRMED', 'INC_STATUS_CONFIRMED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('f1be1cde-ebcd-4baf-a744-2585ea5c9cbc','54b9d8df-c07a-4cb4-b397-adc4faa87c3f' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('0f1186ab-4a31-4127-9425-25d86c15de4a','54b9d8df-c07a-4cb4-b397-adc4faa87c3f' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('4480d1b5-e7aa-4dc0-8d09-cc14d317e849','54b9d8df-c07a-4cb4-b397-adc4faa87c3f' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CONFIRMED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('fa420e51-377a-447e-b450-fe8bb0b6b8a5','54b9d8df-c07a-4cb4-b397-adc4faa87c3f' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('73c4e2b0-a443-4c92-8dee-088907c80261','54b9d8df-c07a-4cb4-b397-adc4faa87c3f' ,
'fe29aad2-6971-4f04-8321-d800eac26c6f', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('27623521-f4c9-4045-ade7-e988af89d146','54b9d8df-c07a-4cb4-b397-adc4faa87c3f' ,
'1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('318fa8a7-32b5-499a-a917-0c98e5e83fb4','54b9d8df-c07a-4cb4-b397-adc4faa87c3f' ,
'0e5567b0-30ac-4518-b245-6093f3bc24b0', null, null, 'INC_STATUS_CONFIRMED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('83804f72-d518-4cfe-ae8f-2754ed68281e','54b9d8df-c07a-4cb4-b397-adc4faa87c3f' ,
'ffc3db8f-6a8e-4923-8e52-d5dabc51328a', null, null, 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;




