ALTER TYPE ri_owner."photo_category_enum" RENAME VALUE 'Certificate' TO 'CERTIFICATE';
ALTER TYPE ri_owner."photo_category_enum" RENAME VALUE 'Other' TO 'OTHER';
