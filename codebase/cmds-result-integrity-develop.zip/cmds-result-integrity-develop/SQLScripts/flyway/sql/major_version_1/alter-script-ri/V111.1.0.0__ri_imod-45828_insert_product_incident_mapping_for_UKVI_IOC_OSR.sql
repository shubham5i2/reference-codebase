--UKVI IOC OSR AC

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('c2003df3-9676-4d61-a071-a4086221d58c','de58e8e0-39c6-4c54-b62e-40cacbc6c56d' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'INC_STATUS_FLAGGED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('0206a6a7-3c5e-4650-9e1c-a4742f8bd83a','de58e8e0-39c6-4c54-b62e-40cacbc6c56d' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('0e109a58-94f1-4529-b5b1-760c6e24b398','de58e8e0-39c6-4c54-b62e-40cacbc6c56d' ,
'fe29aad2-6971-4f04-8321-d800eac26c6f', null, 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('abe72e84-8adb-4cbe-be54-974211eceae9','de58e8e0-39c6-4c54-b62e-40cacbc6c56d' ,
'1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9', null, 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('5f4197ce-a5b7-48f2-9e3f-0a204d5112e6','de58e8e0-39c6-4c54-b62e-40cacbc6c56d' ,
'0e5567b0-30ac-4518-b245-6093f3bc24b0', null, 'INC_STATUS_CONFIRMED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('668c9f25-15f4-43f5-a40d-4227b8d83303','de58e8e0-39c6-4c54-b62e-40cacbc6c56d' ,
'ffc3db8f-6a8e-4923-8e52-d5dabc51328a', null, 'INC_STATUS_FLAGGED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('21f3f9b7-40d4-444d-8d15-2bbfc9afbeb9','de58e8e0-39c6-4c54-b62e-40cacbc6c56d' ,
'29b6aa56-8316-44d9-80d0-d5010a0a8518', null, 'INC_STATUS_FOLLOW_UP_REQUIRED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;







--UKVI IOC OSR GT

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('b6785ee9-7488-4402-a31f-33c15bf3c688','fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'INC_STATUS_FLAGGED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('cdf9829d-5ac1-4932-8354-da2161d78c9c','fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('4376b8ef-3804-4bb5-9e6c-edca9ee70036','fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db' ,
'fe29aad2-6971-4f04-8321-d800eac26c6f', null, 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('728fee35-e71d-403b-b9d4-ffce7e2235ce','fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db' ,
'1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9', null, 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('5387158e-e5b8-43e0-803f-50e94fee3235','fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db' ,
'ffc3db8f-6a8e-4923-8e52-d5dabc51328a', null, 'INC_STATUS_FLAGGED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('c4b2b9a3-42c8-4f04-b028-b14350dfb1cf','fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db' ,
'0e5567b0-30ac-4518-b245-6093f3bc24b0', null, 'INC_STATUS_CONFIRMED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('0a1a9e06-137f-4510-8c49-b9055f69727d','fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db' ,
'29b6aa56-8316-44d9-80d0-d5010a0a8518', null, 'INC_STATUS_FOLLOW_UP_REQUIRED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;