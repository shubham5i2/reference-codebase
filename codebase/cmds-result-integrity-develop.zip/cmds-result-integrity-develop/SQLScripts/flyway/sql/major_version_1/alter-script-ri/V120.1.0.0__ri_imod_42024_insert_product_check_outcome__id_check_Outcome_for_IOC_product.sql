-- IOC AC
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('442dded5-bab0-4496-95b2-dc10cf7605ea','fdbacec5-e80a-4710-b3de-7d5f310b1466'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-02-10 19:07:46.516', '2023-02-10 19:07:46.516', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;


-- IOC GT
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('6144ba27-5be4-49cc-b2c6-7a8772fd6b93','cf9a05e9-2679-42da-b7d2-b34ea3e0724e'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-02-10 19:07:46.516', '2023-02-10 19:07:46.516', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;




--UKVI IOC AC

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('ae57ea3e-b62f-4d4e-85fb-c658e183e277','6d04f596-22f2-49c4-9d47-85b167b8ca6f'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-02-10 19:07:46.516', '2023-02-10 19:07:46.516', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;


--UKVI IOC GT
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('d0aa992e-6e29-4395-a9cf-35f336f54527','54b9d8df-c07a-4cb4-b397-adc4faa87c3f'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-02-10 19:07:46.516', '2023-02-10 19:07:46.516', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;




-- SSR IOC AC Listening
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('6c97aa78-1537-48cf-8272-83f368b7fcac','17e0db26-7f58-40ae-b5a8-999fb68dca96'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-02-10 19:07:46.516', '2023-02-10 19:07:46.516', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

-- SSR IOC AC Reading
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('d652be62-16be-4c82-b4fc-bb99b9dd4f7a','6b2c8f4a-e94f-44c8-8575-22987e5aef17'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-02-10 19:07:46.516', '2023-02-10 19:07:46.516', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

-- SSR IOC AC Writing
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('cbbb4b95-876e-4f3c-bce2-a1677c586038','bb1895b0-f302-4e4c-8bc9-07265f0eadd7'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-02-10 19:07:46.516', '2023-02-10 19:07:46.516', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

-- SSR IOC AC Speaking
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('76d1b5db-3078-4912-b41a-cb474ddce2ae','ff045df4-8c11-4bd8-b2d3-a94aa56a7877'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-02-10 19:07:46.516', '2023-02-10 19:07:46.516', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;


-- SSR IOC GT Listening
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('d56b07e5-58ab-4670-9966-2f029694e105','e1d9b3fb-d428-4342-9656-50470cde4c39'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-02-10 19:07:46.516', '2023-02-10 19:07:46.516', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

-- SSR IOC GT Reading
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('424d505d-2650-42d2-b92d-407dadcb37df','74193427-ccae-4227-8577-9950c9f79d47'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-02-10 19:07:46.516', '2023-02-10 19:07:46.516', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

-- SSR IOC GT Writing
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('0c4cd268-35f6-41c2-8280-92c1448ce5c5','64ada755-5cb3-46ed-b90c-69bd88230402'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-02-10 19:07:46.516', '2023-02-10 19:07:46.516', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

-- SSR IOC GT Speaking
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('0a7fadbe-c0c0-4975-9260-c16b708d0664','4acd484a-958c-42f1-9cdd-fc5f8e12d5da'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-02-10 19:07:46.516', '2023-02-10 19:07:46.516', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;