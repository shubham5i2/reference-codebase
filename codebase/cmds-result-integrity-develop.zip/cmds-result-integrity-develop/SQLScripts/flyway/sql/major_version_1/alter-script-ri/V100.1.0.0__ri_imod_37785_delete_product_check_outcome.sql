DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='39da499f-aa3f-4e90-9a49-b37522f7c652'::uuid;
DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='42953261-196d-4ae3-95ae-d7c3c72d7885'::uuid;
DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='fd7284e1-4bb4-4f81-9004-f94bb3eaf18c'::uuid;
DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='096729c2-0ae3-423b-b0b0-591ff0394029'::uuid;
DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='8cc40ee0-d111-486b-9011-a120f21d2ebf'::uuid;
DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='cbf2922f-5005-4a77-8fe2-6327f01aa6b7'::uuid;
DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='865a3408-a208-49d7-9d21-04b52bab7505'::uuid;
DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='f7c222cc-5354-48ee-8ab4-c40c1e6775d4'::uuid;
DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='1ba29fc3-3ae7-4a4a-ae9c-9e8a1faef0e7'::uuid;
DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='2da8feda-4569-4efc-bea9-243e0b445a06'::uuid;
DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='667f4606-2712-43de-8009-6a28958c88b3'::uuid;
DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='7aae32c3-0329-4bbc-9e02-390340b472ad'::uuid;
DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='bbe4e733-0885-4f21-bef8-85429ef5e047'::uuid;
DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='8763ece8-bd9c-4ec4-942e-0e5cbba51143'::uuid;
DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='b0fe9c5a-62ae-4d24-b701-6b33e2382592'::uuid;
DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='bf04feb7-99d2-4a28-9ad4-07259394f905'::uuid;
DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='7ff8ece5-1d63-49c0-9f7b-dda40aea796a'::uuid;
DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='94cbed58-869a-429d-a1b1-1d4361b35a0b'::uuid;
DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='755b9fff-11e5-41bc-9764-a7c06e6d5865'::uuid;
DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='47035e39-a6be-455b-b626-28551141b946'::uuid;
DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='7d5d6615-efe0-4555-8e1a-56395ca6ef90'::uuid;
DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='89ef43c0-e958-4f02-9c19-3728413a8193'::uuid;
