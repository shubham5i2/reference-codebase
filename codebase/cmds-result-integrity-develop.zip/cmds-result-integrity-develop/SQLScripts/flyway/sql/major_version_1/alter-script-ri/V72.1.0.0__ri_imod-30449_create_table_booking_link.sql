-- Create ENUM Booking Link Role
DO $$ BEGIN CREATE TYPE ri_owner.booking_role_enum AS ENUM (
    'SSRORIGINAL'
    );
EXCEPTION
WHEN duplicate_object THEN null;
END $$;


CREATE TABLE IF NOT EXISTS ri_owner.booking_link(
	booking_link_uuid uuid NOT NULL,
	role ri_owner.booking_role_enum NOT NULL,
	source_booking_uuid uuid NOT NULL,
	target_booking_uuid uuid NOT NULL,
    created_datetime TIMESTAMPTZ NOT NULL,
    updated_datetime TIMESTAMPTZ NOT NULL,
    concurrency_version integer NOT NULL,
	CONSTRAINT pk_01_booking_link_uuid PRIMARY KEY (booking_link_uuid),
	CONSTRAINT fk_01_source_booking_uuid FOREIGN KEY (source_booking_uuid) References ri_owner.booking(booking_uuid),
	CONSTRAINT fk_02_target_booking_uuid FOREIGN KEY (target_booking_uuid) References ri_owner.booking(booking_uuid)
);