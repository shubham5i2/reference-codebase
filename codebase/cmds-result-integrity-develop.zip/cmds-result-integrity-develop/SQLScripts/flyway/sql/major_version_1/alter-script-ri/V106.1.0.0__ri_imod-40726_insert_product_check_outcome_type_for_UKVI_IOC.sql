--UKVI IOC AC

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('93842767-10c1-427c-bde4-1101a4f21782','6d04f596-22f2-49c4-9d47-85b167b8ca6f'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2023-01-27 19:31:11.805', '2023-01-27 19:31:11.805', 0, 'LRW_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('00946ca9-647f-430a-8835-12b872eb0d76', '6d04f596-22f2-49c4-9d47-85b167b8ca6f'::uuid, 'c6eebce9-d53e-430b-ad36-44ed9ce2872a'::uuid, '2023-01-27 19:31:11.805', '2023-01-27 19:31:11.805', 0, 'SPK_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('beb40b42-cd6d-4561-bf25-040154c36369','6d04f596-22f2-49c4-9d47-85b167b8ca6f'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2023-01-27 19:31:11.805', '2023-01-27 19:31:11.805', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('5b456a5b-1099-455f-a2da-ed63e6963e53','6d04f596-22f2-49c4-9d47-85b167b8ca6f'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2023-01-27 19:31:46.516', '2023-01-27 19:31:46.516', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;








--UKVI IOC GT
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('951c5bbb-27fb-4b2d-bdfd-bb6628a504a3','54b9d8df-c07a-4cb4-b397-adc4faa87c3f'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2023-01-27 19:31:11.805', '2023-01-27 19:31:11.805', 0, 'LRW_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('ba9fa311-c3da-4a5e-b1db-be2005942353','54b9d8df-c07a-4cb4-b397-adc4faa87c3f'::uuid, 'c6eebce9-d53e-430b-ad36-44ed9ce2872a'::uuid, '2023-01-27 19:31:11.805', '2023-01-27 19:31:11.805', 0, 'SPK_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('8918028c-801f-4c71-aaad-c85848696d39','54b9d8df-c07a-4cb4-b397-adc4faa87c3f'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2023-01-27 19:31:11.805', '2023-01-27 19:31:11.805', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('d1be61b4-a133-4509-b025-070964956b6e','54b9d8df-c07a-4cb4-b397-adc4faa87c3f'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2023-01-27 19:31:11.805', '2023-01-27 19:31:11.805', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;


