CREATE TABLE IF NOT EXISTS ri_owner.product_incident_mapping (

	product_incident_mapping_uuid uuid not null,
	product_uuid uuid,
	incident_category_uuid uuid,
	incident_severity ri_owner."incident_severity_enum",
	incident_status_type_code varchar(50),
	CONSTRAINT pk_01_id PRIMARY KEY (product_incident_mapping_uuid)
	
	);