DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='7ddc5aab-3fce-4f4e-abd9-f9db0988e6d5'::uuid;
DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='a1181afb-6953-4eb3-bfca-0c750ab0128f'::uuid;
DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='53127ee2-fe21-4adf-84e1-5f11969c33c9'::uuid;



INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid, product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('7ddc5aab-3fce-4f4e-abd9-f9db0988e6d5'::uuid, 'fdbacec5-e80a-4710-b3de-7d5f310b1466'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2022-09-20 00:37:46.516', '2022-09-20 00:37:46.516', 0, 'LRW_INC_CHK');
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid, product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('a1181afb-6953-4eb3-bfca-0c750ab0128f'::uuid, 'fdbacec5-e80a-4710-b3de-7d5f310b1466'::uuid, 'c6eebce9-d53e-430b-ad36-44ed9ce2872a'::uuid, '2022-09-20 00:37:52.439', '2022-09-20 00:37:52.439', 0, 'SPK_INC_CHK');
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid, product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('53127ee2-fe21-4adf-84e1-5f11969c33c9'::uuid, 'fdbacec5-e80a-4710-b3de-7d5f310b1466'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2022-09-20 00:37:58.173', '2022-09-20 00:37:58.173', 0, 'PRC_INC_CHK');