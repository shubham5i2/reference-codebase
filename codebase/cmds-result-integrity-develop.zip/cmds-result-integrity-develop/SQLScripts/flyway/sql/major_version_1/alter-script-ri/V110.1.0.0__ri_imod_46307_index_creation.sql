CREATE INDEX IF NOT EXISTS idx_booking_external_booking_uuid ON ri_owner.booking USING btree (external_booking_uuid);
CREATE INDEX IF NOT EXISTS idx_booking_line_booking_uuid ON ri_owner.booking_line USING btree (booking_uuid);
CREATE INDEX IF NOT EXISTS idx_booking_line_end_datetime ON ri_owner.booking_line USING btree (end_datetime);
CREATE INDEX IF NOT EXISTS idx_booking_link_source_booking_uuid ON ri_owner.booking_link USING btree (source_booking_uuid);
CREATE INDEX IF NOT EXISTS idx_check_outcome_booking_uuid ON ri_owner.check_outcome USING btree (booking_uuid);
CREATE INDEX IF NOT EXISTS idx_incident_booking_uuid ON ri_owner.incident USING btree (booking_uuid);
CREATE INDEX IF NOT EXISTS idx_outcome_status_booking_uuid ON ri_owner.outcome_status USING btree (booking_uuid);
CREATE INDEX IF NOT EXISTS idx_prc_outcome_details_booking_uuid ON ri_owner.prc_outcome_details USING btree (booking_uuid);