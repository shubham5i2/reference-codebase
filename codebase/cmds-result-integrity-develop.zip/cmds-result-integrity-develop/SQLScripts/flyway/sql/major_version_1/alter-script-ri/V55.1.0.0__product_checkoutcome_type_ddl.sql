CREATE TABLE ri_owner.product_check_outcome_type (
	product_check_outcome_type_uuid uuid NOT NULL,
	product_uuid uuid NOT NULL,
	check_outcome_type_uuid uuid NOT NULL,
	created_datetime timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_datetime timestamptz NULL,
	concurrency_version int4 NOT NULL DEFAULT 0,
	check_outcome_type_code varchar(50) NOT NULL,
	CONSTRAINT pk_01_prod_chk_out PRIMARY KEY (product_check_outcome_type_uuid)
);