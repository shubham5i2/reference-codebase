ALTER TABLE ri_owner.booking  ADD COLUMN IF NOT EXISTS booking_version integer;
ALTER TABLE ri_owner.check_outcome  ADD COLUMN IF NOT EXISTS booking_version integer;
ALTER TABLE ri_owner.outcome_status  ADD COLUMN IF NOT EXISTS booking_version integer;