CREATE TABLE IF NOT EXISTS ri_owner.result_integrity_semaphore (
	 semaphore_name VARCHAR(100) NOT NULL,
	 CONSTRAINT pk_result_integrity_semaphore PRIMARY KEY (semaphore_name)
);

INSERT INTO ri_owner.result_integrity_semaphore(semaphore_name) values('OverallIntegrityCheckInitiated') ON CONFLICT DO NOTHING;