
DROP VIEW ri_owner.booking_line_outcome_view;

CREATE OR REPLACE VIEW ri_owner.booking_line_outcome_view
AS SELECT filtered_chkoutcome.booking_uuid,
    filtered_chkoutcome.check_outcome_received,
    filtered_chkoutcome.id,
    filtered_chkoutcome.booking_version
   FROM ( SELECT bl.booking_uuid,
          string_agg(DISTINCT cot2.check_outcome_type_code, ',') AS check_outcome_received,
          ri_owner.uuid_generate_v4() AS id,
          b.booking_version
           FROM ri_owner.booking b
             JOIN ri_owner.booking_line bl ON b.booking_uuid = bl.booking_uuid
             JOIN ri_owner.outcome_status os ON bl.booking_uuid = os.booking_uuid
             JOIN ri_owner.outcome_status_type ost ON ost.outcome_status_type_uuid = os.outcome_status_type_uuid
             JOIN ri_owner.check_outcome co ON co.booking_uuid = bl.booking_uuid
             JOIN ri_owner.check_outcome_type cot2 ON cot2.check_outcome_type_uuid = co.check_outcome_type_uuid
          WHERE (ost.outcome_status_type_code = ANY (ARRAY['OUT_STATUS_IN_PROGRESS', 'OUT_STATUS_REFER', 'OUT_STATUS_REVIEW']))
          AND bl.booking_line_status = 'ACTIVE'
          and exists(select booking_uuid from ri_owner.check_outcome co2 where co2.booking_uuid=b.booking_uuid
          and co2.check_outcome_type_uuid='005ef982-3749-4a59-98c9-5da13fed6017')
          GROUP BY bl.booking_uuid, b.booking_version
          having max(bl.end_datetime) <now()-'24:00:00'::interval) filtered_chkoutcome
  WHERE filtered_chkoutcome.check_outcome_received !~~ '%SPK_INC_CHK%LRW_INC_CHK%'
 AND filtered_chkoutcome.check_outcome_received !~~ '%LRW_INC_CHK%SPK_INC_CHK%'
AND filtered_chkoutcome.check_outcome_received !~~ 'PROB_BANNED_INC_CHK';
