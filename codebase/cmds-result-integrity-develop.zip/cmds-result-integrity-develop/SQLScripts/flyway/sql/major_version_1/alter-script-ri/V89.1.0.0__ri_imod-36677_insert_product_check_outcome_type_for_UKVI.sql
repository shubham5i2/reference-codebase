INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('112735f7-1d35-4d1a-9c15-3f0678e3ca91','4ca26fd2-5216-4e9a-ba08-89bb94599778'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2022-10-07 19:31:11.805', '2022-10-07 19:31:11.805', 0, 'LRW_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('5fdb9f2f-9458-4817-a7b6-537ebf779e9a','4ca26fd2-5216-4e9a-ba08-89bb94599778'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2022-10-07 19:31:11.805', '2022-10-07 19:31:11.805', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('e382ab20-e1bd-4e80-beae-9728c2f3affa', '4ca26fd2-5216-4e9a-ba08-89bb94599778'::uuid, 'c6eebce9-d53e-430b-ad36-44ed9ce2872a'::uuid, '2022-10-07 19:31:11.805', '2022-10-07 19:31:11.805', 0, 'SPK_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('8e34c05e-af5d-4cec-8879-c19c425a3a3e','4ca26fd2-5216-4e9a-ba08-89bb94599778'::uuid, '98760142-bace-4bb0-b2a9-d90b9b393553'::uuid, '2022-10-07 19:31:11.805', '2022-10-07 19:31:11.805', 0, 'PLG_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('8b560b3d-670a-4f3c-a83e-128d3db0f027','4ca26fd2-5216-4e9a-ba08-89bb94599778'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2022-10-07 19:31:11.805', '2022-10-07 19:31:11.805', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;








INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('8dcc79e1-7c62-4097-9a04-e9ce4b08280b','0b0e3eb3-7929-4e38-bc63-dea6ffe6def8'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2022-10-07 19:31:11.805', '2022-10-07 19:31:11.805', 0, 'LRW_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('22c2d983-2e4c-4297-94f6-0a79e8025a04','0b0e3eb3-7929-4e38-bc63-dea6ffe6def8'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2022-10-07 19:31:11.805', '2022-10-07 19:31:11.805', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('56b46ece-da8f-4a7c-a8b1-b16f45c48fec', '0b0e3eb3-7929-4e38-bc63-dea6ffe6def8'::uuid, 'c6eebce9-d53e-430b-ad36-44ed9ce2872a'::uuid, '2022-10-07 19:31:11.805', '2022-10-07 19:31:11.805', 0, 'SPK_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('91b52fb9-f7f4-43c2-9e1a-e547355cb168','0b0e3eb3-7929-4e38-bc63-dea6ffe6def8'::uuid, '98760142-bace-4bb0-b2a9-d90b9b393553'::uuid, '2022-10-07 19:31:11.805', '2022-10-07 19:31:11.805', 0, 'PLG_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('0499e52a-b138-4aef-8946-2e4534849483','0b0e3eb3-7929-4e38-bc63-dea6ffe6def8'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2022-10-07 19:31:11.805', '2022-10-07 19:31:11.805', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;



