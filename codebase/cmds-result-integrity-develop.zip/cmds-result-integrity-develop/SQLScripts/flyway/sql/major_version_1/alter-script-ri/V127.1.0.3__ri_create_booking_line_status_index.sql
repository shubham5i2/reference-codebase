CREATE INDEX IF NOT EXISTS idx_booking_line_booking_line_status
ON ri_owner.booking_line(booking_line_status);
