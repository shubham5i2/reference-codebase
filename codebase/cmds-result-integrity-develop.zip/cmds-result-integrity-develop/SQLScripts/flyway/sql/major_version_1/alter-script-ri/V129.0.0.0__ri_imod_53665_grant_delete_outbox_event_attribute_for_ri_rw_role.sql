DO $$
BEGIN
IF NOT EXISTS (select * from information_schema.role_table_grants Where grantee = 'ri_rw_role'
AND table_name = 'outbox_event_attribute' AND privilege_type='DELETE')
THEN
  GRANT DELETE ON ri_owner.outbox_event_attribute TO ri_rw_role;
END IF;
END $$;

