delete from ri_owner.incident_type where incident_type_uuid = '869311b9-d77f-450d-af85-84243d1c91ea'::uuid;
delete from ri_owner.incident_type where incident_type_uuid = '447c1c5a-1b10-44c4-852f-e2e6e59c4724'::uuid;
delete from ri_owner.incident where incident_type_uuid = '869311b9-d77f-450d-af85-84243d1c91ea'::uuid;
delete from ri_owner.incident where incident_type_uuid = '447c1c5a-1b10-44c4-852f-e2e6e59c4724'::uuid;