-- IOL AC
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('39da499f-aa3f-4e90-9a49-b37522f7c652','3e81e94b-8b6a-42b5-970c-b141f9d195a3'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2022-11-04 19:07:46.516', '2022-11-04 19:07:46.516', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

-- IOL GT
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('42953261-196d-4ae3-95ae-d7c3c72d7885','d96eece2-1d7c-495a-a754-6b523b710a82'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2022-11-04 19:07:46.516', '2022-11-04 19:07:46.516', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

-- IOC AC
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('fd7284e1-4bb4-4f81-9004-f94bb3eaf18c','fdbacec5-e80a-4710-b3de-7d5f310b1466'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2022-11-04 19:07:46.516', '2022-11-04 19:07:46.516', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

-- IOC GT
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('096729c2-0ae3-423b-b0b0-591ff0394029','cf9a05e9-2679-42da-b7d2-b34ea3e0724e'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2022-11-04 19:07:46.516', '2022-11-04 19:07:46.516', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

-- UKVI IOL AC
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('8cc40ee0-d111-486b-9011-a120f21d2ebf','4ca26fd2-5216-4e9a-ba08-89bb94599778'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2022-11-04 19:07:46.516', '2022-11-04 19:07:46.516', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

-- UKVI IOL GT
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('cbf2922f-5005-4a77-8fe2-6327f01aa6b7','0b0e3eb3-7929-4e38-bc63-dea6ffe6def8'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2022-11-04 19:07:46.516', '2022-11-04 19:07:46.516', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

-- SSR IOL AC Listening
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('865a3408-a208-49d7-9d21-04b52bab7505','bb71c4bb-ba26-4569-99fa-fb3d2aec1120'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2022-11-04 19:07:46.516', '2022-11-04 19:07:46.516', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

-- SSR IOL AC Reading
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('f7c222cc-5354-48ee-8ab4-c40c1e6775d4','95fa3301-e17c-4467-bab5-f4754765ad4d'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2022-11-04 19:07:46.516', '2022-11-04 19:07:46.516', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;


-- SSR IOL AC Writing
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('1ba29fc3-3ae7-4a4a-ae9c-9e8a1faef0e7','9cdec6ab-7886-476a-a586-13dfda9a52a9'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2022-11-04 19:07:46.516', '2022-11-04 19:07:46.516', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

-- SSR IOL AC Speaking
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('2da8feda-4569-4efc-bea9-243e0b445a06','deea53e9-886b-4dee-b0b2-9ab29c70a82e'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2022-11-04 19:07:46.516', '2022-11-04 19:07:46.516', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

-- SSR IOL GT Listening
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('667f4606-2712-43de-8009-6a28958c88b3','304d2fa4-642d-4ec7-8600-ae21eb8b4dd8'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2022-11-04 19:07:46.516', '2022-11-04 19:07:46.516', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;


-- SSR IOL GT Reading
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('7aae32c3-0329-4bbc-9e02-390340b472ad','d5d4392d-b3c7-4a99-b039-98a281c0104d'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2022-11-04 19:07:46.516', '2022-11-04 19:07:46.516', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;


-- SSR IOL GT Writing
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('bbe4e733-0885-4f21-bef8-85429ef5e047','c5524e22-ec61-4705-b7d1-5818826b7cd1'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2022-11-04 19:07:46.516', '2022-11-04 19:07:46.516', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

-- SSR IOL GT Speaking
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('8763ece8-bd9c-4ec4-942e-0e5cbba51143','a489fddd-9bb5-4ed4-9678-0a88bde4778c'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2022-11-04 19:07:46.516', '2022-11-04 19:07:46.516', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;


-- SSR IOC AC Listening
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('b0fe9c5a-62ae-4d24-b701-6b33e2382592','17e0db26-7f58-40ae-b5a8-999fb68dca96'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2022-11-04 19:07:46.516', '2022-11-04 19:07:46.516', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

-- SSR IOC AC Reading
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('bf04feb7-99d2-4a28-9ad4-07259394f905','6b2c8f4a-e94f-44c8-8575-22987e5aef17'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2022-11-04 19:07:46.516', '2022-11-04 19:07:46.516', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;


-- SSR IOC AC Writing
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('7ff8ece5-1d63-49c0-9f7b-dda40aea796a','bb1895b0-f302-4e4c-8bc9-07265f0eadd7'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2022-11-04 19:07:46.516', '2022-11-04 19:07:46.516', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

-- SSR IOC AC Speaking
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('94cbed58-869a-429d-a1b1-1d4361b35a0b','ff045df4-8c11-4bd8-b2d3-a94aa56a7877'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2022-11-04 19:07:46.516', '2022-11-04 19:07:46.516', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;


-- SSR IOC GT Listening
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('755b9fff-11e5-41bc-9764-a7c06e6d5865','e1d9b3fb-d428-4342-9656-50470cde4c39'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2022-11-04 19:07:46.516', '2022-11-04 19:07:46.516', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;


-- SSR IOC GT Reading
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('a5416e5f-54ea-418f-9d1f-468d35dae957','74193427-ccae-4227-8577-9950c9f79d47'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2022-11-04 19:07:46.516', '2022-11-04 19:07:46.516', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;


-- SSR IOC GT Writing
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('47035e39-a6be-455b-b626-28551141b946','64ada755-5cb3-46ed-b90c-69bd88230402'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2022-11-04 19:07:46.516', '2022-11-04 19:07:46.516', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

-- SSR IOC GT Speaking
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('7d5d6615-efe0-4555-8e1a-56395ca6ef90','4acd484a-958c-42f1-9cdd-fc5f8e12d5da'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2022-11-04 19:07:46.516', '2022-11-04 19:07:46.516', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

-- SSR IOC GT Reading
INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('89ef43c0-e958-4f02-9c19-3728413a8193','74193427-ccae-4227-8577-9950c9f79d47'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2022-11-04 19:07:46.516', '2022-11-04 19:07:46.516', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;
