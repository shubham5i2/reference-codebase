CREATE OR REPLACE VIEW ri_owner.incident_view
AS SELECT b.booking_uuid,
    b.first_name,
    b.last_name,
    b.test_date,
    b.identity_number,
    b.unique_test_taker_uuid,
    b.short_candidate_number,
    b.product_uuid,
    b.location_uuid,
    u.unique_test_taker,
    i.incident_uuid,
    i.incident_category_uuid,
    i.incident_type_uuid,
    i.incident_severity,
    it.ban_review_required,
    st.incident_status_type_uuid,
    l.test_centre_number AS centre_id,
    ri_owner.uuid_generate_v4() AS id,
    i.created_datetime
   FROM ri_owner.incident i
     JOIN ri_owner.booking b ON i.booking_uuid = b.booking_uuid
     JOIN ri_owner.incident_type it ON i.incident_type_uuid = it.incident_type_uuid
     JOIN ri_owner.incident_status_type st ON i.incident_status_type_uuid = st.incident_status_type_uuid
     JOIN ri_owner.location l ON b.location_uuid = l.location_uuid
     JOIN ri_owner.unique_test_taker u ON b.unique_test_taker_uuid = u.unique_test_taker_uuid
  WHERE st.visible_in_ui = true;