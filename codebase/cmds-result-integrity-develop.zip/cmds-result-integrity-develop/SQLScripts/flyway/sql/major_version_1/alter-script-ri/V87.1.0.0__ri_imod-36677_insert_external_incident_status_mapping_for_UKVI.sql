INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('ebc52fc1-d065-4187-98bc-1aa884cfbe69','4ca26fd2-5216-4e9a-ba08-89bb94599778' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('4079f60b-c772-4cbd-8eb5-ff98480610b9','4ca26fd2-5216-4e9a-ba08-89bb94599778' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CONFIRMED', 'INC_STATUS_CONFIRMED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('aff4210b-e130-423b-9f2a-a41930e25623','4ca26fd2-5216-4e9a-ba08-89bb94599778' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('39e2812c-4e7e-454b-b685-9b58a5a8fb60','4ca26fd2-5216-4e9a-ba08-89bb94599778' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('b09f2657-4853-4ab0-8b01-e9400072361a','4ca26fd2-5216-4e9a-ba08-89bb94599778' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CONFIRMED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('810a3888-3b2e-4122-8a8a-5c3f01ecba87','4ca26fd2-5216-4e9a-ba08-89bb94599778' ,'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('6c07743a-6eb5-4145-8487-afeec67b1564','4ca26fd2-5216-4e9a-ba08-89bb94599778' ,'fe29aad2-6971-4f04-8321-d800eac26c6f', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('54736e88-f3d3-47c9-a341-e8fed33d3b81','4ca26fd2-5216-4e9a-ba08-89bb94599778' ,'1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('7f592c8e-0beb-4677-a3d2-be3a1432c94b','4ca26fd2-5216-4e9a-ba08-89bb94599778' ,'0e5567b0-30ac-4518-b245-6093f3bc24b0', null, null, 'INC_STATUS_CONFIRMED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('7e3f3a9a-891d-4631-aaae-e78440c9c285','4ca26fd2-5216-4e9a-ba08-89bb94599778' ,'ffc3db8f-6a8e-4923-8e52-d5dabc51328a', null, null, 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;








INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('50be13f4-a5c2-4f03-afe7-a8ecaf460546','0b0e3eb3-7929-4e38-bc63-dea6ffe6def8' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('5b823c64-00b0-419c-83cf-e0ceb96c71f0','0b0e3eb3-7929-4e38-bc63-dea6ffe6def8' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CONFIRMED', 'INC_STATUS_CONFIRMED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('cad34884-24dc-456b-92a6-52d00dade97b','0b0e3eb3-7929-4e38-bc63-dea6ffe6def8' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('d717ea75-f933-4219-acd9-878ff4a09fb8','0b0e3eb3-7929-4e38-bc63-dea6ffe6def8' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('1b0b0b24-8b00-4ce1-833e-1c9a6a0a811f','0b0e3eb3-7929-4e38-bc63-dea6ffe6def8' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CONFIRMED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('5c71a2bd-ee24-4fd7-ad14-ca4ac63668d3','0b0e3eb3-7929-4e38-bc63-dea6ffe6def8' ,'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('da37a5d6-c461-4e20-8927-c95ecb883e27','0b0e3eb3-7929-4e38-bc63-dea6ffe6def8' ,'fe29aad2-6971-4f04-8321-d800eac26c6f', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('32b6506f-a0b4-48be-b456-5ad41fb1b91a','0b0e3eb3-7929-4e38-bc63-dea6ffe6def8' ,'1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('b689b859-f5e0-4e42-8304-cc415c2af239','0b0e3eb3-7929-4e38-bc63-dea6ffe6def8' ,'0e5567b0-30ac-4518-b245-6093f3bc24b0', null, null, 'INC_STATUS_CONFIRMED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('318c0391-c0ed-4486-8d00-02ba07698abd','0b0e3eb3-7929-4e38-bc63-dea6ffe6def8' ,'ffc3db8f-6a8e-4923-8e52-d5dabc51328a', null, null, 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;




