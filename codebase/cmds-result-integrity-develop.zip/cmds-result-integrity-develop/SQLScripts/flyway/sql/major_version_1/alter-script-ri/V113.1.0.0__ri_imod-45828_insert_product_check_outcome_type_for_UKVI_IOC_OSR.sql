--UKVI IOC OSR AC

--IELTS OSR SELT on Computer AC LISTENING
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('d9956d67-ac46-4958-87a7-f04facef085c','7768ff79-1c44-4b7d-818f-a935afcb9d94'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'LRW_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('440b65bb-0d31-44a6-bdd9-d3ed2bf744a6','7768ff79-1c44-4b7d-818f-a935afcb9d94'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('f990e305-3ec6-410d-858f-4fa01ad3f073','7768ff79-1c44-4b7d-818f-a935afcb9d94'::uuid,'760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('9865e92a-ff65-42b8-a99b-0b89ea7dc335','7768ff79-1c44-4b7d-818f-a935afcb9d94'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;


--IELTS OSR SELT on Computer AC SPEAKING

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('e5116fba-925f-49d8-9775-9141a0118565', 'c3e46fcc-b54f-49ae-8675-e373db8e6dc2'::uuid, 'c6eebce9-d53e-430b-ad36-44ed9ce2872a'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'SPK_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('2b51ff89-3c6a-4c5e-a2eb-df810dc224f4','c3e46fcc-b54f-49ae-8675-e373db8e6dc2'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('3a9dc25a-4fca-44f6-92e1-7a5317382fd1','c3e46fcc-b54f-49ae-8675-e373db8e6dc2'::uuid,'760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('d8bc3906-6738-44a1-bc09-b99c4cd5a2fc','c3e46fcc-b54f-49ae-8675-e373db8e6dc2'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;


-- IELTS OSR SELT on Computer AC READING
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('b88e570c-ec97-40c8-8bde-22c2f43e648d','d8f6415d-c36f-4a2c-9c44-bbf0e4c65530'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'LRW_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('ae247e43-9969-447e-bc11-c40861ff15c4','d8f6415d-c36f-4a2c-9c44-bbf0e4c65530'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('7084b669-0205-47b0-90d1-6524dd7f857a','d8f6415d-c36f-4a2c-9c44-bbf0e4c65530'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('4bb72b27-0a0d-4043-af21-b9740cea73ce','d8f6415d-c36f-4a2c-9c44-bbf0e4c65530'::uuid,'760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

--IELTS OSR SELT on Computer AC W
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('b2a2d28d-723c-4db9-9354-a386b94c34c9','edd31fef-dd28-4c0a-a593-3cd3b1b74838'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'LRW_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('9a28bcf2-6a49-4c25-9230-a71dec4b9853','edd31fef-dd28-4c0a-a593-3cd3b1b74838'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('f9887ece-d2dc-442e-bd25-e1526f624829','edd31fef-dd28-4c0a-a593-3cd3b1b74838'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('34692dcb-ef58-4d0e-8fc5-2f9c05d73034','edd31fef-dd28-4c0a-a593-3cd3b1b74838'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;





--UKVI IOC OSR GT

--IELTS OSR SELT on Computer GT LISTENING
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('1f912825-353b-4dde-ad00-a1c892bc4ff8','42c488cc-2230-4842-b2aa-fe103f006aa7'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'LRW_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('1c6071c7-d5fc-40ed-a5d3-6cd0ca0cb4df','42c488cc-2230-4842-b2aa-fe103f006aa7'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('522e03ad-aa05-43e2-86a6-ee7eb06cdd1e','42c488cc-2230-4842-b2aa-fe103f006aa7'::uuid,'760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('b0973458-ee55-45f3-976c-5270cd1b9850','42c488cc-2230-4842-b2aa-fe103f006aa7'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

-- IELTS OSR SELT on Computer GT READING
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('b97aeb6f-0363-43a5-98e7-f2b4a42605cc','b6e7b55e-c21e-4002-8c0b-a9f66f8bce61'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'LRW_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('4883618d-7779-4786-a844-4957b057b01c','b6e7b55e-c21e-4002-8c0b-a9f66f8bce61'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('4c3f1cc1-081a-486b-8de5-dfa15d5ac318','b6e7b55e-c21e-4002-8c0b-a9f66f8bce61'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('0946c10e-448f-439c-b486-ea7230b9fdcf','b6e7b55e-c21e-4002-8c0b-a9f66f8bce61'::uuid,'760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

--IELTS OSR SELT on Computer GT W
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('53838dee-4f9d-459b-87b8-3e1d592ade06','a6bf0168-7ed0-49b9-959b-d526ff1087fa'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'LRW_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('e140a7da-5cf7-4d00-b2db-38837ed30de0','a6bf0168-7ed0-49b9-959b-d526ff1087fa'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('ee3183e8-be0e-430e-93aa-a1d26462bfa7','a6bf0168-7ed0-49b9-959b-d526ff1087fa'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('a611acbc-e851-4cc6-ae91-30156368d252','a6bf0168-7ed0-49b9-959b-d526ff1087fa'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;


--IELTS OSR SELT on Computer GT SPEAKING

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('0b16c552-438b-44d3-83a0-a86d2117de4f', 'e73dbfad-a961-4c7e-9fba-e196a2703bb8'::uuid, 'c6eebce9-d53e-430b-ad36-44ed9ce2872a'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'SPK_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('a75b9f2d-0683-4408-9fea-513243f4b2fb','e73dbfad-a961-4c7e-9fba-e196a2703bb8'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('b143806e-7025-43a1-af01-ce0c2816f482','e73dbfad-a961-4c7e-9fba-e196a2703bb8'::uuid,'760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('8f903cf7-ee53-4333-9ac4-02dc148c6cc6','e73dbfad-a961-4c7e-9fba-e196a2703bb8'::uuid, 'b324c90d-5042-4a6e-9600-aef826186b3d'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'PROB_BANNED_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;


