DO $$ BEGIN  CREATE TYPE ri_owner."photo_category_enum" AS ENUM
    ('Certificate', 'Other');
        EXCEPTION  WHEN duplicate_object THEN null;
END $$;

ALTER TABLE ri_owner.test_taker_photo ADD COLUMN IF NOT EXISTS photo_category ri_owner."photo_category_enum";
