ALTER TABLE ri_owner.incident_evidence ALTER COLUMN updated_datetime DROP NOT NULL;
ALTER TABLE ri_owner.incident_comment ALTER COLUMN updated_datetime DROP NOT NULL;
