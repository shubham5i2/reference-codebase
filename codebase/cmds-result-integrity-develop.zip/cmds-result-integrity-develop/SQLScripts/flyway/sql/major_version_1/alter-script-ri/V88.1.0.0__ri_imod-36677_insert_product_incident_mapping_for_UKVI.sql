INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('9c98cfa6-5406-4199-b33d-160cec406f47','4ca26fd2-5216-4e9a-ba08-89bb94599778' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'INC_STATUS_CONFIRMED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('1f8011a5-be38-478a-86f3-5b6e7aa19e7b','4ca26fd2-5216-4e9a-ba08-89bb94599778' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('592467e2-5f3b-471a-97a8-61c877184ddf','4ca26fd2-5216-4e9a-ba08-89bb94599778' ,
'fe29aad2-6971-4f04-8321-d800eac26c6f', null, 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('465556e4-3542-488b-93e0-126fe3aedd40','4ca26fd2-5216-4e9a-ba08-89bb94599778' ,
'1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9', null, 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('22fed6ee-4cfe-4869-9b39-abf2d3f08209','4ca26fd2-5216-4e9a-ba08-89bb94599778' ,
'0e5567b0-30ac-4518-b245-6093f3bc24b0', null, 'INC_STATUS_CONFIRMED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('7abf85bf-544e-4525-a420-b7760cdb6386','4ca26fd2-5216-4e9a-ba08-89bb94599778' ,
'ffc3db8f-6a8e-4923-8e52-d5dabc51328a', null, 'INC_STATUS_FLAGGED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid,
incident_severity, incident_status_type_code)
VALUES('867bf775-43be-4633-9530-ea5b22a60996', '4ca26fd2-5216-4e9a-ba08-89bb94599778',
'ea8998a1-4571-406e-801e-4f708dba786d',
NULL, 'INC_STATUS_CONFIRMED') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid,
incident_severity, incident_status_type_code)
VALUES('c43ef111-d5fa-4969-bdba-92c489f1eb25', '4ca26fd2-5216-4e9a-ba08-89bb94599778',
'0dc60213-86dc-442f-b435-59bed8243bf4',
NULL, 'INC_STATUS_FLAGGED') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;







INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('df26402d-e266-4f36-b977-245ed855728c','0b0e3eb3-7929-4e38-bc63-dea6ffe6def8' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'INC_STATUS_CONFIRMED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('d78dcf88-286f-4d9c-9447-2224ff54d7af','0b0e3eb3-7929-4e38-bc63-dea6ffe6def8' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('aef91fc3-c684-4a65-b9c4-3eaea43318b6','0b0e3eb3-7929-4e38-bc63-dea6ffe6def8' ,
'fe29aad2-6971-4f04-8321-d800eac26c6f', null, 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('573e0df5-f523-4d87-a690-f7238133cd65','0b0e3eb3-7929-4e38-bc63-dea6ffe6def8' ,
'1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9', null, 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('6173168d-20e3-4bc9-b2bc-1c8e1ed3a5d3','0b0e3eb3-7929-4e38-bc63-dea6ffe6def8' ,
'0e5567b0-30ac-4518-b245-6093f3bc24b0', null, 'INC_STATUS_CONFIRMED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('4b0c7872-64a0-4ee1-9a79-2863c2a7f0ee','0b0e3eb3-7929-4e38-bc63-dea6ffe6def8' ,
'ffc3db8f-6a8e-4923-8e52-d5dabc51328a', null, 'INC_STATUS_FLAGGED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid,
incident_severity, incident_status_type_code)
VALUES('49e94b14-4f55-453d-8825-9c771634ff7a', '0b0e3eb3-7929-4e38-bc63-dea6ffe6def8',
'ea8998a1-4571-406e-801e-4f708dba786d',
NULL, 'INC_STATUS_CONFIRMED') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid,
incident_severity, incident_status_type_code)
VALUES('a6e8a9c8-bddb-42db-b764-324c55a9fdc6', '0b0e3eb3-7929-4e38-bc63-dea6ffe6def8',
'0dc60213-86dc-442f-b435-59bed8243bf4',
NULL, 'INC_STATUS_FLAGGED') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;




