ALTER TABLE ri_owner.booking_line ADD CONSTRAINT fk_01_booking_line_booking FOREIGN KEY (booking_uuid) REFERENCES ri_owner.booking (booking_uuid);
 
ALTER TABLE ri_owner.prc_repeater_flag ADD CONSTRAINT fk_01_prc_rep_analysis FOREIGN KEY (prc_repeater_analysis_uuid) REFERENCES ri_owner.prc_repeater_analysis(prc_repeater_analysis_uuid);
 
ALTER TABLE ri_owner.prc_outcome_details ADD CONSTRAINT fk_01_prc_out_det_inc_evd FOREIGN KEY (incident_evidence_uuid) REFERENCES ri_owner.incident_evidence(incident_evidence_uuid);
 
ALTER TABLE ri_owner.prc_repeater_analysis ADD CONSTRAINT fk_01_prc_rep_analysis_out_det FOREIGN KEY (prc_outcome_details_uuid) REFERENCES ri_owner.prc_outcome_details(prc_outcome_details_uuid);
 
ALTER TABLE ri_owner.prc_probability_analysis ADD CONSTRAINT fk_01_prc_prob_analysis_out_det FOREIGN KEY (prc_outcome_details_uuid) REFERENCES ri_owner.prc_outcome_details(prc_outcome_details_uuid);
 
ALTER TABLE ri_owner.booking_link ADD CONSTRAINT fk_01_source_booking_uuid FOREIGN KEY (source_booking_uuid) References ri_owner.booking(booking_uuid);

