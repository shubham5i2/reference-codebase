-- Update event_datetime to updated_datetime
UPDATE ri_owner.booking SET event_datetime = updated_datetime WHERE event_datetime IS NULL;

-- Update event_datetime to created_datetime if updated_datetime is null
UPDATE ri_owner.booking SET event_datetime = created_datetime WHERE event_datetime IS NULL;


-- Update event_datetime to updated_datetime
UPDATE ri_owner.location SET event_datetime = updated_datetime WHERE event_datetime IS NULL;

-- Update event_datetime to created_datetime if updated_datetime is null
UPDATE ri_owner.location SET event_datetime = created_datetime WHERE event_datetime IS NULL;


-- Update event_datetime to updated_datetime
UPDATE ri_owner.incident SET event_datetime = updated_datetime WHERE event_datetime IS NULL;

-- Update event_datetime to created_datetime if updated_datetime is null
UPDATE ri_owner.incident SET event_datetime = created_datetime WHERE event_datetime IS NULL;


-- Update event_datetime to updated_datetime
UPDATE ri_owner.check_outcome SET event_date_time = updated_datetime WHERE event_date_time IS NULL;

-- Update event_datetime to created_datetime if updated_datetime is null
UPDATE ri_owner.check_outcome SET event_date_time = created_datetime WHERE event_date_time IS NULL;

-- Update event_datetime to updated_datetime
UPDATE ri_owner.test_taker_photo SET event_datetime = updated_datetime WHERE event_datetime IS NULL;

-- Update event_datetime to created_datetime if updated_datetime is null
UPDATE ri_owner.test_taker_photo SET event_datetime = created_datetime WHERE event_datetime IS NULL;

