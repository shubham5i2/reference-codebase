alter table ri_owner.incident_evidence alter column incident_evidence_name type text;
alter table ri_owner.incident_evidence alter column incident_evidence_url type text;