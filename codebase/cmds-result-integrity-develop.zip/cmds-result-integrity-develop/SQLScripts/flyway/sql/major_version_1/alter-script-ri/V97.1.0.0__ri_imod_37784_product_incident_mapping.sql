--IOL AC
INSERT INTO ri_owner.product_incident_mapping(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)VALUES('f353bcb2-9b9b-4f1c-bcba-5484ca7275e2','3e81e94b-8b6a-42b5-970c-b141f9d195a3' ,'29b6aa56-8316-44d9-80d0-d5010a0a8518', null, 'INC_STATUS_FOLLOW_UP_REQUIRED')ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

--IOL GT
INSERT INTO ri_owner.product_incident_mapping(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)VALUES('96f5d8a0-c96b-42aa-b2cd-b7e9ab05f32b','d96eece2-1d7c-495a-a754-6b523b710a82' ,'29b6aa56-8316-44d9-80d0-d5010a0a8518', null, 'INC_STATUS_FOLLOW_UP_REQUIRED')ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

--IOC AC

INSERT INTO ri_owner.product_incident_mapping(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)VALUES('ecb90e79-2658-4dfa-b70b-8fa29293d42d','fdbacec5-e80a-4710-b3de-7d5f310b1466' ,'29b6aa56-8316-44d9-80d0-d5010a0a8518', null, 'INC_STATUS_FOLLOW_UP_REQUIRED')ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

--IOC GT

INSERT INTO ri_owner.product_incident_mapping(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)VALUES('236cdcfc-d277-4564-b426-35d546947e6e','cf9a05e9-2679-42da-b7d2-b34ea3e0724e' ,'29b6aa56-8316-44d9-80d0-d5010a0a8518', null, 'INC_STATUS_FOLLOW_UP_REQUIRED')ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

--UKVI IOL AC

INSERT INTO ri_owner.product_incident_mapping(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)VALUES('288a3617-3259-452a-9b5e-d10615d0428d','4ca26fd2-5216-4e9a-ba08-89bb94599778' ,'29b6aa56-8316-44d9-80d0-d5010a0a8518', null, 'INC_STATUS_FOLLOW_UP_REQUIRED')ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

--UKVI IOL GT

INSERT INTO ri_owner.product_incident_mapping(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)VALUES('726ecd4d-b633-4798-8cc7-108a3155c26b','0b0e3eb3-7929-4e38-bc63-dea6ffe6def8' ,'29b6aa56-8316-44d9-80d0-d5010a0a8518', null, 'INC_STATUS_FOLLOW_UP_REQUIRED')ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;


--SSR IOC AC

INSERT INTO ri_owner.product_incident_mapping(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)VALUES('27253051-e95e-4afa-82ff-7c25dab06fd3','cb7cd48c-5e79-4a28-8104-e0bcd8e39999' ,'29b6aa56-8316-44d9-80d0-d5010a0a8518', null, 'INC_STATUS_FOLLOW_UP_REQUIRED')ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

--SSR IOC GT

INSERT INTO ri_owner.product_incident_mapping(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)VALUES('1c56a709-1aec-4a9e-858a-e11a72691780','c37e2fab-898d-46d4-a61b-17f24bb29e83' ,'29b6aa56-8316-44d9-80d0-d5010a0a8518', null, 'INC_STATUS_FOLLOW_UP_REQUIRED')ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

--SSR IOL AC
INSERT INTO ri_owner.product_incident_mapping(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)VALUES('72a8269a-e8ec-4e8d-a91e-1d392cbd43b4','6d28d524-472d-4d53-8fd9-dc7c4bb5325d' ,'29b6aa56-8316-44d9-80d0-d5010a0a8518', null, 'INC_STATUS_FOLLOW_UP_REQUIRED')ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

--SSR IOL GT

INSERT INTO ri_owner.product_incident_mapping(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)VALUES('36fc36c4-d32f-4371-924d-179c1d330bb1','7b1d8d96-c314-40cd-a61c-2b681086a458' ,'29b6aa56-8316-44d9-80d0-d5010a0a8518', null, 'INC_STATUS_FOLLOW_UP_REQUIRED')ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

