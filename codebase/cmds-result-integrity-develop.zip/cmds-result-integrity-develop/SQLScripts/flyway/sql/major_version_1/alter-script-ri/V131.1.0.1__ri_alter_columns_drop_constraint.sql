ALTER TABLE ri_owner.booking_line ALTER COLUMN updated_datetime DROP NOT NULL;
ALTER TABLE ri_owner.unique_test_taker ALTER COLUMN updated_datetime DROP NOT NULL;
