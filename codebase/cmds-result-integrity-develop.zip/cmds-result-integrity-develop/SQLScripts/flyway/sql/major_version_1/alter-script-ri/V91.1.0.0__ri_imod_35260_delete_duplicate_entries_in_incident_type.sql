UPDATE ri_owner.incident SET incident_type_uuid = 'edd3a415-5c0f-4350-bc0d-7b3a8ae27d55' WHERE incident_type_uuid = 'd9e79e19-e93d-42dd-9184-75bb56ed1f26';

DELETE FROM ri_owner.incident_type WHERE incident_type_uuid = 'd9e79e19-e93d-42dd-9184-75bb56ed1f26';
