
INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('230b1b20-21dd-4171-bbe6-82565c8e9a83','6d28d524-472d-4d53-8fd9-dc7c4bb5325d' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('0c50248e-dd0e-45bd-8b09-947512f589a9','6d28d524-472d-4d53-8fd9-dc7c4bb5325d' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CONFIRMED', 'INC_STATUS_CONFIRMED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('a58161b2-8a74-4c73-ae3b-6b6048a5968f','6d28d524-472d-4d53-8fd9-dc7c4bb5325d' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('ce9692b7-63a5-497a-a3e2-f9271fe06ed3','6d28d524-472d-4d53-8fd9-dc7c4bb5325d' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('3d11da90-0f84-45e6-b9ee-4568fdb0f3ca','6d28d524-472d-4d53-8fd9-dc7c4bb5325d' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CONFIRMED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('0b48f0eb-3e54-40d6-99c4-8014e2804ea1','6d28d524-472d-4d53-8fd9-dc7c4bb5325d' ,'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('dd933708-e144-4355-bd3c-0cc45be6273e','6d28d524-472d-4d53-8fd9-dc7c4bb5325d' ,'fe29aad2-6971-4f04-8321-d800eac26c6f', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('ff7f2cac-9739-4643-817f-e9d6efbe8864','6d28d524-472d-4d53-8fd9-dc7c4bb5325d' ,'1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('aaeafa56-9c47-4ef1-8f5b-01999a157d31','6d28d524-472d-4d53-8fd9-dc7c4bb5325d' ,'0e5567b0-30ac-4518-b245-6093f3bc24b0', null, null, 'INC_STATUS_CONFIRMED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('84360631-b1b5-46db-848b-467f3ab9e12b','6d28d524-472d-4d53-8fd9-dc7c4bb5325d' ,'ffc3db8f-6a8e-4923-8e52-d5dabc51328a', null, null, 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;







INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('99a735bc-e163-43c8-aee3-e49261a0859f','7b1d8d96-c314-40cd-a61c-2b681086a458' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('1ad34e4d-e005-499f-9851-fda9ef85db2f','7b1d8d96-c314-40cd-a61c-2b681086a458' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CONFIRMED', 'INC_STATUS_CONFIRMED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('87e77155-75e6-4940-8615-48435c9f804f','7b1d8d96-c314-40cd-a61c-2b681086a458' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('1cff7243-d740-454a-91eb-baafa7b1cc4a','7b1d8d96-c314-40cd-a61c-2b681086a458' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('798ab97d-5731-4e1f-8b75-d84088e35bf5','7b1d8d96-c314-40cd-a61c-2b681086a458' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CONFIRMED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('a8d91b6a-0d15-4090-b18d-601af90739a2','7b1d8d96-c314-40cd-a61c-2b681086a458' ,'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('ca9b15c4-82c9-4a91-ba43-54ec1e561c05','7b1d8d96-c314-40cd-a61c-2b681086a458' ,'fe29aad2-6971-4f04-8321-d800eac26c6f', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('7e6b3303-18cd-4328-beb0-243d45e0cdcc','7b1d8d96-c314-40cd-a61c-2b681086a458' ,'1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('148ce6ef-9531-467c-821a-545ce0d2e003','7b1d8d96-c314-40cd-a61c-2b681086a458' ,'0e5567b0-30ac-4518-b245-6093f3bc24b0', null, null, 'INC_STATUS_CONFIRMED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('d269a7a9-20ff-481e-8728-59dbd7624ce9','7b1d8d96-c314-40cd-a61c-2b681086a458' ,'ffc3db8f-6a8e-4923-8e52-d5dabc51328a', null, null, 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;







INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('99510659-75e6-4e9b-bd4d-7496af9e03ef','cb7cd48c-5e79-4a28-8104-e0bcd8e39999' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('62e27c14-0ae5-4840-bd2b-ff903d158570','cb7cd48c-5e79-4a28-8104-e0bcd8e39999' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CONFIRMED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('443bdad4-1e4e-4588-9ece-d6cd1699976a','cb7cd48c-5e79-4a28-8104-e0bcd8e39999' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('0f80a0dc-2e0e-451a-bf57-a57c7b4b7e96','cb7cd48c-5e79-4a28-8104-e0bcd8e39999' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('82f086a6-52e1-4347-882d-ad22610c5a54','cb7cd48c-5e79-4a28-8104-e0bcd8e39999' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CONFIRMED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('5e4c9c87-1610-4ba1-be65-35617018f14a','cb7cd48c-5e79-4a28-8104-e0bcd8e39999' ,'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('f1aa75e9-6353-4ad8-abba-3893390228d7','cb7cd48c-5e79-4a28-8104-e0bcd8e39999' ,'fe29aad2-6971-4f04-8321-d800eac26c6f', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('18153bbb-f85e-4c6a-85c7-65826de4591a','cb7cd48c-5e79-4a28-8104-e0bcd8e39999' ,'1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('4ef2a331-8698-4ed7-97b7-972264eee386','cb7cd48c-5e79-4a28-8104-e0bcd8e39999' ,'0e5567b0-30ac-4518-b245-6093f3bc24b0', null, null, 'INC_STATUS_CONFIRMED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('d1b6b550-5ac1-4941-90d6-dcff40ca0525','cb7cd48c-5e79-4a28-8104-e0bcd8e39999' ,'ffc3db8f-6a8e-4923-8e52-d5dabc51328a', null, null, 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;







INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('575a4f10-322d-4b8e-9da2-96731a823b6a','c37e2fab-898d-46d4-a61b-17f24bb29e83' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('e858b2e7-446f-4668-b4ab-85843ac10ae9','c37e2fab-898d-46d4-a61b-17f24bb29e83' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CONFIRMED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('9a78def6-ff3e-4ee0-8a26-4ce053499487','c37e2fab-898d-46d4-a61b-17f24bb29e83' ,'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('71a70741-b799-4b3b-96b6-34dd359d8c03','c37e2fab-898d-46d4-a61b-17f24bb29e83' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('2fd86820-5ad4-4be3-a1f2-f0b3e8575367','c37e2fab-898d-46d4-a61b-17f24bb29e83' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CONFIRMED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('2a18f482-a878-4a81-8ec0-afb644197839','c37e2fab-898d-46d4-a61b-17f24bb29e83' ,'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('77ceb3e4-3b45-4ac3-a704-1f154d181120','c37e2fab-898d-46d4-a61b-17f24bb29e83' ,'fe29aad2-6971-4f04-8321-d800eac26c6f', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('b2b049f5-b057-4948-a2aa-a04456f54a84','c37e2fab-898d-46d4-a61b-17f24bb29e83' ,'1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('83d83e31-7150-491a-be52-8e60a74f0ff1','c37e2fab-898d-46d4-a61b-17f24bb29e83' ,'0e5567b0-30ac-4518-b245-6093f3bc24b0', null, null, 'INC_STATUS_CONFIRMED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('8d8c6d7f-5627-47ff-84e0-951ed90b268e','c37e2fab-898d-46d4-a61b-17f24bb29e83' ,'ffc3db8f-6a8e-4923-8e52-d5dabc51328a', null, null, 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;