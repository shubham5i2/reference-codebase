INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('31d1a6c3-3085-4341-92e9-2096413a1261'::uuid, '6d28d524-472d-4d53-8fd9-dc7c4bb5325d'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'CONFIRMED_MALPRACTICE', 'INC_STATUS_CONFIRMED') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('b918dd3f-fd10-471b-9a80-b230b4adf5c7'::uuid, '6d28d524-472d-4d53-8fd9-dc7c4bb5325d'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'WARNING', 'INC_STATUS_INFO') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('dc6f60a8-06c3-4e49-a1fa-b5d0f213a4fc'::uuid, '6d28d524-472d-4d53-8fd9-dc7c4bb5325d'::uuid, 'fe29aad2-6971-4f04-8321-d800eac26c6f'::uuid, NULL, 'INC_STATUS_INFO') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('f09a3a5d-7290-4e8b-b6e3-bd6cc96910ce'::uuid, '6d28d524-472d-4d53-8fd9-dc7c4bb5325d'::uuid, '1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9'::uuid, NULL, 'INC_STATUS_INFO') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('a593fc9b-9e9b-4e07-a014-b6fd4479f7bb'::uuid, '6d28d524-472d-4d53-8fd9-dc7c4bb5325d'::uuid, '0e5567b0-30ac-4518-b245-6093f3bc24b0'::uuid, NULL, 'INC_STATUS_CONFIRMED') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('67c3e0b3-1609-4ae9-acd3-03a3beb040cd'::uuid, '6d28d524-472d-4d53-8fd9-dc7c4bb5325d'::uuid, 'ffc3db8f-6a8e-4923-8e52-d5dabc51328a'::uuid, NULL, 'INC_STATUS_FLAGGED') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('5a00242c-59a1-4d43-bc84-22d7141ccf67'::uuid, '7b1d8d96-c314-40cd-a61c-2b681086a458'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'CONFIRMED_MALPRACTICE', 'INC_STATUS_CONFIRMED') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('b9c73bcc-26ca-4d1b-b6fe-fe114aed7932'::uuid, '7b1d8d96-c314-40cd-a61c-2b681086a458'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'WARNING', 'INC_STATUS_INFO') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('8e248d53-c0a8-4388-b960-1e8403881d11'::uuid, '7b1d8d96-c314-40cd-a61c-2b681086a458'::uuid, 'fe29aad2-6971-4f04-8321-d800eac26c6f'::uuid, NULL, 'INC_STATUS_INFO') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('7777f785-8acb-4fd9-9d0f-ed86deffa467'::uuid, '7b1d8d96-c314-40cd-a61c-2b681086a458'::uuid, '1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9'::uuid, NULL, 'INC_STATUS_INFO') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('f9a374c3-3697-4ce4-949b-63fdaf92ee02'::uuid, '7b1d8d96-c314-40cd-a61c-2b681086a458'::uuid, '0e5567b0-30ac-4518-b245-6093f3bc24b0'::uuid, NULL, 'INC_STATUS_CONFIRMED') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('5bd227d5-3236-4df6-83eb-305fbf0dc457'::uuid, '7b1d8d96-c314-40cd-a61c-2b681086a458'::uuid, 'ffc3db8f-6a8e-4923-8e52-d5dabc51328a'::uuid, NULL, 'INC_STATUS_FLAGGED') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('04b9f4b9-1cba-4619-968d-5f345aab82ca'::uuid, 'cb7cd48c-5e79-4a28-8104-e0bcd8e39999'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'CONFIRMED_MALPRACTICE', 'INC_STATUS_FLAGGED') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('9d1b0f74-849e-4ae9-ba33-441a72138baa'::uuid, 'cb7cd48c-5e79-4a28-8104-e0bcd8e39999'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'WARNING', 'INC_STATUS_INFO') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('6b593007-f254-4e73-91ca-13533a5b953f'::uuid, 'cb7cd48c-5e79-4a28-8104-e0bcd8e39999'::uuid, 'fe29aad2-6971-4f04-8321-d800eac26c6f'::uuid, NULL, 'INC_STATUS_INFO') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('ab0f121f-5eec-45bd-9cbc-98434c035565'::uuid, 'cb7cd48c-5e79-4a28-8104-e0bcd8e39999'::uuid, '1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9'::uuid, NULL, 'INC_STATUS_INFO') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('2f4492db-34f1-4a4e-9d2b-26f32dd99ec6'::uuid, 'cb7cd48c-5e79-4a28-8104-e0bcd8e39999'::uuid, '0e5567b0-30ac-4518-b245-6093f3bc24b0'::uuid, NULL, 'INC_STATUS_CONFIRMED') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('317fa524-a904-45d3-ada6-8a25a73a1afe'::uuid, 'cb7cd48c-5e79-4a28-8104-e0bcd8e39999'::uuid, 'ffc3db8f-6a8e-4923-8e52-d5dabc51328a'::uuid, NULL, 'INC_STATUS_FLAGGED') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('91b02936-2409-4863-9ad6-9bf6f989b241'::uuid, 'c37e2fab-898d-46d4-a61b-17f24bb29e83'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'CONFIRMED_MALPRACTICE', 'INC_STATUS_FLAGGED') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('5be41bf7-316c-4988-a8e9-52059ed45216'::uuid, 'c37e2fab-898d-46d4-a61b-17f24bb29e83'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'WARNING', 'INC_STATUS_INFO') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('2074a0ce-f84c-478c-aac2-72244232fb6c'::uuid, 'c37e2fab-898d-46d4-a61b-17f24bb29e83'::uuid, 'fe29aad2-6971-4f04-8321-d800eac26c6f'::uuid, NULL, 'INC_STATUS_INFO') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('9e0d6c25-aa9e-4e15-a0f9-f971de913008'::uuid, 'c37e2fab-898d-46d4-a61b-17f24bb29e83'::uuid, '1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9'::uuid, NULL, 'INC_STATUS_INFO') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('d44b5905-b3a7-4b4a-a107-3fd592133d6b'::uuid, 'c37e2fab-898d-46d4-a61b-17f24bb29e83'::uuid, '0e5567b0-30ac-4518-b245-6093f3bc24b0'::uuid, NULL, 'INC_STATUS_CONFIRMED') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('347dec3b-e7c6-41a5-8931-261f95e5d537'::uuid, 'c37e2fab-898d-46d4-a61b-17f24bb29e83'::uuid, 'ffc3db8f-6a8e-4923-8e52-d5dabc51328a'::uuid, NULL, 'INC_STATUS_FLAGGED') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('e51acd7b-e1f8-4737-8c5f-a486d25b001b'::uuid, '6d28d524-472d-4d53-8fd9-dc7c4bb5325d'::uuid, 'ea8998a1-4571-406e-801e-4f708dba786d'::uuid, NULL, 'INC_STATUS_CONFIRMED') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('71050992-616f-4f07-8816-474d8a563a0a'::uuid, '7b1d8d96-c314-40cd-a61c-2b681086a458'::uuid, 'ea8998a1-4571-406e-801e-4f708dba786d'::uuid, NULL, 'INC_STATUS_CONFIRMED') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('90791a82-ca10-4189-8e3b-7351a605a7f3'::uuid, '6d28d524-472d-4d53-8fd9-dc7c4bb5325d'::uuid, '0dc60213-86dc-442f-b435-59bed8243bf4'::uuid, NULL, 'INC_STATUS_FLAGGED') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('e37048d6-5839-433b-aae3-e91e829b8aed'::uuid, '7b1d8d96-c314-40cd-a61c-2b681086a458'::uuid, '0dc60213-86dc-442f-b435-59bed8243bf4'::uuid, NULL, 'INC_STATUS_FLAGGED') ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;
