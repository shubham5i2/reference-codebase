ALTER TABLE ri_owner.booking_link ALTER COLUMN updated_datetime DROP NOT NULL;
