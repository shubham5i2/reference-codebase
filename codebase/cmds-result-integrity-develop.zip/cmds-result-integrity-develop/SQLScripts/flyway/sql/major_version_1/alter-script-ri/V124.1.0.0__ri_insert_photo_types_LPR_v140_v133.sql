INSERT INTO ri_owner.photo_type(
    photo_type_uuid, photo_type_code, photo_type_description, updated_datetime, concurrency_version, created_by)
    VALUES ('526c09ce-1419-4b6e-bbd2-0eb2f59e948c', 'TT_ID_HR_S_IAM', 'TT Identity document High-Resolution - Identity document - identity document captured pre Speaking by center staff', NULL, '1', 'Operations User')ON CONFLICT(photo_type_uuid) DO NOTHING;
	
INSERT INTO ri_owner.photo_type(
    photo_type_uuid, photo_type_code, photo_type_description, updated_datetime, concurrency_version, created_by)
    VALUES ('4c0cc294-c188-4958-8725-488b8f176547', 'TT_P_HR_S_IAM', 'TT Profile High-Resolution - profile photo captured by center staff pre Speaking exam', NULL, '1', 'Operations User')ON CONFLICT(photo_type_uuid) DO NOTHING;

INSERT INTO ri_owner.photo_type(
    photo_type_uuid, photo_type_code, photo_type_description, updated_datetime, concurrency_version, created_by)
    VALUES ('5a8ca226-7e07-4819-9af0-7dae099a26c2', 'SSR_ORIGINAL_BOOKING_TRF', 'TT Certificate Photo from the original booking', NULL, '1', 'Operations User')ON CONFLICT(photo_type_uuid) DO NOTHING;
	
	