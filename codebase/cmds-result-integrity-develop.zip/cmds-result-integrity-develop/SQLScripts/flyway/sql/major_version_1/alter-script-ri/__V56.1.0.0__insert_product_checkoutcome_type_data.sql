INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('7ddc5aab-3fce-4f4e-abd9-f9db0988e6d5','5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2022-08-04 19:07:46.516', '2022-08-04 19:07:46.516', 0, 'LRW_INC_CHK');
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('45329764-92bc-4663-b77a-19b8e6290bf6','3e81e94b-8b6a-42b5-970c-b141f9d195a3'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2022-08-04 19:31:11.805', '2022-08-04 19:31:11.805', 0, 'LRW_INC_CHK');
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('189e8974-bd00-4f77-bfd6-b0f20b25ce02','3e81e94b-8b6a-42b5-970c-b141f9d195a3'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2022-08-04 19:31:11.805', '2022-08-04 19:31:11.805', 0, 'LRW_ID_INC_CHK');
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('f2bd0a74-d123-4818-8da6-f36930107eff','d96eece2-1d7c-495a-a754-6b523b710a82'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2022-08-04 19:33:19.248', '2022-08-04 19:33:19.248', 0, 'LRW_INC_CHK');
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('ae470ef0-31fe-4123-aee4-5e6787aafcf1','d96eece2-1d7c-495a-a754-6b523b710a82'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2022-08-04 19:33:19.248', '2022-08-04 19:33:19.248', 0, 'LRW_ID_INC_CHK');
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('a1181afb-6953-4eb3-bfca-0c750ab0128f', '5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0'::uuid, 'c6eebce9-d53e-430b-ad36-44ed9ce2872a'::uuid, '2022-08-04 19:07:52.439', '2022-08-04 19:07:52.439', 0, 'SPK_INC_CHK');
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('cc83df32-9e4b-432e-95cb-fcb669774407', '3e81e94b-8b6a-42b5-970c-b141f9d195a3'::uuid, 'c6eebce9-d53e-430b-ad36-44ed9ce2872a'::uuid, '2022-08-04 19:31:11.805', '2022-08-04 19:31:11.805', 0, 'SPK_INC_CHK');
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('857f4c90-c574-450b-9246-0e4ca981860f', '5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0'::uuid, '98760142-bace-4bb0-b2a9-d90b9b393553'::uuid, '2022-08-04 19:07:54.751', '2022-08-04 19:07:54.751', 0, 'PLG_INC_CHK');
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('22f5f3ab-69e1-4a31-9dd7-0a246c79c6d6','3e81e94b-8b6a-42b5-970c-b141f9d195a3'::uuid, '98760142-bace-4bb0-b2a9-d90b9b393553'::uuid, '2022-08-04 19:31:11.805', '2022-08-04 19:31:11.805', 0, 'PLG_INC_CHK');
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('583afe20-44cd-40f9-a2dd-3de2d03fbda9','d96eece2-1d7c-495a-a754-6b523b710a82'::uuid, '98760142-bace-4bb0-b2a9-d90b9b393553'::uuid, '2022-08-04 19:33:19.248', '2022-08-04 19:33:19.248', 0, 'PLG_INC_CHK');
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('53127ee2-fe21-4adf-84e1-5f11969c33c9','5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2022-08-04 19:07:58.173', '2022-08-04 19:07:58.173', 0, 'PRC_INC_CHK');
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('884b7b40-6165-48f2-be73-675ca01097f6','3e81e94b-8b6a-42b5-970c-b141f9d195a3'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2022-08-04 19:31:11.805', '2022-08-04 19:31:11.805', 0, 'PRC_INC_CHK');
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('dda09cb3-84d4-4f79-92be-81844532af06','d96eece2-1d7c-495a-a754-6b523b710a82'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2022-08-04 19:33:19.248', '2022-08-04 19:33:19.248', 0, 'PRC_INC_CHK');

INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('c0eda392-1126-4e1b-93dc-3fb793165232','d96eece2-1d7c-495a-a754-6b523b710a82'::uuid, 'c6eebce9-d53e-430b-ad36-44ed9ce2872a'::uuid, '2022-08-04 19:33:19.248', '2022-08-04 19:33:19.248', 0, 'SPK_INC_CHK');