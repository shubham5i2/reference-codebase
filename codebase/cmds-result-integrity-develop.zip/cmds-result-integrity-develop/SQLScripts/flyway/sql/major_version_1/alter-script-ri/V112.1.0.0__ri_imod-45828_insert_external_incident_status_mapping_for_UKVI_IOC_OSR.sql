--UKVI IOC OSR AC

INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('ce2d5666-309f-4cc4-af03-c0d2e6a086aa','de58e8e0-39c6-4c54-b62e-40cacbc6c56d' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('dd14c4a5-0dea-45ef-86a1-3533ac7c5889','de58e8e0-39c6-4c54-b62e-40cacbc6c56d' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CONFIRMED', 'INC_STATUS_CONFIRMED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('8e6466df-1951-4476-b59b-53ebfa6dd9f4','de58e8e0-39c6-4c54-b62e-40cacbc6c56d' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('ff9c354b-305d-4ac3-b42b-47d693e093cf','de58e8e0-39c6-4c54-b62e-40cacbc6c56d' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('a6150b2c-a397-4f37-9862-1871ca66aafb','de58e8e0-39c6-4c54-b62e-40cacbc6c56d' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CONFIRMED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('a440ed46-0634-4116-a36e-24e773256c5c','de58e8e0-39c6-4c54-b62e-40cacbc6c56d' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('c760b00c-4e7a-4e56-b2bf-785f2e316195','de58e8e0-39c6-4c54-b62e-40cacbc6c56d' ,
'fe29aad2-6971-4f04-8321-d800eac26c6f', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('379a59c0-f4b0-4262-97d9-6db6b473336e','de58e8e0-39c6-4c54-b62e-40cacbc6c56d' ,
'1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('ea1ce0fe-4c97-426d-9db3-9bc0d83d0fa2','de58e8e0-39c6-4c54-b62e-40cacbc6c56d' ,
'0e5567b0-30ac-4518-b245-6093f3bc24b0', null, null, 'INC_STATUS_CONFIRMED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('21414e17-50ec-4d19-a070-0a01ac07c7cf','de58e8e0-39c6-4c54-b62e-40cacbc6c56d' ,
'ffc3db8f-6a8e-4923-8e52-d5dabc51328a', null, null, 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;




--UKVI IOC OSR GT

INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('0a1ac230-f4fe-4191-89e7-ac7da796e664','fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('9bf5907b-9584-433c-83e6-1cda299b386e','fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CONFIRMED', 'INC_STATUS_CONFIRMED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('1f5fbc76-563c-4b3b-99dd-53f05d3d9707','fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('3e4c1926-99cb-462e-a308-3dc01a5ad72a','fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'FLAGGED', 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('1f5c1e4e-6296-42a5-a199-f4c4ce346525','fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CONFIRMED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;


INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('3b0a289a-1ac7-49c5-b0d8-7eb135268b88','fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'CLEARED', 'INC_STATUS_CLEARED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('aaa807bc-cbcd-4285-be52-f539a8f4f36f','fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db' ,
'fe29aad2-6971-4f04-8321-d800eac26c6f', 'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('f8cf7bd8-f7d1-4cb5-9d35-414228082769','fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db' ,
'1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9',  'INFO', 'FLAGGED', 'INC_STATUS_INFO')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('ee5b2ab7-dc3b-4436-b338-a44c414aaf73','fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db' ,
'0e5567b0-30ac-4518-b245-6093f3bc24b0', null, null, 'INC_STATUS_CONFIRMED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.external_incident_status_mapping
(external_incident_status_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, external_incident_status, incident_status_type_code)
VALUES('60b63ff7-7011-427c-bc65-f6e0ae150721','fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db' ,
'ffc3db8f-6a8e-4923-8e52-d5dabc51328a', null, null, 'INC_STATUS_FLAGGED')
ON CONFLICT(external_incident_status_mapping_uuid) DO NOTHING;