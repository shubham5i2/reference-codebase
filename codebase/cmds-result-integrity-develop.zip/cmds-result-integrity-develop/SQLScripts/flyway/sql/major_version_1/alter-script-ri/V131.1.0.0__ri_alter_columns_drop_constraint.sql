ALTER TABLE ri_owner.incident ALTER COLUMN updated_datetime DROP NOT NULL;
ALTER TABLE ri_owner.incident ALTER COLUMN created_datetime DROP NOT NULL;
ALTER TABLE ri_owner.incident ADD COLUMN IF NOT EXISTS event_datetime timestamptz;
ALTER TABLE ri_owner.check_outcome ALTER COLUMN updated_datetime DROP NOT NULL;
ALTER TABLE ri_owner.check_outcome ADD COLUMN IF NOT EXISTS event_date_time timestamptz;
ALTER TABLE ri_owner.booking ADD COLUMN IF NOT EXISTS event_datetime timestamptz;
ALTER TABLE ri_owner.booking ALTER COLUMN updated_datetime DROP NOT NULL;
ALTER TABLE ri_owner.outcome_status ALTER COLUMN updated_datetime DROP NOT NULL;
ALTER TABLE ri_owner.location ADD COLUMN IF NOT EXISTS event_datetime timestamptz;
ALTER TABLE ri_owner.test_taker_photo ADD COLUMN IF NOT EXISTS event_datetime timestamptz;
ALTER TABLE ri_owner.prc_outcome_details ALTER COLUMN updated_datetime DROP NOT NULL;
ALTER TABLE ri_owner.prc_outcome_details ALTER COLUMN created_datetime DROP NOT NULL;
ALTER TABLE ri_owner.prc_probability_analysis ALTER COLUMN updated_datetime DROP NOT NULL;
ALTER TABLE ri_owner.prc_repeater_analysis ALTER COLUMN updated_datetime DROP NOT NULL;
ALTER TABLE ri_owner.prc_repeater_flag ALTER COLUMN updated_datetime DROP NOT NULL;

