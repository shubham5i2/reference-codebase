INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('7456e27e-d67a-466b-899a-e81b70e41b0f','bb71c4bb-ba26-4569-99fa-fb3d2aec1120'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'LRW_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('b9e8fa10-8378-4938-a82b-20ec2651174f','95fa3301-e17c-4467-bab5-f4754765ad4d'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'LRW_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('80d15282-0cb7-403f-b59a-0612374734da','9cdec6ab-7886-476a-a586-13dfda9a52a9'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'LRW_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;



INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('d6e18abf-fc3b-45aa-aa64-13cafcc38012','304d2fa4-642d-4ec7-8600-ae21eb8b4dd8'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'LRW_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('68ddf6e2-dc7a-4736-b458-501c195bdf20','d5d4392d-b3c7-4a99-b039-98a281c0104d'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'LRW_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('3296e5c8-29fd-40c0-9084-3ab2057fc794','c5524e22-ec61-4705-b7d1-5818826b7cd1'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'LRW_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;







INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('4f814d13-7733-422f-924b-3d35452819ea','17e0db26-7f58-40ae-b5a8-999fb68dca96'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'LRW_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('0b624752-9dd2-4b73-9003-2a6f3ee13e72','6b2c8f4a-e94f-44c8-8575-22987e5aef17'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'LRW_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('a7c8701b-e88c-4cb0-b71d-f0a21a741c40','bb1895b0-f302-4e4c-8bc9-07265f0eadd7'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'LRW_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;



INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('074d03dc-5493-47d0-8a4c-0ee6f07fbdbc','e1d9b3fb-d428-4342-9656-50470cde4c39'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'LRW_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('4280f062-6354-4b71-85f2-9b92794dd0b5','74193427-ccae-4227-8577-9950c9f79d47'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'LRW_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;


INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('397615de-b2b4-4e00-aeb1-f6c7739cae60','64ada755-5cb3-46ed-b90c-69bd88230402'::uuid, '51c94a9d-c563-4f4d-8544-f90e59592463'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'LRW_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;











INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('2fb78cfa-4705-449e-b3f1-d112c5d6fa16','deea53e9-886b-4dee-b0b2-9ab29c70a82e'::uuid, 'c6eebce9-d53e-430b-ad36-44ed9ce2872a'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'SPK_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;



INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('b18ba089-230b-4aff-bbe4-667e926f8040','a489fddd-9bb5-4ed4-9678-0a88bde4778c'::uuid, 'c6eebce9-d53e-430b-ad36-44ed9ce2872a'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'SPK_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;





INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('dd2a66a1-44da-4326-ac22-2d826e63a4b0','ff045df4-8c11-4bd8-b2d3-a94aa56a7877'::uuid, 'c6eebce9-d53e-430b-ad36-44ed9ce2872a'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'SPK_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;



INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('84dfc269-a3f2-442c-ad57-a3988017b802','4acd484a-958c-42f1-9cdd-fc5f8e12d5da'::uuid, 'c6eebce9-d53e-430b-ad36-44ed9ce2872a'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'SPK_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;









INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('cdb765d5-58cb-4ee3-aa2b-9056024309b8','bb71c4bb-ba26-4569-99fa-fb3d2aec1120'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('e2e13fe4-14cb-4da8-9faa-690be8ee1f69','95fa3301-e17c-4467-bab5-f4754765ad4d'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('75597ff0-7ab7-46ec-99d6-595512760368','9cdec6ab-7886-476a-a586-13dfda9a52a9'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('9d87a8ff-5c1d-47e6-b5b5-191c86596256','deea53e9-886b-4dee-b0b2-9ab29c70a82e'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;




INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('f7e0bb47-a96a-4609-a8c6-cc5ef02b3e85','304d2fa4-642d-4ec7-8600-ae21eb8b4dd8'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('c728fc7f-467e-4477-ba76-069d7afd6a27','d5d4392d-b3c7-4a99-b039-98a281c0104d'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('c8e7ceef-70cb-4ce2-be89-b7684ddbbd06','c5524e22-ec61-4705-b7d1-5818826b7cd1'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('e7215a76-c68a-42bf-80be-796e21c19a21','a489fddd-9bb5-4ed4-9678-0a88bde4778c'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;







INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('e2bec5e8-561e-4e74-9bf3-3bd61d07cbc8','17e0db26-7f58-40ae-b5a8-999fb68dca96'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('20d397b0-21d6-4807-aa95-f9b41a3ee56d','6b2c8f4a-e94f-44c8-8575-22987e5aef17'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('06d6bd63-08f3-4678-a20d-d0a89fa70c90','bb1895b0-f302-4e4c-8bc9-07265f0eadd7'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('e5946b8e-ad40-401f-8bde-6662a3c62c76','ff045df4-8c11-4bd8-b2d3-a94aa56a7877'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;




INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('ad202882-3388-4cc7-90f6-fd00f0fbdc39','e1d9b3fb-d428-4342-9656-50470cde4c39'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('13a8ed19-2a91-44d1-8d16-83abb18e2253','74193427-ccae-4227-8577-9950c9f79d47'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('b1189081-5ab4-4316-a6ca-ae1e1e1d59c3','64ada755-5cb3-46ed-b90c-69bd88230402'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('9f4c06cb-b2ca-43e5-9fcb-06c54ed4eb41','4acd484a-958c-42f1-9cdd-fc5f8e12d5da'::uuid, '005ef982-3749-4a59-98c9-5da13fed6017'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'PRC_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;











INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('08ad427d-6621-46b9-b928-cca2a59478ae','bb71c4bb-ba26-4569-99fa-fb3d2aec1120'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('f16611d6-c230-4164-9e88-69c43adf6649','95fa3301-e17c-4467-bab5-f4754765ad4d'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('f3275482-5acf-4917-b8b7-365d2edbedc2','9cdec6ab-7886-476a-a586-13dfda9a52a9'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('dcb23de9-8540-4f67-b5cf-c7b1c8b215a2','deea53e9-886b-4dee-b0b2-9ab29c70a82e'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;




INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('4b8b915f-45e0-4252-8810-d52f44c820cf','304d2fa4-642d-4ec7-8600-ae21eb8b4dd8'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('72ea19be-fc68-4405-a605-b5a7fdad1232','d5d4392d-b3c7-4a99-b039-98a281c0104d'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('0b2426b4-3627-42d9-9c4d-5a0d1f1a48dc','c5524e22-ec61-4705-b7d1-5818826b7cd1'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('9e0ec654-4ed9-4cb9-a498-3757d57acb99','a489fddd-9bb5-4ed4-9678-0a88bde4778c'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;









INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('fbb1115a-765d-44d0-b132-533713b10090','9cdec6ab-7886-476a-a586-13dfda9a52a9'::uuid, '98760142-bace-4bb0-b2a9-d90b9b393553'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'PLG_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;



INSERT INTO ri_owner.product_check_outcome_type(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)VALUES('eb4d669a-d32c-47fe-94d8-833eabb4a307','c5524e22-ec61-4705-b7d1-5818826b7cd1'::uuid, '98760142-bace-4bb0-b2a9-d90b9b393553'::uuid, '2022-09-12 19:07:46.516', '2022-09-12 19:07:46.516', 0, 'PLG_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;