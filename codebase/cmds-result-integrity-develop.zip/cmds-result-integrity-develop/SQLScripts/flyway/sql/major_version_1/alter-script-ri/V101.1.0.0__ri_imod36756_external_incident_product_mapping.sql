UPDATE ri_owner.external_incident_status_mapping
SET  incident_status_type_code='INC_STATUS_CONFIRMED'
WHERE external_incident_status_mapping_uuid='e0649312-8c58-44e7-973d-4ec0d16c0036';

UPDATE ri_owner.external_incident_status_mapping
SET  incident_status_type_code='INC_STATUS_CONFIRMED'
WHERE external_incident_status_mapping_uuid='266c3b7d-fd12-4ce3-afa1-74e0e7c2cecd';

UPDATE ri_owner.external_incident_status_mapping
SET  incident_status_type_code='INC_STATUS_CONFIRMED'
WHERE external_incident_status_mapping_uuid='62e27c14-0ae5-4840-bd2b-ff903d158570';

UPDATE ri_owner.external_incident_status_mapping
SET  incident_status_type_code='INC_STATUS_CONFIRMED'
WHERE external_incident_status_mapping_uuid='e858b2e7-446f-4668-b4ab-85843ac10ae9';