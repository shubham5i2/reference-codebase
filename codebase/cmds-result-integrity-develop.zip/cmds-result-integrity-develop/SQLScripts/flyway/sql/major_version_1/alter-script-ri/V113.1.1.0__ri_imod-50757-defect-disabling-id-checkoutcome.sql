--IELTS OSR SELT on Computer AC LISTENING
delete from ri_owner.product_check_outcome_type where product_check_outcome_type_uuid ='f990e305-3ec6-410d-858f-4fa01ad3f073'::uuid;
--IELTS OSR SELT on Computer AC SPEAKING
delete from ri_owner.product_check_outcome_type where product_check_outcome_type_uuid ='3a9dc25a-4fca-44f6-92e1-7a5317382fd1'::uuid;
-- IELTS OSR SELT on Computer AC READING
delete from ri_owner.product_check_outcome_type where product_check_outcome_type_uuid ='4bb72b27-0a0d-4043-af21-b9740cea73ce'::uuid;
--IELTS OSR SELT on Computer AC W
delete from ri_owner.product_check_outcome_type where product_check_outcome_type_uuid ='34692dcb-ef58-4d0e-8fc5-2f9c05d73034'::uuid;
--IELTS OSR SELT on Computer GT LISTENING
delete from ri_owner.product_check_outcome_type where product_check_outcome_type_uuid ='522e03ad-aa05-43e2-86a6-ee7eb06cdd1e'::uuid;
-- IELTS OSR SELT on Computer GT READING
delete from ri_owner.product_check_outcome_type where product_check_outcome_type_uuid ='0946c10e-448f-439c-b486-ea7230b9fdcf'::uuid;
--IELTS OSR SELT on Computer GT W
delete from ri_owner.product_check_outcome_type where product_check_outcome_type_uuid ='a611acbc-e851-4cc6-ae91-30156368d252'::uuid;
--IELTS OSR SELT on Computer GT SPEAKING
delete from ri_owner.product_check_outcome_type where product_check_outcome_type_uuid ='b143806e-7025-43a1-af01-ce0c2816f482'::uuid;