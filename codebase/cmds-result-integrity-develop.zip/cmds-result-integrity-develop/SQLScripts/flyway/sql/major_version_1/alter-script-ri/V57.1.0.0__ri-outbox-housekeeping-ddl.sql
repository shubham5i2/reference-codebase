GRANT DELETE
ON  ri_owner.outbox_event, ri_owner.outbox_event_attribute
TO  ri_user;