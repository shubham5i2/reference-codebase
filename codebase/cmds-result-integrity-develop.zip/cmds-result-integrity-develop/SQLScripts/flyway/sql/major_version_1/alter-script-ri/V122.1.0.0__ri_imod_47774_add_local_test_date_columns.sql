ALTER TABLE ri_owner.booking ADD COLUMN IF NOT EXISTS test_date_audit varchar(100);
ALTER TABLE ri_owner.booking ADD COLUMN IF NOT EXISTS test_date_offset varchar(10);
ALTER TABLE ri_owner.booking ADD COLUMN IF NOT EXISTS test_date_utc timestamptz;