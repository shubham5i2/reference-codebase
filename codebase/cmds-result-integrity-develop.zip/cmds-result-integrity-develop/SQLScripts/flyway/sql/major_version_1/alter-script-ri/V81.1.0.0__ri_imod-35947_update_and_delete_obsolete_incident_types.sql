UPDATE ri_owner.incident SET incident_type_uuid = 'b93ae42d-0d97-4147-b2df-b47996c2973a' WHERE incident_type_uuid = '0cb65182-e5de-4f3d-a36e-202d24b0b491';
UPDATE ri_owner.incident SET incident_type_uuid = 'd6ba52ee-7c44-4212-a38d-76eafbccd98e' WHERE incident_type_uuid = '8b8b96c6-7b8a-45d7-98b4-1e71a7696095';

DELETE FROM ri_owner.incident_type WHERE incident_type_uuid IN
('29b5b3d9-381b-4dc7-860a-d24dd0397601', '4cefd11d-143d-44c1-824f-a4079f60d5c2', '0cb65182-e5de-4f3d-a36e-202d24b0b491',
'8b8b96c6-7b8a-45d7-98b4-1e71a7696095', '45ba5fe9-c3e6-4344-b814-d5e122c5270e', '1c646790-a2b3-4b25-b18e-c8df6dff5391');
