GRANT DELETE
ON  ri_owner.prc_outcome_details , ri_owner.prc_probability_analysis ,
ri_owner.prc_repeater_analysis  , ri_owner.prc_repeater_flag , ri_owner.incident_evidence
,ri_owner.incident_comment ,ri_owner.incident_evidence ,ri_owner.check_outcome ,
ri_owner.incident
TO  ri_user;
