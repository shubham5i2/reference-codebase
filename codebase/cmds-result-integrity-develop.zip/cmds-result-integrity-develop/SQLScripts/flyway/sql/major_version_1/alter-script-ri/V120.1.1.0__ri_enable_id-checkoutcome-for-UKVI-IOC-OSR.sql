--IELTS OSR SELT on Computer AC LISTENING
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('f990e305-3ec6-410d-858f-4fa01ad3f073','7768ff79-1c44-4b7d-818f-a935afcb9d94'::uuid,'760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

 --IELTS OSR SELT on Computer AC SPEAKING
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('3a9dc25a-4fca-44f6-92e1-7a5317382fd1','c3e46fcc-b54f-49ae-8675-e373db8e6dc2'::uuid,'760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

 -- IELTS OSR SELT on Computer AC READING
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('4bb72b27-0a0d-4043-af21-b9740cea73ce','d8f6415d-c36f-4a2c-9c44-bbf0e4c65530'::uuid,'760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

--IELTS OSR SELT on Computer AC W
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('34692dcb-ef58-4d0e-8fc5-2f9c05d73034','edd31fef-dd28-4c0a-a593-3cd3b1b74838'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

 --IELTS OSR SELT on Computer GT LISTENING
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('522e03ad-aa05-43e2-86a6-ee7eb06cdd1e','42c488cc-2230-4842-b2aa-fe103f006aa7'::uuid,'760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

 -- IELTS OSR SELT on Computer GT READING
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('0946c10e-448f-439c-b486-ea7230b9fdcf','b6e7b55e-c21e-4002-8c0b-a9f66f8bce61'::uuid,'760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

 --IELTS OSR SELT on Computer GT W
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('a611acbc-e851-4cc6-ae91-30156368d252','a6bf0168-7ed0-49b9-959b-d526ff1087fa'::uuid, '760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;

 --IELTS OSR SELT on Computer GT SPEAKING
INSERT INTO ri_owner.product_check_outcome_type
(product_check_outcome_type_uuid,product_uuid, check_outcome_type_uuid, created_datetime, updated_datetime, concurrency_version, check_outcome_type_code)
VALUES('b143806e-7025-43a1-af01-ce0c2816f482','e73dbfad-a961-4c7e-9fba-e196a2703bb8'::uuid,'760ecebb-cad3-449c-927a-507033989b91'::uuid, '2023-05-24 13:24:47.805', '2023-05-24 13:24:47.805', 0, 'LRW_ID_INC_CHK') ON CONFLICT(product_check_outcome_type_uuid) DO NOTHING;
