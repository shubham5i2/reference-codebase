-- Insert new photo type TT_P_HR_IAM_ADD
INSERT INTO ri_owner.photo_type(
	photo_type_uuid, photo_type_code, photo_type_description, updated_datetime, concurrency_version, created_by)
	VALUES ('d03a1dbc-d00b-4e7d-89da-859248fbf7de', 'TT_P_HR_IAM_ADD', 'TT Profile High-Res - In-Centre Captured by IAM on Test Day - photo 2 for In-Centre test only ', NULL, '1', 'Operations User') ON CONFLICT(photo_type_uuid) DO NOTHING;

-- Insert new photo type TT_P_ORIGINAL_BOOKING_ADD
INSERT INTO ri_owner.photo_type(
	photo_type_uuid, photo_type_code, photo_type_description, updated_datetime, concurrency_version, created_by)
	VALUES ('af60ef99-86bb-4c52-a9a6-3a38bd7e4b0b', 'TT_P_ORIGINAL_BOOKING_ADD', 'TT Profile High-Res - In-Centre Captured by IAM on OSR Test Day for In-Centre test only ', NULL, '1', 'Operations User') ON CONFLICT(photo_type_uuid) DO NOTHING;

-- Update description of TT_P_HR_IAM
UPDATE ri_owner.photo_type SET photo_type_description = 'TT Profile High-Res - In-Centre Captured by IAM on Test Day -photo 1 for In-Centre test only' WHERE photo_type_uuid='a101702b-d8dd-4bcd-bcc5-a39cc6cf6fc5';

