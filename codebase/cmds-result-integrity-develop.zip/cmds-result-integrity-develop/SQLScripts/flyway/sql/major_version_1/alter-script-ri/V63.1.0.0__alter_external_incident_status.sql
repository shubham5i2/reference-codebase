DO $$ BEGIN  CREATE TYPE ri_owner."external_incident_status_enum" AS ENUM
    ('FLAGGED','CLEARED','CONFIRMED');
        EXCEPTION  WHEN duplicate_object THEN null;
END $$;


ALTER TABLE ri_owner.incident ADD COLUMN IF NOT EXISTS external_incident_status
ri_owner."external_incident_status_enum";