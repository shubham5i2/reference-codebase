--UKVI IOC AC

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('c4f35999-a3ce-4b00-b44d-5ae2d488b89d','6d04f596-22f2-49c4-9d47-85b167b8ca6f' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'INC_STATUS_FLAGGED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('2d52bb19-d1ee-4a5a-affa-64e34fb86212','6d04f596-22f2-49c4-9d47-85b167b8ca6f' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('7f34c134-27a1-4ec6-885b-16441bce386b','6d04f596-22f2-49c4-9d47-85b167b8ca6f' ,
'fe29aad2-6971-4f04-8321-d800eac26c6f', null, 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('18001c57-cd55-44e3-a432-6c0a8b5cef96','6d04f596-22f2-49c4-9d47-85b167b8ca6f' ,
'1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9', null, 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('f6f71799-0604-4fe2-b45c-45af9e216098','6d04f596-22f2-49c4-9d47-85b167b8ca6f' ,
'0e5567b0-30ac-4518-b245-6093f3bc24b0', null, 'INC_STATUS_CONFIRMED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('47317b9d-74d1-4eac-9172-55a65d4aec98','6d04f596-22f2-49c4-9d47-85b167b8ca6f' ,
'ffc3db8f-6a8e-4923-8e52-d5dabc51328a', null, 'INC_STATUS_FLAGGED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('2b60f780-f3de-4bb0-b5a7-35a6b493a449','6d04f596-22f2-49c4-9d47-85b167b8ca6f' ,
'29b6aa56-8316-44d9-80d0-d5010a0a8518', null, 'INC_STATUS_FOLLOW_UP_REQUIRED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;







--UKVI IOC GT

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('194f171d-2c52-438a-8a33-44218c16c755','54b9d8df-c07a-4cb4-b397-adc4faa87c3f' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'INC_STATUS_FLAGGED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('7588350f-30ff-4fec-bc10-96336b3c159c','54b9d8df-c07a-4cb4-b397-adc4faa87c3f' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('9b25c139-30a8-4050-b984-076da9acfef8','54b9d8df-c07a-4cb4-b397-adc4faa87c3f' ,
'fe29aad2-6971-4f04-8321-d800eac26c6f', null, 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('0ac19815-5ee6-43ab-bb26-cf34e5f69405','54b9d8df-c07a-4cb4-b397-adc4faa87c3f' ,
'1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9', null, 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('72f28a7a-5080-41ef-bab0-c640463bafcc','54b9d8df-c07a-4cb4-b397-adc4faa87c3f' ,
'0e5567b0-30ac-4518-b245-6093f3bc24b0', null, 'INC_STATUS_CONFIRMED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('e2f1e4e6-bfaf-413c-a23d-23a0c2464b71','54b9d8df-c07a-4cb4-b397-adc4faa87c3f' ,
'ffc3db8f-6a8e-4923-8e52-d5dabc51328a', null, 'INC_STATUS_FLAGGED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('462afe44-2fd2-4670-95ca-26ea589b69ce','54b9d8df-c07a-4cb4-b397-adc4faa87c3f' ,
'29b6aa56-8316-44d9-80d0-d5010a0a8518', null, 'INC_STATUS_FOLLOW_UP_REQUIRED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;





