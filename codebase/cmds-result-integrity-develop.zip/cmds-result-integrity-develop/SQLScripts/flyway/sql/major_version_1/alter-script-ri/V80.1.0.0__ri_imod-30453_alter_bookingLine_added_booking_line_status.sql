DO $$ BEGIN  CREATE TYPE ri_owner."booking_line_status_type" AS ENUM
    ('ACTIVE', 'INACTIVE');
        EXCEPTION  WHEN duplicate_object THEN null;
END $$;

ALTER TABLE ri_owner.booking_line ADD COLUMN IF NOT EXISTS booking_line_status ri_owner."booking_line_status_type";
