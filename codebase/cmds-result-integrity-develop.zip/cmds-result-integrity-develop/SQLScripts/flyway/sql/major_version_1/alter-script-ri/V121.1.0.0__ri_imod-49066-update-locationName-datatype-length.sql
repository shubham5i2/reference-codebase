--Location Table--
alter table ri_owner."location"  alter column location_name type varchar(300);