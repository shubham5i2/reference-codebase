INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('4dc2c32d-f154-4084-86dc-caeb33a8a725','3e81e94b-8b6a-42b5-970c-b141f9d195a3' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'INC_STATUS_CONFIRMED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('13de902b-fe04-473d-aa13-408442ead6d1','3e81e94b-8b6a-42b5-970c-b141f9d195a3' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('fe753fd0-a54f-4214-b0a0-cd79488fad3b','3e81e94b-8b6a-42b5-970c-b141f9d195a3' ,
'fe29aad2-6971-4f04-8321-d800eac26c6f', null, 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('b0153dc3-3cbc-4a58-955c-509a0532b429','3e81e94b-8b6a-42b5-970c-b141f9d195a3' ,
'1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9', null, 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('55fdebf0-83f9-4470-9e03-76079e008490','3e81e94b-8b6a-42b5-970c-b141f9d195a3' ,
'0e5567b0-30ac-4518-b245-6093f3bc24b0', null, 'INC_STATUS_CONFIRMED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('c503b472-8284-4332-b663-ce2f0b34eb83','3e81e94b-8b6a-42b5-970c-b141f9d195a3' ,
'ffc3db8f-6a8e-4923-8e52-d5dabc51328a', null, 'INC_STATUS_FLAGGED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;






INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('32c0b7dc-7ed5-4af2-bea9-dbc74c5a4ded','d96eece2-1d7c-495a-a754-6b523b710a82' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'INC_STATUS_CONFIRMED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('d8ba52cd-a86d-48d1-af0b-307f4ff99445','d96eece2-1d7c-495a-a754-6b523b710a82' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('3f384d4a-7c0d-4a54-ad63-e08e4c119fa1','d96eece2-1d7c-495a-a754-6b523b710a82' ,
'fe29aad2-6971-4f04-8321-d800eac26c6f', null, 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('73d79955-7e9e-495d-8c6a-38d4d0cc4a52','d96eece2-1d7c-495a-a754-6b523b710a82' ,
'1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9', null, 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('5626650a-b03d-4a5d-9693-65fac74e8555','d96eece2-1d7c-495a-a754-6b523b710a82' ,
'0e5567b0-30ac-4518-b245-6093f3bc24b0', null, 'INC_STATUS_CONFIRMED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('0ef74eb8-521c-4ae4-8169-8f550855d9c1','d96eece2-1d7c-495a-a754-6b523b710a82' ,
'ffc3db8f-6a8e-4923-8e52-d5dabc51328a', null, 'INC_STATUS_FLAGGED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;






INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('6a37a839-fb8a-40b3-a280-197b0093e46c','fdbacec5-e80a-4710-b3de-7d5f310b1466' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'INC_STATUS_FLAGGED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('eb321241-8b0a-4976-934c-2c6cb1461113','fdbacec5-e80a-4710-b3de-7d5f310b1466' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('7e0870b5-67e5-4a67-ad23-6a754756e77a','fdbacec5-e80a-4710-b3de-7d5f310b1466' ,
'fe29aad2-6971-4f04-8321-d800eac26c6f', null, 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('11172c59-823a-4969-954a-624dfe0edfe3','fdbacec5-e80a-4710-b3de-7d5f310b1466' ,
'1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9', null, 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('e6223a48-968a-4483-bac4-3f41fd393972','fdbacec5-e80a-4710-b3de-7d5f310b1466' ,
'0e5567b0-30ac-4518-b245-6093f3bc24b0', null, 'INC_STATUS_CONFIRMED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('00b1930f-441c-4d4f-b2de-161ea790a1f3','fdbacec5-e80a-4710-b3de-7d5f310b1466' ,
'ffc3db8f-6a8e-4923-8e52-d5dabc51328a', null, 'INC_STATUS_FLAGGED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;







INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('7c551ea0-a472-43d2-a147-12292042b4ee','cf9a05e9-2679-42da-b7d2-b34ea3e0724e' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'CONFIRMED_MALPRACTICE', 'INC_STATUS_FLAGGED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('bb4738dd-a074-4232-9dea-131837edf9a1','cf9a05e9-2679-42da-b7d2-b34ea3e0724e' ,
'3109484a-af84-40eb-a244-fe15d4649104', 'WARNING', 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('471fa576-2dd6-46c6-8638-77b52c2fc8d3','cf9a05e9-2679-42da-b7d2-b34ea3e0724e' ,
'fe29aad2-6971-4f04-8321-d800eac26c6f', null, 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('b153e5b0-3cef-4a47-9fbc-a5fbd7ae938b','cf9a05e9-2679-42da-b7d2-b34ea3e0724e' ,
'1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9', null, 'INC_STATUS_INFO')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('eb97ca26-55d0-43dd-b6fc-baf3b980c95d','cf9a05e9-2679-42da-b7d2-b34ea3e0724e' ,
'0e5567b0-30ac-4518-b245-6093f3bc24b0', null, 'INC_STATUS_CONFIRMED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;

INSERT INTO ri_owner.product_incident_mapping
(product_incident_mapping_uuid, product_uuid, incident_category_uuid, incident_severity, incident_status_type_code)
VALUES('92ea58d3-ff66-44c7-b93c-ad677ef48662','cf9a05e9-2679-42da-b7d2-b34ea3e0724e' ,
'ffc3db8f-6a8e-4923-8e52-d5dabc51328a', null, 'INC_STATUS_FLAGGED')
ON CONFLICT(product_incident_mapping_uuid) DO NOTHING;