DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='857f4c90-c574-450b-9246-0e4ca981860f'::uuid;
DELETE FROM ri_owner.product_check_outcome_type
WHERE product_check_outcome_type_uuid='c1bf5cf0-a70d-4e34-ac23-b7e1209940dd'::uuid;