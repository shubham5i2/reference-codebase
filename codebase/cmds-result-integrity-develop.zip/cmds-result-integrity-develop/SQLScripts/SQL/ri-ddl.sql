CREATE TABLE IF NOT EXISTS ri_owner.outcome_status_type (
	outcome_status_type_uuid uuid NOT NULL,
	outcome_status_type varchar(50) NOT NULL,
	outcome_status_type_code varchar(50) not null,
	effective_from_date DATE NOT NULL,
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
	created_by VARCHAR(36) NOT NULL,
	created_datetime timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_by VARCHAR(36),
	updated_datetime timestamptz ,
	concurrency_version int4 NOT NULL DEFAULT 0,
	CONSTRAINT outcome_status_type_pkey PRIMARY KEY (outcome_status_type_uuid)
);

CREATE TABLE IF NOT EXISTS ri_owner.incident_category (
	incident_category_uuid uuid NOT NULL,
	incident_category_code varchar(50) NOT NULL,
	incident_category varchar(50) NOT NULL,
	effective_from_date DATE NOT NULL,
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
	created_by VARCHAR(36) NOT NULL,
	created_datetime timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_by VARCHAR(36),
	updated_datetime timestamptz ,
	concurrency_version int4 NOT NULL DEFAULT 0,
	CONSTRAINT incident_category_pkey PRIMARY KEY (incident_category_uuid)
);

CREATE TABLE IF NOT EXISTS ri_owner.product (
	product_uuid uuid NOT NULL,
	parent_product_uuid uuid NULL,
	updated_datetime timestamptz NOT NULL,
	created_datetime timestamptz NOT NULL,
	concurrency_version int4 NOT null,
	CONSTRAINT pk_01_product PRIMARY KEY (product_uuid)
);

CREATE TYPE ri_owner."locationType" AS ENUM (
	'GLOBAL',
	'PARTNER',
	'REGION',
	'COUNTRY',
	'TEST_CENTRE',
	'VIRTUAL_BUILDING',
	'PHYSICAL_BUILDING',
	'ROOM');

CREATE TYPE ri_owner."locationStatusType" AS ENUM (
	'ACTIVE',
	'SUSPENDED',
	'INACTIVE');

CREATE TABLE IF NOT EXISTS ri_owner."location" (
	location_uuid uuid NOT NULL,
	parent_location_uuid uuid NULL,
	location_status ri_owner."locationStatusType" NOT NULL,
	location_type_code ri_owner."locationType" NOT NULL,
	partner_code varchar(20) NOT NULL,
	test_centre_number uuid NULL,
	location_name varchar(100) NOT NULL,
	created_datetime timestamptz NOT NULL,
	updated_datetime timestamptz NOT NULL,
	concurrency_version int4 NOT NULL,
	CONSTRAINT pk_01_location PRIMARY KEY (location_uuid)
);

CREATE TABLE IF NOT EXISTS ri_owner.incident_status_type (
	incident_status_type_uuid uuid NOT NULL,
	incident_status_type varchar(50) NOT NULL,
	incident_status_type_code varchar(50) not null,
	effective_from_date DATE NOT NULL,
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
	created_by VARCHAR(36) NOT NULL,
	created_datetime timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_by VARCHAR(36),
	updated_datetime timestamptz ,
	concurrency_version int4 NOT NULL DEFAULT 0,
	CONSTRAINT incident_status_type_pkey PRIMARY KEY (incident_status_type_uuid)
);

CREATE TABLE IF NOT EXISTS ri_owner.check_outcome_status (
	check_outcome_status_uuid uuid NOT NULL,
	check_outcome_status varchar(50) NOT NULL,
	check_outcome_status_code varchar(50) NOT NULL,
	effective_from_date DATE NOT NULL,
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
	created_by VARCHAR(36) NOT NULL,
	created_datetime timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_by VARCHAR(36),
	updated_datetime timestamptz ,
	concurrency_version int4 NOT NULL DEFAULT 0,
	CONSTRAINT check_outcome_status_pkey PRIMARY KEY (check_outcome_status_uuid)
);

CREATE TABLE IF NOT EXISTS ri_owner.check_outcome_type (
	check_outcome_type_uuid uuid NOT NULL,
	check_outcome_type varchar(50) NOT NULL,
	check_outcome_type_code varchar(50) not null,
	effective_from_date DATE NOT NULL,
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
	created_by VARCHAR(36) NOT NULL,
	created_datetime timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_by VARCHAR(36),
	updated_datetime timestamptz ,
	concurrency_version int4 NOT NULL DEFAULT 0,
	CONSTRAINT check_outcome_type_pkey PRIMARY KEY (check_outcome_type_uuid)
);

CREATE TABLE IF NOT EXISTS ri_owner.incident_type (
	incident_type_uuid uuid NOT NULL,
	incident_category_uuid uuid NOT NULL,
	incident_description varchar(50) not null,
	effective_from_date DATE NOT NULL,
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
	created_by VARCHAR(36) NOT NULL,
	created_datetime timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_by VARCHAR(36),
	updated_datetime timestamptz ,
	concurrency_version int4 NOT NULL DEFAULT 0,
	CONSTRAINT incident_type_pkey PRIMARY KEY (incident_type_uuid),
	CONSTRAINT incident_category_uuid_fk FOREIGN KEY (incident_category_uuid) REFERENCES ri_owner.incident_category(incident_category_uuid)
);

CREATE TABLE IF NOT EXISTS ri_owner.unique_test_taker (
	unique_test_taker_uuid uuid NOT NULL,
	unique_test_taker varchar(50) NOT NULL,
	updated_datetime timestamptz NOT NULL,
	created_datetime timestamptz NOT NULL,
	concurrency_version int4 NOT null,
	CONSTRAINT pk_01_unique_test_taker PRIMARY KEY (unique_test_taker_uuid)
);

CREATE TABLE IF NOT EXISTS ri_owner.booking (
	booking_uuid uuid NOT NULL,
	unique_test_taker_uuid uuid NOT NULL,
	product_uuid uuid NOT NULL,
	location_uuid uuid NOT NULL,
	updated_datetime timestamptz NOT NULL,
	created_datetime timestamptz NOT NULL,
	concurrency_version int4 NOT null,
	CONSTRAINT pk_01_booking PRIMARY KEY (booking_uuid),
	CONSTRAINT fk_01_booking_utt FOREIGN KEY (unique_test_taker_uuid) REFERENCES ri_owner.unique_test_taker(unique_test_taker_uuid),
	CONSTRAINT fk_01_booking_prod FOREIGN KEY (product_uuid) REFERENCES ri_owner.product(product_uuid),
	CONSTRAINT fk_01_booking_loc FOREIGN KEY (location_uuid) REFERENCES ri_owner.location(location_uuid)
);

CREATE TABLE IF NOT EXISTS ri_owner.booking_line (
	booking_line_uuid uuid NOT NULL,
	booking_uuid uuid NOT NULL,
	product_uuid uuid NOT NULL,
	location_uuid uuid NOT NULL,
	updated_datetime timestamptz NOT NULL,
	created_datetime timestamptz NOT NULL,
	concurrency_version int4 NOT null,
	CONSTRAINT pk_01_booking_line PRIMARY KEY (booking_line_uuid),
	CONSTRAINT fk_01_booking_line_booking FOREIGN KEY (booking_uuid) REFERENCES ri_owner.booking(booking_uuid),
	CONSTRAINT fk_01_booking_line_prod FOREIGN KEY (product_uuid) REFERENCES ri_owner.product(product_uuid),
	CONSTRAINT fk_01_booking_line_loc FOREIGN KEY (location_uuid) REFERENCES ri_owner.location(location_uuid)
);

CREATE TABLE IF NOT EXISTS ri_owner.outcome_status (
	outcome_status_uuid uuid NOT NULL,
	outcome_status_type_uuid uuid NOT NULL,
	booking_uuid uuid NOT NULL,
	updated_datetime timestamptz NOT NULL,
	created_datetime timestamptz NOT NULL,
	concurrency_version int4 NOT null,
	CONSTRAINT pk_01_out_sts PRIMARY KEY (outcome_status_uuid),
	CONSTRAINT fk_01_out_sts_type FOREIGN KEY (outcome_status_type_uuid) REFERENCES ri_owner.outcome_status_type(outcome_status_type_uuid),
	CONSTRAINT fk_01_out_sts_booking FOREIGN KEY (booking_uuid) REFERENCES ri_owner.booking(booking_uuid)
);

CREATE TABLE IF NOT EXISTS ri_owner.check_outcome (
	check_outcome_uuid uuid NOT NULL,
	check_outcome_status_uuid uuid NOT NULL,
	check_outcome_type_uuid uuid NOT NULL,
	booking_uuid uuid NOT NULL,
	comment varchar(50) NULL,
	updated_datetime timestamptz NOT NULL,
	created_datetime timestamptz NOT NULL,
	concurrency_version int4 NOT NULL,
	CONSTRAINT pk_01_chk_out PRIMARY KEY (check_outcome_uuid),
	CONSTRAINT fk_01_chk_out_sts FOREIGN KEY (check_outcome_status_uuid) REFERENCES ri_owner.check_outcome_status(check_outcome_status_uuid),
	CONSTRAINT fk_01_chk_out_type FOREIGN KEY (check_outcome_type_uuid) REFERENCES ri_owner.check_outcome_type(check_outcome_type_uuid),
	CONSTRAINT fk_01_chk_out_booking FOREIGN KEY (booking_uuid) REFERENCES ri_owner.booking(booking_uuid)
);

CREATE TABLE IF NOT EXISTS ri_owner.incident (
	incident_uuid uuid NOT NULL,
	booking_line_uuid uuid NOT NULL,
	incident_type_uuid uuid NOT NULL,
	incident_category_uuid uuid NOT NULL,
	booking_uuid uuid NULL,
	incident_status_type_uuid uuid NOT NULL,
	check_outcome_uuid uuid NOT NULL,
	updated_datetime timestamptz NOT NULL,
	created_datetime timestamptz NOT NULL,
	concurrency_version int4 NOT null,
	CONSTRAINT pk_01_inc PRIMARY KEY (incident_uuid),
	CONSTRAINT fk_01_inc_type FOREIGN KEY (incident_type_uuid) REFERENCES ri_owner.incident_type(incident_type_uuid),
	CONSTRAINT fk_01_inc_cat FOREIGN KEY (incident_category_uuid) REFERENCES ri_owner.incident_category(incident_category_uuid),
	CONSTRAINT fk_01_inc_booking FOREIGN KEY (booking_uuid) REFERENCES ri_owner.booking(booking_uuid),
	CONSTRAINT fk_01_inc_sts_type FOREIGN KEY (incident_status_type_uuid) REFERENCES ri_owner.incident_status_type(incident_status_type_uuid),
	CONSTRAINT fk_01_inc_chk_out FOREIGN KEY (check_outcome_uuid) REFERENCES ri_owner.check_outcome(check_outcome_uuid)
);

CREATE TABLE IF NOT EXISTS ri_owner.incident_evidence (
	incident_evidence_uuid uuid NOT NULL,
	incident_evidence_text varchar(50) NULL,
	incident_evidence_url varchar(50) NULL,
	incident_uuid uuid NOT NULL,
	updated_datetime timestamptz NOT NULL,
	created_datetime timestamptz NOT NULL,
	concurrency_version int4 NOT null,
	CONSTRAINT pk_01_inc_evd PRIMARY KEY (incident_evidence_uuid),
	CONSTRAINT fk_01_inc_evd_incident FOREIGN KEY (incident_uuid) REFERENCES ri_owner.incident(incident_uuid)
);

CREATE TABLE IF NOT EXISTS ri_owner.prc_outcome_details (
	prc_outcome_details_uuid uuid NOT NULL,
	incident_evidence_uuid uuid NOT NULL,
	inspera_external_test_id uuid NOT NULL,
	booking_uuid uuid NOT NULL,
	unique_test_taker_uuid uuid NOT NULL,
	updated_datetime timestamptz NOT NULL,
	created_datetime timestamptz NOT NULL,
	concurrency_version int4 NOT NULL,
	CONSTRAINT pk_01_prc_out_det PRIMARY KEY (prc_outcome_details_uuid),
	CONSTRAINT fk_01_prc_out_det_inc_evd FOREIGN KEY (incident_evidence_uuid) REFERENCES ri_owner.incident_evidence(incident_evidence_uuid),
	CONSTRAINT fk_01_prc_out_det_booking FOREIGN KEY (booking_uuid) REFERENCES ri_owner.booking(booking_uuid),
	CONSTRAINT fk_01_prc_out_det_utt FOREIGN KEY (unique_test_taker_uuid) REFERENCES ri_owner.unique_test_taker(unique_test_taker_uuid)
);

CREATE TABLE IF NOT EXISTS ri_owner.prc_repeater_analysis (
	prc_repeater_analysis_uuid uuid NOT NULL,
	prc_outcome_details_uuid uuid NOT NULL,
	l_band_score_jump int4 NULL,
	w_band_score_jump int4 NULL,
	r_band_score_jump int4 NULL,
	s_band_score_jump int4 NULL,
	overall_band_score_jump int4 NULL,
	weight int4 NULL,
	updated_datetime timestamptz NOT NULL,
	created_datetime timestamptz NOT NULL,
	concurrency_version int4 NOT NULL,
	CONSTRAINT pk_01_prc_rep_analysis PRIMARY KEY (prc_repeater_analysis_uuid),
	CONSTRAINT fk_01_prc_rep_analysis_out_det FOREIGN KEY (prc_outcome_details_uuid) REFERENCES ri_owner.prc_outcome_details(prc_outcome_details_uuid)
);

CREATE TABLE IF NOT EXISTS ri_owner.prc_probability_analysis (
	prc_probability_analysis_uuid uuid NOT NULL,
	prc_outcome_details_uuid uuid NOT NULL,
	mean_judgemental varchar(50) NULL,
	r_band_score_country_reg int4 NULL,
	r_band_score_res int4 NULL,
	r_band_score_std_res int4 NULL,
	r_band_score_flag int4 NULL,
	l_band_score_country_reg int4 NULL,
	l_band_score_res int4 NULL,
	l_band_score_std_res int4 NULL,
	updated_datetime timestamptz NOT NULL,
	created_datetime timestamptz NOT NULL,
	concurrency_version int4 NOT NULL,
	CONSTRAINT pk_01_prc_prob_analysis PRIMARY KEY (prc_probability_analysis_uuid),
	CONSTRAINT fk_01_prc_prob_analysis_out_det FOREIGN KEY (prc_outcome_details_uuid) REFERENCES ri_owner.prc_outcome_details(prc_outcome_details_uuid)
);

CREATE TABLE IF NOT EXISTS ri_owner.prc_repeater_flag (
	prc_repeater_flag_uuid uuid NOT NULL,
	flagged_for varchar(50) NULL,
	prc_repeater_analysis_uuid uuid NOT NULL,
	updated_datetime timestamptz NOT NULL,
	created_datetime timestamptz NOT NULL,
	concurrency_version int4 NOT null,
	CONSTRAINT pk_01_prc_rep_flg PRIMARY KEY (prc_repeater_flag_uuid),
	CONSTRAINT fk_01_prc_rep_analysis FOREIGN KEY (prc_repeater_analysis_uuid) REFERENCES ri_owner.prc_repeater_analysis(prc_repeater_analysis_uuid)
);

CREATE TABLE IF NOT EXISTS ri_owner.user_group_hierarchy(
	 user_group_uuid UUID ,
	 user_group_data jsonb NOT NULL,
	 concurrency_version INTEGER,
	 created_by VARCHAR(36) NOT NULL,
	 created_time timestamptz NOT NULL,
	 updated_by VARCHAR(36) NULL,
	 updated_time timestamptz NULL,
	 CONSTRAINT pk_user_group_hierarchy PRIMARY KEY (user_group_uuid));

CREATE EXTENSION "uuid-ossp" SCHEMA ri_owner;

	 