create type ri_owner."comment_user_type_enum" as enum(
'REPORTER',
'REVIEWER');

ALTER TABLE ri_owner.incident_comment ADD COLUMN IF NOT EXISTS incident_comment_user_type ri_owner."comment_user_type_enum";
