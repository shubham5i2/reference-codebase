ALTER TABLE ri_owner.check_outcome_type ADD COLUMN eligible_for_integrity_check BOOLEAN
NOT null default FALSE;