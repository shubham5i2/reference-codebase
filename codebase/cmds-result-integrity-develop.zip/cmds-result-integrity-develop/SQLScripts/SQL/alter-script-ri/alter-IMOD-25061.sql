CREATE OR REPLACE VIEW ri_owner.booking_line_outcome_view
AS SELECT bl.booking_uuid,
    max(bl.end_datetime) AS max_end_datetime,
    max(bl.end_datetime) + '24:00:00'::interval AS incident_check_trigger_time,
    string_agg(DISTINCT cot2.check_outcome_type_code::text, ','::text) AS check_outcome_received,
    ri_owner.uuid_generate_v4() AS id
   FROM ri_owner.booking_line bl
     JOIN ri_owner.outcome_status os ON bl.booking_uuid = os.booking_uuid
     JOIN ri_owner.outcome_status_type ost ON ost.outcome_status_type_uuid = os.outcome_status_type_uuid
     JOIN ri_owner.check_outcome co ON co.booking_uuid = bl.booking_uuid
     JOIN ri_owner.check_outcome_type cot2 ON cot2.check_outcome_type_uuid = co.check_outcome_type_uuid
  WHERE ost.outcome_status_type_code::text = 'OUT_STATUS_IN_PROGRESS'::text
  GROUP BY bl.booking_uuid;