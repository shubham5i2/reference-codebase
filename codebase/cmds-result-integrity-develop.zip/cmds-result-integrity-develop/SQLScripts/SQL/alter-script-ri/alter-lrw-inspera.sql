ALTER TABLE ri_owner.booking ADD COLUMN IF NOT EXISTS external_booking_uuid uuid,
ADD COLUMN IF NOT EXISTS composite_candidate_number VARCHAR(20);

ALTER TABLE ri_owner.booking_line ADD COLUMN IF NOT EXISTS external_booking_line_uuid uuid;

CREATE TYPE ri_owner."incident_severity_enum" AS ENUM (
'INFO',
'WARNING',
'CONFIRMED_MALPRACTICE');

ALTER TABLE ri_owner.incident ADD COLUMN IF NOT EXISTS external_incident_changed_date_time timestamptz,
ADD COLUMN IF NOT EXISTS external_incident_id VARCHAR(50),
ADD COLUMN IF NOT EXISTS incident_severity ri_owner."incident_severity_enum";

ALTER TABLE ri_owner.incident_evidence RENAME incident_evidence_text TO incident_evidence_name;

CREATE TABLE ri_owner.incident_comment (
	incident_comment_uuid uuid NOT NULL,
	incident_comment_text varchar(50) NULL,
	incident_comment_date_time timestamptz NULL,
	incident_comment_entered_by varchar(20) NULL,
	incident_uuid uuid NOT NULL,
	updated_datetime timestamptz NOT NULL,
	created_datetime timestamptz NOT NULL,
	concurrency_version int4 NOT NULL,
	CONSTRAINT pk_01_inc_cmt PRIMARY KEY (incident_comment_uuid),
	CONSTRAINT fk_01_inc_cmt_incident FOREIGN KEY (incident_uuid) REFERENCES ri_owner.incident(incident_uuid)
);

ALTER TABLE ri_owner.incident DROP CONSTRAINT IF EXISTS fk_01_inc_booking;

ALTER TABLE ri_owner.check_outcome DROP CONSTRAINT IF EXISTS fk_01_chk_out_booking;

ALTER TABLE ri_owner.outcome_status DROP CONSTRAINT IF EXISTS fk_01_out_sts_booking;

ALTER TABLE ri_owner.prc_outcome_details DROP CONSTRAINT IF EXISTS fk_01_prc_out_det_booking;


ALTER TABLE ri_owner.incident DROP CONSTRAINT IF EXISTS fk_01_inc_chk_out;
alter table ri_owner.incident alter column check_outcome_uuid drop not null;
