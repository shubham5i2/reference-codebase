ALTER TABLE ri_owner.booking_line ADD COLUMN IF NOT EXISTS start_datetime timestamptz,
ADD COLUMN IF NOT EXISTS end_datetime timestamptz;
