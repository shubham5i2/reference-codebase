ALTER TABLE ri_owner.prc_repeater_analysis ALTER COLUMN l_band_score_jump TYPE numeric(50, 20) USING l_band_score_jump::numeric;
ALTER TABLE ri_owner.prc_repeater_analysis ALTER COLUMN w_band_score_jump TYPE numeric(50, 20) USING w_band_score_jump::numeric;
ALTER TABLE ri_owner.prc_repeater_analysis ALTER COLUMN r_band_score_jump TYPE numeric(50, 20) USING r_band_score_jump::numeric;
ALTER TABLE ri_owner.prc_repeater_analysis ALTER COLUMN s_band_score_jump TYPE numeric(50, 20) USING s_band_score_jump::numeric;

