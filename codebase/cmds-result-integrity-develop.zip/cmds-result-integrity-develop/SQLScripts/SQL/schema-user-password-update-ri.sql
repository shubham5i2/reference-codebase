ALTER user ri_user with password 'password123';



