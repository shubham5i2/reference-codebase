--delete incident comments records
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='ac3c0a38-1c61-480e-9738-77b3113ad520'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='c64d9e03-e4fa-4f4b-a931-b370e3e6a4ec'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='91917e68-c024-4754-b53f-a480a12fc499'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='885b5a74-c3d8-4740-9746-701a7039c1f4'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='55e30551-cd46-4a29-919b-bf09829a09e2'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='5d6c1ee4-9757-49de-9b1a-5f106becfe0b'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='2ba1380b-c028-4cbd-b6ef-ac42b1f8a71a'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='18c1a078-bc74-4bb5-b476-1981046b8fe2'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='51fefa69-d9ab-4ee7-b2f5-be22d4948884'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='2e2b249c-4f97-46c2-b88e-ebc811f88725'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='94347e4b-6437-4632-9c25-4b0a8635ad2d'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='4a6f84ff-0eee-4859-b89f-53099596204b'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='cb78c9a0-1261-4591-b82b-7988b09946b2'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='854d164c-efd1-432f-9aa2-3090199be64d'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='324beb28-8dac-4daf-94a3-7c9b9b5c31dc'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='d0d13890-df37-444b-85c4-c2b515fec41a'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='6b28d4d2-d658-4b31-a6e8-007200c45454'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='cf77d372-283f-4599-af9b-f12636d8ea41'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='98c1e653-3aa0-4ba4-a68f-9aaacb6956d9'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='3fc6288e-2161-4565-9ceb-99887fcdd1c1'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='2773472f-8ed2-4875-8717-d1a0b5db88b9'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='2e7fc713-49ea-47fb-8b7c-dbdc937633ed'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='5ed4bbcb-c426-4a89-9fc3-bbbd6fa4ddfe'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='d27fdd0c-ab3d-44d1-9ddb-d0d3a316d62e'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='5fa1434a-0197-4344-84ec-775b5775c8cd'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='9f9a5102-e39a-4261-ba15-73bbc657b4d7'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='865ffd4c-88b1-448b-8cea-69b7fc62212a'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='db64397d-0361-4240-8df0-2b91bf34ba0c'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='8a7897bf-fd7a-416c-8b65-7b1c45dceb94'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='49e6a413-4b27-43d7-865f-51754d7f73ea'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='f591d027-9f4e-47b3-8f39-e948c4f16a1a'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='85e7d188-19c6-4d00-a75a-4f4d74b7f592'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='7be00920-2ea9-4e62-90ca-cacea2038c37'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='9fa24136-9b2c-4561-b809-389fc086b953'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='e3bff02a-ee10-488f-bd0b-6876ed8be533'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='8bf352be-a711-4bf0-9328-a67f773c1318'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='955ffda5-2b21-4d02-975c-afafb51fce8f'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='4c2cf4cf-de01-4e1f-8290-4998b55bc305'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='40c33215-248a-489e-93e1-89eec60db640'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='daba8fb6-afec-41b2-91ee-d1ee208bbcd2'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='332fb527-8f98-42fa-990c-c4b28cb2b07e'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='081849ff-f29f-48fb-a154-9d5cc753d774'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='11009ef1-64dc-475f-b608-174c0d365dd3'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='d658bcf9-f47c-4c4e-80dc-638706d079fb'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='0f548132-4b7d-4aa6-b317-ae035f3770ae'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='be6e08cf-3b87-470f-bc8b-3ccedc701fff'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='a199153b-c4d2-4fdc-93f8-23a1e598856a'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='cf63f911-51c5-40df-85f4-b458cee910f7'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='490aac27-168a-41c6-97b1-fd85a0d4e0ed'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='1a730726-d6e4-481d-b88c-eb9fa9da5d8c'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='2e47e678-78a1-46f5-98ae-8f4582ba7858'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='7bc08aab-05d5-413c-a9df-ec4bbb448535'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='1deb516b-48bb-4df5-a902-8b057c70b6d9'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='13967bf5-030e-427a-827e-c479edaae8b2'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='f5477d65-d3dc-4048-bef1-3bd9b332afd1'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='e2b6c749-786c-4530-a05b-df4d8ed77518'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='006f295e-56f4-41ee-93ad-8e4c393164f5'::uuid;
DELETE FROM ri_owner.incident_comment
WHERE incident_comment_uuid='b4bda89b-311d-478c-8e74-21bc55d594c4'::uuid;

--delete incident evidence records
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='256fe2cd-acac-4e88-a814-46a1532d1619'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='9ee7b152-1d95-448d-a518-a06777c53dd1'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='fab2ada0-d590-4636-b97d-69f76059352d'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='3e15efaa-6f2e-4e52-ba00-6a86be6f45d3'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='7b0e6761-5da4-4903-8881-8ffc98c06225'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='9306b4e7-abd9-45c9-af93-9961d94a6a43'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='d9907f3d-7921-462b-96a4-b8767e811c0f'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='e51d2cee-b426-486f-aa2c-8661bbcd3c9e'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='d9538b13-be3a-4aa1-be02-b7cbbb6a045f'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='70197d24-119f-47d3-bcf5-f5dc39236b4f'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='1dc34914-1c7a-40a8-85fb-746f3ce05c5a'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='eaa010ac-d036-415d-997b-97efaae0efbe'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='8634c534-79c7-4901-975b-09f193d484e0'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='b7c38f7a-0775-4105-aa99-495443d662a6'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='219a0eea-c2ae-43d9-a454-8e48961beaed'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='3da4b3c1-a87d-4c2f-913d-7751fface288'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='21932830-22af-4a11-9f37-1074a603f3b9'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='cf6b88a2-6e15-4f8e-85fb-1145e660f056'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='c71eb132-f549-46d7-a02b-2a23de2acb76'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='fd1a3b85-2643-442d-8c27-8f9784a3051f'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='a3ab46f3-5e2d-492a-bdea-17eb07a3f14f'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='6c0926ed-6cc8-43ae-8872-0cf963460fbc'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='db6819fe-62f8-43fd-af09-1709351c3a58'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='a40411ee-1041-4e77-95e8-10d8335cd29f'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='a5fe222f-9e19-4fbb-914b-98c02ecf97dd'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='c1b754a8-c2c3-4b23-bc43-d32b376f2883'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='7245bcae-dc20-4360-87d6-e642cefb5cdc'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='ec7ef366-9bf4-4680-8a7d-a85193f2ba32'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='2b09fe2d-d7a9-4e9c-a467-b4a9660a2412'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='b39d8194-edcd-421c-9a45-db74c62e0dde'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='070d4822-dbee-4dfe-91a2-da74c5d1afde'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='4e861072-0526-48d2-97cf-e6215aa60066'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='5c837b6d-97ee-41f9-bbf7-3d6ad1d8223f'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='c50f85bb-056a-46a4-84c7-75ed4adc8fda'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='996eef50-665f-42d2-ab4c-dbfbfb69fbd7'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='e3ae74a1-f260-44e0-9e73-15802ef3ed7b'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='53b52dee-08b4-4feb-b84b-50323bd4e2eb'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='db44a5e5-7caf-4156-94ba-b6314187dd80'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='e5b44412-4cb9-4432-8200-c34e561c8aa5'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='fbae218f-9455-4e89-ae5d-5e81507d79bd'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='c53d9d00-d4b4-44e9-8596-70da7ecfb4b5'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='5ae448bf-7755-407b-96b2-ef00f92782c8'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='9d5faccf-3952-4feb-8e6e-4f535d9223ac'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='b9563804-965c-4000-8c63-a227f5873815'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='ee5715b6-2571-4c0c-af9b-488e369ff480'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='b5358492-cc32-47fe-bca1-d059dc2eb59a'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='7a0370ee-8321-4c01-80ac-b9d7c01a6e20'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='6f3439e6-5bcb-4b00-82d3-8dc710bdec37'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='a5ef8f02-abb0-4f4c-afb0-f0040f9b713e'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='c1ae85b5-e38e-47a9-b701-ad79db15322b'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='e17c0f26-868d-459e-841b-cc6cfc737138'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='69fc4a9d-102c-42c6-abb5-43219749dc7d'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='4e48705f-11d6-4f2b-8333-2bc57f3001d8'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='e51fb7bf-5b47-40e5-9d38-93f59401020e'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='da7ce9e7-1887-491e-9b56-7fd13d6b33fb'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='41063f08-026d-4fe5-9d8d-bc256f25c1dd'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='1d7e37af-36d6-4ba5-9653-87a1479d064c'::uuid;
DELETE FROM ri_owner.incident_evidence
WHERE incident_evidence_uuid='66dbaad4-92b0-47ba-9364-9433b0048182'::uuid;

--delete incident records
DELETE FROM ri_owner.incident
WHERE incident_uuid='15e7619e-3529-460d-bd3e-3cb02ba306c8'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='6a834a80-7d90-49b6-a2ce-b9e1197bfd69'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='db5b6fb4-d296-4c28-9ec7-b8c4a4934e1f'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='c3b31afc-027e-42d9-a889-388c6aa87aa9'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='94310df8-587b-430e-896d-e0b3289f1af8'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='ac65072b-8e53-44df-ba7f-ec81f0212450'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='847fe2b7-9306-4c8d-b0d1-eb6f57fb43ec'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='9d0f2700-57c3-49d1-855f-61296f043f9c'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='1fab074e-5963-4ce0-b1b2-6091ff0e634d'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='7e2d46a1-e10b-44c1-9c28-f6e1c2abbebb'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='90794e79-f9c1-4fc0-b7cf-e56a03a07455'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='9d8038b0-3f82-4557-b6fb-51acadef2e46'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='73b765bd-181b-4f1e-8bb2-a4091c939a01'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='9a33a083-1524-4a02-a2a5-aa31dbe2a5ec'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='1edab83b-136e-4c0e-a9ba-7627f602cf75'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='007ac52f-16a1-4d77-9052-0a2279d3493d'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='80fd2ae3-3a42-4f39-a5cc-3eba18ceb24b'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='8e1f4978-8885-4f41-90ef-2cb906fe201e'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='e791ab54-5495-47e4-8ef3-60b10998143b'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='312e1a85-d6e9-4a66-8b46-45eacc8f5b5f'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='778f45eb-27dc-47c5-b902-0a19817203a6'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='f5dae18c-6e3f-4431-829d-68488965d4b6'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='1f0fc0b6-a0ad-4f5c-87b5-ad34b2fc176e'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='63c09942-aea7-401c-a865-5ef31a9b91ee'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='8820e727-eeb0-4862-aa66-ca79c4ffeeb8'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='4d3d0bcd-3dcf-48fb-8283-fa80455e4b2c'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='a5390016-9c2a-41a3-9ac9-0284719fd85e'::uuid;
DELETE FROM ri_owner.incident
WHERE incident_uuid='de9a2b46-e7e6-4f22-a131-cee215ed9ac6'::uuid;

--delete incident type records
DELETE FROM ri_owner.incident_type
WHERE incident_type_uuid='e0122c50-d9ed-4950-978d-5dbc5246256e';
DELETE FROM ri_owner.incident_type
WHERE incident_type_uuid='b807f404-b175-43ce-9168-3d2c36589800';
DELETE FROM ri_owner.incident_type
WHERE incident_type_uuid='4776f091-01a7-4d4b-89bf-bcc45c79a522';
DELETE FROM ri_owner.incident_type
WHERE incident_type_uuid='97540655-b27e-4fa5-85a1-9e0483dc9096';
DELETE FROM ri_owner.incident_type
WHERE incident_type_uuid='a7e4feb3-86e6-4cc2-8dd4-c39f342f55d7';


