--insert into incident_category table
DELETE FROM ri_owner.incident_category
WHERE incident_category_uuid='e89eecc9-a0e2-4642-b682-eff0a28ab8c5';

DELETE FROM ri_owner.incident_category
WHERE incident_category_uuid='abe50b75-3829-4a81-8ebc-355e89eeefbc'::uuid;

DELETE FROM ri_owner.incident_category
WHERE incident_category_uuid='0b604881-366b-43a1-b912-b565cd4f5d55'::uuid;

INSERT INTO ri_owner.incident_category
(incident_category_uuid, incident_category_code, incident_category, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, eligible_for_integrity_check)
VALUES('3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'MALPRACTICE_INC', 'Malpractice Incident', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, TRUE);

INSERT INTO ri_owner.incident_category
(incident_category_uuid, incident_category_code, incident_category, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, eligible_for_integrity_check)
VALUES('fe29aad2-6971-4f04-8321-d800eac26c6f'::uuid, 'TECHNICAL_INC', 'Technical Incident', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, FALSE);

INSERT INTO ri_owner.incident_category
(incident_category_uuid, incident_category_code, incident_category, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, eligible_for_integrity_check)
VALUES('1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9'::uuid, 'OTHER_INC', 'Other Incident', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, FALSE);

--insert into incident_status_type reference table
INSERT INTO ri_owner.incident_status_type
(incident_status_type_uuid, incident_status_type, incident_status_type_code, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('89347a43-2cf9-47a7-b22a-a0ff0514c51a'::uuid, 'Follow up required', 'INC_STATUS_FOLLOW_UP_REQUIRED', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0);

INSERT INTO ri_owner.incident_status_type
(incident_status_type_uuid, incident_status_type, incident_status_type_code, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('8356a550-bbdc-461b-a5e7-49c5f1cd58c9'::uuid, 'Investigation in progress', 'INC_STATUS_INVESTIGATION_IN_PROGRESS', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0);

--insert into outcome_status_type reference table
INSERT INTO ri_owner.outcome_status_type
(outcome_status_type_uuid, outcome_status_type, outcome_status_type_code, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('652255a2-cf34-43d1-9f97-35d2a8cc111e'::uuid, 'Failed', 'OUT_STATUS_FAILED', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0);

INSERT INTO ri_owner.outcome_status_type
(outcome_status_type_uuid, outcome_status_type, outcome_status_type_code, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('527daf2c-7d3e-42f0-91db-1bbeadbe23d3'::uuid, 'Flagged for review', 'OUT_STATUS_REVIEW', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0);

--insert into check_outcome_status reference table
INSERT INTO ri_owner.check_outcome_status
(check_outcome_status_uuid, check_outcome_status, check_outcome_status_code, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('a911b11f-c4f2-4ee9-8450-d954ed3bb9d9'::uuid, 'Failed', 'CHK_OUT_FAILED', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0);



