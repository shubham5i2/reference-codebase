ALTER TABLE ri_owner.incident_type RENAME parent_incident_type_uuid TO external_incident_category ;

Alter table ri_owner.incident_type alter column external_incident_category type varchar(200);

