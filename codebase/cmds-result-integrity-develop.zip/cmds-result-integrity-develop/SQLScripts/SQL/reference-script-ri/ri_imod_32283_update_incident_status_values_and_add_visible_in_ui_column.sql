update ri_owner.incident_status_type 
set incident_status_type = 'Pending'
WHERE incident_status_type_uuid='8356a550-bbdc-461b-a5e7-49c5f1cd58c9'::uuid;

update ri_owner.incident_status_type 
set incident_status_type = 'Referred'
WHERE incident_status_type_uuid='89347a43-2cf9-47a7-b22a-a0ff0514c51a'::uuid;

update ri_owner.incident_status_type 
set incident_status_type = 'Dismissed'
WHERE incident_status_type_uuid='36f8d68f-7f68-4755-9420-cec4168179b0'::uuid;


insert into ri_owner.incident_status_type 
(incident_status_type_uuid, incident_status_type, incident_status_type_code, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
values('b64a0e01-90f7-4545-9f9d-22ab6d88e873','Confirmed',
'INC_STATUS_CONFIRMED','2020-07-01','2099-12-31','Operations User',
'2021-09-23 14:42:50.111 +0530',null,null,0);



ALTER TABLE ri_owner.incident_status_type ADD COLUMN IF NOT EXISTS visible_in_ui boolean;


UPDATE ri_owner.incident_status_type 
SET visible_in_ui = false WHERE incident_status_type_uuid='8356a550-bbdc-461b-a5e7-49c5f1cd58c9'::uuid;

UPDATE ri_owner.incident_status_type 
SET visible_in_ui = false WHERE incident_status_type_uuid='f9dc2a18-2f98-4579-92b2-1568d0858a6a'::uuid;

UPDATE ri_owner.incident_status_type 
SET visible_in_ui = true  WHERE incident_status_type_uuid='6a91d649-18d7-48ae-9797-659b99cb1182'::uuid;

UPDATE ri_owner.incident_status_type 
SET visible_in_ui = true  WHERE incident_status_type_uuid='36f8d68f-7f68-4755-9420-cec4168179b0'::uuid;

UPDATE ri_owner.incident_status_type 
SET visible_in_ui = true  WHERE incident_status_type_uuid='89347a43-2cf9-47a7-b22a-a0ff0514c51a'::uuid;

UPDATE ri_owner.incident_status_type 
SET visible_in_ui = true  WHERE incident_status_type_uuid='936b7d75-39a2-4a23-b936-402f91cc4f40'::uuid;

UPDATE ri_owner.incident_status_type 
SET visible_in_ui = true  WHERE incident_status_type_uuid='b64a0e01-90f7-4545-9f9d-22ab6d88e873'::uuid;



