INSERT INTO ri_owner.outcome_status_type
(outcome_status_type_uuid, outcome_status_type, outcome_status_type_code , effective_from_date, created_by, updated_by, updated_datetime)
VALUES('1ccde77e-961a-4483-866f-fbf49c457440', 'Pre-check', 'OUT_STATUS_NOT_STARTED','2020-07-01','Operations User', NULL, NULL) ON CONFLICT(outcome_status_type_uuid) DO NOTHING;

INSERT INTO ri_owner.outcome_status_type
(outcome_status_type_uuid, outcome_status_type, outcome_status_type_code , effective_from_date, created_by, updated_by, updated_datetime)
VALUES('e6ee5918-d142-4bf6-8c6d-cf035d986350', 'In progress', 'OUT_STATUS_IN_PROGRESS','2020-07-01','Operations User', NULL, NULL) ON CONFLICT(outcome_status_type_uuid) DO NOTHING;

INSERT INTO ri_owner.outcome_status_type
(outcome_status_type_uuid, outcome_status_type, outcome_status_type_code , effective_from_date, created_by, updated_by, updated_datetime)
VALUES('20f4a016-7550-4ce4-b441-acf6fe4e1682', 'Refer', 'OUT_STATUS_REFER','2020-07-01','Operations User', NULL, NULL) ON CONFLICT(outcome_status_type_uuid) DO NOTHING;

INSERT INTO ri_owner.outcome_status_type
(outcome_status_type_uuid, outcome_status_type, outcome_status_type_code , effective_from_date, created_by, updated_by, updated_datetime)
VALUES('a9b16306-398d-4f61-af88-e2eda231cb4b', 'Passed', 'OUT_STATUS_PASSED','2020-07-01','Operations User', NULL, NULL) ON CONFLICT(outcome_status_type_uuid) DO NOTHING;