INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid, ban_review_required)
VALUES('93fb67cc-a5b2-48ec-bf0a-a9a3c637bb3e'::uuid, '0e5567b0-30ac-4518-b245-6093f3bc24b0'::uuid, 'Plagiarism', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'PLG_INC', NULL, true);
