-- Create publish_state	Type for outbox_event table
DO $$ BEGIN  CREATE TYPE ri_owner.publishstatetype AS ENUM
    ('PUBLISH_PENDING', 'PUBLISH_SUCCEED', 'PUBLISH_FAILURE');
        EXCEPTION  WHEN duplicate_object THEN null;
END $$;

-- Create Table for outbox_event
CREATE TABLE IF NOT EXISTS ri_owner.outbox_event (
  outbox_event_uuid UUID NOT NULL,
  transaction_uuid UUID NOT NULL,
  event_name VARCHAR(256) NOT NULL,
  event_datetime TIMESTAMPTZ NOT NULL,
  payload TEXT NOt NULL,
  publish_state ri_owner.publishstatetype NOT NULL,
  retry_count INTEGER NOT NULL, 
  created_datetime TIMESTAMPTZ NOT NULL,  
  updated_datetime TIMESTAMPTZ NOT NULL,  
  concurrency_version INTEGER NOT NULL,  
  CONSTRAINT pk_outbox_event PRIMARY KEY (outbox_event_uuid));
  
-- Create Table for outbox_event_attribute
CREATE TABLE IF NOT EXISTS ri_owner.outbox_event_attribute (
    outbox_event_attribute_uuid UUID NOT NULL,    
    outbox_event_uuid UUID NOT NULL,    
    attribute_key VARCHAR(256) NOT NULL,    
    attribute_value TEXT,    
    updated_datetime TIMESTAMPTZ NOT NULL,   
     CONSTRAINT pk_outbox_event_attribute PRIMARY KEY (outbox_event_attribute_uuid),    
     CONSTRAINT fk_01_outbox_event_attribute FOREIGN KEY (outbox_event_uuid)    
     References ri_owner.outbox_event(outbox_event_uuid),    
     CONSTRAINT uk_01_outbox_event_attribute UNIQUE (outbox_event_uuid, attribute_key));
     
CREATE INDEX IF NOT EXISTS idx_01_outbox_event ON ri_owner.outbox_event USING btree (publish_state, updated_datetime);

CREATE INDEX IF NOT EXISTS idx_02_outbox_event ON ri_owner.outbox_event USING btree (transaction_uuid, event_name);