update ri_owner.check_outcome_type set eligible_for_integrity_check = true where
check_outcome_type_uuid IN ('005ef982-3749-4a59-98c9-5da13fed6017','51c94a9d-c563-4f4d-8544-f90e59592463',
'760ecebb-cad3-449c-927a-507033989b91');