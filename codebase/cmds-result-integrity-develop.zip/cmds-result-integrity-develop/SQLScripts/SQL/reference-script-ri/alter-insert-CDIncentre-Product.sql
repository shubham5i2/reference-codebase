INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
NULL,
'IELTS on Computer',
NULL,
'2020-07-01',
'2099-12-31',
'Operations User',
'2022-03-14 11:30:00.000',
NULL,
NULL,
0) ON CONFLICT(product_uuid) DO NOTHING;



INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('fdbacec5-e80a-4710-b3de-7d5f310b1466',
'5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
'IELTS on Computer Academic',
NULL,
'2020-07-01',
'2099-12-31',
'Operations User',
'2022-03-14 11:30:00.000',
NULL,
NULL,
0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('6ccd6696-0660-409c-8a66-85d79c42f84d',
'fdbacec5-e80a-4710-b3de-7d5f310b1466',
'IELTS on Computer Academic L',
NULL,
'2020-07-01',
'2099-12-31',
'Operations User',
'2022-03-14 11:30:00.000',
NULL,
NULL,
0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('d40d2104-a610-42dc-936b-263fb4ba120a',
'fdbacec5-e80a-4710-b3de-7d5f310b1466',
'IELTS on Computer Academic R',
NULL,
'2020-07-01',
'2099-12-31',
'Operations User',
'2022-03-14 11:30:00.000',
NULL,
NULL,
0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('f0ea4e6f-d550-4687-a231-1032a7987441',
'fdbacec5-e80a-4710-b3de-7d5f310b1466',
'IELTS on Computer Academic W',
NULL,
'2020-07-01',
'2099-12-31',
'Operations User',
'2022-03-14 11:30:00.000',
NULL,
NULL,
0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('43215312-a604-4cbf-8b97-c3695b03e396',
'fdbacec5-e80a-4710-b3de-7d5f310b1466',
'IELTS on Computer Academic S',
NULL,
'2020-07-01',
'2099-12-31',
'Operations User',
'2022-03-14 11:30:00.000',
NULL,
NULL,
0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('cf9a05e9-2679-42da-b7d2-b34ea3e0724e',
'5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0',
'IELTS on Computer General Training',
NULL,
'2020-07-01',
'2099-12-31',
'Operations User',
'2022-03-14 11:30:00.000',
NULL,
NULL,
0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('df2c8f7e-e485-441b-88a5-34b640bff6a5',
'cf9a05e9-2679-42da-b7d2-b34ea3e0724e',
'IELTS on Computer General Training L',
NULL,
'2020-07-01',
'2099-12-31',
'Operations User',
'2022-03-14 11:30:00.000',
NULL,
NULL,
0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('4871fd4e-0c92-40be-9ca1-2707ab1b4a3f',
'cf9a05e9-2679-42da-b7d2-b34ea3e0724e',
'IELTS on Computer General Training R',
NULL,
'2020-07-01',
'2099-12-31',
'Operations User',
'2022-03-14 11:30:00.000',
NULL,
NULL,
0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('b034eca1-0e06-4384-8ae5-e71af4d66bcb',
'cf9a05e9-2679-42da-b7d2-b34ea3e0724e',
'IELTS on Computer General Training W',
NULL,
'2020-07-01',
'2099-12-31',
'Operations User',
'2022-03-14 11:30:00.000',
NULL,
NULL,
0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product (product_uuid, parent_product_uuid, product_name, product_description, available_from_date, available_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version)
VALUES('be5f16d3-be46-4a6f-a3a5-268d5e1721cc',
'cf9a05e9-2679-42da-b7d2-b34ea3e0724e',
'IELTS on Computer General Training S',
NULL,
'2020-07-01',
'2099-12-31',
'Operations User',
'2022-03-14 11:30:00.000',
NULL,
NULL,
0) ON CONFLICT(product_uuid) DO NOTHING;