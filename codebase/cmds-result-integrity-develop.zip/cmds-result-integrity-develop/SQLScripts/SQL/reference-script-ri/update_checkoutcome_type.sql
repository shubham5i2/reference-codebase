UPDATE ri_owner.check_outcome_type
SET eligible_for_integrity_check=true
WHERE check_outcome_type_uuid='98760142-bace-4bb0-b2a9-d90b9b393553';

UPDATE ri_owner.check_outcome_type
SET eligible_for_integrity_check=true
WHERE check_outcome_type_uuid='c6eebce9-d53e-430b-ad36-44ed9ce2872a';