ALTER TABLE ri_owner.incident_type ADD COLUMN IF NOT EXISTS parent_incident_type_uuid uuid;

ALTER TABLE ri_owner.incident_category ADD COLUMN IF NOT EXISTS eligible_for_integrity_check BOOLEAN default TRUE;