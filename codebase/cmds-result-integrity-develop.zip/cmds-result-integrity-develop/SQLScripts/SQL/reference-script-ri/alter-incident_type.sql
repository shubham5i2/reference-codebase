ALTER TABLE ri_owner.incident_type ADD COLUMN IF NOT EXISTS external_incident_type
VARCHAR(200);