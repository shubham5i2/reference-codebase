INSERT INTO ri_owner.product
(product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description)
VALUES('5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0'::uuid, NULL, NULL, NOW(), 0, '2020-07-01', '2099-12-31', 'Operations User', NULL, 'IELTS on Computer', NULL)
ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product
(product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description)
VALUES('fdbacec5-e80a-4710-b3de-7d5f310b1466'::uuid, '5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0'::uuid, NULL, NOW(), 0, '2020-07-01', '2099-12-31', 'Operations User', NULL, 'IELTS on Computer Academic', NULL)
ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product
(product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description)
VALUES('6ccd6696-0660-409c-8a66-85d79c42f84d'::uuid, 'fdbacec5-e80a-4710-b3de-7d5f310b1466'::uuid, NULL, NOW(), 0, '2020-07-01', '2099-12-31', 'Operations User', NULL, 'IELTS on Computer Academic L', NULL)
ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product
(product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description)
VALUES('d40d2104-a610-42dc-936b-263fb4ba120a'::uuid, 'fdbacec5-e80a-4710-b3de-7d5f310b1466'::uuid, NULL, NOW(), 0, '2020-07-01', '2099-12-31', 'Operations User', NULL, 'IELTS on Computer Academic R', NULL)
ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product
(product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description)
VALUES('f0ea4e6f-d550-4687-a231-1032a7987441'::uuid, 'fdbacec5-e80a-4710-b3de-7d5f310b1466'::uuid, NULL, NOW(), 0, '2020-07-01', '2099-12-31', 'Operations User', NULL, 'IELTS on Computer Academic W', NULL)
ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product
(product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description)
VALUES('43215312-a604-4cbf-8b97-c3695b03e396'::uuid, 'fdbacec5-e80a-4710-b3de-7d5f310b1466'::uuid, NULL, NOW(), 0, '2020-07-01', '2099-12-31', 'Operations User', NULL, 'IELTS on Computer Academic S', NULL)
ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product
(product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description)
VALUES('cf9a05e9-2679-42da-b7d2-b34ea3e0724e'::uuid, '5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0'::uuid, NULL, NOW(), 0, '2020-07-01', '2099-12-31', 'Operations User', NULL, 'IELTS on Computer General Training', NULL)
ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product
(product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description)
VALUES('df2c8f7e-e485-441b-88a5-34b640bff6a5'::uuid, 'cf9a05e9-2679-42da-b7d2-b34ea3e0724e'::uuid, NULL, NOW(), 0, '2020-07-01', '2099-12-31', 'Operations User', NULL, 'IELTS on Computer General Training L', NULL)
ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product
(product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description)
VALUES('4871fd4e-0c92-40be-9ca1-2707ab1b4a3f'::uuid, 'cf9a05e9-2679-42da-b7d2-b34ea3e0724e'::uuid, NULL, NOW(), 0, '2020-07-01', '2099-12-31', 'Operations User', NULL, 'IELTS on Computer General Training R', NULL)
ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product
(product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description)
VALUES('b034eca1-0e06-4384-8ae5-e71af4d66bcb'::uuid, 'cf9a05e9-2679-42da-b7d2-b34ea3e0724e'::uuid, NULL, NOW(), 0, '2020-07-01', '2099-12-31', 'Operations User', NULL, 'IELTS on Computer General Training W', NULL)
ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO ri_owner.product
(product_uuid, parent_product_uuid, updated_datetime, created_datetime, concurrency_version, available_from_date, available_to_date, created_by, updated_by, product_name, product_description)
VALUES('be5f16d3-be46-4a6f-a3a5-268d5e1721cc'::uuid, 'cf9a05e9-2679-42da-b7d2-b34ea3e0724e'::uuid, NULL, NOW(), 0, '2020-07-01', '2099-12-31', 'Operations User', NULL, 'IELTS on Computer General Training S', NULL)
ON CONFLICT(product_uuid) DO NOTHING;