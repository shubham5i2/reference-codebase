ALTER TABLE ri_owner.product ALTER COLUMN  product_name TYPE varchar(50);

UPDATE ri_owner.product SET product_name = 'IELTS Online Academic' WHERE product_uuid = '3e81e94b-8b6a-42b5-970c-b141f9d195a3';
UPDATE ri_owner.product SET product_name = 'IELTS Online Academic R' WHERE product_uuid = '4ddcb08b-c2c7-412a-9f59-f4adaf3aa131';
UPDATE ri_owner.product SET product_name = 'IELTS Online Academic W' WHERE product_uuid = 'cb6f4028-c2d8-48f1-8006-1343760ec905';
UPDATE ri_owner.product SET product_name = 'IELTS Online Academic S' WHERE product_uuid = 'fd01b36e-bb07-4229-81c2-483308787e9f';
UPDATE ri_owner.product SET product_name = 'IELTS Online General Training' WHERE product_uuid = 'd96eece2-1d7c-495a-a754-6b523b710a82';
UPDATE ri_owner.product SET product_name = 'IELTS Online General Training L' WHERE product_uuid = '18c94472-35e8-4d89-93da-f6d9caa7f003';
UPDATE ri_owner.product SET product_name = 'IELTS Online General Training R' WHERE product_uuid = 'f21e2e7f-02e8-4bd7-9602-c247e8a02a5a';
UPDATE ri_owner.product SET product_name = 'IELTS Online General Training W' WHERE product_uuid = 'd8c32eff-1112-467b-a881-9e52f5acc796';
UPDATE ri_owner.product SET product_name = 'IELTS Online General Training S' WHERE product_uuid = '48b0643a-11eb-4eff-b4e3-3f930c6fcdd3';
UPDATE ri_owner.product SET product_name = 'IELTS Online Academic L' WHERE product_uuid = '0c6bc64c-fc66-4d5f-879d-89cdc6c3ed31';