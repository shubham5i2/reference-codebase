INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('edd3a415-5c0f-4350-bc0d-7b3a8ae27d55'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'malpractice_another_person_in_frame', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('a5f6e973-851e-4e33-8bcf-9c97bb269686'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'malpractice_assist_another_candidate', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('1b208818-2ff0-4338-9f41-d2a9a80c23af'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'malpractice_attempt_bribery_blackmail', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('d1dc09d8-f729-44e3-9f91-5866382ed5f2'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'malpractice_attempt_bluetooth', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('508d3493-b169-4f6f-bc20-f1714cd8a294'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'malpractice_communicate_other_person', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('64211b7d-9ae3-4508-b9c0-cb9f995be703'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'malpractice_copy_from_other_candidate', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('5cf0fd2f-3f50-4237-9b36-b6207bc10564'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'malpractice_counterfeit_tempered_id', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('ddb2686d-59b0-42d0-8acc-2a4a06a0de4c'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'malpractice_disconnect_from_internet', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('0c1898b6-cedd-4e1a-88aa-491f88fbdddb'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'malpractice_ignore_invigilator_instruction', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('bac5745b-91a1-423e-ac91-5265bbbe4d65'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'malpractice_imposter', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('27ee2fd0-fd09-40c2-96b6-c5ddd098f8e7'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'malpractice_id_not_verified', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('bd12131e-f411-4441-a23b-be51f9572062'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'id_photo_mismatch_personal', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', '27ee2fd0-fd09-40c2-96b6-c5ddd098f8e7'::uuid);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('7236364c-e324-4aaa-aeff-e30b416b26a5'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'id_document_mismatch', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', '27ee2fd0-fd09-40c2-96b6-c5ddd098f8e7'::uuid);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('e0122c50-d9ed-4950-978d-5dbc5246256e'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'other', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', '27ee2fd0-fd09-40c2-96b6-c5ddd098f8e7'::uuid);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('43cae917-4d5b-4122-b53f-4f80d1d2915d'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'malpractice_in_room_id_swap', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('09260095-a1d0-46c1-a46e-aa67b6b9bcfe'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'malpractice_interfere_device', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('e5b53c68-4268-428a-a751-f2264aac4a5b'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'malpractice_leave_room_before_end', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('6272eebc-b48b-4124-bf3a-bf11805642bd'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'malpractice_look_away_from_screen', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('f2d27561-0d7b-419c-ad66-fd6573baa1f1'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'malpractice_possess_electronic_device', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('06d16b48-7697-4701-998b-2e7ed5cc6a78'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'malpractice_remote_assistance', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('81f28ffc-e1dc-451c-8ce9-0deeb48ae7dc'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'malpractice_remove_test_data', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('586ba13d-4a60-4a80-8d1d-81c6b5701fb6'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'malpractice_id_require_follow_up', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('b2879700-978f-4638-9845-7a831a5be550'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'unsure_tt_photo_match', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', '586ba13d-4a60-4a80-8d1d-81c6b5701fb6'::uuid);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('b27426fb-432d-4ad6-bd0b-90a2a0b767aa'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'unsure_id_document_match', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', '586ba13d-4a60-4a80-8d1d-81c6b5701fb6'::uuid);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('be08a4cd-de9f-4616-8dd4-7468cdb015ca'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'unsure_id_photo_match_tt', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', '586ba13d-4a60-4a80-8d1d-81c6b5701fb6'::uuid);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('b807f404-b175-43ce-9168-3d2c36589800'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'other', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', '586ba13d-4a60-4a80-8d1d-81c6b5701fb6'::uuid);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('514f6342-37c5-433e-b328-abefce804508'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'malpractice_do_not_use_iep', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('91a92488-47b5-4cad-bc41-f2a953acb48b'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'malpractice_use_electronic_device', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('7bb39e96-3687-486c-8649-bba4f9ceb9f0'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'malpractice_use_prepared_notes', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('89f21d65-6a24-4254-be08-800805f16346'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'malpractice_use_unauthorized_device', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('97540655-b27e-4fa5-85a1-9e0483dc9099'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'malpractice_other', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('a7e4feb3-86e6-4cc2-8dd4-c39f342f55d7'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'malpractice_have_earpiece', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('8b8e8654-b778-4d92-962e-b174a2d5ec07'::uuid, 'fe29aad2-6971-4f04-8321-d800eac26c6f'::uuid, 'technical_minor_audio_issues', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'TECH_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('97540655-b27e-4fa5-85a1-9e0483dc9098'::uuid, 'fe29aad2-6971-4f04-8321-d800eac26c6f'::uuid, 'technical_loss_of_internet', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'TECH_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('1d62ccfb-7d66-4999-b4d3-20d2a4f0b202'::uuid, 'fe29aad2-6971-4f04-8321-d800eac26c6f'::uuid, 'technical_minor_video_issues', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'TECH_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('97540655-b27e-4fa5-85a1-9e0483dc9097'::uuid, 'fe29aad2-6971-4f04-8321-d800eac26c6f'::uuid, 'technical_other', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'TECH_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('4776f091-01a7-4d4b-89bf-bcc45c79a522'::uuid, 'fe29aad2-6971-4f04-8321-d800eac26c6f'::uuid, 'technical_major_video_issues', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'TECH_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('97540655-b27e-4fa5-85a1-9e0483dc9096'::uuid, 'fe29aad2-6971-4f04-8321-d800eac26c6f'::uuid, 'technical_major_audio_issues', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'TECH_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('d6ba52ee-7c44-4212-a38d-76eafbccd98e'::uuid, '1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9'::uuid, 'other_tt_known_to_examiner', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'OTH_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('203bdd45-aaab-4724-8623-6f364cc3fac0'::uuid, '1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9'::uuid, 'other_tt_request_female_examiner', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'OTH_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('b93ae42d-0d97-4147-b2df-b47996c2973a'::uuid, '1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9'::uuid, 'other_tt_discontinue_test', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'OTH_INC', NULL);

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid)
VALUES('bf81b6d7-41ee-4c19-bdf3-78d3cf4b4749'::uuid, '1d2b6fd7-e289-45bc-ba9b-c08e5caba5d9'::uuid, 'other', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'OTH_INC', NULL);