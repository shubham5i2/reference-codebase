INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid, ban_review_required)
VALUES('b4a2217e-8064-4f71-9fb7-ca1cf164d423'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'Accessing prohibited programs/applications', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL, TRUE);
INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid, ban_review_required)
VALUES('c673ea84-7182-47b3-8cd9-efc723f67d58'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'Hiding face', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL, TRUE);
INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid, ban_review_required)
VALUES('e0a6002a-99f8-4e92-8504-69ac78b8f61a'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'Participating in any other kind of malpractice, fraud, deception or behaviour deemed by the Test Partners to adversely affect the delivery, validity or reputation of IELTS tests or results', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL, TRUE);
INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid, ban_review_required)
VALUES('ff707183-dea9-4c48-93ba-b0b064203153'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'Possessing a Bluetooth device or camera/recording device', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL, TRUE);
INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid, ban_review_required)
VALUES('778a2ed2-482f-4887-bc52-52a6a1d7cc9c'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'Receiving assistance from another person in the room', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL, TRUE);
INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid, ban_review_required)
VALUES('00d2c608-9216-456a-85ec-db40d33f6a3a'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'Refusing to comply with reasonable requests to inspect personal items', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL, TRUE);
INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid, ban_review_required)
VALUES('5db24e51-515e-4f3b-b0cb-f77c33f7d63a'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'Threatening/abusive behaviour to invigilator/test-centre staff', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL, TRUE);
INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid, ban_review_required)
VALUES('f9f4089e-9e7f-4a34-9629-527ebf136c65'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'Using prepared notes (non version specific)', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL, NULL);
INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code, parent_incident_type_uuid, ban_review_required)
VALUES('e782348e-bedf-403a-9f28-7ba5ce60952c'::uuid, '3109484a-af84-40eb-a244-fe15d4649104'::uuid, 'Using prepared notes (version specific)', '2020-07-01', '2099-12-31', 'Operations User', CURRENT_TIMESTAMP, NULL, NULL, 0, 'MPC_INC', NULL, TRUE);
