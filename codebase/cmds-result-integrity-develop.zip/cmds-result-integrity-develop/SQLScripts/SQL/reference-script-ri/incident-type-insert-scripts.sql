INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code)
VALUES('0a896faa-cb43-43ce-8295-48b20373be7a'::uuid, 'ffc3db8f-6a8e-4923-8e52-d5dabc51328a'::uuid, 'Probability', '2020-07-01', '2099-12-31', 'Operations User', '2021-09-23 14:43:02.979', NULL, NULL, 0, 'PRC_PROB_INC');

INSERT INTO ri_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, effective_to_date, created_by, created_datetime, updated_by, updated_datetime, concurrency_version, incident_type_code)
VALUES('2db1fbe1-ae17-4a9b-b821-fd94cccc32e7'::uuid, 'ffc3db8f-6a8e-4923-8e52-d5dabc51328a'::uuid, 'Repeater', '2020-07-01', '2099-12-31', 'Operations User', '2021-09-23 14:43:02.979', NULL, NULL, 0, 'PRC_REP_INC');
