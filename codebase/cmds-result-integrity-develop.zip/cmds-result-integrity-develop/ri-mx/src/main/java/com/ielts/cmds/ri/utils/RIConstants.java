package com.ielts.cmds.ri.utils;

public class RIConstants {

    private RIConstants() {
        throw new IllegalArgumentException("RIConstants");
    }

    public final class EventType {
        private EventType() {
            throw new IllegalArgumentException("EventType");
        }

        public static final String LOCATION_CREATED_EVENT = "LocationCreated";
        public static final String LOCATION_CHANGED_EVENT = "LocationChanged";

        public static final String BOOKING_CREATED_EVENT = "BookingCreated";
        public static final String BOOKING_UPDATED_EVENT = "BookingUpdated";
        public static final String BOOKING_CANCELLED_EVENT = "BookingCancelled";
        public static final String BOOKING_TRANSFERRED_EVENT = "BookingTransferred";
        public static final String PRC_OUTCOME_GENERATED_EVENT = "PRCOutcomeGenerated";
        public static final String PRC_OUTCOME_RECEIVED_EVENT = "PrcOutcomeReceived";
        public static final String RESULT_INTEGRITY_CHECK_CHANGED_EVENT = "ResultIntegrityCheckChanged";
        public static final String RESULT_INTEGRITY_CHECK_CHANGED_EVENT_FAIL = "ResultIntegrityCheckChangedFailed";
        public static final String BOOKING_SEARCH_RESPONSE_GENERATED = "BookingSearchResponseGenerated";
        public static final String IDS_TEST_DAY_INCIDENT_RAISED = "TestDayIncidentRaised";
        public static final String INTEGRITY_CHECK_INITIATED = "IntegrityCheckInitiated";
        public static final String RESULT_INTEGRITY_INCIDENT_DETAILS_RAISED = "ResultIntegrityIncidentDetailsRaised";
        public static final String OVERALL_INTEGRITY_CHECK_INITIATED = "OverallIntegrityCheckInitiated";
        public static final String PHOTO_PUBLISHED_EVENT = "PhotoPublished";
        public static final String INCIDENT_VIEW_RESPONSE_DETAILS_GENERATED_EVENT = "IncidentViewResponseDetailsGenerated";
        public static final String INCIDENT_SEARCH_RESPONSE_GENERATED = "IncidentSearchResponseGenerated";
        public static final String ID_PHOTOS_RESPONSE_GENERATED_EVENT = "IdPhotosResponseGenerated";
        public static final String RESULT_INTEGRITY_BOOKING_CONSUMED = "ResultIntegrityBookingConsumed";
        public static final String RESULT_INTEGRITY_BOOKING_REJECTED = "ResultIntegrityBookingRejected";
        public static final String RESULT_INTEGRITY_LOCATION_CONSUMED = "ResultIntegrityLocationConsumed";
        public static final String RESULT_INTEGRITY_LOCATION_REJECTED = "ResultIntegrityLocationRejected";
        public static final String RESULT_INTEGRITY_PHOTO_CONSUMED = "ResultIntegrityPhotoConsumed";
        public static final String PROBABLE_BAN_OUTCOME_RECEIVED_EVENT = "ProbableBanCheckOutcomeReceived";

    }


    public final class GenericConstants {

        private GenericConstants() {
            throw new IllegalArgumentException("GenericConstants");
        }

        public static final String MSG_ATTR_DATA_TYPE = "String";
        public static final String CONNECTION_ID = "connectionId";
        public static final String EVENT_NAME = "eventName";
        public static final String RI_SERVICE_NAME = "RIService";
        public static final String PARTNER_CODE = "partnerCode";
        public static final String APP_NAME = "ri-mx";
        public static final String TEST_CENTRE = "TEST_CENTRE";

    }

    public final class ErrorResponse {

        private ErrorResponse() {
            throw new IllegalArgumentException("ExceptionErrorCodes");
        }

        public static final String EMPTY_PAYLOAD = "Payload is Empty";
        public static final String RI_INTERFACE_ERROR = "RI-MX";
    }

    public final class CheckOutcomeTypeConstants {

        private CheckOutcomeTypeConstants() {
            throw new IllegalArgumentException("CheckOutcomeTypeConstants");
        }

        public static final String CHK_OUT_TYPE_SPEAKING_INC_CHK_CODE = "SPK_INC_CHK";
        public static final String CHK_OUT_TYPE_LRW_INC_CHK_CODE = "LRW_INC_CHK";
        public static final String CHK_OUT_TYPE_PLG_INC_CHK_CODE = "PLG_INC_CHK";
        public static final String CHK_OUT_TYPE_LRW_ID_INC_CHK_CODE = "LRW_ID_INC_CHK";
        public static final String CHK_OUT_TYPE_PRC_INC_CHK_CODE = "PRC_INC_CHK";
        public static final String CHK_OUT_TYPE_PRO_BAN_INC_CHK_CODE = "PROB_BANNED_INC_CHK";
    }


    public final class PrcOutcomeConstant {

        private PrcOutcomeConstant() {
            throw new IllegalArgumentException("PrcOutcomeConstanta");
        }

        public static final String PRC_INCIDENT_TYPE_DESCRIPTION = "PRC Outcome";
        public static final String INCIDENT_STATUS_TYPE_CODE_FLAGGED = "INC_STATUS_FLAGGED";
        public static final String INCIDENT_STATUS_TYPE_CODE_PASSED = "INC_STATUS_PASSED";
        public static final String INCIDENT_STATUS_TYPE_CODE_CONFIRMED = "INC_STATUS_CONFIRMED";
        public static final String INCIDENT_STATUS_TYPE_CODE_DISMISSED = "INC_STATUS_CLEARED";
        public static final String INCIDENT_STATUS_TYPE_CODE_REFERRED = "INC_STATUS_FOLLOW_UP_REQUIRED";
        public static final String INCIDENT_TYPE_CODE_PROBABILITY = "PRC_PROB_INC";
        public static final String INCIDENT_TYPE_CODE_REPEATER = "PRC_REP_INC";
        public static final String INCIDENT_STATUS_TYPE_CODE_INVESTIGATION =
                "INC_STATUS_INVESTIGATION_IN_PROGRESS";

        public static final String INCIDENT_TYPE_CODE_PLAGIARISM = "PLG_INC";

        public static final String OUTCOME_STATUS_TYPE_CODE_REFER = "OUT_STATUS_REFER";
        public static final String OUTCOME_STATUS_TYPE_CODE_PASSED = "OUT_STATUS_PASSED";
        public static final String OUTCOME_STATUS_TYPE_CODE_NOT_STARTED = "OUT_STATUS_NOT_STARTED";

        public static final String CANDIDATE_ID_CHECK_OUTCOME = "CandidateIdCheckOutcome";
        public static final String LRW_ID_INC_CHK = "LRW_ID_INC_CHK";
        public static final String LRW_INC_CHK = "LRW_INC_CHK";
        public static final String SPEAKING_ID_AND_INCIDENT_RAISED = "SpeakingIdandIncidentRaised";
        public static final String SPK_ID_INC_CHK = "SPK_ID_INC_CHK";
        public static final String MALPRACTICE_INC = "MALPRACTICE_INC";
        public static final String PRC_INC = "PRC_INC";
        public static final String PLG_INC="PLG_INC";
        public static final String PRC_OUT_INC = "PRC_OUT_INC";
        public static final String SPK_INC_CHK = "SPK_INC_CHK";

        public static final String CHECK_OUTCOME_STATUS_CODE_PENDING = "CHK_OUT_PENDING";
        public static final String CHECK_OUTCOME_STATUS_CODE_REVIEW = "CHK_OUT_REVIEW";
        public static final String CHECK_OUTCOME_STATUS_CODE_REFER = "CHK_OUT_REFER";
        public static final String CHECK_OUTCOME_STATUS_CODE_PASSED = "CHK_OUT_PASSED";
        public static final String CHECK_OUTCOME_STATUS_CODE_CLEARED = "CHK_OUT_CLEARED";
        public static final String CHECK_OUTCOME_STATUS_CODE_FAILED = "CHK_OUT_FAILED";
        public static final String CHECK_OUTCOME_STATUS_CODE_NOT_STARTED = "CHK_OUT_NOT_STARTED";
        public static final String CHECK_OUTCOME_INVESTIGATION_IN_PROGRESS = "CHK_OUT_INVESTIGATION_IN_PROGRESS";
        public static final String CHECK_OUTCOME_TYPE_CODE = "PRC_INC_CHK";

        public static final String PLAGIARISM_CHECK_OUTCOME_TYPE_CODE = "PLG_INC_CHK";
        public static final String PLAGIARISM_OUTCOME_RECEIVED = "PlagiarismOutcomeReceived";
        public static final String PLAGIARISM_OUTCOME_CLEARED = "CLEARED";
        public static final String PLAGIARISM_OUTCOME_INDETERMINANT = "INDETERMINANT";
        public static final String PLAGIARISM_OUTCOME_PLAGIARISED = "PLAGIARISED";
        public static final String PLAGIARISM_OUTCOME_UNDER_INVESTIGATION =
                "UNDER_INVESTIGATION";

        public static final String OUTCOME_STATUS_TYPE_CODE_FAILED = "OUT_STATUS_FAILED";
        public static final String OUTCOME_STATUS_TYPE_CODE_IN_PROGRESS = "OUT_STATUS_IN_PROGRESS";
        public static final String OUTCOME_STATUS_TYPE_CODE_REVIEW = "OUT_STATUS_REVIEW";
        public static final String PROBABLE_BAN_CHECK_OUTCOME_TYPE_CODE = "PROB_BANNED_INC_CHK";
        public static final String PROBABLE_BAN_OUTCOME_PASSED = "PASSED";
        public static final String PROBABLE_BAN_OUTCOME_FLAGGED = "FLAGGED";
        public static final String INCIDENT_TYPE_CODE_PROBABLE_BAN = "PROB_BAN_INC";
        public static final String ID_VERIFICATION_STATUS_UNVERIFIED = "UNVERIFIED";
        public static final String ID_VERIFICATION_STATUS_VERIFIED = "VERIFIED";

    }

    public final class UiConstants {

        private UiConstants() {
            throw new IllegalArgumentException("UiConstants");
        }

        public static final String SEARCH_RESOURCE_TYPE = "/v1/incident/booking/search";
        public static final String SUBMIT_PRC_OUTCOME_RESOURCE_TYPE = "/v1/incident/submitprcoutcome";
        public static final String OPERATION_TYPE_POST = "POST";
        public static final String SEARCH_INCIDENT_TYPE = "/v1/incident/search";
        public static final String OPERATION_TYPE_GET = "GET";
        public static final String VIEW_ID_PHOTOS_RESOURCE = "/v1/incident/getidphotos/\\{bookingUuid\\}";
        public static final String INCIDENT_VIEW_RESOURCE = "/v1/incident/\\{bookingUuid\\}";
        public static final String SUBMIT_ID_CHECKOUTCOME_TYPE = "/v1/incident/submitidcheckoutcome";
        public static final String OPERATION_TYPE_PUT = "PUT";

        public static final String UPDATE_INCIDENT_TYPE = "/v1/incident/update";
    }

    public final class PermissionId {

        private PermissionId() {
            throw new IllegalArgumentException("PermissionIds");
        }

        // Permission Ids
        public static final String RI_BOOKING_SEARCH = "RI_BOOKING_SEARCH";
        public static final String RI_BOOKING_PRCOUTCOME = "RI_BOOKING_PRCOUTCOME";
        public static final String RI_INCIDENT_SEARCH = "RI_INCIDENT_SEARCH";
        public static final String RI_INCIDENT_UPDATE = "RI_INCIDENT_UPDATE";
        public static final String RI_INCIDENT_VIEW = "RI_INCIDENT_VIEW";
        public static final String RI_ID_CHECK_VIEW = "RI_ID_CHECK_VIEW";
        public static final String RI_ID_CHECK_UPDATE = "RI_ID_CHECK_UPDATE";
    }

    public final class IncidentStatusConstants {

        private IncidentStatusConstants() {
            throw new IllegalArgumentException("IncidentStatusConstants");
        }

    public static final String FLAGGED = "INC_STATUS_FLAGGED";
    public static final String INFO = "INC_STATUS_INFO";
    public static final String DISMISSED = "INC_STATUS_CLEARED";
    public static final String REFERRED = "INC_STATUS_FOLLOW_UP_REQUIRED";
    public static final String CONFIRMED = "INC_STATUS_CONFIRMED";
    public static final String PASSED = "INC_STATUS_PASSED";
  }

    public final class AwsConstants {

        private AwsConstants() {
            throw new IllegalArgumentException("IncidentStatusConstants");
        }

        public static final String RI_BUCKET = "RI_BUCKET";


    }


    public final class PhotoTypeConstants {

        private PhotoTypeConstants() {
            throw new IllegalArgumentException("PhotoTypeConstants");
        }

        public static final String PHOTO_TYPE_TT_ID_HR_R_CODE = "TT_ID_HR_R";
        public static final String PHOTO_TYPE_TT_P_LR_S_WC_CODE = "TT_P_LR_S_WC";
        public static final String PHOTO_TYPE_TT_ID_LRW_WC_CODE = "TT_ID_LRW_WC";
        public static final String PHOTO_TYPE_TT_ID_S_WC_CODE = "TT_ID_S_WC";
        public static final String PHOTO_TYPE_TT_P_LR_IAM_CODE = "TT_P_LR_IAM";
        public static final String PHOTO_TYPE_TT_P_LR_LRW_WC_CODE = "TT_P_LR_LRW_WC";

    }

    public final class ErrorCodes {

        private ErrorCodes() {
            throw new IllegalArgumentException("ErrorCodes");
        }

        public static final String UNAUTHORISED_TO_SEARCH = "V_unauthorised_to_search_incident";
        public static final String UNAUTHORISED_TO_UPDATE_ID_VERIFICATION_STATUS = "V_unauthorised_to_update_id_verification_status";
        public static final String UNAUTHORISED_TO_VIEW_ID_VERIFICATION_STATUS = "V_unauthorised_to_view_id_verification_status";
        public static final String UNAUTHORISED_TO_VIEW_INCIDENT = "V_unauthorised_to_view_incident";
        public static final String UNAUTHORISED_TO_UPDATE = "V_unauthorised_to_update_incident";
        public static final String UNAUTHORISED_TO_ACCESS_WITH_SELECTED_LOCATION = "E_unauthorised_to_access_with_selected_location";
        public static final String REJECT_WHEN_DATETIME_IS_OBSOLETE = "E_reject_when_datetime_is_obsolete";
    }


    public final class ProductName {

        private ProductName() {
            throw new IllegalArgumentException("ProductName");
        }

        public static final String SPEAKING_PRODUCT = "S";

    }

    public final class ContentType{
        private  ContentType() {
            throw new IllegalArgumentException("Content-Type");
        }
        public static final String DEFAULT_CONTENT_TYPE = "application/octet-stream";

        public static final String PDF_CONTENT_TYPE = "application/pdf";
        public static final String PLAIN_TEXT_CONTENT_TYPE = "text/plain";

        public static final String SVG_CONTENT_TYPE = "image/svg+xml";
        public static final String PNG_CONTENT_TYPE = "image/png";
        public static final String JPEG_CONTENT_TYPE = "image/jpeg";
        public static final String JPG_CONTENT_TYPE = "image/jpg";

        public static final String MP3_CONTENT_TYPE = "audio/mp3";
        public static final String WAV_CONTENT_TYPE = "audio/wav";

        public static final String MP4_CONTENT_TYPE = "video/mp4";
        public static final String MOV_CONTENT_TYPE = "video/quicktime";
    }

}
