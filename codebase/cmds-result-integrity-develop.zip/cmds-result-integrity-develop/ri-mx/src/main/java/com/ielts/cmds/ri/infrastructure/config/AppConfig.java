package com.ielts.cmds.ri.infrastructure.config;

import com.ielts.cmds.common.config.AWSCredentialsProviderFactory;
import com.ielts.cmds.common.config.JmsListnerConfig;
import com.ielts.cmds.common.logger.util.CMDSLoggerUtils;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({AWSCredentialsProviderFactory.class, JmsListnerConfig.class})
public class AppConfig {

	@Bean
	public CMDSLoggerUtils getCMDSLoggerUtils() {
		return new CMDSLoggerUtils();
	}
}
