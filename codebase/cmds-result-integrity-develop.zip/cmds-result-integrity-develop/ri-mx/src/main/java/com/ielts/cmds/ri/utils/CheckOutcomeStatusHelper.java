package com.ielts.cmds.ri.utils;

import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.INCIDENT_STATUS_TYPE_CODE_CONFIRMED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.INCIDENT_STATUS_TYPE_CODE_DISMISSED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.INCIDENT_STATUS_TYPE_CODE_FLAGGED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.INCIDENT_STATUS_TYPE_CODE_PASSED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.MALPRACTICE_INC;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.domain.enums.IncidentSeverityEnum;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeType;
import com.ielts.cmds.ri.infrastructure.entity.Incident;
import com.ielts.cmds.ri.infrastructure.entity.IncidentCategory;
import com.ielts.cmds.ri.infrastructure.entity.IncidentStatusType;
import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.ProductIncidentMapping;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentStatusTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.ProductIncidentMappingRepository;
import com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class CheckOutcomeStatusHelper {

    @Autowired
    CheckOutcomeRepository checkOutcomeRepository;
    @Autowired
    CheckOutcomeTypeRepository checkOutcomeTypeRepository;
    @Autowired
    CheckOutcomeStatusRepository checkOutcomeStatusRepository;
    @Autowired
    IncidentStatusTypeRepository incidentStatusTypeRepository;
    @Autowired
    private ProductIncidentMappingRepository productIncidentMappingRepository;
    @Autowired
    private RICommonUtil riCommonUtil;
    @Autowired
    private IncidentRepository incidentRepository;
    @Autowired
    OutcomeStatusRepository outcomeStatusRepository;
    
    public void setCheckOutcomeStatus(Incident incident, String checkOutcomeTypeCode, Booking optionalBooking) {
        if (isEligibleForIntegrityCheck(incident)) {
            log.info("Processing incident with Eligible For Integrity Check: true");
            CheckOutcomeType checkOutcomeType = getCheckOutComeType(checkOutcomeTypeCode);
            CheckOutcome checkOutcome = getCheckOutcome(incident, checkOutcomeType, optionalBooking);
    if (isMalpracticeIncident(incident) && incident.getIncidentSeverity() != null) {
        processMalpracticeIncident(incident, checkOutcome);
    }
    }
   } 

   private boolean isEligibleForIntegrityCheck(Incident incident) {
     return Boolean.TRUE.equals(incident.getIncidentCategoryByIncidentCategoryUuid().getEligibleForIntegrityCheck());
    }

   private boolean isMalpracticeIncident(Incident incident) {
    return MALPRACTICE_INC.equals(incident.getIncidentCategoryByIncidentCategoryUuid().getIncidentCategoryCode());
   }

   private void processMalpracticeIncident(Incident incident, CheckOutcome checkOutcome) {
    List<Incident> incidentList = getIncidentListByCheckOutcomeAndBookingUuid(checkOutcome, incident.getBookingUuid());
    Boolean checkIfAnyIncidentStatusIsConfirmed = getConfirmedIncidentBooleanList(incidentList);
    Boolean checkIfAnyIncidentStatusIsFlagged = getFlaggedIncidentBooleanList(incidentList);
    Boolean checkIfAllIncidentStatusIsCleared = getClearedIncidentBooleanList(incidentList);

     if (isIncidentSeverityConfirmedMalpractice(incident) && (isIncidentStatusConfirmed(incident)
        || checkIfAnyIncidentStatusIsConfirmed)) {
       logAndSetCheckOutcomeStatus(checkOutcome, PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_FAILED, incident);
     } else if (isIncidentSeverityConfirmedMalpractice(incident) && (isIncidentStatusFlagged(incident)
        || checkIfAnyIncidentStatusIsFlagged)) {
       logAndSetCheckOutcomeStatus(checkOutcome, PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_REVIEW, incident);
     } else if (isIncidentSeverityConfirmedMalpractice(incident) && (isIncidentStatusPassedOrDismissed(incident)
        && Boolean.TRUE.equals(checkIfAllIncidentStatusIsCleared))) {
       logAndSetCheckOutcomeStatus(checkOutcome, PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_PASSED, incident);
     } else {
    	 log.debug("Invalid incident");
     }
     }

     private boolean isIncidentSeverityConfirmedMalpractice(Incident incident) {
          return IncidentSeverityEnum.CONFIRMED_MALPRACTICE.getValue().equals(incident.getIncidentSeverity().getValue());
         }

         private boolean isIncidentStatusConfirmed(Incident incident) {
               return INCIDENT_STATUS_TYPE_CODE_CONFIRMED.equals(incident
                        .getIncidentStatusTypeByIncidentStatusTypeUuid().getIncidentStatusTypeCode());
         }

         private boolean isIncidentStatusFlagged(Incident incident) {
               return INCIDENT_STATUS_TYPE_CODE_FLAGGED.equals(incident
                         .getIncidentStatusTypeByIncidentStatusTypeUuid().getIncidentStatusTypeCode());
         }

         private boolean isIncidentStatusPassedOrDismissed(Incident incident) {
         return INCIDENT_STATUS_TYPE_CODE_PASSED.equals(incident
           .getIncidentStatusTypeByIncidentStatusTypeUuid().getIncidentStatusTypeCode())
                    || INCIDENT_STATUS_TYPE_CODE_DISMISSED.equals(incident
                      .getIncidentStatusTypeByIncidentStatusTypeUuid().getIncidentStatusTypeCode());
           }

         private void logAndSetCheckOutcomeStatus(CheckOutcome checkOutcome, String statusCode,Incident incident) {
            log.info("Setting checkOutcomeStatus to {}", statusCode);
            checkOutcome.setCheckOutcomeStatus(getCheckOutComeStatus(statusCode));
            if (Objects.nonNull(checkOutcome.getCheckOutcomeStatus())) {
                incident.setCheckOutcomeByCheckOutcomeUuid(checkOutcome);
                log.info("Persisting CheckOutcome for corresponding ExternalIncidentId: {}",
                        incident.getExternalIncidentId());
                checkOutcomeRepository.save(checkOutcome);
                Optional<OutcomeStatus> optionalOutcomeStatus = outcomeStatusRepository
                        .findByBookingUuid(incident.getBookingUuid());
                OutcomeStatus outcomeStatus = optionalOutcomeStatus.orElseGet(() -> OutcomeStatus.builder().build());
                outcomeStatus.setCheckOutcomeEventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime());
                outcomeStatusRepository.save(outcomeStatus);
              }

        
         }

    public IncidentStatusType getIncidentStatusType(
            Incident incident, IncidentCategory incidentCategory) {
        IncidentStatusType incidentStatusType = null;
        Booking booking = riCommonUtil.getBooking(incident);
        ProductIncidentMapping productIncidentMapping;
        if (Boolean.TRUE.equals(incidentCategory.getEligibleForIntegrityCheck())) {
            productIncidentMapping = productIncidentMappingRepository
                    .findByProductUuidAndIncidentCategoryUuidAndIncidentSeverity
                            (booking.getProductUuid(), incidentCategory.getIncidentCategoryUuid(),
                                    incident.getIncidentSeverity());
        } else {
            productIncidentMapping = productIncidentMappingRepository
                    .findByProductUuidAndIncidentCategoryUuid
                            (booking.getProductUuid(), incidentCategory.getIncidentCategoryUuid());
        }
        String incidentStatus = productIncidentMapping.getIncidentStatusTypeCode();

        Optional<IncidentStatusType> optionalIncidentStatusType =
                incidentStatusTypeRepository.findByIncidentStatusTypeCode(incidentStatus);
        if (optionalIncidentStatusType.isPresent()) {
            incidentStatusType = optionalIncidentStatusType.get();
        }
        return incidentStatusType;
    }

  public CheckOutcome getNewCheckOutcome(Incident incident, CheckOutcomeType checkOutcomeType, Booking booking) {

        CheckOutcome checkOutcome = new CheckOutcome();

    checkOutcome.setCheckOutcomeType(checkOutcomeType);
    checkOutcome.setBookingUuid(incident.getBookingUuid());
    checkOutcome.setBookingVersion(booking.getBookingVersion());
    checkOutcome.setEventDateTime(LocalDateTime.now());
    return checkOutcome;
  }

    public CheckOutcomeStatus getCheckOutComeStatus(String statusTypeCode) {
        CheckOutcomeStatus checkOutcomeStatus = null;
        Optional<CheckOutcomeStatus> optionalCheckOutcomeStatus =
                checkOutcomeStatusRepository.findByCheckOutcomeStatusCode(statusTypeCode);
        if (optionalCheckOutcomeStatus.isPresent()) {
            checkOutcomeStatus = optionalCheckOutcomeStatus.get();
        }
        return checkOutcomeStatus;
    }

    public CheckOutcomeType getCheckOutComeType(String typeCode) {
        CheckOutcomeType checkOutcomeType = null;
        Optional<CheckOutcomeType> optionalCheckOutcomeStatus =
                checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(typeCode);
        if (optionalCheckOutcomeStatus.isPresent()) {
            checkOutcomeType = optionalCheckOutcomeStatus.get();
        }
        return checkOutcomeType;
    }

    public Boolean getConfirmedIncidentBooleanList(List<Incident> incidentList) {

        boolean flag = false;

        for (Incident listedIncident : incidentList) {
            if (listedIncident.getIncidentStatusTypeByIncidentStatusTypeUuid()
                    .getIncidentStatusTypeCode()
                    .equals(INCIDENT_STATUS_TYPE_CODE_CONFIRMED)) {
                flag = true;
                break;
            }
        }
        return flag;

    }

    public Boolean getFlaggedIncidentBooleanList(List<Incident> incidentList) {

        boolean flag = false;

        for (Incident listedIncident : incidentList) {
            if (listedIncident.getIncidentStatusTypeByIncidentStatusTypeUuid()
                    .getIncidentStatusTypeCode()
                    .equals(INCIDENT_STATUS_TYPE_CODE_FLAGGED)) {
                flag = true;
                break;
            }
        }
        return flag;

    }

    public Boolean getClearedIncidentBooleanList(List<Incident> incidentList) {

        boolean flag = true;
        for (Incident listedIncident : incidentList) {

            if (listedIncident.getIncidentStatusTypeByIncidentStatusTypeUuid()
                    .getIncidentStatusTypeCode()
                    .equals(INCIDENT_STATUS_TYPE_CODE_FLAGGED) || listedIncident
                    .getIncidentStatusTypeByIncidentStatusTypeUuid()
                    .getIncidentStatusTypeCode()
                    .equals(INCIDENT_STATUS_TYPE_CODE_CONFIRMED)) {
                flag = false;
                break;
            }
        }
        return flag;
    }

  private List<Incident> getIncidentListByCheckOutcomeAndBookingUuid(CheckOutcome checkOutcome,
      UUID bookingUuid) {

    List<Incident> incidentList;
    if (Objects.isNull(checkOutcome.getCheckOutcomeUuid())) {
      checkOutcome = null;
    }
    incidentList = incidentRepository
        .findByCheckOutcomeByCheckOutcomeUuidAndBookingUuid(
            checkOutcome, bookingUuid);
    log.info("Incident List From checkOutcome and respective BookingUuid {} ", incidentList);
    return incidentList;
  }

  public CheckOutcome getCheckOutcome(Incident incident, CheckOutcomeType checkOutcomeType,Booking optionalBooking) {
    Optional<CheckOutcome> existingCheckOutcome = checkOutcomeRepository
        .findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
            incident.getBookingUuid(), Optional.ofNullable(checkOutcomeType).map(CheckOutcomeType::getCheckOutcomeTypeUuid).orElse(null));

    CheckOutcome checkOutcome;
    //optionalBooking.get().getBookingVersion()= newVersion ,,,existingCheckOutcome.get().getBookingVersion()=oldVersion
    if(Objects.nonNull(optionalBooking) && existingCheckOutcome.isPresent() ) {

        checkOutcome = existingCheckOutcome.get();
        checkOutcome.setBookingVersion(optionalBooking.getBookingVersion());
        log.info("CheckOutcome for corresponding Incident is already present.");

      } else {
        checkOutcome = getNewCheckOutcome(incident, checkOutcomeType, (optionalBooking != null ?
            optionalBooking : null));
        log.info("Creating new CheckOutcome for corresponding Incident.");
      }
      return checkOutcome;
  }
}

