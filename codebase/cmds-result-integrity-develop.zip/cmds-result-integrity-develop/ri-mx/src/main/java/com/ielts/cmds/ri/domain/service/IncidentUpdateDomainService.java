package com.ielts.cmds.ri.domain.service;

import static com.ielts.cmds.ri.utils.RIConstants.CheckOutcomeTypeConstants.CHK_OUT_TYPE_LRW_INC_CHK_CODE;
import static com.ielts.cmds.ri.utils.RIConstants.CheckOutcomeTypeConstants.CHK_OUT_TYPE_SPEAKING_INC_CHK_CODE;
import static com.ielts.cmds.ri.utils.RIConstants.IncidentStatusConstants.INFO;
import static com.ielts.cmds.ri.utils.RIConstants.PermissionId.RI_INCIDENT_UPDATE;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_FAILED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_PASSED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.INCIDENT_STATUS_TYPE_CODE_CONFIRMED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.INCIDENT_STATUS_TYPE_CODE_DISMISSED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.INCIDENT_STATUS_TYPE_CODE_PASSED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.MALPRACTICE_INC;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.PLG_INC;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.PRC_OUT_INC;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import javax.validation.ConstraintViolation;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.evt074.ResultIntegrityIncidentDetailsWrapperV1;
import com.ielts.cmds.api.evt119.CheckOutcomeV1;
import com.ielts.cmds.api.evt119.IntegrityCheckInitiatedV1;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.context.CMDSErrorContext;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalErrorContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.common.model.out.CommentDetailsV1;
import com.ielts.cmds.ri.common.model.out.ResultIntegrityIncidentDetailsV1;
import com.ielts.cmds.ri.common.model.out.UpdateIncidentDetailsV1;
import com.ielts.cmds.ri.domain.enums.ExternalIncidentStatusEnum;
import com.ielts.cmds.ri.domain.enums.IncidentCommentUserTypeEnum;
import com.ielts.cmds.ri.domain.enums.IncidentSeverityEnum;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeType;
import com.ielts.cmds.ri.infrastructure.entity.Incident;
import com.ielts.cmds.ri.infrastructure.entity.IncidentCategory;
import com.ielts.cmds.ri.infrastructure.entity.IncidentComment;
import com.ielts.cmds.ri.infrastructure.entity.IncidentStatusType;
import com.ielts.cmds.ri.infrastructure.entity.IncidentType;
import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatus;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentCategoryRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentStatusTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;
import com.ielts.cmds.serialization.domain.EnableOutboundEventV2;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Service
@EnableOutboundEventV2
public class IncidentUpdateDomainService extends AbstractCMDSDomainService<Object> {

  private final IncidentRepository incidentRepository;

  private final IncidentTypeRepository incidentTypeRepository;

  private final IncidentStatusTypeRepository incidentStatusTypeRepository;

  private final CheckOutcomeStatusRepository checkOutcomeStatusRepository;

  private final CheckOutcomeRepository checkOutcomeRepository;

  private final CheckOutcomeTypeRepository checkOutcomeTypeRepository;

  private final IncidentCategoryRepository incidentCategoryRepository;

  private final RICommonUtil commonUtil;

  private final CMDSErrorResolver<Object> errorResolver;

  private final OutcomeStatusRepository outcomeStatusRepository;

  @Autowired
  public IncidentUpdateDomainService(ApplicationEventPublisher publisher,
                                     ObjectMapper objectMapper,
                                     @Value("${incidentUpdate.v2}") String isV2Enabled,
                                     CMDSThreadLocalContextService cmdsThreadLocalContextService,
                                     IncidentRepository incidentRepository,
                                     IncidentTypeRepository incidentTypeRepository,
                                     IncidentStatusTypeRepository incidentStatusTypeRepository,
                                     CheckOutcomeStatusRepository checkOutcomeStatusRepository,
                                     CheckOutcomeRepository checkOutcomeRepository,
                                     CheckOutcomeTypeRepository checkOutcomeTypeRepository,
                                     IncidentCategoryRepository incidentCategoryRepository,
                                     RICommonUtil commonUtil,
                                     CMDSErrorResolver<Object> errorResolver,
                                     OutcomeStatusRepository outcomeStatusRepository) {
    super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
    this.incidentRepository = incidentRepository;
    this.incidentTypeRepository = incidentTypeRepository;
    this.incidentStatusTypeRepository = incidentStatusTypeRepository;
    this.checkOutcomeStatusRepository = checkOutcomeStatusRepository;
    this.checkOutcomeRepository = checkOutcomeRepository;
    this.checkOutcomeTypeRepository = checkOutcomeTypeRepository;
    this.incidentCategoryRepository = incidentCategoryRepository;
    this.commonUtil = commonUtil;
    this.errorResolver = errorResolver;
    this.outcomeStatusRepository = outcomeStatusRepository;
  }
  
  @Transactional(noRollbackFor = RuntimeException.class)
  public void on(final UpdateIncidentDetailsV1 updateIncidentDetails)
          throws JsonProcessingException, RbacValidationException {
	  log.info("Received event body for bookingUuid : {}",
              updateIncidentDetails.getIncidentDetails().getBookingUuid());

      CMDSHeaderContext cmdsHeaderContext = ThreadLocalHeaderContext.getContext();

      if (!hasAllAccessToUpdateIncident(cmdsHeaderContext)) {
          handleUnauthorizedAccess(cmdsHeaderContext);
      } else {
          log.info("You have permission to update incident");
          String bookingUuid = updateIncidentDetails.getIncidentDetails().getBookingUuid();
          Incident incident = getIncidentForUpdate(updateIncidentDetails, bookingUuid);
          updateBasedonIncidentCategory(updateIncidentDetails, incident);
      }
      log.debug("Starting of method initHeaderCtx {}", ThreadLocalHeaderContext.getContext());
   }

   private boolean hasAllAccessToUpdateIncident(CMDSHeaderContext cmdsHeaderContext) throws RbacValidationException {
      return commonUtil.hasAllAccess(cmdsHeaderContext.getXaccessToken(), RI_INCIDENT_UPDATE);
   }

   private void handleUnauthorizedAccess(CMDSHeaderContext cmdsHeaderContext) throws RbacValidationException {
      log.info("You do not have permission to update incidents details. " +
              "Please contact your administrator if you do not think this is correct.");
      Set<ConstraintViolation<Object>> violations = RICommonUtil.getSetforNullViolationOfEventBody(
              RIConstants.ErrorCodes.UNAUTHORISED_TO_UPDATE, "unauthorisedToUpdateIncident");
      publishIncidentUpdateEventToOutBoundTopic(null, violations, cmdsHeaderContext);
   }

   private Incident getIncidentForUpdate(UpdateIncidentDetailsV1 updateIncidentDetails, String bookingUuid) {
      Incident incident = getIncidentByUuid(updateIncidentDetails.getIncidentDetails().getIncidentUuid());
      if (Objects.isNull(incident)) {
          throw new ResultIntegrityException("Incident not found for bookingUuid : " + bookingUuid);
      }
      return incident;
   }

    private Incident getIncidentByUuid(String incidentUuid) {
      Optional<Incident> optIncident = incidentRepository.findByIncidentUuid(UUID.fromString(incidentUuid));
      return optIncident.orElseThrow(() -> new ResultIntegrityException(
              "Incident for corresponding incidentUuid not found : " + incidentUuid));
   }

    private void updateBasedonIncidentCategory(UpdateIncidentDetailsV1 updateIncidentDetails, Incident incident) {
      IncidentCategory incidentCategory = getIncidentCategory(
              UUID.fromString(updateIncidentDetails.getIncidentDetails().getIncidentCategoryUuid()));
      Incident updatedIncidentDetails;
      CMDSHeaderContext headerContext = ThreadLocalHeaderContext.getContext();
      if (isPlagiarismOrPrc(incidentCategory)) {
          log.info("Update incident for Plagiarism or PRC");
          updatedIncidentDetails = updateIncidentCommentDetails(updateIncidentDetails, incident);
      } else {
          log.info("Update incident for either Malpractice, Technical or Other");
          updatedIncidentDetails = updateIncidentDetails(updateIncidentDetails, incident);
          if (isMalpractice(incidentCategory)) {
              log.info("Category is Malpractice and Severity is Confirmed Malpractice: setting up CheckOutcomeStatus");
              updateCheckOutcomeStatus(updateIncidentDetails, incident);
              if (!Objects.isNull(incident.getCheckOutcomeByCheckOutcomeUuid())) {
                  publishIntegrityCheckInitiatedEvent(updatedIncidentDetails);
              }
          }
      }

      publishIntegrityIncidentDetailsRaisedEvent(updatedIncidentDetails);
      publishIncidentUpdateEventToOutBoundTopic(updatedIncidentDetails, null, headerContext);
    }

    private boolean isPlagiarismOrPrc(IncidentCategory incidentCategory) {
      return incidentCategory.getIncidentCategoryCode().equals(PLG_INC) ||
              incidentCategory.getIncidentCategoryCode().equals(PRC_OUT_INC);
    }

    private boolean isMalpractice(IncidentCategory incidentCategory) {
      return incidentCategory.getIncidentCategoryCode().equals(MALPRACTICE_INC);
    }

    private void publishIntegrityIncidentDetailsRaisedEvent(final Incident savedIncident) {

    buildHeaderForIntegrityIncidentDetailsRaised(savedIncident);
    log.info("IncidentUpdateDomainService |Publishing Event: {}", ThreadLocalHeaderContext.getContext().getEventName());

    ResultIntegrityIncidentDetailsWrapperV1 resultIntegrityIncidentDetailsWrapperV1 =
            commonUtil.populateIntegrityDetailsRaisedEventWithEvidence(savedIncident);

    commonUtil.publishLog();
    publishEvent(resultIntegrityIncidentDetailsWrapperV1);
    }

    private void buildHeaderForIntegrityIncidentDetailsRaised(Incident savedIncident) {
    CMDSHeaderContext headerContext = new CMDSHeaderContext();
    headerContext.setCorrelationId(ThreadLocalHeaderContext.getContext().getCorrelationId());
    headerContext.setEventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime());
    headerContext.setTransactionId(ThreadLocalHeaderContext.getContext().getTransactionId());
    headerContext.setPartnerCode(ThreadLocalHeaderContext.getContext().getPartnerCode());
    headerContext.setEventName(RIConstants.EventType.RESULT_INTEGRITY_INCIDENT_DETAILS_RAISED);
    headerContext.setEventContext(
            Collections.singletonMap("incidentUuid", String.valueOf(savedIncident.getIncidentUuid())));
    ThreadLocalHeaderContext.clearContext();
    ThreadLocalHeaderContext.setContext(headerContext);

    }

    private void publishIntegrityCheckInitiatedEvent(
      final Incident updateIncident) {

      log.info("IncidentUpdateDomainService |Publishing Event: {}",
        RIConstants.EventType.INTEGRITY_CHECK_INITIATED);
     buildHeader(updateIncident);
     IntegrityCheckInitiatedV1 integrityCheckInitiatedV1 = populateIntegrityCheckEvent(updateIncident);

    commonUtil.publishLog();
    publishEvent(integrityCheckInitiatedV1);
     }

    private void buildHeader(final Incident incident) {
    CMDSHeaderContext headerContext = new CMDSHeaderContext();
    headerContext.setCorrelationId(ThreadLocalHeaderContext.getContext().getCorrelationId());
    headerContext.setEventDateTime(LocalDateTime.now(ZoneOffset.UTC));
    headerContext.setTransactionId(ThreadLocalHeaderContext.getContext().getTransactionId());
    headerContext.setPartnerCode(ThreadLocalHeaderContext.getContext().getPartnerCode());
    headerContext.setEventName(RIConstants.EventType.INTEGRITY_CHECK_INITIATED);
    headerContext.setEventContext(
        Collections.singletonMap("incidentUuid", incident.getIncidentUuid().toString()));
    ThreadLocalHeaderContext.clearContext();
    ThreadLocalHeaderContext.setContext(headerContext);
    }

     private IntegrityCheckInitiatedV1 populateIntegrityCheckEvent(final Incident incident) {

    IntegrityCheckInitiatedV1 integrityCheckInitiatedV1=new IntegrityCheckInitiatedV1();
    if (Objects.nonNull(incident)) {
      integrityCheckInitiatedV1.bookingUuid((incident.getBookingUuid()));
      integrityCheckInitiatedV1.checkOutcome(getCheckOutcomeV1(incident.getCheckOutcomeByCheckOutcomeUuid()));
      integrityCheckInitiatedV1.setBookingVersion(incident.getCheckOutcomeByCheckOutcomeUuid().getBookingVersion());
    }
    return integrityCheckInitiatedV1;

    }
    private CheckOutcomeV1 getCheckOutcomeV1(final CheckOutcome checkOutcome) {

    CheckOutcomeV1 checkOutcomeV1 = new CheckOutcomeV1();
    if (Objects.nonNull(checkOutcome)) {
      checkOutcomeV1.setCheckOutcomeTypeUuid(
              checkOutcome.getCheckOutcomeType().getCheckOutcomeTypeUuid());
        checkOutcomeV1.setCheckOutcomeStatusUuid(
                checkOutcome.getCheckOutcomeStatus().getCheckOutcomeStatusUuid());
     }
     return checkOutcomeV1;
    }

  public void publishIncidentUpdateEventToOutBoundTopic(final Incident savedIncident,
      final Set<ConstraintViolation<Object>> violations,
      CMDSHeaderContext headerContext) {
    log.debug("inside ui method publishing {}", headerContext);
    log.info("publishing event {}", headerContext.getEventName());
    ThreadLocalHeaderContext.clearContext();
    ThreadLocalHeaderContext.setContext(headerContext);
    ResultIntegrityIncidentDetailsWrapperV1 resultIntegrityIncidentDetailsWrapperV1 = Objects.isNull(savedIncident) ? null :
            commonUtil.populateIntegrityDetailsRaisedEventWithEvidence(savedIncident);
    if (CollectionUtils.isNotEmpty(violations)) {
      CMDSErrorResponse eventErrors =
          errorResolver.populatErrorResponse(
              violations, ThreadLocalHeaderContext.getContext().getEventName());
      ThreadLocalErrorContext.setContext(new CMDSErrorContext(eventErrors.getErrorList()));
      publishEvent(null, ThreadLocalErrorContext.getContext().getErrorList());
    } else {
      log.debug("Publishing UI event with event body {}", resultIntegrityIncidentDetailsWrapperV1);
      publishEvent(resultIntegrityIncidentDetailsWrapperV1);
    }

  }

  private CheckOutcome updateCheckOutcomeStatus(final UpdateIncidentDetailsV1 updateIncidentDetails, final Incident incident) {

    IncidentCategory incidentCategory;
    CheckOutcomeStatus checkOutcomeStatus;
    IncidentStatusType incidentStatusType;
    ResultIntegrityIncidentDetailsV1 details = updateIncidentDetails.getIncidentDetails();

    CheckOutcome checkOutcome = getCheckOutcome(incident);


    incidentCategory = getIncidentCategory(UUID.fromString(details.getIncidentCategoryUuid()));
    incidentStatusType = updateIncidentStatusType(
        UUID.fromString(details.getIncidentStatusTypeUuid()));

    if (incidentCategory.getIncidentCategoryCode().equals(MALPRACTICE_INC)
        && details.getIncidentSeverity() != null) {

      if (IncidentSeverityEnum.CONFIRMED_MALPRACTICE.getValue().equals(details.getIncidentSeverity()
          .getValue()) && incidentStatusType.getIncidentStatusTypeCode()
          .equals(INCIDENT_STATUS_TYPE_CODE_CONFIRMED)) {

        checkOutcomeStatus = getCheckOutComeStatus(CHECK_OUTCOME_STATUS_CODE_FAILED);
        log.info("Setting checkOutcomeStatus to failed {} ", checkOutcomeStatus);
        checkOutcome.setCheckOutcomeStatus(checkOutcomeStatus);
      } else if (
          (IncidentSeverityEnum.CONFIRMED_MALPRACTICE.getValue().equals(details.getIncidentSeverity()
              .getValue()) && incidentStatusType.getIncidentStatusTypeCode()
              .equals(INCIDENT_STATUS_TYPE_CODE_PASSED)) ||
              incidentStatusType.getIncidentStatusTypeCode()
                  .equals(INCIDENT_STATUS_TYPE_CODE_DISMISSED) ||
      IncidentSeverityEnum.WARNING.getValue().equals(details.getIncidentSeverity().getValue()))
       {

        Boolean incidentBooleanList = getIncidentBooleanList(incident, checkOutcome);

        if (Boolean.TRUE.equals(incidentBooleanList)) {
          log.info("When IncidentStatus list true set status as passed");
          checkOutcomeStatus = getCheckOutComeStatus(CHECK_OUTCOME_STATUS_CODE_PASSED);
          log.info("Setting checkOutcomeStatus to passed {} ", checkOutcomeStatus);
          checkOutcome.setCheckOutcomeStatus(checkOutcomeStatus);
        }
      }else {
    	  log.debug("Invalid incident details");
      }

      incident.setCheckOutcomeByCheckOutcomeUuid(checkOutcome);
    }
    log.info("Persisting CheckOutcome for corresponding IncidentUuid: {}",
        details.getIncidentUuid());
    CheckOutcome checkOutcomeEntity = checkOutcomeRepository.save(checkOutcome);
    Optional<OutcomeStatus> optionalOutcomeStatus = outcomeStatusRepository
        .findByBookingUuid(UUID.fromString(updateIncidentDetails.getIncidentDetails().getBookingUuid()));
    OutcomeStatus outcomeStatus = optionalOutcomeStatus.orElseGet(() -> OutcomeStatus.builder().build());
    outcomeStatus.setCheckOutcomeEventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime());
    outcomeStatusRepository.save(outcomeStatus);
    incidentRepository.save(incident);
    return checkOutcomeEntity;
  }

  public Boolean getIncidentBooleanList(Incident incident, CheckOutcome checkOutcome) {

    boolean flag = false;
    List<Incident> incidentListForBooleanValue = getIncidentListFromCheckOutcomeAndBookingUuid(
        checkOutcome, incident.getBookingUuid());

    for (Incident listedIncident : incidentListForBooleanValue) {

      if(incident.getIncidentUuid().equals(listedIncident.getIncidentUuid())){
        flag=true;
      }

      else  if (listedIncident.getIncidentStatusTypeByIncidentStatusTypeUuid().getIncidentStatusTypeCode()
          .equals(INCIDENT_STATUS_TYPE_CODE_DISMISSED) || listedIncident
          .getIncidentStatusTypeByIncidentStatusTypeUuid()
          .getIncidentStatusTypeCode()
          .equals(INCIDENT_STATUS_TYPE_CODE_PASSED) || listedIncident
              .getIncidentStatusTypeByIncidentStatusTypeUuid()
              .getIncidentStatusTypeCode()
              .equals(INFO)
      ) {

        flag = true;
      } else {

        flag = false;
        break;
      }
    }
    return flag;

  }

  private List<Incident> getIncidentListFromCheckOutcomeAndBookingUuid(CheckOutcome checkOutcome,
      UUID bookingUuid) {

    List<Incident> incidentList;

    incidentList = incidentRepository
        .findByCheckOutcomeByCheckOutcomeUuidAndBookingUuid(
            checkOutcome, bookingUuid);
    log.info("Incident List From checkOutcome and respective BookingUuid {} ", incidentList);
    return incidentList;
  }

  public CheckOutcomeType getNewCheckOutcomeType(final Incident incident) {

    ExternalIncidentStatusEnum externalIncidentStatus = incident.getExternalIncidentStatus();
    log.info("defined externalIncidentStatus is{} ",
        incident.getExternalIncidentStatus());

    CheckOutcomeType checkOutcomeType = new CheckOutcomeType();

      if (Objects.isNull(externalIncidentStatus)) {
        log.info("ExternalIncidentStatus is null setting checkOutcomeType to LRW {} ",
            incident.getExternalIncidentStatus());
        checkOutcomeType.setCheckOutcomeTypeCode(CHK_OUT_TYPE_LRW_INC_CHK_CODE);
      } else {
        log.info("ExternalIncidentStatus is not null setting checkOutcomeType to Speaking {} ",
            incident.getExternalIncidentStatus());
        checkOutcomeType.setCheckOutcomeTypeCode(CHK_OUT_TYPE_SPEAKING_INC_CHK_CODE);
      }

      Optional<CheckOutcomeType> optionalCheckOutcomeType =
          checkOutcomeTypeRepository
              .findByCheckOutcomeTypeCode(checkOutcomeType.getCheckOutcomeTypeCode());
      if (optionalCheckOutcomeType.isPresent()) {
        checkOutcomeType = optionalCheckOutcomeType.get();
      }

    return checkOutcomeType;
  }

  CheckOutcome getNewCheckOutcome(final Incident incident) {
    CheckOutcomeType checkOutcomeType = getNewCheckOutcomeType(incident);
    CheckOutcome checkOutcome = new CheckOutcome();

    checkOutcome.setCheckOutcomeType(checkOutcomeType);
    checkOutcome.setBookingUuid(incident.getBookingUuid());

    return checkOutcome;
  }

  public CheckOutcome getCheckOutcome(final Incident existIncident) {
    CheckOutcome checkOutcome;
    if (Objects.nonNull(existIncident.getCheckOutcomeByCheckOutcomeUuid())) {
      checkOutcome = existIncident.getCheckOutcomeByCheckOutcomeUuid();
      log.info("CheckOutcome for corresponding Incident is already present.");
    } else {
      checkOutcome = getNewCheckOutcome(existIncident);
      log.info("Creating new CheckOutcome for corresponding Incident.");
    }
    return checkOutcome;
  }


  private Incident updateIncidentDetails(final UpdateIncidentDetailsV1 updateIncidentDetails,
      final Incident incident) {

    log.info("Update incident with all the required fields.");

    ResultIntegrityIncidentDetailsV1 detailsV1 = updateIncidentDetails.getIncidentDetails();
    incident.setIncidentTypeByIncidentTypeUuid(updateIncidentType(UUID.fromString(
            updateIncidentDetails.getIncidentDetails().getIncidentTypeUuid())));
    incident.setIncidentStatusTypeByIncidentStatusTypeUuid(
        updateIncidentStatusType(UUID.fromString(updateIncidentDetails.getIncidentDetails().getIncidentStatusTypeUuid())));
    incident.setIncidentSeverity(
        IncidentSeverityEnum.valueOf(detailsV1.getIncidentSeverity().toString()));
    incident.setBookingUuid(UUID.fromString(detailsV1.getBookingUuid()));
    if (Objects.nonNull(detailsV1.getComments())) {
      setComments(updateIncidentDetails, incident);
    }
    incidentRepository.save(incident);

    return incident;

  }

  private Incident updateIncidentCommentDetails(final UpdateIncidentDetailsV1 updateIncidentDetails,
      final Incident incident) {

    log.info("Update Incident with only comments");

    ResultIntegrityIncidentDetailsV1 detailsV1 = updateIncidentDetails.getIncidentDetails();

    if (Objects.nonNull(detailsV1.getComments())) {
      setComments(updateIncidentDetails, incident);
    }
    incidentRepository.save(incident);

    return incident;

  }


  private void setComments(
      final UpdateIncidentDetailsV1 updateIncidentDetails, final Incident incidentComments) {
      updateIncidentDetails
        .getIncidentDetails()
        .getComments()
        .forEach(comment -> incidentComments.addIncidentComment(buildComment(comment)));
  }

  private IncidentComment buildComment(final CommentDetailsV1 comment) {
    return IncidentComment.builder()
        .incidentCommentEnteredBy(comment.getCommentEnteredBy())
        .incidentCommentText(comment.getComment())
        .incidentCommentDateTime(commonUtil.stringToOffsetDateTime(comment.getCommentDateTime()))
        .incidentCommentUserType(IncidentCommentUserTypeEnum.valueOf(comment.getUserType()))
        .build();
  }

  IncidentCategory getIncidentCategory(final UUID incidentCategoryUuid) {
    IncidentCategory incidentCategory;
    Optional<IncidentCategory> optCategory = incidentCategoryRepository
        .findByIncidentCategoryUuid(incidentCategoryUuid);
    if (optCategory.isPresent()) {
      incidentCategory = optCategory.get();
    } else {
      throw new ResultIntegrityException(
          "IncidentCategory for corresponding booking not found : {}" + incidentCategoryUuid);
    }
    return incidentCategory;
  }

  private CheckOutcomeStatus getCheckOutComeStatus(final String statusTypeCode) {
    CheckOutcomeStatus checkOutcomeStatus = null;
    Optional<CheckOutcomeStatus> optionalCheckOutcomeStatus =
        checkOutcomeStatusRepository.findByCheckOutcomeStatusCode(statusTypeCode);
    if (optionalCheckOutcomeStatus.isPresent()) {
      checkOutcomeStatus = optionalCheckOutcomeStatus.get();
      log.info("checkOutcomeStatus is present {} ", checkOutcomeStatus.getCheckOutcomeStatusCode());
    }
    log.info("generated checkOutcomeStatus is {} ", checkOutcomeStatus);
    return checkOutcomeStatus;
  }


  private IncidentStatusType updateIncidentStatusType(final UUID incidentStatusId) {

    IncidentStatusType incidentStatusType;
    Optional<IncidentStatusType> incidentStatus = incidentStatusTypeRepository
        .findById(incidentStatusId);
    if (incidentStatus.isPresent()) {

      incidentStatusType = incidentStatus.get();
    } else {
      throw new ResultIntegrityException("Incident Status type not found : {}" + incidentStatusId);
    }
    return incidentStatusType;
  }

  private IncidentType updateIncidentType(final UUID incidentTypeId) {

    IncidentType incidentType;
    Optional<IncidentType> optionalIncidentType = incidentTypeRepository.findById(incidentTypeId);
    if (optionalIncidentType.isPresent()) {

      incidentType = optionalIncidentType.get();
    } else {
      throw new ResultIntegrityException("Incident type not found : {}" + incidentTypeId);
    }
    return incidentType;
  }

}
