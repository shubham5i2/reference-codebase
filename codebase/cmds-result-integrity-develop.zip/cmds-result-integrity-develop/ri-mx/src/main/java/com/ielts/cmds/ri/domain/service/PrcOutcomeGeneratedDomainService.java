package com.ielts.cmds.ri.domain.service;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.evt119.CheckOutcomeV1;
import com.ielts.cmds.api.evt119.IntegrityCheckInitiatedV1;
import com.ielts.cmds.ids.common.in.model.PRCRecommendationNodeV1ProbabilityAnalysis;
import com.ielts.cmds.ids.common.in.model.PRCRecommendationNodeV1RepeaterAnalysis;
import com.ielts.cmds.ids.domain.model.PRCOutcomeGeneratedNodeV1;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeType;
import com.ielts.cmds.ri.infrastructure.entity.Incident;
import com.ielts.cmds.ri.infrastructure.entity.IncidentEvidence;
import com.ielts.cmds.ri.infrastructure.entity.IncidentStatusType;
import com.ielts.cmds.ri.infrastructure.entity.IncidentType;
import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.PrcOutcomeDetails;
import com.ielts.cmds.ri.infrastructure.entity.PrcProbabilityAnalysis;
import com.ielts.cmds.ri.infrastructure.entity.PrcRepeaterAnalysis;
import com.ielts.cmds.ri.infrastructure.entity.PrcRepeaterFlag;
import com.ielts.cmds.ri.infrastructure.entity.ProductIncidentMapping;
import com.ielts.cmds.ri.infrastructure.entity.UniqueTestTaker;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentStatusTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.PrcOutcomeDetailsRepository;
import com.ielts.cmds.ri.infrastructure.repository.ProductIncidentMappingRepository;
import com.ielts.cmds.ri.infrastructure.repository.UniqueTestTakerRepository;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;
import com.ielts.cmds.serialization.domain.EnableOutboundEventV2;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@EnableOutboundEventV2
public class PrcOutcomeGeneratedDomainService extends AbstractCMDSDomainService<IntegrityCheckInitiatedV1> {

    private final BookingRepository bookingRepository;
    private final IncidentTypeRepository incidentTypeRepository;
    private final IncidentStatusTypeRepository incidentStatusTypeRepository;
    private final CheckOutcomeRepository checkOutcomeRepository;
    private final CheckOutcomeStatusRepository checkOutcomeStatusRepository;
    private final CheckOutcomeTypeRepository checkOutcomeTypeRepository;
    private final IncidentRepository incidentRepository;
    private final PrcOutcomeDetailsRepository prcOutcomeDetailsRepository;
    private final UniqueTestTakerRepository uniqueTestTakerRepository;
    private final OutcomeStatusRepository outcomeStatusRepository;
    private final ProductIncidentMappingRepository productIncidentMappingRepository;
    private final RICommonUtil riCommonUtil;
    
    @Autowired
    public PrcOutcomeGeneratedDomainService(ApplicationEventPublisher publisher,
                                            ObjectMapper objectMapper,
                                            @Value("${prcOutcomeGenerated.v2}") String isV2Enabled,
                                            CMDSThreadLocalContextService cmdsThreadLocalContextService,
                                            BookingRepository bookingRepository,
                                            IncidentTypeRepository incidentTypeRepository,
                                            IncidentStatusTypeRepository incidentStatusTypeRepository,
                                            CheckOutcomeRepository checkOutcomeRepository,
                                            CheckOutcomeStatusRepository checkOutcomeStatusRepository,
                                            CheckOutcomeTypeRepository checkOutcomeTypeRepository,
                                            IncidentRepository incidentRepository,
                                            PrcOutcomeDetailsRepository prcOutcomeDetailsRepository,
                                            UniqueTestTakerRepository uniqueTestTakerRepository,
                                            OutcomeStatusRepository outcomeStatusRepository,
                                            ProductIncidentMappingRepository productIncidentMappingRepository,
                                            RICommonUtil riCommonUtil) {
		super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
		this.bookingRepository = bookingRepository;
		this.incidentTypeRepository = incidentTypeRepository;
		this.incidentStatusTypeRepository = incidentStatusTypeRepository;
		this.checkOutcomeRepository = checkOutcomeRepository;
		this.checkOutcomeStatusRepository = checkOutcomeStatusRepository;
		this.checkOutcomeTypeRepository = checkOutcomeTypeRepository;
		this.incidentRepository = incidentRepository;
		this.prcOutcomeDetailsRepository = prcOutcomeDetailsRepository;
		this.uniqueTestTakerRepository = uniqueTestTakerRepository;
		this.outcomeStatusRepository = outcomeStatusRepository;
		this.productIncidentMappingRepository = productIncidentMappingRepository;
		this.riCommonUtil = riCommonUtil;
	}

	@SneakyThrows
    @Transactional
    public void on(final PRCOutcomeGeneratedNodeV1 prcOutcomeGeneratedNodeV1) {
        log.debug("PrcOutcomeGeneratedDomainService| on | PRCOutcomeGeneratedNodeV1:{}", prcOutcomeGeneratedNodeV1);

        CheckOutcome checkOutcome = updatePrcOutcome(prcOutcomeGeneratedNodeV1);
        if(checkOutcome!=null) {
            IntegrityCheckInitiatedV1 integrityCheckInitiatedV1 = populateIntegrityCheckEvent(checkOutcome);
            buildHeader();

            publishEvent(integrityCheckInitiatedV1);
        }
    }

    private IntegrityCheckInitiatedV1 populateIntegrityCheckEvent(final CheckOutcome checkOutcome) {
        IntegrityCheckInitiatedV1 integrityCheckInitiatedV1=new IntegrityCheckInitiatedV1();
        integrityCheckInitiatedV1.setCheckOutcome(buildCheckOutcomeV1(checkOutcome));
        integrityCheckInitiatedV1.setBookingUuid((checkOutcome.getBookingUuid()));
        integrityCheckInitiatedV1.setBookingVersion(checkOutcome.getBookingVersion());
        return integrityCheckInitiatedV1;
    }

    private CheckOutcomeV1 buildCheckOutcomeV1(CheckOutcome checkOutcome) {
        CheckOutcomeV1 checkOutcomeV1 = new CheckOutcomeV1();
        checkOutcomeV1.setCheckOutcomeStatusUuid(
               checkOutcome.getCheckOutcomeStatus().getCheckOutcomeStatusUuid());
        checkOutcomeV1.setCheckOutcomeTypeUuid(
                checkOutcome.getCheckOutcomeType().getCheckOutcomeTypeUuid());
        return checkOutcomeV1;
    }

    public CheckOutcome updatePrcOutcome(PRCOutcomeGeneratedNodeV1 prcOutcomeGeneratedNodeV1) {
        log.info("PrcOutcomeGeneratedDomainService| updatePrcOutcome for uttid : {}",
            prcOutcomeGeneratedNodeV1.getUniqueTestTakerUuid());
        CheckOutcome checkOutcomeEntity = null;
        Optional<Booking> optionalBooking = bookingRepository
            .findById(prcOutcomeGeneratedNodeV1.getBookingUuid());
        if (!optionalBooking.isPresent()) {
            optionalBooking = Optional.of(Booking.builder()
                .bookingUuid(prcOutcomeGeneratedNodeV1.getBookingUuid())
                .uniqueTestTakerUuid(prcOutcomeGeneratedNodeV1.getUniqueTestTakerUuid())
                .build());
        }
        Optional<UniqueTestTaker> optionalUniqueTestTaker = uniqueTestTakerRepository
            .findByUniqueTestTakerUuid(optionalBooking.get().getUniqueTestTakerUuid());
        optionalBooking.get().setUniqueTestTaker(optionalUniqueTestTaker.orElse(null));

        CheckOutcome prcCheckOutcome=setCheckOutcome(prcOutcomeGeneratedNodeV1, optionalBooking.get());
        if(prcCheckOutcome!=null) {
            checkOutcomeEntity = checkOutcomeRepository
                    .save(prcCheckOutcome);
            Optional<OutcomeStatus> optionalOutcomeStatus = outcomeStatusRepository
                    .findByBookingUuid(optionalBooking.get().getBookingUuid());
            OutcomeStatus outcomeStatus = optionalOutcomeStatus.orElseGet(() -> OutcomeStatus.builder().build());
            outcomeStatus.setBookingVersion(prcCheckOutcome.getBookingVersion());
            outcomeStatusRepository.save(outcomeStatus);
        }
        return checkOutcomeEntity;
    }

    private Incident setIncident(PRCOutcomeGeneratedNodeV1 prcOutcomeGeneratedNodeV1, Booking booking,
        String incidentAnalysisType, CheckOutcome checkOutcome) {
        IncidentType incidentType = getIncidentType(incidentAnalysisType);
        Incident incident;
        AtomicReference<Optional<Incident>> optionalIncident = new AtomicReference<>(Optional.empty());
        List<Incident> optionalIncidentList = incidentRepository
            .findByBookingUuid(booking.getBookingUuid());
        optionalIncidentList.stream().forEach(incidentFetched -> {
            if (incidentFetched.getIncidentTypeByIncidentTypeUuid().getIncidentTypeCode()
                .equals(incidentAnalysisType)) {
                optionalIncident.set(Optional.of(incidentFetched));
            }
        });
        incident = optionalIncident.get().orElseGet(() -> {
            Incident incidentToCreate = Incident.builder()
                .incidentCategoryByIncidentCategoryUuid(
                    incidentType != null ? incidentType.getIncidentCategoryByIncidentCategoryUuid()
                        : null)
                .incidentTypeByIncidentTypeUuid(incidentType)
                .bookingUuid(booking.getBookingUuid())
                .checkOutcomeByCheckOutcomeUuid(checkOutcome)
                    .eventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime())
                .build();
            setIncidentStatusType(incidentToCreate, prcOutcomeGeneratedNodeV1, incidentAnalysisType);
            incidentToCreate.setIncidentEvidencesByIncidentUuid(
                getIncidenEveidencCollection(prcOutcomeGeneratedNodeV1, incidentAnalysisType, booking,
                    incidentToCreate));
            return incidentToCreate;
        });
        setIncidentStatusType(incident, prcOutcomeGeneratedNodeV1, incidentAnalysisType);
        incident.setIncidentTypeByIncidentTypeUuid(incidentType);
        incident.setIncidentCategoryByIncidentCategoryUuid(
            incidentType != null ? incidentType.getIncidentCategoryByIncidentCategoryUuid() : null);
        incident.setBookingUuid(booking.getBookingUuid());
        incident.setIncidentEvidencesByIncidentUuid(
            getIncidenEveidencCollection(prcOutcomeGeneratedNodeV1, incidentAnalysisType, booking,
                incident));
        incident.setEventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime());

        return incident;
    }

    private CheckOutcome setCheckOutcome(PRCOutcomeGeneratedNodeV1 prcOutcomeGeneratedNodeV1,
        Booking booking) {
        log.info("PrcOutcomeGeneratedDomainService| CheckOutcome enter unti");
        CheckOutcome checkOutcome;
        CheckOutcomeType checkOutcomeType = getCheckOutComeType();
        Optional<CheckOutcome> optionalCheckOutcome = checkOutcomeRepository
            .findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(booking.getBookingUuid(),
                    Optional.ofNullable(checkOutcomeType).map(CheckOutcomeType::getCheckOutcomeTypeUuid).orElse(null));
        if(prcOutcomeGeneratedNodeV1.getUniqueTestTakerUuid().equals(booking.getUniqueTestTakerUuid())) {
            checkOutcome = optionalCheckOutcome.orElseGet(() -> {
                CheckOutcome checkOutcomeToCreate = CheckOutcome.builder()
                        .checkOutcomeStatus(
                                setCheckOutComeStatus(prcOutcomeGeneratedNodeV1))
                        .checkOutcomeType(getCheckOutComeType())
                        .bookingUuid(booking.getBookingUuid())
                        .bookingVersion(booking.getBookingVersion())
                        .eventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime())
                        .build();
                checkOutcomeToCreate.setIncidentsByCheckOutcomeUuid(
                        getIncidentCollection(prcOutcomeGeneratedNodeV1, booking, checkOutcomeToCreate));
                return checkOutcomeToCreate;
            });
            if (optionalCheckOutcome.isPresent()) {
                checkOutcome.setCheckOutcomeStatus(
                        setCheckOutComeStatus(prcOutcomeGeneratedNodeV1));
                checkOutcome.setCheckOutcomeType(getCheckOutComeType());
                checkOutcome.setBookingUuid(booking.getBookingUuid());
                checkOutcome.setIncidentsByCheckOutcomeUuid(
                        getIncidentCollection(prcOutcomeGeneratedNodeV1, booking, checkOutcome));
                checkOutcome.setBookingVersion(booking.getBookingVersion());
                checkOutcome.setEventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime());
            }
            return checkOutcome;
        }else {
            log.error("UUTID is not same");
        }
        return null;
    }

    private List<Incident> getIncidentCollection(PRCOutcomeGeneratedNodeV1 prcOutcomeGeneratedNodeV1,
        Booking booking, CheckOutcome checkOutcome) {
        List<Incident> incidentArrayList = new ArrayList<>();
        if (prcOutcomeGeneratedNodeV1.getProbabilityAnalysis() != null) {
            String incidentAnalysisType = RIConstants.PrcOutcomeConstant.INCIDENT_TYPE_CODE_PROBABILITY;
            incidentArrayList
                .add(setIncident(prcOutcomeGeneratedNodeV1, booking, incidentAnalysisType, checkOutcome));
        }
        if (prcOutcomeGeneratedNodeV1.getRepeaterAnalysis() != null) {
            String incidentAnalysisType = RIConstants.PrcOutcomeConstant.INCIDENT_TYPE_CODE_REPEATER;
            incidentArrayList
                .add(setIncident(prcOutcomeGeneratedNodeV1, booking, incidentAnalysisType, checkOutcome));
        }
        return incidentArrayList;
    }

    private List<IncidentEvidence> getIncidenEveidencCollection(
        PRCOutcomeGeneratedNodeV1 prcOutcomeGeneratedNodeV1, String incidentAnalysisType,
        Booking booking, Incident incident) {
        List<IncidentEvidence> incidentEvidenceList = new ArrayList<>();
        incidentEvidenceList.add(
            setIncidentEvidence(prcOutcomeGeneratedNodeV1, incidentAnalysisType, booking, incident));
        return incidentEvidenceList;
    }

    private IncidentEvidence setIncidentEvidence(PRCOutcomeGeneratedNodeV1 prcOutcomeGeneratedNodeV1,
        String incidentAnalysisType, Booking booking, Incident incident) {
        IncidentEvidence incidentEvidenceToCreate = IncidentEvidence.builder()
            .incidentByIncidentUuid(incident)
            .build();
        incidentEvidenceToCreate.setPrcOutcomeDetailsByIncidentEvidenceUuid(
            getPrcOutcomeDetailsCollection(prcOutcomeGeneratedNodeV1, incidentAnalysisType, booking,
                incidentEvidenceToCreate));
        return incidentEvidenceToCreate;
    }

    private List<PrcOutcomeDetails> getPrcOutcomeDetailsCollection(
        PRCOutcomeGeneratedNodeV1 prcOutcomeGeneratedNodeV1, String incidentAnalysisType,
        Booking booking, IncidentEvidence incidentEvidence) {
        List<PrcOutcomeDetails> prcOutcomeDetailsList = new ArrayList<>();
        prcOutcomeDetailsList.add(
            setPrcOutcomeDetails(prcOutcomeGeneratedNodeV1, incidentAnalysisType, booking,
                incidentEvidence));
        return prcOutcomeDetailsList;
    }

    private PrcOutcomeDetails setPrcOutcomeDetails(
        PRCOutcomeGeneratedNodeV1 prcOutcomeGeneratedNodeV1, String incidentAnalysisType,
        Booking booking, IncidentEvidence incidentEvidence) {
        PrcOutcomeDetails prcOutcomeDetails;
        AtomicReference<Optional<PrcOutcomeDetails>> optionalPrcOutcomeDetails = new AtomicReference<>(
            Optional.empty());
        List<PrcOutcomeDetails> optionalPrcOutcomeDetailsList = prcOutcomeDetailsRepository
            .findByBookingUuid(booking.getBookingUuid());
        optionalPrcOutcomeDetailsList.stream().forEach(prcOutcomeDetalisFromDb -> {
            if (incidentAnalysisType.equals(
                prcOutcomeDetalisFromDb.getIncidentEvidenceByIncidentEvidenceUuid()
                    .getIncidentByIncidentUuid().getIncidentTypeByIncidentTypeUuid()
                    .getIncidentTypeCode())) {
                optionalPrcOutcomeDetails.set(Optional.of(prcOutcomeDetalisFromDb));
            }
        });
        prcOutcomeDetails = optionalPrcOutcomeDetails.get().orElseGet(() -> {
            PrcOutcomeDetails prcOutcomeDetailsToCreate = PrcOutcomeDetails.builder()
                .bookingUuid(booking.getBookingUuid())
                .incidentEvidenceByIncidentEvidenceUuid(incidentEvidence)
                .uniqueTestTakerByUniqueTestTakerUuid(booking.getUniqueTestTaker()).build();

            if (incidentAnalysisType
                .equals(RIConstants.PrcOutcomeConstant.INCIDENT_TYPE_CODE_PROBABILITY)) {
                prcOutcomeDetailsToCreate.setPrcProbabilityAnalysesByPrcOutcomeDetailsUuid(
                    setPrcProbabilityAnalysisCollection(prcOutcomeGeneratedNodeV1.getProbabilityAnalysis(),
                        prcOutcomeDetailsToCreate));
            } else {
                prcOutcomeDetailsToCreate.setPrcRepeaterAnalysesByPrcOutcomeDetailsUuid(
                    setPrcRepeaterAnalysis(prcOutcomeGeneratedNodeV1.getRepeaterAnalysis(),
                        prcOutcomeDetailsToCreate));
            }

            return prcOutcomeDetailsToCreate;
        });
        if (optionalPrcOutcomeDetails.get().isPresent()) {
            prcOutcomeDetails.setBookingUuid(booking.getBookingUuid());
            prcOutcomeDetails.setUniqueTestTakerByUniqueTestTakerUuid(booking.getUniqueTestTaker());

            if (incidentAnalysisType
                .equals(RIConstants.PrcOutcomeConstant.INCIDENT_TYPE_CODE_PROBABILITY)) {
                prcOutcomeDetails.setPrcProbabilityAnalysesByPrcOutcomeDetailsUuid(
                    setPrcProbabilityAnalysisCollection(prcOutcomeGeneratedNodeV1.getProbabilityAnalysis(),
                        prcOutcomeDetails));
            } else {
                prcOutcomeDetails.setPrcRepeaterAnalysesByPrcOutcomeDetailsUuid(
                    setPrcRepeaterAnalysis(prcOutcomeGeneratedNodeV1.getRepeaterAnalysis(),
                        prcOutcomeDetails));
            }
        }
        return prcOutcomeDetails;
    }

    private List<PrcRepeaterAnalysis> setPrcRepeaterAnalysis(
        PRCRecommendationNodeV1RepeaterAnalysis repeaterAnalysis,
        PrcOutcomeDetails prcOutcomeDetails) {
        List<PrcRepeaterAnalysis> prcRepeaterAnalysisList = new ArrayList<>();
        PrcRepeaterAnalysis prcRepeaterAnalysis = PrcRepeaterAnalysis.builder()
            .lBandScoreJump(repeaterAnalysis.getListeningBandscoreJump())
            .rBandScoreJump(repeaterAnalysis.getReadingBandscoreJump())
            .wBandScoreJump(repeaterAnalysis.getWritingBandscoreJump())
            .sBandScoreJump(repeaterAnalysis.getSpeakingBandscoreJump())
            .overallBandScoreJump(repeaterAnalysis.getOverallBandscoreJump())
            .weight(repeaterAnalysis.getWeight())
            .prcOutcomeDetailsByPrcOutcomeDetailsUuid(prcOutcomeDetails)
            .build();

        prcRepeaterAnalysis.setPrcRepeaterFlagsByPrcRepeaterAnalysisUuid(
            setPrcRepeaterFlagCollection(repeaterAnalysis, prcRepeaterAnalysis));

        prcRepeaterAnalysisList.add(prcRepeaterAnalysis);
        return prcRepeaterAnalysisList;
    }

    private List<PrcRepeaterFlag> setPrcRepeaterFlagCollection(
        PRCRecommendationNodeV1RepeaterAnalysis repeaterAnalysis,
        PrcRepeaterAnalysis prcRepeaterAnalysis) {
        List<PrcRepeaterFlag> prcRepeaterFlagList = new ArrayList<>();
        repeaterAnalysis.getFlaggedFor().forEach(flagged -> {
            PrcRepeaterFlag prcRepeaterFlag = PrcRepeaterFlag.builder()
                .flaggedFor(flagged)
                .prcRepeaterAnalysisByPrcRepeaterAnalysisUuid(prcRepeaterAnalysis)
                .build();
            prcRepeaterFlagList.add(prcRepeaterFlag);
        });
        return prcRepeaterFlagList;
    }

    private List<PrcProbabilityAnalysis> setPrcProbabilityAnalysisCollection(
        PRCRecommendationNodeV1ProbabilityAnalysis probabilityAnalysis,
        PrcOutcomeDetails prcOutcomeDetails) {
        List<PrcProbabilityAnalysis> prcProbabilityAnalysisList = new ArrayList<>();
        PrcProbabilityAnalysis prcProbabilityAnalysis = PrcProbabilityAnalysis.builder()
            .lBandScoreCountryReg(probabilityAnalysis.getListeningBandscoreCountryReg())
            .lBandScoreRes(probabilityAnalysis.getListeningBandscoreResidual())
            .lBandScoreStdRes(probabilityAnalysis.getListeningBandscoreStdResidual())
            .rBandScoreCountryReg(probabilityAnalysis.getReadingBandscoreCountryReg())
            .rBandScoreFlag(probabilityAnalysis.getReadingBandscoreFlag())
            .lBandScoreFlag(probabilityAnalysis.getListeningBandscoreFlag())
            .rBandScoreRes(probabilityAnalysis.getReadingBandscoreResidual())
            .rBandScoreStdRes(probabilityAnalysis.getReadingBandscoreStdResidual())
            .meanJudgemental(probabilityAnalysis.getCandidateMeanJudgmental())
            .prcOutcomeDetailsByPrcOutcomeDetailsUuid(prcOutcomeDetails).build();
        prcProbabilityAnalysisList.add(prcProbabilityAnalysis);

        return prcProbabilityAnalysisList;
    }

    private IncidentType getIncidentType(String incidentTypeCode) {
        IncidentType incidentType = null;
        Optional<IncidentType> optionalIncidentType = incidentTypeRepository
            .findByIncidentTypeCode(incidentTypeCode);
        if (optionalIncidentType.isPresent()) {
            incidentType = optionalIncidentType.get();
        }
        return incidentType;
    }

    private void setIncidentStatusType(Incident incident,
        PRCOutcomeGeneratedNodeV1 prcOutcomeGeneratedNodeV1, String incidentAnalysisType) {
        String incidentTypeCode = null;
        if (incidentAnalysisType
            .equals(RIConstants.PrcOutcomeConstant.INCIDENT_TYPE_CODE_PROBABILITY)) {
            if (prcOutcomeGeneratedNodeV1.getProbabilityAnalysis() != null && prcOutcomeGeneratedNodeV1
                .getProbabilityAnalysis().isGlobalFlag()) {
                Booking booking = riCommonUtil.getBooking(incident);
                ProductIncidentMapping productIncidentMapping = productIncidentMappingRepository
                    .findByProductUuidAndIncidentCategoryUuid
                        (booking.getProductUuid(),
                            incident.getIncidentCategoryByIncidentCategoryUuid()
                                .getIncidentCategoryUuid());
                incidentTypeCode = productIncidentMapping.getIncidentStatusTypeCode();
            } else {
                incidentTypeCode = RIConstants.PrcOutcomeConstant.INCIDENT_STATUS_TYPE_CODE_PASSED;
            }
        }
        if (incidentAnalysisType.equals(RIConstants.PrcOutcomeConstant.INCIDENT_TYPE_CODE_REPEATER)) {
            if (prcOutcomeGeneratedNodeV1.getRepeaterAnalysis() != null && !CollectionUtils
                .isEmpty(prcOutcomeGeneratedNodeV1.getRepeaterAnalysis().getFlaggedFor())) {
                Booking booking = riCommonUtil.getBooking(incident);
                ProductIncidentMapping productIncidentMapping = productIncidentMappingRepository
                    .findByProductUuidAndIncidentCategoryUuid
                        (booking.getProductUuid(),
                            incident.getIncidentCategoryByIncidentCategoryUuid()
                                .getIncidentCategoryUuid());
                incidentTypeCode = productIncidentMapping.getIncidentStatusTypeCode();
            } else {
                incidentTypeCode = RIConstants.PrcOutcomeConstant.INCIDENT_STATUS_TYPE_CODE_PASSED;
            }
        }
        Optional<IncidentStatusType> optionalIncidentStatusType = incidentStatusTypeRepository
            .findByIncidentStatusTypeCode(incidentTypeCode);

        if (optionalIncidentStatusType.isPresent()) {
            incident.setIncidentStatusTypeByIncidentStatusTypeUuid(optionalIncidentStatusType.get());
        } else {
            incident.setIncidentTypeByIncidentTypeUuid(null);
        }
    }

    private CheckOutcomeStatus setCheckOutComeStatus(
        PRCOutcomeGeneratedNodeV1 prcOutcomeGeneratedNodeV1) {
        String checkOutcomeStatusCode;
        CheckOutcomeStatus checkOutcomeStatus = null;
        if ((prcOutcomeGeneratedNodeV1.getProbabilityAnalysis() != null && prcOutcomeGeneratedNodeV1
            .getProbabilityAnalysis().isGlobalFlag())
            || (prcOutcomeGeneratedNodeV1.getRepeaterAnalysis() != null && !CollectionUtils
            .isEmpty(prcOutcomeGeneratedNodeV1.getRepeaterAnalysis().getFlaggedFor()))) {
            checkOutcomeStatusCode = RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_REVIEW;
        } else {
            checkOutcomeStatusCode = RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_PASSED;
        }
        Optional<CheckOutcomeStatus> optionalCheckOutcomeStatus = checkOutcomeStatusRepository
            .findByCheckOutcomeStatusCode(checkOutcomeStatusCode);
        if (optionalCheckOutcomeStatus.isPresent()) {
            checkOutcomeStatus = optionalCheckOutcomeStatus.get();
        }
        return checkOutcomeStatus;
    }

    private CheckOutcomeType getCheckOutComeType() {
        String checkOutcomeTypeCode;
        CheckOutcomeType checkOutcomeType = null;
        checkOutcomeTypeCode = RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_TYPE_CODE;

        Optional<CheckOutcomeType> optionalCheckOutcomeStatus = checkOutcomeTypeRepository
            .findByCheckOutcomeTypeCode(checkOutcomeTypeCode);
        if (optionalCheckOutcomeStatus.isPresent()) {
            checkOutcomeType = optionalCheckOutcomeStatus.get();
        }
        return checkOutcomeType;
    }

    private void buildHeader() {
    	CMDSHeaderContext eventHeader = new CMDSHeaderContext();
        eventHeader.setCorrelationId(ThreadLocalHeaderContext.getContext().getCorrelationId());
        eventHeader.setEventDateTime(LocalDateTime.now(ZoneOffset.UTC));
        eventHeader.setTransactionId(ThreadLocalHeaderContext.getContext().getTransactionId());
        eventHeader.setPartnerCode(ThreadLocalHeaderContext.getContext().getPartnerCode());
        eventHeader.setEventName(RIConstants.EventType.INTEGRITY_CHECK_INITIATED);
        ThreadLocalHeaderContext.clearContext();
        ThreadLocalHeaderContext.setContext(eventHeader);
    }
}

