package com.ielts.cmds.ri.infrastructure.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.ielts.cmds.ri.infrastructure.entity.BookingLineOutcomeView;

@Repository
public interface BookingLineOutcomeViewRepository extends
    JpaSpecificationExecutor<BookingLineOutcomeView>,
    JpaRepository<BookingLineOutcomeView, UUID> {

}
