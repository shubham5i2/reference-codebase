package com.ielts.cmds.ri.application.exception;

public class ResultIntegrityException extends RuntimeException {

    private static final long serialVersionUID = 5739366016725073156L;
    public ResultIntegrityException(String message) {
        super(message);
    }
}