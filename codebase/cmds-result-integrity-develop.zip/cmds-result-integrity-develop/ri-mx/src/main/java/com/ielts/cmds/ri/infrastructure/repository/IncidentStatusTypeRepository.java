package com.ielts.cmds.ri.infrastructure.repository;

import com.ielts.cmds.ri.infrastructure.entity.IncidentStatusType;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
@Cacheable("incidentStatusTypes")
public interface IncidentStatusTypeRepository extends JpaRepository<IncidentStatusType, UUID> {
    Optional<IncidentStatusType> findByIncidentStatusTypeCode(String incidentStatusType);
}
