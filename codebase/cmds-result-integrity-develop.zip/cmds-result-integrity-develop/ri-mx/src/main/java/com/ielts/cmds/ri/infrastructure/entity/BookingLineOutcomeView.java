package com.ielts.cmds.ri.infrastructure.entity;

import java.math.BigDecimal;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "booking_line_outcome_view")
public class BookingLineOutcomeView {

  @Id
  @Column(name = "id")
  @org.hibernate.annotations.Type(type = "pg-uuid")
  private UUID id;

  @Column(name = "booking_uuid")
  private UUID bookingUuid;

  @Column(name = "check_outcome_received")
  private String checkOutcomeReceived;

  @Column(name="booking_version")
  private BigDecimal bookingVersion;


  public UUID getId() {
    return id;
  }

  public BigDecimal getBookingVersion() {
    return bookingVersion;
  }

  public void setBookingVersion(BigDecimal bookingVersion) {
    this.bookingVersion = bookingVersion;
  }

  public void setId(UUID id) {
    this.id = id;
  }

  public UUID getBookingUuid() {
    return bookingUuid;
  }

  public void setBookingUuid(UUID bookingUuid) {
    this.bookingUuid = bookingUuid;
  }


  public String getCheckOutcomeReceived() {
    return checkOutcomeReceived;
  }

  public void setCheckOutcomeReceived(String checkOutcomeReceived) {
    this.checkOutcomeReceived = checkOutcomeReceived;
  }
}
