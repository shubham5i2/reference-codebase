package com.ielts.cmds.ri.infrastructure.exception;

public class RIEventProcessingException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public RIEventProcessingException(final String message) {
    super(message);
  }
}

