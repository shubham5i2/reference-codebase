package com.ielts.cmds.ri.application.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ielts.cmds.api.evt_019.BookingChangedEventV1;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.domain.service.BookingCancelledDomainService;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.service.IApplicationServiceV2;
import com.ielts.cmds.serialization.utils.ServiceIdentifier;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

/**
 * The type Booking Cancelled service.
 */
@Service
@ServiceIdentifier(RIConstants.EventType.BOOKING_CANCELLED_EVENT)
@Slf4j
public class BookingCancelledService implements IApplicationServiceV2<BookingChangedEventV1> {

    @Autowired
    BookingCancelledDomainService bookingCancelledDomainService;

    @SneakyThrows
    @Override
    public void process(BookingChangedEventV1 bookingChangedEventV1) {
        try {
            log.debug(
                    "Booking Cancelled Service process started for request with CorrelationId:{}",
                    ThreadLocalHeaderContext.getContext().getCorrelationId());
            if (bookingChangedEventV1 == null) {
                throw new IllegalArgumentException("Payload is Empty");
            }
            bookingCancelledDomainService.on(bookingChangedEventV1.getBookingDetails());
        } catch (IllegalArgumentException e) {
            log.error("Failed to process Booking event due to ", e);
            throw new ProcessingException(e.getMessage(), e);
        }

    }
}

