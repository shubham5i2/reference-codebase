package com.ielts.cmds.ri.infrastructure.entity;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Table(name = "outcome_status_type")
@NoArgsConstructor
@AllArgsConstructor
public class OutcomeStatusType {
	@Id
    @Column(name = "outcome_status_type_uuid")
    private UUID outcomeStatusTypeUuid;

    @Column(name = "outcome_status_type")
    private String type;

    @Column(name = "outcome_status_type_code")
    private String outcomeStatusTypeCode;

    @Column(name = "effective_from_date")
    private LocalDate effectiveFromDate;

    @Column(name = "effective_to_date")
    private LocalDate effectiveToDate;
    
    @Column(name = "created_datetime")
    private OffsetDateTime createdDatetime;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;

    @Column(name = "updated_by")
    private String updatedBy;

    @Version
    @Column(name = "concurrency_version")
    private Integer concurrencyVersion;

}
