package com.ielts.cmds.ri.domain.service;

import static com.ielts.cmds.ri.utils.RIConstants.PermissionId.RI_ID_CHECK_UPDATE;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.LRW_ID_INC_CHK;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import javax.validation.ConstraintViolation;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.evt119.CheckOutcomeV1;
import com.ielts.cmds.api.evt119.IntegrityCheckInitiatedV1;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.context.CMDSErrorContext;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalErrorContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.application.exception.ResultIntegrityValidationException;
import com.ielts.cmds.ri.common.model.out.IdCheckOutcomeReceivedDetailsV1;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeType;
import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatus;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.ri.utils.RIConstants.ErrorCodes;
import com.ielts.cmds.ri.utils.RIConstants.EventType;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;
import com.ielts.cmds.serialization.domain.EnableOutboundEventV2;

import lombok.extern.slf4j.Slf4j;

/**
 * The type Id check outcome received domain service.
 */
@Slf4j
@Service
@EnableOutboundEventV2
public class IdCheckOutcomeReceivedDomainService extends AbstractCMDSDomainService<Object> {

	private final CheckOutcomeRepository checkOutcomeRepository;

	private final CMDSErrorResolver<Object> errorResolver;

	private final RICommonUtil commonUtils;

	private final CheckOutcomeTypeRepository checkOutcomeTypeRepository;

	private final CheckOutcomeStatusRepository checkOutcomeStatusRepository;

	private final OutcomeStatusRepository outcomeStatusRepository;

	@Autowired
	public IdCheckOutcomeReceivedDomainService(ApplicationEventPublisher publisher,
			ObjectMapper objectMapper,
			@Value("${idCheckOutcomeReceived.v2}") String isV2Enabled,
			CMDSThreadLocalContextService cmdsThreadLocalContextService,
			CheckOutcomeRepository checkOutcomeRepository,
			CMDSErrorResolver<Object> errorResolver,
			RICommonUtil commonUtils,
			CheckOutcomeTypeRepository checkOutcomeTypeRepository,
			CheckOutcomeStatusRepository checkOutcomeStatusRepository,
			OutcomeStatusRepository outcomeStatusRepository) {
		super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
		this.checkOutcomeRepository = checkOutcomeRepository;
		this.errorResolver = errorResolver;
		this.commonUtils = commonUtils;
		this.checkOutcomeTypeRepository = checkOutcomeTypeRepository;
		this.checkOutcomeStatusRepository = checkOutcomeStatusRepository;
		this.outcomeStatusRepository = outcomeStatusRepository;
	}

	/**
	 * On.
	 *
	 * @throws RbacValidationException the rbac validation exception
	 * @throws JsonProcessingException the json processing exception
	 * @throws ResultIntegrityValidationException
	 */
	@Transactional(noRollbackFor = RuntimeException.class)
	public void on(final IdCheckOutcomeReceivedDetailsV1 idCheckOutcomeReceivedDetails)
			throws RbacValidationException, JsonProcessingException, ResultIntegrityValidationException {

		log.debug("IdCheckOutcomeReceivedDomainService.on : {}", idCheckOutcomeReceivedDetails.getBookingUuid());
		try {
			CMDSHeaderContext initHeader = ThreadLocalHeaderContext.getContext();
			// check if role has permission to access
			if (!commonUtils.hasAllAccess(
					ThreadLocalHeaderContext.getContext().getXaccessToken(),
					RI_ID_CHECK_UPDATE)) {
				log.info(
						"You do not have permission to update ID verification status. Please contact your administrator if you do not think this correct.");
				Set<ConstraintViolation<Object>> violations =
						RICommonUtil.getSetforNullViolationOfEventBody(
								ErrorCodes.UNAUTHORISED_TO_UPDATE_ID_VERIFICATION_STATUS,
								"unauthorisedToUpdateIDVerificationStatus");

				publishEventAfterUpdatingCheckOutcomeStatus(null, violations, initHeader);
			} else {
				CheckOutcomeType checkOutcomeType = getIdCheckOutComeType();
				CheckOutcomeStatus checkOutcomeStatus = getCheckOutComeStatus(UUID.fromString(
						idCheckOutcomeReceivedDetails.getCheckOutcomeStatusUuid()));
				CheckOutcome checkOutcome = getCheckOutcome(
						UUID.fromString(idCheckOutcomeReceivedDetails.getBookingUuid()),
						checkOutcomeType);


				log.info("CheckOutcome is not present for Booking: {} So inserting data",
						idCheckOutcomeReceivedDetails.getBookingUuid());

				CheckOutcome savedCheckOutcome = updateCheckOutcome(checkOutcome,
						idCheckOutcomeReceivedDetails,
						checkOutcomeType,
						checkOutcomeStatus);
				Optional<OutcomeStatus> optionalOutcomeStatus = outcomeStatusRepository
						.findByBookingUuid(UUID.fromString(idCheckOutcomeReceivedDetails.getBookingUuid()));
				OutcomeStatus outcomeStatus = optionalOutcomeStatus.orElseGet(() -> OutcomeStatus.builder().build());
				outcomeStatus.setCheckOutcomeEventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime());
				outcomeStatusRepository.save(outcomeStatus);
				publishIntegrityCheckInitiatedEvent(idCheckOutcomeReceivedDetails, savedCheckOutcome);

				publishEventAfterUpdatingCheckOutcomeStatus("Success", null, initHeader);
			}

		} catch(ResultIntegrityValidationException | ResultIntegrityException e) {
			log.error("Exception raised", e);
			throw new ResultIntegrityException(
					"CheckOutcome type not found for LRWId check");
		}

	}

	private void publishIntegrityCheckInitiatedEvent(
			final IdCheckOutcomeReceivedDetailsV1 idCheckOutcomeReceivedDetails,
			final CheckOutcome checkOutcome) {
		buildHeader();
		IntegrityCheckInitiatedV1 integrityCheckInitiatedV1 = populateIntegrityCheckEvent(idCheckOutcomeReceivedDetails, checkOutcome);
		commonUtils.publishLog();
		publishEvent(integrityCheckInitiatedV1);
	}

	private void buildHeader() {
		CMDSHeaderContext eventHeader = ThreadLocalHeaderContext.getContext();
		eventHeader.setEventDateTime(LocalDateTime.now(ZoneOffset.UTC));
		eventHeader.setEventName(EventType.INTEGRITY_CHECK_INITIATED);
		ThreadLocalHeaderContext.clearContext();
		ThreadLocalHeaderContext.setContext(eventHeader);
	}

	private IntegrityCheckInitiatedV1 populateIntegrityCheckEvent(final IdCheckOutcomeReceivedDetailsV1 idCheckOutcomeReceivedDetailsV1,
			final CheckOutcome checkOutcome) {

		IntegrityCheckInitiatedV1 integrityCheckInitiatedV1=new IntegrityCheckInitiatedV1();
		integrityCheckInitiatedV1.bookingUuid(UUID.fromString(idCheckOutcomeReceivedDetailsV1.getBookingUuid()));
		integrityCheckInitiatedV1.checkOutcome(mapCheckOutcomeToCheckOutcomeV1(checkOutcome));

		return integrityCheckInitiatedV1;
	}

	private CheckOutcomeV1 mapCheckOutcomeToCheckOutcomeV1(final CheckOutcome checkOutcome) {

		CheckOutcomeV1 checkOutcomeV1 = new CheckOutcomeV1();

		if (Objects.nonNull(checkOutcome)) {
			checkOutcomeV1.setCheckOutcomeTypeUuid(
					checkOutcome.getCheckOutcomeType().getCheckOutcomeTypeUuid());
			checkOutcomeV1.setCheckOutcomeStatusUuid(
					checkOutcome.getCheckOutcomeStatus().getCheckOutcomeStatusUuid());
		}
		return checkOutcomeV1;
	}

	/**
	 * Publish event after updating check outcome status.
	 *
	 * @param eventBody                     the event body
	 * @param violations                    the violations
	 */
	public void publishEventAfterUpdatingCheckOutcomeStatus(final String eventBody,
			final Set<ConstraintViolation<Object>> violations,
			CMDSHeaderContext initHeader) {

		log.info("publishing event {}", ThreadLocalHeaderContext.getContext().getEventName());
		ThreadLocalHeaderContext.setContext(initHeader);
		if (CollectionUtils.isNotEmpty(violations)) {
			CMDSErrorResponse eventErrors =
					errorResolver.populatErrorResponse(
							violations, ThreadLocalHeaderContext.getContext().getEventName());
			ThreadLocalErrorContext.setContext(new CMDSErrorContext(eventErrors.getErrorList()));
			commonUtils.publishLog();
			publishEvent(eventBody,ThreadLocalErrorContext.getContext().getErrorList());
		} else {
			commonUtils.publishLog();
			publishEvent(eventBody);
		}

	}

	/**
	 * Gets check out come type.
	 *
	 * @return the check out come type
	 */
	public CheckOutcomeType getIdCheckOutComeType() {
		return checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(LRW_ID_INC_CHK).
				orElseThrow(()->new ResultIntegrityValidationException("Checkoutcome type code not found"));
	}

	/**
	 * Gets check outcome.
	 *
	 * @param bookingUuid      the booking uuid
	 * @param checkOutcomeType the check outcome type
	 * @return the check outcome
	 */
	public CheckOutcome getCheckOutcome(UUID bookingUuid,
			CheckOutcomeType checkOutcomeType) {

		return checkOutcomeRepository
				.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(bookingUuid, checkOutcomeType.getCheckOutcomeTypeUuid())
				.orElse(new CheckOutcome());
	}

	/**
	 * Insert check outcome check outcome.
	 *
	 * @param idCheckOutcomeReceivedDetailsV1 the id check outcome received details v 1
	 * @param checkOutcomeType                the check outcome type
	 * @param checkOutcomeStatus
	 * @return the check outcome
	 */
	CheckOutcome updateCheckOutcome(CheckOutcome checkOutcome, IdCheckOutcomeReceivedDetailsV1 idCheckOutcomeReceivedDetailsV1,
			CheckOutcomeType checkOutcomeType, CheckOutcomeStatus checkOutcomeStatus) {
		checkOutcome.setBookingUuid(UUID.fromString(idCheckOutcomeReceivedDetailsV1.getBookingUuid()));
		checkOutcome.setCheckOutcomeType(checkOutcomeType);
		checkOutcome.setCheckOutcomeStatus(checkOutcomeStatus);
		checkOutcome.setEventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime());
		return checkOutcomeRepository.save(checkOutcome);
	}

	/**
	 * Gets check out come status.
	 *
	 * @param statusTypeUuid the status type uuid
	 * @return the check out come status
	 */
	public CheckOutcomeStatus getCheckOutComeStatus(UUID statusTypeUuid) {
		CheckOutcomeStatus checkOutcomeStatus;
		Optional<CheckOutcomeStatus> optionalCheckOutcomeStatus =
				checkOutcomeStatusRepository.findByCheckOutcomeStatusUuid(statusTypeUuid);
		if (optionalCheckOutcomeStatus.isPresent()) {
			checkOutcomeStatus = optionalCheckOutcomeStatus.get();
		} else {
			throw new ResultIntegrityException(
					"checkOutcome Status not found for uuid:" + statusTypeUuid);
		}
		return checkOutcomeStatus;
	}
}
