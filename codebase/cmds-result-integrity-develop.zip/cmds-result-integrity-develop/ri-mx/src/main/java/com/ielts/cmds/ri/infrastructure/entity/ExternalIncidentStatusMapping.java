package com.ielts.cmds.ri.infrastructure.entity;

import com.ielts.cmds.ri.domain.enums.ExternalIncidentStatusEnum;
import com.ielts.cmds.ri.domain.enums.IncidentSeverityEnum;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.UUID;

@Data
@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "external_incident_status_mapping")
public class ExternalIncidentStatusMapping {

	@Id
	@Column(name = "external_incident_status_mapping_uuid")
	private UUID externalIncidentStatusMappingUuid;


	@Column(name = "product_uuid")
	private UUID productUuid;


	@Column(name = "incident_category_uuid")
	private UUID incidentCategoryUuid;

	@Enumerated(EnumType.STRING)
	@Column(name = "incident_severity")
	private IncidentSeverityEnum incidentSeverity;

	@Enumerated(EnumType.STRING)
	@Column(name = "external_incident_status")
	private ExternalIncidentStatusEnum externalIncidentStatus;


	@Column(name = "incident_status_type_code")
	private String incidentStatusTypeCode;
}
