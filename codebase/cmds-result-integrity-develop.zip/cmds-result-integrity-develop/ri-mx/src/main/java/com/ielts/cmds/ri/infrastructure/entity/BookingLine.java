package com.ielts.cmds.ri.infrastructure.entity;

import java.time.OffsetDateTime;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.ielts.cmds.ri.domain.enums.BookingLineStatusEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(callSuper = true, exclude = {"booking"})
@Table(name = "booking_line")
public class BookingLine extends CommonModel {

    @Id
    @Column(name = "booking_line_uuid")
    private UUID bookingLineUuid;

    @Column(name = "product_uuid")
    private UUID productUuid;

    @Column(name = "location_uuid")
    private UUID locationUuid;

    @ManyToOne
    @JoinColumn(name = "booking_uuid")
    private Booking booking;

    @Column(name = "external_booking_line_uuid")
    private UUID externalBookingLineUuid;

    @Column(name = "start_datetime")
    private OffsetDateTime startDatetime;

    @Column(name = "end_datetime")
    private OffsetDateTime endDatetime;

    @Enumerated(EnumType.STRING)
    @Column(name = "booking_line_status")
    private BookingLineStatusEnum bookingLineStatus;

}