package com.ielts.cmds.ri.utils;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.encoder.org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;


@Slf4j
@Component
public class FileStorageHelper {

  @Autowired
  AmazonS3 s3Client;

  public void uploadFileToS3FromPresignedUrl(
      final String presignedURL, final String objectKey, final String bucketName)
      throws IOException {

    InputStream inputStream = null;

    try {
      final URL url = getPresignedUrl(presignedURL);
      final HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
      inputStream = httpURLConnection.getInputStream();
      final ObjectMetadata objectMetadata = getObjectMetadataInstance();
      objectMetadata.setContentLength(httpURLConnection.getContentLengthLong());
      uploadFileToS3(objectMetadata, inputStream, objectKey, bucketName);

    } catch (IOException ioException) {
      log.error("IOException occurred while contacting server for file.: {}", ioException);
      throw ioException;
    } finally {
      if (inputStream != null) {
        inputStream.close();
      }
    }
  }
  public URL getPresignedUrl(final String presignedURL) throws IOException {
    return new URL(presignedURL);
  }

  public ObjectMetadata getObjectMetadataInstance() {
    return new ObjectMetadata();
  }

  public void uploadFileToS3(
      final ObjectMetadata metadata,
      final InputStream inputStream,
      final String objectKey,
      final String bucketName)
      throws IOException {

    if (s3Client.doesBucketExistV2(bucketName)) {
      log.debug(String.format("Bucket exists in S3 bucket: %s", bucketName));

      String contentType = generateContentType((extractFileExtension(objectKey)));
      log.info(String.format("assigned Content-Type: %s", contentType));

      metadata.setContentType(contentType);
      s3Client.putObject(bucketName, objectKey, inputStream, metadata);

      log.info("File uploaded successfully");
    } else {
      log.warn(String.format("Bucket does not exists in S3 bucket: %s", bucketName));
      throw new ResultIntegrityException(
          String.format("Bucket does not exists in S3 bucket: %s", bucketName));
    }
  }

  public String extractFileExtension(String fileName) {
    log.info("extracting FileExtension");
    if(!StringUtils.isBlank(fileName)){
      String []arr = fileName.split("/");
      if(arr.length > 1){
        return StringUtils.substringAfter(arr[arr.length - 1], ".");
      }
      else{
        log.info(String
            .format("file name does not contain proper pattern of objectKey: %s", fileName));
        return "";
      }
    }
    log.info(String.format("file name is empty: %s", fileName));
    return "";
  }

  public String generateContentType(String fileType){
    log.info(String.format("assigning content-type to: %s", fileType));
    switch (fileType.toLowerCase()){
      case "pdf":
        return RIConstants.ContentType.PDF_CONTENT_TYPE;
      case "txt":
      case "csv":
        return RIConstants.ContentType.PLAIN_TEXT_CONTENT_TYPE;
      case "png":
        return RIConstants.ContentType.PNG_CONTENT_TYPE;
      case "jpg":
        return RIConstants.ContentType.JPG_CONTENT_TYPE;
      case "jpeg":
        return RIConstants.ContentType.JPEG_CONTENT_TYPE;
      case "svg":
        return RIConstants.ContentType.SVG_CONTENT_TYPE;
      case "mp3":
        return RIConstants.ContentType.MP3_CONTENT_TYPE;
      case "mp4":
        return RIConstants.ContentType.MP4_CONTENT_TYPE;
      case "mov":
        return RIConstants.ContentType.MOV_CONTENT_TYPE;
      case "wav":
        return RIConstants.ContentType.WAV_CONTENT_TYPE;
      default:
        return RIConstants.ContentType.DEFAULT_CONTENT_TYPE;
    }
  }

}
