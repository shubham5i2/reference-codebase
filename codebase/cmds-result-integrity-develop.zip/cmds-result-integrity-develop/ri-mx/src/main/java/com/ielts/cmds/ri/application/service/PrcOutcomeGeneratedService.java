package com.ielts.cmds.ri.application.service;

import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.ids.domain.model.PRCOutcomeGeneratedNodeV1;
import com.ielts.cmds.ri.domain.service.PrcOutcomeGeneratedDomainService;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.service.IApplicationServiceV2;
import com.ielts.cmds.serialization.utils.ServiceIdentifier;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Service
@ServiceIdentifier(RIConstants.EventType.PRC_OUTCOME_GENERATED_EVENT)
@Slf4j
public class PrcOutcomeGeneratedService implements IApplicationServiceV2<PRCOutcomeGeneratedNodeV1> {

	 @Autowired
	 PrcOutcomeGeneratedDomainService prcOutcomeGeneratedDomainService;
	 
	@Override
	@SneakyThrows
	public void process(PRCOutcomeGeneratedNodeV1 prcOutcomeGeneratedNodeV1) {try {
        log.debug(
                "Prc Outcome Generated Service process V2 started for request with CorrelationId:{}",
                ThreadLocalHeaderContext.getContext().getCorrelationId());
        if (prcOutcomeGeneratedNodeV1 == null) {
            throw new IllegalArgumentException("Payload is Empty");
        }
        prcOutcomeGeneratedDomainService.on(prcOutcomeGeneratedNodeV1);
    } catch (IllegalArgumentException e) {
        log.error("Failed to process Booking event due to ", e);
        throw new ProcessingException(e.getMessage(), e);
    }}

}
