package com.ielts.cmds.ri.infrastructure.entity;

import java.util.Collection;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Builder
@Data
@EqualsAndHashCode(callSuper = true, exclude ={"incidentEvidenceByIncidentEvidenceUuid"})
@Table(name = "prc_outcome_details")
@NoArgsConstructor
@AllArgsConstructor
public class PrcOutcomeDetails extends CommonModel {
    
    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
    @Column(name = "prc_outcome_details_uuid")
    private UUID prcOutcomeDetailsUuid;
    
    @Column(name = "inspera_external_test_id")
    private String insperaExternalTestId;

    @ManyToOne
    @JoinColumn(name = "incident_evidence_uuid", referencedColumnName = "incident_evidence_uuid", nullable = false)
    private IncidentEvidence incidentEvidenceByIncidentEvidenceUuid;
    
    @Column(name = "booking_uuid")
    private UUID bookingUuid;
    
    @ManyToOne
    @JoinColumn(name = "unique_test_taker_uuid", referencedColumnName = "unique_test_taker_uuid", nullable = false)
    private UniqueTestTaker uniqueTestTakerByUniqueTestTakerUuid;

    @OneToMany(mappedBy = "prcOutcomeDetailsByPrcOutcomeDetailsUuid", cascade = CascadeType.ALL)
    private Collection<PrcProbabilityAnalysis> prcProbabilityAnalysesByPrcOutcomeDetailsUuid;

    @OneToMany(mappedBy = "prcOutcomeDetailsByPrcOutcomeDetailsUuid", cascade = CascadeType.ALL)
    private Collection<PrcRepeaterAnalysis> prcRepeaterAnalysesByPrcOutcomeDetailsUuid;

}
