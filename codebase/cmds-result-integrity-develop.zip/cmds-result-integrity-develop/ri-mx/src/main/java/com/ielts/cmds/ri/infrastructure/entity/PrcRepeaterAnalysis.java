package com.ielts.cmds.ri.infrastructure.entity;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Builder
@Data
@EqualsAndHashCode(callSuper = true, exclude ={"prcOutcomeDetailsByPrcOutcomeDetailsUuid"})
@Table(name = "prc_repeater_analysis")
@NoArgsConstructor
@AllArgsConstructor
public class PrcRepeaterAnalysis extends CommonModel {
 
    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
    @Column(name = "prc_repeater_analysis_uuid")
    private UUID prcRepeaterAnalysisUuid;
    
    @Basic
    @Column(name = "l_band_score_jump")
    private BigDecimal lBandScoreJump;

    @Basic
    @Column(name = "w_band_score_jump")
    private BigDecimal wBandScoreJump;

    @Basic
    @Column(name = "r_band_score_jump")
    private BigDecimal rBandScoreJump;
    

    @Basic
    @Column(name = "s_band_score_jump")
    private BigDecimal sBandScoreJump;
    
    @Basic
    @Column(name = "overall_band_score_jump")
    private BigDecimal overallBandScoreJump;
    
    @Basic
    @Column(name = "weight")
    private Integer weight;

    @ManyToOne
    @JoinColumn(name = "prc_outcome_details_uuid", referencedColumnName = "prc_outcome_details_uuid", nullable = false)
    private PrcOutcomeDetails prcOutcomeDetailsByPrcOutcomeDetailsUuid;
    
    @OneToMany(mappedBy = "prcRepeaterAnalysisByPrcRepeaterAnalysisUuid", cascade = CascadeType.ALL)
    private List<PrcRepeaterFlag> prcRepeaterFlagsByPrcRepeaterAnalysisUuid;

}
