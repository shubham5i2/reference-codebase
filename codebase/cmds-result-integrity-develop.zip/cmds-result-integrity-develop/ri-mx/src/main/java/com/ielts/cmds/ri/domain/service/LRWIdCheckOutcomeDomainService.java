package com.ielts.cmds.ri.domain.service;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.Objects;
import java.util.Optional;

import com.ielts.cmds.ri.application.exception.ResultIntegrityValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.evt119.CheckOutcomeV1;
import com.ielts.cmds.api.evt119.IntegrityCheckInitiatedV1;
import com.ielts.cmds.ids.domain.model.CandidateIdCheckOutcomeNodeV1;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeType;
import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.Product;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.ProductRepository;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;
import com.ielts.cmds.serialization.domain.EnableOutboundEventV2;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@EnableOutboundEventV2
public class LRWIdCheckOutcomeDomainService extends AbstractCMDSDomainService<IntegrityCheckInitiatedV1> {

  private final CheckOutcomeRepository checkOutcomeRepository;
  private final CheckOutcomeStatusRepository checkOutcomeStatusRepository;
  private final CheckOutcomeTypeRepository checkOutcomeTypeRepository;
  private final OutcomeStatusRepository outcomeStatusRepository;
  private final BookingRepository bookingRepository;
  private final ProductRepository productRepository;
  private static final String IOL_PRODUCT = "IOL";

  @Autowired
  public LRWIdCheckOutcomeDomainService(ApplicationEventPublisher publisher,
                                        ObjectMapper objectMapper,
                                        @Value("${integrityCheckInitiated.v2}") String isV2Enabled,
                                        CMDSThreadLocalContextService cmdsThreadLocalContextService,
                                        CheckOutcomeRepository checkOutcomeRepository,
                                        CheckOutcomeStatusRepository checkOutcomeStatusRepository,
                                        CheckOutcomeTypeRepository checkOutcomeTypeRepository,
                                        OutcomeStatusRepository outcomeStatusRepository,
                                        BookingRepository bookingRepository,
                                        ProductRepository productRepository) {
		super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
		this.checkOutcomeRepository = checkOutcomeRepository;
		this.checkOutcomeStatusRepository = checkOutcomeStatusRepository;
		this.checkOutcomeTypeRepository = checkOutcomeTypeRepository;
		this.outcomeStatusRepository = outcomeStatusRepository;
        this.bookingRepository=bookingRepository;
        this.productRepository = productRepository;
  }

  @SneakyThrows
  @Transactional
  public void on(final CandidateIdCheckOutcomeNodeV1 idCheckOutcomeReceived) {
    log.debug("LRWIdCheckOutcomeDomainService| on | CandidateIdCheckOutcomeNodeV1:{}", idCheckOutcomeReceived);
    // check if product is non-IOL product, then ignore the CandidateIDCheckOutcome from IDS
    if(Objects.nonNull(idCheckOutcomeReceived.getBookingUuid())) {
      Optional<Booking> optionalBooking = bookingRepository.findById(idCheckOutcomeReceived.getBookingUuid());
      if(optionalBooking.isPresent()) {
        Optional<Product> optionalProduct = productRepository.findById(optionalBooking.get().getProductUuid());
        if(optionalProduct.isPresent() && !optionalProduct.get().getProductCharacteristics().contains(IOL_PRODUCT)) {
          log.info("CandidateIdCheckOutcome not being processed, received for {} booking : {}",optionalProduct.get().getProductCharacteristics(),
                  idCheckOutcomeReceived);
          return;
        }
      }
    }
    IntegrityCheckInitiatedV1 incidentDetails = new IntegrityCheckInitiatedV1();
    try {
      CheckOutcome checkOutcome = updateCheckOutcome(idCheckOutcomeReceived);
      Optional<OutcomeStatus> optionalOutcomeStatus = outcomeStatusRepository
          .findByBookingUuid(idCheckOutcomeReceived.getBookingUuid());
      OutcomeStatus outcomeStatus = optionalOutcomeStatus.orElseGet(() -> OutcomeStatus.builder().build());
      outcomeStatus.setBookingVersion(checkOutcome.getBookingVersion());
      outcomeStatus.setCheckOutcomeEventDateTime(checkOutcome.getEventDateTime());
      outcomeStatusRepository.save(outcomeStatus);
      incidentDetails = buildEvent(checkOutcome);
      buildHeader(checkOutcome);
    } catch (ResultIntegrityException e) {
      log.warn("IdCheckOutcomeReceivedCommand execution failed", e);
      buildHeader(null);
    }
    publishEvent(incidentDetails);
  }

private IntegrityCheckInitiatedV1 buildEvent(CheckOutcome checkOutcome) {
    CheckOutcomeV1 checkOutcomeV1 = new CheckOutcomeV1();
  IntegrityCheckInitiatedV1 integrityCheckInitiatedV1=new IntegrityCheckInitiatedV1();
    checkOutcomeV1.setCheckOutcomeStatusUuid(checkOutcome
    		.getCheckOutcomeStatus()
        .getCheckOutcomeStatusUuid());
    checkOutcomeV1.setCheckOutcomeTypeUuid(checkOutcome
    		.getCheckOutcomeType()
        .getCheckOutcomeTypeUuid());

  integrityCheckInitiatedV1.setCheckOutcome(checkOutcomeV1);
  integrityCheckInitiatedV1.setBookingUuid((checkOutcome.getBookingUuid()));
  integrityCheckInitiatedV1.setBookingVersion(checkOutcome.getBookingVersion());

    return integrityCheckInitiatedV1;
  }

  public CheckOutcome updateCheckOutcome(CandidateIdCheckOutcomeNodeV1 idCheckOutcomeReceived) {

    log.info("Enter into updateCheckOutcome(): {}", idCheckOutcomeReceived);
    Optional<Booking> newBookingWithUpdatedBookingVersion = bookingRepository.findById(idCheckOutcomeReceived.getBookingUuid());
    CheckOutcomeType checkOutcomeType = getCheckOutComeType();
    if (newBookingWithUpdatedBookingVersion.isPresent()) {
      CheckOutcome checkOutcome = setCheckOutcome
              (idCheckOutcomeReceived,
                      checkOutcomeType,
                      newBookingWithUpdatedBookingVersion.get());

      Optional<CheckOutcome> existingCheckOutCome =
              checkOutcomeRepository.
                      findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid
                              (idCheckOutcomeReceived.getBookingUuid(), Optional.ofNullable(checkOutcomeType).map(CheckOutcomeType::getCheckOutcomeTypeUuid).orElse(null));

      if (existingCheckOutCome.isPresent() ) {
        checkOutComeValidation(idCheckOutcomeReceived,existingCheckOutCome.orElse(null));
        CheckOutcome alreadyPresentCheckOutCome = existingCheckOutCome.get();
        alreadyPresentCheckOutCome.setCheckOutcomeStatus(
                checkOutcome.getCheckOutcomeStatus());
        alreadyPresentCheckOutCome.setBookingVersion(newBookingWithUpdatedBookingVersion.get().getBookingVersion());
        alreadyPresentCheckOutCome.setEventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime());
        return checkOutcomeRepository.save(alreadyPresentCheckOutCome);
      }
      return checkOutcomeRepository.save(checkOutcome);
    }
    else {
  throw  new ResultIntegrityException("No new Booking against this checkoutcome");
    }
  }

  protected void checkOutComeValidation(final CandidateIdCheckOutcomeNodeV1 idCheckOutcomeReceivedDetails,
                                        final CheckOutcome optionalCheckOutCome) throws ResultIntegrityValidationException {
    if (Objects.nonNull(optionalCheckOutCome)) {
      LocalDateTime localDateTime = optionalCheckOutCome.getEventDateTime();
      if (!(ThreadLocalHeaderContext.getContext().getEventDateTime().isAfter(localDateTime))) {
        throw new ResultIntegrityValidationException(
                String.format("Received Event Date time is before this : %s  " + "for this Booking UUID : %s",
                        localDateTime, idCheckOutcomeReceivedDetails.getBookingUuid()),
                new Throwable());
      }
    }
  }
  private CheckOutcome setCheckOutcome(CandidateIdCheckOutcomeNodeV1 idCheckOutcomeReceived,
                                       CheckOutcomeType checkOutcomeType,
                                       Booking newUpdatedBookingVersion) {
    CheckOutcome checkOutcome = new CheckOutcome();
    checkOutcome.setCheckOutcomeStatus(
        getCheckOutComeStatus(idCheckOutcomeReceived));
    checkOutcome.setCheckOutcomeType(
        checkOutcomeType);
    checkOutcome.setBookingUuid(idCheckOutcomeReceived.getBookingUuid());
    checkOutcome.setBookingVersion(newUpdatedBookingVersion.getBookingVersion());
    checkOutcome.setEventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime());
    return checkOutcome;
  }

  private CheckOutcomeStatus getCheckOutComeStatus(CandidateIdCheckOutcomeNodeV1 idCheckOutcomeReceived) {
    CheckOutcomeStatus checkOutcomeStatus = null;
    Optional<CheckOutcomeStatus> optionalCheckOutcomeStatus =
        checkOutcomeStatusRepository.findById(
            idCheckOutcomeReceived.getStatusUuid());
    if (optionalCheckOutcomeStatus.isPresent()) {
      checkOutcomeStatus = optionalCheckOutcomeStatus.get();
    }
    return checkOutcomeStatus;
  }

  private CheckOutcomeType getCheckOutComeType() {
    CheckOutcomeType checkOutcomeType = null;
    Optional<CheckOutcomeType> optionalCheckOutcomeType =
        checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(
            RIConstants.PrcOutcomeConstant.LRW_ID_INC_CHK);
    if (optionalCheckOutcomeType.isPresent()) {
      checkOutcomeType = optionalCheckOutcomeType.get();
    }
    return checkOutcomeType;
  }

  private void buildHeader(CheckOutcome checkOutcome) {
	  CMDSHeaderContext eventHeader = new CMDSHeaderContext();
    eventHeader.setCorrelationId(ThreadLocalHeaderContext.getContext().getCorrelationId());
    eventHeader.setEventDateTime(LocalDateTime.now(ZoneOffset.UTC));
    eventHeader.setTransactionId(ThreadLocalHeaderContext.getContext().getTransactionId());
    eventHeader.setPartnerCode(ThreadLocalHeaderContext.getContext().getPartnerCode());
    eventHeader.setEventContext(Collections.
        singletonMap("checkOutcomeUuid", Objects.nonNull(checkOutcome) ? checkOutcome
            .getCheckOutcomeUuid().toString() : ""));
    eventHeader.setEventName(RIConstants.EventType.INTEGRITY_CHECK_INITIATED);
    ThreadLocalHeaderContext.clearContext();
    ThreadLocalHeaderContext.setContext(eventHeader);
  }
}
