package com.ielts.cmds.ri.infrastructure.repository;

import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface OutcomeStatusRepository extends JpaRepository<OutcomeStatus, UUID> {
    Optional<OutcomeStatus> findByBookingUuid(UUID bookingUuid);
}
