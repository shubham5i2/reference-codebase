package com.ielts.cmds.ri.domain.service;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import com.ielts.cmds.ri.application.exception.ResultIntegrityValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.evt119.IntegrityCheckInitiatedV1;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ors.common.out.model.IncidentV1;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeType;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;
import com.ielts.cmds.serialization.domain.EnableOutboundEventV2;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@EnableOutboundEventV2
public class SpeakingIdCheckOutcomeDomainService extends AbstractCMDSDomainService<IntegrityCheckInitiatedV1>{

  private final RICommonUtil riCommonUtil;
  private final CheckOutcomeRepository checkOutcomeRepository;
  private final CheckOutcomeStatusRepository checkOutcomeStatusRepository;
  private final CheckOutcomeTypeRepository checkOutcomeTypeRepository;
  
  @Autowired
  public SpeakingIdCheckOutcomeDomainService(ApplicationEventPublisher publisher,
                                             ObjectMapper objectMapper,
                                             @Value("${integrityCheckInitiated.v2}") String isV2Enabled,
                                             CMDSThreadLocalContextService cmdsThreadLocalContextService,
                                             RICommonUtil riCommonUtil,
                                             CheckOutcomeRepository checkOutcomeRepository,
                                             CheckOutcomeStatusRepository checkOutcomeStatusRepository,
                                             CheckOutcomeTypeRepository checkOutcomeTypeRepository) {
		super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
		this.riCommonUtil = riCommonUtil;
		this.checkOutcomeRepository = checkOutcomeRepository;
		this.checkOutcomeStatusRepository = checkOutcomeStatusRepository;
		this.checkOutcomeTypeRepository = checkOutcomeTypeRepository;
  }

  @Transactional
  public void on(final IncidentV1 speakingIdCheckOutcomeReceived) {
    log.debug("SpeakingIdCheckOutcomeDomainService| on | IncidentV1:{}", speakingIdCheckOutcomeReceived);
    IntegrityCheckInitiatedV1 integrityCheckInitiatedDetails;
	try {
		UUID externalBookingUuId = speakingIdCheckOutcomeReceived.getIncidentDetails().getExternalBookingUuid();
		Booking booking = riCommonUtil.getBookingFromExternalBookingUuId(externalBookingUuId);
		if (Objects.isNull(booking)) {
			log.warn("Booking not found for externalBookingUuid: {}", externalBookingUuId);
			throw new ResultIntegrityException("Booking not found for externalBookingUuid : " + externalBookingUuId);
		}
		CheckOutcome checkOutcome = updateCheckOutCome(booking, speakingIdCheckOutcomeReceived);
		integrityCheckInitiatedDetails = riCommonUtil.buildEvent(checkOutcome);
		buildHeader(String.valueOf(checkOutcome.getCheckOutcomeUuid()));
	} catch (ResultIntegrityException e) {
		log.warn("SpeakingIdCheckOutcomeReceivedCommand execution failed", e);
		throw new ResultIntegrityException("Booking not found for externalBookingUuid : " + e);
	}
    publishEvent(integrityCheckInitiatedDetails);
  }

  public CheckOutcome updateCheckOutCome(
      Booking booking, IncidentV1 speakingIdCheckOutcomeReceived) {
    log.info("SpeakingIdCheckOutcomeDomainService  update CheckOutcome(): {}", speakingIdCheckOutcomeReceived);
    CheckOutcomeType checkOutcomeType = getCheckOutComeType();
    CheckOutcome checkOutcome =
        populateCheckOutCome(speakingIdCheckOutcomeReceived, booking, checkOutcomeType);
    Optional<CheckOutcome> existingCheckOutCome =
        checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
            booking.getBookingUuid(), Optional.ofNullable(checkOutcomeType).map(CheckOutcomeType::getCheckOutcomeTypeUuid).orElse(null));
    if (existingCheckOutCome.isPresent()) {
        checkOutComeValidation(speakingIdCheckOutcomeReceived,existingCheckOutCome.orElse(null));
      CheckOutcome alreadyPresentCheckOutCome = existingCheckOutCome.get();
      alreadyPresentCheckOutCome.setCheckOutcomeStatus(
          checkOutcome.getCheckOutcomeStatus());
      alreadyPresentCheckOutCome.setEventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime());
      return checkOutcomeRepository.save(alreadyPresentCheckOutCome);
    }
    return checkOutcomeRepository.save(checkOutcome);
  }

    protected void checkOutComeValidation(final IncidentV1 idCheckOutcomeReceivedDetails,
                                          final CheckOutcome optionalCheckOutCome) throws ResultIntegrityValidationException {
        if (Objects.nonNull(optionalCheckOutCome)) {
            LocalDateTime localDateTime = optionalCheckOutCome.getEventDateTime();
            if (!(ThreadLocalHeaderContext.getContext().getEventDateTime().isAfter(localDateTime))) {
                throw new ResultIntegrityValidationException(
                        String.format("Received Event Date time is before this : %s  " + "for this External Booking UUID : %s",
                                localDateTime, idCheckOutcomeReceivedDetails.getIncidentDetails().getExternalBookingUuid()),
                        new Throwable());
            }
        }
    }
  private CheckOutcome populateCheckOutCome(
      IncidentV1 speakingIdCheckOutcomeReceived,
      Booking booking,
      CheckOutcomeType checkOutcomeType) {
    CheckOutcome checkOutcome = new CheckOutcome();
    checkOutcome.setCheckOutcomeStatus(
        getCheckOutComeStatus(speakingIdCheckOutcomeReceived));
    checkOutcome.setCheckOutcomeType(checkOutcomeType);
    checkOutcome.setBookingUuid(booking.getBookingUuid());
    checkOutcome.setEventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime());

    return checkOutcome;
  }

  private CheckOutcomeType getCheckOutComeType() {
    CheckOutcomeType checkOutcomeType = null;
    Optional<CheckOutcomeType> optionalCheckOutcomeType =
        checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(
            RIConstants.PrcOutcomeConstant.SPK_ID_INC_CHK);
    if (optionalCheckOutcomeType.isPresent()) {
      checkOutcomeType = optionalCheckOutcomeType.get();
    }
    return checkOutcomeType;
  }

  private CheckOutcomeStatus getCheckOutComeStatus(IncidentV1 speakingIdCheckOutcomeReceived) {
    CheckOutcomeStatus checkOutcomeStatus = null;
    Optional<CheckOutcomeStatus> optionalCheckOutcomeStatus =
        checkOutcomeStatusRepository.findByCheckOutcomeStatusCode(
            riCommonUtil.externalIncidentStatus(
                speakingIdCheckOutcomeReceived
                    .getIncidentDetails()
                    .getExternalIncidentStatus()
                    .getValue()));
    if (optionalCheckOutcomeStatus.isPresent()) {
      checkOutcomeStatus = optionalCheckOutcomeStatus.get();
    }
    return checkOutcomeStatus;
  }

  private void buildHeader(String checkOutcomeUuid) {
	  CMDSHeaderContext eventHeader = new CMDSHeaderContext();
    eventHeader.setCorrelationId(ThreadLocalHeaderContext.getContext().getCorrelationId());
    eventHeader.setEventDateTime(LocalDateTime.now(ZoneOffset.UTC));
    eventHeader.setTransactionId(ThreadLocalHeaderContext.getContext().getTransactionId());
    eventHeader.setPartnerCode(ThreadLocalHeaderContext.getContext().getPartnerCode());
    eventHeader.setEventContext(Collections.singletonMap("checkOutcomeUuid", checkOutcomeUuid));
    eventHeader.setEventName(RIConstants.EventType.INTEGRITY_CHECK_INITIATED);
    ThreadLocalHeaderContext.clearContext();
    ThreadLocalHeaderContext.setContext(eventHeader);
  }
}
