package com.ielts.cmds.ri.application.service;

import com.ielts.cmds.common.config.IBaseAuditService;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.common.model.out.SearchBookingRequestV1;
import com.ielts.cmds.ri.domain.service.BookingSearchDomainService;
import com.ielts.cmds.serialization.application.service.IApplicationServiceV2;
import com.ielts.cmds.serialization.utils.ServiceIdentifier;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.ielts.cmds.ri.utils.RIConstants.PermissionId.RI_BOOKING_SEARCH;
import static com.ielts.cmds.ri.utils.RIConstants.UiConstants.OPERATION_TYPE_POST;
import static com.ielts.cmds.ri.utils.RIConstants.UiConstants.SEARCH_RESOURCE_TYPE;

/** The type Booking search service. */
@Service
@ServiceIdentifier(OPERATION_TYPE_POST+(SEARCH_RESOURCE_TYPE))
@Slf4j
public class BookingSearchService implements IApplicationServiceV2<SearchBookingRequestV1>, IBaseAuditService {

  /** The Booking search domain service. */
  @Autowired BookingSearchDomainService bookingSearchDomainService;

  @SneakyThrows
  @Override
  public void process(SearchBookingRequestV1 bookingRequestV1) {
    log.debug(
        "BookingTestTakerSearchService process started for request with transactionId:{}",
        ThreadLocalHeaderContext.getContext().getTransactionId());

    try {
      populateAuditFields();
      bookingSearchDomainService.on(bookingRequestV1);
    } catch (Exception e) {
      log.error("Exception Caught in Service: {}", e.getMessage());
      bookingSearchDomainService.publishEventToOutBoundTopic(null, null);
    }
  }

  @Override
  public String getPermission() {
    return RI_BOOKING_SEARCH;
  }

  @Override
  public String getScreen() {
    return RI_BOOKING_SEARCH;
  }

  @Override
  public String getAction() {
    return BookingSearchService.class.getSimpleName();
  }
}
