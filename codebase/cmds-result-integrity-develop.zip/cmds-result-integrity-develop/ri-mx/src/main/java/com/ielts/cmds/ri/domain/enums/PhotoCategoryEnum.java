package com.ielts.cmds.ri.domain.enums;

public enum PhotoCategoryEnum {
  CERTIFICATE("Certificate"),
  OTHER("Other");

  private String value;

  PhotoCategoryEnum(String value) {
    this.value = value;
  }

  public String getValue() {
    return this.value;
  }

  @Override
  public String toString() {

    return this.value;
  }
  public static PhotoCategoryEnum getEnum(String value) {
	  for(PhotoCategoryEnum category : values()) {
		  if(category.value.equalsIgnoreCase(value)) {
			  return category;
		  }
	  }
	  throw new IllegalArgumentException("No Constant with value " + value +"found");
  }

}
