package com.ielts.cmds.ri.application.service;

import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.infrastructure.entity.Incident;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.ors.common.out.model.IncidentV1;
import com.ielts.cmds.ri.domain.service.SpeakingIdCheckOutcomeDomainService;
import com.ielts.cmds.ri.domain.service.SpeakingIncidentCheckOutcomeDomainService;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.service.IApplicationServiceV2;
import com.ielts.cmds.serialization.utils.ServiceIdentifier;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@ServiceIdentifier(RIConstants.PrcOutcomeConstant.SPEAKING_ID_AND_INCIDENT_RAISED)
public class SpeakingIdAndIncidentService implements IApplicationServiceV2<IncidentV1> {

	@Autowired
	SpeakingIdCheckOutcomeDomainService speakingIdCheckOutcomeDomainService;

	@Autowired
	SpeakingIncidentCheckOutcomeDomainService speakingIncidentCheckOutcomeDomainService;

	@Override
	@SneakyThrows
	public void process(IncidentV1 speakingIncidentV1) {
		try {
			log.debug(
					"Speaking Incident & Id Check Outcome Service V2 process started for request with CorrelationId:{}",
					ThreadLocalHeaderContext.getContext().getCorrelationId());
			if (speakingIncidentV1 == null) {
				throw new IllegalArgumentException("Payload is Empty");
			}

			if (speakingIncidentV1.getIncidentDetails().getExternalIncidentId() == null) {
				speakingIdCheckOutcomeDomainService.on(speakingIncidentV1);
			} else {
				Incident incident=speakingIncidentCheckOutcomeDomainService.on(speakingIncidentV1);
				speakingIncidentCheckOutcomeDomainService.setIncidentEvidence(speakingIncidentV1,incident);
			}
		} catch (IllegalArgumentException e) {
			log.error("Failed to process Speaking Incident Check Outcome Service event due to ", e);
			throw new ProcessingException(e.getMessage(), e);
		}
	}

}
