package com.ielts.cmds.ri.infrastructure.repository;

import com.ielts.cmds.ri.infrastructure.entity.PrcOutcomeDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface PrcOutcomeDetailsRepository extends JpaRepository<PrcOutcomeDetails, UUID> {
    List<PrcOutcomeDetails> findByBookingUuid(UUID bookingUuid);
}
