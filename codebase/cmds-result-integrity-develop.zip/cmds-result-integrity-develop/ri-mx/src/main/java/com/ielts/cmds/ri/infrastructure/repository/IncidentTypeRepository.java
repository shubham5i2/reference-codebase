package com.ielts.cmds.ri.infrastructure.repository;

import com.ielts.cmds.ri.infrastructure.entity.IncidentType;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;
@Repository
@Cacheable("incidentTypes")
public interface IncidentTypeRepository extends JpaRepository<IncidentType, UUID> {
    Optional<IncidentType> findByIncidentTypeCode(String incidentCategoryCode);
    Optional<IncidentType> findByIncidentTypeUuid(UUID incidentTypeUuid);
}
