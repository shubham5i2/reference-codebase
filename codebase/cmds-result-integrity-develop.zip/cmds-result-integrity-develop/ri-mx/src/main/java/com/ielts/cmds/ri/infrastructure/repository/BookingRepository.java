package com.ielts.cmds.ri.infrastructure.repository;

import com.ielts.cmds.ri.infrastructure.entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface BookingRepository extends JpaRepository<Booking, UUID> {
  Optional<Booking> findByExternalBookingUuid(UUID externalBookingUuid);

  Optional<Booking> findByCompositeCandidateNumber(String compositeCandidateNumber);
}

