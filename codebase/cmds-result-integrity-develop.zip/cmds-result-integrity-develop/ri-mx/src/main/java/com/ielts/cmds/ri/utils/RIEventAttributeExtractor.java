package com.ielts.cmds.ri.utils;

import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.outbox.event.model.OutboxEventAttribute;
import com.ielts.cmds.outbox.event.v1.EventAttributeExtractor;
import com.ielts.cmds.ri.utils.RIConstants.GenericConstants;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

@Component
public class RIEventAttributeExtractor implements EventAttributeExtractor {

  @Override
  public List<OutboxEventAttribute> apply(BaseEvent<? extends BaseHeader> baseHeaderBaseEvent) {
    List<OutboxEventAttribute> eventAttributes = new ArrayList<>();

    eventAttributes.add(
        OutboxEventAttribute.builder()
            .attributeKey(GenericConstants.EVENT_NAME)
            .attributeValue(baseHeaderBaseEvent.getEventHeader().getEventName())
            .build());

    if (StringUtils.isNotEmpty(baseHeaderBaseEvent.getEventHeader().getPartnerCode())) {
      eventAttributes.add(
          OutboxEventAttribute.builder()
              .attributeKey(GenericConstants.PARTNER_CODE)
              .attributeValue(baseHeaderBaseEvent.getEventHeader().getPartnerCode())
              .build());
    }

    if (baseHeaderBaseEvent.getEventHeader() instanceof UiHeader
            && ((UiHeader) baseHeaderBaseEvent.getEventHeader()).getConnectionId() != null
            && !((UiHeader) baseHeaderBaseEvent.getEventHeader()).getConnectionId().isEmpty()) {
      eventAttributes.add(
              OutboxEventAttribute.builder()
                      .attributeKey(GenericConstants.CONNECTION_ID)
                      .attributeValue(((UiHeader) baseHeaderBaseEvent.getEventHeader()).getConnectionId())
                      .build());
    }

    return eventAttributes;
  }

}
