package com.ielts.cmds.ri.utils;

import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.OUTCOME_STATUS_TYPE_CODE_IN_PROGRESS;

import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.ielts.cmds.api.evt119.IntegrityCheckInitiatedV1;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatusType;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusTypeRepository;
import com.ielts.cmds.ri.utils.RIConstants.CheckOutcomeTypeConstants;

import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.*;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
@RequiredArgsConstructor
public class IntegrityCheckHelper {

  private final OutcomeStatusRepository outcomeStatusRepository;

  private final OutcomeStatusTypeRepository outcomeStatusTypeRepository;

  private final  BookingRepository bookingRepository;

  public OutcomeStatus setOverallOutcomeStatus(IntegrityCheckInitiatedV1 eventBody,
                                               List<CheckOutcome> checkOutcomeList, List<String> applicableCheckOutcomeCodes,Booking optionalBooking) {
      boolean incidentFailedStatus = checkOutcomeList.stream().anyMatch(checkOutcome -> CHECK_OUTCOME_STATUS_CODE_FAILED
	                    .equals(checkOutcome.getCheckOutcomeStatus().getCheckOutcomeStatusCode()));
      log.info("Received checkOutcome list size {} for booking {}", checkOutcomeList.size(), eventBody.getBookingUuid());
      OutcomeStatus outcomeStatus = new OutcomeStatus();

    if ( Objects.isNull(optionalBooking)) {
      log.debug("OverallOutcomestatus is {} for new booking . ",OUTCOME_STATUS_TYPE_CODE_IN_PROGRESS);
      OutcomeStatus persistedOutcomeStatus = buildOutcomeStatus(eventBody, outcomeStatus);
      return outcomeStatusRepository.save(persistedOutcomeStatus);
    }
    Set<String> checkOutcomeTypeCodeSet = getCheckOutcomeTypeCodeSet(eventBody.getBookingUuid(), checkOutcomeList, applicableCheckOutcomeCodes);
    List<CheckOutcome> eligibleCheckOutcomeList = getEligibleCheckOutcomeList(checkOutcomeList, checkOutcomeTypeCodeSet);
    log.info("Eligible checkOutcome list size -->{} for booking {} ", eligibleCheckOutcomeList.size(), eventBody.getBookingUuid());
    if (incidentFailedStatus) {
      log.info("condition is true: any of the incident is failed");
      outcomeStatus.setOutcomeStatusType(getOutComeStatusType(OUTCOME_STATUS_TYPE_CODE_FAILED));
      OutcomeStatus persistedOutcomeStatus = buildOutcomeStatus(eventBody, outcomeStatus);
      return outcomeStatusRepository.save(persistedOutcomeStatus);
    }
    CheckOutcome prcCheckOutcome = getCheckOutcome(eligibleCheckOutcomeList, CheckOutcomeTypeConstants.CHK_OUT_TYPE_PRC_INC_CHK_CODE);
	if (CHECK_OUTCOME_STATUS_CODE_REFER
            .equals(getNullSafeCheckOutcomeStatusCode(prcCheckOutcome
                    .getCheckOutcomeStatus()))) {
      log.debug("condition is true: prc is refer and none of them is failed: {}",
              prcCheckOutcome.getCheckOutcomeStatus().getCheckOutcomeStatus());
      outcomeStatus.setOutcomeStatusType(
              getOutComeStatusType(OUTCOME_STATUS_TYPE_CODE_REFER));
      OutcomeStatus persistedOutcomeStatus = buildOutcomeStatus(eventBody, outcomeStatus);
      return outcomeStatusRepository.save(persistedOutcomeStatus);
    }

	CheckOutcome probableBanCheckOutcome= getCheckOutcome(eligibleCheckOutcomeList, CheckOutcomeTypeConstants.CHK_OUT_TYPE_PRC_INC_CHK_CODE);
	CheckOutcome idCheckOutcome= getCheckOutcome(eligibleCheckOutcomeList, CheckOutcomeTypeConstants.CHK_OUT_TYPE_LRW_ID_INC_CHK_CODE);
	CheckOutcome lrwCheckOutcome= getCheckOutcome(eligibleCheckOutcomeList, CheckOutcomeTypeConstants.CHK_OUT_TYPE_LRW_INC_CHK_CODE);
	CheckOutcome speakingCheckOutcome= getCheckOutcome(eligibleCheckOutcomeList, CheckOutcomeTypeConstants.CHK_OUT_TYPE_SPEAKING_INC_CHK_CODE);

    if (isAnyOfChecksFlagged(prcCheckOutcome, idCheckOutcome, lrwCheckOutcome, speakingCheckOutcome, probableBanCheckOutcome)) {
      log.info("condition is true: any one from prc, id check, speaking, lrw or probable ban is flagged and none of them is failed");
      log.debug("condition is true: any one from prc, id check, speaking, lrw or probable ban is flagged and none of them is failed:" +
                      "prcCheckOutcomeStatus.getCheckOutcomeStatus(): " + prcCheckOutcome.getCheckOutcomeStatus() +
                      " idCheckOutcomeStatus.getCheckOutcomeStatusCode(): " + idCheckOutcome.getCheckOutcomeStatus() +
                      " lrwCheckOutcomeStatus.getCheckOutcomeStatusCode(): " + lrwCheckOutcome.getCheckOutcomeStatus() +
                      " speakingCheckOutcomeStatus.getCheckOutcomeStatusCode(): " + speakingCheckOutcome.getCheckOutcomeStatus() +
                      " probableBanCheckOutcomeStatus.getCheckOutcomeStatusCode(): " + probableBanCheckOutcome.getCheckOutcomeStatus()
      );
      outcomeStatus.setOutcomeStatusType(
              getOutComeStatusType(OUTCOME_STATUS_TYPE_CODE_REVIEW));
      OutcomeStatus persistedOutcomeStatus = buildOutcomeStatus(eventBody, outcomeStatus);

      return outcomeStatusRepository.save(persistedOutcomeStatus);
    }

    CheckOutcome plagiarismCheckOutcome=
    		getCheckOutcome(eligibleCheckOutcomeList, CheckOutcomeTypeConstants.CHK_OUT_TYPE_PLG_INC_CHK_CODE);
	if (!checkIfAllCheckOutcomeTypeIsReceived(applicableCheckOutcomeCodes, checkOutcomeTypeCodeSet)
            || CHECK_OUTCOME_STATUS_CODE_PENDING
            .equals(getNullSafeCheckOutcomeStatusCode(plagiarismCheckOutcome
                    .getCheckOutcomeStatus()))) {
      log.info("Condition is true: All checks are not received or plagiarism is pending");
      log.debug("condition is true: All checks are not received or plagiarism is pending: plagiarismCheckOutcomeStatus.getCheckOutcomeStatus(): {} ",
              plagiarismCheckOutcome.getCheckOutcomeStatus());
      outcomeStatus.setOutcomeStatusType(
              getOutComeStatusType(OUTCOME_STATUS_TYPE_CODE_IN_PROGRESS));
    } else {
      log.info("condition is true: all checks are received and none of them is failed/refer/flagged and plagiarism is not pending");
      outcomeStatus.setOutcomeStatusType(
              getOutComeStatusType(OUTCOME_STATUS_TYPE_CODE_PASSED));
    }

    OutcomeStatus persistedOutcomeStatus = buildOutcomeStatus(eventBody, outcomeStatus);

    return outcomeStatusRepository.save(persistedOutcomeStatus);
  }

    private boolean isAnyOfChecksFlagged(CheckOutcome prcCheckOutcome, CheckOutcome idCheckOutcome, CheckOutcome lrwCheckOutcome, CheckOutcome speakingCheckOutcome, CheckOutcome probableBanCheckOutcome) {
        return CHECK_OUTCOME_STATUS_CODE_REVIEW.equals(getNullSafeCheckOutcomeStatusCode(prcCheckOutcome.getCheckOutcomeStatus()))
                || CHECK_OUTCOME_STATUS_CODE_REVIEW.equals(getNullSafeCheckOutcomeStatusCode(idCheckOutcome.getCheckOutcomeStatus()))
                || isAnyComponentsChecksFlagged(lrwCheckOutcome, speakingCheckOutcome)
                || CHECK_OUTCOME_STATUS_CODE_REVIEW.equals(getNullSafeCheckOutcomeStatusCode(probableBanCheckOutcome.getCheckOutcomeStatus()));
    }

    private boolean isAnyComponentsChecksFlagged(CheckOutcome lrwCheckOutcome, CheckOutcome speakingCheckOutcome) {
        return CHECK_OUTCOME_STATUS_CODE_REVIEW.equals(getNullSafeCheckOutcomeStatusCode(lrwCheckOutcome.getCheckOutcomeStatus()))
                || CHECK_OUTCOME_STATUS_CODE_REVIEW.equals(getNullSafeCheckOutcomeStatusCode(speakingCheckOutcome.getCheckOutcomeStatus()));
    }

    private String getNullSafeCheckOutcomeStatusCode(CheckOutcomeStatus checkOutcomeStatus) {
	if(checkOutcomeStatus!= null) {
		return checkOutcomeStatus.getCheckOutcomeStatusCode();
	}
	return "";
}


private CheckOutcome getCheckOutcome(List<CheckOutcome> eligibleCheckOutcomeList,
		String checkOutcomeTypeCode) {
	  Optional<CheckOutcome> checkOutcomeOptional = eligibleCheckOutcomeList.stream()
	  .filter(checkOutcome -> checkOutcomeTypeCode.equals(checkOutcome.getCheckOutcomeType().getCheckOutcomeTypeCode()))
	  .findAny();
	  
	return checkOutcomeOptional.orElse(new CheckOutcome());
}



boolean checkIfAllCheckOutcomeTypeIsReceived(List<String> applicableCheckOutcomeCodes, Set<String> checkOutcomeTypeCodeSet) {
    log.debug("checkOutcomeTypeCodeSet size:--> " + checkOutcomeTypeCodeSet.size());
    return checkOutcomeTypeCodeSet.containsAll(applicableCheckOutcomeCodes);
  }
  
  private OutcomeStatus buildOutcomeStatus(
      IntegrityCheckInitiatedV1 integrityCheckInitiatedV1, OutcomeStatus outcomeStatus) {

    Optional<OutcomeStatus> optionalOutcomeStatus = outcomeStatusRepository.findByBookingUuid(
        integrityCheckInitiatedV1.getBookingUuid());
    Optional<Booking> optionalBooking=bookingRepository.findById(integrityCheckInitiatedV1.getBookingUuid());


    if (optionalOutcomeStatus.isPresent()) {
      optionalOutcomeStatus.get().setOutcomeStatusType(
          outcomeStatus.getOutcomeStatusType());
      optionalOutcomeStatus.get().setBookingVersion(optionalBooking.map(Booking::getBookingVersion).orElse(integrityCheckInitiatedV1.getBookingVersion()));
      return optionalOutcomeStatus.get();

    } else {
      outcomeStatus.setBookingUuid(integrityCheckInitiatedV1.getBookingUuid());
      outcomeStatus.setBookingVersion(optionalBooking.map(Booking::getBookingVersion).orElse(integrityCheckInitiatedV1.getBookingVersion()));
      outcomeStatus.setOutcomeStatusType(getOutComeStatusType(OUTCOME_STATUS_TYPE_CODE_IN_PROGRESS));
      return outcomeStatus;
    }
  }

  private OutcomeStatusType getOutComeStatusType(String statusTypeCode) {
    OutcomeStatusType outcomeStatusType = null;
    Optional<OutcomeStatusType> optionalOutcomeStatusType =
        outcomeStatusTypeRepository.findByOutcomeStatusTypeCode(
            statusTypeCode);
    if (optionalOutcomeStatusType.isPresent()) {
      outcomeStatusType = optionalOutcomeStatusType.get();
    }
    return outcomeStatusType;
  }

  Set<String> getCheckOutcomeTypeCodeSet(UUID bookingUuid, List<CheckOutcome> checkOutcomeList, List<String> applicableCheckOutcomeCodes) {
	    Set<String> checkOutcomeTypeCodeSet = new HashSet<>();

	    checkOutcomeList.forEach(checkOutcome ->
	        checkOutcomeTypeCodeSet
	            .add(checkOutcome.getCheckOutcomeType().getCheckOutcomeTypeCode()));
	    checkOutcomeTypeCodeSet.retainAll(applicableCheckOutcomeCodes);
	    log.info("Applicable Checkoutcome code {} for booking uuid {}",applicableCheckOutcomeCodes, bookingUuid);

	    return checkOutcomeTypeCodeSet;
	  }

  List<CheckOutcome> getEligibleCheckOutcomeList(List<CheckOutcome> checkOutcomeList, Set<String> checkOutcomeTypeCodeSet) {
    return checkOutcomeList.stream().filter(checkOutcome ->
        checkOutcomeTypeCodeSet.stream().anyMatch(checkOutcomeTypeCode ->
            checkOutcome.getCheckOutcomeType().getCheckOutcomeTypeCode()
                .equals(checkOutcomeTypeCode))).collect(Collectors.toList());
  }

}
