package com.ielts.cmds.ri.domain.enums;

public enum BookingRoleEnum {
  SSRORIGINAL("SSRORIGINAL");

  private String value;

  BookingRoleEnum(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }

  @Override
  public String toString() {
    return String.valueOf(value);
  }

}
