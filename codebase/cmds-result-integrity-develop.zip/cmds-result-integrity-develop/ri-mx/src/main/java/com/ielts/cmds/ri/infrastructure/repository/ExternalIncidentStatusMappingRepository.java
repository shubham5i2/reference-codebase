package com.ielts.cmds.ri.infrastructure.repository;

import com.ielts.cmds.ri.domain.enums.ExternalIncidentStatusEnum;
import com.ielts.cmds.ri.domain.enums.IncidentSeverityEnum;
import com.ielts.cmds.ri.infrastructure.entity.ExternalIncidentStatusMapping;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface ExternalIncidentStatusMappingRepository extends CrudRepository<ExternalIncidentStatusMapping, UUID> {

    Optional<ExternalIncidentStatusMapping> findByIncidentSeverityAndExternalIncidentStatusAndProductUuidAndIncidentCategoryUuid
            (IncidentSeverityEnum incidentSeverity, ExternalIncidentStatusEnum externalIncidentStatus, UUID productUuid, UUID incidentCategoryUuid);
    default Optional<ExternalIncidentStatusMapping> getExternalIncidentStatusDetails(IncidentSeverityEnum incidentSeverity, ExternalIncidentStatusEnum externalIncidentStatus, UUID productUuid, UUID incidentCategoryUuid) {
        return findByIncidentSeverityAndExternalIncidentStatusAndProductUuidAndIncidentCategoryUuid( incidentSeverity,  externalIncidentStatus,  productUuid,  incidentCategoryUuid);
    }
}
