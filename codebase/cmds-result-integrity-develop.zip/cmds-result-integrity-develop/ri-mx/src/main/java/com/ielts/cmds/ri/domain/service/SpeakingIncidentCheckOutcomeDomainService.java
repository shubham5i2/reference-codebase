package com.ielts.cmds.ri.domain.service;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import com.ielts.cmds.ri.application.exception.ResultIntegrityValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.evt074.ResultIntegrityIncidentDetailsWrapperV1;
import com.ielts.cmds.api.evt119.IntegrityCheckInitiatedV1;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ors.common.out.model.CommentDetailsV1;
import com.ielts.cmds.ors.common.out.model.DocumentsDetailsV1;
import com.ielts.cmds.ors.common.out.model.IncidentDetailsV1;
import com.ielts.cmds.ors.common.out.model.IncidentV1;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.domain.enums.ExternalIncidentStatusEnum;
import com.ielts.cmds.ri.domain.enums.IncidentCommentUserTypeEnum;
import com.ielts.cmds.ri.domain.enums.IncidentSeverityEnum;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.BookingLine;
import com.ielts.cmds.ri.infrastructure.entity.ExternalIncidentStatusMapping;
import com.ielts.cmds.ri.infrastructure.entity.Incident;
import com.ielts.cmds.ri.infrastructure.entity.IncidentCategory;
import com.ielts.cmds.ri.infrastructure.entity.IncidentComment;
import com.ielts.cmds.ri.infrastructure.entity.IncidentEvidence;
import com.ielts.cmds.ri.infrastructure.entity.IncidentStatusType;
import com.ielts.cmds.ri.infrastructure.entity.IncidentType;
import com.ielts.cmds.ri.infrastructure.repository.BookingLineRepository;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.ExternalIncidentStatusMappingRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentCommentRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentStatusTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentTypeRepository;
import com.ielts.cmds.ri.utils.CheckOutcomeStatusHelper;
import com.ielts.cmds.ri.utils.FileStorageHelper;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;
import com.ielts.cmds.serialization.domain.EnableOutboundEventV2;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@Service
@EnableOutboundEventV2
public class SpeakingIncidentCheckOutcomeDomainService extends AbstractCMDSDomainService<Object>{

	private final RICommonUtil riCommonUtil;
	private final IncidentStatusTypeRepository incidentStatusTypeRepository;
	private final IncidentRepository incidentRepository;
	private final IncidentTypeRepository incidentTypeRepository;
	private final BookingLineRepository bookingLineRepository;
	private final ExternalIncidentStatusMappingRepository externalIncidentStatusMappingRepository;
	private final CheckOutcomeStatusHelper checkOutcomeStatusHelper;
	private final FileStorageHelper fileStorageHelper;
	private final IncidentCommentRepository incidentCommentRepository;
	private final String bucketName;
	private final BookingRepository bookingRepository;

	@Autowired
	public SpeakingIncidentCheckOutcomeDomainService(ApplicationEventPublisher publisher,
			ObjectMapper objectMapper,
			@Value("${resultIntegrityIncidentDetailsRaised.v2}") String isV2Enabled,
			CMDSThreadLocalContextService cmdsThreadLocalContextService,
			RICommonUtil riCommonUtil,
			IncidentStatusTypeRepository incidentStatusTypeRepository,
			IncidentRepository incidentRepository,
			IncidentTypeRepository incidentTypeRepository,
			BookingLineRepository bookingLineRepository,
			ExternalIncidentStatusMappingRepository externalIncidentStatusMappingRepository,
			CheckOutcomeStatusHelper checkOutcomeStatusHelper,
			FileStorageHelper fileStorageHelper,
			IncidentCommentRepository incidentCommentRepository,
			@Value("${ri-bucket}") String bucketName,
			BookingRepository bookingRepository) {
		super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
		this.riCommonUtil = riCommonUtil;
		this.incidentStatusTypeRepository = incidentStatusTypeRepository;
		this.incidentRepository = incidentRepository;
		this.incidentTypeRepository = incidentTypeRepository;
		this.bookingLineRepository = bookingLineRepository;
		this.externalIncidentStatusMappingRepository = externalIncidentStatusMappingRepository;
		this.checkOutcomeStatusHelper = checkOutcomeStatusHelper;
		this.fileStorageHelper = fileStorageHelper;
		this.incidentCommentRepository = incidentCommentRepository;
		this.bucketName = bucketName;
		this.bookingRepository=bookingRepository;
	}

	@SneakyThrows
	@Transactional
	public Incident on(
			final IncidentV1 speakingIncidentCheckOutcomeReceived) {
		log.info("Entered into onSpeakingIncidentCheckOutcomeCommand()");

		try {
			UUID externalBookingUuId = speakingIncidentCheckOutcomeReceived.getIncidentDetails()
					.getExternalBookingUuid();

			Booking booking = riCommonUtil.getBookingFromExternalBookingUuId(externalBookingUuId);

			if (Objects.isNull(booking)) {
				log.error("Booking not found for externalBookingUuid: {}", externalBookingUuId);
				throw new ResultIntegrityException("Booking not found for externalBookingUuid : " +
						externalBookingUuId);
			}
			Optional<Booking> optionalBooking=bookingRepository.findById(booking.getBookingUuid());
			//update incident
			final Incident incident = updateIncident(booking, speakingIncidentCheckOutcomeReceived,optionalBooking.orElse(null));

			Boolean eligibleForIntegrity = incident.getIncidentCategoryByIncidentCategoryUuid()
					.getEligibleForIntegrityCheck();

			if (Boolean.TRUE.equals(eligibleForIntegrity)
					&& incident.getIncidentSeverity() != null
					&& IncidentSeverityEnum.CONFIRMED_MALPRACTICE
					.getValue()
					.equals(incident.getIncidentSeverity().getValue())) {
				publishIntegrityCheckInitiatedEvent(incident);
			}
			publishIntegrityIncidentDetailsRaisedEvent(incident,optionalBooking.orElse(null));
			return incident;
		} catch (ResultIntegrityException e) {
			log.error("SpeakingIncidentCheckOutcomeReceivedCommand execution failed", e);
			throw new ResultIntegrityException("Booking not found for externalBookingUuid : " + e);
		}
	}

	private void publishIntegrityCheckInitiatedEvent(Incident incident) {
		IntegrityCheckInitiatedV1 integrityCheckInitiatedDetails;

		log.info("publishing event: {}", RIConstants.EventType.INTEGRITY_CHECK_INITIATED);
		buildHeader(incident, RIConstants.EventType.INTEGRITY_CHECK_INITIATED);
		integrityCheckInitiatedDetails = riCommonUtil.buildEvent(incident.getCheckOutcomeByCheckOutcomeUuid());

		publishEvent(integrityCheckInitiatedDetails);
	}

	private void publishIntegrityIncidentDetailsRaisedEvent(Incident incident, Booking optionalBooking) {

		log.info("publishing event: {}",
				RIConstants.EventType.RESULT_INTEGRITY_INCIDENT_DETAILS_RAISED);
		ResultIntegrityIncidentDetailsWrapperV1 resultIntegrityIncidentDetailsWrapperV1;
		buildHeader(incident, RIConstants.EventType.RESULT_INTEGRITY_INCIDENT_DETAILS_RAISED);
		resultIntegrityIncidentDetailsWrapperV1 = riCommonUtil.populateIntegrityDetailsRaisedEvent(incident,optionalBooking);

		publishEvent(resultIntegrityIncidentDetailsWrapperV1);
	}

  private Incident updateIncident(Booking booking,
      IncidentV1 speakingIncidentCheckOutcomeReceived,Booking optionalBooking) {
    log.info("SpeakingIncidentCheckOutcomeDomainService for update Incident(): {}", speakingIncidentCheckOutcomeReceived);
    Incident incident;
    Optional<Incident> optionalIncident;

		BookingLine bookingLine = getBookingLine(
				speakingIncidentCheckOutcomeReceived);

		if (Objects.nonNull(bookingLine)) {
			optionalIncident = incidentRepository
					.findByExternalIncidentIdAndBookingUuidAndBookingLineUuid(
							speakingIncidentCheckOutcomeReceived.getIncidentDetails().getExternalIncidentId(),
							booking.getBookingUuid(), bookingLine.getBookingLineUuid()
							);
		} else {
			optionalIncident = incidentRepository.findByExternalIncidentIdAndBookingUuid(
					speakingIncidentCheckOutcomeReceived.getIncidentDetails().getExternalIncidentId(),
					booking.getBookingUuid());
		}


		if (optionalIncident.isPresent()) {
			incidentValidation(speakingIncidentCheckOutcomeReceived,optionalIncident.get());
			log.debug(
					"Incident with externalIncidentId:{} is getting updated",
					speakingIncidentCheckOutcomeReceived.getIncidentDetails().getExternalIncidentId());
			incident = optionalIncident.get();
			incident.setExternalIncidentStatus(
					ExternalIncidentStatusEnum.valueOf(speakingIncidentCheckOutcomeReceived
							.getIncidentDetails().getExternalIncidentStatus().toString()));
			incident.setIncidentCommentsByIncidentUuid(new ArrayList<>());
			incident.setIncidentEvidencesByIncidentUuid(new ArrayList<>());
			if (Objects.nonNull(
					speakingIncidentCheckOutcomeReceived
					.getIncidentDetails()
					.getComments())) {
				setIncidentComments(speakingIncidentCheckOutcomeReceived, incident);
			}
			incident.setIncidentSeverity(speakingIncidentCheckOutcomeReceived.getIncidentDetails()
					.getIncidentSeverity() !=null
					? IncidentSeverityEnum.fromValue(
							speakingIncidentCheckOutcomeReceived.getIncidentDetails().getIncidentSeverity()
							.getValue()) :null);
			incident.setIncidentStatusTypeByIncidentStatusTypeUuid(
					getIncidentStatusType(incident, incident.getIncidentCategoryByIncidentCategoryUuid()));
			incident.setEventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime());
		} else {
			log.debug(
					"Incident with externalIncidentId:{} is getting created",
					speakingIncidentCheckOutcomeReceived.getIncidentDetails().getExternalIncidentId());
			incident = populateIncident(booking, speakingIncidentCheckOutcomeReceived, bookingLine);
		}

		checkOutcomeStatusHelper.setCheckOutcomeStatus(incident,
				RIConstants.PrcOutcomeConstant.SPK_INC_CHK,optionalBooking);
		return incidentRepository.save(incident);
	}

	protected void incidentValidation(final IncidentV1 idCheckOutcomeReceivedDetails,
										  final Incident optionalIncident) throws ResultIntegrityValidationException {
		if (Objects.nonNull(optionalIncident)) {
			LocalDateTime localDateTime = optionalIncident.getEventDateTime();
			if (!(ThreadLocalHeaderContext.getContext().getEventDateTime().isAfter(localDateTime))) {
				throw new ResultIntegrityValidationException(
						String.format("Received Event Date time is before this : %s  " + "for this External Booking UUID : %s",
								localDateTime, idCheckOutcomeReceivedDetails.getIncidentDetails().getExternalBookingUuid()),
						new Throwable());
			}
		}
	}

	private Incident populateIncident(Booking booking,
			IncidentV1 speakingIncidentCheckOutcomeReceived, BookingLine bookingLine) {
		log.info("create new incident");
		IncidentDetailsV1 incidentDetails = speakingIncidentCheckOutcomeReceived.getIncidentDetails();
		Incident incident = Incident.builder()
				.externalIncidentId(incidentDetails.getExternalIncidentId())
				.externalIncidentChangedDateTime(incidentDetails.getExternalIncidentChangedDateTime())
				.incidentSeverity(incidentDetails.getIncidentSeverity() !=null
				? IncidentSeverityEnum.fromValue(
						incidentDetails.getIncidentSeverity().getValue()) :null)
				.incidentCommentsByIncidentUuid(new ArrayList<>())
				.incidentEvidencesByIncidentUuid(new ArrayList<>())
				.externalIncidentStatus(
						ExternalIncidentStatusEnum.valueOf(incidentDetails.getExternalIncidentStatus()
								.toString()))
				.eventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime())
				.build();

		incident.setBookingUuid(booking.getBookingUuid());
		if (Objects.nonNull(bookingLine)) {
			incident.setBookingLineUuid(bookingLine.getBookingLineUuid());
		} else {
			incident.setBookingLineUuid(null);
		}

		IncidentType incidentType = getIncidentType(incidentDetails.getIncidentTypeUuid());
		if (Objects.nonNull(incidentType)) {
			incident.setIncidentTypeByIncidentTypeUuid(incidentType);
			incident.setIncidentCategoryByIncidentCategoryUuid(
					incidentType.getIncidentCategoryByIncidentCategoryUuid());
		}
		incident.setIncidentStatusTypeByIncidentStatusTypeUuid(
				getIncidentStatusType(incident, incident.getIncidentCategoryByIncidentCategoryUuid()));
		if (Objects.nonNull(
				speakingIncidentCheckOutcomeReceived
				.getIncidentDetails()
				.getComments())) {
			setIncidentComments(speakingIncidentCheckOutcomeReceived, incident);
		}

		return incident;
	}

	@Transactional
	public void setIncidentEvidence(IncidentV1 speakingIncidentCheckOutcomeReceived,
			Incident incident) {
		if (Objects.nonNull(
				speakingIncidentCheckOutcomeReceived
				.getIncidentDetails()
				.getDocumentsAttached())) {
			speakingIncidentCheckOutcomeReceived.getIncidentDetails().getDocumentsAttached()
			.forEach(element -> incident.addIncidentEvidence(buildEvidence(element,
					speakingIncidentCheckOutcomeReceived.getIncidentDetails().getExternalIncidentId(),
					String.valueOf(speakingIncidentCheckOutcomeReceived.getIncidentDetails()
							.getExternalIncidentChangedDateTime()))));
			incidentRepository.save(incident);
		}
	}

	private String populateObjectKey(String externalIncidentId, String externalIncidentChangedDateTime
			, String getDocumentName) {
		return String.format("incident/%s/%s/%s",
				externalIncidentId, externalIncidentChangedDateTime, getDocumentName);
	}

	private IncidentEvidence buildEvidence(DocumentsDetailsV1 document,
										   String externalIncidentId,
										   String externalIncidentChangedDateTime) {
		String objectKey = populateObjectKey(externalIncidentId, externalIncidentChangedDateTime,
				document.getDocumentName());
		try {
			fileStorageHelper.uploadFileToS3FromPresignedUrl(document.getDocumentURL(), objectKey,
					bucketName);
		} catch (IOException e) {
			log.error("Fail to process IncidentEvidence: ", e);
			throw new ResultIntegrityException(
					"Pre-Singed url can not be processed: " + document.getDocumentURL());
		}
		return IncidentEvidence.builder()
				.incidentEvidenceName(document.getDocumentName())
				.incidentEvidenceUrl(objectKey)
				.build();
	}

	private void setIncidentComments(IncidentV1 speakingIncidentCheckOutcomeReceived,
			Incident incident) {
		speakingIncidentCheckOutcomeReceived.getIncidentDetails().getComments()
		.forEach(element -> incident.addIncidentComment(buildComment(element)));
	}

	private IncidentComment buildComment(CommentDetailsV1 comment) {
		//IMOD-36976: Check for presence of ExternalCommentUUID before acting on it
		Optional<IncidentComment> optionIncidentComment = Optional.empty();
		if(Objects.nonNull(comment.getExternalCommentUuid())) {
			optionIncidentComment = incidentCommentRepository.findByExternalCommentUuid(comment.getExternalCommentUuid());
		}

		IncidentComment incidentComment = optionIncidentComment.orElse(new IncidentComment());
		incidentComment.setIncidentCommentText(comment.getComment());
		incidentComment.setIncidentCommentEnteredBy(comment.getCommentEnteredBy());
		incidentComment.setIncidentCommentDateTime(comment.getCommentDateTime());
		incidentComment.setIncidentCommentUserType(IncidentCommentUserTypeEnum.valueOf(
				comment.getCommentEnteredByUserType().getValue()
				));
		incidentComment.setExternalCommentUuid(comment.getExternalCommentUuid());

	return incidentComment;
}

private IncidentType getIncidentType(UUID incidentTypeUuid) {
	IncidentType incidentType = null;
	Optional<IncidentType> optionalIncidentType = incidentTypeRepository
			.findByIncidentTypeUuid(incidentTypeUuid);
	if (optionalIncidentType.isPresent()) {
		incidentType = optionalIncidentType.get();
	}
	return incidentType;
}

public IncidentStatusType getIncidentStatusType(
		Incident incident, IncidentCategory incidentCategory) {
	IncidentStatusType incidentStatusType = null;
	Booking booking = riCommonUtil.getBooking(incident);
	String incidentStatus = RIConstants.IncidentStatusConstants.INFO;
	Optional<ExternalIncidentStatusMapping> optionalExternalIncidentStatusMapping = externalIncidentStatusMappingRepository
			.getExternalIncidentStatusDetails(incident
					.getIncidentSeverity(), incident.getExternalIncidentStatus(),
					booking.getProductUuid(), incidentCategory.getIncidentCategoryUuid());
	if(optionalExternalIncidentStatusMapping.isPresent()) {
		incidentStatus = optionalExternalIncidentStatusMapping.get().getIncidentStatusTypeCode();
	}

	Optional<IncidentStatusType> optionalIncidentStatusType =
			incidentStatusTypeRepository.findByIncidentStatusTypeCode(incidentStatus);
	if (optionalIncidentStatusType.isPresent()) {
		incidentStatusType = optionalIncidentStatusType.get();
	}
	return incidentStatusType;
}

private BookingLine getBookingLine(IncidentV1 incidentV1) {

	if (checkIfBookingLineIsPresent(incidentV1)) {
		Optional<BookingLine> optionalBookingLine = bookingLineRepository
				.findByExternalBookingLineUuid(
						incidentV1.getIncidentDetails().getExternalBookingLineUuid());
		return optionalBookingLine.orElse(null);
	}
	return null;
}

private boolean checkIfBookingLineIsPresent(IncidentV1 incidentV1) {
	return Objects.nonNull(incidentV1.getIncidentDetails().getExternalBookingLineUuid());
}

private void buildHeader(Incident incident, String eventName) {
	CMDSHeaderContext eventHeader = new CMDSHeaderContext();
	eventHeader.setCorrelationId(ThreadLocalHeaderContext.getContext().getCorrelationId());
	eventHeader.setEventDateTime(LocalDateTime.now(ZoneOffset.UTC));
	eventHeader.setTransactionId(ThreadLocalHeaderContext.getContext().getTransactionId());
	eventHeader.setPartnerCode(ThreadLocalHeaderContext.getContext().getPartnerCode());
	eventHeader.setEventContext(Collections.
			singletonMap("incidentUuid", incident.getIncidentUuid().toString()));
	eventHeader.setEventName(eventName);
	ThreadLocalHeaderContext.clearContext();
	ThreadLocalHeaderContext.setContext(eventHeader);
}
}
