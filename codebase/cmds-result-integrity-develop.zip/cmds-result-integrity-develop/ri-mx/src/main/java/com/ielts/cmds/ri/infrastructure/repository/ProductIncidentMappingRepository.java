package com.ielts.cmds.ri.infrastructure.repository;

import com.ielts.cmds.ri.domain.enums.IncidentSeverityEnum;
import com.ielts.cmds.ri.infrastructure.entity.ProductIncidentMapping;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;


@Repository
public interface ProductIncidentMappingRepository extends CrudRepository<ProductIncidentMapping, UUID> {

  ProductIncidentMapping findByProductUuidAndIncidentCategoryUuidAndIncidentSeverity
      (UUID productUuid, UUID incidentCategoryUuid, IncidentSeverityEnum incidentSeverity);
  ProductIncidentMapping findByProductUuidAndIncidentCategoryUuid
      (UUID productUuid, UUID incidentCategoryUuid);
}
