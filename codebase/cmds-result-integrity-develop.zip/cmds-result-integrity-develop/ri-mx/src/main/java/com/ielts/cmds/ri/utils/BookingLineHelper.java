package com.ielts.cmds.ri.utils;

import com.ielts.cmds.booking.common.out.model.BookingDetails;
import com.ielts.cmds.ri.domain.enums.BookingLineStatusEnum;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.BookingLine;
import com.ielts.cmds.ri.infrastructure.repository.BookingLineRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import static java.time.ZoneOffset.UTC;

@Component
public class BookingLineHelper {

    @Autowired
    private BookingLineRepository bookingLineRepository;


    public List<BookingLine> updateBookingLineDetails(
            Booking booking, BookingDetails bookingDetails) {
        return bookingDetails.getBookingLines().stream()
                .map(e -> getBookingLine(booking, e))
                .collect(Collectors.toList());
    }

    private BookingLine getBookingLine(Booking booking, com.ielts.cmds.booking.common.out.model.BookingLine bookingLine1) {
        BookingLine bookingLine;
        Optional<BookingLine> optionalBookingLine = bookingLineRepository.findById(bookingLine1.getBookingLineUuid());
        bookingLine = optionalBookingLine.orElseGet(() -> {
            BookingLine bookingLineToCreate = new BookingLine();
            bookingLineToCreate.setBooking(booking);
            bookingLineToCreate.setBookingLineUuid(bookingLine1.getBookingLineUuid());
            bookingLineToCreate.setLocationUuid(booking.getLocationUuid());
            bookingLineToCreate.setProductUuid(bookingLine1.getProductUuid());
            bookingLineToCreate.setExternalBookingLineUuid(bookingLine1.getExternalBookingLineUuid());
            bookingLineToCreate.setStartDatetime(bookingLine1.getStartDatetime() != null ?
                    OffsetDateTime.ofInstant(bookingLine1.getStartDatetime(),UTC) : null);
            bookingLineToCreate.setEndDatetime(bookingLine1.getEndDatetime() != null ?
                    OffsetDateTime.ofInstant(bookingLine1.getEndDatetime(),UTC) : null);
            bookingLineToCreate.setBookingLineStatus
                    (BookingLineStatusEnum.valueOf(String.valueOf(bookingLine1.getBookingLineStatus())));
            return bookingLineToCreate;
        });
        if (optionalBookingLine.isPresent()) {
            bookingLine.setBooking(booking);
            bookingLine.setProductUuid(bookingLine1.getProductUuid());
            bookingLine.setLocationUuid(booking.getLocationUuid());
            bookingLine.setBookingLineStatus
                    (BookingLineStatusEnum.valueOf(bookingLine1.getBookingLineStatus().toString()));
        }
        return bookingLine;
    }
}
