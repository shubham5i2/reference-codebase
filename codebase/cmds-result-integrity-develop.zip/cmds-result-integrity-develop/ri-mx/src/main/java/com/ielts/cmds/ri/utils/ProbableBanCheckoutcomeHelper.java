package com.ielts.cmds.ri.utils;

import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_PASSED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_REVIEW;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.INCIDENT_STATUS_TYPE_CODE_FLAGGED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.INCIDENT_STATUS_TYPE_CODE_PASSED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.INCIDENT_TYPE_CODE_PROBABLE_BAN;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.PROBABLE_BAN_OUTCOME_FLAGGED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.PROBABLE_BAN_OUTCOME_PASSED;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.ielts.cmds.api.evt113.ProbableBanCheckOutcomeDetailsV1Inner;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeType;
import com.ielts.cmds.ri.infrastructure.entity.Incident;
import com.ielts.cmds.ri.infrastructure.entity.IncidentComment;
import com.ielts.cmds.ri.infrastructure.entity.IncidentStatusType;
import com.ielts.cmds.ri.infrastructure.entity.IncidentType;
import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.UniqueTestTaker;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentStatusTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.ProductIncidentMappingRepository;
import com.ielts.cmds.ri.infrastructure.repository.UniqueTestTakerRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class ProbableBanCheckoutcomeHelper {
    @Autowired
    BookingRepository bookingRepository;
    @Autowired
    CheckOutcomeRepository checkOutcomeRepository;
    @Autowired
    CheckOutcomeStatusRepository checkOutcomeStatusRepository;
    @Autowired
    CheckOutcomeTypeRepository checkOutcomeTypeRepository;
    @Autowired
    UniqueTestTakerRepository uniqueTestTakerRepository;
    @Autowired
    OutcomeStatusRepository outcomeStatusRepository;
    @Autowired
    IncidentTypeRepository incidentTypeRepository;
    @Autowired
    IncidentStatusTypeRepository incidentStatusTypeRepository;
    @Autowired
    ProductIncidentMappingRepository productIncidentMappingRepository;
    @Autowired
    RICommonUtil riCommonUtil;

    @Transactional
    public CheckOutcome updateProbableBanOutcome(ProbableBanCheckOutcomeDetailsV1Inner probableBanCheckOutcomeDetailsV1Inner,Booking optionalBooking) {
        log.info("ProbableBanCheckoutcomeHelper |Update domain service");
        CheckOutcome checkOutcomeEntity;
        Optional<Booking> existingOptionalBooking=Optional.ofNullable(optionalBooking);
        if (Objects.isNull(optionalBooking)) {
            optionalBooking = Booking.builder()
                    .bookingUuid(probableBanCheckOutcomeDetailsV1Inner.getBookingUuid())
                    .build();
        }
        Optional<UniqueTestTaker> optionalUniqueTestTaker = uniqueTestTakerRepository
                .findByUniqueTestTakerUuid(optionalBooking.getUniqueTestTakerUuid());
        optionalBooking.setUniqueTestTaker(optionalUniqueTestTaker.orElse(null));
        CheckOutcome getCheckOutcome=setCheckOutcome(probableBanCheckOutcomeDetailsV1Inner, optionalBooking);
        if(getCheckOutcome!=null) {
            checkOutcomeEntity = checkOutcomeRepository
                    .save(getCheckOutcome);
            Optional<OutcomeStatus> optionalOutcomeStatus = outcomeStatusRepository
                    .findByBookingUuid(optionalBooking.getBookingUuid());
            if(existingOptionalBooking.isPresent()) {
                OutcomeStatus outcomeStatus = optionalOutcomeStatus.orElseGet(() -> OutcomeStatus.builder().build());
                outcomeStatusRepository.save(outcomeStatus);
                return checkOutcomeEntity;
            }
            return getCheckOutcome;
        }

        return null;
    }

    private CheckOutcome setCheckOutcome
            (ProbableBanCheckOutcomeDetailsV1Inner probableBanCheckOutcomeDetailsV1Inner, Booking booking) {
        log.debug("ProbableBanCheckoutcomeHelper |probable ban event : {}", probableBanCheckOutcomeDetailsV1Inner);
        CheckOutcomeType checkOutcomeType = getCheckOutComeType();

        CheckOutcome checkOutcome;

        // find existing check outcome with booking uuid and Probability Ban check outcome type
        Optional<CheckOutcome> optionalCheckOutcome =
                checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
                        booking.getBookingUuid(), Optional.ofNullable(checkOutcomeType).map(CheckOutcomeType::getCheckOutcomeTypeUuid).orElse(null));

        Optional<Booking> optionalBooking=bookingRepository.findById(booking.getBookingUuid());
      if(optionalBooking.isPresent() &&
              optionalBooking.get().getBookingVersion().compareTo(probableBanCheckOutcomeDetailsV1Inner.getBookingVersion()) <=0) {


          checkOutcome = optionalCheckOutcome.orElseGet(
                          () -> createNewCheckOutcome(probableBanCheckOutcomeDetailsV1Inner, booking, checkOutcomeType));


          if (isItAnOlderBooking(probableBanCheckOutcomeDetailsV1Inner, optionalCheckOutcome.orElse(null))) {
              log.warn("No action taken since received check outcome booking version {} is less than existing version {}"
                      , probableBanCheckOutcomeDetailsV1Inner.getBookingVersion(), optionalCheckOutcome.get().getBookingVersion());
              //Publish NoActionTaken Event
              return null;
          }

          if (optionalCheckOutcome.isPresent()
                  && Objects.nonNull(probableBanCheckOutcomeDetailsV1Inner.getBookingVersion())
                  && Objects.nonNull(optionalCheckOutcome.get().getBookingVersion())
                  && probableBanCheckOutcomeDetailsV1Inner.getBookingVersion().compareTo(
                  optionalBooking.get().getBookingVersion()) >= 0) {

              log.debug(
                      "existing checkOutcome is present : {}",
                      optionalCheckOutcome.get().getCheckOutcomeUuid());

              checkOutcome.setCheckOutcomeStatus(
                      setCheckOutComeStatus(probableBanCheckOutcomeDetailsV1Inner));
              checkOutcome.setCheckOutcomeType(checkOutcomeType);
              checkOutcome.setBookingUuid(booking.getBookingUuid());
              checkOutcome.setIncidentsByCheckOutcomeUuid(
                      getIncidentCollection(probableBanCheckOutcomeDetailsV1Inner, booking, checkOutcome));
              checkOutcome.setBookingVersion(probableBanCheckOutcomeDetailsV1Inner.getBookingVersion());
          }
          return checkOutcome;
      }
      else  {
            checkOutcome = optionalCheckOutcome.orElseGet(
                    () -> {
                        log.info("creating a new check outcome for booking: {}", booking.getBookingUuid());
                        CheckOutcome checkOutcomeToCreate =
                                CheckOutcome.builder()
                                        .checkOutcomeStatus(
                                                setCheckOutComeStatus(probableBanCheckOutcomeDetailsV1Inner))
                                        .checkOutcomeType(checkOutcomeType)
                                        .bookingUuid(booking.getBookingUuid())
                                        .bookingVersion(probableBanCheckOutcomeDetailsV1Inner.getBookingVersion())
                                        .eventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime())
                                        .build();

                        // add incident to check outcome
                        checkOutcomeToCreate.setIncidentsByCheckOutcomeUuid(
                                getIncidentCollection(probableBanCheckOutcomeDetailsV1Inner, booking, checkOutcomeToCreate));
                        return checkOutcomeToCreate;
                    });
            if (optionalCheckOutcome.isPresent()){
                log.debug(
                        "existing checkOutcome is present : {}",
                        optionalCheckOutcome.get().getCheckOutcomeUuid());
                checkOutcome.setIncidentsByCheckOutcomeUuid(
                        getIncidentCollection(probableBanCheckOutcomeDetailsV1Inner, booking, checkOutcome));
                checkOutcome.setBookingVersion(probableBanCheckOutcomeDetailsV1Inner.getBookingVersion());
                checkOutcome.setCheckOutcomeStatus(
                        setCheckOutComeStatus(probableBanCheckOutcomeDetailsV1Inner));
                checkOutcome.setCheckOutcomeType(checkOutcomeType);
                checkOutcome.setBookingUuid(booking.getBookingUuid());

            }
            return checkOutcome;
        }
    }

    private static boolean isItAnOlderBooking(ProbableBanCheckOutcomeDetailsV1Inner probableBanCheckOutcomeDetailsV1Inner, CheckOutcome checkOutcome) {
        return Objects.nonNull(checkOutcome)
                && Objects.nonNull(probableBanCheckOutcomeDetailsV1Inner.getBookingVersion())
                && Objects.nonNull(checkOutcome.getBookingVersion())
                && checkOutcome.getBookingVersion().compareTo(probableBanCheckOutcomeDetailsV1Inner.getBookingVersion()
        ) < 0;
    }

    private CheckOutcome createNewCheckOutcome(ProbableBanCheckOutcomeDetailsV1Inner probableBanCheckOutcomeDetailsV1Inner, Booking booking, CheckOutcomeType checkOutcomeType) {
        log.debug("creating a new check outcome for booking: {}", booking.getBookingUuid());
        CheckOutcome checkOutcomeToCreate =
                CheckOutcome.builder()
                        .checkOutcomeStatus(
                                setCheckOutComeStatus(probableBanCheckOutcomeDetailsV1Inner))
                        .checkOutcomeType(checkOutcomeType)
                        .bookingUuid(booking.getBookingUuid())
                        .bookingVersion(probableBanCheckOutcomeDetailsV1Inner.getBookingVersion())
                        .eventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime())
                        .build();

        // add incident to check outcome
        checkOutcomeToCreate.setIncidentsByCheckOutcomeUuid(
                getIncidentCollection(probableBanCheckOutcomeDetailsV1Inner, booking, checkOutcomeToCreate));
        return checkOutcomeToCreate;
    }


    private CheckOutcomeType getCheckOutComeType() {
        CheckOutcomeType checkOutcomeType = null;

        Optional<CheckOutcomeType> optionalCheckOutcomeType =
                checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.PROBABLE_BAN_CHECK_OUTCOME_TYPE_CODE);
        if (optionalCheckOutcomeType.isPresent()) {
            checkOutcomeType = optionalCheckOutcomeType.get();
        }
        return checkOutcomeType;
    }

    private CheckOutcomeStatus setCheckOutComeStatus(ProbableBanCheckOutcomeDetailsV1Inner probableBanCheckOutcomeDetailsV1Inner) {
        CheckOutcomeStatus checkOutcomeStatus = null;
        String checkOutcomeStatusValue =
                mapProbableBanOutcomeToCheckOutcome(
                        probableBanCheckOutcomeDetailsV1Inner.getOutcome());
        Optional<CheckOutcomeStatus> optionalCheckOutcomeStatus =
                checkOutcomeStatusRepository.findByCheckOutcomeStatusCode(checkOutcomeStatusValue);
        if (optionalCheckOutcomeStatus.isPresent()) {
            checkOutcomeStatus = optionalCheckOutcomeStatus.get();
        }
        return checkOutcomeStatus;
    }

    public String mapProbableBanOutcomeToCheckOutcome(String probableOutcome) {
        switch (probableOutcome) {
            case PROBABLE_BAN_OUTCOME_PASSED:
                return CHECK_OUTCOME_STATUS_CODE_PASSED;
            case PROBABLE_BAN_OUTCOME_FLAGGED:
                return CHECK_OUTCOME_STATUS_CODE_REVIEW;
            default:
                throw new ResultIntegrityException("Invalid Outcome");
        }
    }

    private List<Incident> getIncidentCollection(
            ProbableBanCheckOutcomeDetailsV1Inner probableBanCheckOutcomeDetailsV1Inner, Booking booking,
            CheckOutcome checkOutcome) {
        log.info("Display incident collection for ProbableBanCheckoutcomeHelper: getIncidentCollection()");

        List<Incident> probableBanIncidentList = new ArrayList<>();

        if (CollectionUtils.isNotEmpty(checkOutcome.getIncidentsByCheckOutcomeUuid())) {

            probableBanIncidentList.addAll(
                    checkOutcome.getIncidentsByCheckOutcomeUuid().stream()
                            .filter(
                                    incident ->
                                            INCIDENT_TYPE_CODE_PROBABLE_BAN.equals(
                                                    incident.getIncidentTypeByIncidentTypeUuid().getIncidentTypeCode()))
                            .collect(Collectors.toList()));

            probableBanIncidentList.forEach(
                    incident -> {
                        setIncidentStatusType(
                                incident,
                                probableBanCheckOutcomeDetailsV1Inner.getOutcome());
                        incident.setIncidentCommentsByIncidentUuid(new ArrayList<>());
                    });
            log.debug("Update probable ban incident list : {}", probableBanIncidentList.get(0).getIncidentUuid());
            getIncidentCommentCollection(probableBanCheckOutcomeDetailsV1Inner, probableBanIncidentList.get(0));
            return probableBanIncidentList;
        }

        probableBanIncidentList.add(
                setIncident(probableBanCheckOutcomeDetailsV1Inner, booking.getBookingUuid(), checkOutcome));
        return probableBanIncidentList;
    }



    private void setIncidentStatusType(Incident incident, String probableBanOutcome) {
        String incidentStatusTypeCode = mapProbableBanOutcomeToIncidentStatusType(probableBanOutcome, incident);
        Optional<IncidentStatusType> optionalIncidentStatusType =
                incidentStatusTypeRepository.findByIncidentStatusTypeCode(incidentStatusTypeCode);

        incident.setIncidentStatusTypeByIncidentStatusTypeUuid(optionalIncidentStatusType.orElse(null));
    }

    public String mapProbableBanOutcomeToIncidentStatusType(String probableBanOutcome, Incident incident) {
         switch (probableBanOutcome) {
            case PROBABLE_BAN_OUTCOME_PASSED:
                return INCIDENT_STATUS_TYPE_CODE_PASSED;
            case PROBABLE_BAN_OUTCOME_FLAGGED:
                return getIncidentStatusTypeCode(incident);
            default:
                throw new ResultIntegrityException("Invalid Incident Status");
        }
    }

    private String getIncidentStatusTypeCode(Incident incident) {
        Optional<Booking> optionalBooking = bookingRepository.findById(incident.getBookingUuid());
        if (optionalBooking.isPresent()) {
            return productIncidentMappingRepository
                    .findByProductUuidAndIncidentCategoryUuid(optionalBooking.get().getProductUuid(),
                            incident.getIncidentCategoryByIncidentCategoryUuid().getIncidentCategoryUuid())
                    .getIncidentStatusTypeCode();
        } else {
            log.info("Booking UUID {} is not yet present", incident.getBookingUuid());
            return INCIDENT_STATUS_TYPE_CODE_FLAGGED;
        }
    }

    private void getIncidentCommentCollection(
            ProbableBanCheckOutcomeDetailsV1Inner probableBanCheckOutcomeDetailsV1Inner, Incident incident) {
        incident.addIncidentComment(setIncidentComment(incident, probableBanCheckOutcomeDetailsV1Inner
                .getAdditionalRemarks()));

    }

    private IncidentComment setIncidentComment(Incident incident, String investigationComment) {
        return IncidentComment.builder()
                .incidentByIncidentUuid(incident)
                .incidentCommentText(investigationComment)
                .build();
    }

    private Incident setIncident(
            ProbableBanCheckOutcomeDetailsV1Inner probableBanCheckOutcomeDetailsV1Inner, UUID bookingUuid, CheckOutcome checkOutcome) {
        IncidentType incidentType = getIncidentType();

        Incident incidentToCreate =
                Incident.builder()
                        .incidentCategoryByIncidentCategoryUuid(
                                Objects.nonNull(incidentType)
                                        ? incidentType.getIncidentCategoryByIncidentCategoryUuid()
                                        : null)
                        .incidentTypeByIncidentTypeUuid(incidentType)
                        .bookingUuid(bookingUuid)
                        .checkOutcomeByCheckOutcomeUuid(checkOutcome)
                        .incidentCommentsByIncidentUuid(new ArrayList<>())
                        .eventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime())
                        .build();
        setIncidentStatusType(
                incidentToCreate,
                probableBanCheckOutcomeDetailsV1Inner.getOutcome());
        getIncidentCommentCollection(probableBanCheckOutcomeDetailsV1Inner, incidentToCreate);
        return incidentToCreate;
    }

    private IncidentType getIncidentType() {
        Optional<IncidentType> optionalIncidentType =
                incidentTypeRepository.findByIncidentTypeCode(
                        INCIDENT_TYPE_CODE_PROBABLE_BAN);
        return optionalIncidentType.orElse(null);
    }
}

