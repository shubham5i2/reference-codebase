package com.ielts.cmds.ri.infrastructure.config;

import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.HibernateValidator;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.validation.beanvalidation.SpringConstraintValidatorFactory;

import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.util.Map;

@Configuration
@PropertySource("classpath:errorCode.properties")
@ConfigurationProperties(prefix = "cmds")
@Getter
@Setter
public class ValidationConfig<T> {

  private Map<String, String> errorCode;

  public ValidationConfig(Map<String, String> errorCode) {
      this.errorCode = errorCode;
  }

  @Bean
  public Validator validator(final AutowireCapableBeanFactory autowireCapableBeanFactory) {

    ValidatorFactory validatorFactory =
        Validation.byProvider(HibernateValidator.class)
            .configure()
            .constraintValidatorFactory(
                new SpringConstraintValidatorFactory(autowireCapableBeanFactory))
            .buildValidatorFactory();
    return validatorFactory.getValidator();
  }

  @Bean
  public CMDSErrorResolver<T> errorResolver() {
    return new CMDSErrorResolver<>(errorCode);
  }
}
