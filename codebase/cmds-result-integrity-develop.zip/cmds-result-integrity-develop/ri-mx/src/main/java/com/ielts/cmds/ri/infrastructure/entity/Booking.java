package com.ielts.cmds.ri.infrastructure.entity;



import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.ToString;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import com.ielts.cmds.common.persistence.utils.CMDSOffsetDatetime;
import com.ielts.cmds.common.persistence.utils.CMDSOffsetDatetimeType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "booking")
@Builder
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@TypeDefs({
	  @TypeDef(defaultForType = CMDSOffsetDatetime.class, typeClass = CMDSOffsetDatetimeType.class)
	})
public class Booking extends CommonModel implements Serializable {

    private static final long serialVersionUID = 8195033501228455119L;

    @Id
    @Column(name = "booking_uuid")
    private UUID bookingUuid;

    @Column(name = "product_uuid")
    private UUID productUuid;

    @Column(name = "location_uuid")
    private UUID locationUuid;

    @AttributeOverrides({
        @AttributeOverride(name = "isoDateTime", column = @Column(name = "test_date_audit")),
        @AttributeOverride(name = "localDate", column = @Column(name = "test_date")),
        @AttributeOverride(name = "localOffset", column = @Column(name = "test_date_offset")),
        @AttributeOverride(name = "utcDateTime", column = @Column(name = "test_date_utc"))
    })
    @Embedded
    private CMDSOffsetDatetime testDate;

    @Column(name = "birth_date")
    private LocalDate birthDate;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "identity_number")
    private String identityNumber;

    @Column(name = "short_candidate_number")
    private Integer shortCandidateNumber;

    @Column(name = "unique_test_taker_uuid")
    private UUID uniqueTestTakerUuid;

    @ToString.Exclude
    @OneToMany(mappedBy = "booking", cascade = CascadeType.ALL)
    private List<BookingLine> bookingLines;

    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "unique_test_taker_uuid", referencedColumnName = "unique_test_taker_uuid", insertable = false, updatable = false)
    private UniqueTestTaker uniqueTestTaker;

    @Column(name = "booking_status")
    private String bookingStatus;

    @Column(name = "external_booking_uuid")
    private UUID externalBookingUuid;

    @Column(name = "composite_candidate_number")
    private String compositeCandidateNumber;

    @OneToMany(mappedBy = "sourceBookingUuid", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<BookingLink> bookingLinks;

    @Column(name = "booking_version")
    private BigDecimal bookingVersion;
    
    @Column(name = "event_datetime")
    private LocalDateTime eventDatetime;


}

