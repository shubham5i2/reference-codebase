package com.ielts.cmds.ri.domain.enums;

import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;

public enum IncidentSeverityEnum {
  INFO("INFO"),
  WARNING("WARNING"),
  CONFIRMED_MALPRACTICE("CONFIRMED_MALPRACTICE");

  private String value;

  IncidentSeverityEnum(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }

  @Override
  public String toString() {
    return String.valueOf(value);
  }

  public static IncidentSeverityEnum fromValue(String text) {
    for (IncidentSeverityEnum i : IncidentSeverityEnum.values()) {
      if (String.valueOf(i.value).equals(text)) {
        return i;
      }
    }
    return null;
  }

  public static class Adapter extends TypeAdapter<IncidentSeverityEnum> {
    @Override
    public void write(final JsonWriter jsonWriter, final IncidentSeverityEnum enumeration)
        throws IOException {
      jsonWriter.value(enumeration.getValue());
    }

    @Override
    public IncidentSeverityEnum read(final JsonReader jsonReader) throws IOException {
      String value = jsonReader.nextString();
      return IncidentSeverityEnum.fromValue(String.valueOf(value));
    }
  }

}
