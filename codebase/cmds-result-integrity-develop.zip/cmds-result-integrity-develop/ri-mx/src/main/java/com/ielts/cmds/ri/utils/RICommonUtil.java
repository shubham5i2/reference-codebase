package com.ielts.cmds.ri.utils;

import static com.ielts.cmds.ri.utils.RIConstants.PhotoTypeConstants.PHOTO_TYPE_TT_ID_HR_R_CODE;
import static com.ielts.cmds.ri.utils.RIConstants.PhotoTypeConstants.PHOTO_TYPE_TT_ID_LRW_WC_CODE;
import static com.ielts.cmds.ri.utils.RIConstants.PhotoTypeConstants.PHOTO_TYPE_TT_ID_S_WC_CODE;
import static com.ielts.cmds.ri.utils.RIConstants.PhotoTypeConstants.PHOTO_TYPE_TT_P_LR_S_WC_CODE;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;
import javax.validation.Path;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.validator.internal.engine.ConstraintViolationImpl;
import org.hibernate.validator.internal.engine.path.PathImpl;
import org.springframework.stereotype.Component;

import com.ielts.cmds.api.evt074.CommentDetailsV1;
import com.ielts.cmds.api.evt074.IncidentEvidenceV1Inner;
import com.ielts.cmds.api.evt074.ResultIntegrityIncidentDetailsV1;
import com.ielts.cmds.api.evt074.ResultIntegrityIncidentDetailsV1.IncidentSeverityEnum;
import com.ielts.cmds.api.evt074.ResultIntegrityIncidentDetailsWrapperV1;
import com.ielts.cmds.api.evt119.CheckOutcomeV1;
import com.ielts.cmds.api.evt119.IntegrityCheckInitiatedV1;
import com.ielts.cmds.common.DateTimeDeserializerUtil;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalErrorContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.rbac.api.service.LocationHierarchyService;
import com.ielts.cmds.rbac.api.service.RBACService;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.api.service.model.LocationNode;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.domain.enums.BookingLineStatusEnum;
import com.ielts.cmds.ri.domain.enums.BookingRoleEnum;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.BookingLine;
import com.ielts.cmds.ri.infrastructure.entity.BookingLink;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeType;
import com.ielts.cmds.ri.infrastructure.entity.Incident;
import com.ielts.cmds.ri.infrastructure.entity.ProductCheckOutcomeType;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.ProductCheckOutcomeTypeRepository;
import com.ielts.cmds.ri.utils.RIConstants.GenericConstants;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@RequiredArgsConstructor
public class RICommonUtil {

	private final BookingRepository bookingRepository;
	private final CheckOutcomeTypeRepository checkOutcomeTypeRepository;
	private final ProductCheckOutcomeTypeRepository productCheckOutcomeTypeRepository;
	private final LocationHierarchyService locationHierarchyService;
	private final RBACService rbacService;


	public boolean hasAllPermissions(String xAccessToken, String permissionId, String partner)
			throws RbacValidationException {
		return rbacService.isAuthorisedForPartner(xAccessToken, permissionId, partner);
	}

	public static Set<ConstraintViolation<Object>> getSetforNullViolationOfEventBody(
			final String interpolatedMessage, final String pathProperty) {

		Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
		final String messageTemplate = null;
		Path path = PathImpl.createPathFromString(pathProperty);
		final Map<String, Object> messageParameters = new HashMap<>();
		final Map<String, Object> expressionVariables = new HashMap<>();
		ConstraintViolation<Object> constraintViolationImpl =
				ConstraintViolationImpl.forBeanValidation(
						messageTemplate,
						messageParameters,
						expressionVariables,
						interpolatedMessage,
						null,
						null,
						null,
						null,
						path,
						null,
						null);

		violationSet.add(constraintViolationImpl);
		return violationSet;
	}

	public OffsetDateTime stringToOffsetDateTime(String dateTime) {
		if (org.apache.commons.lang3.StringUtils.isNotBlank(dateTime)) {
			LocalDateTime localDateTime = DateTimeDeserializerUtil.deserializeToLocalDateTime(dateTime);
			return OffsetDateTime.of(localDateTime, ZoneOffset.UTC);
		}
		return null;
	}

	public String externalIncidentStatus(String statusCode) {
		switch (statusCode) {
		case "FLAGGED":
			return RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_FAILED;
		case "PASSED":
			return RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_PASSED;
		case "FOLLOW_UP_REQUIRED":
			return RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_REVIEW;
		default:
			return null;
		}
	}

	public Booking getBookingFromExternalBookingUuId(UUID externalBookingUuId) {
		Booking booking = null;
		Optional<Booking> optionalBooking =
				bookingRepository.findByExternalBookingUuid(externalBookingUuId);
		if (optionalBooking.isPresent()) {
			booking = optionalBooking.get();
		}
		return booking;
	}

	public IntegrityCheckInitiatedV1 buildEvent(CheckOutcome checkOutcome) {
		CheckOutcomeV1 checkOutcomeV1 = new CheckOutcomeV1();
		IntegrityCheckInitiatedV1 integrityCheckInitiatedV1=new IntegrityCheckInitiatedV1();
		checkOutcomeV1.setCheckOutcomeStatusUuid(
				(checkOutcome.getCheckOutcomeStatus().getCheckOutcomeStatusUuid()));
		checkOutcomeV1.setCheckOutcomeTypeUuid(
				(checkOutcome.getCheckOutcomeType().getCheckOutcomeTypeUuid()));


		integrityCheckInitiatedV1.bookingUuid((checkOutcome.getBookingUuid()));
		integrityCheckInitiatedV1.checkOutcome(checkOutcomeV1);
		integrityCheckInitiatedV1.setBookingVersion(checkOutcome.getBookingVersion());

		return integrityCheckInitiatedV1;
	}

	public ResultIntegrityIncidentDetailsWrapperV1 populateIntegrityDetailsRaisedEvent(
			final Incident incident,Booking optionalBooking) {

		ResultIntegrityIncidentDetailsWrapperV1 resultIntegrityIncidentDetailsWrapperV1=new ResultIntegrityIncidentDetailsWrapperV1();
		ResultIntegrityIncidentDetailsV1 resultIntegrityIncidentDetailsV1=new ResultIntegrityIncidentDetailsV1();
		resultIntegrityIncidentDetailsV1.setBanReviewRequired(
				incident.getIncidentTypeByIncidentTypeUuid().getBanReviewRequired());
		resultIntegrityIncidentDetailsV1.setIncidentCategoryUuid(
				incident.getIncidentCategoryByIncidentCategoryUuid().getIncidentCategoryUuid());
		resultIntegrityIncidentDetailsV1.setComments(commentDetailsV1ArrayList(incident));
		resultIntegrityIncidentDetailsV1.setBookingUuid(incident.getBookingUuid());
		resultIntegrityIncidentDetailsV1.setIncidentSeverity(getUpdatedSeverity(incident));
		resultIntegrityIncidentDetailsV1.setIncidentStatusTypeUuid(
				incident
				.getIncidentStatusTypeByIncidentStatusTypeUuid()
				.getIncidentStatusTypeUuid());
		resultIntegrityIncidentDetailsV1.setIncidentTypeUuid(
				incident.getIncidentTypeByIncidentTypeUuid().getIncidentTypeUuid());
		resultIntegrityIncidentDetailsV1.setIncidentUuid(incident.getIncidentUuid() != null
				? incident.getIncidentUuid() : UUID.randomUUID());
		resultIntegrityIncidentDetailsV1.setBookingVersion(optionalBooking != null ? optionalBooking.getBookingVersion() : null );
		resultIntegrityIncidentDetailsWrapperV1.setIncidentDetails(resultIntegrityIncidentDetailsV1);
		return resultIntegrityIncidentDetailsWrapperV1;

	}

	public ResultIntegrityIncidentDetailsWrapperV1 populateIntegrityDetailsRaisedEventWithEvidence(
			final Incident incident) {

		ResultIntegrityIncidentDetailsWrapperV1 resultIntegrityIncidentDetailsWrapperV1=new ResultIntegrityIncidentDetailsWrapperV1();
		ResultIntegrityIncidentDetailsV1 resultIntegrityIncidentDetailsV1=new ResultIntegrityIncidentDetailsV1();
		resultIntegrityIncidentDetailsV1.setBookingUuid(incident.getBookingUuid());
		resultIntegrityIncidentDetailsV1.setIncidentSeverity(getUpdatedSeverity(incident));
		resultIntegrityIncidentDetailsV1.setIncidentTypeUuid(
				incident.getIncidentTypeByIncidentTypeUuid().getIncidentTypeUuid());
		resultIntegrityIncidentDetailsV1.setBanReviewRequired(
				incident.getIncidentTypeByIncidentTypeUuid().getBanReviewRequired());
		resultIntegrityIncidentDetailsV1.setComments(commentDetailsV1ArrayList(incident));
		resultIntegrityIncidentDetailsV1.setIncidentStatusTypeUuid(
				incident
				.getIncidentStatusTypeByIncidentStatusTypeUuid()
				.getIncidentStatusTypeUuid());
		resultIntegrityIncidentDetailsV1.setIncidentUuid(incident.getIncidentUuid() != null
				? incident.getIncidentUuid() : UUID.fromString(""));
		resultIntegrityIncidentDetailsV1.setIncidentCategoryUuid(
				incident.getIncidentCategoryByIncidentCategoryUuid() != null ? incident.getIncidentCategoryByIncidentCategoryUuid().getIncidentCategoryUuid() : null);
		resultIntegrityIncidentDetailsV1.setEvidences(evidenceDetailsV1ArrayList(incident));
		resultIntegrityIncidentDetailsV1.setBookingVersion(incident.getCheckOutcomeByCheckOutcomeUuid().getBookingVersion());
		resultIntegrityIncidentDetailsWrapperV1.setIncidentDetails(resultIntegrityIncidentDetailsV1);

		return resultIntegrityIncidentDetailsWrapperV1;
	}

	public IncidentSeverityEnum getUpdatedSeverity(Incident incident) {
		if (Objects.nonNull(incident.getIncidentSeverity())) {
			return IncidentSeverityEnum.valueOf(
					incident.getIncidentSeverity().getValue());
		}
		return null;
	}

	public List<CommentDetailsV1> commentDetailsV1ArrayList(final Incident incident) {
		List<CommentDetailsV1> commentDetailsV1List = new ArrayList<>();
		CommentDetailsV1 commentDetailsV1=new com.ielts.cmds.api.evt074.CommentDetailsV1();
		if (Objects.nonNull(incident.getIncidentCommentsByIncidentUuid())) {
			incident.getIncidentCommentsByIncidentUuid().stream()
			.collect(Collectors.toList())
			.forEach(
					item -> {
						commentDetailsV1.comment(item.getIncidentCommentText());
						commentDetailsV1.commentDateTime(item.getIncidentCommentDateTime() != null
								? item.getIncidentCommentDateTime()
										: null);
						commentDetailsV1.commentEnteredBy(item.getIncidentCommentEnteredBy());
						commentDetailsV1.userType(item.getIncidentCommentUserType() != null
								? com.ielts.cmds.api.evt074.CommentDetailsV1.UserTypeEnum.valueOf(item.getIncidentCommentUserType().getValue())
										: null);
						commentDetailsV1List.add(commentDetailsV1);
					}
					);
		}
		return commentDetailsV1List;
	}


	public void publishLog() {

		log.debug("message being published : [{}]", ThreadLocalHeaderContext.getContext().getEventName());

		if (ThreadLocalErrorContext.getContext() != null
				&& ThreadLocalErrorContext.getContext().getErrorList() != null
				&& !ThreadLocalErrorContext.getContext().getErrorList().isEmpty()) {

			log.info(
					"Event being Published from {} with metadata as {} and error as {}",
					GenericConstants.APP_NAME,
					ThreadLocalHeaderContext.getContext(),
					ThreadLocalErrorContext.getContext().getErrorList());

		} else {

			log.info(
					"Event being Published from {} with metadata as {}",
					GenericConstants.APP_NAME,
					ThreadLocalHeaderContext.getContext());
		}
	}

	public List<String> generateCheckOutcomeList(Booking booking) {
		List<String> checkOutcomeSet = new ArrayList<>();
		List<String> checkOutcomeTypeCodeList = new ArrayList<>();

		List<CheckOutcomeType> checkOutcomeTypeRepositoryByEligibleForIntegrityCheck =
				checkOutcomeTypeRepository.findByEligibleForIntegrityCheck(true);

		if (CollectionUtils.isNotEmpty(checkOutcomeTypeRepositoryByEligibleForIntegrityCheck)) {

			checkOutcomeTypeRepositoryByEligibleForIntegrityCheck.forEach(
					checkOutcomeType ->
					checkOutcomeSet.add(checkOutcomeType.getCheckOutcomeTypeCode()));
		}
		UUID productUuid = booking.getProductUuid();
		List<BookingLink> bookingLinkList = booking.getBookingLinks();
		if(Objects.nonNull(bookingLinkList) && bookingLinkList.stream().anyMatch(bookingLink ->
		bookingLink.getRole()==BookingRoleEnum.SSRORIGINAL)) {
			log.debug("Received booking is SSR {}",bookingLinkList.size());
			productUuid = getProductUuidForSSRBooking(booking);
		}

		List<ProductCheckOutcomeType> productCheckOutcomeTypeList = productCheckOutcomeTypeRepository
				.findByProductUuid(productUuid);

		if (CollectionUtils.isNotEmpty(productCheckOutcomeTypeList)) {
			productCheckOutcomeTypeList.forEach(p ->
			checkOutcomeTypeCodeList.add(p.getCheckOutcomeTypeCode()));

			log.debug("Product CheckoutCome type code list {}",checkOutcomeTypeCodeList);

			//check common checkOutcomeType
			return checkOutcomeTypeCodeList.stream().filter(checkOutcomeSet::contains)
					.collect(Collectors.toList());
		}
		return Collections.emptyList();

	}

	public List<String> getPhotoTypeConstantsList() {

		List<String> photoTypeConstantsList = new ArrayList<>();

		photoTypeConstantsList.add(PHOTO_TYPE_TT_ID_HR_R_CODE);
		photoTypeConstantsList.add(PHOTO_TYPE_TT_P_LR_S_WC_CODE);
		photoTypeConstantsList.add(PHOTO_TYPE_TT_ID_LRW_WC_CODE);
		photoTypeConstantsList.add(PHOTO_TYPE_TT_ID_S_WC_CODE);

		return photoTypeConstantsList;

	}

	public boolean hasAllAccess(String xAccessToken, String permissionId)
			throws RbacValidationException {
		return rbacService.isAuthorised(xAccessToken, permissionId);
	}

	public List<IncidentEvidenceV1Inner> evidenceDetailsV1ArrayList(final Incident incident) {
		List<IncidentEvidenceV1Inner> evidenceDetailsV1List = new ArrayList<>();
		IncidentEvidenceV1Inner incidentEvidenceV1Inner=new IncidentEvidenceV1Inner();
		if (Objects.nonNull(incident.getIncidentEvidencesByIncidentUuid())) {
			incident.getIncidentEvidencesByIncidentUuid().stream()
			.collect(Collectors.toList())
			.forEach(
					item -> {
						incidentEvidenceV1Inner.evidenceName(item.getIncidentEvidenceName());
						incidentEvidenceV1Inner.evidenceUrl(item.getIncidentEvidenceUrl());
						incidentEvidenceV1Inner.evidenceFileExtention(extractFileExtension(item.getIncidentEvidenceName()));
						evidenceDetailsV1List.add(incidentEvidenceV1Inner);
					}
					);
		}
		return evidenceDetailsV1List;
	}

	String extractFileExtension(String incidentEvidenceName) {

		return StringUtils.substringAfter(incidentEvidenceName, ".");
	}

	public Booking getBooking(Incident incident) {

		if (checkIfBookingIsPresent(incident)) {
			Optional<Booking> optionalBooking =
					bookingRepository.findById(incident.getBookingUuid());
			if (optionalBooking.isPresent()) {
				return optionalBooking.get();
			} else {
				throw new ResultIntegrityException("Booking not present for bookingUuid "
						+ incident.getBookingUuid());
			}
		} else {
			throw new ResultIntegrityException("Booking not present for incidentUuid "
					+ incident.getIncidentUuid());
		}
	}

	public boolean checkIfBookingIsPresent(Incident incident) {
		return Objects.nonNull(incident.getBookingUuid());
	}

	public LocationNode getParentNode(UUID locationUuid, String locationType)
			throws RbacValidationException {
		LocationNode locationNode=locationHierarchyService.getLocationBranchByLocationUuid(locationUuid);
		LocationNode parentNode=locationNode.getParent();
		if(Objects.nonNull(parentNode)) {
			if(locationType.equals(parentNode.getLocationType())){
				return parentNode;
			}else{
				return getParentNode(parentNode.getLocationUuid(),locationType);
			}
		}
		return locationNode;
	}

	private UUID getProductUuidForSSRBooking(Booking booking) {

		List<BookingLine> bookingLines = booking
				.getBookingLines();
		BookingLine activeBookingLine = bookingLines.stream()
				.filter(bookingLine1 -> bookingLine1.getBookingLineStatus()==BookingLineStatusEnum.ACTIVE)
				.collect(Collectors.toList()).get(0);
		log.info("Active booking line uuid {} ",activeBookingLine.getBookingLineUuid());
		return activeBookingLine.getProductUuid();
	}
}
