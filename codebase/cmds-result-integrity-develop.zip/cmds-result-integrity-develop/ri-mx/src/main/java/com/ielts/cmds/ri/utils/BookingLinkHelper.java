package com.ielts.cmds.ri.utils;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.ielts.cmds.booking.common.out.model.BookingDetails;
import com.ielts.cmds.ri.domain.enums.BookingRoleEnum;
import com.ielts.cmds.ri.infrastructure.entity.BookingLink;

@Component
public class BookingLinkHelper {

    public List<BookingLink> updateBookingLinkDetails(
            UUID bookingUuid, BookingDetails bookingDetails) {
        return bookingDetails.getBookingLinks().stream()
                .map(bookingLink1 -> getBookingLink(bookingUuid, bookingLink1))
                .collect(Collectors.toList());
    }

    private BookingLink getBookingLink
            (UUID bookingUuid,com.ielts.cmds.booking.common.out.model.BookingLink bookingLink1) {

        BookingLink bookingLinkToCreate = new BookingLink();
        bookingLinkToCreate.setSourceBookingUuid(bookingUuid);
        bookingLinkToCreate.setRole(BookingRoleEnum.valueOf(bookingLink1.getRole().getValue()));
        bookingLinkToCreate.setTargetBookingUuid(bookingLink1.getLinkedBooking().getBookingUuid());

        return bookingLinkToCreate;
    }
}
