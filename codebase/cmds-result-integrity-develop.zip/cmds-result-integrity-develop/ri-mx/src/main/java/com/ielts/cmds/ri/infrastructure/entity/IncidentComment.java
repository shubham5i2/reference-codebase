package com.ielts.cmds.ri.infrastructure.entity;

import java.time.OffsetDateTime;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.ielts.cmds.ri.domain.enums.IncidentCommentUserTypeEnum;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "incident_comment")
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IncidentComment extends CommonModel {

  @Id
  @GeneratedValue(generator = "UUID")
  @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
  @Column(name = "incident_comment_uuid")
  private UUID incidentCommentUuid;

  @Column(name = "incident_comment_text")
  private String incidentCommentText;

  @Column(name = "incident_comment_date_time")
  private OffsetDateTime incidentCommentDateTime;

  @Column(name = "incident_comment_entered_by")
  private String incidentCommentEnteredBy;

  @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
  @JoinColumn(name = "incident_uuid", referencedColumnName = "incident_uuid", nullable = false)
  private Incident incidentByIncidentUuid;

  @Column(name = "incident_uuid",insertable = false, updatable = false)
  private UUID incidentUuid;

  @Enumerated(EnumType.STRING)
  @Column(name = "incident_comment_user_type")
  private IncidentCommentUserTypeEnum incidentCommentUserType;

  @Column(name = "external_comment_uuid")
  private UUID externalCommentUuid;
}

