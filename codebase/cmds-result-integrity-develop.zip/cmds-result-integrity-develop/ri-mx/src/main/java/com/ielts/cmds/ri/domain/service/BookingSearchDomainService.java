package com.ielts.cmds.ri.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.context.CMDSErrorContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalErrorContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.common.model.out.BookingSearchCriteriaV1;
import com.ielts.cmds.ri.common.model.out.BookingSearchResultListV1;
import com.ielts.cmds.ri.common.model.out.BookingSearchResultListV1Inner;
import com.ielts.cmds.ri.common.model.out.BookingSearchResultV1;
import com.ielts.cmds.ri.common.model.out.BookingSearchResultV1Result;
import com.ielts.cmds.ri.common.model.out.CheckOutcomeV1;
import com.ielts.cmds.ri.common.model.out.SearchBookingRequestV1;
import com.ielts.cmds.ri.common.model.out.SearchPaginationV1;
import com.ielts.cmds.ri.common.model.out.SearchSortV1;
import com.ielts.cmds.ri.common.model.out.SearchSortV1Item;
import com.ielts.cmds.ri.infrastructure.entity.BookingCheckOutcomeView;
import com.ielts.cmds.ri.infrastructure.repository.BookingCheckOutcomeViewRepository;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.validation.ConstraintViolation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import static com.ielts.cmds.ri.utils.RIConstants.PermissionId.RI_BOOKING_SEARCH;

/**
 * The type Booking search domain service.
 */
@Slf4j
@Service
public class BookingSearchDomainService extends AbstractCMDSDomainService<BookingSearchResultV1> {

    private final BookingCheckOutcomeViewRepository bookingCheckOutcomeViewRepository;

    private final CMDSErrorResolver<Object> errorResolver;

    private final RICommonUtil commonUtils;

    @Autowired
    public BookingSearchDomainService(ApplicationEventPublisher publisher,
                                      ObjectMapper objectMapper,
                                      @Value("${bookingSearchResult.v2}") String isV2Enabled,
                                      CMDSThreadLocalContextService cmdsThreadLocalContextService,
                                      BookingCheckOutcomeViewRepository bookingCheckOutcomeViewRepository,
                                      CMDSErrorResolver<Object> errorResolver,
                                      RICommonUtil commonUtils) {
        super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
        this.bookingCheckOutcomeViewRepository = bookingCheckOutcomeViewRepository;
        this.errorResolver = errorResolver;
        this.commonUtils = commonUtils;
    }

    /**
     * On command.
     *
     * @param searchBookings the search booking
     */
    @Transactional(noRollbackFor = RuntimeException.class, propagation = Propagation.REQUIRES_NEW)
    public void on(final SearchBookingRequestV1 searchBookings)
            throws RbacValidationException, JsonProcessingException {

        log.debug("BookingTestTakerSearchDomainService.onCommand : {}", searchBookings);
        // check if role has permission to access
        if (!commonUtils.hasAllPermissions(
                ThreadLocalHeaderContext.getContext().getXaccessToken(),
                RI_BOOKING_SEARCH,
                ThreadLocalHeaderContext.getContext().getPartnerCode())) {
            log.info(
                    "You are not authorised to access this screen. Please contact your administer if you do not think this correct. ");
            Set<ConstraintViolation<Object>> violations =
                    RICommonUtil.getSetforNullViolationOfEventBody("V00012", "unauthorisedToViewBooking");
            publishEventToOutBoundTopic(null, violations);
        } else {
            Pageable pageObj =
                    PageRequest.of(
                            searchBookings.getPagination().getPageNumber(),
                            searchBookings.getPagination().getPageSize(),
                            Sort.by(getSortDirection(searchBookings.getSorting())));

            Specification<BookingCheckOutcomeView> bookingSpecification = getSpecification(searchBookings);

            Page<BookingCheckOutcomeView> bookingPage = bookingCheckOutcomeViewRepository.findAll(bookingSpecification, pageObj);

            BookingSearchResultV1 bookingSearchResultResponse =
                    mapBookingToSearchBookingEvent(searchBookings, bookingPage.getContent(), bookingPage.getTotalElements());

            publishEventToOutBoundTopic(bookingSearchResultResponse, null);
        }
    }

    /**
     * Publish event to out bound topic.
     *
     * @param bookingSearchResultResponse the booking search result response
     * @param violations                  the violations
     */
    public void publishEventToOutBoundTopic(
            final BookingSearchResultV1 bookingSearchResultResponse,
            final Set<ConstraintViolation<Object>> violations) {

        ThreadLocalHeaderContext.getContext().setEventName(RIConstants.EventType.BOOKING_SEARCH_RESPONSE_GENERATED);
        ThreadLocalHeaderContext.getContext().setEventDateTime(LocalDateTime.now());
        log.info("BookingSearchDomainService for publishEventToOutBoundTopic event name: {}", ThreadLocalHeaderContext.getContext().getEventName());

        if (Objects.nonNull(bookingSearchResultResponse)) {
            commonUtils.publishLog();
            publishEvent(bookingSearchResultResponse);
        } else {
            if (CollectionUtils.isNotEmpty(violations)) {
                CMDSErrorResponse eventErrors = errorResolver.populatErrorResponse(violations, ThreadLocalHeaderContext.getContext().getEventName());
                CMDSErrorContext errorContext = new CMDSErrorContext(eventErrors.getErrorList());
                ThreadLocalErrorContext.setContext(errorContext);
            }
            commonUtils.publishLog();
            publishEvent(bookingSearchResultResponse,ThreadLocalErrorContext.getContext().getErrorList());
        }
    }

    private BookingSearchResultV1 mapBookingToSearchBookingEvent(
            final SearchBookingRequestV1 searchBookingRequestV1,
            final List<BookingCheckOutcomeView> bookingList,
            final long totalNumberOfRecords) {

        BookingSearchResultV1Result entries = new BookingSearchResultV1Result();

        SearchBookingRequestV1 searchRequestV1 =
                SearchBookingRequestV1.builder()
                        .criteria(getUserSearchRequestCriteria(searchBookingRequestV1))
                        .pagination(getSearchPaginationV1(searchBookingRequestV1))
                        .sorting(getSearchSorting(searchBookingRequestV1))
                        .build();

        BookingSearchResultListV1 resultListV1 = setBookingEntries(bookingList);

        entries.setTotalCount(String.valueOf((totalNumberOfRecords)));
        entries.setEntries(resultListV1);

        return BookingSearchResultV1.builder().result(entries).search(searchRequestV1).build();
    }

    private BookingSearchResultListV1 setBookingEntries(
            final List<BookingCheckOutcomeView> bookingList) {
        BookingSearchResultListV1 bookingSearchResultListV1 = new BookingSearchResultListV1();

        for (BookingCheckOutcomeView booking : bookingList) {
            BookingSearchResultListV1Inner resultList = new BookingSearchResultListV1Inner();

            resultList.setBirthDate(booking.getBirthDate());
            resultList.setBookingUuid(booking.getBookingUuid());
            resultList.setFirstName(booking.getFirstName());
            resultList.setIdentityNumber(booking.getIdentityNumber());
            resultList.setLastName(booking.getLastName());
            resultList.setTestDate(booking.getTestDate());
            resultList.setShortCandidateNumber(String.valueOf(booking.getShortCandidateNumber()));
            resultList.setUniqueTestTakerId(booking.getUniqueTestTakerId());
            resultList.setCentreId(booking.getCentreId());
            resultList.setCheckOutcome(getCheckOutCome(booking));

            bookingSearchResultListV1.add(resultList);
        }
        return bookingSearchResultListV1;
    }

    private CheckOutcomeV1 getCheckOutCome(BookingCheckOutcomeView outcomeView) {
        CheckOutcomeV1 checkOutcomeV1 = new CheckOutcomeV1();
        checkOutcomeV1.setCheckOutcomeStatusUuid(outcomeView.getCheckOutcomeStatusUuid());
        checkOutcomeV1.setCheckOutcomeTypeUuid(outcomeView.getCheckOutcomeTypeUuid());
        return checkOutcomeV1;
    }

    private SearchSortV1 getSearchSorting(final SearchBookingRequestV1 searchBooking) {
        SearchSortV1 searchSort = new SearchSortV1();
        for (SearchSortV1Item sortItem : searchBooking.getSorting()) {
            SearchSortV1Item searchSortItemV1 =
                    SearchSortV1Item.builder()
                            .sortBy(sortItem.getSortBy())
                            .sortType(sortItem.getSortType())
                            .build();
            searchSort.add(searchSortItemV1);
        }
        return searchSort;
    }

    private SearchPaginationV1 getSearchPaginationV1(final SearchBookingRequestV1 searchBooking) {

        return SearchPaginationV1.builder()
                .pageNumber(searchBooking.getPagination().getPageNumber())
                .pageSize(searchBooking.getPagination().getPageSize())
                .build();
    }

    private BookingSearchCriteriaV1 getUserSearchRequestCriteria(
            final SearchBookingRequestV1 searchBooking) {
        return BookingSearchCriteriaV1.builder()
                .birthDate(searchBooking.getCriteria().getBirthDate())
                .firstName(searchBooking.getCriteria().getFirstName())
                .lastName(searchBooking.getCriteria().getLastName())
                .identityNumber(searchBooking.getCriteria().getIdentityNumber())
                .uniqueTestTakerId(searchBooking.getCriteria().getUniqueTestTakerId())
                .testDate(searchBooking.getCriteria().getTestDate())
                .shortCandidateNumber(searchBooking.getCriteria().getShortCandidateNumber())
                .centreId(searchBooking.getCriteria().getCentreId())
                .checkOutcome(searchBooking.getCriteria().getCheckOutcome())
                .build();
    }

    /**
     * Gets sort direction.
     *
     * @param searchSortItem the search sort item
     * @return the sort direction
     */
    public List<Sort.Order> getSortDirection(final SearchSortV1 searchSortItem) {
        List<Sort.Order> sorts = new ArrayList<>();
        for (SearchSortV1Item sortItem : searchSortItem) {
            if ("asc".equalsIgnoreCase(sortItem.getSortType())) {
                sorts.add(new Sort.Order(Sort.Direction.ASC, sortItem.getSortBy()));
            } else if ("desc".equalsIgnoreCase(sortItem.getSortType())) {
                sorts.add(new Sort.Order(Sort.Direction.DESC, sortItem.getSortBy()));
            }else {
            	log.debug("Improper input");
            }
        }
        return sorts;
    }

    /**
     * Gets specification.
     *
     * @param searchBooking the search booking
     * @return the specification
     */
    public Specification<BookingCheckOutcomeView> getSpecification(final SearchBookingRequestV1 searchBooking) {

        return (root, criteriaQuery, criteriaBuilder) -> {
            BookingSearchCriteriaV1 searchCriteria = searchBooking.getCriteria();
            List<Predicate> predicates = new ArrayList<>();
            Method[] declaredMethods = searchCriteria.getClass().getDeclaredMethods();
            for (Method method : declaredMethods) {
                if (StringUtils.startsWith(method.getName(), "get")
                        && !StringUtils.contains(method.getName(), "getCheckOutcome")) {
                    try {
                        Object value = method.invoke(searchCriteria);

                        buildCriteria(predicates, criteriaBuilder, root, value, method);
                    } catch (IllegalAccessException
                             | IllegalArgumentException
                             | InvocationTargetException ex) {
                        log.error("Error in method invocation", ex);
                        throw new ResultIntegrityException("Exception  {}" + ex);
                    }
                }
            }

            predicates.add(
                    criteriaBuilder.and(
                            criteriaBuilder.equal(
                                    root.get("checkOutcomeTypeUuid"),
                                    searchCriteria.getCheckOutcome().getCheckOutcomeTypeUuid()),
                            criteriaBuilder.equal(
                                    root.get("checkOutcomeStatusUuid"),
                                    searchCriteria.getCheckOutcome().getCheckOutcomeStatusUuid())));

            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        };
    }

    private List<Predicate> buildCriteria(
            List<Predicate> predicates,
            CriteriaBuilder criteriaBuilder,
            Root<BookingCheckOutcomeView> root,
            Object value,
            Method method) {

        if (!ObjectUtils.isEmpty(value)) {
            String name = StringUtils.substringAfter(method.getName(), "get");
            String fieldName = name.substring(0, 1).toLowerCase().concat(name.substring(1));

            if (StringUtils.equals(fieldName, "shortCandidateNumber")) {
                value = Integer.valueOf(String.valueOf(value));
            }

            if (value instanceof String) {
                predicates.add(
                        criteriaBuilder.and(
                                criteriaBuilder.equal(
                                        (criteriaBuilder.lower(root.get(fieldName))),
                                        String.valueOf(value).toLowerCase())));

            } else {
                predicates.add(criteriaBuilder.and(criteriaBuilder.equal((root.get(fieldName)), value)));
            }
        }
        return predicates;
    }
}
