package com.ielts.cmds.ri.domain.service;

import static com.ielts.cmds.ri.utils.RIConstants.IncidentStatusConstants.DISMISSED;
import static com.ielts.cmds.ri.utils.RIConstants.IncidentStatusConstants.PASSED;
import static com.ielts.cmds.ri.utils.RIConstants.IncidentStatusConstants.REFERRED;
import static com.ielts.cmds.ri.utils.RIConstants.PermissionId.RI_BOOKING_PRCOUTCOME;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_CLEARED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_REFER;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import javax.validation.ConstraintViolation;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.evt119.CheckOutcomeV1;
import com.ielts.cmds.api.evt119.IntegrityCheckInitiatedV1;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.context.CMDSErrorContext;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalErrorContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.common.model.out.PrcOutcomeV1;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeType;
import com.ielts.cmds.ri.infrastructure.entity.Incident;
import com.ielts.cmds.ri.infrastructure.entity.IncidentStatusType;
import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.UniqueTestTaker;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentStatusTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.UniqueTestTakerRepository;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;
import com.ielts.cmds.serialization.domain.EnableOutboundEventV2;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@EnableOutboundEventV2
public class PrcOutcomeReceivedDomainService extends AbstractCMDSDomainService<Object> {

   private final BookingRepository bookingRepository;
   private final CheckOutcomeRepository checkOutcomeRepository;
   private final CheckOutcomeStatusRepository checkOutcomeStatusRepository;
   private final CheckOutcomeTypeRepository checkOutcomeTypeRepository;
   private final UniqueTestTakerRepository uniqueTestTakerRepository;
   private final OutcomeStatusRepository outcomeStatusRepository;
   private final IncidentStatusTypeRepository incidentStatusTypeRepository;
   private final IncidentRepository incidentRepository;
   private final RICommonUtil commonUtils;
   private final CMDSErrorResolver<Object> errorResolver;

    @Autowired
    public PrcOutcomeReceivedDomainService(ApplicationEventPublisher publisher,
                                         ObjectMapper objectMapper,
                                         @Value("${prcOutcomeReceived.v2}") String isV2Enabled,
                                         CMDSThreadLocalContextService cmdsThreadLocalContextService,
                                         BookingRepository bookingRepository,
                                         CheckOutcomeRepository checkOutcomeRepository,
                                         CheckOutcomeStatusRepository checkOutcomeStatusRepository,
                                         CheckOutcomeTypeRepository checkOutcomeTypeRepository,
                                         UniqueTestTakerRepository uniqueTestTakerRepository,
                                         OutcomeStatusRepository outcomeStatusRepository,
                                         IncidentStatusTypeRepository incidentStatusTypeRepository,
                                         IncidentRepository incidentRepository,
                                         RICommonUtil commonUtils,
                                         CMDSErrorResolver<Object> errorResolver) {
    super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
    this.bookingRepository = bookingRepository;
    this.checkOutcomeRepository = checkOutcomeRepository;
    this.checkOutcomeStatusRepository = checkOutcomeStatusRepository;
    this.checkOutcomeTypeRepository = checkOutcomeTypeRepository;
    this.uniqueTestTakerRepository = uniqueTestTakerRepository;
    this.outcomeStatusRepository = outcomeStatusRepository;
    this.incidentStatusTypeRepository = incidentStatusTypeRepository;
    this.incidentRepository = incidentRepository;
    this.commonUtils = commonUtils;
    this.errorResolver = errorResolver;
  }

  @SneakyThrows
  @Transactional
  public void on(final PrcOutcomeV1 prcOutcomeReceived) {
    log.debug("PrcOutcomeReceivedDomainService| on | PrcOutcomeV1:{}", prcOutcomeReceived);
    CMDSHeaderContext initHeader = ThreadLocalHeaderContext.getContext();
    if (!commonUtils.hasAllPermissions(
        ThreadLocalHeaderContext.getContext().getXaccessToken(),
        RI_BOOKING_PRCOUTCOME,
        ThreadLocalHeaderContext.getContext().getPartnerCode())) {
      log.info("You do not have permission to update Prc Outcome.");
      Set<ConstraintViolation<Object>> violations =
          RICommonUtil.getSetforNullViolationOfEventBody(
              "V00013", "unauthorisedToUpdatePrcOutcome");
      publishUiEvent(null, violations, initHeader);

    } else if (CollectionUtils.isEmpty(prcOutcomeReceived.getBookingUuidList())) {
      log.info("You must select at least one Test Taker for this action");
      Set<ConstraintViolation<Object>> violations =
          RICommonUtil.getSetforNullViolationOfEventBody("V00014", "bookingSelectionList");
      publishUiEvent(null, violations, initHeader);

    } else {
      prcOutcomeReceived
          .getBookingUuidList()
          .forEach(
              booking -> {
                try {
                  Optional<Booking> optionalBooking = bookingRepository.findById(UUID.fromString(booking));
                  if (!optionalBooking.isPresent()) {
                    optionalBooking =
                        Optional.of(
                            Booking.builder().bookingUuid(UUID.fromString(booking)).build());
                  }
                  CheckOutcome checkOutcome = updateCheckOutcome(prcOutcomeReceived, optionalBooking.get());
                  IntegrityCheckInitiatedV1 integrityCheckInitiatedV1 = populateIntegrityCheckEvent(checkOutcome);
                  setIncidentStatusType(checkOutcome,prcOutcomeReceived);
                  buildHeader();
                  commonUtils.publishLog();
                  publishEvent(integrityCheckInitiatedV1);
                } catch (ResultIntegrityException e) {
                  log.error("PrcOutcomeReceivedCommand execution failed", e);
                  throw new ResultIntegrityException("PrcOutcomeReceivedCommand execution failed : " + e);
                }
              });
      String eventBody = "Success";
      publishUiEvent(eventBody, null, initHeader);
    }
  }

  IntegrityCheckInitiatedV1 populateIntegrityCheckEvent(final CheckOutcome checkOutcome) {
      IntegrityCheckInitiatedV1 integrityCheckInitiatedV1=new IntegrityCheckInitiatedV1();

      integrityCheckInitiatedV1.bookingUuid((checkOutcome.getBookingUuid()));
      integrityCheckInitiatedV1.checkOutcome(buildCheckOutcomeV1(checkOutcome));
      integrityCheckInitiatedV1.setBookingVersion(checkOutcome.getBookingVersion());
      return integrityCheckInitiatedV1;
  }

  private CheckOutcomeV1 buildCheckOutcomeV1(CheckOutcome checkOutcome) {
    CheckOutcomeV1 checkOutcomeV1 = new CheckOutcomeV1();
    checkOutcomeV1.setCheckOutcomeStatusUuid(
           checkOutcome.getCheckOutcomeStatus().getCheckOutcomeStatusUuid());
    checkOutcomeV1.setCheckOutcomeTypeUuid(
            checkOutcome.getCheckOutcomeType().getCheckOutcomeTypeUuid());
    return checkOutcomeV1;
  }

  public void publishUiEvent(
      String eventBody,
      Set<ConstraintViolation<Object>> violations,
      CMDSHeaderContext initHeader) {
    ThreadLocalHeaderContext.setContext(initHeader);
    log.info("publishUiEvent: {}", ThreadLocalHeaderContext.getContext().getEventName());
    if (Objects.nonNull(eventBody)) {
      publishEvent(eventBody);
    } else {
      if (CollectionUtils.isNotEmpty(violations)) {
        CMDSErrorResponse eventErrors =
            errorResolver.populatErrorResponse(
                violations, ThreadLocalHeaderContext.getContext().getEventName());
        ThreadLocalErrorContext.setContext(new CMDSErrorContext(eventErrors.getErrorList()));
        publishEvent(eventBody, ThreadLocalErrorContext.getContext().getErrorList());
      }
    }
  }

  public CheckOutcome updateCheckOutcome(PrcOutcomeV1 prcOutcomeReceived, Booking booking) {
    log.debug("Update PRC outcome updatePrcOutcome(): {}", prcOutcomeReceived);
    CheckOutcome checkOutcome;
    Optional<UniqueTestTaker> optionalUniqueTestTaker =
        uniqueTestTakerRepository.findByUniqueTestTakerUuid(booking.getUniqueTestTakerUuid());
    booking.setUniqueTestTaker(optionalUniqueTestTaker.orElse(null));
    checkOutcome = checkOutcomeRepository.save(setCheckOutcome(prcOutcomeReceived, booking));
    Optional<OutcomeStatus> optionalOutcomeStatus = outcomeStatusRepository
        .findByBookingUuid(booking.getBookingUuid());
    OutcomeStatus outcomeStatus = optionalOutcomeStatus.orElseGet(() -> OutcomeStatus.builder().build());
    outcomeStatus.setBookingVersion(checkOutcome.getBookingVersion());
    outcomeStatusRepository.save(outcomeStatus);
    return checkOutcome;
  }

  private CheckOutcome setCheckOutcome(PrcOutcomeV1 prcOutcomeReceived, Booking booking) {
    CheckOutcome checkOutcome;
    CheckOutcomeType checkOutcomeType = getCheckOutComeType();
    Optional<CheckOutcome> optionalCheckOutcome =
        checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
            booking.getBookingUuid(), Optional.ofNullable(checkOutcomeType).map(CheckOutcomeType::getCheckOutcomeTypeUuid).orElse(null));
    checkOutcome =
        optionalCheckOutcome.orElseGet(
            () ->
                CheckOutcome.builder()
                    .checkOutcomeStatus(
                        getCheckOutComeStatus(prcOutcomeReceived))
                    .checkOutcomeType(getCheckOutComeType())
                    .bookingUuid(booking.getBookingUuid())
                        .bookingVersion(booking.getBookingVersion())
                        .eventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime())
                    .build());
    if (optionalCheckOutcome.isPresent()) {
      checkOutcome.setCheckOutcomeStatus(
          getCheckOutComeStatus(prcOutcomeReceived));
      checkOutcome.setCheckOutcomeType(getCheckOutComeType());
      checkOutcome.setBookingUuid(booking.getBookingUuid());
      checkOutcome.setBookingVersion(booking.getBookingVersion());
      checkOutcome.setEventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime());
    }
    return checkOutcome;
  }

  private CheckOutcomeStatus getCheckOutComeStatus(PrcOutcomeV1 prcOutcomeReceived) {
    CheckOutcomeStatus checkOutcomeStatus = null;
    Optional<CheckOutcomeStatus> optionalCheckOutcomeStatus =
        checkOutcomeStatusRepository.findById(
            UUID.fromString(prcOutcomeReceived.getCheckOutcomeStatusUuid()));
    if (optionalCheckOutcomeStatus.isPresent()) {
      checkOutcomeStatus = optionalCheckOutcomeStatus.get();
    }
    return checkOutcomeStatus;
  }

  private CheckOutcomeType getCheckOutComeType() {
    CheckOutcomeType checkOutcomeType = null;
    Optional<CheckOutcomeType> optionalCheckOutcomeStatus =
        checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(
            RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_TYPE_CODE);
    if (optionalCheckOutcomeStatus.isPresent()) {
      checkOutcomeType = optionalCheckOutcomeStatus.get();
    }
    return checkOutcomeType;
  }

  private void buildHeader() {
    CMDSHeaderContext eventHeader = ThreadLocalHeaderContext.getContext();
    eventHeader.setEventDateTime(LocalDateTime.now(ZoneOffset.UTC));
    eventHeader.setEventName(RIConstants.EventType.INTEGRITY_CHECK_INITIATED);
    ThreadLocalHeaderContext.clearContext();
    ThreadLocalHeaderContext.setContext(eventHeader);
  }

  private void setIncidentStatusType(CheckOutcome checkOutcome,PrcOutcomeV1 prcOutcomeReceived)
  {
    CheckOutcomeStatus checkOutcomeStatus = getCheckOutComeStatus(prcOutcomeReceived);
    List<Incident> incidentList = incidentRepository
        .findByCheckOutcomeByCheckOutcomeUuid(checkOutcome);
    incidentList.stream().forEach(incident -> {
      if (checkOutcomeStatus.getCheckOutcomeStatusCode().equals(CHECK_OUTCOME_STATUS_CODE_REFER) &&
              (!StringUtils.equals(incident.getIncidentStatusTypeByIncidentStatusTypeUuid().getIncidentStatusTypeCode(), PASSED)))
      {
          Optional<IncidentStatusType> optionalIncidentStatusType =
                  incidentStatusTypeRepository.findByIncidentStatusTypeCode(REFERRED);
          incident.setIncidentStatusTypeByIncidentStatusTypeUuid
                  (optionalIncidentStatusType.orElse(null));
      }
      if (checkOutcomeStatus.getCheckOutcomeStatusCode().equals(CHECK_OUTCOME_STATUS_CODE_CLEARED) &&
        (!StringUtils.equals(incident.getIncidentStatusTypeByIncidentStatusTypeUuid().getIncidentStatusTypeCode(), PASSED)))
      {
          Optional<IncidentStatusType> optionalIncidentStatusType =
                  incidentStatusTypeRepository.findByIncidentStatusTypeCode(DISMISSED);
          incident.setIncidentStatusTypeByIncidentStatusTypeUuid
                  (optionalIncidentStatusType.orElse(null));
      }
    });
  }
}
