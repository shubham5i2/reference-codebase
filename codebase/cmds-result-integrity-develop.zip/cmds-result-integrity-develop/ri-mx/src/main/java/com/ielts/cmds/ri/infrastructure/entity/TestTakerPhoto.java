package com.ielts.cmds.ri.infrastructure.entity;

import java.time.LocalDateTime;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ielts.cmds.ri.domain.enums.PhotoCategoryEnum;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "test_taker_photo")
public class TestTakerPhoto extends CommonModel {

  @Id
  @Column(name = "photo_uuid")
  private UUID photoUuid;

  @Column(name = "booking_uuid")
  private UUID bookingUuid;

  @Column(name = "photo_type_uuid")
  private UUID photoTypeUuid;

  @Column(name = "photo_path")
  private String photoPath;

  @Column(name = "photo_version")
  private Integer photoVersion;

  @Enumerated(EnumType.STRING)
  @Column(name = "photo_category")
  private PhotoCategoryEnum photoCategory;
  
  @Column(name = "event_datetime")
  private LocalDateTime eventDatetime;



}