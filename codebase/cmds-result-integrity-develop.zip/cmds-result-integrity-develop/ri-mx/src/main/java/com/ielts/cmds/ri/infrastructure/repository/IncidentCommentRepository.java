package com.ielts.cmds.ri.infrastructure.repository;

import com.ielts.cmds.ri.infrastructure.entity.IncidentComment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface IncidentCommentRepository extends JpaRepository<IncidentComment, UUID> {

  List<IncidentComment> findByIncidentUuid(UUID incidentUuid);
  List<IncidentComment> findByIncidentUuidOrderByUpdatedDateTimeDesc(UUID incidentUuid);
  Optional<IncidentComment> findByExternalCommentUuid(UUID externalCommentUuid);
}
