package com.ielts.cmds.ri.domain.service;

import static com.ielts.cmds.ri.utils.RIConstants.EventType.RESULT_INTEGRITY_LOCATION_CONSUMED;
import static com.ielts.cmds.ri.utils.RIConstants.EventType.RESULT_INTEGRITY_LOCATION_REJECTED;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import javax.validation.ConstraintViolation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.lpr.common.out.model.LocationV1;
import com.ielts.cmds.ri.application.exception.ResultIntegrityValidationException;
import com.ielts.cmds.ri.common.model.out.ResultIntegrityLocationConsumedV1;
import com.ielts.cmds.ri.infrastructure.entity.Location;
import com.ielts.cmds.ri.infrastructure.repository.LocationRepository;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;
import com.ielts.cmds.serialization.domain.EnableOutboundEventV2;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@EnableOutboundEventV2
public class LocationChangedDomainService extends AbstractCMDSDomainService<ResultIntegrityLocationConsumedV1> {
	private final LocationRepository locationRepository;
	private final CMDSErrorResolver<Object> errorResolver;

	@Autowired
	public LocationChangedDomainService(ApplicationEventPublisher publisher, CMDSErrorResolver<Object> errorResolver, ObjectMapper objectMapper,
			@Value("${locationChanged.v2}") String isV2Enabled,
			CMDSThreadLocalContextService cmdsThreadLocalContextService,
			LocationRepository locationRepository) {
		super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
		this.locationRepository = locationRepository;
		this.errorResolver= errorResolver;
	}

	@Transactional
	public void on(final LocationV1 locationV1) throws ResultIntegrityValidationException {
		log.debug("Entered into on(): {}", locationV1);
		final Optional<Location> optLocation = locationRepository.findById(locationV1.getLocationUuid());
		Location existingLocation = optLocation.orElse(new Location());
		try {

			locationValidation(locationV1, optLocation.orElse(null));
			log.debug("Location with locationId:{} is getting created", locationV1.getLocationUuid());
			Location savedLocation = locationRepository.save(updateLocation(existingLocation, locationV1));
			ResultIntegrityLocationConsumedV1 locationConsumedV1 = buildLocationNode(savedLocation);
			buildHeader(RESULT_INTEGRITY_LOCATION_CONSUMED);
			publishEvent(locationConsumedV1);


		} catch (final ResultIntegrityValidationException exception) {
			log.warn("Exception raised", exception);
			buildHeader(RESULT_INTEGRITY_LOCATION_REJECTED);
			ResultIntegrityLocationConsumedV1 rejectedEvent = buildRejectedEvent(existingLocation);
			Set<ConstraintViolation<Object>> violations =
					RICommonUtil.getSetforNullViolationOfEventBody(
							RIConstants.ErrorCodes.REJECT_WHEN_DATETIME_IS_OBSOLETE,
							"rejectwhendatetimeisobsolete");

			CMDSErrorResponse eventErrors =
					errorResolver.populatErrorResponse(
							violations, ThreadLocalHeaderContext.getContext().getEventName());
			publishEvent(rejectedEvent, eventErrors.getErrorList());
		}
	}

	public void locationValidation(
			final LocationV1 locationDetails,
			final Location optionalLocation)
					throws ResultIntegrityValidationException {
		if (Objects.nonNull(optionalLocation)) {
			LocalDateTime localDateTime = optionalLocation.getEventDatetime();
			if (!(ThreadLocalHeaderContext.getContext().getEventDateTime().isAfter(localDateTime))) {
				throw new ResultIntegrityValidationException(
						String.format(
								"Received Event Date time is before this : %s  " + "for this Location UUID : %s",
								localDateTime, locationDetails.getLocationUuid()),
						new Throwable());
			}
		}
	}

	public void buildHeader(final String eventName) {
		final CMDSHeaderContext header = new CMDSHeaderContext();
		header.setCorrelationId(ThreadLocalHeaderContext.getContext().getCorrelationId());
		header.setEventDateTime(LocalDateTime.now());
		header.setTransactionId(ThreadLocalHeaderContext.getContext().getTransactionId());
		header.setPartnerCode(ThreadLocalHeaderContext.getContext().getPartnerCode());
		header.setEventName(eventName);
		ThreadLocalHeaderContext.clearContext();
		ThreadLocalHeaderContext.setContext(header);
	}

	public ResultIntegrityLocationConsumedV1 buildRejectedEvent(Location location) {
		ResultIntegrityLocationConsumedV1 rejectedEvent = new ResultIntegrityLocationConsumedV1();
		rejectedEvent.setLocationUuid(String.valueOf(location.getLocationUuid()));
		rejectedEvent.setParentLocationUuid(String.valueOf(location.getParentLocationUuid()));
		rejectedEvent.setLocationName(location.getLocationName());
		rejectedEvent.setLocationTypeCode(Objects.nonNull(location.getLocationTypeCode()) ?
				ResultIntegrityLocationConsumedV1.LocationTypeCodeEnum.valueOf(location.getLocationTypeCode().getValue()) : null);
		rejectedEvent.setTestCentreNumber(location.getTestCentreNumber());
		rejectedEvent.setStatus(Objects.nonNull(location.getLocationStatus()) ?
				ResultIntegrityLocationConsumedV1.StatusEnum.valueOf(location.getLocationStatus().getValue()) : null);
		rejectedEvent.setPartnerCode((location.getPartnerCode()));


		return rejectedEvent;
	}

	public ResultIntegrityLocationConsumedV1 buildLocationNode(Location location) {
		ResultIntegrityLocationConsumedV1 locationConsumedV1 = new ResultIntegrityLocationConsumedV1();
		locationConsumedV1.setLocationUuid(String.valueOf(location.getLocationUuid()));
		locationConsumedV1.setParentLocationUuid(String.valueOf(location.getParentLocationUuid()));
		locationConsumedV1.setLocationName(location.getLocationName());
		locationConsumedV1.setLocationTypeCode(Objects.nonNull(location.getLocationTypeCode()) ?
				ResultIntegrityLocationConsumedV1.LocationTypeCodeEnum.valueOf(location.getLocationTypeCode().getValue()): null);
		locationConsumedV1.setTestCentreNumber(location.getTestCentreNumber());
		locationConsumedV1.setStatus(Objects.nonNull(location.getLocationStatus()) ?
				ResultIntegrityLocationConsumedV1.StatusEnum.valueOf(location.getLocationStatus().getValue()) : null);
		locationConsumedV1.setPartnerCode((location.getPartnerCode()));
		return locationConsumedV1;
	}


	public Location updateLocation(final Location existingLocation, final LocationV1 locationV1) {
		setCommonLocationData(existingLocation, locationV1);
		existingLocation.setUpdatedDatetime(OffsetDateTime.now(ZoneOffset.UTC));
		existingLocation.setEventDatetime(ThreadLocalHeaderContext.getContext().getEventDateTime());
		return existingLocation;
	}

	public void setCommonLocationData(final Location location, final LocationV1 locationV1) {
		location.setLocationUuid(locationV1.getLocationUuid());
		location.setParentLocationUuid(locationV1.getParentLocationUuid());
		location.setLocationTypeCode(locationV1.getLocationTypeCode());
		location.setPartnerCode(String.valueOf(locationV1.getPartnerCode()));
		location.setLocationName(locationV1.getLocationName());
		location.setCreatedDatetime(OffsetDateTime.now(ZoneOffset.UTC));

		location.setTestCentreNumber(locationV1.getTestCentreNumber());
		location.setLocationStatus(locationV1.getStatus());
	}
}

