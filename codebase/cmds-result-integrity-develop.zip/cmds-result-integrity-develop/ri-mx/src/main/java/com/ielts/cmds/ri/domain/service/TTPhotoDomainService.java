package com.ielts.cmds.ri.domain.service;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.application.exception.ResultIntegrityValidationException;
import com.ielts.cmds.ri.domain.enums.PhotoCategoryEnum;
import com.ielts.cmds.ri.infrastructure.entity.TestTakerPhoto;
import com.ielts.cmds.ri.infrastructure.repository.TestTakerPhotoRepository;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;
import com.ielts.cmds.testtaker.common.events.model.PhotoPublishedV1;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class TTPhotoDomainService extends AbstractCMDSDomainService<PhotoPublishedV1> {

  private final TestTakerPhotoRepository testTakerPhotoRepository;

  @Autowired
  public TTPhotoDomainService(ApplicationEventPublisher publisher,
                              ObjectMapper objectMapper,
                              @Value("${resultIntegrityPhotoConsumed.v2}") String isV2Enabled,
                              CMDSThreadLocalContextService cmdsThreadLocalContextService,
                              TestTakerPhotoRepository testTakerPhotoRepository) {
    super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
    this.testTakerPhotoRepository = testTakerPhotoRepository;
  }

  @Transactional
  @SneakyThrows
	public void on(final PhotoPublishedV1 photoPublishedV1) {

		Optional<TestTakerPhoto> optionalTestTakerPhoto = testTakerPhotoRepository
				.findById(photoPublishedV1.getPhotoUuid());
		try {
			photoValidation(photoPublishedV1, optionalTestTakerPhoto.orElse(null));
			final TestTakerPhoto photo = generatePhotoFrom(optionalTestTakerPhoto.orElse(null),photoPublishedV1);
			testTakerPhotoRepository.save(photo);
			log.info("PhotoPublishedEvent successfully processed for event: {}",
					ThreadLocalHeaderContext.getContext().getEventName());
			publishPhotoConsumedEvent(photoPublishedV1, photo);
		} catch (ResultIntegrityValidationException e) {
			log.warn("PhotoPublishedSelectionCommand execution failed", e);

		}
	}

	protected void photoValidation(final PhotoPublishedV1 photoEventBody,
			final TestTakerPhoto optionalTestTakerPhoto) throws ResultIntegrityValidationException {
		if ( Objects.nonNull(optionalTestTakerPhoto)) {
			LocalDateTime localDateTime = optionalTestTakerPhoto.getEventDatetime();
			if (!(ThreadLocalHeaderContext.getContext().getEventDateTime().isAfter(localDateTime))) {
				throw new ResultIntegrityValidationException(
						String.format("Received Event Date time is before this : %s  " + "for this Result UUID : %s",
								localDateTime, photoEventBody.getPhotoUuid()),
						new Throwable());
			}
		}
	}


	TestTakerPhoto generatePhotoFrom(TestTakerPhoto optionalTestTakerPhoto, PhotoPublishedV1 photoEvent) {

		TestTakerPhoto photo = Optional.ofNullable(optionalTestTakerPhoto)
				.orElseGet(() -> TestTakerPhoto.builder().photoUuid(photoEvent.getPhotoUuid()).build());
		photo.setBookingUuid(photoEvent.getBookingUuid());
		photo.setPhotoPath(photoEvent.getPhotoPath());
		photo.setPhotoVersion(photoEvent.getPhotoVersion());
		photo.setPhotoTypeUuid(photoEvent.getPhotoTypeUuid());
		photo.setPhotoCategory(PhotoCategoryEnum.getEnum(photoEvent.getPhotoCategory().toString()));
		photo.setEventDatetime(ThreadLocalHeaderContext.getContext().getEventDateTime());

		return photo;
	}


  public void publishPhotoConsumedEvent(PhotoPublishedV1 photoPublishedV1, TestTakerPhoto photo) {
    photoPublishedV1.setBookingUuid(photo.getBookingUuid());
    photoPublishedV1.setCompositeCandidateNumber(photoPublishedV1.getCompositeCandidateNumber());
    photoPublishedV1.setPhotoTypeUuid(photoPublishedV1.getPhotoTypeUuid());
    photoPublishedV1.setPhotoUuid(photo.getPhotoUuid());
    photoPublishedV1.setPhotoPath(photo.getPhotoPath());
    photoPublishedV1.setPhotoVersion(photo.getPhotoVersion());
    photoPublishedV1.setPhotoCategory(com.ielts.cmds.testtaker.common.events.model.PhotoCategoryEnum.valueOf(photo.getPhotoCategory().getValue()));

    try {
      buildHeader();
      publishEvent(photoPublishedV1);
      log.info("Photo Event Published");

    } catch (final Exception e) {
      log.warn(" TTPhotoConsumedEvent failed execution ",e);
    }

  }

  private void buildHeader() {
    CMDSHeaderContext header = new CMDSHeaderContext();
    header.setCorrelationId(ThreadLocalHeaderContext.getContext().getCorrelationId());
    header.setEventDateTime(LocalDateTime.now(ZoneOffset.UTC));
    header.setTransactionId(ThreadLocalHeaderContext.getContext().getTransactionId());
    header.setPartnerCode(ThreadLocalHeaderContext.getContext().getPartnerCode());
    header.setEventName(RIConstants.EventType.RESULT_INTEGRITY_PHOTO_CONSUMED);
    ThreadLocalHeaderContext.setContext(header);
  }
}

