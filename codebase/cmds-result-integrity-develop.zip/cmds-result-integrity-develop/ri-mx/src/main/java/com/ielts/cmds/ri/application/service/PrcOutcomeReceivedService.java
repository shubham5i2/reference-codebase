package com.ielts.cmds.ri.application.service;

import com.ielts.cmds.common.config.IBaseAuditService;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.common.model.out.PrcOutcomeV1;
import com.ielts.cmds.ri.domain.service.PrcOutcomeReceivedDomainService;
import com.ielts.cmds.serialization.application.service.IApplicationServiceV2;
import com.ielts.cmds.serialization.utils.ServiceIdentifier;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.ielts.cmds.ri.utils.RIConstants.PermissionId.RI_BOOKING_PRCOUTCOME;
import static com.ielts.cmds.ri.utils.RIConstants.UiConstants.OPERATION_TYPE_POST;
import static com.ielts.cmds.ri.utils.RIConstants.UiConstants.SUBMIT_PRC_OUTCOME_RESOURCE_TYPE;

/** The type Prc outcome received service. */
@Service
@ServiceIdentifier(OPERATION_TYPE_POST+(SUBMIT_PRC_OUTCOME_RESOURCE_TYPE))
@Slf4j
public class PrcOutcomeReceivedService implements IApplicationServiceV2<PrcOutcomeV1>, IBaseAuditService {

  /** The Prc outcome received domain service. */
  @Autowired PrcOutcomeReceivedDomainService prcOutcomeReceivedDomainService;

  @Override
  public void process(PrcOutcomeV1 prcOutcomeReceived) {
    log.debug(
        "Prc Outcome Received Service process started for request with CorrelationId:{}",
        ThreadLocalHeaderContext.getContext().getCorrelationId());
    CMDSHeaderContext initHeader = ThreadLocalHeaderContext.getContext();
    populateAuditFields();
    try {
        prcOutcomeReceivedDomainService.on(prcOutcomeReceived);
    } catch (IllegalArgumentException e) {
      log.error("Failed to process Prc Outcome Received event due to ", e);
      prcOutcomeReceivedDomainService.publishUiEvent(null, null, initHeader);
    }
  }

  @Override
  public String getPermission() {
    return RI_BOOKING_PRCOUTCOME;
  }

  @Override
  public String getScreen() {
    return RI_BOOKING_PRCOUTCOME;
  }

  @Override
  public String getAction() {
    return PrcOutcomeReceivedService.class.getSimpleName();
  }
}
