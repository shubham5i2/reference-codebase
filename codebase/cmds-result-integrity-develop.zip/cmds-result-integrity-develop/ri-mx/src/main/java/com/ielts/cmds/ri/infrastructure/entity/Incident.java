package com.ielts.cmds.ri.infrastructure.entity;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.ielts.cmds.ri.domain.enums.ExternalIncidentStatusEnum;
import com.ielts.cmds.ri.domain.enums.IncidentSeverityEnum;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Builder
@ToString(exclude = {"incidentCommentsByIncidentUuid", "incidentTypeByIncidentTypeUuid",
"incidentCategoryByIncidentCategoryUuid", "incidentStatusTypeByIncidentStatusTypeUuid",
"incidentEvidencesByIncidentUuid"})
@Table(name = "incident")
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true,exclude = {"externalIncidentChangedDateTime",
"incidentEvidencesByIncidentUuid", "incidentCommentsByIncidentUuid"})
@Data
public class Incident extends CommonModel{
	
    
    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
    @Column(name = "incident_uuid")
    private UUID incidentUuid;

    
    @Column(name = "booking_line_uuid")
    private UUID bookingLineUuid;
    
    
    @Column(name = "external_incident_id")
    private String externalIncidentId;

    
    @Column(name = "external_incident_changed_date_time")
    private OffsetDateTime externalIncidentChangedDateTime;
    

    @Enumerated(EnumType.STRING)
    @Column(name = "incident_severity")
    private IncidentSeverityEnum incidentSeverity;

    @ManyToOne
    @JoinColumn(name = "incident_type_uuid", referencedColumnName = "incident_type_uuid", nullable = false)
    private IncidentType incidentTypeByIncidentTypeUuid;
    
    @ManyToOne
    @JoinColumn(name = "incident_category_uuid", referencedColumnName = "incident_category_uuid", nullable = false)
    private IncidentCategory incidentCategoryByIncidentCategoryUuid;

    @Column(name = "booking_uuid")
    private UUID bookingUuid;
    

    @ManyToOne
    @JoinColumn(name = "incident_status_type_uuid", referencedColumnName = "incident_status_type_uuid", nullable = false)
    private IncidentStatusType incidentStatusTypeByIncidentStatusTypeUuid;
    

    @ManyToOne
    @JoinColumn(name = "check_outcome_uuid", referencedColumnName = "check_outcome_uuid", nullable = false)
    private CheckOutcome checkOutcomeByCheckOutcomeUuid;
    

    @OneToMany(mappedBy = "incidentByIncidentUuid", cascade = CascadeType.ALL)
    private List<IncidentEvidence> incidentEvidencesByIncidentUuid;
    

    @OneToMany(mappedBy = "incidentByIncidentUuid", cascade = CascadeType.ALL)
    private List<IncidentComment> incidentCommentsByIncidentUuid;
    
    public void addIncidentEvidence(IncidentEvidence incidentEvidence) {
        this.incidentEvidencesByIncidentUuid.add(incidentEvidence);
        incidentEvidence.setIncidentByIncidentUuid(this);
    }

    public void addIncidentComment(IncidentComment incidentComment) {
        this.incidentCommentsByIncidentUuid.add(incidentComment);
        incidentComment.setIncidentByIncidentUuid(this);
    }


    @Enumerated(EnumType.STRING)
    @Column(name = "external_incident_status")
    private ExternalIncidentStatusEnum externalIncidentStatus;

    @Column(name = "event_datetime")
    private LocalDateTime eventDateTime;
    

}
