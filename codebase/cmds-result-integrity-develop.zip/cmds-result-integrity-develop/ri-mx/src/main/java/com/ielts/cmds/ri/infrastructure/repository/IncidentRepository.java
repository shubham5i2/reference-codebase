package com.ielts.cmds.ri.infrastructure.repository;

import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.Incident;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IncidentRepository extends JpaRepository<Incident, UUID> {

  List<Incident> findByBookingUuid(UUID bookingUuid);

  Optional<Incident> findByExternalIncidentIdAndBookingUuidAndBookingLineUuid(
      String externalIncidentId, UUID bookingUuid, UUID bookingLineUuid);

  Optional<Incident> findByExternalIncidentIdAndBookingUuid(String externalIncidentId,
      UUID bookingUuid);

  Optional<Incident> findByExternalIncidentId(String externalIncidentId);

  Optional<Incident> findByIncidentUuid(UUID externalIncidentId);

  List<Incident> findByCheckOutcomeByCheckOutcomeUuid(CheckOutcome checkOutcome);

  List<Incident> findByCheckOutcomeByCheckOutcomeUuidAndBookingUuid(
      CheckOutcome checkOutcome, UUID bookingUuid);
}
