package com.ielts.cmds.ri.application.service;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.lpr.common.out.model.LocationV1;
import com.ielts.cmds.ri.domain.service.LocationChangedDomainService;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.service.IApplicationServiceV2;
import com.ielts.cmds.serialization.utils.ServiceIdentifier;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * The type Location service.
 */
@Service
@ServiceIdentifier(RIConstants.EventType.LOCATION_CHANGED_EVENT)
@Slf4j
public class LocationChangedService implements IApplicationServiceV2<LocationV1> {

  @Autowired LocationChangedDomainService locationChangedDomainService;

  @SneakyThrows
  @Override
  public void process(LocationV1 locationV1) {
    log.debug(
        "Location Service process started for request with CorrelationId:{}",
        ThreadLocalHeaderContext.getContext().getCorrelationId());
      locationChangedDomainService.on(locationV1);
  }

}
