package com.ielts.cmds.ri.infrastructure.entity;


import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ielts.cmds.ri.domain.enums.BookingRoleEnum;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "booking_link")
@Builder
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
public class BookingLink extends CommonModel implements Serializable {

    private static final long serialVersionUID = 8195033501228455119L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "booking_link_uuid")
    private UUID bookingLinkUuid;

    @Enumerated(EnumType.STRING)
    @Column(name = "role")
    private BookingRoleEnum role;

    @Column(name = "source_booking_uuid")
    private UUID sourceBookingUuid;

    @Column(name = "target_booking_uuid")
    private UUID targetBookingUuid;

}

