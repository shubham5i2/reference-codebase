package com.ielts.cmds.ri.infrastructure.repository;

import com.ielts.cmds.ri.infrastructure.entity.Location;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

/**
 * Location repository to perform CRUD operations on Location. It is extended from JpaRepository to
 * refresh data.
 */
@Repository
public interface LocationRepository extends JpaRepository<Location, UUID> {
}

