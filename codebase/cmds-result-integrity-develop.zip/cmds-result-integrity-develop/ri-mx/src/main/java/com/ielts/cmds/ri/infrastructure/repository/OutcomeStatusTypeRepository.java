package com.ielts.cmds.ri.infrastructure.repository;

import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatusType;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;
@Repository
@Cacheable("outcomeStatusType")
public interface OutcomeStatusTypeRepository extends JpaRepository<OutcomeStatusType, UUID> {
    Optional<OutcomeStatusType> findByOutcomeStatusTypeCode(String outcomeStatusTypeCode);
}
