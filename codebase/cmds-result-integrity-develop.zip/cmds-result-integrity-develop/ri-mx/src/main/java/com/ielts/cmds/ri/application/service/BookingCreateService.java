package com.ielts.cmds.ri.application.service;

import com.ielts.cmds.api.evt_019.BookingChangedEventV1;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.domain.service.BookingCreatedDomainService;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.service.IApplicationServiceV2;
import com.ielts.cmds.serialization.utils.ServiceIdentifier;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * The type Booking create service.
 */
@Service
@ServiceIdentifier(RIConstants.EventType.BOOKING_CREATED_EVENT)
@Slf4j
public class BookingCreateService implements IApplicationServiceV2<BookingChangedEventV1> {

	@Autowired
	BookingCreatedDomainService bookingCreatedDomainService;

    @SneakyThrows
    @Override
	public void process(BookingChangedEventV1 bookingChangedEvent) {
		try {
			log.debug("Booking Create Service process started for request with CorrelationId:{}",
					ThreadLocalHeaderContext.getContext().getCorrelationId());
			if (bookingChangedEvent == null) {
				throw new IllegalArgumentException("Payload is Empty");
			}
			bookingCreatedDomainService.on(bookingChangedEvent.getBookingDetails());
		} catch (IllegalArgumentException e) {
			log.error("Failed to process Booking event due to ", e);
			throw new ProcessingException(e.getMessage(), e);
		}
	}
}
