package com.ielts.cmds.ri.infrastructure.repository;

import com.ielts.cmds.ri.infrastructure.entity.IncidentView;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface IncidentViewRepository extends JpaSpecificationExecutor<IncidentView>,
    JpaRepository<IncidentView, UUID> {


  List<IncidentView> findByBookingUuidOrderByCreatedDatetime(UUID bookingUuid);
}
