package com.ielts.cmds.ri.infrastructure.repository;

import com.ielts.cmds.ri.infrastructure.entity.ProductCheckOutcomeType;
import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductCheckOutcomeTypeRepository extends
    JpaRepository<ProductCheckOutcomeType, UUID> {

  List<ProductCheckOutcomeType> findByProductUuid(UUID productUuid);
}
