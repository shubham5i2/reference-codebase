package com.ielts.cmds.ri.infrastructure.repository;

import com.ielts.cmds.ri.infrastructure.entity.BookingLine;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface BookingLineRepository extends JpaRepository<BookingLine, UUID> {
    Optional<BookingLine> findByExternalBookingLineUuid(UUID externalBookingLineUuid);

    List<BookingLine> findByEndDatetimeBefore(Timestamp modDate);
}
