package com.ielts.cmds.ri.infrastructure.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;

@Repository
public interface CheckOutcomeRepository extends JpaRepository<CheckOutcome, UUID> {

	Optional<CheckOutcome> findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(UUID bookingUuid, UUID checkOutcomeTypeUuid);

	List<CheckOutcome> findByBookingUuid(UUID bookingUuid);
}
