package com.ielts.cmds.ri.infrastructure.event.listener;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.rbac.api.service.RBACService;
import com.ielts.cmds.serialization.application.service.ApplicationServiceFactory;
import com.ielts.cmds.serialization.application.service.ApplicationServiceFactoryV2;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.infra.AbstractUIListener;
import com.ielts.cmds.serialization.utils.BaseEventExtractor;
import com.ielts.cmds.serialization.utils.CmdsLoggerInitializer;
import com.ielts.cmds.serialization.utils.CmdsLoggerInitializerV2;
import com.ielts.cmds.serialization.utils.EventBodyExtractor;
import com.ielts.cmds.serialization.utils.MessageVersionIdentifier;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

/** The type Ri ui listener. */
@Service
public class RIUiListener extends AbstractUIListener<UiHeader> {

	@SuppressWarnings("rawtypes")
	@Autowired
	protected RIUiListener(ObjectMapper mapper,
						   EventBodyExtractor extractEventBody,
						   BaseEventExtractor extractBaseEvent,
						   CmdsLoggerInitializerV2 initializeCmdsLogger,
						   CmdsLoggerInitializer initializeCmdsLoggerV1,
						   MessageVersionIdentifier identifyVersion,
						   ApplicationServiceFactoryV2 applicationServiceFactoryV2,
						   ApplicationServiceFactory applicationServiceFactory,
						   RBACService rbacService,
						   CMDSThreadLocalContextService cmdsThreadLocalContextService) {
		super(mapper,
				extractEventBody,
				extractBaseEvent,
				initializeCmdsLogger,
				initializeCmdsLoggerV1,
				identifyVersion,
				applicationServiceFactoryV2,
				applicationServiceFactory,
				rbacService,
				cmdsThreadLocalContextService);
	}

	@JmsListener(destination = "${aws.sqs.ri-ui-queue-in.name}")
  public void onReceive(Message<String> riUiRequest) {
	  onReceive(riUiRequest.getHeaders(), riUiRequest.getPayload());
  }
}
