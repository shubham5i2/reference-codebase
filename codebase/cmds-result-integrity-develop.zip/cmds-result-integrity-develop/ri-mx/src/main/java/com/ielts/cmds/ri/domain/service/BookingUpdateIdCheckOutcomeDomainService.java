package com.ielts.cmds.ri.domain.service;

import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_PASSED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.ID_VERIFICATION_STATUS_VERIFIED;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.evt119.CheckOutcomeV1;
import com.ielts.cmds.api.evt119.IntegrityCheckInitiatedV1;
import com.ielts.cmds.api.evt_019.TestTakerDetailsV1;
import com.ielts.cmds.api.evt_019.TestTakerDetailsV1.IdentityVerificationStatusEnum;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.application.exception.ResultIntegrityValidationException;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeType;
import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.Product;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.ProductRepository;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;
import com.ielts.cmds.serialization.domain.EnableOutboundEventV2;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
@EnableOutboundEventV2
public class BookingUpdateIdCheckOutcomeDomainService extends AbstractCMDSDomainService<IntegrityCheckInitiatedV1> {

	private CheckOutcomeRepository checkOutcomeRepository;
	private CheckOutcomeTypeRepository checkOutcomeTypeRepository;
	private CheckOutcomeStatusRepository checkOutcomeStatusRepository;
	private OutcomeStatusRepository outcomeStatusRepository;
	private ProductRepository productRepository;
	@Autowired
	public BookingUpdateIdCheckOutcomeDomainService(ApplicationEventPublisher publisher, ObjectMapper objectMapper,  @Value("${integrityCheckInitiated.v2}")String isV2Enabled,
			CMDSThreadLocalContextService cmdsThreadLocalContextService,CheckOutcomeRepository checkOutcomeRepository,
			CheckOutcomeTypeRepository checkOutcomeTypeRepository,CheckOutcomeStatusRepository checkOutcomeStatusRepository,
			OutcomeStatusRepository outcomeStatusRepository,ProductRepository productRepository ) {
		super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
		this.checkOutcomeRepository=checkOutcomeRepository;
		this.checkOutcomeTypeRepository=checkOutcomeTypeRepository;
		this.outcomeStatusRepository=outcomeStatusRepository;
		this.productRepository=productRepository;
		this.checkOutcomeStatusRepository=checkOutcomeStatusRepository;
	}

	public void updateIdCheckOutcome(Booking booking, TestTakerDetailsV1 testTakerDetails) {
		log.debug("Enter into updateIdCheckOutcome(): {}", testTakerDetails);
		try {
			CheckOutcome checkOutcome = setCheckOutCome(booking,testTakerDetails);
			if(Objects.nonNull(checkOutcome)) {
				log.info("publishing event: {}", RIConstants.EventType.INTEGRITY_CHECK_INITIATED);
				IntegrityCheckInitiatedV1 integrityCheckInitiatedV1 = buildEvent(checkOutcome);
				buildIntegrityCheckInitiatedHeader(checkOutcome);
				log.debug("IOC ID Check Outcome: IntegrityCheckInitiated event header {}, with eventbody {}", ThreadLocalHeaderContext.getContext(), integrityCheckInitiatedV1);
				publishEvent(integrityCheckInitiatedV1);
			} else {
				log.info("Not an IOC variant, hence not updating check outcome");
			}
		}catch (ResultIntegrityValidationException e) {
			log.warn("Could not find static data into the database",e);
		}
	}

	private CheckOutcome setCheckOutCome(Booking booking, TestTakerDetailsV1 testTakerDetails) {

		CheckOutcome savedCheckOutcome = null;
		Optional<Product> optProduct = productRepository.findById(booking.getProductUuid());
		if (optProduct.isPresent() && optProduct.get().getProductCharacteristics().contains("IOC")) {
			log.info("IOC variant, hence updating check outcome");

			// find existing check outcome with booking uuid and Id check outcome type
			CheckOutcomeType checkOutcomeType = getCheckOutComeType();
			Optional<CheckOutcome> optionalCheckOutcome =
					checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
							booking.getBookingUuid(), checkOutcomeType.getCheckOutcomeTypeUuid());
			CheckOutcomeStatus checkOutcomeStatus = getCheckOutComeStatus(testTakerDetails);

			CheckOutcome checkOutcome =
					optionalCheckOutcome.orElse(new CheckOutcome());
			checkOutcome.setCheckOutcomeStatus(checkOutcomeStatus);
			checkOutcome.setCheckOutcomeType(checkOutcomeType);
			checkOutcome.setBookingUuid(booking.getBookingUuid());
			checkOutcome.setBookingVersion(booking.getBookingVersion());
			checkOutcome.setEventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime());
			savedCheckOutcome = checkOutcomeRepository.save(checkOutcome);
			Optional<OutcomeStatus> optionalOutcomeStatus = outcomeStatusRepository
					.findByBookingUuid(booking.getBookingUuid());
			OutcomeStatus outcomeStatus = optionalOutcomeStatus.orElse(new OutcomeStatus());
			outcomeStatus.setCheckOutcomeEventDateTime(savedCheckOutcome.getEventDateTime());
			outcomeStatus.setBookingVersion(booking.getBookingVersion());
			outcomeStatusRepository.save(outcomeStatus);
		}
		return savedCheckOutcome;
	}


	public CheckOutcomeStatus getCheckOutComeStatus(TestTakerDetailsV1 testTakerDetails) {
		log.debug("Enter into getCheckOutComeStatus()");
		Optional<CheckOutcomeStatus> optionalCheckOutcomeStatus = Optional.empty();
		String checkOutcomeStatusValue = Optional.ofNullable(testTakerDetails)
				.map(TestTakerDetailsV1::getIdentityVerificationStatus)
				.map(IdentityVerificationStatusEnum::getValue)
				.map(this::mapIdVerificationStatusToCheckOutcome)
				.orElse(null);

		if (Objects.nonNull(checkOutcomeStatusValue)) {
			optionalCheckOutcomeStatus =
					checkOutcomeStatusRepository.findByCheckOutcomeStatusCode(checkOutcomeStatusValue);

		}

		return optionalCheckOutcomeStatus.orElseThrow(()-> new ResultIntegrityValidationException("Checkoutcome status not found"));
	}

  protected String mapIdVerificationStatusToCheckOutcome(String idVerificationStatus) {
    if(ID_VERIFICATION_STATUS_VERIFIED.equals(idVerificationStatus)) {
        return CHECK_OUTCOME_STATUS_CODE_PASSED;
    } else {
        return null;
    }
    }

	CheckOutcomeType getCheckOutComeType() {
		Optional<CheckOutcomeType> optionalCheckOutcomeType =
				checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(
						RIConstants.PrcOutcomeConstant.LRW_ID_INC_CHK);
		return optionalCheckOutcomeType.orElseThrow(()-> new ResultIntegrityValidationException("Checkoutcome type not found"));
	}


	private void buildIntegrityCheckInitiatedHeader(
			final CheckOutcome checkOutcome) {
		CMDSHeaderContext cmdsHeaderContext = new CMDSHeaderContext();
		cmdsHeaderContext.setCorrelationId(ThreadLocalHeaderContext.getContext().getCorrelationId());
		cmdsHeaderContext.setEventDateTime(LocalDateTime.now(ZoneOffset.UTC));
		cmdsHeaderContext.setTransactionId(ThreadLocalHeaderContext.getContext().getTransactionId());
		cmdsHeaderContext.setPartnerCode(ThreadLocalHeaderContext.getContext().getPartnerCode());
		cmdsHeaderContext.setEventName(RIConstants.EventType.INTEGRITY_CHECK_INITIATED);
		Map<String, String> eventContext = new HashMap<>();
		eventContext.putIfAbsent("bookingUuid", String.valueOf(checkOutcome.getBookingUuid()));
		eventContext.putIfAbsent("checkOutcomeUuid", String.valueOf(checkOutcome.getCheckOutcomeUuid()));
		cmdsHeaderContext.setEventContext(eventContext);
		ThreadLocalHeaderContext.clearContext();
		ThreadLocalHeaderContext.setContext(cmdsHeaderContext);
	}


	private IntegrityCheckInitiatedV1 buildEvent(CheckOutcome checkOutcome) {
		CheckOutcomeV1 checkOutcomeV1 = new CheckOutcomeV1();
		IntegrityCheckInitiatedV1 integrityCheckInitiatedV1=new IntegrityCheckInitiatedV1();
		checkOutcomeV1.setCheckOutcomeStatusUuid(
				checkOutcome.getCheckOutcomeStatus().getCheckOutcomeStatusUuid());
		checkOutcomeV1.setCheckOutcomeTypeUuid(
				checkOutcome.getCheckOutcomeType().getCheckOutcomeTypeUuid());

		integrityCheckInitiatedV1.setCheckOutcome(checkOutcomeV1);
		integrityCheckInitiatedV1.setBookingUuid((checkOutcome.getBookingUuid()));
		integrityCheckInitiatedV1.setBookingVersion(checkOutcome.getBookingVersion());

		return integrityCheckInitiatedV1;
	}
}

