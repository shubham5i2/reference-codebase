package com.ielts.cmds.ri.infrastructure.repository;


import com.ielts.cmds.ri.infrastructure.entity.PhotoType;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface PhotoTypeRepository extends CrudRepository<PhotoType, UUID> {

  Optional<PhotoType> findByPhotoTypeCode(String photoTypeCode);

}