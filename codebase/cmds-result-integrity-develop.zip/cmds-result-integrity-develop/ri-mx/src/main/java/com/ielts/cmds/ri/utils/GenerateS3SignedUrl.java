package com.ielts.cmds.ri.utils;

import com.amazonaws.HttpMethod;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;
import com.ielts.cmds.ri.infrastructure.config.AwsCommonConfig;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.net.URL;
import java.time.Instant;
import java.util.Date;
import java.util.function.BinaryOperator;

@Slf4j
@Component
public class GenerateS3SignedUrl implements BinaryOperator<String> {

  @Autowired
  private AwsCommonConfig awsCommonConfig;
  @Value("${expiration-duration}")
  private String expirationDuration;
  @Value("${aws.region}")
  private String awsRegion;

  public GenerateS3SignedUrl(@Value("${expiration-duration}") String expirationDuration, @Value("${aws.region}") String awsRegion, AwsCommonConfig awsCommonConfig) {
      this.awsCommonConfig = awsCommonConfig;
      this.expirationDuration = expirationDuration;
      this.awsRegion = awsRegion;
  }
  @Override
  @SneakyThrows
  public String apply(String bucketName, String objectKey) {

    long expirationInMillis = 1000L * 60 * 60 * Integer.parseInt(expirationDuration);

    log.info("create pre-signed url generate request..");
    GeneratePresignedUrlRequest generatePresignedUrlRequest =
        new GeneratePresignedUrlRequest(bucketName, objectKey)
            .withMethod(HttpMethod.GET)
            .withExpiration(Date.from(Instant.now().plusMillis(expirationInMillis)));

    log.debug("generate pre-signed url..");
    URL preSignedUrl = awsCommonConfig.getAmazonS3Client()
        .generatePresignedUrl(generatePresignedUrlRequest);

    log.info("return pre-signed url for file : {} with expiration in {} hrs.", objectKey, Integer.parseInt(expirationDuration));
    return preSignedUrl.toString();

  }
}
