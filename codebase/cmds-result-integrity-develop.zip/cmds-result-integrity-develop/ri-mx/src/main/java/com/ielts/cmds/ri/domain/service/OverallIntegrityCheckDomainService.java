package com.ielts.cmds.ri.domain.service;

import static com.ielts.cmds.ri.utils.RIConstants.CheckOutcomeTypeConstants.CHK_OUT_TYPE_LRW_INC_CHK_CODE;
import static com.ielts.cmds.ri.utils.RIConstants.CheckOutcomeTypeConstants.CHK_OUT_TYPE_SPEAKING_INC_CHK_CODE;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_PASSED;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.dao.PessimisticLockingFailureException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.evt119.CheckOutcomeV1;
import com.ielts.cmds.api.evt119.IntegrityCheckInitiatedV1;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.BookingLineOutcomeView;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeType;
import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatus;
import com.ielts.cmds.ri.infrastructure.repository.BookingLineOutcomeViewRepository;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.ResultIntegritySemaphoreRepository;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.ri.utils.RIConstants.EventType;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class OverallIntegrityCheckDomainService extends AbstractCMDSDomainService<IntegrityCheckInitiatedV1> {

	private final CheckOutcomeRepository checkOutcomeRepository;

	private final CheckOutcomeTypeRepository checkOutcomeTypeRepository;

	private final CheckOutcomeStatusRepository checkOutcomeStatusRepository;

	private final BookingLineOutcomeViewRepository bookingLineOutcomeViewRepository;

	private final OutcomeStatusRepository outcomeStatusRepository;

	private final BookingRepository bookingRepository;

	private final RICommonUtil riCommonUtil;

	private final ResultIntegritySemaphoreRepository resultIntegritySemaphoreRepository;

	@Autowired
	public OverallIntegrityCheckDomainService(ApplicationEventPublisher publisher,
			ObjectMapper objectMapper,
			@Value("${integrityCheckInitiated.v2}") String isV2Enabled,
			CMDSThreadLocalContextService cmdsThreadLocalContextService,
			CheckOutcomeRepository checkOutcomeRepository,
			CheckOutcomeTypeRepository checkOutcomeTypeRepository,
			CheckOutcomeStatusRepository checkOutcomeStatusRepository,
			BookingLineOutcomeViewRepository bookingLineOutcomeViewRepository,
			OutcomeStatusRepository outcomeStatusRepository,
			BookingRepository bookingRepository,
			RICommonUtil riCommonUtil,
			ResultIntegritySemaphoreRepository resultIntegritySemaphoreRepository) {
		super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
		this.checkOutcomeRepository = checkOutcomeRepository;
		this.checkOutcomeTypeRepository = checkOutcomeTypeRepository;
		this.checkOutcomeStatusRepository = checkOutcomeStatusRepository;
		this.bookingLineOutcomeViewRepository = bookingLineOutcomeViewRepository;
		this.outcomeStatusRepository = outcomeStatusRepository;
		this.bookingRepository = bookingRepository;
		this.riCommonUtil = riCommonUtil;
		this.resultIntegritySemaphoreRepository = resultIntegritySemaphoreRepository;
	}

	@SneakyThrows
	@Transactional
	public void on() {
		log.info("Triggering to check checkOutcome status in every 5 min");
		try {
			resultIntegritySemaphoreRepository.findById(RIConstants.EventType.OVERALL_INTEGRITY_CHECK_INITIATED);
			List<BookingLineOutcomeView> bookingList = bookingLineOutcomeViewRepository
					.findAll();

			bookingList.forEach(existingBooking ->
			checkAndSetCheckOutcome(
					existingBooking.getBookingUuid(),
					existingBooking.getCheckOutcomeReceived(),
					existingBooking.getBookingVersion()));

			log.info("Processed {} bookings",bookingList.size());

		} catch (PessimisticLockingFailureException e) {
			throw e;
		}
		catch (Exception e) {
			throw new ResultIntegrityException(
					"Parsing exception : " + e);
		}
	}


	void checkAndSetCheckOutcome(final UUID existingBookingUuid, final String checkOutcomeReceived, final BigDecimal bookingVersion) {
		Optional<Booking> optionalBooking = bookingRepository.findById(existingBookingUuid);
		if (optionalBooking.isPresent()) {
			List<String> eligibleCheckOutcome = riCommonUtil.generateCheckOutcomeList(optionalBooking.get());

			if (!StringUtils.contains(checkOutcomeReceived, CHK_OUT_TYPE_LRW_INC_CHK_CODE)
					&& eligibleCheckOutcome.contains(CHK_OUT_TYPE_LRW_INC_CHK_CODE)) {
				log.debug("LRW Incident check is missing: generating LRW Incident check");
				insertCheckOutcome(CHECK_OUTCOME_STATUS_CODE_PASSED, CHK_OUT_TYPE_LRW_INC_CHK_CODE, existingBookingUuid, bookingVersion);
			}

			if (!StringUtils.contains(checkOutcomeReceived, CHK_OUT_TYPE_SPEAKING_INC_CHK_CODE)
					&& eligibleCheckOutcome.contains(CHK_OUT_TYPE_SPEAKING_INC_CHK_CODE)) {
				log.debug("Speaking Incident check is missing: generating Speaking Incident check");
				insertCheckOutcome(CHECK_OUTCOME_STATUS_CODE_PASSED, CHK_OUT_TYPE_SPEAKING_INC_CHK_CODE, existingBookingUuid, bookingVersion);
			}
		} else {
			log.info("Booking is not present for bookingUuid: {} No action taken", existingBookingUuid);
		}

	}

	void insertCheckOutcome(final String checkOutcomeStatus, final String checkOutcomeTypeCode, final UUID existingBookingUuid,final BigDecimal bookingVersion) {


		CheckOutcome checkOutcome;

		CheckOutcomeType checkOutcomeType = getCheckOutComeType(checkOutcomeTypeCode);
		Optional<CheckOutcome> optionalCheckOutcome = 
				checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
						existingBookingUuid, Optional.ofNullable(checkOutcomeType).map(CheckOutcomeType::getCheckOutcomeTypeUuid).orElse(null));

		if(optionalCheckOutcome.isPresent()) {
			checkOutcome = optionalCheckOutcome.get();
		} else {
			checkOutcome = CheckOutcome.builder()
					.bookingUuid(existingBookingUuid)
					.bookingVersion(bookingVersion)
					.build();
			checkOutcome.setCheckOutcomeType(checkOutcomeType);
		}

		checkOutcome
		.setCheckOutcomeStatus(
				getCheckOutComeStatus(checkOutcomeStatus));
		checkOutcome.setEventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime());
		checkOutcomeRepository.save(checkOutcome);

		Optional<OutcomeStatus> optionalOutcomeStatus = outcomeStatusRepository
				.findByBookingUuid(existingBookingUuid);
		OutcomeStatus outcomeStatus = optionalOutcomeStatus.orElseGet(() -> OutcomeStatus.builder().build());
		outcomeStatus.setCheckOutcomeEventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime());
		outcomeStatus.setBookingVersion(checkOutcome.getBookingVersion());
		outcomeStatusRepository.save(outcomeStatus);
		publishIntegrityCheckInitiatedEvent(checkOutcome, existingBookingUuid);
	}

	private CheckOutcomeType getCheckOutComeType(String checkOutcomeTypeCode) {
		CheckOutcomeType checkOutcomeType = null;
		Optional<CheckOutcomeType> optionalCheckOutcomeStatus =
				checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(
						checkOutcomeTypeCode);
		if (optionalCheckOutcomeStatus.isPresent()) {
			checkOutcomeType = optionalCheckOutcomeStatus.get();
		}
		return checkOutcomeType;
	}

	private CheckOutcomeStatus getCheckOutComeStatus(String checkOutcomeStatusCode) {

		CheckOutcomeStatus checkOutcomeStatus = new CheckOutcomeStatus();

		Optional<CheckOutcomeStatus> optionalCheckOutcomeStatus = checkOutcomeStatusRepository
				.findByCheckOutcomeStatusCode(checkOutcomeStatusCode);
		if (optionalCheckOutcomeStatus.isPresent()) {
			checkOutcomeStatus = optionalCheckOutcomeStatus.get();
		}
		return checkOutcomeStatus;
	}

	void publishIntegrityCheckInitiatedEvent(final CheckOutcome checkOutcome, final UUID bookingUuid) {
		CMDSHeaderContext baseHeader = new CMDSHeaderContext();
		buildHeader(baseHeader);
		IntegrityCheckInitiatedV1 integrityCheckInitiatedV1 = populateIntegrityCheckEvent(checkOutcome, bookingUuid);

		// raise an internal event
		publishEvent(integrityCheckInitiatedV1);
	}

	private IntegrityCheckInitiatedV1 populateIntegrityCheckEvent(final CheckOutcome checkOutcome, UUID bookingUuid) {
		IntegrityCheckInitiatedV1 integrityCheckInitiatedV1=new IntegrityCheckInitiatedV1();
		integrityCheckInitiatedV1.bookingUuid((bookingUuid));
		integrityCheckInitiatedV1.checkOutcome(getCheckOutcome(checkOutcome));
		integrityCheckInitiatedV1.setBookingVersion(checkOutcome.getBookingVersion());

		return integrityCheckInitiatedV1;
	}

	private CheckOutcomeV1 getCheckOutcome(final CheckOutcome checkOutcome) {

		CheckOutcomeV1 checkOutcomeV1 = new CheckOutcomeV1();

		checkOutcomeV1.setCheckOutcomeTypeUuid(
				checkOutcome.getCheckOutcomeType().getCheckOutcomeTypeUuid());
		checkOutcomeV1.setCheckOutcomeStatusUuid(
				checkOutcome.getCheckOutcomeStatus().getCheckOutcomeStatusUuid());

		return checkOutcomeV1;
	}

	private void buildHeader(final CMDSHeaderContext eventHeader) {
		eventHeader.setCorrelationId(ThreadLocalHeaderContext.getContext().getCorrelationId());
		eventHeader.setEventDateTime(LocalDateTime.now(ZoneOffset.UTC));
		eventHeader.setTransactionId(ThreadLocalHeaderContext.getContext().getTransactionId());
		eventHeader.setEventName(EventType.INTEGRITY_CHECK_INITIATED);
		ThreadLocalHeaderContext.clearContext();
		ThreadLocalHeaderContext.setContext(eventHeader);
	}

}
