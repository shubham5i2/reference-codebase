package com.ielts.cmds.ri.utils;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.common.model.out.IncidentSearchCriteriaV1;
import com.ielts.cmds.ri.common.model.out.SearchIncidentRequestV1;
import com.ielts.cmds.ri.infrastructure.entity.IncidentView;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.function.BiFunction;
@Slf4j
@Component
public class IncidentSearchSpecification implements BiFunction<SearchIncidentRequestV1,Set<UUID>, Specification<IncidentView>>{
	@Override
	public Specification<IncidentView> apply(
	    final SearchIncidentRequestV1 searchIncidents, Set<UUID> commonAccessibleLocation) {
	    return (root, criteriaQuery, criteriaBuilder) -> {
	        IncidentSearchCriteriaV1 searchCriteria = searchIncidents.getCriteria();
	        List<Predicate> predicates = new ArrayList<>();
	        Method[] declaredMethods = searchCriteria.getClass().getDeclaredMethods();
	        for (Method method : declaredMethods) {
	            if (StringUtils.startsWith(method.getName(), "get")) {
	            	addingPredicatesForIncidentSearchCriteria(root, criteriaBuilder, searchCriteria, commonAccessibleLocation, predicates, method);
	            }
	        }
	        return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
	    };
	}
	void addingPredicatesForIncidentSearchCriteria(
	    Root<IncidentView> root, CriteriaBuilder criteriaBuilder,
	    IncidentSearchCriteriaV1 searchCriteria, Set<UUID> commonAccessibleLocation,
	    List<Predicate> predicates, Method method) {
	    try {
	        Object value = method.invoke(searchCriteria);
	        if (StringUtils.contains(method.getName(), "getIncidentSeverity")
	                && StringUtils.isNotBlank(searchCriteria.getIncidentSeverity())) {
	            addIncidentSeverityPredicate(criteriaBuilder, root, searchCriteria, predicates);
	        } else if (StringUtils.contains(method.getName(), "getTestDateFrom")
	                || StringUtils.contains(method.getName(), "getTestDateTo")) {
	            addTestDatePredicate(criteriaBuilder, root, searchCriteria, predicates);
	        } else if (StringUtils.contains(method.getName(), "getLocationUuid")) {
	            addLocationUuidPredicate(criteriaBuilder, root, commonAccessibleLocation, predicates);
	        } else {
	            buildCriteria(predicates, criteriaBuilder, root, value, method);
	        }
	    } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
	        handleMethodInvocationException(ex);
	    }
	}
	private void addIncidentSeverityPredicate(
	    CriteriaBuilder criteriaBuilder, Root<IncidentView> root,
	    IncidentSearchCriteriaV1 searchCriteria, List<Predicate> predicates) {
	    predicates.add(criteriaBuilder.and(
	        criteriaBuilder.equal(root.get("incidentSeverity"), searchCriteria.getIncidentSeverity())));
	}
	private void addTestDatePredicate(
	    CriteriaBuilder criteriaBuilder, Root<IncidentView> root,
	    IncidentSearchCriteriaV1 searchCriteria, List<Predicate> predicates) {
	    predicates.add(criteriaBuilder.and(
	        criteriaBuilder.greaterThanOrEqualTo(root.get("testDate"), searchCriteria.getTestDateFrom()),
	        criteriaBuilder.lessThanOrEqualTo(root.get("testDate"), searchCriteria.getTestDateTo())));
	}
	private void addLocationUuidPredicate(
	    CriteriaBuilder criteriaBuilder, Root<IncidentView> root,
	    Set<UUID> commonAccessibleLocation, List<Predicate> predicates) {
	    predicates.add(criteriaBuilder.and(
	        root.get("locationUuid").in(commonAccessibleLocation)));
	}
	protected void handleMethodInvocationException(Exception ex) {
	    log.warn("Error in method invocation", ex);
	    throw new ResultIntegrityException("Exception  {}" + ex);
	}
  protected List<Predicate> buildCriteria(
      List<Predicate> predicates,
      CriteriaBuilder criteriaBuilder,
      Root<IncidentView> root,
      Object objectValue,
      Method method) {
    if (!ObjectUtils.isEmpty(objectValue)) {
      String methodName = StringUtils.substringAfter(method.getName(), "get");
      String field = methodName.substring(0, 1).toLowerCase().concat(methodName.substring(1));
      if (StringUtils.equals(field, "shortCandidateNumber")) {
        objectValue = Integer.valueOf(String.valueOf(objectValue));
      }
      if (objectValue instanceof String) {
        predicates.add(
            criteriaBuilder.and(
                criteriaBuilder.equal(
                    (criteriaBuilder.lower(root.get(field))),
                    String.valueOf(objectValue).toLowerCase())));
      } else {
        predicates.add(criteriaBuilder.and(criteriaBuilder.equal((root.get(field)), objectValue)));
      }
    }
    return predicates;
  }
}
