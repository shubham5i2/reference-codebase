package com.ielts.cmds.ri.domain.enums;

import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;

public enum ExternalIncidentStatusEnum {
  FLAGGED("FLAGGED"),
  CLEARED("CLEARED"),
  CONFIRMED("CONFIRMED");


  private String value;

  ExternalIncidentStatusEnum(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }

  @Override
  public String toString() {
    return String.valueOf(value);
  }

  public static ExternalIncidentStatusEnum fromValue(String text) {
    for (ExternalIncidentStatusEnum i : ExternalIncidentStatusEnum.values()) {
      if (String.valueOf(i.value).equals(text)) {
        return i;
      }
    }
    return null;
  }

  public static class Adapter extends TypeAdapter<ExternalIncidentStatusEnum> {
    @Override
    public void write(final JsonWriter jsonWriter, final ExternalIncidentStatusEnum enumeration)
        throws IOException {
      jsonWriter.value(enumeration.getValue());
    }

    @Override
    public ExternalIncidentStatusEnum read(final JsonReader jsonReader) throws IOException {
      String value = jsonReader.nextString();
      return ExternalIncidentStatusEnum.fromValue(String.valueOf(value));
    }
  }

}
