package com.ielts.cmds.ri.domain.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.evt_019.BookingDetailsV1;
import com.ielts.cmds.ri.infrastructure.repository.BookingLineRepository;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.UniqueTestTakerRepository;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.EnableOutboundEventV2;

@Service
@EnableOutboundEventV2
public class BookingCancelledDomainService extends CommonBookingDomainService {

    @Autowired
    public BookingCancelledDomainService(ApplicationEventPublisher publisher,
                                         ObjectMapper objectMapper,
                                         @Value("${resultIntegrityBookingConsumed.v2}") String isV2Enabled,
                                         CMDSThreadLocalContextService cmdsThreadLocalContextService,
                                         BookingRepository bookingRepository,
                                         BookingLineRepository bookingLineRepository,
                                         UniqueTestTakerRepository uniqueTestTakerRepository,
                                         OutcomeStatusRepository outcomeStatusRepository,
                                         OutcomeStatusTypeRepository outcomeStatusTypeRepository,
                                         BookingUpdateIdCheckOutcomeDomainService bookingUpdateIdCheckOutcomeDomainService,
                                         TTUpdateDomainService ttUpdateDomainService) {
        super(publisher,
                objectMapper,
                isV2Enabled,
                cmdsThreadLocalContextService,
                bookingRepository,
                bookingLineRepository,
                uniqueTestTakerRepository,
                outcomeStatusRepository,
                outcomeStatusTypeRepository,
                bookingUpdateIdCheckOutcomeDomainService,
                ttUpdateDomainService);
    }

    @Transactional
    public void on(BookingDetailsV1 bookingDetails) {
        process(bookingDetails);
    }
}

