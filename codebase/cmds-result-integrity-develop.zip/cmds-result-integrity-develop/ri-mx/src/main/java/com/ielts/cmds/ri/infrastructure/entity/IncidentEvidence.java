package com.ielts.cmds.ri.infrastructure.entity;

import java.util.Collection;
import java.util.UUID;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Builder
@Data
@EqualsAndHashCode(callSuper = true)
@Table(name = "incident_evidence")
@NoArgsConstructor
@AllArgsConstructor
public class IncidentEvidence extends CommonModel {

  @Id
  @GeneratedValue(generator = "UUID")
  @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
  @Column(name = "incident_evidence_uuid")
  private UUID incidentEvidenceUuid;
  

  @Basic
  @Column(name = "incident_evidence_name")
  private String incidentEvidenceName;
  

  @Basic
  @Column(name = "incident_evidence_url")
  private String incidentEvidenceUrl;
  

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "incident_uuid", referencedColumnName = "incident_uuid", nullable = false)
  private Incident incidentByIncidentUuid;
  

  @OneToMany(mappedBy = "incidentEvidenceByIncidentEvidenceUuid", cascade = CascadeType.ALL)
  private Collection<PrcOutcomeDetails> prcOutcomeDetailsByIncidentEvidenceUuid;
  

  @Column(name = "incident_uuid", insertable = false, updatable = false)
  private UUID incidentUuid;

}
