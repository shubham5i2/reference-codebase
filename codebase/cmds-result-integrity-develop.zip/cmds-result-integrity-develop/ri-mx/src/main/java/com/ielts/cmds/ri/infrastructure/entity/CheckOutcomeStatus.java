package com.ielts.cmds.ri.infrastructure.entity;

import java.time.OffsetDateTime;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "check_outcome_status")
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class CheckOutcomeStatus {

	@Id
	@Column(name = "check_outcome_status_uuid")
	private UUID checkOutcomeStatusUuid;
	
	@Column(name = "check_outcome_status")
	private String checkOutcomeStatus;
	
	@Column(name = "check_outcome_status_code")
	private String checkOutcomeStatusCode;
	
	@Column(name = "effective_from_date")
	private OffsetDateTime effectiveFromDate;
	
	@Column(name = "effective_to_date")
	private OffsetDateTime effectiveToDate;
	
	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "created_datetime")
	private OffsetDateTime createdDatetime;
	
	@Column(name = "updated_by")
	private String updatedBy;
	
	@Column(name = "updated_datetime")
	private OffsetDateTime updatedDatetime;
	
	@Column(name = "concurrency_version")
	@Version
	private Integer concurrencyVersion;


}
