package com.ielts.cmds.ri.application.service;

import com.ielts.cmds.common.config.IBaseAuditService;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.common.model.out.OverallIntegrityCheckInitiatedV1;
import com.ielts.cmds.ri.domain.service.OverallIntegrityCheckDomainService;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.service.IApplicationServiceV2;
import com.ielts.cmds.serialization.utils.ServiceIdentifier;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.PessimisticLockingFailureException;
import org.springframework.stereotype.Service;

@Service
@ServiceIdentifier(RIConstants.EventType.OVERALL_INTEGRITY_CHECK_INITIATED)
@Slf4j
public class OverallIntegrityCheckService implements IApplicationServiceV2<OverallIntegrityCheckInitiatedV1>, IBaseAuditService {

  @Autowired
  OverallIntegrityCheckDomainService overallIntegrityCheckDomainService;

  @SneakyThrows
  @Override
  public void process(OverallIntegrityCheckInitiatedV1 overallIntegrityCheckInitiatedV1) {
    try {
      log.info(
          "OverallIntegrityCheckInitiated process started for request with transactionId:{}",
          ThreadLocalHeaderContext.getContext().getTransactionId());

      if (overallIntegrityCheckInitiatedV1 == null) {
        throw new IllegalArgumentException("Payload is Empty");
      }

      populateAuditFields();

      overallIntegrityCheckDomainService.on();

    } catch (PessimisticLockingFailureException e) {
      log.info(
          "Another instance of {} is already running",
          RIConstants.EventType.OVERALL_INTEGRITY_CHECK_INITIATED);
      log.warn("Failed to process OverallIntegrityCheck due to  ", e);
    } catch (IllegalArgumentException e) {
      log.error("Failed to process RI event due to ", e);
      throw new ProcessingException(e.getMessage(), e);
    }
  }

  @Override
  public String getPermission() {
    return null;
  }

  @Override
  public String getScreen() {
    return null;
  }

  @Override
  public String getAction() {
    return OverallIntegrityCheckService.class.getSimpleName();
  }
}
