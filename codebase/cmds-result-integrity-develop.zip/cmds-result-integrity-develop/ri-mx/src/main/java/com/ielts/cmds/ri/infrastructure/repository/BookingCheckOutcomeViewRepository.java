package com.ielts.cmds.ri.infrastructure.repository;

import com.ielts.cmds.ri.infrastructure.entity.BookingCheckOutcomeView;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface BookingCheckOutcomeViewRepository
    extends JpaSpecificationExecutor<BookingCheckOutcomeView>,
        JpaRepository<BookingCheckOutcomeView, UUID> {}
