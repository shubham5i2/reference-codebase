package com.ielts.cmds.ri.infrastructure.repository;

import com.ielts.cmds.ri.infrastructure.entity.UniqueTestTaker;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;
@Repository
public interface UniqueTestTakerRepository extends JpaRepository<UniqueTestTaker, UUID> {

   Optional<UniqueTestTaker> findByUniqueTestTakerUuid (UUID uniqueTestTakerUuid);

}
