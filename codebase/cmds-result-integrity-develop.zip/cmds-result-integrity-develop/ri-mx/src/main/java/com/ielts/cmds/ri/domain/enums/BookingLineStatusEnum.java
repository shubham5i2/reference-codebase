package com.ielts.cmds.ri.domain.enums;

public enum BookingLineStatusEnum {
  ACTIVE("ACTIVE"),
  INACTIVE("INACTIVE");

  private String value;

  BookingLineStatusEnum(String value) {
    this.value = value;
  }

  public String getValue() {
    return this.value;
  }

  @Override
  public String toString() {
    return String.valueOf(this.value);
  }

}
