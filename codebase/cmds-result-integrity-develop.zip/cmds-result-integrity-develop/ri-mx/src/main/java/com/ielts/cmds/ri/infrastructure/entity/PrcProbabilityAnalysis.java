package com.ielts.cmds.ri.infrastructure.entity;

import java.math.BigDecimal;
import java.util.UUID;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Builder
@Data
@EqualsAndHashCode(callSuper = true, exclude={"prcOutcomeDetailsByPrcOutcomeDetailsUuid"})
@Table(name = "prc_probability_analysis")
@NoArgsConstructor
@AllArgsConstructor
public class PrcProbabilityAnalysis extends CommonModel  {
   
    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
    @Column(name = "prc_probability_analysis_uuid")
    private UUID prcProbabilityAnalysisUuid;
    

    @Basic
    @Column(name = "mean_judgemental")
    private BigDecimal meanJudgemental;
    

    @Basic
    @Column(name = "r_band_score_country_reg")
    private BigDecimal rBandScoreCountryReg;
    

    @Basic
    @Column(name = "r_band_score_res")
    private BigDecimal rBandScoreRes;
    

    @Basic
    @Column(name = "r_band_score_std_res")
    private BigDecimal rBandScoreStdRes;
    

    @Basic
    @Column(name = "r_band_score_flag")
    private String rBandScoreFlag;
    

    @Basic
    @Column(name = "l_band_score_flag")
    private String lBandScoreFlag;
    

    @Basic
    @Column(name = "l_band_score_country_reg")
    private BigDecimal lBandScoreCountryReg;
    

    @Basic
    @Column(name = "l_band_score_res")
    private BigDecimal lBandScoreRes;
    

    @Basic
    @Column(name = "l_band_score_std_res")
    private BigDecimal lBandScoreStdRes;
    

    @ManyToOne
    @JoinColumn(name = "prc_outcome_details_uuid", referencedColumnName = "prc_outcome_details_uuid", nullable = false)
    private PrcOutcomeDetails prcOutcomeDetailsByPrcOutcomeDetailsUuid;

}
