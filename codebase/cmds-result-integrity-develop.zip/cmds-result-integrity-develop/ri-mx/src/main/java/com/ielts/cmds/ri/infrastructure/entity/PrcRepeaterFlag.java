package com.ielts.cmds.ri.infrastructure.entity;

import java.util.UUID;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Builder
@Data
@EqualsAndHashCode(callSuper = true, exclude = {"prcRepeaterAnalysisByPrcRepeaterAnalysisUuid"})
@Table(name = "prc_repeater_flag")
@NoArgsConstructor
@AllArgsConstructor
public class PrcRepeaterFlag extends CommonModel {
    
    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
    @Column(name = "prc_repeater_flag_uuid")
    private UUID prcRepeaterFlagUuid;
    
    @Basic
    @Column(name = "flagged_for")
    private String flaggedFor;
    

    @ManyToOne
    @JoinColumn(name = "prc_repeater_analysis_uuid", referencedColumnName = "prc_repeater_analysis_uuid", nullable = false)
    private PrcRepeaterAnalysis prcRepeaterAnalysisByPrcRepeaterAnalysisUuid;

}
