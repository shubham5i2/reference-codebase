package com.ielts.cmds.ri.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.context.CMDSErrorContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalErrorContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.rbac.api.service.JWTDecoder;
import com.ielts.cmds.rbac.api.service.LocationHierarchyService;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.api.service.model.ClaimDetails;
import com.ielts.cmds.rbac.api.service.model.CmdsAuthentication;
import com.ielts.cmds.rbac.api.utils.RBACServiceUtils;
import com.ielts.cmds.ri.common.model.out.BookingDetailsV1;
import com.ielts.cmds.ri.common.model.out.IncidentSearchCriteriaV1;
import com.ielts.cmds.ri.common.model.out.IncidentSearchResultDetailsV1;
import com.ielts.cmds.ri.common.model.out.IncidentSearchResultListV1;
import com.ielts.cmds.ri.common.model.out.IncidentSearchResultListV1Inner;
import com.ielts.cmds.ri.common.model.out.IncidentSearchResultV1;
import com.ielts.cmds.ri.common.model.out.IncidentSearchResultV1Result;
import com.ielts.cmds.ri.common.model.out.IncidentSeverityEnum;
import com.ielts.cmds.ri.common.model.out.ResultIntegrityIncidentDetailsV1;
import com.ielts.cmds.ri.common.model.out.SearchIncidentRequestV1;
import com.ielts.cmds.ri.common.model.out.SearchPaginationV1;
import com.ielts.cmds.ri.common.model.out.SearchSortV1;
import com.ielts.cmds.ri.common.model.out.SearchSortV1Item;
import com.ielts.cmds.ri.infrastructure.entity.IncidentView;
import com.ielts.cmds.ri.infrastructure.repository.IncidentViewRepository;
import com.ielts.cmds.ri.utils.IncidentSearchSpecification;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.ConstraintViolation;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

import static com.ielts.cmds.ri.utils.RIConstants.ErrorCodes.UNAUTHORISED_TO_ACCESS_WITH_SELECTED_LOCATION;
import static com.ielts.cmds.ri.utils.RIConstants.ErrorCodes.UNAUTHORISED_TO_SEARCH;
import static com.ielts.cmds.ri.utils.RIConstants.GenericConstants.TEST_CENTRE;
import static com.ielts.cmds.ri.utils.RIConstants.PermissionId.RI_INCIDENT_SEARCH;

@Slf4j
@Service
public class IncidentSearchDomainService extends AbstractCMDSDomainService<IncidentSearchResultV1> {

  private final CMDSErrorResolver<Object> errorResolver;

  private final RICommonUtil commonUtils;

  private final IncidentViewRepository incidentViewRepository;

  private final JWTDecoder jwtDecoder;

  private final LocationHierarchyService locationHierarchyService;

  private final IncidentSearchSpecification searchSpecification;

  @Autowired
  public IncidentSearchDomainService(ApplicationEventPublisher publisher,
                                     ObjectMapper objectMapper,
                                     @Value("${incidentSearchResponseGenerated.v2}") String isV2Enabled,
                                     CMDSThreadLocalContextService cmdsThreadLocalContextService,
                                     CMDSErrorResolver<Object> errorResolver,
                                     RICommonUtil commonUtils,
                                     IncidentViewRepository incidentViewRepository,
                                     JWTDecoder jwtDecoder,
                                     LocationHierarchyService locationHierarchyService,
                                     IncidentSearchSpecification searchSpecification) {
    super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
    this.errorResolver = errorResolver;
    this.commonUtils = commonUtils;
    this.incidentViewRepository = incidentViewRepository;
    this.jwtDecoder = jwtDecoder;
    this.locationHierarchyService = locationHierarchyService;
    this.searchSpecification = searchSpecification;
  }

  @Transactional(noRollbackFor = RuntimeException.class)
  public void on(final SearchIncidentRequestV1 searchIncidents)
      throws JsonProcessingException, RbacValidationException {

    log.debug("IncidentSearchDomainService.onCommand : {}", searchIncidents);


    if (!commonUtils.hasAllAccess(
        ThreadLocalHeaderContext.getContext().getXaccessToken(), RI_INCIDENT_SEARCH)) {
      log.info(
          "You are not authorised to access this screen. Please contact your administer if you do not think this correct. ");
      Set<ConstraintViolation<Object>> violations =
          RICommonUtil.getSetforNullViolationOfEventBody(
              UNAUTHORISED_TO_SEARCH, "unauthorisedToSearchIncident");
      publishEventToOutBoundTopic(null, violations);
    }
    else {
      Pageable pageObj =
          PageRequest.of(
                  searchIncidents.getPagination().getPageNumber(),
                  searchIncidents.getPagination().getPageSize(),
              Sort.by(getSortDirection(searchIncidents.getSorting())));

          Set<UUID> accessibleLocations = getAccessibleLocations();
          Set<UUID> accessibleLocationsForBooking = getChildLocations(searchIncidents.getCriteria());
          Set<UUID> commonAccessibleLocations = getCommonAccessibleLocations(accessibleLocations, accessibleLocationsForBooking);

      if (Objects.isNull(commonAccessibleLocations)) {
        log.info(
            "You are not authorised to access with the selected Location. Please contact your administer if you do not think this correct.");
        Set<ConstraintViolation<Object>> violations =
            RICommonUtil.getSetforNullViolationOfEventBody(
                UNAUTHORISED_TO_ACCESS_WITH_SELECTED_LOCATION,
                "unauthorisedToAccessWithSelectedLocation");
        publishEventToOutBoundTopic(null, violations);

      } else {

        Specification<IncidentView> incidentSpecification;

        if (Objects.nonNull(searchIncidents.getCriteria().getLocationUuid())) {
          incidentSpecification = searchSpecification.apply(searchIncidents, commonAccessibleLocations);
        } else {
          incidentSpecification = searchSpecification.apply(searchIncidents, accessibleLocations);
        }

        Page<IncidentView> incidentPage = incidentViewRepository.findAll(incidentSpecification, pageObj);

        IncidentSearchResultV1 incidentSearchResultResponse =
            mapIncidentToSearchIncidentEvent(searchIncidents, incidentPage.getContent(), incidentPage.getTotalElements());

        publishEventToOutBoundTopic(incidentSearchResultResponse, null);
      }
    }
  }


  public void publishEventToOutBoundTopic(
      final IncidentSearchResultV1 incidentSearchResultResponse,
      final Set<ConstraintViolation<Object>> violations) {

    ThreadLocalHeaderContext.getContext().setEventName(RIConstants.EventType.INCIDENT_SEARCH_RESPONSE_GENERATED);
    ThreadLocalHeaderContext.getContext().setEventDateTime(LocalDateTime.now());

    log.info("IncidentSearchDomainService |publishEventToOutBoundTopic: {}", ThreadLocalHeaderContext.getContext().getEventName());

    if (Objects.nonNull(incidentSearchResultResponse)) {
        commonUtils.publishLog();
        publishEvent(incidentSearchResultResponse);
    } else {
      if (CollectionUtils.isNotEmpty(violations)) {
        CMDSErrorResponse eventErrors =
            errorResolver.populatErrorResponse(
                violations, ThreadLocalHeaderContext.getContext().getEventName());
        ThreadLocalErrorContext.setContext(new CMDSErrorContext(eventErrors.getErrorList()));
      }
      commonUtils.publishLog();
      publishEvent(null, ThreadLocalErrorContext.getContext().getErrorList());
    }
  }

  private IncidentSearchResultV1 mapIncidentToSearchIncidentEvent(
      final SearchIncidentRequestV1 searchIncidents,
      final List<IncidentView> incidentViewList,
      final long totalNumberOfRecords) throws RbacValidationException {

    IncidentSearchResultV1Result entries = new IncidentSearchResultV1Result();
    IncidentSearchResultV1 incidentSearchResultV1 = new IncidentSearchResultV1();

    SearchIncidentRequestV1 searchRequestV1 =
        SearchIncidentRequestV1.builder()
            .criteria(getUserSearchRequestCriteria(searchIncidents))
            .pagination(getSearchPaginationV1(searchIncidents))
            .sorting(getSearchSorting(searchIncidents))
            .build();

    IncidentSearchResultListV1 resultListV1 = setIncidentEntries(incidentViewList);

    entries.setTotalCount(String.valueOf((totalNumberOfRecords)));
    entries.setEntries(resultListV1);

    incidentSearchResultV1.setSearch(searchRequestV1);
    incidentSearchResultV1.setResult(entries);
    log.debug("IncidentSearchDomainService |incidentSearchResultV1 {}", incidentSearchResultV1);
    return incidentSearchResultV1;
  }

  private IncidentSearchResultListV1 setIncidentEntries(final List<IncidentView> incidentViews)
      throws RbacValidationException {
    IncidentSearchResultListV1 incidentSearchResultListV1 = new IncidentSearchResultListV1();

    for (IncidentView incident : incidentViews) {

      IncidentSearchResultDetailsV1 resultV1 = new IncidentSearchResultDetailsV1();
      BookingDetailsV1 bookingDetailsV1 = new BookingDetailsV1();

      bookingDetailsV1.setBookingUuid(incident.getBookingUuid().toString());
      bookingDetailsV1.setUniqueTestTakerId(incident.getUniqueTestTakerId());
      bookingDetailsV1.setUniqueTestTakerUuid(incident.getUniqueTestTakerUuid().toString());
      bookingDetailsV1.setFirstName(incident.getFirstName());
      bookingDetailsV1.setLastName(incident.getLastName());
      bookingDetailsV1.setShortCandidateNumber(incident.getShortCandidateNumber());
      bookingDetailsV1.setIdentityNumber(incident.getIdentityNumber());
      bookingDetailsV1.setTestDate(incident.getTestDate());
      if (Objects.nonNull(incident.getLocationUuid())) {
        bookingDetailsV1.setLocationUuid(String.valueOf(
            commonUtils.getParentNode(incident.getLocationUuid(), TEST_CENTRE).getLocationUuid()));
      }
      bookingDetailsV1.setProductUuid(incident.getProductUuid().toString());

      ResultIntegrityIncidentDetailsV1 resultIntegrityDetails =
          new ResultIntegrityIncidentDetailsV1();

      resultIntegrityDetails.setBookingUuid(incident.getBookingUuid().toString());
      resultIntegrityDetails.setIncidentUuid(incident.getIncidentUuid().toString());
      resultIntegrityDetails.setIncidentCategoryUuid(incident.getIncidentCategoryUuid().toString());
      resultIntegrityDetails.setIncidentStatusTypeUuid(
          incident.getIncidentStatusTypeUuid().toString());
      resultIntegrityDetails.setIncidentTypeUuid(incident.getIncidentTypeUuid().toString());
      if (Objects.nonNull(incident.getIncidentSeverity())) {
        resultIntegrityDetails
            .setIncidentSeverity(IncidentSeverityEnum.valueOf(incident.getIncidentSeverity()));
      }
      resultIntegrityDetails.setBanReviewRequired(incident.getBanReviewRequired());

      resultV1.setBookingDetails(bookingDetailsV1);
      resultV1.setIncidentDetails(resultIntegrityDetails);

      IncidentSearchResultListV1Inner resultList =
          IncidentSearchResultListV1Inner.builder().incidentBookingDetails(resultV1).build();

      incidentSearchResultListV1.add(resultList);
    }
    return incidentSearchResultListV1;
  }

  public Set<UUID> getAccessibleLocations() throws RbacValidationException {

      CmdsAuthentication decodeAccessToken =
          this.jwtDecoder.decodeAccessToken(ThreadLocalHeaderContext.getContext().getXaccessToken());
      List<ClaimDetails> claimDetailsList = RBACServiceUtils.getClaimList(decodeAccessToken);
      if (!CollectionUtils.isEmpty(claimDetailsList)) {
        Set<UUID> claimedLocationSet = new HashSet<>();
        for (ClaimDetails claim : claimDetailsList) {
          claimedLocationSet.addAll(locationHierarchyService.getUuidsOfLocationBranchByLocationUuid(
              claim.getLocationUuid(), LocalDate.now()));

        }
        return claimedLocationSet;
      }
    return Collections.emptySet();
  }

  public Set<UUID> getChildLocations(IncidentSearchCriteriaV1 incidentSearchCriteriaV1)
      throws RbacValidationException {
    Set<UUID> searchCriteriaLocationSet = new HashSet<>();
    if (Objects.nonNull(incidentSearchCriteriaV1.getLocationUuid())) {

      searchCriteriaLocationSet = locationHierarchyService.getUuidsOfLocationBranchByLocationUuid(
          incidentSearchCriteriaV1.getLocationUuid(), LocalDate.now());
    }
    return searchCriteriaLocationSet;
  }

  public Set<UUID> getCommonAccessibleLocations(Set<UUID> claimedLocationSet, Set<UUID> searchCriteriaLocationSet){

    Set<UUID> intersection= new HashSet<>(claimedLocationSet);
     intersection.retainAll(searchCriteriaLocationSet);
     return intersection;

  }



  private SearchSortV1 getSearchSorting(final SearchIncidentRequestV1 searchIncident) {
    SearchSortV1 searchSort = new SearchSortV1();
    for (SearchSortV1Item sortItem : searchIncident.getSorting()) {
      SearchSortV1Item searchSortItemV1 =
          SearchSortV1Item.builder()
              .sortBy(sortItem.getSortBy())
              .sortType(sortItem.getSortType())
              .build();
      searchSort.add(searchSortItemV1);
    }
    return searchSort;
  }

  private SearchPaginationV1 getSearchPaginationV1(final SearchIncidentRequestV1 searchIncidents) {

    return SearchPaginationV1.builder()
        .pageNumber(searchIncidents.getPagination().getPageNumber())
        .pageSize(searchIncidents.getPagination().getPageSize())
        .build();
  }

  private IncidentSearchCriteriaV1 getUserSearchRequestCriteria(
      final SearchIncidentRequestV1 searchIncident) {
    return IncidentSearchCriteriaV1.builder()
        .uniqueTestTakerId(searchIncident.getCriteria().getUniqueTestTakerId())
        .shortCandidateNumber(searchIncident.getCriteria().getShortCandidateNumber())
        .locationUuid(searchIncident.getCriteria().getLocationUuid())
        .productUuid(searchIncident.getCriteria().getProductUuid())
        .testDateFrom(searchIncident.getCriteria().getTestDateFrom())
        .testDateTo(searchIncident.getCriteria().getTestDateTo())
        .identityNumber(searchIncident.getCriteria().getIdentityNumber())
        .firstName(searchIncident.getCriteria().getFirstName())
        .lastName(searchIncident.getCriteria().getLastName())
        .incidentCategoryUuid(searchIncident.getCriteria().getIncidentCategoryUuid())
        .incidentStatusTypeUuid(searchIncident.getCriteria().getIncidentStatusTypeUuid())
        .incidentTypeUuid(searchIncident.getCriteria().getIncidentTypeUuid())
        .incidentSeverity(searchIncident.getCriteria().getIncidentSeverity())
        .build();
  }

  /**
   * Gets sort direction.
   *
   * @param searchSortItem the search sort item
   * @return the sort direction
   */
  public List<Sort.Order> getSortDirection(final SearchSortV1 searchSortItem) {
    List<Sort.Order> sorts = new ArrayList<>();
    for (SearchSortV1Item sortItem : searchSortItem) {
      if ("asc".equalsIgnoreCase(sortItem.getSortType())) {
        sorts.add(new Sort.Order(Sort.Direction.ASC, sortItem.getSortBy()));
      } else if ("desc".equalsIgnoreCase(sortItem.getSortType())) {
        sorts.add(new Sort.Order(Sort.Direction.DESC, sortItem.getSortBy()));
      }else {
    	  log.debug("Invalid Input");
      }
    }
    return sorts;
  }
}
