package com.ielts.cmds.ri.application.service;

import com.ielts.cmds.ids.domain.model.ReceivedIncidentDetailsV1;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.domain.service.TestDayIncidentDomainService;
import com.ielts.cmds.ri.infrastructure.entity.Incident;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.service.IApplicationServiceV2;
import com.ielts.cmds.serialization.utils.ServiceIdentifier;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@ServiceIdentifier(RIConstants.EventType.IDS_TEST_DAY_INCIDENT_RAISED)
public class TestDayIncidentService implements IApplicationServiceV2<ReceivedIncidentDetailsV1> {

    @Autowired
    TestDayIncidentDomainService testDayIncidentDomainService;

    @Override
    public void process(ReceivedIncidentDetailsV1 receivedIncidentDetailsV1) {
       try {   		
    		Incident incident=testDayIncidentDomainService.on(receivedIncidentDetailsV1);
    		testDayIncidentDomainService.setEvidence(receivedIncidentDetailsV1,incident);
    	}catch(Exception e) {
    		 log.error("Exception Caught in Service: {}", e);
    		 throw new ResultIntegrityException(e.getMessage());
    	}
    }
}
