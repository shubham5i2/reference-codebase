package com.ielts.cmds.ri.infrastructure.entity;

import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.Data;
import lombok.EqualsAndHashCode;

/** Entity class to hold audit columns */
@MappedSuperclass
@Data
@EqualsAndHashCode(exclude = {"updatedDateTime", "createdDateTime"})
@EntityListeners(AuditingEntityListener.class)
public class CommonModel {

    @CreatedDate
    @Column(name = "created_datetime", updatable = false)
    private Instant createdDateTime;

    @LastModifiedDate
    @Column(name = "updated_datetime", insertable = false)
    private Instant updatedDateTime;

    @Version
    @Column(name = "concurrency_version")
    private Integer concurrencyVersion;
}
