package com.ielts.cmds.ri.application.service;

import com.ielts.cmds.common.config.IBaseAuditService;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.domain.service.IncidentViewDomainService;
import com.ielts.cmds.serialization.application.service.IApplicationServiceV2;
import com.ielts.cmds.serialization.utils.ServiceIdentifier;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.ielts.cmds.ri.utils.RIConstants.UiConstants.INCIDENT_VIEW_RESOURCE;
import static com.ielts.cmds.ri.utils.RIConstants.UiConstants.OPERATION_TYPE_GET;

@Slf4j
@Service
@ServiceIdentifier(OPERATION_TYPE_GET+(INCIDENT_VIEW_RESOURCE))
public class IncidentViewService implements IApplicationServiceV2<Object>, IBaseAuditService {

  @Autowired
  IncidentViewDomainService incidentViewDomainService;

  @SneakyThrows
  @Override
  public void process(Object emptyPayload) {
    log.debug(
        "ViewIncidentService process started for request with transactionId:{}",
        ThreadLocalHeaderContext.getContext().getTransactionId());
    try {
        incidentViewDomainService.on();
    } catch (Exception e) {
      log.error("Exception: {}", e.getMessage());
      incidentViewDomainService.publishEventToOutBoundTopic(null, null);
    }
  }

  @Override
  public String getPermission() {
    return null;
  }

  @Override
  public String getScreen() {
    return null;
  }

  @Override
  public String getAction() {
    return IncidentViewService.class.getSimpleName();
  }
}
