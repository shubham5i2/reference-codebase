package com.ielts.cmds.ri.domain.service;

import static java.time.ZoneOffset.UTC;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.RI_Event002_ResultIntegrityBookingConsumed.ResultIntegrityBookingConsumedV1;
import com.ielts.cmds.api.evt_019.BookingDetailsV1;
import com.ielts.cmds.common.persistence.utils.CMDSOffsetDatetime;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.application.exception.ResultIntegrityValidationException;
import com.ielts.cmds.ri.domain.enums.BookingLineStatusEnum;
import com.ielts.cmds.ri.domain.enums.BookingRoleEnum;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.BookingLine;
import com.ielts.cmds.ri.infrastructure.entity.BookingLink;
import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatusType;
import com.ielts.cmds.ri.infrastructure.entity.UniqueTestTaker;
import com.ielts.cmds.ri.infrastructure.repository.BookingLineRepository;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.UniqueTestTakerRepository;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CommonBookingDomainService extends AbstractCMDSDomainService<ResultIntegrityBookingConsumedV1> {

    private BookingRepository bookingRepository;

    private BookingLineRepository bookingLineRepository;

    private UniqueTestTakerRepository uniqueTestTakerRepository;

    private OutcomeStatusRepository outcomeStatusRepository;

    private OutcomeStatusTypeRepository outcomeStatusTypeRepository;

    private BookingUpdateIdCheckOutcomeDomainService bookingUpdateIdCheckOutcomeDomainService;

    private TTUpdateDomainService ttUpdateDomainService;


    @Autowired
    CommonBookingDomainService(ApplicationEventPublisher publisher,
                               ObjectMapper objectMapper,
                               String isV2Enabled,
                               CMDSThreadLocalContextService cmdsThreadLocalContextService,
                               BookingRepository bookingRepository,
                               BookingLineRepository bookingLineRepository,
                               UniqueTestTakerRepository uniqueTestTakerRepository,
                               OutcomeStatusRepository outcomeStatusRepository,
                               OutcomeStatusTypeRepository outcomeStatusTypeRepository,
                               BookingUpdateIdCheckOutcomeDomainService bookingUpdateIdCheckOutcomeDomainService,
                               TTUpdateDomainService ttUpdateDomainService) {
        super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
        this.bookingRepository = bookingRepository;
        this.bookingLineRepository = bookingLineRepository;
        this.uniqueTestTakerRepository = uniqueTestTakerRepository;
        this.outcomeStatusRepository = outcomeStatusRepository;
        this.outcomeStatusTypeRepository = outcomeStatusTypeRepository;
        this.bookingUpdateIdCheckOutcomeDomainService = bookingUpdateIdCheckOutcomeDomainService;
        this.ttUpdateDomainService=ttUpdateDomainService;
    }

    protected void process(BookingDetailsV1 bookingDetails) {
        log.info("Received event body for bookingUuid : {}", bookingDetails.getBookingUuid());
        Optional<Booking> optionalBooking = bookingRepository.findById(bookingDetails.getBookingUuid());
        ResultIntegrityBookingConsumedV1 builtBookingDetails = null;
        List<ErrorDescription> errorList = new ArrayList<>();
        BaseEventErrors errors = new BaseEventErrors(errorList);
        try {
            if(Objects.isNull(bookingDetails.getTestTaker().getUniqueTestTakerUuid())){
                log.error("No uniqueTestTakerId is allocated for bookingUuid",bookingDetails.getBookingUuid());
                return;
            }
            bookingValidation(bookingDetails, optionalBooking.orElse(null));
            UUID existingUniqueTestTakeUuid= optionalBooking.map(Booking::getUniqueTestTakerUuid).orElse(null);

            Booking booking = updateBookingDetails(bookingDetails, optionalBooking.orElse(null));
            log.info("Booking Created for CommonBookingDomainService: {} ", booking.toString());

            updateOutcomeStatus(booking,RIConstants.PrcOutcomeConstant.OUTCOME_STATUS_TYPE_CODE_NOT_STARTED);

            if(!ThreadLocalHeaderContext.getContext().getEventName().equals(RIConstants.EventType.BOOKING_CANCELLED_EVENT)
                 && !ThreadLocalHeaderContext.getContext().getEventName().equals(RIConstants.EventType.BOOKING_TRANSFERRED_EVENT)) {

                if (optionalBooking.isPresent() && Objects.nonNull(bookingDetails.getTestTaker().getUniqueTestTakerUuid())) {
                    ttUpdateDomainService.resetExistingCheckOutcomes(existingUniqueTestTakeUuid, bookingDetails);
                }
                bookingUpdateIdCheckOutcomeDomainService.updateIdCheckOutcome(booking, bookingDetails.getTestTaker());

            }
            // build outgoing event
            builtBookingDetails = buildBookingDetails(booking);

    		// update header context
            buildHeader(RIConstants.EventType.RESULT_INTEGRITY_BOOKING_CONSUMED);
            log.debug("ResultIntegrityBookingConsumedV1 event header {}, with eventbody {}", ThreadLocalHeaderContext.getContext(), builtBookingDetails);
    		// publish
    		publishEvent(builtBookingDetails);
            
        } catch (final ResultIntegrityValidationException e) {
            log.warn("BookingCommand execution failed", e);
            if (optionalBooking.isPresent()) {
                builtBookingDetails =
                        buildBookingDetails(optionalBooking.get());
            }
            errors = getBaseEventErrors(e);
            buildHeader(RIConstants.EventType.RESULT_INTEGRITY_BOOKING_REJECTED);
            publishEvent(builtBookingDetails,errors.getErrorList());
        }
    }

    public BaseEventErrors getBaseEventErrors(ResultIntegrityValidationException  e) {
        List<ErrorDescription> errorDescriptions = new ArrayList<>();
        ErrorDescription errorDescription = new ErrorDescription();
        errorDescription.setMessage(e.getMessage());
        errorDescription.setType(ErrorTypeEnum.VALIDATION);
        errorDescription.setTitle("Validation Failed");
        errorDescription.setErrorCode("V045");
        errorDescriptions.add(errorDescription);
        return new BaseEventErrors(errorDescriptions);
    }

  public void updateOutcomeStatus(Booking booking, String outcomeStatusCode) {
   Optional<OutcomeStatus> optionalCheckOutcome =
        outcomeStatusRepository.findByBookingUuid(booking.getBookingUuid());
    OutcomeStatus outcomeStatus =
        optionalCheckOutcome.orElseGet(
            () ->
                OutcomeStatus.builder()
                    .outcomeStatusType(
                        getOutcomeStatusType(outcomeStatusCode))
                    .bookingUuid(booking.getBookingUuid())
                    .build());

    outcomeStatusRepository.save(outcomeStatus);
  }

  private OutcomeStatusType getOutcomeStatusType(String outcomeStatusTypeCode) {
    OutcomeStatusType outcomeStatusType;
    Optional<OutcomeStatusType> optionalOutcomeStatus =
        outcomeStatusTypeRepository.findByOutcomeStatusTypeCode(outcomeStatusTypeCode);
    if (optionalOutcomeStatus.isPresent()) {
      outcomeStatusType = optionalOutcomeStatus.get();
    } else {
      throw new ResultIntegrityException(
          "Outcome Status type not found : {}" + outcomeStatusTypeCode);
    }
    return outcomeStatusType;
  }

  private void bookingValidation(
      final BookingDetailsV1 bookingDetails,
      final Booking optionalBooking)
      throws ResultIntegrityValidationException {
    if (Objects.nonNull(optionalBooking)) {
      LocalDateTime localDateTime = optionalBooking.getEventDatetime();
      if (!(ThreadLocalHeaderContext.getContext().getEventDateTime().isAfter(localDateTime))) {
        throw new ResultIntegrityValidationException(
            String.format(
                "Received Event Date time is before this : %s  " + "for this Booking UUID : %s",
                localDateTime, bookingDetails.getBookingUuid()),
            new Throwable());
      }
    }
  }

  protected Booking updateBookingDetails(
      final BookingDetailsV1 bookingDetails,
      final Booking optionalBooking) {
      Booking booking =
        Optional.ofNullable(optionalBooking).orElseGet(
            () ->
                Booking.builder()
                    .bookingUuid(bookingDetails.getBookingUuid())
                    .build());
    UniqueTestTaker persistedUniqueTestTaker = updateUniqueTestTaker(bookingDetails);
    booking.setUniqueTestTaker(persistedUniqueTestTaker);
    booking.setUniqueTestTakerUuid(persistedUniqueTestTaker.getUniqueTestTakerUuid());
    booking.setLocationUuid(bookingDetails.getLocationUuid());
    booking.setProductUuid(bookingDetails.getProductUuid());
    CMDSOffsetDatetime testDate = new CMDSOffsetDatetime(bookingDetails.getTestDate());
    booking.setTestDate(testDate);
    booking.setBirthDate(bookingDetails.getTestTaker().getBirthDate());
    booking.setFirstName(bookingDetails.getTestTaker().getFirstName());
    booking.setLastName(bookingDetails.getTestTaker().getLastName());
    booking.setIdentityNumber(bookingDetails.getTestTaker().getIdentityNumber());
    booking.setShortCandidateNumber(
        Integer.valueOf(bookingDetails.getTestTaker().getShortCandidateNumber()));
    booking.setExternalBookingUuid(bookingDetails.getExternalBookingUuid());
    booking.setCompositeCandidateNumber(
        bookingDetails.getTestTaker().getCompositeCandidateNumber());
    if (bookingDetails.getBookingLines() != null) {
      booking.setBookingLines(updateBookingLineDetails(booking, bookingDetails));
    }
    booking.setBookingStatus(bookingDetails.getBookingStatus().toString());
    if (bookingDetails.getLinkedBookings() != null) {
      booking.setBookingLinks(updateBookingLinkDetails(bookingDetails.getBookingUuid(),bookingDetails));
    }
    booking.setBookingVersion(bookingDetails.getBookingVersion());
    booking.setEventDatetime(ThreadLocalHeaderContext.getContext().getEventDateTime());
    return bookingRepository.save(booking);
  }

    private UniqueTestTaker updateUniqueTestTaker(BookingDetailsV1 bookingDetails) {
        Optional<UniqueTestTaker> optionalUniqueTestTaker =
                uniqueTestTakerRepository.findByUniqueTestTakerUuid(
                        bookingDetails.getTestTaker().getUniqueTestTakerUuid());

        return optionalUniqueTestTaker.orElseGet(
                () -> {
                    UniqueTestTaker uniqueTestTakerToCreate = new UniqueTestTaker();
                    uniqueTestTakerToCreate.setUniqueTestTaker(
                            bookingDetails.getTestTaker().getUniqueTestTakerId());
                    uniqueTestTakerToCreate.setUniqueTestTakerUuid(
                            bookingDetails.getTestTaker().getUniqueTestTakerUuid());
                    return uniqueTestTakerToCreate;
                });
    }

  protected List<BookingLine> updateBookingLineDetails(
      Booking booking, BookingDetailsV1 bookingDetails) {
    return bookingDetails.getBookingLines().stream()
        .map(e -> getBookingLine(booking, e))
        .collect(Collectors.toList());
  }

    private BookingLine getBookingLine(Booking booking, com.ielts.cmds.api.evt_019.BookingLineV1 bookingLine1) {
        BookingLine bookingLine;
        Optional<BookingLine> optionalBookingLine = bookingLineRepository.findById(bookingLine1.getBookingLineUuid());
        bookingLine = optionalBookingLine.orElseGet(() -> {
            BookingLine bookingLineToCreate = new BookingLine();
            bookingLineToCreate.setBookingLineStatus
                    (BookingLineStatusEnum.valueOf(bookingLine1.getBookingLineStatus().toString()));
            bookingLineToCreate.setBooking(booking);
            bookingLineToCreate.setBookingLineUuid(bookingLine1.getBookingLineUuid());
            bookingLineToCreate.setLocationUuid(booking.getLocationUuid());
            bookingLineToCreate.setProductUuid(bookingLine1.getProductUuid());
            bookingLineToCreate.setExternalBookingLineUuid(bookingLine1.getExternalBookingLineUuid());
            bookingLineToCreate.setStartDatetime(bookingLine1.getStartDateTime() != null ?
              OffsetDateTime.ofInstant(bookingLine1.getStartDateTime().toInstant(),UTC) : null);
            bookingLineToCreate.setEndDatetime(bookingLine1.getEndDateTime() != null ?
              OffsetDateTime.ofInstant(bookingLine1.getEndDateTime().toInstant(),UTC) : null);
            bookingLineToCreate.setBookingLineStatus
              (BookingLineStatusEnum.valueOf(bookingLine1.getBookingLineStatus().toString()));
          return bookingLineToCreate;
        });
        if (optionalBookingLine.isPresent()) {
            bookingLine.setBookingLineStatus
                    (BookingLineStatusEnum.valueOf(bookingLine1.getBookingLineStatus().toString()));
            bookingLine.setBooking(booking);
            bookingLine.setProductUuid(bookingLine1.getProductUuid());
            bookingLine.setLocationUuid(booking.getLocationUuid());
            bookingLine.setStartDatetime(bookingLine1.getStartDateTime() != null ?
                    OffsetDateTime.ofInstant(bookingLine1.getStartDateTime().toInstant(),UTC) : null);
            bookingLine.setEndDatetime(bookingLine1.getEndDateTime() != null ?
                    OffsetDateTime.ofInstant(bookingLine1.getEndDateTime().toInstant(),UTC) : null);
        }
        return bookingLine;
    }

    protected List<BookingLink> updateBookingLinkDetails(
            UUID bookingUuid, BookingDetailsV1 bookingDetails) {
        return bookingDetails.getLinkedBookings().stream()
                .map(bookingLink1 -> getBookingLink(bookingUuid, bookingLink1))
                .collect(Collectors.toList());
    }

    private BookingLink getBookingLink
            (UUID bookingUuid, com.ielts.cmds.api.evt_019.BookingLinkV1 bookingLink1) {

        BookingLink bookingLinkToCreate = new BookingLink();
        bookingLinkToCreate.setSourceBookingUuid(bookingUuid);

        bookingLinkToCreate.setTargetBookingUuid(bookingLink1.getLinkedBooking().getBookingUuid());
        bookingLinkToCreate.setRole(BookingRoleEnum.valueOf(bookingLink1.getRole().getValue()));

        return bookingLinkToCreate;
    }

    private void buildHeader(String eventName) {
        CMDSHeaderContext eventHeader = new CMDSHeaderContext();
        eventHeader.setPartnerCode(ThreadLocalHeaderContext.getContext().getPartnerCode());
        eventHeader.setEventName(eventName);
        eventHeader.setCorrelationId(ThreadLocalHeaderContext.getContext().getCorrelationId());
        eventHeader.setEventDateTime(LocalDateTime.now());
        eventHeader.setTransactionId(ThreadLocalHeaderContext.getContext().getTransactionId());
        ThreadLocalHeaderContext.clearContext();
        ThreadLocalHeaderContext.setContext(eventHeader);
    }

    private ResultIntegrityBookingConsumedV1 buildBookingDetails(Booking booking) {
        ResultIntegrityBookingConsumedV1 bookingDetails = new ResultIntegrityBookingConsumedV1();
        bookingDetails.setBookingUuid(booking.getBookingUuid());
        bookingDetails.setExternalBookingUuid(booking.getExternalBookingUuid());
        bookingDetails.setProductUuid(booking.getProductUuid());
        bookingDetails.setLocationUuid(booking.getLocationUuid());
        bookingDetails.setBookingStatus(ResultIntegrityBookingConsumedV1.BookingStatusEnum.valueOf(booking.getBookingStatus()));
        bookingDetails.setBookingLinks(mapBookingLinkToBookingDetails(booking));
        bookingDetails.setBookingLines(mapBookingLineToBookingDetails(booking));
        bookingDetails.setBookingVersion(booking.getBookingVersion());
        bookingDetails.setBirthDate(booking.getBirthDate());
        bookingDetails.setCompositeCandidateNumber(booking.getCompositeCandidateNumber());
        bookingDetails.setFirstName(booking.getFirstName());
        bookingDetails.setLastName(booking.getLastName());
        bookingDetails.setIdentityNumber(booking.getIdentityNumber());
        bookingDetails.setShortCandidateNumber(booking.getShortCandidateNumber().toString());
        bookingDetails.setTestDate(booking.getTestDate().getLocalDate());
        bookingDetails.setUniqueTestTakerUuid(booking.getUniqueTestTakerUuid());
        return bookingDetails;
    }

    private List<com.ielts.cmds.api.RI_Event002_ResultIntegrityBookingConsumed.BookingLinkV1> mapBookingLinkToBookingDetails(final Booking booking) {

        List<com.ielts.cmds.api.RI_Event002_ResultIntegrityBookingConsumed.BookingLinkV1> bookingLinkList = new ArrayList<>();
        com.ielts.cmds.api.RI_Event002_ResultIntegrityBookingConsumed.BookingLinkV1 bookingLink = new com.ielts.cmds.api.RI_Event002_ResultIntegrityBookingConsumed.BookingLinkV1();
        if (Objects.nonNull(booking) && Objects.nonNull(booking.getBookingLinks())) {
            booking.getBookingLinks().forEach(bookingLink1 -> {
                bookingLink.setBookingUuid(bookingLink1.getSourceBookingUuid());
                bookingLink.setRole(com.ielts.cmds.api.RI_Event002_ResultIntegrityBookingConsumed.BookingLinkV1.RoleEnum.valueOf(bookingLink1.getRole().getValue()));
                bookingLinkList.add(bookingLink);
            });
        }
        return bookingLinkList;
    }

    private List<com.ielts.cmds.api.RI_Event002_ResultIntegrityBookingConsumed.BookingLineV1> mapBookingLineToBookingDetails(final Booking booking) {

        List<com.ielts.cmds.api.RI_Event002_ResultIntegrityBookingConsumed.BookingLineV1> bookingLineList = new ArrayList<>();
        com.ielts.cmds.api.RI_Event002_ResultIntegrityBookingConsumed.BookingLineV1 bookingLine = new com.ielts.cmds.api.RI_Event002_ResultIntegrityBookingConsumed.BookingLineV1();
        if (Objects.nonNull(booking) && Objects.nonNull(booking.getBookingLines())) {
            booking.getBookingLines().forEach(bookingLine1 -> {
                bookingLine.setBookingUuid(booking.getBookingUuid());
                bookingLine.setProductUuid(bookingLine1.getProductUuid());
                bookingLine.setBookingLineUuid(bookingLine1.getBookingLineUuid());
                bookingLine.setLocationUuid(bookingLine1.getLocationUuid());
                bookingLine.setExternalBookingLineUuid(bookingLine1.getExternalBookingLineUuid());
                bookingLine.setBookingLineStatus(com.ielts.cmds.api.RI_Event002_ResultIntegrityBookingConsumed.BookingLineV1.BookingLineStatusEnum.valueOf(bookingLine1.getBookingLineStatus().getValue()));
                bookingLine.setEndDateTime(bookingLine1.getEndDatetime());
                bookingLine.setStartDateTime(bookingLine1.getStartDatetime());
                bookingLineList.add(bookingLine);
            });
        }
        return bookingLineList;
    }

}