package com.ielts.cmds.ri.application.service;

import com.ielts.cmds.common.config.IBaseAuditService;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.api.evt119.IntegrityCheckInitiatedV1;
import com.ielts.cmds.ri.domain.service.IntegrityCheckDomainService;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.service.IApplicationServiceV2;
import com.ielts.cmds.serialization.utils.ServiceIdentifier;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@ServiceIdentifier(RIConstants.EventType.INTEGRITY_CHECK_INITIATED)
@Slf4j
public class IntegrityCheckService implements IApplicationServiceV2<IntegrityCheckInitiatedV1>, IBaseAuditService {

  @Autowired
  IntegrityCheckDomainService integrityCheckDomainService;

  @Override
  @SneakyThrows
  public void process(IntegrityCheckInitiatedV1 integrityCheckInitiatedV1) {
    try {
      log.info(
          "IntegrityCheckInitiated process started for request with transactionId:{}",
          ThreadLocalHeaderContext.getContext().getTransactionId());

      if (integrityCheckInitiatedV1 == null) {
        throw new IllegalArgumentException("Payload is Empty");
      }

      populateAuditFields();

      integrityCheckDomainService.on(integrityCheckInitiatedV1);
    } catch (IllegalArgumentException e) {
      log.error("Failed to process RI event due to ", e);
      throw new ProcessingException(e.getMessage(), e);
    }
  }

  @Override
  public String getPermission() {
    return null;
  }

  @Override
  public String getScreen() {
    return null;
  }

  @Override
  public String getAction() {
    return IntegrityCheckService.class.getSimpleName();
  }
}
