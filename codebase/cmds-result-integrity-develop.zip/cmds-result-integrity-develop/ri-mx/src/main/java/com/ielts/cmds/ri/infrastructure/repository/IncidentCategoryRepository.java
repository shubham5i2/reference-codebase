package com.ielts.cmds.ri.infrastructure.repository;

import com.ielts.cmds.ri.infrastructure.entity.IncidentCategory;

import java.util.Optional;
import java.util.UUID;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
@Cacheable("incidentCategory")
public interface IncidentCategoryRepository extends JpaRepository<IncidentCategory, UUID> {
    Optional<IncidentCategory> findByIncidentCategoryUuid(UUID incidentCategoryUuid);
}
