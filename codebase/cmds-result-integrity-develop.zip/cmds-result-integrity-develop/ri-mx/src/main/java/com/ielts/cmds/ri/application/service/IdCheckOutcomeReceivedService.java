package com.ielts.cmds.ri.application.service;

import com.ielts.cmds.common.config.IBaseAuditService;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.common.model.out.IdCheckOutcomeReceivedDetailsV1;
import com.ielts.cmds.ri.domain.service.IdCheckOutcomeReceivedDomainService;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.serialization.application.service.IApplicationServiceV2;
import com.ielts.cmds.serialization.utils.ServiceIdentifier;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.ielts.cmds.ri.utils.RIConstants.PermissionId.RI_BOOKING_SEARCH;
import static com.ielts.cmds.ri.utils.RIConstants.UiConstants.OPERATION_TYPE_PUT;
import static com.ielts.cmds.ri.utils.RIConstants.UiConstants.SUBMIT_ID_CHECKOUTCOME_TYPE;

/**
 * The type Id check outcome received service.
 */
@Service
@ServiceIdentifier(OPERATION_TYPE_PUT+(SUBMIT_ID_CHECKOUTCOME_TYPE))
@Slf4j
public class IdCheckOutcomeReceivedService implements IApplicationServiceV2<IdCheckOutcomeReceivedDetailsV1>, IBaseAuditService {

    /**
     * The Booking search domain service.
     */
    @Autowired
    IdCheckOutcomeReceivedDomainService idCheckOutcomeReceivedDomainService;

    @Autowired
    RICommonUtil riCommonUtil;

    @SneakyThrows
    @Override
    public void process(IdCheckOutcomeReceivedDetailsV1 idCheckOutcomeReceivedDetails) {
        CMDSHeaderContext initHeader = ThreadLocalHeaderContext.getContext();
        log.info(
                "IdCheckOutcomeReceivedService process started for request with transactionId:{}",
                ThreadLocalHeaderContext.getContext().getTransactionId());

        try {
            //populate audit
            populateAuditFields();

            // Execute command
            idCheckOutcomeReceivedDomainService.on(idCheckOutcomeReceivedDetails);
        } catch (Exception e) {
            log.error("Exception Caught in Service: {}", e.getMessage());
            idCheckOutcomeReceivedDomainService.publishEventAfterUpdatingCheckOutcomeStatus(null, null, initHeader);
        }
    }

    @Override
    public String getPermission() {
        return RI_BOOKING_SEARCH;
    }

    @Override
    public String getScreen() {
        return RI_BOOKING_SEARCH;
    }

    @Override
    public String getAction() {
        return IdCheckOutcomeReceivedService.class.getSimpleName();
    }
}