package com.ielts.cmds.ri.domain.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.evt074.ResultIntegrityIncidentDetailsWrapperV1;
import com.ielts.cmds.api.evt119.CheckOutcomeV1;
import com.ielts.cmds.api.evt119.IntegrityCheckInitiatedV1;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.api.evt113.ProbableBanCheckOutcomeDetailsV1Inner;
import com.ielts.cmds.api.evt113.ProbableBanCheckOutcomeV1;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.Incident;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.utils.ProbableBanCheckoutcomeHelper;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;
import com.ielts.cmds.serialization.domain.EnableOutboundEventV2;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.INCIDENT_TYPE_CODE_PROBABLE_BAN;

@Slf4j
@Service
@EnableOutboundEventV2
public class ProbableBanOutcomeReceivedDomainService extends AbstractCMDSDomainService<Object> {

  private final ProbableBanCheckoutcomeHelper probableBanCheckoutcomeHelper;
  private final RICommonUtil riCommonUtil;
  private final BookingRepository bookingRepository;

  @Autowired
  public ProbableBanOutcomeReceivedDomainService(ApplicationEventPublisher publisher,
                                                 ObjectMapper objectMapper,
                                                 @Value("${integrityCheckInitiated.v2}") String isV2Enabled,
                                                 CMDSThreadLocalContextService cmdsThreadLocalContextService,
                                                 ProbableBanCheckoutcomeHelper probableBanCheckoutcomeHelper,
                                                 RICommonUtil riCommonUtil,
                                                 BookingRepository bookingRepository) {
    super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
    this.probableBanCheckoutcomeHelper = probableBanCheckoutcomeHelper;
    this.riCommonUtil = riCommonUtil;
    this.bookingRepository=bookingRepository;
  }

  @SneakyThrows
  public void on(final ProbableBanCheckOutcomeV1 probableBanCheckOutcomeV1) {
      log.debug("ProbableBanOutcomeReceivedDomainService| on | ProbableBanCheckOutcomeV1:{}", probableBanCheckOutcomeV1);
      List<ProbableBanCheckOutcomeDetailsV1Inner> failedBookings = new ArrayList<>();
      probableBanCheckOutcomeV1.getProbableBanCheckOutcomeDetails().forEach(
              probableBanCheckOutcomeDetailsV1Inner -> {
                try {
                  log.debug("Saving checkOutcome for booking {}", probableBanCheckOutcomeDetailsV1Inner.getBookingUuid());
                    Optional<Booking> optionalBooking =
                            bookingRepository.findById(probableBanCheckOutcomeDetailsV1Inner.getBookingUuid());
                    CheckOutcome checkOutcome =
                          probableBanCheckoutcomeHelper.updateProbableBanOutcome(probableBanCheckOutcomeDetailsV1Inner,optionalBooking.orElse(null));
                  if(checkOutcome !=null) {
                      publishIntegrityCheckInitiatedEvent(checkOutcome);
                      publishIntegrityIncidentDetailsRaisedEvent(checkOutcome,optionalBooking.orElse(null));
                  }

                } catch (ResultIntegrityException e) {
                  log.error("ProbableBanOutcomeReceivedCommand execution failed", e);
                  failedBookings.add(probableBanCheckOutcomeDetailsV1Inner);
                }
              }
      );
      if(!failedBookings.isEmpty()) {
        throw  new ResultIntegrityException(failedBookings.size()+" bookings failed while processing ProbableBanCheckOutcome");
      }
  }

  private void publishIntegrityCheckInitiatedEvent(CheckOutcome checkOutcome) {
    log.debug("publishing event: {}", RIConstants.EventType.INTEGRITY_CHECK_INITIATED);
    IntegrityCheckInitiatedV1 integrityCheckInitiatedV1 = eventBuilder(checkOutcome);
    buildHeaderForIntegrityCheckInit(checkOutcome);

    publishEvent(integrityCheckInitiatedV1);
  }

  private IntegrityCheckInitiatedV1 eventBuilder(CheckOutcome checkOutcome) {
   CheckOutcomeV1 checkOutcomeV1 = new CheckOutcomeV1();
    IntegrityCheckInitiatedV1 integrityCheckInitiatedV1=new IntegrityCheckInitiatedV1();
    checkOutcomeV1.setCheckOutcomeStatusUuid(
           checkOutcome.getCheckOutcomeStatus().getCheckOutcomeStatusUuid());
    checkOutcomeV1.setCheckOutcomeTypeUuid(
            checkOutcome.getCheckOutcomeType().getCheckOutcomeTypeUuid());

    integrityCheckInitiatedV1.bookingUuid((checkOutcome.getBookingUuid()));
    integrityCheckInitiatedV1.checkOutcome(checkOutcomeV1);
    integrityCheckInitiatedV1.setBookingVersion(checkOutcome.getBookingVersion());
    return integrityCheckInitiatedV1;
  }

  private void buildHeaderForIntegrityCheckInit(CheckOutcome checkOutcome) {
    CMDSHeaderContext headerContext = new CMDSHeaderContext();
    headerContext.setPartnerCode(ThreadLocalHeaderContext.getContext().getPartnerCode());
    headerContext.setEventContext(
            Collections.singletonMap(
                    "checkOutcomeUuid", String.valueOf(Objects.nonNull(checkOutcome) && Objects.nonNull(checkOutcome.getCheckOutcomeUuid())
                            ? checkOutcome.getCheckOutcomeUuid() : "")));
    headerContext.setCorrelationId(ThreadLocalHeaderContext.getContext().getCorrelationId());
    headerContext.setEventDateTime(LocalDateTime.now(ZoneOffset.UTC));
    headerContext.setTransactionId(ThreadLocalHeaderContext.getContext().getTransactionId());
    headerContext.setEventName(RIConstants.EventType.INTEGRITY_CHECK_INITIATED);
    headerContext.setConnectionId(ThreadLocalHeaderContext.getContext().getConnectionId());
    ThreadLocalHeaderContext.clearContext();
    ThreadLocalHeaderContext.setContext(headerContext);
  }

  private void publishIntegrityIncidentDetailsRaisedEvent(CheckOutcome checkOutcome,Booking optionalBooking) {

    Incident incident =
        checkOutcome.getIncidentsByCheckOutcomeUuid().stream()
            .filter(
                incident1 ->
                    INCIDENT_TYPE_CODE_PROBABLE_BAN.equals(
                        incident1.getIncidentTypeByIncidentTypeUuid().getIncidentTypeCode()))
            .collect(Collectors.toList())
            .get(0);

    buildHeaderForIntegrityIncidentDetailsRaised(incident);

    ResultIntegrityIncidentDetailsWrapperV1 resultIntegrityIncidentDetailsWrapperV1 = riCommonUtil.populateIntegrityDetailsRaisedEvent(incident,optionalBooking);

    publishEvent(resultIntegrityIncidentDetailsWrapperV1);
  }

  private void buildHeaderForIntegrityIncidentDetailsRaised(Incident incident) {
    CMDSHeaderContext headerContext = new CMDSHeaderContext();
    headerContext.setPartnerCode(ThreadLocalHeaderContext.getContext().getPartnerCode());
    headerContext.setEventDateTime(LocalDateTime.now(ZoneOffset.UTC));
    headerContext.setEventName(RIConstants.EventType.RESULT_INTEGRITY_INCIDENT_DETAILS_RAISED);
    headerContext.setCorrelationId(ThreadLocalHeaderContext.getContext().getCorrelationId());
    headerContext.setTransactionId(ThreadLocalHeaderContext.getContext().getTransactionId());

    headerContext.setEventContext(
        Collections.singletonMap("incidentUuid", String.valueOf(incident.getIncidentUuid())));
    ThreadLocalHeaderContext.clearContext();
    ThreadLocalHeaderContext.setContext(headerContext);
  }

}

