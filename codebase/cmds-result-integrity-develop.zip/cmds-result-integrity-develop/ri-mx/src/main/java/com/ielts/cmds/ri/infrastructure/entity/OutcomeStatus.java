package com.ielts.cmds.ri.infrastructure.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Builder
@Getter
@Setter
@Table(name = "outcome_status")
@NoArgsConstructor
@AllArgsConstructor
public class OutcomeStatus extends CommonModel {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "outcome_status_uuid")
    private UUID outcomeStatusUuid;
	
	@ManyToOne(cascade = CascadeType.REFRESH, fetch = FetchType.LAZY)
    @JoinColumn(name = "outcome_status_type_uuid")
    private OutcomeStatusType outcomeStatusType;
	
	@Column(name = "booking_uuid")
    private UUID bookingUuid;
	
	@Column(name = "check_outcome_event_datetime")
    private LocalDateTime checkOutcomeEventDateTime;
	
	@Column(name = "booking_version")
    private BigDecimal bookingVersion;

}
