package com.ielts.cmds.ri.infrastructure.entity;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "photo_type")
public class PhotoType implements Serializable {

    private static final long serialVersionUID = 1845479687461848212L;

    @Id
    @Column(name = "photo_type_uuid")
    private UUID photoTypeUuid;

    @Column(name = "photo_type_code")
    private String photoTypeCode;

    @Column(name = "photo_type_description")
    private String photoTypeDescription;

    @Column(name = "created_datetime")
    private OffsetDateTime createdDatetime;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;

    @Column(name = "updated_by")
    private String updatedBy;

    @Version
    @Column(name = "concurrency_version")
    private Integer concurrencyVersion;
}