package com.ielts.cmds.ri.infrastructure.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "result_integrity_semaphore")
@Data
@EqualsAndHashCode
@NoArgsConstructor
public class ResultIntegritySemaphore {

  @Id String semaphoreName;
}
