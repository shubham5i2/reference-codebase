package com.ielts.cmds.ri.infrastructure.entity;

import java.time.OffsetDateTime;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Version;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@Entity
@Table(name = "incident_type")
@NoArgsConstructor
@AllArgsConstructor
public class IncidentType {
	
	@Id
    @Column(name = "incident_type_uuid")
    private UUID incidentTypeUuid;
	
	@Column(name = "incident_description")
    private String incidentDescription;
	
	@Column(name = "incident_type_code")
    private String incidentTypeCode;
	
	@Column(name = "effective_from_date")
    private OffsetDateTime effectiveFromDate;
	
	@Column(name = "effective_to_date")
    private OffsetDateTime effectiveToDate;
	
	@Column(name = "created_by")
    private String createdBy;
	
	@Column(name = "created_datetime")
    private OffsetDateTime createdDatetime;
	
	@Column(name = "updated_by")
    private String updatedBy;
	
	@Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;
	
	@Version
    @Column(name = "concurrency_version")
    private int concurrencyVersion;
	
	@ManyToOne
    @JoinColumn(name = "incident_category_uuid", referencedColumnName = "incident_category_uuid", nullable = false)
    private IncidentCategory incidentCategoryByIncidentCategoryUuid;
	
	@Column(name = "external_incident_category")
    private String externalIncidentCategory;
	
	@Column(name = "ban_review_required")
    private Boolean banReviewRequired;

}
