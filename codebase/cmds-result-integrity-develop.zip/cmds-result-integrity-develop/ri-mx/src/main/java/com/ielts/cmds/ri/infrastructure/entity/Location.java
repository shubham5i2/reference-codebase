package com.ielts.cmds.ri.infrastructure.entity;

import com.ielts.cmds.lpr.common.enums.LocationStatus;
import com.ielts.cmds.lpr.common.enums.LocationTypeCode;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.UUID;

@Data
@EqualsAndHashCode(exclude = {"createdDatetime", "updatedDatetime"})
@Entity(name="RILocation")
@Table(name = "location")
public class Location {

  @Id
  @Column(name = "location_uuid")
  private UUID locationUuid;

  @Column(name = "parent_location_uuid")
  private UUID parentLocationUuid;

  @Enumerated(EnumType.STRING)
  @Column(name = "status")
  private LocationStatus locationStatus;

  @Enumerated(EnumType.STRING)
  @Column(name = "location_type")
  private LocationTypeCode locationTypeCode;

  @Column(name = "partner_code")
  private String partnerCode;

  @Column(name = "location_name")
  private String locationName;
  
  @Column(name = "test_centre_number")
  private String testCentreNumber;
  
  @Column(name = "created_datetime")
  private OffsetDateTime createdDatetime;

  @Column(name = "updated_datetime")
  private OffsetDateTime updatedDatetime;

  @Column(name = "event_datetime")
  private LocalDateTime eventDatetime;

  @Version
  @Column(name = "concurrency_version")
  private Integer concurrencyVersion;

}
