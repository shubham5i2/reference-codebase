package com.ielts.cmds.ri.application.service;

import com.ielts.cmds.common.config.IBaseAuditService;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.common.model.out.UpdateIncidentDetailsV1;
import com.ielts.cmds.ri.domain.service.IncidentUpdateDomainService;
import com.ielts.cmds.serialization.application.service.IApplicationServiceV2;
import com.ielts.cmds.serialization.utils.ServiceIdentifier;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.ielts.cmds.ri.utils.RIConstants.PermissionId.RI_INCIDENT_UPDATE;
import static com.ielts.cmds.ri.utils.RIConstants.UiConstants.OPERATION_TYPE_PUT;
import static com.ielts.cmds.ri.utils.RIConstants.UiConstants.UPDATE_INCIDENT_TYPE;

@Service
@ServiceIdentifier(OPERATION_TYPE_PUT+(UPDATE_INCIDENT_TYPE))
@Slf4j
public class IncidentUpdateService implements IApplicationServiceV2<UpdateIncidentDetailsV1>, IBaseAuditService {

    @Autowired
    IncidentUpdateDomainService incidentUpdateDomainService;

    @SneakyThrows
    @Override
    public void process(UpdateIncidentDetailsV1 updateIncidentDetails) {
        CMDSHeaderContext initHeader = ThreadLocalHeaderContext.getContext();
        try {
            log.debug(
                    "Incident Update Service process started for request with CorrelationId:{}",
                    ThreadLocalHeaderContext.getContext().getCorrelationId());
            populateAuditFields();
            if (updateIncidentDetails == null) {
                throw new IllegalArgumentException("Payload is Empty");
            }
            incidentUpdateDomainService.on(updateIncidentDetails);

        } catch (Exception e) {
            log.error("Exception Caught in Service: {}", e.getMessage());
            incidentUpdateDomainService.publishIncidentUpdateEventToOutBoundTopic(null, null, initHeader);
        }
    }

    @Override
    public String getPermission() {
        return RI_INCIDENT_UPDATE;
    }

    @Override
    public String getScreen() {
        return RI_INCIDENT_UPDATE;
    }

    @Override
    public String getAction() {
        return IncidentUpdateService.class.getSimpleName();
    }
}
