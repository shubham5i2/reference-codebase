package com.ielts.cmds.ri.infrastructure.event.listener;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.serialization.application.service.ApplicationServiceFactory;
import com.ielts.cmds.serialization.application.service.ApplicationServiceFactoryV2;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.infra.AbstractListener;
import com.ielts.cmds.serialization.utils.BaseEventExtractor;
import com.ielts.cmds.serialization.utils.CmdsLoggerInitializer;
import com.ielts.cmds.serialization.utils.CmdsLoggerInitializerV2;
import com.ielts.cmds.serialization.utils.EventBodyExtractor;
import com.ielts.cmds.serialization.utils.MessageVersionIdentifier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.Message;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

@Service
public class RIIntListener extends AbstractListener<BaseHeader> {

    @SuppressWarnings("rawtypes")
	@Autowired
    public RIIntListener(ObjectMapper mapper,
                         EventBodyExtractor extractEventBody,
                         BaseEventExtractor extractBaseEvent,
                         CmdsLoggerInitializerV2 loggerInitializerV2,
                         CmdsLoggerInitializer loggerInitializerV1,
                         MessageVersionIdentifier identifyVersion,
                         ApplicationServiceFactoryV2 applicationServiceFactoryV2,
                         ApplicationServiceFactory applicationServiceFactory,
                         CMDSThreadLocalContextService cmdsThreadLocalContextService) {
        super(mapper,
                extractEventBody,
                extractBaseEvent,
                loggerInitializerV2,
                loggerInitializerV1,
                identifyVersion,
                applicationServiceFactoryV2,
                applicationServiceFactory,
                cmdsThreadLocalContextService);
    }

    @Retryable(maxAttemptsExpression = "${retry.maxAttempts}",
            backoff = @Backoff(delayExpression = "${retry.delay}", multiplierExpression = "${retry.multiplier}"))
    @JmsListener(destination = "${aws.sqs.ri-int-queue-in.name}")
    public void on(Message<String> eventMessage) {onReceive(eventMessage.getHeaders(), eventMessage.getPayload());
    }
}
