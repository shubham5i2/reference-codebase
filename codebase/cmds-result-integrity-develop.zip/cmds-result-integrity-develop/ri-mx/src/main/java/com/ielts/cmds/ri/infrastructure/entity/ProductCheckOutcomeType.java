package com.ielts.cmds.ri.infrastructure.entity;

import java.time.OffsetDateTime;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Data
@Table(name = "product_check_outcome_type")
public class ProductCheckOutcomeType {

  @Id
  @Column(name = "product_check_outcome_type_uuid")
  private UUID productCheckOutcomeTypeUuid;

  @Column(name = "product_uuid")
  private UUID productUuid;

  @Column(name = "check_outcome_type_uuid")
  private UUID checkOutcomeTypeUuid;

  @Column(name = "updated_datetime")
  private OffsetDateTime updatedDatetime;

  @Column(name = "created_datetime")
  private OffsetDateTime createdDatetime;

  @Version
  @Column(name = "concurrency_version")
  private Integer concurrencyVersion;

  @Column(name = "check_outcome_type_code")
  private String checkOutcomeTypeCode;

}
