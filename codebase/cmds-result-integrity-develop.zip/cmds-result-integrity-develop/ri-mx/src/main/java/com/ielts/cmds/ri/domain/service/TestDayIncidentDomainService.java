package com.ielts.cmds.ri.domain.service;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.evt074.ResultIntegrityIncidentDetailsWrapperV1;
import com.ielts.cmds.api.evt119.CheckOutcomeV1;
import com.ielts.cmds.api.evt119.IntegrityCheckInitiatedV1;
import com.ielts.cmds.ids.domain.model.CommentDetailsV1;
import com.ielts.cmds.ids.domain.model.DocumentsDetailsV1;
import com.ielts.cmds.ids.domain.model.ReceivedIncidentDetailsV1;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.application.exception.ResultIntegrityValidationException;
import com.ielts.cmds.ri.domain.enums.IncidentCommentUserTypeEnum;
import com.ielts.cmds.ri.domain.enums.IncidentSeverityEnum;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.Incident;
import com.ielts.cmds.ri.infrastructure.entity.IncidentCategory;
import com.ielts.cmds.ri.infrastructure.entity.IncidentComment;
import com.ielts.cmds.ri.infrastructure.entity.IncidentEvidence;
import com.ielts.cmds.ri.infrastructure.entity.IncidentType;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentCategoryRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentTypeRepository;
import com.ielts.cmds.ri.utils.CheckOutcomeStatusHelper;
import com.ielts.cmds.ri.utils.FileStorageHelper;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.ri.utils.RIConstants.EventType;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;
import com.ielts.cmds.serialization.domain.EnableOutboundEventV2;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@EnableOutboundEventV2
public class TestDayIncidentDomainService extends AbstractCMDSDomainService<Object> {

	private final IncidentRepository incidentRepository;
	private final IncidentTypeRepository incidentTypeRepository;
	private final IncidentCategoryRepository incidentCategoryRepository;
	private final RICommonUtil riCommonUtil;
	private final CheckOutcomeStatusHelper checkOutcomeStatusHelper;
	private final FileStorageHelper fileStorageHelper;
  	private final String bucketName;
      private BookingRepository bookingRepository;

  @Autowired
  public TestDayIncidentDomainService(ApplicationEventPublisher publisher,
                                      ObjectMapper objectMapper,
                                      @Value("${testDayIncident.v2}") String isV2Enabled,
                                      CMDSThreadLocalContextService cmdsThreadLocalContextService,
                                      IncidentRepository incidentRepository,
                                      IncidentTypeRepository incidentTypeRepository,
                                      IncidentCategoryRepository incidentCategoryRepository,
                                      RICommonUtil riCommonUtil,
                                      CheckOutcomeStatusHelper checkOutcomeStatusHelper,
                                      FileStorageHelper fileStorageHelper,
                                      @Value("${ri-bucket}") String bucketName,
                                      BookingRepository bookingRepository) {
    super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
    this.incidentRepository = incidentRepository;
	this.incidentTypeRepository = incidentTypeRepository;
	this.incidentCategoryRepository = incidentCategoryRepository;
	this.riCommonUtil = riCommonUtil;
	this.checkOutcomeStatusHelper = checkOutcomeStatusHelper;
	this.fileStorageHelper = fileStorageHelper;
	this.bucketName = bucketName;
    this.bookingRepository=bookingRepository;
  }

  @SneakyThrows
  @Transactional
  public Incident on(final ReceivedIncidentDetailsV1 receivedIncidentDetailsV1) {

    log.debug("TestDayIncidentDomainService| on | ReceivedIncidentDetailsV1:{}", receivedIncidentDetailsV1);

    Incident incident;
    Optional<Incident> optIncident;

    if (Objects.nonNull(receivedIncidentDetailsV1.getBookingLineUuId())) {
      optIncident =
          incidentRepository.findByExternalIncidentIdAndBookingUuidAndBookingLineUuid(
              receivedIncidentDetailsV1.getExternalIncidentId(),
              receivedIncidentDetailsV1.getBookingUuId(),
              receivedIncidentDetailsV1.getBookingLineUuId());
    } else {
      optIncident = incidentRepository.findByExternalIncidentId(receivedIncidentDetailsV1.getExternalIncidentId());
    }
    if (optIncident.isPresent()) {
    	incidentValidation(receivedIncidentDetailsV1,optIncident.orElse(null));
      log.debug(
          "Incident with externalIncidentId:{} is getting updated",
          receivedIncidentDetailsV1.getExternalIncidentId());
      incident = optIncident.get();
      updateIncident(receivedIncidentDetailsV1, incident);
    } else {
      log.debug(
          "Location with locationId:{} is getting created",
          receivedIncidentDetailsV1.getExternalIncidentId());
      incident = createIncident(receivedIncidentDetailsV1);
    }
      Optional<Booking> optionalBooking=bookingRepository.findById(incident.getBookingUuid());
      checkOutcomeStatusHelper.setCheckOutcomeStatus(
        incident, RIConstants.PrcOutcomeConstant.LRW_INC_CHK,optionalBooking.orElse(null));
    Incident savedIncident = incidentRepository.save(incident);

    if (incident.getIncidentCategoryByIncidentCategoryUuid().getEligibleForIntegrityCheck().booleanValue()
        && incident.getIncidentSeverity() != null
        && IncidentSeverityEnum.CONFIRMED_MALPRACTICE
        .getValue()
        .equals(incident.getIncidentSeverity().getValue())) {
      publishIntegrityCheckInitiatedEvent(incident, savedIncident);
    }

      publishIntegrityIncidentDetailsRaisedEvent(incident, savedIncident,optionalBooking.orElse(null));

      return incident;
     }
  
  protected void incidentValidation(final ReceivedIncidentDetailsV1 receivedIncidentDetailsV1,
			final Incident optionalIncident) throws ResultIntegrityValidationException {
		if (Objects.nonNull(optionalIncident)) {
			LocalDateTime localDateTime = optionalIncident.getEventDateTime();
			if (!(ThreadLocalHeaderContext.getContext().getEventDateTime().isAfter(localDateTime))) {
				throw new ResultIntegrityValidationException(
						String.format("Received Event Date time is before this : %s  " + "for this Booking UUID : %s",
								localDateTime, receivedIncidentDetailsV1.getBookingUuId()),
						new Throwable());
			}
		}
	}

  private void publishIntegrityIncidentDetailsRaisedEvent(
      Incident incident,
      Incident savedIncident,Booking optionalBooking) {
    ResultIntegrityIncidentDetailsWrapperV1 resultIntegrityIncidentDetailsWrapperV1;
    buildHeader(RIConstants.EventType.RESULT_INTEGRITY_INCIDENT_DETAILS_RAISED, savedIncident);
    log.info("Publishing Event: {}",
        RIConstants.EventType.RESULT_INTEGRITY_INCIDENT_DETAILS_RAISED);
    resultIntegrityIncidentDetailsWrapperV1 = riCommonUtil.populateIntegrityDetailsRaisedEvent(incident,optionalBooking);
    publishEvent(resultIntegrityIncidentDetailsWrapperV1);
  }

  private void publishIntegrityCheckInitiatedEvent(
      Incident incident,
			Incident savedIncident) {
		IntegrityCheckInitiatedV1 integrityCheckInitiatedV1;
		buildHeader(EventType.INTEGRITY_CHECK_INITIATED, savedIncident);
		log.info("Publishing event: {}", EventType.INTEGRITY_CHECK_INITIATED);

		integrityCheckInitiatedV1 = populateIntegrityCheckEvent(incident);

		publishEvent(integrityCheckInitiatedV1);
	}

  private IntegrityCheckInitiatedV1 populateIntegrityCheckEvent(final Incident incident) {
      IntegrityCheckInitiatedV1 integrityCheckInitiatedV1=new IntegrityCheckInitiatedV1();
      CheckOutcomeV1 checkOutcomeV1=getCheckOutcome(incident.getCheckOutcomeByCheckOutcomeUuid());
      integrityCheckInitiatedV1.bookingUuid((incident.getBookingUuid()));
      integrityCheckInitiatedV1.checkOutcome(checkOutcomeV1);
      integrityCheckInitiatedV1.setBookingVersion(incident.getCheckOutcomeByCheckOutcomeUuid().getBookingVersion());

     return  integrityCheckInitiatedV1;
  }

  private CheckOutcomeV1 getCheckOutcome(final CheckOutcome checkOutcome) {

    CheckOutcomeV1 checkOutcomeV1 = new CheckOutcomeV1();

    if (Objects.nonNull(checkOutcome)) {
      checkOutcomeV1.setCheckOutcomeTypeUuid(
              checkOutcome.getCheckOutcomeType().getCheckOutcomeTypeUuid());
      checkOutcomeV1.setCheckOutcomeStatusUuid(
              checkOutcome.getCheckOutcomeStatus().getCheckOutcomeStatusUuid());
    }
    return checkOutcomeV1;
  }

  private void buildHeader(String eventName, Incident incident) {
	    CMDSHeaderContext header = new CMDSHeaderContext();
	    header.setCorrelationId(ThreadLocalHeaderContext.getContext().getCorrelationId());
	    header.setEventDateTime(LocalDateTime.now(ZoneOffset.UTC));
	    header.setTransactionId(ThreadLocalHeaderContext.getContext().getTransactionId());
	    header.setPartnerCode(ThreadLocalHeaderContext.getContext().getPartnerCode());
	    header.setEventName(eventName);

	    header.setEventContext(Collections.singletonMap("incidentUuid", incident.getIncidentUuid().toString()));
	    ThreadLocalHeaderContext.clearContext();
	    ThreadLocalHeaderContext.setContext(header);
  }

  Incident createIncident(final ReceivedIncidentDetailsV1 receivedIncidentDetailsV1) {
    log.info("create incident");

    IncidentCategory incidentCategory = null;

    Optional<IncidentCategory> optionalIncidentCategory =
        incidentCategoryRepository.findByIncidentCategoryUuid(
            receivedIncidentDetailsV1.getIncidentCategoryUuid());

    if (optionalIncidentCategory.isPresent()) {
      incidentCategory = optionalIncidentCategory.get();
    }

    Incident createIncident =
        Incident.builder()
            .externalIncidentId(receivedIncidentDetailsV1.getExternalIncidentId())
            .incidentTypeByIncidentTypeUuid(
                getIncidentType(receivedIncidentDetailsV1).orElse(null))
            .incidentSeverity(receivedIncidentDetailsV1.getIncidentSeverity() !=null
               ? IncidentSeverityEnum.valueOf(receivedIncidentDetailsV1.getIncidentSeverity()) : null)
            .incidentCategoryByIncidentCategoryUuid(incidentCategory)
            .bookingUuid(receivedIncidentDetailsV1.getBookingUuId())
            .incidentCommentsByIncidentUuid(new ArrayList<>())
            .incidentEvidencesByIncidentUuid(new ArrayList<>())
            .eventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime())
            .build();

    createIncident.setBookingLineUuid(receivedIncidentDetailsV1.getBookingLineUuId());

    if (Objects.nonNull(receivedIncidentDetailsV1
        .getComments())) {
      setComments(receivedIncidentDetailsV1, createIncident);
    }

    createIncident.setIncidentStatusTypeByIncidentStatusTypeUuid(
        checkOutcomeStatusHelper.getIncidentStatusType(
            createIncident, createIncident.getIncidentCategoryByIncidentCategoryUuid()));
    return createIncident;
  }

  private void updateIncident(
      final ReceivedIncidentDetailsV1 receivedIncidentDetailsV1, Incident existingIncidentToUpdate) {
    existingIncidentToUpdate.setIncidentCommentsByIncidentUuid(new ArrayList<>());
    existingIncidentToUpdate.setIncidentEvidencesByIncidentUuid(new ArrayList<>());
    if (Objects.nonNull(receivedIncidentDetailsV1.getComments())) {
      setComments(receivedIncidentDetailsV1, existingIncidentToUpdate);
    }

    existingIncidentToUpdate.setEventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime());
  }

  private void setComments(
      final ReceivedIncidentDetailsV1 receivedIncidentDetailsV1, Incident incidentComments) {
    receivedIncidentDetailsV1
        .getComments()
        .forEach(comment -> incidentComments.addIncidentComment(buildComment(comment)));
  }

  private IncidentComment buildComment(CommentDetailsV1 comment) {
    return IncidentComment.builder()
        .incidentCommentEnteredBy(comment.getCommentEnteredBy())
        .incidentCommentText(comment.getComment())
        .incidentCommentDateTime(riCommonUtil.stringToOffsetDateTime(comment.getCommentDateTime()))
        .incidentCommentUserType(IncidentCommentUserTypeEnum.REPORTER)
        .build();
  }

  @Transactional
  public void setEvidence(
      final ReceivedIncidentDetailsV1 receivedIncidentDetailsV1, Incident incidentEvidence) {
      if (Objects.nonNull(receivedIncidentDetailsV1
              .getDocumentsAttached())) {
          receivedIncidentDetailsV1
                  .getDocumentsAttached()
                  .forEach(evidence -> incidentEvidence.addIncidentEvidence(buildEvidence(evidence,
                  receivedIncidentDetailsV1.getExternalIncidentId(),
                  receivedIncidentDetailsV1.getExternalIncidentChangedDateTime())));
          incidentRepository.save(incidentEvidence);
      }

  }

  private Optional<IncidentType> getIncidentType(
      final ReceivedIncidentDetailsV1 receivedIncidentDetailsV1) {

    Optional<IncidentType> optionalIncidentType;
    if (!ObjectUtils.isEmpty(
            receivedIncidentDetailsV1.getIncidentSubTypeUuid())) {
      optionalIncidentType =
          incidentTypeRepository.findByIncidentTypeUuid(
                  receivedIncidentDetailsV1.getIncidentSubTypeUuid());
      return optionalIncidentType;
    }
    optionalIncidentType =
        incidentTypeRepository.findByIncidentTypeUuid(
                receivedIncidentDetailsV1.getIncidentTypeUuid());
    return optionalIncidentType;
  }

  private String populateObjectKey(String externalIncidentId, String externalIncidentChangedDateTime
      , String getDocumentName) {
    return String.format("incident/%s/%s/%s",
        externalIncidentId, externalIncidentChangedDateTime, getDocumentName);
  }

  private IncidentEvidence buildEvidence(
      DocumentsDetailsV1 document,
      String externalIncidentId,
      String externalIncidentChangedDateTime) {
    String objectKey = populateObjectKey(externalIncidentId, externalIncidentChangedDateTime,
        document.getDocumentName());
    try {
      fileStorageHelper.uploadFileToS3FromPresignedUrl(document.getDocumentURL(), objectKey,
          bucketName);
    } catch (IOException e) {
        log.error("Failed to buildEvidence", e);
      throw new ResultIntegrityException(
          "Pre-Singed url can not be processed: " + document.getDocumentURL());
    }
    return IncidentEvidence.builder()
        .incidentEvidenceName(document.getDocumentName())
        .incidentEvidenceUrl(objectKey)
        .build();
  }
}
