package com.ielts.cmds.ri.application.exception;

public class ResultIntegrityValidationException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public ResultIntegrityValidationException(String message, Throwable cause) {
        super(message, cause);
    }

	public ResultIntegrityValidationException() {
	}
	
	public ResultIntegrityValidationException(String message) {
		super(message);
	}
}