package com.ielts.cmds.ri.application.service;

import com.ielts.cmds.common.config.IBaseAuditService;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.plagiarism.common.out.model.PlagiarismOutcomeV1;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.domain.service.PlagiarismOutcomeReceivedDomainService;
import com.ielts.cmds.serialization.application.service.IApplicationServiceV2;
import com.ielts.cmds.serialization.utils.ServiceIdentifier;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Objects;

import static com.ielts.cmds.ri.utils.RIConstants.ErrorResponse.EMPTY_PAYLOAD;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.PLAGIARISM_OUTCOME_RECEIVED;

@Service
@ServiceIdentifier(PLAGIARISM_OUTCOME_RECEIVED)
@Slf4j
public class PlagiarismOutcomeReceivedService implements IApplicationServiceV2<PlagiarismOutcomeV1>, IBaseAuditService {

  @Autowired
  PlagiarismOutcomeReceivedDomainService plagiarismOutcomeReceivedDomainService;

  @Override
  @SneakyThrows
  public void process(PlagiarismOutcomeV1 plagiarismOutcomeV1) {
    try {
      log.debug(
          "Plagiarism Outcome Service V1 process started for request with CorrelationId:{}",
          ThreadLocalHeaderContext.getContext().getCorrelationId());
      if (Objects.isNull(plagiarismOutcomeV1)) {
        throw new IllegalArgumentException(EMPTY_PAYLOAD);
      }
      plagiarismOutcomeReceivedDomainService.on(plagiarismOutcomeV1);

    } catch (IllegalArgumentException e) {
      log.error("Failed to process Plagiarism Outcome Service event due to ", e);
      throw new ResultIntegrityException(e.getMessage());
    }
  }

  @Override
  public String getPermission() {
    return null;
  }

  @Override
  public String getScreen() {
    return null;
  }

  @Override
  public String getAction() {
    return PlagiarismOutcomeReceivedService.class.getSimpleName();
  }
}
