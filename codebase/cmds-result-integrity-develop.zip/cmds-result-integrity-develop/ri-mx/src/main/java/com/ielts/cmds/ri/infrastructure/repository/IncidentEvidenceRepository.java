package com.ielts.cmds.ri.infrastructure.repository;

import com.ielts.cmds.ri.infrastructure.entity.IncidentEvidence;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface IncidentEvidenceRepository extends JpaRepository<IncidentEvidence, UUID> {

  List<IncidentEvidence> findByIncidentUuidAndIncidentEvidenceNameIsNotNullAndIncidentEvidenceUrlIsNotNull(UUID incidentUuid);
  default List<IncidentEvidence> getEvidenceListWhereNameAndUrlIsNotNull(UUID incidentUuid) {
    return findByIncidentUuidAndIncidentEvidenceNameIsNotNullAndIncidentEvidenceUrlIsNotNull(incidentUuid);
  }
}
