package com.ielts.cmds.ri.infrastructure.repository;

import com.ielts.cmds.ri.infrastructure.entity.TestTakerPhoto;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;


@Repository
public interface TestTakerPhotoRepository extends CrudRepository<TestTakerPhoto, UUID> {

  List<TestTakerPhoto> findByBookingUuid(UUID bookingUuid);
}
