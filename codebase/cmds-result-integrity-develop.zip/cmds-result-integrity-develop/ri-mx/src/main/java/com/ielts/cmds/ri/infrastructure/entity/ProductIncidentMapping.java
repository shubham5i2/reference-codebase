package com.ielts.cmds.ri.infrastructure.entity;

import com.ielts.cmds.ri.domain.enums.IncidentSeverityEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.UUID;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "product_incident_mapping")
public class ProductIncidentMapping {

  @Id
  @Column(name = "product_incident_mapping_uuid")
  private UUID productIncidentMappingUuid;

  @Column(name = "product_uuid")
  private UUID productUuid;

  @Column(name = "incident_category_uuid")
  private UUID incidentCategoryUuid;

  @Enumerated(EnumType.STRING)
  @Column(name = "incident_severity")
  private IncidentSeverityEnum incidentSeverity;

  @Column(name = "incident_status_type_code")
  private String incidentStatusTypeCode;
}
