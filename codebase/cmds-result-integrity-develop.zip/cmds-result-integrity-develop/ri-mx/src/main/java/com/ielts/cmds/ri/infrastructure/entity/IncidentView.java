package com.ielts.cmds.ri.infrastructure.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.UUID;

@Data
@Entity
@Table(name = "incident_view")
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IncidentView {

  @Id
  @Column(name = "id")
  private UUID id;

  @Column(name = "booking_uuid")
  private UUID bookingUuid;

  @Column(name = "centre_id")
  private String centreId;

  @Column(name = "identity_number")
  private String identityNumber;

  @Column(name = "first_name")
  private String firstName;

  @Column(name = "last_name")
  private String lastName;

  @Column(name = "test_date")
  private LocalDate testDate;

  @Column(name = "unique_test_taker_uuid")
  private UUID uniqueTestTakerUuid;

  @Column(name = "short_candidate_number")
  private String shortCandidateNumber;

  @Column(name = "product_uuid")
  private UUID productUuid;

  @Column(name = "location_uuid")
  private UUID locationUuid;

  @Column(name = "unique_test_taker")
  private String uniqueTestTakerId;

  @Column(name = "incident_uuid")
  private UUID incidentUuid;

  @Column(name = "incident_category_uuid")
  private UUID incidentCategoryUuid;

  @Column(name = "incident_type_uuid")
  private UUID incidentTypeUuid;

  @Column(name = "incident_severity")
  private String incidentSeverity;

  @Column(name = "ban_review_required")
  private Boolean banReviewRequired;

  @Column(name = "incident_status_type_uuid")
  private UUID incidentStatusTypeUuid;

  @Column(name = "created_datetime")
  private OffsetDateTime createdDatetime;

}
