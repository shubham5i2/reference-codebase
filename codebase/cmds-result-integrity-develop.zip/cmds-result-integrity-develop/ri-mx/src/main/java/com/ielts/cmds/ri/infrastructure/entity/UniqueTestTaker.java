package com.ielts.cmds.ri.infrastructure.entity;

import java.util.List;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Entity
@Table(name = "unique_test_taker")
@ToString(exclude = "booking")
public class UniqueTestTaker extends CommonModel {

 @Id
 @Column(name = "unique_test_taker_uuid")
 private UUID uniqueTestTakerUuid;

 @Column(name = "unique_test_taker")
 private String uniqueTestTaker;

 @OneToMany(mappedBy = "uniqueTestTaker")
 private List<Booking> booking;
}
