package com.ielts.cmds.ri.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.context.CMDSErrorContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalErrorContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.ri.common.model.out.BookingDetailsV1;
import com.ielts.cmds.ri.common.model.out.CommentDetailsV1;
import com.ielts.cmds.ri.common.model.out.CommentsV1;
import com.ielts.cmds.ri.common.model.out.IncidentEvidenceV1;
import com.ielts.cmds.ri.common.model.out.IncidentEvidenceV1Inner;
import com.ielts.cmds.ri.common.model.out.IncidentSearchResultDetailsV1;
import com.ielts.cmds.ri.common.model.out.IncidentSeverityEnum;
import com.ielts.cmds.ri.common.model.out.ResultIntegrityIncidentDetailsV1;
import com.ielts.cmds.ri.common.model.out.ViewIncidentDetailsListV1;
import com.ielts.cmds.ri.common.model.out.ViewIncidentDetailsV1;
import com.ielts.cmds.ri.infrastructure.entity.IncidentView;
import com.ielts.cmds.ri.infrastructure.repository.IncidentCommentRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentEvidenceRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentViewRepository;
import com.ielts.cmds.ri.utils.GenerateS3SignedUrl;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.ri.utils.RIConstants.ErrorCodes;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.encoder.org.apache.commons.lang3.StringUtils;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.ConstraintViolation;

import static com.ielts.cmds.ri.utils.RIConstants.EventType.INCIDENT_VIEW_RESPONSE_DETAILS_GENERATED_EVENT;
import static com.ielts.cmds.ri.utils.RIConstants.GenericConstants.TEST_CENTRE;
import static com.ielts.cmds.ri.utils.RIConstants.PermissionId.RI_INCIDENT_VIEW;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;


@Slf4j
@Service
public class IncidentViewDomainService extends AbstractCMDSDomainService<ViewIncidentDetailsListV1> {

    private final IncidentViewRepository incidentViewRepository;

    private final IncidentCommentRepository incidentCommentRepository;

    private final IncidentEvidenceRepository incidentEvidenceRepository;

    private final CMDSErrorResolver<Object> errorResolver;

    private final RICommonUtil commonUtil;

    private final String bucketName;

    private final GenerateS3SignedUrl generateS3SignedUrl;

    @Autowired
    public IncidentViewDomainService(ApplicationEventPublisher publisher,
                                     ObjectMapper objectMapper,
                                     @Value("${incidentView.v2}") String isV2Enabled,
                                     CMDSThreadLocalContextService cmdsThreadLocalContextService,
                                     IncidentViewRepository incidentViewRepository,
                                     IncidentCommentRepository incidentCommentRepository,
                                     IncidentEvidenceRepository incidentEvidenceRepository,
                                     CMDSErrorResolver<Object> errorResolver,
                                     RICommonUtil commonUtil,
                                     @Value("${ri-bucket}") String bucketName,
                                     GenerateS3SignedUrl generateS3SignedUrl) {
        super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
        this.incidentViewRepository = incidentViewRepository;
        this.incidentCommentRepository = incidentCommentRepository;
        this.incidentEvidenceRepository = incidentEvidenceRepository;
        this.errorResolver = errorResolver;
        this.commonUtil = commonUtil;
        this.bucketName = bucketName;
        this.generateS3SignedUrl = generateS3SignedUrl;
    }

    @Transactional(noRollbackFor = RuntimeException.class)
    public void on() throws JsonProcessingException, RbacValidationException {

        log.debug("IncidentViewDomainService.on : {}", ThreadLocalHeaderContext.getContext().getTransactionId());
        if (!commonUtil.hasAllAccess(
                ThreadLocalHeaderContext.getContext().getXaccessToken(),
                RI_INCIDENT_VIEW)) {
            log.info(
                    "You do not have permission to view incident details. Please contact your administrator if you do not think this correct.");
            Set<ConstraintViolation<Object>> violations =
                    RICommonUtil.getSetforNullViolationOfEventBody
                            (ErrorCodes.UNAUTHORISED_TO_VIEW_INCIDENT, "unauthorisedToViewIncident");
            publishEventToOutBoundTopic(null,  violations);
        } else {
            ViewIncidentDetailsListV1 incidentDetailsResponse = null;
            List<IncidentView> incidentDetailList = getIncidentDetail(UUID.fromString
                    (ThreadLocalHeaderContext.getContext().getEventContext().get("bookingUuid")));

            if (CollectionUtils.isNotEmpty(incidentDetailList)) {
                log.info("Generating response ");
                incidentDetailsResponse = generateIncidentResponseData(incidentDetailList);
            } else {
                log.info("Incident Data not found in database");
            }
            publishEventToOutBoundTopic(incidentDetailsResponse, null);
        }
    }

    List<IncidentView> getIncidentDetail(UUID bookingUuid) {
        return incidentViewRepository.findByBookingUuidOrderByCreatedDatetime(bookingUuid);
    }


    ViewIncidentDetailsListV1 generateIncidentResponseData(List<IncidentView> incidentViewList) throws RbacValidationException {
        log.info("IncidentViewDomainService for generateIncidentResponseData");
        List<ViewIncidentDetailsV1> viewIncidentDetailsV1List = new ArrayList<>();

        for (IncidentView incidentView : incidentViewList) {
            ViewIncidentDetailsV1 viewIncidentDetailsV1 = ViewIncidentDetailsV1
                    .builder()
                    .incidentBookingDetails(IncidentSearchResultDetailsV1
                            .builder()
                            .bookingDetails(BookingDetailsV1
                                    .builder()
                                    .bookingUuid(String.valueOf(incidentView.getBookingUuid()))
                                    .uniqueTestTakerUuid(String.valueOf(incidentView.getUniqueTestTakerUuid()))
                                    .uniqueTestTakerId(incidentView.getUniqueTestTakerId())
                                    .shortCandidateNumber(incidentView.getShortCandidateNumber())
                                    .locationUuid(Objects.nonNull(incidentView.getLocationUuid()) ? String.valueOf(
                                            commonUtil.getParentNode(incidentView.getLocationUuid(), TEST_CENTRE)
                                                    .getLocationUuid()) : null)
                                    .productUuid(String.valueOf(incidentView.getProductUuid()))
                                    .firstName(incidentView.getFirstName())
                                    .lastName(incidentView.getLastName())
                                    .testDate(incidentView.getTestDate())
                                    .identityNumber(incidentView.getIdentityNumber())
                                    .build())
                            .incidentDetails(ResultIntegrityIncidentDetailsV1
                                    .builder()
                                    .bookingUuid(String.valueOf(incidentView.getBookingUuid()))
                                    .incidentUuid(String.valueOf(incidentView.getIncidentUuid()))
                                    .incidentCategoryUuid(String.valueOf(incidentView.getIncidentCategoryUuid()))
                                    .incidentTypeUuid(String.valueOf(incidentView.getIncidentTypeUuid()))
                                    .incidentStatusTypeUuid(String.valueOf(incidentView.getIncidentStatusTypeUuid()))
                                    .incidentSeverity((incidentView.getIncidentSeverity()!=null)
                                            ? IncidentSeverityEnum.valueOf(incidentView.getIncidentSeverity()):null)
                                    .banReviewRequired(incidentView.getBanReviewRequired())
                                        .comments(setComments(incidentView.getIncidentUuid()))
                                    .evidences(setEvidences(incidentView.getIncidentUuid()))
                                    .build())
                            .build())
                    .build();

            viewIncidentDetailsV1List.add(viewIncidentDetailsV1);
        }
        log.info("Exiting generateIncidentResponseData");
        return ViewIncidentDetailsListV1
                .builder()
                .entries(viewIncidentDetailsV1List)
                .build();

    }

    CommentsV1 setComments(final UUID incidentUuid) {
        CommentsV1 commentsV1 = new CommentsV1();
        commentsV1.addAll(commentDetailsV1ArrayList(incidentUuid));
        return commentsV1;
    }

    ArrayList<CommentDetailsV1> commentDetailsV1ArrayList(final UUID incidentUuid) {
        log.info("IncidentViewDomainService for commentDetailsV1ArrayList");
        ArrayList<CommentDetailsV1> commentDetailsV1List = new ArrayList<>();
        new ArrayList<>(incidentCommentRepository.findByIncidentUuidOrderByUpdatedDateTimeDesc(incidentUuid))
                .forEach(
                        item ->
                                commentDetailsV1List.add(
                                        CommentDetailsV1.builder()
                                                .comment(item.getIncidentCommentText())
                                                .commentDateTime(
                                                        item.getIncidentCommentDateTime() != null
                                                                ? item.getIncidentCommentDateTime().toString()
                                                                : "")
                                                .commentEnteredBy(item.getIncidentCommentEnteredBy())
                                                .userType(item.getIncidentCommentUserType() !=null
                                                    ? item.getIncidentCommentUserType().toString()
                                                    :"")
                                                .build())
                );
        return commentDetailsV1List;
    }

    IncidentEvidenceV1 setEvidences(final UUID incidentUuid) {
        IncidentEvidenceV1 incidentEvidenceV1 = new IncidentEvidenceV1();
        incidentEvidenceV1.addAll(incidentEvidenceV1ArrayList(incidentUuid));
        return incidentEvidenceV1;
    }

    ArrayList<IncidentEvidenceV1Inner> incidentEvidenceV1ArrayList(final UUID incidentUuid) {
        log.info("IncidentViewDomainService for incidentEvidenceV1ArrayList");
        ArrayList<IncidentEvidenceV1Inner> incidentEvidenceV1List = new ArrayList<>();
        new ArrayList<>(incidentEvidenceRepository
            .getEvidenceListWhereNameAndUrlIsNotNull(incidentUuid))
                .forEach(
                        item ->
                                incidentEvidenceV1List.add(
                                        IncidentEvidenceV1Inner.builder()
                                                .evidenceName(item.getIncidentEvidenceName())
                                                .evidenceUrl(getSignedUrl(item.getIncidentEvidenceUrl()))
                                                .evidenceFileExtention(extractFileExtension(item.getIncidentEvidenceName()))
                                                .build())
                );

        return incidentEvidenceV1List;
    }

    String getSignedUrl(String incidentEvidenceUrl) {
        return generateS3SignedUrl.apply(bucketName, incidentEvidenceUrl);
    }


    String extractFileExtension(String incidentEvidenceName) {
        return StringUtils.substringAfter(incidentEvidenceName, ".");
    }

    public void publishEventToOutBoundTopic(
            final ViewIncidentDetailsListV1 incidentDetailResponse,
            final Set<ConstraintViolation<Object>> violations) {

        final ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.findAndRegisterModules();
        ThreadLocalHeaderContext.getContext()
                .setEventName(INCIDENT_VIEW_RESPONSE_DETAILS_GENERATED_EVENT);

        log.debug("publishEventToOutBoundTopic: {}", ThreadLocalHeaderContext.getContext().getEventName());

        if (Objects.nonNull(incidentDetailResponse)) {
            commonUtil.publishLog();
            publishEvent(incidentDetailResponse);
        } else {
            if (CollectionUtils.isNotEmpty(violations)) {
                CMDSErrorResponse eventErrors =
                        errorResolver.populatErrorResponse(
                                violations, ThreadLocalHeaderContext.getContext().getEventName());
                ThreadLocalErrorContext.setContext(new CMDSErrorContext(eventErrors.getErrorList()));
            }
            commonUtil.publishLog();
            publishEvent(null, ThreadLocalErrorContext.getContext().getErrorList());
        }
    }
}
