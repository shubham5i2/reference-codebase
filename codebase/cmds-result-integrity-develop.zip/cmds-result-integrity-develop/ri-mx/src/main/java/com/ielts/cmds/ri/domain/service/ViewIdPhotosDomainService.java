package com.ielts.cmds.ri.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.context.CMDSErrorContext;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalErrorContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.ri.common.model.out.BookingDetailsV1;
import com.ielts.cmds.ri.common.model.out.BookingIdPhotoDetailsV1;
import com.ielts.cmds.ri.common.model.out.PhotosV1;
import com.ielts.cmds.ri.common.model.out.PhotosV1Inner;
import com.ielts.cmds.ri.domain.enums.PhotoCategoryEnum;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeType;
import com.ielts.cmds.ri.infrastructure.entity.PhotoType;
import com.ielts.cmds.ri.infrastructure.entity.TestTakerPhoto;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.PhotoTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.TestTakerPhotoRepository;
import com.ielts.cmds.ri.utils.GenerateS3SignedUrl;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.ri.utils.RIConstants.ErrorCodes;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.ConstraintViolation;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import static com.ielts.cmds.ri.utils.RIConstants.CheckOutcomeTypeConstants.CHK_OUT_TYPE_LRW_ID_INC_CHK_CODE;
import static com.ielts.cmds.ri.utils.RIConstants.EventType.ID_PHOTOS_RESPONSE_GENERATED_EVENT;
import static com.ielts.cmds.ri.utils.RIConstants.GenericConstants.TEST_CENTRE;
import static com.ielts.cmds.ri.utils.RIConstants.PermissionId.RI_ID_CHECK_VIEW;


@Slf4j
@Service
public class ViewIdPhotosDomainService extends AbstractCMDSDomainService<BookingIdPhotoDetailsV1> {

    private final BookingRepository bookingRepository;
    private final CheckOutcomeRepository checkOutcomeRepository;
    private final CheckOutcomeTypeRepository checkOutcomeTypeRepository;
    private final TestTakerPhotoRepository testTakerPhotoRepository;
    private final PhotoTypeRepository photoTypeRepository;
    private final String bucketName;
    private final GenerateS3SignedUrl generateS3SignedUrl;
    private final CMDSErrorResolver<Object> errorResolver;
    private final RICommonUtil commonUtil;

    @Autowired
    public ViewIdPhotosDomainService(ApplicationEventPublisher publisher,
                                     ObjectMapper objectMapper,
                                     @Value("${idPhotosResponseGenerated.v2}") String isV2Enabled,
                                     CMDSThreadLocalContextService cmdsThreadLocalContextService,
                                     BookingRepository bookingRepository,
                                     CheckOutcomeRepository checkOutcomeRepository,
                                     CheckOutcomeTypeRepository checkOutcomeTypeRepository,
                                     TestTakerPhotoRepository testTakerPhotoRepository,
                                     PhotoTypeRepository photoTypeRepository,
                                     @Value("${tt.photo.bucket.name}") String bucketName,
                                     GenerateS3SignedUrl generateS3SignedUrl,
                                     CMDSErrorResolver<Object> errorResolver,
                                     RICommonUtil commonUtil) {
        super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
        this.bookingRepository = bookingRepository;
        this.checkOutcomeRepository = checkOutcomeRepository;
        this.checkOutcomeTypeRepository = checkOutcomeTypeRepository;
        this.testTakerPhotoRepository = testTakerPhotoRepository;
        this.photoTypeRepository = photoTypeRepository;
        this.bucketName = bucketName;
        this.generateS3SignedUrl = generateS3SignedUrl;
        this.errorResolver = errorResolver;
        this.commonUtil = commonUtil;
    }

    @Transactional(noRollbackFor = RuntimeException.class)
    public void on() throws JsonProcessingException, RbacValidationException {
        log.info("ViewIdPhotosDomainService.on");
        if (!commonUtil.hasAllAccess(
                ThreadLocalHeaderContext.getContext().getXaccessToken(),
                RI_ID_CHECK_VIEW)) {
            log.info(
                    "You do not have permission to view ID verification status. Please contact your administrator if you do not think this correct.");
            Set<ConstraintViolation<Object>> violations =
                    RICommonUtil.getSetforNullViolationOfEventBody
                            (ErrorCodes.UNAUTHORISED_TO_VIEW_ID_VERIFICATION_STATUS, "unauthorisedToViewIDVerificationStatus");
            publishViewIdPhotosEventToOutBoundTopic(null, violations);
        } else {
            BookingIdPhotoDetailsV1 bookingIdPhotoDetailResponse = null;
            Optional<Booking> bookingDetail = getBookingDetail(ThreadLocalHeaderContext.getContext());

            if (bookingDetail.isPresent()) {
                log.info("Generating response ");
                bookingIdPhotoDetailResponse = generateIdPhotosResponseData(bookingDetail.get());
            } else {
                log.info("Booking Data not found in database");
            }

            publishViewIdPhotosEventToOutBoundTopic
                    (bookingIdPhotoDetailResponse,  null);

        }
    }

    Optional<Booking> getBookingDetail(final CMDSHeaderContext  baseHeader) {
        UUID bookingUuid = UUID.fromString(baseHeader.getEventContext().get("bookingUuid"));
        return bookingRepository.findById(bookingUuid);
    }


    BookingIdPhotoDetailsV1 generateIdPhotosResponseData(Booking bookingDetail) throws RbacValidationException {

        return BookingIdPhotoDetailsV1
                .builder()
                .checkOutcomeStatusUuid(getCheckOutcomeStatusUuid(bookingDetail.getBookingUuid()))
                .bookingDetails(BookingDetailsV1.builder()
                        .bookingUuid(bookingDetail.getBookingUuid().toString())
                        .uniqueTestTakerUuid(bookingDetail.getUniqueTestTakerUuid().toString())
                        .uniqueTestTakerId(bookingDetail.getUniqueTestTaker().getUniqueTestTaker())
                        .shortCandidateNumber(bookingDetail.getShortCandidateNumber().toString())
                        .locationUuid((bookingDetail.getLocationUuid()!=null)?String.valueOf(
                                commonUtil.getParentNode(bookingDetail.getLocationUuid(), TEST_CENTRE)
                                        .getLocationUuid()):null)
                        .productUuid(bookingDetail.getProductUuid().toString())
                        .firstName(bookingDetail.getFirstName())
                        .lastName(bookingDetail.getLastName())
                        .testDate(bookingDetail.getTestDate().getLocalDate())
                        .identityNumber(bookingDetail.getIdentityNumber())
                        .build())
                .photos(setPhotos(bookingDetail.getBookingUuid()))
                .build();
    }

    String getCheckOutcomeStatusUuid(UUID bookingUuid) {

        CheckOutcomeType checkOutcomeType = getCheckOutComeType();
        CheckOutcome checkOutcome = getCheckOutcome(bookingUuid, checkOutcomeType);

        if (Objects.nonNull(checkOutcome)) {
            return checkOutcome.getCheckOutcomeStatus().getCheckOutcomeStatusUuid().toString();
        }
        return null;
    }

    CheckOutcomeType getCheckOutComeType() {
        CheckOutcomeType checkOutcomeType = null;
        Optional<CheckOutcomeType> optionalCheckOutcomeType =
                checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(CHK_OUT_TYPE_LRW_ID_INC_CHK_CODE);
        if (optionalCheckOutcomeType.isPresent()) {
            checkOutcomeType = optionalCheckOutcomeType.get();
        }
        return checkOutcomeType;
    }

    CheckOutcome getCheckOutcome(UUID bookingUuid, CheckOutcomeType checkOutcomeType) {
        Optional<CheckOutcome> optionalCheckOutcome = checkOutcomeRepository
                .findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(bookingUuid, checkOutcomeType.getCheckOutcomeTypeUuid());
        return optionalCheckOutcome.orElse(null);
    }

    PhotosV1 setPhotos(final UUID bookingUuid) {
        PhotosV1 photosV1 = new PhotosV1();
        photosV1.addAll(photosV1ArrayList(bookingUuid));
        return photosV1;
    }

    ArrayList<PhotosV1Inner> photosV1ArrayList(final UUID bookingUuid) {

        ArrayList<PhotosV1Inner> photosV1ArrayList = new ArrayList<>();

        List<TestTakerPhoto> testTakerPhotoList =
                testTakerPhotoRepository.findByBookingUuid(bookingUuid); //List1

        List<String> staticPhotoTypeCodeList = commonUtil.getPhotoTypeConstantsList(); //List2

        Map<UUID, String> photoTypeUuidMapByStaticTypeCode =
                getPhotoTypeUuidMapByStaticTypeCode(); //Map1

        List<UUID> photoTypeUuidList = new ArrayList<>();
      for(String photoTypeCode : staticPhotoTypeCodeList) {
        photoTypeUuidList.addAll(photoTypeUuidMapByStaticTypeCode.entrySet().stream()
            .filter(entry -> Objects.equals(entry.getValue(), photoTypeCode))
            .map(Map.Entry::getKey)
            .collect(Collectors.toList()));
      }

        List<TestTakerPhoto> testTakerPhotoListForSpecifiedPhotoType =
                testTakerPhotoList.stream().
                        filter(testTakerPhoto -> photoTypeUuidList.stream()
                                .anyMatch(photoTypeUuid -> testTakerPhoto.getPhotoTypeUuid().equals(photoTypeUuid)))
                        .collect(Collectors.toList()); //List3

        List<TestTakerPhoto> testTakerCertificatePhotoList =
            testTakerPhotoList.stream().filter(testTakerPhoto ->
            testTakerPhoto.getPhotoCategory() == PhotoCategoryEnum.CERTIFICATE).collect(
            Collectors.toList());

        testTakerPhotoListForSpecifiedPhotoType.addAll(testTakerCertificatePhotoList);

        new ArrayList<>(testTakerPhotoListForSpecifiedPhotoType)
                .forEach(
                        item ->
                                photosV1ArrayList.add(
                                        PhotosV1Inner.builder()
                                                .photoUuid(item.getPhotoUuid().toString())
                                                .photoTypeUuid(item.getPhotoTypeUuid().toString())
                                                .photoTypeCode(photoTypeUuidMapByStaticTypeCode.get(item.getPhotoTypeUuid()))
                                                .photoUrl(getSignedUrl(item.getPhotoPath()))
                                                .build())
                );
        return photosV1ArrayList;
    }

    private Map<UUID, String> getPhotoTypeUuidMapByStaticTypeCode() {

        Map<UUID, String> photoTypeUuidMapByStaticTypeCode = new HashMap<>(); //Map1
        Iterable<PhotoType> photoTypeList = photoTypeRepository.findAll();

        for(PhotoType photoType : photoTypeList)
        {
            UUID photoTypeUuid = photoType.getPhotoTypeUuid();
            String photoTypeCode = photoType.getPhotoTypeCode();
            photoTypeUuidMapByStaticTypeCode.put(photoTypeUuid, photoTypeCode);
        }
        return photoTypeUuidMapByStaticTypeCode;
    }

    String getSignedUrl(String photoPath) {
        return generateS3SignedUrl.apply(bucketName, photoPath);
    }


    public void publishViewIdPhotosEventToOutBoundTopic(
            final BookingIdPhotoDetailsV1 bookingIdPhotoDetailResponse,
            final Set<ConstraintViolation<Object>> violations) {

        ThreadLocalHeaderContext.getContext().setEventName(ID_PHOTOS_RESPONSE_GENERATED_EVENT);
        log.debug("publishEventToOutBoundTopic: {}", ThreadLocalHeaderContext.getContext().getEventName());

        if (Objects.nonNull(bookingIdPhotoDetailResponse)) {
            commonUtil.publishLog();
            publishEvent(bookingIdPhotoDetailResponse);
        } else {
            if (CollectionUtils.isNotEmpty(violations)) {
                CMDSErrorResponse eventErrors =
                        errorResolver.populatErrorResponse(
                                violations, ThreadLocalHeaderContext.getContext().getEventName());
                ThreadLocalErrorContext.setContext(new CMDSErrorContext(eventErrors.getErrorList()));
            }
            commonUtil.publishLog();
            publishEvent(null,ThreadLocalErrorContext.getContext().getErrorList());

        }
    }
}
