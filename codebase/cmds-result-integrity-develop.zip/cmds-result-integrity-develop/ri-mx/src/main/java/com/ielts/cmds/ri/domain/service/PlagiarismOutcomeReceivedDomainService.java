package com.ielts.cmds.ri.domain.service;

import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_FAILED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_PASSED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_PENDING;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.INCIDENT_STATUS_TYPE_CODE_INVESTIGATION;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.INCIDENT_STATUS_TYPE_CODE_PASSED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.INCIDENT_TYPE_CODE_PLAGIARISM;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.PLAGIARISM_OUTCOME_CLEARED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.PLAGIARISM_OUTCOME_INDETERMINANT;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.PLAGIARISM_OUTCOME_PLAGIARISED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.PLAGIARISM_OUTCOME_UNDER_INVESTIGATION;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.evt074.ResultIntegrityIncidentDetailsWrapperV1;
import com.ielts.cmds.api.evt119.CheckOutcomeV1;
import com.ielts.cmds.api.evt119.IntegrityCheckInitiatedV1;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.plagiarism.common.enums.PlagiarismOutcomeEnum;
import com.ielts.cmds.plagiarism.common.out.model.CommentsV1;
import com.ielts.cmds.plagiarism.common.out.model.PlagiarismOutcomeV1;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.domain.enums.IncidentSeverityEnum;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeType;
import com.ielts.cmds.ri.infrastructure.entity.Incident;
import com.ielts.cmds.ri.infrastructure.entity.IncidentComment;
import com.ielts.cmds.ri.infrastructure.entity.IncidentStatusType;
import com.ielts.cmds.ri.infrastructure.entity.IncidentType;
import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatus;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentStatusTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.ProductIncidentMappingRepository;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;
import com.ielts.cmds.serialization.domain.EnableOutboundEventV2;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@EnableOutboundEventV2
public class PlagiarismOutcomeReceivedDomainService extends AbstractCMDSDomainService<Object> {

  private final BookingRepository bookingRepository;

  private final CheckOutcomeTypeRepository checkOutcomeTypeRepository;

  private final CheckOutcomeRepository checkOutcomeRepository;

  private final CheckOutcomeStatusRepository checkOutcomeStatusRepository;

  private final IncidentTypeRepository incidentTypeRepository;

  private final IncidentStatusTypeRepository incidentStatusTypeRepository;

  private final ProductIncidentMappingRepository productIncidentMappingRepository;

  private final RICommonUtil riCommonUtil;

  private final OutcomeStatusRepository outcomeStatusRepository;

  @Autowired
	public PlagiarismOutcomeReceivedDomainService(ApplicationEventPublisher publisher,
                                                  ObjectMapper objectMapper,
                                                  @Value("${plagiarismOutcomeReceived.v2}") String isV2Enabled,
                                                  CMDSThreadLocalContextService cmdsThreadLocalContextService,
                                                  BookingRepository bookingRepository,
                                                  CheckOutcomeTypeRepository checkOutcomeTypeRepository,
                                                  CheckOutcomeRepository checkOutcomeRepository,
                                                  CheckOutcomeStatusRepository checkOutcomeStatusRepository,
                                                  IncidentTypeRepository incidentTypeRepository,
                                                  IncidentStatusTypeRepository incidentStatusTypeRepository,
                                                  ProductIncidentMappingRepository productIncidentMappingRepository,
                                                  RICommonUtil riCommonUtil,
                                                  OutcomeStatusRepository outcomeStatusRepository) {
		super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
		this.bookingRepository = bookingRepository;
		this.checkOutcomeTypeRepository = checkOutcomeTypeRepository;
		this.checkOutcomeRepository = checkOutcomeRepository;
		this.checkOutcomeStatusRepository = checkOutcomeStatusRepository;
		this.incidentTypeRepository = incidentTypeRepository;
		this.incidentStatusTypeRepository = incidentStatusTypeRepository;
		this.productIncidentMappingRepository = productIncidentMappingRepository;
		this.riCommonUtil = riCommonUtil;
		this.outcomeStatusRepository = outcomeStatusRepository;
	}

  @Transactional
  @SneakyThrows
  public void on(final PlagiarismOutcomeV1 plagiarismOutcomeV1) {

    try {
      Optional<Booking> optionalBooking=bookingRepository.findByCompositeCandidateNumber(plagiarismOutcomeV1.getPlagiarismOutcomeDetails().getCompositeCandidateNumber());

      CheckOutcome checkOutcome = updatePlagiarismOutcome(plagiarismOutcomeV1,optionalBooking.orElse(null));

      publishIntegrityCheckInitiatedEvent(checkOutcome);

      publishIntegrityIncidentDetailsRaisedEvent(checkOutcome,optionalBooking.orElse(null));

    } catch (ResultIntegrityException e) {
      log.warn("PlagiarismOutcomeCommand execution failed", e);
      throw new ResultIntegrityException(e.getMessage());
    }
  }

  public CheckOutcome updatePlagiarismOutcome(PlagiarismOutcomeV1 plagiarismOutcomeV1, Booking optionalBooking) {
    log.debug(
        "PlagiarismOutcomeReceivedDomainService | updatePlagiarismOutcome for composite candidate number : {}",
        plagiarismOutcomeV1.getPlagiarismOutcomeDetails().getCompositeCandidateNumber());
    CheckOutcome checkOutcomeEntity;
        if (Objects.nonNull(optionalBooking)) {
        checkOutcomeEntity =
                checkOutcomeRepository.save(setCheckOutcome(plagiarismOutcomeV1, optionalBooking));
        Optional<OutcomeStatus> optionalOutcomeStatus = outcomeStatusRepository
                .findByBookingUuid(optionalBooking.getBookingUuid());
        OutcomeStatus outcomeStatus = optionalOutcomeStatus.orElseGet(() -> OutcomeStatus.builder().build());
        outcomeStatus.setBookingVersion(checkOutcomeEntity.getBookingVersion());
        outcomeStatusRepository.save(outcomeStatus);
    }
    else {
      throw new ResultIntegrityException("Booking not found!!");
    }
    return checkOutcomeEntity;
  }

  private CheckOutcome setCheckOutcome(PlagiarismOutcomeV1 plagiarismOutcomeV1, Booking booking) {
    log.info("PlagiarismOutcomeReceivedDomainService CheckOutcome for plagiarism event");
    CheckOutcomeType checkOutcomeType = getCheckOutComeType();

    CheckOutcome checkOutcome;

    // find existing check outcome with booking uuid and Plagiarism check outcome type
    Optional<CheckOutcome> optionalCheckOutcome =
        checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
            booking.getBookingUuid(), Optional.ofNullable(checkOutcomeType).map(CheckOutcomeType::getCheckOutcomeTypeUuid).orElse(null));

    checkOutcome =
        optionalCheckOutcome.orElseGet(
            () -> {
              log.debug("creating a new check outcome for booking: {}", booking.getBookingUuid());
              CheckOutcome checkOutcomeToCreate =
                  CheckOutcome.builder()
                      .checkOutcomeStatus(
                          setCheckOutComeStatus(plagiarismOutcomeV1))
                      .checkOutcomeType(checkOutcomeType)
                      .bookingUuid(booking.getBookingUuid())
                          .bookingVersion(booking.getBookingVersion())
                          .eventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime())
                      .build();

              // add incident to check outcome
              checkOutcomeToCreate.setIncidentsByCheckOutcomeUuid(
                  getIncidentCollection(plagiarismOutcomeV1, booking, checkOutcomeToCreate));
              return checkOutcomeToCreate;
            });
    //booking.getBookingVersion= newVersion ,,,optionalCheckOutcome.get().getBookingVersion())=oldVersion
    if (optionalCheckOutcome.isPresent() ) {
        log.debug(
                "existing checkOutcome is present : {}",
                optionalCheckOutcome.get().getCheckOutcomeUuid());

        checkOutcome.setCheckOutcomeStatus(
                setCheckOutComeStatus(plagiarismOutcomeV1));
        checkOutcome.setCheckOutcomeType(checkOutcomeType);
        checkOutcome.setBookingUuid(booking.getBookingUuid());
                checkOutcome.setIncidentsByCheckOutcomeUuid(
                getIncidentCollection(plagiarismOutcomeV1, booking, checkOutcome));
        checkOutcome.setBookingVersion(booking.getBookingVersion());
        checkOutcome.setEventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime());
      }
    return checkOutcome;
  }

  private List<Incident> getIncidentCollection(
      PlagiarismOutcomeV1 plagiarismOutcomeV1, Booking booking, CheckOutcome checkOutcome) {

    List<Incident> plagiarismIncidentList = new ArrayList<>();

    if (CollectionUtils.isNotEmpty(checkOutcome.getIncidentsByCheckOutcomeUuid())) {

      plagiarismIncidentList.addAll(
          checkOutcome.getIncidentsByCheckOutcomeUuid().stream()
              .filter(
                  incident ->
                          RIConstants.PrcOutcomeConstant.INCIDENT_TYPE_CODE_PLAGIARISM.equals(
                          incident.getIncidentTypeByIncidentTypeUuid().getIncidentTypeCode()))
              .collect(Collectors.toList()));

      plagiarismIncidentList.forEach(
          incident -> {
            setIncidentStatusType(
                incident,
                plagiarismOutcomeV1.getPlagiarismOutcomeDetails().getOutcome().getValue());
            incident.setIncidentCommentsByIncidentUuid(new ArrayList<>());
            incident.setIncidentSeverity(mapPlagiarismStatusToIncidentSeverity(
                plagiarismOutcomeV1.getPlagiarismOutcomeDetails().getOutcome()));
          });
      log.debug("updating existing incident : {}", plagiarismIncidentList.get(0).getIncidentUuid());
      getIncidentCommentCollection(plagiarismOutcomeV1, plagiarismIncidentList.get(0));
      return plagiarismIncidentList;
    }

    plagiarismIncidentList.add(
        setIncident(plagiarismOutcomeV1, booking.getBookingUuid(), checkOutcome));
    return plagiarismIncidentList;
  }

  private Incident setIncident(
      PlagiarismOutcomeV1 plagiarismOutcomeV1, UUID bookingUuid, CheckOutcome checkOutcome) {

    IncidentType incidentType = getIncidentType();
    log.debug("creating new incident for bookingUuid: {} and type: {}", bookingUuid, incidentType);

    Incident incidentToCreate =
        Incident.builder()
            .incidentCategoryByIncidentCategoryUuid(
                Objects.nonNull(incidentType)
                    ? incidentType.getIncidentCategoryByIncidentCategoryUuid()
                    : null)
            .incidentTypeByIncidentTypeUuid(incidentType)
            .bookingUuid(bookingUuid)
            .incidentSeverity(
                mapPlagiarismStatusToIncidentSeverity(
                    plagiarismOutcomeV1.getPlagiarismOutcomeDetails().getOutcome()))
            .checkOutcomeByCheckOutcomeUuid(checkOutcome)
            .incidentCommentsByIncidentUuid(new ArrayList<>())
                .eventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime())
            .build();
    setIncidentStatusType(
        incidentToCreate,
        plagiarismOutcomeV1.getPlagiarismOutcomeDetails().getOutcome().getValue());
    getIncidentCommentCollection(plagiarismOutcomeV1, incidentToCreate);
    return incidentToCreate;
  }

  public IncidentSeverityEnum mapPlagiarismStatusToIncidentSeverity(
      PlagiarismOutcomeEnum plagiarismOutcomeEnum) {

    switch (plagiarismOutcomeEnum) {
      case PLAGIARISED:
        return IncidentSeverityEnum.CONFIRMED_MALPRACTICE;
      case CLEARED:
      case INDETERMINANT:
        return null;
      case UNDER_INVESTIGATION:
        return IncidentSeverityEnum.INFO;
      default:
        throw new ResultIntegrityException("Invalid Plagiarism Status");
    }
  }

  private void getIncidentCommentCollection(
      PlagiarismOutcomeV1 plagiarismOutcomeV1, Incident incident) {
    if(CollectionUtils.isNotEmpty(plagiarismOutcomeV1.getPlagiarismOutcomeDetails().getInvestigationComments())) {
      plagiarismOutcomeV1
              .getPlagiarismOutcomeDetails()
              .getInvestigationComments()
              .forEach(
                      investigationComment ->
                              incident.addIncidentComment(setIncidentComment(incident, investigationComment))
              );
    }
  }

  private IncidentComment setIncidentComment(Incident incident, CommentsV1 investigationComment) {
    return IncidentComment.builder()
        .incidentByIncidentUuid(incident)
        .incidentCommentText(investigationComment.getComment())
        .incidentCommentEnteredBy(investigationComment.getCommentEnteredBy())
        .incidentCommentDateTime(
            riCommonUtil.stringToOffsetDateTime(investigationComment.getCommentDateTime()))
        .build();
  }

  private void setIncidentStatusType(Incident incident, String plagiarismOutcome) {
    String incidentStatusTypeCode = mapPlagiarismOutcomeToIncidentStatusType(plagiarismOutcome,incident);
    Optional<IncidentStatusType> optionalIncidentStatusType =
        incidentStatusTypeRepository.findByIncidentStatusTypeCode(incidentStatusTypeCode);

    incident.setIncidentStatusTypeByIncidentStatusTypeUuid(optionalIncidentStatusType.orElse(null));
  }

  protected String mapPlagiarismOutcomeToIncidentStatusType(String plagiarismOutcome,Incident incident) {
    Booking booking = riCommonUtil.getBooking(incident);
    switch (plagiarismOutcome) {
      case PLAGIARISM_OUTCOME_CLEARED:
      case PLAGIARISM_OUTCOME_INDETERMINANT:
        return INCIDENT_STATUS_TYPE_CODE_PASSED;
      case PLAGIARISM_OUTCOME_PLAGIARISED:
        return productIncidentMappingRepository
            .findByProductUuidAndIncidentCategoryUuid(booking.getProductUuid(),
                incident.getIncidentCategoryByIncidentCategoryUuid().getIncidentCategoryUuid())
            .getIncidentStatusTypeCode();
      case PLAGIARISM_OUTCOME_UNDER_INVESTIGATION:
        return INCIDENT_STATUS_TYPE_CODE_INVESTIGATION;
      default:
        throw new ResultIntegrityException("Invalid Incident Status");
    }
  }

  private IncidentType getIncidentType() {
    Optional<IncidentType> optionalIncidentType =
        incidentTypeRepository.findByIncidentTypeCode(
            RIConstants.PrcOutcomeConstant.INCIDENT_TYPE_CODE_PLAGIARISM);
    return optionalIncidentType.orElse(null);
  }

  private CheckOutcomeStatus setCheckOutComeStatus(PlagiarismOutcomeV1 plagiarismOutcomeV1) {
    CheckOutcomeStatus checkOutcomeStatus = null;
    String checkOutcomeStatusValue =
        mapPlagiarismOutcomeToCheckOutcome(
            plagiarismOutcomeV1.getPlagiarismOutcomeDetails().getOutcome().getValue());
    Optional<CheckOutcomeStatus> optionalCheckOutcomeStatus =
        checkOutcomeStatusRepository.findByCheckOutcomeStatusCode(checkOutcomeStatusValue);
    if (optionalCheckOutcomeStatus.isPresent()) {
      checkOutcomeStatus = optionalCheckOutcomeStatus.get();
    }
    return checkOutcomeStatus;
  }

  protected String mapPlagiarismOutcomeToCheckOutcome(String plagiarismOutcome) {
    switch (plagiarismOutcome) {
      case PLAGIARISM_OUTCOME_CLEARED:
      case PLAGIARISM_OUTCOME_INDETERMINANT:
        return CHECK_OUTCOME_STATUS_CODE_PASSED;
      case PLAGIARISM_OUTCOME_PLAGIARISED:
        return CHECK_OUTCOME_STATUS_CODE_FAILED;
      case PLAGIARISM_OUTCOME_UNDER_INVESTIGATION:
        return CHECK_OUTCOME_STATUS_CODE_PENDING;
      default:
        throw new ResultIntegrityException("Invalid Outcome");
    }
  }

  private CheckOutcomeType getCheckOutComeType() {
    CheckOutcomeType checkOutcomeType = null;

    Optional<CheckOutcomeType> optionalCheckOutcomeStatus =
        checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.PLAGIARISM_CHECK_OUTCOME_TYPE_CODE);
    if (optionalCheckOutcomeStatus.isPresent()) {
      checkOutcomeType = optionalCheckOutcomeStatus.get();
    }
    return checkOutcomeType;
  }

  private void buildHeaderForIntegrityCheckInit(CheckOutcome checkOutcome) {
    CMDSHeaderContext headerContext = new CMDSHeaderContext();
    headerContext.setCorrelationId(ThreadLocalHeaderContext.getContext().getCorrelationId());
    headerContext.setEventDateTime(LocalDateTime.now(ZoneOffset.UTC));
    headerContext.setTransactionId(ThreadLocalHeaderContext.getContext().getTransactionId());
    headerContext.setPartnerCode(ThreadLocalHeaderContext.getContext().getPartnerCode());
    headerContext.setEventName(RIConstants.EventType.INTEGRITY_CHECK_INITIATED);

    headerContext.setEventContext(
        Collections.singletonMap(
            "checkOutcomeUuid", String.valueOf(Objects.nonNull(checkOutcome) && Objects.nonNull(checkOutcome.getCheckOutcomeUuid())
                ? checkOutcome.getCheckOutcomeUuid() : "")));
    log.debug(
            "Plagiarism integrity check intiated header set : {}", headerContext);
    ThreadLocalHeaderContext.clearContext();
    ThreadLocalHeaderContext.setContext(headerContext);
  }

  private IntegrityCheckInitiatedV1 eventBuilder(CheckOutcome checkOutcome) {
    CheckOutcomeV1 checkOutcomeV1 = new CheckOutcomeV1();
    IntegrityCheckInitiatedV1 integrityCheckInitiatedV1=new IntegrityCheckInitiatedV1();
    checkOutcomeV1.setCheckOutcomeStatusUuid(
          checkOutcome.getCheckOutcomeStatus().getCheckOutcomeStatusUuid());
    checkOutcomeV1.setCheckOutcomeTypeUuid(
           checkOutcome.getCheckOutcomeType().getCheckOutcomeTypeUuid());

    integrityCheckInitiatedV1.bookingUuid((checkOutcome.getBookingUuid()));
    integrityCheckInitiatedV1.checkOutcome(checkOutcomeV1);
    integrityCheckInitiatedV1.setBookingVersion(checkOutcome.getBookingVersion());

    return integrityCheckInitiatedV1;
  }

  private void publishIntegrityCheckInitiatedEvent(CheckOutcome checkOutcome) {
    IntegrityCheckInitiatedV1 integrityCheckInitiatedV1 = eventBuilder(checkOutcome);

    buildHeaderForIntegrityCheckInit(checkOutcome);

    publishEvent(integrityCheckInitiatedV1);
  }

  private void publishIntegrityIncidentDetailsRaisedEvent(CheckOutcome checkOutcome, Booking optionalBooking) {

    Incident incident =
        checkOutcome.getIncidentsByCheckOutcomeUuid().stream()
            .filter(
                incident1 ->
                    INCIDENT_TYPE_CODE_PLAGIARISM.equals(
                        incident1.getIncidentTypeByIncidentTypeUuid().getIncidentTypeCode()))
            .collect(Collectors.toList())
            .get(0);

    buildHeaderForIntegrityIncidentDetailsRaised(incident);

    ResultIntegrityIncidentDetailsWrapperV1 resultIntegrityIncidentDetailsWrapperV1 =
        riCommonUtil.populateIntegrityDetailsRaisedEvent(incident,optionalBooking);

    publishEvent(resultIntegrityIncidentDetailsWrapperV1);
  }

  private void buildHeaderForIntegrityIncidentDetailsRaised(Incident incident) {
    CMDSHeaderContext headerContext = new CMDSHeaderContext();
    headerContext.setCorrelationId(ThreadLocalHeaderContext.getContext().getCorrelationId());
    headerContext.setEventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime());
    headerContext.setTransactionId(ThreadLocalHeaderContext.getContext().getTransactionId());
    headerContext.setPartnerCode(ThreadLocalHeaderContext.getContext().getPartnerCode());
    headerContext.setEventName(RIConstants.EventType.RESULT_INTEGRITY_INCIDENT_DETAILS_RAISED);

    headerContext.setEventContext(
              Collections.singletonMap("incidentUuid", incident.getIncidentUuid().toString()));
    ThreadLocalHeaderContext.clearContext();
    ThreadLocalHeaderContext.setContext(headerContext);
    log.debug(
            "Plagiarism incident details raised header set : {}", headerContext);
  }


}
