package com.ielts.cmds.ri.application.service;

import com.ielts.cmds.common.config.IBaseAuditService;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.domain.service.ViewIdPhotosDomainService;
import com.ielts.cmds.serialization.application.service.IApplicationServiceV2;
import com.ielts.cmds.serialization.utils.ServiceIdentifier;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.ielts.cmds.ri.utils.RIConstants.UiConstants.OPERATION_TYPE_GET;
import static com.ielts.cmds.ri.utils.RIConstants.UiConstants.VIEW_ID_PHOTOS_RESOURCE;

@Slf4j
@Service
@ServiceIdentifier(OPERATION_TYPE_GET+(VIEW_ID_PHOTOS_RESOURCE))
public class ViewIdPhotosService implements IApplicationServiceV2<Object>, IBaseAuditService {

  @Autowired
  ViewIdPhotosDomainService viewIdPhotosDomainService;

  @SneakyThrows
  @Override
  public void process(Object emptyPayload) {
    log.debug(
        "ViewIncidentService process started for request with transactionId:{}",
        ThreadLocalHeaderContext.getContext().getTransactionId());
    try {
        viewIdPhotosDomainService.on();
    } catch (Exception e) {
      log.error("Exception: {}", e.getMessage());

      viewIdPhotosDomainService.
          publishViewIdPhotosEventToOutBoundTopic(null,null);
    }
  }

  @Override
  public String getPermission() {
    return null;
  }

  @Override
  public String getScreen() {
    return null;
  }

  @Override
  public String getAction() {
    return ViewIdPhotosService.class.getSimpleName();
  }
}
