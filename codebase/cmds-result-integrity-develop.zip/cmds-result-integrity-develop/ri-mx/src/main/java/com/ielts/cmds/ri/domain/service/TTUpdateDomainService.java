package com.ielts.cmds.ri.domain.service;


import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.evt119.CheckOutcomeV1;
import com.ielts.cmds.api.evt119.IntegrityCheckInitiatedV1;
import com.ielts.cmds.api.evt_019.BookingDetailsV1;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeType;
import com.ielts.cmds.ri.infrastructure.entity.Incident;
import com.ielts.cmds.ri.infrastructure.entity.IncidentComment;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentCommentRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentRepository;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;
import com.ielts.cmds.serialization.domain.EnableOutboundEventV2;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
@EnableOutboundEventV2
public class TTUpdateDomainService extends AbstractCMDSDomainService<IntegrityCheckInitiatedV1>{


  private final CheckOutcomeTypeRepository checkOutcomeTypeRepository;

  private CheckOutcomeRepository checkOutcomeRepository;

  private IncidentRepository incidentRepository;

  private IncidentCommentRepository incidentCommentRepository;

  @Autowired
  public TTUpdateDomainService(CheckOutcomeTypeRepository checkOutcomeTypeRepository, CheckOutcomeRepository checkOutcomeRepository,
                        IncidentRepository incidentRepository, IncidentCommentRepository incidentCommentRepository,
                        ApplicationEventPublisher publisher, ObjectMapper objectMapper,
                        @Value("${integrityCheckInitiated.v2}") String isV2Enabled, CMDSThreadLocalContextService cmdsThreadLocalContextService) {
    super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
    this.checkOutcomeTypeRepository= checkOutcomeTypeRepository;
    this.checkOutcomeRepository=checkOutcomeRepository;
    this.incidentRepository=incidentRepository;
    this.incidentCommentRepository=incidentCommentRepository;
  }


  public void resetExistingCheckOutcomes(UUID existingUniqueTestTakeUuid, BookingDetailsV1 bookingDetails) {
   Optional<CheckOutcome> optionalPrcCheckOutcome = checkOutcomeRepository
        .findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(bookingDetails.getBookingUuid()
            , getCheckOutComeType(RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_TYPE_CODE).getCheckOutcomeTypeUuid());
    CheckOutcome prcCheckOutcome;
    boolean publishIntegrityInitiatedFlag=false;
    prcCheckOutcome = optionalPrcCheckOutcome.isPresent() ? optionalPrcCheckOutcome.get() : null ;
    if (Objects.equals(existingUniqueTestTakeUuid, bookingDetails.getTestTaker().getUniqueTestTakerUuid())) {
      if (optionalPrcCheckOutcome.isPresent()) {
        prcCheckOutcome.setBookingVersion(bookingDetails.getBookingVersion());
        checkOutcomeRepository.save(prcCheckOutcome);
        publishIntegrityInitiatedFlag=true;
        //publishIntegrityCheckInitiatedEvent

      }
    } else {
      if (optionalPrcCheckOutcome.isPresent()) {
        log.info("For bookingUuid: {}, Uttid has been changed from {} to {}  !!",bookingDetails.getBookingUuid(),
                existingUniqueTestTakeUuid,bookingDetails.getTestTaker().getUniqueTestTakerUuid());
        prcCheckOutcome = optionalPrcCheckOutcome.get();
        List<Incident> prcIncidentList = incidentRepository
            .findByCheckOutcomeByCheckOutcomeUuidAndBookingUuid(prcCheckOutcome, bookingDetails.getBookingUuid());
        prcIncidentList.forEach(incident -> incidentRepository.delete(incident));
        checkOutcomeRepository.delete(prcCheckOutcome);
      }
    }

    Optional<CheckOutcome> optionalProbBanCheckOutcome = checkOutcomeRepository
        .findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(bookingDetails.getBookingUuid()
            , getCheckOutComeType(RIConstants.PrcOutcomeConstant.PROBABLE_BAN_CHECK_OUTCOME_TYPE_CODE).getCheckOutcomeTypeUuid());
    if (optionalProbBanCheckOutcome.isPresent()) {
      CheckOutcome probBanCheckOutcome = optionalProbBanCheckOutcome.get();
      List<Incident> probBanIncidentList = incidentRepository
          .findByCheckOutcomeByCheckOutcomeUuidAndBookingUuid(probBanCheckOutcome, bookingDetails.getBookingUuid());

      probBanIncidentList.forEach(incident -> {
        List<IncidentComment> incidentCommentList = incidentCommentRepository
            .findByIncidentUuid(incident.getIncidentUuid());
        if (!incidentCommentList.isEmpty()) {
          incidentCommentList.forEach(incidentComment -> incidentCommentRepository
              .delete(incidentComment));
        }
        incidentRepository.delete(incident);
      });
      checkOutcomeRepository.delete(probBanCheckOutcome);
    }

    List<CheckOutcome> checkOutcomeList = checkOutcomeRepository
        .findByBookingUuid(bookingDetails.getBookingUuid());
    //Here need to exclude prc checkoutCome and publishIntegrityCheckInitiatedEvent for all checkOutcomes in loop
    checkOutcomeList.forEach(checkOutcome ->
            checkOutcome.setBookingVersion(bookingDetails.getBookingVersion()));
  checkOutcomeRepository.saveAll(checkOutcomeList);


    if(Objects.nonNull(prcCheckOutcome) && publishIntegrityInitiatedFlag) {
      log.debug("PRC Outcome IntegrityCheckInitiated event header {}, with eventbody {}", ThreadLocalHeaderContext.getContext(), prcCheckOutcome);
      publishIntegrityCheckInitiatedEvent(prcCheckOutcome);
    }
  }
  public CheckOutcomeType getCheckOutComeType(String checkoutcometypeCode) {
    CheckOutcomeType checkOutcomeType = null;
    Optional<CheckOutcomeType> optionalCheckOutcomeType =
        checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(checkoutcometypeCode);
    if (optionalCheckOutcomeType.isPresent()) {
      checkOutcomeType = optionalCheckOutcomeType.get();
    }
    return checkOutcomeType;
  }

  private void publishIntegrityCheckInitiatedEvent(CheckOutcome checkOutcome) {
    IntegrityCheckInitiatedV1 integrityCheckInitiatedV1 = eventBuilder(checkOutcome);

    buildHeaderForIntegrityCheckInit(checkOutcome);

    publishEvent(integrityCheckInitiatedV1);
  }

  private IntegrityCheckInitiatedV1 eventBuilder(CheckOutcome checkOutcome) {
    CheckOutcomeV1 checkOutcomeV1 = new CheckOutcomeV1();
    IntegrityCheckInitiatedV1 integrityCheckInitiatedV1=new IntegrityCheckInitiatedV1();
    checkOutcomeV1.setCheckOutcomeStatusUuid(checkOutcome.getCheckOutcomeStatus().getCheckOutcomeStatusUuid());
    checkOutcomeV1.setCheckOutcomeTypeUuid(checkOutcome.getCheckOutcomeType().getCheckOutcomeTypeUuid());

    integrityCheckInitiatedV1.bookingUuid((checkOutcome.getBookingUuid()));
    integrityCheckInitiatedV1.checkOutcome(checkOutcomeV1);
    integrityCheckInitiatedV1.setBookingVersion(checkOutcome.getBookingVersion());

    return integrityCheckInitiatedV1;
  }

  private void buildHeaderForIntegrityCheckInit(CheckOutcome checkOutcome) {
    CMDSHeaderContext headerContext = new CMDSHeaderContext();
    headerContext.setCorrelationId(ThreadLocalHeaderContext.getContext().getCorrelationId());
    headerContext.setEventDateTime(LocalDateTime.now(ZoneOffset.UTC));
    headerContext.setTransactionId(ThreadLocalHeaderContext.getContext().getTransactionId());
    headerContext.setPartnerCode(ThreadLocalHeaderContext.getContext().getPartnerCode());
    headerContext.setEventName(RIConstants.EventType.INTEGRITY_CHECK_INITIATED);

    headerContext.setEventContext(
            Collections.singletonMap(
                    "checkOutcomeUuid", String.valueOf(Objects.nonNull(checkOutcome) && Objects.nonNull(checkOutcome.getCheckOutcomeUuid())
                            ? checkOutcome.getCheckOutcomeUuid() : "")));

    ThreadLocalHeaderContext.clearContext();
    ThreadLocalHeaderContext.setContext(headerContext);
  }
}

