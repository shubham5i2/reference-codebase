package com.ielts.cmds.ri.application.service;

import com.ielts.cmds.api.evt113.ProbableBanCheckOutcomeV1;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.domain.service.ProbableBanOutcomeReceivedDomainService;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.service.IApplicationServiceV2;
import com.ielts.cmds.serialization.utils.ServiceIdentifier;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@ServiceIdentifier(RIConstants.EventType.PROBABLE_BAN_OUTCOME_RECEIVED_EVENT)
public class ProbableBanOutcomeReceivedService implements IApplicationServiceV2<ProbableBanCheckOutcomeV1> {

  @Autowired
  ProbableBanOutcomeReceivedDomainService probableBanOutcomeReceivedDomainService;

  @Override
  public void process(ProbableBanCheckOutcomeV1 probableBanCheckOutcomeV1) {
	  try {
			 
		  probableBanOutcomeReceivedDomainService.on(probableBanCheckOutcomeV1);

	  }catch (Exception e) {
          log.error("Exception Caught in Service: {}", e);
          throw new ResultIntegrityException(e.getMessage());
      }
  }
}
