package com.ielts.cmds.ri.application.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.domain.service.TTPhotoDomainService;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.service.IApplicationServiceV2;
import com.ielts.cmds.serialization.utils.ServiceIdentifier;
import com.ielts.cmds.testtaker.common.events.model.PhotoPublishedV1;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@ServiceIdentifier(RIConstants.EventType.PHOTO_PUBLISHED_EVENT)
public class TTPhotoService implements IApplicationServiceV2<PhotoPublishedV1> {

    @Autowired
    TTPhotoDomainService ttPhotoDomainService;

    @Override
    public void process(PhotoPublishedV1 photoPublishedV1) {
    	try {
    		ttPhotoDomainService.on(photoPublishedV1);
    	}catch (Exception e) {
            log.error("Exception Caught in Service: {}", e);
            throw new ResultIntegrityException(e.getMessage());
    	}
    }
}