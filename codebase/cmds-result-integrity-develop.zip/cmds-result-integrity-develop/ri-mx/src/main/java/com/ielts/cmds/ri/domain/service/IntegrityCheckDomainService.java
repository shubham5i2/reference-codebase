package com.ielts.cmds.ri.domain.service;

import static com.ielts.cmds.ri.utils.RIConstants.CheckOutcomeTypeConstants.CHK_OUT_TYPE_PRO_BAN_INC_CHK_CODE;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.evt044.CheckOutcomeV1;
import com.ielts.cmds.api.evt044.IncidentDetailsV1;
import com.ielts.cmds.api.evt119.IntegrityCheckInitiatedV1;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeType;
import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatus;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusTypeRepository;
import com.ielts.cmds.ri.utils.IntegrityCheckHelper;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class IntegrityCheckDomainService extends AbstractCMDSDomainService<IncidentDetailsV1> {

  private final CheckOutcomeRepository checkOutcomeRepository;

  private final CheckOutcomeTypeRepository checkOutcomeTypeRepository;

  private final BookingRepository bookingRepository;

  private final RICommonUtil riCommonUtil;
  
  private final IntegrityCheckHelper integrityCheckHelper;

  @Autowired
  public IntegrityCheckDomainService(ApplicationEventPublisher publisher,
                                     ObjectMapper objectMapper,
                                     @Value("${resultIntegrityCheckChanged.v2}") String isV2Enabled,
                                     CMDSThreadLocalContextService cmdsThreadLocalContextService,
                                     CheckOutcomeRepository checkOutcomeRepository,
                                     OutcomeStatusRepository outcomeStatusRepository,
                                     OutcomeStatusTypeRepository outcomeStatusTypeRepository,
                                     CheckOutcomeTypeRepository checkOutcomeTypeRepository,
                                     BookingRepository bookingRepository,
                                     RICommonUtil riCommonUtil,
                                     IntegrityCheckHelper integrityCheckHelper) {
    super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
    this.checkOutcomeRepository = checkOutcomeRepository;
    this.checkOutcomeTypeRepository = checkOutcomeTypeRepository;
    this.bookingRepository = bookingRepository;
    this.riCommonUtil = riCommonUtil;
    this.integrityCheckHelper = integrityCheckHelper;
  }

  @SneakyThrows
  @Transactional
  public void on(final IntegrityCheckInitiatedV1 integrityCheckInitiatedV1) {

    log.debug("IntegrityCheckDomainService calculating OutcomeStatus ");

    if (Objects.nonNull(integrityCheckInitiatedV1.getCheckOutcome()) && Objects.nonNull(integrityCheckInitiatedV1.getCheckOutcome().getCheckOutcomeTypeUuid())) {
      //IMOD-49165 publish event only for eligible outcomes
      Optional<CheckOutcomeType> receivedCheckOutComeTypeOp =
              checkOutcomeTypeRepository.findByCheckOutcomeTypeUuid(integrityCheckInitiatedV1.getCheckOutcome().getCheckOutcomeTypeUuid());
      Optional<Booking> optionalBooking = bookingRepository.findById(integrityCheckInitiatedV1.getBookingUuid());
      if (receivedCheckOutComeTypeOp.isPresent()) {
        List<String> eligibleCheckOutcomeCodes = getEligibleCheckOutcomeReceived(optionalBooking.orElse(null), receivedCheckOutComeTypeOp.get());
        if (CollectionUtils.isNotEmpty(eligibleCheckOutcomeCodes) &&
                eligibleCheckOutcomeCodes.contains(receivedCheckOutComeTypeOp.get().getCheckOutcomeTypeCode())) {
          List<CheckOutcome> checkOutcomeList = checkOutcomeRepository
                  .findByBookingUuid(integrityCheckInitiatedV1.getBookingUuid());

          OutcomeStatus outcomeStatus = integrityCheckHelper
                  .setOverallOutcomeStatus(integrityCheckInitiatedV1, checkOutcomeList, eligibleCheckOutcomeCodes,optionalBooking.orElse(null));
          log.debug("overalloutcomestatus for booking uuid {} is {}", integrityCheckInitiatedV1.getBookingUuid(), optionalBooking.isPresent() ? outcomeStatus.getOutcomeStatusType()
                 : null);

          IncidentDetailsV1 incidentDetailsV1 = mapOutcomeStatusToIncident(outcomeStatus, integrityCheckInitiatedV1);
          log.debug("Integrity Check changed event header {}, with eventbody {}", ThreadLocalHeaderContext.getContext(), incidentDetailsV1);
          publishResultIntegrityCheckChangedEvent(incidentDetailsV1);
        } else {
          log.info("{} is not eligible check outcome for booking {}", integrityCheckInitiatedV1.getCheckOutcome().getCheckOutcomeTypeUuid(),
                  integrityCheckInitiatedV1.getBookingUuid());
        }
      } else {
        log.info("No CheckOutcomeType available in warehouse with the given CheckOutcomeTypeUuid {}", integrityCheckInitiatedV1.getCheckOutcome().getCheckOutcomeTypeUuid());
      }
    } else {
      log.info("CheckOutcomeTypeUuid is not received in the payload. IntegrityCheckInitiated not published for booking uuid {}", integrityCheckInitiatedV1.getBookingUuid());
    }
  }


  private List<String> getEligibleCheckOutcomeReceived(Booking optionalBooking,CheckOutcomeType receivedCheckOutcome) {
    if (Objects.nonNull(optionalBooking)) {
      return riCommonUtil.generateCheckOutcomeList(optionalBooking);
    }
    else {
      if (CHK_OUT_TYPE_PRO_BAN_INC_CHK_CODE.equals(receivedCheckOutcome.getCheckOutcomeTypeCode())) {
        return Collections.singletonList(CHK_OUT_TYPE_PRO_BAN_INC_CHK_CODE);
      }
      return Collections.emptyList();
    }
  }

  IncidentDetailsV1 mapOutcomeStatusToIncident(final OutcomeStatus outcomeStatus,
      final IntegrityCheckInitiatedV1 integrityCheckInitiatedV1) {
    IncidentDetailsV1 incidentDetailsV1 = new IncidentDetailsV1();
    incidentDetailsV1.setBookingUuid(UUID.fromString(String.valueOf(integrityCheckInitiatedV1.getBookingUuid())));
    incidentDetailsV1.setOutcomeStatusTypeUuid((outcomeStatus.getOutcomeStatusType().getOutcomeStatusTypeUuid()));
    incidentDetailsV1.setCheckOutcome(mapEvt044CheckOutcomeToModelCheckOutcome(integrityCheckInitiatedV1.getCheckOutcome()));
    incidentDetailsV1.setBookingVersion(outcomeStatus.getBookingVersion());

    return incidentDetailsV1;
  }

  void publishResultIntegrityCheckChangedEvent(IncidentDetailsV1 incidentDetailsV1) {
    CMDSHeaderContext headerContext = new CMDSHeaderContext();
    headerContext.setCorrelationId(ThreadLocalHeaderContext.getContext().getCorrelationId());
    headerContext.setEventDateTime(ThreadLocalHeaderContext.getContext().getEventDateTime());
    headerContext.setTransactionId(ThreadLocalHeaderContext.getContext().getTransactionId());
    headerContext.setPartnerCode(ThreadLocalHeaderContext.getContext().getPartnerCode());
    headerContext.setEventName(RIConstants.EventType.RESULT_INTEGRITY_CHECK_CHANGED_EVENT);

    ThreadLocalHeaderContext.clearContext();
    ThreadLocalHeaderContext.setContext(headerContext);
    publishEvent(incidentDetailsV1);
  }

  CheckOutcomeV1 mapEvt044CheckOutcomeToModelCheckOutcome(com.ielts.cmds.api.evt119.CheckOutcomeV1 modelCheckOutcomeV1) {
    CheckOutcomeV1 checkOutcomeV1 = new CheckOutcomeV1();
    checkOutcomeV1.setCheckOutcomeStatusUuid(modelCheckOutcomeV1.getCheckOutcomeStatusUuid());
    checkOutcomeV1.setCheckOutcomeTypeUuid(modelCheckOutcomeV1.getCheckOutcomeTypeUuid());
    return  checkOutcomeV1;
  }

}
