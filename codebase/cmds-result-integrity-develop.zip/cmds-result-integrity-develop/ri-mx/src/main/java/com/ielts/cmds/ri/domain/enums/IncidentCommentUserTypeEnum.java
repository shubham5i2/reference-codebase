package com.ielts.cmds.ri.domain.enums;

public enum IncidentCommentUserTypeEnum {
  REPORTER("REPORTER"),
  REVIEWER("REVIEWER");

  private String value;

  IncidentCommentUserTypeEnum(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }

  @Override
  public String toString() {
    return String.valueOf(value);
  }

}
