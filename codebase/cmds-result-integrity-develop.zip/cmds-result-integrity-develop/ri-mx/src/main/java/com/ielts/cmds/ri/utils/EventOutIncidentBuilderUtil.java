package com.ielts.cmds.ri.utils;

import com.ielts.cmds.ri.common.model.out.CheckOutcomeV1;
import com.ielts.cmds.ri.common.model.out.IncidentDetailsV1;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatus;
import org.springframework.stereotype.Component;

@Component
public class EventOutIncidentBuilderUtil {
    public IncidentDetailsV1 buildIncidentDetailsV1(CheckOutcome checkOutcome, OutcomeStatus outcomeStatus) {
        IncidentDetailsV1 incidentDetailsV1 = new IncidentDetailsV1();
        incidentDetailsV1.setBookingUuid(checkOutcome.getBookingUuid());
        incidentDetailsV1.setOutcomeStatusTypeUuid(outcomeStatus.getOutcomeStatusType()
                .getOutcomeStatusTypeUuid());
        incidentDetailsV1.setCheckOutcome(buildCheckOutcomeV1(checkOutcome));
        return incidentDetailsV1;
    }

    private CheckOutcomeV1 buildCheckOutcomeV1(CheckOutcome checkOutcome) {
        CheckOutcomeV1 checkOutcomeV1 = new CheckOutcomeV1();
        checkOutcomeV1.setCheckOutcomeStatusUuid(checkOutcome.getCheckOutcomeStatus().getCheckOutcomeStatusUuid());
        checkOutcomeV1.setCheckOutcomeTypeUuid(checkOutcome.getCheckOutcomeType().getCheckOutcomeTypeUuid());
        return checkOutcomeV1;
    }
}
