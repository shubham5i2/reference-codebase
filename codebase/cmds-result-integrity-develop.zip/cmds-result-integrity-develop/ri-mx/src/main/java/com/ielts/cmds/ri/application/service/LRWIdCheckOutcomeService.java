package com.ielts.cmds.ri.application.service;

import com.ielts.cmds.ids.domain.model.CandidateIdCheckOutcomeNodeV1;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.domain.service.LRWIdCheckOutcomeDomainService;
import com.ielts.cmds.serialization.application.service.IApplicationServiceV2;
import com.ielts.cmds.serialization.utils.ServiceIdentifier;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.CANDIDATE_ID_CHECK_OUTCOME;

@Slf4j
@Service
@ServiceIdentifier(CANDIDATE_ID_CHECK_OUTCOME )
public class LRWIdCheckOutcomeService implements IApplicationServiceV2<CandidateIdCheckOutcomeNodeV1> {

    @Autowired
    LRWIdCheckOutcomeDomainService lrwIdCheckOutcomeDomainService;
    
    @SneakyThrows
    @Override
    public void process(CandidateIdCheckOutcomeNodeV1 candidateIdCheckOutcomeNodeV1) {
    	try {
    		lrwIdCheckOutcomeDomainService.on(candidateIdCheckOutcomeNodeV1);
    }catch (Exception e) {
        log.error("Exception Caught in Service: {}", e);
        throw new ResultIntegrityException(e.getMessage());
    }
   }
}
