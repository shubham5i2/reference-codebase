package com.ielts.cmds.ri.domain.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.evt_019.TestTakerDetailsV1;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.application.exception.ResultIntegrityValidationException;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeType;
import com.ielts.cmds.ri.infrastructure.entity.Product;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.ProductRepository;
import com.ielts.cmds.ri.utils.BookingDetailsEvent;
import com.ielts.cmds.ri.utils.CheckOutcomeStatusEvent;
import com.ielts.cmds.ri.utils.RICommonUtil;

@ExtendWith(MockitoExtension.class)
class BookingUpdateIdCheckOutcomeDomainServiceTest {

    @InjectMocks
    @Spy
    BookingUpdateIdCheckOutcomeDomainService bookingUpdateIdCheckOutcomeDomainService;
    @Mock
    CheckOutcomeRepository checkOutcomeRepository;
    @Mock
    CheckOutcomeTypeRepository checkOutcomeTypeRepository;
    @Mock
    CheckOutcomeStatusRepository checkOutcomeStatusRepository;
    @Mock
    OutcomeStatusRepository outcomeStatusRepository;
    @Mock
    ProductRepository productRepository;
    @Mock
    private ObjectMapper mapper;
    @Mock
    RICommonUtil riCommonUtil;


    @BeforeEach
    void init(){
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

        CMDSHeaderContext ctx = new CMDSHeaderContext();
        ctx.setCorrelationId(UUID.randomUUID());
        ctx.setTransactionId(UUID.randomUUID());
        ctx.setPartnerCode("BC");
        ctx.setConnectionId(UUID.randomUUID().toString());
        ctx.setEventDateTime(LocalDateTime.now());
        ThreadLocalHeaderContext.setContext(ctx);
    }
    @Test
    void updateIdCheckOutcomeForIocProduct_when_IdVerificationStatus_is_verified() {
        Product product = new Product();
        product.setProductCharacteristics("{\"characteristics\": [\"IOC\"],\"RoAutoAccepted\": [\"TRUE\"]}");
        TestTakerDetailsV1 testTakerDetails = BookingDetailsEvent.getTestTakerDetailsEvt019();
        testTakerDetails.setIdentityVerificationStatus(TestTakerDetailsV1.IdentityVerificationStatusEnum.VERIFIED);
        
        when(productRepository.findById(any(UUID.class)))
                .thenReturn(Optional.of(product));
        when(checkOutcomeRepository.save(any())).thenReturn(CheckOutcomeStatusEvent.getPassedCheckoutCome());
        
        when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(any()))
                .thenReturn(Optional.of(new CheckOutcomeType()));
        when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(any(), any()))
                .thenReturn(Optional.of(CheckOutcomeStatusEvent.getPassedCheckoutCome()));
        when(checkOutcomeStatusRepository.findByCheckOutcomeStatusCode(any()))
                .thenReturn(Optional.of(CheckOutcomeStatusEvent.getCheckOutcomeStatusAsPassed()));
        doNothing().when(bookingUpdateIdCheckOutcomeDomainService).publishEvent(any());
		final Executable executable = () ->
                bookingUpdateIdCheckOutcomeDomainService.updateIdCheckOutcome(BookingDetailsEvent.setBookingForTest(), testTakerDetails);
        Assertions.assertDoesNotThrow(executable);
    }

    @Test
    void updateIdCheckOutcomeForIocProduct_when_IdVerificationStatus_is_unverified() {
        Product product = new Product();
        product.setProductCharacteristics("{\"characteristics\": [\"IOC\"],\"RoAutoAccepted\": [\"TRUE\"]}");
        TestTakerDetailsV1 testTakerDetails = BookingDetailsEvent.getTestTakerDetailsEvt019();
        testTakerDetails.setIdentityVerificationStatus(TestTakerDetailsV1.IdentityVerificationStatusEnum.UNVERIFIED);
        when(productRepository.findById(any(UUID.class)))
                .thenReturn(Optional.of(product));
        when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(any()))
                .thenReturn(Optional.of(new CheckOutcomeType()));
        when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(any(), any()))
                .thenReturn(Optional.empty());
        final Executable executable = () ->
                bookingUpdateIdCheckOutcomeDomainService.updateIdCheckOutcome(BookingDetailsEvent.setBookingForTest(), testTakerDetails);
        Assertions.assertDoesNotThrow(executable);

    }

    @Test
    void updateIdCheckOutcomeForIocProduct_when_ExistingCheckOutcomeIsNotPresent() {
        Product product = new Product();
        product.setProductCharacteristics("{\"characteristics\": [\"IOC\"],\"RoAutoAccepted\": [\"TRUE\"]}");
        TestTakerDetailsV1 testTakerDetails = BookingDetailsEvent.getTestTakerDetailsEvt019();
        when(productRepository.findById(any(UUID.class)))
                .thenReturn(Optional.of(product));
        when(checkOutcomeRepository.save(any())).thenReturn(CheckOutcomeStatusEvent.getPassedCheckoutCome());
        
        when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(any()))
                .thenReturn(Optional.of(new CheckOutcomeType()));
        when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(any(), any()))
                .thenReturn(Optional.empty());
        when(checkOutcomeStatusRepository.findByCheckOutcomeStatusCode(any()))
                .thenReturn(Optional.of(CheckOutcomeStatusEvent.getCheckOutcomeStatusAsPassed()));
        doNothing().when(bookingUpdateIdCheckOutcomeDomainService).publishEvent(any());
		
        final Executable executable = () ->
                bookingUpdateIdCheckOutcomeDomainService.updateIdCheckOutcome(BookingDetailsEvent.setBookingForTest(), testTakerDetails);
        Assertions.assertDoesNotThrow(executable);
    }
    
    @Test
    void updateIdCheckOutcome_when_ExistingCheckOutcomeIsPresent() {
    	Product product = new Product();
    	product.setProductCharacteristics("{\"characteristics\": [\"IOC\"],\"RoAutoAccepted\": [\"TRUE\"]}");
        TestTakerDetailsV1 testTakerDetails = BookingDetailsEvent.getTestTakerDetailsEvt019();         
       Booking booking = new Booking();
	Executable excecutable = () -> bookingUpdateIdCheckOutcomeDomainService.updateIdCheckOutcome(booking , testTakerDetails);
       assertDoesNotThrow(excecutable);
       assertNotNull(excecutable);    
       assertEquals(Booking.class,booking.getClass());
    }
    @Test
    void updateIdCheckOutcomeForOtherProduct_should_return_null() {
        Product product = new Product();
        product.setProductCharacteristics("{\"characteristics\": [\"IOL\"],\"RoAutoAccepted\": [\"TRUE\"]}");
        TestTakerDetailsV1 testTakerDetails = BookingDetailsEvent.getTestTakerDetailsEvt019();
        
        when(productRepository.findById(any(UUID.class)))
        .thenReturn(Optional.of(product));        
        final Executable executable = () -> bookingUpdateIdCheckOutcomeDomainService.updateIdCheckOutcome(BookingDetailsEvent.setBookingForTest(), testTakerDetails);
        Assertions.assertDoesNotThrow(executable);

    }
   
    @Test
    void updateIdCheckOutcomeForProduct_shouldNot_return_null() {
        Product product = new Product();
        product.setProductCharacteristics("{\"characteristics\": [\"IOL\"],\"RoAutoAccepted\": [\"TRUE\"]}");
        TestTakerDetailsV1 testTakerDetails = BookingDetailsEvent.getTestTakerDetailsEvt019();
                      
        final Executable executable = () -> bookingUpdateIdCheckOutcomeDomainService.getCheckOutComeStatus(testTakerDetails);
        Assertions.assertThrows(ResultIntegrityValidationException.class,executable);

    }
    
    @Test
    void testSetEventDateTime_ValidDateTime() {
       
        CMDSHeaderContext cmdsHeaderContext = new CMDSHeaderContext();        
        LocalDateTime validDateTime = LocalDateTime.now();
        
        cmdsHeaderContext.setEventDateTime(validDateTime);
        
        assertEquals(validDateTime, cmdsHeaderContext.getEventDateTime());
    }
    @Test
    void getCheckOutComeStatus_ValidTestTakerDetails_ReturnsCheckOutcomeStatus() {
        TestTakerDetailsV1 testTakerDetails = BookingDetailsEvent.getTestTakerDetailsEvt019();
        when(checkOutcomeStatusRepository.findByCheckOutcomeStatusCode(any()))
                .thenReturn(Optional.of(CheckOutcomeStatusEvent.getCheckOutcomeStatusAsPassed()));

        CheckOutcomeStatus result = bookingUpdateIdCheckOutcomeDomainService.getCheckOutComeStatus(testTakerDetails);

        assertNotNull(result);
        assertEquals(CheckOutcomeStatusEvent.getCheckOutcomeStatusAsPassed(), result);
    }
    @Test
    void getCheckOutComeType_TypeExists_ReturnsCheckOutcomeType() {
        when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(any()))
                .thenReturn(Optional.of(new CheckOutcomeType()));

        CheckOutcomeType result = bookingUpdateIdCheckOutcomeDomainService.getCheckOutComeType();

        assertNotNull(result);
    }

    @Test
    void getCheckOutComeType_TypeDoesNotExist_ReturnsNull() {
        when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(any()))
                .thenReturn(Optional.empty());

        assertThrows(ResultIntegrityValidationException.class, 
        		()->bookingUpdateIdCheckOutcomeDomainService.getCheckOutComeType());

    }
    
}
    

