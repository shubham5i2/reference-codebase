package com.ielts.cmds.ri.domain.service;

import com.ielts.cmds.ri.common.model.out.IncidentDetailsV1;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeType;
import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatusType;
import java.util.UUID;

import com.ielts.cmds.ri.utils.EventOutIncidentBuilderUtil;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class EventOutIncidentBuilderUtilTest {

  @InjectMocks
  EventOutIncidentBuilderUtil eventOutIncidentBuilderUtil;

  CheckOutcome checkOutcome;

  OutcomeStatus outcomeStatus;

  @BeforeEach
  void setUp () {
    CheckOutcomeStatus checkOutcomeStatus = new CheckOutcomeStatus();
    checkOutcomeStatus.setCheckOutcomeStatusUuid(UUID.randomUUID());

    CheckOutcomeType checkOutcomeType = new CheckOutcomeType();
    checkOutcomeType.setCheckOutcomeTypeUuid(UUID.randomUUID());

    OutcomeStatusType outcomeStatusType = new OutcomeStatusType();
    outcomeStatusType.setOutcomeStatusTypeUuid(UUID.randomUUID());


    checkOutcome = CheckOutcome.builder()
        .bookingUuid(UUID.randomUUID())
        .checkOutcomeStatus(checkOutcomeStatus)
        .checkOutcomeType(checkOutcomeType)
        .build();

    outcomeStatus = OutcomeStatus.builder().outcomeStatusUuid(UUID.randomUUID())
        .outcomeStatusType(outcomeStatusType)
        .build();
  }

  @Test
  void testBuildIncidentDetailsV1_shouldReturn_incidentDetails() {
    IncidentDetailsV1 incidentDetailsV1 =
        eventOutIncidentBuilderUtil.buildIncidentDetailsV1(checkOutcome, outcomeStatus);

    Assertions.assertNotNull(incidentDetailsV1);
  }

}
