package com.ielts.cmds.ri.application.service;

import com.ielts.cmds.ri.domain.service.ViewIdPhotosDomainService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.*;


/**
 * The type View id photos service test.
 */
@ExtendWith(MockitoExtension.class)
class ViewIdPhotosServiceTest {

  @InjectMocks
  ViewIdPhotosService viewIdPhotosService;

  @Mock
  ViewIdPhotosDomainService viewIdPhotosDomainService;

  /**
   * When valid payload then verify domain call with no exception.
   *
   * @throws Exception the exception
   */
  @Test
  void whenValidPayload_thenVerifyDomainCallWithNoException()
      throws Exception {

    viewIdPhotosService.process(new Object());
    verify(viewIdPhotosDomainService, times(1)).on();
  }

  @Test
  void whenValidPayload_thenThrowException()
          throws Exception {
    doThrow(RuntimeException.class).when(viewIdPhotosDomainService).on();

    viewIdPhotosService.process(new Object());
    verify(viewIdPhotosDomainService, times(1)).publishViewIdPhotosEventToOutBoundTopic(null, null);
  }

  @Test
  void testBaseAudits() {
    Assertions.assertNull(viewIdPhotosService.getPermission());
    Assertions.assertNull(viewIdPhotosService.getScreen());
    Assertions.assertNotNull(viewIdPhotosService.getAction());
  }


}


