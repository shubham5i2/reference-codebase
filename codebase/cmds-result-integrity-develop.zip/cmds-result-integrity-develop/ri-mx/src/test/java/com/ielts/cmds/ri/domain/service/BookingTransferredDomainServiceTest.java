package com.ielts.cmds.ri.domain.service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.evt_019.BookingDetailsV1;
import com.ielts.cmds.infrastructure.event.context.CMDSAuditContext;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusTypeRepository;
import com.ielts.cmds.ri.utils.BookingDetailsEvent;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.ri.utils.RIUtil;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BookingTransferredDomainServiceTest {

	@InjectMocks
	@Spy
	private BookingTransferredDomainService bookingTransferredDomainService;
	@Mock
	private OutcomeStatusRepository outcomeStatusRepository;
	@Mock
	private BookingRepository bookingRepository;
	@Mock
	private OutcomeStatusTypeRepository outcomeStatusTypeRepository;
	@Spy
	private ObjectMapper mapper;
	private CMDSHeaderContext cmdsHeaderContext;


	@BeforeEach
	void init() {
		mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
		mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
		mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		cmdsHeaderContext = RIUtil.createCMDSHeaderContextByEventName(RIConstants.EventType.BOOKING_CANCELLED_EVENT);
		ThreadLocalHeaderContext.setContext(cmdsHeaderContext);
		ThreadLocalAuditContext.setContext(new CMDSAuditContext());
	}
	@Test
	void bookingTransferreedCheck() {
		doNothing().when(bookingTransferredDomainService).process(ArgumentMatchers.any(BookingDetailsV1.class));
		Executable executable = () -> bookingTransferredDomainService.on(BookingDetailsEvent.getBookingDetailsBody());
		Assertions.assertDoesNotThrow(executable);
		}


}
