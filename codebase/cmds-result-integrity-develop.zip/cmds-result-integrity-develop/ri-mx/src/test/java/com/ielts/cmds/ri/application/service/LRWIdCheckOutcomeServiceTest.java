package com.ielts.cmds.ri.application.service;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ielts.cmds.ids.domain.model.CandidateIdCheckOutcomeNodeV1;
import com.ielts.cmds.ri.domain.service.LRWIdCheckOutcomeDomainService;

@ExtendWith(SpringExtension.class)
class LRWIdCheckOutcomeServiceTest {

	@InjectMocks
    LRWIdCheckOutcomeService checkOutcomeService;

	@Mock
	private LRWIdCheckOutcomeDomainService lrwIdCheckOutcomeDomainService;
	
	@Test
	void testProcess() {
		CandidateIdCheckOutcomeNodeV1 candidateCheckOutcome = new CandidateIdCheckOutcomeNodeV1();
		checkOutcomeService.process(candidateCheckOutcome);
		verify(lrwIdCheckOutcomeDomainService, times(1)).on(candidateCheckOutcome);
	}

}
