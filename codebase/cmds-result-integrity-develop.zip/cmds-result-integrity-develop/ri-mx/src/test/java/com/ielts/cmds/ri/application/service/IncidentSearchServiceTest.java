package com.ielts.cmds.ri.application.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.ri.common.model.out.SearchIncidentRequestV1;
import com.ielts.cmds.ri.domain.service.IncidentSearchDomainService;
import com.ielts.cmds.ri.utils.IncidentSearchTestSetup;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class IncidentSearchServiceTest {

  @InjectMocks IncidentSearchService incidentSearchService;

  @Mock IncidentSearchDomainService incidentSearchDomainService;

  SearchIncidentRequestV1 requestV1;

  @BeforeEach
  void setup(){
    requestV1 = IncidentSearchTestSetup.createSearchIncidentRequestObject();
  }

  @Test
  void whenIncidentEventIsReceived_ThenDelegateRequestToDomainService()
      throws RbacValidationException, JsonProcessingException {

    doNothing().when(incidentSearchDomainService).on(requestV1);
    final Executable executable = () -> incidentSearchService.process(requestV1);

    assertDoesNotThrow(executable);
  }

  @Test
  void whenIncidentEventIsReceived_ThenThrowException()
          throws RbacValidationException, JsonProcessingException {

    doThrow(RuntimeException.class).when(incidentSearchDomainService).on(requestV1);
    final Executable executable = () -> incidentSearchService.process(requestV1);

    assertDoesNotThrow(executable);
    verify(incidentSearchDomainService).publishEventToOutBoundTopic(null, null);
  }

}
