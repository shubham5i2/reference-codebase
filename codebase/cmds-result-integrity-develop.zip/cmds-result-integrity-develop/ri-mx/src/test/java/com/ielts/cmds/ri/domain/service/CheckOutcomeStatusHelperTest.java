package com.ielts.cmds.ri.domain.service;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.UUID;

import com.ielts.cmds.ri.infrastructure.entity.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.ri.domain.enums.IncidentSeverityEnum;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentStatusTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.ProductIncidentMappingRepository;
import com.ielts.cmds.ri.utils.BookingDetailsEvent;
import com.ielts.cmds.ri.utils.CheckOutcomeStatusEvent;
import com.ielts.cmds.ri.utils.CheckOutcomeStatusHelper;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.ri.utils.TestDayIncidentRaisedEvent;

@ExtendWith(MockitoExtension.class)
class CheckOutcomeStatusHelperTest {

  @InjectMocks @Spy
  private CheckOutcomeStatusHelper checkOutcomeStatusHelper;

  @Mock CheckOutcomeRepository checkOutcomeRepository;
  @Mock CheckOutcomeTypeRepository checkOutcomeTypeRepository;
  @Mock CheckOutcomeStatusRepository checkOutcomeStatusRepository;
  @Mock IncidentStatusTypeRepository incidentStatusTypeRepository;
  @Mock ProductIncidentMappingRepository productIncidentMappingRepository;
  @Mock 
  private RICommonUtil riCommonUtil;
  @Mock
  private IncidentRepository incidentRepository;
  @Mock
  private OutcomeStatusRepository outcomeStatusRepository;
  @Mock
  private BookingRepository bookingRepository;
  @Mock private Optional<Booking> optionalBooking;

  @BeforeEach
  void setUp() {
    optionalBooking=Optional.of(BookingDetailsEvent.setBookingForTest());
  }

  @Test
  void setCheckOutcomeStatusOnValidFlow_when_EligibleForIntegrityCheck_is_false() {
	  
    Incident incident = TestDayIncidentRaisedEvent.getIncident();
    incident.getIncidentCategoryByIncidentCategoryUuid().setEligibleForIntegrityCheck(false);
    
    checkOutcomeStatusHelper.setCheckOutcomeStatus(incident, "LRW_INC_CHK",optionalBooking.orElse(null));
    assertNull(incident.getCheckOutcomeByCheckOutcomeUuid());
  }

  @Test
  void setCheckOutcomeStatusWhenIncidentStatusIsFlagged_for_confirmed_malpractice() {

    Incident incident = TestDayIncidentRaisedEvent.getIncident();
    incident.setIncidentSeverity(IncidentSeverityEnum.CONFIRMED_MALPRACTICE);
    incident.setIncidentUuid(UUID.fromString("c2b58881-9ca3-49f0-8a19-a45d05a0dbed"));
    assertNotNull(UUID.randomUUID());
    Mockito.when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode("LRW_INC_CHK"))
        .thenReturn(Optional.of(CheckOutcomeStatusEvent.getCheckOutcomeType()));
    Mockito.when(checkOutcomeStatusRepository.findByCheckOutcomeStatusCode("CHK_OUT_REVIEW"))
        .thenReturn(Optional.of(CheckOutcomeStatusEvent.getCheckOutcomeStatusAsReview()));
    when(incidentRepository.findByCheckOutcomeByCheckOutcomeUuidAndBookingUuid(any(),any())).thenReturn(
        TestDayIncidentRaisedEvent.getIncidentList());

    CheckOutcome checkoutCome = CheckOutcomeStatusEvent.getCheckoutCome();
    Mockito.when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
                            incident.getBookingUuid(), CheckOutcomeStatusEvent.getCheckOutcomeType().getCheckOutcomeTypeUuid()))
            .thenReturn(Optional.of(checkoutCome));
    checkOutcomeStatusHelper.setCheckOutcomeStatus(incident, "LRW_INC_CHK",optionalBooking.orElse(null));
  }

  @Test
  void setCheckOutcomeStatusOn_for_ExistingCheckoutCome() {

    Incident incident = TestDayIncidentRaisedEvent.getMalpracticeIncident();
    incident.setIncidentUuid(UUID.fromString("c2b58881-9ca3-49f0-8a19-a45d05a0dbed"));
    CheckOutcome checkoutCome = CheckOutcomeStatusEvent.getCheckoutCome();
    Mockito.when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode("LRW_INC_CHK"))
        .thenReturn(Optional.of(CheckOutcomeStatusEvent.getCheckOutcomeType()));
    Mockito.when(
            checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
                incident.getBookingUuid(), CheckOutcomeStatusEvent.getCheckOutcomeType().getCheckOutcomeTypeUuid()))
        .thenReturn(Optional.of(checkoutCome));
    when(incidentRepository.findByCheckOutcomeByCheckOutcomeUuidAndBookingUuid(any(),any())).thenReturn(
        TestDayIncidentRaisedEvent.getIncidentList());

    final Executable executable = () ->
        checkOutcomeStatusHelper.setCheckOutcomeStatus(incident, "LRW_INC_CHK",optionalBooking.orElse(null));
    assertDoesNotThrow(executable);
  }

  @Test
  void setCheckOutcomeStatusWhenIncidentStatusIsConfirmed_for_confirmed_malpractice() {

    Incident incident = TestDayIncidentRaisedEvent.getIncident();
    incident.setIncidentStatusTypeByIncidentStatusTypeUuid(TestDayIncidentRaisedEvent
        .getConfirmedIncidentStatusType());
    incident.setIncidentSeverity(IncidentSeverityEnum.CONFIRMED_MALPRACTICE);
    incident.setIncidentUuid(UUID.fromString("c2b58881-9ca3-49f0-8a19-a45d05a0dbed"));
    Mockito.when(checkOutcomeStatusRepository.findByCheckOutcomeStatusCode("CHK_OUT_FAILED"))
        .thenReturn(Optional.of(CheckOutcomeStatusEvent.getCheckOutcomeStatusAsFailed()));
    Mockito.when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode("LRW_INC_CHK"))
        .thenReturn(Optional.of(CheckOutcomeStatusEvent.getCheckOutcomeType()));
   CheckOutcome checkoutCome = CheckOutcomeStatusEvent.getCheckoutCome();
    Mockito.when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
                    incident.getBookingUuid(), CheckOutcomeStatusEvent.getCheckOutcomeType().getCheckOutcomeTypeUuid()))
            .thenReturn(Optional.of(checkoutCome));

    final Executable executable = () ->
    checkOutcomeStatusHelper.setCheckOutcomeStatus(incident, "LRW_INC_CHK",optionalBooking.orElse(null));
    assertDoesNotThrow(executable);
  }

  @Test
  void setCheckOutcomeStatusWhenIncidentStatusIsDismissed_for_confirmed_malpractice() {

    Incident incident = TestDayIncidentRaisedEvent.getIncident();
    incident.setIncidentStatusTypeByIncidentStatusTypeUuid(TestDayIncidentRaisedEvent
        .getDismissedIncidentStatusType());
    incident.setIncidentSeverity(IncidentSeverityEnum.CONFIRMED_MALPRACTICE);
    incident.setIncidentUuid(UUID.fromString("c2b58881-9ca3-49f0-8a19-a45d05a0dbed"));
    Mockito.when(checkOutcomeStatusRepository.findByCheckOutcomeStatusCode("CHK_OUT_PASSED"))
        .thenReturn(Optional.of(CheckOutcomeStatusEvent.getCheckOutcomeStatusAsPassed()));
    Mockito.when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode("LRW_INC_CHK"))
        .thenReturn(Optional.of(CheckOutcomeStatusEvent.getCheckOutcomeType()));
    Mockito.when(checkOutcomeRepository.save(ArgumentMatchers.any()))
        .thenReturn(CheckOutcomeStatusEvent.getCheckoutCome());
    when(incidentRepository.findByCheckOutcomeByCheckOutcomeUuidAndBookingUuid(any(),any())).thenReturn(
        TestDayIncidentRaisedEvent.getIncidentList());
     CheckOutcome checkoutCome = CheckOutcomeStatusEvent.getCheckoutCome();
    Mockito.when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
                    incident.getBookingUuid(), CheckOutcomeStatusEvent.getCheckOutcomeType().getCheckOutcomeTypeUuid()))
            .thenReturn(Optional.of(checkoutCome));

    final Executable executable = () ->
    checkOutcomeStatusHelper.setCheckOutcomeStatus(incident, "LRW_INC_CHK",optionalBooking.orElse(null));
    assertDoesNotThrow(executable);
  }

  @Test
  void setCheckOutcomeStatusWhenAnyOneIncidentStatusIsFlagged_for_confirmed_malpractice() {

    Incident incident = TestDayIncidentRaisedEvent.getIncident();
    incident.setIncidentSeverity(IncidentSeverityEnum.CONFIRMED_MALPRACTICE);
    incident.setIncidentUuid(UUID.fromString("c2b58881-9ca3-49f0-8a19-a45d05a0dbed"));
    incident.setIncidentStatusTypeByIncidentStatusTypeUuid(TestDayIncidentRaisedEvent
        .getDismissedIncidentStatusType());
    Mockito.when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode("LRW_INC_CHK"))
        .thenReturn(Optional.of(CheckOutcomeStatusEvent.getCheckOutcomeType()));
    Mockito.when(checkOutcomeStatusRepository.findByCheckOutcomeStatusCode("CHK_OUT_REVIEW"))
        .thenReturn(Optional.of(CheckOutcomeStatusEvent.getCheckOutcomeStatusAsReview()));
    when(incidentRepository.findByCheckOutcomeByCheckOutcomeUuidAndBookingUuid(any(),any())).thenReturn(
        TestDayIncidentRaisedEvent.getFlaggedIncidentList());
    CheckOutcome checkoutCome = CheckOutcomeStatusEvent.getCheckoutCome();
    Mockito.when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
                    incident.getBookingUuid(), CheckOutcomeStatusEvent.getCheckOutcomeType().getCheckOutcomeTypeUuid()))
            .thenReturn(Optional.of(checkoutCome));

    final Executable executable = () ->
    checkOutcomeStatusHelper.setCheckOutcomeStatus(incident, "LRW_INC_CHK",optionalBooking.orElse(null));
    assertDoesNotThrow(executable);
  }
  
  @Test
  void test_whenNewBookingVersionIsHigher() {

    Incident incident = TestDayIncidentRaisedEvent.getMalpracticeIncidentforNewVersion();
    incident.setIncidentUuid(UUID.fromString("552cfb1e-3d39-42c4-8366-5b675e51ff3a"));
    CheckOutcome checkoutCome = CheckOutcomeStatusEvent.getCheckoutComeWithNewVersion();
    Mockito.when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode("LRW_INC_CHK"))
            .thenReturn(Optional.of(CheckOutcomeStatusEvent.getCheckOutcomeType()));
    Mockito.when(
                    checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
                            incident.getBookingUuid(), CheckOutcomeStatusEvent.getCheckOutcomeType().getCheckOutcomeTypeUuid()))
            .thenReturn(Optional.of(checkoutCome));
    when(incidentRepository.findByCheckOutcomeByCheckOutcomeUuidAndBookingUuid(any(),any())).thenReturn(
            TestDayIncidentRaisedEvent.getIncidentList());

    final Executable executable = () ->
            checkOutcomeStatusHelper.setCheckOutcomeStatus(incident, "LRW_INC_CHK",optionalBooking.orElse(null));
    assertDoesNotThrow(executable);
  }
  @Test
  void setCheckOutcomeStatusOnValidFlow_when_EligibleForIntegrityCheck_is_true() {
      Incident incident = TestDayIncidentRaisedEvent.getIncident();
      incident.getIncidentCategoryByIncidentCategoryUuid().setEligibleForIntegrityCheck(false);

      checkOutcomeStatusHelper.setCheckOutcomeStatus(incident, "LRW_INC_CHK", optionalBooking.orElse(null));
      assertNull(incident.getCheckOutcomeByCheckOutcomeUuid());
  }
  @Test
  void getIncidentStatusType_WhenEligibleForIntegrityCheck() {
      Incident incidentMock = mock(Incident.class);
      IncidentCategory incidentCategoryMock = mock(IncidentCategory.class);
      Booking bookingMock = mock(Booking.class);
      ProductIncidentMapping productIncidentMappingMock = mock(ProductIncidentMapping.class);
      IncidentStatusType incidentStatusTypeMock = mock(IncidentStatusType.class);
      when(incidentCategoryMock.getEligibleForIntegrityCheck()).thenReturn(true);
      
      when(riCommonUtil.getBooking(incidentMock)).thenReturn(bookingMock);

      UUID productUuid = UUID.randomUUID();
      UUID incidentCategoryUuid = UUID.randomUUID();
      IncidentSeverityEnum incidentSeverityMock = mock(IncidentSeverityEnum.class);
      when(incidentMock.getIncidentSeverity()).thenReturn(incidentSeverityMock);
      when(bookingMock.getProductUuid()).thenReturn(productUuid);
      when(incidentCategoryMock.getIncidentCategoryUuid()).thenReturn(incidentCategoryUuid);
      when(productIncidentMappingRepository.findByProductUuidAndIncidentCategoryUuidAndIncidentSeverity(
              productUuid, incidentCategoryUuid, incidentSeverityMock)).thenReturn(productIncidentMappingMock);

      when(productIncidentMappingMock.getIncidentStatusTypeCode()).thenReturn("STATUS_CODE");
      when(incidentStatusTypeRepository.findByIncidentStatusTypeCode("STATUS_CODE"))
              .thenReturn(Optional.of(incidentStatusTypeMock));

      IncidentStatusType result = checkOutcomeStatusHelper.getIncidentStatusType(incidentMock, incidentCategoryMock);

      // Assert
      assertNotNull(result);
      assertEquals(incidentStatusTypeMock, result);
  }
  @Test
  void getIncidentStatusType_WhenNotEligibleForIntegrityCheck() {
      Incident incidentMock = mock(Incident.class);
      IncidentCategory incidentCategoryMock = mock(IncidentCategory.class);
      Booking bookingMock = mock(Booking.class);
      ProductIncidentMapping productIncidentMappingMock = mock(ProductIncidentMapping.class);
      IncidentStatusType incidentStatusTypeMock = mock(IncidentStatusType.class);

      when(incidentCategoryMock.getEligibleForIntegrityCheck()).thenReturn(false);
      when(riCommonUtil.getBooking(incidentMock)).thenReturn(bookingMock);

      UUID productUuid = UUID.randomUUID();
      UUID incidentCategoryUuid = UUID.randomUUID();
      when(bookingMock.getProductUuid()).thenReturn(productUuid);
      when(incidentCategoryMock.getIncidentCategoryUuid()).thenReturn(incidentCategoryUuid);

      when(productIncidentMappingRepository.findByProductUuidAndIncidentCategoryUuid(
              productUuid, incidentCategoryUuid)).thenReturn(productIncidentMappingMock);

      when(productIncidentMappingMock.getIncidentStatusTypeCode()).thenReturn("STATUS_CODE");
      when(incidentStatusTypeRepository.findByIncidentStatusTypeCode("STATUS_CODE"))
              .thenReturn(Optional.of(incidentStatusTypeMock));
      IncidentStatusType result = checkOutcomeStatusHelper.getIncidentStatusType(incidentMock, incidentCategoryMock);

      // Assert
      assertNotNull(result);
      assertEquals(incidentStatusTypeMock, result);
  }
}