package com.ielts.cmds.ri.domain.service;

import static com.ielts.cmds.ri.utils.IntegrityCheckEvent.getOutcomeStatus;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.api.evt044.IncidentDetailsV1;
import com.ielts.cmds.api.evt119.IntegrityCheckInitiatedV1;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeType;
import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatus;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusTypeRepository;
import com.ielts.cmds.ri.utils.BookingDetailsEvent;
import com.ielts.cmds.ri.utils.IntegrityCheckEvent;
import com.ielts.cmds.ri.utils.IntegrityCheckHelper;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.ri.utils.RIConstants;

@ExtendWith(MockitoExtension.class)
class IntegrityCheckDomainServiceTest {

  @InjectMocks
  @Spy
  IntegrityCheckDomainService integrityCheckDomainService;

  @Mock
  CheckOutcomeRepository checkOutcomeRepository;

  @Mock
  OutcomeStatusRepository outcomeStatusRepository;
  @Mock
  CheckOutcomeTypeRepository checkOutcomeTypeRepository;
  @Mock
  BookingRepository bookingRepository;
  @Mock
  RICommonUtil riCommonUtil;
  
  @Mock
  IntegrityCheckHelper integrityCheckHelper;

  @Mock
  OutcomeStatusTypeRepository outcomeStatusTypeRepository;

  @BeforeEach
  void setup() {
    CMDSHeaderContext header = IntegrityCheckEvent.getHeader();
    ThreadLocalHeaderContext.setContext(header);
  }

  @ParameterizedTest
  @MethodSource("argumentProviderForIntegrityCheckInitiated")
  void testOnCommand_should_publish_event_nonpbc(final IntegrityCheckInitiatedV1 integrityCheckInitiatedV1,
                                              final IncidentDetailsV1 incidentDetailsV1, final OutcomeStatus outcomeStatus) {
    when(bookingRepository.findById(any())).thenReturn(Optional.of(Booking.builder().build()));
    List<CheckOutcome> checkOutcomeList = new ArrayList<>();
    CheckOutcome checkOutcome = new CheckOutcome();
    checkOutcome.setCheckOutcomeType(CheckOutcomeType.builder().checkOutcomeTypeCode(RIConstants.PrcOutcomeConstant.SPK_INC_CHK).build());
    checkOutcome.setCheckOutcomeStatus(CheckOutcomeStatus.builder().checkOutcomeStatusCode("PASSED").build());
    
    checkOutcomeList.add(checkOutcome);
    when(checkOutcomeRepository.findByBookingUuid(any())).thenReturn(checkOutcomeList);
    Mockito.when(riCommonUtil.generateCheckOutcomeList(any())).thenReturn(Arrays.asList(RIConstants.PrcOutcomeConstant.SPK_INC_CHK,RIConstants.PrcOutcomeConstant.LRW_INC_CHK));
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeUuid(any())).thenReturn(Optional.of(CheckOutcomeType.builder().checkOutcomeTypeCode(RIConstants.PrcOutcomeConstant.SPK_INC_CHK).build()));

    doReturn(outcomeStatus).when(integrityCheckHelper).setOverallOutcomeStatus(any(), any(), any(), any());
    
    doNothing().when(integrityCheckDomainService).publishEvent(any());
    Assertions.assertDoesNotThrow(()-> integrityCheckDomainService.on(integrityCheckInitiatedV1));

  }

  @ParameterizedTest
  @MethodSource("argumentProviderForIntegrityCheckInitiated")
  void testOn_no_booking_nonpbc_ineligible_checkoutcome_should_not_publish_event(final IntegrityCheckInitiatedV1 integrityCheckInitiatedV1) {
    when(bookingRepository.findById(any())).thenReturn(Optional.empty());
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeUuid(any())).thenReturn(Optional.of(CheckOutcomeType.builder().checkOutcomeTypeCode("PLG_INC_CHK").build()));
    Assertions.assertDoesNotThrow(()-> integrityCheckDomainService.on(integrityCheckInitiatedV1));

  }

  @ParameterizedTest
  @MethodSource("argumentProviderForIntegrityCheckInitiated")
  void testOnCommand_with_ineligible_check_outcome_should_not_publish_event(
          IntegrityCheckInitiatedV1 integrityCheckInitiatedV1) {
    when(bookingRepository.findById(any())).thenReturn(Optional.of(Booking.builder().build()));
    Mockito.when(riCommonUtil.generateCheckOutcomeList(any())).thenReturn(Collections.emptyList());
    Mockito.when(checkOutcomeTypeRepository.findByCheckOutcomeTypeUuid(integrityCheckInitiatedV1.getCheckOutcome().getCheckOutcomeTypeUuid()))
            .thenReturn(Optional.of(IntegrityCheckEvent.getLRW_ID_CheckOutcomeTypeCode()));

    Assertions.assertDoesNotThrow(()-> integrityCheckDomainService.on(integrityCheckInitiatedV1));
    Mockito.verify(integrityCheckDomainService, Mockito.times(0)).publishResultIntegrityCheckChangedEvent(any());

  }

  @ParameterizedTest
  @MethodSource("argumentProviderForIntegrityCheckInitiated")
  void testOnCommand_with_non_existing_check_outcome_should_not_publish_event(
          final IntegrityCheckInitiatedV1 integrityCheckInitiatedV1) {

    Mockito.when(checkOutcomeTypeRepository.findByCheckOutcomeTypeUuid(integrityCheckInitiatedV1.getCheckOutcome().getCheckOutcomeTypeUuid()))
            .thenReturn(Optional.empty());

    Assertions.assertDoesNotThrow(()-> integrityCheckDomainService.on(integrityCheckInitiatedV1));
    Mockito.verify(integrityCheckDomainService, Mockito.times(0)).publishResultIntegrityCheckChangedEvent(any());

  }

  @ParameterizedTest
  @MethodSource("argumentProviderForIntegrityCheckInitiated")
  void testPublish_event(final IntegrityCheckInitiatedV1 integrityCheckInitiatedV1,
      final IncidentDetailsV1 incidentDetailsV1, final OutcomeStatus outcomeStatus) {
    doNothing().when(integrityCheckDomainService).publishEvent(any());
    integrityCheckDomainService
        .publishResultIntegrityCheckChangedEvent(incidentDetailsV1);
    assertNotNull(incidentDetailsV1);
    verify(integrityCheckDomainService).publishEvent(any());
  }

  @ParameterizedTest
  @MethodSource("argumentProviderForIntegrityCheckInitiated")
  void testInvalidCheckOutcomeTypeUuid(final IntegrityCheckInitiatedV1 integrityCheckInitiatedV1) {
    integrityCheckInitiatedV1.setCheckOutcome(null);
    Assertions.assertDoesNotThrow(()-> integrityCheckDomainService.on(integrityCheckInitiatedV1));
  }

  @ParameterizedTest
  @MethodSource("argumentProviderForIntegrityCheckInitiated")
  void testOnCommand_should_publish_event_nonpbc_when_No_Booking_Present(final IntegrityCheckInitiatedV1 integrityCheckInitiatedV1,
                                                 final IncidentDetailsV1 incidentDetailsV1, final OutcomeStatus outcomeStatus) {
    when(bookingRepository.findById(any())).thenReturn(Optional.of(Booking.builder().build()));
    List<CheckOutcome> checkOutcomeList = new ArrayList<>();
    CheckOutcome checkOutcome = new CheckOutcome();
    checkOutcome.setCheckOutcomeType(CheckOutcomeType.builder().checkOutcomeTypeCode(RIConstants.PrcOutcomeConstant.SPK_INC_CHK).build());
    checkOutcome.setCheckOutcomeStatus(CheckOutcomeStatus.builder().checkOutcomeStatusCode("PASSED").build());
    checkOutcomeList.add(checkOutcome);
    when(bookingRepository.findById(integrityCheckInitiatedV1.getBookingUuid())).thenReturn(Optional.of(BookingDetailsEvent.setBookingForTest()));
    when(checkOutcomeRepository.findByBookingUuid(any())).thenReturn(checkOutcomeList);
    Mockito.when(riCommonUtil.generateCheckOutcomeList(any())).thenReturn(Arrays.asList(RIConstants.PrcOutcomeConstant.SPK_INC_CHK,RIConstants.PrcOutcomeConstant.LRW_INC_CHK));
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeUuid(any())).thenReturn(Optional.of(CheckOutcomeType.builder().checkOutcomeTypeCode(RIConstants.PrcOutcomeConstant.SPK_INC_CHK).build()));
    doReturn(outcomeStatus).when(integrityCheckHelper).setOverallOutcomeStatus(any(), any(), any(), any());
    doNothing().when(integrityCheckDomainService).publishEvent(any());
    Assertions.assertDoesNotThrow(()-> integrityCheckDomainService.on(integrityCheckInitiatedV1));

  }

  @ParameterizedTest
  @MethodSource("argumentProviderForIntegrityCheckInitiated")
  void testOnCommand_should_publish_event_IfBookingFlagIsfalse(final IntegrityCheckInitiatedV1 integrityCheckInitiatedV1,
                                                 final IncidentDetailsV1 incidentDetailsV1, final OutcomeStatus outcomeStatus) {

    when(bookingRepository.findById(any())).thenReturn(Optional.of(Booking.builder().build()));
    List<CheckOutcome> checkOutcomeList = new ArrayList<>();
    CheckOutcome checkOutcome = new CheckOutcome();
    checkOutcome.setCheckOutcomeType(CheckOutcomeType.builder().checkOutcomeTypeCode(RIConstants.PrcOutcomeConstant.SPK_INC_CHK).build());
    checkOutcome.setCheckOutcomeStatus(CheckOutcomeStatus.builder().checkOutcomeStatusCode("PASSED").build());
    
    when(bookingRepository.findById(integrityCheckInitiatedV1.getBookingUuid())).thenReturn(Optional.empty());
    when(checkOutcomeRepository.findByBookingUuid(any())).thenReturn(checkOutcomeList);
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeUuid(any())).thenReturn(Optional.of(CheckOutcomeType.builder().checkOutcomeTypeCode(RIConstants.CheckOutcomeTypeConstants.CHK_OUT_TYPE_PRO_BAN_INC_CHK_CODE).build()));
    doReturn(outcomeStatus).when(integrityCheckHelper).setOverallOutcomeStatus(any(), any(), any(), any());
    doNothing().when(integrityCheckDomainService).publishEvent(any());
    Assertions.assertDoesNotThrow(()-> integrityCheckDomainService.on(integrityCheckInitiatedV1));

  }

    private static Stream<Arguments> argumentProviderForIntegrityCheckInitiated() {
    IntegrityCheckInitiatedV1 integrityCheckInitiatedV1 = IntegrityCheckEvent.getIntegrityCheckInitiatedV1();
    IncidentDetailsV1 incidentDetailsV1 = IntegrityCheckEvent.buildIncidentDetailsV1();
    OutcomeStatus outcomeStatus = getOutcomeStatus();

    return Stream.of(
        Arguments.of(
            integrityCheckInitiatedV1,
            incidentDetailsV1,
            outcomeStatus
        ));
  }
}
