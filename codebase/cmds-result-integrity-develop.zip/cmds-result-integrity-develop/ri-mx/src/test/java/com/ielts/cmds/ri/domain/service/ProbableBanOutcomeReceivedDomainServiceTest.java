package com.ielts.cmds.ri.domain.service;

import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_PASSED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_REVIEW;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.INCIDENT_STATUS_TYPE_CODE_FLAGGED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.INCIDENT_STATUS_TYPE_CODE_PASSED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.INCIDENT_STATUS_TYPE_CODE_REFERRED;
import static org.mockito.ArgumentMatchers.any;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import com.ielts.cmds.api.evt113.ProbableBanCheckOutcomeDetailsV1Inner;
import com.ielts.cmds.api.evt113.ProbableBanCheckOutcomeV1;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.Incident;
import com.ielts.cmds.ri.infrastructure.entity.IncidentCategory;
import com.ielts.cmds.ri.infrastructure.entity.IncidentStatusType;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentStatusTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.ProductIncidentMappingRepository;
import com.ielts.cmds.ri.infrastructure.repository.UniqueTestTakerRepository;
import com.ielts.cmds.ri.utils.BookingDetailsEvent;
import com.ielts.cmds.ri.utils.ProbableBanCheckoutcomeHelper;
import com.ielts.cmds.ri.utils.ProbableBanOutcomeReceivedEvent;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.ri.utils.RIConstants;

@ExtendWith(MockitoExtension.class)
class ProbableBanOutcomeReceivedDomainServiceTest {

	@InjectMocks
	@Spy
	ProbableBanOutcomeReceivedDomainService probableBanOutcomeReceivedDomainService;

	@Mock
	private BookingRepository bookingRepository;

	@Mock
	private CheckOutcomeTypeRepository checkOutcomeTypeRepository;

	@Mock
	private CheckOutcomeRepository checkOutcomeRepository;

	@Mock
	private CheckOutcomeStatusRepository checkOutcomeStatusRepository;

	@Mock
	private IncidentTypeRepository incidentTypeRepository;

	@Mock
	private IncidentStatusTypeRepository incidentStatusTypeRepository;

	@Mock
	private UniqueTestTakerRepository uniqueTestTakerRepository;

	@Spy
	private ProbableBanCheckoutcomeHelper probableBanCheckoutcomeHelper;

	@Spy
	@InjectMocks
	RICommonUtil riCommonUtil;

	@Spy
	Booking booking;

	CheckOutcome checkOutcome;
	@Spy
	Incident incident;

	@Mock
	ProductIncidentMappingRepository productIncidentMappingRepository;

	@Mock
	OutcomeStatusRepository outcomeStatusRepository;

	@BeforeEach
	void setUp() {
		booking = Booking.builder().bookingUuid(UUID.fromString("2a6c84d5-3cd3-4c29-bff5-426f55c9db80"))
				.compositeCandidateNumber("123456").bookingVersion(BigDecimal.valueOf(0)).build();

		checkOutcome = ProbableBanOutcomeReceivedEvent.generateCheckOutcomeEntity();
		CMDSHeaderContext ctx = new CMDSHeaderContext();
		ctx.setCorrelationId(UUID.randomUUID());
		ctx.setTransactionId(UUID.randomUUID());
		ctx.setPartnerCode("CA");
		ctx.setEventDateTime(LocalDateTime.now());
		ThreadLocalHeaderContext.setContext(ctx);
		ReflectionTestUtils.setField(probableBanCheckoutcomeHelper, "bookingRepository", bookingRepository);
		ReflectionTestUtils.setField(probableBanCheckoutcomeHelper, "checkOutcomeRepository", checkOutcomeRepository);
		ReflectionTestUtils.setField(probableBanCheckoutcomeHelper, "checkOutcomeStatusRepository",
				checkOutcomeStatusRepository);
		ReflectionTestUtils.setField(probableBanCheckoutcomeHelper, "checkOutcomeTypeRepository",
				checkOutcomeTypeRepository);
		ReflectionTestUtils.setField(probableBanCheckoutcomeHelper, "uniqueTestTakerRepository",
				uniqueTestTakerRepository);
		ReflectionTestUtils.setField(probableBanCheckoutcomeHelper, "outcomeStatusRepository", outcomeStatusRepository);
		ReflectionTestUtils.setField(probableBanCheckoutcomeHelper, "incidentTypeRepository", incidentTypeRepository);
		ReflectionTestUtils.setField(probableBanCheckoutcomeHelper, "incidentStatusTypeRepository",
				incidentStatusTypeRepository);
		ReflectionTestUtils.setField(probableBanCheckoutcomeHelper, "productIncidentMappingRepository",
				productIncidentMappingRepository);
	}

	@Test
	void testMapProbableBanOutcomeToIncidentStatusType() {
		String incidentStatusType;
		Incident incident = ProbableBanOutcomeReceivedEvent.getProbableBanIncident();
		Booking booking = new Booking();
		booking.setProductUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
		IncidentCategory incidentCategory = new IncidentCategory();

		incidentCategory.setIncidentCategoryUuid(UUID.fromString("7ce32c94-7bd7-409c-a755-7cb5a2b62195"));
		incident.setIncidentCategoryByIncidentCategoryUuid(incidentCategory);

		IncidentStatusType incidentStatusTypes = new IncidentStatusType();
		incidentStatusTypes.setIncidentStatusTypeCode("PASSED");
		incidentStatusTypes.setIncidentStatusTypeUuid(UUID.randomUUID());
		incident.setIncidentStatusTypeByIncidentStatusTypeUuid(incidentStatusTypes);

		Mockito.when(bookingRepository.findById(incident.getBookingUuid())).thenReturn(Optional.of(booking));
		Mockito.when(productIncidentMappingRepository.findByProductUuidAndIncidentCategoryUuid(
				UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"),
				UUID.fromString("7ce32c94-7bd7-409c-a755-7cb5a2b62195")))
				.thenReturn(ProbableBanOutcomeReceivedEvent.getProductIncidentMapping());
		incidentStatusType = probableBanCheckoutcomeHelper.mapProbableBanOutcomeToIncidentStatusType("PASSED",
				incident);

		Assertions.assertEquals(INCIDENT_STATUS_TYPE_CODE_PASSED, incidentStatusType);

		incidentStatusType = probableBanCheckoutcomeHelper.mapProbableBanOutcomeToIncidentStatusType("FLAGGED",
				incident);

		Assertions.assertEquals(INCIDENT_STATUS_TYPE_CODE_REFERRED, incidentStatusType);

		Assertions.assertThrows(ResultIntegrityException.class,
				() -> probableBanCheckoutcomeHelper.mapProbableBanOutcomeToIncidentStatusType("INVALID", incident));
		Assertions.assertNotNull(productIncidentMappingRepository.findByProductUuidAndIncidentCategoryUuid(
				UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"),
				UUID.fromString("7ce32c94-7bd7-409c-a755-7cb5a2b62195")));
	}

	@Test
	void testMapPlagiarismOutcomeToCheckOutcome() {
		String checkOutcomeStatus;

		checkOutcomeStatus = probableBanCheckoutcomeHelper.mapProbableBanOutcomeToCheckOutcome("PASSED");

		Assertions.assertEquals(CHECK_OUTCOME_STATUS_CODE_PASSED, checkOutcomeStatus);

		checkOutcomeStatus = probableBanCheckoutcomeHelper.mapProbableBanOutcomeToCheckOutcome("FLAGGED");

		Assertions.assertEquals(CHECK_OUTCOME_STATUS_CODE_REVIEW, checkOutcomeStatus);

		Assertions.assertThrows(ResultIntegrityException.class,
				() -> probableBanCheckoutcomeHelper.mapProbableBanOutcomeToCheckOutcome("INVALID"));
	}

	@Test
	void test_shouldCreateNewCheckOutcomeAndIncident_whenNoExistingCheckOutcomeIsPresentForBooking() {
		ProbableBanCheckOutcomeDetailsV1Inner probableBanCheckOutcomeDetailsV1Inner = ProbableBanOutcomeReceivedEvent
				.generateProbableBanCheckOutcomeDetailsV1InnerPassed();
		CheckOutcome savedCheckOutcome = ProbableBanOutcomeReceivedEvent.generateCheckOutcomeEntity();
		savedCheckOutcome.setCheckOutcomeUuid(UUID.fromString("2a6c84d5-3cd3-4c29-bff5-426f55c9db80"));
		CheckOutcome modifiedCheckOutcome = ProbableBanOutcomeReceivedEvent.generateCheckOutcomeEntity();
		modifiedCheckOutcome.setCheckOutcomeUuid(UUID.fromString("6d1c020d-5407-4e14-b9c0-8af26a907d9e"));

		Mockito.when(bookingRepository.findById(UUID.fromString("2a6c84d5-3cd3-4c29-bff5-426f55c9db80")))
				.thenReturn(Optional.empty());

		Mockito.when(checkOutcomeTypeRepository
				.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.PROBABLE_BAN_CHECK_OUTCOME_TYPE_CODE))
				.thenReturn(Optional.of(ProbableBanOutcomeReceivedEvent.generateCheckOutcomeTypeEntity()));
		Mockito.when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
				UUID.fromString("2a6c84d5-3cd3-4c29-bff5-426f55c9db80"),
				ProbableBanOutcomeReceivedEvent.generateCheckOutcomeTypeEntity().getCheckOutcomeTypeUuid()))
				.thenReturn(Optional.empty());
		Mockito.when(checkOutcomeStatusRepository.findByCheckOutcomeStatusCode(CHECK_OUTCOME_STATUS_CODE_PASSED))
				.thenReturn(Optional.of(ProbableBanOutcomeReceivedEvent.generateCheckOutcomeStatusEntity()));
		Mockito.when(incidentTypeRepository
				.findByIncidentTypeCode(RIConstants.PrcOutcomeConstant.INCIDENT_TYPE_CODE_PROBABLE_BAN))
				.thenReturn(Optional.of(ProbableBanOutcomeReceivedEvent.getIncidentTypeProbableBan()));
		Mockito.when(incidentStatusTypeRepository.findByIncidentStatusTypeCode(INCIDENT_STATUS_TYPE_CODE_PASSED))
				.thenReturn(Optional.of(ProbableBanOutcomeReceivedEvent.getPassedIncidentStatusType()));
		Mockito.when(checkOutcomeRepository.save(any())).thenReturn(savedCheckOutcome);
		Mockito.when(bookingRepository.findById(booking.getBookingUuid())).thenReturn(Optional.of(booking));

		CheckOutcome checkOutcomeCreated = probableBanCheckoutcomeHelper
				.updateProbableBanOutcome(probableBanCheckOutcomeDetailsV1Inner, booking);

		Assertions.assertEquals(UUID.fromString("2a6c84d5-3cd3-4c29-bff5-426f55c9db80"),
				checkOutcomeCreated.getCheckOutcomeUuid());
	}

	@Test
	void test_shouldUpdateCheckOutcomeAndIncident_whenBothPresent() {
		ProbableBanCheckOutcomeDetailsV1Inner probableBanCheckOutcomeDetailsV1Inner = ProbableBanOutcomeReceivedEvent
				.generateProbableBanCheckOutcomeDetailsV1InnerPassed();
		booking.setBookingVersion(BigDecimal.valueOf(1));
		CheckOutcome savedCheckOutcome = ProbableBanOutcomeReceivedEvent.generateCheckOutcomeEntityFlaggedForReview();
		savedCheckOutcome.setCheckOutcomeUuid(UUID.fromString("6d1c020d-5407-4e14-b9c0-8af26a907d9e"));

		CheckOutcome modifiedCheckOutcome = ProbableBanOutcomeReceivedEvent.generateCheckOutcomeEntity();
		modifiedCheckOutcome.setCheckOutcomeUuid(UUID.fromString("6d1c020d-5407-4e14-b9c0-8af26a907d9e"));

		Mockito.when(bookingRepository.findById(UUID.fromString("2a6c84d5-3cd3-4c29-bff5-426f55c9db80")))
				.thenReturn(Optional.of(booking));
		Mockito.when(checkOutcomeTypeRepository
				.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.PROBABLE_BAN_CHECK_OUTCOME_TYPE_CODE))
				.thenReturn(Optional.of(ProbableBanOutcomeReceivedEvent.generateCheckOutcomeTypeEntity()));
		Mockito.when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
				UUID.fromString("2a6c84d5-3cd3-4c29-bff5-426f55c9db80"),
				ProbableBanOutcomeReceivedEvent.generateCheckOutcomeTypeEntity().getCheckOutcomeTypeUuid()))
				.thenReturn(Optional.of(savedCheckOutcome));
		Mockito.when(checkOutcomeStatusRepository.findByCheckOutcomeStatusCode(CHECK_OUTCOME_STATUS_CODE_PASSED))
				.thenReturn(Optional.of(ProbableBanOutcomeReceivedEvent.generateCheckOutcomeStatusEntity()));
		Mockito.when(incidentStatusTypeRepository.findByIncidentStatusTypeCode(INCIDENT_STATUS_TYPE_CODE_PASSED))
				.thenReturn(Optional.of(ProbableBanOutcomeReceivedEvent.getPassedIncidentStatusType()));
		Mockito.when(checkOutcomeRepository.save(savedCheckOutcome)).thenReturn(modifiedCheckOutcome);
		Mockito.when(bookingRepository.findById(booking.getBookingUuid())).thenReturn(Optional.of(booking));

		CheckOutcome checkOutcomeCreated = probableBanCheckoutcomeHelper
				.updateProbableBanOutcome(probableBanCheckOutcomeDetailsV1Inner, booking);

		Assertions.assertEquals(UUID.fromString("6d1c020d-5407-4e14-b9c0-8af26a907d9e"),
				checkOutcomeCreated.getCheckOutcomeUuid());
		Assertions.assertEquals("CHK_OUT_PASSED",
				checkOutcomeCreated.getCheckOutcomeStatus().getCheckOutcomeStatusCode());
	}

	@Test
	void testOn_shouldPublishIntegrityCheckInitiatedEvent_onSuccess() {
		ProbableBanCheckOutcomeV1 probableBanCheckOutcomeV1 = ProbableBanOutcomeReceivedEvent
				.generateProbableBanOutcome();
		CheckOutcome savedCheckOutcome = ProbableBanOutcomeReceivedEvent.generateCheckOutcomeEntity();
		savedCheckOutcome.setCheckOutcomeUuid(UUID.fromString("2a6c84d5-3cd3-4c29-bff5-426f55c9db80"));
		ProbableBanCheckOutcomeDetailsV1Inner probableBanCheckOutcomeDetailsV1Inner = ProbableBanOutcomeReceivedEvent
				.generateProbableBanCheckOutcomeDetailsV1InnerPassed();
		Booking optBooking = BookingDetailsEvent.setBookingForTest();
		Mockito.when(checkOutcomeTypeRepository
				.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.PROBABLE_BAN_CHECK_OUTCOME_TYPE_CODE))
				.thenReturn(Optional.of(ProbableBanOutcomeReceivedEvent.generateCheckOutcomeTypeEntity()));
		Mockito.when(checkOutcomeStatusRepository.findByCheckOutcomeStatusCode(CHECK_OUTCOME_STATUS_CODE_PASSED))
				.thenReturn(Optional.of(ProbableBanOutcomeReceivedEvent.generateCheckOutcomeStatusEntity()));
		Mockito.when(incidentTypeRepository
				.findByIncidentTypeCode(RIConstants.PrcOutcomeConstant.INCIDENT_TYPE_CODE_PROBABLE_BAN))
				.thenReturn(Optional.of(ProbableBanOutcomeReceivedEvent.getIncidentTypeProbableBan()));
		Mockito.when(incidentStatusTypeRepository.findByIncidentStatusTypeCode(INCIDENT_STATUS_TYPE_CODE_PASSED))
				.thenReturn(Optional.of(ProbableBanOutcomeReceivedEvent.getPassedIncidentStatusType()));
		Mockito.when(checkOutcomeRepository.save(any())).thenReturn(savedCheckOutcome);

		Mockito.when(bookingRepository.findById(optBooking.getBookingUuid())).thenReturn(Optional.of(optBooking));

		savedCheckOutcome.setIncidentsByCheckOutcomeUuid(
				Collections.singletonList(ProbableBanOutcomeReceivedEvent.getProbableBanIncident()));
		savedCheckOutcome.getIncidentsByCheckOutcomeUuid()
				.forEach(incident -> incident.setIncidentUuid(UUID.fromString("e58ed763-928c-4155-bee9-fdbaaadc15f3")));

		probableBanCheckoutcomeHelper.updateProbableBanOutcome(probableBanCheckOutcomeDetailsV1Inner,
				optBooking);

		Mockito.verify(probableBanCheckoutcomeHelper).updateProbableBanOutcome(
				probableBanCheckOutcomeV1.getProbableBanCheckOutcomeDetails().get(0), optBooking);
	}

	@Test
	void testOn_shouldThrowException_onError() {
		ProbableBanCheckOutcomeV1 probableBanCheckOutcomeV1 = ProbableBanOutcomeReceivedEvent
				.generateProbableBanOutcome();

		Mockito.doThrow(new ResultIntegrityException("error in processing")).when(probableBanCheckoutcomeHelper)
				.updateProbableBanOutcome(probableBanCheckOutcomeV1.getProbableBanCheckOutcomeDetails().get(0),
						null);

		Assertions.assertThrows(ResultIntegrityException.class,
				() -> probableBanOutcomeReceivedDomainService.on(probableBanCheckOutcomeV1));
	}

	@Test
	void test_shouldPublishNoActionTakenEvent_whenExistingCheckOutcomeVersionIsLatest() {
		ProbableBanCheckOutcomeDetailsV1Inner probableBanCheckOutcomeDetailsV1Inner = ProbableBanOutcomeReceivedEvent
				.generateProbableBanCheckOutcomeDetailsV1InnerPassed();
		booking.setBookingVersion(BigDecimal.valueOf(1));
		CheckOutcome savedCheckOutcome = ProbableBanOutcomeReceivedEvent.generateCheckOutcomeEntityFlaggedForReview();
		savedCheckOutcome.setCheckOutcomeUuid(UUID.fromString("6d1c020d-5407-4e14-b9c0-8af26a907d9e"));
		savedCheckOutcome.setBookingVersion(BigDecimal.valueOf(2));
		CheckOutcome modifiedCheckOutcome = ProbableBanOutcomeReceivedEvent.generateCheckOutcomeEntity();
		modifiedCheckOutcome.setCheckOutcomeUuid(UUID.fromString("6d1c020d-5407-4e14-b9c0-8af26a907d9e"));

		Mockito.when(bookingRepository.findById(UUID.fromString("2a6c84d5-3cd3-4c29-bff5-426f55c9db80")))
				.thenReturn(Optional.of(booking));
		Mockito.when(checkOutcomeTypeRepository
				.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.PROBABLE_BAN_CHECK_OUTCOME_TYPE_CODE))
				.thenReturn(Optional.of(ProbableBanOutcomeReceivedEvent.generateCheckOutcomeTypeEntity()));
		Mockito.when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
				UUID.fromString("2a6c84d5-3cd3-4c29-bff5-426f55c9db80"),
				ProbableBanOutcomeReceivedEvent.generateCheckOutcomeTypeEntity().getCheckOutcomeTypeUuid()))
				.thenReturn(Optional.of(savedCheckOutcome));
		Mockito.when(bookingRepository.findById(booking.getBookingUuid())).thenReturn(Optional.of(booking));

		Assertions.assertDoesNotThrow(() -> probableBanCheckoutcomeHelper
				.updateProbableBanOutcome(probableBanCheckOutcomeDetailsV1Inner, booking));
	}

	@Test
	void test_whenOptionalBookingIsNotPresent() {
		String incidentStatusType;
		Incident incident = ProbableBanOutcomeReceivedEvent.getProbableBanIncident();

		incidentStatusType = probableBanCheckoutcomeHelper.mapProbableBanOutcomeToIncidentStatusType("FLAGGED",
				incident);

		Assertions.assertEquals(INCIDENT_STATUS_TYPE_CODE_FLAGGED, incidentStatusType);

		Assertions.assertThrows(ResultIntegrityException.class,
				() -> probableBanCheckoutcomeHelper.mapProbableBanOutcomeToIncidentStatusType("INVALID", incident));

	}

	@Test
	void test_should_Save_CheckOutcomeWhenNoOptionalBookingIsPresent() {
		ProbableBanCheckOutcomeDetailsV1Inner probableBanCheckOutcomeDetailsV1Inner = ProbableBanOutcomeReceivedEvent
				.generateProbableBanCheckOutcomeDetailsV1InnerPassed();
		CheckOutcome savedCheckOutcome = ProbableBanOutcomeReceivedEvent.generateCheckOutcomeEntity();
		savedCheckOutcome.setCheckOutcomeUuid(UUID.fromString("2a6c84d5-3cd3-4c29-bff5-426f55c9db80"));
		Mockito.when(checkOutcomeTypeRepository
				.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.PROBABLE_BAN_CHECK_OUTCOME_TYPE_CODE))
				.thenReturn(Optional.of(ProbableBanOutcomeReceivedEvent.generateCheckOutcomeTypeEntity()));
		Mockito.when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
				UUID.fromString("2a6c84d5-3cd3-4c29-bff5-426f55c9db80"),
				ProbableBanOutcomeReceivedEvent.generateCheckOutcomeTypeEntity().getCheckOutcomeTypeUuid()))
				.thenReturn(Optional.empty());
		Mockito.when(checkOutcomeStatusRepository.findByCheckOutcomeStatusCode(CHECK_OUTCOME_STATUS_CODE_PASSED))
				.thenReturn(Optional.of(ProbableBanOutcomeReceivedEvent.generateCheckOutcomeStatusEntity()));
		Mockito.when(incidentTypeRepository
				.findByIncidentTypeCode(RIConstants.PrcOutcomeConstant.INCIDENT_TYPE_CODE_PROBABLE_BAN))
				.thenReturn(Optional.of(ProbableBanOutcomeReceivedEvent.getIncidentTypeProbableBan()));
		Mockito.when(incidentStatusTypeRepository.findByIncidentStatusTypeCode(INCIDENT_STATUS_TYPE_CODE_PASSED))
				.thenReturn(Optional.of(ProbableBanOutcomeReceivedEvent.getPassedIncidentStatusType()));
		Mockito.when(checkOutcomeRepository.save(any())).thenReturn(savedCheckOutcome);

		Mockito.when(bookingRepository.findById(booking.getBookingUuid())).thenReturn(Optional.empty());

		Assertions.assertDoesNotThrow(() -> probableBanCheckoutcomeHelper
				.updateProbableBanOutcome(probableBanCheckOutcomeDetailsV1Inner, booking));
	}

}
