package com.ielts.cmds.ri.domain.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatchers;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.ids.domain.model.PRCOutcomeGeneratedNodeV1;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.PrcOutcomeDetails;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentEvidenceRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentStatusTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.PrcOutcomeDetailsRepository;
import com.ielts.cmds.ri.infrastructure.repository.ProductIncidentMappingRepository;
import com.ielts.cmds.ri.infrastructure.repository.UniqueTestTakerRepository;
import com.ielts.cmds.ri.utils.EventOutIncidentBuilderUtil;
import com.ielts.cmds.ri.utils.PrcOutcomeDetailsEvent;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.ri.utils.TestDayIncidentRaisedEvent;

@ExtendWith(MockitoExtension.class)
class PrcOutcomeGeneratedDomainServiceTest {

	@InjectMocks
	@Spy
	PrcOutcomeGeneratedDomainService prcOutcomeGeneratedDomainService;

  @Mock private BookingRepository bookingRepository;
  @Mock private IncidentTypeRepository incidentTypeRepository;
  @Mock private IncidentStatusTypeRepository incidentStatusTypeRepository;
  @Mock private CheckOutcomeRepository checkOutcomeRepository;
  @Mock private CheckOutcomeStatusRepository checkOutcomeStatusRepository;
  @Mock private CheckOutcomeTypeRepository checkOutcomeTypeRepository;
  @Mock private IncidentEvidenceRepository incidentEvidenceRepository;
  @Mock private IncidentRepository incidentRepository;
  @Mock private PrcOutcomeDetailsRepository prcOutcomeDetailsRepository;
  @Mock private UniqueTestTakerRepository uniqueTestTakerRepository;
  @Mock private ApplicationEventPublisher applicationEventPublisher;
  @Mock private ObjectMapper objectMapper;
  @Mock private CheckOutcome checkOutcome;

  @Mock private RICommonUtil riCommonUtil;

  @Mock private OutcomeStatusRepository outcomeStatusRepository;
  @Mock private OutcomeStatusTypeRepository outcomeStatusTypeRepository;
  @Mock
  private ProductIncidentMappingRepository productIncidentMappingRepository;

  @Mock
  EventOutIncidentBuilderUtil eventOutIncidentBuilderUtil;

  @Captor ArgumentCaptor<CheckOutcome> checkOutcomeArgumentCaptor;

  @Captor ArgumentCaptor<OutcomeStatus> outcomeStatusArgumentCaptor;
  
  @BeforeEach
  void setup() {
	  CMDSHeaderContext ctx = new CMDSHeaderContext();
	  ctx.setCorrelationId(UUID.randomUUID());
	  ctx.setTransactionId(UUID.randomUUID());
	  ctx.setPartnerCode("CA");
	  ctx.setEventDateTime(LocalDateTime.now());
	  ThreadLocalHeaderContext.setContext(ctx);
  }

  @ParameterizedTest
  @MethodSource("argumentsProviderForPrcServiceTest")
  void createPrcOutcomeGeneratedOnValidFlow(
      PRCOutcomeGeneratedNodeV1 prcOutcomeGeneratedNodeV1,
      CheckOutcome checkOutcome,
      List<PrcOutcomeDetails> prcOutcomeDetailsList)
      throws JsonProcessingException {

    when(bookingRepository.findById(prcOutcomeGeneratedNodeV1.getBookingUuid()))
        .thenReturn(PrcOutcomeDetailsEvent.getBookingForTest());
    when(incidentTypeRepository
        .findByIncidentTypeCode(any()))
            .thenReturn(Optional.of(PrcOutcomeDetailsEvent.getIncidentTypePrc()));
    doReturn(PrcOutcomeDetailsEvent.getBookingForTest().get())
        .when(riCommonUtil).getBooking(any());
    when(productIncidentMappingRepository
            .findByProductUuidAndIncidentCategoryUuid
                (UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590")
                    ,UUID.fromString("7ce32c94-7bd7-409c-a755-7cb5a2b62195")))
        .thenReturn(TestDayIncidentRaisedEvent.getProductIncidentMapping());
    when(checkOutcomeRepository.save(ArgumentMatchers.any())).thenReturn(checkOutcome);
    doNothing().when(prcOutcomeGeneratedDomainService).publishEvent(any());
    when(checkOutcomeTypeRepository
            .findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_TYPE_CODE)).thenReturn(Optional.of(PrcOutcomeDetailsEvent.getCheckOutcomeTypeEntity()));
    when(uniqueTestTakerRepository
            .findByUniqueTestTakerUuid(PrcOutcomeDetailsEvent.getBookingForTest().get().getUniqueTestTakerUuid()))
            .thenReturn(Optional.of(PrcOutcomeDetailsEvent.getUniqueTestTaker()));
    prcOutcomeGeneratedDomainService.on(prcOutcomeGeneratedNodeV1);

    Mockito.verify(checkOutcomeRepository).save(checkOutcomeArgumentCaptor.capture());
  }

  @ParameterizedTest
  @MethodSource("argumentsProviderForPrcServiceTest")
  void createPrcOutcomeGeneratedOnValidFlowForPassed(
      PRCOutcomeGeneratedNodeV1 prcOutcomeGeneratedNodeV1,
      CheckOutcome checkOutcome,
      List<PrcOutcomeDetails> prcOutcomeDetailsList) {
	  when(incidentTypeRepository
		        .findByIncidentTypeCode(any()))
		            .thenReturn(Optional.of(PrcOutcomeDetailsEvent.getIncidentTypePrc()));
	  when(productIncidentMappingRepository
	            .findByProductUuidAndIncidentCategoryUuid
	                (UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590")
	                    ,UUID.fromString("7ce32c94-7bd7-409c-a755-7cb5a2b62195")))
	        .thenReturn(TestDayIncidentRaisedEvent.getProductIncidentMapping());
    when(bookingRepository.findById(prcOutcomeGeneratedNodeV1.getBookingUuid()))
        .thenReturn(PrcOutcomeDetailsEvent.getBookingForTest());
    doReturn(PrcOutcomeDetailsEvent.getBookingForTest().get())
    .when(riCommonUtil).getBooking(any());
    when(checkOutcomeRepository.save(ArgumentMatchers.any())).thenReturn(checkOutcome);
    doNothing().when(prcOutcomeGeneratedDomainService).publishEvent(any());
    when(checkOutcomeTypeRepository
            .findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_TYPE_CODE)).thenReturn(Optional.of(PrcOutcomeDetailsEvent.getCheckOutcomeTypeEntity()));

    prcOutcomeGeneratedDomainService.on(prcOutcomeGeneratedNodeV1);

    Mockito.verify(checkOutcomeRepository).save(checkOutcomeArgumentCaptor.capture());
  }

  @ParameterizedTest
  @MethodSource("argumentsProviderForPrcServiceTest")
  void createPrcOutcomeGeneratedThrowResultIntegrityException(
      PRCOutcomeGeneratedNodeV1 prcOutcomeGeneratedNodeV1,
      CheckOutcome checkOutcome,
      List<PrcOutcomeDetails> prcOutcomeDetailsList)
      throws JsonProcessingException {
    when(bookingRepository.findById(prcOutcomeGeneratedNodeV1.getBookingUuid()))
        .thenReturn(PrcOutcomeDetailsEvent.getBookingForTest());

    when(checkOutcomeRepository.save(ArgumentMatchers.any())).thenReturn(checkOutcome);
    when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
            ArgumentMatchers.any(), ArgumentMatchers.any()))
        .thenReturn(Optional.of(new CheckOutcome()));
    when(incidentTypeRepository
            .findByIncidentTypeCode(any()))
        .thenReturn(Optional.of(PrcOutcomeDetailsEvent.getIncidentTypePrc()));
    doReturn(PrcOutcomeDetailsEvent.getBookingForTest().get())
        .when(riCommonUtil).getBooking(any());
    when(productIncidentMappingRepository
            .findByProductUuidAndIncidentCategoryUuid
                (UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590")
                    ,UUID.fromString("7ce32c94-7bd7-409c-a755-7cb5a2b62195")))
        .thenReturn(TestDayIncidentRaisedEvent.getProductIncidentMapping());
    when(prcOutcomeDetailsRepository.findByBookingUuid(ArgumentMatchers.any()))
        .thenReturn(prcOutcomeDetailsList);
    doNothing().when(prcOutcomeGeneratedDomainService).publishEvent(any());
    when(checkOutcomeTypeRepository
            .findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_TYPE_CODE)).thenReturn(Optional.of(PrcOutcomeDetailsEvent.getCheckOutcomeTypeEntity()));

    prcOutcomeGeneratedDomainService.on(prcOutcomeGeneratedNodeV1);

    Mockito.verify(checkOutcomeRepository).save(ArgumentMatchers.any());
  }

  @ParameterizedTest
  @MethodSource("argumentsProviderForPrcServiceTest")
  void createPrcOutcomeGeneratedOnValidFlow_whenBookingNotPresent_shouldSaveTheOutcome(
      PRCOutcomeGeneratedNodeV1 prcOutcomeGeneratedNodeV1,
      CheckOutcome checkOutcome,
      List<PrcOutcomeDetails> prcOutcomeDetailsList)
      throws JsonProcessingException {
    when(bookingRepository.findById(prcOutcomeGeneratedNodeV1.getBookingUuid()))
        .thenReturn(Optional.empty());

    when(incidentTypeRepository
            .findByIncidentTypeCode(any()))
        .thenReturn(Optional.of(PrcOutcomeDetailsEvent.getIncidentTypePrc()));
    doReturn(PrcOutcomeDetailsEvent.getBookingForTest().get())
        .when(riCommonUtil).getBooking(any());
    when(productIncidentMappingRepository
            .findByProductUuidAndIncidentCategoryUuid
                (UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590")
                    ,UUID.fromString("7ce32c94-7bd7-409c-a755-7cb5a2b62195")))
        .thenReturn(TestDayIncidentRaisedEvent.getProductIncidentMapping());
    when(checkOutcomeRepository.save(ArgumentMatchers.any())).thenReturn(checkOutcome);
    doNothing().when(prcOutcomeGeneratedDomainService).publishEvent(any());
    when(checkOutcomeTypeRepository
            .findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_TYPE_CODE)).
            thenReturn(Optional.of(PrcOutcomeDetailsEvent.getCheckOutcomeTypeEntity()));

    prcOutcomeGeneratedDomainService.on(prcOutcomeGeneratedNodeV1);
    Mockito.verify(checkOutcomeRepository).save(checkOutcomeArgumentCaptor.capture());
  }

  private static Stream<Arguments> argumentsProviderForPrcServiceTest() {
    PRCOutcomeGeneratedNodeV1 prcOutcomeGeneratedNodeV1 =
        PrcOutcomeDetailsEvent.getPrcOutcomeGeneratedNodeV1();
    CheckOutcome checkOutcome = PrcOutcomeDetailsEvent.getCheckOutcome();
    List<PrcOutcomeDetails> prcOutcomeDetailsList = PrcOutcomeDetailsEvent.getListPrcOutcome();
    return Stream.of(
        Arguments.of(
            prcOutcomeGeneratedNodeV1,
            checkOutcome,
            prcOutcomeDetailsList
            ));
  }
  @ParameterizedTest
  @MethodSource("argumentsProviderForPrcServiceTest")
  void shouldNotCreatewhenPRCUttidAndBookingUttidIsNotSame(
          PRCOutcomeGeneratedNodeV1 prcOutcomeGeneratedNodeV1,
          CheckOutcome checkOutcome,
          List<PrcOutcomeDetails> prcOutcomeDetailsList)
          throws JsonProcessingException {
    PRCOutcomeGeneratedNodeV1 prcOutcomeGeneratedNodeV1_differentUttid=PrcOutcomeDetailsEvent.getPrcOutcomeGeneratedNodeV1_DifferentUttid();
    when(bookingRepository.findById(prcOutcomeGeneratedNodeV1_differentUttid.getBookingUuid()))
            .thenReturn(PrcOutcomeDetailsEvent.getBookingForTest());
     when(checkOutcomeTypeRepository
            .findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_TYPE_CODE)).
            thenReturn(Optional.of(PrcOutcomeDetailsEvent.getCheckOutcomeTypeEntity()));

    assertDoesNotThrow(()->prcOutcomeGeneratedDomainService.on(prcOutcomeGeneratedNodeV1_differentUttid));
  }
}
