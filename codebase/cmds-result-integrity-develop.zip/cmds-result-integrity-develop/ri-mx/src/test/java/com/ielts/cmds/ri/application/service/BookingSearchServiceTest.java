package com.ielts.cmds.ri.application.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.ri.common.model.out.SearchBookingRequestV1;
import com.ielts.cmds.ri.domain.service.BookingSearchDomainService;
import com.ielts.cmds.ri.domain.service.BookingSearchTestSetup;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.*;

/** The type Booking search service test. */
@ExtendWith(MockitoExtension.class)
class BookingSearchServiceTest {

  /** The Booking search service. */
  @InjectMocks BookingSearchService bookingSearchService;

  /** The Booking search domain service. */
  @Mock BookingSearchDomainService bookingSearchDomainService;

  private static SearchBookingRequestV1 requestV1;

  /** Init. */
  @BeforeEach
  void init() {
    requestV1 = BookingSearchTestSetup.createSearchBookingRequestObject();
  }

  /**
   * When booking event is received then delegate request to domain service.
   */
  @Test
  void whenBookingEventIsReceived_ThenDelegateRequestToDomainService()
      throws RbacValidationException, JsonProcessingException {

    final Executable executable = () -> bookingSearchService.process(requestV1);

    assertDoesNotThrow(executable);
    verify(bookingSearchDomainService, times(1)).on(requestV1);
  }

  @Test
  void whenBookingEventIsReceived_ThenThrowException()
          throws RbacValidationException, JsonProcessingException {

    doThrow(RuntimeException.class).when(bookingSearchDomainService).on(any());
    final Executable executable = () -> bookingSearchService.process(requestV1);

    assertDoesNotThrow(executable);
    verify(bookingSearchDomainService, times(1)).publishEventToOutBoundTopic(null,null);
  }
}
