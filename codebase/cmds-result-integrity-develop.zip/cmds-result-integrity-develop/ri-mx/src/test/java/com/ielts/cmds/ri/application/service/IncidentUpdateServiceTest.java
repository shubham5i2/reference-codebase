package com.ielts.cmds.ri.application.service;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.ri.common.model.out.UpdateIncidentDetailsV1;
import com.ielts.cmds.ri.domain.service.IncidentUpdateDomainService;
import com.ielts.cmds.ri.utils.IncidentUpdateTestSetup;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
class IncidentUpdateServiceTest {

    @InjectMocks
    IncidentUpdateService incidentUpdateService;

    @Mock
    IncidentUpdateDomainService incidentUpdateDomainService;


    @Test
    void whenIncidentEventIsReceived_ThenDelegateRequestToDomainService()
            throws JsonProcessingException, RbacValidationException {
        UpdateIncidentDetailsV1 requestV1 = IncidentUpdateTestSetup.updateIncidentDetailsV1();

        doNothing().when(incidentUpdateDomainService).on(requestV1);
        final Executable executable = () -> incidentUpdateService.process(requestV1);


        assertDoesNotThrow(executable);

    }

    @Test
    void whenIncidentEventIsReceivedWithNullUpdateDetails_ThenThrowException()
            throws JsonProcessingException, RbacValidationException {

        final Executable executable = () -> incidentUpdateService.process(null);
        assertDoesNotThrow(executable);
        verify(incidentUpdateDomainService, times(0)).on(any());
        verify(incidentUpdateDomainService, times(1)).publishIncidentUpdateEventToOutBoundTopic(any(), any(), any());
    }


}


