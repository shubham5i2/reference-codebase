package com.ielts.cmds.ri.application.service;

import com.ielts.cmds.ri.domain.service.IncidentViewDomainService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.*;

/**
 * The type Incident view service test.
 */
@ExtendWith(MockitoExtension.class)
class IncidentViewServiceTest {

  @InjectMocks
  IncidentViewService incidentViewService;

  @Mock
  IncidentViewDomainService incidentViewDomainService;

  /**
   * When valid payload then verify domain call with no exception.
   *
   * @throws Exception the exception
   */
  @Test
  void whenValidPayload_thenVerifyDomainCallWithNoException()
      throws Exception {
    incidentViewService.process(new Object());
    verify(incidentViewDomainService, times(1)).on();
  }

  @Test
  void whenInValidPayload_thenThrowException()
          throws Exception {
    doThrow(RuntimeException.class).when(incidentViewDomainService).on();
    incidentViewService.process(new Object());
    verify(incidentViewDomainService, times(1)).publishEventToOutBoundTopic(null, null);
  }

  @Test
  void testBaseAudits() {
    Assertions.assertNull(incidentViewService.getPermission());
    Assertions.assertNull(incidentViewService.getScreen());
    Assertions.assertNotNull(incidentViewService.getAction());
  }

}


