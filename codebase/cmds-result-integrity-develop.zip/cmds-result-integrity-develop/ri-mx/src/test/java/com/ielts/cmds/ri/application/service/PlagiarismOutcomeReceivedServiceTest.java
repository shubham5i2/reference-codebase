package com.ielts.cmds.ri.application.service;

import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.plagiarism.common.out.model.PlagiarismOutcomeV1;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.domain.service.PlagiarismOutcomeReceivedDomainService;
import com.ielts.cmds.ri.utils.PlagiarismOutcomeReceivedEvent;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.UUID;

import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(SpringExtension.class)
class PlagiarismOutcomeReceivedServiceTest {

	@InjectMocks
	PlagiarismOutcomeReceivedService plagiarismOutcomeReceivedService;
	
	@Mock
	PlagiarismOutcomeReceivedDomainService plagiarismOutcomeReceivedDomainService;
	
	@Test
	void testProcess() {
		CMDSHeaderContext ctx = new CMDSHeaderContext();
		ctx.setCorrelationId(UUID.randomUUID());
		ThreadLocalHeaderContext.setContext(ctx);
		PlagiarismOutcomeV1 plagiarismOutcomeV1 = PlagiarismOutcomeReceivedEvent.generatePlagiarismOutcome();
		plagiarismOutcomeReceivedService.process(plagiarismOutcomeV1);
		
		verify(plagiarismOutcomeReceivedDomainService,times(1)).on(plagiarismOutcomeV1);
	}
	
	@Test
	void testProcessWithException() {
		CMDSHeaderContext ctx = new CMDSHeaderContext();
		ctx.setCorrelationId(UUID.randomUUID());
		ThreadLocalHeaderContext.setContext(ctx);
		
		assertThrows(ResultIntegrityException.class, () -> plagiarismOutcomeReceivedService.process(null));
		
	}
	@Test
	void testBaseAudits() {
		Assertions.assertNull(plagiarismOutcomeReceivedService.getPermission());
		Assertions.assertNull(plagiarismOutcomeReceivedService.getScreen());
		Assertions.assertNotNull(plagiarismOutcomeReceivedService.getAction());
	}
	
}
