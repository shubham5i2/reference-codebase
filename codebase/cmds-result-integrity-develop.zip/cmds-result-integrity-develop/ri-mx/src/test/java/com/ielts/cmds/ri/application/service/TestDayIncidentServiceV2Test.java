package com.ielts.cmds.ri.application.service;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.ids.domain.model.ReceivedIncidentDetailsV1;
import com.ielts.cmds.ri.domain.service.TestDayIncidentDomainService;

@ExtendWith(MockitoExtension.class)
class TestDayIncidentServiceV2Test {

	@InjectMocks
    TestDayIncidentService testDayIncidentService;

	@Mock
	TestDayIncidentDomainService testDayIncidentDomainService;

	@Test
	void testProcess() {
		ReceivedIncidentDetailsV1 incidentDetails = new ReceivedIncidentDetailsV1();
		testDayIncidentService.process(incidentDetails);
		verify(testDayIncidentDomainService, times(1)).on(incidentDetails);
	}
}
