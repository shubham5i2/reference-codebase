package com.ielts.cmds.ri.application.service;

import com.ielts.cmds.api.evt119.IntegrityCheckInitiatedV1;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.ri.domain.service.IntegrityCheckDomainService;
import com.ielts.cmds.ri.utils.IntegrityCheckEvent;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class IntegrityCheckServiceTest {

  @InjectMocks
  IntegrityCheckService integrityCheckService;

  @Mock
  IntegrityCheckDomainService integrityCheckDomainService;

  @Test
  void whenProcessCalled_shouldProcessTheData() {
    IntegrityCheckInitiatedV1 IntegrityCheckInitiatedV1 = IntegrityCheckEvent.getIntegrityCheckInitiatedV1();

    Mockito.doNothing().when(integrityCheckDomainService).on(IntegrityCheckInitiatedV1);

    integrityCheckService.process(IntegrityCheckInitiatedV1);

    Mockito.verify(integrityCheckDomainService).on(IntegrityCheckInitiatedV1);
  }

  @Test
  void whenProcessCalled_shouldThrowException() {
    Assertions.assertThrows(ProcessingException.class, () -> integrityCheckService.process(null));
  }

}
