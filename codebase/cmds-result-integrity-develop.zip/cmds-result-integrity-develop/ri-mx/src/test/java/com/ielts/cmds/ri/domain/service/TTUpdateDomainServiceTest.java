package com.ielts.cmds.ri.domain.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.evt_019.BookingDetailsV1;
import com.ielts.cmds.infrastructure.event.context.CMDSAuditContext;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeType;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentCommentRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.ProductRepository;
import com.ielts.cmds.ri.utils.BookingDetailsEvent;
import com.ielts.cmds.ri.utils.IncidentViewTestSetup;
import com.ielts.cmds.ri.utils.IntegrityCheckEvent;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.ri.utils.RIUtil;
import com.ielts.cmds.ri.utils.TestDayIncidentRaisedEvent;

@ExtendWith(MockitoExtension.class)
class TTUpdateDomainServiceTest {

  @InjectMocks
  @Spy
  TTUpdateDomainService ttUpdateDomainService;
  @Mock
  CheckOutcomeRepository checkOutcomeRepository;
  @Mock
  CheckOutcomeTypeRepository checkOutcomeTypeRepository;
  @Mock
  CheckOutcomeStatusRepository checkOutcomeStatusRepository;
  @Mock
  OutcomeStatusRepository outcomeStatusRepository;
  @Mock
  ProductRepository productRepository;
  @Mock
  IncidentRepository incidentRepository;
  @Mock
  IncidentCommentRepository incidentCommentRepository;
  @Captor
  ArgumentCaptor<CheckOutcome> checkOutcomeArgumentCaptor;
  @Mock
  private ObjectMapper mapper;
  private CMDSHeaderContext cmdsHeaderContext;

  @BeforeEach
  void init() {
    mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
    mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    cmdsHeaderContext = RIUtil.createCMDSHeaderContextByEventName(RIConstants.EventType.BOOKING_CANCELLED_EVENT);
    ThreadLocalHeaderContext.setContext(cmdsHeaderContext);
    ThreadLocalAuditContext.setContext(new CMDSAuditContext());
  }

  /**
   * Update booking version of prc outcome when uttid not changed and prc outcome exists.
   */
  @Test
  void updateBookingVersionOfPrcOutcome_when_UttidNotChangedAndPrcOutcomeExists() {

    Booking booking = BookingDetailsEvent.setBookingForTest();
    BookingDetailsV1 bookingDetails = BookingDetailsEvent.getBookingDetailsBody();
    booking.setUniqueTestTakerUuid(UUID.fromString("e427ff0e-698e-48af-bf54-5aba8c95606d"));
    bookingDetails.getTestTaker().setUniqueTestTakerUuid(UUID.fromString("e427ff0e-698e-48af-bf54-5aba8c95606d"));
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_TYPE_CODE))
            .thenReturn(Optional.of(IntegrityCheckEvent.getPRCCheckOutcomeType()));
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.PROBABLE_BAN_CHECK_OUTCOME_TYPE_CODE))
            .thenReturn(Optional.of(IntegrityCheckEvent.getProbableBanCheckOutcomeType()));
    when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
    		booking.getBookingUuid(), IntegrityCheckEvent.getPRCCheckOutcomeType().getCheckOutcomeTypeUuid()))
            .thenReturn(Optional.of(IntegrityCheckEvent.getPRCCheckOutcome()));
    when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
    		booking.getBookingUuid(), IntegrityCheckEvent.getProbableBanCheckOutcomeType().getCheckOutcomeTypeUuid()))
            .thenReturn(Optional.of(IntegrityCheckEvent.getProbableBanCheckOutcomeAsPassed()));
    when(checkOutcomeRepository.save(any())).thenReturn(IntegrityCheckEvent.getPRCCheckOutcome());

    doNothing().when(ttUpdateDomainService).publishEvent(any());
    ttUpdateDomainService.resetExistingCheckOutcomes(booking.getUniqueTestTakerUuid(), bookingDetails);
    Mockito.verify(checkOutcomeRepository).save(checkOutcomeArgumentCaptor.capture());

  }

  /**
   * Test reset overall outcome status when uttid not changed and prc outcome not exists.
   */
  @Test
  void testresetExistingCheckOutcomes_when_UttidNotChangedAndPrcOutcomeNotExists() {
    Booking booking = BookingDetailsEvent.setBookingForTest();
    BookingDetailsV1 bookingDetails = BookingDetailsEvent.getBookingDetailsBody();
    booking.setUniqueTestTakerUuid(UUID.fromString("e427ff0e-698e-48af-bf54-5aba8c95606d"));
    bookingDetails.getTestTaker().setUniqueTestTakerUuid(UUID.fromString("e427ff0e-698e-48af-bf54-5aba8c95606d"));
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_TYPE_CODE))
        .thenReturn(Optional.of(IntegrityCheckEvent.getPRCCheckOutcomeType()));
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.PROBABLE_BAN_CHECK_OUTCOME_TYPE_CODE))
        .thenReturn(Optional.of(IntegrityCheckEvent.getProbableBanCheckOutcomeType()));
    when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
    		booking.getBookingUuid(), IntegrityCheckEvent.getPRCCheckOutcomeType().getCheckOutcomeTypeUuid()))
        .thenReturn(Optional.empty());
    when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
    		booking.getBookingUuid(), IntegrityCheckEvent.getProbableBanCheckOutcomeType().getCheckOutcomeTypeUuid()))
        .thenReturn(Optional.of(IntegrityCheckEvent.getProbableBanCheckOutcomeAsPassed()));
    when(incidentRepository.findByCheckOutcomeByCheckOutcomeUuidAndBookingUuid
        (IntegrityCheckEvent.getProbableBanCheckOutcomeAsPassed(), booking.getBookingUuid()))
        .thenReturn(TestDayIncidentRaisedEvent.getIncidentList());
    ttUpdateDomainService.resetExistingCheckOutcomes(booking.getBookingUuid(), bookingDetails);
    Mockito.verify(incidentRepository, times(2)).delete(TestDayIncidentRaisedEvent.getIncidentList().get(0));
    Mockito.verify(checkOutcomeRepository, times(2)).delete(checkOutcomeArgumentCaptor.capture());
  }

  /**
   * Test reset overall outcome status when uttid changed and prc outcome not exists.
   */
  @Test
  void testresetExistingCheckOutcomes_when_UttidChangedAndPrcOutcomeNotExists() {
    Booking booking = BookingDetailsEvent.setBookingForTest();
    BookingDetailsV1 bookingDetails = BookingDetailsEvent.getBookingDetailsBody();
    booking.setUniqueTestTakerUuid(UUID.fromString("e427ff0e-698e-48af-bf54-5aba8c95606d"));
    bookingDetails.getTestTaker().setUniqueTestTakerUuid(UUID.fromString("f427ff0e-698e-48af-bf54-5aba8c95606d"));
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_TYPE_CODE))
        .thenReturn(Optional.of(IntegrityCheckEvent.getPRCCheckOutcomeType()));
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.PROBABLE_BAN_CHECK_OUTCOME_TYPE_CODE))
        .thenReturn(Optional.of(IntegrityCheckEvent.getProbableBanCheckOutcomeType()));
    when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
    		booking.getBookingUuid(), IntegrityCheckEvent.getPRCCheckOutcomeType().getCheckOutcomeTypeUuid()))
        .thenReturn(Optional.empty());
    when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
    		booking.getBookingUuid(), IntegrityCheckEvent.getProbableBanCheckOutcomeType().getCheckOutcomeTypeUuid()))
        .thenReturn(Optional.of(IntegrityCheckEvent.getProbableBanCheckOutcomeAsPassed()));
    when(incidentRepository.findByCheckOutcomeByCheckOutcomeUuidAndBookingUuid
        (IntegrityCheckEvent.getProbableBanCheckOutcomeAsPassed(), booking.getBookingUuid()))
        .thenReturn(TestDayIncidentRaisedEvent.getIncidentList());
    assertDoesNotThrow(() -> ttUpdateDomainService.resetExistingCheckOutcomes(booking.getBookingUuid(), bookingDetails));
    Mockito.verify(incidentRepository, times(2)).delete(TestDayIncidentRaisedEvent.getIncidentList().get(0));
    Mockito.verify(checkOutcomeRepository, times(2)).delete(checkOutcomeArgumentCaptor.capture());
  }

  /**
   * Delete prc outcome when uttid changed and prc outcome exists.
   */
  @Test
  void deletePrcOutcome_when_UttidChangedAndPrcOutcomeExists() {
    Booking booking = BookingDetailsEvent.setBookingForTest();
    BookingDetailsV1 bookingDetails = BookingDetailsEvent.getBookingDetailsBody();
    booking.setUniqueTestTakerUuid(UUID.fromString("e427ff0e-698e-48af-bf54-5aba8c95606d"));
    bookingDetails.getTestTaker().setUniqueTestTakerUuid(UUID.fromString("f427ff0e-698e-48af-bf54-5aba8c95606d"));
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_TYPE_CODE))
        .thenReturn(Optional.of(IntegrityCheckEvent.getPRCCheckOutcomeType()));
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.PROBABLE_BAN_CHECK_OUTCOME_TYPE_CODE))
        .thenReturn(Optional.of(IntegrityCheckEvent.getProbableBanCheckOutcomeType()));
    when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
    		booking.getBookingUuid(), IntegrityCheckEvent.getPRCCheckOutcomeType().getCheckOutcomeTypeUuid()))
        .thenReturn(Optional.of(IntegrityCheckEvent.getPRCCheckOutcome()));
    when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
    		booking.getBookingUuid(), IntegrityCheckEvent.getProbableBanCheckOutcomeType().getCheckOutcomeTypeUuid()))
        .thenReturn(Optional.of(IntegrityCheckEvent.getProbableBanCheckOutcomeAsPassed()));
   when(incidentRepository.findByCheckOutcomeByCheckOutcomeUuidAndBookingUuid
        (IntegrityCheckEvent.getProbableBanCheckOutcomeAsPassed(), booking.getBookingUuid()))
        .thenReturn(TestDayIncidentRaisedEvent.getIncidentList());
    when(incidentRepository.findByCheckOutcomeByCheckOutcomeUuidAndBookingUuid
        (IntegrityCheckEvent.getProbableBanCheckOutcomeAsPassed(), booking.getBookingUuid()))
        .thenReturn(TestDayIncidentRaisedEvent.getIncidentList());
    assertDoesNotThrow(() -> ttUpdateDomainService.resetExistingCheckOutcomes(booking.getBookingUuid(), bookingDetails));
    Mockito.verify(incidentRepository, times(2)).delete(TestDayIncidentRaisedEvent.getIncidentList().get(0));

  }

  /**
   * Test reset overall outcome status when uttid not changed and prc outcome and probable outcome not exists.
   */
  @Test
  void testresetExistingCheckOutcomes_when_UttidNotChangedAndPrcOutcomeAndProbableOutcomeNotExists() {
    Booking booking = BookingDetailsEvent.setBookingForTest();
    BookingDetailsV1 bookingDetails = BookingDetailsEvent.getBookingDetailsBody();
    booking.setUniqueTestTakerUuid(UUID.fromString("e427ff0e-698e-48af-bf54-5aba8c95606d"));
    bookingDetails.getTestTaker().setUniqueTestTakerUuid(UUID.fromString("e427ff0e-698e-48af-bf54-5aba8c95606d"));
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_TYPE_CODE))
        .thenReturn(Optional.of(IntegrityCheckEvent.getPRCCheckOutcomeType()));
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.PROBABLE_BAN_CHECK_OUTCOME_TYPE_CODE))
        .thenReturn(Optional.of(IntegrityCheckEvent.getProbableBanCheckOutcomeType()));
    when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
    		booking.getBookingUuid(), IntegrityCheckEvent.getPRCCheckOutcomeType().getCheckOutcomeTypeUuid()))
        .thenReturn(Optional.empty());
    when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
    		booking.getBookingUuid(), IntegrityCheckEvent.getProbableBanCheckOutcomeType().getCheckOutcomeTypeUuid()))
        .thenReturn(Optional.empty());
    ttUpdateDomainService.resetExistingCheckOutcomes(booking.getBookingUuid(), bookingDetails);
    Mockito.verify(incidentRepository, times(0)).delete(TestDayIncidentRaisedEvent.getIncidentList().get(0));
    Mockito.verify(checkOutcomeRepository, times(0)).delete(checkOutcomeArgumentCaptor.capture());
  }

  /**
   * Test reset overall outcome status when uttid changed and prc outcome exists and probable ban outcome not exists.
   */
  @Test
  void testresetExistingCheckOutcomes_when_UttidChangedAndPrcOutcomeExistsAndProbableBanOutcomeNotExists() {
    Booking booking = BookingDetailsEvent.setBookingForTest();
    BookingDetailsV1 bookingDetails = BookingDetailsEvent.getBookingDetailsBody();
    booking.setUniqueTestTakerUuid(UUID.fromString("e427ff0e-698e-48af-bf54-5aba8c95606d"));
    bookingDetails.getTestTaker().setUniqueTestTakerUuid(UUID.fromString("f427ff0e-698e-48af-bf54-5aba8c95606d"));
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_TYPE_CODE))
        .thenReturn(Optional.of(IntegrityCheckEvent.getPRCCheckOutcomeType()));
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.PROBABLE_BAN_CHECK_OUTCOME_TYPE_CODE))
        .thenReturn(Optional.of(IntegrityCheckEvent.getProbableBanCheckOutcomeType()));
    when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
    		booking.getBookingUuid(), IntegrityCheckEvent.getPRCCheckOutcomeType().getCheckOutcomeTypeUuid()))
        .thenReturn(Optional.of(IntegrityCheckEvent.getPRCCheckOutcome()));
    when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
    		booking.getBookingUuid(), IntegrityCheckEvent.getProbableBanCheckOutcomeType().getCheckOutcomeTypeUuid()))
        .thenReturn(Optional.empty());
    assertDoesNotThrow(() -> ttUpdateDomainService.resetExistingCheckOutcomes(booking.getBookingUuid(), bookingDetails));

  }

// Add test cases for spk,plg,lrw to check if all present and if some present

  /**
   * Test get check outcome type.
   */
  @Test
  void testGetCheckOutcomeType() {
    // Arrange
    CheckOutcomeType checkOutcomeType = new CheckOutcomeType();
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode("code")).thenReturn(Optional.of(checkOutcomeType));

    // Act
    CheckOutcomeType result = ttUpdateDomainService.getCheckOutComeType("code");

    // Assert
    assertNotNull(result);
    assertEquals(checkOutcomeType, result);
  }

  /**
   * Test get check outcome type with invalid code.
   */
  @Test
  void testGetCheckOutcomeTypeWithInvalidCode() {
    // Arrange
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode("invalidCode")).thenReturn(Optional.empty());

    // Act
    CheckOutcomeType result = ttUpdateDomainService.getCheckOutComeType("invalidCode");

    // Assert
    assertNull(result);
  }

  @Test
  void updateBookingVersionOfPrcOutcome_when_UttidNotChangedAndPrcOutcomeExists_PublishIntegrityCheckInitiatedEvent() {
    Booking booking = BookingDetailsEvent.setBookingForTest();
    BookingDetailsV1 bookingDetails = BookingDetailsEvent.getBookingDetailsBody();
    booking.setUniqueTestTakerUuid(UUID.fromString("e427ff0e-698e-48af-bf54-5aba8c95606d"));
    bookingDetails.getTestTaker().setUniqueTestTakerUuid(UUID.fromString("e427ff0e-698e-48af-bf54-5aba8c95606d"));
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_TYPE_CODE))
            .thenReturn(Optional.of(IntegrityCheckEvent.getPRCCheckOutcomeType()));
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.PROBABLE_BAN_CHECK_OUTCOME_TYPE_CODE))
            .thenReturn(Optional.of(IntegrityCheckEvent.getProbableBanCheckOutcomeType()));
    when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
    		booking.getBookingUuid(), IntegrityCheckEvent.getPRCCheckOutcomeType().getCheckOutcomeTypeUuid()))
            .thenReturn(Optional.of(IntegrityCheckEvent.getPRCCheckOutcome()));
    when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
    		booking.getBookingUuid(), IntegrityCheckEvent.getProbableBanCheckOutcomeType().getCheckOutcomeTypeUuid()))
            .thenReturn(Optional.of(IntegrityCheckEvent.getProbableBanCheckOutcomeAsPassed()));
    when(checkOutcomeRepository.save(any())).thenReturn(IntegrityCheckEvent.getPRCCheckOutcome());
    when(checkOutcomeRepository.findByBookingUuid(booking.getBookingUuid())).
            thenReturn(IntegrityCheckEvent.listOfAllCheckOutcome());
    doNothing().when(ttUpdateDomainService).publishEvent(any());
    ttUpdateDomainService.resetExistingCheckOutcomes(booking.getUniqueTestTakerUuid(), bookingDetails);
    Mockito.verify(checkOutcomeRepository).save(checkOutcomeArgumentCaptor.capture());

  }

}
