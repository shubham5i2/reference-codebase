package com.ielts.cmds.ri.domain.service;

import static com.ielts.cmds.ri.utils.RIConstants.GenericConstants.TEST_CENTRE;
import static com.ielts.cmds.ri.utils.RIConstants.PermissionId.RI_INCIDENT_SEARCH;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anySet;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Stream;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Root;
import javax.validation.ConstraintViolation;
import javax.validation.metadata.ConstraintDescriptor;

import org.hibernate.validator.internal.engine.ConstraintViolationImpl;
import org.hibernate.validator.internal.engine.path.PathImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatchers;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.rbac.api.service.JWTDecoder;
import com.ielts.cmds.rbac.api.service.LocationHierarchyService;
import com.ielts.cmds.rbac.api.service.RBACService;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.api.service.model.CmdsAuthentication;
import com.ielts.cmds.rbac.api.service.model.LocationNode;
import com.ielts.cmds.rbac.api.utils.RBACServiceUtils;
import com.ielts.cmds.ri.common.model.out.SearchIncidentRequestV1;
import com.ielts.cmds.ri.common.model.out.SearchSortV1Item;
import com.ielts.cmds.ri.infrastructure.entity.IncidentView;
import com.ielts.cmds.ri.infrastructure.repository.IncidentViewRepository;
import com.ielts.cmds.ri.utils.IncidentSearchSpecification;
import com.ielts.cmds.ri.utils.IncidentSearchTestSetup;
import com.ielts.cmds.ri.utils.RICommonUtil;

/**
 * The type Booking search domain service test.
 */
@ExtendWith(MockitoExtension.class)
class IncidentSearchDomainServiceTest {

  /**
   * The Booking search domain service.
   */
  @Spy
  @InjectMocks
  IncidentSearchDomainService incidentSearchDomainService;

  @Mock
  private IncidentViewRepository incidentViewRepository;


  /**
   * The Booking out come specification.
   */
  @Captor
  ArgumentCaptor<Specification<IncidentView>> incidentSpecification;

  /**
   * The Pageable arg.
   */
  @Captor
  ArgumentCaptor<Pageable> pageableArg;

  /**
   * The Root.
   */
  @Mock
  Root<IncidentView> root;

  @Mock
  CmdsAuthentication authentication;

  /**
   * The Criteria builder.
   */
  @Mock
  CriteriaBuilder criteriaBuilder;

  /**
   * The Criteria query.
   */
  @Mock
  CriteriaQuery<IncidentView> criteriaQuery;

  @Mock
  Specification<IncidentView> incidentViewSpecification;

  /**
   * The Expr.
   */
  @Mock
  Expression<?> expr;

  /**
   * The Common utils.
   */
  @Mock
  RICommonUtil commonUtils;

  @Mock
  private CMDSErrorResolver<Object> errorResolver;

  /**
   * The Violations.
   */
  @Mock
  Set<ConstraintViolation<Object>> violations;

  @Mock
  IncidentSearchSpecification searchSpecification;

  @Mock
  JWTDecoder jwtDecoder;

  @Mock
  RBACServiceUtils rbacServiceUtils;


  @Spy
  private LocationHierarchyService locationHierarchyService;

  @Spy
  private LocationNode locationNode;

  @Mock
  CmdsAuthentication cmdsAuthentication;

  @Mock
  private RBACService rbacService;

  /**
   * Sets up.
   */
  @BeforeEach
  void setUp() {
    CMDSHeaderContext headerContext = new CMDSHeaderContext();
    headerContext.setXaccessToken("");
    ThreadLocalHeaderContext.setContext(headerContext);
  }

  @ParameterizedTest
  @MethodSource("provideArgumentsForSearchIncidentCommand")
  void whenReceivedValid_UserGroupCommand_thenNoException(
      final SearchIncidentRequestV1 requestV1,
      final List<IncidentView> viewList,
      final Pageable pageObj)
      throws RbacValidationException, JsonProcessingException {

    Set<UUID> commonLocation = IncidentSearchTestSetup.getCommonAccessibleLocationsForBooking();
    Page<IncidentView> pageableUserdtl = new PageImpl<>(viewList, pageObj, 50);

    when(commonUtils.hasAllAccess("", RI_INCIDENT_SEARCH)).thenReturn(true);

    when(searchSpecification.apply(requestV1,commonLocation)).thenReturn(incidentViewSpecification);

    doReturn(locationNode).when(commonUtils).getParentNode(ArgumentMatchers.any(),ArgumentMatchers.any());

    when(locationHierarchyService.getUuidsOfLocationBranchByLocationUuid(ArgumentMatchers.any(),
        ArgumentMatchers.any())).thenReturn(IncidentSearchTestSetup.getClaimedAccessibleLocations());

    when(incidentViewRepository.findAll(incidentViewSpecification, pageObj))
        .thenReturn(pageableUserdtl);
    when(commonUtils.getParentNode(IncidentSearchTestSetup.generateIncidentViewData()
        .getLocationUuid(),TEST_CENTRE)).thenReturn(locationNode);

    when(jwtDecoder.decodeAccessToken(ThreadLocalHeaderContext.getContext().getXaccessToken()))
        .thenReturn(authentication);
    when(RBACServiceUtils.getClaimList(authentication))
        .thenReturn(IncidentSearchTestSetup.claimDetailsList());
    doNothing().when(incidentSearchDomainService).publishEvent(any());

    incidentSearchDomainService.on(requestV1);

    verify(incidentViewRepository).findAll(incidentSpecification.capture(), pageableArg.capture());

    assertEquals(0, pageableArg.getValue().getPageNumber());
    assertEquals(10, pageableArg.getValue().getPageSize());
    assertNotNull(pageableArg.getValue().getSort());
  }

  @ParameterizedTest
  @MethodSource("provideArgumentsForSearchIncidentCommand")
  void testOnCommand_WhenInvalidAccess_ShouldPublishMessageWithErrors(
      final SearchIncidentRequestV1 requestV1,
      final List<IncidentView> viewList,
      final Pageable pageObj)
      throws RbacValidationException, JsonProcessingException {

    when(commonUtils.hasAllAccess("", RI_INCIDENT_SEARCH)).thenReturn(false);

    Set<ConstraintViolation<Object>> constraintViolation =
        getSetforNullViolationOfEventBody("V_unauthorised_to_search_incident");
    when(errorResolver.populatErrorResponse(constraintViolation, "IncidentSearchResponseGenerated"))
        .thenReturn(new CMDSErrorResponse());
    doNothing().when(incidentSearchDomainService).publishEvent(any(), any());
    incidentSearchDomainService.on(requestV1);

    Mockito.verify(commonUtils).hasAllAccess("", RI_INCIDENT_SEARCH);
  }

  @ParameterizedTest
  @MethodSource("provideArgumentsForSearchIncidentCommand")
  void testOnCommand_WhenInvalidAccessToLocation_ShouldPublishMessageWithErrors(
      final SearchIncidentRequestV1 requestV1,
      final List<IncidentView> viewList,
      final Pageable pageObj)
      throws RbacValidationException, JsonProcessingException {

    when(commonUtils.hasAllAccess("", RI_INCIDENT_SEARCH)).thenReturn(true);
    doReturn(Collections.emptySet()).when(incidentSearchDomainService)
        .getAccessibleLocations();
    doReturn(Collections.emptySet()).when(incidentSearchDomainService)
        .getChildLocations(any());

    doReturn(null).when(incidentSearchDomainService)
        .getCommonAccessibleLocations(anySet(),anySet());
    Set<ConstraintViolation<Object>> constraintViolation =
        getSetforLocationViolationOfEventBody("E_unauthorised_to_access_with_selected_location");
    when(errorResolver.populatErrorResponse(constraintViolation, "IncidentSearchResponseGenerated"))
        .thenReturn(new CMDSErrorResponse());
    doNothing().when(incidentSearchDomainService).publishEvent(any(), any());
    incidentSearchDomainService.on(requestV1);

    Mockito.verify(commonUtils).hasAllAccess("", RI_INCIDENT_SEARCH);
  }

  @Test
  void getAccessibleLocationsTest() throws RbacValidationException {

    when(jwtDecoder.decodeAccessToken(ThreadLocalHeaderContext.getContext().getXaccessToken()))
        .thenReturn(authentication);
    when(RBACServiceUtils.getClaimList(authentication))
        .thenReturn(IncidentSearchTestSetup.claimDetailsList());

    assertNotNull(incidentSearchDomainService.getAccessibleLocations());

  }

  /**
   * Gets setfor null violation of event body.
   *
   * @param interpolatedMessage the interpolated message
   * @return the setfor null violation of event body
   */
  public Set<ConstraintViolation<Object>> getSetforNullViolationOfEventBody(
      final String interpolatedMessage) {

    Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
    final String messageTemplate = null;
    final Class<Object> rootBeanClass = null;
    final Object rootBean = null;
    final Object leafBeanInstance = null;
    final Object value = null;
    final javax.validation.Path propertyPath =
        PathImpl.createPathFromString("unauthorisedToSearchIncident");
    final ConstraintDescriptor<?> constraintDescriptor = null;
    final Map<String, Object> messageParameters = new HashMap<>();
    final Map<String, Object> expressionVariables = new HashMap<>();
    ConstraintViolation<Object> constraintViolationImpl1 =
        (ConstraintViolationImpl<Object>)
            ConstraintViolationImpl.forBeanValidation(
                messageTemplate,
                messageParameters,
                expressionVariables,
                interpolatedMessage,
                rootBeanClass,
                rootBean,
                leafBeanInstance,
                value,
                propertyPath,
                constraintDescriptor,
                null);

    violationSet.add(constraintViolationImpl1);
    return violationSet;
  }


  private static Stream<Arguments> provideArgumentsForSearchIncidentCommand() {

    List<IncidentView> viewList = new ArrayList<>();

    final SearchIncidentRequestV1 incidentRequestV1 =
        IncidentSearchTestSetup.createSearchIncidentRequestObject();

    IncidentView incidentView = IncidentSearchTestSetup.generateIncidentViewData();
    viewList.add(incidentView);
    List<Sort.Order> sorts = new ArrayList<>();
    SearchSortV1Item searchItem =
            SearchSortV1Item.builder().sortType("asc").sortBy("centreId").build();
    sorts.add(new Sort.Order(Sort.Direction.ASC, searchItem.getSortBy()));
    SearchSortV1Item searchItemV1 =
            SearchSortV1Item.builder().sortBy("uniqueTestTakerId").sortType("desc").build();
    sorts.add(new Sort.Order(Sort.Direction.DESC, searchItemV1.getSortBy()));
    Pageable pageObj =
        PageRequest.of(
            0,
            10,
            Sort.by(sorts));

    return Stream.of(Arguments.of(incidentRequestV1, viewList, pageObj));
  }

  public Set<ConstraintViolation<Object>> getSetforLocationViolationOfEventBody(
      final String interpolatedMessage) {

    Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
    final String messageTemplate = null;
    final String interpolatedHeaderMessage = interpolatedMessage;
    final Class<Object> rootBeanClass = null;
    final Object rootBean = null;
    final Object leafBeanInstance = null;
    final Object value = null;
    final javax.validation.Path propertyPath =
        PathImpl.createPathFromString("unauthorisedToAccessWithSelectedLocation");
    final ConstraintDescriptor<?> constraintDescriptor = null;
    final Map<String, Object> messageParameters = new HashMap<>();
    final Map<String, Object> expressionVariables = new HashMap<>();
    ConstraintViolation<Object> constraintViolationImpl1 =
        (ConstraintViolationImpl<Object>)
            ConstraintViolationImpl.forBeanValidation(
                messageTemplate,
                messageParameters,
                expressionVariables,
                interpolatedHeaderMessage,
                rootBeanClass,
                rootBean,
                leafBeanInstance,
                value,
                propertyPath,
                constraintDescriptor,
                null);

    violationSet.add(constraintViolationImpl1);
    return violationSet;
  }
}
