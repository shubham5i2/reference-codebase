package com.ielts.cmds.ri;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.lpr.common.enums.LocationStatus;
import com.ielts.cmds.lpr.common.enums.LocationTypeCode;
import com.ielts.cmds.lpr.common.enums.PartnerCode;
import com.ielts.cmds.lpr.common.enums.RequestStatus;
import com.ielts.cmds.lpr.common.out.model.LocationNode;
import com.ielts.cmds.lpr.common.out.model.LocationV1;
import com.ielts.cmds.ri.infrastructure.entity.Location;

public class LocationTestSetup {
    public static LocationNode getLocationChanged() {
        UiHeader uiCmdsHeader = new UiHeader();
        uiCmdsHeader.setTransactionId(UUID.fromString("779187f5-38ed-4e86-b311-050ffe394f81"));
        uiCmdsHeader.setEventName("LocationCreated");
        uiCmdsHeader.setCallbackURL("");
        uiCmdsHeader.setConnectionId("ec81310d-03b6-");
        uiCmdsHeader.setCorrelationId(UUID.fromString("413b7690-990f-42ce-ab76-783af084513a"));
        uiCmdsHeader.setEventDateTime(null);

        LocationNode locationNode = new LocationNode();
        locationNode.setPartnerCode(PartnerCode.IDP);
        locationNode.setLocationUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
        locationNode.setParentLocationUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46591"));
        locationNode.setTestCentreNumber("AU240");
        locationNode.setLocationTypeCode(LocationTypeCode.TEST_CENTRE);
        locationNode.setLocationName("IDP Melbourne");
        locationNode.setExternalLocationUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46592"));
        locationNode.setExternalParentLocationUuid(
                UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46521"));
        locationNode.setLocationStatus(LocationStatus.ACTIVE);
        locationNode.setTestCentreAdministratorUuid(
                UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46522"));
        LocalDate approvedDate =
                LocalDate.parse("2020-05-01", DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        locationNode.setApprovedDate(approvedDate);
        locationNode.setEligibleForOfflineTesting(false);
        locationNode.setRequestStatus(RequestStatus.APPROVED);
        locationNode.setTimezoneName("UTC");
        locationNode.setWebsiteURL("https://www.cambridgeassessment.org.uk/");
        return locationNode;
    }

    public static Location getLocationData() {
        LocationNode locationNode = getLocationChanged();
        Location location = new Location();
        location.setLocationUuid(locationNode.getLocationUuid());
        location.setParentLocationUuid(locationNode.getParentLocationUuid());
        location.setLocationStatus(locationNode.getLocationStatus());
        location.setLocationTypeCode(locationNode.getLocationTypeCode());
        location.setPartnerCode(locationNode.getPartnerCode().getValue());
        location.setLocationName(locationNode.getLocationName());
        location.setCreatedDatetime(OffsetDateTime.now());
        location.setUpdatedDatetime(OffsetDateTime.now());
        location.setTestCentreNumber(locationNode.getTestCentreNumber());
        return location;
    }


	public static LocationNode getEventBody() {
		return getLocationChanged();
	}

    public static LocationV1 getLocationV1Data() {
        LocationV1 locationV1 = new LocationV1();
        locationV1.setLocationUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
        locationV1.setParentLocationUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46591"));
       locationV1.setStatus(LocationStatus.ACTIVE);
        locationV1.setLocationTypeCode(LocationTypeCode.TEST_CENTRE);
        locationV1.setPartnerCode(PartnerCode.valueOf("IDP"));
        locationV1.setLocationName("IDP Melbourne");
        locationV1.setTestCentreNumber("AU240");
        return locationV1;
    }
}