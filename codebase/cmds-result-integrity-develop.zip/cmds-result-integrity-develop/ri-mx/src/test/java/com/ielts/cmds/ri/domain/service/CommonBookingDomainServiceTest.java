package com.ielts.cmds.ri.domain.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ielts.cmds.api.evt_019.BookingDetailsV1;
import com.ielts.cmds.api.evt_019.TestTakerDetailsV1;
import com.ielts.cmds.infrastructure.event.context.CMDSAuditContext;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.BookingLine;
import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatusType;
import com.ielts.cmds.ri.infrastructure.repository.BookingLineRepository;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.UniqueTestTakerRepository;
import com.ielts.cmds.ri.utils.BookingDetailsEvent;
import com.ielts.cmds.ri.utils.IntegrityCheckEvent;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.ri.utils.RIUtil;

@ExtendWith(SpringExtension.class)
class CommonBookingDomainServiceTest {

	@InjectMocks
	@Spy
	private CommonBookingDomainService abstractBookingDomainService;
	@Mock
	private BookingRepository bookingRepository;
	@Mock
	private BookingLineRepository bookingLineRepository;
	@Mock
	private UniqueTestTakerRepository uniqueTestTakerRepository;
	@Mock
	private OutcomeStatusRepository outcomeStatusRepository;
	@Mock
	private OutcomeStatusTypeRepository outcomeStatusTypeRepository;

	private CMDSHeaderContext cmdsHeaderContext;
	@Mock
	private BookingUpdateIdCheckOutcomeDomainService bookingUpdateIdCheckOutcomeDomainService;
	@Mock
	private CheckOutcomeTypeRepository checkOutcomeTypeRepository;
	@Mock
	private TTUpdateDomainService ttUpdateDomainService;

	@BeforeEach
	void init() {
		cmdsHeaderContext = RIUtil.createCMDSHeaderContextByEventName(RIConstants.EventType.BOOKING_CANCELLED_EVENT);
		ThreadLocalHeaderContext.setContext(cmdsHeaderContext);
		ThreadLocalAuditContext.setContext(new CMDSAuditContext());
	}

	@Test
	void processTest() {
		BookingDetailsV1 bookingDetails = BookingDetailsEvent.getBookingDetailsBody();
		Booking booking = BookingDetailsEvent.setBookingForTest();
		booking.setBookingStatus("PAID");
		booking.setBookingVersion(BigDecimal.valueOf(4));
		doReturn(booking).when(bookingRepository).save(any());
		doNothing().when(abstractBookingDomainService).publishEvent(ArgumentMatchers.any());
		when(uniqueTestTakerRepository.findByUniqueTestTakerUuid(ArgumentMatchers.any(UUID.class)))
				.thenReturn(Optional.of(BookingDetailsEvent.getUniqueTestTaker()));
		when(uniqueTestTakerRepository.save(ArgumentMatchers.any()))
				.thenReturn(BookingDetailsEvent.getUniqueTestTaker());
		OutcomeStatusType outcomeStatusType = new OutcomeStatusType();
		when(outcomeStatusTypeRepository
				.findByOutcomeStatusTypeCode(RIConstants.PrcOutcomeConstant.OUTCOME_STATUS_TYPE_CODE_NOT_STARTED))
				.thenReturn(Optional.of(outcomeStatusType));
		doReturn(Optional.of(booking)).when(bookingRepository).findById(bookingDetails.getBookingUuid());

		Assertions.assertDoesNotThrow(() -> abstractBookingDomainService.process(bookingDetails));
	}
	
	@Test
	void processTestNoUniqueTestTakerId() {
		TestTakerDetailsV1 testTaker = new TestTakerDetailsV1();
		testTaker.setUniqueTestTakerId(null);
		BookingDetailsV1 bookingDetails = BookingDetailsEvent.getBookingDetailsBody();
		bookingDetails.setTestTaker(testTaker);
		Booking booking = BookingDetailsEvent.setBookingForTest();
		doReturn(booking).when(bookingRepository).save(any());
		final Executable executable = () -> abstractBookingDomainService.process(bookingDetails);

		Assertions.assertDoesNotThrow(executable);
	}
	
	@Test
	void processTestWithOptionalOutcome() {
		BookingDetailsV1 bookingDetails = BookingDetailsEvent.getBookingDetailsBody();
		Booking booking = BookingDetailsEvent.setBookingForTest();
		booking.setBookingStatus("PAID");
		booking.setBookingVersion(BigDecimal.valueOf(4));
		doReturn(booking).when(bookingRepository).save(any());
		OutcomeStatus outcomeStatus = new OutcomeStatus();

		when(outcomeStatusRepository.findByBookingUuid(ArgumentMatchers.any())).thenReturn(Optional.of(outcomeStatus));
		doNothing().when(abstractBookingDomainService).publishEvent(ArgumentMatchers.any());
		when(uniqueTestTakerRepository.findByUniqueTestTakerUuid(ArgumentMatchers.any(UUID.class)))
				.thenReturn(Optional.of(BookingDetailsEvent.getUniqueTestTaker()));
		when(uniqueTestTakerRepository.save(ArgumentMatchers.any()))
				.thenReturn(BookingDetailsEvent.getUniqueTestTaker());
		OutcomeStatusType outcomeStatusType = new OutcomeStatusType();
		when(outcomeStatusTypeRepository
				.findByOutcomeStatusTypeCode(RIConstants.PrcOutcomeConstant.OUTCOME_STATUS_TYPE_CODE_NOT_STARTED))
				.thenReturn(Optional.of(outcomeStatusType));
		doReturn(Optional.of(booking)).when(bookingRepository).findById(bookingDetails.getBookingUuid());
		Assertions.assertDoesNotThrow(() -> abstractBookingDomainService.process(bookingDetails));
	}
	
	@Test
	void processTestWithoutOptionalOutcome() {
		BookingDetailsV1 bookingDetails = BookingDetailsEvent.getBookingDetailsBody();
		Booking booking = BookingDetailsEvent.setBookingForTest();
		booking.setBookingStatus("PAID");
		booking.setBookingVersion(BigDecimal.valueOf(2));
		doReturn(booking).when(bookingRepository).save(any());
		when(outcomeStatusRepository.findByBookingUuid(ArgumentMatchers.any())).thenReturn(Optional.empty());
		doNothing().when(abstractBookingDomainService).publishEvent(ArgumentMatchers.any());
		when(uniqueTestTakerRepository.findByUniqueTestTakerUuid(ArgumentMatchers.any(UUID.class)))
				.thenReturn(Optional.of(BookingDetailsEvent.getUniqueTestTaker()));
		when(uniqueTestTakerRepository.save(ArgumentMatchers.any()))
				.thenReturn(BookingDetailsEvent.getUniqueTestTaker());
		when(outcomeStatusTypeRepository
				.findByOutcomeStatusTypeCode(RIConstants.PrcOutcomeConstant.OUTCOME_STATUS_TYPE_CODE_NOT_STARTED))
				.thenReturn(Optional.empty());
		doReturn(Optional.of(booking)).when(bookingRepository).findById(bookingDetails.getBookingUuid());
		
		Assertions.assertThrows(ResultIntegrityException.class, () -> abstractBookingDomainService.process(bookingDetails));
	}
	
	@Test
	void processTestInvalidBooking() {
		BookingDetailsV1 bookingDetails = BookingDetailsEvent.getBookingDetailsBody();
		bookingDetails.getBookingLines().get(0).setStartDateTime(null);
		Booking booking = BookingDetailsEvent.setBookingForTest();
		booking.setBookingStatus("PAID");
		booking.setBookingVersion(BigDecimal.valueOf(4));
		booking.setEventDatetime(LocalDateTime.now(ZoneOffset.UTC).plusMonths(3));
		doReturn(booking).when(bookingRepository).save(any());
		doReturn(Optional.of(booking)).when(bookingRepository).findById(bookingDetails.getBookingUuid());
		doNothing().when(abstractBookingDomainService).publishEvent(any(),any());
		Assertions.assertDoesNotThrow(() -> abstractBookingDomainService.process(bookingDetails));
	}
	
	@Test
	void processTestNoBooking() {
		BookingDetailsV1 bookingDetails = BookingDetailsEvent.getBookingDetailsBody();
		bookingDetails.setBookingLines(null);
		bookingDetails.setLinkedBookings(null);
		Booking booking = BookingDetailsEvent.setBookingForTest();
		doReturn(booking).when(bookingRepository).save(any());
		doReturn(Optional.empty()).when(bookingRepository).findById(bookingDetails.getBookingUuid());
		when(uniqueTestTakerRepository.save(ArgumentMatchers.any()))
		.thenReturn(BookingDetailsEvent.getUniqueTestTaker());
		OutcomeStatus outcomeStatus = new OutcomeStatus();
		when(outcomeStatusRepository.findByBookingUuid(ArgumentMatchers.any())).thenReturn(Optional.of(outcomeStatus));
		doNothing().when(abstractBookingDomainService).publishEvent(any());
		Assertions.assertDoesNotThrow(() -> abstractBookingDomainService.process(bookingDetails));
	}
	
	@Test
	void processTestNoBookingWithBookingLine() {
		BookingDetailsV1 bookingDetails = BookingDetailsEvent.getBookingDetailsBody();
		Booking booking = BookingDetailsEvent.setBookingForTest();
		doReturn(booking).when(bookingRepository).save(any());
		doReturn(Optional.empty()).when(bookingRepository).findById(bookingDetails.getBookingUuid());
		when(uniqueTestTakerRepository.save(ArgumentMatchers.any()))
		.thenReturn(BookingDetailsEvent.getUniqueTestTaker());
		OutcomeStatus outcomeStatus = new OutcomeStatus();
		BookingLine bookingLine = new BookingLine();
		when(bookingLineRepository.findById(ArgumentMatchers.any(UUID.class))).thenReturn(Optional.of(bookingLine));
		when(outcomeStatusRepository.findByBookingUuid(ArgumentMatchers.any())).thenReturn(Optional.of(outcomeStatus));
		doNothing().when(abstractBookingDomainService).publishEvent(any());
		Assertions.assertDoesNotThrow(() -> abstractBookingDomainService.process(bookingDetails));
	}

	@Test
	void processTest_When_receivedBookingVersionIs_High() {
		BookingDetailsV1 bookingDetails = BookingDetailsEvent.getBookingDetailsBody();
		Booking booking = BookingDetailsEvent.setBookingForTest();
		booking.setBookingStatus("PAID");
		booking.setBookingVersion(BigDecimal.valueOf(2));
		doReturn(booking).when(bookingRepository).save(any());
		doNothing().when(abstractBookingDomainService).publishEvent(ArgumentMatchers.any());
		when(uniqueTestTakerRepository.findByUniqueTestTakerUuid(ArgumentMatchers.any(UUID.class)))
				.thenReturn(Optional.of(BookingDetailsEvent.getUniqueTestTaker()));
		when(uniqueTestTakerRepository.save(ArgumentMatchers.any()))
				.thenReturn(BookingDetailsEvent.getUniqueTestTaker());
		OutcomeStatusType outcomeStatusType = new OutcomeStatusType();
		when(outcomeStatusTypeRepository
				.findByOutcomeStatusTypeCode(RIConstants.PrcOutcomeConstant.OUTCOME_STATUS_TYPE_CODE_NOT_STARTED))
				.thenReturn(Optional.of(outcomeStatusType));
		doReturn(Optional.of(booking)).when(bookingRepository).findById(bookingDetails.getBookingUuid());
		when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode("PRC_INC_CHK")).
				thenReturn(Optional.of(IntegrityCheckEvent.getPRCCheckOutcomeType()));
		Assertions.assertDoesNotThrow(() -> abstractBookingDomainService.process(bookingDetails));
	}


	@Test
	void processTestNotForEventBookingCancelled() {
		BookingDetailsV1 bookingDetails = BookingDetailsEvent.getBookingDetailsBody();
		ThreadLocalHeaderContext.clearContext();
		cmdsHeaderContext = RIUtil.createCMDSHeaderContextByEventName(RIConstants.EventType.BOOKING_UPDATED_EVENT);
		ThreadLocalHeaderContext.setContext(cmdsHeaderContext);
		ThreadLocalAuditContext.setContext(new CMDSAuditContext());
		Booking booking = BookingDetailsEvent.setBookingForTest();
		booking.setBookingStatus("PAID");
		booking.setBookingVersion(BigDecimal.valueOf(2));
		doReturn(booking).when(bookingRepository).save(any());
		doNothing().when(abstractBookingDomainService).publishEvent(ArgumentMatchers.any());
		when(uniqueTestTakerRepository.findByUniqueTestTakerUuid(ArgumentMatchers.any(UUID.class)))
				.thenReturn(Optional.of(BookingDetailsEvent.getUniqueTestTaker()));
		when(uniqueTestTakerRepository.save(ArgumentMatchers.any()))
				.thenReturn(BookingDetailsEvent.getUniqueTestTaker());
		OutcomeStatusType outcomeStatusType = new OutcomeStatusType();
		when(outcomeStatusTypeRepository
				.findByOutcomeStatusTypeCode(RIConstants.PrcOutcomeConstant.OUTCOME_STATUS_TYPE_CODE_NOT_STARTED))
				.thenReturn(Optional.of(outcomeStatusType));
		doReturn(Optional.of(booking)).when(bookingRepository).findById(bookingDetails.getBookingUuid());

		Assertions.assertDoesNotThrow(() -> abstractBookingDomainService.process(bookingDetails));
	}

  @Test
  void process_ShouldNotRaiseNPE_WhenBookingVersionIsNull() {
    BookingDetailsV1 bookingDetails = BookingDetailsEvent.getBookingDetailsBody();
    bookingDetails.setBookingVersion(BigDecimal.valueOf(1));
    Booking booking = BookingDetailsEvent.setBookingForTest();
    booking.setBookingStatus("PAID");
    booking.setBookingVersion(null);
    doReturn(booking).when(bookingRepository).save(any());
    doNothing().when(abstractBookingDomainService).publishEvent(ArgumentMatchers.any());
    when(uniqueTestTakerRepository.findByUniqueTestTakerUuid(ArgumentMatchers.any(UUID.class)))
        .thenReturn(Optional.of(BookingDetailsEvent.getUniqueTestTaker()));
    when(uniqueTestTakerRepository.save(ArgumentMatchers.any()))
        .thenReturn(BookingDetailsEvent.getUniqueTestTaker());
    OutcomeStatusType outcomeStatusType = new OutcomeStatusType();
    when(outcomeStatusTypeRepository.findByOutcomeStatusTypeCode(
            RIConstants.PrcOutcomeConstant.OUTCOME_STATUS_TYPE_CODE_NOT_STARTED))
        .thenReturn(Optional.of(outcomeStatusType));
    doReturn(Optional.of(booking))
        .when(bookingRepository)
        .findById(bookingDetails.getBookingUuid());
    when(outcomeStatusRepository.findByBookingUuid(ArgumentMatchers.any())).thenReturn(Optional.of(new OutcomeStatus()));
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode("PRC_INC_CHK"))
        .thenReturn(Optional.of(IntegrityCheckEvent.getPRCCheckOutcomeType()));
    Assertions.assertDoesNotThrow(() -> abstractBookingDomainService.process(bookingDetails));
  }

  @Test
  void process_ShouldNotRaiseNPE_WhenBookingVersionsAreNull() {
    BookingDetailsV1 bookingDetails = BookingDetailsEvent.getBookingDetailsBody();
    bookingDetails.setBookingVersion(null);
    Booking booking = BookingDetailsEvent.setBookingForTest();
    booking.setBookingStatus("PAID");
    booking.setBookingVersion(null);
    doReturn(booking).when(bookingRepository).save(any());
    doNothing().when(abstractBookingDomainService).publishEvent(ArgumentMatchers.any());
    when(uniqueTestTakerRepository.findByUniqueTestTakerUuid(ArgumentMatchers.any(UUID.class)))
        .thenReturn(Optional.of(BookingDetailsEvent.getUniqueTestTaker()));
    when(uniqueTestTakerRepository.save(ArgumentMatchers.any()))
        .thenReturn(BookingDetailsEvent.getUniqueTestTaker());
    OutcomeStatusType outcomeStatusType = new OutcomeStatusType();
    when(outcomeStatusTypeRepository.findByOutcomeStatusTypeCode(
            RIConstants.PrcOutcomeConstant.OUTCOME_STATUS_TYPE_CODE_NOT_STARTED))
        .thenReturn(Optional.of(outcomeStatusType));
    doReturn(Optional.of(booking))
        .when(bookingRepository)
        .findById(bookingDetails.getBookingUuid());
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode("PRC_INC_CHK"))
        .thenReturn(Optional.of(IntegrityCheckEvent.getPRCCheckOutcomeType()));
    Assertions.assertDoesNotThrow(() -> abstractBookingDomainService.process(bookingDetails));
  }
}
