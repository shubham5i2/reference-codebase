package com.ielts.cmds.ri.application.service;

import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.UUID;

import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.ors.common.out.model.IncidentV1;
import com.ielts.cmds.ri.domain.service.SpeakingIdCheckOutcomeDomainService;
import com.ielts.cmds.ri.domain.service.SpeakingIncidentCheckOutcomeDomainService;
import com.ielts.cmds.ri.utils.SpeakingIdAndIncidentCheckOutcomeEvent;

@ExtendWith(SpringExtension.class)
class SpeakingIdAndIncidentServiceTest {

	@InjectMocks
	SpeakingIdAndIncidentService idAndIncidentServiceV2;
	
	@Mock
	SpeakingIdCheckOutcomeDomainService speakingIdCheckOutcomeDomainService;

	@Mock
	SpeakingIncidentCheckOutcomeDomainService speakingIncidentCheckOutcomeDomainService;
	
	@Test
	void testProcessWithoutExternalIncidentId() {
		CMDSHeaderContext ctx = new CMDSHeaderContext();
		ctx.setCorrelationId(UUID.randomUUID());
		ThreadLocalHeaderContext.setContext(ctx);
		IncidentV1 incidentV1 = SpeakingIdAndIncidentCheckOutcomeEvent.getSpeakingIdCheckOutcomeNode();
		incidentV1.getIncidentDetails().setExternalIncidentId(null);
		idAndIncidentServiceV2.process(incidentV1);
		
		verify(speakingIdCheckOutcomeDomainService, times(1)).on(incidentV1);
	}
	
	@Test
	void testProcessWithExternalIncidentId() {
		CMDSHeaderContext ctx = new CMDSHeaderContext();
		ctx.setCorrelationId(UUID.randomUUID());
		ThreadLocalHeaderContext.setContext(ctx);
		IncidentV1 incidentV1 = SpeakingIdAndIncidentCheckOutcomeEvent.getSpeakingIdCheckOutcomeNode();
		idAndIncidentServiceV2.process(incidentV1);
		
		verify(speakingIncidentCheckOutcomeDomainService, times(1)).on(incidentV1);
	}
	
	@Test
	void testProcessWithException() {
		CMDSHeaderContext ctx = new CMDSHeaderContext();
		ctx.setCorrelationId(UUID.randomUUID());
		ThreadLocalHeaderContext.setContext(ctx);
		
		assertThrows(ProcessingException.class, () -> idAndIncidentServiceV2.process(null));
	}
	
}
