package com.ielts.cmds.ri.domain.service;

import static com.ielts.cmds.ri.utils.RIConstants.PermissionId.RI_ID_CHECK_UPDATE;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import javax.validation.ConstraintViolation;
import javax.validation.metadata.ConstraintDescriptor;

import org.hibernate.validator.internal.engine.ConstraintViolationImpl;
import org.hibernate.validator.internal.engine.path.PathImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.rbac.api.service.RBACService;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.ri.application.exception.ResultIntegrityValidationException;
import com.ielts.cmds.ri.common.model.out.IdCheckOutcomeReceivedDetailsV1;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.utils.IdCheckOutcomeReceivedEvent;
import com.ielts.cmds.ri.utils.RICommonUtil;

/**
 * The type Id check outcome received domain service test.
 */
@ExtendWith(MockitoExtension.class)
class IdCheckOutcomeReceivedDomainServiceTest {

	/**
	 * The Id check outcome received domain service.
	 */
	@InjectMocks
	@Spy
	IdCheckOutcomeReceivedDomainService idCheckOutcomeReceivedDomainService;

	@Mock
	private CheckOutcomeTypeRepository checkOutcomeTypeRepository;

	/**
	 * The Check outcome repository.
	 */
	@Mock
	CheckOutcomeRepository checkOutcomeRepository;

	private IdCheckOutcomeReceivedDetailsV1 requestV1;

	/**
	 * The Common utils.
	 */
	@Mock
	RICommonUtil commonUtils;

	@Mock
	private CMDSErrorResolver<Object> errorResolver;

	/**
	 * The Violations.
	 */
	@Mock
	Set<ConstraintViolation<Object>> violations;

	@Mock
	private RBACService rbacService;

	/**
	 * The Check outcome status repository.
	 */
	@Mock
	CheckOutcomeStatusRepository checkOutcomeStatusRepository;

	@Mock
	OutcomeStatusRepository outcomeStatusRepository;

	/**
	 * Sets up.
	 */
	@BeforeEach
	void setUp() {
		requestV1 = IdCheckOutcomeReceivedEvent.createIdCheckOutcomeReceivedObject();
		CMDSHeaderContext header = IdCheckOutcomeReceivedEvent.generateEventHeader();
		ThreadLocalHeaderContext.setContext(header);
	}

	/**
	 * Test when command is received save and publish event.
	 *
	 * @throws RbacValidationException the rbac validation exception
	 * @throws JsonProcessingException the json processing exception
	 */
	@Test
	void testWhenCommandIsReceived_SaveAndPublishEvent() throws RbacValidationException, JsonProcessingException {

		when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode("LRW_ID_INC_CHK"))
				.thenReturn(Optional.of(IdCheckOutcomeReceivedEvent.getCheckOutcomeType()));

		idCheckOutcomeReceivedDomainService.getCheckOutcome(UUID.fromString("0d9dbdd5-f1e6-4753-b7a9-573a898cd11c"),
				IdCheckOutcomeReceivedEvent.getCheckOutcomeType());

		when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
				UUID.fromString("0d9dbdd5-f1e6-4753-b7a9-573a898cd11c"),
				IdCheckOutcomeReceivedEvent.getCheckOutcomeType().getCheckOutcomeTypeUuid()))
						.thenReturn(Optional.of(IdCheckOutcomeReceivedEvent.getCheckOutcome()));

		when(checkOutcomeStatusRepository.findByCheckOutcomeStatusUuid(any()))
				.thenReturn(Optional.of(IdCheckOutcomeReceivedEvent.getCheckOutcomeStatus()));

		when(commonUtils.hasAllAccess("", RI_ID_CHECK_UPDATE)).thenReturn(true);
		when(checkOutcomeRepository.save(any())).thenReturn(IdCheckOutcomeReceivedEvent.getCheckOutcome());
		doNothing().when(idCheckOutcomeReceivedDomainService).publishEvent(any());
		idCheckOutcomeReceivedDomainService.on(requestV1);

		Mockito.verify(commonUtils).hasAllAccess("", RI_ID_CHECK_UPDATE);
	}

	@Test
	void testWhenCommandIsReceived_ThrowException_whenCheckOutcomeStatus_isNotValid()
			throws RbacValidationException, JsonProcessingException {

		when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode("LRW_ID_INC_CHK"))
				.thenReturn(Optional.of(IdCheckOutcomeReceivedEvent.getCheckOutcomeType()));

		when(checkOutcomeStatusRepository.findByCheckOutcomeStatusUuid(any()))
				.thenReturn(Optional.of(IdCheckOutcomeReceivedEvent.getCheckOutcomeStatus()));

		when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
				UUID.fromString("0d9dbdd5-f1e6-4753-b7a9-573a898cd11c"),
				IdCheckOutcomeReceivedEvent.getCheckOutcomeType().getCheckOutcomeTypeUuid()))
						.thenReturn(Optional.of(IdCheckOutcomeReceivedEvent.getCheckOutcome()));
		when(commonUtils.hasAllAccess("", RI_ID_CHECK_UPDATE)).thenReturn(true);
		doNothing().when(idCheckOutcomeReceivedDomainService).publishEvent(any());

		idCheckOutcomeReceivedDomainService.on(requestV1);
		Mockito.verify(commonUtils).hasAllAccess("", RI_ID_CHECK_UPDATE);
	}

	/**
	 * Test when command is received with no access save and publish event.
	 *
	 * @throws RbacValidationException the rbac validation exception
	 * @throws JsonProcessingException the json processing exception
	 */
	@Test
	void testWhenCommandIsReceived_WithNoAccess_SaveAndPublishEvent()
			throws RbacValidationException, JsonProcessingException {
		when(commonUtils.hasAllAccess("", RI_ID_CHECK_UPDATE)).thenReturn(false);

		Set<ConstraintViolation<Object>> constraintViolation = getSetForViolationOfEventBody(
				"V_unauthorised_to_update_id_verification_status");
		when(errorResolver.populatErrorResponse(constraintViolation, "PUT/v1/incident/submitidcheckoutcome"))
				.thenReturn(new CMDSErrorResponse());
		doNothing().when(idCheckOutcomeReceivedDomainService).publishEvent(any(), any());
		idCheckOutcomeReceivedDomainService.on(requestV1);
		Mockito.verify(commonUtils).hasAllAccess("", RI_ID_CHECK_UPDATE);
	}

	/**
	 * Test when command is received with no booking then throw exception.
	 *
	 * @throws RbacValidationException the rbac validation exception
	 */
	@Test
	void testWhenCommandIsReceived_WithNoCheckOutcomeType_Then_ThrowException()
			throws RbacValidationException, ResultIntegrityValidationException {
		when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(any())).thenReturn(Optional.empty());

		ResultIntegrityValidationException thrownEx = assertThrows(ResultIntegrityValidationException.class, () -> {
			idCheckOutcomeReceivedDomainService.getIdCheckOutComeType();
		});
		// then
		assertNotNull(thrownEx);
		assertNotNull(thrownEx.getMessage());

	}

	/**
	 * Test when command is received insert new check outcome save and publish
	 * event.
	 *
	 * @throws RbacValidationException the rbac validation exception
	 * @throws JsonProcessingException the json processing exception
	 */
	@Test
	void testWhenCommandIsReceived_InsertNewCheckOutcome_SaveAndPublishEvent()
			throws RbacValidationException, JsonProcessingException {
		when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode("LRW_ID_INC_CHK"))
				.thenReturn(Optional.of(IdCheckOutcomeReceivedEvent.getCheckOutcomeType()));

		idCheckOutcomeReceivedDomainService.getCheckOutcome(UUID.fromString("0d9dbdd5-f1e6-4753-b7a9-573a898cd11c"),
				IdCheckOutcomeReceivedEvent.getCheckOutcomeType());

		when(checkOutcomeStatusRepository.findByCheckOutcomeStatusUuid(any()))
				.thenReturn(Optional.of(IdCheckOutcomeReceivedEvent.getCheckOutcomeStatus()));

		when(commonUtils.hasAllAccess("", RI_ID_CHECK_UPDATE)).thenReturn(true);
		when(checkOutcomeRepository.save(any())).thenReturn(IdCheckOutcomeReceivedEvent.getCheckOutcome());
		doNothing().when(idCheckOutcomeReceivedDomainService).publishEvent(any());
		idCheckOutcomeReceivedDomainService.on(requestV1);
		Mockito.verify(commonUtils).hasAllAccess("", RI_ID_CHECK_UPDATE);

	}

	/**
	 * Gets set for violation of event body.
	 *
	 * @param interpolatedMessage the interpolated message
	 * @return the set for violation of event body
	 */
	public Set<ConstraintViolation<Object>> getSetForViolationOfEventBody(final String interpolatedMessage) {

		Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
		final String messageTemplate = null;
		final Class<Object> rootBeanClass = null;
		final Object rootBean = null;
		final Object leafBeanInstance = null;
		final Object value = null;
		final javax.validation.Path propertyPath = PathImpl
				.createPathFromString("unauthorisedToUpdateIDVerificationStatus");
		final ConstraintDescriptor<?> constraintDescriptor = null;
		final Map<String, Object> messageParameters = new HashMap<>();
		final Map<String, Object> expressionVariables = new HashMap<>();
		ConstraintViolation<Object> constraintViolationImpl1 = (ConstraintViolationImpl<Object>) ConstraintViolationImpl
				.forBeanValidation(messageTemplate, messageParameters, expressionVariables, interpolatedMessage,
						rootBeanClass, rootBean, leafBeanInstance, value, propertyPath, constraintDescriptor, null);

		violationSet.add(constraintViolationImpl1);
		return violationSet;
	}
}
