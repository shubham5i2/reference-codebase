package com.ielts.cmds.ri.application.service;

import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.common.model.out.PrcOutcomeV1;
import com.ielts.cmds.ri.domain.service.PrcOutcomeReceivedDomainService;
import com.ielts.cmds.ri.utils.PrcOutcomeReceivedEvent;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PrcOutcomeReceivedServiceTest {

    @InjectMocks
    private PrcOutcomeReceivedService prcOutcomeReceivedService;

    @Mock
    private PrcOutcomeReceivedDomainService prcOutcomeReceivedDomainService;

    @Test
    void PrcOutcomeRequest_DelegateRequestToLocationDomainService_DoNotThrowException() {
        PrcOutcomeV1 prcOutcomeReceived = PrcOutcomeReceivedEvent.getPrcOutcomeReceivedNode();
        final Executable executable = () -> prcOutcomeReceivedService.process(prcOutcomeReceived);
        assertDoesNotThrow(executable);
        verify(prcOutcomeReceivedDomainService, times(1)).on(prcOutcomeReceived);
    }

    @Test
    void PrcOutcomeRequest_DelegateRequestToLocationDomainService_DoThrowException() {
        CMDSHeaderContext header = new CMDSHeaderContext();
        header.setCorrelationId(UUID.randomUUID());
        ThreadLocalHeaderContext.setContext(header);
        PrcOutcomeV1 prcOutcomeReceived = PrcOutcomeReceivedEvent.getPrcOutcomeReceivedNode();
        doThrow(IllegalArgumentException.class).when(prcOutcomeReceivedDomainService).on(prcOutcomeReceived);
        prcOutcomeReceivedService.process(prcOutcomeReceived);
        verify(prcOutcomeReceivedDomainService, times(1)).publishUiEvent(any(),any(),any());
    }

}
