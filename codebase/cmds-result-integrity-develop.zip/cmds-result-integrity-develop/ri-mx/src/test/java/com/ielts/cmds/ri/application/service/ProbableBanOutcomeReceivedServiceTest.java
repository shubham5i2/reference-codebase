package com.ielts.cmds.ri.application.service;

import com.ielts.cmds.api.evt113.ProbableBanCheckOutcomeV1;
import com.ielts.cmds.ri.domain.service.ProbableBanOutcomeReceivedDomainService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class ProbableBanOutcomeReceivedServiceTest {

  @InjectMocks
  ProbableBanOutcomeReceivedService probableBanOutcomeReceivedService;

  @Mock
  ProbableBanOutcomeReceivedDomainService probableBanOutcomeReceivedDomainService;

  @Test
  void testProcess() {
    ProbableBanCheckOutcomeV1 probableBanCheckOutcomeV1 = new ProbableBanCheckOutcomeV1();
    probableBanOutcomeReceivedService.process(probableBanCheckOutcomeV1);
    verify(probableBanOutcomeReceivedDomainService, times(1)).on(probableBanCheckOutcomeV1);
  }
}
