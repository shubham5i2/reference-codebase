package com.ielts.cmds.ri.domain.service;

import static com.ielts.cmds.ri.utils.RIConstants.PermissionId.RI_ID_CHECK_VIEW;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import javax.validation.ConstraintViolation;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.outbox.event.OutboxEventBuilder;
import com.ielts.cmds.rbac.api.service.RBACService;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.api.service.model.LocationNode;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.PhotoTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.TestTakerPhotoRepository;
import com.ielts.cmds.ri.utils.GenerateS3SignedUrl;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.ri.utils.ViewIdPhotosTestSetup;


/**
 * The type View id photos domain service test.
 */
@ExtendWith(MockitoExtension.class)
class ViewIdPhotosDomainServiceTest {


  /** The View Id Photos domain service. */
  @Spy
  @InjectMocks
  ViewIdPhotosDomainService viewIdPhotosDomainService;

  /**
   * The Outbox event builder.
   */
  @Mock
  OutboxEventBuilder outboxEventBuilder;

  /**
   * The Booking repository.
   */
  @Mock
  BookingRepository bookingRepository;

  /**
   * The Check outcome repository.
   */
  @Mock
  CheckOutcomeRepository checkOutcomeRepository;

  /**
   * The Check outcome type repository.
   */
  @Mock
  CheckOutcomeTypeRepository checkOutcomeTypeRepository;

  /**
   * The Test taker photo repository.
   */
  @Mock
  TestTakerPhotoRepository testTakerPhotoRepository;

  /**
   * The Photo type repository.
   */
  @Mock
  PhotoTypeRepository photoTypeRepository;

  @Mock
  private GenerateS3SignedUrl generateS3SignedUrl;

  @Mock
  private ApplicationEventPublisher applicationEventPublisher;

  /**
   * The Common utils.
   */
  @Mock
  RICommonUtil commonUtils;

  @Mock
  private CMDSErrorResolver<Object> errorResolver;

  /** The Violations. */
  @Mock
  Set<ConstraintViolation<Object>> violations;

  @Mock
  private RBACService rbacService;

  @Spy
  private LocationNode locationNode;


  /**
   * Init.
   */
  @BeforeEach
  void init() {
    CMDSHeaderContext header = ViewIdPhotosTestSetup.generateEventHeader();
    header.setEventName("GET/v1/incident/getidphotos/{bookingUuid}");
    header.setPartnerCode("BC");
    Map<String, String> eventContext = new HashMap<>();
    eventContext.put("bookingUuid", "71dda922-d851-419b-8fc8-467f4121bd5d");
    header.setEventContext(eventContext);
    ThreadLocalHeaderContext.setContext(header);
  }


  /**
   * When view id photos event is received with invalid access then publish to outbound topic.
   *
   * @throws RbacValidationException the rbac validation exception
   * @throws JsonProcessingException the json processing exception
   */
  @Test
  void whenViewIdPhotosEventIsReceived_WithInvalidAccess_ThenPublishToOutboundTopic()
      throws RbacValidationException, JsonProcessingException {

    when(commonUtils.hasAllAccess("", RI_ID_CHECK_VIEW)).thenReturn(false);
    Set<ConstraintViolation<Object>> constraintViolation =
        ViewIdPhotosTestSetup.setForNullViolationOfEventBody("V_unauthorised_to_view_id_verification_status");
    when(errorResolver.populatErrorResponse
        (constraintViolation, "IdPhotosResponseGenerated"))
        .thenReturn(new CMDSErrorResponse());
    doNothing().when(viewIdPhotosDomainService).publishEvent(any(),any());
    viewIdPhotosDomainService.on();

    verify(commonUtils).hasAllAccess("", RI_ID_CHECK_VIEW);
  }

  /**
   * When object is null with valid access then publish to outbound topic.
   *
   * @throws RbacValidationException the rbac validation exception
   */
  @Test
  void whenObjectIsNull_WithValidAccess_ThenPublishToOutboundTopic()
      throws RbacValidationException {

    when(commonUtils.hasAllAccess("", RI_ID_CHECK_VIEW)).thenReturn(true);
    doNothing().when(viewIdPhotosDomainService).publishEvent(any(),any());
    final Executable executable = () -> viewIdPhotosDomainService.on();
    assertDoesNotThrow(executable);
  }


  /**
   * Test generate id photos response data.
   */
  @Test
  void testGenerateIdPhotosResponseData() throws RbacValidationException {

    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode("LRW_ID_INC_CHK"))
        .thenReturn(Optional.of(ViewIdPhotosTestSetup.setCheckOutcomeType()));

    when(checkOutcomeRepository
        .findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid
            (UUID.fromString("71dda922-d851-419b-8fc8-467f4121bd5d")
                , ViewIdPhotosTestSetup.setCheckOutcomeType().getCheckOutcomeTypeUuid()))
        .thenReturn(Optional.of(ViewIdPhotosTestSetup.setCheckOutCome()));

    when(testTakerPhotoRepository
        .findByBookingUuid(UUID.fromString("71dda922-d851-419b-8fc8-467f4121bd5d")))
        .thenReturn(ViewIdPhotosTestSetup.setTestTakerPhotoList());

    when(commonUtils.getPhotoTypeConstantsList())
        .thenCallRealMethod();

    when(photoTypeRepository.findAll())
        .thenReturn(ViewIdPhotosTestSetup.setPhotoTypeIterable());

    doReturn(locationNode).when(commonUtils).getParentNode(any(),any());

    viewIdPhotosDomainService
        .generateIdPhotosResponseData(ViewIdPhotosTestSetup.setBookingForTest());

    verify(viewIdPhotosDomainService)
        .setPhotos(UUID.fromString("71dda922-d851-419b-8fc8-467f4121bd5d"));
    verify(viewIdPhotosDomainService)
        .getCheckOutcomeStatusUuid(UUID.fromString("71dda922-d851-419b-8fc8-467f4121bd5d"));
    verify(viewIdPhotosDomainService)
        .getCheckOutComeType();

  }

  /**
   * Test get check outcome status uuid.
   */
  @Test
  void testGetCheckOutcomeStatusUuid() {

    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode("LRW_ID_INC_CHK"))
        .thenReturn(Optional.of(ViewIdPhotosTestSetup.setCheckOutcomeType()));

    doReturn(null).when(viewIdPhotosDomainService)
        .getCheckOutcome(UUID.fromString("71dda922-d851-419b-8fc8-467f4121bd5d")
            , ViewIdPhotosTestSetup.setCheckOutcomeType());

    final Executable executable =
        () ->
            viewIdPhotosDomainService.getCheckOutcomeStatusUuid
                (UUID.fromString("71dda922-d851-419b-8fc8-467f4121bd5d"));

    assertDoesNotThrow(executable);
  }


}


