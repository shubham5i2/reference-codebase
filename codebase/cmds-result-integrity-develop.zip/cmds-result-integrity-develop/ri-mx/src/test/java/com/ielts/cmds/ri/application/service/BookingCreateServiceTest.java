package com.ielts.cmds.ri.application.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.ielts.cmds.api.evt_019.BookingChangedEventV1;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.ri.domain.service.BookingCreatedDomainService;

@ExtendWith(MockitoExtension.class)
class BookingCreateServiceTest {

    @InjectMocks
    BookingCreateService bookingCreateService;

    @Mock
    BookingCreatedDomainService bookingCreatedDomainService;

    @Test
    void whenProcessCalledShouldThrowException() {
    	CMDSHeaderContext headerContext = new CMDSHeaderContext();
        ThreadLocalHeaderContext.setContext(headerContext);
    	ProcessingException expected = Assertions.assertThrows(ProcessingException.class, () ->
    		bookingCreateService.process(null)
    	);
    	assertEquals("Payload is Empty", expected.getMessage());
    }

    @Test
    void whenProcessCalledShouldReturnValidResponse() {
        BookingChangedEventV1 bookingChangedEvent = new BookingChangedEventV1();
        CMDSHeaderContext headerContext = new CMDSHeaderContext();
        ThreadLocalHeaderContext.setContext(headerContext);
        bookingCreateService.process(bookingChangedEvent);
        verify(bookingCreatedDomainService, times(1)).on(bookingChangedEvent.getBookingDetails());
    }

}
