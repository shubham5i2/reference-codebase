package com.ielts.cmds.ri.domain.service;

import static com.ielts.cmds.plagiarism.common.enums.PlagiarismOutcomeEnum.CLEARED;
import static com.ielts.cmds.plagiarism.common.enums.PlagiarismOutcomeEnum.INDETERMINANT;
import static com.ielts.cmds.plagiarism.common.enums.PlagiarismOutcomeEnum.PLAGIARISED;
import static com.ielts.cmds.plagiarism.common.enums.PlagiarismOutcomeEnum.UNDER_INVESTIGATION;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_FAILED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_PASSED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_PENDING;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.INCIDENT_STATUS_TYPE_CODE_CONFIRMED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.INCIDENT_STATUS_TYPE_CODE_INVESTIGATION;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.INCIDENT_STATUS_TYPE_CODE_PASSED;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.plagiarism.common.out.model.PlagiarismOutcomeV1;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.domain.enums.IncidentSeverityEnum;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeType;
import com.ielts.cmds.ri.infrastructure.entity.Incident;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentStatusTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.ProductIncidentMappingRepository;
import com.ielts.cmds.ri.utils.BookingDetailsEvent;
import com.ielts.cmds.ri.utils.PlagiarismOutcomeReceivedEvent;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.ri.utils.TestDayIncidentRaisedEvent;

@ExtendWith(MockitoExtension.class)
class PlagiarismOutcomeReceivedDomainServiceTest {

  @InjectMocks @Spy PlagiarismOutcomeReceivedDomainService plagiarismOutcomeReceivedDomainService;

  @Mock private BookingRepository bookingRepository;

  @Mock private CheckOutcomeTypeRepository checkOutcomeTypeRepository;

  @Mock private CheckOutcomeRepository checkOutcomeRepository;

  @Mock private CheckOutcomeStatusRepository checkOutcomeStatusRepository;

  @Mock private IncidentTypeRepository incidentTypeRepository;

  @Mock private IncidentStatusTypeRepository incidentStatusTypeRepository;

  @Mock RICommonUtil riCommonUtil;
  
  @Mock OutcomeStatusRepository outcomeStatusRepository;

  Booking booking;

  CheckOutcome checkOutcome;

  @Mock
  ProductIncidentMappingRepository productIncidentMappingRepository;

  @BeforeEach
  void setUp() {
    booking =
        Booking.builder()
            .bookingUuid(UUID.fromString("93fb67cc-a5b2-48ec-bf0a-a9a3c637bb3e"))
            .compositeCandidateNumber("123456")
                .bookingVersion(BigDecimal.valueOf(3))
            .build();

    checkOutcome = PlagiarismOutcomeReceivedEvent.generateCheckOutcomeEntity();

    CMDSHeaderContext ctx = new CMDSHeaderContext();
    ctx.setCorrelationId(UUID.randomUUID());
    ctx.setTransactionId(UUID.randomUUID());
    ctx.setPartnerCode("BC");
    ctx.setEventDateTime(LocalDateTime.now());
    ThreadLocalHeaderContext.setContext(ctx);
  }

  @Test
  void testMapPlagiarismOutcomeToIncidentStatusType() {
    String incidentStatusType;
    Incident incident = PlagiarismOutcomeReceivedEvent.getPlagiarismIncident();
    Mockito.doReturn(BookingDetailsEvent.setBookingForTest())
            .when(riCommonUtil).getBooking(incident);
    when(productIncidentMappingRepository
            .findByProductUuidAndIncidentCategoryUuid
                (UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672")
                    ,UUID.fromString("7ce32c94-7bd7-409c-a755-7cb5a2b62195")))
        .thenReturn(TestDayIncidentRaisedEvent.getProductIncidentMapping());

    incidentStatusType =
        plagiarismOutcomeReceivedDomainService
            .mapPlagiarismOutcomeToIncidentStatusType("CLEARED",incident);

    Assertions.assertEquals(INCIDENT_STATUS_TYPE_CODE_PASSED, incidentStatusType);

    incidentStatusType =
        plagiarismOutcomeReceivedDomainService.mapPlagiarismOutcomeToIncidentStatusType(
            "INDETERMINANT",incident);

    Assertions.assertEquals(INCIDENT_STATUS_TYPE_CODE_PASSED, incidentStatusType);

    incidentStatusType =
        plagiarismOutcomeReceivedDomainService.mapPlagiarismOutcomeToIncidentStatusType(
            "UNDER_INVESTIGATION",incident);

    Assertions.assertEquals(INCIDENT_STATUS_TYPE_CODE_INVESTIGATION, incidentStatusType);

    incidentStatusType =
        plagiarismOutcomeReceivedDomainService.mapPlagiarismOutcomeToIncidentStatusType(
            "PLAGIARISED",incident);

    Assertions.assertEquals(INCIDENT_STATUS_TYPE_CODE_CONFIRMED, incidentStatusType);

    Assertions.assertThrows(
        ResultIntegrityException.class,
        () ->
          plagiarismOutcomeReceivedDomainService.mapPlagiarismOutcomeToIncidentStatusType(
              "INVALID",incident)
        );
  }

  @Test
  void testMapPlagiarismStatusToIncidentSeverity() {
    IncidentSeverityEnum incidentSeverity;

    incidentSeverity =
        plagiarismOutcomeReceivedDomainService.mapPlagiarismStatusToIncidentSeverity(PLAGIARISED);

    Assertions.assertEquals(IncidentSeverityEnum.CONFIRMED_MALPRACTICE, incidentSeverity);

    incidentSeverity =
        plagiarismOutcomeReceivedDomainService.mapPlagiarismStatusToIncidentSeverity(CLEARED);

    Assertions.assertNull(incidentSeverity);

    incidentSeverity =
        plagiarismOutcomeReceivedDomainService.mapPlagiarismStatusToIncidentSeverity(
            UNDER_INVESTIGATION);

    Assertions.assertEquals(IncidentSeverityEnum.INFO, incidentSeverity);

    incidentSeverity =
        plagiarismOutcomeReceivedDomainService.mapPlagiarismStatusToIncidentSeverity(INDETERMINANT);

    Assertions.assertNull(incidentSeverity);
  }

  @Test
  void testMapPlagiarismOutcomeToCheckOutcome() {
    String checkOutcomeStatus;

    checkOutcomeStatus =
        plagiarismOutcomeReceivedDomainService.mapPlagiarismOutcomeToCheckOutcome("CLEARED");

    Assertions.assertEquals(CHECK_OUTCOME_STATUS_CODE_PASSED, checkOutcomeStatus);

    checkOutcomeStatus =
        plagiarismOutcomeReceivedDomainService.mapPlagiarismOutcomeToCheckOutcome("INDETERMINANT");

    Assertions.assertEquals(CHECK_OUTCOME_STATUS_CODE_PASSED, checkOutcomeStatus);

    checkOutcomeStatus =
        plagiarismOutcomeReceivedDomainService.mapPlagiarismOutcomeToCheckOutcome(
            "UNDER_INVESTIGATION");

    Assertions.assertEquals(CHECK_OUTCOME_STATUS_CODE_PENDING, checkOutcomeStatus);

    checkOutcomeStatus =
        plagiarismOutcomeReceivedDomainService.mapPlagiarismOutcomeToCheckOutcome("PLAGIARISED");

    Assertions.assertEquals(CHECK_OUTCOME_STATUS_CODE_FAILED, checkOutcomeStatus);

    Assertions.assertThrows(
        ResultIntegrityException.class,
        () ->
          plagiarismOutcomeReceivedDomainService.mapPlagiarismOutcomeToCheckOutcome("INVALID")
        );
  }

  @Test
  void test_shouldCreateNewCheckOutcomeAndIncident_whenNoExistingCheckOutcomeIsPresentForBooking() {
    PlagiarismOutcomeV1 plagiarismOutcomeV1 =
        PlagiarismOutcomeReceivedEvent.generatePlagiarismOutcomePassed();
    CheckOutcome savedCheckOutcome = PlagiarismOutcomeReceivedEvent.generateCheckOutcomeEntity();
    savedCheckOutcome.setCheckOutcomeUuid(UUID.fromString("6d1c020d-5407-4e14-b9c0-8af26a907d9e"));

  when(
            checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(
                RIConstants.PrcOutcomeConstant.PLAGIARISM_CHECK_OUTCOME_TYPE_CODE))
        .thenReturn(Optional.of(PlagiarismOutcomeReceivedEvent.generateCheckOutcomeTypeEntity()));
    when(
            checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
                UUID.fromString("93fb67cc-a5b2-48ec-bf0a-a9a3c637bb3e"),
                PlagiarismOutcomeReceivedEvent.generateCheckOutcomeTypeEntity().getCheckOutcomeTypeUuid()))
        .thenReturn(Optional.empty());
    when(
            checkOutcomeStatusRepository.findByCheckOutcomeStatusCode(
                CHECK_OUTCOME_STATUS_CODE_PASSED))
        .thenReturn(Optional.of(PlagiarismOutcomeReceivedEvent.generateCheckOutcomeStatusEntity()));
    when(
            incidentTypeRepository.findByIncidentTypeCode(
                RIConstants.PrcOutcomeConstant.INCIDENT_TYPE_CODE_PLAGIARISM))
        .thenReturn(Optional.of(PlagiarismOutcomeReceivedEvent.getIncidentTypePlagiarism()));
    when(
            incidentStatusTypeRepository.findByIncidentStatusTypeCode(
                INCIDENT_STATUS_TYPE_CODE_PASSED))
        .thenReturn(Optional.of(PlagiarismOutcomeReceivedEvent.getPassedIncidentStatusType()));
    when(checkOutcomeRepository.save(any())).thenReturn(savedCheckOutcome);

    Mockito.doReturn(BookingDetailsEvent.setBookingForTest())
        .when(riCommonUtil).getBooking(any());
    
    when(outcomeStatusRepository.findByBookingUuid(UUID.fromString("93fb67cc-a5b2-48ec-bf0a-a9a3c637bb3e")))
    .thenReturn(Optional.empty());

    CheckOutcome checkOutcomeCreated =
        plagiarismOutcomeReceivedDomainService.updatePlagiarismOutcome(plagiarismOutcomeV1,booking);

    Assertions.assertEquals(
        UUID.fromString("6d1c020d-5407-4e14-b9c0-8af26a907d9e"),
        checkOutcomeCreated.getCheckOutcomeUuid());
  }

  @Test
  void test_shouldThrowException_whenNoBookingExists() {
    PlagiarismOutcomeV1 plagiarismOutcomeV1 =
        PlagiarismOutcomeReceivedEvent.generatePlagiarismOutcomePassed();

    Assertions.assertThrows(
        ResultIntegrityException.class,
        () ->
          plagiarismOutcomeReceivedDomainService.updatePlagiarismOutcome(plagiarismOutcomeV1,null));
  }

  @Test
  void test_shouldUpdateCheckOutcomeAndIncident_whenBothPresent() {
    PlagiarismOutcomeV1 plagiarismOutcomeV1 =
        PlagiarismOutcomeReceivedEvent.generatePlagiarismOutcomePassed();
    CheckOutcome savedCheckOutcome =
        PlagiarismOutcomeReceivedEvent.generateCheckOutcomeEntityPending();
    savedCheckOutcome.setCheckOutcomeUuid(UUID.fromString("6d1c020d-5407-4e14-b9c0-8af26a907d9e"));

    CheckOutcome modifiedCheckOutcome = PlagiarismOutcomeReceivedEvent.generateCheckOutcomeEntity();
    modifiedCheckOutcome.setCheckOutcomeUuid(
        UUID.fromString("6d1c020d-5407-4e14-b9c0-8af26a907d9e"));

//    when(bookingRepository.findByCompositeCandidateNumber("123456"))
//        .thenReturn(Optional.of(booking));
    when(
            checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(
                RIConstants.PrcOutcomeConstant.PLAGIARISM_CHECK_OUTCOME_TYPE_CODE))
        .thenReturn(Optional.of(PlagiarismOutcomeReceivedEvent.generateCheckOutcomeTypeEntity()));
    Mockito.when(
            checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
                UUID.fromString("93fb67cc-a5b2-48ec-bf0a-a9a3c637bb3e"),
                PlagiarismOutcomeReceivedEvent.generateCheckOutcomeTypeEntity().getCheckOutcomeTypeUuid()))
        .thenReturn(Optional.of(savedCheckOutcome));

    when(checkOutcomeRepository.save(savedCheckOutcome)).thenReturn(modifiedCheckOutcome);

    CheckOutcome checkOutcomeCreated =
        plagiarismOutcomeReceivedDomainService.updatePlagiarismOutcome(plagiarismOutcomeV1,booking);

    Assertions.assertEquals(
        UUID.fromString("6d1c020d-5407-4e14-b9c0-8af26a907d9e"),
        checkOutcomeCreated.getCheckOutcomeUuid());
    Assertions.assertEquals(
        "CHK_OUT_PASSED",
        checkOutcomeCreated
            .getCheckOutcomeStatus()
            .getCheckOutcomeStatusCode());
    Assertions.assertEquals(1, checkOutcomeCreated.getIncidentsByCheckOutcomeUuid().size());
  }

  @Test
  void testOn_shouldPublishIntegrityCheckInitiatedEvent_onSuccess() {
    PlagiarismOutcomeV1 plagiarismOutcomeV1 =
        PlagiarismOutcomeReceivedEvent.generatePlagiarismOutcome();

    CheckOutcome modifiedCheckOutcome = PlagiarismOutcomeReceivedEvent.generateCheckOutcomeEntity();
    modifiedCheckOutcome.setCheckOutcomeUuid(
        UUID.fromString("6d1c020d-5407-4e14-b9c0-8af26a907d9e"));
    modifiedCheckOutcome
        .getIncidentsByCheckOutcomeUuid()
        .forEach(
            incident -> {
              incident.setIncidentUuid(UUID.fromString("e58ed763-928c-4155-bee9-fdbaaadc15f3"));
              incident.setIncidentSeverity(IncidentSeverityEnum.INFO);
            });
    Optional<Booking> optionalBooking=bookingRepository.findByCompositeCandidateNumber(plagiarismOutcomeV1.getPlagiarismOutcomeDetails().getCompositeCandidateNumber());

    Mockito.doReturn(modifiedCheckOutcome)
        .when(plagiarismOutcomeReceivedDomainService)
        .updatePlagiarismOutcome(plagiarismOutcomeV1,optionalBooking.orElse(null));
    
    Mockito.doNothing().when(plagiarismOutcomeReceivedDomainService).publishEvent(any());


    plagiarismOutcomeReceivedDomainService.on(plagiarismOutcomeV1);

    Mockito.verify(plagiarismOutcomeReceivedDomainService)
        .updatePlagiarismOutcome(plagiarismOutcomeV1,optionalBooking.orElse(null));

    Mockito.verify(plagiarismOutcomeReceivedDomainService, Mockito.times(2))
        .publishEvent(any());
  }

  @Test
  void testOn_shouldThrowException_onError() {
    PlagiarismOutcomeV1 plagiarismOutcomeV1 = PlagiarismOutcomeReceivedEvent.generatePlagiarismOutcome();
    Mockito.doThrow(new ResultIntegrityException("error in processing"))
        .when(plagiarismOutcomeReceivedDomainService)
        .updatePlagiarismOutcome(plagiarismOutcomeV1,null);

    Assertions.assertThrows(
        ResultIntegrityException.class,
        () ->
          plagiarismOutcomeReceivedDomainService.on(plagiarismOutcomeV1)
        );
  }

  @Test
  void test_newBookingWithHigherBookingVersion(){
    PlagiarismOutcomeV1 plagiarismOutcomeV1=PlagiarismOutcomeReceivedEvent.generatePlagiarismOutcomePassed();
    CheckOutcome savedCheckOutcome =
            PlagiarismOutcomeReceivedEvent.generateCheckOutcomeEntityPending();
    savedCheckOutcome.setCheckOutcomeUuid(UUID.fromString("6d1c020d-5407-4e14-b9c0-8af26a907d9e"));

    CheckOutcome modifiedCheckOutcome = PlagiarismOutcomeReceivedEvent.generateCheckOutcomeEntity();
    modifiedCheckOutcome.setCheckOutcomeUuid(
            UUID.fromString("6d1c020d-5407-4e14-b9c0-8af26a907d9e"));
    modifiedCheckOutcome
            .getIncidentsByCheckOutcomeUuid()
            .forEach(
                    incident -> {
                      incident.setIncidentUuid(UUID.fromString("e58ed763-928c-4155-bee9-fdbaaadc15f3"));
                      incident.setIncidentSeverity(IncidentSeverityEnum.INFO);
                    });

     Optional<Booking> optionalBooking=bookingRepository.findByCompositeCandidateNumber(plagiarismOutcomeV1.getPlagiarismOutcomeDetails().getCompositeCandidateNumber());

    Mockito.doReturn(modifiedCheckOutcome)
            .when(plagiarismOutcomeReceivedDomainService)
            .updatePlagiarismOutcome(plagiarismOutcomeV1,optionalBooking.orElse(null));

    Mockito.doNothing().when(plagiarismOutcomeReceivedDomainService).publishEvent(any());


    plagiarismOutcomeReceivedDomainService.on(plagiarismOutcomeV1);

    Mockito.verify(plagiarismOutcomeReceivedDomainService)
            .updatePlagiarismOutcome(plagiarismOutcomeV1,optionalBooking.orElse(null));

    Mockito.verify(plagiarismOutcomeReceivedDomainService, Mockito.times(2))
            .publishEvent(any());
  }
  @Test
  void test_newBookingWithLowerBookingVersion(){
    PlagiarismOutcomeV1 plagiarismOutcomeV1=PlagiarismOutcomeReceivedEvent.generatePlagiarismOutcomePassed();
    Optional<CheckOutcomeType> optionalCheckOutcomeType= Optional.of(PlagiarismOutcomeReceivedEvent.generateCheckOutcomeTypeEntity());
    CheckOutcome savedCheckOutcome =
            PlagiarismOutcomeReceivedEvent.generateCheckOutcomeEntityPending();
    savedCheckOutcome.setCheckOutcomeUuid(UUID.fromString("6d1c020d-5407-4e14-b9c0-8af26a907d9e"));

    CheckOutcome modifiedCheckOutcome = PlagiarismOutcomeReceivedEvent.generateCheckOutcomeEntity();
    modifiedCheckOutcome.setCheckOutcomeUuid(
            UUID.fromString("6d1c020d-5407-4e14-b9c0-8af26a907d9e"));

//    when( bookingRepository.findByCompositeCandidateNumber(String.valueOf(123456))).thenReturn(Optional.of(booking));
    when( checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.PLAGIARISM_CHECK_OUTCOME_TYPE_CODE)).thenReturn(optionalCheckOutcomeType);
    when(
            checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
                    UUID.fromString("93fb67cc-a5b2-48ec-bf0a-a9a3c637bb3e"),
                    PlagiarismOutcomeReceivedEvent.generateCheckOutcomeTypeEntity().getCheckOutcomeTypeUuid()))
            .thenReturn(Optional.of(savedCheckOutcome));
    when(outcomeStatusRepository
            .findByBookingUuid(booking.getBookingUuid())).thenReturn(Optional.empty());
    when(checkOutcomeRepository.save(savedCheckOutcome)).thenReturn(savedCheckOutcome);
    /*when(productIncidentMappingRepository
            .findByProductUuidAndIncidentCategoryUuid(booking.getProductUuid(),PlagiarismOutcomeReceivedEvent.getPlagiarismIncidentCategory().getIncidentCategoryUuid()))
            .thenReturn(TestDayIncidentRaisedEvent.getProductIncidentMapping());
*/
    CheckOutcome checkOutcomeCreated = plagiarismOutcomeReceivedDomainService.updatePlagiarismOutcome(plagiarismOutcomeV1,booking);
    Assertions.assertEquals(
            UUID.fromString("6d1c020d-5407-4e14-b9c0-8af26a907d9e"),
            checkOutcomeCreated.getCheckOutcomeUuid());
  }
}
