package com.ielts.cmds.ri.domain.service;

import com.ielts.cmds.api.evt119.IntegrityCheckInitiatedV1;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ors.common.enums.ExternalIncidentStatusEnum;
import com.ielts.cmds.ors.common.out.model.IncidentV1;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.application.exception.ResultIntegrityValidationException;
import com.ielts.cmds.ri.infrastructure.entity.*;
import com.ielts.cmds.ri.infrastructure.repository.*;
import com.ielts.cmds.ri.utils.*;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SpeakingIdCheckOutcomeDomainServiceTest {

  @InjectMocks
  @Spy
  SpeakingIdCheckOutcomeDomainService speakingIdCheckOutcomeDomainService;

  @Mock
  private CheckOutcomeRepository checkOutcomeRepository;
  @Mock
  private CheckOutcomeStatusRepository checkOutcomeStatusRepository;
  @Mock
  private CheckOutcomeTypeRepository checkOutcomeTypeRepository;
  @Mock
  private OutcomeStatusRepository outcomeStatusRepository;
  @Mock
  private OutcomeStatusTypeRepository outcomeStatusTypeRepository;
  @Mock
  private CheckOutcome checkOutcome;
  @Mock
  EventOutIncidentBuilderUtil eventOutIncidentBuilderUtil;

  @Mock
  RICommonUtil riCommonUtil;

  @Captor
  ArgumentCaptor<CheckOutcome> checkOutcomeArgumentCaptor;

  @Captor
  ArgumentCaptor<OutcomeStatus> outcomeStatusArgumentCaptor;
  
  @BeforeEach
  public void init() {
	  CMDSHeaderContext ctx = new CMDSHeaderContext();
	  ctx.setCorrelationId(UUID.randomUUID());
	  ctx.setTransactionId(UUID.randomUUID());
	  ctx.setEventDateTime(LocalDateTime.now());
	  ctx.setPartnerCode("CA");
	  ThreadLocalHeaderContext.setContext(ctx);
  }

  @SneakyThrows
  @ParameterizedTest
  @MethodSource("argumentsProviderForSpeakingIdCheckOutcomeServiceTest")
  void createSpeakingIdCheckOutcomeOnValidFlow(
      IncidentV1 speakingIdCheckOutcomeReceived,
      CheckOutcome checkOutcome, CheckOutcomeStatus checkOutcomeStatus, Booking booking,
      CheckOutcomeType checkOutcomeType
  ) {
    when(checkOutcomeRepository.save(ArgumentMatchers.any())).thenReturn(checkOutcome);
    Mockito.doReturn(booking).when(
        riCommonUtil).getBookingFromExternalBookingUuId(
        speakingIdCheckOutcomeReceived.getIncidentDetails().getExternalBookingUuid()
    );
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.SPK_ID_INC_CHK))
        .thenReturn(Optional.of(checkOutcomeType));
    when(checkOutcomeStatusRepository.findByCheckOutcomeStatusCode(
        riCommonUtil.externalIncidentStatus(
            speakingIdCheckOutcomeReceived.getIncidentDetails().getExternalIncidentStatus().getValue()
        ))).thenReturn(Optional.of(checkOutcomeStatus));
    when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
        booking.getBookingUuid(), checkOutcomeType.getCheckOutcomeTypeUuid()
    )).thenReturn(Optional.empty());
    doNothing().when(speakingIdCheckOutcomeDomainService).publishEvent(ArgumentMatchers.any());

    speakingIdCheckOutcomeDomainService.on(speakingIdCheckOutcomeReceived);
    Mockito.verify(checkOutcomeRepository).save(checkOutcomeArgumentCaptor.capture());
  }

  @SneakyThrows
  @ParameterizedTest
  @MethodSource("argumentsProviderForSpeakingIdCheckOutcomeServiceTest")
  void createSpeakingIdCheckOutcomeOnValidFlowUpdate(
      IncidentV1 speakingIdCheckOutcomeReceived,
      CheckOutcome checkOutcome, CheckOutcomeStatus checkOutcomeStatus, Booking booking,
      CheckOutcomeType checkOutcomeType
  ) {
    speakingIdCheckOutcomeReceived.getIncidentDetails().setExternalIncidentStatus(
        ExternalIncidentStatusEnum.CLEARED
    );
    when(checkOutcomeRepository.save(ArgumentMatchers.any())).thenReturn(checkOutcome);
    when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
        booking.getBookingUuid(), checkOutcomeType.getCheckOutcomeTypeUuid()
    )).thenReturn(Optional.of(checkOutcome));
    Mockito.doReturn(booking).when(
        riCommonUtil).getBookingFromExternalBookingUuId(
        speakingIdCheckOutcomeReceived.getIncidentDetails().getExternalBookingUuid()
    );
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.SPK_ID_INC_CHK))
        .thenReturn(Optional.of(checkOutcomeType));
    when(checkOutcomeStatusRepository.findByCheckOutcomeStatusCode(
        riCommonUtil.externalIncidentStatus(
            speakingIdCheckOutcomeReceived.getIncidentDetails().getExternalIncidentStatus().getValue()
        ))).thenReturn(Optional.of(checkOutcomeStatus));
    doNothing().when(speakingIdCheckOutcomeDomainService).publishEvent(ArgumentMatchers.any());

    speakingIdCheckOutcomeDomainService.on(speakingIdCheckOutcomeReceived);
    Mockito.verify(checkOutcomeRepository).save(checkOutcomeArgumentCaptor.capture());
  }

  @SneakyThrows
  @ParameterizedTest
  @MethodSource("argumentsProviderForSpeakingIdCheckOutcomeServiceTest")
  void createSpeakingIdCheckOutcomeOnInvalidFlow_ThrowsException(
      IncidentV1 speakingIdCheckOutcomeReceived,
      CheckOutcome checkOutcome, CheckOutcomeStatus checkOutcomeStatus, Booking booking,
      CheckOutcomeType checkOutcomeType
  ) {
    speakingIdCheckOutcomeReceived.getIncidentDetails().setExternalIncidentStatus(
        ExternalIncidentStatusEnum.CONFIRMED
    );
    doThrow(new ResultIntegrityException("Error")).when(checkOutcomeRepository).save(ArgumentMatchers.any());
    when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
        booking.getBookingUuid(), checkOutcomeType.getCheckOutcomeTypeUuid()
    )).thenReturn(Optional.of(checkOutcome));
    Mockito.doReturn(booking).when(
        riCommonUtil).getBookingFromExternalBookingUuId(
        speakingIdCheckOutcomeReceived.getIncidentDetails().getExternalBookingUuid()
    );
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.SPK_ID_INC_CHK))
        .thenReturn(Optional.of(checkOutcomeType));
    when(checkOutcomeStatusRepository.findByCheckOutcomeStatusCode(
        riCommonUtil.externalIncidentStatus(
            speakingIdCheckOutcomeReceived.getIncidentDetails().getExternalIncidentStatus().getValue()
        ))).thenReturn(Optional.of(checkOutcomeStatus));

    Assertions.assertThrows(ResultIntegrityException.class,()->
        speakingIdCheckOutcomeDomainService.on(speakingIdCheckOutcomeReceived)
    );
  }

  @SneakyThrows
  @ParameterizedTest
  @MethodSource("argumentsProviderForSpeakingIdCheckOutcomeServiceTest")
  void createSpeakingIdCheckOutcomeOnInvalidFlow_ThrowsException_checkoutcome_status(
      IncidentV1 speakingIdCheckOutcomeReceived,
      CheckOutcome checkOutcome, CheckOutcomeStatus checkOutcomeStatus, Booking booking,
      CheckOutcomeType checkOutcomeType
  ) {
    speakingIdCheckOutcomeReceived.getIncidentDetails().setExternalIncidentStatus(
        ExternalIncidentStatusEnum.FLAGGED
    );
    doThrow(new ResultIntegrityException("Error")).when(checkOutcomeRepository).save(ArgumentMatchers.any());
    when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
        booking.getBookingUuid(), checkOutcomeType.getCheckOutcomeTypeUuid()
    )).thenReturn(Optional.of(checkOutcome));
    Mockito.doReturn(booking).when(
        riCommonUtil).getBookingFromExternalBookingUuId(
        speakingIdCheckOutcomeReceived.getIncidentDetails().getExternalBookingUuid()
    );
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.SPK_ID_INC_CHK))
        .thenReturn(Optional.of(checkOutcomeType));
    when(checkOutcomeStatusRepository.findByCheckOutcomeStatusCode(
        riCommonUtil.externalIncidentStatus(
            speakingIdCheckOutcomeReceived.getIncidentDetails().getExternalIncidentStatus().getValue()
        ))).thenReturn(Optional.of(checkOutcomeStatus));

    Assertions.assertThrows(ResultIntegrityException.class,()->
        speakingIdCheckOutcomeDomainService.on(speakingIdCheckOutcomeReceived)
    );
  }

  @SneakyThrows
  @ParameterizedTest
  @MethodSource("argumentsProviderForSpeakingIdCheckOutcomeServiceTest")
  void createSpeakingIdCheckOutcomeOnInvalidFlow_WhenBookingIsNull(
      IncidentV1 speakingIdCheckOutcomeReceived,
      CheckOutcome checkOutcome, CheckOutcomeStatus checkOutcomeStatus, Booking booking,
      CheckOutcomeType checkOutcomeType
  ) {
    Mockito.doReturn(null).when(
        riCommonUtil).getBookingFromExternalBookingUuId(
        speakingIdCheckOutcomeReceived.getIncidentDetails().getExternalBookingUuid()
    );
    Assertions.assertThrows(ResultIntegrityException.class,()->
        speakingIdCheckOutcomeDomainService.on(speakingIdCheckOutcomeReceived)
    );
  }

  @Test
  void whenPayloadEventDatetimeisBeforeDBDatetime() {

    com.ielts.cmds.ors.common.out.model.IncidentV1 speakingIdCheckOutcomeReceivedNode =
            SpeakingIdAndIncidentCheckOutcomeEvent.getSpeakingIdCheckOutcomeNode();
    CheckOutcome checkOutcome = PrcOutcomeReceivedEvent.getCheckOutcome();
    checkOutcome.setBookingUuid(UUID.fromString("1b07b3ee-7c85-408f-9695-916a15f46590"));
    Incident incident = SpeakingIdAndIncidentCheckOutcomeEvent.getIncident();
    incident.setEventDateTime(LocalDateTime.parse("2023-06-14T10:15:30"));
    incident.setIncidentCommentsByIncidentUuid(TestDayIncidentRaisedEvent.getCommentsEntity());
    incident.setIncidentEvidencesByIncidentUuid(TestDayIncidentRaisedEvent.getEvidenceEntity());
    incident.setIncidentStatusTypeByIncidentStatusTypeUuid(
            TestDayIncidentRaisedEvent.getFlaggedIncidentStatusType());
    IncidentType incidentType = SpeakingIdAndIncidentCheckOutcomeEvent.getIncidentType();
    IncidentCategory incidentCategory = SpeakingIdAndIncidentCheckOutcomeEvent
            .getIncidentCatagory();
    incident.setIncidentTypeByIncidentTypeUuid(incidentType);
    incident.setIncidentCategoryByIncidentCategoryUuid(incidentCategory);

    CMDSHeaderContext ctx = ThreadLocalHeaderContext.getContext();
    ctx.setEventDateTime(LocalDateTime.parse("2023-05-10T10:15:30"));
    ThreadLocalHeaderContext.setContext(ctx);

    Assertions.assertThrows(ResultIntegrityValidationException.class, () -> speakingIdCheckOutcomeDomainService.checkOutComeValidation(speakingIdCheckOutcomeReceivedNode,checkOutcome));
  }

  private static Stream<Arguments> argumentsProviderForSpeakingIdCheckOutcomeServiceTest() {
    com.ielts.cmds.ors.common.out.model.IncidentV1 speakingIdCheckOutcomeReceivedNode =
        SpeakingIdAndIncidentCheckOutcomeEvent.getSpeakingIdCheckOutcomeNode();
    CheckOutcome checkOutcome = PrcOutcomeReceivedEvent.getCheckOutcome();
    checkOutcome.setBookingUuid(UUID.fromString("1b07b3ee-7c85-408f-9695-916a15f46590"));
    CheckOutcomeStatus checkOutcomeStatus = SpeakingIdAndIncidentCheckOutcomeEvent.getCheckoutcomeStatus();
    Booking booking = PrcOutcomeReceivedEvent.getBookingForTest().get();
    CheckOutcomeType checkOutcomeType = SpeakingIdAndIncidentCheckOutcomeEvent.getCheckOutcomeType();
    return Stream.of(
        Arguments.of(
            speakingIdCheckOutcomeReceivedNode,
            checkOutcome,
            checkOutcomeStatus,
            booking,
            checkOutcomeType));

  }
}
