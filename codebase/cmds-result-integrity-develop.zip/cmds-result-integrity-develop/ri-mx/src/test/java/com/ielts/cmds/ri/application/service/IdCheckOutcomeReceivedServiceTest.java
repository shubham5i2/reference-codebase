package com.ielts.cmds.ri.application.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.ri.common.model.out.IdCheckOutcomeReceivedDetailsV1;
import com.ielts.cmds.ri.domain.service.IdCheckOutcomeReceivedDomainService;
import com.ielts.cmds.ri.utils.IdCheckOutcomeReceivedEvent;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;

/**
 * The type Id check outcome received service test.
 */
@ExtendWith(MockitoExtension.class)
class IdCheckOutcomeReceivedServiceTest {

  /**
   * The Id check outcome received service.
   */
  @InjectMocks
  IdCheckOutcomeReceivedService idCheckOutcomeReceivedService;

  /**
   * The Id check outcome received domain service.
   */
  @Mock
  IdCheckOutcomeReceivedDomainService idCheckOutcomeReceivedDomainService;


  private static IdCheckOutcomeReceivedDetailsV1 requestV1;

  /**
   * Init.
   */
  @BeforeEach
  void init() {
    requestV1 = IdCheckOutcomeReceivedEvent.createIdCheckOutcomeReceivedObject();
  }

  /**
   * When id check outcome event is received then delegate request to domain service.
   *
   * @throws RbacValidationException the rbac validation exception
   * @throws JsonProcessingException the json processing exception
   */
  @Test
  void whenIdCheckOutcomeEventIsReceived_ThenDelegateRequestToDomainService()
      throws RbacValidationException, JsonProcessingException {

    Mockito.doNothing().when(idCheckOutcomeReceivedDomainService)
        .on(requestV1);
    final Executable executable = () -> idCheckOutcomeReceivedService.process(requestV1);

    assertDoesNotThrow(executable);
  }

  @Test
  void whenIdCheckOutcomeEventIsReceived_ThenThrowException()
          throws RbacValidationException, JsonProcessingException {

    Mockito.doThrow(RuntimeException.class).when(idCheckOutcomeReceivedDomainService)
            .on(requestV1);
    final Executable executable = () -> idCheckOutcomeReceivedService.process(requestV1);

    assertDoesNotThrow(executable);
    Mockito.verify(idCheckOutcomeReceivedDomainService).publishEventAfterUpdatingCheckOutcomeStatus(any(), any(), any());
  }
}
