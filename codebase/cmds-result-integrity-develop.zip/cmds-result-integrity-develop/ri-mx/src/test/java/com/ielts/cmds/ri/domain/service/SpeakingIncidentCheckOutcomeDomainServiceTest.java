package com.ielts.cmds.ri.domain.service;


import static com.ielts.cmds.ri.utils.TestDayIncidentRaisedEvent.*;
import static com.ielts.cmds.ri.utils.TestDayIncidentRaisedEvent.getParentIncidentTypeTech;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;

import com.ielts.cmds.ids.domain.model.ReceivedIncidentDetailsV1;
import com.ielts.cmds.ri.application.exception.ResultIntegrityValidationException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatchers;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ors.common.out.model.IncidentDetailsV1;
import com.ielts.cmds.ors.common.out.model.IncidentV1;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.domain.enums.ExternalIncidentStatusEnum;
import com.ielts.cmds.ri.domain.enums.IncidentSeverityEnum;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.BookingLine;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeType;
import com.ielts.cmds.ri.infrastructure.entity.Incident;
import com.ielts.cmds.ri.infrastructure.entity.IncidentCategory;
import com.ielts.cmds.ri.infrastructure.entity.IncidentStatusType;
import com.ielts.cmds.ri.infrastructure.entity.IncidentType;
import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatus;
import com.ielts.cmds.ri.infrastructure.repository.BookingLineRepository;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.ExternalIncidentStatusMappingRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentCommentRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentStatusTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentTypeRepository;
import com.ielts.cmds.ri.utils.BookingDetailsEvent;
import com.ielts.cmds.ri.utils.CheckOutcomeStatusHelper;
import com.ielts.cmds.ri.utils.EventOutIncidentBuilderUtil;
import com.ielts.cmds.ri.utils.FileStorageHelper;
import com.ielts.cmds.ri.utils.PrcOutcomeReceivedEvent;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant;
import com.ielts.cmds.ri.utils.SpeakingIdAndIncidentCheckOutcomeEvent;
import com.ielts.cmds.ri.utils.TestDayIncidentRaisedEvent;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
class SpeakingIncidentCheckOutcomeDomainServiceTest {

  @InjectMocks
  @Spy
  SpeakingIncidentCheckOutcomeDomainService speakingIncidentCheckOutcomeDomainService;

  @Mock
  CheckOutcomeRepository checkOutcomeRepository;

  @Spy
  private FileStorageHelper fileStorageHelper;

  @Mock
  IncidentRepository incidentRepository;

  @Spy
  @InjectMocks
  CheckOutcomeStatusHelper checkOutcomeStatusHelper;

  @Mock
  CheckOutcomeTypeRepository checkOutcomeTypeRepository;
  @Mock
  CheckOutcomeStatusRepository checkOutcomeStatusRepository;

  @Spy
  private InputStream inputStream;

  @Mock
  EventOutIncidentBuilderUtil eventOutIncidentBuilderUtil;

  @Mock
  IncidentTypeRepository incidentTypeRepository;

  @Mock
  BookingLineRepository bookingLineRepository;

  @Mock
  IncidentStatusTypeRepository incidentStatusTypeRepository;

  @Mock
  BookingRepository bookingRepository;

  @Mock
  ExternalIncidentStatusMappingRepository externalIncidentStatusMappingRepository;

  @Mock
  RICommonUtil riCommonUtil;

  @Mock
  ObjectMetadata objectMetadata;

  @Spy
  AmazonS3Client amazonS3Client;

  @Captor
  ArgumentCaptor<Incident> incidentArgumentCaptor;

  @Captor
  ArgumentCaptor<OutcomeStatus> outcomeStatusArgumentCaptor;

  @Mock
  IncidentCommentRepository incidentCommentRepository;

  @BeforeEach
  void setUp() {
    ReflectionTestUtils
        .setField(speakingIncidentCheckOutcomeDomainService, "checkOutcomeStatusHelper",
            checkOutcomeStatusHelper);
    ReflectionTestUtils
        .setField(speakingIncidentCheckOutcomeDomainService, "bucketName", "RI_BUCKET");
    
    CMDSHeaderContext ctx = new CMDSHeaderContext();
	  ctx.setCorrelationId(UUID.randomUUID());
	  ctx.setTransactionId(UUID.randomUUID());
	  ctx.setEventDateTime(LocalDateTime.now());
	  ctx.setPartnerCode("CA");
	  ThreadLocalHeaderContext.setContext(ctx);
	  
  }

  @SneakyThrows
  @ParameterizedTest
  @MethodSource("argumentsProviderForSpeakingIncidentCheckOutcomeServiceTest")
  void createSpeakingIdCheckOutcomeOnValidFlow(
      IncidentV1 speakingIdCheckOutcomeReceived,
      CheckOutcome checkOutcome, CheckOutcomeStatus checkOutcomeStatus, Booking booking,
      CheckOutcomeType checkOutcomeType,
      IncidentCategory incidentCategory,
      IncidentType incidentType, BookingLine bookingLine, Incident incident
  ) {
    IncidentDetailsV1 details = speakingIdCheckOutcomeReceived.getIncidentDetails();
    details.setExternalIncidentChangedDateTime(OffsetDateTime.now(ZoneOffset.UTC));
    speakingIdCheckOutcomeReceived.setIncidentDetails(details);
    doReturn(booking).when(
        riCommonUtil).getBookingFromExternalBookingUuId(
        speakingIdCheckOutcomeReceived.getIncidentDetails().getExternalBookingUuid()
    );

    when(incidentRepository.findByExternalIncidentIdAndBookingUuidAndBookingLineUuid(
        incident.getExternalIncidentId(), booking.getBookingUuid(), bookingLine.getBookingLineUuid()
    )).thenReturn(Optional.empty());
    doReturn(BookingDetailsEvent.setBookingForTest()).when(riCommonUtil).getBooking(any());
    Mockito.when(externalIncidentStatusMappingRepository
        .getExternalIncidentStatusDetails
            (IncidentSeverityEnum.valueOf("CONFIRMED_MALPRACTICE"),
                ExternalIncidentStatusEnum.valueOf("FLAGGED"),
                UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672")
                , UUID.fromString("7ce32c94-7bd7-409c-a755-7cb5a2b62196")))
        .thenReturn(Optional.of(TestDayIncidentRaisedEvent.getExternalIncidentStatusMapping()));
    when(incidentTypeRepository.findByIncidentTypeUuid(
        incidentType.getIncidentTypeUuid()
    )).thenReturn(Optional.of(incidentType));
    when(bookingLineRepository.findByExternalBookingLineUuid(
        bookingLine.getExternalBookingLineUuid()
    )).thenReturn(Optional.of(bookingLine));

    when(incidentRepository.save(any())).thenReturn(incident);

    doNothing().when(checkOutcomeStatusHelper).setCheckOutcomeStatus(any(), anyString(),any());

    doNothing().when(speakingIncidentCheckOutcomeDomainService).publishEvent(ArgumentMatchers.any());
    
    speakingIncidentCheckOutcomeDomainService.on(speakingIdCheckOutcomeReceived);
    Mockito.verify(incidentRepository).save(incidentArgumentCaptor.capture());
  }

  @SneakyThrows
  @ParameterizedTest
  @MethodSource("argumentsProviderForSpeakingIncidentCheckOutcomeServiceTest")
  void createSpeakingIdCheckOutcomeOnValidFlowForPngTypeFile(
      IncidentV1 speakingIdCheckOutcomeReceived,
      CheckOutcome checkOutcome, CheckOutcomeStatus checkOutcomeStatus, Booking booking,
      CheckOutcomeType checkOutcomeType,
      IncidentCategory incidentCategory,
      IncidentType incidentType, BookingLine bookingLine, Incident incident
  ) {
    IncidentDetailsV1 details = speakingIdCheckOutcomeReceived.getIncidentDetails();
    details.setExternalIncidentChangedDateTime(OffsetDateTime.now(ZoneOffset.UTC));
    speakingIdCheckOutcomeReceived
        .getIncidentDetails().getDocumentsAttached().get(0).setDocumentName("Evd.png");

    speakingIdCheckOutcomeReceived.setIncidentDetails(details);
    doReturn(booking).when(
        riCommonUtil).getBookingFromExternalBookingUuId(
        speakingIdCheckOutcomeReceived.getIncidentDetails().getExternalBookingUuid()
    );

    when(incidentRepository.findByExternalIncidentIdAndBookingUuidAndBookingLineUuid(
        incident.getExternalIncidentId(), booking.getBookingUuid(), bookingLine.getBookingLineUuid()
    )).thenReturn(Optional.empty());
    doReturn(BookingDetailsEvent.setBookingForTest()).when(riCommonUtil).getBooking(any());
    Mockito.when(externalIncidentStatusMappingRepository
            .getExternalIncidentStatusDetails
                (IncidentSeverityEnum.valueOf("CONFIRMED_MALPRACTICE"),
                    ExternalIncidentStatusEnum.valueOf("FLAGGED"),
                    UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672")
                    , UUID.fromString("7ce32c94-7bd7-409c-a755-7cb5a2b62196")))
        .thenReturn(Optional.of(TestDayIncidentRaisedEvent.getExternalIncidentStatusMapping()));
    when(incidentTypeRepository.findByIncidentTypeUuid(
        incidentType.getIncidentTypeUuid()
    )).thenReturn(Optional.of(incidentType));
    when(bookingLineRepository.findByExternalBookingLineUuid(
        bookingLine.getExternalBookingLineUuid()
    )).thenReturn(Optional.of(bookingLine));

    when(incidentRepository.save(any())).thenReturn(incident);

    doNothing().when(checkOutcomeStatusHelper).setCheckOutcomeStatus(any(), anyString(),any());

    doNothing().when(speakingIncidentCheckOutcomeDomainService).publishEvent(ArgumentMatchers.any());
    
    speakingIncidentCheckOutcomeDomainService.on(speakingIdCheckOutcomeReceived);
    Mockito.verify(incidentRepository).save(incidentArgumentCaptor.capture());
  }

  @SneakyThrows
  @ParameterizedTest
  @MethodSource("argumentsProviderForSpeakingIncidentCheckOutcomeServiceTest")
  void createSpeakingIdCheckOutcomeOnInvalidFlow_For_Document(
      IncidentV1 speakingIdCheckOutcomeReceived,
      CheckOutcome checkOutcome, CheckOutcomeStatus checkOutcomeStatus, Booking booking,
      CheckOutcomeType checkOutcomeType,
      IncidentCategory incidentCategory,
      IncidentType incidentType, BookingLine bookingLine, Incident incident
  ) {
    IncidentDetailsV1 details = speakingIdCheckOutcomeReceived.getIncidentDetails();
    details.setExternalIncidentChangedDateTime(OffsetDateTime.now(ZoneOffset.UTC));
    speakingIdCheckOutcomeReceived
        .getIncidentDetails().getDocumentsAttached().get(0).setDocumentName("Evd.mp3");
    speakingIdCheckOutcomeReceived.setIncidentDetails(details);
    doReturn(booking).when(
        riCommonUtil).getBookingFromExternalBookingUuId(
        speakingIdCheckOutcomeReceived.getIncidentDetails().getExternalBookingUuid()
    );
    when(incidentRepository.findByExternalIncidentIdAndBookingUuidAndBookingLineUuid(
        incident.getExternalIncidentId(), booking.getBookingUuid(), bookingLine.getBookingLineUuid()
    )).thenReturn(Optional.empty());
    doReturn(BookingDetailsEvent.setBookingForTest()).when(riCommonUtil).getBooking(any());
    Mockito.when(externalIncidentStatusMappingRepository
        .getExternalIncidentStatusDetails
            (IncidentSeverityEnum.valueOf("CONFIRMED_MALPRACTICE"),
                ExternalIncidentStatusEnum.valueOf("FLAGGED"),
                UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672")
                , UUID.fromString("7ce32c94-7bd7-409c-a755-7cb5a2b62196")))
        .thenReturn(Optional.of(TestDayIncidentRaisedEvent.getExternalIncidentStatusMapping()));
    when(incidentTypeRepository.findByIncidentTypeUuid(
        incidentType.getIncidentTypeUuid()
    )).thenReturn(Optional.of(incidentType));
    when(bookingLineRepository.findByExternalBookingLineUuid(
        bookingLine.getExternalBookingLineUuid()
    )).thenReturn(Optional.of(bookingLine));
    doNothing().when(checkOutcomeStatusHelper).setCheckOutcomeStatus(any(), anyString(),any());
    doNothing().when(speakingIncidentCheckOutcomeDomainService).publishEvent(ArgumentMatchers.any());
    when(incidentRepository.save(any())).thenReturn(incident);

    Assertions.assertDoesNotThrow( () ->
        speakingIncidentCheckOutcomeDomainService.on(speakingIdCheckOutcomeReceived)
    );

  }

  @SneakyThrows
  @ParameterizedTest
  @MethodSource("argumentsProviderForSpeakingIncidentCheckOutcomeServiceTest")
  void createSpeakingIdCheckOutcomeOnInvalidFlow_For_Document_Video_File(
      IncidentV1 speakingIdCheckOutcomeReceived,
      CheckOutcome checkOutcome, CheckOutcomeStatus checkOutcomeStatus, Booking booking,
      CheckOutcomeType checkOutcomeType,
      IncidentCategory incidentCategory,
      IncidentType incidentType, BookingLine bookingLine, Incident incident
  ) {
    IncidentDetailsV1 details = speakingIdCheckOutcomeReceived.getIncidentDetails();
    details.setExternalIncidentChangedDateTime(OffsetDateTime.now(ZoneOffset.UTC));
    speakingIdCheckOutcomeReceived
        .getIncidentDetails().getDocumentsAttached().get(0).setDocumentName("Evd.mp4");
    speakingIdCheckOutcomeReceived.setIncidentDetails(details);
    doReturn(booking).when(
        riCommonUtil).getBookingFromExternalBookingUuId(
        speakingIdCheckOutcomeReceived.getIncidentDetails().getExternalBookingUuid()
    );
    when(incidentRepository.findByExternalIncidentIdAndBookingUuidAndBookingLineUuid(
        incident.getExternalIncidentId(), booking.getBookingUuid(), bookingLine.getBookingLineUuid()
    )).thenReturn(Optional.empty());
    doReturn(BookingDetailsEvent.setBookingForTest()).when(riCommonUtil).getBooking(any());
    Mockito.when(externalIncidentStatusMappingRepository
            .getExternalIncidentStatusDetails
                (IncidentSeverityEnum.valueOf("CONFIRMED_MALPRACTICE"),
                    ExternalIncidentStatusEnum.valueOf("FLAGGED"),
                    UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672")
                    , UUID.fromString("7ce32c94-7bd7-409c-a755-7cb5a2b62196")))
        .thenReturn(Optional.of(TestDayIncidentRaisedEvent.getExternalIncidentStatusMapping()));
    when(incidentTypeRepository.findByIncidentTypeUuid(
        incidentType.getIncidentTypeUuid()
    )).thenReturn(Optional.of(incidentType));
    when(bookingLineRepository.findByExternalBookingLineUuid(
        bookingLine.getExternalBookingLineUuid()
    )).thenReturn(Optional.of(bookingLine));
     doNothing().when(checkOutcomeStatusHelper).setCheckOutcomeStatus(any(), anyString(),any());
    doNothing().when(speakingIncidentCheckOutcomeDomainService).publishEvent(ArgumentMatchers.any());
    when(incidentRepository.save(any())).thenReturn(incident);

    Assertions.assertDoesNotThrow( () ->
        speakingIncidentCheckOutcomeDomainService.on(speakingIdCheckOutcomeReceived)
    );

  }


  @SneakyThrows
  @ParameterizedTest
  @MethodSource("argumentsProviderForSpeakingIncidentCheckOutcomeServiceTest")
  void createSpeakingIdCheckOutcomeOnValidFlowUpdate(
      IncidentV1 speakingIdCheckOutcomeReceived,
      CheckOutcome checkOutcome, CheckOutcomeStatus checkOutcomeStatus, Booking booking,
      CheckOutcomeType checkOutcomeType,
      IncidentCategory incidentCategory,
      IncidentType incidentType, BookingLine bookingLine, Incident incident
  ) {
    IncidentDetailsV1 details = speakingIdCheckOutcomeReceived.getIncidentDetails();
    details.setExternalIncidentChangedDateTime(OffsetDateTime.now(ZoneOffset.UTC));
    speakingIdCheckOutcomeReceived
        .getIncidentDetails().getDocumentsAttached().get(0).setDocumentName("Evd.csv");
    speakingIdCheckOutcomeReceived.setIncidentDetails(details);
    doReturn(booking).when(
        riCommonUtil).getBookingFromExternalBookingUuId(
        speakingIdCheckOutcomeReceived.getIncidentDetails().getExternalBookingUuid()
    );
    IncidentStatusType incidentStatusType = TestDayIncidentRaisedEvent
        .getFlaggedIncidentStatusType();
    when(bookingLineRepository.findByExternalBookingLineUuid(
        bookingLine.getExternalBookingLineUuid()
    )).thenReturn(Optional.of(bookingLine));
    when(incidentRepository.findByExternalIncidentIdAndBookingUuidAndBookingLineUuid(
        incident.getExternalIncidentId(), booking.getBookingUuid(), bookingLine.getBookingLineUuid()
    )).thenReturn(Optional.of(incident));
    doReturn(BookingDetailsEvent.setBookingForTest()).when(riCommonUtil).getBooking(any());
    Mockito.when(externalIncidentStatusMappingRepository
        .getExternalIncidentStatusDetails
            (IncidentSeverityEnum.valueOf("CONFIRMED_MALPRACTICE"),
                ExternalIncidentStatusEnum.valueOf("FLAGGED"),
                UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672")
                , UUID.fromString("ed5f1e14-a155-4d3a-83e0-592ac2899046")))
        .thenReturn(Optional.of(TestDayIncidentRaisedEvent.getExternalIncidentStatusMapping()));
    when(incidentStatusTypeRepository
        .findByIncidentStatusTypeCode(PrcOutcomeConstant.INCIDENT_STATUS_TYPE_CODE_CONFIRMED))
        .thenReturn(Optional.of(incidentStatusType));
    when(incidentRepository.save(any())).thenReturn(incident);
    doNothing().when(checkOutcomeStatusHelper).setCheckOutcomeStatus(any(), anyString(),any());
    doNothing().when(speakingIncidentCheckOutcomeDomainService).publishEvent(ArgumentMatchers.any());
    
    speakingIncidentCheckOutcomeDomainService.on(speakingIdCheckOutcomeReceived);
    Mockito.verify(incidentRepository).save(incidentArgumentCaptor.capture());
  }

  @SneakyThrows
  @ParameterizedTest
  @MethodSource("argumentsProviderForSpeakingIncidentCheckOutcomeServiceTest")
  void createSpeakingIdCheckOutcomeOnInvalidFlow_ThrowsException(
      IncidentV1 speakingIdCheckOutcomeReceived,
      CheckOutcome checkOutcome, CheckOutcomeStatus checkOutcomeStatus, Booking booking,
      CheckOutcomeType checkOutcomeType,
      IncidentCategory incidentCategory,
      IncidentType incidentType, BookingLine bookingLine, Incident incident
  ) {
    IncidentDetailsV1 details = speakingIdCheckOutcomeReceived.getIncidentDetails();
    details.setExternalIncidentChangedDateTime(OffsetDateTime.now(ZoneOffset.UTC));
    speakingIdCheckOutcomeReceived
        .getIncidentDetails().getDocumentsAttached().get(0).setDocumentName("Evd.wav");
    speakingIdCheckOutcomeReceived.setIncidentDetails(details);
    doReturn(booking).when(
        riCommonUtil).getBookingFromExternalBookingUuId(
        speakingIdCheckOutcomeReceived.getIncidentDetails().getExternalBookingUuid()
    );

    IncidentStatusType incidentStatusType = TestDayIncidentRaisedEvent
        .getFlaggedIncidentStatusType();
    doReturn(BookingDetailsEvent.setBookingForTest()).when(riCommonUtil).getBooking(any());
    Mockito.when(externalIncidentStatusMappingRepository
        .getExternalIncidentStatusDetails
            (IncidentSeverityEnum.valueOf("CONFIRMED_MALPRACTICE"),
                ExternalIncidentStatusEnum.valueOf("FLAGGED"),
                UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672")
                , UUID.fromString("7ce32c94-7bd7-409c-a755-7cb5a2b62196")))
        .thenReturn(Optional.of(TestDayIncidentRaisedEvent.getExternalIncidentStatusMapping()));
    when(incidentStatusTypeRepository
        .findByIncidentStatusTypeCode(PrcOutcomeConstant.INCIDENT_STATUS_TYPE_CODE_CONFIRMED))
        .thenReturn(Optional.of(incidentStatusType));

    when(incidentRepository.findByExternalIncidentIdAndBookingUuidAndBookingLineUuid(
        incident.getExternalIncidentId(), booking.getBookingUuid(), bookingLine.getBookingLineUuid()
    )).thenReturn(Optional.empty());
    when(incidentTypeRepository.findByIncidentTypeUuid(
        incidentType.getIncidentTypeUuid()
    )).thenReturn(Optional.of(incidentType));
    when(bookingLineRepository.findByExternalBookingLineUuid(
        bookingLine.getExternalBookingLineUuid()
    )).thenReturn(Optional.of(bookingLine));
    doNothing().when(checkOutcomeStatusHelper).setCheckOutcomeStatus(any(), anyString(),any());
   doThrow(new ResultIntegrityException("Error")).when(incidentRepository)
        .save(any());

    Assertions.assertThrows(ResultIntegrityException.class, () ->
        speakingIncidentCheckOutcomeDomainService.on(speakingIdCheckOutcomeReceived)
    );
  }

  @SneakyThrows
  @ParameterizedTest
  @MethodSource("argumentsProviderForSpeakingIncidentCheckOutcomeServiceTest")
  void createSpeakingIdCheckOutcomeOnInvalidFlow_ThrowsException_When_Booking_is_null(
      IncidentV1 speakingIdCheckOutcomeReceived,
      CheckOutcome checkOutcome, CheckOutcomeStatus checkOutcomeStatus, Booking booking,
      CheckOutcomeType checkOutcomeType,
      IncidentCategory incidentCategory,
      IncidentType incidentType, BookingLine bookingLine, Incident incident
  ) {
    doReturn(null).when(
        riCommonUtil).getBookingFromExternalBookingUuId(
        speakingIdCheckOutcomeReceived.getIncidentDetails().getExternalBookingUuid()
    );
    Assertions.assertThrows(ResultIntegrityException.class, () ->
        speakingIncidentCheckOutcomeDomainService.on(speakingIdCheckOutcomeReceived)
    );
  }
  
  @SneakyThrows
  @ParameterizedTest
  @MethodSource("argumentsProviderForSpeakingIncidentCheckOutcomeServiceTest")
  void createSpeakingIdCheckOutcomeForTechnicalIncidentTypeOnValidFlow(
	      IncidentV1 speakingIdCheckOutcomeReceived,
	      CheckOutcome checkOutcome, CheckOutcomeStatus checkOutcomeStatus, Booking booking,
	      CheckOutcomeType checkOutcomeType,
	      IncidentCategory incidentCategory,
	      IncidentType incidentType, BookingLine bookingLine, Incident incident
	  ) {
    IncidentDetailsV1 details = speakingIdCheckOutcomeReceived.getIncidentDetails();
    details.setExternalIncidentChangedDateTime(OffsetDateTime.now(ZoneOffset.UTC));
    speakingIdCheckOutcomeReceived.setIncidentDetails(details);
    incident.setIncidentTypeByIncidentTypeUuid(incidentType);
    incident.setIncidentCategoryByIncidentCategoryUuid(incidentCategory);
    incident.setCheckOutcomeByCheckOutcomeUuid(null);
    doReturn(booking).when(riCommonUtil).getBookingFromExternalBookingUuId(
        speakingIdCheckOutcomeReceived.getIncidentDetails().getExternalBookingUuid());
    when(incidentRepository.findByExternalIncidentIdAndBookingUuidAndBookingLineUuid(
        incident.getExternalIncidentId(), booking.getBookingUuid(), bookingLine.getBookingLineUuid()
    )).thenReturn(Optional.empty());
    doReturn(BookingDetailsEvent.setBookingForTest()).when(riCommonUtil).getBooking(any());
    Mockito.when(externalIncidentStatusMappingRepository
            .getExternalIncidentStatusDetails
                (IncidentSeverityEnum.valueOf("CONFIRMED_MALPRACTICE"),
                    ExternalIncidentStatusEnum.valueOf("FLAGGED"),
                    UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672")
                    , UUID.fromString("7ce32c94-7bd7-409c-a755-7cb5a2b62196")))
        .thenReturn(Optional.of(TestDayIncidentRaisedEvent.getExternalIncidentStatusMapping()));
    when(incidentTypeRepository.findByIncidentTypeUuid(
        incidentType.getIncidentTypeUuid()
    )).thenReturn(Optional.of(incidentType));
    when(bookingLineRepository.findByExternalBookingLineUuid(
        bookingLine.getExternalBookingLineUuid()
    )).thenReturn(Optional.of(bookingLine));

    when(incidentRepository.save(any())).thenReturn(incident);
    doNothing().when(checkOutcomeStatusHelper).setCheckOutcomeStatus(any(), anyString(),any());
    doNothing().when(speakingIncidentCheckOutcomeDomainService).publishEvent(ArgumentMatchers.any());

    speakingIncidentCheckOutcomeDomainService.on(speakingIdCheckOutcomeReceived);
    Mockito.verify(incidentRepository).save(incidentArgumentCaptor.capture());
  }

  @SneakyThrows
  @ParameterizedTest
  @MethodSource("argumentsProviderForSpeakingIncidentCheckOutcomeServiceTest")
  void createSpeakingIdCheckOutcomeForTechnicalIncidentTypeOnValidFlowWithoutBookingLine(
          IncidentV1 speakingIdCheckOutcomeReceived,
          CheckOutcome checkOutcome, CheckOutcomeStatus checkOutcomeStatus, Booking booking,
          CheckOutcomeType checkOutcomeType,
          IncidentCategory incidentCategory,
          IncidentType incidentType, BookingLine bookingLine, Incident incident
  ) {
    IncidentDetailsV1 details = speakingIdCheckOutcomeReceived.getIncidentDetails();
    details.setExternalIncidentChangedDateTime(OffsetDateTime.now(ZoneOffset.UTC));
    speakingIdCheckOutcomeReceived.setIncidentDetails(details);
    incident.setIncidentTypeByIncidentTypeUuid(incidentType);
    incident.setIncidentCategoryByIncidentCategoryUuid(incidentCategory);
    incident.setCheckOutcomeByCheckOutcomeUuid(null);
    incident.setIncidentCommentsByIncidentUuid(TestDayIncidentRaisedEvent.getCommentsEntity());
    doReturn(booking).when(riCommonUtil).getBookingFromExternalBookingUuId(
            speakingIdCheckOutcomeReceived.getIncidentDetails().getExternalBookingUuid());
    when(incidentRepository.findByExternalIncidentIdAndBookingUuid(
            incident.getExternalIncidentId(), booking.getBookingUuid()
    )).thenReturn((Optional.of(incident)));
    doReturn(BookingDetailsEvent.setBookingForTest()).when(riCommonUtil).getBooking(any());
   when(bookingLineRepository.findByExternalBookingLineUuid(
            bookingLine.getExternalBookingLineUuid()
    )).thenReturn(Optional.empty());
    when(incidentRepository.save(any())).thenReturn(incident);
   doNothing().when(checkOutcomeStatusHelper).setCheckOutcomeStatus(any(), anyString(),any());
    doNothing().when(speakingIncidentCheckOutcomeDomainService).publishEvent(ArgumentMatchers.any());

    speakingIncidentCheckOutcomeDomainService.on(speakingIdCheckOutcomeReceived);
    Mockito.verify(incidentRepository).save(incidentArgumentCaptor.capture());
  }

  @SneakyThrows
  @ParameterizedTest
  @MethodSource("argumentsProviderForSpeakingIncidentCheckOutcomeServiceTest")
  void ShouldnotCreteSpeakingCheckOutcomeForIncident_withSeverityWARING(
          IncidentV1 speakingIdCheckOutcomeReceived,
          CheckOutcome checkOutcome, CheckOutcomeStatus checkOutcomeStatus, Booking booking,
          CheckOutcomeType checkOutcomeType,
          IncidentCategory incidentCategory,
          IncidentType incidentType, BookingLine bookingLine, Incident incident )throws IOException {  IncidentDetailsV1 details = speakingIdCheckOutcomeReceived.getIncidentDetails();
    details.setExternalIncidentChangedDateTime(OffsetDateTime.now(ZoneOffset.UTC));
    details.setIncidentSeverity(com.ielts.cmds.ors.common.enums.IncidentSeverityEnum.WARNING);
    speakingIdCheckOutcomeReceived.setIncidentDetails(details);
    doReturn(booking).when(
            riCommonUtil).getBookingFromExternalBookingUuId(
            speakingIdCheckOutcomeReceived.getIncidentDetails().getExternalBookingUuid()
    );

    when(incidentRepository.findByExternalIncidentIdAndBookingUuidAndBookingLineUuid(
            incident.getExternalIncidentId(), booking.getBookingUuid(), bookingLine.getBookingLineUuid()
    )).thenReturn(Optional.empty());
    doReturn(BookingDetailsEvent.setBookingForTest()).when(riCommonUtil).getBooking(any());
    Mockito.when(externalIncidentStatusMappingRepository
                    .getExternalIncidentStatusDetails
                            (IncidentSeverityEnum.valueOf("WARNING"),
                                    ExternalIncidentStatusEnum.valueOf("FLAGGED"),
                                    UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672")
                                    , UUID.fromString("7ce32c94-7bd7-409c-a755-7cb5a2b62196")))
            .thenReturn(Optional.of(TestDayIncidentRaisedEvent.getExternalIncidentStatusMapping()));
    when(incidentTypeRepository.findByIncidentTypeUuid(
            incidentType.getIncidentTypeUuid()
    )).thenReturn(Optional.of(incidentType));
    when(bookingLineRepository.findByExternalBookingLineUuid(
            bookingLine.getExternalBookingLineUuid()
    )).thenReturn(Optional.of(bookingLine));

    when(incidentRepository.save(any())).thenReturn(incident);

    doNothing().when(checkOutcomeStatusHelper).setCheckOutcomeStatus(any(), anyString(),any());

    doNothing().when(speakingIncidentCheckOutcomeDomainService).publishEvent(ArgumentMatchers.any());

    speakingIncidentCheckOutcomeDomainService.on(speakingIdCheckOutcomeReceived);
    Mockito.verify(incidentRepository).save(incidentArgumentCaptor.capture());
    Mockito.verify(checkOutcomeStatusHelper,times(0)).
            getCheckOutComeStatus(RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_FAILED);
    Mockito.verify(checkOutcomeStatusHelper,times(0)).
            getCheckOutComeStatus(RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_REVIEW);
    Mockito.verify(checkOutcomeStatusHelper,times(0)).
            getCheckOutComeStatus(RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_PASSED);
  }

  @Test
  void whenPayloadEventDatetimeisBeforeDBDatetime() {

    IncidentV1 speakingIdCheckOutcomeReceivedNode =
            SpeakingIdAndIncidentCheckOutcomeEvent.getSpeakingIdCheckOutcomeNode();
    CheckOutcome checkOutcome = PrcOutcomeReceivedEvent.getCheckOutcome();
    checkOutcome.setBookingUuid(UUID.fromString("1b07b3ee-7c85-408f-9695-916a15f46590"));
    Incident incident = SpeakingIdAndIncidentCheckOutcomeEvent.getIncident();
    incident.setEventDateTime(LocalDateTime.parse("2023-06-14T10:15:30"));
    incident.setIncidentCommentsByIncidentUuid(TestDayIncidentRaisedEvent.getCommentsEntity());
    incident.setIncidentEvidencesByIncidentUuid(TestDayIncidentRaisedEvent.getEvidenceEntity());
    incident.setIncidentStatusTypeByIncidentStatusTypeUuid(
            TestDayIncidentRaisedEvent.getFlaggedIncidentStatusType());
    IncidentType incidentType = SpeakingIdAndIncidentCheckOutcomeEvent.getIncidentType();
    IncidentCategory incidentCategory = SpeakingIdAndIncidentCheckOutcomeEvent
            .getIncidentCatagory();
    incident.setIncidentTypeByIncidentTypeUuid(incidentType);
    incident.setIncidentCategoryByIncidentCategoryUuid(incidentCategory);

    CMDSHeaderContext ctx = ThreadLocalHeaderContext.getContext();
    ctx.setEventDateTime(LocalDateTime.parse("2023-05-10T10:15:30"));
    ThreadLocalHeaderContext.setContext(ctx);

    Assertions.assertThrows(ResultIntegrityValidationException.class, () -> speakingIncidentCheckOutcomeDomainService.incidentValidation(speakingIdCheckOutcomeReceivedNode,incident));
  }

  @ParameterizedTest
  @MethodSource("argumentsProviderForSpeakingIncidentCheckOutcomeServiceTest")
  void testSpeakingEvidences(
          IncidentV1 speakingIdCheckOutcomeReceived,
          CheckOutcome checkOutcome, CheckOutcomeStatus checkOutcomeStatus, Booking booking,
          CheckOutcomeType checkOutcomeType,
          IncidentCategory incidentCategory,
          IncidentType incidentType, BookingLine bookingLine, Incident incident
  ) throws IOException  {
    IncidentDetailsV1 details = speakingIdCheckOutcomeReceived.getIncidentDetails();
    details.setExternalIncidentChangedDateTime(OffsetDateTime.now(ZoneOffset.UTC));
    speakingIdCheckOutcomeReceived
            .getIncidentDetails().getDocumentsAttached().get(0).setDocumentName("Evd.wav");
    speakingIdCheckOutcomeReceived.setIncidentDetails(details);
    String key =
            "incident/INC123/" + details.getExternalIncidentChangedDateTime().toString() + "/Evd.wav";
    String preSignedUrl = speakingIdCheckOutcomeReceived
            .getIncidentDetails().getDocumentsAttached().get(0).getDocumentURL();
    doNothing().when(fileStorageHelper)
        .uploadFileToS3FromPresignedUrl(preSignedUrl, key, "RI_BUCKET");
    Assertions.assertDoesNotThrow(()->speakingIncidentCheckOutcomeDomainService.setIncidentEvidence(speakingIdCheckOutcomeReceived,incident));
  }

  private static Stream<Arguments> argumentsProviderForSpeakingIncidentCheckOutcomeServiceTest() {
    IncidentV1 speakingIdCheckOutcomeReceivedNode =
        SpeakingIdAndIncidentCheckOutcomeEvent.getSpeakingIdCheckOutcomeNode();
    CheckOutcome checkOutcome = PrcOutcomeReceivedEvent.getCheckOutcome();
    checkOutcome.setBookingUuid(UUID.fromString("1b07b3ee-7c85-408f-9695-916a15f46590"));
    CheckOutcomeStatus checkOutcomeStatus = SpeakingIdAndIncidentCheckOutcomeEvent
        .getCheckoutcomeStatus();
    Booking booking = PrcOutcomeReceivedEvent.getBookingForTest().get();
    booking.setBookingUuid(UUID.fromString("0d9dbdd5-f1e6-4753-b7a9-573a898cd11c"));
    Incident incident = SpeakingIdAndIncidentCheckOutcomeEvent.getIncident();
    incident.setIncidentCommentsByIncidentUuid(TestDayIncidentRaisedEvent.getCommentsEntity());
    incident.setIncidentEvidencesByIncidentUuid(TestDayIncidentRaisedEvent.getEvidenceEntity());
    incident.setIncidentStatusTypeByIncidentStatusTypeUuid(
        TestDayIncidentRaisedEvent.getFlaggedIncidentStatusType());
    IncidentType incidentType = SpeakingIdAndIncidentCheckOutcomeEvent.getIncidentType();
    IncidentCategory incidentCategory = SpeakingIdAndIncidentCheckOutcomeEvent
        .getIncidentCatagory();
    CheckOutcomeType checkOutcomeType = SpeakingIdAndIncidentCheckOutcomeEvent
        .getCheckOutcomeType();
    BookingLine bookingLine = SpeakingIdAndIncidentCheckOutcomeEvent.getBookingLine();
    bookingLine.setBookingLineUuid(UUID.fromString("0d9dbdd5-f1e6-4753-b7a9-573a898cd11c"));
    return Stream.of(
        Arguments.of(
            speakingIdCheckOutcomeReceivedNode,
            checkOutcome,
            checkOutcomeStatus,
            booking,
            checkOutcomeType,
            incidentCategory,
            incidentType, bookingLine,
            incident));

  }
}

