package com.ielts.cmds.ri.domain.service;

import static com.ielts.cmds.ri.utils.RIConstants.PermissionId.RI_INCIDENT_VIEW;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.validation.ConstraintViolation;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.context.CMDSAuditContext;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.rbac.api.service.RBACService;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.api.service.model.LocationNode;
import com.ielts.cmds.ri.infrastructure.entity.IncidentView;
import com.ielts.cmds.ri.infrastructure.repository.IncidentCommentRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentEvidenceRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentViewRepository;
import com.ielts.cmds.ri.utils.GenerateS3SignedUrl;
import com.ielts.cmds.ri.utils.IncidentViewTestSetup;
import com.ielts.cmds.ri.utils.RICommonUtil;

@ExtendWith(MockitoExtension.class)
class IncidentViewDomainServiceTest {


  /** The Incident view domain service. */
  @Spy
  @InjectMocks
  IncidentViewDomainService incidentViewDomainService;

  /**
   * The Generate s3 signed url.
   */
  @Mock
  GenerateS3SignedUrl generateS3SignedUrl;

  /**
   * The Incident view repository.
   */
  @Mock
  IncidentViewRepository incidentViewRepository;

  /**
   * The Incident comment repository.
   */
  @Mock
  IncidentCommentRepository incidentCommentRepository;

  /**
   * The Incident evidence repository.
   */
  @Mock
  IncidentEvidenceRepository incidentEvidenceRepository;

  /**
   * The Common utils.
   */
  @Mock
  RICommonUtil commonUtils;

  @Mock
  private CMDSErrorResolver<Object> errorResolver;

  /** The Violations. */
  @Mock
  Set<ConstraintViolation<Object>> violations;

  @Mock
  private RBACService rbacService;

  @Spy
  private LocationNode locationNode;


  /**
   * Init.
   */
  @BeforeEach
  void init() {
    CMDSHeaderContext header = IncidentViewTestSetup.generateEventHeader();
    CMDSAuditContext audit = IncidentViewTestSetup.generateAudit();
    header.setEventName("GET/v1/incident/{bookingUuid}");
    header.setPartnerCode("BC");
    Map<String, String> eventContext = new HashMap<>();
    eventContext.put("bookingUuid", "71dda922-d851-419b-8fc8-467f4121bd5d");
    header.setEventContext(eventContext);

    ThreadLocalAuditContext.setContext(audit);
    ThreadLocalHeaderContext.setContext(header);
  }


  /**
   * When view incident event is received with invalid access then publish to outbound topic.
   *
   * @throws RbacValidationException the rbac validation exception
   * @throws JsonProcessingException the json processing exception
   */
  @Test
  void whenViewIncidentEventIsReceived_WithInvalidAccess_ThenPublishToOutboundTopic()
      throws RbacValidationException, JsonProcessingException {

    when(commonUtils.hasAllAccess("", RI_INCIDENT_VIEW)).thenReturn(false);
    Set<ConstraintViolation<Object>> constraintViolation =
        IncidentViewTestSetup.setForNullViolationOfEventBody("V_unauthorised_to_view_incident");
    when(errorResolver.populatErrorResponse
        (constraintViolation, "IncidentViewResponseDetailsGenerated"))
        .thenReturn(new CMDSErrorResponse());
    doNothing().when(incidentViewDomainService).publishEvent(any(),any());
    incidentViewDomainService.on();

    verify(commonUtils).hasAllAccess("", RI_INCIDENT_VIEW);
  }

  /**
   * When object is null with valid access then publish to outbound topic.
   *
   * @throws RbacValidationException the rbac validation exception
   */
  @Test
  void whenObjectIsNull_WithValidAccess_ThenPublishToOutboundTopic()
      throws RbacValidationException {

    when(commonUtils.hasAllAccess("", RI_INCIDENT_VIEW)).thenReturn(true);
    doNothing().when(incidentViewDomainService).publishEvent(any(),any());
    final Executable executable = () -> incidentViewDomainService.on();
    assertDoesNotThrow(executable);
  }

  /**
   * When object is not null with valid access then publish to outbound topic.
   *
   * @throws RbacValidationException the rbac validation exception
   */
  @Test
  void whenObjectIsNotNull_WithValidAccess_ThenPublishToOutboundTopic()
      throws RbacValidationException {

    when(commonUtils.hasAllAccess("", RI_INCIDENT_VIEW)).thenReturn(true);
    when(incidentViewRepository.findByBookingUuidOrderByCreatedDatetime(UUID.fromString
            ("71dda922-d851-419b-8fc8-467f4121bd5d")))
        .thenReturn(IncidentViewTestSetup.generateIncidentViewDataList());

    doReturn(IncidentViewTestSetup.generateIncidentDetailData()).when(incidentViewDomainService)
        .generateIncidentResponseData(IncidentViewTestSetup.generateIncidentViewDataList());
    doNothing().when(incidentViewDomainService).publishEvent(any());

    final Executable executable = () -> incidentViewDomainService.on();

    assertDoesNotThrow(executable);

  }

  /**
   * Test generate incident response data.
   */
  @Test
  void testGenerateIncidentResponseData() throws RbacValidationException {

    List<IncidentView> incidentView = IncidentViewTestSetup.generateIncidentViewDataList();

    when(incidentCommentRepository.findByIncidentUuidOrderByUpdatedDateTimeDesc(UUID.fromString("0b04b3ee-7c85-408f-9695-916a15f46509")))
        .thenReturn(IncidentViewTestSetup.incidentCommentList());

    when(incidentEvidenceRepository
        .getEvidenceListWhereNameAndUrlIsNotNull(UUID.fromString("0b04b3ee-7c85-408f-9695-916a15f46509")))
        .thenReturn(IncidentViewTestSetup.incidentEvidenceList());

    doReturn(locationNode).when(commonUtils).getParentNode(any(),any());


        incidentViewDomainService.generateIncidentResponseData(incidentView);

    verify(incidentViewDomainService, times(1))
        .setComments(UUID.fromString("0b04b3ee-7c85-408f-9695-916a15f46509"));

    verify(incidentViewDomainService, times(1))
        .setEvidences(UUID.fromString("0b04b3ee-7c85-408f-9695-916a15f46509"));

  }


  /**
   * Test get incident details.
   */
  @Test
  void testGetIncidentDetails() {

    List<IncidentView> incidentView =
        incidentViewDomainService.getIncidentDetail(
            UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46598"));

    assertEquals(0, incidentView.size());
  }
}


