package com.ielts.cmds.ri.domain.service;

import static com.ielts.cmds.ri.utils.RICommonUtil.getSetforNullViolationOfEventBody;
import static com.ielts.cmds.ri.utils.RIConstants.EventType.RESULT_INTEGRITY_LOCATION_REJECTED;
import static com.ielts.cmds.ri.utils.TestDayIncidentRaisedEvent.getFlaggedIncidentStatusType;
import static com.ielts.cmds.ri.utils.TestDayIncidentRaisedEvent.getParentIncidentTypeTech;
import static com.ielts.cmds.ri.utils.TestDayIncidentRaisedEvent.getTechIncident;
import static com.ielts.cmds.ri.utils.TestDayIncidentRaisedEvent.getTechIncidentCategory;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.*;
import java.util.stream.Stream;

import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.lpr.common.out.model.LocationV1;
import com.ielts.cmds.ri.LocationTestSetup;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.application.exception.ResultIntegrityValidationException;
import com.ielts.cmds.ri.infrastructure.entity.*;
import com.ielts.cmds.ri.infrastructure.repository.*;
import org.hibernate.validator.internal.engine.ConstraintViolationImpl;
import org.hibernate.validator.internal.engine.path.PathImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatchers;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import com.ielts.cmds.ids.domain.model.ReceivedIncidentDetailsV1;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.domain.enums.IncidentSeverityEnum;
import com.ielts.cmds.ri.utils.BookingDetailsEvent;
import com.ielts.cmds.ri.utils.CheckOutcomeStatusEvent;
import com.ielts.cmds.ri.utils.CheckOutcomeStatusHelper;
import com.ielts.cmds.ri.utils.FileStorageHelper;
import com.ielts.cmds.ri.utils.IncidentDetailsEvent;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.ri.utils.TestDayIncidentRaisedEvent;

import javax.validation.ConstraintViolation;
import javax.validation.metadata.ConstraintDescriptor;

@ExtendWith(MockitoExtension.class)
class TestDayIncidentDomainServiceTest {

  @InjectMocks
  @Spy
  TestDayIncidentDomainService testDayIncidentDomainService;

  @Mock
  IncidentRepository incidentRepository;

  @Mock
  IncidentTypeRepository incidentTypeRepository;


  @Mock
  IncidentCategoryRepository incidentCategoryRepository;
  
  @Mock
  RICommonUtil riCommonUtil;

  @Mock
  private CMDSErrorResolver<Object> errorResolver;

  @Mock
  CheckOutcomeTypeRepository checkOutcomeTypeRepository;
  
  @Mock
  CheckOutcomeRepository checkOutcomeRepository;

  @Spy
  @InjectMocks
  CheckOutcomeStatusHelper checkOutcomeStatusHelper;

  @Captor
  ArgumentCaptor<Incident> incidentArgumentCaptor;

  @Spy
  private FileStorageHelper fileStorageHelper;

  @Mock
  BookingRepository bookingRepository;

  @BeforeEach
  void setUp() {
    ReflectionTestUtils.setField(
        testDayIncidentDomainService, "checkOutcomeStatusHelper", checkOutcomeStatusHelper);
    ReflectionTestUtils
        .setField(testDayIncidentDomainService, "bucketName", "RI_BUCKET");
    
    CMDSHeaderContext ctx = new CMDSHeaderContext();
	ctx.setCorrelationId(UUID.randomUUID());
	ctx.setTransactionId(UUID.randomUUID());
	ctx.setPartnerCode("CA");
	ctx.setEventDateTime(LocalDateTime.now(ZoneOffset.UTC).minusSeconds(5));
	ThreadLocalHeaderContext.setContext(ctx);
  }

  @ParameterizedTest
  @MethodSource("argumentProviderForTestDayIncidentTestTech")
  void testOnCommand_shouldPersistTechIncident_withSeverityConfirm_Malpractice(
		  ReceivedIncidentDetailsV1 lrwIncidentDetails,
      IncidentCategory techIncidentCategory,
      IncidentType techIncidentType,
      IncidentStatusType flaggedIncidentStatusType,
      Incident incident,
      Incident incidentPersisted) throws IOException {
    incident.setIncidentSeverity(IncidentSeverityEnum.CONFIRMED_MALPRACTICE);
    incident.setExternalIncidentChangedDateTime(OffsetDateTime.of
        (LocalDateTime.parse("2021-04-26T15:20:35.723"),ZoneOffset.UTC));
    incident.setEventDateTime(LocalDateTime.now(ZoneOffset.UTC).minusHours(1));
    CheckOutcome checkOutcome = new CheckOutcome();
    CheckOutcomeType checkoutcomeUUID = new CheckOutcomeType();
    checkoutcomeUUID.setCheckOutcomeTypeUuid(UUID.randomUUID());
	checkOutcome.setCheckOutcomeType(checkoutcomeUUID);
	CheckOutcomeStatus checkoutcomeStatus = new CheckOutcomeStatus();
	checkoutcomeStatus.setCheckOutcomeStatus(UUID.randomUUID().toString());
	checkOutcome.setCheckOutcomeStatus(checkoutcomeStatus );
	incident.setCheckOutcomeByCheckOutcomeUuid(null);
	incident.getIncidentCategoryByIncidentCategoryUuid().setEligibleForIntegrityCheck(false);
    lrwIncidentDetails.getDocumentsAttached().get(0).setDocumentName("Evd.pdf");
    Mockito.when(
        incidentRepository.findByExternalIncidentIdAndBookingUuidAndBookingLineUuid(
            lrwIncidentDetails.getExternalIncidentId(), lrwIncidentDetails.getBookingUuId(),
            lrwIncidentDetails.getBookingLineUuId()))
        .thenReturn(Optional.of(incident));
    Mockito.when(incidentRepository.save(ArgumentMatchers.any())).thenReturn(incident);
    doNothing().when(checkOutcomeStatusHelper).setCheckOutcomeStatus(any(), anyString(),any());
    doNothing().when(testDayIncidentDomainService).publishEvent(any());

    testDayIncidentDomainService.on(lrwIncidentDetails);
    Mockito.verify(incidentRepository).save(incidentArgumentCaptor.capture());
  }

  @ParameterizedTest
  @MethodSource("argumentProviderForTestDayIncidentTestTech")
  void testOnCommand_shouldPersistTechIncident_withSeverityConfirm_MalpracticeForSubType(
		  ReceivedIncidentDetailsV1 lrwIncidentDetails,
      IncidentCategory techIncidentCategory,
      IncidentType techIncidentType,
      IncidentStatusType flaggedIncidentStatusType,
      Incident incident,
      Incident incidentPersisted) throws IOException {
    lrwIncidentDetails
        .setIncidentSubTypeUuid(UUID.fromString("ed5f1e14-a155-4d3a-83e0-592ac2899011"));
    incident.setIncidentSeverity(IncidentSeverityEnum.CONFIRMED_MALPRACTICE);
    incident.setExternalIncidentChangedDateTime(OffsetDateTime.of
        (LocalDateTime.parse("2021-04-26T15:20:35.723"),ZoneOffset.UTC));
    incident.setEventDateTime(LocalDateTime.now(ZoneOffset.UTC).minusDays(1));
    lrwIncidentDetails.getDocumentsAttached().get(0)
        .setDocumentName("Evd.mov");
    Mockito.when(
        incidentRepository.findByExternalIncidentIdAndBookingUuidAndBookingLineUuid(
            lrwIncidentDetails.getExternalIncidentId(), lrwIncidentDetails.getBookingUuId(),
            lrwIncidentDetails.getBookingLineUuId()))
        .thenReturn(Optional.of(incident));
    Mockito.when(incidentRepository.save(ArgumentMatchers.any())).thenReturn(incident);
    doNothing().when(checkOutcomeStatusHelper).setCheckOutcomeStatus(any(), anyString(),any());
    doNothing().when(testDayIncidentDomainService).publishEvent(any());
    
    testDayIncidentDomainService.on(lrwIncidentDetails);

    Mockito.verify(incidentRepository).save(incidentArgumentCaptor.capture());
  }

  @ParameterizedTest
  @MethodSource("argumentProviderForTestDayIncidentTestTech")
  void testOnCommand_shouldPersistTechIncident_withSeverityConfirm_MalpracticeForUpdateIncident(
	  ReceivedIncidentDetailsV1 lrwIncidentDetails,
      IncidentCategory techIncidentCategory,
      IncidentType techIncidentType,
      IncidentStatusType flaggedIncidentStatusType,
      Incident incident,
      Incident incidentPersisted) throws IOException {
    lrwIncidentDetails
        .setIncidentSubTypeUuid(UUID.fromString("ed5f1e14-a155-4d3a-83e0-592ac2899011"));
    incident.setIncidentSeverity(IncidentSeverityEnum.CONFIRMED_MALPRACTICE);
    incident.setExternalIncidentChangedDateTime(OffsetDateTime.of
        (LocalDateTime.parse("2021-04-26T15:20:35.723"),ZoneOffset.UTC));
    incident.setEventDateTime(LocalDateTime.now().minusDays(5));
    lrwIncidentDetails.getDocumentsAttached().get(0)
        .setDocumentName("Evd.txt");
    Mockito.when(
        incidentRepository.findByExternalIncidentIdAndBookingUuidAndBookingLineUuid(lrwIncidentDetails.getExternalIncidentId(),
            lrwIncidentDetails.getBookingUuId(),
            lrwIncidentDetails.getBookingLineUuId()))
        .thenReturn(Optional.of(incident));

    Mockito.when(incidentRepository.save(ArgumentMatchers.any())).thenReturn(incident);
    doNothing().when(testDayIncidentDomainService).publishEvent(any());
    when(bookingRepository.findById(UUID.fromString("c2b58881-9ca3-49f0-8a19-a45d05a0dbed"))).thenReturn(Optional.of(BookingDetailsEvent.setBookingForTest()));
    when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
                    incident.getBookingUuid(), CheckOutcomeStatusEvent.getCheckOutcomeType().getCheckOutcomeTypeUuid()))
    .thenReturn(Optional.of(CheckOutcomeStatusEvent.getCheckoutCome()));
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode("LRW_INC_CHK"))
            .thenReturn(Optional.of(CheckOutcomeStatusEvent.getCheckOutcomeType()));
    testDayIncidentDomainService.on(lrwIncidentDetails);

    Mockito.verify(incidentRepository).save(incidentArgumentCaptor.capture());
  }
  
  @ParameterizedTest
  @MethodSource("argumentProviderForTestDayIncidentTestTech")
  void testOnCommand_shouldPersistTechIncidentOnInvalidFlow_For_Document_withSeverityConfirm_MalpracticeForUpdateIncident(
		  ReceivedIncidentDetailsV1 lrwIncidentDetails,
      IncidentCategory techIncidentCategory,
      IncidentType techIncidentType,
      IncidentStatusType flaggedIncidentStatusType,
      Incident incident,
      Incident incidentPersisted) throws IOException {
    lrwIncidentDetails.setIncidentSubTypeUuid(UUID.fromString("ed5f1e14-a155-4d3a-83e0-592ac2899011"));
    incident.setIncidentSeverity(IncidentSeverityEnum.CONFIRMED_MALPRACTICE);
    incident.setExternalIncidentChangedDateTime(OffsetDateTime.of
        (LocalDateTime.parse("2021-04-26T15:20:35.723"),ZoneOffset.UTC));
    incident.setEventDateTime(LocalDateTime.now().minusDays(5));
    lrwIncidentDetails.getDocumentsAttached().get(0)
        .setDocumentName("Evd.svg");
    Mockito.when(
            incidentRepository.findByExternalIncidentIdAndBookingUuidAndBookingLineUuid(lrwIncidentDetails.getExternalIncidentId(),
                lrwIncidentDetails.getBookingUuId(),
                lrwIncidentDetails.getBookingLineUuId()))
        .thenReturn(Optional.of(incident));
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode("LRW_INC_CHK")).thenReturn(Optional.of(IncidentDetailsEvent.getCheckOutcomeType()));
    when(bookingRepository.findById(UUID.fromString("c2b58881-9ca3-49f0-8a19-a45d05a0dbed"))).thenReturn(Optional.of(BookingDetailsEvent.setBookingForTest()));
    Mockito.when(incidentRepository.save(ArgumentMatchers.any())).thenReturn(incident);
    doNothing().when(testDayIncidentDomainService).publishEvent(any());
    Assertions.assertDoesNotThrow(()->
    testDayIncidentDomainService.on(lrwIncidentDetails));

  }
  @ParameterizedTest
  @MethodSource("argumentProviderForTestDayIncidentTestTech")
  void testOnCommand_shouldPersistLRWIncident_withSeverityWARING(
          ReceivedIncidentDetailsV1 lrwIncidentDetails,
          IncidentCategory techIncidentCategory,
          IncidentType techIncidentType,
          IncidentStatusType flaggedIncidentStatusType,
          Incident incident,
          Incident incidentPersisted) throws IOException {
    lrwIncidentDetails
            .setIncidentSubTypeUuid(UUID.fromString("ed5f1e14-a155-4d3a-83e0-592ac2899011"));
    incident.setIncidentSeverity(IncidentSeverityEnum.WARNING);
    incident.setExternalIncidentChangedDateTime(OffsetDateTime.of
            (LocalDateTime.now(),ZoneOffset.UTC));
    incident.setEventDateTime(LocalDateTime.now().minusDays(1));
    lrwIncidentDetails.getDocumentsAttached().get(0)
            .setDocumentName("Evd.txt");
    Mockito.when(
                    incidentRepository.findByExternalIncidentIdAndBookingUuidAndBookingLineUuid(lrwIncidentDetails.getExternalIncidentId(),
                            lrwIncidentDetails.getBookingUuId(),
                            lrwIncidentDetails.getBookingLineUuId()))
            .thenReturn(Optional.of(incident));

   Mockito.when(incidentRepository.save(ArgumentMatchers.any())).thenReturn(incident);
    doNothing().when(testDayIncidentDomainService).publishEvent(any());
    when(bookingRepository.findById(UUID.fromString("c2b58881-9ca3-49f0-8a19-a45d05a0dbed"))).thenReturn(Optional.of(BookingDetailsEvent.setBookingForTest()));
    when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
            incident.getBookingUuid(), CheckOutcomeStatusEvent.getCheckOutcomeType().getCheckOutcomeTypeUuid()))
    .thenReturn(Optional.of(CheckOutcomeStatusEvent.getCheckoutCome()));
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode("LRW_INC_CHK"))
            .thenReturn(Optional.of(CheckOutcomeStatusEvent.getCheckOutcomeType()));
    testDayIncidentDomainService.on(lrwIncidentDetails);

    Mockito.verify(incidentRepository).save(incidentArgumentCaptor.capture());
    Mockito.verify(checkOutcomeStatusHelper,times(0)).
            getCheckOutComeStatus(RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_FAILED);
    Mockito.verify(checkOutcomeStatusHelper,times(0)).
            getCheckOutComeStatus(RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_REVIEW);
    Mockito.verify(checkOutcomeStatusHelper,times(0)).
            getCheckOutComeStatus(RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_PASSED);
  }

  @ParameterizedTest
  @MethodSource("argumentProviderForTestDayIncidentTestTech")
  void testLRWEvidences( ReceivedIncidentDetailsV1 lrwIncidentDetails,
                     IncidentCategory techIncidentCategory,
                     IncidentType techIncidentType,
                     IncidentStatusType flaggedIncidentStatusType,
                     Incident incident,
                     Incident incidentPersisted) throws IOException {
    lrwIncidentDetails
            .setIncidentSubTypeUuid(UUID.fromString("ed5f1e14-a155-4d3a-83e0-592ac2899011"));
    incident.setIncidentSeverity(IncidentSeverityEnum.CONFIRMED_MALPRACTICE);
    incident.setExternalIncidentChangedDateTime(OffsetDateTime.of
            (LocalDateTime.parse("2021-04-26T15:20:35.723"),ZoneOffset.UTC));
    lrwIncidentDetails.getDocumentsAttached().get(0)
            .setDocumentName("Evd.txt");
    String key =
            "incident/INC123/" + incident.getExternalIncidentChangedDateTime().toString() + "/Evd.txt";
    String preSignedUrl = lrwIncidentDetails.getDocumentsAttached().get(0).getDocumentURL();


    doNothing().when(fileStorageHelper)
        .uploadFileToS3FromPresignedUrl(preSignedUrl, key, "RI_BUCKET");

   Assertions.assertDoesNotThrow(()->testDayIncidentDomainService.setEvidence(lrwIncidentDetails,incident));
  }

  @Test
  void whenPayloadEventDatetimeisBeforeDBDatetime() {

    ReceivedIncidentDetailsV1 receivedIncidentDetailsV1 = TestDayIncidentRaisedEvent.getLRWIncidentDetails();

    Incident incidentTech = getTechIncident();
    incidentTech.setEventDateTime(LocalDateTime.parse("2023-06-14T10:15:30"));
    CMDSHeaderContext ctx = ThreadLocalHeaderContext.getContext();
    ctx.setEventDateTime(LocalDateTime.parse("2023-05-10T10:15:30"));
    ThreadLocalHeaderContext.setContext(ctx);

    IncidentCategory techIncidentCategory = getTechIncidentCategory();
    IncidentStatusType flaggedIncidentStatusType = getFlaggedIncidentStatusType();
    IncidentType incidentTypeTech = getParentIncidentTypeTech();
    incidentTech.setIncidentTypeByIncidentTypeUuid(incidentTypeTech);
    incidentTech.setIncidentCategoryByIncidentCategoryUuid(techIncidentCategory);
    incidentTech.setIncidentStatusTypeByIncidentStatusTypeUuid(flaggedIncidentStatusType);

    Assertions.assertThrows(ResultIntegrityValidationException.class, () -> testDayIncidentDomainService.incidentValidation(receivedIncidentDetailsV1,incidentTech));
  }

  private static Stream<Arguments> argumentProviderForTestDayIncidentTestTech() {
	ReceivedIncidentDetailsV1 receivedIncidentDetailsV1 = TestDayIncidentRaisedEvent.getLRWIncidentDetails();
    IncidentCategory techIncidentCategory = getTechIncidentCategory();
    IncidentStatusType flaggedIncidentStatusType = getFlaggedIncidentStatusType();
    IncidentType incidentTypeTech = getParentIncidentTypeTech();
    Incident incidentTech = getTechIncident();
    Incident incidentTechPersisted = getTechIncident();
    incidentTechPersisted.setIncidentUuid(UUID.randomUUID());
    return Stream.of(
        Arguments.of(
        	receivedIncidentDetailsV1,
            techIncidentCategory,
            incidentTypeTech,
            flaggedIncidentStatusType,
            incidentTech,
            incidentTechPersisted));
  }
}
