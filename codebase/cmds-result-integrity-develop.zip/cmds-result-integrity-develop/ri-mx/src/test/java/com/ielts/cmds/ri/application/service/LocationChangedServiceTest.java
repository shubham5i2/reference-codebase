package com.ielts.cmds.ri.application.service;

import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.lpr.common.out.model.LocationV1;
import com.ielts.cmds.ri.LocationTestSetup;
import com.ielts.cmds.ri.domain.service.LocationChangedDomainService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LocationChangedServiceTest {

	@InjectMocks
	LocationChangedService locationChangedService;

	@Mock
	private LocationChangedDomainService locationChangedDomainService;

	@Test
	void testProcess() {
		CMDSHeaderContext ctx = new CMDSHeaderContext();
		ctx.setCorrelationId(UUID.randomUUID());
		ThreadLocalHeaderContext.setContext(ctx);
		
		locationChangedService.process(LocationTestSetup.getLocationV1Data());
		
		verify(locationChangedDomainService, times(1)).on(ArgumentMatchers.any());
	}

	@Test
	void testProcessException() {
		CMDSHeaderContext ctx = new CMDSHeaderContext();
		ctx.setCorrelationId(UUID.randomUUID());
		ThreadLocalHeaderContext.setContext(ctx);
		doThrow(RuntimeException.class).when(locationChangedDomainService).on(ArgumentMatchers.any());
		
		LocationV1  loc = LocationTestSetup.getLocationV1Data();
		
		RuntimeException expectedException = Assertions.assertThrows(RuntimeException.class, 
		() -> 
			locationChangedService.process(loc));
		
		assertEquals(RuntimeException.class.getName(), expectedException.getClass().getName());
	}

}
