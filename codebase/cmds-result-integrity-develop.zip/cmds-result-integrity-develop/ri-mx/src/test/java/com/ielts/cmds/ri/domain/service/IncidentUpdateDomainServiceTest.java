package com.ielts.cmds.ri.domain.service;

import static com.ielts.cmds.ri.utils.RIConstants.CheckOutcomeTypeConstants.CHK_OUT_TYPE_SPEAKING_INC_CHK_CODE;
import static com.ielts.cmds.ri.utils.RIConstants.PermissionId.RI_INCIDENT_UPDATE;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_PASSED;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.LRW_INC_CHK;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.SPK_INC_CHK;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import javax.validation.ConstraintViolation;
import javax.validation.metadata.ConstraintDescriptor;

import org.hibernate.validator.internal.engine.ConstraintViolationImpl;
import org.hibernate.validator.internal.engine.path.PathImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.evt074.ResultIntegrityIncidentDetailsWrapperV1;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.ri.common.model.out.IncidentSeverityEnum;
import com.ielts.cmds.ri.common.model.out.UpdateIncidentDetailsV1;
import com.ielts.cmds.ri.domain.enums.ExternalIncidentStatusEnum;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeType;
import com.ielts.cmds.ri.infrastructure.entity.Incident;
import com.ielts.cmds.ri.infrastructure.repository.BookingLineRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentCategoryRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentStatusTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.ProductRepository;
import com.ielts.cmds.ri.utils.CheckOutcomeStatusEvent;
import com.ielts.cmds.ri.utils.IncidentUpdateTestSetup;
import com.ielts.cmds.ri.utils.RICommonUtil;
import com.ielts.cmds.ri.utils.TestDayIncidentRaisedEvent;

@ExtendWith(MockitoExtension.class)
class IncidentUpdateDomainServiceTest {

    @InjectMocks
    @Spy
    IncidentUpdateDomainService incidentUpdateDomainService;

    @Mock
    private IncidentRepository incidentRepository;

    @Mock
    private CMDSErrorResolver<Object> errorResolver;

    /**
     * The Violations.
     */
    @Mock
    Set<ConstraintViolation<Object>> violations;


    @Mock
    private IncidentTypeRepository incidentTypeRepository;

    @Mock
    private IncidentStatusTypeRepository incidentStatusTypeRepository;

    @Mock
    CheckOutcomeRepository checkOutcomeRepository;

    @Mock
    CheckOutcomeTypeRepository checkOutcomeTypeRepository;

    @Mock
    CheckOutcomeStatusRepository checkOutcomeStatusRepository;

    @Mock
    IncidentCategoryRepository incidentCategoryRepository;

    @Mock
    private ProductRepository productRepository;

    @Mock
    private BookingLineRepository bookingLineRepository;

    @Mock
    RICommonUtil commonUtil;

    Incident incident;

    @Mock
    OutcomeStatusRepository outcomeStatusRepository;

    @BeforeEach
    void setup() {
        CMDSHeaderContext header = IncidentUpdateTestSetup.generateEventHeader();
        ThreadLocalHeaderContext.setContext(header);
    }

    @Test
    void testOn_Method() throws RbacValidationException {

        UpdateIncidentDetailsV1 detailsV1 = IncidentUpdateTestSetup.updateIncidentDetailsV1();
        detailsV1.getIncidentDetails().setIncidentSeverity(IncidentSeverityEnum.CONFIRMED_MALPRACTICE);

        when(incidentRepository.findByIncidentUuid(UUID.fromString(detailsV1
                .getIncidentDetails().getIncidentUuid())))
                .thenReturn(Optional.of(IncidentUpdateTestSetup.getIncident()));

        when(incidentTypeRepository.findById(UUID.fromString(detailsV1.getIncidentDetails().getIncidentTypeUuid())))
                .thenReturn(Optional.of(IncidentUpdateTestSetup.incidentType()));

        when(incidentStatusTypeRepository.findById(UUID.fromString(detailsV1.getIncidentDetails().getIncidentStatusTypeUuid())))
                .thenReturn(Optional.of(IncidentUpdateTestSetup.incidentStatusType()));

        when(incidentCategoryRepository.findByIncidentCategoryUuid(UUID.fromString(detailsV1.getIncidentDetails().getIncidentCategoryUuid())))
                .thenReturn(Optional.of(TestDayIncidentRaisedEvent.getIncidentCategory()));


        when(checkOutcomeStatusRepository.findByCheckOutcomeStatusCode(CHECK_OUTCOME_STATUS_CODE_PASSED))
                .thenReturn(Optional.of(IncidentUpdateTestSetup.getCheckOutcomeStatusAsPassed()));


        when(incidentRepository.save(ArgumentMatchers.any())).thenReturn(IncidentUpdateTestSetup.getIncident());

        when(incidentRepository.findByCheckOutcomeByCheckOutcomeUuidAndBookingUuid(any(),any())).thenReturn(
            TestDayIncidentRaisedEvent.getIncidentList());


        when(commonUtil.hasAllAccess("", RI_INCIDENT_UPDATE)).thenReturn(true);

        doNothing().when(incidentUpdateDomainService).publishEvent(any());
        final Executable executable = () -> incidentUpdateDomainService.on(detailsV1);
        assertDoesNotThrow(executable);
    }

    @Test
    void testOn_Method_when_external_status_is_present() throws RbacValidationException {

        UpdateIncidentDetailsV1 detailsV1 = IncidentUpdateTestSetup.updateIncidentDetailsV1();
        detailsV1.getIncidentDetails().setIncidentSeverity(IncidentSeverityEnum.CONFIRMED_MALPRACTICE);

        Incident incident = IncidentUpdateTestSetup.getIncident();
        incident.setCheckOutcomeByCheckOutcomeUuid(null);
        incident.setExternalIncidentStatus(ExternalIncidentStatusEnum.CONFIRMED);

        when(incidentRepository.findByIncidentUuid(UUID.fromString(detailsV1
            .getIncidentDetails().getIncidentUuid())))
            .thenReturn(Optional.of(incident));

        when(incidentTypeRepository.findById(UUID.fromString(detailsV1.getIncidentDetails().getIncidentTypeUuid())))
            .thenReturn(Optional.of(IncidentUpdateTestSetup.incidentType()));

        when(incidentStatusTypeRepository.findById(UUID.fromString(detailsV1.getIncidentDetails().getIncidentStatusTypeUuid())))
            .thenReturn(Optional.of(IncidentUpdateTestSetup.incidentStatusType()));

        when(incidentCategoryRepository.findByIncidentCategoryUuid(UUID.fromString(detailsV1.getIncidentDetails().getIncidentCategoryUuid())))
            .thenReturn(Optional.of(TestDayIncidentRaisedEvent.getIncidentCategory()));


        when(checkOutcomeStatusRepository.findByCheckOutcomeStatusCode(CHECK_OUTCOME_STATUS_CODE_PASSED))
            .thenReturn(Optional.of(IncidentUpdateTestSetup.getCheckOutcomeStatusAsPassed()));


        when(incidentRepository.save(ArgumentMatchers.any())).thenReturn(incident);

        when(incidentRepository.findByCheckOutcomeByCheckOutcomeUuidAndBookingUuid(any(),any())).thenReturn(
            TestDayIncidentRaisedEvent.getIncidentList());

        CheckOutcomeType checkOutcomeType = CheckOutcomeStatusEvent.getCheckOutcomeType();
        checkOutcomeType.setCheckOutcomeType(SPK_INC_CHK);

        when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(CHK_OUT_TYPE_SPEAKING_INC_CHK_CODE))
            .thenReturn(Optional.of(checkOutcomeType));


        when(commonUtil.hasAllAccess("", RI_INCIDENT_UPDATE)).thenReturn(true);

        Mockito.doNothing()
            .when(incidentUpdateDomainService)
            .publishEvent(ArgumentMatchers.any());

        final Executable executable = () -> incidentUpdateDomainService.on(detailsV1);
        assertDoesNotThrow(executable);
    }

    @Test
    void testOn_MethodWithConfirmedStatus(

    ) throws  RbacValidationException {

        UpdateIncidentDetailsV1 detailsV1 = IncidentUpdateTestSetup.updateIncidentDetailsV1();
        detailsV1.getIncidentDetails().setIncidentSeverity(IncidentSeverityEnum.CONFIRMED_MALPRACTICE);

        when(incidentRepository.findByIncidentUuid(UUID.fromString(detailsV1
            .getIncidentDetails().getIncidentUuid())))
            .thenReturn(Optional.of(IncidentUpdateTestSetup.getIncident()));

        when(incidentTypeRepository.findById(UUID.fromString(detailsV1.getIncidentDetails().getIncidentTypeUuid())))
            .thenReturn(Optional.of(IncidentUpdateTestSetup.incidentType()));

        when(incidentStatusTypeRepository.findById(UUID.fromString(detailsV1.getIncidentDetails().getIncidentStatusTypeUuid())))
            .thenReturn(Optional.of(IncidentUpdateTestSetup.incidentStatusType()));

        when(incidentCategoryRepository.findByIncidentCategoryUuid(UUID.fromString(detailsV1.getIncidentDetails().getIncidentCategoryUuid())))
            .thenReturn(Optional.of(TestDayIncidentRaisedEvent.getIncidentCategory()));




        when(incidentRepository.save(ArgumentMatchers.any())).thenReturn(IncidentUpdateTestSetup.getIncident());

        when(incidentRepository.findByCheckOutcomeByCheckOutcomeUuidAndBookingUuid(any(),any())).thenReturn(
            TestDayIncidentRaisedEvent.getIncidentListWithConfirmed());


        when(commonUtil.hasAllAccess("", RI_INCIDENT_UPDATE)).thenReturn(true);

        Mockito.doNothing()
            .when(incidentUpdateDomainService)
            .publishEvent(ArgumentMatchers.any());

        final Executable executable = () -> incidentUpdateDomainService.on(detailsV1);
        assertDoesNotThrow(executable);
    }


    @Test
    void testUpdateIncidentComment() throws RbacValidationException, JsonProcessingException {

        UpdateIncidentDetailsV1 detailsV1 = IncidentUpdateTestSetup.updateIncidentDetailsV1();

        when(incidentRepository.findByIncidentUuid(UUID.fromString(detailsV1
                .getIncidentDetails().getIncidentUuid())))
                .thenReturn(Optional.of(IncidentUpdateTestSetup.getIncident()));


        when(incidentCategoryRepository.findByIncidentCategoryUuid(UUID.fromString(detailsV1.getIncidentDetails().getIncidentCategoryUuid())))
                .thenReturn(Optional.of(IncidentUpdateTestSetup.getPRCIncidentCategory()));


        when(incidentRepository.save(ArgumentMatchers.any())).thenReturn(IncidentUpdateTestSetup.getIncident());

        when(commonUtil.hasAllAccess("", RI_INCIDENT_UPDATE)).thenReturn(true);

        Mockito.doNothing()
                .when(incidentUpdateDomainService)
                .publishEvent(ArgumentMatchers.any());

        incidentUpdateDomainService.on(detailsV1);
        assertNotNull(detailsV1);
    }

    @Test
    void testGetNewCheckOutCome() {
        when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(LRW_INC_CHK))
                .thenReturn(Optional.of(CheckOutcomeStatusEvent.getCheckOutcomeType()));

        incidentUpdateDomainService.getNewCheckOutcome(TestDayIncidentRaisedEvent.getIncident());
        assertNotNull(TestDayIncidentRaisedEvent.getIncident());
    }

    @Test
    void testWhenUserDoes_Not_HaveAccess() throws JsonProcessingException, RbacValidationException {

        UpdateIncidentDetailsV1 detailsV1 = IncidentUpdateTestSetup.updateIncidentDetailsV1();

        when(commonUtil.hasAllAccess("", RI_INCIDENT_UPDATE)).thenReturn(false);

        Set<ConstraintViolation<Object>> constraintViolation =
                getSetforNullViolationOfEventBody("V_unauthorised_to_update_incident");
        when(errorResolver.populatErrorResponse(constraintViolation, "PUT/v1/incident/update"))
                .thenReturn(new CMDSErrorResponse());
        doNothing().when(incidentUpdateDomainService).publishEvent(any(),any());
        incidentUpdateDomainService.on(detailsV1);
        assertThat(detailsV1).isNotNull();
    }

    @Test
    void testUIPublishWhenEventBodyNull() throws JsonProcessingException, RbacValidationException {

        CMDSHeaderContext headerContext = IncidentUpdateTestSetup.generateEventHeader();
        Set<ConstraintViolation<Object>> constraintViolation =
                getSetforNullViolationOfEventBody("V_unauthorised_to_update_incident");

        when(errorResolver.populatErrorResponse(constraintViolation, "PUT/v1/incident/update"))
                .thenReturn(new CMDSErrorResponse());
        doNothing().when(incidentUpdateDomainService).publishEvent(any(), any());
        incidentUpdateDomainService.publishIncidentUpdateEventToOutBoundTopic(null, constraintViolation, headerContext);
        verify(incidentUpdateDomainService).publishEvent(any(), any());

    }

    @Test
    void testUIPublishWhenEventBodyNotNull() throws JsonProcessingException, RbacValidationException {

        Incident updatedIncident = IncidentUpdateTestSetup.getIncident();
        CMDSHeaderContext headerContext = IncidentUpdateTestSetup.generateEventHeader();
        ResultIntegrityIncidentDetailsWrapperV1 wrapperV1 =
                new ResultIntegrityIncidentDetailsWrapperV1();
        wrapperV1.setIncidentDetails(IncidentUpdateTestSetup.createIncidentDetailsForUpdateV2());
        when(commonUtil.populateIntegrityDetailsRaisedEventWithEvidence(updatedIncident))
                .thenReturn(wrapperV1);
        doNothing().when(incidentUpdateDomainService).publishEvent(wrapperV1);
        incidentUpdateDomainService.publishIncidentUpdateEventToOutBoundTopic(updatedIncident, null, headerContext);
        verify(incidentUpdateDomainService).publishEvent(wrapperV1);

    }

    private static Set<ConstraintViolation<Object>> getSetforNullViolationOfEventBody(
            final String interpolatedMessage) {

        Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
        final String messageTemplate = null;
        final Class<Object> rootBeanClass = null;
        final Object rootBean = null;
        final Object leafBeanInstance = null;
        final Object value = null;
        final javax.validation.Path propertyPath =
                PathImpl.createPathFromString("unauthorisedToUpdateIncident");
        final ConstraintDescriptor<?> constraintDescriptor = null;
        final Map<String, Object> messageParameters = new HashMap<>();
        final Map<String, Object> expressionVariables = new HashMap<>();
        ConstraintViolation<Object> constraintViolationImpl1 =
                        ConstraintViolationImpl.forBeanValidation(
                                messageTemplate,
                                messageParameters,
                                expressionVariables,
                                interpolatedMessage,
                                rootBeanClass,
                                rootBean,
                                leafBeanInstance,
                                value,
                                propertyPath,
                                constraintDescriptor,
                                null);

        violationSet.add(constraintViolationImpl1);
        return violationSet;
    }

}