package com.ielts.cmds.ri.domain.service;

import static com.ielts.cmds.ri.utils.RIConstants.EventType.RESULT_INTEGRITY_LOCATION_REJECTED;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Stream;

import javax.validation.ConstraintViolation;
import javax.validation.metadata.ConstraintDescriptor;

import org.hibernate.validator.internal.engine.ConstraintViolationImpl;
import org.hibernate.validator.internal.engine.path.PathImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.lpr.common.enums.LocationStatus;
import com.ielts.cmds.lpr.common.enums.LocationTypeCode;
import com.ielts.cmds.lpr.common.out.model.LocationV1;
import com.ielts.cmds.ri.LocationTestSetup;
import com.ielts.cmds.ri.application.exception.ResultIntegrityValidationException;
import com.ielts.cmds.ri.infrastructure.entity.Location;
import com.ielts.cmds.ri.infrastructure.repository.LocationRepository;

@ExtendWith(MockitoExtension.class)
class LocationChangedDomainServiceTest {

    @InjectMocks
    @Spy
    LocationChangedDomainService locationChangedDomainService;

    @Mock
    LocationRepository locationRepo;
    @Mock
    private CMDSErrorResolver<Object> errorResolver;

    @BeforeEach
    void setup() {
        CMDSHeaderContext ctx = new CMDSHeaderContext();
        ctx.setCorrelationId(UUID.randomUUID());
        ctx.setTransactionId(UUID.randomUUID());
        ctx.setPartnerCode("CA");
        ctx.setEventDateTime(LocalDateTime.now());
        ThreadLocalHeaderContext.setContext(ctx);
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForLocationServiceTest")
    void onPublishingSuccessEvent(
            LocationV1 locationV1, Location expectedLocation
    ) {
        locationV1.setLocationTypeCode(LocationTypeCode.PHYSICAL_BUILDING);
        expectedLocation.setEventDatetime(LocalDateTime.parse("2023-06-14T10:15:30"));

        Mockito.doNothing().when(locationChangedDomainService).publishEvent(ArgumentMatchers.any());
        when(locationRepo.findById(UUID.fromString(String.valueOf(locationV1.getLocationUuid())))).thenReturn(Optional.of(expectedLocation));
        doReturn(expectedLocation).when(locationRepo).save(ArgumentMatchers.any());
        locationChangedDomainService.on(locationV1);
        assertNotNull(locationV1);
    }

    @Test
    void whenPayloadEventDatetimeisBeforeDBDatetime() {

        LocationV1 locationV1 = LocationTestSetup.getLocationV1Data();
        Location expectedLocation = LocationTestSetup.getLocationData();
        expectedLocation.setEventDatetime(LocalDateTime.parse("2023-06-14T10:15:30"));
        CMDSHeaderContext ctx = ThreadLocalHeaderContext.getContext();
        ctx.setEventDateTime(LocalDateTime.parse("2023-05-10T10:15:30"));
        ThreadLocalHeaderContext.setContext(ctx);
        
        doThrow(ResultIntegrityValidationException.class).when(locationChangedDomainService).locationValidation(locationV1, expectedLocation);
        Mockito.doNothing().when(locationChangedDomainService).publishEvent(ArgumentMatchers.any(), ArgumentMatchers.any());

        Set<ConstraintViolation<Object>> constraintViolation =
                getSetforNullViolationOfEventBody("E_reject_when_datetime_is_obsolete");
        when(errorResolver.populatErrorResponse(constraintViolation, "ResultIntegrityLocationRejected"))
                .thenReturn(new CMDSErrorResponse());

        when(locationRepo.findById(UUID.fromString(String.valueOf(locationV1.getLocationUuid())))).thenReturn(Optional.of(expectedLocation));
        locationChangedDomainService.on(locationV1);
        assertEquals(RESULT_INTEGRITY_LOCATION_REJECTED, ThreadLocalHeaderContext.getContext().getEventName());
    }
    public Set<ConstraintViolation<Object>> getSetforNullViolationOfEventBody(
            final String interpolatedMessage) {

        Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
        final String messageTemplate = null;
        final String interpolatedHeaderMessage = interpolatedMessage;
        final Class<Object> rootBeanClass = null;
        final Object rootBean = null;
        final Object leafBeanInstance = null;
        final Object value = null;
        final javax.validation.Path propertyPath =
                PathImpl.createPathFromString("rejectwhendatetimeisobsolete");
        final ConstraintDescriptor<?> constraintDescriptor = null;
        final Map<String, Object> messageParameters = new HashMap<>();
        final Map<String, Object> expressionVariables = new HashMap<>();
        ConstraintViolation<Object> constraintViolationImpl1 =
                (ConstraintViolationImpl<Object>)
                        ConstraintViolationImpl.forBeanValidation(
                                messageTemplate,
                                messageParameters,
                                expressionVariables,
                                interpolatedHeaderMessage,
                                rootBeanClass,
                                rootBean,
                                leafBeanInstance,
                                value,
                                propertyPath,
                                constraintDescriptor,
                                null);

        violationSet.add(constraintViolationImpl1);
        return violationSet;
    }

    /*
     * When update location request of location type TEST_CENTRE is received then
     * location should be updated and validated against the expected location
     */
    @ParameterizedTest
    @MethodSource("argumentsProviderForLocationServiceTest")
    void updateLocation_whenLocationTypeisTestCentre_ThenLocationIsUpdatedAndValidated(
            LocationV1 locationV1, Location expectedLocation) {
        // Given
        expectedLocation.setLocationTypeCode(LocationTypeCode.TEST_CENTRE);

        Location inputDBLocation = spy(expectedLocation);
        inputDBLocation.setLocationName("IDP Sydney");
        inputDBLocation.setLocationStatus(LocationStatus.INACTIVE);

        Location actualLocation = locationChangedDomainService.updateLocation(inputDBLocation, locationV1);

        // then
        assertEquals(expectedLocation.getLocationUuid(), actualLocation.getLocationUuid());
        assertEquals(expectedLocation.getParentLocationUuid(), actualLocation.getParentLocationUuid());
        assertEquals(expectedLocation.getLocationStatus(), actualLocation.getLocationStatus());
        assertEquals(expectedLocation.getLocationTypeCode(), actualLocation.getLocationTypeCode());
        assertEquals(expectedLocation.getPartnerCode(), actualLocation.getPartnerCode());
        assertEquals(expectedLocation.getTestCentreNumber(), actualLocation.getTestCentreNumber());
        assertEquals(expectedLocation.getLocationName(), actualLocation.getLocationName());

    }

    /*
     * When update location request of location type PHYSICAL_BUILDING and approved
     * products is empty then location should be updated and productLocationRelation
     * List is empty
     */
    @ParameterizedTest
    @MethodSource("argumentsProviderForLocationServiceTest")
    void updateLocation_whenApprovedProductListIsEmptyAndLocTypeIsPhysicalBuilding_ThenProdLocRelationListIsEmptyAndLocIsUpdated(
            LocationV1 locationV1, Location expectedLocation) {
        // Given
        Location inputDBLocation = spy(expectedLocation);
        inputDBLocation.setLocationName("IDP Sydney");
        inputDBLocation.setLocationStatus(LocationStatus.INACTIVE);

        locationV1.setLocationTypeCode(LocationTypeCode.PHYSICAL_BUILDING);
        locationV1.setApprovedProducts(new ArrayList<>());

        expectedLocation.setLocationTypeCode(LocationTypeCode.PHYSICAL_BUILDING);

        Location testCentreLoc = spy(expectedLocation);
        testCentreLoc.setLocationUuid(expectedLocation.getParentLocationUuid());
        testCentreLoc.setLocationTypeCode(LocationTypeCode.TEST_CENTRE);
        testCentreLoc.setParentLocationUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46595"));
        Location actualLocation = locationChangedDomainService.updateLocation(inputDBLocation, locationV1);

        // then
        assertEquals(expectedLocation.getLocationUuid(), actualLocation.getLocationUuid());
        assertEquals(expectedLocation.getParentLocationUuid(), actualLocation.getParentLocationUuid());
        assertEquals(expectedLocation.getLocationStatus(), actualLocation.getLocationStatus());
        assertEquals(expectedLocation.getLocationTypeCode(), actualLocation.getLocationTypeCode());
        assertEquals(expectedLocation.getPartnerCode(), actualLocation.getPartnerCode());
        assertEquals(expectedLocation.getTestCentreNumber(), actualLocation.getTestCentreNumber());
        assertEquals(expectedLocation.getLocationName(), actualLocation.getLocationName());

    }

    /*
     * When update location request of location type ROOM is received then location
     * should be created and validated against the expected location
     */
    @ParameterizedTest
    @MethodSource("argumentsProviderForLocationServiceTest")
    void updateLocation_whenLocationTypeisRoom_ThenLocationIsUpdatedAndValidated(
            LocationV1 locationV1, Location expectedLocation) {
        // Given
        locationV1.setLocationTypeCode(LocationTypeCode.ROOM);

        expectedLocation.setLocationTypeCode(LocationTypeCode.ROOM);

        Location inputDBLocation = spy(expectedLocation);
        inputDBLocation.setLocationName("IDP Sydney");
        inputDBLocation.setLocationStatus(LocationStatus.INACTIVE);

        Location buildingLoc = spy(expectedLocation);
        buildingLoc.setLocationUuid(expectedLocation.getParentLocationUuid());
        buildingLoc.setLocationTypeCode(LocationTypeCode.PHYSICAL_BUILDING);
        buildingLoc.setParentLocationUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46594"));
        Location testCentreLoc = spy(expectedLocation);
        testCentreLoc.setLocationUuid(buildingLoc.getParentLocationUuid());
        testCentreLoc.setLocationTypeCode(LocationTypeCode.TEST_CENTRE);
        testCentreLoc.setParentLocationUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46595"));

        // When
        Location actualLocation = locationChangedDomainService.updateLocation(inputDBLocation, locationV1);

        // then
        assertEquals(expectedLocation.getLocationUuid(), actualLocation.getLocationUuid());
        assertEquals(expectedLocation.getParentLocationUuid(), actualLocation.getParentLocationUuid());
        assertEquals(expectedLocation.getLocationStatus(), actualLocation.getLocationStatus());
        assertEquals(expectedLocation.getLocationTypeCode(), actualLocation.getLocationTypeCode());
        assertEquals(expectedLocation.getPartnerCode(), actualLocation.getPartnerCode());
        assertEquals(expectedLocation.getTestCentreNumber(), actualLocation.getTestCentreNumber());
        assertEquals(expectedLocation.getLocationName(), actualLocation.getLocationName());

    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForLocationServiceTest")
    void LocationDomain_OnMethodTestNewLocation(
            LocationV1 expectedLocation) {
        final Executable executable =
                () -> locationChangedDomainService.on(expectedLocation);
       assertNotNull(executable);
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForLocationServiceTest")
    void LocationDomain_OnMethodTestExistingLocation(
            LocationV1 locationV1, Location expectedLocation) {
    	CMDSHeaderContext ctx = new CMDSHeaderContext();
    	ctx.setCorrelationId(UUID.randomUUID());
    	ctx.setTransactionId(UUID.randomUUID());
    	ctx.setPartnerCode("BC");
        ctx.setEventDateTime(LocalDateTime.now());
		ThreadLocalHeaderContext.setContext(ctx );
		doNothing().when(locationChangedDomainService).publishEvent(ArgumentMatchers.any());
		doReturn(expectedLocation).when(locationRepo).save(ArgumentMatchers.any());
        Assertions.assertDoesNotThrow(() -> locationChangedDomainService.on(locationV1));
    }

    /*
     * This is method source to provide arguments for the required test cases
     * wherever this method source has been used.
     */
    private static Stream<Arguments> argumentsProviderForLocationServiceTest() {
        Location location = LocationTestSetup.getLocationData();
        LocationV1 locationV1 = LocationTestSetup.getLocationV1Data();
        return Stream.of(Arguments.of(locationV1,location));
    }
}
