package com.ielts.cmds.ri.application.service;

import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.ids.domain.model.PRCOutcomeGeneratedNodeV1;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.domain.service.PrcOutcomeGeneratedDomainService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.UUID;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class PrcOutcomeGeneratedServiceTest {

	@InjectMocks
	private PrcOutcomeGeneratedService prcOutcomeGeneratedService;

	@Mock
	private PrcOutcomeGeneratedDomainService prcOutcomeGeneratedDomainService;

	@BeforeEach
	void setup() {
		CMDSHeaderContext ctx = new CMDSHeaderContext();
		ctx.setCorrelationId(UUID.randomUUID());
		ThreadLocalHeaderContext.setContext(ctx);
	}
	@Test
	void testProcess() {
		PRCOutcomeGeneratedNodeV1 orcOutcomeGeneratedNodeV1 = new PRCOutcomeGeneratedNodeV1();
		prcOutcomeGeneratedService.process(orcOutcomeGeneratedNodeV1);
		verify(prcOutcomeGeneratedDomainService, times(1)).on(orcOutcomeGeneratedNodeV1);
	}
	
	@Test
	void testProcessExpectedException() {
		Assertions.assertThrows(ProcessingException.class, () -> prcOutcomeGeneratedService.process(null));
	}
}
