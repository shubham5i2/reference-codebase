package com.ielts.cmds.ri.domain.service;

import static org.mockito.Mockito.doNothing;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.evt_019.BookingDetailsV1;
import com.ielts.cmds.ri.utils.BookingDetailsEvent;

@ExtendWith(MockitoExtension.class)
class BookingUpdatedDomainServiceTest {

	@InjectMocks
	@Spy
	private BookingUpdatedDomainService bookingUpdatedDomainService;

	@Test
	void bookingUpdatedCheck() throws JsonProcessingException {
		doNothing().when(bookingUpdatedDomainService).process(ArgumentMatchers.any(BookingDetailsV1.class));
		Executable executable = () -> bookingUpdatedDomainService
				.on(BookingDetailsEvent.getBookingDetailsBody());
		Assertions.assertDoesNotThrow(executable);
	}

}
