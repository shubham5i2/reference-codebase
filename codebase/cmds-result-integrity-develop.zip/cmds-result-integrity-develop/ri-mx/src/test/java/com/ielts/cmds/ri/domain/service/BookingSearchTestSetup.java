package com.ielts.cmds.ri.domain.service;

import com.ielts.cmds.infrastructure.event.context.CMDSAuditContext;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.ri.common.model.out.*;
import com.ielts.cmds.ri.infrastructure.entity.BookingCheckOutcomeView;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class BookingSearchTestSetup {

  public static CMDSHeaderContext generateEventHeader() {
    CMDSHeaderContext eventHeader = new CMDSHeaderContext();
    eventHeader.setConnectionId("ec81310d-03b6-");
    eventHeader.setCorrelationId(UUID.fromString("413b7690-990f-42ce-ab76-783af084513a"));
    eventHeader.setEventDateTime(LocalDateTime.parse("2021-04-26T15:20:35.723"));
    eventHeader.setTransactionId(UUID.fromString("13009c19-5bef-4bf3-871e-fd08748e0339"));
    eventHeader.setXaccessToken("");
    eventHeader.setPartnerCode("BC");
    eventHeader.setEventName("POST/v1/testtaker/search");
    Map<String, String> eventContext = new HashMap<String, String>();
    eventHeader.setEventContext(eventContext);

    return eventHeader;
  }

  public static SearchBookingRequestV1 createSearchBookingRequestObject() {
    SearchBookingRequestV1 requestV1 = new SearchBookingRequestV1();
    requestV1.setCriteria(generateCriteria());
    requestV1.setSorting(getSorting());
    requestV1.setPagination(getPagination());

    return requestV1;
  }

  public static SearchBookingRequestV1 createSearchBookingRequestObjectForSpec() {
    SearchBookingRequestV1 requestV1 = new SearchBookingRequestV1();
    requestV1.setCriteria(generateCriteriaForSpec());
    requestV1.setSorting(getSorting());
    requestV1.setPagination(getPagination());

    return requestV1;
  }

  public static BookingSearchCriteriaV1 generateCriteriaForSpec() {
    BookingSearchCriteriaV1 criteriaV1 = new BookingSearchCriteriaV1();
    criteriaV1.setUniqueTestTakerId("uttid");
    criteriaV1.setCheckOutcome(generateCheckOutcome());
    return criteriaV1;
  }

  public static SearchBookingRequestV1 createSearchBookingRequestObjectForSpecException() {
    SearchBookingRequestV1 requestV1 = new SearchBookingRequestV1();
    requestV1.setCriteria(generateCriteriaForSpecException());
    requestV1.setSorting(getSorting());
    requestV1.setPagination(getPagination());

    return requestV1;
  }

  public static BookingSearchCriteriaV1 generateCriteriaForSpecException() {
    BookingSearchCriteriaV1 criteriaV1 = new BookingSearchCriteriaV1();
    criteriaV1.setShortCandidateNumber("RE");
    criteriaV1.setCheckOutcome(generateCheckOutcome());
    return criteriaV1;
  }

  public static BookingSearchCriteriaV1 generateCriteria() {
    BookingSearchCriteriaV1 criteriaV1 = new BookingSearchCriteriaV1();
    criteriaV1.setUniqueTestTakerId("uttid");
    criteriaV1.setIdentityNumber("INO110");
    criteriaV1.setLastName("lname");
    criteriaV1.setFirstName("fname");
    criteriaV1.setBirthDate(LocalDate.now());
    criteriaV1.setCentreId("IN002");
    criteriaV1.setShortCandidateNumber("000168");
    criteriaV1.setCheckOutcome(generateCheckOutcome());
    return criteriaV1;
  }

  /**
   * Gets pagination.
   *
   * @return the pagination
   */
  public static SearchPaginationV1 getPagination() {
    SearchPaginationV1 pagination = SearchPaginationV1.builder().pageSize(10).pageNumber(0).build();
    return pagination;
  }

  /**
   * Gets sorting.
   *
   * @return the sorting
   */
  public static SearchSortV1 getSorting() {
    SearchSortV1 searchSortV1 = new SearchSortV1();
    SearchSortV1Item searchItem =
        SearchSortV1Item.builder().sortType("asc").sortBy("centreId").build();
    SearchSortV1Item searchItemV1 =
        SearchSortV1Item.builder().sortBy("uniqueTestTakerId").sortType("desc").build();
    searchSortV1.add(searchItem);
    searchSortV1.add(searchItemV1);

    return searchSortV1;
  }

  public static CheckOutcomeV1 generateCheckOutcome() {
    CheckOutcomeV1 checkOutcomeV1 = new CheckOutcomeV1();
    checkOutcomeV1.setCheckOutcomeTypeUuid(UUID.fromString("005ef982-3749-4a59-98c9-5da13fed6017"));
    checkOutcomeV1.setCheckOutcomeStatusUuid(
        UUID.fromString("52c9a929-724d-4e6c-aa34-d9d979ac0f48"));
    return checkOutcomeV1;
  }

  public static CMDSAuditContext generateAudit() {
    CMDSAuditContext baseAudit = new CMDSAuditContext();
    baseAudit.setPrincipalId(null);
    baseAudit.setPrincipalName(null);
    baseAudit.setPermission("RI_BOOKING_SEARCH");
    baseAudit.setCausedByEventDateTime(LocalDateTime.parse("2021-04-26T15:20:35.723"));
    baseAudit.setCausedByEventName("POST/v1/testtaker/search");
    baseAudit.setCausedByTransactionId(UUID.fromString("13009c19-5bef-4bf3-871e-fd08748e0339"));
    baseAudit.setCausedByCorrelationId(UUID.fromString("413b7690-990f-42ce-ab76-783af084513a"));
    Map<String, String> auditContext = new HashMap<String, String>();
    auditContext.put("screen","RI_BOOKING_SEARCH");
    auditContext.put("action" , "BookingSearchCommand");
    baseAudit.setAuditContext(auditContext);

    return baseAudit;
  }

  public static BookingCheckOutcomeView generateBookingViewData() {
    return BookingCheckOutcomeView.builder()
        .bookingUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46598"))
        .firstName("Joey")
        .lastName("Chandler")
        .identityNumber("IN001")
        .uniqueTestTakerId("uttid")
        .birthDate(LocalDate.now())
        .testDate(LocalDate.now())
        .centreId("IN001")
        .checkOutcomeStatusUuid(UUID.fromString("52c9a929-724d-4e6c-aa34-d9d979ac0f48"))
        .checkOutcomeTypeUuid(UUID.fromString("005ef982-3749-4a59-98c9-5da13fed6017"))
        .build();
  }
}
