package com.ielts.cmds.ri.infrastructure.event.listener;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;

import java.io.IOException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.booking.common.out.model.BookingDetails;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.ri.utils.RIUtil;

@ExtendWith(MockitoExtension.class)
class RIIntListenerTest {

    @InjectMocks
    @Spy
    private RIIntListener riIntListener;

    private ObjectMapper mapper = new ObjectMapper();
    
    private Message<String> message;
    
    private CMDSHeaderContext headerContext;
    
    

    /**
     * Init.
     *
     * @throws IOException the io exception
     */
    @BeforeEach
    void init() throws IOException {
    	headerContext = RIUtil.createCMDSHeaderContextByEventName(RIConstants.EventType.BOOKING_CREATED_EVENT);
    	BookingDetails details = new BookingDetails();
    	
    	message = MessageBuilder.withPayload(mapper.writeValueAsString(details))
    			.setHeader("eventHeader", headerContext)
    			.build();
    }

   
    @Test
    void whenValidIntSqsMessageIsReceived_ThenNoExceptionIsRaised() {

       doNothing().when(riIntListener).onReceive(message.getHeaders(), message.getPayload());
       
       Executable executable = () -> riIntListener.on(message);
       Assertions.assertDoesNotThrow(executable);
    }
    
    @Test
    void whenValidIntSqsMessageIsReceived_ThenExceptionIsRaised() {

       doThrow(RuntimeException.class).when(riIntListener).onReceive(message.getHeaders(), message.getPayload());
       
       Executable executable = () -> riIntListener.on(message);
       Assertions.assertThrows(RuntimeException.class, executable);
    }

}
