package com.ielts.cmds.ri.utils;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.utils.RIConstants.AwsConstants;

@ExtendWith(MockitoExtension.class)
class FileStorageHelperTest {

  @InjectMocks @Spy FileStorageHelper fileStorageHelper;

  @Mock ObjectMetadata objectMetadata;

  @Spy AmazonS3Client amazonS3Client;

  @Mock private InputStream inputStream;

  @Mock PutObjectResult putObjectResult;

  // @Mock HttpURLConnection httpURLConnection;

  @Test
  void uploadFileToS3FromPresignedUrl_withNoException() throws IOException {
    String preSignedUrl = "https://mybucketpresigned.test.amazonaws.com/test/Test.json";
    URL url = mock(URL.class);
    HttpURLConnection httpURLConnection = mock(HttpURLConnection.class);
    doReturn(url).when(fileStorageHelper).getPresignedUrl(preSignedUrl);
    doReturn(httpURLConnection).when(url).openConnection();

    doReturn(objectMetadata).when(fileStorageHelper).getObjectMetadataInstance();

    doReturn(inputStream).when(httpURLConnection).getInputStream();
    doNothing()
        .when(fileStorageHelper)
        .uploadFileToS3(objectMetadata, inputStream, "Test.pdf", "RI_BUCKET");
    Assertions.assertDoesNotThrow(
        () ->
            fileStorageHelper.uploadFileToS3FromPresignedUrl(
                "https://mybucketpresigned.test.amazonaws.com/test/Test.json",
                "Test.pdf",
                "RI_BUCKET"));
  }

  @Test
  void uploadContentAsFile_NoException() {

    final String uploadBucketName = AwsConstants.RI_BUCKET;

    doReturn(true).when(amazonS3Client).doesBucketExistV2(uploadBucketName);
    final ObjectMetadata objectMetadata = new ObjectMetadata();
    objectMetadata.setContentLength(1000);

    doReturn(putObjectResult)
        .when(amazonS3Client)
        .putObject(uploadBucketName, "Test.json", inputStream, objectMetadata);

    assertDoesNotThrow(
        () ->
            fileStorageHelper.uploadFileToS3(
                objectMetadata, inputStream, "Test.json", AwsConstants.RI_BUCKET));
  }

  @Test
  void uploadContentAsFile_WithException() {

    final String uploadBucketName = AwsConstants.RI_BUCKET;

    doReturn(false).when(amazonS3Client).doesBucketExistV2(uploadBucketName);
    final ObjectMetadata objectMetadata = new ObjectMetadata();
    objectMetadata.setContentLength(1000);

    final Executable executable =
        () ->
            fileStorageHelper.uploadFileToS3(
                objectMetadata, inputStream, "Test.png", AwsConstants.RI_BUCKET);
    assertThrows(ResultIntegrityException.class, executable);
  }

  @Test
  void copyFileToCmdsS3_invalidPresignedUrl_throwIOException() {

    final Executable executable =
        () ->
            fileStorageHelper.uploadFileToS3FromPresignedUrl(
                "https://mybucketpresigned.com/test/Test.txt", "Test.txt", "RI_BUCKET");
    assertThrows(IOException.class, executable);
  }

  @Test
  void createInstanceTest() {
    assertAll(() -> Assertions.assertNotNull(fileStorageHelper.getObjectMetadataInstance()));
  }

  @Test
  void extractFileExtensionTest() {
    String str = "incident/INC123/2021-04-26T15:20:35.723/Evd.pdf";
    assertEquals("pdf",fileStorageHelper.extractFileExtension(str));
  }

  @Test
  void extractFileExtensionSecondScenarioTest() {
    String str = "Evd.pdf";
    assertEquals("",fileStorageHelper.extractFileExtension(str));
    assertEquals("",fileStorageHelper.extractFileExtension("  "));
  }

  @Test
  void generateContentTypeTest() {
    assertEquals("application/pdf",fileStorageHelper.generateContentType("pdf"));
    assertEquals("text/plain",fileStorageHelper.generateContentType("txt"));
    assertEquals("text/plain",fileStorageHelper.generateContentType("csv"));
    assertEquals("image/png",fileStorageHelper.generateContentType("png"));
    assertEquals("image/jpg",fileStorageHelper.generateContentType("jpg"));
    assertEquals("image/jpeg",fileStorageHelper.generateContentType("jpeg"));
    assertEquals("image/svg+xml",fileStorageHelper.generateContentType("svg"));
    assertEquals("audio/mp3",fileStorageHelper.generateContentType("mp3"));
    assertEquals("audio/wav",fileStorageHelper.generateContentType("WAV"));
    assertEquals("video/mp4",fileStorageHelper.generateContentType("mp4"));
    assertEquals("video/quicktime",fileStorageHelper.generateContentType("mov"));
    assertEquals("application/octet-stream",fileStorageHelper.generateContentType("doc"));
  }
}
