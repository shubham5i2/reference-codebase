package com.ielts.cmds.ri.application.service;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.ri.domain.service.TTPhotoDomainService;
import com.ielts.cmds.testtaker.common.events.model.PhotoPublishedV1;

@ExtendWith(MockitoExtension.class)
class TTPhotoServiceTest {

	@InjectMocks
    TTPhotoService ttPhotoService;

	@Mock
	TTPhotoDomainService ttPhotoDomainService;

	@Test
	void testProcess() {
		PhotoPublishedV1 photoPublishedV1 = new PhotoPublishedV1();
		ttPhotoService.process(photoPublishedV1);
		verify(ttPhotoDomainService, times(1)).on(photoPublishedV1);
	}

}
