package com.ielts.cmds.ri.domain.service;

import static com.ielts.cmds.ri.utils.TestDayIncidentRaisedEvent.*;
import static com.ielts.cmds.ri.utils.TestDayIncidentRaisedEvent.getParentIncidentTypeTech;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;

import com.ielts.cmds.ids.domain.model.ReceivedIncidentDetailsV1;
import com.ielts.cmds.ri.application.exception.ResultIntegrityValidationException;
import com.ielts.cmds.ri.infrastructure.entity.*;
import com.ielts.cmds.ri.utils.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatchers;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.ids.domain.model.CandidateIdCheckOutcomeNodeV1;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.ProductRepository;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
class LRWIdCheckOutcomeDomainServiceTest {

	@Mock
	private CheckOutcomeRepository checkOutcomeRepository;
	@Mock
	private CheckOutcomeStatusRepository checkOutcomeStatusRepository;
	@Mock
	private CheckOutcomeTypeRepository checkOutcomeTypeRepository;
	@Mock
	private OutcomeStatusRepository outcomeStatusRepository;
	@Mock
	private OutcomeStatusTypeRepository outcomeStatusTypeRepository;
	@Mock
	private CheckOutcome checkOutcome;
	@Mock
    EventOutIncidentBuilderUtil eventOutIncidentBuilderUtil;

	@Spy @InjectMocks
	RICommonUtil riCommonUtil;

	@InjectMocks
	@Spy
	private LRWIdCheckOutcomeDomainService lrwIdCheckOutcomeDomainService;

	@Captor
	ArgumentCaptor<CheckOutcome> checkOutcomeArgumentCaptor;

	@Captor
	ArgumentCaptor<OutcomeStatus> outcomeStatusArgumentCaptor;
	@Mock
	private BookingRepository bookingRepository;
	@Mock
	private ProductRepository productRepository;

	@BeforeEach
	public void init() {
		CMDSHeaderContext ctx = new CMDSHeaderContext();
		ctx.setCorrelationId(UUID.randomUUID());
		ctx.setTransactionId(UUID.randomUUID());
		ctx.setPartnerCode("CA");
		ctx.setEventDateTime(LocalDateTime.now());
		ThreadLocalHeaderContext.setContext(ctx);
	}

	@SneakyThrows
	@ParameterizedTest
	@MethodSource("argumentsProviderForIdCheckOutcomeServiceTest")
	void createIdCheckOutcomeOnValidFlow(CandidateIdCheckOutcomeNodeV1 expectedLRWIdCheckOutcomeV1,
			CheckOutcome checkOutcome, OutcomeStatus outcomeStatus) {
		doNothing().when(lrwIdCheckOutcomeDomainService).publishEvent(any());
		when(checkOutcomeRepository.save(ArgumentMatchers.any())).thenReturn(checkOutcome);
		when(checkOutcomeStatusRepository.findById(expectedLRWIdCheckOutcomeV1.getStatusUuid()))
				.thenReturn(Optional.of(LRWIdCheckOutcomeEvent.getCheckoutcomeStatus()));
		when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.LRW_ID_INC_CHK))
				.thenReturn(Optional.of(LRWIdCheckOutcomeEvent.getCheckOutcomeType()));
		when(bookingRepository.findById(expectedLRWIdCheckOutcomeV1.getBookingUuid())).
				thenReturn(Optional.of(LRWIdCheckOutcomeEvent.getBookingWithLowerBookingVersion()));
		when(productRepository.findById(UUID.fromString("592cfb1e-3d39-42c4-8366-5b675e51ff3a"))).
				thenReturn(Optional.of(LRWIdCheckOutcomeEvent.getIOLProduct()));

		lrwIdCheckOutcomeDomainService.on(expectedLRWIdCheckOutcomeV1);
		Mockito.verify(checkOutcomeRepository).save(checkOutcomeArgumentCaptor.capture());
	}

	@SneakyThrows
	@ParameterizedTest
	@MethodSource("argumentsProviderForIdCheckOutcomeServiceTest")
	void createIdCheckOutcomeOnValidFlowUpdateWithNewBookingHigherVersion(CandidateIdCheckOutcomeNodeV1 expectedLRWIdCheckOutcomeV1,
			CheckOutcome checkOutcome, OutcomeStatus outcomeStatus) {
		doNothing().when(lrwIdCheckOutcomeDomainService).publishEvent(any());
		when(checkOutcomeRepository.save(ArgumentMatchers.any())).thenReturn(checkOutcome);
		when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
				expectedLRWIdCheckOutcomeV1.getStatusUuid(), LRWIdCheckOutcomeEvent.getCheckOutcomeType().getCheckOutcomeTypeUuid()))
				.thenReturn(Optional.of(checkOutcome));
		when(checkOutcomeStatusRepository.findById(expectedLRWIdCheckOutcomeV1.getStatusUuid()))
				.thenReturn(Optional.of(LRWIdCheckOutcomeEvent.getCheckoutcomeStatus()));
		when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.LRW_ID_INC_CHK))
				.thenReturn(Optional.of(LRWIdCheckOutcomeEvent.getCheckOutcomeType()));
		when(bookingRepository.findById(expectedLRWIdCheckOutcomeV1.getBookingUuid())).thenReturn(Optional.of(LRWIdCheckOutcomeEvent.getBookingWithHigherBookingVersion()));
		when(productRepository.findById(UUID.fromString("592cfb1e-3d39-42c4-8366-5b675e51ff3a"))).
				thenReturn(Optional.of(LRWIdCheckOutcomeEvent.getIOLProduct()));

		lrwIdCheckOutcomeDomainService.on(expectedLRWIdCheckOutcomeV1);
		Mockito.verify(checkOutcomeRepository).save(checkOutcomeArgumentCaptor.capture());
	}

	@SneakyThrows
	@ParameterizedTest
	@MethodSource("argumentsProviderForIdCheckOutcomeServiceTest")
	void createIdCheckOutcomeOnInValidFlowWithResultIntegrityException(
			CandidateIdCheckOutcomeNodeV1 expectedLRWIdCheckOutcomeV1, CheckOutcome checkOutcome,
			OutcomeStatus outcomeStatus) {
		doNothing().when(lrwIdCheckOutcomeDomainService).publishEvent(any());
		doThrow(new ResultIntegrityException("Error")).when(checkOutcomeRepository).save(ArgumentMatchers.any());
		when(checkOutcomeStatusRepository.findById(expectedLRWIdCheckOutcomeV1.getStatusUuid()))
				.thenReturn(Optional.of(LRWIdCheckOutcomeEvent.getCheckoutcomeStatus()));
		when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.LRW_ID_INC_CHK))
				.thenReturn(Optional.of(LRWIdCheckOutcomeEvent.getCheckOutcomeType()));
		when(bookingRepository.findById(expectedLRWIdCheckOutcomeV1.getBookingUuid())).thenReturn(Optional.of(LRWIdCheckOutcomeEvent.getBookingWithHigherBookingVersion()));
		when(productRepository.findById(UUID.fromString("592cfb1e-3d39-42c4-8366-5b675e51ff3a"))).
				thenReturn(Optional.of(LRWIdCheckOutcomeEvent.getIOLProduct()));

		lrwIdCheckOutcomeDomainService.on(expectedLRWIdCheckOutcomeV1);
		Mockito.verify(checkOutcomeRepository).save(ArgumentMatchers.any());
	}

	private static Stream<Arguments> argumentsProviderForIdCheckOutcomeServiceTest() {
		CandidateIdCheckOutcomeNodeV1 idCheckOutcomeReceivedNode = LRWIdCheckOutcomeEvent
				.getIdCheckOutcomeReceivedNode();
		CheckOutcome checkOutcome = PrcOutcomeReceivedEvent.getCheckOutcome();
		checkOutcome.setBookingUuid(UUID.fromString("1b07b3ee-7c85-408f-9695-916a15f46590"));
		checkOutcome.setBookingVersion(BigDecimal.valueOf(1));
		OutcomeStatus outcomeStatus = PrcOutcomeReceivedEvent.getOutcomeStatus().get();
		return Stream.of(Arguments.of(idCheckOutcomeReceivedNode, checkOutcome, outcomeStatus));
	}

	@SneakyThrows
	@ParameterizedTest
	@MethodSource("argumentsProviderForIdCheckOutcomeServiceTest")
	void createIdCheckOutcomeOnValidFlowUpdateWithNewBookingLowerVersion(CandidateIdCheckOutcomeNodeV1 expectedLRWIdCheckOutcomeV1,
											   CheckOutcome checkOutcome, OutcomeStatus outcomeStatus) {
		when(checkOutcomeRepository.save(ArgumentMatchers.any())).thenReturn(checkOutcome);
		when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(
				expectedLRWIdCheckOutcomeV1.getStatusUuid(), LRWIdCheckOutcomeEvent.getCheckOutcomeType().getCheckOutcomeTypeUuid()))
				.thenReturn(Optional.of(checkOutcome));
		when(checkOutcomeStatusRepository.findById(expectedLRWIdCheckOutcomeV1.getStatusUuid()))
				.thenReturn(Optional.of(LRWIdCheckOutcomeEvent.getCheckoutcomeStatus()));
		when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(RIConstants.PrcOutcomeConstant.LRW_ID_INC_CHK))
				.thenReturn(Optional.of(LRWIdCheckOutcomeEvent.getCheckOutcomeType()));
		when(bookingRepository.findById(expectedLRWIdCheckOutcomeV1.getBookingUuid())).thenReturn(Optional.of(LRWIdCheckOutcomeEvent.getBookingWithLowerBookingVersion()));
		doNothing().when(lrwIdCheckOutcomeDomainService).publishEvent(any());
		when(productRepository.findById(UUID.fromString("592cfb1e-3d39-42c4-8366-5b675e51ff3a"))).
				thenReturn(Optional.of(LRWIdCheckOutcomeEvent.getIOLProduct()));

		lrwIdCheckOutcomeDomainService.on(expectedLRWIdCheckOutcomeV1);
		Mockito.verify(checkOutcomeRepository).save(checkOutcomeArgumentCaptor.capture());
	}

	@SneakyThrows
	@ParameterizedTest
	@MethodSource("argumentsProviderForIdCheckOutcomeServiceTest")
	void TestIfProductPresentAndProductIsIOCProduct(CandidateIdCheckOutcomeNodeV1 expectedLRWIdCheckOutcomeV1,
																		 CheckOutcome checkOutcome, OutcomeStatus outcomeStatus) {
 		when(bookingRepository.findById(expectedLRWIdCheckOutcomeV1.getBookingUuid())).thenReturn(Optional.of(LRWIdCheckOutcomeEvent.getBookingWithLowerBookingVersion()));
		when(productRepository.findById(UUID.fromString("592cfb1e-3d39-42c4-8366-5b675e51ff3a"))).
				thenReturn(Optional.of(LRWIdCheckOutcomeEvent.getIOCProduct()));

		Assertions.assertDoesNotThrow(()-> lrwIdCheckOutcomeDomainService.on(expectedLRWIdCheckOutcomeV1));
		Mockito.verify(lrwIdCheckOutcomeDomainService).on(expectedLRWIdCheckOutcomeV1);
		Mockito.verify(productRepository).findById(UUID.fromString("592cfb1e-3d39-42c4-8366-5b675e51ff3a"));
		Mockito.verify(bookingRepository).findById(expectedLRWIdCheckOutcomeV1.getBookingUuid());
		Assertions.assertEquals( "IOC",LRWIdCheckOutcomeEvent.getIOCProduct().getProductCharacteristics());
		Mockito.verify(lrwIdCheckOutcomeDomainService, times(0)).publishEvent(ArgumentMatchers.any());
		Mockito.verify(checkOutcomeRepository,times(0)).save(ArgumentMatchers.any());
	}

	@Test
	void whenPayloadEventDatetimeisBeforeDBDatetime() {

		CandidateIdCheckOutcomeNodeV1 idCheckOutcomeReceivedNode = LRWIdCheckOutcomeEvent
				.getIdCheckOutcomeReceivedNode();
		CheckOutcome checkOutcome = PrcOutcomeReceivedEvent.getCheckOutcome();
		checkOutcome.setEventDateTime(LocalDateTime.parse("2023-06-14T10:15:30"));

		checkOutcome.setBookingUuid(UUID.fromString("1b07b3ee-7c85-408f-9695-916a15f46590"));
		checkOutcome.setBookingVersion(BigDecimal.valueOf(1));
		OutcomeStatus outcomeStatus = PrcOutcomeReceivedEvent.getOutcomeStatus().get();
		CMDSHeaderContext ctx = ThreadLocalHeaderContext.getContext();
		ctx.setEventDateTime(LocalDateTime.parse("2023-05-10T10:15:30"));
		ThreadLocalHeaderContext.setContext(ctx);

		Assertions.assertThrows(ResultIntegrityValidationException.class, () -> lrwIdCheckOutcomeDomainService.checkOutComeValidation(idCheckOutcomeReceivedNode,checkOutcome));
	}



}
