package com.ielts.cmds.ri.domain.service;

import static com.ielts.cmds.ri.utils.RIConstants.PermissionId.RI_BOOKING_PRCOUTCOME;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Stream;

import javax.validation.ConstraintViolation;
import javax.validation.metadata.ConstraintDescriptor;

import com.ielts.cmds.ids.domain.model.CandidateIdCheckOutcomeNodeV1;
import com.ielts.cmds.ri.application.exception.ResultIntegrityValidationException;
import com.ielts.cmds.ri.utils.LRWIdCheckOutcomeEvent;
import org.hibernate.validator.internal.engine.ConstraintViolationImpl;
import org.hibernate.validator.internal.engine.path.PathImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatchers;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.outbox.event.OutboxEventBuilder;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.ri.common.model.out.PrcOutcomeV1;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeType;
import com.ielts.cmds.ri.infrastructure.entity.OutcomeStatus;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentRepository;
import com.ielts.cmds.ri.infrastructure.repository.IncidentStatusTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.UniqueTestTakerRepository;
import com.ielts.cmds.ri.utils.PrcOutcomeDetailsEvent;
import com.ielts.cmds.ri.utils.PrcOutcomeReceivedEvent;
import com.ielts.cmds.ri.utils.RICommonUtil;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
class PrcOutcomeReceivedDomainServiceTest {

  @InjectMocks @Spy  PrcOutcomeReceivedDomainService prcOutcomeReceivedDomainService;
  @Mock private BookingRepository bookingRepository;
  @Mock private CheckOutcomeRepository checkOutcomeRepository;
  @Mock private CheckOutcomeStatusRepository checkOutcomeStatusRepository;
  @Mock private CheckOutcomeTypeRepository checkOutcomeTypeRepository;
  @Mock private UniqueTestTakerRepository uniqueTestTakerRepository;
  @Mock private ApplicationEventPublisher applicationEventPublisher;

  @Mock private ObjectMapper objectMapper;
  @Mock private CheckOutcome checkOutcome;

  @Mock OutboxEventBuilder outboxEventBuilder;

  @Mock private RICommonUtil commonUtils;
  @Mock private CMDSErrorResolver<Object> errorResolver;

  @Captor ArgumentCaptor<CheckOutcome> checkOutcomeArgumentCaptor;

  @Captor ArgumentCaptor<OutcomeStatus> outcomeStatusArgumentCaptor;

  @Mock
  private IncidentRepository incidentRepository;

  @Mock
  private IncidentStatusTypeRepository incidentStatusTypeRepository;

  @Mock
  OutcomeStatusRepository outcomeStatusRepository;

  @BeforeEach
  void setUp() {
    CMDSHeaderContext ctx = new CMDSHeaderContext();
    ctx.setCorrelationId(UUID.randomUUID());
    ctx.setTransactionId(UUID.randomUUID());
    ctx.setPartnerCode("CA");
    ctx.setEventDateTime(LocalDateTime.now());
    ThreadLocalHeaderContext.setContext(ctx);
  }

  @SneakyThrows
  @ParameterizedTest
  @MethodSource("argumentsProviderForPrcOutcomeReceivedServiceTest")
  void createPrcOutcomeReceivedOnValidFlowForReferCheckOutcomeStatus(
      PrcOutcomeV1 expectedPrcOutcomeV1,
      CheckOutcome checkOutcome) {
	  checkOutcome.setCheckOutcomeUuid(UUID.randomUUID());
	  CheckOutcomeType checkOutcomeType = new CheckOutcomeType();
	  checkOutcomeType.setCheckOutcomeTypeUuid(UUID.randomUUID());
	  checkOutcomeType.setCheckOutcomeTypeCode(RI_BOOKING_PRCOUTCOME);
	  CheckOutcomeStatus checkOutcomeStatus = new CheckOutcomeStatus();
      checkOutcomeStatus.setCheckOutcomeStatusUuid(
          UUID.randomUUID());
      checkOutcomeStatus.setCheckOutcomeStatusCode("CHK_OUT_REFER");
      checkOutcomeStatus.setCheckOutcomeStatus("Refer");
      checkOutcome.setCheckOutcomeStatus(checkOutcomeStatus);
   
    when(bookingRepository.findById(UUID.fromString("ed5f1e15-a155-4d3a-83e0-592ac2899046")))
        .thenReturn(Optional.empty());
    when(checkOutcomeStatusRepository.findById(any())).thenReturn(Optional.of(checkOutcomeStatus));
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(any())).thenReturn(Optional.of(checkOutcomeType));
    when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(any(), any())).thenReturn(Optional.of(checkOutcome));
    when(checkOutcomeRepository.save(ArgumentMatchers.any())).thenReturn(checkOutcome);
    
	when(incidentRepository.findByCheckOutcomeByCheckOutcomeUuid(checkOutcome))
        .thenReturn(PrcOutcomeDetailsEvent.getIncidentList());
    when(incidentStatusTypeRepository.findByIncidentStatusTypeCode(any()))
        .thenReturn(Optional.of(PrcOutcomeReceivedEvent.getIncidentStatusType()));
    when(checkOutcomeRepository.save(ArgumentMatchers.any())).thenReturn(checkOutcome);

    when(commonUtils.hasAllPermissions(
            ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any()))
        .thenReturn(true);
    doNothing().when(prcOutcomeReceivedDomainService).publishEvent(any());
    prcOutcomeReceivedDomainService.on(expectedPrcOutcomeV1);

    Mockito.verify(checkOutcomeRepository).save(checkOutcomeArgumentCaptor.capture());
  }

  @SneakyThrows
  @ParameterizedTest
  @MethodSource("argumentsProviderForPrcOutcomeReceivedServiceTest")
  void createPrcOutcomeReceivedOnValidFlowForClearedCheckOutcomeStatus(
      PrcOutcomeV1 expectedPrcOutcomeV1,
      CheckOutcome checkOutcome) {
	  
	 checkOutcome.setCheckOutcomeUuid(UUID.randomUUID());
	 CheckOutcomeType checkOutcomeType = new CheckOutcomeType();
	 checkOutcomeType.setCheckOutcomeTypeUuid(UUID.randomUUID());
	 checkOutcomeType.setCheckOutcomeTypeCode(RI_BOOKING_PRCOUTCOME);
	 CheckOutcomeStatus checkOutcomeStatus = new CheckOutcomeStatus();
     checkOutcomeStatus.setCheckOutcomeStatusUuid(
          UUID.randomUUID());
     checkOutcomeStatus.setCheckOutcomeStatusCode("CHK_OUT_REFER");
     checkOutcomeStatus.setCheckOutcomeStatus("Refer");
     checkOutcome.setCheckOutcomeStatus(checkOutcomeStatus);
   
    when(bookingRepository.findById(UUID.fromString("ed5f1e15-a155-4d3a-83e0-592ac2899046")))
        .thenReturn(Optional.empty());
    when(checkOutcomeStatusRepository.findById(any())).thenReturn(Optional.of(checkOutcomeStatus));
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(any())).thenReturn(Optional.of(checkOutcomeType));
    when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(any(), any())).thenReturn(Optional.of(checkOutcome));
    when(checkOutcomeRepository.save(ArgumentMatchers.any())).thenReturn(checkOutcome);
    
    when(bookingRepository.findById(UUID.fromString("ed5f1e15-a155-4d3a-83e0-592ac2899046")))
        .thenReturn(PrcOutcomeReceivedEvent.getBookingForTest());
    when(checkOutcomeStatusRepository.findById(any()))
        .thenReturn(Optional.of(PrcOutcomeReceivedEvent.generateCheckOutcomeStatusCleared()));
    when(incidentRepository.findByCheckOutcomeByCheckOutcomeUuid(checkOutcome))
        .thenReturn(PrcOutcomeDetailsEvent.getIncidentList());
    when(incidentStatusTypeRepository.findByIncidentStatusTypeCode(any()))
        .thenReturn(Optional.of(PrcOutcomeReceivedEvent.getIncidentStatusType()));
    when(checkOutcomeRepository.save(ArgumentMatchers.any())).thenReturn(checkOutcome);

    when(commonUtils.hasAllPermissions(
        ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any()))
        .thenReturn(true);
    doNothing().when(prcOutcomeReceivedDomainService).publishEvent(any());
    prcOutcomeReceivedDomainService.on(expectedPrcOutcomeV1);

    Mockito.verify(checkOutcomeRepository).save(checkOutcomeArgumentCaptor.capture());
  }

  @ParameterizedTest
  @MethodSource("argumentsProviderForPrcOutcomeReceivedServiceTest")
  void createPrcOutcomeReceivedOnValidFlow_shouldSaveTheOutcome_whenNoBookingPresent(
      PrcOutcomeV1 expectedPrcOutcomeV1,
      CheckOutcome checkOutcome)
      throws RbacValidationException {
	  checkOutcome.setCheckOutcomeUuid(UUID.randomUUID());
	  CheckOutcomeType checkOutcomeType = new CheckOutcomeType();
	  checkOutcomeType.setCheckOutcomeTypeUuid(UUID.randomUUID());
	  checkOutcomeType.setCheckOutcomeTypeCode(RI_BOOKING_PRCOUTCOME);
	  CheckOutcomeStatus checkOutcomeStatus = new CheckOutcomeStatus();
      checkOutcomeStatus.setCheckOutcomeStatusUuid(
          UUID.randomUUID());
      checkOutcomeStatus.setCheckOutcomeStatusCode("CHK_OUT_REFER");
      checkOutcomeStatus.setCheckOutcomeStatus("Refer");
      checkOutcome.setCheckOutcomeStatus(checkOutcomeStatus);
    when(bookingRepository.findById(UUID.fromString("ed5f1e15-a155-4d3a-83e0-592ac2899046")))
        .thenReturn(Optional.empty());
    when(checkOutcomeStatusRepository.findById(any())).thenReturn(Optional.of(checkOutcomeStatus));
    when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(any())).thenReturn(Optional.of(checkOutcomeType));
    when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(any(), any())).thenReturn(Optional.of(checkOutcome));
    when(checkOutcomeRepository.save(ArgumentMatchers.any())).thenReturn(checkOutcome);
    doNothing().when(prcOutcomeReceivedDomainService).publishEvent(any());
    when(commonUtils.hasAllPermissions(
            ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any()))
        .thenReturn(true);
    prcOutcomeReceivedDomainService.on(expectedPrcOutcomeV1);

    Mockito.verify(checkOutcomeRepository).save(checkOutcomeArgumentCaptor.capture());
  }

  @SneakyThrows
  @ParameterizedTest
  @MethodSource("argumentsProviderForPrcOutcomeReceivedServiceTest")
  void createPrcOutcomeGeneratedOnWhenOutcomeStatusNull(
      PrcOutcomeV1 expectedPrcOutcomeV1,
      CheckOutcome checkOutcome) {
		checkOutcome.setCheckOutcomeUuid(UUID.randomUUID());
		CheckOutcomeType checkOutcomeType = new CheckOutcomeType();
		checkOutcomeType.setCheckOutcomeTypeUuid(UUID.randomUUID());
		checkOutcomeType.setCheckOutcomeTypeCode(RI_BOOKING_PRCOUTCOME);
		CheckOutcomeStatus checkOutcomeStatus = new CheckOutcomeStatus();
		checkOutcomeStatus.setCheckOutcomeStatusUuid(UUID.randomUUID());
		checkOutcomeStatus.setCheckOutcomeStatusCode("CHK_OUT_REFER");
		checkOutcomeStatus.setCheckOutcomeStatus("Refer");
		checkOutcome.setCheckOutcomeStatus(checkOutcomeStatus);

		when(checkOutcomeStatusRepository.findById(any())).thenReturn(Optional.of(checkOutcomeStatus));
		when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(any())).thenReturn(Optional.of(checkOutcomeType));
		when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(any(), any()))
				.thenReturn(Optional.of(checkOutcome));
		when(checkOutcomeRepository.save(ArgumentMatchers.any())).thenReturn(checkOutcome);
  
    when(bookingRepository.findById(UUID.fromString(expectedPrcOutcomeV1.getBookingUuidList().get(0))))
        .thenReturn(PrcOutcomeReceivedEvent.getBookingForTest());
  
    when(commonUtils.hasAllPermissions(
            ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any()))
        .thenReturn(true);
    doNothing().when(prcOutcomeReceivedDomainService).publishEvent(any());
    doNothing().when(prcOutcomeReceivedDomainService).publishUiEvent(any(),any(),any());

    prcOutcomeReceivedDomainService.on(expectedPrcOutcomeV1);

    Mockito.verify(checkOutcomeRepository).save(checkOutcomeArgumentCaptor.capture());
  }

  @ParameterizedTest
  @MethodSource("argumentsProviderForPrcOutcomeReceivedServiceTest")
  void testOnCommand_WhenInvalidAccess_ShouldPublishMessageWithErrors(PrcOutcomeV1 prcOutcomeV1) throws RbacValidationException {

    CMDSHeaderContext headerContext = BookingSearchTestSetup.generateEventHeader();
    ThreadLocalHeaderContext.setContext(headerContext);

    when(commonUtils.hasAllPermissions(
            "",
            RI_BOOKING_PRCOUTCOME,
            ThreadLocalHeaderContext.getContext().getPartnerCode()))
        .thenReturn(false);

    Set<ConstraintViolation<Object>> constraintViolation =
        getSetforNullViolationOfEventBody("V00013");
    when(errorResolver.populatErrorResponse(constraintViolation, "POST/v1/testtaker/search"))
        .thenReturn(new CMDSErrorResponse());
    doNothing().when(prcOutcomeReceivedDomainService).publishEvent(any(),any());
    prcOutcomeReceivedDomainService.on(prcOutcomeV1);

    Mockito.verify(commonUtils)
        .hasAllPermissions(
            "",
            RI_BOOKING_PRCOUTCOME,
            ThreadLocalHeaderContext.getContext().getPartnerCode());
  }

  @ParameterizedTest
  @MethodSource("argumentsProviderForPrcOutcomeReceivedServiceTest")
  void testOnCommand_BookingListIsEmpty_ShouldPublishMessageWithErrors(PrcOutcomeV1 prcOutcomeReceivedNode) throws RbacValidationException {

    CMDSHeaderContext header = BookingSearchTestSetup.generateEventHeader();
    ThreadLocalHeaderContext.setContext(header);
    prcOutcomeReceivedNode.setBookingUuidList(null);

    when(commonUtils.hasAllPermissions(
            "",
            RI_BOOKING_PRCOUTCOME,
            ThreadLocalHeaderContext.getContext().getPartnerCode()))
        .thenReturn(true);

    doNothing().when(prcOutcomeReceivedDomainService).publishUiEvent(any(),any(),any());
     prcOutcomeReceivedDomainService.on(prcOutcomeReceivedNode);

    Mockito.verify(commonUtils)
        .hasAllPermissions(
            "",
            RI_BOOKING_PRCOUTCOME,
            ThreadLocalHeaderContext.getContext().getPartnerCode());
  }

  public Set<ConstraintViolation<Object>> setNullViolationForBookingList(
      final String interpolatedMessage) {

    Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
    final String messageTemplate = null;
    final Class<Object> rootBeanClass = null;
    final Object rootBean = null;
    final Object leafBeanInstance = null;
    final Object value = null;
    final javax.validation.Path propertyPath =
        PathImpl.createPathFromString("bookingSelectionList");
    final ConstraintDescriptor<?> constraintDescriptor = null;
    final Map<String, Object> messageParameters = new HashMap<>();
    final Map<String, Object> expressionVariables = new HashMap<>();
    ConstraintViolation<Object> constraintViolationImpl1 =
        (ConstraintViolationImpl<Object>)
            ConstraintViolationImpl.forBeanValidation(
                messageTemplate,
                messageParameters,
                expressionVariables,
                interpolatedMessage,
                rootBeanClass,
                rootBean,
                leafBeanInstance,
                value,
                propertyPath,
                constraintDescriptor,
                null);

    violationSet.add(constraintViolationImpl1);
    return violationSet;
  }

  public Set<ConstraintViolation<Object>> getSetforNullViolationOfEventBody(
      final String interpolatedMessage) {

    Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
    final String messageTemplate = null;
    final String interpolatedHeaderMessage = interpolatedMessage;
    final Class<Object> rootBeanClass = null;
    final Object rootBean = null;
    final Object leafBeanInstance = null;
    final Object value = null;
    final javax.validation.Path propertyPath =
        PathImpl.createPathFromString("unauthorisedToUpdatePrcOutcome");
    final ConstraintDescriptor<?> constraintDescriptor = null;
    final Map<String, Object> messageParameters = new HashMap<>();
    final Map<String, Object> expressionVariables = new HashMap<>();
    ConstraintViolation<Object> constraintViolationImpl1 =
        (ConstraintViolationImpl<Object>)
            ConstraintViolationImpl.forBeanValidation(
                messageTemplate,
                messageParameters,
                expressionVariables,
                interpolatedHeaderMessage,
                rootBeanClass,
                rootBean,
                leafBeanInstance,
                value,
                propertyPath,
                constraintDescriptor,
                null);

    violationSet.add(constraintViolationImpl1);
    return violationSet;
  }

  private static Stream<Arguments> argumentsProviderForPrcOutcomeReceivedServiceTest() {
    PrcOutcomeV1 prcOutcomeReceivedNode = PrcOutcomeReceivedEvent.getPrcOutcomeReceivedNode();
    CheckOutcome checkOutcome = PrcOutcomeReceivedEvent.getCheckOutcome();
    return Stream.of(
        Arguments.of(
            prcOutcomeReceivedNode,
            checkOutcome));
  }

}
