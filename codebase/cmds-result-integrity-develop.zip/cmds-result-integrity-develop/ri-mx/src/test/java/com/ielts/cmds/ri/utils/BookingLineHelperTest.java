package com.ielts.cmds.ri.utils;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.booking.common.out.model.BookingDetails;
import com.ielts.cmds.ri.domain.enums.BookingLineStatusEnum;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.BookingLine;
import com.ielts.cmds.ri.infrastructure.repository.BookingLineRepository;

@ExtendWith(MockitoExtension.class)
class BookingLineHelperTest {


    @Spy
    @InjectMocks
    BookingLineHelper bookingLineHelper;
    @Mock
    BookingLineRepository bookingLineRepository;

    @Test
    void updateBookingLine_When_BookingLine_Is_Optional() {

        BookingDetails bookingDetails=BookingDetailsEvent.getBookingDetailsBodyCommon();
        Booking booking = new Booking();
        booking.setBookingStatus("PAID");
        booking.setBookingUuid(UUID.fromString("000e1f2a-6fa9-403b-8fd3-d7dd146451d7"));
        BookingLine bookingLine=new BookingLine();
        List<BookingLine> bookingLineList=new ArrayList<>();
        bookingLine.setBookingLineStatus(BookingLineStatusEnum.ACTIVE);
        bookingLine.setBookingLineUuid(UUID.fromString("1b4fcb9a-fd24-468e-93d4-881c7dd78a8a"));
        bookingLine.setProductUuid(UUID.fromString("3e81e94b-8b6a-42b5-970c-b141f9d195a3"));
        bookingLineList.add(bookingLine);
        when(bookingLineRepository.findById(bookingDetails.getBookingLines().get(0).getBookingLineUuid())).thenReturn(Optional.of(bookingLine));
        Assertions.assertDoesNotThrow(() -> bookingLineHelper.updateBookingLineDetails(booking,bookingDetails));
    }

    @Test
    void updateBookingLine_When_BookingLine_Is_Not_Optional() {

        BookingDetails bookingDetails=BookingDetailsEvent.getBookingDetailsBodyCommon();
        Booking booking = new Booking();
        booking.setBookingStatus("PAID");
        booking.setBookingUuid(UUID.fromString("000e1f2a-6fa9-403b-8fd3-d7dd146451d7"));
        BookingLine bookingLine=new BookingLine();
        List<BookingLine> bookingLineList=new ArrayList<>();
        bookingLine.setBookingLineStatus(BookingLineStatusEnum.ACTIVE);
        bookingLine.setBookingLineUuid(UUID.fromString("1b4fcb9a-fd24-468e-93d4-881c7dd78a8a"));
        bookingLine.setProductUuid(UUID.fromString("3e81e94b-8b6a-42b5-970c-b141f9d195a3"));
        bookingLineList.add(bookingLine);
        when(bookingLineRepository.findById(bookingDetails.getBookingLines().get(0).getBookingLineUuid())).thenReturn(Optional.empty());
        Assertions.assertDoesNotThrow(() -> bookingLineHelper.updateBookingLineDetails(booking,bookingDetails));
    }


}
