package com.ielts.cmds.ri.domain.service;

import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.LRW_INC_CHK;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.PRC_INC;
import static com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant.SPK_INC_CHK;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.PessimisticLockingFailureException;

import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeType;
import com.ielts.cmds.ri.infrastructure.repository.BookingLineOutcomeViewRepository;
import com.ielts.cmds.ri.infrastructure.repository.BookingRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.CheckOutcomeTypeRepository;
import com.ielts.cmds.ri.infrastructure.repository.OutcomeStatusRepository;
import com.ielts.cmds.ri.infrastructure.repository.ResultIntegritySemaphoreRepository;
import com.ielts.cmds.ri.utils.OverallIntegrityCheckEvent;
import com.ielts.cmds.ri.utils.RICommonUtil;

@ExtendWith(MockitoExtension.class)
class OverallIntegrityCheckDomainServiceTest {

  @InjectMocks
  @Spy
  private OverallIntegrityCheckDomainService overallIntegrityCheckDomainService;

  @Mock
  CheckOutcomeRepository checkOutcomeRepository;

  @Mock
  CheckOutcomeTypeRepository checkOutcomeTypeRepository;

  @Mock
  CheckOutcomeStatusRepository checkOutcomeStatusRepository;

  @Mock
  BookingLineOutcomeViewRepository bookingLineOutcomeViewRepository;

  @Mock
  OutcomeStatusRepository outcomeStatusRepository;

  @Mock
  BookingRepository bookingRepository;

  @Mock
  RICommonUtil riCommonUtil;

  @Mock
  private ResultIntegritySemaphoreRepository resultIntegritySemaphoreRepository;

  @BeforeEach
  void setup() {
    CMDSHeaderContext header = new CMDSHeaderContext();
    header.setCorrelationId(UUID.randomUUID());
    header.setTransactionId(UUID.randomUUID());
    ThreadLocalHeaderContext.setContext(header);
  }

  @Test
  void testOnCommand_should_publish_event() {

    Mockito.when(bookingLineOutcomeViewRepository
        .findAll())
        .thenReturn(OverallIntegrityCheckEvent.listOfView());

    Mockito.doNothing().when(overallIntegrityCheckDomainService)
        .checkAndSetCheckOutcome(any(), anyString(),any());

    overallIntegrityCheckDomainService.on();
  }

  @Test
  void testOn_Throws_Exception() {

    Mockito.when(bookingLineOutcomeViewRepository
                    .findAll())
            .thenThrow(RuntimeException.class);

    assertThrows(ResultIntegrityException.class, ()-> overallIntegrityCheckDomainService.on());
  }

  @Test
  void testOnCommand_should_not_publish_event() {

    Mockito.when(bookingLineOutcomeViewRepository
                    .findAll())
            .thenReturn(OverallIntegrityCheckEvent.listOfView());

    overallIntegrityCheckDomainService.on();

    Mockito.verify(overallIntegrityCheckDomainService, Mockito.times(0)).publishEvent(any());
  }

  @Test
  void testCheckAndSetCheckOutcome() {

    String checkOutcomeReceived = "PRC_INC_CHK,PLG_INC_CHK";

    List<String> eligibleCheckOutcomeList = new ArrayList<>();
    eligibleCheckOutcomeList.add(LRW_INC_CHK);
    eligibleCheckOutcomeList.add(SPK_INC_CHK);
    eligibleCheckOutcomeList.add(PRC_INC);
    Mockito.when(bookingRepository.findById(any())).thenReturn(Optional.ofNullable(Booking.builder().build()));

    Mockito.doReturn(eligibleCheckOutcomeList).when(riCommonUtil)
            .generateCheckOutcomeList(any());


    Mockito.doNothing().when(overallIntegrityCheckDomainService)
        .insertCheckOutcome(anyString(), anyString(), any(),any());

    overallIntegrityCheckDomainService
            .checkAndSetCheckOutcome(UUID.fromString("3c8b6bda-83bd-47c5-aca6-a2d911ba097d"), checkOutcomeReceived, BigDecimal.valueOf(0));  }

  @Test
  void testInsertCheckOutcome_And_PublishEvent() {

	UUID randomUUID = UUID.randomUUID();
    Mockito.doNothing().when(overallIntegrityCheckDomainService)
        .publishIntegrityCheckInitiatedEvent(any(), any());

    Mockito.when(checkOutcomeStatusRepository.findByCheckOutcomeStatusCode(any()))
        .thenReturn(Optional.of(OverallIntegrityCheckEvent.getCheckOutcomeStatus()));

    Mockito.when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(any()))
        .thenReturn(Optional.of(OverallIntegrityCheckEvent.getCheckOutcomeType()));

    assertNotNull(randomUUID);

    overallIntegrityCheckDomainService
        .insertCheckOutcome("FAILED", "LRW_INC_CHK",
            randomUUID,BigDecimal.valueOf(0));
    Mockito.verify(overallIntegrityCheckDomainService,Mockito.times(1))
    .publishIntegrityCheckInitiatedEvent(any(), any());
  }

  @Test
  void testInsertCheckOutcome_With_Existing_outcome_And_PublishEvent() {


    Mockito.doNothing().when(overallIntegrityCheckDomainService)
            .publishIntegrityCheckInitiatedEvent(any(), any());

    Mockito.when(checkOutcomeStatusRepository.findByCheckOutcomeStatusCode(any()))
            .thenReturn(Optional.of(OverallIntegrityCheckEvent.getCheckOutcomeStatus()));

    Mockito.when(checkOutcomeTypeRepository.findByCheckOutcomeTypeCode(any()))
            .thenReturn(Optional.of(OverallIntegrityCheckEvent.getCheckOutcomeType()));

    Optional<CheckOutcome> checkOutcome = Optional.of(CheckOutcome.builder()
            .checkOutcomeStatus(CheckOutcomeStatus.builder().build())
            .checkOutcomeType(CheckOutcomeType.builder().build())
            .build());

    Mockito.when(checkOutcomeRepository.findByBookingUuidAndCheckOutcomeTypeCheckOutcomeTypeUuid(any(),any())).thenReturn(checkOutcome);

    assertNotNull(BigDecimal.valueOf(0));
    overallIntegrityCheckDomainService
            .insertCheckOutcome("FAILED", "LRW_INC_CHK",
                    UUID.randomUUID(),BigDecimal.valueOf(0));
  }

  @Test
  void testPublishIntegrityCheckInitiatedEvent() {

	CheckOutcome checkEvent = OverallIntegrityCheckEvent.getCheckOutcome();
	UUID randomUUID = UUID.randomUUID();
    Mockito.doNothing().when(overallIntegrityCheckDomainService).publishEvent(any());
    assertNotNull(UUID.randomUUID());
    overallIntegrityCheckDomainService
        .publishIntegrityCheckInitiatedEvent(checkEvent,randomUUID);
    verify(overallIntegrityCheckDomainService).publishIntegrityCheckInitiatedEvent(checkEvent,randomUUID);

  }
  @Test
  void on_ShouldThrowPessimisticLockingFailureException_WhenLockIsNotAcquired() {
    doThrow(PessimisticLockingFailureException.class)
        .when(resultIntegritySemaphoreRepository)
        .findById(any());
    assertThrows(
        PessimisticLockingFailureException.class, () -> overallIntegrityCheckDomainService.on());
  }

}
