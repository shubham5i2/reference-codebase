package com.ielts.cmds.ri.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.rbac.api.service.RBACService;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.ri.application.exception.ResultIntegrityException;
import com.ielts.cmds.ri.common.model.out.SearchBookingRequestV1;
import com.ielts.cmds.ri.common.model.out.SearchSortV1Item;
import com.ielts.cmds.ri.infrastructure.entity.BookingCheckOutcomeView;
import com.ielts.cmds.ri.infrastructure.repository.BookingCheckOutcomeViewRepository;
import com.ielts.cmds.ri.utils.RICommonUtil;
import org.hibernate.validator.internal.engine.ConstraintViolationImpl;
import org.hibernate.validator.internal.engine.path.PathImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.*;
import javax.validation.ConstraintViolation;
import javax.validation.metadata.ConstraintDescriptor;
import java.util.*;
import java.util.stream.Stream;

import static com.ielts.cmds.ri.utils.RIConstants.PermissionId.RI_BOOKING_SEARCH;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

/** The type Booking search domain service test. */
@ExtendWith(MockitoExtension.class)
class BookingSearchDomainServiceTest {
  /** The Booking search domain service. */
  @Spy @InjectMocks BookingSearchDomainService bookingSearchDomainService;

  @Mock private BookingCheckOutcomeViewRepository checkOutcomeViewRepository;

  /** The Booking outcome specification. */
  @Captor ArgumentCaptor<Specification<BookingCheckOutcomeView>> bookingOutComeSpecification;

  /** The Pageable arg. */
  @Captor ArgumentCaptor<Pageable> pageableArg;

  /** The Root. */
  @Mock Root<BookingCheckOutcomeView> root;

  /** The Criteria builder. */
  @Mock CriteriaBuilder criteriaBuilder;

  /** The Criteria query. */
  @Mock CriteriaQuery<BookingCheckOutcomeView> criteriaQuery;

  /** The Expr. */
  @SuppressWarnings("rawtypes")
@Mock Expression expr;

  private static SearchBookingRequestV1 requestV1;

  /** The Common utils. */
  @Mock RICommonUtil commonUtils;

  @Mock private CMDSErrorResolver<Object> errorResolver;

  /** The Violations. */
  @Mock Set<ConstraintViolation<Object>> violations;

  @Mock private RBACService rbacService;

  /** Sets up. */
  @BeforeEach
  void setUp() {
    requestV1 = BookingSearchTestSetup.createSearchBookingRequestObject();

    ThreadLocalAuditContext.setContext(BookingSearchTestSetup.generateAudit());
    ThreadLocalHeaderContext.setContext(BookingSearchTestSetup.generateEventHeader());
  }

  /**
   * When received valid user group command then no exception.
   *
   * @param requestV1 the request v 1
   * @param viewList the view list
   * @param pageObj the page obj
   * @throws RbacValidationException the rbac validation exception
   */
  @SuppressWarnings("unchecked")
@ParameterizedTest
  @MethodSource("provideArgumentsForSearchBookingCommand")
  void whenReceivedValid_UserGroupCommand_thenNoException(
      final SearchBookingRequestV1 requestV1,
      final List<BookingCheckOutcomeView> viewList,
      final Pageable pageObj)
      throws RbacValidationException, JsonProcessingException {

    Page<BookingCheckOutcomeView> pageableUserdtl = new PageImpl<>(viewList, pageObj, 50);

    when(commonUtils.hasAllPermissions("", RI_BOOKING_SEARCH, "BC")).thenReturn(true);

    when(checkOutcomeViewRepository.findAll(any(Specification.class), eq(pageObj)))
        .thenReturn(pageableUserdtl);

    doNothing().when(bookingSearchDomainService).publishEvent(any());

    bookingSearchDomainService.on(requestV1);

    verify(checkOutcomeViewRepository)
        .findAll(bookingOutComeSpecification.capture(), pageableArg.capture());

    assertEquals(0, pageableArg.getValue().getPageNumber());
    assertEquals(10, pageableArg.getValue().getPageSize());
    assertNotNull(pageableArg.getValue().getSort());
  }

  /**
   * Test on command when invalid access should publish message with errors.
   *
   * @param requestV1 the request v 1
   * @param viewList the view list
   * @param pageObj the page obj
   * @throws RbacValidationException the rbac validation exception
   */
  @ParameterizedTest
  @MethodSource("provideArgumentsForSearchBookingCommand")
  void testOnCommand_WhenInvalidAccess_ShouldPublishMessageWithErrors(
      final SearchBookingRequestV1 requestV1,
      final List<BookingCheckOutcomeView> viewList,
      final Pageable pageObj)
      throws RbacValidationException, JsonProcessingException {

    when(commonUtils.hasAllPermissions(
            "", RI_BOOKING_SEARCH, ThreadLocalHeaderContext.getContext().getPartnerCode()))
        .thenReturn(false);

    Set<ConstraintViolation<Object>> constraintViolation =
        getSetforNullViolationOfEventBody("V00012");
    when(errorResolver.populatErrorResponse(constraintViolation, "BookingSearchResponseGenerated"))
        .thenReturn(new CMDSErrorResponse());
    doNothing().when(bookingSearchDomainService).publishEvent(any(),any());
    bookingSearchDomainService.on(requestV1);

    Mockito.verify(commonUtils).hasAllPermissions("", RI_BOOKING_SEARCH, "BC");
  }

  /**
   * Gets setfor null violation of event body.
   *
   * @param interpolatedMessage the interpolated message
   * @return the setfor null violation of event body
   */
  public Set<ConstraintViolation<Object>> getSetforNullViolationOfEventBody(
      final String interpolatedMessage) {

    Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
    final String messageTemplate = null;
    final Class<Object> rootBeanClass = null;
    final Object rootBean = null;
    final Object leafBeanInstance = null;
    final Object value = null;
    final javax.validation.Path propertyPath =
        PathImpl.createPathFromString("unauthorisedToViewBooking");
    final ConstraintDescriptor<?> constraintDescriptor = null;
    final Map<String, Object> messageParameters = new HashMap<>();
    final Map<String, Object> expressionVariables = new HashMap<>();
    ConstraintViolation<Object> constraintViolationImpl1 =
        (ConstraintViolationImpl<Object>)
            ConstraintViolationImpl.forBeanValidation(
                messageTemplate,
                messageParameters,
                expressionVariables,
                interpolatedMessage,
                rootBeanClass,
                rootBean,
                leafBeanInstance,
                value,
                propertyPath,
                constraintDescriptor,
                null);

    violationSet.add(constraintViolationImpl1);
    return violationSet;
  }

  /** Test get specification. */
  @Test
  void testGetSpecification() {

    requestV1 = BookingSearchTestSetup.createSearchBookingRequestObjectForSpec();

    Predicate expectedPredicate = Mockito.mock(Predicate.class);

    Path uniqueTestTakerIdPath = Mockito.mock(Path.class);
    Predicate compareUniqueTestTakerId = Mockito.mock(Predicate.class);

    Mockito.when(root.get(ArgumentMatchers.anyString())).thenReturn(uniqueTestTakerIdPath);
    Mockito.when(criteriaBuilder.lower(ArgumentMatchers.any())).thenReturn(expr);
    Mockito.when(criteriaBuilder.equal(ArgumentMatchers.any(), ArgumentMatchers.anyString()))
        .thenReturn(compareUniqueTestTakerId);

    List<Predicate> expectedPredicateList = new ArrayList<>();
    expectedPredicateList.add(expectedPredicate);

    Mockito.when(criteriaBuilder.and(ArgumentMatchers.any())).thenReturn(expectedPredicate);

    Specification<BookingCheckOutcomeView> bookingSpecification =
        bookingSearchDomainService.getSpecification(requestV1);
    Predicate actualPredicate =
        bookingSpecification.toPredicate(root, criteriaQuery, criteriaBuilder);

    Assertions.assertEquals(expectedPredicate, actualPredicate);
  }

  /** Test get specification throws exception. */
  @Test
  void testGetSpecification_throwsException() {

    requestV1 = BookingSearchTestSetup.createSearchBookingRequestObjectForSpecException();

    Predicate expectedPredicate = Mockito.mock(Predicate.class);

    List<Predicate> expectedPredicateList = new ArrayList<>();
    expectedPredicateList.add(expectedPredicate);

    Specification<BookingCheckOutcomeView> bookingSpecification =
        bookingSearchDomainService.getSpecification(requestV1);

    final ResultIntegrityException thrownEx =
        assertThrows(
            ResultIntegrityException.class,
            () ->
              bookingSpecification.toPredicate(root, criteriaQuery, criteriaBuilder)
            );

    // then
    assertNotNull(thrownEx);
    assertNotNull(thrownEx.getMessage());
  }

  private static Stream<Arguments> provideArgumentsForSearchBookingCommand() {

    List<BookingCheckOutcomeView> viewList = new ArrayList<>();

    final SearchBookingRequestV1 bookingRequestV1 = BookingSearchTestSetup.createSearchBookingRequestObject();

    BookingCheckOutcomeView bookingCheckOutcomeView =
        BookingSearchTestSetup.generateBookingViewData();
    viewList.add(bookingCheckOutcomeView);

    List<Sort.Order> sorts = new ArrayList<>();
    SearchSortV1Item searchItem =
            SearchSortV1Item.builder().sortType("asc").sortBy("centreId").build();
    sorts.add(new Sort.Order(Sort.Direction.ASC, searchItem.getSortBy()));
    SearchSortV1Item searchItemV1 =
            SearchSortV1Item.builder().sortBy("uniqueTestTakerId").sortType("desc").build();
    sorts.add(new Sort.Order(Sort.Direction.DESC, searchItemV1.getSortBy()));

    Pageable pageObj =
        PageRequest.of(
            0,
            10,
            Sort.by(sorts));

    return Stream.of(Arguments.of(bookingRequestV1, viewList, pageObj));
  }
}
