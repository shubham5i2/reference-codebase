package com.ielts.cmds.ri.utils;

import static java.time.ZoneOffset.UTC;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.ielts.cmds.api.evt_019.BookingDetailsV1;
import com.ielts.cmds.api.evt_019.BookingLinkV1;
import com.ielts.cmds.api.evt_019.LinkedBookingV1;
import com.ielts.cmds.booking.common.enums.BookingDetailStatusEnum;
import com.ielts.cmds.booking.common.enums.BookingLineStatusEnum;
import com.ielts.cmds.booking.common.enums.BookingStatusEnum;
import com.ielts.cmds.booking.common.enums.IdentityVerificationStatusEnum;
import com.ielts.cmds.booking.common.enums.RoleEnum;
import com.ielts.cmds.booking.common.out.model.CancelBookingDetails;
import com.ielts.cmds.booking.common.out.model.TestTakerDetails;
import com.ielts.cmds.booking.common.out.model.TransferBookingDetails;
import com.ielts.cmds.common.persistence.utils.CMDSOffsetDatetime;
import com.ielts.cmds.ri.domain.enums.BookingRoleEnum;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.BookingLine;
import com.ielts.cmds.ri.infrastructure.entity.UniqueTestTaker;

public class BookingDetailsEvent {

    public static BookingDetailsV1 getBookingDetailsBody() {
        BookingDetailsV1 booking = new BookingDetailsV1();
        booking.setBookingUuid(UUID.fromString("4fd557d7-701d-4341-8e81-943a8d88fa8c"));
        booking.setExternalBookingUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46598"));
        booking.setBookingStatus(BookingDetailsV1.BookingStatusEnum.PAID);
        booking.setExternalBookingReference("TestBookingReference");
        booking.setProductUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
        booking.setLocationUuid(UUID.fromString("742d0a15-6238-4be0-b893-38122603c5a8"));
        booking.setTestDate(OffsetDateTime.parse("2023-10-31T16:20:35.723Z"));
        booking.setTestTaker(getTestTakerDetailsEvt019());
        booking.setExternalBookingReference("TestBookingReference");
        booking.setBookingVersion(BigDecimal.valueOf(3));
        List<com.ielts.cmds.api.evt_019.BookingLineV1> list = new ArrayList<>();
        com.ielts.cmds.api.evt_019.BookingLineV1 bln1 = new com.ielts.cmds.api.evt_019.BookingLineV1();
        bln1.setBookingLineUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        bln1.setStartTimeLocal(OffsetDateTime.parse("2023-10-02T20:15:30+01:00",
                DateTimeFormatter.ISO_DATE_TIME));
        bln1.setStartTimeLocal(OffsetDateTime.parse("2024-10-02T20:15:30+01:00",
                DateTimeFormatter.ISO_DATE_TIME));
        bln1.setBookingLineStatus(com.ielts.cmds.api.evt_019.BookingLineV1.BookingLineStatusEnum.ACTIVE);
        bln1.setProductUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
        list.add(bln1);
        booking.setBookingLines(list);
        List<BookingLinkV1> bookingLinkList = new ArrayList<>();
        BookingLinkV1 bookingLink = new BookingLinkV1();
        LinkedBookingV1 linkedBooking = new LinkedBookingV1();
        linkedBooking.setBookingUuid(UUID.fromString("742d0a15-6238-4be0-b893-38122603c5a8"));
        linkedBooking.setProductUuid(UUID.fromString("7d55eb13-1e7d-4904-b0c7-7cba5490824c"));
        bookingLink.setLinkedBooking(linkedBooking);
        bookingLink.setRole(BookingLinkV1.RoleEnum.fromValue(RoleEnum.SSRORIGINAL.getValue()));
        bookingLinkList.add(bookingLink);
        booking.setLinkedBookings(bookingLinkList);
        return booking;
    }

    public static com.ielts.cmds.booking.common.out.model.BookingDetails getBookingDetailsBodyCommon() {
        com.ielts.cmds.booking.common.out.model.BookingDetails booking = new com.ielts.cmds.booking.common.out.model.BookingDetails();
        booking.setBookingUuid(UUID.fromString("4fd557d7-701d-4341-8e81-943a8d88fa8c"));
        booking.setExternalBookingUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46598"));
        booking.setBookingStatus(BookingStatusEnum.PAID);
        booking.setExternalBookingReference("TestBookingReference");
        booking.setProductUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
        booking.setLocationUuid(UUID.fromString("742d0a15-6238-4be0-b893-38122603c5a8"));
        LocalDate testDate = LocalDate.parse("2020-09-29", DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        booking.setTestDate(testDate);
        booking.setTestTaker(getTestTakerDetails());
        booking.setExternalBookingReference("TestBookingReference");
        List<com.ielts.cmds.booking.common.out.model.BookingLine> list = new ArrayList<>();
        com.ielts.cmds.booking.common.out.model.BookingLine bln1 = new com.ielts.cmds.booking.common.out.model.BookingLine();
        bln1.setBookingLineUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        Instant startTimeUTC = Instant.parse("2020-09-29T17:30:35.723Z");
        bln1.setStartDatetime(startTimeUTC);
        LocalDateTime startTimeLocal = LocalDateTime.parse("2020-09-29T21:00:35.723Z", DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
        bln1.setStartTimeLocal(startTimeLocal);
        bln1.setBookingLineStatus(BookingLineStatusEnum.ACTIVE);
        bln1.setProductUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
        list.add(bln1);
        booking.setBookingLines(list);
        List<com.ielts.cmds.booking.common.out.model.BookingLink> bookingLinkList = new ArrayList<>();
        com.ielts.cmds.booking.common.out.model.BookingLink bookingLink = new com.ielts.cmds.booking.common.out.model.BookingLink();
        com.ielts.cmds.booking.common.out.model.LinkedBooking linkedBooking = new com.ielts.cmds.booking.common.out.model.LinkedBooking();
        linkedBooking.setBookingUuid(UUID.fromString("742d0a15-6238-4be0-b893-38122603c5a8"));
        bookingLink.setLinkedBooking(linkedBooking);
        bookingLink.setRole(RoleEnum.fromValue(RoleEnum.SSRORIGINAL.getValue()));
        bookingLinkList.add(bookingLink);
        booking.setBookingLinks(bookingLinkList);
        return booking;
    }

    public static CancelBookingDetails getCancelBookingDetailsBody() {
        CancelBookingDetails booking = new CancelBookingDetails();
        booking.setBookingUuid(UUID.fromString("4fd557d7-701d-4341-8e81-943a8d88fa8c"));
        booking.setExternalBookingUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46598"));
        booking.setBookingStatus(BookingStatusEnum.PAID);
        booking.setBookingDetailStatus(BookingDetailStatusEnum.COMPLETE);
        booking.setExternalBookingReference("TestBookingReference");
        booking.setProductUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
        booking.setLocationUuid(UUID.fromString("742d0a15-6238-4be0-b893-38122603c5a8"));
        LocalDate testDate = LocalDate.parse("2020-09-29", DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        booking.setTestDate(testDate);
        booking.setTestTaker(getTestTakerDetails());
        booking.setExternalBookingReference("TestBookingReference");
        List<com.ielts.cmds.booking.common.out.model.BookingLine> list = new ArrayList<>();
        com.ielts.cmds.booking.common.out.model.BookingLine bln1 = new com.ielts.cmds.booking.common.out.model.BookingLine();
        bln1.setBookingLineUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        bln1.setStartDatetime(OffsetDateTime.now().toInstant());
        bln1.setStartTimeLocal(LocalDateTime.from(OffsetDateTime.now()));
        bln1.setBookingLineStatus(BookingLineStatusEnum.ACTIVE);
        bln1.setProductUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
        bln1.setExtraTimeMinutes(90);
        bln1.setProductUuid(UUID.fromString("17e0db26-7f58-40ae-b5a8-999fb68dca96"));
        list.add(bln1);

        booking.setBookingLines(list);
        return booking;

    }


    public static TransferBookingDetails getTransferBookingDetailsBody() {
        TransferBookingDetails booking = new TransferBookingDetails();
        booking.setBookingUuid(UUID.fromString("4fd557d7-701d-4341-8e81-943a8d88fa8c"));
        booking.setExternalBookingUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46598"));
        booking.setBookingStatus(BookingStatusEnum.PAID);
        booking.setExternalBookingReference("TestBookingReference");
        booking.setProductUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
        booking.setLocationUuid(UUID.fromString("742d0a15-6238-4be0-b893-38122603c5a8"));
        booking.setTestTaker(getTestTakerDetails());
        LocalDate testDate = LocalDate.parse("2020-09-29", DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        booking.setTestDate(testDate);
        booking.setExternalBookingReference("TestBookingReference");
        booking.setBookingDetailStatus(BookingDetailStatusEnum.COMPLETE);
        List<com.ielts.cmds.booking.common.out.model.BookingLine> list = new ArrayList<>();
        com.ielts.cmds.booking.common.out.model.BookingLine bln1 = new com.ielts.cmds.booking.common.out.model.BookingLine();
        bln1.setBookingLineUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        Instant startTimeUTC = Instant.parse("2020-09-29T17:30:35.723Z");
        bln1.setStartDatetime(startTimeUTC);
        LocalDateTime startTimeLocal = LocalDateTime.parse("2020-09-29T21:00:35.723Z", DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
        bln1.setStartTimeLocal(startTimeLocal);
        bln1.setBookingLineStatus(BookingLineStatusEnum.ACTIVE);
        bln1.setProductUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
        bln1.setBookingLineStatus(BookingLineStatusEnum.ACTIVE);
        bln1.setProductUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
        bln1.setExtraTimeMinutes((500));
        bln1.setExternalBookingLineUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
        Instant endTimeUTC = Instant.parse("2020-09-29T17:30:35.723Z");
        bln1.setEndDatetime(endTimeUTC);
        list.add(bln1);

        booking.setBookingLines(list);
        return booking;
    }

    public static Booking setBookingForTest() {
        Booking booking = Booking.builder().build();
        booking.setBookingUuid(UUID.fromString("4fd557d7-701d-4341-8e81-943a8d88fa8c"));
        booking.setShortCandidateNumber(123457);
        booking.setBookingStatus("PAID");
        booking.setConcurrencyVersion(null);
        booking.setProductUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
        booking.setLocationUuid(UUID.fromString("742d0a15-6238-4be0-b893-38122603c5a8"));
        LocalDate testDateLocal = LocalDate.parse("2020-09-29", DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        booking.setEventDatetime(LocalDateTime.now());
        OffsetDateTime offsetDateTime = OffsetDateTime.of(testDateLocal, LocalTime.MIDNIGHT, UTC);
        CMDSOffsetDatetime testDate = new CMDSOffsetDatetime(offsetDateTime);
       	booking.setTestDate(testDate);
       	booking.setEventDatetime(LocalDateTime.now(ZoneOffset.UTC).minusMonths(3));
        
        booking.setExternalBookingUuid(UUID.fromString("1f7c250e-2faf-4ec9-97a6-6203e01f2a51"));
        booking.setProductUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        booking.setBookingVersion(BigDecimal.valueOf(2));

        List<BookingLine> list = new ArrayList<>();
        BookingLine bln1 = new BookingLine();
        bln1.setBookingLineUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        bln1.setProductUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
        bln1.setBookingLineStatus(com.ielts.cmds.ri.domain.enums.BookingLineStatusEnum.ACTIVE);
        list.add(bln1);
        booking.setBookingLines(list);

        List<com.ielts.cmds.ri.infrastructure.entity.BookingLink> bookingLinkList = new ArrayList<>();
        com.ielts.cmds.ri.infrastructure.entity.BookingLink bookingLink = new com.ielts.cmds.ri.infrastructure.entity.BookingLink();
        bookingLink.setTargetBookingUuid(UUID.fromString("fb3d85cd-c86a-4c7c-96d8-8d7cbdb6fe78"));
        bookingLink.setRole(BookingRoleEnum.SSRORIGINAL);
        bookingLink.setBookingLinkUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
        bookingLinkList.add(bookingLink);
        booking.setBookingLinks(bookingLinkList);
        return booking;
    }

    public static UniqueTestTaker getUniqueTestTaker() {
        UniqueTestTaker uniqueTestTaker = new UniqueTestTaker();
        uniqueTestTaker.setUniqueTestTakerUuid(getBookingDetailsBody().getTestTaker().getUniqueTestTakerUuid());
        return uniqueTestTaker;
    }

    public static UniqueTestTaker getUniqueTestTakerForCancelled() {
        UniqueTestTaker uniqueTestTaker = new UniqueTestTaker();
        uniqueTestTaker.setUniqueTestTakerUuid(getBookingDetailsBodyCommon().getTestTaker().getUniqueTestTakerUuid());
        return uniqueTestTaker;
    }

    public static com.ielts.cmds.booking.common.out.model.TestTakerDetails getTestTakerDetails() {
        TestTakerDetails testTakerDetails = new TestTakerDetails();
        testTakerDetails.setShortCandidateNumber("123457");
        testTakerDetails.setUniqueTestTakerUuid(UUID.fromString("e427ff0e-698e-48af-bf54-5aba8c95606d"));
        testTakerDetails.setUniqueTestTakerId("2514cf2d-1252-4ecc-8d76-67ed5d663d46");
        testTakerDetails.setIdentityVerificationStatus(IdentityVerificationStatusEnum.VERIFIED);


        return testTakerDetails;
    }

    public static com.ielts.cmds.api.evt_019.TestTakerDetailsV1 getTestTakerDetailsEvt019() {
        com.ielts.cmds.api.evt_019.TestTakerDetailsV1 testTakerDetails = new com.ielts.cmds.api.evt_019.TestTakerDetailsV1();
        testTakerDetails.setShortCandidateNumber("123457");
        testTakerDetails.setUniqueTestTakerUuid(UUID.fromString("e427ff0e-698e-48af-bf54-5aba8c95606d"));
        testTakerDetails.setUniqueTestTakerId("2514cf2d-1252-4ecc-8d76-67ed5d663d46");
        testTakerDetails.setIdentityVerificationStatus(com.ielts.cmds.api.evt_019.TestTakerDetailsV1.IdentityVerificationStatusEnum.VERIFIED);
        return testTakerDetails;
    }


    public static Booking setSSRBookingForTest() {
        Booking booking = Booking.builder().build();
        booking.setBookingUuid(UUID.fromString("4fd557d7-701d-4341-8e81-943a8d88fa8c"));
        booking.setShortCandidateNumber(123457);
        booking.setConcurrencyVersion(null);
        booking.setProductUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
        booking.setLocationUuid(UUID.fromString("742d0a15-6238-4be0-b893-38122603c5a8"));
        
        LocalDate testDateLocal = LocalDate.parse("2020-09-29", DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        
        OffsetDateTime offsetDateTime = OffsetDateTime.of(testDateLocal, LocalTime.MIDNIGHT, UTC);
        CMDSOffsetDatetime testDate = new CMDSOffsetDatetime(offsetDateTime);
       	booking.setTestDate(testDate);
       	
        booking.setExternalBookingUuid(UUID.fromString("1f7c250e-2faf-4ec9-97a6-6203e01f2a51"));
        booking.setProductUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));

        List<BookingLine> list = new ArrayList<>();
        BookingLine bln1 = new BookingLine();
        BookingLine bln2 = new BookingLine();
        bln1.setBookingLineUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        bln1.setProductUuid(UUID.fromString("4fd557d7-701d-4341-8e81-943a8d88fa8c"));
        bln1.setBookingLineStatus(com.ielts.cmds.ri.domain.enums.BookingLineStatusEnum.ACTIVE);

        bln2.setBookingLineUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        bln2.setProductUuid(UUID.fromString("4fd557d7-701d-4341-8e81-943a8d88fa8c"));
        bln2.setBookingLineStatus(com.ielts.cmds.ri.domain.enums.BookingLineStatusEnum.INACTIVE);

        list.add(bln1);
        list.add(bln2);
        booking.setBookingLines(list);

        List<com.ielts.cmds.ri.infrastructure.entity.BookingLink> bookingLinkList = new ArrayList<>();
        com.ielts.cmds.ri.infrastructure.entity.BookingLink bookingLink = new com.ielts.cmds.ri.infrastructure.entity.BookingLink();
        com.ielts.cmds.ri.infrastructure.entity.BookingLink bookingLink2 = new com.ielts.cmds.ri.infrastructure.entity.BookingLink();

        bookingLink.setBookingLinkUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        bookingLink.setTargetBookingUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
        bookingLink.setSourceBookingUuid(UUID.fromString("4fd557d7-701d-4341-8e81-943a8d88fa8c"));
        bookingLink.setRole(BookingRoleEnum.SSRORIGINAL);
        bookingLink.setConcurrencyVersion(0);

        bookingLink2.setBookingLinkUuid(UUID.fromString("36a46e15-0ecb-4fa0-9882-557c8b66403b"));
        bookingLink2.setTargetBookingUuid(UUID.fromString("9d8288d2-0a46-417e-b47b-965aa6c2943b"));
        bookingLink2.setSourceBookingUuid(UUID.fromString("c1f1b95b-0011-4739-bf1a-f0ef7cd4fdc7"));
        bookingLink2.setRole(BookingRoleEnum.SSRORIGINAL);
        bookingLink2.setConcurrencyVersion(0);
        bookingLinkList.add(bookingLink);
        bookingLinkList.add(bookingLink2);
        booking.setBookingLinks(bookingLinkList);


        return booking;
    }

    public static CancelBookingDetails getBookingDetailsBodyForCancelled() {
        CancelBookingDetails booking = new CancelBookingDetails();
        booking.setBookingUuid(UUID.fromString("4fd557d7-701d-4341-8e81-943a8d88fa8c"));
        booking.setExternalBookingUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46598"));
        booking.setBookingStatus(BookingStatusEnum.PAID);
        booking.setExternalBookingReference("TestBookingReference");
        booking.setProductUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
        booking.setLocationUuid(UUID.fromString("742d0a15-6238-4be0-b893-38122603c5a8"));
        LocalDate testDate = LocalDate.parse("2020-09-29", DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        booking.setTestDate(testDate);
        booking.setTestTaker(getTestTakerDetails());
        booking.setExternalBookingReference("TestBookingReference");
        List<com.ielts.cmds.booking.common.out.model.BookingLine> list = new ArrayList<>();
        com.ielts.cmds.booking.common.out.model.BookingLine bln1 = new com.ielts.cmds.booking.common.out.model.BookingLine();
        bln1.setBookingLineUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        Instant startTimeUTC = Instant.parse("2020-09-29T17:30:35.723Z");
        bln1.setStartDatetime(startTimeUTC);
        LocalDateTime startTimeLocal = LocalDateTime.parse("2020-09-29T21:00:35.723Z", DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
        bln1.setStartTimeLocal(startTimeLocal);
        bln1.setBookingLineStatus(BookingLineStatusEnum.ACTIVE);
        bln1.setProductUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
        list.add(bln1);
        booking.setBookingLines(list);
        List<com.ielts.cmds.booking.common.out.model.BookingLink> bookingLinkList = new ArrayList<>();
        com.ielts.cmds.booking.common.out.model.BookingLink bookingLink = new com.ielts.cmds.booking.common.out.model.BookingLink();
        com.ielts.cmds.booking.common.out.model.LinkedBooking linkedBooking = new com.ielts.cmds.booking.common.out.model.LinkedBooking();
        linkedBooking.setBookingUuid(UUID.fromString("742d0a15-6238-4be0-b893-38122603c5a8"));
        bookingLink.setLinkedBooking(linkedBooking);
        bookingLink.setRole(RoleEnum.fromValue(RoleEnum.SSRORIGINAL.getValue()));
        bookingLinkList.add(bookingLink);
        booking.setBookingLinks(bookingLinkList);
        return booking;
    }

    public static List<BookingLine> getBookingLines() {
        List<BookingLine> bookingLineList = new ArrayList<>();
        BookingLine bookingLine = new BookingLine();
        bookingLine.setBookingLineUuid(UUID.fromString("742d0a15-6238-4be0-b893-38122603c5a8"));
        bookingLine.setProductUuid(UUID.fromString("00000a15-6238-4be0-b893-38122603c5a8"));
        bookingLine.setBookingLineStatus(com.ielts.cmds.ri.domain.enums.BookingLineStatusEnum.ACTIVE);
        bookingLineList.add(bookingLine);
        return bookingLineList;
    }
}