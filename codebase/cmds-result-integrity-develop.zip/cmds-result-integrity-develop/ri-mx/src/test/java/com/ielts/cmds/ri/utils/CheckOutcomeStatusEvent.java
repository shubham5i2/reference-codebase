package com.ielts.cmds.ri.utils;

import static java.time.ZoneOffset.UTC;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.ielts.cmds.common.persistence.utils.CMDSOffsetDatetime;
import com.ielts.cmds.ri.infrastructure.entity.Booking;
import com.ielts.cmds.ri.infrastructure.entity.BookingLine;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcome;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeStatus;
import com.ielts.cmds.ri.infrastructure.entity.CheckOutcomeType;
import com.ielts.cmds.ri.utils.RIConstants.PrcOutcomeConstant;

public class CheckOutcomeStatusEvent {

  public static CheckOutcomeType getCheckOutcomeType(){
    CheckOutcomeType checkOutcomeType = new CheckOutcomeType();
    checkOutcomeType.setCheckOutcomeTypeUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
    checkOutcomeType.setCheckOutcomeType(RIConstants.PrcOutcomeConstant.LRW_INC_CHK);
    checkOutcomeType.setCheckOutcomeTypeCode("LRW_ID_INC_CHK");
    return checkOutcomeType;
  }

  public static CheckOutcomeStatus getCheckOutcomeStatusAsCleared(){
    CheckOutcomeStatus checkOutcomeStatus = new CheckOutcomeStatus();
    checkOutcomeStatus.setCheckOutcomeStatusUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
    checkOutcomeStatus.setCheckOutcomeStatusCode(RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_CLEARED);
    return checkOutcomeStatus;
  }

  public static CheckOutcomeStatus getCheckOutcomeStatusAsFailed(){
    CheckOutcomeStatus checkOutcomeStatus = new CheckOutcomeStatus();
    checkOutcomeStatus.setCheckOutcomeStatusUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
    checkOutcomeStatus.setCheckOutcomeStatusCode(PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_FAILED);
    return checkOutcomeStatus;
  }

  public static CheckOutcome getCheckoutCome(){
    CheckOutcome checkOutcome = new CheckOutcome();
    checkOutcome.setCheckOutcomeStatus(getCheckOutcomeStatusAsCleared());
    checkOutcome.setCheckOutcomeUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
    checkOutcome.setCheckOutcomeType(getCheckOutcomeType());
    checkOutcome.setBookingVersion(BigDecimal.valueOf(3));
    checkOutcome.setEventDateTime(LocalDateTime.now());
    return checkOutcome;
  }
  public static CheckOutcome getCheckoutComeForIncident(){
    CheckOutcome checkOutcome = new CheckOutcome();
    checkOutcome.setCheckOutcomeStatus(getCheckOutcomeStatusAsCleared());
    checkOutcome.setCheckOutcomeUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
    checkOutcome.setCheckOutcomeType(getCheckOutcomeType());
    return checkOutcome;
  }

  public static CheckOutcome getCheckoutComeAsFailed(){
    CheckOutcome checkOutcome = new CheckOutcome();
    checkOutcome.setCheckOutcomeStatus(getCheckOutcomeStatusAsFailed());
    checkOutcome.setCheckOutcomeUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
    checkOutcome.setCheckOutcomeType(getCheckOutcomeType());
    checkOutcome.setEventDateTime(LocalDateTime.now());
    return checkOutcome;
  }

  public static CheckOutcomeStatus getCheckOutcomeStatusAsReview(){
    CheckOutcomeStatus checkOutcomeStatus = new CheckOutcomeStatus();
    checkOutcomeStatus.setCheckOutcomeStatusUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
    checkOutcomeStatus.setCheckOutcomeStatusCode(RIConstants.PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_REVIEW);
    return checkOutcomeStatus;
  }

  public static CheckOutcomeStatus getCheckOutcomeStatusAsPassed(){
    CheckOutcomeStatus checkOutcomeStatus = new CheckOutcomeStatus();
    checkOutcomeStatus.setCheckOutcomeStatusUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
    checkOutcomeStatus.setCheckOutcomeStatusCode(PrcOutcomeConstant.CHECK_OUTCOME_STATUS_CODE_PASSED);
    return checkOutcomeStatus;
  }

  public static CheckOutcome getPassedCheckoutCome(){
    CheckOutcome checkOutcome = new CheckOutcome();
    checkOutcome.setBookingUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
    checkOutcome.setCheckOutcomeStatus(getCheckOutcomeStatusAsPassed());
    checkOutcome.setCheckOutcomeUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
    checkOutcome.setCheckOutcomeType(getCheckOutcomeType());
    checkOutcome.setEventDateTime(LocalDateTime.now());
    return checkOutcome;
  }

  public static Booking getBookingForTest() {
    Booking booking = Booking.builder().build();
    booking.setBookingUuid(UUID.fromString("4fd557d7-701d-4341-8e81-943a8d88fa8c"));
    booking.setShortCandidateNumber(123457);
    booking.setConcurrencyVersion(null);
    booking.setProductUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
    booking.setLocationUuid(UUID.fromString("742d0a15-6238-4be0-b893-38122603c5a8"));
    booking.setEventDatetime(LocalDateTime.now());
    LocalDate testDateLocal = LocalDate.parse("2020-09-29", DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    
    OffsetDateTime offsetDateTime = OffsetDateTime.of(testDateLocal, LocalTime.MIDNIGHT, UTC);
    CMDSOffsetDatetime testDate = new CMDSOffsetDatetime(offsetDateTime);
   	booking.setTestDate(testDate);
   	
    booking.setExternalBookingUuid(UUID.fromString("1f7c250e-2faf-4ec9-97a6-6203e01f2a51"));
    booking.setProductUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
    booking.setBookingVersion(BigDecimal.valueOf(3));

    List<BookingLine> list = new ArrayList<>();
    BookingLine bln1 = new BookingLine();
    bln1.setBookingLineUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
    bln1.setProductUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
    list.add(bln1);
    booking.setBookingLines(list);
    return booking;
  }

  public static CheckOutcome getCheckoutComeWithNewVersion(){
    CheckOutcome checkOutcome = new CheckOutcome();
    checkOutcome.setCheckOutcomeStatus(getCheckOutcomeStatusAsCleared());
    checkOutcome.setCheckOutcomeUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
    checkOutcome.setCheckOutcomeType(getCheckOutcomeType());
    checkOutcome.setBookingVersion(BigDecimal.valueOf(1));
    checkOutcome.setEventDateTime(LocalDateTime.now());
    return checkOutcome;
  }

}
