package com.ielts.cmds.ri.application.service;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.springframework.dao.PessimisticLockingFailureException;

import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.common.model.out.OverallIntegrityCheckInitiatedV1;
import com.ielts.cmds.ri.domain.service.OverallIntegrityCheckDomainService;
import com.ielts.cmds.ri.utils.OverallIntegrityCheckEvent;
import com.ielts.cmds.ri.utils.RIConstants;

@ExtendWith(MockitoExtension.class)
class OverallIntegrityCheckServiceTest {

  @Captor
  ArgumentCaptor<String> logCaptor;

  @Spy
  Logger log;
  @Spy
  @InjectMocks
  OverallIntegrityCheckService overallIntegrityCheckService;

  @Mock
  OverallIntegrityCheckDomainService overallIntegrityCheckDomainService;

  @BeforeEach
  void init() throws NoSuchFieldException, IllegalAccessException {
    ThreadLocalHeaderContext.setContext(new CMDSHeaderContext());
    ThreadLocalHeaderContext.getContext().setTransactionId(UUID.randomUUID());
    Field field = OverallIntegrityCheckService.class.getDeclaredField("log");
    field.setAccessible(true);
    Field modifiersField = Field.class.getDeclaredField("modifiers");
    modifiersField.setAccessible(true);
    modifiersField.setInt(field, field.getModifiers() & ~Modifier.FINAL);
    field.set(null, log);
  }


  @Test
  void whenProcessCalledShouldThrowException() {
    assertThrows(ProcessingException.class, () -> overallIntegrityCheckService.process(null));
  }

  @Test
  void whenProcessCalled_shouldProcessTheData() {
    OverallIntegrityCheckInitiatedV1 overallIntegrityCheckInitiatedV1 = OverallIntegrityCheckEvent.buildOverallIntegrityCheck();

    Mockito.doNothing().when(overallIntegrityCheckDomainService).on();

    overallIntegrityCheckService.process(overallIntegrityCheckInitiatedV1);

    verify(overallIntegrityCheckDomainService).on();
  }

  @Test
  void whenProcessCalled_whenPayloadIsEmpty_shouldThrowException() {
    assertThrows(ProcessingException.class, () -> overallIntegrityCheckService.process(null));
  }

  @Test
  void process_ShouldLogAlert_WhenPessimisticLockingFailureException() {
    doThrow(PessimisticLockingFailureException.class).when(overallIntegrityCheckDomainService).on();
    OverallIntegrityCheckInitiatedV1 overallIntegrityCheckInitiatedV1 =
        OverallIntegrityCheckEvent.buildOverallIntegrityCheck();
    overallIntegrityCheckService.process(overallIntegrityCheckInitiatedV1);
    verify(log, times(2)).info(logCaptor.capture(), logCaptor.capture());
    verify(log, times(1)).warn(anyString(),any(PessimisticLockingFailureException.class));
    verifyNoMoreInteractions(log);
    assertAll(
        () -> assertEquals(4, logCaptor.getAllValues().size()),
        () ->
            assertEquals(
                "Another instance of {} is already running", logCaptor.getAllValues().get(2)),
        () ->
            assertEquals(
                RIConstants.EventType.OVERALL_INTEGRITY_CHECK_INITIATED,
                logCaptor.getAllValues().get(3)));
  }
}
