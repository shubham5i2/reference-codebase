package com.ielts.cmds.ri.domain.service;

import static org.mockito.Mockito.doNothing;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.evt_019.BookingDetailsV1;
import com.ielts.cmds.ri.utils.BookingDetailsEvent;

@ExtendWith(MockitoExtension.class)
class BookingCreatedDomainServiceTest {

	@InjectMocks
	@Spy
	private BookingCreatedDomainService bookingCreatedDomainService;

	@Test
	void bookingCreatedCheck() throws JsonProcessingException {
		doNothing().when(bookingCreatedDomainService).process(ArgumentMatchers.any(BookingDetailsV1.class));
		Executable executable = () -> bookingCreatedDomainService.on(BookingDetailsEvent.getBookingDetailsBody());
		Assertions.assertDoesNotThrow(executable);
	}
}
