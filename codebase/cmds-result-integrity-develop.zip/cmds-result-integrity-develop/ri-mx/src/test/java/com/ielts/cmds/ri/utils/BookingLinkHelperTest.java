package com.ielts.cmds.ri.utils;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.booking.common.out.model.BookingDetails;
import com.ielts.cmds.ri.infrastructure.repository.BookingLineRepository;

@ExtendWith(MockitoExtension.class)
class BookingLinkHelperTest {


    @Spy
    @InjectMocks
    BookingLinkHelper bookingLinkHelper;
    @Mock
    BookingLineRepository bookingLineRepository;

    @Test
    void updateBookingLink_When_BookingLink_Is_Optional() {

        BookingDetails bookingDetails=BookingDetailsEvent.getBookingDetailsBodyCommon();
        bookingLinkHelper.updateBookingLinkDetails(bookingDetails.getBookingUuid(), bookingDetails);
        Assertions.assertDoesNotThrow(() -> bookingLinkHelper.updateBookingLinkDetails(bookingDetails.getBookingUuid(), bookingDetails));
    }

}
