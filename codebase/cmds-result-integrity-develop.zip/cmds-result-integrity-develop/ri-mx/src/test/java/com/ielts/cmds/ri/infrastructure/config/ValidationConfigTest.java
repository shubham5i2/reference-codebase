package com.ielts.cmds.ri.infrastructure.config;

import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(SpringExtension.class)
@EnableConfigurationProperties(value = ValidationConfig.class)
@TestPropertySource("classpath:errorCode.properties")
@ContextConfiguration(
        loader = AnnotationConfigContextLoader.class,
        classes = {ValidationConfig.class})
class ValidationConfigTest<T> {

    @Autowired
    private ValidationConfig<T> validationConfig;

    @Autowired
    private CMDSErrorResolver<T> errorResolver;

    @Test
    void whenValidationConfigInvoked_errorCodePropertiesLoadedCorrectly() {
        String expectedError = "Headers cannot be null or Empty.";
        assertNotNull(validationConfig.getErrorCode());
        assertEquals(5, validationConfig.getErrorCode().size());
        assertEquals(expectedError, validationConfig.getErrorCode().get("V00006").trim());
    }

    @Test
    void testCMDSErrorResolverBeanCreated() {
        assertNotNull(errorResolver);
        assertNotNull(errorResolver.getErrorCodeMapper());
        assertEquals(5, errorResolver.getErrorCodeMapper().size());
    }
}
