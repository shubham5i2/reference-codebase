package com.ielts.cmds.ri.infrastructure.event.listener;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;

import java.io.IOException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.booking.common.out.model.BookingDetails;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.ri.utils.RIConstants;
import com.ielts.cmds.ri.utils.RIUtil;

/**
 * The type Booking ui listener test.
 */
@ExtendWith(MockitoExtension.class)
class RIUiListenerTest {

	@InjectMocks
	@Spy
	private RIUiListener bookingUiListener;

	private ObjectMapper mapper = new ObjectMapper();

	private Message<String> message;

	private CMDSHeaderContext headerContext;

	/**
	 * Init.
	 *
	 * @throws IOException the io exception
	 */
	@BeforeEach
	void init() throws IOException {
		headerContext = RIUtil.createCMDSHeaderContextByEventName(RIConstants.EventType.BOOKING_CREATED_EVENT);
		BookingDetails details = new BookingDetails();

		message = MessageBuilder.withPayload(mapper.writeValueAsString(details)).setHeader("eventHeader", headerContext)
				.build();
	}

	/**
	 * This test should not throw any exception when valid sqs message is
	 * received @throws JsonProcessingException the json processing exception
	 *
	 * @throws ProcessingException the processing exception
	 */
	@Test
	void whenValidIntSqsMessageIsReceived_ThenNoExceptionIsRaised() {

		doNothing().when(bookingUiListener).onReceive(message.getHeaders(), message.getPayload());

		Executable executable = () -> bookingUiListener.onReceive(message);
		Assertions.assertDoesNotThrow(executable);
	}

	/**
	 * When invalid event name in int sqs message is received then no exception is
	 * raised.
	 *
	 * @throws JsonProcessingException the json processing exception
	 * @throws ProcessingException     the processing exception
	 */
	@Test
	void whenInvalidEventNameInIntSqsMessageIsReceived_ThenNoExceptionIsRaised() {

		doThrow(RuntimeException.class).when(bookingUiListener).onReceive(message.getHeaders(), message.getPayload());

		Executable executable = () -> bookingUiListener.onReceive(message);
		Assertions.assertThrows(RuntimeException.class, executable);
	}

}
