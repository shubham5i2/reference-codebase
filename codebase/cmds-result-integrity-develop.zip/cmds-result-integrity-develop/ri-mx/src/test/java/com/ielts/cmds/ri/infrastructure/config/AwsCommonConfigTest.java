package com.ielts.cmds.ri.infrastructure.config;

import com.amazonaws.services.s3.AmazonS3;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

/** The type Aws common config test. */
@ExtendWith(MockitoExtension.class)
class AwsCommonConfigTest {

    /** The Aws common config. */
    @InjectMocks
    AwsCommonConfig awsCommonConfig;

    @BeforeEach
    void setUp(){
        awsCommonConfig=new AwsCommonConfig("eu_west_2");
    }
    /** Test get s3 client. */
    @Test
    void testGetS3Client() {
        AmazonS3 s3ClientResult = awsCommonConfig.getAmazonS3Client();
        Assertions.assertNotNull(s3ClientResult);
    }
}
