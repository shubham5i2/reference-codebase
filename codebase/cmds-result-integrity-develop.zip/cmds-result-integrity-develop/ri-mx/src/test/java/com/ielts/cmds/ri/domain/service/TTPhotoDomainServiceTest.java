package com.ielts.cmds.ri.domain.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ri.infrastructure.entity.TestTakerPhoto;
import com.ielts.cmds.ri.infrastructure.repository.TestTakerPhotoRepository;
import com.ielts.cmds.ri.utils.TTPhotoEvent;
import com.ielts.cmds.testtaker.common.events.model.PhotoCategoryEnum;
import com.ielts.cmds.testtaker.common.events.model.PhotoPublishedV1;

@ExtendWith(MockitoExtension.class)
class TTPhotoDomainServiceTest {

	@InjectMocks
	@Spy
	private TTPhotoDomainService ttDomainService;

	@Mock
	private TestTakerPhotoRepository repository;

	@Test
	void whenReceivingPhotoPublishedEvent_ThenPhotoIsSavedInDB() {
		CMDSHeaderContext ctx = new CMDSHeaderContext();
		ctx.setEventDateTime(LocalDateTime.now());
		ctx.setEventName("Test");
		ThreadLocalHeaderContext.setContext(ctx);
		doNothing().when(ttDomainService).publishEvent(ArgumentMatchers.any());
		final Executable executable = () -> ttDomainService.on(TTPhotoEvent.generatePhotoPublished());
		assertDoesNotThrow(executable);
	}

	@Test
	void whenGeneratePhotoMethodsIsCalled_generateCorrectPhotoObject() {
		CMDSHeaderContext ctx = new CMDSHeaderContext();
		ctx.setEventDateTime(LocalDateTime.now());
		ctx.setEventName("Test");
		ThreadLocalHeaderContext.setContext(ctx);
		TestTakerPhoto optionalPhoto = new TestTakerPhoto();
		optionalPhoto.setPhotoPath("test.com/testFilename");
		optionalPhoto.setPhotoUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
		optionalPhoto.setPhotoVersion(1);
		optionalPhoto.setPhotoTypeUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
		optionalPhoto.setBookingUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
		
		final TestTakerPhoto photo = ttDomainService.generatePhotoFrom(optionalPhoto,TTPhotoEvent.generatePhotoPublished());
		PhotoPublishedV1 photoPublishedV1 = TTPhotoEvent.generatePhotoPublished();
		assertEquals(photoPublishedV1.getBookingUuid(), photo.getBookingUuid());
		assertEquals(photoPublishedV1.getPhotoUuid(), photo.getPhotoTypeUuid());
		assertEquals(photoPublishedV1.getPhotoVersion(), photo.getPhotoVersion());
		assertEquals(photoPublishedV1.getPhotoTypeUuid(), photo.getPhotoTypeUuid());
		assertEquals("test.com/testFilename", photo.getPhotoPath());
		Assertions.assertNotNull(photo.getPhotoUuid());
		assertEquals(photoPublishedV1.getPhotoCategory().getValue(), photo.getPhotoCategory().getValue());
	}
}
