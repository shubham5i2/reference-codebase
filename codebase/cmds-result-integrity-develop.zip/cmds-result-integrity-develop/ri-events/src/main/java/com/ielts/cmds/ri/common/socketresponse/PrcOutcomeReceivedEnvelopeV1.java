package com.ielts.cmds.ri.common.socketresponse;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
public class PrcOutcomeReceivedEnvelopeV1 {
    @JsonProperty("meta")
    private SocketResponseMetaDataV1 meta;
    @JsonProperty("response")
    private Object response;
    @JsonProperty("errors")
    private BaseEventErrors errors;

}
