
package com.ielts.cmds.ri.common.socketresponse;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;

/**
 * Event that goes in the topic
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaClientCodegen", date = "2021-12-29T11:51:29.594Z[GMT]")
public class SearchBookingEnvelopeV1 {
  @SerializedName("meta")
  private SocketResponseMetaDataV1 meta = null;

  @SerializedName("response")
  private BookingSearchResultV1 response = null;

  @SerializedName("errors")
  private BaseEventErrors errors = null;

  public SearchBookingEnvelopeV1 meta(SocketResponseMetaDataV1 meta) {
    this.meta = meta;
    return this;
  }

   /**
   * Get meta
   * @return meta
  **/
  public SocketResponseMetaDataV1 getMeta() {
    return meta;
  }

  public void setMeta(SocketResponseMetaDataV1 meta) {
    this.meta = meta;
  }

  public SearchBookingEnvelopeV1 response(BookingSearchResultV1 response) {
    this.response = response;
    return this;
  }

   /**
   * Get response
   * @return response
  **/
  public BookingSearchResultV1 getResponse() {
    return response;
  }

  public void setResponse(BookingSearchResultV1 response) {
    this.response = response;
  }

  public SearchBookingEnvelopeV1 errors(BaseEventErrors errors) {
    this.errors = errors;
    return this;
  }

   /**
   * Get errors
   * @return errors
  **/
  public BaseEventErrors getErrors() {
    return errors;
  }

  public void setErrors(BaseEventErrors errors) {
    this.errors = errors;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SearchBookingEnvelopeV1 searchBookingEnvelopeV1 = (SearchBookingEnvelopeV1) o;
    return Objects.equals(this.meta, searchBookingEnvelopeV1.meta) &&
        Objects.equals(this.response, searchBookingEnvelopeV1.response) &&
        Objects.equals(this.errors, searchBookingEnvelopeV1.errors);
  }

  @Override
  public int hashCode() {
    return Objects.hash(meta, response, errors);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SearchBookingEnvelopeV1 {\n");
    
    sb.append("    meta: ").append(toIndentedString(meta)).append("\n");
    sb.append("    response: ").append(toIndentedString(response)).append("\n");
    sb.append("    errors: ").append(toIndentedString(errors)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}
