
package com.ielts.cmds.ri.common.socketresponse;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * IncidentEvidenceV1Inner
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaClientCodegen", date = "2022-07-08T06:21:51.566Z[GMT]")
public class IncidentEvidenceV1Inner {

  @SerializedName("evidenceName")
  private String evidenceName = null;

  @SerializedName("evidenceUrl")
  private String evidenceUrl = null;

  @SerializedName("evidenceFileExtention")
  private String evidenceFileExtention = null;

}
