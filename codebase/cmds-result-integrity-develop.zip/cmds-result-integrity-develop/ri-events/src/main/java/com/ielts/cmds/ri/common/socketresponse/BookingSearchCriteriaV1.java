
package com.ielts.cmds.ri.common.socketresponse;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

import java.util.Objects;

/**
 * Criteria for searching booking
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaClientCodegen", date = "2021-12-29T11:51:29.594Z[GMT]")
public class BookingSearchCriteriaV1 {
  @SerializedName("uniqueTestTakerId")
  private String uniqueTestTakerId = null;

  @SerializedName("shortCandidateNumber")
  private String shortCandidateNumber = null;

  @SerializedName("centreId")
  private String centreId = null;

  @SerializedName("firstName")
  private String firstName = null;

  @SerializedName("lastName")
  private String lastName = null;

  @SerializedName("testDate")
  private LocalDate testDate = null;

  @SerializedName("birthDate")
  private LocalDate birthDate = null;

  @SerializedName("identityNumber")
  private String identityNumber = null;

  @SerializedName("checkOutcome")
  private CheckOutcomeV1 checkOutcome = null;

  public BookingSearchCriteriaV1 uniqueTestTakerId(String uniqueTestTakerId) {
    this.uniqueTestTakerId = uniqueTestTakerId;
    return this;
  }

   /**
   * Get uniqueTestTakerId
   * @return uniqueTestTakerId
  **/
  public String getUniqueTestTakerId() {
    return uniqueTestTakerId;
  }

  public void setUniqueTestTakerId(String uniqueTestTakerId) {
    this.uniqueTestTakerId = uniqueTestTakerId;
  }

  public BookingSearchCriteriaV1 shortCandidateNumber(String shortCandidateNumber) {
    this.shortCandidateNumber = shortCandidateNumber;
    return this;
  }

   /**
   * 6 digit test taker number
   * @return shortCandidateNumber
  **/
  public String getShortCandidateNumber() {
    return shortCandidateNumber;
  }

  public void setShortCandidateNumber(String shortCandidateNumber) {
    this.shortCandidateNumber = shortCandidateNumber;
  }

  public BookingSearchCriteriaV1 centreId(String centreId) {
    this.centreId = centreId;
    return this;
  }

   /**
   * Get centreId
   * @return centreId
  **/
  public String getCentreId() {
    return centreId;
  }

  public void setCentreId(String centreId) {
    this.centreId = centreId;
  }

  public BookingSearchCriteriaV1 firstName(String firstName) {
    this.firstName = firstName;
    return this;
  }

   /**
   * Get firstName
   * @return firstName
  **/
  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public BookingSearchCriteriaV1 lastName(String lastName) {
    this.lastName = lastName;
    return this;
  }

   /**
   * Get lastName
   * @return lastName
  **/
  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public BookingSearchCriteriaV1 testDate(LocalDate testDate) {
    this.testDate = testDate;
    return this;
  }

   /**
   * Get testDate
   * @return testDate
  **/
  public LocalDate getTestDate() {
    return testDate;
  }

  public void setTestDate(LocalDate testDate) {
    this.testDate = testDate;
  }

  public BookingSearchCriteriaV1 birthDate(LocalDate birthDate) {
    this.birthDate = birthDate;
    return this;
  }

   /**
   * Get birthDate
   * @return birthDate
  **/
  public LocalDate getBirthDate() {
    return birthDate;
  }

  public void setBirthDate(LocalDate birthDate) {
    this.birthDate = birthDate;
  }

  public BookingSearchCriteriaV1 identityNumber(String identityNumber) {
    this.identityNumber = identityNumber;
    return this;
  }

   /**
   * Get identityNumber
   * @return identityNumber
  **/
  public String getIdentityNumber() {
    return identityNumber;
  }

  public void setIdentityNumber(String identityNumber) {
    this.identityNumber = identityNumber;
  }

  public BookingSearchCriteriaV1 checkOutcome(CheckOutcomeV1 checkOutcome) {
    this.checkOutcome = checkOutcome;
    return this;
  }

   /**
   * Get checkOutcome
   * @return checkOutcome
  **/
  public CheckOutcomeV1 getCheckOutcome() {
    return checkOutcome;
  }

  public void setCheckOutcome(CheckOutcomeV1 checkOutcome) {
    this.checkOutcome = checkOutcome;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BookingSearchCriteriaV1 bookingSearchCriteriaV1 = (BookingSearchCriteriaV1) o;
    return Objects.equals(this.uniqueTestTakerId, bookingSearchCriteriaV1.uniqueTestTakerId) &&
        Objects.equals(this.shortCandidateNumber, bookingSearchCriteriaV1.shortCandidateNumber) &&
        Objects.equals(this.centreId, bookingSearchCriteriaV1.centreId) &&
        Objects.equals(this.firstName, bookingSearchCriteriaV1.firstName) &&
        Objects.equals(this.lastName, bookingSearchCriteriaV1.lastName) &&
        Objects.equals(this.testDate, bookingSearchCriteriaV1.testDate) &&
        Objects.equals(this.birthDate, bookingSearchCriteriaV1.birthDate) &&
        Objects.equals(this.identityNumber, bookingSearchCriteriaV1.identityNumber) &&
        Objects.equals(this.checkOutcome, bookingSearchCriteriaV1.checkOutcome);
  }

  @Override
  public int hashCode() {
    return Objects.hash(uniqueTestTakerId, shortCandidateNumber, centreId, firstName, lastName, testDate, birthDate, identityNumber, checkOutcome);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BookingSearchCriteriaV1 {\n");
    
    sb.append("    uniqueTestTakerId: ").append(toIndentedString(uniqueTestTakerId)).append("\n");
    sb.append("    shortCandidateNumber: ").append(toIndentedString(shortCandidateNumber)).append("\n");
    sb.append("    centreId: ").append(toIndentedString(centreId)).append("\n");
    sb.append("    firstName: ").append(toIndentedString(firstName)).append("\n");
    sb.append("    lastName: ").append(toIndentedString(lastName)).append("\n");
    sb.append("    testDate: ").append(toIndentedString(testDate)).append("\n");
    sb.append("    birthDate: ").append(toIndentedString(birthDate)).append("\n");
    sb.append("    identityNumber: ").append(toIndentedString(identityNumber)).append("\n");
    sb.append("    checkOutcome: ").append(toIndentedString(checkOutcome)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}
