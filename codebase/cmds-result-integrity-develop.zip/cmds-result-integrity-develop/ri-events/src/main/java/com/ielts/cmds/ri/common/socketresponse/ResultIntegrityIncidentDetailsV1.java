
package com.ielts.cmds.ri.common.socketresponse;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Result Integrity Incident Details
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaClientCodegen", date = "2022-07-08T06:21:51.566Z[GMT]")
public class ResultIntegrityIncidentDetailsV1 {

  @SerializedName("bookingUuid")
  private String bookingUuid = null;

  @SerializedName("incidentUuid")
  private String incidentUuid = null;

  @SerializedName("incidentCategoryUuid")
  private String incidentCategoryUuid = null;

  @SerializedName("incidentTypeUuid")
  private String incidentTypeUuid = null;

  @SerializedName("incidentStatusTypeUuid")
  private String incidentStatusTypeUuid = null;

  @SerializedName("incidentSeverity")
  private String incidentSeverity = null;

  @SerializedName("banReviewRequired")
  private Boolean banReviewRequired = null;

  @SerializedName("comments")
  private CommentsV1 comments = null;

  @SerializedName("evidences")
  private IncidentEvidenceV1 evidences = null;

}
