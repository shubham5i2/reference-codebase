
package com.ielts.cmds.ri.common.socketresponse;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;

/**
 * IncidentEvidenceV1
 */
@Data
@Builder
@NoArgsConstructor
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaClientCodegen", date = "2022-07-08T06:21:51.566Z[GMT]")
public class IncidentEvidenceV1 extends ArrayList<IncidentEvidenceV1Inner> {

}
