
package com.ielts.cmds.ri.common.socketresponse;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

import java.util.Objects;

/**
 * BookingSearchResultListV1Inner
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaClientCodegen", date = "2021-12-29T11:51:29.594Z[GMT]")
public class BookingSearchResultListV1Inner {
  @SerializedName("bookingUuid")
  private String bookingUuid = null;

  @SerializedName("uniqueTestTakerId")
  private String uniqueTestTakerId = null;

  @SerializedName("shortCandidateNumber")
  private String shortCandidateNumber = null;

  @SerializedName("centreId")
  private String centreId = null;

  @SerializedName("firstName")
  private String firstName = null;

  @SerializedName("lastName")
  private String lastName = null;

  @SerializedName("testDate")
  private LocalDate testDate = null;

  @SerializedName("birthDate")
  private LocalDate birthDate = null;

  @SerializedName("identityNumber")
  private String identityNumber = null;

  public BookingSearchResultListV1Inner bookingUuid(String bookingUuid) {
    this.bookingUuid = bookingUuid;
    return this;
  }

   /**
   * Get bookingUuid
   * @return bookingUuid
  **/
  public String getBookingUuid() {
    return bookingUuid;
  }

  public void setBookingUuid(String bookingUuid) {
    this.bookingUuid = bookingUuid;
  }

  public BookingSearchResultListV1Inner uniqueTestTakerId(String uniqueTestTakerId) {
    this.uniqueTestTakerId = uniqueTestTakerId;
    return this;
  }

   /**
   * Get uniqueTestTakerId
   * @return uniqueTestTakerId
  **/
  public String getUniqueTestTakerId() {
    return uniqueTestTakerId;
  }

  public void setUniqueTestTakerId(String uniqueTestTakerId) {
    this.uniqueTestTakerId = uniqueTestTakerId;
  }

  public BookingSearchResultListV1Inner shortCandidateNumber(String shortCandidateNumber) {
    this.shortCandidateNumber = shortCandidateNumber;
    return this;
  }

   /**
   * 6 digit test taker number
   * @return shortCandidateNumber
  **/
  public String getShortCandidateNumber() {
    return shortCandidateNumber;
  }

  public void setShortCandidateNumber(String shortCandidateNumber) {
    this.shortCandidateNumber = shortCandidateNumber;
  }

  public BookingSearchResultListV1Inner centreId(String centreId) {
    this.centreId = centreId;
    return this;
  }

   /**
   * Get centreId
   * @return centreId
  **/
  public String getCentreId() {
    return centreId;
  }

  public void setCentreId(String centreId) {
    this.centreId = centreId;
  }

  public BookingSearchResultListV1Inner firstName(String firstName) {
    this.firstName = firstName;
    return this;
  }

   /**
   * Get firstName
   * @return firstName
  **/
  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public BookingSearchResultListV1Inner lastName(String lastName) {
    this.lastName = lastName;
    return this;
  }

   /**
   * Get lastName
   * @return lastName
  **/
  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public BookingSearchResultListV1Inner testDate(LocalDate testDate) {
    this.testDate = testDate;
    return this;
  }

   /**
   * Get testDate
   * @return testDate
  **/
  public LocalDate getTestDate() {
    return testDate;
  }

  public void setTestDate(LocalDate testDate) {
    this.testDate = testDate;
  }

  public BookingSearchResultListV1Inner birthDate(LocalDate birthDate) {
    this.birthDate = birthDate;
    return this;
  }

   /**
   * Get birthDate
   * @return birthDate
  **/
  public LocalDate getBirthDate() {
    return birthDate;
  }

  public void setBirthDate(LocalDate birthDate) {
    this.birthDate = birthDate;
  }

  public BookingSearchResultListV1Inner identityNumber(String identityNumber) {
    this.identityNumber = identityNumber;
    return this;
  }

   /**
   * Get identityNumber
   * @return identityNumber
  **/
  public String getIdentityNumber() {
    return identityNumber;
  }

  public void setIdentityNumber(String identityNumber) {
    this.identityNumber = identityNumber;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BookingSearchResultListV1Inner bookingSearchResultListV1Inner = (BookingSearchResultListV1Inner) o;
    return Objects.equals(this.bookingUuid, bookingSearchResultListV1Inner.bookingUuid) &&
        Objects.equals(this.uniqueTestTakerId, bookingSearchResultListV1Inner.uniqueTestTakerId) &&
        Objects.equals(this.shortCandidateNumber, bookingSearchResultListV1Inner.shortCandidateNumber) &&
        Objects.equals(this.centreId, bookingSearchResultListV1Inner.centreId) &&
        Objects.equals(this.firstName, bookingSearchResultListV1Inner.firstName) &&
        Objects.equals(this.lastName, bookingSearchResultListV1Inner.lastName) &&
        Objects.equals(this.testDate, bookingSearchResultListV1Inner.testDate) &&
        Objects.equals(this.birthDate, bookingSearchResultListV1Inner.birthDate) &&
        Objects.equals(this.identityNumber, bookingSearchResultListV1Inner.identityNumber);
  }

  @Override
  public int hashCode() {
    return Objects.hash(bookingUuid, uniqueTestTakerId, shortCandidateNumber, centreId, firstName, lastName, testDate, birthDate, identityNumber);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BookingSearchResultListV1Inner {\n");
    
    sb.append("    bookingUuid: ").append(toIndentedString(bookingUuid)).append("\n");
    sb.append("    uniqueTestTakerId: ").append(toIndentedString(uniqueTestTakerId)).append("\n");
    sb.append("    shortCandidateNumber: ").append(toIndentedString(shortCandidateNumber)).append("\n");
    sb.append("    centreId: ").append(toIndentedString(centreId)).append("\n");
    sb.append("    firstName: ").append(toIndentedString(firstName)).append("\n");
    sb.append("    lastName: ").append(toIndentedString(lastName)).append("\n");
    sb.append("    testDate: ").append(toIndentedString(testDate)).append("\n");
    sb.append("    birthDate: ").append(toIndentedString(birthDate)).append("\n");
    sb.append("    identityNumber: ").append(toIndentedString(identityNumber)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}
