
package com.ielts.cmds.ri.common.socketresponse;

import com.google.gson.annotations.SerializedName;
import lombok.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * BaseEventErrors
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaClientCodegen", date = "2021-12-29T11:51:29.594Z[GMT]")
public class BaseEventErrors {
  @SerializedName("errorList")
  private List<BaseEventErrorsErrorList> errorList = null;

  public BaseEventErrors errorList(List<BaseEventErrorsErrorList> errorList) {
    this.errorList = errorList;
    return this;
  }

  public BaseEventErrors addErrorListItem(BaseEventErrorsErrorList errorListItem) {
    if (this.errorList == null) {
      this.errorList = new ArrayList<BaseEventErrorsErrorList>();
    }
    this.errorList.add(errorListItem);
    return this;
  }

   /**
   * Get errorList
   * @return errorList
  **/
  public List<BaseEventErrorsErrorList> getErrorList() {
    return errorList;
  }

  public void setErrorList(List<BaseEventErrorsErrorList> errorList) {
    this.errorList = errorList;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BaseEventErrors baseEventErrors = (BaseEventErrors) o;
    return Objects.equals(this.errorList, baseEventErrors.errorList);
  }

  @Override
  public int hashCode() {
    return Objects.hash(errorList);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BaseEventErrors {\n");
    
    sb.append("    errorList: ").append(toIndentedString(errorList)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}
