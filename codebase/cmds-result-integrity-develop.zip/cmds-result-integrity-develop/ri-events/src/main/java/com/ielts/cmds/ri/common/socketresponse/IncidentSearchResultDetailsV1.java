
package com.ielts.cmds.ri.common.socketresponse;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * incidents search result details
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaClientCodegen", date = "2022-07-08T06:21:51.566Z[GMT]")
public class IncidentSearchResultDetailsV1 {

  @SerializedName("bookingDetails")
  private BookingDetailsV1 bookingDetails = null;

  @SerializedName("incidentDetails")
  private ResultIntegrityIncidentDetailsV1 incidentDetails = null;

}
