
package com.ielts.cmds.ri.common.socketresponse;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;

/**
 * Event that goes in the topic
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaClientCodegen", date = "2021-12-29T11:51:29.594Z[GMT]")
public class SearchBookingRequestV1 {
  @SerializedName("criteria")
  private BookingSearchCriteriaV1 criteria = null;

  @SerializedName("pagination")
  private SearchPaginationV1 pagination = null;

  @SerializedName("sorting")
  private SearchSortV1 sorting = null;

  public SearchBookingRequestV1 criteria(BookingSearchCriteriaV1 criteria) {
    this.criteria = criteria;
    return this;
  }

   /**
   * Get criteria
   * @return criteria
  **/
  public BookingSearchCriteriaV1 getCriteria() {
    return criteria;
  }

  public void setCriteria(BookingSearchCriteriaV1 criteria) {
    this.criteria = criteria;
  }

  public SearchBookingRequestV1 pagination(SearchPaginationV1 pagination) {
    this.pagination = pagination;
    return this;
  }

   /**
   * Get pagination
   * @return pagination
  **/
  public SearchPaginationV1 getPagination() {
    return pagination;
  }

  public void setPagination(SearchPaginationV1 pagination) {
    this.pagination = pagination;
  }

  public SearchBookingRequestV1 sorting(SearchSortV1 sorting) {
    this.sorting = sorting;
    return this;
  }

   /**
   * Get sorting
   * @return sorting
  **/
  public SearchSortV1 getSorting() {
    return sorting;
  }

  public void setSorting(SearchSortV1 sorting) {
    this.sorting = sorting;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SearchBookingRequestV1 searchBookingRequestV1 = (SearchBookingRequestV1) o;
    return Objects.equals(this.criteria, searchBookingRequestV1.criteria) &&
        Objects.equals(this.pagination, searchBookingRequestV1.pagination) &&
        Objects.equals(this.sorting, searchBookingRequestV1.sorting);
  }

  @Override
  public int hashCode() {
    return Objects.hash(criteria, pagination, sorting);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SearchBookingRequestV1 {\n");
    
    sb.append("    criteria: ").append(toIndentedString(criteria)).append("\n");
    sb.append("    pagination: ").append(toIndentedString(pagination)).append("\n");
    sb.append("    sorting: ").append(toIndentedString(sorting)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}
