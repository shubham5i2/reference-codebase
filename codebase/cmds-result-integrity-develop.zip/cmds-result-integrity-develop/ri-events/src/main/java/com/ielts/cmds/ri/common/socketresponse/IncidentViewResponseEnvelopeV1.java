
package com.ielts.cmds.ri.common.socketresponse;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Event that goes in the topic
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaClientCodegen", date = "2022-07-08T06:21:51.566Z[GMT]")
public class IncidentViewResponseEnvelopeV1 {

  @SerializedName("meta")
  private SocketResponseMetaDataV1 meta = null;

  @SerializedName("response")
  private ViewIncidentDetailsListV1 response = null;

  @SerializedName("errors")
  private BaseEventErrors errors = null;

}
