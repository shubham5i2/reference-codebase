
package com.ielts.cmds.ri.common.socketresponse;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;

/**
 * SearchSortV1Item
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaClientCodegen", date = "2021-12-29T11:51:29.594Z[GMT]")
public class SearchSortV1Item {
  @SerializedName("sortBy")
  private String sortBy = null;

  @SerializedName("sortType")
  private String sortType = null;

  public SearchSortV1Item sortBy(String sortBy) {
    this.sortBy = sortBy;
    return this;
  }

   /**
   * Sort by which field/column in UI
   * @return sortBy
  **/
  public String getSortBy() {
    return sortBy;
  }

  public void setSortBy(String sortBy) {
    this.sortBy = sortBy;
  }

  public SearchSortV1Item sortType(String sortType) {
    this.sortType = sortType;
    return this;
  }

   /**
   * Sort by Ascending/Descending Order
   * @return sortType
  **/
  public String getSortType() {
    return sortType;
  }

  public void setSortType(String sortType) {
    this.sortType = sortType;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SearchSortV1Item searchSortV1Item = (SearchSortV1Item) o;
    return Objects.equals(this.sortBy, searchSortV1Item.sortBy) &&
        Objects.equals(this.sortType, searchSortV1Item.sortType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(sortBy, sortType);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SearchSortV1Item {\n");
    
    sb.append("    sortBy: ").append(toIndentedString(sortBy)).append("\n");
    sb.append("    sortType: ").append(toIndentedString(sortType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}
