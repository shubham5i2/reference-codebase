
package com.ielts.cmds.ri.common.socketresponse;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;

/**
 * BookingSearchResultV1
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaClientCodegen", date = "2021-12-29T11:51:29.594Z[GMT]")
public class BookingSearchResultV1 {
  @SerializedName("search")
  private SearchBookingRequestV1 search = null;

  @SerializedName("result")
  private BookingSearchResultV1Result result = null;

  public BookingSearchResultV1 search(SearchBookingRequestV1 search) {
    this.search = search;
    return this;
  }

   /**
   * Get search
   * @return search
  **/
  public SearchBookingRequestV1 getSearch() {
    return search;
  }

  public void setSearch(SearchBookingRequestV1 search) {
    this.search = search;
  }

  public BookingSearchResultV1 result(BookingSearchResultV1Result result) {
    this.result = result;
    return this;
  }

   /**
   * Get result
   * @return result
  **/
  public BookingSearchResultV1Result getResult() {
    return result;
  }

  public void setResult(BookingSearchResultV1Result result) {
    this.result = result;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BookingSearchResultV1 bookingSearchResultV1 = (BookingSearchResultV1) o;
    return Objects.equals(this.search, bookingSearchResultV1.search) &&
        Objects.equals(this.result, bookingSearchResultV1.result);
  }

  @Override
  public int hashCode() {
    return Objects.hash(search, result);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BookingSearchResultV1 {\n");
    
    sb.append("    search: ").append(toIndentedString(search)).append("\n");
    sb.append("    result: ").append(toIndentedString(result)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}
