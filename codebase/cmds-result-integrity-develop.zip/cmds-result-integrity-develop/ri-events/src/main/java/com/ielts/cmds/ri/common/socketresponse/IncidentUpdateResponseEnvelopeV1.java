package com.ielts.cmds.ri.common.socketresponse;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import lombok.*;

@Data
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class IncidentUpdateResponseEnvelopeV1 {


    @JsonProperty("meta")
    private SocketResponseMetaDataV1 meta;
    @JsonProperty("response")
    private Object response;
    @JsonProperty("errors")
    private BaseEventErrors errors;
}
