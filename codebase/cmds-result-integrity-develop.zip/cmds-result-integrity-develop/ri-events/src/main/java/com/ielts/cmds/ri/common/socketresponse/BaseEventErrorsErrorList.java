
package com.ielts.cmds.ri.common.socketresponse;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.IOException;
import java.util.Objects;

/**
 * BaseEventErrorsErrorList
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaClientCodegen", date = "2021-12-29T11:51:29.594Z[GMT]")
public class BaseEventErrorsErrorList {
  @SerializedName("interface")
  private String _interface = null;

  /**
   * Gets or Sets type
   */
  @JsonAdapter(TypeEnum.Adapter.class)
  public enum TypeEnum {
    WARNING("WARNING"),
    ERROR("ERROR"),
    VALIDATION("VALIDATION");

    private String value;

    TypeEnum(String value) {
      this.value = value;
    }
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
    public static TypeEnum fromValue(String input) {
      for (TypeEnum b : TypeEnum.values()) {
        if (b.value.equals(input)) {
          return b;
        }
      }
      return null;
    }
    public static class Adapter extends TypeAdapter<TypeEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final TypeEnum enumeration) throws IOException {
        jsonWriter.value(String.valueOf(enumeration.getValue()));
      }

      @Override
      public TypeEnum read(final JsonReader jsonReader) throws IOException {
        Object value = jsonReader.nextString();
        return TypeEnum.fromValue((String)(value));
      }
    }
  }
  @SerializedName("type")
  private TypeEnum type = null;

  @SerializedName("errorCode")
  private String errorCode = null;

  @SerializedName("title")
  private String title = null;

  @SerializedName("message")
  private String message = null;

  @SerializedName("errorTicketUuid")
  private String errorTicketUuid = null;

  @SerializedName("source")
  private BaseEventErrorsSource source = null;

  public BaseEventErrorsErrorList _interface(String _interface) {
    this._interface = _interface;
    return this;
  }

   /**
   * Get _interface
   * @return _interface
  **/
  public String getInterface() {
    return _interface;
  }

  public void setInterface(String _interface) {
    this._interface = _interface;
  }

  public BaseEventErrorsErrorList type(TypeEnum type) {
    this.type = type;
    return this;
  }

   /**
   * Get type
   * @return type
  **/
  public TypeEnum getType() {
    return type;
  }

  public void setType(TypeEnum type) {
    this.type = type;
  }

  public BaseEventErrorsErrorList errorCode(String errorCode) {
    this.errorCode = errorCode;
    return this;
  }

   /**
   * Get errorCode
   * @return errorCode
  **/
  public String getErrorCode() {
    return errorCode;
  }

  public void setErrorCode(String errorCode) {
    this.errorCode = errorCode;
  }

  public BaseEventErrorsErrorList title(String title) {
    this.title = title;
    return this;
  }

   /**
   * Get title
   * @return title
  **/
  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public BaseEventErrorsErrorList message(String message) {
    this.message = message;
    return this;
  }

   /**
   * Get message
   * @return message
  **/
  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public BaseEventErrorsErrorList errorTicketUuid(String errorTicketUuid) {
    this.errorTicketUuid = errorTicketUuid;
    return this;
  }

   /**
   * Get errorTicketUuid
   * @return errorTicketUuid
  **/
  public String getErrorTicketUuid() {
    return errorTicketUuid;
  }

  public void setErrorTicketUuid(String errorTicketUuid) {
    this.errorTicketUuid = errorTicketUuid;
  }

  public BaseEventErrorsErrorList source(BaseEventErrorsSource source) {
    this.source = source;
    return this;
  }

   /**
   * Get source
   * @return source
  **/
  public BaseEventErrorsSource getSource() {
    return source;
  }

  public void setSource(BaseEventErrorsSource source) {
    this.source = source;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BaseEventErrorsErrorList baseEventErrorsErrorList = (BaseEventErrorsErrorList) o;
    return Objects.equals(this._interface, baseEventErrorsErrorList._interface) &&
        Objects.equals(this.type, baseEventErrorsErrorList.type) &&
        Objects.equals(this.errorCode, baseEventErrorsErrorList.errorCode) &&
        Objects.equals(this.title, baseEventErrorsErrorList.title) &&
        Objects.equals(this.message, baseEventErrorsErrorList.message) &&
        Objects.equals(this.errorTicketUuid, baseEventErrorsErrorList.errorTicketUuid) &&
        Objects.equals(this.source, baseEventErrorsErrorList.source);
  }

  @Override
  public int hashCode() {
    return Objects.hash(_interface, type, errorCode, title, message, errorTicketUuid, source);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BaseEventErrorsErrorList {\n");
    
    sb.append("    _interface: ").append(toIndentedString(_interface)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    errorCode: ").append(toIndentedString(errorCode)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("    errorTicketUuid: ").append(toIndentedString(errorTicketUuid)).append("\n");
    sb.append("    source: ").append(toIndentedString(source)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}
