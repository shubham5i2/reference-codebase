### [3.28.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.28.0...v3.28.1) (2024-05-16)


### Bug Fixes

* <h2>Technical Features</h2><h3>IMOD-45258 Refactor code to generate CEFR level</h3><h3>IMOD-61780 update to latest outbox processor version</h3><p><ol><li>DevOps Ticket: IMOD-61955</li></ol> ([55982c4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/55982c451724fc53662e9dc2a8645796efbc02db))


### Features

* <h2>Technical Features</h2><h3>IMOD-45258 Refactor code to generate CEFR level</h3><h3>IMOD-61780 update to latest outbox processor version</h3><p><ol><li>DevOps Ticket: IMOD-61955</li></ol> ([024c787](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/024c7878be770e9574fa04b0ed5453989afc3fb9))

## [3.28.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.27.2...v3.28.0) (2024-05-16)

### [3.27.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.27.1...v3.27.2) (2024-05-10)


### ⚠ BREAKING CHANGES

* IMOD-61780 update to latest outbox processor version

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!587

* Merge branch 'feature/IMOD-61780-update_outbox_library' into 'develop' ([d84905a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/d84905a7eae9e97c574d8a76ab1fb28b0711b23e))

### [3.27.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.27.0...v3.27.1) (2024-05-07)

## [3.27.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.26.0...v3.27.0) (2024-05-06)

## [3.26.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.25.1...v3.26.0) (2024-04-30)

### [3.25.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.25.0...v3.25.1) (2024-04-15)

## [3.25.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.24.0...v3.25.0) (2024-04-10)

## [3.24.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.23.1...v3.24.0) (2024-04-09)

### [3.23.2-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.23.1...v3.23.2-hotfix.1) (2024-04-04)

### [3.22.1-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.22.1-hotfix.1...v3.22.1-hotfix.2) (2024-03-26)

### [3.22.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.22.0...v3.22.1-hotfix.1) (2024-03-15)

### [3.23.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.23.0...v3.23.1) (2024-03-25)


### ⚠ BREAKING CHANGES

* IMOD-59954 enable release version

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!575

* Merge branch 'feature/rm-event-release-version' into 'develop' ([4accc7b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/4accc7b3d14f5a17c69750ad32500a1c2461e779))

## [3.23.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.22.1...v3.23.0) (2024-03-12)

### [3.22.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.22.0...v3.22.1) (2024-03-04)

## [3.22.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.21.0...v3.22.0) (2024-01-10)

## [3.21.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.20.0...v3.21.0) (2024-01-09)

## [3.20.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.19.0...v3.20.0) (2024-01-08)

## [3.19.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.18.0...v3.19.0) (2023-12-22)

## [3.18.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.17.2...v3.18.0) (2023-12-19)

### [3.17.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.17.1...v3.17.2) (2023-12-13)

### [3.17.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.17.0...v3.17.1) (2023-12-08)


### ⚠ BREAKING CHANGES

* tt details script staging

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!560

* Merge branch 'feature/TT-Details-Script-Staging' into 'develop' ([bba502b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/bba502b39961cb7208b629d2d0d1352253a6e6fd))

## [3.17.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.16.0...v3.17.0) (2023-11-21)

## [3.16.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.15.0...v3.16.0) (2023-11-06)

## [3.15.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.14.3...v3.15.0) (2023-10-27)

### [3.14.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.14.2...v3.14.3) (2023-10-26)

### [3.14.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.14.1...v3.14.2) (2023-10-19)


### ⚠ BREAKING CHANGES

* event-adapter-spring

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!543

* Merge branch 'feature/event-adpater-spring-retrofit' into 'develop' ([32d9a54](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/32d9a54068436cee2b0d4f0cbed991cefa144aac))

### [3.14.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.14.0...v3.14.1) (2023-09-25)


### Features

* <h2>Business Features</h2><h3>IMOD-40315 RM: Use local test date in TRF number for all IELTS products</h3><p><strong>Purpose:</strong><br />  RM to use local test date in TRF number for all IELTS products So that the TRF number will have the right info<h3>IMOD-42950 UI: Display  local test date in RM & RD specific UI pages</h3><p><strong>Purpose:</strong><br />Display the local test date of the bookings in the RM & RD specific UI pages.<h3>IMOD-25864 RM: Apply assessed scores for exempted components</h3><p><strong>Purpose:</strong><br /> RM to apply the assessed scores for the exempted components So that it can be publish to the downstream systems<h3>IMOD-25865 RM: Generate Access Arrangement endorsement for the eTRF/TRF</h3><p><strong>Purpose:</strong><br />RM to add endorsement to bookings with certain approved access arrangements when the result is released.<h3>IMOD-37187 Include line breaks in administrator comments for OSR result.s</h3><p><strong>Purpose:</strong><br /> RM to add Administrator’s comments with line breaks to bookings when the result is released.<h3>IMOD-40264 RM: Handle multiple admin comments on one booking</h3><p><strong>Purpose:</strong><br />Adding multiple administrator comments for both AA and OSR booking. <h3>IMOD-40475 RM: Reject EOR requests for exempt components</h3><p><strong>Purpose:</strong><br />When RM receives an EOR request for an exempted components and RM should reject the EOR request for the booking.<h2>Technical Features</h2><h3>IMOD-49689 RM:Consume Arrangement Types data from EVT-019</h3><p><strong>Purpose:</strong><br />RM consume and persist the ArrangementTypes data for each booking in the new BookingAccessArrangement table.<ol><li>DevOps Ticket: IMOD-51275,IMOD-51279</li></ol> ([1f6bcfc](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/1f6bcfce29081639eb11c27c42410db01b5fd273))

## [3.14.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.13.2...v3.14.0) (2023-09-20)

### [3.13.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.13.1...v3.13.2) (2023-09-15)

### [3.13.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.13.0...v3.13.1) (2023-09-15)

## [3.13.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.12.6...v3.13.0) (2023-09-15)

### [3.12.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.12.5...v3.12.6) (2023-09-15)


### ⚠ BREAKING CHANGES

* Remove unused tables

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!516

* Merge branch 'feature/Remove_unused_tables' into 'develop' ([596f4b0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/596f4b04552a7d6e4b90da6ad23046605b30fa35))

### [3.12.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.12.4...v3.12.5) (2023-09-13)

### [3.12.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.12.3...v3.12.4) (2023-09-12)

### [3.12.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.12.2...v3.12.3) (2023-09-12)

### [3.12.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.12.1...v3.12.2) (2023-09-12)

### [3.12.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.12.0...v3.12.1) (2023-09-12)

## [3.12.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.11.2...v3.12.0) (2023-09-11)

### [3.11.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.11.1...v3.11.2) (2023-09-11)


### Features

* <h2>Business Features</h2><h3>IMOD-48306 RM: Manage cancelled bookings in RM</h3><p><strong>Purpose:</strong><br />  Change cancelled bookings results status to ‘Permanently Withheld’ with the label ‘Cancelled’<h3>IMOD-48273 RM: EOR OSR Results data structure changes</h3><p><strong>Purpose:</strong><br /> Consume OSR EOR results from Inspera which contain intermediate results rounds with no band score present.<h3>IMOD-47694 RM UI to only consider valid OSR bookings</h3><p><strong>Purpose:</strong><br />Cancelled and Voided OSR bookings to not be considered by the RM UI ,only accurate information about original and linked OSR bookings<h3>IMOD-44383 RM: Partner Ops / Global Ops Manager changes the status of the booking to 'Incomplete' from 'Unconfirmed' (manual)</h3><p><strong>Purpose:</strong><br />Change the status of the Incomplete booking status to ‘Incomplete’ from ‘Unconfirmed’ via results status update UI page in RM<h2>Technical Stories</h2><h3>IMOD-46703 Move Manage Results Search API from Booking Mx to RM Mx</h3><h3>PRD: Test taker's result stuck in 'Validated' status</h3><ol><li>DevOps Tickets: IMOD-50663,IMOD-50908,IMOD-50831,IMOD-50781</li></ol> ([2c56b93](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/2c56b93b65d86b8bc0eb94610c13b4a92a4bdb8c))

### [3.11.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.11.0...v3.11.1) (2023-09-08)

## [3.11.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.10.2...v3.11.0) (2023-09-07)

### [3.10.3-hotfix.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.10.3-hotfix.3...v3.10.3-hotfix.4) (2024-03-11)

### [3.10.3-hotfix.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.10.3-hotfix.2...v3.10.3-hotfix.3) (2023-11-22)


### Features

* <h2>Business Features</h2><h3>	IMOD-48306 	 ([82f0031](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/82f0031967cae07000fe2a14bab4a66e5ba3a098))

### [3.10.3-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.10.3-hotfix.1...v3.10.3-hotfix.2) (2023-11-21)

### [3.10.3-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.10.2...v3.10.3-hotfix.1) (2023-11-08)

### [3.10.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.10.1...v3.10.2) (2023-09-06)

### [3.10.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.10.0...v3.10.1) (2023-09-06)

## [3.10.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.9.2...v3.10.0) (2023-09-04)

### [3.9.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.9.1...v3.9.2) (2023-09-04)

### [3.9.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.9.0...v3.9.1) (2023-09-04)

## [3.9.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.8.0...v3.9.0) (2023-09-04)

## [3.8.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.7.0...v3.8.0) (2023-09-01)

## [3.7.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.6.0...v3.7.0) (2023-09-01)

## [3.6.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.5.0...v3.6.0) (2023-09-01)

### [3.5.1-hotfix.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.5.1-hotfix.2...v3.5.1-hotfix.3) (2023-10-02)

### [3.5.1-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.5.1-hotfix.1...v3.5.1-hotfix.2) (2023-09-29)

### [3.5.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.5.0...v3.5.1-hotfix.1) (2023-09-29)

## [3.5.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.4.0...v3.5.0) (2023-08-23)

## [3.4.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.3.0...v3.4.0) (2023-08-23)

## [3.3.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.2.1...v3.3.0) (2023-08-22)

### [3.2.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.2.0...v3.2.1) (2023-08-21)

## [3.2.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.1.0...v3.2.0) (2023-08-21)

## [3.1.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v3.0.0...v3.1.0) (2023-08-09)


### ⚠ BREAKING CHANGES

* feature/staging-changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!466

* Merge branch 'feature/staging-changes' into 'develop' ([21611a1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/21611a16134e31f55bbfd910b906636511920246))

## [3.0.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.48.2...v3.0.0) (2023-08-09)

### [2.48.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.48.1...v2.48.2) (2023-08-09)

### [2.48.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.48.0...v2.48.1) (2023-08-07)

## [2.48.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.47.0...v2.48.0) (2023-08-04)

## [2.47.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.46.0...v2.47.0) (2023-07-31)

## [2.46.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.45.0...v2.46.0) (2023-07-31)


### Features

* <h2>Business Features</h2> <h3>IMOD-45040 Process UKVI IOC OSR Results (AC & GT)</h3><p><strong>Purpose:</strong><br />Process results for UKVI OSR IOC bookings. <h3>IMOD-44380 RM: Consume Results type and Results status 'Incomplete' from LPR</h3><p><strong>Purpose:</strong><br />Consume new result type and resut status from LPR. <h3>IMOD-42608 RM: Add new results status label in RM to enable resolution of results marked Absent in error</h3><p><strong>Purpose:</strong><br />Add new result status label to resolve results marked to Absent by mistake. <h3>IMOD-42448 RM: Missing results status rule: 'Withheld - Pre-release Check Investigation' to 'Permanently Withheld - Pre-release Check Investigation'</h3><p><strong>Purpose:</strong><br />Add new status transition rule for status to change from 'Withheld - Pre-release Check Investigation' to 'Permanently Withheld - Pre-release Check. <h3>IMOD-30211 [ACT017] RM UI: Include information on linked bookings</h3><p><strong>Purpose:</strong><br />To display information regarding linked bookings on UI. <h2>Technical Stories</h2><h3>IMOD-46703 [TECH] RM - Copy scripts from LPR Mx to activate UKVI IOC OSR product</h3><h3>IMOD-45144 RM: Logs for SumoLogic Result Status Transition Rule Monitoring</h3><h3>IMOD-40652 Sparta: RM: Upgrade for Object Serialized Event Consumption in rm-mx</h3><h3>IMOD-40654 Sparta: RM: Upgrade for Object Serialized Event Consumption in rm-dist-ui</h3><h3>IMOD-43448 RM: Modify results release scheduler to consider only recent bookings</h3><h2>Bug Fixes</h2> <h3>IMOD-43337 Global Operations Manager users unable to update results status from Validated to Withheld.</h3> <h3>IMOD-31107 CMDS-IDP-SIT : EOR request is successful when invalid value passed in one of the "externalEorLineUuid" field of EorLines and also result status is changed to UNCONFIRMED, EOR Pending in RM UI from 'Released'.</h3> <ol><li>DevOps Ticket: IMOD-47936</li><li>Infra Ticket: IMOD-49156</li></ol> ([b0c41d3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/b0c41d3443bb560fd4861f29c4409d99d08b4042))

## [2.45.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.44.0...v2.45.0) (2023-07-28)

### [2.44.1-hotfix.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.44.1-hotfix.2...v2.44.1-hotfix.3) (2023-08-16)


### Bug Fixes

* <h2>Bug Fixes</h2><h3>IMOD-49476 CMDS -IDP- SIT | Booking Result status are getting duplicated and got released multiple times after completing the EOR round in CMDS RM screen</h3><h3>IMOD-49480 CMDS -IDP- SIT | INT-261 is not triggered to ORS if we do an EOR score change</h3><h3>IMOD-49758 CMDS-IDP/BC-SIT: INT-261 is not triggered to ORS for normal round of results.</h3><h3>IMOD-42429 CMDS-IDP-SIT - Result auto-transition happened twice for Confirmed and permanently withheld statuses</h3><ol><li>DevOps Ticket: IMOD-49881</li></ol> ([6cb782d](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/6cb782d2ffd5330d111e432e177bb08e088439b4))

### [2.44.1-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.44.1-hotfix.1...v2.44.1-hotfix.2) (2023-08-16)

### [2.44.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.44.0...v2.44.1-hotfix.1) (2023-08-09)

## [2.44.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.43.0...v2.44.0) (2023-07-24)


### Features

* <h2>Business Features</h2><h3>IMOD-45040 Process UKVI IOC OSR Results (AC & GT)</h3><p><strong>Purpose:</strong><br />Process results for UKVI OSR IOC bookings.<h3>IMOD-44380 RM: Consume Results type and Results status 'Incomplete' from LPR</h3><p><strong>Purpose:</strong><br />Consume new result type and resut status from LPR.<h3>IMOD-42608 RM: Add new results status label in RM to enable resolution of results marked Absent in error</h3><p><strong>Purpose:</strong><br />Add new result status label to resolve results marked to Absent by mistake.<h3>IMOD-42448 RM: Missing results status rule: 'Withheld - Pre-release Check Investigation' to 'Permanently Withheld - Pre-release Check Investigation'</h3><p><strong>Purpose:</strong><br />Add new status transition rule for status to change from 'Withheld - Pre-release Check Investigation' to 'Permanently Withheld - Pre-release Check.<h3>IMOD-30211 [ACT017] RM UI: Include information on linked bookings</h3><p><strong>Purpose:</strong><br />To display information regarding linked bookings on UI.<h2>Technical Stories</h2><h3>IMOD-46799 [TECH] New swaggers for Manage Results search</h3><h3>IMOD-46791 [TECH] Create new endpoint in API gateway for Manage Results search</h3><h3>IMOD-46703 [TECH] RM - Copy scripts from LPR Mx to activate UKVI IOC OSR product</h3><h3>IMOD-45551 Sparta - RM - Swagger 2.0 Specification Update for UI Events</h3><h3>IMOD-45144 RM: Logs for SumoLogic Result Status Transition Rule Monitoring</h3><h2>Bug Fixes</h2><h3>IMOD-43337 Global Operations Manager users unable to update results status from Validated to Withheld.</h3><h3>IMOD-31107 CMDS-IDP-SIT : EOR request is successful when invalid value passed in one of the "externalEorLineUuid" field of EorLines and also result status is changed to UNCONFIRMED, EOR Pending in RM UI from 'Released'.</h3><ol><li>DevOps Ticket: IMOD-48866</li></ol> ([0d490ce](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/0d490cefa86a96ecc7cb7d1cee7cf1a114a431c9))

## [2.43.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.42.3...v2.43.0) (2023-07-24)

### [2.40.4-hotfix.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.40.4-hotfix.4...v2.40.4-hotfix.5) (2023-07-21)

### [2.40.4-hotfix.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.40.4-hotfix.3...v2.40.4-hotfix.4) (2023-06-09)


### Features

* <h2>Business Features</h2><h3>IMOD-42491 RM to add admin comments when Booking is released</h3><p><strong>Purpose:</strong><br />Admin comments are generated after all booking updates are received(when results are released). This will be an enabler for TT detail changes Post cut-off feature.</p><h3>IMOD-42046 RM to generate TRF and CEFR numbers when booking is Released</h3><p><strong>Purpose:</strong><br />TRF Number and CEFR levels are generated after all booking updates are received (when results are released). This will be an enabler for TT detail changes Post cut-off feature.</p><h3>IMOD-40330 [ACT049] RM should only update the results status to Validated when all RI checks are passed</h3><p><strong>Purpose:</strong><br />After the overall outcome is passed, the result status is moved to Validated. Now, Validated state means that all integrity checks have been passed.</p><h3>IMOD-40280 [ACT049] RM re-sets status to Unconfirmed from Permanently Withheld when an incident is dismissed</h3><p><strong>Purpose:</strong><br />When all incidents are dismissed in an incident type, the status is reset to Unconfirmed automatically.</p><h3>IMOD-40183 RM: Consume OSR IOL product data from LPR Mx</h3><p><strong>Purpose:</strong><br />Support OSR IOL product</p><h3>IMOD-38147 [ACT049] RM to accept updates to existing malpractice incidents</h3><p><strong>Purpose:</strong><br />RM will accept updates to incidents after an incident has been created. This also removes the manual workaround we currently do to tackle with the incident updates.</p><h3>IMOD-35670 [ACT049] RM consumes Probable Banned Data from the RI event and withholds booking</h3><p><strong>Purpose:</strong><br />RM will accept probable banned data and automatically transitions the results status.</p><h2>Bug Fixes</h2><ol><li>IMOD-36983 CMDS-IDP-SIT: Updated Date Time field is not getting updated in Product Config table - RM MX</li><li>IMOD-42429 CMDS-IDP-SIT - Result auto-transition happened twice for Confirmed and permanently withheld statuses</li><li>IMOD-42869 CUPA UAT - CMDS - &lsquo;Validated&rsquo; and &lsquo;Released&rsquo; Result status changes are getting Duplicated in RM Status history tab</li><li>IMOD-42927 CMDS-IDP-UAT - Result status publishing twice for Unconfirmed status for OSR Candidates</li></ol> ([393104a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/393104a981cb99bd5151fd2c26dbd6a6ef961ac2))
* v56.2 ([fe7110b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/fe7110bdf36631558aa743a869f16241cccbcc82))

### [2.40.4-hotfix.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.40.4-hotfix.2...v2.40.4-hotfix.3) (2023-06-09)


### Features

* <h2>Business Features</h2><h3>IMOD-42491 RM to add admin comments when Booking is released</h3><p><strong>Purpose:</strong><br />Admin comments are generated after all booking updates are received(when results are released). This will be an enabler for TT detail changes Post cut-off feature.</p><h3>IMOD-42046 RM to generate TRF and CEFR numbers when booking is Released</h3><p><strong>Purpose:</strong><br />TRF Number and CEFR levels are generated after all booking updates are received (when results are released). This will be an enabler for TT detail changes Post cut-off feature.</p><h3>IMOD-40330 [ACT049] RM should only update the results status to Validated when all RI checks are passed</h3><p><strong>Purpose:</strong><br />After the overall outcome is passed, the result status is moved to Validated. Now, Validated state means that all integrity checks have been passed.</p><h3>IMOD-40280 [ACT049] RM re-sets status to Unconfirmed from Permanently Withheld when an incident is dismissed</h3><p><strong>Purpose:</strong><br />When all incidents are dismissed in an incident type, the status is reset to Unconfirmed automatically.</p><h3>IMOD-40183 RM: Consume OSR IOL product data from LPR Mx</h3><p><strong>Purpose:</strong><br />Support OSR IOL product</p><h3>IMOD-38147 [ACT049] RM to accept updates to existing malpractice incidents</h3><p><strong>Purpose:</strong><br />RM will accept updates to incidents after an incident has been created. This also removes the manual workaround we currently do to tackle with the incident updates.</p><h3>IMOD-35670 [ACT049] RM consumes Probable Banned Data from the RI event and withholds booking</h3><p><strong>Purpose:</strong><br />RM will accept probable banned data and automatically transitions the results status.</p><h2>Bug Fixes</h2><ol><li>IMOD-36983 CMDS-IDP-SIT: Updated Date Time field is not getting updated in Product Config table - RM MX</li><li>IMOD-42429 CMDS-IDP-SIT - Result auto-transition happened twice for Confirmed and permanently withheld statuses</li><li>IMOD-42869 CUPA UAT - CMDS - &lsquo;Validated&rsquo; and &lsquo;Released&rsquo; Result status changes are getting Duplicated in RM Status history tab</li><li>IMOD-42927 CMDS-IDP-UAT - Result status publishing twice for Unconfirmed status for OSR Candidates</li></ol> ([a8b202d](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/a8b202dd6d9024c45b18d799b9b3ca0a040160f9))
* <h2>Business Features</h2><h3>IMOD-42491 RM to add admin comments when Booking is released</h3><p><strong>Purpose:</strong><br />Admin comments are generated after all booking updates are received(when results are released). This will be an enabler for TT detail changes Post cut-off feature.</p><h3>IMOD-42046 RM to generate TRF and CEFR numbers when booking is Released</h3><p><strong>Purpose:</strong><br />TRF Number and CEFR levels are generated after all booking updates are received (when results are released). This will be an enabler for TT detail changes Post cut-off feature.</p><h3>IMOD-40330 [ACT049] RM should only update the results status to Validated when all RI checks are passed</h3><p><strong>Purpose:</strong><br />After the overall outcome is passed, the result status is moved to Validated. Now, Validated state means that all integrity checks have been passed.</p><h3>IMOD-40280 [ACT049] RM re-sets status to Unconfirmed from Permanently Withheld when an incident is dismissed</h3><p><strong>Purpose:</strong><br />When all incidents are dismissed in an incident type, the status is reset to Unconfirmed automatically.</p><h3>IMOD-40183 RM: Consume OSR IOL product data from LPR Mx</h3><p><strong>Purpose:</strong><br />Support OSR IOL product</p><h3>IMOD-38147 [ACT049] RM to accept updates to existing malpractice incidents</h3><p><strong>Purpose:</strong><br />RM will accept updates to incidents after an incident has been created. This also removes the manual workaround we currently do to tackle with the incident updates.</p><h3>IMOD-35670 [ACT049] RM consumes Probable Banned Data from the RI event and withholds booking</h3><p><strong>Purpose:</strong><br />RM will accept probable banned data and automatically transitions the results status.</p><h2>Bug Fixes</h2><ol><li>IMOD-36983 CMDS-IDP-SIT: Updated Date Time field is not getting updated in Product Config table - RM MX</li><li>IMOD-42429 CMDS-IDP-SIT - Result auto-transition happened twice for Confirmed and permanently withheld statuses</li><li>IMOD-42869 CUPA UAT - CMDS - &lsquo;Validated&rsquo; and &lsquo;Released&rsquo; Result status changes are getting Duplicated in RM Status history tab</li><li>IMOD-42927 CMDS-IDP-UAT - Result status publishing twice for Unconfirmed status for OSR Candidates</li></ol> ([dfd5b98](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/dfd5b98153f17c930c0660ef51e0e141a86b2682))

### [2.40.4-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.40.4-hotfix.1...v2.40.4-hotfix.2) (2023-06-09)


### Features

* <h2>Business Features</h2><h3>IMOD-42491 RM to add admin comments when Booking is released</h3><p><strong>Purpose:</strong><br /> ([db48adc](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/db48adc42154eddded2bec8cb378ae473886c9ca))
* <h2>Business Features</h2><h3>IMOD-42491 RM to add admin comments when Booking is released</h3><p><strong>Purpose:</strong><br /> ([ad3eb27](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/ad3eb271fe34ba7bdd8de3f8ceebcd07fb1dd9c3))

### [2.40.4-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.40.3...v2.40.4-hotfix.1) (2023-06-09)

### [2.42.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.42.2...v2.42.3) (2023-07-05)

### [2.42.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.42.1...v2.42.2) (2023-06-28)

### [2.42.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.42.0...v2.42.1) (2023-06-05)

## [2.42.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.41.8...v2.42.0) (2023-06-01)


### ⚠ BREAKING CHANGES

* feature/44383-dummy-changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!425

* Merge branch 'feature/IMOD-44383-dummy-changes' into 'develop' ([4b28453](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/4b28453a4cc3d06563208e4740573c9db1de29cf))

### [2.41.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.41.7...v2.41.8) (2023-05-24)

### [2.41.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.41.6...v2.41.7) (2023-05-24)

### [2.41.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.41.5...v2.41.6) (2023-05-24)

### [2.41.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.41.4...v2.41.5) (2023-05-22)


### ⚠ BREAKING CHANGES

* upgrade outbox version

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!418

* Merge branch 'feature/Outbox-Version-Update' into 'develop' ([8b87f21](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/8b87f21eed3e577ec1a5d09bfb589baa2b95d71d))

### [2.41.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.41.3...v2.41.4) (2023-05-17)

### [2.41.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.41.2...v2.41.3) (2023-05-17)

### [2.41.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.41.1...v2.41.2) (2023-05-16)


### ⚠ BREAKING CHANGES

* semver-test

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!414

* Merge branch 'feature/semver-test' into 'develop' ([06064f8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/06064f8a0d4b5a1b59615af780faae50630a0cab))

### [2.41.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.41.0...v2.41.1) (2023-05-16)

## [2.41.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.40.4...v2.41.0) (2023-05-15)

### [2.40.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.40.3...v2.40.4) (2023-05-11)

### [2.40.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.40.2...v2.40.3) (2023-05-05)

### [2.40.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.40.1...v2.40.2) (2023-04-25)

### [2.40.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.40.0...v2.40.1) (2023-04-25)

### [2.35.8-hotfix.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.8-hotfix.9...v2.35.8-hotfix.10) (2023-04-06)

### [2.35.8-hotfix.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.8-hotfix.8...v2.35.8-hotfix.9) (2023-03-23)

### [2.35.8-hotfix.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.8-hotfix.7...v2.35.8-hotfix.8) (2023-03-09)

### [2.35.8-hotfix.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.8-hotfix.6...v2.35.8-hotfix.7) (2023-03-09)

### [2.35.8-hotfix.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.8-hotfix.5...v2.35.8-hotfix.6) (2023-03-02)

### [2.35.8-hotfix.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.8-hotfix.4...v2.35.8-hotfix.5) (2023-02-22)

### [2.35.8-hotfix.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.8-hotfix.3...v2.35.8-hotfix.4) (2023-02-16)

### [2.35.8-hotfix.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.8-hotfix.2...v2.35.8-hotfix.3) (2023-02-02)

### [2.35.8-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.8-hotfix.1...v2.35.8-hotfix.2) (2023-02-01)

### [2.35.8-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.7...v2.35.8-hotfix.1) (2023-01-27)

## [2.40.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.39.0...v2.40.0) (2023-04-11)

## [2.39.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.38.0...v2.39.0) (2023-04-10)


### ⚠ BREAKING CHANGES

* feature/IMOD-44856-Bug-fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!398

* Merge branch 'feature/IMOD-44856-Bug-fix' into 'develop' ([a9f5f0c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/a9f5f0c2d70553c28be3fc201c54020376939791))

## [2.38.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.37.0...v2.38.0) (2023-04-10)


### ⚠ BREAKING CHANGES

* feature/release-version-generate

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!397

* Merge branch 'feature/release-version-generate' into 'develop' ([e1b543c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/e1b543c0533a870d3f5da8a8deb84ae31029def4))

### [2.37.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.37.0...v2.37.1-hotfix.1) (2023-04-05)

## [2.37.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.36.10...v2.37.0) (2023-03-30)

### [2.36.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.36.9...v2.36.10) (2023-03-28)

### [2.36.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.36.8...v2.36.9) (2023-03-22)

### [2.36.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.36.7...v2.36.8) (2023-03-15)


### ⚠ BREAKING CHANGES

* optimise rule engine

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!374

* Merge branch 'feature/Rule-Engine-Optimisation-Execution-Context' into 'develop' ([781fa50](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/781fa5022d1768a78d9c9144650beb42c114fedb))

### [2.36.8-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.36.7...v2.36.8-hotfix.1) (2023-03-14)

### [2.35.8-hotfix.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.8-hotfix.7...v2.35.8-hotfix.8) (2023-03-09)

### [2.35.8-hotfix.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.8-hotfix.6...v2.35.8-hotfix.7) (2023-03-09)

### [2.35.8-hotfix.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.8-hotfix.5...v2.35.8-hotfix.6) (2023-03-02)

### [2.35.8-hotfix.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.8-hotfix.4...v2.35.8-hotfix.5) (2023-02-22)

### [2.35.8-hotfix.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.8-hotfix.3...v2.35.8-hotfix.4) (2023-02-16)

### [2.35.8-hotfix.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.8-hotfix.2...v2.35.8-hotfix.3) (2023-02-02)

### [2.35.8-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.8-hotfix.1...v2.35.8-hotfix.2) (2023-02-01)

### [2.35.8-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.7...v2.35.8-hotfix.1) (2023-01-27)

### [2.36.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.36.6...v2.36.7) (2023-03-09)

### [2.36.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.36.5...v2.36.6) (2023-03-01)


### ⚠ BREAKING CHANGES

* Retrofit Prod hotfix to DEV

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!372

* Merge branch 'hotfix' into 'develop' ([b838122](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/b8381223ec5fbc019253ecad7eaa52dc579576e4))

### [2.34.1-hotfix.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.34.1-hotfix.2...v2.34.1-hotfix.3) (2023-02-28)

### [2.34.1-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.34.1-hotfix.1...v2.34.1-hotfix.2) (2023-02-17)

### [2.34.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.34.0...v2.34.1-hotfix.1) (2023-02-17)

### [2.36.5-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.36.4...v2.36.5-hotfix.1) (2023-02-27)

### [2.35.8-hotfix.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.8-hotfix.4...v2.35.8-hotfix.5) (2023-02-22)

### [2.35.8-hotfix.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.8-hotfix.3...v2.35.8-hotfix.4) (2023-02-16)

### [2.35.8-hotfix.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.8-hotfix.2...v2.35.8-hotfix.3) (2023-02-02)

### [2.35.8-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.8-hotfix.1...v2.35.8-hotfix.2) (2023-02-01)

### [2.35.8-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.7...v2.35.8-hotfix.1) (2023-01-27)

### [2.36.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.36.4...v2.36.5) (2023-02-27)

### [2.36.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.36.3...v2.36.4) (2023-02-20)


### ⚠ BREAKING CHANGES

* RBAC caching

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!360

* Merge branch 'feature/RBAC-Version-Update-Caching' into 'develop' ([6ea47ca](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/6ea47ca10796b544df9fe282c5511aa22b887ba6))

### [2.36.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.36.2...v2.36.3) (2023-02-20)

### [2.36.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.36.1...v2.36.2) (2023-02-16)

### [2.36.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.36.0...v2.36.1) (2023-02-15)

## [2.36.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.14...v2.36.0) (2023-02-07)

### [2.35.14](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.13...v2.35.14) (2023-02-07)

### [2.35.13](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.12...v2.35.13) (2023-01-30)


### ⚠ BREAKING CHANGES

* dummy-changes-for-release-version

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!347

* Merge branch 'feature/IMOD-41231-dummy-change-to-release-version-tag' into 'develop' ([42e428a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/42e428a16cf5fa25c6532ad63787a8eaac6a73e7))

### [2.35.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.11...v2.35.12) (2023-01-24)

### [2.35.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.10...v2.35.11) (2023-01-16)

### [2.35.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.9...v2.35.10) (2023-01-16)

### [2.35.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.8...v2.35.9) (2023-01-12)

### [2.35.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.7...v2.35.8) (2023-01-11)

### [2.35.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.6...v2.35.7) (2023-01-06)


### ⚠ BREAKING CHANGES

* Update rm-application.properties

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!331

* Merge branch 'feature/Feature_Flag_Disable' into 'develop' ([ba1a875](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/ba1a875fda65716109177267a9e6c06f68630291))

### [2.35.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.5...v2.35.6) (2023-01-06)

### [2.35.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.4...v2.35.5) (2023-01-05)

### [2.35.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.3...v2.35.4) (2023-01-04)

### [2.35.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.2...v2.35.3) (2023-01-03)

### [2.35.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.1...v2.35.2) (2023-01-03)

### [2.35.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.35.0...v2.35.1) (2023-01-03)

## [2.35.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.34.1...v2.35.0) (2023-01-03)

### [2.34.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.34.0...v2.34.1) (2022-12-29)

## [2.34.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.33.0...v2.34.0) (2022-12-07)


### ⚠ BREAKING CHANGES

* Feature/Absence-Management

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!296

* Merge branch 'feature/Absence-management' into 'develop' ([6a92972](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/6a92972315d503d3dc04ebef4fb1cb38e672412e))

## [2.33.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.32.13...v2.33.0) (2022-11-17)

### [2.32.8-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.32.7...v2.32.8-hotfix.1) (2022-11-16)
### [2.32.13](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.32.12...v2.32.13) (2022-11-10)


### ⚠ BREAKING CHANGES

* Feature/ignore no action taken outbox

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!301

* Merge branch 'feature/Ignore-NoActionTaken-Outbox' into 'develop' ([64233f1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/64233f109c381dabd362170c450b6a8c4b23fb4f))

### [2.32.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.32.11...v2.32.12) (2022-11-09)

### [2.32.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.32.10...v2.32.11) (2022-11-09)

### [2.32.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.32.9...v2.32.10) (2022-11-08)

### [2.32.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.32.8...v2.32.9) (2022-10-28)

### [2.32.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.32.7...v2.32.8) (2022-10-28)

### [2.32.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.32.6...v2.32.7) (2022-10-21)


### ⚠ BREAKING CHANGES

* removing all eor validations when receiving scores

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!294

* Merge branch 'feature/IMOD-36709-Relaxing-Eor-Score-Validation' into 'develop' ([b2ccef8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/b2ccef8594b58804ee375bbc8292cc605054dc46))

### [2.32.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.32.5...v2.32.6) (2022-10-12)


### ⚠ BREAKING CHANGES

* osr admin comments

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!293

* Merge branch 'feature/IMOD-36779-OSR-Admin-Comments' into 'develop' ([069499d](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/069499d9c0c542808b49b395b446f7dbf0c03828))

### [2.32.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.32.4...v2.32.5) (2022-10-12)

### [2.32.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.32.3...v2.32.4) (2022-10-12)


### ⚠ BREAKING CHANGES

* feature/IMOD-36832-Update-LPR-Scripts-In-RM

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!291

* Merge branch 'feature/IMOD-36832-Update-LPR-Scripts-In-RM' into 'develop' ([e111d5b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/e111d5b2591378b5a65e962c154c8fe3bc60d2d4))

### [2.32.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.32.2...v2.32.3) (2022-10-11)

### [2.32.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.32.1...v2.32.2) (2022-10-10)

### [2.32.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.32.0...v2.32.1) (2022-09-23)

## [2.32.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.31.6...v2.32.0) (2022-09-20)


### ⚠ BREAKING CHANGES

* Feature/ssr results sub feature

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!283

* Merge branch 'feature/SSR-Results-SubFeature' into 'develop' ([cdc96ab](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/cdc96ab95519912148e94bc08dbbdfff36a19cb0))

### [2.31.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.31.5...v2.31.6) (2022-09-16)

### [2.31.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.31.4...v2.31.5) (2022-09-09)

### [2.31.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.31.3...v2.31.4) (2022-09-09)


### ⚠ BREAKING CHANGES

* Feature/manual status update

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!279

* Merge branch 'feature/Manual_Status_Update' into 'develop' ([3caad40](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/3caad40463d00a70cb6db0466d4dda19b204f296))

### [2.31.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.31.2...v2.31.3) (2022-09-09)


### ⚠ BREAKING CHANGES

* Reference data update

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!277

* Merge branch 'feature/IMOD-35428_Update_Reference_Data' into 'develop' ([eae16d0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/eae16d0d541bf8982f1275973d40487eb760acda))

### [2.31.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.31.1...v2.31.2) (2022-09-08)

### [2.31.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.31.0...v2.31.1) (2022-09-06)

## [2.31.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.30.9...v2.31.0) (2022-09-02)

### [2.30.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.30.8...v2.30.9) (2022-08-31)

### [2.30.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.30.7...v2.30.8) (2022-08-31)

### [2.30.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.30.6...v2.30.7) (2022-08-31)


### ⚠ BREAKING CHANGES

* Feature/imod 35174 rm incident comment fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!270

* Merge branch 'feature/IMOD-35174-RM-Incident-Comment-Fix' into 'develop' ([65067f0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/65067f041382918c17d606b01cbbe71245dd0474))

### [2.30.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.30.5...v2.30.6) (2022-08-30)

### [2.30.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.30.4...v2.30.5) (2022-08-30)

### [2.30.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.30.3...v2.30.4) (2022-08-23)


### ⚠ BREAKING CHANGES

* Feature/imod 33000 rm incidentstatus

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!258

* Merge branch 'feature/IMOD-33000_RM_incidentstatus' into 'develop' ([6d94cd2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/6d94cd21f757e20ed32109bd4ed4603a20f8ebae))

### [2.30.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.30.2...v2.30.3) (2022-08-19)


### ⚠ BREAKING CHANGES

* IMOD-28115 country, territory refresh

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!265

* Merge branch 'feature/IMOD-28115' into 'develop' ([92dee3e](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/92dee3e59e097ed9f942b6db8a969acf7e698a7a))

### [2.30.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.30.1...v2.30.2) (2022-08-16)

### [2.30.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.30.0...v2.30.1) (2022-08-16)

## [2.30.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.29.1...v2.30.0) (2022-08-16)

### [2.29.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.29.0...v2.29.1) (2022-08-15)


### ⚠ BREAKING CHANGES

* Change parameter key

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!261

* Merge branch 'feature/change-parameter-per-design' into 'develop' ([f64ce51](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/f64ce518a76cb0149b65dd637a9d22a3e11df1b4))

## [2.29.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.28.1...v2.29.0) (2022-08-15)

### [2.28.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.28.0...v2.28.1) (2022-08-12)

## [2.28.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.27.0...v2.28.0) (2022-08-10)


### ⚠ BREAKING CHANGES

* Auto Release

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!253

* Merge branch 'feature/IMOD-32924-consume-photo-category' into 'develop' ([875bfd2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/875bfd2aa7f8722f8591c6156c836e896a17d0f6))

## [2.27.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.26.0...v2.27.0) (2022-08-03)


### ⚠ BREAKING CHANGES

* Outbox Feature Flag

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!251

* Merge branch 'feature/IMOD-33463-RM-Outbox-Feature-Flag' into 'develop' ([b17e6e0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/b17e6e0adf2aa577b306f1408ccee3f5b5c38898))

## [2.26.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.25.6...v2.26.0) (2022-07-26)


### ⚠ BREAKING CHANGES

* IMOD-31306 process OnHold for multiple booking

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!232

* Merge branch 'feature/IMOD-31306_OnHold_MultiBookings' into 'develop' ([24e677a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/24e677adc01e36ce763dac6d62e57519399eaf1b))

### [2.25.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.25.5...v2.25.6) (2022-07-18)


### ⚠ BREAKING CHANGES

* IMOD-33026 default legacy bookings to have onhold false and result_history

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!247

* Merge branch 'feature/IMOD-33026_default_data_to_onHold_false' into 'develop' ([37f02be](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/37f02be2c6aa86e1a5787c650c23f5bb8e8f7521))

### [2.25.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.25.4...v2.25.5) (2022-07-18)


### ⚠ BREAKING CHANGES

* Feature/imod 33026 fix on hold update date time

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!244

* Merge branch 'feature/IMOD-33026_Fix_onHoldUpdateDateTime' into 'develop' ([8506683](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/85066830a46d30fbf0f17495aedb713d271d946d))

### [2.25.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.25.3...v2.25.4) (2022-07-14)


### ⚠ BREAKING CHANGES

* Feature/update result label

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!239

* Merge branch 'feature/UpdateResultLabel' into 'develop' ([1d44c9c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/1d44c9c00a17c7498b743c7e1b09412bcfb63a32))

### [2.25.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.25.2...v2.25.3) (2022-07-13)


### ⚠ BREAKING CHANGES

* Feature/imod 31955 on hold flag

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!234

* Merge branch 'feature/IMOD-31955-OnHoldFlag' into 'develop' ([2233ccb](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/2233ccb52cf61fc454c0b82fc324984bce4294b9))

### [2.25.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.25.1...v2.25.2) (2022-07-12)


### ⚠ BREAKING CHANGES

* Location fix for DEV

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!241

* Merge branch 'feature/Location-Fix' into 'develop' ([7c40ca7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/7c40ca7195e5407e3d95fc9c0e6942b277a0c888))

### [2.25.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.25.0...v2.25.1) (2022-07-11)

## [2.25.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.24.6...v2.25.0) (2022-07-06)

### [2.24.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.24.5...v2.24.6) (2022-07-04)

### [2.24.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.24.4...v2.24.5) (2022-07-02)

### [2.24.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.24.3...v2.24.4) (2022-06-28)


### ⚠ BREAKING CHANGES

* Eventual Consistency ResultLocationChanged

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!229

* Merge branch 'feature/IMOD-30558-ResultChanged' into 'develop' ([6d78763](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/6d7876377aad6abb27ca5e1a95cf806d76f36227))

### [2.24.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.24.2...v2.24.3) (2022-06-24)

### [2.24.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.24.1...v2.24.2) (2022-06-23)

### [2.24.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.24.0...v2.24.1) (2022-06-23)

## [2.24.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.23.6...v2.24.0) (2022-06-23)

### [2.23.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.23.5...v2.23.6) (2022-06-17)


### ⚠ BREAKING CHANGES

* Feature/IMOD-30994-EOR-Bug-Fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!223

* Merge branch 'feature/IMOD-30994-EOR-Bug-Fix' into 'develop' ([70c8779](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/70c87796f1ce1f42f813fa5c813f65b0ca60ae82))

### [2.23.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.23.4...v2.23.5) (2022-06-01)

### [2.23.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.23.3...v2.23.4) (2022-05-26)


### ⚠ BREAKING CHANGES

* Feature/fix code smells add missing db scripts

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!219

* Merge branch 'feature/FixCodeSmells-Add-Missing-DB-Scripts' into 'develop' ([bd1293e](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/bd1293ea9226d0d4d3bd298a5550abaa91de4472))

### [2.23.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.23.2...v2.23.3) (2022-05-26)


### ⚠ BREAKING CHANGES

* IMOD-30533 StatusUpdate to generate V2 BookingResultsGenerated to UI

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!217

* Merge branch 'feature/IMOD-30533-StatusUpdateTogenerateV2response' into 'develop' ([dacc0b4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/dacc0b42a3718d30c1514394d19f4c243ec1213a))

### [2.23.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.23.1...v2.23.2) (2022-05-26)


### ⚠ BREAKING CHANGES

* Feature/incident comments

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!216

* Merge branch 'feature/Incident-Comments' into 'develop' ([55c200b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/55c200b2c8c0e07a031712fc9d66ba8f7d28702c))

### [2.23.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.23.0...v2.23.1) (2022-05-24)


### ⚠ BREAKING CHANGES

* Feature/imod 29095 bug fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!215

* Merge branch 'feature/IMOD-29095-Bug-Fix' into 'develop' ([7c3dc0c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/7c3dc0caa5cdae21ae18b8dac22e0ae914d44ca5))

## [2.23.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.22.0...v2.23.0) (2022-05-18)


### ⚠ BREAKING CHANGES

* Feature/technical improvements

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!213

* Merge branch 'feature/Technical-Improvements' into 'develop' ([d5d12e6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/d5d12e60fd648a14f3df315265c108f118713ee8))

## [2.22.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.21.0...v2.22.0) (2022-05-18)


### ⚠ BREAKING CHANGES

* Feature/imod 28929 ri incident malpractice status transition

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!199

* Merge branch 'feature/IMOD-28929_RI_incident_status_transition' into 'develop' ([dceab6d](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/dceab6d7b7f5291ef2413d3c326e4e705b0e1926))

## [2.21.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.20.13...v2.21.0) (2022-05-18)


### ⚠ BREAKING CHANGES

* Feature/IMOD-28493 add v2 response mapper for bookinResultGenerated event

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!190

* Merge branch 'feature/IMOD-28493_lambda_dist_' into 'develop' ([e522a2f](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/e522a2f4d02677b1c29d8d359adcefeaa6241fec))

### [2.20.13](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.20.12...v2.20.13) (2022-05-16)


### ⚠ BREAKING CHANGES

* Feature/IMOD-30119

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!214

* Merge branch 'feature/IMOD-30119' into 'develop' ([2982a92](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/2982a92c8c2860bd1feb15a07d9c63d00db2116d))

### [2.20.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.20.11...v2.20.12) (2022-05-12)


### ⚠ BREAKING CHANGES

* Feature/imod 29050

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!201

* Merge branch 'feature/IMOD-29050' into 'develop' ([e7ecd02](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/e7ecd020a8bfc8e7ad9b3b7af3b93465503aa899))

### [2.20.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.20.10...v2.20.11) (2022-05-11)


### ⚠ BREAKING CHANGES

* Hotfix IMOD-29363

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!211

* Merge branch 'hotfix' into 'develop' ([38d337f](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/38d337fc7d86f12068e218d7983dfe5d87ee520c))

### [2.20.11-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.20.10...v2.20.11-hotfix.1) (2022-05-11)

### [2.15.3-hotfix.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.15.3-hotfix.2...v2.15.3-hotfix.3) (2022-05-11)
### [2.20.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.20.9...v2.20.10) (2022-05-06)


### ⚠ BREAKING CHANGES

* Feature/imod 29592 eor failure scenario bug fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!208

* Merge branch 'feature/IMOD-29592-Eor-Failure-Scenario-Bug-Fix' into 'develop' ([c2b16c2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/c2b16c28855ab7f4225b76eabb4fa875ea93b8d0))

### [2.20.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.20.8...v2.20.9) (2022-05-05)


### ⚠ BREAKING CHANGES

* Feature/photo add external photo uuid

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!195

* Merge branch 'feature/Photo-Add-External-Photo-Uuid' into 'develop' ([7e9f60c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/7e9f60c4bcd9341094d694d4485eb87ee6b71c6b))

### [2.20.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.20.7...v2.20.8) (2022-05-04)


### ⚠ BREAKING CHANGES

* Increased version as the jar in DEV is packaged with older version

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!206

* Merge branch 'feature/addconstructor-to-eorcompleted' into 'develop' ([81a65fc](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/81a65fc0b3edb2a1dbc010aa8776dd65d4909e70))

### [2.20.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.20.6...v2.20.7) (2022-05-04)


### ⚠ BREAKING CHANGES

* Feature/addconstructor to eorcompleted

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!205

* Merge branch 'feature/addconstructor-to-eorcompleted' into 'develop' ([f2fe4d9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/f2fe4d9f4ad79d50c02e9270d3e3785daab12850))

### [2.20.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.20.5...v2.20.6) (2022-05-04)


### ⚠ BREAKING CHANGES

* consume eor completed

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!204

* Merge branch 'feature/Consume_Eor_completed' into 'develop' ([32a24d1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/32a24d1803b4e7ccd064dbf4825bc253c8f9bfc8))

### [2.20.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.20.4...v2.20.5) (2022-05-04)


### ⚠ BREAKING CHANGES

* Feature/eor failure scenarios

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!200

* Merge branch 'feature/EOR-Failure-Scenarios' into 'develop' ([0f3700a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/0f3700ae2d236d9e7ed8eb37a5e8075509f19f0c))

### [2.20.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.20.3...v2.20.4) (2022-04-29)


### ⚠ BREAKING CHANGES

* Feature/imod 29191 bug fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!198

* Merge branch 'feature/IMOD-29191-Bug-Fix' into 'develop' ([35189c1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/35189c189907c1c9fded800b98add13c16e067f0))

### [2.20.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.20.2...v2.20.3) (2022-04-26)


### ⚠ BREAKING CHANGES

* fixed IMOD-29052

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!194

* Merge branch 'feature/IMOD-29052-BugFix' into 'develop' ([50a3afb](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/50a3afb30b06a825acfe4c464c3747f2359eeeef))

### [2.20.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.20.1...v2.20.2) (2022-04-25)


### ⚠ BREAKING CHANGES

* DB CI CD Implementation

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!193

* Merge branch 'feature/IMOD-28802_DB_pipeline' into 'develop' ([05ee438](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/05ee4380f39d0ff64bfbb1e114ec6c7c1566e522))

### [2.20.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.20.0...v2.20.1) (2022-04-19)


### ⚠ BREAKING CHANGES

* Missing hotfix changes updated

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!188

* Merge branch 'feature/ResultUpdate' into 'develop' ([ca612ca](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/ca612cade4ca1a859c4e95ddb37373de27a0d9dc))

## [2.20.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.19.0...v2.20.0) (2022-04-19)


### ⚠ BREAKING CHANGES

* Feature/imod 26287 consume ri incidents

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!186

* Merge branch 'feature/IMOD-26287_ConsumeRI_incidents' into 'develop' ([e388567](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/e38856762ddeb1bfb3d70bffef69fd0c13069f21))

## [2.19.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.18.0...v2.19.0) (2022-04-13)


### ⚠ BREAKING CHANGES

* EOR feature

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!182

* Merge branch 'feature/IMOD-21087/imod-1461-EOR-ORS-Events-library' into 'develop' ([862da14](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/862da14c3e80202aa156c40a62ac2b3317fc25ed))

### [2.18.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.18.0...v2.18.1-hotfix.1) (2022-04-12)

## [2.18.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.17.4...v2.18.0) (2022-04-12)

### [2.17.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.17.3...v2.17.4) (2022-04-05)


### ⚠ BREAKING CHANGES

* Feature/imod 27534 view single tt

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!173
* Add partnerCode to message attribute when publish messages to the topic

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!175

* Merge branch 'feature/IMOD-27534-viewSingleTT' into 'develop' ([d73dbc6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/d73dbc6d4d6a3664c4f1c8da49c25a93b06dda5b))
* Merge branch 'feature/IMOD-28210-add-partnerCode-When-publishingMessage' into 'develop' ([668877f](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/668877fe3d47b43992ef71477f31448d80ef1175))

### [2.17.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.17.2...v2.17.3) (2022-04-04)


### ⚠ BREAKING CHANGES

* Feature/imod 27531 suitability checks

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!172

* Merge branch 'feature/IMOD-27531_suitability_checks' into 'develop' ([78eb6d0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/78eb6d000c1add1ba06e3724e237753be55224e2))

### [2.17.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.17.1...v2.17.2) (2022-03-23)


### ⚠ BREAKING CHANGES

* Feature/imod 26234 eor update status transition

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!167

* Merge branch 'feature/IMOD-26234_EOR_update_status_transition' into 'develop' ([9cc93ab](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/9cc93ab4b2963c579ae07482e0de6960b427ab1a))

### [2.17.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.17.0...v2.17.1) (2022-03-22)


### ⚠ BREAKING CHANGES

* Feature/imod 26751 consume eor requested to initiate eor

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management!165

* Merge branch 'feature/IMOD-26751-ConsumeEorRequestedToInitiateEOR' into 'develop' ([80d09bf](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/commit/80d09bfc1f31a582a6e9ae656fa2279336c9caf9))

## [2.17.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.16.1...v2.17.0) (2022-03-11)

### [2.16.1](https://git-us-east1-c.ci-gateway.int.gprd.gitlab.net:8989/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.16.0...v2.16.1) (2022-03-10)

## [2.16.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.15.3...v2.16.0) (2022-03-10)

### [2.15.3-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.15.3-hotfix.1...v2.15.3-hotfix.2) (2022-04-07)

### [2.15.3-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.15.2...v2.15.3-hotfix.1) (2022-03-25)

### [2.15.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.15.2...v2.15.3) (2022-02-26)

### [2.15.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.15.1...v2.15.2) (2022-02-23)

### [2.15.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.15.0...v2.15.1) (2022-02-22)

## [2.15.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.14.0...v2.15.0) (2022-02-21)

## [2.14.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.13.0...v2.14.0) (2022-02-21)

## [2.13.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.12.0...v2.13.0) (2022-02-18)

## [2.12.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.11.0...v2.12.0) (2022-02-17)

## [2.11.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.10.0...v2.11.0) (2022-02-14)

## [2.10.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.9.0...v2.10.0) (2022-02-11)

## [2.9.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.8.0...v2.9.0) (2022-02-10)

## [2.8.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.7.0...v2.8.0) (2022-02-04)

## [2.7.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.6.0...v2.7.0) (2022-02-04)

## [2.6.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.5.0...v2.6.0) (2022-02-01)

## [2.5.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.4.0...v2.5.0) (2022-01-28)

## [2.4.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.3.0...v2.4.0) (2022-01-28)

## [2.3.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.2.0...v2.3.0) (2022-01-27)

## [2.2.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.1.0...v2.2.0) (2022-01-26)

## [2.1.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v2.0.0...v2.1.0) (2022-01-25)

## [2.0.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v1.11.3...v2.0.0) (2022-01-21)

### [1.11.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v1.11.2...v1.11.3) (2022-01-14)

### [1.11.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v1.11.1...v1.11.2) (2022-01-14)

### [1.11.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v1.11.0...v1.11.1) (2022-01-11)

## [1.11.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v1.10.0...v1.11.0) (2022-01-06)

## [1.10.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v1.9.2...v1.10.0) (2022-01-05)

### [1.9.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v1.9.1...v1.9.2) (2022-01-04)

### [1.9.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v1.9.0...v1.9.1) (2022-01-04)

## [1.9.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v1.8.0...v1.9.0) (2022-01-03)

## [1.8.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v1.7.3...v1.8.0) (2021-12-30)

### [1.7.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v1.7.2...v1.7.3) (2021-12-24)

### [1.7.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v1.7.1...v1.7.2) (2021-12-21)

### [1.7.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v1.7.0...v1.7.1) (2021-12-21)

## [1.7.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v1.6.0...v1.7.0) (2021-12-16)

### [1.6.1-hotfix.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v1.6.1-hotfix.3...v1.6.1-hotfix.4) (2021-12-14)

### [1.6.1-hotfix.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v1.6.1-hotfix.2...v1.6.1-hotfix.3) (2021-12-13)

### [1.6.1-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v1.6.1-hotfix.1...v1.6.1-hotfix.2) (2021-12-09)

### [1.6.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v1.6.0...v1.6.1-hotfix.1) (2021-12-08)

## [1.6.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v1.5.0...v1.6.0) (2021-11-22)

## [1.5.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v1.4.0...v1.5.0) (2021-11-16)

## [1.4.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v1.3.0...v1.4.0) (2021-10-27)

## [1.3.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v1.2.0...v1.3.0) (2021-10-05)

## [1.1.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/compare/v1.0.0...v1.1.0) (2021-08-26)

## 1.0.0 (2021-08-23)
