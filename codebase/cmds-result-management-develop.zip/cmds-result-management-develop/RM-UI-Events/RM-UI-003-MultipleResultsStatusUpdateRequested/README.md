
# rmui003multipleresultsstatusupdaterequested MultipleResultsStatusUpdateRequested Event
rmui003multipleresultsstatusupdaterequested MultipleResultsStatusUpdateRequested Event




Event published by _____


Put description here


| Code | Description |
| ---- | ----------- |
| 202 | Accepted |



| Name | Type | Description | Required |
| ---- | ---- | ----------- | -------- |


| Name | Type | Description | Required |
| ---- | ---- | ----------- | -------- |
