**Pre-requisites:**

1) The DB/role/user/schema should not be present already so that this will create everything from scratch

**Steps to execute RM DB Scripts:**

1) Go to cmds-result-management repository in develop branch (https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/-/tree/develop/)

2) Go to SQLScripts folder and download the entire folder (https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-management/-/tree/develop/SQLScripts)

3) Connect to RM DB Instance using below command (Provide password when prompted)
   `psql -h <<HOST>> -U postgres`

4) Executing file create_database_ddl.sql will drop existing rm database and recreate it.This should be one time run. Please consult Suersh Kanna (kanna.suresh@cambridgeassessment.org.uk) before executing this script.
   `\i create_database_ddl.sql`

5) Execute ielts_master.sql . This will connect to rm database and recreate all tables and data if they do not already exist.
   `\i ielts_master.sql`

**Post execution checks:**

1) All 30 tables are created in rm DB with postgres as schema
2) rm_user and rm_rw_role are created