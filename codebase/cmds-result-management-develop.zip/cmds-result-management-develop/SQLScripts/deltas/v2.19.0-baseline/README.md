* Steps to execute:
	Run script: IMOD-26287_create_incident_table.sql
	
* Validation:
    - new table should be created "rm_owner.incident"
  