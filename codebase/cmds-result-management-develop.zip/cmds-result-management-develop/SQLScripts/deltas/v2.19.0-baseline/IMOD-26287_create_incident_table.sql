CREATE TYPE incident_severity_type AS ENUM (
	'INFO',
	'WARNING',
	'CONFIRMED_MALPRACTICE'
	);

CREATE TABLE IF NOT EXISTS rm_owner.incident(
	incident_uuid uuid NOT NULL,
	booking_uuid uuid NOT NULL,
	incident_type_uuid uuid,
	incident_severity incident_severity_type,
	ban_review_required boolean,
	incident_status_type_uuid uuid,
	event_datetime TIMESTAMPTZ NOT NULL,
    created_by varchar(36) NOT NULL,
    created_datetime TIMESTAMPTZ NOT NULL,
    updated_by varchar(36) NULL,
    updated_datetime TIMESTAMPTZ NULL,
    concurrency_version integer NOT NULL,
	constraint pk_incident PRIMARY KEY (incident_uuid),
	constraint booking_incident_Type_unique UNIQUE (booking_uuid, incident_type_uuid)
);
