--In booking database.

\copy (select b.booking_uuid, b.banned_status from booking_owner.booking b) TO 'absolute\path\with\bookingBannedStatus.csv' WITH delimiter ',' csv header;
