--In RM database,

CREATE TEMP TABLE tmp_booking(booking_uuid uuid, banned_status banned_status_type);

\copy tmp_booking FROM 'absolute\path\with\bookingBannedStatus.csv' WITH delimiter ',' csv header;

UPDATE rm_owner.booking SET banned_status = tmp_booking.banned_status FROM tmp_booking WHERE booking.booking_uuid = tmp_booking.booking_uuid;
UPDATE rm_owner.booking SET banned_status = 'UNKNOWN' WHERE booking.banned_status IS NULL;
