CREATE TYPE banned_status_type AS ENUM (
	'UNKNOWN',
	'BANNED',
	'NOTBANNED'
	);

ALTER TABLE rm_owner.booking ADD column IF NOT EXISTS banned_status banned_status_type;
