* Steps to execute:
    1. In RM DB: Run the script 1000_IMOD-28002_alter_booking_add_banned_status.sql
    2. In BOOKING DB: Run the script 1001_IMOD-28002_extract_bannedStatus_from_booking_db.sql
    3. In RM : Run the script 1002_IMOD-28002_update_rm_data_from_cvs.sql

* Validation:
	- Table booking should contain the column banned_status.
