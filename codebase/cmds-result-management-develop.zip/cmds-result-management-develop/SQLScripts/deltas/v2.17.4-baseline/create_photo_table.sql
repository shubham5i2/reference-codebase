-- Table to keep TT Candidate photo

CREATE TABLE rm_owner.photo
(
   photo_uuid uuid NOT NULL,
   photo_type_uuid uuid NOT NULL,
   booking_uuid uuid NOT NULL,
   composite_candidate_number varchar (20) NOT NULL,
   photo_path text NOT NULL,
   photo_version integer NOT NULL,
   event_datetime timestamptz NULL,
   created_by varchar (36) NOT NULL DEFAULT 'Operations User',
   created_datetime timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
   updated_by varchar (36),
   updated_datetime timestamptz,
   concurrency_version INTEGER NOT NULL DEFAULT 0,
   CONSTRAINT pk_photo PRIMARY KEY (photo_uuid)
);