DROP TABLE IF EXISTS rm_owner.incident_category CASCADE;

CREATE TABLE IF NOT EXISTS rm_owner.incident_category (
	incident_category_uuid uuid NOT NULL,
	incident_category_code varchar(50) NOT NULL,
	incident_category varchar(50) NOT NULL,
	effective_from_date DATE NOT NULL,
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
	created_by VARCHAR(36) NOT NULL,
	created_datetime timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_by VARCHAR(36),
	updated_datetime timestamptz ,
	concurrency_version int4 NOT NULL DEFAULT 0,
	CONSTRAINT incident_category_pkey PRIMARY KEY (incident_category_uuid)
);