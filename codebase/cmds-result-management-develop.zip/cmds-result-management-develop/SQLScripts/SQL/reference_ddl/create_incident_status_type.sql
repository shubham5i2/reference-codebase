DROP TABLE IF EXISTS rm_owner.incident_status_type;

CREATE TABLE IF NOT EXISTS rm_owner.incident_status_type (
	incident_status_type_uuid uuid NOT NULL,
	incident_status_type varchar(50) NOT NULL,
	incident_status_type_code varchar(50) not null,
	effective_from_date DATE NOT NULL,
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
	created_by VARCHAR(36) NOT NULL,
	created_datetime timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_by VARCHAR(36),
	updated_datetime timestamptz ,
	concurrency_version int4 NOT NULL DEFAULT 0,
	CONSTRAINT incident_status_type_pkey PRIMARY KEY (incident_status_type_uuid)
);