DROP TABLE IF EXISTS rm_owner.country CASCADE;

CREATE TABLE IF NOT EXISTS rm_owner.country (
    country_uuid UUID NOT NULL, 
    country_iso3_code VARCHAR(3) NOT NULL UNIQUE,
    country_name VARCHAR(100) NOT NULL,  
    legacy_reference VARCHAR(3),
    effective_from_date DATE NOT NULL DEFAULT '2020-07-01',
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
    created_by VARCHAR(36) NOT NULL,
    created_datetime TIMESTAMPTZ NOT NULL DEFAULT current_timestamp,
    updated_by VARCHAR(36),
    updated_datetime TIMESTAMPTZ,
    concurrency_version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT pk_country PRIMARY KEY (country_uuid)
);