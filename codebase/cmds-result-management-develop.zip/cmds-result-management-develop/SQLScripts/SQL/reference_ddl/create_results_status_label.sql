DROP TABLE IF EXISTS rm_owner.results_status_label CASCADE;

CREATE TABLE IF NOT EXISTS rm_owner.results_status_label (
	results_status_label_uuid UUID NOT NULL,
    results_status_type_uuid UUID NOT NULL,
    results_status_label VARCHAR(50) NOT NULL,
	results_status_label_code VARCHAR(50) NOT NULL,
    results_status_comment_mandatory BOOLEAN NOT NULL,	
    effective_from_date DATE NOT NULL,
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
    created_by VARCHAR(36) NOT NULL,
    created_datetime TIMESTAMPTZ NOT NULL DEFAULT current_timestamp,
    updated_by VARCHAR(36),
    updated_datetime TIMESTAMPTZ,
    concurrency_version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT pk_results_status_label PRIMARY KEY (results_status_label_uuid),
	CONSTRAINT fk_01_results_status_label_results_status_type FOREIGN KEY (results_status_type_uuid) REFERENCES rm_owner.results_status_type(results_status_type_uuid)
);