DROP TABLE IF EXISTS rm_owner.territory;

CREATE TABLE IF NOT EXISTS rm_owner.territory (
    territory_uuid UUID NOT NULL,
    country_uuid UUID NOT NULL,
    territory_iso_code VARCHAR(6) NOT NULL UNIQUE,
    territory_name VARCHAR(100) NOT NULL,
    legacy_reference VARCHAR(3),
    effective_from_date DATE NOT NULL,
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
    created_by VARCHAR(36) NOT NULL,
    created_datetime TIMESTAMPTZ NOT NULL DEFAULT current_timestamp,
    updated_by VARCHAR(36),
    updated_datetime TIMESTAMPTZ,
    concurrency_version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT pk_territory PRIMARY KEY (territory_uuid),
    CONSTRAINT fk_01_territory_country FOREIGN KEY (country_uuid) REFERENCES rm_owner.country(country_uuid)
);