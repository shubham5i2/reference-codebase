DROP TABLE IF EXISTS rm_owner.identification_type;

CREATE TABLE IF NOT EXISTS rm_owner.identification_type (
    identification_type_uuid UUID NOT NULL,
    identification_type VARCHAR(50) NOT NULL,
    description VARCHAR(100) NOT NULL,
    legacy_reference VARCHAR(3),
    effective_from_date DATE NOT NULL,
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
    created_by VARCHAR(36) NOT NULL,
    created_datetime TIMESTAMPTZ NOT NULL DEFAULT current_timestamp,
    updated_by VARCHAR(36),
    updated_datetime TIMESTAMPTZ,
    concurrency_version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT pk_identification_type PRIMARY KEY (identification_type_uuid)
);