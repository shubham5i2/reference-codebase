DROP TABLE IF EXISTS rm_owner.module_type CASCADE;

CREATE TABLE IF NOT EXISTS rm_owner.module_type (
    module_type_uuid UUID NOT NULL,
    module_type VARCHAR(20) NOT NULL,
    description VARCHAR(100) NULL,
    effective_from_date DATE NOT NULL,
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
    created_by VARCHAR(36) NOT NULL ,
    created_datetime TIMESTAMPTZ NOT NULL DEFAULT current_date,
    updated_by VARCHAR(36),
    updated_datetime TIMESTAMPTZ,
    concurrency_version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT pk_module_type PRIMARY KEY (module_type_uuid)
    );