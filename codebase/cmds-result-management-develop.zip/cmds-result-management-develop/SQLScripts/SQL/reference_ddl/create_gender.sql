DROP TABLE IF EXISTS rm_owner.gender;

CREATE TABLE IF NOT EXISTS rm_owner.gender (
    gender_uuid UUID NOT NULL,
    gender_code VARCHAR(1) NOT NULL UNIQUE,
    gender_description VARCHAR(100) NOT NULL,
    legacy_reference VARCHAR(3),
    effective_from_date DATE NOT NULL,
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
    created_by VARCHAR(36) NOT NULL,
    created_datetime TIMESTAMPTZ NOT NULL DEFAULT current_timestamp,
    updated_by VARCHAR(36),
    updated_datetime TIMESTAMPTZ,
    concurrency_version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT pk_gender PRIMARY KEY (gender_uuid)
);