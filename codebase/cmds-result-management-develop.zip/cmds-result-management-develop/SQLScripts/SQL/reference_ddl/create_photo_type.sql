DROP TABLE IF EXISTS rm_owner.photo_type;

CREATE TABLE IF NOT EXISTS rm_owner.photo_type
 (
    photo_type_uuid UUID NOT NULL,
    photo_type_code VARCHAR(20) NOT NULL,
    photo_type_description VARCHAR(200) NOT NULL,
    effective_from_date DATE NOT NULL DEFAULT '2020-07-01',
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
    created_datetime TIMESTAMPTZ NOT NULL DEFAULT current_timestamp,
    updated_datetime TIMESTAMPTZ DEFAULT current_timestamp,
    concurrency_version INTEGER NOT NULL,
    updated_by VARCHAR(36),
    created_by VARCHAR(36) NOT NULL,
    CONSTRAINT pk_photo_type PRIMARY KEY (photo_type_uuid)
    );
