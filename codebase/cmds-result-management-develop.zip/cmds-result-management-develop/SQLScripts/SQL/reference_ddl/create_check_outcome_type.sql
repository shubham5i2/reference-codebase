DROP TABLE IF EXISTS rm_owner.check_outcome_type;

CREATE TABLE IF NOT EXISTS rm_owner.check_outcome_type (
	check_outcome_type_uuid uuid NOT NULL,
	check_outcome_type varchar(50) NOT NULL,
	check_outcome_type_code varchar(50) not null,
	effective_from_date DATE NOT NULL,
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
	created_by VARCHAR(36) NOT NULL,
	created_datetime timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_by VARCHAR(36),
	updated_datetime timestamptz ,
	concurrency_version int4 NOT NULL DEFAULT 0,
	CONSTRAINT check_outcome_type_pkey PRIMARY KEY (check_outcome_type_uuid)
);