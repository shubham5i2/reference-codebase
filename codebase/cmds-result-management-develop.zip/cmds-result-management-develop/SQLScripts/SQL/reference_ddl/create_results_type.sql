DROP TABLE IF EXISTS rm_owner.results_type;

CREATE TABLE IF NOT EXISTS rm_owner.results_type (
     results_type_uuid UUID,
     results_type VARCHAR(50) NOT NULL,
	 results_type_code VARCHAR(50) NOT NULL,
     effective_from_date DATE NOT NULL,
     effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
     created_by VARCHAR(36) NOT NULL,
     created_datetime TIMESTAMPTZ NOT NULL DEFAULT current_timestamp,
     updated_by VARCHAR(36),
     updated_datetime TIMESTAMPTZ,
     concurrency_version INTEGER NOT NULL DEFAULT 0,
     CONSTRAINT pk_results_type PRIMARY KEY (results_type_uuid)
);