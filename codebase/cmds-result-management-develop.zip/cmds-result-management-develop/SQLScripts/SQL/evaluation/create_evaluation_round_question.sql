-- Create Table for evaluation_round_question
CREATE TABLE IF NOT EXISTS rm_owner.evaluation_round_question (
	evaluation_round_question_uuid uuid NOT NULL,
    question_uuid uuid NOT NULL,
    evaluation_round_uuid uuid NOT NULL,
	question_weight smallint NULL,
	created_by varchar(36) NOT NULL,
	created_datetime timestamptz NOT NULL,
	updated_by varchar(36) NULL,
	updated_datetime timestamptz NULL,
	concurrency_version INTEGER NOT NULL,
	CONSTRAINT pk_evaluation_round_question PRIMARY KEY (evaluation_round_question_uuid),
	CONSTRAINT fk_01_evaluation_round_question_question FOREIGN KEY (question_uuid) REFERENCES rm_owner.question (question_uuid),
	CONSTRAINT fk_02_evaluation_round_question_evaluation_round FOREIGN KEY (evaluation_round_uuid) REFERENCES rm_owner.evaluation_round(evaluation_round_uuid)
	);
	
-- Create Table for evaluation_round_question
COMMENT ON TABLE rm_owner.evaluation_round_question IS 'Table holds records for each Question OR Interaction asked for the related test component.';
COMMENT ON COLUMN rm_owner.evaluation_round_question.evaluation_round_question_uuid IS 'Evaluation Round Question UUID to uniquely identify a record in evaluation_round_question.';
COMMENT ON COLUMN rm_owner.evaluation_round_question.question_uuid IS 'Qusetion UUID reference associated with the evaluation_round_question.';
COMMENT ON COLUMN rm_owner.evaluation_round_question.evaluation_round_uuid IS 'Evaluation Round UUID reference associated with the evaluation_round_question.';
COMMENT ON COLUMN rm_owner.evaluation_round_question.question_weight IS 'Column to hold question_weight to identify which is Task 1 and Task 2 in the Writing File. Task 2 has a double weighting in Results Determination.';
COMMENT ON COLUMN rm_owner.evaluation_round_question.created_by IS 'Column to hold the user who created the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.evaluation_round_question.created_datetime IS 'Column to hold the time at which the record was created. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.evaluation_round_question.updated_by IS 'Column to hold the user who updated the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.evaluation_round_question.updated_datetime IS 'Column to hold the time at which the record was updated. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.evaluation_round_question.concurrency_version IS 'Column to hold version details so as to ensure that there is only one update at a time.';