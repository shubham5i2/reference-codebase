-- Create Table for question
CREATE TABLE IF NOT EXISTS rm_owner.question (
    question_uuid uuid NOT NULL,
    external_question_id integer NULL,
	created_by varchar(36) NOT NULL,
	created_datetime timestamptz NOT NULL,
	updated_by varchar(36) NULL,
	updated_datetime timestamptz NULL,
	concurrency_version INTEGER NOT NULL,
	CONSTRAINT pk_question PRIMARY KEY (question_uuid)
	);
	
-- Create Table for question
COMMENT ON TABLE rm_owner.question IS 'Table to hold records for external question IDs mapped with CMDS UUID';
COMMENT ON COLUMN rm_owner.question.question_uuid IS 'Question UUID to uniquely identify a record in question.';
COMMENT ON COLUMN rm_owner.question.external_question_id IS 'Column to hold external question IDs.';
COMMENT ON COLUMN rm_owner.question.created_by IS 'Column to hold the user who created the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.question.created_datetime IS 'Column to hold the time at which the record was created. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.question.updated_by IS 'Column to hold the user who updated the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.question.updated_datetime IS 'Column to hold the time at which the record was updated. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.question.concurrency_version IS 'Column to hold version details so as to ensure that there is only one update at a time.';