-- Create Table for evaluation_history
CREATE TABLE IF NOT EXISTS rm_owner.evaluation_history (
    evaluation_history_uuid uuid NOT NULL,
	evaluation_round_history_uuid uuid NOT NULL,
    evaluation_uuid uuid NOT NULL,
    external_question_id integer NOT NULL,
    question_weight smallint NULL,
    score smallint NULL,
	created_by varchar(36) NOT NULL,
	created_datetime timestamptz NOT NULL,
	updated_by varchar(36) NULL,
	updated_datetime timestamptz NULL,
	concurrency_version INTEGER NOT NULL,
	CONSTRAINT pk_evaluation_history PRIMARY KEY (evaluation_history_uuid),
    CONSTRAINT fk_01_evaluation_history_evaluation_round_history FOREIGN KEY (evaluation_round_history_uuid) REFERENCES rm_owner.evaluation_round_history (evaluation_round_history_uuid)
	);
	
-- Comments on evaluation_history table and columns
COMMENT ON TABLE rm_owner.evaluation_history IS 'Table to hold history records of evaluation table to show in UI';
COMMENT ON COLUMN rm_owner.evaluation_history.evaluation_history_uuid IS 'Evaluation History  UUID to uniquely identify a record in evaluation_history.';
COMMENT ON COLUMN rm_owner.evaluation_history.evaluation_round_history_uuid IS 'Evaluation Round History UUID reference associated with the evaluation_history.';
COMMENT ON COLUMN rm_owner.evaluation_history.evaluation_uuid IS 'Evaluation UUID  reference associated with the evaluation_history.';
COMMENT ON COLUMN rm_owner.evaluation_history.external_question_id IS 'Column to hold external question IDs';
COMMENT ON COLUMN rm_owner.evaluation_history.question_weight IS 'Column to hold question_weight to identify which is Task 1 and Task 2 in the Writing File. Task 2 has a double weighting in Results Determination.';
COMMENT ON COLUMN rm_owner.evaluation_history.score IS 'Column to hold evaluation score.';
COMMENT ON COLUMN rm_owner.evaluation_history.created_by IS 'Column to hold the user who created the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.evaluation_history.created_datetime IS 'Column to hold the time at which the record was created. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.evaluation_history.updated_by IS 'Column to hold the user who updated the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.evaluation_history.updated_datetime IS 'Column to hold the time at which the record was updated. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.evaluation_history.concurrency_version IS 'Column to hold version details so as to ensure that there is only one update at a time.';