-- Create Table for mark_history
CREATE TABLE IF NOT EXISTS rm_owner.mark_history (
    mark_history_uuid uuid NOT NULL,
    mark_criteria_uuid uuid NOT NULL,
	evaluation_history_uuid uuid NOT NULL,
    mark_uuid uuid NOT NULL,
    marks numeric(2,1) NOT NULL,
    result_received_datetime timestamptz NOT NULL,
	created_by varchar(36) NOT NULL,
	created_datetime timestamptz NOT NULL,
	updated_by varchar(36) NULL,
	updated_datetime timestamptz NULL,
	concurrency_version INTEGER NOT NULL,
	CONSTRAINT pk_mark_history PRIMARY KEY (mark_history_uuid),
	CONSTRAINT fk_01_mark_history_mark_criteria	FOREIGN KEY (mark_criteria_uuid) References rm_owner.mark_criteria(mark_criteria_uuid),
	CONSTRAINT fk_02_mark_history_evaluation_history FOREIGN KEY (evaluation_history_uuid) References rm_owner.evaluation_history(evaluation_history_uuid)
	);
	
-- Create Table for mark_history
COMMENT ON TABLE rm_owner.mark_history IS 'Table to hold history records of mark table to show in UI';
COMMENT ON COLUMN rm_owner.mark_history.mark_history_uuid IS 'Mark History UUID to uniquely identify a record in mark_history.';
COMMENT ON COLUMN rm_owner.mark_history.mark_criteria_uuid IS 'Mark Criteria UUID reference associated with the mark_history.';
COMMENT ON COLUMN rm_owner.mark_history.evaluation_history_uuid IS 'Evaluation History UUID reference associated with the mark_history.';
COMMENT ON COLUMN rm_owner.mark_history.mark_uuid IS 'Mark UUID reference associated with the mark_history.';
COMMENT ON COLUMN rm_owner.mark_history.marks IS 'Column to hold marks for each record in evaluation table.';
COMMENT ON COLUMN rm_owner.mark_history.result_received_datetime IS ' When any of the marks received previously changes then a new record is inserted with a new timestamptz.';
COMMENT ON COLUMN rm_owner.mark_history.created_by IS 'Column to hold the user who created the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.mark_history.created_datetime IS 'Column to hold the time at which the record was created. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.mark_history.updated_by IS 'Column to hold the user who updated the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.mark_history.updated_datetime IS 'Column to hold the time at which the record was updated. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.mark_history.concurrency_version IS 'Column to hold version details so as to ensure that there is only one update at a time.';
