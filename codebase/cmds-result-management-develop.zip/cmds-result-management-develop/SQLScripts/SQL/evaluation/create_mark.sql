-- Create mark table
CREATE TABLE IF NOT EXISTS rm_owner.mark (
    mark_uuid uuid NOT NULL,
    evaluation_uuid uuid NOT NULL,
    mark_criteria_uuid uuid NOT NULL,
    marks smallint NOT NULL,
    created_by varchar(36) NOT NULL,
    created_datetime TIMESTAMPTZ NOT NULL,
    updated_by varchar(36) NULL,
    updated_datetime TIMESTAMPTZ NULL,
    concurrency_version integer NOT NULL,
    CONSTRAINT pk_mark PRIMARY KEY (mark_uuid),
    CONSTRAINT fk_01_mark_mark_criteria FOREIGN KEY (mark_criteria_uuid) REFERENCES rm_owner.mark_criteria(mark_criteria_uuid),
    CONSTRAINT fk_02_mark_evaluation FOREIGN KEY (evaluation_uuid) REFERENCES rm_owner.evaluation(evaluation_uuid)
    );
    
-- Create Table for mark
COMMENT ON TABLE rm_owner.mark IS 'Table to hold mark records for each evaluation with the criteria type referenced in mark_criteria';
COMMENT ON COLUMN rm_owner.mark.mark_uuid IS 'Mark UUID to uniquely identify a record in mark table.';
COMMENT ON COLUMN rm_owner.mark.evaluation_uuid IS 'Evaluation UUID reference associated with the mark';
COMMENT ON COLUMN rm_owner.mark.mark_criteria_uuid IS 'Mark Criteria UUID reference associated with the mark';
COMMENT ON COLUMN rm_owner.mark.marks IS 'Column to hold marks for each record in evaluation table.';
COMMENT ON COLUMN rm_owner.mark.created_by IS 'Column to hold the user who created the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.mark.created_datetime IS 'Column to hold the time at which the record was created. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.mark.updated_by IS 'Column to hold the user who updated the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.mark.updated_datetime IS 'Column to hold the time at which the record was updated. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.mark.concurrency_version IS 'Column to hold version details so as to ensure that there is only one update at a time.';
