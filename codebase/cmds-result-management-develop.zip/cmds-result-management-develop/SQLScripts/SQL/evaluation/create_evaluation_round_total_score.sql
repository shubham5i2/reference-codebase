-- Create Table for evaluation_round_total_score
CREATE TABLE IF NOT EXISTS rm_owner.evaluation_round_total_score (
    evaluation_round_total_score_uuid uuid NOT NULL,
    round_id smallint NOT NULL,
    booking_line_uuid uuid NOT NULL,
    parent_test_event_id integer NULL,
    test_event_id integer NOT NULL,
    round_total_score smallint NOT NULL,
	created_by varchar(36) NOT NULL,
	created_datetime timestamptz NOT NULL,
	updated_by varchar(36) NULL,
	updated_datetime timestamptz NULL,
	concurrency_version INTEGER NOT NULL,
	CONSTRAINT pk_evaluation_round_total_score PRIMARY KEY (evaluation_round_total_score_uuid)
);

-- Create Table for evaluation_round_total_score
COMMENT ON TABLE rm_owner.evaluation_round_total_score IS 'Table to hold records with calculated evaluation round total scores';
COMMENT ON COLUMN rm_owner.evaluation_round_total_score.evaluation_round_total_score_uuid IS 'Evaluation Round Total Score UUID to uniquely identify a record in evaluation_round_total_score.';
COMMENT ON COLUMN rm_owner.evaluation_round_total_score.round_id IS 'Column to hold external round IDs.';
COMMENT ON COLUMN rm_owner.evaluation_round_total_score. booking_line_uuid IS 'Booking Line UUID reference associated with the evaluation_round_total_score.';
COMMENT ON COLUMN rm_owner.evaluation_round_total_score.parent_test_event_id IS 'Column to hold the parent test event IDs.';
COMMENT ON COLUMN rm_owner.evaluation_round_total_score.test_event_id IS 'Column to hold the child test event IDs.';
COMMENT ON COLUMN rm_owner.evaluation_round_total_score.round_total_score IS 'Column to hold calculated total score for each evaluation round.';
COMMENT ON COLUMN rm_owner.evaluation_round_total_score.created_by IS 'Column to hold the user who created the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.evaluation_round_total_score.created_datetime IS 'Column to hold the time at which the record was created. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.evaluation_round_total_score.updated_by IS 'Column to hold the user who updated the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.evaluation_round_total_score.updated_datetime IS 'Column to hold the time at which the record was updated. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.evaluation_round_total_score.concurrency_version IS 'Column to hold version details so as to ensure that there is only one update at a time.';
