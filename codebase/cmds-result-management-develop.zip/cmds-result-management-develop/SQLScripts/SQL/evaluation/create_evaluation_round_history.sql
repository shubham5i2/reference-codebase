-- Create Table for evaluation_round_history
CREATE TABLE IF NOT EXISTS rm_owner.evaluation_round_history (
	evaluation_round_history_uuid uuid NOT NULL,
    evaluation_round_uuid uuid NOT NULL,
	booking_uuid uuid NOT NULL,
    booking_line_uuid uuid NULL,
    external_parent_test_id integer NULL,
    external_test_id integer NOT NULL,
    round_id smallint NOT NULL,
    final_grade NUMERIC(2,1) NOT NULL,
    result_status rm_owner.result_status_type NOT NULL,
    result_received_datetime timestamptz  NOT NULL,
	created_by varchar(36) NOT NULL,
	created_datetime timestamptz NOT NULL,
	updated_by varchar(36) NULL,
	updated_datetime timestamptz NULL,
	concurrency_version INTEGER NOT NULL,
	CONSTRAINT pk_evaluation_round_history PRIMARY KEY (evaluation_round_history_uuid)
);

-- Comments on evaluation_round_history table and columns
COMMENT ON TABLE rm_owner.evaluation_round_history IS 'Table to hold history records of evaluation_round table to show in UI';
COMMENT ON COLUMN rm_owner.evaluation_round_history.evaluation_round_history_uuid IS 'Evaluation Round History UUID to uniquely identify a record in evaluation_round_history';
COMMENT ON COLUMN rm_owner.evaluation_round_history.evaluation_round_uuid IS 'Evaluation Round UUID reference associated with the evaluation_round_history.';
COMMENT ON COLUMN rm_owner.evaluation_round_history.booking_uuid IS 'Booking UUID reference associated with the evaluation_round_history.';
COMMENT ON COLUMN rm_owner.evaluation_round_history.booking_line_uuid IS 'Booking Line UUID reference associated with the evaluation_round_history.';
COMMENT ON COLUMN rm_owner.evaluation_round_history.external_parent_test_id IS 'Column to hold the parent test event IDs.';
COMMENT ON COLUMN rm_owner.evaluation_round_history.external_test_id IS 'Column to hold the child test event IDs.';
COMMENT ON COLUMN rm_owner.evaluation_round_history.round_id IS 'Column to hold external round IDs.';
COMMENT ON COLUMN rm_owner.evaluation_round_history.final_grade IS 'Column to hold external final grade of test event.';
COMMENT ON COLUMN rm_owner.evaluation_round_history.result_status IS 'Column to identify the result status from result_status_type.';
COMMENT ON COLUMN rm_owner.evaluation_round_history.result_received_datetime IS 'Result Received DateTime when the result is received by Results Management.';
COMMENT ON COLUMN rm_owner.evaluation_round_history.created_by IS 'Column to hold the user who created the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.evaluation_round_history.created_datetime IS 'Column to hold the time at which the record was created. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.evaluation_round_history.updated_by IS 'Column to hold the user who updated the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.evaluation_round_history.updated_datetime IS 'Column to hold the time at which the record was updated. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.evaluation_round_history.concurrency_version IS 'Column to hold version details so as to ensure that there is only one update at a time.';