- The script 1000_IMOD-25088_create_reference_data.sql, 1001_IMOD-25088_insert_reference_data.sql and 1002_IMOD-25088_drop_result_type.sql is related to
  update the reference data from LPR.
  1. Run the script 1000_IMOD-25088_create_reference_data.sql.
  2. Run the script 1001_IMOD-25088_insert_reference_data.sql.
	3. Run the script 1002_IMOD-25088_drop_result_type.sql.

* Validation:
  - 31 reference data tables are recreated
	- Data recreated in 29 reference data tables
	- Result Type table is not present.