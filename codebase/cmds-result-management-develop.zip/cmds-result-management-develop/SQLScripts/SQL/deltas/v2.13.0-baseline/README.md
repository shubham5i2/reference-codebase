1. Infra team to put the password and add it in SSM Parameter store. 
2. **rm_user** is the default user of the DB which application uses for DB access.
3. In environments apart from Sandbox, Password for the rm_user should be created randomly by Infra team and set in the AWS SSM parameter store DB password parameter value. This password will not be shared with anyone apart from Tech Leads. 
4. Sample script to set rm_user password below:

`ALTER user rm_user with password 'REPLACE_THIS_STRING_WITH_APPLICATION_USER_PASSWORD_TO_BE_SET_BY_INFRA';`