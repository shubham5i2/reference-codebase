Run both scripts:
1. IMOD-26751-create_eor_ddl.sql
2. IMOD-26751-create_eor_line_ddl.sql

*Verification*
1. Verify that eor table exists in the DB.
2. Verify that eor_line table exists in the DB.
