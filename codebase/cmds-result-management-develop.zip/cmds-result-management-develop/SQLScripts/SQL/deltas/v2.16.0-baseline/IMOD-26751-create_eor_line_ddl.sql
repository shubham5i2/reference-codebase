CREATE TABLE IF NOT EXISTS rm_owner.eor_line(
	eor_line_uuid uuid NOT NULL,
	eor_uuid uuid NOT NULL,
    created_by varchar(36) NOT NULL,
    created_datetime TIMESTAMPTZ NOT NULL,
    updated_by varchar(36) NULL,
    updated_datetime TIMESTAMPTZ NULL,
    concurrency_version integer NOT NULL,
	CONSTRAINT pk_eor_line PRIMARY KEY (eor_line_uuid),
	CONSTRAINT fk_01_eor_line_eor FOREIGN KEY (eor_uuid) References rm_owner.eor(eor_uuid)
);
