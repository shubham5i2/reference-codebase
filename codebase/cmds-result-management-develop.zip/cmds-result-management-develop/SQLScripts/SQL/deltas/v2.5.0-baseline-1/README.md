- The script 1000_IMOD-24886_create_reference_data.sql and 1001_IMOD-24886_insert_reference_data.sql is related to
  update the reference data from LPR.
    1. Run the script 1000_IMOD-24886_create_reference_data.sql.
    2. Run the script 1001_IMOD-24886_insert_reference_data.sql.

* Validation:
    - In the check_outcome_status table, the count of rows should be 5.
    - In the check_outcome_type table, the count of rows should be 7.
    - In the address_type table, the count of rows should be 4.
    - In the contact_type table, the count of rows should be 4.
    - In the country table, the count of rows should be 255.
    - In the education_level table, the count of rows should be 4.
    - In the gender table, the count of rows should be 2.
    - In the territory table, the count of rows should be 4690.