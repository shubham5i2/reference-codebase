* Steps to execute:
	Run script: IMOD-26753_alter_eor_add_columns.sql
	
* Validation:
	- Expected new column created in the table with the column name "eor_outcome_datetime" as timestampz time