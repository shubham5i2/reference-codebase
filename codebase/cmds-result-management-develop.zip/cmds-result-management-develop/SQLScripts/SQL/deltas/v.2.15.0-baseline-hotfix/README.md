* Steps to execute:
	1. Request data copy from booking to populate the new fields.
		1.1 Run script 1000_extract_isvoid_data_from_booking.sql to extract the information from Booking (booking_owner schema) in the csv file defined in 'absolute\path\with\filename.csv'.
        1.2 Run script 1001_update_rm_isvoid_field_from_csv.sql to load data from csv file into RM (rm_owner schema) and update new fields in booking table. 
	2. Run the script 1002_set_is_void_true_for_bookings_created_through_queue.sql
	
* Validation:
	- select * from rm_owner.booking where is_void IS NULL; -- This should return 0 records