--In booking database.

\copy (select booking_uuid, is_void from booking_owner.booking) TO 'filename.csv' WITH delimiter ',' csv header;