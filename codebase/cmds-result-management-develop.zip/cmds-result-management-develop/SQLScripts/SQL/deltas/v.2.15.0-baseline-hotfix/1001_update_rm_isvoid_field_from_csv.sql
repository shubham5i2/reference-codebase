--In RM database,

CREATE TEMP TABLE tmp_booking(booking_uuid uuid, is_void boolean);

\copy tmp_booking FROM 'absolute\path\with\filename.csv' WITH delimiter ',' csv header;

UPDATE rm_owner.booking SET is_void = tmp_booking.is_void FROM tmp_booking WHERE booking.booking_uuid = tmp_booking.booking_uuid;