--In RM database,

UPDATE rm_owner.booking SET is_void = FALSE WHERE is_void IS NULL;