CREATE TABLE IF NOT EXISTS rm_owner.evaluation_round_booking (
	evaluation_round_booking_uuid UUID DEFAULT uuid_generate_v4() NOT NULL,
    evaluation_round_uuid uuid NULL,
    booking_uuid uuid NULL,
	booking_line_uuid uuid NULL,
    round_id integer NULL,
	created_by varchar(36) NOT NULL DEFAULT 'Operations User',
	created_datetime timestamptz NOT NULL DEFAULT now(),
	updated_by varchar(36) NULL,
	updated_datetime timestamptz NULL,
	concurrency_version INTEGER NOT NULL DEFAULT 0,
	CONSTRAINT pk_evaluation_round_booking PRIMARY KEY (evaluation_round_booking_uuid)
);