\ir  ..//..//rule//insert_rule.sql
