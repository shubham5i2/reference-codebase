- The script 1000_IMOD-24755_insert_rule_table.sql is related to update the column rule_id from rule table.
    1. Run the script 1000_IMOD-24755_insert_rule_table.sql.

* Validation:
    - In the results_status_comment table, the count of rows should be 7.
    - In the column rule_id should be those entries: R1, R2, R3, R4, R5, R6, R7.