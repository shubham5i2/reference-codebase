Run `IMOD-26050-refresh_product_reference.sql` file by using below command
`\ir IMOD-26050-refresh_product_referenc.sql`

*Verification*
1. `select product_name from rm_owner.product where product_uuid = '3e81e94b-8b6a-42b5-970c-b141f9d195a3';` should return *IELTS Online Academic*
