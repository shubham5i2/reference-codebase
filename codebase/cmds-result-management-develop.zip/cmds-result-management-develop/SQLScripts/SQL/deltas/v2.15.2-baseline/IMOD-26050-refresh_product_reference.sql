\ir ..//..//set_client_encoding.sql
\ir ..//..//reference_dml//insert_country.sql
\ir ..//..//reference_dml//insert_sector_type.sql
\ir ..//..//product_dml//insert_product.sql