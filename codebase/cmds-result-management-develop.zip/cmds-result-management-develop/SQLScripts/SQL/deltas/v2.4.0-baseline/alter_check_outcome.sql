ALTER TABLE rm_owner.check_outcome ADD COLUMN IF NOT EXISTS event_datetime timestamptz;
