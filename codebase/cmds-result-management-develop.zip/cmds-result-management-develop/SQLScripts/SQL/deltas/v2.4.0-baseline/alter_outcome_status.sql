ALTER TABLE rm_owner.outcome_status ADD COLUMN IF NOT EXISTS event_datetime timestamptz;

