\ir  ..//..//product_ddl//create_product.sql
\ir  ..//..//product_dml//insert_product.sql