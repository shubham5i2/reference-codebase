- The script IMOD-21441-Rerun-Product-Scripts-IOL.script contains the path to create_product.sql and insert_product.sql. This will drop and recreate product data with IOL name
    1. Run the script create_product.sql
	2. Run the script insert_product.sql
	
* Validation:
	- select * from rm_owner.product where product_name = 'IELTS Online'; //should return 1 row
