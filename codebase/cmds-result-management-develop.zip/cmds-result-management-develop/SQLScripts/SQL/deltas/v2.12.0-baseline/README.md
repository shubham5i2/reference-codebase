Execution:
1. Run the script "alter_booking_add_isVoid_column.sql"
2. verify that the column is_void exists in rm_owner.booking table.
