ALTER TABLE rm_owner.booking ADD COLUMN IF NOT EXISTS is_void bool;
