- The script 1000_IMOD-23192_Booking_structure_refactor.sql is related to the refactor of Booking table, The fields unique_test_taker_id, short_candidate_number, birth_date, title, first_name, last_name, nationality_uuid, nationality_other was moved from table unique_test_taker to booking and identity_number moved out of unique_test_taker_identity to booking. 

* Steps to execute:
	1. Run the script 1000_IMOD-23192_Booking_structure_refactor.sql.
	2. Request data copy from booking to populate the new fields.
		2.1 Run script 1001_IMOD-23192_extract_data_from_booking_fields.sql to extract the information from Booking (booking_owner schema) in the csv file defined in 'absolute\path\with\filename.csv'.
        2.2 Run script 1002_IMOD-23192_update_rm_fields_from_cvs.sql to load data from csv file into RM (rm_owner schema) and update new fields in booking table. 
	3. Run the script 1003_IMOD-23192_set_constraints_drop_table.sql
	
* Validation:
	- In the table booking the "fk_01_booking_unique_test_taker" should be deleted. 
	- In the table booking the count of fields should be 21 and included the fields listed above.
	- New fields in booking table should be filled.