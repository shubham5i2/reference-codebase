--In RM database,

CREATE TEMP TABLE tmp_booking(booking_uuid uuid, unique_test_taker_uuid varchar(36), unique_test_taker_id varchar(14), title varchar(12), first_name varchar(100), last_name varchar(100), birth_date date, short_candidate_number varchar(6), nationality_uuid varchar(36), nationality_other varchar(100), identity_number varchar(100));

\copy tmp_booking FROM 'absolute\path\with\filename.csv' WITH delimiter ',' csv header;

ALTER TABLE tmp_booking ALTER unique_test_taker_uuid TYPE uuid USING CAST(nullif(unique_test_taker_uuid, 'NULL') AS uuid), ALTER nationality_uuid TYPE uuid USING CAST(nullif(nationality_uuid, 'NULL') AS uuid);

UPDATE rm_owner.booking SET unique_test_taker_id = tmp_booking.unique_test_taker_id, unique_test_taker_uuid = tmp_booking.unique_test_taker_uuid, title = tmp_booking.title, first_name = tmp_booking.first_name, last_name = tmp_booking.last_name, birth_date = tmp_booking.birth_date, short_candidate_number = lpad(tmp_booking.short_candidate_number, 6, '0'), nationality_uuid = tmp_booking.nationality_uuid, nationality_other = tmp_booking.nationality_other, identity_number = tmp_booking.identity_number FROM tmp_booking WHERE booking.booking_uuid = tmp_booking.booking_uuid;