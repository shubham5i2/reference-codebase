ALTER TABLE rm_owner.booking DROP CONSTRAINT fk_01_booking_unique_test_taker;

ALTER TABLE rm_owner.booking ADD COLUMN unique_test_taker_id varchar(14) NULL;
ALTER TABLE rm_owner.booking ADD COLUMN short_candidate_number varchar(6) NULL;
ALTER TABLE rm_owner.booking ADD COLUMN birth_date date NULL;
ALTER TABLE rm_owner.booking ADD COLUMN title varchar(12) NULL;
ALTER TABLE rm_owner.booking ADD COLUMN first_name varchar(100) NULL;
ALTER TABLE rm_owner.booking ADD COLUMN last_name varchar(100) NULL;
ALTER TABLE rm_owner.booking ADD COLUMN nationality_uuid uuid NULL;
ALTER TABLE rm_owner.booking ADD COLUMN nationality_other varchar(100) NULL;
ALTER TABLE rm_owner.booking ADD COLUMN identity_number varchar(100) NULL;

COMMENT ON COLUMN rm_owner.booking.unique_test_taker_id IS 'Column to hold human readable unique TestTaker IDs';
COMMENT ON COLUMN rm_owner.booking.short_candidate_number IS 'Column to hold candidate number';
COMMENT ON COLUMN rm_owner.booking.birth_date IS 'Column to hold the date of birth of the test taker';
COMMENT ON COLUMN rm_owner.booking.title IS 'Column to hold the title of the test taker';
COMMENT ON COLUMN rm_owner.booking.first_name IS 'Column to hold First name of the test taker';
COMMENT ON COLUMN rm_owner.booking.last_name IS 'Column to hold Last name of the test taker';
COMMENT ON COLUMN rm_owner.booking.nationality_uuid IS 'Nationality UUID reference associated with nationality';
COMMENT ON COLUMN rm_owner.booking.nationality_other IS 'Column to hold other nationality of test taker';
COMMENT ON COLUMN rm_owner.booking.identity_number IS 'Column to hold Identity number of the test taker';
