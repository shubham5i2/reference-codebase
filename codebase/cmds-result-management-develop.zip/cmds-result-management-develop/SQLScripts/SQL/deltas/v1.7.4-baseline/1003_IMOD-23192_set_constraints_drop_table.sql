
ALTER TABLE rm_owner.booking ALTER COLUMN unique_test_taker_id SET NOT NULL;
ALTER TABLE rm_owner.booking ALTER COLUMN short_candidate_number SET NOT NULL;

DROP TABLE rm_owner.unique_test_taker_identity;
DROP TABLE rm_owner.unique_test_taker;