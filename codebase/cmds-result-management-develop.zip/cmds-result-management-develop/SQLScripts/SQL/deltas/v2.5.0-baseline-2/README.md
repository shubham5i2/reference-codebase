Run the script  alter_result.sql

Verification: the below query should return:
constraint_name    |
-------------------+
booking_uuid_unique|

select constraint_name from information_schema.constraint_column_usage where table_name = 'result'  and constraint_name = 'booking_uuid_unique';
