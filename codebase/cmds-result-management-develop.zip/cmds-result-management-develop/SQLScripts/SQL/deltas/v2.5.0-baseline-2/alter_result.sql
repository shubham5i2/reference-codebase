-- Add booking_uuid_unique to result table to prevent duplication of the result records.
DO $$
BEGIN
    BEGIN
        ALTER TABLE rm_owner."result" ADD CONSTRAINT booking_uuid_unique UNIQUE (booking_uuid);
    EXCEPTION
        WHEN duplicate_table THEN RAISE NOTICE 'Table constraint booking_uuid_unique already exists';
    END;
END $$;