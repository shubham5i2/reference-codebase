- The script 1000_IMOD-25068_create_reference_data.sql and 1001_IMOD-25068_insert_reference_data.sql is related to
  update the reference data from LPR.
    1. Run the script 1000_IMOD-25068_create_reference_data.sql.
    2. Run the script 1001_IMOD-25068_insert_reference_data.sql.

* Validation:
    - In the identification_type table, the count of rows should be 13.
    - In the incident_category table, the count of rows should be 7.
    - In the incident_status_type table, the count of rows should be 3.
    - In the incident_type table, the count of rows should be 1.
    - In the language table, the count of rows should be 144.
    - In the mark_criteria table, the count of rows should be 7.
    - In the module_type table, the count of rows should be 2.
    - In the nationality table, the count of rows should be 251.
    - In the note_type table, the count of rows should be 2.
    - In the occupation_level table, the count of rows should be 8.
    - In the occupation_sector table, the count of rows should be 20.