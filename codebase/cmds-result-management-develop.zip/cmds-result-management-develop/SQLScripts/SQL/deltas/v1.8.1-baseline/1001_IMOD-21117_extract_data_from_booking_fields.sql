--In booking database.
\copy ( select booking_uuid, booking_status, booking_detail_status from booking_owner.booking) TO 'absolute\path\with\filename.csv' WITH delimiter ',' csv header;