-- Type Creation for booking Detail Status Type
DO $$ BEGIN
	CREATE TYPE rm_owner.booking_detail_status_type AS ENUM
   	('INCOMPLETE', 'COMPLETE');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Type Creation for booking Status Type
DO $$ BEGIN
	CREATE TYPE rm_owner.booking_status_type AS ENUM
   	('PAID', 'CANCELLED', 'UNPAID');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

alter table if exists rm_owner.booking ADD COLUMN if not exists booking_status rm_owner.booking_status_type NULL;
alter table if exists rm_owner.booking ADD COLUMN if not exists booking_detail_status rm_owner.booking_detail_status_type NULL ;
alter table if exists rm_owner.booking ADD COLUMN if not exists event_datetime TIMESTAMPTZ NULL;

COMMENT ON COLUMN rm_owner.booking.booking_status IS 'Booking column for status type from booking_status_type';
COMMENT ON COLUMN rm_owner.booking.booking_detail_status IS 'Booking column for the detail of status type from booking_detail_status_type';
COMMENT ON COLUMN rm_owner.booking.event_datetime IS 'Booking column holds the eventDateTime received from booking (eventHeader)';