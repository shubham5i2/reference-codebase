- The script 1000_IMOD-21117_Create_Update_incomplete_bookings.sql is related to the columns "booking_status", "booking_detail_status" and "event_datetime" creation in RM DB, as needed to both columns the Enum types "booking_status_type" and "booking_detail_status_type" are also created.
* Steps to execute:
	1. Run the script 1000_IMOD-21117_Create_Update_incomplete_bookings.sql.
	2. Request data copy from booking to populate new fields.
		2.1 Run script 1001_IMOD-21117_extract_data_from_booking_fields.sql to extract the information from Booking (booking_owner schema) in the csv file defined in 'absolute\path\with\filename.csv'.
        2.2 Run script 1002_IMOD-21117_update_rm_fields_from_cvs.sql to load data from csv file into RM (rm_owner schema) and update new fields in booking table. **Change path to CSV file**. 
	
* Validation:
	- In the table booking the fields "booking_status", "booking_detail_status" and "event_datetime" should listed. 
		- script to list all columns:
		```sql 
		SELECT 
			COLUMN_NAME 
		FROM INFORMATION_SCHEMA.COLUMNS 
		WHERE TABLE_NAME = 'booking' 
			AND TABLE_SCHEMA = 'rm_owner'
		```
	- In the custom Types both "booking_status_type" and "booking_detail_status_type" should listed.
		- script to list the custom types: 
		```sql
		SELECT
		   t.typname AS enumtype,
		   en.enumlabel AS enumlabel
		FROM pg_type t
		LEFT JOIN pg_catalog.pg_namespace n ON n.oid = t.typnamespace
		JOIN pg_enum en ON en.enumtypid = t.oid
		WHERE n.nspname='rm_owner' and t.typname IN ('booking_status_type', 'booking_detail_status_type')
		```