--In RM database,
CREATE TEMP TABLE tmp_booking(booking_uuid uuid, booking_status rm_owner.booking_status_type, booking_detail_status rm_owner.booking_detail_status_type);

\copy tmp_booking FROM 'absolute\path\with\filename.csv' WITH delimiter ',' csv header;

UPDATE rm_owner.booking SET booking_status = tmp_booking.booking_status, booking_detail_status = tmp_booking.booking_detail_status FROM tmp_booking WHERE booking.booking_uuid = tmp_booking.booking_uuid;