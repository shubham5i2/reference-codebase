-- RUN
\ir ..//..//reference_dml//insert_results_status_label.sql
\ir ..//..//reference_dml//insert_results_status_comment.sql