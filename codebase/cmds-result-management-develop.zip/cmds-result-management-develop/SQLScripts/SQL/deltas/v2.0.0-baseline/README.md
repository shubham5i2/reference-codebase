Execution Instructions:
======================

1. Run the script in this folder.

Verification Instructions:
==========================

1. Verify that rm_owner.rule table exists in the database