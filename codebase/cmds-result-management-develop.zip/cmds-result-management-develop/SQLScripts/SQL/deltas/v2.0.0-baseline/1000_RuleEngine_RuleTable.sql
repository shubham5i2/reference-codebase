\ir  ..//..//rule//create_rule.sql
