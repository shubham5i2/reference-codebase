ALTER TABLE rm_owner.eor
ADD column IF NOT EXISTS external_eor_id VARCHAR(100) NOT NULL,
ADD COLUMN IF NOT EXISTS external_eor_uuid uuid NOT NULL,
ADD COLUMN IF NOT EXISTS external_booking_uuid uuid NOT NULL,
ADD COLUMN IF NOT EXISTS booking_uuid uuid NOT NULL,
ADD COLUMN IF NOT EXISTS eor_request_datetime TIMESTAMPTZ NULL,
ADD COLUMN IF NOT EXISTS eor_status eor_status_type NULL;
