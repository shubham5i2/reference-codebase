ALTER TABLE rm_owner.eor_line
ADD COLUMN IF NOT EXISTS booking_line_uuid uuid NOT NULL,
ADD COLUMN IF NOT EXISTS external_booking_line_uuid uuid NULL,
ADD COLUMN IF NOT EXISTS external_eor_line_uuid uuid NULL;
