* Steps to execute:
    1. Run IMOD-26751_create_eor_status_Type_enum.sql
    2. Run IMOD-26751_alter_eor_add_columns.sql
    3. Run IMOD-26751_alter_eor_line_add_columns.sql

* Validation:
  1. Verify eor_status_Type exists in the DB.
  2. Verify eor table has the following columns (external_eor_id, external_eor_uuid, external_booking_uuid, booking_uuid, eor_request_datetime, eor_status)
  3. Verify eor_line table has the following columns (booking_line_uuid, external_booking_line_uuid, external_eor_line_uuid)
