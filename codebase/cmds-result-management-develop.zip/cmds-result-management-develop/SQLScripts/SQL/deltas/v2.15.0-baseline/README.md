Run `create_result_status_concurrency.sql` file by using below command
`\ir create_result_status_concurrency.sql`

*Verification*
1. New table with name `result_status_concurrency` should be created with 2 columns
