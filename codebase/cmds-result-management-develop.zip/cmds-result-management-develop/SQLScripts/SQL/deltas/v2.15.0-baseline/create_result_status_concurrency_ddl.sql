CREATE TABLE rm_owner.result_status_concurrency(
booking_uuid uuid,
concurrency_version integer,
CONSTRAINT pk_result_status_concurrency PRIMARY KEY (booking_uuid)
);