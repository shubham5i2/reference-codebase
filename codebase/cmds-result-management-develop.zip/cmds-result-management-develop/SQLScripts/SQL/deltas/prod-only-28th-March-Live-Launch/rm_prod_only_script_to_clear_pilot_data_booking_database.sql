-- In Booking Database
UPDATE booking_owner.booking_release_status 
SET results_status_type_uuid = '57d416a1-57b3-4b72-b24c-d511f1749a79', booking_release_status_updated_datetime = NOW()::TIMESTAMP, 
updated_datetime = NOW()::TIMESTAMP, concurrency_version = concurrency_version + 1 
WHERE booking_uuid IN (
	'<PASS_BOKING_UUID_1>', '<PASS_BOKING_UUID_2>', '<PASS_BOKING_UUID_N>'
);