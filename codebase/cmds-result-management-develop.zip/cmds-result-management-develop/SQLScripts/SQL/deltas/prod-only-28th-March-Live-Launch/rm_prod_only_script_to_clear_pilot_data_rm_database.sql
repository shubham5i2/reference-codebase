-- In RM Database
DO 
$updatetopermwithheld$
DECLARE 
    booking_uuid_value uuid;
    results_status_history_uuid_value uuid;
BEGIN 

    FOR booking_uuid_value IN SELECT booking_uuid FROM rm_owner.booking WHERE booking_uuid in ('<PASS_BOKING_UUID_1>', '<PASS_BOKING_UUID_2>', '<PASS_BOKING_UUID_N>')
    LOOP 

        INSERT INTO rm_owner.results_status_history (results_status_history_uuid, booking_uuid, results_status_type_uuid, results_status_comment_text, created_by, created_datetime, concurrency_version) 
        VALUES (uuid_generate_v4(), booking_uuid_value, '57d416a1-57b3-4b72-b24c-d511f1749a79', 'Optional Comment', 'Operations User', NOW()::TIMESTAMP, 0) 
        RETURNING results_status_history_uuid INTO results_status_history_uuid_value;

        UPDATE rm_owner.result SET results_status_history_uuid = results_status_history_uuid_value, concurrency_version = concurrency_version + 1, updated_by = 'Operations User', updated_datetime = NOW()::TIMESTAMP WHERE booking_uuid = booking_uuid_value;

    END LOOP;

END;
$updatetopermwithheld$
LANGUAGE plpgsql;

-- In Booking Database
UPDATE booking_owner.booking_release_status 
SET results_status_type_uuid = '57d416a1-57b3-4b72-b24c-d511f1749a79', booking_release_status_updated_datetime = NOW()::TIMESTAMP, 
updated_datetime = NOW()::TIMESTAMP, concurrency_version = concurrency_version + 1 
WHERE booking_uuid IN (
	SELECT booking_uuid FROM booking_owner.booking 
	WHERE test_date = '2023-02-10' AND partner_code = 'BC'
);