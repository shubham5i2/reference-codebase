**Steps to execute:**

	1. Stop Result Management & Booking Microservice in Production environment to ensure no processing happens during the activity
	2. Take DB backup of Result Management & Booking Mx database tables
	3. Run the following scripts
		* In booking database, run script `rm_prod_only_script_to_clear_pilot_data_booking_database.sql` to move status to Permanently Withheld by passing the booking_uuid list
    	* In rm database, run script `rm_prod_only_script_to_clear_pilot_data_rm_database.sql` to move status to Permanently Withheld by passing the booking_uuid list
	4. Start Result Management & Booking Microservice back
