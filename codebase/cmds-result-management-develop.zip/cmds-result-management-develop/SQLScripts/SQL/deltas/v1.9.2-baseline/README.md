IMOD-21964: RM to process ResultIntegrityCheckChanged event (EVT-44).

Run the scripts in this folder in the order indicated in the prefix. 
Check that:
1. check_outcome_type table exists and has 7 rows.
2. outcome_status_type table exists and has 4 rows.
3. check_outcome_status table exists and has 5 rows.
4. check_outcome table exists.
5. outcome_status table exists.