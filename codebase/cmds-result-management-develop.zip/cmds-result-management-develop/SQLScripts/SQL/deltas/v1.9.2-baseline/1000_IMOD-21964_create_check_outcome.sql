CREATE TABLE IF NOT EXISTS rm_owner.check_outcome (
    check_outcome_uuid uuid NOT NULL,
    booking_uuid uuid NOT NULL,
    created_by VARCHAR(36) NOT NULL,
    created_datetime timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_by VARCHAR(36),
    updated_datetime timestamptz ,
    concurrency_version int4 NOT NULL DEFAULT 0,
    check_outcome_status_uuid uuid NOT NULL,
    check_outcome_type_uuid uuid NOT NULL,
    CONSTRAINT check_outcome_pkey PRIMARY KEY (check_outcome_uuid)
);