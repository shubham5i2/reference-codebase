ALTER TABLE rm_owner.booking ADD COLUMN IF NOT EXISTS external_booking_uuid uuid;
