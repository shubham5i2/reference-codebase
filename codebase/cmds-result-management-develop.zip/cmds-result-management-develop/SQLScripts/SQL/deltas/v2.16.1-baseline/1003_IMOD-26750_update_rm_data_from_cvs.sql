--In RM database,

CREATE TEMP TABLE tmp_booking(booking_uuid uuid, external_booking_uuid uuid);
CREATE TEMP TABLE tmp_booking_line(booking_line_uuid uuid, external_booking_line_uuid uuid);

\copy tmp_booking FROM 'absolute\path\with\bookingExternalUuid.csv' WITH delimiter ',' csv header;
\copy tmp_booking_line FROM 'absolute\path\with\bookingLineExternalUuid.csv' WITH delimiter ',' csv header;

UPDATE rm_owner.booking SET external_booking_uuid = tmp_booking.external_booking_uuid FROM tmp_booking WHERE booking.booking_uuid = tmp_booking.booking_uuid;
UPDATE rm_owner.booking_line SET external_booking_line_uuid = tmp_booking_line.external_booking_line_uuid FROM tmp_booking_line WHERE booking_line.booking_line_uuid = tmp_booking_line.booking_line_uuid;
