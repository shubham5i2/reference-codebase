--In booking database.

\copy (select b.booking_uuid, b.external_booking_uuid from booking_owner.booking b) TO 'absolute\path\with\bookingExternalUuid.csv' WITH delimiter ',' csv header;
\copy (select bl.booking_line_uuid, bl.external_booking_line_uuid from booking_owner.booking_line bl) TO 'absolute\path\with\bookingLineExternalUuid.csv' WITH delimiter ',' csv header;
