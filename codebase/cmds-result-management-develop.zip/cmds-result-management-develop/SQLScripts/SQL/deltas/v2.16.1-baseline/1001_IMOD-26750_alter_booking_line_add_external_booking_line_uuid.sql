ALTER TABLE rm_owner.booking_line ADD COLUMN IF NOT EXISTS external_booking_line_uuid uuid;
