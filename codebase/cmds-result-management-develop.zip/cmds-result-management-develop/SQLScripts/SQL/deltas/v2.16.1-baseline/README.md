* Steps to execute:
    1. Run the script 1000_IMOD-26750_alter_booking_add_external_booking_uuid.sql
    2. Run the script 1001_IMOD-26750_alter_booking_line_add_external_booking_line_uuid.sql
    3. Request data copy from booking to populate the new fields. 
       * Run script 1002_IMOD-26750_extract_data_from_booking_fields.sql to extract the information from Booking (booking_owner schema) in the csv file.
       * Run script 1003_IMOD-26750_update_rm_data_from_cvs.sql to load data from csv file into RM (rm_owner schema) and update new fields.

* Validation:
    - Table booking should contain the column external_booking_uuid.
    - Table booking_line should contain the column external_booking_line_uuid.
