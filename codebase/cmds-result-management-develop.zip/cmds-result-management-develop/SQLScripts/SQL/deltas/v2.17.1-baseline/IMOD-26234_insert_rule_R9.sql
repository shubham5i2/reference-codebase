-- UNCONFIRMED to CONFIRMED (EOR_COMPLETED)
insert into rm_owner.rule (
  rule_id, from_status_uuid, from_status_label_uuid, 
  to_status_uuid, to_status_label_uuid, 
  to_status_comment_uuid, trigger_type, 
  additional_checks, permission_id, 
  created_by, created_datetime, updated_by, 
  updated_datetime, concurrency_version
) 
values 
  (
    'R9', 
    '3d189282-e531-47f2-aa22-d24eef1d20b6', 
    'aee4f1ac-d11a-4423-b1b6-61cb5bb30a78', 
    '27c03460-2662-4a63-b1aa-6d158b85c0a5', 
    null, 
    null, 
    'AUTO', 
    'EOR_COMPLETED', 
    null, 
    'Operations User', 
    now (), 
    null, 
    null, 
    0
  );
