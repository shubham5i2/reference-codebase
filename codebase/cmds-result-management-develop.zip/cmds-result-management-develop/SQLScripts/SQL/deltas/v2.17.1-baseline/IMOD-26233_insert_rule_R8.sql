-- RELEASED to UNCONFIRMED (EOR_PENDING)
insert into rm_owner.rule (
  rule_id, from_status_uuid, from_status_label_uuid, 
  to_status_uuid, to_status_label_uuid, 
  to_status_comment_uuid, trigger_type, 
  additional_checks, permission_id, 
  created_by, created_datetime, updated_by, 
  updated_datetime, concurrency_version
) 
values 
  (
    'R8', 
    '1aef5721-71fc-434b-8e42-c2f077753826', 
    null, 
    '3d189282-e531-47f2-aa22-d24eef1d20b6', 
    'aee4f1ac-d11a-4423-b1b6-61cb5bb30a78', 
    null, 
    'AUTO', 
    'EOR_PENDING', 
    null, 
    'Operations User', 
    now (), 
    null, 
    null, 
    0
  );
