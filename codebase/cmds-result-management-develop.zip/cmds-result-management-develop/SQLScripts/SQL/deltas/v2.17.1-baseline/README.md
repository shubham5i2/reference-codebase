* Steps to execute:
	Run script: 00_recreate_rules_id.sql
	Run script: IMOD-26233_insert_rule_R8.sql 
	Run script: IMOD-26234_insert_rule_R9.sql 
	
* Validation:
	- Expected in table rm_owner.rule 9 rows and the rule_id column with values R1 to R9.