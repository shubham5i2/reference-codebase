-- Create EMUM Type for result types
DO $$ BEGIN CREATE TYPE rm_owner.result_type_name AS ENUM (
    'NORMAL',
    'JAGGED-1',
    'JAGGED-2',
    'EOR'
    );
EXCEPTION
WHEN duplicate_object THEN null;
END $$;

-- Create Table for result type
CREATE TABLE IF NOT EXISTS rm_owner.result_type (
    result_type_uuid uuid NOT NULL,
    result_type_name rm_owner.result_type_name NOT NULL,
    result_type_priority smallint NOT NULL,
    created_by varchar(36) NOT NULL,
    created_datetime TIMESTAMPTZ NOT NULL,
    updated_by varchar(36) NULL,
    updated_datetime TIMESTAMPTZ NULL,
    concurrency_version integer NOT NULL,
    CONSTRAINT pk_result_type PRIMARY KEY (result_type_uuid)
);