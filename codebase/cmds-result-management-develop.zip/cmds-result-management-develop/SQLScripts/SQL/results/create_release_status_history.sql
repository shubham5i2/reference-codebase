-- Create EMUM Type for result status types
DO $$ BEGIN CREATE TYPE rm_owner.release_status_type AS ENUM (
    'UNCONFIRMED',
    'CONFIRMED',
    'VALIDATING',
    'VALIDATED',
    'RELEASED',
    'WITHHELD',
    'PERMANENTLY_ WITHHELD',
    'PENDING_REVIEW'
);
EXCEPTION
WHEN duplicate_object THEN null;
END $$;

-- Create rm_owner.release_status_history table
CREATE TABLE IF NOT EXISTS rm_owner.release_status_history (
    release_status_history_uuid uuid NOT NULL,
    booking_uuid uuid NOT NULL,
    release_status rm_owner.release_status_type NOT NULL,
    release_status_update_datetime TIMESTAMPTZ NOT NULL,
    release_status_comment varchar(2000) NULL,
    undergoing_eor boolean NOT NULL,
    created_by varchar(36) NOT NULL,
    created_datetime TIMESTAMPTZ NOT NULL,
    updated_by varchar(36) NULL,
    updated_datetime TIMESTAMPTZ NULL,
    concurrency_version integer NOT NULL,
    CONSTRAINT pk_release_status_history PRIMARY KEY (release_status_history_uuid)
);