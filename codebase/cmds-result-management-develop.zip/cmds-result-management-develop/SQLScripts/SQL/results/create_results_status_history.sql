-- Create rm_owner.results_status_history table
CREATE TABLE IF NOT EXISTS rm_owner.results_status_history (
    results_status_history_uuid uuid NOT NULL,
    booking_uuid uuid NOT NULL,
    results_status_type_uuid uuid NOT NULL,
    results_status_label_uuid uuid,
    results_status_comment_uuid uuid,
    created_by varchar(36) NOT NULL,
    created_datetime TIMESTAMPTZ NOT NULL DEFAULT current_timestamp,
    updated_by varchar(36),
    updated_datetime TIMESTAMPTZ,
    concurrency_version INTEGER NOT NULL DEFAULT 0,
    results_status_comment_text VARCHAR(100) NULL,
    CONSTRAINT pk_results_status_history PRIMARY KEY (results_status_history_uuid)
);
