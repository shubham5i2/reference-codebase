--DML scripts for results status type

INSERT INTO rm_owner.result_type(result_type_uuid, "result_type_name" , result_type_priority, created_by, created_datetime, concurrency_version)
VALUES ('76a3e4f0-2a7b-4aec-8389-2255726a31ef',
        'NORMAL',
        1,
		'Operations User',
		pg_catalog.now(),
		0
	) ON CONFLICT(result_type_uuid) DO NOTHING;

INSERT INTO rm_owner.result_type(result_type_uuid, "result_type_name" , result_type_priority, created_by, created_datetime, concurrency_version)
VALUES ('d28fec9b-752f-477a-a124-2a726d247098',
        'JAGGED-1',
        1,
		'Operations User',
		pg_catalog.now(),
		0
	) ON CONFLICT(result_type_uuid) DO NOTHING;

INSERT INTO rm_owner.result_type(result_type_uuid, "result_type_name" , result_type_priority, created_by, created_datetime, concurrency_version)
VALUES ('63b2b641-9cfc-4870-936d-9639a8069ecb',
        'JAGGED-2',
        1,
		'Operations User',
		pg_catalog.now(),
		0
	) ON CONFLICT(result_type_uuid) DO NOTHING;


INSERT INTO rm_owner.result_type(result_type_uuid, "result_type_name" , result_type_priority, created_by, created_datetime, concurrency_version)
VALUES ('399b45a9-9c32-4889-a44e-cdc595f8a6f7',
        'EOR',
        1,
		'Operations User',
		pg_catalog.now(),
		0
	) ON CONFLICT(result_type_uuid) DO NOTHING;