-- Create Tablse for location address
CREATE TABLE IF NOT EXISTS rm_owner.result_line (
    result_line_uuid uuid NOT NULL,
    result_line_score NUMERIC(2, 1) NOT NULL,
    result_uuid uuid NOT NULL,
    booking_line_uuid uuid NOT NULL,
    external_test_id integer NOT NULL,
    created_by VARCHAR(36) NOT NULL,
    created_datetime TIMESTAMPTZ NOT NULL,
    updated_by VARCHAR(36) NULL,
    updated_datetime TIMESTAMPTZ NULL,
    concurrency_version integer NOT NULL,
    CONSTRAINT pk_result_line PRIMARY KEY (result_line_uuid),
    CONSTRAINT fk_01_result_line_result FOREIGN KEY (result_uuid) References rm_owner.result(result_uuid)
);