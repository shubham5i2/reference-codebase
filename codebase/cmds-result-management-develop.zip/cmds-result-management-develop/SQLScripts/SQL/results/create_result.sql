-- Create Table for result
CREATE TABLE IF NOT EXISTS rm_owner.result (
    result_uuid uuid  DEFAULT public.uuid_generate_v4() NOT NULL,
    result_type_uuid uuid NULL,
    booking_uuid uuid NOT NULL,
    result_score NUMERIC(2, 1) NULL,
    trf_number VARCHAR(18),
    cerf_level VARCHAR(32),
    published_time TIMESTAMPTZ NULL,
    external_test_id integer NULL,
    created_by varchar(36) NOT NULL,
    created_datetime TIMESTAMPTZ NOT NULL,
    updated_by varchar(36) NULL,
    updated_datetime TIMESTAMPTZ NULL,
    concurrency_version integer NOT NULL,
    results_status_history_uuid uuid,
    CONSTRAINT pk_result PRIMARY KEY (result_uuid),
    CONSTRAINT fk_01_result_result_type FOREIGN KEY (result_type_uuid) References rm_owner.result_type(result_type_uuid)
);