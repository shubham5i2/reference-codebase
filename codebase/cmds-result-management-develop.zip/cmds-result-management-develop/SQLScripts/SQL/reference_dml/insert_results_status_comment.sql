--DML scripts for results status comment

TRUNCATE TABLE rm_owner.results_status_comment;

--Imposter
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('b1ede794-3206-47d6-b0f7-e9e1f4c5ea9b',
		'50324a6c-4fb5-464d-a063-7a146ffb96bc',
		'Imposter',
		'IMPOSTER',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Collusion (unknown means)
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('3cafd6ac-7ef2-4a0f-ac19-0481291f2192',
		'50324a6c-4fb5-464d-a063-7a146ffb96bc',
		'Collusion (unknown means)',
		'COLLUSION_UNKNOWN_MEANS',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Banned candidate
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('13ea595a-56b5-436b-a625-071b2cf26a86',
		'50324a6c-4fb5-464d-a063-7a146ffb96bc',
		'Banned candidate',
		'BANNED_CANDIDATE',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Another person in frame
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('31900013-a742-4d96-a7fc-a1a98c5ae1a4',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Another person in frame',
		'ANOTHER_PERSON_IN_FRAME',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Assisting another candidate
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('28ac69c7-88d2-4946-b9dd-465d26cebd02',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Assisting another candidate',
		'ASSISTING_ANOTHER_CANDIDATE',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Attempted bribery or blackmail
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('5964a833-ead0-4fe6-9f3b-3639c984ba76',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Attempted bribery or blackmail',
		'ATTEMPTED_BRIBERY_OR_BLACKMAIL',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Attempting to bring a Bluetooth device into the test room
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('268ff3f8-6441-4e68-a1f1-3ac470708527',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Attempting to bring a Bluetooth device into the test room',
		'ATTEMPTING_BRING_BLUETOOTH_DEVICE_INTO_TEST_ROOM',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Communicating with another person
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('ba249447-b271-4e2c-a222-ce6d0e67c0a3',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Communicating with another person',
		'COMMUNICATING_WITH_ANOTHER_PERSON',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Copying from another candidate
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('aeeb67b7-2a22-4219-bc70-f15cc4737dc8',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Copying from another candidate',
		'COPYING_FROM_ANOTHER_CANDIDATE',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Counterfeit/tampered ID
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('2df4d29d-bfae-4096-97cc-a125529b7af3',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Counterfeit/tampered ID',
		'COUNTERFEIT_TAMPERED_ID',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Disconnecting from internet
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('bab03221-e1d9-461d-b2d6-147abb65b5da',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Disconnecting from internet',
		'DISCONNECTING_FROM_INTERNET',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Ignoring invigilator’s instructions
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('92eb618a-e8b4-4f35-8ac6-9efc3e97bcd5',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Ignoring invigilator’s instructions',
		'IGNORING_INVIGILATORS_INSTRUCTIONS',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Imposter
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('66f7f581-49dc-4077-a65d-fd780c5d1c7a',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Imposter',
		'IMPOSTER',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Incorrect ID
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('05a9daa6-c5be-49fe-9d45-d5be5e5cde54',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Incorrect ID',
		'INCORRECT_ID',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--In-room identity swap
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('843594fe-76c9-4250-a43d-6ad8d4d2ff4c',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'In-room identity swap',
		'IN_ROOM_IDENTITY_SWAP',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Interfering with device
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('092487c5-b672-4ec5-9721-bc8b87c7630c',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Interfering with device',
		'INTERFERING_WITH_DEVICE',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Leaving the test room before the end of the test
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('b8b59705-adfe-4a0c-8140-eb6050871fa8',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Leaving the test room before the end of the test',
		'LEAVING_TEST_ROOM_BEFORE_END_TEST',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Looking away from screen
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('d12ff4bb-8301-46ef-8645-8c4ba5914536',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Looking away from screen',
		'LOOKING_AWAY_FROM_SCREEN',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Possessing an electronic device
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('7ae811ce-02fa-4766-8d8e-0c733a4c9a3e',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Possessing an electronic device',
		'POSSESSING_AN_ELECTRONIC_DEVICE',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Receiving remote assistance
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('9eae8753-e01f-4d14-a31b-2b79bce14abe',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Receiving remote assistance',
		'RECEIVING_REMOTE_ASSISTANCE',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Receiving assistance from another person in the room
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('1dcbf354-c20c-4c89-a0c2-25398248107e',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Receiving assistance from another person in the room',
		'RECEIVING_ASSISTANCE_FROM_ANOTHER_PERSON_IN_ROOM',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Removing test data from the test room
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('875d47d5-e9ef-4e6e-b1d7-68265efbb2cb',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Removing test data from the test room',
		'REMOVING_TEST_DATA_FROM_TEST_ROOM',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Threatening/abusive behaviour to proctor/test-centre staff
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('680cb282-3381-4391-923e-ca67937f503e',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Threatening/abusive behaviour to proctor/test-centre staff',
		'THREATENING_ABUSIVE_BEHAVIOUR_TO_PROCTOR_TESTCENTRE_STAFF',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;


--Unable to verify ID
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('b4b765c3-34e0-4915-aea8-be1d0f212a1c',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Unable to verify ID',
		'UNABLE_TO_VERIFY_ID',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Using a program other than Inspera Exam Portal
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('b946184e-eaa2-45b0-bc7b-96eac6a1a3ea',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Using a program other than Inspera Exam Portal',
		'USING_PROGRAM_OTHER_THAN_INSPERA_EXAM_PORTAL',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Using an electronic device (e.g. camera, phone)
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('4a3d2877-9905-4e2c-a04c-9de97194ed19',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Using an electronic device (e.g. camera, phone)',
		'USING_ELECTRONIC_DEVICE',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Using prepared notes (non version specific)
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('d43c9ee6-99e1-4e3d-a751-79fd25e00da3',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Using prepared notes (non version specific)',
		'USING_PREPARED_NOTES_NON_VERSION_SPECIFIC',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Using prepared notes (version specific)
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('97ab8adc-e76c-4d62-a4f5-cd4d761e1bb0',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Using prepared notes (version specific)',
		'USING_PREPARED_NOTES_VERSION_SPECIFIC',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Using prepared notes (unknown if version specific)
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('eb4654bb-c8cf-4e6e-96e5-a19f049d534a',
		'd00d4331-f798-429a-9c18-49893bdcba59',
		'Using prepared notes (unknown if version specific)',
		'USING_PREPARED_NOTES_UNKNOWN_VERSION_SPECIFIC',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Counterfeit/tampered TRF
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('531801cc-286d-4e96-bff5-cb4b463639ad',
		'5728a79a-5785-4bd2-858a-3202236eb4e8',
		'Counterfeit/tampered TRF',
		'COUNTERFEIT_TAMPERED_TRF',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;

--Imposter
INSERT INTO rm_owner.results_status_comment(results_status_comment_uuid, results_status_label_uuid, results_status_comment_text, results_status_comment_code, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('2d132b7e-3880-42f6-831a-e79d5ead9059',
		'5728a79a-5785-4bd2-858a-3202236eb4e8',
		'Imposter',
		'IMPOSTER',
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(results_status_comment_uuid) DO NOTHING;
