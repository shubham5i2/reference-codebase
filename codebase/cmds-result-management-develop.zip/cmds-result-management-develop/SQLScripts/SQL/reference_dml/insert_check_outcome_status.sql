TRUNCATE TABLE rm_owner.check_outcome_status;

INSERT INTO rm_owner.check_outcome_status
(check_outcome_status_uuid, check_outcome_status, check_outcome_status_code, effective_from_date, created_by,updated_by,updated_datetime)
VALUES('dfdf18cf-d77b-4da3-905b-e5d3438f5127', 'Not started', 'CHK_OUT_NOT_STARTED', '2020-07-01','Operations User', NULL, NULL) ON CONFLICT(check_outcome_status_uuid) DO NOTHING;

INSERT INTO rm_owner.check_outcome_status
(check_outcome_status_uuid, check_outcome_status,check_outcome_status_code, effective_from_date, created_by,updated_by,updated_datetime)
VALUES('d957f555-77eb-41ff-a179-902a56ae0273', 'Flagged for review', 'CHK_OUT_REVIEW', '2020-07-01','Operations User', NULL, NULL) ON CONFLICT(check_outcome_status_uuid) DO NOTHING;

INSERT INTO rm_owner.check_outcome_status
(check_outcome_status_uuid, check_outcome_status,check_outcome_status_code, effective_from_date, created_by,updated_by,updated_datetime)
VALUES('52c9a929-724d-4e6c-aa34-d9d979ac0f48', 'Refer', 'CHK_OUT_REFER', '2020-07-01','Operations User', NULL, NULL) ON CONFLICT(check_outcome_status_uuid) DO NOTHING;

INSERT INTO rm_owner.check_outcome_status
(check_outcome_status_uuid, check_outcome_status,check_outcome_status_code, effective_from_date, created_by,updated_by,updated_datetime)
VALUES('ceff8c5a-ee52-489a-8803-7ae6406547ce', 'Cleared', 'CHK_OUT_CLEARED', '2020-07-01','Operations User', NULL, NULL) ON CONFLICT(check_outcome_status_uuid) DO NOTHING;

INSERT INTO rm_owner.check_outcome_status
(check_outcome_status_uuid, check_outcome_status,check_outcome_status_code, effective_from_date, created_by,updated_by,updated_datetime)
VALUES('a75ee32e-48f8-4062-bac7-41e34a5531ae', 'Passed', 'CHK_OUT_PASSED', '2020-07-01','Operations User', NULL, NULL) ON CONFLICT(check_outcome_status_uuid) DO NOTHING;
