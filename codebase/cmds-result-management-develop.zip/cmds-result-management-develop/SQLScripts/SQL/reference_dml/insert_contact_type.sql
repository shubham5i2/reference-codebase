TRUNCATE TABLE rm_owner.contact_type;

--DML scripts contact type
INSERT INTO rm_owner.contact_type( contact_type_uuid, contact_type, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('c3397312-8ea3-453d-871b-68a1ef8c9184',
		'Primary',
		NULL,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(contact_type_uuid) DO NOTHING;


INSERT INTO rm_owner.contact_type( contact_type_uuid, contact_type, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('457a494b-64ca-497f-868f-cc0e5f30a97f',
		'Results Admin',
		NULL,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(contact_type_uuid) DO NOTHING;


INSERT INTO rm_owner.contact_type( contact_type_uuid, contact_type, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('80f4bba7-70b2-4e16-bef4-2ff06c58f620',
		'Partner Contact',
		NULL,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(contact_type_uuid) DO NOTHING;


INSERT INTO rm_owner.contact_type( contact_type_uuid, contact_type, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('d07a3d76-0006-4802-bd47-ee8ece5432ca',
		'Test Centre Manager',
		NULL,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(contact_type_uuid) DO NOTHING;

