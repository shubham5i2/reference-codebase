TRUNCATE TABLE rm_owner.organisation_type;

--DML scripts for organisation type
INSERT INTO rm_owner.organisation_type(
	organisation_type_uuid, organisation_type, description, effective_from_date, created_by, updated_by, updated_datetime)
	VALUES ('e496aa98-86a3-476d-8be3-21ee0aa23c93','RO','Recognising Organisation', '2020-07-01', 'Operations User',NULL,NULL)  ON CONFLICT(organisation_type_uuid) DO NOTHING;

INSERT INTO rm_owner.organisation_type(
	organisation_type_uuid, organisation_type, description, effective_from_date, created_by, updated_by, updated_datetime)
	VALUES ('e392ae7c-016f-433a-bdfa-b79bfcdddf26','VO','Verified Organisation', '2020-07-01', 'Operations User',NULL,NULL)  ON CONFLICT(organisation_type_uuid) DO NOTHING;
	