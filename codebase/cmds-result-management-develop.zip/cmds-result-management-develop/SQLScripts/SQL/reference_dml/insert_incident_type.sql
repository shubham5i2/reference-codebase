TRUNCATE TABLE rm_owner.incident_type;

INSERT INTO rm_owner.incident_type
(incident_type_uuid, incident_category_uuid, incident_description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES('0a896faa-cb43-43ce-8295-48b20373be7a', 'ffc3db8f-6a8e-4923-8e52-d5dabc51328a', 'PRC Outcome', '2020-07-01','Operations User', NULL, NULL) ON CONFLICT(incident_type_uuid) DO NOTHING;