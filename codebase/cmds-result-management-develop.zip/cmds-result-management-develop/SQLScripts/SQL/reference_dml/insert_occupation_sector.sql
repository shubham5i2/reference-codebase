TRUNCATE TABLE rm_owner.occupation_sector;

--DML scripts for occupation sector
INSERT INTO rm_owner.occupation_sector (occupation_sector_uuid, occupation_sector, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('5ad0193f-69b0-45bd-9e8a-ce53e6f8bd24',
        'Other',
        '0',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_sector_uuid) DO NOTHING;


INSERT INTO rm_owner.occupation_sector (occupation_sector_uuid, occupation_sector, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('58c8c007-f5e9-4d98-8ee1-719580f8ecae',
        'Administrative services',
        '1',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_sector_uuid) DO NOTHING;


INSERT INTO rm_owner.occupation_sector (occupation_sector_uuid, occupation_sector, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('b5c24955-1fbd-4b6a-97ad-78bac78b49da',
        'Agriculture, Fishing, Forestry, Mining',
        '2',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_sector_uuid) DO NOTHING;


INSERT INTO rm_owner.occupation_sector (occupation_sector_uuid, occupation_sector, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('9469946e-8a1f-4365-b175-32c455645527',
        'Arts and Entertainment',
        '3',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_sector_uuid) DO NOTHING;


INSERT INTO rm_owner.occupation_sector (occupation_sector_uuid, occupation_sector, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('b610b8b9-4714-4cb5-9a95-ea105206881a',
        'Banking and Finance',
        '4',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_sector_uuid) DO NOTHING;


INSERT INTO rm_owner.occupation_sector (occupation_sector_uuid, occupation_sector, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('e559f6ae-d8c1-4f42-89eb-385ed3cf9ef0',
        'Catering and Leisure',
        '5',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_sector_uuid) DO NOTHING;


INSERT INTO rm_owner.occupation_sector (occupation_sector_uuid, occupation_sector, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('ece6423b-c3b3-4556-ae08-e127fad1ad63',
        'Construction Industries',
        '6',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_sector_uuid) DO NOTHING;


INSERT INTO rm_owner.occupation_sector (occupation_sector_uuid, occupation_sector, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('9beb03f6-4f6d-48ff-8503-9fcdce020860',
        'Craft and Design',
        '7',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_sector_uuid) DO NOTHING;


INSERT INTO rm_owner.occupation_sector (occupation_sector_uuid, occupation_sector, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('72d9fe7c-14fc-487d-8f44-50cb6cf6f2ea',
        'Education',
        '8',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_sector_uuid) DO NOTHING;


INSERT INTO rm_owner.occupation_sector (occupation_sector_uuid, occupation_sector, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('0124af6e-3549-45fd-9b02-d2c4b8b732d8',
        'Health and Social Services',
        '9',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_sector_uuid) DO NOTHING;


INSERT INTO rm_owner.occupation_sector (occupation_sector_uuid, occupation_sector, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('9c825169-d902-4e3e-8b98-6cc629b0f4f5',
        'Installation, Maintenance and Repair Services',
        '10',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_sector_uuid) DO NOTHING;


INSERT INTO rm_owner.occupation_sector (occupation_sector_uuid, occupation_sector, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('a6fc1e69-e083-4f07-a1ce-f480a06a49b3',
        'Law and Legal Services',
        '11',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_sector_uuid) DO NOTHING;


INSERT INTO rm_owner.occupation_sector (occupation_sector_uuid, occupation_sector, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('50ff8654-6001-4f94-8b6f-4f702b0f971b',
        'Manufacturing and Assembly',
        '12',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_sector_uuid) DO NOTHING;


INSERT INTO rm_owner.occupation_sector (occupation_sector_uuid, occupation_sector, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('8108305e-7f57-429e-aa4a-6fd14f37e28a',
        'Personal Services',
        '13',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_sector_uuid) DO NOTHING;


INSERT INTO rm_owner.occupation_sector (occupation_sector_uuid, occupation_sector, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('9801167a-92b6-4d83-84cb-f949d396877a',
        'Retail Trade',
        '14',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_sector_uuid) DO NOTHING;


INSERT INTO rm_owner.occupation_sector (occupation_sector_uuid, occupation_sector, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('9677bf95-4793-4061-91f2-b7298a989898',
        'Technical and Scientific',
        '15',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_sector_uuid) DO NOTHING;


INSERT INTO rm_owner.occupation_sector (occupation_sector_uuid, occupation_sector, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('1ec92890-b3c9-4be3-b962-8f4572b94540',
        'Telecommunications & the Media',
        '16',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_sector_uuid) DO NOTHING;


INSERT INTO rm_owner.occupation_sector (occupation_sector_uuid, occupation_sector, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('247cc5aa-d620-4534-98db-42ee6fac377a',
        'Transport',
        '17',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_sector_uuid) DO NOTHING;


INSERT INTO rm_owner.occupation_sector (occupation_sector_uuid, occupation_sector, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('556cb5ac-e6c7-452d-aef2-f7e3563c8f63',
        'Utilities (gas, water etc )',
        '18',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_sector_uuid) DO NOTHING;


INSERT INTO rm_owner.occupation_sector (occupation_sector_uuid, occupation_sector, legacy_reference, effective_from_date, created_by,updated_by,updated_datetime)
VALUES ('089e8fe0-305d-48f0-aebd-9318268234f1',
        'Wholesale Trade',
        '19',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(occupation_sector_uuid) DO NOTHING;

