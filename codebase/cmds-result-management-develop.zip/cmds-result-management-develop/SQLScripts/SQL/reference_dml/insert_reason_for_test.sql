TRUNCATE TABLE rm_owner.reason_for_test;

--DML scripts for reason for test
INSERT INTO rm_owner.reason_for_test (reason_code_uuid, reason, legacy_reference,created_by, updated_by, updated_datetime)
VALUES ('5163e521-1ec8-4b84-be61-65498cd58dfa',
        'Other',
        '0',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(reason_code_uuid) DO NOTHING;


INSERT INTO rm_owner.reason_for_test (reason_code_uuid, reason, legacy_reference,created_by, updated_by, updated_datetime)
VALUES ('426485c0-302d-4f2b-bec2-a65168c8ed04',
        'For higher education extended course (three months or more)',
        '1',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(reason_code_uuid) DO NOTHING;


INSERT INTO rm_owner.reason_for_test (reason_code_uuid, reason, legacy_reference,created_by, updated_by, updated_datetime)
VALUES ('a41dc6ff-0a21-4dc9-becc-f8db1b5fd7e2',
        'For higher education short course (three months or less)',
        '2',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(reason_code_uuid) DO NOTHING;


INSERT INTO rm_owner.reason_for_test (reason_code_uuid, reason, legacy_reference,created_by, updated_by, updated_datetime)
VALUES ('5db03c10-7c33-4ebb-b8ec-aa634236307a',
        'For other education purposes',
        '3',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(reason_code_uuid) DO NOTHING;


INSERT INTO rm_owner.reason_for_test (reason_code_uuid, reason, legacy_reference,created_by, updated_by, updated_datetime)
VALUES ('854e5951-e8eb-44fa-ac92-0b64183c1806',
        'For registration as a doctor',
        '4',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(reason_code_uuid) DO NOTHING;


INSERT INTO rm_owner.reason_for_test (reason_code_uuid, reason, legacy_reference,created_by, updated_by, updated_datetime)
VALUES ('6ac2066d-d48d-4498-9a6c-2a9e920b2933',
        'For immigration',
        '5',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(reason_code_uuid) DO NOTHING;


INSERT INTO rm_owner.reason_for_test (reason_code_uuid, reason, legacy_reference,created_by, updated_by, updated_datetime)
VALUES ('8a8a62f9-39d1-4a2f-9141-a181148f9fa3',
        'For employment',
        '6',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(reason_code_uuid) DO NOTHING;


INSERT INTO rm_owner.reason_for_test (reason_code_uuid, reason, legacy_reference,created_by, updated_by, updated_datetime)
VALUES ('bcb7e249-e38a-4701-906d-330e0f71efb9',
        'For professional registration (NOT medical)',
        '7',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(reason_code_uuid) DO NOTHING;


INSERT INTO rm_owner.reason_for_test (reason_code_uuid, reason, legacy_reference,created_by, updated_by, updated_datetime)
VALUES ('2eade3b2-b1d8-4e56-b84e-fa0159fb89ae',
        'For personal reasons',
        '8',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(reason_code_uuid) DO NOTHING;


INSERT INTO rm_owner.reason_for_test (reason_code_uuid, reason, legacy_reference, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('4be75c95-d672-46fb-898a-9d897712b1d7',
        'No longer used (Education)',
        'E',
        '2020-01-01',
        '2020-01-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(reason_code_uuid) DO NOTHING;


INSERT INTO rm_owner.reason_for_test (reason_code_uuid, reason, legacy_reference, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('613d620c-30cd-48c7-bbcc-b0ffb8c107cb',
        'No longer used (Private)',
        'P',
        '2020-01-01',
        '2020-01-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(reason_code_uuid) DO NOTHING;


INSERT INTO rm_owner.reason_for_test (reason_code_uuid, reason, legacy_reference, effective_from_date, effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('745778b2-3c9d-4919-8edc-ed74ab6232ce',
        'No longer used (Work)',
        'W',
        '2020-01-01',
        '2020-01-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(reason_code_uuid) DO NOTHING;


INSERT INTO rm_owner.reason_for_test (reason_code_uuid, reason, legacy_reference,created_by, updated_by, updated_datetime)
VALUES ('b021e1e5-f742-4a88-9401-4023b065854c',
        'Missing/Invalid',
        'X',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(reason_code_uuid) DO NOTHING;


INSERT INTO rm_owner.reason_for_test (reason_code_uuid, reason, legacy_reference,created_by, updated_by, updated_datetime)
VALUES ('bef12bdb-6b53-4966-85d1-dc70ef3b4b25',
        'For registration as a nurse (including CGFNS)',
        '9',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(reason_code_uuid) DO NOTHING;


INSERT INTO rm_owner.reason_for_test (reason_code_uuid, reason, legacy_reference,created_by, updated_by, updated_datetime)
VALUES ('b079552f-79d0-49fb-8ff4-069ba51f481f',
        'For registration as a dentist',
        '10',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(reason_code_uuid) DO NOTHING;

