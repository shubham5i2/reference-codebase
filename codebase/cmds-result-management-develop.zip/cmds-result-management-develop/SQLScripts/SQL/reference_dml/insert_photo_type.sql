TRUNCATE TABLE rm_owner.photo_type;

INSERT INTO rm_owner.photo_type(
	photo_type_uuid, photo_type_code, photo_type_description, updated_datetime, concurrency_version, created_by)
	VALUES ('69c06e96-48ae-4b81-afce-7f121cdf9fa3', 'TT_ID_HR_R', 'TT Identity document - Registration Uploaded to ORS by TT at time of registration', NULL, '1', 'Operations User');


INSERT INTO rm_owner.photo_type(
	photo_type_uuid, photo_type_code, photo_type_description, updated_datetime, concurrency_version, created_by)
	VALUES ('34a7a10a-09ae-4247-992e-85ca0182b57e', 'TT_P_HR_R', 'TT Profile High Res Registration (Future) - Uploaded to ORS by TT at time of registration', NULL, '1', 'Operations User');


INSERT INTO rm_owner.photo_type(
	photo_type_uuid, photo_type_code, photo_type_description, updated_datetime, concurrency_version, created_by)
	VALUES ('a8663e0b-0e17-477a-8b8d-4f1b5ddbee2a', 'TT_P_LR_IAM', 'TT Profile Low-Res - In-Centre Captured by IAM on Test Day - for In-Centre test only', NULL, '1', 'Operations User');


INSERT INTO rm_owner.photo_type(
	photo_type_uuid, photo_type_code, photo_type_description, updated_datetime, concurrency_version, created_by)
	VALUES ('a101702b-d8dd-4bcd-bcc5-a39cc6cf6fc5', 'TT_P_HR_IAM', 'TT Profile High-Res - In-Centre Captured by IAM on Test Day - for In-Centre test only Only provided to CMDS on request for Investigation purposes', NULL, '1', 'Operations User');


INSERT INTO rm_owner.photo_type(
	photo_type_uuid, photo_type_code, photo_type_description, updated_datetime, concurrency_version, created_by)
	VALUES ('f6c594bb-6dc3-438b-8e94-c87edaa47cd6', 'TT_P_LR_LRW_WC', 'TT Profile Low-Res - LRW - Web-Cam TT Web-cam for IaH LRW test only', NULL, '1', 'Operations User');


INSERT INTO rm_owner.photo_type(
	photo_type_uuid, photo_type_code, photo_type_description, updated_datetime, concurrency_version, created_by)
	VALUES ('bb275ded-e945-4588-b137-18e554bb1ce8', 'TT_P_LR_S_WC', 'TT Profile Low-Res - Speaking - Web-Cam TT Web-cam for IaH Speaking test only', NULL, '1', 'Operations User');


INSERT INTO rm_owner.photo_type(
	photo_type_uuid, photo_type_code, photo_type_description, updated_datetime, concurrency_version, created_by)
	VALUES ('d2918fba-887a-4373-b06d-e88e110ed19b', 'TT_ID_LRW_WC', 'TT Identity document - LRW - Web-Cam TT Web-cam for IaH LRW test only', NULL, '1', 'Operations User');


INSERT INTO rm_owner.photo_type(
	photo_type_uuid, photo_type_code, photo_type_description, updated_datetime, concurrency_version, created_by)
	VALUES ('1050fc8a-0fe8-4395-94db-e76cb047104a', 'TT_ID_S_WC', 'TT Identity document - Speaking- Web-Cam TT Web-cam for IaH Speaking test only', NULL, '1', 'Operations User');