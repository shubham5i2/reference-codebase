TRUNCATE TABLE rm_owner.incident_category CASCADE;

INSERT INTO rm_owner.incident_category
(incident_category_uuid, incident_category, incident_category_code, effective_from_date, created_by, updated_by, updated_datetime)
VALUES('0b604881-366b-43a1-b912-b565cd4f5d55', 'Speaking Incident', 'SPK_INC', '2020-07-01','Operations User', NULL, NULL) ON CONFLICT(incident_category_uuid) DO NOTHING;

INSERT INTO rm_owner.incident_category
(incident_category_uuid, incident_category, incident_category_code, effective_from_date, created_by, updated_by, updated_datetime)
VALUES('abe50b75-3829-4a81-8ebc-355e89eeefbc', 'LRW Incident', 'LRW_INC', '2020-07-01','Operations User', NULL, NULL) ON CONFLICT(incident_category_uuid) DO NOTHING;

INSERT INTO rm_owner.incident_category
(incident_category_uuid, incident_category, incident_category_code, effective_from_date, created_by, updated_by, updated_datetime)
VALUES('e89eecc9-a0e2-4642-b682-eff0a28ab8c5', 'Proctoring Incident', 'PROC_INC', '2020-07-01','Operations User', NULL, NULL) ON CONFLICT(incident_category_uuid) DO NOTHING;

INSERT INTO rm_owner.incident_category
(incident_category_uuid, incident_category, incident_category_code, effective_from_date, created_by, updated_by, updated_datetime)
VALUES('ffc3db8f-6a8e-4923-8e52-d5dabc51328a', 'PRC Outcome', 'PRC_OUT_INC', '2020-07-01','Operations User', NULL, NULL) ON CONFLICT(incident_category_uuid) DO NOTHING;

INSERT INTO rm_owner.incident_category
(incident_category_uuid, incident_category, incident_category_code, effective_from_date, created_by, updated_by, updated_datetime)
VALUES('0e5567b0-30ac-4518-b245-6093f3bc24b0', 'Plagiarism', 'PLG_INC', '2020-07-01','Operations User', NULL, NULL) ON CONFLICT(incident_category_uuid) DO NOTHING;

INSERT INTO rm_owner.incident_category
(incident_category_uuid, incident_category, incident_category_code, effective_from_date, created_by, updated_by, updated_datetime)
VALUES('29b6aa56-8316-44d9-80d0-d5010a0a8518', 'Probable Banned Candidate', 'PROB_BANNED_INC', '2020-07-01','Operations User', NULL, NULL) ON CONFLICT(incident_category_uuid) DO NOTHING;

INSERT INTO rm_owner.incident_category
(incident_category_uuid, incident_category, incident_category_code, effective_from_date, created_by, updated_by, updated_datetime)
VALUES('612b3bb0-0524-4e80-85bc-c4e28d4867cd', 'ID Check', 'ID_CHK_INC', '2020-07-01','Operations User', NULL, NULL) ON CONFLICT(incident_category_uuid) DO NOTHING;