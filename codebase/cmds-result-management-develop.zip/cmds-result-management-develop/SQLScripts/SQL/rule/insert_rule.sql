TRUNCATE TABLE rm_owner.rule;

-- null to UNCONFIRMED

INSERT INTO rm_owner.rule(rule_id, from_status_uuid, from_status_label_uuid, to_status_uuid, to_status_label_uuid, to_status_comment_uuid, trigger_type, additional_checks, permission_id)
VALUES( 'R1',
								NULL,
								NULL,
								'3d189282-e531-47f2-aa22-d24eef1d20b6',
								NULL,
								NULL,
								'AUTO',
								'BOOKING_PRESENT',
								NULL);

-- UNCONFIRMED to CONFIRMED

INSERT INTO rm_owner.rule(rule_id, from_status_uuid, from_status_label_uuid, to_status_uuid, to_status_label_uuid, to_status_comment_uuid, trigger_type, additional_checks, permission_id)
VALUES( 'R2',
								'3d189282-e531-47f2-aa22-d24eef1d20b6',
								NULL,
								'27c03460-2662-4a63-b1aa-6d158b85c0a5',
								NULL,
								NULL,
								'AUTO',
								'BOOKING_PRESENT,FINAL_RESULT_PRESENT',
								NULL);

-- CONFIRMED to PENDING_REVIEW

INSERT INTO rm_owner.rule(rule_id, from_status_uuid, from_status_label_uuid, to_status_uuid, to_status_label_uuid, to_status_comment_uuid, trigger_type, additional_checks, permission_id)
VALUES( 'R3',
								'27c03460-2662-4a63-b1aa-6d158b85c0a5',
								NULL,
								'19bdb4b7-74bc-4f3d-b846-eb4a4e8022e6',
								NULL,
								NULL,
								'AUTO',
								'BOOKING_PRESENT,FINAL_RESULT_PRESENT,PRC_OUTCOME_FLAGGED_FOR_REVIEW',
								NULL);

-- CONFIRMED to VALIDATED

INSERT INTO rm_owner.rule(rule_id, from_status_uuid, from_status_label_uuid, to_status_uuid, to_status_label_uuid, to_status_comment_uuid, trigger_type, additional_checks, permission_id)
VALUES( 'R4',
								'27c03460-2662-4a63-b1aa-6d158b85c0a5',
								NULL,
								'ac65e5b7-3bcc-4147-baff-827f030dc6c8',
								NULL,
								NULL,
								'AUTO',
								'BOOKING_PRESENT,FINAL_RESULT_PRESENT,PRC_OUTCOME_PASSED',
								NULL);

-- PENDING_REVIEW to VALIDATED

INSERT INTO rm_owner.rule(rule_id, from_status_uuid, from_status_label_uuid, to_status_uuid, to_status_label_uuid, to_status_comment_uuid, trigger_type, additional_checks, permission_id)
VALUES( 'R5',
								'19bdb4b7-74bc-4f3d-b846-eb4a4e8022e6',
								NULL,
								'ac65e5b7-3bcc-4147-baff-827f030dc6c8',
								NULL,
								NULL,
								'AUTO',
								'BOOKING_PRESENT,FINAL_RESULT_PRESENT,PRC_OUTCOME_CLEARED',
								NULL);

-- PENDING_REVIEW to WITHHELD (PRC_INVESTIGATION)

INSERT INTO rm_owner.rule(rule_id, from_status_uuid, from_status_label_uuid, to_status_uuid, to_status_label_uuid, to_status_comment_uuid, trigger_type, additional_checks, permission_id)
VALUES( 'R6',
								'19bdb4b7-74bc-4f3d-b846-eb4a4e8022e6',
								NULL,
								'735d2d71-b4a9-47ec-b566-34b2d3015540',
								'52a50291-bd70-4989-9fce-584b0aa3cc65',
								NULL,
								'AUTO',
								'BOOKING_PRESENT,FINAL_RESULT_PRESENT,PRC_OUTCOME_REFER',
								NULL);

-- WITHHELD (PRC_INVESTIGATION) to VALIDATED

INSERT INTO rm_owner.rule(rule_id, from_status_uuid, from_status_label_uuid, to_status_uuid, to_status_label_uuid, to_status_comment_uuid, trigger_type, additional_checks, permission_id)
VALUES( 'R7',
								'735d2d71-b4a9-47ec-b566-34b2d3015540',
								'52a50291-bd70-4989-9fce-584b0aa3cc65',
								'ac65e5b7-3bcc-4147-baff-827f030dc6c8',
								NULL,
								NULL,
								'AUTO',
								'BOOKING_PRESENT,FINAL_RESULT_PRESENT,PRC_OUTCOME_CLEARED',
								NULL);