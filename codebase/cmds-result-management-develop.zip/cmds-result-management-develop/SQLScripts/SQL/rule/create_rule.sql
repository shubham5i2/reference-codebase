-- Create ENUM Type for trigger_type
DO $$ BEGIN CREATE TYPE rm_owner.trigger_type AS ENUM (
    'MANUAL',
    'AUTO'
    );
EXCEPTION
WHEN duplicate_object THEN null;
END $$;

DROP TABLE IF EXISTS rm_owner.rule;

CREATE TABLE rm_owner.rule (
	rule_id varchar(10) NOT NULL,
	from_status_uuid uuid NULL,
	from_status_label_uuid uuid NULL,
	to_status_uuid uuid NOT NULL,
	to_status_label_uuid uuid NULL,
	to_status_comment_uuid uuid NULL,
	trigger_type rm_owner."trigger_type" NOT NULL,
	additional_checks varchar(150) NULL,
	permission_id VARCHAR(50) NULL,
	created_by varchar(36) NOT NULL DEFAULT 'Operations User', 
	created_datetime timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP, 
	updated_by varchar(36),
	updated_datetime timestamptz,
	concurrency_version INTEGER NOT NULL DEFAULT 0,
	CONSTRAINT pk_rule PRIMARY KEY (rule_id)
    );
