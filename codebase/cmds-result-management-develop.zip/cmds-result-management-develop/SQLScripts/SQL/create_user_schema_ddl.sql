--Create schema for rm database
CREATE SCHEMA IF NOT EXISTS rm_owner AUTHORIZATION postgres;

-- Revoke privileges from 'public' role
REVOKE CREATE ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON DATABASE rm FROM PUBLIC;

-- Create role rm_rw_role
DO $$
BEGIN
  CREATE ROLE rm_rw_role WITH
  NOLOGIN
  NOSUPERUSER
  INHERIT
  NOCREATEDB
  NOCREATEROLE
  NOREPLICATION;
  EXCEPTION WHEN DUPLICATE_OBJECT THEN
  RAISE NOTICE 'Role rm_rw_role already exists';
END
$$;

-- Create user rm_user and grant rm_rw_role to this user   
DO $$
BEGIN
CREATE USER rm_user WITH
	LOGIN
	NOSUPERUSER
	NOCREATEDB
	NOCREATEROLE
	INHERIT
	NOREPLICATION
	CONNECTION LIMIT -1
	PASSWORD 'rm_user';
  EXCEPTION WHEN DUPLICATE_OBJECT THEN
  RAISE NOTICE 'User rm_user already exists';
END
$$;
    
GRANT CONNECT ON DATABASE rm TO rm_rw_role;
GRANT USAGE ON SCHEMA rm_owner TO rm_user;	
ALTER DEFAULT PRIVILEGES IN SCHEMA rm_owner GRANT INSERT, SELECT, UPDATE ON TABLES TO rm_rw_role;
GRANT rm_rw_role TO rm_user;


