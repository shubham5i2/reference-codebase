-- IELTS RM Microservice SQL scripts

\c rm
\i set_client_encoding.sql
\i create_user_schema_ddl.sql
\i add_uuid_extension.sql
-- Where is this? \i update_cefr_level.sql

--Reference DDL scripts
\ir  reference_ddl//create_access_arrangement.sql
\ir  reference_ddl//create_address_type.sql
\ir  reference_ddl//create_allocation_group.sql
\ir  reference_ddl//create_country.sql
\ir  reference_ddl//create_contact_type.sql
\ir  reference_ddl//create_education_level.sql
\ir  reference_ddl//create_gender.sql
\ir  reference_ddl//create_identification_type.sql
\ir  reference_ddl//create_language.sql
\ir  reference_ddl//create_mark_criteria.sql
\ir  reference_ddl//create_module_type.sql
\ir  reference_ddl//create_nationality.sql
\ir  reference_ddl//create_note_type.sql
\ir  reference_ddl//create_occupation_level.sql
\ir  reference_ddl//create_occupation_sector.sql
\ir  reference_ddl//create_organisation_type.sql
\ir  reference_ddl//create_partner.sql
\ir  reference_ddl//create_reason_for_test.sql
\ir  reference_ddl//create_sector_type.sql
\ir  reference_ddl//create_territory.sql
\ir  reference_ddl//create_results_status_type.sql
\ir  reference_ddl//create_results_status_label.sql
\ir  reference_ddl//create_results_status_comment.sql

-- Product DDL scripts
\ir  product_ddl//create_product.sql

-- Location DDL scripts
\ir  location_ddl//create_location.sql

-- Booking DDL scripts
\ir  booking//create_unique_test_taker.sql
\ir  booking//create_booking.sql
\ir  booking//create_booking_line.sql
\ir  booking//create_unique_test_taker_identity.sql

--Prc DDL scripts
\ir prc//create_prc_outcome_details.sql
\ir prc//create_prc_repeater_analysis.sql
\ir prc//create_prc_probability_analysis.sql

-- Results DDL scripts
\ir  results//create_result_type.sql -- Move to reference folder later
\ir  results//create_result.sql
\ir  results//create_result_line.sql
\ir  results//create_release_status_history.sql
\ir  results//create_results_status_history.sql
\ir  results//insert_result_type.sql
-- where is this??\ir  results//alter_table_result_cerf_level.sql

--Evaluation DDL scripts
\ir  evaluation//create_question.sql
\ir  evaluation//create_evaluation_round.sql
\ir  evaluation//create_evaluation_round_question.sql 
\ir  evaluation//create_evaluation.sql
\ir  evaluation//create_mark.sql
\ir  evaluation//create_evaluation_round_total_score.sql

--Evaluation history DDL scripts
\ir  evaluation//create_evaluation_round_history.sql
\ir  evaluation//create_evaluation_history.sql
\ir  evaluation//create_mark_history.sql

--RBAC DDL Scripts
\ir  rbac_ddl//create_user_group_hierarchy.sql

--Reference DML scripts
\ir  reference_dml//insert_address_type.sql
\ir  reference_dml//insert_contact_type.sql
\ir  reference_dml//insert_country.sql
\ir  reference_dml//insert_education_level.sql
\ir  reference_dml//insert_gender.sql
\ir  reference_dml//insert_identification_type.sql
\ir  reference_dml//insert_language.sql
\ir  reference_dml//insert_mark_criteria.sql
\ir  reference_dml//insert_module_type.sql
\ir  reference_dml//insert_nationality.sql
\ir  reference_dml//insert_note_type.sql
\ir  reference_dml//insert_occupation_level.sql
\ir  reference_dml//insert_occupation_sector.sql
\ir  reference_dml//insert_organisation_type.sql
\ir  reference_dml//insert_partner.sql
\ir  reference_dml//insert_reason_for_test.sql
\ir  reference_dml//insert_sector_type.sql
\ir  reference_dml//insert_territory.sql
\ir  reference_dml//insert_results_status_type.sql
--\ir  reference_dml//insert_result_type.sql Mismatch between columns in LPR & RM. RM's copy is present in results folder
\ir  reference_dml//insert_results_status_label.sql
\ir  reference_dml//insert_results_status_comment.sql

--Product DML scripts
\ir  product_dml//insert_product.sql

--RBAC DML Scripts
\ir  rbac_dml//insert_user_group_hierarchy.sql
