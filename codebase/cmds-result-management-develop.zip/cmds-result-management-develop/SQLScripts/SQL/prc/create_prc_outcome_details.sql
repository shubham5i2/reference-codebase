-- Create EMUM Type for prc_outcome_details types
DO $$ BEGIN CREATE TYPE rm_owner.prc_outcome_details_type AS ENUM (
    'HOLD',
    'PROCESSED'
);
EXCEPTION
WHEN duplicate_object THEN null;
END $$;

-- Create Table for prc_outcome_details
CREATE TABLE IF NOT EXISTS rm_owner.prc_outcome_details(
    prc_outcome_details_uuid uuid NOT NULL,	
    unique_test_taker_id varchar(14) NOT NULL,
    external_test_id integer NOT NULL,
    booking_uuid uuid NOT NULL,
    prc_outcome_details_received_datetime timestamptz NOT NULL,
    action_taken_status rm_owner.prc_outcome_details_type NOT NULL,
    created_by VARCHAR(36) NOT NULL,
    created_datetime TIMESTAMPTZ NOT NULL,
    updated_by VARCHAR(36) NULL,
    updated_datetime TIMESTAMPTZ NULL,
    concurrency_version integer NOT NULL, 
    CONSTRAINT pk_prc_outcome_details PRIMARY KEY (prc_outcome_details_uuid),
    CONSTRAINT uk_01_unique_test_taker_booking UNIQUE (booking_uuid, unique_test_taker_id)
);
    
-- Comments on prc_outcome_details table and columns
COMMENT ON TABLE rm_owner.prc_outcome_details IS 'Represents a result of Pre-Release Checks - A series of checks performed by Validation on the marks ready for issue to check for potential cheating and test performances measuring.';
COMMENT ON COLUMN rm_owner.prc_outcome_details.prc_outcome_details_uuid IS 'Prc Outcome Details UUID to uniquely identify a record in prc_outcome';
COMMENT ON COLUMN rm_owner.prc_outcome_details.unique_test_taker_id IS 'Column to hold Unique Test Taker IDs';
COMMENT ON COLUMN rm_owner.prc_outcome_details.external_test_id IS 'Column to hold external test IDs';
COMMENT ON COLUMN rm_owner.prc_outcome_details.booking_uuid IS 'Booking UUID reference associated with prc_outcome_details table';
COMMENT ON COLUMN rm_owner.prc_outcome_details.prc_outcome_details_received_datetime IS 'Column to hold received datetime';
COMMENT ON COLUMN rm_owner.prc_outcome_details.action_taken_status IS 'Column to hold PRC Outcome is received before final result is received.PROCESSED  PRC Outcome is applied to the result after  final result is received.';
COMMENT ON COLUMN rm_owner.prc_outcome_details.created_by IS 'Column to hold the user who created the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.prc_outcome_details.created_datetime IS 'Column to hold the time at which the record was created. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.prc_outcome_details.updated_by IS 'Column to hold the user who updated the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.prc_outcome_details.updated_datetime IS 'Column to hold the time at which the record was updated. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.prc_outcome_details.concurrency_version IS 'Column to hold version details so as to ensure that there is only one update at a time.'
