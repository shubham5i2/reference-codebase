-- Create EMUM Type for prc_repeater_analysis types
DO $$ BEGIN CREATE TYPE rm_owner.prc_repeater_analysis_type AS ENUM (
     'L+R',
     'W+S'
);
EXCEPTION
WHEN duplicate_object THEN null;
END $$;

-- Create Table for prc_repeater_analysis
CREATE TABLE IF NOT EXISTS rm_owner.prc_repeater_analysis(
    prc_repeater_analysis_uuid uuid NOT NULL,
    prc_outcome_details_uuid uuid NOT NULL,
    flagged_for rm_owner.prc_repeater_analysis_type NOT NULL,
    reading_bandscore_jump NUMERIC(2,1) NULL,
    writing_bandscore_jump NUMERIC(2,1) NULL,
    speaking_bandscore_jump NUMERIC(2,1) NULL,
    listening_bandscore_jump NUMERIC(2,1) NULL,
    overall_bandscore_jump NUMERIC(2,1) NULL,
    weight smallint NULL,
    created_by VARCHAR(36) NOT NULL,
    created_datetime TIMESTAMPTZ NOT NULL,
    updated_by VARCHAR(36) NULL,
    updated_datetime TIMESTAMPTZ NULL,
    concurrency_version integer NOT NULL,
    CONSTRAINT pk_prc_repeater_analysis PRIMARY KEY (prc_repeater_analysis_uuid),
    CONSTRAINT fk_01_prc_repeater_analysis_prc_outcome_details FOREIGN KEY (prc_outcome_details_uuid) REFERENCES rm_owner.prc_outcome_details (prc_outcome_details_uuid)
);
    
-- Comments on prc_repeater_analysis table and columns
COMMENT ON TABLE rm_owner.prc_repeater_analysis IS 'A part of the PRC Outcome Details. Represents the outcome of repeaters analysis indicating if the Test Taker was flagged by repeater analysis performed.';
COMMENT ON COLUMN rm_owner.prc_repeater_analysis.prc_repeater_analysis_uuid IS 'Prc Repeater Analysis UUID to uniquely identify a record in prc_repeater_analysis';
COMMENT ON COLUMN rm_owner.prc_repeater_analysis.prc_outcome_details_uuid IS 'Prc Outcome Details UUID refrence associated with prc_repeater_analysis';
COMMENT ON COLUMN rm_owner.prc_repeater_analysis.flagged_for IS 'Column to hold flagged information of prc_repeater_analysis';
COMMENT ON COLUMN rm_owner.prc_repeater_analysis.reading_bandscore_jump IS 'Column to hold Reading Bandscore Jump ';
COMMENT ON COLUMN rm_owner.prc_repeater_analysis.writing_bandscore_jump IS 'Column to hold Writing Bandscore Jump';
COMMENT ON COLUMN rm_owner.prc_repeater_analysis.speaking_bandscore_jump IS 'Column to hold Speaking Bandscore Jump';
COMMENT ON COLUMN rm_owner.prc_repeater_analysis.listening_bandscore_jump IS 'Column to hold Listening Bandscore Jump';
COMMENT ON COLUMN rm_owner.prc_repeater_analysis.overall_bandscore_jump IS 'Column to hold overall bandscore';
COMMENT ON COLUMN rm_owner.prc_repeater_analysis.weight IS 'Column to hold weight';
COMMENT ON COLUMN rm_owner.prc_repeater_analysis.created_by IS 'Column to hold the user who created the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.prc_repeater_analysis.created_datetime IS 'Column to hold the time at which the record was created. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.prc_repeater_analysis.updated_by IS 'Column to hold the user who updated the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.prc_repeater_analysis.updated_datetime IS 'Column to hold the time at which the record was updated. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.prc_repeater_analysis.concurrency_version IS 'Column to hold version details so as to ensure that there is only one update at a time.';