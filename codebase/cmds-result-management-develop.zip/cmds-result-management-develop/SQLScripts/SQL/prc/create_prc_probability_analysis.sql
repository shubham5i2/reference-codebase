-- Create Table for prc_probability_analysis
CREATE TABLE IF NOT EXISTS rm_owner.prc_probability_analysis(
    prc_probability_analysis_uuid uuid NOT NULL,
    prc_outcome_details_uuid uuid NOT NULL,
    global_flag boolean NOT NULL,
    candidate_mean_judgmental NUMERIC(20,1) NULL,
    reading_bandscore_flag varchar(100) NULL,
    reading_bandscore_countryreg NUMERIC(20,1) NULL,
    reading_bandscore_residual NUMERIC(20,1) NULL,
    reading_bandscore_stdresidual NUMERIC(20,1) NULL,
    listening_bandscore_flag varchar(100) NULL,
    listening_bandscore_countryreg NUMERIC(20,1) NULL,
    listening_bandscore_residual NUMERIC(20,1) NULL,
    listening_bandscore_stdresidual NUMERIC(20,1) NULL,
    created_by varchar(36) NOT NULL,
    created_datetime TIMESTAMPTZ NOT NULL,
    updated_by VARCHAR(36) NULL,
    updated_datetime TIMESTAMPTZ NULL,
    concurrency_version integer NOT NULL,
    CONSTRAINT pk_prc_probability_analysis PRIMARY KEY (prc_probability_analysis_uuid),
    CONSTRAINT fk_01_prc_probability_analysis_prc_outcome_details FOREIGN KEY (prc_outcome_details_uuid) REFERENCES rm_owner.prc_outcome_details (prc_outcome_details_uuid)
);
    
-- Comments on prc_probability_analysis table and columns
COMMENT ON TABLE rm_owner.prc_probability_analysis IS 'A part of the PRC Outcome Details. Represents the outcome of probability analysis indicating if the Test Taker was flagged by probability analysis performed.';
COMMENT ON COLUMN rm_owner.prc_probability_analysis.prc_probability_analysis_uuid IS 'Prc Probability Analysis UUID to uniquely identify a record in prc_probability_analysis';
COMMENT ON COLUMN rm_owner.prc_probability_analysis.prc_outcome_details_uuid IS 'Prc Outcome Details UUID refrence associated with prc_probability_analysis';
COMMENT ON COLUMN rm_owner.prc_probability_analysis.global_flag IS 'Column to hold global flag';
COMMENT ON COLUMN rm_owner.prc_probability_analysis.candidate_mean_judgmental IS 'Column to hold candidate mean judgmental';
COMMENT ON COLUMN rm_owner.prc_probability_analysis.reading_bandscore_flag IS 'Column to hold Reading Bandscore Flag';
COMMENT ON COLUMN rm_owner.prc_probability_analysis.reading_bandscore_countryreg IS 'Column to hold Reading Bandscore Countryreg';
COMMENT ON COLUMN rm_owner.prc_probability_analysis.reading_bandscore_residual IS 'Column to hold Reading Bandscore Residual';
COMMENT ON COLUMN rm_owner.prc_probability_analysis.reading_bandscore_stdresidual IS 'Column to hold Reading Bandscore Stdresidual ';
COMMENT ON COLUMN rm_owner.prc_probability_analysis.listening_bandscore_flag IS 'Column to hold Listening Bandscore Flag';
COMMENT ON COLUMN rm_owner.prc_probability_analysis.listening_bandscore_countryreg IS 'Column to hold Listening Bandscore Countryreg';
COMMENT ON COLUMN rm_owner.prc_probability_analysis.listening_bandscore_residual IS 'Column to hold Listening Bandscore Residual';
COMMENT ON COLUMN rm_owner.prc_probability_analysis.listening_bandscore_stdresidual IS 'Column to holds Listening Bandscore Stdresidual';
COMMENT ON COLUMN rm_owner.prc_probability_analysis.created_by IS 'Column to hold the user who created the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.prc_probability_analysis.created_datetime IS 'Column to hold the time at which the record was created. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.prc_probability_analysis.updated_by IS 'Column to hold the user who updated the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.prc_probability_analysis.updated_datetime IS 'Column to hold the time at which the record was updated. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.prc_probability_analysis.concurrency_version IS 'Column to hold version details so as to ensure that there is only one update at a time.';