-- Create Table unique_test_taker_identity
CREATE TABLE IF NOT EXISTS rm_owner.unique_test_taker_identity(
    unique_test_taker_identity_uuid uuid NOT NULL,
    unique_test_taker_uuid uuid NOT NULL,
    identity_number varchar(100) NOT NULL,
    identity_type_uuid uuid NOT NULL,
    identity_issuing_auth varchar(100) NULL,
    identity_expiry_date date NULL,
    created_by varchar(36) NOT NULL,
    created_datetime timestamptz NOT NULL,
    updated_by varchar(36) NULL,
    updated_datetime timestamptz NULL,
    concurrency_version integer NOT NULL,
    CONSTRAINT pk_unique_test_taker_identity PRIMARY KEY (unique_test_taker_identity_uuid),
    CONSTRAINT fk_01_unique_test_taker_identity_unique_test_taker FOREIGN KEY (unique_test_taker_uuid) REFERENCES rm_owner.unique_test_taker (unique_test_taker_uuid)
);

-- Comments on unique_testtaker_identity table and columns
COMMENT ON TABLE rm_owner.unique_test_taker_identity IS 'Table to Represents a set of attributes used to establish Test Taker identity.';
COMMENT ON COLUMN rm_owner.unique_test_taker_identity.unique_test_taker_identity_uuid IS 'Unique Testtaker Identity UUID to uniquely identify a record in unique_test_taker_identity';
COMMENT ON COLUMN rm_owner.unique_test_taker_identity.unique_test_taker_uuid IS 'Unique Test Taker UUID refrence associated with unique_test_taker_identity';
COMMENT ON COLUMN rm_owner.unique_test_taker_identity.identity_number IS 'Column to hold Identity number of the test taker';
COMMENT ON COLUMN rm_owner.unique_test_taker_identity.identity_type_uuid IS 'Column to hold identity_type_uuid reference associated with identity_type table';
COMMENT ON COLUMN rm_owner.unique_test_taker_identity.identity_issuing_auth IS 'Column to hold identity issuing authority details';
COMMENT ON COLUMN rm_owner.unique_test_taker_identity.identity_expiry_date IS 'Column to hold expiry date of identity';
COMMENT ON COLUMN rm_owner.unique_test_taker_identity.created_by IS 'Column to hold the user who created the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.unique_test_taker_identity.created_datetime IS 'Column to hold the time at which the record was created. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.unique_test_taker_identity.updated_by IS 'Column to hold the user who updated the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.unique_test_taker_identity.updated_datetime IS 'Column to hold the time at which the record was updated. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.unique_test_taker_identity.concurrency_version IS 'Column to hold version details so as to ensure that there is only one update at a time.';