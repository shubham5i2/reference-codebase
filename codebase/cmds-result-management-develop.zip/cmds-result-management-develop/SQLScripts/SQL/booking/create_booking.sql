-- Create Table for booking
CREATE TABLE IF NOT EXISTS rm_owner.booking (
    booking_uuid uuid NOT NULL,
    unique_test_taker_uuid uuid NOT NULL,
    test_date date NOT NULL,
    partner_code varchar(20) NOT NULL,
    financial_year integer NOT NULL,
    location_uuid uuid  NOT NULL,
    product_uuid uuid  NOT NULL,
    created_by VARCHAR(36) NOT NULL,
    created_datetime TIMESTAMPTZ NOT NULL,
    updated_by VARCHAR(36) NULL,
    updated_datetime TIMESTAMPTZ NULL,
    concurrency_version integer NOT NULL,
    CONSTRAINT pk_booking PRIMARY KEY (booking_uuid),
    CONSTRAINT fk_01_booking_unique_test_taker FOREIGN KEY (unique_test_taker_uuid) REFERENCES rm_owner.unique_test_taker (unique_test_taker_uuid)
);

-- Comments on booking table and columns
COMMENT ON TABLE rm_owner.booking IS 'Table to hold booking details';
COMMENT ON COLUMN rm_owner.booking.booking_uuid IS 'Booking Line UUID to uniquely identify a record in booking.';
COMMENT ON COLUMN rm_owner.booking.unique_test_taker_uuid IS 'Unique Test Taker UUID reference associated with the booking';
COMMENT ON COLUMN rm_owner.booking.test_date IS 'Column to hold date of test';
COMMENT ON COLUMN rm_owner.booking.partner_code IS 'Column to hold partner code detail for booking.';
COMMENT ON COLUMN rm_owner.booking.financial_year IS 'Financial year based on the test date ';
COMMENT ON COLUMN rm_owner.booking.location_uuid IS 'Location UUID for which the booking is made.';
COMMENT ON COLUMN rm_owner.booking.product_uuid IS 'product UUID for which the booking is made.';
COMMENT ON COLUMN rm_owner.booking.created_by IS 'Column to hold the user who created the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.booking.created_datetime IS 'Column to hold the time at which the record was created. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.booking.updated_by IS 'Column to hold the user who updated the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.booking.updated_datetime IS 'Column to hold the time at which the record was updated. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.booking.concurrency_version IS 'Column to hold version details so as to ensure that there is only one update at a time.';
