-- Create Table for unique_test_taker
CREATE TABLE IF NOT EXISTS rm_owner.unique_test_taker(
	unique_test_taker_uuid uuid NOT NULL,
	unique_test_taker_id varchar(14) NOT NULL,
	short_candidate_number varchar(6) NOT NULL,
	birth_date date NOT NULL,
	title varchar(12) NULL,
	first_name varchar(100) NULL,
	last_name varchar(100) NULL,
	nationality_uuid uuid NULL,
	nationality_other varchar(100) NULL,
	created_by varchar(36) NOT NULL,
	created_datetime timestamptz NOT NULL,
	updated_by varchar(36) NULL,
	updated_datetime timestamptz NULL,
	concurrency_version integer NOT NULL,
	CONSTRAINT pk_unique_test_taker PRIMARY KEY (unique_test_taker_uuid)
);

-- Comments on unique_test_taker table and columns
COMMENT ON TABLE rm_owner.unique_test_taker IS 'Table to hold unique test taker detail';
COMMENT ON COLUMN rm_owner.unique_test_taker.unique_test_taker_uuid IS 'Unique Test Taker UUID to uniquely identify a record in unique_test_taker';
COMMENT ON COLUMN rm_owner.unique_test_taker.unique_test_taker_id IS 'Column to hold  human readable unique TestTaker IDs';
COMMENT ON COLUMN rm_owner.unique_test_taker.short_candidate_number IS 'Column to hold candidate number';
COMMENT ON COLUMN rm_owner.unique_test_taker.birth_date IS 'Column to hold the date of birth of the test taker';
COMMENT ON COLUMN rm_owner.unique_test_taker.title IS 'Column to hold the title of the test taker';
COMMENT ON COLUMN rm_owner.unique_test_taker.first_name IS 'Column to hold First name of the test taker';
COMMENT ON COLUMN rm_owner.unique_test_taker.last_name IS 'Column to hold Last name of the test taker';
COMMENT ON COLUMN rm_owner.unique_test_taker.nationality_uuid IS 'Nationality UUID reference associated with nationality';
COMMENT ON COLUMN rm_owner.unique_test_taker.nationality_other IS 'Column to hold other nationality of test taker';
COMMENT ON COLUMN rm_owner.unique_test_taker.created_by IS 'Column to hold the user who created the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.unique_test_taker.created_datetime IS 'Column to hold the time at which the record was created. This is used for audit 
purposes.';
COMMENT ON COLUMN rm_owner.unique_test_taker.updated_by IS 'Column to hold the user who updated the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.unique_test_taker.updated_datetime IS 'Column to hold the time at which the record was updated. This is used for audit 
purposes.';
COMMENT ON COLUMN rm_owner.unique_test_taker.concurrency_version IS 'Column to hold version details so as to ensure that there is only one update at 
a time.';

