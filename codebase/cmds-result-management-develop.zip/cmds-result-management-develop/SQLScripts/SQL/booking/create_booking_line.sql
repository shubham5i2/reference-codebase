-- Create Table for booking_line
CREATE TABLE IF NOT EXISTS rm_owner.booking_line (
    booking_line_uuid uuid NOT NULL,
    booking_uuid uuid NOT NULL,
	product_uuid uuid NULL,
    created_by VARCHAR(36) NOT NULL,
    created_datetime TIMESTAMPTZ NOT NULL,
    updated_by VARCHAR(36) NULL,
    updated_datetime TIMESTAMPTZ NULL,
    concurrency_version integer NOT NULL,
    CONSTRAINT pk_booking_line PRIMARY KEY (booking_line_uuid),
    CONSTRAINT fk_01_booking_line_booking FOREIGN KEY (booking_uuid) REFERENCES rm_owner.booking (booking_uuid)
);

-- Comments on booking_line table and columns
COMMENT ON TABLE rm_owner.booking_line IS 'Table to hold booking_line details';
COMMENT ON COLUMN rm_owner.booking_line.booking_line_uuid IS 'Booking Line UUID to uniquely identify a record in booking_line.';
COMMENT ON COLUMN rm_owner.booking_line.booking_uuid IS 'Booking UUID associated with the booking_line.';
COMMENT ON COLUMN rm_owner.booking_line.created_by IS 'Column to hold the user who created the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.booking_line.created_datetime IS 'Column to hold the time at which the record was created. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.booking_line.updated_by IS 'Column to hold the user who updated the record. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.booking_line.updated_datetime IS 'Column to hold the time at which the record was updated. This is used for audit purposes.';
COMMENT ON COLUMN rm_owner.booking_line.concurrency_version IS 'Column to hold version details so as to ensure that there is only one update at a time.';