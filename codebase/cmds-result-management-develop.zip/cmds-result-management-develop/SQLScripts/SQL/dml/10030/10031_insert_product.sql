
\ir  ..//..//product_dml//insert_product.sql