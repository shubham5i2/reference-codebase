-- This query will remove old duplicate evaluation_round_booking and keep the latest ones based on the creation_datetime of the evaluation_round.
DELETE FROM rm_owner.evaluation_round_booking erb
WHERE erb.evaluation_round_booking_uuid  NOT IN (SELECT evaluation_round_booking_uuid
                                                 FROM rm_owner.evaluation_round_booking latest_erb,
                                                      rm_owner.evaluation_round er2
                                                 WHERE latest_erb.evaluation_round_uuid = er2.evaluation_round_uuid
                                                 AND ((latest_erb.booking_line_uuid IS NOT NULL
                                                        AND erb.booking_line_uuid IS NOT NULL
                                                        AND latest_erb.booking_line_uuid=erb.booking_line_uuid
                                                        AND latest_erb.booking_uuid=erb.booking_uuid
                                                       )
                                                     OR (latest_erb.booking_line_uuid IS NULL
                                                        AND erb.booking_line_uuid IS NULL
                                                        AND latest_erb.booking_uuid = erb.booking_uuid
                                                        )
                                                      )
                                                 AND latest_erb.round_id = erb.round_id ORDER BY er2.created_datetime  DESC LIMIT 1
                                                )
AND erb.booking_uuid IN (SELECT booking_uuid
                         FROM rm_owner.evaluation_round_booking
                         WHERE  booking_line_uuid IS NULL
                         GROUP BY booking_uuid, round_id
                         HAVING COUNT(*)>=2
                        );
