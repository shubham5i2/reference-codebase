--add results_status_comment_text column to results_status_history_table
ALTER TABLE rm_owner.results_status_history
ADD COLUMN results_status_comment_text VARCHAR(100) NULL;

