Alter table rm_owner.product add constraint fk_02_product_module_type FOREIGN KEY (module_type_uuid) REFERENCES rm_owner.module_type(module_type_uuid);
