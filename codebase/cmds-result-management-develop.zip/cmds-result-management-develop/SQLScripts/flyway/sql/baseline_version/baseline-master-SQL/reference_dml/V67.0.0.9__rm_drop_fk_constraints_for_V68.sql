Alter table rm_owner.mark drop constraint fk_01_mark_mark_criteria;

