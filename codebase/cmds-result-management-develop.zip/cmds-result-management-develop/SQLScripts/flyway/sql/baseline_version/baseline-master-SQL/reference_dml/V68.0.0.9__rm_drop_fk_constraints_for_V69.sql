Alter table rm_owner.product drop constraint fk_02_product_module_type ;
