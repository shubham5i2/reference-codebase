drop table rm_owner.mark_history;

drop table rm_owner.evaluation_history;

drop table rm_owner.evaluation_round_history;