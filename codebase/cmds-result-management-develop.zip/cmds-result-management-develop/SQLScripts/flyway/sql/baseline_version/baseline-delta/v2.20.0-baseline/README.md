* Steps to execute:
  1. In RI DB: Run the script V124.0.1.0__rm_IMOD-38147_extract_incident_uuids_from_ri_db.sql
  2. In RM DB: Run the script V124.0.2.0__rm_IMOD-38147_update_rm_data_from_cvs.sql

* Validation:
	- In RM DB, Table incident should contain the column external_incident_uuid and it should contain values.
