* Steps to execute:
	Run script: V123.0.0.0__rm_IMOD-26287_create_incident_table.sql
	
* Validation:
    - new table should be created "rm_owner.incident"
  