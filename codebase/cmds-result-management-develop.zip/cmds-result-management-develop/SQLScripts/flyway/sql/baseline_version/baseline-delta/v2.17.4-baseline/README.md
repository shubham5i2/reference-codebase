* Steps to execute:
	Run script: V119.0.0.0__rm_IMOD-27535_create_photo_table.sql
	
* Validation:
	- Expected new table "photo" should be created with 12 fields