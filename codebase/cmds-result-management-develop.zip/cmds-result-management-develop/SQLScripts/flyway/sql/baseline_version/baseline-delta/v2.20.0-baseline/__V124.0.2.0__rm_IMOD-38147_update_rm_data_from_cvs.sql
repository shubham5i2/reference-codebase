--In RM database,

CREATE TEMP TABLE tmp_incident(incident_uuid uuid, booking_uuid uuid, incident_type_uuid uuid);

\copy tmp_incident FROM 'absolute\path\with\incident_uuids.csv' WITH delimiter ',' csv header;

ALTER TABLE rm_owner.incident
ADD COLUMN IF NOT EXISTS external_incident_uuid uuid null,
DROP CONSTRAINT IF EXISTS booking_incident_type_unique,
DROP CONSTRAINT IF EXISTS booking_external_incident_uuid,
ADD CONSTRAINT booking_external_incident_uuid UNIQUE (booking_uuid, external_incident_uuid);

UPDATE rm_owner.incident SET external_incident_uuid = tmp_incident.incident_uuid
FROM tmp_incident
WHERE incident.booking_uuid = tmp_incident.booking_uuid
AND incident.incident_type_uuid = tmp_incident.incident_type_uuid;
