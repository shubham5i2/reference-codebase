
/copy (select i.incident_uuid, i.booking_uuid, i.incident_type_uuid from ri_owner.incident i) TO 'absolute\path\with\incident_uuids.csv' WITH delimiter ',' csv header;
