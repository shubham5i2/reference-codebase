package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.constants.ReceiverConstants.BOOKING_SEARCH_REQUESTED_EVENT_NAME;
import static com.ielts.cmds.integration.constants.ReceiverConstants.MULTIPLE_ON_HOLD_UPDATE_REQUESTED_EVENT_NAME;
import static com.ielts.cmds.integration.constants.ReceiverConstants.MULTIPLE_RESULTS_STATUS_UPDATE_REQUESTED_EVENT_NAME;
import static com.ielts.cmds.integration.constants.ReceiverConstants.PARTNER_CODE;
import static com.ielts.cmds.integration.constants.ReceiverConstants.RESULTS_VIEW_REQUESTED_EVENT_NAME;
import static com.ielts.cmds.integration.constants.ReceiverConstants.RM_UI_TOPIC_IN;
import static com.ielts.cmds.integration.constants.ReceiverConstants.SINGLE_ON_HOLD_UPDATE_REQUESTED_EVENT_NAME;
import static com.ielts.cmds.integration.constants.ReceiverConstants.SINGLE_RESULTS_STATUS_UPDATE_REQUESTED_EVENT_NAME;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.utils.CMDSCommonUtils;
import com.ielts.cmds.integration.factory.ReceiverServiceFactory;
import com.ielts.cmds.integration.services.BookingSearchRequestedService;
import com.ielts.cmds.integration.services.MultipleOnHoldUpdateRequestedService;
import com.ielts.cmds.integration.services.MultipleResultsStatusUpdateRequestedService;
import com.ielts.cmds.integration.services.ResultsViewRequestedService;
import com.ielts.cmds.integration.services.SingleOnHoldUpdateRequestedService;
import com.ielts.cmds.integration.services.SingleResultsStatusUpdateRequestedService;
import com.ielts.cmds.serialization.lambda.AbstractReceiverLambda;
import com.ielts.cmds.serialization.lambda.mapper.IObjectMapper;
import com.ielts.cmds.serialization.lambda.receiver.service.AbstractServiceFactory;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class RMUIReceiver extends AbstractReceiverLambda implements IObjectMapper {

	@Override
	public AbstractServiceFactory getServiceFactory() {
		@SuppressWarnings("rawtypes")
		final Map<String, IReceiverService> initServices = new HashMap<>();
		final ObjectMapper mapper = getMapperWithProperties();
		initServices.put(RESULTS_VIEW_REQUESTED_EVENT_NAME, new ResultsViewRequestedService(mapper));
		initServices.put(SINGLE_RESULTS_STATUS_UPDATE_REQUESTED_EVENT_NAME,
				new SingleResultsStatusUpdateRequestedService());
		initServices.put(MULTIPLE_RESULTS_STATUS_UPDATE_REQUESTED_EVENT_NAME,
				new MultipleResultsStatusUpdateRequestedService());
		initServices.put(SINGLE_ON_HOLD_UPDATE_REQUESTED_EVENT_NAME, new SingleOnHoldUpdateRequestedService(mapper));
		initServices.put(MULTIPLE_ON_HOLD_UPDATE_REQUESTED_EVENT_NAME, new MultipleOnHoldUpdateRequestedService());
		initServices.put(BOOKING_SEARCH_REQUESTED_EVENT_NAME, new BookingSearchRequestedService());
		return new ReceiverServiceFactory(initServices);
	}

	@Override
	public String getTopicArn() {
		return System.getenv(RM_UI_TOPIC_IN);
	}

	@Override
	protected String getPartnerCode() {
		return CMDSCommonUtils.getDataFromClaims(ThreadLocalHeaderContext.getContext().getXaccessToken(), PARTNER_CODE);
	}

}
