package com.ielts.cmds.integration.services;

import static com.ielts.cmds.integration.constants.ReceiverConstants.BOOKING_UUID;
import static com.ielts.cmds.integration.constants.ReceiverConstants.SINGLE_RESULTS_STATUS_UPDATE_REQUESTED_OUTGOING_EVENT_NAME;

import java.util.Objects;
import java.util.UUID;

import com.ielts.cmds.api.rmui002singleresultsstatusupdaterequested.ResultStatusUpdateRequestV1;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

public class SingleResultsStatusUpdateRequestedService implements
		IReceiverService<com.ielts.cmds.api.common.ui_client.ResultStatusUpdateRequestV1, ResultStatusUpdateRequestV1> {

	@Override
	public String getOutgoingEventName() {
		return SINGLE_RESULTS_STATUS_UPDATE_REQUESTED_OUTGOING_EVENT_NAME;
	}

	@Override
	public ResultStatusUpdateRequestV1 process(
			final com.ielts.cmds.api.common.ui_client.ResultStatusUpdateRequestV1 incomingEvent) {
		final ResultStatusUpdateRequestV1 resultsStatusUpdateRequest = new ResultStatusUpdateRequestV1();
		if (Objects.nonNull(ThreadLocalHeaderContext.getContext().getEventContext().get(BOOKING_UUID))) {
			resultsStatusUpdateRequest.setBookingUuid(
					UUID.fromString(ThreadLocalHeaderContext.getContext().getEventContext().get(BOOKING_UUID)));
		}
		resultsStatusUpdateRequest.setResultStatusTypeUuid(incomingEvent.getResultStatusTypeUuid());
		resultsStatusUpdateRequest.setResultConcurrencyVersion(incomingEvent.getResultConcurrencyVersion());
		resultsStatusUpdateRequest.setResultStatusLabelUuid(incomingEvent.getResultStatusLabelUuid());
		resultsStatusUpdateRequest.setResultStatusCommentUuid(incomingEvent.getResultStatusCommentUuid());
		resultsStatusUpdateRequest.setResultStatusCommentText(incomingEvent.getResultStatusCommentText());
		return resultsStatusUpdateRequest;
	}

}
