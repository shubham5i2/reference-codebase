package com.ielts.cmds.integration.constants;

public class ReceiverConstants {
	private ReceiverConstants() {
	}

    public static final String RM_UI_TOPIC_IN = "rm_ui_topic_in_arn";
    public static final String PARTNER_CODE = "partnerCode";
    public static final String BOOKING_UUID = "bookingUuid";
    public static final String ON_HOLD = "onHold";

    public static final String RESULTS_VIEW_REQUESTED_EVENT_NAME = "GET/v2/result/booking/{bookingUuid}";
    public static final String SINGLE_RESULTS_STATUS_UPDATE_REQUESTED_EVENT_NAME = "POST/v1/result/booking/{bookingUuid}/status";
    public static final String MULTIPLE_RESULTS_STATUS_UPDATE_REQUESTED_EVENT_NAME = "POST/v1/result/bookings/status";
    public static final String SINGLE_ON_HOLD_UPDATE_REQUESTED_EVENT_NAME = "PUT/v1/result/booking/{bookingUuid}/onhold";
    public static final String MULTIPLE_ON_HOLD_UPDATE_REQUESTED_EVENT_NAME = "PUT/v1/result/bookings/onhold";
	public static final String BOOKING_SEARCH_REQUESTED_EVENT_NAME = "POST/v1/result/booking/search";

	public static final String RESULTS_VIEW_REQUESTED_OUTGOING_EVENT_NAME = "ResultsViewRequested";
	public static final String SINGLE_RESULTS_STATUS_UPDATE_REQUESTED_OUTGOING_EVENT_NAME = "SingleResultsStatusUpdateRequested";
	public static final String MULTIPLE_RESULTS_STATUS_UPDATE_REQUESTED_OUTGOING_EVENT_NAME = "MultipleResultsStatusUpdateRequested";
	public static final String SINGLE_ON_HOLD_UPDATE_REQUESTED_OUTGOING_EVENT_NAME = "SingleOnHoldUpdateRequested";
	public static final String MULTIPLE_ON_HOLD_UPDATE_REQUESTED_OUTGOING_EVENT_NAME = "MultipleOnHoldUpdateRequested";
	public static final String BOOKING_SEARCH_REQUESTED_OUTGOING_EVENT_NAME = "BookingSearchRequested";

}
