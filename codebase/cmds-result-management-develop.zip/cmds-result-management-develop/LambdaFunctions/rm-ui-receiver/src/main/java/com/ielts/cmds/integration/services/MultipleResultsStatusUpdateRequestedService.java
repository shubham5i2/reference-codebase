package com.ielts.cmds.integration.services;

import static com.ielts.cmds.integration.constants.ReceiverConstants.MULTIPLE_RESULTS_STATUS_UPDATE_REQUESTED_OUTGOING_EVENT_NAME;

import com.ielts.cmds.api.rmui003multipleresultsstatusupdaterequested.ResultBulkStatusUpdateRequestV1;
import com.ielts.cmds.api.rmui003multipleresultsstatusupdaterequested.ResultStatusUpdateRequestV1;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;

import java.util.Objects;

public class MultipleResultsStatusUpdateRequestedService implements
		IReceiverService<com.ielts.cmds.api.common.ui_client.ResultBulkStatusUpdateRequestV1, ResultBulkStatusUpdateRequestV1> {

	@Override
	public String getOutgoingEventName() {
		return MULTIPLE_RESULTS_STATUS_UPDATE_REQUESTED_OUTGOING_EVENT_NAME;
	}

	@Override
	public ResultBulkStatusUpdateRequestV1 process(
			final com.ielts.cmds.api.common.ui_client.ResultBulkStatusUpdateRequestV1 incomingEvent) {
		final ResultBulkStatusUpdateRequestV1 multipleResultsStatusUpdateRequest = new ResultBulkStatusUpdateRequestV1();
		multipleResultsStatusUpdateRequest.setBookingUuidList(incomingEvent.getBookingUuidList());

        if (Objects.nonNull(incomingEvent.getTargetResultStatus())) {
            final ResultStatusUpdateRequestV1 targetResultStatus =
                    new ResultStatusUpdateRequestV1();
            targetResultStatus.setResultStatusTypeUuid(
                    incomingEvent.getTargetResultStatus().getResultStatusTypeUuid());
            targetResultStatus.setResultConcurrencyVersion(
                    incomingEvent.getTargetResultStatus().getResultConcurrencyVersion());
            targetResultStatus.setResultStatusLabelUuid(
                    incomingEvent.getTargetResultStatus().getResultStatusLabelUuid());
            targetResultStatus.setResultStatusCommentUuid(
                    incomingEvent.getTargetResultStatus().getResultStatusCommentUuid());
            targetResultStatus.setResultStatusCommentText(
                    incomingEvent.getTargetResultStatus().getResultStatusCommentText());
            multipleResultsStatusUpdateRequest.setTargetResultStatus(targetResultStatus);
        }

        if (Objects.nonNull(incomingEvent.getCurrentResultStatus())) {
            final ResultStatusUpdateRequestV1 currentResultStatus =
                    new ResultStatusUpdateRequestV1();
            currentResultStatus.setResultStatusTypeUuid(
                    incomingEvent.getCurrentResultStatus().getResultStatusTypeUuid());
            currentResultStatus.setResultConcurrencyVersion(
                    incomingEvent.getCurrentResultStatus().getResultConcurrencyVersion());
            currentResultStatus.setResultStatusLabelUuid(
                    incomingEvent.getCurrentResultStatus().getResultStatusLabelUuid());
            currentResultStatus.setResultStatusCommentUuid(
                    incomingEvent.getCurrentResultStatus().getResultStatusCommentUuid());
            currentResultStatus.setResultStatusCommentText(
                    incomingEvent.getCurrentResultStatus().getResultStatusCommentText());
            multipleResultsStatusUpdateRequest.setCurrentResultStatus(currentResultStatus);
        }

		return multipleResultsStatusUpdateRequest;
	}

}
