package com.ielts.cmds.integration.services;

import static com.ielts.cmds.integration.constants.ReceiverConstants.MULTIPLE_ON_HOLD_UPDATE_REQUESTED_OUTGOING_EVENT_NAME;
import static com.ielts.cmds.integration.constants.ReceiverConstants.ON_HOLD;

import java.util.Objects;

import com.ielts.cmds.api.rmui005multipleonholdupdaterequested.ResultOnHoldBulkUpdateRequestV1;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

public class MultipleOnHoldUpdateRequestedService implements
		IReceiverService<com.ielts.cmds.api.common.ui_client.ResultOnHoldBulkUpdateRequestV1, ResultOnHoldBulkUpdateRequestV1> {

	@Override
	public String getOutgoingEventName() {
		return MULTIPLE_ON_HOLD_UPDATE_REQUESTED_OUTGOING_EVENT_NAME;
	}

	@Override
	public ResultOnHoldBulkUpdateRequestV1 process(
			final com.ielts.cmds.api.common.ui_client.ResultOnHoldBulkUpdateRequestV1 incomingEvent) {
		final ResultOnHoldBulkUpdateRequestV1 multipleOnHoldUpdateRequest = new ResultOnHoldBulkUpdateRequestV1();
		multipleOnHoldUpdateRequest.setBookingUuidList(incomingEvent.getBookingUuidList());
		if (Objects.nonNull(ThreadLocalHeaderContext.getContext().getEventContext().get(ON_HOLD))) {
			multipleOnHoldUpdateRequest.setOnHold(
					Boolean.parseBoolean(ThreadLocalHeaderContext.getContext().getEventContext().get(ON_HOLD)));
		}
		return multipleOnHoldUpdateRequest;
	}

}
