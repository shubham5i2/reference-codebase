package com.ielts.cmds.integration.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import com.ielts.cmds.api.rmui006bookingsearchrequested.PeriodNodeV1;
import com.ielts.cmds.api.rmui006bookingsearchrequested.SearchBookingV1Criteria;
import com.ielts.cmds.api.rmui006bookingsearchrequested.SearchPaginationV1;
import com.ielts.cmds.api.rmui006bookingsearchrequested.SearchRequestV1;
import com.ielts.cmds.api.rmui006bookingsearchrequested.SearchSortV1Item;
import com.ielts.cmds.integration.constants.ReceiverConstants;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;

public class BookingSearchRequestedService
		implements IReceiverService<com.ielts.cmds.api.common.ui_client.SearchRequestV1, SearchRequestV1> {

	@Override
	public SearchRequestV1 process(final com.ielts.cmds.api.common.ui_client.SearchRequestV1 eventBody) {
		final SearchRequestV1 searchRequestV1 = new SearchRequestV1();
		searchRequestV1.setCriteria(getCriteria(eventBody.getCriteria()));
		searchRequestV1.setPagination(getPagination(eventBody.getPagination()));
		searchRequestV1.setSorting(getSorting(eventBody.getSorting()));
		return searchRequestV1;
	}

	private List<SearchSortV1Item> getSorting(
			final List<com.ielts.cmds.api.common.ui_client.SearchSortV1Item> inputSearchSortItemList) {
		final List<SearchSortV1Item> outputSearchSortList = new ArrayList<>();
		inputSearchSortItemList.stream().forEach(inputSearchSortItem -> {
			final SearchSortV1Item outputSearchSortItem = new SearchSortV1Item();
			outputSearchSortItem.setSortBy(inputSearchSortItem.getSortBy());
			outputSearchSortItem.setSortType(inputSearchSortItem.getSortType());
			outputSearchSortList.add(outputSearchSortItem);
		});
		return outputSearchSortList;

	}

	private SearchPaginationV1 getPagination(final com.ielts.cmds.api.common.ui_client.SearchPaginationV1 pagination) {
		final SearchPaginationV1 searchPaginationV1 = new SearchPaginationV1();
		if (Optional.ofNullable(pagination.getPageNumber()).isPresent()) {
			searchPaginationV1.setPageNumber(String.valueOf(pagination.getPageNumber()));
		}
		if (Optional.ofNullable(pagination.getPageSize()).isPresent()) {
			searchPaginationV1.setPageSize(String.valueOf(pagination.getPageSize()));
		}
		return searchPaginationV1;
	}

	private SearchBookingV1Criteria getCriteria(
			final com.ielts.cmds.api.common.ui_client.SearchBookingV1Criteria criteria) {
		final SearchBookingV1Criteria searchBookingV1Criteria = new SearchBookingV1Criteria();
		if (Optional.ofNullable(criteria.getBookingStatus()).isPresent()) {
			searchBookingV1Criteria.setBookingStatus(
					SearchBookingV1Criteria.BookingStatusEnum.valueOf(criteria.getBookingStatus().getValue()));
		}
		if (Optional.ofNullable(criteria.getBookingDetailStatus()).isPresent()) {
			searchBookingV1Criteria.setBookingDetailStatus(SearchBookingV1Criteria.BookingDetailStatusEnum
					.valueOf(criteria.getBookingDetailStatus().getValue()));
		}
		searchBookingV1Criteria.setBookingUuid(criteria.getBookingUuid());
		searchBookingV1Criteria.setFirstName(criteria.getFirstName());
		searchBookingV1Criteria.setIdentityNumber(criteria.getIdentityNumber());
		searchBookingV1Criteria.setIsVoid(criteria.getIsVoid());
		searchBookingV1Criteria.setLastName(criteria.getLastName());
		searchBookingV1Criteria.setOnHold(criteria.getOnHold());
		searchBookingV1Criteria.setPartnerCodeList(criteria.getPartnerCodeList());
		searchBookingV1Criteria.setProductUuidList(criteria.getProductUuidList());
		searchBookingV1Criteria.setResultStatusUuid(criteria.getResultStatusUuid());
		searchBookingV1Criteria.setShortCandidateNumber(criteria.getShortCandidateNumber());
		searchBookingV1Criteria.setTestCentreUuid(criteria.getTestCentreUuid());
		searchBookingV1Criteria.setTestTakerUuid(criteria.getTestTakerUuid());
		searchBookingV1Criteria.setTestCentreUuidList(criteria.getTestCentreUuidList());
		searchBookingV1Criteria.setUniqueTestTakerId(criteria.getUniqueTestTakerId());
		searchBookingV1Criteria.setProductUuid(criteria.getProductUuid());
		searchBookingV1Criteria.setTimeRange(getTimeRange(criteria.getTimeRange()));
		return searchBookingV1Criteria;
	}

	private PeriodNodeV1 getTimeRange(com.ielts.cmds.api.common.ui_client.@Valid PeriodNodeV1 timeRange) {
		PeriodNodeV1 periodNode = new PeriodNodeV1();
		periodNode.setStartTime(timeRange.getStartTime());
		periodNode.setEndTime(timeRange.getEndTime());
		return periodNode;
	}

	@Override
	public String getOutgoingEventName() {
		return ReceiverConstants.BOOKING_SEARCH_REQUESTED_OUTGOING_EVENT_NAME;
	}
}
