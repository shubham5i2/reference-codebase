package com.ielts.cmds.integration.services;

import static com.ielts.cmds.integration.constants.ReceiverConstants.SINGLE_ON_HOLD_UPDATE_REQUESTED_OUTGOING_EVENT_NAME;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.rmui004singleonholdupdaterequested.SingleOnHoldUpdateRequestedV1;
import com.ielts.cmds.serialization.lambda.receiver.service.RequestWithParamsReceiverService;

public class SingleOnHoldUpdateRequestedService
		extends RequestWithParamsReceiverService<SingleOnHoldUpdateRequestedV1> {

	public SingleOnHoldUpdateRequestedService(ObjectMapper mapper) {
		super(mapper);
	}

	@Override
	public String getOutgoingEventName() {
		return SINGLE_ON_HOLD_UPDATE_REQUESTED_OUTGOING_EVENT_NAME;
	}

}
