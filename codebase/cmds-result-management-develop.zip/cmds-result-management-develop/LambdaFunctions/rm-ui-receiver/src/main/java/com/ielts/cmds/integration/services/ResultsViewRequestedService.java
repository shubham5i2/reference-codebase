package com.ielts.cmds.integration.services;

import static com.ielts.cmds.integration.constants.ReceiverConstants.RESULTS_VIEW_REQUESTED_OUTGOING_EVENT_NAME;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.rmui001resultsviewrequested.ResultsViewRequestedV1;
import com.ielts.cmds.serialization.lambda.receiver.service.RequestWithParamsReceiverService;

public class ResultsViewRequestedService extends RequestWithParamsReceiverService<ResultsViewRequestedV1> {

	public ResultsViewRequestedService(ObjectMapper mapper) {
		super(mapper);
	}

	@Override
	public String getOutgoingEventName() {
		return RESULTS_VIEW_REQUESTED_OUTGOING_EVENT_NAME;
	}

}
