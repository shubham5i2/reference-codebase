package com.ielts.cmds.integration.helper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import com.ielts.cmds.api.common.ui_client.PeriodNodeV1;
import com.ielts.cmds.api.common.ui_client.ResultBulkStatusUpdateRequestV1;
import com.ielts.cmds.api.common.ui_client.ResultOnHoldBulkUpdateRequestV1;
import com.ielts.cmds.api.common.ui_client.ResultStatusUpdateRequestV1;
import com.ielts.cmds.api.common.ui_client.SearchBookingV1Criteria;
import com.ielts.cmds.api.common.ui_client.SearchPaginationV1;
import com.ielts.cmds.api.common.ui_client.SearchRequestV1;
import com.ielts.cmds.api.common.ui_client.SearchSortV1Item;

public class RMUIReceiverTestSetup {

	public static String getXAccessToken() {
		return "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkJTT3YxZ21Zam1vSWNUZFpFcGN3XyJ9.eyJodHRwczovL2NtZHNpei5jb20vcGFydG5lckNvZGUiOiJHTE9CQUxfSUVMVFMiLCJodHRwczovL2NtZHNpei5jb20vaWQiOiJhdXRoMHxkZDc2MDM1Zi0xZjgxLTQ5M2ItYjY3Yi03ZGVlMTliNTIzYTQiLCJodHRwczovL2NtZHNpei5jb20vcm9sZXMiOlsibDpjNmQ2Yjc5NS1iMjBiLTQ2NmMtOTJlZi03YTUzNzUyZTIzOGMvZzo4ZjQwZDlkOS00ZmQ0LTQ3YTYtOTcyMi1kOWI5ZmM1ZTgxYWQiXSwiaHR0cHM6Ly9jbWRzaXouY29tL2VtYWlsIjoic2hhcm1hLnM1QGNhbWJyaWRnZWFzc2Vzc21lbnQub3JnLnVrIiwiaHR0cHM6Ly9jbWRzaXouY29tL2ZpcnN0TmFtZSI6IlNoaXZhbmsiLCJodHRwczovL2NtZHNpei5jb20vbGFzdE5hbWUiOiJTaGFybWEiLCJpc3MiOiJodHRwczovL2NtZHMtc2FuZGJveC5ldS5hdXRoMC5jb20vIiwic3ViIjoiYXV0aDB8ZGQ3NjAzNWYtMWY4MS00OTNiLWI2N2ItN2RlZTE5YjUyM2E0IiwiYXVkIjpbImNtZHMtc2FuZGJveC11aS1hcGkiLCJodHRwczovL2NtZHMtc2FuZGJveC5ldS5hdXRoMC5jb20vdXNlcmluZm8iXSwiaWF0IjoxNjgwMjY3MTg0LCJleHAiOjE2ODAyODE1ODQsImF6cCI6IjZucEpIS0tKaUdaSGtMSVBONWFCVzNuYUUwbEFtT25ZIiwic2NvcGUiOiJvcGVuaWQgcHJvZmlsZSBlbWFpbCJ9.mho84Bjz97Ort6e1I3_7dmSqoHAM7GnF-q3jNATTk7djYBR9tLMB3CK7woHQ1nWVTrL6ltFvF0cMNJH8fVTxc4wDhoT9H3opemAs7Ssbf8--by4SXV6bxICYLSN6RVPvrJ9mqJj1MI-V__fB63gTGcfaLUQQIlGpST9AuSYtfSkqzDtGjVFEv1OTm0Obx-c0wFUZFfngzJx8pgy1VHR5qIZBJ1s_z-23RNYeRqjdIjKvTViAC1sk-7oI7-jGTpQFx_K2pVwpNmxJvZoR4GmwbKaAdNGM7_uBPSl7cUb6C19zuCuGpa9vtvpEUTRnPRaSy-xiX3ihPucoZUlSyKH4pQ";
	}

	public static ResultStatusUpdateRequestV1 getSingleResultsStatusUpdateRequest() {
		ResultStatusUpdateRequestV1 resultStatusUpdateRequest = new ResultStatusUpdateRequestV1();
		resultStatusUpdateRequest.setResultStatusTypeUuid(UUID.randomUUID());
		resultStatusUpdateRequest.setResultConcurrencyVersion(0);
		resultStatusUpdateRequest.setResultStatusLabelUuid(UUID.randomUUID());
		resultStatusUpdateRequest.setResultStatusCommentUuid(UUID.randomUUID());
		resultStatusUpdateRequest.setResultStatusCommentText("Admin Comment");
		return resultStatusUpdateRequest;
	}

	public static ResultBulkStatusUpdateRequestV1 getMultipleResultsStatusUpdateRequest() {
		final ResultBulkStatusUpdateRequestV1 multipleResultsStatusUpdateRequest = new ResultBulkStatusUpdateRequestV1();

		List<UUID> bookingUuidList = new ArrayList<>();
		bookingUuidList.add(UUID.randomUUID());
		bookingUuidList.add(UUID.randomUUID());
		bookingUuidList.add(UUID.randomUUID());
		multipleResultsStatusUpdateRequest.setBookingUuidList(bookingUuidList);

		ResultStatusUpdateRequestV1 targetResultStatus = new ResultStatusUpdateRequestV1();
		targetResultStatus.setResultStatusTypeUuid(UUID.randomUUID());
		targetResultStatus.setResultConcurrencyVersion(1);
		targetResultStatus.setResultStatusLabelUuid(UUID.randomUUID());
		targetResultStatus.setResultStatusCommentUuid(UUID.randomUUID());
		targetResultStatus.setResultStatusCommentText("Admin Comment Updated");
		multipleResultsStatusUpdateRequest.setTargetResultStatus(targetResultStatus);

		ResultStatusUpdateRequestV1 currentResultStatus = new ResultStatusUpdateRequestV1();
		currentResultStatus.setResultStatusTypeUuid(UUID.randomUUID());
		currentResultStatus.setResultConcurrencyVersion(0);
		currentResultStatus.setResultStatusLabelUuid(UUID.randomUUID());
		currentResultStatus.setResultStatusCommentUuid(UUID.randomUUID());
		currentResultStatus.setResultStatusCommentText("Admin Comment");
		multipleResultsStatusUpdateRequest.setCurrentResultStatus(currentResultStatus);

		return multipleResultsStatusUpdateRequest;
	}

	public static ResultOnHoldBulkUpdateRequestV1 getMultipleOnHoldUpdateRequest() {
		ResultOnHoldBulkUpdateRequestV1 multipleOnHoldUpdateRequest = new ResultOnHoldBulkUpdateRequestV1();
		List<UUID> bookingUuidList = new ArrayList<>();
		bookingUuidList.add(UUID.randomUUID());
		bookingUuidList.add(UUID.randomUUID());
		bookingUuidList.add(UUID.randomUUID());
		multipleOnHoldUpdateRequest.setBookingUuidList(bookingUuidList);

		return multipleOnHoldUpdateRequest;
	}

	public static SearchRequestV1 getBookingSearchRequestedRequest() {
		SearchRequestV1 searchTestTakerRequestV1 = new SearchRequestV1();

		SearchBookingV1Criteria searchBookingV1Criteria = new SearchBookingV1Criteria();
		searchBookingV1Criteria.setUniqueTestTakerId("T-F8-04L0-NBIN");
		searchBookingV1Criteria.setBookingUuid("ab032fe3-f292-4bba-8178-394c01fb254f");
		searchBookingV1Criteria.setFirstName("Alan");
		searchBookingV1Criteria.setLastName("Davies");
		searchBookingV1Criteria.setShortCandidateNumber("alan@examplecom");
		searchBookingV1Criteria.setBookingUuid("uuid");
		searchBookingV1Criteria.setIdentityNumber("AB12314");
		searchBookingV1Criteria.setTestCentreUuid("testCentreuuid");
		searchBookingV1Criteria.setResultStatusUuid("resultStatusUuid");
		searchBookingV1Criteria.setTestTakerUuid("testTakerUuid");
		searchBookingV1Criteria.setBookingStatus(SearchBookingV1Criteria.BookingStatusEnum.valueOf("PAID"));
		searchBookingV1Criteria
				.setBookingDetailStatus(SearchBookingV1Criteria.BookingDetailStatusEnum.valueOf("COMPLETE"));
		List<String> testCentreUuidList = new ArrayList<>(Arrays.asList(UUID.randomUUID().toString()));
		searchBookingV1Criteria.setTestCentreUuidList(testCentreUuidList);
		List<String> productUuidList = new ArrayList<>(Arrays.asList(UUID.randomUUID().toString()));
		searchBookingV1Criteria.setProductUuidList(productUuidList);
		List<String> partnerCodeList = new ArrayList<>(Arrays.asList("string"));
		searchBookingV1Criteria.setPartnerCodeList(partnerCodeList);
		PeriodNodeV1 periodNodeV1 = new PeriodNodeV1();
		searchBookingV1Criteria.setTimeRange(periodNodeV1);
		searchTestTakerRequestV1.setCriteria(searchBookingV1Criteria);

		SearchPaginationV1 searchPaginationV1 = new SearchPaginationV1();
		searchPaginationV1.setPageNumber(new BigDecimal("1"));
		searchPaginationV1.setPageSize(new BigDecimal("50"));
		searchTestTakerRequestV1.setPagination(searchPaginationV1);

		List<SearchSortV1Item> searchSortV1List = new ArrayList<>();
		SearchSortV1Item searchSortV1 = new SearchSortV1Item();
		searchSortV1.setSortBy("444333d5-f1e6-4753-b7a9-573a8985c5c5");
		searchSortV1.setSortType("BANNED");
		searchSortV1List.add(searchSortV1);
		searchTestTakerRequestV1.setSorting(searchSortV1List);

		return searchTestTakerRequestV1;
	}

}
