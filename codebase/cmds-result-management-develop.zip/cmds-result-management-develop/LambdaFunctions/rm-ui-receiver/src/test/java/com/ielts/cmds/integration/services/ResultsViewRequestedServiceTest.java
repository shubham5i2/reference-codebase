package com.ielts.cmds.integration.services;

import static com.ielts.cmds.integration.constants.ReceiverConstants.RESULTS_VIEW_REQUESTED_OUTGOING_EVENT_NAME;
import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ResultsViewRequestedServiceTest {

	@InjectMocks
	private ResultsViewRequestedService resultsViewRequestedService;

	@Test
	void when_callingGetOutgoingEventName_thenReturnEvent() {
		String actualEventName = resultsViewRequestedService.getOutgoingEventName();
		assertEquals(RESULTS_VIEW_REQUESTED_OUTGOING_EVENT_NAME, actualEventName);
	}

}
