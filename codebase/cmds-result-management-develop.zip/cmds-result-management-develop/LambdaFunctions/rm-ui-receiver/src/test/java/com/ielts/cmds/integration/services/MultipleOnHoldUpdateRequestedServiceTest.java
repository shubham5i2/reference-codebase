package com.ielts.cmds.integration.services;

import static com.ielts.cmds.integration.constants.ReceiverConstants.MULTIPLE_ON_HOLD_UPDATE_REQUESTED_OUTGOING_EVENT_NAME;
import static com.ielts.cmds.integration.constants.ReceiverConstants.ON_HOLD;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.HashMap;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.api.rmui005multipleonholdupdaterequested.ResultOnHoldBulkUpdateRequestV1;
import com.ielts.cmds.integration.helper.RMUIReceiverTestSetup;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

@ExtendWith(MockitoExtension.class)
class MultipleOnHoldUpdateRequestedServiceTest {

	@InjectMocks
	private MultipleOnHoldUpdateRequestedService multipleOnHoldUpdateRequestedService;

	@BeforeEach
	void init() {
		HeaderContext headerContext = new HeaderContext();
		headerContext.setEventContext(new HashMap<>());
		ThreadLocalHeaderContext.setContext(headerContext);
	}

	@Test
	void when_callingGetOutgoingEventName_thenReturnEvent() {
		String actualEventName = multipleOnHoldUpdateRequestedService.getOutgoingEventName();
		assertEquals(MULTIPLE_ON_HOLD_UPDATE_REQUESTED_OUTGOING_EVENT_NAME, actualEventName);
	}

	@Test
	void whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEvent() {
		ThreadLocalHeaderContext.getContext().getEventContext().put(ON_HOLD, Boolean.TRUE.toString());
		final com.ielts.cmds.api.common.ui_client.ResultOnHoldBulkUpdateRequestV1 incomingEvent = RMUIReceiverTestSetup
				.getMultipleOnHoldUpdateRequest();
		final ResultOnHoldBulkUpdateRequestV1 outgoingEvent = multipleOnHoldUpdateRequestedService
				.process(incomingEvent);

		assertEquals(incomingEvent.getBookingUuidList(), outgoingEvent.getBookingUuidList());
		assertEquals(ThreadLocalHeaderContext.getContext().getEventContext().get(ON_HOLD),
				outgoingEvent.getOnHold().toString());
	}

	@Test
	void whenProcess_NoOnHold_thenIncomingEventIsMappedCorrectlyToOutgoingEvent() {
		final com.ielts.cmds.api.common.ui_client.ResultOnHoldBulkUpdateRequestV1 incomingEvent = RMUIReceiverTestSetup
				.getMultipleOnHoldUpdateRequest();
		final ResultOnHoldBulkUpdateRequestV1 outgoingEvent = multipleOnHoldUpdateRequestedService
				.process(incomingEvent);

		assertEquals(incomingEvent.getBookingUuidList(), outgoingEvent.getBookingUuidList());
		assertNull(ThreadLocalHeaderContext.getContext().getEventContext().get(ON_HOLD));
	}

}
