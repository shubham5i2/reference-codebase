package com.ielts.cmds.integration.services;

import static com.ielts.cmds.integration.constants.ReceiverConstants.SINGLE_ON_HOLD_UPDATE_REQUESTED_OUTGOING_EVENT_NAME;
import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class SingleOnHoldUpdateRequestedServiceTest {

	@InjectMocks
	private SingleOnHoldUpdateRequestedService singleOnHoldUpdateRequestedService;

	@Test
	void when_callingGetOutgoingEventName_thenReturnEvent() {
		String actualEventName = singleOnHoldUpdateRequestedService.getOutgoingEventName();
		assertEquals(SINGLE_ON_HOLD_UPDATE_REQUESTED_OUTGOING_EVENT_NAME, actualEventName);
	}

}
