package com.ielts.cmds.integration.services;

import static com.ielts.cmds.integration.constants.ReceiverConstants.BOOKING_SEARCH_REQUESTED_OUTGOING_EVENT_NAME;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.api.common.ui_client.SearchRequestV1;
import com.ielts.cmds.integration.helper.RMUIReceiverTestSetup;

@ExtendWith(MockitoExtension.class)
class BookingSearchRequestedServiceTest {

	@InjectMocks
	private BookingSearchRequestedService resultBookingSearchRequestedService;

	@Test
	void when_callingGetOutgoingEventName_thenReturnEvent() {
		String actualEventName = resultBookingSearchRequestedService.getOutgoingEventName();
		assertEquals(BOOKING_SEARCH_REQUESTED_OUTGOING_EVENT_NAME, actualEventName);
	}

	@Test
	void whenReceiveBookingSearchRequested_thenProcessCriteria() {
		SearchRequestV1 searchRequestV1 = RMUIReceiverTestSetup.getBookingSearchRequestedRequest();
		com.ielts.cmds.api.rmui006bookingsearchrequested.SearchRequestV1 bookingSearchRequested = resultBookingSearchRequestedService
				.process(searchRequestV1);
		assertNotNull(bookingSearchRequested);
		assertEquals(searchRequestV1.getCriteria().getUniqueTestTakerId(),
				bookingSearchRequested.getCriteria().getUniqueTestTakerId());
		assertEquals(searchRequestV1.getCriteria().getBookingUuid(),
				bookingSearchRequested.getCriteria().getBookingUuid());
		assertEquals(searchRequestV1.getCriteria().getBookingStatus().getValue(),
				bookingSearchRequested.getCriteria().getBookingStatus().getValue());
		assertEquals(searchRequestV1.getCriteria().getBookingDetailStatus().getValue(),
				bookingSearchRequested.getCriteria().getBookingDetailStatus().getValue());

	}

	@Test
	void whenReceiveBookingSearchRequested_thenBookingDetailStatusAndBookingStatusNull() {
		SearchRequestV1 searchRequestV1 = RMUIReceiverTestSetup.getBookingSearchRequestedRequest();
		searchRequestV1.getCriteria().setBookingStatus(null);
		searchRequestV1.getCriteria().setBookingDetailStatus(null);
		com.ielts.cmds.api.rmui006bookingsearchrequested.SearchRequestV1 bookingSearchRequested = resultBookingSearchRequestedService
				.process(searchRequestV1);
		assertNotNull(bookingSearchRequested);
		assertNull(bookingSearchRequested.getCriteria().getBookingStatus());
		assertNull(bookingSearchRequested.getCriteria().getBookingDetailStatus());

	}

	@Test
	void whenReceiveBookingSearchRequested_thenImplementGetPagination() {
		SearchRequestV1 searchRequestV1 = RMUIReceiverTestSetup.getBookingSearchRequestedRequest();
		com.ielts.cmds.api.rmui006bookingsearchrequested.SearchRequestV1 bookingSearchRequested = resultBookingSearchRequestedService
				.process(searchRequestV1);
		assertNotNull(bookingSearchRequested);
		assertEquals(searchRequestV1.getPagination().getPageNumber().toString(),
				bookingSearchRequested.getPagination().getPageNumber());
		assertEquals(searchRequestV1.getPagination().getPageSize().toString(),
				bookingSearchRequested.getPagination().getPageSize());

	}

	@Test
	void whenReceiveBookingSearchRequested_thenPageNumberAndPageSizeNull() {
		SearchRequestV1 searchRequestV1 = RMUIReceiverTestSetup.getBookingSearchRequestedRequest();
		searchRequestV1.getPagination().setPageNumber(null);
		searchRequestV1.getPagination().setPageSize(null);
		com.ielts.cmds.api.rmui006bookingsearchrequested.SearchRequestV1 bookingSearchRequested = resultBookingSearchRequestedService
				.process(searchRequestV1);
		assertNotNull(bookingSearchRequested);
		assertNull(bookingSearchRequested.getPagination().getPageNumber());
		assertNull(bookingSearchRequested.getPagination().getPageSize());

	}

	@Test
	void whenReceiveBookingSearchRequested_thenImplementGetSorting() {
		SearchRequestV1 searchRequestV1 = RMUIReceiverTestSetup.getBookingSearchRequestedRequest();
		com.ielts.cmds.api.rmui006bookingsearchrequested.SearchRequestV1 bookingSearchRequested = resultBookingSearchRequestedService
				.process(searchRequestV1);
		assertEquals(searchRequestV1.getSorting().toString(), bookingSearchRequested.getSorting().toString());
	}

}
