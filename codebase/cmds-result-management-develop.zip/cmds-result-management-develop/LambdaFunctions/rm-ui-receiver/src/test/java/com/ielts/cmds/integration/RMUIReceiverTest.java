package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.constants.ReceiverConstants.RM_UI_TOPIC_IN;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.auth0.jwt.exceptions.JWTDecodeException;
import com.ielts.cmds.integration.factory.ReceiverServiceFactory;
import com.ielts.cmds.integration.helper.RMUIReceiverTestSetup;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import uk.org.webcompere.systemstubs.environment.EnvironmentVariables;
import uk.org.webcompere.systemstubs.jupiter.SystemStub;
import uk.org.webcompere.systemstubs.jupiter.SystemStubsExtension;

@ExtendWith(MockitoExtension.class)
@ExtendWith(SystemStubsExtension.class)
class RMUIReceiverTest {

	@SystemStub
	private EnvironmentVariables environmentVariables;

	@Mock
	private RMUIReceiver rmUiReceiver;

	@BeforeEach
	void setUp() {
		environmentVariables.set(RM_UI_TOPIC_IN, "rm-topic-url");
		rmUiReceiver = Mockito.spy(rmUiReceiver);
	}

	@Test
	void whenTokenIsNotNull_thenGetPartnerCode() {
		HeaderContext headerContext = new HeaderContext();
		headerContext.setXaccessToken(RMUIReceiverTestSetup.getXAccessToken());
		ThreadLocalHeaderContext.setContext(headerContext);
		String expectedPartnerCode = "GLOBAL_IELTS";
		String actualPartnerCode = rmUiReceiver.getPartnerCode();
		assertEquals(expectedPartnerCode, actualPartnerCode);
	}

	@Test
	void whenCallingGetPartnerCodeAndTokenIsNull_thenThrowException() {
		HeaderContext headerContext = new HeaderContext();
		headerContext.setXaccessToken("token");
		ThreadLocalHeaderContext.setContext(headerContext);
		assertThrows(JWTDecodeException.class, () -> rmUiReceiver.getPartnerCode());
	}

	@Test
	void whenCallingGetTopicArn_thenReturnTopicArn() {
		String expectedTopicUrl = "rm-topic-url";
		assertEquals(expectedTopicUrl, rmUiReceiver.getTopicArn());
	}

	@Test
	void test_getServiceFactory() {
		assertTrue(rmUiReceiver.getServiceFactory() instanceof ReceiverServiceFactory);
	}
}
