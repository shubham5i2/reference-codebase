package com.ielts.cmds.integration.services;

import static com.ielts.cmds.integration.constants.ReceiverConstants.BOOKING_UUID;
import static com.ielts.cmds.integration.constants.ReceiverConstants.SINGLE_RESULTS_STATUS_UPDATE_REQUESTED_OUTGOING_EVENT_NAME;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.HashMap;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.api.rmui002singleresultsstatusupdaterequested.ResultStatusUpdateRequestV1;
import com.ielts.cmds.integration.helper.RMUIReceiverTestSetup;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

@ExtendWith(MockitoExtension.class)
class SingleResultsStatusUpdateRequestedServiceTest {

	@InjectMocks
	private SingleResultsStatusUpdateRequestedService singleResultsStatusUpdateRequestedService;

	@BeforeEach
	void init() {
		HeaderContext headerContext = new HeaderContext();
		headerContext.setEventContext(new HashMap<>());
		ThreadLocalHeaderContext.setContext(headerContext);
	}

	@Test
	void when_callingGetOutgoingEventName_thenReturnEvent() {
		String actualEventName = singleResultsStatusUpdateRequestedService.getOutgoingEventName();
		assertEquals(SINGLE_RESULTS_STATUS_UPDATE_REQUESTED_OUTGOING_EVENT_NAME, actualEventName);
	}

	@Test
	void whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEvent() {
		ThreadLocalHeaderContext.getContext().getEventContext().put(BOOKING_UUID, UUID.randomUUID().toString());
		final com.ielts.cmds.api.common.ui_client.ResultStatusUpdateRequestV1 incomingEvent = RMUIReceiverTestSetup
				.getSingleResultsStatusUpdateRequest();
		final ResultStatusUpdateRequestV1 outgoingEvent = singleResultsStatusUpdateRequestedService
				.process(incomingEvent);
		assertEquals(incomingEvent.getResultStatusTypeUuid(), outgoingEvent.getResultStatusTypeUuid());
		assertEquals(incomingEvent.getResultConcurrencyVersion(), outgoingEvent.getResultConcurrencyVersion());
		assertEquals(incomingEvent.getResultStatusLabelUuid(), outgoingEvent.getResultStatusLabelUuid());
		assertEquals(incomingEvent.getResultStatusCommentUuid(), outgoingEvent.getResultStatusCommentUuid());
		assertEquals(incomingEvent.getResultStatusCommentText(), outgoingEvent.getResultStatusCommentText());
		assertEquals(ThreadLocalHeaderContext.getContext().getEventContext().get(BOOKING_UUID),
				outgoingEvent.getBookingUuid().toString());
	}

	@Test
	void whenProcess_NoBookingUuid_thenIncomingEventIsMappedCorrectlyToOutgoingEvent() {
		final com.ielts.cmds.api.common.ui_client.ResultStatusUpdateRequestV1 incomingEvent = RMUIReceiverTestSetup
				.getSingleResultsStatusUpdateRequest();
		final ResultStatusUpdateRequestV1 outgoingEvent = singleResultsStatusUpdateRequestedService
				.process(incomingEvent);
		assertEquals(incomingEvent.getResultStatusTypeUuid(), outgoingEvent.getResultStatusTypeUuid());
		assertEquals(incomingEvent.getResultConcurrencyVersion(), outgoingEvent.getResultConcurrencyVersion());
		assertEquals(incomingEvent.getResultStatusLabelUuid(), outgoingEvent.getResultStatusLabelUuid());
		assertEquals(incomingEvent.getResultStatusCommentUuid(), outgoingEvent.getResultStatusCommentUuid());
		assertEquals(incomingEvent.getResultStatusCommentText(), outgoingEvent.getResultStatusCommentText());
		assertNull(outgoingEvent.getBookingUuid());
	}

}
