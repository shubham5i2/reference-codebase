package com.ielts.cmds.integration.services;

import static com.ielts.cmds.integration.constants.ReceiverConstants.MULTIPLE_RESULTS_STATUS_UPDATE_REQUESTED_OUTGOING_EVENT_NAME;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.api.rmui003multipleresultsstatusupdaterequested.ResultBulkStatusUpdateRequestV1;
import com.ielts.cmds.integration.helper.RMUIReceiverTestSetup;

@ExtendWith(MockitoExtension.class)
class MultipleResultsStatusUpdateRequestedServiceTest {

	@InjectMocks
	private MultipleResultsStatusUpdateRequestedService multipleResultsStatusUpdateRequestedService;

	@Test
	void when_callingGetOutgoingEventName_thenReturnEvent() {
		String actualEventName = multipleResultsStatusUpdateRequestedService.getOutgoingEventName();
		assertEquals(MULTIPLE_RESULTS_STATUS_UPDATE_REQUESTED_OUTGOING_EVENT_NAME, actualEventName);
	}

	@Test
	void whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEvent() {
		final com.ielts.cmds.api.common.ui_client.ResultBulkStatusUpdateRequestV1 incomingEvent = RMUIReceiverTestSetup
				.getMultipleResultsStatusUpdateRequest();
		final ResultBulkStatusUpdateRequestV1 outgoingEvent = multipleResultsStatusUpdateRequestedService
				.process(incomingEvent);

		assertEquals(incomingEvent.getBookingUuidList(), outgoingEvent.getBookingUuidList());

		assertEquals(incomingEvent.getTargetResultStatus().getResultStatusTypeUuid(),
				outgoingEvent.getTargetResultStatus().getResultStatusTypeUuid());
		assertEquals(incomingEvent.getTargetResultStatus().getResultConcurrencyVersion(),
				outgoingEvent.getTargetResultStatus().getResultConcurrencyVersion());
		assertEquals(incomingEvent.getTargetResultStatus().getResultStatusLabelUuid(),
				outgoingEvent.getTargetResultStatus().getResultStatusLabelUuid());
		assertEquals(incomingEvent.getTargetResultStatus().getResultStatusCommentUuid(),
				outgoingEvent.getTargetResultStatus().getResultStatusCommentUuid());
		assertEquals(incomingEvent.getTargetResultStatus().getResultStatusCommentText(),
				outgoingEvent.getTargetResultStatus().getResultStatusCommentText());

		assertEquals(incomingEvent.getCurrentResultStatus().getResultStatusTypeUuid(),
				outgoingEvent.getCurrentResultStatus().getResultStatusTypeUuid());
		assertEquals(incomingEvent.getCurrentResultStatus().getResultConcurrencyVersion(),
				outgoingEvent.getCurrentResultStatus().getResultConcurrencyVersion());
		assertEquals(incomingEvent.getCurrentResultStatus().getResultStatusLabelUuid(),
				outgoingEvent.getCurrentResultStatus().getResultStatusLabelUuid());
		assertEquals(incomingEvent.getCurrentResultStatus().getResultStatusCommentUuid(),
				outgoingEvent.getCurrentResultStatus().getResultStatusCommentUuid());
		assertEquals(incomingEvent.getCurrentResultStatus().getResultStatusCommentText(),
				outgoingEvent.getCurrentResultStatus().getResultStatusCommentText());
	}

    @Test
    void
            whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEventWhenTargetResultStatusIsNull() {
        final com.ielts.cmds.api.common.ui_client.ResultBulkStatusUpdateRequestV1 incomingEvent =
                RMUIReceiverTestSetup.getMultipleResultsStatusUpdateRequest();
        incomingEvent.setTargetResultStatus(null);
        final ResultBulkStatusUpdateRequestV1 outgoingEvent =
                multipleResultsStatusUpdateRequestedService.process(incomingEvent);

        assertNull(outgoingEvent.getTargetResultStatus());
    }

    @Test
    void
            whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEventWhenCurrentResultStatusIsNull() {
        final com.ielts.cmds.api.common.ui_client.ResultBulkStatusUpdateRequestV1 incomingEvent =
                RMUIReceiverTestSetup.getMultipleResultsStatusUpdateRequest();
        incomingEvent.setCurrentResultStatus(null);
        final ResultBulkStatusUpdateRequestV1 outgoingEvent =
                multipleResultsStatusUpdateRequestedService.process(incomingEvent);

        assertNull(outgoingEvent.getCurrentResultStatus());
    }
}
