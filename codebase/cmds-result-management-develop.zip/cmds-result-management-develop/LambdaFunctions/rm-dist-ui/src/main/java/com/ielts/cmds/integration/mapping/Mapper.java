package com.ielts.cmds.integration.mapping;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.rm.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

public interface Mapper {

    public default ObjectMapper getMapper() {
        final ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        objectMapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        objectMapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
        return objectMapper;
    }

    /** Maps Request EventHeader to Socket Response EventHeader. */
    public default SocketResponseMetaDataV1 mapRequestEventHeaderToSocketResponseHeader() {
        final SocketResponseMetaDataV1 responseHeaders = new SocketResponseMetaDataV1();
        responseHeaders.setCorrelationId(ThreadLocalHeaderContext.getContext().getCorrelationId());
        responseHeaders.setConnectionId(ThreadLocalHeaderContext.getContext().getConnectionId());
        return responseHeaders;
    }
}
