package com.ielts.cmds.integration;

import com.ielts.cmds.integration.factory.ServiceFactoryV2;
import com.ielts.cmds.serialization.lambda.AbstractDistUiLambda;
import com.ielts.cmds.serialization.lambda.dist.ui.service.AbstractServiceFactoryV2;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import java.util.Objects;

public class RMDistUI extends AbstractDistUiLambda {

    @Override
    public AbstractServiceFactoryV2 getServiceFactory() {
        return new ServiceFactoryV2();
    }

    @Override
    protected <T1, T2> boolean isProcessingRequired(IServiceV2<T1, T2> service) {
        return Objects.nonNull(service)
                && !ThreadLocalHeaderContext.getContext().getEventContext().containsKey("sendToUI");
    }
}
