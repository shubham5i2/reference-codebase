package com.ielts.cmds.integration.factory;

import com.ielts.cmds.integration.constants.RmDistConstants;
import com.ielts.cmds.integration.mapping.BookingResultsGeneratedEventMapping;
import com.ielts.cmds.integration.mapping.BookingSearchRejectedEventMapping;
import com.ielts.cmds.integration.mapping.BookingSearchResponseGeneratedEventMapping;
import com.ielts.cmds.integration.mapping.NoActionTakenEventMapping;
import com.ielts.cmds.integration.mapping.OnHoldUpdateCompletedEventMapping;
import com.ielts.cmds.integration.mapping.OnHoldUpdateInitiationRejectedEventMapping;
import com.ielts.cmds.integration.mapping.ResultStatusChangedEventMapping;
import com.ielts.cmds.integration.mapping.ResultStatusUpdateCompletedEventMapping;
import com.ielts.cmds.serialization.lambda.dist.ui.service.AbstractServiceFactoryV2;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import java.util.HashMap;
import java.util.Map;

public class ServiceFactoryV2 extends AbstractServiceFactoryV2 {

    @SuppressWarnings("rawtypes")
    private static Map<String, IServiceV2> mapServices = new HashMap<>();

    static {
        mapServices.put(
                RmDistConstants.BOOKING_RESULT_GENERATED_EVENT_NAME,
                new BookingResultsGeneratedEventMapping());

        mapServices.put(
                RmDistConstants.RESULT_ON_HOLD_REJECTED_EVENT_NAME,
                new ResultStatusChangedEventMapping());
        mapServices.put(
                RmDistConstants.ON_HOLD_UPDATE_REJECTED_EVENT_NAME,
                new OnHoldUpdateInitiationRejectedEventMapping());
        mapServices.put(
                RmDistConstants.ON_HOLD_UPDATE_COMPLETED_EVENT_NAME,
                new OnHoldUpdateCompletedEventMapping());
        mapServices.put(
                RmDistConstants.RESULTS_STATUS_UPDATE_COMPLETED_EVENT_NAME,
                new ResultStatusUpdateCompletedEventMapping());
        mapServices.put(
                RmDistConstants.NO_ACTION_TAKEN_EVENT_NAME, new NoActionTakenEventMapping());
        mapServices.put(
                RmDistConstants.RESULTS_STATUS_CHANGED_EVENT_NAME,
                new ResultStatusChangedEventMapping());
        mapServices.put(
                RmDistConstants.BOOKING_SEARCH_RESPONSE_GENERATED_EVENT_NAME,
                new BookingSearchResponseGeneratedEventMapping());
        mapServices.put(
                RmDistConstants.BOOKING_SEARCH_REJECTED_EVENT_NAME,
                new BookingSearchRejectedEventMapping());
    }

    public ServiceFactoryV2() {
        super(mapServices);
    }

    @SuppressWarnings("unchecked")
    @Override
    public <T1, T2> IServiceV2<T1, T2> getService(String eventName) {
        return mapServices.get(eventName);
    }
}
