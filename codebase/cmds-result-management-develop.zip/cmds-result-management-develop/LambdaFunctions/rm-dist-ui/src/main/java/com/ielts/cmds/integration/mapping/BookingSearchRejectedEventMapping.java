package com.ielts.cmds.integration.mapping;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.ielts.cmds.api.rm026bookingsearchrejected.BaseEventErrors;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.BaseEventErrorsErrorListInner;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.BaseEventErrorsErrorListInner.TypeEnum;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.BaseEventErrorsErrorListInnerSource;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.ResultEnvelopeV3;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

public class BookingSearchRejectedEventMapping implements IServiceV2<BaseEventErrors, ResultEnvelopeV3> {

	@Override
	public ResultEnvelopeV3 process(BaseEventErrors cmdsEventBody) {
		final ResultEnvelopeV3 resultEnvelope = new ResultEnvelopeV3();
		resultEnvelope.setMeta(mapRequestEventHeaderToSocketResponseHeader());
		resultEnvelope.setErrors(mapRequestEventErrorsToResponseErrors(cmdsEventBody));
		return resultEnvelope;
	}

	SocketResponseMetaDataV1 mapRequestEventHeaderToSocketResponseHeader() {
		final SocketResponseMetaDataV1 responseHeaders = new SocketResponseMetaDataV1();
		if(Objects.nonNull(ThreadLocalHeaderContext.getContext())) {	
			responseHeaders.setCorrelationId(ThreadLocalHeaderContext.getContext().getCorrelationId().toString());
			responseHeaders.setConnectionId(ThreadLocalHeaderContext.getContext().getConnectionId());
		}
		return responseHeaders;
	}

	com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.BaseEventErrors mapRequestEventErrorsToResponseErrors(
			BaseEventErrors cmdsEventBody) {
		final com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.BaseEventErrors baseEventErrors = new com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.BaseEventErrors();
		List<BaseEventErrorsErrorListInner> errorResponseList = new ArrayList<>();
		cmdsEventBody.getErrorList().forEach(error -> {
			BaseEventErrorsErrorListInner errorResponse = new BaseEventErrorsErrorListInner();
			errorResponse.setErrorTicketUuid(error.getErrorTicketUuid().toString());
			errorResponse.setErrorCode(error.getErrorCode());
			errorResponse.setInterface(error.getInterface());
			errorResponse.setMessage(error.getMessage());
			errorResponse.setTitle(error.getTitle());
			if (Objects.nonNull(error.getType())) {
				errorResponse.setType(TypeEnum.fromValue(error.getType().getValue()));
			}
			BaseEventErrorsErrorListInnerSource source = new BaseEventErrorsErrorListInnerSource();
			source.setPath(error.getSource().getPath());
			source.setValue(error.getSource().getValue());
			errorResponse.setSource(source);
			errorResponseList.add(errorResponse);
		});
		baseEventErrors.setErrorList(errorResponseList);
		return baseEventErrors;
	}
}
