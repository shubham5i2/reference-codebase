package com.ielts.cmds.integration.mapper;

import com.ielts.cmds.rm.common.enums.ComponentTypeEnum;
import com.ielts.cmds.rm.common.out.model.BookingResultHistoryEventV2;
import com.ielts.cmds.rm.common.out.model.BookingResultsStatusHistoryV1;
import com.ielts.cmds.rm.common.out.model.ResultHistoryV1;
import com.ielts.cmds.rm.common.out.socketresponse.ComponentRoundInfoV1;
import com.ielts.cmds.rm.common.out.socketresponse.LatestComponentScoreV1;
import com.ielts.cmds.rm.common.out.socketresponse.LinkedBookingDetailsV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultBookingDetailsV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultDetailsEventV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultScoreInfoV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultStatusInfoV1;
import java.util.List;

public class BookingDetailsMapper {

    public ResultBookingDetailsV1 map(
            BookingResultHistoryEventV2 bookingResultHistoryEvent,
            List<ResultScoreInfoV1> resultScoreInfoList) {
        if (bookingResultHistoryEvent.getBookingResultInfo() == null) {
            return null;
        }
        com.ielts.cmds.rm.common.out.model.LinkedBookingDetailsV1 linkedBookingDetailsV1 =
                bookingResultHistoryEvent.getBookingResultInfo().getLinkedBookingDetails();
        return ResultBookingDetailsV1.builder()
                .bookingUuid(bookingResultHistoryEvent.getBookingResultInfo().getBookingUuid())
                .currentResultStatus(currentResultStatus(bookingResultHistoryEvent))
                .latestComponentScore(latestComponentRound(resultScoreInfoList))
                .personalDetails(
                        bookingResultHistoryEvent.getBookingResultInfo().getPersonalDetails())
                .productDetails(
                        bookingResultHistoryEvent.getBookingResultInfo().getProductDetails())
                .testBookingDetails(
                        bookingResultHistoryEvent.getBookingResultInfo().getTestBookingDetails())
                .resultDetails(resultDetails(bookingResultHistoryEvent))
                .linkedBookingDetails(getLinkedBookingDetailsV1(linkedBookingDetailsV1))
                .build();
    }

    private LinkedBookingDetailsV1 getLinkedBookingDetailsV1(
            com.ielts.cmds.rm.common.out.model.LinkedBookingDetailsV1 linkedBookingDetailsV1) {
        LinkedBookingDetailsV1 detailsV1 = null;
        if (linkedBookingDetailsV1 != null) {
            detailsV1 =
                    LinkedBookingDetailsV1.builder()
                            .bookingUuid(linkedBookingDetailsV1.getBookingUuid())
                            .productUuid(linkedBookingDetailsV1.getProductUuid())
                            .locationId(linkedBookingDetailsV1.getLocationId())
                            .compositeCandidateNumber(
                                    linkedBookingDetailsV1.getCompositeCandidateNumber())
                            .locationName(linkedBookingDetailsV1.getLocationName())
                            .shortCandidateNumber(linkedBookingDetailsV1.getShortCandidateNumber())
                            .testCentreName(linkedBookingDetailsV1.getTestCentreName())
                            .testCentreNumber(linkedBookingDetailsV1.getTestCentreNumber())
                            .testDate(linkedBookingDetailsV1.getTestDate())
                            .productName(linkedBookingDetailsV1.getProductName())
                            .build();
        }
        return detailsV1;
    }

    ResultDetailsEventV1 resultDetails(BookingResultHistoryEventV2 bookingResultHistoryEvent) {
        if (bookingResultHistoryEvent == null) {
                return null;
        }
        ResultDetailsEventV1 result = new ResultDetailsEventV1();
        result.setResultUuid(
                bookingResultHistoryEvent
                        .getBookingResultInfo()
                        .getResultDetails()
                        .getResultUuid());
        result.setResultScore(
                bookingResultHistoryEvent
                        .getBookingResultInfo()
                        .getResultDetails()
                        .getResultScore());
        result.setCefrLevel(
                bookingResultHistoryEvent.getBookingResultInfo().getResultDetails().getCefrLevel());
        result.setTrfNumber(
                bookingResultHistoryEvent.getBookingResultInfo().getResultDetails().getTrfNumber());

        return result;
    }

    ResultStatusInfoV1 currentResultStatus(BookingResultHistoryEventV2 bookingResultHistoryEvent) {
        BookingResultsStatusHistoryV1 getActualResultStatus = null;
        ResultHistoryV1 currentResultHistoryV1 = null;
        if (bookingResultHistoryEvent.getBookingResultsStatusHistory() != null
                && !bookingResultHistoryEvent.getBookingResultsStatusHistory().isEmpty()) {
            getActualResultStatus =
                    bookingResultHistoryEvent
                            .getBookingResultsStatusHistory()
                            .get(
                                    bookingResultHistoryEvent
                                                    .getBookingResultsStatusHistory()
                                                    .size()
                                            - 1);
        }
        if (bookingResultHistoryEvent.getBookingResultHistory() != null
                && !bookingResultHistoryEvent.getBookingResultHistory().isEmpty()) {
            currentResultHistoryV1 =
                    bookingResultHistoryEvent
                            .getBookingResultHistory()
                            .get(bookingResultHistoryEvent.getBookingResultHistory().size() - 1);
        }
        return new ResultStatusInfoMapper()
                .buildResultStatusInfo(getActualResultStatus, currentResultHistoryV1);
    }

    LatestComponentScoreV1 latestComponentRound(List<ResultScoreInfoV1> resultScoreInfoList) {
        if (resultScoreInfoList == null) {
            return null;
        }
        LatestComponentScoreV1 latest = new LatestComponentScoreV1();
        latest.setOverall(getLatestComponent(resultScoreInfoList, ComponentTypeEnum.O));
        latest.setListening(getLatestComponent(resultScoreInfoList, ComponentTypeEnum.L));
        latest.setReading(getLatestComponent(resultScoreInfoList, ComponentTypeEnum.R));
        latest.setSpeaking(getLatestComponent(resultScoreInfoList, ComponentTypeEnum.S));
        latest.setWriting(getLatestComponent(resultScoreInfoList, ComponentTypeEnum.W));

        return latest;
    }

    ComponentRoundInfoV1 getLatestComponent(
            List<ResultScoreInfoV1> resultScoreInfoList, ComponentTypeEnum componentType) {

        ResultScoreInfoV1 resultScore =
                resultScoreInfoList.stream()
                        .filter(
                                resultScoreInfoV1 ->
                                        componentType
                                                .getComponent()
                                                .equals(resultScoreInfoV1.getComponentGradeType()))
                        .findFirst()
                        .orElse(null);
        if (resultScore == null) {
            return null;
        }
        return resultScore.getComponentRounds().stream()
                .reduce((actual, next) -> next)
                .orElse(null);
    }
}
