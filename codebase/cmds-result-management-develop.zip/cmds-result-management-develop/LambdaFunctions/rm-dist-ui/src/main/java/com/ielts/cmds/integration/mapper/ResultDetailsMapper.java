package com.ielts.cmds.integration.mapper;

import com.ielts.cmds.rm.common.out.model.BookingResultHistoryEventV2;
import com.ielts.cmds.rm.common.out.socketresponse.ResultBookingDetailsV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultDetailsV2;
import com.ielts.cmds.rm.common.out.socketresponse.ResultScoreInfoV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultStatusInfoV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultTTPhotoDetailsV1;
import java.util.ArrayList;
import java.util.List;

public class ResultDetailsMapper {

    public ResultDetailsV2 map(BookingResultHistoryEventV2 bookingResultHistoryEvent) {
        List<ResultScoreInfoV1> resultScoreInfoList =
                buildResultScoreInfo(bookingResultHistoryEvent);
        return ResultDetailsV2.builder()
                .bookingDetails(
                        buildResultBookingDetails(bookingResultHistoryEvent, resultScoreInfoList))
                .resultScoreHistory(resultScoreInfoList)
                .resultStatusHistory(buildResultStatusInfo(bookingResultHistoryEvent))
                .resultTTPhotoDetails(buildResultTTPhotoDetails(bookingResultHistoryEvent))
                .build();
    }

    ResultBookingDetailsV1 buildResultBookingDetails(
            BookingResultHistoryEventV2 bookingResultHistoryEvent,
            List<ResultScoreInfoV1> resultScoreInfoList) {
        return new BookingDetailsMapper().map(bookingResultHistoryEvent, resultScoreInfoList);
    }

    List<ResultScoreInfoV1> buildResultScoreInfo(
            BookingResultHistoryEventV2 bookingResultHistoryEvent) {

        if (bookingResultHistoryEvent.getBookingResultInfo() == null) {
            return new ArrayList<>();
        }

        return new ResultScoreInfoMapper(
                        bookingResultHistoryEvent.getBookingResultInfo().getProductDetails())
                .map(bookingResultHistoryEvent.getBookingResultsScore());
    }

    List<ResultStatusInfoV1> buildResultStatusInfo(
            BookingResultHistoryEventV2 bookingResultHistoryEvent) {
        return new ResultStatusInfoMapper()
                .map(
                        bookingResultHistoryEvent.getBookingResultsStatusHistory(),
                        bookingResultHistoryEvent.getBookingResultHistory());
    }

    List<ResultTTPhotoDetailsV1> buildResultTTPhotoDetails(
            BookingResultHistoryEventV2 bookingResultHistoryEvent) {
        return new ResultTTPhotoDetailsMapper()
                .map(bookingResultHistoryEvent.getBookingResultTTPhotos());
    }
}
