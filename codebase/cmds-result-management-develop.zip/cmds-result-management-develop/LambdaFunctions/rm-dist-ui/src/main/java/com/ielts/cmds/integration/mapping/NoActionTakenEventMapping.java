package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.rm.common.out.model.NoActionTakenEventV1;
import com.ielts.cmds.rm.common.out.socketresponse.NoActionTakenDetailsV1;
import com.ielts.cmds.rm.common.out.socketresponse.NoActionTakenSocketEnvelopeV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

public class NoActionTakenEventMapping
        implements Mapper, IServiceV2<NoActionTakenEventV1, NoActionTakenSocketEnvelopeV1> {

    @Override
    public NoActionTakenSocketEnvelopeV1 process(NoActionTakenEventV1 cmdsEventBody) {
        NoActionTakenSocketEnvelopeV1 noActionTakenSocketEnvelope =
                new NoActionTakenSocketEnvelopeV1();
        noActionTakenSocketEnvelope.setMeta(mapRequestEventHeaderToSocketResponseHeader());
        noActionTakenSocketEnvelope.setResponse(mapRequestEventToResponseBody(cmdsEventBody));
        noActionTakenSocketEnvelope.setErrors(ThreadLocalErrorContext.getContext());
        return noActionTakenSocketEnvelope;
    }

    public NoActionTakenDetailsV1 mapRequestEventToResponseBody(
            NoActionTakenEventV1 cmdsEventBody) {
        return NoActionTakenDetailsV1.builder().bookingUuid(cmdsEventBody.getBookingUuid()).build();
    }
}
