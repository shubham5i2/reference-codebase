package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.integration.mapper.ResultDetailsMapper;
import com.ielts.cmds.rm.common.out.model.BookingResultHistoryEventV2;
import com.ielts.cmds.rm.common.out.socketresponse.ResultDetailsV2;
import com.ielts.cmds.rm.common.out.socketresponse.ResultEnvelopeV2;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

public class BookingResultsGeneratedEventMapping
        implements Mapper, IServiceV2<BookingResultHistoryEventV2, ResultEnvelopeV2> {

    private ResultDetailsMapper resultDetailsMapper = new ResultDetailsMapper();

    public ResultDetailsV2 mapRequestEventBodyToResponseBody(
            final BookingResultHistoryEventV2 bookingResultHistoryEvent) {
        if (bookingResultHistoryEvent == null) {
            return null;
        }
        return resultDetailsMapper.map(bookingResultHistoryEvent);
    }

    @Override
    public ResultEnvelopeV2 process(BookingResultHistoryEventV2 incomingEvent) {
        ResultEnvelopeV2 bookingResultDataOutV1Envelope = new ResultEnvelopeV2();
        bookingResultDataOutV1Envelope.setMeta(mapRequestEventHeaderToSocketResponseHeader());
        bookingResultDataOutV1Envelope.setResponse(
                mapRequestEventBodyToResponseBody(incomingEvent));
        bookingResultDataOutV1Envelope.setErrors(ThreadLocalErrorContext.getContext());
        return bookingResultDataOutV1Envelope;
    }
}
