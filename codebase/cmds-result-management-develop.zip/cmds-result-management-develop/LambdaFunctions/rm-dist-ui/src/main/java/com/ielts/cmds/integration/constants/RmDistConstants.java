package com.ielts.cmds.integration.constants;

public class RmDistConstants {
    private RmDistConstants() {}

    public static final String APPLICATION_NAME = "RM-DIST-UI-LAMBDA";
    public static final String BOOKING_RESULT_GENERATED_EVENT_NAME = "BookingResultsGenerated";
    public static final String RESULT_ON_HOLD_REJECTED_EVENT_NAME = "ResultOnHoldRejected";
    public static final String ON_HOLD_UPDATE_REJECTED_EVENT_NAME =
            "OnHoldUpdateInitiationRejected";
    public static final String ON_HOLD_UPDATE_COMPLETED_EVENT_NAME = "OnHoldUpdateCompleted";
    public static final String RESULTS_STATUS_UPDATE_COMPLETED_EVENT_NAME =
            "ResultStatusUpdateCompleted";
    public static final String NO_ACTION_TAKEN_EVENT_NAME = "NoActionTaken";
    public static final String RESULTS_STATUS_CHANGED_EVENT_NAME = "ResultStatusChanged";
    public static final String BOOKING_SEARCH_RESPONSE_GENERATED_EVENT_NAME =
            "BookingSearchResponseGenerated";
    public static final String BOOKING_SEARCH_REJECTED_EVENT_NAME = "BookingSearchRejected";
}
