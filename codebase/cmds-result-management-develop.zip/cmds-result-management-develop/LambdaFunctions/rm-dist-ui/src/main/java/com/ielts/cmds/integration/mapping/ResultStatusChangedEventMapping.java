package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.api.evt020.ResultStatus;
import com.ielts.cmds.rm.common.out.socketresponse.BookingResultChangedDetailsV1;
import com.ielts.cmds.rm.common.out.socketresponse.BookingResultChangedSocketEnvelopeV1;
import com.ielts.cmds.rm.common.out.socketresponse.BookingResultChangedSocketInfoV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

public class ResultStatusChangedEventMapping
        implements Mapper, IServiceV2<ResultStatus, BookingResultChangedSocketEnvelopeV1> {

    public BookingResultChangedDetailsV1 mapRequestEventBodyToResponseBody(
            ResultStatus resultStatus) {
        return BookingResultChangedDetailsV1.builder()
                .bookingResultInfo(getBookingResultInfo(resultStatus))
                .build();
    }

    private BookingResultChangedSocketInfoV1 getBookingResultInfo(ResultStatus resultStatus) {
        return BookingResultChangedSocketInfoV1.builder()
                .bookingUuid(resultStatus.getBooking().getBookingUuid())
                .externalBookingUuid(resultStatus.getBooking().getExternalBookingUuid())
                .onHold(resultStatus.getOnHold())
                .resultUuid(resultStatus.getResultUuid())
                .build();
    }

    @Override
    public BookingResultChangedSocketEnvelopeV1 process(ResultStatus cmdsEventBody) {
        BookingResultChangedSocketEnvelopeV1 bookingResultChangedSocketEnvelope =
                new BookingResultChangedSocketEnvelopeV1();
        bookingResultChangedSocketEnvelope.setMeta(mapRequestEventHeaderToSocketResponseHeader());
        bookingResultChangedSocketEnvelope.setResponse(
                mapRequestEventBodyToResponseBody(cmdsEventBody));
        bookingResultChangedSocketEnvelope.setErrors(ThreadLocalErrorContext.getContext());
        return bookingResultChangedSocketEnvelope;
    }
}
