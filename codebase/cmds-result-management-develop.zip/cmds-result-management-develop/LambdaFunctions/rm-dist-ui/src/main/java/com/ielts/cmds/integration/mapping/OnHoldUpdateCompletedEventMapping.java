package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.rm.common.out.model.OnHoldUpdateCompletedV1;
import com.ielts.cmds.rm.common.out.socketresponse.OnHoldUpdateCompletedDetailsV1;
import com.ielts.cmds.rm.common.out.socketresponse.OnHoldUpdateCompletedSocketEnvelopeV1;
import com.ielts.cmds.rm.common.out.socketresponse.OnHoldUpdateCompletedSummaryV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

public class OnHoldUpdateCompletedEventMapping
        implements Mapper,
                IServiceV2<OnHoldUpdateCompletedV1, OnHoldUpdateCompletedSocketEnvelopeV1> {

    public OnHoldUpdateCompletedDetailsV1 mapRequestEventBodyToResponseBody(
            OnHoldUpdateCompletedV1 eventBody) {
        return OnHoldUpdateCompletedDetailsV1.builder()
                .onHoldUpdateSummary(
                        OnHoldUpdateCompletedSummaryV1.builder()
                                .passCount(
                                        eventBody.getOnHoldUpdateSummary().getPassedUpdatesCount())
                                .failureCount(
                                        eventBody.getOnHoldUpdateSummary().getFailedUpdatesCount())
                                .build())
                .build();
    }

    @Override
    public OnHoldUpdateCompletedSocketEnvelopeV1 process(OnHoldUpdateCompletedV1 cmdsEventBody) {
        final OnHoldUpdateCompletedSocketEnvelopeV1 onHoldUpdateCompletedSocketEnvelope =
                new OnHoldUpdateCompletedSocketEnvelopeV1();
        onHoldUpdateCompletedSocketEnvelope.setMeta(mapRequestEventHeaderToSocketResponseHeader());
        onHoldUpdateCompletedSocketEnvelope.setResponse(
                mapRequestEventBodyToResponseBody(cmdsEventBody));
        onHoldUpdateCompletedSocketEnvelope.setErrors(ThreadLocalErrorContext.getContext());
        return onHoldUpdateCompletedSocketEnvelope;
    }
}
