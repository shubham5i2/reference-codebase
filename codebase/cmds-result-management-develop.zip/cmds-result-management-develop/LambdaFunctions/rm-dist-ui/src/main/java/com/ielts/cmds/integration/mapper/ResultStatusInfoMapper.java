package com.ielts.cmds.integration.mapper;

import com.ielts.cmds.rm.common.out.model.BookingResultsStatusHistoryV1;
import com.ielts.cmds.rm.common.out.model.ResultHistoryV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultStatusInfoV1;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ResultStatusInfoMapper {

    public List<ResultStatusInfoV1> map(
            List<BookingResultsStatusHistoryV1> bookingResultsStatusHistoryList,
            List<ResultHistoryV1> resultHistoryList) {

        List<BookingResultsStatusHistoryV1> bookingResultsStatusHistoryV1NonNull =
                Optional.ofNullable(bookingResultsStatusHistoryList).orElse(new ArrayList<>());
        List<ResultStatusInfoV1> resultStatusHistory =
                bookingResultsStatusHistoryV1NonNull.stream()
                        .map(this::buildResultStatusInfo)
                        .collect(Collectors.toList());

        List<ResultHistoryV1> resultHistoryV1NonNull =
                Optional.ofNullable(resultHistoryList).orElse(new ArrayList<>());
        List<ResultStatusInfoV1> resultHistory =
                resultHistoryV1NonNull.stream()
                        .map(this::buildResultStatusInfo1)
                        .collect(Collectors.toList());
        List<ResultStatusInfoV1> merge = new ArrayList<>();
        merge.addAll(resultStatusHistory);
        merge.addAll(resultHistory);
        merge.sort(Comparator.comparing(ResultStatusInfoV1::getResultStatusUpdateDatetime));
        log.debug("resultHistoryandResultStatusHistory{}", merge);
        return merge;
    }

    ResultStatusInfoV1 buildResultStatusInfo(
            BookingResultsStatusHistoryV1 bookingResultsStatusHistory) {
        if (bookingResultsStatusHistory == null) {
            return null;
        }
        return ResultStatusInfoV1.builder()
                .resultsStatusHistoryUuid(bookingResultsStatusHistory.getResultsStatusHistoryUuid())
                .resultStatusTypeUuid(bookingResultsStatusHistory.getResultStatusTypeUuid())
                .resultStatusLabelUuid(bookingResultsStatusHistory.getResultStatusLabelUuid())
                .resultStatusComment(bookingResultsStatusHistory.getResultStatusCommentText())
                .resultStatusCommentUuid(bookingResultsStatusHistory.getResultStatusCommentUuid())
                .resultStatusType(bookingResultsStatusHistory.getResultStatusType())
                .resultStatusLabel(bookingResultsStatusHistory.getResultStatusLabel())
                .resultStatusUpdateDatetime(
                        bookingResultsStatusHistory
                                .getResultStatusUpdateDatetime()
                                .toLocalDateTime())
                .resultStatusUpdatedBy(bookingResultsStatusHistory.getResultStatusUpdatedBy())
                .build();
    }

    ResultStatusInfoV1 buildResultStatusInfo1(ResultHistoryV1 resultHistory) {
        if (resultHistory == null) {
            return null;
        }
        return ResultStatusInfoV1.builder()
                .onHold(resultHistory.getOnHold())
                .resultStatusUpdatedBy(resultHistory.getOnHoldUpdatedBy())
                .resultStatusUpdateDatetime(
                        resultHistory.getOnHoldUpdatedDateTime().toLocalDateTime())
                .build();
    }

    ResultStatusInfoV1 buildResultStatusInfo(
            BookingResultsStatusHistoryV1 bookingResultsStatusHistoryV1,
            ResultHistoryV1 resultHistoryV1) {
        ResultStatusInfoV1 resultStatusInfoV1 =
                buildResultStatusInfo(bookingResultsStatusHistoryV1);
        if (Objects.nonNull(resultStatusInfoV1) && Objects.nonNull(resultHistoryV1)) {
            resultStatusInfoV1.setOnHold(resultHistoryV1.getOnHold());
        }
        return resultStatusInfoV1;
    }
}
