package com.ielts.cmds.integration.mapper;

import com.ielts.cmds.rm.common.enums.ComponentTypeEnum;
import com.ielts.cmds.rm.common.out.model.ComponentGradesInfoV1;
import com.ielts.cmds.rm.common.out.model.MarksGeneratedEventV1;
import com.ielts.cmds.rm.common.out.model.ProductGeneratedEventV1;
import com.ielts.cmds.rm.common.out.socketresponse.ComponentRoundInfoV1;
import com.ielts.cmds.rm.common.out.socketresponse.CriteriaV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultScoreInfoV1;
import com.ielts.cmds.rm.common.out.socketresponse.TaskInfoV1;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ResultScoreInfoMapper {

    private final Map<UUID, ComponentTypeEnum> productTypes;

    public ResultScoreInfoMapper(List<ProductGeneratedEventV1> productGeneratedEventList) {
        this.productTypes =
                productGeneratedEventList.stream()
                        .collect(
                                Collectors.toMap(
                                        ProductGeneratedEventV1::getProductUuid,
                                        productGeneratedEventV1 ->
                                                ComponentTypeEnum.valueOf(
                                                        productGeneratedEventV1.getComponent())));
    }

    public List<ResultScoreInfoV1> map(List<ComponentGradesInfoV1> componentGradesInfoV1s) {
        Map<ComponentTypeEnum, ResultScoreInfoV1> resultScoreInfoMap =
                Stream.of(ComponentTypeEnum.values())
                        .collect(
                                Collectors.toMap(
                                        Function.identity(),
                                        componentTypeEnum ->
                                                ResultScoreInfoV1.builder()
                                                        .componentGradeType(
                                                                componentTypeEnum.getComponent())
                                                        .componentRounds(new ArrayList<>())
                                                        .build()));
        componentGradesInfoV1s.forEach(
                componentGradesInfoV1 ->
                        resultScoreInfoMap
                                .get(
                                        productTypes.getOrDefault(
                                                componentGradesInfoV1.getProductUuid(),
                                                ComponentTypeEnum.O))
                                .getComponentRounds()
                                .add(addComponentRoundInfo(componentGradesInfoV1)));

        return new ArrayList<>(resultScoreInfoMap.values());
    }

    private ComponentRoundInfoV1 addComponentRoundInfo(
            ComponentGradesInfoV1 componentGradesInfoV1) {
        return ComponentRoundInfoV1.builder()
                .componentEvaluationRoundId(componentGradesInfoV1.getComponentEvaluationRoundId())
                .dateReceived(componentGradesInfoV1.getComponentReceivedDate().toLocalDateTime())
                .overallFinalGrade(componentGradesInfoV1.getComponentFinalGrade())
                .overallResultType(componentGradesInfoV1.getComponentResultType())
                .rawScore(componentGradesInfoV1.getTotalScore())
                .tasks(buildTaskInfo(componentGradesInfoV1))
                .isUpdated(componentGradesInfoV1.getIsUpdated())
                .build();
    }

    List<TaskInfoV1> buildTaskInfo(ComponentGradesInfoV1 componentGradesInfo) {
        // For NOT writing nor speaking no task is created
        ComponentTypeEnum componentType =
                productTypes.getOrDefault(
                        componentGradesInfo.getProductUuid(), ComponentTypeEnum.O);
        if (componentType != ComponentTypeEnum.W && componentType != ComponentTypeEnum.S) {
            return Collections.emptyList();
        }

        List<TaskInfoV1> tasksInfo = new ArrayList<>();

        for (int i = 0; i < componentGradesInfo.getEvaluations().size(); i++) {
            TaskInfoV1 task = new TaskInfoV1();
            task.setTaskNumber(i + 1);
            task.setExaminer(componentGradesInfo.getEvaluations().get(i).getEvaluatorId());
            task.setCriterias(
                    buildCriteria(componentGradesInfo.getEvaluations().get(i).getMarks()));
            tasksInfo.add(task);
        }
        return tasksInfo;
    }

    List<CriteriaV1> buildCriteria(List<MarksGeneratedEventV1> marksGeneratedEvent) {
        return marksGeneratedEvent.stream()
                .map(
                        mark ->
                                new CriteriaV1(
                                        mark.getCriteriaUuid(),
                                        mark.getCriteriaValue(),
                                        mark.getRewardMarks()))
                .collect(Collectors.toList());
    }
}
