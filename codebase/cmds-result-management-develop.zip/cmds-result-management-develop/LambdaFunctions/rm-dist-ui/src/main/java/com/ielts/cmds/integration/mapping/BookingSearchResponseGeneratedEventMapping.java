package com.ielts.cmds.integration.mapping;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import javax.validation.Valid;

import com.ielts.cmds.api.rm025bookingsearchresponsegenerated.BookingSearchResponseResultV1;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.BookingDetailsV1;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.BookingDetailsV1.BannedStatusEnum;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.BookingDetailsV1.BookingDetailStatusEnum;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.BookingDetailsV1.BookingStatusEnum;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.BookingSearchResponseResultListV1;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.BookingSearchResultV1;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.ProductDetailsV1;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.ResultDetailsV1;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.ResultEnvelopeV3;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.ResultLineDetailsV1;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.ResultsStatusCommentDetailsV1;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.ResultsStatusDetailsV1;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.ResultsStatusLabelDetailsV1;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.ResultsStatusTypeDetailsV1;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.SocketResponseMetaDataV1;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.TestCentreDetailsV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

public class BookingSearchResponseGeneratedEventMapping
		implements IServiceV2<BookingSearchResponseResultV1, ResultEnvelopeV3> {

	@Override
	public ResultEnvelopeV3 process(BookingSearchResponseResultV1 cmdsEventBody) {
		final ResultEnvelopeV3 resultEnvelope = new ResultEnvelopeV3();
		resultEnvelope.setMeta(mapRequestEventHeaderToSocketResponseHeader());
		resultEnvelope.setResponse(mapRequestEventBodyToResponseBody(cmdsEventBody.getResult()));
		return resultEnvelope;
	}

	SocketResponseMetaDataV1 mapRequestEventHeaderToSocketResponseHeader() {
		final SocketResponseMetaDataV1 responseHeaders = new SocketResponseMetaDataV1();
		if(Objects.nonNull(ThreadLocalHeaderContext.getContext())) {			
			responseHeaders.setCorrelationId(ThreadLocalHeaderContext.getContext().getCorrelationId().toString());
			responseHeaders.setConnectionId(ThreadLocalHeaderContext.getContext().getConnectionId());
		}
		return responseHeaders;
	}

	com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.BookingSearchResponseResultV1 mapRequestEventBodyToResponseBody(
			com.ielts.cmds.api.rm025bookingsearchresponsegenerated.BookingSearchResponseResultListV1 bookingSearchResponseResultListV1) {
		final com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.BookingSearchResponseResultV1 bookingSearchResponseResult = new com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.BookingSearchResponseResultV1();
		bookingSearchResponseResult.setResult(buildResult(bookingSearchResponseResultListV1));
		return bookingSearchResponseResult;
	}

	BookingSearchResponseResultListV1 buildResult(
			com.ielts.cmds.api.rm025bookingsearchresponsegenerated.@Valid BookingSearchResponseResultListV1 bookingSearchResponseResultListV1) {
		final BookingSearchResponseResultListV1 bookingSearchResponseResultList = new BookingSearchResponseResultListV1();
		bookingSearchResponseResultList.setEntries(buildEntries(bookingSearchResponseResultListV1.getEntries()));
		bookingSearchResponseResultList.setTotalCount(bookingSearchResponseResultListV1.getTotalCount());
		return bookingSearchResponseResultList;
	}

	List<BookingSearchResultV1> buildEntries(
			@Valid List<com.ielts.cmds.api.rm025bookingsearchresponsegenerated.BookingSearchResultV1> entries) {
		final List<BookingSearchResultV1> bookingSearchOutputList = new ArrayList<>();
		entries.stream().forEach(entry -> {
			final BookingSearchResultV1 bookingResult = new BookingSearchResultV1();
			bookingResult.setBookingDetails(buildBookingDetails(entry.getBookingDetails()));
			bookingResult.setResultDetails(buildResultDetails(entry.getResultDetails()));
			bookingSearchOutputList.add(bookingResult);
		});
		return bookingSearchOutputList;
	}

	ResultDetailsV1 buildResultDetails(
			com.ielts.cmds.api.rm025bookingsearchresponsegenerated.@Valid ResultDetailsV1 resultDetailsV1) {
		final ResultDetailsV1 resultDetails = new ResultDetailsV1();
		resultDetails.setOnHold(resultDetailsV1.getOnHold());
		resultDetails.setProductInfo(buildProductInfo(resultDetailsV1.getProductInfo()));
		resultDetails.setResultLineDetails(buildResultLineDetails(resultDetailsV1.getResultLineDetails()));
		resultDetails.setResultScore(resultDetailsV1.getResultScore());
		if(Objects.nonNull(resultDetailsV1.getResultsStatus())) {
			resultDetails.setResultsStatus(buildResultsStatus(resultDetailsV1.getResultsStatus()));
		}
		resultDetails.setResultUuid(resultDetailsV1.getResultUuid());
		return resultDetails;
	}

	ResultsStatusDetailsV1 buildResultsStatus(
			com.ielts.cmds.api.rm025bookingsearchresponsegenerated.@Valid ResultsStatusDetailsV1 resultsStatus) {
		final ResultsStatusDetailsV1 resultStatusDetails = new ResultsStatusDetailsV1();
		resultStatusDetails.setResultsStatusHistoryUuid(resultsStatus.getResultsStatusHistoryUuid());
		if(Objects.nonNull(resultsStatus.getResultsStatusComment())) {			
			resultStatusDetails.setResultsStatusComment(buildResultsStatusComment(resultsStatus.getResultsStatusComment()));
		}
		if(Objects.nonNull(resultsStatus.getResultsStatusLabel())) {			
			resultStatusDetails.setResultsStatusLabel(buildResultsStatusLabel(resultsStatus.getResultsStatusLabel()));
		}
		if(Objects.nonNull(resultsStatus.getResultsStatusType())) {			
			resultStatusDetails.setResultsStatusType(buildResultsStatusType(resultsStatus.getResultsStatusType()));
		}
		return resultStatusDetails;
	}

	ResultsStatusTypeDetailsV1 buildResultsStatusType(
			com.ielts.cmds.api.rm025bookingsearchresponsegenerated.ResultsStatusTypeDetailsV1 resultsStatusTypeDetailsV1) {
		final ResultsStatusTypeDetailsV1 resultStatusDetails = new ResultsStatusTypeDetailsV1();
		resultStatusDetails.setResultsStatusTypeUuid(resultsStatusTypeDetailsV1.getResultsStatusTypeUuid());
		resultStatusDetails.setResultsStatusTypeValue(resultsStatusTypeDetailsV1.getResultsStatusTypeValue());
		return resultStatusDetails;
	}

	ResultsStatusLabelDetailsV1 buildResultsStatusLabel(
			com.ielts.cmds.api.rm025bookingsearchresponsegenerated.ResultsStatusLabelDetailsV1 resultsStatusLabelDetailsV1) {
		final ResultsStatusLabelDetailsV1 resultStatusLabelDetails = new ResultsStatusLabelDetailsV1();
		resultStatusLabelDetails.setResultsStatusLabelUuid(resultsStatusLabelDetailsV1.getResultsStatusLabelUuid());
		resultStatusLabelDetails.setResultsStatusLabelValue(resultsStatusLabelDetailsV1.getResultsStatusLabelValue());
		return resultStatusLabelDetails;
	}

	ResultsStatusCommentDetailsV1 buildResultsStatusComment(
			com.ielts.cmds.api.rm025bookingsearchresponsegenerated.ResultsStatusCommentDetailsV1 resultsStatusCommentDetailsV1) {
		final ResultsStatusCommentDetailsV1 resultStatusCommentDetails = new ResultsStatusCommentDetailsV1();
		resultStatusCommentDetails
				.setResultsStatusCommentUuid(resultsStatusCommentDetailsV1.getResultsStatusCommentUuid());
		resultStatusCommentDetails
				.setResultsStatusCommentValue(resultsStatusCommentDetailsV1.getResultsStatusCommentValue());
		return resultStatusCommentDetails;
	}

	List<ResultLineDetailsV1> buildResultLineDetails(
			@Valid List<com.ielts.cmds.api.rm025bookingsearchresponsegenerated.ResultLineDetailsV1> inputResultLineList) {
		final List<ResultLineDetailsV1> outputResultLineList = new ArrayList<>();
		inputResultLineList.stream().forEach(line -> {
			final ResultLineDetailsV1 resultLine = new ResultLineDetailsV1();
			resultLine.setComponentInfo(buildProductInfo(line.getComponentInfo()));
			resultLine.setResultLineScore(line.getResultLineScore());
			resultLine.setResultLineUuid(line.getResultLineUuid());
			outputResultLineList.add(resultLine);
		});
		return outputResultLineList;
	}

	ProductDetailsV1 buildProductInfo(
			com.ielts.cmds.api.rm025bookingsearchresponsegenerated.@Valid ProductDetailsV1 productInfo) {
		final ProductDetailsV1 productDetails = new ProductDetailsV1();
		productDetails.setComponent(productInfo.getComponent());
		productDetails.setProductName(productInfo.getProductName());
		productDetails.setProductUuid(productInfo.getProductUuid());
		return productDetails;
	}

	BookingDetailsV1 buildBookingDetails(
			com.ielts.cmds.api.rm025bookingsearchresponsegenerated.@Valid BookingDetailsV1 bookingDetailsV1) {
		final BookingDetailsV1 bookingDetails = new BookingDetailsV1();
		bookingDetails.setBannedStatus(buildBannedStatus(bookingDetailsV1.getBannedStatus()));
		bookingDetails.setBirthDate(bookingDetailsV1.getBirthDate());
		bookingDetails.setBookingDetailStatus(buildBookingDetailStatus(bookingDetailsV1.getBookingDetailStatus()));
		bookingDetails.setBookingStatus(buildBookingStatus(bookingDetailsV1.getBookingStatus()));
		bookingDetails.setBookingUuid(bookingDetailsV1.getBookingUuid());
		bookingDetails.setExternalBookingUuid(bookingDetailsV1.getExternalBookingUuid());
		bookingDetails.setFinancialYear(bookingDetailsV1.getFinancialYear());
		bookingDetails.setFirstName(bookingDetailsV1.getFirstName());
		bookingDetails.setIdentityNumber(bookingDetailsV1.getIdentityNumber());
		bookingDetails.setIsVoid(bookingDetailsV1.getIsVoid());
		bookingDetails.setLastName(bookingDetailsV1.getLastName());
		bookingDetails.setLocationUuid(bookingDetailsV1.getLocationUuid());
		bookingDetails.setNationalityOther(bookingDetailsV1.getNationalityOther());
		bookingDetails.setNationalityUuid(bookingDetailsV1.getNationalityUuid());
		bookingDetails.setPartnerCode(bookingDetailsV1.getPartnerCode());
		bookingDetails.setProductUuid(bookingDetailsV1.getProductUuid());
		bookingDetails.setShortCandidateNumber(bookingDetailsV1.getShortCandidateNumber());
		bookingDetails.setTestCentreInfo(buildTestCentreInfo(bookingDetailsV1.getTestCentreInfo()));
		bookingDetails.setTestDate(bookingDetailsV1.getTestDate());
		bookingDetails.setTitle(bookingDetailsV1.getTitle());
		bookingDetails.setUniqueTestTakerId(bookingDetailsV1.getUniqueTestTakerId());
		bookingDetails.setUniqueTestTakerUuid(bookingDetailsV1.getUniqueTestTakerUuid());
		return bookingDetails;
	}

	TestCentreDetailsV1 buildTestCentreInfo(
			com.ielts.cmds.api.rm025bookingsearchresponsegenerated.@Valid TestCentreDetailsV1 testCentreInfo) {
		final TestCentreDetailsV1 testCentreDetails = new TestCentreDetailsV1();
		testCentreDetails.setLocationUuid(testCentreInfo.getLocationUuid());
		testCentreDetails.setTestCentreNumber(testCentreInfo.getTestCentreNumber());
		testCentreDetails.setTestCentreUuid(testCentreInfo.getTestCentreUuid());
		return testCentreDetails;
	}

	BookingStatusEnum buildBookingStatus(
			com.ielts.cmds.api.rm025bookingsearchresponsegenerated.BookingDetailsV1.BookingStatusEnum bookingStatus) {
		if (Optional.ofNullable(bookingStatus.getValue()).isPresent()) {
			return BookingDetailsV1.BookingStatusEnum.valueOf(bookingStatus.getValue());
		}
		return null;

	}

	BookingDetailStatusEnum buildBookingDetailStatus(
			com.ielts.cmds.api.rm025bookingsearchresponsegenerated.BookingDetailsV1.BookingDetailStatusEnum bookingDetailStatus) {
		if (Optional.ofNullable(bookingDetailStatus.getValue()).isPresent()) {
			return BookingDetailStatusEnum.valueOf(bookingDetailStatus.getValue());
		}
		return null;
	}

	BannedStatusEnum buildBannedStatus(
			com.ielts.cmds.api.rm025bookingsearchresponsegenerated.BookingDetailsV1.BannedStatusEnum bannedStatus) {
		if (Optional.ofNullable(bannedStatus.getValue()).isPresent()) {
			return BannedStatusEnum.valueOf(bannedStatus.getValue());
		}
		return null;
	}

}