package com.ielts.cmds.integration.mapper;

import com.ielts.cmds.rm.common.out.model.ResultTTPhotoV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultTTPhotoDetailsV1;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ResultTTPhotoDetailsMapper {

    public List<ResultTTPhotoDetailsV1> map(List<ResultTTPhotoV1> resultTTPhotoList) {

        if (resultTTPhotoList == null) {
            return new ArrayList<>();
        }

        return resultTTPhotoList.stream()
                .map(
                        resultTTPhoto ->
                                ResultTTPhotoDetailsV1.builder()
                                        .photoType(resultTTPhoto.getPhotoType())
                                        .photoUrl(resultTTPhoto.getPhotoUrl())
                                        .photoUuid(resultTTPhoto.getPhotoUuid())
                                        .build())
                .collect(Collectors.toList());
    }
}
