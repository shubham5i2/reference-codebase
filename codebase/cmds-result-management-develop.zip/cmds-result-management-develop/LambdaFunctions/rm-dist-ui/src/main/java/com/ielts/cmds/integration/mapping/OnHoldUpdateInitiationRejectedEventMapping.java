package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.rm.common.out.model.OnHoldUpdateInitiatedV1;
import com.ielts.cmds.rm.common.out.socketresponse.OnHoldUpdateInitiatedDetailsV1;
import com.ielts.cmds.rm.common.out.socketresponse.OnHoldUpdateInitiatedSocketEnvelopeV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

public class OnHoldUpdateInitiationRejectedEventMapping
        implements Mapper,
                IServiceV2<OnHoldUpdateInitiatedV1, OnHoldUpdateInitiatedSocketEnvelopeV1> {

    @Override
    public OnHoldUpdateInitiatedSocketEnvelopeV1 process(OnHoldUpdateInitiatedV1 cmdsEventBody) {
        OnHoldUpdateInitiatedSocketEnvelopeV1 onHoldUpdateInitiatedSocketEnvelope =
                new OnHoldUpdateInitiatedSocketEnvelopeV1();
        onHoldUpdateInitiatedSocketEnvelope.setMeta(mapRequestEventHeaderToSocketResponseHeader());
        onHoldUpdateInitiatedSocketEnvelope.setResponse(
                mapRequestEventToResponseBody(cmdsEventBody));
        onHoldUpdateInitiatedSocketEnvelope.setErrors(ThreadLocalErrorContext.getContext());
        return onHoldUpdateInitiatedSocketEnvelope;
    }

    public OnHoldUpdateInitiatedDetailsV1 mapRequestEventToResponseBody(
            OnHoldUpdateInitiatedV1 cmdsEventBody) {
        return OnHoldUpdateInitiatedDetailsV1.builder()
                .bookingUuids(cmdsEventBody.getBookingUuids())
                .onHold(cmdsEventBody.getOnHold())
                .build();
    }
}
