package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.integration.mapper.ResultStatusUpdateSummaryMapper;
import com.ielts.cmds.rm.common.out.model.ResultStatusUpdateCompletedV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultsStatusUpdateCompletedDetailsV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultsStatusUpdateCompletedSocketEnvelopeV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

public class ResultStatusUpdateCompletedEventMapping
        implements Mapper,
                IServiceV2<
                        ResultStatusUpdateCompletedV1,
                        ResultsStatusUpdateCompletedSocketEnvelopeV1> {

    public ResultsStatusUpdateCompletedDetailsV1 mapRequestEventBodyToResponseBody(
            final ResultStatusUpdateCompletedV1 resultStatusUpdateCompletedV1) {
        if (resultStatusUpdateCompletedV1 == null) {
            return null;
        }
        return ResultsStatusUpdateCompletedDetailsV1.builder()
                .resultStatusUpdateSummary(
                        new ResultStatusUpdateSummaryMapper()
                                .map(resultStatusUpdateCompletedV1.getResultStatusUpdateSummary()))
                .build();
    }

    @Override
    public ResultsStatusUpdateCompletedSocketEnvelopeV1 process(
            ResultStatusUpdateCompletedV1 cmdsEventBody) {
        ResultsStatusUpdateCompletedSocketEnvelopeV1 resultsStatusUpdateCompletedSocketEnvelope =
                new ResultsStatusUpdateCompletedSocketEnvelopeV1();
        resultsStatusUpdateCompletedSocketEnvelope.setMeta(
                mapRequestEventHeaderToSocketResponseHeader());
        resultsStatusUpdateCompletedSocketEnvelope.setResponse(
                mapRequestEventBodyToResponseBody(cmdsEventBody));
        resultsStatusUpdateCompletedSocketEnvelope.setErrors(ThreadLocalErrorContext.getContext());
        return resultsStatusUpdateCompletedSocketEnvelope;
    }
}
