package com.ielts.cmds.integration.mapper;

import com.ielts.cmds.rm.common.out.model.ResultStatusUpdateSummaryV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultsStatusUpdateCompletedSummaryV1;

public class ResultStatusUpdateSummaryMapper {

    public ResultsStatusUpdateCompletedSummaryV1 map(
            ResultStatusUpdateSummaryV1 resultStatusUpdateSummary) {

        if (resultStatusUpdateSummary == null) {
            return null;
        }

        return ResultsStatusUpdateCompletedSummaryV1.builder()
                .failureCount(resultStatusUpdateSummary.getFailedUpdatesCount())
                .passCount(resultStatusUpdateSummary.getPassedUpdatesCount())
                .build();
    }
}
