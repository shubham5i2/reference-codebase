package com.ielts.cmds.integration.mapping;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

import com.ielts.cmds.api.evt020.ResultStatus;
import com.ielts.cmds.integration.testdata.setup.RMCommonTestDataSetup;
import com.ielts.cmds.integration.testdata.setup.ResultStatusTestDataSetup;
import com.ielts.cmds.rm.common.out.socketresponse.BookingResultChangedDetailsV1;
import com.ielts.cmds.rm.common.out.socketresponse.BookingResultChangedSocketEnvelopeV1;
import com.ielts.cmds.rm.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ResultStatusChangedEventMappingTest {

    @Spy @InjectMocks ResultStatusChangedEventMapping resultStatusChangedEventMapping;

    @Test
    void getEnvelopeObject_ShouldReturnValidBookingResultDataOutV1Envelope_whenValidParameters() {

        BookingResultChangedSocketEnvelopeV1 bookingResultChangedSocketEnvelopeV1 =
                new BookingResultChangedSocketEnvelopeV1();
        final SocketResponseMetaDataV1 responseHeaders =
                RMCommonTestDataSetup.mapRequestEventHeader();
        ResultStatus eventBody = ResultStatusTestDataSetup.buildResultStatus();
        BookingResultChangedDetailsV1 response =
                ResultStatusTestDataSetup.buildBookingResultChangedDetailsV1(eventBody);
        bookingResultChangedSocketEnvelopeV1.setErrors(ThreadLocalErrorContext.getContext());
        bookingResultChangedSocketEnvelopeV1.setMeta(responseHeaders);
        bookingResultChangedSocketEnvelopeV1.setResponse(response);
        doReturn(response)
                .when(resultStatusChangedEventMapping)
                .mapRequestEventBodyToResponseBody(eventBody);
        doReturn(responseHeaders)
                .when(resultStatusChangedEventMapping)
                .mapRequestEventHeaderToSocketResponseHeader();
        BookingResultChangedSocketEnvelopeV1 actual =
                resultStatusChangedEventMapping.process(eventBody);
        assertEquals(
                response.getBookingResultInfo().getBookingUuid(),
                actual.getResponse().getBookingResultInfo().getBookingUuid());
        assertEquals(
                response.getBookingResultInfo().getExternalBookingUuid(),
                actual.getResponse().getBookingResultInfo().getExternalBookingUuid());
    }

    @Test
    void
            mapRequestEventBodyToResponseBody_ShouldReturnBookingResultChangedDetailsV1_WhenGetsResultStatus() {
        ResultStatus eventBody = ResultStatusTestDataSetup.buildResultStatus();
        BookingResultChangedDetailsV1 actual =
                resultStatusChangedEventMapping.mapRequestEventBodyToResponseBody(eventBody);
        assertAll(
                () ->
                        assertEquals(
                                actual.getBookingResultInfo().getBookingUuid(),
                                eventBody.getBooking().getBookingUuid()),
                () ->
                        assertEquals(
                                actual.getBookingResultInfo().getOnHold(), eventBody.getOnHold()));
    }
}
