package com.ielts.cmds.integration.mapping;


import java.util.List;
import java.util.UUID;

import javax.validation.Valid;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.api.rm025bookingsearchresponsegenerated.BookingSearchResponseResultListV1;
import com.ielts.cmds.api.rm025bookingsearchresponsegenerated.BookingSearchResponseResultV1;
import com.ielts.cmds.api.rm025bookingsearchresponsegenerated.ResultsStatusTypeDetailsV1;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.BookingDetailsV1;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.BookingDetailsV1.BannedStatusEnum;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.BookingDetailsV1.BookingDetailStatusEnum;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.BookingDetailsV1.BookingStatusEnum;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.BookingSearchResultV1;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.ProductDetailsV1;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.ResultEnvelopeV3;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.ResultLineDetailsV1;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.ResultsStatusCommentDetailsV1;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.ResultsStatusDetailsV1;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.ResultsStatusLabelDetailsV1;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.SocketResponseMetaDataV1;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.TestCentreDetailsV1;
import com.ielts.cmds.integration.testdata.setup.BookingSearchTestDataSetup;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(MockitoExtension.class)
class BookingSearchResponseGeneratedEventMappingTest {

	@InjectMocks
	private BookingSearchResponseGeneratedEventMapping bookingSearchResponseGeneratedEventMapping;

	@BeforeEach
	void setup() {
		HeaderContext headerContext = new HeaderContext();
		headerContext.setConnectionId(UUID.randomUUID().toString());
		headerContext.setCorrelationId(UUID.randomUUID());
		ThreadLocalHeaderContext.setContext(headerContext);
	}

	@Test
	void when_CallingProcess_ExpectResultEnvelopeToBeSet() {
		BookingSearchResponseResultV1 cmdsEventBody = BookingSearchTestDataSetup.getBookingSearchResponse();
		final ResultEnvelopeV3 resultEnvelope = bookingSearchResponseGeneratedEventMapping.process(cmdsEventBody);
		assertNotNull(resultEnvelope);
		assertEquals(cmdsEventBody.getResult().getEntries().size(),
				resultEnvelope.getResponse().getResult().getEntries().size());
		assertEquals(cmdsEventBody.getResult().getTotalCount(),
				resultEnvelope.getResponse().getResult().getTotalCount());
	}

	@Test
	void when_mapRequestEventHeaderToSocketResponseHeader_MetaInfoIsSet() {
		final SocketResponseMetaDataV1 socketMetaResponse = bookingSearchResponseGeneratedEventMapping
				.mapRequestEventHeaderToSocketResponseHeader();
		assertEquals(ThreadLocalHeaderContext.getContext().getCorrelationId().toString(), socketMetaResponse.getCorrelationId());
		assertEquals(ThreadLocalHeaderContext.getContext().getConnectionId(), socketMetaResponse.getConnectionId());
	}

	@Test
	void when_mapRequestEventHeaderToSocketResponseHeader_MetaInfoIsNotSet() {
		ThreadLocalHeaderContext.setContext(null);
		final SocketResponseMetaDataV1 socketMetaResponse = bookingSearchResponseGeneratedEventMapping
				.mapRequestEventHeaderToSocketResponseHeader();
		assertNull(socketMetaResponse.getCorrelationId());
		assertNull(socketMetaResponse.getConnectionId());
	}

	@Test
	void when_CallingBuildResponse_ExpectBookingSearchResponseResultToBeSet() {
		BookingSearchResponseResultListV1 result = BookingSearchTestDataSetup.getBuildResult();
		final com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.BookingSearchResponseResultV1 bookingSearchResponseResult = bookingSearchResponseGeneratedEventMapping
				.mapRequestEventBodyToResponseBody(result);
		assertNotNull(bookingSearchResponseResult);
		assertEquals(result.getEntries().size(), bookingSearchResponseResult.getResult().getEntries().size());
		assertEquals(result.getTotalCount(), bookingSearchResponseResult.getResult().getTotalCount());
	}

	@Test
	void when_CallingBuildResult_ExpectBookingSearchResponseResultListToBeSet() {
		@Valid
		BookingSearchResponseResultListV1 resultList = BookingSearchTestDataSetup.getBuildResult();
		final com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.BookingSearchResponseResultListV1 bookingSearchResponseResultList = bookingSearchResponseGeneratedEventMapping
				.buildResult(resultList);
		assertNotNull(bookingSearchResponseResultList);
		assertEquals(resultList.getEntries().size(), bookingSearchResponseResultList.getEntries().size());
		assertEquals(resultList.getTotalCount(), bookingSearchResponseResultList.getTotalCount());
	}

	@Test
	void when_CallingBuildEntries_ExpectListOfBookingSearchResultToBeSet() {
		@Valid
		List<com.ielts.cmds.api.rm025bookingsearchresponsegenerated.BookingSearchResultV1> entries = BookingSearchTestDataSetup
				.getResultEntries();
		final List<BookingSearchResultV1> bookingSearchOutputList = bookingSearchResponseGeneratedEventMapping
				.buildEntries(entries);
		assertNotNull(bookingSearchOutputList);
		assertEquals(entries.size(), bookingSearchOutputList.size());
	}

	@Test
	void when_CallingBuildResultDetails_ExpectResultsStatusDetailsToBeSet() {
		com.ielts.cmds.api.rm025bookingsearchresponsegenerated.@Valid ResultsStatusDetailsV1 resultsStatus = BookingSearchTestDataSetup
				.getResultsStatus();
		final ResultsStatusDetailsV1 resultsStatusDetails = bookingSearchResponseGeneratedEventMapping
				.buildResultsStatus(resultsStatus);
		assertNotNull(resultsStatusDetails);
		assertEquals(resultsStatus.getResultsStatusHistoryUuid(), resultsStatusDetails.getResultsStatusHistoryUuid());
	}

	@Test
	void when_CallingBuildResultDetails_FieldsNull_ExpectResultsStatusDetailsToBeNull() {
		com.ielts.cmds.api.rm025bookingsearchresponsegenerated.@Valid ResultsStatusDetailsV1 resultsStatus = BookingSearchTestDataSetup
				.getResultsStatus();
		resultsStatus.setResultsStatusHistoryUuid(null);
		resultsStatus.setResultsStatusType(null);
		resultsStatus.setResultsStatusLabel(null);
		resultsStatus.setResultsStatusComment(null);
		final ResultsStatusDetailsV1 resultsStatusDetails = bookingSearchResponseGeneratedEventMapping
				.buildResultsStatus(resultsStatus);
		assertNotNull(resultsStatusDetails);
		assertNull(resultsStatusDetails.getResultsStatusHistoryUuid());
		assertNull(resultsStatusDetails.getResultsStatusType());
		assertNull(resultsStatusDetails.getResultsStatusLabel());
		assertNull(resultsStatusDetails.getResultsStatusComment());
	}

	@Test
	void when_CallingBuildResultsStatusType_ExpectResultsStatusTypeDetailsToBeSet() {
		ResultsStatusTypeDetailsV1 resultsStatusTypeDetails = BookingSearchTestDataSetup
				.getResultsStatusType();
		final com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.ResultsStatusTypeDetailsV1 resultDetails = bookingSearchResponseGeneratedEventMapping
				.buildResultsStatusType(resultsStatusTypeDetails);
		assertNotNull(resultDetails);
		assertEquals(resultsStatusTypeDetails.getResultsStatusTypeUuid(), resultDetails.getResultsStatusTypeUuid());
		assertEquals(resultsStatusTypeDetails.getResultsStatusTypeValue(), resultDetails.getResultsStatusTypeValue());
	}

	@Test
	void when_CallingbuildResultsStatusLabel_ExpectResultsStatusLabelDetailsToBe() {
		com.ielts.cmds.api.rm025bookingsearchresponsegenerated.ResultsStatusLabelDetailsV1 resultsStatusLabelDetails = BookingSearchTestDataSetup
				.getResultsStatusLabel();
		final ResultsStatusLabelDetailsV1 detailsV1 = bookingSearchResponseGeneratedEventMapping
				.buildResultsStatusLabel(resultsStatusLabelDetails);
		assertNotNull(detailsV1);
		assertEquals(resultsStatusLabelDetails.getResultsStatusLabelUuid(), detailsV1.getResultsStatusLabelUuid());
		assertEquals(resultsStatusLabelDetails.getResultsStatusLabelValue(), detailsV1.getResultsStatusLabelValue());
	}

	@Test
	void when_CallingBuildResultsStatusComment_ExpectResultsStatusCommentDetailsToBeSet() {
		com.ielts.cmds.api.rm025bookingsearchresponsegenerated.ResultsStatusCommentDetailsV1 resultsStatusCommentDetails = BookingSearchTestDataSetup
				.getResultsStatusComment();
		final ResultsStatusCommentDetailsV1 commentDetails = bookingSearchResponseGeneratedEventMapping
				.buildResultsStatusComment(resultsStatusCommentDetails);
		assertNotNull(commentDetails);
		assertEquals(resultsStatusCommentDetails.getResultsStatusCommentUuid(),
				commentDetails.getResultsStatusCommentUuid());
		assertEquals(resultsStatusCommentDetails.getResultsStatusCommentValue(),
				commentDetails.getResultsStatusCommentValue());
	}

	@Test
	void when_CallingBuildResultLineDetails_ExpectListOfResultLineDetailsV1ToBeSet() {
		@Valid
		List<com.ielts.cmds.api.rm025bookingsearchresponsegenerated.ResultLineDetailsV1> resultLineDetails = BookingSearchTestDataSetup
				.getResultLineDetails();
		final List<ResultLineDetailsV1> detailsV1s = bookingSearchResponseGeneratedEventMapping
				.buildResultLineDetails(resultLineDetails);
		assertNotNull(detailsV1s);
		assertEquals(resultLineDetails.get(0).getResultLineScore(), detailsV1s.get(0).getResultLineScore());
		assertEquals(resultLineDetails.get(0).getResultLineUuid(), detailsV1s.get(0).getResultLineUuid());
	}

	@Test
	void when_CallingBuildProductInfo_ExpectProductDetailsToBeSet() {
		com.ielts.cmds.api.rm025bookingsearchresponsegenerated.@Valid ProductDetailsV1 productInfo = BookingSearchTestDataSetup
				.getProductInfo();
		final ProductDetailsV1 detailsV1 = bookingSearchResponseGeneratedEventMapping.buildProductInfo(productInfo);
		assertNotNull(detailsV1);
		assertEquals(productInfo.getComponent(), detailsV1.getComponent());
		assertEquals(productInfo.getProductName(), detailsV1.getProductName());
		assertEquals(productInfo.getProductUuid(), detailsV1.getProductUuid());
	}

	@Test
	void when_CallingBuildBookingDetails_ExpectBookingDetailsToBeSet() {
		com.ielts.cmds.api.rm025bookingsearchresponsegenerated.@Valid BookingDetailsV1 details = BookingSearchTestDataSetup
				.getBookingDetails();
		final BookingDetailsV1 bookingDetails = bookingSearchResponseGeneratedEventMapping.buildBookingDetails(details);
		assertNotNull(bookingDetails);
		assertEquals(details.getBannedStatus().getValue(), bookingDetails.getBannedStatus().getValue());
		assertEquals(details.getBirthDate(), bookingDetails.getBirthDate());
		assertEquals(details.getBookingDetailStatus().getValue(), bookingDetails.getBookingDetailStatus().getValue());
		assertEquals(details.getBookingStatus().getValue(), bookingDetails.getBookingStatus().getValue());
		assertEquals(details.getBookingUuid(), bookingDetails.getBookingUuid());
		assertEquals(details.getExternalBookingUuid(), bookingDetails.getExternalBookingUuid());
		assertEquals(details.getFinancialYear(), bookingDetails.getFinancialYear());
		assertEquals(details.getFirstName(), bookingDetails.getFirstName());
		assertEquals(details.getIdentityNumber(), bookingDetails.getIdentityNumber());
		assertEquals(details.getIsVoid(), bookingDetails.getIsVoid());
		assertEquals(details.getLastName(), bookingDetails.getLastName());
		assertEquals(details.getLocationUuid(), bookingDetails.getLocationUuid());
		assertEquals(details.getNationalityOther(), bookingDetails.getNationalityOther());
		assertEquals(details.getNationalityUuid(), bookingDetails.getNationalityUuid());
		assertEquals(details.getPartnerCode(), bookingDetails.getPartnerCode());
		assertEquals(details.getProductUuid(), bookingDetails.getProductUuid());
		assertEquals(details.getShortCandidateNumber(), bookingDetails.getShortCandidateNumber());
		assertEquals(details.getTestDate(), bookingDetails.getTestDate());
		assertEquals(details.getTitle(), bookingDetails.getTitle());
		assertEquals(details.getUniqueTestTakerId(), bookingDetails.getUniqueTestTakerId());
		assertEquals(details.getUniqueTestTakerUuid(), bookingDetails.getUniqueTestTakerUuid());
	}

	@Test
	void when_CallingBuildTestCentreInfo_ExpectTestCentreDetailsToBeSet() {
		com.ielts.cmds.api.rm025bookingsearchresponsegenerated.@Valid TestCentreDetailsV1 testCentreInfo = BookingSearchTestDataSetup
				.getTestCentreInfo();
		final TestCentreDetailsV1 detailsV1 = bookingSearchResponseGeneratedEventMapping
				.buildTestCentreInfo(testCentreInfo);
		assertNotNull(detailsV1);
		assertEquals(testCentreInfo.getLocationUuid(), detailsV1.getLocationUuid());
		assertEquals(testCentreInfo.getTestCentreNumber(), detailsV1.getTestCentreNumber());
		assertEquals(testCentreInfo.getTestCentreUuid(), detailsV1.getTestCentreUuid());
	}

	@Test
	void when_CallingBuildBookingStatus_ExpectBookingStatusEnumToBeSet() {
		com.ielts.cmds.api.rm025bookingsearchresponsegenerated.BookingDetailsV1.BookingStatusEnum bookingStatus = BookingSearchTestDataSetup
				.getBookingDetails().getBookingStatus();
		final BookingStatusEnum statusEnum = bookingSearchResponseGeneratedEventMapping
				.buildBookingStatus(bookingStatus);
		assertNotNull(statusEnum);
		assertEquals(bookingStatus.getValue(), statusEnum.getValue());
	}

	@Test
	void when_CallingBuildBookingDetailStatus_ExpectBookingDetailStatusEnumToBeSet() {
		com.ielts.cmds.api.rm025bookingsearchresponsegenerated.BookingDetailsV1.BookingDetailStatusEnum bookingDetailStatus = BookingSearchTestDataSetup
				.getBookingDetails().getBookingDetailStatus();
		final BookingDetailStatusEnum bookingDetailStatusEnum = bookingSearchResponseGeneratedEventMapping
				.buildBookingDetailStatus(bookingDetailStatus);
		assertNotNull(bookingDetailStatusEnum);
		assertEquals(bookingDetailStatus.getValue(), bookingDetailStatusEnum.getValue());
	}

	@Test
	void when_CallingBuildBannedStatus_ExpectBannedStatusEnumToBeSet() {
		com.ielts.cmds.api.rm025bookingsearchresponsegenerated.BookingDetailsV1.BannedStatusEnum bannedStatus = BookingSearchTestDataSetup
				.getBookingDetails().getBannedStatus();
		final BannedStatusEnum bannedStatusEnum = bookingSearchResponseGeneratedEventMapping
				.buildBannedStatus(bannedStatus);
		assertNotNull(bannedStatusEnum);
		assertEquals(bannedStatus.getValue(), bannedStatusEnum.getValue());
	}
}
