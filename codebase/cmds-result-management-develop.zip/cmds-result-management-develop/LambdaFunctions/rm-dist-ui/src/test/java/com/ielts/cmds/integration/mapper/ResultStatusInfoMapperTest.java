package com.ielts.cmds.integration.mapper;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.testdata.setup.BookingResultsGeneratedEventTestDataSetup;
import com.ielts.cmds.rm.common.out.model.BookingResultHistoryEventV2;
import com.ielts.cmds.rm.common.out.model.BookingResultsStatusHistoryV1;
import com.ielts.cmds.rm.common.out.model.ResultHistoryV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultStatusInfoV1;

@ExtendWith(MockitoExtension.class)
class ResultStatusInfoMapperTest {

    @Spy @InjectMocks ResultStatusInfoMapper resultStatusInfoMapper;

    private static Stream<Arguments> provideValidBookingResultHistory()
            throws JsonProcessingException {

        return Stream.of(Arguments.of(BookingResultsGeneratedEventTestDataSetup.buildBookingResultHistoryEventV2()));
    }

    private static Stream<Arguments> provideEmptyBookingResultHistory()
            throws JsonProcessingException {
        return Stream.of(Arguments.of(BookingResultsGeneratedEventTestDataSetup.buildBookingResultHistoryEventV2()));
    }

    @ParameterizedTest
    @MethodSource("provideValidBookingResultHistory")
    void map_ResultStatusInfoV1List_WhenReceiveValidEvent(
            BookingResultHistoryEventV2 bookingResultHistoryEvent) {

        List<BookingResultsStatusHistoryV1> rshListFromEvent =
                bookingResultHistoryEvent.getBookingResultsStatusHistory();
        List<ResultStatusInfoV1> mapResponse =
                resultStatusInfoMapper.map(rshListFromEvent, new ArrayList<>());

        assertNotNull(mapResponse);
        assertEquals(rshListFromEvent.size(), mapResponse.size());
        assertAll(
                () ->
                        assertEquals(
                                rshListFromEvent.get(0).getResultsStatusHistoryUuid(),
                                mapResponse.get(0).getResultsStatusHistoryUuid()),
                () ->
                        assertEquals(
                                rshListFromEvent.get(0).getResultStatusCommentText(),
                                mapResponse.get(0).getResultStatusComment()),
                () ->
                        assertEquals(
                                rshListFromEvent.get(0).getResultStatusCommentUuid(),
                                mapResponse.get(0).getResultStatusCommentUuid()),
                () ->
                        assertEquals(
                                rshListFromEvent.get(0).getResultStatusLabelUuid(),
                                mapResponse.get(0).getResultStatusLabelUuid()),
                () ->
                        assertEquals(
                                rshListFromEvent.get(0).getResultStatusTypeUuid(),
                                mapResponse.get(0).getResultStatusTypeUuid()),
                () ->
                        assertEquals(
                                rshListFromEvent
                                        .get(0)
                                        .getResultStatusUpdateDatetime()
                                        .toLocalDateTime(),
                                mapResponse.get(0).getResultStatusUpdateDatetime()),
                () ->
                        assertEquals(
                                rshListFromEvent.get(0).getResultStatusUpdatedBy(),
                                mapResponse.get(0).getResultStatusUpdatedBy()));
    }

    @ParameterizedTest
    @MethodSource("provideEmptyBookingResultHistory")
    void map_ResultStatusInfoV1Empty_WhenReceiveEmptyEvent(
            BookingResultHistoryEventV2 bookingResultHistoryEvent) {

        List<ResultStatusInfoV1> mapResponse =
                resultStatusInfoMapper.map(null, new ArrayList<>());

        assertTrue(mapResponse.isEmpty());
    }

    @Test
    void map_ResultStatusInfoV1Null_WhenReceiveEmptyEvent() {

        ResultStatusInfoV1 mapResponse = resultStatusInfoMapper.buildResultStatusInfo(null);
        assertNull(mapResponse);
    }

    @Test
    void map_ResultStatusInfoV1_WhenResultHistoryListAndResultStatusHistoryList_ScenarioTwo() {

        final List<BookingResultsStatusHistoryV1> bookingResultsStatusHistoryList =
                BookingResultsGeneratedEventTestDataSetup.buildBookingResultsStatusHistoryListScenarioTwo();
        final List<ResultHistoryV1> resultHistoryList =
                BookingResultsGeneratedEventTestDataSetup.buildResultHistoryListScenarioTwo();
        List<ResultStatusInfoV1> actual =
                resultStatusInfoMapper.map(bookingResultsStatusHistoryList, resultHistoryList);
        assertNotNull(actual);
        assertEquals(2, actual.size());
        assertEquals(
                bookingResultsStatusHistoryList.get(0).getResultStatusTypeUuid(),
                actual.get(1).getResultStatusTypeUuid());
        assertEquals(
                bookingResultsStatusHistoryList.get(0).getResultStatusType(),
                actual.get(1).getResultStatusType());
        assertEquals(
                bookingResultsStatusHistoryList.get(0).getResultStatusCommentText(),
                actual.get(1).getResultStatusComment());
        assertEquals(
                bookingResultsStatusHistoryList.get(0).getResultStatusLabelUuid(),
                actual.get(1).getResultStatusLabelUuid());
        assertEquals(
                bookingResultsStatusHistoryList.get(0).getResultStatusLabel(),
                actual.get(1).getResultStatusLabel());
        assertEquals(
                bookingResultsStatusHistoryList.get(0).getResultStatusCommentUuid(),
                actual.get(1).getResultStatusCommentUuid());
        assertNull(actual.get(1).getOnHold());
        assertEquals(resultHistoryList.get(0).getOnHold(), actual.get(0).getOnHold());
    }

    @Test
    void map_ResultStatusInfoV1_WhenResultHistoryListAndResultStatusHistoryList_ScenarioOne() {

        final List<BookingResultsStatusHistoryV1> bookingResultsStatusHistoryList =
                BookingResultsGeneratedEventTestDataSetup.buildBookingResultsStatusHistoryListScenarioOne();
        final List<ResultHistoryV1> resultHistoryList =
                BookingResultsGeneratedEventTestDataSetup.buildResultHistoryListScenarioOne();
        List<ResultStatusInfoV1> actual =
                resultStatusInfoMapper.map(bookingResultsStatusHistoryList, resultHistoryList);
        assertNotNull(actual);
        assertEquals(2, actual.size());
        assertEquals(
                bookingResultsStatusHistoryList.get(0).getResultStatusTypeUuid(),
                actual.get(0).getResultStatusTypeUuid());
        assertEquals(
                bookingResultsStatusHistoryList.get(0).getResultStatusType(),
                actual.get(0).getResultStatusType());
        assertEquals(
                bookingResultsStatusHistoryList.get(0).getResultStatusCommentText(),
                actual.get(0).getResultStatusComment());
        assertEquals(
                bookingResultsStatusHistoryList.get(0).getResultStatusLabelUuid(),
                actual.get(0).getResultStatusLabelUuid());
        assertEquals(
                bookingResultsStatusHistoryList.get(0).getResultStatusLabel(),
                actual.get(0).getResultStatusLabel());
        assertEquals(
                bookingResultsStatusHistoryList.get(0).getResultStatusCommentUuid(),
                actual.get(0).getResultStatusCommentUuid());
        assertNull(actual.get(0).getOnHold());
        assertEquals(resultHistoryList.get(0).getOnHold(), actual.get(1).getOnHold());
    }
}
