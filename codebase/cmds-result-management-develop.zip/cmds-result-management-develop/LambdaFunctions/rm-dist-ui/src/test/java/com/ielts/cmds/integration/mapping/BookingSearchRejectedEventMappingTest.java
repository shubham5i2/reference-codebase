package com.ielts.cmds.integration.mapping;


import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.api.rm026bookingsearchrejected.BaseEventErrors;
import com.ielts.cmds.api.rm026bookingsearchrejected.BaseEventErrorsErrorListInner;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.ResultEnvelopeV3;
import com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.SocketResponseMetaDataV1;
import com.ielts.cmds.integration.testdata.setup.BookingSearchTestDataSetup;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(MockitoExtension.class)
class BookingSearchRejectedEventMappingTest {

	@InjectMocks
	private BookingSearchRejectedEventMapping bookingSearchRejectedEventMapping;

	@BeforeEach
	void setup() {
		HeaderContext headerContext = new HeaderContext();
		headerContext.setConnectionId(UUID.randomUUID().toString());
		headerContext.setCorrelationId(UUID.randomUUID());
		ThreadLocalHeaderContext.setContext(headerContext);

		com.ielts.cmds.infrastructure.event.BaseEventErrors errorContext = new com.ielts.cmds.infrastructure.event.BaseEventErrors();
		ThreadLocalErrorContext.setContext(errorContext);
	}

	@Test
	void when_CallingProcess_ExpectResultEnvelopeToBeSet() {
		BaseEventErrors cmdsEventBody = BookingSearchTestDataSetup.getBookingSearchRejectedResponse();
		final ResultEnvelopeV3 resultEnvelope = bookingSearchRejectedEventMapping.process(cmdsEventBody);

		final BaseEventErrorsErrorListInner sourceError = cmdsEventBody.getErrorList().get(0);
		final com.ielts.cmds.api.rmws007bookingsearchsocketresponsegenerated.BaseEventErrorsErrorListInner destinationError = resultEnvelope.getErrors().getErrorList().get(0);

		assertNotNull(resultEnvelope);
		assertEquals(sourceError.getErrorTicketUuid().toString(), destinationError.getErrorTicketUuid());
		assertEquals(sourceError.getErrorCode(), destinationError.getErrorCode());
		assertEquals(sourceError.getInterface(), destinationError.getInterface());
		assertEquals(sourceError.getMessage(), destinationError.getMessage());
		assertEquals(sourceError.getTitle(), destinationError.getTitle());
		assertEquals(sourceError.getType().getValue(), destinationError.getType().getValue());
		assertEquals(sourceError.getSource().getPath(), destinationError.getSource().getPath());
		assertEquals(sourceError.getSource().getValue(), destinationError.getSource().getValue());
	}

	@Test
	void when_mapRequestEventHeaderToSocketResponseHeader_MetaInfoIsSet() {
		final SocketResponseMetaDataV1 socketMetaResponse = bookingSearchRejectedEventMapping
				.mapRequestEventHeaderToSocketResponseHeader();
		assertEquals(ThreadLocalHeaderContext.getContext().getCorrelationId().toString(),
				socketMetaResponse.getCorrelationId());
		assertEquals(ThreadLocalHeaderContext.getContext().getConnectionId(), socketMetaResponse.getConnectionId());
	}

	@Test
	void when_mapRequestEventHeaderToSocketResponseHeader_MetaInfoIsNotSet() {
		ThreadLocalHeaderContext.setContext(null);
		final SocketResponseMetaDataV1 socketMetaResponse = bookingSearchRejectedEventMapping
				.mapRequestEventHeaderToSocketResponseHeader();
		assertNull(socketMetaResponse.getCorrelationId());
		assertNull(socketMetaResponse.getConnectionId());
	}
}
