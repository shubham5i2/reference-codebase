package com.ielts.cmds.integration.mapping;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.integration.testdata.setup.OnHoldUpdateTestDataSetup;
import com.ielts.cmds.rm.common.out.model.OnHoldUpdateInitiatedV1;
import com.ielts.cmds.rm.common.out.socketresponse.OnHoldUpdateInitiatedDetailsV1;
import com.ielts.cmds.rm.common.out.socketresponse.OnHoldUpdateInitiatedSocketEnvelopeV1;
import com.ielts.cmds.rm.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

@ExtendWith(MockitoExtension.class)
class OnHoldUpdateInitiationRejectedEventMappingTest {

    @Spy @InjectMocks private OnHoldUpdateInitiationRejectedEventMapping onHoldUpdateInitiationRejectedEventMapping;

    @Test
    void mapRequestEventBodyToResponseBody_ShouldReturnOnHoldUpdateInitiatedDetailsV1_WhenGetsOnHoldUpdateInitiatedV1() {
        OnHoldUpdateInitiatedV1 eventBody =
        		OnHoldUpdateInitiatedV1.builder()
        		.onHold(true)
        		.bookingUuids(new ArrayList<>())
                .build();
        OnHoldUpdateInitiatedDetailsV1 actual =
        		onHoldUpdateInitiationRejectedEventMapping.mapRequestEventToResponseBody(eventBody);
        assertEquals(actual.getOnHold(),eventBody.getOnHold());
        assertEquals(actual.getBookingUuids(),eventBody.getBookingUuids());
    }

    @Test
    void getEnvelopeObject_ShouldReturnValidOnHoldUpdateInitiatedSocketEnvelopeV1_whenValidParameters() {
    	
    	OnHoldUpdateInitiatedSocketEnvelopeV1 onHoldupdateSocketEnvelopeV1 = new OnHoldUpdateInitiatedSocketEnvelopeV1();
    	final SocketResponseMetaDataV1 responseHeaders = OnHoldUpdateTestDataSetup.mapRequestEventHeader();
    	OnHoldUpdateInitiatedV1 eventBody =OnHoldUpdateTestDataSetup.buildOnHoldUpdateInitiatedV1();
    	OnHoldUpdateInitiatedDetailsV1 response = OnHoldUpdateTestDataSetup.buildOnHoldUpdateInitiatedDetailsV1();
    	onHoldupdateSocketEnvelopeV1.setErrors(ThreadLocalErrorContext.getContext());
    	onHoldupdateSocketEnvelopeV1.setMeta(responseHeaders);
    	onHoldupdateSocketEnvelopeV1.setResponse(response);
    	doReturn(response).when(onHoldUpdateInitiationRejectedEventMapping).mapRequestEventToResponseBody(eventBody);
    	doReturn(responseHeaders).when(onHoldUpdateInitiationRejectedEventMapping).mapRequestEventHeaderToSocketResponseHeader();
    	OnHoldUpdateInitiatedSocketEnvelopeV1 actual = onHoldUpdateInitiationRejectedEventMapping.process(eventBody);
    	assertEquals(response.getOnHold(),actual.getResponse().getOnHold());
    	assertEquals(response.getBookingUuids(),actual.getResponse().getBookingUuids());
        
    }
}
