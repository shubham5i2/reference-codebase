package com.ielts.cmds.integration.testdata.setup;

import com.ielts.cmds.rm.common.enums.ComponentTypeEnum;
import com.ielts.cmds.rm.common.enums.PhotoTypeEnum;
import com.ielts.cmds.rm.common.out.model.BookingPersonalDetailsV1;
import com.ielts.cmds.rm.common.out.model.BookingResultDetailsV1;
import com.ielts.cmds.rm.common.out.model.BookingResultHistoryEventV1;
import com.ielts.cmds.rm.common.out.model.BookingResultHistoryEventV2;
import com.ielts.cmds.rm.common.out.model.BookingResultInfoEventV1;
import com.ielts.cmds.rm.common.out.model.BookingResultsStatusEventV1;
import com.ielts.cmds.rm.common.out.model.BookingResultsStatusHistoryV1;
import com.ielts.cmds.rm.common.out.model.ComponentGradesEventV1;
import com.ielts.cmds.rm.common.out.model.ComponentGradesInfoV1;
import com.ielts.cmds.rm.common.out.model.EvaluationRoundEventV1;
import com.ielts.cmds.rm.common.out.model.EvaluationsGeneratedEventV1;
import com.ielts.cmds.rm.common.out.model.EvaluationsInfoV1;
import com.ielts.cmds.rm.common.out.model.LinkedBookingDetailsV1;
import com.ielts.cmds.rm.common.out.model.MarksGeneratedEventV1;
import com.ielts.cmds.rm.common.out.model.ProductGeneratedEventV1;
import com.ielts.cmds.rm.common.out.model.QuestionGeneratedEventV1;
import com.ielts.cmds.rm.common.out.model.ResultBookingInfoV1;
import com.ielts.cmds.rm.common.out.model.ResultHistoryV1;
import com.ielts.cmds.rm.common.out.model.ResultLineEventV1;
import com.ielts.cmds.rm.common.out.model.ResultStatusUpdateCompletedV1;
import com.ielts.cmds.rm.common.out.model.ResultStatusUpdateSummaryV1;
import com.ielts.cmds.rm.common.out.model.ResultTTPhotoV1;
import com.ielts.cmds.rm.common.out.model.TestBookingDetailsV1;
import com.ielts.cmds.rm.common.out.socketresponse.ComponentRoundInfoV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultScoreInfoV1;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class BookingResultsGeneratedEventTestDataSetup {

    public static BookingResultsStatusEventV1 buildBookingResultsStatusEvent(boolean empty) {
        if (empty) return BookingResultsStatusEventV1.builder().build();
        return BookingResultsStatusEventV1.builder()
                .resultsStatusHistoryUuid(UUID.randomUUID())
                .resultStatusUpdateDatetime(OffsetDateTime.now())
                .resultStatusTypeUuid(UUID.randomUUID())
                .resultStatusLabelUuid(UUID.randomUUID())
                .resultStatusComment("New Comment")
                .resultStatusCommentUuid(UUID.randomUUID())
                .resultStatusUpdatedBy("Update User")
                .build();
    }

    public static List<EvaluationRoundEventV1> buildEvaluationRoundEvent() {
        List<EvaluationRoundEventV1> evaluationRoundEvents =
                Stream.of(1, 2, 3)
                        .map(
                                roundId ->
                                        EvaluationRoundEventV1.builder()
                                                .overallFinalGrade(8.5F)
                                                .overallResultType("JAGGED-1")
                                                .overallEvaluationRoundId(roundId)
                                                .componentsGrades(
                                                        buildComponentGradesEvent(roundId))
                                                .build())
                        .collect(Collectors.toList());
        evaluationRoundEvents.get(1).setOverallFinalGrade(7.5F);
        evaluationRoundEvents.get(1).setOverallResultType("JAGGED-2");
        evaluationRoundEvents.get(2).setOverallFinalGrade(6.5F);
        evaluationRoundEvents.get(1).setOverallResultType("NORMAL");

        return evaluationRoundEvents;
    }

    private static List<ComponentGradesEventV1> buildComponentGradesEvent(Integer roundId) {
        switch (roundId) {
            case 1:
                return Stream.of(ComponentTypeEnum.values())
                        .map(
                                componentType ->
                                        ComponentGradesEventV1.builder()
                                                .componentEvaluationRoundId(roundId)
                                                .componentFinalGrade(8.5F)
                                                .componentResultType(
                                                        componentType == ComponentTypeEnum.R
                                                                        || componentType
                                                                                == ComponentTypeEnum
                                                                                        .L
                                                                ? "NORMAL"
                                                                : "JAGGED-1")
                                                .totalScore(38)
                                                .product(buildProductGeneratedEvent(componentType))
                                                .questions(buildQuestionGeneratedEvent())
                                                .build())
                        .collect(Collectors.toList());
            case 2:
                return Stream.of(ComponentTypeEnum.W, ComponentTypeEnum.S)
                        .map(
                                componentType ->
                                        ComponentGradesEventV1.builder()
                                                .componentEvaluationRoundId(roundId)
                                                .componentFinalGrade(7.5F)
                                                .componentResultType(
                                                        componentType == ComponentTypeEnum.W
                                                                ? "NORMAL"
                                                                : "JAGGED-2")
                                                .totalScore(28)
                                                .product(buildProductGeneratedEvent(componentType))
                                                .questions(buildQuestionGeneratedEvent())
                                                .build())
                        .collect(Collectors.toList());
            default:
                return Stream.of(ComponentTypeEnum.S)
                        .map(
                                componentType ->
                                        ComponentGradesEventV1.builder()
                                                .componentEvaluationRoundId(roundId)
                                                .componentFinalGrade(6.5F)
                                                .componentResultType("NORMAL")
                                                .totalScore(18)
                                                .product(buildProductGeneratedEvent(componentType))
                                                .questions(buildQuestionGeneratedEvent())
                                                .build())
                        .collect(Collectors.toList());
        }
    }

    private static List<QuestionGeneratedEventV1> buildQuestionGeneratedEvent() {
        return Stream.of(1, 2)
                .map(
                        questionId ->
                                QuestionGeneratedEventV1.builder()
                                        .questionWeight(questionId + 2)
                                        .questionUuid(UUID.randomUUID())
                                        .questionId(questionId)
                                        .evaluations(buildEvaluationsGeneratedEvent())
                                        .build())
                .collect(Collectors.toList());
    }

    private static List<EvaluationsGeneratedEventV1> buildEvaluationsGeneratedEvent() {
        return Stream.of(30, 40)
                .map(
                        score ->
                                EvaluationsGeneratedEventV1.builder()
                                        .evaluationUuid(UUID.randomUUID())
                                        .evaluatorId(score * 10)
                                        .score(30)
                                        .marks(buildMarksGeneratedEvent(score))
                                        .build())
                .collect(Collectors.toList());
    }

    private static List<MarksGeneratedEventV1> buildMarksGeneratedEvent(int score) {
        return Stream.of(score - 10, 10)
                .map(
                        mark ->
                                MarksGeneratedEventV1.builder()
                                        .criteriaUuid(UUID.randomUUID())
                                        .markUuid(UUID.randomUUID())
                                        .rewardMarks(mark)
                                        .build())
                .collect(Collectors.toList());
    }

    private static ProductGeneratedEventV1 buildProductGeneratedEvent(
            ComponentTypeEnum componentType) {
        return ProductGeneratedEventV1.builder()
                .component(componentType.toString())
                .productDescription("Test for " + componentType)
                .productUuid(UUID.randomUUID())
                .productName("IELTS " + componentType)
                .build();
    }

    public static BookingResultHistoryEventV1 buildBookingResultHistoryEvent() {
        return BookingResultHistoryEventV1.builder()
                .bookingResultInfo(buildBookingResultInfoDetails())
                .bookingResultsScore(buildEvaluationRoundEvent())
                .bookingResultsStatusHistory(
                        Stream.of(buildBookingResultsStatusEvent(false))
                                .collect(Collectors.toList()))
                .build();
    }

    private static BookingResultInfoEventV1 buildBookingResultInfoDetails() {
        return BookingResultInfoEventV1.builder()
                .bookingResultLines(buildResultLines())
                .bookingResultStatus(buildBookingResultsStatusEvent(false))
                .bookingResultConcurrencyVersion(1)
                .bookingUuid(UUID.randomUUID())
                .overallScore(8.5F)
                .resultUuid(UUID.randomUUID())
                .trfNumber("19GB001234SMIJ599A")
                .resultTypeUuid(UUID.randomUUID())
                .build();
    }

    public static BookingResultHistoryEventV2 buildBookingResultHistoryEventV2() {
        return BookingResultHistoryEventV2.builder()
                .bookingResultInfo(buildBookingResultInfo())
                .bookingResultsScore(buildComponentGradeInfo())
                .bookingResultHistory(buildResultHistoryListScenarioOne())
                .bookingResultsStatusHistory(buildBookingResultsStatusHistoryListScenarioOne())
                .bookingResultTTPhotos(buildBookingResultTTPhotos())
                .build();
    }

    public static BookingResultHistoryEventV2
            buildBookingResultHistoryEventV2ForWritingComponent() {
        return BookingResultHistoryEventV2.builder()
                .bookingResultInfo(buildBookingResultInfoForWritingComponent())
                .bookingResultsScore(buildComponentGradeInfo())
                .bookingResultHistory(buildResultHistoryListScenarioOne())
                .bookingResultsStatusHistory(buildBookingResultsStatusHistoryListScenarioOne())
                .bookingResultTTPhotos(buildBookingResultTTPhotos())
                .build();
    }

    private static List<ResultTTPhotoV1> buildBookingResultTTPhotos() {
        List<ResultTTPhotoV1> resultTTPhotoV1List = new ArrayList<>();
        resultTTPhotoV1List.add(
                ResultTTPhotoV1.builder()
                        .photoType(PhotoTypeEnum.TT_ID_HR_R)
                        .photoUuid(UUID.randomUUID())
                        .photoUrl(
                                "d9be5-ff26-4541-acf7-bf5ef7a9a151_f6c594bb-6dc3-438b-8e94-c87edaa47cd6_1.jpeg")
                        .build());
        return resultTTPhotoV1List;
    }

    public static List<ComponentGradesInfoV1> buildComponentGradeInfo() {
        List<ComponentGradesInfoV1> componentRoundInfoList = new ArrayList<>();
        componentRoundInfoList.add(
                ComponentGradesInfoV1.builder()
                        .componentEvaluationRoundId(1)
                        .componentFinalGrade(7f)
                        .componentReceivedDate(OffsetDateTime.now())
                        .componentResultType("NORMAL")
                        .evaluations(buildEvaluationsInfo())
                        .isUpdated(true)
                        .productUuid(UUID.fromString("d154eaf8-b288-4e7d-ab93-45b2469f9a34"))
                        .totalScore(8)
                        .build());
        return componentRoundInfoList;
    }

    private static List<EvaluationsInfoV1> buildEvaluationsInfo() {
        return Stream.of(30, 40)
                .map(
                        score ->
                                EvaluationsInfoV1.builder()
                                        .evaluationUuid(UUID.randomUUID())
                                        .evaluatorId(score * 10)
                                        .score(30)
                                        .marks(buildMarksGeneratedEvent(score))
                                        .build())
                .collect(Collectors.toList());
    }

    private static ResultBookingInfoV1 buildBookingResultInfo() {
        return ResultBookingInfoV1.builder()
                .bookingUuid(UUID.randomUUID())
                .personalDetails(buildPersonalDetails())
                .productDetails(buildProductDetails())
                .resultDetails(buildResultDetails())
                .testBookingDetails(buildTestBookingDetails())
                .linkedBookingDetails(new LinkedBookingDetailsV1())
                .build();
    }

    private static ResultBookingInfoV1 buildBookingResultInfoForWritingComponent() {
        return ResultBookingInfoV1.builder()
                .bookingUuid(UUID.randomUUID())
                .personalDetails(buildPersonalDetails())
                .productDetails(buildProductDetailsForWriting())
                .resultDetails(buildResultDetails())
                .testBookingDetails(buildTestBookingDetails())
                .linkedBookingDetails(new LinkedBookingDetailsV1())
                .build();
    }

    public static TestBookingDetailsV1 buildTestBookingDetails() {
        return TestBookingDetailsV1.builder()
                .compositeCandidateNumber("101H")
                .locationId("13R")
                .locationName("IELTS Global")
                .shortCandidateNumber("000103")
                .testCentreName("UK")
                .testCentreNumber("AU241")
                .testDate(LocalDate.now())
                .productUuid(UUID.randomUUID())
                .productName("IELTS " + ComponentTypeEnum.R.getComponent())
                .build();
    }

    public static BookingResultDetailsV1 buildResultDetails() {
        return BookingResultDetailsV1.builder()
                .cefrLevel("C1")
                .resultScore(8.5F)
                .resultUuid(UUID.randomUUID())
                .trfNumber("2210000782KLIP1IHA")
                .build();
    }

    public static List<ProductGeneratedEventV1> buildProductDetails() {
        List<ProductGeneratedEventV1> productList = new ArrayList<>();
        UUID productUuid = UUID.randomUUID();
        productList.add(
                ProductGeneratedEventV1.builder()
                        .component(ComponentTypeEnum.R.name())
                        .productDescription(
                                "Test for " + ComponentTypeEnum.R.getComponent().toString())
                        .productName("IELTS " + ComponentTypeEnum.R.getComponent())
                        .productUuid(productUuid)
                        .build());
        return productList;
    }

    public static List<ProductGeneratedEventV1> buildProductDetailsForWriting() {
        List<ProductGeneratedEventV1> productList = new ArrayList<>();
        productList.add(
                ProductGeneratedEventV1.builder()
                        .component(ComponentTypeEnum.W.name())
                        .productDescription("Test for " + ComponentTypeEnum.W.getComponent())
                        .productName("IELTS " + ComponentTypeEnum.W.getComponent())
                        .productUuid(UUID.fromString("d154eaf8-b288-4e7d-ab93-45b2469f9a34"))
                        .build());
        return productList;
    }

    public static BookingPersonalDetailsV1 buildPersonalDetails() {
        // TODO Auto-generated method stub
        return BookingPersonalDetailsV1.builder()
                .birthDate(LocalDate.of(2000, 8, 13))
                .familyName("Alan")
                .givenName("Davis")
                .identityDocumentNumber("12")
                .isBanned(false)
                .nationality("Indian")
                .uniqueTestTakerId("T-8I-0FFK-D89D")
                .uniqueTestTakerUuid(UUID.randomUUID())
                .build();
    }

    private static List<ResultLineEventV1> buildResultLines() {
        return Stream.of(8.5F, 8.5F, 7.5F, 6.5F)
                .map(
                        score ->
                                ResultLineEventV1.builder()
                                        .bookingLineUuid(UUID.randomUUID())
                                        .resultLineUuid(UUID.randomUUID())
                                        .productUuid(UUID.randomUUID())
                                        .resultLineScore(score)
                                        .build())
                .collect(Collectors.toList());
    }

    public static List<ResultScoreInfoV1> buildResultsScoreInfo() {
        List<ResultScoreInfoV1> resultScoreInfoList = new ArrayList<>();

        resultScoreInfoList.add(
                ResultScoreInfoV1.builder()
                        .componentGradeType(ComponentTypeEnum.O.getComponent())
                        .componentRounds(buildComponentRounds())
                        .build());
        resultScoreInfoList.add(
                ResultScoreInfoV1.builder()
                        .componentGradeType(ComponentTypeEnum.L.getComponent())
                        .componentRounds(buildComponentRounds())
                        .build());
        resultScoreInfoList.add(
                ResultScoreInfoV1.builder()
                        .componentGradeType(ComponentTypeEnum.R.getComponent())
                        .componentRounds(buildComponentRounds())
                        .build());
        resultScoreInfoList.add(
                ResultScoreInfoV1.builder()
                        .componentGradeType(ComponentTypeEnum.S.getComponent())
                        .componentRounds(buildComponentRounds())
                        .build());
        resultScoreInfoList.add(
                ResultScoreInfoV1.builder()
                        .componentGradeType(ComponentTypeEnum.W.getComponent())
                        .componentRounds(buildComponentRounds())
                        .build());
        return resultScoreInfoList;
    }

    private static List<ComponentRoundInfoV1> buildComponentRounds() {
        List<ComponentRoundInfoV1> componentRoundInfoList = new ArrayList<>();
        componentRoundInfoList.add(
                ComponentRoundInfoV1.builder()
                        .componentEvaluationRoundId(1)
                        .overallResultType("NORMAL")
                        .overallFinalGrade(7f)
                        .build());
        return componentRoundInfoList;
    }

    public static List<BookingResultsStatusHistoryV1>
            buildBookingResultsStatusHistoryListScenarioOne() {
        final List<BookingResultsStatusHistoryV1> bookingResultsStatusHistoryList =
                new ArrayList<>();
        final BookingResultsStatusHistoryV1 bookingResultsStatusHistory =
                new BookingResultsStatusHistoryV1();
        bookingResultsStatusHistory.setResultsStatusHistoryUuid(UUID.randomUUID());
        bookingResultsStatusHistory.setResultStatusCommentUuid(UUID.randomUUID());
        bookingResultsStatusHistory.setResultStatusLabelUuid(UUID.randomUUID());
        bookingResultsStatusHistory.setResultStatusTypeUuid(UUID.randomUUID());
        bookingResultsStatusHistory.setResultStatusCommentText("Comment Value");
        bookingResultsStatusHistory.setResultStatusUpdatedBy("Rocky");
        bookingResultsStatusHistory.setResultStatusLabel("status label");
        bookingResultsStatusHistory.setResultStatusType("Result Type");
        bookingResultsStatusHistory.setResultStatusUpdateDatetime(OffsetDateTime.now());
        bookingResultsStatusHistoryList.add(bookingResultsStatusHistory);
        return bookingResultsStatusHistoryList;
    }

    public static List<ResultHistoryV1> buildResultHistoryListScenarioOne() {
        final List<ResultHistoryV1> resultHistoryList = new ArrayList<>();
        final ResultHistoryV1 resultHistory = new ResultHistoryV1();
        resultHistory.setOnHold(true);
        resultHistory.setOnHoldUpdatedBy("Jammy");
        resultHistory.setResultHistoryUuid(UUID.randomUUID());
        resultHistory.setOnHoldUpdatedDateTime(OffsetDateTime.now());
        resultHistoryList.add(resultHistory);
        return resultHistoryList;
    }

    public static List<BookingResultsStatusHistoryV1>
            buildBookingResultsStatusHistoryListScenarioTwo() {
        final List<BookingResultsStatusHistoryV1> bookingResultsStatusHistoryList =
                new ArrayList<>();
        final BookingResultsStatusHistoryV1 bookingResultsStatusHistory =
                new BookingResultsStatusHistoryV1();
        bookingResultsStatusHistory.setResultsStatusHistoryUuid(UUID.randomUUID());
        bookingResultsStatusHistory.setResultStatusCommentUuid(UUID.randomUUID());
        bookingResultsStatusHistory.setResultStatusLabelUuid(UUID.randomUUID());
        bookingResultsStatusHistory.setResultStatusTypeUuid(UUID.randomUUID());
        bookingResultsStatusHistory.setResultStatusCommentText("Comment Value");
        bookingResultsStatusHistory.setResultStatusUpdatedBy("Rocky");
        bookingResultsStatusHistory.setResultStatusUpdateDatetime(
                OffsetDateTime.now().plusDays(10));
        bookingResultsStatusHistoryList.add(bookingResultsStatusHistory);
        return bookingResultsStatusHistoryList;
    }

    public static List<ResultHistoryV1> buildResultHistoryListScenarioTwo() {
        final List<ResultHistoryV1> resultHistoryList = new ArrayList<>();
        final ResultHistoryV1 resultHistory = new ResultHistoryV1();
        resultHistory.setOnHold(true);
        resultHistory.setOnHoldUpdatedBy("Jammy");
        resultHistory.setResultHistoryUuid(UUID.randomUUID());
        resultHistory.setOnHoldUpdatedDateTime(OffsetDateTime.now().minusDays(10));
        resultHistoryList.add(resultHistory);
        return resultHistoryList;
    }

    public static ResultStatusUpdateCompletedV1 generateResultStatusUpdateSummaryEvent() {
        ResultStatusUpdateCompletedV1 resultStatusUpdateCompletedV1 =
                new ResultStatusUpdateCompletedV1();
        ResultStatusUpdateSummaryV1 resultStatusUpdateSummary = new ResultStatusUpdateSummaryV1();
        resultStatusUpdateSummary.setFailedUpdatesCount(0);
        resultStatusUpdateSummary.setPassedUpdatesCount(0);
        resultStatusUpdateCompletedV1.setResultStatusUpdateSummary(resultStatusUpdateSummary);
        return resultStatusUpdateCompletedV1;
    }
}
