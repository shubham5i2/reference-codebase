package com.ielts.cmds.integration.testdata.setup;

import java.util.ArrayList;
import java.util.UUID;

import com.ielts.cmds.rm.common.out.model.OnHoldUpdateCompletedV1;
import com.ielts.cmds.rm.common.out.model.OnHoldUpdateInitiatedV1;
import com.ielts.cmds.rm.common.out.model.OnHoldUpdateSummaryV1;
import com.ielts.cmds.rm.common.out.socketresponse.OnHoldUpdateCompletedDetailsV1;
import com.ielts.cmds.rm.common.out.socketresponse.OnHoldUpdateCompletedSocketEnvelopeV1;
import com.ielts.cmds.rm.common.out.socketresponse.OnHoldUpdateCompletedSummaryV1;
import com.ielts.cmds.rm.common.out.socketresponse.OnHoldUpdateInitiatedDetailsV1;
import com.ielts.cmds.rm.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

public class OnHoldUpdateTestDataSetup {
	
	public static OnHoldUpdateCompletedSocketEnvelopeV1 buildOnHoldUpdateCompletedSocketEnvelopeV1()
	{
		OnHoldUpdateCompletedSocketEnvelopeV1 onHoldUpdateCompletedSocketEnvelopeV1 = 
				OnHoldUpdateCompletedSocketEnvelopeV1.builder()
				.meta(mapRequestEventHeader())
				.errors(ThreadLocalErrorContext.getContext())
				.response(buildOnHoldCompletedDetailsV1())
				.build();
		return onHoldUpdateCompletedSocketEnvelopeV1; 
	}
	
	private static OnHoldUpdateCompletedDetailsV1 buildOnHoldCompletedDetailsV1() {
		OnHoldUpdateCompletedDetailsV1 onHoldUpdateCompletedDetailsV1 =
				OnHoldUpdateCompletedDetailsV1.builder()
				.onHoldUpdateSummary(buildOnHoldSummary())
				.build();
		return onHoldUpdateCompletedDetailsV1;
	}

	private static OnHoldUpdateCompletedSummaryV1 buildOnHoldSummary() {
		OnHoldUpdateCompletedSummaryV1 onHoldUpdateCompletedSummaryV1 =
				OnHoldUpdateCompletedSummaryV1.builder()
				.failureCount(3)
				.passCount(4)
				.build();
		return onHoldUpdateCompletedSummaryV1;
	}

	public static SocketResponseMetaDataV1 mapRequestEventHeader() {
		final SocketResponseMetaDataV1 responseHeaders = new SocketResponseMetaDataV1();
		responseHeaders.setCorrelationId(UUID.fromString("867b46ce-3306-4456-816b-fc8cf9a926ce"));
		responseHeaders.setConnectionId("867b46ce-3306-4456-816b-fc8cf9a926ce");
		return responseHeaders;
	}
	
	public static OnHoldUpdateCompletedV1 buildOnHoldUpdateCompletedV1()
	{
		OnHoldUpdateCompletedV1 onHoldUpdateCompletedV1 =
				OnHoldUpdateCompletedV1.builder()
				.onHoldUpdateSummary(OnHoldUpdateSummaryV1.builder()
                                        .passedUpdatesCount(3)
                                        .failedUpdatesCount(4)
                                        .build())
				.build();
		return onHoldUpdateCompletedV1;
	}
	
	public static OnHoldUpdateCompletedDetailsV1 buildOnHoldUpdateCompletedDetailsV1()
	{
		OnHoldUpdateCompletedDetailsV1 onHoldUpdateCompletedDetailsV1 =
				OnHoldUpdateCompletedDetailsV1.builder()
				.onHoldUpdateSummary(buildOnHoldSummary())
				.build();
		return onHoldUpdateCompletedDetailsV1;
	}
	public static OnHoldUpdateInitiatedV1 buildOnHoldUpdateInitiatedV1()
	{
		OnHoldUpdateInitiatedV1 onHoldUpdateInitiatedV1 =
				OnHoldUpdateInitiatedV1.builder()
				.bookingUuids(new ArrayList<>())
				.onHold(true)
				.build();
		return onHoldUpdateInitiatedV1;
	}
	public static OnHoldUpdateInitiatedDetailsV1 buildOnHoldUpdateInitiatedDetailsV1()
	{
		OnHoldUpdateInitiatedDetailsV1 onHoldUpdateInitiatedDetailsV1 =
				OnHoldUpdateInitiatedDetailsV1.builder()
				.onHold(true)
				.bookingUuids(new ArrayList<>())
				.build();
		return onHoldUpdateInitiatedDetailsV1;
	}

}
