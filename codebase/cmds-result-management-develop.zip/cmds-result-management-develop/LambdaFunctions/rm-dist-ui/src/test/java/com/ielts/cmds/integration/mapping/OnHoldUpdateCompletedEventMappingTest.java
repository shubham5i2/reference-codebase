package com.ielts.cmds.integration.mapping;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.integration.testdata.setup.OnHoldUpdateTestDataSetup;
import com.ielts.cmds.rm.common.out.model.OnHoldUpdateCompletedV1;
import com.ielts.cmds.rm.common.out.model.OnHoldUpdateSummaryV1;
import com.ielts.cmds.rm.common.out.socketresponse.OnHoldUpdateCompletedDetailsV1;
import com.ielts.cmds.rm.common.out.socketresponse.OnHoldUpdateCompletedSocketEnvelopeV1;
import com.ielts.cmds.rm.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

@ExtendWith(MockitoExtension.class)
class OnHoldUpdateCompletedEventMappingTest {

    @Spy @InjectMocks private OnHoldUpdateCompletedEventMapping onHoldUpdateCompletedEventMapping;

    @Test
    void
            mapRequestEventBodyToResponseBody_ShouldReturnOnHoldUpdateCompletedDetailsV1_WhenGetsOnHoldUpdateCompletedV1() {
        long passed = 3;
        long failed = 4;
        OnHoldUpdateCompletedV1 eventBody =
                OnHoldUpdateCompletedV1.builder()
                        .onHoldUpdateSummary(
                                OnHoldUpdateSummaryV1.builder()
                                        .passedUpdatesCount(passed)
                                        .failedUpdatesCount(failed)
                                        .build())
                        .build();
        OnHoldUpdateCompletedDetailsV1 actual =
                onHoldUpdateCompletedEventMapping.mapRequestEventBodyToResponseBody(eventBody);
        assertAll(
                () -> assertEquals(passed, actual.getOnHoldUpdateSummary().getPassCount()),
                () -> assertEquals(failed, actual.getOnHoldUpdateSummary().getFailureCount()));
    }

    @Test
    void getEnvelopeObject_ShouldReturnValidOnHoldUpdateCompletedSocketEnvelopeV1_whenValidParameters() {
    	
    	OnHoldUpdateCompletedSocketEnvelopeV1 onHoldSocketEnvelopeV1 = new OnHoldUpdateCompletedSocketEnvelopeV1();
    	final SocketResponseMetaDataV1 responseHeaders = OnHoldUpdateTestDataSetup.mapRequestEventHeader();
    	OnHoldUpdateCompletedV1 eventBody =OnHoldUpdateTestDataSetup.buildOnHoldUpdateCompletedV1();
    	OnHoldUpdateCompletedDetailsV1 response = OnHoldUpdateTestDataSetup.buildOnHoldUpdateCompletedDetailsV1();
    	onHoldSocketEnvelopeV1.setErrors(ThreadLocalErrorContext.getContext());
    	onHoldSocketEnvelopeV1.setMeta(responseHeaders);
    	onHoldSocketEnvelopeV1.setResponse(response);
    	doReturn(response).when(onHoldUpdateCompletedEventMapping).mapRequestEventBodyToResponseBody(eventBody);
    	doReturn(responseHeaders).when(onHoldUpdateCompletedEventMapping).mapRequestEventHeaderToSocketResponseHeader();
    	OnHoldUpdateCompletedSocketEnvelopeV1 actual = onHoldUpdateCompletedEventMapping.process(eventBody);
    	assertEquals(response.getOnHoldUpdateSummary().getFailureCount(),actual.getResponse().getOnHoldUpdateSummary().getFailureCount());
    	assertEquals(response.getOnHoldUpdateSummary().getPassCount(),actual.getResponse().getOnHoldUpdateSummary().getPassCount());
        
    }
}
