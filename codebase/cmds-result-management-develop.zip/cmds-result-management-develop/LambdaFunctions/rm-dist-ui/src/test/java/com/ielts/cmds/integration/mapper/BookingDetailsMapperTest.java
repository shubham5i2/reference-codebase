package com.ielts.cmds.integration.mapper;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.testdata.setup.BookingResultsGeneratedEventTestDataSetup;
import com.ielts.cmds.rm.common.out.model.BookingResultHistoryEventV2;
import com.ielts.cmds.rm.common.out.socketresponse.LatestComponentScoreV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultBookingDetailsV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultScoreInfoV1;

@ExtendWith(MockitoExtension.class)
class BookingDetailsMapperTest {

    @Spy @InjectMocks BookingDetailsMapper bookingDetailsMapper;

    private static Stream<Arguments> provideValidBookingResultHistory()
            throws JsonProcessingException {

        return Stream.of(
                Arguments.of(
                		BookingResultsGeneratedEventTestDataSetup.buildBookingResultHistoryEventV2(),
                        new ArrayList<ResultScoreInfoV1>()));
    }

    @ParameterizedTest
    @MethodSource("provideValidBookingResultHistory")
    void map_ResultBookingDetail_WhenReceiveValidEvent(
            BookingResultHistoryEventV2 bookingResultHistoryEvent,
            List<ResultScoreInfoV1> resultScoreInfoList) {

        // when
        when(bookingDetailsMapper.currentResultStatus(bookingResultHistoryEvent))
                .thenReturn(Mockito.any());
        when(bookingDetailsMapper.latestComponentRound(resultScoreInfoList))
                .thenReturn(new LatestComponentScoreV1());

        ResultBookingDetailsV1 mapResponse =
                bookingDetailsMapper.map(bookingResultHistoryEvent, resultScoreInfoList);

        assertNotNull(mapResponse);
        assertEquals(mapResponse.getBookingUuid(),bookingResultHistoryEvent.getBookingResultInfo().getBookingUuid());
    }

    private static Stream<Arguments> provideResultScoreInfoList() throws JsonProcessingException {

        return Stream.of(Arguments.of(BookingResultsGeneratedEventTestDataSetup.buildResultsScoreInfo()));
    }

    @ParameterizedTest
    @MethodSource("provideResultScoreInfoList")
    void map_LatestComponentScore(List<ResultScoreInfoV1> resultScoreInfoList) {

        // when
        LatestComponentScoreV1 mapResponse =
                bookingDetailsMapper.latestComponentRound(resultScoreInfoList);

        assertNotNull(mapResponse);
        assertAll(
                () -> assertEquals(mapResponse.getOverall().getComponentEvaluationRoundId(),resultScoreInfoList.get(0).getComponentRounds().get(0).getComponentEvaluationRoundId()),
                () -> assertEquals(mapResponse.getListening().getOverallFinalGrade(),resultScoreInfoList.get(0).getComponentRounds().get(0).getOverallFinalGrade()),
                () -> assertEquals(mapResponse.getReading().getRawScore(),resultScoreInfoList.get(0).getComponentRounds().get(0).getRawScore()),
                () -> assertEquals(mapResponse.getSpeaking().getOverallResultType(),resultScoreInfoList.get(0).getComponentRounds().get(0).getOverallResultType()),
                () -> assertEquals(mapResponse.getWriting().getDateReceived(),resultScoreInfoList.get(0).getComponentRounds().get(0).getDateReceived()));
    }

    @Test
    void map_LatestComponentScore_EmptyResutls() {

        // when
        LatestComponentScoreV1 mapResponse =
                bookingDetailsMapper.latestComponentRound(new ArrayList<ResultScoreInfoV1>());

        assertNotNull(mapResponse);
        assertAll(
                () -> assertNull(mapResponse.getOverall()),
                () -> assertNull(mapResponse.getListening()),
                () -> assertNull(mapResponse.getReading()),
                () -> assertNull(mapResponse.getSpeaking()),
                () -> assertNull(mapResponse.getWriting()));
    }
}
