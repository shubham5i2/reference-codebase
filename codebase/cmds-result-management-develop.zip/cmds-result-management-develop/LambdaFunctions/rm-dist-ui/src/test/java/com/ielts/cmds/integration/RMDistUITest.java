package com.ielts.cmds.integration;


import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.integration.factory.ServiceFactoryV2;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class RMDistUITest {

    @InjectMocks @Spy private RMDistUI rmDistUI;

    @SuppressWarnings("rawtypes")
    @Mock
    private IServiceV2 service;

    @Test
    void processRequestTest() {
        assertTrue(rmDistUI.getServiceFactory() instanceof ServiceFactoryV2);
    }

    @SuppressWarnings("unchecked")
    @Test
    void isProcessingRequired_ExpectTrue() {
        HeaderContext context = new HeaderContext();
        Map<String, String> eventContext = new HashMap<>();
        context.setEventContext(eventContext);
        ThreadLocalHeaderContext.setContext(context);
        assertTrue(rmDistUI.isProcessingRequired(service));
    }

    @Test
    void isProcessingRequiredNoService_ExpectFalse() {
        HeaderContext context = new HeaderContext();
        Map<String, String> eventContext = new HashMap<>();
        context.setEventContext(eventContext);
        ThreadLocalHeaderContext.setContext(context);
        assertFalse(rmDistUI.isProcessingRequired(null));
    }

    @SuppressWarnings("unchecked")
    @Test
    void isProcessingRequiredContextPresent_ExpectFalse() {
        HeaderContext context = new HeaderContext();
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put("sendToUI", "false");
        context.setEventContext(eventContext);
        ThreadLocalHeaderContext.setContext(context);
        assertFalse(rmDistUI.isProcessingRequired(service));
    }

    @Test
    void isProcessingRequiredt_ExpectFalse() {
        HeaderContext context = new HeaderContext();
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put("sendToUI", "false");
        context.setEventContext(eventContext);
        ThreadLocalHeaderContext.setContext(context);
        assertFalse(rmDistUI.isProcessingRequired(null));
    }
}
