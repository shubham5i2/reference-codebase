package com.ielts.cmds.integration.mapping;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.integration.testdata.setup.OnHoldUpdateTestDataSetup;
import com.ielts.cmds.rm.common.out.model.NoActionTakenEventV1;
import com.ielts.cmds.rm.common.out.socketresponse.NoActionTakenDetailsV1;
import com.ielts.cmds.rm.common.out.socketresponse.NoActionTakenSocketEnvelopeV1;
import com.ielts.cmds.rm.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

@ExtendWith(MockitoExtension.class)
class NoActionTakenEventMappingTest {

    @Spy @InjectMocks private NoActionTakenEventMapping noActionTakenEventMapping;

    @Test
    void mapRequestEventBodyToResponseBody_ShouldReturnNoActionTakenDetailsV1_WhenGetsNoActionTakenEventV1() {
    	NoActionTakenEventV1 eventBody = new NoActionTakenEventV1();
    	eventBody.setBookingUuid(UUID.randomUUID());
        NoActionTakenDetailsV1 actual =
        		noActionTakenEventMapping.mapRequestEventToResponseBody(eventBody);
        assertEquals(actual.getBookingUuid(),eventBody.getBookingUuid());
    }

    @Test
    void getEnvelopeObject_ShouldReturnValidNoActionTakenSocketEnvelopeV1_whenValidParameters() {
    	
    	NoActionTakenSocketEnvelopeV1 noActionTakenSocketEnvelopeV1 = new NoActionTakenSocketEnvelopeV1();
    	final SocketResponseMetaDataV1 responseHeaders = OnHoldUpdateTestDataSetup.mapRequestEventHeader();
    	NoActionTakenEventV1 eventBody = new NoActionTakenEventV1();
    	eventBody.setBookingUuid(UUID.randomUUID());
    	NoActionTakenDetailsV1 response = new NoActionTakenDetailsV1();
    	response.setBookingUuid(UUID.randomUUID());		
    	noActionTakenSocketEnvelopeV1.setErrors(ThreadLocalErrorContext.getContext());
    	noActionTakenSocketEnvelopeV1.setMeta(responseHeaders);
    	noActionTakenSocketEnvelopeV1.setResponse(response);
    	doReturn(response).when(noActionTakenEventMapping).mapRequestEventToResponseBody(eventBody);
    	doReturn(responseHeaders).when(noActionTakenEventMapping).mapRequestEventHeaderToSocketResponseHeader();
    	NoActionTakenSocketEnvelopeV1 actual = noActionTakenEventMapping.process(eventBody);
    	assertEquals(response.getBookingUuid(),actual.getResponse().getBookingUuid());
        
    }
}
