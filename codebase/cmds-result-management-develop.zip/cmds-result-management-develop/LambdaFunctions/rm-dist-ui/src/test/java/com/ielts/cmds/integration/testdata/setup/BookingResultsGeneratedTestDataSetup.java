package com.ielts.cmds.integration.testdata.setup;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.ielts.cmds.rm.common.enums.ComponentTypeEnum;
import com.ielts.cmds.rm.common.enums.PhotoTypeEnum;
import com.ielts.cmds.rm.common.out.socketresponse.ComponentRoundInfoV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultBookingDetailsV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultDetailsEventV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultDetailsV2;
import com.ielts.cmds.rm.common.out.socketresponse.ResultEnvelopeV2;
import com.ielts.cmds.rm.common.out.socketresponse.ResultScoreInfoV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultStatusInfoV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultTTPhotoDetailsV1;
import com.ielts.cmds.rm.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

public class BookingResultsGeneratedTestDataSetup {
	
	public static ResultEnvelopeV2 buildResultEnvelopeV2()
	{
		ResultEnvelopeV2 resultEnvelopeV2 = 
				ResultEnvelopeV2.builder()
				.meta(mapRequestEventHeader())
				.errors(ThreadLocalErrorContext.getContext())
				.response(buildResultDetails()).build();
		return resultEnvelopeV2;
	}
	public static ResultDetailsV2 buildResultDetails() {
		ResultDetailsV2 resultDetailsV2 =
				ResultDetailsV2.builder()
				.bookingDetails(buildBookingDetails())
				.resultScoreHistory(buildResultsScoreInfo())
				.resultStatusHistory(buildResultStatusHistory())
				.resultTTPhotoDetails(buildResultTTPhotoDetails())
				.build();
		return resultDetailsV2;
	}
	private static List<ResultTTPhotoDetailsV1> buildResultTTPhotoDetails() {
		List<ResultTTPhotoDetailsV1> resultTTPhotoDetailsList = new ArrayList<>();
		resultTTPhotoDetailsList.add(
				ResultTTPhotoDetailsV1.builder()
				.photoType(PhotoTypeEnum.TT_ID_HR_R)
				.photoUuid(UUID.randomUUID())
				.photoUrl("d9be5-ff26-4541-acf7-bf5ef7a9a151_f6c594bb-6dc3-438b-8e94-c87edaa47cd6_1.jpeg")
				.build());
		return resultTTPhotoDetailsList;
	}
	private static List<ResultStatusInfoV1> buildResultStatusHistory() {
		List<ResultStatusInfoV1> resultStatusInfoV1List = new ArrayList<>();
		resultStatusInfoV1List.add(
				ResultStatusInfoV1.builder()
				.onHold(true)
				.resultsStatusHistoryUuid(UUID.randomUUID())
				.resultStatusComment("Comment Value")
				.resultStatusCommentUuid(UUID.randomUUID())
				.resultStatusLabel("status label")
				.resultStatusLabelUuid(UUID.randomUUID())
				.resultStatusType("Result Type")
				.resultStatusTypeUuid(UUID.randomUUID())
				.resultStatusUpdateDatetime(LocalDateTime.now())
				.resultStatusUpdatedBy("Rocky")
				.build());
		return resultStatusInfoV1List;
	}
	 public static List<ResultScoreInfoV1> buildResultsScoreInfo() {
	        List<ResultScoreInfoV1> resultScoreInfoList = new ArrayList<>();

	        resultScoreInfoList.add(
	                ResultScoreInfoV1.builder()
	                        .componentGradeType(ComponentTypeEnum.O.getComponent())
	                        .componentRounds(buildComponentRounds())
	                        .build());
	        resultScoreInfoList.add(
	                ResultScoreInfoV1.builder()
	                        .componentGradeType(ComponentTypeEnum.L.getComponent())
	                        .componentRounds(buildComponentRounds())
	                        .build());
	        resultScoreInfoList.add(
	                ResultScoreInfoV1.builder()
	                        .componentGradeType(ComponentTypeEnum.R.getComponent())
	                        .componentRounds(buildComponentRounds())
	                        .build());
	        resultScoreInfoList.add(
	                ResultScoreInfoV1.builder()
	                        .componentGradeType(ComponentTypeEnum.S.getComponent())
	                        .componentRounds(buildComponentRounds())
	                        .build());
	        resultScoreInfoList.add(
	                ResultScoreInfoV1.builder()
	                        .componentGradeType(ComponentTypeEnum.W.getComponent())
	                        .componentRounds(buildComponentRounds())
	                        .build());
	        return resultScoreInfoList;
	    }
	 private static List<ComponentRoundInfoV1> buildComponentRounds() {
	        List<ComponentRoundInfoV1> componentRoundInfoList = new ArrayList<>();
	        componentRoundInfoList.add(
	                ComponentRoundInfoV1.builder()
	                        .componentEvaluationRoundId(1)
	                        .overallResultType("NORMAL")
	                        .overallFinalGrade(7f)
	                        .build());
	        return componentRoundInfoList;
	    }
	 
	private static ResultBookingDetailsV1 buildBookingDetails() {
		ResultBookingDetailsV1 resultBookingDetailsV1 =
		ResultBookingDetailsV1.builder()
		.bookingUuid(UUID.randomUUID())
		.currentResultStatus(buildCurrentResultStatus())
		.personalDetails(BookingResultsGeneratedEventTestDataSetup.buildPersonalDetails())
		.productDetails(BookingResultsGeneratedEventTestDataSetup.buildProductDetails())
		.resultDetails(buildResultDetailsv1())
		.testBookingDetails(BookingResultsGeneratedEventTestDataSetup.buildTestBookingDetails())
		.build();
		return resultBookingDetailsV1;
	}
	private static ResultDetailsEventV1 buildResultDetailsv1() {
		return ResultDetailsEventV1.builder()
				.cefrLevel("C1")
				.resultScore(8.5F)
				.resultUuid(UUID.randomUUID())
				.trfNumber("2210000782KLIP1IHA")
				.build();
	}
	private static ResultStatusInfoV1 buildCurrentResultStatus() {
		ResultStatusInfoV1 resultStatusInfoV1=
				ResultStatusInfoV1.builder()
				.onHold(true)
				.resultsStatusHistoryUuid(UUID.randomUUID())
				.resultStatusComment("Comment Value")
				.resultStatusCommentUuid(UUID.randomUUID())
				.resultStatusLabel("status label")
				.resultStatusLabelUuid(UUID.randomUUID())
				.resultStatusType("Result Type")
				.resultStatusTypeUuid(UUID.randomUUID())
				.resultStatusUpdateDatetime(LocalDateTime.now())
				.resultStatusUpdatedBy("Rocky")
				.build();
		return resultStatusInfoV1;
	}
	public static SocketResponseMetaDataV1 mapRequestEventHeader() {
		final SocketResponseMetaDataV1 responseHeaders = new SocketResponseMetaDataV1();
		responseHeaders.setCorrelationId(UUID.fromString("867b46ce-3306-4456-816b-fc8cf9a926ce"));
		responseHeaders.setConnectionId("867b46ce-3306-4456-816b-fc8cf9a926ce");
		return responseHeaders;
	}
}
