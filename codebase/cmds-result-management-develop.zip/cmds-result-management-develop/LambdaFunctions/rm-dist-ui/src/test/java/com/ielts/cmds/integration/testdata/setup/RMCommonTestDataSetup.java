package com.ielts.cmds.integration.testdata.setup;

import com.ielts.cmds.rm.common.out.socketresponse.SocketResponseMetaDataV1;
import java.util.UUID;

public class RMCommonTestDataSetup {

    public static SocketResponseMetaDataV1 mapRequestEventHeader() {
        SocketResponseMetaDataV1 responseHeaders = new SocketResponseMetaDataV1();
        responseHeaders.setCorrelationId(UUID.randomUUID());
        responseHeaders.setConnectionId("867b46ce-3306-4456-816b-fc8cf9a926ce");
        return responseHeaders;
    }
}
