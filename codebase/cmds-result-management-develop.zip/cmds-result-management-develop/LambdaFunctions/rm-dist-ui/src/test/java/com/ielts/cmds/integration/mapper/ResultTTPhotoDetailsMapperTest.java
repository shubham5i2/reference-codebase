package com.ielts.cmds.integration.mapper;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.testdata.setup.BookingResultsGeneratedEventTestDataSetup;
import com.ielts.cmds.rm.common.out.model.BookingResultHistoryEventV2;
import com.ielts.cmds.rm.common.out.model.ResultTTPhotoV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultTTPhotoDetailsV1;

@ExtendWith(MockitoExtension.class)
class ResultTTPhotoDetailsMapperTest {

    @Spy @InjectMocks ResultTTPhotoDetailsMapper resultTTPhotoDetailsMapper;

    private static Stream<Arguments> provideValidBookingResultHistory()
            throws JsonProcessingException {

        return Stream.of(Arguments.of(BookingResultsGeneratedEventTestDataSetup.buildBookingResultHistoryEventV2()));
    }

    private static Stream<Arguments> provideEmptyBookingResultHistory()
            throws JsonProcessingException {

        return Stream.of(Arguments.of(BookingResultsGeneratedEventTestDataSetup.buildBookingResultHistoryEventV2()));
    }

    @ParameterizedTest
    @MethodSource("provideValidBookingResultHistory")
    void map_ResultTTPhotoDetailsList_WhenReceiveValidEvent(
            BookingResultHistoryEventV2 bookingResultHistoryEvent) {

        List<ResultTTPhotoV1> resultTTPhotoListFromEvent =
                bookingResultHistoryEvent.getBookingResultTTPhotos();
        List<ResultTTPhotoDetailsV1> mapResponse =
                resultTTPhotoDetailsMapper.map(resultTTPhotoListFromEvent);

        assertNotNull(mapResponse);
        assertEquals(resultTTPhotoListFromEvent.size(), mapResponse.size());
        assertAll(
                () ->
                        assertEquals(
                                resultTTPhotoListFromEvent.get(0).getPhotoType(),
                                mapResponse.get(0).getPhotoType()),
                () ->
                        assertEquals(
                                resultTTPhotoListFromEvent.get(0).getPhotoUrl(),
                                mapResponse.get(0).getPhotoUrl()),
                () ->
                        assertEquals(
                                resultTTPhotoListFromEvent.get(0).getPhotoUuid(),
                                mapResponse.get(0).getPhotoUuid()));
    }

    @ParameterizedTest
    @MethodSource("provideEmptyBookingResultHistory")
    void map_ResultStatusInfoV1Empty_WhenReceiveEmptyEvent(
            BookingResultHistoryEventV2 bookingResultHistoryEvent) {

        List<ResultTTPhotoDetailsV1> mapResponse =
                resultTTPhotoDetailsMapper.map(null);

        assertTrue(mapResponse.isEmpty());
    }
}
