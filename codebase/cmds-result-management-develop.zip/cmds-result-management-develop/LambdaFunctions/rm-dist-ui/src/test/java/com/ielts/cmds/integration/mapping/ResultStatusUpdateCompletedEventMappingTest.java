package com.ielts.cmds.integration.mapping;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.doReturn;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.integration.testdata.setup.OnHoldUpdateTestDataSetup;
import com.ielts.cmds.integration.testdata.setup.ResultStatusTestDataSetup;
import com.ielts.cmds.rm.common.out.model.ResultStatusUpdateCompletedV1;
import com.ielts.cmds.rm.common.out.model.ResultStatusUpdateSummaryV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultsStatusUpdateCompletedDetailsV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultsStatusUpdateCompletedSocketEnvelopeV1;
import com.ielts.cmds.rm.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

@ExtendWith(MockitoExtension.class)
class ResultStatusUpdateCompletedEventMappingTest {

    @Spy @InjectMocks private ResultStatusUpdateCompletedEventMapping resultStatusUpdateCompletedEventMapping;
    
    @Test
    void mapRequestEventBodyToResponseBody_ShouldReturnResultsStatusUpdateCompletedDetailsV1_WhenGetsResultStatusUpdateCompletedV1() {
    	ResultStatusUpdateCompletedV1 eventBody =
    			ResultStatusUpdateCompletedV1.builder()
        		.resultStatusUpdateSummary(
        				ResultStatusUpdateSummaryV1.builder()
        				.failedUpdatesCount(3)
        				.passedUpdatesCount(4)
        				.build())
                .build();
        ResultsStatusUpdateCompletedDetailsV1 actual =
        		resultStatusUpdateCompletedEventMapping.mapRequestEventBodyToResponseBody(eventBody);
        assertEquals(actual.getResultStatusUpdateSummary().getFailureCount(),eventBody.getResultStatusUpdateSummary().getFailedUpdatesCount());
        assertEquals(actual.getResultStatusUpdateSummary().getPassCount(),eventBody.getResultStatusUpdateSummary().getPassedUpdatesCount());
    }

    @Test
    void getEnvelopeObject_ShouldReturnValidResultsStatusUpdateCompletedSocketEnvelopeV1_whenValidParameters() {
    	
    	ResultsStatusUpdateCompletedSocketEnvelopeV1 resultupdateSocketEnvelopeV1 = new ResultsStatusUpdateCompletedSocketEnvelopeV1();
    	final SocketResponseMetaDataV1 responseHeaders = OnHoldUpdateTestDataSetup.mapRequestEventHeader();
    	ResultStatusUpdateCompletedV1 eventBody = ResultStatusTestDataSetup.buildResultStatusUpdateCompletedV1();
    	ResultsStatusUpdateCompletedDetailsV1 response = ResultStatusTestDataSetup.buildResultsStatusUpdateCompletedDetailsV1();
    	resultupdateSocketEnvelopeV1.setErrors(ThreadLocalErrorContext.getContext());
    	resultupdateSocketEnvelopeV1.setMeta(responseHeaders);
    	resultupdateSocketEnvelopeV1.setResponse(response);
    	doReturn(response).when(resultStatusUpdateCompletedEventMapping).mapRequestEventBodyToResponseBody(eventBody);
    	doReturn(responseHeaders).when(resultStatusUpdateCompletedEventMapping).mapRequestEventHeaderToSocketResponseHeader();
    	ResultsStatusUpdateCompletedSocketEnvelopeV1 actual = resultStatusUpdateCompletedEventMapping.process(eventBody);
    	assertEquals(response.getResultStatusUpdateSummary().getFailureCount(),actual.getResponse().getResultStatusUpdateSummary().getFailureCount());
    	assertEquals(response.getResultStatusUpdateSummary().getPassCount(),actual.getResponse().getResultStatusUpdateSummary().getPassCount());
    }
    
    @Test
    void mapRequestEventBodyToResponseBody_ShouldReturnNull_WhenNullResultStatusUpdateCompletedV1() {
        assertNull(resultStatusUpdateCompletedEventMapping.mapRequestEventBodyToResponseBody(null));
    }
}
