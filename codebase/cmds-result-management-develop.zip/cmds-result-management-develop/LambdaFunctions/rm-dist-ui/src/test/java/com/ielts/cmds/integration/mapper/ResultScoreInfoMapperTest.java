package com.ielts.cmds.integration.mapper;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.testdata.setup.BookingResultsGeneratedEventTestDataSetup;
import com.ielts.cmds.rm.common.out.model.BookingResultHistoryEventV2;
import com.ielts.cmds.rm.common.out.model.ComponentGradesInfoV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultScoreInfoV1;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ResultScoreInfoMapperTest {

    private static Stream<Arguments> provideValidBookingResultHistory()
            throws JsonProcessingException {

        return Stream.of(
                Arguments.of(
                        BookingResultsGeneratedEventTestDataSetup
                                .buildBookingResultHistoryEventV2(),
                        new ArrayList<ResultScoreInfoV1>()));
    }

    private static Stream<Arguments> provideValidBookingResultHistoryWritingComponent()
            throws JsonProcessingException {

        return Stream.of(
                Arguments.of(
                        BookingResultsGeneratedEventTestDataSetup
                                .buildBookingResultHistoryEventV2ForWritingComponent(),
                        new ArrayList<ResultScoreInfoV1>()));
    }

    @ParameterizedTest
    @MethodSource("provideValidBookingResultHistory")
    void map_ResultStatusInfoV1List_WhenReceiveValidEvent(
            BookingResultHistoryEventV2 bookingResultHistoryEvent) {

        List<ComponentGradesInfoV1> evaluationRoundInfoList =
                bookingResultHistoryEvent.getBookingResultsScore();
        List<ResultScoreInfoV1> mapResponse =
                new ResultScoreInfoMapper(
                                bookingResultHistoryEvent
                                        .getBookingResultInfo()
                                        .getProductDetails())
                        .map(evaluationRoundInfoList);

        assertNotNull(mapResponse);
    }

    @ParameterizedTest
    @MethodSource("provideValidBookingResultHistoryWritingComponent")
    void map_ResultStatusInfoV1List_WhenReceiveValidEventV2(
            BookingResultHistoryEventV2 bookingResultHistoryEvent) {

        List<ComponentGradesInfoV1> evaluationRoundInfoList =
                bookingResultHistoryEvent.getBookingResultsScore();
        List<ResultScoreInfoV1> mapResponse =
                new ResultScoreInfoMapper(
                                bookingResultHistoryEvent
                                        .getBookingResultInfo()
                                        .getProductDetails())
                        .map(evaluationRoundInfoList);

        assertNotNull(mapResponse);
    }
}
