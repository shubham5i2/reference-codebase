package com.ielts.cmds.integration.testdata.setup;

import java.math.BigDecimal;
import java.util.UUID;

import com.ielts.cmds.api.evt020.ResultStatus;
import com.ielts.cmds.api.evt020.ResultStatusBooking;
import com.ielts.cmds.rm.common.out.model.ResultStatusUpdateCompletedV1;
import com.ielts.cmds.rm.common.out.model.ResultStatusUpdateSummaryV1;
import com.ielts.cmds.rm.common.out.socketresponse.BookingResultChangedDetailsV1;
import com.ielts.cmds.rm.common.out.socketresponse.BookingResultChangedSocketInfoV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultsStatusUpdateCompletedDetailsV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultsStatusUpdateCompletedSummaryV1;

public class ResultStatusTestDataSetup {

	public static ResultStatusUpdateCompletedV1 buildResultStatusUpdateCompletedV1() {
		ResultStatusUpdateCompletedV1 resultStatusUpdateCompletedV1 =
				ResultStatusUpdateCompletedV1.builder()
				.resultStatusUpdateSummary(ResultStatusUpdateSummaryV1.builder()
						.failedUpdatesCount(3)
						.passedUpdatesCount(4)
						.build())
				.build();
		return resultStatusUpdateCompletedV1;
	}

	public static ResultsStatusUpdateCompletedDetailsV1 buildResultsStatusUpdateCompletedDetailsV1() {

		ResultsStatusUpdateCompletedDetailsV1 resultsStatusUpdateCompletedDetailsV1 =
				ResultsStatusUpdateCompletedDetailsV1.builder()
				.resultStatusUpdateSummary(ResultsStatusUpdateCompletedSummaryV1.builder()
						.failureCount(3)
						.passCount(4)
						.build())
				.build();
		return resultsStatusUpdateCompletedDetailsV1;
	}

	public static BookingResultChangedDetailsV1 buildBookingResultChangedDetailsV1(ResultStatus resultStatus)
	{
		return BookingResultChangedDetailsV1.builder()
				.bookingResultInfo(buildBookingResultInfo(resultStatus))
				.build();
	}

	public static BookingResultChangedSocketInfoV1 buildBookingResultInfo(ResultStatus resultStatus) {
		return BookingResultChangedSocketInfoV1.builder()
				.externalBookingUuid(resultStatus.getBooking().getExternalBookingUuid())
				.bookingUuid(resultStatus.getBooking().getBookingUuid())
				.resultUuid(resultStatus.getResultUuid())
				.onHold(resultStatus.getOnHold())
				.build();
	}
	public static ResultStatus buildResultStatus()
	{
		ResultStatus resultStatus = new ResultStatus();
		resultStatus.setOnHold(true);
		resultStatus.setResultUuid(UUID.randomUUID());
		ResultStatusBooking resultStatusBooking = new ResultStatusBooking();
		resultStatusBooking.setBookingUuid(UUID.randomUUID());
		resultStatusBooking.setBookingVersion(BigDecimal.valueOf(1));
		resultStatusBooking.setExternalBookingUuid(UUID.randomUUID());
		resultStatus.setBooking(resultStatusBooking);
		return resultStatus;
	}
}
