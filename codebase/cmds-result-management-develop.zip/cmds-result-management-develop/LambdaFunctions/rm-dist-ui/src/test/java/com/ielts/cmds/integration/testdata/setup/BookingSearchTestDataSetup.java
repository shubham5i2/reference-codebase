package com.ielts.cmds.integration.testdata.setup;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.ielts.cmds.api.rm025bookingsearchresponsegenerated.BookingDetailsV1;
import com.ielts.cmds.api.rm025bookingsearchresponsegenerated.BookingDetailsV1.BannedStatusEnum;
import com.ielts.cmds.api.rm025bookingsearchresponsegenerated.BookingDetailsV1.BookingDetailStatusEnum;
import com.ielts.cmds.api.rm025bookingsearchresponsegenerated.BookingDetailsV1.BookingStatusEnum;
import com.ielts.cmds.api.rm025bookingsearchresponsegenerated.BookingSearchResponseResultListV1;
import com.ielts.cmds.api.rm025bookingsearchresponsegenerated.BookingSearchResponseResultV1;
import com.ielts.cmds.api.rm025bookingsearchresponsegenerated.BookingSearchResultV1;
import com.ielts.cmds.api.rm025bookingsearchresponsegenerated.ProductDetailsV1;
import com.ielts.cmds.api.rm025bookingsearchresponsegenerated.ResultDetailsV1;
import com.ielts.cmds.api.rm025bookingsearchresponsegenerated.ResultLineDetailsV1;
import com.ielts.cmds.api.rm025bookingsearchresponsegenerated.ResultsStatusCommentDetailsV1;
import com.ielts.cmds.api.rm025bookingsearchresponsegenerated.ResultsStatusDetailsV1;
import com.ielts.cmds.api.rm025bookingsearchresponsegenerated.ResultsStatusLabelDetailsV1;
import com.ielts.cmds.api.rm025bookingsearchresponsegenerated.ResultsStatusTypeDetailsV1;
import com.ielts.cmds.api.rm025bookingsearchresponsegenerated.TestCentreDetailsV1;
import com.ielts.cmds.api.rm026bookingsearchrejected.BaseEventErrors;
import com.ielts.cmds.api.rm026bookingsearchrejected.BaseEventErrorsErrorListInner;
import com.ielts.cmds.api.rm026bookingsearchrejected.BaseEventErrorsErrorListInner.TypeEnum;
import com.ielts.cmds.api.rm026bookingsearchrejected.BaseEventErrorsErrorListInnerSource;


public class BookingSearchTestDataSetup {

	public static BookingSearchResponseResultV1 getBookingSearchResponse() {
		final BookingSearchResponseResultV1 bookingSearchResponseResult = new BookingSearchResponseResultV1();
		bookingSearchResponseResult.setResult(getBuildResult());
		return bookingSearchResponseResult;
	}
	
	public static BaseEventErrors getBookingSearchRejectedResponse() {
		final BaseEventErrors errors = new BaseEventErrors();
		List<BaseEventErrorsErrorListInner> errorList = new ArrayList<>();
		BaseEventErrorsErrorListInner error = new BaseEventErrorsErrorListInner();
		error.setErrorCode("ERR123");
		error.setErrorTicketUuid(UUID.randomUUID());
		error.setInterface("RM");
		error.setMessage("Some Error in Permission");
		error.setTitle("Unauthorized");
		error.setType(TypeEnum.ERROR);
		BaseEventErrorsErrorListInnerSource source = new BaseEventErrorsErrorListInnerSource();
		source.setPath("Rbac");
		source.setValue("Unauthorized");
		error.setSource(source);
		errorList.add(error);
		errors.setErrorList(errorList);
		return errors;
	}

	public static BookingSearchResponseResultListV1 getBuildResult() {
		final BookingSearchResponseResultListV1 bookingSearchResponseResultList = new BookingSearchResponseResultListV1();
		bookingSearchResponseResultList.setEntries(getResultEntries());
		bookingSearchResponseResultList.setTotalCount("2");
		return bookingSearchResponseResultList;
	}

	public static List<BookingSearchResultV1> getResultEntries() {
		final List<BookingSearchResultV1> entries = new ArrayList<>();
		BookingSearchResultV1 entryOne = new BookingSearchResultV1();
		entryOne.setResultDetails(getResultDetails());
		entryOne.setBookingDetails(getBookingDetails());
		entries.add(entryOne);
		return entries;
	}
	
	public static BookingDetailsV1 getBookingDetails() {
		final BookingDetailsV1 bookingDetails = new BookingDetailsV1();
		bookingDetails.setBannedStatus(BannedStatusEnum.valueOf("BANNED"));
		bookingDetails.setBirthDate(LocalDate.of(2004, 12, 17));
		bookingDetails.setBookingDetailStatus(BookingDetailStatusEnum.INCOMPLETE);
		bookingDetails.setBookingStatus(BookingStatusEnum.UNPAID);
		bookingDetails.setBookingUuid(UUID.randomUUID());
		bookingDetails.setExternalBookingUuid(UUID.randomUUID());
		bookingDetails.setFinancialYear(2024);
		bookingDetails.setFirstName("brodie");
		bookingDetails.setIdentityNumber("BR008");
		bookingDetails.setIsVoid(false);
		bookingDetails.setLastName("H.");
		bookingDetails.setLocationUuid(UUID.randomUUID());
		bookingDetails.setNationalityOther("Indian");
		bookingDetails.setNationalityUuid(UUID.randomUUID());
		bookingDetails.setPartnerCode("BC");
		bookingDetails.setProductUuid(UUID.randomUUID());
		bookingDetails.setShortCandidateNumber("00067");
		bookingDetails.setTestCentreInfo(getTestCentreInfo());
		bookingDetails.setTestDate(LocalDate.of(2024, 11, 15));
		bookingDetails.setUniqueTestTakerId("IN-00037");
		bookingDetails.setTitle("Mr");
		bookingDetails.setUniqueTestTakerUuid(UUID.randomUUID());
		return bookingDetails;
	}

	public static TestCentreDetailsV1 getTestCentreInfo() {
		final TestCentreDetailsV1 testCentreDetails = new TestCentreDetailsV1();
		testCentreDetails.setLocationUuid(UUID.randomUUID());
		testCentreDetails.setTestCentreNumber("24256");
		testCentreDetails.setTestCentreUuid(UUID.randomUUID());
		return testCentreDetails;
	}

	public static ResultDetailsV1 getResultDetails() {
		final ResultDetailsV1 resultDetails = new ResultDetailsV1();
		resultDetails.setOnHold(false);
		resultDetails.setProductInfo(getProductInfo());
		resultDetails.setResultLineDetails(getResultLineDetails());
		resultDetails.setResultScore((float)8.5);
		resultDetails.setResultsStatus(getResultsStatus());
		resultDetails.setResultUuid(UUID.randomUUID());
		return resultDetails;
	}

	public static ResultsStatusDetailsV1 getResultsStatus() {
		final ResultsStatusDetailsV1 resultsStatusDetails = new ResultsStatusDetailsV1();
		resultsStatusDetails.setResultsStatusComment(getResultsStatusComment());
		resultsStatusDetails.setResultsStatusHistoryUuid(UUID.randomUUID());
		resultsStatusDetails.setResultsStatusLabel(getResultsStatusLabel());
		resultsStatusDetails.setResultsStatusType(getResultsStatusType());
		return resultsStatusDetails;
	}

	public static ResultsStatusTypeDetailsV1 getResultsStatusType() {
		final ResultsStatusTypeDetailsV1 resultsStatusTypeDetails = new ResultsStatusTypeDetailsV1();
		resultsStatusTypeDetails.setResultsStatusTypeUuid(UUID.randomUUID());
		resultsStatusTypeDetails.setResultsStatusTypeValue("Confirmed");
		return resultsStatusTypeDetails;
	}

	public static ResultsStatusLabelDetailsV1 getResultsStatusLabel() {
		final ResultsStatusLabelDetailsV1 resultsStatusLabelDetails = new ResultsStatusLabelDetailsV1();
		resultsStatusLabelDetails.setResultsStatusLabelUuid(UUID.randomUUID());
		resultsStatusLabelDetails.setResultsStatusLabelValue("EOR pending");		
		return resultsStatusLabelDetails;
	}

	public static ResultsStatusCommentDetailsV1 getResultsStatusComment() {
		final ResultsStatusCommentDetailsV1 resultsStatusCommentDetails = new ResultsStatusCommentDetailsV1();
		resultsStatusCommentDetails.setResultsStatusCommentUuid(UUID.randomUUID());
		resultsStatusCommentDetails.setResultsStatusCommentValue("Unconfirmed");
		return resultsStatusCommentDetails;
	}

	public static List<ResultLineDetailsV1> getResultLineDetails() {
		List<ResultLineDetailsV1> resultLineDetails = new ArrayList<>();
		ResultLineDetailsV1 line = new ResultLineDetailsV1();
		line.setComponentInfo(getComponentInfo());
		line.setResultLineScore((float)8.5);
		line.setResultLineUuid(UUID.randomUUID());
		resultLineDetails.add(line);
		return resultLineDetails;
	}

	public static ProductDetailsV1 getComponentInfo() {
		ProductDetailsV1 productDetails = new ProductDetailsV1();
		productDetails.setComponent("L");
		productDetails.setProductName("IELTS Online");
		productDetails.setProductUuid(UUID.randomUUID());
		return productDetails;
	}

	public static ProductDetailsV1 getProductInfo() {
		ProductDetailsV1 productDetails = new ProductDetailsV1();
		productDetails.setComponent("L");
		productDetails.setProductName("IELTS");
		productDetails.setProductUuid(UUID.randomUUID());
		return productDetails;
	}
	
	
	
	
}
