package com.ielts.cmds.integration.mapper;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.testdata.setup.BookingResultsGeneratedEventTestDataSetup;
import com.ielts.cmds.rm.common.out.model.ResultStatusUpdateCompletedV1;
import com.ielts.cmds.rm.common.out.socketresponse.ResultsStatusUpdateCompletedSummaryV1;

@ExtendWith(MockitoExtension.class)
class ResultStatusUpdateSummaryMapperTest {

    @Spy @InjectMocks ResultStatusUpdateSummaryMapper resultStatusUpdateSummaryMapper;

    private static Stream<Arguments> provideValidResultStatusUpdateSummary()
            throws JsonProcessingException {

        return Stream.of(Arguments.of(BookingResultsGeneratedEventTestDataSetup.generateResultStatusUpdateSummaryEvent()));
    }

    @ParameterizedTest
    @MethodSource("provideValidResultStatusUpdateSummary")
    void map_ResultStatusUpdateSummary_WhenReceiveValidEvent(
            ResultStatusUpdateCompletedV1 resultStatusUpdateCompletedEvent) {

        ResultsStatusUpdateCompletedSummaryV1 mapResponse =
                resultStatusUpdateSummaryMapper.map(
                        resultStatusUpdateCompletedEvent.getResultStatusUpdateSummary());
        assertNotNull(mapResponse);
        assertAll(
                () ->
                        assertEquals(
                                resultStatusUpdateCompletedEvent
                                        .getResultStatusUpdateSummary()
                                        .getFailedUpdatesCount(),
                                mapResponse.getFailureCount()),
                () ->
                        assertEquals(
                                resultStatusUpdateCompletedEvent
                                        .getResultStatusUpdateSummary()
                                        .getPassedUpdatesCount(),
                                mapResponse.getPassCount()));
    }

    @Test
    void map_ResultStatusUpdateSummaryEmpty_WhenReceiveEmptyEvent() {

        ResultStatusUpdateCompletedV1 resultStatusUpdateCompletedEvent =
                ResultStatusUpdateCompletedV1.builder().build();
        ResultsStatusUpdateCompletedSummaryV1 mapResponse =
                resultStatusUpdateSummaryMapper.map(
                        resultStatusUpdateCompletedEvent.getResultStatusUpdateSummary());
        assertNull(mapResponse);
    }
}
