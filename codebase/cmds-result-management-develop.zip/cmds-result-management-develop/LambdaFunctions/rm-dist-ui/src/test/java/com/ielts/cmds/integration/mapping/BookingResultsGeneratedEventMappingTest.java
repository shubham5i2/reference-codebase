package com.ielts.cmds.integration.mapping;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.doReturn;

import com.ielts.cmds.integration.mapper.ResultDetailsMapper;
import com.ielts.cmds.integration.testdata.setup.BookingResultsGeneratedEventTestDataSetup;
import com.ielts.cmds.integration.testdata.setup.BookingResultsGeneratedTestDataSetup;
import com.ielts.cmds.integration.testdata.setup.RMCommonTestDataSetup;
import com.ielts.cmds.rm.common.out.model.BookingResultHistoryEventV2;
import com.ielts.cmds.rm.common.out.socketresponse.ResultDetailsV2;
import com.ielts.cmds.rm.common.out.socketresponse.ResultEnvelopeV2;
import com.ielts.cmds.rm.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class BookingResultsGeneratedEventMappingTest {

    @Spy @InjectMocks BookingResultsGeneratedEventMapping bookingResultsGeneratedEventMapping;

    @Test
    void getEnvelopeObject_ShouldReturnValidResultEnvelopeV2_whenValidParameters() {

        ResultEnvelopeV2 bookingResultDataOutV1Envelope = new ResultEnvelopeV2();
        final SocketResponseMetaDataV1 responseHeaders =
                RMCommonTestDataSetup.mapRequestEventHeader();
        BookingResultHistoryEventV2 eventBody =
                BookingResultsGeneratedEventTestDataSetup.buildBookingResultHistoryEventV2();
        ResultDetailsV2 response = BookingResultsGeneratedTestDataSetup.buildResultDetails();
        bookingResultDataOutV1Envelope.setErrors(ThreadLocalErrorContext.getContext());
        bookingResultDataOutV1Envelope.setMeta(responseHeaders);
        bookingResultDataOutV1Envelope.setResponse(response);
        doReturn(response)
                .when(bookingResultsGeneratedEventMapping)
                .mapRequestEventBodyToResponseBody(eventBody);
        doReturn(responseHeaders)
                .when(bookingResultsGeneratedEventMapping)
                .mapRequestEventHeaderToSocketResponseHeader();
        ResultEnvelopeV2 actual = bookingResultsGeneratedEventMapping.process(eventBody);
        assertEquals(
                response.getBookingDetails().getBookingUuid(),
                actual.getResponse().getBookingDetails().getBookingUuid());
    }

    @Test
    void mapRequestEventBodyToResponseBody_ShouldReturnNull_WhenNullResultDetailsV2() {
        assertNull(bookingResultsGeneratedEventMapping.mapRequestEventBodyToResponseBody(null));
    }

    @Test
    void
            mapRequestEventBodyToResponseBody_ShouldReturnValidBookingResultHistoryEventV2_WhenValidResultDetailsV2() {
        BookingResultHistoryEventV2 eventBody =
                BookingResultsGeneratedEventTestDataSetup.buildBookingResultHistoryEventV2();
        ResultDetailsV2 response = BookingResultsGeneratedTestDataSetup.buildResultDetails();
        ResultDetailsMapper resultDetailsMapper = new ResultDetailsMapper();
        ResultDetailsV2 actual =
                bookingResultsGeneratedEventMapping.mapRequestEventBodyToResponseBody(eventBody);
        resultDetailsMapper.map(eventBody);
        assertEquals(
                actual.getBookingDetails().getCurrentResultStatus().getOnHold(),
                response.getBookingDetails().getCurrentResultStatus().getOnHold());
        assertEquals(
                actual.getBookingDetails().getCurrentResultStatus().getResultStatusComment(),
                response.getBookingDetails().getCurrentResultStatus().getResultStatusComment());
        assertEquals(
                actual.getBookingDetails().getCurrentResultStatus().getResultStatusType(),
                response.getBookingDetails().getCurrentResultStatus().getResultStatusType());
    }
}
