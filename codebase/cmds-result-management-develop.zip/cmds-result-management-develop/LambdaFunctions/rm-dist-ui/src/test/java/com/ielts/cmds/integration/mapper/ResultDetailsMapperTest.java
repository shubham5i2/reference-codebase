package com.ielts.cmds.integration.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.testdata.setup.BookingResultsGeneratedEventTestDataSetup;
import com.ielts.cmds.rm.common.out.model.BookingResultHistoryEventV2;
import com.ielts.cmds.rm.common.out.socketresponse.ResultDetailsV2;
import com.ielts.cmds.rm.common.out.socketresponse.ResultScoreInfoV1;

@ExtendWith(MockitoExtension.class)
class ResultDetailsMapperTest {

    @Spy @InjectMocks ResultDetailsMapper resultDetailsMapper;

    private static Stream<Arguments> provideValidBookingResultHistory()
            throws JsonProcessingException {

        return Stream.of(
                Arguments.of(
                		BookingResultsGeneratedEventTestDataSetup.buildBookingResultHistoryEventV2(),
                        new ArrayList<ResultScoreInfoV1>()));
    }

    @ParameterizedTest
    @MethodSource("provideValidBookingResultHistory")
    void map_ResultBookingDetail_WhenReceiveValidEvent(
            BookingResultHistoryEventV2 bookingResultHistoryEvent,
            List<ResultScoreInfoV1> resultScoreInfoList) {

    	ResultDetailsV2 mapResponse =
        		resultDetailsMapper.map(bookingResultHistoryEvent);
        assertNotNull(mapResponse);
        assertEquals(bookingResultHistoryEvent.getBookingResultInfo().getBookingUuid(),mapResponse.getBookingDetails().getBookingUuid());
        assertEquals(bookingResultHistoryEvent.getBookingResultInfo().getResultDetails().getResultUuid(),mapResponse.getBookingDetails().getResultDetails().getResultUuid());
        assertEquals(bookingResultHistoryEvent.getBookingResultInfo().getResultDetails().getCefrLevel(),mapResponse.getBookingDetails().getResultDetails().getCefrLevel());
        assertEquals(bookingResultHistoryEvent.getBookingResultInfo().getResultDetails().getTrfNumber(),mapResponse.getBookingDetails().getResultDetails().getTrfNumber());
    }

}
