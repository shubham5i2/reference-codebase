# Steps to follow to run in bastion
1. Open WinScp and provide shared bastion host details (PFB) and ppk file inside the advance option(authentication <PROVIDE_PPK_FILE>) , click Login
   File Protocol: SFTP
   Host Name: bastion.shared.cmdsiz.com
   Port: 22
   Username: cognizant
   Advance option(Authentication): <PROVIDE_PPK_FILE>

2.Copy the provided shells script and jar file into the remote bastion host. Provide execution rights to the copied files.

3.Go to Commands menu and then click Open in PuTTY

4. Run the script for unpublished by passing the argument booking uuids.All names are case sensitive.
   `sh ./emit-photochange-event-arguments.sh bookingUUID1 bookingUUID2 ... `
   For example, to run this script, use the following command
   `sh ./emit-photochange-event-arguments.sh ea44cfb7-49ac-4110-b85c-c19d64385423 74dc9928-131b-4947-8827-0428c6b3b6ac`

5.Once the script execution is successful,the updated booking_uuids will be displayed in the terminal.

# Photo-published-service Project

Note: This is for better understanding for the project, Not to be used in bastion host
## Introduction:
This module allows a user to publish the EVT-045 Photo published event from the provided booking UUIds.

## Arguments:
* **Booking uuids:** The list of booking ids to process.

## Packaging & run: 
1. **Building the JAR via:** ```mvn package```
2. **Run via command:** ```java  -jar photo-published-service-0.0.1-SNAPSHOT.jar 9bd68aeb-d47a-4d66-9796-a5a460980249```
