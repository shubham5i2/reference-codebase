#!/bin/bash
allBookings=""
if [ "$#" -gt 0 ]; then
  bookingUUIDs=("$@")
fi
for bookingUUID in "${bookingUUIDs[@]}"; do
  # Extract UUIDs from the current bookingUUID using grep
  uuids=$(echo "$bookingUUID" | grep -oE '\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b' | tr '\n' ' ')

  # Check if any UUIDs are found
if [ -n "$uuids" ]; then
    echo "Booking UUIDs for: $uuids"
    echo "______________________________"
    allBookings+=" $bookingUUID"
else
    echo "No valid UUIDs found for $bookingUUID"
fi
done
echo "Booking UUIDs: $allBookings"
java  -jar -Dspring.config.location=file:./config/application.properties photo-published-service-0.0.1-SNAPSHOT.jar $allBookings