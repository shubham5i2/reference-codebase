package com.ielts.cmds.ttservice.utils;

public class Constants {
    public static final String PHOTO_PUBLISHED = "PhotoPublished";
}
