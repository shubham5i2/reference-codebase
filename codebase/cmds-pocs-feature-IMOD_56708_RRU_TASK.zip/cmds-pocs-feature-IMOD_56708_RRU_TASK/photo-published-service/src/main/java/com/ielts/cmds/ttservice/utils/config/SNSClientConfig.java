package com.ielts.cmds.ttservice.utils.config;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.AmazonSNSClient;
import org.springframework.stereotype.Component;

@Component
public class SNSClientConfig {

    private SNSClientConfig() {
    }

    public static AmazonSNS getSNSClient() {
        return AmazonSNSClient.builder()
                .withRegion(Regions.EU_WEST_2)
                .build();
    }
}
