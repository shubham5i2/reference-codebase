package com.ielts.cmds.ttservice.repository;

import com.ielts.cmds.ttservice.entity.Photo;
import com.ielts.cmds.testtaker.common.events.model.PhotoCategoryEnum;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;


@Repository
public interface PhotoRepository extends CrudRepository<Photo, UUID> {

    Optional<Photo> findByBookingUuidAndPhotoCategoryOrderByPhotoVersionDesc(
            final UUID bookingUuid,
            final PhotoCategoryEnum photoCategory
    );

}
