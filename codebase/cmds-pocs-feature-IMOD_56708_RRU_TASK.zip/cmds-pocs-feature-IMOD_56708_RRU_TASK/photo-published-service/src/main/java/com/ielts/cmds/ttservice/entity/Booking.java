package com.ielts.cmds.ttservice.entity;


import com.ielts.cmds.api.evt_019.BookingDetailsV1.BookingStatusEnum;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.UUID;

@Data
@EqualsAndHashCode(exclude = {"updatedDatetime", "createdDatetime"})
@Entity
@Table(name = "booking")
public class Booking implements Serializable {
  private static final long serialVersionUID = 1123570468184916928L;

  @Id
  @Column(name = "booking_uuid")
  private UUID bookingUuid;

  @Column(name = "composite_candidate_number")
  private String compositeCandidateNumber;

  @Column(name = "partner_code")
  private String partnerCode;

  @Column(name = "test_date")
  private LocalDate testDate;

  @Column(name = "external_booking_uuid")
  private UUID externalBookingUuid;

  @Column(name = "unique_test_taker_uuid")
  private UUID uniqueTestTakerUuid;

  @Enumerated(EnumType.STRING)
  @Column(name = "booking_status")
  private BookingStatusEnum bookingStatus;

  @Column(name = "product_uuid")
  private UUID productUuid;

  @Column(name = "event_datetime")
  private OffsetDateTime eventDatetime;

  @Column(name = "updated_datetime")
  private OffsetDateTime updatedDatetime;

  @Column(name = "created_datetime")
  private OffsetDateTime createdDatetime;

//  @OneToMany(mappedBy = "booking", cascade = CascadeType.ALL)
//  private List<BookingLink> bookingLinks;
}
