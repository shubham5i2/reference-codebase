package com.ielts.cmds.ttservice.utils;

import com.ielts.cmds.ttservice.entity.Photo;
import com.ielts.cmds.testtaker.common.events.model.PhotoPublishedV1;
import org.springframework.stereotype.Component;

@Component
public class BuildPhotoPublished045 {


    public PhotoPublishedV1 generatePhotoResponse(Photo photo) {
        PhotoPublishedV1 photoPublished = new PhotoPublishedV1();
        photoPublished.setPhotoPath(photo.getFileName());
        photoPublished.setPhotoTypeUuid(photo.getPhotoTypeUuid());
        photoPublished.setPhotoVersion(photo.getPhotoVersion());
        photoPublished.setBookingUuid(photo.getBookingUuid());
        photoPublished.setCompositeCandidateNumber(photo.getCompositeCandidateNumber());
        photoPublished.setPhotoUuid(photo.getPhotoUuid());
        photoPublished.setPhotoCategory(photo.getPhotoCategory());
        return photoPublished;
    }

}
