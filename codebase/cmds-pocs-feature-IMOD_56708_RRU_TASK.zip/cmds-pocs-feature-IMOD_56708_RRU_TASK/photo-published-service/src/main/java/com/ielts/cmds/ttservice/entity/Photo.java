package com.ielts.cmds.ttservice.entity;

import com.ielts.cmds.testtaker.common.events.model.PhotoCategoryEnum;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.UUID;

@Getter
@Setter
@Entity
@Table(name = "photo")
public class Photo implements Serializable {

    private static final long serialVersionUID = 1845479687461848212L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "photo_uuid")
    private UUID photoUuid;

    @Column(name = "booking_uuid")
    private UUID bookingUuid;

    @Column(name = "composite_candidate_number")
    private String compositeCandidateNumber;

    @Column(name = "photo_type_uuid")
    private UUID photoTypeUuid;

    @Column(name = "source")
    private String source;

    @Column(name = "file_name")
    private String fileName;

    @Column(name = "photo_url")
    private String photoUrl;

    @Column(name = "photo_version")
    private Integer photoVersion;

    @Column(name = "photo_description")
    private String photoDescription;

    @Column(name = "created_datetime")
    private OffsetDateTime createdDatetime;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "updated_by")
    private String updatedBy;

    @Version
    @Column(name = "concurrency_version")
    private Integer concurrencyVersion;

    @Column(name = "photo_timestamp")
    private LocalDateTime photoTimestamp;

    @Column(name = "photo_external_uuid")
    private UUID photoExternalUuid;

    @Column(name = "external_booking_uuid")
    private UUID externalBookingUuid;

    @Enumerated(EnumType.STRING)
    @Column(name = "photo_category")
    private PhotoCategoryEnum photoCategory;

}