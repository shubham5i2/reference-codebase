package com.ielts.cmds.ttservice;

import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.ttservice.entity.Booking;
import com.ielts.cmds.ttservice.entity.Photo;
import com.ielts.cmds.ttservice.repository.BookingRepository;
import com.ielts.cmds.ttservice.repository.PhotoRepository;
import com.ielts.cmds.ttservice.utils.BuildPhotoPublished045;
import com.ielts.cmds.ttservice.utils.Constants;
import com.ielts.cmds.ttservice.utils.EventPublisher;
import com.ielts.cmds.ttservice.utils.Helpers;
import com.ielts.cmds.testtaker.common.events.model.PhotoCategoryEnum;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Slf4j
@ComponentScan("com.ielts.cmds")
@EnableJpaRepositories(basePackages = "com.ielts.cmds")
@EntityScan(basePackages = {"com.ielts.cmds"})
@SpringBootApplication
@RequiredArgsConstructor
public class PhotoPublishServiceApplication implements CommandLineRunner {

    @Value("${batchSize}")
    int batchSize;

    @Autowired
    private PhotoRepository photoRepository;
    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private EventPublisher eventPublisher;

    @Autowired
    private Helpers helpers;

    @Autowired
    private BuildPhotoPublished045 buildPhotoPublished045;

    public static void main(String[] args) {
        SpringApplication.run(PhotoPublishServiceApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        List<UUID> bookingTemps = new ArrayList<>();
        List<String> unProcessedBookings = new ArrayList<>();
        List<String> invalidUuids = new ArrayList<>();
        for (String arg: args){
            if(helpers.isValidUUID(arg)){
                bookingTemps.add(UUID.fromString(arg));
            }
            else {
                invalidUuids.add(arg);
                log.info("Booking not processed as the UUID is invalid: {}", arg);
            }
        }
        log.info("List of Invalid BookingUUID: {}", invalidUuids);

        List<List<UUID>> batchesList = helpers.createBatches(bookingTemps,batchSize);
        for(List<UUID> currentBatch : batchesList) {
            for (UUID bookingUUID : currentBatch) {
                log.info("Processing current batch: {}", currentBatch);

                Optional<Booking> booking1 = bookingRepository.findByBookingUuid(bookingUUID);
                if(booking1.isPresent()) {
                    Optional<Photo> photo = photoRepository.findByBookingUuidAndPhotoCategoryOrderByPhotoVersionDesc(bookingUUID, PhotoCategoryEnum.Certificate);
                    if(photo.isPresent()) {
                        log.info("Constructing PhotoPublish event for bookingUuid {}", bookingUUID);
                        ThreadLocalHeaderContext.setContext(eventPublisher.buildHeader(Constants.PHOTO_PUBLISHED));
                        ThreadLocalHeaderContext.getContext().getEventContext().put("bookingUuid", bookingUUID.toString());
                        ThreadLocalHeaderContext.getContext().setPartnerCode(booking1.get().getPartnerCode());
                        eventPublisher.publishV1Event(buildPhotoPublished045.generatePhotoResponse(photo.get()));
                        log.info("PhotoPublished event published for bookingUuid {} with transactionId {}", bookingUUID, ThreadLocalHeaderContext.getContext().getTransactionId());
                    }
                    else{
                        log.info("Photo of type certificate is not present for Booking {}",bookingUUID);
                    }
                }else{
                    log.info("Booking with BookingUuid {} is not present.",bookingUUID);
                }
            }
        }
        log.info("Bookings not processed due to booking version mismatch: {}", unProcessedBookings);
        log.info("Bookings not processed as the UUIDS are invalid: {}", invalidUuids);
        System.exit(0);
    }
}