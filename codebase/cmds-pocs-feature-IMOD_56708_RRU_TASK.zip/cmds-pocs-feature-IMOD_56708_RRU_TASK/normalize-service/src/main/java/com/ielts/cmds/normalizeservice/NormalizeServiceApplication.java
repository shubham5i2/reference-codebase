package com.ielts.cmds.normalizeservice;

import com.ielts.cmds.normalizeservice.utils.Helpers;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.ielts.cmds.normalizeservice.entity.BookingTemp;
import com.ielts.cmds.normalizeservice.repository.BookingTempRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Slf4j
@ComponentScan("com.ielts.cmds")
@EnableJpaRepositories(basePackages = "com.ielts.cmds")
@EntityScan(basePackages = {"com.ielts.cmds"})
@SpringBootApplication
@RequiredArgsConstructor
 public class NormalizeServiceApplication implements CommandLineRunner {

	@Value("${batchSize}")
	private int batchSize;
	@Autowired
	private Helpers helpers;
	@Autowired
	private BookingTempRepository bookingTempRepo;
	public static void main(String[] args) {
		SpringApplication.run(NormalizeServiceApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		List<BookingTemp> batches = bookingTempRepo.findAll();
		List<List<BookingTemp>> batchesListBooking = helpers.createBatches(batches,batchSize);
		for(List<BookingTemp> runningBatch: batchesListBooking){
			for(BookingTemp booking: runningBatch){
				log.info("Updating NormalizedID Number for bookingUuid {}", booking.getBookingUuid());
				String normalizedId = removeAllNonAlphaNumeric(booking.getIdentityNumber());
				booking.setNormalizedIdentityNumber(normalizedId);
			}
			bookingTempRepo.saveAll(runningBatch);
		}
		System.exit(0);
	}

	public String removeAllNonAlphaNumeric(String identityNumber) {
		if (identityNumber == null) {
			return null;
		}
		return identityNumber.replaceAll("[^\\p{Alnum}]", "").toUpperCase();
	}
}