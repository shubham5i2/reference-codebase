package com.ielts.cmds.normalizeservice.repository;


import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ielts.cmds.normalizeservice.entity.BookingTemp;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface BookingTempRepository extends CrudRepository<BookingTemp, UUID>, JpaSpecificationExecutor<BookingTemp> {
    Optional<BookingTemp> findByBookingUuid(final UUID bookingUuid);

    List<BookingTemp> findAll();
}
