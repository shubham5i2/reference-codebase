package com.ielts.cmds.normalizeservice.utils;

import com.ielts.cmds.normalizeservice.entity.BookingTemp;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Component
public class Helpers {

    public List<List<BookingTemp>> createBatches(List<BookingTemp> batches, int batchSize) {
        List<List<BookingTemp>> batch = new ArrayList<>();
        for(int i=0;i<batches.size();i+=batchSize){
            int end = Math.min(i+batchSize,batches.size());
            batch.add(batches.subList(i,end));
        }
        return batch;
    }
}
