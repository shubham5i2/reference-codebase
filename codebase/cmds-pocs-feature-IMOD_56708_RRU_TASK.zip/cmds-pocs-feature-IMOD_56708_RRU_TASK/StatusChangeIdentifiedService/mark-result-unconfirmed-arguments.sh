#!/bin/bash
allBookings=""
number_arg=""
if [ "$#" -ge 1 ]; then
  if [[ $1 =~ ^[0-9]+$ ]]; then
      number_arg="$1"
      shift
    fi
fi
if [ "$#" -gt 0 ]; then
  bookingUUIDs=("$@")
fi
echo $execution_output
for bookingUUID in "${bookingUUIDs[@]}"; do
uuids=$(echo "$bookingUUID " | grep -oE '\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b' | tr '\n' ' ')
if [ -n "$uuids" ]; then
    echo "Booking UUIDs for: $uuids"
    echo "______________________________"
    allBookings+=" $bookingUUID"
  else
    echo "No valid UUIDs found for $bookingUUID"
  fi
done
echo "Booking UUIDs: $allBookings"
if [ -n "$number_arg" ]; then
  echo "jar executed "
  java -Dspring.config.location=file:./config/application.properties -Dstep=$number_arg -jar rm-service-0.0.1-SNAPSHOT.jar $allBookings
else
  echo "Number argument not provided. Skipping JAR execution.Allowed values are 1 and 2 "
fi