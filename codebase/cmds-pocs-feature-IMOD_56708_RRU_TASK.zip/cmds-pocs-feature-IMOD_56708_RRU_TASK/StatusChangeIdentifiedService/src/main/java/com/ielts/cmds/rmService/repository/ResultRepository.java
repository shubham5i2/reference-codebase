package com.ielts.cmds.rmService.repository;

import com.ielts.cmds.rmService.entity.Result;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.io.Serializable;

@Repository
public interface ResultRepository extends CrudRepository<Result, Serializable> {

    Result findByBookingUuid(Serializable serializable);

}

