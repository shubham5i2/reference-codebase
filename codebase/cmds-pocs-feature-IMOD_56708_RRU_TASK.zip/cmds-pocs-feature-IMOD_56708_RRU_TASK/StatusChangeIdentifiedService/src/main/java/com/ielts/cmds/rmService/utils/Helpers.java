package com.ielts.cmds.rmService.utils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Component
public class Helpers {

    @Value("${batchSize}")
    private int batchSize;

    public boolean isValidUUID(String arg){
        try{
            UUID.fromString(arg);
            return true;
        }
        catch (IllegalArgumentException e){
            return false;
        }
    }

    public List<List<UUID>> createBatches(List<UUID> data){
        List<List<UUID>> batches = new ArrayList<>();
        for(int i=0;i<data.size();i+=batchSize){
            int end = Math.min(i+batchSize,data.size());
            batches.add(data.subList(i,end));
        }
        return batches;
    }
}
