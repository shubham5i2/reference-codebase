package com.ielts.cmds.rmService.utils;

public class Constants {
    public static final String OUTCOME_STATUS_TYPE_PASSED = "a9b16306-398d-4f61-af88-e2eda231cb4b";
    public static final String CONFIRMED_STATUS = "27c03460-2662-4a63-b1aa-6d158b85c0a5";
    public static final String STATUS_CHANGE_IDENTIFIED = "StatusChangeIdentified";
    public static final String RESULTS_STATUS_COMMENT_TEXT = "resultStatusCommentText";
}
