package com.ielts.cmds.rmService.utils;

import com.ielts.cmds.rm.common.out.model.StatusChangeIdentifiedEventV1;
import org.springframework.stereotype.Component;

import java.util.UUID;

import static com.ielts.cmds.rmService.utils.Constants.CONFIRMED_STATUS;

@Component
public class BuildStatusChangeIdentifiedUtils {

    public StatusChangeIdentifiedEventV1 buildStatusChangeIdentifiedEvent(UUID bookingUuid) {
        StatusChangeIdentifiedEventV1 statusChangeIdentifiedEventV1 = new StatusChangeIdentifiedEventV1();
        statusChangeIdentifiedEventV1.setBookingUuid(bookingUuid);
        statusChangeIdentifiedEventV1.setTargetStatusTypeUuid(UUID.fromString(CONFIRMED_STATUS));
        return statusChangeIdentifiedEventV1;
    }

}
