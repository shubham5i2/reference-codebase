package com.ielts.cmds.rmService.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import java.util.UUID;

/** Entity class for ResultLine */
@Entity
@Table(name = "result_line")
@Data
@EqualsAndHashCode(
        callSuper = true,
        exclude = {"bookingLineEntity", "result"})
@ToString(callSuper = true)
public class ResultLine extends CommonModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "result_line_uuid")
    private UUID resultLineUuid;

    @Column(name = "result_line_score")
    private Float resultLineScore;

    @ToString.Exclude
    @ManyToOne(cascade = CascadeType.REFRESH, fetch = FetchType.LAZY)
    @JoinColumn(name = "result_uuid")
    private Result result;

    @OneToOne(cascade = CascadeType.REFRESH, fetch = FetchType.LAZY)
    @JoinColumn(name = "booking_line_uuid")
    private BookingLineEntity bookingLineEntity;

    @Column(name = "external_test_id")
    private int externalTestId;
}
