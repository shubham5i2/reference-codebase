package com.ielts.cmds.rmService.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDate;
import java.util.UUID;

/** Entity class to hold columns of results_status_type table */
@Entity
@Table(name = "results_status_type")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class ResultsStatusType extends CommonModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "results_status_type_uuid")
    private UUID resultsStatusTypeUuid;

    @Column(name = "effective_from_date")
    private LocalDate effectiveFromDate;

    @Column(name = "effective_to_date")
    private LocalDate effectiveToDate;

    @Column(name = "results_status")
    private String resultsStatus;

    @Enumerated(EnumType.STRING)
    @Column(name = "results_status_code")
    private ResultsStatusTypeEnum resultsStatusCode;
}
