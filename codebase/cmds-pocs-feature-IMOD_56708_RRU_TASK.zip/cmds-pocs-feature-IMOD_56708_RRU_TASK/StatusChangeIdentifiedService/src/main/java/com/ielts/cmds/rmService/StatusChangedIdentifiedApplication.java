package com.ielts.cmds.rmService;

import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.rm.common.enums.ResultPublishStatusType;
import com.ielts.cmds.rm.common.out.model.StatusChangeIdentifiedEventV1;
import com.ielts.cmds.rmService.entity.Booking;
import com.ielts.cmds.rmService.entity.OutcomeStatus;
import com.ielts.cmds.rmService.entity.Result;
import com.ielts.cmds.rmService.repository.BookingRepository;
import com.ielts.cmds.rmService.repository.OutcomeStatusRepository;
import com.ielts.cmds.rmService.repository.ResultRepository;
import com.ielts.cmds.rmService.utils.BuildStatusChangeIdentifiedUtils;
import com.ielts.cmds.rmService.utils.EventPublisher;
import com.ielts.cmds.rmService.utils.Helpers;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static com.ielts.cmds.rmService.utils.Constants.OUTCOME_STATUS_TYPE_PASSED;
import static com.ielts.cmds.rmService.utils.Constants.RESULTS_STATUS_COMMENT_TEXT;
import static com.ielts.cmds.rmService.utils.Constants.STATUS_CHANGE_IDENTIFIED;

@Slf4j
@ComponentScan("com.ielts.cmds")
@EnableJpaRepositories(basePackages = "com.ielts.cmds")
@EntityScan(basePackages = {"com.ielts.cmds"})
@SpringBootApplication
@RequiredArgsConstructor
public class StatusChangedIdentifiedApplication implements CommandLineRunner {

    private final OutcomeStatusRepository outcomeStatusRepository;

    private final BookingRepository bookingRepository;

    private final ResultRepository resultRepository;

    private final EventPublisher eventPublisher;

    private final BuildStatusChangeIdentifiedUtils statusChangeIdentifiedUtils;

    private final Helpers helpers;

    @Value("${batchSize}")
    int batchSize;

    @Value("${step}")
    private String step;

    public static void main(String[] args) {
        SpringApplication.run(StatusChangedIdentifiedApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        List<UUID> bookingUuids = new ArrayList<>();
        List<UUID> unProcessedBookings = new ArrayList<>();
        List<String> invalidUuids = new ArrayList<>();
        for (String arg: args){
                bookingUuids.add(UUID.fromString(arg));
        }
        List<List<UUID>> batchesList = helpers.createBatches(bookingUuids);

        for(List<UUID> currentBatch : batchesList) {
            for (UUID currentBookingUuid : currentBatch) {
                log.info("Processing current batch: {}", currentBatch);
                processBooking(currentBookingUuid, unProcessedBookings);
            }
        }
        log.info("Bookings not processed due to booking version mismatch: {}", unProcessedBookings);
        log.info("Bookings not processed as the UUIDS are invalid: {}", invalidUuids);
        System.exit(0);
    }

    @Transactional
    private void processBooking(UUID currentBookingUuid, List<UUID> unProcessedBookings) {
        Booking booking = bookingRepository.findByBookingUuid(currentBookingUuid);
        if (!step.equals("2")) {
            updateResultTablePublishStatus(currentBookingUuid);
            //updateOutcomeStatusTable(booking);
        }
        if(!step.equals("1")) {
            publishStatusIdentifiedEvent(currentBookingUuid, booking);
        }
    }

    private void publishStatusIdentifiedEvent(UUID currentBookingUuid, Booking booking) {
            log.info("Constructing StatusChangeIdentified event for bookingUuid {}", currentBookingUuid);
            StatusChangeIdentifiedEventV1 evntBody = statusChangeIdentifiedUtils.buildStatusChangeIdentifiedEvent(currentBookingUuid);
            ThreadLocalHeaderContext.setContext(eventPublisher.buildHeader(STATUS_CHANGE_IDENTIFIED, booking.getPartnerCode()));
            ThreadLocalHeaderContext.getContext().getEventContext().put(RESULTS_STATUS_COMMENT_TEXT, "IMOD-56708");
            ThreadLocalHeaderContext.getContext().getEventContext().put("bookingUuid", currentBookingUuid.toString());
            log.info("Context {}", ThreadLocalHeaderContext.getContext());
            log.info("Body {}", evntBody);
            eventPublisher.publishV1Event(evntBody);
            log.info("StatusChangeIdentified event published for bookingUuid {} with transactionId {}", currentBookingUuid, ThreadLocalHeaderContext.getContext().getTransactionId());
    }

    private void updateOutcomeStatusTable(Booking booking) {
        OutcomeStatus outcomeStatus = outcomeStatusRepository.findByBookingUuid(booking.getBookingUuid());
        outcomeStatus.setOutcomeStatusTypeUuid(UUID.fromString(OUTCOME_STATUS_TYPE_PASSED));
        outcomeStatus.setBookingVersion(booking.getConcurrencyVersion());
        outcomeStatusRepository.save(outcomeStatus);
        log.info("OutcomeStatus table updated for bookingUuid {}", booking.getBookingUuid());
    }

    private void updateResultTablePublishStatus(UUID bookingUuid) {
        Result result = resultRepository.findByBookingUuid(bookingUuid);
        result.setResultPublishStatus(ResultPublishStatusType.UNPUBLISHED);
        resultRepository.save(result);
        log.info("Result table's publish status updated for bookingUuid {}", bookingUuid);
    }

}