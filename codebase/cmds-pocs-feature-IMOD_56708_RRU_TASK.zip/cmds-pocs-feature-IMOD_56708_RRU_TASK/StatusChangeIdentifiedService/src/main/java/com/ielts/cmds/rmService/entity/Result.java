package com.ielts.cmds.rmService.entity;

import com.ielts.cmds.rm.common.enums.ResultPublishStatusType;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Entity class for Result */
@Entity
@Table(name = "result")
@Data
@EqualsAndHashCode(
        callSuper = true,
        exclude = {"resultLines", "resultsStatusHistory"})
@ToString(callSuper = true)
public class Result extends CommonModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "result_uuid")
    private UUID resultUuid;

    @Column(name = "result_type_uuid")
    private UUID resultTypeUuid;

    @Column(name = "booking_uuid")
    private UUID bookingUuid;

    @Column(name = "result_score")
    private Float resultScore;

    @Column(name = "trf_number")
    private String trfNumber;

    @Column(name = "cefr_level")
    private String cefrLevel;

    @Column(name = "external_test_id")
    private Integer externalTestId;

    @Column(name = "published_time")
    private OffsetDateTime publishedTime;

    @Column(name = "on_hold")
    private Boolean onHold;

    @Column(name = "administrator_comments")
    private String administratorComments;

    @Column(name = "event_datetime")
    private LocalDateTime eventDatetime;

    @Column(name = "result_history_uuid")
    private UUID resultHistoryUuid;

    @Enumerated(EnumType.STRING)
    @Column(name = "result_publish_status")
    private ResultPublishStatusType resultPublishStatus;

    @OneToMany(
            mappedBy = "result",
            cascade = CascadeType.ALL,
            orphanRemoval = true,
            fetch = FetchType.LAZY)
    private Set<ResultLine> resultLines;

    @OneToOne(cascade = CascadeType.REFRESH, fetch = FetchType.LAZY)
    @JoinColumn(name = "results_status_history_uuid")
    private ResultsStatusHistory resultsStatusHistory;

    public void addResultLines(ResultLine resultLine) {
        if (resultLine != null) {
            if (this.resultLines == null) this.resultLines = new HashSet<>();
            this.resultLines.add(resultLine);
            resultLine.setResult(this);
        }
    }
    @Column(name = "booking_version")
    private Integer bookingVersion;

}
