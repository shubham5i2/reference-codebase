package com.ielts.cmds.rmService.entity;

public enum ResultsStatusTypeEnum {
    UNCONFIRMED,
    CONFIRMED,
    VALIDATED,
    PENDING_REVIEW,
    WITHHELD,
    PERMANENTLY_WITHHELD,
    ABSENT,
    RELEASED,
    INCOMPLETE
}
