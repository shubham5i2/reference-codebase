package com.ielts.cmds.rmService.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;
import java.time.Instant;

/** Entity class to hold audit columns */
@MappedSuperclass
@Data
@EqualsAndHashCode(exclude = {"updatedDateTime", "createdDateTime"})
@EntityListeners(AuditingEntityListener.class)
public class CommonModel {

    @CreatedBy
    @Column(name = "created_by", updatable = false)
    private String createdBy;

    @CreatedDate
    @Column(name = "created_datetime", updatable = false)
    private Instant createdDateTime;

    @LastModifiedBy
    @Column(name = "updated_by", insertable = false)
    private String updatedBy;

    @LastModifiedDate
    @Column(name = "updated_datetime", insertable = false)
    private Instant updatedDateTime;

    @Version
    @Column(name = "concurrency_version")
    private Integer concurrencyVersion;
}
