package com.ielts.cmds.rmService.entity;

import com.ielts.cmds.api.evt_019.BookingLineV1;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.OffsetDateTime;
import java.util.UUID;

/** Entity class to hold columns of booking_line table */
@Entity
@Table(name = "booking_line")
@Data
@EqualsAndHashCode(
        callSuper = true,
        exclude = {"booking"})
@NoArgsConstructor
public class BookingLineEntity extends CommonModel {

    @Id
    @Column(name = "booking_line_uuid")
    private UUID bookingLineUuid;

    @Column(name = "product_uuid")
    private UUID productUuid;

    @Column(name = "external_booking_line_uuid")
    private UUID externalBookingLineUuid;

    @Column(name = "booking_uuid", insertable = false, updatable = false)
    private UUID bookingUuid;

    @Column(name = "end_datetime")
    private OffsetDateTime endDateTime;

    @Enumerated(EnumType.STRING)
    @Column(name = "booking_line_status")
    private BookingLineV1.BookingLineStatusEnum bookingLineStatus;
}
