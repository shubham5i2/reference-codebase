package com.ielts.cmds.rmService.entity;

import com.ielts.cmds.api.evt_019.BookingDetailsV1;
import com.ielts.cmds.api.evt_019.TestTakerDetailsV1;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

/** Entity class to hold columns of booking table */
@Entity
@Table(name = "booking")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class Booking extends CommonModel {

    @Id
    @Column(name = "booking_uuid")
    private UUID bookingUuid;

    @Column(name = "external_booking_uuid")
    private UUID externalBookingUuid;

    @Column(name = "partner_code")
    private String partnerCode;

    @Column(name = "test_date")
    private LocalDate testDate;

    @Column(name = "financial_year")
    private Integer financialYear;

    @Column(name = "location_uuid")
    private UUID locationUuid;

    @Column(name = "product_uuid")
    private UUID productUuid;

    @Column(name = "unique_test_taker_uuid")
    private UUID uniqueTestTakerUuid;

    @Column(name = "unique_test_taker_id")
    private String uniqueTestTakerId;

    @Column(name = "short_candidate_number")
    private String shortCandidateNumber;

    @Column(name = "composite_candidate_number")
    private String compositeCandidateNumber;

    @Column(name = "birth_date")
    private LocalDate birthDate;

    @Column(name = "title")
    private String title;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "nationality_uuid")
    private UUID nationalityUuid;

    @Column(name = "nationality_other")
    private String nationalityOther;

    @Column(name = "identity_number")
    private String identityNumber;

    @OneToMany(mappedBy = "bookingUuid", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<BookingLineEntity> bookingLineEntities;

    @Enumerated(EnumType.STRING)
    @Column(name = "booking_status")
    private BookingDetailsV1.BookingStatusEnum bookingStatus;

    @Enumerated(EnumType.STRING)
    @Column(name = "booking_detail_status")
    private BookingDetailsV1.BookingDetailStatusEnum bookingDetailStatus;

    @Column(name = "event_datetime")
    private LocalDateTime eventDatetime;

    @Column(name = "is_void")
    private Boolean isVoid;

    @Enumerated(EnumType.STRING)
    @Column(name = "banned_status")
    private TestTakerDetailsV1.BannedStatusEnum bannedStatus;

    @OneToMany(mappedBy = "sourceBookingUuid", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<BookingLink> bookingLinks;

    @Column(name = "booking_version")
    private Integer bookingVersion;

    @Column(name = "identity_type_uuid")
    private UUID identityTypeUuid;

    @Column(name = "identity_issuing_authority")
    private String identityIssuingAuthority;

    @Column(name = "identity_expiry_date")
    private LocalDate identityExpiryDate;

    @Column(name = "sex_uuid")
    private UUID sexUuid;

    @Column(name = "email")
    private String email;

    @Column(name = "phone")
    private String phone;

    @Column(name = "mobile")
    private String mobile;

    @Column(name = "address_line_1")
    private String addressLine1;

    @Column(name = "address_line_2")
    private String addressLine2;

    @Column(name = "address_line_3")
    private String addressLine3;

    @Column(name = "address_line_4")
    private String addressLine4;

    @Column(name = "state_territory_uuid")
    private UUID stateTerritoryUuid;

    @Column(name = "postal_code")
    private String postalCode;

    @Column(name = "city")
    private String city;

    @Column(name = "country_uuid")
    private UUID countryUuid;

    @Column(name = "language_uuid")
    private UUID languageUuid;

}
