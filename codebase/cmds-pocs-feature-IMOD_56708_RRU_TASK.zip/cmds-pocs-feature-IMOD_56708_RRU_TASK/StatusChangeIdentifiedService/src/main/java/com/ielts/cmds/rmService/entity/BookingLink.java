package com.ielts.cmds.rmService.entity;

import com.ielts.cmds.api.evt_019.BookingLinkV1;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.UUID;

/** Entity class to hold columns of booking_link table */
@Entity
@Table(name = "booking_link")
@Data
@EqualsAndHashCode(
        callSuper = true,
        exclude = {"sourceBooking"})
@NoArgsConstructor
public class BookingLink extends CommonModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "booking_link_uuid")
    private UUID bookingLinkUuid;

    @Column(name = "target_booking_uuid")
    private UUID targetBookingUuid;

    @Column(name = "source_booking_uuid")
    private UUID sourceBookingUuid;

    @Enumerated(EnumType.STRING)
    @Column(name = "role")
    private BookingLinkV1.RoleEnum role;
}
