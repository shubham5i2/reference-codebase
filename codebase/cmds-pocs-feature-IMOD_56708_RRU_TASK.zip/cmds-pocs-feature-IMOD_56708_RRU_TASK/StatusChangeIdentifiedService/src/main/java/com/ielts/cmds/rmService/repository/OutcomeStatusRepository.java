package com.ielts.cmds.rmService.repository;


import com.ielts.cmds.rmService.entity.OutcomeStatus;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.io.Serializable;
import java.util.UUID;

@Repository
public interface OutcomeStatusRepository extends CrudRepository<OutcomeStatus, Serializable> {

    boolean existsByBookingUuidAndBookingVersionAndOutcomeStatusTypeUuid(UUID bookingUuid, Integer bookingVersion,
                                                                         UUID OutcomeStatusTypeUuid);
    OutcomeStatus findByBookingUuid(UUID bookingUuid);
}
