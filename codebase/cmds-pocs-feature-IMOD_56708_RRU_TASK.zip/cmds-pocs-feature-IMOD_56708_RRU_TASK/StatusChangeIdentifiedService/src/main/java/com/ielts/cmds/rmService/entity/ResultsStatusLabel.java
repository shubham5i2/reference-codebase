package com.ielts.cmds.rmService.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.time.LocalDate;
import java.util.UUID;

/** Entity class to hold columns of results_status_label table */
@Entity
@Table(name = "results_status_label")
@Data
@EqualsAndHashCode(
        callSuper = true)
@NoArgsConstructor
public class ResultsStatusLabel extends CommonModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "results_status_label_uuid")
    private UUID resultsStatusLabelUuid;

    @Column(name = "effective_from_date")
    private LocalDate effectiveFromDate;

    @Column(name = "effective_to_date")
    private LocalDate effectiveToDate;

    @ManyToOne(cascade = CascadeType.REFRESH, fetch = FetchType.LAZY)
    @JoinColumn(name = "results_status_type_uuid")
    private ResultsStatusType resultsStatusType;

    @Column(name = "results_status_label")
    private String statusLabel;

    @Column(name = "results_status_comment_mandatory")
    private Boolean resultsStatusCommentMandatory;
    
    @Column(name = "results_status_label_code")
    private String resultStatusLabelCode;

}
