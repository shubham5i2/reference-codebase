package com.ielts.cmds.rmService.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "outcome_status")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class OutcomeStatus extends CommonModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "outcome_status_uuid")
    private UUID outcomeStatusUuid;

    @Column(name = "booking_uuid")
    private UUID bookingUuid;

    @Column(name = "outcome_status_type_uuid")
    private UUID outcomeStatusTypeUuid;

    @Column(name = "event_datetime")
    private LocalDateTime eventDateTime;

    @Column(name = "booking_version")
    private Integer bookingVersion;
}
