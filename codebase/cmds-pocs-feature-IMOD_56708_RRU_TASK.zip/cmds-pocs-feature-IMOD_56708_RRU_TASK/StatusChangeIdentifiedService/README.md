# Steps to follow
1. Open WinScp and provide shared bastion host details (PFB) and ppk file inside the advance option(authentication <PROVIDE_PPK_FILE>) , click Login
   File Protocol: SFTP
   Host Name: bastion.shared.cmdsiz.com
   Port: 22
   Username: cognizant
   Advance option(Authentication): <PROVIDE_PPK_FILE>

2.Copy the provided shells script and jar file into the remote bastion host. Provide execution rights to the copied files.

3.Go to Commands menu and then click Open in PuTTY

4. Run the script for unpublished by passing the argument with 1 and booking uuids.All names are case sensitive.
   `sh ./mark-result-unpublished-arguments.sh 1 bookingUUID1 bookingUUID2 ... `
   For example, to run this script, use the following command
   `sh ./mark-result-unpublished-arguments.sh 1 ea44cfb7-49ac-4110-b85c-c19d64385423 74dc9928-131b-4947-8827-0428c6b3b6ac`

5. Similarly,run the script for unconfirmed by passing the argument with 1 and booking uuids.All names are case sensitive.
   `sh ./mark-result-unconfirmed-arguments.sh 2 bookingUUID1 bookingUUID2 ... `
   For example, to run this script, use the following command
   `sh ./mark-result-unconfirmed-arguments.sh 2 ea44cfb7-49ac-4110-b85c-c19d64385423 74dc9928-131b-4947-8827-0428c6b3b6ac`

6. Once the script execution is successful,the updated booking_uuids will be displayed in the terminal.

# StatusChangedIdentifiedService Project

Note: This is for better understanding for the project, Not to be used in bastion host
## Introduction:
This module allows a user to re-release the booking with latest booking information. That is one via two steps:
* Update the published status of a booking to UNPUBLISHED
* Publish CONFIRMED "StatusChangedIdentified" event.

## Arguments:
* **Booking uuids:** The list of booking ids to process.

## Flags & environment variables:
* **--step:** Allow to execute either or both steps.
  * **--step=1:** allows to only update the published status of a booking to UNPUBLISHED.
  * **--step=2:** allows to only Publish CONFIRMED "StatusChangedIdentified" event.
  * **Any other value:** Will execute both steps.

## Packaging & run:
1. **Building the JAR via:** ```mvn package```
2. **Run via command:** ```java -Dstep=1 -jar target/rm-service-0.0.1-SNAPSHOT.jar 9bd68aeb-d47a-4d66-9796-a5a460980249```
