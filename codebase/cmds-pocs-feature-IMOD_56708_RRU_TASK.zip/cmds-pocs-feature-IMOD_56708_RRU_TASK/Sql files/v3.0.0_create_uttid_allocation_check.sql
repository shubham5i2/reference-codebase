--create uttid allocation check table
CREATE TABLE IF NOT EXISTS booking_owner.uttid_allocation_check(unique_test_taker_uuid uuid,booking_uuid uuid ,check_condition varchar(255));