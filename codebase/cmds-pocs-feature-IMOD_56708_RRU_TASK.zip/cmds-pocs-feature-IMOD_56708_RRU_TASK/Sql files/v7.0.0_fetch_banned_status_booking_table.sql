--fetch the banned status for which booking got changed
SELECT table1.booking_id, table1.status AS status_table1, table2.status AS status_table2
FROM table1
JOIN table2 ON table1.booking_id = table2.booking_id
WHERE table1.status <> table2.status;