--temporary booking table for evt-040
CREATE TABLE IF NOT EXISTS booking_owner.booking_temp AS TABLE booking_owner.booking WITH NO DATA;