#!/bin/bash
getHost(){
env=$2
database=$1
db_dev=${database}-db.dev.cmdsiz.com
db_sandbox=${database}-db.sandbox.cmdsiz.com
db_sandbox2=${database}-db2.sandbox.cmdsiz.com
db_sandbox3=${database}-db3.sandbox.cmdsiz.com
db_sit=${database}-db.sit.cmdsiz.com
db_sit2=${database}-db2.sit.cmdsiz.com
db_uat=${database}-db.uat.cmdsiz.com
db_perf=${database}-db.perf.cmdsiz.com
db_staging=${database}-db.staging.cmdsiz.com
db_prod=${database}-db.cmdsiz.com
db_host_key=db_$env
host=$(eval "echo \$$db_host_key")
echo "Host name is: $host"
}
if [ "$#" -lt 2 ]; then
  echo "Usage: $0 <environment_name> <bookingUUID1> <bookingUUID2> ..."
  exit 1
fi
environment_name=$1
shift
bookingUUIDs=("$@")
source_database="booking"
getHost ${source_database} ${environment_name}
if [ "$host" == "" ]; then
  echo "Please enter correct environment name. Allowed values are sandbox,sandbox2,sandbox3,sit,sit2,uat,perf,staging,prod"
  exit 1
fi
echo "Enter Password for booking DB"
num=1
while [ $# -gt 0 ]
do
  query+="'$1',"
  shift
done
v2=${query::-1}
execution_output=$( psql --host ${host} --port 5432 -U postgres -d booking <<EOF
UPDATE booking_owner.booking set identity_verification_status = 'UNVERIFIED' where booking_uuid in ($v2)
EOF
)

echo "query for the $v2"
echo "$execution_output"


