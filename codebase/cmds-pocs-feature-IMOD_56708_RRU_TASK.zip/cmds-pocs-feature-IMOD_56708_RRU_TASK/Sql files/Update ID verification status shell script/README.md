1. Open WinScp and provide shared bastion host details (PFB) and ppk file inside the advance option(authentication <PROVIDE_PPK_FILE>) , click Login
   File Protocol: SFTP
   Host Name: bastion.shared.cmdsiz.com
   Port: 22
   Username: cognizant
   Advance option(Authentication): <PROVIDE_PPK_FILE>
2. Copy the provided shell script and CSV file into the remote bastion host. Provide execution rights to the copied files.
3. Go to Commands menu and then click Open in PuTTY
4. Run the script by passing the environment name. Allowed ENV_NAME in the below command are sandbox, prod. All names are case sensitive.
   `sh ./trf-script.sh <ENV_NAME>`
   For example, to run this script in sandbox, use the following command
   `sh ./trf-script.sh sandbox`
5. Now, the script prompts to provide Booking Mx postgres details (in the environment name you provided). Provide the Password (copy the password and right click on terminal and enter).
6. Once the script execution is successful,the updated booking_uuids will be displayed in the terminal.