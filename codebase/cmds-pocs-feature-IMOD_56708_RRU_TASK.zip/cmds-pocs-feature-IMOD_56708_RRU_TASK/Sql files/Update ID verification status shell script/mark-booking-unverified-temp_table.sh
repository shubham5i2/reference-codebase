#!/bin/bash
getHost(){
env=$2
database=$1
db_dev=${database}-db.dev.cmdsiz.com
db_sandbox=${database}-db.sandbox.cmdsiz.com
db_sandbox2=${database}-db2.sandbox.cmdsiz.com
db_sandbox3=${database}-db3.sandbox.cmdsiz.com
db_sit=${database}-db.sit.cmdsiz.com
db_sit2=${database}-db2.sit.cmdsiz.com
db_uat=${database}-db.uat.cmdsiz.com
db_perf=${database}-db.perf.cmdsiz.com
db_staging=${database}-db.staging.cmdsiz.com
db_prod=${database}-db.cmdsiz.com
db_host_key=db_$env
host=$(eval "echo \$$db_host_key")
echo "Host name is: $host"
}
environment_name=$1
source_database="booking"
getHost ${source_database} ${environment_name}
if [ "$host" == "" ]; then
  echo "Please enter correct environment name. Allowed values are sandbox, prod"
  exit 1
fi
echo "Enter Password for booking DB"
execution_output=$( psql --host ${host} --port 5432 -U postgres -d booking <<EOF
CREATE TABLE IF NOT EXISTS booking_owner.tmp_booking(booking_uuid uuid);
\copy tmp_booking FROM 'test.csv' WITH delimiter ',' csv header;
UPDATE booking_owner.booking set identity_verification_status = 'UNVERIFIED' from booking_owner.tmp_booking where tmp_booking.booking_uuid = booking.booking_uuid;
EOF
)
bookingUuids=$( psql --host ${host} --port 5432 -U postgres -d booking <<EOF
SELECT booking_uuid FROM tmp_booking;
EOF
)
echo $execution_output
echo $bookingUuids
echo "______________________________"
uuids=$(echo "$bookingUuids" | grep -oE '\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b' | tr '\n' ' ')
echo "Booking UUIDs: $uuids"
