--fetch the uttid which got changed
select a.booking_uuid , a.external_booking_uuid from booking_owner.booking_temp a
join booking_owner.booking c on c.unique_test_taker_uuid != a.unique_test_taker_uuid
and c.booking_uuid = a.booking_uuid
and c.external_booking_uuid = a.external_booking_uuid;

