--insert query to update uttid_allocation_check table
INSERT INTO booking_owner.uttid_allocation_check(unique_test_taker_uuid,booking_uuid,check_condition)
select a.unique_test_taker_uuid, a.booking_uuid,'check1_criteria1' as check_condition from  booking_owner.bookingtemp a
join booking_owner.unique_test_taker_identity b on a.external_unique_test_taker_uuid = b.external_unique_test_taker_uuid
AND a.booking_uuid = b.booking_uuid
UNION
select a.unique_test_taker_uuid, a.booking_uuid,'check1_criteria2' as check_condition from  booking_owner.bookingtemp a
join booking_owner.unique_test_taker_identity b on a.external_unique_test_taker_uuid = b.external_unique_test_taker_uuid
AND a.booking_uuid != b.booking_uuid
UNION
select a.unique_test_taker_uuid,a.booking_uuid,'check2_criteria1' as check_condition from  booking_owner.bookingtemp a
join booking_owner.unique_test_taker_identity b on a.nationality_uuid = b.nationality_uuid
AND a.normalized_identity_number = b.normalized_identity_number
UNION
select a.unique_test_taker_uuid,a.booking_uuid,'check3_criteria1' as check_condition from  booking_owner.bookingtemp a
join booking_owner.unique_test_taker_identity b on a.nationality_uuid = b.nationality_uuid
AND a.first_name = b.first_name AND a.last_name = b.last_name AND a.birth_date = b.birth_date;