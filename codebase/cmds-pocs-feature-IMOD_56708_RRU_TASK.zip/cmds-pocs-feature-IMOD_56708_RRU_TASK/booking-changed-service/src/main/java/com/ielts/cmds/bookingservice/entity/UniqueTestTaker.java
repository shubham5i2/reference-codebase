package com.ielts.cmds.bookingservice.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Version;
import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Data
@ToString(exclude = {"booking", "uniqueTestTakerIdentityList"})
@EqualsAndHashCode(exclude = {"booking", "updatedDatetime", "createdDatetime",
    "uniqueTestTakerIdentityList"})
@Entity
@Table(name = "unique_test_taker")
public class UniqueTestTaker implements Serializable {

  private static final long serialVersionUID = -9137861765026704924L;

  @Id
  @Column(name = "unique_test_taker_uuid")
  private UUID uniqueTestTakerUuid;

  @OneToMany(mappedBy = "uniqueTestTaker")
  private List<Booking> booking;

  @Column(name = "unique_test_taker_id")
  private String uniqueTestTakerId;

  @Column(name = "created_datetime")
  private OffsetDateTime createdDatetime;

  @Column(name = "updated_datetime")
  private OffsetDateTime updatedDatetime;

  @Version
  @Column(name = "concurrency_version")
  private Integer concurrencyVersion;

  @OneToMany(mappedBy = "uniqueTestTaker", cascade = CascadeType.ALL)
  private List<UniqueTestTakerIdentity> uniqueTestTakerIdentityList = new ArrayList<>();

  public void addUttIdentity(UniqueTestTakerIdentity uniqueTestTakerIdentity) {
    uniqueTestTakerIdentity.setUniqueTestTaker(this);
    uniqueTestTakerIdentityList.add(uniqueTestTakerIdentity);
  }
}
