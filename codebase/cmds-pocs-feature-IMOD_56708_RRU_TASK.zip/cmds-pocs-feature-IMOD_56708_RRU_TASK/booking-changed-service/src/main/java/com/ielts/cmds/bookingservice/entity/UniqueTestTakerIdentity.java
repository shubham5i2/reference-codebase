package com.ielts.cmds.bookingservice.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.Version;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(
    exclude = {
        "uniqueTestTakerIdentityUuid",
        "externalUniqueTestTakerUuid",
        "email",
        "uniqueTestTaker",
        "uniqueTestTakerUuid",
        "updatedDatetime",
        "createdDatetime",
        "reasonForMatch",
        "bookingUUID",
        "externalBookingUuid",
        "concurrencyVersion",
        "exclusion",
        "isPersisted",
        "updatedBy"


    })
@Entity
@Table(name = "unique_test_taker_identity")
public class UniqueTestTakerIdentity implements Serializable {

  private static final long serialVersionUID = -3758247641078622442L;

  @Id
//  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "unique_test_taker_identity_uuid")
  private UUID uniqueTestTakerIdentityUuid;

  @Column(name = "identity_type_uuid")
  private UUID identityTypeUuid;

  @Column(name = "external_unique_test_taker_uuid")
  private UUID externalUniqueTestTakerUuid;

  @Column(name = "external_booking_uuid")
  private UUID externalBookingUuid;

  @Column(name = "nationality_uuid")
  private UUID nationalityUuid;

  @Column(name = "first_name")
  private String firstName;

  @Column(name = "last_name")
  private String lastName;

  @Column(name = "birth_date")
  private LocalDate birthDate;

  @Column(name = "identity_number")
  private String identityNumber;

  @Column(name = "normalized_identity_number")
  private String normalizedIdentityNumber;

  @Column(name = "email")
  private String email;

  @Column(name = "created_datetime")
  private OffsetDateTime createdDatetime;

  @Column(name = "updated_datetime")
  private OffsetDateTime updatedDatetime;

  @Column(name = "unique_test_taker_uuid", insertable = false, updatable = false)
  private UUID uniqueTestTakerUuid;

  @OneToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "unique_test_taker_uuid" )
  private UniqueTestTaker uniqueTestTaker;

  @Column(name = "booking_uuid")
  private UUID bookingUUID;

  @Transient
  private String reasonForMatch;

  @Version
  @Column(name = "concurrency_version")
  private Integer concurrencyVersion;

  @Transient
  private boolean isPersisted;

  @Column(name = "exclusion")
  private boolean exclusion;

  @Column(name = "updated_by")
  private String updatedBy;

  @Transient
  private UUID presentUniqueTestTakerUuid;

  @Transient
  private String presentReasonForMatch;
}
