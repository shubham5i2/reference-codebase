package com.ielts.cmds.bookingservice.utils;

public class Constants {
    public static final String BOOKING_UPDATED_EVENT = "BookingUpdated";
}
