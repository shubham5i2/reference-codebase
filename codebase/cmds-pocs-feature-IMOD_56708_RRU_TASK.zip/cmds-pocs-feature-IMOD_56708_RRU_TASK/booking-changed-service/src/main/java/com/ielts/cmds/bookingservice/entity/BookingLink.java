package com.ielts.cmds.bookingservice.entity;


import com.ielts.cmds.booking.common.enums.RoleEnum;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.UUID;

@Getter
@Setter
@Entity(name="booking_link_bk")
@Table(name = "booking_link")
public class BookingLink implements Serializable {

  private static final long serialVersionUID = 1111112729029091060L;

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "booking_link_uuid")
  private UUID bookingLinkUuid;

  @Enumerated(EnumType.STRING)
  @Column(name = "role")
  private RoleEnum role;

  @Column(name = "source_booking_uuid")
  private UUID sourceBookingUuid;

  @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
  @JoinColumn(name = "target_booking_uuid")
  private Booking booking;
}