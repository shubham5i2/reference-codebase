package com.ielts.cmds.bookingservice.repository;

import com.ielts.cmds.booking.common.enums.RoleEnum;
import com.ielts.cmds.bookingservice.entity.Booking;
import com.ielts.cmds.bookingservice.entity.BookingLink;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface BookingLinkRepository extends CrudRepository<BookingLink, UUID>, JpaSpecificationExecutor<BookingLink> {
    List<BookingLink> findByBooking(final Booking booking);
    List<BookingLink> findByBookingBookingUuidAndRole(final UUID booking,final RoleEnum roleEnum);



    List<BookingLink> findBySourceBookingUuid(final UUID bookingUuid);
    List<BookingLink> findBySourceBookingUuidAndRole(final UUID bookingUuid,final RoleEnum role);

}