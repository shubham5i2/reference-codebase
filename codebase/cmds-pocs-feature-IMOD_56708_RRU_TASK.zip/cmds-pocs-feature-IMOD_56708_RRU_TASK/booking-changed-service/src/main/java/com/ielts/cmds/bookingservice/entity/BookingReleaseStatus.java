package com.ielts.cmds.bookingservice.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.UUID;

@Data
@EqualsAndHashCode(exclude = {"bookingReleaseStatusUpdateDatetime", "updatedDatetime", "createdDatetime"})
@Entity
@Table(name = "booking_release_status")
public class BookingReleaseStatus implements Serializable {

  private static final long serialVersionUID = 8901231110243966730L;

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "booking_release_status_uuid")
  private UUID bookingReleaseStatusUuid;

  @Column(name = "booking_uuid")
  private UUID bookingUuid;

  @Column(name = "results_status_type_uuid")
  private UUID resultsStatusTypeUuid;

  @Column(name = "booking_release_status_updated_datetime")
  private OffsetDateTime bookingReleaseStatusUpdateDatetime;

  @Version
  @Column(name = "concurrency_version")
  private Integer concurrencyVersion;

  @Column(name = "updated_datetime")
  private OffsetDateTime updatedDatetime;

  @Column(name = "created_datetime")
  private OffsetDateTime createdDatetime;

  @Column(name = "on_hold")
  private boolean onHold;

  @Column(name = "last_event_datetime")
  private LocalDateTime lastEventDateTime;
}
