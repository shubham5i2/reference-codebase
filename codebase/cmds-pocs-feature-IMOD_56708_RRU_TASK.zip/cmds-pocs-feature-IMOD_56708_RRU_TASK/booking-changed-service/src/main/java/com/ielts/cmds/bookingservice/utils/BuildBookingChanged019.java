package com.ielts.cmds.bookingservice.utils;

import com.ielts.cmds.api.evt_019.*;
import com.ielts.cmds.bookingservice.entity.Booking;
import com.ielts.cmds.bookingservice.repository.BookingLinkRepository;
import com.ielts.cmds.bookingservice.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Component
public class BuildBookingChanged019 {

    @Autowired
    private BookingRepository bookingRepo;

    @Autowired
    private BookingLinkRepository bookingLinkRepository;

    public BookingDetailsV1 bookingDetailsFrom019(
            final Booking booking
    ) {
        BookingDetailsV1 bookingResponse = new BookingDetailsV1();
        if (Objects.nonNull(booking.getBookingUuid())) {
            bookingResponse.setBookingUuid(booking.getBookingUuid());
        }
        bookingResponse.setExternalBookingUuid(booking.getExternalBookingUuid());
        bookingResponse.setIsVoid(false);
        bookingResponse.setPartnerCode(booking.getPartnerCode());
        if (Objects.nonNull(booking.getLocationUuid())) {
            bookingResponse.setLocationUuid(booking.getLocationUuid());
        }
        if (Objects.nonNull(booking.getProductUuid())) {
            bookingResponse.setProductUuid(booking.getProductUuid());
        }
        bookingResponse.setTestDate(booking.getTestDate().getUtcDateTime());
        bookingResponse.setBookingStatus(BookingDetailsV1.BookingStatusEnum.valueOf(booking.getBookingStatus().toString()));
        bookingResponse.setBookingDetailStatus(BookingDetailsV1.BookingDetailStatusEnum.valueOf(booking.getBookingDetailStatus().toString()));
        bookingResponse.setTestPlatformReady(booking.isTestPlatformReady());
        bookingResponse.setExternalBookingReference(booking.getExternalBookingReference());
        bookingResponse.setMarketingInfo(populateBookingResponseMarketingInfo019(booking));
        bookingResponse.setTestTaker(populateBookingResponseTestTaker019(booking));
        bookingResponse.setBookingLines(populateBookingResponseBookingLines019(booking));
        bookingResponse.setAgentName(booking.getAgentName());
        if (booking.getConsentGiven() != null) {
            bookingResponse.setConsentGiven(booking.getConsentGiven());
        }
        bookingResponse.setLinkedBookings(bookingLinksOf019(booking));

        if (booking.getConcurrencyVersion() != null) {
            try {
                Booking updatedBooking = bookingRepo.findByBookingUuidOrderByConcurrencyVersionDesc(booking.getBookingUuid());
                bookingResponse.setBookingVersion(BigDecimal.valueOf(updatedBooking.getConcurrencyVersion()));
            } catch (DataIntegrityViolationException e) {
                bookingResponse.setBookingVersion(BigDecimal.valueOf(booking.getConcurrencyVersion()));
            }
        }

        return bookingResponse;
    }

    private MarketingInfoV1 populateBookingResponseMarketingInfo019(Booking booking) {
        MarketingInfoV1 bookingResponseMarketingInfo = new MarketingInfoV1();
        if (Objects.nonNull(booking.getEducationLevelUuid()))
            bookingResponseMarketingInfo.setEducationLevelUuid(booking.getEducationLevelUuid());
        if (Objects.nonNull(booking.getYearsOfStudy())) {
            bookingResponseMarketingInfo.setYearsOfStudy(BigDecimal.valueOf(booking.getYearsOfStudy()));
        }
        if (Objects.nonNull(booking.getOccupationSectorUuid()))
            bookingResponseMarketingInfo.setOccupationSectorUuid(booking.getOccupationSectorUuid());
        if (Objects.nonNull(booking.getOccupationLevelUuid()))
            bookingResponseMarketingInfo.setOccupationLevelUuid(booking.getOccupationLevelUuid());
        if (Objects.nonNull(booking.getReasonForTestUuid()))
            bookingResponseMarketingInfo.setReasonForTestUuid(booking.getReasonForTestUuid());
        bookingResponseMarketingInfo.setApplyingToCountryUuid(String.valueOf(booking.getApplyingToCountryUuid()));
        bookingResponseMarketingInfo.setCurrentEnglishStudyPlace(booking.getCurrentEnglishStudyPlace());
        bookingResponseMarketingInfo.setOccupationSectorOther(booking.getOccupationSectorOther());
        bookingResponseMarketingInfo.setOccupationLevelOther(booking.getOccupationLevelOther());
        bookingResponseMarketingInfo.setReasonForTestOther(booking.getReasonForTestOther());
        bookingResponseMarketingInfo.setCountryApplyingToOther(booking.getCountryApplyingToOther());

        return bookingResponseMarketingInfo;
    }

    private TestTakerDetailsV1 populateBookingResponseTestTaker019(Booking booking) {
        TestTakerDetailsV1 testTakerDetailsV1 = new TestTakerDetailsV1();
        if (Objects.nonNull(booking.getUniqueTestTakerUuid())) {
            testTakerDetailsV1.setUniqueTestTakerUuid(booking.getUniqueTestTakerUuid());
            testTakerDetailsV1.setUniqueTestTakerId(booking.getUniqueTestTaker().getUniqueTestTakerId());
        }
        testTakerDetailsV1.setBannedStatus(TestTakerDetailsV1.BannedStatusEnum.valueOf(booking.getBannedStatus()));
        testTakerDetailsV1.setShortCandidateNumber(
                String.format("%06d", booking.getShortCandidateNumber()));
        testTakerDetailsV1.setCompositeCandidateNumber(booking.getCompositeCandidateNumber());
        testTakerDetailsV1.setExternalUniqueTestTakerUuid(booking.getExternalUniqueTestTakerUuid());
        testTakerDetailsV1.setIdentityNumber(booking.getIdentityNumber());
        if (Objects.nonNull(booking.getIdentityTypeUuid()))
            testTakerDetailsV1.setIdentityTypeUuid(booking.getIdentityTypeUuid());
        testTakerDetailsV1.setIdentityVerificationStatus(TestTakerDetailsV1.IdentityVerificationStatusEnum.valueOf(booking.getIdentityVerificationStatus().toString()));
        testTakerDetailsV1.setIdentityIssuingAuthority(booking.getIdentityIssuingAuth());
        testTakerDetailsV1.setIdentityExpiryDate(booking.getIdentityExpiryDate());
        testTakerDetailsV1.setFirstName(booking.getFirstName());
        testTakerDetailsV1.setLastName(booking.getLastName());
        testTakerDetailsV1.setBirthDate(booking.getBirthDate());
        testTakerDetailsV1.setSexUuid(booking.getSexUuid());
        testTakerDetailsV1.setEmail(booking.getEmail());
        testTakerDetailsV1.setTitle(booking.getTitle());
        testTakerDetailsV1.setPhone(booking.getPhone());
        testTakerDetailsV1.setMobile(booking.getMobile());
        testTakerDetailsV1.setSebPassword(booking.getSeb().getSebPassword());
        testTakerDetailsV1.setTestPlatformUsername(booking.getTestPlatformUsername());
        testTakerDetailsV1.setTestPlatformPassword(booking.getTestPlatformPassword());
        if (Objects.nonNull(booking.getLanguageUuid()))
            testTakerDetailsV1.setLanguageUuid(booking.getLanguageUuid());
        if (Objects.nonNull(booking.getNationalityUuid()))
            testTakerDetailsV1.setNationalityUuid(booking.getNationalityUuid());
        testTakerDetailsV1.setNotes(booking.getNotes());
        testTakerDetailsV1.setLanguageOther(booking.getLanguageOther());
        testTakerDetailsV1.setNationalityOther(booking.getNationalityOther());
        testTakerDetailsV1.setAddress(populateTestTakerAddress019(booking));
        return testTakerDetailsV1;
    }

    private TestTakerAddressV1 populateTestTakerAddress019(Booking booking) {
        TestTakerAddressV1 address = new TestTakerAddressV1();
        address.setAddressLine1(booking.getAddressLine1());
        address.setAddressLine2(booking.getAddressLine2());
        address.setAddressLine3(booking.getAddressLine3());
        address.setAddressLine4(booking.getAddressLine4());
        if (Objects.nonNull(booking.getStateTerritoryUuid()))
            address.setStateTerritoryUuid(booking.getStateTerritoryUuid());
        address.setPostalCode(booking.getPostalCode());
        address.setCity(booking.getCity());
        address.setCountryUuid(booking.getCountryUuid());
        return address;
    }

    private List<BookingLineV1> populateBookingResponseBookingLines019(Booking booking) {
        List<BookingLineV1> bookingLinesResponse = new ArrayList<>();
        if (booking != null && booking.getBookingLines() != null) {
            booking.getBookingLines()
                    .forEach(
                            bookingLine -> {
                                BookingLineV1 bookingLineResponse = new BookingLineV1();
                                bookingLineResponse.setExternalBookingLineUuid(bookingLine.getExternalBookingLineUuid());
                                if (Objects.nonNull(bookingLine.getBookingLineUuid())) {
                                    bookingLineResponse.setBookingLineUuid(bookingLine.getBookingLineUuid());
                                }
                                if (Objects.nonNull(bookingLine.getProductUuid())) {
                                    bookingLineResponse.setProductUuid(bookingLine.getProductUuid());
                                }
                                bookingLineResponse.setStartDateTime(bookingLine.getStartDatetime());
                                bookingLineResponse.setEndDateTime(bookingLine.getEndDatetime());
                                bookingLineResponse.setStartTimeLocal(bookingLine.getStartDatetimeLocal().toOffsetDateTime());
                                bookingLineResponse.setBookingLineStatus(BookingLineV1.BookingLineStatusEnum.valueOf(bookingLine.getBookinLineStatus().toString()));
                                bookingLineResponse.setTestPlatformReady(bookingLine.isTestPlatformReady());
//								if (!bookingLine.getAccessArrangements().isEmpty()) {
//									bookingLineResponse.setArrangementTypes(populateArrangementTypes(bookingLine.getAccessArrangements()));
//								} else {
//									bookingLineResponse.setArrangementTypes(Collections.emptyList());
//								}
                                bookingLinesResponse.add(bookingLineResponse);
                            }
                    );
        }

        return bookingLinesResponse;
    }

    public List<BookingLinkV1> bookingLinksOf019(Booking booking) {
        List<BookingLinkV1> bookingLinks = new ArrayList<>();

        List<com.ielts.cmds.bookingservice.entity.BookingLink> links =
                bookingLinkRepository.findBySourceBookingUuid(booking.getBookingUuid()
                );

        if(links != null && !links.isEmpty()) {
            links.forEach(
                    link -> {
                        BookingLinkV1 bookingLink = new BookingLinkV1();
                        bookingLink.setRole(BookingLinkV1.RoleEnum.valueOf(link.getRole().toString()));
                        bookingLink.setLinkedBooking(new LinkedBookingV1());
                        bookingLink.getLinkedBooking().setBookingUuid(link.getBooking().getBookingUuid());
                        bookingLink.getLinkedBooking().setProductUuid(link.getBooking().getProductUuid());
                        bookingLink.getLinkedBooking().setExternalBookingUuid(
                                link.getBooking().getExternalBookingUuid()
                        );

                        bookingLinks.add(bookingLink);
                    }
            );
        }
        return bookingLinks;
    }
}
