package com.ielts.cmds.orsservice.entity;

import com.ielts.cmds.booking.common.enums.BookingLineStatusEnum;
import lombok.Data;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Version;
import java.io.Serializable;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;
import java.util.UUID;

@Data
@Entity(name="booking_line")
@ToString(exclude = {"booking"})
@Table(name = "booking_line")
public class BookingLine implements Serializable {

    private static final long serialVersionUID = 1111112729029091060L;

    @Id
    @Column(name = "booking_line_uuid")
    private UUID bookingLineUuid;

    @Column(name = "external_booking_line_uuid")
    private UUID externalBookingLineUuid;

    @Column(name = "product_uuid")
    private UUID productUuid;

    @Column(name = "location_uuid")
    private UUID locationUuid;

    @Column(name = "start_datetime")
    private OffsetDateTime startDatetime;

    @Column(name = "start_datetime_local")
    private ZonedDateTime startDatetimeLocal;

    @Column(name = "extra_time_min")
    private Integer extraTimeMin;

    @Column(name = "end_datetime")
    private OffsetDateTime endDatetime;

    @Enumerated(EnumType.STRING)
    @Column(name = "booking_line_status")
    private BookingLineStatusEnum bookinLineStatus;

    @Column(name = "test_platform_ready")
    private boolean testPlatformReady;

//    @OneToMany(mappedBy = "bookingLine", cascade = CascadeType.ALL)
//    private List<AccessArrangement> accessArrangements = new ArrayList<>();

    @Column(name = "created_datetime")
    private OffsetDateTime createdDatetime;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;

    @Version
    @Column(name = "concurrency_version")
    private Integer concurrencyVersion;

    @ManyToOne
    @JoinColumn(name = "booking_uuid")
    private Booking booking;
}
