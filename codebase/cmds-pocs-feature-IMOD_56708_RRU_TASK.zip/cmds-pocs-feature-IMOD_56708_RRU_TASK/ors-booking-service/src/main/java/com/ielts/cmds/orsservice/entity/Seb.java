package com.ielts.cmds.orsservice.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;
import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.UUID;

@Data
@EqualsAndHashCode(exclude = {"updatedDatetime", "createdDatetime"})
@Entity
@Table(name = "seb")
public class Seb implements Serializable {

  private static final long serialVersionUID = -2125657685314291694L;

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "seb_uuid")
  private UUID sebUuid;

  @Column(name = "location_uuid")
  private UUID locationUuid;

  @Column(name = "product_uuid")
  private UUID productUuid;

  @Column(name = "test_date")
  private OffsetDateTime testDate;

  @ToString.Exclude
  @Column(name = "seb_password")
  private String sebPassword;

  @Column(name = "created_datetime")
  private OffsetDateTime createdDatetime;

  @Column(name = "updated_datetime")
  private OffsetDateTime updatedDatetime;

  @Version
  @Column(name = "concurrency_version")
  private Integer concurrencyVersion;
}
