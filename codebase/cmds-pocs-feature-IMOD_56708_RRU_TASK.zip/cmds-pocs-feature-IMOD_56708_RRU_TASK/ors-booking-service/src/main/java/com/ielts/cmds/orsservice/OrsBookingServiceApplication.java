package com.ielts.cmds.orsservice;

import com.ielts.cmds.api.evt_040.BookingChangeRequested;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.orsservice.entity.Booking;
import com.ielts.cmds.orsservice.repository.BookingRepository;
import com.ielts.cmds.orsservice.utils.BuildBookingChanged040;
import com.ielts.cmds.orsservice.utils.Constants;
import com.ielts.cmds.orsservice.utils.EventPublisher;
import com.ielts.cmds.orsservice.utils.Helpers;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;


@Slf4j
@ComponentScan("com.ielts.cmds")
@EnableJpaRepositories(basePackages = "com.ielts.cmds")
@EntityScan(basePackages = {"com.ielts.cmds"})
@SpringBootApplication
public class OrsBookingServiceApplication implements CommandLineRunner {

    @Value("${batchSize}")
    int batchSize;
    @Autowired
    private BookingRepository bookingRepo;

    @Autowired
    private EventPublisher eventPublisher;

    @Autowired
    private BuildBookingChanged040 response;

    @Autowired
    private Helpers helpers;

    public static void main(String[] args) {
        SpringApplication.run(OrsBookingServiceApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        List<UUID> bookingTemps = new ArrayList<>();
        List<String> unProcessedBookings = new ArrayList<>();
        List<String> invalidUuids = new ArrayList<>();
        for (String arg: args){
            if(helpers.isValidUUID(arg)){
                bookingTemps.add(UUID.fromString(arg));
            }
            else {
                invalidUuids.add(arg);
                log.info("Booking not processed as the UUID is invalid: {}", arg);
            }
        }
        log.info("List of Invalid BookingUUID: {}", invalidUuids);

        List<List<UUID>> batchesList = helpers.createBatches(bookingTemps,batchSize);
        for(List<UUID> currentBatch : batchesList) {
            for (UUID bookingUUID : currentBatch) {
                log.info("Processing current batch: {}", currentBatch);

                Optional<Booking> booking1 = bookingRepo.findByBookingUuid(bookingUUID);
                if(booking1.isPresent()){
                    log.info("Constructing BookingChanged event for bookingUuid {}",bookingUUID);
                    BookingChangeRequested bookingChangeRequested = response.bookingDetailsFrom040(booking1.get());
                    ThreadLocalHeaderContext.setContext(eventPublisher.buildHeader(Constants.BOOKING_CHANGE_REQUESTED));
                    ThreadLocalHeaderContext.getContext().setPartnerCode(booking1.get().getPartnerCode());
                    ThreadLocalHeaderContext.getContext().getEventContext().put("bookingUuid",bookingUUID.toString());
                    eventPublisher.publishV2Event(bookingChangeRequested);
                    log.info("BookingChanged event published for bookingUuid {} with transactionId {}",bookingUUID,ThreadLocalHeaderContext.getContext().getTransactionId());
                }
                else{
                    unProcessedBookings.add(bookingUUID.toString());
                }

            }
        }
        log.info("Bookings not processed as not found in Booking DB: {}", unProcessedBookings);
        log.info("Bookings not processed as the UUIDS are invalid: {}", invalidUuids);
        System.exit(0);
    }
}