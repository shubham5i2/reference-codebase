package com.ielts.cmds.orsservice.utils;

public class Constants {
   public static final String BOOKING_CHANGE_REQUESTED = "BookingChangeRequested";
}
