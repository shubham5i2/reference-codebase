package com.ielts.cmds.orsservice.utils;

import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.MessageAttributeValue;
import com.amazonaws.services.sns.model.PublishRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalErrorContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.orsservice.utils.config.SNSClientConfig;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import static java.time.ZoneOffset.UTC;

@Slf4j
@Component
public class EventPublisher {

    private final ObjectMapper mapper;
    private final AmazonSNS snsClient;

    @Value("${aws.sns.ors-ext-topic-in.arn}")
    private String topicArn;

    public EventPublisher() {
        this.mapper = this.getMapperWithProperties();
        this.snsClient = SNSClientConfig.getSNSClient();
    }

    @SneakyThrows
    public <T> void publishV1Event(final T message) {

        log.info("In V1 publisher with metadata {}", ThreadLocalHeaderContext.getContext());
        Map<String, MessageAttributeValue> messageAttributes = this.getMessageAttributesForV1();

        log.info("Request for publishing BaseHeader initiated");
        BaseEvent<BaseHeader> event = this.getBaseEvent(message);
        PublishRequest snsPublishRequest = this.buildBaseEventPublisher(event, messageAttributes);
        log.info("V1 Event published with eventBody and structure {}", event);

        this.snsClient.publish(snsPublishRequest);
        log.info("Event V1 being Published from Runner Service with metadata as {}", ThreadLocalHeaderContext.getContext());

    }

    @SneakyThrows
    public <T> void publishV2Event(final T message) {
        log.info("In V2 publisher with metadata {}", ThreadLocalHeaderContext.getContext());
        Map<String, MessageAttributeValue> messageAttributes = this.getMessageAttributesForV2();
        PublishRequest snsPublishRequest = (new PublishRequest()).withMessageAttributes(messageAttributes).withTopicArn(topicArn).withMessage(this.mapper.writeValueAsString(message));

        this.snsClient.publish(snsPublishRequest);
        log.info("Event V2 being Published from Runner Service with metadata as {}", ThreadLocalHeaderContext.getContext());
    }


    protected <T> BaseEvent<BaseHeader> getBaseEvent(final T message) throws JsonProcessingException {
        return (new BaseEvent<>(this.getBaseHeader(), this.mapper.writeValueAsString(message), this.getBaseEventErrors(), this.getBaseAudit()));
    }

    private PublishRequest buildBaseEventPublisher(BaseEvent<BaseHeader> event, Map<String, MessageAttributeValue> messageAttributes) throws JsonProcessingException {
        return (new PublishRequest()).withTopicArn(topicArn).withMessageAttributes(messageAttributes).withMessage(this.mapper.writeValueAsString(event));
    }

    protected BaseHeader getBaseHeader() {
        BaseHeader baseHeader = new BaseHeader();
        BeanUtils.copyProperties(ThreadLocalHeaderContext.getContext(), baseHeader);
        return baseHeader;
    }

    protected BaseAudit getBaseAudit() {
        BaseAudit audit = new BaseAudit();
        if(Objects.nonNull(ThreadLocalAuditContext.getContext())) {
            BeanUtils.copyProperties(ThreadLocalAuditContext.getContext(), audit);
        }
        return audit;
    }

    protected BaseEventErrors getBaseEventErrors() {
        BaseEventErrors errors = new BaseEventErrors();
        if(Objects.nonNull(ThreadLocalErrorContext.getContext())) {
            BeanUtils.copyProperties(ThreadLocalErrorContext.getContext(), errors);
        }
        return errors;
    }

    @SneakyThrows
    protected Map<String, MessageAttributeValue> getMessageAttributesForV1() {
        Map<String, MessageAttributeValue> messageAttributes = new HashMap<>();
        CMDSHeaderContext context = ThreadLocalHeaderContext.getContext();
        messageAttributes.put("eventName", (new MessageAttributeValue()).withDataType("String").withStringValue(context.getEventName()));
        if (context.getPartnerCode() != null) {
            messageAttributes.put("partnerCode", (new MessageAttributeValue()).withDataType("String").withStringValue(context.getPartnerCode()));
        }

        if (context.getConnectionId() != null) {
            messageAttributes.put("connectionId", (new MessageAttributeValue()).withDataType("String").withStringValue(context.getConnectionId()));
        }
        return messageAttributes;
    }

    @SneakyThrows
    protected Map<String, MessageAttributeValue> getMessageAttributesForV2() {

        Map<String, MessageAttributeValue> messageAttributes = new HashMap<>();
        CMDSHeaderContext context = ThreadLocalHeaderContext.getContext();
        messageAttributes.put("eventHeaders", (new MessageAttributeValue()).withDataType("String.Array").withStringValue(this.mapper.writeValueAsString(context)));
        messageAttributes.put("eventName", (new MessageAttributeValue()).withDataType("String").withStringValue(context.getEventName()));
        if (context.getPartnerCode() != null) {
            messageAttributes.put("partnerCode", (new MessageAttributeValue()).withDataType("String").withStringValue(context.getPartnerCode()));
        }

        if (ThreadLocalAuditContext.getContext() != null) {
            messageAttributes.put("audit", (new MessageAttributeValue()).withDataType("String.Array").withStringValue(this.mapper.writeValueAsString(ThreadLocalAuditContext.getContext())));
        }
        return messageAttributes;
    }

    private ObjectMapper getMapperWithProperties() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE, false);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        return mapper;
    }

    public CMDSHeaderContext buildHeader(String eventName) {
        CMDSHeaderContext header = new CMDSHeaderContext();
        header.setTransactionId(UUID.randomUUID());
        header.setCorrelationId(UUID.randomUUID());
        header.setEventDateTime(LocalDateTime.now(UTC));
        header.setEventName(eventName);
        header.setEventContext(new HashMap<>());
        return header;
    }

}
