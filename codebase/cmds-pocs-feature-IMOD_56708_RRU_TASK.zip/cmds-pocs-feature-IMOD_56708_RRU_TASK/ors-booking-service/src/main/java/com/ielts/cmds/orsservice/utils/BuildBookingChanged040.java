package com.ielts.cmds.orsservice.utils;

import com.ielts.cmds.api.evt_040.*;
import com.ielts.cmds.orsservice.entity.Booking;
import com.ielts.cmds.orsservice.repository.BookingLinkRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Component
public class BuildBookingChanged040 {

    @Autowired
    private BookingLinkRepository bookingLinkRepository;

    public BookingChangeRequested bookingDetailsFrom040(
            final Booking booking
    ) {
        BookingChangeRequested response040 = new BookingChangeRequested();
        if (Objects.nonNull(booking.getProductUuid())) {
            response040.setProductUuid(booking.getProductUuid());
        }
        if (Objects.nonNull(booking.getLocationUuid())) {
            response040.setLocationUuid(booking.getLocationUuid());
        }
        response040.setTestDate(booking.getTestDate().getUtcDateTime());
        response040.setExternalBookingUuid(booking.getExternalBookingUuid());
        response040.setExternalBookingReference(booking.getExternalBookingReference());
        response040.setBookingDetailStatus(BookingChangeRequested.BookingDetailStatusEnum.valueOf(booking.getBookingDetailStatus().toString()));
        response040.setBookingStatus(BookingChangeRequested.BookingStatusEnum.valueOf(booking.getBookingStatus().toString()));
        response040.setAgentName(booking.getAgentName());
        if (booking.getConsentGiven() != null) {
            response040.setConsentGiven(booking.getConsentGiven());
        }
        response040.setMarketingInfo(populateBookingResponseMarketingInfo040(booking));
        response040.setTestTaker(populateBookingResponseTestTaker040(booking));
        response040.setBookingLines(populateBookingResponseBookingLines040(booking));
        response040.setLinkedBookings(bookingLinksOf040(booking));

        return response040;
    }

    private MarketingInfo populateBookingResponseMarketingInfo040(Booking booking) {
        MarketingInfo bookingResponseMarketingInfo = new MarketingInfo();
        if (Objects.nonNull(booking.getEducationLevelUuid()))
            bookingResponseMarketingInfo.setEducationLevelUuid(booking.getEducationLevelUuid());
        if (Objects.nonNull(booking.getYearsOfStudy())) {
            bookingResponseMarketingInfo.setYearsOfStudy(booking.getYearsOfStudy());
        }
        if (Objects.nonNull(booking.getOccupationSectorUuid()))
            bookingResponseMarketingInfo.setOccupationSectorUuid(booking.getOccupationSectorUuid());
        if (Objects.nonNull(booking.getOccupationLevelUuid()))
            bookingResponseMarketingInfo.setOccupationLevelUuid(booking.getOccupationLevelUuid());
        if (Objects.nonNull(booking.getReasonForTestUuid()))
            bookingResponseMarketingInfo.setReasonForTestUuid(booking.getReasonForTestUuid());
        bookingResponseMarketingInfo.setApplyingToCountryUuid(booking.getApplyingToCountryUuid());
        bookingResponseMarketingInfo.setOccupationSectorOther(booking.getOccupationSectorOther());
        bookingResponseMarketingInfo.setOccupationLevelOther(booking.getOccupationLevelOther());
        bookingResponseMarketingInfo.setReasonForTestOther(booking.getReasonForTestOther());
        bookingResponseMarketingInfo.setCountryApplyingToOther(booking.getCountryApplyingToOther());

        return bookingResponseMarketingInfo;
    }

    private TestTakerDetails populateBookingResponseTestTaker040(Booking booking) {
        TestTakerDetails testTakerDetails = new TestTakerDetails();
        testTakerDetails.setExternalUniqueTestTakerUuid(booking.getExternalUniqueTestTakerUuid());
        testTakerDetails.setIdentityNumber(booking.getIdentityNumber());
        if (Objects.nonNull(booking.getIdentityTypeUuid()))
            testTakerDetails.setIdentityTypeUuid(booking.getIdentityTypeUuid());
        testTakerDetails.setIdentityVerificationStatus(TestTakerDetails.IdentityVerificationStatusEnum.valueOf(booking.getIdentityVerificationStatus().toString()));
        testTakerDetails.setIdentityIssuingAuthority(booking.getIdentityIssuingAuth());
        testTakerDetails.setIdentityExpiryDate(booking.getIdentityExpiryDate());
        testTakerDetails.setFirstName(booking.getFirstName());
        testTakerDetails.setLastName(booking.getLastName());
        testTakerDetails.setBirthDate(booking.getBirthDate());
        testTakerDetails.setSexUuid(booking.getSexUuid());
        testTakerDetails.setEmail(booking.getEmail());
        testTakerDetails.setTitle(booking.getTitle());
        testTakerDetails.setPhone(booking.getPhone());
        testTakerDetails.setMobile(booking.getMobile());
        if (Objects.nonNull(booking.getLanguageUuid()))
            testTakerDetails.setLanguageUuid(booking.getLanguageUuid());
        if (Objects.nonNull(booking.getNationalityUuid()))
            testTakerDetails.setNationalityUuid(booking.getNationalityUuid());
        testTakerDetails.setLanguageOther(booking.getLanguageOther());
        testTakerDetails.setNationalityOther(booking.getNationalityOther());
        testTakerDetails.setNotes(booking.getNotes());
        testTakerDetails.setAddress(populateTestTakerAddress040(booking));

        return testTakerDetails;
    }

    private TestTakerAddress populateTestTakerAddress040(Booking booking) {
        TestTakerAddress address = new TestTakerAddress();
        address.setAddressLine1(booking.getAddressLine1());
        address.setAddressLine2(booking.getAddressLine2());
        address.setAddressLine3(booking.getAddressLine3());
        address.setAddressLine4(booking.getAddressLine4());
        if (Objects.nonNull(booking.getStateTerritoryUuid()))
            address.setStateTerritoryUuid(booking.getStateTerritoryUuid());
        address.setPostalCode(booking.getPostalCode());
        address.setCity(booking.getCity());
        address.setCountryUuid(booking.getCountryUuid());
        return address;
    }

    private List<BookingLine> populateBookingResponseBookingLines040(Booking booking) {
        List<BookingLine> bookingLinesResponse = new ArrayList<>();
        if (booking != null && booking.getBookingLines() != null) {
            booking.getBookingLines()
                    .forEach(
                            bookingLine -> {
                                BookingLine bookingLineResponse = new BookingLine();
                                bookingLineResponse.setExternalBookingLineUuid(bookingLine.getExternalBookingLineUuid());
                                bookingLineResponse.setStartDateTime(bookingLine.getStartDatetime());
                                bookingLineResponse.setStartDateTimeLocal(bookingLine.getStartDatetimeLocal().toOffsetDateTime());
                                if (Objects.nonNull(bookingLine.getProductUuid())) {
                                    bookingLineResponse.setProductUuid(bookingLine.getProductUuid());
                                }
                                if (Objects.nonNull(bookingLine.getBookinLineStatus())) {
                                    bookingLineResponse.setBookingLineStatus(BookingLine.BookingLineStatusEnum.valueOf(bookingLine.getBookinLineStatus().toString()));
                                }
                                bookingLinesResponse.add(bookingLineResponse);
                            }
                    );
        }

        return bookingLinesResponse;
    }

    public List<BookingLink> bookingLinksOf040(Booking booking) {
        List<BookingLink> bookingLinks = new ArrayList<>();

        List<com.ielts.cmds.orsservice.entity.BookingLink> links =
                bookingLinkRepository.findBySourceBookingUuid(booking.getBookingUuid()
                );

        if(links != null && !links.isEmpty()) {
            links.forEach(
                    link -> {
                        BookingLink bookingLink = new BookingLink();
                        bookingLink.setRole(BookingLink.RoleEnum.valueOf(link.getRole().toString()));
                        bookingLink.setLinkedBooking(new LinkedBooking());
                        bookingLink.getLinkedBooking().setProductUuid(link.getBooking().getProductUuid());
                        bookingLink.getLinkedBooking().setExternalBookingUuid(link.getBooking().getExternalBookingUuid());

                        bookingLinks.add(bookingLink);
                    }
            );
        }
        return bookingLinks;
    }
}
