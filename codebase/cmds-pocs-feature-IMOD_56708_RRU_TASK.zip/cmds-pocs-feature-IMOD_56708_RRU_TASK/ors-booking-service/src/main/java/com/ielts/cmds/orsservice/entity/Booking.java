package com.ielts.cmds.orsservice.entity;


import com.ielts.cmds.booking.common.enums.BookingDetailStatusEnum;
import com.ielts.cmds.booking.common.enums.BookingStatusEnum;
import com.ielts.cmds.booking.common.enums.IdentityVerificationStatusEnum;
import com.ielts.cmds.common.persistence.utils.CMDSOffsetDatetime;
import com.ielts.cmds.common.persistence.utils.CMDSOffsetDatetimeType;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Version;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

@Data
@EqualsAndHashCode(exclude = {"bookingLines", "bookingLinks", "updatedDatetime", "uniqueTestTakerIdentityList",
        "createdDatetime", "testPlatformUsername", "bookingReleaseStatus", "matchDate"})
@Entity(name="booking")
@Table(name = "bookingtemp")
@TypeDefs({
        @TypeDef(defaultForType = CMDSOffsetDatetime.class, typeClass = CMDSOffsetDatetimeType.class)
})
public class Booking implements Serializable {

  private static final long serialVersionUID = 1123570468184916928L;

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "booking_uuid")
  private UUID bookingUuid;

  @Column(name = "location_uuid")
  private UUID locationUuid;

  @Column(name = "product_uuid")
  private UUID productUuid;

  // Use Attribute override if you want to override default column names
  @AttributeOverrides({
          @AttributeOverride(name = "isoDateTime", column = @Column(name = "test_date_string")),
          @AttributeOverride(name = "localDate", column = @Column(name = "test_date")),
          @AttributeOverride(name = "localOffset", column = @Column(name = "test_date_offset")),
          @AttributeOverride(name = "utcDateTime", column = @Column(name = "test_date_utc"))
  })
  @Embedded
  private CMDSOffsetDatetime testDate;

  @Column(name = "external_booking_reference")
  private String externalBookingReference;

  @Column(name = "external_booking_uuid")
  private UUID externalBookingUuid;

  @Enumerated(EnumType.STRING)
  @Column(name = "booking_status")
  private BookingStatusEnum bookingStatus;

  @Enumerated(EnumType.STRING)
  @Column(name = "booking_detail_status")
  private BookingDetailStatusEnum bookingDetailStatus;

  @Enumerated(EnumType.STRING)
  @Column(name = "identity_verification_status")
  private IdentityVerificationStatusEnum identityVerificationStatus;

  @Column(name = "partner_code")
  private String partnerCode;

  @Column(name = "agent_name")
  private String agentName;

  @Column(name = "consent_given")
  private Boolean consentGiven;

  @Column(name = "banned_status")
  private String bannedStatus;

  @Column(name = "is_void")
  private Boolean isVoid;

  @Column(name = "unique_test_taker_uuid")
  private UUID uniqueTestTakerUuid;

  @Column(name = "external_unique_test_taker_uuid")
  private UUID externalUniqueTestTakerUuid;

  @Column(name = "short_candidate_number")
  private Integer shortCandidateNumber;

  @Column(name = "composite_candidate_number")
  private String compositeCandidateNumber;

  @Column(name = "test_platform_username")
  private String testPlatformUsername;

  @ToString.Exclude
  @Column(name = "test_platform_password")
  private String testPlatformPassword;

  @Column(name = "test_platform_ready")
  private boolean testPlatformReady;

  @Column(name = "first_name")
  private String firstName;

  @Column(name = "last_name")
  private String lastName;

  @Column(name = "email")
  private String email;

  @Column(name = "identity_number")
  private String identityNumber;

  @Column(name = "identity_type_uuid")
  private UUID identityTypeUuid;

  @Column(name = "identity_issuing_auth")
  private String identityIssuingAuth;

  @Column(name = "identity_expiry_date")
  private LocalDate identityExpiryDate;

    @Column(name = "birth_date")
    private LocalDate birthDate;

    @Column(name = "sex")
    private String sex;

    @Column(name = "gender_uuid")
    private UUID sexUuid;

    @Column(name = "title")
    private String title;

    @Column(name = "language_uuid")
    private UUID languageUuid;

    @Column(name = "nationality_uuid")
    private UUID nationalityUuid;

    @Column(name = "notes")
    private String notes;

    @Column(name = "phone")
    private String phone;

    @Column(name = "mobile")
    private String mobile;

    @Column(name = "address_line_1")
    private String addressLine1;

    @Column(name = "address_line_2")
    private String addressLine2;

    @Column(name = "address_line_3")
    private String addressLine3;

    @Column(name = "address_line_4")
    private String addressLine4;

    @Column(name = "state_territory_uuid")
    private UUID stateTerritoryUuid;

    @Column(name = "postal_code")
    private String postalCode;

    @Column(name = "city")
    private String city;

    @Column(name = "country_iso3_code")
    private String countryIso3Code;

    @Column(name = "country_uuid")
    private UUID countryUuid;

    @Column(name = "special_arrangement_required")
    private Boolean specialArrangementRequired;

    @Column(name = "education_level_uuid")
    private UUID educationLevelUuid;

    @Column(name = "years_of_study")
    private Integer yearsOfStudy;

    @Column(name = "occupation_sector_uuid")
    private UUID occupationSectorUuid;

    @Column(name = "occupation_level_uuid")
    private UUID occupationLevelUuid;

    @Column(name = "reason_for_test_uuid")
    private UUID reasonForTestUuid;

    @Column(name = "country_applying_to")
    private String countryApplyingTo;

    @Column(name = "applying_to_country_uuid")
    private UUID applyingToCountryUuid;

    @Column(name = "current_english_study_place")
    private String currentEnglishStudyPlace;

    @Column(name = "occupation_sector_other")
    private String occupationSectorOther;

    @Column(name = "occupation_level_other")
    private String occupationLevelOther;

    @Column(name = "reason_for_test_other")
    private String reasonForTestOther;

    @Column(name = "country_applying_to_other")
    private String countryApplyingToOther;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;

    @Column(name = "created_datetime")
    private OffsetDateTime createdDatetime;

    @Column(name = "updated_by")
    private String updatedBy;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "language_other")
    private String languageOther;

    @Column(name = "nationality_other")
    private String nationalityOther;

    @OneToMany(mappedBy = "booking", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<BookingLine> bookingLines;

    @OneToMany(mappedBy = "booking", cascade = CascadeType.ALL)
    private List<BookingLink> bookingLinks;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "unique_test_taker_uuid", referencedColumnName = "unique_test_taker_uuid", insertable = false, updatable = false)
    private UniqueTestTaker uniqueTestTaker;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "seb_uuid")
    private Seb seb;

    @Version
    @Column(name = "concurrency_version")
    private Integer concurrencyVersion;

    @Column(name = "reason_for_match")
    private String reasonForMatch;

    @OneToMany
    @JoinColumn(name = "booking_uuid", referencedColumnName = "booking_uuid")
    private List<UniqueTestTakerIdentity> uniqueTestTakerIdentityList;

    @OneToMany
    @JoinColumn(name = "booking_uuid", referencedColumnName = "booking_uuid")
    private List<BookingReleaseStatus> bookingReleaseStatus;

    @Column(name = "match_date")
    private LocalDate matchDate;

    @Column(name = "last_event_datetime")
    private LocalDateTime lastEventDateTime;

    @Column(name = "normalized_identity_number")
    private String normalizedIdentityNumber;
}
