import json
import logging
import sys
# Logger
logging.basicConfig(level=logging.DEBUG)

path = {
    "/v2/reference/address_type":{"reference_type":"address_type"},
    "/v2/reference/address_type/{addressTypeUuid}":{"reference_type":"address_type"},
    "/v2/reference/access_arrangement_type":{"reference_type":"access_arrangement_type"},
    "/v2/reference/access_arrangement_type/{accessArrangementTypeUuid}":{"reference_type":"access_arrangement_type"},
    "/v2/reference/ban_reason":{"reference_type":"ban_reason"},
    "/v2/reference/ban_reason/{banReasonUuid}":{"reference_type":"ban_reason"},
    "/v2/reference/check_outcome_status":{"reference_type":"check_outcome_status"},
    "/v2/reference/check_outcome_status/{checkOutcomeStatusUuid}":{"reference_type":"check_outcome_status"},
    "/v2/reference/check_outcome_type":{"reference_type":"check_outcome_type"},
    "/v2/reference/check_outcome_type/{checkOutcomeTypeUuid}":{"reference_type":"check_outcome_type"},
    "/v2/reference/contact_type":{"reference_type":"contact_type"},
    "/v2/reference/contact_type/{contactTypeUuid}":{"reference_type":"contact_type"},
    "/v2/reference/education_level":{"reference_type":"education_level"},
    "/v2/reference/education_level/{educationLevelUuid}":{"reference_type":"education_level"},
    "/v2/reference/gender":{"reference_type":"gender"},
    "/v2/reference/gender/{genderUuid}":{"reference_type":"gender"},
    "/v2/reference/identification_type":{"reference_type":"identification_type"},
    "/v2/reference/identification_type/{identificationTypeUuid}":{"reference_type":"identification_type"},
    "/v2/reference/incident_status_type":{"reference_type":"incident_status_type"},
    "/v2/reference/incident_status_type/{incidentStatusUuid}":{"reference_type":"incident_status_type"},
    "/v2/reference/language":{"reference_type":"language"},
    "/v2/reference/language/{languageUuid}":{"reference_type":"language"},
    "/v2/reference/mark_criteria":{"reference_type":"mark_criteria"},
    "/v2/reference/mark_criteria/{markCriteriaUuid}":{"reference_type":"mark_criteria"},
    "/v2/reference/module_type":{"reference_type":"module_type"},
    "/v2/reference/module_type/{moduleTypeUuid}":{"reference_type":"module_type"},
    "/v2/reference/nationality":{"reference_type":"nationality"},
    "/v2/reference/nationality/{nationalityUuid}":{"reference_type":"nationality"},
    "/v2/reference/note_type":{"reference_type":"note_type"},
    "/v2/reference/note_type/{noteTypeUuid}":{"reference_type":"note_type"},
    "/v2/reference/occupation_level":{"reference_type":"occupation_level"},
    "/v2/reference/occupation_level/{occupationLevelUuid}":{"reference_type":"occupation_level"},
    "/v2/reference/occupation_sector":{"reference_type":"occupation_sector"},
    "/v2/reference/occupation_sector/{occupationSectorUuid}":{"reference_type":"occupation_sector"},
    "/v2/reference/organisation_type":{"reference_type":"organisation_type"},
    "/v2/reference/organisation_type/{organisationTypeUuid}":{"reference_type":"organisation_type"},
    "/v2/reference/outcome_status_type":{"reference_type":"outcome_status_type"},
    "/v2/reference/outcome_status_type/{outcomeStatusTypeUuid}":{"reference_type":"outcome_status_type"},
    "/v2/reference/partner":{"reference_type":"partner"},
    "/v2/reference/partner/{partnerUuid}":{"reference_type":"partner"},
    "/v2/reference/photo_type":{"reference_type":"photo_type"},
    "/v2/reference/photo_type/{photoTypeUuid}":{"reference_type":"photo_type"},
    "/v2/reference/reason_for_test":{"reference_type":"reason_for_test"},
    "/v2/reference/reason_for_test/{reasonForTestUuid}":{"reference_type":"reason_for_test"},
    "/v2/reference/results_type":{"reference_type":"results_type"},
    "/v2/reference/results_type/{resultsTypeUuid}":{"reference_type":"results_type"},
    "/v2/reference/sector_type":{"reference_type":"sector_type"},
    "/v2/reference/sector_type/{sectorTypeUuid}":{"reference_type":"sector_type"}
}


def get_json_from_file(filename):
    with open(filename) as json_file:
        data = json.load(json_file)
    return data


def write_json_to_file(filename, data):
    with open(filename, 'w') as f:
        json.dump(data, f, indent=4)
    return True


def get_integration_value_with_given_templates_for_generic_reference(lambda_arn, request_template, response_template, response_code):
    return {
        "uri": "arn:aws:apigateway:${AWS::Region}:lambda:path/2015-03-31/functions/" + lambda_arn + "/invocations",
        "responses": {
            "default":
            {
                "statusCode": response_code,
                "responseTemplates": {
                    "application/json": response_template
                }
            },
            ".*.400.*": {
                "statusCode": 400,
                "responseTemplates": {
                    "application/json": "#set ($errorMessageObj = $util.parseJson($input.path('$.errorMessage')))$errorMessageObj.body"
                }
            }
        },
        "requestTemplates": {
                    "application/json": request_template
        },
        "passthroughBehavior": "when_no_match",
        "httpMethod": "POST",
        "contentHandling": "CONVERT_TO_TEXT",
        "type": "aws"
    }


def update_root_level_data(data, custom_security_schemes_default_key, custom_security_schemes_value, custom_security_schemes_key, validators_definition_value, validators_definition_key, filename):
    # Removing default Root level Scheme
    data['components']['securitySchemes'].pop(
        custom_security_schemes_default_key)

    bad_request_value = {"statusCode": "400", "responseType": "BAD_REQUEST_BODY", "responseTemplates": {
        "application/json": "{\n     \"interface\": \"$context.resourcePath\",\n     \"type\":  \"ERROR\",\n     \"errorCode\":  \"400\",\n     \"errorTicketUuid\":  \"$context.requestId\",\n     \"message\":  \"$context.error.validationErrorString\",\n     \"title\": $context.error.messageString\n}"}}
    bad_request_parameter_value = {"statusCode": "400", "responseType": "BAD_REQUEST_PARAMETERS", "responseTemplates": {
        "application/json": "{\n     \"interface\": \"$context.resourcePath\",\n     \"type\":  \"ERROR\",\n     \"errorCode\":  \"400\",\n     \"errorTicketUuid\":  \"$context.requestId\",\n     \"message\":  \"$context.error.validationErrorString\",\n     \"title\": $context.error.messageString\n}"}}
    data['x-amazon-apigateway-gateway-responses']["BAD_REQUEST_BODY"] = bad_request_value
    data['x-amazon-apigateway-gateway-responses']["BAD_REQUEST_PARAMETERS"] = bad_request_parameter_value
    data['components']['securitySchemes'][custom_security_schemes_key] = custom_security_schemes_value

    data[validators_definition_key] = validators_definition_value
    logging.debug("Root Level data is updated successfully")
    return True


def update_method_level_data(custom_security_schemes_value, data, mock_integration_value, method_integration_key, method_security_value, method_security_key, method_validator_value, method_validator_key, filename):
    # Adding Method level data
    paths = data['paths']
    for current_path in paths:
        # Adding Options method in LPR for solving CORS issues
      options_method_value = {
        "responses": {
            "200": {
                "description": "200 response",
                "headers": {
                    "Access-Control-Allow-Origin": {
                        "schema": {
                            "type": "string"
                        }
                    },
                    "Access-Control-Allow-Methods": {
                        "schema": {
                            "type": "string"
                        }
                    },
                    "Access-Control-Allow-Headers": {
                        "schema": {
                            "type": "string"
                        }
                    }
                },
                "content": {}
            }
        },
        "x-amazon-apigateway-integration": {
            "responses": {
                "default": {
                    "statusCode": "200",
                    "responseParameters": {
                        "method.response.header.Access-Control-Allow-Methods": "'GET,OPTIONS,POST,PUT,DELETE'",
                        "method.response.header.Access-Control-Allow-Headers": "'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,x-access-token'",
                        "method.response.header.Access-Control-Allow-Origin": "'*'"
                    }
                }
            },
            "requestTemplates": {
                "application/json": "{\"statusCode\": 200}"
            },
            "passthroughBehavior": "when_no_match",
            "type": "mock"
        }
    }
 
      if (current_path in path):
        paths[current_path.split(":")[0]]['options'] = options_method_value

      for current_http_method in paths[current_path]:

    # Skipping options method
       if (current_http_method == "options"):
        continue

    # Adding data different to all methods
    # LPR Service Paths
       receiver_name = "${stageVariables.lpr_ref_data_cache_reader}"
       lpr_lambda_arn = "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:"+receiver_name
       lpr_response_template = "#set($inputRoot = $input.path('$'))\n#set($context.responseOverride.status = $inputRoot.get('statusCode'))\n$inputRoot.get('body')"
       lpr_get_request_template = "#set($allParams = $input.params())\r\n{\r\n#set($paramsHeader = $allParams.get('header'))\r\n#set($paramsPath = $allParams.get('path'))\r\n#set($paramQueryString = $allParams.get('querystring'))\r\n\"eventHeader\" : {\r\n    \"xaccessToken\":\"$util.escapeJavaScript($paramsHeader.get('Authorization')).replace('Bearer ','')\",\r\n    \"eventName\":\"$context.httpMethod$context.resourcePath\",\r\n\t\"eventContext\" : {\r\n\t    \"reference_type\" : \""+ path[current_path]['reference_type'] +"\"\r\n\t\t#foreach($paramPathName in $paramsPath.keySet())\r\n\t\t,\"referenceUuid\" : \"$util.escapeJavaScript($paramsPath.get($paramPathName))\"\r\n\t\t#if($foreach.hasNext),#end\r\n\t\t#end\r\n\t\t#foreach($paramQueryStr in $paramQueryString.keySet())\r\n\t\t,\"$paramQueryStr\" : \"$util.escapeJavaScript($paramQueryString.get($paramQueryStr))\"\r\n\t\t#if($foreach.hasNext),#end\r\n\t\t#end\r\n    },\r\n    \"transactionId\" : \"$context.requestId\"\r\n    }\r\n}"
       paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_given_templates_for_generic_reference(lpr_lambda_arn,lpr_get_request_template, lpr_response_template, 202)


       if current_http_method != 'parameters':
          paths[current_path][current_http_method][method_security_key] = method_security_value
          paths[current_path][current_http_method][method_validator_key] = method_validator_value
          default_response_template = "#set($context.responseOverride.status =  202)\n#set($inputRoot = $input.path('$.body'))\n$inputRoot"

       # Making 2 required parameters false and skipping next steps for LPR paths
       if current_http_method == 'parameters':
         paths[current_path][current_http_method][0]['required'] = False
         paths[current_path][current_http_method][2]['required'] = False
         continue

        # Headers Key
       lpr_response_headers_definition_key = "headers"
       lpr_response_headers_key = "responseParameters"
       lpr_request_headers_key = "requestParameters"
       # Headers Value
       lpr_response_headers_definition_value = {
        "Access-Control-Allow-Origin": {
            "schema": {
                "type": "string"
            }
        },
        "Access-Control-Allow-Methods": {
            "schema": {
                "type": "string"
            }
        },
        "Access-Control-Allow-Headers": {
            "schema": {
                "type": "string"
            }
        }
    }
       lpr_response_headers_value = {
        "method.response.header.Access-Control-Allow-Methods": "'GET,OPTIONS,POST,PUT,DELETE'",
        "method.response.header.Access-Control-Allow-Headers": "'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,x-access-token'",
        "method.response.header.Access-Control-Allow-Origin": "'*'"
    }
       lpr_request_headers_value = {
        "integration.request.header.Access-Control-Allow-Origin": "'*'"
    }

       # checking if the method is put or post to assign respective VTL
       paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_given_templates_for_generic_reference(
        lpr_lambda_arn,lpr_get_request_template, lpr_response_template, 200)

    # adding response headers
       lpr_request_headers_value = {
        "integration.request.header.Access-Control-Allow-Origin": "'*'",
    }
       lpr_response_headers_value = {
        "method.response.header.Access-Control-Allow-Methods": "'GET,OPTIONS,POST,PUT,DELETE'",
        "method.response.header.Access-Control-Allow-Headers": "'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,x-access-token'",
        "method.response.header.Access-Control-Allow-Origin": "'*'"
    }

    # adding response headers
       paths[current_path][current_http_method]["responses"]["200"] = paths[current_path][current_http_method]["responses"]["200"]
       paths[current_path][current_http_method]["responses"]["200"][lpr_response_headers_definition_key] = lpr_response_headers_definition_value

    # adding request headers
       paths[current_path][current_http_method][method_integration_key][lpr_request_headers_key] = lpr_request_headers_value
       paths[current_path][current_http_method][method_integration_key]["responses"]["default"][lpr_response_headers_key] = lpr_response_headers_value

    logging.debug("Method Level data is updated successfully")
    return True

def update_swagger(filename):
  try:
      data = get_json_from_file(filename)
  except Exception as e:
    logging.error("Unable to open file for reading: %s (Exiting)",e,exc_info=False)
    return False

  # Keys
  method_security_key = "security"
  method_validator_key = "x-amazon-apigateway-request-validator"
  method_integration_key = "x-amazon-apigateway-integration"
  custom_security_schemes_key = "rest-api-authorizer"
  custom_security_schemes_default_key = "Some_Random_Api_Key"
  validators_definition_key = "x-amazon-apigateway-request-validators"
  # Values
  method_security_value = [ { "rest-api-authorizer": [] } ]
  method_validator_value = "Validate body, query string parameters, and headers"
  mock_integration_value = {
        "responses": {
          "default": {
            "statusCode": "200"
          }
        },
        "requestTemplates": {
          "application/json": "{\"statusCode\": 200}"
        },
        "passthroughBehavior": "when_no_match",
        "type": "mock"
      }
  custom_security_schemes_value = {
      "type": "apiKey",
      "name": "Authorization",
      "in": "header",
      "x-amazon-apigateway-authtype": "custom",
      "x-amazon-apigateway-authorizer": {
          "authorizerUri": "arn:aws:apigateway:${AWS::Region}:lambda:path/2015-03-31/functions/arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:${stageVariables.auth0_lambda_name}/invocations",
          "authorizerResultTtlInSeconds": 0,
          "identityValidationExpression": "^Bearer [-0-9a-zA-z\\.]*$",
          "type": "token"
      }
  }
  custom_security_schemes_value_v2 = {
      "type": "apiKey",
      "name": "x-access-token",
      "in": "header",
      "x-amazon-apigateway-authtype": "custom",
      "x-amazon-apigateway-authorizer": {
          "authorizerUri": "arn:aws:apigateway:${AWS::Region}:lambda:path/2015-03-31/functions/arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:${stageVariables.auth0_lambda_name}/invocations",
          "authorizerResultTtlInSeconds": 0,
          "identityValidationExpression": "^Bearer [-0-9a-zA-z\\.]*$",
          "type": "token"
      }
  }
  validators_definition_value = {
      "Validate body, query string parameters, and headers": {
        "validateRequestParameters": True,
        "validateRequestBody": True
      },
      "Validate query string parameters, and headers": {
        "validateRequestParameters": True,
        "validateRequestBody": False
      },
      "Validate body": {
        "validateRequestParameters": False,
        "validateRequestBody": True
      }
  }

  try:
    update_root_level_data(data, custom_security_schemes_default_key, custom_security_schemes_value, custom_security_schemes_key, validators_definition_value, validators_definition_key, filename)
  except KeyError as e:
    logging.error("Error in Updating Root Level Data: KEY_NOT_FOUND -> %s ",e,exc_info=False)
  try:
    update_method_level_data(custom_security_schemes_value, data, mock_integration_value, method_integration_key, method_security_value, method_security_key, method_validator_value, method_validator_key,filename)
  except KeyError as e:
    logging.error("Error in Updating Method Level Data: KEY_NOT_FOUND -> %s ",e,exc_info=False)
  # Writing updated JSON data to file
  try:
    write_json_to_file(filename, data)
    logging.debug("Swagger File is Successfully updated")
    return True
  except Exception as e:
    logging.error("Some Error in Opening file for writing : %s",e,exc_info=False)

def run_script():
  try:
    swagger_file_name = sys.argv[1]
    update_swagger(swagger_file_name)
  except IndexError as e:
    logging.error("Please provide \"filepath\" as argument in execution command - %s",e,exc_info=False)

run_script()

