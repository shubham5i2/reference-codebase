import json
import logging
import sys
# Logger
logging.basicConfig(level=logging.DEBUG)

path = [
    "/v2/products/{productUuid}",
    "/v2/products"
]

path_with_options = [
    "/v2/products/{productUuid}",
    "/v2/products"
]
stage_variables_dict = {}
stage_variables_dict["products"] = "${stageVariables.lpr_product_read_cache}"


def get_json_from_file(filename):
    with open(filename) as json_file:
        data = json.load(json_file)
    return data


def write_json_to_file(filename, data):
    with open(filename, 'w') as f:
        json.dump(data, f, indent=4)
    return True


def get_integration_value_with_given_templates_for_product(lambda_arn, response_template, response_code):
    return {
        "uri": "arn:aws:apigateway:${AWS::Region}:lambda:path/2015-03-31/functions/" + lambda_arn + "/invocations",
        "responses": {
            "default":
            {
                "statusCode": response_code,
                "responseTemplates": {
                    "application/json": response_template
                }
            },
            ".*.400.*": {
                "statusCode": 400,
                "responseTemplates": {
                    "application/json": "#set ($errorMessageObj = $util.parseJson($input.path('$.errorMessage')))$errorMessageObj.body"
                }
            }
        },
        "passthroughBehavior": "when_no_match",
        "httpMethod": "POST",
        "contentHandling": "CONVERT_TO_TEXT",
        "type": "AWS_PROXY"
    }


def update_root_level_data(data, custom_security_schemes_default_key, custom_security_schemes_value, custom_security_schemes_key, custom_security_schemes_value_v2, custom_security_schemes_key_v2, validators_definition_value, validators_definition_key, filename):
    # Removing default Root level Scheme
    data['components']['securitySchemes'].pop(
        custom_security_schemes_default_key)

    bad_request_value = {"statusCode": "400", "responseType": "BAD_REQUEST_BODY", "responseTemplates": {
        "application/json": "{\n     \"interface\": \"$context.resourcePath\",\n     \"type\":  \"ERROR\",\n     \"errorCode\":  \"400\",\n     \"errorTicketUuid\":  \"$context.requestId\",\n     \"message\":  \"$context.error.validationErrorString\",\n     \"title\": $context.error.messageString\n}"}}
    bad_request_parameter_value = {"statusCode": "400", "responseType": "BAD_REQUEST_PARAMETERS", "responseTemplates": {
        "application/json": "{\n     \"interface\": \"$context.resourcePath\",\n     \"type\":  \"ERROR\",\n     \"errorCode\":  \"400\",\n     \"errorTicketUuid\":  \"$context.requestId\",\n     \"message\":  \"$context.error.validationErrorString\",\n     \"title\": $context.error.messageString\n}"}}
    data['x-amazon-apigateway-gateway-responses']["BAD_REQUEST_BODY"] = bad_request_value
    data['x-amazon-apigateway-gateway-responses']["BAD_REQUEST_PARAMETERS"] = bad_request_parameter_value
    data['components']['securitySchemes'][custom_security_schemes_key] = custom_security_schemes_value
    data['components']['securitySchemes'][custom_security_schemes_key_v2] = custom_security_schemes_value_v2

    data[validators_definition_key] = validators_definition_value
    logging.debug("Root Level data is updated successfully")
    return True


def update_method_level_data(custom_security_schemes_value, data, mock_integration_value, method_integration_key, method_security_value, method_security_key, method_validator_value, method_validator_key, filename):
    # Adding Method level data
    paths = data['paths']
    for current_path in paths:
        # Adding Options method in SM for solving CORS issues
      options_method_value = {
        "responses": {
            "200": {
                "description": "200 response",
                "headers": {
                    "Access-Control-Allow-Origin": {
                        "schema": {
                            "type": "string"
                        }
                    },
                    "Access-Control-Allow-Methods": {
                        "schema": {
                            "type": "string"
                        }
                    },
                    "Access-Control-Allow-Headers": {
                        "schema": {
                            "type": "string"
                        }
                    }
                },
                "content": {}
            }
        },
        "x-amazon-apigateway-integration": {
            "responses": {
                "default": {
                    "statusCode": "200",
                    "responseParameters": {
                        "method.response.header.Access-Control-Allow-Methods": "'GET,OPTIONS,POST,PUT,DELETE'",
                        "method.response.header.Access-Control-Allow-Headers": "'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,correlationId,eventDateTime,x-access-token'",
                        "method.response.header.Access-Control-Allow-Origin": "'*'"
                    }
                }
            },
            "requestTemplates": {
                "application/json": "{\"statusCode\": 200}"
            },
            "passthroughBehavior": "when_no_match",
            "type": "mock"
        }
    }
 
      if (current_path in path_with_options):
       paths[current_path]['options'] = options_method_value

      for current_http_method in paths[current_path]:
 
    # Skipping options method
       if (current_http_method == "options"):
        continue

     # Adding Mock Integration to /healthcheck path and skipping rest of the steps for it
       current_path_array = current_path.split('/')
       micro_service = current_path_array[2]

    # Adding data different to all methods
    # Staff Management Service Paths
       receiver_name = stage_variables_dict.get(micro_service, "")
       sm_lambda_arn = "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:"+receiver_name
       sm_response_template = "#set($inputRoot = $input.path('$'))\n#set($context.responseOverride.status = $inputRoot.get('statusCode'))\n$inputRoot.get('body')"
        
       if current_http_method != 'parameters':
          paths[current_path][current_http_method][method_security_key] = method_security_value
          paths[current_path][current_http_method][method_validator_key] = method_validator_value
          default_response_template = "#set($context.responseOverride.status =  202)\n#set($inputRoot = $input.path('$.body'))\n$inputRoot"

       # Making 2 required parameters false and skipping next steps for SM paths
       if current_http_method == 'parameters':
         paths[current_path][current_http_method][0]['required'] = False
         paths[current_path][current_http_method][2]['required'] = False
         continue

        # Headers Key
       sm_response_headers_definition_key = "headers"
       sm_response_headers_key = "responseParameters"
       sm_request_headers_key = "requestParameters"
       # Headers Value
       sm_response_headers_definition_value = {
        "Access-Control-Allow-Origin": {
            "schema": {
                "type": "string"
            }
        },
        "Access-Control-Allow-Methods": {
            "schema": {
                "type": "string"
            }
        },
        "Access-Control-Allow-Headers": {
            "schema": {
                "type": "string"
            }
        }
    }
       sm_response_headers_value = {
        "method.response.header.Access-Control-Allow-Methods": "'GET,OPTIONS,POST,PUT,DELETE'",
        "method.response.header.Access-Control-Allow-Headers": "'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,correlationId,eventDateTime,x-access-token'",
        "method.response.header.Access-Control-Allow-Origin": "'*'"
    }
       sm_request_headers_value = {
        "integration.request.header.eventDateTime": "method.request.header.eventDateTime",
        "integration.request.header.Access-Control-Allow-Origin": "'*'",
        "integration.request.header.correlationId": "method.request.header.correlationId",
    }

       # checking if the method is put or post to assign respective VTL
       paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_given_templates_for_product(
        sm_lambda_arn, sm_response_template, 200)

    # adding response headers
       sm_request_headers_value = {
        "integration.request.header.eventDateTime": "method.request.header.eventDateTime",
        "integration.request.header.Access-Control-Allow-Origin": "'*'",
        "integration.request.header.correlationId": "method.request.header.correlationId"
    }
       sm_response_headers_value = {
        "method.response.header.Access-Control-Allow-Methods": "'GET,OPTIONS,POST,PUT,DELETE'",
        "method.response.header.Access-Control-Allow-Headers": "'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,correlationId,eventDateTime,x-access-token'",
        "method.response.header.Access-Control-Allow-Origin": "'*'"
    }

    # adding response headers
       paths[current_path][current_http_method]["responses"]["200"] = paths[current_path][current_http_method]["responses"]["200"]
       paths[current_path][current_http_method]["responses"]["200"][sm_response_headers_definition_key] = sm_response_headers_definition_value

    # adding request headers
       paths[current_path][current_http_method][method_integration_key][sm_request_headers_key] = sm_request_headers_value
       paths[current_path][current_http_method][method_integration_key]["responses"]["default"][sm_response_headers_key] = sm_response_headers_value

    logging.debug("Method Level data is updated successfully")
    return True

def update_swagger(filename):
  try:
      data = get_json_from_file(filename)
  except Exception as e:
    logging.error("Unable to open file for reading: %s (Exiting)",e,exc_info=False)
    return False

  # Keys
  method_security_key = "security"
  method_validator_key = "x-amazon-apigateway-request-validator"
  method_integration_key = "x-amazon-apigateway-integration"
  custom_security_schemes_key = "rest-api-authorizer"
  custom_security_schemes_key_v2 = "rest-api-authorizer-v2"
  custom_security_schemes_default_key = "Some_Random_Api_Key"
  validators_definition_key = "x-amazon-apigateway-request-validators"
  # Values
  method_security_value = [ { "rest-api-authorizer": [] } ]
  method_validator_value = "Validate body, query string parameters, and headers"
  mock_integration_value = {
        "responses": {
          "default": {
            "statusCode": "200"
          }
        },
        "requestTemplates": {
          "application/json": "{\"statusCode\": 200}"
        },
        "passthroughBehavior": "when_no_match",
        "type": "mock"
      }
  custom_security_schemes_value = {
      "type": "apiKey",
      "name": "Authorization",
      "in": "header",
      "x-amazon-apigateway-authtype": "custom",
      "x-amazon-apigateway-authorizer": {
          "authorizerUri": "arn:aws:apigateway:${AWS::Region}:lambda:path/2015-03-31/functions/arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:${stageVariables.auth0_lambda_name}/invocations",
          "authorizerResultTtlInSeconds": 0,
          "identityValidationExpression": "^Bearer [-0-9a-zA-z\\.]*$",
          "type": "token"
      }
  }
  custom_security_schemes_value_v2 = {
      "type": "apiKey",
      "name": "x-access-token",
      "in": "header",
      "x-amazon-apigateway-authtype": "custom",
      "x-amazon-apigateway-authorizer": {
          "authorizerUri": "arn:aws:apigateway:${AWS::Region}:lambda:path/2015-03-31/functions/arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:${stageVariables.auth0_lambda_name}/invocations",
          "authorizerResultTtlInSeconds": 0,
          "identityValidationExpression": "^Bearer [-0-9a-zA-z\\.]*$",
          "type": "token"
      }
  }
  validators_definition_value = {
      "Validate body, query string parameters, and headers": {
        "validateRequestParameters": True,
        "validateRequestBody": True
      },
      "Validate query string parameters, and headers": {
        "validateRequestParameters": True,
        "validateRequestBody": False
      },
      "Validate body": {
        "validateRequestParameters": False,
        "validateRequestBody": True
      }
  }

  try:
    update_root_level_data(data, custom_security_schemes_default_key, custom_security_schemes_value, custom_security_schemes_key, custom_security_schemes_value_v2, custom_security_schemes_key_v2, validators_definition_value, validators_definition_key, filename)
  except KeyError as e:
    logging.error("Error in Updating Root Level Data: KEY_NOT_FOUND -> %s ",e,exc_info=False)
  try:
    update_method_level_data(custom_security_schemes_value, data, mock_integration_value, method_integration_key, method_security_value, method_security_key, method_validator_value, method_validator_key,filename)
  except KeyError as e:
    logging.error("Error in Updating Method Level Data: KEY_NOT_FOUND -> %s ",e,exc_info=False)
  # Writing updated JSON data to file
  try:
    write_json_to_file(filename, data)
    logging.debug("Swagger File is Successfully updated")
    return True
  except Exception as e:
    logging.error("Some Error in Opening file for writing : %s",e,exc_info=False)

def run_script():
  try:
    swagger_file_name = sys.argv[1]
    update_swagger(swagger_file_name)
  except IndexError as e:
    logging.error("Please provide \"filepath\" as argument in execution command - %s",e,exc_info=False)

run_script()

