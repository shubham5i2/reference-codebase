### [3.43.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.43.1...v3.43.2) (2024-05-06)


### ⚠ BREAKING CHANGES

* reasonUuid changes

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!473

* Merge branch 'feature/IMOD-60595_ban_swagger' into 'develop' ([d9b81c9](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/d9b81c948c113832ae78cefbe1fdedf4e57ccd75))

### [3.43.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.43.0...v3.43.1) (2024-05-03)


### ⚠ BREAKING CHANGES

* IMOD-60595 ban swagger changes

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!472

* Merge branch 'feature/IMOD-60595_ban_swagger_changes' into 'develop' ([27b5ac5](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/27b5ac532e2282988965d1119668edce1567e6cf))

## [3.43.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.42.3...v3.43.0) (2024-04-22)

### [3.42.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.42.2...v3.42.3) (2024-04-12)

### [3.42.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.42.1...v3.42.2) (2024-04-10)


### ⚠ BREAKING CHANGES

* Feature/imod-59256-ac-gt-products

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!455

* Merge branch 'feature/IMOD-59256_AC_GT_Products' into 'develop' ([794ddd3](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/794ddd316e227e7bdf77b1ead338390145fc7867))

### [3.42.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.42.0...v3.42.1) (2024-04-10)

## [3.42.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.41.1...v3.42.0) (2024-04-09)

### [3.41.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.41.0...v3.41.1) (2024-03-21)


### ⚠ BREAKING CHANGES

* dummy changes to trigger pipeline

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!451
* reference data api gateway pipeline issue fixed

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!450

* Merge branch 'feature/reference-data-ag-dummy-changes' into 'develop' ([095e7b9](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/095e7b93e36e81d529547edb172244ee66cac766))
* Merge branch 'feature/reference-data-pipeline-fix' into 'develop' ([83f653c](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/83f653c06d88088e23484be59133aa89241c8a1a))

## [3.41.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.40.0...v3.41.0) (2024-03-21)


### ⚠ BREAKING CHANGES

* IMOD-53679-API-gateway-changes-for-generic-reference-reader-lambda

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!448

* Merge branch 'feature/IMOD-53679-APIGatewayChanges-for-reference-data-reader-lambda' into 'develop' ([ebc9732](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/ebc9732f6a365ffbf1ea96619631e9eb45f53a5e))

## [3.40.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.39.0...v3.40.0) (2024-03-21)

## [3.39.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.38.1...v3.39.0) (2024-03-05)

### [3.38.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.38.0...v3.38.1) (2023-12-12)

## [3.38.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.37.1...v3.38.0) (2023-12-12)


### ⚠ BREAKING CHANGES

* product swagger json added with new preprocessor script

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!443

* Merge branch 'feature/IMOD-54506_create_preprocessor_for_product' into 'develop' ([ba0adaf](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/ba0adaf3cf5195cec43b2018cf46828dd1140657))

### [3.37.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.37.0...v3.37.1) (2023-12-12)

## [3.37.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.36.3...v3.37.0) (2023-11-07)

### [3.36.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.36.2...v3.36.3) (2023-11-07)


### ⚠ BREAKING CHANGES

* Feature/incredibles stable changes

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!442

* Merge branch 'feature/Incredibles-stable-changes' into 'develop' ([061d6af](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/061d6afd09b5859efb9eda4ed5c3c49914b592f1))

### [3.36.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.36.1...v3.36.2) (2023-10-30)

### [3.36.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.36.0...v3.36.1) (2023-10-09)


### ⚠ BREAKING CHANGES

* Feature/IMOD-47804-activate-deactivate-products

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!439

* Merge branch 'feature/IMOD-47804-activate-deactivate-products' into 'develop' ([c7b484a](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/c7b484a493c0d5bd1c91c8ded0cda6053c1f96f3))

## [3.36.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.35.1...v3.36.0) (2023-09-19)

### [3.35.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.35.0...v3.35.1) (2023-08-16)

## [3.35.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.34.0...v3.35.0) (2023-08-11)

## [3.34.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.33.0...v3.34.0) (2023-08-10)


### Features

* <h2>Bugfix</h2><h3>IMOD-49695 fix</h3><p><strong>Purpose:</strong><br />Incident Details page in IncidentManagement Screen not working in UI</p><br /></p> ([31736cd](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/31736cd181da5611082ad79e447b9b56a7183137))

## [3.33.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.32.0...v3.33.0) (2023-08-08)

## [3.32.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.31.2...v3.32.0) (2023-08-04)

### [3.31.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.31.1...v3.31.2) (2023-07-28)


### ⚠ BREAKING CHANGES

* postal code validation

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!420

* Merge branch 'feature/postalCode-length' into 'develop' ([1006fe2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/1006fe2aeedcd4485278b83daa54e469f0648e4d))

### [3.31.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.31.0...v3.31.1) (2023-07-27)

## [3.31.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.30.1...v3.31.0) (2023-07-19)

### [3.30.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.30.0...v3.30.1) (2023-07-17)


### ⚠ BREAKING CHANGES

* IMOD-45912 Event serialization swagger changes for SM, LPR and RO receiver lambda

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!400

* Merge branch 'feature/SM-UI-SWAGGER-CHANGES-45912' into 'develop' ([0718faa](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/0718faa7e9883b41030e6bec12c31d40d590bd3f))

## [3.30.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.29.1...v3.30.0) (2023-07-03)

### [3.29.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.29.0...v3.29.1) (2023-06-27)

## [3.29.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.28.18...v3.29.0) (2023-06-20)


### ⚠ BREAKING CHANGES

* Created structure for adding event serialization endpoints

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!403

* Merge branch 'feature/IMOD-40657-Event_Serialization_Structure' into 'develop' ([3806140](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/38061408c6919f00fbb162ff9edb92699885f3c0))

### [3.28.18](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.28.17...v3.28.18) (2023-05-23)


### ⚠ BREAKING CHANGES

* Replaced CI_BUILD_TAG to CI_COMMIT_TAG

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!396

* Merge branch 'feature/update_gitlab_variable' into 'develop' ([91eea2b](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/91eea2b33299a1556c808259c8cc781280629704))

### [3.28.17](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.28.16...v3.28.17) (2023-04-11)

### [3.28.16](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.28.15...v3.28.16) (2023-04-06)


### ⚠ BREAKING CHANGES

* Add external swagger client generator

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!393

* Merge branch 'feature/generate-jar-from-json' into 'develop' ([f741cf8](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/f741cf899e625020ca92f00ac3fed236da2313d9))

### [3.28.15](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.28.14...v3.28.15) (2023-04-06)


### ⚠ BREAKING CHANGES

* adding cod for generating jar file from the Json files

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!392

* Merge branch 'feature/jar-generator' into 'develop' ([333f69b](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/333f69b15c6390687bc2fc64cf5696829e52ce97))

### [3.28.14](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.28.13...v3.28.14) (2023-04-06)


### ⚠ BREAKING CHANGES

* updated dashboard changes

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!391

* Merge branch 'feature/dashboard' into 'develop' ([3651238](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/36512388e22b0ef8cd674176a149e72fda9e5bab))

### [3.28.13](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.28.12...v3.28.13) (2023-04-06)


### ⚠ BREAKING CHANGES

* updated dashboard changes and docker runner image

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!390

* Merge branch 'feature/dashboard_changes' into 'develop' ([2b8db95](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/2b8db9549cfadc019fea4853a70e5f55844d7061))

### [3.28.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.28.11...v3.28.12) (2023-03-30)

### [3.28.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.28.10...v3.28.11) (2023-03-14)


### ⚠ BREAKING CHANGES

* Pact integration changes for dev and sit

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!382

* Merge branch 'feature/imod-pact-integration-dev-sit' into 'develop' ([0f670d1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/0f670d1cc1611c0255e9eb480b6c90e458759fca))

### [3.28.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.28.9...v3.28.10) (2023-03-13)

### [3.28.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.28.8...v3.28.9) (2023-02-28)

### [3.28.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.28.7...v3.28.8) (2023-02-20)


### ⚠ BREAKING CHANGES

* Feature/incredibles sprint 10 6

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!377

* Merge branch 'feature/Incredibles-Sprint-10-6' into 'develop' ([3d308bc](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/3d308bca724e09a31f16e53c0b4c4be6f1be68ba))

### [3.28.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.28.6...v3.28.7) (2023-02-14)


### ⚠ BREAKING CHANGES

* removed tactical-ui changes

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!376

* Merge branch 'feature/IMOD-42151' into 'develop' ([fe07650](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/fe07650a30c21611a3b684bdf2277d31021b4f29))

### [3.28.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.28.5...v3.28.6) (2023-01-25)


### ⚠ BREAKING CHANGES

* enable staging environment

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!371

* Merge branch 'feature/staging-env-changes' into 'develop' ([2c6823a](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/2c6823abda3b98b014c80b72e6919aaa10ab639e))

### [3.28.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.28.4...v3.28.5) (2023-01-25)

### [3.28.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.28.3...v3.28.4) (2023-01-25)


### ⚠ BREAKING CHANGES

* feature/IMOD-36242

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!369

* Merge branch 'feature/IMOD-36242' into 'develop' ([f0fff74](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/f0fff749e1f905f6da25b0253a697bcd9a6a62bb))

### [3.28.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.28.2...v3.28.3) (2023-01-20)


### ⚠ BREAKING CHANGES

* feature/IMOD-39509

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!368
* feature/IMOD-30322

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!367

* Merge branch 'feature/IMOD-39509' into 'develop' ([aa606db](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/aa606db402a6030d83a14a6bdd71e22de634de73))
* Merge branch 'feature/mmds_final' into 'develop' ([1ddc0ba](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/1ddc0ba3fb7ab959e8e9550462f43acb99dafe1b))

### [3.28.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.28.1...v3.28.2) (2023-01-13)

### [3.28.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.28.0...v3.28.1) (2022-12-21)

## [3.28.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.27.1...v3.28.0) (2022-12-06)

### [3.27.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.27.0...v3.27.1) (2022-11-16)


### ⚠ BREAKING CHANGES

* Minor change to create version

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!359
* feature/IMOD_38013_external_end_point_change_for_location

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!357

* Merge branch 'feature/IMOD_38013_external_end_point_change_for_location' into 'develop' ([137dc50](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/137dc50661418b1a6fd338a602c751d3f07b156a))
* Merge branch 'feature/IMOD-38013-patch-version' into 'develop' ([45487fb](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/45487fbb28b255b2ad0753d8c68ba44c6414f2e9))

## [3.27.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.26.9...v3.27.0) (2022-11-09)

### [3.26.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.26.8...v3.26.9) (2022-10-27)


### ⚠ BREAKING CHANGES

* changes in agentnname swagger validation

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!355

* Merge branch 'feature/agentname-min-lengthchange' into 'develop' ([a132ffc](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/a132ffc28a1a43998a01284070e95ab3089eb500))

### [3.26.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.26.7...v3.26.8) (2022-10-26)


### ⚠ BREAKING CHANGES

* v2 swagger changes

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!354

* Merge branch 'feature/v2-swagger-changes' into 'develop' ([4a7f55e](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/4a7f55e818e87572c336e5d616b6642fb516a9ba))

### [3.26.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.26.6...v3.26.7) (2022-10-21)


### ⚠ BREAKING CHANGES

* Feature/test swagger

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!353

* Merge branch 'feature/test-swagger' into 'develop' ([37271d2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/37271d24c274e9fa888044e67889176126655884))

### [3.26.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.26.5...v3.26.6) (2022-10-21)


### ⚠ BREAKING CHANGES

* Feature/dummy changes

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!352

* Merge branch 'feature/dummy-changes' into 'develop' ([50a810c](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/50a810ccd590fc6a3d971c79c76a45bcdd504119))

### [3.26.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.26.4...v3.26.5) (2022-10-20)


### ⚠ BREAKING CHANGES

* pact pipeline issue

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!351

* Merge branch 'feature/pact-pipeline-issue' into 'develop' ([eb410ce](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/eb410ce571d6188f8d250f4f6ab0a92e1f47bde4))

### [3.26.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.26.3...v3.26.4) (2022-10-20)


### ⚠ BREAKING CHANGES

* IMOD-37113

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!350

* Merge branch 'feature/dummy_changes' into 'develop' ([bf2d1de](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/bf2d1de715c780fad0b63092382e1fae96f6304c))

### [3.26.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.26.2...v3.26.3) (2022-10-17)


### ⚠ BREAKING CHANGES

* IMOD-21542 voided changes

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!345

* Merge branch 'feature/IMOD-21542_BookingVoided' into 'develop' ([9a74a93](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/9a74a9382bd174c859a4be0f6a155b659580c0f3))

### [3.26.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.26.1...v3.26.2) (2022-10-10)

### [3.26.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.26.0...v3.26.1) (2022-09-23)


### ⚠ BREAKING CHANGES

* Feature/swagger changes for speakingincident

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!342

* Merge branch 'feature/swagger_changes_for_speakingincident' into 'develop' ([762ad04](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/762ad0471e65a09da0cd770768e3e48eab2115b6))

## [3.26.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.25.1...v3.26.0) (2022-09-21)

### [3.25.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.25.0...v3.25.1) (2022-09-19)


### ⚠ BREAKING CHANGES

* bookings-links and exempt removal

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!340

* Merge branch 'feature/linked_bookings_fix' into 'develop' ([dc2258a](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/dc2258aaac1c1c0becc3b6a67bdce2d3781d306f))

## [3.25.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.24.0...v3.25.0) (2022-09-16)

## [3.24.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.23.0...v3.24.0) (2022-09-15)

## [3.23.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.22.0...v3.23.0) (2022-09-01)

## [3.22.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.21.1...v3.22.0) (2022-08-26)

### [3.21.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.21.0...v3.21.1) (2022-08-22)


### ⚠ BREAKING CHANGES

* Feature/imod 33003 photo category

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!333

* Merge branch 'feature/IMOD-33003-Photo-category' into 'develop' ([0e27995](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/0e2799512e39712fdeee2f42dedea497020900ce))

## [3.21.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.20.0...v3.21.0) (2022-08-19)

## [3.20.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.19.2...v3.20.0) (2022-08-18)

### [3.19.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.19.1...v3.19.2) (2022-08-12)


### ⚠ BREAKING CHANGES

* Feature/imod 16548 15702 edit and update id verification status

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!326

* Merge branch 'feature/IMOD-16548_15702_edit_and_update_id_verification_status' into 'develop' ([81a7b32](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/81a7b3211838511a27a982e9357c20cd23617a44))

### [3.19.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.19.0...v3.19.1) (2022-08-09)

## [3.19.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.18.2...v3.19.0) (2022-08-08)

### [3.18.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.18.1...v3.18.2) (2022-07-29)


### ⚠ BREAKING CHANGES

* Feature/ors speaking incident changes

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!321

* Merge branch 'feature/ors-speaking-incident-changes' into 'develop' ([60b314d](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/60b314d6b2b0bdfb3edb553f58b86210161b3c7a))

### [3.18.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.18.0...v3.18.1) (2022-07-28)


### ⚠ BREAKING CHANGES

* preprocessor script to point to ORS-ext-receiver lambda

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!323

* Merge branch 'feature/IMOD-30663' into 'develop' ([623a95f](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/623a95ff8dc5c0c4e6d400fef54483011a4b541b))

## [3.18.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.17.3...v3.18.0) (2022-07-22)


### ⚠ BREAKING CHANGES

* Feature IMOD-31993 add new resource to api-gw

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!320

* Merge branch 'feature/IMOD-31993_API_gateway_for_multiple_result_status_update' into 'develop' ([32a5bf6](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/32a5bf6eace241c51d1970dc7c0ff4896873e638))

### [3.17.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.17.2...v3.17.3) (2022-07-20)


### ⚠ BREAKING CHANGES

* Fix errors in websocket response json

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!319

* Merge branch 'feature/add-missing-websocket-response-resultv2' into 'develop' ([c17ca90](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/c17ca901ee456cb365543b7d40c22d80a5edfc1a))

### [3.17.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.17.1...v3.17.2) (2022-07-19)


### ⚠ BREAKING CHANGES

* ors event changes

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!317

* Merge branch 'feature/Ors-model-change' into 'develop' ([2f074dc](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/2f074dc1048079c29c916827e2697b894ea793d1))

### [3.17.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.17.0...v3.17.1) (2022-07-19)

## [3.17.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.16.3...v3.17.0) (2022-07-13)


### ⚠ BREAKING CHANGES

* on hold search criteria added to booking search 

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!314

* Merge branch 'feature/on-hold-search-criteria' into 'develop' ([464b52a](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/464b52aafaa4e1e040bc5c5986a1a86ff0c89a74))

### [3.16.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.16.2...v3.16.3) (2022-07-12)


### ⚠ BREAKING CHANGES

* Feature/imod 31153 incident search and view changes

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!311

* Merge branch 'feature/IMOD-31153_incident_search_and_view_changes' into 'develop' ([ab76763](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/ab7676339ec6acc1b6e4219dcda54a0a6b730359))

### [3.16.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.16.1...v3.16.2) (2022-07-07)


### ⚠ BREAKING CHANGES

* Feature/incredibles sprint 9 1

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!313
* Feature/incredibles sprint 9 1

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!312

* Merge branch 'feature/Incredibles-Sprint-9-1' into 'develop' ([ac0e258](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/ac0e25800c7bf4a31bccc78b4bb17bc31ef5c0ee))
* Merge branch 'feature/Incredibles-Sprint-9-1' into 'develop' ([0134589](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/01345896ebcf830b7905233d24252e28490fc8b0))

### [3.16.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.16.0...v3.16.1) (2022-07-04)

## [3.16.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.15.4...v3.16.0) (2022-06-23)

### [3.15.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.15.3...v3.15.4) (2022-06-22)


### ⚠ BREAKING CHANGES

* Feature/imod 21458 regression stats

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!299

* Merge branch 'feature/IMOD-21458_Regression_Stats' into 'develop' ([c8c2d9a](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/c8c2d9a742a5c43924e5cd7e9418b0314ed0ae2b))

### [3.15.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.15.2...v3.15.3) (2022-06-22)


### ⚠ BREAKING CHANGES

* updated swagger changes for ban feature - removed bannedPeriodUuid as field in...

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!305

* Merge branch 'feature/Incredibles_Ban_changes' into 'develop' ([5b1b798](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/5b1b79898b6182203f67020cf8d0c6a08cebbcec))

### [3.15.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.15.1...v3.15.2) (2022-05-24)

### [3.15.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.15.0...v3.15.1) (2022-05-18)

## [3.15.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.14.3...v3.15.0) (2022-05-16)

### [3.14.4-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.14.3...v3.14.4-hotfix.1) (2022-05-13)

### [3.14.3-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.14.2...v3.14.3-hotfix.1) (2022-05-13)

### [3.14.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.14.2...v3.14.3) (2022-05-11)

### Features

* Change to public runner in swagger web ui ([135a18a](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/135a18a680bd12e1a037dfe7420dfc832d5189bd))
* Change to public runner in swagger web ui ([d847cc2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/d847cc23b73ae0b43a306a0fb1accf2435840fc6))
* Feature/enable private runners ([6860d92](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/6860d92909fccd93c750b3098dce47b129d21370))
* Feature/enable private runners ([ce3b045](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/ce3b045eb0e4edad559c423285c1a39af58f30bc))

### [3.14.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.14.1...v3.14.2) (2022-04-28)


### ⚠ BREAKING CHANGES

* Updating image version

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!283
* changes in image version

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!282

### Bug Fixes

* ssm param existence validation ([859c036](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/859c036803c00492538be643f8f8300d19a53cf1))


* Merge branch 'feature/Imod-updateing-image-version' into 'develop' ([eb4b04c](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/eb4b04cb2316e9265265b7c3926637898fac30ac))
* Merge branch 'feature/IMOD-updating-image-version' into 'develop' ([8900e61](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/8900e611344b3f8e152bbcfac0aff2e5164292a9))

### [3.14.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.14.0...v3.14.1) (2022-04-27)


### ⚠ BREAKING CHANGES

* feature/IMOD-21179_identify_child

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!279

* Merge branch 'feature/IMOD-21179_identify_child' into 'develop' ([b1ce03b](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/b1ce03b85b217cf5d41e5cda84b7732807e28b5c))

## [3.14.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.13.3...v3.14.0) (2022-04-26)


### ⚠ BREAKING CHANGES

* Incident managment Api Gateway

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!272

* Merge branch 'feature/IMOD-25128_ID_Verification' into 'develop' ([23c0bb8](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/23c0bb881656b1be6624e1d50b05401dc39c177c))

### [3.13.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.13.2...v3.13.3) (2022-04-21)


### ⚠ BREAKING CHANGES

* removing fields in voidoutcome

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!276

* Merge branch 'feature/28870-void-fields-change' into 'develop' ([908e582](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/908e58205c2f6ab2e40f312b175aee5eb2b8be80))

### [3.13.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.13.1...v3.13.2) (2022-04-21)

### [3.13.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.13.0...v3.13.1) (2022-04-19)

## [3.13.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.12.5...v3.13.0) (2022-04-11)


### ⚠ BREAKING CHANGES

* added new v2 endpoint for view result details page

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!270

* Merge branch 'feature/Add-v2-Endpoint-For-RM-View-Details' into 'develop' ([5720f54](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/5720f545ae1c14a1850c7c81f2b3e295b358b2d5))

### [3.12.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.12.4...v3.12.5) (2022-04-08)


### ⚠ BREAKING CHANGES

* trf download for ui swagger

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!269

* Merge branch 'feature/imod-8270-etrf-uidesign' into 'develop' ([bb3020c](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/bb3020cd1ae389c17d4b21bc8354e69a59120604))

### [3.12.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.12.3...v3.12.4) (2022-04-07)


### ⚠ BREAKING CHANGES

* Feature/incredibles sprint 8 1

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!268

* Merge branch 'feature/Incredibles-Sprint-8-1' into 'develop' ([01dc424](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/01dc4245628f780e534c937f063ad7ad37e01dcf))

### [3.12.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.12.2...v3.12.3) (2022-04-07)


### ⚠ BREAKING CHANGES

* Feature/imod-27922_result_available_for_years

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!267

* Merge branch 'feature/IMOD-27922_result_available_for_years' into 'develop' ([76e8b2f](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/76e8b2f1016fbfaac46ef73c6c0de740b31a91ce))

### [3.12.1-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.12.1-hotfix.1...v3.12.1-hotfix.2) (2022-04-01)

### [3.12.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.12.0...v3.12.1-hotfix.1) (2022-04-01)
### [3.12.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.12.1...v3.12.2) (2022-04-01)

### [3.12.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.12.0...v3.12.1) (2022-04-01)

## [3.12.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.11.2...v3.12.0) (2022-03-31)

### [3.11.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.11.1...v3.11.2) (2022-03-31)


### ⚠ BREAKING CHANGES

* Added ors_speaking_incident_event stage variable in ielts-cmds-sandbox-api-external-rest in api-gateway

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!255
* Update swagger-apigw-external-ci.yml

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!254

* Merge branch 'feature/IMOD-28093' into 'develop' ([0c38b5f](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/0c38b5f8075fa7657466b38918d75711c0472648))
* Merge branch 'feature/IMOD-28093' into 'develop' ([35d190f](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/35d190f53017167f5ebac91d6d96d6a3c441a5f1))

### [3.11.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.11.0...v3.11.1) (2022-03-25)


### ⚠ BREAKING CHANGES

* Update swagger-ui-apiw stage variables

See merge request ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger!250

* Merge branch 'feature/IMOD-27776-ui' into 'develop' ([e9565c6](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/commit/e9565c6ac8101a66bc51eea3c90c08d892714c14))

## [3.11.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.10.0...v3.11.0) (2022-03-24)

## [3.10.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.9.2...v3.10.0) (2022-03-22)

### [3.9.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.9.1...v3.9.2) (2022-03-11)

### [3.9.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.9.0...v3.9.1) (2022-03-09)

## [3.9.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.8.3...v3.9.0) (2022-02-24)

### [3.8.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.8.2...v3.8.3) (2022-02-24)

### [3.8.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.8.1...v3.8.2) (2022-02-23)

### [3.8.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.8.0...v3.8.1) (2022-02-18)

## [3.8.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.7.1...v3.8.0) (2022-02-10)

### [3.7.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.7.0...v3.7.1) (2022-02-07)

## [3.7.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.6.9...v3.7.0) (2022-01-27)

### [3.6.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.6.8...v3.6.9) (2022-01-24)

### [3.6.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.6.7...v3.6.8) (2022-01-24)

### [3.6.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.6.6...v3.6.7) (2022-01-18)

### [3.6.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.6.5...v3.6.6) (2022-01-11)

### [3.6.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.6.4...v3.6.5) (2022-01-10)

### [3.6.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.6.3...v3.6.4) (2021-11-22)

### [3.6.1-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.6.1-hotfix.1...v3.6.1-hotfix.2) (2021-11-22)

### [3.6.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.6.0...v3.6.1-hotfix.1) (2021-11-19)


### Bug Fixes

### [3.6.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.6.2...v3.6.3) (2021-11-19)

### [3.6.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.6.1...v3.6.2) (2021-11-18)

### [3.6.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.6.0...v3.6.1) (2021-11-15)

## [3.6.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.5.2...v3.6.0) (2021-11-10)

### [3.5.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.5.1...v3.5.2) (2021-11-09)

### [3.5.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.5.0...v3.5.1) (2021-11-09)

## [3.5.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.4.1...v3.5.0) (2021-11-05)

### [3.4.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.4.0...v3.4.1) (2021-11-02)

## [3.4.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.3.1...v3.4.0) (2021-11-02)

### [3.3.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.3.0...v3.3.1-hotfix.1) (2021-11-03)

### [3.3.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.3.0...v3.3.1) (2021-10-28)

## [3.3.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.2.1...v3.3.0) (2021-10-27)

### [3.2.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.2.0...v3.2.1) (2021-10-26)

## [3.2.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.1.0...v3.2.0) (2021-10-25)

## [3.1.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.0.2...v3.1.0) (2021-10-21)

### [3.0.3-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.0.2...v3.0.3-hotfix.1) (2021-10-19)

### [3.0.2-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.0.1...v3.0.2-hotfix.1) (2021-10-12)

### [3.0.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.0.1...v3.0.2) (2021-10-18)


### [3.0.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v3.0.0...v3.0.1) (2021-10-11)

## [3.0.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v2.1.0...v3.0.0) (2021-09-23)

## [2.1.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v2.0.1...v2.1.0) (2021-09-14)

### [2.0.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v2.0.0...v2.0.1) (2021-08-21)

## [2.0.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v1.5.2...v2.0.0) (2021-08-13)

### [1.5.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v1.5.1...v1.5.2) (2021-08-09)

### [1.5.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v1.5.0...v1.5.1) (2021-08-03)

## [1.5.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v1.4.0...v1.5.0) (2021-07-30)

## [1.4.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v1.3.0...v1.4.0) (2021-07-28)

## [1.3.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v1.2.1...v1.3.0) (2021-07-28)

### [1.2.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v1.2.0...v1.2.1) (2021-07-21)

## [1.2.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v1.1.0...v1.2.0) (2021-07-19)

## [1.1.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v1.0.3...v1.1.0) (2021-07-16)

### [1.0.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v1.0.2...v1.0.3) (2021-07-14)

### [1.0.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v1.0.1...v1.0.2) (2021-07-08)

### [1.0.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-interfaces-grp/cmds-ui-swagger/compare/v1.0.0...v1.0.1) (2021-07-08)

## 1.0.0 (2021-07-07)
