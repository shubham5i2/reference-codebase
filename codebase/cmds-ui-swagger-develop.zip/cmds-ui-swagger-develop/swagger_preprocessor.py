import json
import logging
import sys
#Logger
logging.basicConfig(level=logging.DEBUG)

inspera_path={
  "/v1/testdaymaterialapproved": {"xinsperaSignature":True,"eventName":"ContentApprovedNotificationReceived"},
  "/v1/testdaymaterialready": {"xinsperaSignature":True,"eventName":"ContentExportReadyNotificationReceived"},
  "/v1/testtakerphotosavailable": {"xinsperaSignature":True,"eventName":"TTPhotosCapturedNotificationReceived"},
  "/v1/jaggedanalysiscomplete": {"xinsperaSignature":True,"eventName":"JaggedStatusSetNotificationReceived"},
  "/v1/candidateIdVerified": {"xinsperaSignature":True,"eventName":"IDCheckVerificationNotificationReceived"},
  "/v1/candidateIdRejected": {"xinsperaSignature":True,"eventName":"IDCheckRejectedNotificationReceived"},
  "/v1/candidateIdRequiresFollowUp": {"xinsperaSignature":True,"eventName":"IDCheckRequiresFollowUpNotificationReceived"},
  "/v1/candidateFlagAdded": {"xinsperaSignature":True,"eventName":"CandidateFlagAddedNotificationReceived"},
  "/v1/incidentReportAddedToLoggedEvent": {"xinsperaSignature":True,"eventName":"IncidentReportAddedToLoggedEventNotificationReceived"},
  "/v1/filesAttachedToLoggedEvent": {"xinsperaSignature":True,"eventName":"FilesAttachedToLoggedEventNotificationReceived"},
  "/v1/testtakersubmissiondelivered": {"xinsperaSignature":True,"eventName":"SubmissionDeliveredNotificationReceived"},
  "/v1/testtakersubmissionexportfinished": {"xinsperaSignature":True,"eventName":"SubmissionExportReadyNotificationReceived"},
  "/v1/compositefinalgradesetevent": {"xinsperaSignature":True,"eventName":"composite_final_grade_set"},
  "/v1/marksandgradesbyroundexportfinished": {"xinsperaSignature":True,"eventName":"marks_and_grades_by_round_export_finished"},
  "/v1/testtakerhistoryrequest": {"xinsperaSignature":False,"eventName":"/v1/testtakerhistoryrequest"},
  "/v1/prcrecommendation": {"xinsperaSignature":False,"eventName":"/v1/prcrecommendation"}
}

path = [
  "/healthcheck",
  "/v1/users",
  "/v1/usergroups",
  "/v1/users/search",
  "/v1/users/{userUuid}",
  "/v1/users/{userUuid}/usergroups",
  "/v1/users/locations",
  "/v1/booking",
  "/v1/booking/{bookingId}",
  "/v1/bookingline/{bookingLineId}",
  "/v1/uploadlocation",
  "/v1/notetypes",
  "/v1/partners",
  "/v1/sectortypes",
  "/v1/organisationtypes",
  "/v1/moduletypes",
  "/v1/contacttypes",
  "/v1/addresstypes",
  "/v1/countries",
  "/v1/countries/{countryCode}/territories",
  "/v1/testtakerhistoryrequest",
  "/v1/prcrecommendation",
  "/v1/ros/search",
  "/v1/ros",
  "/v1/ros/{recognisingOrganisationUuid}",
  "/v1/cdmarksavailable",
  "/v1/booking/{externalBookingUuid}/cancel",
  "/v1/booking/organisation-selection",
  "/v1/booking/organisation-selection/{externalSelectionUuid}/withdraw",
  "/v1/testtaker/search",
  "/v1/testtaker/bookinghistory/{uniqueTestTakerUuid}",
  "/v1/testtaker/removeexclusion/{bookingUuid}/{uniqueTestTakerUuid}",
  "/v1/testtaker/removeuttidassociation/{bookingUuid}",
  "/v1/booking/{externalBookingUuid}/transfer",
  "/v1/booking/{bookingUuid}",
  "/v1/products",
  "/v1/resultstatus",
  "/v1/result/booking/{bookingUuid}",
  "/v1/booking/search",
  "/v1/testdaymaterialapproved",
  "/v1/testdaymaterialready",
  "/v1/testtaker/associateuttid",
  "/v1/testtakerphotosavailable",
  "/v1/incident/booking/search",
  "/v1/incident/submitprcoutcome",
  "/v1/booking/{externalBookingUuid}/photo",
  "/v1/ros/hierarchy",
  "/v1/ros/orgId/{organisationId}",
  "/v1/jaggedanalysiscomplete",
  "/v1/incident/receivespeakingincident",
  "/v1/booking/eor",
  "/v1/trf/booking/{bookingUuid}/selections/search",
  "/v1/candidateIdVerified",
  "/v1/candidateIdRejected",
  "/v1/candidateIdRequiresFollowUp",
  "/v2/result/booking/{bookingUuid}",
  "/v1/etrf/booking/{bookingUuid}/download/etrf",
  "/v1/trf/booking/{bookingUuid}/download/trf",
  "/v1/testtaker/bannedperiod/{uniqueTestTakerUuid}",
  "/v1/testtaker/bannedperiod/{uniqueTestTakerUuid}/{bannedPeriodUuid}",
  "/v1/regressionstatsavailable",
  "/v1/result/booking/{bookingUuid}/onhold",
  "/v1/result/bookings/onhold",
  "/v1/incident/search",
  "/v1/incident/{bookingUuid}",
  "/v1/incident/getidphotos/{bookingUuid}",
  "/v1/result/bookings/status",
  "/v1/candidateFlagAdded",
  "/v1/incidentReportAddedToLoggedEvent",
  "/v1/filesAttachedToLoggedEvent",
  "/v1/incident/update",
  "/v1/incident/submitidcheckoutcome",
  "/v1/testtakersubmissiondelivered",
  "/v1/testtakersubmissionexportfinished",
  "/v2/booking",
  "/v1/booking/refund-request",
  "/v1/locations",
  "/v1/locations/search",
  "/v1/locations/{locationUuid}",
  "/v1/searchMarks",
  "/v1/manualMarksUpdate",
  "/v1/accessArrangementRequested",
  "/v1/accessArrangementDetailsRequested",
  "/v2/booking/{externalBookingUuid}/transfer",
  "/v1/accessArrangementApproved",
  "/v1/result/booking/search",
  "/v1/products/{productUuid}"
]

# Add POST / PUT endpoints for which you want to enable serialization
enable_swagger_2_post_put_endpoints = [
    "/v1/users",
    "/v1/users/search",
    "/v1/users/{userUuid}/usergroups",
    "/v1/users/{userUuid}",
    "/v1/ros/search",
    "/v1/ros",
    "/v1/ros/{recognisingOrganisationUuid}",
    "/v1/trf/booking/{bookingUuid}/selections/search",
    "/v1/trf/booking/{bookingUuid}/download/trf",
    "/v1/etrf/booking/{bookingUuid}/download/etrf",
    "/v1/ros/{recognisingOrganisationUuid}",
    "/v1/locations",
    "/v1/locations/search",
    "/v1/locations/{locationUuid}",
    "/v1/uploadlocation",
    "/v1/accessArrangementRequested",
    "/v1/accessArrangementDetailsRequested",
    "/v1/accessArrangementApproved",
    "/v1/result/booking/{bookingUuid}/status",
    "/v1/result/bookings/status",
    "/v1/result/booking/{bookingUuid}/onhold",
    "/v1/result/bookings/onhold",
    "/v1/result/booking/search",
    "/v1/testtaker/associateuttid",
    "/v1/testtaker/bannedperiod/{uniqueTestTakerUuid}",
    "/v1/testtaker/bannedperiod/{uniqueTestTakerUuid}/{bannedPeriodUuid}",
    "/v1/testtaker/search",
    "/v1/booking/search",
    "/v1/products/{productUuid}"
]

# Add GET / DELETE endpoints for which you want to enable serialization
enable_swagger_2_get_delete_endpoints = [
    "/v1/usergroups",
    "/v1/users/{userUuid}",
    "/v1/users/locations",
    "/v1/ros/process",
    "/v1/ros/{recognisingOrganisationUuid}",
    "/v1/ros/orgId/{organisationId}",
    "/v1/ros/hierarchy",
    "/v1/notetypes",
    "/v1/partners",
    "/v1/sectortypes",
    "/v1/organisationtypes",
    "/v1/moduletypes",
    "/v1/contacttypes",
    "/v1/addresstypes",
    "/v1/countries",
    "/v1/countries/{countryCode}/territories",
    "/v1/locations/{locationUuid}",
    "/v1/products",
    "/v1/resultstatus",
    "/v2/result/booking/{bookingUuid}",
    "/v1/incident/getidphotos/{bookingUuid}",
    "/v1/incident/{bookingUuid}",
    "/v1/testtaker/bookinghistory/{uniqueTestTakerUuid}",
    "/v1/testtaker/removeexclusion/{bookingUuid}/{uniqueTestTakerUuid}",
    "/v1/testtaker/removeuttidassociation/{bookingUuid}",
    "/v1/booking/{bookingUuid}"

]

path_with_options =[
  "/v1/users",
  "/v1/usergroups",
  "/v1/users/search",
  "/v1/users/{userUuid}",
  "/v1/users/{userUuid}/usergroups",
  "/v1/users/locations",
  "/v1/notetypes",
  "/v1/partners",
  "/v1/sectortypes",
  "/v1/organisationtypes",
  "/v1/moduletypes",
  "/v1/contacttypes",
  "/v1/addresstypes",
  "/v1/countries",
  "/v1/countries/{countryCode}/territories" ,
  "/v1/ros/search",
  "/v1/ros",
  "/v1/ros/{recognisingOrganisationUuid}",
  "/v1/testtaker/search",
  "/v1/testtaker/bookinghistory/{uniqueTestTakerUuid}",
  "/v1/testtaker/removeexclusion/{bookingUuid}/{uniqueTestTakerUuid}",
  "/v1/testtaker/removeuttidassociation/{bookingUuid}",
  "/v1/booking/{bookingUuid}",
  "/v1/products",
  "/v1/resultstatus",
  "/v1/result/booking/{bookingUuid}",
  "/v2/result/booking/{bookingUuid}",
  "/v1/booking/search",
  "/v1/result/booking/{bookingUuid}/status",
  "/v1/testtaker/associateuttid",
  "/v1/incident/booking/search",
  "/v1/incident/submitprcoutcome",
  "/v1/ros/hierarchy",
  "/v1/ros/orgId/{organisationId}",
  "/v1/trf/booking/{bookingUuid}/selections/search",
  "/v1/incident/receivespeakingincident",
  "/v1/etrf/booking/{bookingUuid}/download/etrf",
  "/v1/trf/booking/{bookingUuid}/download/trf",
  "/v1/testtaker/bannedperiod/{uniqueTestTakerUuid}",
  "/v1/testtaker/bannedperiod/{uniqueTestTakerUuid}/{bannedPeriodUuid}",
  "/v1/regressionstatsavailable",
  "/v1/result/booking/{bookingUuid}/onhold",
  "/v1/result/bookings/onhold",
  "/v1/incident/search",
  "/v1/incident/{bookingUuid}",
  "/v1/incident/getidphotos/{bookingUuid}",
  "/v1/result/bookings/status",
  "/v1/booking/refund-request",
  "/v1/locations",
  "/v1/locations/search",
  "/v1/locations/{locationUuid}",
  "/v1/searchMarks",
  "/v1/manualMarksUpdate",
  "/v1/accessArrangementRequested",
  "/v1/accessArrangementDetailsRequested",
  "/v1/accessArrangementApproved",
  "/v1/products/{productUuid}"
]
stage_variables_dict = {}
stage_variables_dict["users"] = "${stageVariables.sm_ui_receiver}"
stage_variables_dict["usergroups"] = "${stageVariables.sm_ui_receiver}"
stage_variables_dict["ros"] = "${stageVariables.ro_ui_receiver}"
stage_variables_dict["testtaker"] = "${stageVariables.booking_ui_receiver}"
stage_variables_dict["booking"] = "${stageVariables.booking_ui_receiver}"
stage_variables_dict["result"] = "${stageVariables.rm_ui_receiver}"
stage_variables_dict["incident"] = "${stageVariables.ri_ui_receiver}"
stage_variables_dict["trf"] = "${stageVariables.rd_ui_receiver}"
stage_variables_dict["etrf"] = "${stageVariables.rd_ui_receiver}"
stage_variables_dict["lds"] = "${stageVariables.lds_ext_receiver}"
stage_variables_dict["locations"] = "${stageVariables.lpr_ui_receiver}"
stage_variables_dict["mmo"] = "${stageVariables.mmo_ui_receiver}"
stage_variables_dict["aa"] = "${stageVariables.aa_ui_receiver}"
stage_variables_dict["products"] = "${stageVariables.lpr_ui_receiver}"


def get_json_from_file(filename):
  with open(filename) as json_file:
    data = json.load(json_file)
  return data

def write_json_to_file(filename, data):
  with open(filename, 'w') as f:
    json.dump(data, f, indent=4)
  return True

def get_integration_value_with_given_templates(lambda_arn, request_template, response_template, response_code):
    return {
          "uri": "arn:aws:apigateway:${AWS::Region}:lambda:path/2015-03-31/functions/" + lambda_arn + "/invocations",
          "responses": {
              "default":
                  {
                      "statusCode": response_code,
                      "responseTemplates": {
                          "application/json": response_template
                      }
                  },
                  "BadRequest.*": {
                      "statusCode": 500,
                      "responseTemplates": {
                          "application/json": "#set ($errorMessageObj = $util.parseJson($input.path('$.errorMessage')))$errorMessageObj.body"
                      }
                  },
             ".*.400.*": {
                      "statusCode": 400,
                      "responseTemplates": {
                          "application/json": "#set ($errorMessageObj = $util.parseJson($input.path('$.errorMessage')))$errorMessageObj.body"
                      }
                  }
           },
          "requestTemplates": {
            "application/json": request_template
          },
          "passthroughBehavior": "when_no_match",
          "httpMethod": "POST",
          "contentHandling": "CONVERT_TO_TEXT",
          "type": "aws"
      }

def get_integration_value_with_given_templates_for_serialization(lambda_arn, request_template, response_template, response_code):
    return {
          "uri": "arn:aws:apigateway:${AWS::Region}:lambda:path/2015-03-31/functions/" + lambda_arn + "/invocations",
          "responses": {
              "default":
                  {
                      "statusCode": response_code,
                      "responseTemplates": {
                          "application/json": response_template
                      }
                  },
             "BadRequest.*": {
                      "statusCode": 400,
                      "responseTemplates": {
                          "application/json": "#set($errorMessageString = $input.path('$.errorMessage'))\n#set( $errorMessage = $errorMessageString.replace(\"BadRequest: \", \"\") )\n{\n    \"interface\": \"$context.resourcePath\",\n      \"type\": \"VALIDATION\",\n      \"errorCode\": \"V0001\",\n      \"message\": $errorMessage,\n      \"errorTicketUuid\": \"$context.requestId\",\n      \"title\": \"Invalid request body\"\n}"
                      }
                  }
           },
          "requestTemplates": {
            "application/json": request_template
          },
          "passthroughBehavior": "when_no_match",
          "httpMethod": "POST",
          "contentHandling": "CONVERT_TO_TEXT",
          "type": "aws"
      }

def get_custom_security_for_photo_path_in_cmds_external():
    return {
        "rest-api-authorizer": []
    }

def get_integration_value_with_default_templates(lambda_arn, response_template):
  return {
        "uri": "arn:aws:apigateway:${AWS::Region}:lambda:path/2015-03-31/functions/" + lambda_arn + "/invocations",
        "responses": {
            "default": {
              "statusCode": "202",
              "responseTemplates": {
                "application/json": response_template
              }
            }
        },
        "passthroughBehavior": "when_no_match",
        "httpMethod": "POST",
        "contentHandling": "CONVERT_TO_TEXT",
        "type": "aws"
    }

def update_root_level_data(data, custom_security_schemes_default_key, custom_security_schemes_value, custom_security_schemes_key, custom_security_schemes_value_v2, custom_security_schemes_key_v2, validators_definition_value, validators_definition_key, filename):
  # Removing default Root level Scheme
  data['components']['securitySchemes'].pop(custom_security_schemes_default_key)

  bad_request_value = {"statusCode": "400", "responseType": "BAD_REQUEST_BODY", "responseTemplates": {
      "application/json": "{\n     \"interface\": \"$context.resourcePath\",\n     \"type\":  \"ERROR\",\n     \"errorCode\":  \"400\",\n     \"errorTicketUuid\":  \"$context.requestId\",\n     \"message\":  \"$context.error.validationErrorString\",\n     \"title\": $context.error.messageString\n}"}}
  bad_request_parameter_value = {"statusCode": "400", "responseType": "BAD_REQUEST_PARAMETERS", "responseTemplates": {
      "application/json": "{\n     \"interface\": \"$context.resourcePath\",\n     \"type\":  \"ERROR\",\n     \"errorCode\":  \"400\",\n     \"errorTicketUuid\":  \"$context.requestId\",\n     \"message\":  \"$context.error.validationErrorString\",\n     \"title\": $context.error.messageString\n}"}}
  data['x-amazon-apigateway-gateway-responses']["BAD_REQUEST_BODY"] = bad_request_value
  data['x-amazon-apigateway-gateway-responses']["BAD_REQUEST_PARAMETERS"] = bad_request_parameter_value

  # Adding new Root level Scheme
  if "cmds-inspera.json" in filename :
    # Security scheme for Inspera
    data['components']['securitySchemes'][custom_security_schemes_key_v2] = custom_security_schemes_value_v2
  else:
    # Security scheme for anything other than inspera
    data['components']['securitySchemes'][custom_security_schemes_key] = custom_security_schemes_value

  if "cmds-external.json" in filename:
  #Adding authorizer default and v2 to booking microservice
    data['components']['securitySchemes'][custom_security_schemes_key_v2] = custom_security_schemes_value_v2

  if "cmds-ca.json" in filename:
  #Adding authorizer default and v2 to mmds microservice
    data['components']['securitySchemes'][custom_security_schemes_key_v2] = custom_security_schemes_value_v2

  data[validators_definition_key] = validators_definition_value
  logging.debug("Root Level data is updated successfully")
  return True

def update_method_level_data(custom_security_schemes_value, data, mock_integration_value, method_integration_key, method_security_value, method_security_key, method_validator_value, method_validator_key,filename):
  # Adding Method level data
  paths = data['paths']
  for current_path in paths:

    # Adding Options method in SM for solving CORS issues
    options_method_value = {
        "responses": {
          "200": {
            "description": "200 response",
            "headers": {
              "Access-Control-Allow-Origin": {
                "schema": {
                  "type": "string"
                }
              },
              "Access-Control-Allow-Methods": {
                "schema": {
                  "type": "string"
                }
              },
              "Access-Control-Allow-Headers": {
                "schema": {
                  "type": "string"
                }
              }
            },
            "content": {}
          }
        },
        "x-amazon-apigateway-integration": {
          "responses": {
            "default": {
              "statusCode": "200",
              "responseParameters": {
                "method.response.header.Access-Control-Allow-Methods": "'GET,OPTIONS,POST,PUT,DELETE'",
                "method.response.header.Access-Control-Allow-Headers": "'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,connectionId,correlationId,eventDateTime,x-access-token'",
                "method.response.header.Access-Control-Allow-Origin": "'*'"
              }
            }
          },
          "requestTemplates": {
            "application/json": "{\"statusCode\": 200}"
          },
          "passthroughBehavior": "when_no_match",
          "type": "mock"
        }
      }
    if(current_path in path_with_options):
      paths[current_path]['options'] = options_method_value

    for current_http_method in paths[current_path]:

      # Skipping options method
      if(current_http_method == "options"):
        continue

      # Adding Mock Integration to /healthcheck path and skipping rest of the steps for it
      current_path_array = current_path.split('/')
      if current_path == path[0]:
        paths[current_path][current_http_method][method_integration_key] = mock_integration_value
        continue
      # Otherwise saving the micro_service name
      else:
        micro_service = current_path_array[2]

      if len(current_path_array) >= 3:
        rd_micro_service = current_path_array[len(current_path_array)-1]

      # Adding common data to all methods if it's not parameters method
      if current_http_method != 'parameters' and "cmds-inspera.json" not in filename:
        paths[current_path][current_http_method][method_security_key] = method_security_value
        paths[current_path][current_http_method][method_validator_key] = method_validator_value
        default_response_template = "#set($context.responseOverride.status =  202)\n#set($inputRoot = $input.path('$.body'))\n$inputRoot"
        if "cmds-external.json" in filename:
            method_security_value = [{"rest-api-authorizer-v2": []}]
            paths[current_path][current_http_method][method_security_key] = method_security_value
            paths[current_path][current_http_method][method_validator_key] = method_validator_value

      # For Booking same resource name (booking) is shared between api-external and api-ui, however they used different receiver lambda.
      if "cmds-ui.json" in filename:
        stage_variables_dict["booking"] = "${stageVariables.booking_ui_receiver}"
        stage_variables_dict["trf"] = "${stageVariables.rd_ui_receiver}"
        stage_variables_dict["etrf"] = "${stageVariables.rd_ui_receiver}"
        stage_variables_dict["searchMarks"] = "${stageVariables.mmo_ui_receiver}"
        stage_variables_dict["manualMarksUpdate"] = "${stageVariables.mmo_ui_receiver}"
        stage_variables_dict["accessArrangementRequested"] = "${stageVariables.aa_ui_receiver}"
        stage_variables_dict["accessArrangementDetailsRequested"] = "${stageVariables.aa_ui_receiver}"
        stage_variables_dict["accessArrangementApproved"] = "${stageVariables.aa_ui_receiver}"

      # Adding data different to all methods
      # Staff Management Service Paths
      receiver_name = stage_variables_dict.get(micro_service, "")
      sm_lambda_arn = "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:"+receiver_name
      sm_post_put_request_template = "#set($allParams = $input.params())\r\n{\r\n #set($paramsHeader = $allParams.get('header'))\r\n #set($paramsPath = $allParams.get('path'))\r\n #set($paramQueryString = $allParams.get('querystring'))\r\n\"eventHeader\" : {\r\n    #foreach($paramHeaderName in $paramsHeader.keySet())\r\n    #if($paramHeaderName.toLowerCase() == 'connectionid') \r\n        \"connectionId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #elseif($paramHeaderName.toLowerCase() == 'correlationid') \r\n        \"correlationId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\" \r\n    #elseif($paramHeaderName.toLowerCase() == 'eventdatetime') \r\n        \"eventDateTimeAsString\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #elseif($paramHeaderName.toLowerCase() == 'authorization') \r\n        \"xaccessToken\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName)).replace('Bearer ','')\"    \r\n    #else\r\n       \"$paramHeaderName\" : \"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #end\r\n        #if($foreach.hasNext),#end\r\n    #end,\r\n    \"eventName\" :  \"$context.httpMethod$context.resourcePath\",\r\n    \"eventContext\" : {\r\n\t\t#foreach($paramPathName in $paramsPath.keySet())\r\n\t\t\"$paramPathName\" : \"$util.escapeJavaScript($paramsPath.get($paramPathName))\"\r\n\t\t#if($foreach.hasNext || $paramQueryString.keySet().size()>0),#end\r\n\t\t#end\r\n\t\t#foreach($paramQueryStr in $paramQueryString.keySet())\r\n\t\t\"$paramQueryStr\" : \"$util.escapeJavaScript($paramQueryString.get($paramQueryStr))\"\r\n\t\t#if($foreach.hasNext),#end\r\n\t\t#end\r\n    },\r\n    \"transactionId\" : \"$context.requestId\"\r\n},\r\n\"eventBody\" : \"$util.escapeJavaScript($input.json('$')).replaceAll(\"\\\\'\",\"'\")\",\r\n    \"httpMethod\" : \"$context.httpMethod\",\r\n    \"resource\" : \"$context.resourcePath\"\r\n}"
      swagger_2_post_put_request_template = "#set($allParams = $input.params())\r\n{\r\n #set($paramsHeader = $allParams.get('header'))\r\n #set($paramsPath = $allParams.get('path'))\r\n #set($paramQueryString = $allParams.get('querystring'))\r\n\"eventHeader\" : {\r\n    #foreach($paramHeaderName in $paramsHeader.keySet())\r\n    #if($paramHeaderName.toLowerCase() == 'connectionid') \r\n        \"connectionId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #elseif($paramHeaderName.toLowerCase() == 'correlationid') \r\n        \"correlationId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\" \r\n    #elseif($paramHeaderName.toLowerCase() == 'eventdatetime') \r\n        \"eventDateTimeAsString\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #elseif($paramHeaderName.toLowerCase() == 'authorization') \r\n        \"xaccessToken\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName)).replace('Bearer ','')\"    \r\n    #else\r\n       \"$paramHeaderName\" : \"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #end\r\n        #if($foreach.hasNext),#end\r\n    #end,\r\n    \"eventName\" :  \"$context.httpMethod$context.resourcePath\",\r\n    \"eventContext\" : {\r\n\t\t#foreach($paramPathName in $paramsPath.keySet())\r\n\t\t\"$paramPathName\" : \"$util.escapeJavaScript($paramsPath.get($paramPathName))\"\r\n\t\t#if($foreach.hasNext || $paramQueryString.keySet().size()>0),#end\r\n\t\t#end\r\n\t\t#foreach($paramQueryStr in $paramQueryString.keySet())\r\n\t\t\"$paramQueryStr\" : \"$util.escapeJavaScript($paramQueryString.get($paramQueryStr))\"\r\n\t\t#if($foreach.hasNext),#end\r\n\t\t#end\r\n    },\r\n    \"transactionId\" : \"$context.requestId\"\r\n},\r\n\"eventBody\" : $input.json('$'),\n    \"httpMethod\" : \"$context.httpMethod\",\r\n    \"resource\" : \"$context.resourcePath\"\r\n}"
      sm_get_delete_request_template = "#set($allParams = $input.params())\r\n{\r\n #set($paramsHeader = $allParams.get('header'))\r\n #set($paramsPath = $allParams.get('path'))\r\n #set($paramQueryString = $allParams.get('querystring'))\r\n\"eventHeader\" : {\r\n    #foreach($paramHeaderName in $paramsHeader.keySet())\r\n    #if($paramHeaderName.toLowerCase() == 'connectionid') \r\n        \"connectionId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #elseif($paramHeaderName.toLowerCase() == 'correlationid') \r\n        \"correlationId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\" \r\n    #elseif($paramHeaderName.toLowerCase() == 'eventdatetime') \r\n        \"eventDateTimeAsString\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #elseif($paramHeaderName.toLowerCase() == 'authorization') \r\n        \"xaccessToken\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName)).replace('Bearer ','')\"    \r\n    #else\r\n       \"$paramHeaderName\" : \"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #end\r\n        #if($foreach.hasNext),#end\r\n    #end,\r\n    \"eventName\" :  \"$context.httpMethod$context.resourcePath\",\r\n    \"eventContext\" : {\r\n\t\t#foreach($paramPathName in $paramsPath.keySet())\r\n\t\t\"$paramPathName\" : \"$util.escapeJavaScript($paramsPath.get($paramPathName))\"\r\n\t\t#if($foreach.hasNext),#end\r\n\t\t#end\r\n\t\t#foreach($paramQueryStr in $paramQueryString.keySet())\r\n\t\t\"$paramQueryStr\" : \"$util.escapeJavaScript($paramQueryString.get($paramQueryStr))\"\r\n\t\t#if($foreach.hasNext),#end\r\n\t\t#end\r\n    },\r\n    \"transactionId\" : \"$context.requestId\"\r\n},\r\n    \"eventBody\" : \"\",\r\n    \"httpMethod\" : \"$context.httpMethod\",\r\n    \"resource\" : \"$context.resourcePath\"\r\n}"
      swagger_2_get_delete_request_template = "#set($allParams = $input.params())\r\n{\r\n #set($paramsHeader = $allParams.get('header'))\r\n #set($paramsPath = $allParams.get('path'))\r\n #set($paramQueryString = $allParams.get('querystring'))\r\n\"eventHeader\" : {\r\n    #foreach($paramHeaderName in $paramsHeader.keySet())\r\n    #if($paramHeaderName.toLowerCase() == 'connectionid') \r\n        \"connectionId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #elseif($paramHeaderName.toLowerCase() == 'correlationid') \r\n        \"correlationId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\" \r\n    #elseif($paramHeaderName.toLowerCase() == 'eventdatetime') \r\n        \"eventDateTimeAsString\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #elseif($paramHeaderName.toLowerCase() == 'authorization') \r\n        \"xaccessToken\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName)).replace('Bearer ','')\"    \r\n    #else\r\n       \"$paramHeaderName\" : \"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #end\r\n        #if($foreach.hasNext),#end\r\n    #end,\r\n    \"eventName\" :  \"$context.httpMethod$context.resourcePath\",\r\n    \"eventContext\" : {\r\n\t\t#foreach($paramPathName in $paramsPath.keySet())\r\n\t\t\"$paramPathName\" : \"$util.escapeJavaScript($paramsPath.get($paramPathName))\"\r\n\t\t#if($foreach.hasNext),#end\r\n\t\t#end\r\n\t\t#foreach($paramQueryStr in $paramQueryString.keySet())\r\n\t\t\"$paramQueryStr\" : \"$util.escapeJavaScript($paramQueryString.get($paramQueryStr))\"\r\n\t\t#if($foreach.hasNext),#end\r\n\t\t#end\r\n    },\r\n    \"transactionId\" : \"$context.requestId\"\r\n},\r\n    \"eventBody\" : null,\r\n    \"httpMethod\" : \"$context.httpMethod\",\r\n    \"resource\" : \"$context.resourcePath\"\r\n}"
      sm_response_template = "#set($inputRoot = $input.path('$'))\n#set($context.responseOverride.status = $inputRoot.get('statusCode'))\n$inputRoot.get('body')"
      accepted_response_template = "#set($inputRoot = $input.path('$'))\n$inputRoot.get('body')"

      if "cmds-ui.json" in filename and (micro_service == "users" or micro_service == "usergroups" or micro_service== "ros" or micro_service == "testtaker" or micro_service == "booking" or micro_service == "result" or micro_service == "incident" or micro_service == "trf" or micro_service == "etrf" or micro_service == "locations" or micro_service == "searchMarks" or micro_service == "manualMarksUpdate" or micro_service == "accessArrangementRequested" or micro_service == "accessArrangementDetailsRequested" or micro_service == "accessArrangementApproved" or micro_service == "products"):

        if (micro_service == "accessArrangementRequested" or micro_service == "accessArrangementDetailsRequested" or micro_service == "accessArrangementApproved"):
          sm_post_put_request_template = "#set($allParams = $input.params())\r\n{\r\n #set($paramsHeader = $allParams.get('header'))\r\n #set($paramsPath = $allParams.get('path'))\r\n #set($paramQueryString = $allParams.get('querystring'))\r\n\"eventHeader\" : {\r\n    #foreach($paramHeaderName in $paramsHeader.keySet())\r\n    #if($paramHeaderName.toLowerCase() == 'connectionid') \r\n        \"connectionId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #elseif($paramHeaderName.toLowerCase() == 'correlationid') \r\n        \"correlationId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\" \r\n    #elseif($paramHeaderName.toLowerCase() == 'eventdatetime') \r\n        \"eventDateTimeAsString\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #elseif($paramHeaderName.toLowerCase() == 'authorization') \r\n        \"xaccessToken\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName)).replace('Bearer ','')\"    \r\n    #else\r\n       \"$paramHeaderName\" : \"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #end\r\n        #if($foreach.hasNext),#end\r\n    #end,\r\n    \"eventName\" :  \"$context.httpMethod$context.resourcePath\",\r\n    \"eventContext\" : {\r\n\t\t#foreach($paramPathName in $paramsPath.keySet())\r\n\t\t\"$paramPathName\" : \"$util.escapeJavaScript($paramsPath.get($paramPathName))\"\r\n\t\t#if($foreach.hasNext || $paramQueryString.keySet().size()>0),#end\r\n\t\t#end\r\n\t\t#foreach($paramQueryStr in $paramQueryString.keySet())\r\n\t\t\"$paramQueryStr\" : \"$util.escapeJavaScript($paramQueryString.get($paramQueryStr))\"\r\n\t\t#if($foreach.hasNext),#end\r\n\t\t#end\r\n    },\r\n    \"transactionId\" : \"$context.requestId\"\r\n},\r\n\"eventBody\" : $input.json('$'),\r\n    \"httpMethod\" : \"$context.httpMethod\",\r\n    \"resource\" : \"$context.resourcePath\"\r\n}"
        # Making 2 required parameters false and skipping next steps for SM paths
        if current_http_method == 'parameters':
          paths[current_path][current_http_method][0]['required'] = False
          paths[current_path][current_http_method][2]['required'] = False
          continue

        # Headers Key
        sm_response_headers_definition_key = "headers"
        sm_response_headers_key = "responseParameters"
        sm_request_headers_key = "requestParameters"
        # Headers Value
        sm_response_headers_definition_value = {
          "Access-Control-Allow-Origin": {
                "schema": {
                  "type": "string"
                }
              },
              "Access-Control-Allow-Methods": {
                "schema": {
                  "type": "string"
                }
              },
              "Access-Control-Allow-Headers": {
                "schema": {
                  "type": "string"
                }
              }
        }
        sm_response_headers_value = {
              "method.response.header.Access-Control-Allow-Methods": "'GET,OPTIONS,POST,PUT,DELETE'",
              "method.response.header.Access-Control-Allow-Headers": "'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,connectionId,correlationId,eventDateTime,x-access-token'",
              "method.response.header.Access-Control-Allow-Origin": "'*'"
        }
        sm_request_headers_value = {
              "integration.request.header.eventDateTime": "method.request.header.eventDateTime",
              "integration.request.header.Access-Control-Allow-Origin": "'*'",
              "integration.request.header.correlationId": "method.request.header.correlationId",
              "integration.request.header.connectionId": "method.request.header.connectionId"
        }

        # checking if the method is put or post to assign respective VTL
        if current_path in enable_swagger_2_post_put_endpoints and (current_http_method == 'post' or current_http_method == 'put'):
          paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_given_templates_for_serialization(sm_lambda_arn,swagger_2_post_put_request_template,accepted_response_template, 202)
        elif current_path in enable_swagger_2_get_delete_endpoints and  (current_http_method == 'get' or current_http_method == 'delete'):
          paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_given_templates_for_serialization(sm_lambda_arn,swagger_2_get_delete_request_template,accepted_response_template, 202)
        elif current_http_method == "post" or current_http_method == "put":
          paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_given_templates(sm_lambda_arn,sm_post_put_request_template,sm_response_template, 200)
          # Without Path Param
        else:
          paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_given_templates(sm_lambda_arn,sm_get_delete_request_template,sm_response_template, 200)

        # adding request headers
        paths[current_path][current_http_method][method_integration_key][sm_request_headers_key] = sm_request_headers_value

        # adding response headers
        paths[current_path][current_http_method]["responses"]["202"][sm_response_headers_definition_key] = sm_response_headers_definition_value
        paths[current_path][current_http_method]["responses"]["200"] = paths[current_path][current_http_method]["responses"]["202"]
        paths[current_path][current_http_method][method_integration_key]["responses"]["default"][sm_response_headers_key] = sm_response_headers_value

      elif "cmds-external.json" in filename and micro_service == "ros":
        ro_ext_lambda_arn = "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:${stageVariables.ro_ext_receiver}"
        # Headers Key
        ro_ext_response_headers_definition_key = "headers"
        ro_ext_response_headers_key = "responseParameters"
        ro_ext_request_headers_key = "requestParameters"
        ro_get_request_template = "#set($allParams = $input.params())\r\n{\r\n #set($paramsHeader = $allParams.get('header'))\r\n #set($paramsPath = $allParams.get('path'))\r\n #set($paramQueryString = $allParams.get('querystring'))\r\n\"eventHeader\" : {\r\n    #foreach($paramHeaderName in $paramsHeader.keySet())\r\n    #if($paramHeaderName.toLowerCase() == 'connectionid') \r\n        \"connectionId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #elseif($paramHeaderName.toLowerCase() == 'correlationid') \r\n        \"correlationId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\" \r\n    #elseif($paramHeaderName.toLowerCase() == 'eventdatetime') \r\n        \"eventDateTimeAsString\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #elseif($paramHeaderName.toLowerCase() == 'x-access-token') \r\n        \"xaccessToken\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName)).replace('Bearer ','')\"    \r\n    #else\r\n       \"$paramHeaderName\" : \"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #end\r\n        #if($foreach.hasNext),#end\r\n    #end,\r\n    \"eventName\" :  \"$context.httpMethod$context.resourcePath\",\r\n    \"eventContext\" : {\r\n\t\t#foreach($paramPathName in $paramsPath.keySet())\r\n\t\t\"$paramPathName\" : \"$util.escapeJavaScript($paramsPath.get($paramPathName))\"\r\n\t\t#if($foreach.hasNext),#end\r\n\t\t#end\r\n\t\t#foreach($paramQueryStr in $paramQueryString.keySet())\r\n\t\t\"$paramQueryStr\" : \"$util.escapeJavaScript($paramQueryString.get($paramQueryStr))\"\r\n\t\t#if($foreach.hasNext),#end\r\n\t\t#end\r\n    },\r\n    \"transactionId\" : \"$context.requestId\"\r\n},\r\n    \"eventBody\" : \"\",\r\n    \"httpMethod\" : \"$context.httpMethod\",\r\n    \"resource\" : \"$context.resourcePath\"\r\n}"
        ro_ext_response_template = "#set($inputRoot = $input.path('$'))\n#set($context.responseOverride.status = $inputRoot.get('statusCode'))\n$inputRoot.get('body')"
        # Headers Value
        ro_ext_response_headers_definition_value = {
          "Access-Control-Allow-Origin": {
                "schema": {
                  "type": "string"
                }
              },
              "Access-Control-Allow-Methods": {
                "schema": {
                  "type": "string"
                }
              },
              "Access-Control-Allow-Headers": {
                "schema": {
                  "type": "string"
                }
              }
        }
        ro_ext_response_headers_value = {
              "method.response.header.Access-Control-Allow-Methods": "'GET,OPTIONS,POST,PUT,DELETE'",
              "method.response.header.Access-Control-Allow-Headers": "'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,correlationId,eventDateTime,x-access-token'",
              "method.response.header.Access-Control-Allow-Origin": "'*'"
        }
        ro_ext_request_headers_value = {
              "integration.request.header.eventDateTime": "method.request.header.eventDateTime",
              "integration.request.header.Access-Control-Allow-Origin": "'*'",
              "integration.request.header.correlationId": "method.request.header.correlationId"
        }
        paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_given_templates(ro_ext_lambda_arn,ro_get_request_template,ro_ext_response_template, 202)
        # adding request headers
        paths[current_path][current_http_method][method_integration_key][ro_ext_request_headers_key] = ro_ext_request_headers_value

        # adding response headers
        paths[current_path][current_http_method]["responses"]["202"][ro_ext_response_headers_definition_key] = ro_ext_response_headers_definition_value
        paths[current_path][current_http_method]["responses"]["200"] = paths[current_path][current_http_method]["responses"]["202"]
        paths[current_path][current_http_method][method_integration_key]["responses"]["default"][ro_ext_response_headers_key] = ro_ext_response_headers_value
      # SM External Service Paths
      elif "cmds-external.json" in filename and micro_service == "uploadlocation":

        lpr_lambda_arn = "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:${stageVariables.lpr_ext_receiver}"
        # Eliminating parameters method
        if current_http_method == 'parameters':
          continue

        # Use x-access-token in VTL for external API Gateway
        sm_post_put_request_template = "#set($allParams = $input.params())\r\n{\r\n #set($paramsHeader = $allParams.get('header'))\r\n #set($paramsPath = $allParams.get('path'))\r\n #set($paramQueryString = $allParams.get('querystring'))\r\n\"eventHeader\" : {\r\n    #foreach($paramHeaderName in $paramsHeader.keySet())\r\n    #if($paramHeaderName.toLowerCase() == 'connectionid') \r\n        \"connectionId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #elseif($paramHeaderName.toLowerCase() == 'correlationid') \r\n        \"correlationId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\" \r\n    #elseif($paramHeaderName.toLowerCase() == 'eventdatetime') \r\n        \"eventDateTimeAsString\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #elseif($paramHeaderName.toLowerCase() == 'x-access-token') \r\n        \"xaccessToken\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName)).replace('Bearer ','')\"    \r\n    #else\r\n       \"$paramHeaderName\" : \"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #end\r\n        #if($foreach.hasNext),#end\r\n    #end,\r\n    \"eventName\" :  \"$context.httpMethod$context.resourcePath\",\r\n    \"eventContext\" : {\r\n\t\t#foreach($paramPathName in $paramsPath.keySet())\r\n\t\t\"$paramPathName\" : \"$util.escapeJavaScript($paramsPath.get($paramPathName))\"\r\n\t\t#if($foreach.hasNext),#end\r\n\t\t#end\r\n\t\t#foreach($paramQueryStr in $paramQueryString.keySet())\r\n\t\t\"$paramQueryStr\" : \"$util.escapeJavaScript($paramQueryString.get($paramQueryStr))\"\r\n\t\t#if($foreach.hasNext),#end\r\n\t\t#end\r\n    },\r\n    \"transactionId\" : \"$context.requestId\"\r\n},\r\n\"eventBody\" : $input.json('$')\n}"
        paths[current_path][current_http_method][
                                    method_integration_key] = get_integration_value_with_given_templates(
                                    lpr_lambda_arn, sm_post_put_request_template, sm_response_template, 202)
      # SM External Service Paths
      elif "cmds-external.json" in filename and micro_service == "users":

        sm_lambda_arn = "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:${stageVariables.sm_ext_receiver}"
        # Eliminating parameters method
        if current_http_method == 'parameters':
          continue

        # Use x-access-token in VTL for external API Gateway
        sm_post_put_request_template = "#set($allParams = $input.params())\r\n{\r\n #set($paramsHeader = $allParams.get('header'))\r\n #set($paramsPath = $allParams.get('path'))\r\n #set($paramQueryString = $allParams.get('querystring'))\r\n\"eventHeader\" : {\r\n    #foreach($paramHeaderName in $paramsHeader.keySet())\r\n    #if($paramHeaderName.toLowerCase() == 'connectionid') \r\n        \"connectionId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #elseif($paramHeaderName.toLowerCase() == 'correlationid') \r\n        \"correlationId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\" \r\n    #elseif($paramHeaderName.toLowerCase() == 'eventdatetime') \r\n        \"eventDateTimeAsString\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #elseif($paramHeaderName.toLowerCase() == 'x-access-token') \r\n        \"xaccessToken\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName)).replace('Bearer ','')\"    \r\n    #else\r\n       \"$paramHeaderName\" : \"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #end\r\n        #if($foreach.hasNext),#end\r\n    #end,\r\n    \"eventName\" :  \"$context.httpMethod$context.resourcePath\",\r\n    \"eventContext\" : {\r\n\t\t#foreach($paramPathName in $paramsPath.keySet())\r\n\t\t\"$paramPathName\" : \"$util.escapeJavaScript($paramsPath.get($paramPathName))\"\r\n\t\t#if($foreach.hasNext),#end\r\n\t\t#end\r\n\t\t#foreach($paramQueryStr in $paramQueryString.keySet())\r\n\t\t\"$paramQueryStr\" : \"$util.escapeJavaScript($paramQueryString.get($paramQueryStr))\"\r\n\t\t#if($foreach.hasNext),#end\r\n\t\t#end\r\n    },\r\n    \"transactionId\" : \"$context.requestId\"\r\n},\r\n\"eventBody\" : \"$util.escapeJavaScript($input.json('$')).replaceAll(\"\\\\'\",\"'\")\",\r\n    \"httpMethod\" : \"$context.httpMethod\",\r\n    \"resource\" : \"$context.resourcePath\"\r\n}"
        # checking if the method is put or post to assign respective VTL
        if current_http_method == "post" or current_http_method == "put":
          paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_given_templates(sm_lambda_arn,sm_post_put_request_template,sm_response_template, 202)
          # Without Path Param
        else:
          paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_given_templates(sm_lambda_arn,sm_get_delete_request_template,sm_response_template, 202)

      # Booking Service Paths
      elif micro_service == "booking" or micro_service == "bookingline":

        # Eliminating parameters method for booking paths
        if current_http_method == 'parameters':
          continue

        if rd_micro_service == "organisation-selection" or rd_micro_service == "withdraw":

                    result_delivery_lambda_arn = "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:${stageVariables.ors_ext_receiver}"
                    result_delivery_put_request_template = "#set($allParams = $input.params()){ #set($paramsHeader = $allParams.get('header')) #set($paramsPath = $allParams.get('path')) #set($paramQueryString = $allParams.get('querystring'))\"eventHeader\" : {    #foreach($paramHeaderName in $paramsHeader.keySet())    #if($paramHeaderName.toLowerCase() == 'correlationid')         \"correlationId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"     #elseif($paramHeaderName.toLowerCase() == 'eventdatetime')         \"eventDateTimeAsString\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'eventname')         \"eventName\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'x-access-token')         \"xaccessToken\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName)).replace('Bearer ','')\"        #else       \"$paramHeaderName\" : \"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #end        #if($foreach.hasNext),#end    #end,     \"eventName\" :  \"OrganisationSelectionChangedByTestTaker\", \"eventContext\" : {\t\t#foreach($paramPathName in $paramsPath.keySet())\t\t\"$paramPathName\" : \"$util.escapeJavaScript($paramsPath.get($paramPathName))\"\t\t#if($foreach.hasNext),#end\t\t#end\t\t#foreach($paramQueryStr in $paramQueryString.keySet())\t\t\"$paramQueryStr\" : \"$util.escapeJavaScript($paramQueryString.get($paramQueryStr))\"\t\t#if($foreach.hasNext),#end\t\t#end    },    \"transactionId\" : \"$context.requestId\"},\"eventBody\" : \"$util.escapeJavaScript($input.json('$')).replaceAll(\"\\\\'\",\"'\")\",    \"httpMethod\" : \"$context.httpMethod\",    \"resource\" : \"$context.resourcePath\"}";
                    result_delivery_post_request_template = "#set($allParams = $input.params()){ #set($paramsHeader = $allParams.get('header')) #set($paramsPath = $allParams.get('path')) #set($paramQueryString = $allParams.get('querystring'))\"eventHeader\" : {    #foreach($paramHeaderName in $paramsHeader.keySet())    #if($paramHeaderName.toLowerCase() == 'correlationid')         \"correlationId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"     #elseif($paramHeaderName.toLowerCase() == 'eventdatetime')         \"eventDateTimeAsString\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'eventname')         \"eventName\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'x-access-token')         \"xaccessToken\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName)).replace('Bearer ','')\"        #else       \"$paramHeaderName\" : \"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #end        #if($foreach.hasNext),#end    #end,     \"eventName\" :  \"OrganisationSelectionWithdrawRequestedByTestTaker\", \"eventContext\" : {\t\t#foreach($paramPathName in $paramsPath.keySet())\t\t\"$paramPathName\" : \"$util.escapeJavaScript($paramsPath.get($paramPathName))\"\t\t#if($foreach.hasNext),#end\t\t#end\t\t#foreach($paramQueryStr in $paramQueryString.keySet())\t\t\"$paramQueryStr\" : \"$util.escapeJavaScript($paramQueryString.get($paramQueryStr))\"\t\t#if($foreach.hasNext),#end\t\t#end    },    \"transactionId\" : \"$context.requestId\"},\"eventBody\" : \"$util.escapeJavaScript($input.json('$')).replaceAll(\"\\\\'\",\"'\")\",    \"httpMethod\" : \"$context.httpMethod\",    \"resource\" : \"$context.resourcePath\"}";
                    rd_response_template = "#set($inputRoot = $input.path('$'))\n#set($context.responseOverride.status = $inputRoot.get('statusCode'))\n$inputRoot.get('body')"

                    # Adding different Request template to post and put and skipping others
                    if current_http_method == "put":
                        paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_given_templates(result_delivery_lambda_arn,result_delivery_put_request_template,rd_response_template, 202)
                    elif current_http_method == "post":
                        paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_given_templates(result_delivery_lambda_arn,result_delivery_post_request_template,rd_response_template, 202)
                    else:
                        paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_default_templates(result_delivery_lambda_arn,default_response_template)

        else:

          tt_lambda_arn = "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:${stageVariables.ors_ext_receiver}"
          booking_lambda_arn = "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:${stageVariables.ors_ext_receiver}"
          booking_lambda_arn_v1 = "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:${stageVariables.ors_ext_receiver_v1}"
          booking_put_request_template = "#set($allParams = $input.params()){ #set($paramsHeader = $allParams.get('header')) #set($paramsPath = $allParams.get('path')) #set($paramQueryString = $allParams.get('querystring'))\"eventHeader\" : {    #foreach($paramHeaderName in $paramsHeader.keySet())    #if($paramHeaderName.toLowerCase() == 'correlationid')         \"correlationId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"     #elseif($paramHeaderName.toLowerCase() == 'eventdatetime')         \"eventDateTimeAsString\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'eventname')         \"eventName\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'x-access-token')         \"xaccessToken\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName)).replace('Bearer ','')\"        #else       \"$paramHeaderName\" : \"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #end        #if($foreach.hasNext),#end    #end,     \"eventName\" :  \"BookingChangeRequested\",     \"resource\" : \"$context.resourcePath\",    \"eventContext\" : {\t\t#foreach($paramPathName in $paramsPath.keySet())\t\t\"$paramPathName\" : \"$util.escapeJavaScript($paramsPath.get($paramPathName))\"\t\t#if($foreach.hasNext),#end\t\t#end\t\t#foreach($paramQueryStr in $paramQueryString.keySet())\t\t\"$paramQueryStr\" : \"$util.escapeJavaScript($paramQueryString.get($paramQueryStr))\"\t\t#if($foreach.hasNext),#end\t\t#end    },    \"transactionId\" : \"$context.requestId\"},\"eventBody\" : \"$util.escapeJavaScript($input.json('$')).replaceAll(\"\\\\'\",\"'\")\",    \"httpMethod\" : \"$context.httpMethod\" }";
          booking_put_request_template_v2 = "#set($allParams = $input.params()){ #set($paramsHeader = $allParams.get('header')) #set($paramsPath = $allParams.get('path')) #set($paramQueryString = $allParams.get('querystring'))\"eventHeader\" : {    #foreach($paramHeaderName in $paramsHeader.keySet())    #if($paramHeaderName.toLowerCase() == 'correlationid')         \"correlationId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"     #elseif($paramHeaderName.toLowerCase() == 'eventdatetime')         \"eventDateTimeAsString\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'eventname')         \"eventName\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'authorization')         \"xaccessToken\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName)).replace('Bearer ','')\"        #else       \"$paramHeaderName\" : \"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #end        #if($foreach.hasNext),#end    #end,     \"eventName\" :  \"BookingChangeRequested\",     \"resource\" : \"$context.resourcePath\",    \"eventContext\" : {\t\t#foreach($paramPathName in $paramsPath.keySet())\t\t\"$paramPathName\" : \"$util.escapeJavaScript($paramsPath.get($paramPathName))\"\t\t#if($foreach.hasNext),#end\t\t#end\t\t#foreach($paramQueryStr in $paramQueryString.keySet())\t\t\"$paramQueryStr\" : \"$util.escapeJavaScript($paramQueryString.get($paramQueryStr))\"\t\t#if($foreach.hasNext),#end\t\t#end    },    \"transactionId\" : \"$context.requestId\"},\"eventBody\" : \"$util.escapeJavaScript($input.json('$')).replaceAll(\"\\\\'\",\"'\")\",    \"httpMethod\" : \"$context.httpMethod\" }";
          booking_post_cancel_request_template = "#set($allParams = $input.params()){ #set($paramsHeader = $allParams.get('header')) #set($paramsPath = $allParams.get('path')) #set($paramQueryString = $allParams.get('querystring'))\"eventHeader\" : {    #foreach($paramHeaderName in $paramsHeader.keySet())    #if($paramHeaderName.toLowerCase() == 'correlationid')         \"correlationId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"     #elseif($paramHeaderName.toLowerCase() == 'eventdatetime')         \"eventDateTimeAsString\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'eventname')         \"eventName\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'x-access-token')         \"xaccessToken\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName)).replace('Bearer ','')\"        #else       \"$paramHeaderName\" : \"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #end        #if($foreach.hasNext),#end    #end,     \"eventName\" :  \"BookingCancelRequested\",     \"resource\" : \"$context.resourcePath\",    \"eventContext\" : {\t\t#foreach($paramPathName in $paramsPath.keySet())\t\t\"$paramPathName\" : \"$util.escapeJavaScript($paramsPath.get($paramPathName))\"\t\t#if($foreach.hasNext),#end\t\t#end    },    \"transactionId\" : \"$context.requestId\"},    \"httpMethod\" : \"$context.httpMethod\" }"
          booking_put_request_v2_template_v1_booking = "#set($allParams = $input.params()){ #set($paramsHeader = $allParams.get('header')) #set($paramsPath = $allParams.get('path')) #set($paramQueryString = $allParams.get('querystring'))\"eventHeader\" : {    #foreach($paramHeaderName in $paramsHeader.keySet())    #if($paramHeaderName.toLowerCase() == 'correlationid')         \"correlationId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"     #elseif($paramHeaderName.toLowerCase() == 'eventdatetime')         \"eventDateTimeAsString\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'eventname')         \"eventName\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'x-access-token')         \"xaccessToken\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName)).replace('Bearer ','')\"        #else       \"$paramHeaderName\" : \"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #end        #if($foreach.hasNext),#end    #end,     \"eventName\" :  \"BookingChangeRequested\",     \"resource\" : \"$context.resourcePath\",    \"eventContext\" : {\t\t#foreach($paramPathName in $paramsPath.keySet())\t\t\"$paramPathName\" : \"$util.escapeJavaScript($paramsPath.get($paramPathName))\"\t\t#if($foreach.hasNext),#end\t\t#end\t\t#foreach($paramQueryStr in $paramQueryString.keySet())\t\t\"$paramQueryStr\" : \"$util.escapeJavaScript($paramQueryString.get($paramQueryStr))\"\t\t#if($foreach.hasNext),#end\t\t#end    },    \"transactionId\" : \"$context.requestId\"},\"eventBody\" : $input.json('$'),    \"httpMethod\" : \"$context.httpMethod\" }";
          booking_put_request_v2_template_v2_booking = "#set($allParams = $input.params()){ #set($paramsHeader = $allParams.get('header')) #set($paramsPath = $allParams.get('path')) #set($paramQueryString = $allParams.get('querystring'))\"eventHeader\" : {    #foreach($paramHeaderName in $paramsHeader.keySet())    #if($paramHeaderName.toLowerCase() == 'correlationid')         \"correlationId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"     #elseif($paramHeaderName.toLowerCase() == 'eventdatetime')         \"eventDateTimeAsString\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'eventname')         \"eventName\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'authorization')         \"xaccessToken\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName)).replace('Bearer ','')\"        #else       \"$paramHeaderName\" : \"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #end        #if($foreach.hasNext),#end    #end,     \"eventName\" :  \"BookingChangeRequested\",     \"resource\" : \"$context.resourcePath\",    \"eventContext\" : {\t\t#foreach($paramPathName in $paramsPath.keySet())\t\t\"$paramPathName\" : \"$util.escapeJavaScript($paramsPath.get($paramPathName))\"\t\t#if($foreach.hasNext),#end\t\t#end\t\t#foreach($paramQueryStr in $paramQueryString.keySet())\t\t\"$paramQueryStr\" : \"$util.escapeJavaScript($paramQueryString.get($paramQueryStr))\"\t\t#if($foreach.hasNext),#end\t\t#end    },    \"transactionId\" : \"$context.requestId\"},\"eventBody\" : $input.json('$'),    \"httpMethod\" : \"$context.httpMethod\" }";
          booking_post_transfer_request_v2_template = "#set($allParams = $input.params()){ #set($paramsHeader = $allParams.get('header')) #set($paramsPath = $allParams.get('path')) #set($paramQueryString = $allParams.get('querystring'))\"eventHeader\" : {    #foreach($paramHeaderName in $paramsHeader.keySet())    #if($paramHeaderName.toLowerCase() == 'correlationid')         \"correlationId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"     #elseif($paramHeaderName.toLowerCase() == 'eventdatetime')         \"eventDateTimeAsString\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'eventname')         \"eventName\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'authorization')         \"xaccessToken\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName)).replace('Bearer ','')\"        #else       \"$paramHeaderName\" : \"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #end        #if($foreach.hasNext),#end    #end,     \"eventName\" :  \"BookingTransferRequested\",     \"resource\" : \"$context.resourcePath\",    \"eventContext\" : {\t\t#foreach($paramPathName in $paramsPath.keySet())\t\t\"$paramPathName\" : \"$util.escapeJavaScript($paramsPath.get($paramPathName))\"\t\t#if($foreach.hasNext),#end\t\t#end\t\t#foreach($paramQueryStr in $paramQueryString.keySet())\t\t\"$paramQueryStr\" : \"$util.escapeJavaScript($paramQueryString.get($paramQueryStr))\"\t\t#if($foreach.hasNext),#end\t\t#end    },    \"transactionId\" : \"$context.requestId\"},\"eventBody\" : $input.json('$'),    \"httpMethod\" : \"$context.httpMethod\" }"
          booking_post_transfer_request_template = "#set($allParams = $input.params()){ #set($paramsHeader = $allParams.get('header')) #set($paramsPath = $allParams.get('path')) #set($paramQueryString = $allParams.get('querystring'))\"eventHeader\" : {    #foreach($paramHeaderName in $paramsHeader.keySet())    #if($paramHeaderName.toLowerCase() == 'correlationid')         \"correlationId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"     #elseif($paramHeaderName.toLowerCase() == 'eventdatetime')         \"eventDateTimeAsString\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'eventname')         \"eventName\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'x-access-token')         \"xaccessToken\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName)).replace('Bearer ','')\"        #else       \"$paramHeaderName\" : \"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #end        #if($foreach.hasNext),#end    #end,     \"eventName\" :  \"BookingTransferredByOrs\",     \"resource\" : \"$context.resourcePath\",    \"eventContext\" : {\t\t#foreach($paramPathName in $paramsPath.keySet())\t\t\"$paramPathName\" : \"$util.escapeJavaScript($paramsPath.get($paramPathName))\"\t\t#if($foreach.hasNext),#end\t\t#end\t\t#foreach($paramQueryStr in $paramQueryString.keySet())\t\t\"$paramQueryStr\" : \"$util.escapeJavaScript($paramQueryString.get($paramQueryStr))\"\t\t#if($foreach.hasNext),#end\t\t#end    },    \"transactionId\" : \"$context.requestId\"},\"eventBody\" : $input.json('$'),    \"httpMethod\" : \"$context.httpMethod\" }"
          booking_post_photo_request_template = "#set($allParams = $input.params())\r\n{\r\n #set($paramsHeader = $allParams.get('header'))\r\n #set($paramsPath = $allParams.get('path'))\r\n #set($paramQueryString = $allParams.get('querystring'))\r\n\"eventHeader\" : {\r\n    #foreach($paramHeaderName in $paramsHeader.keySet())\r\n    #if($paramHeaderName.toLowerCase() == 'connectionid') \r\n        \"connectionId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #elseif($paramHeaderName.toLowerCase() == 'correlationid') \r\n        \"correlationId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\" \r\n    #elseif($paramHeaderName.toLowerCase() == 'eventdatetime') \r\n        \"eventDateTimeAsString\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #elseif($paramHeaderName.toLowerCase() == 'authorization') \r\n        \"xaccessToken\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName)).replace('Bearer ','')\"    \r\n    #else\r\n       \"$paramHeaderName\" : \"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #end\r\n        #if($foreach.hasNext),#end\r\n    #end,\r\n    \"eventName\" :  \"OrsPhotoProvided\",\r\n    \"eventContext\" : {\r\n\t\t#foreach($paramPathName in $paramsPath.keySet())\r\n\t\t\"$paramPathName\" : \"$util.escapeJavaScript($paramsPath.get($paramPathName))\"\r\n\t\t#if($foreach.hasNext),#end\r\n\t\t#end\r\n\t\t#foreach($paramQueryStr in $paramQueryString.keySet())\r\n\t\t\"$paramQueryStr\" : \"$util.escapeJavaScript($paramQueryString.get($paramQueryStr))\"\r\n\t\t#if($foreach.hasNext),#end\r\n\t\t#end\r\n    },\r\n    \"transactionId\" : \"$context.requestId\"\r\n},\r\n    \"eventBody\" : \"$util.escapeJavaScript($input.json('$')).replaceAll(\"\\\\'\",\"'\")\",\r\n    \"httpMethod\" : \"$context.httpMethod\",\r\n    \"resource\" : \"$context.resourcePath\"\r\n}"
          refund_put_request_template = "#set($allParams = $input.params()){ #set($paramsHeader = $allParams.get('header')) #set($paramsPath = $allParams.get('path')) #set($paramQueryString = $allParams.get('querystring'))\"eventHeader\" : {    #foreach($paramHeaderName in $paramsHeader.keySet())    #if($paramHeaderName.toLowerCase() == 'correlationid')         \"correlationId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"     #elseif($paramHeaderName.toLowerCase() == 'eventdatetime')         \"eventDateTimeAsString\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'eventname')         \"eventName\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'authorization')         \"xaccessToken\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName)).replace('Bearer ','')\"        #else       \"$paramHeaderName\" : \"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #end        #if($foreach.hasNext),#end    #end,     \"eventName\" :  \"RefundRequestedByOrs\",     \"resource\" : \"$context.resourcePath\",    \"eventContext\" : {\t\t#foreach($paramPathName in $paramsPath.keySet())\t\t\"$paramPathName\" : \"$util.escapeJavaScript($paramsPath.get($paramPathName))\"\t\t#if($foreach.hasNext),#end\t\t#end\t\t#foreach($paramQueryStr in $paramQueryString.keySet())\t\t\"$paramQueryStr\" : \"$util.escapeJavaScript($paramQueryString.get($paramQueryStr))\"\t\t#if($foreach.hasNext),#end\t\t#end    },    \"transactionId\" : \"$context.requestId\"},\"eventBody\" : \"$util.escapeJavaScript($input.json('$')).replaceAll(\"\\\\'\",\"'\")\",    \"httpMethod\" : \"$context.httpMethod\" }"
          bookin_response_template = "#set($inputRoot = $input.path('$'))\n$inputRoot.body"
          eor_lambda_arn = "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:${stageVariables.ors_ext_receiver}"
          eor_response_template = "#set($inputRoot = $input.path('$'))\n$inputRoot.body"
          eor_request_template ="#set($allParams = $input.params()){ #set($paramsHeader = $allParams.get('header')) #set($paramsPath = $allParams.get('path')) #set($paramQueryString = $allParams.get('querystring'))\"eventHeader\" : {    #foreach($paramHeaderName in $paramsHeader.keySet())    #if($paramHeaderName.toLowerCase() == 'correlationid')         \"correlationId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"     #elseif($paramHeaderName.toLowerCase() == 'eventdatetime')         \"eventDateTimeAsString\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'eventname')         \"eventName\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'authorization')         \"xaccessToken\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName)).replace('Bearer ','')\"        #else       \"$paramHeaderName\" : \"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #end        #if($foreach.hasNext),#end    #end,     \"eventName\" :  \"EorRequestedByOrs\",     \"resource\" : \"$context.resourcePath\",    \"eventContext\" : {\t\t#foreach($paramPathName in $paramsPath.keySet())\t\t\"$paramPathName\" : \"$util.escapeJavaScript($paramsPath.get($paramPathName))\"\t\t#if($foreach.hasNext),#end\t\t#end    },    \"transactionId\" : \"$context.requestId\"},\"eventBody\" : \"$util.escapeJavaScript($input.json('$')).replaceAll(\"\\\\'\",\"'\")\",    \"httpMethod\" : \"$context.httpMethod\"}"

          if current_http_method == "post":
            if current_path == path[26]:  # cancel
                                paths[current_path][current_http_method][
                                    method_integration_key] = get_integration_value_with_given_templates(
                                    booking_lambda_arn_v1, booking_post_cancel_request_template, bookin_response_template, 202)
            elif current_path == path[33]:  # v1 transfer
                paths[current_path][current_http_method][
                    method_integration_key] = get_integration_value_with_given_templates(booking_lambda_arn_v1,
                                                                                          booking_post_transfer_request_template,
                                                                                          bookin_response_template,
                                                                                          202)
            elif current_path == path[83]:  # v2 transfer
                paths[current_path][current_http_method][method_security_key] = []
                paths[current_path][current_http_method][method_security_key].append(get_custom_security_for_photo_path_in_cmds_external())
                paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_given_templates(booking_lambda_arn_v1,
                                                                                          booking_post_transfer_request_v2_template,
                                                                                          bookin_response_template,
                                                                                          202)

            elif current_path == path[45]:  # Photo
                paths[current_path][current_http_method][method_security_key] = []
                paths[current_path][current_http_method][method_security_key].append(get_custom_security_for_photo_path_in_cmds_external())
                paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_given_templates(
                    tt_lambda_arn,
                    booking_post_photo_request_template,
                    bookin_response_template,
                    202
                )
          elif current_http_method == "put":#booking
            if current_path == path[7]:  # v1 booking
              paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_given_templates(booking_lambda_arn_v1,booking_put_request_v2_template_v1_booking,bookin_response_template, 202)

            elif current_path == path[74]:  # v2 booking
              paths[current_path][current_http_method][method_security_key] = []
              paths[current_path][current_http_method][method_security_key].append(
                get_custom_security_for_photo_path_in_cmds_external())
              paths[current_path][current_http_method][
                method_integration_key] = get_integration_value_with_given_templates(booking_lambda_arn_v1,
                                                                                     booking_put_request_v2_template_v2_booking,
                                                                                     bookin_response_template,
                                                                                     202)
            elif current_path == path[50]:
              method_security_value = [{"rest-api-authorizer": []}]
              paths[current_path][current_http_method][method_security_key] = method_security_value
              paths[current_path][current_http_method][method_validator_key] = method_validator_value
              paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_given_templates(eor_lambda_arn,
                                                                                          eor_request_template,
                                                                                          eor_response_template,
                                                                                          202)

            elif current_path == path[75]:  # refund
              method_security_value = [{"rest-api-authorizer": []}]
              paths[current_path][current_http_method][method_security_key] = method_security_value
              paths[current_path][current_http_method][method_validator_key] = method_validator_value
              paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_given_templates(booking_lambda_arn,
                                                                                          refund_put_request_template,
                                                                                          bookin_response_template,
                                                                                          202)
          else:#default
              paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_default_templates(booking_lambda_arn,default_response_template)

      elif "cmds-external.json" in filename and micro_service == "incident":
        ors_lambda_arn = "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:${stageVariables.ors_ext_receiver}"
        ors_response_template = "#set($inputRoot = $input.path('$'))\n#set($context.responseOverride.status = $inputRoot.get('statusCode'))\n$inputRoot.get('body')"

        if current_http_method == "post":
          method_security_value = [{"rest-api-authorizer": []}]
          paths[current_path][current_http_method][method_security_key] = method_security_value
          paths[current_path][current_http_method][method_validator_key] = method_validator_value
          if current_path == path[49]:
            ors_request_template = "#set($allParams = $input.params()){ #set($paramsHeader = $allParams.get('header')) #set($paramsPath = $allParams.get('path')) #set($paramQueryString = $allParams.get('querystring'))\"eventHeader\" : {    #foreach($paramHeaderName in $paramsHeader.keySet())    #if($paramHeaderName.toLowerCase() == 'correlationid')         \"correlationId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"     #elseif($paramHeaderName.toLowerCase() == 'eventdatetime')         \"eventDateTimeAsString\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'eventname')         \"eventName\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'authorization')         \"xaccessToken\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName)).replace('Bearer ','')\"        #else       \"$paramHeaderName\" : \"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #end        #if($foreach.hasNext),#end    #end,     \"eventName\" :  \"${stageVariables.ors_speaking_incident_event}\",     \"resource\" : \"$context.resourcePath\",    \"eventContext\" : {\t\t#foreach($paramPathName in $paramsPath.keySet())\t\t\"$paramPathName\" : \"$util.escapeJavaScript($paramsPath.get($paramPathName))\"\t\t#if($foreach.hasNext),#end\t\t#end    },    \"transactionId\" : \"$context.requestId\"},\"eventBody\" : \"$util.escapeJavaScript($input.json('$')).replaceAll(\"\\\\'\",\"'\")\",    \"httpMethod\" : \"$context.httpMethod\" }";
            paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_given_templates(ors_lambda_arn, ors_request_template, ors_response_template, 202)

      # Inspera API Gateway IDS Paths

      elif "cmds-inspera.json" in filename:
        ids_lambda_arn = "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:${stageVariables.ids_ext_receiver}"
        ids_response_template = "#set($inputRoot = $input.path('$')) \n#set($context.responseOverride.status = $inputRoot.statusCode)"
        if current_http_method == "post":
          paths[current_path][current_http_method][method_validator_key] = method_validator_value
          if inspera_path[current_path]['xinsperaSignature']:   
            ids_request_template = "{\n  \"eventHeader\": {\n  \"eventName\":\""+ inspera_path[current_path]['eventName'] +"\",\n  \"eventDateTimeAsString\": $input.json('$.timestamp').replace('Z','.000Z'),\n  \"xinsperaSignature\": \"$input.params().header.get('X-Inspera-Signature')\"\n  },\n  \"eventBody\":$input.json('$'),\n\"httpMethod\": \"$context.httpMethod\",\n\"resource\": \"$context.resourcePath\"\n}"
            paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_given_templates(ids_lambda_arn, ids_request_template, ids_response_template, 200)
          else:
            ids_request_template = "{\n  \"eventHeader\": {\n    \"correlationId\": \"$input.params().header.get('correlationId')\",\n    \"eventDateTimeAsString\": \"$input.params().header.get('eventDateTime')\",\n    \"eventName\": \"$context.httpMethod$context.resourcePath\"\n  },\n  \"eventBody\":$input.json('$'),\n\"httpMethod\": \"$context.httpMethod\",\n\"resource\": \"$context.resourcePath\"\n}"
            method_security_value = [ { "rest-api-authorizer-v2" : [] } ]
            paths[current_path][current_http_method][method_security_key] = method_security_value

      # CA Legacy Adapter Paths
      elif "cmds-ca.json" in filename:
        lds_marks_response_template = "#set($inputRoot = $input.path('$')) \n#set($context.responseOverride.status = $inputRoot.statusCode)"
        lds_lambda_arn = "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:${stageVariables.lds_ext_receiver}"
        lds_regstats_response_template = "#set($inputRoot = $input.path('$'))\n#set($context.responseOverride.status = $inputRoot.get('statusCode'))\n$inputRoot.get('body')"
        method_security_value = [ { "rest-api-authorizer-v2" : [] } ]
        if current_http_method == "post":
          paths[current_path][current_http_method][method_security_key] = method_security_value
          paths[current_path][current_http_method][method_validator_key] = method_validator_value
          if current_path == "/v1/cdmarksavailable":
            lds_marks_request_template = "{\n  \"eventHeader\": {\n  \"eventVersion\": \"v2\",\n  \"correlationId\": \"$input.params().header.get('correlationId')\",\n    \"eventDateTimeAsString\": \"$input.params().header.get('eventDateTime')\",\n    \"eventName\": \"$context.httpMethod$context.resourcePath\",\n    \"transactionId\": \"$context.requestId\"\n  },\n  \"eventBody\":$input.json('$'),\n\"httpMethod\": \"$context.httpMethod\",\n\"resource\": \"$context.resourcePath\"\n}"
            paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_given_templates(lds_lambda_arn, lds_marks_request_template, lds_marks_response_template, 200)
          elif current_path == "/v1/regressionstatsavailable":
            method_security_value = [ { "rest-api-authorizer" : [] } ]
            paths[current_path][current_http_method][method_security_key] = method_security_value
            paths[current_path][current_http_method][method_validator_key] = method_validator_value
            lds_regstats_request_template = "#set($allParams = $input.params()){ #set($paramsHeader = $allParams.get('header')) #set($paramsPath = $allParams.get('path')) #set($paramQueryString = $allParams.get('querystring'))\"eventHeader\" : {    #foreach($paramHeaderName in $paramsHeader.keySet())    #if($paramHeaderName.toLowerCase() == 'correlationid') \"correlationId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"     #elseif($paramHeaderName.toLowerCase() == 'eventdatetime')         \"eventDateTimeAsString\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'eventname')         \"eventName\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #elseif($paramHeaderName.toLowerCase() == 'authorization')         \"xaccessToken\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName)).replace('Bearer ','')\"        #else       \"$paramHeaderName\" : \"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"    #end        #if($foreach.hasNext),#end    #end,     \"eventName\" :  \"$context.httpMethod$context.resourcePath\", \"eventVersion\" :  \"v2\", \"eventContext\" : {\t\t#foreach($paramPathName in $paramsPath.keySet())\t\t\"$paramPathName\" : \"$util.escapeJavaScript($paramsPath.get($paramPathName))\"\t\t#if($foreach.hasNext),#end\t\t#end\t\t#foreach($paramQueryStr in $paramQueryString.keySet())\t\t\"$paramQueryStr\" : \"$util.escapeJavaScript($paramQueryString.get($paramQueryStr))\"\t\t#if($foreach.hasNext),#end\t\t#end    },    \"transactionId\" : \"$context.requestId\"},\"eventBody\" : $input.json('$'),    \"httpMethod\" : \"$context.httpMethod\",    \"resource\" : \"$context.resourcePath\"}";
            paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_given_templates(lds_lambda_arn, lds_regstats_request_template, lds_regstats_response_template, 202)

      # LPR Service Paths
      else:
        # Eliminating parameters method for LPR paths
        if current_http_method == 'parameters':
          continue

        # Headers Key
        lpr_ref_response_headers_definition_key = "headers"
        lpr_ref_response_headers_key = "responseParameters"
        lpr_ref_request_headers_key = "requestParameters"
        # Headers Value
        lpr_ref_response_headers_definition_value = {
          "Access-Control-Allow-Origin": {
                "schema": {
                  "type": "string"
                }
              },
              "Access-Control-Allow-Methods": {
                "schema": {
                  "type": "string"
                }
              },
              "Access-Control-Allow-Headers": {
                "schema": {
                  "type": "string"
                }
              }
        }
        lpr_ref_response_headers_value = {
              "method.response.header.Access-Control-Allow-Methods": "'GET,OPTIONS,POST,PUT,DELETE'",
              "method.response.header.Access-Control-Allow-Headers": "'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,connectionId,correlationId,eventDateTime,x-access-token'",
              "method.response.header.Access-Control-Allow-Origin": "'*'"
        }
        lpr_ref_request_headers_value = {
              "integration.request.header.eventDateTime": "method.request.header.eventDateTime",
              "integration.request.header.Access-Control-Allow-Origin": "'*'",
              "integration.request.header.correlationId": "method.request.header.correlationId",
              "integration.request.header.connectionId": "method.request.header.connectionId"
        }


        lpr_ext_lambda_arn = "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:${stageVariables.lpr_ext_receiver}"
        lpr_ui_lambda_arn = "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:${stageVariables.lpr_ui_receiver}"

        lpr_post_request_template="#set($allParams = $input.params())\r\n{\r\n #set($paramsHeader = $allParams.get('header'))\r\n #set($paramsPath = $allParams.get('path'))\r\n #set($paramQueryString = $allParams.get('querystring'))\r\n\"eventHeader\" : {\r\n    #foreach($paramHeaderName in $paramsHeader.keySet())\r\n    #if($paramHeaderName.toLowerCase() == 'connectionid') \r\n        \"connectionId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #elseif($paramHeaderName.toLowerCase() == 'correlationid') \r\n        \"correlationId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\" \r\n    #elseif($paramHeaderName.toLowerCase() == 'eventdatetime') \r\n        \"eventDateTimeAsString\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #elseif($paramHeaderName.toLowerCase() == 'x-access-token') \r\n        \"xaccessToken\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName)).replace('Bearer ','')\"    \r\n    #else\r\n       \"$paramHeaderName\" : \"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #end\r\n        #if($foreach.hasNext),#end\r\n    #end,\r\n    \"eventName\" :  \"$context.httpMethod$context.resourcePath\",\r\n    \"eventContext\" : {\r\n\t\t#foreach($paramPathName in $paramsPath.keySet())\r\n\t\t\"$paramPathName\" : \"$util.escapeJavaScript($paramsPath.get($paramPathName))\"\r\n\t\t#if($foreach.hasNext),#end\r\n\t\t#end\r\n\t\t#foreach($paramQueryStr in $paramQueryString.keySet())\r\n\t\t\"$paramQueryStr\" : \"$util.escapeJavaScript($paramQueryString.get($paramQueryStr))\"\r\n\t\t#if($foreach.hasNext),#end\r\n\t\t#end\r\n    },\r\n    \"transactionId\" : \"$context.requestId\"\r\n},\r\n    \"eventBody\" : \"$util.escapeJavaScript($input.json('$')).replaceAll(\"\\\\'\",\"'\")\",\r\n    \"httpMethod\" : \"$context.httpMethod\",\r\n    \"resource\" : \"$context.resourcePath\"\r\n}"
        lpr_response_template = "#set($inputRoot = $input.path('$'))\n$inputRoot.body"

        lpr_get_request_template = "#set($allParams = $input.params())\r\n{\r\n #set($paramsHeader = $allParams.get('header'))\r\n #set($paramsPath = $allParams.get('path'))\r\n #set($paramQueryString = $allParams.get('querystring'))\r\n\"eventHeader\" : {\r\n    #foreach($paramHeaderName in $paramsHeader.keySet())\r\n    #if($paramHeaderName.toLowerCase() == 'connectionid') \r\n        \"connectionId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #elseif($paramHeaderName.toLowerCase() == 'correlationid') \r\n        \"correlationId\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\" \r\n    #elseif($paramHeaderName.toLowerCase() == 'eventdatetime') \r\n        \"eventDateTimeAsString\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #elseif($paramHeaderName.toLowerCase() == 'authorization') \r\n        \"xaccessToken\":\"$util.escapeJavaScript($paramsHeader.get($paramHeaderName)).replace('Bearer ','')\"    \r\n    #else\r\n       \"$paramHeaderName\" : \"$util.escapeJavaScript($paramsHeader.get($paramHeaderName))\"\r\n    #end\r\n        #if($foreach.hasNext),#end\r\n    #end,\r\n    \"eventName\" :  \"$context.httpMethod$context.resourcePath\",\r\n    \"eventContext\" : {\r\n\t\t#foreach($paramPathName in $paramsPath.keySet())\r\n\t\t\"$paramPathName\" : \"$util.escapeJavaScript($paramsPath.get($paramPathName))\"\r\n\t\t#if($foreach.hasNext),#end\r\n\t\t#end\r\n\t\t#foreach($paramQueryStr in $paramQueryString.keySet())\r\n\t\t\"$paramQueryStr\" : \"$util.escapeJavaScript($paramQueryString.get($paramQueryStr))\"\r\n\t\t#if($foreach.hasNext),#end\r\n\t\t#end\r\n    },\r\n    \"transactionId\" : \"$context.requestId\"\r\n},\r\n    \"eventBody\" : \"\",\r\n    \"httpMethod\" : \"$context.httpMethod\",\r\n    \"resource\" : \"$context.resourcePath\"\r\n}"

        # Adding Request and Response template only to one POST Method
        if current_http_method == "post":
          paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_given_templates(lpr_ext_lambda_arn,lpr_post_request_template,lpr_response_template, 202)
        elif current_http_method == "get":
          paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_given_templates(lpr_ui_lambda_arn,lpr_get_request_template,lpr_response_template, 202)
        else:
          paths[current_path][current_http_method][method_integration_key] = get_integration_value_with_default_templates(lpr_ext_lambda_arn,default_response_template)

        # adding request headers
        paths[current_path][current_http_method][method_integration_key][lpr_ref_request_headers_key] = lpr_ref_request_headers_value

        # adding response headers
        paths[current_path][current_http_method]["responses"]["202"][lpr_ref_response_headers_definition_key] = lpr_ref_response_headers_definition_value
        paths[current_path][current_http_method]["responses"]["200"] = paths[current_path][current_http_method]["responses"]["202"]
        paths[current_path][current_http_method][method_integration_key]["responses"]["default"][lpr_ref_response_headers_key] = lpr_ref_response_headers_value

  logging.debug("Method Level data is updated successfully")
  return True

def update_swagger(filename):
  try:
      data = get_json_from_file(filename)
  except Exception as e:
    logging.error("Unable to open file for reading: %s (Exiting)",e,exc_info=False)
    return False

  # Keys
  method_security_key = "security"
  method_validator_key = "x-amazon-apigateway-request-validator"
  method_integration_key = "x-amazon-apigateway-integration"
  custom_security_schemes_key = "rest-api-authorizer"
  custom_security_schemes_key_v2 = "rest-api-authorizer-v2"
  custom_security_schemes_default_key = "Some_Random_Api_Key"
  validators_definition_key = "x-amazon-apigateway-request-validators"
  # Values
  method_security_value = [ { "rest-api-authorizer": [] } ]
  method_validator_value = "Validate body, query string parameters, and headers"
  mock_integration_value = {
        "responses": {
          "default": {
            "statusCode": "200"
          }
        },
        "requestTemplates": {
          "application/json": "{\"statusCode\": 200}"
        },
        "passthroughBehavior": "when_no_match",
        "type": "mock"
      }
  custom_security_schemes_value = {
      "type": "apiKey",
      "name": "Authorization",
      "in": "header",
      "x-amazon-apigateway-authtype": "custom",
      "x-amazon-apigateway-authorizer": {
          "authorizerUri": "arn:aws:apigateway:${AWS::Region}:lambda:path/2015-03-31/functions/arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:${stageVariables.auth0_lambda_name}/invocations",
          "authorizerResultTtlInSeconds": 0,
          "identityValidationExpression": "^Bearer [-0-9a-zA-z\\.]*$",
          "type": "token"
      }
  }
  custom_security_schemes_value_v2 = {
      "type": "apiKey",
      "name": "x-access-token",
      "in": "header",
      "x-amazon-apigateway-authtype": "custom",
      "x-amazon-apigateway-authorizer": {
          "authorizerUri": "arn:aws:apigateway:${AWS::Region}:lambda:path/2015-03-31/functions/arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:${stageVariables.auth0_lambda_name}/invocations",
          "authorizerResultTtlInSeconds": 0,
          "identityValidationExpression": "^Bearer [-0-9a-zA-z\\.]*$",
          "type": "token"
      }
  }
  validators_definition_value = {
      "Validate body, query string parameters, and headers": {
        "validateRequestParameters": True,
        "validateRequestBody": True
      },
      "Validate query string parameters, and headers": {
        "validateRequestParameters": True,
        "validateRequestBody": False
      },
      "Validate body": {
        "validateRequestParameters": False,
        "validateRequestBody": True
      }
  }

  try:
    update_root_level_data(data, custom_security_schemes_default_key, custom_security_schemes_value, custom_security_schemes_key, custom_security_schemes_value_v2, custom_security_schemes_key_v2, validators_definition_value, validators_definition_key, filename)
  except KeyError as e:
    logging.error("Error in Updating Root Level Data: KEY_NOT_FOUND -> %s ",e,exc_info=False)
  try:
    update_method_level_data(custom_security_schemes_value, data, mock_integration_value, method_integration_key, method_security_value, method_security_key, method_validator_value, method_validator_key,filename)
  except KeyError as e:
    logging.error("Error in Updating Method Level Data: KEY_NOT_FOUND -> %s ",e,exc_info=False)
  # Writing updated JSON data to file
  try:
    write_json_to_file(filename, data)
    logging.debug("Swagger File is Successfully updated")
    return True
  except Exception as e:
    logging.error("Some Error in Opening file for writing : %s",e,exc_info=False)

def run_script():
  try:
    swagger_file_name = sys.argv[1]
    update_swagger(swagger_file_name)
  except IndexError as e:
    logging.error("Please provide \"filepath\" as argument in execution command - %s",e,exc_info=False)

run_script()
