
import json
with open('assume-cred.json') as json_file:
    result = json.load(json_file)
    f = open("aws-cred.sh", "a")
    f.write("export AWS_ACCESS_KEY_ID=%s\n" % (result['Credentials']['AccessKeyId']))
    f.write("export AWS_SECRET_ACCESS_KEY=%s\n" % (result['Credentials']['SecretAccessKey']))
    f.write("export AWS_SESSION_TOKEN=%s" % (result['Credentials']['SessionToken']))
    f.close()