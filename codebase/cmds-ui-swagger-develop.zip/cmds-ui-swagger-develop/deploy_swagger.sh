apigateway_id=$1
keyvalues=$2
api_domain_name=$3
#rest_api_name=ielts-cmds-$CI_ENVIRONMENT_NAME-api-external
web_acl_regional=$4
rest_api_name=''
file_name=''
apigateway_accesslog_destination_arn_var=$6
echo "api gateway name $5"
#remove :* at the end of arn value
apigateway_accesslog_destination_arn=${apigateway_accesslog_destination_arn_var::-2}

echo $5
if [ "$5" == "external" ]; then
  echo "inside external $5"
  rest_api_name=ielts-cmds-$CI_ENVIRONMENT_NAME-api-external-rest
  file_name='cmds-external.json'
elif [ "$5" == "inspera" ]; then
  echo "inside inspera $5"
  rest_api_name=ielts-cmds-$CI_ENVIRONMENT_NAME-api-inspera-rest
  file_name='cmds-inspera.json'
elif [ "$5" == "ca" ]; then
  echo "inside ca $5"
  rest_api_name=ielts-cmds-$CI_ENVIRONMENT_NAME-api-api-ca-legacy
  file_name='cmds-ca.json'
elif [ "$5" == "product-ui" ]; then
  echo "inside product-ui $5"
  rest_api_name=ielts-cmds-$CI_ENVIRONMENT_NAME-api-product-ui-rest
  file_name='cmds-product-ui.json'
elif [ "$5" == "generic-reference-ui" ]; then
  echo "inside generic-reference-ui $5"
  rest_api_name=ielts-cmds-$CI_ENVIRONMENT_NAME-api-generic-reference-ui-rest
  file_name='cmds-generic-reference-ui.json'
	echo "inside product-ui $5";
	rest_api_name=ielts-cmds-$CI_ENVIRONMENT_NAME-api-product-ui-rest;
    file_name='cmds-product-ui.json'
elif [ "$5" == "country-territory-ui" ]; then
	echo "inside country-territory-ui $5";
	rest_api_name=ielts-cmds-$CI_ENVIRONMENT_NAME-api-country-territory-ui-rest;
    file_name='cmds-country-territory-ui.json'
else
  echo "inside Ui $5"
  rest_api_name=ielts-cmds-$CI_ENVIRONMENT_NAME-api-ui-rest
  file_name='cmds-ui.json'

fi

echo "rest_api_name  == $rest_api_name"
echo "file_name  == $file_name"

#Import API
echo "Import Swagger RestAPI"
if [ "$5" == "external" ]; then
  aws apigateway put-rest-api --rest-api-id $apigateway_id --mode overwrite --body 'file://cmds-external.json'
elif [ "$5" == "inspera" ]; then
  aws apigateway put-rest-api --rest-api-id $apigateway_id --mode merge --body 'file://cmds-inspera.json'
elif [ "$5" == "ca" ]; then
  aws apigateway put-rest-api --rest-api-id $apigateway_id --mode merge --body 'file://cmds-ca.json'
elif [ "$5" == "generic-reference-ui" ]; then
  echo "gateway id $apigateway_id"
  ### To get base base of existing item[1] of generic-reference-ui api-gateway
  response_generic_reference_ui_base_path=$(aws apigateway get-base-path-mappings --domain-name $api_domain_name --query items[1].basePath)
  generic_reference_ui_base_path=cache-generic-ref
  aws apigateway put-rest-api --rest-api-id $apigateway_id --mode overwrite --body 'file://cmds-generic-reference-ui.json'
elif [ "$5" == "product-ui" ]; then
  echo "gateway id $apigateway_id"
  ### To get base base of existing item[1] of product-ui api-gateway
  respons_product_ui_base_path=$(aws apigateway get-base-path-mappings --domain-name $api_domain_name --query items[1].basePath)
  product_ui_base_path=cache-product
  aws apigateway put-rest-api --rest-api-id $apigateway_id --mode overwrite --body 'file://cmds-product-ui.json'
elif [ "$5" == "country-territory-ui" ]; then
  echo "gateway id $apigateway_id"
  response_country_territory_ui_base_path=$(aws apigateway get-base-path-mappings --domain-name $api_domain_name --query items[1].basePath)
  country_territory_ui_base_path=cache-country-territory
  aws apigateway put-rest-api --rest-api-id $apigateway_id --mode overwrite --body 'file://cmds-country-territory-ui.json'
else
  aws apigateway put-rest-api --rest-api-id $apigateway_id --mode overwrite --body 'file://cmds-ui.json'
fi

#Create deployment stage
echo "Create deployment stage"
echo "$apigateway_id"
echo "$CI_ENVIRONMENT_NAME"
echo "$keyvalues"
aws apigateway create-deployment --rest-api-id $apigateway_id --stage-name ${CI_ENVIRONMENT_NAME} --variables $keyvalues

#Validate whether base mapping already exists
echo "Validate whether base mapping already exists"
response=$(aws apigateway get-base-path-mappings --domain-name $api_domain_name --query items[0].stage)

echo "If base mapping doesnot exists create otherwise ignore "$response
if [ "$response" == "null" ]; then
  echo "base mapping does not exists, creating base mapping"
  aws apigateway create-base-path-mapping --domain-name $api_domain_name --rest-api-id $apigateway_id --stage ${CI_ENVIRONMENT_NAME}
  if [ "$respons_product_ui_base_path" == "null" ]; then
    aws apigateway create-base-path-mapping --domain-name $api_domain_name --rest-api-id $apigateway_id --stage ${CI_ENVIRONMENT_NAME} --base-path $product_ui_base_path
  fi
  echo "base mapping already exists"
else
  if [ "$response_generic_reference_ui_base_path" == "null" ]; then
    aws apigateway create-base-path-mapping --domain-name $api_domain_name --rest-api-id $apigateway_id --stage ${CI_ENVIRONMENT_NAME} --base-path $generic_reference_ui_base_path
  fi
  if [ "$response_country_territory_ui_base_path" == "null" ]; then
    aws apigateway create-base-path-mapping --domain-name $api_domain_name --rest-api-id $apigateway_id --stage ${CI_ENVIRONMENT_NAME} --base-path $country_territory_ui_base_path
  fi
  echo "base mapping already exists"
fi

#Attach WAF to API gateway stage
resourceArn=arn:aws:apigateway:${AWS_DEFAULT_REGION}::/restapis/$apigateway_id/stages/${CI_ENVIRONMENT_NAME}
echo "Resource arn : $resourceArn"
echo "Web acl id : $web_acl_regional"
aws wafv2 associate-web-acl --web-acl-arn $web_acl_regional --resource-arn $resourceArn --region ${AWS_DEFAULT_REGION}

#Update cloud watch logging
echo "Update cloud watch logging "
aws apigateway update-stage --rest-api-id $apigateway_id --stage-name ${CI_ENVIRONMENT_NAME} --patch-operations op=replace,path=/*/*/logging/loglevel,value=INFO op=replace,path=/*/*/logging/dataTrace,value=true op=replace,path=/accessLogSettings/destinationArn,value=$apigateway_accesslog_destination_arn op=replace,path=/accessLogSettings/format,value=\''{​​​​​"requestId":"$context.requestId","ip":"$context.identity.sourceIp","caller":"$context.identity.caller","user":"$context.identity.user","requestTime":"$context.requestTime","httpMethod":"$context.httpMethod","resourcePath":"$context.resourcePath","status":"$context.status","protocol":"$context.protocol","responseLength":"$context.responseLength"}'\'

#Update rest api name
echo "Update rest api name"
aws apigateway update-rest-api --rest-api-id $apigateway_id --patch-operations op=replace,path=/name,value=$rest_api_name
