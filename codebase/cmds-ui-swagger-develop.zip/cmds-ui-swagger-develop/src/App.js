import React from "react"; 
import { Router, Switch, Route } from "react-router-dom";

import PrivateRoute from "./components/PrivateRoute";
import Loading from "./components/Loading";
import NavBar from "./components/NavBar/NavBar";
import SwaggerContent from "./views/SwaggerContent/SwaggerContent";
import Error from "./views/Error/Error";
import Home from "./views/Home/Home";
import { useAuth0 } from "./react-auth0-spa";
import history from "./utils/history";
import Footer from './components/Footer/Footer';

// styles
import "./App.css";

// fontawesome
import initFontAwesome from "./utils/initFontAwesome";
initFontAwesome();

const App = () => {
  const { loading } = useAuth0();

  if (loading) {
    return <Loading />;
  }
  return (
    <Router history={history}>
      <div id="app" className="application d-flex flex-column h-100">
        <NavBar />
        <div className="content">
          <Switch>
            <PrivateRoute path="/swagger-content" component={SwaggerContent} />
            {/* <PrivateRoute path="/swagger-content" component={Home} /> */}
            <Route path="/error/email-verification" component={Error} />
            <Route path="/" component={Home} />
          </Switch>
        </div>
        <Footer />
      </div>
    </Router>
  );
};

// http://localhost:3000/?supportSignUp=true&supportForgotPassword=true&message=Your%20email%20was%20verified.%20You%20can%20continue%20using%20the%20application.&success=true&code=success#
export default App;
