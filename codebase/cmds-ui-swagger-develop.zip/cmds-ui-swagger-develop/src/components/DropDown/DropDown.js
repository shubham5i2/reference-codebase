import './DropDown.css';
import { Dropdown, DropdownMenu, DropdownToggle } from 'reactstrap';
import React, { useState, useEffect } from 'react';

const DropDown = props => {

    const [displayName, setDisplayName] = useState(props.envNames[0] ? props.envNames[0] : "-------");

    const [dropdownOpen, setDropdownOpen] = useState(false);

    useEffect(() => {
        if (!props.envNames || props.envNames.length < 1) {
            console.error("envNames to be passed as props in Array of string");
        }

        if (!props.onchange || typeof props.onchange !== "function") {
            console.error("onChange to be passed as props as function");
        }

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);



    const toggle = () => {
        setDropdownOpen(prevState => !prevState);
    }

    const selectedItem = (index) => {
        toggle();
        props.onchange(props.envNames[index]);
        setDisplayName(props.envNames[index]);
    };


    const dropDownList = props.envNames && props.envNames.map((item, index) => {
        return (
            <div key={index} className="each-dropdown-item" onClick={e => selectedItem(index)}>{item}</div>
        )

    })

    return (
        <div className="dropdown-container">
            <h6>Environment</h6>
            <Dropdown isOpen={dropdownOpen} toggle={toggle}>
                <DropdownToggle
                    tag="div"
                    data-toggle="dropdown"
                    caret
                    aria-expanded={dropdownOpen}
                >
                    {displayName}
                </DropdownToggle>
                <DropdownMenu>
                    {dropDownList}
                </DropdownMenu>
            </Dropdown>
        </div>
    );
}


export default DropDown;