import React from "react";
import './Footer.css';
import idp from "../../assets/idp.svg";
import ca from "../../assets/CA.svg";
import bc from "../../assets/bc.png";

const Footer = () => (
  <div className="footer">
    <h2 className="footer-title">Partners</h2>
    <div className="partners-list">
      <img src={idp} className="partner-logo" alt="IDP"></img>
      <img src={ca} className="partner-logo" alt="CA"></img>
      <img src={bc} className="partner-logo" alt="BC"></img>
    </div>
    <div className="bottom-line"></div>
  </div>
);

export default Footer;
