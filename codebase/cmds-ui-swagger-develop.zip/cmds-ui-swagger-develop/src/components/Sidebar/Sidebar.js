import React, { useState } from 'react';
import APILink from '../ApiLinkHandler/ApiLinkHandler';
import DropDown from "../DropDown/DropDown";
import './Sidebar.css';

const Sidebar = props => {
  const [selectedDoc, setSelectedDoc] = useState(props.definitionList[0].name);
  let apiLinks = []
  for (let i = 0; i < props.definitionList.length; i++) {
    let selected = false
    if (selectedDoc === props.definitionList[i].name) {
      selected = true

    }
    apiLinks.push(
      <APILink
        key={i}
        selected={selected}
        apiLinkData={props.definitionList[i]}
        updateDefinitionLink={(name, apilink) => { setUpdatedDocument(name, apilink) }}
      />
    )
  }

  const selectedEnv = (env) => {
    props.onChangeEnv(env);
  }

  function setUpdatedDocument(name, apilink) {
    setSelectedDoc(name)
    props.updateDefinitionLink(apilink)
  }
  return (
    <div className="side-bar">
      <div className="side-bar-body">
        <DropDown className="dropdown-toggles" envNames={props.envNames} onchange={selectedEnv} />
        <br></br>
        <h2>API DOCS</h2>
        {apiLinks}
      </div>
    </div>
  )
}

export default Sidebar;