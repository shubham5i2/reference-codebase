import React from 'react';
import './ApiLinkHandler.css'
const APILink = props => {
    let name = props.apiLinkData.name
    let apiLink = props.apiLinkData.url
    let apilink_class = props.selected ? "api-link hightlight":"api-link"
    function handleClick() {
      props.updateDefinitionLink(name,apiLink)
    }

  return (  
    <div className={apilink_class} onClick={() => handleClick()}>
      {name}
    </div>
  )
}

export default APILink;