import { default as devCmdsExternal } from "./dev/cmds-external.json";
import { default as devCmdsEvents } from "./dev/cmds-events.json";
import { default as devCmdsUI } from "./dev/cmds-ui.json";
import { default as devCmdsWebSocket } from "./dev/cmds-ui-websocket.json";
import { default as devOrs } from "./dev/ors.json";
import { default as devCmdsInspera } from "./dev/cmds-inspera.json";
import { default as devLegacyAdaptor } from "./dev/legacy_adaptor.json";

import { default as designCmdsExternal } from "./design/cmds-external.json";
import { default as designCmdsEvents } from "./design/cmds-events.json";
import { default as designCmdsUI } from "./design/cmds-ui.json";
import { default as designCmdsWebSocket } from "./design/cmds-ui-websocket.json";
import { default as designOrs } from "./design/ors.json";
import { default as designCmdsInspera } from "./design/cmds-inspera.json";
import { default as designLegacyAdaptor } from "./design/legacy_adaptor.json";

import { default as draftCmdsExternal } from "./draft/cmds-external.json";
import { default as draftCmdsEvents } from "./draft/cmds-events.json";
import { default as draftCmdsUI } from "./draft/cmds-ui.json";
import { default as draftOrs } from "./draft/ors.json";
import { default as draftCmdsInspera } from "./draft/cmds-inspera.json";

import { default as QACmdsExternal } from "./qa/cmds-external.json";
import { default as QACmdsEvents } from "./qa/cmds-events.json";
import { default as QACmdsUI } from "./qa/cmds-ui.json";
import { default as QAOrs } from "./qa/ors.json";
import { default as QAInspera } from "./qa/cmds-inspera.json";

import { default as prodCmdsExternal } from "./prod/cmds-external.json";
import { default as prodCmdsEvents } from "./prod/cmds-events.json";
import { default as prodCmdsUI } from "./prod/cmds-ui.json";
import { default as prodOrs } from "./prod/ors.json";

import { default as integrationCmdsExternal } from "./integration/cmds-external.json";
import { default as integrationCmdsEvents } from "./integration/cmds-events.json";
import { default as integrationCmdsUI } from "./integration/cmds-ui.json";
import { default as integrationOrs } from "./integration/ors.json";
import { default as integrationInspera } from "./integration/cmds-inspera.json";

const swagger = {
  envNames: ["Development", "Design", "Draft", "Integration-defs"],
  envList: {
    Development: [
      {
        name: "CMDS-External",
        url: devCmdsExternal,
      },
      {
        name: "CMDS-Events",
        url: devCmdsEvents,
      },
      {
        name: "CMDS-UI",
        url: devCmdsUI,
      },
      {
          name: "CMDS-WEB-SOCKET",
          url: devCmdsWebSocket,
      },
      {
        name: "ORS",
        url: devOrs,
      },
      {
        name: "CMDS-Inspera",
        url: devCmdsInspera,
      },
      {
          name: "Legacy Adaptor",
          url: devLegacyAdaptor,
      }
    ],
    Design: [
          {
            name: "CMDS-External",
            url: designCmdsExternal,
          },
          {
            name: "CMDS-Events",
            url: designCmdsEvents,
          },
          {
            name: "CMDS-UI",
            url: designCmdsUI,
          },
          {
              name: "CMDS-WEB-SOCKET",
              url: designCmdsWebSocket,
          },
          {
            name: "ORS",
            url: designOrs,
          },
          {
            name: "CMDS-Inspera",
            url: designCmdsInspera,
          },
          {
            name: "Legacy Adaptor",
            url: designLegacyAdaptor,
          }
    ],
    QA: [
      {
        name: "CMDS-External",
        url: QACmdsExternal,
      },
      {
        name: "CMDS-Events",
        url: QACmdsEvents,
      },
      {
        name: "CMDS-UI",
        url: QACmdsUI,
      },
      {
        name: "ORS",
        url: QAOrs,
      },
      {
        name: "Inspera",
        url: QAInspera,
      }
    ],
    Production: [
      {
        name: "CMDS-External",
        url: prodCmdsExternal,
      },
      {
        name: "CMDS-Events",
        url: prodCmdsEvents,
      },
      {
        name: "CMDS-UI",
        url: prodCmdsUI,
      },
      {
        name: "ORS",
        url: prodOrs,
      },
    ],
    Draft: [
      {
        name: "CMDS-External",
        url: draftCmdsExternal,
      },
      {
        name: "CMDS-Events",
        url: draftCmdsEvents,
      },
      {
        name: "CMDS-UI",
        url: draftCmdsUI,
      },
      {
        name: "ORS",
        url: draftOrs,
      },
      {
        name: "CMDS-Inspera",
        url: draftCmdsInspera,
      }
    ],
    "Integration-defs": [
      {
        name: "CMDS-External",
        url: integrationCmdsExternal,
      },
      {
        name: "CMDS-Events",
        url: integrationCmdsEvents,
      },
      {
        name: "CMDS-UI",
        url: integrationCmdsUI,
      },
      {
        name: "ORS",
        url: integrationOrs,
      },
      {
        name: "CMDS-Inspera",
        url: integrationInspera,
      }
    ],
  },
};

export default swagger;
