import './Error.css';
import React from 'react';
import { CardDeck, Card, CardBody, CardText } from 'reactstrap';

const Error = (props) => {
    // const [isOpen, setIsOpen] = useState(false);
    // const [email, setEmail] = useState("");
    // \w+@(cambridgeassessment|britishcouncil|ielts|idp)+?\.(([com]|[org]|[pl]){2,3})+|\.[uk]{2}
    return (
        <div className="error-container">
            <h1 className="title">Email needs to be verified</h1>
            <div>
                <p>Click the link sent to you in the mail...</p>
                <p>Sometimes link shows <em>error</em> on authorize, Never Mind! Try login to app. again! </p>
                <p>Didn't received an email itself?</p>
            </div>
            {/* <Button color="danger" onClick={toggle} style={{ marginBottom: '1rem' }}>Click here</Button>
            <Collapse isOpen={isOpen}>
                <Card>
                    <InputGroup>
                        <InputGroupAddon addonType="prepend">
                            <InputGroupText>Email Address</InputGroupText>
                        </InputGroupAddon>
                        <Input value={email} onChange={e => setEmail(e.target.value)} placeholder="Email" />
                    </InputGroup>
                </Card>
                <div className="submit-btn">
                    <Button onClick={onSubmit} color="primary">Submit</Button>
                </div>
            </Collapse> */}
            <h5>Contact Administrators</h5>
            <CardDeck className="card-deck-container">
                <Card className="card-container">
                    <CardBody>
                        <h2>Vignesh Pushkaran</h2>
                        <h4>Full stack Engineer</h4>
                        <CardText>pushkaran.v@cambridgeassessment.org.uk</CardText>
                    </CardBody>
                </Card>
                <Card className="card-container">
                    <CardBody>
                        <h2>Jennings Mcenroe</h2>
                        <h4>Full stack Engineer</h4>
                        <CardText>selvaraj.j@cambridgeassessment.org.uk</CardText>
                    </CardBody>
                </Card>
            </CardDeck>
        </div>
    );
}

export default Error;
