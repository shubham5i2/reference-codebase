
import './SwaggerContent.css';
import SwaggerUI from 'swagger-ui';
import React, { useState, useEffect } from 'react'
import Config from '../../utils/organization_config.json';
import Sidebar from '../../components/Sidebar/Sidebar';
import '../../../node_modules/swagger-ui/dist/swagger-ui.css';
import swaggerData from '../../swaggerData';

const organizationConfig = Config.orgData;

const SwaggerContent = () => {


  const [swaggerList, setSwaggerList] = useState(swaggerData.envList.Development);

  //Default development CMDS_EXTERNAL will be selected
  const [definitionLink, setDefinitionLink] = useState(swaggerData.envList.Development[0].url);

  const updateDefinitionLink = (newLink) => {
    setDefinitionLink(newLink);
  }

  const selectedEnv = (env) => {
    setSwaggerList(swaggerData.envList[env]);
  }

  useEffect(() => {
    SwaggerUI({
      domNode: document.getElementById("api-data"),
      spec: definitionLink
    })
  });

  return (
    <div>
      <div className="swagger-container">
        <Sidebar
          organizationConfig={organizationConfig}
          definitionList={swaggerList}
          updateDefinitionLink={updateDefinitionLink}
          envNames={swaggerData.envNames}
          onChangeEnv={selectedEnv}
        />
        <div id="api-data" />
      </div>
    </div>
  );
};

export default SwaggerContent;
