import React from "react";
import './Home.css';
import { useAuth0 } from "../../react-auth0-spa";
import swaggerImage from "../../assets/swagger.png";
import history from "../../utils/history";

const Home = () => {
  const { isAuthenticated } = useAuth0();
  if (isAuthenticated) {
    history.push({ pathname: '/swagger-content' });
  }

  return (
    <div className="home">
      <div className="welcome-msg">
        <h6>Welcome!</h6>
        <p>to IELTS Swagger API Platform</p>
        <img id="swagger-logo" src={swaggerImage} alt="swagger logo"></img>
        <h6>with Open API standard</h6>
        <p>Login, to explore swagger API of CMDS External, Internal and ORS along with environments like
        Production, QA, Develpoment and Draft Version.</p>
      </div>
    </div>
  )
};

export default Home;
