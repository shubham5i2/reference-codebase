#!/bin/bash
file="$1/junit-test.sh"
file2="$1/sonar-valid.sh"
if [ -e "$file" && -e "$file2" ]; then
    echo "Junit and sonar valid exec files exist"
    sleep 5s
else
    echo "copying junit and sonar exec files"
    cp ./junit-test.sh $1
    cp ./sonar-valid.sh $1
    sleep 5s
fi
