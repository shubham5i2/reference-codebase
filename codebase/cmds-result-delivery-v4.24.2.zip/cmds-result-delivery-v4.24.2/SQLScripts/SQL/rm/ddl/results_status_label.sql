-- Table: rd_owner.results_status_label

-- DROP TABLE rd_owner.results_status_label;

CREATE TABLE rd_owner.results_status_label (
    results_status_label_uuid uuid NOT NULL,
    results_status_type_uuid uuid NOT NULL,
    results_status_label character varying(50) NOT NULL,
    results_status_label_code character varying(50) NOT NULL,
    results_status_comment_mandatory boolean NOT NULL,
    effective_from_date date NOT NULL,
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
    created_by character varying(36) NOT NULL,
    created_datetime timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by character varying(36),
    updated_datetime timestamp with time zone,
    concurrency_version integer DEFAULT 0 NOT NULL,
	CONSTRAINT pk_results_status_label PRIMARY KEY (results_status_label_uuid),
	CONSTRAINT fk_01_results_satus_label_results_status_type FOREIGN KEY (results_status_type_uuid)
    REFERENCES rd_owner.results_status_type (results_status_type_uuid)
);

