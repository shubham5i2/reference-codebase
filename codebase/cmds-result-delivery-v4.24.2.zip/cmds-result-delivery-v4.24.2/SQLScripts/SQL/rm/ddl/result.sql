-- Table: rd_owner.result

-- DROP TABLE rd_owner.result;

-- Create Table for result
CREATE TABLE IF NOT EXISTS rd_owner.result (
    result_uuid UUID NOT NULL,
    result_type_uuid UUID NOT NULL,
    booking_uuid UUID NOT NULL,
    result_score NUMERIC(2, 1) NOT NULL,
    trf_number VARCHAR(18),
    cefr_level VARCHAR(32),
    published_time TIMESTAMPTZ NULL,
	results_status_type_uuid uuid NOT NULL,
    results_status_label_uuid uuid NULL,
	status_updated_datetime TIMESTAMPTZ NOT NULL,
	result_status_comment VARCHAR(100),
	absence boolean NULL,
    event_datetime TIMESTAMPTZ NOT NULL,
    updated_datetime TIMESTAMPTZ NOT NULL,
    concurrency_version integer NOT NULL,
    CONSTRAINT pk_result PRIMARY KEY (result_uuid),
    CONSTRAINT uk_01_result_booking_uuid UNIQUE (booking_uuid)
);
