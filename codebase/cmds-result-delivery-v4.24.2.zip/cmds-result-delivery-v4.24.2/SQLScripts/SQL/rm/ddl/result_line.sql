-- Table: rd_owner.result_line

-- DROP TABLE rd_owner.result_line;

-- Create Table for result_line
CREATE TABLE IF NOT EXISTS rd_owner.result_line (
    result_line_uuid UUID NOT NULL,
    result_line_score NUMERIC(2, 1) NOT NULL,
    result_uuid UUID NOT NULL,
    booking_line_uuid UUID NOT NULL,
   product_uuid uuid NOT NULL,
    absence boolean NULL,
    updated_datetime TIMESTAMPTZ NOT NULL,
    CONSTRAINT pk_result_line PRIMARY KEY (result_line_uuid),
    CONSTRAINT fk_01_result_line_result FOREIGN KEY (result_uuid) References rd_owner.result(result_uuid)
);
