-- Create EMUM Type for status

-- DROP TABLE rd_owner.result_delivery;


DO $$ BEGIN CREATE TYPE rd_owner.status AS ENUM (
	'DELIVERED', 'UNDELIVERED', 'DELIVERY_PENDING'
    );
EXCEPTION
WHEN duplicate_object THEN null;
END $$;

-- Creating table for result_delivery
CREATE TABLE IF NOT EXISTS rd_owner.result_delivery(
    result_delivery_uuid UUID NOT NULL,
	transaction_uuid UUID NOT NULL,
    result_uuid UUID NOT NULL,    
	status rd_owner.status NOT NULL,
    system VARCHAR(10) NOT NULL,
	status_updated_datetime TIMESTAMPTZ NOT NULL,
    CONSTRAINT pk_result_delivery PRIMARY KEY (result_delivery_uuid),
    CONSTRAINT fk_01_result_delivery_result FOREIGN KEY (result_uuid ) REFERENCES rd_owner.result (result_uuid) ON UPDATE NO ACTION ON DELETE NO ACTION,
	CONSTRAINT uk_01_result_delivery UNIQUE (result_uuid, system, transaction_uuid)
	);

