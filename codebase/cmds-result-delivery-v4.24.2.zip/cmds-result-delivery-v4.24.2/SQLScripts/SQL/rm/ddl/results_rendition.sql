--Create result rendition

CREATE TABLE IF NOT EXISTS rd_owner.results_rendition(
         results_rendition_uuid UUID NOT NULL,
         result_uuid UUID NOT NULL,
         rendition_type_uuid UUID NOT NULL,
         rendition_file_path character varying(256) NOT NULL,
         rendition_file_version character varying(64) NOT NULL,
         rendition_description character varying(100) NOT NULL,
         updated_datetime TIMESTAMPTZ NOT NULL,
         transaction_uuid UUID NOT NULL,
         CONSTRAINT pk_results_rendition PRIMARY KEY(results_rendition_uuid),
         CONSTRAINT fk_01_results_rendition_result FOREIGN KEY(result_uuid) REFERENCES rd_owner.result (result_uuid),
         CONSTRAINT fk_02_results_rendition_rendition_type FOREIGN KEY(rendition_type_uuid) References rd_owner.rendition_type(rendition_type_uuid),
		 CONSTRAINT uk_01_results_rendition UNIQUE (result_uuid, rendition_type_uuid, rendition_file_path, rendition_file_version)
);  
