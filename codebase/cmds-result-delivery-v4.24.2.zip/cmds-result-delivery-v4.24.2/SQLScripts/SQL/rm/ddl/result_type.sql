
-- DROP TABLE rd_owner.result_type;

-- DROP TYPE rd_owner.result_type_name;

-- Create EMUM Type for result types
DO $$ BEGIN CREATE TYPE rd_owner.result_type_name AS ENUM (
    'NORMAL', 'JAGGED_1', 'EOR', 'JAGGED_2'
    );
EXCEPTION
WHEN duplicate_object THEN null;
END $$;

-- Create Table for result type

CREATE TABLE IF NOT EXISTS rd_owner.result_type
(
    result_type_uuid uuid NOT NULL,
    result_type VARCHAR(50) NOT NULL,
    result_type_code VARCHAR(50) NOT NULL,
    effective_from_date date NOT NULL,
    effective_to_date date NOT NULL DEFAULT '2099-12-31',
    created_by VARCHAR(36) NOT NULL,
    created_datetime timestamp with time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_by VARCHAR(36),
    updated_datetime timestamp with time zone,
    concurrency_version integer NOT NULL DEFAULT 0,
    CONSTRAINT pk_results_type PRIMARY KEY (result_type_uuid)
);


