-- Table: rd_owner.results_status_type

-- DROP TABLE rd_owner.results_status_type;

CREATE TABLE IF NOT EXISTS rd_owner.results_status_type (
    results_status_type_uuid uuid NOT NULL,
    results_status VARCHAR(50) NOT NULL,
    results_status_code VARCHAR(50) NOT NULL,
    effective_from_date date NOT NULL,
    effective_to_date date DEFAULT '2099-12-31' NOT NULL,
    created_by VARCHAR(36) NOT NULL,
    created_datetime timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by VARCHAR(36),
    updated_datetime timestamp with time zone,
    concurrency_version integer DEFAULT 0 NOT NULL,
	CONSTRAINT pk_results_status_type PRIMARY KEY (results_status_type_uuid)
	
);
