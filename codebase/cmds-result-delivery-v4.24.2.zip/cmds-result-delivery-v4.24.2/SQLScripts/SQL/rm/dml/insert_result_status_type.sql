-- DML scripts for results_status_type
	
	
INSERT INTO rd_owner.results_status_type(results_status_type_uuid, results_status, results_status_code, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('3d189282-e531-47f2-aa22-d24eef1d20b6', 
		'Unconfirmed', 
		'UNCONFIRMED', 
		'2020-07-01', 
		'Operations User', 
		NULL, 
		NULL) ON CONFLICT(results_status_type_uuid) DO NOTHING;

INSERT INTO rd_owner.results_status_type(results_status_type_uuid, results_status, results_status_code, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('27c03460-2662-4a63-b1aa-6d158b85c0a5', 
		'Confirmed', 
		'CONFIRMED', 
		'2020-07-01', 
		'Operations User', 
		NULL, 
		NULL) ON CONFLICT(results_status_type_uuid) DO NOTHING;
		
INSERT INTO rd_owner.results_status_type(results_status_type_uuid, results_status, results_status_code, effective_from_date,  created_by, updated_by, updated_datetime)
VALUES ('ac65e5b7-3bcc-4147-baff-827f030dc6c8', 
		'Validated', 
		'VALIDATED', 
		'2020-07-01', 
		'Operations User', 
		NULL, 
		NULL) ON CONFLICT(results_status_type_uuid) DO NOTHING;		
		
INSERT INTO rd_owner.results_status_type(results_status_type_uuid, results_status, results_status_code, effective_from_date,  created_by, updated_by, updated_datetime)
VALUES ('19bdb4b7-74bc-4f3d-b846-eb4a4e8022e6', 
		'Pending Review', 
		'PENDING_REVIEW', 
		'2020-07-01', 
		'Operations User', 
		NULL, 
		NULL) ON CONFLICT(results_status_type_uuid) DO NOTHING;	
		
INSERT INTO rd_owner.results_status_type(results_status_type_uuid, results_status, results_status_code, effective_from_date,  effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('735d2d71-b4a9-47ec-b566-34b2d3015540', 
		'Withheld', 
		'WITHHELD', 
		'2020-07-01', 
		'2099-12-31', 
		'Operations User', 
		NULL, 
		NULL) ON CONFLICT(results_status_type_uuid) DO NOTHING;			

INSERT INTO rd_owner.results_status_type(results_status_type_uuid, results_status, results_status_code, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('57d416a1-57b3-4b72-b24c-d511f1749a79', 
		'Permanently Withheld', 
		'PERMANENTLY_WITHHELD', 
		'2020-07-01', 
		'Operations User', 
		NULL, 
		NULL) ON CONFLICT(results_status_type_uuid) DO NOTHING;	
		
INSERT INTO rd_owner.results_status_type(results_status_type_uuid, results_status, results_status_code, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('e0ae368e-2cfd-4dad-8b6e-2e0809e0ea87', 
		'Absent', 
		'ABSENT', 
		'2020-07-01', 
		'Operations User', 
		NULL, 
		NULL) ON CONFLICT(results_status_type_uuid) DO NOTHING;	

INSERT INTO rd_owner.results_status_type(results_status_type_uuid, results_status, results_status_code, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('1aef5721-71fc-434b-8e42-c2f077753826', 
		'Released', 
		'RELEASED', 
		'2020-07-01', 
		'Operations User', 
		NULL, 
		NULL) ON CONFLICT(results_status_type_uuid) DO NOTHING;	

