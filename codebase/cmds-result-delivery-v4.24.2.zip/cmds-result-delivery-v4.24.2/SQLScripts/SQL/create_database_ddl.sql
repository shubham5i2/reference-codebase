-- Create Database
DROP ROLE IF EXISTS rd_impl_role;
DROP USER IF EXISTS rd_user;


CREATE DATABASE rd
    WITH
    OWNER = postgres
    ENCODING = 'UTF8'
    CONNECTION LIMIT = -1;
