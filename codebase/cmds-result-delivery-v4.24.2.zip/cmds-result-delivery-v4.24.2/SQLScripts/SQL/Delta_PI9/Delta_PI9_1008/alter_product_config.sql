-- Alter Script for Removing photo_type column

ALTER TABLE rd_owner.product_config DROP COLUMN photo_type;