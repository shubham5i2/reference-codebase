UPDATE rd_owner.product SET product_characteristics ='{"characteristics": ["IOL", "SELT"],"RoAutoAccepted": ["FALSE"]}' WHERE product_uuid ='4ca26fd2-5216-4e9a-ba08-89bb94599778';

UPDATE rd_owner.product SET product_characteristics ='{"characteristics": ["IOL", "SELT"],"RoAutoAccepted": ["FALSE"]}' WHERE product_uuid ='0b0e3eb3-7929-4e38-bc63-dea6ffe6def8';

UPDATE rd_owner.product SET product_characteristics ='{"characteristics": ["IOL", "SELT","SSR"],"RoAutoAccepted": ["FALSE"]}' WHERE product_uuid ='2948e48b-519b-484e-aed9-93a30a8a9485';

UPDATE rd_owner.product SET product_characteristics ='{"characteristics": ["IOL", "SELT","SSR"],"RoAutoAccepted": ["FALSE"]}' WHERE product_uuid ='58c171e7-6789-498c-9e2e-e26f4bf8c90c';

UPDATE rd_owner.product SET product_characteristics ='{"characteristics": ["IOC", "SELT"],"RoAutoAccepted": ["FALSE"]}' WHERE product_uuid ='6d04f596-22f2-49c4-9d47-85b167b8ca6f';

UPDATE rd_owner.product SET product_characteristics ='{"characteristics": ["IOC", "SELT"],"RoAutoAccepted": ["FALSE"]}' WHERE product_uuid ='54b9d8df-c07a-4cb4-b397-adc4faa87c3f';

UPDATE rd_owner.product SET product_characteristics ='{"characteristics": ["IOC", "SELT","SSR"],"RoAutoAccepted": ["FALSE"]}' WHERE product_uuid ='de58e8e0-39c6-4c54-b62e-40cacbc6c56d';

UPDATE rd_owner.product SET product_characteristics ='{"characteristics": ["IOC", "SELT","SSR"],"RoAutoAccepted": ["FALSE"]}' WHERE product_uuid ='fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db';
