--Script to alter the photo_type_code type and add new types

ALTER type rd_owner.photo_type_code ADD VALUE 'TT_ID_HR_S_IAM';

ALTER type rd_owner.photo_type_code ADD VALUE 'TT_P_HR_S_IAM';