--DML scripts for product_config UKVI data 

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('b97129a8-5462-46e1-8db4-bbe22e3d54fb',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        '4ca26fd2-5216-4e9a-ba08-89bb94599778',
		'IDP',
		'UKVI_TRF_IOL_AC',
		'ACADEMIC');
		
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('8ca2de87-a197-4b91-a736-a7214d87c724',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        '0b0e3eb3-7929-4e38-bc63-dea6ffe6def8',
		'IDP',
		'UKVI_TRF_IOL_GT',
		'GENERAL TRAINING');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('ad5f5016-edb1-4971-aa97-ada0a1a80112',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        '4ca26fd2-5216-4e9a-ba08-89bb94599778',
		'BC',
		'UKVI_TRF_IOL_AC',
		'ACADEMIC');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('56b468ef-f0bd-48df-b098-fba1ea876353',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        '0b0e3eb3-7929-4e38-bc63-dea6ffe6def8',
		'BC',
		'UKVI_TRF_IOL_GT',
		'GENERAL TRAINING');
		
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('0fc91522-a6b7-439b-854f-fba1a4484ab3',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        '4ca26fd2-5216-4e9a-ba08-89bb94599778',
		'IDP',
		'UKVI_ETRF_IOL_AC',
		'ACADEMIC');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('f71134b9-9c78-47dd-a37b-8aca87ef88ef',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        '0b0e3eb3-7929-4e38-bc63-dea6ffe6def8',
		'IDP',
		'UKVI_ETRF_IOL_GT',
		'GENERAL TRAINING');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('607c6a9a-4f99-4f74-b075-dfd72715f90e',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        '4ca26fd2-5216-4e9a-ba08-89bb94599778',
		'BC',
		'UKVI_ETRF_IOL_AC',
		'ACADEMIC');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('3eff74b3-8f94-4b5c-ad73-2f0c8b1654f7',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        '0b0e3eb3-7929-4e38-bc63-dea6ffe6def8',
		'BC',
		'UKVI_ETRF_IOL_GT',
		'GENERAL TRAINING');