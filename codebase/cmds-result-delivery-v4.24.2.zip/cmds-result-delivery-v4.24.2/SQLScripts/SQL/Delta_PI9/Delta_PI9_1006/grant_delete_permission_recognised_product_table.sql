
GRANT delete ON table rd_owner.recognised_product TO rd_impl_role;