update  rd_owner.product_config set product_uuid='3e81e94b-8b6a-42b5-970c-b141f9d195a3'
where product_config_uuid='50ecccf8-6488-4d8c-a14c-1e4fde394aad'