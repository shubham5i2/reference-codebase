--Script to add SSR Photo Type in photo_type table 

INSERT INTO rd_owner.test_taker_photo_type(
	photo_type_uuid, photo_type_code, photo_type_description, updated_datetime, concurrency_version, created_by)
	VALUES ('5a8ca226-7e07-4819-9af0-7dae099a26c2', 'SSR_ORIGINAL_BOOKING_TRF', 'TT Certificate Photo from the original booking', NULL, '1', 'Operations User')ON CONFLICT(photo_type_uuid) DO NOTHING;
