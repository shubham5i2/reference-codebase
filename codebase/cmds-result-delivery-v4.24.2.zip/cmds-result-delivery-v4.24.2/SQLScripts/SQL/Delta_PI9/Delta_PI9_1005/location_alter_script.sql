ALTER TABLE rd_owner.location rename column location_type_code to location_type;

ALTER TABLE rd_owner.location add column status varchar(50);