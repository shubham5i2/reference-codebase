-- Query to update High Resolution photo type having IOC product 

UPDATE rd_owner.test_taker_photo SET photo_category='Certificate' where photo_type_uuid='a101702b-d8dd-4bcd-bcc5-a39cc6cf6fc5' AND booking_uuid in (select b.booking_uuid from rd_owner.test_taker_photo ttp, rd_owner.booking b, rd_owner.product pr where ttp.booking_uuid = b.booking_uuid and b.product_uuid = pr.product_uuid and pr.product_uuid IN ('fdbacec5-e80a-4710-b3de-7d5f310b1466','cf9a05e9-2679-42da-b7d2-b34ea3e0724e','cb7cd48c-5e79-4a28-8104-e0bcd8e39999','c37e2fab-898d-46d4-a61b-17f24bb29e83'));
