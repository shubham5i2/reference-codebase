--DML scripts for product_config SSR data 

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , photo_type , template_name , report_module_name)
VALUES ('e6cf83e0-d839-4227-b9a0-e43398232bb4',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        '6d28d524-472d-4d53-8fd9-dc7c4bb5325d',
		'IDP',
		'SSR_ORIGINAL_BOOKING_TRF',
		'TRF_SSR_IOL_AC',
		'ACADEMIC');
		
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , photo_type , template_name , report_module_name)
VALUES ('b8739447-2f2f-4cd0-97fa-994678dc40c8',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        '7b1d8d96-c314-40cd-a61c-2b681086a458',
		'IDP',
		'SSR_ORIGINAL_BOOKING_TRF',
		'TRF_SSR_IOL_GT',
		'GENERAL TRAINING');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , photo_type , template_name , report_module_name)
VALUES ('268eb792-454f-4b05-90ae-25d40cc7b2c3',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        '6d28d524-472d-4d53-8fd9-dc7c4bb5325d',
		'BC',
		'SSR_ORIGINAL_BOOKING_TRF',
		'TRF_SSR_IOL_AC',
		'ACADEMIC');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , photo_type , template_name , report_module_name)
VALUES ('4c0b23e6-77a2-4d6b-97e5-9bcf2566c2b2',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        '7b1d8d96-c314-40cd-a61c-2b681086a458',
		'BC',
		'SSR_ORIGINAL_BOOKING_TRF',
		'TRF_SSR_IOL_GT',
		'GENERAL TRAINING');
		
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , photo_type , template_name , report_module_name)
VALUES ('13a99930-7bbd-4397-9b42-ab5332d451b4',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        '6d28d524-472d-4d53-8fd9-dc7c4bb5325d',
		'IDP',
		'SSR_ORIGINAL_BOOKING_TRF',
		'ETRF_SSR_IOL_AC',
		'ACADEMIC');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , photo_type , template_name , report_module_name)
VALUES ('15d01317-7b75-411e-86de-27ae8ed0f559',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        '7b1d8d96-c314-40cd-a61c-2b681086a458',
		'IDP',
		'SSR_ORIGINAL_BOOKING_TRF',
		'ETRF_SSR_IOL_GT',
		'GENERAL TRAINING');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , photo_type , template_name , report_module_name)
VALUES ('8ded190b-fcbf-4311-8234-e0980c22d4b9',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        '6d28d524-472d-4d53-8fd9-dc7c4bb5325d',
		'BC',
		'SSR_ORIGINAL_BOOKING_TRF',
		'ETRF_SSR_IOL_AC',
		'ACADEMIC');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , photo_type , template_name , report_module_name)
VALUES ('0808a01e-e1a0-448a-9083-89051464c3cd',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        '7b1d8d96-c314-40cd-a61c-2b681086a458',
		'BC',
		'SSR_ORIGINAL_BOOKING_TRF',
		'ETRF_SSR_IOL_GT',
		'GENERAL TRAINING');
------
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , photo_type , template_name , report_module_name)
VALUES ('104760a2-aa05-414c-a76d-08e61d93c17e',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        'cb7cd48c-5e79-4a28-8104-e0bcd8e39999',
		'IDP',
		'SSR_ORIGINAL_BOOKING_TRF',
		'TRF_SSR_CD_AC',
		'ACADEMIC');
		
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , photo_type , template_name , report_module_name)
VALUES ('cedd6284-51e9-4ec5-98f8-7466f3c59876',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        'c37e2fab-898d-46d4-a61b-17f24bb29e83',
		'BC',
		'SSR_ORIGINAL_BOOKING_TRF',
		'TRF_SSR_CD_GT',
		'GENERAL TRAINING');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , photo_type , template_name , report_module_name)
VALUES ('dc6dbfd1-ca9e-47bb-9700-d0b42a3abc52',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        'cb7cd48c-5e79-4a28-8104-e0bcd8e39999',
		'BC',
		'SSR_ORIGINAL_BOOKING_TRF',
		'TRF_SSR_CD_AC',
		'ACADEMIC');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , photo_type , template_name , report_module_name)
VALUES ('ed7ade7d-e73e-46af-8bd1-9c9055a923e1',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        'c37e2fab-898d-46d4-a61b-17f24bb29e83',
		'IDP',
		'SSR_ORIGINAL_BOOKING_TRF',
		'TRF_SSR_CD_GT',
		'GENERAL TRAINING');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , photo_type , template_name , report_module_name)
VALUES ('2fa14930-3db2-4c55-9675-d8a8552c23b1',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        'cb7cd48c-5e79-4a28-8104-e0bcd8e39999',
		'IDP',
		'SSR_ORIGINAL_BOOKING_TRF',
		'ETRF_SSR_CD_AC',
		'ACADEMIC');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , photo_type , template_name , report_module_name)
VALUES ('26bc07d4-4808-4769-ac17-3057bd0055a1',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        'c37e2fab-898d-46d4-a61b-17f24bb29e83',
		'IDP',
		'SSR_ORIGINAL_BOOKING_TRF',
		'ETRF_SSR_CD_GT',
		'GENERAL TRAINING');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , photo_type , template_name , report_module_name)
VALUES ('573ef18e-5591-41fa-a40b-19100ac5799a',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        'cb7cd48c-5e79-4a28-8104-e0bcd8e39999',
		'BC',
		'SSR_ORIGINAL_BOOKING_TRF',
		'ETRF_SSR_CD_AC',
		'ACADEMIC');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , photo_type , template_name , report_module_name)
VALUES ('e4e0feba-81bb-4e3a-8691-c7a4ae1f20e7',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        'c37e2fab-898d-46d4-a61b-17f24bb29e83',
		'BC',
		'SSR_ORIGINAL_BOOKING_TRF',
		'ETRF_SSR_CD_GT',
		'GENERAL TRAINING');