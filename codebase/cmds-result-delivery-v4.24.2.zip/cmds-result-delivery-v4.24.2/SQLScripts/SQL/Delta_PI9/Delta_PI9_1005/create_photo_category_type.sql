-- Create Type for test_taker_photo table

CREATE TYPE rd_owner."photo_category" AS ENUM
 ('Certificate','Other');
	