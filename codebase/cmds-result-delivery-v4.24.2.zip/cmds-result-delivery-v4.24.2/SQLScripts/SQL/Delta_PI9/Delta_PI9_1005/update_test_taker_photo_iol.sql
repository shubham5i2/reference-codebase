-- Query to update Low Resolution photo type having IOL product 


UPDATE rd_owner.test_taker_photo SET photo_category='Certificate' where photo_type_uuid='f6c594bb-6dc3-438b-8e94-c87edaa47cd6' AND booking_uuid in (select b.booking_uuid from rd_owner.test_taker_photo ttp, rd_owner.booking b, rd_owner.product pr where ttp.booking_uuid = b.booking_uuid and b.product_uuid = pr.product_uuid and pr.product_uuid IN ('d96eece2-1d7c-495a-a754-6b523b710a82','3e81e94b-8b6a-42b5-970c-b141f9d195a3','6d28d524-472d-4d53-8fd9-dc7c4bb5325d','7b1d8d96-c314-40cd-a61c-2b681086a458'));
