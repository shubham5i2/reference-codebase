--Script to alter the photo_type_code type and add new type 

ALTER type rd_owner.photo_type_code ADD VALUE 'SSR_ORIGINAL_BOOKING_TRF' AFTER 'TT_ID_S_WC' ;