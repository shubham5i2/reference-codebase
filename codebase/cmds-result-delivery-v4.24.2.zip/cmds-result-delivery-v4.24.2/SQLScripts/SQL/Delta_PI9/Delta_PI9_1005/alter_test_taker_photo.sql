--Alter test_taker_photo table

ALTER TABLE rd_owner.test_taker_photo ADD COLUMN IF NOT EXISTS 
"photo_category" rd_owner.photo_category DEFAULT NULL;
   








