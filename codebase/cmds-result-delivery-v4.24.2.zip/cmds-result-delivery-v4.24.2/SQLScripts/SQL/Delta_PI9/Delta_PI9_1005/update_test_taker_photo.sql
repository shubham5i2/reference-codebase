-- Query to update remaining records with Other

UPDATE rd_owner.test_taker_photo SET photo_category='Other' where photo_category is null;
