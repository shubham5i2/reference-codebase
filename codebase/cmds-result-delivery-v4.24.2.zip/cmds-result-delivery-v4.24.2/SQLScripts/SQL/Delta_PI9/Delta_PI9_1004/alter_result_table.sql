-- Alter script for result table 

alter table rd_owner.result add column administrator_comments VARCHAR(400) NULL;