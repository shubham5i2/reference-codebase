-- IELTS Result Delivery SQL scripts
\c rd

\i create_schema.sql
\i add_uuid_extension.sql

-- Booking DDL scripts
\ir booking//ddl//booking.sql
\ir booking//ddl//booking_line.sql

-- location DDL scripts
\ir location//ddl//location.sql
\ir location//ddl//organisation_type.sql

-- location DML scripts
\ir location//dml//insert_organisation_type.sql

-- Module DDL scripts
\ir moduleType//ddl//module_type.sql

-- Module DML scripts
\ir moduleType//dml//insert_module_type.sql

-- Product DDL scripts
\ir product//ddl//product.sql

-- Product DML scripts
\ir product//dml//insert_product.sql

-- RO DDL scripts
\ir  ro//ddl//recognising_organisation.sql
\ir  ro//ddl//recognised_product.sql
\ir  ro//ddl//linked_recognising_organisation.sql

-- Rendition_Type DDL scripts
\ir rendition//ddl//rendition_type.sql

-- Rendition_Type DML scripts
\ir rendition//dml//insert_rendition_type.sql

-- Result DDL scripts
\ir  rm//ddl//result_type.sql
\ir  rm//ddl//results_status_type.sql
\ir  rm//ddl//results_status_label.sql
\ir  rm//ddl//result.sql
\ir  rm//ddl//result_line.sql
\ir  rm//ddl//result_delivery.sql
\ir  rm//ddl//results_rendition.sql
\ir  rm//ddl//result_trf_print_status.sql

-- Result DML scripts
\ir rm//dml//insert_result_type.sql
\ir rm//dml//insert_result_status_type.sql
\ir rm//dml//insert_results_status_label.sql

-- Selection DDL scripts
\ir selection//ddl//selection.sql
\ir selection//ddl//minimum_score.sql

-- Gender DML and DDL scripts
\ir gender//ddl/gender.sql
\ir gender//dml/insert_gender.sql

-- Country DML and DDL scripts
\ir country//ddl/country.sql
\ir country//dml/insert_country.sql

-- Language DML and DDL scripts
\ir language//ddl/language.sql
\ir language//dml/insert_language.sql

-- Nationality DML and DDL scripts
\ir nationality//ddl/nationality.sql
\ir nationality//dml/insert_nationality.sql

-- TTPhoto DDL scripts
\ir ttPhoto//ddl//test_taker_photo.sql
\ir ttPhoto//ddl//test_taker_photo_type.sql

-- TTPhoto DML scripts
\ir ttPhoto//dml//insert_test_taker_photo_type.sql

-- Territory DDL scripts
\ir  territory//ddl//territory.sql

-- Territory DML scripts
\ir territory//dml//insert_territory.sql

-- RO Address DDL scripts
\ir  ro//ddl//recognising_organisation_address.sql

-- Address Type DDL and DML scripts
\ir  ro//ddl//address_type.sql
\ir  ro//dml//insert_address_type.sql

-- Result TRF Print Status DDL scripts
\ir  rm//ddl//result_trf_print_status.sql

-- Unverified Address DDL scripts
\ir  ro//ddl//unverified_address.sql

--Report Delivery Requested DDL scripts
\ir  rm//ddl//report_delivery_requested.sql

--Outbox DDL scripts
\ir  outbox//ddl//create_outbox_event.sql
\ir  outbox//ddl//create_outbox_event_attribute.sql

-- Product_Config DDL and DML scripts
\ir product_config//ddl//create_product_config.sql
\ir product_config//dml//insert_product_config.sql

-- User_Group_Hierarchy DDL and DML Scripts
\ir user//ddl//user_group_hierarchy.sql
\ir user//dml//insert_user_group_hierarchy.sql

-- Booking Link DDL script
\ir booking//ddl//booking_link.sql


