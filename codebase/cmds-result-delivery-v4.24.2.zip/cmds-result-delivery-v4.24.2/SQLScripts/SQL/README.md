**Pre-requisites:**

1) The DB/role/user/schema should not be present already so that this will create everything from scratch

**Steps to execute RD DB Scripts:**

1) Go to cmds-rd repository in develop branch (https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/-/tree/develop/)

2) Go to SQLScripts folder and download the entire folder (https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/-/tree/develop/SQLScripts)

3) Connect to RD DB Instance using below command (Provide password when prompted)

    `psql -h <<HOST>> -U postgres`

4) Executing file create_database_ddl.sql will drop existing rd database and recreate it.This should be one time run.
Please consult Monjure Alam before executing this script.

5) Execute result_master.sql . This will connect to rd database and recreate all tables and data if they do not already exist.


**Post execution checks:**

1) All 6 tables are created in rd DB with rd_owner as schema
2) rd_user and rd_impl_role are created

May 9th 2022- comments:
This SQL folder is created to have a backup of existing db scipts before baselining these scripts for flyway integration. 
