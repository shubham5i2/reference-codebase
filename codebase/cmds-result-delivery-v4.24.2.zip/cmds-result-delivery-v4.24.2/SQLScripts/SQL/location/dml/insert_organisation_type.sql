-- DML scripts for organisation_type

INSERT INTO rd_owner.organisation_type( organisation_type_uuid, organisation_type, description, effective_from_date,  effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('e496aa98-86a3-476d-8be3-21ee0aa23c93',
		'RO',
		'Recognising Organisation',
		'2020-07-01',
		'2099-12-31',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(organisation_type_uuid) DO NOTHING;


INSERT INTO rd_owner.organisation_type( organisation_type_uuid, organisation_type, description, effective_from_date,  effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('e392ae7c-016f-433a-bdfa-b79bfcdddf26',
		'VO',
		'Verified Organisation',
		'2020-07-01',
		'2099-12-31',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(organisation_type_uuid) DO NOTHING;
