-- Create Type for location table
DO $$ BEGIN
	CREATE TYPE rd_owner."locationTypeCodeType" AS ENUM
    ('GLOBAL_IELTS', 'GLOBAL', 'PARTNER', 'REGION', 'COUNTRY', 'TEST_CENTRE', 'VIRTUAL_BUILDING', 'PHYSICAL_BUILDING', 'ROOM');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Create location table

CREATE TABLE IF NOT EXISTS rd_owner.location
(
	location_uuid UUID NOT NULL,
	parent_location_uuid UUID NULL,
	location_name character varying(300) NOT NULL,
	location_type_code rd_owner."locationTypeCodeType" NOT NULL,
	test_centre_number character varying(5) NULL,
	updated_datetime TIMESTAMPTZ NOT NULL,
	concurrency_version integer NOT NULL,
	event_datetime TIMESTAMPTZ NOT NULL,
	CONSTRAINT pk_location PRIMARY KEY (location_uuid)
	);
