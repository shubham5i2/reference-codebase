-- Address Type script
\ir ..//..//ro//ddl//address_type.sql

