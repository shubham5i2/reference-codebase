-- Linked Recognising Organisation scripts
\ir ..//..//ro//ddl//linked_recognising_organisation.sql

