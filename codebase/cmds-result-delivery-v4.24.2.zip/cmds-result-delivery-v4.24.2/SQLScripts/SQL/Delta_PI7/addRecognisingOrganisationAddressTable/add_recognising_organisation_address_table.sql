-- Recognising Organisation Address scripts
\ir ..//..//ro//ddl//recognising_organisation_address.sql

