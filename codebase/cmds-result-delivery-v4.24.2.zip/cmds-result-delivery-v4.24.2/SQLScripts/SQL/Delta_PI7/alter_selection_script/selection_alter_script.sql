ALTER TABLE rd_owner.selection ADD COLUMN associated_selection_uuid UUID

ALTER TABLE rd_owner.selection 
ADD CONSTRAINT uk_02_selection_recognising_organisation_uuid_external_booking_uuid UNIQUE(recognising_organisation_uuid,external_booking_uuid);


ALTER TYPE rd_owner.confirmation_status ADD VALUE 'INVALID';
