-- Type Creation for Product Status Type
DO $$ BEGIN
	CREATE TYPE rd_owner.product_status_type AS ENUM
   	('DRAFT', 'PUBLISHED');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

ALTER TABLE rd_owner.product
ADD COLUMN product_name VARCHAR(100) NOT NULL;
ALTER TABLE rd_owner.product
ADD COLUMN product_description VARCHAR(100) NULL;
ALTER TABLE rd_owner.product
ADD COLUMN bookable BOOLEAN NOT NULL;
ALTER TABLE rd_owner.product
ADD COLUMN approval_required BOOLEAN NOT NULL;
ALTER TABLE rd_owner.product
ADD COLUMN duration INTEGER NULL;
ALTER TABLE rd_owner.product
ADD COLUMN product_status rd_owner.product_status_type NOT NULL;
ALTER TABLE rd_owner.product
ADD COLUMN available_from_date DATE NOT NULL DEFAULT '2020-07-01';
ALTER TABLE rd_owner.product
ADD COLUMN available_to_date  DATE NOT NULL DEFAULT '2099-12-31';
ALTER TABLE rd_owner.product
ADD COLUMN created_by VARCHAR(36) NOT NULL;
ALTER TABLE rd_owner.product
ADD COLUMN updated_by VARCHAR(36) NULL;
ALTER TABLE rd_owner.product
ADD COLUMN created_datetime TIMESTAMPTZ NOT NULL DEFAULT current_timestamp;
ALTER TABLE rd_owner.product
ADD COLUMN updated_datetime TIMESTAMPTZ;
ALTER TABLE rd_owner.product
ADD COLUMN concurrency_version INTEGER NOT NULL DEFAULT 0;