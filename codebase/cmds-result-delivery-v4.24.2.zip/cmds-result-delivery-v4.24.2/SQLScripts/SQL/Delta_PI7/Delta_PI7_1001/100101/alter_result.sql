ALTER TABLE rd_owner.result DROP CONSTRAINT fk_01_result_result_type;
ALTER TABLE rd_owner.result DROP CONSTRAINT fk_02_result_result_status_type;
ALTER TABLE rd_owner.result DROP CONSTRAINT fk_03_result_result_status_label;