ALTER TABLE rd_owner.result_type
ADD COLUMN result_type_code VARCHAR(50) NOT NULL;
ALTER TABLE rd_owner.result_type
ADD COLUMN result_type VARCHAR(50) NOT NULL;
ALTER TABLE rd_owner.result_type
DROP COLUMN result_type_name;
ALTER TABLE rd_owner.result_type
DROP COLUMN result_type_priority;
ALTER TABLE rd_owner.result_type
ADD COLUMN effective_from_date DATE NOT NULL DEFAULT '2020-07-01';
ALTER TABLE rd_owner.result_type
ADD COLUMN effective_to_date  DATE NOT NULL DEFAULT '2099-12-31';
ALTER TABLE rd_owner.result_type
ADD COLUMN created_by VARCHAR(36) NOT NULL;
ALTER TABLE rd_owner.result_type
ADD COLUMN updated_by VARCHAR(36) NULL;
ALTER TABLE rd_owner.result_type
ADD COLUMN created_datetime TIMESTAMPTZ NOT NULL DEFAULT current_timestamp;
ALTER TABLE rd_owner.result_type
ADD COLUMN updated_datetime TIMESTAMPTZ;
ALTER TABLE rd_owner.result_type
ADD COLUMN concurrency_version INTEGER NOT NULL DEFAULT 0;