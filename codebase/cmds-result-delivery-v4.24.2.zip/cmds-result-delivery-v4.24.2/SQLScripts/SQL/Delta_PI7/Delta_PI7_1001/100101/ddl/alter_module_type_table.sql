ALTER TABLE rd_owner.module_type
ADD COLUMN effective_from_date DATE NOT NULL DEFAULT '2020-07-01';
ALTER TABLE rd_owner.module_type
ADD COLUMN effective_to_date  DATE NOT NULL DEFAULT '2099-12-31';
ALTER TABLE rd_owner.module_type
ADD COLUMN created_by VARCHAR(36) NOT NULL;
ALTER TABLE rd_owner.module_type
ADD COLUMN updated_by VARCHAR(36) NULL;
ALTER TABLE rd_owner.module_type
ADD COLUMN created_datetime TIMESTAMPTZ NOT NULL DEFAULT current_timestamp;
ALTER TABLE rd_owner.module_type
ADD COLUMN updated_datetime TIMESTAMPTZ;
ALTER TABLE rd_owner.module_type
ADD COLUMN concurrency_version INTEGER NOT NULL DEFAULT 0;