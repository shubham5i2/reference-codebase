ALTER TABLE rd_owner.results_status_label
ADD COLUMN results_status_label VARCHAR(50) NOT NULL;
ALTER TABLE rd_owner.results_status_label
ADD COLUMN results_status_type_uuid UUID NOT NULL;
ALTER TABLE rd_owner.results_status_label
ADD COLUMN results_status_comment_mandatory BOOLEAN NOT NULL;
ALTER TABLE rd_owner.results_status_label
ADD COLUMN effective_from_date DATE NOT NULL DEFAULT '2020-07-01';
ALTER TABLE rd_owner.results_status_label
ADD COLUMN effective_to_date  DATE NOT NULL DEFAULT '2099-12-31';
ALTER TABLE rd_owner.results_status_label
ADD COLUMN created_by VARCHAR(36) NOT NULL;
ALTER TABLE rd_owner.results_status_label
ADD COLUMN updated_by VARCHAR(36) NULL;
ALTER TABLE rd_owner.results_status_label
ADD COLUMN created_datetime TIMESTAMPTZ NOT NULL DEFAULT current_timestamp;
ALTER TABLE rd_owner.results_status_label
ADD COLUMN updated_datetime TIMESTAMPTZ;
ALTER TABLE rd_owner.results_status_label
ADD COLUMN concurrency_version INTEGER NOT NULL DEFAULT 0;
ALTER TABLE rd_owner.results_status_label
ADD CONSTRAINT fk_01_results_satus_label_results_status_type FOREIGN KEY (results_status_type_uuid) REFERENCES rd_owner.results_status_type(results_status_type_uuid);