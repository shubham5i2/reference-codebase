-- Table: rd_owner.booking_line

-- Create Type for booking_line table
DO $$ BEGIN
	CREATE TYPE rd_owner."bookingLineStatusType" AS ENUM
    ('ACTIVE', 'EXEMPT');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- DROP TABLE rd_owner.booking_line;

CREATE TABLE rd_owner.booking_line
(
    booking_line_uuid uuid NOT NULL,
    external_booking_line_uuid uuid NOT NULL,
    product_uuid uuid NOT NULL,
    booking_uuid uuid NOT NULL,
    booking_line_status rd_owner."bookingLineStatusType" NOT NULL,
    updated_datetime TIMESTAMPTZ NOT NULL,
    CONSTRAINT pk_booking_line PRIMARY KEY (booking_line_uuid),
    CONSTRAINT fk_01_booking_line_booking FOREIGN KEY (booking_uuid)
    REFERENCES rd_owner.booking (booking_uuid)
);