-- Table: rd_owner.booking

-- Create Type for booking table
DO $$ BEGIN
	CREATE TYPE rd_owner."bookingStatusType" AS ENUM
    ('PAID', 'CANCELLED', 'UNPAID', 'REFUNDED');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
	CREATE TYPE rd_owner."bookingDetailsStatusType" AS ENUM
    ('COMPLETE', 'INCOMPLETE');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- DROP TABLE rd_owner.booking;

CREATE TABLE rd_owner.booking
(
    booking_uuid uuid NOT NULL,
    external_booking_uuid uuid NOT NULL,
    location_uuid uuid NOT NULL,
    product_uuid uuid NOT NULL,
    external_booking_reference character varying(100) NOT NULL,
    test_date date NOT NULL,
    short_candidate_number integer NOT NULL,
    booking_status rd_owner."bookingStatusType" NOT NULL,
    partner_code character varying(20) NOT NULL,
    booking_details_status rd_owner."bookingDetailsStatusType" NOT NULL,
    agent_name character varying(100) NULL,
    unique_test_taker_uuid uuid NULL,
    external_unique_test_taker_uuid uuid NOT NULL,
    composite_candidate_number character varying(20) NOT NULL,
    first_name character varying(100) NULL,
    last_name character varying(100) NULL,
    email character varying(320) NULL,
    identity_number character varying(100) NULL,
    identity_type_uuid uuid NULL,
    identity_issuing_auth character varying(100) NULL,
    identity_expiry_date TIMESTAMPTZ NULL,
    birth_date TIMESTAMPTZ NULL,
    sex_uuid uuid NULL,
    title character varying(12) NULL,
    language_uuid uuid NULL,
    nationality_uuid uuid NULL,
    phone character varying(20) NULL,
    mobile character varying(20) NULL,
    address_line_1 character varying(100) NULL,
    address_line_2 character varying(100) NULL,
    address_line_3 character varying(100) NULL,
    address_line_4 character varying(100) NULL,
    state_territory_uuid uuid NULL,
    postal_code character varying(20) NULL,
    city character varying(200) NULL,
    country_uuid uuid NULL,
    years_of_study integer NULL,
    occupation_sector_uuid uuid NULL,
    reason_for_test_uuid uuid NULL,
    occupation_level_uuid uuid NULL,
    updated_datetime TIMESTAMPTZ NOT NULL,
    event_datetime TIMESTAMPTZ NOT NULL,
    concurrency_version integer NOT NULL,
    CONSTRAINT pk_booking PRIMARY KEY (booking_uuid),
    CONSTRAINT uk_01_booking_external_booking_uuid UNIQUE (external_booking_uuid)
);