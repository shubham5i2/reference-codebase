-- Table: rd_owner.booking_link

-- Create Type for booking_link table
DO $$ BEGIN
	CREATE TYPE rd_owner."role" AS ENUM
    ('SSRORIGINAL');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;


CREATE TABLE rd_owner.booking_link
(
    booking_link_uuid uuid NOT NULL,
	role rd_owner."role" NOT NULL,
	source_booking_uuid uuid NOT NULL,
    target_booking_uuid uuid NOT NULL,
    created_datetime timestamptz NOT NULL,
	updated_datetime timestamptz NULL,
	created_by VARCHAR(36) NULL,
	updated_by VARCHAR(36) NULL,
	concurrency_version integer NULL,
    CONSTRAINT pk_booking_link PRIMARY KEY (booking_link_uuid),
    CONSTRAINT fk_01_source_booking_uuid FOREIGN KEY (source_booking_uuid)
	REFERENCES rd_owner.booking (booking_uuid),
	CONSTRAINT fk_02_target_booking_uuid FOREIGN KEY (target_booking_uuid)
	REFERENCES rd_owner.booking (booking_uuid)
		
);
