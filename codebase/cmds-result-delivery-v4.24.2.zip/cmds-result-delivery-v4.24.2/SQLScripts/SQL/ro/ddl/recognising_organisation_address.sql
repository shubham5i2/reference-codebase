CREATE TABLE IF NOT EXISTS rd_owner.recognising_organisation_address  (
    address_uuid UUID NOT NULL,
    recognising_organisation_uuid UUID NOT NULL,
    address_type_uuid UUID NOT NULL,
    addressline1 VARCHAR(100),
	addressline2 VARCHAR(100),
	addressline3 VARCHAR(100),
	addressline4 VARCHAR(100),
    city VARCHAR(100),
    postalcode VARCHAR(100),
    updated_datetime TIMESTAMPTZ,
    CONSTRAINT pk_recognising_organisation_address PRIMARY KEY (address_uuid),
    CONSTRAINT fk_01_recognising_organisation_address_recognising_organisation FOREIGN KEY (recognising_organisation_uuid) REFERENCES rd_owner.recognising_organisation(recognising_organisation_uuid)
);
