-- Create recognised_product table

CREATE TABLE IF NOT EXISTS rd_owner.recognised_product
(
	recognised_product_uuid UUID NOT NULL,
	recognising_organisation_uuid UUID NOT NULL,
	product_uuid UUID NOT NULL,
	effective_from_datetime TIMESTAMPTZ NOT NULL,
	effective_to_datetime TIMESTAMPTZ NOT NULL,
	updated_datetime TIMESTAMPTZ NOT NULL,
	CONSTRAINT pk_recognised_product PRIMARY KEY (recognised_product_uuid),
	CONSTRAINT fk_01_recognised_product_recognising_org FOREIGN KEY (recognising_organisation_uuid)
    REFERENCES rd_owner.recognising_organisation (recognising_organisation_uuid)
	);
 
