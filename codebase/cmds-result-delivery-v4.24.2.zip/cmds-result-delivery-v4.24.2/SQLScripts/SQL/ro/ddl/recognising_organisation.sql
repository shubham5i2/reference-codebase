-- Create Type for recognising_organisation table
DO $$ BEGIN
	CREATE TYPE rd_owner."verificationStatusType" AS ENUM
    ('PENDING', 'APPROVED', 'REJECTED','VERIFIED');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

	
DO $$ BEGIN
	CREATE TYPE rd_owner."methodOfDeliveryType" AS ENUM
    ('POSTAL', 'E-DELIVERY');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;


	
DO $$ BEGIN
	CREATE TYPE rd_owner."orgStatusType" AS ENUM
    ('INACTIVE', 'ACTIVE');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Create recognising_organisation table **/

CREATE TABLE IF NOT EXISTS rd_owner.recognising_organisation
(
	recognising_organisation_uuid UUID NOT NULL,
	organisation_type_uuid UUID NOT NULL,
	organisation_id character varying(25) NOT NULL,
	name character varying(255) NOT NULL,
	verification_status rd_owner."verificationStatusType" NOT NULL,
	partner_code character varying(25) NOT NULL,
	method_of_delivery rd_owner."methodOfDeliveryType" NOT NULL,
	parent_recognising_organisation_uuid UUID NULL,
	organisation_status  rd_owner."orgStatusType" NOT NULL,
	organisation_code character varying(20) NULL,
	replaced_by_recognising_organisation_uuid UUID NULL,
	soft_deleted boolean NULL,
	updated_datetime TIMESTAMPTZ NOT NULL, 
	event_datetime TIMESTAMPTZ NOT NULL, 
	concurrency_version integer NOT NULL,
	CONSTRAINT pk_recognising_organisation PRIMARY KEY (recognising_organisation_uuid),
	CONSTRAINT fk_01_recognising_organisation_organisation_type FOREIGN KEY (recognising_organisation_uuid)
    REFERENCES rd_owner.recognising_organisation (recognising_organisation_uuid)
	);
 
