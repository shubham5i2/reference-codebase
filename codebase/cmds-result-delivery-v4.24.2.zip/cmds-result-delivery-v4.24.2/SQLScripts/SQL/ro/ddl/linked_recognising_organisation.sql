DO $$ BEGIN
	CREATE TYPE rd_owner."linkedRecognisingOrganisationType" AS ENUM
    ('PARENT_RO', 'RESULTS_DELIVERY', 'REPLACED_BY');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

CREATE TABLE IF NOT EXISTS rd_owner.linked_recognising_organisation
(
    linked_recognising_organisation_uuid uuid NOT NULL,
    source_recognising_organisation_uuid uuid NOT NULL,
    target_recognising_organisation_uuid uuid NOT NULL,
    linked_recognising_organisation_type rd_owner."linkedRecognisingOrganisationType" NOT NULL,
    link_effective_from_datetime TIMESTAMPTZ NOT NULL,
    link_effective_to_datetime TIMESTAMPTZ NOT NULL,
    updated_datetime TIMESTAMPTZ NOT NULL,
	deleted boolean NOT NULL DEFAULT false,
    CONSTRAINT pk_linked_recognising_organisation PRIMARY KEY (linked_recognising_organisation_uuid),
CONSTRAINT fk_01_linked_recognising_organisation_recognising_organisation_uuid FOREIGN KEY (source_recognising_organisation_uuid) References rd_owner.recognising_organisation(recognising_organisation_uuid) ON UPDATE NO ACTION ON DELETE NO ACTION,
CONSTRAINT fk_02_linked_recognising_organisation_recognising_organisation_uuid FOREIGN KEY (target_recognising_organisation_uuid) References rd_owner.recognising_organisation(recognising_organisation_uuid) ON UPDATE NO ACTION ON DELETE NO ACTION,
    CONSTRAINT uk_01_source_recognising_organisation_uuid__target_recognising_organisation_uuid_linked_recognising_organisation_type UNIQUE (source_recognising_organisation_uuid,target_recognising_organisation_uuid,linked_recognising_organisation_type)
);