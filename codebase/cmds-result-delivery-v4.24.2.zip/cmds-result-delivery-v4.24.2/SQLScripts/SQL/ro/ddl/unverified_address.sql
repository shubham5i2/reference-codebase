CREATE TABLE IF NOT EXISTS rd_owner.unverified_address
(
unverified_address_uuid UUID NOT NULL,
recognising_organisation_uuid UUID,
addressline1 VARCHAR(100) NOT NULL,
addressline2 VARCHAR(100),
addressline3 VARCHAR(100),
addressline4 VARCHAR(100),
city VARCHAR(50),
postalcode VARCHAR(50),
territory_uuid UUID,
territory_iso_code VARCHAR(50),
country_iso_code VARCHAR(50) NOT NULL,
email VARCHAR(100),
phone VARCHAR(100),
organisation_name VARCHAR(100) NOT NULL,
contact_known_name VARCHAR(100),
 CONSTRAINT pk_unverified_address PRIMARY KEY (unverified_address_uuid),
CONSTRAINT fk_recognising_organisation_uuid FOREIGN KEY(recognising_organisation_uuid)
	REFERENCES rd_owner.recognising_organisation (recognising_organisation_uuid)
	
);
