Below LPR changes needs to be reflected in rd database as per ticket https://btsservice.atlassian.net/browse/IMOD-28106

SQLScripts/Delta_PI8/Delta_PI8_1005/lpr_insert_country_script.sql

SQLScripts/Delta_PI8/Delta_PI8_1005/lpr_insert_reinstate_country.sql

SQLScripts/Delta_PI8/Delta_PI8_1005/lpr_insert_reinstate_nationality.sql

SQLScripts/Delta_PI8/Delta_PI8_1005/lpr_reinstate_gender.sql

SQLScripts/Delta_PI8/Delta_PI8_1005/lpr_update_nationality.sql