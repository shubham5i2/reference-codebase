INSERT INTO rd_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference,effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('6024eecd-83bc-4d0f-a437-ed0719510579',
        'BUR',
        'Burma',
        'BUR',       
        '2022-03-20',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;
		

INSERT INTO rd_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference,effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('ce92e241-e666-467f-a69f-8b7125d0c983',
        'CTE',
        'Canton and Enderburys Phoenix Is',
        'CTE',       
        '2022-03-20',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;
