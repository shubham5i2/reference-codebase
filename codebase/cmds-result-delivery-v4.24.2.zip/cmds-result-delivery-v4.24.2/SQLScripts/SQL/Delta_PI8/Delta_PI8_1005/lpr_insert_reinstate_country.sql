INSERT INTO rd_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference,effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('f1d98bb8-070a-472e-b2ff-bad6ec945419',
        'ZAR',
        'Zaire',
        'ZAR',       
        '2022-03-20',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;
		
INSERT INTO rd_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference,effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('40bd389f-857d-4ade-8eb4-ce8d7b2d9928',
        'SCG',
        'Serbia and Montenegro',
        'SEM',
        '2022-03-20',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;
		
INSERT INTO rd_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference,effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('aae32c9f-108a-4f39-9c86-cef73294ee2e',
        'ANT',
        'Netherland Antilles',
        'ANT',
        '2022-03-20',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;
