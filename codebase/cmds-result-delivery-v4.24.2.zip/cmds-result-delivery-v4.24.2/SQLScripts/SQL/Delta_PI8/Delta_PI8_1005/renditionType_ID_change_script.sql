ALTER TYPE rd_owner.rendition_type_code ADD VALUE 'ETRF';

UPDATE rd_owner.rendition_type SET rendition_type_code = 'ETRF' WHERE rendition_type_uuid = '15b2e233-81a4-4263-b327-9b47ba09eb01';

INSERT INTO rd_owner.rendition_type(rendition_type_uuid, rendition_type_code) VALUES ('14fedb8c-5639-4f8b-95d1-345b8f0cd0ce','TRF');
