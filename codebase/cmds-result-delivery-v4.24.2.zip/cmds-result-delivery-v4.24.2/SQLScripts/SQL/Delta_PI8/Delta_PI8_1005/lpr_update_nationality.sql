UPDATE rd_owner.nationality SET legacy_reference='256' WHERE nationality_uuid='f6c8f731-18e7-4608-b2c2-dd2facb6175b'
 AND nationality_code='GGY';

UPDATE rd_owner.nationality SET legacy_reference='255' WHERE nationality_uuid='4b263904-e3d3-44df-9886-410b4e1b5c8c'
 AND nationality_code='IMN';
