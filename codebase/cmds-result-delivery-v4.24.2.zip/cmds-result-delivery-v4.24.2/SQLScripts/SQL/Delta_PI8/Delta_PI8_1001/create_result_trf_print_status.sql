-- Result TRF Print Status script
\ir ..//..//rm//ddl//result_trf_print_status.sql

