ALTER TABLE rd_owner.selection ADD COLUMN unverified_address_uuid UUID;

