-- Unverified Address script
\ir ..//..//ro//ddl//unverified_address.sql

