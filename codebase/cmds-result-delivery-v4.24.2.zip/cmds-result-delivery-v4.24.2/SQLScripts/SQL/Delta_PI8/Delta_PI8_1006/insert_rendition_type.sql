INSERT INTO rd_owner.rendition_type (rendition_type_uuid, rendition_type_code, effective_from_date, effective_to_date)
VALUES ('281c20d8-26fd-4e58-b162-4b233542d422',
        'ERESULT',
        '2020-12-01',
	    '2099-12-31');