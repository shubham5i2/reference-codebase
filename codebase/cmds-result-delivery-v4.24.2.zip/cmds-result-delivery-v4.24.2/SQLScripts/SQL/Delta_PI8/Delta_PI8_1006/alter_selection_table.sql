ALTER TABLE rd_owner.selection
ALTER COLUMN recognising_organisation_uuid DROP NOT NULL;
