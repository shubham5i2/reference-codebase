CREATE TABLE rd_owner.report_delivery_requested (
	report_delivery_requested_uuid uuid,
	booking_uuid uuid NOT NULL,
	transaction_uuid uuid NOT NULL,
	updated_datetime TIMESTAMPTZ,
	concurrency_version INTEGER NOT NULL DEFAULT 0,
	
	CONSTRAINT pk_report_delivery_requested PRIMARY KEY(report_delivery_requested_uuid),
	CONSTRAINT uk_01_report_delivery_requested UNIQUE(booking_uuid, transaction_uuid)

);