ALTER TYPE rd_owner.delivery_status  ADD VALUE 'NOT_APPLICABLE_FOR_UA';

