-- DROP TABLE rd_owner.territory;

-- Create territory table

CREATE TABLE IF NOT EXISTS rd_owner.territory (
    territory_uuid uuid NOT NULL,
    country_uuid uuid NOT NULL,
    territory_iso_code VARCHAR(6) NOT NULL UNIQUE,
    territory_name VARCHAR(100) NOT NULL,
    legacy_reference VARCHAR(3),
    effective_from_date date NOT NULL,
    effective_to_date date DEFAULT '2099-12-31' NOT NULL,
    created_by VARCHAR(36) NOT NULL,
    created_datetime timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by VARCHAR(36),
    updated_datetime timestamp with time zone,
    concurrency_version integer DEFAULT 0 NOT NULL,
	CONSTRAINT pk_territory PRIMARY KEY (territory_uuid),
	CONSTRAINT fk_01_territory_country FOREIGN KEY (country_uuid ) REFERENCES rd_owner.country (country_uuid)
);

