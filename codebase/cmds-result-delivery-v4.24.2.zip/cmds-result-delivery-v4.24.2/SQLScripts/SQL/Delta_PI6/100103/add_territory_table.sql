-- Territory change scripts
\ir ..//..//territory//ddl//territory.sql

\ir ..//..//territory//dml//insert_territory.sql
