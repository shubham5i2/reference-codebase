


-- Rendition Type change scripts
\ir ..//..//rendition//ddl//rendition_type.sql

\ir ..//..//rendition//dml//insert_rendition_type.sql
