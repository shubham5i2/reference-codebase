ALTER TYPE rd_owner.delivery_status ADD VALUE 'DELIVERY_PENDING';
ALTER TYPE rd_owner.delivery_status ADD VALUE 'DELIVERY_REQUESTED';
ALTER TYPE rd_owner.delivery_status ADD VALUE 'REDELIVERY_REQUESTED';
ALTER TYPE rd_owner.delivery_status ADD VALUE 'REDELIVERY_REQUEST_PENDING';
ALTER TYPE rd_owner.delivery_status ADD VALUE 'REDELIVERED';


