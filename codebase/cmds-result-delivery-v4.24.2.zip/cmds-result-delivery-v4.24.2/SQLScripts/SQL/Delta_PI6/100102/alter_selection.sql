-- if not exist create EMUM Type for minimum_score_satisfied
DO $$ BEGIN CREATE TYPE rd_owner.minimum_score_satisfied AS ENUM (
    'SATISFIED', 'UNSATISFIED', 'NOT_APPLICABLE'
    );
EXCEPTION
WHEN duplicate_object THEN null;
END $$;

ALTER TABLE rd_owner.selection
ADD COLUMN minimum_score_satisfied rd_owner.minimum_score_satisfied NOT NULL