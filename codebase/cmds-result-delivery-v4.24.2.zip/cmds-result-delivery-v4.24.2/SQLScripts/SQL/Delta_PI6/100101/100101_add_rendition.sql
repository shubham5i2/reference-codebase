


-- Result Rendition change scripts
\ir ..//..//rm//ddl//results_rendition.sql
