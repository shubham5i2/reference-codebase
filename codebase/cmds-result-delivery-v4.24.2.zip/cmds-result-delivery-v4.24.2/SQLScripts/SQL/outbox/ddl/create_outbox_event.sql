-- Create publish_state	Type for outbox_event table
DO $$ BEGIN
	CREATE TYPE rd_owner."publishStateType" AS ENUM
    ('PUBLISH_PENDING', 'PUBLISH_SUCCEED', 'PUBLISH_FAILURE');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;


-- Create Table for outbox_event
CREATE TABLE IF NOT EXISTS rd_owner.outbox_event (
    outbox_event_uuid UUID NOT NULL,
    transaction_uuid UUID NOT NULL,
	event_name VARCHAR(256) NOT NULL,
	event_datetime TIMESTAMPTZ NOT NULL,
	payload TEXT NOt NULL,
	publish_state rd_owner."publishStateType" NOT NULL,
	retry_count INTEGER NOT NULL,
	created_datetime TIMESTAMPTZ NOT NULL,
	updated_datetime TIMESTAMPTZ NOT NULL,
    concurrency_version INTEGER NOT NULL,
    CONSTRAINT pk_outbox_event PRIMARY KEY (outbox_event_uuid)
);
