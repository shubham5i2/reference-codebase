-- Create Table for outbox_event_attribute
CREATE TABLE IF NOT EXISTS rd_owner.outbox_event_attribute (
    outbox_event_attribute_uuid UUID NOT NULL,
    outbox_event_uuid UUID NOT NULL,
	attribute_key VARCHAR(256) NOT NULL,
	attribute_value TEXT,
	updated_datetime TIMESTAMPTZ NOT NULL,
    CONSTRAINT pk_outbox_event_attribute PRIMARY KEY (outbox_event_attribute_uuid),
	CONSTRAINT fk_01_outbox_event_attribute FOREIGN KEY (outbox_event_uuid) References rd_owner.outbox_event(outbox_event_uuid),
	CONSTRAINT uk_01_outbox_event_attribute UNIQUE (outbox_event_uuid, attribute_key)
);
