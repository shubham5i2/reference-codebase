-- Table: rd_owner.test_taker_photo_type

-- DROP TABLE rd_owner.test_taker_photo_type;

-- DROP TYPE rd_owner.photo_type_code;

DO $$ BEGIN CREATE TYPE rd_owner.photo_type_code AS ENUM (
    'TT_ID_HR_R', 'TT_P_HR_R', 'TT_P_LR_IAM', 'TT_P_HR_IAM', 'TT_P_LR_LRW_WC', 'TT_P_LR_S_WC', 'TT_ID_LRW_WC', 'TT_ID_S_WC'
    );
EXCEPTION
WHEN duplicate_object THEN null;
END $$;

CREATE TABLE rd_owner.test_taker_photo_type
(
    photo_type_uuid uuid NOT NULL,
    photo_type_code rd_owner.photo_type_code NOT NULL,
	photo_type_description VARCHAR(200) NOT NULL,
	effective_from_date DATE NOT NULL DEFAULT '2020-07-01',
	effective_to_date  DATE NOT NULL DEFAULT '2099-12-31',
	created_by VARCHAR(36) NOT NULL,
	updated_by VARCHAR(36) NULL,
	created_datetime TIMESTAMPTZ NOT NULL DEFAULT current_timestamp,
	updated_datetime TIMESTAMPTZ,
	concurrency_version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT pk_tt_photo_type PRIMARY KEY (photo_type_uuid)
);

