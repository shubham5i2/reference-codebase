-- Table: rd_owner.test_taker_photo

-- DROP TABLE rd_owner.test_taker_photo;

CREATE TABLE rd_owner.test_taker_photo
(
    photo_uuid uuid NOT NULL,
    booking_uuid uuid NOT NULL,
    photo_type_uuid uuid NOT NULL,
    file_path VARCHAR(256) NOT NULL,
    photo_version VARCHAR(10) NOT NULL,
    updated_datetime TIMESTAMPTZ NOT NULL,
    event_datetime TIMESTAMPTZ NOT NULL,
    concurrency_version integer NOT NULL,
    CONSTRAINT pk_test_taker_photo PRIMARY KEY (photo_uuid),
    CONSTRAINT uk_01_test_taker_photo_booking_uuid_photo_type_uuid UNIQUE (booking_uuid,photo_type_uuid)
);