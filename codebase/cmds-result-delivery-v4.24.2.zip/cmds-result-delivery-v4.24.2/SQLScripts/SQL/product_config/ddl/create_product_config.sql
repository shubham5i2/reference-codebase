-- Table: rd_owner.product_config


CREATE TABLE IF NOT EXISTS rd_owner.product_config
(
    product_config_uuid uuid NOT NULL,
    rendition_type_uuid uuid NOT NULL,
    product_uuid uuid NOT NULL,
	partner_code VARCHAR(20) NOT NULL,
    template_name VARCHAR(100) NOT NULL,
	report_module_name VARCHAR(100) NOT NULL,
	effective_from_date DATE NOT NULL DEFAULT '2020-07-01',
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
	created_by VARCHAR(36) NOT NULL DEFAULT 'Operations User',
	updated_by VARCHAR(36),
	created_datetime timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_datetime timestamp with time zone,
    concurrency_version integer NOT NULL DEFAULT 0,
    CONSTRAINT pk_01_product_config PRIMARY KEY (product_config_uuid)
);
