/** Running this script for UUID **/

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";