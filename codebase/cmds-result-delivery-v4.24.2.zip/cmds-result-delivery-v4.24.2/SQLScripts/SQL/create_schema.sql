/** Restrict on creating table in public schema **/
REVOKE ALL ON SCHEMA public FROM PUBLIC;

/** Create Schema **/
CREATE SCHEMA IF NOT EXISTS rd_owner;

/** Create role rd_impl_role **/
DO $$
BEGIN	
 CREATE ROLE rd_impl_role;
        EXCEPTION WHEN DUPLICATE_OBJECT THEN
        RAISE NOTICE 'Role rd_impl_role already exists';
END
$$;

/** Create User with login **/
DO $$
BEGIN
CREATE USER rd_user;
  EXCEPTION WHEN DUPLICATE_OBJECT THEN
  RAISE NOTICE 'User rd_user already exists';
END
$$;

/** Grant Create table access for rd_owner **/
GRANT USAGE, CREATE ON SCHEMA rd_owner TO rd_impl_role;

/** Table Level Access **/
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA rd_owner TO rd_impl_role;

/** Automatically grant permissions on tables and views added **/
ALTER DEFAULT PRIVILEGES IN SCHEMA rd_owner GRANT SELECT, INSERT, UPDATE ON TABLES TO rd_impl_role;

/** Grant permission to all sequences **/
GRANT USAGE ON ALL SEQUENCES IN SCHEMA rd_owner TO rd_impl_role;

/** Grant permissions to sequences added in the future**/
ALTER DEFAULT PRIVILEGES IN SCHEMA rd_owner GRANT USAGE ON SEQUENCES TO rd_impl_role;

/** Grant User with Role **/
GRANT rd_impl_role to rd_user;

/** Grant DATABASE with login **/
GRANT CONNECT on DATABASE rd to rd_user;
