-- Type For Component Type
DO $$ BEGIN
	CREATE TYPE rd_owner.component_type AS ENUM ('R','L','W','S');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;	

-- Creating table for minimum_score
CREATE TABLE IF NOT EXISTS rd_owner.minimum_score
(
	minimum_score_uuid UUID NOT NULL,
	selection_uuid UUID NOT NULL,
	minimum_score_value NUMERIC(2, 1) NOT NULL,
	component rd_owner.component_type NOT NULL,
	updated_datetime TIMESTAMPTZ NOT NULL,
	CONSTRAINT pk_minimum_score PRIMARY KEY (minimum_score_uuid),
	CONSTRAINT fk_01_minumum_score_selection FOREIGN KEY (selection_uuid ) REFERENCES rd_owner.selection (selection_uuid) ON UPDATE NO ACTION ON DELETE NO ACTION
	);
