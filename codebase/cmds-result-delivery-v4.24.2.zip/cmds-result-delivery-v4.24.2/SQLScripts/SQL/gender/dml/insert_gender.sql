--DML scripts for gender
		
INSERT INTO rd_owner.gender (gender_uuid, gender_code, gender_description, legacy_reference, effective_from_date,  effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('1c596055-1313-4761-9ff3-2bd9fee84390',
        'F',
        'Female',
        'F',
        '2020-07-01',
		'2099-12-31',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(gender_uuid) DO NOTHING;


INSERT INTO rd_owner.gender (gender_uuid, gender_code, gender_description, legacy_reference, effective_from_date,  effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('34de7534-8ed4-4043-8614-53641a012305',
        'M',
        'Male',
        'M',
        '2020-07-01',
		'2099-12-31',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(gender_uuid) DO NOTHING;
		
INSERT INTO rd_owner.gender (gender_uuid, gender_code, gender_description, legacy_reference, effective_from_date,  effective_to_date, created_by, updated_by, updated_datetime)
VALUES ('936338a0-5a3d-447b-83f5-af43ae909ceb',
        'X',
        'Other',
        'X',
        '2020-07-01',
		'2022-03-21',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(gender_uuid) DO NOTHING;