-- Table: rd_owner.gender

-- DROP TABLE rd_owner.gender;

CREATE TABLE IF NOT EXISTS rd_owner.gender (
    gender_uuid uuid NOT NULL,
    gender_code VARCHAR(1) NOT NULL,
    gender_description VARCHAR(100) NOT NULL,
    legacy_reference VARCHAR(3),
    effective_from_date date NOT NULL,
    effective_to_date date DEFAULT '2099-12-31' NOT NULL,
    created_by VARCHAR(36) NOT NULL,
    created_datetime TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by VARCHAR(36),
    updated_datetime TIMESTAMPTZ,
    concurrency_version integer DEFAULT 0 NOT NULL,
    CONSTRAINT gender_gender_code_key UNIQUE (gender_code),
    CONSTRAINT pk_gender PRIMARY KEY (gender_uuid)
);