these scripts will not be pickedup by flyway as these scipts are versioned below baseline. These scripts should be executed by infra team manually.

