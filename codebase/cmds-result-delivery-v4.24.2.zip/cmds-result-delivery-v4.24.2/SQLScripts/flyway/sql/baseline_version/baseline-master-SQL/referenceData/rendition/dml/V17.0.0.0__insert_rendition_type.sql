-- DML scripts for rendition_type

INSERT INTO rd_owner.rendition_type( rendition_type_uuid, rendition_type_code, effective_from_date, effective_to_date)
VALUES ('15b2e233-81a4-4263-b327-9b47ba09eb01',
        'ETRF',
		'2020-12-01',
	    '2099-12-31') ON CONFLICT(rendition_type_uuid) DO NOTHING;

INSERT INTO rd_owner.rendition_type( rendition_type_uuid, rendition_type_code, effective_from_date, effective_to_date)
VALUES ('281c20d8-26fd-4e58-b162-4b233542d422',
        'ERESULT',
        '2020-12-01',
	    '2099-12-31') ON CONFLICT(rendition_type_uuid) DO NOTHING;

INSERT INTO rd_owner.rendition_type(rendition_type_uuid, rendition_type_code, effective_from_date, effective_to_date) 
VALUES ('14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
		'TRF',
		'2020-12-01',
	    '2099-12-31') ON CONFLICT(rendition_type_uuid) DO NOTHING;


