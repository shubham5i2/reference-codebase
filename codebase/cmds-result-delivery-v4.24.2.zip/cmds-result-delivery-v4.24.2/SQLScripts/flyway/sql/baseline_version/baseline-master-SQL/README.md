This folder is having db scripts that are versioning for baseline creation of flyway integration.
rd_master.sql file is having sequence of scripts to be executed and this file is NOT considered by flyway. Added only for reference of versioning order.


