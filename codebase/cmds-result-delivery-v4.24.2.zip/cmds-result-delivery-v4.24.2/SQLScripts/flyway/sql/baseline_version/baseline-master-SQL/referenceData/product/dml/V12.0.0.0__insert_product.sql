INSERT INTO rd_owner.product VALUES ('637f8e1b-0931-4184-9fed-37bc9fdb53d5', NULL, NULL, 'IELTS Online', NULL, NULL, false, NULL, NULL, 'CD', false, '2020-07-01', '2099-12-31', 'PUBLISHED', 'Operations User', '2020-07-13 05:30:00+00', NULL, NULL, 0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO rd_owner.product VALUES ('3e81e94b-8b6a-42b5-970c-b141f9d195a3', '637f8e1b-0931-4184-9fed-37bc9fdb53d5', 'D901', 'IELTS Online Academic', NULL, '7a28a632-8728-4f74-882e-72e9d3649763', true, NULL, NULL, 'CD', false, '2020-07-01', '2099-12-31', 'PUBLISHED', 'Operations User', '2020-07-13 05:30:00+00', NULL, NULL, 0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO rd_owner.product VALUES ('4ddcb08b-c2c7-412a-9f59-f4adaf3aa131', '3e81e94b-8b6a-42b5-970c-b141f9d195a3', NULL, 'IELTS Online Academic R', NULL, '7a28a632-8728-4f74-882e-72e9d3649763', false, 'R', 60, 'CD', false, '2020-07-01', '2099-12-31', 'PUBLISHED', 'Operations User', '2020-07-13 05:30:00+00', NULL, NULL, 0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO rd_owner.product VALUES ('cb6f4028-c2d8-48f1-8006-1343760ec905', '3e81e94b-8b6a-42b5-970c-b141f9d195a3', NULL, 'IELTS Online Academic W', NULL, '7a28a632-8728-4f74-882e-72e9d3649763', false, 'W', 60, 'CD', false, '2020-07-01', '2099-12-31', 'PUBLISHED', 'Operations User', '2020-07-13 05:30:00+00', NULL, NULL, 0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO rd_owner.product VALUES ('fd01b36e-bb07-4229-81c2-483308787e9f', '3e81e94b-8b6a-42b5-970c-b141f9d195a3', NULL, 'IELTS Online Academic S', NULL, '7a28a632-8728-4f74-882e-72e9d3649763', false, 'S', 20, 'CD', false, '2020-07-01', '2099-12-31', 'PUBLISHED', 'Operations User', '2020-07-13 05:30:00+00', NULL, NULL, 0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO rd_owner.product VALUES ('0c6bc64c-fc66-4d5f-879d-89cdc6c3ed31', '3e81e94b-8b6a-42b5-970c-b141f9d195a3', NULL, 'IELTS Online Academic L', NULL, '7a28a632-8728-4f74-882e-72e9d3649763', false, 'L', 35, 'CD', false, '2020-07-01', '2099-12-31', 'PUBLISHED', 'Operations User', '2020-07-13 05:30:00+00', NULL, NULL, 0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO rd_owner.product VALUES ('5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0', NULL, NULL, 'IELTS on Computer', NULL, NULL, false, NULL, NULL, 'CD', false, '2020-07-01', '2099-12-31', 'PUBLISHED', 'Operations User', '2022-03-14 11:30:00+00', NULL, NULL, 0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO rd_owner.product VALUES ('fdbacec5-e80a-4710-b3de-7d5f310b1466', '5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0', '0383', 'IELTS on Computer Academic', NULL, '7a28a632-8728-4f74-882e-72e9d3649763', true, NULL, NULL, 'CD', false, '2020-07-01', '2099-12-31', 'PUBLISHED', 'Operations User', '2022-03-14 11:30:00+00', NULL, NULL, 0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO rd_owner.product VALUES ('6ccd6696-0660-409c-8a66-85d79c42f84d', 'fdbacec5-e80a-4710-b3de-7d5f310b1466', NULL, 'IELTS on Computer Academic L', NULL, '7a28a632-8728-4f74-882e-72e9d3649763', false, 'L', 35, 'CD', false, '2020-07-01', '2099-12-31', 'PUBLISHED', 'Operations User', '2022-03-14 11:30:00+00', NULL, NULL, 0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO rd_owner.product VALUES ('d40d2104-a610-42dc-936b-263fb4ba120a', 'fdbacec5-e80a-4710-b3de-7d5f310b1466', NULL, 'IELTS on Computer Academic R', NULL, '7a28a632-8728-4f74-882e-72e9d3649763', false, 'R', 60, 'CD', false, '2020-07-01', '2099-12-31', 'PUBLISHED', 'Operations User', '2022-03-14 11:30:00+00', NULL, NULL, 0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO rd_owner.product VALUES ('f0ea4e6f-d550-4687-a231-1032a7987441', 'fdbacec5-e80a-4710-b3de-7d5f310b1466', NULL, 'IELTS on Computer Academic W', NULL, '7a28a632-8728-4f74-882e-72e9d3649763', false, 'W', 60, 'CD', false, '2020-07-01', '2099-12-31', 'PUBLISHED', 'Operations User', '2022-03-14 11:30:00+00', NULL, NULL, 0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO rd_owner.product VALUES ('43215312-a604-4cbf-8b97-c3695b03e396', 'fdbacec5-e80a-4710-b3de-7d5f310b1466', NULL, 'IELTS on Computer Academic S', NULL, '7a28a632-8728-4f74-882e-72e9d3649763', false, 'S', 20, 'CD', false, '2020-07-01', '2099-12-31', 'PUBLISHED', 'Operations User', '2022-03-14 11:30:00+00', NULL, NULL, 0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO rd_owner.product VALUES ('cf9a05e9-2679-42da-b7d2-b34ea3e0724e', '5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0', '0382', 'IELTS on Computer General Training', NULL, '0ae29abe-5862-4c48-92e4-00d7eba376a2', true, NULL, NULL, 'CD', false, '2020-07-01', '2099-12-31', 'PUBLISHED', 'Operations User', '2022-03-14 11:30:00+00', NULL, NULL, 0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO rd_owner.product VALUES ('df2c8f7e-e485-441b-88a5-34b640bff6a5', 'cf9a05e9-2679-42da-b7d2-b34ea3e0724e', NULL, 'IELTS on Computer General Training L', NULL, '0ae29abe-5862-4c48-92e4-00d7eba376a2', false, 'L', 35, 'CD', false, '2020-07-01', '2099-12-31', 'PUBLISHED', 'Operations User', '2022-03-14 11:30:00+00', NULL, NULL, 0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO rd_owner.product VALUES ('4871fd4e-0c92-40be-9ca1-2707ab1b4a3f', 'cf9a05e9-2679-42da-b7d2-b34ea3e0724e', NULL, 'IELTS on Computer General Training R', NULL, '0ae29abe-5862-4c48-92e4-00d7eba376a2', false, 'R', 60, 'CD', false, '2020-07-01', '2099-12-31', 'PUBLISHED', 'Operations User', '2022-03-14 11:30:00+00', NULL, NULL, 0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO rd_owner.product VALUES ('b034eca1-0e06-4384-8ae5-e71af4d66bcb', 'cf9a05e9-2679-42da-b7d2-b34ea3e0724e', NULL, 'IELTS on Computer General Training W', NULL, '0ae29abe-5862-4c48-92e4-00d7eba376a2', false, 'W', 60, 'CD', false, '2020-07-01', '2099-12-31', 'PUBLISHED', 'Operations User', '2022-03-14 11:30:00+00', NULL, NULL, 0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO rd_owner.product VALUES ('be5f16d3-be46-4a6f-a3a5-268d5e1721cc', 'cf9a05e9-2679-42da-b7d2-b34ea3e0724e', NULL, 'IELTS on Computer General Training S', NULL, '0ae29abe-5862-4c48-92e4-00d7eba376a2', false, 'S', 20, 'CD', false, '2020-07-01', '2099-12-31', 'PUBLISHED', 'Operations User', '2022-03-14 11:30:00+00', NULL, NULL, 0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO rd_owner.product VALUES ('d96eece2-1d7c-495a-a754-6b523b710a82', '637f8e1b-0931-4184-9fed-37bc9fdb53d5', 'D902', 'IELTS Online General Training', NULL, '0ae29abe-5862-4c48-92e4-00d7eba376a2', true, NULL, NULL, 'CD', false, '2020-07-01', '2022-03-28', 'PUBLISHED', 'Operations User', '2020-07-13 05:30:00+00', NULL, NULL, 0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO rd_owner.product VALUES ('18c94472-35e8-4d89-93da-f6d9caa7f003', 'd96eece2-1d7c-495a-a754-6b523b710a82', NULL, 'IELTS Online General Training L', NULL, '0ae29abe-5862-4c48-92e4-00d7eba376a2', false, 'L', 35, 'CD', false, '2020-07-01', '2022-03-28', 'PUBLISHED', 'Operations User', '2020-07-13 05:30:00+00', NULL, NULL, 0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO rd_owner.product VALUES ('f21e2e7f-02e8-4bd7-9602-c247e8a02a5a', 'd96eece2-1d7c-495a-a754-6b523b710a82', NULL, 'IELTS Online General Training R', NULL, '0ae29abe-5862-4c48-92e4-00d7eba376a2', false, 'R', 60, 'CD', false, '2020-07-01', '2022-03-28', 'PUBLISHED', 'Operations User', '2020-07-13 05:30:00+00', NULL, NULL, 0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO rd_owner.product VALUES ('d8c32eff-1112-467b-a881-9e52f5acc796', 'd96eece2-1d7c-495a-a754-6b523b710a82', NULL, 'IELTS Online General Training W', NULL, '0ae29abe-5862-4c48-92e4-00d7eba376a2', false, 'W', 60, 'CD', false, '2020-07-01', '2022-03-28', 'PUBLISHED', 'Operations User', '2020-07-13 05:30:00+00', NULL, NULL, 0) ON CONFLICT(product_uuid) DO NOTHING;

INSERT INTO rd_owner.product VALUES ('48b0643a-11eb-4eff-b4e3-3f930c6fcdd3', 'd96eece2-1d7c-495a-a754-6b523b710a82', NULL, 'IELTS Online General Training S', NULL, '0ae29abe-5862-4c48-92e4-00d7eba376a2', false, 'S', 20, 'CD', false, '2020-07-01', '2022-03-28', 'PUBLISHED', 'Operations User', '2020-07-13 05:30:00+00', NULL, NULL, 0) ON CONFLICT(product_uuid) DO NOTHING;

