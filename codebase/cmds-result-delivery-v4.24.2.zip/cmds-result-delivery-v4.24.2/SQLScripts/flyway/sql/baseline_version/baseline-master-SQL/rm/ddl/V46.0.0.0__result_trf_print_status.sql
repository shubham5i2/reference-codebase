CREATE TABLE IF NOT EXISTS rd_owner.result_trf_print_status
(
    result_trf_print_status_uuid uuid NOT NULL,
    result_uuid uuid NOT NULL,
    printed_datetime TIMESTAMPTZ NOT NULL,
    print_count integer NOT NULL,
    results_rendition_uuid uuid NOT NULL,
    updated_datetime TIMESTAMPTZ NOT NULL,
    printed_by VARCHAR(100) NOT NULL,
	rendition_type_uuid uuid,
    CONSTRAINT pk_result_trf_print_status PRIMARY KEY (result_trf_print_status_uuid),
    CONSTRAINT uk_01_result_trf_print_status_result_uuid UNIQUE (result_uuid),
    CONSTRAINT fk_01_result_trf_print_status_result_result_uuid FOREIGN KEY (result_uuid)
        REFERENCES rd_owner.result (result_uuid),
    CONSTRAINT fk_02_result_trf_print_status_results_rendition_results_rendition_uuid FOREIGN KEY (results_rendition_uuid)
        REFERENCES rd_owner.results_rendition (results_rendition_uuid) 
);

