-- IELTS Result Delivery SQL scripts
\c rd

\i create_schema.sql
\i add_uuid_extension.sql

-- Booking DDL scripts
\ir booking//ddl//booking.sql
\ir booking//ddl//booking_line.sql

-- location DDL scripts
\ir referenceData//location//ddl//location.sql
\ir referenceData//location//ddl//organisation_type.sql

-- location DML scripts
\ir referenceData//location//dml//insert_organisation_type.sql

-- Module DDL scripts
\ir referenceData//moduleType//ddl//module_type.sql

-- Module DML scripts
\ir referenceData//moduleType//dml//insert_module_type.sql

-- Product DDL scripts
\ir referenceData//product//ddl//product.sql

-- Product DML scripts
\ir referenceData//product//dml//insert_product.sql

-- RO DDL scripts
\ir  ro//ddl//recognising_organisation.sql
\ir  ro//ddl//recognised_product.sql
\ir  ro//ddl//linked_recognising_organisation.sql

-- Rendition_Type DDL scripts
\ir referenceData//rendition//ddl//rendition_type.sql

-- Rendition_Type DML scripts
\ir referenceData//rendition//dml//insert_rendition_type.sql

-- Result DDL scripts
\ir  rm//ddl//result_type.sql
\ir  rm//ddl//results_status_type.sql
\ir  rm//ddl//results_status_label.sql
\ir  rm//ddl//result.sql
\ir  rm//ddl//result_line.sql
\ir  rm//ddl//result_delivery.sql
\ir  rm//ddl//results_rendition.sql

-- Result DML scripts
\ir rm//dml//insert_result_type.sql
\ir rm//dml//insert_result_status_type.sql
\ir rm//dml//insert_results_status_label.sql

-- Selection DDL scripts
\ir selection//ddl//selection.sql
\ir selection//ddl//minimum_score.sql

-- Gender DML and DDL scripts
\ir referenceData//gender//ddl/gender.sql
\ir referenceData//gender//dml/insert_gender.sql

-- Country DML and DDL scripts
\ir referenceData//country//ddl/country.sql
\ir referenceData//country//dml/insert_country.sql

-- Language DML and DDL scripts
\ir referenceData//language//ddl/language.sql
\ir referenceData//language//dml/insert_language.sql

-- Nationality DML and DDL scripts
\ir referenceData//nationality//ddl/nationality.sql
\ir referenceData//nationality//dml/insert_nationality.sql

-- TTPhoto DDL scripts
\ir ttPhoto//ddl//test_taker_photo.sql
\ir ttPhoto//ddl//test_taker_photo_type.sql

-- TTPhoto DML scripts
\ir ttPhoto//dml//insert_test_taker_photo_type.sql

-- Territory DDL scripts
\ir  referenceData//territory//ddl//territory.sql

-- Territory DML scripts
\ir referenceData//territory//dml//insert_territory.sql

-- RO Address DDL scripts
\ir  ro//ddl//recognising_organisation_address.sql

-- Address Type DDL and DML scripts
\ir  ro//ddl//address_type.sql
\ir  ro//dml//insert_address_type.sql

-- Result TRF Print Status DDL scripts
\ir  rm//ddl//result_trf_print_status.sql

-- Unverified Address DDL scripts
\ir  ro//ddl//unverified_address.sql

--Report Delivery Requested DDL scripts
\ir  rm//ddl//report_delivery_requested.sql




