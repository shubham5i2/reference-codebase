DO $$ BEGIN CREATE TYPE rd_owner.rendition_type_code AS ENUM (
	'TRF', 'ERESULT','ETRF'
    );
EXCEPTION
WHEN duplicate_object THEN null;
END $$;


-- Creating table for rendition_type_code
CREATE TABLE IF NOT EXISTS rd_owner.rendition_type(
    rendition_type_uuid UUID NOT NULL,
	rendition_type_code rd_owner.rendition_type_code NOT NULL,
	effective_from_date DATE NOT NULL DEFAULT '2020-12-01',
	effective_to_date  DATE NOT NULL DEFAULT '2099-12-31',
    CONSTRAINT rendition_type_code PRIMARY KEY (rendition_type_uuid)
    	);
		
		
		