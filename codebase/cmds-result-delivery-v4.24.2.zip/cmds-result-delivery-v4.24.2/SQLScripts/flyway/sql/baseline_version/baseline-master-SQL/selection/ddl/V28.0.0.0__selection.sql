-- Create EMUM Type for delivery_status
DO $$ BEGIN CREATE TYPE rd_owner.delivery_status AS ENUM (
    'UNDELIVERED', 'DELIVERY_PENDING', 'DELIVERY_REQUESTED', 'DELIVERED', 'REDELIVERY_REQUESTED', 'REDELIVERY_REQUEST_PENDING', 'REDELIVERED'
    );
EXCEPTION
WHEN duplicate_object THEN null;
END $$;

-- Create EMUM Type for confirmation_status
DO $$ BEGIN CREATE TYPE rd_owner.confirmation_status AS ENUM (
    'CONFIRMED', 'CONDITIONAL', 'WITHDRAWN', 'INVALID'
    );
EXCEPTION
WHEN duplicate_object THEN null;
END $$;

-- Create EMUM Type for minimum_score_satisfied
DO $$ BEGIN CREATE TYPE rd_owner.minimum_score_satisfied AS ENUM (
    'SATISFIED', 'UNSATISFIED', 'NOT_APPLICABLE'
    );
EXCEPTION
WHEN duplicate_object THEN null;
END $$;

-- Creating table for selection
CREATE TABLE IF NOT EXISTS rd_owner.selection(
    selection_uuid UUID NOT NULL,
    external_selection_uuid UUID NOT NULL,    
	recognising_organisation_uuid UUID,
	unverified_address_uuid UUID,
	external_booking_uuid UUID NOT NULL,
	external_booking_reference VARCHAR(100) NULL,
	selection_date TIMESTAMPTZ NOT NULL,
	delivery_status_changed_datetime TIMESTAMPTZ NOT NULL,
	confirmation_status_changed_datetime TIMESTAMPTZ NOT NULL,
	case_number VARCHAR(100) NULL,
	person_department VARCHAR(100) NULL,
	updated_datetime TIMESTAMPTZ NOT NULL,
	event_datetime TIMESTAMPTZ NOT NULL,
    concurrency_version INTEGER NOT NULL,
	overall_minimum_score NUMERIC(2, 1),
	delivery_status rd_owner.delivery_status NOT NULL,
	confirmation_status rd_owner.confirmation_status NOT NULL,
	minimum_score_satisfied rd_owner.minimum_score_satisfied NOT NULL,
	associated_selection_uuid uuid,
    CONSTRAINT pk_selection PRIMARY KEY (selection_uuid),
	CONSTRAINT uk_01_selection UNIQUE (external_selection_uuid),
	CONSTRAINT uk_02_selection_recognising_organisation_uuid_external_booking_ UNIQUE (recognising_organisation_uuid,external_booking_uuid)

	);
	
