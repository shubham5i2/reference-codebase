-- Table: rd_owner.product

-- Create Type for product table
DO $$ BEGIN
	CREATE TYPE rd_owner."component_type" AS ENUM
    ('R', 'L', 'W', 'S');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
	CREATE TYPE rd_owner."format_type" AS ENUM
    ('CD', 'PB');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Type Creation for Product Status Type
DO $$ BEGIN
	CREATE TYPE rd_owner.product_status_type AS ENUM
   	('DRAFT', 'PUBLISHED');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

--Create Table for Product

CREATE TABLE rd_owner.product (
    product_uuid uuid NOT NULL,
    parent_product_uuid uuid,
    legacy_product_id character varying(24),
    product_name character varying(100) NOT NULL,
    product_description character varying(1000),
    module_type_uuid uuid,
    bookable boolean NOT NULL,
    component rd_owner.component_type,
    duration integer,
    format rd_owner.format_type,
    approval_required boolean NOT NULL,
    available_from_date date NOT NULL,
    available_to_date date NOT NULL,
    product_status rd_owner.product_status_type NOT NULL,
    created_by character varying(36) NOT NULL,
    created_datetime timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by character varying(36),
    updated_datetime timestamp with time zone,
    concurrency_version integer NOT NULL,
	CONSTRAINT pk_product PRIMARY KEY (product_uuid),
	CONSTRAINT fk_01_product_product FOREIGN KEY (parent_product_uuid) REFERENCES rd_owner.product(product_uuid),
	CONSTRAINT fk_02_product_module_type FOREIGN KEY (module_type_uuid) REFERENCES rd_owner.module_type(module_type_uuid)
);

