--DML scripts for product_config UKVI IOC data 

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('25d08ffb-4dd9-4d82-89a6-314d6d012b6a',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        '6d04f596-22f2-49c4-9d47-85b167b8ca6f',
		'IDP',
		'UKVI_TRF_CD',
		'ACADEMIC');
		
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('a0d33c32-a5b8-44bd-9c9c-5ccd7a807a75',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        '54b9d8df-c07a-4cb4-b397-adc4faa87c3f',
		'IDP',
		'UKVI_TRF_CD',
		'GENERAL TRAINING');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('046f844f-7ddf-4f48-a5b8-8e7b237fad09',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        '6d04f596-22f2-49c4-9d47-85b167b8ca6f',
		'BC',
		'UKVI_TRF_CD',
		'ACADEMIC');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('74099209-6417-4891-a741-6b9262ff026d',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        '54b9d8df-c07a-4cb4-b397-adc4faa87c3f',
		'BC',
		'UKVI_TRF_CD',
		'GENERAL TRAINING');
		
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('14fc5a1f-a51c-4211-bd72-91aa48e3d491',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        '6d04f596-22f2-49c4-9d47-85b167b8ca6f',
		'IDP',
		'UKVI_ETRF_CD',
		'ACADEMIC');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('bb2c2582-6559-4ead-bd93-3067218e8ae3',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        '54b9d8df-c07a-4cb4-b397-adc4faa87c3f',
		'IDP',
		'UKVI_ETRF_CD',
		'GENERAL TRAINING');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('66b3532e-6921-480d-b9c2-8e8fb8a99da9',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        '6d04f596-22f2-49c4-9d47-85b167b8ca6f',
		'BC',
		'UKVI_ETRF_CD',
		'ACADEMIC');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('adca1ab5-9eaa-4646-b81c-1ddcf14d9124',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        '54b9d8df-c07a-4cb4-b397-adc4faa87c3f',
		'BC',
		'UKVI_ETRF_CD',
		'GENERAL TRAINING');