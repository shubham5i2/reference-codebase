UPDATE rd_owner.product SET available_to_date='2099-12-31' where product_uuid='637f8e1b-0931-4184-9fed-37bc9fdb53d5';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS Online AC', product_characteristics ='{"characteristics": ["IOL"],"RoAutoAccepted": ["FALSE"]}' where product_uuid='3e81e94b-8b6a-42b5-970c-b141f9d195a3';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS Online AC R', product_characteristics ='{"characteristics": ["IOL"]}' where product_uuid='4ddcb08b-c2c7-412a-9f59-f4adaf3aa131';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS Online AC W', product_characteristics ='{"characteristics": ["IOL"]}' where product_uuid='cb6f4028-c2d8-48f1-8006-1343760ec905';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS Online AC S', product_characteristics ='{"characteristics": ["IOL"]}' where product_uuid='fd01b36e-bb07-4229-81c2-483308787e9f';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS Online AC L', product_characteristics ='{"characteristics": ["IOL"]}' where product_uuid='0c6bc64c-fc66-4d5f-879d-89cdc6c3ed31';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS Online GT', product_characteristics ='{"characteristics": ["IOL"],"RoAutoAccepted": ["FALSE"]}' where product_uuid='d96eece2-1d7c-495a-a754-6b523b710a82';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS Online GT L', product_characteristics ='{"characteristics": ["IOL"]}' where product_uuid='18c94472-35e8-4d89-93da-f6d9caa7f003';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS Online GT R', product_characteristics ='{"characteristics": ["IOL"]}' where product_uuid='f21e2e7f-02e8-4bd7-9602-c247e8a02a5a';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS Online GT W', product_characteristics ='{"characteristics": ["IOL"]}' where product_uuid='d8c32eff-1112-467b-a881-9e52f5acc796';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS Online GT S', product_characteristics ='{"characteristics": ["IOL"]}' where product_uuid='48b0643a-11eb-4eff-b4e3-3f930c6fcdd3';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR Online AC', product_characteristics ='{"characteristics": ["IOL", "OSR", "SSR"],"RoAutoAccepted": ["FALSE"]}' where product_uuid='6d28d524-472d-4d53-8fd9-dc7c4bb5325d';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR Online AC R', product_characteristics ='{"characteristics": ["IOL", "OSR", "SSR"]}' where product_uuid='95fa3301-e17c-4467-bab5-f4754765ad4d';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR Online AC W', product_characteristics ='{"characteristics": ["IOL", "OSR", "SSR"]}' where product_uuid='9cdec6ab-7886-476a-a586-13dfda9a52a9';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR Online AC S', product_characteristics ='{"characteristics": ["IOL", "OSR", "SSR"]}' where product_uuid='deea53e9-886b-4dee-b0b2-9ab29c70a82e';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR Online AC L', product_characteristics ='{"characteristics": ["IOL", "OSR", "SSR"]}' where product_uuid='bb71c4bb-ba26-4569-99fa-fb3d2aec1120';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR Online GT', product_characteristics ='{"characteristics": ["IOL", "OSR", "SSR"],"RoAutoAccepted": ["FALSE"]}' where product_uuid='7b1d8d96-c314-40cd-a61c-2b681086a458';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR Online GT L', product_characteristics ='{"characteristics": ["IOL", "OSR", "SSR"]}' where product_uuid='304d2fa4-642d-4ec7-8600-ae21eb8b4dd8';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR Online GT R', product_characteristics ='{"characteristics": ["IOL", "OSR", "SSR"]}' where product_uuid='d5d4392d-b3c7-4a99-b039-98a281c0104d';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR Online GT W', product_characteristics ='{"characteristics": ["IOL", "OSR", "SSR"]}' where product_uuid='c5524e22-ec61-4705-b7d1-5818826b7cd1';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR Online GT S', product_characteristics ='{"characteristics": ["IOL", "OSR", "SSR"]}' where product_uuid='a489fddd-9bb5-4ed4-9678-0a88bde4778c';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS SELT Online AC', product_characteristics ='{"characteristics": ["IOL", "SELT"],"RoAutoAccepted": ["FALSE"]}' where product_uuid='4ca26fd2-5216-4e9a-ba08-89bb94599778';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS SELT Online AC R', product_characteristics ='{"characteristics": ["IOL", "SELT"]}' where product_uuid='6d79a787-f2aa-4937-ad65-6e6fc8c7b9ab';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS SELT Online AC W', product_characteristics ='{"characteristics": ["IOL", "SELT"]}' where product_uuid='b0a52175-dc8d-43c0-a5ce-01daa3a3e460';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS SELT Online AC S', product_characteristics ='{"characteristics": ["IOL", "SELT"]}' where product_uuid='71e8956f-eb04-4390-aaa5-7f0fb1b5f1ac';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS SELT Online AC L', product_characteristics ='{"characteristics": ["IOL", "SELT"]}' where product_uuid='04ffa164-b36c-4cb8-a949-e1a20d5e38b3';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS SELT Online GT', product_characteristics ='{"characteristics": ["IOL", "SELT"],"RoAutoAccepted": ["FALSE"]}' where product_uuid='0b0e3eb3-7929-4e38-bc63-dea6ffe6def8';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS SELT Online GT L', product_characteristics ='{"characteristics": ["IOL", "SELT"]}' where product_uuid='f828ebe4-e0dd-4060-8cf7-6afbfc47b326';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS SELT Online GT R', product_characteristics ='{"characteristics": ["IOL", "SELT"]}' where product_uuid='91f1dbd5-e455-4067-b7fb-3fdbaac0107f';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS SELT Online GT W', product_characteristics ='{"characteristics": ["IOL", "SELT"]}' where product_uuid='d2e559ef-859c-465d-ba90-f85b1cbf3f02';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS SELT Online GT S', product_characteristics ='{"characteristics": ["IOL", "SELT"]}' where product_uuid='d0fa4932-4aa0-45fc-8234-24bb967b49e5';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR SELT Online AC', product_characteristics ='{"characteristics": ["IOL", "SELT","OSR", "SSR"],"RoAutoAccepted": ["FALSE"]}' where product_uuid='2948e48b-519b-484e-aed9-93a30a8a9485';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR SELT Online AC R', product_characteristics ='{"characteristics": ["IOL", "SELT","OSR", "SSR"]} ' where product_uuid='29689961-a480-4860-b6e2-d1e2bafaacc2';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR SELT Online AC W', product_characteristics ='{"characteristics": ["IOL", "SELT","OSR", "SSR"]} ' where product_uuid='6fa5a6a4-7b2a-44fd-a7d2-b5dd280c3804';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR SELT Online AC S', product_characteristics ='{"characteristics": ["IOL", "SELT","OSR", "SSR"]} ' where product_uuid='b41a4d86-9f98-43e7-ad13-0dbedf9c9a18';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR SELT Online AC L', product_characteristics ='{"characteristics": ["IOL", "SELT","OSR", "SSR"]} ' where product_uuid='2aef48a5-b42a-47bd-9a7a-19a99bb64dde';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR SELT Online GT', product_characteristics ='{"characteristics": ["IOL", "SELT","OSR", "SSR"],"RoAutoAccepted": ["FALSE"]}' where product_uuid='58c171e7-6789-498c-9e2e-e26f4bf8c90c';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR SELT Online GT L', product_characteristics ='{"characteristics": ["IOL", "SELT","OSR", "SSR"]} ' where product_uuid='2352424a-1806-4c81-8a4e-3a674d12eed9';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR SELT Online GT R', product_characteristics ='{"characteristics": ["IOL", "SELT","OSR", "SSR"]} ' where product_uuid='11f076ba-a9af-4d7a-81de-fb910f45339e';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR SELT Online GT W', product_characteristics ='{"characteristics": ["IOL", "SELT","OSR", "SSR"]} ' where product_uuid='9fa3a10f-0e6f-4b4d-9ea9-35fafa4cf665';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR SELT Online GT S', product_characteristics ='{"characteristics": ["IOL", "SELT","OSR", "SSR"]} ' where product_uuid='a4dd69cc-65ce-423a-a3ee-331228c8e97b';

UPDATE rd_owner.product SET available_to_date='2099-12-31' where product_uuid='5dee6f91-b15c-4e7a-8bd8-bdced2bcc5f0';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS on Computer AC', product_characteristics ='{"characteristics": ["IOC"],"RoAutoAccepted": ["TRUE"]}' where product_uuid='fdbacec5-e80a-4710-b3de-7d5f310b1466';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS on Computer AC L', product_characteristics ='{"characteristics": ["IOC"]}' where product_uuid='6ccd6696-0660-409c-8a66-85d79c42f84d';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS on Computer AC R', product_characteristics ='{"characteristics": ["IOC"]}' where product_uuid='d40d2104-a610-42dc-936b-263fb4ba120a';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS on Computer AC W', product_characteristics ='{"characteristics": ["IOC"]}' where product_uuid='f0ea4e6f-d550-4687-a231-1032a7987441';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS on Computer AC S', product_characteristics ='{"characteristics": ["IOC"]}' where product_uuid='43215312-a604-4cbf-8b97-c3695b03e396';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS on Computer GT', product_characteristics ='{"characteristics": ["IOC"],"RoAutoAccepted": ["TRUE"]}' where product_uuid='cf9a05e9-2679-42da-b7d2-b34ea3e0724e';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS on Computer GT L', product_characteristics ='{"characteristics": ["IOC"]}' where product_uuid='df2c8f7e-e485-441b-88a5-34b640bff6a5';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS on Computer GT R', product_characteristics ='{"characteristics": ["IOC"]}' where product_uuid='4871fd4e-0c92-40be-9ca1-2707ab1b4a3f';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS on Computer GT W', product_characteristics ='{"characteristics": ["IOC"]}' where product_uuid='b034eca1-0e06-4384-8ae5-e71af4d66bcb';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS on Computer GT S', product_characteristics ='{"characteristics": ["IOC"]}' where product_uuid='be5f16d3-be46-4a6f-a3a5-268d5e1721cc';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS OSR on Computer AC', product_characteristics ='{"characteristics": ["IOC", "OSR", "SSR"],"RoAutoAccepted": ["FALSE"]}' where product_uuid='cb7cd48c-5e79-4a28-8104-e0bcd8e39999';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS OSR on Computer AC R', product_characteristics ='{"characteristics": ["IOC", "OSR", "SSR"]}' where product_uuid='6b2c8f4a-e94f-44c8-8575-22987e5aef17';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS OSR on Computer AC W', product_characteristics ='{"characteristics": ["IOC", "OSR", "SSR"]}' where product_uuid='bb1895b0-f302-4e4c-8bc9-07265f0eadd7';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS OSR on Computer AC S', product_characteristics ='{"characteristics": ["IOC", "OSR", "SSR"]}' where product_uuid='ff045df4-8c11-4bd8-b2d3-a94aa56a7877';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS OSR on Computer AC L', product_characteristics ='{"characteristics": ["IOC", "OSR", "SSR"]}' where product_uuid='17e0db26-7f58-40ae-b5a8-999fb68dca96';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS OSR on Computer GT', product_characteristics ='{"characteristics": ["IOC", "OSR", "SSR"],"RoAutoAccepted": ["FALSE"]}' where product_uuid='c37e2fab-898d-46d4-a61b-17f24bb29e83';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS OSR on Computer GT L', product_characteristics ='{"characteristics": ["IOC", "OSR", "SSR"]}' where product_uuid='e1d9b3fb-d428-4342-9656-50470cde4c39';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS OSR on Computer GT R', product_characteristics ='{"characteristics": ["IOC", "OSR", "SSR"]}' where product_uuid='74193427-ccae-4227-8577-9950c9f79d47';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS OSR on Computer GT W', product_characteristics ='{"characteristics": ["IOC", "OSR", "SSR"]}' where product_uuid='64ada755-5cb3-46ed-b90c-69bd88230402';

UPDATE rd_owner.product SET available_to_date='2099-12-31', product_name='IELTS OSR on Computer GT S', product_characteristics ='{"characteristics": ["IOC", "OSR", "SSR"]}' where product_uuid='4acd484a-958c-42f1-9cdd-fc5f8e12d5da';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS SELT on Computer AC', product_characteristics ='{"characteristics": ["IOC", "SELT"],"RoAutoAccepted": ["TRUE"]}' where product_uuid='6d04f596-22f2-49c4-9d47-85b167b8ca6f';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS SELT on Computer AC R', product_characteristics ='{"characteristics": ["IOC", "SELT"]}' where product_uuid='15d0e10b-9046-40ba-a9d5-a5fdacbdf29d';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS SELT on Computer AC W', product_characteristics ='{"characteristics": ["IOC", "SELT"]}' where product_uuid='76f5c60e-4ea1-451c-89c5-8ad2adad6ea3';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS SELT on Computer AC S', product_characteristics ='{"characteristics": ["IOC", "SELT"]}' where product_uuid='ae943abe-3d6b-48d3-a841-064515f13db1';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS SELT on Computer AC L', product_characteristics ='{"characteristics": ["IOC", "SELT"]}' where product_uuid='d9caf654-789a-4b50-a5e3-7123c365b92d';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS SELT on Computer GT', product_characteristics ='{"characteristics": ["IOC", "SELT"],"RoAutoAccepted": ["TRUE"]}' where product_uuid='54b9d8df-c07a-4cb4-b397-adc4faa87c3f';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS SELT on Computer GT L', product_characteristics ='{"characteristics": ["IOC", "SELT"]}' where product_uuid='9e8b80f8-c697-4c88-959d-4875b265b927';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS SELT on Computer GT R', product_characteristics ='{"characteristics": ["IOC", "SELT"]}' where product_uuid='a9610d1d-124d-4d58-8468-b921202ca1ee';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS SELT on Computer GT W', product_characteristics ='{"characteristics": ["IOC", "SELT"]}' where product_uuid='7cc8a727-4671-4b5a-b0fd-60c08b3a023b';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS SELT on Computer GT S', product_characteristics ='{"characteristics": ["IOC", "SELT"]}' where product_uuid='169ba597-2638-4ddf-b245-15f390397d9a';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR SELT on Computer AC', product_characteristics ='{"characteristics": ["IOC", "SELT","OSR", "SSR"],"RoAutoAccepted": ["FALSE"]}' where product_uuid='de58e8e0-39c6-4c54-b62e-40cacbc6c56d';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR SELT on Computer AC R', product_characteristics ='{"characteristics": ["IOC", "SELT","OSR", "SSR"]} ' where product_uuid='d8f6415d-c36f-4a2c-9c44-bbf0e4c65530';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR SELT on Computer AC W', product_characteristics ='{"characteristics": ["IOC", "SELT","OSR", "SSR"]} ' where product_uuid='edd31fef-dd28-4c0a-a593-3cd3b1b74838';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR SELT on Computer AC S', product_characteristics ='{"characteristics": ["IOC", "SELT","OSR", "SSR"]} ' where product_uuid='c3e46fcc-b54f-49ae-8675-e373db8e6dc2';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR SELT on Computer AC L', product_characteristics ='{"characteristics": ["IOC", "SELT","OSR", "SSR"]} ' where product_uuid='7768ff79-1c44-4b7d-818f-a935afcb9d94';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR SELT on Computer GT', product_characteristics ='{"characteristics": ["IOC", "SELT","OSR", "SSR"],"RoAutoAccepted": ["FALSE"]}' where product_uuid='fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR SELT on Computer GT L', product_characteristics ='{"characteristics": ["IOC", "SELT","OSR", "SSR"]} ' where product_uuid='42c488cc-2230-4842-b2aa-fe103f006aa7';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR SELT on Computer GT R', product_characteristics ='{"characteristics": ["IOC", "SELT","OSR", "SSR"]} ' where product_uuid='b6e7b55e-c21e-4002-8c0b-a9f66f8bce61';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR SELT on Computer GT W', product_characteristics ='{"characteristics": ["IOC", "SELT","OSR", "SSR"]} ' where product_uuid='a6bf0168-7ed0-49b9-959b-d526ff1087fa';

UPDATE rd_owner.product SET available_to_date='2022-03-28', product_name='IELTS OSR SELT on Computer GT S', product_characteristics ='{"characteristics": ["IOC", "SELT","OSR", "SSR"]} ' where product_uuid='e73dbfad-a961-4c7e-9fba-e196a2703bb8';
