CREATE INDEX IF NOT EXISTS idx_booking_line_booking_uuid ON rd_owner.booking_line(booking_uuid);

CREATE INDEX IF NOT EXISTS idx_result_line_result_uuid ON rd_owner.result_line(result_uuid);

CREATE INDEX IF NOT EXISTS idx_outbox_event_attribute_outbox_event_uuid ON rd_owner.outbox_event_attribute(outbox_event_uuid);

CREATE INDEX IF NOT EXISTS idx_recognised_product_recognising_organisation_uuid ON rd_owner.recognised_product(recognising_organisation_uuid);
