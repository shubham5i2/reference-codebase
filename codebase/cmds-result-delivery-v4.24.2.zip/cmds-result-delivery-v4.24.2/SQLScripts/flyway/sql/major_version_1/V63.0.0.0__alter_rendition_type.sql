alter table rd_owner.rendition_type add column effective_to_date DATE NOT NULL DEFAULT '2099-12-31';

alter table rd_owner.rendition_type add column effective_from_date DATE NOT NULL DEFAULT '2020-12-01'