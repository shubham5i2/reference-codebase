--DML scripts for product_config UKVI IOC CHINA data 

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('eb0720cd-0b25-40eb-856b-64e3a1fce5e9',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        '6d04f596-22f2-49c4-9d47-85b167b8ca6f',
		'BC_CHN',
		'UKVI_TRF_CD',
		'ACADEMIC');
		
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('c6ab4d9c-7ced-443a-a202-ad1128fff9ce',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        '54b9d8df-c07a-4cb4-b397-adc4faa87c3f',
		'BC_CHN',
		'UKVI_TRF_CD',
		'GENERAL TRAINING');

		
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('1b8c9241-654e-43e3-af9d-878921cf88c3',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        '6d04f596-22f2-49c4-9d47-85b167b8ca6f',
		'BC_CHN',
		'UKVI_ETRF_CD',
		'ACADEMIC');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('a4059c4f-6c1a-4e09-b4e8-7d25fc18dfab',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        '54b9d8df-c07a-4cb4-b397-adc4faa87c3f',
		'BC_CHN',
		'UKVI_ETRF_CD',
		'GENERAL TRAINING');
