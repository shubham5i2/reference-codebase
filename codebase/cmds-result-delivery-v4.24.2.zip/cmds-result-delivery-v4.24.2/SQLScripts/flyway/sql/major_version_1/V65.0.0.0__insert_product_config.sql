--DML scripts for product_config table 
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('57eabf3f-ac5f-495c-89a3-24dd059d90ae',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        'fdbacec5-e80a-4710-b3de-7d5f310b1466',
		'IDP',
		'TRF_CD_AC',
		'ACADEMIC');


INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('ace7123a-4119-4332-b0a3-9ffd2566ca37',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        'cf9a05e9-2679-42da-b7d2-b34ea3e0724e',
		'IDP',
		'TRF_CD_GT',
		'GENERAL TRAINING');
		


INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('62989961-747d-45bf-9d49-50c5681a3883',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        '3e81e94b-8b6a-42b5-970c-b141f9d195a3',
		'IDP',
		'TRF_IOL_AC',
		'ACADEMIC');


INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('0fa04f81-d64b-4cf7-a5b7-013b792218f0',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        'd96eece2-1d7c-495a-a754-6b523b710a82',
		'IDP',
		'TRF_IOL_GT',
		'GENERAL TRAINING');
	
		
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('05b0a41b-b3b2-4d11-9afa-f55ece09199d',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        'fdbacec5-e80a-4710-b3de-7d5f310b1466',
		'BC',
		'TRF_CD_AC',
		'ACADEMIC');
		
		
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('5649c572-fb02-440c-941e-a28d2feb1460',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        'cf9a05e9-2679-42da-b7d2-b34ea3e0724e',
		'BC',
		'TRF_CD_GT',
		'GENERAL TRAINING');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('aed153ee-77d5-4091-9792-f0c881b0fc9c',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        '3e81e94b-8b6a-42b5-970c-b141f9d195a3',
		'BC',
		'TRF_IOL_AC',
		'ACADEMIC');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('3e1bf54c-10aa-42f7-bc76-75c2212d41b8',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        'd96eece2-1d7c-495a-a754-6b523b710a82',
		'BC',
		'TRF_IOL_GT',
		'GENERAL TRAINING');
		

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('e43b0e51-ccdd-4dc1-803b-b3d14b751747',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        'fdbacec5-e80a-4710-b3de-7d5f310b1466',
		'IDP',
		'ETRF_CD_AC',
		'ACADEMIC');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('edc3d2b5-8f8b-458c-b5dd-85d941881802',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        'cf9a05e9-2679-42da-b7d2-b34ea3e0724e',
		'IDP',
		'ETRF_CD_GT',
		'GENERAL TRAINING');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('50ecccf8-6488-4d8c-a14c-1e4fde394aad',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        'cf9a05e9-2679-42da-b7d2-b34ea3e0724e',
		'IDP',
		'ETRF_IOL_AC',
		'ACADEMIC');

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('12cde761-b605-478c-a384-b9215f8591af',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        'd96eece2-1d7c-495a-a754-6b523b710a82',
		'IDP',
		'ETRF_IOL_GT',
		'GENERAL TRAINING');
		
		

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('83805b6d-75ff-42c9-8312-90d6683012c2',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        'fdbacec5-e80a-4710-b3de-7d5f310b1466',
		'BC',
		'ETRF_CD_AC',
		'ACADEMIC');
		

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('c123ee34-2fd7-4bf3-bc21-08eb4966de41',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        'cf9a05e9-2679-42da-b7d2-b34ea3e0724e',
		'BC',
		'ETRF_CD_GT',
		'GENERAL TRAINING');
		

INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('6d7e2bb6-1734-4540-befd-e34574ff2148',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        '3e81e94b-8b6a-42b5-970c-b141f9d195a3',
		'BC',
		'ETRF_IOL_AC',
		'ACADEMIC');
		
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('e00fa445-dd05-4195-a018-76536e6fb090',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        'd96eece2-1d7c-495a-a754-6b523b710a82',
		'BC',
		'ETRF_IOL_GT',
		'GENERAL TRAINING');
		


