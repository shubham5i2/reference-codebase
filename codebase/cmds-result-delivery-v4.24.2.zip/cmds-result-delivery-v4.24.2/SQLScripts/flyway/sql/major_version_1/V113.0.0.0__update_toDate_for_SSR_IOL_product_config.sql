update rd_owner.product_config set effective_to_date = '2099-12-31' where template_name like '%SSR_IOL%';
