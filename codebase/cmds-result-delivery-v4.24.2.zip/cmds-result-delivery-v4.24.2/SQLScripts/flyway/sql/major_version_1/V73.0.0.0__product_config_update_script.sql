update rd_owner.product_config set photo_type = 'TT_P_HR_IAM' where template_name LIKE '%CD%';
update rd_owner.product_config set photo_type = 'TT_P_LR_LRW_WC' where template_name LIKE '%IOL%';