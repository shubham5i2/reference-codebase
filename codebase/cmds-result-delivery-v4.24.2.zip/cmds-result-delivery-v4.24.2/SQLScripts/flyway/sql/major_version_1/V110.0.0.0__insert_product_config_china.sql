--ETRF-IOL-GT
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('dbfcef1b-ebc3-4e66-9901-3b5ec6a78f5a',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        'cf9a05e9-2679-42da-b7d2-b34ea3e0724e',
		'BC_CHN',
		'ETRF_CD',
		'GENERAL TRAINING');

--TRF-IOL-GT
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('702dbb64-5cb4-4248-a013-b6f873318ed9',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        'cf9a05e9-2679-42da-b7d2-b34ea3e0724e',
		'BC_CHN',
		'TRF_CD',
		'GENERAL TRAINING');

--ETRF-CD-AC		
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('d7a01b01-06cd-4401-a227-5fe60f4640e0',
        '15b2e233-81a4-4263-b327-9b47ba09eb01',
        'fdbacec5-e80a-4710-b3de-7d5f310b1466',
		'BC_CHN',
		'ETRF_CD',
		'ACADEMIC');
	
--TRF-CD-AC		
INSERT INTO rd_owner.product_config  (product_config_uuid, rendition_type_uuid , product_uuid, partner_code , template_name , report_module_name)
VALUES ('152fbb39-0460-44df-a762-b0026ba22085',
        '14fedb8c-5639-4f8b-95d1-345b8f0cd0ce',
        'fdbacec5-e80a-4710-b3de-7d5f310b1466',
		'BC_CHN',
		'TRF_CD',
		'ACADEMIC');