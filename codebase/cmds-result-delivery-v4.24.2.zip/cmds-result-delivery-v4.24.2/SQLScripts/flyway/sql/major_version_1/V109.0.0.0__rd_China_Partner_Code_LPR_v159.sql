CREATE TABLE IF NOT EXISTS rd_owner.partner
(
    partner_uuid uuid NOT NULL,
    partner_code character varying(20) NOT NULL,
    partner_name character varying(50) NOT NULL,
    effective_from_date date NOT NULL,
    effective_to_date date NOT NULL DEFAULT '2099-12-31'::date,
    created_by character varying(36) NOT NULL,
    created_datetime timestamp with time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_by character varying(36),
    updated_datetime timestamp with time zone,
    concurrency_version integer NOT NULL DEFAULT 0,
    CONSTRAINT pk_partner PRIMARY KEY (partner_uuid),
    CONSTRAINT partner_partner_code_key UNIQUE (partner_code)
);

INSERT INTO rd_owner.partner (partner_uuid, partner_code, partner_name, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('c39eb8a4-6127-4236-8363-deae1c01dd83','GLOBAL_IELTS','Global IELTS','01/07/2020','Operations User',NULL,NULL) ON CONFLICT(partner_uuid) DO NOTHING;

INSERT INTO rd_owner.partner (partner_uuid, partner_code, partner_name, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('8a37c2fc-edd2-44c2-960b-d8de98dade28','BC','British Council','01/07/2020','Operations User',NULL,NULL) ON CONFLICT(partner_uuid) DO NOTHING;

INSERT INTO rd_owner.partner (partner_uuid, partner_code, partner_name, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('945a233a-6779-43a1-be88-dc97b9b36509','IDP','IDP','01/07/2020','Operations User',NULL,NULL) ON CONFLICT(partner_uuid) DO NOTHING;

INSERT INTO rd_owner.partner (partner_uuid, partner_code, partner_name, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('6889087c-d81d-4461-a734-477a056c7d89','CA','UCLES','01/07/2020','Operations User',NULL,NULL) ON CONFLICT(partner_uuid) DO NOTHING;

INSERT INTO rd_owner.partner (partner_uuid, partner_code, partner_name, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('8bf20f44-b5d4-4234-8f8d-93d5045d0588','IELTS_USA','CEII','01/07/2020','Operations User',NULL,NULL) ON CONFLICT(partner_uuid) DO NOTHING;

INSERT INTO rd_owner.partner (partner_uuid, partner_code, partner_name, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('e28e8ca3-0545-43cd-9678-aae1c9eb0171','BC_CHN','British Council China','01/01/2023','Operations User',NULL,NULL) ON CONFLICT(partner_uuid) DO NOTHING;
