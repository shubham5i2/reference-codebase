UPDATE rd_owner.product_config
SET template_name = REPLACE(template_name, '_AC', '')
WHERE template_name like '%_AC';

UPDATE rd_owner.product_config
SET template_name = REPLACE(template_name, '_GT', '')
WHERE template_name like '%_GT'