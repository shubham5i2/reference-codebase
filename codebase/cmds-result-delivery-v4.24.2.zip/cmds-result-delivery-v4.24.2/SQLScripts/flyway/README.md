This flyway folder is created as part of flyway integration to automate db scripts execution in all the environments.

Confluence page reference: https://confluence.britishcouncil.org/pages/viewpage.action?spaceKey=IMPS&title=1.1.1+-+Refactoring+existing+source+code