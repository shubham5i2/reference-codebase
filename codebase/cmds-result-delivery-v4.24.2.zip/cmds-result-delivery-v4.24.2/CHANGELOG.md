### [4.24.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.24.1...v4.24.2) (2023-04-28)

### [4.24.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.24.0...v4.24.1) (2023-04-28)

## [4.24.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.23.0...v4.24.0) (2023-04-25)

### [4.14.1-hotfix.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.14.1-hotfix.3...v4.14.1-hotfix.4) (2023-04-06)

### [4.14.1-hotfix.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.14.1-hotfix.2...v4.14.1-hotfix.3) (2023-04-06)

### [4.14.1-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.14.1-hotfix.1...v4.14.1-hotfix.2) (2023-02-24)

### [4.14.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.14.0...v4.14.1-hotfix.1) (2023-02-22)

## [4.23.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.22.0...v4.23.0) (2023-04-10)

## [4.22.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.21.1...v4.22.0) (2023-04-06)

### [4.14.1-hotfix.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.14.1-hotfix.2...v4.14.1-hotfix.3) (2023-04-06)

### [4.14.1-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.14.1-hotfix.1...v4.14.1-hotfix.2) (2023-02-24)

### [4.14.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.14.0...v4.14.1-hotfix.1) (2023-02-22)

### [4.21.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.21.0...v4.21.1) (2023-02-27)

### [4.14.1-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.14.1-hotfix.1...v4.14.1-hotfix.2) (2023-02-24)

### [4.14.1-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.14.0...v4.14.1-hotfix.1) (2023-02-22)

## [4.21.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.20.0...v4.21.0) (2023-02-27)

## [4.20.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.19.1...v4.20.0) (2023-02-21)

### [4.19.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.19.0...v4.19.1) (2023-02-10)

## [4.19.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.18.0...v4.19.0) (2023-02-02)

## [4.18.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.17.0...v4.18.0) (2023-02-01)

## [4.17.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.16.0...v4.17.0) (2023-01-30)

## [4.16.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.15.1...v4.16.0) (2023-01-30)

### [4.15.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.15.0...v4.15.1) (2023-01-30)


### ⚠ BREAKING CHANGES

* Update lpr events to accept BC_CHN

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery!397

* Merge branch 'feature/BC_CHN_lpr_events_change' into 'develop' ([7bcdaf5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/commit/7bcdaf508ca2d82b2748a149fca6059028ad83fd))

## [4.15.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.14.1...v4.15.0) (2023-01-25)

### [4.14.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.14.0...v4.14.1) (2023-01-24)

## [4.14.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.13.2...v4.14.0) (2023-01-17)

### [4.13.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.13.1...v4.13.2) (2023-01-06)

### [4.13.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.13.0...v4.13.1) (2023-01-04)

## [4.13.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.12.0...v4.13.0) (2022-12-13)

## [4.12.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.11.4...v4.12.0) (2022-11-22)

### [4.11.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.11.3...v4.11.4) (2022-11-18)

### [4.11.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.11.2...v4.11.3) (2022-11-10)

### [4.11.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.11.1...v4.11.2) (2022-11-09)

### [4.11.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.11.0...v4.11.1) (2022-11-07)

## [4.11.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.10.0...v4.11.0) (2022-11-02)

## [4.10.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.9.8...v4.10.0) (2022-10-26)

### [4.9.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.9.7...v4.9.8) (2022-10-21)

### [4.9.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.9.6...v4.9.7) (2022-10-18)

### [4.9.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.9.5...v4.9.6) (2022-10-18)

### [4.9.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.9.4...v4.9.5) (2022-10-13)

### [4.9.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.9.3...v4.9.4) (2022-10-12)

### [4.9.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.9.2...v4.9.3) (2022-10-12)

### [4.9.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.9.1...v4.9.2) (2022-10-07)


### ⚠ BREAKING CHANGES

* Branch to create release version for IMOD-36596- Hotfix- admin signature field templates in SIT (Dummy Changes)

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery!358
* IMOD-36596- Prod Hotfix- admin signature field templates

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery!356

* Merge branch 'feature/branch_to_create_release' into 'develop' ([ccad072](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/commit/ccad0727a9a39703802cc4a57e5da0766f6afe8d))
* Merge branch 'hotfix' into 'develop' ([874265d](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/commit/874265d71a74225e3b8a4212390be724afe4ceb5))

### [4.1.5-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.1.4...v4.1.5-hotfix.1) (2022-10-07)

### [4.9.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.9.0...v4.9.1) (2022-09-26)

## [4.9.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.8.0...v4.9.0) (2022-09-23)

## [4.8.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.7.0...v4.8.0) (2022-09-22)

## [4.7.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.6.0...v4.7.0) (2022-09-22)

## [4.6.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.5.2...v4.6.0) (2022-09-21)

### [4.5.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.5.1...v4.5.2) (2022-09-20)

### [4.5.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.5.0...v4.5.1) (2022-09-20)

## [4.5.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.4.0...v4.5.0) (2022-09-19)

## [4.4.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.3.1...v4.4.0) (2022-09-19)

### [4.3.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.3.0...v4.3.1) (2022-09-19)

## [4.3.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.2.0...v4.3.0) (2022-09-16)

## [4.2.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.1.4...v4.2.0) (2022-09-14)

### [4.1.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.1.3...v4.1.4) (2022-09-12)

### [4.1.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.1.2...v4.1.3) (2022-09-01)

### [4.1.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.1.1...v4.1.2) (2022-08-30)

### [4.1.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.1.0...v4.1.1) (2022-08-26)

## [4.1.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v4.0.0...v4.1.0) (2022-08-25)

## [4.0.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.11.1...v4.0.0) (2022-08-24)

### [3.11.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.11.0...v3.11.1) (2022-08-18)

## [3.11.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.10.1...v3.11.0) (2022-08-10)

### [3.10.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.10.0...v3.10.1) (2022-08-10)

## [3.10.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.9.4...v3.10.0) (2022-08-09)

### [3.9.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.9.3...v3.9.4) (2022-08-09)

### [3.9.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.9.2...v3.9.3) (2022-08-09)

### [3.9.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.9.1...v3.9.2) (2022-08-09)

### [3.9.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.9.0...v3.9.1) (2022-08-09)

## [3.9.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.8.1...v3.9.0) (2022-08-08)

### [3.8.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.8.0...v3.8.1) (2022-08-05)

## [3.8.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.7.0...v3.8.0) (2022-08-02)

## [3.7.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.6.1...v3.7.0) (2022-07-29)

### [3.6.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.6.0...v3.6.1) (2022-07-28)

## [3.6.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.5.1...v3.6.0) (2022-07-26)

### [3.5.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.5.0...v3.5.1) (2022-07-26)

## [3.5.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.4.0...v3.5.0) (2022-07-26)

## [3.4.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.3.0...v3.4.0) (2022-07-26)

## [3.3.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.2.0...v3.3.0) (2022-07-26)

## [3.2.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.1.0...v3.2.0) (2022-07-25)

## [3.1.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v3.0.0...v3.1.0) (2022-07-25)

## [3.0.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.10.0...v3.0.0) (2022-07-25)

## [2.10.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.9.0...v2.10.0) (2022-07-22)

## [2.9.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.8.0...v2.9.0) (2022-07-18)

## [2.8.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.7.0...v2.8.0) (2022-07-15)

## [2.7.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.6.0...v2.7.0) (2022-07-12)

## [2.6.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.5.1...v2.6.0) (2022-07-11)

### [2.5.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.5.0...v2.5.1) (2022-07-08)

## [2.5.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.4.0...v2.5.0) (2022-07-05)

## [2.4.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.3.3...v2.4.0) (2022-06-27)

### [2.3.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.3.2...v2.3.3) (2022-06-21)

### [2.3.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.3.1...v2.3.2) (2022-06-20)

### [2.3.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.3.0...v2.3.1) (2022-06-14)

## [2.3.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.2.0...v2.3.0) (2022-06-14)

## [2.2.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.1.7...v2.2.0) (2022-06-14)

### [2.1.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.1.6...v2.1.7) (2022-06-14)


### ⚠ BREAKING CHANGES

* DB CI CD Implementation

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery!265

* Merge branch 'feature/IMOD-30940_rd_db_pipeline' into 'develop' ([4e04d5c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/commit/4e04d5c34a35665b6468b17c87c81906a8f85b1f))

### [2.1.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.1.5...v2.1.6) (2022-06-08)

### [2.1.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.1.4...v2.1.5) (2022-06-08)

### [2.1.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.1.3...v2.1.4) (2022-06-06)

### [2.1.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.1.2...v2.1.3) (2022-06-06)

### [2.1.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.1.1...v2.1.2) (2022-05-18)

### [2.1.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.1.0...v2.1.1) (2022-05-17)

## [2.1.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.0.4...v2.1.0) (2022-05-16)

### [2.0.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.0.3...v2.0.4) (2022-05-16)

### [2.0.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.0.2...v2.0.3) (2022-05-16)

### [2.0.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.0.1...v2.0.2) (2022-05-13)

### [2.0.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v2.0.0...v2.0.1) (2022-05-11)

## [2.0.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.44.0...v2.0.0) (2022-05-10)

## [1.44.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.43.4...v1.44.0) (2022-04-28)

### [1.43.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.43.3...v1.43.4) (2022-04-21)

### [1.43.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.43.2...v1.43.3) (2022-04-21)

### [1.43.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.43.1...v1.43.2) (2022-04-18)

### [1.43.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.43.0...v1.43.1) (2022-04-18)

## [1.43.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.42.0...v1.43.0) (2022-04-13)

## [1.42.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.41.0...v1.42.0) (2022-04-06)

## [1.41.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.40.0...v1.41.0) (2022-04-04)

## [1.40.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.39.0...v1.40.0) (2022-03-31)

## [1.39.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.38.0...v1.39.0) (2022-03-31)

## [1.38.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.37.0...v1.38.0) (2022-03-28)

## [1.37.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.36.1...v1.37.0) (2022-03-25)

### [1.36.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.36.0...v1.36.1) (2022-03-23)

## [1.36.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.12...v1.36.0) (2022-03-10)

### [1.35.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.11...v1.35.12) (2022-02-24)

### [1.35.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.10...v1.35.11) (2022-02-24)

### [1.35.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.9...v1.35.10) (2022-02-24)

### [1.35.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.8...v1.35.9) (2022-02-18)

### [1.35.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.7...v1.35.8) (2022-02-18)

### [1.35.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.6...v1.35.7) (2022-02-14)

### [1.35.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.5...v1.35.6) (2022-02-10)

### [1.35.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.4...v1.35.5) (2022-02-10)

### [1.35.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.3...v1.35.4) (2022-02-10)

### [1.35.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.2...v1.35.3) (2022-02-08)

### [1.35.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.1...v1.35.2) (2022-02-08)

### [1.35.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.35.0...v1.35.1) (2022-02-07)

## [1.35.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.34.4...v1.35.0) (2022-02-07)

### [1.34.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.34.3...v1.34.4) (2022-02-01)

### [1.34.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.34.2...v1.34.3) (2022-01-31)

### [1.34.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.34.1...v1.34.2) (2022-01-25)

### [1.34.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.34.0...v1.34.1) (2022-01-21)

## [1.34.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.33.0...v1.34.0) (2022-01-14)

## [1.33.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.32.0...v1.33.0) (2022-01-11)

## [1.32.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.31.1...v1.32.0) (2022-01-10)

### [1.31.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.31.0...v1.31.1) (2021-12-28)

## [1.31.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.30.6...v1.31.0) (2021-12-24)

### [1.30.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.30.5...v1.30.6) (2021-12-24)

### [1.30.5-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.30.5-hotfix.1...v1.30.5-hotfix.2) (2021-12-20)

### [1.30.5-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.30.4...v1.30.5-hotfix.1) (2021-12-08)

### [1.30.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.30.4...v1.30.5) (2021-12-10)

### [1.30.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.30.3...v1.30.4) (2021-12-03)

### [1.30.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.30.2...v1.30.3) (2021-12-03)

### [1.30.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.30.1...v1.30.2) (2021-12-02)

### [1.30.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.30.0...v1.30.1) (2021-12-02)

## [1.30.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.29.0...v1.30.0) (2021-12-01)

## [1.29.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.28.1...v1.29.0) (2021-11-30)

### [1.28.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.28.0...v1.28.1) (2021-11-26)

## [1.28.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.27.0...v1.28.0) (2021-11-24)

## [1.27.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.26.0...v1.27.0) (2021-11-22)

## [1.26.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.25.0...v1.26.0) (2021-11-22)

## [1.25.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.24.0...v1.25.0) (2021-11-19)

## [1.24.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.23.0...v1.24.0) (2021-11-17)

## [1.23.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.22.0...v1.23.0) (2021-11-17)

## [1.22.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.21.0...v1.22.0) (2021-11-17)

## [1.21.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.20.0...v1.21.0) (2021-11-17)

## [1.20.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.19.0...v1.20.0) (2021-11-17)

## [1.19.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.18.0...v1.19.0) (2021-11-16)

## [1.18.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.17.0...v1.18.0) (2021-11-16)

## [1.17.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.16.0...v1.17.0) (2021-11-16)

## [1.16.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.15.0...v1.16.0) (2021-11-16)

## [1.15.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.14.0...v1.15.0) (2021-11-11)

## [1.14.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.13.0...v1.14.0) (2021-11-10)

## [1.13.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.12.0...v1.13.0) (2021-11-10)

## [1.12.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.11.0...v1.12.0) (2021-11-09)

## [1.11.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.10.0...v1.11.0) (2021-11-08)

## [1.10.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.9.0...v1.10.0) (2021-10-11)

## [1.9.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.8.0...v1.9.0) (2021-10-11)

## [1.8.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.7.0...v1.8.0) (2021-10-06)

## [1.7.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.6.0...v1.7.0) (2021-09-27)

## [1.6.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.5.0...v1.6.0) (2021-09-23)

## [1.5.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.4.0...v1.5.0) (2021-09-23)

## [1.4.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.3.0...v1.4.0) (2021-09-20)

## [1.3.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.2.0...v1.3.0) (2021-09-13)

## [1.2.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.1.1...v1.2.0) (2021-09-13)

### [1.1.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.1.0...v1.1.1) (2021-08-18)

## [1.1.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-result-delivery/compare/v1.0.1...v1.1.0) (2021-08-17)
