package com.ielts.cmds.rd.socket.response;

import java.time.OffsetDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class TRFBookingDownloadResultsV1 {

    private String trfDownloadUrl;

    private Integer printEventCount;

    @JsonFormat(pattern = "dd MMM yyyy hh:mm a")
    private OffsetDateTime printedDateTime;

    private String printedBy;

    private String fileName;
}
