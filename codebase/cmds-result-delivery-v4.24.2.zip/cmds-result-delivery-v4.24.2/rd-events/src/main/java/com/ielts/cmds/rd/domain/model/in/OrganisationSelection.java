package com.ielts.cmds.rd.domain.model.in;

import lombok.*;

import java.util.UUID;


@Data
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class OrganisationSelection {

    private UUID externalSelectionUuid;
}
