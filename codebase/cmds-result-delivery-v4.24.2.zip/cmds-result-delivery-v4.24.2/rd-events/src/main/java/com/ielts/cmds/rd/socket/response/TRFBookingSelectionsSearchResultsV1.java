package com.ielts.cmds.rd.socket.response;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class TRFBookingSelectionsSearchResultsV1 {
    private UUID bookingUuid;

    private UUID resultUuid;

    private String givenName;

    private String familyName;

    private String testCenterNumber;

    @JsonFormat(pattern = "dd MMM yyyy")
    private LocalDate testDate;

    private String testTakerNumber;

    private String resultStatus;

    @JsonFormat(pattern = "dd MMM yyyy")
    private OffsetDateTime resultLastUpdatedDate;

    private Integer totalSelectionsCount;

    private List<ResultDeliveryTemplatePrintStatusNodeV1> printStatus;

    private List<SelectionNodeV1> selections;

}
