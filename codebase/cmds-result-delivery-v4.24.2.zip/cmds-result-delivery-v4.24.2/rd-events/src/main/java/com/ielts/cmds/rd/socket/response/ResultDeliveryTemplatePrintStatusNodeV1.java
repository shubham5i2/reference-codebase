package com.ielts.cmds.rd.socket.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.OffsetDateTime;
import java.util.UUID;

@Setter
@Getter
@NoArgsConstructor
public class ResultDeliveryTemplatePrintStatusNodeV1 {

    private Integer printEventCount;

    @JsonFormat(pattern = "dd MMM yyyy hh:mm a")
    private OffsetDateTime printedDateTime;

    private String printedBy;

    private UUID renditionTypeUuid;

}
