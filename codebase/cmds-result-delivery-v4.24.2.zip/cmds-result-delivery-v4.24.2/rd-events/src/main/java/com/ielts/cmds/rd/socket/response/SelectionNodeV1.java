
package com.ielts.cmds.rd.socket.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.OffsetDateTimeSerializer;
import com.ielts.cmds.rd.domain.model.enums.DeliveryStatusEnum;
import com.ielts.cmds.rd.domain.model.enums.MinimumScoreSatisfiedEnum;
import com.ielts.cmds.rd.domain.model.utils.CMDSLocalDateTimeDeserializer;
import lombok.Getter;
import lombok.Setter;

import java.time.OffsetDateTime;
import java.util.UUID;


@Getter
@Setter
public class SelectionNodeV1 {

    private UUID selectionUuid;

    private UUID externalSelectionUuid;

    @JsonSerialize(
            using = OffsetDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = CMDSLocalDateTimeDeserializer.class
    )
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    private OffsetDateTime selectionDate;

    private DeliveryStatusEnum deliveryStatus;

    @JsonSerialize(
            using = OffsetDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = CMDSLocalDateTimeDeserializer.class
    )
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    private OffsetDateTime deliveryStatusChangedDatetime;


    private String confirmationStatus;

    @JsonSerialize(
            using = OffsetDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = CMDSLocalDateTimeDeserializer.class
    )
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    private OffsetDateTime confirmationStatusChangedDatetime;

    private MinimumScoreSatisfiedEnum minimumScoreSatisfied;

    private String caseNumber;

    private String personDepartment;

    private String trfNumber;

    private String organisationId;

    private String organisationName;

    private String organisationAddress;

    private String organisationType;


}
