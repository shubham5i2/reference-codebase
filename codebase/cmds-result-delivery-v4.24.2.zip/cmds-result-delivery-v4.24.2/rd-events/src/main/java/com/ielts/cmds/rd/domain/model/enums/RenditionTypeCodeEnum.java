package com.ielts.cmds.rd.domain.model.enums;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;

@JsonAdapter(RenditionTypeCodeEnum.Adapter.class)
public enum RenditionTypeCodeEnum {
    TRF("TRF"),
    ETRF("ETRF"),
    ERESULT("ERESULT");

    private final String value;

    RenditionTypeCodeEnum(String value) {
        this.value = value;
    }

    public static RenditionTypeCodeEnum fromValue(String text) {
        for (RenditionTypeCodeEnum renditionTypeCodeEnum : RenditionTypeCodeEnum.values()) {
            if (String.valueOf(renditionTypeCodeEnum.value).equals(text)) {
                return renditionTypeCodeEnum;
            }
        }
        return null;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static class Adapter extends TypeAdapter<RenditionTypeCodeEnum> {
        @Override
        public void write(final JsonWriter jsonWriter, final RenditionTypeCodeEnum enumeration)
                throws IOException {
            jsonWriter.value(enumeration.getValue());
        }

        @Override
        public RenditionTypeCodeEnum read(final JsonReader jsonReader) throws IOException {
            String value = jsonReader.nextString();
            return RenditionTypeCodeEnum.fromValue(String.valueOf(value));
        }
    }
}
