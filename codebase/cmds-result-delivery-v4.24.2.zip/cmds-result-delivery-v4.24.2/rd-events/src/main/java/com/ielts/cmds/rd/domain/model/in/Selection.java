package com.ielts.cmds.rd.domain.model.in;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class Selection {
    private UUID bookingUuid = null;

    private UUID externalBookingUuid = null;

    private SelectionSelection selection = null;
}
