package com.ielts.cmds.rd.domain.model.utils;

import java.io.IOException;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

public class CMDSLocalDateTimeDeserializer extends JsonDeserializer<OffsetDateTime> {

    private static final String PATTERN = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

    public CMDSLocalDateTimeDeserializer() {
    }

    public OffsetDateTime deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        OffsetDateTime localDT = OffsetDateTime.parse(p.getValueAsString());
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(PATTERN);
        return OffsetDateTime.ofInstant(Instant.parse(dateTimeFormatter.format(localDT)), ZoneOffset.UTC);
    }
}





