package com.ielts.cmds.rd.domain.model.enums;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;

@JsonAdapter(FormatEnum.Adapter.class)
public enum FormatEnum {

    CD("CD"),
    PB("PB");
    private final String value;
    FormatEnum(String value) {
        this.value = value;
    }

    public static FormatEnum fromValue(String text) {
        for (FormatEnum formatEnum : FormatEnum.values()) {
            if (String.valueOf(formatEnum.value).equals(text)) {
                return formatEnum;
            }
        }
        return null;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static class Adapter extends TypeAdapter<FormatEnum> {
        @Override
        public void write(final JsonWriter jsonWriter, final FormatEnum enumeration)
                throws IOException {
            jsonWriter.value(enumeration.getValue());
        }

        @Override
        public FormatEnum read(final JsonReader jsonReader) throws IOException {
            String value = jsonReader.nextString();
            return FormatEnum.fromValue(String.valueOf(value));
        }
    }

}
