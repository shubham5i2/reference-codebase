package com.ielts.cmds.rd.socket.response;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.organisation.common.out.socketresponse.SocketResponseMetaDataV1;

import lombok.Data;


@Data
public class TRFBookingDownloadResultsResponseV1 {

    private SocketResponseMetaDataV1 meta;

    private TRFBookingDownloadResultsV1 response;

    private BaseEventErrors errors;
}
