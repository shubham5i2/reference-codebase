package com.ielts.cmds.rd.domain.model.enums;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;

@JsonAdapter(LocationStatusEnum.Adapter.class)
public enum LocationStatusEnum {
    ACTIVE("ACTIVE"), INACTIVE("INACTIVE"), SUSPENDED("SUSPENDED");

    private String value;

    LocationStatusEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static LocationStatusEnum fromValue(String text) {
        for (LocationStatusEnum b : LocationStatusEnum.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        return null;
    }

    public static class Adapter extends TypeAdapter<LocationStatusEnum> {
        @Override
        public void write(final JsonWriter jsonWriter, final LocationStatusEnum enumeration) throws IOException {
            jsonWriter.value(enumeration.getValue());
        }

        @Override
        public LocationStatusEnum read(final JsonReader jsonReader) throws IOException {
            Object value = jsonReader.nextString();
            return LocationStatusEnum.fromValue(String.valueOf(value));
        }
    }
}
