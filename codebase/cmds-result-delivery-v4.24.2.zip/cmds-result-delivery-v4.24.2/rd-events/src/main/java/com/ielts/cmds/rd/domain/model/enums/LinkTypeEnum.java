package com.ielts.cmds.rd.domain.model.enums;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;

@JsonAdapter(LinkTypeEnum.Adapter.class)
public enum LinkTypeEnum {

    RESULTS_DELIVERY("RESULTS_DELIVERY"),
    PARENT_RO("PARENT_RO"),
    REPLACED_BY("REPLACED_BY");

    private final String value;

    LinkTypeEnum(String value) {
        this.value = value;
    }

    public static LinkTypeEnum fromValue(String text) {
        for (LinkTypeEnum linkTypeEnum : LinkTypeEnum.values()) {
            if (String.valueOf(linkTypeEnum.value).equals(text)) {
                return linkTypeEnum;
            }
        }
        return null;
    }


    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static class Adapter extends TypeAdapter<LinkTypeEnum> {
        @Override
        public void write(final JsonWriter jsonWriter, final LinkTypeEnum enumeration)
                throws IOException {
            jsonWriter.value(enumeration.getValue());
        }

        @Override
        public LinkTypeEnum read(final JsonReader jsonReader) throws IOException {
            String value = jsonReader.nextString();
            return LinkTypeEnum.fromValue(String.valueOf(value));
        }
    }
}
