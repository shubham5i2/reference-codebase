package com.ielts.cmds.rd.domain.model.enums;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;

@JsonAdapter(MinimumScoreSatisfiedEnum.Adapter.class)
public enum MinimumScoreSatisfiedEnum {

    UNSATISFIED("UNSATISFIED"),
    SATISFIED("SATISFIED"),
    NOT_APPLICABLE("NOT_APPLICABLE");

    private final String value;

    MinimumScoreSatisfiedEnum(String value) {
        this.value = value;
    }

    public static MinimumScoreSatisfiedEnum fromValue(String text) {
        for (MinimumScoreSatisfiedEnum minimumScoreSatisfiedEnum : MinimumScoreSatisfiedEnum.values()) {
            if (String.valueOf(minimumScoreSatisfiedEnum.value).equals(text)) {
                return minimumScoreSatisfiedEnum;
            }
        }
        return null;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static class Adapter extends TypeAdapter<MinimumScoreSatisfiedEnum> {
        @Override
        public void write(final JsonWriter jsonWriter, final MinimumScoreSatisfiedEnum enumeration)
                throws IOException {
            jsonWriter.value(enumeration.getValue());
        }

        @Override
        public MinimumScoreSatisfiedEnum read(final JsonReader jsonReader) throws IOException {
            String value = jsonReader.nextString();
            return MinimumScoreSatisfiedEnum.fromValue(String.valueOf(value));
        }
    }
}
