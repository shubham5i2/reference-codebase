package com.ielts.cmds.rd.domain.model.enums;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;

@JsonAdapter(PhotoTypeCodeEnum.Adapter.class)
public enum PhotoTypeCodeEnum {

    TT_ID_HR_R("TT_ID_HR_R"),
    TT_P_HR_R("TT_P_HR_R"),
    TT_P_LR_IAM("TT_P_LR_IAM"),
    TT_P_HR_IAM("TT_P_HR_IAM"),
    TT_P_LR_LRW_WC("TT_P_LR_LRW_WC"),
    TT_P_LR_S_WC("TT_P_LR_S_WC"),
    TT_ID_LRW_WC("TT_ID_LRW_WC"),
    TT_ID_S_WC("TT_ID_S_WC"),
    SSR_ORIGINAL_BOOKING_TRF("SSR_ORIGINAL_BOOKING_TRF");

    private final String value;

    PhotoTypeCodeEnum(String value) {
        this.value = value;
    }

    public static PhotoTypeCodeEnum fromValue(String text) {
        for (PhotoTypeCodeEnum photoTypeCodeEnum : PhotoTypeCodeEnum.values()) {
            if (String.valueOf(photoTypeCodeEnum.value).equals(text)) {
                return photoTypeCodeEnum;
            }
        }
        return null;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static class Adapter extends TypeAdapter<PhotoTypeCodeEnum> {
        @Override
        public void write(final JsonWriter jsonWriter, final PhotoTypeCodeEnum enumeration)
                throws IOException {
            jsonWriter.value(enumeration.getValue());
        }

        @Override
        public PhotoTypeCodeEnum read(final JsonReader jsonReader) throws IOException {
            String value = jsonReader.nextString();
            return PhotoTypeCodeEnum.fromValue(String.valueOf(value));
        }
    }
}
