package com.ielts.cmds.rd.domain.model.in;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.OffsetDateTimeSerializer;
import com.ielts.cmds.rd.domain.model.enums.DeliveryStatusEnum;
import com.ielts.cmds.rd.domain.model.utils.CMDSLocalDateTimeDeserializer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;
import java.util.UUID;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class SelectionSelection {

    private UUID selectionUuid = null;

    private UUID externalSelectionUuid = null;

    private DeliveryStatusEnum deliveryStatus = null;

    @JsonSerialize(
            using = OffsetDateTimeSerializer.class
    )
    @JsonDeserialize(
            using = CMDSLocalDateTimeDeserializer.class
    )
    private OffsetDateTime deliveryStatusChangedDateTime = null;
}
