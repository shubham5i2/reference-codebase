# Result Delivery Microservice project
This is the microservice project for Result Delivery.

For Running the project locally add this command in VM options:   -Dspring.config.location=file:src/main/resources/application.properties 

## External config argument
-Dspring.config.location=file:{path}application.properties

## CLI run command
java -jar rd-mx-0.0.1-SNAPSHOT.jar --spring.config.location=/var/config/properties/application.properties