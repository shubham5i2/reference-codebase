package com.ielts.cmds.rd.infrastructure.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource(value = {"rd-application.properties", "application.properties"})
public class RDApplicationConfig {}
