package com.ielts.cmds.rd.domain.service;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.application.exception.ResultDeliveryValidationException;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.domain.command.LegacyResultDeliveryRequestCommand;
import com.ielts.cmds.rd.domain.model.enums.DeliveryStatusEnum;
import com.ielts.cmds.rd.domain.model.enums.PhotoTypeCodeEnum;
import com.ielts.cmds.rd.domain.model.out.ReferenceDataNodeV1;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import com.ielts.cmds.rd.domain.utils.BuildResultReleaseNodeV1Utils;
import com.ielts.cmds.rd.infrastructure.entity.*;
import com.ielts.cmds.rd.infrastructure.repositories.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.constraints.NotNull;
import java.lang.reflect.InvocationTargetException;
import java.time.OffsetDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static java.time.ZoneOffset.UTC;


@Service
@RequiredArgsConstructor
@Slf4j
public class LegacyRDRequestDomainService extends AbstractDomainService {

    private final ObjectMapper objectMapper;

    private final ResultRepository resultRepository;

    private final TestTakerPhotoRepository testTakerPhotoRepository;

    private final ApplicationEventPublisher applicationEventPublisher;

    private final BookingRepository bookingRepository;

    private final BuildResultReleaseNodeV1Utils resultReleaseNodeV1Utils;

    private final ProductRepository productRepository;

    private final ResultsStatusTypeRepository resultsStatusTypeRepository;

    private final GenderRepository genderRepository;

    private final CountryRepository countryRepository;

    private final TerritoryRepository territoryRepository;

    private final TestTakerPhotoTypeRepository testTakerPhotoTypeRepository;

    @Transactional
    public void on(@NotNull LegacyResultDeliveryRequestCommand command) throws JsonProcessingException, ResultDeliveryValidationException, InvocationTargetException, IllegalAccessException {

        log.info("Received Legacy Result Delivery Requested event with Booking Uuid {} and Result uuid {}",
                command.getEventBody().getResultDetails().getBookingUuid(), command.getEventBody().getResultDetails().getResultUuid());

        Optional<ResultReleasedNodeV1> resultReleasedNodeV1 = Optional.empty();
        String eventBody;
        BaseEvent<BaseHeader> event;
        final BaseHeader eventHeader = new BaseHeader();
        BaseEventErrors baseEventErrors = null;

        try {
            Optional<Result> optionalResult = resultRepository.findById(command.getEventBody().getResultDetails().getResultUuid());

            Result result = optionalResult.orElseThrow(() -> new ResultDeliveryValidationException
                    ("Legacy result delivery initiated Event Failed as Result is not Present", new Throwable()));

            setDeliveryStatusForInitiateEvent(command, result);
            ResultReleasedNodeV1 resultReleasedNodeV11 = resultReleaseNodeV1Utils.buildResultReleasedNodeV1(result.getResultUuid());
            resultReleasedNodeV11.setReferenceData(getReferenceData(result));
            resultReleasedNodeV1 = Optional.of(resultReleasedNodeV11);
            eventBody = objectMapper.writeValueAsString(resultReleasedNodeV1);
            buildHeader(command, eventHeader, resultReleasedNodeV1);
        } catch (final ResultDeliveryValidationException e) {
            log.error("LegacyResultDeliveryRequestCommand execution failed", e);
            eventBody = getEventBodyForReportGenerationEvents(command.getEventBody().getBookingDetails().getBookingUuid());
            baseEventErrors = resultReleaseNodeV1Utils.getBaseEventErrors(e);
            buildHeader(command, eventHeader, resultReleasedNodeV1);
        }
        event = new BaseEvent<>(eventHeader, eventBody, baseEventErrors, command.getAudit());

        applicationEventPublisher.publishEvent(event);
    }

    private void setDeliveryStatusForInitiateEvent(final LegacyResultDeliveryRequestCommand command, Result result) throws ResultDeliveryValidationException {

        List<ResultDelivery> resultDeliveryList = result.getResultDelivery();
        ResultDelivery resultDelivery = new ResultDelivery();
        Optional<ResultsStatusType> optionalResultsStatusType = Optional.empty();
        if (Objects.nonNull(result.getResultsStatusTypeUuid())) {
            optionalResultsStatusType = resultsStatusTypeRepository.findById(result.getResultsStatusTypeUuid());
        }
        if (optionalResultsStatusType.isPresent()) {
            ResultsStatusType resultsStatusType = optionalResultsStatusType.get();

            if (resultsStatusType.getResultStatusCode().equals(RDConstants.GenericConstants.RELEASED) ||
                    resultsStatusType.getResultStatusCode().equals(RDConstants.GenericConstants.PERMANENTLY_WITHHELD)) {
                resultDelivery.setStatus(DeliveryStatusEnum.DELIVERY_PENDING);
            } else {
                throw new ResultDeliveryValidationException(String.format("Can not initiate result delivery process because result status type is : %s ",
                        resultsStatusType.getResultStatusCode()), new Throwable());
            }
        } else {
            throw new ResultDeliveryValidationException(String.format("Could not find ResultsStatusType in DB : %s",
                    result.getResultsStatusTypeUuid()), new Throwable());
        }
        resultDelivery.setResultDeliveryUuid(UUID.randomUUID());
        resultDelivery.setStatusUpdatedDateTime(OffsetDateTime.now(UTC));
        resultDelivery.setTransactionUuid(command.getEventHeaders().getTransactionId());
        resultDelivery.setSystem(RDConstants.GenericConstants.LA);
        resultDelivery.setResult(result);
        resultDeliveryList.add(resultDelivery);
        result.setResultDelivery(resultDeliveryList);
        resultRepository.save(result);
    }

    public void buildHeader(final LegacyResultDeliveryRequestCommand command, BaseHeader eventHeader, Optional<ResultReleasedNodeV1> resultNodeV1) {
        eventHeader.setCorrelationId(command.getEventHeaders().getCorrelationId());
        eventHeader.setEventDateTime(command.getEventHeaders().getEventDateTime());
        eventHeader.setTransactionId(command.getEventHeaders().getTransactionId());
        eventHeader.setPartnerCode(command.getEventHeaders().getPartnerCode());
        Map<String, String> eventContext = Optional
                .ofNullable(command.getEventHeaders().getEventContext())
                .orElseGet(HashMap::new);

        if (Objects.nonNull(command.getEventBody()) && Objects.nonNull(command.getEventBody().getResultDetails().getResultUuid())) {
            eventContext.put("resultUuid", command.getEventBody().getResultDetails().getResultUuid().toString());
        }
        eventHeader.setEventContext(eventContext);
        if (resultNodeV1.isPresent()) {
            eventHeader.setEventName(RDConstants.EventType.LEGACY_RESULT_DELIVERY_INITIATED);
        } else {
            eventHeader.setEventName(RDConstants.EventType.LEGACY_RESULT_DELIVERY_INITIATED_FAILED);
        }
    }


    private List<ReferenceDataNodeV1> getReferenceData(Result result) {
        ReferenceDataNodeV1 referenceDataNodeV1 = new ReferenceDataNodeV1();
        ReferenceDataNodeV1 referenceDataNodeV2 = new ReferenceDataNodeV1();
        ReferenceDataNodeV1 referenceDataNodeV3 = new ReferenceDataNodeV1();
        ReferenceDataNodeV1 referenceDataNodeV4 = new ReferenceDataNodeV1();
        ReferenceDataNodeV1 referenceDataNodeV5 = new ReferenceDataNodeV1();
        ReferenceDataNodeV1 referenceDataNodeV6 = new ReferenceDataNodeV1();

        List<ReferenceDataNodeV1> referenceDataNodesList = new ArrayList<>();

        Optional<Booking> optionalBooking = Objects.isNull(result.getBookingUuid())
                ? Optional.empty() : bookingRepository.findById(result.getBookingUuid());

        Optional<ResultsStatusType> optionalResultsStatusType = Objects.isNull(result.getResultsStatusTypeUuid())
                ? Optional.empty() : resultsStatusTypeRepository.findById(result.getResultsStatusTypeUuid());

        //building gender node
        Optional<ReferenceDataNodeV1> genderReferenceDataNode = buildGenderReferenceNode(referenceDataNodeV1, optionalBooking);
        genderReferenceDataNode.ifPresent(referenceDataNodesList::add);

        //building country node
        Optional<ReferenceDataNodeV1> countryReferenceDataNode = buildCountryReferenceNode(referenceDataNodeV2, optionalBooking);
        countryReferenceDataNode.ifPresent(referenceDataNodesList::add);

        //building territory node
        Optional<ReferenceDataNodeV1> territoryReferenceDataNode = buildTerritoryReferenceNode(referenceDataNodeV3, optionalBooking);
        territoryReferenceDataNode.ifPresent(referenceDataNodesList::add);

        //building product_module_type node
        Optional<ReferenceDataNodeV1> productModuleReferenceDataNode = buildProductModuleReferenceNode(referenceDataNodeV4, optionalBooking);
        productModuleReferenceDataNode.ifPresent(referenceDataNodesList::add);

        //building test taker photos node
        Optional<ReferenceDataNodeV1> tTPhotoReferenceDataNode = buildTtPhotoReferenceNode(referenceDataNodeV5, optionalBooking);
        tTPhotoReferenceDataNode.ifPresent(referenceDataNodesList::add);

        //building result status type node
        Optional<ReferenceDataNodeV1> resultsStatusTypeReferenceDataNode = buildResultsStatusTypeReferenceDataNode(referenceDataNodeV6, optionalResultsStatusType);
        resultsStatusTypeReferenceDataNode.ifPresent(referenceDataNodesList::add);

        return referenceDataNodesList;
    }

    private Optional<ReferenceDataNodeV1> buildResultsStatusTypeReferenceDataNode(ReferenceDataNodeV1 referenceDataNodeV6, Optional<ResultsStatusType> optionalResultsStatusType) {
        if (optionalResultsStatusType.isPresent() && Objects.nonNull(optionalResultsStatusType.get().getResultStatusTypeUuid())) {
            referenceDataNodeV6.setReferenceId(optionalResultsStatusType.get().getResultStatusTypeUuid().toString());
            referenceDataNodeV6.setReferenceValue(optionalResultsStatusType.get().getResultStatusCode());
            return Optional.of(referenceDataNodeV6);
        }
        return Optional.empty();
    }

    private Optional<ReferenceDataNodeV1> buildTtPhotoReferenceNode(ReferenceDataNodeV1 referenceDataNodeV5, Optional<Booking> optionalBooking) {
        if (optionalBooking.isPresent() && Objects.nonNull(optionalBooking.get().getBookingUuid())) {
            List<TestTakerPhoto> testTakerPhotos = testTakerPhotoRepository.findByBookingUuid(optionalBooking.get().getBookingUuid());

            Optional<TestTakerPhotoType> optionalTestTakerPhotoType = testTakerPhotoTypeRepository.findByPhotoTypeCode(PhotoTypeCodeEnum.valueOf("TT_P_LR_LRW_WC"));

            if (!testTakerPhotos.isEmpty() && optionalTestTakerPhotoType.isPresent()) {
                List<TestTakerPhoto> testTakerLowResolutionPhoto = testTakerPhotos.stream()
                        .filter(testTakerPhoto -> testTakerPhoto.getPhotoTypeUuid().equals(
                                optionalTestTakerPhotoType.get().getPhotoTypeUuid())).collect(Collectors.toList());
                if (!testTakerLowResolutionPhoto.isEmpty()) {
                    referenceDataNodeV5.setReferenceId(testTakerLowResolutionPhoto.get(0).getPhotoTypeUuid().toString());
                    referenceDataNodeV5.setReferenceValue(optionalTestTakerPhotoType.get().getPhotoTypeCode().getValue());
                    return Optional.of(referenceDataNodeV5);
                }
            }
        }
        return Optional.empty();
    }

    private Optional<ReferenceDataNodeV1> buildProductModuleReferenceNode(ReferenceDataNodeV1 referenceDataNodeV4, Optional<Booking> optionalBooking) {
        if (optionalBooking.isPresent() && Objects.nonNull(optionalBooking.get().getProductUuid())) {
            Optional<Product> optionalProduct = productRepository.findById(optionalBooking.get().getProductUuid());

            if (optionalProduct.isPresent()) {
                referenceDataNodeV4.setReferenceId("Product_Module_Type");
                referenceDataNodeV4.setReferenceValue(optionalProduct.get().getModuleType().getLegacyModuleType());
                return Optional.of(referenceDataNodeV4);
            }
        }
        return Optional.empty();
    }

    private Optional<ReferenceDataNodeV1> buildTerritoryReferenceNode(ReferenceDataNodeV1 referenceDataNodeV3, Optional<Booking> optionalBooking) {
        if (optionalBooking.isPresent() && Objects.nonNull(optionalBooking.get().getStateTerritoryUuid())) {
            Optional<Territory> optionalTerritory = territoryRepository.findById(optionalBooking.get().getStateTerritoryUuid());
            if (optionalTerritory.isPresent()) {
                referenceDataNodeV3.setReferenceId(optionalBooking.get().getStateTerritoryUuid().toString());
                referenceDataNodeV3.setReferenceValue(optionalTerritory.get().getTerritoryName());
                return Optional.of(referenceDataNodeV3);
            }
        }
        return Optional.empty();
    }

    private Optional<ReferenceDataNodeV1> buildCountryReferenceNode(ReferenceDataNodeV1 referenceDataNodeV2, Optional<Booking> optionalBooking) {
        if (optionalBooking.isPresent() && Objects.nonNull(optionalBooking.get().getCountryUuid())) {
            Optional<Country> optionalCountry = countryRepository.findById(optionalBooking.get().getCountryUuid());
            if (optionalCountry.isPresent()) {
                referenceDataNodeV2.setReferenceId(optionalBooking.get().getCountryUuid().toString());
                referenceDataNodeV2.setReferenceValue(optionalCountry.get().getCountryIso3Code());
                return Optional.of(referenceDataNodeV2);
            }
        }
        return Optional.empty();
    }

    private Optional<ReferenceDataNodeV1> buildGenderReferenceNode(ReferenceDataNodeV1 referenceDataNodeV1, Optional<Booking> optionalBooking) {
        if (optionalBooking.isPresent() && Objects.nonNull(optionalBooking.get().getSexUuid())) {
            Optional<Gender> optionalGender = genderRepository.findById(optionalBooking.get().getSexUuid());
            if (optionalGender.isPresent()) {
                referenceDataNodeV1.setReferenceId(optionalBooking.get().getSexUuid().toString());
                referenceDataNodeV1.setReferenceValue(optionalGender.get().getGenderCode());
                return Optional.of(referenceDataNodeV1);
            }
        }
        return Optional.empty();
    }

    @Override
    protected ResultRepository getResultRepository() {
        return this.resultRepository;
    }

    @Override
    protected BuildResultReleaseNodeV1Utils getBuildResultReleasedNodeV1Utils() {
        return this.resultReleaseNodeV1Utils;
    }

    @Override
    protected ObjectMapper getObjectMapper() {
        return this.objectMapper;
    }
}

