package com.ielts.cmds.rd.domain.utils;

import com.ielts.cmds.application.command.BaseCommand;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.common.enums.ComponentEnum;
import com.ielts.cmds.rd.application.exception.ResultDeliveryValidationException;
import com.ielts.cmds.rd.application.exception.TestTakerPhotoNotFoundException;
import com.ielts.cmds.rd.domain.model.ReportGenerationModel;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import com.ielts.cmds.rd.infrastructure.config.TemplateGenerationS3Operations;
import com.ielts.cmds.rd.infrastructure.entity.*;
import com.ielts.cmds.rd.infrastructure.repositories.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static com.ielts.cmds.rd.domain.RDConstants.GenericConstants.BC_CHINA;

/*
 * This class is used to prepare TRF(Test Report Form) and ETRF data model
 */

@Component
@Slf4j
@RequiredArgsConstructor
public class BuildTemplateDataUtils {

    private final LocationRepository locationRepository;

    private final BookingRepository bookingRepository;

    private final ResultRepository resultRepository;

    private final GenderRepository genderRepository;

    private final CountryRepository countryRepository;

    private final NationalityRepository nationalityRepository;

    private final LanguageRepository languageRepository;

    private final ProductRepository productRepository;

    private final TemplateGenerationS3Operations awsS3Configuration;

    public ReportGenerationModel prepareTemplateData(@NotNull final BaseCommand<BaseHeader, ResultReleasedNodeV1> command) throws ResultDeliveryValidationException, IOException {
        ReportGenerationModel reportGenerationModel = new ReportGenerationModel();
        //getting Location data from LocationRepository for TRF or ETRF data model
        Optional<Location> optionalLocation = locationRepository.findById(command.getEventBody().getBookingDetails().getLocationUuid());
        Location location = optionalLocation.orElseThrow(() -> new ResultDeliveryValidationException
                ("Event failed as Location is not present", new Throwable()));

        //getting Booking data from BookingRepository for TRF or ETRF data model
        Optional<Booking> optionalBooking = bookingRepository.findById(command.getEventBody().getBookingDetails().getBookingUuid());
        Booking booking = optionalBooking.orElseThrow(() -> new ResultDeliveryValidationException
                ("Event failed as Booking is not present", new Throwable()));

        //getting Result data from ResultRepository for TRF or ETRF data model
        Optional<Result> optionalResult = resultRepository.findById(command.getEventBody().getResultDetails().getResultUuid());
        Result result = optionalResult.orElseThrow(() -> new ResultDeliveryValidationException
                ("Event failed as Result is not present", new Throwable()));

        setTemplateLocationDetails(location, reportGenerationModel);

        setTemplateBookingDetails(booking, reportGenerationModel);

        List<ResultLine> resultLines = result.getResultLines();
        setTemplateResultDetails(result, resultLines, reportGenerationModel, booking);

        return reportGenerationModel;
    }

    //method to set test centre number of a candidate into TRF or ETRF model
    public void setTemplateLocationDetails(Location location, ReportGenerationModel reportGenerationModel) {
        String testCentreNumber = location.getTestCentreNumber();
        if (!StringUtils.isBlank(testCentreNumber)) {
            reportGenerationModel.setCentreNumber(testCentreNumber.toUpperCase());
        }
    }

    //method to set booking details of a candidate into TRF or ETRF model
    private void setTemplateBookingDetails(Booking booking, ReportGenerationModel reportGenerationModel) throws IOException, ResultDeliveryValidationException {
        Optional<LocalDate> optionalLocalDate = Optional.ofNullable(booking.getTestDate());

        if (optionalLocalDate.isPresent()) {
            LocalDate testDate = LocalDate.parse(booking.getTestDate().toString());
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MMM/yyyy");
            reportGenerationModel.setBookingTestDate(formatter.format(testDate).toUpperCase());
        }

        Integer candidateNumber = booking.getShortCandidateNumber();
        String shortCandidateNumber = String.format("%06d", candidateNumber);
        if (!StringUtils.isBlank(shortCandidateNumber)) {
            reportGenerationModel.setCandidateNumber(shortCandidateNumber);
        }

        String familyName = booking.getLastName();
        if (!StringUtils.isBlank((familyName))) {
            reportGenerationModel.setFamilyName(familyName.toUpperCase());
        }

        String firstName = booking.getFirstName();
        if (!StringUtils.isBlank((firstName))) {
            reportGenerationModel.setFirstName(firstName.toUpperCase());
        }

        String candidateId = booking.getIdentityNumber();
        if (!StringUtils.isBlank((candidateId))) {
            reportGenerationModel.setCandidateId(candidateId.toUpperCase());
        }

        //download TT photo from cmds s3 storage
        if (awsS3Configuration != null) {
            Optional<String> image = awsS3Configuration.getTtImageFromS3Bucket(booking);
            if (image.isPresent()) {
                reportGenerationModel.setTtPhoto(image.get());
            } else {
                throw new TestTakerPhotoNotFoundException("Test Taker Photo Not Found For Booking UUID " + booking.getBookingUuid(), new Throwable());
            }
        }

        Optional<LocalDate> optionalDateOfBirth = Optional.ofNullable(booking.getBirthDate());
        if (optionalDateOfBirth.isPresent()) {
            LocalDate dateOfBirth = LocalDate.parse(booking.getBirthDate().toString());
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            reportGenerationModel.setDateOfBirth(formatter.format(dateOfBirth));
        }

        if (Objects.nonNull(booking.getSexUuid())) {
            Optional<Gender> optionalGender = genderRepository.findById(booking.getSexUuid());
            String gender = "";
            if (optionalGender.isPresent()) {
                gender = optionalGender.get().getGenderCode();
                if (!StringUtils.isBlank((gender))) {
                    reportGenerationModel.setSex(gender.toUpperCase());
                }
            }
        }

        if (Objects.nonNull(booking.getNationalityUuid())) {
            String nationality = "";
            Optional<Nationality> optionalNationality = nationalityRepository.findById(booking.getNationalityUuid());
            if (optionalNationality.isPresent()) {
                nationality = optionalNationality.get().getNationalityName();
                if (!StringUtils.isBlank(nationality)) {
                    if(isPartnerCodeChina(booking.getPartnerCode())) {
                        reportGenerationModel.setCountryOrRegionOfOrigin(nationality.toUpperCase());
                    }
                    else{
                        reportGenerationModel.setCountryOfNationality(nationality.toUpperCase());
                    }
                }
            }
        }

        if (Objects.nonNull(booking.getLanguageUuid())) {
            String language = "";
            Optional<Language> optionalLanguage = languageRepository.findById(booking.getLanguageUuid());
            if (optionalLanguage.isPresent()) {
                language = optionalLanguage.get().getLanguageName();
                if (!StringUtils.isBlank(language)) {
                    reportGenerationModel.setFirstLanguage(language.toUpperCase());
                }
            }
        }

        if (Objects.nonNull(booking.getProductUuid())) {
            Optional<Product> optionalProduct = productRepository.findById(booking.getProductUuid());
            optionalProduct.ifPresent(product -> reportGenerationModel.setProductModule(product.getModuleType().getDescription().toUpperCase()));
        }
    }

    protected boolean isPartnerCodeChina(String partnerCode) {
        return BC_CHINA.equals(partnerCode);
    }

    //method to set result details of a candidate into TRF or ETRF model
    private void setTemplateResultDetails(Result result, List<ResultLine> resultLine1, ReportGenerationModel reportGenerationModel,
                                          Booking booking) throws ResultDeliveryValidationException {
        Double overallBandScore = result.getResultScore();
        if (overallBandScore != null) {
            reportGenerationModel.setOverallBandScore(overallBandScore.toString());
        }

        String cefrLevel = result.getCefrLevel();
        if (!StringUtils.isBlank(cefrLevel)) {
            reportGenerationModel.setCefrLevel(cefrLevel);
        }

        String administratorComments = result.getAdministratorComments();
        if (!StringUtils.isBlank(administratorComments)) {
            reportGenerationModel.setComments(administratorComments);
        }

        OffsetDateTime publishedTime = OffsetDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        reportGenerationModel.setDate(formatter.format(publishedTime));

        String testReportFormNumber = result.getTrfNumber();
        if (!StringUtils.isBlank(testReportFormNumber)) {
            reportGenerationModel.setTrfNumber(testReportFormNumber.toUpperCase());
        }

        reportGenerationModel.setSchemeCode("Private Candidate");

        // Booking Line UUID for Component = L
        final Optional<ResultLine> componentScoreL = getComponentScore(resultLine1, booking, ComponentEnum.L);
        if (componentScoreL.isPresent()) {
            reportGenerationModel.setListening(componentScoreL.get().getResultLineScore().toString());
        } else {
            throw new ResultDeliveryValidationException("Listening score is not present", new Throwable());
        }

        // Booking Line UUID for Component = R
        final Optional<ResultLine> componentScoreR = getComponentScore(resultLine1, booking, ComponentEnum.R);
        if (componentScoreR.isPresent()) {
            reportGenerationModel.setReading(componentScoreR.get().getResultLineScore().toString());
        } else {
            throw new ResultDeliveryValidationException("Reading score is not present", new Throwable());
        }

        // Booking Line UUID for Component = W
        final Optional<ResultLine> componentScoreW = getComponentScore(resultLine1, booking, ComponentEnum.W);
        if (componentScoreW.isPresent()) {
            reportGenerationModel.setWriting(componentScoreW.get().getResultLineScore().toString());
        } else {
            throw new ResultDeliveryValidationException("Writing score is not present", new Throwable());
        }

        // Booking Line UUID for Component = S
        final Optional<ResultLine> componentScoreS = getComponentScore(resultLine1, booking, ComponentEnum.S);
        if (componentScoreS.isPresent()) {
            reportGenerationModel.setSpeaking(componentScoreS.get().getResultLineScore().toString());
        } else {
            throw new ResultDeliveryValidationException("Speaking score is not present", new Throwable());
        }
    }

    //method to get component score of test taker
    private Optional<ResultLine> getComponentScore(List<ResultLine> resultLine, Booking booking, ComponentEnum component) {
        List<BookingLine> bookingLines = new ArrayList<>(Collections.emptyList());
        booking.getBookingLines()
                .forEach(e -> {
                    Optional<Product> optionalProduct = productRepository.findById(e.getProductUuid());
                    if (optionalProduct.isPresent()) {
                        Product product = optionalProduct.get();
                        if (product.getComponent().equals(component)) {
                            bookingLines.add(e);
                        }
                    }
                });
        Optional<BookingLine> bookingLine = bookingLines.stream().findFirst();
        return bookingLine.flatMap(line -> resultLine.stream().filter(entity -> entity.getBookingLineUuid().equals(line.getBookingLineUuid())).findFirst());
    }
}
