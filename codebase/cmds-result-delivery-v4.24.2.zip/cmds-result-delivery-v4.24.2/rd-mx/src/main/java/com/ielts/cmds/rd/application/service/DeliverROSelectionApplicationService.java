package com.ielts.cmds.rd.application.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.config.IApplicationService;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.domain.command.DeliverROSelectionCommand;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;
import com.ielts.cmds.rd.domain.service.DeliverROSelectionDomainService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class DeliverROSelectionApplicationService implements IApplicationService {

    private final ObjectMapper objectMapper;

    private final DeliverROSelectionDomainService deliverROSelectionDomainService;

    @Override
    public void process(BaseEvent<? extends BaseHeader> baseEvent) throws ProcessingException {
        try {
            final BaseHeader eventHeader = baseEvent.getEventHeader();
            final BaseEventErrors eventErrors = baseEvent.getEventErrors();
            final OrganisationSelectionNodeV1 organisationSelectionNodeV1 = objectMapper
                    .readValue(baseEvent.getEventBody(), OrganisationSelectionNodeV1.class);
            if (organisationSelectionNodeV1 == null) {
                throw new IllegalArgumentException(RDConstants.GenericConstants.EMPTY_PAYLOAD);
            }
            //build command
            final DeliverROSelectionCommand deliverROSelectionCommand = DeliverROSelectionCommand.builder()
                    .eventHeader(eventHeader).eventBody(organisationSelectionNodeV1)
                    .eventErrors(eventErrors).eventAudit(baseEvent.getAudit()).build();

            //execute command
            deliverROSelectionDomainService.on(deliverROSelectionCommand);

        } catch (IllegalArgumentException | JsonProcessingException e) {
            log.error("Failed to process Receiving Organisation Selection Changed event due to ", e);
            throw new ProcessingException(e.getMessage(), e);
        }
    }

    @Override
    public String getServiceIdentifier() {
        return RDConstants.EventType.RO_SELECTION_DELIVERY_REQUESTED;
    }

}

