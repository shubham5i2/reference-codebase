package com.ielts.cmds.rd.infrastructure.entity;

import lombok.*;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.UUID;
import javax.persistence.*;
import java.time.LocalDate;
import java.time.OffsetDateTime;

@Getter
@Setter
@Entity
@Table(name = "language")
@NoArgsConstructor
@AllArgsConstructor
@Builder
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class Language {

    @Id
    @Column(name = "language_uuid")
    private UUID languageUuid;

    @Column(name = "language_code")
    private String languageCode;

    @Column(name = "language_name")
    private String languageName;

    @Column(name = "created_datetime")
    private OffsetDateTime createdDatetime;

    @Column(name = "effective_to_date")
    private LocalDate effectiveToDate;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;

    @Column(name = "updated_by")
    private String updatedBy;

    @Column(name = "created_by")
    private String createdBy;

    @Version
    @Column(name = "concurrency_version")
    private Integer concurrencyVersion;

    @Column(name = "legacy_reference")
    private String legacyReference;

    @Column(name = "effective_from_date")
    private LocalDate effectiveFromDate;


}
