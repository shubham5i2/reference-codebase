package com.ielts.cmds.rd.domain.utils;

import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.common.enums.MethodOfDeliveryEnum;
import com.ielts.cmds.organisation.common.enums.OrganisationStatusEnum;
import com.ielts.cmds.organisation.common.enums.VerificationStatusEnum;
import com.ielts.cmds.rd.domain.command.DeliverROSelectionCommand;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;
import com.ielts.cmds.rd.domain.model.out.SelectionNodeV1;
import com.ielts.cmds.rd.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.rd.infrastructure.entity.Selection;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.*;

import static java.time.ZoneOffset.UTC;

@Component
@RequiredArgsConstructor
@Slf4j
public class DeliverROSelectionUtils {


    /**
     * check if secondary selection is eligible
     *
     * @return true if eligible
     */
    public boolean isSecondarySelectionEligible(RecognisingOrganisation recognisingOrganisation) {

        return recognisingOrganisation.getMethodOfDelivery().equals(MethodOfDeliveryEnum.E_DELIVERY)
                && recognisingOrganisation.getVerificationStatus().equals(VerificationStatusEnum.APPROVED)
                && recognisingOrganisation.getOrganisationStatus().equals(OrganisationStatusEnum.ACTIVE);
    }

    /**
     * generate selection entity to save, from selectionNodeV1
     *
     * @param organisationSelectionNodeV1 updated node
     * @return selection entity
     */
    public Selection getSelectionEntity(OrganisationSelectionNodeV1 organisationSelectionNodeV1) {
        SelectionNodeV1 selectionNodeV1 = organisationSelectionNodeV1.getSelection();
        Selection selection = new Selection();
        selection.setSelectionUuid(selectionNodeV1.getSelectionUuid());
        selection.setAssociatedSelectionUuid(selectionNodeV1.getAssociatedSelectionUuid());
        selection.setExternalSelectionUuid(selectionNodeV1.getExternalSelectionUuid());
        selection.setRecognisingOrganisationUuid(organisationSelectionNodeV1.getOrganisationDetails().getRecognisingOrganisationUuid());
        selection.setExternalBookingUuid(organisationSelectionNodeV1.getBookingDetails().getExternalBookingUuid());
        selection.setExternalBookingReference(organisationSelectionNodeV1.getBookingDetails().getExternalBookingReference());
        selection.setSelectionDate(selectionNodeV1.getSelectionDate());
        selection.setDeliveryStatus(selectionNodeV1.getDeliveryStatus());
        selection.setDeliveryStatusChangedDatetime(selectionNodeV1.getDeliveryStatusChangedDatetime());
        selection.setConfirmationStatus(selectionNodeV1.getConfirmationStatus());
        selection.setConfirmationStatusChangedDatetime(selectionNodeV1.getConfirmationStatusChangedDatetime());
        selection.setOverallMinimumScore(selectionNodeV1.getOverallMinimumScore());
        selection.setMinimumScoreSatisfied(selectionNodeV1.getMinimumScoreSatisfied());
        selection.setCaseNumber(selectionNodeV1.getCaseNumber());
        selection.setPersonDepartment(selectionNodeV1.getPersonDepartment());
        selection.setUpdatedDatetime(OffsetDateTime.now());
        selection.setEventDatetime(OffsetDateTime.now());

        return selection;
    }


    /**
     * copy organisationNodeV1 from source to destination node
     */
    public OrganisationSelectionNodeV1 generateOrganisationSelectionNode(OrganisationSelectionNodeV1 source) {
        OrganisationSelectionNodeV1 organisationSelectionNodeV1 = new OrganisationSelectionNodeV1();
        organisationSelectionNodeV1.setSelection(setSelectionNode(source.getSelection()));
        organisationSelectionNodeV1.setOrganisationDetails(source.getOrganisationDetails());
        organisationSelectionNodeV1.setBookingDetails(source.getBookingDetails());
        organisationSelectionNodeV1.setLocationDetails(source.getLocationDetails());

        return organisationSelectionNodeV1;
    }

    public SelectionNodeV1 setSelectionNode(SelectionNodeV1 source)
    {
        SelectionNodeV1 selection = new SelectionNodeV1();
        selection.setSelectionUuid(source.getSelectionUuid());
        selection.setAssociatedSelectionUuid(source.getAssociatedSelectionUuid());
        selection.setExternalSelectionUuid(source.getExternalSelectionUuid());
        selection.setSelectionDate(source.getSelectionDate());
        selection.setDeliveryStatus(source.getDeliveryStatus());
        selection.setDeliveryStatusChangedDatetime(source.getDeliveryStatusChangedDatetime());
        selection.setConfirmationStatus(source.getConfirmationStatus());
        selection.setConfirmationStatusChangedDatetime(source.getConfirmationStatusChangedDatetime());
        selection.setOverallMinimumScore(source.getOverallMinimumScore());
        selection.setMinimumScoreSatisfied(source.getMinimumScoreSatisfied());
        selection.setCaseNumber(source.getCaseNumber());
        selection.setPersonDepartment(source.getPersonDepartment());
        selection.setTrfNumber(source.getTrfNumber());
        selection.setSelectionDate(source.getSelectionDate());
        selection.setMinimumScores(source.getMinimumScores());
        return selection;
    }

    /**
     * check if selection is unique
     *
     * @return true if unique
     */
    public boolean isSelectionUnique(List<Selection> selections, Selection selection) {
        for (Selection selection1 : selections) {
            if (Objects.nonNull(selection1.getRecognisingOrganisationUuid())
                    && selection1.getRecognisingOrganisationUuid().equals(selection.getRecognisingOrganisationUuid())) {
                return false;
            }
        }
        return true;
    }

    public Selection setSelectionFromCommand(DeliverROSelectionCommand command,Selection selection)
    {
        selection.setSelectionUuid(command.getEventBody().getSelection().getSelectionUuid());
        selection.setAssociatedSelectionUuid(command.getEventBody().getSelection().getAssociatedSelectionUuid());
        selection.setExternalSelectionUuid(command.getEventBody().getSelection().getExternalSelectionUuid());
        selection.setRecognisingOrganisationUuid(command.getEventBody().getOrganisationDetails().getRecognisingOrganisationUuid());
        selection.setExternalBookingUuid(command.getEventBody().getBookingDetails().getExternalBookingUuid());
        selection.setSelectionDate(command.getEventBody().getSelection().getSelectionDate());
        selection.setDeliveryStatus(command.getEventBody().getSelection().getDeliveryStatus());
        selection.setDeliveryStatusChangedDatetime(command.getEventBody().getSelection().getDeliveryStatusChangedDatetime());
        selection.setConfirmationStatus(command.getEventBody().getSelection().getConfirmationStatus());
        selection.setConfirmationStatusChangedDatetime(command.getEventBody().getSelection().getConfirmationStatusChangedDatetime());
        selection.setOverallMinimumScore(command.getEventBody().getSelection().getOverallMinimumScore());
        selection.setMinimumScoreSatisfied(command.getEventBody().getSelection().getMinimumScoreSatisfied());
        selection.setCaseNumber(command.getEventBody().getSelection().getCaseNumber());
        selection.setPersonDepartment(command.getEventBody().getSelection().getPersonDepartment());
        selection.setSelectionDate(command.getEventBody().getSelection().getSelectionDate());
        return selection;
    }

    /**
     * Build event header with varied event name
     */
    public BaseHeader buildHeader(BaseHeader eventHeaders, String eventName) {
        BaseHeader baseHeader = new BaseHeader();
        baseHeader.setEventName(eventName);
        baseHeader.setCorrelationId(eventHeaders.getCorrelationId());
        baseHeader.setEventDateTime(LocalDateTime.now(UTC));
        baseHeader.setTransactionId(eventHeaders.getTransactionId());
        baseHeader.setPartnerCode(eventHeaders.getPartnerCode());
        if (Objects.isNull(eventHeaders.getEventContext())) {
            Map<String, String> commandContext = new HashMap<>();
            eventHeaders.setEventContext(commandContext);
        }
        Map<String, String> context = new HashMap<>(eventHeaders.getEventContext());
        baseHeader.setEventContext(context);
        return baseHeader;
    }

    /**
     * set errors if duplicate selection found
     *
     * @param message error message
     */
    public BaseEventErrors getBaseEventErrors(String message) {
        BaseEventErrors baseEventErrors;
        List<ErrorDescription> errorDescriptions = new ArrayList<>();
        ErrorDescription errorDescription = new ErrorDescription();
        errorDescription.setMessage(message);
        errorDescription.setType(ErrorTypeEnum.VALIDATION);
        errorDescription.setTitle("Validation Failed");
        errorDescription.setErrorCode("V045");
        errorDescriptions.add(errorDescription);
        baseEventErrors = new BaseEventErrors(errorDescriptions);
        return baseEventErrors;
    }
}
