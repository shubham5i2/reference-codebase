package com.ielts.cmds.rd.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.application.exception.ResultDeliveryValidationException;
import com.ielts.cmds.rd.domain.command.BookingChangeAnalysisCommand;
import com.ielts.cmds.rd.domain.enums.ResultDataAnalysisOutcomeFlag;
import com.ielts.cmds.rd.domain.model.out.ReferenceDataNodeV1;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import com.ielts.cmds.rd.domain.utils.BuildResultReleaseNodeV1Utils;
import com.ielts.cmds.rd.domain.utils.DomainEventsPublisher;
import com.ielts.cmds.rd.infrastructure.entity.Result;
import com.ielts.cmds.rd.infrastructure.entity.ResultsStatusLabel;
import com.ielts.cmds.rd.infrastructure.entity.ResultsStatusType;
import com.ielts.cmds.rd.infrastructure.repositories.ProductConfigRepository;
import com.ielts.cmds.rd.infrastructure.repositories.ResultRepository;
import com.ielts.cmds.rd.infrastructure.repositories.ResultsStatusLabelRepository;
import com.ielts.cmds.rd.infrastructure.repositories.ResultsStatusTypeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.constraints.NotNull;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

import static com.ielts.cmds.rd.domain.RDConstants.EventType.*;


@Service
@Slf4j
@RequiredArgsConstructor
public class BookingChangeAnalysisDomainService extends AbstractDomainService {

    private final ResultRepository resultRepository;

    private final ObjectMapper objectMapper;

    private final BuildResultReleaseNodeV1Utils resultReleaseNodeV1Utils;

    private final DomainEventsPublisher domainEventsPublisher;

    private final ResultsStatusLabelRepository resultsStatusLabelRepository;

    private final ResultsStatusTypeRepository resultsStatusTypeRepository;

    private final ProductConfigRepository productConfigRepository;

    @Transactional
    public void on(@NotNull BookingChangeAnalysisCommand command)
            throws JsonProcessingException, ResultDeliveryValidationException, InvocationTargetException, IllegalAccessException {

        log.info("Received Booking change Analysis event with booking uuid {}", command.getEventBody().getBookingUuid());

        Optional<Result> optionalResult = resultRepository.findByBookingUuid(command.getEventBody().getBookingUuid());
        List<BaseEvent<BaseHeader>> baseEventList = new ArrayList<>();
        if (!optionalResult.isPresent()) {
            log.info("NoActionTaken event is published as Result is not found for the booking with bookingUuid {}",command.getEventBody().getBookingUuid());
            BaseEvent<BaseHeader> event = new BaseEvent<>(buildHeader(command.getEventHeaders(), NO_ACTION_TAKEN),
                    NO_ACTION_TAKEN, null, command.getAudit());
            baseEventList.add(event);
        } else {
            Optional<ResultsStatusType> optionalResultsStatusType = resultsStatusTypeRepository.findById(optionalResult.get().getResultsStatusTypeUuid());
            ResultsStatusType resultStatusType = null;
            if (optionalResultsStatusType.isPresent()) {
                resultStatusType = optionalResultsStatusType.get();
            }

            List<BaseEvent<BaseHeader>> reportGenerationRequestedEventList = new ArrayList<>();
            Optional<BaseEvent<BaseHeader>> legacyResultDeliveryEvent = Optional.empty();
            if (Objects.nonNull(resultStatusType)) {
                legacyResultDeliveryEvent = legacyResultDeliveryRequestedEvent(command,
                        optionalResult, resultStatusType);

                //change legacyResultDeliveryRequested event name to NoActionTaken to restrict LA delivery trigger from booking
                legacyResultDeliveryEvent.ifPresent(laEvent -> {
                    laEvent.getEventHeader().setEventName(NO_ACTION_TAKEN);
                    laEvent.getEventHeader().getEventContext().put("reason","To restrict Result Delivery to LA when Booking updated");
                });

                //generate reportGenerationRequested event multiple times with different renditionTypeUuid
                reportGenerationRequestedEventList = getEventsForReportGenerationRequested(command.getEventBody().getPartnerCode(), command.getEventBody().getProductUuid(), command.getEventHeaders(), optionalResult.get(), resultStatusType);

                //change ReportGenerationRequested event name to NoActionTaken to restrict generation trigger from booking
                reportGenerationRequestedEventList.
                        forEach(generationEvent -> {
                            generationEvent.getEventHeader().setEventName(NO_ACTION_TAKEN);
                            generationEvent.getEventHeader().getEventContext().put("reason","To restrict Report Generation when Booking updated");
                        });
            }
            legacyResultDeliveryEvent.ifPresent(baseEventList::add);

            if (!reportGenerationRequestedEventList.isEmpty()) {
                baseEventList.addAll(reportGenerationRequestedEventList);
            }

            if (baseEventList.isEmpty()) {
                baseEventList.add(noActionRequiredEvent(command.getEventHeaders()));
            }

        }
        domainEventsPublisher.baseEventListPublisher(baseEventList);
    }

    @Override
    public List<BaseEvent<BaseHeader>> getEventsForReportGenerationRequested(String partnerCode, UUID productUuid, BaseHeader baseHeader, Result result, ResultsStatusType resultsStatusType) throws JsonProcessingException {

        List<BaseEvent<BaseHeader>> reportGenerationRequestedEvents = new ArrayList<>();

        if (baseHeader.getEventContext().containsKey(ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getKey())
                && (baseHeader.getEventContext().get(ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getKey()).equals("true"))) {
            if ((Objects.equals(resultsStatusType.getResultStatusCode(), RELEASED))) {
                log.info("Report Generation is to be initiated as TRF CRITICAL INFORMATION is changed for booking with resultUuid {}",result.getResultUuid());
                ReportGenerationEventInput reportGenerationEventInput = new ReportGenerationEventInput(partnerCode, productUuid, result.getResultUuid());

                List<BaseEvent<BaseHeader>> generationEventList = prepareReportGenerationEvents
                        (baseHeader, reportGenerationEventInput);
                reportGenerationRequestedEvents.addAll(generationEventList);

            } else {
                log.info("NoActionTaken event published as Result status is not RELEASED ");
                BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
                baseEvent.setEventBody(NO_ACTION_TAKEN);
                baseEvent.setEventHeader(buildHeader(baseHeader, NO_ACTION_TAKEN));
                baseEvent.setEventErrors(null);
                reportGenerationRequestedEvents.add(baseEvent);
            }
        }
        return reportGenerationRequestedEvents;
    }


    private Optional<ResultsStatusLabel> setResultStatusLabel(Optional<Result> optionalResult) {
        ResultsStatusLabel resultStatusLabel = new ResultsStatusLabel();
        if (optionalResult.isPresent() && Objects.nonNull(optionalResult.get().getResultsStatusLabelUuid())) {
            final UUID resultStatusLabelUuid = optionalResult.get().getResultsStatusLabelUuid();
            Optional<ResultsStatusLabel> optionalResultsStatusLabel = resultsStatusLabelRepository.findById(resultStatusLabelUuid);
            if (optionalResultsStatusLabel.isPresent()) {
                final String resultStatusLabelCode = optionalResultsStatusLabel.get().getResultsStatusLabelCode();
                resultStatusLabel.setResultsStatusLabelCode(resultStatusLabelCode);
                resultStatusLabel.setResultsStatusLabelUuid(resultStatusLabelUuid);
                return Optional.of(resultStatusLabel);
            }
        }
        return Optional.empty();
    }

    private ResultsStatusType setResultStatusType(Optional<Result> optionalResult) {
        ResultsStatusType resultStatusType = new ResultsStatusType();
        if (optionalResult.isPresent() && Objects.nonNull(optionalResult.get().getResultsStatusTypeUuid())) {
            final UUID resultStatusTypeUuid = optionalResult.get().getResultsStatusTypeUuid();
            Optional<ResultsStatusType> optionalResultsStatusType = resultsStatusTypeRepository.findById(resultStatusTypeUuid);
            if (optionalResultsStatusType.isPresent()) {
                final String resultStatusTypeCode = optionalResultsStatusType.get().getResultStatusCode();
                resultStatusType.setResultStatusTypeUuid(resultStatusTypeUuid);
                resultStatusType.setResultStatusCode(resultStatusTypeCode);
            }
        }
        return resultStatusType;

    }

    private ResultReleasedNodeV1 buildResultNodeV1(Optional<Result> optionalResult) {
        ResultReleasedNodeV1 resultReleasedNodeV1 = null;
        if (optionalResult.isPresent()) {
            resultReleasedNodeV1 = resultReleaseNodeV1Utils.buildResultReleasedNodeV1(optionalResult.get().getResultUuid());
        }
        ResultsStatusType resultStatusType = setResultStatusType(optionalResult);
        Optional<ResultsStatusLabel> resultStatusLabel = setResultStatusLabel(optionalResult);

        if (Objects.nonNull(resultReleasedNodeV1)) {
            getReferenceData(resultReleasedNodeV1, resultStatusType, resultStatusLabel);
        }
        return resultReleasedNodeV1;

    }

    private BaseEvent<BaseHeader> noActionRequiredEvent(BaseHeader eventHeaders) {
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        baseEvent.setEventHeader(buildHeader(eventHeaders, NO_ACTION_TAKEN));
        baseEvent.setEventBody(NO_ACTION_TAKEN);
        baseEvent.setEventErrors(null);
        return baseEvent;
    }

    private Optional<BaseEvent<BaseHeader>> legacyResultDeliveryRequestedEvent(BookingChangeAnalysisCommand command,
                                                                               Optional<Result> optionalResult, ResultsStatusType resultStatusType) throws JsonProcessingException {
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        if (command.getEventHeaders().getEventContext()
                .containsKey(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey())
                && (command.getEventHeaders().getEventContext()
                .get(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey())
                .equals(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue()))) {
            if ((Objects.equals(resultStatusType.getResultStatusCode(), RELEASED))) {
                log.info("Triggering notification to LA as Result Status is RELEASED and RESULT INFORMATION is changed for booking with bookingUuid {}",command.getEventBody().getBookingUuid());
                baseEvent.setEventHeader(buildHeader(command.getEventHeaders(), LEGACY_RESULT_DELIVERY_REQUESTED));
                String body = objectMapper.writeValueAsString(buildResultNodeV1(optionalResult));
                baseEvent.setEventBody(body);
                baseEvent.setEventErrors(null);
                return Optional.of(baseEvent);
            } else if ((Objects.equals(resultStatusType.getResultStatusCode(), PERMANENTLY_WITHHELD))) {
                log.info("Result Status is PERMANENTLY_WITHHELD for booking with bookingUuid {}",command.getEventBody().getBookingUuid());
                baseEvent.setEventHeader(buildHeader(command.getEventHeaders(), NO_ACTION_TAKEN));
                String body = objectMapper.writeValueAsString(NO_ACTION_TAKEN);
                baseEvent.setEventBody(body);
                baseEvent.setEventErrors(null);
                return Optional.of(baseEvent);

            }
        }

        return Optional.empty();
    }


    private void getReferenceData(ResultReleasedNodeV1 resultReleasedNodeV1, ResultsStatusType resultStatusType,
                                  Optional<ResultsStatusLabel> resultStatusLabel) {
        ReferenceDataNodeV1 referenceDataNodeV1 = new ReferenceDataNodeV1();
        ReferenceDataNodeV1 referenceDataNodeV2 = new ReferenceDataNodeV1();
        List<ReferenceDataNodeV1> referenceDataNodeV1List = new ArrayList<>();
        if (resultStatusType != null) {
            referenceDataNodeV1.setReferenceId(resultStatusType.getResultStatusTypeUuid().toString());
            referenceDataNodeV1.setReferenceValue(resultStatusType.getResultStatusCode());
        }
        if (resultStatusLabel.isPresent()) {
            referenceDataNodeV2.setReferenceId(resultStatusLabel.get().getResultsStatusLabelUuid().toString());
            referenceDataNodeV2.setReferenceValue(resultStatusLabel.get().getResultsStatusLabelCode());
        }

        referenceDataNodeV1List.add(referenceDataNodeV1);
        referenceDataNodeV1List.add(referenceDataNodeV2);
        resultReleasedNodeV1.setReferenceData(referenceDataNodeV1List);
    }

    @Override
    protected ObjectMapper getObjectMapper() {
        return this.objectMapper;
    }

    @Override
    protected BuildResultReleaseNodeV1Utils getBuildResultReleasedNodeV1Utils() {
        return this.resultReleaseNodeV1Utils;
    }

    @Override
    protected ProductConfigRepository getProductConfigRepository() {
        return this.productConfigRepository;
    }

}
