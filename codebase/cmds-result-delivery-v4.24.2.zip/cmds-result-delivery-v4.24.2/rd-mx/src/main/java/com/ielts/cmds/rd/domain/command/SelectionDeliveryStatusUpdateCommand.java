package com.ielts.cmds.rd.domain.command;

import com.ielts.cmds.application.command.BaseCommand;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.domain.model.in.Selection;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
public class SelectionDeliveryStatusUpdateCommand extends BaseCommand<BaseHeader, Selection> {

    @Builder
    public SelectionDeliveryStatusUpdateCommand(BaseHeader eventHeader, Selection eventBody,
                                      BaseEventErrors eventErrors) {
        super(eventHeader, eventBody, eventErrors, null);
    }
}
