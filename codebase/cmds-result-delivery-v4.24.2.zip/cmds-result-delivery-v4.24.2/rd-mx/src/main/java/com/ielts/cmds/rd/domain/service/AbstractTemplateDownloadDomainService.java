package com.ielts.cmds.rd.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.outbox.event.OutboxEventBuilder;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rd.application.exception.ResultDeliveryValidationException;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.domain.command.TemplateDownloadCommand;
import com.ielts.cmds.rd.domain.model.enums.RenditionTypeCodeEnum;
import com.ielts.cmds.rd.domain.model.out.ReferenceDataNodeV1;
import com.ielts.cmds.rd.domain.model.out.ResultDeliveryRecognisingOrganisationAddressV1;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import com.ielts.cmds.rd.domain.utils.*;
import com.ielts.cmds.rd.infrastructure.entity.*;
import com.ielts.cmds.rd.infrastructure.repositories.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.validation.constraints.NotNull;
import java.lang.reflect.InvocationTargetException;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.*;

import static com.ielts.cmds.rd.domain.RDConstants.EventType.*;
import static com.ielts.cmds.rd.domain.RDConstants.GenericConstants.TEMPLATE_NOT_FOUND_MESSAGE;
import static com.ielts.cmds.rd.domain.RDConstants.GenericConstants.ERROR_MESSAGE;
import static com.ielts.cmds.rd.domain.RDConstants.GenericConstants.ERROR_CODE;
import static java.time.ZoneOffset.UTC;

/**
 * This abstract class is responsible for
 * 1. Updating result trf print status table with required data
 * 2. Sending payload response to rd-dist-ui lambda function inorder to download templates from UI
 * and also update print count, printed by and print datetime status in UI
 */

@Slf4j
@RequiredArgsConstructor
abstract class AbstractTemplateDownloadDomainService {

    private final ObjectMapper objectMapper;

    private final ResultRepository resultRepository;

    private final ResultsRenditionRepository resultsRenditionRepository;

    private final ResultTrfPrintStatusRepository resultTrfPrintStatusRepository;

    private final SelectionRepository selectionRepository;

    private final RenditionTypeRepository renditionTypeRepository;

    private final RecognisingOrganisationRepository recognisingOrganisationRepository;

    private final BookingRepository bookingRepository;

    private final BuildResultReleaseNodeV1Utils buildResultReleaseNodeV1Utils;

    private final BuildSelectionNodeV1Utils buildOrganisationSelectionNodeV1Utils;

    private final BuildRecognisingOrganisationNodeV1Utils buildRecognisingOrganisationNodeV1Utils;

    private final DomainEventsPublisher domainEventsPublisher;

    private final OutboxEventBuilder outboxEventBuilder = new OutboxEventBuilder();

    private final ResultsStatusTypeRepository resultsStatusTypeRepository;

    @Autowired
    private final RbacAuthorization rbacAuthorization;

    public void process(@NotNull final TemplateDownloadCommand command, RenditionTypeCodeEnum renditionTypeCodeEnum) throws JsonProcessingException, InvocationTargetException, IllegalAccessException, ResultDeliveryValidationException {

        log.info("Received POST/v1/" + renditionTypeCodeEnum.toString().toLowerCase() + "/booking/{bookingUuid}/download/" + renditionTypeCodeEnum.toString().toLowerCase() + " event with transaction id {}", command.getEventHeaders().getTransactionId());

        List<BaseEvent<UiHeader>> publishingEventList = new ArrayList<>();
        BaseEvent<UiHeader> publishingEvent;
        Map<String, String> errors;

        try {
            String bookingUuidFromContext = command.getEventHeaders().getEventContext().get("bookingUuid");
            UUID bookingUuid = UUID.fromString(bookingUuidFromContext);
            Optional<Booking> optionalBooking = bookingRepository.findById(bookingUuid);
            Booking booking = optionalBooking.orElseThrow(() -> new ResultDeliveryValidationException
                    ("Template Download event failed as Booking is not present", new Throwable()));
            boolean isRbacValidationPassed = rbacAuthorization.isUserAuthorized(booking, command.getEventHeaders(), RDConstants.GenericConstants.DOWNLOAD_ETRF);

            if (isRbacValidationPassed && isResultStatusTypeValid(booking)) {
                Result result = getResult(booking.getBookingUuid());
                ResultTrfPrintStatus resultTrfPrintStatus = new ResultTrfPrintStatus();
                updateResultTrfPrintStatusDetails(result, renditionTypeCodeEnum, resultTrfPrintStatus);
                String eventBody = generateEventBody(booking.getBookingUuid(), result.getResultUuid(), renditionTypeCodeEnum);
                publishingEvent = getSuccessEventToPublish(renditionTypeCodeEnum, command.getEventHeaders(), eventBody);
            } else {
                errors = getErrorMessageAndCode(isRbacValidationPassed);
                BaseEventErrors baseEventErrors = getBaseEventErrors(errors.get(ERROR_MESSAGE), errors.get(ERROR_CODE));
                publishingEvent = getFailedEventToPublish(renditionTypeCodeEnum, command.getEventHeaders(), baseEventErrors);
            }

        } catch (ResultDeliveryValidationException resultDeliveryValidationException) {
            log.error("TemplateDownloadCommand execution failed due to: ", resultDeliveryValidationException);
            String errorCode = "V045";
            BaseEventErrors baseEventErrors = getBaseEventErrors(resultDeliveryValidationException.getMessage(), errorCode);
            publishingEvent = getFailedEventToPublish(renditionTypeCodeEnum, command.getEventHeaders(), baseEventErrors);
        } catch (RbacValidationException e) {
            log.error("RBAC Validation Failed - {} ", e.getMessage());
            errors = getErrorMessageAndCode(false);
            BaseEventErrors baseEventErrors = getBaseEventErrors(errors.get(ERROR_MESSAGE), errors.get(ERROR_CODE));
            publishingEvent = getFailedEventToPublish(renditionTypeCodeEnum, command.getEventHeaders(), baseEventErrors);
        }

        BaseEvent<UiHeader> persistenceIgnoredEvent = (BaseEvent<UiHeader>) outboxEventBuilder.buildAsPersistenceIgnored(publishingEvent);
        publishingEventList.add(persistenceIgnoredEvent);

        domainEventsPublisher.uiEventListPublisher(publishingEventList);
    }

    private Map<String, String> getErrorMessageAndCode(boolean isRbacValidationPassed) {
        Map<String, String> errors = new HashMap<>();
        if (!isRbacValidationPassed) {
            errors.put(ERROR_MESSAGE, "You do not have permission to download eTRF and TRF");
            errors.put(ERROR_CODE, "V040");
        } else {
            errors.put(ERROR_MESSAGE, "Results status not set to released");
            errors.put(ERROR_CODE, "V039");
        }
        return errors;
    }

    /**
     * isResultStatusTypeValid
     *
     * @param booking Booking
     * @return resultStatusTypeValidationStatus
     */

//   validation to check whether result and result status is released or not
    private boolean isResultStatusTypeValid(Booking booking) throws ResultDeliveryValidationException {
        boolean isValid;
        Result result = getResult(booking.getBookingUuid());
        Optional<ResultsStatusType> optionalResultsStatusType = resultsStatusTypeRepository.findById(result.getResultsStatusTypeUuid());

        if (optionalResultsStatusType.isPresent() && optionalResultsStatusType.get().getResultStatusCode().equals(RELEASED)) {
            isValid = true;
        } else {
            isValid = false;
        }
        return isValid;
    }

    private Result getResult(UUID bookingUuid) throws ResultDeliveryValidationException {
        Optional<Result> optionalResult = resultRepository.findByBookingUuid(bookingUuid);
        return optionalResult.orElseThrow(() -> new ResultDeliveryValidationException
                ("Template Download event failed as Result is not present for the booking uuid " + bookingUuid, new Throwable()));
    }

    /**
     * getSuccessEventToPublish
     *
     * @param renditionTypeCodeEnum renditionTypeCodeEnum
     * @param uiHeader              UiHeader
     * @param eventBody             publishing Event Body
     * @return success event
     */

    private BaseEvent<UiHeader> getSuccessEventToPublish(final RenditionTypeCodeEnum renditionTypeCodeEnum, final UiHeader uiHeader, String eventBody) {
        BaseEvent<UiHeader> publishingEvent;
        if (renditionTypeCodeEnum.equals(RenditionTypeCodeEnum.ETRF)) {
            publishingEvent = generatePublishingEvent(uiHeader, ETRF_DOWNLOAD_RESPONSE_GENERATED, eventBody, null);
        } else {
            publishingEvent = generatePublishingEvent(uiHeader, TRF_DOWNLOAD_RESPONSE_GENERATED, eventBody, null);
        }
        return publishingEvent;
    }

    /**
     * generate publishing event
     *
     * @param uiHeader              UiHeader
     * @param errors                BaseEventErrors
     * @param renditionTypeCodeEnum renditionTypeCodeEnum
     * @return failed event
     */

    private BaseEvent<UiHeader> getFailedEventToPublish(final RenditionTypeCodeEnum renditionTypeCodeEnum, final UiHeader uiHeader, BaseEventErrors errors) {
        BaseEvent<UiHeader> publishingEvent;
        if (renditionTypeCodeEnum.equals(RenditionTypeCodeEnum.ETRF)) {
            publishingEvent = generatePublishingEvent(uiHeader, ETRF_DOWNLOAD_RESPONSE_GENERATE_FAILED, null, errors);
        } else {
            publishingEvent = generatePublishingEvent(uiHeader, TRF_DOWNLOAD_RESPONSE_GENERATE_FAILED, null, errors);
        }
        return publishingEvent;
    }

    /**
     * @param result                result
     * @param renditionTypeCodeEnum renditionTypeCodeEnum
     * @param resultTrfPrintStatus  resultTrfPrintStatus
     * @throws ResultDeliveryValidationException
     */

    private void updateResultTrfPrintStatusDetails(Result result, RenditionTypeCodeEnum renditionTypeCodeEnum, ResultTrfPrintStatus resultTrfPrintStatus) throws ResultDeliveryValidationException {

        RenditionType renditionType = renditionTypeRepository.findByRenditionTypeCodeEnum(renditionTypeCodeEnum);

        ResultTrfPrintStatus printStatus = resultTrfPrintStatusRepository.findByResultUuidAndRenditionTypeUuid(result.getResultUuid(), renditionType.getRenditionTypeUuid());

        if (Objects.nonNull(printStatus)) {
            increaseExistingTemplatePrintCount(printStatus, result, renditionType);
        } else {
            increaseNonExistingTemplatePrintCount(resultTrfPrintStatus, result, renditionType);
        }
    }

    /**
     * @param resultTrfPrintStatus resultTrfPrintStatus
     * @param result               result
     * @param renditionType        renditionType
     * @throws ResultDeliveryValidationException
     */
    private void increaseNonExistingTemplatePrintCount(ResultTrfPrintStatus resultTrfPrintStatus, Result result, RenditionType renditionType) throws ResultDeliveryValidationException {

        resultTrfPrintStatus.setResultTrfPrintStatusUuid(UUID.randomUUID());
        resultTrfPrintStatus.setPrintCount(1);

        resultTrfPrintStatus.setPrintedBy("Admin");
        resultTrfPrintStatus.setPrintedDateTime(OffsetDateTime.now(UTC));
        resultTrfPrintStatus.setResultUuid(result.getResultUuid());

        //get latest eTRF/TRF template of a test taker
        List<ResultsRendition> resultsRenditionList = resultsRenditionRepository.findByResultUuidOrderByUpdatedDatetimeDesc(result.getResultUuid());
        ResultsRendition resultsRendition = resultsRenditionList.stream()
                .filter(rendition -> rendition.getRenditionTypeUuid().equals(renditionType.getRenditionTypeUuid())).findFirst()
                .orElseThrow(() -> new ResultDeliveryValidationException(TEMPLATE_NOT_FOUND_MESSAGE, new Throwable()));

        resultTrfPrintStatus.setResultsRenditionUuid(resultsRendition.getResultsRenditionUuid());
        resultTrfPrintStatus.setRenditionTypeUuid(resultsRendition.getRenditionTypeUuid());
        resultTrfPrintStatus.setUpdatedDateTime(OffsetDateTime.now(UTC));

        resultTrfPrintStatusRepository.save(resultTrfPrintStatus);
    }

    /**
     * @param resultTrfPrintStatus resultTrfPrintStatus
     * @param result               result
     * @param renditionType        renditionType
     * @throws ResultDeliveryValidationException
     */
    private void increaseExistingTemplatePrintCount(ResultTrfPrintStatus resultTrfPrintStatus, Result result, RenditionType renditionType) throws ResultDeliveryValidationException {

        resultTrfPrintStatus.setResultTrfPrintStatusUuid(resultTrfPrintStatus.getResultTrfPrintStatusUuid());
        resultTrfPrintStatus.setPrintCount(resultTrfPrintStatus.getPrintCount() + 1);
        resultTrfPrintStatus.setPrintedBy(resultTrfPrintStatus.getPrintedBy());
        resultTrfPrintStatus.setPrintedDateTime(OffsetDateTime.now(UTC));
        resultTrfPrintStatus.setResultUuid(result.getResultUuid());

        //get latest eTRF/TRF template of a test taker
        List<ResultsRendition> resultsRenditionList = resultsRenditionRepository.findByResultUuidOrderByUpdatedDatetimeDesc(result.getResultUuid());
        ResultsRendition resultsRendition = resultsRenditionList.stream()
                .filter(rendition -> rendition.getRenditionTypeUuid().equals(renditionType.getRenditionTypeUuid())).findFirst()
                .orElseThrow(() -> new ResultDeliveryValidationException(TEMPLATE_NOT_FOUND_MESSAGE, new Throwable()));

        resultTrfPrintStatus.setResultsRenditionUuid(resultsRendition.getResultsRenditionUuid());
        resultTrfPrintStatus.setRenditionTypeUuid(resultsRendition.getRenditionTypeUuid());
        resultTrfPrintStatus.setUpdatedDateTime(OffsetDateTime.now(UTC));

        resultTrfPrintStatusRepository.save(resultTrfPrintStatus);
    }

    /**
     * generate publishing event
     *
     * @param uiHeader  UiHeader
     * @param eventName publishing Event Name
     * @param eventBody publishing Event Body
     * @param errors    Event Errors
     * @return publishing event
     */
    private BaseEvent<UiHeader> generatePublishingEvent
    (UiHeader uiHeader, String eventName, String eventBody, BaseEventErrors errors) {
        BaseEvent<UiHeader> baseEvent = new BaseEvent<>();
        baseEvent.setEventHeader(buildHeader(uiHeader, eventName));
        baseEvent.setEventBody(eventBody);
        baseEvent.setEventErrors(errors);

        return baseEvent;
    }

    /**
     * @param bookingUuid           bookingUuid from incoming event
     * @param resultUuid            resultUuid from result entity
     * @param renditionTypeCodeEnum renditionTypeCodeEnum
     * @return event body
     */
    private String generateEventBody(UUID bookingUuid, UUID resultUuid, RenditionTypeCodeEnum renditionTypeCodeEnum) throws JsonProcessingException, ResultDeliveryValidationException {

        ResultReleasedNodeV1 resultReleasedNodeV1;

        Optional<Booking> optionalBooking = bookingRepository.findById(bookingUuid);
        Booking booking = optionalBooking.orElseThrow(() -> new ResultDeliveryValidationException
                ("Template Download event failed as Booking is not present", new Throwable()));

        Optional<Result> optionalResult = resultRepository.findByBookingUuid(bookingUuid);
        Result result = optionalResult.orElseThrow(() -> new ResultDeliveryValidationException
                ("Template Download event failed as Result is not present", new Throwable()));

        resultReleasedNodeV1 = buildResultReleaseNodeV1Utils.buildResultReleasedNodeV1(resultUuid);

        resultReleasedNodeV1.setReferenceData(setReferenceDataForRendition(renditionTypeCodeEnum, result));

        List<Selection> selections = selectionRepository.findByExternalBookingUuid(booking.getExternalBookingUuid());

        for (Selection selection : selections) {
            Optional<RecognisingOrganisation> organisationOptional = recognisingOrganisationRepository.findById(selection.getRecognisingOrganisationUuid());
            RecognisingOrganisation organisation = organisationOptional.orElseThrow(() -> new ResultDeliveryValidationException
                    ("Template Download event failed as Recognising Organisation is not present", new Throwable()));

            resultReleasedNodeV1.setOrganisation(buildRecognisingOrganisationNodeV1Utils.buildRecognisingOrganisationNodeV1(organisation.getRecognisingOrganisationUuid()));
            resultReleasedNodeV1.getOrganisation().setAddresses(setAddressesNodeV1FromEntity(organisation.getRecognisingOrganisationAddresses()));
            resultReleasedNodeV1.setSelection(buildOrganisationSelectionNodeV1Utils.buildSelectionNodeV1(selection.getSelectionUuid()));
        }
        return objectMapper.writeValueAsString(resultReleasedNodeV1);
    }

    public List<ReferenceDataNodeV1> setReferenceDataForRendition(RenditionTypeCodeEnum renditionTypeCode, Result result) throws ResultDeliveryValidationException {

        RenditionType renditionType = renditionTypeRepository.findByRenditionTypeCodeEnum(renditionTypeCode);

        List<ResultsRendition> resultsRenditionList = resultsRenditionRepository.findByResultUuidOrderByUpdatedDatetimeDesc(result.getResultUuid());
        ResultsRendition resultsRendition = resultsRenditionList.stream()
                .filter(rendition -> rendition.getRenditionTypeUuid().equals(renditionType.getRenditionTypeUuid())).findFirst()
                .orElseThrow(() -> new ResultDeliveryValidationException(TEMPLATE_NOT_FOUND_MESSAGE, new Throwable()));

        List<ReferenceDataNodeV1> referenceDataNodeV1List = new ArrayList<>();

        ReferenceDataNodeV1 referenceDataNodeV1 = new ReferenceDataNodeV1();

        referenceDataNodeV1.setReferenceId(renditionType.getRenditionTypeUuid().toString());
        referenceDataNodeV1.setReferenceValue(resultsRendition.getRenditionFilePath());

        referenceDataNodeV1List.add(referenceDataNodeV1);
        return referenceDataNodeV1List;
    }

    /**
     * return ResultDeliveryRecognisingOrganisationAddressV1 list from entity list
     *
     * @param recognisingOrganisationAddresses list of entity objects
     */
    private List<ResultDeliveryRecognisingOrganisationAddressV1> setAddressesNodeV1FromEntity(List<RecognisingOrganisationAddress> recognisingOrganisationAddresses) {
        List<ResultDeliveryRecognisingOrganisationAddressV1> addressV1List = new ArrayList<>();
        for (RecognisingOrganisationAddress address : recognisingOrganisationAddresses) {
            ResultDeliveryRecognisingOrganisationAddressV1 addressV1 = new ResultDeliveryRecognisingOrganisationAddressV1(
                    address.getAddressUuid(), address.getAddressTypeUuid(), address.getAddressLine1(), address.getAddressLine2(),
                    address.getAddressLine3(), address.getAddressLine4(), address.getCity(), address.getPostalCode());

            addressV1List.add(addressV1);
        }
        return addressV1List;
    }

    /**
     * generate baseEvent headers
     *
     * @param eventName publishing event name
     * @return event headers for publishing event
     */
    private UiHeader buildHeader(UiHeader eventHeaders, String eventName) {
        UiHeader uiHeader = new UiHeader();
        uiHeader.setConnectionId(eventHeaders.getConnectionId());
        uiHeader.setEventName(eventName);
        uiHeader.setCorrelationId(eventHeaders.getCorrelationId());
        uiHeader.setEventDateTime(LocalDateTime.now());
        uiHeader.setTransactionId(eventHeaders.getTransactionId());
        uiHeader.setPartnerCode(eventHeaders.getPartnerCode());
        uiHeader.setEventContext(eventHeaders.getEventContext());
        return uiHeader;
    }

    /**
     * generate base event errors
     *
     * @param message accepts exception as an argument
     * @return event errors for publishing event
     */
    public BaseEventErrors getBaseEventErrors(String message, String errorCode) {
        BaseEventErrors baseEventErrors;
        List<ErrorDescription> errorDescriptions = new ArrayList<>();

        ErrorDescription description = new ErrorDescription();
        description.setMessage(message);
        description.setType(ErrorTypeEnum.VALIDATION);
        description.setTitle(message);
        description.setErrorCode(errorCode);
        description.setInterfaceName("Result Delivery");

        errorDescriptions.add(description);
        baseEventErrors = new BaseEventErrors(errorDescriptions);
        return baseEventErrors;
    }
}
