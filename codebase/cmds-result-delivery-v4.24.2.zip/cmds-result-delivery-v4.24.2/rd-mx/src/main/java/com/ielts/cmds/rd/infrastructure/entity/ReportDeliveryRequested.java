package com.ielts.cmds.rd.infrastructure.entity;

import lombok.Data;
import lombok.ToString;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.UUID;

@Data
@Entity
@ToString
@Table(name = "report_delivery_requested",uniqueConstraints = { @UniqueConstraint(columnNames = { "report_generation_requested_uuid" }) })
public class ReportDeliveryRequested implements Serializable {

    private static final long serialVersionUID = -9166574440100059322L;

    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
    @Column(name = "report_delivery_requested_uuid", unique = true, nullable = false)
    private UUID reportDeliveryRequestedUuid;

    @Column(name = "booking_uuid")
    private UUID bookingUuid;

    @Column(name = "report_generation_requested_uuid")
    private UUID reportGenerationRequestedUuid;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;

    @Version
    @Column(name = "concurrency_version")
    private Integer concurrencyVersion;

}
