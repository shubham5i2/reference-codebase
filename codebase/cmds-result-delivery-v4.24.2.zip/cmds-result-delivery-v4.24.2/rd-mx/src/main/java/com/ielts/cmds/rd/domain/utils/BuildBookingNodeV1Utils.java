package com.ielts.cmds.rd.domain.utils;


import com.ielts.cmds.rd.domain.model.out.BookingLineNodeV1;
import com.ielts.cmds.rd.domain.model.out.BookingNodeV1;
import com.ielts.cmds.rd.infrastructure.entity.Booking;
import com.ielts.cmds.rd.infrastructure.entity.BookingLine;
import com.ielts.cmds.rd.infrastructure.repositories.BookingRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class BuildBookingNodeV1Utils {

    private final BookingRepository bookingRepository;


    public BookingNodeV1 buildResultDeliveryBookingNodeV1(UUID bookingUuid) {
        BookingNodeV1 bookingNode = new BookingNodeV1();
        if (Objects.nonNull(bookingUuid)) {
            Optional<Booking> optionalBooking = bookingRepository.findById(bookingUuid);
            if (optionalBooking.isPresent()) {
                Booking booking = optionalBooking.get();
                bookingNode.setBookingUuid(booking.getBookingUuid());
                bookingNode.setExternalBookingUuid(booking.getExternalBookingUuid());
                bookingNode.setExternalBookingReference(booking.getExternalBookingReference());
                bookingNode.setShortCandidateNumber(booking.getShortCandidateNumber());
                bookingNode.setPartnerCode(booking.getPartnerCode());
                bookingNode.setLocationUuid(booking.getLocationUuid());
                bookingNode.setProductUuid(booking.getProductUuid());
                bookingNode.setTestDate(booking.getTestDate());
                bookingNode.setBookingStatus(booking.getBookingStatus());
                bookingNode.setBookingDetailStatus(booking.getBookingDetailStatus());
                bookingNode.setAgentName(booking.getAgentName());
                bookingNode.setUniqueTestTakerUuid(booking.getUniqueTestTakerUuid());
                bookingNode.setCompositeCandidateNumber(booking.getCompositeCandidateNumber());
                bookingNode.setExternalUniqueTestTakerUuid(booking.getExternalUniqueTestTakerUuid());
                bookingNode.setIdentityNumber(booking.getIdentityNumber());
                bookingNode.setIdentityTypeUuid(booking.getIdentityTypeUuid());
                bookingNode.setIdentityIssuingAuthority(booking.getIdentityIssuingAuth());
                bookingNode.setIdentityExpiryDate(booking.getIdentityExpiryDate());
                bookingNode.setFirstName(booking.getFirstName());
                bookingNode.setLastName(booking.getLastName());
                bookingNode.setBirthDate(booking.getBirthDate());
                bookingNode.setSexUuid(booking.getSexUuid());
                bookingNode.setEmail(booking.getEmail());
                bookingNode.setTitle(booking.getTitle());
                bookingNode.setPhone(booking.getPhone());
                bookingNode.setMobile(booking.getMobile());
                bookingNode.setLanguageUuid(booking.getLanguageUuid());
                bookingNode.setNationalityUuid(booking.getNationalityUuid());
                bookingNode.setAddressLine1(booking.getAddressLine1());
                bookingNode.setAddressLine2(booking.getAddressLine2());
                bookingNode.setAddressLine3(booking.getAddressLine3());
                bookingNode.setAddressLine4(booking.getAddressLine4());
                bookingNode.setStateTerritoryUuid(booking.getStateTerritoryUuid());
                bookingNode.setPostalCode(booking.getPostalCode());
                bookingNode.setCity(booking.getCity());
                bookingNode.setCountryUuid(booking.getCountryUuid());
                bookingNode.setYearsOfStudy(booking.getYearsOfStudy());
                bookingNode.setOccupationSectorUuid(booking.getOccupationSectorUuid());
                bookingNode.setOccupationLevelUuid(booking.getOccupationLevelUuid());
                bookingNode.setReasonForTestUuid(booking.getReasonForTestUuid());
                List<BookingLineNodeV1> bookingLineNodeV1List = booking.getBookingLines().stream()
                        .map(this::setBookingLineList).collect(Collectors.toList());
                bookingNode.setBookingLines(bookingLineNodeV1List);
            }
        }
        return bookingNode;
    }

    public BookingLineNodeV1 setBookingLineList(BookingLine bookingLine) {

        BookingLineNodeV1 bookingLineNodeV1 = new BookingLineNodeV1();
        bookingLineNodeV1.setBookingLineUuid(bookingLine.getBookingLineUuid());
        bookingLineNodeV1.setProductUuid(bookingLine.getProductUuid());
        bookingLineNodeV1.setExternalBookingLineUuid(bookingLine.getExternalBookingLineUuid());
        bookingLineNodeV1.setBookingLineStatus(bookingLine.getBookingLineStatus());

        return bookingLineNodeV1;
    }
}
