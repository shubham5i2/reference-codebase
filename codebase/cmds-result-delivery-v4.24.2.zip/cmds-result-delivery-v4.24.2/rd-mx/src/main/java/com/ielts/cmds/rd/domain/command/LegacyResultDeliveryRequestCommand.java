package com.ielts.cmds.rd.domain.command;

import com.ielts.cmds.application.command.BaseCommand;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class LegacyResultDeliveryRequestCommand extends BaseCommand<BaseHeader, ResultReleasedNodeV1> {

    @Builder
    public LegacyResultDeliveryRequestCommand(BaseHeader eventHeader, ResultReleasedNodeV1 eventBody,
                                              BaseEventErrors eventErrors, BaseAudit audit) {
        super(eventHeader, eventBody, eventErrors, audit);
    }

}
