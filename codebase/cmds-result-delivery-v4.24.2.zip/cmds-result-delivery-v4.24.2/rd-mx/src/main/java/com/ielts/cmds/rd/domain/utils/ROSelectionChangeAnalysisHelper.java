package com.ielts.cmds.rd.domain.utils;

import com.ielts.cmds.rd.domain.model.enums.ConfirmationStatusEnum;
import com.ielts.cmds.rd.domain.model.enums.DeliveryStatusEnum;
import com.ielts.cmds.rd.domain.model.enums.MinimumScoreSatisfiedEnum;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;
import com.ielts.cmds.rd.domain.model.out.RecognisedProductNodeV1;
import com.ielts.cmds.rd.domain.model.out.RecognisingOrganisationNodeV1;
import com.ielts.cmds.rd.domain.model.out.SelectionNodeV1;
import com.ielts.cmds.rd.infrastructure.entity.RecognisedProduct;
import com.ielts.cmds.rd.infrastructure.entity.RecognisingOrganisation;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ROSelectionChangeAnalysisHelper {

    /**
     * copy node date from source to destination
     * @return destination node
     */
    public OrganisationSelectionNodeV1 setNode(OrganisationSelectionNodeV1 source, OrganisationSelectionNodeV1 destination) {

        destination.setSelection(source.getSelection());
        destination.setOrganisationDetails(source.getOrganisationDetails());
        destination.setBookingDetails(source.getBookingDetails());
        destination.setLocationDetails(source.getLocationDetails());

        return destination;
    }

    /**
     * set RecognisingOrganisationNodeV1 from recognisingOrganising entity
     * for secondary selection event body
     */
    public RecognisingOrganisationNodeV1 setRecognisingOrganisationForSecondarySelection(RecognisingOrganisation recognisingOrganisation)
    {
        RecognisingOrganisationNodeV1 organisationNodeV1 = new RecognisingOrganisationNodeV1();

        organisationNodeV1.setRecognisingOrganisationUuid(recognisingOrganisation.getRecognisingOrganisationUuid());
        organisationNodeV1.setOrganisationId(recognisingOrganisation.getOrganisationId());
        organisationNodeV1.setOrganisationTypeUuid(recognisingOrganisation.getOrganisationTypeUuid());
        organisationNodeV1.setOrganisationId(recognisingOrganisation.getOrganisationId());
        organisationNodeV1.setName(recognisingOrganisation.getName());
        organisationNodeV1.setVerificationStatus(recognisingOrganisation.getVerificationStatus());
        organisationNodeV1.setPartnerCode(recognisingOrganisation.getPartnerCode());
        organisationNodeV1.setMethodOfDelivery(recognisingOrganisation.getMethodOfDelivery());
        organisationNodeV1.setParentRecognisingOrganisationUuid(recognisingOrganisation.getParentRecognisingOrganisationUuid());
        organisationNodeV1.setOrganisationStatus(recognisingOrganisation.getOrganisationStatus());
        organisationNodeV1.setOrganisationCode(recognisingOrganisation.getOrganisationCode());
        organisationNodeV1.setReplacedByRecognisingOrganisationUuid(recognisingOrganisation.getReplacedByRecognisingOrganisationUuid());

        List<RecognisedProductNodeV1> recognisedProducts = new ArrayList<>();
        for(RecognisedProduct recognisedProduct : recognisingOrganisation.getRecognisedProducts())
        {
            RecognisedProductNodeV1 recognisedProductNodeV1= new RecognisedProductNodeV1();
            recognisedProductNodeV1.setRecognisedProductUuid(recognisedProduct.getRecognisedProductUuid());
            recognisedProductNodeV1.setProductUuid(recognisedProduct.getProductUuid());
            recognisedProductNodeV1.setEffectiveFromDateTime(recognisedProduct.getEffectiveFromDatetime());
            recognisedProductNodeV1.setEffectiveToDateTime(recognisedProduct.getEffectiveToDatetime());
            recognisedProducts.add(recognisedProductNodeV1);
        }
        organisationNodeV1.setRecognisedProducts(recognisedProducts);
        organisationNodeV1.setLinkedOrganisations(new ArrayList<>());
        return organisationNodeV1;
    }

    /**
     * set selection data for secondary selection
     */
    public SelectionNodeV1 setSelectionForSecondarySelection(SelectionNodeV1 primarySelection)
    {
        SelectionNodeV1 secondarySelection = new SelectionNodeV1();

        secondarySelection.setSelectionUuid(UUID.randomUUID());
        secondarySelection.setAssociatedSelectionUuid(primarySelection.getSelectionUuid());
        secondarySelection.setExternalSelectionUuid(UUID.randomUUID());
        secondarySelection.setSelectionDate(primarySelection.getSelectionDate());
        secondarySelection.setDeliveryStatus(DeliveryStatusEnum.DELIVERY_PENDING);
        secondarySelection.setDeliveryStatusChangedDatetime(OffsetDateTime.now());
        secondarySelection.setConfirmationStatus(ConfirmationStatusEnum.CONFIRMED);
        secondarySelection.setConfirmationStatusChangedDatetime(OffsetDateTime.now());
        secondarySelection.setMinimumScoreSatisfied(MinimumScoreSatisfiedEnum.NOT_APPLICABLE);
        secondarySelection.setTrfNumber(primarySelection.getTrfNumber());
        secondarySelection.setSharedDate(primarySelection.getSharedDate());

        return secondarySelection;
    }

}
