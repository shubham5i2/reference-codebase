package com.ielts.cmds.rd.infrastructure.entity;

import lombok.Data;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.UUID;

@Data
@Entity
@ToString(exclude = {"result", "renditionType"})
@Table(name = "results_rendition")
public class ResultsRendition implements Serializable {

    private static final long serialVersionUID = -9166574440100059322L;

    @Id
    @Column(name = "results_rendition_uuid")
    private UUID resultsRenditionUuid;

    @Column(name = "result_uuid")
    private UUID resultUuid;

    @Column(name = "rendition_type_uuid")
    private UUID renditionTypeUuid;

    @Column(name = "rendition_file_path")
    private String renditionFilePath;

    @Column(name = "rendition_file_version")
    private String renditionFileVersion;

    @Column(name = "rendition_description")
    private String renditionDescription;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;

    @Column(name = "report_generation_requested_uuid")
    private UUID reportGenerationRequestedUuid;

    @ManyToOne
    @JoinColumn(name = "result_uuid", insertable = false, nullable = false, updatable = false, referencedColumnName = "result_uuid")
    private Result result;

    @ManyToOne
    @JoinColumn(name = "rendition_type_uuid", insertable = false, nullable = false, updatable = false, referencedColumnName = "rendition_type_uuid")
    private RenditionType renditionType;
}
