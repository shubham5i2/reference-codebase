package com.ielts.cmds.rd.infrastructure.entity;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.time.LocalDate;
import java.time.OffsetDateTime;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString(exclude = "product")
@Table(name = "module_type")
public class ModuleType implements Serializable {

    private static final long serialVersionUID = 4231283217996617420L;

    @Id
    @Column(name = "module_type_uuid")
    private UUID moduleTypeUuid;

    @Column(name = "module_type")
    private String moduleTypeCode;

    @Column(name = "legacy_module_type")
    private String legacyModuleType;

    @Column(name = "description")
    private String description;

    @OneToMany(mappedBy = "moduleType", cascade = CascadeType.ALL)
    private List<Product> product = new ArrayList<>();

    @Column(name = "effective_from_date")
    private LocalDate effectiveFromDate;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;

    @Version
    @Column(name = "concurrency_version")
    private Integer concurrencyVersion;

    @Column(name = "created_datetime")
    private OffsetDateTime createdDatetime;

    @Column(name = "updated_by")
    private String updatedBy;

    @Column(name = "effective_to_date")
    private LocalDate effectiveToDate;


}
