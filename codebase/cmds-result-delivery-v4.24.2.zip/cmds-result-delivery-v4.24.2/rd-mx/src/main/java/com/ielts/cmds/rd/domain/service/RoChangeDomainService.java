package com.ielts.cmds.rd.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.application.command.BaseCommand;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.common.out.event.*;
import com.ielts.cmds.rd.application.exception.ResultDeliveryValidationException;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.domain.command.RoChangeSelectionCommand;
import com.ielts.cmds.rd.domain.model.enums.LinkTypeEnum;
import com.ielts.cmds.rd.domain.model.out.ResultDeliveryRONodeV1;
import com.ielts.cmds.rd.domain.utils.BuildResultDeliveryRONodeV1Utils;
import com.ielts.cmds.rd.infrastructure.entity.LinkedRecognisingOrganisation;
import com.ielts.cmds.rd.infrastructure.entity.RecognisedProduct;
import com.ielts.cmds.rd.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.rd.infrastructure.entity.RecognisingOrganisationAddress;
import com.ielts.cmds.rd.infrastructure.repositories.RecognisingOrganisationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static java.time.ZoneOffset.UTC;

@Slf4j
@Service
@RequiredArgsConstructor
public class RoChangeDomainService {

    private final ObjectMapper objectMapper;

    private final ApplicationEventPublisher applicationEventPublisher;

    private final RecognisingOrganisationRepository recognisingOrganisationRepository;

    private final BuildResultDeliveryRONodeV1Utils buildResultDeliveryRONodeV1Utils;

    @Transactional
    public void on(@NotNull final RoChangeSelectionCommand command) throws JsonProcessingException {

        log.info("Received RO selection change event with RO uuid  {}", command.getEventBody().getRecognisingOrganisationUuid());

        Optional<ResultDeliveryRONodeV1> roNodeV1 = Optional.empty();
        String eventBody;
        BaseEvent<BaseHeader> event;
        final BaseHeader eventHeader = new BaseHeader();
        try {
            Optional<RecognisingOrganisation> optionalRecognisingOrganisation = recognisingOrganisationRepository
                    .findById(command.getEventBody().getRecognisingOrganisationUuid());
            roValidation(command, optionalRecognisingOrganisation);
            RecognisingOrganisation recognisingOrganisation = updateRoDetails(command, optionalRecognisingOrganisation);
            roNodeV1 = Optional.of(buildResultDeliveryRONodeV1Utils.buildResultDeliveryRONodeV1(recognisingOrganisation.getRecognisingOrganisationUuid()));
            eventBody = objectMapper.writeValueAsString(roNodeV1);
            buildHeader(command, eventHeader, roNodeV1);
        } catch (final ResultDeliveryValidationException e) {
            log.error("RoChangeSelectionCommand execution failed", e);
            eventBody = null;
            buildHeader(command, eventHeader, roNodeV1);
        }
        event = new BaseEvent<>(eventHeader, eventBody, null, command.getAudit());

        applicationEventPublisher.publishEvent(event);
    }

    private void roValidation(final RoChangeSelectionCommand command, final Optional<RecognisingOrganisation> optionalRecognisingOrganisation) throws ResultDeliveryValidationException {
        if (optionalRecognisingOrganisation.isPresent()) {
            LocalDateTime localDateTime = optionalRecognisingOrganisation.get().getEventDatetime().toLocalDateTime();
            if (!(command.getEventHeaders().getEventDateTime().isAfter(localDateTime))) {
                throw new ResultDeliveryValidationException(String.format("Received Event Date time is before this : %s  " + "for this RO UUID : %s"
                        , localDateTime, command.getEventBody().getRecognisingOrganisationUuid()), new Throwable());
            }
        }

    }

    private RecognisingOrganisation updateRoDetails(final RoChangeSelectionCommand command, final Optional<RecognisingOrganisation> optionalRecognisingOrganisation) {
        RecognisingOrganisation recognisingOrganisation = optionalRecognisingOrganisation.orElseGet(()
                ->{
            List<RecognisedProduct> products = new ArrayList<>();
            return RecognisingOrganisation.builder()
                .recognisingOrganisationUuid(command.getEventBody().getRecognisingOrganisationUuid())
                .recognisedProducts(products).build();
        });
        recognisingOrganisation.setRecognisingOrganisationUuid(command.getEventBody().getRecognisingOrganisationUuid());
        recognisingOrganisation.setOrganisationTypeUuid(command.getEventBody().getOrganisationTypeUuid());
        recognisingOrganisation.setOrganisationId(command.getEventBody().getOrganisationId().toString());
        recognisingOrganisation.setName(command.getEventBody().getOrganisationName());
        recognisingOrganisation.setVerificationStatus(command.getEventBody().getVerificationStatus());
        recognisingOrganisation.setPartnerCode(command.getEventBody().getPartnerCode());
        recognisingOrganisation.setMethodOfDelivery(command.getEventBody().getMethodOfDelivery());
        recognisingOrganisation.setParentRecognisingOrganisationUuid(null);
        recognisingOrganisation.setOrganisationStatus(command.getEventBody().getOrganisationStatus());
        recognisingOrganisation.setOrganisationCode(command.getEventBody().getOrganisationCode());
        recognisingOrganisation.setReplacedByRecognisingOrganisationUuid(null);
        recognisingOrganisation.setSoftDeleted(false);
        recognisingOrganisation.setEventDatetime(OffsetDateTime.of(command.getEventHeaders().getEventDateTime(), UTC));
        recognisingOrganisation.setUpdatedDatetime(OffsetDateTime.now(UTC));
        if (Objects.nonNull(command.getEventBody().getAddresses())) {
            recognisingOrganisation.setRecognisingOrganisationAddresses(updateAddressDetails(recognisingOrganisation, command));
        }
        if (Objects.nonNull(command.getEventBody().getRecognisedProducts())) {
            recognisingOrganisation.setRecognisedProducts(updateRecognisingProductDetails(recognisingOrganisation, command));
        }
        if (Objects.nonNull(command.getEventBody().getLinkedOrganisations())) {
            recognisingOrganisation.setLinkedRecognisingOrganisations(checkForDeletedLinkedROs(recognisingOrganisation, command.getEventBody().getLinkedOrganisations()));
            recognisingOrganisation.setLinkedRecognisingOrganisations(updateLinkedOrganisations(recognisingOrganisation, command.getEventBody()));
        } else if (Objects.isNull(command.getEventBody().getLinkedOrganisations()) && Objects.nonNull(recognisingOrganisation.getLinkedRecognisingOrganisations())) {
            recognisingOrganisation.getLinkedRecognisingOrganisations().forEach(e -> e.setDeleted(true));
        }

        recognisingOrganisationRepository.save(recognisingOrganisation);
        return recognisingOrganisation;
    }

    private List<LinkedRecognisingOrganisation> checkForDeletedLinkedROs(RecognisingOrganisation recognisingOrganisation, RoChangedEventV1LinkedOrganisations linkedOrganisations) {
        List<LinkedRecognisingOrganisation> linkedROs =Collections.emptyList();
        if(Objects.nonNull(recognisingOrganisation.getLinkedRecognisingOrganisations())){
            linkedROs = recognisingOrganisation.getLinkedRecognisingOrganisations().stream().map(savedLinkedRos -> updateDeletedLinkedRos(savedLinkedRos, linkedOrganisations)).collect(Collectors.toList());
        }
        return linkedROs;
    }


    private List<LinkedRecognisingOrganisation> updateLinkedOrganisations(RecognisingOrganisation recognisingOrganisation, RoChangedEventV1 roChangedEventV1) {
        return roChangedEventV1.getLinkedOrganisations().stream().map(e ->
                setLinkedRecognisingOrganisations(recognisingOrganisation, e)).collect(Collectors.toList());
    }

    private LinkedRecognisingOrganisation setLinkedRecognisingOrganisations(RecognisingOrganisation recognisingOrganisation, RoChangedEventV1LinkedOrganisation e) {
        LinkedRecognisingOrganisation linkedRecognisingOrganisation = new LinkedRecognisingOrganisation();

        linkedRecognisingOrganisation.setLinkedRecognisingOrganisationUuid(e.getLinkedRecognisingOrganisationUuid());
        linkedRecognisingOrganisation.setRecognisingOrganisation(recognisingOrganisation);
        linkedRecognisingOrganisation.setTargetRecognisingOrganisationUuid(e.getTargetRecognisingOrganisationUuid());
        linkedRecognisingOrganisation.setLinkedRecognisingOrganisationType(LinkTypeEnum.valueOf(e.getLinkType().getValue()));
        linkedRecognisingOrganisation.setLinkEffectiveFromDatetime(OffsetDateTime.of(e.getLinkEffectiveFromDateTime(), UTC));
        linkedRecognisingOrganisation.setLinkEffectiveToDatetime(OffsetDateTime.of(e.getLinkEffectiveToDateTime(), UTC));
        linkedRecognisingOrganisation.setUpdatedDatetime(OffsetDateTime.now(UTC));
        linkedRecognisingOrganisation.setDeleted(false);

        return linkedRecognisingOrganisation;
    }

    private LinkedRecognisingOrganisation updateDeletedLinkedRos(LinkedRecognisingOrganisation savedLinkedRos, RoChangedEventV1LinkedOrganisations linkedOrganisations) {
        long count = linkedOrganisations.stream().filter(incomingLinkedRos -> incomingLinkedRos.getLinkedRecognisingOrganisationUuid()
                .equals(savedLinkedRos.getLinkedRecognisingOrganisationUuid())).count();
        if (count == 0) {
            savedLinkedRos.setDeleted(true);
        }
        return savedLinkedRos;
    }

    private List<RecognisingOrganisationAddress> updateAddressDetails(RecognisingOrganisation recognisingOrganisation, BaseCommand<BaseHeader, RoChangedEventV1> command) {
        return command.getEventBody().getAddresses().stream()
                .map(e -> getAddresses(recognisingOrganisation, e))
                .collect(Collectors.toList());
    }

    private RecognisingOrganisationAddress getAddresses(RecognisingOrganisation recognisingOrganisation, RoChangedEventV1Address roChangedEventV1Address) {
        Optional<RecognisingOrganisationAddress> optionalRecognisingOrganisationAddress = Optional.empty();
        if(Objects.nonNull(recognisingOrganisation.getRecognisingOrganisationAddresses())) {
            optionalRecognisingOrganisationAddress = recognisingOrganisation.getRecognisingOrganisationAddresses().stream()
                    .filter(e -> e.getAddressUuid().equals(roChangedEventV1Address.getAddressUuid())).findFirst();
        }
        RecognisingOrganisationAddress address = optionalRecognisingOrganisationAddress.orElseGet(RecognisingOrganisationAddress::new);

        address.setAddressUuid(roChangedEventV1Address.getAddressUuid());
        address.setAddressTypeUuid(roChangedEventV1Address.getAddressTypeUuid());
        address.setAddressLine1(roChangedEventV1Address.getAddressLine1());
        address.setAddressLine2(roChangedEventV1Address.getAddressLine2());
        address.setAddressLine3(roChangedEventV1Address.getAddressLine3());
        address.setAddressLine4(roChangedEventV1Address.getAddressLine4());
        address.setCity(roChangedEventV1Address.getCity());
        address.setPostalCode(roChangedEventV1Address.getPostalCode());
        address.setRecognisingOrganisation(recognisingOrganisation);
        address.setUpdatedDateTime(OffsetDateTime.now());
        return address;
    }

    private List<RecognisedProduct> updateRecognisingProductDetails(RecognisingOrganisation recognisingOrganisation, BaseCommand<BaseHeader, RoChangedEventV1> command) {
        List<RecognisedProduct> products = recognisingOrganisation.getRecognisedProducts();
        products.clear();
        for(RoChangedEventV1RecognisedProduct product : command.getEventBody().getRecognisedProducts())
        {
            products.add(getRecognisingProduct(recognisingOrganisation, product));
        }
        return products;
    }

    private RecognisedProduct getRecognisingProduct(RecognisingOrganisation recognisingOrganisation, RoChangedEventV1RecognisedProduct product) {

        RecognisedProduct recognisedProduct = new RecognisedProduct();
        recognisedProduct.setRecognisedProductUuid(product.getRecognisedProductUuid());
        recognisedProduct.setRecognisingOrganisation(recognisingOrganisation);
        recognisedProduct.setProductUuid(product.getProductUuid());
        recognisedProduct.setEffectiveFromDatetime(OffsetDateTime.of(product.getEffectiveFromDateTime(), UTC));
        recognisedProduct.setEffectiveToDatetime(OffsetDateTime.of(product.getEffectiveToDateTime(), UTC));
        recognisedProduct.setUpdatedDatetime(OffsetDateTime.now(UTC));
        return recognisedProduct;
    }

    public void buildHeader(final RoChangeSelectionCommand command, BaseHeader eventHeader, Optional<ResultDeliveryRONodeV1> recognisingOrganisationNodeV1) {
        eventHeader.setCorrelationId(command.getEventHeaders().getCorrelationId());
        eventHeader.setEventDateTime(LocalDateTime.now());
        eventHeader.setTransactionId(command.getEventHeaders().getTransactionId());
        eventHeader.setPartnerCode(command.getEventHeaders().getPartnerCode());
        Map<String, String> eventContext = Optional
                .ofNullable(command.getEventHeaders().getEventContext())
                .orElseGet(HashMap::new);
        eventContext.put("recognisingOrganisationUuid", command.getEventBody().getRecognisingOrganisationUuid().toString());
        eventHeader.setEventContext(eventContext);

        if (recognisingOrganisationNodeV1.isPresent()) {
            eventHeader.setEventName(RDConstants.EventType.SELECTION_RO_CHANGED);
        } else {
            eventHeader.setEventName(RDConstants.EventType.SELECTION_RO_CHANGE_FAILED);
        }

    }

}