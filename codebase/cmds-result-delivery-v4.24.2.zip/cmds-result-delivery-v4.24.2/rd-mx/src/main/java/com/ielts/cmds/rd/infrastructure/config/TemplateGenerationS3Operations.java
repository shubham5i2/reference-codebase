package com.ielts.cmds.rd.infrastructure.config;

import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.util.IOUtils;
import com.ielts.cmds.common.utils.s3.CMDSS3Client;
import com.ielts.cmds.rd.application.exception.ResultDeliveryValidationException;
import com.ielts.cmds.rd.domain.model.enums.PhotoCategoryEnum;
import com.ielts.cmds.rd.infrastructure.entity.Booking;
import com.ielts.cmds.rd.infrastructure.entity.TestTakerPhoto;
import com.ielts.cmds.rd.infrastructure.repositories.TestTakerPhotoRepository;
import com.ielts.cmds.rd.infrastructure.repositories.TestTakerPhotoTypeRepository;
import lombok.Generated;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

@Component
@Slf4j
@RequiredArgsConstructor
@Generated
public class TemplateGenerationS3Operations {

    private final TestTakerPhotoRepository testTakerPhotoRepository;

    private final TestTakerPhotoTypeRepository testTakerPhotoTypeRepository;

    @Value("${trf.result.bucket.name}")
    private String trfResultBucketName;

    @Value("${tt.photo.bucket.name}")
    private String ttPhotoBucketName;

    private final CMDSS3Client cmdss3Client;

    //method to get testTaker's low resolution test day image from S3 bucket
    public Optional<String> getTtImageFromS3Bucket(Booking booking) throws IOException, ResultDeliveryValidationException {
        String key;
        List<TestTakerPhoto> testTakerPhotos = testTakerPhotoRepository.findByBookingUuid(booking.getBookingUuid());
        Optional<TestTakerPhoto> optionalTestTakerPhoto = testTakerPhotos.stream().filter(ttp -> ttp.getPhotoCategory().equals(PhotoCategoryEnum.Certificate)).findFirst();
        TestTakerPhoto testTakerPhoto = optionalTestTakerPhoto.orElseThrow(() -> new ResultDeliveryValidationException
                ("Test Taker photo is not available for booking uuid: " + booking.getBookingUuid(), new Throwable()));
        key = testTakerPhoto.getFilePath();
        if (cmdss3Client.doesObjectExist(ttPhotoBucketName, key)) {
            S3Object s3Object = cmdss3Client.getObject(ttPhotoBucketName, key);
            S3ObjectInputStream inputStream = s3Object.getObjectContent();
            byte[] encoded = Base64.encodeBase64(IOUtils.toByteArray(inputStream));
            return Optional.of(new String(encoded, StandardCharsets.UTF_8));
        } else {
            log.error("Test Taker photo is not available for booking uuid : {} ", booking.getBookingUuid());
            return Optional.empty();
        }
    }

    @SneakyThrows
    //method to upload generated Template into S3 bucket
    public PutObjectResult uploadTemplateFileToS3Bucket(File outputFile) {

        PutObjectResult putObjectResult = cmdss3Client.uploadObject(trfResultBucketName, outputFile.getName(), outputFile);
        Path path = Paths.get(outputFile.getPath());
        if (Files.deleteIfExists(path)) {
            log.debug("Temporary Template file deleted successfully");
        } else {
            log.debug("Unable to delete temporary Template file");
        }
        return putObjectResult;
    }
}
