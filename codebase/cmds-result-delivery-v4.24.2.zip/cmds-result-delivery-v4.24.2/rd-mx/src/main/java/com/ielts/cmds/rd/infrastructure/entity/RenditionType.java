package com.ielts.cmds.rd.infrastructure.entity;

import com.ielts.cmds.rd.domain.model.enums.RenditionTypeCodeEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.*;
import java.io.Serializable;
import java.time.OffsetDateTime;

import java.util.UUID;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "rendition_type")
public class RenditionType implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "rendition_type_uuid")
    private UUID renditionTypeUuid;

    @Enumerated(EnumType.STRING)
    @Column(name = "rendition_type_code")
    private RenditionTypeCodeEnum renditionTypeCodeEnum;

    @Column(name = "effective_from_date")
    private OffsetDateTime effectiveFromDate;

    @Column(name = "effective_to_date")
    private OffsetDateTime effectiveToDate;
}
