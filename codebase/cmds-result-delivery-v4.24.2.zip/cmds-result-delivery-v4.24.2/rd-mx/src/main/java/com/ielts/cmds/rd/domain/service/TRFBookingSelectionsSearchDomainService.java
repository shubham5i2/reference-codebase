package com.ielts.cmds.rd.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.outbox.event.OutboxEventBuilder;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rd.application.exception.ResultDeliveryValidationException;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.domain.command.TRFBookingSelectionsSearchCommand;
import com.ielts.cmds.rd.domain.model.out.RecognisingOrganisationNodeV1;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import com.ielts.cmds.rd.domain.model.out.SearchSortV1Item;
import com.ielts.cmds.rd.domain.model.out.TRFBookingSearchResultsV1;
import com.ielts.cmds.rd.domain.utils.*;
import com.ielts.cmds.rd.infrastructure.entity.*;
import com.ielts.cmds.rd.infrastructure.repositories.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.constraints.NotNull;
import java.util.*;
import java.util.stream.Collectors;

import static com.ielts.cmds.rd.domain.RDConstants.EventType.*;
import static com.ielts.cmds.rd.domain.RDConstants.SortFieldNameConstants.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class TRFBookingSelectionsSearchDomainService {

    private final ObjectMapper objectMapper;

    private final AddressTypeRepository addressTypeRepository;

    private final OrganisationTypeRepository organisationTypeRepository;

    private final BuildResultReleaseNodeV1Utils buildResultReleaseNodeV1Utils;

    private final ResultRepository resultRepository;

    private final SelectionRepository selectionRepository;

    private final RecognisingOrganisationRepository recognisingOrganisationRepository;

    private final UnverifiedAddressRepository unverifiedAddressRepository;

    private final BookingRepository bookingRepository;

    private final DomainEventsPublisher domainEventsPublisher;

    private final TRFBookingSelectionsSearchUtils selectionsSearchUtils;

    private final BuildSelectionNodeV1Utils selectionNodeV1Utils;

    private final BuildRecognisingOrganisationNodeV1Utils organisationNodeV1Utils;

    private final OutboxEventBuilder outboxEventBuilder = new OutboxEventBuilder();

    @Autowired
    private final RbacAuthorization rbacAuthorization;


    @Transactional(readOnly = true)
    public void on(@NotNull final TRFBookingSelectionsSearchCommand command) throws JsonProcessingException, ResultDeliveryValidationException, RbacValidationException {

        log.debug("Received trf/v1/booking/{bookingUuid}/selections/search event with Booking Uuid {}", command.getEventBody().getCriteria().getBookingUuid());

        List<BaseEvent<UiHeader>> publishingEventList = new ArrayList<>();
        BaseEvent<UiHeader> publishingEvent;

        UUID bookingUuid = command.getEventBody().getCriteria().getBookingUuid();

        Optional<Booking> optionalBooking = bookingRepository.findById(bookingUuid);
        Booking booking = optionalBooking.orElseThrow(() -> new ResultDeliveryValidationException
                ("TRF Booking Selections Search Event Failed as booking is not Present", new Throwable()));

        //for future scope
        List<String> availableSortFields =
                Arrays.asList(ORGANISATION_ID, ORGANISATION_NAME, ORGANISATION_ADDRESS, SELECTION_DATE,
                        PERSON_DEPARTMENT, ORGANISATION_TYPE, CONFIRMATION_STATUS, CONFIRMATION_STATUS_CHANGED_DATE_TIME, CASE_NUMBER);

        //List of invalid SearchSortItems
        List<SearchSortV1Item> unavailableSortItems = selectionsSearchUtils
                .allSortItemFieldsAvailabilityCheck(command.getEventBody().getSorting(), availableSortFields);

        //List of invalid field names from SearchSortItems list
        List<String> unavailableSortFieldNames = unavailableSortItems.stream()
                .map(SearchSortV1Item::getSortBy).collect(Collectors.toList());
        boolean allSortItemsAvailable = unavailableSortItems.isEmpty();
        boolean isRbacValidationPassed = rbacAuthorization.isUserAuthorized(booking, command.getEventHeaders(), RDConstants.GenericConstants.VIEW_ETRF);
        Optional<Result> optionalResult = resultRepository.findByBookingUuid(bookingUuid);

        // if result for given bookingUUid is present and all sort fields are available and user is authorized

        if (isRbacValidationPassed && optionalResult.isPresent() && allSortItemsAvailable) {
            Result result = optionalResult.get();
            String eventBody = generateEventBody(command, result.getResultUuid(), result);
            publishingEvent = generatePublishingEvent(command, TRF_BOOKING_SELECTIONS_SEARCH_RESULT_GENERATED, eventBody, null);

            log.info("Booking selections search success for bookingUuid {}", command.getEventBody().getCriteria().getBookingUuid());
        }

        //if result for given bookingUuid is not found or invalid sort fields found or rbac validation is failed
        else {
            String errorMessage = getErrorMessage(unavailableSortFieldNames, availableSortFields, allSortItemsAvailable, isRbacValidationPassed);
            String errorCode = "";
            if (!isRbacValidationPassed) {
                errorCode = "V041";
            }
            BaseEventErrors errors = selectionsSearchUtils.getBaseEventErrors(errorMessage, errorCode);
            publishingEvent = generatePublishingEvent(command, TRF_BOOKING_SELECTIONS_SEARCH_RESULT_GENERATE_FAILED, null, errors);
            log.info("Booking Selections search failed for bookingUuid {} as {}", command.getEventBody().getCriteria().getBookingUuid(), errorMessage);
        }
        BaseEvent<UiHeader> persistenceIgnoredEvent = (BaseEvent<UiHeader>) outboxEventBuilder.buildAsPersistenceIgnored(publishingEvent);
        publishingEventList.add(persistenceIgnoredEvent);

        domainEventsPublisher.uiEventListPublisher(publishingEventList);
    }

    private String getErrorMessage(List<String> unavailableSortFieldNames, List<String> availableSortFields, boolean allSortItemsAvailable, boolean isRbacValidationPassed) {
        String errorMsg = "";
        if (!isRbacValidationPassed) {
            errorMsg = "You do not have permission to view this page";
        } else if (!allSortItemsAvailable) {
            log.info("Unknown sort fields found: " + unavailableSortFieldNames + ". Available fields for sorting: " + availableSortFields);
        } else {
            log.info("Result for the bookingUuid not present");
        }
        return errorMsg;
    }

    /**
     * generate publishing event
     *
     * @param command   TRFBookingSelectionsSearchCommand
     * @param eventName publishing Event Name
     * @param eventBody publishing Event Body
     * @param errors    Event Errors
     * @return publishing event
     */
    private BaseEvent<UiHeader> generatePublishingEvent(TRFBookingSelectionsSearchCommand command, String eventName, String eventBody, BaseEventErrors errors) {
        BaseEvent<UiHeader> baseEvent = new BaseEvent<>();
        baseEvent.setEventHeader(selectionsSearchUtils.buildHeader(command, eventName));
        baseEvent.setEventBody(eventBody);
        baseEvent.setEventErrors(errors);

        return baseEvent;
    }


    /**
     * @param command    TRFBookingSelectionsSearchCommand
     * @param resultUuid resultUuid from result entity
     * @return event body
     */
    private String generateEventBody(TRFBookingSelectionsSearchCommand command, UUID resultUuid, Result result) throws JsonProcessingException, ResultDeliveryValidationException {

        List<ResultReleasedNodeV1> resultReleasedNodeV1List;

        TRFBookingSearchResultsV1 trfBookingSearchResultsV1 = new TRFBookingSearchResultsV1();

        UUID bookingUuid = command.getEventBody().getCriteria().getBookingUuid();

        //get booking entity for external_booking_uuid to fetch selections
        Optional<Booking> optionalBooking = bookingRepository.findById(bookingUuid);
        Booking booking = optionalBooking.orElseThrow(() -> new ResultDeliveryValidationException
                ("TRF Booking Selections Search Event Failed as booking is not Present", new Throwable()));

        List<Selection> selections = selectionRepository.findByExternalBookingUuid(booking.getExternalBookingUuid());

        ResultReleasedNodeV1 resultReleasedNodeV1 = buildResultReleaseNodeV1Utils.buildResultReleasedNodeV1(resultUuid);

        resultReleasedNodeV1.setReferenceData(buildResultReleaseNodeV1Utils.getReferenceData(result));

        //If selections not available for the booking
        if (selections.isEmpty()) {
            log.info("Booking with bookingUuid {} has no selections.", bookingUuid);
            trfBookingSearchResultsV1 = getEventBodyWhenSelectionsNotAvailable(resultReleasedNodeV1);
        }
        //when booking has selections available
        else {
            resultReleasedNodeV1List = getEventBodyWhenSelectionsAvailable(resultReleasedNodeV1, selections);

            trfBookingSearchResultsV1.setTotalCount(selections.size());

            trfBookingSearchResultsV1.setEntries(resultReleasedNodeV1List);

        }
        return objectMapper.writeValueAsString(trfBookingSearchResultsV1);
    }

    /**
     * when booking UUID has no selections available
     *
     * @param resultReleasedNodeV1 with booking details
     */
    public TRFBookingSearchResultsV1 getEventBodyWhenSelectionsNotAvailable(ResultReleasedNodeV1 resultReleasedNodeV1) {
        List<ResultReleasedNodeV1> resultReleasedNodeV1List = new ArrayList<>();
        TRFBookingSearchResultsV1 trfBookingSearchResultsV1 = new TRFBookingSearchResultsV1();
        resultReleasedNodeV1List.add(resultReleasedNodeV1);
        trfBookingSearchResultsV1.setTotalCount(0);
        trfBookingSearchResultsV1.setEntries(resultReleasedNodeV1List);

        return trfBookingSearchResultsV1;
    }

    /**
     * when booking UUID has selections available
     *
     * @param resultReleasedNodeV1 with booking details
     * @param selections           list of selections
     */
    public List<ResultReleasedNodeV1> getEventBodyWhenSelectionsAvailable(ResultReleasedNodeV1 resultReleasedNodeV1, List<Selection> selections) throws ResultDeliveryValidationException {

        List<ResultReleasedNodeV1> resultReleasedNodeV1List = new ArrayList<>();

        for (Selection selection : selections) {

            ResultReleasedNodeV1 resultReleasedNodeV11 = selectionsSearchUtils.getResultReleasedNodeV1Copy(resultReleasedNodeV1);
            resultReleasedNodeV11.setSelection(selectionNodeV1Utils.buildSelectionNodeV1(selection.getSelectionUuid()));

            //If the selection is related to Unverified Address
            if (selection.getRecognisingOrganisationUuid() == null) {
                Optional<UnverifiedAddress> unverifiedAddressOptional = unverifiedAddressRepository.findById(selection.getUnverifiedAddressUuid());
                UnverifiedAddress unverifiedAddress = unverifiedAddressOptional.orElseThrow(() -> new ResultDeliveryValidationException
                        ("TRF Booking Selections Search Event Failed as UA is not Present", new Throwable()));

                resultReleasedNodeV11.setOrganisation(setUnverifiedAddressInRONode(unverifiedAddress));
                resultReleasedNodeV11.setDeliveryAddress(getDeliveryAddressForUA(unverifiedAddress));
                resultReleasedNodeV11.setOrganisationType("Unverified Address");
            }
            //if the selection is related to Recognising Organisation
            else {
                Optional<RecognisingOrganisation> organisationOptional = recognisingOrganisationRepository.findById(selection.getRecognisingOrganisationUuid());
                RecognisingOrganisation organisation = organisationOptional.orElseThrow(() -> new ResultDeliveryValidationException
                        ("TRF Booking Selections Search Event Failed as RO is not Present", new Throwable()));

                resultReleasedNodeV11.setOrganisation(organisationNodeV1Utils.buildRecognisingOrganisationNodeV1(organisation.getRecognisingOrganisationUuid()));
                resultReleasedNodeV11.getOrganisation().setAddresses(selectionsSearchUtils.setAddressesNodeV1FromEntity(organisation.getRecognisingOrganisationAddresses()));

                resultReleasedNodeV11.setDeliveryAddress(getDeliveryAddress(organisation));

                // set OrganisationType for sorting
                Optional<OrganisationType> optionalOrganisationType = organisationTypeRepository.findById(organisation.getOrganisationTypeUuid());
                OrganisationType organisationType = optionalOrganisationType.orElseThrow(() -> new ResultDeliveryValidationException
                        ("TRF Booking Selections Search Event Failed as Organisation Type is not Present", new Throwable()));

                resultReleasedNodeV11.setOrganisationType(organisationType.getDescription());
            }

            resultReleasedNodeV1List.add(resultReleasedNodeV11);

        }
        return resultReleasedNodeV1List;
    }

    private RecognisingOrganisationNodeV1 setUnverifiedAddressInRONode(UnverifiedAddress unverifiedAddress) {
        RecognisingOrganisationNodeV1 recognisingOrganisationNodeV1 = new RecognisingOrganisationNodeV1();

        recognisingOrganisationNodeV1.setOrganisationId("Not Available");
        recognisingOrganisationNodeV1.setName(unverifiedAddress.getOrganisationName());

        return recognisingOrganisationNodeV1;
    }

    /**
     * @param organisation RecognisingOrganisation entity
     * @return deliveryAddress
     */
    public String getDeliveryAddress(RecognisingOrganisation organisation) throws ResultDeliveryValidationException {
        //get addressType from db and fetch deliveryAddressType
        Optional<AddressType> optionalAddressType = addressTypeRepository.findAll().stream()
                .filter(addressType -> addressType.getAddressTypeName().equalsIgnoreCase(DELIVERY))
                .findFirst();
        AddressType addressType = optionalAddressType.orElseThrow(() -> new ResultDeliveryValidationException
                ("TRF Booking Selections Search Event Failed as DELIVERY addressType is not Present", new Throwable()));

        //get delivery organisation address using filter from addressTypeUuid
        Optional<RecognisingOrganisationAddress> organisationAddresses = organisation.getRecognisingOrganisationAddresses().stream()
                .filter(orgAddress ->
                        orgAddress.getAddressTypeUuid().equals(addressType.getAddressTypeUuid())
                ).findFirst();
        if (!organisationAddresses.isPresent()) {
            log.info("Delivery Address is not available for organisation with organisationId {} ", organisation.getOrganisationId());
        }
        RecognisingOrganisationAddress organisationAddress = organisationAddresses.orElseThrow(() -> new ResultDeliveryValidationException
                ("TRF Booking Selections Search Event Failed as OrganisationAddress is not Present", new Throwable()));

        organisationAddress.setAddressLine1(validateAndSetAddress(organisationAddress.getAddressLine1()));
        organisationAddress.setAddressLine2(validateAndSetAddress(organisationAddress.getAddressLine2()));
        organisationAddress.setAddressLine3(validateAndSetAddress(organisationAddress.getAddressLine3()));
        organisationAddress.setAddressLine4(validateAndSetAddress(organisationAddress.getAddressLine4()));
        organisationAddress.setCity(validateAndSetAddress(organisationAddress.getCity()));
        organisationAddress.setPostalCode(validateAndSetAddress(organisationAddress.getPostalCode()));

        // set delivery address for sorting
        return (organisationAddress.getAddressLine1() + organisationAddress.getAddressLine2() +
                organisationAddress.getAddressLine3() + organisationAddress.getAddressLine4() +
                organisationAddress.getCity() + organisationAddress.getPostalCode()).trim().replace(" ", ", ");

    }

    private String getDeliveryAddressForUA(UnverifiedAddress unverifiedAddress) {
        unverifiedAddress.setAddressLine1(validateAndSetAddress(unverifiedAddress.getAddressLine1()));
        unverifiedAddress.setAddressLine2(validateAndSetAddress(unverifiedAddress.getAddressLine2()));
        unverifiedAddress.setAddressLine3(validateAndSetAddress(unverifiedAddress.getAddressLine3()));
        unverifiedAddress.setAddressLine4(validateAndSetAddress(unverifiedAddress.getAddressLine4()));
        unverifiedAddress.setCity(validateAndSetAddress(unverifiedAddress.getCity()));
        unverifiedAddress.setPostalCode(validateAndSetAddress(unverifiedAddress.getPostalCode()));
        unverifiedAddress.setTerritoryIsoCode(validateAndSetAddress(unverifiedAddress.getTerritoryIsoCode()));

        return (unverifiedAddress.getAddressLine1() + unverifiedAddress.getAddressLine2() +
                unverifiedAddress.getAddressLine3() + unverifiedAddress.getAddressLine4() +
                unverifiedAddress.getCity() + unverifiedAddress.getPostalCode() +
                unverifiedAddress.getTerritoryIsoCode() + unverifiedAddress.getCountryIsoCode()).trim().replace(" ", ", ");
    }

    private String validateAndSetAddress(String address) {
        if (Objects.isNull(address)) {
            return "";
        }
        return address + " ";
    }


}
