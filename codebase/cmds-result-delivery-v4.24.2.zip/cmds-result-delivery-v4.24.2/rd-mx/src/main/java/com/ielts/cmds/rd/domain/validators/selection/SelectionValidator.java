package com.ielts.cmds.rd.domain.validators.selection;

import com.ielts.cmds.rd.domain.model.SelectionDataBody;
import com.ielts.cmds.rd.domain.validators.selection.validation.SelectionCreateGroupValidation;
import com.ielts.cmds.rd.domain.validators.selection.validation.SelectionUpdateGroupValidation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import java.util.HashSet;
import java.util.Set;

/**
 *
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class SelectionValidator {

    private final Validator validator;

    public Set<ConstraintViolation<SelectionDataBody>> validate(final SelectionDataBody selectionDataBody) {
        Set<ConstraintViolation<SelectionDataBody>> constraintViolations = new HashSet<>();

        if (selectionDataBody.getSelectionEntity().isPresent())
            constraintViolations.addAll(validateSelectionDataForUpdate(selectionDataBody));
        else
            constraintViolations.addAll(validateSelectionDataForCreate(selectionDataBody));


        return constraintViolations;
    }

    Set<ConstraintViolation<SelectionDataBody>> validateSelectionDataForCreate(final SelectionDataBody selectionDataBody) {
        return validator.validate(selectionDataBody, SelectionCreateGroupValidation.class);
    }

    Set<ConstraintViolation<SelectionDataBody>> validateSelectionDataForUpdate(final SelectionDataBody selectionDataBody) {
        return validator.validate(selectionDataBody, SelectionUpdateGroupValidation.class);
    }

}
