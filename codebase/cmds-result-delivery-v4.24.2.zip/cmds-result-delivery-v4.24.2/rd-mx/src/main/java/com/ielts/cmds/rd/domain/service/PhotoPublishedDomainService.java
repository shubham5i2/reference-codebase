package com.ielts.cmds.rd.domain.service;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.application.command.BaseCommand;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.application.exception.ResultDeliveryValidationException;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.domain.command.PhotoPublishedSelectionCommand;
import com.ielts.cmds.rd.domain.enums.ResultDataAnalysisOutcomeFlag;
import com.ielts.cmds.rd.domain.model.enums.PhotoCategoryEnum;
import com.ielts.cmds.rd.domain.model.out.TTPhotoNodeV1;
import com.ielts.cmds.rd.domain.utils.BuildResultReleaseNodeV1Utils;
import com.ielts.cmds.rd.infrastructure.entity.TestTakerPhoto;
import com.ielts.cmds.rd.infrastructure.repositories.ResultRepository;
import com.ielts.cmds.rd.infrastructure.repositories.TestTakerPhotoRepository;
import com.ielts.cmds.rd.infrastructure.repositories.TestTakerPhotoTypeRepository;
import com.ielts.cmds.testtaker.common.events.model.PhotoPublishedV1;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static java.time.ZoneOffset.UTC;

@Service
@Slf4j
@RequiredArgsConstructor
public class PhotoPublishedDomainService extends AbstractDomainService {

    private final ObjectMapper objectMapper;

    private final ApplicationEventPublisher applicationEventPublisher;

    private final TestTakerPhotoRepository testTakerPhotoRepository;

    private final TestTakerPhotoTypeRepository testTakerPhotoTypeRepository;

    private final ResultRepository resultRepository;

    private final BuildResultReleaseNodeV1Utils resultReleaseNodeV1Utils;

    @Transactional
    public void on(@NotNull final PhotoPublishedSelectionCommand command) throws JsonProcessingException {

        log.info("Received photo published event with photo uuid as {}", command.getEventBody().getPhotoUuid());

        Optional<TTPhotoNodeV1> ttPhotoNodeV1 = Optional.empty();
        String eventBody;
        Map<String, String> ttDataUpdateMap = Optional
                .ofNullable(command.getEventHeaders().getEventContext())
                .orElseGet(HashMap::new);

        BaseEvent<BaseHeader> event;
        final BaseHeader eventHeader = new BaseHeader();
        BaseEventErrors baseEventErrors = null;
        try {
            Optional<TestTakerPhoto> optionalTestTakerPhoto = testTakerPhotoRepository.findById(command.getEventBody().getPhotoUuid());
            checkIfLatestEvent(command, optionalTestTakerPhoto);
            ttDataUpdateMap = updateTestTakerPhotoFlagInfo(optionalTestTakerPhoto, command);
            TestTakerPhoto testTakerPhoto = updateTTPhotoDetails(command, optionalTestTakerPhoto);
            ttPhotoNodeV1 = Optional.of(buildTTPhotoNodeV1(testTakerPhoto));
            eventBody = objectMapper.writeValueAsString(ttPhotoNodeV1);
            buildHeader(command, eventHeader, ttPhotoNodeV1, ttDataUpdateMap);
        } catch (final ResultDeliveryValidationException e) {
            log.error("PhotoPublishedSelectionCommand execution failed", e);
            eventBody = getEventBodyForReportGenerationEvents(command.getEventBody().getBookingUuid());
            baseEventErrors = resultReleaseNodeV1Utils.getBaseEventErrors(e);

            buildHeader(command, eventHeader, ttPhotoNodeV1, ttDataUpdateMap);
        }
        event = new BaseEvent<>(eventHeader, eventBody, baseEventErrors, command.getAudit());
        applicationEventPublisher.publishEvent(event);
    }

    protected void checkIfLatestEvent(final PhotoPublishedSelectionCommand command, final Optional<TestTakerPhoto> optionalTestTakerPhoto) throws ResultDeliveryValidationException {
        if (optionalTestTakerPhoto.isPresent()) {
            LocalDateTime localDateTime = optionalTestTakerPhoto.get().getEventDateTime().toLocalDateTime();
            if (!(command.getEventHeaders().getEventDateTime().isAfter(localDateTime))) {
                throw new ResultDeliveryValidationException(String.format("Received Event Date time is before this : %s  " + "for this Result UUID : %s"
                        , localDateTime, command.getEventBody().getPhotoUuid()), new Throwable());
            }
        }
    }

    private TestTakerPhoto updateTTPhotoDetails(final PhotoPublishedSelectionCommand command, final Optional<TestTakerPhoto> optionalTestTakerPhoto) {
        TestTakerPhoto ttPhoto = optionalTestTakerPhoto.orElseGet(() -> TestTakerPhoto.builder().photoUuid(command.getEventBody().getPhotoUuid()).build());
        ttPhoto.setBookingUuid(command.getEventBody().getBookingUuid());
        ttPhoto.setPhotoTypeUuid(command.getEventBody().getPhotoTypeUuid());
        ttPhoto.setPhotoVersion(command.getEventBody().getPhotoVersion().toString());
        ttPhoto.setFilePath(command.getEventBody().getPhotoPath());
        ttPhoto.setPhotoCategory(com.ielts.cmds.rd.domain.model.enums.PhotoCategoryEnum.valueOf(command.getEventBody().getPhotoCategory().toString()));
        ttPhoto.setEventDateTime(OffsetDateTime.of(command.getEventHeaders().getEventDateTime(), UTC));
        ttPhoto.setUpdatedDateTime(OffsetDateTime.now(UTC));
        testTakerPhotoRepository.save(ttPhoto);
        return ttPhoto;
    }

    private Map<String, String> updateTestTakerPhotoFlagInfo(Optional<TestTakerPhoto> optionalTestTakerPhoto, BaseCommand<BaseHeader, PhotoPublishedV1> command) {
        Map<String, String> map = new HashMap<>();
        if (!optionalTestTakerPhoto.isPresent()) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
            map.put(ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getValue());
        }
        if (optionalTestTakerPhoto.isPresent()) {
            calculateDeltaFlag(command, optionalTestTakerPhoto.get(), map);
        }

        return map;
    }

    private void calculateDeltaFlag(BaseCommand<BaseHeader, PhotoPublishedV1> command, TestTakerPhoto testTakerPhoto, Map<String, String> map) {

        boolean photoVersion = !Objects.equals(testTakerPhoto.getPhotoVersion(), command.getEventBody().getPhotoVersion());
        boolean photoPath = !Objects.equals(testTakerPhoto.getFilePath(), command.getEventBody().getPhotoPath());
        if (testTakerPhoto.getPhotoCategory().equals(PhotoCategoryEnum.Certificate) && (photoVersion || photoPath)) {
            map.put(ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getValue());
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        }
    }

    public void buildHeader(final PhotoPublishedSelectionCommand command, BaseHeader eventHeader, Optional<TTPhotoNodeV1> optionalTTPhotoNodeV1, Map<String, String> ttDataUpdateMap) {
        eventHeader.setCorrelationId(command.getEventHeaders().getCorrelationId());
        eventHeader.setEventDateTime(command.getEventHeaders().getEventDateTime());
        eventHeader.setTransactionId(command.getEventHeaders().getTransactionId());
        eventHeader.setPartnerCode(command.getEventHeaders().getPartnerCode());
        eventHeader.setEventContext(ttDataUpdateMap);
        if (Objects.nonNull((command.getEventBody().getPhotoUuid()))) {
            eventHeader.getEventContext().put("photoUuid", command.getEventBody().getPhotoUuid().toString());
        }

        if (optionalTTPhotoNodeV1.isPresent()) {
            eventHeader.setEventName(RDConstants.EventType.RESULT_DELIVERY_PHOTO_DETAIL_CHANGED);
        } else {
            eventHeader.setEventName(RDConstants.EventType.RESULT_DELIVERY_PHOTO_DETAIL_CHANGE_FAILED);
        }
    }

    private TTPhotoNodeV1 buildTTPhotoNodeV1(TestTakerPhoto testTakerPhoto) {
        TTPhotoNodeV1 ttPhotoNodeV1 = new TTPhotoNodeV1();
        ttPhotoNodeV1.setPhotoUuid(testTakerPhoto.getPhotoUuid());
        ttPhotoNodeV1.setBookingUuid(testTakerPhoto.getBookingUuid());
        ttPhotoNodeV1.setPhotoTypeUuid(testTakerPhoto.getPhotoTypeUuid());
        ttPhotoNodeV1.setFilePath(testTakerPhoto.getFilePath());
        ttPhotoNodeV1.setPhotoVersion(testTakerPhoto.getPhotoVersion());
        return ttPhotoNodeV1;
    }

    @Override
    protected ObjectMapper getObjectMapper() {
        return this.objectMapper;
    }

    @Override
    protected ResultRepository getResultRepository() {
        return this.resultRepository;
    }

    @Override
    protected BuildResultReleaseNodeV1Utils getBuildResultReleasedNodeV1Utils() {
        return this.resultReleaseNodeV1Utils;
    }
}
