package com.ielts.cmds.rd.domain.model;

import com.ielts.cmds.cre.model.GeneratorData;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class ReportGenerationModel implements GeneratorData {

    private String productModule;

    private String centreNumber;

    private String bookingTestDate;

    private String candidateNumber;

    private String familyName;

    private String firstName;

    private String candidateId;

    private String ttPhoto;

    private String dateOfBirth;

    private String sex;

    private String schemeCode;

    private String countryOrRegionOfOrigin;

    private String countryOfNationality;

    private String firstLanguage;

    private String listening;

    private String reading;

    private String writing;

    private String speaking;

    private String overallBandScore;

    private String cefrLevel;

    private String comments;

    private String date;

    private String trfNumber;

    private String below;

    private String templateName;

    private String templateNotes;

    private String writingResitScoresLabel;

    private String readingResitScoresLabel;

    private String speakingResitScoresLabel;

    private String listeningResitScoresLabel;

    private String singleSkillResitHeaderLabel;

    private String ukviNumber;

}
