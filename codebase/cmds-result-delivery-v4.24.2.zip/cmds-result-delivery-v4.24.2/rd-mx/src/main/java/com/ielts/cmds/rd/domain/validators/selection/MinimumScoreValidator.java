package com.ielts.cmds.rd.domain.validators.selection;

import com.ielts.cmds.ors.common.enums.ComponentEnum;
import com.ielts.cmds.ors.common.enums.ConfirmationStatusEnum;
import com.ielts.cmds.ors.common.out.model.ComponentMinimumScoreNodeV1ORS;
import com.ielts.cmds.ors.common.out.model.SelectionNodeV1ORS;
import com.ielts.cmds.rd.domain.model.SelectionDataBody;
import com.ielts.cmds.rd.domain.validators.selection.validation.ValidMinimumScore;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author vedire
 */
@Component
@Slf4j
public class MinimumScoreValidator
        implements ConstraintValidator<ValidMinimumScore, SelectionDataBody> {

    @Override
    public boolean isValid(final SelectionDataBody selectionDataBody, final ConstraintValidatorContext context) {
        context.disableDefaultConstraintViolation();

        SelectionNodeV1ORS selectionNode = selectionDataBody.getSelection();
        boolean isValid = true;

        //If it is a CONDITIONAL the check minimum score data integrity
        if (selectionNode.getConfirmationStatus()
                == ConfirmationStatusEnum.CONDITIONAL) {
            //Minimum score object should not be null
            if (Objects.isNull(selectionNode.getMinimumScore())) {
                context.buildConstraintViolationWithTemplate("{cmds.invalid.minimumScoreIsNull}")
                        .addPropertyNode("selection.minimumScore").addConstraintViolation();
                isValid = false;
            }

            //Overall minimum score should not be null
            if (Objects.nonNull(selectionNode.getMinimumScore()) && (Objects.isNull(selectionNode.getMinimumScore().getOverallMinimumScore()))) {
                context.buildConstraintViolationWithTemplate("{cmds.invalid.overAllScoreIsNull}")
                        .addPropertyNode("selection.minimumScore.overallMinimumScore").addConstraintViolation();
                isValid = false;
            }
        }

        if (Objects.nonNull(selectionNode.getMinimumScore()) && Objects.nonNull(selectionNode
                .getMinimumScore()
                .getComponentMinimumScores())) {

            List<ComponentMinimumScoreNodeV1ORS> componentScores = selectionNode
                    .getMinimumScore()
                    .getComponentMinimumScores();

            //If original component array size > distinct component array size then there are some duplicate elements
            //There should not be any duplicate component
            Map<ComponentEnum, List<ComponentMinimumScoreNodeV1ORS>> componentEnumListMap = componentScores.stream().collect(Collectors.groupingBy(ComponentMinimumScoreNodeV1ORS::getComponent));
            componentEnumListMap.entrySet().stream()
                    .filter(e -> e.getValue().size() > 1)
                    .forEach(e -> {
                        Integer index = componentScores.lastIndexOf(e.getValue().get(0));
                        String propertyNode = "selection.minimumScore.componentMinimumScores[" + index + "].component";
                        context.buildConstraintViolationWithTemplate("{cmds.invalid.duplicateComponentName}")
                                .addPropertyNode(propertyNode).addConstraintViolation();

                    });

            return componentScores.size() <= componentScores.stream().map(ComponentMinimumScoreNodeV1ORS::getComponent).distinct().count();

        }
        return isValid;
    }

}
