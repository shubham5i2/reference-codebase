package com.ielts.cmds.rd.domain.validators.selection.validation;

public interface SelectionCreateGroupValidation {
}
