package com.ielts.cmds.rd.domain.command;

import com.ielts.cmds.application.command.BaseCommand;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.ors.common.out.model.OrganisationSelectionNodeV1ORS;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ROSelectionCommand extends BaseCommand<BaseHeader, OrganisationSelectionNodeV1ORS> {

    @Builder
    public ROSelectionCommand(final BaseHeader eventHeader, final OrganisationSelectionNodeV1ORS eventBody,
                              final BaseEventErrors eventErrors, final BaseAudit eventAudit) {
        super(eventHeader, eventBody, eventErrors, eventAudit);
    }

}
