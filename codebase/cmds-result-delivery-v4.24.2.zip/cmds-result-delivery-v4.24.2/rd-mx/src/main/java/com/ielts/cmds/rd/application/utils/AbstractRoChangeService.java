/**
 * 
 */
package com.ielts.cmds.rd.application.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.rd.domain.command.RoChangeSelectionCommand;
import com.ielts.cmds.rd.domain.service.RoChangeDomainService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * @author vedire
 *
 */
@RequiredArgsConstructor
@Slf4j
public class AbstractRoChangeService {
	
	private final ObjectMapper objectMapper;
	
	private final RoChangeDomainService roChangeDomainService;

	public void process(BaseEvent<? extends BaseHeader> baseEvent) throws ProcessingException {
		 try {
			 final BaseHeader eventHeader = baseEvent.getEventHeader();
			 final BaseEventErrors eventErrors = baseEvent.getEventErrors();
			 final RoChangedEventV1 roChangedEventV1Body = objectMapper
					 .readValue(baseEvent.getEventBody(), RoChangedEventV1.class);
			 if (roChangedEventV1Body == null) {
				 throw new IllegalArgumentException("Payload is Empty");
			 }

			 // build command
			 final RoChangeSelectionCommand roChangeSelectionCommand = RoChangeSelectionCommand.builder()
					 .eventHeader(eventHeader).eventBody(roChangedEventV1Body)
					 .eventErrors(eventErrors).eventAudit(baseEvent.getAudit())
					 .build();

	            //Execute command
	            roChangeDomainService.on(roChangeSelectionCommand);
	        } catch (IllegalArgumentException | JsonProcessingException e) {
	            log.error("Failed to process Ro event due to ", e);
	            throw new ProcessingException(e.getMessage(), e);
	        }
		 
	}
}
