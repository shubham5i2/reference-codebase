package com.ielts.cmds.rd.domain.utils;

import com.ielts.cmds.rd.domain.model.enums.ConfirmationStatusEnum;
import com.ielts.cmds.rd.domain.model.out.SelectionMinimumScoreNodeV1;
import com.ielts.cmds.rd.domain.model.out.SelectionNodeV1;
import com.ielts.cmds.rd.infrastructure.entity.Booking;
import com.ielts.cmds.rd.infrastructure.entity.MinimumScore;
import com.ielts.cmds.rd.infrastructure.entity.Result;
import com.ielts.cmds.rd.infrastructure.entity.Selection;
import com.ielts.cmds.rd.infrastructure.repositories.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class BuildSelectionNodeV1Utils {

    private final SelectionRepository selectionRepository;

    private final ResultRepository resultRepository;

    private final BookingRepository bookingRepository;

    private final RecognisingOrganisationRepository recognisingOrganisationRepository;

    private final LocationRepository locationRepository;

    public SelectionNodeV1 buildSelectionNodeV1(UUID selectionUuid) {
        SelectionNodeV1 selectionNodeV1 = new SelectionNodeV1();
        if(Objects.nonNull(selectionUuid)) {
            Optional<Selection> optionalSelection = selectionRepository.findById(selectionUuid);
            if (optionalSelection.isPresent()) {
                Selection selection = optionalSelection.orElse(null);
                selectionNodeV1.setSelectionUuid(selection.getSelectionUuid());
                selectionNodeV1.setExternalSelectionUuid(selection.getExternalSelectionUuid());
                selectionNodeV1.setSelectionDate(selection.getSelectionDate());
                selectionNodeV1.setDeliveryStatus(selection.getDeliveryStatus());
                selectionNodeV1.setDeliveryStatusChangedDatetime(selection.getDeliveryStatusChangedDatetime());
                selectionNodeV1
                        .setConfirmationStatus(ConfirmationStatusEnum.valueOf(selection.getConfirmationStatus().getValue()));
                selectionNodeV1.setConfirmationStatusChangedDatetime(selection.getConfirmationStatusChangedDatetime());
                selectionNodeV1.setOverallMinimumScore(selection.getOverallMinimumScore());
                selectionNodeV1.setCaseNumber(selection.getCaseNumber());
                selectionNodeV1.setPersonDepartment(selection.getPersonDepartment());
                selectionNodeV1.setTrfNumber(getTrfNumberFromResult(selection.getExternalBookingUuid()));
                selectionNodeV1.setMinimumScoreSatisfied(selection.getMinimumScoreSatisfied());
                selectionNodeV1.setSharedDate(LocalDate.now());
                selectionNodeV1.setMinimumScores(setMinimumScoreV1(selection.getMinimumScores()));
            }
        }
        return selectionNodeV1;
    }

    private String getTrfNumberFromResult(final UUID externalBookingUuid) {
        Optional<Booking> optionalBooking = bookingRepository.findByExternalBookingUuid(externalBookingUuid);
        Optional<Result> optionalResult = Optional.empty();
        if (optionalBooking.isPresent()) {
            Booking booking = optionalBooking.get();
            optionalResult = resultRepository.findByBookingUuid(booking.getBookingUuid());

        }
        return optionalResult.map(Result::getTrfNumber).orElse(null);
    }

    private List<SelectionMinimumScoreNodeV1> setMinimumScoreV1(List<MinimumScore> minimumScores) {
        if (Objects.isNull(minimumScores))
            return Collections.emptyList();
        else {
            return minimumScores.stream()
                    .map(ms -> {
                        SelectionMinimumScoreNodeV1 minimumScoreNodeV1 = new SelectionMinimumScoreNodeV1();
                        minimumScoreNodeV1.setComponent(ms.getComponent());
                        minimumScoreNodeV1.setMinimumScoreValue(ms.getMinimumScoreValue());
                        minimumScoreNodeV1.setMinimumScoreUuid(ms.getMinimumScoreUuid());
                        return minimumScoreNodeV1;
                    }).collect(Collectors.toList());
        }
    }
}
