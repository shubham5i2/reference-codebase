package com.ielts.cmds.rd.infrastructure.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.UUID;

@Data
@ToString
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "recognising_organisation_address")
public class RecognisingOrganisationAddress implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -8970326851956422995L;

    @Id
    @Column(name = "address_uuid")
    private UUID addressUuid;

    @Column(name="address_type_uuid")
    private UUID addressTypeUuid;

    @Column(name="addressline1")
    private String addressLine1;

    @Column(name="addressline2")
    private String addressLine2;

    @Column(name="addressline3")
    private String addressLine3;

    @Column(name="addressline4")
    private String addressLine4;

    @Column(name="city")
    private String city;

    @Column(name="postalcode")
    private String postalCode;

    @Column(name="updated_datetime")
    private OffsetDateTime updatedDateTime;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "recognising_organisation_uuid")
    private RecognisingOrganisation recognisingOrganisation;

}
