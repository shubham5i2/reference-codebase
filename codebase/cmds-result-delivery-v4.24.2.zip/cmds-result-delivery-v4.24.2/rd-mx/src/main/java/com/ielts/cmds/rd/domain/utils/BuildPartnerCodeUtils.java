package com.ielts.cmds.rd.domain.utils;

import com.ielts.cmds.rd.infrastructure.entity.Booking;
import com.ielts.cmds.rd.infrastructure.repositories.BookingRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotNull;
import java.util.Optional;
import java.util.UUID;

@Component
@RequiredArgsConstructor
@Slf4j
public class BuildPartnerCodeUtils {

    private final BookingRepository bookingRepository;

    public String getPartnerCode(@NotNull UUID bookingUuid) {
        String partnerCode;
        Optional<Booking> optionalBooking = bookingRepository.findById(bookingUuid);
        if (optionalBooking.isPresent()) {
            partnerCode = optionalBooking.get().getPartnerCode();
            return partnerCode;
        }
        throw new IllegalStateException("Partner code cannot be retrieved as booking is not present");
    }
}
