package com.ielts.cmds.rd.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.domain.command.TRFPermanentlyWithholdRequestedCommand;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import com.ielts.cmds.rd.domain.utils.BuildResultReleaseNodeV1Utils;
import com.ielts.cmds.rd.infrastructure.entity.Result;
import com.ielts.cmds.rd.infrastructure.repositories.ResultRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.constraints.NotNull;
import java.lang.reflect.InvocationTargetException;
import java.util.Objects;
import java.util.Optional;

@Service
@Slf4j
@RequiredArgsConstructor
public class TRFPermanentlyWithheldRequestedDomainService {

    private final ObjectMapper objectMapper;

    private final ApplicationEventPublisher applicationEventPublisher;

    private final BuildResultReleaseNodeV1Utils buildResultReleaseNodeV1Utils;

    private final ResultRepository resultRepository;

    @Transactional
    public void on(@NotNull final TRFPermanentlyWithholdRequestedCommand command) throws JsonProcessingException, InvocationTargetException, IllegalAccessException {
        Optional<ResultReleasedNodeV1> optionalResultReleasedNodeV1 = Optional.empty();
        BaseEvent<BaseHeader> baseEvent = null;
        String eventBody;

        if (Objects.nonNull(command.getEventBody().getResultDetails().getResultUuid())) {
            optionalResultReleasedNodeV1 = Optional.of(buildResultReleaseNodeV1Utils
                    .buildResultReleasedNodeV1(command.getEventBody().getResultDetails().getResultUuid()));

            Optional<Result> optionalResult = resultRepository.findById(command.getEventBody().getResultDetails().getResultUuid());
            if (optionalResult.isPresent()) {
                ResultReleasedNodeV1 resultReleasedNodeV1 = optionalResultReleasedNodeV1.get();
                resultReleasedNodeV1.setReferenceData(buildResultReleaseNodeV1Utils.getReferenceData(optionalResult.get()));
            }
        }

        optionalResultReleasedNodeV1.ifPresent(resultReleasedNodeV11 -> resultReleasedNodeV11.getResultDetails().setResultRenditions(null));
        eventBody = objectMapper.writeValueAsString(optionalResultReleasedNodeV1);
        baseEvent = new BaseEvent<>(setEventHeader(command.getEventHeaders()), eventBody, null, null);
        applicationEventPublisher.publishEvent(baseEvent);
    }

    private BaseHeader setEventHeader(BaseHeader incomingHeaders) throws InvocationTargetException, IllegalAccessException {
        BaseHeader baseHeader = new BaseHeader();
        BeanUtils.copyProperties(baseHeader, incomingHeaders);
        baseHeader.setEventName(RDConstants.EventType.TRF_PERMANENTLY_WITHHELD);
        return baseHeader;
    }
}
