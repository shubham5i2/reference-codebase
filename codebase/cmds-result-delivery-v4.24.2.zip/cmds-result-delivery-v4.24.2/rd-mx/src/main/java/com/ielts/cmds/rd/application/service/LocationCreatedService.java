package com.ielts.cmds.rd.application.service;

import com.ielts.cmds.lpr.common.out.model.LocationV1;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.config.IApplicationService;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.lpr.common.in.model.LocationNode;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.domain.command.CreateLocationSelectionCommand;
import com.ielts.cmds.rd.domain.service.LocationCreatedDomainService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class LocationCreatedService implements IApplicationService {

	private final ObjectMapper objectMapper;

	private final LocationCreatedDomainService locationCreatedDomainService;

	@Override
	public String getServiceIdentifier() {
		return RDConstants.EventType.LOCATION_CHANGED;
	}

	@Override
	public void process(BaseEvent<? extends BaseHeader> baseEvent) throws ProcessingException {

		try {
            final BaseHeader eventHeader = baseEvent.getEventHeader();
            final BaseEventErrors eventErrors = baseEvent.getEventErrors();
            final LocationV1 locationBody = objectMapper
                    .readValue(baseEvent.getEventBody(), LocationV1.class);
            if (locationBody == null) {
                throw new IllegalArgumentException("Payload is Empty");
            }
            // build command
            final CreateLocationSelectionCommand createLocationSelectionCommand = CreateLocationSelectionCommand.builder()
                    .eventHeader(eventHeader).eventBody(locationBody)
                    .eventErrors(eventErrors).eventAudit(baseEvent.getAudit())
                    .build();

            // Execute command
            locationCreatedDomainService.on(createLocationSelectionCommand);
        } catch (IllegalArgumentException | JsonProcessingException e) {
            log.error("Failed to process Booking event due to ", e);
            throw new ProcessingException(e.getMessage(), e);
        }
		
	}

}
