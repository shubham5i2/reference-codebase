package com.ielts.cmds.rd.domain.enums;


import com.ielts.cmds.rd.domain.RDConstants;
import lombok.Getter;
import lombok.RequiredArgsConstructor;


@RequiredArgsConstructor
@Getter
public enum SecondarySelectionEnums {

    SECONDARY_SELECTION(RDConstants.GenericConstants.SECONDARY_SELECTION, "true");

    private final String key;

    private final String value;
}