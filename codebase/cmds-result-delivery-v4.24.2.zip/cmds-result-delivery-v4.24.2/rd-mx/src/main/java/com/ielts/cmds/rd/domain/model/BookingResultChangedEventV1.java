package com.ielts.cmds.rd.domain.model;

import com.google.gson.annotations.SerializedName;

import com.ielts.cmds.rm.common.out.model.BookingResultInfoEventV1;
import lombok.Data;

@Data
public class BookingResultChangedEventV1 {
  @SerializedName("bookingResultInfo")
  private BookingResultInfoEventV1 bookingResultInfo = null;

}
