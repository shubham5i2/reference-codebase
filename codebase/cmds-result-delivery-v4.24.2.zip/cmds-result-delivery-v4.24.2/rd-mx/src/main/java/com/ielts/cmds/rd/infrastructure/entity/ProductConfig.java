package com.ielts.cmds.rd.infrastructure.entity;

import lombok.Data;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.UUID;

@Entity
@ToString
@Table(name = "product_config")
@Data
public class ProductConfig implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "product_config_uuid")
    private UUID productConfigUuid;

    @Column(name = "rendition_type_uuid")
    private UUID renditionTypeUuid;

    @Column(name = "product_uuid")
    private UUID productUuid;

    @Column(name = "partner_code")
    private String partnerCode;

    @Column(name = "template_name")
    private String templateName;

    @Column(name = "report_module_name")
    private String reportModuleName;

    @Column(name = "effective_from_date")
    private LocalDate effectiveFromDate;

    @Column(name = "effective_to_date")
    private LocalDate effectiveToDate;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "updated_by")
    private String updatedBy;

    @Column(name = "created_datetime")
    private OffsetDateTime createdDatetime;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;

    @Version
    @Column(name = "concurrency_version")
    private Integer concurrencyVersion;

}
