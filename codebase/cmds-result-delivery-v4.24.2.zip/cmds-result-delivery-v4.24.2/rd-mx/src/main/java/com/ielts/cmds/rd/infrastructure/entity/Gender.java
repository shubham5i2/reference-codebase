package com.ielts.cmds.rd.infrastructure.entity;

import lombok.*;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.UUID;

@Getter
@Setter
@Entity
@Table(name = "gender")
@NoArgsConstructor
@AllArgsConstructor
@Builder
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class Gender {

    @Id
    @Column(name = "gender_uuid")
    private UUID genderUuid;

    @Column(name = "gender_code")
    private String genderCode;

    @Column(name = "gender_description")
    private String genderDescription;

    @Column(name = "effective_from_date")
    private LocalDate effectiveFromDate;

    @Column(name = "legacy_reference")
    private String legacyReference;

    @Column(name = "effective_to_date")
    private LocalDate effectiveToDate;

    @Version
    @Column(name = "concurrency_version")
    private Integer concurrencyVersion;

    @Column(name = "updated_by")
    private String updatedBy;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;

    @Column(name = "created_datetime")
    private OffsetDateTime createdDatetime;

}
