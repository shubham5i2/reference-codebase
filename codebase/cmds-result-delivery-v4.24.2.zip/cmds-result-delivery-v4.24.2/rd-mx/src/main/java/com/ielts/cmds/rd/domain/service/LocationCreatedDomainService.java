package com.ielts.cmds.rd.domain.service;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.application.command.BaseCommand;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.lpr.common.out.model.LocationV1;
import com.ielts.cmds.rd.application.exception.ResultDeliveryValidationException;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.domain.command.CreateLocationSelectionCommand;
import com.ielts.cmds.rd.domain.model.out.LocationNodeDetails;
import com.ielts.cmds.rd.infrastructure.entity.Location;
import com.ielts.cmds.rd.infrastructure.repositories.LocationRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;


@Service
@Slf4j
public class LocationCreatedDomainService {

    private final ObjectMapper objectMapper;

    private final LocationRepository locationRepository;

    private final ApplicationEventPublisher applicationEventPublisher;

    @Autowired
    public LocationCreatedDomainService(ObjectMapper objectMapper, LocationRepository locationRepository,
                                        ApplicationEventPublisher applicationEventPublisher) {
        this.objectMapper = objectMapper;
        this.locationRepository = locationRepository;
        this.applicationEventPublisher = applicationEventPublisher;
    }

    @Transactional
    public void on(CreateLocationSelectionCommand command) throws JsonProcessingException {

        log.info("Received location created event with location uuid {} ", command.getEventBody().getLocationUuid());

        Optional<LocationNodeDetails> optionalLocationNodeDetails = Optional.empty();
        String eventBody;
        try {
            Optional<Location> optionalLocation = locationRepository.findById(command.getEventBody().getLocationUuid());
            locationValidation(command, optionalLocation);
            Location location = addLocationDetails(command, optionalLocation);
            optionalLocationNodeDetails = Optional.of(buildLocationNode(location));
            eventBody = objectMapper.writeValueAsString(optionalLocationNodeDetails);
        } catch (final ResultDeliveryValidationException e) {
            log.error("LocationCommand execution failed", e);
            eventBody = null;
        }
        BaseEvent<BaseHeader> event = new BaseEvent<>(buildHeader(command, optionalLocationNodeDetails), eventBody, null, command.getAudit());
        applicationEventPublisher.publishEvent(event);
    }

    public BaseHeader buildHeader(CreateLocationSelectionCommand command, Optional<LocationNodeDetails> locationNodeDetails) {
        BaseHeader eventHeader = new BaseHeader();
        eventHeader.setCorrelationId(command.getEventHeaders().getCorrelationId());
        eventHeader.setEventDateTime(LocalDateTime.now());
        eventHeader.setTransactionId(command.getEventHeaders().getTransactionId());
        eventHeader.setPartnerCode(command.getEventHeaders().getPartnerCode());
        Map<String, String> eventContext = Optional
                .ofNullable(command.getEventHeaders().getEventContext())
                .orElseGet(HashMap::new);

        if (Objects.nonNull((command.getEventBody().getLocationUuid()))) {
            eventContext.put("locationUuid", command.getEventBody().getLocationUuid().toString());
        }
        eventHeader.setEventContext(eventContext);

        if (locationNodeDetails.isPresent()) {
            eventHeader.setEventName(RDConstants.EventType.SELECTION_LOCATION_EVENT);
        } else {
            eventHeader.setEventName(RDConstants.EventType.SELECTION_LOCATION_EVENT_FAILED);
        }
        return eventHeader;
    }


    private void locationValidation(CreateLocationSelectionCommand command,
                                    Optional<Location> optionalLocation) throws ResultDeliveryValidationException {
        if (optionalLocation.isPresent()) {
            LocalDateTime localDateTime = optionalLocation.get().getEventDatetime().toLocalDateTime();
            if (!(command.getEventHeaders().getEventDateTime().isAfter(localDateTime))) {
                throw new ResultDeliveryValidationException(String.format("Received Event Date time is before this : %s  " + "for this Location UUID : %s"
                        , localDateTime, command.getEventBody().getLocationUuid()), new Throwable());
            }
        }

    }

    private Location addLocationDetails(BaseCommand<BaseHeader, LocationV1> command, Optional<Location> optionalLocation) {
        Location location = optionalLocation.orElseGet(() -> Location.builder().locationUuid(command.getEventBody().getLocationUuid()).build());
        location.setLocationName(command.getEventBody().getLocationName());
        location.setLocationType(command.getEventBody().getLocationTypeCode());
        location.setParentLocationUuid(command.getEventBody().getParentLocationUuid());
        location.setPartnerCode(String.valueOf(command.getEventBody().getPartnerCode()));
        location.setTestCentreNumber(command.getEventBody().getTestCentreNumber());
        location.setStatus(command.getEventBody().getStatus());
        location.setUpdatedDatetime(OffsetDateTime.now(ZoneOffset.UTC));
        location.setEventDatetime(OffsetDateTime.of(command.getEventHeaders().getEventDateTime(), ZoneOffset.UTC));
        locationRepository.save(location);
        return location;
    }

    private LocationNodeDetails buildLocationNode(Location location) {
        LocationNodeDetails locationNodeDetails = new LocationNodeDetails();
        locationNodeDetails.setLocationUuid(location.getLocationUuid());
        locationNodeDetails.setParentLocationUuid(location.getParentLocationUuid());
        locationNodeDetails.setLocationName(location.getLocationName());
        locationNodeDetails.setLocationTypeCode(location.getLocationType());
        locationNodeDetails.setTestCentreNumber(location.getTestCentreNumber());
        return locationNodeDetails;
    }
}
