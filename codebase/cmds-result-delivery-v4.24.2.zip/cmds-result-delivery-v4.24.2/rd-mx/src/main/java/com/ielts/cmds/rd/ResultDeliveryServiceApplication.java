package com.ielts.cmds.rd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;
import com.ielts.cmds.outbox.configuration.EnableOutbox;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScan("com.ielts.cmds")
@EnableCaching
@EnableJpaRepositories(basePackages = "com.ielts.cmds")
@EntityScan(basePackages = {"com.ielts.cmds"})

@EnableOutbox
public class ResultDeliveryServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResultDeliveryServiceApplication.class, args);
	}

}
 
