package com.ielts.cmds.rd.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.rd.application.exception.ResultDeliveryValidationException;
import com.ielts.cmds.rd.domain.command.TemplateDownloadCommand;
import com.ielts.cmds.rd.domain.model.enums.RenditionTypeCodeEnum;
import com.ielts.cmds.rd.domain.utils.*;
import com.ielts.cmds.rd.infrastructure.repositories.*;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.lang.reflect.InvocationTargetException;

@Service
public class ETRFDownloadDomainService extends AbstractTemplateDownloadDomainService {

    @Autowired
    public ETRFDownloadDomainService(ObjectMapper objectMapper, ResultRepository resultRepository,
                                     ResultsRenditionRepository resultsRenditionRepository, ResultTrfPrintStatusRepository resultTrfPrintStatusRepository,
                                     SelectionRepository selectionRepository, RenditionTypeRepository renditionTypeRepository,
                                     RecognisingOrganisationRepository recognisingOrganisationRepository, BookingRepository bookingRepository,
                                     BuildResultReleaseNodeV1Utils buildResultReleaseNodeV1Utils, BuildSelectionNodeV1Utils buildOrganisationSelectionNodeV1Utils,
                                     BuildRecognisingOrganisationNodeV1Utils buildRecognisingOrganisationNodeV1Utils, DomainEventsPublisher domainEventsPublisher,
                                     ResultsStatusTypeRepository resultsStatusTypeRepository,
                                     RbacAuthorization rbacAuthorization) {
        super(objectMapper, resultRepository, resultsRenditionRepository, resultTrfPrintStatusRepository, selectionRepository, renditionTypeRepository, recognisingOrganisationRepository, bookingRepository, buildResultReleaseNodeV1Utils, buildOrganisationSelectionNodeV1Utils, buildRecognisingOrganisationNodeV1Utils, domainEventsPublisher, resultsStatusTypeRepository, rbacAuthorization);
    }

    @Transactional
    @SneakyThrows
    public void on(TemplateDownloadCommand command) throws JsonProcessingException, ResultDeliveryValidationException, InvocationTargetException, IllegalAccessException {
        process(command, RenditionTypeCodeEnum.ETRF);
    }
}
