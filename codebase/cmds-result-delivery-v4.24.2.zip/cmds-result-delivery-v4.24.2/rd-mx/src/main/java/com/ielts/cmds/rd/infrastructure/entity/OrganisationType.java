package com.ielts.cmds.rd.infrastructure.entity;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import javax.persistence.Version;
import java.time.LocalDate;
import java.time.OffsetDateTime;


/**
 * The persistent class for the organisation_type database table.
 * 
 */
@Entity(name="organisation_type")
@Data
@EqualsAndHashCode
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class OrganisationType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="organisation_type_uuid")
	private UUID organisationTypeUuid;

	private String description;

	@Column(name="organisation_type")
	private String organisationTypeName;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "effective_from_date")
	private LocalDate effectiveFromDate;

	@Column(name = "updated_by")
	private String updatedBy;

	@Column(name = "created_datetime")
	private OffsetDateTime createdDatetime;

	@Column(name = "effective_to_date")
	private LocalDate effectiveToDate;

	@Version
	@Column(name = "concurrency_version")
	private Integer concurrencyVersion;

	@Column(name = "updated_datetime")
	private OffsetDateTime updatedDatetime;

}