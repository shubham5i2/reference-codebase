package com.ielts.cmds.rd.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.common.enums.MethodOfDeliveryEnum;
import com.ielts.cmds.organisation.common.enums.OrganisationStatusEnum;
import com.ielts.cmds.organisation.common.enums.VerificationStatusEnum;
import com.ielts.cmds.rd.application.exception.ResultDeliveryValidationException;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.domain.command.ROSelectionChangeAnalysisCommand;
import com.ielts.cmds.rd.domain.enums.SecondarySelectionEnums;
import com.ielts.cmds.rd.domain.model.SelectionAggregate;
import com.ielts.cmds.rd.domain.model.enums.ConfirmationStatusEnum;
import com.ielts.cmds.rd.domain.model.enums.DeliveryStatusEnum;
import com.ielts.cmds.rd.domain.model.enums.LinkTypeEnum;
import com.ielts.cmds.rd.domain.model.enums.MinimumScoreSatisfiedEnum;
import com.ielts.cmds.rd.domain.model.out.LinkedRecognisingOrganisationV1;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;
import com.ielts.cmds.rd.domain.utils.BuildOrganisationSelectionNodeV1Utils;
import com.ielts.cmds.rd.domain.utils.BuildResultModelUtils;
import com.ielts.cmds.rd.domain.utils.DomainEventsPublisher;
import com.ielts.cmds.rd.domain.utils.ROSelectionChangeAnalysisHelper;
import com.ielts.cmds.rd.infrastructure.entity.*;
import com.ielts.cmds.rd.infrastructure.repositories.*;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.ConstraintViolation;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.*;

import static com.ielts.cmds.rd.domain.RDConstants.EventType.RO_SELECTION_CHANGED_FAILED;
import static com.ielts.cmds.rd.domain.RDConstants.EventType.RO_SELECTION_DELIVERY_REQUESTED;
import static java.time.ZoneOffset.UTC;


@Service
@Slf4j
@RequiredArgsConstructor
public class ROSelectionChangeAnalysisDomainService extends AbstractDomainService{

    private final ObjectMapper objectMapper;

    private final ResultRepository resultRepository;

    private final SelectionRepository selectionRepository;

    private final ResultsStatusTypeRepository resultsStatusTypeRepository;

    private final RecognisingOrganisationRepository recognisingOrganisationRepository;

    private final BookingRepository bookingRepository;

    private final OrganisationTypeRepository organisationTypeRepository;

    private final DomainEventsPublisher domainEventsPublisher;

    private final BuildResultModelUtils resultModelUtils;

    private final BuildOrganisationSelectionNodeV1Utils buildOrganisationSelectionNodeUtils;


    @Transactional
    @SneakyThrows
    public void on(@NotNull ROSelectionChangeAnalysisCommand command) throws JsonProcessingException {

        ROSelectionChangeAnalysisHelper helper = new ROSelectionChangeAnalysisHelper();

        List<BaseEvent<BaseHeader>> baseEventList = new ArrayList<>();
        //if eventBody is null
        if (isErrorTypeValidationOrError(command.getEventErrors())) {
            log.info("Received RO Selection Change Analysis event with event errors of type Validation/Error for TransactionId {}", command.getEventHeaders().getTransactionId());
            Optional<BaseEvent<BaseHeader>> errorEvent = generateErrorEvent(command);
            errorEvent.ifPresent(baseEventList::add);
        }
        // if eventBody is not null
        else {
            log.debug("Received RO Selection Change Analysis event with Selection Uuid {}", command.getEventBody().getSelection().getSelectionUuid());

            OrganisationSelectionNodeV1 organisationSelectionNodeV1 = new OrganisationSelectionNodeV1();
            organisationSelectionNodeV1 = helper.setNode(command.getEventBody(), organisationSelectionNodeV1);

            OrganisationSelectionNodeV1 eventBodyForPrimarySelection = new OrganisationSelectionNodeV1();
            eventBodyForPrimarySelection = helper.setNode(command.getEventBody(), eventBodyForPrimarySelection);

            UUID bookingUuid = command.getEventBody().getBookingDetails().getBookingUuid();

            Optional<BaseEvent<BaseHeader>> roSelectionDeliveryRequestedEvent;

            //Retrieve Result using booking Uuid
            Optional<Result> optionalResult = resultRepository.findByBookingUuid(bookingUuid);


            if (optionalResult.isPresent()) {

                log.info("Result is available for booking with externalBookingUuid {}", command.getEventBody().getBookingDetails().getExternalBookingUuid());

                Result result = optionalResult.get();

                //Retrieve Result Status using resultUuid from result
                Optional<ResultsStatusType> optionalResultStatusType = resultsStatusTypeRepository
                        .findById(result.getResultsStatusTypeUuid());
                ResultsStatusType resultsStatusType = optionalResultStatusType
                        .orElseThrow(() -> new ResultDeliveryValidationException
                                ("RO Selection Change Analysis Event Failed as Result Status type is not Present", new Throwable()));

                Optional<Booking> optionalBooking = bookingRepository.findById(bookingUuid);

                //get Selection from database
                Optional<Selection> optionalSelection = selectionRepository
                        .findById(command.getEventBody().getSelection().getSelectionUuid());

                Selection selection = optionalSelection.orElseThrow(() -> new ResultDeliveryValidationException
                        ("RO Selection Change Analysis Event Failed as  selection is not Present", new Throwable()));


                //get optional Recognising Organisation for selection Aggregate
                Optional<RecognisingOrganisation> optionalRO = recognisingOrganisationRepository
                        .findById(selection.getRecognisingOrganisationUuid());
                RecognisingOrganisation recognisingOrganisation1 = optionalRO.orElse(null);

                //get optional Organisation Type for selection Aggregate
                Optional<OrganisationType> optionalOrganisationType = Optional.empty();
                if (optionalRO.isPresent()) {
                    optionalOrganisationType = organisationTypeRepository
                            .findById(recognisingOrganisation1.getOrganisationTypeUuid());
                }
                //selection Aggregate validations
                SelectionAggregate selectionAggregate;
                selectionAggregate = getSelectionAggregate(optionalResult, optionalBooking, selection, optionalRO, optionalOrganisationType);

                Set<ConstraintViolation<SelectionAggregate>> violations = selectionAggregate.canSelectionBeDeliveredToResultPortal();

                //resultStatus is released or not
                boolean isResultStatusReleased = Objects.equals(resultsStatusType.getResultStatusCode(), RDConstants.GenericConstants.RELEASED);

                //if any violations are present or ResultStatus is not released
                if (!violations.isEmpty() || !isResultStatusReleased) {
                    organisationSelectionNodeV1.getSelection().setDeliveryStatus(DeliveryStatusEnum.UNDELIVERED);
                    organisationSelectionNodeV1.getSelection().setDeliveryStatusChangedDatetime(OffsetDateTime.now());
                    if (isResultStatusReleased) {
                        //if confirmation status is other than confirmed
                        if (command.getEventBody().getSelection().getConfirmationStatus() != ConfirmationStatusEnum.CONFIRMED) {
                            boolean minScoreSatisfied = selectionAggregate.isMinimumScoreSatisfied();
                            MinimumScoreSatisfiedEnum minScore = minScoreSatisfied ? MinimumScoreSatisfiedEnum.SATISFIED : MinimumScoreSatisfiedEnum.UNSATISFIED;
                            organisationSelectionNodeV1.getSelection().setMinimumScoreSatisfied(minScore);
                        }
                        //if confirmation status is confirmed
                        else {
                            organisationSelectionNodeV1.getSelection().setMinimumScoreSatisfied(MinimumScoreSatisfiedEnum.NOT_APPLICABLE);
                        }
                    }

                    eventBodyForPrimarySelection = helper.setNode(organisationSelectionNodeV1, eventBodyForPrimarySelection);
                }
                //if Selection eligible and min score satisfied and resultStatus is Released
                else {
                    if (command.getEventBody().getSelection().getConfirmationStatus().equals(ConfirmationStatusEnum.CONDITIONAL)) {
                        eventBodyForPrimarySelection.getSelection().setMinimumScoreSatisfied(MinimumScoreSatisfiedEnum.SATISFIED);
                    }
                    // list of linked organisations
                    RecognisingOrganisation recognisingOrganisation = recognisingOrganisationRepository.findById(selection.getRecognisingOrganisationUuid()).orElseThrow(() -> new ResultDeliveryValidationException
                            ("RO Selection Change Analysis Event Failed as Selection is not Present", new Throwable()));

                    List<LinkedRecognisingOrganisation> linkedOrganisations = recognisingOrganisation.getLinkedRecognisingOrganisations();

                    //set linked organisations to event body
                    setLinkedOrganisationData(eventBodyForPrimarySelection, linkedOrganisations);
                    int numberOfValidLinkedROs = 0;

                    for (LinkedRecognisingOrganisation linkedOrganisation : linkedOrganisations) {
                        Optional<RecognisingOrganisation> optionalRecognisingOrganisation = recognisingOrganisationRepository
                                .findById(linkedOrganisation.getTargetRecognisingOrganisationUuid());

                        //if link is valid and linkType is resultDelivery
                        if (isLinkedOrganisationEligible(linkedOrganisation, optionalRecognisingOrganisation)) {

                            numberOfValidLinkedROs++;
                            organisationSelectionNodeV1.setOrganisationDetails
                                    (helper.setRecognisingOrganisationForSecondarySelection(optionalRecognisingOrganisation.get()));

                            organisationSelectionNodeV1.setSelection(helper.setSelectionForSecondarySelection(command.getEventBody().getSelection()));

                            roSelectionDeliveryRequestedEvent = roSelectionDeliveryRequestedEvent(command, organisationSelectionNodeV1);
                            roSelectionDeliveryRequestedEvent.ifPresent(baseEventList::add);
                        }
                    }
                    log.info("Number of additional delivery organisations present for the selected Organisation: {}. Number of valid delivery organisations according to business validations: {}", linkedOrganisations.size(), numberOfValidLinkedROs);
                }

                roSelectionDeliveryRequestedEvent = roSelectionDeliveryRequestedEvent(command, eventBodyForPrimarySelection);
                roSelectionDeliveryRequestedEvent.ifPresent(baseEventList::add);

            }
            //if result not found in database
            else {
                log.info("Result is not present in db for booking with externalBookingUuid {}", command.getEventBody().getBookingDetails().getExternalBookingUuid());
                organisationSelectionNodeV1.getSelection().setDeliveryStatus(DeliveryStatusEnum.UNDELIVERED);
                roSelectionDeliveryRequestedEvent = roSelectionDeliveryRequestedEvent(command, organisationSelectionNodeV1);
                roSelectionDeliveryRequestedEvent.ifPresent(baseEventList::add);

            }
        }
        domainEventsPublisher.baseEventListPublisher(baseEventList);
    }


    /**
     * set linked RO details for primary selection event
     *
     * @param eventBodyForPrimarySelection primary selection body
     * @param linkedRos                    ROs from primary selection
     * @return
     */
    private void setLinkedOrganisationData
    (OrganisationSelectionNodeV1 eventBodyForPrimarySelection, List<LinkedRecognisingOrganisation> linkedRos) {

        for (LinkedRecognisingOrganisation linkedRO : linkedRos) {
            LinkedRecognisingOrganisationV1 linkedRoV1 = new LinkedRecognisingOrganisationV1();
            linkedRoV1.setLinkedOrganisationUuid(linkedRO.getLinkedRecognisingOrganisationUuid());
            linkedRoV1.setLinkType(linkedRO.getLinkedRecognisingOrganisationType());
            linkedRoV1.setLinkEffectiveFromDateTime(linkedRO.getLinkEffectiveFromDatetime());
            linkedRoV1.setLinkEffectiveToDateTime(linkedRO.getLinkEffectiveToDatetime());
            if (Objects.isNull(eventBodyForPrimarySelection.getOrganisationDetails().getLinkedOrganisations())) {
                List<LinkedRecognisingOrganisationV1> linkedOrganisations = new ArrayList<>();
                eventBodyForPrimarySelection.getOrganisationDetails().setLinkedOrganisations(linkedOrganisations);
            }
            eventBodyForPrimarySelection.getOrganisationDetails().getLinkedOrganisations().add(linkedRoV1);
        }

    }


    /**
     * generate error event if eventBody is null in command
     *
     * @param command NULL
     * @return error event
     */
    public Optional<BaseEvent<BaseHeader>> generateErrorEvent(ROSelectionChangeAnalysisCommand command) throws JsonProcessingException {
        BaseEvent<BaseHeader> errorEvent = new BaseEvent<>();
        errorEvent.setEventHeader(buildHeader(command.getEventHeaders(), RO_SELECTION_CHANGED_FAILED));
        if(Objects.nonNull(command.getEventBody()))
        {
            errorEvent.setEventBody(getEventBodyForSelectionEvents(command.getEventBody().getSelection().getExternalSelectionUuid()));
        }
        errorEvent.setEventErrors(command.getEventErrors());
        return Optional.of(errorEvent);
    }


    /**
     * set eventHeader and eventBody
     * check for secondary selection and set flag true
     *
     * @return event
     */
    private Optional<BaseEvent<BaseHeader>> roSelectionDeliveryRequestedEvent(ROSelectionChangeAnalysisCommand command, OrganisationSelectionNodeV1 organisationSelectionNodeV1) throws JsonProcessingException {
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        baseEvent.setEventHeader(buildHeader(command.getEventHeaders(), RO_SELECTION_DELIVERY_REQUESTED));
        //Set Secondary Selection Flag
        if (Objects.nonNull(organisationSelectionNodeV1.getSelection().getAssociatedSelectionUuid())) {
            baseEvent.getEventHeader().getEventContext().put(SecondarySelectionEnums.SECONDARY_SELECTION.getKey(), SecondarySelectionEnums.SECONDARY_SELECTION.getValue());
        }
        String body = objectMapper.writeValueAsString(organisationSelectionNodeV1);
        baseEvent.setEventBody(body);
        baseEvent.setEventErrors(null);
        return Optional.of(baseEvent);
    }

    /**
     * check if current date is between from and to dates
     * link Type is result Delivery
     * Enums : E_DELIVERY, APPROVED, ACTIVE
     *
     * @return true if both are valid.
     */
    private boolean isLinkedOrganisationEligible(LinkedRecognisingOrganisation linkedRO, Optional<RecognisingOrganisation> optionalRecognisingOrganisation) {
        boolean roValid = false;
        if (optionalRecognisingOrganisation.isPresent()) {
            RecognisingOrganisation recognisingOrganisation = optionalRecognisingOrganisation.get();
            roValid = recognisingOrganisation.getMethodOfDelivery().equals(MethodOfDeliveryEnum.E_DELIVERY)
                    && recognisingOrganisation.getVerificationStatus().equals(VerificationStatusEnum.APPROVED)
                    && recognisingOrganisation.getOrganisationStatus().equals(OrganisationStatusEnum.ACTIVE);
        }
        boolean dateAndLinkTypeValid = false;
        OffsetDateTime currentDate = OffsetDateTime.now();
        OffsetDateTime from = linkedRO.getLinkEffectiveFromDatetime();
        OffsetDateTime to = linkedRO.getLinkEffectiveToDatetime();
        if (from.isBefore(currentDate) && currentDate.isBefore(to)
                && linkedRO.getLinkedRecognisingOrganisationType().equals(LinkTypeEnum.RESULTS_DELIVERY))
            dateAndLinkTypeValid = true;

        return dateAndLinkTypeValid && roValid && !linkedRO.getDeleted();
    }


    private SelectionAggregate getSelectionAggregate(Optional<Result> optionalResult, Optional<Booking> finalOptionalBooking, Selection e, Optional<RecognisingOrganisation> recognisingOrganisation, Optional<OrganisationType> optionalOrganisationType) {
        return SelectionAggregate.builder()
                .selection(e)
                .result(resultModelUtils.populateResultModelData(optionalResult))
                .booking(finalOptionalBooking.orElse(null))
                .organisation(recognisingOrganisation.orElse(null))
                .organisationType(optionalOrganisationType.orElse(null))
                .command(null).build();
    }

    @Override
    public BaseHeader buildHeader(BaseHeader eventHeaders, String eventName) {
        BaseHeader baseHeader = new BaseHeader();
        baseHeader.setEventName(eventName);
        if (Objects.isNull(eventHeaders.getEventContext())) {
            Map<String, String> contextFromCommand = new HashMap<>();
            eventHeaders.setEventContext(contextFromCommand);
        }
        Map<String, String> context = new HashMap<>(eventHeaders.getEventContext());
        baseHeader.setEventContext(context);
        baseHeader.setCorrelationId(eventHeaders.getCorrelationId());
        baseHeader.setTransactionId(eventHeaders.getTransactionId());
        baseHeader.setEventDateTime(LocalDateTime.now(UTC));
        baseHeader.setPartnerCode(eventHeaders.getPartnerCode());
        return baseHeader;
    }

    @Override
    protected BuildOrganisationSelectionNodeV1Utils getBuildOrganisationSelectionNodeV1Utils() {
        return this.buildOrganisationSelectionNodeUtils;
    }

    @Override
    protected SelectionRepository getSelectionRepository() {
        return this.selectionRepository;
    }

    @Override
    protected ObjectMapper getObjectMapper() {
        return this.objectMapper;
    }

}