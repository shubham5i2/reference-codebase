package com.ielts.cmds.rd.domain.command;

import com.ielts.cmds.application.command.BaseCommand;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DeliverROSelectionCommand extends BaseCommand<BaseHeader, OrganisationSelectionNodeV1> {

    @Builder
    public DeliverROSelectionCommand(final BaseHeader eventHeader, final OrganisationSelectionNodeV1 eventBody,
                                            final BaseEventErrors eventErrors, final BaseAudit eventAudit) {
        super(eventHeader, eventBody, eventErrors, eventAudit);
    }

}

