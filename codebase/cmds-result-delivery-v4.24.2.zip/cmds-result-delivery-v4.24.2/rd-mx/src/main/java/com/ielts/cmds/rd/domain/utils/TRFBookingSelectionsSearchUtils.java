package com.ielts.cmds.rd.domain.utils;

import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.rd.domain.command.TRFBookingSelectionsSearchCommand;
import com.ielts.cmds.rd.domain.model.out.ResultDeliveryRecognisingOrganisationAddressV1;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import com.ielts.cmds.rd.domain.model.out.SearchSortV1Item;
import com.ielts.cmds.rd.infrastructure.entity.RecognisingOrganisationAddress;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class TRFBookingSelectionsSearchUtils {

    /**
     * return ResultDeliveryRecognisingOrganisationAddressV1 list from entity list
     *
     * @param recognisingOrganisationAddresses list of entity objects
     */
    public List<ResultDeliveryRecognisingOrganisationAddressV1> setAddressesNodeV1FromEntity(List<RecognisingOrganisationAddress> recognisingOrganisationAddresses) {
        List<ResultDeliveryRecognisingOrganisationAddressV1> addressV1List = new ArrayList<>();
        for (RecognisingOrganisationAddress address : recognisingOrganisationAddresses) {
            ResultDeliveryRecognisingOrganisationAddressV1 addressV1 = new ResultDeliveryRecognisingOrganisationAddressV1(
                    address.getAddressUuid(), address.getAddressTypeUuid(), address.getAddressLine1(), address.getAddressLine2(),
                    address.getAddressLine3(), address.getAddressLine4(), address.getCity(), address.getPostalCode());

            addressV1List.add(addressV1);
        }
        return addressV1List;
    }

    /**
     * generate baseEvent headers
     *
     * @param eventName publishing event name
     * @return event headers for publishing event
     */
    public UiHeader buildHeader(TRFBookingSelectionsSearchCommand command, String eventName) {
        UiHeader baseHeader = new UiHeader();
        baseHeader.setConnectionId(command.getEventHeaders().getConnectionId());
        baseHeader.setEventName(eventName);
        baseHeader.setCorrelationId(command.getEventHeaders().getCorrelationId());
        baseHeader.setEventDateTime(command.getEventHeaders().getEventDateTime());
        baseHeader.setTransactionId(command.getEventHeaders().getTransactionId());
        baseHeader.setPartnerCode(command.getEventHeaders().getPartnerCode());
        Map<String, String> eventContext = Optional
                .ofNullable(command.getEventHeaders().getEventContext())
                .orElseGet(HashMap::new);

        eventContext.put("bookingUuid" , command.getEventBody().getCriteria().getBookingUuid().toString());
        baseHeader.setEventContext(eventContext);
        return baseHeader;
    }

    /**
     * generate base event errors
     *
     * @param message error message
     * @param errorCode
     * @return event errors for publishing event
     */
    public BaseEventErrors getBaseEventErrors(String message, String errorCode) {
        BaseEventErrors baseEventErrors;
        List<ErrorDescription> errorDescriptions = new ArrayList<>();
        ErrorDescription description = new ErrorDescription();
        if (!errorCode.isEmpty()) {
            description.setErrorCode(errorCode);
        }
        description.setMessage(message);
        errorDescriptions.add(description);
        baseEventErrors = new BaseEventErrors(errorDescriptions);
        return baseEventErrors;
    }

    /**
     * Copy contents of resultReleasedNodeV1 to new Object
     *
     * @param resultReleasedNodeV1 common node
     * @return new Object
     */
    public ResultReleasedNodeV1 getResultReleasedNodeV1Copy(ResultReleasedNodeV1 resultReleasedNodeV1) {
        ResultReleasedNodeV1 resultReleasedNodeV11 = new ResultReleasedNodeV1();
        resultReleasedNodeV11.setBookingDetails(resultReleasedNodeV1.getBookingDetails());
        resultReleasedNodeV11.setResultDetails(resultReleasedNodeV1.getResultDetails());
        resultReleasedNodeV11.setLocationDetails(resultReleasedNodeV1.getLocationDetails());
        resultReleasedNodeV11.setTtPhotoDetails(resultReleasedNodeV1.getTtPhotoDetails());
        resultReleasedNodeV11.setReferenceData(resultReleasedNodeV1.getReferenceData());
        return resultReleasedNodeV11;
    }

    /**
     * check if all sortItems are available fields
     *
     * @param sortItems           from command
     * @param availableSortFields list of available sort fields
     * @return true if unavailable list is empty
     */
    public List<SearchSortV1Item> allSortItemFieldsAvailabilityCheck(List<SearchSortV1Item> sortItems, List<String> availableSortFields) {

        return sortItems.stream()
                .filter(sortItem -> !availableSortFields.contains(sortItem.getSortBy()))
                .collect(Collectors.toList());

    }
}
