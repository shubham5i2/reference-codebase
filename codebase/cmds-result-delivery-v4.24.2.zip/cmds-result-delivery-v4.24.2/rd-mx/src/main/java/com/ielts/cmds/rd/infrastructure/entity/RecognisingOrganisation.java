package com.ielts.cmds.rd.infrastructure.entity;

import com.ielts.cmds.organisation.common.enums.MethodOfDeliveryEnum;
import com.ielts.cmds.organisation.common.enums.OrganisationStatusEnum;
import com.ielts.cmds.organisation.common.enums.VerificationStatusEnum;
import lombok.*;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import javax.persistence.*;
import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Data
@ToString(exclude = {"recognisedProducts","linkedRecognisingOrganisations","recognisingOrganisationAddresses"})
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "recognising_organisation")
public class RecognisingOrganisation implements Serializable{

    /**
     *
     */
    private static final long serialVersionUID = -8970326851956422995L;

    @Id
    @Column(name = "recognising_organisation_uuid")
    private UUID recognisingOrganisationUuid;

    @Column(name = "organisation_type_uuid")
    private UUID organisationTypeUuid;

    @Column(name = "organisation_id")
    private String organisationId;

    @Column(name = "name")
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(name = "verification_status")
    private VerificationStatusEnum verificationStatus;

    @Column(name = "partner_code")
    private String partnerCode;

    @Column(name = "method_of_delivery")
    private MethodOfDeliveryEnum methodOfDelivery;

    @Column(name = "parent_recognising_organisation_uuid")
    private UUID parentRecognisingOrganisationUuid;

    @Enumerated(EnumType.STRING)
    @Column(name = "organisation_status")
    private OrganisationStatusEnum organisationStatus;

    @Column(name = "organisation_code")
    private String organisationCode;

    @Column(name = "replaced_by_recognising_organisation_uuid")
    private UUID replacedByRecognisingOrganisationUuid;

    @Column(name = "soft_deleted")
    private Boolean softDeleted;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;

    @Column(name = "event_datetime")
    private OffsetDateTime eventDatetime;

    @Version
    @Column(name = "concurrency_version")
    private Integer concurrencyVersion;

    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(mappedBy = "recognisingOrganisation", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<RecognisedProduct> recognisedProducts = new ArrayList<>();

    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(mappedBy = "recognisingOrganisation", cascade = CascadeType.ALL)
    private List<LinkedRecognisingOrganisation> linkedRecognisingOrganisations = new ArrayList<>();

    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(mappedBy = "recognisingOrganisation", cascade = CascadeType.ALL)
    private List<RecognisingOrganisationAddress> recognisingOrganisationAddresses = new ArrayList<>();


}
