package com.ielts.cmds.rd.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.application.command.BaseCommand;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import com.ielts.cmds.rd.domain.model.out.ResultRenditionNodeV1;
import com.ielts.cmds.rd.domain.utils.BuildResultReleaseNodeV1Utils;
import com.ielts.cmds.rd.infrastructure.entity.ProductConfig;
import com.ielts.cmds.rd.infrastructure.entity.ReportDeliveryRequested;
import com.ielts.cmds.rd.infrastructure.entity.ResultsRendition;
import com.ielts.cmds.rd.infrastructure.repositories.ProductConfigRepository;
import com.ielts.cmds.rd.infrastructure.repositories.ReportDeliveryRequestedRepository;
import com.ielts.cmds.rd.infrastructure.repositories.ResultsRenditionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static com.ielts.cmds.rd.domain.RDConstants.EventType.NO_ACTION_TAKEN;
import static com.ielts.cmds.rd.domain.RDConstants.EventType.REPORT_DELIVERY_REQUESTED;

/**
 * This domain service will validate existing of ETRF template if the incoming event is TRF
 * and vice versa
 */

@Slf4j
@RequiredArgsConstructor
@Service
public class ReportGeneratedChangeAnalysisDomainService {

    private final ObjectMapper objectMapper;

    private final ApplicationEventPublisher applicationEventPublisher;

    private final ResultsRenditionRepository resultsRenditionRepository;

    private final ProductConfigRepository productConfigRepository;

    private final ReportDeliveryRequestedRepository reportDeliveryRequestedRepository;

    private final BuildResultReleaseNodeV1Utils buildResultReleaseNodeV1Utils;

    public void on(@NotNull final BaseCommand<BaseHeader, ResultReleasedNodeV1> command) throws JsonProcessingException {
        BaseEvent<BaseHeader> publishingEvent;
        List<ResultsRendition> resultsRenditionList = resultsRenditionRepository.findByResultUuidAndReportGenerationRequestedUuid
                (command.getEventBody().getResultDetails().getResultUuid(), UUID.fromString(command.getEventHeaders().getEventContext().get("reportGenerationRequestedUuid")));
        List<ProductConfig> productConfigList = productConfigRepository.findByProductUuidAndPartnerCode(command.getEventBody().getBookingDetails().getProductUuid(), command.getEventHeaders().getPartnerCode());
        publishingEvent = getEventToPublish(command, resultsRenditionList, productConfigList.size());
        applicationEventPublisher.publishEvent(publishingEvent);
    }

    public BaseEvent<BaseHeader> getEventToPublish(BaseCommand<BaseHeader, ResultReleasedNodeV1> command, List<ResultsRendition> resultsRenditionList, int productConfigSize) throws JsonProcessingException {
        BaseEvent<BaseHeader> publishingEvent;
        if (resultsRenditionList.size() == productConfigSize) {
            log.info("All required templates are generated for Booking with bookingUuid {}", command.getEventBody().getBookingDetails().getBookingUuid());
            ReportDeliveryRequested reportDeliveryRequested = getReportDeliveryRequestedEntity(command);
            //No modifications should be done to reportDeliveryRequested Entity: Refer IMOD-37131
            reportDeliveryRequestedRepository.save(reportDeliveryRequested);
            ResultReleasedNodeV1 resultReleasedNodeV1 = buildResultReleaseNodeV1Utils.buildResultReleasedNodeV1(command.getEventBody().getResultDetails().getResultUuid());
            resultReleasedNodeV1.getResultDetails().getResultRenditions().clear();
            addLatestRenditions(resultReleasedNodeV1, resultsRenditionList);
            String eventBody = objectMapper.writeValueAsString(resultReleasedNodeV1);
            publishingEvent = generateTRFDeliveryRequestedEvent(command.getEventHeaders(), eventBody);
        } else {
            log.info("All required templates are not yet generated for booking with bookingUuid {}", command.getEventBody().getBookingDetails().getBookingUuid());
            publishingEvent = noActionTaken(command.getEventHeaders(), "All Reports are not generated");
        }
        return publishingEvent;
    }

    public void addLatestRenditions(ResultReleasedNodeV1 resultReleasedNodeV1, List<ResultsRendition> resultsRenditionList) {
        List<ResultRenditionNodeV1> resultRenditionNodeV1s = convertRenditionEntityToNode(resultsRenditionList);
        resultReleasedNodeV1.getResultDetails().setResultRenditions(resultRenditionNodeV1s);
    }

    public List<ResultRenditionNodeV1> convertRenditionEntityToNode(List<ResultsRendition> resultsRenditionList) {
        List<ResultRenditionNodeV1> resultRenditionNodeV1s = new ArrayList<>();
        for (ResultsRendition rendition : resultsRenditionList) {
            ResultRenditionNodeV1 renditionNodeV1 = new ResultRenditionNodeV1();
            renditionNodeV1.setRenditionTypeUuid(rendition.getRenditionTypeUuid());
            renditionNodeV1.setRenditionFilePath(rendition.getRenditionFilePath());
            renditionNodeV1.setResultsRenditionUuid(rendition.getResultsRenditionUuid());
            renditionNodeV1.setUpdatedDatetime(rendition.getUpdatedDatetime());
            renditionNodeV1.setRenditionDescription(rendition.getRenditionDescription());
            renditionNodeV1.setRenditionFileVersion(rendition.getRenditionFileVersion());
            resultRenditionNodeV1s.add(renditionNodeV1);
        }
        return resultRenditionNodeV1s;
    }

    public ReportDeliveryRequested getReportDeliveryRequestedEntity(BaseCommand<BaseHeader, ResultReleasedNodeV1> command) {
        ReportDeliveryRequested reportDeliveryRequested = new ReportDeliveryRequested();

        reportDeliveryRequested.setBookingUuid(command.getEventBody().getBookingDetails().getBookingUuid());
        reportDeliveryRequested.setReportGenerationRequestedUuid(UUID.fromString(command.getEventHeaders().getEventContext().get("reportGenerationRequestedUuid")));
        reportDeliveryRequested.setUpdatedDatetime(OffsetDateTime.now());

        return reportDeliveryRequested;
    }

    /**
     * generate success event
     *
     * @param eventHeader header
     * @param eventBody   body
     */
    private BaseEvent<BaseHeader> generateTRFDeliveryRequestedEvent(BaseHeader eventHeader, String eventBody) {
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        baseEvent.setEventHeader(buildHeader(eventHeader, REPORT_DELIVERY_REQUESTED));
        baseEvent.setEventBody(eventBody);
        baseEvent.setEventErrors(null);
        return baseEvent;
    }

    /**
     * generate NO_ACTION_TAKEN event
     *
     * @param eventHeader header
     */
    private BaseEvent<BaseHeader> noActionTaken(BaseHeader eventHeader, String message) {
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        baseEvent.setEventHeader(buildHeader(eventHeader, NO_ACTION_TAKEN));
        baseEvent.setEventBody("NoActionTaken");
        baseEvent.setEventErrors(getBaseEventErrors(message));
        return baseEvent;
    }

    /**
     * Build event header with varied event name
     */
    public BaseHeader buildHeader(BaseHeader eventHeaders, String eventName) {
        BaseHeader baseHeader = new BaseHeader();
        baseHeader.setEventName(eventName);
        baseHeader.setTransactionId(eventHeaders.getTransactionId());
        baseHeader.setCorrelationId(eventHeaders.getCorrelationId());
        baseHeader.setEventDateTime(LocalDateTime.now());
        baseHeader.setPartnerCode(eventHeaders.getPartnerCode());
        baseHeader.setEventContext(eventHeaders.getEventContext());
        return baseHeader;
    }

    public BaseEventErrors getBaseEventErrors(String message) {
        BaseEventErrors baseEventErrors;
        List<ErrorDescription> errorDescriptions = new ArrayList<>();
        ErrorDescription errorDescription = new ErrorDescription();
        errorDescription.setMessage(message);
        errorDescription.setType(ErrorTypeEnum.VALIDATION);
        errorDescription.setTitle("Validation Failed");
        errorDescriptions.add(errorDescription);
        baseEventErrors = new BaseEventErrors(errorDescriptions);
        return baseEventErrors;
    }

    @Transactional
    public void onFailure(BaseCommand<BaseHeader, ResultReleasedNodeV1> command) {
        log.info("INT 261 is already notified for Booking with bookingUuid {}", command.getEventBody().getBookingDetails().getBookingUuid());
        BaseEvent<BaseHeader> publishingEvent = noActionTaken
                (command.getEventHeaders(), "Aborting the command as it is a duplicate business operation");
        applicationEventPublisher.publishEvent(publishingEvent);
    }
}
