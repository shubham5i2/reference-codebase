package com.ielts.cmds.rd.domain.service;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.ors.common.enums.ComponentEnum;
import com.ielts.cmds.ors.common.out.model.ComponentMinimumScoreNodeV1ORS;
import com.ielts.cmds.ors.common.out.model.MinimumScoreNodeV1ORS;
import com.ielts.cmds.ors.common.out.model.OrganisationNodeV1ORS;
import com.ielts.cmds.ors.common.out.model.SelectionNodeV1ORS;
import com.ielts.cmds.rd.application.exception.ResultDeliveryValidationException;
import com.ielts.cmds.rd.domain.command.DeliverROSelectionCommand;
import com.ielts.cmds.rd.domain.enums.SecondarySelectionEnums;
import com.ielts.cmds.rd.domain.model.SelectionAggregate;
import com.ielts.cmds.rd.domain.model.SelectionDataBody;
import com.ielts.cmds.rd.domain.model.enums.ConfirmationStatusEnum;
import com.ielts.cmds.rd.domain.model.enums.DeliveryStatusEnum;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;
import com.ielts.cmds.rd.domain.model.out.SelectionNodeV1;
import com.ielts.cmds.rd.domain.utils.BuildOrganisationSelectionNodeV1Utils;
import com.ielts.cmds.rd.domain.utils.BuildResultModelUtils;
import com.ielts.cmds.rd.domain.utils.DeliverROSelectionUtils;
import com.ielts.cmds.rd.domain.validators.selection.validation.SelectionUpdateGroupValidation;
import com.ielts.cmds.rd.infrastructure.entity.*;
import com.ielts.cmds.rd.infrastructure.event.utils.ConstraintViolationUtils;
import com.ielts.cmds.rd.infrastructure.repositories.*;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import javax.validation.constraints.NotNull;
import java.time.OffsetDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static com.ielts.cmds.rd.domain.RDConstants.EventType.*;


@Service
@Slf4j
@RequiredArgsConstructor
public class DeliverROSelectionDomainService extends AbstractDomainService {

    private final ResultRepository resultRepository;

    private final SelectionRepository selectionRepository;

    private final RecognisingOrganisationRepository recognisingOrganisationRepository;

    private final BookingRepository bookingRepository;

    private final OrganisationTypeRepository organisationTypeRepository;

    private final ResultsStatusTypeRepository resultsStatusTypeRepository;

    private final ApplicationEventPublisher applicationEventPublisher;

    private final BuildResultModelUtils resultModelUtils;

    private final DeliverROSelectionUtils deliverROSelectionUtils;

    private final Validator validator;

    private final ObjectMapper objectMapper;

    private final CMDSErrorResolver<SelectionDataBody> errorResolver;

    private final BuildOrganisationSelectionNodeV1Utils buildOrganisationSelectionNodeV1Utils;

    @Transactional
    @SneakyThrows
    public void on(@NotNull final DeliverROSelectionCommand command) throws JsonProcessingException, ResultDeliveryValidationException {

        log.debug("Received RO Selection Change Analysis event with Selection Uuid {}", command.getEventBody().getSelection().getSelectionUuid());

        BaseEvent<BaseHeader> publishingEvent;
        String publishingEventName = null;

        List<ErrorDescription> errorList = new ArrayList<>();
        BaseEventErrors errors = new BaseEventErrors(errorList);


        OrganisationSelectionNodeV1 organisationSelectionNodeV1 = deliverROSelectionUtils.generateOrganisationSelectionNode(command.getEventBody());

        boolean isPrimarySelection = Objects.isNull(command.getEventBody().getSelection().getAssociatedSelectionUuid());

        final SelectionDataBody selectionDataBody = buildSelectionBody(command);

        final Set<ConstraintViolation<SelectionDataBody>> constraintViolations = new HashSet<>();
        constraintViolations.addAll(validator.validate(selectionDataBody, SelectionUpdateGroupValidation.class));


        if (constraintViolations.isEmpty()) {

            log.info("Selection Data received with externalSelectionUuid {} is valid and has no data violations", command.getEventBody().getSelection().getExternalSelectionUuid());
            //for primary selection
            if (isPrimarySelection) {
                log.info("Selection with externalSelectionUuid {} is a primary selection", command.getEventBody().getSelection().getExternalSelectionUuid());
                Selection selection = selectionRepository.findById(command.getEventBody().getSelection().getSelectionUuid()).orElseThrow(() -> new ResultDeliveryValidationException
                        ("Deliver RO Selection Event Failed as recognising organisation is not Present", new Throwable()));

                publishingEventName = generateEventForPrimarySelection(command, organisationSelectionNodeV1, selection, selectionDataBody, errors);
                selectionRepository.save(selection);
            }
            //for secondary selection
            else {
                log.info("Selection with externalSelectionUuid {} is a secondary selection", command.getEventBody().getSelection().getExternalSelectionUuid());
                Optional<RecognisingOrganisation> optionalRecognisingOrganisation = recognisingOrganisationRepository
                        .findById(command.getEventBody().getOrganisationDetails().getRecognisingOrganisationUuid());
                RecognisingOrganisation recognisingOrganisation = optionalRecognisingOrganisation.orElseThrow(() -> new ResultDeliveryValidationException
                        ("Deliver RO  Selection Event Failed as recognising organisation is not Present", new Throwable()));

                Selection selection = deliverROSelectionUtils.getSelectionEntity(organisationSelectionNodeV1);
                List<Selection> selections = selectionRepository.findByExternalBookingUuid(selection.getExternalBookingUuid());

                Selection secondarySelection = getSecondarySelection(selections);
                if (secondarySelection != null && secondarySelection.getDeliveryStatus().equals(DeliveryStatusEnum.DELIVERY_REQUESTED)) {
                    publishingEventName = checkStatusForSecondarySelection(selections, organisationSelectionNodeV1);
                }
                // if selection is unique
                else if (deliverROSelectionUtils.isSelectionUnique(selections, selection)) {
                    publishingEventName = generateEventForSecondarySelection(organisationSelectionNodeV1, recognisingOrganisation, selection);
                }
                // if selection already exists
                else {
                    log.info("Selection with externalSelectionUuid {} already exists.", command.getEventBody().getSelection().getExternalSelectionUuid());
                    publishingEventName = RO_SELECTION_DELIVERY_REQUEST_FAILED;
                    errors = deliverROSelectionUtils.getBaseEventErrors("Duplicate Selection found");
                }
            }
        } else {
            Selection selection = selectionRepository.findById(command.getEventBody().getSelection().getSelectionUuid()).orElseThrow(() -> new ResultDeliveryValidationException
                    ("Deliver RO Selection Event Failed as recognising organisation is not Present", new Throwable()));
            publishingEventName = generateEventWhenConstraint(organisationSelectionNodeV1, selection);
            selectionRepository.save(selection);
            CMDSErrorResponse eventErrors = errorResolver.populatErrorResponse(constraintViolations, ORGANISATION_SELECTION_DELIVERY_STATUS_CHANGED);
            errors = new BaseEventErrors(eventErrors.getErrorList());
        }
        publishingEvent = buildPublishingEvent(command, organisationSelectionNodeV1, publishingEventName, errors);
        applicationEventPublisher.publishEvent(publishingEvent);
    }

    private String generateEventWhenConstraint(OrganisationSelectionNodeV1 organisationSelectionNodeV1, Selection selection) {
        String publishingEventName;

        organisationSelectionNodeV1.getSelection().setDeliveryStatus(DeliveryStatusEnum.UNDELIVERED);
        organisationSelectionNodeV1.getSelection().setDeliveryStatusChangedDatetime(OffsetDateTime.now());
        selection.setDeliveryStatus(DeliveryStatusEnum.UNDELIVERED);
        selection.setDeliveryStatusChangedDatetime(OffsetDateTime.now());
        publishingEventName = ORGANISATION_SELECTION_DELIVERY_STATUS_CHANGED;

        return publishingEventName;
    }

    private Selection getSecondarySelection(List<Selection> selections) {
        for (Selection secondarySelection : selections) {
            if (Objects.nonNull(secondarySelection.getAssociatedSelectionUuid())) {
                return secondarySelection;
            }
        }
        return null;
    }

    private String checkStatusForSecondarySelection(List<Selection> selections, OrganisationSelectionNodeV1 organisationSelectionNodeV1) {
        for (Selection secondarySelection : selections) {
            if (Objects.nonNull(secondarySelection.getAssociatedSelectionUuid())) {
                Optional<Selection> optionalSelection = selectionRepository.findById(secondarySelection.getSelectionUuid());
                if (optionalSelection.isPresent()) {
                    Selection selection = optionalSelection.get();
                    organisationSelectionNodeV1.getSelection().setDeliveryStatus(DeliveryStatusEnum.REDELIVERY_REQUESTED);
                    organisationSelectionNodeV1.getSelection().setDeliveryStatusChangedDatetime(OffsetDateTime.now());
                    selection.setDeliveryStatus(DeliveryStatusEnum.REDELIVERY_REQUESTED);
                    selection.setDeliveryStatusChangedDatetime(OffsetDateTime.now());
                    selectionRepository.save(selection);
                }
            }
        }
        return ORGANISATION_SELECTION_DELIVERY_STATUS_CHANGED;
    }

    /**
     * set eventHeader and eventBody
     * check for secondary selection and set flag true
     *
     * @return event
     */
    public BaseEvent<BaseHeader> buildPublishingEvent(DeliverROSelectionCommand command, OrganisationSelectionNodeV1 organisationSelectionNodeV1, String eventName, BaseEventErrors errors) throws JsonProcessingException {
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        baseEvent.setEventHeader(deliverROSelectionUtils.buildHeader(command.getEventHeaders(), eventName));
        //Set Secondary Selection Flag
        if (Objects.nonNull(organisationSelectionNodeV1.getSelection().getAssociatedSelectionUuid())) {
            baseEvent.getEventHeader().getEventContext().put(SecondarySelectionEnums.SECONDARY_SELECTION.getKey(), SecondarySelectionEnums.SECONDARY_SELECTION.getValue());
        }
        String body = objectMapper.writeValueAsString(organisationSelectionNodeV1);
        if (isErrorTypeValidationOrError(errors)) {
            body = getEventBodyForSelectionEvents(command.getEventBody().getSelection().getExternalSelectionUuid());
        }
        baseEvent.setEventBody(body);
        baseEvent.setEventErrors(errors);
        return baseEvent;
    }

    private String generateEventForSecondarySelection(OrganisationSelectionNodeV1 organisationSelectionNodeV1, RecognisingOrganisation recognisingOrganisation, Selection selection) {
        //If secondary selection eligible
        String publishingEventName;
        if (deliverROSelectionUtils.isSecondarySelectionEligible(recognisingOrganisation)) {
            log.info("Secondary selection with externalSelectionUuid {},is eligible for delivery as no business violations are found.", organisationSelectionNodeV1.getSelection().getExternalSelectionUuid());
            organisationSelectionNodeV1.getSelection().setDeliveryStatus(DeliveryStatusEnum.DELIVERY_PENDING);
            selection.setDeliveryStatus(DeliveryStatusEnum.DELIVERY_PENDING);
            organisationSelectionNodeV1.getSelection().setDeliveryStatusChangedDatetime(OffsetDateTime.now());
            selection.setDeliveryStatusChangedDatetime(OffsetDateTime.now());
            publishingEventName = RECOGNISING_ORGANISATION_RESULTS_DELIVERY_REQUESTED;
        }
        //If secondary selection not eligible
        else {
            log.info("Secondary selection with externalSelectionUuid {},is not eligible for delivery as business violations are found.", organisationSelectionNodeV1.getSelection().getExternalSelectionUuid());
            organisationSelectionNodeV1.getSelection().setDeliveryStatus(DeliveryStatusEnum.UNDELIVERED);
            selection.setDeliveryStatus(DeliveryStatusEnum.UNDELIVERED);
            organisationSelectionNodeV1.getSelection().setDeliveryStatusChangedDatetime(OffsetDateTime.now());
            selection.setDeliveryStatusChangedDatetime(OffsetDateTime.now());
            publishingEventName = ORGANISATION_SELECTION_DELIVERY_STATUS_CHANGED;
        }
        selectionRepository.save(selection);
        return publishingEventName;
    }

    private String generateEventForPrimarySelection(DeliverROSelectionCommand command, OrganisationSelectionNodeV1 organisationSelectionNodeV1,
                                                    Selection selection, SelectionDataBody selectionDataBody, BaseEventErrors errors) throws ResultDeliveryValidationException {


        selection = deliverROSelectionUtils.setSelectionFromCommand(command, selection);
        String publishingEventName;

        Optional<Result> optionalResult = resultRepository.findByBookingUuid(command.getEventBody().getBookingDetails().getBookingUuid());

        //if result present in db
        if (optionalResult.isPresent()) {
            log.info("Result is present in db for the booking with externalBookingUuid {} ", command.getEventBody().getBookingDetails().getExternalBookingUuid());
            //validate using selection aggregate
            Set<ConstraintViolation<SelectionAggregate>> violations = validateSelection(command);

            Optional<ResultsStatusType> optionalResultsStatusType = resultsStatusTypeRepository
                    .findById(optionalResult.get().getResultsStatusTypeUuid());
            ResultsStatusType resultsStatusType = optionalResultsStatusType.orElseThrow(() -> new ResultDeliveryValidationException
                    ("Deliver RO Selection Event Failed as Result Status data is not Present", new Throwable()));
            //if primary Selection eligible
            if (violations.isEmpty() && !isOrganisationTypeVO(selection) && resultsStatusType.getResultStatusCode().equals(RELEASED)) {
                log.info("Primary selection with externalSelectionUuid {},is eligible for delivery as no business violations are found.", command.getEventBody().getSelection().getExternalSelectionUuid());
                organisationSelectionNodeV1.getSelection().setDeliveryStatus(DeliveryStatusEnum.DELIVERY_PENDING);
                organisationSelectionNodeV1.getSelection().setDeliveryStatusChangedDatetime(OffsetDateTime.now());
                selection.setDeliveryStatus(DeliveryStatusEnum.DELIVERY_PENDING);
                selection.setDeliveryStatusChangedDatetime(OffsetDateTime.now());
                publishingEventName = RECOGNISING_ORGANISATION_RESULTS_DELIVERY_REQUESTED;

            }
            //if primary Selection not eligible
            else {
                log.info("Primary selection with externalSelectionUuid {} is not eligible for delivery as business violations are found.", command.getEventBody().getSelection().getExternalSelectionUuid());
                List<ConstraintViolation<SelectionDataBody>> selectionDataBodyCompatibleViolation
                        = convertToSelectionDataBodyViolations(selectionDataBody, violations);
                Set<ConstraintViolation<SelectionDataBody>> violationSet = new HashSet<>(selectionDataBodyCompatibleViolation);
                CMDSErrorResponse eventErrors = errorResolver.populatErrorResponse(violationSet, ORGANISATION_SELECTION_DELIVERY_STATUS_CHANGED);
                errors.getErrorList().addAll(eventErrors.getErrorList());
                organisationSelectionNodeV1.getSelection().setDeliveryStatus(DeliveryStatusEnum.UNDELIVERED);
                organisationSelectionNodeV1.getSelection().setDeliveryStatusChangedDatetime(OffsetDateTime.now());
                selection.setDeliveryStatus(DeliveryStatusEnum.UNDELIVERED);
                selection.setDeliveryStatusChangedDatetime(OffsetDateTime.now());
                publishingEventName = ORGANISATION_SELECTION_DELIVERY_STATUS_CHANGED;
            }
            if (command.getEventBody().getSelection().getDeliveryStatus().equals(DeliveryStatusEnum.REDELIVERY_REQUESTED) && violations.isEmpty()) {
                log.info("Selection with externalSelectionUuid {}, DeliveryStatus is set to REDELIVERY_REQUESTED", command.getEventBody().getSelection().getExternalSelectionUuid());
                organisationSelectionNodeV1.getSelection().setDeliveryStatus(DeliveryStatusEnum.REDELIVERY_REQUESTED);
                organisationSelectionNodeV1.getSelection().setDeliveryStatusChangedDatetime(OffsetDateTime.now());
                selection.setDeliveryStatus(DeliveryStatusEnum.REDELIVERY_REQUESTED);
                selection.setDeliveryStatusChangedDatetime(OffsetDateTime.now());
                publishingEventName = ORGANISATION_SELECTION_DELIVERY_STATUS_CHANGED;
            }
        }
        //if result not found in db
        else {
            log.info("Selection with externalSelectionUuid {} is undelivered as Result is not present in db for the booking with externalBookingUuid {} ", command.getEventBody().getSelection().getExternalSelectionUuid(), command.getEventBody().getBookingDetails().getExternalBookingUuid());
            organisationSelectionNodeV1.getSelection().setDeliveryStatus(DeliveryStatusEnum.UNDELIVERED);
            organisationSelectionNodeV1.getSelection().setDeliveryStatusChangedDatetime(OffsetDateTime.now());
            selection.setDeliveryStatus(DeliveryStatusEnum.UNDELIVERED);
            selection.setDeliveryStatusChangedDatetime(OffsetDateTime.now());
            publishingEventName = ORGANISATION_SELECTION_DELIVERY_STATUS_CHANGED;
        }


        return publishingEventName;
    }

    /**
     * validate primary selection using selection aggregate common methods
     *
     * @return violations if aby
     */
    public Set<ConstraintViolation<SelectionAggregate>> validateSelection(DeliverROSelectionCommand command) throws ResultDeliveryValidationException {
        UUID bookingUuid = command.getEventBody().getBookingDetails().getBookingUuid();

        Optional<Result> optionalResult = resultRepository.findByBookingUuid(bookingUuid);

        Optional<Booking> optionalBooking = bookingRepository.findById(bookingUuid);

        //get Selection from database
        Optional<Selection> optionalSelection = selectionRepository
                .findById(command.getEventBody().getSelection().getSelectionUuid());

        Selection selection = optionalSelection.orElseThrow(() -> new ResultDeliveryValidationException
                ("RO Selection Change Analysis Event Failed as  selection is not Present", new Throwable()));

        //get optional Recognising Organisation for selection Aggregate
        Optional<RecognisingOrganisation> optionalRO = recognisingOrganisationRepository
                .findById(selection.getRecognisingOrganisationUuid());
        RecognisingOrganisation recognisingOrganisation = optionalRO.orElseThrow(() -> new ResultDeliveryValidationException
                ("RO Selection Change Analysis Event Failed as  recognising organisation is not Present", new Throwable()));

        //get optional Organisation Type for selection Aggregate
        Optional<OrganisationType> optionalOrganisationType = organisationTypeRepository
                .findById(recognisingOrganisation.getOrganisationTypeUuid());

        //selection Aggregate validations
        SelectionAggregate selectionAggregate = getSelectionAggregate(optionalResult, optionalBooking, selection, optionalRO, optionalOrganisationType);

        return selectionAggregate.canSelectionBeDeliveredToResultPortal();
    }

    /**
     * returns selection aggregate object
     *
     * @param optionalResult           optional
     * @param optionalBooking          optional
     * @param selection                nonOptional
     * @param recognisingOrganisation  optional
     * @param optionalOrganisationType optional
     */
    private SelectionAggregate getSelectionAggregate(Optional<Result> optionalResult, Optional<Booking> optionalBooking, Selection selection, Optional<RecognisingOrganisation> recognisingOrganisation, Optional<OrganisationType> optionalOrganisationType) {
        return SelectionAggregate.builder()
                .selection(selection)
                .result(resultModelUtils.populateResultModelData(optionalResult))
                .booking(optionalBooking.orElse(null))
                .organisation(recognisingOrganisation.orElse(null))
                .organisationType(optionalOrganisationType.orElse(null))
                .command(null).build();
    }

    private boolean isOrganisationTypeVO(Selection selection) throws ResultDeliveryValidationException {
        //get optional Recognising Organisation for selection Aggregate
        Optional<RecognisingOrganisation> optionalRO = recognisingOrganisationRepository
                .findById(selection.getRecognisingOrganisationUuid());
        RecognisingOrganisation recognisingOrganisation = optionalRO.orElseThrow(() -> new ResultDeliveryValidationException
                ("RO Selection Change Analysis Event Failed as  recognising organisation is not Present", new Throwable()));

        //get optional Organisation Type for selection Aggregate
        Optional<OrganisationType> optionalOrganisationType = organisationTypeRepository
                .findById(recognisingOrganisation.getOrganisationTypeUuid());

        return optionalOrganisationType.isPresent() && optionalOrganisationType.get().getOrganisationTypeName().equals("VO");
    }

    private SelectionDataBody buildSelectionBody(DeliverROSelectionCommand command) {
        Optional<Selection> selection = selectionRepository.findByExternalSelectionUuid(command.getEventBody().getSelection().getExternalSelectionUuid());
        Optional<Booking> booking = bookingRepository.findByExternalBookingUuid(command.getEventBody().getBookingDetails().getExternalBookingUuid());
        Optional<RecognisingOrganisation> recognisingOrganisation = Optional.empty();

        if (Objects.nonNull(command.getEventBody().getOrganisationDetails().getRecognisingOrganisationUuid())) {
            recognisingOrganisation = recognisingOrganisationRepository
                    .findById(command.getEventBody().getOrganisationDetails().getRecognisingOrganisationUuid());
        }

        SelectionDataBody selectionDataBody = new SelectionDataBody();
        selectionDataBody.setEventDateTime(command.getEventHeaders().getEventDateTime());
        selectionDataBody.setSelectionEntity(selection.orElse(null));
        selectionDataBody.setBookingEntity(booking.orElse(null));
        selectionDataBody.setOrganisationEntity(recognisingOrganisation.orElse(null));
        selectionDataBody.setExternalBookingUuid(command.getEventBody().getBookingDetails().getExternalBookingUuid());
        selectionDataBody.setSelection(getSelection(command));
        selectionDataBody.setExternalBookingReference(command.getEventBody().getBookingDetails().getExternalBookingReference());

        return selectionDataBody;
    }

    public SelectionNodeV1ORS getSelection(DeliverROSelectionCommand command){

        SelectionNodeV1ORS selectionNodeV1 = getSelectionNodeV1Ors(command.getEventBody().getSelection());

        OrganisationNodeV1ORS organisationNodeV1 = new OrganisationNodeV1ORS();
        organisationNodeV1.setOrganisationUuid(command.getEventBody().getOrganisationDetails().getRecognisingOrganisationUuid());
        selectionNodeV1.setOrganisation(organisationNodeV1);

        MinimumScoreNodeV1ORS minimumScoreNodeV1 = new MinimumScoreNodeV1ORS();
        minimumScoreNodeV1.setOverallMinimumScore(command.getEventBody().getSelection().getOverallMinimumScore());
        if (!Objects.isNull(command.getEventBody().getSelection().getMinimumScores())) {
            List<ComponentMinimumScoreNodeV1ORS> minimumScores = command.getEventBody().getSelection().getMinimumScores().stream().map(e -> {
                ComponentMinimumScoreNodeV1ORS componentMinimumScoreNodeV1 = new ComponentMinimumScoreNodeV1ORS();
                componentMinimumScoreNodeV1.setComponent(ComponentEnum.valueOf(e.getComponent().toString()));
                componentMinimumScoreNodeV1.setMinimumScore(e.getMinimumScoreValue());
                return componentMinimumScoreNodeV1;
            }).collect(Collectors.toList());

            minimumScoreNodeV1.setComponentMinimumScores(minimumScores);
        }
        selectionNodeV1.setMinimumScore(minimumScoreNodeV1);
        if (command.getEventBody().getSelection().getConfirmationStatus().equals(ConfirmationStatusEnum.CONFIRMED)) {
            selectionNodeV1.setMinimumScore(null);
        }

        return selectionNodeV1;
    }

    private SelectionNodeV1ORS getSelectionNodeV1Ors(SelectionNodeV1 selectionNodeV1) {

        SelectionNodeV1ORS selectionNodeV1ORS = new SelectionNodeV1ORS();

        selectionNodeV1ORS.setSelectionUuid(selectionNodeV1.getSelectionUuid());
        selectionNodeV1ORS.setExternalSelectionUuid(selectionNodeV1.getExternalSelectionUuid());
        selectionNodeV1ORS.setConfirmationStatus(com.ielts.cmds.ors.common.enums.ConfirmationStatusEnum.valueOf(selectionNodeV1.getConfirmationStatus().toString()));
        selectionNodeV1ORS.setConfirmationStatusChangedDateTime(selectionNodeV1.getConfirmationStatusChangedDatetime());
        selectionNodeV1ORS.setCaseNumber(selectionNodeV1.getCaseNumber());
        selectionNodeV1ORS.setPersonDepartment(selectionNodeV1.getPersonDepartment());

        return selectionNodeV1ORS;
    }


    private List<ConstraintViolation<SelectionDataBody>> convertToSelectionDataBodyViolations(final SelectionDataBody selectionDataBody, Set<ConstraintViolation<SelectionAggregate>> violations) {
        return violations.stream()
                .map(aggregateViolation ->
                        ConstraintViolationUtils.createNewConstraintViolation(SelectionDataBody.class,
                                selectionDataBody,
                                aggregateViolation.getMessage(),
                                aggregateViolation.getPropertyPath().toString()))
                .collect(Collectors.toList());
    }

    @Override
    protected ObjectMapper getObjectMapper() {
        return this.objectMapper;
    }

    @Override
    protected BuildOrganisationSelectionNodeV1Utils getBuildOrganisationSelectionNodeV1Utils() {
        return this.buildOrganisationSelectionNodeV1Utils;
    }

    @Override
    protected SelectionRepository getSelectionRepository() {
        return this.selectionRepository;
    }


}