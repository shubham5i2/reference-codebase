package com.ielts.cmds.rd.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.application.exception.ResultDeliveryValidationException;
import com.ielts.cmds.rd.domain.command.ROSelectionCommand;
import com.ielts.cmds.rd.domain.model.SelectionAggregate;
import com.ielts.cmds.rd.domain.model.SelectionDataBody;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;
import com.ielts.cmds.rd.domain.utils.BuildOrganisationSelectionNodeV1Utils;
import com.ielts.cmds.rd.domain.utils.BuildResultModelUtils;
import com.ielts.cmds.rd.domain.utils.DomainEventsPublisher;
import com.ielts.cmds.rd.domain.validators.selection.SelectionValidator;
import com.ielts.cmds.rd.infrastructure.entity.*;
import com.ielts.cmds.rd.infrastructure.event.utils.ConstraintViolationUtils;
import com.ielts.cmds.rd.infrastructure.repositories.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.ConstraintViolation;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import static com.ielts.cmds.rd.domain.RDConstants.EventType.RECEIVING_ORGANISATION_SELECTION_CHANGED;
import static java.time.ZoneOffset.UTC;

/**
 * @author arorap
 */

@Slf4j
@Service
@RequiredArgsConstructor
public class OrganizationSelectionDomainService extends AbstractDomainService {

    private final SelectionRepository selectionRepository;

    private final CMDSErrorResolver<SelectionDataBody> errorResolver;

    private final SelectionValidator selectionValidator;

    private final BookingRepository bookingRepository;

    private final RecognisingOrganisationRepository recognisingOrganisationRepository;

    private final ResultRepository resultRepository;

    private final ObjectMapper objectMapper;

    private final OrganisationTypeRepository organisationTypeRepository;

    private final MinimumScoreRepository minimumScoreRepository;

    private final ResultsStatusTypeRepository resultsStatusTypeRepository;

    private final BuildResultModelUtils resultModelUtils;

    private final BuildOrganisationSelectionNodeV1Utils buildOrganisationSelectionNodeV1Utils;

    private final DomainEventsPublisher domainEventsPublisher;

    @Transactional
    public void onCommand(final ROSelectionCommand command) throws JsonProcessingException, ResultDeliveryValidationException {

        log.info("Received organisation selection event body with external selection uuid as {}", command.getEventBody().getSelection().getExternalSelectionUuid());

        //In some cases we need to throw and exception for reprocessing and if failed then go to DLQ
        //In other cases we need to check for validation
        List<BaseEvent<BaseHeader>> eventList = new ArrayList<>();
        Optional<Selection> optionalSelection = selectionRepository.findByExternalSelectionUuid(command.getEventBody().getSelection().getExternalSelectionUuid());
        selectionValidation(command, optionalSelection);
        //Build Selection Aggregate from command
        final SelectionAggregate selectionAggregate = buildSelectionAggregate(command);

        final SelectionDataBody selectionDataBody = buildSelectionBody(command);

        //Call the selection validator to validate the selection before proceeding for create or update
        final Set<ConstraintViolation<SelectionDataBody>> violations = new HashSet<>(selectionValidator.validate(selectionDataBody));
        if (violations.isEmpty()) {
            //If there are no data violation the call the aggregate to check for business rule violation
            log.info("Received Valid Selection Data. No SelectionDataBody violations for selection with externalSelectionUuid {}", command.getEventBody().getSelection().getExternalSelectionUuid());
            final Set<ConstraintViolation<SelectionAggregate>> aggregateViolations = selectionAggregate.canUpdateSelection();
            List<ConstraintViolation<SelectionDataBody>> selectionDataBodyCompatibleViolation
                    = convertToSelectionDataBodyViolations(selectionDataBody, aggregateViolations);

            //Add all business violation to root violations list
            violations.addAll(selectionDataBodyCompatibleViolation);
        }

        if (violations.isEmpty()) {
            log.info("No Business rule violations found for selection with externalSelectionUuid {} ", command.getEventBody().getSelection().getExternalSelectionUuid());
            //If there are no violations then proceed with the update
            Selection selectionEntity = selectionAggregate.updateSelection();
            selectionRepository.save(selectionEntity);

            log.info("Create/Update Selection request for ExternalSelectionUuid: {} and TransactionId: {} is processed and saved to db successfully", command.getEventBody().getSelection().getExternalSelectionUuid(), command.getEventHeaders().getTransactionId());

            OrganisationSelectionNodeV1 selectionNodeV1 = buildOrganisationSelectionNodeV1Utils.buildOrganisationSelectionNodeV1Utils(selectionEntity.getSelectionUuid());

            BaseEvent<BaseHeader> baseEvent = populateBaseEvent(command, selectionNodeV1, RECEIVING_ORGANISATION_SELECTION_CHANGED);
            eventList.add(baseEvent);
        } else {
            log.info("Data violations or Business violations found for selection create/update with TransactionId {}", command.getEventHeaders().getTransactionId());
            //If there are violations found during validation
            // then produce event with proper event error list
            final Set<ConstraintViolation<SelectionAggregate>> aggregateViolations = selectionAggregate.canUpdateSelection();
            List<ConstraintViolation<SelectionDataBody>> selectionDataBodyCompatibleViolation
                    = convertToSelectionDataBodyViolations(selectionDataBody, aggregateViolations);

            //Add all business violation to root violations list
            violations.addAll(selectionDataBodyCompatibleViolation);
            BaseEvent<BaseHeader> baseEvent = buildErrorDomainEvent(command.getEventHeaders(), RECEIVING_ORGANISATION_SELECTION_CHANGED, violations, command);
            eventList.add(baseEvent);
        }

        domainEventsPublisher.baseEventListPublisher(eventList);
    }

    //This method is used to check the eventDatetime  of the event received and compare with previous eventDatetime from database
    // to capture the latest data
    private void selectionValidation(final ROSelectionCommand command, final Optional<Selection> optionalSelection) throws ResultDeliveryValidationException {
        if (optionalSelection.isPresent()) {
            LocalDateTime localDateTime = optionalSelection.get().getEventDatetime().toLocalDateTime();
            if (!(command.getEventHeaders().getEventDateTime().isAfter(localDateTime))) {
                throw new ResultDeliveryValidationException(String.format("Received Event Date time is before this : %s  " + "for this Booking UUID : %s"
                        , localDateTime, command.getEventBody().getSelection().getExternalSelectionUuid()), new Throwable());
            }
        }

    }

    private List<ConstraintViolation<SelectionDataBody>> convertToSelectionDataBodyViolations(final SelectionDataBody selectionDataBody, Set<ConstraintViolation<SelectionAggregate>> aggregateViolations) {
        return aggregateViolations.stream()
                .map(aggregateConstraintViolation ->
                        ConstraintViolationUtils.createNewConstraintViolation(SelectionDataBody.class,
                                selectionDataBody,
                                aggregateConstraintViolation.getMessage(),
                                aggregateConstraintViolation.getPropertyPath().toString()))
                .collect(Collectors.toList());
    }

    private SelectionDataBody buildSelectionBody(ROSelectionCommand command) {
        Optional<Selection> selection = selectionRepository.findByExternalSelectionUuid(command.getEventBody().getSelection().getExternalSelectionUuid());
        Optional<Booking> booking = bookingRepository.findByExternalBookingUuid(command.getEventBody().getExternalBookingUuid());
        Optional<RecognisingOrganisation> recognisingOrganisation = Optional.empty();
        if (Objects.nonNull(command.getEventBody().getSelection().getOrganisation().getOrganisationUuid())) {
            recognisingOrganisation = recognisingOrganisationRepository
                    .findById(command.getEventBody().getSelection().getOrganisation().getOrganisationUuid());
        }

        SelectionDataBody selectionDataBody = new SelectionDataBody();
        selectionDataBody.setEventDateTime(command.getEventHeaders().getEventDateTime());
        selectionDataBody.setSelectionEntity(selection.orElse(null));
        selectionDataBody.setBookingEntity(booking.orElse(null));
        selectionDataBody.setOrganisationEntity(recognisingOrganisation.orElse(null));
        selectionDataBody.setExternalBookingUuid(command.getEventBody().getExternalBookingUuid());
        selectionDataBody.setSelection(command.getEventBody().getSelection());
        selectionDataBody.setExternalBookingReference(command.getEventBody().getExternalBookingReference());
        return selectionDataBody;
    }


    public BaseEvent<BaseHeader> buildErrorDomainEvent(final BaseHeader baseHeader, final String rejectedEventName,
                                                       final Set<ConstraintViolation<SelectionDataBody>> violation, final ROSelectionCommand command) throws JsonProcessingException {
        String datePattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
        OffsetDateTime localDT = OffsetDateTime.parse(baseHeader.getEventDateTimeAsString());
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(datePattern);
        baseHeader.setEventDateTime(
                LocalDateTime.ofInstant(Instant.parse(dateTimeFormatter.format(localDT)), ZoneOffset.UTC));
        baseHeader.setEventName(rejectedEventName);
        CMDSErrorResponse eventErrors = errorResolver.populatErrorResponse(violation, rejectedEventName);
        BaseEventErrors baseEventErrors = new BaseEventErrors(eventErrors.getErrorList());
        String eventBody = getEventBodyForSelectionEvents(command.getEventBody().getSelection().getExternalSelectionUuid());
        return new BaseEvent<>(baseHeader, eventBody, baseEventErrors, command.getAudit());
    }

    private SelectionAggregate buildSelectionAggregate(final ROSelectionCommand command) {
        Optional<Selection> selection = selectionRepository.findByExternalSelectionUuid(command.getEventBody().getSelection().getExternalSelectionUuid());
        Optional<Booking> booking = bookingRepository.findByExternalBookingUuid(command.getEventBody().getExternalBookingUuid());
        Optional<RecognisingOrganisation> recognisingOrganisation = Optional.empty();
        if (Objects.nonNull(command.getEventBody().getSelection().getOrganisation().getOrganisationUuid())) {
            recognisingOrganisation = recognisingOrganisationRepository
                    .findById(command.getEventBody().getSelection().getOrganisation().getOrganisationUuid());
        }
        if (selection.isPresent()) {
            List<MinimumScore> minimumScores = selection.get().getMinimumScores();
            minimumScores.forEach(e -> minimumScoreRepository.deleteById(e.getMinimumScoreUuid()));
        }

        Optional<OrganisationType> organisationType = Optional.empty();
        if (recognisingOrganisation.isPresent()) {
            organisationType = organisationTypeRepository.findById(recognisingOrganisation.get().getOrganisationTypeUuid());
        }
        Optional<Result> result = Optional.empty();
        if (booking.isPresent()) {
            result = resultRepository.findByBookingUuid(booking.get().getBookingUuid());
        }
        //Build Selection Aggregate based on the available data
        return SelectionAggregate.builder()
                .command(command)
                .selection(selection.orElse(null))
                .booking(booking.orElse(null))
                .organisation(recognisingOrganisation.orElse(null))
                .result(resultModelUtils.populateResultModelData(result))
                .organisationType(organisationType.orElse(null))
                .build();
    }


    public BaseEvent<BaseHeader> populateBaseEvent(final ROSelectionCommand roSelectionCommand,
                                                   final OrganisationSelectionNodeV1 selectionNodeV1, String eventName) throws JsonProcessingException {
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        BaseHeader baseHeader = buildBaseHeader(roSelectionCommand.getEventHeaders(), roSelectionCommand);
        baseHeader.setEventName(eventName);
        baseEvent.setEventHeader(baseHeader);
        baseEvent.setEventBody(objectMapper.writeValueAsString(selectionNodeV1));
        baseEvent.setEventErrors(null);
        baseEvent.setAudit(roSelectionCommand.getAudit());
        return baseEvent;

    }


    public BaseHeader buildBaseHeader(BaseHeader eventHeaders, ROSelectionCommand roSelectionCommand) {
        BaseHeader baseHeader = new BaseHeader();
        baseHeader.setEventDateTime(LocalDateTime.now(UTC));
        baseHeader.setCorrelationId(eventHeaders.getCorrelationId());
        Map<String, String> eventContext = Optional
                .ofNullable(roSelectionCommand.getEventHeaders().getEventContext())
                .orElseGet(HashMap::new);

        eventContext.put("externalSelectionUuid", roSelectionCommand.getEventBody().getSelection().getExternalSelectionUuid().toString());
        baseHeader.setEventContext(eventContext);
        baseHeader.setTransactionId(eventHeaders.getTransactionId());
        baseHeader.setCallbackURL(eventHeaders.getCallbackURL());
        baseHeader.setEventDiscriminator(eventHeaders.getEventDiscriminator());
        baseHeader.setPartnerCode(eventHeaders.getPartnerCode());
        baseHeader.setXaccessToken(eventHeaders.getXaccessToken());
        baseHeader.setCallbackURL(eventHeaders.getCallbackURL());
        baseHeader.setEventDateTimeAsString(eventHeaders.getEventDateTimeAsString());
        return baseHeader;
    }

    @Override
    protected ObjectMapper getObjectMapper() {
        return this.objectMapper;
    }

    @Override
    protected BuildOrganisationSelectionNodeV1Utils getBuildOrganisationSelectionNodeV1Utils() {
        return this.buildOrganisationSelectionNodeV1Utils;
    }

    @Override
    protected SelectionRepository getSelectionRepository() {
        return this.selectionRepository;
    }



}
