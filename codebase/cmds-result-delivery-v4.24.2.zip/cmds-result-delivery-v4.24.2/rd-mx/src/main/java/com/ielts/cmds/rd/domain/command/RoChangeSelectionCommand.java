package com.ielts.cmds.rd.domain.command;

import com.ielts.cmds.application.command.BaseCommand;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class RoChangeSelectionCommand extends BaseCommand<BaseHeader, RoChangedEventV1> {

    @Builder
    public RoChangeSelectionCommand(final BaseHeader eventHeader, final RoChangedEventV1 eventBody,
                                    final BaseEventErrors eventErrors, final BaseAudit eventAudit) {
        super(eventHeader, eventBody, eventErrors, eventAudit);
    }

}
