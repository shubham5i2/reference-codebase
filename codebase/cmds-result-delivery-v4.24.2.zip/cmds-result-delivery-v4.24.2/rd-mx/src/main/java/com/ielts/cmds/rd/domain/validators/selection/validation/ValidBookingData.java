package com.ielts.cmds.rd.domain.validators.selection.validation;

import com.ielts.cmds.rd.domain.validators.selection.SelectionBookingValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Constraint(validatedBy = {SelectionBookingValidator.class})
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
public @interface ValidBookingData {

    String message() default "{cmds.invalid.externalBookingUuid}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
