package com.ielts.cmds.rd.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.application.exception.ResultDeliveryRuntimeException;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.domain.command.ROSelectionCommand;
import com.ielts.cmds.rd.domain.command.ROSelectionWithdrawCommand;
import com.ielts.cmds.rd.domain.model.SelectionAggregate;
import com.ielts.cmds.rd.domain.model.enums.ConfirmationStatusEnum;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;
import com.ielts.cmds.rd.domain.utils.BuildOrganisationSelectionNodeV1Utils;
import com.ielts.cmds.rd.infrastructure.entity.Booking;
import com.ielts.cmds.rd.infrastructure.entity.Selection;
import com.ielts.cmds.rd.infrastructure.repositories.BookingRepository;
import com.ielts.cmds.rd.infrastructure.repositories.SelectionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.ConstraintViolation;
import javax.validation.constraints.NotNull;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static com.ielts.cmds.rd.domain.RDConstants.GenericConstants.EXTERNAL_SELECTION_UUID;


@Service
@Slf4j
@RequiredArgsConstructor
public class OrganisationSelectionWithdrawnDomainService extends AbstractDomainService {

    private final ObjectMapper objectMapper;

    private final ApplicationEventPublisher applicationEventPublisher;

    private final SelectionRepository selectionRepository;

    private final BookingRepository bookingRepository;

    private final CMDSErrorResolver<SelectionAggregate> errorResolver;

    private final BuildOrganisationSelectionNodeV1Utils buildOrganisationSelectionNodeV1Utils;

    @Transactional
    public void on(@NotNull final ROSelectionWithdrawCommand command) throws JsonProcessingException {

        BaseEvent<BaseHeader> event = new BaseEvent<>();
        String eventBody;
        Optional<OrganisationSelectionNodeV1> selectionNodeV1;
        try {

            Map<String, String> eventContext = command.getEventHeaders().getEventContext();

            UUID externalSelectionUuid = UUID.fromString(eventContext.get("externalSelectionUuid"));

            log.info("Received {} event with transaction id {} and externalSelectionUuid {}", command.getEventHeaders().getEventName(), command.getEventHeaders().getTransactionId(), externalSelectionUuid);

            eventContext.put("eventDateTime", command.getEventHeaders().getEventDateTimeAsString());

            Optional<Selection> optionalSelection = selectionRepository.findByExternalSelectionUuid(externalSelectionUuid);

            final SelectionAggregate selectionAggregate = buildSelectionAggregate(command);

            //Call the selection validator to validate the selection before proceeding for withdrawal
            final Set<ConstraintViolation<SelectionAggregate>> violations = new HashSet<>(selectionAggregate
                    .canWithdrawSelection(optionalSelection, command));

            if (violations.isEmpty() && optionalSelection.isPresent()) {
                Selection selection = optionalSelection.get();
                if (selection.getConfirmationStatus() != ConfirmationStatusEnum.WITHDRAWN) {
                    withdrawSelection(selection, command);
                }
                selectionNodeV1 = Optional.of(buildOrganisationSelectionNodeV1Utils.buildOrganisationSelectionNodeV1Utils(selection.getSelectionUuid()));
                eventBody = objectMapper.writeValueAsString(selectionNodeV1);
                event = populateBaseEvent(eventBody, command);
            } else {
                //If there are violations found during validation
                // then produce event with proper event error list
                event = buildErrorDomainEvent(command,
                        RDConstants.EventType.ORGANISATION_SELECTION_WITHDRAWN,
                        violations);
            }

        } catch (final JsonProcessingException e) {
            log.error("ROSelectionWithdrawCommand execution failed", e);
            throw new ResultDeliveryRuntimeException(e.getMessage());
        }
        applicationEventPublisher.publishEvent(event);
    }

    private SelectionAggregate buildSelectionAggregate(final ROSelectionWithdrawCommand roSelectionWithdrawCommand) {
        UUID externalSelectionUuid = UUID.fromString(roSelectionWithdrawCommand.getEventHeaders().getEventContext().get(EXTERNAL_SELECTION_UUID));
        Optional<Selection> selection = selectionRepository.findByExternalSelectionUuid(externalSelectionUuid);
        Optional<Booking> booking = Optional.empty();
        if (selection.isPresent()) {
            booking = bookingRepository.findByExternalBookingUuid(selection.get().getExternalBookingUuid());
        }
        BaseHeader baseHeader = new BaseHeader();
        baseHeader.setEventDateTime(roSelectionWithdrawCommand.getEventHeaders().getEventDateTime());
        ROSelectionCommand command = ROSelectionCommand.builder().eventHeader(baseHeader).eventBody(null).eventErrors(null).build();

        //Build Selection Aggregate based on the available data
        return SelectionAggregate.builder()
                .command(command)
                .selection(selection.orElse(null))
                .booking(booking.orElse(null))
                .build();
    }

    private BaseEvent<BaseHeader> populateBaseEvent(final String eventBody, final ROSelectionWithdrawCommand command) {
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        baseEvent.setEventHeader(buildHeader(command));
        baseEvent.setEventBody(eventBody);
        baseEvent.setEventErrors(null);
        baseEvent.setAudit(command.getAudit());
        return baseEvent;
    }

    private void withdrawSelection(Selection selection, ROSelectionWithdrawCommand command) {
        selection.setConfirmationStatus(ConfirmationStatusEnum.WITHDRAWN);
        selection.setConfirmationStatusChangedDatetime(OffsetDateTime.of(command.getEventHeaders().getEventDateTime(), ZoneOffset.UTC));
        selection.setEventDatetime(OffsetDateTime.of(command.getEventHeaders().getEventDateTime(), ZoneOffset.UTC));
        selection.setUpdatedDatetime(OffsetDateTime.now());
        selection.setSelectionDate(OffsetDateTime.of(command.getEventHeaders().getEventDateTime(), ZoneOffset.UTC));
        selectionRepository.save(selection);
    }

    public BaseEvent<BaseHeader> buildErrorDomainEvent(final ROSelectionWithdrawCommand command, final String rejectedEventName,
                                                       final Set<ConstraintViolation<SelectionAggregate>> violation) throws JsonProcessingException {
        String pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
        final BaseHeader baseHeader = command.getEventHeaders();
        OffsetDateTime localDT = OffsetDateTime.parse(baseHeader.getEventDateTimeAsString());
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(pattern);
        baseHeader.setEventName(rejectedEventName);
        baseHeader.setEventDateTime(
                LocalDateTime.ofInstant(Instant.parse(dateTimeFormatter.format(localDT)), ZoneOffset.UTC));
        CMDSErrorResponse eventErrors = errorResolver.populatErrorResponse(violation, rejectedEventName);
        BaseEventErrors baseEventErrors = new BaseEventErrors(eventErrors.getErrorList());
        String eventBody = getEventBodyForSelectionEvents(UUID.fromString(command.getEventHeaders().getEventContext().get(EXTERNAL_SELECTION_UUID)));
        return new BaseEvent<>(baseHeader, eventBody, baseEventErrors, command.getAudit());
    }

    public BaseHeader buildHeader(ROSelectionWithdrawCommand command) {
        BaseHeader eventHeader = new BaseHeader();
        eventHeader.setCorrelationId(command.getEventHeaders().getCorrelationId());
        eventHeader.setEventDateTime(LocalDateTime.now());
        eventHeader.setTransactionId(command.getEventHeaders().getTransactionId());
        eventHeader.setPartnerCode(command.getEventHeaders().getPartnerCode());
        eventHeader.setEventContext(command.getEventHeaders().getEventContext());
        eventHeader.setEventName(RDConstants.EventType.ORGANISATION_SELECTION_WITHDRAWN);
        return eventHeader;
    }

    @Override
    protected ObjectMapper getObjectMapper() {
        return this.objectMapper;
    }

    @Override
    protected BuildOrganisationSelectionNodeV1Utils getBuildOrganisationSelectionNodeV1Utils() {
        return this.buildOrganisationSelectionNodeV1Utils;
    }

    @Override
    protected SelectionRepository getSelectionRepository() {
        return this.selectionRepository;
    }


}


