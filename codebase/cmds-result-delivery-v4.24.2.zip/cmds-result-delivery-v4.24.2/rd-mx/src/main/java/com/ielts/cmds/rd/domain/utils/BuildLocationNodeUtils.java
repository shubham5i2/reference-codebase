package com.ielts.cmds.rd.domain.utils;

import com.ielts.cmds.rbac.api.service.model.LocationNode;
import com.ielts.cmds.rbac.implementation.impl.LocationHierarchyServiceImpl;
import com.ielts.cmds.rd.domain.model.out.BookingLinkNodeV1;
import com.ielts.cmds.rd.domain.model.out.LocationChangeNodeV1;
import com.ielts.cmds.rd.domain.model.out.ResultDeliveryBookingNodeV1;
import com.ielts.cmds.rd.infrastructure.entity.Location;
import com.ielts.cmds.rd.infrastructure.repositories.LocationRepository;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
@RequiredArgsConstructor
@Slf4j
public class BuildLocationNodeUtils {

    private final LocationRepository locationRepository;

    private final LocationHierarchyServiceImpl locationHierarchyService;

    public LocationChangeNodeV1 buildLocationChangeNodeV1(UUID locationUuid) {
        LocationChangeNodeV1 locationChangeNodeV1 = new LocationChangeNodeV1();
        if (Objects.nonNull(locationUuid)) {
            Optional<Location> optionalLocation = locationRepository.findById(locationUuid);
            if (optionalLocation.isPresent()) {
                Location location = optionalLocation.orElse(null);
                locationChangeNodeV1.setLocationUuid(location.getLocationUuid());
                locationChangeNodeV1.setLocationName(location.getLocationName());
                locationChangeNodeV1.setLocationTypeCode(location.getLocationType());
                locationChangeNodeV1.setParentLocationUuid(location.getParentLocationUuid());
                locationChangeNodeV1.setTestCentreNumber(location.getTestCentreNumber());
            }
        }
        return locationChangeNodeV1;

    }


    public List<LocationChangeNodeV1> buildLocationChangeNodeV1List(ResultDeliveryBookingNodeV1 bookingNodeV1) {
        Set<LocationChangeNodeV1> locationChangeNodeV1Set = new HashSet<>();

        if (Objects.nonNull(bookingNodeV1.getLocationUuid())) {
            Optional<Location> optionalLocation = locationRepository.findById(bookingNodeV1.getLocationUuid());
            if (optionalLocation.isPresent()) {
                LocationChangeNodeV1 locationChangeNodeV1 = new LocationChangeNodeV1();
                Location location = optionalLocation.orElse(null);
                locationChangeNodeV1.setLocationUuid(location.getLocationUuid());
                locationChangeNodeV1.setLocationName(location.getLocationName());
                locationChangeNodeV1.setLocationTypeCode(location.getLocationType());
                locationChangeNodeV1.setParentLocationUuid(location.getParentLocationUuid());
                locationChangeNodeV1.setTestCentreNumber(location.getTestCentreNumber());

                locationChangeNodeV1Set.add(locationChangeNodeV1);
            }
        }
        if (Objects.nonNull(bookingNodeV1.getBookingLinks())) {
            for (BookingLinkNodeV1 bookingLinkNodeV1 : bookingNodeV1.getBookingLinks()) {
                LocationChangeNodeV1 locationChangeNodeV1 = new LocationChangeNodeV1();
                Optional<Location> optionalLinkedLocation = locationRepository.findById(bookingLinkNodeV1.getLinkedBooking().getLocationUuid());
                if (optionalLinkedLocation.isPresent()) {
                    Location location = optionalLinkedLocation.orElse(null);
                    locationChangeNodeV1.setLocationUuid(location.getLocationUuid());
                    locationChangeNodeV1.setLocationName(location.getLocationName());
                    locationChangeNodeV1.setLocationTypeCode(location.getLocationType());
                    locationChangeNodeV1.setParentLocationUuid(location.getParentLocationUuid());
                    locationChangeNodeV1.setTestCentreNumber(location.getTestCentreNumber());

                    locationChangeNodeV1Set.add(locationChangeNodeV1);
                }
            }
        }

        UUID testCentreLocationUuid = getTestCentreLocationUuid(bookingNodeV1.getLocationUuid());
        locationChangeNodeV1Set.add(buildLocationChangeNodeV1(testCentreLocationUuid));
        return new ArrayList<>(locationChangeNodeV1Set);
    }

    @SneakyThrows
    public UUID getTestCentreLocationUuid(UUID locationUuid) {
        LocationNode locationNode = locationHierarchyService.getLocationBranchByLocationUuid(locationUuid);
        locationNode = getTestCentreLocationNode(locationNode);
        return Optional.ofNullable(locationNode).orElse(new LocationNode()).getLocationUuid();
    }

    public LocationNode getTestCentreLocationNode(LocationNode locationNode)
    {
        if(Objects.isNull(locationNode) || ("TEST_CENTRE").equals(locationNode.getLocationType()) )
        {
            return locationNode;
        }
        return getTestCentreLocationNode(locationNode.getParent());
    }
}
