package com.ielts.cmds.rd.domain.utils;

import com.ielts.cmds.rbac.api.service.RBACService;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
@Slf4j
@RequiredArgsConstructor
public class RbacUtils {

    @Autowired
    private RBACService rbacService;

    public boolean hasAllPermissions(String xAccessToken, String permissionId, String partner)
            throws RbacValidationException {
        return rbacService.isAuthorisedForPartner(xAccessToken, permissionId, partner);
    }

    public boolean isAuthorisedForLocationForProduct(String xAccessToken, String permissionId, UUID locationUuid, UUID productUuid)
            throws RbacValidationException {
        return rbacService.isAuthorisedInLocationForProduct(xAccessToken, permissionId, locationUuid, productUuid);
    }

}

