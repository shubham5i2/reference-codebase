package com.ielts.cmds.rd.application.service;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.config.IApplicationService;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.domain.command.SelectionDeliveryStatusUpdateCommand;
import com.ielts.cmds.rd.domain.model.in.Selection;
import com.ielts.cmds.rd.domain.service.SelectionDeliveryStatusUpdateDomainService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import static com.ielts.cmds.rd.domain.RDConstants.EventType.RO_RESULT_DELIVERY_REQ_RECEIVED;

@Service
@RequiredArgsConstructor
@Slf4j
public class SelectionDeliveryStatusUpdateService implements IApplicationService {

    private final ObjectMapper objectMapper;

    private final SelectionDeliveryStatusUpdateDomainService selectionDeliveryStatusUpdateDomainService;
    @Override
    public void process(BaseEvent<? extends BaseHeader> baseEvent) throws ProcessingException {
        try {
            final BaseHeader eventHeader = baseEvent.getEventHeader();
            final BaseEventErrors eventErrors = baseEvent.getEventErrors();
            final Selection roReceivedEventV1Body = objectMapper
                    .readValue(baseEvent.getEventBody(), Selection.class);

            if (roReceivedEventV1Body == null) {
                throw new IllegalArgumentException("Payload is Empty");
            }
            // build command
            final SelectionDeliveryStatusUpdateCommand deliveryStatusUpdateCommand = SelectionDeliveryStatusUpdateCommand.builder()
                    .eventHeader(eventHeader).eventBody(roReceivedEventV1Body).eventErrors(eventErrors)
                    .build();
            // Execute command
            selectionDeliveryStatusUpdateDomainService.on(deliveryStatusUpdateCommand);
        } catch (IllegalArgumentException | JsonProcessingException e) {
            log.error("Failed to process Ro event due to ", e);
            throw new ProcessingException(e.getMessage(), e);
        }
    }

    @Override
    public String getServiceIdentifier() {
        return RO_RESULT_DELIVERY_REQ_RECEIVED;
    }
}
