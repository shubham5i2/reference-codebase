package com.ielts.cmds.rd.domain.utils;

import com.ielts.cmds.rd.application.exception.ResultDeliveryValidationException;
import com.ielts.cmds.rd.domain.model.ResultLineModel;
import com.ielts.cmds.rd.domain.model.ResultModel;
import com.ielts.cmds.rd.infrastructure.entity.*;
import com.ielts.cmds.rd.infrastructure.repositories.BookingRepository;
import com.ielts.cmds.rd.infrastructure.repositories.ProductRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Component
@RequiredArgsConstructor
@Slf4j
public class BuildResultModelUtils {

    private final BookingRepository bookingRepository;

    private final ProductRepository productRepository;

    public ResultModel populateResultModelData(Optional<Result> optionalResult) {
        ResultModel resultModel = new ResultModel();
        Result result = optionalResult.orElse(null);
        if (Objects.nonNull(result)) {
            resultModel.setResultUuid(result.getResultUuid());
            resultModel.setResultTypeUuid(result.getResultTypeUuid());
            resultModel.setBookingUuid(result.getBookingUuid());
            resultModel.setResultScore(result.getResultScore());
            resultModel.setTrfNumber(result.getTrfNumber());
            resultModel.setCefrLevel(result.getCefrLevel());
            resultModel.setPublishedTime(result.getPublishedTime());
            resultModel.setEventDateTime(result.getEventDateTime());
            resultModel.setUpdatedDateTime(result.getUpdatedDateTime());
            resultModel.setResultsStatusTypeUuid(result.getResultsStatusTypeUuid());
            resultModel.setResultLineModelList(setResultLinesForResultModel(result));
        }
        return resultModel;

    }

    private List<ResultLineModel> setResultLinesForResultModel(Result result) {
        List<ResultLine> resultLine = result.getResultLines();
        List<ResultLineModel> resultLineModelList = new ArrayList<>();
        resultLine.forEach(e -> {
            try {
                resultLineModelList.add(setResultLinesModel(result, e));
            } catch (ResultDeliveryValidationException resultDeliveryValidationException) {
                log.error("Error in ResultLines Model :", resultDeliveryValidationException);
            }
        });
        return resultLineModelList;
    }

    private ResultLineModel setResultLinesModel(Result result, ResultLine resultLine) throws ResultDeliveryValidationException {
        Booking booking = bookingRepository.findById(result.getBookingUuid()).orElseThrow(() -> new ResultDeliveryValidationException("No booking present", new Throwable()));
        List<BookingLine> bookingLineList = booking.getBookingLines();
        ResultLineModel resultLineModel = new ResultLineModel();
        bookingLineList.stream().filter(bookingLine -> bookingLine.getBookingLineUuid()
                .equals(resultLine.getBookingLineUuid())).forEach(e -> {
            try {
                setResultLineModelDetails(resultLine, resultLineModel, e);
            } catch (ResultDeliveryValidationException resultDeliveryValidationException) {
                log.error("Error in populating Result Line model due to : ", resultDeliveryValidationException);
            }
        });

        return resultLineModel;

    }

    private void setResultLineModelDetails(ResultLine resultLine, ResultLineModel resultLineModel, BookingLine e) throws ResultDeliveryValidationException {
        Product product = productRepository.findById(e.getProductUuid()).orElseThrow(() -> new ResultDeliveryValidationException("No Product found for this", new Throwable()));
        resultLineModel.setResultLineUuid(resultLine.getResultLineUuid());
        resultLineModel.setResultLineScore(resultLine.getResultLineScore());
        resultLineModel.setAbsence(resultLine.isAbsence());
        resultLineModel.setBookingLineUuid(resultLine.getBookingLineUuid());
        resultLineModel.setProductUuid(e.getProductUuid());
        resultLineModel.setComponent(product.getComponent());
    }

}
