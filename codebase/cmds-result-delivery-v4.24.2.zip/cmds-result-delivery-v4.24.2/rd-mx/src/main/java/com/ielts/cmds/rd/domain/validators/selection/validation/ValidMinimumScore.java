/**
 * 
 */
package com.ielts.cmds.rd.domain.validators.selection.validation;

import com.ielts.cmds.rd.domain.validators.selection.MinimumScoreValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Constraint(validatedBy = { MinimumScoreValidator.class })
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.TYPE })
public @interface ValidMinimumScore {

	String message() default "{cmds.invalid.minimumScoreIsNull}";

	Class<?>[] groups() default {};

	Class<? extends Payload>[] payload() default {};

}
