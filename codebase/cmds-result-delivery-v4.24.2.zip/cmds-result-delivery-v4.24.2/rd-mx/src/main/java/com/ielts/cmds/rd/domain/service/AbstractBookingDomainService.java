package com.ielts.cmds.rd.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.application.command.BaseCommand;
import com.ielts.cmds.booking.common.CMDSAddress;
import com.ielts.cmds.booking.common.out.model.BookingDetails;
import com.ielts.cmds.booking.common.out.model.TestTakerDetails;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.application.exception.ResultDeliveryValidationException;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.domain.enums.ResultDataAnalysisOutcomeFlag;
import com.ielts.cmds.rd.domain.model.out.ResultDeliveryBookingNodeV1;
import com.ielts.cmds.rd.domain.utils.BuildResultDeliveryBookingNodeV1Utils;
import com.ielts.cmds.rd.domain.utils.BuildResultReleaseNodeV1Utils;
import com.ielts.cmds.rd.infrastructure.entity.Booking;
import com.ielts.cmds.rd.infrastructure.entity.BookingLine;
import com.ielts.cmds.rd.infrastructure.entity.BookingLink;
import com.ielts.cmds.rd.infrastructure.repositories.BookingRepository;
import com.ielts.cmds.rd.infrastructure.repositories.ResultRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static java.time.ZoneOffset.UTC;

@Slf4j
@RequiredArgsConstructor
abstract class AbstractBookingDomainService extends AbstractDomainService{

    private final BookingRepository bookingRepository;

    private final ObjectMapper objectMapper;

    private final BuildResultDeliveryBookingNodeV1Utils resultDeliveryBookingNodeV1Utils;

    private final ResultRepository resultRepository;

    private final BuildResultReleaseNodeV1Utils resultReleaseNodeV1Utils;

    private final ApplicationEventPublisher applicationEventPublisher;

    protected void process(@NotNull final BaseCommand<BaseHeader, BookingDetails> command) throws JsonProcessingException {
        log.info("Received event with booking uuid {}", command.getEventBody().getBookingUuid());

        Optional<ResultDeliveryBookingNodeV1> bookingNodeV1 = Optional.empty();
        String eventBody;
        Map<String, String> ttDataUpdateMap = Optional
                .ofNullable(command.getEventHeaders().getEventContext())
                .orElseGet(HashMap::new);

        final BaseHeader eventHeader = new BaseHeader();
        try {
            Optional<Booking> optionalBooking = bookingRepository.findById(command.getEventBody().getBookingUuid());
            bookingValidation(command, optionalBooking);
            ttDataUpdateMap = bookingInfoUpdateFlag(optionalBooking, command);
            Booking booking = updateBookingDetails(command, optionalBooking);
            bookingNodeV1 = Optional.of(resultDeliveryBookingNodeV1Utils.buildResultDeliveryBookingNodeV1(booking.getBookingUuid()));
            eventBody = objectMapper.writeValueAsString(bookingNodeV1);
            buildHeader(command, eventHeader, bookingNodeV1, ttDataUpdateMap);
        } catch (final ResultDeliveryValidationException e) {
            log.error("BookingCommand execution failed", e);
            eventBody = getEventBodyForReportGenerationEvents(command.getEventBody().getBookingUuid());
            buildHeader(command, eventHeader, bookingNodeV1, ttDataUpdateMap);
        }
        BaseEvent<BaseHeader> event = new BaseEvent<>(eventHeader, eventBody, null, command.getAudit());
        applicationEventPublisher.publishEvent(event);
    }

    private void testTakerInfoFlagUpdate(Booking booking, BaseCommand<BaseHeader, BookingDetails> command, Map<String, String> map) {
        if (!Objects.equals(booking.getShortCandidateNumber(), Integer.valueOf(command.getEventBody().getTestTaker().getShortCandidateNumber()))) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        }
        if (!Objects.equals(booking.getTitle(), command.getEventBody().getTestTaker().getTitle())) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        }
        if (!Objects.equals(booking.getIdentityIssuingAuth(), command.getEventBody().getTestTaker().getIdentityIssuingAuthority())) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        }
        if (!Objects.equals(booking.getIdentityExpiryDate(), command.getEventBody().getTestTaker().getIdentityExpiryDate())) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        }
        if (!Objects.equals(booking.getIdentityTypeUuid(), command.getEventBody().getTestTaker().getIdentityTypeUuid())) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        }
    }

    private void testTakerContactInfoFlagUpdate(Booking booking, BaseCommand<BaseHeader, BookingDetails> command, Map<String, String> map) {
        if (!Objects.equals(booking.getPhone(), command.getEventBody().getTestTaker().getPhone())) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        }
        if (!Objects.equals(booking.getEmail(), command.getEventBody().getTestTaker().getEmail())) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        }
    }

    private void testTakerAddressInfoUpdateFlag(Booking booking, BaseCommand<BaseHeader, BookingDetails> command, Map<String, String> map) {
        if (!Objects.equals(booking.getAddressLine1(), command.getEventBody().getTestTaker().getAddress().getAddressLine1())) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        }
        if (!Objects.equals(booking.getAddressLine2(), command.getEventBody().getTestTaker().getAddress().getAddressLine2())) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        }
        if (!Objects.equals(booking.getAddressLine3(), command.getEventBody().getTestTaker().getAddress().getAddressLine3())) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        }
        if (!Objects.equals(booking.getAddressLine4(), command.getEventBody().getTestTaker().getAddress().getAddressLine4())) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        }
        if (!Objects.equals(booking.getCity(), command.getEventBody().getTestTaker().getAddress().getCity())) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        }
        if (!Objects.equals(booking.getPostalCode(), command.getEventBody().getTestTaker().getAddress().getPostalCode())) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        }
        if (!Objects.equals(booking.getStateTerritoryUuid(), command.getEventBody().getTestTaker().getAddress().getStateTerritoryUuid())) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        }
    }

    private void ttPersonalInfoFlagUpdate(Booking booking, BaseCommand<BaseHeader, BookingDetails> command, Map<String, String> map) {
        //ttPersonalInfoFlagUpdate
        if (booking == null) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
            map.put(ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getValue());
        }
        if (booking != null) {
            if (!Objects.equals(booking.getLastName(), command.getEventBody().getTestTaker().getLastName())) {
                map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
                map.put(ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getValue());
            }
            if (!Objects.equals(booking.getFirstName(), command.getEventBody().getTestTaker().getFirstName())) {
                map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
                map.put(ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getValue());
            }
            if (!Objects.equals(booking.getBirthDate(), command.getEventBody().getTestTaker().getBirthDate())) {
                map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
                map.put(ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getValue());
            }
            ttPersonalInfoFlagUpdateChecks(booking, command, map);
        }
    }

    private void ttPersonalInfoFlagUpdateChecks(Booking booking, BaseCommand<BaseHeader, BookingDetails> command, Map<String, String> map) {
        if (!Objects.equals(booking.getLanguageUuid(), command.getEventBody().getTestTaker().getLanguageUuid())) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
            map.put(ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getValue());
        }
        if (!Objects.equals(booking.getIdentityNumber(), command.getEventBody().getTestTaker().getIdentityNumber())) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
            map.put(ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getValue());
        }
        if (!Objects.equals(booking.getNationalityUuid(), command.getEventBody().getTestTaker().getNationalityUuid())) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
            map.put(ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getValue());
        }
        if (!Objects.equals(booking.getSexUuid(), command.getEventBody().getTestTaker().getSexUuid())) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
            map.put(ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getValue());
        }
        if (!Objects.equals(booking.getCountryUuid(), command.getEventBody().getTestTaker().getAddress().getCountryUuid())) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
            map.put(ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getValue());
        }
    }

    private void marketingInfoFlagUpdate(Booking booking, BaseCommand<BaseHeader, BookingDetails> command, Map<String, String> map) {
        if (!Objects.equals(booking.getYearsOfStudy(), command.getEventBody().getMarketingInfo().getYearsOfStudy())) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        }
        if (!Objects.equals(booking.getReasonForTestUuid(), command.getEventBody().getMarketingInfo().getReasonForTestUuid())) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        }
        if (!Objects.equals(booking.getOccupationLevelUuid(), command.getEventBody().getMarketingInfo().getOccupationLevelUuid())) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        }
        if (!Objects.equals(booking.getOccupationSectorUuid(), command.getEventBody().getMarketingInfo().getOccupationSectorUuid())) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        }
    }

    private Map<String, String> bookingInfoUpdateFlag(Optional<Booking> optionalBooking, BaseCommand<BaseHeader, BookingDetails> command) {
        Booking booking = optionalBooking.orElse(null);
        Map<String, String> map = new HashMap<>();
        ttPersonalInfoFlagUpdate(booking, command, map);
        if (booking != null) {
            testTakerContactInfoFlagUpdate(booking, command, map);
            testTakerInfoFlagUpdate(booking, command, map);
            marketingInfoFlagUpdate(booking, command, map);
            testTakerAddressInfoUpdateFlag(booking, command, map);
            if (!Objects.equals(booking.getAgentName(), command.getEventBody().getAgentName())) {
                map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
            }
            if (!Objects.equals(booking.getTestDate(), command.getEventBody().getTestDate())) {
                map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
                map.put(ResultDataAnalysisOutcomeFlag.TT_BOOKING_TRANSFERRED.getKey(), ResultDataAnalysisOutcomeFlag.TT_BOOKING_TRANSFERRED.getValue());
            }
            if (!Objects.equals(booking.getLocationUuid(), command.getEventBody().getLocationUuid())) {
                map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
            }
            if (!Objects.equals(booking.getProductUuid(), command.getEventBody().getProductUuid())) {
                map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
            }
        }
        return map;
    }

    private void bookingValidation(final BaseCommand<BaseHeader, BookingDetails> command, final Optional<Booking> optionalBooking) throws ResultDeliveryValidationException {
        if (optionalBooking.isPresent()) {
            LocalDateTime localDateTime = optionalBooking.get().getEventDatetime().toLocalDateTime();
            if (!(command.getEventHeaders().getEventDateTime().isAfter(localDateTime))) {
                throw new ResultDeliveryValidationException(String.format("Received Event Date time is before this : %s  " + "for this Booking UUID : %s"
                        , localDateTime, command.getEventBody().getBookingUuid()), new Throwable());
            }
        }

    }

    protected void buildHeader(final BaseCommand<BaseHeader, BookingDetails> command, BaseHeader header, Optional<ResultDeliveryBookingNodeV1> bookingNodeV1, Map<String, String> ttDataUpdateMap) {
        header.setCorrelationId(command.getEventHeaders().getCorrelationId());
        header.setEventDateTime(LocalDateTime.now());
        header.setTransactionId(command.getEventHeaders().getTransactionId());
        header.setPartnerCode(command.getEventHeaders().getPartnerCode());
        if (Objects.nonNull(command.getEventBody().getBookingUuid())) {
            ttDataUpdateMap.put("bookingUuid", command.getEventBody().getBookingUuid().toString());
        }
        header.setEventContext(ttDataUpdateMap);
        if (bookingNodeV1.isPresent()) {
            header.setEventName(RDConstants.EventType.SELECTION_CHANGED_EVENT);
        } else {
            header.setEventName(RDConstants.EventType.SELECTION_CHANGED_EVENT_FAILED);
        }
    }

    protected Booking updateBookingDetails(final BaseCommand<BaseHeader, BookingDetails> command, final Optional<Booking> optionalBooking) {
        Booking booking = optionalBooking.orElseGet(() -> Booking.builder().bookingUuid(command.getEventBody().getBookingUuid()).build());
        if (Objects.nonNull(command.getEventBody().getBookingLinks()) && !command.getEventBody().getBookingLinks().isEmpty()) {
            booking.setBookingLink(updateBookingLinkDetails(command.getEventBody().getBookingUuid(), command));
        }
        booking.setExternalBookingUuid(command.getEventBody().getExternalBookingUuid());
        booking.setExternalBookingReference(command.getEventBody().getExternalBookingReference());
        booking.setLocationUuid(command.getEventBody().getLocationUuid());
        booking.setProductUuid(command.getEventBody().getProductUuid());
        booking.setTestDate(command.getEventBody().getTestDate());
        booking.setShortCandidateNumber(Integer.valueOf(command.getEventBody().getTestTaker().getShortCandidateNumber()));
        booking.setBookingStatus(command.getEventBody().getBookingStatus());
        booking.setEventDatetime(OffsetDateTime.of(command.getEventHeaders().getEventDateTime(), UTC));
        booking.setUpdatedDatetime(OffsetDateTime.now(UTC));
        booking.setBookingLines(updateBookingLineDetails(booking, command));
        booking.setAgentName(command.getEventBody().getAgentName());
        booking.setPartnerCode(command.getEventBody().getPartnerCode());
        booking.setBookingDetailStatus(command.getEventBody().getBookingDetailStatus());
        setTestTakerDetails(booking, command.getEventBody().getTestTaker());
        setMarketingInfoDetails(booking, command);
        bookingRepository.save(booking);
        return booking;
    }

    private void setMarketingInfoDetails(Booking booking, BaseCommand<BaseHeader, BookingDetails> command) {
        booking.setYearsOfStudy(command.getEventBody().getMarketingInfo().getYearsOfStudy());
        booking.setOccupationSectorUuid(command.getEventBody().getMarketingInfo().getOccupationSectorUuid());
        booking.setReasonForTestUuid(command.getEventBody().getMarketingInfo().getReasonForTestUuid());
        booking.setOccupationLevelUuid(command.getEventBody().getMarketingInfo().getOccupationLevelUuid());
    }

    private void setTestTakerDetails(Booking booking, TestTakerDetails testTaker) {
        booking.setIdentityNumber(testTaker.getIdentityNumber());
        booking.setUniqueTestTakerUuid(testTaker.getUniqueTestTakerUuid());
        booking.setExternalUniqueTestTakerUuid(testTaker.getExternalUniqueTestTakerUuid());
        booking.setCompositeCandidateNumber(testTaker.getCompositeCandidateNumber());
        booking.setFirstName(testTaker.getFirstName());
        booking.setLastName(testTaker.getLastName());
        booking.setEmail(testTaker.getEmail());
        booking.setIdentityTypeUuid(testTaker.getIdentityTypeUuid());
        booking.setIdentityIssuingAuth(testTaker.getIdentityIssuingAuthority());
        booking.setIdentityExpiryDate(testTaker.getIdentityExpiryDate());
        booking.setBirthDate(testTaker.getBirthDate());
        booking.setTitle(testTaker.getTitle());
        booking.setSexUuid(testTaker.getSexUuid());
        booking.setLanguageUuid(testTaker.getLanguageUuid());
        booking.setNationalityUuid(testTaker.getNationalityUuid());
        booking.setPhone(testTaker.getPhone());
        booking.setMobile(testTaker.getMobile());
        setTestTakerAddress(booking, testTaker.getAddress());
    }

    protected List<BookingLink> updateBookingLinkDetails(UUID bookingUuid, BaseCommand<BaseHeader, BookingDetails> command) {
        return command.getEventBody().getBookingLinks().stream()
                .map(e -> getBookingLink(bookingUuid, e))
                .collect(Collectors.toList());
    }

    private BookingLink getBookingLink(UUID bookingUuid, com.ielts.cmds.booking.common.out.model.BookingLink e) {
        BookingLink bookingLink = new BookingLink();
        bookingLink.setBookingLinkUuid(UUID.randomUUID());
        bookingLink.setSourceBookingUuid(bookingUuid);
        bookingLink.setTargetBookingUuid(e.getLinkedBooking().getBookingUuid());
        bookingLink.setCreatedDatetime(OffsetDateTime.now(UTC));
        bookingLink.setRole(e.getRole());
        return bookingLink;
    }

    private void setTestTakerAddress(Booking booking, CMDSAddress address) {
        booking.setAddressLine1(address.getAddressLine1());
        booking.setAddressLine2(address.getAddressLine2());
        booking.setAddressLine3(address.getAddressLine3());
        booking.setAddressLine4(address.getAddressLine4());
        booking.setStateTerritoryUuid(address.getStateTerritoryUuid());
        booking.setCountryUuid(address.getCountryUuid());
        booking.setPostalCode(address.getPostalCode());
        booking.setCity(address.getCity());
    }

    protected List<BookingLine> updateBookingLineDetails(Booking booking, BaseCommand<BaseHeader, BookingDetails> command) {
        return command.getEventBody().getBookingLines().stream()
                .map(e -> getBookingLine(booking, e))
                .collect(Collectors.toList());
    }

    private BookingLine getBookingLine(Booking booking, com.ielts.cmds.booking.common.out.model.BookingLine e) {
        BookingLine bookingLine = new BookingLine();
        bookingLine.setBookingLineUuid(e.getBookingLineUuid());
        bookingLine.setExternalBookingLineUuid(e.getExternalBookingLineUuid());
        bookingLine.setProductUuid(e.getProductUuid());
        bookingLine.setBooking(booking);
        bookingLine.setBookingLineStatus(e.getBookingLineStatus());
        bookingLine.setUpdatedDatetime(OffsetDateTime.now(UTC));
        return bookingLine;
    }

    @Override
    protected ResultRepository getResultRepository() {
        return this.resultRepository;
    }

    @Override
    protected BuildResultReleaseNodeV1Utils getBuildResultReleasedNodeV1Utils() {
        return this.resultReleaseNodeV1Utils;
    }

    @Override
    protected ObjectMapper getObjectMapper() {
        return this.objectMapper;
    }

}
