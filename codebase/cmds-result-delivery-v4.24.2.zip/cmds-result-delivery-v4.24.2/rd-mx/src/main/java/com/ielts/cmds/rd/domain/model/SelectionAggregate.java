package com.ielts.cmds.rd.domain.model;

import com.ielts.cmds.organisation.common.enums.MethodOfDeliveryEnum;
import com.ielts.cmds.organisation.common.enums.OrganisationStatusEnum;
import com.ielts.cmds.organisation.common.enums.VerificationStatusEnum;
import com.ielts.cmds.ors.common.out.model.MinimumScoreNodeV1ORS;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.domain.command.ROSelectionCommand;
import com.ielts.cmds.rd.domain.command.ROSelectionWithdrawCommand;
import com.ielts.cmds.rd.domain.enums.ViolationCodeEnums;
import com.ielts.cmds.rd.domain.model.enums.ComponentEnum;
import com.ielts.cmds.rd.domain.model.enums.ConfirmationStatusEnum;
import com.ielts.cmds.rd.domain.model.enums.DeliveryStatusEnum;
import com.ielts.cmds.rd.domain.model.enums.MinimumScoreSatisfiedEnum;
import com.ielts.cmds.rd.infrastructure.entity.*;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang.StringUtils;
import org.hibernate.validator.internal.engine.ConstraintViolationImpl;
import org.hibernate.validator.internal.engine.path.PathImpl;
import org.springframework.util.Assert;

import javax.validation.ConstraintViolation;
import javax.validation.Path;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.Period;
import java.util.*;

import static com.ielts.cmds.rd.domain.RDConstants.GenericConstants.*;
import static java.time.ZoneOffset.UTC;

@Getter
@Builder
@Setter
public class SelectionAggregate {

    private final ROSelectionCommand command;

    private Selection selection;

    private final Booking booking;

    private final RecognisingOrganisation organisation;

    private final ResultModel result;

    private final OrganisationType organisationType;

    private final Set<ConstraintViolation<SelectionAggregate>> violations = new HashSet<>();

    public Optional<Selection> getSelection() {
        return Optional.ofNullable(selection);
    }

    public Optional<Booking> getBooking() {
        return Optional.ofNullable(booking);
    }

    public Optional<RecognisingOrganisation> getOrganisation() {
        return Optional.ofNullable(organisation);
    }

    public Optional<ResultModel> getResult() {
        return Optional.ofNullable(result);
    }

    public Selection updateSelection() {
        canUpdateSelection();
        if (!violations.isEmpty())
            throw new IllegalStateException("Can not update the selection. There are some violations present in the selection");

        //Create or update selection based on the data
        if (Objects.isNull(selection)) {
            //Means selection is not present in db
            //Create the selection
            selection = new Selection();
            selection.setSelectionUuid(UUID.randomUUID()); //Create CMDS selection uuid
            selection.setDeliveryStatus(DeliveryStatusEnum.UNDELIVERED);
            selection.setExternalBookingUuid(command.getEventBody().getExternalBookingUuid());
            selection.setExternalSelectionUuid(command.getEventBody().getSelection().getExternalSelectionUuid());
        }
        if (StringUtils.isEmpty(selection.getExternalBookingReference())) {
            selection.setExternalBookingReference(command.getEventBody().getExternalBookingReference());
        }
        selection.setCaseNumber(command.getEventBody().getSelection().getCaseNumber());

        selection.setConfirmationStatusChangedDatetime(
                command.getEventBody().getSelection().getConfirmationStatusChangedDateTime());
        selection.setDeliveryStatus(DeliveryStatusEnum.UNDELIVERED);
        selection.setDeliveryStatusChangedDatetime(OffsetDateTime.now(UTC));
        selection.setEventDatetime(OffsetDateTime.of(command.getEventHeaders().getEventDateTime(), UTC));
        selection.setPersonDepartment(command.getEventBody().getSelection().getPersonDepartment());
        selection.setSelectionDate(OffsetDateTime.of(command.getEventHeaders().getEventDateTime(), UTC));
        if (Objects.nonNull(command.getEventBody().getSelection().getMinimumScore())) {
            selection.setOverallMinimumScore(command.getEventBody().getSelection().getMinimumScore().getOverallMinimumScore());
            selection.setMinimumScores(setMinimumScoreData(command.getEventBody().getSelection().getMinimumScore(), selection));
        }
        if (Objects.nonNull(selection.getConfirmationStatus()) &&
                selection.getConfirmationStatus().equals(ConfirmationStatusEnum.CONDITIONAL) &&
                command.getEventBody().getSelection().getConfirmationStatus().equals(com.ielts.cmds.ors.common.enums.ConfirmationStatusEnum.CONFIRMED) &&
                Objects.isNull(command.getEventBody().getSelection().getMinimumScore())) {
            selection.setOverallMinimumScore(0.0);
        }
        selection.setMinimumScoreSatisfied(MinimumScoreSatisfiedEnum.NOT_APPLICABLE);
        selection.setRecognisingOrganisationUuid(command.getEventBody().getSelection().getOrganisation().getOrganisationUuid());
        selection.setConfirmationStatus(ConfirmationStatusEnum.valueOf(command.getEventBody().getSelection().getConfirmationStatus().toString()));
        selection.setUpdatedDatetime(OffsetDateTime.now());
        return selection;
    }

    private List<MinimumScore> setMinimumScoreData(MinimumScoreNodeV1ORS minimumScoreNodeV1, Selection selection) {
        List<MinimumScore> minimumScoreList = selection.getMinimumScores();
        minimumScoreList.clear();
        if (Objects.nonNull(minimumScoreNodeV1.getComponentMinimumScores())) {
            minimumScoreNodeV1.getComponentMinimumScores().forEach(e -> {
                MinimumScore minimumScore = new MinimumScore();
                minimumScore.setMinimumScoreUuid(UUID.randomUUID());
                minimumScore.setMinimumScoreValue(e.getMinimumScore());
                minimumScore.setComponent(ComponentEnum.valueOf(e.getComponent().toString()));
                minimumScore.setSelection(selection);
                minimumScore.setUpdatedDatetime(OffsetDateTime.now(UTC));
                minimumScoreList.add(minimumScore);
            });
        }
        return minimumScoreList;
    }

    public Set<ConstraintViolation<SelectionAggregate>> canUpdateSelection() {
        //Clear previous violation if any
        violations.clear();

        //Booking test date validation

        if (Objects.nonNull(booking) && !isBookingTestDateValid()) {
            setViolation(ViolationCodeEnums.V017.getValue(), RDConstants.GenericConstants.EXTERNAL_BOOKING_UUID, command.getEventHeaders()
                    .getEventDateTime().toLocalDate().toString());
        }

        //Selection conditions validations
        if (Objects.nonNull(organisation)) {

            if (!(isOrganizationApproved() || isOrganizationVerified())) {
                setViolation(ViolationCodeEnums.V019.getValue(), RDConstants.GenericConstants.ORG_SELECTION_CONSTRAINT, organisation.getVerificationStatus().getValue());
            }

            if (!isOrganizationActive()) {
                setViolation(ViolationCodeEnums.V020.getValue(), RDConstants.GenericConstants.ORG_SELECTION_CONSTRAINT, organisation.getOrganisationStatus().getValue());
            }
        }

        //If their is a preexisting selection in database and it is not in undelivered state
        if (Objects.nonNull(selection) && !isUndelivered()) {
            setViolation(ViolationCodeEnums.V032.getValue(), EXTERNAL_SELECTION_UUID_CONSTRAINT, selection.getExternalSelectionUuid().toString());
        }

        //If organisationType id not RO
        if (Objects.nonNull(organisationType) && Objects.nonNull(organisation) && !(isOrganisationTypeRO() || isOrganisationTypeVO())) {
            setViolation(ViolationCodeEnums.V022.getValue(), RDConstants.GenericConstants.ORG_SELECTION_CONSTRAINT, organisation.getOrganisationStatus().getValue());
        }

        return violations;
    }

    public Set<ConstraintViolation<SelectionAggregate>> canWithdrawSelection(Optional<Selection> optionalSelection,
                                                                             ROSelectionWithdrawCommand command) {
        //Clear previous violation if any
        violations.clear();
        String pathValue = "{externalSelectionUuid}";

        //Selection exist validation
        if (!optionalSelection.isPresent()) {
            setViolation(ViolationCodeEnums.V028.getValue(), RDConstants.GenericConstants.EXTERNAL_SELECTION_UUID,
                    pathValue);
        }

        //selection updateDateTime validation
        if (optionalSelection.isPresent() && command.getEventHeaders().getEventDateTime()
                .isBefore(optionalSelection.get().getEventDatetime().toLocalDateTime())) {
            setViolation(ViolationCodeEnums.V030.getValue(), RDConstants.GenericConstants.EVENT_DATE_TIME,
                    EVENT_DATETIME_PATH);
        }

        if (optionalSelection.isPresent() && optionalSelection.get().getConfirmationStatus() == ConfirmationStatusEnum.WITHDRAWN) {
            setViolation(ViolationCodeEnums.V036.getValue(), RDConstants.GenericConstants.WITHDRAWN,
                    pathValue);
        }

        //Booking test date validation
        if (optionalSelection.isPresent() && (!isBookingTestDateValid())) {
            Map<String, String> eventContext = command.getEventHeaders().getEventContext();
            eventContext.put(RDConstants.GenericConstants.EXTERNAL_BOOKING_UUID, optionalSelection.get().getExternalBookingUuid().toString());
            setViolation(ViolationCodeEnums.V017.getValue(), RDConstants.GenericConstants.EXTERNAL_BOOKING_UUID, EXTERNAL_BOOKING_UUID_PATH);
        }

        //Delivery Status validation
        if (optionalSelection.isPresent() && optionalSelection.get().getDeliveryStatus() != DeliveryStatusEnum.NOT_APPLICABLE_FOR_UA
                && optionalSelection.get().getDeliveryStatus() != DeliveryStatusEnum.UNDELIVERED) {
            setViolation(ViolationCodeEnums.V029.getValue(), RDConstants.GenericConstants.EXTERNAL_SELECTION_UUID, pathValue);
        }
        return violations;
    }

    public void flagSelectionAsDeliveryRequested() {
        Assert.notNull(selection, SELECTION_DELIVERY_STATUS_SELECTION_NOT_FOUND_MESSAGE);
        selection.setDeliveryStatus(DeliveryStatusEnum.DELIVERY_REQUESTED);
        selection.setDeliveryStatusChangedDatetime(OffsetDateTime.now());
    }

    public void flagSelectionAsRedeliveryRequested() {
        Assert.notNull(selection, SELECTION_DELIVERY_STATUS_SELECTION_NOT_FOUND_MESSAGE);
        selection.setDeliveryStatus(DeliveryStatusEnum.REDELIVERY_REQUESTED);
        selection.setDeliveryStatusChangedDatetime(OffsetDateTime.now());
    }

    public void flagSelectionAsPending() {
        Assert.notNull(selection, "Can not update selection delivery status. No selection found");
        selection.setDeliveryStatus(DeliveryStatusEnum.DELIVERY_PENDING);
        if (selection.getConfirmationStatus().equals(ConfirmationStatusEnum.CONDITIONAL)) {
            selection.setMinimumScoreSatisfied(MinimumScoreSatisfiedEnum.SATISFIED);
        }
        selection.setDeliveryStatusChangedDatetime(OffsetDateTime.now());
    }

    public boolean isOrganisationTypeRO() {
        Assert.notNull(organisationType, ORGANISATION_TYPE_CANNOT_BE_NULL_MESSAGE);
        return organisationType.getOrganisationTypeName().equals("RO");
    }

    public boolean isOrganisationTypeVO() {
        Assert.notNull(organisationType, ORGANISATION_TYPE_CANNOT_BE_NULL_MESSAGE);
        return organisationType.getOrganisationTypeName().equals("VO");
    }

    public boolean isBookingTestDateValid() {
        Assert.notNull(booking, BOOKING_CANNOT_BE_NULL_MESSAGE);
        Assert.notNull(command.getEventHeaders().getEventDateTime(), EVENT_DATETIME_CANNOT_BE_NULL_MESSAGE);

        LocalDate bookingTestDate = booking.getTestDate();
        LocalDate selectionSubmissionDate = command.getEventHeaders().getEventDateTime().toLocalDate();

        int periodYrs = Period.between(bookingTestDate, selectionSubmissionDate).getYears();
        int periodDays = Period.between(bookingTestDate, selectionSubmissionDate).getDays();
        int periodMonth = Period.between(bookingTestDate, selectionSubmissionDate).getMonths();

        return !(periodYrs >= 2 && (periodDays > 0 || periodMonth > 0));
    }

    public Set<ConstraintViolation<SelectionAggregate>> isSelectionConditionsAreValid() {

        violations.clear();

        if (Objects.isNull(organisation)) {
            setViolation("V014", "selection.recognisingOrganisationUuid", selection.getRecognisingOrganisationUuid().toString());
        }

        if (Objects.isNull(organisationType)) {
            assert organisation != null;
            setViolation("V014", "organisation.organisationTypeUuid", organisation.getOrganisationTypeUuid().toString());
        }

        if (!isOrganizationActive()) {
            assert organisation != null;
            setViolation("V020", ORG_SELECTION_CONSTRAINT, organisation.getOrganisationStatus().getValue());
        }

        if (!(isOrganisationTypeRO() || isOrganisationTypeVO())) {
            assert organisationType != null;
            setViolation("V022", ORG_SELECTION_CONSTRAINT, organisationType.getOrganisationTypeName());
        }

        if (!(isOrganizationApproved() || isOrganizationVerified())) {
            assert organisation != null;
            setViolation("V019", ORG_SELECTION_CONSTRAINT, organisation.getVerificationStatus().getValue());
        }

        if(!isOrganisationEDeliveryAccepted()){
            assert organisation != null;
            setViolation("V018", ORG_SELECTION_CONSTRAINT, organisation.getMethodOfDelivery().getValue());
        }

        return violations;
    }

    public boolean isSelectionWithdrawn() {
        return selection.getConfirmationStatus().equals(ConfirmationStatusEnum.WITHDRAWN);
    }

    public Set<ConstraintViolation<SelectionAggregate>> canSelectionBeDeliveredToResultPortal() {

        violations.clear();
        Set<ConstraintViolation<SelectionAggregate>> set = isSelectionConditionsAreValid();
        if (set.isEmpty()) {
            if (isSelectionWithdrawn()) {
                setViolation("V036", "selection.externalSelectionUuid", organisation.getVerificationStatus().getValue());
                return violations;
            }
            if (selection.getConfirmationStatus().equals(ConfirmationStatusEnum.CONDITIONAL) && !isMinimumScoreSatisfied()) {
                setViolation("V037", "selection.minimumScore.overallMinimumScore", selection.getOverallMinimumScore().toString());

                return violations;
            }
        }
        return violations;
    }

    public void flagSelectionMinimumScoreUnSatisfiedCriteria() {
        selection.setMinimumScoreSatisfied(MinimumScoreSatisfiedEnum.UNSATISFIED);
        selection.setDeliveryStatus(DeliveryStatusEnum.UNDELIVERED);
        selection.setDeliveryStatusChangedDatetime(OffsetDateTime.now());
    }

    public boolean isMinimumScoreSatisfied() {
        List<ResultLineModel> resultLineList;

        //OverAll Minimum Score Check
        if (result.getResultScore() < selection.getOverallMinimumScore()) {
            return false;
        }
        resultLineList = result.getResultLineModelList();
        //Component wise score comparison
        return resultLineComponentScoreComparison(selection.getMinimumScores(), resultLineList);
    }


    private boolean resultLineComponentScoreComparison(List<MinimumScore> minimumScoreList, List<ResultLineModel> resultLineList) {
        for (MinimumScore minimumScore : minimumScoreList) {
            Optional<ResultLineModel> resultLine = resultLineList.stream()
                    .filter(e -> e.getComponent().getValue().equals(minimumScore.getComponent().getValue()))
                    .findFirst();
            if (resultLine.isPresent() && (resultLine.get().getResultLineScore() < minimumScore.getMinimumScoreValue())) {
                return false;
            }
        }
        return true;
    }

    public boolean isOrganizationApproved() {
        Assert.notNull(organisation, SELECTION_ORGANIZATION_CANNOT_BE_NULL);

        return isOrganisationTypeRO() && organisation.getVerificationStatus() == VerificationStatusEnum.APPROVED;
    }

    public boolean isOrganizationVerified() {
        Assert.notNull(organisation, SELECTION_ORGANIZATION_CANNOT_BE_NULL);

        return isOrganisationTypeVO() && organisation.getVerificationStatus() == VerificationStatusEnum.VERIFIED;
    }

    public boolean isOrganizationActive() {
        Assert.notNull(organisation, SELECTION_ORGANIZATION_CANNOT_BE_NULL);

        return organisation.getOrganisationStatus() == OrganisationStatusEnum.ACTIVE;
    }

    public boolean isOrganisationEDeliveryAccepted(){
        Assert.notNull(organisation, SELECTION_ORGANIZATION_CANNOT_BE_NULL);

        return organisation.getMethodOfDelivery() == MethodOfDeliveryEnum.E_DELIVERY;
    }

    public boolean isUndelivered() {
        Assert.notNull(selection, SELECTION_DELIVERY_STATUS_SELECTION_NOT_FOUND_MESSAGE);
        return selection.getDeliveryStatus() == DeliveryStatusEnum.UNDELIVERED;
    }

    public void setViolation(final String errorCode, final String pathProperty, final String pathValue) {
        Path path = PathImpl.createPathFromString(pathProperty);
        final Map<String, Object> messageParameters = new HashMap<>();
        final Map<String, Object> expressionVariables = new HashMap<>();

        ConstraintViolation<SelectionAggregate> constraintViolationImpl = ConstraintViolationImpl
                .forBeanValidation(null, messageParameters, expressionVariables, errorCode,
                        null, null, null, pathValue, path, null, null);

        violations.add(constraintViolationImpl);
    }

    public Set<ConstraintViolation<SelectionAggregate>> canUpdateUASelection() {
        //Clear previous violation if any
        violations.clear();

        //Booking test date validation
        if (Objects.nonNull(booking) && !isBookingTestDateValid()) {
            setViolation(ViolationCodeEnums.V017.getValue(), RDConstants.GenericConstants.EXTERNAL_BOOKING_UUID, command.getEventHeaders()
                    .getEventDateTime().toLocalDate().toString());
        }
        return violations;
    }
}
