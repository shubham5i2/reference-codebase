package com.ielts.cmds.rd.domain.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Getter
public enum ViolationCodeEnums {

    V017("V017"),
    V018("V018"),
    V019("V019"),
    V020("V020"),
    V022("V022"),
    V027("V027"),
    V028("V028"),
    V029("V029"),
    V030("V030"),
    V032("V032"),
    V036("V036");

    private final String value;

}
