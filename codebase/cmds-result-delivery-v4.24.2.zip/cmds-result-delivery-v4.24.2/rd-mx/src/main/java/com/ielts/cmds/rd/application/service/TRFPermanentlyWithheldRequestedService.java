package com.ielts.cmds.rd.application.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.config.IApplicationService;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.domain.command.TRFPermanentlyWithholdRequestedCommand;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import com.ielts.cmds.rd.domain.service.TRFPermanentlyWithheldRequestedDomainService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.lang.reflect.InvocationTargetException;

@Service
@RequiredArgsConstructor
@Slf4j
public class TRFPermanentlyWithheldRequestedService implements IApplicationService {

    private final ObjectMapper objectMapper;

    private final TRFPermanentlyWithheldRequestedDomainService trfPermanentlyWithheldRequestedDomainService;

    @Override
    public void process(BaseEvent<? extends BaseHeader> baseEvent) throws ProcessingException {
        try {
            final BaseHeader eventHeader = baseEvent.getEventHeader();
            final BaseEventErrors eventErrors = baseEvent.getEventErrors();
            final ResultReleasedNodeV1 resultReleasedNodeV1 = objectMapper
                    .readValue(baseEvent.getEventBody(), ResultReleasedNodeV1.class);
            if (resultReleasedNodeV1 == null) {
                throw new IllegalArgumentException(RDConstants.GenericConstants.EMPTY_PAYLOAD);
            }
            //build command
            final TRFPermanentlyWithholdRequestedCommand trfPermanentlyWithholdRequestedCommand = TRFPermanentlyWithholdRequestedCommand.builder()
                    .eventHeaders(eventHeader).eventBody(resultReleasedNodeV1)
                    .eventErrors(eventErrors).eventAudit(baseEvent.getAudit()).build();

            //execute command
            trfPermanentlyWithheldRequestedDomainService.on(trfPermanentlyWithholdRequestedCommand);

        } catch (IllegalArgumentException | JsonProcessingException | InvocationTargetException | IllegalAccessException e) {
            log.error("Failed to process TRF Generation event due to ", e);
            throw new ProcessingException(e.getMessage(), e);
        }
    }

    @Override
    public String getServiceIdentifier() {
        return RDConstants.EventType.TRF_PERMANENTLY_WITHHOLD_REQUESTED;
    }
}
