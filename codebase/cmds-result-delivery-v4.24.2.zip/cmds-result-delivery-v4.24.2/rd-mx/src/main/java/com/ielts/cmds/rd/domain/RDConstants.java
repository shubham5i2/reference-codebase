package com.ielts.cmds.rd.domain;

public class RDConstants {

    private RDConstants() {
    }

    public static final class EventType {
        public static final String LOCATION_CHANGED = "LocationChanged";
        public static final String BOOKING_CREATED_EVENT = "BookingCreated";
        public static final String BOOKING_UPDATED_EVENT = "BookingUpdated";
        public static final String BOOKING_TRANSFERRED_EVENT = "BookingTransferred";
        public static final String PHOTO_PUBLISHED_EVENT = "PhotoPublished";
        public static final String BOOKING_CHANGED_EVENT = "SelectionBookingChanged";
        public static final String RESULT_RELEASE_EVENT = "BookingResultChanged";
        public static final String RO_CREATE_EVENT = "RoCreated";
        public static final String RO_CHANGED_EVENT = "RoChanged";
        public static final String RO_SELECTION_CHANGED_FAILED = "ROSelectionChangedFailed";
        public static final String SELECTION_CHANGED_EVENT = "SelectionBookingChanged";
        public static final String SELECTION_CHANGED_EVENT_FAILED = "SelectionBookingChangeFailed";
        public static final String SELECTION_LOCATION_EVENT = "SelectionLocationCreated";
        public static final String SELECTION_LOCATION_EVENT_FAILED = "SelectionLocationCreateFailed";
        public static final String LEGACY_RESULT_DELIVERY_REQUESTED = "LegacyResultDeliveryRequested";
        public static final String NO_ACTION_TAKEN = "NoActionTaken";
        public static final String RELEASED = "RELEASED";
        public static final String PERMANENTLY_WITHHELD = "PERMANENTLY_WITHHELD";
        public static final String TT_PHOTO_CHANGED_EVENT = "ResultDeliveryPhotoDetailChanged";
        public static final String RO_RESULT_DELIVERY_REQ_RECEIVED = "RecognisingOrganisationResultsDeliveryRequestReceived";
        public static final String ORGANISATION_SELECTION_DELIVERY_STATUS_CHANGED = "OrganisationSelectionDeliveryStatusChanged";
        public static final String RO_SELECTION_DELIVERY_REQUEST_FAILED = "ROSelectionDeliveryRequestFailed";
        public static final String ORGANISATION_SELECTION_WITHDRAWN = "OrganisationSelectionWithdrawn";
        public static final String LEGACY_RESULT_DELIVERY_INITIATED = "LegacyResultDeliveryInitiated";
        public static final String LEGACY_RESULT_DELIVERY_INITIATED_FAILED = "LegacyResultDeliveryInitiateFailed";
        public static final String TRF_PERMANENTLY_WITHHOLD_REQUESTED = "TRFPermanentlyWithholdRequested";
        public static final String ETRF_PERMANENTLY_WITHHOLD_REQUESTED = "ETRFPermanentlyWithholdRequested";
        public static final String RESULT_PERMANENTLY_WITHHOLD_REQUESTED = "ResultPermanentlyWithholdRequested";
        public static final String SELECTION_RESULT_RELEASED = "SelectionResultReleased";
        public static final String TRF_GENERATION_REQUESTED_EVENT = "TRFGenerationRequested";
        public static final String ETRF_GENERATION_REQUESTED_EVENT = "ETRFGenerationRequested";
        public static final String TRF_GENERATED_EVENT = "TRFGenerated";
        public static final String TRF_GENERATED_FAILED_EVENT = "TRFGenerateFailed";
        public static final String ETRF_GENERATED_FAILED_EVENT = "ETRFGenerateFailed";
        public static final String RECOGNISING_ORGANISATION_RESULTS_DELIVERY_REQUESTED = "RecognisingOrganisationResultsDeliveryRequested";
        public static final String SELECTION_RESULT_RELEASED_FAILED = "SelectionResultReleaseFailed";
        public static final String RESULT_DELIVERY_PHOTO_DETAIL_CHANGED = "ResultDeliveryPhotoDetailChanged";
        public static final String RESULT_DELIVERY_PHOTO_DETAIL_CHANGE_FAILED = "ResultDeliveryPhotoDetailChangedFailed";
        public static final String LEGACY_RESULT_DELIVERY_CHANGED = "LegacyResultDeliveryChanged";
        public static final String LEGACY_RESULT_DELIVERY_CHANGE_FAILED = "LegacyResultDeliveryChangeFailed";
        public static final String LEGACY_RESULT_PUBLISHED = "LegacyResultPublished";
        public static final String LEGACY_RESULT_PUBLISH_FAILED = "LegacyResultPublishFailed";
        public static final String RO_SELECTION_DELIVERY_REQUESTED = "ROSelectionDeliveryRequested";
        public static final String RECEIVING_ORGANISATION_SELECTION_CHANGED = "ReceivingOrganisationSelectionChanged";
        public static final String SELECTION_RO_CHANGED = "SelectionRoChanged";
        public static final String SELECTION_RO_CHANGE_FAILED = "SelectionRoChangeFailed";
        public static final String REPORT_GENERATED = "ReportGenerated";
        public static final String REPORT_DELIVERY_REQUESTED = "ReportDeliveryRequested";
        public static final String TRF_PERMANENTLY_WITHHELD = "TRFPermanentlyWithheld";
        public static final String POST_V1_TRF_BOOKING_BOOKING_UUID_SELECTIONS_SEARCH = "POST/v1/trf/booking/\\{(.*?)\\}/selections/search";
        public static final String TRF_BOOKING_SELECTIONS_SEARCH_RESULT_GENERATED = "TRFBookingSelectionsSearchResultGenerated";
        public static final String TRF_BOOKING_SELECTIONS_SEARCH_RESULT_GENERATE_FAILED = "TRFBookingSelectionsSearchResultGenerateFailed";
        public static final String DELIVERY = "DELIVERY";
        public static final String POST_V1_ETRF_BOOKING_BOOKING_UUID_DOWNLOAD_ETRF = "POST/v1/etrf/booking/\\{(.*?)\\}/download/etrf";
        public static final String POST_V1_TRF_BOOKING_BOOKING_UUID_DOWNLOAD_TRF = "POST/v1/trf/booking/\\{(.*?)\\}/download/trf";
        public static final String ETRF_DOWNLOAD_RESPONSE_GENERATED = "ETRFDownloadResponseGenerated";
        public static final String ETRF_DOWNLOAD_RESPONSE_GENERATE_FAILED = "ETRFDownloadResponseGenerateFailed";
        public static final String TRF_DOWNLOAD_RESPONSE_GENERATED = "TRFDownloadResponseGenerated";
        public static final String TRF_DOWNLOAD_RESPONSE_GENERATE_FAILED = "TRFDownloadResponseGenerateFailed";
        public static final String REPORT_GENERATION_REQUESTED = "ReportGenerationRequested";
        public static final String REPORT_GENERATED_FAILED = "ReportGeneratedFailed";
        public static final String SELECTION_CHANGED = "RecognisingOrganisationSelectionChangedByTestTaker";
        public static final String SELECTION_WITHDRAW = "RecognisingOrganisationSelectionWithdrawRequestedByTestTaker";
        private EventType() {
        }

    }

    public static final class SortFieldNameConstants {
        public static final String ORGANISATION_ID = "organisationId";
        public static final String ORGANISATION_NAME = "organisationName";
        public static final String ORGANISATION_ADDRESS = "organisationAddress";
        public static final String SELECTION_DATE = "selectionDate";
        public static final String PERSON_DEPARTMENT = "personDepartment";
        public static final String CASE_NUMBER = "caseNumber";
        public static final String CONFIRMATION_STATUS = "confirmationStatus";
        public static final String CONFIRMATION_STATUS_CHANGED_DATE_TIME = "confirmationStatusChangedDateTime";
        public static final String ORGANISATION_TYPE = "organisationType";

        private SortFieldNameConstants() {

        }
    }

    public static final class GenericConstants {
        public static final String SECONDARY_SELECTION = "secondarySelection";
        public static final String MSG_ATTR_DATA_TYPE = "String";
        public static final String EVENT_NAME = "eventName";
        public static final String EVENT_DATETIME_PATH = "{eventDateTime}";
        public static final String EMPTY_PAYLOAD = "Empty Payload";
        public static final String PARTNER_CODE = "partnerCode";
        public static final String CONNECTION_ID = "connectionId";
        public static final String ORG_SELECTION_CONSTRAINT = "selection.organisation.organisationUuid";
        public static final String EXTERNAL_SELECTION_UUID_CONSTRAINT = "selection.externalSelectionUuid";
        public static final String EXTERNAL_SELECTION_UUID = "externalSelectionUuid";
        public static final String EVENT_DATE_TIME = "eventDateTime";
        public static final String EXTERNAL_BOOKING_UUID = "externalBookingUuid";
        public static final String EXTERNAL_BOOKING_UUID_PATH = "{externalBookingUuid}";
        public static final String TT_RESULT_DATA_CHANGED = "ttResultDataChanged";
        public static final String TRF_CRITICAL_INFO_CHANGED = "trfCriticalInfoChanged";
        public static final  String TT_BOOKING_TRANSFERRED  = "ttBookingTransferred";
        public static final String RD = "RD";
        public static final String LA = "LA";
        public static final String PRINCIPAL_ID = "auth0|ResultDelivery";
        public static final String PRINCIPAL_NAME = "ResultDelivery";
        public static final String PERMISSION = "ResultDeliveryDefaultPermission";
        public static final String SELECTION_DELIVERY_STATUS_SELECTION_NOT_FOUND_MESSAGE = "Can not check selection delivery status. No selection found";
        public static final String EVENT_DATETIME_CANNOT_BE_NULL_MESSAGE = "Event datetime can not be null";
        public static final String BOOKING_CANNOT_BE_NULL_MESSAGE = "Booking can not be null";
        public static final String ORGANISATION_TYPE_CANNOT_BE_NULL_MESSAGE = "OrganisationType cannot be null";
        public static final String PERMANENTLY_WITHHELD = "PERMANENTLY_WITHHELD";
        public static final String RELEASED = "RELEASED";
        public static final String WITHDRAWN = "WITHDRAWN";
        public static final String SELECTION_ORGANIZATION_CANNOT_BE_NULL = "Selection Organization cannot be null";
        public static final String TRF = "TRF";
        public static final String ETRF = "ETRF";
        public static final String DOWNLOAD_ETRF = "DOWNLOAD_ETRF";
        public static final String VIEW_ETRF = "VIEW_ETRF";
        public static final String BC_CHINA = "BC_CHN";

        public static final String ERROR_MESSAGE = "errorMessage";

        public static final String ERROR_CODE = "errorCode";

        public static final String TEMPLATE_NOT_FOUND_MESSAGE= "Download cannot be completed since there is no matching template/s found for this booking!";

        private GenericConstants() {
        }
    }
}
