package com.ielts.cmds.rd.application.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.config.IApplicationService;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.domain.command.ReportGeneratedChangeAnalysisCommand;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import com.ielts.cmds.rd.domain.service.ReportGeneratedChangeAnalysisDomainService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.util.Objects;

import static com.ielts.cmds.rd.domain.RDConstants.EventType.REPORT_GENERATED;

@Service
@RequiredArgsConstructor
@Slf4j
public class ReportGeneratedChangeAnalysisService implements IApplicationService {

    private final ObjectMapper objectMapper;

    private final ReportGeneratedChangeAnalysisDomainService reportGeneratedChangeAnalysisDomainService;

    @Override
    public void process(BaseEvent<? extends BaseHeader> baseEvent) throws ProcessingException {
        ReportGeneratedChangeAnalysisCommand reportGeneratedChangeAnalysisCommand = null;
        try {
            final BaseHeader eventHeader = baseEvent.getEventHeader();
            final BaseEventErrors eventErrors = baseEvent.getEventErrors();
            ResultReleasedNodeV1 resultReleasedNodeV1 = null;
            if (Objects.nonNull(baseEvent.getEventBody()))
                resultReleasedNodeV1 = objectMapper
                        .readValue(baseEvent.getEventBody(), ResultReleasedNodeV1.class);

            //build command
            reportGeneratedChangeAnalysisCommand = ReportGeneratedChangeAnalysisCommand.builder()
                    .eventHeader(eventHeader).eventBody(resultReleasedNodeV1)
                    .eventErrors(eventErrors).eventAudit(baseEvent.getAudit()).build();

            //execute command
            reportGeneratedChangeAnalysisDomainService.on(reportGeneratedChangeAnalysisCommand);

        } catch (DataIntegrityViolationException e) {
            log.error("Failed to process {} due to {} ", REPORT_GENERATED, e);
            reportGeneratedChangeAnalysisDomainService.onFailure(reportGeneratedChangeAnalysisCommand);
        } catch (IllegalArgumentException | JsonProcessingException e) {
            log.error("Failed to process Report Generated event due to ", e);
            throw new ProcessingException(e.getMessage(), e);
        }
    }

    @Override
    public String getServiceIdentifier() {
        return REPORT_GENERATED;
    }
}



