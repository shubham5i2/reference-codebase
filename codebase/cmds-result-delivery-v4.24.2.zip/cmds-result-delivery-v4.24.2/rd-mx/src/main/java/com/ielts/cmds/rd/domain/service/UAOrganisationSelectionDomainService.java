package com.ielts.cmds.rd.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.ors.common.out.model.MinimumScoreNodeV1ORS;
import com.ielts.cmds.ors.common.out.model.SelectionNodeV1ORS;
import com.ielts.cmds.rd.application.exception.ResultDeliveryValidationException;
import com.ielts.cmds.rd.domain.command.ROSelectionCommand;
import com.ielts.cmds.rd.domain.model.SelectionAggregate;
import com.ielts.cmds.rd.domain.model.SelectionDataBody;
import com.ielts.cmds.rd.domain.model.enums.ComponentEnum;
import com.ielts.cmds.rd.domain.model.enums.ConfirmationStatusEnum;
import com.ielts.cmds.rd.domain.model.enums.DeliveryStatusEnum;
import com.ielts.cmds.rd.domain.model.enums.MinimumScoreSatisfiedEnum;
import com.ielts.cmds.rd.domain.utils.BuildOrganisationSelectionNodeV1Utils;
import com.ielts.cmds.rd.domain.validators.selection.SelectionValidator;
import com.ielts.cmds.rd.infrastructure.entity.Booking;
import com.ielts.cmds.rd.infrastructure.entity.MinimumScore;
import com.ielts.cmds.rd.infrastructure.entity.Selection;
import com.ielts.cmds.rd.infrastructure.entity.UnverifiedAddress;
import com.ielts.cmds.rd.infrastructure.event.utils.ConstraintViolationUtils;
import com.ielts.cmds.rd.infrastructure.repositories.BookingRepository;
import com.ielts.cmds.rd.infrastructure.repositories.SelectionRepository;
import com.ielts.cmds.rd.infrastructure.repositories.UnverifiedAddressRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.ConstraintViolation;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import static com.ielts.cmds.rd.domain.RDConstants.EventType.RECEIVING_ORGANISATION_SELECTION_CHANGED;
import static java.time.ZoneOffset.UTC;


@Service
@Slf4j
@RequiredArgsConstructor
public class UAOrganisationSelectionDomainService extends AbstractDomainService  {

    private final ObjectMapper objectMapper;

    private final SelectionValidator selectionValidator;

    private final SelectionRepository selectionRepository;

    private final BookingRepository bookingRepository;

    private final UnverifiedAddressRepository unverifiedAddressRepository;

    private final ApplicationEventPublisher applicationEventPublisher;

    private final BuildOrganisationSelectionNodeV1Utils buildOrganisationSelectionNodeV1Utils;

    private final CMDSErrorResolver<SelectionDataBody> errorResolver;


    @Transactional
    public void onCommand(final ROSelectionCommand command) throws JsonProcessingException, ResultDeliveryValidationException {

        log.debug("Received RO Selection Change Analysis event with Selection Uuid {}", command.getEventBody().getSelection().getSelectionUuid());

        final SelectionDataBody selectionDataBody = buildSelectionBody(command);

        final SelectionAggregate selectionAggregate = buildSelectionAggregate(command);

        //Call the selection validator to validate the selection before proceeding for create or update
        final Set<ConstraintViolation<SelectionDataBody>> violations = new HashSet<>(selectionValidator.validate(selectionDataBody));

        BaseEvent<BaseHeader> publishingEvent;

        //when selection data body violations are found
        if (!violations.isEmpty()) {
            log.info("Data violations found for selection create/update with TransactionId {}",command.getEventHeaders().getTransactionId());
            publishingEvent = buildErrorDomainEvent(command.getEventHeaders(), RECEIVING_ORGANISATION_SELECTION_CHANGED, violations, command);
        }
        //if no data violations are found
        else {
            log.info("Received Valid Selection Data. No SelectionDataBody violations for selection with externalSelectionUuid {}",command.getEventBody().getSelection().getExternalSelectionUuid());
            final Set<ConstraintViolation<SelectionAggregate>> aggregateViolations = selectionAggregate.canUpdateUASelection();
            List<ConstraintViolation<SelectionDataBody>> selectionDataBodyCompatibleViolation
                    = convertToSelectionDataBodyViolations(selectionDataBody, aggregateViolations);

            //Add all business violation to root violations list
            violations.addAll(selectionDataBodyCompatibleViolation);
            //if no selection aggregate violations are found
            if (violations.isEmpty()) {
                log.info("No Business rule violations for selection with externalSelectionUuid {}",command.getEventBody().getSelection().getExternalSelectionUuid());
                Optional<Selection> optionalSelection = selectionRepository.findByExternalSelectionUuid(command.getEventBody().getSelection().getExternalSelectionUuid());
                Optional<UnverifiedAddress> optionalUnverifiedAddress = optionalSelection.flatMap(value -> unverifiedAddressRepository.findById(value.getUnverifiedAddressUuid()));
                UnverifiedAddress unverifiedAddress = getUAEntityFromNode(command, optionalUnverifiedAddress);
                Selection selection = getSelectionEntityFromNode(command, unverifiedAddress, optionalSelection);
                //if the operation is update selection, set selectionUuid and UAUuid from db
                if (optionalSelection.isPresent()) {
                    selection.setSelectionUuid(optionalSelection.get().getSelectionUuid());
                    selection.setUnverifiedAddressUuid(optionalSelection.get().getUnverifiedAddressUuid());
                    unverifiedAddress.setUnverifiedAddressUuid(optionalSelection.get().getUnverifiedAddressUuid());
                }

                unverifiedAddressRepository.save(unverifiedAddress);
                selectionRepository.save(selection);

                log.info("Create/Update UA Selection request for ExternalSelectionUuid: {} and TransactionId: {} is processed and saved to db successfully",command.getEventBody().getSelection().getExternalSelectionUuid(),command.getEventHeaders().getTransactionId());

                com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1 outOrganisationSelectionNodeV1 = buildOrganisationSelectionNodeV1Utils.buildOrganisationSelectionNodeV1Utils(selection.getSelectionUuid());
                outOrganisationSelectionNodeV1.setOrganisationDetails(null);
                publishingEvent = getPublishingEvent(outOrganisationSelectionNodeV1, command);

            }
            //if selection aggregate violations are found
            else {
                log.info("Business violations found for selection create/update with TransactionId {}",command.getEventHeaders().getTransactionId());
                publishingEvent = buildErrorDomainEvent(command.getEventHeaders(), RECEIVING_ORGANISATION_SELECTION_CHANGED, violations, command);
            }

        }
        applicationEventPublisher.publishEvent(publishingEvent);
    }

    private Selection getSelectionEntityFromNode(ROSelectionCommand command, UnverifiedAddress unverifiedAddress, Optional<Selection> optionalSelection) {
        SelectionNodeV1ORS selectionNodeV1 = command.getEventBody().getSelection();
        Selection selection = optionalSelection.orElse(new Selection());
        if (!optionalSelection.isPresent()) {
            selection.setSelectionUuid(UUID.randomUUID());
        }
        selection.setUnverifiedAddressUuid(unverifiedAddress.getUnverifiedAddressUuid());
        selection.setExternalSelectionUuid(selectionNodeV1.getExternalSelectionUuid());
        selection.setExternalBookingUuid(command.getEventBody().getExternalBookingUuid());
        selection.setExternalBookingReference(command.getEventBody().getExternalBookingReference());
        selection.setSelectionDate(OffsetDateTime.of(command.getEventHeaders().getEventDateTime(), UTC));
        selection.setConfirmationStatus(ConfirmationStatusEnum.valueOf(selectionNodeV1.getConfirmationStatus().toString()));
        selection.setConfirmationStatusChangedDatetime(selectionNodeV1.getConfirmationStatusChangedDateTime());
        if(Objects.nonNull(selectionNodeV1.getMinimumScore())) {
            selection.setOverallMinimumScore(selectionNodeV1.getMinimumScore().getOverallMinimumScore());
            selection.setMinimumScores(getMinimumScoreData(selectionNodeV1.getMinimumScore(), selection));
        }
        selection.setMinimumScoreSatisfied(MinimumScoreSatisfiedEnum.NOT_APPLICABLE);
        selection.setCaseNumber(selectionNodeV1.getCaseNumber());
        selection.setPersonDepartment(selectionNodeV1.getPersonDepartment());
        selection.setUpdatedDatetime(OffsetDateTime.now());
        selection.setEventDatetime(OffsetDateTime.now());
        selection.setDeliveryStatus(DeliveryStatusEnum.NOT_APPLICABLE_FOR_UA);
        selection.setDeliveryStatusChangedDatetime(OffsetDateTime.now());
        return selection;
    }

    private UnverifiedAddress getUAEntityFromNode(ROSelectionCommand command, Optional<UnverifiedAddress> optionalUnverifiedAddress) {
        UnverifiedAddress unverifiedAddress = optionalUnverifiedAddress.orElse(new UnverifiedAddress());
        if (!optionalUnverifiedAddress.isPresent()) {
            unverifiedAddress.setUnverifiedAddressUuid(UUID.randomUUID());
        }
        unverifiedAddress.setAddressLine1(command.getEventBody().getSelection().getUnverifiedAddress().getAddress().getAddressLine1());
        unverifiedAddress.setAddressLine2(command.getEventBody().getSelection().getUnverifiedAddress().getAddress().getAddressLine2());
        unverifiedAddress.setAddressLine3(command.getEventBody().getSelection().getUnverifiedAddress().getAddress().getAddressLine3());
        unverifiedAddress.setAddressLine4(command.getEventBody().getSelection().getUnverifiedAddress().getAddress().getAddressLine4());
        unverifiedAddress.setCity(command.getEventBody().getSelection().getUnverifiedAddress().getAddress().getCity());
        unverifiedAddress.setPostalCode(command.getEventBody().getSelection().getUnverifiedAddress().getAddress().getPostalCode());
        unverifiedAddress.setTerritoryUuid(command.getEventBody().getSelection().getUnverifiedAddress().getAddress().getTerritoryUuid());
        unverifiedAddress.setTerritoryIsoCode(command.getEventBody().getSelection().getUnverifiedAddress().getAddress().getTerritoryIsoCode());
        unverifiedAddress.setCountryIsoCode(command.getEventBody().getSelection().getUnverifiedAddress().getAddress().getCountryIso3Code());
        unverifiedAddress.setEmail(command.getEventBody().getSelection().getUnverifiedAddress().getAddress().getEmail());
        unverifiedAddress.setPhone(command.getEventBody().getSelection().getUnverifiedAddress().getAddress().getPhone());
        unverifiedAddress.setOrganisationName(command.getEventBody().getSelection().getUnverifiedAddress().getOrganisationName());
        unverifiedAddress.setContactKnownName(command.getEventBody().getSelection().getUnverifiedAddress().getContactKnownName());
        return unverifiedAddress;
    }

    private List<MinimumScore> getMinimumScoreData(MinimumScoreNodeV1ORS minimumScoreNodeV1, Selection selection) {
        List<MinimumScore> minimumScoreList = selection.getMinimumScores();
        minimumScoreList.clear();
        if (Objects.nonNull(minimumScoreNodeV1.getComponentMinimumScores())) {
            minimumScoreNodeV1.getComponentMinimumScores().forEach(e -> {
                MinimumScore uaMinimumScore = new MinimumScore();
                uaMinimumScore.setMinimumScoreUuid(UUID.randomUUID());
                uaMinimumScore.setMinimumScoreValue(e.getMinimumScore());
                uaMinimumScore.setComponent(ComponentEnum.valueOf(e.getComponent().toString()));
                uaMinimumScore.setUpdatedDatetime(OffsetDateTime.now(UTC));
                uaMinimumScore.setSelection(selection);
                minimumScoreList.add(uaMinimumScore);
            });
        }
        return minimumScoreList;
    }


    private SelectionDataBody buildSelectionBody(ROSelectionCommand command) {
        Optional<Selection> selection = selectionRepository.findByExternalSelectionUuid(command.getEventBody().getSelection().getExternalSelectionUuid());
        Optional<Booking> booking = bookingRepository.findByExternalBookingUuid(command.getEventBody().getExternalBookingUuid());

        SelectionDataBody selectionDataBody = new SelectionDataBody();
        selectionDataBody.setEventDateTime(command.getEventHeaders().getEventDateTime());
        selectionDataBody.setSelectionEntity(selection.orElse(null));
        selectionDataBody.setBookingEntity(booking.orElse(null));
        selectionDataBody.setOrganisationEntity(null);
        selectionDataBody.setExternalBookingUuid(command.getEventBody().getExternalBookingUuid());
        selectionDataBody.setSelection(command.getEventBody().getSelection());
        selectionDataBody.setExternalBookingReference(command.getEventBody().getExternalBookingReference());
        return selectionDataBody;
    }

    private SelectionAggregate buildSelectionAggregate(final ROSelectionCommand command) {
        Optional<Selection> selection = selectionRepository.findByExternalSelectionUuid(command.getEventBody().getSelection().getExternalSelectionUuid());
        Optional<Booking> booking = bookingRepository.findByExternalBookingUuid(command.getEventBody().getExternalBookingUuid());

        //Build Selection Aggregate based on the available data
        return SelectionAggregate.builder()
                .command(command)
                .selection(selection.orElse(null))
                .booking(booking.orElse(null))
                .build();
    }

    private List<ConstraintViolation<SelectionDataBody>> convertToSelectionDataBodyViolations(final SelectionDataBody selectionDataBody, Set<ConstraintViolation<SelectionAggregate>> aggregateViolations) {
        return aggregateViolations.stream()
                .map(aggregateConstraintViolation ->
                        ConstraintViolationUtils.createNewConstraintViolation(SelectionDataBody.class,
                                selectionDataBody,
                                aggregateConstraintViolation.getMessage(),
                                aggregateConstraintViolation.getPropertyPath().toString()))
                .collect(Collectors.toList());
    }

    public BaseEvent<BaseHeader> getPublishingEvent(com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1 outOrganisationSelectionNodeV1, ROSelectionCommand command) throws JsonProcessingException {
        BaseEvent<BaseHeader> publishingEvent = new BaseEvent<>();

        publishingEvent.setEventHeader(buildHeader(command.getEventHeaders() , command));
        publishingEvent.setEventBody(objectMapper.writeValueAsString(outOrganisationSelectionNodeV1));

        return publishingEvent;
    }

    public BaseHeader buildHeader(BaseHeader eventHeader, ROSelectionCommand command){
        BaseHeader baseHeader = new BaseHeader();
        baseHeader.setEventName(RECEIVING_ORGANISATION_SELECTION_CHANGED);
        baseHeader.setTransactionId(eventHeader.getTransactionId());
        baseHeader.setCorrelationId(eventHeader.getCorrelationId());
        baseHeader.setEventDateTime(LocalDateTime.now());
        baseHeader.setPartnerCode(eventHeader.getPartnerCode());
        Map<String, String> eventContext = Optional
                .ofNullable(command.getEventHeaders().getEventContext())
                .orElseGet(HashMap::new);
        eventContext.put("externalSelectionUuid", command.getEventBody().getSelection().getExternalSelectionUuid().toString());
        baseHeader.setEventContext(eventContext);

        return baseHeader;
    }

    public BaseEvent<BaseHeader> buildErrorDomainEvent(final BaseHeader baseHeader, final String rejectedEventName,
                                                       final Set<ConstraintViolation<SelectionDataBody>> violation, final ROSelectionCommand command) throws JsonProcessingException {
        baseHeader.setEventName(rejectedEventName);
        String pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
        OffsetDateTime localDT = OffsetDateTime.parse(baseHeader.getEventDateTimeAsString());
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(pattern);
        baseHeader.setEventDateTime(
                LocalDateTime.ofInstant(Instant.parse(dateTimeFormatter.format(localDT)), ZoneOffset.UTC));
        CMDSErrorResponse eventErrors = errorResolver.populatErrorResponse(violation, rejectedEventName);
        BaseEventErrors baseEventErrors = new BaseEventErrors(eventErrors.getErrorList());
        String eventBody = getEventBodyForSelectionEvents(command.getEventBody().getSelection().getExternalSelectionUuid());
        return new BaseEvent<>(baseHeader, eventBody, baseEventErrors, command.getAudit());
    }

    @Override
    protected ObjectMapper getObjectMapper() {
        return this.objectMapper;
    }

    @Override
    protected BuildOrganisationSelectionNodeV1Utils getBuildOrganisationSelectionNodeV1Utils() {
        return this.buildOrganisationSelectionNodeV1Utils;
    }

    @Override
    protected SelectionRepository getSelectionRepository() {
        return this.selectionRepository;
    }


}
