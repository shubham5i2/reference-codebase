package com.ielts.cmds.rd.domain.utils;

import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.infrastructure.event.publishers.RDEventPublisher;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class DomainEventsPublisher {
    private final ApplicationEventPublisher applicationEventPublisher;

    private final RDEventPublisher rdEventPublisher;


    public void baseEventListPublisher(List<BaseEvent<BaseHeader>> eventList) {
        eventList.forEach(e ->  log.debug("List of Events to be published: {}",
                e.getEventHeader().getEventName()));

        try {
            eventList.forEach(applicationEventPublisher::publishEvent);
            eventList.forEach((i->log.info("Event being Published from {} with metadata as {} and error as {}",
                    RDConstants.GenericConstants.RD,
                    i.getEventHeader(),
                    i.getEventErrors())));

        }catch (Exception e){
            log.info("Exception while publishing event list",e);
        }
    }

    public void uiEventListPublisher(List<BaseEvent<UiHeader>> eventList) {
        eventList.forEach(e ->  log.debug("List of Events to be published: {}",
                e.getEventHeader().getEventName()));

        try {
            eventList.forEach(rdEventPublisher::publishEventWithUiHeader);
            eventList.forEach((i->log.info("Event being Published from {} with metadata as {} and error as {}",
                    RDConstants.GenericConstants.RD,
                    i.getEventHeader(),
                    i.getEventErrors())));

        }catch (Exception e){
            log.info("Exception while publishing event list",e);
        }
    }
}
