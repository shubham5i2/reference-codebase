package com.ielts.cmds.rd.application.factories;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ielts.cmds.common.config.IApplicationService;
import com.ielts.cmds.rd.application.exception.ApplicationServiceNotFoundException;
import com.ielts.cmds.rd.infrastructure.event.utils.PatternMatcher;


/**
 * Application service factory class which will map each of the application
 * service implementing {@link IApplicationService} with its service identifier
 * so that it can return the proper application service when called with a valid
 * <b>service identifier</b>
 *
 * @author Monjure Alam
 */
@Component
public class ApplicationServiceFactory {

    private final List<IApplicationService> iApplicationServices;

    @Autowired
    public ApplicationServiceFactory(final List<IApplicationService> iApplicationServices) {
        this.iApplicationServices = iApplicationServices;
    }

    public IApplicationService getService(String eventName) {
        if (iApplicationServices == null) {
            throw new ApplicationServiceNotFoundException("Failed to find a application service with type of IApplicationService : " + eventName);
        }
        return iApplicationServices.stream()
                .filter(e -> PatternMatcher.isMatched(e.getServiceIdentifier(), eventName))
                .findFirst()
                .orElseThrow(() -> new ApplicationServiceNotFoundException("Service not found for  event name- " + eventName));
    }

}
