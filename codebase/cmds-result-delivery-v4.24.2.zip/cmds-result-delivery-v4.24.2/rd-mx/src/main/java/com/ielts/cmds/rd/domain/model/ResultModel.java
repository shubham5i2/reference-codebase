package com.ielts.cmds.rd.domain.model;

import com.ielts.cmds.rd.infrastructure.entity.Result;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class ResultModel extends Result {

    private List<ResultLineModel> resultLineModelList;
}
