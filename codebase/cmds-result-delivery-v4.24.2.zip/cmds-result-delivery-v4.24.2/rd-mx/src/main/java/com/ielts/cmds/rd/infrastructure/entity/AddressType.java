package com.ielts.cmds.rd.infrastructure.entity;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.OffsetDateTime;
import java.util.UUID;

@Data
@ToString
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "address_type")
public class AddressType {

    @Id
    @Column(name = "address_type_uuid")
    private UUID addressTypeUuid;

    @Column(name = "address_type_name")
    private String addressTypeName;

    @Column(name = "description")
    private String description;

    @Column(name = "effective_from_date")
    private OffsetDateTime effectiveFromDate;

    @Column(name = "effective_to_date")
    private OffsetDateTime effectiveToDate;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "created_datetime")
    private OffsetDateTime createdDateTime;

    @Column(name = "updated_by")
    private String updatedBy;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDateTime;

    @Column(name = "concurrency_version")
    private Integer concurrencyVersion;

}
