package com.ielts.cmds.rd.infrastructure.entity;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity
@Table(name = "recognised_product")
public class RecognisedProduct implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1518064328466854947L;

	@Id
    @Column(name = "recognised_product_uuid")
    private UUID recognisedProductUuid;

    @Column(name = "product_uuid")
    private UUID productUuid;

    @Column(name = "effective_from_datetime")
    private OffsetDateTime effectiveFromDatetime;

    @Column(name = "effective_to_datetime")
    private OffsetDateTime effectiveToDatetime;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "recognising_organisation_uuid")
    private RecognisingOrganisation recognisingOrganisation;
}
