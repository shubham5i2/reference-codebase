package com.ielts.cmds.rd.domain.utils;

import com.ielts.cmds.rd.domain.model.enums.ComponentEnum;
import com.ielts.cmds.rd.domain.model.out.BookingLinkNodeV1;
import com.ielts.cmds.rd.domain.model.out.LinkBookingNodeV1;
import com.ielts.cmds.rd.domain.model.out.ResultDeliveryBookingLineNodeV1;
import com.ielts.cmds.rd.domain.model.out.ResultDeliveryBookingNodeV1;
import com.ielts.cmds.rd.infrastructure.entity.Booking;
import com.ielts.cmds.rd.infrastructure.entity.BookingLine;
import com.ielts.cmds.rd.infrastructure.entity.BookingLink;
import com.ielts.cmds.rd.infrastructure.entity.Product;
import com.ielts.cmds.rd.infrastructure.repositories.BookingRepository;
import com.ielts.cmds.rd.infrastructure.repositories.ProductRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class BuildResultDeliveryBookingNodeV1Utils {

    private final BookingRepository bookingRepository;

    private final ProductRepository productRepository;

    public ResultDeliveryBookingNodeV1 buildResultDeliveryBookingNodeV1(UUID bookingUuid) {
        ResultDeliveryBookingNodeV1 bookingNodeV1 = new ResultDeliveryBookingNodeV1();
        if (Objects.nonNull(bookingUuid)) {
            Optional<Booking> optionalBooking = bookingRepository.findById(bookingUuid);
            if (optionalBooking.isPresent()) {
                Booking booking = optionalBooking.get();
                bookingNodeV1.setBookingUuid(booking.getBookingUuid());
                bookingNodeV1.setExternalBookingUuid(booking.getExternalBookingUuid());
                bookingNodeV1.setExternalBookingReference(booking.getExternalBookingReference());
                bookingNodeV1.setShortCandidateNumber(booking.getShortCandidateNumber());
                bookingNodeV1.setPartnerCode(booking.getPartnerCode());
                bookingNodeV1.setLocationUuid(booking.getLocationUuid());
                bookingNodeV1.setProductUuid(booking.getProductUuid());
                bookingNodeV1.setTestDate(booking.getTestDate());
                bookingNodeV1.setBookingStatus(booking.getBookingStatus());
                bookingNodeV1.setBookingDetailStatus(booking.getBookingDetailStatus());
                bookingNodeV1.setAgentName(booking.getAgentName());
                bookingNodeV1.setUniqueTestTakerUuid(booking.getUniqueTestTakerUuid());
                bookingNodeV1.setCompositeCandidateNumber(booking.getCompositeCandidateNumber());
                bookingNodeV1.setExternalUniqueTestTakerUuid(booking.getExternalUniqueTestTakerUuid());
                bookingNodeV1.setIdentityNumber(booking.getIdentityNumber());
                bookingNodeV1.setIdentityTypeUuid(booking.getIdentityTypeUuid());
                bookingNodeV1.setIdentityIssuingAuthority(booking.getIdentityIssuingAuth());
                bookingNodeV1.setIdentityExpiryDate(booking.getIdentityExpiryDate());
                bookingNodeV1.setFirstName(booking.getFirstName());
                bookingNodeV1.setLastName(booking.getLastName());
                bookingNodeV1.setBirthDate(booking.getBirthDate());
                bookingNodeV1.setSexUuid(booking.getSexUuid());
                bookingNodeV1.setEmail(booking.getEmail());
                bookingNodeV1.setTitle(booking.getTitle());
                bookingNodeV1.setPhone(booking.getPhone());
                bookingNodeV1.setMobile(booking.getMobile());
                bookingNodeV1.setLanguageUuid(booking.getLanguageUuid());
                bookingNodeV1.setNationalityUuid(booking.getNationalityUuid());
                bookingNodeV1.setAddressLine1(booking.getAddressLine1());
                bookingNodeV1.setAddressLine2(booking.getAddressLine2());
                bookingNodeV1.setAddressLine3(booking.getAddressLine3());
                bookingNodeV1.setAddressLine4(booking.getAddressLine4());
                bookingNodeV1.setStateTerritoryUuid(booking.getStateTerritoryUuid());
                bookingNodeV1.setPostalCode(booking.getPostalCode());
                bookingNodeV1.setCity(booking.getCity());
                bookingNodeV1.setCountryUuid(booking.getCountryUuid());
                bookingNodeV1.setYearsOfStudy(booking.getYearsOfStudy());
                bookingNodeV1.setOccupationSectorUuid(booking.getOccupationSectorUuid());
                bookingNodeV1.setOccupationLevelUuid(booking.getOccupationLevelUuid());
                bookingNodeV1.setReasonForTestUuid(booking.getReasonForTestUuid());
                List<ResultDeliveryBookingLineNodeV1> bookingLineNodeV1List = booking.getBookingLines().stream()
                        .map(this::setBookingLineList).collect(Collectors.toList());
                bookingNodeV1.setBookingLines(bookingLineNodeV1List);
                if (Objects.nonNull(booking.getBookingLink()) && !booking.getBookingLink().isEmpty()) {
                    List<BookingLinkNodeV1> bookingLinkNodeV1List = booking.getBookingLink().stream()
                            .map(this::setBookingLinkList).collect(Collectors.toList());
                    bookingNodeV1.setBookingLinks(bookingLinkNodeV1List);
                }
            }
        }
        return bookingNodeV1;
    }

    public ResultDeliveryBookingLineNodeV1 setBookingLineList(BookingLine bookingLine) {
        Optional<Product> product = productRepository.findById(bookingLine.getProductUuid());
        ResultDeliveryBookingLineNodeV1 bookingLineNodeV1 = new ResultDeliveryBookingLineNodeV1();
        bookingLineNodeV1.setBookingLineUuid(bookingLine.getBookingLineUuid());
        bookingLineNodeV1.setProductUuid(bookingLine.getProductUuid());
        bookingLineNodeV1.setExternalBookingLineUuid(bookingLine.getExternalBookingLineUuid());
        bookingLineNodeV1.setBookingLineStatus(bookingLine.getBookingLineStatus());
        product.ifPresent(value -> bookingLineNodeV1.setComponentName(ComponentEnum.valueOf(value.getComponent().getValue())));
        return bookingLineNodeV1;
    }

    public BookingLinkNodeV1 setBookingLinkList(BookingLink bookingLink) {
        BookingLinkNodeV1 bookingLinkNodeV1 = new BookingLinkNodeV1();
        Optional<Booking> optionalBooking = bookingRepository.findById(bookingLink.getTargetBookingUuid());
        if (optionalBooking.isPresent()) {
            Booking booking = optionalBooking.get();
            LinkBookingNodeV1 linkBookingNodeV1 = new LinkBookingNodeV1();
            linkBookingNodeV1.setBookingUuid(booking.getBookingUuid());
            linkBookingNodeV1.setExternalBookingUuid(booking.getExternalBookingUuid());
            linkBookingNodeV1.setProductUuid(booking.getProductUuid());
            linkBookingNodeV1.setLocationUuid(booking.getLocationUuid());
            linkBookingNodeV1.setTestDate(booking.getTestDate());
            linkBookingNodeV1.setShortCandidateNumber(booking.getShortCandidateNumber());
            bookingLinkNodeV1.setLinkedBooking(linkBookingNodeV1);
            bookingLinkNodeV1.setRole(bookingLink.getRole());
        }
        return bookingLinkNodeV1;
    }
}
