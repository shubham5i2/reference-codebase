package com.ielts.cmds.rd.domain.command;

import com.ielts.cmds.application.command.BaseCommand;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ReportGeneratedChangeAnalysisCommand  extends BaseCommand<BaseHeader, ResultReleasedNodeV1> {

    @Builder
    public ReportGeneratedChangeAnalysisCommand(final BaseHeader eventHeader, final ResultReleasedNodeV1 eventBody,
                                          final BaseEventErrors eventErrors, final BaseAudit eventAudit) {
        super(eventHeader, eventBody, eventErrors, eventAudit);
    }
}
