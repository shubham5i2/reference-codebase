package com.ielts.cmds.rd.infrastructure.entity;

import com.ielts.cmds.organisation.common.enums.ComponentEnum;
import com.ielts.cmds.rd.domain.model.enums.FormatEnum;
import com.ielts.cmds.rd.domain.model.enums.ProductStatusEnum;
import lombok.*;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.UUID;

@Entity(name="RDProduct")
@ToString(exclude = "moduleType")
@Table(name = "product")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class Product implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "product_uuid")
    private UUID productUuid;

    @Column(name = "parent_product_uuid")
    private UUID parentProductUuid;

    @Column(name = "legacy_product_id")
    private String legacyProductId;

    @Enumerated(EnumType.STRING)
    @Column(name = "component")
    private ComponentEnum component;

    @Enumerated(EnumType.STRING)
    @Column(name = "format")
    private FormatEnum format;

    @ManyToOne
    @JoinColumn(name = "module_type_uuid", insertable = false, updatable = false, referencedColumnName = "module_type_uuid")
    private ModuleType moduleType;

    @Column(name = "bookable")
    private boolean bookable;

    @Column(name = "approval_required")
    private boolean approvalRequired;

    @Column(name = "available_from_date")
    private LocalDate availableFromDate;

    @Column(name = "available_to_date")
    private LocalDate availableToDate;

    @Column(name = "product_name")
    private String productName;

    @Column(name = "product_description")
    private String productDescription;

    @Column(name = "duration")
    private Integer duration;

    @Enumerated(EnumType.STRING)
    @Column(name = "product_status")
    private ProductStatusEnum productStatus;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "created_datetime")
    private OffsetDateTime createdDatetime;

    @Column(name = "updated_by")
    private String updatedBy;

    @Version
    @Column(name = "concurrency_version")
    private Integer concurrencyVersion;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;

    @Column(name = "product_characteristics")
    private String productCharacteristics;
}
