package com.ielts.cmds.rd.domain.validators.selection;

import com.ielts.cmds.ors.common.enums.ConfirmationStatusEnum;
import com.ielts.cmds.rd.domain.model.SelectionDataBody;
import com.ielts.cmds.rd.domain.utils.ValidatorUtils;
import com.ielts.cmds.rd.domain.validators.selection.validation.ValidSelectionData;
import com.ielts.cmds.rd.infrastructure.entity.Booking;
import com.ielts.cmds.rd.infrastructure.entity.Selection;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Objects;
import java.util.Optional;

/**
 * This validator will validate mandatory selection data from incoming event
 */

@Component
public class SelectionDataValidator implements ConstraintValidator<ValidSelectionData, SelectionDataBody> {

    @Override
    public boolean isValid(final SelectionDataBody selectionDataBody, final ConstraintValidatorContext context) {
        context.disableDefaultConstraintViolation();

        boolean isValid = true;
        //Check if ExternalSelectionUuid is not present
        if (Objects.isNull(selectionDataBody.getSelection().getExternalSelectionUuid())) {
            isValid = false;
            ValidatorUtils.addConstraintValidatorAndReturn(context,
                    "{cmds.invalid.externalSelectionUuid.null}", "selection.externalSelectionUuid");
        }

        // minimum scores should not be present for confirmed selection
        if (selectionDataBody.getSelection().getConfirmationStatus() == ConfirmationStatusEnum.CONFIRMED && Objects.nonNull(selectionDataBody.getSelection().getMinimumScore())) {
            isValid = false;
            ValidatorUtils.addConstraintValidatorAndReturn(context,
                    "{cmds.invalid.minimumScoreIsNotNull}", "selection.minimumScore");
        }

        //Check if externalBookingUuid is present in selection event
        if (Objects.isNull(selectionDataBody.getExternalBookingUuid())) {
            isValid = false;
            ValidatorUtils.addConstraintValidatorAndReturn(context,
                    "{cmds.invalid.externalBookingUuid}", "externalBookingUuid");
        }

        //Check if organisationUuid is present in selection event when unverified address is null
        if (Objects.isNull(selectionDataBody.getSelection().getUnverifiedAddress()) && (Objects.isNull(selectionDataBody.getSelection().getOrganisation())
                || Objects.isNull(selectionDataBody.getSelection().getOrganisation().getOrganisationUuid()))) {
            isValid = false;
            ValidatorUtils.addConstraintValidatorAndReturn(context,
                    "{cmds.invalid.organisationUuid}", "selection.organisation.organisationUuid");
        }

        //Chek if organization is available in database when unverified address is null
        if (Objects.isNull(selectionDataBody.getSelection().getUnverifiedAddress()) && !selectionDataBody.getOrganisationEntity().isPresent()) {
            isValid = false;
            ValidatorUtils.addConstraintValidatorAndReturn(context,
                    "{cmds.invalid.organizationNotFound}", "selection.organisation.organisationUuid");
        }

        //for unverified address, check for country3ISOCode,addressLine1,organisationName
        if (Objects.nonNull(selectionDataBody.getSelection().getUnverifiedAddress()) && !unverifiedAddressViolation(selectionDataBody, context)) {
            isValid = false;
        }


        // If ORS Selection UUID != CMDS Selection UUID the raise constraint violation
        if (selectionDataBody.getSelectionEntity().isPresent() && !selectionViolation(selectionDataBody, context)) {
            isValid = false;
        }

        Optional<Booking> optionalBooking = selectionDataBody.getBookingEntity();
        if (optionalBooking.isPresent() && !StringUtils.isBlank(selectionDataBody.getExternalBookingReference())
                && !optionalBooking.get().getExternalBookingReference().equalsIgnoreCase(selectionDataBody.getExternalBookingReference())) {

            context.buildConstraintViolationWithTemplate("{cmds.invalid.invalidExternalBookingReference}")
                    .addPropertyNode("externalBookingReference").addConstraintViolation();
            isValid = false;
        }
        return isValid;
    }

    public boolean unverifiedAddressViolation(final SelectionDataBody selectionDataBody, final ConstraintValidatorContext context) {
        boolean isValid = true;
        if (selectionDataBody.getSelection().getUnverifiedAddress().getAddress().getAddressLine1().trim().isEmpty()) {
            isValid = false;
            ValidatorUtils.addConstraintValidatorAndReturn(context,
                    "{cmds.invalid.addressLine1IsEmpty}", "selection.unverifiedAddress.address.addressLine1");
        }
        if (selectionDataBody.getSelection().getUnverifiedAddress().getAddress().getCountryIso3Code().trim().isEmpty()) {
            isValid = false;
            ValidatorUtils.addConstraintValidatorAndReturn(context,
                    "{cmds.invalid.countryIso3CodeIsEmpty}", "selection.unverifiedAddress.address.countryIso3Code");
        }
        //check if UA organisation name is empty
        if (selectionDataBody.getSelection().getUnverifiedAddress().getOrganisationName().trim().isEmpty()) {
            isValid = false;
            ValidatorUtils.addConstraintValidatorAndReturn(context,
                    "{cmds.invalid.UAOrganisationName}", "selection.unverifiedAddress.organisationName");
        }
        return isValid;
    }

    public boolean selectionViolation(final SelectionDataBody selectionDataBody, final ConstraintValidatorContext context) {
        Optional<Selection> optionalSelection = selectionDataBody.getSelectionEntity();
        boolean isValid = true;
        if (optionalSelection.isPresent()) {
            if (Objects.nonNull(selectionDataBody.getSelection().getSelectionUuid())
                    && !Objects.equals(selectionDataBody.getSelection().getSelectionUuid(), optionalSelection.get().getSelectionUuid())) {
                isValid = false;
                ValidatorUtils.addConstraintValidatorAndReturn(context,
                        "{cmds.invalid.duplicateSelectionRequest}", "selection.selectionUuid");
            }

            if (Objects.nonNull(selectionDataBody.getExternalBookingUuid()) && !selectionDataBody.getExternalBookingUuid().equals(optionalSelection.get().getExternalBookingUuid())) {
                isValid = false;
                ValidatorUtils.addConstraintValidatorAndReturn(context,
                        "{cmds.invalid.mismatchedExternalBookingUuid}", "externalBookingUuid");
            }

            if (OffsetDateTime.of(selectionDataBody.getEventDateTime(), ZoneOffset.UTC).isBefore(optionalSelection.get().getUpdatedDatetime())) {
                isValid = false;
                ValidatorUtils.addConstraintValidatorAndReturn(context,
                        "{cmds.invalid.updateDateTimeError}", "eventDateTime");
            }

            if (optionalSelection.get().getConfirmationStatus().getValue().equals("WITHDRAWN")) {
                isValid = false;
                ValidatorUtils.addConstraintValidatorAndReturn(context,
                        "{cmds.invalid.confirmationStatus}", "selection.confirmationStatus");
            }
        }
        return isValid;
    }


}
