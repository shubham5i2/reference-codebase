package com.ielts.cmds.rd.domain.utils;

import javax.validation.ConstraintValidatorContext;

public class ValidatorUtils {

    private ValidatorUtils(){}

    public static void addConstraintValidatorAndReturn(ConstraintValidatorContext context, final String errorIdentifier, final String errorPath){
        context.buildConstraintViolationWithTemplate(errorIdentifier)
                .addPropertyNode(errorPath)
                .addConstraintViolation();
    }
}
