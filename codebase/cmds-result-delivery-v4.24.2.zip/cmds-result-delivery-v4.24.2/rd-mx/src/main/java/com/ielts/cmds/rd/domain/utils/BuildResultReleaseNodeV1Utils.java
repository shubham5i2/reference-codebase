package com.ielts.cmds.rd.domain.utils;

import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.rd.application.exception.ResultDeliveryValidationException;
import com.ielts.cmds.rd.domain.model.out.*;
import com.ielts.cmds.rd.infrastructure.entity.*;
import com.ielts.cmds.rd.infrastructure.repositories.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class BuildResultReleaseNodeV1Utils {

    private final ResultRepository resultRepository;

    private final ResultsRenditionRepository resultsRenditionRepository;

    private final BuildResultDeliveryBookingNodeV1Utils resultDeliveryBookingNodeV1Utils;

    private final BuildLocationNodeUtils buildLocationNodeUtils;

    private final TestTakerPhotoRepository testTakerPhotoRepository;

    private final ResultsStatusTypeRepository resultsStatusTypeRepository;

    private final ResultsStatusLabelRepository resultsStatusLabelRepository;

    private final ResultTypeRepository resultTypeRepository;

    private final ResultTrfPrintStatusRepository resultTrfPrintStatusRepository;

    private final ProductRepository productRepository;

    public ResultReleasedNodeV1 buildResultReleasedNodeV1(UUID resultUuid) {
        ResultReleasedNodeV1 resultReleasedNodeV1 = new ResultReleasedNodeV1();
        Optional<Result> optionalResult = resultRepository.findById(resultUuid);
        if (optionalResult.isPresent()) {
            Result result = optionalResult.get();
            if (Objects.nonNull(result.getBookingUuid())) {
                List<TestTakerPhoto> testTakerPhotos = testTakerPhotoRepository.findByBookingUuid(result.getBookingUuid());
                ResultDeliveryBookingNodeV1 resultDeliveryBookingNodeV1 = resultDeliveryBookingNodeV1Utils.buildResultDeliveryBookingNodeV1(result.getBookingUuid());
                List<TTPhotoNodeV1> testTakerDataList = new ArrayList<>();
                if (!testTakerPhotos.isEmpty()) {
                    testTakerDataList.addAll(getTestTakerData(testTakerPhotos));
                }
                return resultReleasedNodeV1.toBuilder()
                        .locationDetails(buildLocationNodeUtils.buildLocationChangeNodeV1List(resultDeliveryBookingNodeV1))
                        .bookingDetails(resultDeliveryBookingNodeV1)
                        .resultDetails(setResultNodeV1(result))
                        .ttPhotoDetails(testTakerDataList)
                        .productDetails(getProductNodeV1(resultDeliveryBookingNodeV1))
                        .build();
            }
        }
        return resultReleasedNodeV1;
    }

    private ResultNodeV1 setResultNodeV1(Result result) {
        ResultNodeV1 resultNodeV1 = new ResultNodeV1();
        List<ResultLineNodeV1> resultLineNodeV1List = result.getResultLines().stream().map(this::getResultLineNodeV1)
                .collect(Collectors.toList());

        List<ResultsRendition> resultsRenditions = resultsRenditionRepository.findByResultUuidOrderByUpdatedDatetimeDesc(result.getResultUuid());
        List<ResultRenditionNodeV1> resultRenditionNodeV1List = new ArrayList<>();
        if (!resultsRenditions.isEmpty()) {
            resultsRenditions.stream().forEach(resultsRendition -> {
                ResultRenditionNodeV1 resultRenditionNodeV1 = new ResultRenditionNodeV1();
                resultRenditionNodeV1.setResultsRenditionUuid(resultsRendition.getResultsRenditionUuid());
                resultRenditionNodeV1.setRenditionTypeUuid(resultsRendition.getRenditionTypeUuid());
                resultRenditionNodeV1.setRenditionDescription(resultsRendition.getRenditionDescription());
                resultRenditionNodeV1.setRenditionFilePath(resultsRendition.getRenditionFilePath());
                resultRenditionNodeV1.setRenditionFileVersion(resultsRendition.getRenditionFileVersion());
                resultRenditionNodeV1.setUpdatedDatetime(resultsRendition.getUpdatedDatetime());

                resultRenditionNodeV1List.add(resultRenditionNodeV1);
            });
        }

        resultNodeV1.setResultUuid(result.getResultUuid());
        resultNodeV1.setResultTypeUuid(result.getResultTypeUuid());
        resultNodeV1.setBookingUuid(result.getBookingUuid());
        resultNodeV1.setResultScore(result.getResultScore());
        resultNodeV1.setTrfNumber(result.getTrfNumber());
        resultNodeV1.setCefrLevel(result.getCefrLevel());
        resultNodeV1.setResultsStatusTypeUuid(result.getResultsStatusTypeUuid());
        resultNodeV1.setResultStatusLabelUuid(result.getResultsStatusLabelUuid());
        resultNodeV1.setStatusUpdatedDatetime(result.getStatusUpdatedDatetime());
        resultNodeV1.setResultStatusComment(result.getResultStatusComment());
        resultNodeV1.setAdministratorComments(result.getAdministratorComments());
        resultNodeV1.setAbsence(false);
        resultNodeV1.setResultLines(resultLineNodeV1List);
        resultNodeV1.setResultRenditions(resultRenditionNodeV1List);

        List<ResultTrfPrintStatus> resultTrfPrintStatusList = resultTrfPrintStatusRepository.findByResultUuid(result.getResultUuid());
        List<ResultDeliveryResultTrfPrintStatusNodeV1> trfPrintStatusNodeV1List = new ArrayList<>();
        if (!resultTrfPrintStatusList.isEmpty()) {

            resultTrfPrintStatusList.stream().forEach(printStatus -> {
                ResultDeliveryResultTrfPrintStatusNodeV1 resultDeliveryResultTrfPrintStatusNodeV1 = new ResultDeliveryResultTrfPrintStatusNodeV1();
                resultDeliveryResultTrfPrintStatusNodeV1.setPrintCount(printStatus.getPrintCount());
                resultDeliveryResultTrfPrintStatusNodeV1.setPrintedBy(printStatus.getPrintedBy());
                resultDeliveryResultTrfPrintStatusNodeV1.setPrintedDatetime(printStatus.getPrintedDateTime());
                resultDeliveryResultTrfPrintStatusNodeV1.setResultTrfPrintStatusUuid(printStatus.getResultTrfPrintStatusUuid());
                resultDeliveryResultTrfPrintStatusNodeV1.setRenditionTypeUuid(printStatus.getRenditionTypeUuid());

                trfPrintStatusNodeV1List.add(resultDeliveryResultTrfPrintStatusNodeV1);
            });
        }
        resultNodeV1.setTrfPrintStatus(trfPrintStatusNodeV1List);
        return resultNodeV1;
    }

    private ResultLineNodeV1 getResultLineNodeV1(ResultLine resultLine) {
        ResultLineNodeV1 resultLineNodeV1 = new ResultLineNodeV1();
        resultLineNodeV1.setResultLineUuid(resultLine.getResultLineUuid());
        resultLineNodeV1.setBookingLineUuid(resultLine.getBookingLineUuid());
        resultLineNodeV1.setResultLineScore(resultLine.getResultLineScore());
        resultLineNodeV1.setProductUuid(resultLine.getProductUuid());
        resultLineNodeV1.setAbsence(false);
        return resultLineNodeV1;
    }

    public List<TTPhotoNodeV1> getTestTakerData(List<TestTakerPhoto> testTakerPhoto) {
        return testTakerPhoto.stream().map(testTakerPhoto1 -> {
            TTPhotoNodeV1 ttPhotoNodeV1 = new TTPhotoNodeV1();
            ttPhotoNodeV1.setBookingUuid(testTakerPhoto1.getBookingUuid());
            ttPhotoNodeV1.setPhotoUuid(testTakerPhoto1.getPhotoUuid());
            ttPhotoNodeV1.setFilePath(testTakerPhoto1.getFilePath());
            ttPhotoNodeV1.setPhotoTypeUuid(testTakerPhoto1.getPhotoTypeUuid());
            ttPhotoNodeV1.setPhotoVersion(testTakerPhoto1.getPhotoVersion());
            ttPhotoNodeV1.setPhotoCategory(testTakerPhoto1.getPhotoCategory());
            return ttPhotoNodeV1;
        }).collect(Collectors.toList());
    }

    public BaseEventErrors getBaseEventErrors(ResultDeliveryValidationException e) {
        BaseEventErrors baseEventErrors;
        List<ErrorDescription> errorDescriptions = new ArrayList<>();
        ErrorDescription errorDescription = new ErrorDescription();
        errorDescription.setMessage(e.getMessage());
        errorDescription.setType(ErrorTypeEnum.VALIDATION);
        errorDescription.setTitle("Validation Failed");
        errorDescription.setErrorCode("V045");
        errorDescriptions.add(errorDescription);
        baseEventErrors = new BaseEventErrors(errorDescriptions);
        return baseEventErrors;
    }

    public BaseEventErrors getResultTypeEventErrors(String msg) {
        BaseEventErrors baseEventErrors;
        List<ErrorDescription> errorDescriptions = new ArrayList<>();
        ErrorDescription errorDescription = new ErrorDescription();
        errorDescription.setMessage(msg);
        errorDescription.setType(ErrorTypeEnum.VALIDATION);
        errorDescription.setTitle("Validation Failed");
        errorDescription.setErrorCode("V045");
        errorDescriptions.add(errorDescription);
        baseEventErrors = new BaseEventErrors(errorDescriptions);
        return baseEventErrors;
    }

    public List<ReferenceDataNodeV1> getReferenceData(Result result) {
        ReferenceDataNodeV1 referenceDataNodeV1 = new ReferenceDataNodeV1();
        ReferenceDataNodeV1 referenceDataNodeV2 = new ReferenceDataNodeV1();
        ReferenceDataNodeV1 referenceDataNodeV3 = new ReferenceDataNodeV1();

        Optional<ResultsStatusType> optionalResultStatusType = Objects.isNull(result.getResultsStatusTypeUuid())
                ? Optional.empty() : resultsStatusTypeRepository.findById(result.getResultsStatusTypeUuid());

        Optional<ResultsStatusLabel> optionalResultStatusLabel = Objects.isNull(result.getResultsStatusLabelUuid())
                ? Optional.empty() : resultsStatusLabelRepository.findById(result.getResultsStatusLabelUuid());

        Optional<ResultType> optionalResultType = Objects.isNull(result.getResultTypeUuid())
                ? Optional.empty() : resultTypeRepository.findById(result.getResultTypeUuid());

        if (optionalResultStatusType.isPresent()) {
            referenceDataNodeV1.setReferenceId(optionalResultStatusType.get().getResultStatusTypeUuid().toString());
            referenceDataNodeV1.setReferenceValue(optionalResultStatusType.get().getResultStatusCode());
        }
        if (optionalResultStatusLabel.isPresent()) {
            referenceDataNodeV2.setReferenceId(optionalResultStatusLabel.get().getResultsStatusLabelUuid().toString());
            referenceDataNodeV2.setReferenceValue(optionalResultStatusLabel.get().getResultsStatusLabelCode());
        }
        if (optionalResultType.isPresent()) {
            referenceDataNodeV3.setReferenceId(optionalResultType.get().getResultTypeUuid().toString());
            referenceDataNodeV3.setReferenceValue(optionalResultType.get().getResultTypeCode());
        }

        return Arrays.asList(referenceDataNodeV1, referenceDataNodeV2, referenceDataNodeV3);

    }

    public ProductNodeV1 getProductNodeV1(ResultDeliveryBookingNodeV1 bookingNodeV1)
    {
        ProductNodeV1 productNodeV1 = new ProductNodeV1();
        if(Objects.nonNull(bookingNodeV1.getProductUuid())) {
            Optional<Product> optionalProduct = productRepository.findById(bookingNodeV1.getProductUuid());
            if(optionalProduct.isPresent()){
                Product product = optionalProduct.get();
                productNodeV1.setProductUuid(product.getProductUuid());
                productNodeV1.setProductCharacteristics(product.getProductCharacteristics());
            }
        }
        return  productNodeV1;
    }
}

