package com.ielts.cmds.rd.domain.validators.selection.validation;

import com.ielts.cmds.rd.domain.validators.selection.SelectionDataValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Constraint(validatedBy = {SelectionDataValidator.class})
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.TYPE })
public @interface ValidSelectionData {

    String message() default "{cmds.invalid.externalSelectionUuid.null}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
