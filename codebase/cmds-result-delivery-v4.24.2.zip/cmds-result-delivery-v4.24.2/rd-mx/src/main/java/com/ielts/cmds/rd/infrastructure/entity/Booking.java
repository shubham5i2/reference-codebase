package com.ielts.cmds.rd.infrastructure.entity;


import com.ielts.cmds.booking.common.enums.BookingDetailStatusEnum;
import com.ielts.cmds.booking.common.enums.BookingStatusEnum;
import lombok.*;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Getter
@Setter
@ToString(exclude = {"bookingLines","bookingLink"})
@Entity
@Table(name = "booking")
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Booking implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1319817545118378032L;

	@Id
    @Column(name = "booking_uuid")
    private UUID bookingUuid;

    @Column(name = "external_booking_uuid")
    private UUID externalBookingUuid;

    @Column(name = "external_booking_reference")
    private String externalBookingReference;

    @Column(name = "location_uuid")
    private UUID locationUuid;

    @Column(name = "product_uuid")
    private UUID productUuid;

    @Column(name = "test_date")
    private LocalDate testDate;

    @Column(name = "short_candidate_number")
    private Integer shortCandidateNumber;

    @Enumerated(EnumType.STRING)
    @Column(name = "booking_status")
    private BookingStatusEnum bookingStatus;

    @Column(name="partner_code")
    private String partnerCode;

    @Enumerated(EnumType.STRING)
    @Column(name = "booking_details_status")
    private BookingDetailStatusEnum bookingDetailStatus;

    @Column(name = "agent_name")
    private String agentName;

    @Column(name = "unique_test_taker_uuid")
    private UUID uniqueTestTakerUuid;

    @Column(name = "external_unique_test_taker_uuid")
    private UUID externalUniqueTestTakerUuid;

    @Column(name = "composite_candidate_number")
    private String compositeCandidateNumber;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "email")
    private String email;

    @Column(name = "identity_number")
    private String identityNumber;

    @Column(name = "identity_type_uuid")
    private UUID identityTypeUuid;

    @Column(name = "identity_issuing_auth")
    private String identityIssuingAuth;

    @Column(name = "identity_expiry_date")
    private LocalDate identityExpiryDate;

    @Column(name = "birth_date")
    private LocalDate birthDate;

    @Column(name = "sex_uuid")
    private UUID sexUuid;

    @Column(name = "title")
    private String title;

    @Column(name = "language_uuid")
    private UUID languageUuid;

    @Column(name = "nationality_uuid")
    private UUID nationalityUuid;

    @Column(name = "phone")
    private String phone;

    @Column(name = "mobile")
    private String mobile;

    @Column(name = "address_line_1")
    private String addressLine1;

    @Column(name = "address_line_2")
    private String addressLine2;

    @Column(name = "address_line_3")
    private String addressLine3;

    @Column(name = "address_line_4")
    private String addressLine4;

    @Column(name = "state_territory_uuid")
    private UUID stateTerritoryUuid;

    @Column(name = "postal_code")
    private String postalCode;

    @Column(name = "city")
    private String city;

    @Column(name = "country_uuid")
    private UUID countryUuid;

    @Column(name = "years_of_study")
    private Integer yearsOfStudy;

    @Column(name = "occupation_sector_uuid")
    private UUID occupationSectorUuid;

    @Column(name = "reason_for_test_uuid")
    private UUID reasonForTestUuid;

    @Column(name = "occupation_level_uuid")
    private UUID occupationLevelUuid;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;

    @Column(name = "event_datetime")
    private OffsetDateTime eventDatetime;

    @Version
    @Column(name = "concurrency_version")
    private Integer concurrencyVersion;

    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(mappedBy = "booking", cascade = CascadeType.ALL)
    private List<BookingLine> bookingLines = new ArrayList<>();

    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(mappedBy = "sourceBookingUuid", cascade = CascadeType.ALL)
    private List<BookingLink> bookingLink = new ArrayList<>();

}

