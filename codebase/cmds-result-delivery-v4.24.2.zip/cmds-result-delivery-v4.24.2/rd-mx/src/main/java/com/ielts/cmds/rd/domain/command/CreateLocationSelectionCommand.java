package com.ielts.cmds.rd.domain.command;

import com.ielts.cmds.application.command.BaseCommand;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.lpr.common.in.model.LocationNode;

import com.ielts.cmds.lpr.common.out.model.LocationV1;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CreateLocationSelectionCommand  extends BaseCommand<BaseHeader, LocationV1>{

	@Builder
	    public CreateLocationSelectionCommand(final BaseHeader eventHeader, final LocationV1 eventBody,
											  final BaseEventErrors eventErrors, final BaseAudit eventAudit) {
	        super(eventHeader, eventBody, eventErrors, eventAudit);
	    }

}
