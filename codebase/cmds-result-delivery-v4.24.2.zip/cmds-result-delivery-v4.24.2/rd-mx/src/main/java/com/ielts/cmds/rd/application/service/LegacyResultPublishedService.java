package com.ielts.cmds.rd.application.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.config.IApplicationService;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.domain.command.LegacyResultPublishCommand;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import com.ielts.cmds.rd.domain.service.LegacyResultDeliveryChangedDomainService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.lang.reflect.InvocationTargetException;

@Service
@RequiredArgsConstructor
@Slf4j
public class LegacyResultPublishedService implements IApplicationService {

    private final ObjectMapper objectMapper;

    private final LegacyResultDeliveryChangedDomainService legacyResultDeliveryDomainService;

    @Override
    public String getServiceIdentifier() {
        return RDConstants.EventType.LEGACY_RESULT_PUBLISHED;
    }

    @Override
    public void process(final BaseEvent<? extends BaseHeader> baseEvent) throws ProcessingException {

        try {
            final BaseHeader eventHeader = baseEvent.getEventHeader();
            final BaseEventErrors eventErrors = baseEvent.getEventErrors();
            final ResultReleasedNodeV1 resultDetailsBody = objectMapper
                    .readValue(baseEvent.getEventBody(), ResultReleasedNodeV1 .class);
            if (resultDetailsBody == null) {
                throw new IllegalArgumentException(RDConstants.GenericConstants.EMPTY_PAYLOAD);
            }

            // build command
            final LegacyResultPublishCommand legacyResultPublishCommand = LegacyResultPublishCommand.builder()
                    .eventHeader(eventHeader).eventBody(resultDetailsBody)
                    .eventErrors(eventErrors).eventAudit(baseEvent.getAudit())
                    .build();

            // Execute command
            legacyResultDeliveryDomainService.on(legacyResultPublishCommand);
        } catch (IllegalArgumentException | JsonProcessingException | InvocationTargetException | IllegalAccessException e) {
            log.error("Failed to process LegacyResultPublished event due to ", e);
            throw new ProcessingException(e.getMessage(), e);
        }

    }
}
