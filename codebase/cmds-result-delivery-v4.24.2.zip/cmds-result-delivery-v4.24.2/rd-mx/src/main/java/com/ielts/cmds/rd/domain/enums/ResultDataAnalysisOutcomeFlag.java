package com.ielts.cmds.rd.domain.enums;

import com.ielts.cmds.rd.domain.RDConstants;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Getter
public enum ResultDataAnalysisOutcomeFlag {

    TT_RESULT_DATA_CHANGED(RDConstants.GenericConstants.TT_RESULT_DATA_CHANGED, "true"),

    TRF_CRITICAL_INFO_CHANGED(RDConstants.GenericConstants.TRF_CRITICAL_INFO_CHANGED, "true"),

    TT_BOOKING_TRANSFERRED(RDConstants.GenericConstants.TT_BOOKING_TRANSFERRED, "true");

    private final String key;

    private final String value;


}
