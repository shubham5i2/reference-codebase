package com.ielts.cmds.rd.infrastructure.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.UUID;

@Data
@Entity
@ToString(exclude = "result")
@Table(name = "result_line")
public class ResultLine implements Serializable{

    /**
     *
     */
    private static final long serialVersionUID = 86183085442690969L;

    @Id
    @Column(name = "result_line_uuid")
    private UUID resultLineUuid;

    @Column(name = "result_line_score")
    private Double resultLineScore;

    @Column(name = "booking_line_uuid")
    private UUID bookingLineUuid;

    @Column(name = "product_uuid")
    private UUID productUuid;

    @Column(name = "absence")
    private boolean absence;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDateTime;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "result_uuid")
    private Result result;

}
