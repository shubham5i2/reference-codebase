package com.ielts.cmds.rd.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.application.command.BaseCommand;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.application.exception.ResultDeliveryValidationException;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.domain.model.enums.DeliveryStatusEnum;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import com.ielts.cmds.rd.domain.utils.BuildResultReleaseNodeV1Utils;
import com.ielts.cmds.rd.infrastructure.entity.Result;
import com.ielts.cmds.rd.infrastructure.entity.ResultDelivery;
import com.ielts.cmds.rd.infrastructure.repositories.ResultRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;

import javax.validation.constraints.NotNull;
import java.lang.reflect.InvocationTargetException;
import java.time.OffsetDateTime;
import java.util.*;

import static java.time.ZoneOffset.UTC;

@Slf4j
@RequiredArgsConstructor
abstract class AbstractResultDeliveryDomainService {
    private final ObjectMapper objectMapper;

    private final ResultRepository resultRepository;

    private final ApplicationEventPublisher applicationEventPublisher;

    private final BuildResultReleaseNodeV1Utils buildResultReleaseNodeV1Utils;


    protected void process(@NotNull final BaseCommand<BaseHeader, ResultReleasedNodeV1> command) throws JsonProcessingException, InvocationTargetException, IllegalAccessException {

        log.info("Received Legacy Result Delivery Changed event with Booking Uuid {} and Result uuid {}",
                command.getEventBody().getResultDetails().getBookingUuid(), command.getEventBody().getResultDetails().getResultUuid());

        Optional<ResultReleasedNodeV1> resultReleasedNodeV1 = Optional.empty();
        String eventBody;
        BaseEvent<BaseHeader> event;
        final BaseHeader eventHeader = new BaseHeader();
        BaseEventErrors baseEventErrors = null;

        try {
            Optional<Result> optionalResult = resultRepository.findById(command.getEventBody().getResultDetails().getResultUuid());

            Result result = optionalResult.orElseThrow(() -> new ResultDeliveryValidationException
                    ("Legacy result delivery changed Event Failed as Result is not Present", new Throwable()));

            setDeliveryStatusForRDChangedEvent(command, result);

            resultReleasedNodeV1 = Optional.of(buildResultReleaseNodeV1Utils.buildResultReleasedNodeV1(result.getResultUuid()));
            eventBody = objectMapper.writeValueAsString(resultReleasedNodeV1);
            buildHeader(resultReleasedNodeV1, command, eventHeader);
        } catch (final ResultDeliveryValidationException e) {
            log.error("LegacyResultPublishCommand execution failed", e);
            eventBody = null;
            baseEventErrors = buildResultReleaseNodeV1Utils.getBaseEventErrors(e);
            buildHeader(resultReleasedNodeV1, command, eventHeader);
        }
        event = new BaseEvent<>(eventHeader, eventBody, baseEventErrors, command.getAudit());

        applicationEventPublisher.publishEvent(event);
    }

    private void setDeliveryStatusForRDChangedEvent(final BaseCommand<BaseHeader, ResultReleasedNodeV1> command, Result result){

        List<ResultDelivery> resultDeliveryList = result.getResultDelivery();
        ResultDelivery resultDelivery = new ResultDelivery();
        Optional<ResultDelivery> latestUpdatedEntry = resultDeliveryList.stream().max(Comparator.comparing(ResultDelivery::getStatusUpdatedDateTime));
        if(latestUpdatedEntry.isPresent()){
            resultDelivery = latestUpdatedEntry.get();
        } else {
            resultDelivery.setResultDeliveryUuid(UUID.randomUUID());
        }
        if ( Objects.isNull(command.getEventErrors())) {
            resultDelivery.setStatus(DeliveryStatusEnum.DELIVERED);
        } else {
            resultDelivery.setStatus(DeliveryStatusEnum.UNDELIVERED);
        }
        resultDelivery.setStatusUpdatedDateTime(OffsetDateTime.now(UTC));
        resultDelivery.setTransactionUuid(command.getEventHeaders().getTransactionId());
        resultDelivery.setSystem(RDConstants.GenericConstants.LA);
        resultDelivery.setResult(result);
        resultDeliveryList.add(resultDelivery);
        result.setResultDelivery(resultDeliveryList);
        resultRepository.save(result);
    }

    private void buildHeader(final Optional<ResultReleasedNodeV1> eventBody,final BaseCommand<BaseHeader, ResultReleasedNodeV1> command, BaseHeader eventHeader) {
        eventHeader.setCorrelationId(command.getEventHeaders().getCorrelationId());
        eventHeader.setEventDateTime(command.getEventHeaders().getEventDateTime());
        eventHeader.setTransactionId(command.getEventHeaders().getTransactionId());
        eventHeader.setPartnerCode(command.getEventHeaders().getPartnerCode());
        eventHeader.setEventContext(command.getEventHeaders().getEventContext());
        if(Objects.nonNull(command.getEventBody().getResultDetails().getResultUuid())){
            eventHeader.getEventContext().put("resultUuid" , command.getEventBody().getResultDetails().getResultUuid().toString());
        }
        if (Objects.isNull(command.getEventErrors()) && eventBody.isPresent() ) {
            eventHeader.setEventName(RDConstants.EventType.LEGACY_RESULT_DELIVERY_CHANGED);
        } else {
            eventHeader.setEventName(RDConstants.EventType.LEGACY_RESULT_DELIVERY_CHANGE_FAILED);
        }
    }

}