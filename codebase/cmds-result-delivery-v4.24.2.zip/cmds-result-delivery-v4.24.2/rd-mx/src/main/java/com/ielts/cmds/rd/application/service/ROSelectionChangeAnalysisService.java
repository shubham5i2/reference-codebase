package com.ielts.cmds.rd.application.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.config.IApplicationService;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.domain.command.ROSelectionChangeAnalysisCommand;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;
import com.ielts.cmds.rd.domain.service.ROSelectionChangeAnalysisDomainService;
import com.ielts.cmds.rd.domain.service.UASelectionChangeAnalysisDomainService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
@RequiredArgsConstructor
@Slf4j
public class ROSelectionChangeAnalysisService implements IApplicationService {

    private final ObjectMapper objectMapper;

    private final ROSelectionChangeAnalysisDomainService roSelectionChangeAnalysisDomainService;

    private final UASelectionChangeAnalysisDomainService uaSelectionChangeAnalysisDomainService;

    @Override
    public void process(BaseEvent<? extends BaseHeader> baseEvent) throws ProcessingException {
        try {
            final BaseHeader eventHeader = baseEvent.getEventHeader();
            final BaseEventErrors eventErrors = baseEvent.getEventErrors();
            OrganisationSelectionNodeV1 organisationSelectionNodeV1 = null;
            if (Objects.nonNull(baseEvent.getEventBody()))
                organisationSelectionNodeV1 = objectMapper
                        .readValue(baseEvent.getEventBody(), OrganisationSelectionNodeV1.class);

            //build command
            final ROSelectionChangeAnalysisCommand roSelectionChangeAnalysisCommand = ROSelectionChangeAnalysisCommand.builder()
                    .eventHeader(eventHeader).eventBody(organisationSelectionNodeV1)
                    .eventErrors(eventErrors).eventAudit(baseEvent.getAudit()).build();

            //execute command
            if((Objects.nonNull(organisationSelectionNodeV1) && Objects.isNull(organisationSelectionNodeV1.getOrganisationDetails())))
                uaSelectionChangeAnalysisDomainService.on(roSelectionChangeAnalysisCommand);
            else
                roSelectionChangeAnalysisDomainService.on(roSelectionChangeAnalysisCommand);


        } catch (IllegalArgumentException | JsonProcessingException e) {
            log.error("Failed to process Receiving Organisation Selection Changed event due to ", e);
            throw new ProcessingException(e.getMessage(), e);
        }
    }

    @Override
    public String getServiceIdentifier() {
        return RDConstants.EventType.RECEIVING_ORGANISATION_SELECTION_CHANGED;
    }

}
