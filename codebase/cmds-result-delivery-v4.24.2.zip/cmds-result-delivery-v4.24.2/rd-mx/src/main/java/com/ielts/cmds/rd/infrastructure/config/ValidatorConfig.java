package com.ielts.cmds.rd.infrastructure.config;

import java.util.Map;

import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.hibernate.validator.HibernateValidator;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.validation.beanvalidation.SpringConstraintValidatorFactory;

import com.ielts.cmds.common.exception.util.CMDSErrorResolver;

import lombok.Getter;
import lombok.Setter;

@Configuration
@PropertySource("classpath:errorCode.properties")
@ConfigurationProperties(prefix = "cmds")
@Getter
@Setter
public class ValidatorConfig<T> {

	private Map<String, String> errorCode;

	@Bean
	public Validator validator(final AutowireCapableBeanFactory autowireCapableBeanFactory) {

		ValidatorFactory validatorFactory =
				Validation.byProvider(HibernateValidator.class)
						.configure()
						.constraintValidatorFactory(
								new SpringConstraintValidatorFactory(autowireCapableBeanFactory))
						.buildValidatorFactory();
		return validatorFactory.getValidator();
	}

	@Bean
	public CMDSErrorResolver<T> errorResolver() {
		return new CMDSErrorResolver<>(errorCode);
	}


}
