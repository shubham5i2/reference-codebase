


package com.ielts.cmds.rd.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.domain.command.ROSelectionChangeAnalysisCommand;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.constraints.NotNull;

import java.time.LocalDateTime;

import static com.ielts.cmds.rd.domain.RDConstants.EventType.NO_ACTION_TAKEN;

@Service
@Slf4j
@RequiredArgsConstructor
public class UASelectionChangeAnalysisDomainService {

    private final ObjectMapper objectMapper;

    private final ApplicationEventPublisher applicationEventPublisher;


    @Transactional
    @SneakyThrows
    public void on(@NotNull ROSelectionChangeAnalysisCommand command) throws JsonProcessingException {

        applicationEventPublisher.publishEvent(getPublishingEvent(command));

    }

    public BaseEvent<BaseHeader> getPublishingEvent(ROSelectionChangeAnalysisCommand command) throws JsonProcessingException {
        BaseEvent<BaseHeader> publishingEvent = new BaseEvent<>();

        publishingEvent.setEventHeader(buildHeader(command.getEventHeaders()));
        publishingEvent.setEventBody(objectMapper.writeValueAsString(command.getEventBody()));
        publishingEvent.setEventErrors(null);
        log.info("publishing NoActionTaken event as the event body is for UA selection");
        return publishingEvent;
    }

    private BaseHeader buildHeader(BaseHeader eventHeader) {
        BaseHeader baseHeader = new BaseHeader();
        baseHeader.setEventName(NO_ACTION_TAKEN);
        baseHeader.setTransactionId(eventHeader.getTransactionId());
        baseHeader.setCorrelationId(eventHeader.getCorrelationId());
        baseHeader.setEventDateTime(LocalDateTime.now());
        baseHeader.setPartnerCode(eventHeader.getPartnerCode());
        baseHeader.setEventContext(eventHeader.getEventContext());

        return baseHeader;
    }


}