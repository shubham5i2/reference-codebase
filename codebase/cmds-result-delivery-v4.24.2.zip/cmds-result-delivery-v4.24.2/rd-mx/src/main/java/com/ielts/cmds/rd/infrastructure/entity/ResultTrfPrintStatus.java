package com.ielts.cmds.rd.infrastructure.entity;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.UUID;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "result_trf_print_status")
public class ResultTrfPrintStatus implements Serializable {

    private static final long serialVersionUID = 86184085442690959L;

    @Id
    @Column(name = "result_trf_print_status_uuid")
    private UUID resultTrfPrintStatusUuid;

    @Column(name = "result_uuid")
    private UUID resultUuid;

    @Column(name = "printed_datetime")
    private OffsetDateTime printedDateTime;

    @Column(name = "print_count")
    private Integer printCount;

    @Column(name = "results_rendition_uuid")
    private UUID resultsRenditionUuid;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDateTime;

    @Column(name = "printed_by")
    private String printedBy;

    @Column(name = "rendition_type_uuid")
    private UUID renditionTypeUuid;

    @ManyToOne
    @JoinColumn(name = "result_uuid", insertable = false, nullable = false, updatable = false, referencedColumnName = "result_uuid")
    private Result result;

}
