package com.ielts.cmds.rd.infrastructure.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ielts.cmds.rd.domain.model.enums.LinkTypeEnum;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.UUID;

@Data
@ToString(exclude = "sourceRecognisingOrganisationUuid")
@Entity
@Table(name = "linked_recognising_organisation")
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LinkedRecognisingOrganisation implements Serializable {

    private static final long serialVersionUID = 1518064328466854939L;

    @Id
    @Column(name = "linked_recognising_organisation_uuid")
    private UUID linkedRecognisingOrganisationUuid;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "source_recognising_organisation_uuid")
    private RecognisingOrganisation recognisingOrganisation;

    @Column(name = "target_recognising_organisation_uuid")
    private UUID targetRecognisingOrganisationUuid;

    @Enumerated(EnumType.STRING)
    @Column(name = "linked_recognising_organisation_type")
    private LinkTypeEnum linkedRecognisingOrganisationType;

    @Column(name = "link_effective_from_datetime")
    private OffsetDateTime linkEffectiveFromDatetime;

    @Column(name = "link_effective_to_datetime")
    private OffsetDateTime linkEffectiveToDatetime;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;

    @Column(name = "deleted")
    private Boolean deleted;
}
