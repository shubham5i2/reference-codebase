package com.ielts.cmds.rd.domain.utils;


import com.ielts.cmds.rd.domain.model.out.ResultDeliveryLinkedRecognisingOrganisationV1;
import com.ielts.cmds.rd.domain.model.out.ResultDeliveryRONodeV1;
import com.ielts.cmds.rd.domain.model.out.ResultDeliveryRecognisedProductNodeV1;
import com.ielts.cmds.rd.infrastructure.entity.LinkedRecognisingOrganisation;
import com.ielts.cmds.rd.infrastructure.entity.RecognisedProduct;
import com.ielts.cmds.rd.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.rd.infrastructure.repositories.RecognisingOrganisationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class BuildResultDeliveryRONodeV1Utils {

    private final RecognisingOrganisationRepository recognisingOrganisationRepository;

    public ResultDeliveryRONodeV1 buildResultDeliveryRONodeV1(UUID recognisingOrganisationUuid) {
        ResultDeliveryRONodeV1 resultDeliveryRONodeV1 = new ResultDeliveryRONodeV1();
        if (Objects.nonNull(recognisingOrganisationUuid)) {
            Optional<RecognisingOrganisation> optionalRecognisingOrganisation = recognisingOrganisationRepository.findById(recognisingOrganisationUuid);
            if (optionalRecognisingOrganisation.isPresent()) {
                RecognisingOrganisation recognisingOrganisation = optionalRecognisingOrganisation.get();
                resultDeliveryRONodeV1.setRecognisingOrganisationUuid(recognisingOrganisation.getRecognisingOrganisationUuid());
                resultDeliveryRONodeV1.setOrganisationTypeUuid(recognisingOrganisation.getOrganisationTypeUuid());
                resultDeliveryRONodeV1.setOrganisationId(recognisingOrganisation.getOrganisationId());
                resultDeliveryRONodeV1.setName(recognisingOrganisation.getName());
                resultDeliveryRONodeV1.setVerificationStatus(recognisingOrganisation.getVerificationStatus());
                resultDeliveryRONodeV1.setPartnerCode(recognisingOrganisation.getPartnerCode());
                resultDeliveryRONodeV1.setMethodOfDelivery(recognisingOrganisation.getMethodOfDelivery());
                resultDeliveryRONodeV1.setParentRecognisingOrganisationUuid(recognisingOrganisation.getParentRecognisingOrganisationUuid());
                resultDeliveryRONodeV1.setOrganisationStatus(recognisingOrganisation.getOrganisationStatus());
                resultDeliveryRONodeV1.setOrganisationCode(recognisingOrganisation.getOrganisationCode());
                resultDeliveryRONodeV1.setReplacedByRecognisingOrganisationUuid(recognisingOrganisation.getReplacedByRecognisingOrganisationUuid());
                List<ResultDeliveryRecognisedProductNodeV1> recognisedProductNodeV1List = recognisingOrganisation.getRecognisedProducts().stream()
                        .map(this::getRecognisingProductNodeV1).collect(Collectors.toList());
                resultDeliveryRONodeV1.setRecognisedProducts(recognisedProductNodeV1List);
                if(Objects.nonNull(recognisingOrganisation.getLinkedRecognisingOrganisations())) {
                    List<ResultDeliveryLinkedRecognisingOrganisationV1> linkedRecognisingOrganisationV1List = recognisingOrganisation.getLinkedRecognisingOrganisations().stream()
                            .filter(e -> e.getDeleted().equals(false))
                            .map(this::getLinkedRecognisingOrganisationNodeV1).collect(Collectors.toList());
                    resultDeliveryRONodeV1.setLinkedOrganisations(linkedRecognisingOrganisationV1List);
                } else {
                    resultDeliveryRONodeV1.setLinkedOrganisations(null);
                }
            }
        }
        return resultDeliveryRONodeV1;
    }

    private ResultDeliveryLinkedRecognisingOrganisationV1 getLinkedRecognisingOrganisationNodeV1(LinkedRecognisingOrganisation linkedRecognisingOrganisation) {
        ResultDeliveryLinkedRecognisingOrganisationV1 resultDeliveryLinkedRecognisingOrganisationV1 = new ResultDeliveryLinkedRecognisingOrganisationV1();
        resultDeliveryLinkedRecognisingOrganisationV1.setLinkedOrganisationUuid(linkedRecognisingOrganisation.getLinkedRecognisingOrganisationUuid());
        resultDeliveryLinkedRecognisingOrganisationV1.setLinkEffectiveFromDateTime(linkedRecognisingOrganisation.getLinkEffectiveFromDatetime());
        resultDeliveryLinkedRecognisingOrganisationV1.setLinkEffectiveToDateTime(linkedRecognisingOrganisation.getLinkEffectiveToDatetime());
        resultDeliveryLinkedRecognisingOrganisationV1.setLinkType(linkedRecognisingOrganisation.getLinkedRecognisingOrganisationType());
        return resultDeliveryLinkedRecognisingOrganisationV1;
    }

    private ResultDeliveryRecognisedProductNodeV1 getRecognisingProductNodeV1(RecognisedProduct e) {
        ResultDeliveryRecognisedProductNodeV1 recognisedProductNodeV1 = new ResultDeliveryRecognisedProductNodeV1();
        recognisedProductNodeV1.setProductUuid(e.getProductUuid());
        recognisedProductNodeV1.setRecognisedProductUuid(e.getRecognisedProductUuid());
        recognisedProductNodeV1.setEffectiveFromDateTime(e.getEffectiveFromDatetime());
        recognisedProductNodeV1.setEffectiveToDateTime(e.getEffectiveToDatetime());
        return recognisedProductNodeV1;
    }
}
