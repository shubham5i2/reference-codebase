package com.ielts.cmds.rd.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.domain.command.SelectionDeliveryStatusUpdateCommand;
import com.ielts.cmds.rd.domain.model.SelectionAggregate;
import com.ielts.cmds.rd.domain.model.enums.DeliveryStatusEnum;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;
import com.ielts.cmds.rd.domain.utils.BuildOrganisationSelectionNodeV1Utils;
import com.ielts.cmds.rd.infrastructure.entity.Selection;
import com.ielts.cmds.rd.infrastructure.repositories.SelectionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.validator.internal.engine.ConstraintViolationImpl;
import org.hibernate.validator.internal.engine.path.PathImpl;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.ConstraintViolation;
import javax.validation.Path;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.*;

import static java.time.ZoneOffset.UTC;


@Service
@Slf4j
@RequiredArgsConstructor
public class SelectionDeliveryStatusUpdateDomainService {

    private final ObjectMapper objectMapper;

    private final ApplicationEventPublisher applicationEventPublisher;

    private final SelectionRepository selectionRepository;

    private final CMDSErrorResolver<SelectionAggregate> errorResolver;

    private final BuildOrganisationSelectionNodeV1Utils buildOrganisationSelectionNodeV1Utils;

    @Transactional
    public void on(@NotNull final SelectionDeliveryStatusUpdateCommand command) throws JsonProcessingException {
        log.info("Received RecognisingOrganisationResultsDeliveryRequestReceived event with selection uuid  {}",
                command.getEventBody().getSelection().getSelectionUuid());

        String eventBody = null;
        BaseEvent<BaseHeader> event;
        final BaseHeader eventHeader = new BaseHeader();
        BaseEventErrors baseEventErrors = new BaseEventErrors();
        Selection selection = null;
        UUID externalSelectionUuid = command.getEventBody().getSelection().getExternalSelectionUuid();
        Optional<Selection> optionalSelection = selectionRepository.findByExternalSelectionUuid(externalSelectionUuid);
        boolean errorStatus = checkCommandEventError(command);
        if (optionalSelection.isPresent()) {
            selection = optionalSelection.get();
            if (errorStatus) {
                selection.setDeliveryStatus(DeliveryStatusEnum.DELIVERY_REQUESTED);
            } else {
                selection.setDeliveryStatus(DeliveryStatusEnum.UNDELIVERED);
                Set<ConstraintViolation<SelectionAggregate>> violations = addDeliveryStatusUpdateViolation("V046", "UNDELIVERED");
                baseEventErrors = generateEventErrorResponse(command.getEventHeaders(),
                        RDConstants.EventType.ORGANISATION_SELECTION_DELIVERY_STATUS_CHANGED, violations);
            }
            updateDataBase(selection);
            OrganisationSelectionNodeV1 selectionNodeV1 = buildOrganisationSelectionNodeV1Utils.buildOrganisationSelectionNodeV1Utils(selection.getSelectionUuid());
            eventBody = objectMapper.writeValueAsString(selectionNodeV1);
            buildHeader(command, eventHeader);
        }
        event = new BaseEvent<>(eventHeader, eventBody, baseEventErrors, null);
        applicationEventPublisher.publishEvent(event);
    }

    public void buildHeader(@NotNull SelectionDeliveryStatusUpdateCommand command, BaseHeader eventHeader) {
        eventHeader.setCorrelationId(command.getEventHeaders().getCorrelationId());
        eventHeader.setEventDateTime(LocalDateTime.now());
        eventHeader.setTransactionId(command.getEventHeaders().getTransactionId());
        eventHeader.setPartnerCode(command.getEventHeaders().getPartnerCode());
        Map<String, String> eventContext = Optional
                .ofNullable(command.getEventHeaders().getEventContext())
                .orElseGet(HashMap::new);
        eventContext.put("externalSelectionUuid", command.getEventBody().getSelection().getExternalSelectionUuid().toString());
        eventHeader.setEventContext(eventContext);

        eventHeader.setEventName(RDConstants.EventType.ORGANISATION_SELECTION_DELIVERY_STATUS_CHANGED);
    }

    private BaseEventErrors generateEventErrorResponse(final BaseHeader baseHeader, final String rejectedEventName,
                                                       final Set<ConstraintViolation<SelectionAggregate>> violation) {
        baseHeader.setEventName(rejectedEventName);
        CMDSErrorResponse eventErrors = errorResolver.populatErrorResponse(violation, rejectedEventName);
        return new BaseEventErrors(eventErrors.getErrorList());
    }

    public Set<ConstraintViolation<SelectionAggregate>> addDeliveryStatusUpdateViolation(
            final String interpolatedMessage, final String pathProperty) {
        Set<ConstraintViolation<SelectionAggregate>> violationSet = new HashSet<>();
        Path path = PathImpl.createPathFromString(pathProperty);
        final String messageTemplate = null;
        final Map<String, Object> messageParameters = new HashMap<>();
        final Map<String, Object> expressionVariables = new HashMap<>();
        ConstraintViolation<SelectionAggregate> constraintViolationImpl = ConstraintViolationImpl
                .forBeanValidation(messageTemplate, messageParameters, expressionVariables, interpolatedMessage,
                        null, null, null, null, path, null, null);
        violationSet.add(constraintViolationImpl);
        return violationSet;
    }

    private Boolean checkCommandEventError(SelectionDeliveryStatusUpdateCommand command) {

        return command.getEventErrors() == null;
    }

    private void updateDataBase(Selection selection) {
        selection.setDeliveryStatusChangedDatetime(OffsetDateTime.now(UTC));
        selectionRepository.save(selection);
    }
}
