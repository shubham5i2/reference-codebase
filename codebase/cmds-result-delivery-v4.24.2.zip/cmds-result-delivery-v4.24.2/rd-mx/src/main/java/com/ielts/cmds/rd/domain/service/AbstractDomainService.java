package com.ielts.cmds.rd.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.application.exception.ResultDeliveryRuntimeException;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import com.ielts.cmds.rd.domain.model.out.ResultRenditionNodeV1;
import com.ielts.cmds.rd.domain.utils.BuildOrganisationSelectionNodeV1Utils;
import com.ielts.cmds.rd.domain.utils.BuildResultReleaseNodeV1Utils;
import com.ielts.cmds.rd.infrastructure.entity.ProductConfig;
import com.ielts.cmds.rd.infrastructure.entity.Result;
import com.ielts.cmds.rd.infrastructure.entity.ResultsStatusType;
import com.ielts.cmds.rd.infrastructure.entity.Selection;
import com.ielts.cmds.rd.infrastructure.repositories.ProductConfigRepository;
import com.ielts.cmds.rd.infrastructure.repositories.ResultRepository;
import com.ielts.cmds.rd.infrastructure.repositories.SelectionRepository;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.*;

import static com.ielts.cmds.rd.domain.RDConstants.EventType.REPORT_GENERATION_REQUESTED;

@Component
@RequiredArgsConstructor
@Slf4j
abstract class AbstractDomainService {


    public List<BaseEvent<BaseHeader>> prepareReportGenerationEvents(BaseHeader commandHeader, ReportGenerationEventInput reportGenerationEventInput) throws JsonProcessingException {
        List<BaseEvent<BaseHeader>> generationEvents = new ArrayList<>();

        List<ProductConfig> productConfigList = getProductConfigRepository().findByProductUuidAndPartnerCode
                (reportGenerationEventInput.productUuid, reportGenerationEventInput.partnerCode);

        ResultReleasedNodeV1 eventBody = getBuildResultReleasedNodeV1Utils().buildResultReleasedNodeV1(reportGenerationEventInput.resultUuid);
        UUID reportGenerationRequestedUuid = UUID.randomUUID();
        for (ProductConfig productConfig : productConfigList) {

            BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
            commandHeader.getEventContext().put("renditionTypeUuid" , productConfig.getRenditionTypeUuid().toString());
            BaseHeader header = buildHeader(commandHeader, REPORT_GENERATION_REQUESTED);
            header = setReportGenerationRequestedUuidInContext(reportGenerationRequestedUuid,header);
            baseEvent.setEventHeader(header);

            //clear existing result renditions in eventBody and add renditionTypeUuid
            if (Objects.nonNull(eventBody) && Objects.nonNull(eventBody.getResultDetails())) {
                ResultRenditionNodeV1 resultRenditionNodeV1 = new ResultRenditionNodeV1();
                resultRenditionNodeV1.setRenditionTypeUuid(productConfig.getRenditionTypeUuid());
                if (Objects.nonNull(eventBody.getResultDetails().getResultRenditions())) {
                    eventBody.getResultDetails().getResultRenditions().clear();
                }
                //set rendition type uuid in eventBody
                eventBody.getResultDetails().getResultRenditions().add(resultRenditionNodeV1);
                log.info("ReportGeneration for booking with bookingUuid {} is requested for template {}", eventBody.getBookingDetails().getBookingUuid(), productConfig.getTemplateName());
            }
            String body = getObjectMapper().writeValueAsString(eventBody);
            baseEvent.setEventBody(body);
            baseEvent.setEventErrors(null);
            generationEvents.add(baseEvent);
        }
        return generationEvents;
    }

    protected BaseHeader setReportGenerationRequestedUuidInContext(UUID reportGenerationRequestedUuid,BaseHeader header){
        header.getEventContext().put("reportGenerationRequestedUuid",reportGenerationRequestedUuid.toString());
        return header;
    }


    protected BaseHeader buildHeader(BaseHeader eventHeaders, String eventName) {
        BaseHeader baseHeader = new BaseHeader();
        baseHeader.setEventName(eventName);
        baseHeader.setPartnerCode(eventHeaders.getPartnerCode());
        baseHeader.setEventDateTime(LocalDateTime.now());
        baseHeader.setTransactionId(eventHeaders.getTransactionId());
        baseHeader.setCorrelationId(eventHeaders.getCorrelationId());
        baseHeader.setEventContext(new HashMap<>(eventHeaders.getEventContext()));

        return baseHeader;
    }

    protected String getEventBodyForSelectionEvents(UUID externalSelectionUuid) throws JsonProcessingException {
        String eventBody = null;
        Optional<Selection> optionalSelection = getSelectionRepository().findByExternalSelectionUuid(externalSelectionUuid);
        if (optionalSelection.isPresent()) {
            OrganisationSelectionNodeV1 selectionNodeV1 = getBuildOrganisationSelectionNodeV1Utils().buildOrganisationSelectionNodeV1Utils(optionalSelection.get().getSelectionUuid());
            eventBody = getObjectMapper().writeValueAsString(selectionNodeV1);
        }
        return eventBody;
    }

    protected String getEventBodyForReportGenerationEvents(UUID bookingUuid) throws JsonProcessingException {
        String eventBody = null;
        Optional<Result> optionalResult = getResultRepository().findByBookingUuid(bookingUuid);
        if (optionalResult.isPresent()) {
            ResultReleasedNodeV1 resultReleasedNodeV1 = getBuildResultReleasedNodeV1Utils().buildResultReleasedNodeV1(optionalResult.get().getResultUuid());
            eventBody = getObjectMapper().writeValueAsString(resultReleasedNodeV1);
        }
        return eventBody;
    }

    protected boolean isErrorTypeValidationOrError(BaseEventErrors errors) {
        boolean errorValidation = false;
        List<ErrorDescription> errorList = Optional.ofNullable(errors).orElse(new BaseEventErrors(new ArrayList<>())).getErrorList();
        for (ErrorDescription description : errorList) {
            if (ErrorTypeEnum.ERROR.equals(description.getType()) || ErrorTypeEnum.VALIDATION.equals(description.getType())) {
                errorValidation = true;
                break;
            }
        }
        return errorValidation;
    }


    protected abstract ObjectMapper getObjectMapper();

    protected List<BaseEvent<BaseHeader>> getEventsForReportGenerationRequested(String partnerCode, UUID productUuid, BaseHeader baseHeader, Result result, ResultsStatusType resultsStatusType) throws JsonProcessingException
    {
        throw new ResultDeliveryRuntimeException("Method definition for getEventsForReportGenerationRequested() not found ");
    }

    protected BuildResultReleaseNodeV1Utils getBuildResultReleasedNodeV1Utils()
    {
        throw new ResultDeliveryRuntimeException("Method definition for getBuildResultReleasedNodeV1Utils() not found ");
    }

    protected ProductConfigRepository getProductConfigRepository()
    {
        throw new ResultDeliveryRuntimeException("Method definition for getProductConfigRepository() not found ");
    }

    protected BuildOrganisationSelectionNodeV1Utils getBuildOrganisationSelectionNodeV1Utils()
    {
        throw new ResultDeliveryRuntimeException("Method definition for getBuildOrganisationSelectionNodeV1Utils() not found ");
    }

    protected SelectionRepository getSelectionRepository()
    {
        throw new ResultDeliveryRuntimeException("Method definition for getSelectionRepository() not found ");
    }

    protected ResultRepository getResultRepository()
    {
        throw new ResultDeliveryRuntimeException("Method definition for getResultRepository() not found ");
    }

    @AllArgsConstructor
    protected class ReportGenerationEventInput {
        String partnerCode;
        UUID productUuid;
        UUID resultUuid;
    }

}
