package com.ielts.cmds.rd.domain.service;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.application.exception.ResultDeliveryValidationException;
import com.ielts.cmds.rd.domain.command.PhotoChangeAnalysisCommand;
import com.ielts.cmds.rd.domain.enums.ResultDataAnalysisOutcomeFlag;
import com.ielts.cmds.rd.domain.model.out.ReferenceDataNodeV1;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import com.ielts.cmds.rd.domain.utils.BuildResultReleaseNodeV1Utils;
import com.ielts.cmds.rd.domain.utils.DomainEventsPublisher;
import com.ielts.cmds.rd.infrastructure.entity.*;
import com.ielts.cmds.rd.infrastructure.repositories.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.constraints.NotNull;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

import static com.ielts.cmds.rd.domain.RDConstants.EventType.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class PhotoChangeAnalysisDomainService extends AbstractDomainService {

    private final ObjectMapper objectMapper;

    private final BookingRepository bookingRepository;

    private final ResultRepository resultRepository;

    private final DomainEventsPublisher domainEventsPublisher;

    private final BuildResultReleaseNodeV1Utils resultReleaseNodeV1Utils;

    private final ResultsStatusLabelRepository resultsStatusLabelRepository;

    private final ResultsStatusTypeRepository resultsStatusTypeRepository;

    private final ResultTypeRepository resultTypeRepository;

    private final ProductConfigRepository productConfigRepository;

    @Transactional
    public void on(@NotNull PhotoChangeAnalysisCommand command) throws JsonProcessingException, ResultDeliveryValidationException, InvocationTargetException, IllegalAccessException {

        log.info("Received Photo Change Analysis event with Booking Uuid {}", command.getEventBody().getBookingUuid());

        List<BaseEvent<BaseHeader>> baseEventList = new ArrayList<>();
        Optional<Result> optionalResult = resultRepository.findByBookingUuid(command.getEventBody().getBookingUuid());

        if (!optionalResult.isPresent()) {
            log.info("NoActionTaken event is published as Result is not found for the booking with bookingUuid {}",command.getEventBody().getBookingUuid());
            baseEventList.add(noActionTaken(command.getEventHeaders()));
        } else {
            Result result = optionalResult.get();
            Optional<BaseEvent<BaseHeader>> legacyResultDeliveryEvent = legacyResultDeliveryRequestedEvent(command, result);
            Booking booking = bookingRepository.findById(command.getEventBody().getBookingUuid()).orElseThrow(() -> new ResultDeliveryValidationException
                    ("Photo Change Analysis Event Failed as Booking is not Present", new Throwable()));
            ResultsStatusType resultStatusType = setResultStatusCode(result);
            //generate reportGenerationRequested event multiple times with different renditionTypeUuid
            List<BaseEvent<BaseHeader>> reportGenerationRequestedEventList = getEventsForReportGenerationRequested(booking.getPartnerCode(), booking.getProductUuid(), command.getEventHeaders(), result, resultStatusType);
            legacyResultDeliveryEvent.ifPresent(baseEventList::add);

            if (!reportGenerationRequestedEventList.isEmpty()) {
                baseEventList.addAll(reportGenerationRequestedEventList);
            }

            if (baseEventList.isEmpty()) {
                baseEventList.add(noActionTaken(command.getEventHeaders()));
            }
        }
        domainEventsPublisher.baseEventListPublisher(baseEventList);
    }

    private ResultsStatusType setResultStatusCode(Result result) {
        ResultsStatusType resultStatusType = new ResultsStatusType();
        if (Objects.nonNull(result.getResultsStatusTypeUuid())) {
            final UUID resultStatusTypeUuid = result.getResultsStatusTypeUuid();
            Optional<ResultsStatusType> optionalResultsStatusType = resultsStatusTypeRepository.findById(resultStatusTypeUuid);
            if (optionalResultsStatusType.isPresent()) {
                if (optionalResultsStatusType.get().getResultStatusCode().equals(RELEASED)) {
                    resultStatusType.setResultStatusCode(RELEASED);
                }
                resultStatusType.setResultStatusTypeUuid(resultStatusTypeUuid);
            }
        }
        return resultStatusType;
    }

    private ResultsStatusLabel setResultStatusLabel(Result result) {
        ResultsStatusLabel resultStatusLabel = new ResultsStatusLabel();
        if (Objects.nonNull(result.getResultsStatusLabelUuid())) {
            final UUID resultStatusLabelUuid = result.getResultsStatusLabelUuid();
            Optional<ResultsStatusLabel> optionalResultsStatusLabel = resultsStatusLabelRepository.findById(resultStatusLabelUuid);
            if (optionalResultsStatusLabel.isPresent()) {
                final String resultStatusLabelCode = optionalResultsStatusLabel.get().getResultsStatusLabelCode();

                resultStatusLabel.setResultsStatusLabelCode(resultStatusLabelCode);
                resultStatusLabel.setResultsStatusLabelUuid(resultStatusLabelUuid);
            }
        }
        return resultStatusLabel;
    }

    private ResultType setResultType(Result result) {
        ResultType resultType = new ResultType();
        if (Objects.nonNull(result.getResultTypeUuid())) {
            final UUID resultTypeUuid = result.getResultTypeUuid();
            Optional<ResultType> optionalResultType = resultTypeRepository.findById(resultTypeUuid);
            if (optionalResultType.isPresent()) {
                final String resultTypeCode = optionalResultType.get().getResultTypeCode();
                resultType.setResultTypeUuid(resultTypeUuid);
                resultType.setResultTypeCode(resultTypeCode);
            }
        }
        return resultType;
    }

    private Optional<BaseEvent<BaseHeader>> legacyResultDeliveryRequestedEvent(PhotoChangeAnalysisCommand command,
                                                                               Result result) throws JsonProcessingException {
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        ResultsStatusType resultStatusType = setResultStatusCode(result);
        if (command.getEventHeaders().getEventContext().containsKey(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey())
                && (command.getEventHeaders().getEventContext().get(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey())
                .equals(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue()))
                && (Objects.equals(resultStatusType.getResultStatusCode(), RELEASED))) {
            baseEvent.setEventHeader(buildHeader(command.getEventHeaders(), LEGACY_RESULT_DELIVERY_REQUESTED));

            String body = objectMapper.writeValueAsString(buildResultNodeV1(result));
            baseEvent.setEventBody(body);
            baseEvent.setEventErrors(getBaseEventErrors());
            return Optional.of(baseEvent);
        }
        return Optional.empty();
    }

    @Override
    public List<BaseEvent<BaseHeader>> getEventsForReportGenerationRequested(String partnerCode, UUID productUuid, BaseHeader baseheader, Result result, ResultsStatusType resultsStatusType) throws JsonProcessingException {

        List<BaseEvent<BaseHeader>> reportGenerationRequestedEvents = new ArrayList<>();

        if (baseheader.getEventContext().containsKey(ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getKey())
                && (baseheader.getEventContext().get(ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getKey())
                .equals(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue()))
                && (Objects.equals(resultsStatusType.getResultStatusCode(), RELEASED))) {
            log.info("Report Generation is to be initiated as TRF CRITICAL INFORMATION is changed for booking with resultUuid {}",result.getResultUuid());
            ReportGenerationEventInput reportGenerationEventInput = new ReportGenerationEventInput(partnerCode, productUuid, result.getResultUuid());

            List<BaseEvent<BaseHeader>> generationEventList = prepareReportGenerationEvents(baseheader, reportGenerationEventInput);
            reportGenerationRequestedEvents.addAll(generationEventList);

        } else {
            log.info("NoActionTaken event is published as Result status is not RELEASED");
            BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
            baseEvent.setEventHeader(buildHeader(baseheader, NO_ACTION_TAKEN));
            baseEvent.setEventBody(NO_ACTION_TAKEN);
            baseEvent.setEventErrors(null);
            reportGenerationRequestedEvents.add(baseEvent);
        }
        return reportGenerationRequestedEvents;
    }


    private BaseEvent<BaseHeader> noActionTaken(BaseHeader eventHeader) {
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        baseEvent.setEventHeader(buildHeader(eventHeader, NO_ACTION_TAKEN));
        baseEvent.setEventBody("NoActionTaken");
        baseEvent.setEventErrors(getBaseEventErrors());
        return baseEvent;
    }


    private BaseEventErrors getBaseEventErrors() {
        BaseEventErrors baseEventErrors;
        List<ErrorDescription> errorDescriptions = new ArrayList<>();
        ErrorDescription errorDescription = new ErrorDescription();
        errorDescription.setInterfaceName("POST/v1/users");
        errorDescription.setMessage("PhotoChangeAnalysisCommand execution failed");
        errorDescription.setType(ErrorTypeEnum.VALIDATION);
        errorDescription.setTitle("Validation Failed");
        errorDescription.setErrorCode("V0023");
        errorDescriptions.add(errorDescription);
        baseEventErrors = new BaseEventErrors(errorDescriptions);
        return baseEventErrors;
    }

    private ResultReleasedNodeV1 buildResultNodeV1(Result result) {
        ResultReleasedNodeV1 resultReleasedNodeV1;

        resultReleasedNodeV1 = resultReleaseNodeV1Utils.buildResultReleasedNodeV1(result.getResultUuid());

        if (Objects.nonNull(resultReleasedNodeV1)) {
            getReferenceData(resultReleasedNodeV1, result);
        }

        return resultReleasedNodeV1;
    }

    protected void getReferenceData(ResultReleasedNodeV1 resultReleasedNodeV1, Result result) {

        ResultsStatusType resultStatusType = setResultStatusCode(result);
        ResultsStatusLabel resultStatusLabel = setResultStatusLabel(result);
        ResultType resultType = setResultType(result);

        ReferenceDataNodeV1 referenceDataNodeV1 = new ReferenceDataNodeV1();
        ReferenceDataNodeV1 referenceDataNodeV2 = new ReferenceDataNodeV1();
        ReferenceDataNodeV1 referenceDataNodeV3 = new ReferenceDataNodeV1();
        List<ReferenceDataNodeV1> referenceDataNodeV1s = new ArrayList<>();

        referenceDataNodeV1.setReferenceId(resultStatusType.getResultStatusTypeUuid().toString());
        referenceDataNodeV1.setReferenceValue(resultStatusType.getResultStatusCode());

        if (resultStatusLabel.getResultsStatusLabelUuid() != null) {
            referenceDataNodeV2.setReferenceId(resultStatusLabel.getResultsStatusLabelUuid().toString());
            referenceDataNodeV2.setReferenceValue(resultStatusLabel.getResultsStatusLabelCode());
        }

        referenceDataNodeV3.setReferenceId(resultType.getResultTypeUuid().toString());
        referenceDataNodeV3.setReferenceValue(resultType.getResultTypeCode());

        referenceDataNodeV1s.add(referenceDataNodeV1);
        referenceDataNodeV1s.add(referenceDataNodeV2);
        referenceDataNodeV1s.add(referenceDataNodeV3);
        resultReleasedNodeV1.setReferenceData(referenceDataNodeV1s);
    }

    @Override
    protected ObjectMapper getObjectMapper() {
        return this.objectMapper;
    }

    @Override
    protected BuildResultReleaseNodeV1Utils getBuildResultReleasedNodeV1Utils() {
        return this.resultReleaseNodeV1Utils;
    }

    @Override
    protected ProductConfigRepository getProductConfigRepository() {
        return this.productConfigRepository;
    }
}
