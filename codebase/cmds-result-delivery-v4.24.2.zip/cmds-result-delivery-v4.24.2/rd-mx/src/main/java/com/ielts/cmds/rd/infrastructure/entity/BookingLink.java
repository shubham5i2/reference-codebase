package com.ielts.cmds.rd.infrastructure.entity;

import com.ielts.cmds.booking.common.enums.RoleEnum;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.UUID;

@Data
@ToString(exclude = "booking")
@Entity
@Table(name = "booking_link")
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BookingLink implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 4109283217996617420L;

    @Id
    @Column(name = "booking_link_uuid")
    private UUID bookingLinkUuid;

    @Enumerated(EnumType.STRING)
    @Column(name = "role")
    private RoleEnum role;

    @Column(name = "source_booking_uuid")
    private UUID sourceBookingUuid;

    @Column(name = "target_booking_uuid")
    private UUID targetBookingUuid;

    @Column(name = "created_datetime")
    private OffsetDateTime createdDatetime;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "updated_by")
    private String updatedBy;

    @Version
    @Column(name = "concurrency_version")
    private Integer concurrencyVersion;

}