package com.ielts.cmds.rd.domain.utils;


import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;
import com.ielts.cmds.rd.infrastructure.entity.Booking;
import com.ielts.cmds.rd.infrastructure.entity.Selection;
import com.ielts.cmds.rd.infrastructure.repositories.BookingRepository;
import com.ielts.cmds.rd.infrastructure.repositories.SelectionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Component
@RequiredArgsConstructor
@Slf4j
public class BuildOrganisationSelectionNodeV1Utils {

    private final BuildSelectionNodeV1Utils buildSelectionNodeV1Utils;

    private final BuildRecognisingOrganisationNodeV1Utils buildRecognisingOrganisationNodeV1Utils;

    private final BuildBookingNodeV1Utils buildBookingNodeV1Utils;

    private final BuildLocationNodeUtils buildLocationNodeUtils;

    private final SelectionRepository selectionRepository;

    private final BookingRepository bookingRepository;

    public OrganisationSelectionNodeV1 buildOrganisationSelectionNodeV1Utils(UUID selectionUuid) {
        OrganisationSelectionNodeV1 organisationSelectionNodeV1 = new OrganisationSelectionNodeV1();
        Optional<Selection> optionalSelection = Optional.empty();
        Optional<Booking> optionalBooking = Optional.empty();
        if (Objects.nonNull(selectionUuid)) {
            optionalSelection = selectionRepository.findById(selectionUuid);
        }
        if (optionalSelection.isPresent()) {
            optionalBooking = bookingRepository.findByExternalBookingUuid(optionalSelection.get().getExternalBookingUuid());
        }
        if (optionalBooking.isPresent()) {
            return OrganisationSelectionNodeV1.builder()
                    .selection(buildSelectionNodeV1Utils.buildSelectionNodeV1(selectionUuid))
                    .organisationDetails(buildRecognisingOrganisationNodeV1Utils.buildRecognisingOrganisationNodeV1(optionalSelection.get().getRecognisingOrganisationUuid()))
                    .bookingDetails(buildBookingNodeV1Utils.buildResultDeliveryBookingNodeV1(optionalBooking.get().getBookingUuid()))
                    .locationDetails(buildLocationNodeUtils.buildLocationChangeNodeV1(optionalBooking.get().getLocationUuid()))
                    .build();
        }
        return organisationSelectionNodeV1;
    }


}
