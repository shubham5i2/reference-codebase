package com.ielts.cmds.rd.application.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.config.IApplicationService;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.domain.command.ReportGenerationRequestedCommand;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import com.ielts.cmds.rd.domain.service.ReportGenerationRequestedDomainService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@RequiredArgsConstructor
@Service
public class ReportGenerationRequestedService implements IApplicationService {

    private final ObjectMapper objectMapper;

    private final ReportGenerationRequestedDomainService reportGenerationRequestedDomainService;

    @Override
    public void process(BaseEvent<? extends BaseHeader> baseEvent) throws ProcessingException {
        try {
            final BaseHeader eventHeader = baseEvent.getEventHeader();
            final BaseEventErrors eventErrors = baseEvent.getEventErrors();
            final ResultReleasedNodeV1 resultReleasedNodeV1 = objectMapper
                    .readValue(baseEvent.getEventBody(), ResultReleasedNodeV1.class);
            if (resultReleasedNodeV1 == null) {
                throw new IllegalArgumentException(RDConstants.GenericConstants.EMPTY_PAYLOAD);
            }
            //build command
            final ReportGenerationRequestedCommand reportGenerationRequestedCommand = ReportGenerationRequestedCommand.builder()
                    .eventHeaders(eventHeader).eventBody(resultReleasedNodeV1)
                    .eventErrors(eventErrors).eventAudit(baseEvent.getAudit()).build();

            //execute command
            reportGenerationRequestedDomainService.on(reportGenerationRequestedCommand);

        } catch (IllegalArgumentException | JsonProcessingException e) {
            log.error("Failed to process Report Generation event due to ", e);
            throw new ProcessingException(e.getMessage(), e);
        }
    }

    @Override
    public String getServiceIdentifier() {
        return RDConstants.EventType.REPORT_GENERATION_REQUESTED;
    }
}

