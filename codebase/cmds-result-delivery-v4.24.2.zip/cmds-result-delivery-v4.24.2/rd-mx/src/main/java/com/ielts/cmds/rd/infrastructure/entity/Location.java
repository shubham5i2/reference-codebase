package com.ielts.cmds.rd.infrastructure.entity;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;

import com.ielts.cmds.lpr.common.enums.LocationStatus;
import com.ielts.cmds.lpr.common.enums.LocationTypeCode;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity(name = "RDLocation")
@Table(name = "location")
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Location implements Serializable{


    /**
	 * 
	 */
	private static final long serialVersionUID = -6869339738100744894L;

	@Id
    @Column(name = "location_uuid")
    private UUID locationUuid;

    @Column(name = "parent_location_uuid")
    private UUID parentLocationUuid;

    @Column(name = "location_name")
    private String locationName;

    @Column(name = "partner_code")
    private String partnerCode;

    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    private LocationStatus status;

    @Column(name = "test_centre_number")
    private String testCentreNumber;

    @Enumerated(EnumType.STRING)
    @Column(name = "location_type")
    private LocationTypeCode locationType;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;

    @Column(name = "event_datetime")
    private OffsetDateTime eventDatetime;

    @Version
    @Column(name = "concurrency_version")
    private Integer concurrencyVersion;

}
