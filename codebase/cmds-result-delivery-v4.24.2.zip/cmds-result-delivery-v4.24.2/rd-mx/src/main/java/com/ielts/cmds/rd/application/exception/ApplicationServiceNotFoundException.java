package com.ielts.cmds.rd.application.exception;

/**
 * An exception class denoting that a particular application can not be found
 *
 * @author Monjure Alam
 */
public class ApplicationServiceNotFoundException extends RuntimeException {

	/**
	 *
	 */
	private static final long serialVersionUID = 5739366016725073156L;

	public ApplicationServiceNotFoundException(String message) {
		super(message);
	}
}
