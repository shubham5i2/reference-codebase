package com.ielts.cmds.rd.application.exception;

public class TestTakerPhotoNotFoundException extends RuntimeException {

    private static final long serialVersionUID = 1L;


    public TestTakerPhotoNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
