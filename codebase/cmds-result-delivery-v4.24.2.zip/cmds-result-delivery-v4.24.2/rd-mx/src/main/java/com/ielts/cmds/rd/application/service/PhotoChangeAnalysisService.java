package com.ielts.cmds.rd.application.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.config.IApplicationService;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.domain.command.PhotoChangeAnalysisCommand;
import com.ielts.cmds.rd.domain.model.out.TTPhotoNodeV1;
import com.ielts.cmds.rd.domain.service.PhotoChangeAnalysisDomainService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.lang.reflect.InvocationTargetException;

import static com.ielts.cmds.rd.domain.RDConstants.EventType.TT_PHOTO_CHANGED_EVENT;

@Service
@RequiredArgsConstructor
@Slf4j
public class PhotoChangeAnalysisService implements IApplicationService {

    private final ObjectMapper objectMapper;

    private final PhotoChangeAnalysisDomainService photoChangeAnalysisDomainService;
    @Override
    public void process(BaseEvent<? extends BaseHeader> baseEvent) throws ProcessingException {
        try{
            final BaseHeader eventHeader = baseEvent.getEventHeader();
            final BaseEventErrors eventErrors = baseEvent.getEventErrors();
            final TTPhotoNodeV1 ttPhotoNodeV1 = objectMapper
                    .readValue(baseEvent.getEventBody(), TTPhotoNodeV1.class);
            if(ttPhotoNodeV1 == null)
            {
                throw new IllegalArgumentException("Payload is Empty");
            }

            final PhotoChangeAnalysisCommand photoChangeAnalysisCommand = PhotoChangeAnalysisCommand.builder()
                    .eventHeader(eventHeader).eventBody(ttPhotoNodeV1).eventErrors(eventErrors).eventAudit(baseEvent.getAudit())
                    .build();

            photoChangeAnalysisDomainService.on(photoChangeAnalysisCommand);
        }catch (IllegalArgumentException | JsonProcessingException | InvocationTargetException | IllegalAccessException e) {

            log.error("Failed to process Photo Change Analysis event due to ", e);
            throw new ProcessingException(e.getMessage(), e);
        }
    }

    @Override
    public String getServiceIdentifier() {
        return TT_PHOTO_CHANGED_EVENT;
    }


}
