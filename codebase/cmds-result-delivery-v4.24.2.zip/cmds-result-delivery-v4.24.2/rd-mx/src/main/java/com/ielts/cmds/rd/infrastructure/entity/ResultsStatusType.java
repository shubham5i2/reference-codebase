package com.ielts.cmds.rd.infrastructure.entity;

import lombok.Data;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.UUID;

@Data
@Entity
@Table(name = "results_status_type")
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class ResultsStatusType implements Serializable {

    private static final long serialVersionUID = 86183085442690969L;

    @Id
    @Column(name = "results_status_type_uuid")
    private UUID resultStatusTypeUuid;

    @Column(name = "results_status_code")
    private String resultStatusCode;

    @Column(name = "results_status")
    private String resultsStatus;

    @Column(name = "updated_by")
    private String updatedBy;

    @Column(name = "effective_to_date")
    private LocalDate effectiveToDate;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "created_datetime")
    private OffsetDateTime createdDatetime;

    @Version
    @Column(name = "concurrency_version")
    private Integer concurrencyVersion;

    @Column(name = "effective_from_date")
    private LocalDate effectiveFromDate;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;
}
