package com.ielts.cmds.rd.domain.service;

import com.amazonaws.services.s3.model.PutObjectResult;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.booking.common.enums.BookingLineStatusEnum;
import com.ielts.cmds.booking.common.enums.RoleEnum;
import com.ielts.cmds.cre.ApacheReportEngine;
import com.ielts.cmds.cre.ApacheReportGeneratorEngine;
import com.ielts.cmds.cre.generator.PDFGenerator;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.application.exception.ResultDeliveryValidationException;
import com.ielts.cmds.rd.application.exception.TestTakerPhotoNotFoundException;
import com.ielts.cmds.rd.domain.command.ReportGenerationRequestedCommand;
import com.ielts.cmds.rd.domain.model.ReportGenerationModel;
import com.ielts.cmds.rd.domain.model.enums.RenditionTypeCodeEnum;
import com.ielts.cmds.rd.domain.model.out.BookingLinkNodeV1;
import com.ielts.cmds.rd.domain.model.out.ResultDeliveryBookingLineNodeV1;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import com.ielts.cmds.rd.domain.utils.BuildResultReleaseNodeV1Utils;
import com.ielts.cmds.rd.domain.utils.BuildTemplateDataUtils;
import com.ielts.cmds.rd.domain.utils.PrepareTemplateData;
import com.ielts.cmds.rd.infrastructure.config.TemplateGenerationS3Operations;
import com.ielts.cmds.rd.infrastructure.entity.*;
import com.ielts.cmds.rd.infrastructure.repositories.*;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.constraints.NotNull;
import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static com.ielts.cmds.rd.domain.RDConstants.EventType.REPORT_GENERATED;
import static com.ielts.cmds.rd.domain.RDConstants.EventType.REPORT_GENERATED_FAILED;

@Service
@RequiredArgsConstructor
@Slf4j
public class ReportGenerationRequestedDomainService {

    private final ResultRepository resultRepository;

    private final ResultsRenditionRepository resultsRenditionRepository;

    private final ObjectMapper objectMapper;

    private final ApplicationEventPublisher applicationEventPublisher;

    private final BuildResultReleaseNodeV1Utils resultReleaseNodeV1Utils;

    private final TemplateGenerationS3Operations trfGenerationS3Operations;

    private final PrepareTemplateData abstractPrepareTemplateData;

    private final ApacheReportEngine apacheReportEngine = new ApacheReportGeneratorEngine();

    private PDFGenerator pdfGenerator;

    private final BuildTemplateDataUtils buildTemplateDataUtils;

    private final ProductConfigRepository productConfigRepository;

    private final RenditionTypeRepository renditionTypeRepository;

    private final ProductRepository productRepository;

    private final BookingRepository bookingRepository;

    private final LocationRepository locationRepository;

    @Value("${ukvi-reference-number.ukvi}")
    private String ukviReferenceNumberStructure;

    @Transactional
    @SneakyThrows
    public void on(@NotNull ReportGenerationRequestedCommand command) throws JsonProcessingException {
        Optional<ResultReleasedNodeV1> resultReleasedNodeV1 = Optional.empty();
        String eventBody;
        BaseEvent<BaseHeader> event;
        BaseHeader eventHeader = new BaseHeader();
        BaseEventErrors baseEventErrors = null;

        try {
            /********************** Report data preparation starts here **********************/

            Optional<ProductConfig> optionalProductConfig = productConfigRepository
                    .findByProductUuidAndPartnerCodeAndRenditionTypeUuidAndEffectiveFromDateLessThanEqualAndEffectiveToDateGreaterThanEqual
                            (command.getEventBody().getBookingDetails().getProductUuid(),
                                    command.getEventBody().getBookingDetails().getPartnerCode(),
                                    command.getEventBody().getResultDetails().getResultRenditions().get(0).getRenditionTypeUuid(),
                                    LocalDate.now(), LocalDate.now());

            ProductConfig productConfig = optionalProductConfig.orElseThrow(
                    () -> new ResultDeliveryValidationException("Event failed as Product config record is not present", new Throwable()));


            Optional<RenditionType> optionalRenditionType = renditionTypeRepository
                    .findById(command.getEventBody().getResultDetails().getResultRenditions().get(0).getRenditionTypeUuid());

            RenditionTypeCodeEnum reportType = optionalRenditionType.orElseThrow(
                            () -> new ResultDeliveryValidationException("Event failed as Rendition type uuid is not present", new Throwable()))
                    .getRenditionTypeCodeEnum();

            Optional<Result> optionalResult = resultRepository.findById(command.getEventBody().getResultDetails().getResultUuid());

            Result result = optionalResult.orElseThrow(() -> new ResultDeliveryValidationException("Event failed as Result is not present", new Throwable()));

            ReportGenerationModel reportGenerationModel = buildTemplateDataUtils.prepareTemplateData(command);

            reportGenerationModel.setUkviNumber(generateUKVIReferenceNumber(command, reportGenerationModel));

            reportGenerationModel.setTemplateName(productConfig.getTemplateName());

            //SSR booking specific changes
            if (Objects.nonNull(command.getEventBody().getBookingDetails().getBookingLinks()) && !command.getEventBody().getBookingDetails().getBookingLinks().isEmpty()) {
                buildSSRSpecificValues(command, productRepository, reportGenerationModel);
                buildOriginalTestDetailsInSSRTemplate(command, reportGenerationModel);
            }

            log.info("Report Generation data prepared successfully! for {} for booking with bookingUuid {}", productConfig.getTemplateName(), command.getEventBody().getBookingDetails().getBookingUuid());

            /********************** Report data preparation ends here **********************/

            pdfGenerator = apacheReportEngine.getPDFType();

            final byte[] generatorOutput = abstractPrepareTemplateData.generatePDF(reportGenerationModel, pdfGenerator);
            ResultsRendition resultsRendition = null;

            if (generatorOutput != null) {

                //generate TRF file in the format "{composite_candidate_number}-{test_date in dd-mm-yyyy}-{renditionType}.pdf"
                File outputFile = abstractPrepareTemplateData.generateTemplateFileName(command, reportType);

                FileUtils.writeByteArrayToFile(outputFile, generatorOutput);

                //upload generated TRF file into S3 bucket
                PutObjectResult putObjectResult = trfGenerationS3Operations.uploadTemplateFileToS3Bucket(outputFile);

                log.info(reportType + " file uploaded successfully to S3 bucket");

                //save TRF data into database
                resultsRendition = abstractPrepareTemplateData.updateResultsRenditionDetails(command, result, resultsRenditionRepository, outputFile, putObjectResult, reportType);
            }

            ResultReleasedNodeV1 resultReleasedNodeV11 = resultReleaseNodeV1Utils.buildResultReleasedNodeV1(result.getResultUuid());
            resultReleasedNodeV11.setReferenceData(resultReleaseNodeV1Utils.getReferenceData(result));
            resultReleasedNodeV1 = Optional.of(resultReleasedNodeV11);
            eventBody = objectMapper.writeValueAsString(resultReleasedNodeV1);
            if (Objects.nonNull(resultsRendition)) {
                command.getEventHeaders().getEventContext().put("renditionUuid", resultsRendition.getResultsRenditionUuid().toString());
            }
            eventHeader = abstractPrepareTemplateData.buildHeader(command, eventHeader, REPORT_GENERATED);


        } catch (ResultDeliveryValidationException | TestTakerPhotoNotFoundException exception) {
            log.error("RequestReportGenerationCommand execution failed due to: ", exception);
            eventBody = null;
            BaseEventErrors eventErrors = abstractPrepareTemplateData.buildEventError(exception);
            baseEventErrors = new BaseEventErrors(eventErrors.getErrorList());
            eventHeader = abstractPrepareTemplateData.buildHeader(command, eventHeader, REPORT_GENERATED_FAILED);
        }
        event = new BaseEvent<>(eventHeader, eventBody, baseEventErrors, command.getAudit());
        applicationEventPublisher.publishEvent(event);
    }


    /**
     * @param command               ReportGenerationRequestedCommand
     * @param productRepository     ProductRepository
     * @param reportGenerationModel ReportGenerationModel
     * @throws ResultDeliveryValidationException
     */
    public void buildSSRSpecificValues(ReportGenerationRequestedCommand command, ProductRepository productRepository, ReportGenerationModel reportGenerationModel) throws ResultDeliveryValidationException {
        List<ResultDeliveryBookingLineNodeV1> bookingLines = command.getEventBody().getBookingDetails().getBookingLines();
        Optional<ResultDeliveryBookingLineNodeV1> optionalResultDeliveryBookingLineNodeV1 = bookingLines.stream().filter(e -> e.getBookingLineStatus().equals(BookingLineStatusEnum.ACTIVE)).findFirst();
        if (optionalResultDeliveryBookingLineNodeV1.isPresent()) {
            Optional<Product> optionalProduct = productRepository.findById(optionalResultDeliveryBookingLineNodeV1.get().getProductUuid());
            if (optionalProduct.isPresent()) {
                String templateNotes = abstractPrepareTemplateData.getTemplateNotes(optionalProduct.get().getComponent().getValue());
                reportGenerationModel.setTemplateNotes(templateNotes);
                abstractPrepareTemplateData.setSSRSpecificComponentResitValues(optionalProduct.get().getComponent().getValue(), reportGenerationModel);
            }
        }
    }

    public void buildOriginalTestDetailsInSSRTemplate(ReportGenerationRequestedCommand command, ReportGenerationModel reportGenerationModel) throws ResultDeliveryValidationException {

        BookingLinkNodeV1 bookingLink = command.getEventBody().getBookingDetails().getBookingLinks().stream()
                .filter(bl -> bl.getRole().equals(RoleEnum.SSRORIGINAL))
                .findFirst().orElseThrow((() -> new ResultDeliveryValidationException
                        ("Original Booking not found in bookingLinks for the OSR booking with bookingUuid: " + command.getEventBody().getBookingDetails().getBookingUuid(), new Throwable())));

        Optional<Booking> optionalOriginalBooking = bookingRepository.findById(bookingLink.getLinkedBooking().getBookingUuid());

        Booking originalBooking = optionalOriginalBooking.orElseThrow((() -> new ResultDeliveryValidationException
                ("Original Booking for the OSR booking with bookingUuid is not found: " + command.getEventBody().getBookingDetails().getBookingUuid(), new Throwable())));

        //set test date in dd/MMM/yyyy format
        reportGenerationModel.setBookingTestDate(getReportTestDateFormat(originalBooking.getTestDate()));
        //set short candidate number with zeros appended
        String candidateNumber = String.format("%06d", originalBooking.getShortCandidateNumber());
        if (!StringUtils.isBlank(candidateNumber)) {
            reportGenerationModel.setCandidateNumber(candidateNumber);
        }
        //set original booking ID document number in candidate ID
        reportGenerationModel.setCandidateId(originalBooking.getIdentityNumber());
        //set test centre
        Optional<Location> optionalLocation = locationRepository.findById(originalBooking.getLocationUuid());
        Location location = optionalLocation.orElseThrow(() -> new ResultDeliveryValidationException
                ("Event failed as Location is not present for Original Booking", new Throwable()));
        buildTemplateDataUtils.setTemplateLocationDetails(location, reportGenerationModel);

    }

    public String getReportTestDateFormat(LocalDate date) {

        LocalDate localDate = LocalDate.parse(date.toString());
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MMM/yyyy");
        return formatter.format(localDate).toUpperCase();
    }

    //method to set UKVI Reference number in Report Model
    public String generateUKVIReferenceNumber(ReportGenerationRequestedCommand command, ReportGenerationModel reportGenerationModel) {
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("ddMMyyyy");

        final String testDate = command.getEventBody().getBookingDetails().getTestDate().format(dateFormat);
        final String centreNumber = reportGenerationModel.getCentreNumber();
        final String candidateNumber = reportGenerationModel.getCandidateNumber();

        final String[] replacementList = {testDate, centreNumber, candidateNumber};
        final String[] searchList = {"[TEST_DATE]", "[CENTRE_NUMBER]", "[CANDIDATE_NUMBER]"};

        return StringUtils.replaceEach(ukviReferenceNumberStructure, searchList, replacementList);
    }

}
