package com.ielts.cmds.rd.domain.command;

import com.ielts.cmds.application.command.BaseCommand;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.ors.common.out.model.SelectionNodeV1ORS;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ROSelectionWithdrawCommand extends BaseCommand<BaseHeader, SelectionNodeV1ORS> {

    @Builder
    public ROSelectionWithdrawCommand(final BaseHeader eventHeader, final SelectionNodeV1ORS eventBody,
                                      final BaseEventErrors eventErrors, final BaseAudit eventAudit) {
        super(eventHeader, eventBody, eventErrors, eventAudit);
    }
}
