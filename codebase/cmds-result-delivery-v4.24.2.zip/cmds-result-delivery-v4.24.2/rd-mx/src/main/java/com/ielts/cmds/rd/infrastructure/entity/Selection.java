package com.ielts.cmds.rd.infrastructure.entity;

import com.ielts.cmds.rd.domain.model.enums.ConfirmationStatusEnum;
import com.ielts.cmds.rd.domain.model.enums.DeliveryStatusEnum;
import com.ielts.cmds.rd.domain.model.enums.MinimumScoreSatisfiedEnum;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * The persistent class for the selection database table.
 *
 */
@Entity(name = "selection")
@Data
@EqualsAndHashCode(exclude = {"minimumScores"})
@NoArgsConstructor
public class Selection implements Serializable {

	private static final long serialVersionUID = -5515188705021478528L;

	@Id
	@Column(name = "selection_uuid")
	private UUID selectionUuid;

	@Column(name="associated_selection_uuid")
	private UUID associatedSelectionUuid;

	@Column(name="case_number")
	private String caseNumber;

	@Version
	@Column(name="concurrency_version")
	private Integer concurrencyVersion;

	@Column(name="confirmation_status")
	@Enumerated(EnumType.STRING)
	private ConfirmationStatusEnum confirmationStatus;

	@Column(name="confirmation_status_changed_datetime")
	private OffsetDateTime confirmationStatusChangedDatetime;

	@Column(name="delivery_status")
	@Enumerated(EnumType.STRING)
	private DeliveryStatusEnum deliveryStatus;

	@Column(name="delivery_status_changed_datetime")
	private OffsetDateTime deliveryStatusChangedDatetime;

	@Column(name="event_datetime")
	private OffsetDateTime eventDatetime;

	@Column(name="external_booking_reference")
	private String externalBookingReference;

	@Column(name="external_selection_uuid")
	private UUID externalSelectionUuid;

	@Column(name="overall_minimum_score")
	private Double overallMinimumScore;

	@Column(name = "person_department")
	private String personDepartment;

	@Column(name = "selection_date")
	private OffsetDateTime selectionDate;

	@Column(name = "updated_datetime")
	private OffsetDateTime updatedDatetime;

	@OneToMany(mappedBy = "selection", cascade = CascadeType.ALL, orphanRemoval = true)
	@ToString.Exclude
	private List<MinimumScore> minimumScores = new ArrayList<>();

	@Column(name = "external_booking_uuid")
	private UUID externalBookingUuid;

	@Enumerated(EnumType.STRING)
	@Column(name = "minimum_score_satisfied")
	private MinimumScoreSatisfiedEnum minimumScoreSatisfied;

	@Column(name = "recognising_organisation_uuid")
	private UUID recognisingOrganisationUuid;

	@Column(name = "unverified_address_uuid")
	private UUID unverifiedAddressUuid;


}