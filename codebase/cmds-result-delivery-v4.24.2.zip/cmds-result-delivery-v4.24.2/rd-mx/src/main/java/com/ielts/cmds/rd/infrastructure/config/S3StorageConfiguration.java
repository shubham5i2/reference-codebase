package com.ielts.cmds.rd.infrastructure.config;

import com.ielts.cmds.common.config.s3.DefaultS3ClientConfiguration;
import com.ielts.cmds.common.config.s3.DefaultS3PresignerConfiguration;
import com.ielts.cmds.common.utils.s3.CMDSS3Client;
import com.ielts.cmds.common.utils.s3.DefaultCMDSS3Client;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/*
 * This is a configuration class for Amazon S3 common utils
 */

@Configuration
public class S3StorageConfiguration {

    @Bean
    public CMDSS3Client cmdsS3Client() {
        return new DefaultCMDSS3Client(new DefaultS3ClientConfiguration(),new DefaultS3PresignerConfiguration());
    }
}
