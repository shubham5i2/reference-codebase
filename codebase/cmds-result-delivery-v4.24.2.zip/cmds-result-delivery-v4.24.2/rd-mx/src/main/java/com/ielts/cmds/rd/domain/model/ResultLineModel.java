package com.ielts.cmds.rd.domain.model;

import com.ielts.cmds.organisation.common.enums.ComponentEnum;
import com.ielts.cmds.rd.infrastructure.entity.ResultLine;
import lombok.Data;
import lombok.EqualsAndHashCode;


@Data
@EqualsAndHashCode(callSuper = false)
public class ResultLineModel extends ResultLine {

    private ComponentEnum component;
}
