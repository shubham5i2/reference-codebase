package com.ielts.cmds.rd.infrastructure.entity;


import lombok.Data;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.UUID;

@Data
@Entity
@Table(name = "results_status_label")
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class ResultsStatusLabel implements Serializable {

    private static final long serialVersionUID = 86183085442690969L;

    @Id
    @Column(name = "results_status_label_uuid")
    private UUID resultsStatusLabelUuid;

    @Column(name = "results_status_label_code")
    private String resultsStatusLabelCode;

    @Column(name = "results_status_type_uuid")
    private UUID resultsStatusTypeUuid;

    @Column(name = "results_status_comment_mandatory")
    private Boolean resultsStatusCommentMandatory;

    @Column(name = "effective_from_date")
    private LocalDate effectiveFromDate;

    @Column(name = "results_status_label")
    private String resultStatusLabel;

    @Column(name = "created_datetime")
    private OffsetDateTime createdDatetime;

    @Column(name = "effective_to_date")
    private LocalDate effectiveToDate;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;

    @Version
    @Column(name = "concurrency_version")
    private Integer concurrencyVersion;

    @Column(name = "updated_by")
    private String updatedBy;

}
