package com.ielts.cmds.rd.infrastructure.entity;

import lombok.*;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.UUID;
import javax.persistence.*;
import java.time.LocalDate;
import java.time.OffsetDateTime;

@Getter
@Setter
@Entity
@Table(name = "nationality")
@NoArgsConstructor
@AllArgsConstructor
@Builder
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class Nationality {

    @Id
    @Column(name = "nationality_uuid")
    private UUID nationalityUuid;

    @Column(name = "nationality_code")
    private String nationalityCode;

    @Column(name = "nationality_name")
    private String nationalityName;

    @Column(name = "legacy_reference")
    private String legacyReference;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "effective_from_date")
    private LocalDate effectiveFromDate;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;

    @Column(name = "updated_by")
    private String updatedBy;

    @Version
    @Column(name = "concurrency_version")
    private Integer concurrencyVersion;

    @Column(name = "created_datetime")
    private OffsetDateTime createdDatetime;

    @Column(name = "effective_to_date")
    private LocalDate effectiveToDate;


}
