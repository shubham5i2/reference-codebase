package com.ielts.cmds.rd.infrastructure.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ielts.cmds.booking.common.enums.BookingLineStatusEnum;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.UUID;

@Data
@ToString(exclude = "booking")
@Entity
@Table(name = "booking_line")
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BookingLine implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 4109283217996617420L;

    @Id
    @Column(name = "booking_line_uuid")
    private UUID bookingLineUuid;

    @Column(name = "external_booking_line_uuid")
    private UUID externalBookingLineUuid;

    @Column(name = "product_uuid")
    private UUID productUuid;

    @Enumerated(EnumType.STRING)
    @Column(name = "booking_line_status")
    private BookingLineStatusEnum bookingLineStatus;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "booking_uuid")
    private Booking booking;


}