package com.ielts.cmds.rd.infrastructure.entity;

import com.ielts.cmds.rd.domain.model.enums.ComponentEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.UUID;


/**
 * The persistent class for the minimum_score database table.
 *
 */
@Entity(name="minimum_score")
@Data
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class MinimumScore implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="minimum_score_uuid")
	private UUID minimumScoreUuid;

	@Enumerated(EnumType.STRING)
	private ComponentEnum component;

	@Column(name="minimum_score_value")
	private Double minimumScoreValue;

	@Column(name="updated_datetime")
	private OffsetDateTime updatedDatetime;

	//bi-directional many-to-one association to Selection
	@ManyToOne
	@JoinColumn(name="selection_uuid")
	private Selection selection;


}