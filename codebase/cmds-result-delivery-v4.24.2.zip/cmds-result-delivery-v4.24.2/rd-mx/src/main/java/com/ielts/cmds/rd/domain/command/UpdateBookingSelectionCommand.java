package com.ielts.cmds.rd.domain.command;

import com.ielts.cmds.application.command.BaseCommand;
import com.ielts.cmds.booking.common.out.model.BookingDetails;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class UpdateBookingSelectionCommand extends BaseCommand<BaseHeader, BookingDetails> {

    @Builder
    public UpdateBookingSelectionCommand(final BaseHeader eventHeader, final BookingDetails eventBody,
                                         final BaseEventErrors eventErrors, final BaseAudit eventAudit) {
        super(eventHeader, eventBody, eventErrors, eventAudit);
    }
}
