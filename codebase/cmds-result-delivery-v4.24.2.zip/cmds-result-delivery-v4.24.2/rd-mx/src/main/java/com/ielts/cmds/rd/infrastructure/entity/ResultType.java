package com.ielts.cmds.rd.infrastructure.entity;


import lombok.Data;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.UUID;


@Data
@Entity
@Table(name = "result_type")
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class ResultType implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 86183085442690969L;

    @Id
    @Column(name = "result_type_uuid")
    private UUID resultTypeUuid;

    @Column(name = "result_type_code")
    private String resultTypeCode;

    @Column(name = "result_type")
    private String resultTypeName;

    @Column(name = "effective_from_date")
    private LocalDate effectiveFromDate;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "updated_by")
    private String updatedBy;

    @Column(name = "created_datetime")
    private OffsetDateTime createdDatetime;

    @Version
    @Column(name = "concurrency_version")
    private Integer concurrencyVersion;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;

    @Column(name = "effective_to_date")
    private LocalDate effectiveToDate;

}
