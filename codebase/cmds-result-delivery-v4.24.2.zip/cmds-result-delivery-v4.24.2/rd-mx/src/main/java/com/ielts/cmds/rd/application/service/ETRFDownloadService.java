package com.ielts.cmds.rd.application.service;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.common.config.IApplicationService;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.rd.domain.command.TemplateDownloadCommand;
import com.ielts.cmds.rd.domain.service.ETRFDownloadDomainService;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.lang.reflect.InvocationTargetException;

import static com.ielts.cmds.rd.domain.RDConstants.EventType.POST_V1_ETRF_BOOKING_BOOKING_UUID_DOWNLOAD_ETRF;

@Slf4j
@RequiredArgsConstructor
@Service
public class ETRFDownloadService implements IApplicationService {

    private final ETRFDownloadDomainService etrfDownloadDomainService;

    @SneakyThrows
    @Override
    public void process(BaseEvent<? extends BaseHeader> baseEvent) throws ProcessingException {
        try {
            BaseEvent<UiHeader> uiEvent = (BaseEvent<UiHeader>) baseEvent;
            final UiHeader eventHeader = uiEvent.getEventHeader();
            final BaseEventErrors eventErrors = baseEvent.getEventErrors();

            //build command
            final TemplateDownloadCommand templateDownloadCommand = TemplateDownloadCommand.builder()
                    .eventHeader(eventHeader).eventErrors(eventErrors).eventAudit(baseEvent.getAudit()).build();

            //execute command
            etrfDownloadDomainService.on(templateDownloadCommand);

        } catch (IllegalArgumentException | JsonProcessingException | InvocationTargetException | IllegalAccessException e) {
            log.error("Failed to process " + POST_V1_ETRF_BOOKING_BOOKING_UUID_DOWNLOAD_ETRF + " event due to ", e);
            throw new ProcessingException(e.getMessage(), e);
        }
    }

    @Override
    public String getServiceIdentifier() {
        return POST_V1_ETRF_BOOKING_BOOKING_UUID_DOWNLOAD_ETRF;
    }

}
