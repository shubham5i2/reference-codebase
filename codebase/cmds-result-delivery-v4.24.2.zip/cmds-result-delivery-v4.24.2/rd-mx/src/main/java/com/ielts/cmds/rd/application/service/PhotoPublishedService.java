package com.ielts.cmds.rd.application.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.config.IApplicationService;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.domain.command.PhotoPublishedSelectionCommand;
import com.ielts.cmds.rd.domain.service.PhotoPublishedDomainService;
import com.ielts.cmds.testtaker.common.events.model.PhotoPublishedV1;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;


@Service
@RequiredArgsConstructor
@Slf4j
public class PhotoPublishedService implements IApplicationService {

    private final ObjectMapper objectMapper;

    private final PhotoPublishedDomainService photoPublishedDomainService;

    @Override
    public String getServiceIdentifier() {
        return RDConstants.EventType.PHOTO_PUBLISHED_EVENT;
    }

    @Override
    public void process(final BaseEvent<? extends BaseHeader> baseEvent) throws ProcessingException {

        try {
            final BaseHeader eventHeader = baseEvent.getEventHeader();
            final BaseEventErrors eventErrors = baseEvent.getEventErrors();
            final PhotoPublishedV1 photoPublishedV1 = objectMapper
                    .readValue(baseEvent.getEventBody(), PhotoPublishedV1.class);
            if (photoPublishedV1 == null) {
                throw new IllegalArgumentException("Payload is Empty");
            }
            // build command
            final PhotoPublishedSelectionCommand photoPublishedSelectionCommand = PhotoPublishedSelectionCommand.builder()
                    .eventHeader(eventHeader).eventBody(photoPublishedV1).eventErrors(eventErrors)
                    .build();
            // Execute command
            photoPublishedDomainService.on(photoPublishedSelectionCommand);
        } catch (IllegalArgumentException | JsonProcessingException e) {
            log.error("Failed to process Result event due to ", e);
            throw new ProcessingException(e.getMessage(), e);
        }

    }
}
