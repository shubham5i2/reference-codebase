package com.ielts.cmds.rd.application.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.config.IApplicationService;
import com.ielts.cmds.rd.application.utils.AbstractRoChangeService;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.domain.service.RoChangeDomainService;
import org.springframework.stereotype.Service;

@Service
public class RoChangedApplicationService extends AbstractRoChangeService implements IApplicationService {
	
	public RoChangedApplicationService(ObjectMapper objectMapper, RoChangeDomainService roChangeDomainService) {
		super(objectMapper, roChangeDomainService);
	}

	@Override
	public String getServiceIdentifier() {
		return RDConstants.EventType.RO_CHANGED_EVENT;
	}
	
}
