package com.ielts.cmds.rd.domain.service;

import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Objects;

import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.application.command.BaseCommand;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.infrastructure.event.publishers.BaseEventPublisher;

/**
 * @param <E> Event data type
 * @param <T> Command type
 */
public interface IDomainService<E, T extends BaseCommand<BaseHeader, E>> {

    /**
     * @param command Command to be invoked
     */
    @Transactional
    default void on(final T command) throws JsonProcessingException, InvocationTargetException, IllegalAccessException {
        BaseEventPublisher<BaseHeader> publisher = getPublisher();
        Objects.requireNonNull(publisher, "Event publisher cannot be null");

        List<BaseEvent<BaseHeader>> events = process(commandConverter(command));
        Objects.requireNonNull(events, "List of events cannot be null");
        if (events.isEmpty()) {
            throw new IllegalStateException("List of events cannot be empty");
        }

        events.forEach(publisher::publish);
    }

    T commandConverter(BaseCommand<BaseHeader, E> command);

    List<BaseEvent<BaseHeader>> process(T command) throws JsonProcessingException, InvocationTargetException, IllegalAccessException;

    BaseEventPublisher<BaseHeader> getPublisher();
}
