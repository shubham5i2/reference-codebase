package com.ielts.cmds.rd.application.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.config.IApplicationService;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.domain.command.TRFBookingSelectionsSearchCommand;
import com.ielts.cmds.rd.domain.model.out.TRFBookingSelectionsSearchRequestV1;
import com.ielts.cmds.rd.domain.service.TRFBookingSelectionsSearchDomainService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;


@Slf4j
@RequiredArgsConstructor
@Service
public class TRFBookingSelectionsSearchService implements IApplicationService {

    private final ObjectMapper objectMapper;

    private final TRFBookingSelectionsSearchDomainService trfBookingSelectionsSearchDomainService;

    @Override
    public void process(BaseEvent<? extends BaseHeader> baseEvent) throws ProcessingException {
        try {
            BaseEvent<UiHeader> uiEvent = (BaseEvent<UiHeader>) baseEvent;
            final UiHeader eventHeader = uiEvent.getEventHeader();
            final BaseEventErrors eventErrors = baseEvent.getEventErrors();

            final TRFBookingSelectionsSearchRequestV1 trfBookingSelectionsSearchRequestV1 = objectMapper
                    .readValue(baseEvent.getEventBody(), TRFBookingSelectionsSearchRequestV1.class);
            if (trfBookingSelectionsSearchRequestV1 == null) {
                throw new IllegalArgumentException(RDConstants.GenericConstants.EMPTY_PAYLOAD);
            }
            //build command

            final TRFBookingSelectionsSearchCommand trfBookingSelectionsSearchCommand = TRFBookingSelectionsSearchCommand.builder()
                    .eventHeader(eventHeader).eventBody(trfBookingSelectionsSearchRequestV1)
                    .eventErrors(eventErrors).eventAudit(baseEvent.getAudit()).build();

            //execute command
            trfBookingSelectionsSearchDomainService.on(trfBookingSelectionsSearchCommand);

        } catch (IllegalArgumentException | JsonProcessingException  e) {
            log.error("Failed to process rf/v1/booking/{bookingUuid}/selections/search event due to ", e);
            throw new ProcessingException(e.getMessage(), e);
        } catch (RbacValidationException e) {
            log.error("RBAC Validation Failed {}", e.getMessage());
        }
    }

    @Override
    public String getServiceIdentifier() {
        return RDConstants.EventType.POST_V1_TRF_BOOKING_BOOKING_UUID_SELECTIONS_SEARCH;
    }

}


