package com.ielts.cmds.rd.application.service;

import static com.ielts.cmds.rd.domain.RDConstants.EventType.BOOKING_CHANGED_EVENT;

import org.springframework.stereotype.Service;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.config.IApplicationService;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.domain.command.BookingChangeAnalysisCommand;
import com.ielts.cmds.rd.domain.model.out.ResultDeliveryBookingNodeV1;
import com.ielts.cmds.rd.domain.service.BookingChangeAnalysisDomainService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.InvocationTargetException;


@Service
@RequiredArgsConstructor
@Slf4j
public class BookingChangeAnalysisService implements IApplicationService {
	
	private final ObjectMapper objectMapper;

    private final BookingChangeAnalysisDomainService bookingChangeAnalysisDomainService;

    @Override
    public void process(BaseEvent<? extends BaseHeader> baseEvent) throws ProcessingException {

        try {
            final BaseHeader eventHeader = baseEvent.getEventHeader();
            final BaseEventErrors eventErrors = baseEvent.getEventErrors();
            final ResultDeliveryBookingNodeV1 resultDeliveryBookingNodeV1 = objectMapper
                    .readValue(baseEvent.getEventBody(), ResultDeliveryBookingNodeV1.class);

            if (resultDeliveryBookingNodeV1 == null) {
                throw new IllegalArgumentException("Payload is Empty");
            }

            // build command
            final BookingChangeAnalysisCommand bookingChangeAnalysisCommand = BookingChangeAnalysisCommand.builder()
                    .eventHeader(eventHeader).eventBody(resultDeliveryBookingNodeV1).eventErrors(eventErrors).eventAudit(baseEvent.getAudit())
                    .build();

            // Execute command
            bookingChangeAnalysisDomainService.on(bookingChangeAnalysisCommand);
        } catch (IllegalArgumentException | JsonProcessingException | InvocationTargetException | IllegalAccessException e) {
            log.error("Failed to process Booking event due to ", e);
            throw new ProcessingException(e.getMessage(), e);
        }

    }

    @Override
    public String getServiceIdentifier() {
        return BOOKING_CHANGED_EVENT;
    }
	
	

}
