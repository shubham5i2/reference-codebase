package com.ielts.cmds.rd.domain.validators.selection;

import com.ielts.cmds.rd.domain.model.SelectionDataBody;
import com.ielts.cmds.rd.domain.utils.ValidatorUtils;
import com.ielts.cmds.rd.domain.validators.selection.validation.ValidBookingData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.Objects;

@Slf4j
@Component
public class SelectionBookingValidator implements ConstraintValidator<ValidBookingData, SelectionDataBody> {
    @Override
    public boolean isValid(SelectionDataBody selectionDataBody, ConstraintValidatorContext constraintValidatorContext) {
        constraintValidatorContext.disableDefaultConstraintViolation();
        boolean isValid = true;
        if (!selectionDataBody.getBookingEntity().isPresent() && Objects.nonNull(selectionDataBody.getExternalBookingUuid())) {
            isValid = false;
            ValidatorUtils.addConstraintValidatorAndReturn(constraintValidatorContext,
                    "{cmds.invalid.bookingNotFound}", "externalBookingUuid");
        }
        return isValid;
    }
}
