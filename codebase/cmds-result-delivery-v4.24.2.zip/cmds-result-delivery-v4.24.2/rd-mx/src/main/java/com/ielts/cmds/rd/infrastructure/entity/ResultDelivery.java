package com.ielts.cmds.rd.infrastructure.entity;

import com.ielts.cmds.rd.domain.model.enums.DeliveryStatusEnum;
import lombok.Data;
import lombok.ToString;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import javax.persistence.*;
import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.UUID;

@Data
@Entity
@ToString(exclude = "result")
@Table(name = "result_delivery")
public class ResultDelivery implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -9166574440000059322L;

    @Id
    @Column(name = "result_delivery_uuid", updatable = false, nullable = false)
    private UUID resultDeliveryUuid;

    @Column(name = "system")
	private String system;

	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private DeliveryStatusEnum status;

	@Column(name = "status_updated_datetime")
	private OffsetDateTime statusUpdatedDateTime;

	@Column(name = "transaction_uuid")
	private UUID transactionUuid;

    @LazyCollection(LazyCollectionOption.FALSE)
    @ManyToOne(cascade=CascadeType.ALL)
    @JoinColumn(name = "result_uuid")
    private Result result;

}
