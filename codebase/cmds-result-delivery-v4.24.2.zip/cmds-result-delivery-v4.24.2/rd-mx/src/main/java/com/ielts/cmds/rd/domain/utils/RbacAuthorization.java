package com.ielts.cmds.rd.domain.utils;

import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rd.infrastructure.entity.Booking;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class RbacAuthorization {

    @Autowired
    private RbacUtils rbacUtils;

    public Boolean isUserAuthorized(Booking booking, UiHeader uiHeader, String permission) throws RbacValidationException {
        boolean isAuthorizationPassed;

        if (isLocationValidForProduct(uiHeader, permission, booking)) {
            isAuthorizationPassed = true;
        } else {
            isAuthorizationPassed = false;
        }
        return isAuthorizationPassed;
    }

    boolean isPartnerCodeValid(UiHeader uiHeader, String permission, Booking booking) throws RbacValidationException {
        boolean isValid;
        if (rbacUtils.hasAllPermissions(
                uiHeader.getXaccessToken(),
                permission,
                booking.getPartnerCode())) {
            isValid = true;
        } else {
            log.info("RBAC Validation Failed due to partner code restriction for {}", permission);
            isValid = false;
        }
        return isValid;
    }

    boolean isLocationValidForProduct(UiHeader uiHeader, String permission, Booking booking) throws RbacValidationException {
        boolean isValid;
        if (
                rbacUtils.isAuthorisedForLocationForProduct(
                        uiHeader.getXaccessToken(),
                        permission,
                        booking.getLocationUuid(),
                        booking.getProductUuid()
                )) {
            isValid = true;
        } else {
            log.info("RBAC Validation Failed due to location for product restriction for {}", permission);
            isValid = false;
        }
        return isValid;
    }
}
