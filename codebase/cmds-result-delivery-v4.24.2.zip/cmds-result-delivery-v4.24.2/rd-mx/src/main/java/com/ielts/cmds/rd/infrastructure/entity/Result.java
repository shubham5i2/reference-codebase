package com.ielts.cmds.rd.infrastructure.entity;

import lombok.*;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import javax.persistence.*;
import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Data
@ToString(exclude = {"resultLines", "resultDelivery", "resultsRenditions", "resultTrfPrintStatus"})
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "result")
public class Result implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -9166575440000059321L;

    @Id
    @Column(name = "result_uuid")
    private UUID resultUuid;

    @Column(name = "result_type_uuid")
    private UUID resultTypeUuid;

    @Column(name = "booking_uuid")
    private UUID bookingUuid;

    @Column(name = "result_score")
    private Double resultScore;

    @Column(name = "trf_number")
    private String trfNumber;

    @Column(name = "cefr_level")
    private String cefrLevel;

    @Column(name = "published_time")
    private OffsetDateTime publishedTime;

    @Column(name = "results_status_type_uuid")
    private UUID resultsStatusTypeUuid;

    @Column(name = "results_status_label_uuid")
    private UUID resultsStatusLabelUuid;

    @Column(name = "status_updated_datetime")
    private OffsetDateTime statusUpdatedDatetime;

    @Column(name = "result_status_comment")
    private String resultStatusComment;

    @Column(name = "administrator_comments")
    private String administratorComments;

    @Column(name = "absence")
    private boolean absence;

    @Column(name = "event_datetime")
    private OffsetDateTime eventDateTime;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDateTime;

    @Version
    @Column(name = "concurrency_version")
    private Integer concurrencyVersion;

    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(mappedBy = "result", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ResultLine> resultLines = new ArrayList<>();

    @OneToMany(mappedBy = "result", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ResultDelivery> resultDelivery = new ArrayList<>();

    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(mappedBy = "result", cascade = CascadeType.ALL)
    private List<ResultsRendition> resultsRenditions = new ArrayList<>();

    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(mappedBy = "result", cascade = CascadeType.ALL)
    private List<ResultTrfPrintStatus> resultTrfPrintStatus = new ArrayList<>();

}
