package com.ielts.cmds.rd.domain.utils;

import com.ielts.cmds.rd.domain.model.out.LinkedRecognisingOrganisationV1;
import com.ielts.cmds.rd.domain.model.out.RecognisedProductNodeV1;
import com.ielts.cmds.rd.domain.model.out.RecognisingOrganisationNodeV1;
import com.ielts.cmds.rd.infrastructure.entity.LinkedRecognisingOrganisation;
import com.ielts.cmds.rd.infrastructure.entity.RecognisedProduct;
import com.ielts.cmds.rd.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.rd.infrastructure.repositories.RecognisingOrganisationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class BuildRecognisingOrganisationNodeV1Utils {

    private final RecognisingOrganisationRepository recognisingOrganisationRepository;

    public RecognisingOrganisationNodeV1 buildRecognisingOrganisationNodeV1(UUID recognisingOrganisationUuid){
        RecognisingOrganisationNodeV1 roNodeV1 =  new RecognisingOrganisationNodeV1();
        if(Objects.nonNull(recognisingOrganisationUuid)) {
            Optional<RecognisingOrganisation> optionalRecognisingOrganisation = recognisingOrganisationRepository
                    .findById(recognisingOrganisationUuid);
            if (optionalRecognisingOrganisation.isPresent()){
                RecognisingOrganisation recognisingOrganisation = optionalRecognisingOrganisation.get();
                roNodeV1.setRecognisingOrganisationUuid(recognisingOrganisation.getRecognisingOrganisationUuid());
                roNodeV1.setOrganisationTypeUuid(recognisingOrganisation.getOrganisationTypeUuid());
                roNodeV1.setOrganisationId(recognisingOrganisation.getOrganisationId());
                roNodeV1.setName(recognisingOrganisation.getName());
                roNodeV1.setVerificationStatus(recognisingOrganisation.getVerificationStatus());
                roNodeV1.setPartnerCode(recognisingOrganisation.getPartnerCode());
                roNodeV1.setMethodOfDelivery(recognisingOrganisation.getMethodOfDelivery());
                roNodeV1.setParentRecognisingOrganisationUuid(recognisingOrganisation.getParentRecognisingOrganisationUuid());
                roNodeV1.setOrganisationStatus(recognisingOrganisation.getOrganisationStatus());
                roNodeV1.setOrganisationCode(recognisingOrganisation.getOrganisationCode());
                roNodeV1.setReplacedByRecognisingOrganisationUuid(recognisingOrganisation.getReplacedByRecognisingOrganisationUuid());
                List<RecognisedProductNodeV1> recognisedProductNodeV1List = recognisingOrganisation.getRecognisedProducts().stream()
                        .map(this::getRecognisingProductNodeV1).collect(Collectors.toList());
                roNodeV1.setRecognisedProducts(recognisedProductNodeV1List);

                if(Objects.nonNull(recognisingOrganisation.getLinkedRecognisingOrganisations())) {
                    List<LinkedRecognisingOrganisationV1> linkedRecognisingOrganisationV1List = recognisingOrganisation.getLinkedRecognisingOrganisations().stream()
                            .filter(e -> e.getDeleted().equals(false))
                            .map(this::getLinkedRecognisingOrganisationNodeV1).collect(Collectors.toList());
                    roNodeV1.setLinkedOrganisations(linkedRecognisingOrganisationV1List);
                } else {
                    roNodeV1.setLinkedOrganisations(null);
                }
            }
        }
        return  roNodeV1;
    }

private LinkedRecognisingOrganisationV1 getLinkedRecognisingOrganisationNodeV1(LinkedRecognisingOrganisation linkedRecognisingOrganisation) {
        LinkedRecognisingOrganisationV1 linkedRecognisingOrganisationV1 = new LinkedRecognisingOrganisationV1();
        linkedRecognisingOrganisationV1.setLinkedOrganisationUuid(linkedRecognisingOrganisation.getLinkedRecognisingOrganisationUuid());
        linkedRecognisingOrganisationV1.setLinkEffectiveFromDateTime(linkedRecognisingOrganisation.getLinkEffectiveFromDatetime());
        linkedRecognisingOrganisationV1.setLinkEffectiveToDateTime(linkedRecognisingOrganisation.getLinkEffectiveToDatetime());
        linkedRecognisingOrganisationV1.setLinkType(linkedRecognisingOrganisation.getLinkedRecognisingOrganisationType());
        return linkedRecognisingOrganisationV1;
        }

    private RecognisedProductNodeV1 getRecognisingProductNodeV1(RecognisedProduct e) {
        RecognisedProductNodeV1 recognisedProductNodeV1 = new RecognisedProductNodeV1();
        recognisedProductNodeV1.setProductUuid(e.getProductUuid());
        recognisedProductNodeV1.setRecognisedProductUuid(e.getRecognisedProductUuid());
        recognisedProductNodeV1.setEffectiveFromDateTime(e.getEffectiveFromDatetime());
        recognisedProductNodeV1.setEffectiveToDateTime(e.getEffectiveToDatetime());
        return recognisedProductNodeV1;
    }
}
