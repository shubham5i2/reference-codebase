/**
 * 
 */
package com.ielts.cmds.rd.domain.validators.selection.validation;

/**
 * @author vedire
 *
 */
public interface BookingValidation {

}
