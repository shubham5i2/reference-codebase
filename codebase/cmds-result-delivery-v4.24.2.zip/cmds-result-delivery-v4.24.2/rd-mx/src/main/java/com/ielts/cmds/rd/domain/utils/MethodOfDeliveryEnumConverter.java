package com.ielts.cmds.rd.domain.utils;

import java.util.stream.Stream;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.ielts.cmds.organisation.common.enums.MethodOfDeliveryEnum;


@Converter(autoApply = true)
public class MethodOfDeliveryEnumConverter implements AttributeConverter<MethodOfDeliveryEnum, String>{

	@Override
	public String convertToDatabaseColumn(MethodOfDeliveryEnum methodOfDeliveryEnum) {
		if (methodOfDeliveryEnum == null) {
			return null;
		}
		return methodOfDeliveryEnum.getValue();
	}

	@Override
	public MethodOfDeliveryEnum convertToEntityAttribute(String convertedMethodOfDeliveryEnum) {
		if (convertedMethodOfDeliveryEnum == null) {
			return null;
		}
		return Stream.of(MethodOfDeliveryEnum.values())
				.filter(methodOfDeliveryEnum -> methodOfDeliveryEnum.getValue().equals(convertedMethodOfDeliveryEnum))
				.findFirst()
				.orElseThrow(IllegalArgumentException::new);
	}
}
