package com.ielts.cmds.rd.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.rd.domain.command.LegacyResultPublishFailCommand;
import com.ielts.cmds.rd.domain.utils.BuildResultReleaseNodeV1Utils;
import com.ielts.cmds.rd.infrastructure.repositories.ResultRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.lang.reflect.InvocationTargetException;

@Service
public class LegacyResultDeliveryChangeFailedDomainService extends AbstractResultDeliveryDomainService {

    @Autowired
    public LegacyResultDeliveryChangeFailedDomainService(ObjectMapper objectMapper, ResultRepository resultRepository,
                                                         ApplicationEventPublisher applicationEventPublisher, BuildResultReleaseNodeV1Utils buildResultReleaseNodeV1Utils) {
        super(objectMapper, resultRepository, applicationEventPublisher, buildResultReleaseNodeV1Utils);  }

    @Transactional
    public void on(LegacyResultPublishFailCommand command) throws JsonProcessingException, InvocationTargetException, IllegalAccessException {
        process(command);
    }


}