package com.ielts.cmds.rd.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.rd.domain.command.UpdateBookingSelectionCommand;
import com.ielts.cmds.rd.domain.utils.BuildResultDeliveryBookingNodeV1Utils;
import com.ielts.cmds.rd.domain.utils.BuildResultReleaseNodeV1Utils;
import com.ielts.cmds.rd.infrastructure.repositories.BookingRepository;
import com.ielts.cmds.rd.infrastructure.repositories.ResultRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Slf4j
public class BookingUpdatedDomainService extends AbstractBookingDomainService {

    @Autowired
    public BookingUpdatedDomainService(BookingRepository bookingRepository, ObjectMapper objectMapper, BuildResultDeliveryBookingNodeV1Utils resultDeliveryBookingNodeV1Utils, ResultRepository resultRepository, BuildResultReleaseNodeV1Utils resultReleaseNodeV1Utils, ApplicationEventPublisher applicationEventPublisher) {
        super(bookingRepository, objectMapper, resultDeliveryBookingNodeV1Utils, resultRepository, resultReleaseNodeV1Utils, applicationEventPublisher);
    }

    @Transactional
    public void on(UpdateBookingSelectionCommand command) throws JsonProcessingException {
        process(command);
    }

}
