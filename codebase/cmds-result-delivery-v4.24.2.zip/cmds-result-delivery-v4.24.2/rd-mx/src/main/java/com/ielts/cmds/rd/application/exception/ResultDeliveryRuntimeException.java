package com.ielts.cmds.rd.application.exception;

public class ResultDeliveryRuntimeException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = 5739366016725073156L;

    public ResultDeliveryRuntimeException(String message) {
        super(message);
    }
}
