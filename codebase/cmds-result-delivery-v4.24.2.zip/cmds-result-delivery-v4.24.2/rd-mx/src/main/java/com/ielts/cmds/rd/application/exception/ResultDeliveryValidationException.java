package com.ielts.cmds.rd.application.exception;

import com.ielts.cmds.common.exception.ProcessingException;

public class ResultDeliveryValidationException extends ProcessingException{
    private static final long serialVersionUID = 1L;


    public ResultDeliveryValidationException(String message, Throwable cause) {
        super(message, cause);
    }
}