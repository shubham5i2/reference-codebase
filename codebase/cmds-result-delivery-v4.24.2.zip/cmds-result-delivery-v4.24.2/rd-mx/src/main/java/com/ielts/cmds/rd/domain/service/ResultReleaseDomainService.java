package com.ielts.cmds.rd.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.application.command.BaseCommand;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.application.exception.ResultDeliveryValidationException;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.domain.command.ResultReleaseSelectionCommand;
import com.ielts.cmds.rd.domain.enums.ResultDataAnalysisOutcomeFlag;
import com.ielts.cmds.rd.domain.model.BookingResultChangedEventV1;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import com.ielts.cmds.rd.domain.utils.BuildResultReleaseNodeV1Utils;
import com.ielts.cmds.rd.domain.utils.DomainEventsPublisher;
import com.ielts.cmds.rd.infrastructure.entity.Booking;
import com.ielts.cmds.rd.infrastructure.entity.Result;
import com.ielts.cmds.rd.infrastructure.entity.ResultLine;
import com.ielts.cmds.rd.infrastructure.entity.ResultsStatusType;
import com.ielts.cmds.rd.infrastructure.repositories.BookingRepository;
import com.ielts.cmds.rd.infrastructure.repositories.ResultRepository;
import com.ielts.cmds.rd.infrastructure.repositories.ResultsStatusTypeRepository;
import com.ielts.cmds.rm.common.out.model.ResultLineEventV1;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.constraints.NotNull;
import java.lang.reflect.InvocationTargetException;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static java.time.ZoneOffset.UTC;

@Service
@Slf4j
@RequiredArgsConstructor
public class ResultReleaseDomainService {

    private final ObjectMapper objectMapper;

    private final ResultRepository resultRepository;

    private final BookingRepository bookingRepository;

    private final DomainEventsPublisher domainEventsPublisher;

    private final ResultsStatusTypeRepository resultsStatusTypeRepository;

    private final BuildResultReleaseNodeV1Utils resultReleaseNodeV1Utils;


    @Transactional
    public void on(@NotNull final ResultReleaseSelectionCommand command) throws JsonProcessingException, InvocationTargetException, IllegalAccessException {

        log.info("Received Result released selection event with result uuid {}", command.getEventBody().getBookingResultInfo().getResultUuid());

        List<BaseEvent<BaseHeader>> eventList = new ArrayList<>();
        eventList.add(getResultReleaseEvent(command));

        //EventList Publishing using domainEventsPublisher
        domainEventsPublisher.baseEventListPublisher(eventList);

    }

    private BaseEvent<BaseHeader> getResultReleaseEvent(ResultReleaseSelectionCommand command) throws JsonProcessingException, InvocationTargetException, IllegalAccessException {

        log.info("Received Result released event with result uuid {}", command.getEventBody().getBookingResultInfo().getResultUuid());

        Optional<ResultReleasedNodeV1> resultReleasedNodeV1 = Optional.empty();
        String eventBody = null;
        Map<String, String> ttDataUpdateMap = Optional
                .ofNullable(command.getEventHeaders().getEventContext())
                .orElseGet(HashMap::new);


        BaseEvent<BaseHeader> event;
        final BaseHeader eventHeader = new BaseHeader();
        BaseEventErrors baseEventErrors = null;
        Optional<Result> optionalResult = resultRepository.findById(command.getEventBody().getBookingResultInfo().getResultUuid());
        try {
            resultValidation(command, optionalResult);
            ttDataUpdateMap = resultInfoUpdateFlag(optionalResult, command);
            String trfNumber = command.getEventBody().getBookingResultInfo().getTrfNumber();
            if (Objects.isNull(command.getEventBody().getBookingResultInfo().getResultTypeUuid())) {
                eventBody = null;
                baseEventErrors = resultReleaseNodeV1Utils.getResultTypeEventErrors("Result Type UUid missing");
                buildHeader(command, eventHeader, resultReleasedNodeV1, ttDataUpdateMap);
            } else if (Objects.isNull(trfNumber)) {
                log.info("TRF Number is Null {}", command.getEventBody().getBookingResultInfo().getTrfNumber());
                eventBody = null;
                baseEventErrors = resultReleaseNodeV1Utils.getResultTypeEventErrors("TRF Number is missing");
                buildHeader(command, eventHeader, resultReleasedNodeV1, ttDataUpdateMap);
            } else {
                Result result = updateResultDetails(command, optionalResult);
                ResultReleasedNodeV1 resultReleasedNodeV11 = resultReleaseNodeV1Utils.buildResultReleasedNodeV1(result.getResultUuid());
                resultReleasedNodeV11.setReferenceData(resultReleaseNodeV1Utils.getReferenceData(result));
                resultReleasedNodeV1 = Optional.of(resultReleasedNodeV11);
                eventBody = objectMapper.writeValueAsString(resultReleasedNodeV1);
                buildHeader(command, eventHeader, resultReleasedNodeV1, ttDataUpdateMap);
                optionalResult = Optional.of(result);
            }
        } catch (final ResultDeliveryValidationException e) {
            log.error("ResultReleaseSelectionCommand execution failed", e);
            eventBody = null;
            baseEventErrors = resultReleaseNodeV1Utils.getBaseEventErrors(e);
            buildHeader(command, eventHeader, resultReleasedNodeV1, ttDataUpdateMap);
        }
        if (optionalResult.isPresent() && Objects.nonNull(optionalResult.get().getBookingUuid())) {
            Optional<Booking> optionalBooking = bookingRepository.findById(optionalResult.get().getBookingUuid());
            optionalBooking.ifPresent(booking -> eventHeader.setPartnerCode(booking.getPartnerCode()));
        }

        event = new BaseEvent<>(eventHeader, eventBody, baseEventErrors, command.getAudit());
        return event;
    }

    protected void resultValidation(final ResultReleaseSelectionCommand command, final Optional<Result> optionalResult) throws ResultDeliveryValidationException {
        if (optionalResult.isPresent()) {
            LocalDateTime localDateTime = optionalResult.get().getEventDateTime().toLocalDateTime();
            if (!(command.getEventHeaders().getEventDateTime().isAfter(localDateTime))) {
                throw new ResultDeliveryValidationException(String.format("Received Event Date time is before this : %s  " + "for this Result UUID : %s"
                        , localDateTime, command.getEventBody().getBookingResultInfo().getResultUuid()), new Throwable());
            }
        }
    }

    private Result updateResultDetails(final ResultReleaseSelectionCommand command, final Optional<Result> optionalResult) {
        Result result = optionalResult.orElseGet(() -> Result.builder().resultUuid(command.getEventBody().getBookingResultInfo().getResultUuid()).build());
        if (Objects.nonNull(command.getEventBody().getBookingResultInfo().getOverallScore())) {
            result.setResultScore(command.getEventBody().getBookingResultInfo().getOverallScore().doubleValue());
        } else {
            result.setResultScore(0.0);
        }
        result.setResultTypeUuid(command.getEventBody().getBookingResultInfo().getResultTypeUuid());
        result.setBookingUuid(command.getEventBody().getBookingResultInfo().getBookingUuid());
        result.setTrfNumber(command.getEventBody().getBookingResultInfo().getTrfNumber());
        String cefrLevel = command.getEventBody().getBookingResultInfo().getCefrLevel();
        result.setCefrLevel(cefrLevel);
        if (Objects.isNull(cefrLevel)) {
            result.setCefrLevel(String.valueOf(0));
        }
        result.setResultUuid(command.getEventBody().getBookingResultInfo().getResultUuid());
        result.setResultsStatusTypeUuid(command.getEventBody().getBookingResultInfo().getBookingResultStatus().getResultStatusTypeUuid());
        result.setResultsStatusLabelUuid(command.getEventBody().getBookingResultInfo().getBookingResultStatus().getResultStatusLabelUuid());
        result.setAbsence(false);
        result.setAdministratorComments(command.getEventBody().getBookingResultInfo().getAdministratorComments());
        result.setEventDateTime(OffsetDateTime.of(command.getEventHeaders().getEventDateTime(), UTC));
        result.setUpdatedDateTime(OffsetDateTime.now(UTC));
        result.setResultStatusComment(command.getEventBody().getBookingResultInfo().getBookingResultStatus().getResultStatusComment());
        result.setStatusUpdatedDatetime(command.getEventBody().getBookingResultInfo().getBookingResultStatus().getResultStatusUpdateDatetime());
        result.setPublishedTime(OffsetDateTime.now(UTC));

        if (Objects.isNull(result.getResultLines())) {
            result.setResultLines(updateResultLineDetails(result, command));
        } else {
            result.getResultLines().clear();
            result.getResultLines().addAll(updateResultLineDetails(result, command));
        }
        checkForPermanentlyWithheld(result);
        resultRepository.save(result);

        return result;
    }

    private void checkForPermanentlyWithheld(Result result) {
        if (Objects.nonNull(result.getResultsStatusTypeUuid())) {
            Optional<ResultsStatusType> optionalResultsStatusType = resultsStatusTypeRepository.findById(result.getResultsStatusTypeUuid());
            if (optionalResultsStatusType.isPresent()) {
                ResultsStatusType resultsStatusType = optionalResultsStatusType.get();
                if (resultsStatusType.getResultStatusCode().equals(RDConstants.EventType.PERMANENTLY_WITHHELD)) {
                    result.setResultScore(0.0);
                    result.getResultLines().forEach(e -> e.setResultLineScore(0.0));
                }
            }
        }
    }

    private Map<String, String> resultInfoUpdateFlag(Optional<Result> optionalResult, BaseCommand<BaseHeader, BookingResultChangedEventV1> command) {
        Map<String, String> map = new HashMap<>();
        if (!optionalResult.isPresent()) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
            map.put(ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getValue());
        }
        optionalResult.ifPresent(result -> deltaFlagCalculation(command, result, map));

        return map;
    }

    private void deltaFlagCalculation(BaseCommand<BaseHeader, BookingResultChangedEventV1> command, Result result, Map<String, String> map) {
        Optional<ResultsStatusType> optionalResultStatusType = resultsStatusTypeRepository.findById(command.getEventBody().getBookingResultInfo().getBookingResultStatus().getResultStatusTypeUuid());
        if ((!Objects.equals(result.getResultsStatusTypeUuid(), command.getEventBody().getBookingResultInfo().getBookingResultStatus().getResultStatusTypeUuid()))
                && (optionalResultStatusType.isPresent()) && ((optionalResultStatusType.get().getResultStatusCode().equals("RELEASED")) || (optionalResultStatusType.get().getResultStatusCode().equals("PERMANENTLY_WITHHELD")))) {
            map.put(ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getValue());
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        }
        if (!Objects.equals(result.getTrfNumber(), command.getEventBody().getBookingResultInfo().getTrfNumber())) {
            map.put(ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getValue());
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        }
        if (!Objects.equals(result.getCefrLevel(), command.getEventBody().getBookingResultInfo().getCefrLevel())) {
            map.put(ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getValue());
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        }
        if (!Objects.equals(result.getResultScore().floatValue(), command.getEventBody().getBookingResultInfo().getOverallScore())) {
            map.put(ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getValue());
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        }
        if (result.getResultLines().size() != command.getEventBody().getBookingResultInfo().getBookingResultLines().size()) {
            map.put(ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getValue());
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        } else {
            command.getEventBody().getBookingResultInfo().getBookingResultLines().forEach(e -> result.getResultLines().stream().filter(compareResultLinesUUID(e)).forEach(ct ->
                    comparingResultLineScore(map, ct.getResultLineScore(), e.getResultLineScore())));
        }
        if (!Objects.equals(result.getResultsStatusLabelUuid(), command.getEventBody().getBookingResultInfo().getBookingResultStatus().getResultStatusLabelUuid())) {
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        }
    }

    private Predicate<ResultLine> compareResultLinesUUID(ResultLineEventV1 e) {
        return temp -> temp.getResultLineUuid().equals(e.getResultLineUuid());
    }

    private void comparingResultLineScore(Map<String, String> map, Double resultLineScore, Float resultLineScore2) {
        if (!Objects.equals(resultLineScore.floatValue(), resultLineScore2)) {
            map.put(ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getValue());
            map.put(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey(), ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getValue());
        }
    }


    private List<ResultLine> updateResultLineDetails(Result result, BaseCommand<BaseHeader, BookingResultChangedEventV1> command) {
        return command.getEventBody().getBookingResultInfo().getBookingResultLines().stream()
                .map(e -> getResultLine(result, e))
                .collect(Collectors.toList());
    }

    private ResultLine getResultLine(Result result, ResultLineEventV1 resultLineDetails) {
        ResultLine resultLine = new ResultLine();
        resultLine.setResultLineUuid(resultLineDetails.getResultLineUuid());
        resultLine.setProductUuid(resultLineDetails.getProductUuid());
        resultLine.setResultLineScore(resultLineDetails.getResultLineScore().doubleValue());
        resultLine.setBookingLineUuid(resultLineDetails.getBookingLineUuid());
        resultLine.setAbsence(false);
        resultLine.setUpdatedDateTime(OffsetDateTime.now(UTC));
        resultLine.setResult(result);
        return resultLine;
    }

    public void buildHeader(final ResultReleaseSelectionCommand command, BaseHeader eventHeader, Optional<ResultReleasedNodeV1> resultNodeV1, Map<String, String> ttDataUpdateMap) {
        eventHeader.setCorrelationId(command.getEventHeaders().getCorrelationId());
        eventHeader.setEventDateTime(command.getEventHeaders().getEventDateTime());
        eventHeader.setTransactionId(command.getEventHeaders().getTransactionId());
        eventHeader.setPartnerCode(command.getEventHeaders().getPartnerCode());
        Map<String , String> eventContext = new HashMap<>(ttDataUpdateMap);
        if(Objects.nonNull(command.getEventBody().getBookingResultInfo().getResultUuid())) {
            eventContext.put("resultUuid", command.getEventBody().getBookingResultInfo().getResultUuid().toString());
        }
        eventHeader.setEventContext(eventContext);
        if (resultNodeV1.isPresent()) {
            eventHeader.setEventName(RDConstants.EventType.SELECTION_RESULT_RELEASED);
        } else {
            eventHeader.setEventName(RDConstants.EventType.SELECTION_RESULT_RELEASED_FAILED);
        }
    }

}
