package com.ielts.cmds.rd.domain.model;

import com.ielts.cmds.ors.common.out.model.OrganisationSelectionNodeV1ORS;
import com.ielts.cmds.rd.domain.validators.selection.validation.*;
import com.ielts.cmds.rd.infrastructure.entity.Booking;
import com.ielts.cmds.rd.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.rd.infrastructure.entity.Selection;
import lombok.*;

import java.time.LocalDateTime;
import java.util.Optional;


@Getter
@Setter
@ValidSelectionBookingProduct(groups = {SelectionCreateGroupValidation.class, SelectionUpdateGroupValidation.class})
@ValidSelectionData(groups = {SelectionCreateGroupValidation.class, SelectionUpdateGroupValidation.class})
@ValidBookingData(groups = {SelectionCreateGroupValidation.class})
@ValidMinimumScore(groups = {SelectionCreateGroupValidation.class, SelectionUpdateGroupValidation.class})
@NoArgsConstructor
@Builder(toBuilder = true)
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class SelectionDataBody extends OrganisationSelectionNodeV1ORS {

    private Selection selectionEntity;

    private Booking bookingEntity;

    private RecognisingOrganisation organisationEntity;

    private LocalDateTime eventDateTime;

    public Optional<Selection> getSelectionEntity() {
        return Optional.ofNullable(selectionEntity);
    }

    public Optional<Booking> getBookingEntity() {
        return Optional.ofNullable(bookingEntity);
    }

    public Optional<RecognisingOrganisation> getOrganisationEntity() {
        return Optional.ofNullable(organisationEntity);
    }
}
