package com.ielts.cmds.rd.infrastructure.entity;

import lombok.*;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.UUID;

@Getter
@Setter
@Entity
@Table(name = "country")
@NoArgsConstructor
@AllArgsConstructor
@Builder
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class Country {

    @Id
    @Column(name = "country_uuid")
    private UUID countryUuid;

    @Column(name = "country_iso3_code")
    private String countryIso3Code;

    @Column(name = "country_name")
    private String countryName;

    @Column(name = "effective_from_date")
    private LocalDate effectiveFromDate;

    @Column(name = "legacy_reference")
    private String legacyReference;

    @Column(name = "effective_to_date")
    private LocalDate effectiveToDate;

    @Column(name = "created_datetime")
    private OffsetDateTime createdDatetime;

    @Column(name = "created_by")
    private String createdBy;

    @Version
    @Column(name = "concurrency_version")
    private Integer concurrencyVersion;

    @Column(name = "updated_datetime")
    private OffsetDateTime updatedDatetime;

    @Column(name = "updated_by")
    private String updatedBy;

}
