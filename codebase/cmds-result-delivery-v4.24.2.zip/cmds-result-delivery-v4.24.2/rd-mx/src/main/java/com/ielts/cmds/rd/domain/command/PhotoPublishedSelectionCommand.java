package com.ielts.cmds.rd.domain.command;


import com.ielts.cmds.application.command.BaseCommand;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.testtaker.common.events.model.PhotoPublishedV1;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class PhotoPublishedSelectionCommand extends BaseCommand<BaseHeader, PhotoPublishedV1> {

    @Builder
    public PhotoPublishedSelectionCommand(BaseHeader eventHeader, PhotoPublishedV1 eventBody,
                                         BaseEventErrors eventErrors) {
        super(eventHeader, eventBody, eventErrors, null);
    }
}
