/**
 *
 */
package com.ielts.cmds.rd.application.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.config.IApplicationService;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.ors.common.out.model.OrganisationSelectionNodeV1ORS;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.domain.RDConstants.EventType;
import com.ielts.cmds.rd.domain.command.ROSelectionCommand;
import com.ielts.cmds.rd.domain.service.OrganizationSelectionDomainService;
import com.ielts.cmds.rd.domain.service.UAOrganisationSelectionDomainService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Objects;

/**
 * @author vedire
 *
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class OrganizationSelectionApplicationService implements IApplicationService {

    private final OrganizationSelectionDomainService organizationSelectionDomainService;

    private final UAOrganisationSelectionDomainService uaOrganisationSelectionDomainService;

    private final ObjectMapper objectMapper;

    @Override
    public String getServiceIdentifier() {
        return EventType.SELECTION_CHANGED;
    }

    @Override
    public void process(BaseEvent<? extends BaseHeader> baseEvent) throws ProcessingException {

        try {
            BaseEventErrors eventErrors = baseEvent.getEventErrors();
            OrganisationSelectionNodeV1ORS organizationSelection = objectMapper.readValue(baseEvent.getEventBody(),
                    OrganisationSelectionNodeV1ORS.class);
            if (organizationSelection == null) {
                throw new IllegalArgumentException(RDConstants.GenericConstants.EMPTY_PAYLOAD);
            }

            // build command
            final ROSelectionCommand roSelection = ROSelectionCommand.builder()
                    .eventHeader(baseEvent.getEventHeader()).eventBody(organizationSelection)
                    .eventErrors(eventErrors).eventAudit(baseEvent.getAudit())
                    .build();

            // Execute command
            if (Objects.isNull(organizationSelection.getSelection().getOrganisation())) {
                uaOrganisationSelectionDomainService.onCommand(roSelection);
            }
            else {
                organizationSelectionDomainService.onCommand(roSelection);
            }
        } catch (Exception e) {
            log.error("RO Selection create/update failed. Event {}", baseEvent, e);
            throw new ProcessingException(e.getMessage(), e);
        }

    }

}
