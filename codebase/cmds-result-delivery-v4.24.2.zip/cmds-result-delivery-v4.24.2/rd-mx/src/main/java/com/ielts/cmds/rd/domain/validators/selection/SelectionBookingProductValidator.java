package com.ielts.cmds.rd.domain.validators.selection;

import com.ielts.cmds.rd.domain.model.SelectionDataBody;
import com.ielts.cmds.rd.domain.validators.selection.validation.ValidSelectionBookingProduct;
import com.ielts.cmds.rd.infrastructure.entity.Booking;
import com.ielts.cmds.rd.infrastructure.entity.RecognisedProduct;
import com.ielts.cmds.rd.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.rd.infrastructure.repositories.RecognisingOrganisationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.ListJoin;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * @author vedire
 */

@Slf4j
@RequiredArgsConstructor
@Component
public class SelectionBookingProductValidator implements ConstraintValidator<ValidSelectionBookingProduct, SelectionDataBody> {

    private final RecognisingOrganisationRepository organisationRepository;

    @Override
    public boolean isValid(final SelectionDataBody selectionDataBody, final ConstraintValidatorContext context) {
        boolean isValid = true;
        if (selectionDataBody.getBookingEntity().isPresent() && selectionDataBody.getOrganisationEntity().isPresent()) {
            RecognisingOrganisation recognisingOrganisation = selectionDataBody.getOrganisationEntity().orElse(null);
            try {
                context.disableDefaultConstraintViolation();
                Specification<RecognisingOrganisation> selectionSpec = getBookingSpecification(selectionDataBody);
                long selectionCount = organisationRepository.count(selectionSpec);
                assert recognisingOrganisation != null;
                if (selectionCount == 0 || recognisingOrganisation.getRecognisedProducts().stream()
                        .noneMatch(e -> OffsetDateTime.now().isBefore(e.getEffectiveToDatetime())
                                && OffsetDateTime.now().isAfter(e.getEffectiveFromDatetime()))) {
                    context.buildConstraintViolationWithTemplate("{cmds.invalid.notValidProduct}")
                            .addPropertyNode("externalBookingUuid").addConstraintViolation();
                    isValid = false;
                }
            } catch (Exception ex) {
                log.error("Exception in other: ", ex);
                return false;
            }
        }

        return isValid;

    }

    public Specification<RecognisingOrganisation> getBookingSpecification(final SelectionDataBody selectionDataBody) {

        return (root, query, cb) -> {
            List<Predicate> predicateList = new ArrayList<>();

            ListJoin<RecognisingOrganisation, RecognisedProduct> recognisingProd = root.joinList("recognisedProducts",
                    JoinType.INNER);
            Root<Booking> bookingRoot = query.from(Booking.class);

            Predicate booingExtUuid = cb.equal(bookingRoot.get("externalBookingUuid"),
                    selectionDataBody.getExternalBookingUuid());

            Predicate orgUUID = cb.and(cb.equal(root.get("recognisingOrganisationUuid"), selectionDataBody.getSelection().getOrganisation().getOrganisationUuid()), booingExtUuid);
            Predicate prodPredicate = cb
                    .and(cb.equal(recognisingProd.get("productUuid"), bookingRoot.get("productUuid")), orgUUID);

            predicateList.add(prodPredicate);

            Predicate[] predicates = new Predicate[predicateList.size()];
            query.distinct(true);
            return cb.and(predicateList.toArray(predicates));

        };

    }

}
