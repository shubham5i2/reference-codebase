package com.ielts.cmds.rd.domain.utils;

import com.amazonaws.services.s3.model.PutObjectResult;
import com.ielts.cmds.application.command.BaseCommand;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.cre.generator.PDFGenerator;
import com.ielts.cmds.cre.model.GeneratorData;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.rd.application.exception.ResultDeliveryValidationException;
import com.ielts.cmds.rd.domain.model.ReportGenerationModel;
import com.ielts.cmds.rd.domain.model.enums.RenditionTypeCodeEnum;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import com.ielts.cmds.rd.infrastructure.entity.RenditionType;
import com.ielts.cmds.rd.infrastructure.entity.Result;
import com.ielts.cmds.rd.infrastructure.entity.ResultsRendition;
import com.ielts.cmds.rd.infrastructure.repositories.RenditionTypeRepository;
import com.ielts.cmds.rd.infrastructure.repositories.ResultsRenditionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Component
@RequiredArgsConstructor
@Slf4j
public class PrepareTemplateData {

    private final BuildPartnerCodeUtils buildPartnerCodeUtils;

    private final RenditionTypeRepository renditionTypeRepository;

    static Map<String, String> component = new HashMap<>();

    static {
        component.put("L", "Listening");
        component.put("R", "Reading");
        component.put("W", "Writing");
        component.put("S", "Speaking");
    }

    public File generateTemplateFileName(BaseCommand<BaseHeader, ResultReleasedNodeV1> command, RenditionTypeCodeEnum renditionTypeCodeEnum) {
        LocalDate testDate = LocalDate.parse(command.getEventBody().getBookingDetails().getTestDate().toString());
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        String candidateTestDate = formatter.format(testDate);

        return new File(command.getEventBody().getBookingDetails().getCompositeCandidateNumber() + "-" + candidateTestDate + "-" + renditionTypeCodeEnum + ".pdf");
    }

    public BaseEventErrors buildEventError(Exception exception) {
        BaseEventErrors baseEventErrors;
        List<ErrorDescription> errorDescriptions = new ArrayList<>();
        ErrorDescription errorDescription = new ErrorDescription();
        errorDescription.setMessage(exception.getMessage());
        errorDescription.setType(ErrorTypeEnum.VALIDATION);
        errorDescription.setTitle("Validation Failed");
        errorDescription.setErrorCode("V045");
        errorDescriptions.add(errorDescription);
        baseEventErrors = new BaseEventErrors(errorDescriptions);
        return baseEventErrors;
    }

    //method to save TRF data into results rendition
    public ResultsRendition updateResultsRenditionDetails(BaseCommand<BaseHeader, ResultReleasedNodeV1> command, Result result, ResultsRenditionRepository resultsRenditionRepository, File outputFile, PutObjectResult putObjectResult, RenditionTypeCodeEnum renditionTypeCode) throws ResultDeliveryValidationException {
        ResultsRendition resultsRendition = new ResultsRendition();
        RenditionType renditionType = renditionTypeRepository.findAll().stream().filter(renditionTypeRef ->
                renditionTypeRef.getRenditionTypeCodeEnum().equals(renditionTypeCode)).findFirst().orElseThrow(() ->
                new ResultDeliveryValidationException("Rendition type uuid not found", new Throwable()));
        resultsRendition.setRenditionTypeUuid(renditionType.getRenditionTypeUuid());
        resultsRendition.setResultsRenditionUuid(UUID.randomUUID());
        resultsRendition.setResultUuid(result.getResultUuid());
        resultsRendition.setRenditionFilePath(outputFile.getName());
        resultsRendition.setRenditionFileVersion(putObjectResult.getVersionId());
        resultsRendition.setRenditionDescription("Normal Results");
        resultsRendition.setUpdatedDatetime(OffsetDateTime.now());
        resultsRendition.setReportGenerationRequestedUuid(UUID.fromString(command.getEventHeaders().getEventContext().get("reportGenerationRequestedUuid")));

        resultsRenditionRepository.save(resultsRendition);
        log.info("Template data saved into database successfully");
        return resultsRendition;
    }

    //method to build header for outcome EventHeader
    public BaseHeader buildHeader(BaseCommand<BaseHeader, ResultReleasedNodeV1> command, BaseHeader eventHeader, String generatedEventName) {
        eventHeader.setCorrelationId(command.getEventHeaders().getCorrelationId());
        eventHeader.setEventDateTime(LocalDateTime.now());
        eventHeader.setTransactionId(command.getEventHeaders().getTransactionId());
        eventHeader.setPartnerCode(getPartnerCode(command));
        eventHeader.setEventContext(command.getEventHeaders().getEventContext());
        if (Objects.nonNull(command.getEventBody().getBookingDetails().getBookingUuid())) {
            eventHeader.getEventContext().put("bookingUuid", command.getEventBody().getBookingDetails().getBookingUuid().toString());
        }
        if (Objects.nonNull(command.getEventBody().getResultDetails().getResultUuid())) {
            eventHeader.getEventContext().put("resultUuid", command.getEventBody().getResultDetails().getResultUuid().toString());
        }
        eventHeader.setEventDiscriminator(command.getEventHeaders().getEventDiscriminator());
        eventHeader.setEventName(generatedEventName);
        return eventHeader;
    }

    public String getPartnerCode(BaseCommand<BaseHeader, ResultReleasedNodeV1> command) {
        return buildPartnerCodeUtils.getPartnerCode(command.getEventBody().getBookingDetails().getBookingUuid());
    }


    public byte[] generatePDF(GeneratorData trfGenerationModel, PDFGenerator pdfGenerator) throws IOException, InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        return pdfGenerator.generatePDF(trfGenerationModel);
    }

    public String getTemplateNotes(String componentName) throws ResultDeliveryValidationException {
        if (component.containsKey(componentName)) {
            return String.format("This Test Report Form includes the result of a %s retake. Please see the Administrator Comments below for further information.", component.get(componentName));
        } else {
            throw new ResultDeliveryValidationException("Invalid component found " + componentName, new Throwable());
        }
    }

    public void setSSRSpecificComponentResitValues(String componentName, ReportGenerationModel reportGenerationModel) throws ResultDeliveryValidationException {
        String resit = "Retake";
        reportGenerationModel.setSingleSkillResitHeaderLabel(getSSRResitComponentName(componentName));
        switch (componentName) {
            case "L":
                reportGenerationModel.setListeningResitScoresLabel(resit);
                break;
            case "R":
                reportGenerationModel.setReadingResitScoresLabel(resit);
                break;
            case "W":
                reportGenerationModel.setWritingResitScoresLabel(resit);
                break;
            default:
                reportGenerationModel.setSpeakingResitScoresLabel(resit);
                break;
        }
    }

    public String getSSRResitComponentName(String componentName) throws ResultDeliveryValidationException {
        if (component.containsKey(componentName)) {
            return String.format("One Skill Retake: %s", component.get(componentName));
        } else {
            throw new ResultDeliveryValidationException("Invalid component found" + componentName, new Throwable());
        }
    }
}
