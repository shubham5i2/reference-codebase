package com.ielts.cmds.rd.domain.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.common.enums.MethodOfDeliveryEnum;
import com.ielts.cmds.organisation.common.enums.OrganisationStatusEnum;
import com.ielts.cmds.organisation.common.enums.VerificationStatusEnum;
import com.ielts.cmds.rd.application.exception.ResultDeliveryValidationException;
import com.ielts.cmds.rd.domain.RDConstants;
import com.ielts.cmds.rd.domain.command.ResultChangeAnalysisCommand;
import com.ielts.cmds.rd.domain.enums.ResultDataAnalysisOutcomeFlag;
import com.ielts.cmds.rd.domain.enums.SecondarySelectionEnums;
import com.ielts.cmds.rd.domain.model.SelectionAggregate;
import com.ielts.cmds.rd.domain.model.enums.ConfirmationStatusEnum;
import com.ielts.cmds.rd.domain.model.enums.DeliveryStatusEnum;
import com.ielts.cmds.rd.domain.model.enums.LinkTypeEnum;
import com.ielts.cmds.rd.domain.model.enums.MinimumScoreSatisfiedEnum;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import com.ielts.cmds.rd.domain.model.out.SelectionNodeV1;
import com.ielts.cmds.rd.domain.utils.*;
import com.ielts.cmds.rd.infrastructure.entity.*;
import com.ielts.cmds.rd.infrastructure.repositories.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.ConstraintViolation;
import javax.validation.constraints.NotNull;
import java.lang.reflect.InvocationTargetException;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static com.ielts.cmds.rd.domain.RDConstants.EventType.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class ResultChangeAnalysisDomainService extends AbstractDomainService {

    private final ObjectMapper objectMapper;

    private final ResultsStatusTypeRepository resultsStatusTypeRepository;

    private final ResultRepository resultRepository;

    private final BookingRepository bookingRepository;

    private final SelectionRepository selectionRepository;

    private final RecognisingOrganisationRepository recognisingOrganisationRepository;

    private final OrganisationTypeRepository organisationTypeRepository;

    private final CMDSErrorResolver<SelectionAggregate> errorResolver;

    private final DomainEventsPublisher domainEventsPublisher;

    private final BuildResultModelUtils resultModelUtils;

    private final BuildOrganisationSelectionNodeV1Utils buildOrganisationSelectionNodeV1Utils;

    private final BuildRecognisingOrganisationNodeV1Utils buildRecognisingOrganisationNodeV1Utils;

    private final BuildBookingNodeV1Utils buildBookingNodeV1Utils;

    private final BuildLocationNodeUtils buildLocationNodeUtils;

    private final ProductConfigRepository productConfigRepository;

    private final BuildResultReleaseNodeV1Utils resultReleaseNodeV1Utils;

    @Transactional(readOnly = true)
    public void on(@NotNull ResultChangeAnalysisCommand command) throws JsonProcessingException, ResultDeliveryValidationException {
        log.info("Received Result Change Analysis event with Booking Uuid {} and Result Uuid {}", command.getEventBody().getResultDetails().getBookingUuid(), command.getEventBody().getResultDetails().getResultUuid());

        List<BaseEvent<BaseHeader>> baseEventList = new ArrayList<>();
        Optional<ResultsStatusType> optionalResultStatusType = resultsStatusTypeRepository
                .findById(command.getEventBody().getResultDetails().getResultsStatusTypeUuid());
        ResultsStatusType resultsStatusType = optionalResultStatusType
                .orElseThrow(() -> new ResultDeliveryValidationException
                        ("Result Change Analysis Event Failed as Result Status type is not Present", new Throwable()));
        Result result = resultRepository.findById(command.getEventBody().getResultDetails().getResultUuid()).orElseThrow(() -> new ResultDeliveryValidationException
                ("Result Change Analysis Event Failed as Result is not Present", new Throwable()));
        Optional<BaseEvent<BaseHeader>> legacyResultDeliveryEvent = legacyResultDeliveryRequestedEvent(command, resultsStatusType);

        Optional<BaseEvent<BaseHeader>> resultPermanentlyWithheldEvent = resultPermanentlyWithheldRequestedEvent(command, resultsStatusType);
        //generate reportGenerationRequested event multiple times with different renditionTypeUuid
        List<BaseEvent<BaseHeader>> reportGenerationRequestedEventList = getEventsForReportGenerationRequested(command.getEventBody().getBookingDetails().getPartnerCode(), command.getEventBody().getBookingDetails().getProductUuid(), command.getEventHeaders(), result, resultsStatusType);

        if (!reportGenerationRequestedEventList.isEmpty()) {
            baseEventList.addAll(reportGenerationRequestedEventList);
        }

        legacyResultDeliveryEvent.ifPresent(baseEventList::add);
        resultPermanentlyWithheldEvent.ifPresent(baseEventList::add);
        baseEventList.addAll(getPrimarySelectionList(command));

        if (baseEventList.isEmpty()) {
            baseEventList.add(noActionRequiredEvent(command.getEventHeaders()));
        }

        baseEventList.addAll(getSecondarySelectionList(command.getEventHeaders(), baseEventList));

        //EventList Publishing using domainEventsPublisher
        domainEventsPublisher.baseEventListPublisher(baseEventList);
    }

    @Override
    public List<BaseEvent<BaseHeader>> getEventsForReportGenerationRequested(String partnerCode, UUID productUuid, BaseHeader baseHeader, Result result, ResultsStatusType resultsStatusType) throws JsonProcessingException {

        ResultReleasedNodeV1 eventBody = resultReleaseNodeV1Utils.buildResultReleasedNodeV1(result.getResultUuid());
        List<BaseEvent<BaseHeader>> reportGenerationRequestedEvents = new ArrayList<>();
        if (baseHeader.getEventContext().containsKey(ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getKey())
                && (baseHeader.getEventContext().get(ResultDataAnalysisOutcomeFlag.TRF_CRITICAL_INFO_CHANGED.getKey()).equals("true"))) {
            if ((Objects.equals(resultsStatusType.getResultStatusCode(), RELEASED))) {
                log.info("Report Generation is to be initiated as TRF CRITICAL INFORMATION is changed for booking with resultUuid {}",result.getResultUuid());
                ReportGenerationEventInput reportGenerationEventInput = new ReportGenerationEventInput(partnerCode, productUuid, result.getResultUuid());
                List<BaseEvent<BaseHeader>> generationEventList = prepareReportGenerationEvents(baseHeader, reportGenerationEventInput);
                reportGenerationRequestedEvents.addAll(generationEventList);
            } else if ((Objects.equals(resultsStatusType.getResultStatusCode(), PERMANENTLY_WITHHELD))) {
                log.info("Result Status is PERMANENTLY_WITHHELD and RESULT INFORMATION is changed for booking with resultUuid {}",result.getResultUuid());
                BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
                baseEvent.setEventHeader(buildHeader(baseHeader, TRF_PERMANENTLY_WITHHOLD_REQUESTED));
                String body = objectMapper.writeValueAsString(eventBody);
                baseEvent.setEventBody(body);
                baseEvent.setEventErrors(null);
                reportGenerationRequestedEvents.add(baseEvent);
            } else {
                log.info("NoActionTaken published as Result status is neither RELEASED nor PERMANENTLY_WITHHELD");
                BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
                baseEvent.setEventHeader(buildHeader(baseHeader, NO_ACTION_TAKEN));
                baseEvent.setEventBody(NO_ACTION_TAKEN);
                baseEvent.setEventErrors(null);
                reportGenerationRequestedEvents.add(baseEvent);
            }
        }
        return reportGenerationRequestedEvents;
    }

    private List<BaseEvent<BaseHeader>> getSecondarySelectionList(BaseHeader baseHeader, List<BaseEvent<BaseHeader>> primaryBaseEventList) {
        List<BaseEvent<BaseHeader>> secondarySelectionList = new ArrayList<>();
        primaryBaseEventList.stream()
                .filter(eventList -> eventList.getEventHeader().getEventName().equals(RO_SELECTION_DELIVERY_REQUESTED))
                .filter(errorEvent -> errorEvent.getEventErrors() == null)
                .forEach(e -> {
                    try {
                        secondarySelectionList.addAll(buildSecondarySelectionList(e, baseHeader));
                    } catch (JsonProcessingException jsonProcessingException) {
                        log.error("Error while conversion", jsonProcessingException);
                    }
                });
        log.info("This Booking has {} valid secondary selections",secondarySelectionList.size());
        return secondarySelectionList;
    }

    private List<BaseEvent<BaseHeader>> buildSecondarySelectionList(BaseEvent<BaseHeader> primarySelectionEvent, BaseHeader baseHeader) throws JsonProcessingException {
        List<BaseEvent<BaseHeader>> baseEventList = new ArrayList<>();
        OrganisationSelectionNodeV1 organisationSelectionNodeV1 = objectMapper.readValue(primarySelectionEvent.getEventBody(), OrganisationSelectionNodeV1.class);

        if (Objects.nonNull(organisationSelectionNodeV1)) {
            Optional<RecognisingOrganisation> optionalRecognisingOrganisation = recognisingOrganisationRepository.findById(organisationSelectionNodeV1.getOrganisationDetails().getRecognisingOrganisationUuid());

            Optional<Selection> optionalSelection = selectionRepository.findById(organisationSelectionNodeV1.getSelection().getSelectionUuid());
            if (optionalRecognisingOrganisation.isPresent() && optionalSelection.isPresent()) {
                List<LinkedRecognisingOrganisation> linkedRecognisingOrganisations = optionalRecognisingOrganisation.get().getLinkedRecognisingOrganisations();

                if (!linkedRecognisingOrganisations.isEmpty()) {
                    List<Selection> secondarySelections = linkedRecognisingOrganisations.stream().filter(linkedRecognisingOrganisationType -> linkedRecognisingOrganisationType.getLinkedRecognisingOrganisationType().equals(LinkTypeEnum.RESULTS_DELIVERY))
                            .filter(effectiveTo -> OffsetDateTime.now().isBefore(effectiveTo.getLinkEffectiveToDatetime()))
                            .filter(effectiveFrom -> OffsetDateTime.now().isAfter(effectiveFrom.getLinkEffectiveFromDatetime()))
                            .filter(flag -> flag.getDeleted().equals(false))
                            .filter(validOrganisation -> isValidLinkedOrganisation(validOrganisation.getTargetRecognisingOrganisationUuid()).equals(true))
                            .map(linkedROs -> setSelection(linkedROs, optionalSelection.get().getSelectionUuid())).collect(Collectors.toList());
                    baseEventList.addAll(buildROSelectionDeliveryRequestedEvent(baseHeader, secondarySelections, optionalSelection.get(), organisationSelectionNodeV1));
                }

            }
        }

        return baseEventList;
    }

    private Boolean isValidLinkedOrganisation(UUID targetROUuid) {
        Optional<RecognisingOrganisation> optionalROs = recognisingOrganisationRepository.findById(targetROUuid);
        if (optionalROs.isPresent()) {
            Optional<OrganisationType> optionalOrganisationType = organisationTypeRepository.findById(optionalROs.get().getOrganisationTypeUuid());

            return optionalROs.get().getMethodOfDelivery().equals(MethodOfDeliveryEnum.E_DELIVERY) &&
                    optionalROs.get().getVerificationStatus().equals(VerificationStatusEnum.APPROVED) &&
                    optionalROs.get().getOrganisationStatus().equals(OrganisationStatusEnum.ACTIVE) &&
                    optionalOrganisationType.isPresent() &&
                    optionalOrganisationType.get().getOrganisationTypeName().equals("RO");
        }
        return false;
    }


    private Selection setSelection(LinkedRecognisingOrganisation linkedRecognisingOrganisation, UUID selectionUuid) {
        Selection selection = new Selection();
        selection.setSelectionUuid(UUID.randomUUID());
        selection.setExternalSelectionUuid(UUID.randomUUID());
        selection.setAssociatedSelectionUuid(selectionUuid);
        selection.setRecognisingOrganisationUuid(linkedRecognisingOrganisation.getTargetRecognisingOrganisationUuid());
        return selection;
    }

    private List<BaseEvent<BaseHeader>> buildROSelectionDeliveryRequestedEvent(BaseHeader baseHeader, List<Selection> selectionList, Selection primarySelection, OrganisationSelectionNodeV1 organisationSelectionNodeV1) {
        List<BaseEvent<BaseHeader>> baseEventList = new ArrayList<>();
        BaseHeader eventHeader = buildHeader(baseHeader, RDConstants.EventType.RO_SELECTION_DELIVERY_REQUESTED);
        Map<String, String> map = new HashMap<>();
        map.put(SecondarySelectionEnums.SECONDARY_SELECTION.getKey(), SecondarySelectionEnums.SECONDARY_SELECTION.getValue());
        eventHeader.setEventContext(map);

        List<OrganisationSelectionNodeV1> organisationSelectionNodeV1List = selectionList.stream().map(e ->
                buildROSelectionDeliveryRequestedEventBody(e, primarySelection, organisationSelectionNodeV1)).collect(Collectors.toList());
        organisationSelectionNodeV1List.forEach(e -> {
            BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
            String eventBody = null;
            try {
                eventBody = objectMapper.writeValueAsString(e);
            } catch (JsonProcessingException jsonProcessingException) {
                log.error("error while conversion", jsonProcessingException);
            }
            baseEvent.setEventHeader(eventHeader);
            baseEvent.setEventBody(eventBody);
            baseEvent.setEventErrors(null);
            baseEventList.add(baseEvent);
        });
        return baseEventList;
    }

    private OrganisationSelectionNodeV1 buildROSelectionDeliveryRequestedEventBody(Selection secondarySelection, Selection primarySelection, OrganisationSelectionNodeV1 organisationSelectionNodeV11) {
        OrganisationSelectionNodeV1 organisationSelectionNodeV1 = new OrganisationSelectionNodeV1();
        if (secondarySelection != null) {
            return OrganisationSelectionNodeV1.builder()
                    .selection(buildSecondarySelectionNodeV1(secondarySelection, primarySelection))
                    .organisationDetails(buildRecognisingOrganisationNodeV1Utils.buildRecognisingOrganisationNodeV1(secondarySelection.getRecognisingOrganisationUuid()))
                    .bookingDetails(buildBookingNodeV1Utils.buildResultDeliveryBookingNodeV1(organisationSelectionNodeV11.getBookingDetails().getBookingUuid()))
                    .locationDetails(buildLocationNodeUtils.buildLocationChangeNodeV1(organisationSelectionNodeV11.getLocationDetails().getLocationUuid()))
                    .build();
        }
        return organisationSelectionNodeV1;
    }

    private SelectionNodeV1 buildSecondarySelectionNodeV1(Selection secondarySelection, Selection primarySelection) {
        SelectionNodeV1 selectionNodeV1 = new SelectionNodeV1();
        if (Objects.nonNull(secondarySelection.getSelectionUuid())) {
            selectionNodeV1.setSelectionUuid(secondarySelection.getSelectionUuid());
            selectionNodeV1.setAssociatedSelectionUuid(primarySelection.getSelectionUuid());
            selectionNodeV1.setExternalSelectionUuid(secondarySelection.getExternalSelectionUuid());
            selectionNodeV1.setSelectionDate(primarySelection.getSelectionDate());
            selectionNodeV1.setDeliveryStatus(primarySelection.getDeliveryStatus());
            selectionNodeV1.setDeliveryStatusChangedDatetime(primarySelection.getDeliveryStatusChangedDatetime());
            selectionNodeV1.setConfirmationStatus(ConfirmationStatusEnum.CONFIRMED);
            selectionNodeV1.setConfirmationStatusChangedDatetime(OffsetDateTime.now());
            selectionNodeV1.setOverallMinimumScore(null);
            selectionNodeV1.setCaseNumber(null);
            selectionNodeV1.setPersonDepartment(null);
            selectionNodeV1.setTrfNumber(getTrfNumberFromResult(primarySelection.getExternalBookingUuid()));
            selectionNodeV1.setMinimumScoreSatisfied(MinimumScoreSatisfiedEnum.NOT_APPLICABLE);
            selectionNodeV1.setSharedDate(LocalDate.now());
            selectionNodeV1.setMinimumScores(null);

        }
        return selectionNodeV1;
    }

    private String getTrfNumberFromResult(final UUID externalBookingUuid) {
        Optional<Booking> optionalBooking = bookingRepository.findByExternalBookingUuid(externalBookingUuid);
        Optional<Result> optionalResult = Optional.empty();
        if (optionalBooking.isPresent()) {
            Booking booking = optionalBooking.get();
            optionalResult = resultRepository.findByBookingUuid(booking.getBookingUuid());

        }
        return optionalResult.map(Result::getTrfNumber).orElse(null);
    }

    private List<BaseEvent<BaseHeader>> getPrimarySelectionList(ResultChangeAnalysisCommand command) {
        List<BaseEvent<BaseHeader>> baseEventList = new ArrayList<>();
        Optional<Result> optionalResult;
        Optional<Booking> optionalBooking = Optional.empty();
        Result result;
        Optional<ResultsStatusType> optionalResultsStatusType = Optional.empty();
        List<Selection> selectionList = new ArrayList<>();
        optionalResult = resultRepository.findById(command.getEventBody().getResultDetails().getResultUuid());
        if (optionalResult.isPresent()) {
            result = optionalResult.get();
            optionalBooking = bookingRepository.findById(result.getBookingUuid());
            optionalResultsStatusType = resultsStatusTypeRepository.findById(result.getResultsStatusTypeUuid());
        }
        if (optionalBooking.isPresent()) {
            selectionList = selectionRepository.findByExternalBookingUuid(optionalBooking.get().getExternalBookingUuid());
        }

        if (Objects.nonNull(selectionList) && optionalResultsStatusType.isPresent()
                && (optionalResultsStatusType.get().getResultStatusCode().equals(RDConstants.EventType.RELEASED))) {
            log.info("Booking with bookingUuid {} has {} primary selections",command.getEventBody().getBookingDetails().getBookingUuid(),selectionList.size());
            baseEventList.addAll(checkSelectionsDeliveryEligibilityForPrimarySelections(optionalResult, selectionList, optionalBooking, command));
        }
        return baseEventList;
    }

    private List<BaseEvent<BaseHeader>> checkSelectionsDeliveryEligibilityForPrimarySelections(Optional<Result> optionalResult, List<Selection> selectionList,
                                                                                               Optional<Booking> optionalBooking, ResultChangeAnalysisCommand command) {
        List<BaseEvent<BaseHeader>> baseEventList = new ArrayList<>();
        selectionList.stream().filter(e -> Objects.isNull(e.getAssociatedSelectionUuid())).forEach(selection -> {
            BaseEvent<BaseHeader> baseEvent = null;
            Optional<RecognisingOrganisation> recognisingOrganisation = recognisingOrganisationRepository.findById(selection.getRecognisingOrganisationUuid());

            Optional<OrganisationType> optionalOrganisationType = Optional.empty();
            if (recognisingOrganisation.isPresent()) {
                optionalOrganisationType = organisationTypeRepository.findById(recognisingOrganisation.get().getOrganisationTypeUuid());
            }
            SelectionAggregate selectionAggregate;
            selectionAggregate = getSelectionAggregate(optionalResult, optionalBooking, selection, recognisingOrganisation, optionalOrganisationType);

            if (selection.getDeliveryStatus().equals(DeliveryStatusEnum.DELIVERY_REQUESTED)) {
                baseEvent = buildRedeliveryRequestedEvent(command, selection, selectionAggregate);

            } else {
                baseEvent = buildAndSetSelectionDeliveryStatusEvent(command, selection, selectionAggregate);
            }
            if (optionalBooking.isPresent()) {
                baseEvent.getEventHeader().setPartnerCode(optionalBooking.get().getPartnerCode());
            }
            baseEventList.add(baseEvent);
        });
        return baseEventList;
    }

    private SelectionAggregate getSelectionAggregate(Optional<Result> optionalResult, Optional<Booking> finalOptionalBooking,
                                                     Selection e, Optional<RecognisingOrganisation> recognisingOrganisation, Optional<OrganisationType> optionalOrganisationType) {
        return SelectionAggregate.builder()
                .selection(e)
                .result(resultModelUtils.populateResultModelData(optionalResult))
                .booking(finalOptionalBooking.orElse(null))
                .organisation(recognisingOrganisation.orElse(null))
                .organisationType(optionalOrganisationType.orElse(null))
                .command(null).build();
    }

    private BaseEvent<BaseHeader> buildRedeliveryRequestedEvent(ResultChangeAnalysisCommand command, Selection selection, SelectionAggregate selectionAggregate) {
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        try {
            selectionAggregate.flagSelectionAsRedeliveryRequested();
            BaseEvent<BaseHeader> tempBaseEvent = buildSelectionEvent(selection, command);
            BeanUtils.copyProperties(baseEvent, tempBaseEvent);
            baseEvent.getEventHeader().setEventName(RDConstants.EventType.RO_SELECTION_DELIVERY_REQUESTED);
        } catch (JsonProcessingException | InvocationTargetException | IllegalAccessException e) {
            log.error("Event Failed To Process : ", e);
        }
        return baseEvent;
    }


    private BaseEvent<BaseHeader> buildAndSetSelectionDeliveryStatusEvent(ResultChangeAnalysisCommand command, Selection selection, SelectionAggregate selectionAggregate) {
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        Set<ConstraintViolation<SelectionAggregate>> violations = selectionAggregate.canSelectionBeDeliveredToResultPortal();
        if (!violations.isEmpty()) {
            long minimumScoreCriteriaFailedCount = violations.stream().filter(e -> e.getMessage().equals("V037")).count();
            if (minimumScoreCriteriaFailedCount != 0) {
                selectionAggregate.flagSelectionMinimumScoreUnSatisfiedCriteria();
            }
            baseEvent = buildErrorDomainEvent(command, violations);
            try {
                baseEvent.setEventBody(buildOrganisationSelectionNodeV1(selectionAggregate));
            } catch (JsonProcessingException e) {
                log.error("Error in processing Json object : ", e);
            }
        } else {
            try {
                selectionAggregate.flagSelectionAsPending();
                baseEvent = buildSelectionEvent(selection, command);
            } catch (JsonProcessingException ex) {
                log.error("Error in processing Json : ", ex);
            }
        }
        return baseEvent;
    }

    private BaseEvent<BaseHeader> buildSelectionEvent(Selection selection, ResultChangeAnalysisCommand command) throws JsonProcessingException {
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        BaseHeader baseHeader = buildHeader(command.getEventHeaders(), RDConstants.EventType.RO_SELECTION_DELIVERY_REQUESTED);
        OrganisationSelectionNodeV1 selectionNodeV1 = buildOrganisationSelectionNodeV1Utils.buildOrganisationSelectionNodeV1Utils(selection.getSelectionUuid());
        String eventBody = objectMapper.writeValueAsString(selectionNodeV1);
        baseEvent.setEventHeader(baseHeader);
        baseEvent.setEventBody(eventBody);
        baseEvent.setEventErrors(null);

        return baseEvent;
    }

    private BaseEvent<BaseHeader> buildErrorDomainEvent(ResultChangeAnalysisCommand command, Set<ConstraintViolation<SelectionAggregate>> violations) {
        BaseHeader baseHeader = buildHeader(command.getEventHeaders(), RDConstants.EventType.RO_SELECTION_DELIVERY_REQUESTED);
        baseHeader.setEventDateTime(command.getEventHeaders().getEventDateTime());
        CMDSErrorResponse eventErrors = errorResolver.populatErrorResponse(violations, RDConstants.EventType.RO_SELECTION_DELIVERY_REQUESTED);
        BaseEventErrors baseEventErrors = new BaseEventErrors(eventErrors.getErrorList());
        return new BaseEvent<>(baseHeader, null, baseEventErrors, command.getAudit());
    }

    private String buildOrganisationSelectionNodeV1(SelectionAggregate selectionAggregate) throws JsonProcessingException {
        String eventBody = "";
        if (selectionAggregate.getSelection().isPresent()) {
            Selection selection = selectionAggregate.getSelection().orElse(null);
            if (Objects.nonNull(selection)) {
                OrganisationSelectionNodeV1 organisationSelectionNodeV1 = buildOrganisationSelectionNodeV1Utils
                        .buildOrganisationSelectionNodeV1Utils(selection.getSelectionUuid());
                eventBody = objectMapper.writeValueAsString(organisationSelectionNodeV1);
            }
        }
        return eventBody;
    }

    private BaseEvent<BaseHeader> noActionRequiredEvent(BaseHeader eventHeaders) {
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        baseEvent.setEventHeader(buildHeader(eventHeaders, NO_ACTION_TAKEN));
        baseEvent.setEventBody(NO_ACTION_TAKEN);
        baseEvent.setEventErrors(null);
        return baseEvent;
    }

    private Optional<BaseEvent<BaseHeader>> legacyResultDeliveryRequestedEvent(ResultChangeAnalysisCommand command, ResultsStatusType resultsStatusType) throws JsonProcessingException {
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        if (command.getEventHeaders().getEventContext().containsKey(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey())
                && (command.getEventHeaders().getEventContext().get(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey()).equals("true"))
                && ((Objects.equals(resultsStatusType.getResultStatusCode(), RELEASED)) ||
                (Objects.equals(resultsStatusType.getResultStatusCode(), PERMANENTLY_WITHHELD)))) {
            log.info("Triggering notification to LA as Result Status is RELEASED/PERMANENTLY_WITHHELD and RESULT INFORMATION is changed for booking with bookingUuid {}",command.getEventBody().getBookingDetails().getBookingUuid());
            baseEvent.setEventHeader(buildHeader(command.getEventHeaders(), LEGACY_RESULT_DELIVERY_REQUESTED));
            String body = objectMapper.writeValueAsString(command.getEventBody());
            baseEvent.setEventBody(body);
            baseEvent.setEventErrors(null);
            return Optional.of(baseEvent);
        }
        return Optional.empty();
    }

    private Optional<BaseEvent<BaseHeader>> resultPermanentlyWithheldRequestedEvent(ResultChangeAnalysisCommand command, ResultsStatusType resultsStatusType) throws JsonProcessingException {
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        if (command.getEventHeaders().getEventContext().containsKey(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey())
                && (command.getEventHeaders().getEventContext().get(ResultDataAnalysisOutcomeFlag.TT_RESULT_DATA_CHANGED.getKey()).equals("true"))
                && (Objects.equals(resultsStatusType.getResultStatusCode(), PERMANENTLY_WITHHELD))) {
            log.info("Result Status is PERMANENTLY_WITHHELD and RESULT INFORMATION is changed for booking with bookingUuid {}",command.getEventBody().getBookingDetails().getBookingUuid());
            baseEvent.setEventHeader(buildHeader(command.getEventHeaders(), RESULT_PERMANENTLY_WITHHOLD_REQUESTED));
            String body = objectMapper.writeValueAsString(command.getEventBody());
            baseEvent.setEventBody(body);
            baseEvent.setEventErrors(null);
            return Optional.of(baseEvent);
        }
        return Optional.empty();
    }

    @Override
    protected ObjectMapper getObjectMapper() {
        return this.objectMapper;
    }

    @Override
    protected BuildResultReleaseNodeV1Utils getBuildResultReleasedNodeV1Utils() {
        return this.resultReleaseNodeV1Utils;
    }

    @Override
    protected ProductConfigRepository getProductConfigRepository() {
        return this.productConfigRepository;
    }

}
