#!/usr/bin/env sh
mkdir -p .cache
cd .cache
if [ ! -f google-java-format-1.7-all-deps.jar ]
then
    curl -LJO "https://github.com/google/google-java-format/releases/download/google-java-format-1.7/google-java-format-1.7-all-deps.jar"
    chmod 755 google-java-format-1.7-all-deps.jar
fi
cd ..
changed_java_files=$(git diff --cached --diff-filter=ACMR --name-only -- "*.java")
echo $changed_java_files
length=${#changed_java_files}
if [ $length -gt 0 ]; then
    echo "Formatting java files"
    java -jar .cache/google-java-format-1.7-all-deps.jar --aosp --replace $changed_java_files
    # git add $changed_java_files
    # msg=$(git log -1 --pretty=format:%s%b)
    # echo "Committed again $msg"
    # git commit -m "$msg"
else 
    echo "no files to format"
fi
