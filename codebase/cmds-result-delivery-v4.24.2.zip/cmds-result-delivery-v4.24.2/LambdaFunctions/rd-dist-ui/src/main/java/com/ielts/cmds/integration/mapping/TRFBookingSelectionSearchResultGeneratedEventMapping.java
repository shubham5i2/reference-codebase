package com.ielts.cmds.integration.mapping;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang.WordUtils;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.organisation.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.rd.domain.model.out.LocationChangeNodeV1;
import com.ielts.cmds.rd.domain.model.out.ReferenceDataNodeV1;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import com.ielts.cmds.rd.domain.model.out.TRFBookingSearchResultsV1;
import com.ielts.cmds.rd.socket.response.ResultDeliveryTemplatePrintStatusNodeV1;
import com.ielts.cmds.rd.socket.response.SelectionNodeV1;
import com.ielts.cmds.rd.socket.response.TRFBookingSelectionsSearchResultsResponseV1;
import com.ielts.cmds.rd.socket.response.TRFBookingSelectionsSearchResultsV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TRFBookingSelectionSearchResultGeneratedEventMapping implements Mapper, IServiceV2<TRFBookingSearchResultsV1, TRFBookingSelectionsSearchResultsResponseV1> {

    public TRFBookingSelectionsSearchResultsResponseV1 mapRequestEventBodyToResponseBody(final TRFBookingSearchResultsV1 eventBody) {
        TRFBookingSelectionsSearchResultsResponseV1 responseV1 = new TRFBookingSelectionsSearchResultsResponseV1();
        if (Objects.nonNull(eventBody.getEntries())) {
            ResultReleasedNodeV1 resultReleasedNodeV1 = eventBody.getEntries().get(0);
            TRFBookingSelectionsSearchResultsV1 resultsV1 = new TRFBookingSelectionsSearchResultsV1();
            resultsV1.setBookingUuid(resultReleasedNodeV1.getBookingDetails().getBookingUuid());
            resultsV1.setResultUuid(resultReleasedNodeV1.getResultDetails().getResultUuid());
            resultsV1.setGivenName(resultReleasedNodeV1.getBookingDetails().getFirstName());
            resultsV1.setFamilyName(resultReleasedNodeV1.getBookingDetails().getLastName());
            if(Objects.nonNull(getLocationDetails(resultReleasedNodeV1.getBookingDetails().getLocationUuid(),resultReleasedNodeV1))) {
                resultsV1.setTestCenterNumber(getLocationDetails(resultReleasedNodeV1.getBookingDetails().getLocationUuid(), resultReleasedNodeV1).getTestCentreNumber());
            }
            resultsV1.setTestDate(resultReleasedNodeV1.getBookingDetails().getTestDate());
            resultsV1.setTestTakerNumber(String.format("%06d",resultReleasedNodeV1.getBookingDetails().getShortCandidateNumber()));
            resultsV1.setResultStatus(WordUtils.capitalizeFully(getReferenceValue(resultReleasedNodeV1, resultReleasedNodeV1.getResultDetails().getResultsStatusTypeUuid())));
            resultsV1.setResultLastUpdatedDate(resultReleasedNodeV1.getResultDetails().getStatusUpdatedDatetime());

            List<ResultDeliveryTemplatePrintStatusNodeV1> printStatusNodeV1List = new ArrayList<>();
            resultReleasedNodeV1.getResultDetails().getTrfPrintStatus().forEach(e -> {
                ResultDeliveryTemplatePrintStatusNodeV1 printStatusNodeV1 = new ResultDeliveryTemplatePrintStatusNodeV1();
                printStatusNodeV1.setPrintEventCount(e.getPrintCount());
                printStatusNodeV1.setPrintedBy(e.getPrintedBy());
                printStatusNodeV1.setPrintedDateTime(e.getPrintedDatetime());
                printStatusNodeV1.setRenditionTypeUuid(e.getRenditionTypeUuid());

                printStatusNodeV1List.add(printStatusNodeV1);
            });
            resultsV1.setPrintStatus(printStatusNodeV1List);

            resultsV1.setTotalSelectionsCount(eventBody.getTotalCount());
            List<SelectionNodeV1> selections = new ArrayList<>();
            if (eventBody.getTotalCount() != 0) {
                selections = eventBody.getEntries().stream()
                        .map(this::getSelectionNodeV1).collect(Collectors.toList());
            }
            resultsV1.setSelections(selections);

            responseV1.setResponse(resultsV1);

        }
        
        return responseV1;
    }

    public SelectionNodeV1 getSelectionNodeV1(ResultReleasedNodeV1 resultReleasedNodeV1) {
        com.ielts.cmds.rd.domain.model.out.SelectionNodeV1 selection = resultReleasedNodeV1.getSelection();
        SelectionNodeV1 lambdaSelection = new SelectionNodeV1();
        lambdaSelection.setSelectionUuid(selection.getSelectionUuid());
        lambdaSelection.setExternalSelectionUuid(selection.getExternalSelectionUuid());
        lambdaSelection.setSelectionDate(selection.getSelectionDate());
        lambdaSelection.setDeliveryStatus(selection.getDeliveryStatus());
        lambdaSelection.setDeliveryStatusChangedDatetime(selection.getDeliveryStatusChangedDatetime());
        lambdaSelection.setConfirmationStatus(WordUtils.capitalizeFully(selection.getConfirmationStatus().toString()));
        lambdaSelection.setConfirmationStatusChangedDatetime(selection.getConfirmationStatusChangedDatetime());
        lambdaSelection.setMinimumScoreSatisfied(selection.getMinimumScoreSatisfied());
        lambdaSelection.setCaseNumber(selection.getCaseNumber());
        lambdaSelection.setPersonDepartment(selection.getPersonDepartment());
        lambdaSelection.setTrfNumber(selection.getTrfNumber());
        lambdaSelection.setOrganisationId(resultReleasedNodeV1.getOrganisation().getOrganisationId());
        lambdaSelection.setOrganisationName(resultReleasedNodeV1.getOrganisation().getName());
        lambdaSelection.setOrganisationAddress(resultReleasedNodeV1.getDeliveryAddress());
        lambdaSelection.setOrganisationType(resultReleasedNodeV1.getOrganisationType());

        return lambdaSelection;
    }

    private String getReferenceValue(ResultReleasedNodeV1 resultReleasedNodeV1, UUID uuid) {

        Map<String, String> referenceData = resultReleasedNodeV1.getReferenceData().stream().filter(e -> Objects.nonNull(e) && Objects.nonNull(e.getReferenceId()))
                .collect(Collectors.toMap(ReferenceDataNodeV1::getReferenceId, ReferenceDataNodeV1::getReferenceValue));
        if (Objects.isNull(uuid)) {
            return null;
        }
        return referenceData.get(String.valueOf(uuid));
    }

    public LocationChangeNodeV1 getLocationDetails(UUID locationUuid, ResultReleasedNodeV1 resultReleasedNodeV1)
    {

        Optional<LocationChangeNodeV1> locationChangeNodeV1Optional = resultReleasedNodeV1.getLocationDetails().stream()
                .filter(Objects::nonNull)
                .filter(location -> location.getLocationUuid().equals(locationUuid))
                .findFirst();
        return locationChangeNodeV1Optional.orElse(null);
    }


	@Override
	public TRFBookingSelectionsSearchResultsResponseV1 process(TRFBookingSearchResultsV1 eventBody) {
		TRFBookingSelectionsSearchResultsResponseV1 response = new TRFBookingSelectionsSearchResultsResponseV1();
        if (Objects.nonNull(eventBody)) {
            response = mapRequestEventBodyToResponseBody(eventBody);
        }
        final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
        final BaseEventErrors responseErrors = ThreadLocalErrorContext.getContext();
        log.info("response errors {} ", responseErrors);
        response.setMeta(responseHeaders);
        response.setErrors(responseErrors);
        return response;
	}
}
