package com.ielts.cmds.integration.mapping;

import static com.ielts.cmds.integration.constants.RDDistConstants.PRESIGN_TIMEOUT;
import static com.ielts.cmds.integration.constants.RDDistConstants.TRF_BUCKET;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.integration.presign.PresignURL;
import com.ielts.cmds.organisation.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.rd.domain.model.out.ReferenceDataNodeV1;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

public interface Mapper {

	default ObjectMapper getMapper(){
		final ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.registerModule(new JavaTimeModule());
		objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
		objectMapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
		objectMapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
		objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		return objectMapper;
	}
	
	default SocketResponseMetaDataV1 mapRequestEventHeaderToSocketResponseHeader() {
		final SocketResponseMetaDataV1 responseHeaders = new SocketResponseMetaDataV1();
		responseHeaders.setCorrelationId(ThreadLocalHeaderContext.getContext().getCorrelationId());
		responseHeaders.setConnectionId(ThreadLocalHeaderContext.getContext().getConnectionId());
		return responseHeaders;
	}
	
	default BaseEventErrors getBaseEventErrors() {
        BaseEventErrors baseEventErrors;
        List<ErrorDescription> errorDescriptions = new ArrayList<>();
        ErrorDescription errorDescription = new ErrorDescription();
        errorDescription.setMessage("Presigned URL is not generated");
        errorDescription.setType(ErrorTypeEnum.VALIDATION);
        errorDescription.setErrorCode("V049");
        errorDescription.setTitle("Validation Failed");
        errorDescriptions.add(errorDescription);
        baseEventErrors = new BaseEventErrors(errorDescriptions);
        return baseEventErrors;
    }
	
	default String mapRequestEventBodyToResponseBody(final ReferenceDataNodeV1 referenceDataNodeV1) {
        String file = referenceDataNodeV1.getReferenceValue();
        return getPresign().handlePresign(getTRFBucket(), file, getTimeOut());
    }
	default String getTimeOut() {
		return System.getenv(PRESIGN_TIMEOUT);
	}

	default String getTRFBucket() {
		return System.getenv(TRF_BUCKET);
	}

	default PresignURL getPresign() {
    	return new PresignURL();
    }
}
