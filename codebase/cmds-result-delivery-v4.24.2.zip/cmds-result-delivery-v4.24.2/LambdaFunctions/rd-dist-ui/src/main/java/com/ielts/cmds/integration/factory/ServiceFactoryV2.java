package com.ielts.cmds.integration.factory;

import java.util.HashMap;
import java.util.Map;

import com.ielts.cmds.integration.mapping.ETRFDownloadResponseGeneratedMapping;
import com.ielts.cmds.integration.mapping.TRFBookingSelectionSearchResultGeneratedEventMapping;
import com.ielts.cmds.integration.mapping.TRFDownloadResponseGeneratedMapping;
import com.ielts.cmds.serialization.lambda.dist.ui.service.AbstractServiceFactoryV2;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;

public class ServiceFactoryV2 extends AbstractServiceFactoryV2 {

    @SuppressWarnings("rawtypes")
    private static final Map<String, IServiceV2> mapServices = new HashMap<>();


    static{
        mapServices.put("TRFBookingSelectionsSearchResultGenerated", new TRFBookingSelectionSearchResultGeneratedEventMapping());
        mapServices.put("TRFBookingSelectionsSearchResultGenerateFailed", new TRFBookingSelectionSearchResultGeneratedEventMapping());
        mapServices.put("ETRFDownloadResponseGenerated", new ETRFDownloadResponseGeneratedMapping());
        mapServices.put("TRFDownloadResponseGenerated", new TRFDownloadResponseGeneratedMapping());
        mapServices.put("TRFDownloadResponseGenerateFailed", new TRFDownloadResponseGeneratedMapping());
        mapServices.put("ETRFDownloadResponseGenerateFailed", new ETRFDownloadResponseGeneratedMapping());
    }

    public ServiceFactoryV2() {
        super(mapServices);
    }

    @SuppressWarnings("unchecked")
	@Override
	public <I, O> IServiceV2<I, O> getService(String eventIdentifier) {
		return mapServices.get(eventIdentifier);
	}
}
