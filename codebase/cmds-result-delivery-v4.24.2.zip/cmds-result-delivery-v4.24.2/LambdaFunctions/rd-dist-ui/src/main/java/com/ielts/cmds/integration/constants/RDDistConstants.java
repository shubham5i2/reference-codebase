package com.ielts.cmds.integration.constants;

/**
 * Constants class for RD Distributor UI Lambda
 */
public class RDDistConstants {

    private RDDistConstants() {
    }

    public static final String APPLICATION_NAME = "RD-DIST-LAMBDA";
    public static final String RD = "RD";
    public static final String SOCKET_END_POINT = "websocket_apigateway_endpoint";
    public static final String REGION = "AWS_REGION";
    public static final String TRF_BUCKET = "trf_bucket_name";
    public static final String PRESIGN_TIMEOUT = "presigned_url_timeout_second";
}
