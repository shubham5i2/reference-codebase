package com.ielts.cmds.integration;

import com.ielts.cmds.integration.factory.ServiceFactoryV2;
import com.ielts.cmds.serialization.lambda.AbstractDistUiLambda;
import com.ielts.cmds.serialization.lambda.dist.ui.service.AbstractServiceFactoryV2;

/**
 * @author cts
 * <p>
 * This class serves the purpose of handling RD responses to Internal
 * CMDS system/UI. It reads RD events and post it back to internal API
 * gateway/RD-Identity services
 */

public class RDDistUI extends AbstractDistUiLambda {

	@Override
	public AbstractServiceFactoryV2 getServiceFactory() {
		return new ServiceFactoryV2();
	}

}
