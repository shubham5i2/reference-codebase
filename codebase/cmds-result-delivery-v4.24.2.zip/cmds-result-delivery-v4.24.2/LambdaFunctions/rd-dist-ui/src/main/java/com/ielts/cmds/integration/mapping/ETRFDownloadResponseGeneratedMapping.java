package com.ielts.cmds.integration.mapping;

import java.util.Objects;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.organisation.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.rd.domain.model.out.ReferenceDataNodeV1;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import com.ielts.cmds.rd.socket.response.ETRFBookingDownloadResultsResponseV1;
import com.ielts.cmds.rd.socket.response.ETRFBookingDownloadResultsV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ETRFDownloadResponseGeneratedMapping implements Mapper, IServiceV2<ResultReleasedNodeV1, ETRFBookingDownloadResultsResponseV1> {

    
	@Override
	public ETRFBookingDownloadResultsResponseV1 process(ResultReleasedNodeV1 releasedNodeV1) {
		ETRFBookingDownloadResultsResponseV1 response = new ETRFBookingDownloadResultsResponseV1();
        String presignedUrl = null;
        ETRFBookingDownloadResultsV1 etrfBookingDownloadResultsV1 = new ETRFBookingDownloadResultsV1();
        if (Objects.nonNull(releasedNodeV1.getReferenceData())) {
            ReferenceDataNodeV1 referenceData = releasedNodeV1.getReferenceData().get(0);
            presignedUrl = mapRequestEventBodyToResponseBody(referenceData);
            log.info("Presigned URL Generated: {} for transaction uuid {}", presignedUrl, ThreadLocalHeaderContext.getContext().getTransactionId());

            etrfBookingDownloadResultsV1.setTrfDownloadUrl(presignedUrl);

            releasedNodeV1.getResultDetails().getTrfPrintStatus().stream().forEach(e -> {
                if (e.getRenditionTypeUuid().toString().equals(referenceData.getReferenceId())) {
                    etrfBookingDownloadResultsV1.setPrintEventCount(e.getPrintCount());
                    etrfBookingDownloadResultsV1.setPrintedBy(e.getPrintedBy());
                    etrfBookingDownloadResultsV1.setPrintedDateTime(e.getPrintedDatetime());
                }
            });
            etrfBookingDownloadResultsV1.setFileName(releasedNodeV1.getReferenceData().get(0).getReferenceValue());
        }
        if (Objects.isNull(presignedUrl)) {
            BaseEventErrors baseEventErrors = getBaseEventErrors();
            ThreadLocalErrorContext.setContext(baseEventErrors);
            log.error("Presigned URL is not generated: {} for transaction uuid {}", baseEventErrors, ThreadLocalHeaderContext.getContext().getTransactionId());
        }
        final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
        final BaseEventErrors responseErrors = ThreadLocalErrorContext.getContext();
        response.setMeta(responseHeaders);
        response.setErrors(responseErrors);
        response.setResponse(etrfBookingDownloadResultsV1);
        return response;
	}

}
