package com.ielts.cmds.integration.presign;

import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.presigner.S3Presigner;
import software.amazon.awssdk.services.s3.presigner.model.GetObjectPresignRequest;
import software.amazon.awssdk.services.s3.presigner.model.PresignedGetObjectRequest;

import java.time.Duration;

public class PresignURL {

    public String handlePresign(String bucketName, String file, String timeout) {


        GetObjectRequest getObjectRequest =
                GetObjectRequest.builder()
                        .bucket(bucketName)
                        .key(file)
                        .build();


        // Generate the presigned request
        PresignedGetObjectRequest presignedGetObjectRequest =
                getS3Presigner().presignGetObject(getGetObjectPresignRequest(timeout, getObjectRequest));

        return presignedGetObjectRequest.url().toString();
    }
    
    protected S3Presigner getS3Presigner() {
    	Region region = Region.EU_WEST_2;

        return S3Presigner.builder()
                .region(region)
                .build();
    }
    
    protected GetObjectPresignRequest getGetObjectPresignRequest(final String timeout, 
    		final GetObjectRequest getObjectRequest) {
    	return GetObjectPresignRequest.builder()
                .signatureDuration(Duration.ofSeconds(Long.parseLong(timeout)))
                .getObjectRequest(getObjectRequest)
                .build();
    }
}
