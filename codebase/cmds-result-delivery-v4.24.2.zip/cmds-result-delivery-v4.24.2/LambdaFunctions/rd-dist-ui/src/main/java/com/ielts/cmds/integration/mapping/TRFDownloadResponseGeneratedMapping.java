package com.ielts.cmds.integration.mapping;

import java.util.Objects;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.organisation.common.out.socketresponse.SocketResponseMetaDataV1;
import com.ielts.cmds.rd.domain.model.out.ReferenceDataNodeV1;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import com.ielts.cmds.rd.socket.response.TRFBookingDownloadResultsResponseV1;
import com.ielts.cmds.rd.socket.response.TRFBookingDownloadResultsV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TRFDownloadResponseGeneratedMapping implements Mapper, IServiceV2<ResultReleasedNodeV1, TRFBookingDownloadResultsResponseV1> {

	@Override
	public TRFBookingDownloadResultsResponseV1 process(ResultReleasedNodeV1 eventBody) {
		TRFBookingDownloadResultsResponseV1 response = new TRFBookingDownloadResultsResponseV1();
        String presignedUrl = null;
        TRFBookingDownloadResultsV1 trfBookingDownloadResultsV1 = new TRFBookingDownloadResultsV1();

        if (Objects.nonNull(eventBody.getReferenceData())) {
            ReferenceDataNodeV1 referenceData = eventBody.getReferenceData().get(0);
            presignedUrl = mapRequestEventBodyToResponseBody(referenceData);
            log.info("Presigned URL Generated: {} for transaction uuid {}", presignedUrl, ThreadLocalHeaderContext.getContext().getTransactionId());

            trfBookingDownloadResultsV1.setTrfDownloadUrl(presignedUrl);

            eventBody.getResultDetails().getTrfPrintStatus().stream().forEach(e -> {
                if (e.getRenditionTypeUuid().toString().equals(referenceData.getReferenceId())) {
                    trfBookingDownloadResultsV1.setPrintEventCount(e.getPrintCount());
                    trfBookingDownloadResultsV1.setPrintedBy(e.getPrintedBy());
                    trfBookingDownloadResultsV1.setPrintedDateTime(e.getPrintedDatetime());
                }
            });

            trfBookingDownloadResultsV1.setFileName(eventBody.getReferenceData().get(0).getReferenceValue());
        }
        if (Objects.isNull(presignedUrl)) {
            BaseEventErrors baseEventErrors = getBaseEventErrors();
            ThreadLocalErrorContext.setContext(baseEventErrors);
            log.error("Presigned URL is not generated: {} for transaction uuid {}", baseEventErrors, ThreadLocalHeaderContext.getContext().getTransactionId());
        }
        final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
        final BaseEventErrors responseErrors = ThreadLocalErrorContext.getContext();
        response.setMeta(responseHeaders);
        response.setErrors(responseErrors);
        response.setResponse(trfBookingDownloadResultsV1);
        return response;
	}

}
