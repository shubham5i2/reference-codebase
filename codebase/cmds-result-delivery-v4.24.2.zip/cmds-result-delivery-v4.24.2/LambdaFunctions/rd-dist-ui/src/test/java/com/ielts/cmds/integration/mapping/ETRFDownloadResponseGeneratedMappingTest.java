package com.ielts.cmds.integration.mapping;

import static com.ielts.cmds.integration.constants.RDDistConstants.PRESIGN_TIMEOUT;
import static com.ielts.cmds.integration.constants.RDDistConstants.TRF_BUCKET;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.doReturn;

import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.integration.SQSEventSetup;
import com.ielts.cmds.integration.presign.PresignURL;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import com.ielts.cmds.rd.socket.response.ETRFBookingDownloadResultsResponseV1;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import uk.org.webcompere.systemstubs.environment.EnvironmentVariables;
import uk.org.webcompere.systemstubs.jupiter.SystemStub;
import uk.org.webcompere.systemstubs.jupiter.SystemStubsExtension;

@ExtendWith(MockitoExtension.class)
@ExtendWith(SystemStubsExtension.class)
class ETRFDownloadResponseGeneratedMappingTest {
	
	@Spy @InjectMocks private ETRFDownloadResponseGeneratedMapping etrfDownloadResponseGeneratedMapping;
	
	@Mock private PresignURL presignURL;
	
	@SystemStub private EnvironmentVariables environmentVariables;
	
	@Test
	void processTest() {
		final HeaderContext context = new HeaderContext();
		context.setTransactionId(UUID.randomUUID());
		ThreadLocalHeaderContext.setContext(context);
		final ResultReleasedNodeV1 releasedNodeV1 = SQSEventSetup.populateETRFDownloadEventBody();
		doReturn(presignURL).when(etrfDownloadResponseGeneratedMapping).getPresign();
		environmentVariables.set(TRF_BUCKET, "test");
		environmentVariables.set(PRESIGN_TIMEOUT, "2");
		
		doReturn("www.jammy.in").when(presignURL).handlePresign("test", "Template.pdf", "2");
		final ETRFBookingDownloadResultsResponseV1 actual = 
				etrfDownloadResponseGeneratedMapping.process(releasedNodeV1);
		assertNotNull(actual);
	}
	
	@Test
	void processTestWithErrors() {
		final HeaderContext context = new HeaderContext();
		context.setTransactionId(UUID.randomUUID());
		ThreadLocalHeaderContext.setContext(context);
		final ResultReleasedNodeV1 releasedNodeV1 = SQSEventSetup.populateETRFDownloadEventBody();
		doReturn(presignURL).when(etrfDownloadResponseGeneratedMapping).getPresign();
		environmentVariables.set(TRF_BUCKET, "test");
		environmentVariables.set(PRESIGN_TIMEOUT, "2");
		
		doReturn(null).when(presignURL).handlePresign("test", "Template.pdf", "2");
		final ETRFBookingDownloadResultsResponseV1 actual = 
				etrfDownloadResponseGeneratedMapping.process(releasedNodeV1);
		assertNotNull(actual.getErrors());
	}

}
