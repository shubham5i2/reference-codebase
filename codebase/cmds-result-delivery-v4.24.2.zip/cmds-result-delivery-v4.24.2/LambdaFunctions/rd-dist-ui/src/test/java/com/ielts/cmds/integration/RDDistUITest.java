package com.ielts.cmds.integration;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.integration.factory.ServiceFactoryV2;
import com.ielts.cmds.serialization.lambda.dist.ui.service.AbstractServiceFactoryV2;

@ExtendWith(MockitoExtension.class)
class RDDistUITest {
	
	@InjectMocks private RDDistUI rdDistUI;
	
	@Test
	void getServiceFactoryTest() {
		final AbstractServiceFactoryV2 actual = rdDistUI.getServiceFactory();
		assertNotNull(actual);
		assertTrue(actual instanceof ServiceFactoryV2);
	}

}
