package com.ielts.cmds.integration.mapping;

import static org.junit.Assert.assertNotNull;

import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.integration.SQSEventSetup;
import com.ielts.cmds.rd.domain.model.out.TRFBookingSearchResultsV1;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

@ExtendWith(MockitoExtension.class)
class TRFBookingSelectionSearchResultGeneratedMappingTest {
	
	@Spy @InjectMocks private TRFBookingSelectionSearchResultGeneratedEventMapping trfBookingSelectionSearchResultGeneratedEventMapping;
	
	@Test
	void processTestWithSelections() {
		final HeaderContext context = new HeaderContext();
		context.setTransactionId(UUID.randomUUID());
		ThreadLocalHeaderContext.setContext(context);
		final TRFBookingSearchResultsV1 trfBookingSearchResultsV1 = SQSEventSetup.populateTRFSelectionSearchEventBody();
		assertNotNull(trfBookingSelectionSearchResultGeneratedEventMapping.process(trfBookingSearchResultsV1));
	}
	
	@Test
	void processTestWithNoSelections() {
		final HeaderContext context = new HeaderContext();
		context.setTransactionId(UUID.randomUUID());
		ThreadLocalHeaderContext.setContext(context);
		final TRFBookingSearchResultsV1 trfBookingSearchResultsV1 = SQSEventSetup.populateTRFSelectionSearchEventBodyWithNoSelections();
		assertNotNull(trfBookingSelectionSearchResultGeneratedEventMapping.process(trfBookingSearchResultsV1));
	}
	

}
