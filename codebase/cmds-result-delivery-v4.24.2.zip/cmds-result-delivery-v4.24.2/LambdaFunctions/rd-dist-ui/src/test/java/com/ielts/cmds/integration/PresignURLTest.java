package com.ielts.cmds.integration;

import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.integration.presign.PresignURL;

@ExtendWith(MockitoExtension.class)
class PresignURLTest {
	
	@Spy @InjectMocks private PresignURL presignURL;
	
	@Test
	void presignTest() {
		assertNotNull(presignURL.handlePresign("test", "test.pdf", "2"));
	}

}
