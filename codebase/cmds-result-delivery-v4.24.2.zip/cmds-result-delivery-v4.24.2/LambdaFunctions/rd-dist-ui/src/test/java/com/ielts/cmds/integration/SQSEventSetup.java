package com.ielts.cmds.integration;

import java.time.LocalDateTime;
import java.time.Month;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.rd.domain.model.enums.ConfirmationStatusEnum;
import com.ielts.cmds.rd.domain.model.enums.DeliveryStatusEnum;
import com.ielts.cmds.rd.domain.model.enums.MinimumScoreSatisfiedEnum;
import com.ielts.cmds.rd.domain.model.out.LocationChangeNodeV1;
import com.ielts.cmds.rd.domain.model.out.RecognisingOrganisationNodeV1;
import com.ielts.cmds.rd.domain.model.out.ReferenceDataNodeV1;
import com.ielts.cmds.rd.domain.model.out.ResultDeliveryBookingLineNodeV1;
import com.ielts.cmds.rd.domain.model.out.ResultDeliveryBookingNodeV1;
import com.ielts.cmds.rd.domain.model.out.ResultDeliveryResultTrfPrintStatusNodeV1;
import com.ielts.cmds.rd.domain.model.out.ResultLineNodeV1;
import com.ielts.cmds.rd.domain.model.out.ResultNodeV1;
import com.ielts.cmds.rd.domain.model.out.ResultReleasedNodeV1;
import com.ielts.cmds.rd.domain.model.out.ResultRenditionNodeV1;
import com.ielts.cmds.rd.domain.model.out.SelectionNodeV1;
import com.ielts.cmds.rd.domain.model.out.TRFBookingSearchResultsV1;
import com.ielts.cmds.rd.domain.model.out.TTPhotoNodeV1;
import com.ielts.cmds.rd.domain.model.proxy.in.ResultStatus;

public class SQSEventSetup {

    public static final String SOCKET_END_POINT = "websocket_apigateway_endpoint";

    public static List<LocationChangeNodeV1> buildLocationChangeNodeV1() {
        List<LocationChangeNodeV1> locationList = new ArrayList<>();
        LocationChangeNodeV1 locationChangeNodeV1 = new LocationChangeNodeV1();

        locationChangeNodeV1.setLocationUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
        locationChangeNodeV1.setLocationName("location.getLocationName()");
        locationChangeNodeV1.setParentLocationUuid(UUID.fromString("0b07b3ee-7c85-408f-9695-916a15f46590"));
        locationChangeNodeV1.setTestCentreNumber("33");
        locationList.add(locationChangeNodeV1);
        return locationList;

    }

    public static ResultDeliveryBookingNodeV1 buildResultDeliveryBookingNodeV1() {
        ResultDeliveryBookingNodeV1 bookingNodeV1 = new ResultDeliveryBookingNodeV1();
        bookingNodeV1.setBookingUuid(UUID.fromString("4fd557d7-701d-4341-8e81-943a8d88fa8c"));
        bookingNodeV1.setExternalBookingUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        bookingNodeV1.setExternalBookingReference("cef4fcb1-2bd2-51f3-889d-abd47d775672");
        bookingNodeV1.setLocationUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        bookingNodeV1.setProductUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        bookingNodeV1.setShortCandidateNumber(Integer.valueOf("12"));
        bookingNodeV1.setPartnerCode("IDP");
        bookingNodeV1.setAgentName("Theâ€¯Agencyâ€¯Inc.");
        bookingNodeV1.setUniqueTestTakerUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        bookingNodeV1.setExternalUniqueTestTakerUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        bookingNodeV1.setCompositeCandidateNumber("47775672");
        bookingNodeV1.setFirstName("abc");
        bookingNodeV1.setLastName("c");
        bookingNodeV1.setEmail("abc@mail.com");
        bookingNodeV1.setIdentityNumber("AB1234");
        bookingNodeV1.setIdentityTypeUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        bookingNodeV1.setSexUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775673"));
        bookingNodeV1.setTitle("exam");
        bookingNodeV1.setLanguageUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        bookingNodeV1.setNationalityUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        bookingNodeV1.setPhone("09876");
        bookingNodeV1.setMobile("98373459300");
        bookingNodeV1.setAddressLine1("address1");
        bookingNodeV1.setAddressLine2("address2");
        bookingNodeV1.setAddressLine3("3");
        bookingNodeV1.setAddressLine4("4");
        bookingNodeV1.setCity("vfyu");
        bookingNodeV1.setStateTerritoryUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        bookingNodeV1.setCountryUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775662"));
        bookingNodeV1.setYearsOfStudy(4);
        bookingNodeV1.setOccupationSectorUuid(UUID.randomUUID());
        bookingNodeV1.setOccupationLevelUuid(UUID.randomUUID());
        bookingNodeV1.setReasonForTestUuid(UUID.randomUUID());
        ResultDeliveryBookingLineNodeV1 bookingLine = new ResultDeliveryBookingLineNodeV1();

        bookingLine.setBookingLineUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        bookingLine.setExternalBookingLineUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        bookingLine.setProductUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        List<ResultDeliveryBookingLineNodeV1> bookingLineList = new ArrayList<>();
        bookingLineList.add(bookingLine);
        bookingNodeV1.setBookingLines(bookingLineList);
        bookingNodeV1.setAgentName("cef4fcb1-2bd2-51f3-889d-abd47d775672");
        bookingNodeV1.setPartnerCode("cef4fcb1-2bd2-51f3-889d-abd47d775672");
        bookingNodeV1.setIdentityNumber("cef4fcb1-2bd2-51f3-889d-abd47d775672");

        return bookingNodeV1;
    }

    private static ResultNodeV1 setResultNodeV1() {
        ResultNodeV1 resultNodeV1 = new ResultNodeV1();

        resultNodeV1.setResultUuid(UUID.fromString("4fd557d7-701d-4341-8e81-943a8d88fa8c"));
        resultNodeV1.setBookingUuid(UUID.fromString("4fd557d7-701d-4341-8e81-943a8d88fa8c"));
        resultNodeV1.setTrfNumber("19CA002712WXA250A");
        resultNodeV1.setCefrLevel("B2");
        resultNodeV1.setResultScore(6.4);
        resultNodeV1.setResultsStatusTypeUuid(UUID.fromString("4fd557d7-701d-4341-8e81-943a8d88fa8c"));
        resultNodeV1.setPublishedTime(OffsetDateTime.now());
        resultNodeV1.setResultTypeUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));

        List<ResultDeliveryResultTrfPrintStatusNodeV1> printStatusNodeV1List = new ArrayList<>();
        ResultDeliveryResultTrfPrintStatusNodeV1 resultDeliveryResultTrfPrintStatusNodeV1 = new ResultDeliveryResultTrfPrintStatusNodeV1();
        resultDeliveryResultTrfPrintStatusNodeV1.setPrintedBy("IELTS");
        resultDeliveryResultTrfPrintStatusNodeV1.setPrintCount(2);
        resultDeliveryResultTrfPrintStatusNodeV1.setPrintedDatetime(OffsetDateTime.now());
        resultDeliveryResultTrfPrintStatusNodeV1.setResultTrfPrintStatusUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        resultDeliveryResultTrfPrintStatusNodeV1.setRenditionTypeUuid(UUID.fromString("15b2e233-81a4-4263-b327-9b47ba09eb01"));
        printStatusNodeV1List.add(resultDeliveryResultTrfPrintStatusNodeV1);
        resultNodeV1.setTrfPrintStatus(printStatusNodeV1List);

        ResultStatus resultStatus = new ResultStatus();
        resultStatus.setBookingReleaseStatusHistoryUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        resultStatus.setStatusDateTime(LocalDateTime.now());
        resultStatus.setReleaseStatus("UNCONFIRMED");
        resultStatus.setUndergoingEor(false);
        resultStatus.setReleaseStatusComment("123456");
        List<ResultLineNodeV1> list = new ArrayList<>();
        ResultLineNodeV1 resultLines = new ResultLineNodeV1();
        resultLines.setResultLineUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        resultLines.setBookingLineUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        resultLines.setResultLineScore(6.5);
        resultLines.setResultLineUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        resultLines.setBookingLineUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        list.add(resultLines);
        resultNodeV1.setResultLines(list);

        List<ResultRenditionNodeV1> renditionNodeV1 = new ArrayList<>();
        ResultRenditionNodeV1 resultRenditionNodeV1 = new ResultRenditionNodeV1();
        resultRenditionNodeV1.setResultsRenditionUuid(UUID.randomUUID());
        resultRenditionNodeV1.setRenditionTypeUuid(UUID.randomUUID());
        resultRenditionNodeV1.setRenditionFileVersion("File Version");
        resultRenditionNodeV1.setRenditionFilePath("File path");
        resultRenditionNodeV1.setRenditionDescription("description");

        renditionNodeV1.add(resultRenditionNodeV1);

        resultNodeV1.setResultRenditions(renditionNodeV1);
        return resultNodeV1;
    }

    public static List<TTPhotoNodeV1> getTestTakerData() {
        List<TTPhotoNodeV1> list = new ArrayList<>();
        TTPhotoNodeV1 ttPhotoNodeV1 = new TTPhotoNodeV1();
        ttPhotoNodeV1.setBookingUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        ttPhotoNodeV1.setPhotoUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        ttPhotoNodeV1.setFilePath("cef4fcb1-2bd2-51f3-889d-abd47d775672");
        ttPhotoNodeV1.setPhotoTypeUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775672"));
        ttPhotoNodeV1.setPhotoVersion("7");
        list.add(ttPhotoNodeV1);
        return list;
    }

    public static SelectionNodeV1 getSelectionNodeV1ForTest() {
        SelectionNodeV1 selectionNodeV1 = new SelectionNodeV1();
        selectionNodeV1.setSelectionUuid(UUID.fromString("2fd557d7-701d-4341-8e81-943a8d88fa8c"));
        selectionNodeV1.setExternalSelectionUuid(UUID.randomUUID());
        selectionNodeV1.setSelectionDate(OffsetDateTime.now());
        selectionNodeV1.setCaseNumber("DCBA");
        selectionNodeV1.setPersonDepartment("Shyam");
        selectionNodeV1.setConfirmationStatus(ConfirmationStatusEnum.CONFIRMED);
        selectionNodeV1.setConfirmationStatusChangedDatetime(OffsetDateTime.now());
        selectionNodeV1.setMinimumScoreSatisfied(MinimumScoreSatisfiedEnum.SATISFIED);
        selectionNodeV1.setTrfNumber("dfcgvbjhknk");
        selectionNodeV1.setDeliveryStatus(DeliveryStatusEnum.DELIVERY_PENDING);
        selectionNodeV1.setDeliveryStatusChangedDatetime(OffsetDateTime.now());
        return selectionNodeV1;
    }

    public static TRFBookingSearchResultsV1 populateTRFSelectionSearchEventBody() {

        List<ResultReleasedNodeV1> resultReleasedNodeV1s = new ArrayList<>();
        ResultReleasedNodeV1 resultReleasedNodeV1 = new ResultReleasedNodeV1();
        ResultReleasedNodeV1 resultReleasedNodeV2 = new ResultReleasedNodeV1();

        resultReleasedNodeV2.setResultDetails(setResultNodeV1());
        resultReleasedNodeV2.setBookingDetails(buildResultDeliveryBookingNodeV1());
        resultReleasedNodeV2.setLocationDetails(buildLocationChangeNodeV1());
        resultReleasedNodeV2.setTtPhotoDetails(getTestTakerData());
        resultReleasedNodeV2.setSelection(getSelectionNodeV1ForTest());
        resultReleasedNodeV2.setOrganisation(setOrganisationDetails());
        resultReleasedNodeV2.setReferenceData(getReferenceData());
        resultReleasedNodeV2.setDeliveryAddress("gcfvhbjnkml");

        resultReleasedNodeV1.setResultDetails(setResultNodeV1());
        resultReleasedNodeV1.setBookingDetails(buildResultDeliveryBookingNodeV1());
        resultReleasedNodeV1.setLocationDetails(buildLocationChangeNodeV1());
        resultReleasedNodeV1.setTtPhotoDetails(getTestTakerData());
        resultReleasedNodeV1.setSelection(getSelectionNodeV1ForTest());
        resultReleasedNodeV1.setOrganisation(setOrganisationDetails());
        resultReleasedNodeV1.setReferenceData(getReferenceData());
        resultReleasedNodeV1.setDeliveryAddress("zsrxdtfyguhij");

        resultReleasedNodeV1s.add(resultReleasedNodeV1);
        resultReleasedNodeV1s.add(resultReleasedNodeV2);
        TRFBookingSearchResultsV1 trfBookingSearchResultsV1 = TRFBookingSearchResultsV1.builder()
                .totalCount(1)
                .entries(resultReleasedNodeV1s).build();

        return trfBookingSearchResultsV1;

    }


    public static TRFBookingSearchResultsV1 populateTRFSelectionSearchEventBodyWithNoSelections() {

        List<ResultReleasedNodeV1> resultReleasedNodeV1s = new ArrayList<>();
        ResultReleasedNodeV1 resultReleasedNodeV1 = new ResultReleasedNodeV1();
        ResultReleasedNodeV1 resultReleasedNodeV2 = new ResultReleasedNodeV1();

        resultReleasedNodeV2.setResultDetails(setResultNodeV1());
        resultReleasedNodeV2.setBookingDetails(buildResultDeliveryBookingNodeV1());
        resultReleasedNodeV2.setLocationDetails(buildLocationChangeNodeV1());
        resultReleasedNodeV2.setTtPhotoDetails(getTestTakerData());
        resultReleasedNodeV2.setReferenceData(getReferenceData());
        resultReleasedNodeV2.setDeliveryAddress("gcfvhbjnkml");

        resultReleasedNodeV1.setResultDetails(setResultNodeV1());
        resultReleasedNodeV1.setBookingDetails(buildResultDeliveryBookingNodeV1());
        resultReleasedNodeV1.setLocationDetails(buildLocationChangeNodeV1());
        resultReleasedNodeV1.setTtPhotoDetails(getTestTakerData());
        resultReleasedNodeV1.setReferenceData(getReferenceData());
        resultReleasedNodeV1.setDeliveryAddress("zsrxdtfyguhij");

        resultReleasedNodeV1s.add(resultReleasedNodeV1);
        resultReleasedNodeV1s.add(resultReleasedNodeV2);
        TRFBookingSearchResultsV1 trfBookingSearchResultsV1 = TRFBookingSearchResultsV1.builder()
                .totalCount(0)
                .entries(resultReleasedNodeV1s).build();

        return trfBookingSearchResultsV1;

    }

    public static RecognisingOrganisationNodeV1 setOrganisationDetails() {
        RecognisingOrganisationNodeV1 ro = new RecognisingOrganisationNodeV1();
        ro.setOrganisationId("fhvgbjkn");
        ro.setName("cambridge");

        return ro;
    }

    public static List<ReferenceDataNodeV1> getReferenceData() {
        ReferenceDataNodeV1 referenceDataNodeV1 = new ReferenceDataNodeV1();
        ReferenceDataNodeV1 referenceDataNodeV2 = new ReferenceDataNodeV1();
        ReferenceDataNodeV1 referenceDataNodeV3 = new ReferenceDataNodeV1();
        referenceDataNodeV1.setReferenceId("cef4fcb1-2bd2-51f3-889d-abd47d775772");
        referenceDataNodeV1.setReferenceValue("cef4fcb1-2bd2-51f3-889d-abd47d875672");
        referenceDataNodeV2.setReferenceId("cef4fcb1-2bd2-51f3-889d-abd47d775972");
        referenceDataNodeV2.setReferenceValue("cef4fcb1-2bd2-51f3-889d-abd47d175672");
        referenceDataNodeV3.setReferenceId("cef4fcb1-2bd2-51f3-889d-abd47d775272");
        referenceDataNodeV3.setReferenceValue("cef4fcb1-2bd2-51f3-889d-abd47d375672");
        referenceDataNodeV1.setReferenceId("15b2e233-81a4-4263-b327-9b47ba09eb01");
        referenceDataNodeV1.setReferenceValue("Template.pdf");

        return Arrays.asList(referenceDataNodeV1, referenceDataNodeV2, referenceDataNodeV3);
    }

    public UiHeader populateEventHeader() {
        final UiHeader header = new UiHeader();
        header.setConnectionId("WPl56dCALPECGwg=");
        header.setTransactionId(UUID.fromString("3e81e94b-8b6a-42b5-970c-b141f9d195a4"));
        header.setCorrelationId(UUID.fromString("123e4567-e89b-12d3-a456-426614174000"));
        header.setPartnerCode(null);
        header.setEventName("TRFBookingSelectionsSearchResultGenerated");
        header.setEventDateTime(LocalDateTime.of(2020, Month.NOVEMBER, 23, 05, 52, 55));
        header.setEventDiscriminator("RD-UI");
        return header;
    }


    public static ResultReleasedNodeV1 populateETRFDownloadEventBody() {

        ResultReleasedNodeV1 resultReleasedNodeV1 = new ResultReleasedNodeV1();

        resultReleasedNodeV1.setResultDetails(setResultNodeV1());
        resultReleasedNodeV1.setBookingDetails(buildResultDeliveryBookingNodeV1());
        resultReleasedNodeV1.setLocationDetails(buildLocationChangeNodeV1());
        resultReleasedNodeV1.setTtPhotoDetails(getTestTakerData());
        resultReleasedNodeV1.setSelection(getSelectionNodeV1ForTest());
        resultReleasedNodeV1.setReferenceData(getReferenceData());

        return resultReleasedNodeV1;

    }
}



