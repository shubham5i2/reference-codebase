package com.ielts.cmds.integration.factory;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ServiceFactoryV2Test {
	
	@InjectMocks private ServiceFactoryV2 serviceFactoryV2;
	
	@Test
	void getServiceTest() {
		assertNotNull(serviceFactoryV2.getService("TRFBookingSelectionsSearchResultGenerated"));
		assertNotNull(serviceFactoryV2.getService("TRFBookingSelectionsSearchResultGenerateFailed"));
		assertNotNull(serviceFactoryV2.getService("ETRFDownloadResponseGenerated"));
		assertNotNull(serviceFactoryV2.getService("TRFDownloadResponseGenerated"));
		assertNotNull(serviceFactoryV2.getService("TRFDownloadResponseGenerateFailed"));
		assertNotNull(serviceFactoryV2.getService("ETRFDownloadResponseGenerateFailed"));
		assertNull(serviceFactoryV2.getService("SomeRandomEvent"));
	}

}
