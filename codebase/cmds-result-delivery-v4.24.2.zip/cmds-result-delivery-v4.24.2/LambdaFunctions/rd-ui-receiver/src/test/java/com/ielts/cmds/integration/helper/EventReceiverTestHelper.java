package com.ielts.cmds.integration.helper;

import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.integration.request.UiEvent;

import java.time.LocalDateTime;
import java.util.UUID;

public class EventReceiverTestHelper {

    public static UiEvent getRequestEvent() {
        final UiEvent bookingUiEvent = new UiEvent();
        final UiHeader uiHeader = new UiHeader();
        uiHeader.setConnectionId("testConnectionId");
        uiHeader.setCorrelationId(UUID.randomUUID());
        uiHeader.setXaccessToken(getXaccesstoken());
        uiHeader.setEventDateTime(LocalDateTime.now());
        uiHeader.setTransactionId(UUID.randomUUID());
        uiHeader.setPartnerCode("IDP");
        bookingUiEvent.setEventHeader(uiHeader);
        bookingUiEvent.setEventBody(getEventBody());
        bookingUiEvent.setEventErrors(null);
        return bookingUiEvent;
    }

    public static UiEvent getFailedRequestEvent() {
        final UiEvent bookingUiEvent = new UiEvent();
        final UiHeader uiHeader = new UiHeader();
        uiHeader.setConnectionId("testConnectionId");
        uiHeader.setCorrelationId(UUID.randomUUID());
        uiHeader.setXaccessToken(getXaccesstoken());
        uiHeader.setEventDateTime(LocalDateTime.now());
        uiHeader.setTransactionId(UUID.randomUUID());
        uiHeader.setPartnerCode(UUID.randomUUID().toString());
        bookingUiEvent.setEventHeader(uiHeader);
        bookingUiEvent.setEventBody(getEventBody());
        bookingUiEvent.setEventErrors(null);
        return bookingUiEvent;
    }

    public static UiEvent getEmptyPartnerCode() {
        final UiEvent bookingUiEvent = new UiEvent();
        final UiHeader uiHeader = new UiHeader();
        uiHeader.setConnectionId("testConnectionId");
        uiHeader.setCorrelationId(UUID.randomUUID());
        uiHeader.setXaccessToken(null);
        uiHeader.setEventDateTime(LocalDateTime.now());
        uiHeader.setTransactionId(UUID.randomUUID());
        bookingUiEvent.setEventHeader(uiHeader);
        bookingUiEvent.setEventBody(getEventBody());
        bookingUiEvent.setEventErrors(null);
        return bookingUiEvent;
    }

    private static String getXaccesstoken() {
        return "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkJTT3YxZ21Zam1vSWNUZFpFcGN3XyJ9.eyJodHRwOi8vY21kc2l6LmNvbS9wYXJ0bmVyQ29kZSI6IkJDIiwiaXNzIjoiaHR0cHM6Ly9jbWRzLXNhbmRib3guZXUuYXV0aDAuY29tLyIsInN1YiI6IkxMOW1KOXE0U0JSWHlxUXVNYzFuM0pkWUxJZzA3REdBQGNsaWVudHMiLCJhdWQiOiJjbWRzLXNhbmRib3gtYXBpIiwiaWF0IjoxNjI1NzI0NzkzLCJleHAiOjE2MjU3MzkxOTMsImF6cCI6IkxMOW1KOXE0U0JSWHlxUXVNYzFuM0pkWUxJZzA3REdBIiwiZ3R5IjoiY2xpZW50LWNyZWRlbnRpYWxzIn0.XvyUmuU-H3NDQKGB9skGBrjcdHdNaww7sUV8TVLWUffZ-we18b69-6aHHhyjMttfmakIgpBygqv8vtxsO8xMG5uQPp9O64gySQ3gLiiRJ6uOWVw8lV28O14PNpLLbten8yNV_9NP-W8-xLyQ1Dvm8Isu9I5h0fycLhEDqvYtNoRD62KV-fq7zoI05C3bzSdW8slSGJIQ3s82h75ahK9PCnD4MUi47fyWBUQxLycb-jnUElheHwSMT5a3BJ3QoAMEDFkZK_k8-5Zq99wOBMvMqLpHkd7S2ATvR3RKQXxq3zGF8Kwi__BBgERs7LcB165KiiCrESsJ2GQQexJin4oYxg";
    }

    private static String getEventBody() {
        return "{\n" +
                "  \"criteria\": {\n" +
                "    \"uniqueTestTakerId\": \"T-F8-04L0-NBIN\",\n" +
                "    \"bookingUuid\": \"ab032fe3-f292-4bba-8178-394c01fb254f\",\n" +
                "    \"externalBookingReference\": \"REF0012345\",\n" +
                "    \"firstName\": \"Alan\",\n" +
                "    \"lastName\": \"Davies\",\n" +
                "    \"email\": \"alan@example.com\",\n" +
                "    \"birthDate\": \"2021-07-08\",\n" +
                "    \"identityNumber\": \"AB12314\",\n" +
                "    \"nationalityUuid\": \"0d9dbdd5-f1e6-4753-b7a9-573a898cd11c\"\n" +
                "  },\n" +
                "  \"pagination\": {\n" +
                "    \"pageNumber\": \"1\",\n" +
                "    \"pageSize\": \"50\"\n" +
                "  },\n" +
                "  \"sorting\": [\n" +
                "    {\n" +
                "      \"sortBy\": \"uniqueTestTakerId\",\n" +
                "      \"sortType\": \"ASC/DSC\"\n" +
                "    }\n" +
                "  ]\n" +
                "}";
    }
}
