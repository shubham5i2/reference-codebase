package com.ielts.cmds.integration;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.PublishResult;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.helper.EventReceiverTestHelper;
import com.ielts.cmds.integration.request.UiEvent;
import com.ielts.cmds.integration.response.GateWayResponseEntity;
import org.apache.http.HttpStatus;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import static com.ielts.cmds.integration.constants.ReceiverConstants.RD_UI_TOPIC_IN_ARN;
import static com.ielts.cmds.integration.constants.ReceiverConstants.REGION;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

/**
 * The type Rd ui receiver test.
 */
@ExtendWith(MockitoExtension.class)
class RDUIReceiverTest {

    @Mock
    private ObjectMapper mapper;

    @Spy
    private RDUIReceiver rdUiReceiver;

    @Mock
    private AmazonSNS snsClient;

    @Mock
    private GateWayResponseEntity<BaseHeader> gateWayResponseEntity;

    @Mock
    private UiEvent uiEvent;

    @Mock
    private UiEvent uiEvent1;

    @Mock
    private UiEvent uiEvent2;

    @Mock
    private Context context;

    @Mock
    private PublishResult snsPublishResult;

    /**
     * Sets up.
     *
     * @throws Exception the exception
     */
    @BeforeEach
    void setUp() {

        this.mapper = new ObjectMapper();
        uiEvent = EventReceiverTestHelper.getRequestEvent();
        uiEvent1 = EventReceiverTestHelper.getFailedRequestEvent();
        uiEvent2 = EventReceiverTestHelper.getEmptyPartnerCode();

        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);

        ReflectionTestUtils.setField(rdUiReceiver, "region", REGION);
        ReflectionTestUtils.setField(rdUiReceiver, "topicArn", RD_UI_TOPIC_IN_ARN);
    }

    @Test
    void handleRequest_Positive_ExpectNoException() throws JsonProcessingException {
        when(rdUiReceiver.getSNSClient()).thenReturn(snsClient);
        when(snsClient.publish(ArgumentMatchers.any())).thenReturn(snsPublishResult);
        gateWayResponseEntity = rdUiReceiver.handleRequest(uiEvent, context);
        Assertions.assertEquals(gateWayResponseEntity.getHeaders().getPartnerCode(), "BC");
    }

    /**
     * Handle request positive expect invalid parameter exception.
     *
     * @throws JsonProcessingException the json processing exception
     */
    @Test
    void handleRequest_Positive_ExpectInvalidParameterException() throws JsonProcessingException {
        when(rdUiReceiver.getSNSClient()).thenReturn(snsClient);
        when(snsClient.publish(ArgumentMatchers.any())).thenReturn(snsPublishResult);
        final GateWayResponseEntity<BaseHeader> response = rdUiReceiver.handleRequest(uiEvent, context);
        Assertions.assertNotNull(response);
        assertEquals(HttpStatus.SC_ACCEPTED, response.getStatusCode());
    }

    /**
     * Publish request body to sns expect json processing exception.
     *
     * @throws JsonProcessingException the json processing exception
     */
    @Test
    void publishRequestBodyToSNS_ExpectJsonProcessingException() throws JsonProcessingException {

        gateWayResponseEntity.setStatusCode(201);
        gateWayResponseEntity.setBase64Encoded(true);
        gateWayResponseEntity.setBody("body");
        gateWayResponseEntity = rdUiReceiver.handleRequest(uiEvent1, context);

        Assertions.assertNotNull(gateWayResponseEntity);
    }

    @Test
    void whenPartnerCodeIsEmpty() throws JsonProcessingException {

        when(rdUiReceiver.publishRequestBodyToSNS(uiEvent2)).thenReturn(gateWayResponseEntity);
        gateWayResponseEntity = rdUiReceiver.handleRequest(uiEvent2, context);
        Assertions.assertNotNull(gateWayResponseEntity);
    }
}

