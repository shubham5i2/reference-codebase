package com.ielts.cmds.integration.constants;

public class ReceiverConstants {
  private ReceiverConstants() {}

  public static final String RD_UI_TOPIC_IN_ARN = "rd_ui_topic_in_arn";
  public static final String RD_UI_LAMBDA = "RdUiReceiverLambda";
  public static final String PARTNER_CODE = "partnerCode";
  public static final String REGION = "AWS_REGION";
  public static final String MSG_ATTR_DATA_TYPE = "String";
  public static final String NAME = "eventName";
}
