package com.ielts.cmds.integration.response;

import com.ielts.cmds.infrastructure.event.BaseHeader;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GateWayResponseEntity<T extends BaseHeader> {
	private int statusCode;
	private boolean isBase64Encoded;
	private T headers;
	private String body;
}
