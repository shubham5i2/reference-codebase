package com.ielts.cmds.integration;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.AmazonSNSClient;
import com.amazonaws.services.sns.model.MessageAttributeValue;
import com.amazonaws.services.sns.model.PublishRequest;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;
import com.ielts.cmds.common.logger.util.CMDSLambdaLoggerUtil;
import com.ielts.cmds.common.utils.CMDSCommonUtils;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.constants.ReceiverConstants;
import com.ielts.cmds.integration.exception.RdDistException;
import com.ielts.cmds.integration.request.UiEvent;
import com.ielts.cmds.integration.response.GateWayResponseEntity;
import com.ielts.cmds.integration.response.ProxyResponseBody;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static com.ielts.cmds.integration.constants.ReceiverConstants.*;
import static java.lang.String.format;

/**
 * The type Rd ui receiver.
 */
@Slf4j
public class RDUIReceiver {

    private final ObjectMapper mapper;

    private final String region;

    private final String topicArn;

    public RDUIReceiver() {

        this.mapper = new ObjectMapper();

        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);

        this.region = System.getenv(REGION);
        this.topicArn = System.getenv(RD_UI_TOPIC_IN_ARN);
    }

    /**
     * @param event
     * @return
     */
    public final GateWayResponseEntity<BaseHeader> handleRequest(final UiEvent event, Context context) throws JsonProcessingException {
        final UUID transactionId = UUID.randomUUID();
        event.getEventHeader().setTransactionId(transactionId);
        Map<String, String> eventContext = event.getEventHeader().getEventContext();
        initializeLogger(transactionId, event.getEventHeader().getCorrelationId(), eventContext);
        log.info("Event received in rd mx : rd-ui-receiver with metadata as {}", mapper.writeValueAsString(event.getEventHeader()));

        log.debug("Request Event: {} ", mapper.writeValueAsString(event));

        return publishRequestBodyToSNS(event);
    }

    /**
     * Publish request body to sns gateway response entity.
     *
     * @param eventToSNS the event to sns
     * @return the gateway response entity
     * @throws JsonProcessingException the json processing exception
     */
    public GateWayResponseEntity<BaseHeader> publishRequestBodyToSNS(final BaseEvent<? extends BaseHeader> eventToSNS)
            throws JsonProcessingException {
        log.debug("START:publishRequestBodyToSNS");
        try {
            final String partnerCode =
                    CMDSCommonUtils.getDataFromClaims(
                            eventToSNS.getEventHeader().getXaccessToken(), PARTNER_CODE);
            eventToSNS.getEventHeader().setPartnerCode(partnerCode);
            log.debug("Event To SNS for partnerCode: {}", eventToSNS.getEventHeader().getPartnerCode());

            publishRequest(eventToSNS);
            log.debug(
                    "Request has been successfully published to SNS: {}, Published message:{}",
                    eventToSNS.getEventHeader(),
                    mapper.writeValueAsString(eventToSNS.getEventBody()));
            log.info("Event being published from Rd Mx : rd-ui-receiver with metadata as {} ", mapper.writeValueAsString(eventToSNS.getEventHeader()));
            return generateResponse(eventToSNS);
        } catch (Exception exception) {
            log.error(
                    "Bad Request Exception - Check for valid Parameters: {}",
                    ExceptionUtils.getStackTrace(exception));
            return generateErrorResponse(
                    eventToSNS,
                    exception,
                    "Unable to publish message - Bad Request",
                    HttpStatus.SC_BAD_REQUEST);
        }
    }

    /**
     * Publish request.
     */
    protected void publishRequest(final BaseEvent<? extends BaseHeader> eventToSNS) {
        try {

            String requestBodyToSNS = mapper.writeValueAsString(eventToSNS);
            AmazonSNS extTopicSNSClient = getSNSClient();
            PublishRequest snsPublishRequest = new PublishRequest();

            final Map<String, MessageAttributeValue> messageAttributes = getMessageAttributes(eventToSNS);

            snsPublishRequest.withMessageAttributes(messageAttributes);
            snsPublishRequest.setTopicArn(determineTopicArn());
            snsPublishRequest.setMessage(requestBodyToSNS);
            extTopicSNSClient.publish(snsPublishRequest);

            log.debug(
                    "MESSAGE PUBLISHED for correlationId: {} ,transaction id: {} stringRequestBodyToSNS: {}",
                    eventToSNS.getEventHeader().getCorrelationId(),
                    eventToSNS.getEventHeader().getTransactionId(),
                    requestBodyToSNS);

        } catch (Exception e) {
            log.error("Bad Request Exception - Check for valid Parameters: ", e);
            throw new RdDistException(format("TransactionId:%s - Exception on posting responseBody to RD INT Topic: %s",
                    eventToSNS.getEventHeader().getTransactionId(), e));
        }

    }

    private Map<String, MessageAttributeValue> getMessageAttributes(final BaseEvent<? extends BaseHeader> baseEvent) {
        final Map<String, MessageAttributeValue> messageAttributes = new HashMap<>();

        messageAttributes.put(
                ReceiverConstants.NAME,
                new MessageAttributeValue()
                        .withDataType(ReceiverConstants.MSG_ATTR_DATA_TYPE)
                        .withStringValue(baseEvent.getEventHeader().getEventName()));
        if (StringUtils.isNotBlank(baseEvent.getEventHeader().getPartnerCode())) {
            messageAttributes.put(
                    ReceiverConstants.PARTNER_CODE,
                    new MessageAttributeValue()
                            .withDataType(ReceiverConstants.MSG_ATTR_DATA_TYPE)
                            .withStringValue(baseEvent.getEventHeader().getPartnerCode()));
        }
        return messageAttributes;
    }

    /**
     * Generate response gateway response entity.
     *
     * @param event the event
     * @return the gateway response entity
     * @throws JsonProcessingException the json processing exception
     */
    protected GateWayResponseEntity<BaseHeader> generateResponse(
            final BaseEvent<? extends BaseHeader> event) throws JsonProcessingException {
        ProxyResponseBody responseBody =
                new ProxyResponseBody(event.getEventHeader().getTransactionId());
        final GateWayResponseEntity<BaseHeader> gateWayResponseEntity = new GateWayResponseEntity<>();

        gateWayResponseEntity.setStatusCode(HttpStatus.SC_ACCEPTED);
        gateWayResponseEntity.setBase64Encoded(Boolean.TRUE);
        gateWayResponseEntity.setHeaders(event.getEventHeader());
        gateWayResponseEntity.setBody(mapper.writeValueAsString(responseBody));
        return gateWayResponseEntity;
    }

    /**
     * Generate error response gate way response entity.
     *
     * @param event      the event
     * @param exception  the exception
     * @param title      the title
     * @param httpStatus the http status
     * @return the gate way response entity
     * @throws JsonProcessingException the json processing exception
     */
    protected GateWayResponseEntity<BaseHeader> generateErrorResponse(final BaseEvent<? extends BaseHeader> event, final Exception exception,
                                                                      final String title,
                                                                      final int httpStatus)
            throws JsonProcessingException {
        final Source source = new Source(exception.getMessage(), event.getEventHeader().getEventName());
        final GateWayResponseEntity<BaseHeader> gateWayResponseEntity = new GateWayResponseEntity<>();
        final ErrorDescription errorDescription = new ErrorDescription();

        gateWayResponseEntity.setStatusCode(httpStatus);
        errorDescription.setInterfaceName(RD_UI_LAMBDA);
        errorDescription.setType(ErrorTypeEnum.ERROR);
        errorDescription.setErrorCode("");
        errorDescription.setSource(source);
        errorDescription.setErrorTicketUuid(event.getEventHeader().getCorrelationId());
        errorDescription.setTitle(title);
        errorDescription.setMessage(exception.getMessage());
        gateWayResponseEntity.setHeaders(event.getEventHeader());
        gateWayResponseEntity.setBody(mapper.writeValueAsString(errorDescription));
        log.info("Event being published from Rd Mx : rd-ui-receiver with metadata as {} and error {}",
                mapper.writeValueAsString(event.getEventHeader()), exception.getMessage());
        return gateWayResponseEntity;
    }


    /**
     * Initialize logger.
     *
     * @param transactionId the transaction id
     * @param correlationId the correlation id
     * @param eventContext  the event context
     */
    protected void initializeLogger(final UUID transactionId, final UUID correlationId, final Map<String, String> eventContext) {
        final CMDSLambdaLoggerUtil loggerUtil = new CMDSLambdaLoggerUtil();
        loggerUtil.initializeThreadContextMap(
                transactionId.toString(), RD_UI_LAMBDA, correlationId.toString(), eventContext);
    }

    protected AmazonSNS getSNSClient() {
        return AmazonSNSClient.builder().withRegion(region).build();
    }

    protected String determineTopicArn() {
        return topicArn;
    }
}
