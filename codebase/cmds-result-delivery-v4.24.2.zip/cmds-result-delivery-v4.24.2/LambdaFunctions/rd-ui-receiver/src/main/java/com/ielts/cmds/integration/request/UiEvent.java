package com.ielts.cmds.integration.request;

import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.UiHeader;

public class UiEvent extends BaseEvent<UiHeader> {
	
}
