package com.ielts.cmds.integration.testdata;

import java.util.UUID;

import com.ielts.cmds.serialization.lambda.utils.HeaderContext;

public class SQSEventBodySetup {

	public static HeaderContext getThreadHeaderContext() {
		final HeaderContext context = new HeaderContext();
		context.setCorrelationId(UUID.randomUUID());
		context.setTransactionId(UUID.randomUUID());
		context.setEventName("POST/v1/regressionstatsavailable");
		return context;
	}

}
