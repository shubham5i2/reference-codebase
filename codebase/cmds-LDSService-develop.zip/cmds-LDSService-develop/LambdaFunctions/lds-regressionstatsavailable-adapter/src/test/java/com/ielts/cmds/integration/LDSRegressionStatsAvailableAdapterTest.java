package com.ielts.cmds.integration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.sns.AmazonSNS;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.evt177.RegressionStatsFileDetailsPublishedV1;
import com.ielts.cmds.integration.testdata.SQSEventBodySetup;
import com.ielts.cmds.serialization.lambda.config.SNSClientConfig;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

@ExtendWith(MockitoExtension.class)
class LDSRegressionStatsAvailableAdapterTest {

	@Mock
	private AmazonS3 s3Client;

	@Mock
	private AmazonSNS snsClient;

	@Mock
	private ObjectMapper mapper;

	@Spy
	@InjectMocks
	private LDSRegressionStatsAvailableAdapter ldsRegressionStatsAvailbleAdapter;

	private static MockedStatic<SNSClientConfig> snsClientConfig;

	private final String topicArn = "topic-out";

	@BeforeAll
	static void init() {
		snsClientConfig = Mockito.mockStatic(SNSClientConfig.class);
	}

	@AfterAll
	static void close() {
		snsClientConfig.close();
	}

	@BeforeEach
	void setup() {
		HeaderContext headerContext = SQSEventBodySetup.getThreadHeaderContext();
		ThreadLocalHeaderContext.setContext(headerContext);
		snsClientConfig.when(SNSClientConfig::getSNSClient).thenReturn(snsClient);
		ReflectionTestUtils.setField(ldsRegressionStatsAvailbleAdapter, "topicArn", topicArn);
	}

	@Test
	void getTopicName() {
		assertNotNull(ldsRegressionStatsAvailbleAdapter.getTopicName());
		assertEquals("topic-out", ldsRegressionStatsAvailbleAdapter.getTopicName());
	}
	
	@Test
	void processRequest() throws JsonProcessingException {
		RegressionStatsFileDetailsPublishedV1 regressionStatsFileDetailsPublishedV1 = new RegressionStatsFileDetailsPublishedV1();
		regressionStatsFileDetailsPublishedV1.setFileName("file");
		regressionStatsFileDetailsPublishedV1.setPresignedUrl("url");
		assertNotNull(ldsRegressionStatsAvailbleAdapter.processRequest(regressionStatsFileDetailsPublishedV1));
		assertEquals("POST/v1/regressionstatsavailable",ThreadLocalHeaderContext.getContext().getEventName());
	}

	
}
