package com.ielts.cmds.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.integration.constants.ReceiverConstants;
import com.ielts.cmds.integration.exception.LdsDistException;
import com.ielts.cmds.integration.mapper.EventMapper;
import com.ielts.cmds.integration.model.LALocationNode;
import com.ielts.cmds.lpr.common.out.model.LocationV1;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;
import com.ielts.cmds.serialization.lambda.AbstractLambda;
import com.ielts.cmds.serialization.lambda.config.DisablePublishToTopic;
import com.ielts.cmds.serialization.lambda.config.ExternalOutputType;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

import java.util.Objects;
import java.util.UUID;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import static com.ielts.cmds.integration.constants.ReceiverConstants.TRANSACTIONID;
import static com.ielts.cmds.integration.constants.ReceiverConstants.PARTNER_CODE;
import static com.ielts.cmds.integration.constants.ReceiverConstants.CORRELATIONID;
import static java.lang.String.format;

@Slf4j
@DisablePublishToTopic
public class LdsLocationDistLa extends AbstractLambda<LocationV1, ExternalOutputType> {

    private final String extCallbackUrl;
    private AuthenticationClient authenticationClient;
    private final EnvironmentAwareAuthenticationClientFactory authenticationClientFactory;

    public LdsLocationDistLa() {
        this.extCallbackUrl = System.getenv(ReceiverConstants.LA_ENDPOINT_URL);
        this.authenticationClientFactory = new EnvironmentAwareAuthenticationClientFactory();
    }
    @SneakyThrows
    @Override
    protected ExternalOutputType processRequest(LocationV1 locationNode) {
        final EventMapper eventMapper = new EventMapper();
        LALocationNode laLocationNode = eventMapper.locationChanged(locationNode);
        log.info("Request being sent to LA: {}", new ObjectMapper().writeValueAsString(laLocationNode));
        if(Objects.isNull(laLocationNode)) {
            log.info("Mapping is not successful. Call to LA is aborted");
            return null;
        }

        postRequestToLa(laLocationNode, extCallbackUrl);
        return null;
    }

    protected void postRequestToLa(final LALocationNode reqBody, final String externalUrl) {
        final UUID transactionId = ThreadLocalHeaderContext.getContext().getTransactionId();
        log.info(" In postRequestToLa Method!! \n RequestBody :{} !! , Callback URL : {} !!", reqBody, externalUrl);
        try {
            final HttpHeaders eventHeaders = getHttpHeaders(ThreadLocalHeaderContext.getContext());
            final HttpEntity<LALocationNode> eventEntity = new HttpEntity<>(reqBody, eventHeaders);
            log.info("EventHeaders: {} ,!!! EventEntity: {} !!!",eventHeaders,eventEntity);
            RestTemplate restTemplate = authenticationClient.getRestTemplate();
            final ResponseEntity<String> response = restTemplate.postForEntity(externalUrl, eventEntity, String.class);
            if (!(response.getStatusCode() == HttpStatus.OK || response.getStatusCode() == HttpStatus.ACCEPTED)) {
                throw new LdsDistException(
                        format(
                                "Request Failed with StatusCode:%s. TransactionId:%s",
                                response.getStatusCode(), transactionId));
            }
            log.info(
                    "Request success with status code: {} . TransactionId: {} ",
                    response.getStatusCode(),
                    transactionId);
        } catch (Exception ex) {
            throw new LdsDistException(
                    format("TransactionId:%s - Exception on posting requestBody: %s", transactionId, ex));
        }

    }

    HttpHeaders getHttpHeaders(final HeaderContext eventHeader) throws LdsDistException {
        final HttpHeaders httpHeaders = new HttpHeaders();
		try {
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
			httpHeaders.set(TRANSACTIONID, eventHeader.getTransactionId().toString());
			httpHeaders.set(CORRELATIONID, eventHeader.getCorrelationId().toString());
			httpHeaders.set(PARTNER_CODE, eventHeader.getPartnerCode());
			authenticationClient = getAuthenticationClient(getPartner());
			httpHeaders.set(authenticationClient.getAuthorizationHeaderName(), authenticationClient.getAccessToken());
			log.info(" HttpHeaders done !!");
		} catch (Exception exception) {
		    log.error("Exception Caught in Service: {}", exception);
		    throw new LdsDistException(exception.getMessage());
	  }
        return httpHeaders;
    }

  protected AuthenticationClient  getAuthenticationClient(String partnerCode) throws LdsDistException {
      if (authenticationClient == null) {
    	  try {
    		  authenticationClient = authenticationClientFactory.getAuthenticationClient(partnerCode);
    	  } catch (Exception exception) {
    		  log.error("Exception Caught in Service: {}", exception);
    		  throw new LdsDistException(exception.getMessage());
    	  }
          
      }
      return authenticationClient;
  }

    String getPartner() {
        return ReceiverConstants.CA;
    }

    @Override
    protected String getTopicName() {
        return null;
    }
}

