package com.ielts.cmds.integration.exception;

public class LdsDistException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public LdsDistException(final String message) {
        super(message);
    }
}
