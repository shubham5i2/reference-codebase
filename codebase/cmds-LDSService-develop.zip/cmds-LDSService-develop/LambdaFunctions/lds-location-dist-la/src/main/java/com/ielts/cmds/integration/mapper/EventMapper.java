package com.ielts.cmds.integration.mapper;

import com.ielts.cmds.integration.model.LocationAddressV1;
import com.ielts.cmds.integration.model.LocationProductV1;
import com.ielts.cmds.integration.model.LALocationNode;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


/**
 * This class is used to map incoming event to appropriate API request body
 */
@Slf4j
public class EventMapper {

    public LALocationNode locationChanged(com.ielts.cmds.lpr.common.out.model.LocationV1 locationNode) {

        try {
            final LALocationNode laLocationNode = new LALocationNode();
            laLocationNode.setLocationUuid(locationNode.getLocationUuid());
            laLocationNode.setParentLocationUuid(locationNode.getParentLocationUuid());
            laLocationNode.setLocationTypeCode(locationNode.getLocationTypeCode());
            laLocationNode.setPartnerCode(locationNode.getPartnerCode());
            laLocationNode.setLocationStatus(locationNode.getStatus());
            laLocationNode.setLocationName(locationNode.getLocationName());
            laLocationNode.setTestCentreNumber(locationNode.getTestCentreNumber());
            laLocationNode.setApprovedDate((locationNode.getApprovedDate()));
            laLocationNode.setTimezoneName(locationNode.getTimezoneName());
            laLocationNode.setWebsiteURL(locationNode.getWebsiteURL());


            if (Objects.nonNull(locationNode.getAddresses())) {
                List<LocationAddressV1> addressList = new ArrayList<>();
                locationNode.getAddresses().forEach(locationAddresses -> {

                    LocationAddressV1 locationAddressV1 = new LocationAddressV1();
                    locationAddressV1.setLocationAddressUuid(locationAddresses.getLocationAddressUuid());
                    locationAddressV1.setAddressLine1(locationAddresses.getAddressLine1());
                    locationAddressV1.setAddressLine2(locationAddresses.getAddressLine2());
                    locationAddressV1.setAddressLine3(locationAddresses.getAddressLine3());
                    locationAddressV1.setAddressLine4(locationAddresses.getAddressLine4());
                    locationAddressV1.setAddressTypeUuid(locationAddresses.getAddressTypeUuid());
                    locationAddressV1.setTerritoryUuid(locationAddresses.getTerritoryUuid());
                    locationAddressV1.setCity(locationAddresses.getCity());
                    locationAddressV1.setEmail(locationAddresses.getEmail());
                    locationAddressV1.setPrimaryPhone(locationAddresses.getPrimaryPhone());
                    locationAddressV1.setCountryIso3Code(locationAddresses.getCountryIso3Code());
                    locationAddressV1.setPostalCode(locationAddresses.getPostalCode());
                    locationAddressV1.setCountryUuid(locationAddresses.getCountryUuid());
                    addressList.add(locationAddressV1);
                });
                laLocationNode.setLocationAddresses(addressList);

            }

            if (Objects.nonNull(locationNode.getApprovedProducts())) {
                List<LocationProductV1> approvedProductList = new ArrayList<>();
                locationNode.getApprovedProducts().forEach(locationHierarchyApprovedProduct -> {
                    LocationProductV1 locationProductV1 = new LocationProductV1();
                    locationProductV1.setProductUuid(locationHierarchyApprovedProduct.getProductUuid());
                    locationProductV1.setEffectiveToDate(dateFormat(locationHierarchyApprovedProduct.getEffectiveToDate()));
                    locationProductV1.setEffectiveFromDate(dateFormat(locationHierarchyApprovedProduct.getEffectiveFromDate()));

                    locationProductV1.setLocationApprovedProductUuid(locationHierarchyApprovedProduct.getLocationProductUuid());
                    approvedProductList.add(locationProductV1);
                });
                laLocationNode.setApprovedProducts(approvedProductList);
            }
            return laLocationNode;
        } catch (Exception exception) {
            log.error("Unable to map LocationNode to LALocationNode", exception);
            return null;
        }

    }

    public String dateFormat(LocalDate localDate) {

        if (Objects.nonNull(localDate)) {
           return DateTimeFormatter.ofPattern("yyyy-MM-dd").format(localDate);
        }
        return null;
    }
}