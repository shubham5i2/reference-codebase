package com.ielts.cmds.integration.utils;


import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.constants.ReceiverConstants;
import com.ielts.cmds.integration.model.LocationAddressV1;
import com.ielts.cmds.integration.model.LocationProductV1;
import com.ielts.cmds.integration.model.LALocationNode;
import com.ielts.cmds.lpr.common.enums.LocationStatus;
import com.ielts.cmds.lpr.common.enums.LocationTypeCode;
import com.ielts.cmds.lpr.common.enums.PartnerCode;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.ielts.cmds.integration.constants.ReceiverConstants.CA;

public class SQSEventBodySetup {


    private static final ObjectMapper mapper = getMapper();

    public static HttpHeaders getHttpHeaders(BaseHeader eventHeader) {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(ReceiverConstants.TRANSACTIONID, eventHeader.getTransactionId().toString());
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.set(ReceiverConstants.CORRELATIONID, eventHeader.getCorrelationId().toString());
        httpHeaders.set(ReceiverConstants.PARTNER_CODE, eventHeader.getPartnerCode());
        return httpHeaders;
    }

    public static String getEventBody() throws JsonProcessingException {
        BaseHeader eventHeader = getEventHeader();
        LALocationNode LALocationNode = setLocationNodeV1();
        String eventBody = mapper.writeValueAsString(LALocationNode);
        BaseEventErrors errorResponse = getErrors();
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        baseEvent.setEventHeader(eventHeader);
        baseEvent.setEventBody(eventBody);
        baseEvent.setEventErrors(errorResponse);
        return mapper.writeValueAsString(baseEvent);
    }

    public static String getEventBody1() throws JsonProcessingException {
        BaseHeader eventHeader = getEventHeader();
        LALocationNode LALocationNode = setLocationNodeV2();
        String eventBody = mapper.writeValueAsString(LALocationNode);
        BaseEventErrors errorResponse = getErrors();
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        baseEvent.setEventHeader(eventHeader);
        baseEvent.setEventBody(eventBody);
        baseEvent.setEventErrors(errorResponse);
        return mapper.writeValueAsString(baseEvent);
    }

    public static BaseEventErrors getErrors() {
        List<ErrorDescription> errorList = new ArrayList<>();
        ErrorDescription description = new ErrorDescription();
        description.setInterfaceName("LocationNodeV1");
        description.setType(ErrorTypeEnum.VALIDATION);
        description.setErrorCode("1234");
        Source source = Source.builder().value("").path("product_uuid").build();
        description.setSource(source);
        errorList.add(description);
        BaseEventErrors errorResponse = new BaseEventErrors(errorList);
        errorResponse.getErrorList();

        return errorResponse;
    }

    public static HeaderContext getEventRequest() throws JsonProcessingException {
        HeaderContext event = new HeaderContext();
        event.setEventName("LocationChanged");
        event.setTransactionId(UUID.fromString("2120c28b-3ce7-4b88-b163-cc20bf6d5728"));
        event.setCallbackURL("https://wiremock.shared.cmdsiz.com/ors/invoke/v1/lds");
        event.setPartnerCode(CA);
        return event;
    }

    public String populateSQSEventInvalidHeader() throws JsonProcessingException {
        final ObjectMapper mapper = getMapper();
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        BaseHeader header = getEventHeader();
        header.setTransactionId(null);
        baseEvent.setEventHeader(header);
        baseEvent.setEventBody(mapper.writeValueAsString(setLocationNodeV1()));
        baseEvent.setEventErrors(null);


        return mapper.writeValueAsString(baseEvent);
    }

    public static String getInvalidEvent() throws JsonProcessingException {
        BaseHeader eventHeader = getEventHeader();
        LALocationNode LALocationNode = setLocationNodeV1();
        String eventBody = mapper.writeValueAsString(LALocationNode);
        BaseEventErrors errorResponse = getErrors();
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        baseEvent.setEventHeader(eventHeader);
        baseEvent.setEventBody(eventBody);
        baseEvent.setEventErrors(errorResponse);
        return "baseEvent";
    }

    public static LALocationNode setLocationNodeV1() {
        LALocationNode LALocationNode = new LALocationNode();
        LALocationNode.setLocationUuid(UUID.fromString("ba961901-f633-4cd5-aa33-d6593d6a3e7c"));
        LALocationNode.setParentLocationUuid(UUID.fromString("e6b8da53-dcc0-44ee-8464-91b1ad7dd7ff"));
        LALocationNode.setLocationTypeCode(LocationTypeCode.TEST_CENTRE);
        LALocationNode.setPartnerCode(PartnerCode.IDP);
        LALocationNode.setLocationStatus(LocationStatus.ACTIVE);
        LALocationNode.setLocationName("IDPMelbourne56");
        LALocationNode.setTestCentreNumber("AU123");
        LALocationNode.setWebsiteURL("https://www.cambridgeassessment.org.uk/");
        LALocationNode.setApprovedDate("2020-01-20");
        LALocationNode.setTimezoneName("Etc/UTC");
        LALocationNode.setLocationAddresses(getLocationAddress());
        LALocationNode.setApprovedProducts(getApprovedProducts());


        return LALocationNode;
    }

    public static LALocationNode setLocationNodeV2() {
        LALocationNode LALocationNode = new LALocationNode();
        LALocationNode.setLocationUuid(UUID.fromString("ba961901-f633-4cd5-aa33-d6593d6a3e7c"));
        LALocationNode.setParentLocationUuid(UUID.fromString("e6b8da53-dcc0-44ee-8464-91b1ad7dd7ff"));
        LALocationNode.setLocationTypeCode(LocationTypeCode.TEST_CENTRE);
        LALocationNode.setPartnerCode(PartnerCode.IDP);
        LALocationNode.setLocationStatus(LocationStatus.ACTIVE);
        LALocationNode.setLocationName("IDPMelbourne56");
        LALocationNode.setTestCentreNumber("AU123");
        LALocationNode.setWebsiteURL("https://www.cambridgeassessment.org.uk/");
        LALocationNode.setApprovedDate("2020-01-30");
        LALocationNode.setTimezoneName("Etc/UTC");
        LALocationNode.setLocationAddresses(getLocationAddress());
        LALocationNode.setApprovedProducts(getApprovedProducts());

        return LALocationNode;
    }

    public static com.ielts.cmds.lpr.common.out.model.LocationV1 setOutModelLocationNode() {
        com.ielts.cmds.lpr.common.out.model.LocationV1 locationV1 = new com.ielts.cmds.lpr.common.out.model.LocationV1();
        locationV1.setLocationUuid(UUID.fromString("ba961901-f633-4cd5-aa33-d6593d6a3e7c"));
        locationV1.setParentLocationUuid(UUID.fromString("e6b8da53-dcc0-44ee-8464-91b1ad7dd7ff"));
        locationV1.setLocationTypeCode(LocationTypeCode.TEST_CENTRE);
        locationV1.setPartnerCode(PartnerCode.IDP);

        locationV1.setLocationName("IDPMelbourne56");
        locationV1.setTestCentreNumber("AU123");
        locationV1.setWebsiteURL("https://www.cambridgeassessment.org.uk/");
        locationV1.setApprovedDate("2020-01-30");
        locationV1.setTimezoneName("Etc/UTC");

        locationV1.setAddresses(getOutModelAddresses());
        locationV1.setApprovedProducts(getOutModelApprovedProducts());

        return locationV1;
    }

    private static List<com.ielts.cmds.lpr.common.out.model.LocationAddressV1> getOutModelAddresses() {
        List<com.ielts.cmds.lpr.common.out.model.LocationAddressV1> addressList = new ArrayList<>();
        com.ielts.cmds.lpr.common.out.model.LocationAddressV1 locationAddressV1 = new com.ielts.cmds.lpr.common.out.model.LocationAddressV1();
        locationAddressV1.setCountryIso3Code("AUS");
        locationAddressV1.setAddressLine1("GPO BOX 1515");
        locationAddressV1.setAddressLine2("The Triangle Building");
        locationAddressV1.setAddressLine4("string");
        locationAddressV1.setAddressLine3("string");
        locationAddressV1.setAddressTypeUuid(UUID.fromString("b32a82a0-693c-4dfd-824f-962784f8bf7d"));
        locationAddressV1.setCity("Melbourne");
        locationAddressV1.setEmail("info@cambridgeassessment.org.uk");
        locationAddressV1.setPostalCode("3000");
        locationAddressV1.setPrimaryPhone("+44 (0)1223 553311");
        locationAddressV1.setTerritoryUuid(UUID.fromString("b32a82a0-693c-4dfd-824f-962784f8bf7d"));
        locationAddressV1.setCountryUuid(UUID.fromString( "b32a82a0-693c-4dfd-824f-962784f8bf8e"));
        locationAddressV1.setLocationAddressUuid(UUID.fromString("cc5d92da-11e6-4285-95a1-d6744ecf9cae"));
        addressList.add(locationAddressV1);
        return addressList;
    }

    public static List<LocationProductV1> getApprovedProducts() {
        List<LocationProductV1> productlist=new ArrayList<>();
        LocationProductV1 locationProductV1 = new LocationProductV1();
        locationProductV1.setProductUuid(UUID.fromString("2c3bace7-9ac7-4213-ab5f-11b34264f9ce"));
        locationProductV1.setEffectiveFromDate("2021-01-30");
        locationProductV1.setEffectiveToDate("2022-03-28");
        locationProductV1.setLocationApprovedProductUuid(UUID.fromString("956e12b0-5a09-48b4-b52c-f2e0658410e0"));
        productlist.add(locationProductV1);
        return productlist;
    }

    public static List<com.ielts.cmds.lpr.common.out.model.LocationProductV1> getOutModelApprovedProducts() {
        List<com.ielts.cmds.lpr.common.out.model.LocationProductV1> productlist=new ArrayList<>();
        com.ielts.cmds.lpr.common.out.model.LocationProductV1 locationProductV1 = new com.ielts.cmds.lpr.common.out.model.LocationProductV1();
        locationProductV1.setProductUuid(UUID.fromString("2c3bace7-9ac7-4213-ab5f-11b34264f9ce"));
        locationProductV1.setEffectiveFromDate(LocalDate.now());
        locationProductV1.setEffectiveToDate(LocalDate.now());
        productlist.add(locationProductV1);
        return productlist;
    }

    public static List<LocationAddressV1> getLocationAddress() {
        List<LocationAddressV1> addressList = new ArrayList<>();
        LocationAddressV1 locationAddressV1 = new LocationAddressV1();
        locationAddressV1.setCountryIso3Code("AUS");
        locationAddressV1.setAddressLine1("GPO BOX 1515");
        locationAddressV1.setAddressLine2("The Triangle Building");
        locationAddressV1.setAddressLine4("string");
        locationAddressV1.setAddressLine3("string");
        locationAddressV1.setAddressTypeUuid(UUID.fromString("b32a82a0-693c-4dfd-824f-962784f8bf7d"));
        locationAddressV1.setCity("Melbourne");
        locationAddressV1.setEmail("info@cambridgeassessment.org.uk");
        locationAddressV1.setPostalCode("3000");
        locationAddressV1.setPrimaryPhone("+44 (0)1223 553311");
        locationAddressV1.setTerritoryUuid(UUID.fromString("b32a82a0-693c-4dfd-824f-962784f8bf7d"));
        locationAddressV1.setCountryUuid(UUID.fromString( "b32a82a0-693c-4dfd-824f-962784f8bf8e"));
        locationAddressV1.setLocationAddressUuid(UUID.fromString("cc5d92da-11e6-4285-95a1-d6744ecf9cae"));
        addressList.add(locationAddressV1);

        return addressList;
    }

    public static ObjectMapper getMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        return mapper;

    }

    public static BaseHeader getEventHeader() {
        BaseHeader eventHeader = new BaseHeader();
        eventHeader.setTransactionId(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
        eventHeader.setCallbackURL("http://35.178.179.164:8105/selection");
        eventHeader.setCorrelationId(UUID.fromString("779187f5-38ed-4e86-b311-050ffe394f81"));
        eventHeader.setPartnerCode("CA");
        eventHeader.setEventName("LegacyResultDelivery");
        LocalDateTime eventDateTime =
                LocalDateTime.parse(
                        "2020-09-29T21:00:35.723Z",
                        DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
        eventHeader.setEventDateTime(eventDateTime);
        return eventHeader;
    }

    public static Map<String, String> getEnvironmentVariablesStub() {
        Map<String, String> map = new HashMap<>();
        map.put(ReceiverConstants.CLIENT_ID, "cmds-id");
        map.put(ReceiverConstants.CLIENT_SECRET, "cmds-secret");
        map.put(ReceiverConstants.ACCESS_TOKEN, "access-token");
        map.put("bc_auth_token_url", "BC_AUTH_URL");
        map.put(ReceiverConstants.CA_AUTH_URL, "ca_auth_url");
        return map;
    }


}


