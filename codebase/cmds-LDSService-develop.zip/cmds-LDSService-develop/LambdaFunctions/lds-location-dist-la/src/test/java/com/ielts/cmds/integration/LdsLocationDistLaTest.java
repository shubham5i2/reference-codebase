package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.constants.ReceiverConstants.CA;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.exception.LdsDistException;
import com.ielts.cmds.integration.model.LALocationNode;
import com.ielts.cmds.integration.utils.SQSEventBodySetup;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.clients.CAAuthenticationClient;
import com.ielts.cmds.security.exception.TokenNotReceivedException;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

@ExtendWith(MockitoExtension.class)
class LdsLocationDistLaTest {


    @Mock
    CAAuthenticationClient authenticationClient;

    @Mock
    private LdsLocationDistLa ldsLocationDistLa;

    @Mock
    private EnvironmentAwareAuthenticationClientFactory authenticationClientFactory;

    @Mock
    private RestTemplate restTemplate;


    @BeforeEach
    public void setUp() throws Exception {
        String eventBody = SQSEventBodySetup.getEventBody();
    }

    @Test
    void getPartnerCodeConstants_whenGetPartnerCodeConstants_thenReturnCA() {
        LdsLocationDistLa locationDistLaSpy = Mockito.spy(ldsLocationDistLa);
        String partnerCodeConstants = locationDistLaSpy.getPartner();
        assertEquals(CA, partnerCodeConstants);
    }

    @Test
    void verifyCallTo_authClient() {
        LdsLocationDistLa locationDistLaSpy = Mockito.spy(ldsLocationDistLa);

        doReturn(authenticationClient).when(locationDistLaSpy).getAuthenticationClient("CA");
        AuthenticationClient authClient = locationDistLaSpy.getAuthenticationClient("CA");
        assertEquals(authenticationClient, authClient);
    }

    @Test
    void testProcessRequest() throws Exception {
        LdsLocationDistLa locationDistLaSpy = Mockito.spy(ldsLocationDistLa);

        ReflectionTestUtils.setField(locationDistLaSpy, "extCallbackUrl", "http://localhost");
        doReturn(authenticationClient).when(locationDistLaSpy).getAuthenticationClient("CA");
        when(authenticationClient.getAuthorizationHeaderName()).thenReturn("Authorization");
        when(authenticationClient.getAccessToken()).thenReturn("XYZ");
        when(authenticationClient.getRestTemplate()).thenReturn(restTemplate);
        ResponseEntity<String> response = new ResponseEntity<>(HttpStatus.OK);
        doReturn(response).when(restTemplate).postForEntity(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.eq(String.class));
         com.ielts.cmds.lpr.common.out.model.LocationV1 locationNode = SQSEventBodySetup.setOutModelLocationNode();
        HeaderContext headerCtx = new HeaderContext();
        headerCtx.setTransactionId(UUID.randomUUID());
        headerCtx.setCorrelationId(UUID.randomUUID());
        headerCtx.setPartnerCode("CA");
        ThreadLocalHeaderContext.setContext(headerCtx);
        locationDistLaSpy.processRequest(locationNode);
        assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());
    }

    @Test
    void whenLegacyDeliveryHasValidAuthenticationHeader_ThenVerifyCallToRestTemplate() throws Exception {
        LdsLocationDistLa locationDistLaSpy = Mockito.spy(ldsLocationDistLa);

        ReflectionTestUtils.setField(locationDistLaSpy, "extCallbackUrl", "http://localhost");
        doReturn(authenticationClient).when(locationDistLaSpy).getAuthenticationClient("CA");
        when(authenticationClient.getAuthorizationHeaderName()).thenReturn("Authorization");
        when(authenticationClient.getAccessToken()).thenReturn("XYZ");
        when(authenticationClient.getRestTemplate()).thenReturn(restTemplate);
        ResponseEntity<String> response = new ResponseEntity<>(HttpStatus.OK);

        doReturn(response).when(restTemplate).postForEntity(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.eq(String.class));

        com.ielts.cmds.lpr.common.out.model.LocationV1 locationNode = SQSEventBodySetup.setOutModelLocationNode();
        HeaderContext headerCtx = new HeaderContext();
        headerCtx.setTransactionId(UUID.randomUUID());
        headerCtx.setCorrelationId(UUID.randomUUID());
        headerCtx.setPartnerCode("CA");
        ThreadLocalHeaderContext.setContext(headerCtx);
        locationDistLaSpy.processRequest(locationNode);
        assertDoesNotThrow(() -> locationDistLaSpy.processRequest(locationNode));
        assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());
    }

    @Test
    void whenEventBodyIsNull() throws Exception {
        LdsLocationDistLa locationDistLaSpy = Mockito.spy(ldsLocationDistLa);

        ReflectionTestUtils.setField(locationDistLaSpy, "extCallbackUrl", "http://localhost");
        doReturn(authenticationClient).when(locationDistLaSpy).getAuthenticationClient("CA");
        when(authenticationClient.getAuthorizationHeaderName()).thenReturn("Authorization");
        when(authenticationClient.getAccessToken()).thenReturn("XYZ");
        when(authenticationClient.getRestTemplate()).thenReturn(restTemplate);
        ResponseEntity<String> response = new ResponseEntity<>(HttpStatus.OK);
        doReturn(response).when(restTemplate).postForEntity(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.eq(String.class));
        com.ielts.cmds.lpr.common.out.model.LocationV1 locationNode = SQSEventBodySetup.setOutModelLocationNode();
        HeaderContext headerCtx = new HeaderContext();
        headerCtx.setTransactionId(UUID.randomUUID());
        headerCtx.setCorrelationId(UUID.randomUUID());
        headerCtx.setPartnerCode("CA");
        ThreadLocalHeaderContext.setContext(headerCtx);
        locationDistLaSpy.processRequest(locationNode);
        assertDoesNotThrow(() -> locationDistLaSpy.processRequest(locationNode));
        assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());
    }


      @Test
        void whenLegacyDeliveryHasInvalidAuthenticationHeader_ThenVerifyCallToRestTemplate() throws Exception {
          LdsLocationDistLa locationDistLaSpy = Mockito.spy(ldsLocationDistLa);

          ReflectionTestUtils.setField(locationDistLaSpy, "extCallbackUrl", "http://localhost");
        doReturn(authenticationClient).when(locationDistLaSpy).getAuthenticationClient("CA");
        when(authenticationClient.getAuthorizationHeaderName()).thenReturn("Authorization");
        when(authenticationClient.getAccessToken()).thenReturn("XYZ");
        when(authenticationClient.getRestTemplate()).thenReturn(restTemplate);
        ResponseEntity<String> response = new ResponseEntity<>(HttpStatus.OK);
        doReturn(response).when(restTemplate).postForEntity(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.eq(String.class));
        com.ielts.cmds.lpr.common.out.model.LocationV1 locationNode = SQSEventBodySetup.setOutModelLocationNode();
        HeaderContext headerCtx = new HeaderContext();
        headerCtx.setTransactionId(UUID.randomUUID());
        headerCtx.setCorrelationId(UUID.randomUUID());
        headerCtx.setPartnerCode("CA");
        ThreadLocalHeaderContext.setContext(headerCtx);
        assertDoesNotThrow(() -> locationDistLaSpy.processRequest(locationNode));
        verify(locationDistLaSpy, times(1)).postRequestToLa(ArgumentMatchers.any(LALocationNode.class), ArgumentMatchers.anyString());
      }
    @Test
    void whenBadGateway_ThenThrowException() throws LdsDistException, TokenNotReceivedException, JsonProcessingException {
        LdsLocationDistLa locationDistLaSpy = Mockito.spy(ldsLocationDistLa);
        ReflectionTestUtils.setField(locationDistLaSpy, "extCallbackUrl", "http://localhost");
        doReturn(authenticationClient).when(locationDistLaSpy).getAuthenticationClient("CA");
        when(authenticationClient.getAuthorizationHeaderName()).thenReturn("Authorization");
        when(authenticationClient.getAccessToken()).thenReturn("XYZ");
        when(authenticationClient.getRestTemplate()).thenReturn(restTemplate);
        ResponseEntity<String> response = new ResponseEntity<>(HttpStatus.BAD_GATEWAY);

        doReturn(response).when(restTemplate).postForEntity(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.eq(String.class));

        com.ielts.cmds.lpr.common.out.model.LocationV1 locationNode = SQSEventBodySetup.setOutModelLocationNode();
        HeaderContext headerCtx = new HeaderContext();
        headerCtx.setTransactionId(UUID.randomUUID());
        headerCtx.setCorrelationId(UUID.randomUUID());
        headerCtx.setPartnerCode("CA");
        ThreadLocalHeaderContext.setContext(headerCtx);
        assertThrows(LdsDistException.class,() -> locationDistLaSpy.processRequest(locationNode));
        assertEquals(HttpStatus.BAD_GATEWAY.value(), response.getStatusCodeValue());
    }

    @Test
    void verifyCallTo_authenticationClient() {
        LdsLocationDistLa ldsLprDistLa = Mockito.spy(ldsLocationDistLa);
        doReturn(authenticationClient).when(ldsLprDistLa).getAuthenticationClient("CA");
        AuthenticationClient authClient = ldsLprDistLa.getAuthenticationClient("CA");
        assertEquals(authenticationClient, authClient);
    }
    @Test
    void getAuthenticationClientWhenPartnerCodeNull_ExpectException() throws  LdsDistException{
        LdsLocationDistLa ldsLprDistLa = Mockito.spy(ldsLocationDistLa);
        assertThrows(LdsDistException.class,()->ldsLprDistLa.getAuthenticationClient(null));
    }

    @Test
    void getHttpHeadersWhenNull_ExpectException() throws JsonProcessingException, LdsDistException{
        LdsLocationDistLa ldsLprDistLa = Mockito.spy(ldsLocationDistLa);
        assertThrows(LdsDistException.class,()->ldsLprDistLa.getHttpHeaders(null));
    }

    @Test
    void getTopicName_ExpectNull() {
        LdsLocationDistLa ldsLprDistLa = Mockito.spy(ldsLocationDistLa);
        assertNull(ldsLprDistLa.getTopicName());
    }

}
