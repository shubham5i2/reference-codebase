package com.ielts.cmds.integration.presign;

import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.presigner.S3Presigner;
import software.amazon.awssdk.services.s3.presigner.model.GetObjectPresignRequest;
import software.amazon.awssdk.services.s3.presigner.model.PresignedGetObjectRequest;

import java.time.Duration;

@Slf4j
public class PresignUrl {
    public String handlePresign(String timeOut,String bucketName, String file)  {

        Region region = Region.EU_WEST_2;
        S3Presigner presigner = S3Presigner.builder()
                .region(region)
                .build();

        GetObjectPresignRequest getObjectPresignRequest = GetObjectPresignRequest.builder()
                .signatureDuration(Duration.ofSeconds(Long.parseLong(timeOut)))
                .getObjectRequest(requestBuilder -> requestBuilder.bucket(bucketName).key(file))
                .build();

        // Generate the presigned request
        PresignedGetObjectRequest presignedGetObjectRequest =
                presigner.presignGetObject(getObjectPresignRequest);
        log.debug("PresignUrl Generated:{}", presignedGetObjectRequest.url());

        return presignedGetObjectRequest.url().toString();
    }
}
