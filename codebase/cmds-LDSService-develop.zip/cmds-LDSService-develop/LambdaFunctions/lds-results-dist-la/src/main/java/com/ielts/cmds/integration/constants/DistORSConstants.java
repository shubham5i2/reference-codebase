package com.ielts.cmds.integration.constants;

public class DistORSConstants {

    private DistORSConstants() {}

    public static final String TRANSACTIONID = "transactionId";
    public static final String CORRELATIONID = "correlationId";
    public static final String PARTNER_CODE = "partnerCode";
    public static final String EVENT_NAME_FAIL = "LegacyResultPublishedFailed";
    public static final String EVENT_NAME_SUCCESS = "LegacyResultPublished";
    public static final String RD = "LDS";
    public static final String CA = "CA";
    public static final String CLIENT_ID = "client_id";
    public static final String LDS_INT_TOPIC_IN = "lds_int_topic_in_arn";
    public static final String CLIENT_SECRET = "client_secret";
    public static final String AUTH_HEADER = "auth_header";
    public static final String AUTH_HEADER_NAME = "Authorization";
    public static final String ACCESS_TOKEN = "access_token";
    public static final String LEGACY_RESULT_DELIVERED_LA = "RDLegacyDeliveredDistLA";  //Need to Change when implementing business logic
    public static final String LA_ENDPOINT_URL = "endpoint_url";
    public static final String TESTTAKER_BUCKET = "tt_photo_bucket_name";
    public static final String URLTIMEOUT ="presigned_url_timeout_second";
    public static final String CA_AUTH_URL = "ca_auth_url";
    public static final String REGION = "AWS_REGION";
    public static final String RD_DIST_LAMBDA = "rd-legacyresultdelivery-dist-la";
    public static final String MSG_ATTR_DATA_TYPE = "String";
    public static final String NAME = "eventName";
    public static final String UKVI_REFERENCE_NUMBER_STRUCTURE =
            "IEL/[TEST_DATE]/[CENTRE_NUMBER]/[CANDIDATE_NUMBER]";
    public static final String ACTIVE = "ACTIVE";

}
