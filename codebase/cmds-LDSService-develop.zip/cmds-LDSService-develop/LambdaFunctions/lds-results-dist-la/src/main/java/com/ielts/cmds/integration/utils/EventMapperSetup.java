package com.ielts.cmds.integration.utils;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.api.evt004.LocationChangeNodeV1;
import com.ielts.cmds.api.evt004.ReferenceDataNodeV1;
import com.ielts.cmds.api.evt004.ResultDeliveryBookingLineNodeV1;
import com.ielts.cmds.api.evt004.ResultDeliveryBookingNodeV1;
import com.ielts.cmds.api.evt004.ResultDeliveryProductNodeV1;
import com.ielts.cmds.api.evt004.ResultLineNodeV1;
import com.ielts.cmds.api.evt004.ResultReleasedNodeV1;
import com.ielts.cmds.integration.constants.DistORSConstants;
import com.ielts.cmds.integration.exception.LdsDistException;
import com.ielts.cmds.lpr.common.enums.LocationTypeCode;
import com.ielts.cmds.rd.lads.integration.model.ProductCharacteristicsV1;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.validation.Valid;

@Slf4j
public class EventMapperSetup {

    private final ObjectMapper mapper;
    private static final Pattern UNDERSCORE_PATTERN = Pattern.compile("_[a-z]");
    
    public EventMapperSetup(){
        this.mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
    }

    public Map<String, String> setScoreInMap(ResultReleasedNodeV1 resultReleasedNodeV1) {

        Map<String, String> componentScore = new HashMap<>();

        if (resultReleasedNodeV1.getResultDetails().getResultLines() != null &&
                resultReleasedNodeV1.getReferenceData() != null) {
            Map<@Valid UUID, Float> resultScoreData = resultReleasedNodeV1.getResultDetails().getResultLines().stream()
                    .collect(Collectors.toMap(ResultLineNodeV1::getBookingLineUuid, ResultLineNodeV1::getResultLineScore));

            Map<String, String> scoreAgainstProductUuid = resultScoreData.entrySet()
                    .stream()
                    .collect(Collectors.toMap(product -> product.getKey().toString(), score -> score.getValue().toString()));

            Map<@Valid UUID, String> bookingLineData = resultReleasedNodeV1.getBookingDetails().getBookingLines().stream()
                    .collect(Collectors.toMap(ResultDeliveryBookingLineNodeV1::getBookingLineUuid, ResultDeliveryBookingLineNodeV1::getComponentName));

            Map<String, String> referenceData = bookingLineData.entrySet()
                    .stream()
                    .collect(Collectors.toMap(product -> product.getKey().toString(), Map.Entry::getValue));

            for (Map.Entry<String, String> entry : referenceData.entrySet()) {
                String keyInReferenceData = entry.getKey();
                if (scoreAgainstProductUuid.containsKey(keyInReferenceData)) {
                    switch (referenceData.get(keyInReferenceData)) {
                        case "L":
                            componentScore.put("L", scoreAgainstProductUuid.get(keyInReferenceData));
                            break;
                        case "R":
                            componentScore.put("R", scoreAgainstProductUuid.get(keyInReferenceData));
                            break;
                        case "W":
                            componentScore.put("W", scoreAgainstProductUuid.get(keyInReferenceData));
                            break;
                        case "S":
                            componentScore.put("S", scoreAgainstProductUuid.get(keyInReferenceData));
                            break;
                        default:
                            log.warn("Invalid Component {} found for product {}", referenceData.get(keyInReferenceData), keyInReferenceData);
                            break;
                    }
                }
            }
        }
        return componentScore;
    }

    public String dateFormat(LocalDate localDate) {
        String formattedDate;

        formattedDate = DateTimeFormatter.ofPattern("dd/MM/yyyy").format(localDate);
        return formattedDate;
    }

    public String setAddress(ResultDeliveryBookingNodeV1 bookingNodeV1) {
        String tempAddress = "";
        if ((StringUtils.isNotBlank(bookingNodeV1.getAddressLine1()))) {
            tempAddress = tempAddress + bookingNodeV1.getAddressLine1();
        }
        if ((StringUtils.isNotBlank(bookingNodeV1.getAddressLine2()) || StringUtils.isNotBlank(tempAddress))) {
            tempAddress = tempAddress + "," + bookingNodeV1.getAddressLine2();
        }
        else {
            tempAddress = tempAddress + bookingNodeV1.getAddressLine2();
        }
        if ((StringUtils.isNotBlank(bookingNodeV1.getAddressLine3()) || StringUtils.isNotBlank(tempAddress))) {
            tempAddress = tempAddress + "," + bookingNodeV1.getAddressLine3();
        }
        else {
            tempAddress = tempAddress + bookingNodeV1.getAddressLine3();
        }
        if ((StringUtils.isNotBlank(bookingNodeV1.getAddressLine4()) || StringUtils.isNotBlank(tempAddress))) {
            tempAddress = tempAddress + "," + bookingNodeV1.getAddressLine4();
        }
        else {
            tempAddress = tempAddress + bookingNodeV1.getAddressLine4();
        }
        if (tempAddress.length() > 420) {
            return tempAddress.substring(0, 420);
        } else {
            return tempAddress;
        }
    }

    public String getReferenceValue(ResultReleasedNodeV1 resultReleasedNodeV1, UUID uuid) {

        Map<String, String> referenceData = resultReleasedNodeV1.getReferenceData().stream().filter(e -> Objects.nonNull(e) && Objects.nonNull(e.getReferenceId()))
                .collect(Collectors.toMap(ReferenceDataNodeV1::getReferenceId, ReferenceDataNodeV1::getReferenceValue));
        if (Objects.isNull(uuid)) {
            return null;
        }
        return referenceData.get(String.valueOf(uuid));
    }

    public String getAgModule(ResultReleasedNodeV1 resultReleasedNodeV1) {
        Map<String, String> referenceData = resultReleasedNodeV1.getReferenceData().stream().filter(e -> Objects.nonNull(e) && Objects.nonNull(e.getReferenceId()))
                .collect(Collectors.toMap(ReferenceDataNodeV1::getReferenceId, ReferenceDataNodeV1::getReferenceValue));

        return referenceData.get("Product_Module_Type");
    }

    public String getCandidateNumber(String candidateNumber) {
        int zeros = 6;
        zeros = zeros - candidateNumber.length();
        String appendZeros = String.join("", Collections.nCopies(zeros, String.valueOf('0')));
        return appendZeros + candidateNumber;

    }

    public static String convertToCamelCase(String str) {
        if (str != null) {
            str = str.toLowerCase();
            str = str.substring(0, 1).toUpperCase()
                    + str.substring(1);
            Matcher matcher = UNDERSCORE_PATTERN.matcher(str);
            while (matcher.find()) {
                str = str.replaceFirst(UNDERSCORE_PATTERN.pattern(),
                		" " + Character.toUpperCase(str.charAt(matcher.end( ) - 1)));
                
            }
        }
        return str;
    }

    public LocationChangeNodeV1 getLocationDetails(UUID locationUuid, ResultReleasedNodeV1 resultReleasedNodeV1) {
        Optional<LocationChangeNodeV1> locationChangeNodeV1Optional = resultReleasedNodeV1.getLocationDetails().stream()
                .filter(location -> (locationUuid).equals(location.getLocationUuid()))
                .findFirst();
        return locationChangeNodeV1Optional.orElse(null);
    }

    public UUID getTestCentreDetails(ResultReleasedNodeV1 resultReleasedNodeV1) {
        Optional<LocationChangeNodeV1> locationChangeNodeV1Optional = resultReleasedNodeV1.getLocationDetails().stream()
                .filter(location -> location.getLocationTypeCode().equals(LocationTypeCode.TEST_CENTRE.getValue()))
                .findFirst();
        LocationChangeNodeV1 locationChangeNodeV1 = locationChangeNodeV1Optional.orElse(new LocationChangeNodeV1());
        return Optional.ofNullable(locationChangeNodeV1.getLocationUuid()).orElse(null);
    }

    public ResultDeliveryBookingLineNodeV1 getSSRProductUuid(ResultReleasedNodeV1 resultReleasedNodeV1)
    {
        Optional<ResultDeliveryBookingLineNodeV1> optionalBookingLineNodeV1 = resultReleasedNodeV1.getBookingDetails().getBookingLines().stream()
                .filter(bookingLine -> DistORSConstants.ACTIVE.equals(bookingLine.getBookingLineStatus()))
                .findFirst();
        return optionalBookingLineNodeV1.orElse(null);
    }

    public String getSeltIndicator(ResultReleasedNodeV1 resultReleased) {
        return Optional.ofNullable(resultReleased)
                .map(ResultReleasedNodeV1::getProductDetails)
                .map(ResultDeliveryProductNodeV1::getProductCharacteristics)
                .map(this::getProductCharacteristicsV1)
                .map(ProductCharacteristicsV1::getCharacteristics)
                .filter(characteristics -> characteristics.contains("SELT"))
                .map(seltCharacteristic -> "1")
                .orElse("0");
    }

    ProductCharacteristicsV1 getProductCharacteristicsV1(String s) {
        if(Objects.isNull(s) || s.isEmpty()) {
            return new ProductCharacteristicsV1();
        }
        try {
            return mapper.readValue(s, ProductCharacteristicsV1.class);
        } catch (JsonProcessingException e) {
        	log.error("Exception Caught in Service: {}", e);
            throw new LdsDistException(e.getMessage());
        }
    }

    public String generateUKVIReferenceNumber(ResultReleasedNodeV1 resultReleasedNodeV1) {
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("ddMMyyyy");
        final String testDate =
                resultReleasedNodeV1.getBookingDetails().getTestDate().format(dateFormat);
        final String centreNumber =
                resultReleasedNodeV1.getLocationDetails().stream()
                        .map(LocationChangeNodeV1::getTestCentreNumber)
                        .filter(Objects::nonNull)
                        .filter(s -> !s.isEmpty())
                        .findFirst()
                        .orElse("");
        final String candidateNumber =
                getCandidateNumber(
                        resultReleasedNodeV1
                                .getBookingDetails()
                                .getShortCandidateNumber()
                                .toString());
        final String[] replacementList = {testDate, centreNumber, candidateNumber};
        final String[] searchList = {"[TEST_DATE]", "[CENTRE_NUMBER]", "[CANDIDATE_NUMBER]"};

        return StringUtils.replaceEach(
                DistORSConstants.UKVI_REFERENCE_NUMBER_STRUCTURE, searchList, replacementList);
    }
}
