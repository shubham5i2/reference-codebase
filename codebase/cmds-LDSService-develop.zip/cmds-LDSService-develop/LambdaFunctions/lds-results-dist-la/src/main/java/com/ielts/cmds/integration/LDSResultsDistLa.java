package com.ielts.cmds.integration;

import com.amazonaws.services.s3.model.AmazonS3Exception;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.evt004.ResultReleasedNodeV1;
import com.ielts.cmds.api.evt004.TTPhotoNodeV1;
import com.ielts.cmds.api.evt004.TTPhotoNodeV1.PhotoCategoryEnum;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.integration.config.S3StorageConfiguration;
import com.ielts.cmds.integration.constants.DistORSConstants;
import com.ielts.cmds.integration.exception.LdsDistException;
import com.ielts.cmds.integration.mapper.EventMapper;
import com.ielts.cmds.integration.presign.PresignUrl;
import com.ielts.cmds.rd.lads.integration.model.MessageV1;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.exception.InvalidClientException;
import com.ielts.cmds.security.exception.TokenNotReceivedException;
import com.ielts.cmds.security.factory.AuthenticationClientFactory;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;
import com.ielts.cmds.serialization.lambda.AbstractLambda;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static com.ielts.cmds.integration.constants.DistORSConstants.*;
import static java.lang.String.format;

import java.security.KeyStoreException;
import java.security.cert.CertificateException;

/**
 * This class serves the purpose of handling Result Delivery to Legacy Adapter.
 */
@Slf4j
public class LDSResultsDistLa extends AbstractLambda<ResultReleasedNodeV1, ResultReleasedNodeV1> {

    private final AuthenticationClientFactory securityAuthenticationFactory;
    private final String extCallbackUrl;
    private final String ttPhotoBucket;
    private final String timeOut;
    private final String topicArn;
    private final S3StorageConfiguration s3StorageConfiguration;

    public LDSResultsDistLa() {
        this.securityAuthenticationFactory = new EnvironmentAwareAuthenticationClientFactory();
        this.extCallbackUrl = System.getenv(LA_ENDPOINT_URL);
        this.ttPhotoBucket = System.getenv(TESTTAKER_BUCKET);
        this.timeOut = System.getenv(URLTIMEOUT);
        this.topicArn = System.getenv(DistORSConstants.LDS_INT_TOPIC_IN);
        this.s3StorageConfiguration = new S3StorageConfiguration();
    }

    @Override
    protected String getTopicName() {
        return topicArn;
    }

    @Override
    protected ResultReleasedNodeV1 processRequest(ResultReleasedNodeV1 resultReleased) {
        try {
             log.info("Event Received in {}:{} with metadata as {} ",RD, getApplicationName(), ThreadLocalHeaderContext.getContext().getEventContext());
            log.info("resultReleasedNodeV1 :{} ",resultReleased);
            Optional<MessageV1> laMessageOp = fetchS3ObjectAndMapInboundEventToLA(resultReleased);
            if(laMessageOp.isPresent()) {
                ResponseEntity<String> response = postRequestToLa(laMessageOp.get());
                if(response.getStatusCode() == HttpStatus.OK) {
                    prepareSuccessHeader();
                } else {
                    log.info("Code is not 200 not accepted by LA , response code {} ", response.getStatusCode());
                    prepareErrorContext(response.getStatusCodeValue());
                    prepareFailHeader();
                }
                return resultReleased;
            } else {
                log.info("Couldn't convert incoming event to LA model. Call to LA is aborted");
                prepareErrorContext(400);
                prepareFailHeader();
                return resultReleased;
            }
        } catch (Exception ex) {
            log.error("Exception on processing event ", ex);
            throw new LdsDistException(format("Exception on processing event :%s", ex));
        }
    }


    private Optional<MessageV1> fetchS3ObjectAndMapInboundEventToLA(ResultReleasedNodeV1 resultReleased) {
        final EventMapper eventMapper = new EventMapper();
        final PresignUrl presignUrl = new PresignUrl();
        String result = "";
        try {
            if(Objects.nonNull(resultReleased)) {
                if (Objects.nonNull(resultReleased.getTtPhotoDetails()) && Objects.nonNull(resultReleased.getReferenceData())) {

                    Optional<String> optionalTtPhoto = resultReleased.getTtPhotoDetails().stream()
                            .filter(photo -> PhotoCategoryEnum.CERTIFICATE == photo.getPhotoCategory())
                            .map(TTPhotoNodeV1::getFilePath).findFirst();

                    String ttPhoto = optionalTtPhoto.orElseThrow(() -> new LdsDistException
                            ("Test Taker Photo not received"));

                    boolean doesTtPhotoExist = s3StorageConfiguration.s3Client().doesObjectExist(ttPhotoBucket, ttPhoto);

                    if (!doesTtPhotoExist) {
                        log.warn("TT photo {} }does not exists in the bucket {}", ttPhoto, ttPhotoBucket);
                    }
                    result = presignUrl.handlePresign(timeOut, ttPhotoBucket, ttPhoto);
                    log.info("result: {} ", result);
                }
                MessageV1 messageV1 = eventMapper.mapIncomingResultToLA(resultReleased, result);
                log.info("MessageV1 after mapping :{} ", messageV1);
                return Optional.of(messageV1);
            } else {
                throw new LdsDistException("Invalid message");
            }
        } catch (AmazonS3Exception amazonS3Exception) {
            log.error("AmazonS3Exception occurred ", amazonS3Exception);
        }
        return Optional.empty();
    }


    private void prepareFailHeader() {
        HeaderContext eventHeader = ThreadLocalHeaderContext.getContext();
        eventHeader.setEventName(EVENT_NAME_FAIL);
        eventHeader.setEventDateTime(LocalDateTime.now());
        ThreadLocalHeaderContext.setContext(eventHeader);
    }

    private void prepareSuccessHeader() {
        HeaderContext eventHeader = ThreadLocalHeaderContext.getContext();
        eventHeader.setEventName(EVENT_NAME_SUCCESS);
        eventHeader.setEventDateTime(LocalDateTime.now());
        ThreadLocalHeaderContext.setContext(eventHeader);
    }

    private void prepareErrorContext(int httpStatus) {
        List<ErrorDescription> errorDescriptionList = generateErrorResponse("Request has not been accepted by legacy adapter", httpStatus);
        BaseEventErrors errorContext = new BaseEventErrors(errorDescriptionList);
        ThreadLocalErrorContext.setContext(errorContext);
    }

    protected List<ErrorDescription> generateErrorResponse(final String errorMessage, final int httpStatus) {
        List<ErrorDescription> errorDescriptionList = new ArrayList<>();
        final Source source = new Source(errorMessage, ThreadLocalHeaderContext.getContext().getEventName());

        final ErrorDescription errorDescription = new ErrorDescription();
        errorDescription.setInterfaceName(RD_DIST_LAMBDA);
        errorDescription.setType(ErrorTypeEnum.ERROR);
        errorDescription.setErrorCode(String.valueOf(httpStatus));
        errorDescription.setSource(source);
        errorDescription.setErrorTicketUuid(ThreadLocalHeaderContext.getContext().getCorrelationId());
        errorDescription.setTitle("Invalid Request");
        errorDescription.setMessage(errorMessage);
        errorDescriptionList.add(errorDescription);
        return  errorDescriptionList;
    }

    protected ResponseEntity<String> postRequestToLa(final MessageV1 responseBody) throws Exception {
        AuthenticationClient authenticationClient = getAuthenticationClient(getPartnerCodeConstant());
        log.info("In PostRequesttoLA !! MessageV1: {} ",responseBody);
        try {
            final HttpHeaders eventHeaders = getHttpHeaders(ThreadLocalHeaderContext.getContext(), authenticationClient);
            final HttpEntity<?> eventEntity = new HttpEntity<>(responseBody, eventHeaders);
            final ResponseEntity<String> response = authenticationClient.getRestTemplate()
                    .postForEntity(extCallbackUrl, eventEntity, String.class);
            log.info("Response code {} ", response.getStatusCode());
            return response;
        } catch (RestClientException | TokenNotReceivedException | InvalidClientException | JsonProcessingException ex) {
            log.error(" Exception on posting requestBody: ", ex);
            throw new LdsDistException("Event Headers - Exception on posting requestBody:");
        }
    }

    HttpHeaders getHttpHeaders(final HeaderContext eventHeader, final AuthenticationClient authenticationClient) throws Exception {
    	log.info("eventHeader: ",eventHeader.toString());
        final HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.set(TRANSACTIONID, String.valueOf(eventHeader.getTransactionId()));
        httpHeaders.set(CORRELATIONID, String.valueOf(eventHeader.getCorrelationId()));
        httpHeaders.set(PARTNER_CODE, eventHeader.getPartnerCode());
        httpHeaders.set(authenticationClient.getAuthorizationHeaderName(), authenticationClient.getAccessToken());
        return httpHeaders;
    }

    AuthenticationClient getAuthenticationClient(String partnerCode) throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException, InvalidClientException {
        return securityAuthenticationFactory.getAuthenticationClient(partnerCode);
    }

    protected String getPartnerCodeConstant() {
        return DistORSConstants.CA;
    }

    protected String getApplicationName() {
        return DistORSConstants.LEGACY_RESULT_DELIVERED_LA;
    }

}
