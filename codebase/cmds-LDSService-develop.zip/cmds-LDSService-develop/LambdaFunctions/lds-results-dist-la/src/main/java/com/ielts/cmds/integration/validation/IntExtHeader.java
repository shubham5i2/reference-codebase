package com.ielts.cmds.integration.validation;

import com.ielts.cmds.rd.domain.model.out.validations.ExtHeader;
import com.ielts.cmds.rd.domain.model.out.validations.IntHeader;

import javax.validation.GroupSequence;

@GroupSequence({IntHeader.class, ExtHeader.class})
public interface IntExtHeader {}
