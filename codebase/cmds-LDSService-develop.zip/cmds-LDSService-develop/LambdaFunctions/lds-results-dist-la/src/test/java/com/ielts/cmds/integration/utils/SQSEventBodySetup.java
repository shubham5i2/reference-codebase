package com.ielts.cmds.integration.utils;


import static com.ielts.cmds.integration.constants.DistORSConstants.ACCESS_TOKEN;
import static com.ielts.cmds.integration.constants.DistORSConstants.CA_AUTH_URL;
import static com.ielts.cmds.integration.constants.DistORSConstants.CLIENT_ID;
import static com.ielts.cmds.integration.constants.DistORSConstants.CLIENT_SECRET;
import static com.ielts.cmds.integration.constants.DistORSConstants.CORRELATIONID;
import static com.ielts.cmds.integration.constants.DistORSConstants.PARTNER_CODE;
import static com.ielts.cmds.integration.constants.DistORSConstants.TESTTAKER_BUCKET;
import static com.ielts.cmds.integration.constants.DistORSConstants.TRANSACTIONID;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import com.ielts.cmds.api.evt004.LinkBookingNodeV1;
import com.ielts.cmds.api.evt004.LocationChangeNodeV1;
import com.ielts.cmds.api.evt004.ReferenceDataNodeV1;
import com.ielts.cmds.api.evt004.ResultDeliveryBookingLineNodeV1;
import com.ielts.cmds.api.evt004.ResultDeliveryBookingLinkNodeV1;
import com.ielts.cmds.api.evt004.ResultDeliveryBookingLinkNodeV1.RoleEnum;
import com.ielts.cmds.api.evt004.ResultDeliveryBookingNodeV1;
import com.ielts.cmds.api.evt004.ResultLineNodeV1;
import com.ielts.cmds.api.evt004.ResultNodeV1;
import com.ielts.cmds.api.evt004.ResultReleasedNodeV1;
import com.ielts.cmds.api.evt004.TTPhotoNodeV1;
import com.ielts.cmds.api.evt004.TTPhotoNodeV1.PhotoCategoryEnum;
import com.ielts.cmds.lpr.common.enums.LocationTypeCode;
import com.ielts.cmds.rd.domain.model.enums.ComponentEnum;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;

public class SQSEventBodySetup {


    public static HttpHeaders getHttpHeaders(HeaderContext headerContext) {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.set(TRANSACTIONID, headerContext.getTransactionId().toString());
        httpHeaders.set(CORRELATIONID, headerContext.getCorrelationId().toString());
        httpHeaders.set(PARTNER_CODE, headerContext.getPartnerCode());
        return httpHeaders;
    }

    public static ResultReleasedNodeV1 setResultReleasedNodeV1() {
        ResultReleasedNodeV1 resultReleasedNodeV1 = new ResultReleasedNodeV1();

        resultReleasedNodeV1.setBookingDetails(setBookingNodeV1());
        resultReleasedNodeV1.setLocationDetails(setLocationNodeV1());
        resultReleasedNodeV1.setResultDetails(setResult());
        resultReleasedNodeV1.setReferenceData(setReferenceDataNodeV1());
        resultReleasedNodeV1.setTtPhotoDetails(setTtPhotoNodeV1());

        return resultReleasedNodeV1;
    }

    public static ResultDeliveryBookingNodeV1 setBookingNodeV1() {
        ResultDeliveryBookingNodeV1 booking = new ResultDeliveryBookingNodeV1();
        booking.setBookingUuid(UUID.randomUUID());
        booking.setExternalBookingUuid(UUID.randomUUID());
        booking.setShortCandidateNumber(918654);
        booking.setLocationUuid(UUID.fromString("f368fda0-149d-4ffd-8674-ff7396f4946f"));
        LocalDate testDate =
                LocalDate.parse(
                        "2020-09-29T21:00:35.723Z",
                        DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
        booking.setTestDate(testDate);
        booking.setTitle("Mr");
        booking.setLastName("Deokar");
        booking.setFirstName("Madhur");
        booking.setSexUuid(UUID.randomUUID());
        LocalDate birthDate =
                LocalDate.parse(
                        "1998-09-21",
                        DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        booking.setBirthDate(birthDate);
        booking.setPhone("9764577724");
        booking.setCity("Pune");
        booking.setPostalCode("8787");
        booking.setCountryUuid(UUID.randomUUID());
        booking.setStateTerritoryUuid(UUID.randomUUID());
        booking.setAddressLine1("Flat 9");
        booking.setAddressLine2("Harshanil");
        booking.setAddressLine3("Rambaug");
        booking.setAddressLine4("Pune");
        booking.setEmail("abc@Gmail.com");
        booking.setYearsOfStudy(3);
        booking.setLanguageUuid(UUID.randomUUID());
        booking.setReasonForTestUuid(UUID.randomUUID());
        booking.setOccupationSectorUuid(UUID.randomUUID());
        booking.setOccupationLevelUuid(UUID.randomUUID());
        booking.setNationalityUuid(UUID.randomUUID());
        booking.setIdentityIssuingAuthority("GOV");
        LocalDate identityExpiryDate =
                LocalDate.parse(
                        "1998-09-21",
                        DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        booking.setIdentityExpiryDate(identityExpiryDate);
        booking.setIdentityTypeUuid(UUID.randomUUID());
        booking.setIdentityNumber("ID00765");
        booking.setAgentName("ABJSYT");
        booking.setBookingLines(setBookingLineNodeV1());
        return booking;
    }

    public static ResultDeliveryBookingNodeV1 setBookingNodeV1Address() {
        ResultDeliveryBookingNodeV1 booking = new ResultDeliveryBookingNodeV1();
        booking.setBookingUuid(UUID.randomUUID());
        booking.setExternalBookingUuid(UUID.randomUUID());
        booking.setShortCandidateNumber(918654);
        LocalDate testDate =
                LocalDate.parse(
                        "2020-09-29T21:00:35.723Z",
                        DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
        booking.setTestDate(testDate);
        booking.setTitle("Mr");
        booking.setLastName("Deokar");
        booking.setFirstName("Madhur");
        booking.setSexUuid(UUID.randomUUID());
        LocalDate birthDate =
                LocalDate.parse(
                        "1998-09-21",
                        DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        booking.setBirthDate(birthDate);
        booking.setPhone("9764577724");
        booking.setCity("Pune");
        booking.setPostalCode("411038");
        booking.setCountryUuid(UUID.randomUUID());
        booking.setStateTerritoryUuid(UUID.randomUUID());
        booking.setAddressLine1("");
        booking.setAddressLine2("");
        booking.setAddressLine3("");
        booking.setAddressLine4("");
        booking.setEmail("abc@Gmail.com");
        booking.setYearsOfStudy(3);
        booking.setLanguageUuid(UUID.randomUUID());
        booking.setReasonForTestUuid(UUID.randomUUID());
        booking.setOccupationSectorUuid(UUID.randomUUID());
        booking.setOccupationLevelUuid(UUID.randomUUID());
        booking.setNationalityUuid(UUID.randomUUID());
        booking.setIdentityIssuingAuthority("GOV");
        LocalDate identityExpiryDate =
                LocalDate.parse(
                        "1998-09-21",
                        DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        booking.setIdentityExpiryDate(identityExpiryDate);
        booking.setIdentityTypeUuid(UUID.randomUUID());
        booking.setIdentityNumber("ID00765");
        booking.setAgentName("ABJSYT");
        booking.setBookingLines(setBookingLineNodeV1());
        return booking;
    }

    public static List<ResultDeliveryBookingLineNodeV1> setBookingLineNodeV1() {
        List<ResultDeliveryBookingLineNodeV1> bookingLineNodeV1s = new ArrayList<>();
        ResultDeliveryBookingLineNodeV1 nodeV1 = new ResultDeliveryBookingLineNodeV1();
        nodeV1.setBookingLineUuid(UUID.fromString("e873fca7-849b-4e3b-8dfc-b6b5108619ab"));
        nodeV1.setBookingLineStatus("ACTIVE");
        nodeV1.setProductUuid(UUID.fromString("e873fca7-849b-4e3b-8dfc-b6b5108619ab"));
        nodeV1.setExternalBookingLineUuid(UUID.randomUUID());
        nodeV1.setComponentName(ComponentEnum.L.toString());
        bookingLineNodeV1s.add(nodeV1);

        ResultDeliveryBookingLineNodeV1 nodeV2 = new ResultDeliveryBookingLineNodeV1();
        nodeV2.setBookingLineUuid(UUID.fromString("e873fca7-849b-4e3b-8dfc-b6b5108621ab"));
        nodeV2.setBookingLineStatus("EXEMPT");
        nodeV2.setProductUuid(UUID.randomUUID());
        nodeV2.setExternalBookingLineUuid(UUID.randomUUID());
        nodeV2.setComponentName(ComponentEnum.R.toString());
        bookingLineNodeV1s.add(nodeV2);

        ResultDeliveryBookingLineNodeV1 nodeV3 = new ResultDeliveryBookingLineNodeV1();
        nodeV3.setBookingLineUuid(UUID.fromString("e873fca7-849b-4e3b-8dfc-b6b5108600ab"));
        nodeV3.setBookingLineStatus("EXEMPT");
        nodeV3.setProductUuid(UUID.randomUUID());
        nodeV3.setExternalBookingLineUuid(UUID.randomUUID());
        nodeV3.setComponentName(ComponentEnum.W.toString());
        bookingLineNodeV1s.add(nodeV3);

        ResultDeliveryBookingLineNodeV1 nodeV4 = new ResultDeliveryBookingLineNodeV1();
        nodeV4.setBookingLineUuid(UUID.fromString("e873fca7-849b-4e3b-8dfc-b6b5102109ab"));
        nodeV4.setBookingLineStatus("EXEMPT");
        nodeV4.setProductUuid(UUID.randomUUID());
        nodeV4.setExternalBookingLineUuid(UUID.randomUUID());
        nodeV4.setComponentName(ComponentEnum.S.toString());
        bookingLineNodeV1s.add(nodeV4);

        return bookingLineNodeV1s;
    }

    public static List<LocationChangeNodeV1> setLocationNodeV1() {
        List<LocationChangeNodeV1> locations = new ArrayList<>();
        LocationChangeNodeV1 location = new LocationChangeNodeV1();
        location.setLocationUuid(UUID.fromString("e873fca7-849b-4e3b-8dfc-b6b5108619ab"));
        location.setParentLocationUuid(UUID.randomUUID());
        location.setLocationTypeCode(LocationTypeCode.TEST_CENTRE.toString());
        location.setTestCentreNumber("TN0843");
        location.setLocationName("Mumbai");
        locations.add(location);
        return locations;
    }

    public static List<ResultLineNodeV1> setResultLineNodeV1() {
        List<ResultLineNodeV1> resultLines = new ArrayList<>();
        ResultLineNodeV1 nodeV1 = new ResultLineNodeV1();
        nodeV1.setResultLineUuid(UUID.randomUUID());
        nodeV1.setBookingLineUuid(UUID.fromString("e873fca7-849b-4e3b-8dfc-b6b5108619ab"));
        nodeV1.setProductUuid(UUID.fromString("e873fca7-849b-4e3b-8dfc-b6b5108619ab"));
        nodeV1.setAbsence(false);
        nodeV1.setResultLineScore((float) 8.5);
        resultLines.add(nodeV1);

        ResultLineNodeV1 nodeV2 = new ResultLineNodeV1();
        nodeV2.setResultLineUuid(UUID.randomUUID());
        nodeV2.setBookingLineUuid(UUID.fromString("e873fca7-849b-4e3b-8dfc-b6b5108621ab"));
        nodeV2.setProductUuid(UUID.fromString("e873fca7-849b-4e3b-8dfc-b6b5108621ab"));
        nodeV2.setAbsence(false);
        nodeV2.setResultLineScore((float) 8.5);
        resultLines.add(nodeV2);

        ResultLineNodeV1 nodeV3 = new ResultLineNodeV1();
        nodeV3.setResultLineUuid(UUID.randomUUID());
        nodeV3.setBookingLineUuid(UUID.fromString("e873fca7-849b-4e3b-8dfc-b6b5108600ab"));
        nodeV3.setProductUuid(UUID.fromString("e873fca7-849b-4e3b-8dfc-b6b5108600ab"));
        nodeV3.setAbsence(false);
        nodeV3.setResultLineScore((float) 7.5);
        resultLines.add(nodeV3);

        ResultLineNodeV1 nodeV4 = new ResultLineNodeV1();
        nodeV4.setResultLineUuid(UUID.randomUUID());
        nodeV4.setBookingLineUuid(UUID.fromString("e873fca7-849b-4e3b-8dfc-b6b5102109ab"));
        nodeV4.setProductUuid(UUID.fromString("e873fca7-849b-4e3b-8dfc-b6b5102109ab"));
        nodeV4.setAbsence(false);
        nodeV4.setResultLineScore((float) 7.5);
        resultLines.add(nodeV4);

        return resultLines;
    }

    public static ResultNodeV1 setResult() {
        ResultNodeV1 result = new ResultNodeV1();
        result.setResultUuid(UUID.randomUUID());
        result.setResultTypeUuid(UUID.randomUUID());
        result.setResultScore((float) 8.6);
        result.setTrfNumber("TRN9856123");
        result.setCefrLevel("Advance");
        result.setResultStatusComment("ResultReleased");
        result.setAdministratorComments("Admin comments");
        result.setResultLines(setResultLineNodeV1());
        return result;
    }

    public static List<ReferenceDataNodeV1> setReferenceDataNodeV1() {
        List<ReferenceDataNodeV1> referenceData = new ArrayList<>();
        ReferenceDataNodeV1 reference = new ReferenceDataNodeV1();
        reference.setReferenceId("e873fca7-849b-4e3b-8dfc-b6b5108621ab");
        reference.setReferenceValue("L");
        referenceData.add(reference);

        ReferenceDataNodeV1 reference1 = new ReferenceDataNodeV1();
        reference1.setReferenceId("e873fca7-849b-4e3b-8dfc-b6b5108619ab");
        reference1.setReferenceValue("R");
        referenceData.add(reference1);

        ReferenceDataNodeV1 reference2 = new ReferenceDataNodeV1();
        reference2.setReferenceId("e873fca7-849b-4e3b-8dfc-b6b5108600ab");
        reference2.setReferenceValue("W");
        referenceData.add(reference2);

        ReferenceDataNodeV1 reference3 = new ReferenceDataNodeV1();
        reference3.setReferenceId("e873fca7-849b-4e3b-8dfc-b6b5102109ab");
        reference3.setReferenceValue("S");
        referenceData.add(reference3);

        ReferenceDataNodeV1 reference4 = new ReferenceDataNodeV1();
        reference4.setReferenceId("4fd557d7-701d-4341-8e81-943a8d88fa8b");
        reference4.setReferenceValue("TTPhoto");
        referenceData.add(reference4);
        return referenceData;
    }

    public static List<ReferenceDataNodeV1> setReferenceDataNodeV1Null() {
        List<ReferenceDataNodeV1> referenceData = new ArrayList<>();
        ReferenceDataNodeV1 reference = new ReferenceDataNodeV1();
        reference.setReferenceId(null);
        reference.setReferenceValue(null);
        referenceData.add(reference);

        ReferenceDataNodeV1 reference1 = new ReferenceDataNodeV1();
        reference1.setReferenceId("");
        reference1.setReferenceValue("R");
        referenceData.add(reference1);

        return referenceData;
    }

    public static List<TTPhotoNodeV1> setTtPhotoNodeV1() {
        List<TTPhotoNodeV1> ttPhotoDetails = new ArrayList<>();
        TTPhotoNodeV1 ttPhotoNodeV1 = new TTPhotoNodeV1();
        ttPhotoNodeV1.setBookingUuid(UUID.fromString("4fd557d7-701d-4341-8e81-943a8d88fa8b"));
        ttPhotoNodeV1.setPhotoTypeUuid(UUID.fromString("4fd557d7-701d-4341-8e81-943a8d88fa8b"));
        ttPhotoNodeV1.setPhotoUuid(UUID.fromString("4fd557d7-701d-4341-8e81-943a8d88fa8b"));
        ttPhotoNodeV1.setFilePath("TTPhoto.jpg");
        ttPhotoNodeV1.setPhotoVersion("V0.0.2");
        ttPhotoNodeV1.setPhotoCategory(PhotoCategoryEnum.CERTIFICATE);
        ttPhotoDetails.add(ttPhotoNodeV1);
        return ttPhotoDetails;
    }

    public static Map<String, String> getEnvironmentVariablesStub() {
        Map<String, String> map = new HashMap<>();
        map.put(CLIENT_ID, "cmds-id");
        map.put(CLIENT_SECRET, "cmds-secret");
        map.put(ACCESS_TOKEN, "access-token");
        map.put("bc_auth_token_url", "BC_AUTH_URL");
        map.put(CA_AUTH_URL, "ca_auth_url");
        map.put(TESTTAKER_BUCKET, "tt_photo_bucket_name");
        return map;
    }

    public static ResultReleasedNodeV1 setResultReleasedNodeV1EmptyAddress() {
        ResultReleasedNodeV1 resultReleasedNodeV1 = new ResultReleasedNodeV1();

        resultReleasedNodeV1.setBookingDetails(setEmptyAddressBookingNodeV1());
        resultReleasedNodeV1.setLocationDetails(setLocationNodeV1());
        resultReleasedNodeV1.setResultDetails(setResult());
        resultReleasedNodeV1.setReferenceData(setReferenceDataNodeV1());
        resultReleasedNodeV1.setTtPhotoDetails(setTtPhotoNodeV1());

        return resultReleasedNodeV1;
    }

    public static ResultReleasedNodeV1 setResultReleasedNodeV1AddressExceeds() {
        ResultReleasedNodeV1 resultReleasedNodeV1 = new ResultReleasedNodeV1();

        resultReleasedNodeV1.setBookingDetails(setAddressRangeExceedsBookingNodeV1());
        resultReleasedNodeV1.setLocationDetails(setLocationNodeV1());
        resultReleasedNodeV1.setResultDetails(setResult());
        resultReleasedNodeV1.setReferenceData(setReferenceDataNodeV1());
        resultReleasedNodeV1.setTtPhotoDetails(setTtPhotoNodeV1());

        return resultReleasedNodeV1;
    }

    public static ResultDeliveryBookingNodeV1 setEmptyAddressBookingNodeV1() {
        ResultDeliveryBookingNodeV1 booking = new ResultDeliveryBookingNodeV1();
        booking.setBookingUuid(UUID.randomUUID());
        booking.setExternalBookingUuid(UUID.randomUUID());
        booking.setShortCandidateNumber(918654);
        booking.setLocationUuid(UUID.randomUUID());
        LocalDate testDate =
                LocalDate.parse(
                        "2020-09-29T21:00:35.723Z",
                        DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
        booking.setTestDate(testDate);
        booking.setTitle("Mr");
        booking.setLastName("Deokar");
        booking.setFirstName("Madhur");
        booking.setSexUuid(UUID.randomUUID());
        LocalDate birthDate =
                LocalDate.parse(
                        "1998-09-21",
                        DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        booking.setBirthDate(birthDate);
        booking.setPhone("9764577724");
        booking.setCity("Pune");
        booking.setPostalCode("411038");
        booking.setCountryUuid(UUID.randomUUID());
        booking.setStateTerritoryUuid(UUID.randomUUID());
        booking.setAddressLine1("");
        booking.setAddressLine2("");
        booking.setAddressLine3("");
        booking.setAddressLine4("");
        booking.setEmail("abc@Gmail.com");
        booking.setYearsOfStudy(3);
        booking.setLanguageUuid(UUID.randomUUID());
        booking.setReasonForTestUuid(UUID.randomUUID());
        booking.setOccupationSectorUuid(UUID.randomUUID());
        booking.setOccupationLevelUuid(UUID.randomUUID());
        booking.setNationalityUuid(UUID.randomUUID());
        booking.setIdentityIssuingAuthority("GOV");
        LocalDate identityExpiryDate =
                LocalDate.parse(
                        "1998-09-21",
                        DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        booking.setIdentityExpiryDate(identityExpiryDate);
        booking.setIdentityTypeUuid(UUID.randomUUID());
        booking.setIdentityNumber("ID00765");
        booking.setAgentName("ABJSYT");
        booking.setProductUuid(UUID.fromString("779187f5-38ed-4e86-b311-050ffe394f81"));
        booking.setBookingLines(setBookingLineNodeV1());
        booking.setBookingLinks(setBookingLinkNodeV1List());
        return booking;
    }

    public static List<ResultDeliveryBookingLinkNodeV1> setBookingLinkNodeV1List() {
        List<ResultDeliveryBookingLinkNodeV1> bookingLinkNodeV1List = new ArrayList<>();
        ResultDeliveryBookingLinkNodeV1 bookingLink = new ResultDeliveryBookingLinkNodeV1();

        LinkBookingNodeV1 link = new LinkBookingNodeV1();
        link.setExternalBookingUuid(UUID.randomUUID());
        link.setBookingUuid(UUID.randomUUID());
        link.setLocationUuid(UUID.randomUUID());
        link.setTestDate(LocalDate.now());
        link.setShortCandidateNumber(100);
        bookingLink.setRole(RoleEnum.SSRORIGINAL);
        bookingLink.setLinkedBooking(link);
        bookingLinkNodeV1List.add(bookingLink);

        return bookingLinkNodeV1List;
    }

    public static ResultDeliveryBookingNodeV1 setAddressRangeExceedsBookingNodeV1() {
        ResultDeliveryBookingNodeV1 booking = new ResultDeliveryBookingNodeV1();
        booking.setBookingUuid(UUID.randomUUID());
        booking.setExternalBookingUuid(UUID.randomUUID());
        booking.setShortCandidateNumber(918654);
        booking.setLocationUuid(UUID.randomUUID());
        LocalDate testDate =
                LocalDate.parse(
                        "2020-09-29T21:00:35.723Z",
                        DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
        booking.setTestDate(testDate);
        booking.setTitle("Mr");
        booking.setLastName("Deokar");
        booking.setFirstName("Madhur");
        booking.setSexUuid(UUID.randomUUID());
        LocalDate birthDate =
                LocalDate.parse(
                        "1998-09-21",
                        DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        booking.setBirthDate(birthDate);
        booking.setPhone("9764577724");
        booking.setCity("Pune");
        booking.setPostalCode("411038");
        booking.setCountryUuid(UUID.randomUUID());
        booking.setStateTerritoryUuid(UUID.randomUUID());
        booking.setAddressLine1("The University of Cambridge is a collegiate research university in Cambridge, United Kingdom. Founded in 1209 and granted a royal charter by Henry III in 1231");
        booking.setAddressLine2("Cambridge is the second-oldest university in the English-speaking world and the world's fourth-oldest surviving university.");
        booking.setAddressLine3("Cambridge’s central administration has evolved over a number of years. Today, it principally consists of the Unified Administrative Service, which comprises the Academic Division");
        booking.setAddressLine4("Cambridge is also the second-oldest university in the English-speaking world and the world's fourth-oldest surviving university.");
        booking.setEmail("abc@Gmail.com");
        booking.setYearsOfStudy(3);
        booking.setLanguageUuid(UUID.randomUUID());
        booking.setReasonForTestUuid(UUID.randomUUID());
        booking.setOccupationSectorUuid(UUID.randomUUID());
        booking.setOccupationLevelUuid(UUID.randomUUID());
        booking.setNationalityUuid(UUID.randomUUID());
        booking.setIdentityIssuingAuthority("GOV");
        LocalDate identityExpiryDate =
                LocalDate.parse(
                        "1998-09-21",
                        DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        booking.setIdentityExpiryDate(identityExpiryDate);
        booking.setIdentityTypeUuid(UUID.randomUUID());
        booking.setIdentityNumber("ID00765");
        booking.setAgentName("ABJSYT");
        booking.setBookingLines(setBookingLineNodeV1());
        return booking;
    }
    
    public static LocationChangeNodeV1 getLocationChangeNodeV1() {
        LocationChangeNodeV1 location = new LocationChangeNodeV1();
        location.setLocationUuid(UUID.fromString("f368fda0-149d-4ffd-8674-ff7396f4946f"));
        location.setLocationName("Vijayawada");
        location.setLocationTypeCode("PHYSICAL_BUILDING");
        location.setTestCentreNumber("0010");
        location.setStatus(LocationChangeNodeV1.StatusEnum.ACTIVE);
        return location;
    }
}
