package com.ielts.cmds.integration;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.AmazonS3Exception;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.api.evt004.ResultReleasedNodeV1;
import com.ielts.cmds.integration.config.S3StorageConfiguration;
import com.ielts.cmds.integration.constants.DistORSConstants;
import com.ielts.cmds.integration.exception.LdsDistException;
import com.ielts.cmds.integration.utils.SQSEventBodySetup;
import com.ielts.cmds.rd.lads.integration.model.MessageV1;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.clients.CAAuthenticationClient;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;
import com.ielts.cmds.security.utils.CAToken;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static com.ielts.cmds.integration.constants.DistORSConstants.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LDSResultsDistLATest {

    @Mock
    ObjectMapper mapper;

    @Mock
    CAAuthenticationClient authenticationClient;

    @Mock
    private LDSResultsDistLa rdLegacyResultDeliveryDistLa;

    @Mock
    private EnvironmentAwareAuthenticationClientFactory securityAuthenticationFactory;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    S3StorageConfiguration s3StorageConfiguration;

    @Mock
    AmazonS3 amazonS3;

    @Captor
    private ArgumentCaptor<MessageV1> eventCapt;

    @BeforeEach
    public void setUp() {
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);

        ReflectionTestUtils.setField(rdLegacyResultDeliveryDistLa, "securityAuthenticationFactory", securityAuthenticationFactory);
        ReflectionTestUtils.setField(rdLegacyResultDeliveryDistLa, "extCallbackUrl", "https://endpoint.orsdomain.com");
        ReflectionTestUtils.setField(rdLegacyResultDeliveryDistLa, "ttPhotoBucket", TESTTAKER_BUCKET);
        ReflectionTestUtils.setField(rdLegacyResultDeliveryDistLa, "timeOut", "900");
        ReflectionTestUtils.setField(rdLegacyResultDeliveryDistLa, "s3StorageConfiguration", s3StorageConfiguration);

        HeaderContext header = new HeaderContext();
        header.setCorrelationId(UUID.randomUUID());
        header.setTransactionId(UUID.randomUUID());
        header.setPartnerCode("CA");
        ThreadLocalHeaderContext.setContext(header);
    }

    @Test
    void getApplicationName() {
        LDSResultsDistLa ldsResultsDistLaSpy = Mockito.spy(rdLegacyResultDeliveryDistLa);
        String applicationName = ldsResultsDistLaSpy.getApplicationName();
        assertEquals(LEGACY_RESULT_DELIVERED_LA, applicationName);
    }

    @Test
    void getPartnerCodeConstants_whenGetPartnerCodeConstants_thenReturnCA() {
        LDSResultsDistLa ldsResultsDistLaSpy = Mockito.spy(rdLegacyResultDeliveryDistLa);
        String partnerCodeConstants = ldsResultsDistLaSpy.getPartnerCodeConstant();
        assertEquals(DistORSConstants.CA, partnerCodeConstants);
    }

    @Test
    void handle_request_headers_tokenException() throws Exception {
        LDSResultsDistLa ldsResultsDistLaSpy = Mockito.spy(rdLegacyResultDeliveryDistLa);
        AuthenticationClient authenticationClient = ldsResultsDistLaSpy.getAuthenticationClient("CA");
        Executable exe = () -> ldsResultsDistLaSpy.getHttpHeaders(ThreadLocalHeaderContext.getContext(), authenticationClient);
        assertThrows(RuntimeException.class, exe);
    }

    @Test
    void verifyCallTo_authClient() throws Exception {
        LDSResultsDistLa ldsResultsDistLaSpy = Mockito.spy(rdLegacyResultDeliveryDistLa);
        doReturn(authenticationClient).when(ldsResultsDistLaSpy).getAuthenticationClient("CA");
        AuthenticationClient authClient = ldsResultsDistLaSpy.getAuthenticationClient("CA");
        assertEquals(authenticationClient, authClient);
    }

    @Test
    void whenLegacyDeliveryHasValidAuthenticationHeader_ThenVerifyCallToRestTemplate() throws Exception {
        LDSResultsDistLa ldsResultsDistLaSpy = Mockito.spy(rdLegacyResultDeliveryDistLa);
        //Prepare test data
        ResultReleasedNodeV1 releasedNode = SQSEventBodySetup.setResultReleasedNodeV1();
        Map<String, String> map = new HashMap<>();
        map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
        map.put(AUTH_HEADER, AUTH_HEADER_NAME);
        ResponseEntity<String> orsResponse = new ResponseEntity<>(HttpStatus.OK);
        HttpHeaders eventHeaders = SQSEventBodySetup.getHttpHeaders(ThreadLocalHeaderContext.getContext());
        eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));

        //Define mock variables behaviour
        when(s3StorageConfiguration.s3Client()).thenReturn(amazonS3);
        when(securityAuthenticationFactory.getAuthenticationClient(CA)).thenReturn(authenticationClient);

        doReturn("authHeaderName").when(authenticationClient).getAuthorizationHeaderName();
        doReturn("accessToken").when(authenticationClient).getAccessToken();
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        doReturn(orsResponse).when(restTemplate).postForEntity(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.eq(String.class));
        //Execute and assert test
        assertDoesNotThrow(() -> ldsResultsDistLaSpy.processRequest(releasedNode));
        assertEquals(HttpStatus.OK.value(), orsResponse.getStatusCodeValue());
    }

    @Test
    void handle_request_call_exception() {
        LDSResultsDistLa ldsResultsDistLaSpy = Mockito.spy(rdLegacyResultDeliveryDistLa);
        ResultReleasedNodeV1 releasedNode = SQSEventBodySetup.setResultReleasedNodeV1();
        CAToken caToken = new CAToken();
        caToken.setAccessToken("accessToken");
        caToken.setExpiresIn(132984);
        caToken.setScope("Scope");
        caToken.setTokenType("Bearer");
        ReflectionTestUtils.setField(ldsResultsDistLaSpy, "securityAuthenticationFactory", securityAuthenticationFactory);
        ReflectionTestUtils.setField(ldsResultsDistLaSpy, "extCallbackUrl", "https://withdrawendpoint.orsdomain.com");
        when(s3StorageConfiguration.s3Client()).thenReturn(amazonS3);
        assertThrows(LdsDistException.class, () -> ldsResultsDistLaSpy.processRequest(releasedNode));
    }

    @Test
    void whenTestTakerPhotoExistsInS3() throws Exception {
        LDSResultsDistLa ldsResultsDistLaSpy = Mockito.spy(rdLegacyResultDeliveryDistLa);
        //Prepare test data
        ResultReleasedNodeV1 releasedNode = SQSEventBodySetup.setResultReleasedNodeV1();
        Map<String, String> map = new HashMap<>();
        map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
        map.put(AUTH_HEADER, AUTH_HEADER_NAME);
        ResponseEntity<String> orsResponse = new ResponseEntity<>(HttpStatus.OK);
        HttpHeaders eventHeaders = SQSEventBodySetup.getHttpHeaders(ThreadLocalHeaderContext.getContext());
        eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));

        //Define mock variables behaviour
        when(securityAuthenticationFactory.getAuthenticationClient(CA)).thenReturn(authenticationClient);
        when(s3StorageConfiguration.s3Client()).thenReturn(amazonS3);
        when(s3StorageConfiguration.s3Client().doesObjectExist(TESTTAKER_BUCKET, "TTPhoto.jpg")).thenReturn(true);

        doReturn("authHeaderName").when(authenticationClient).getAuthorizationHeaderName();
        doReturn("accessToken").when(authenticationClient).getAccessToken();
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        doReturn(orsResponse).when(restTemplate).postForEntity(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.eq(String.class));
        //Execute and assert test
        assertDoesNotThrow(() -> ldsResultsDistLaSpy.processRequest(releasedNode));
        assertEquals(HttpStatus.OK.value(), orsResponse.getStatusCodeValue());
    }

    @Test
    void whenTestTakerPhotoDoesNotExistsInS3() throws Exception {
        LDSResultsDistLa ldsResultsDistLaSpy = Mockito.spy(rdLegacyResultDeliveryDistLa);
        //Prepare test data
        ResultReleasedNodeV1 releasedNode = SQSEventBodySetup.setResultReleasedNodeV1();
        Map<String, String> map = new HashMap<>();
        map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
        map.put(AUTH_HEADER, AUTH_HEADER_NAME);
        ResponseEntity<String> orsResponse = new ResponseEntity<>(HttpStatus.OK);
        HttpHeaders eventHeaders = SQSEventBodySetup.getHttpHeaders(ThreadLocalHeaderContext.getContext());
        eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));

        //Define mock variables behaviour
        when(securityAuthenticationFactory.getAuthenticationClient(CA)).thenReturn(authenticationClient);
        when(s3StorageConfiguration.s3Client()).thenReturn(amazonS3);
        when(s3StorageConfiguration.s3Client().doesObjectExist(TESTTAKER_BUCKET, "TTPhoto.jpg")).thenReturn(false);

        doReturn("authHeaderName").when(authenticationClient).getAuthorizationHeaderName();
        doReturn("accessToken").when(authenticationClient).getAccessToken();
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        doReturn(orsResponse).when(restTemplate).postForEntity(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.eq(String.class));
        //Execute and assert test
        assertDoesNotThrow(() -> ldsResultsDistLaSpy.processRequest(releasedNode));
        assertEquals(HttpStatus.OK.value(), orsResponse.getStatusCodeValue());
    }

    @Test
    void whenAddressIsEmpty_ThenVerifyCallToRestTemplate() throws Exception {
        LDSResultsDistLa ldsResultsDistLaSpy = Mockito.spy(rdLegacyResultDeliveryDistLa);
        //Prepare test data
        ResultReleasedNodeV1 releasedNode = SQSEventBodySetup.setResultReleasedNodeV1EmptyAddress();
        Map<String, String> map = new HashMap<>();
        map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
        map.put(AUTH_HEADER, AUTH_HEADER_NAME);
        ResponseEntity<String> orsResponse = new ResponseEntity<>(HttpStatus.OK);
        HttpHeaders eventHeaders = SQSEventBodySetup.getHttpHeaders(ThreadLocalHeaderContext.getContext());
        eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));
        //Define mock variables behaviour
        when(s3StorageConfiguration.s3Client()).thenReturn(amazonS3);
        when(s3StorageConfiguration.s3Client().doesObjectExist(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(true);
        when(securityAuthenticationFactory.getAuthenticationClient(CA)).thenReturn(authenticationClient);

        doReturn("authHeaderName").when(authenticationClient).getAuthorizationHeaderName();
        doReturn("accessToken").when(authenticationClient).getAccessToken();
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        doReturn(orsResponse).when(restTemplate).postForEntity(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.eq(String.class));
        //Execute and assert test
        assertDoesNotThrow(() -> ldsResultsDistLaSpy.processRequest(releasedNode));
        assertEquals(HttpStatus.OK.value(), orsResponse.getStatusCodeValue());
    }

    @Test
    void whenAddressExceeds_ThenVerifyCallToRestTemplate() throws Exception {
        LDSResultsDistLa ldsResultsDistLaSpy = Mockito.spy(rdLegacyResultDeliveryDistLa);
        //Prepare test data
        ResultReleasedNodeV1 releasedNode = SQSEventBodySetup.setResultReleasedNodeV1AddressExceeds();
        Map<String, String> map = new HashMap<>();
        map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
        map.put(AUTH_HEADER, AUTH_HEADER_NAME);
        ResponseEntity<String> orsResponse = new ResponseEntity<>(HttpStatus.OK);
        HttpHeaders eventHeaders = SQSEventBodySetup.getHttpHeaders(ThreadLocalHeaderContext.getContext());
        eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));
        //Define mock variables behaviour
        when(s3StorageConfiguration.s3Client()).thenReturn(amazonS3);
        when(s3StorageConfiguration.s3Client().doesObjectExist(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(true);
        when(securityAuthenticationFactory.getAuthenticationClient(CA)).thenReturn(authenticationClient);

        doReturn("authHeaderName").when(authenticationClient).getAuthorizationHeaderName();
        doReturn("accessToken").when(authenticationClient).getAccessToken();
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        doReturn(orsResponse).when(restTemplate).postForEntity(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.eq(String.class));
        //Execute and assert test
        assertDoesNotThrow(() -> ldsResultsDistLaSpy.processRequest(releasedNode));
        assertEquals(HttpStatus.OK.value(), orsResponse.getStatusCodeValue());
    }

    @Test
    void whenLegacyDeliveryHasInvalidAuthenticationHeader_ThenVerifyCallToRestTemplate() throws Exception {
        LDSResultsDistLa ldsResultsDistLaSpy = Mockito.spy(rdLegacyResultDeliveryDistLa);
        //Prepare test data
        ResultReleasedNodeV1 releasedNode = SQSEventBodySetup.setResultReleasedNodeV1();
        Map<String, String> map = new HashMap<>();
        map.put(ACCESS_TOKEN, com.ielts.cmds.integration.utils.SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
        map.put(AUTH_HEADER, AUTH_HEADER_NAME);
        ResponseEntity<String> LAResponse = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        HttpHeaders eventHeaders = SQSEventBodySetup.getHttpHeaders(ThreadLocalHeaderContext.getContext());
        eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));
        //Define mock variables behaviour
        when(s3StorageConfiguration.s3Client()).thenReturn(amazonS3);
        when(securityAuthenticationFactory.getAuthenticationClient(CA)).thenReturn(authenticationClient);

        doReturn("authHeaderName").when(authenticationClient).getAuthorizationHeaderName();
        doReturn("accessToken").when(authenticationClient).getAccessToken();
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        doReturn(LAResponse).when(restTemplate).postForEntity(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.eq(String.class));
        //Execute and assert test
        assertDoesNotThrow(() -> ldsResultsDistLaSpy.processRequest(releasedNode));
        verify(ldsResultsDistLaSpy, times(1)).postRequestToLa(eventCapt.capture());
        verify(ldsResultsDistLaSpy, times(1)).generateErrorResponse(anyString(), ArgumentMatchers.eq(HttpStatus.BAD_REQUEST.value()));
        assertEquals(HttpStatus.BAD_REQUEST.value(), LAResponse.getStatusCodeValue());
    }

    @Test
    void whenBodyIsNull_ThenThrowLdsDistException() {
        LDSResultsDistLa ldsResultsDistLaSpy = Mockito.spy(rdLegacyResultDeliveryDistLa);
        // Given
        assertThrows(LdsDistException.class, () -> ldsResultsDistLaSpy.processRequest(null));
    }

    @Test
    void testWithValidCalculatedPercentageScore() throws Exception {
        LDSResultsDistLa ldsResultsDistLaSpy = Mockito.spy(rdLegacyResultDeliveryDistLa);
        //Prepare test data
        ResultReleasedNodeV1 releasedNode = SQSEventBodySetup.setResultReleasedNodeV1();
        ResponseEntity<String> orsResponse = new ResponseEntity<>(HttpStatus.OK);
        //Define mock variables behaviour
        when(securityAuthenticationFactory.getAuthenticationClient(CA)).thenReturn(authenticationClient);
        when(s3StorageConfiguration.s3Client()).thenReturn(amazonS3);
        when(s3StorageConfiguration.s3Client().doesObjectExist(TESTTAKER_BUCKET, "TTPhoto.jpg")).thenReturn(true);
        doReturn("authHeaderName").when(authenticationClient).getAuthorizationHeaderName();
        doReturn("accessToken").when(authenticationClient).getAccessToken();
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        doReturn(orsResponse).when(restTemplate).postForEntity(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.eq(String.class));
        //Execute and assert test
        assertDoesNotThrow(() -> ldsResultsDistLaSpy.processRequest(releasedNode));
    }

    @Test
    void testWithValidCalculatedPercentageScoreExceptionFromRestAPI() throws Exception {
        LDSResultsDistLa ldsResultsDistLaSpy = Mockito.spy(rdLegacyResultDeliveryDistLa);
        //Prepare test data
        ResultReleasedNodeV1 releasedNode = SQSEventBodySetup.setResultReleasedNodeV1();
        //Define mock variables behaviour
        when(securityAuthenticationFactory.getAuthenticationClient(CA)).thenReturn(authenticationClient);
        when(s3StorageConfiguration.s3Client()).thenReturn(amazonS3);
        when(s3StorageConfiguration.s3Client().doesObjectExist(TESTTAKER_BUCKET, "TTPhoto.jpg")).thenReturn(true);
        doReturn("authHeaderName").when(authenticationClient).getAuthorizationHeaderName();
        doReturn("accessToken").when(authenticationClient).getAccessToken();
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        doThrow(RestClientException.class).when(restTemplate).postForEntity(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.eq(String.class));
        //Execute and assert test
        assertThrows(LdsDistException.class, () -> ldsResultsDistLaSpy.processRequest(releasedNode));
    }

    @Test
    void whenAddressExceeds_ThenVerifyNoCallToRestTemplate() {
        LDSResultsDistLa ldsResultsDistLaSpy = Mockito.spy(rdLegacyResultDeliveryDistLa);
        //Prepare test data
        ResultReleasedNodeV1 releasedNode = SQSEventBodySetup.setResultReleasedNodeV1AddressExceeds();
        Map<String, String> map = new HashMap<>();
        map.put(ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ACCESS_TOKEN));
        map.put(AUTH_HEADER, AUTH_HEADER_NAME);
        HttpHeaders eventHeaders = SQSEventBodySetup.getHttpHeaders(ThreadLocalHeaderContext.getContext());
        eventHeaders.set(map.get(AUTH_HEADER), map.get(ACCESS_TOKEN));
        //Define mock variables behaviour
        when(s3StorageConfiguration.s3Client()).thenReturn(amazonS3);
        when(s3StorageConfiguration.s3Client().doesObjectExist(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenThrow(AmazonS3Exception.class);
        //Execute and assert test
        assertDoesNotThrow(() -> ldsResultsDistLaSpy.processRequest(releasedNode));
    }

    @Test
    void testGetTopicName() {
        LDSResultsDistLa ldsResultsDistLaSpy = Mockito.spy(rdLegacyResultDeliveryDistLa);
        assertNull(ldsResultsDistLaSpy.getTopicName());
    }
}
