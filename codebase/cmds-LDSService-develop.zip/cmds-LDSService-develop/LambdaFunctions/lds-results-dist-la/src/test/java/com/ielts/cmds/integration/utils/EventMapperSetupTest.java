package com.ielts.cmds.integration.utils;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.api.evt004.ResultDeliveryBookingNodeV1;
import com.ielts.cmds.api.evt004.ResultReleasedNodeV1;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class EventMapperSetupTest {

    @InjectMocks EventMapperSetup eventMapperSetup;

    @Test
    void checkForNullUuid(){
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        assertDoesNotThrow(()->eventMapperSetup.getReferenceValue(resultReleasedNodeV1,null));
    }

    @Test
    void checkForNullReferenceId(){
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        resultReleasedNodeV1.getReferenceData().get(0).setReferenceId(null);
        assertDoesNotThrow(()->eventMapperSetup.getReferenceValue(resultReleasedNodeV1,null));
    }

    @Test
    void checkForNullReferenceData(){
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        resultReleasedNodeV1.setReferenceData(SQSEventBodySetup.setReferenceDataNodeV1Null());
        assertDoesNotThrow(()->eventMapperSetup.getReferenceValue(resultReleasedNodeV1,null));
    }

    @Test
    void checkForNullResultLines(){
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        resultReleasedNodeV1.getResultDetails().setResultLines(null);
        resultReleasedNodeV1.setReferenceData(null);
        assertDoesNotThrow(()->eventMapperSetup.setScoreInMap(resultReleasedNodeV1));
    }

    @Test
    void checkForsetAddress(){
        ResultDeliveryBookingNodeV1 resultDeliveryBookingNodeV1 = SQSEventBodySetup.setBookingNodeV1Address();
        assertDoesNotThrow(()->eventMapperSetup.setAddress(resultDeliveryBookingNodeV1));
    }

}
