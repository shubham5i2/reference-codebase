package com.ielts.cmds.integration.mapper;

import com.ielts.cmds.api.evt004.ResultDeliveryProductNodeV1;
import com.ielts.cmds.api.evt004.ResultReleasedNodeV1;
import com.ielts.cmds.integration.utils.SQSEventBodySetup;
import com.ielts.cmds.rd.lads.integration.model.MessageV1;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(MockitoExtension.class)
class EventMapperTest {

    @Spy
    @InjectMocks
    private EventMapper eventMapper;

    @Test
    void check_getNonEmptyString_returnNull() {
        String output = eventMapper.getNonEmptyString("");
        assertNull(output);
    }

    @Test
    void check_getNonEmptyString() {
        String output = eventMapper.getNonEmptyString("Hello");
        assertNotNull(output);
        assertEquals("Hello",output);
    }

    @Test
    void check_mapIncomingResultToLA_forSsr() {
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        resultReleasedNodeV1.getBookingDetails().setBookingLinks(SQSEventBodySetup.setBookingLinkNodeV1List());
        String presignUrl = "www.test.url";
        MessageV1 messageV1 = eventMapper.mapIncomingResultToLA(resultReleasedNodeV1, presignUrl);
        assertNotNull(messageV1);
        assertNotNull(messageV1.getMsg().get(0).getLinkedBookings());
        assertEquals("000100",messageV1.getMsg().get(0).getLinkedBookings().get(0).getLinkedBooking().getCandidateNumber());
    }

    @Test
    void check_setSSRBookingSpecificFields() {
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        resultReleasedNodeV1.getBookingDetails().setBookingLinks(SQSEventBodySetup.setBookingLinkNodeV1List());
        String presignUrl = "www.test.url";
        MessageV1 messageV1 = eventMapper.mapIncomingResultToLA(resultReleasedNodeV1, presignUrl);
        assertNotNull(messageV1);
        assertNotNull(messageV1.getMsg().get(0).getLinkedBookings());
        assertEquals("000100",messageV1.getMsg().get(0).getLinkedBookings().get(0).getLinkedBooking().getCandidateNumber());
    }

    @Test
    void check_mapIncomingResultToLA_ukvi_product() {
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        resultReleasedNodeV1.setProductDetails(new ResultDeliveryProductNodeV1());
        resultReleasedNodeV1.getProductDetails().setProductCharacteristics("{\"characteristics\": [\"IOL\", \"SELT\"],\"RoAutoAccepted\": [\"FALSE\"]}");
        String presignUrl = "www.test.url";
        MessageV1 messageV1 = eventMapper.mapIncomingResultToLA(resultReleasedNodeV1, presignUrl);
        assertNotNull(messageV1);
        assertEquals("1",messageV1.getMsg().get(0).getResultData().getSeltIndicator());
        assertEquals("f368fda0-149d-4ffd-8674-ff7396f4946f",messageV1.getMsg().get(0).getResultData().getLocationUuid().toString());
        assertEquals("e873fca7-849b-4e3b-8dfc-b6b5108619ab",messageV1.getMsg().get(0).getResultData().getTestCentreUuid().toString());
        assertNotNull(messageV1.getMsg().get(0).getResultData().getUkviERefId());
    }

    @Test
    void check_mapIncomingResultToLA_location_presentIn_locationDetails() {
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        resultReleasedNodeV1.getLocationDetails().add(SQSEventBodySetup.getLocationChangeNodeV1());
        String presignUrl = "www.test.url";
        MessageV1 messageV1 = eventMapper.mapIncomingResultToLA(resultReleasedNodeV1, presignUrl);
        assertNotNull(messageV1);
        assertNotNull(messageV1.getMsg().get(0).getResultData().getCentreNumber());
        assertEquals("0010",messageV1.getMsg().get(0).getResultData().getCentreNumber());
    }

    @Test
    void check_mapIncomingResultToLA_withTitle_and_names_Nul() {
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        resultReleasedNodeV1.getBookingDetails().setTitle(null);
        resultReleasedNodeV1.getBookingDetails().setFirstName(null);
        resultReleasedNodeV1.getBookingDetails().setLastName(null);
        String presignUrl = "www.test.url";
        MessageV1 messageV1 = eventMapper.mapIncomingResultToLA(resultReleasedNodeV1, presignUrl);
        assertNotNull(messageV1);
        assertNull(messageV1.getMsg().get(0).getResultData().getTitle());
        assertNull(messageV1.getMsg().get(0).getResultData().getFamilyName());
        assertNull(messageV1.getMsg().get(0).getResultData().getGivenName());
    }

    @Test
    void check_mapIncomingResultToLA_with_phone_email_city_postalCode_null() {
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        resultReleasedNodeV1.getBookingDetails().setPhone(null);
        resultReleasedNodeV1.getBookingDetails().setEmail(null);
        resultReleasedNodeV1.getBookingDetails().setCity(null);
        resultReleasedNodeV1.getBookingDetails().setPostalCode(null);
        String presignUrl = "www.test.url";
        MessageV1 messageV1 = eventMapper.mapIncomingResultToLA(resultReleasedNodeV1, presignUrl);
        assertNotNull(messageV1);
        assertNull(messageV1.getMsg().get(0).getResultData().getTelephone());
        assertNull(messageV1.getMsg().get(0).getResultData().getEmail());
        assertNull(messageV1.getMsg().get(0).getResultData().getTown());
        assertNull(messageV1.getMsg().get(0).getResultData().getPostcode());
    }

    @Test
    void check_mapIncomingResultToLA_with_empty_address_nullAgentName() {
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        resultReleasedNodeV1.setBookingDetails(SQSEventBodySetup.setEmptyAddressBookingNodeV1());
        resultReleasedNodeV1.getBookingDetails().setAgentName(null);
        String presignUrl = "www.test.url";
        MessageV1 messageV1 = eventMapper.mapIncomingResultToLA(resultReleasedNodeV1, presignUrl);
        assertNotNull(messageV1);
        assertNull(messageV1.getMsg().get(0).getResultData().getAddress());
        assertNull(messageV1.getMsg().get(0).getResultData().getAgentRepName());
    }

    @Test
    void check_mapIncomingResultToLA_ssr_no_active_bookingLines() {
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        resultReleasedNodeV1.getBookingDetails().getBookingLines().get(0).setBookingLineStatus("INACTIVE");
        String presignUrl = "www.test.url";
        MessageV1 messageV1 = eventMapper.mapIncomingResultToLA(resultReleasedNodeV1, presignUrl);
        assertNotNull(messageV1);
        assertNull(messageV1.getMsg().get(0).getResultData().getSsrProductUuid());
    }

    @Test
    void check_mapIncomingResultToLA_ssr_location_presentIn_locationDetails() {
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        resultReleasedNodeV1.getBookingDetails().setBookingLinks(SQSEventBodySetup.setBookingLinkNodeV1List());
        resultReleasedNodeV1.getLocationDetails().add(SQSEventBodySetup.getLocationChangeNodeV1());
        String presignUrl = "www.test.url";
        MessageV1 messageV1 = eventMapper.mapIncomingResultToLA(resultReleasedNodeV1, presignUrl);
        assertNotNull(messageV1);
        assertNotNull(messageV1.getMsg().get(0).getResultData().getCentreNumber());
        assertNotNull(messageV1.getMsg().get(0).getLinkedBookings().get(0).getLinkedBooking());
    }

}
