package com.ielts.cmds.integration.service;

import static com.ielts.cmds.integration.constants.ReceiverConstants.MARKS_FILE_DETAILS_PUBLISHED;
import com.ielts.cmds.api.common.ca_client.CARequestNodeV1;
import com.ielts.cmds.api.evt176.MarksFileDetailsV1;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;

public class MarksFileDetailsPublishService implements IReceiverService<CARequestNodeV1, MarksFileDetailsV1> {

	@Override
	public MarksFileDetailsV1 process(CARequestNodeV1 caRequestNode) {
		final MarksFileDetailsV1 marksFileDetails = new MarksFileDetailsV1();
		marksFileDetails.setFileName(caRequestNode.getFileName());
		marksFileDetails.setPresignedUrl(caRequestNode.getPresignedUrl());
		return marksFileDetails;
	}

	@Override
	public String getOutgoingEventName() {
		return MARKS_FILE_DETAILS_PUBLISHED;
	}

}
