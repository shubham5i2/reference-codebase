package com.ielts.cmds.integration.constants;

public class ReceiverConstants {
  private ReceiverConstants() {}

  public static final String LDS_EXT_TOPIC_IN_ARN = "lds_ext_topic_in_arn";
  public static final String REGRESSION_STATS_AVAILABLE_ENDPOINT = "POST/v1/regressionstatsavailable";
  public static final String REGRESSION_STATS_FILE_DETAILS_PUBLISHED = "RegressionStatsFileDetailsPublished";
  public static final String MARKS_FILE_DETAILS_PUBLISHED = "MarksFileDetailsPublished";
  public static final String MARKS_FILE_DETAILS_PUBLISHED_ENDPOINT = "POST/v1/cdmarksavailable";

}
