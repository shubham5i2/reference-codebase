package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.constants.ReceiverConstants.LDS_EXT_TOPIC_IN_ARN;
import static com.ielts.cmds.integration.constants.ReceiverConstants.MARKS_FILE_DETAILS_PUBLISHED_ENDPOINT;
import static com.ielts.cmds.integration.constants.ReceiverConstants.REGRESSION_STATS_AVAILABLE_ENDPOINT;

import java.util.HashMap;
import java.util.Map;

import com.ielts.cmds.integration.factory.ReceiverServiceFactory;
import com.ielts.cmds.integration.service.MarksFileDetailsPublishService;
import com.ielts.cmds.integration.service.RegressionStatsFileDetailsPublishService;
import com.ielts.cmds.serialization.lambda.AbstractReceiverLambda;
import com.ielts.cmds.serialization.lambda.mapper.IObjectMapper;
import com.ielts.cmds.serialization.lambda.receiver.service.AbstractServiceFactory;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LDSExtReceiver extends AbstractReceiverLambda implements IObjectMapper {

	@Override
	public AbstractServiceFactory getServiceFactory() {
		@SuppressWarnings("rawtypes")
		final Map<String, IReceiverService> initServices = new HashMap<>();
		initServices.put(MARKS_FILE_DETAILS_PUBLISHED_ENDPOINT, new MarksFileDetailsPublishService());
		initServices.put(REGRESSION_STATS_AVAILABLE_ENDPOINT, new RegressionStatsFileDetailsPublishService());
		return new ReceiverServiceFactory(initServices);
	}

	@Override
	public String getTopicArn() {
		return System.getenv(LDS_EXT_TOPIC_IN_ARN);
	}

	@Override
	protected <O> void publishToTopic(O event) {
		log.debug("Overriding the behaviour. Not publishing to lds_ext_topic_in");
	}

}

