package com.ielts.cmds.integration.service;

import static com.ielts.cmds.integration.constants.ReceiverConstants.REGRESSION_STATS_FILE_DETAILS_PUBLISHED;

import com.ielts.cmds.api.common.ca_client.CountryRegressionStatsNotificationDetailsV1;
import com.ielts.cmds.api.evt177.RegressionStatsFileDetailsPublishedV1;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;

public class RegressionStatsFileDetailsPublishService implements 
		IReceiverService<CountryRegressionStatsNotificationDetailsV1, RegressionStatsFileDetailsPublishedV1> {

	@Override
	public RegressionStatsFileDetailsPublishedV1 process(CountryRegressionStatsNotificationDetailsV1 regressionStatsNotificationDetails) {
		final RegressionStatsFileDetailsPublishedV1 regressionStatsFileDetailsPublished = 
				new RegressionStatsFileDetailsPublishedV1();
		regressionStatsFileDetailsPublished.setFileName(regressionStatsNotificationDetails.getFileName());
		regressionStatsFileDetailsPublished.setPresignedUrl(regressionStatsNotificationDetails.getPresignedUrl());
		return regressionStatsFileDetailsPublished;
	}
	
	@Override
	public String getOutgoingEventName() {
		return REGRESSION_STATS_FILE_DETAILS_PUBLISHED;
	}

}
