package com.ielts.cmds.integration.testdata;

import com.ielts.cmds.api.common.ca_client.CountryRegressionStatsNotificationDetailsV1;
import com.ielts.cmds.api.evt177.RegressionStatsFileDetailsPublishedV1;

public class RegressionStatsFileDetailsPublishTestData {
	
	public static RegressionStatsFileDetailsPublishedV1 getRegressionStatsFileDetailsPublished() {
		final RegressionStatsFileDetailsPublishedV1 regressionStatsFileDetailsPublished = 
				new RegressionStatsFileDetailsPublishedV1();
		regressionStatsFileDetailsPublished.setFileName("filename");
		regressionStatsFileDetailsPublished.setFileName("www.testurl.com");
		return regressionStatsFileDetailsPublished;
	}
	
	public static CountryRegressionStatsNotificationDetailsV1 getCountryRegressionStatsNotificationDetails() {
		final CountryRegressionStatsNotificationDetailsV1 countryRegressionStatsNotificationDetailsV1 = 
				new CountryRegressionStatsNotificationDetailsV1();
		countryRegressionStatsNotificationDetailsV1.setFileName("filename");
		countryRegressionStatsNotificationDetailsV1.setFileName("www.testurl.com");
		return countryRegressionStatsNotificationDetailsV1;
	}

}
