package com.ielts.cmds.integration.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.integration.testdata.RegressionStatsFileDetailsPublishTestData;

@ExtendWith(MockitoExtension.class)
class RegressionStatsFileDetailsPublishServiceTest {

	@InjectMocks private RegressionStatsFileDetailsPublishService regressionStatsFileDetailsPublishService;

	@Test
	void whenCallingProcess_ExpectObject() {
		assertEquals(RegressionStatsFileDetailsPublishTestData.getRegressionStatsFileDetailsPublished(), 
				regressionStatsFileDetailsPublishService.process(
						RegressionStatsFileDetailsPublishTestData.getCountryRegressionStatsNotificationDetails()));
	}

	@Test
	void whenCallingGetOutgoingEventName_ExpectMarksFileDetailsPublished() {
		assertEquals("RegressionStatsFileDetailsPublished", regressionStatsFileDetailsPublishService.getOutgoingEventName());
	}

}
