package com.ielts.cmds.integration.testdata;

import com.ielts.cmds.api.common.ca_client.CARequestNodeV1;
import com.ielts.cmds.api.evt176.MarksFileDetailsV1;

public class MarksFileDetailsPublishTestData {
	
	public static MarksFileDetailsV1 getMarksFileDetails() {
		final MarksFileDetailsV1 marksFileDetails = new MarksFileDetailsV1();
		marksFileDetails.setFileName("filename");
		marksFileDetails.setFileName("www.testurl.com");
		return marksFileDetails;
	}
	
	public static CARequestNodeV1 getCaRequestNode() {
		final CARequestNodeV1 caRequestNodeV1 = new CARequestNodeV1();
		caRequestNodeV1.setFileName("filename");
		caRequestNodeV1.setFileName("www.testurl.com");
		return caRequestNodeV1;
	}
}
