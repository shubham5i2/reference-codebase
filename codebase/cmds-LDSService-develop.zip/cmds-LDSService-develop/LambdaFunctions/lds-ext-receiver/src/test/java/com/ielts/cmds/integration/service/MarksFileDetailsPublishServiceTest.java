package com.ielts.cmds.integration.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.integration.testdata.MarksFileDetailsPublishTestData;

@ExtendWith(MockitoExtension.class)
class MarksFileDetailsPublishServiceTest {
	
	@InjectMocks private MarksFileDetailsPublishService marksFileDetailsPublishService;
	
	@Test
	void whenCallingProcess_ExpectObject() {
		assertEquals(MarksFileDetailsPublishTestData.getMarksFileDetails(), 
				marksFileDetailsPublishService.process(MarksFileDetailsPublishTestData.getCaRequestNode()));
	}
	
	@Test
	void whenCallingGetOutgoingEventName_ExpectMarksFileDetailsPublished() {
		assertEquals("MarksFileDetailsPublished", marksFileDetailsPublishService.getOutgoingEventName());
	}

	
}
