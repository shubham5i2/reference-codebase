package com.ielts.cmds.integration;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.api.evt176.MarksFileDetailsV1;
import com.ielts.cmds.integration.factory.ReceiverServiceFactory;

import uk.org.webcompere.systemstubs.environment.EnvironmentVariables;
import uk.org.webcompere.systemstubs.jupiter.SystemStub;
import uk.org.webcompere.systemstubs.jupiter.SystemStubsExtension;

@ExtendWith(SystemStubsExtension.class)
@ExtendWith(MockitoExtension.class)
class LDSExtReceiverTest {
	
	@SystemStub
	private EnvironmentVariables environmentVariables;
	
	@Mock
	private LDSExtReceiver ldsExtReceiver;

	@BeforeEach
	void setUp() {
		ldsExtReceiver = Mockito.spy(ldsExtReceiver);
	}


	@Test
	void whenCallingGetTopicArn_thenReturnTopicArn() {
		String expectedTopicUrl = "lds-topic";
		environmentVariables.set("lds_ext_topic_in_arn", "lds-topic");
		assertEquals(expectedTopicUrl, ldsExtReceiver.getTopicArn());
	}
	
	@Test
	void whenCallingPublishToTopic_ExpectNoMethodInvocation() {
		final MarksFileDetailsV1 event = new MarksFileDetailsV1();
		assertDoesNotThrow(()->ldsExtReceiver.publishToTopic(event));
		verify(ldsExtReceiver, times(1)).publishToTopic(event);
		verifyNoMoreInteractions(ldsExtReceiver);
	}
	
	@Test
	void whenCallingGetServiceFactory_ExpectServiceFactoryInstance() {
		assertTrue(ldsExtReceiver.getServiceFactory() instanceof ReceiverServiceFactory);
	}

	
	

}
