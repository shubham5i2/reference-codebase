package com.ielts.cmds.integration.presign;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;

import java.net.URL;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import software.amazon.awssdk.services.s3.presigner.S3Presigner;
import software.amazon.awssdk.services.s3.presigner.model.GetObjectPresignRequest;
import software.amazon.awssdk.services.s3.presigner.model.PresignedGetObjectRequest;

@ExtendWith(MockitoExtension.class)
class PresignUrlTest {
	
	@Mock private S3Presigner presigner;
	
	@Mock private URL url;
	
	@Mock private PresignedGetObjectRequest presignedGetObjectRequest;
	
	@InjectMocks private PresignUrl presignUrl;
	
	
	@Test
	void handlePresign_ExpectPresignedUrl() {
		
		doReturn(presignedGetObjectRequest)
		.when(presigner)
		.presignGetObject(any(GetObjectPresignRequest.class));
		doReturn(url)
		.when(presignedGetObjectRequest)
		.url();
		doReturn("www.test.org")
		.when(url)
		.toString();
		final String actual = presignUrl.handlePresign(presigner, "20", "test-bucket", "test.jpeg");
		assertEquals("www.test.org", actual);
		
	}

}
