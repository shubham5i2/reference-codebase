package com.ielts.cmds.integration.mapper;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.integration.testdata.LdsPhotosTestDataSetup;
import com.ielts.cmds.testtaker.common.events.model.PhotoPublishedV1;

@ExtendWith(MockitoExtension.class)
class EventMapperTest {
	
	@Spy @InjectMocks private EventMapper eventMapper;
	
	@Test
	void mapRequestToLa_ExpectRequestToBeMapped() {
		final String presignedUrl = "www.url.presign.test";
		final PhotoPublishedV1 photoPublishedV1 = LdsPhotosTestDataSetup.getPhotoPublishedV1();
		final com.ielts.cmds.integration.mapper.model.PhotoPublishedV1 photoBody = LdsPhotosTestDataSetup.getPhotoPublishedAPIBody();
		photoBody.getPhotoDetails().setPhotoPath(presignedUrl);
		final com.ielts.cmds.integration.mapper.model.PhotoPublishedV1 actual = eventMapper.mapRequestToLa(photoPublishedV1, presignedUrl);
		assertEquals(photoBody, actual);
	}

}
