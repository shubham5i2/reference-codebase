package com.ielts.cmds.integration;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import java.security.KeyStoreException;
import java.security.cert.CertificateException;
import java.util.UUID;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.sns.AmazonSNS;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.constants.LADSConstants;
import com.ielts.cmds.integration.exception.LdsDistClientException;
import com.ielts.cmds.integration.exception.LdsDistException;
import com.ielts.cmds.integration.mapper.EventMapper;
import com.ielts.cmds.integration.presign.PresignUrl;
import com.ielts.cmds.integration.testdata.LdsPhotosTestDataSetup;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.exception.InvalidClientException;
import com.ielts.cmds.security.exception.TokenNotReceivedException;
import com.ielts.cmds.security.factory.AuthenticationClientFactory;
import com.ielts.cmds.serialization.lambda.config.SNSClientConfig;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import com.ielts.cmds.testtaker.common.events.model.PhotoPublishedV1;

import software.amazon.awssdk.services.s3.presigner.S3Presigner;

@ExtendWith(MockitoExtension.class)
class LdsPhotosDistLaTest {

	@Mock private AuthenticationClientFactory securityAuthenticationFactory;
	private String laEndpointUrl = "www.la.url";
	private String ttPhotoBucket = "test-bucket";
	private String timeout = "60480";
	@Mock private AmazonS3 s3Client;
	@Mock private AmazonSNS snsClient;
	
	private static MockedStatic<S3Config> s3ClientConfig;
	private static MockedStatic	<SNSClientConfig> snsClientConfig;
	@Mock private S3Presigner presigner;
	@Mock private PresignUrl presignUrl;
	@Mock private EventMapper eventMapper;
	@Mock private AuthenticationClient authenticationClient;
	@Mock private RestTemplate restTemplate;
	@Mock private HttpHeaders httpHeaders;
    @Spy @InjectMocks private LdsPhotosDistLa ldsPhotosDistLa;
    
    @BeforeAll
    static void init() {
    	s3ClientConfig  = Mockito.mockStatic(S3Config.class);
    	snsClientConfig = Mockito.mockStatic(SNSClientConfig.class);
    }
    
    @AfterAll
    static void close() {
    	s3ClientConfig.close();
    	snsClientConfig.close();
    }
    
    @BeforeEach
    void setup() {
    	s3ClientConfig.when(S3Config::s3Client).thenReturn(s3Client);
    	s3ClientConfig.when(S3Config::s3Presigner).thenReturn(presigner);
    	snsClientConfig.when(SNSClientConfig::getSNSClient).thenReturn(snsClient);
    	ReflectionTestUtils.setField(ldsPhotosDistLa, "securityAuthenticationFactory", securityAuthenticationFactory);
    	ReflectionTestUtils.setField(ldsPhotosDistLa, "laEndpointUrl", laEndpointUrl);
    	ReflectionTestUtils.setField(ldsPhotosDistLa, "ttPhotoBucket", ttPhotoBucket);
    	ReflectionTestUtils.setField(ldsPhotosDistLa, "timeout", timeout);
    	ReflectionTestUtils.setField(ldsPhotosDistLa, "s3Client", s3Client);
    	ReflectionTestUtils.setField(ldsPhotosDistLa, "presigner", presigner);
    	ReflectionTestUtils.setField(ldsPhotosDistLa, "presignUrl", presignUrl);
    	ReflectionTestUtils.setField(ldsPhotosDistLa, "eventMapper", eventMapper);
    }
    
    @Test
    void getTopicName_ExpectNull() {
    	assertNull(ldsPhotosDistLa.getTopicName());
    }
    
    @Test
    void processRequest_ExpectNull() {
    	final PhotoPublishedV1 photoPublished = LdsPhotosTestDataSetup.getPhotoPublishedV1();
    	final com.ielts.cmds.integration.mapper.model.PhotoPublishedV1 photoBody = LdsPhotosTestDataSetup.getPhotoPublishedAPIBody();
    	final String presignedUrl = "www.test.org";
    	doReturn(presignedUrl).when(ldsPhotosDistLa).getPresignedUrl(photoPublished.getPhotoPath());
    	doReturn(photoBody).when(eventMapper).mapRequestToLa(photoPublished, presignedUrl);
    	doReturn(new ResponseEntity<>(HttpStatus.OK)).when(ldsPhotosDistLa).postRequestToLa(photoBody);
    	assertNull(ldsPhotosDistLa.processRequest(photoPublished));
    }
    
    @Test
    void processRequestWithLdsDistClientException_ExpectNull() {
    	final PhotoPublishedV1 photoPublished = LdsPhotosTestDataSetup.getPhotoPublishedV1();
    	final com.ielts.cmds.integration.mapper.model.PhotoPublishedV1 photoBody = LdsPhotosTestDataSetup.getPhotoPublishedAPIBody();
    	final String presignedUrl = "www.test.org";
    	doReturn(presignedUrl).when(ldsPhotosDistLa).getPresignedUrl(photoPublished.getPhotoPath());
    	doReturn(photoBody).when(eventMapper).mapRequestToLa(photoPublished, presignedUrl);
    	doThrow(LdsDistClientException.class).when(ldsPhotosDistLa).postRequestToLa(photoBody);
    	assertNull(ldsPhotosDistLa.processRequest(photoPublished));
    }
    
    @Test
    void processRequestWithHttpClientException_ExpectNull() {
    	final PhotoPublishedV1 photoPublished = LdsPhotosTestDataSetup.getPhotoPublishedV1();
    	final com.ielts.cmds.integration.mapper.model.PhotoPublishedV1 photoBody = LdsPhotosTestDataSetup.getPhotoPublishedAPIBody();
    	final String presignedUrl = "www.test.org";
    	doReturn(presignedUrl).when(ldsPhotosDistLa).getPresignedUrl(photoPublished.getPhotoPath());
    	doReturn(photoBody).when(eventMapper).mapRequestToLa(photoPublished, presignedUrl);
    	doThrow(HttpClientErrorException.class).when(ldsPhotosDistLa).postRequestToLa(photoBody);
    	assertNull(ldsPhotosDistLa.processRequest(photoPublished));
    }
    
    @Test
    void processRequestWithHttpServerException_ExpectException() {
    	final PhotoPublishedV1 photoPublished = LdsPhotosTestDataSetup.getPhotoPublishedV1();
    	final com.ielts.cmds.integration.mapper.model.PhotoPublishedV1 photoBody = LdsPhotosTestDataSetup.getPhotoPublishedAPIBody();
    	final String presignedUrl = "www.test.org";
    	doReturn(presignedUrl).when(ldsPhotosDistLa).getPresignedUrl(photoPublished.getPhotoPath());
    	doReturn(photoBody).when(eventMapper).mapRequestToLa(photoPublished, presignedUrl);
    	doThrow(HttpServerErrorException.class).when(ldsPhotosDistLa).postRequestToLa(photoBody);
    	assertThrows(LdsDistException.class, ()->ldsPhotosDistLa.processRequest(photoPublished));
    }
    
    @Test
    void getPresignedUrlBucketDoesNotExist_ExpectClientException() {
    	doReturn(false).when(s3Client).doesBucketExistV2(ttPhotoBucket);
    	assertThrows(LdsDistClientException.class, ()->ldsPhotosDistLa.getPresignedUrl("somepath.jpeg"));
    }
    
    @Test
    void getPresignedUrlObjectDoesNotExist_ExpectClientException() {
    	doReturn(true).when(s3Client).doesBucketExistV2(ttPhotoBucket);
    	doReturn(false).when(s3Client).doesObjectExist(ttPhotoBucket, "path.jpeg");
    	assertThrows(LdsDistClientException.class, ()->ldsPhotosDistLa.getPresignedUrl("path.jpeg"));
    }
    
    @Test
    void getPresignedUrl_ExpectPresignedUrl() {
    	doReturn(true).when(s3Client).doesBucketExistV2(ttPhotoBucket);
    	doReturn(true).when(s3Client).doesObjectExist(ttPhotoBucket, "some.jpeg");
    	doReturn("www.test.url").when(presignUrl).handlePresign(presigner, timeout, ttPhotoBucket, "some.jpeg");
    	assertEquals("www.test.url",ldsPhotosDistLa.getPresignedUrl("some.jpeg"));
    }
    
    @Test
    void postRequestToLa_ExpectOkStatus() 
    		throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException, InvalidClientException {
    	final com.ielts.cmds.integration.mapper.model.PhotoPublishedV1 photoBody = LdsPhotosTestDataSetup.getPhotoPublishedAPIBody();
    	doReturn(authenticationClient).when(ldsPhotosDistLa).getAuthenticationClient();
    	doReturn(httpHeaders).when(ldsPhotosDistLa).getHttpHeaders(authenticationClient);
    	doReturn(restTemplate).when(authenticationClient).getRestTemplate();
    	doReturn(new ResponseEntity<>(HttpStatus.OK)).when(restTemplate)
    	.postForEntity(eq(laEndpointUrl), any(HttpEntity.class), eq(String.class));
    	final ResponseEntity<String> actual = ldsPhotosDistLa.postRequestToLa(photoBody);
    	assertEquals(HttpStatus.OK, actual.getStatusCode());
    }
    
    @Test
    void postRequestToLaInvalidClientException_ExpectLDSDistClientException() 
    		throws JsonProcessingException, CertificateException, KeyStoreException, 
    		TokenNotReceivedException, InvalidClientException {
    	final com.ielts.cmds.integration.mapper.model.PhotoPublishedV1 photoBody = LdsPhotosTestDataSetup.getPhotoPublishedAPIBody();
    	doThrow(InvalidClientException.class).when(ldsPhotosDistLa).getAuthenticationClient();
    	assertThrows(LdsDistClientException.class, () -> ldsPhotosDistLa.postRequestToLa(photoBody));
    }
    
    @Test
    void postRequestToLaCertificateException_ExpectLDSDistClientException() 
    		throws JsonProcessingException, CertificateException, KeyStoreException, 
    		TokenNotReceivedException, InvalidClientException {
    	final com.ielts.cmds.integration.mapper.model.PhotoPublishedV1 photoBody = LdsPhotosTestDataSetup.getPhotoPublishedAPIBody();
    	doThrow(CertificateException.class).when(ldsPhotosDistLa).getAuthenticationClient();
    	assertThrows(LdsDistClientException.class, () -> ldsPhotosDistLa.postRequestToLa(photoBody));
    }
    
    @Test
    void postRequestToLaKeystoreException_ExpectLDSDistClientException()  
    		throws JsonProcessingException, CertificateException, KeyStoreException, 
    		TokenNotReceivedException, InvalidClientException {
 
    	final com.ielts.cmds.integration.mapper.model.PhotoPublishedV1 photoBody = LdsPhotosTestDataSetup.getPhotoPublishedAPIBody();
    	doThrow(KeyStoreException.class).when(ldsPhotosDistLa).getAuthenticationClient();
    	assertThrows(LdsDistClientException.class, () -> ldsPhotosDistLa.postRequestToLa(photoBody));
    }
    
    @Test
    void postRequestToLaTokenNotReceivedException_ExpectLDSDistClientException() 
    		throws JsonProcessingException, CertificateException, KeyStoreException, 
    		TokenNotReceivedException, InvalidClientException {
    	final com.ielts.cmds.integration.mapper.model.PhotoPublishedV1 photoBody = LdsPhotosTestDataSetup.getPhotoPublishedAPIBody();
    	doReturn(authenticationClient).when(ldsPhotosDistLa).getAuthenticationClient();
    	doThrow(TokenNotReceivedException.class).when(ldsPhotosDistLa).getHttpHeaders(authenticationClient);
    	assertThrows(LdsDistClientException.class, () -> ldsPhotosDistLa.postRequestToLa(photoBody));
    }
    
    @Test
    void postRequestToLaJsonProcessingException_ExpectLDSDistClientException() 
    		throws JsonProcessingException, CertificateException, KeyStoreException, 
    		TokenNotReceivedException, InvalidClientException {
    	final com.ielts.cmds.integration.mapper.model.PhotoPublishedV1 photoBody = LdsPhotosTestDataSetup.getPhotoPublishedAPIBody();
    	doReturn(authenticationClient).when(ldsPhotosDistLa).getAuthenticationClient();
    	doThrow(JsonProcessingException.class).when(ldsPhotosDistLa).getHttpHeaders(authenticationClient);
    	assertThrows(LdsDistClientException.class, () -> ldsPhotosDistLa.postRequestToLa(photoBody));
    }
    
    @Test
    void postRequestToLaClientException_ExpectClientException() 
    		throws JsonProcessingException, CertificateException, KeyStoreException, 
    		TokenNotReceivedException, InvalidClientException {
    	final com.ielts.cmds.integration.mapper.model.PhotoPublishedV1 photoBody = LdsPhotosTestDataSetup.getPhotoPublishedAPIBody();
    	doReturn(authenticationClient).when(ldsPhotosDistLa).getAuthenticationClient();
    	doReturn(httpHeaders).when(ldsPhotosDistLa).getHttpHeaders(authenticationClient);
    	doReturn(restTemplate).when(authenticationClient).getRestTemplate();
    	doThrow(HttpClientErrorException.class).when(restTemplate)
    	.postForEntity(eq(laEndpointUrl), any(HttpEntity.class), eq(String.class));
    	assertThrows(HttpClientErrorException.class, () -> ldsPhotosDistLa.postRequestToLa(photoBody));
    }
    
    @Test
    void postRequestToLaServerException_ExpectServerException() 
    		throws JsonProcessingException, CertificateException, KeyStoreException, 
    		TokenNotReceivedException, InvalidClientException {
    	final com.ielts.cmds.integration.mapper.model.PhotoPublishedV1 photoBody = LdsPhotosTestDataSetup.getPhotoPublishedAPIBody();
    	doReturn(authenticationClient).when(ldsPhotosDistLa).getAuthenticationClient();
    	doReturn(httpHeaders).when(ldsPhotosDistLa).getHttpHeaders(authenticationClient);
    	doReturn(restTemplate).when(authenticationClient).getRestTemplate();
    	doThrow(HttpServerErrorException.class).when(restTemplate)
    	.postForEntity(eq(laEndpointUrl), any(HttpEntity.class), eq(String.class));
    	assertThrows(HttpServerErrorException.class, () -> ldsPhotosDistLa.postRequestToLa(photoBody));
    }
    
    @Test
    void getHttpHeaders_ExpectHeaders() 
    		throws JsonProcessingException, CertificateException, KeyStoreException, 
    		TokenNotReceivedException, InvalidClientException {
    	final HeaderContext cmdsHeaderContext = new HeaderContext();
    	cmdsHeaderContext.setTransactionId(UUID.randomUUID());
    	cmdsHeaderContext.setCorrelationId(UUID.randomUUID());
    	ThreadLocalHeaderContext.setContext(cmdsHeaderContext);
    	doReturn("Authentication").when(authenticationClient).getAuthorizationHeaderName();
    	doReturn("abc").when(authenticationClient).getAccessToken();
    	final HttpHeaders actual = ldsPhotosDistLa.getHttpHeaders(authenticationClient);
    	assertEquals("abc", actual.get("Authentication").get(0));
    	assertEquals(MediaType.APPLICATION_JSON, actual.getContentType());
    	assertEquals(cmdsHeaderContext.getCorrelationId().toString(), actual.get("correlationId").get(0));
    	assertEquals(cmdsHeaderContext.getTransactionId().toString(), actual.get("transactionId").get(0));
    	assertEquals("CA", actual.get("partnerCode").get(0));
    }
    
    @Test
    void getAuthenticationClient_ExpectAuthClientObject() 
    		throws JsonProcessingException, CertificateException, KeyStoreException, 
    		TokenNotReceivedException, InvalidClientException {
    	doReturn(authenticationClient).when(securityAuthenticationFactory).getAuthenticationClient(LADSConstants.CA);
    	assertEquals(authenticationClient, ldsPhotosDistLa.getAuthenticationClient());
    }
}
