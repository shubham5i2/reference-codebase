package com.ielts.cmds.integration.testdata;

import java.security.cert.Certificate;
import java.util.UUID;

import com.ielts.cmds.testtaker.common.events.model.PhotoCategoryEnum;
import com.ielts.cmds.testtaker.common.events.model.PhotoPublishedV1;

public class LdsPhotosTestDataSetup {

	public static PhotoPublishedV1 getPhotoPublishedV1() {
		final PhotoPublishedV1 photoPublishedV1 = new PhotoPublishedV1();
		photoPublishedV1.setBookingUuid(UUID.fromString("fc5d683e-c330-404f-a182-7a0be7d76c67"));
		photoPublishedV1.setCompositeCandidateNumber("AV10199");
		photoPublishedV1.setPhotoCategory(PhotoCategoryEnum.Certificate);
		photoPublishedV1.setPhotoPath("photo.jpeg");
		photoPublishedV1.setPhotoTypeUuid(UUID.fromString("ea1fb78f-889a-4d04-a6d2-6e90ff27754c"));
		photoPublishedV1.setPhotoUuid(UUID.fromString("9f9a6e21-a6b6-48c6-9fb6-cd6676ac3545"));
		photoPublishedV1.setPhotoVersion(2);
		return photoPublishedV1;
	}
	
	public static com.ielts.cmds.integration.mapper.model.PhotoPublishedV1 getPhotoPublishedAPIBody() {
		final com.ielts.cmds.integration.mapper.model.PhotoPublishedV1 photoPublished = new com.ielts.cmds.integration.mapper.model.PhotoPublishedV1();
		final com.ielts.cmds.integration.mapper.model.PhotoPublishedV1PhotoDetails photoPublishedDetails = new com.ielts.cmds.integration.mapper.model.PhotoPublishedV1PhotoDetails();
		photoPublishedDetails.setBookingUuid(UUID.fromString("fc5d683e-c330-404f-a182-7a0be7d76c67"));
		photoPublishedDetails.setCompositeCandidateNumber("AV10199");
		photoPublishedDetails.setPhotoCategory("Certificate");
		photoPublishedDetails.setPhotoPath("photo.jpeg");
		photoPublishedDetails.setPhotoTypeUuid(UUID.fromString("ea1fb78f-889a-4d04-a6d2-6e90ff27754c"));
		photoPublishedDetails.setPhotoUuid(UUID.fromString("9f9a6e21-a6b6-48c6-9fb6-cd6676ac3545"));
		photoPublishedDetails.setPhotoVersion(2);
		photoPublished.setPhotoDetails(photoPublishedDetails);
		return photoPublished;
	}
}
