package com.ielts.cmds.integration.mapper.model;

import com.google.gson.annotations.SerializedName;
import java.util.UUID;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/** PhotoPublishedV1PhotoDetails */
@Data
@EqualsAndHashCode
@ToString
public class PhotoPublishedV1PhotoDetails {
  @SerializedName("photoUuid")
  private UUID photoUuid = null;

  @SerializedName("bookingUuid")
  private UUID bookingUuid = null;

  @SerializedName("compositeCandidateNumber")
  private String compositeCandidateNumber = null;

  @SerializedName("photoTypeUuid")
  private UUID photoTypeUuid = null;

  @SerializedName("photoVersion")
  private Integer photoVersion = null;

  @SerializedName("photoPath")
  private String photoPath = null;

  @SerializedName("photoCategory")
  private String photoCategory = null;
}
