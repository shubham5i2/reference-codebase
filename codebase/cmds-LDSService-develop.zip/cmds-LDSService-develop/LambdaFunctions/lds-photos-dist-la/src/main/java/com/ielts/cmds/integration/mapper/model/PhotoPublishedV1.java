package com.ielts.cmds.integration.mapper.model;

import com.google.gson.annotations.SerializedName;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/** Details of the Test taker Photo */
@Data
@ToString
@EqualsAndHashCode
public class PhotoPublishedV1 {
  @SerializedName("photoDetails")
  private PhotoPublishedV1PhotoDetails photoDetails = null;
}
