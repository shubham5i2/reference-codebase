package com.ielts.cmds.integration;

import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.ielts.cmds.integration.constants.LADSConstants;

import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.presigner.S3Presigner;

public class S3Config {

	private S3Config(){

	}
	
	public static AmazonS3 s3Client() {
		return AmazonS3ClientBuilder.standard()
                .withCredentials(new DefaultAWSCredentialsProviderChain())
                .withRegion(System.getenv(LADSConstants.REGION))
                .build();
	}
	
	public static S3Presigner s3Presigner() {
		return S3Presigner.builder()
                .region(Region.of(System.getenv(LADSConstants.REGION)))
                .build();
	}

}
