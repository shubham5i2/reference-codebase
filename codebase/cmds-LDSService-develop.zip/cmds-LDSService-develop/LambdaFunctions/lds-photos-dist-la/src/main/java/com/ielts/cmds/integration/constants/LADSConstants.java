package com.ielts.cmds.integration.constants;

public class LADSConstants {

    private LADSConstants() {}

    public static final String TRANSACTIONID = "transactionId";
    public static final String CORRELATIONID = "correlationId";
    public static final String PARTNER_CODE = "partnerCode";
    public static final String CA = "CA";
    public static final String LA_ENDPOINT_URL = "endpoint_url";
    public static final String TESTTAKER_BUCKET = "s3_bucket";
    public static final String URLTIMEOUT ="presigned_url_timeout_second";
    public static final String REGION = "AWS_REGION";

}
