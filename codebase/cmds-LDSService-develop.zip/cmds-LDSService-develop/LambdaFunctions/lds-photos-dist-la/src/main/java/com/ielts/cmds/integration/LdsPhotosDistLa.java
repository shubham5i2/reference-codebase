package com.ielts.cmds.integration;


import static com.ielts.cmds.integration.constants.LADSConstants.CORRELATIONID;
import static com.ielts.cmds.integration.constants.LADSConstants.LA_ENDPOINT_URL;
import static com.ielts.cmds.integration.constants.LADSConstants.PARTNER_CODE;
import static com.ielts.cmds.integration.constants.LADSConstants.TESTTAKER_BUCKET;
import static com.ielts.cmds.integration.constants.LADSConstants.TRANSACTIONID;
import static com.ielts.cmds.integration.constants.LADSConstants.URLTIMEOUT;
import static java.lang.String.format;

import java.security.KeyStoreException;
import java.security.cert.CertificateException;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import com.amazonaws.services.s3.AmazonS3;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.constants.LADSConstants;
import com.ielts.cmds.integration.exception.LdsDistClientException;
import com.ielts.cmds.integration.exception.LdsDistException;
import com.ielts.cmds.integration.mapper.EventMapper;
import com.ielts.cmds.integration.presign.PresignUrl;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.exception.InvalidClientException;
import com.ielts.cmds.security.exception.TokenNotReceivedException;
import com.ielts.cmds.security.factory.AuthenticationClientFactory;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;
import com.ielts.cmds.serialization.lambda.AbstractLambda;
import com.ielts.cmds.serialization.lambda.config.DisablePublishToTopic;
import com.ielts.cmds.serialization.lambda.config.ExternalOutputType;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import com.ielts.cmds.testtaker.common.events.model.PhotoPublishedV1;

import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.services.s3.presigner.S3Presigner;

/**
 * This class serves the purpose of handling Delivery of photos to Legacy Adapter.
 */
@Slf4j
@DisablePublishToTopic
public class LdsPhotosDistLa extends AbstractLambda<PhotoPublishedV1, ExternalOutputType> {

    private final AuthenticationClientFactory securityAuthenticationFactory;
    private final String laEndpointUrl;
    private final String ttPhotoBucket;
    private final String timeout;
    private final AmazonS3 s3Client;
    private final S3Presigner presigner;
    private final PresignUrl presignUrl;
    private final EventMapper eventMapper;

    public LdsPhotosDistLa() {
        this.securityAuthenticationFactory = new EnvironmentAwareAuthenticationClientFactory();
        this.laEndpointUrl = System.getenv(LA_ENDPOINT_URL);
        this.ttPhotoBucket = System.getenv(TESTTAKER_BUCKET);
        this.timeout = System.getenv(URLTIMEOUT);
        this.s3Client =  S3Config.s3Client();
        this.presignUrl = new PresignUrl();
        this.eventMapper = new EventMapper();
        this.presigner = S3Config.s3Presigner();

    }

    @Override
    protected String getTopicName() {
        return null;
    }

    @Override
    protected ExternalOutputType processRequest(PhotoPublishedV1 photoPublishedV1) {
        try {
        	final String presignedUrl = getPresignedUrl(photoPublishedV1.getPhotoPath());
            postRequestToLa(eventMapper.mapRequestToLa(photoPublishedV1, presignedUrl));
        } catch (LdsDistClientException | HttpClientErrorException ex) {
            log.error("Client Exception on processing event ", ex);
        }
        
        catch (HttpServerErrorException ex) {
            log.error("Server Exception on processing event ", ex);
            throw new LdsDistException(format("Exception on processing event :%s", ex));
        }
        return null;
    }


    String getPresignedUrl(final String photoPath) {
    	if(!s3Client.doesBucketExistV2(ttPhotoBucket)) {
    		log.error("S3 Bucket {} doesn't exist ", ttPhotoBucket);
    		throw new LdsDistClientException("S3 Bucket Does Not Exist");
    	}
    	if(!s3Client.doesObjectExist(ttPhotoBucket, photoPath)) {
    		log.error("S3 Object with path {} doesn't exist in the bucket {}", photoPath, ttPhotoBucket);
    		throw new LdsDistClientException("S3 Object Does Not Exist in the Bucket");
    	}
    	return presignUrl.handlePresign(presigner, timeout, ttPhotoBucket, photoPath);
    }

    ResponseEntity<String> postRequestToLa(final com.ielts.cmds.integration.mapper.model.PhotoPublishedV1 responseBody) {
        
        try {
        	final AuthenticationClient authenticationClient = getAuthenticationClient();
            log.debug("Request object to LA: {} ",responseBody);
            final HttpHeaders eventHeaders = getHttpHeaders(authenticationClient);
            final HttpEntity<?> eventEntity = new HttpEntity<>(responseBody, eventHeaders);
            final ResponseEntity<String> response = authenticationClient.getRestTemplate()
                    .postForEntity(laEndpointUrl, eventEntity, String.class);
            log.info("Response code {} ", response.getStatusCode());
            return response;
        } catch (InvalidClientException | TokenNotReceivedException |  JsonProcessingException | CertificateException | KeyStoreException  ex) {
            log.error(" Exception on posting requestBody: ", ex);
            throw new LdsDistClientException(ex.getMessage());
        }
    }

    HttpHeaders getHttpHeaders(final AuthenticationClient authenticationClient) 
    		throws TokenNotReceivedException, JsonProcessingException, CertificateException, KeyStoreException{
        final HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.set(TRANSACTIONID, String.valueOf(ThreadLocalHeaderContext.getContext().getTransactionId()));
        httpHeaders.set(CORRELATIONID, String.valueOf(ThreadLocalHeaderContext.getContext().getCorrelationId()));
        httpHeaders.set(PARTNER_CODE, LADSConstants.CA);
        httpHeaders.set(authenticationClient.getAuthorizationHeaderName(), authenticationClient.getAccessToken());
        return httpHeaders;
    }

    AuthenticationClient getAuthenticationClient() throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException, InvalidClientException {
        return securityAuthenticationFactory.getAuthenticationClient(LADSConstants.CA);
    }
}
