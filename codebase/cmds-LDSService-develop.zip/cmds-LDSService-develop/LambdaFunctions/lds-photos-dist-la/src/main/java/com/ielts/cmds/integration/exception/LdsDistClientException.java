package com.ielts.cmds.integration.exception;

public class LdsDistClientException extends RuntimeException{

    private static final long serialVersionUID = 1L;

    public LdsDistClientException(final String message) {
        super(message);
    }
}
