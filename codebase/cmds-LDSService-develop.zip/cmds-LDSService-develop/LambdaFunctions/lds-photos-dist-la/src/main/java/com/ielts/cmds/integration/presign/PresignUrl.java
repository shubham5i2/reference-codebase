package com.ielts.cmds.integration.presign;

import java.time.Duration;

import software.amazon.awssdk.services.s3.presigner.S3Presigner;
import software.amazon.awssdk.services.s3.presigner.model.GetObjectPresignRequest;
import software.amazon.awssdk.services.s3.presigner.model.PresignedGetObjectRequest;

public class PresignUrl {
    public String handlePresign(final S3Presigner presigner, final String timeout, final String bucketName, final String file)  {


    GetObjectPresignRequest getObjectPresignRequest =
        GetObjectPresignRequest.builder()
            .signatureDuration(Duration.ofSeconds(Long.parseLong(timeout)))
            .getObjectRequest(requestBuilder -> requestBuilder.bucket(bucketName).key(file))
            .build();

        // Generate the presigned request
        PresignedGetObjectRequest presignedGetObjectRequest =
                presigner.presignGetObject(getObjectPresignRequest);

        return presignedGetObjectRequest.url().toString();
    }
}
