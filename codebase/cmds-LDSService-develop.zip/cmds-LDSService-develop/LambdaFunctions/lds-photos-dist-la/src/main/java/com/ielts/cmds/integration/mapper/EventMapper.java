package com.ielts.cmds.integration.mapper;


import com.ielts.cmds.testtaker.common.events.model.PhotoPublishedV1;

/**
 * This class is used to map incoming event to appropriate API request body
 */
public class EventMapper {

      public com.ielts.cmds.integration.mapper.model.PhotoPublishedV1 mapRequestToLa(final PhotoPublishedV1 incomingPhotoDetails, final String presignedUrl) {
    	  final com.ielts.cmds.integration.mapper.model.PhotoPublishedV1 photoPublished = new com.ielts.cmds.integration.mapper.model.PhotoPublishedV1();
    	  final com.ielts.cmds.integration.mapper.model.PhotoPublishedV1PhotoDetails photoDetails = new com.ielts.cmds.integration.mapper.model.PhotoPublishedV1PhotoDetails();
    	  photoDetails.setBookingUuid(incomingPhotoDetails.getBookingUuid());
    	  photoDetails.setCompositeCandidateNumber(incomingPhotoDetails.getCompositeCandidateNumber());
    	  photoDetails.setPhotoUuid(incomingPhotoDetails.getPhotoUuid());
    	  photoDetails.setPhotoTypeUuid(incomingPhotoDetails.getPhotoTypeUuid());
    	  photoDetails.setPhotoCategory(incomingPhotoDetails.getPhotoCategory().getValue());
    	  photoDetails.setPhotoVersion(incomingPhotoDetails.getPhotoVersion());
    	  photoDetails.setPhotoPath(presignedUrl);
    	  photoPublished.setPhotoDetails(photoDetails);
    	  return photoPublished;
      }
	  
}


