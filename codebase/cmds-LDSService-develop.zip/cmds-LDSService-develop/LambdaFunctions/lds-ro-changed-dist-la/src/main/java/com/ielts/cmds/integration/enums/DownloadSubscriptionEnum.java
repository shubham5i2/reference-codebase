package com.ielts.cmds.integration.enums;

public enum DownloadSubscriptionEnum {
    POSTAL(0),
    E_DELIVERY(1);

    private Integer value;

    DownloadSubscriptionEnum(Integer value) {
        this.value = value;
    }

    public Integer getValue() {
        return value;
    }

}
