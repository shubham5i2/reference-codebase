package com.ielts.cmds.integration.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/** MessageDetailsV1Inner */
@Data
public class MessageDetailsV1Inner {

    @JsonProperty(value = "rec_Id")
    private String recId;

    private RoDataV1 roData;

    private LinkedOrganisationsListV1 linkedOrganisations;
}
