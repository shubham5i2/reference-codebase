package com.ielts.cmds.integration.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

/** RoDataV1 */
@Data
@JsonInclude(value = Include.NON_NULL)
public class RoDataV1 implements Serializable {

    /** */
    private static final long serialVersionUID = 1267845277398089618L;

    private Integer organisationId;

    private String name;

    private String email;

    private String title;

    private String firstName;

    private String lastName;

    private String phoneNo;

    private Integer isDeleted;

    private String countryIsoCode;

    private String addressLine1;

    private String addressLine2;

    private String addressLine3;

    private String addressLine4;

    private Integer downloadSubscription;
    
    private Integer resultsAvailableForYears;
}
