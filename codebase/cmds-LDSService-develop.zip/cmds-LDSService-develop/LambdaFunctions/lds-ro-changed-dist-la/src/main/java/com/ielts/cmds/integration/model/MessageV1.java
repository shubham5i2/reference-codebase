package com.ielts.cmds.integration.model;

import lombok.Data;

/** MessageV1 */
@Data
public class MessageV1 {

    private MessageDetailsV1 msg;
}
