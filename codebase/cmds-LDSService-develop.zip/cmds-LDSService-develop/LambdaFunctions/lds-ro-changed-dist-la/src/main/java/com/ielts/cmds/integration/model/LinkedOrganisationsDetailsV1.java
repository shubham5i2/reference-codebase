package com.ielts.cmds.integration.model;

import lombok.Data;

/** LinkedOrganisationsDetailsV1 */
@Data
public class LinkedOrganisationsDetailsV1 {

    private String linkedRecognisingOrganisationUuid;

    private String targetRecognisingOrganisationUuid;

    private String linkType;

    private String linkEffectiveFromDateTime;

    private String linkEffectiveToDateTime;
}
