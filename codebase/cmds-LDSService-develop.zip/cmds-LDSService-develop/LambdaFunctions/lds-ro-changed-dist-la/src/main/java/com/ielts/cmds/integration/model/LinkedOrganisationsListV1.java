package com.ielts.cmds.integration.model;

import java.util.ArrayList;

import lombok.Data;
import lombok.EqualsAndHashCode;

/** LinkedOrganisationsListV1 */
@Data
@EqualsAndHashCode(callSuper = true)
public class LinkedOrganisationsListV1 extends ArrayList<LinkedOrganisationsDetailsV1> {/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}
