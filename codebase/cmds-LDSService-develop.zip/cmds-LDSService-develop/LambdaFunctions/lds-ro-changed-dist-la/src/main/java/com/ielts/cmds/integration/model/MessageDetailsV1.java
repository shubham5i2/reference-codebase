package com.ielts.cmds.integration.model;

import java.util.ArrayList;

import lombok.Data;
import lombok.EqualsAndHashCode;

/** MessageDetailsV1 */
@Data
@EqualsAndHashCode(callSuper = true)
public class MessageDetailsV1 extends ArrayList<MessageDetailsV1Inner> {

    /** */
    private static final long serialVersionUID = 5890814810577684603L;
}
