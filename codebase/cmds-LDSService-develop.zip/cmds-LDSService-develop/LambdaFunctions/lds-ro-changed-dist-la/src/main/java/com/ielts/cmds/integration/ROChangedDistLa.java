package com.ielts.cmds.integration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreate;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.integration.enums.DownloadSubscriptionEnum;
import com.ielts.cmds.integration.enums.IsDeletedEnum;
import com.ielts.cmds.integration.exception.ROChangedDistLAException;
import com.ielts.cmds.integration.model.LinkedOrganisationsDetailsV1;
import com.ielts.cmds.integration.model.LinkedOrganisationsListV1;
import com.ielts.cmds.integration.model.MessageDetailsV1;
import com.ielts.cmds.integration.model.MessageDetailsV1Inner;
import com.ielts.cmds.integration.model.MessageV1;
import com.ielts.cmds.integration.model.RoDataV1;
import com.ielts.cmds.integration.utils.ROChangedDistLaConstants;
import com.ielts.cmds.organisation.common.enums.MethodOfDeliveryEnum;
import com.ielts.cmds.organisation.common.enums.OrganisationStatusEnum;
import com.ielts.cmds.organisation.common.enums.VerificationStatusEnum;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Address;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Addresses;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Contact;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.exception.TokenNotReceivedException;
import com.ielts.cmds.security.factory.AuthenticationClientFactory;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;
import com.ielts.cmds.serialization.lambda.AbstractLambda;
import com.ielts.cmds.serialization.lambda.config.ExternalOutputType;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import lombok.extern.slf4j.Slf4j;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static java.lang.String.format;

@Slf4j
public class ROChangedDistLa extends AbstractLambda<RoChangedEventV1, ExternalOutputType> {

    private final AuthenticationClientFactory securityAuthenticationFactory = new EnvironmentAwareAuthenticationClientFactory();

    @Override
    protected String getTopicName() {
        return null;
    }

    @Override
    protected ExternalOutputType processRequest(RoChangedEventV1 roChangedEvent) {
        try{
            log.info("Event Received in {}:{} ", ROChangedDistLaConstants.RO, ROChangedDistLaConstants.RO_CHANGED_DIST_LA_LAMBDA);
            mapAndSendExternalEvent(roChangedEvent);
        } catch (Exception e) {
            List<ErrorDescription> errors = generateAndLogErrorResponse(ThreadLocalHeaderContext.getContext(), e);
            ThreadLocalErrorContext.setContext(new BaseEventErrors(errors));
            log.error("Client Exception on processing event ", e);
        }
		return null;
    }

    private void mapAndSendExternalEvent(RoChangedEventV1 roChangedEvent) throws Exception {
        log.info(" roChanged event {} : ",roChangedEvent) ;
        RoDataV1 roData = new RoDataV1();
        roData.setOrganisationId(roChangedEvent.getOrganisationId());
        roData.setName(roChangedEvent.getOrganisationName());
        roData.setResultsAvailableForYears(roChangedEvent.getResultAvailableForYears());
        Optional<RoChangedEventV1Contact> resultsAdminContact =
                roChangedEvent.getContacts().stream()
                        .filter(
                                contact ->
                                        contact.getContactType()
                                                .equals(
                                                        ROChangedDistLaConstants
                                                                .RESULTS_ADMIN_CONTACT_TYPE))
                        .findAny();
        if (RoDataCreate.MethodOfDeliveryEnum.E_DELIVERY == (roChangedEvent.getMethodOfDelivery())) {
            roData.setDownloadSubscription(DownloadSubscriptionEnum.E_DELIVERY.getValue());
        } else {
            roData.setDownloadSubscription(DownloadSubscriptionEnum.POSTAL.getValue());
        }
        resultsAdminContact.ifPresent(
                contact -> {
                    roData.setTitle(resultsAdminContact.get().getTitle());
                    roData.setFirstName(resultsAdminContact.get().getFirstName());
                    roData.setLastName(resultsAdminContact.get().getLastName());
                    Optional<RoChangedEventV1Address> resultAdminAddress =
                            getMainAddressDetails(resultsAdminContact.get().getAddresses());
                    resultAdminAddress.ifPresent(
                            address -> roData.setEmail(resultAdminAddress.get().getEmail()));
                });
        Optional<RoChangedEventV1Address> mainAddress =
                getMainAddressDetails(roChangedEvent.getAddresses());
        mainAddress.ifPresent(address -> setData(roData, address));
        if (RoDataCreate.OrganisationStatusEnum.ACTIVE == ( roChangedEvent.getOrganisationStatus())
                && RoDataCreate.VerificationStatusEnum.APPROVED == (roChangedEvent.getVerificationStatus()) ){
            roData.setIsDeleted(IsDeletedEnum.ZERO.getValue());
        } else {
            roData.setIsDeleted(IsDeletedEnum.ONE.getValue());
        }
        log.info(" RoData: {}" ,roData);
        MessageDetailsV1Inner messageDetails = new MessageDetailsV1Inner();
        messageDetails.setRecId(roChangedEvent.getRecognisingOrganisationUuid().toString());
        messageDetails.setRoData(roData);
        messageDetails.setLinkedOrganisations(setLinkedOrganisationsData(roChangedEvent));
        MessageDetailsV1 msgDetailsList = new MessageDetailsV1();
        msgDetailsList.add(messageDetails);
        log.info("message details: {} ",messageDetails);
        MessageV1 msg = new MessageV1();
        log.info("messagev1 :{} ", msg);
        msg.setMsg(msgDetailsList);
        log.info("Request Body to LA: {}", new ObjectMapper().writeValueAsString(msg));
        postRequestToExternalAPI(msg);
    }

    private LinkedOrganisationsListV1 setLinkedOrganisationsData(RoChangedEventV1 roChangedEvent) {
        LinkedOrganisationsListV1 linkedOrganisationsListV1 = new LinkedOrganisationsListV1();
        roChangedEvent
                .getLinkedOrganisations()
                .forEach(
                        linkedOrganisation -> {
                            LinkedOrganisationsDetailsV1 details =
                                    new LinkedOrganisationsDetailsV1();
                            details.setLinkedRecognisingOrganisationUuid(
                                    String.valueOf(
                                            linkedOrganisation
                                                    .getLinkedRecognisingOrganisationUuid()));
                            details.setTargetRecognisingOrganisationUuid(
                                    String.valueOf(
                                            linkedOrganisation
                                                    .getTargetRecognisingOrganisationUuid()));
                            details.setLinkType(String.valueOf(linkedOrganisation.getLinkType()));
                            DateTimeFormatter formatter =
                                    DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
                            String formattedFromDateTime =
                                    linkedOrganisation
                                            .getLinkEffectiveFromDateTime()
                                            .format(formatter);
                            details.setLinkEffectiveFromDateTime(formattedFromDateTime);
                            String formattedToDateTime =
                                    linkedOrganisation
                                            .getLinkEffectiveToDateTime()
                                            .format(formatter);
                            details.setLinkEffectiveToDateTime(formattedToDateTime);
                            linkedOrganisationsListV1.add(details);
                        });
        return linkedOrganisationsListV1;
    }

    private void setData(RoDataV1 roData, RoChangedEventV1Address mainAddress) {
        roData.setPhoneNo(mainAddress.getPhone());
        roData.setCountryIsoCode(mainAddress.getCountryIso3Code());
        roData.setAddressLine1(mainAddress.getAddressLine1());
        roData.setAddressLine2(mainAddress.getAddressLine2());
        roData.setAddressLine3(mainAddress.getAddressLine3());
        roData.setAddressLine4(mainAddress.getAddressLine4());
    }

    protected void postRequestToExternalAPI(MessageV1 requestMsg) throws Exception {

        log.info("In postRequesttoexternalAPI method !!!");
        AuthenticationClient authenticationClient =
                securityAuthenticationFactory.getAuthenticationClient("CA");
        UUID transactionId = ThreadLocalHeaderContext.getContext().getTransactionId();
        try {
            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.setContentType(MediaType.APPLICATION_JSON);
            httpHeaders.set(
                    authenticationClient.getAuthorizationHeaderName(),
                    authenticationClient.getAccessToken());
            final HttpEntity<?> eventEntity = new HttpEntity<>(requestMsg, httpHeaders);
            log.info("HttpHeaders: {} , AuthenticationClient : {} ,AccessToken: {} ",
                    httpHeaders,authenticationClient,authenticationClient.getAccessToken());
            final ResponseEntity<String> response =
                    authenticationClient
                            .getRestTemplate()
                            .postForEntity(getLAEndpointUrl(), eventEntity, String.class);
            if (response.getStatusCode() != HttpStatus.OK) {

                throw new ROChangedDistLAException(
                        format(
                                "Request Failed with StatusCode:%s, message:%s, TransactionId:%s",
                                response.getStatusCode(), response.getBody(), transactionId));
            }
            log.info(
                    "Request success with StatusCode: {} and message: {}. TransactionId: {} ",
                    response.getStatusCode(),
                    response.getBody(),
                    transactionId);
        } catch (RestClientException
                 | TokenNotReceivedException
                 | JsonProcessingException ex) {
            log.error("Exception on posting requestBody: ", ex);
            throw new ROChangedDistLAException(
                    format(
                            "TransactionId:%s - Exception on posting requestBody: %s",
                            transactionId, ex));
        }
    }

    public String getLAEndpointUrl() {
        return System.getenv(ROChangedDistLaConstants.CALLBACK_URL);
    }

    Optional<RoChangedEventV1Address> getMainAddressDetails(
            RoChangedEventV1Addresses roChangedEventAddresses) {

        return roChangedEventAddresses.stream()
                .filter(
                        address ->
                                ROChangedDistLaConstants.MAIN_ADDRESS_TYPE.equals(
                                        address.getAddressType()))
                .findAny();
    }

    /**
     * Method to generate Error Response
     *
     */
    protected List<ErrorDescription> generateAndLogErrorResponse(
            HeaderContext eventHeader, Exception exception) {
        ErrorDescription errorDescription = new ErrorDescription();
        errorDescription.setInterfaceName(ROChangedDistLaConstants.RO_CHANGED_DIST_LA_LAMBDA);
        errorDescription.setMessage(exception.getMessage());
        errorDescription.setTitle(ROChangedDistLaConstants.EXCEPTION_MESSAGE_PROCESSING);
        errorDescription.setType(ErrorTypeEnum.ERROR);
        errorDescription.setErrorCode(eventHeader.getEventName());
        errorDescription.setErrorTicketUuid(null);

        Source source =
                new Source(
                        exception.getMessage(), ROChangedDistLaConstants.RO_CHANGED_DIST_LA_LAMBDA);
        errorDescription.setSource(source);

        List<ErrorDescription> eventErrors = new ArrayList<>();
        eventErrors.add(errorDescription);
        log.error("Exception while calling LA API: {} ", eventErrors);
        return eventErrors;
    }
}


