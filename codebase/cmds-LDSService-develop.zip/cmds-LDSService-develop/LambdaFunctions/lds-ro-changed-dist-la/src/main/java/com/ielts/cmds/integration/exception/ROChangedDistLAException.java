package com.ielts.cmds.integration.exception;

public class ROChangedDistLAException extends RuntimeException {

    private static final long serialVersionUID = -4365063613498686628L;

    public ROChangedDistLAException(final String message) {
        super(message);
    }
}

