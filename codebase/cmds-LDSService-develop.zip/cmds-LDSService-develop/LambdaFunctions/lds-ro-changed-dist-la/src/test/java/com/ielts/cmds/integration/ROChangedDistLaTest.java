package com.ielts.cmds.integration;

import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreate;
import com.ielts.cmds.integration.exception.ROChangedDistLAException;
import com.ielts.cmds.integration.model.MessageV1;
import com.ielts.cmds.integration.utils.ROChangedDistLaConstants;
import com.ielts.cmds.organisation.common.enums.MethodOfDeliveryEnum;
import com.ielts.cmds.organisation.common.enums.OrganisationStatusEnum;
import com.ielts.cmds.organisation.common.enums.VerificationStatusEnum;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.*;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ROChangedDistLaTest {

    @Mock private ROChangedDistLa roChangedDistLa;

    @Mock AuthenticationClient authenticationClient;

    @Mock private EnvironmentAwareAuthenticationClientFactory securityAuthenticationFactory;

    @Mock private RestTemplate restTemplate;

    RoChangedEventV1 roChangedEventV1;

    @BeforeEach
    public void setUp() {
        roChangedEventV1 = SQSEventDataSetup.populateEventBody();
        ReflectionTestUtils.setField(roChangedDistLa, "securityAuthenticationFactory", securityAuthenticationFactory);

        HeaderContext header = new HeaderContext();
        header.setCorrelationId(UUID.randomUUID());
        header.setTransactionId(UUID.randomUUID());
        ThreadLocalHeaderContext.setContext(header);
    }

    @Test
    void whenRequestHasValidAuthenticationHeader_ThenVerifyCallToRestTemplate() throws Exception {
        ROChangedDistLa changedDistLaSpy = Mockito.spy(roChangedDistLa);
        Map<String, String> map = new HashMap<>();
        map.put(
                ROChangedDistLaConstants.ACCESS_TOKEN,
                SQSEventDataSetup.getEnvironmentVariablesStub()
                        .get(ROChangedDistLaConstants.ACCESS_TOKEN));
        map.put(ROChangedDistLaConstants.AUTH_HEADER, ROChangedDistLaConstants.AUTH_HEADER_NAME);
        ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.OK);
        doReturn(authenticationClient)
                .when(securityAuthenticationFactory)
                .getAuthenticationClient("CA");
        HttpHeaders httpHeaders = getHttpHeaders();
        httpHeaders.set(
                map.get(ROChangedDistLaConstants.AUTH_HEADER),
                map.get(ROChangedDistLaConstants.ACCESS_TOKEN));
//        doReturn(map.get(ROChangedDistLaConstants.AUTH_HEADER))
//                .when(authenticationClient)
//                .getAuthorizationHeaderName();
//        doReturn(map.get(ROChangedDistLaConstants.ACCESS_TOKEN))
//                .when(authenticationClient)
//                .getAccessToken();
        //doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        String url = "http://35.178.179.164:8105/romaster";
        //doReturn(url).when(changedDistLaSpy).getLAEndpointUrl();
        MessageV1 msg = SQSEventDataSetup.mockCMDSMessage();
        HttpEntity<?> eventEntity = new HttpEntity<>(msg, httpHeaders);
        //doReturn(response2).when(restTemplate).postForEntity(url, eventEntity, String.class);
        // Execute and assert test
        assertDoesNotThrow(() -> changedDistLaSpy.processRequest(roChangedEventV1));
        assertEquals(2, msg.getMsg().get(0).getLinkedOrganisations().size());
        assertEquals("41dfca9e-5308-40a7-a3db-7c9b1ae78bc5", msg.getMsg()
                .get(0)
                .getLinkedOrganisations()
                .get(0)
                .getLinkedRecognisingOrganisationUuid());
        assertEquals(
                "1f50ca55-3800-48c7-8f30-0723f5fac264",
                msg.getMsg()
                        .get(0)
                        .getLinkedOrganisations()
                        .get(0)
                        .getTargetRecognisingOrganisationUuid());
        assertEquals(
                "PARENT_RO", msg.getMsg().get(0).getLinkedOrganisations().get(0).getLinkType());
        assertEquals(
                "2020-11-23T05:52:55Z",
                String.valueOf(
                        msg.getMsg()
                                .get(0)
                                .getLinkedOrganisations()
                                .get(0)
                                .getLinkEffectiveFromDateTime()));
        assertEquals(
                "2020-12-23T00:00:00Z",
                String.valueOf(
                        msg.getMsg()
                                .get(0)
                                .getLinkedOrganisations()
                                .get(0)
                                .getLinkEffectiveToDateTime()));
    }

    @Test
    void whenRequestHasValidAuthenticationHeader_ThenVerifyMethodOfDelivery() throws Exception {
        ROChangedDistLa changedDistLaSpy = Mockito.spy(roChangedDistLa);

        Map<String, String> map = new HashMap<>();
        map.put(
                ROChangedDistLaConstants.ACCESS_TOKEN,
                SQSEventDataSetup.getEnvironmentVariablesStub()
                        .get(ROChangedDistLaConstants.ACCESS_TOKEN));
        map.put(ROChangedDistLaConstants.AUTH_HEADER, ROChangedDistLaConstants.AUTH_HEADER_NAME);
        ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.OK);
        doReturn(authenticationClient)
                .when(securityAuthenticationFactory)
                .getAuthenticationClient("CA");
        HttpHeaders httpHeaders = getHttpHeaders();
        httpHeaders.set(
                map.get(ROChangedDistLaConstants.AUTH_HEADER),
                map.get(ROChangedDistLaConstants.ACCESS_TOKEN));
        doReturn(map.get(ROChangedDistLaConstants.AUTH_HEADER))
                .when(authenticationClient)
                .getAuthorizationHeaderName();
        doReturn(map.get(ROChangedDistLaConstants.ACCESS_TOKEN))
                .when(authenticationClient)
                .getAccessToken();
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        String url = "http://35.178.179.164:8105/romaster";
        doReturn(url).when(changedDistLaSpy).getLAEndpointUrl();
        MessageV1 msg = SQSEventDataSetup.mockCMDSMessage();
        msg.getMsg().get(0).getRoData().setDownloadSubscription(1);
        msg.getMsg().get(0).getRoData().setIsDeleted(0);
        HttpEntity<?> eventEntity = new HttpEntity<>(msg, httpHeaders);
        doReturn(response2).when(restTemplate).postForEntity(url, eventEntity, String.class);

       assertDoesNotThrow(() -> changedDistLaSpy.processRequest(roChangedEventV1));
    }

    @Test
    void whenRequestHasValidAuthenticationHeader_ThenVerifyMethodOfDeliveryPostal() throws Exception {
        ROChangedDistLa changedDistLaSpy = Mockito.spy(roChangedDistLa);

        Map<String, String> map = new HashMap<>();
        map.put(
                ROChangedDistLaConstants.ACCESS_TOKEN,
                SQSEventDataSetup.getEnvironmentVariablesStub()
                        .get(ROChangedDistLaConstants.ACCESS_TOKEN));
        map.put(ROChangedDistLaConstants.AUTH_HEADER, ROChangedDistLaConstants.AUTH_HEADER_NAME);
        ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.OK);
        doReturn(authenticationClient)
                .when(securityAuthenticationFactory)
                .getAuthenticationClient("CA");
        HttpHeaders httpHeaders = getHttpHeaders();
        httpHeaders.set(
                map.get(ROChangedDistLaConstants.AUTH_HEADER),
                map.get(ROChangedDistLaConstants.ACCESS_TOKEN));
        doReturn(map.get(ROChangedDistLaConstants.AUTH_HEADER))
                .when(authenticationClient)
                .getAuthorizationHeaderName();
        doReturn(map.get(ROChangedDistLaConstants.ACCESS_TOKEN))
                .when(authenticationClient)
                .getAccessToken();
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        String url = "http://35.178.179.164:8105/romaster";
        doReturn(url).when(changedDistLaSpy).getLAEndpointUrl();
        MessageV1 msg = SQSEventDataSetup.mockCMDSMessage();
        roChangedEventV1.setMethodOfDelivery(RoDataCreate.MethodOfDeliveryEnum.POSTAL);
        roChangedEventV1.setOrganisationStatus(RoDataCreate.OrganisationStatusEnum.ACTIVE);
        roChangedEventV1.setVerificationStatus(RoDataCreate.VerificationStatusEnum.APPROVED);
        msg.getMsg().get(0).getRoData().setDownloadSubscription(1);
        msg.getMsg().get(0).getRoData().setIsDeleted(0);

        HttpEntity<?> eventEntity = new HttpEntity<>(msg, httpHeaders);
        doReturn(response2).when(restTemplate).postForEntity(url, eventEntity, String.class);

        assertDoesNotThrow(() -> changedDistLaSpy.processRequest(roChangedEventV1));
    }
    @Test
    void whenRequestNotSentCorrectly_ThenVerifyStatusCode() throws Exception {
        ROChangedDistLa changedDistLaSpy = Mockito.spy(roChangedDistLa);

        Map<String, String> map = new HashMap<>();
        map.put(
                ROChangedDistLaConstants.ACCESS_TOKEN,
                SQSEventDataSetup.getEnvironmentVariablesStub()
                        .get(ROChangedDistLaConstants.ACCESS_TOKEN));
        map.put(ROChangedDistLaConstants.AUTH_HEADER, ROChangedDistLaConstants.AUTH_HEADER_NAME);
        ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        doReturn(authenticationClient)
                .when(securityAuthenticationFactory)
                .getAuthenticationClient("CA");
        HttpHeaders httpHeaders = getHttpHeaders();
        httpHeaders.set(
                map.get(ROChangedDistLaConstants.AUTH_HEADER),
                map.get(ROChangedDistLaConstants.ACCESS_TOKEN));
        doReturn(map.get(ROChangedDistLaConstants.AUTH_HEADER))
                .when(authenticationClient)
                .getAuthorizationHeaderName();
        doReturn(map.get(ROChangedDistLaConstants.ACCESS_TOKEN))
                .when(authenticationClient)
                .getAccessToken();
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        String url = "http://35.178.179.164:8105/romaster";
        doReturn(url).when(changedDistLaSpy).getLAEndpointUrl();
        MessageV1 msg = SQSEventDataSetup.mockCMDSMessage();
        HttpEntity<?> eventEntity = new HttpEntity<>(msg, httpHeaders);
        doReturn(response2).when(restTemplate).postForEntity(url, eventEntity, String.class);
        // Execute and assert test
        assertNull(changedDistLaSpy.processRequest(roChangedEventV1));
    }

    @Test
    void whenRequestisInValid_ThenVerifyStatusCode() throws Exception {
        ROChangedDistLa changedDistLaSpy = Mockito.spy(roChangedDistLa);

        Map<String, String> map = new HashMap<>();
        map.put(
                ROChangedDistLaConstants.ACCESS_TOKEN,
                SQSEventDataSetup.getEnvironmentVariablesStub()
                        .get(ROChangedDistLaConstants.ACCESS_TOKEN));
        map.put(ROChangedDistLaConstants.AUTH_HEADER, ROChangedDistLaConstants.AUTH_HEADER_NAME);
        ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        doReturn(authenticationClient)
                .when(securityAuthenticationFactory)
                .getAuthenticationClient("CA");
        HttpHeaders httpHeaders = getHttpHeaders();
        doReturn(map.get(ROChangedDistLaConstants.AUTH_HEADER))
                .when(authenticationClient)
                .getAuthorizationHeaderName();
        doReturn(map.get(ROChangedDistLaConstants.ACCESS_TOKEN))
                .when(authenticationClient)
                .getAccessToken();
        httpHeaders.set(
                map.get(ROChangedDistLaConstants.AUTH_HEADER),
                map.get(ROChangedDistLaConstants.ACCESS_TOKEN));
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        String url = "http://35.178.179.164:8105/romaster";
        doReturn(url).when(changedDistLaSpy).getLAEndpointUrl();
        MessageV1 msg = SQSEventDataSetup.mockCMDSMessage();
        HttpEntity<?> eventEntity = new HttpEntity<>(msg, httpHeaders);
        doReturn(response2).when(restTemplate).postForEntity(url, eventEntity, String.class);
        // Execute and assert test
        assertNull(changedDistLaSpy.processRequest(roChangedEventV1));
        assertEquals(HttpStatus.BAD_REQUEST.value(), response2.getStatusCodeValue());
    }

    @Test
    void whenLegacyDeliveryHasInvalidAuthenticationHeader_ThenReturnFailResponseFromRest() throws Exception {
        ROChangedDistLa changedDistLaSpy = Mockito.spy(roChangedDistLa);

        Map<String, String> map = new HashMap<>();
        map.put(
                ROChangedDistLaConstants.ACCESS_TOKEN,
                SQSEventDataSetup.getEnvironmentVariablesStub()
                        .get(ROChangedDistLaConstants.ACCESS_TOKEN));
        map.put(ROChangedDistLaConstants.AUTH_HEADER, ROChangedDistLaConstants.AUTH_HEADER_NAME);
        ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        doReturn(authenticationClient)
                .when(securityAuthenticationFactory)
                .getAuthenticationClient("CA");
        HttpHeaders httpHeaders = getHttpHeaders();
        doReturn(map.get(ROChangedDistLaConstants.AUTH_HEADER))
                .when(authenticationClient)
                .getAuthorizationHeaderName();
        doReturn(map.get(ROChangedDistLaConstants.ACCESS_TOKEN))
                .when(authenticationClient)
                .getAccessToken();
        httpHeaders.set(
                map.get(ROChangedDistLaConstants.AUTH_HEADER),
                map.get(ROChangedDistLaConstants.ACCESS_TOKEN));
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        String url = "http://35.178.179.164:8105/romaster";
        doReturn(url).when(changedDistLaSpy).getLAEndpointUrl();
        MessageV1 msg = SQSEventDataSetup.mockCMDSMessage();
        HttpEntity<?> eventEntity = new HttpEntity<>(msg, httpHeaders);
        doReturn(response2).when(restTemplate).postForEntity(url, eventEntity, String.class);

        assertThrows(ROChangedDistLAException.class, () -> changedDistLaSpy.postRequestToExternalAPI(msg));
        assertEquals(HttpStatus.BAD_REQUEST.value(),response2.getStatusCodeValue());
    }

    @Test
    void whenRequestNotSentWithToken_ThenVerifyStatusCode() throws Exception {
        ROChangedDistLa changedDistLaSpy = Mockito.spy(roChangedDistLa);

        Map<String, String> map = new HashMap<>();
        map.put(
                ROChangedDistLaConstants.ACCESS_TOKEN,
                SQSEventDataSetup.getEnvironmentVariablesStub()
                        .get(ROChangedDistLaConstants.ACCESS_TOKEN));
        map.put(ROChangedDistLaConstants.AUTH_HEADER, ROChangedDistLaConstants.AUTH_HEADER_NAME);
        doReturn(authenticationClient)
                .when(securityAuthenticationFactory)
                .getAuthenticationClient("CA");
        HttpHeaders httpHeaders = getHttpHeaders();
        doReturn(map.get(ROChangedDistLaConstants.AUTH_HEADER))
                .when(authenticationClient)
                .getAuthorizationHeaderName();
        doThrow(RestClientException.class).when(authenticationClient).getRestTemplate();
        httpHeaders.set(
                map.get(ROChangedDistLaConstants.AUTH_HEADER),
                map.get(ROChangedDistLaConstants.ACCESS_TOKEN));
        // Execute and assert test
        assertNull(changedDistLaSpy.processRequest(roChangedEventV1));
    }

    @Test
    void testGetLAEndpointUrl() {
        ROChangedDistLa changedDistLaSpy = Mockito.spy(roChangedDistLa);
        assertNull(changedDistLaSpy.getLAEndpointUrl());
    }

    @Test
    void testGetTopicName() {
        ROChangedDistLa changedDistLaSpy = Mockito.spy(roChangedDistLa);
        assertNull(changedDistLaSpy.getTopicName());
    }



    private HttpHeaders getHttpHeaders() {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        return httpHeaders;
    }
}
