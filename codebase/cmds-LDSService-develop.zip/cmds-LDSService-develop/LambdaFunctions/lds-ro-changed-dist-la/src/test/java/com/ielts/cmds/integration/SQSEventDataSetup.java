package com.ielts.cmds.integration;

import static java.time.ZoneOffset.UTC;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreate;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreateLinkedOrganisation;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.integration.enums.DownloadSubscriptionEnum;
import com.ielts.cmds.integration.enums.IsDeletedEnum;
import com.ielts.cmds.integration.model.LinkedOrganisationsDetailsV1;
import com.ielts.cmds.integration.model.LinkedOrganisationsListV1;
import com.ielts.cmds.integration.model.MessageDetailsV1;
import com.ielts.cmds.integration.model.MessageDetailsV1Inner;
import com.ielts.cmds.integration.model.MessageV1;
import com.ielts.cmds.integration.model.RoDataV1;
import com.ielts.cmds.integration.utils.ROChangedDistLaConstants;
import com.ielts.cmds.organisation.common.enums.LinkTypeEnum;
import com.ielts.cmds.organisation.common.enums.MethodOfDeliveryEnum;
import com.ielts.cmds.organisation.common.enums.OrganisationStatusEnum;
import com.ielts.cmds.organisation.common.enums.VerificationStatusEnum;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Address;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Addresses;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1AlternateName;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1AlternateNames;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Contact;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Contacts;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1LinkedOrganisation;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1LinkedOrganisations;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Note;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Notes;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class SQSEventDataSetup {

    static final ObjectMapper mapper = new ObjectMapper();

    public static String getEventRequest() throws JsonProcessingException {

        final UiHeader header = populateEventHeader();
        final RoChangedEventV1 bodyList = populateEventBody();
        final String body = mapper.writeValueAsString(bodyList);
        final BaseEventErrors errors = null;
        final BaseEvent<UiHeader> event = new BaseEvent<>(header, body, errors, null);
        return mapper.writeValueAsString(event);
    }

    public static RoChangedEventV1 populateEventBody() {

        RoChangedEventV1 roChangedEvent = new RoChangedEventV1();
        roChangedEvent.setRecognisingOrganisationUuid(
                UUID.fromString("1afbf4b7-a534-40f6-9714-d5d97e10bed4"));
        roChangedEvent.setOrganisationName("Montreal University");
        roChangedEvent.setOrganisationId(124);
        roChangedEvent.setResultAvailableForYears(3);
        roChangedEvent.setOrganisationType("Recognising Organisation");
        roChangedEvent.setOrganisationTypeUuid(
                UUID.fromString("e496aa98-86a3-476d-8be3-21ee0aa23c93"));
        roChangedEvent.setOrganisationStatus(RoDataCreate.OrganisationStatusEnum.ACTIVE);
        roChangedEvent.setVerificationStatus(RoDataCreate.VerificationStatusEnum.APPROVED);
        roChangedEvent.setPartnerCode("IDP");
        roChangedEvent.setPartnerContact("partner contact");
        roChangedEvent.setMethodOfDelivery(RoDataCreate.MethodOfDeliveryEnum.POSTAL);
        roChangedEvent.setSectorType("College / University");
        roChangedEvent.setSectorTypeUuid(UUID.fromString("48270c84-4cc8-489e-8eac-2af59898175a"));
        roChangedEvent.setWebsiteUrl("www.university.com");
        roChangedEvent.setOrganisationCode("UIDNJN");
        roChangedEvent.setSoftDeleted(false);
        roChangedEvent.setAddresses(setAddressData());
        roChangedEvent.setContacts(setContactsData());
        roChangedEvent.setAlternateNames(setAlternateNamesData());
        roChangedEvent.setNotes(setRoNotesData());
        roChangedEvent.setMinimumScores(null);
        roChangedEvent.setRecognisedProducts(null);
        roChangedEvent.setLinkedOrganisations(setLinkedOrganisations());
        return roChangedEvent;
    }

    private static RoChangedEventV1LinkedOrganisations setLinkedOrganisations() {
        RoChangedEventV1LinkedOrganisations likedOrganisationList =
                new RoChangedEventV1LinkedOrganisations();
        RoChangedEventV1LinkedOrganisation linkedOrganisation =
                new RoChangedEventV1LinkedOrganisation();
        linkedOrganisation.setLinkedRecognisingOrganisationUuid(
                UUID.fromString("41dfca9e-5308-40a7-a3db-7c9b1ae78bc5"));
        linkedOrganisation.setTargetRecognisingOrganisationUuid(
                UUID.fromString("1f50ca55-3800-48c7-8f30-0723f5fac264"));
        linkedOrganisation.setLinkType(RoDataCreateLinkedOrganisation.LinkTypeEnum.PARENT_RO);
        linkedOrganisation.setLinkEffectiveFromDateTime(
                OffsetDateTime.of(2020, 11, 23, 05, 52, 55, 555,UTC));
        linkedOrganisation.setLinkEffectiveToDateTime(
                OffsetDateTime.of(2020, 12, 23, 00, 00, 00, 000,UTC));
        likedOrganisationList.add(linkedOrganisation);
        RoChangedEventV1LinkedOrganisation linkedOrganisation1 =
                new RoChangedEventV1LinkedOrganisation();
        linkedOrganisation1.setLinkedRecognisingOrganisationUuid(
                UUID.fromString("6797fa33-4b8f-414b-bc1e-a9589430dbc5"));
        linkedOrganisation1.setTargetRecognisingOrganisationUuid(
                UUID.fromString("f54b165c-a342-4a26-8232-f452f491f409"));
        linkedOrganisation1.setLinkType(RoDataCreateLinkedOrganisation.LinkTypeEnum.REPLACED_BY);
        linkedOrganisation1.setLinkEffectiveFromDateTime(
                OffsetDateTime.now());
        linkedOrganisation1.setLinkEffectiveToDateTime(
                OffsetDateTime.now());
        likedOrganisationList.add(linkedOrganisation1);
        return likedOrganisationList;
    }

    private static RoChangedEventV1Contacts setContactsData() {
        RoChangedEventV1Contacts contacts = new RoChangedEventV1Contacts();
        RoChangedEventV1Contact primaryContact = new RoChangedEventV1Contact();
        primaryContact.setContactUuid(UUID.fromString("a1ec3711-f81d-426a-a0eb-e2c67ff5a257"));
        primaryContact.setContactTypeUuid(UUID.fromString("c3397312-8ea3-453d-871b-68a1ef8c9184"));
        primaryContact.setContactType("Primary");
        primaryContact.setTitle("Mr");
        primaryContact.setFirstName("Chris");
        primaryContact.setLastName("John");
        primaryContact.setEffectiveFromDateTime(OffsetDateTime.now());
        primaryContact.setEffectiveToDateTime(OffsetDateTime.now());
        primaryContact.setAddresses(setContactsAddressData());
        contacts.add(primaryContact);
        RoChangedEventV1Contact resultsAdminContact = new RoChangedEventV1Contact();
        resultsAdminContact.setContactUuid(UUID.fromString("bf1c7e10-9cca-46de-9c13-c2627ea02aad"));
        resultsAdminContact.setContactTypeUuid(
                UUID.fromString("457a494b-64ca-497f-868f-cc0e5f30a97f"));
        resultsAdminContact.setContactType("Results Admin");
        resultsAdminContact.setTitle("Mr");
        resultsAdminContact.setFirstName("Chris");
        resultsAdminContact.setLastName("John");
        resultsAdminContact.setEffectiveFromDateTime(OffsetDateTime.now());
        resultsAdminContact.setEffectiveToDateTime(OffsetDateTime.now());
        resultsAdminContact.setAddresses(setContactsAddressData());
        contacts.add(resultsAdminContact);
        return contacts;
    }

    private static RoChangedEventV1Addresses setContactsAddressData() {
        RoChangedEventV1Addresses addresses = new RoChangedEventV1Addresses();
        RoChangedEventV1Address address = new RoChangedEventV1Address();
        address.setAddressUuid(UUID.fromString("4ca62415-61e0-4d4a-ab0d-67776fb2638a"));
        address.setAddressTypeUuid(UUID.fromString("c96fbd08-a302-4aa2-a594-13cdb33bb380"));
        address.setAddressType("Main");
        address.setAddressLine1("street");
        address.setAddressLine2("dfe");
        address.setAddressLine3(null);
        address.setAddressLine4(null);
        address.setCity("Hyderabad");
        address.setCountry("INDIA");
        address.setCountryIso3Code("IND");
        address.setCountryUuid(UUID.fromString("4b8dac87-d2dd-4599-b055-2f73a5f0a01a"));
        address.setEmail("email@email.com");
        address.setPhone("1234567");
        address.setPostalCode("UIOP");
        address.setTerritory(null);
        address.setTerritoryIsoCode(null);
        address.setTerritoryUuid(null);
        addresses.add(address);
        return addresses;
    }

    private static RoChangedEventV1Notes setRoNotesData() {
        RoChangedEventV1Notes notes = new RoChangedEventV1Notes();
        RoChangedEventV1Note note = new RoChangedEventV1Note();
        note.setNoteUuid(UUID.fromString("6230b520-e96b-4b66-a146-b66a2ad60d6b"));
        note.setNoteTypeUuid(UUID.fromString("f9aa5ac1-da99-40f2-82e7-a5fea9e45979"));
        note.setNoteContent("note 1");
        note.setUpdatedDatetime(LocalDateTime.now());
        notes.add(note);
        RoChangedEventV1Note note1 = new RoChangedEventV1Note();
        note1.setNoteUuid(UUID.fromString("20c73561-d2f9-4b41-9146-69293c95d563"));
        note1.setNoteTypeUuid(UUID.fromString("f9aa5ac1-da99-40f2-82e7-a5fea9e45979"));
        note1.setNoteContent("note 2");
        note1.setUpdatedDatetime(LocalDateTime.now());
        notes.add(note1);
        return notes;
    }

    private static RoChangedEventV1AlternateNames setAlternateNamesData() {
        RoChangedEventV1AlternateNames altNames = new RoChangedEventV1AlternateNames();
        RoChangedEventV1AlternateName altName = new RoChangedEventV1AlternateName();
        altName.setAlternateNameUuid(UUID.fromString("42efb8ed-1b0c-4155-8743-7d2303cd0a32"));
        altName.setName("alt name 1");
        altNames.add(altName);
        RoChangedEventV1AlternateName altName1 = new RoChangedEventV1AlternateName();
        altName1.setAlternateNameUuid(UUID.fromString("b05fbf74-ca30-489c-9f23-9f8f5a9b3c89"));
        altName1.setName("alt name 2");
        altNames.add(altName1);
        return altNames;
    }

    private static RoChangedEventV1Addresses setAddressData() {
        RoChangedEventV1Addresses addresses = new RoChangedEventV1Addresses();
        RoChangedEventV1Address address = new RoChangedEventV1Address();
        address.setAddressUuid(UUID.fromString("9e5146b0-0fd1-4da7-aa2f-ebfd65405e9f"));
        address.setAddressTypeUuid(UUID.fromString("c96fbd08-a302-4aa2-a594-13cdb33bb380"));
        address.setAddressType("Main");
        address.setAddressLine1("street 57");
        address.setAddressLine2("dsd");
        address.setAddressLine3(null);
        address.setAddressLine4(null);
        address.setCity("Hyd");
        address.setCountry("INDIA");
        address.setCountryIso3Code("IND");
        address.setCountryUuid(UUID.fromString("4b8dac87-d2dd-4599-b055-2f73a5f0a01a"));
        address.setEmail("mainAddress@gmail.com");
        address.setPhone(null);
        address.setPostalCode(null);
        address.setTerritory(null);
        address.setTerritoryIsoCode(null);
        address.setTerritoryUuid(null);
        addresses.add(address);
        RoChangedEventV1Address address1 = new RoChangedEventV1Address();
        address1.setAddressUuid(UUID.fromString("cba8cb7d-bffb-4af3-ad2a-0342e1773b1c"));
        address1.setAddressTypeUuid(UUID.fromString("d13761e9-c134-4f80-a0a8-239a683a9c00"));
        address1.setAddressType("Delivery");
        address1.setAddressLine1("street 1");
        address1.setAddressLine2(null);
        address1.setAddressLine3(null);
        address1.setAddressLine4(null);
        address1.setCity("Hyderabad");
        address1.setCountry("INDIA");
        address1.setCountryIso3Code("IND");
        address1.setCountryUuid(UUID.fromString("4b8dac87-d2dd-4599-b055-2f73a5f0a01a"));
        address1.setEmail("deliveryAddress@email.com");
        address1.setPhone("1234567");
        address1.setPostalCode("INFD");
        address1.setTerritory(null);
        address1.setTerritoryIsoCode(null);
        address1.setTerritoryUuid(null);
        addresses.add(address1);
        return addresses;
    }


    public static UiHeader populateEventHeader() {
        UiHeader uiHeader = new UiHeader();
        uiHeader.setConnectionId("WPl56dCALPECGwg=");
        uiHeader.setTransactionId(UUID.fromString("3e81e94b-8b6a-42b5-970c-b141f9d195a4"));
        uiHeader.setCorrelationId(UUID.fromString("123e4567-e89b-12d3-a456-426614174000"));
        uiHeader.setPartnerCode(null);
        uiHeader.setEventName("RoChanged");
        uiHeader.setEventDateTime(LocalDateTime.now());
        uiHeader.setEventDiscriminator("LA");
        return uiHeader;
    }

    public static Map<String, String> getEnvironmentVariablesStub() {
        Map<String, String> map = new HashMap<>();
        map.put(ROChangedDistLaConstants.CLIENT_ID, "cmds-id");
        map.put(ROChangedDistLaConstants.CLIENT_SECRET, "cmds-secret");
        map.put(ROChangedDistLaConstants.ACCESS_TOKEN, "access-token");
        map.put("ca_auth_token_url", "CA_AUTH_URL");
        return map;
    }

    public static MessageV1 mockCMDSMessage() {
        RoChangedEventV1 roChangedEvent = populateEventBody();
        RoDataV1 roData = new RoDataV1();
        roData.setOrganisationId(124);
        roData.setName("Montreal University");
        roData.setTitle("Mr");
        roData.setFirstName("Chris");
        roData.setLastName("John");
        roData.setEmail("email@email.com");
        roData.setCountryIsoCode("IND");
        roData.setAddressLine1("street 57");
        roData.setAddressLine2("dsd");
        roData.setIsDeleted(IsDeletedEnum.ZERO.getValue());
        roData.setDownloadSubscription(DownloadSubscriptionEnum.POSTAL.getValue());
        roData.setResultsAvailableForYears(3);
        LinkedOrganisationsListV1 linkedOrganisationsListV1 = new LinkedOrganisationsListV1();
        roChangedEvent
                .getLinkedOrganisations()
                .forEach(
                        linkedOrganisation -> {
                            LinkedOrganisationsDetailsV1 details =
                                    new LinkedOrganisationsDetailsV1();
                            details.setLinkedRecognisingOrganisationUuid(
                                    String.valueOf(
                                            linkedOrganisation
                                                    .getLinkedRecognisingOrganisationUuid()));
                            details.setTargetRecognisingOrganisationUuid(
                                    String.valueOf(
                                            linkedOrganisation
                                                    .getTargetRecognisingOrganisationUuid()));
                            details.setLinkType(String.valueOf(linkedOrganisation.getLinkType()));
                            DateTimeFormatter formatter =
                                    DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
                            String formattedFromDateTime =
                                    linkedOrganisation
                                            .getLinkEffectiveFromDateTime()
                                            .format(formatter);
                            details.setLinkEffectiveFromDateTime(formattedFromDateTime);
                            String formattedToDateTime =
                                    linkedOrganisation
                                            .getLinkEffectiveToDateTime()
                                            .format(formatter);
                            details.setLinkEffectiveToDateTime(formattedToDateTime);
                            linkedOrganisationsListV1.add(details);
                        });
        MessageDetailsV1Inner messageDetails = new MessageDetailsV1Inner();
        messageDetails.setRecId(roChangedEvent.getRecognisingOrganisationUuid().toString());
        messageDetails.setRoData(roData);
        messageDetails.setLinkedOrganisations(linkedOrganisationsListV1);
        MessageDetailsV1 msgDetailsList = new MessageDetailsV1();
        msgDetailsList.add(messageDetails);
        MessageV1 msg = new MessageV1();
        msg.setMsg(msgDetailsList);
        return msg;
    }
}
