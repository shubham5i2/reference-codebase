package com.ielts.cmds.integration;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.sns.AmazonSNS;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.evt004.ResultReleasedNodeV1;
import com.ielts.cmds.api.evt178.PublishStatusV2;
import com.ielts.cmds.integration.constants.LADSConstants;
import com.ielts.cmds.integration.exception.LdsDistClientException;
import com.ielts.cmds.integration.exception.LdsDistException;
import com.ielts.cmds.integration.mapper.EventMapper;
import com.ielts.cmds.integration.model.MessageV1;
import com.ielts.cmds.integration.presign.PresignUrl;
import com.ielts.cmds.integration.testdata.SQSEventBodySetup;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.exception.InvalidClientException;
import com.ielts.cmds.security.exception.TokenNotReceivedException;
import com.ielts.cmds.security.factory.AuthenticationClientFactory;
import com.ielts.cmds.serialization.lambda.config.SNSClientConfig;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import software.amazon.awssdk.services.s3.presigner.S3Presigner;

import java.security.KeyStoreException;
import java.security.cert.CertificateException;
import java.util.UUID;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;


@ExtendWith(MockitoExtension.class)
class LDSResultsV2DistLaTest {

    @Mock
    private AuthenticationClientFactory securityAuthenticationFactory;

    @Mock
    private AmazonS3 s3Client;

    @Mock
    private AmazonSNS snsClient;

    @Mock
    private S3Presigner presigner;

    @Mock
    private PresignUrl presignUrl;

    @Mock
    private EventMapper eventMapper;

    @Mock
    private AuthenticationClient authenticationClient;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private HttpHeaders httpHeaders;

    @Spy
    @InjectMocks
    private LDSResultsV2DistLa ldsResultsV2DistLa;

    private static MockedStatic<S3Config> s3ClientConfig;

    private static MockedStatic<SNSClientConfig> snsClientConfig;

    private final String laEndpointUrl = "www.la.url";

    private final String ttPhotoBucket = "test-bucket";

    private final String timeout = "60480";

    private final String topicArn = "topic-out";

    @BeforeAll
    static void init() {
        s3ClientConfig = Mockito.mockStatic(S3Config.class);
        snsClientConfig = Mockito.mockStatic(SNSClientConfig.class);
    }

    @AfterAll
    static void close() {
        s3ClientConfig.close();
        snsClientConfig.close();
    }

    @BeforeEach
    void setup() {
        HeaderContext headerContext = SQSEventBodySetup.getThreadHeaderContext();
        ThreadLocalHeaderContext.setContext(headerContext);
        s3ClientConfig.when(S3Config::s3Client).thenReturn(s3Client);
        s3ClientConfig.when(S3Config::s3Presigner).thenReturn(presigner);
        snsClientConfig.when(SNSClientConfig::getSNSClient).thenReturn(snsClient);
        ReflectionTestUtils.setField(ldsResultsV2DistLa, "securityAuthenticationFactory", securityAuthenticationFactory);
        ReflectionTestUtils.setField(ldsResultsV2DistLa, "laEndpointUrl", laEndpointUrl);
        ReflectionTestUtils.setField(ldsResultsV2DistLa, "ttPhotoBucket", ttPhotoBucket);
        ReflectionTestUtils.setField(ldsResultsV2DistLa, "timeout", timeout);
        ReflectionTestUtils.setField(ldsResultsV2DistLa, "s3Client", s3Client);
        ReflectionTestUtils.setField(ldsResultsV2DistLa, "presigner", presigner);
        ReflectionTestUtils.setField(ldsResultsV2DistLa, "presignUrl", presignUrl);
        ReflectionTestUtils.setField(ldsResultsV2DistLa, "eventMapper", eventMapper);
        ReflectionTestUtils.setField(ldsResultsV2DistLa, "topicArn", topicArn);
    }

    @Test
    void getTopicName_ExpectNull() {
        assertNotNull(ldsResultsV2DistLa.getTopicName());
        assertEquals("topic-out",ldsResultsV2DistLa.getTopicName());
    }

    @Test
    void processRequest_Expect_AckEvent_with_publishedStatus() {
        final ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        final String presignedUrl = "www.test.org";
        doReturn(presignedUrl).when(ldsResultsV2DistLa).getPresignedUrlForPhoto(resultReleasedNodeV1);
        doReturn(new ResponseEntity<>(HttpStatus.OK)).when(ldsResultsV2DistLa).postRequestToLa(ArgumentMatchers.any());
        PublishStatusV2 publishStatusV2 = ldsResultsV2DistLa.processRequest(resultReleasedNodeV1);
        assertNotNull(publishStatusV2);
        assertEquals("PUBLISHED",publishStatusV2.getStatus());
    }

    @Test
    void processRequestWithLdsDistClientException_Expect_AckEvent_with_FailedStatus() {
        final ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        final String presignedUrl = "www.test.org";
        doReturn(presignedUrl).when(ldsResultsV2DistLa).getPresignedUrlForPhoto(resultReleasedNodeV1);
        doThrow(LdsDistClientException.class).when(ldsResultsV2DistLa).postRequestToLa(ArgumentMatchers.any());
        PublishStatusV2 publishStatusV2 = ldsResultsV2DistLa.processRequest(resultReleasedNodeV1);
        assertNotNull(publishStatusV2);
        assertEquals("FAILED",publishStatusV2.getStatus());
    }

    @Test
    void processRequestWithHttpClientException_ExpectAckEvent_with_FailedStatus() {
        final ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        final String presignedUrl = "www.test.org";
        doReturn(presignedUrl).when(ldsResultsV2DistLa).getPresignedUrlForPhoto(resultReleasedNodeV1);
        doThrow(HttpClientErrorException.class).when(ldsResultsV2DistLa).postRequestToLa(ArgumentMatchers.any());
        PublishStatusV2 publishStatusV2 = ldsResultsV2DistLa.processRequest(resultReleasedNodeV1);
        assertNotNull(publishStatusV2);
        assertEquals("FAILED",publishStatusV2.getStatus());
    }

    @Test
    void processRequestWithHttpServerErrorException_Expect_throwException() {
        final ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        final String presignedUrl = "www.test.org";
        doReturn(presignedUrl).when(ldsResultsV2DistLa).getPresignedUrlForPhoto(resultReleasedNodeV1);
        doThrow(HttpServerErrorException.class).when(ldsResultsV2DistLa).postRequestToLa(ArgumentMatchers.any());
        assertThrows(HttpServerErrorException.class,()->ldsResultsV2DistLa.processRequest(resultReleasedNodeV1));
        Mockito.verify(ldsResultsV2DistLa, times(0)).buildHeader();
    }

    @Test
    void getPresignedUrlForPhoto_expect_url() {
        final ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        final String presignedUrl = "www.test.org";
        doReturn(presignedUrl).when(ldsResultsV2DistLa).generatePresignedUrl(ArgumentMatchers.anyString());
        assertEquals(presignedUrl,ldsResultsV2DistLa.getPresignedUrlForPhoto(resultReleasedNodeV1));
    }

    @Test
    void getPresignedUrlForPhoto_throw_exception() {
        final ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        resultReleasedNodeV1.getTtPhotoDetails().clear();
        assertThrows(LdsDistException.class,()->ldsResultsV2DistLa.getPresignedUrlForPhoto(resultReleasedNodeV1));
    }

    @Test
    void getPresignedUrlForPhoto_expect_emptyString() {
        final ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        resultReleasedNodeV1.setTtPhotoDetails(null);
        assertEquals("",ldsResultsV2DistLa.getPresignedUrlForPhoto(resultReleasedNodeV1));
    }

    @Test
    void getPresignedUrlBucketDoesNotExist_ExpectClientException() {
        doReturn(false).when(s3Client).doesBucketExistV2(ttPhotoBucket);
        Assertions.assertThrows(LdsDistClientException.class, ()->ldsResultsV2DistLa.generatePresignedUrl("somepath.jpeg"));
    }

    @Test
    void getPresignedUrlObjectDoesNotExist_ExpectClientException() {
        doReturn(true).when(s3Client).doesBucketExistV2(ttPhotoBucket);
        doReturn(false).when(s3Client).doesObjectExist(ttPhotoBucket, "path.jpeg");
        Assertions.assertThrows(LdsDistClientException.class, ()->ldsResultsV2DistLa.generatePresignedUrl("path.jpeg"));
    }

    @Test
    void getPresignedUrl_ExpectPresignedUrl() {
        doReturn(true).when(s3Client).doesBucketExistV2(ttPhotoBucket);
        doReturn(true).when(s3Client).doesObjectExist(ttPhotoBucket, "some.jpeg");
        doReturn("www.test.url").when(presignUrl).handlePresign(presigner, timeout, ttPhotoBucket, "some.jpeg");
        assertEquals("www.test.url",ldsResultsV2DistLa.generatePresignedUrl("some.jpeg"));
    }

    @Test
    void postRequestToLa_ExpectOkStatus() throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException, InvalidClientException {
        MessageV1 messageV1 = SQSEventBodySetup.getMessageV1();
        httpHeaders = SQSEventBodySetup.getHttpHeaders(ThreadLocalHeaderContext.getContext());
        doReturn(authenticationClient).when(ldsResultsV2DistLa).getAuthenticationClient();
        doReturn(httpHeaders).when(ldsResultsV2DistLa).getHttpHeaders(authenticationClient);
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        doReturn(new ResponseEntity<>(HttpStatus.OK)).when(restTemplate)
                .postForEntity(eq(laEndpointUrl), any(HttpEntity.class), eq(String.class));
        final ResponseEntity<String> actual = ldsResultsV2DistLa.postRequestToLa(messageV1);
        assertEquals(HttpStatus.OK, actual.getStatusCode());
    }

    @Test
    void postRequestToLaInvalidClientException_ExpectLDSDistClientException() throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException, InvalidClientException {
        MessageV1 messageV1 = SQSEventBodySetup.getMessageV1();
        doThrow(InvalidClientException.class).when(ldsResultsV2DistLa).getAuthenticationClient();
        Assertions.assertThrows(LdsDistClientException.class, () -> ldsResultsV2DistLa.postRequestToLa(messageV1));
    }

    @Test
    void postRequestToLaCertificateException_ExpectLDSDistClientException() throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException, InvalidClientException {
        MessageV1 messageV1 = SQSEventBodySetup.getMessageV1();
        doThrow(CertificateException.class).when(ldsResultsV2DistLa).getAuthenticationClient();
        Assertions.assertThrows(LdsDistClientException.class, () -> ldsResultsV2DistLa.postRequestToLa(messageV1));
    }

    @Test
    void postRequestToLaKeystoreException_ExpectLDSDistClientException() throws TokenNotReceivedException, InvalidClientException, CertificateException, KeyStoreException, JsonProcessingException {
        MessageV1 messageV1 = SQSEventBodySetup.getMessageV1();
        
        doThrow(KeyStoreException.class).when(ldsResultsV2DistLa).getAuthenticationClient();
        Assertions.assertThrows(LdsDistClientException.class, () -> ldsResultsV2DistLa.postRequestToLa(messageV1));
    }

    @Test
    void postRequestToLaTokenNotReceivedException_ExpectLDSDistClientException() throws TokenNotReceivedException, InvalidClientException, CertificateException, KeyStoreException, JsonProcessingException {
        MessageV1 messageV1 = SQSEventBodySetup.getMessageV1();
        doReturn(authenticationClient).when(ldsResultsV2DistLa).getAuthenticationClient();
        doThrow(TokenNotReceivedException.class).when(ldsResultsV2DistLa).getHttpHeaders(authenticationClient);
        Assertions.assertThrows(LdsDistClientException.class, () -> ldsResultsV2DistLa.postRequestToLa(messageV1));
    }

    @Test
    void postRequestToLaJsonProcessingException_ExpectLDSDistClientException() throws TokenNotReceivedException, InvalidClientException, CertificateException, KeyStoreException, JsonProcessingException {
        MessageV1 messageV1 = SQSEventBodySetup.getMessageV1();
        doReturn(authenticationClient).when(ldsResultsV2DistLa).getAuthenticationClient();
        doThrow(JsonProcessingException.class).when(ldsResultsV2DistLa).getHttpHeaders(authenticationClient);
        Assertions.assertThrows(LdsDistClientException.class, () -> ldsResultsV2DistLa.postRequestToLa(messageV1));
    }

    @Test
    void postRequestToLaClientException_ExpectClientException() throws TokenNotReceivedException, CertificateException, KeyStoreException, JsonProcessingException, InvalidClientException {
        MessageV1 messageV1 = SQSEventBodySetup.getMessageV1();
        httpHeaders = SQSEventBodySetup.getHttpHeaders(ThreadLocalHeaderContext.getContext());
        doReturn(authenticationClient).when(ldsResultsV2DistLa).getAuthenticationClient();
        doReturn(httpHeaders).when(ldsResultsV2DistLa).getHttpHeaders(authenticationClient);
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        doThrow(HttpClientErrorException.class).when(restTemplate)
                .postForEntity(eq(laEndpointUrl), any(HttpEntity.class), eq(String.class));
        Assertions.assertThrows(HttpClientErrorException.class, () -> ldsResultsV2DistLa.postRequestToLa(messageV1));
    }

    @Test
    void postRequestToLaServerException_ExpectServerException() throws TokenNotReceivedException, CertificateException, KeyStoreException, JsonProcessingException, InvalidClientException {
        MessageV1 messageV1 = SQSEventBodySetup.getMessageV1();
        httpHeaders = SQSEventBodySetup.getHttpHeaders(ThreadLocalHeaderContext.getContext());
        doReturn(authenticationClient).when(ldsResultsV2DistLa).getAuthenticationClient();
        doReturn(httpHeaders).when(ldsResultsV2DistLa).getHttpHeaders(authenticationClient);
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        doThrow(HttpServerErrorException.class).when(restTemplate)
                .postForEntity(eq(laEndpointUrl), any(HttpEntity.class), eq(String.class));
        Assertions.assertThrows(HttpServerErrorException.class, () -> ldsResultsV2DistLa.postRequestToLa(messageV1));
    }

    @Test
    void getHttpHeaders_ExpectHeaders() throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException {
        final HeaderContext cmdsHeaderContext = new HeaderContext();
        cmdsHeaderContext.setTransactionId(UUID.randomUUID());
        cmdsHeaderContext.setCorrelationId(UUID.randomUUID());
        ThreadLocalHeaderContext.setContext(cmdsHeaderContext);
        doReturn("Authentication").when(authenticationClient).getAuthorizationHeaderName();
        doReturn("abc").when(authenticationClient).getAccessToken();
        final HttpHeaders actual = ldsResultsV2DistLa.getHttpHeaders(authenticationClient);
        assertEquals("abc", actual.get("Authentication").get(0));
        assertEquals(MediaType.APPLICATION_JSON, actual.getContentType());
        assertEquals(cmdsHeaderContext.getCorrelationId().toString(), actual.get("correlationId").get(0));
        assertEquals(cmdsHeaderContext.getTransactionId().toString(), actual.get("transactionId").get(0));
        assertEquals("CA", actual.get("partnerCode").get(0));
    }

    @Test
    void getAuthenticationClient_ExpectAuthClientObject() throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException, InvalidClientException {
        doReturn(authenticationClient).when(securityAuthenticationFactory).getAuthenticationClient(LADSConstants.CA);
        assertEquals(authenticationClient, ldsResultsV2DistLa.getAuthenticationClient());
    }
}
