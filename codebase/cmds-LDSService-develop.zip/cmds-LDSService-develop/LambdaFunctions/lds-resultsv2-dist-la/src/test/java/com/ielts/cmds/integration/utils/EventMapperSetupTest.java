package com.ielts.cmds.integration.utils;


import com.ielts.cmds.api.evt004.LocationChangeNodeV1;
import com.ielts.cmds.api.evt004.ResultDeliveryBookingLineNodeV1;
import com.ielts.cmds.integration.exception.LdsDistException;
import com.ielts.cmds.integration.model.ProductCharacteristicsV1;
import com.ielts.cmds.integration.testdata.SQSEventBodySetup;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.api.evt004.ResultDeliveryBookingNodeV1;
import com.ielts.cmds.api.evt004.ResultReleasedNodeV1;

import java.time.LocalDate;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class EventMapperSetupTest {

    @InjectMocks EventMapperSetup eventMapperSetup;

    @Test
    void checkForNullUuid(){
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        assertDoesNotThrow(()->eventMapperSetup.getReferenceValue(resultReleasedNodeV1,null));
    }

    @Test
    void checkForNullReferenceId(){
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        resultReleasedNodeV1.getReferenceData().get(0).setReferenceId(null);
        String value = eventMapperSetup.getReferenceValue(resultReleasedNodeV1,null);
        assertNull(value);
    }

    @Test
    void checkForNullReferenceData(){
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        resultReleasedNodeV1.setReferenceData(SQSEventBodySetup.setReferenceDataNodeV1());
        String value = eventMapperSetup.getReferenceValue(resultReleasedNodeV1,UUID.fromString("e873fca7-849b-4e3b-8dfc-b6b5108621ab"));
        assertEquals("L",value);
    }

    @Test
    void checkForNullResultLines(){
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        resultReleasedNodeV1.getResultDetails().setResultLines(null);
        resultReleasedNodeV1.setReferenceData(null);
        assertDoesNotThrow(()->eventMapperSetup.setScoreInMap(resultReleasedNodeV1));
    }

    @Test
    void checkForSetAddress(){
        ResultDeliveryBookingNodeV1 resultDeliveryBookingNodeV1 = SQSEventBodySetup.setBookingNodeV1Address();
        String address = eventMapperSetup.setAddress(resultDeliveryBookingNodeV1);
        assertEquals("Vijayawada,Ibm,Krishna,AP",address);
    }

    @Test
    void checkForSetAddress_empty_address(){
        ResultDeliveryBookingNodeV1 resultDeliveryBookingNodeV1 = SQSEventBodySetup.setEmptyAddressBookingNodeV1();
        String address = eventMapperSetup.setAddress(resultDeliveryBookingNodeV1);
        assertEquals("",address);
    }

    @Test
    void checkForSetAddress_oversize_address(){
        ResultDeliveryBookingNodeV1 booking = SQSEventBodySetup.setAddressRangeExceedsBookingNodeV1();
        String fullAddress = booking.getAddressLine1() + "," +booking.getAddressLine2() +","+booking.getAddressLine3()+","+booking.getAddressLine4();
        String address = eventMapperSetup.setAddress(booking);
        assertNotEquals(fullAddress.length(),address.length());
    }

    @Test
    void checkFor_setScoreInMap(){
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        Map<String, String> componentScores = eventMapperSetup.setScoreInMap(resultReleasedNodeV1);
        assertNotNull(componentScores);
        assertEquals(4, componentScores.size());
    }

    @Test
    void checkFor_setScoreInMap_referenceData_null(){
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        resultReleasedNodeV1.setReferenceData(null);
        Map<String, String> componentScores = eventMapperSetup.setScoreInMap(resultReleasedNodeV1);
        assertNotNull(componentScores);
        assertEquals(0, componentScores.size());
    }

    @Test
    void checkFor_setScoreInMap_default_switch(){
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        resultReleasedNodeV1.getBookingDetails().getBookingLines().get(0).setComponentName("J");
        Map<String, String> componentScores = eventMapperSetup.setScoreInMap(resultReleasedNodeV1);
        assertNotNull(componentScores);
        assertEquals(3, componentScores.size());
    }

    @Test
    void check_dateFormat() {
        LocalDate date = LocalDate.of(2000,3,10);
        String dateInFormat = eventMapperSetup.dateFormat(date);
        assertNotNull(dateInFormat);
        assertEquals("10/03/2000",dateInFormat);
    }

    @Test
    void check_getAgModule() {
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        String agModule = eventMapperSetup.getAgModule(resultReleasedNodeV1);
        assertNotNull(agModule);
        assertEquals("CD",agModule);
    }

    @Test
    void check_getCandidateNumber() {
        String candidateNumber = eventMapperSetup.getCandidateNumber("48");
        assertNotNull(candidateNumber);
        assertEquals("000048",candidateNumber);
    }

    @Test
    void check_convertToCamelCase() {
        String resultStatus = EventMapperSetup.convertToCamelCase("PERMANENTLY_WITHHELD");
        assertNotNull(resultStatus);
        assertEquals("Permanently Withheld",resultStatus);
    }

    @Test
    void check_getLocationDetails() {
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        LocationChangeNodeV1 locationDetails = eventMapperSetup.getLocationDetails(UUID.randomUUID(),resultReleasedNodeV1);
        assertNull(locationDetails);
    }

    @Test
    void check_getSeltIndicator() {
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        String selt = eventMapperSetup.getSeltIndicator(resultReleasedNodeV1);
        assertNotNull(selt);
        assertEquals("0",selt);
    }

    @Test
    void check_getSSRProductUuid() {
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        ResultDeliveryBookingLineNodeV1 bookingLineNodeV1 = eventMapperSetup.getSSRProductUuid(resultReleasedNodeV1);
        assertNotNull(bookingLineNodeV1);
        assertEquals("e873fca7-849b-4e3b-8dfc-b6b5108619ab",bookingLineNodeV1.getBookingLineUuid().toString());
    }

    @Test
    void check_getTestCentreDetails() {
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        UUID locationUuid = eventMapperSetup.getTestCentreDetails(resultReleasedNodeV1);
        assertNotNull(locationUuid);
        assertEquals("e873fca7-849b-4e3b-8dfc-b6b5108619ab",locationUuid.toString());
    }

    @Test
    void check_generateUKVIReferenceNumber() {
        ResultReleasedNodeV1 resultReleasedNodeV1 = SQSEventBodySetup.setResultReleasedNodeV1();
        String ukviReferenceNumber = eventMapperSetup.generateUKVIReferenceNumber(resultReleasedNodeV1);
        assertNotNull(ukviReferenceNumber);
        assertEquals("IEL/29092020/TN0843/918654",ukviReferenceNumber);
    }

    @Test
    void check_getProductCharacteristics() {
        String json = "{\"characteristics\": [\"IOL\", \"SELT\"],\"RoAutoAccepted\": [\"FALSE\"]}";
        ProductCharacteristicsV1 productCharacteristicsV1 = eventMapperSetup.getProductCharacteristicsV1(json);
        assertNotNull(productCharacteristicsV1);
        assertEquals("IOL",productCharacteristicsV1.getCharacteristics().get(0));
    }

    @Test
    void check_getProductCharacteristics_isNull() {
        String json = null;
        ProductCharacteristicsV1 productCharacteristicsV1 = eventMapperSetup.getProductCharacteristicsV1(json);
        assertNotNull(productCharacteristicsV1);
        assertNull(productCharacteristicsV1.getCharacteristics());
    }

    @Test
    void check_getProductCharacteristics_throwException() {
        String json = "invalidJson";
        assertThrows(LdsDistException.class, ()->eventMapperSetup.getProductCharacteristicsV1(json));
    }

}
