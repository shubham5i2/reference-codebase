package com.ielts.cmds.integration.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * MessageDetailsV1Inner
 */
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class MessageDetailsV1Inner {
    @JsonProperty("rec_Id")
    private String recId = null;

    @JsonProperty("resultData")
    private ResultDataV1 resultData = null;

    @JsonProperty("linkedBookings")
    private LinkedBookingsV1 linkedBookings = null;

}
