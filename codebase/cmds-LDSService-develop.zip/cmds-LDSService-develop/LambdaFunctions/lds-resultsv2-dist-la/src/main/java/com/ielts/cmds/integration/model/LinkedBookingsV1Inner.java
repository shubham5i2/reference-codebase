package com.ielts.cmds.integration.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * LinkedBookingsV1Inner
 */

@Getter
@Setter
@ToString
@EqualsAndHashCode
public class LinkedBookingsV1Inner {
    /**
     * Gets or Sets role
     */
    public enum RoleEnum {
        @JsonProperty("SSRORIGINAL")
        SSRORIGINAL("SSRORIGINAL"),
        @JsonProperty("FOR_FUTURE_USE")
        FOR_FUTURE_USE("FOR_FUTURE_USE");

        private String value;

        RoleEnum(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        public static RoleEnum fromValue(String input) {
            for (RoleEnum b : RoleEnum.values()) {
                if (b.value.equals(input)) {
                    return b;
                }
            }
            return null;
        }
    }

    @JsonProperty("role")
    private RoleEnum role = null;

    @JsonProperty("linkedBooking")
    private LinkedBookingDetailsV1 linkedBooking = null;

}
