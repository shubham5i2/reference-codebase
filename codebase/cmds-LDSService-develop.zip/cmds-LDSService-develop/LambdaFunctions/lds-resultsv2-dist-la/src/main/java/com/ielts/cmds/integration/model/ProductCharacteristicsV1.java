package com.ielts.cmds.integration.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class ProductCharacteristicsV1 {

    @JsonProperty(value = "characteristics")
    private List<String> characteristics;

    @JsonProperty(value = "RoAutoAccepted")
    private List<Boolean> roAutoAccepted;
}
