
package com.ielts.cmds.integration.model;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;

/**
 * LinkedBookingsV1
 */

@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper = false)
public class LinkedBookingsV1 extends ArrayList<LinkedBookingsV1Inner> {/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
