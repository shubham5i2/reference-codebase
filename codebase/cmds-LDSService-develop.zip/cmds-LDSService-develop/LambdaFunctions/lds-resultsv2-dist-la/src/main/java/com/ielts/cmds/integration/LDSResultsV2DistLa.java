package com.ielts.cmds.integration;

import com.amazonaws.services.s3.AmazonS3;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.evt004.ResultReleasedNodeV1;
import com.ielts.cmds.api.evt004.TTPhotoNodeV1;
import com.ielts.cmds.api.evt178.PublishStatusV2;
import com.ielts.cmds.integration.constants.LADSConstants;
import com.ielts.cmds.integration.exception.LdsDistClientException;
import com.ielts.cmds.integration.exception.LdsDistException;
import com.ielts.cmds.integration.mapper.EventMapper;
import com.ielts.cmds.integration.model.MessageV1;
import com.ielts.cmds.integration.presign.PresignUrl;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.exception.InvalidClientException;
import com.ielts.cmds.security.exception.TokenNotReceivedException;
import com.ielts.cmds.security.factory.AuthenticationClientFactory;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;
import com.ielts.cmds.serialization.lambda.AbstractLambda;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import software.amazon.awssdk.services.s3.presigner.S3Presigner;

import java.security.KeyStoreException;
import java.security.cert.CertificateException;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Optional;

import static com.ielts.cmds.integration.constants.LADSConstants.CORRELATIONID;
import static com.ielts.cmds.integration.constants.LADSConstants.LA_ENDPOINT_URL;
import static com.ielts.cmds.integration.constants.LADSConstants.LEGACY_RESULT_PUBLISHED_V2;
import static com.ielts.cmds.integration.constants.LADSConstants.PARTNER_CODE;
import static com.ielts.cmds.integration.constants.LADSConstants.TEST_TAKER_BUCKET;
import static com.ielts.cmds.integration.constants.LADSConstants.TRANSACTIONID;
import static com.ielts.cmds.integration.constants.LADSConstants.URL_TIMEOUT;
import static java.time.ZoneOffset.UTC;

/**
 * This class serves the purpose of handling Delivery of photos to Legacy Adapter.
 */
@Slf4j
public class LDSResultsV2DistLa extends AbstractLambda<ResultReleasedNodeV1, PublishStatusV2> {

    private final AuthenticationClientFactory securityAuthenticationFactory;
    private final String laEndpointUrl;
    private final String ttPhotoBucket;
    private final String timeout;
    private final AmazonS3 s3Client;
    private final S3Presigner presigner;
    private final PresignUrl presignUrl;
    private final EventMapper eventMapper;
    private final String topicArn;

    public LDSResultsV2DistLa() {
        this.topicArn = System.getenv(LADSConstants.LDS_INT_TOPIC_IN);
        this.securityAuthenticationFactory = new EnvironmentAwareAuthenticationClientFactory();
        this.laEndpointUrl = System.getenv(LA_ENDPOINT_URL);
        this.ttPhotoBucket = System.getenv(TEST_TAKER_BUCKET);
        this.timeout = System.getenv(URL_TIMEOUT);
        this.s3Client =  S3Config.s3Client();
        this.presignUrl = new PresignUrl();
        this.eventMapper = new EventMapper();
        this.presigner = S3Config.s3Presigner();

    }

    @Override
    protected String getTopicName() {
        return topicArn;
    }

    @Override
    protected PublishStatusV2 processRequest(ResultReleasedNodeV1 resultReleasedNodeV1) throws LdsDistException {
        PublishStatusV2 publishStatusV2 = buildLegacyResultPublishStatusEvent(resultReleasedNodeV1);
        try {
        	final String presignedUrl = getPresignedUrlForPhoto(resultReleasedNodeV1);
            postRequestToLa(eventMapper.mapIncomingResultToLA(resultReleasedNodeV1, presignedUrl));
        } catch (LdsDistClientException | HttpClientErrorException ex) {
            log.info("Received 4X response");
            log.error("Client Exception on processing event ", ex);
            publishStatusV2.setStatus("FAILED");
        }
        buildHeader();
        log.info("publishing ack event body : {} ",publishStatusV2);
        return publishStatusV2;
    }

    String getPresignedUrlForPhoto(ResultReleasedNodeV1 resultReleased) {
        String testDayPhotoPresignUrl = "";
        if (Objects.nonNull(resultReleased) && Objects.nonNull(resultReleased.getTtPhotoDetails())) {

                Optional<String> optionalTtPhotoPath = resultReleased.getTtPhotoDetails().stream()
                        .filter(photo -> TTPhotoNodeV1.PhotoCategoryEnum.CERTIFICATE == photo.getPhotoCategory())
                        .map(TTPhotoNodeV1::getFilePath).findFirst();

                String ttPhotoPath = optionalTtPhotoPath.orElseThrow(() -> new LdsDistException
                        ("Test Taker Photo not received"));
                testDayPhotoPresignUrl = generatePresignedUrl(ttPhotoPath);
                log.debug("result: {} ", testDayPhotoPresignUrl);
        }
        return testDayPhotoPresignUrl;
    }


    String generatePresignedUrl(final String photoPath) {
    	if(!s3Client.doesBucketExistV2(ttPhotoBucket)) {
    		log.error("S3 Bucket {} doesn't exist ", ttPhotoBucket);
    		throw new LdsDistClientException("S3 Bucket Does Not Exist");
    	}
    	if(!s3Client.doesObjectExist(ttPhotoBucket, photoPath)) {
    		log.error("S3 Object with path {} doesn't exist in the bucket {}", photoPath, ttPhotoBucket);
    		throw new LdsDistClientException("S3 Object Does Not Exist in the Bucket");
    	}
    	return presignUrl.handlePresign(presigner, timeout, ttPhotoBucket, photoPath);
    }

    ResponseEntity<String> postRequestToLa(MessageV1 responseBody) {
        try {
        	final AuthenticationClient authenticationClient = getAuthenticationClient();
            log.debug("Request object to LA: {} ",responseBody);
            final HttpHeaders eventHeaders = getHttpHeaders(authenticationClient);
            final HttpEntity<?> eventEntity = new HttpEntity<>(responseBody, eventHeaders);
            final ResponseEntity<String> response = authenticationClient.getRestTemplate()
                    .postForEntity(laEndpointUrl, eventEntity, String.class);
            log.info("Response code {} ", response.getStatusCode());
            return response;
        } catch (InvalidClientException | TokenNotReceivedException |  JsonProcessingException | CertificateException | KeyStoreException  ex) {
            log.error(" Exception on posting requestBody: ", ex);
            throw new LdsDistClientException(ex.getMessage());
        }
    }

    HttpHeaders getHttpHeaders(final AuthenticationClient authenticationClient) 
    		throws TokenNotReceivedException, JsonProcessingException, CertificateException, KeyStoreException{
        final HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.set(TRANSACTIONID, String.valueOf(ThreadLocalHeaderContext.getContext().getTransactionId()));
        httpHeaders.set(CORRELATIONID, String.valueOf(ThreadLocalHeaderContext.getContext().getCorrelationId()));
        httpHeaders.set(PARTNER_CODE, LADSConstants.CA);
        httpHeaders.set(authenticationClient.getAuthorizationHeaderName(), authenticationClient.getAccessToken());
        return httpHeaders;
    }

    public void buildHeader() {
        HeaderContext eventHeader = ThreadLocalHeaderContext.getContext();
        eventHeader.setEventName(LEGACY_RESULT_PUBLISHED_V2);
        eventHeader.setEventDateTime(LocalDateTime.now(UTC));
        ThreadLocalHeaderContext.setContext(eventHeader);
    }

    PublishStatusV2 buildLegacyResultPublishStatusEvent(ResultReleasedNodeV1 resultReleasedNodeV1){
        PublishStatusV2 publishStatusV2 = new PublishStatusV2();
        publishStatusV2.setBookingUuid(resultReleasedNodeV1.getBookingDetails().getBookingUuid());
        publishStatusV2.setResultUuid(resultReleasedNodeV1.getResultDetails().getResultUuid());
        publishStatusV2.setStatus("PUBLISHED");
        return publishStatusV2;
    }

    AuthenticationClient getAuthenticationClient() throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException, InvalidClientException {
        return securityAuthenticationFactory.getAuthenticationClient(LADSConstants.CA);
    }
}
