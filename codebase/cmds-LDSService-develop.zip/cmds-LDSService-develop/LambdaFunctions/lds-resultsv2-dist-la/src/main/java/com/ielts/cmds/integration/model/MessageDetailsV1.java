package com.ielts.cmds.integration.model;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
/**
 * MessageDetailsV1
 */

@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper = false)
public class MessageDetailsV1 extends ArrayList<MessageDetailsV1Inner> {/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
