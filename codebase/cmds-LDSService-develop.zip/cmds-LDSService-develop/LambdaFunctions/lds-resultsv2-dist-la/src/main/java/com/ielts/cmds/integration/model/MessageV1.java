package com.ielts.cmds.integration.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * MessageV1
 */
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class MessageV1 {
    @JsonProperty("msg")
    private MessageDetailsV1 msg = null;
}
