package com.ielts.cmds.integration.mapper;

import com.ielts.cmds.api.evt004.LocationChangeNodeV1;
import com.ielts.cmds.api.evt004.ResultDeliveryBookingLineNodeV1;
import com.ielts.cmds.api.evt004.ResultDeliveryBookingLinkNodeV1;
import com.ielts.cmds.api.evt004.ResultReleasedNodeV1;
import com.ielts.cmds.integration.model.LinkedBookingDetailsV1;
import com.ielts.cmds.integration.model.LinkedBookingsV1;
import com.ielts.cmds.integration.model.LinkedBookingsV1Inner;
import com.ielts.cmds.integration.model.MessageDetailsV1;
import com.ielts.cmds.integration.model.MessageDetailsV1Inner;
import com.ielts.cmds.integration.model.MessageV1;
import com.ielts.cmds.integration.model.ResultDataV1;
import com.ielts.cmds.integration.utils.EventMapperSetup;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/**
 * This class is used to map incoming event to appropriate API request body
 */
@Slf4j
public class EventMapper {

    public MessageV1 mapIncomingResultToLA(ResultReleasedNodeV1 resultReleased, String result) {
        EventMapperSetup eventMapperSetup = new EventMapperSetup();
        MessageV1 messageV1 = new MessageV1();
        MessageDetailsV1 messageDetailsV1 = new MessageDetailsV1();
        MessageDetailsV1Inner messageDetailsV1Inner = new MessageDetailsV1Inner();
        messageDetailsV1Inner.setRecId(UUID.randomUUID().toString());

        ResultDataV1 resultDataV1 = createResultData(resultReleased, eventMapperSetup, result);

        setSeltIndicator(resultDataV1, resultReleased, eventMapperSetup);

        setLocationDetails(resultDataV1, resultReleased, eventMapperSetup);
        setCandidateDetails(resultDataV1, resultReleased, eventMapperSetup);
        setAdditionalDetails(resultDataV1, resultReleased, eventMapperSetup);

        setScoresAndPercentage(resultDataV1, resultReleased, eventMapperSetup);

        if(Objects.nonNull(resultReleased.getBookingDetails().getBookingLinks())) {
            setSSRBookingSpecificFields(resultDataV1, resultReleased, messageDetailsV1Inner, eventMapperSetup);
        }

        log.info("Listening result:{}", resultDataV1.getListeningResult());
        log.info("Speaking result:{}", resultDataV1.getSpeakingResult());

        messageDetailsV1Inner.setResultData(resultDataV1);
        messageDetailsV1.add(messageDetailsV1Inner);
        messageV1.setMsg(messageDetailsV1);
        log.info("in event mapper!! mapping done !");
        return messageV1;
    }

    private ResultDataV1 createResultData(ResultReleasedNodeV1 resultReleased, EventMapperSetup eventMapperSetup, String result) {
        ResultDataV1 resultDataV1 = new ResultDataV1();

        String tempAddress = getNonEmptyString(eventMapperSetup.setAddress(resultReleased.getBookingDetails()));
        if (tempAddress != null) {
            resultDataV1.setAddress(tempAddress);
        }
        if (resultReleased.getBookingDetails().getEmail() != null) {
            resultDataV1.setEmail(getNonEmptyString(resultReleased.getBookingDetails().getEmail()));
        }
        resultDataV1.setYearsStudy(resultReleased.getBookingDetails().getYearsOfStudy());
        resultDataV1.setFirstLangCode((getNonEmptyString(String.valueOf(resultReleased.getBookingDetails().getLanguageUuid()))));
        resultDataV1.setReasonId((getNonEmptyString(String.valueOf(resultReleased.getBookingDetails().getReasonForTestUuid()))));
        resultDataV1.setJobId((getNonEmptyString(String.valueOf(resultReleased.getBookingDetails().getOccupationSectorUuid()))));
        resultDataV1.setLevelId((getNonEmptyString(String.valueOf(resultReleased.getBookingDetails().getOccupationLevelUuid()))));
        resultDataV1.setNationalityCode((getNonEmptyString(String.valueOf(resultReleased.getBookingDetails().getNationalityUuid()))));
        resultDataV1.setIdIssuingAuthority(getNonEmptyString(resultReleased.getBookingDetails().getIdentityIssuingAuthority()));
        resultDataV1.setIdExpiryDate(getNonEmptyString(eventMapperSetup.dateFormat(resultReleased.getBookingDetails().getIdentityExpiryDate())));
        resultDataV1.setIdType((getNonEmptyString(String.valueOf(resultReleased.getBookingDetails().getIdentityTypeUuid()))));
        resultDataV1.setIdNumber(getNonEmptyString(resultReleased.getBookingDetails().getIdentityNumber()));
        resultDataV1.setAgModual(getNonEmptyString(eventMapperSetup.getAgModule(resultReleased)));
        resultDataV1.setCbielts(1);
        resultDataV1.setCertid(getNonEmptyString(resultReleased.getResultDetails().getTrfNumber()));
        if(Objects.nonNull(resultReleased.getBookingDetails().getAgentName())) {
            resultDataV1.setAgentRepName(getNonEmptyString(resultReleased.getBookingDetails().getAgentName()));
        }
        resultDataV1.setCefrScore(getNonEmptyString(resultReleased.getResultDetails().getCefrLevel()));
        //get status from reference data
        resultDataV1.setResultStatus(EventMapperSetup.convertToCamelCase(getNonEmptyString(eventMapperSetup.getReferenceValue(resultReleased, resultReleased.getResultDetails().getResultsStatusTypeUuid()))));
        resultDataV1.setSittingDate(getNonEmptyString(eventMapperSetup.dateFormat(resultReleased.getBookingDetails().getTestDate())));
        resultDataV1.setQualification("International English Language Testing System");
        resultDataV1.setAssessmentcode((getNonEmptyString(String.valueOf(resultReleased.getBookingDetails().getProductUuid()))));
        resultDataV1.setCandidateRegistrationPhoto("");
        resultDataV1.setCandidateTestdayPhoto(getNonEmptyString(result));


        return resultDataV1;
    }

    private void setSeltIndicator(ResultDataV1 resultDataV1, ResultReleasedNodeV1 resultReleased, EventMapperSetup eventMapperSetup) {
        resultDataV1.setSeltIndicator(getNonEmptyString(eventMapperSetup.getSeltIndicator(resultReleased)));
        if (resultDataV1.getSeltIndicator().equals("1")) {
            resultDataV1.setUkviERefId(getNonEmptyString(eventMapperSetup.generateUKVIReferenceNumber(resultReleased)));
            resultDataV1.setLocationUuid(resultReleased.getBookingDetails().getLocationUuid());
            resultDataV1.setTestCentreUuid(eventMapperSetup.getTestCentreDetails(resultReleased));
        }
        resultDataV1.setLsIndicator("0");
    }

    private void setLocationDetails(ResultDataV1 resultDataV1, ResultReleasedNodeV1 resultReleased, EventMapperSetup eventMapperSetup) {
        LocationChangeNodeV1 locationChangeNodeV1 = eventMapperSetup.getLocationDetails(resultReleased.getBookingDetails().getLocationUuid(), resultReleased);
        if(Objects.nonNull(locationChangeNodeV1)) {
            resultDataV1.setCentreNumber(getNonEmptyString(locationChangeNodeV1.getTestCentreNumber()));
        }
    }

    private void setCandidateDetails(ResultDataV1 resultDataV1, ResultReleasedNodeV1 resultReleased, EventMapperSetup eventMapperSetup) {
        resultDataV1.setCandidateNumber(getNonEmptyString(eventMapperSetup.getCandidateNumber(String.valueOf(resultReleased.getBookingDetails().getShortCandidateNumber()))));
        resultDataV1.setCompositeCandidateNumber(resultReleased.getBookingDetails().getCompositeCandidateNumber());
		resultDataV1.setTestDate(getNonEmptyString(eventMapperSetup.dateFormat(resultReleased.getBookingDetails().getTestDate())));
        resultDataV1.setOverallResult(BigDecimal.valueOf(resultReleased.getResultDetails().getResultScore()));
    }

    private void setAdditionalDetails(ResultDataV1 resultDataV1, ResultReleasedNodeV1 resultReleased, EventMapperSetup eventMapperSetup) {

        if (resultReleased.getBookingDetails().getTitle() != null) {
            resultDataV1.setTitle(getNonEmptyString(resultReleased.getBookingDetails().getTitle()));
        }
        if(resultReleased.getBookingDetails().getLastName() != null) {
            resultDataV1.setFamilyName(getNonEmptyString(resultReleased.getBookingDetails().getLastName()));
        }
        if(resultReleased.getBookingDetails().getFirstName() != null) {
            resultDataV1.setGivenName(getNonEmptyString(resultReleased.getBookingDetails().getFirstName()));
        }
        resultDataV1.setGender(getNonEmptyString(eventMapperSetup.getReferenceValue(resultReleased, resultReleased.getBookingDetails().getSexUuid())));
        resultDataV1.setDateOfBirth(getNonEmptyString(eventMapperSetup.dateFormat(resultReleased.getBookingDetails().getBirthDate())));
        if (resultReleased.getBookingDetails().getPhone() != null) {
            resultDataV1.setTelephone(getNonEmptyString(resultReleased.getBookingDetails().getPhone()));
        }
        if (resultReleased.getBookingDetails().getCity() != null) {
            resultDataV1.setTown(getNonEmptyString(resultReleased.getBookingDetails().getCity()));
        }
        if (resultReleased.getBookingDetails().getPostalCode() != null) {
            resultDataV1.setPostcode(getNonEmptyString(resultReleased.getBookingDetails().getPostalCode()));
        }
        resultDataV1.setCountryCode(getNonEmptyString(eventMapperSetup.getReferenceValue(resultReleased, resultReleased.getBookingDetails().getCountryUuid())));
        resultDataV1.setRegion(getNonEmptyString(eventMapperSetup.getReferenceValue(resultReleased, resultReleased.getBookingDetails().getCountryUuid())));

    }

    private void setScoresAndPercentage(ResultDataV1 resultDataV1, ResultReleasedNodeV1 resultReleased, EventMapperSetup eventMapperSetup) {
        Map<String, String> componentScore = eventMapperSetup.setScoreInMap(resultReleased);
        resultDataV1.setListeningResult(componentScore.get("L"));
        resultDataV1.setReadingResult(componentScore.get("R"));
        resultDataV1.setWritingResult(componentScore.get("W"));
        resultDataV1.setSpeakingResult(componentScore.get("S"));

        Double listeningScore = Double.parseDouble(resultDataV1.getListeningResult());
        Double readingScore = Double.parseDouble(resultDataV1.getReadingResult());
        Double writingScore = Double.parseDouble(resultDataV1.getWritingResult());
        Double speakingScore = Double.parseDouble(resultDataV1.getSpeakingResult());

        Double percentageScore= ((listeningScore+readingScore+writingScore+speakingScore)/36)*100;
        resultDataV1.setPercentageScore((int) Math.round(percentageScore));

        log.info("Listening {} !! Reading {} !! Writing {} !! Speaking {} !", listeningScore, readingScore, writingScore, speakingScore);
        log.info("Percentage score {} !", percentageScore);

        resultDataV1.setIbaseLastModified(getNonEmptyString(LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy'T'HH:mm:ss"))));
        resultDataV1.setRefundFlag(0);
        resultDataV1.setRemarks(getNonEmptyString(resultReleased.getResultDetails().getAdministratorComments()));
    }

    private void setSSRBookingSpecificFields(ResultDataV1 resultDataV1, ResultReleasedNodeV1 resultReleased, MessageDetailsV1Inner messageDetailsV1Inner, EventMapperSetup eventMapperSetup) {
        ResultDeliveryBookingLineNodeV1 bookingLine = eventMapperSetup.getSSRProductUuid(resultReleased);
        if(Objects.nonNull(bookingLine)) {
            resultDataV1.setSsrProductUuid(bookingLine.getProductUuid());
        }
        LinkedBookingsV1 linkedBookingsV1 = createLinkedBookings(resultReleased, eventMapperSetup);
        messageDetailsV1Inner.setLinkedBookings(linkedBookingsV1);
    }

    private LinkedBookingsV1 createLinkedBookings(ResultReleasedNodeV1 resultReleasedNodeV1, EventMapperSetup eventMapperSetup) {
        LinkedBookingsV1 linkedBookingsV1 = new LinkedBookingsV1();
        for(ResultDeliveryBookingLinkNodeV1 bookingLink : resultReleasedNodeV1.getBookingDetails().getBookingLinks()) {
            LinkedBookingsV1Inner linkedBookingsV1Inner = new LinkedBookingsV1Inner();
            linkedBookingsV1Inner.setRole(LinkedBookingsV1Inner.RoleEnum.fromValue(bookingLink.getRole().toString()));
            LinkedBookingDetailsV1 linkedBookingDetailsV1 = new LinkedBookingDetailsV1();
            linkedBookingDetailsV1.setCandidateNumber(getNonEmptyString(eventMapperSetup.getCandidateNumber(bookingLink.getLinkedBooking().getShortCandidateNumber().toString())));
            linkedBookingDetailsV1.setTestDate(getNonEmptyString(eventMapperSetup.dateFormat(bookingLink.getLinkedBooking().getTestDate())));
            LocationChangeNodeV1 locationChangeNodeV1 = eventMapperSetup.getLocationDetails(bookingLink.getLinkedBooking().getLocationUuid(),resultReleasedNodeV1);
            if(Objects.nonNull(locationChangeNodeV1)) {
                linkedBookingDetailsV1.setCentreNumber(getNonEmptyString(locationChangeNodeV1.getTestCentreNumber()));
            }
            linkedBookingsV1Inner.setLinkedBooking(linkedBookingDetailsV1);
            linkedBookingsV1.add(linkedBookingsV1Inner);
        }
        return linkedBookingsV1;
    }

    public String getNonEmptyString(String value) {
        if(StringUtils.isEmpty(value)) {
            return null;
        }
        else {
            return value;
        }
    }


}


