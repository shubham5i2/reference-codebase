package com.ielts.cmds.integration.constants;

public class LADSConstants {

    private LADSConstants() {}

    public static final String TRANSACTIONID = "transactionId";
    public static final String CORRELATIONID = "correlationId";
    public static final String PARTNER_CODE = "partnerCode";
    public static final String CA = "CA";
    public static final String LA_ENDPOINT_URL = "endpoint_url";
    public static final String URL_TIMEOUT ="presigned_url_timeout_second";
    public static final String REGION = "AWS_REGION";
    public static final String TEST_CENTRE= "TEST_CENTRE";
    public static final String ACTIVE = "ACTIVE";
    public static final String UKVI_REFERENCE_NUMBER_STRUCTURE = "IEL/[TEST_DATE]/[CENTRE_NUMBER]/[CANDIDATE_NUMBER]";
    public static final String CLIENT_ID = "client_id";
    public static final String CLIENT_SECRET = "client_secret";
    public static final String ACCESS_TOKEN = "access_token";
    public static final String CA_AUTH_URL = "ca_auth_url";
    public static final String TEST_TAKER_BUCKET = "tt_photo_bucket_name";
    public static final String LEGACY_RESULT_PUBLISHED_V2 = "LegacyResultPublishedV2";
    public static final String LDS_INT_TOPIC_IN = "lds_int_topic_in_arn";




}
