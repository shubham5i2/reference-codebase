package com.ielts.cmds.integration.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * ResultDataV1
 */

@Getter
@Setter
@ToString
@EqualsAndHashCode
public class ResultDataV1 {
  @JsonProperty("seltIndicator")
  private String seltIndicator = null;

  @JsonProperty("lsIndicator")
  private String lsIndicator = null;

  @JsonProperty("centreNumber")
  private String centreNumber = null;

  @JsonProperty("candidateNumber")
  private String candidateNumber = null;

  @JsonProperty("testDate")
  private String testDate = null;

  @JsonProperty("compositeCandidateNumber")
  private String compositeCandidateNumber = null;

  @JsonProperty("overallResult")
  private BigDecimal overallResult = null;

  @JsonProperty("title")
  private String title = null;

  @JsonProperty("familyName")
  private String familyName = null;

  @JsonProperty("givenName")
  private String givenName = null;

  @JsonProperty("gender")
  private String gender = null;

  @JsonProperty("dateOfBirth")
  private String dateOfBirth = null;

  @JsonProperty("telephone")
  private String telephone = null;

  @JsonProperty("town")
  private String town = null;

  @JsonProperty("postcode")
  private String postcode = null;

  @JsonProperty("countryCode")
  private String countryCode = null;

  @JsonProperty("region")
  private String region = null;

  @JsonProperty("address")
  private String address = null;

  @JsonProperty("email")
  private String email = null;

  @JsonProperty("yearsStudy")
  private Integer yearsStudy = null;

  @JsonProperty("firstLangCode")
  private String firstLangCode = null;

  @JsonProperty("reasonId")
  private String reasonId = null;

  @JsonProperty("jobId")
  private String jobId = null;

  @JsonProperty("levelId")
  private String levelId = null;

  @JsonProperty("nationalityCode")
  private String nationalityCode = null;

  @JsonProperty("idIssuingAuthority")
  private String idIssuingAuthority = null;

  @JsonProperty("idExpiryDate")
  private String idExpiryDate = null;

  @JsonProperty("idType")
  private String idType = null;

  @JsonProperty("idNumber")
  private String idNumber = null;

  @JsonProperty("agModual")
  private String agModual = null;

  @JsonProperty("cbielts")
  private Integer cbielts = null;

  @JsonProperty("certid")
  private String certid = null;

  @JsonProperty("agentRepName")
  private String agentRepName = null;

  @JsonProperty("ukviERefId")
  private String ukviERefId = null;

  @JsonProperty("cefrScore")
  private String cefrScore = null;

  @JsonProperty("percentageScore")
  private Integer percentageScore = null;

  @JsonProperty("resultStatus")
  private String resultStatus = null;

  @JsonProperty("locationUuid")
  private UUID locationUuid = null;

  @JsonProperty("testCentreUuid")
  private UUID testCentreUuid = null;

  @JsonProperty("sittingDate")
  private String sittingDate = null;

  @JsonProperty("qualification")
  private String qualification = null;

  @JsonProperty("assessmentcode")
  private String assessmentcode = null;

  @JsonProperty("candidateRegistrationPhoto")
  private String candidateRegistrationPhoto = null;

  @JsonProperty("candidateTestdayPhoto")
  private String candidateTestdayPhoto = null;

  @JsonProperty("listeningResult")
  private String listeningResult = null;

  @JsonProperty("readingResult")
  private String readingResult = null;

  @JsonProperty("speakingResult")
  private String speakingResult = null;

  @JsonProperty("writingResult")
  private String writingResult = null;

  @JsonProperty("ibaseLastModified")
  private String ibaseLastModified = null;

  @JsonProperty("refundFlag")
  private Integer refundFlag = null;

  @JsonProperty("ssrProductUuid")
  private UUID ssrProductUuid = null;

  @JsonProperty("remarks")
  private String remarks = null;

}
