package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.constants.DistORSConstants.EVENT_NAME;
import static com.ielts.cmds.integration.constants.DistORSConstants.EVENT_NAME_FAILED;
import static com.ielts.cmds.integration.constants.DistORSConstants.PARTNER_CODE;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.ielts.cmds.integration.constants.DistORSConstants;
import com.ielts.cmds.integration.utils.SQSEventBodySetup;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.clients.CAAuthenticationClient;
import com.ielts.cmds.security.factory.AuthenticationClientFactory;
import com.ielts.cmds.security.utils.CAToken;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import java.util.UUID;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

@ExtendWith(MockitoExtension.class)
class RDSelectionDeliveredDistLaTest {

    @Mock
    CAAuthenticationClient authenticationClient;

    @Mock
    private RDSelectionDeliveredDistLa rdSelectionDeliveredDistLa;

    @Mock
    private AuthenticationClientFactory securityAuthenticationFactory;

    @Mock
    private RestTemplate restTemplate;

    OrganisationSelectionNodeV1 organisationSelectionNodeV1;

    @BeforeEach
    public void setUp() {
        //this.securityAuthenticationFactory = new EnvironmentAwareAuthenticationClientFactory();

        ReflectionTestUtils.setField(rdSelectionDeliveredDistLa, "extCallbackUrl", "https://withdrawendpoint.orsdomain.com");
        ReflectionTestUtils.setField(rdSelectionDeliveredDistLa, "securityAuthenticationFactory", securityAuthenticationFactory);

        organisationSelectionNodeV1 = SQSEventBodySetup.getROSelection();

        HeaderContext headerCtx = new HeaderContext();
        headerCtx.setPartnerCode("CA");
        headerCtx.setEventName("EventName");
        headerCtx.setCorrelationId(UUID.randomUUID());
        headerCtx.setTransactionId(UUID.randomUUID());
        ThreadLocalHeaderContext.setContext(headerCtx);
    }

    @Test
    void getPartnerCodeConstants_whengetPartnerCodeConstants_thenReturnCA() {
        RDSelectionDeliveredDistLa selectionDeliveredDistLaSpy = Mockito.spy(rdSelectionDeliveredDistLa);
        String partnerCodeConstants = selectionDeliveredDistLaSpy.getPartnerCodeConstant();
        Assertions.assertEquals(DistORSConstants.CA, partnerCodeConstants);
    }

    @Test
    void check_getApplicationName() {
        RDSelectionDeliveredDistLa selectionDeliveredDistLaSpy = Mockito.spy(rdSelectionDeliveredDistLa);
        String applicationName = selectionDeliveredDistLaSpy.getApplicationName();
        Assertions.assertEquals(DistORSConstants.ORGANISATION_SELECTION_DELIVERED_LA, applicationName);
    }

    @Test
    void handle_request_headers_with_exception() throws Exception {
        RDSelectionDeliveredDistLa selectionDeliveredDistLaSpy = Mockito.spy(rdSelectionDeliveredDistLa);
        doThrow(new RuntimeException()).when(selectionDeliveredDistLaSpy).getAuthenticationClient("CA");
        Executable exe = () -> selectionDeliveredDistLaSpy.processRequest(organisationSelectionNodeV1);
        assertThrows(RuntimeException.class, exe);
    }

    @Test
    void handle_request_headers_tokenException() throws Exception {
        RDSelectionDeliveredDistLa selectionDeliveredDistLaSpy = Mockito.spy(rdSelectionDeliveredDistLa);
        doReturn(authenticationClient).when(selectionDeliveredDistLaSpy).getAuthenticationClient("CA");
        AuthenticationClient authenticationClient = selectionDeliveredDistLaSpy.getAuthenticationClient("CA");
        Executable exe = () -> selectionDeliveredDistLaSpy.getHttpHeaders(ThreadLocalHeaderContext.getContext(), authenticationClient);
        assertThrows(RuntimeException.class, exe);

    }

    @Test
    void handle_request_http_response_is_400() throws Exception {
        RDSelectionDeliveredDistLa selectionDeliveredDistLaSpy = Mockito.spy(rdSelectionDeliveredDistLa);

        CAToken caToken = new CAToken();
        caToken.setAccessToken("accessToken");
        caToken.setExpiresIn(132984);
        caToken.setScope("Scope");
        caToken.setTokenType("Bearer");

        ResponseEntity<String> response = new ResponseEntity<>(HttpStatus.BAD_REQUEST);

        doReturn(authenticationClient).when(selectionDeliveredDistLaSpy).getAuthenticationClient("CA");
        doReturn("accessToken").when(authenticationClient).getAccessToken();
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        lenient().doReturn(caToken).when(restTemplate).postForObject(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpEntity.class),
                ArgumentMatchers.eq(Class.class));
        doReturn("authHeaderName").when(authenticationClient).getAuthorizationHeaderName();

        doReturn(response).when(restTemplate).postForEntity(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpEntity.class),
                ArgumentMatchers.eq(String.class));

        Executable exe = () -> selectionDeliveredDistLaSpy.processRequest(organisationSelectionNodeV1);
        assertDoesNotThrow(exe);
        Assertions.assertEquals(response.getStatusCodeValue(), HttpStatus.BAD_REQUEST.value());

    }

    @Test
    void handle_request_call() throws Exception {
        RDSelectionDeliveredDistLa selectionDeliveredDistLaSpy = Mockito.spy(rdSelectionDeliveredDistLa);

        CAToken caToken = new CAToken();
        caToken.setAccessToken("accessToken");
        caToken.setExpiresIn(132984);
        caToken.setScope("Scope");
        caToken.setTokenType("Bearer");

        ResponseEntity<String> response = new ResponseEntity<>(HttpStatus.OK);

        doReturn(authenticationClient).when(selectionDeliveredDistLaSpy).getAuthenticationClient("CA");
        doReturn("accessToken").when(authenticationClient).getAccessToken();
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        lenient().doReturn(caToken).when(restTemplate).postForObject(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.eq(Class.class));
        doReturn("authHeaderName").when(authenticationClient).getAuthorizationHeaderName();

        doReturn(response).when(restTemplate).postForEntity(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.eq(String.class));

        Executable exe = () -> selectionDeliveredDistLaSpy.processRequest(organisationSelectionNodeV1);
        assertDoesNotThrow(exe);
        Assertions.assertEquals(response.getStatusCodeValue(), HttpStatus.OK.value());
    }

    @Test
    void verifyCallTo_authClient() throws Exception {
        RDSelectionDeliveredDistLa selectionDeliveredDistLaSpy = Mockito.spy(rdSelectionDeliveredDistLa);

        doReturn(authenticationClient).when(selectionDeliveredDistLaSpy).getAuthenticationClient("CA");
        AuthenticationClient authClient = selectionDeliveredDistLaSpy.getAuthenticationClient("CA");
        Assertions.assertEquals(authenticationClient, authClient);
    }

  @Test
  void buildHeaderTestWithSuccessEvent() {

    HeaderContext eventHeader = ThreadLocalHeaderContext.getContext();
    eventHeader.setEventName(EVENT_NAME);
    Assertions.assertEquals(EVENT_NAME,eventHeader.getEventName());
  }

  @Test
  void buildHeaderTestWithFailureEvent() {

    HeaderContext eventHeader = ThreadLocalHeaderContext.getContext();
    eventHeader.setEventName(EVENT_NAME_FAILED);
    Assertions.assertEquals(EVENT_NAME_FAILED,eventHeader.getEventName());
  }

    @Test
    void buildHeader_test() {
        RDSelectionDeliveredDistLa selectionDeliveredDistLaSpy = Mockito.spy(rdSelectionDeliveredDistLa);
        ThreadLocalHeaderContext.getContext().setPartnerCode("IDP");
        String partnerCode = ThreadLocalHeaderContext.getContext().getPartnerCode();
        assertNotEquals(EVENT_NAME,ThreadLocalHeaderContext.getContext().getEventName());
        selectionDeliveredDistLaSpy.buildHeader(EVENT_NAME);
        assertEquals(EVENT_NAME,ThreadLocalHeaderContext.getContext().getEventName());
        assertEquals(partnerCode,ThreadLocalHeaderContext.getContext().getPartnerCode());
        assertEquals("IDP",partnerCode);

    }

    @Test
    void handle_request_call_restClient_exception() throws Exception {
        RDSelectionDeliveredDistLa selectionDeliveredDistLaSpy = Mockito.spy(rdSelectionDeliveredDistLa);

        CAToken caToken = new CAToken();
        caToken.setAccessToken("accessToken");
        caToken.setExpiresIn(132984);
        caToken.setScope("Scope");
        caToken.setTokenType("Bearer");

        ReflectionTestUtils.setField(selectionDeliveredDistLaSpy, "securityAuthenticationFactory",
                securityAuthenticationFactory);
        ReflectionTestUtils.setField(selectionDeliveredDistLaSpy, "extCallbackUrl", "https://withdrawendpoint.orsdomain.com");
        doReturn(authenticationClient).when(selectionDeliveredDistLaSpy).getAuthenticationClient("CA");
        doReturn("accessToken").when(authenticationClient).getAccessToken();
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();

        doThrow(HttpClientErrorException.class)
                .when(restTemplate)
                .postForEntity(ArgumentMatchers.anyString(), ArgumentMatchers.any(), ArgumentMatchers.any());

        doReturn("authHeaderName").when(authenticationClient).getAuthorizationHeaderName();

        assertDoesNotThrow(() -> selectionDeliveredDistLaSpy.processRequest(organisationSelectionNodeV1));
    }

    @Test
    void testGetAuthenticationClient() throws Exception {
        RDSelectionDeliveredDistLa selectionDeliveredDistLaSpy = Mockito.spy(rdSelectionDeliveredDistLa);

        when(securityAuthenticationFactory.getAuthenticationClient("CA")).thenReturn(authenticationClient);
        assertNotNull(selectionDeliveredDistLaSpy.getAuthenticationClient("CA"));
    }

    @Test
    void testGetTopicName() {
        RDSelectionDeliveredDistLa selectionDeliveredDistLaSpy = Mockito.spy(rdSelectionDeliveredDistLa);
        assertNull(selectionDeliveredDistLaSpy.getTopicName());
    }
}
