package com.ielts.cmds.integration.constants;

public class DistORSConstantsUtils {


    private DistORSConstantsUtils() {}

    public static final String CLIENT_ID = "client_id";
    public static final String CLIENT_SECRET = "client_secret";
    public static final String AUTH_HEADER = "auth_header";
    public static final String AUTH_HEADER_NAME = "Authorization";
    public static final String ACCESS_TOKEN = "access_token";
}
