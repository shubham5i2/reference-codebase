package com.ielts.cmds.integration.utils;

import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.constants.DistORSConstants;
import com.ielts.cmds.integration.constants.DistORSConstantsUtils;
import com.ielts.cmds.rd.domain.model.enums.ComponentEnum;
import com.ielts.cmds.rd.domain.model.enums.ConfirmationStatusEnum;
import com.ielts.cmds.rd.domain.model.enums.DeliveryStatusEnum;
import com.ielts.cmds.rd.domain.model.out.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class SQSEventBodySetup {

    private static final ObjectMapper mapper = getMapper();

    public static BaseEvent<BaseHeader> getEventRequest() throws JsonProcessingException {
        BaseEvent<BaseHeader> event = new BaseEvent<>();
        event.setEventHeader(populateEventHeader());
        event.setEventBody(mapper.writeValueAsString(getROSelection()));
        event.setEventErrors(null);
        return event;
    }

    public static BaseHeader populateEventHeader() {
        final BaseHeader eventHeader = new BaseHeader();
        eventHeader.setCorrelationId(UUID.fromString("f4cd7c74-8277-44a2-95a6-29e0d96aca1a"));
        eventHeader.setTransactionId(UUID.fromString("9865f5ba-2c82-491b-a807-c12afcf8eb3a"));
        eventHeader.setEventDateTime(
                LocalDateTime.parse(
                        "2020-09-29T21:00:35.723Z",
                        DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")));
        eventHeader.setEventName("ReceivingOrganisationSelectionChanged");
        eventHeader.setPartnerCode("CA");
        return eventHeader;
    }

    public static BaseEvent<BaseHeader> populateBaseEventWithError() throws JsonProcessingException {

        OrganisationSelectionNodeV1 selectionNodeV1 = getROSelection();
        String eventBody = mapper.writeValueAsString(selectionNodeV1);

        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        baseEvent.setEventHeader(populateEventHeader());
        baseEvent.setEventBody(eventBody);
        baseEvent.setEventErrors(getErrors());
        return baseEvent;
    }

    public static OrganisationSelectionNodeV1 getROSelection() {

        OrganisationSelectionNodeV1 organisationSelectionNodeV1 = new OrganisationSelectionNodeV1();
        BookingNodeV1 booking = new BookingNodeV1();
        RecognisingOrganisationNodeV1 orgSelection = new RecognisingOrganisationNodeV1();
        LocationChangeNodeV1 locationSelection = new LocationChangeNodeV1();
        SelectionMinimumScoreNodeV1 minimumScore = new SelectionMinimumScoreNodeV1();
        List<SelectionMinimumScoreNodeV1> minimumScoreList = new ArrayList<>();

        RecognisingOrganisationNodeV1 recognisingOrganisationNodeV1=new RecognisingOrganisationNodeV1();
        recognisingOrganisationNodeV1.setOrganisationId(UUID.randomUUID().toString());
        recognisingOrganisationNodeV1.setName("vhbjnk");

        organisationSelectionNodeV1.setOrganisationDetails(recognisingOrganisationNodeV1);

        booking.setExternalBookingUuid(UUID.randomUUID());
        booking.setBookingUuid(UUID.randomUUID());
        booking.setShortCandidateNumber(12345);
        booking.setTestDate(LocalDate.now());
        organisationSelectionNodeV1.setBookingDetails(booking);

        orgSelection.setOrganisationId("123456");
        orgSelection.setName("OrgName1");
        orgSelection.setRecognisingOrganisationUuid(UUID.randomUUID());
        organisationSelectionNodeV1.setOrganisationDetails(orgSelection);

        locationSelection.setLocationName("TestCentre-1");
        locationSelection.setLocationUuid(UUID.randomUUID());
        locationSelection.setTestCentreNumber("WAS-BU");
        organisationSelectionNodeV1.setLocationDetails(locationSelection);

        minimumScore.setComponent(ComponentEnum.L);
        minimumScore.setMinimumScoreUuid(UUID.randomUUID());
        minimumScore.setMinimumScoreValue(9.0);
        minimumScoreList.add(minimumScore);
        SelectionNodeV1 selectionNodeV1 = new SelectionNodeV1();
        selectionNodeV1.setMinimumScores(minimumScoreList);

        selectionNodeV1.setCaseNumber("WA-1234");
        selectionNodeV1.setConfirmationStatus(ConfirmationStatusEnum.CONFIRMED);
        selectionNodeV1.setDeliveryStatus(DeliveryStatusEnum.UNDELIVERED);
        selectionNodeV1.setDeliveryStatusChangedDatetime(OffsetDateTime.now());
        selectionNodeV1.setSelectionUuid(UUID.randomUUID());
        selectionNodeV1.setExternalSelectionUuid(UUID.randomUUID());
        selectionNodeV1.setOverallMinimumScore(9.0);
        selectionNodeV1.setPersonDepartment("Test");
        selectionNodeV1.setSelectionDate(OffsetDateTime.now());
        selectionNodeV1.setSharedDate(LocalDate.now());
        selectionNodeV1.setTrfNumber("12345");
        organisationSelectionNodeV1.setSelection(selectionNodeV1);
        return organisationSelectionNodeV1;
    }

    public static SQSEvent populateSQSEvent() throws JsonProcessingException {
        final ObjectMapper mapper = getMapper();
        final String event = mapper.writeValueAsString(getEventRequest());
        final SQSEvent.SQSMessage sqsMessage = new SQSEvent.SQSMessage();
        final SQSEvent sqsEvent = new SQSEvent();
        final List<SQSEvent.SQSMessage> records = new ArrayList<SQSEvent.SQSMessage>();

        sqsMessage.setAwsRegion(DistORSConstants.REGION);
        sqsMessage.setBody(event);
        records.add(sqsMessage);
        sqsEvent.setRecords(records);
        return sqsEvent;
    }

    public static SQSEvent populateSQSEventWithPC() throws JsonProcessingException {
        final ObjectMapper mapper = getMapper();
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        BaseHeader header = populateEventHeader();
        header.setPartnerCode("IDP");
        baseEvent.setEventHeader(header);
        baseEvent.setEventBody(mapper.writeValueAsString(getROSelection()));
        baseEvent.setEventErrors(null);
        final String event = mapper.writeValueAsString(baseEvent);
        final SQSEvent.SQSMessage sqsMessage = new SQSEvent.SQSMessage();
        final SQSEvent sqsEvent = new SQSEvent();
        final List<SQSEvent.SQSMessage> records = new ArrayList<SQSEvent.SQSMessage>();

        sqsMessage.setBody(event);
        records.add(sqsMessage);
        sqsEvent.setRecords(records);
        return sqsEvent;
    }

    public static SQSEvent populateInvalidSQSEvent() throws JsonProcessingException {
        final ObjectMapper mapper = getMapper();
        BaseEvent<BaseHeader> baseEvent = getEventRequest();
        baseEvent.setEventBody("");
        baseEvent.setEventErrors(null);
        final String event = mapper.writeValueAsString(baseEvent);
        final SQSEvent.SQSMessage sqsMessage = new SQSEvent.SQSMessage();
        final SQSEvent sqsEvent = new SQSEvent();
        final List<SQSEvent.SQSMessage> records = new ArrayList<SQSEvent.SQSMessage>();

        sqsMessage.setAwsRegion(DistORSConstants.REGION);
        sqsMessage.setBody(event);
        records.add(sqsMessage);
        sqsEvent.setRecords(records);
        return sqsEvent;
    }

    public static SQSEvent populateSQSEventInvalidHeader() throws JsonProcessingException {
        final ObjectMapper mapper = getMapper();
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        BaseHeader header = populateEventHeader();
        header.setTransactionId(null);
        baseEvent.setEventHeader(header);
        baseEvent.setEventBody(mapper.writeValueAsString(getROSelection()));
        baseEvent.setEventErrors(null);
        final String event = mapper.writeValueAsString(baseEvent);
        final SQSEvent.SQSMessage sqsMessage = new SQSEvent.SQSMessage();
        final SQSEvent sqsEvent = new SQSEvent();
        final List<SQSEvent.SQSMessage> records = new ArrayList<SQSEvent.SQSMessage>();

        sqsMessage.setBody(event);
        records.add(sqsMessage);
        sqsEvent.setRecords(records);
        return sqsEvent;
    }

    public static BaseEventErrors getErrors () {
        List<ErrorDescription> errorList = new ArrayList<>();
        ErrorDescription description = new ErrorDescription();
        description.setInterfaceName("SelectionNodeV1");
        description.setType(ErrorTypeEnum.VALIDATION);
        description.setErrorCode("1234");
        Source source = Source.builder().value("").path("product_uuid").build();
        description.setSource(source);
        errorList.add(description);

        BaseEventErrors errorResponse = new BaseEventErrors(errorList);
        errorResponse.getErrorList();

        return errorResponse;
    }

    public static ObjectMapper getMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        return mapper;
    }

    public static Map<String, String> getEnvironmentVariablesStub() {
        Map<String, String> map = new HashMap<>();
        map.put(DistORSConstantsUtils.CLIENT_ID, "cmds-id");
        map.put(DistORSConstantsUtils.CLIENT_SECRET, "cmds-secret");
        map.put(DistORSConstantsUtils.ACCESS_TOKEN, "access-token");
        map.put("bc_auth_token_url", "BC_AUTH_URL");
        map.put("ca_auth_url","CA_AUTH_URL");
        return map;
    }


}
