package com.ielts.cmds.integration.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;

/**
 * RoSelectionDataV1Inner
 */

@Data
@NoArgsConstructor
public class RoSelectionDataV1Inner {

    private Integer orgId;

    private String orgName;

    @JsonFormat(pattern = "dd/MM/yyyy'T'HH:mm:ss")
    private OffsetDateTime sharedDate;
}
