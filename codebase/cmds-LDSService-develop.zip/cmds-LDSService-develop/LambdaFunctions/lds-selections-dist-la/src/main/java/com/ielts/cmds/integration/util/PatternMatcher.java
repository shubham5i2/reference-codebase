package com.ielts.cmds.integration.util;

import java.util.Collections;

public class PatternMatcher {


    public String appendZerosForCandidate(String candidate)
    {
        int zeros=6;
        zeros=zeros-candidate.length();
        String appendZeros=String.join("", Collections.nCopies(zeros, String.valueOf('0')));
        return appendZeros+candidate;
    }


}
