package com.ielts.cmds.integration.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.google.gson.annotations.SerializedName;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * MessageDetailsV1Inner
 */

@Data
@NoArgsConstructor
public class MessageDetailsV1Inner {

	@JsonProperty("rec_Id")
    private String recId;

    private String centre;

    private String candidate;

    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    @SerializedName("testDate")
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate testDate;

    private RoSelectionDataV1 roSelection;

}
