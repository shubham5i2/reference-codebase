package com.ielts.cmds.integration.exception;

public class RdDistException extends RuntimeException{

    private static final long serialVersionUID = 1L;

    public RdDistException(final String message) {
        super(message);
    }
}
