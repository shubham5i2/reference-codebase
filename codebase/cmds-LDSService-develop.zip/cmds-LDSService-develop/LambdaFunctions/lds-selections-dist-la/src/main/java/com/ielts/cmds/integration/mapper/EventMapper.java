package com.ielts.cmds.integration.mapper;

import com.ielts.cmds.integration.model.MessageDetailsV1;
import com.ielts.cmds.integration.model.MessageDetailsV1Inner;
import com.ielts.cmds.integration.model.MessageV1;
import com.ielts.cmds.integration.model.RoSelectionDataV1;
import com.ielts.cmds.integration.model.RoSelectionDataV1Inner;
import com.ielts.cmds.integration.util.PatternMatcher;
import com.ielts.cmds.rd.domain.model.in.Selection;
import com.ielts.cmds.rd.domain.model.in.SelectionSelection;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;
import lombok.extern.slf4j.Slf4j;

import java.time.OffsetDateTime;
import java.util.UUID;

import static java.time.ZoneOffset.UTC;

/** This class is used to map incoming event to appropriate API request body */

@Slf4j
public class EventMapper {

    public MessageV1 mapIncomingSelectionDeliveryRequest(final OrganisationSelectionNodeV1 organisationSelectionNodeV1) {
        MessageV1 messageV1 = new MessageV1();
        MessageDetailsV1 messageDetailsV1 = new MessageDetailsV1();
        MessageDetailsV1Inner messageDetailsV1Inner = new MessageDetailsV1Inner();
        RoSelectionDataV1 roSelectionDataV1 = new RoSelectionDataV1();
        RoSelectionDataV1Inner roSelectionDataV1Inner = new RoSelectionDataV1Inner();

        messageDetailsV1Inner.setRecId(UUID.randomUUID().toString());

        messageDetailsV1Inner.setCentre(organisationSelectionNodeV1.getLocationDetails().getTestCentreNumber());

        messageDetailsV1Inner.setCandidate(new PatternMatcher().appendZerosForCandidate(String.valueOf(organisationSelectionNodeV1.getBookingDetails().getShortCandidateNumber())));
        messageDetailsV1Inner.setTestDate(organisationSelectionNodeV1.getBookingDetails().getTestDate());
        roSelectionDataV1Inner.setOrgId(Integer.parseInt(organisationSelectionNodeV1.getOrganisationDetails().getOrganisationId()));
        roSelectionDataV1Inner.setOrgName(organisationSelectionNodeV1.getOrganisationDetails().getName());
        roSelectionDataV1Inner.setSharedDate(OffsetDateTime.now(UTC));

        roSelectionDataV1.add(roSelectionDataV1Inner);
        messageDetailsV1Inner.setRoSelection(roSelectionDataV1);
        messageDetailsV1.add(messageDetailsV1Inner);
        messageV1.setMsg(messageDetailsV1);

        return messageV1;
    }

    public Selection mapIncomingRequestToPublishTopicOut(final OrganisationSelectionNodeV1 organisationSelectionNodeV1){
        Selection selection = new Selection();
        selection.setBookingUuid(organisationSelectionNodeV1.getBookingDetails().getBookingUuid());
        selection.setExternalBookingUuid(organisationSelectionNodeV1.getBookingDetails().getExternalBookingUuid());

        SelectionSelection selection1 = new SelectionSelection();
        selection1.setSelectionUuid(organisationSelectionNodeV1.getSelection().getSelectionUuid());
        selection1.setExternalSelectionUuid(organisationSelectionNodeV1.getSelection().getExternalSelectionUuid());
        selection1.setDeliveryStatus(organisationSelectionNodeV1.getSelection().getDeliveryStatus());
        selection1.setDeliveryStatusChangedDateTime(organisationSelectionNodeV1.getSelection().getDeliveryStatusChangedDatetime());

        selection.setSelection(selection1);
        return selection;
    }

}
