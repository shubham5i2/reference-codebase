package com.ielts.cmds.integration.model;

import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.ArrayList;

/**
 * RoSelectionDataV1
 */

@NoArgsConstructor
@ToString
public class RoSelectionDataV1 extends ArrayList<RoSelectionDataV1Inner> {/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
