package com.ielts.cmds.integration.model;

import lombok.NoArgsConstructor;

import java.util.ArrayList;

/**
 * MessageDetailsV1
 */


@NoArgsConstructor
public class MessageDetailsV1 extends ArrayList<MessageDetailsV1Inner> {/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


}
