package com.ielts.cmds.integration.model;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * MessageV1
 */

@Data
@NoArgsConstructor

public class MessageV1 {

    private MessageDetailsV1 msg;

}
