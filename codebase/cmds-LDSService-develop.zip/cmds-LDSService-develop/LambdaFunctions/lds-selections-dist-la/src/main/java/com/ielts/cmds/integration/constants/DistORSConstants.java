package com.ielts.cmds.integration.constants;

public class DistORSConstants {

    private DistORSConstants() {}

    public static final String TRANSACTIONID = "transactionId";
    public static final String CORRELATIONID = "correlationId";
    public static final String PARTNER_CODE = "partnerCode";
    public static final String LDS= "LDS";
    public static final String CA= "CA";
    public static final String EVENT_NAME= "RecognisingOrganisationResultsDeliveryRequestReceived";
    public static final String ENDPOINT_URL= "endpoint_url";
    public static final String ORGANISATION_SELECTION_DELIVERED_LA = "RDSelectionDeliveredDistLA";  //Need to Change when implementing business logic
    public static final String LDS_INT_TOPIC_IN = "lds_int_topic_in_arn";
    public static final String REGION = "AWS_REGION";
    public static final String INTERFACE_NAME = "RecognisingOrganisationResultsDeliveryRequestReceived";
    public static final String ERROR_TITLE = "LA Delivery Issue";
    public static final String MSG_ATTR_DATA_TYPE = "String";
    public static final String NAME = "eventName";

    public static final String EVENT_NAME_FAILED= "RecognisingOrganisationResultsDeliveryRequestReceiveFailed";
}
