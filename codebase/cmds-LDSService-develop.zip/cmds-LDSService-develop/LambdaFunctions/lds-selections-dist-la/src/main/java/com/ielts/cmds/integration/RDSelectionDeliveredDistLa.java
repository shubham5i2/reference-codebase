package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.constants.DistORSConstants.*;
import static java.time.ZoneOffset.UTC;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.integration.constants.DistORSConstants;
import com.ielts.cmds.integration.mapper.EventMapper;
import com.ielts.cmds.integration.model.MessageV1;
import com.ielts.cmds.rd.domain.model.in.Selection;
import com.ielts.cmds.rd.domain.model.out.OrganisationSelectionNodeV1;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.exception.InvalidClientException;
import com.ielts.cmds.security.exception.TokenNotReceivedException;
import com.ielts.cmds.security.factory.AuthenticationClientFactory;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;
import com.ielts.cmds.serialization.lambda.AbstractLambda;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import java.security.KeyStoreException;
import java.security.cert.CertificateException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;

@Slf4j
public class RDSelectionDeliveredDistLa extends AbstractLambda<OrganisationSelectionNodeV1, Selection> {


    private final AuthenticationClientFactory securityAuthenticationFactory;

    private final String extCallbackUrl;

    public RDSelectionDeliveredDistLa() {
        this.securityAuthenticationFactory = new EnvironmentAwareAuthenticationClientFactory();
        this.extCallbackUrl = System.getenv(ENDPOINT_URL);
    }

    @Override
    protected String getTopicName() {
        return System.getenv(DistORSConstants.LDS_INT_TOPIC_IN);
    }

    @Override
    @SneakyThrows
    protected Selection processRequest(OrganisationSelectionNodeV1 organisationSelectionNodeV1) {
        EventMapper eventMapper = new EventMapper();
        MessageV1 messageV1 = eventMapper.mapIncomingSelectionDeliveryRequest(organisationSelectionNodeV1);
        if(postRequestToExternalAPI(messageV1)) {
            buildHeader(EVENT_NAME);
            return eventMapper.mapIncomingRequestToPublishTopicOut(organisationSelectionNodeV1);
        }

        buildHeader(EVENT_NAME_FAILED);
        return new Selection();

    }

    public void buildHeader(String eventName) {

        HeaderContext eventHeader = ThreadLocalHeaderContext.getContext();
        eventHeader.setEventDateTime(LocalDateTime.now(UTC));
        eventHeader.setEventName(eventName);
        ThreadLocalHeaderContext.setContext(eventHeader);

    }


    protected boolean postRequestToExternalAPI(final MessageV1 messageV1) throws Exception {

        AuthenticationClient authenticationClient = getAuthenticationClient(getPartnerCodeConstant());
        try {
            final HttpHeaders eventHeaders = getHttpHeaders(ThreadLocalHeaderContext.getContext(), authenticationClient);

            final HttpEntity<?> eventEntity = new HttpEntity<>(messageV1, eventHeaders);
            log.info(" Evententity : {} MessageV1: {} EndpointURL : {} ",eventEntity,messageV1, extCallbackUrl );

            final ResponseEntity<String> response = authenticationClient.getRestTemplate()
                    .postForEntity(extCallbackUrl, eventEntity, String.class);


            log.debug("Response code {} ", response.getStatusCode());

            log.info("Event to be published {} on {} ", ThreadLocalHeaderContext.getContext().getEventName(), LDS_INT_TOPIC_IN);

            return true;

        } catch (HttpClientErrorException | TokenNotReceivedException | JsonProcessingException ex) {
            log.error(" Exception on posting requestBody: ", ex);
            ThreadLocalErrorContext.setContext(populateErrorResponse(ex, "4X"));
            return false;
        }
    }


    protected BaseEventErrors populateErrorResponse(final Exception exception, final String httpStatus) {
        List<ErrorDescription> errorDescriptionList = new ArrayList<>();
        final Source source = new Source(exception.getMessage(), ThreadLocalHeaderContext.getContext().getEventName());

        final ErrorDescription errorDescription = new ErrorDescription();
        errorDescription.setInterfaceName(INTERFACE_NAME);
        errorDescription.setType(ErrorTypeEnum.ERROR);
        errorDescription.setErrorCode(httpStatus);
        errorDescription.setSource(source);
        errorDescription.setErrorTicketUuid(ThreadLocalHeaderContext.getContext().getCorrelationId());
        errorDescription.setTitle(ERROR_TITLE);
        errorDescription.setMessage(exception.getMessage());
        errorDescriptionList.add(errorDescription);

        return new BaseEventErrors(errorDescriptionList);
    }

    HttpHeaders getHttpHeaders(final HeaderContext eventHeader, final AuthenticationClient authenticationClient) throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException {
        final HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.set(TRANSACTIONID, eventHeader.getTransactionId().toString());
        httpHeaders.set(CORRELATIONID, eventHeader.getCorrelationId().toString());
        httpHeaders.set(PARTNER_CODE, getPartnerCodeConstant());

        httpHeaders.set(authenticationClient.getAuthorizationHeaderName(), authenticationClient.getAccessToken());
        return httpHeaders;
    }

    protected AuthenticationClient getAuthenticationClient(String partnerCode) throws JsonProcessingException, CertificateException, KeyStoreException, TokenNotReceivedException, InvalidClientException {
        return securityAuthenticationFactory.getAuthenticationClient(partnerCode);
    }

    protected String getPartnerCodeConstant(){
        return DistORSConstants.CA;
    }

    protected String getApplicationName(){
        return DistORSConstants.ORGANISATION_SELECTION_DELIVERED_LA;
    }

}
