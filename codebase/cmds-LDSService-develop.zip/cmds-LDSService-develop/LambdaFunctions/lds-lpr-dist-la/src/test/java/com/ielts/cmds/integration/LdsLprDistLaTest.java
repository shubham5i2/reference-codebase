package com.ielts.cmds.integration;

import com.amazonaws.AmazonClientException;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.AmazonSNSException;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.constants.ReceiverConstants;
import com.ielts.cmds.integration.exception.LdsDistException;
import com.ielts.cmds.integration.model.LocationNodeV1;
import com.ielts.cmds.integration.utils.SQSEventBodySetup;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.clients.CAAuthenticationClient;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;
import com.ielts.cmds.security.utils.CAToken;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatchers;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class LdsLprDistLaTest {

    private final SQSEventBodySetup sqsEventSetup = new SQSEventBodySetup();

    private final ObjectMapper objectMapper = SQSEventBodySetup.getMapper();

    @Mock
    ObjectMapper mapper;

    @Mock
    CAAuthenticationClient authenticationClient;

    @Spy
    private LdsLprDistLa ldsLprDistLa;

    @Spy
    private SQSEvent event, eventInvalid, eventInvalidHeader, event2, event3;

    @Spy
    private SQSEvent.SQSMessage messageBody, messageInvalid, messageInvalidHeader, messageBody2, messageBody3;

    @Mock
    private EnvironmentAwareAuthenticationClientFactory securityAuthenticationFactory;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private AmazonSNS snsClientMock;

    @Captor
    private ArgumentCaptor<LocationNodeV1> eventCapt;

    @Captor
    private ArgumentCaptor<BaseEvent<BaseHeader>> baseEventCapt;

    @BeforeEach
    public void setUp() throws Exception {
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);

        ReflectionTestUtils.setField(ldsLprDistLa, "securityAuthenticationFactory", securityAuthenticationFactory);
        ReflectionTestUtils.setField(ldsLprDistLa, "extCallbackUrl", "https://endpoint.orsdomain.com");
//        ReflectionTestUtils.setField(ldsLprDistLa, "region", ReceiverConstants.REGION);
//        ReflectionTestUtils.setField(ldsLprDistLa, "timeOut", "900");
        String eventBody = SQSEventBodySetup.getEventBody();
        messageBody.setBody(eventBody);
        List<SQSEvent.SQSMessage> records = new ArrayList<>();
        records.add(messageBody);
        event.setRecords(records);
        String invalidEvent = SQSEventBodySetup.getInvalidEvent();
        messageInvalid.setBody(invalidEvent);
        List<SQSEvent.SQSMessage> records2 = new ArrayList<>();
        records2.add(messageInvalid);
        eventInvalid.setRecords(records2);
        String invalidEventHeader = sqsEventSetup.populateSQSEventInvalidHeader();
        messageInvalidHeader.setBody(invalidEventHeader);
        List<SQSEvent.SQSMessage> records3 = new ArrayList<>();
        records3.add(messageInvalidHeader);
        eventInvalidHeader.setRecords(records3);
        List<SQSEvent.SQSMessage> records4 = new ArrayList<>();
        records4.add(messageBody2);
        event2.setRecords(records4);
        List<SQSEvent.SQSMessage> records5 = new ArrayList<>();
        records5.add(messageBody3);
        event3.setRecords(records5);

    }

    @Test
    void getApplicationName() {
        String applicationName = ldsLprDistLa.getApplicationName();
        assertEquals(ReceiverConstants.LPR_LOCATION_CONSUMED_LA, applicationName);
    }

    @Test
    void getPartnerCodeConstants_whenGetPartnerCodeConstants_thenReturnCA() {
        String partnerCodeConstants = ldsLprDistLa.getPartnerCodeConstant();
        assertEquals(ReceiverConstants.CA, partnerCodeConstants);
    }


    @Test
    void handle_request_headers_tokenException() throws Exception {

        BaseEvent<BaseHeader> baseEvent = SQSEventBodySetup.getEventRequest();
        AuthenticationClient authenticationClient = ldsLprDistLa.getAuthenticationClient("CA");
        Executable exe = () -> ldsLprDistLa.getHttpHeaders(baseEvent.getEventHeader(), authenticationClient);
        assertThrows(RuntimeException.class, exe);
    }

    @Test
    void verifyCallTo_authClient() throws Exception {
        doReturn(authenticationClient).when(ldsLprDistLa).getAuthenticationClient("CA");
        AuthenticationClient authClient = ldsLprDistLa.getAuthenticationClient("CA");
        assertEquals(authenticationClient, authClient);
    }

    @Test
    void handle_request_headers_eventViolations() {

        Executable exe = () -> ldsLprDistLa.handleRequest(eventInvalidHeader);
        assertThrows(LdsDistException.class, exe);
    }

    @Test
    void whenLegacyDeliveryHasInvalidEvent_ThenVerifyCallToRestTemplate() {
        assertThrows(LdsDistException.class, () -> ldsLprDistLa.handleRequest(eventInvalid));
    }

    @Test
    void whenLegacyDeliveryHasValidAuthenticationHeader_ThenVerifyCallToRestTemplate() throws Exception {
        BaseEvent<?> baseEvent = objectMapper.readValue(messageBody.getBody(), BaseEvent.class);
        Map<String, String> map = new HashMap<>();
        map.put(ReceiverConstants.ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ReceiverConstants.ACCESS_TOKEN));
        map.put(ReceiverConstants.AUTH_HEADER, ReceiverConstants.AUTH_HEADER_NAME);
        ResponseEntity<String> response = new ResponseEntity<>(HttpStatus.OK);
        HttpHeaders eventHeaders = SQSEventBodySetup.getHttpHeaders(baseEvent.getEventHeader());
        eventHeaders.set(map.get(ReceiverConstants.AUTH_HEADER), map.get(ReceiverConstants.ACCESS_TOKEN));
        when(ldsLprDistLa.getSNSClient()).thenReturn(snsClientMock);
        when(securityAuthenticationFactory.getAuthenticationClient(ReceiverConstants.CA)).thenReturn(authenticationClient);

        doReturn("authHeaderName").when(authenticationClient).getAuthorizationHeaderName();
        doReturn("accessToken").when(authenticationClient).getAccessToken();
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        doReturn(response).when(restTemplate).postForEntity(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.eq(String.class));
        assertDoesNotThrow(() -> ldsLprDistLa.handleRequest(event));
        assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());
    }

    @Test
    void handle_request_call_exception() throws Exception {
        CAToken caToken = new CAToken();
        caToken.setAccessToken("accessToken");
        caToken.setExpiresIn(132984);
        caToken.setScope("Scope");
        caToken.setTokenType("Bearer");
        ReflectionTestUtils.setField(ldsLprDistLa, "securityAuthenticationFactory", securityAuthenticationFactory);
        ReflectionTestUtils.setField(ldsLprDistLa, "extCallbackUrl", "https://withdrawendpoint.orsdomain.com");
        doReturn(authenticationClient).when(ldsLprDistLa).getAuthenticationClient("CA");
        doReturn("accessToken").when(authenticationClient).getAccessToken();
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        doThrow(RestClientException.class).when(restTemplate).postForEntity(ArgumentMatchers.anyString(), ArgumentMatchers.any(), ArgumentMatchers.any());
        doReturn("authHeaderName").when(authenticationClient).getAuthorizationHeaderName();
        assertThrows(LdsDistException.class, () -> ldsLprDistLa.handleRequest(event));
    }


    @Test
    void whenEventBodyIsNull() throws Exception {
        messageBody.setBody(SQSEventBodySetup.getEventBody1());
        BaseEvent<?> baseEvent = objectMapper.readValue(messageBody.getBody(), BaseEvent.class);
        Map<String, String> map = new HashMap<>();
        map.put(ReceiverConstants.ACCESS_TOKEN, SQSEventBodySetup.getEnvironmentVariablesStub().get(ReceiverConstants.ACCESS_TOKEN));
        map.put(ReceiverConstants.AUTH_HEADER, ReceiverConstants.AUTH_HEADER_NAME);
        ResponseEntity<String> response = new ResponseEntity<>(HttpStatus.OK);
        HttpHeaders eventHeaders = SQSEventBodySetup.getHttpHeaders(baseEvent.getEventHeader());
        eventHeaders.set(map.get(ReceiverConstants.AUTH_HEADER), map.get(ReceiverConstants.ACCESS_TOKEN));
        when(ldsLprDistLa.getSNSClient()).thenReturn(snsClientMock);
        when(securityAuthenticationFactory.getAuthenticationClient(ReceiverConstants.CA)).thenReturn(authenticationClient);
        doReturn("authHeaderName").when(authenticationClient).getAuthorizationHeaderName();
        doReturn("accessToken").when(authenticationClient).getAccessToken();
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        doReturn(response).when(restTemplate).postForEntity(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.eq(String.class));
        assertDoesNotThrow(() -> ldsLprDistLa.handleRequest(event));
        assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());
    }


    @Test
    void whenLegacyDeliveryHasInvalidAuthenticationHeader_ThenVerifyCallToRestTemplate() throws Exception,LdsDistException {
        BaseEvent<?> baseEvent = objectMapper.readValue(messageBody.getBody(), BaseEvent.class);
        Map<String, String> map = new HashMap<>();
        map.put(ReceiverConstants.ACCESS_TOKEN, com.ielts.cmds.integration.utils.SQSEventBodySetup.getEnvironmentVariablesStub().get(ReceiverConstants.ACCESS_TOKEN));
        map.put(ReceiverConstants.AUTH_HEADER, ReceiverConstants.AUTH_HEADER_NAME);
        ResponseEntity<String> LAResponse = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        HttpHeaders eventHeaders = SQSEventBodySetup.getHttpHeaders(baseEvent.getEventHeader());
        eventHeaders.set(map.get(ReceiverConstants.AUTH_HEADER), map.get(ReceiverConstants.ACCESS_TOKEN));
        when(ldsLprDistLa.getSNSClient()).thenReturn(snsClientMock);
        when(securityAuthenticationFactory.getAuthenticationClient(ReceiverConstants.CA)).thenReturn(authenticationClient);

        doReturn("authHeaderName").when(authenticationClient).getAuthorizationHeaderName();
        doReturn("accessToken").when(authenticationClient).getAccessToken();
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        doReturn(LAResponse).when(restTemplate).postForEntity(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.eq(String.class));
        assertDoesNotThrow(() -> ldsLprDistLa.handleRequest(event));
        verify(ldsLprDistLa, times(1)).postRequestToLaAndPublishEvent(baseEventCapt.capture(), eventCapt.capture());
        assertEquals(HttpStatus.BAD_REQUEST.value(), LAResponse.getStatusCodeValue());
    }

    @Test
    void WhenHandleRequestCallToPublish_ThrowException() throws Exception {

        CAToken caToken = new CAToken();
        caToken.setAccessToken("accessToken");
        caToken.setExpiresIn(132984);
        caToken.setScope("Scope");
        caToken.setTokenType("Bearer");
        ResponseEntity<String> response = new ResponseEntity<>(HttpStatus.OK);
        doReturn(authenticationClient).when(ldsLprDistLa).getAuthenticationClient("CA");
        doReturn("accessToken").when(authenticationClient).getAccessToken();
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        when(ldsLprDistLa.getSNSClient()).thenReturn(snsClientMock);
        lenient().doReturn(caToken).when(restTemplate).postForObject(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.eq(Class.class));
        doReturn("authHeaderName").when(authenticationClient).getAuthorizationHeaderName();

        doThrow(new AmazonClientException("Test")).when(restTemplate).postForEntity(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.eq(String.class));
        Executable exe = () -> ldsLprDistLa.handleRequest(event);
        assertThrows(LdsDistException.class, exe);
    }

    @Test
    void WhenHandleRequestCallToPublish_ThrowAmazonSNSException() throws Exception {

        CAToken caToken = new CAToken();
        caToken.setAccessToken("accessToken");
        caToken.setExpiresIn(132984);
        caToken.setScope("Scope");
        caToken.setTokenType("Bearer");
        ResponseEntity<String> response = new ResponseEntity<>(HttpStatus.OK);
        doReturn(authenticationClient).when(ldsLprDistLa).getAuthenticationClient("CA");
        doReturn("accessToken").when(authenticationClient).getAccessToken();
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        when(ldsLprDistLa.getSNSClient()).thenReturn(snsClientMock);
        lenient().doReturn(caToken).when(restTemplate).postForObject(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.eq(Class.class));
        doReturn("authHeaderName").when(authenticationClient).getAuthorizationHeaderName();

        doThrow(new AmazonSNSException("Test")).when(restTemplate).postForEntity(ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.eq(String.class));
        Executable exe = () -> ldsLprDistLa.handleRequest(event);
        assertThrows(LdsDistException.class, exe);
    }


    @Test
    void whenEventHeaderIsNull_ThenThrowRDDistException() throws Exception {
        String expectedExceptionMsg = "EventHeaders does not exist";
        BaseEvent<?> baseEvent = objectMapper.readValue(messageBody.getBody(), BaseEvent.class);
        baseEvent.setEventHeader(null);
        baseEvent.setEventErrors(null);
        String eventBody = objectMapper.writeValueAsString(baseEvent);
        messageBody.setBody(eventBody);
        assertThrows(LdsDistException.class, () -> ldsLprDistLa.handleRequest(event), expectedExceptionMsg);
    }

    @Test
    void whenBodyIsNull_ThenThrowRdDistException() throws Exception {
        String expectedExceptionMsg = "EventBody does not exist";
        BaseEvent<?> baseEvent = objectMapper.readValue(messageBody.getBody(), BaseEvent.class);
        baseEvent.setEventBody(null);
        baseEvent.setEventErrors(null);
        String eventBody = objectMapper.writeValueAsString(baseEvent);
        messageBody.setBody(eventBody);
        assertThrows(LdsDistException.class, () -> ldsLprDistLa.handleRequest(event), expectedExceptionMsg);
    }


}
