package com.ielts.cmds.integration.utils;


import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.constants.ReceiverConstants;
import com.ielts.cmds.integration.model.LocationHierarchyAddressV1;
import com.ielts.cmds.integration.model.LocationHierarchyApprovedProductV1;
import com.ielts.cmds.integration.model.LocationNodeV1;
import com.ielts.cmds.lpr.common.enums.LocationStatus;
import com.ielts.cmds.lpr.common.enums.LocationTypeCode;
import com.ielts.cmds.lpr.common.enums.PartnerCode;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class SQSEventBodySetup {


    private static final ObjectMapper mapper = getMapper();

    public static HttpHeaders getHttpHeaders(BaseHeader eventHeader) {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(ReceiverConstants.TRANSACTIONID, eventHeader.getTransactionId().toString());
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.set(ReceiverConstants.CORRELATIONID, eventHeader.getCorrelationId().toString());
        httpHeaders.set(ReceiverConstants.PARTNER_CODE, eventHeader.getPartnerCode());
        return httpHeaders;
    }

    public static String getEventBody() throws JsonProcessingException {
        BaseHeader eventHeader = getEventHeader();
        LocationNodeV1 locationNodeV1 = setLocationNodeV1();
        String eventBody = mapper.writeValueAsString(locationNodeV1);
        BaseEventErrors errorResponse = getErrors();
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        baseEvent.setEventHeader(eventHeader);
        baseEvent.setEventBody(eventBody);
        baseEvent.setEventErrors(errorResponse);
        return mapper.writeValueAsString(baseEvent);
    }

    public static String getEventBody1() throws JsonProcessingException {
        BaseHeader eventHeader = getEventHeader();
        LocationNodeV1 locationNodeV1 = setLocationNodeV2();
        String eventBody = mapper.writeValueAsString(locationNodeV1);
        BaseEventErrors errorResponse = getErrors();
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        baseEvent.setEventHeader(eventHeader);
        baseEvent.setEventBody(eventBody);
        baseEvent.setEventErrors(errorResponse);
        return mapper.writeValueAsString(baseEvent);
    }

    public static BaseEventErrors getErrors() {
        List<ErrorDescription> errorList = new ArrayList<>();
        ErrorDescription description = new ErrorDescription();
        description.setInterfaceName("LocationNodeV1");
        description.setType(ErrorTypeEnum.VALIDATION);
        description.setErrorCode("1234");
        Source source = Source.builder().value("").path("product_uuid").build();
        description.setSource(source);
        errorList.add(description);
        BaseEventErrors errorResponse = new BaseEventErrors(errorList);
        errorResponse.getErrorList();

        return errorResponse;
    }

    public static BaseEvent<BaseHeader> getEventRequest() throws JsonProcessingException {
        BaseEvent<BaseHeader> event = new BaseEvent<>();
        event.setEventHeader(getEventHeader());
        event.setEventBody(mapper.writeValueAsString(setLocationNodeV1()));
        event.setEventErrors(null);
        return event;
    }

    public String populateSQSEventInvalidHeader() throws JsonProcessingException {
        final ObjectMapper mapper = getMapper();
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        BaseHeader header = getEventHeader();
        header.setTransactionId(null);
        baseEvent.setEventHeader(header);
        baseEvent.setEventBody(mapper.writeValueAsString(setLocationNodeV1()));
        baseEvent.setEventErrors(null);


        return mapper.writeValueAsString(baseEvent);
    }

    public static String getInvalidEvent() throws JsonProcessingException {
        BaseHeader eventHeader = getEventHeader();
        LocationNodeV1 locationNodeV1 = setLocationNodeV1();
        String eventBody = mapper.writeValueAsString(locationNodeV1);
        BaseEventErrors errorResponse = getErrors();
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        baseEvent.setEventHeader(eventHeader);
        baseEvent.setEventBody(eventBody);
        baseEvent.setEventErrors(errorResponse);
        return "baseEvent";
    }

    public static LocationNodeV1 setLocationNodeV1() {
        LocationNodeV1 locationNodeV1 = new LocationNodeV1();
        locationNodeV1.setLocationUuid(UUID.fromString("ba961901-f633-4cd5-aa33-d6593d6a3e7c"));
        locationNodeV1.setParentLocationUuid(UUID.fromString("e6b8da53-dcc0-44ee-8464-91b1ad7dd7ff"));
        locationNodeV1.setLocationTypeCode(LocationTypeCode.TEST_CENTRE);
        locationNodeV1.setPartnerCode(PartnerCode.IDP);
        locationNodeV1.setLocationStatus(LocationStatus.ACTIVE);
        locationNodeV1.setLocationName("IDPMelbourne56");
        locationNodeV1.setTestCentreNumber("AU123");
        locationNodeV1.setWebsiteURL("https://www.cambridgeassessment.org.uk/");
        locationNodeV1.setApprovedDate("2020-01-20");
        locationNodeV1.setTimezoneName("Etc/UTC");
        locationNodeV1.setLocationAddresses(getLocationAddress());
        locationNodeV1.setApprovedProducts(getApprovedProducts());


        return locationNodeV1;
    }

    public static LocationNodeV1 setLocationNodeV2() {
        LocationNodeV1 locationNodeV1 = new LocationNodeV1();
        locationNodeV1.setLocationUuid(UUID.fromString("ba961901-f633-4cd5-aa33-d6593d6a3e7c"));
        locationNodeV1.setParentLocationUuid(UUID.fromString("e6b8da53-dcc0-44ee-8464-91b1ad7dd7ff"));
        locationNodeV1.setLocationTypeCode(LocationTypeCode.TEST_CENTRE);
        locationNodeV1.setPartnerCode(PartnerCode.IDP);
        locationNodeV1.setLocationStatus(LocationStatus.ACTIVE);
        locationNodeV1.setLocationName("IDPMelbourne56");
        locationNodeV1.setTestCentreNumber("AU123");
        locationNodeV1.setWebsiteURL("https://www.cambridgeassessment.org.uk/");
        locationNodeV1.setApprovedDate("2020-01-30");
        locationNodeV1.setTimezoneName("Etc/UTC");
        locationNodeV1.setLocationAddresses(getLocationAddress());
        locationNodeV1.setApprovedProducts(getApprovedProducts());

        return locationNodeV1;
    }

    public static List<LocationHierarchyApprovedProductV1> getApprovedProducts() {
        List<LocationHierarchyApprovedProductV1> productlist=new ArrayList<>();
        LocationHierarchyApprovedProductV1 locationHierarchyApprovedProductV1 = new LocationHierarchyApprovedProductV1();
        locationHierarchyApprovedProductV1.setProductUuid(UUID.fromString("2c3bace7-9ac7-4213-ab5f-11b34264f9ce"));
        locationHierarchyApprovedProductV1.setEffectiveFromDate("2021-01-30");
        locationHierarchyApprovedProductV1.setEffectiveToDate("2022-03-28");
        productlist.add(locationHierarchyApprovedProductV1);
        return productlist;
    }

    public static List<LocationHierarchyAddressV1> getLocationAddress() {
        List<LocationHierarchyAddressV1> addressList = new ArrayList<>();
        LocationHierarchyAddressV1 locationHierarchyAddressV1 = new LocationHierarchyAddressV1();
        locationHierarchyAddressV1.setCountryIso3Code("AUS");
        locationHierarchyAddressV1.setAddressLine1("GPO BOX 1515");
        locationHierarchyAddressV1.setAddressLine2("The Triangle Building");
        locationHierarchyAddressV1.setAddressLine4("string");
        locationHierarchyAddressV1.setAddressLine3("string");
        locationHierarchyAddressV1.setAddressTypeUuid(UUID.fromString("b32a82a0-693c-4dfd-824f-962784f8bf7d"));
        locationHierarchyAddressV1.setCity("Melbourne");
        locationHierarchyAddressV1.setEmail("info@cambridgeassessment.org.uk");
        locationHierarchyAddressV1.setPostalCode("3000");
        locationHierarchyAddressV1.setPrimaryPhone("+44 (0)1223 553311");
        locationHierarchyAddressV1.setTerritoryUuid(UUID.fromString("b32a82a0-693c-4dfd-824f-962784f8bf7d"));

        addressList.add(locationHierarchyAddressV1);

        return addressList;
    }

    public static ObjectMapper getMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        return mapper;

    }

    public static BaseHeader getEventHeader() {
        BaseHeader eventHeader = new BaseHeader();
        eventHeader.setTransactionId(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775668"));
        eventHeader.setCallbackURL("http://35.178.179.164:8105/selection");
        eventHeader.setCorrelationId(UUID.fromString("779187f5-38ed-4e86-b311-050ffe394f81"));
        eventHeader.setPartnerCode("CA");
        eventHeader.setEventName("LegacyResultDelivery");
        LocalDateTime eventDateTime =
                LocalDateTime.parse(
                        "2020-09-29T21:00:35.723Z",
                        DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
        eventHeader.setEventDateTime(eventDateTime);
        return eventHeader;
    }

    public static Map<String, String> getEnvironmentVariablesStub() {
        Map<String, String> map = new HashMap<>();
        map.put(ReceiverConstants.CLIENT_ID, "cmds-id");
        map.put(ReceiverConstants.CLIENT_SECRET, "cmds-secret");
        map.put(ReceiverConstants.ACCESS_TOKEN, "access-token");
        map.put("bc_auth_token_url", "BC_AUTH_URL");
        map.put(ReceiverConstants.CA_AUTH_URL, "ca_auth_url");
        return map;
    }


}


