package com.ielts.cmds.integration.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.NoArgsConstructor;
import java.util.UUID;

/**
 * LocationNodeV1
 */
@NoArgsConstructor
@JsonInclude(value = Include.NON_NULL)
public class LocationHierarchyAddressV1  {

    private UUID addressTypeUuid;

    private String addressLine1;

    private String addressLine2;

    private String addressLine3;

    private String addressLine4;

    private String city;

    private UUID territoryUuid;

    private String postalCode;

    private String countryIso3Code;

    private UUID countryUuid;

    private String email;

    private String primaryPhone;
    
    public LocationHierarchyAddressV1(UUID addressTypeUuid, String addressLine1, String addressLine2,
	    String addressLine3, String addressLine4, String city, UUID territoryUuid, String postalCode,
	    String countryIso3Code, UUID countryUuid, String email, String primaryPhone) {
	this.addressTypeUuid = addressTypeUuid;
	this.addressLine1 = addressLine1;
	this.addressLine2 = addressLine2;
	this.addressLine3 = addressLine3;
	this.addressLine4 = addressLine4;
	this.city = city;
	this.territoryUuid = territoryUuid;
	this.postalCode = postalCode;
	this.countryIso3Code = countryIso3Code;
	this.countryUuid = countryUuid;
	this.email = email;
	this.primaryPhone = primaryPhone;
    }

    public UUID getAddressTypeUuid() {
        return addressTypeUuid;
    }

    public void setAddressTypeUuid(UUID addressTypeUuid) {
        this.addressTypeUuid = addressTypeUuid;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getAddressLine3() {
        return addressLine3;
    }

    public void setAddressLine3(String addressLine3) {
        this.addressLine3 = addressLine3;
    }

    public String getAddressLine4() {
        return addressLine4;
    }

    public void setAddressLine4(String addressLine4) {
        this.addressLine4 = addressLine4;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public UUID getTerritoryUuid() {
        return territoryUuid;
    }

    public void setTerritoryUuid(UUID territoryUuid) {
        this.territoryUuid = territoryUuid;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getCountryIso3Code() {
        return countryIso3Code;
    }

    public void setCountryIso3Code(String countryIso3Code) {
        this.countryIso3Code = countryIso3Code;
    }

    public UUID getCountryUuid() {
        return countryUuid;
    }

    public void setCountryUuid(UUID countryUuid) {
        this.countryUuid = countryUuid;
    }

    public String getEmail() {
        return email;
    }

    @Override
    public String toString() {
        return "LocationHierarchyAddressV1{" +
                "addressTypeUuid=" + addressTypeUuid +
                ", addressLine1='" + addressLine1 + '\'' +
                ", addressLine2='" + addressLine2 + '\'' +
                ", addressLine3='" + addressLine3 + '\'' +
                ", addressLine4='" + addressLine4 + '\'' +
                ", city='" + city + '\'' +
                ", territoryUuid=" + territoryUuid +
                ", postalCode='" + postalCode + '\'' +
                ", countryIso3Code='" + countryIso3Code + '\'' +
                ", countryUuid=" + countryUuid +
                ", email='" + email + '\'' +
                ", primaryPhone='" + primaryPhone + '\'' +
                '}';
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPrimaryPhone() {
        return primaryPhone;
    }

    public void setPrimaryPhone(String primaryPhone) {
        this.primaryPhone = primaryPhone;
    }
}
