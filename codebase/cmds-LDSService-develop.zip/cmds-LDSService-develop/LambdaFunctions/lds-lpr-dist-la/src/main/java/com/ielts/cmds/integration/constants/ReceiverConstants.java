package com.ielts.cmds.integration.constants;

public class ReceiverConstants {

    private ReceiverConstants() {
    }

    public static final String TRANSACTIONID = "transactionId";
    public static final String CORRELATIONID = "correlationId";
    public static final String PARTNER_CODE = "partnerCode";
    public static final String LDS = "LDS";
    public static final String CA = "CA";
    public static final String CLIENT_ID = "client_id";
    public static final String CLIENT_SECRET = "client_secret";
    public static final String AUTH_HEADER = "auth_header";
    public static final String AUTH_HEADER_NAME = "Authorization";
    public static final String ACCESS_TOKEN = "access_token";
    public static final String LA_ENDPOINT_URL = "endpoint_url";
    public static final String URLTIMEOUT = "presigned_url_timeout_second";
    public static final String CA_AUTH_URL = "ca_auth_url";
    public static final String REGION = "AWS_REGION";
    public static final String LPR_LOCATION_CONSUMED_LA = "Lpr_Location_Consumed_La";


}