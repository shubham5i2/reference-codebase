package com.ielts.cmds.integration.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.NoArgsConstructor;

import java.util.UUID;

/**
 * LocationNodeV1
 */
@NoArgsConstructor
@JsonInclude(value = Include.NON_NULL)
public class LocationHierarchyApprovedProductV1 {

    private UUID productUuid;

    private String effectiveFromDate;

    private String effectiveToDate;
    
    public LocationHierarchyApprovedProductV1(UUID productUuid, String effectiveFromDate, String effectiveToDate) {
	this.productUuid = productUuid;
	this.effectiveFromDate = effectiveFromDate;
	this.effectiveToDate = effectiveToDate;
    }

    public UUID getProductUuid() {
        return productUuid;
    }

    @Override
    public String toString() {
        return "LocationHierarchyApprovedProductV1{" +
                "productUuid=" + productUuid +
                ", effectiveFromDate=" + effectiveFromDate +
                ", effectiveToDate=" + effectiveToDate +
                '}';
    }

    public void setProductUuid(UUID productUuid) {
        this.productUuid = productUuid;
    }

    public String getEffectiveFromDate() {
        return effectiveFromDate;
    }

    public void setEffectiveFromDate(String effectiveFromDate) {
        this.effectiveFromDate = effectiveFromDate;
    }

    public String getEffectiveToDate() {
        return effectiveToDate;
    }

    public void setEffectiveToDate(String effectiveToDate) {
        this.effectiveToDate = effectiveToDate;
    }


}
