package com.ielts.cmds.integration;


import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.amazonaws.services.s3.model.AmazonS3Exception;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.AmazonSNSClient;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.common.logger.util.CMDSLambdaLoggerUtil;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.constants.ReceiverConstants;
import com.ielts.cmds.integration.exception.LdsDistException;
import com.ielts.cmds.integration.mapper.EventMapper;
import com.ielts.cmds.integration.model.LocationNodeV1;
import com.ielts.cmds.lpr.common.out.model.LocationNode;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.exception.InvalidClientException;
import com.ielts.cmds.security.exception.TokenNotReceivedException;
import com.ielts.cmds.security.factory.AuthenticationClientFactory;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestClientException;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import java.security.KeyStoreException;
import java.security.cert.CertificateException;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import static java.lang.String.format;

@Slf4j
public class LdsLprDistLa {
    private final ObjectMapper objectMapper;
    private final AuthenticationClientFactory securityAuthenticationFactory;
    private final String extCallbackUrl;

    public LdsLprDistLa() {
        this.objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        objectMapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        objectMapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        objectMapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
        objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        this.extCallbackUrl = System.getenv(ReceiverConstants.LA_ENDPOINT_URL);
        this.securityAuthenticationFactory = new EnvironmentAwareAuthenticationClientFactory();
    }

    public void handleRequest(final SQSEvent input) throws Exception {

        for (SQSEvent.SQSMessage message : input.getRecords()) {
            final String sqsMessage = message.getBody();
            validateAndSendEventRequest(sqsMessage);
        }

    }

    /*
     * Validates and sends the received sqs message body for further processing
     *
     * @param sqsMessage
     * @param context
     * @throws JsonProcessingException
     */
    private void validateAndSendEventRequest(final String sqsMessage) throws Exception {
        try {
            final BaseEvent<BaseHeader> event = validateHeadersAndBody(sqsMessage);
            final BaseHeader eventHeader = event.getEventHeader();
            final UUID transactionId = eventHeader.getTransactionId();
            final UUID correlationId = eventHeader.getCorrelationId();
            Map<String, String> eventContext = event.getEventHeader().getEventContext();

            initializeLogger(transactionId, correlationId, eventContext);
            log.info("Event Received in {}:{} with metadata as {} and error as {}",
                    ReceiverConstants.LDS, getApplicationName(), event.getEventHeader(), event.getEventErrors());

            mapAndSendExternalEvent(event);

        } catch (Exception ex) {
            log.error("Exception on processing event ", ex);
            throw new LdsDistException(format("Exception on processing event :%s", ex));
        }
    }

    /**
     * This method validates event headers and event body.
     *
     * @param sqsMsg
     * @return
     * @throws JsonProcessingException
     */
    private BaseEvent<BaseHeader> validateHeadersAndBody(final String sqsMsg) throws JsonProcessingException {

        final BaseEvent<BaseHeader> cmdsEvent = objectMapper.readValue(sqsMsg, new TypeReference<BaseEvent<BaseHeader>>() {
        });
        final Validator cmdsEventValidator = Validation.buildDefaultValidatorFactory().getValidator();

        final Set<ConstraintViolation<BaseEvent<BaseHeader>>> eventViolations =
                cmdsEventValidator.validate(cmdsEvent);

        if (!CollectionUtils.isEmpty(eventViolations)) {

            final Set<String> errorMessageSet = eventViolations.stream()
                    .map(ConstraintViolation::getMessage)
                    .collect(Collectors.toSet());

            final String errorMessage = String.join(", ", errorMessageSet);
            log.error("Validation failed for CMDSEvent - {} :", errorMessage);
            log.info("Event being published from LDS LPR DS : lds-lpr-dist-la lambda with metadata as {} and error {}",
                    objectMapper.writeValueAsString(cmdsEvent.getEventHeader()), errorMessage);
            throw new LdsDistException(
                    format("CMDS Event Validation failed- [%s] for the request %s", errorMessage, sqsMsg));
        }
        validateEventBody(cmdsEvent);
        return cmdsEvent;
    }

    /*
     * This method validates event body and event errors
     */
    private void validateEventBody(BaseEvent<BaseHeader> event) {
        if (StringUtils.isEmpty(event.getEventBody()) && event.getEventErrors() == null) {
            throw new LdsDistException(
                    format("Not a valid event. No event body and no event error: %s", event));
        }
    }

    /*
     * It processes and sends event body to appropriate external api resource based on EventType
     *
     * @param event
     * @param headers
     * @throws JsonProcessingException
     */
    private void mapAndSendExternalEvent(final BaseEvent<BaseHeader> event)
            throws Exception {
        final EventMapper eventMapper = new EventMapper();
        LocationNodeV1 locationNodeV1 = new LocationNodeV1();
        try {
            if (event.getEventBody() != null) {
                log.info(" Before Mapping ..");
                LocationNode locationNode = objectMapper.readValue(event.getEventBody(), LocationNode.class);
                log.info("LocationNode Date {} : ", locationNode.getApprovedDate());
                locationNodeV1 = eventMapper.locationConsumed(locationNode);
            }

            log.debug("EventBody: {}", objectMapper.writeValueAsString(locationNodeV1));
        } catch (AmazonS3Exception amazonS3Exception) {
            log.error("AmazonS3Exception occurred ", amazonS3Exception);
        }
        log.info("Mapping Done: {}", locationNodeV1.getLocationUuid());
        postRequestToLaAndPublishEvent(event, locationNodeV1);
    }


    protected void postRequestToLaAndPublishEvent(final BaseEvent<BaseHeader> event,
            final LocationNodeV1 requestBody)throws Exception {
	
        AuthenticationClient authenticationClient = getAuthenticationClient(getPartnerCodeConstant());
        try {
            final HttpHeaders eventHeaders = getHttpHeaders(event.getEventHeader(), authenticationClient);
            final HttpEntity<?> eventEntity = new HttpEntity<>(requestBody, eventHeaders);
            final ResponseEntity<String> response = authenticationClient.getRestTemplate()
                    .postForEntity(extCallbackUrl, eventEntity, String.class);
            log.info(
                    "Request success with status code: {} ",
                    response.getStatusCode());

        } catch (RestClientException | TokenNotReceivedException  | LdsDistException|
                 JsonProcessingException ex) {
            log.error(" Exception on posting requestBody: ", ex);
            throw new LdsDistException("Event Headers - Exception on posting requestBody:");
        }

    }

    HttpHeaders getHttpHeaders(final BaseHeader eventHeader, final AuthenticationClient authenticationClient) throws LdsDistException, TokenNotReceivedException, CertificateException, KeyStoreException, JsonProcessingException {

        final HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.set(ReceiverConstants.TRANSACTIONID, eventHeader.getTransactionId().toString());
        httpHeaders.set(ReceiverConstants.CORRELATIONID, eventHeader.getCorrelationId().toString());
        httpHeaders.set(ReceiverConstants.PARTNER_CODE, eventHeader.getPartnerCode());
        httpHeaders.set(authenticationClient.getAuthorizationHeaderName(), authenticationClient.getAccessToken());
        return httpHeaders;
    }

    protected AuthenticationClient getAuthenticationClient(String partnerCode) throws LdsDistException, TokenNotReceivedException, InvalidClientException, CertificateException, KeyStoreException, JsonProcessingException {
        return securityAuthenticationFactory.getAuthenticationClient(partnerCode);
    }

    protected AmazonSNS getSNSClient() {
        return AmazonSNSClient.builder().withRegion(ReceiverConstants.REGION).build();
    }

    protected String getPartnerCodeConstant() {
        return ReceiverConstants.CA;
    }


    protected String getApplicationName() {
        return ReceiverConstants.LPR_LOCATION_CONSUMED_LA;
    }

    /*
     * Method to initialize Logger Context for ORS lambda
     *
     * @param transactionId
     * @param context
     */
    protected void initializeLogger(final UUID transactionId, final UUID correlationId, final Map<String, String> eventContext) {
        final CMDSLambdaLoggerUtil loggerUtil = new CMDSLambdaLoggerUtil();
        loggerUtil.initializeThreadContextMap(
                transactionId.toString(), getApplicationName(), correlationId.toString(), eventContext);
    }
}

