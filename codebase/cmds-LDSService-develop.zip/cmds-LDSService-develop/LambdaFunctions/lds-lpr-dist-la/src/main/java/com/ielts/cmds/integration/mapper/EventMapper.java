package com.ielts.cmds.integration.mapper;

import com.ielts.cmds.integration.model.LocationHierarchyAddressV1;
import com.ielts.cmds.integration.model.LocationHierarchyApprovedProductV1;
import com.ielts.cmds.integration.model.LocationNodeV1;
import com.ielts.cmds.lpr.common.out.model.LocationNode;
import lombok.extern.slf4j.Slf4j;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


/**
 * This class is used to map incoming event to appropriate API request body
 */
@Slf4j
public class EventMapper {

    public LocationNodeV1 locationConsumed(LocationNode locationNode) {


        final LocationNodeV1 locationNodeV1=new LocationNodeV1();
        locationNodeV1.setLocationUuid(locationNode.getLocationUuid());
        locationNodeV1.setParentLocationUuid(locationNode.getParentLocationUuid());
        locationNodeV1.setLocationTypeCode(locationNode.getLocationTypeCode());
        locationNodeV1.setPartnerCode(locationNode.getPartnerCode());
        locationNodeV1.setLocationStatus(locationNode.getLocationStatus());
        locationNodeV1.setLocationName(locationNode.getLocationName());
        locationNodeV1.setTestCentreNumber(locationNode.getTestCentreNumber());
        locationNodeV1.setApprovedDate(dateFormat(locationNode.getApprovedDate()));
        locationNodeV1.setTimezoneName(locationNode.getTimezoneName());
        locationNodeV1.setWebsiteURL(locationNode.getWebsiteURL());

        if (Objects.nonNull(locationNode.getLocationAddresses())) {
            List<LocationHierarchyAddressV1> addressList = new ArrayList<>();
            locationNode.getLocationAddresses().forEach(locationHierarchyAddresses -> {
                LocationHierarchyAddressV1 locationHierarchyAddressV1 = new LocationHierarchyAddressV1();
                locationHierarchyAddressV1.setAddressLine1(locationHierarchyAddresses.getAddressLine1());
                locationHierarchyAddressV1.setAddressLine2(locationHierarchyAddresses.getAddressLine2());
                locationHierarchyAddressV1.setAddressLine3(locationHierarchyAddresses.getAddressLine3());
                locationHierarchyAddressV1.setAddressLine4(locationHierarchyAddresses.getAddressLine4());
                locationHierarchyAddressV1.setAddressTypeUuid(locationHierarchyAddresses.getAddressTypeUuid());
                locationHierarchyAddressV1.setTerritoryUuid(locationHierarchyAddresses.getTerritoryUuid());
                locationHierarchyAddressV1.setCity(locationHierarchyAddresses.getCity());
                locationHierarchyAddressV1.setEmail(locationHierarchyAddresses.getEmail());
                locationHierarchyAddressV1.setPrimaryPhone(locationHierarchyAddresses.getPrimaryPhone());
                locationHierarchyAddressV1.setCountryIso3Code(locationHierarchyAddresses.getCountryIso3Code());
                locationHierarchyAddressV1.setPostalCode(locationHierarchyAddresses.getPostalCode());
                addressList.add(locationHierarchyAddressV1);
            });
            locationNodeV1.setLocationAddresses(addressList);
        }

        if(Objects.nonNull(locationNode.getApprovedProducts())) {
            List<LocationHierarchyApprovedProductV1> approvedProductList = new ArrayList<>();
            locationNode.getApprovedProducts().forEach(locationHierarchyApprovedProduct -> {
                LocationHierarchyApprovedProductV1 locationHierarchyApprovedProductV1 = new LocationHierarchyApprovedProductV1();
                locationHierarchyApprovedProductV1.setProductUuid(locationHierarchyApprovedProduct.getProductUuid());
                locationHierarchyApprovedProductV1.setEffectiveToDate(dateFormat(locationHierarchyApprovedProduct.getEffectiveToDate()));
                locationHierarchyApprovedProductV1.setEffectiveFromDate(dateFormat(locationHierarchyApprovedProduct.getEffectiveFromDate()));
                approvedProductList.add(locationHierarchyApprovedProductV1);
            });
            locationNodeV1.setApprovedProducts(approvedProductList);
        }

        log.info("LocationNodeV1 object{}: ", locationNodeV1.toString());
        return locationNodeV1;

    }

    public String dateFormat(LocalDate localDate) {

        if (Objects.nonNull(localDate)) {
           return DateTimeFormatter.ofPattern("yyyy-MM-dd").format(localDate);
        }
        return null;
    }
}