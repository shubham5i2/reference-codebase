package com.ielts.cmds.integration.model;


import java.util.List;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.ielts.cmds.lpr.common.enums.LocationStatus;
import com.ielts.cmds.lpr.common.enums.LocationTypeCode;
import com.ielts.cmds.lpr.common.enums.PartnerCode;

import lombok.NoArgsConstructor;

/**
 * LocationNodeV1
 */
@NoArgsConstructor
@JsonInclude(value = Include.NON_NULL)
public class LocationNodeV1 {

    private UUID locationUuid;

    @Override
    public String toString() {
        return "LocationNodeV1{" +
                "locationUuid=" + locationUuid +
                ", parentLocationUuid=" + parentLocationUuid +
                ", partnerCode=" + partnerCode +
                ", locationTypeCode=" + locationTypeCode +
                ", locationName='" + locationName + '\'' +
                ", locationStatus=" + locationStatus +
                ", testCentreNumber='" + testCentreNumber + '\'' +
                ", approvedDate=" + approvedDate +
                ", timezoneName='" + timezoneName + '\'' +
                ", websiteURL='" + websiteURL + '\'' +
                ", approvedProducts=" + approvedProducts +
                ", locationAddresses=" + locationAddresses +
                '}';
    }

    private UUID parentLocationUuid;

    private PartnerCode partnerCode;

    private LocationTypeCode locationTypeCode;

    private String locationName;

    private LocationStatus locationStatus;

    private String testCentreNumber;

    private String approvedDate;

    private String timezoneName;

    private String websiteURL;

    private List<LocationHierarchyApprovedProductV1> approvedProducts;

    private List<LocationHierarchyAddressV1> locationAddresses;
    
    public LocationNodeV1(UUID locationUuid, UUID parentLocationUuid, PartnerCode partnerCode,
	    LocationTypeCode locationTypeCode, String locationName, LocationStatus locationStatus,
	    String testCentreNumber, String approvedDate, String timezoneName, String websiteURL,
	    List<LocationHierarchyApprovedProductV1> approvedProducts,
	    List<LocationHierarchyAddressV1> locationAddresses) {
	this.locationUuid = locationUuid;
	this.parentLocationUuid = parentLocationUuid;
	this.partnerCode = partnerCode;
	this.locationTypeCode = locationTypeCode;
	this.locationName = locationName;
	this.locationStatus = locationStatus;
	this.testCentreNumber = testCentreNumber;
	this.approvedDate = approvedDate;
	this.timezoneName = timezoneName;
	this.websiteURL = websiteURL;
	this.approvedProducts = approvedProducts;
	this.locationAddresses = locationAddresses;
    }

    public UUID getLocationUuid() {
        return locationUuid;
    }

    public UUID getParentLocationUuid() {
        return parentLocationUuid;
    }

    public void setParentLocationUuid(UUID parentLocationUuid) {
        this.parentLocationUuid = parentLocationUuid;
    }

    public PartnerCode getPartnerCode() {
        return partnerCode;
    }

    public void setPartnerCode(PartnerCode partnerCode) {
        this.partnerCode = partnerCode;
    }

    public LocationTypeCode getLocationTypeCode() {
        return locationTypeCode;
    }

    public void setLocationTypeCode(LocationTypeCode locationTypeCode) {
        this.locationTypeCode = locationTypeCode;
    }

    public LocationStatus getLocationStatus() {
        return locationStatus;
    }

    public void setLocationStatus(LocationStatus locationStatus) {
        this.locationStatus = locationStatus;
    }


    public String getLocationName() {
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }


    public String getTestCentreNumber() {
        return testCentreNumber;
    }

    public void setTestCentreNumber(String testCentreNumber) {
        this.testCentreNumber = testCentreNumber;
    }

    public String getApprovedDate() {
        return approvedDate;
    }

    public void setApprovedDate(String approvedDate) {
        this.approvedDate = approvedDate;
    }

    public String getTimezoneName() {
        return timezoneName;
    }

    public void setTimezoneName(String timezoneName) {
        this.timezoneName = timezoneName;
    }

    public String getWebsiteURL() {
        return websiteURL;
    }

    public void setWebsiteURL(String websiteURL) {
        this.websiteURL = websiteURL;
    }

    public List<LocationHierarchyApprovedProductV1> getApprovedProducts() {
        return approvedProducts;
    }

    public void setApprovedProducts(List<LocationHierarchyApprovedProductV1> approvedProducts) {
        this.approvedProducts = approvedProducts;
    }

    public List<LocationHierarchyAddressV1> getLocationAddresses() {
        return locationAddresses;
    }

    public void setLocationAddresses(List<LocationHierarchyAddressV1> locationAddresses) {
        this.locationAddresses = locationAddresses;
    }

    public void setLocationUuid(UUID locationUuid) {
        this.locationUuid = locationUuid;
    }


}
