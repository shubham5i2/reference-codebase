package com.ielts.cmds.integration;


import com.ielts.cmds.api.evt020.ResultStatus;
import com.ielts.cmds.integration.constants.ReceiverConstants;
import com.ielts.cmds.integration.exception.LdsDistException;
import com.ielts.cmds.integration.mapper.EventMapper;
import com.ielts.cmds.integration.model.ResultStatusChangesV1;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.factory.AuthenticationClientFactory;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;
import com.ielts.cmds.serialization.lambda.AbstractLambda;
import com.ielts.cmds.serialization.lambda.config.ExternalOutputType;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import java.util.UUID;


import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import static com.ielts.cmds.integration.constants.ReceiverConstants.*;
import static java.lang.String.format;

@Slf4j
public class LdsResultStatusDistLa extends AbstractLambda<ResultStatus, ExternalOutputType> {

  private final String extCallbackUrl;
  private AuthenticationClient authenticationClient;
  private final AuthenticationClientFactory securityAuthenticationFactory;

  public LdsResultStatusDistLa()  {
    this.extCallbackUrl = System.getenv(ReceiverConstants.LA_ENDPOINT_URL);
    this.securityAuthenticationFactory = new EnvironmentAwareAuthenticationClientFactory();

  }
    @SneakyThrows
    @Override
    protected ExternalOutputType processRequest(ResultStatus resultStatus) {

      final EventMapper eventMapper = new EventMapper();
      ResultStatusChangesV1 resultStatusChangesV1 = eventMapper.resultStatusConsumed(resultStatus);
      log.info("Mapping Done: {}", resultStatusChangesV1.getResultStatusHistoryUuid());
      postRequestToLaAndPublishEvent(resultStatusChangesV1, extCallbackUrl);
      return null;
    }


  protected void postRequestToLaAndPublishEvent(final ResultStatusChangesV1 resBody,
                                                final String extCallbackUrl) {
    final UUID transactionId = ThreadLocalHeaderContext.getContext().getTransactionId();
    log.info(" In postRequestToLaAndPublishEvent Method!! \n ResponseBody :{} !! , Callback URL : {} !!", resBody,extCallbackUrl);
    try {
      final HttpHeaders eventHeaders = getHttpHeaders(ThreadLocalHeaderContext.getContext());
      log.info("EVentHeaders: {} !! ",eventHeaders );
      final HttpEntity<ResultStatusChangesV1> eventEntity = new HttpEntity<>(resBody, eventHeaders);
      log.info("EventEntity {}",eventEntity);
      final ResponseEntity<String> response = authenticationClient.getRestTemplate()
              .postForEntity(extCallbackUrl, eventEntity, String.class);
      if (!(response.getStatusCode() == HttpStatus.OK || response.getStatusCode() == HttpStatus.ACCEPTED)) {

        throw new LdsDistException(
                format(
                        "Request Failed with StatusCode:%s. TransactionId:%s",
                        response.getStatusCode(), transactionId));
      }
      log.info(
              "Request success with status code: {} . TransactionId: {} ",
              response.getStatusCode(),
              transactionId);
    } catch (Exception ex) {
      throw new LdsDistException(
              format("TransactionId:%s - Exception on posting requestBody: %s", transactionId, ex));
    }
  }

  protected String getApplicationName() {
    return ReceiverConstants.LPR_RESULT_STATUS_LA;
  }

  HttpHeaders getHttpHeaders(final HeaderContext eventHeader) throws Exception {

    final HttpHeaders httpHeaders = new HttpHeaders();
    log.info("In HttpHeaders Method  !!");
    httpHeaders.setContentType(MediaType.APPLICATION_JSON);
    httpHeaders.set(TRANSACTIONID, eventHeader.getTransactionId().toString());
    httpHeaders.set(CORRELATIONID, eventHeader.getCorrelationId().toString());
    httpHeaders.set(PARTNER_CODE, eventHeader.getPartnerCode());
    log.info("HttpHeaders setting !! {}  ", httpHeaders );
    authenticationClient=getAuthenticationClient(getPartner());
    log.info("After getAuthenticationClient() !! ");
    httpHeaders.set(authenticationClient.getAuthorizationHeaderName(), authenticationClient.getAccessToken());
    log.info(" HttpHeaders done !!");
    return httpHeaders;
  }

  protected AuthenticationClient  getAuthenticationClient(String partnerCode) throws Exception {
    log.info("Authentication client before !! :");
    log.info("In  getAuthenticationClient() : & authentication Client is: {} !!" ,authenticationClient);
    if (authenticationClient == null) {
      authenticationClient = securityAuthenticationFactory.getAuthenticationClient(partnerCode);
    }
    log.info(" AuthenticationClient : {} ",authenticationClient);
    return authenticationClient;
  }

  String getPartner() {
    return ReceiverConstants.CA;
  }

  @Override
  protected String getTopicName() {
    return null;
  }

}
