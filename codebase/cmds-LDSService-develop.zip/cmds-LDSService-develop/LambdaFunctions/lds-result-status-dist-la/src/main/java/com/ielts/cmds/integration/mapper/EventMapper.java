package com.ielts.cmds.integration.mapper;

import com.ielts.cmds.api.evt020.ResultStatus;
import com.ielts.cmds.integration.model.BookingV1;
import com.ielts.cmds.integration.model.ResultStatusChangesV1;
import com.ielts.cmds.integration.model.ResultStatusCommentV1;
import com.ielts.cmds.integration.model.ResultStatusLabelV1;
import com.ielts.cmds.integration.model.ResultStatusV1;
import com.ielts.cmds.integration.model.ResultStatusV1.ResultStatusTypeEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;


/**
 * This class is used to map incoming event to appropriate API request body
 */
@Slf4j
public class EventMapper {

  public ResultStatusChangesV1 resultStatusConsumed(ResultStatus resultStatus) {

    final ResultStatusChangesV1 resultStatusChangesV1 = new ResultStatusChangesV1();

    resultStatusChangesV1.setResultStatusHistoryUuid(String.valueOf(resultStatus
        .getResultStatusHistoryUuid()));
    resultStatusChangesV1.setStatusDateTime(statusDateTimeFormat(resultStatus.getStatusDateTime()));

    if (Objects.nonNull(resultStatus.getResultUuid())) {
      resultStatusChangesV1.setResultUuid(String.valueOf(resultStatus.getResultUuid()));
    }

      String centreNumber = getCenterNumber(resultStatus.getBooking().getCompositeCandidateNumber());
      String candidateNumber = getCandidateNumber(resultStatus.getBooking().getCompositeCandidateNumber());
      BookingV1 bookingV1 = new BookingV1();
      bookingV1.setCandidateNumber(getCandidateNumber(candidateNumber));
      bookingV1.setCentreNumber(getCenterNumber(centreNumber));
      bookingV1.setTestDate(testDateFormat(resultStatus.getBooking().getTestDate()));
      resultStatusChangesV1.setBooking(bookingV1);
    
      ResultStatusV1 resultStatusV1 = new ResultStatusV1();
      resultStatusV1.setResultStatusTypeUuid(String.valueOf(resultStatus.getResultStatus()
          .getResultStatusTypeUuid()));
      resultStatusV1.setResultStatusType(getResultStatusType(resultStatus.getResultStatus().getResultStatusType())); 
      resultStatusChangesV1.setResultStatus(resultStatusV1);
    
    if (Objects.nonNull(resultStatus.getResultStatusLabel())) {
      ResultStatusLabelV1 resultStatusLabelV1 = new ResultStatusLabelV1();
      resultStatusLabelV1.setResultStatusLabelUuid(String.valueOf(resultStatus.getResultStatusLabel()
          .getResultStatusLabelUuid()));
      resultStatusLabelV1.setResultStatusLabelText(resultStatus.getResultStatusLabel()
          .getResultStatusLabelText());

      resultStatusChangesV1.setResultStatusLabel(resultStatusLabelV1);
    }

    if (Objects.nonNull(resultStatus.getResultStatusComment())) {
      ResultStatusCommentV1 resultStatusCommentV1 = new ResultStatusCommentV1();
      resultStatusCommentV1.setResultStatusCommentUuid(String.valueOf(resultStatus
          .getResultStatusComment().getResultStatusCommentUuid()));
      resultStatusCommentV1.setResultStatusCommentText(resultStatus.getResultStatusComment()
          .getResultStatusCommentText());
      resultStatusCommentV1.setResultStatusCommentOtherText(resultStatus
          .getResultStatusCommentOtherText());

      resultStatusChangesV1.setResultStatusComment(resultStatusCommentV1);
    }

    log.info("resultStatusChangesV1 object{}: ", resultStatusChangesV1);
    return resultStatusChangesV1;

  }

  public ResultStatusTypeEnum getResultStatusType(Serializable resultStatusType) {
	  if(resultStatusType != null) {
		  for(ResultStatusTypeEnum enumValue: ResultStatusTypeEnum.values()) {
			  if(enumValue.toString().equals(resultStatusType.toString())) {
				  return enumValue;
			  }
		  }
	  }
	  
	return null;
  }

  public String getCandidateNumber(String compositeCandidateNumber) {
	  if(StringUtils.isEmpty(compositeCandidateNumber)) {
	  return null;
	  }
	  return compositeCandidateNumber.substring(compositeCandidateNumber.length() - 6);
  }

  public String getCenterNumber(String compositeCandidateNumber) {
	  if(StringUtils.isEmpty(compositeCandidateNumber)) {
	     return null;
	  }
	  return compositeCandidateNumber.substring(0, 5);
  } 
  

  public String testDateFormat(LocalDate localDate) {
    if (Objects.nonNull(localDate)) {
      return DateTimeFormatter.ofPattern("yyyy-MM-dd").format(localDate);
    }
    return null;
  }

  public String statusDateTimeFormat(OffsetDateTime offsetDateTime) {
    if (Objects.nonNull(offsetDateTime)) {
      return DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'").format(offsetDateTime);
    }
    return null;
  }

}