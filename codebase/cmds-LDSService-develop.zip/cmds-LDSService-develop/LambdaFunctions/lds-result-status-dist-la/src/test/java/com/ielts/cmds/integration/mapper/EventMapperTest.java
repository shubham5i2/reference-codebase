package com.ielts.cmds.integration.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.io.Serializable;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import com.ielts.cmds.api.evt020.ResultStatusResultStatus.ResultStatusTypeEnum;

class EventMapperTest {

  @Spy
  @InjectMocks
  private EventMapper eventMapper;
  @BeforeEach
  public void setUp(){
	  MockitoAnnotations.openMocks(this);
    eventMapper = new EventMapper();
  }
  
  @Test
  void testDateFormatTest(){
    String formattedDate = eventMapper.testDateFormat(LocalDate.of(2024,1,9));
    assertNotNull(formattedDate);

    String nullDate = eventMapper.testDateFormat(null);
    assertNull(nullDate);
  }

  @Test
  void statusDateTimeFormatTest(){
    String formattedDateTime = eventMapper.statusDateTimeFormat(OffsetDateTime.now());
    assertNotNull(formattedDateTime);
    
    
    String nullFormattedDateTime = eventMapper.statusDateTimeFormat(null);
    assertNull(nullFormattedDateTime);
  }
  @Test
  void testgetCandidateNumber(){ 
    String candidateNumber = eventMapper.getCandidateNumber("BAA123456");
    assertNotNull(candidateNumber);
    assertEquals("123456",candidateNumber);
    
    String nullCandidateNumber = eventMapper.getCandidateNumber(null);
    assertNull(nullCandidateNumber);
  } 
  
  @Test
  void testgetCenterNumber(){ 
    String candidateNumber = eventMapper.getCenterNumber("2135954");
    assertNotNull(candidateNumber);
    assertEquals("21359",candidateNumber);
    
    String nullCandidateNumber = eventMapper.getCenterNumber(null);
    assertNull(nullCandidateNumber);
  } 
  
  @Test
  void testgetResultStatusType() {
	ResultStatusTypeEnum expectedEnum = ResultStatusTypeEnum.ABSENT;
	com.ielts.cmds.api.evt020.ResultStatusResultStatus.ResultStatusTypeEnum inputEnum = expectedEnum;
	assertEquals(expectedEnum,inputEnum);
	ResultStatusTypeEnum nullInputEnum = null;
	Serializable nullResultenum = eventMapper.getResultStatusType(nullInputEnum);
	assertNull(nullResultenum);
  }

}

