package com.ielts.cmds.integration;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.api.evt020.ResultStatus;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.integration.constants.ReceiverConstants;
import com.ielts.cmds.integration.exception.LdsDistException;
import com.ielts.cmds.integration.model.ResultStatusChangesV1;
import com.ielts.cmds.integration.utils.SQSEventBodySetup;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.util.UUID;

import static com.ielts.cmds.serialization.lambda.constants.EventAdapterConstants.AWS_REGION;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LdsResultStatusDistLaTest {

  @Mock
  ObjectMapper mapper;

  @Mock
  AuthenticationClient authenticationClient;

  @Mock
  private LdsResultStatusDistLa ldsResultStatusDistLa;

  @Mock
  private EnvironmentAwareAuthenticationClientFactory securityAuthenticationFactory;

  @Mock
  private RestTemplate restTemplate;


  @BeforeEach
  public void setUp() {
    System.setProperty(AWS_REGION, "eu-west-2");
    mapper.registerModule(new JavaTimeModule());
    mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
    mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    mapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);

    ReflectionTestUtils.setField(ldsResultStatusDistLa, "securityAuthenticationFactory", securityAuthenticationFactory);
    ReflectionTestUtils.setField(ldsResultStatusDistLa, "extCallbackUrl", "https://wiremock.shared.cmdsiz.com/ors/invoke/v1/lds");

    CMDSHeaderContext header = new CMDSHeaderContext();
    header.setCorrelationId(UUID.randomUUID());
    header.setTransactionId(UUID.randomUUID());
    header.setPartnerCode("CA");
    com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext.setContext(header);

  }

  @Test
  void getApplicationName() {
    when(ldsResultStatusDistLa.getApplicationName()).thenCallRealMethod();
    String applicationName = ldsResultStatusDistLa.getApplicationName();
    assertEquals(ReceiverConstants.LPR_RESULT_STATUS_LA, applicationName);
  }

  @Test
  void getPartnerCodeConstants_whenGetPartnerCodeConstants_thenReturnCA() {
    LdsResultStatusDistLa ldsResultStatusDistLaSpy = Mockito.spy(ldsResultStatusDistLa);
    String partnerCodeConstants = ldsResultStatusDistLaSpy.getPartner();
    assertEquals(ReceiverConstants.CA, partnerCodeConstants);
  }

  @Test
  void verifyCallTo_authClient() throws Exception {
    LdsResultStatusDistLa ldsResultStatusDistLaSpy = Mockito.spy(ldsResultStatusDistLa);
    doReturn(authenticationClient).when(ldsResultStatusDistLaSpy).getAuthenticationClient("CA");
    AuthenticationClient authClient = ldsResultStatusDistLaSpy.getAuthenticationClient("CA");
    assertEquals(authenticationClient, authClient);
  }


  @Test
  void testProcessRequest() throws Exception {
    LdsResultStatusDistLa ldsResultStatusDistLaSpy = Mockito.spy(ldsResultStatusDistLa);
    ReflectionTestUtils.setField(ldsResultStatusDistLaSpy, "extCallbackUrl", "http://localhost");
    doReturn(authenticationClient).when(ldsResultStatusDistLaSpy).getAuthenticationClient("CA");
    when(authenticationClient.getAuthorizationHeaderName()).thenReturn("Authorization");
    when(authenticationClient.getAccessToken()).thenReturn("XYZ");
    when(authenticationClient.getRestTemplate()).thenReturn(restTemplate);
    ResponseEntity<String> response = new ResponseEntity<>(HttpStatus.OK);
    doReturn(response).when(restTemplate).postForEntity(ArgumentMatchers.anyString(),
            any(HttpEntity.class), eq(String.class));
    ResultStatus resultStatus = SQSEventBodySetup.setResultStatus();
    HeaderContext headerCtx = new HeaderContext();
    headerCtx.setTransactionId(UUID.randomUUID());
    headerCtx.setCorrelationId(UUID.randomUUID());
    headerCtx.setPartnerCode("CA");
    ThreadLocalHeaderContext.setContext(headerCtx);
    ldsResultStatusDistLaSpy.processRequest(resultStatus);
    assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());
  }

  @Test
  void whenLegacyDeliveryHasValidAuthenticationHeader_ThenVerifyCallToRestTemplate() throws Exception {
    LdsResultStatusDistLa ldsResultStatusDistLaSpy = Mockito.spy(ldsResultStatusDistLa);
    ReflectionTestUtils.setField(ldsResultStatusDistLaSpy, "extCallbackUrl", "http://localhost");
    doReturn(authenticationClient).when(ldsResultStatusDistLaSpy).getAuthenticationClient("CA");
    when(authenticationClient.getAuthorizationHeaderName()).thenReturn("Authorization");
    when(authenticationClient.getAccessToken()).thenReturn("XYZ");
    when(authenticationClient.getRestTemplate()).thenReturn(restTemplate);
    ResponseEntity<String> response = new ResponseEntity<>(HttpStatus.OK);
    doReturn(response).when(restTemplate).postForEntity(ArgumentMatchers.anyString(),
            any(HttpEntity.class), eq(String.class));
    ResultStatus resultStatus = SQSEventBodySetup.setResultStatus();
    HeaderContext headerCtx = new HeaderContext();
    headerCtx.setTransactionId(UUID.randomUUID());
    headerCtx.setCorrelationId(UUID.randomUUID());
    headerCtx.setPartnerCode("CA");
    ThreadLocalHeaderContext.setContext(headerCtx);
    assertDoesNotThrow(() -> ldsResultStatusDistLaSpy.processRequest(resultStatus));
    assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());
  }

  @Test
  void whenEventBodyIsNull() throws Exception {
    LdsResultStatusDistLa ldsResultStatusDistLaSpy = Mockito.spy(ldsResultStatusDistLa);
    ReflectionTestUtils.setField(ldsResultStatusDistLaSpy, "extCallbackUrl", "http://localhost");
    doReturn(authenticationClient).when(ldsResultStatusDistLaSpy).getAuthenticationClient("CA");
    when(authenticationClient.getAuthorizationHeaderName()).thenReturn("Authorization");
    when(authenticationClient.getAccessToken()).thenReturn("XYZ");
    when(authenticationClient.getRestTemplate()).thenReturn(restTemplate);
    ResponseEntity<String> response = new ResponseEntity<>(HttpStatus.OK);
    doReturn(response).when(restTemplate).postForEntity(ArgumentMatchers.anyString(),
            any(HttpEntity.class), eq(String.class));
    ResultStatus resultStatus = SQSEventBodySetup.setResultStatus();
    HeaderContext headerCtx = new HeaderContext();
    headerCtx.setTransactionId(UUID.randomUUID());
    headerCtx.setCorrelationId(UUID.randomUUID());
    headerCtx.setPartnerCode("CA");
    ThreadLocalHeaderContext.setContext(headerCtx);
    assertDoesNotThrow(() -> ldsResultStatusDistLaSpy.processRequest(resultStatus));
    assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());
  }

  @Test
  void whenLegacyDeliveryHasInvalidAuthenticationHeader_ThenVerifyCallToRestTemplate() throws Exception {
    LdsResultStatusDistLa ldsResultStatusDistLaSpy = Mockito.spy(ldsResultStatusDistLa);
    ReflectionTestUtils.setField(ldsResultStatusDistLaSpy, "extCallbackUrl", "http://localhost");
    doReturn(authenticationClient).when(ldsResultStatusDistLaSpy).getAuthenticationClient("CA");
    when(authenticationClient.getAuthorizationHeaderName()).thenReturn("Authorization");
    when(authenticationClient.getAccessToken()).thenReturn("XYZ");
    ResponseEntity<String> response = new ResponseEntity<>(HttpStatus.OK);

    doReturn(restTemplate).when(authenticationClient).getRestTemplate();
    doReturn(response).when(restTemplate).postForEntity(ArgumentMatchers.anyString(),
            ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.eq(String.class));

    ResultStatus resultStatus = SQSEventBodySetup.setResultStatus();
    HeaderContext headerCtx = new HeaderContext();
    headerCtx.setTransactionId(UUID.randomUUID());
    headerCtx.setCorrelationId(UUID.randomUUID());
    headerCtx.setPartnerCode("CA");
    ThreadLocalHeaderContext.setContext(headerCtx);
    assertDoesNotThrow(() -> ldsResultStatusDistLaSpy.processRequest(resultStatus));
    verify(ldsResultStatusDistLaSpy, times(1)).postRequestToLaAndPublishEvent(ArgumentMatchers.any(ResultStatusChangesV1.class), ArgumentMatchers.anyString());
  }

  @Test
  void whenLegacyDeliveryHasInvalidAuthenticationHeader_ThenReturnFailResponseFromRest() throws Exception {
    LdsResultStatusDistLa ldsResultStatusDistLaSpy = Mockito.spy(ldsResultStatusDistLa);
    ReflectionTestUtils.setField(ldsResultStatusDistLaSpy, "extCallbackUrl", "http://localhost");
    doReturn(authenticationClient).when(ldsResultStatusDistLaSpy).getAuthenticationClient("CA");
    when(authenticationClient.getAuthorizationHeaderName()).thenReturn("Authorization");
    when(authenticationClient.getAccessToken()).thenReturn("XYZ");
    ResponseEntity<String> response = new ResponseEntity<>(HttpStatus.FORBIDDEN);

    doReturn(restTemplate).when(authenticationClient).getRestTemplate();
    doReturn(response).when(restTemplate).postForEntity(ArgumentMatchers.anyString(),
            ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.eq(String.class));

    ResultStatus resultStatus = SQSEventBodySetup.setResultStatus();
    HeaderContext headerCtx = new HeaderContext();
    headerCtx.setTransactionId(UUID.randomUUID());
    headerCtx.setCorrelationId(UUID.randomUUID());
    headerCtx.setPartnerCode("CA");
    ThreadLocalHeaderContext.setContext(headerCtx);

    assertThrows(LdsDistException.class, () -> ldsResultStatusDistLaSpy.processRequest(resultStatus));
  }

  @Test
  void testgetAuthenticationClient() throws Exception {
    LdsResultStatusDistLa ldsResultStatusDistLaSpy = Mockito.spy(ldsResultStatusDistLa);
    doReturn(authenticationClient).when(securityAuthenticationFactory).getAuthenticationClient("CA");
    assertNotNull(ldsResultStatusDistLaSpy.getAuthenticationClient("CA"));
  }

  @Test
  void testGetTopicName() {
    LdsResultStatusDistLa ldsResultStatusDistLaSpy = Mockito.spy(ldsResultStatusDistLa);
    assertNull(ldsResultStatusDistLaSpy.getTopicName());
  }

}
