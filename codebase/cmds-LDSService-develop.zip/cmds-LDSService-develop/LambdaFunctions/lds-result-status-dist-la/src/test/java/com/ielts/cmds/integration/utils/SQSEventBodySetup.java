package com.ielts.cmds.integration.utils;


import com.ielts.cmds.api.evt020.*;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.UUID;

public class SQSEventBodySetup {


  public static ResultStatus setResultStatus() {
    final ResultStatus resultStatus = new ResultStatus();
    ResultStatusBooking resultStatusBooking = new ResultStatusBooking();
    resultStatusBooking.setCompositeCandidateNumber("240AU20000168");
    resultStatusBooking.setTestDate(LocalDate.now());

    ResultStatusResultStatus resultStatusType = new ResultStatusResultStatus();
    resultStatusType.setResultStatusTypeUuid(UUID.fromString("33cbdfca-0583-4542-a830-dd96d871c452"));
    resultStatusType.setResultStatusType(ResultStatusResultStatus.ResultStatusTypeEnum.CONFIRMED);

    ResultStatusResultStatusLabel resultStatusLabel = new ResultStatusResultStatusLabel();
    resultStatusLabel.setResultStatusLabelUuid(UUID.fromString("33cbdfca-0583-4542-a830-dd96d871c452"));
    resultStatusLabel.setResultStatusLabelText("Label");

    ResultStatusResultStatusComment resultStatusComment = new ResultStatusResultStatusComment();
    resultStatusComment.setResultStatusCommentUuid(UUID.fromString("33cbdfca-0583-4542-a830-dd96d871c452"));
    resultStatusComment.setResultStatusCommentText("Comment Text");

    resultStatus.setResultStatusHistoryUuid(UUID.fromString("33cbdfca-0583-4542-a830-dd96d871c452"));
    resultStatus.setResultUuid(UUID.fromString("33cbdfca-0583-4542-a830-dd96d871c452"));
    resultStatus.setStatusDateTime(OffsetDateTime.now());
    resultStatus.setBooking(resultStatusBooking);
    resultStatus.setResultStatus(resultStatusType);
    resultStatus.setResultStatusLabel(resultStatusLabel);
    resultStatus.setResultStatusComment(resultStatusComment);
    resultStatus.setResultStatusCommentOtherText("Other text");

    return resultStatus;
  }

}


