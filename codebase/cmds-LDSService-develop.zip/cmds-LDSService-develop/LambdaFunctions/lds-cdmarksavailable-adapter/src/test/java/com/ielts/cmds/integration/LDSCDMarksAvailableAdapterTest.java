package com.ielts.cmds.integration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.sns.AmazonSNS;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.evt176.MarksFileDetailsV1;
import com.ielts.cmds.integration.testdata.SQSEventBodySetup;
import com.ielts.cmds.serialization.lambda.config.SNSClientConfig;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

@ExtendWith(MockitoExtension.class)
class LDSCDMarksAvailableAdapterTest {

	@Mock
	private ObjectMapper mapper;
	
	@Mock
	private AmazonS3 s3Client;

	@Mock
	private AmazonSNS snsClient;

	@Spy
	@InjectMocks
	private LDSCDMarksAvailableAdapter ldsMarksAvailableAdapter;

	private static MockedStatic<SNSClientConfig> snsClientConfig;

	private final String topicArn = "topic-out";

	@BeforeAll
	static void init() {
		snsClientConfig = Mockito.mockStatic(SNSClientConfig.class);
	}

	@AfterAll
	static void close() {
		snsClientConfig.close();
	}

	@BeforeEach
	void setup() {
		HeaderContext headerContext = SQSEventBodySetup.getThreadHeaderContext();
		ThreadLocalHeaderContext.setContext(headerContext);
		snsClientConfig.when(SNSClientConfig::getSNSClient).thenReturn(snsClient);
		ReflectionTestUtils.setField(ldsMarksAvailableAdapter, "topicArn", topicArn);
	}

	@Test
	void getTopicName() {
		assertNotNull(ldsMarksAvailableAdapter.getTopicName());
		assertEquals("topic-out", ldsMarksAvailableAdapter.getTopicName());
	}
	
	@Test
	void processRequest() throws JsonProcessingException {
		MarksFileDetailsV1 marksFileDetailsV1 = new MarksFileDetailsV1();
		marksFileDetailsV1.setFileName("file");
		marksFileDetailsV1.setPresignedUrl("www.test.org");
		assertNotNull(ldsMarksAvailableAdapter.processRequest(marksFileDetailsV1));
		assertEquals("POST/v1/cdmarksavailable",ThreadLocalHeaderContext.getContext().getEventName());
	}


}
