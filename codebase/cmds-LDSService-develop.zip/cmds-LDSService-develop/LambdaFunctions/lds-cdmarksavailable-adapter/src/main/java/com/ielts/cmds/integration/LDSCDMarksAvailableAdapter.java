package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.constants.LADSConstants.POST_V1_CDMARKSAVAILABLE;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.api.evt176.MarksFileDetailsV1;
import com.ielts.cmds.integration.constants.LADSConstants;
import com.ielts.cmds.serialization.lambda.AbstractLambda;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import lombok.SneakyThrows;

public class LDSCDMarksAvailableAdapter extends AbstractLambda<MarksFileDetailsV1, MarksFileDetailsV1> {

	private final String topicArn;
	private final ObjectMapper mapper;

	public LDSCDMarksAvailableAdapter() {
		this.mapper = new ObjectMapper();
		this.topicArn = System.getenv(LADSConstants.LDS_INT_TOPIC_IN);
		mapper.registerModule(new JavaTimeModule());
		mapper.configure(DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE, false);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
		mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
		mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);

	}

	@Override
	protected String getTopicName() {
		return topicArn;
	}

	@Override
	@SneakyThrows
	protected MarksFileDetailsV1 processRequest(final MarksFileDetailsV1 marksFileDetailsV1) {
		ThreadLocalHeaderContext.getContext().setEventName(POST_V1_CDMARKSAVAILABLE);
		return marksFileDetailsV1;
		
	}

}

