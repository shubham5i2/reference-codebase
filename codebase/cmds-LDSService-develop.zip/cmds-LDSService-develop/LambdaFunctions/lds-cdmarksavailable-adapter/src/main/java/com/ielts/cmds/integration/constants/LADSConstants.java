package com.ielts.cmds.integration.constants;

public final class LADSConstants {

    private LADSConstants() {}

    public static final String LDS_INT_TOPIC_IN = "topic_arn";
    public static final String POST_V1_CDMARKSAVAILABLE="POST/v1/cdmarksavailable";

}
