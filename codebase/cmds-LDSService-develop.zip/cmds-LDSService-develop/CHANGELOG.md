## [1.9.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.8.1...v1.9.0) (2024-05-15)


### ⚠ BREAKING CHANGES

* Create a tag for IMOD-59861 retrofit

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService!59
* Retrofit Imod 59861

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService!58

* Merge branch 'feature/retrofit-IMOD-59861' into 'develop' ([b93cedc](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/commit/b93cedc23172298bc5225eb3e8a7eea2655d0696))
* Merge branch 'hotfix' into 'develop' ([3740193](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/commit/3740193f06a577202334ec54ff65b4c17aed6c24))

### [1.8.2-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.8.1...v1.8.2-hotfix.1) (2024-04-19)

### [1.8.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.8.0...v1.8.1) (2024-03-07)

## [1.8.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.7.1...v1.8.0) (2024-02-28)

### [1.7.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.7.0...v1.7.1) (2024-01-30)

## [1.7.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.6.0...v1.7.0) (2024-01-10)

## [1.6.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.5.0...v1.6.0) (2023-12-21)

## [1.5.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.4.0...v1.5.0) (2023-12-21)

## [1.4.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.3.0...v1.4.0) (2023-12-21)

## [1.3.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.2.0...v1.3.0) (2023-11-22)

## [1.2.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.1.0...v1.2.0) (2023-11-22)

## [1.1.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.0.22...v1.1.0) (2023-11-10)

### [1.0.22](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.0.21...v1.0.22) (2023-10-31)

### [1.0.21](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.0.20...v1.0.21) (2023-09-22)


### Features

* <h2>Defect Fix Retrofit </h2><p>IMOD-51466 : CMDS-CUPA/IDP-UAT: Results aren't delivered to RO selections even after releasing results for IOC, IOL and OSR TTs<br/></p> ([043882c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/commit/043882ca4b5682957aadd79ac9a4165ced0894a2))

### [1.0.20](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.0.19...v1.0.20) (2023-08-17)


### Features

* <h2>Technical Features</h2><p><strong>Purpose</strong><br />EVT004 version update to 1.1 <br /></p> ([0aae2df](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/commit/0aae2dfce2adc8e4b02c232633eb9e6d854c67db))

### [1.0.19](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.0.18...v1.0.19) (2023-08-08)


### Features

* <h2>Functional Features</h2><h3>LADS - Consume updated EVT004 swagger strucuture</h3><p><strong>Purpose:</strong><br />LADS consumes evt-004 and evt-020</p> ([547ab98](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/commit/547ab98f80207d03b5961c19fe6575fecd66d2ae))

### [1.0.18](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.0.17...v1.0.18) (2023-07-28)


### Features

* <h2>Technical Features</h2><h3>IMOD-40419 Phoenix: LADS : Upgrade for Object Serialized Event Consumption in lds-selections-dist-la</h3><p><strong>Purpose: Event serialization for selection consumer lambda</strong><br /></strong><br /></p><h3>IMOD-40421 Phoenix: LADS : Upgrade for Object Serialized Event Consumption in lds-ro-changed-dist-la</h3><p><strong>Purpose: Event serialization for RO consumer lambda</strong><br /></strong><br /></p> ([90b4b41](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/commit/90b4b41fd39438e095bbe2f6184fa55f4f3e1f60))

### [1.0.17](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.0.16...v1.0.17) (2023-06-15)


### ⚠ BREAKING CHANGES

* feature/ILAND-5657-partnercode-retrofit38311

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService!30

* Merge branch 'feature/ILAD-5657-partnercode-retrofit38311' into 'develop' ([a0cc3a5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/commit/a0cc3a50d30d1c9b41fa6d3b589728e12c207dd4))

### [1.0.16](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.0.15...v1.0.16) (2023-06-13)


### ⚠ BREAKING CHANGES

* Feature/IMOD-44647 bug fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService!28

### Features

* Merge branch 'feature/IMOD-44647' into 'develop' ([5da0a4b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/commit/5da0a4b3b096634aa11efe7c725cfdd5cb7ee224))

### [1.0.15](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.0.14...v1.0.15) (2023-05-30)


### ⚠ BREAKING CHANGES

* feature/dummy-change-percentile-deployment

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService!27

* Merge branch 'feature/dummy-change-percentile-deployment' into 'develop' ([669af1e](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/commit/669af1ea54ff4f4de07e7592cd3e7e43e185ed38))

### [1.0.14](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.0.13...v1.0.14) (2023-04-07)


### ⚠ BREAKING CHANGES

* feature/imod-42622-calculate-percentage-score.

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService!25

* Merge branch 'feature/imod-42622' into 'develop' ([25e9ac8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/commit/25e9ac828010d9b53ec5d631d6361ecb6d3e767c))

### [1.0.13](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.0.12...v1.0.13) (2023-04-04)


### ⚠ BREAKING CHANGES

* feature/defect-imod-44262-partner-code-fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService!24

* Merge branch 'feature/defect-imod-44262' into 'develop' ([10c165c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/commit/10c165cae111fe416165217bc53f7d5944dbe9fb))

### [1.0.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.0.11...v1.0.12) (2023-03-02)


### ⚠ BREAKING CHANGES

* feature/update-java-event-adapter-library-version

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService!18

* Merge branch 'feature/update-java-event-adapter-library-version' into 'develop' ([ae4a65a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/commit/ae4a65a57b2c866638ec48633a58fe435265f852))

### [1.0.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.0.10...v1.0.11) (2023-02-16)


### ⚠ BREAKING CHANGES

* feature/imod-40434-event-serialization-lpr-event-version-updation

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService!16

* Merge branch 'feature/imod-40434-event-serialization' into 'develop' ([85f43a0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/commit/85f43a027aba4c4bd73ef27f66ed5e5e5c56504b))

### [1.0.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.0.9...v1.0.10) (2023-02-15)


### ⚠ BREAKING CHANGES

* feature/imod-40434-event-serialization-lds-location-dist-la

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService!15

* Merge branch 'feature/imod-40434-event-serialization' into 'develop' ([e1c646c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/commit/e1c646c42466d62ea80a72ad932be33a079fdfa3))

### [1.0.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.0.8...v1.0.9) (2023-02-15)


### ⚠ BREAKING CHANGES

* feature/imod-41587-event-serialization-lds-result-status-dist-la

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService!14

* Merge branch 'feature/imod-41587-event-serialization' into 'develop' ([178d94c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/commit/178d94c7d57e4c47d376ee8f766861d8813fe820))

### [1.0.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.0.7...v1.0.8) (2023-01-31)


### ⚠ BREAKING CHANGES

* feature/imod-40797_yml_staging_changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService!13

* Merge branch 'feature/imod-40797_yml_staging_changes' into 'develop' ([f1e1eae](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/commit/f1e1eae240b8ab6bb5ef5a917520b4950b9cf2ae))

### [1.0.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.0.6...v1.0.7) (2023-01-27)


### ⚠ BREAKING CHANGES

* feature/imod-38069_eor_evt-20_lads

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService!7

* Merge branch 'feature/imod-38069_eor_evt-20_lads' into 'develop' ([e633f4c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/commit/e633f4ce00d4f872b51c20c3379c0966e911ca09))

### [1.0.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.0.5...v1.0.6) (2023-01-24)


### ⚠ BREAKING CHANGES

* feature/IMOD-30322-mmds_changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService!12

* Merge branch 'feature/mmds_changes' into 'develop' ([05ac2e5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/commit/05ac2e5c34ec50a5b9acaedd2d7f2e63587b84cc))

### [1.0.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.0.4...v1.0.5) (2023-01-05)


### ⚠ BREAKING CHANGES

* feature/imod-38998-defect-test

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService!11

* Merge branch 'feature/imod-38998-defect-test' into 'develop' ([8898a4b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/commit/8898a4b4265f103b63c468db96ada37b2d98174d))

### [1.0.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.0.3...v1.0.4) (2023-01-03)


### ⚠ BREAKING CHANGES

* Feature/imod-37389-RD-lambda-movement

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService!9

* Merge branch 'feature/imod-37389_RD' into 'develop' ([f8d0109](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/commit/f8d01097de816cabc7f09a7b93ef6154fc8cf189))

### [1.0.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.0.2...v1.0.3) (2023-01-03)


### ⚠ BREAKING CHANGES

* Feature/imod-38817-RO-lambda-movement

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService!10

* Merge branch 'feature/imod_38817_RO' into 'develop' ([d1d2f8f](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/commit/d1d2f8f7117c84d18a889d539c35717373b03c42))

### [1.0.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.0.1...v1.0.2) (2022-12-23)


### ⚠ BREAKING CHANGES

* feature/imod-38395_evt_112_locationchanged

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService!8

* Merge branch 'feature/IMOD-38395_evt_112_locationchanged' into 'develop' ([7af40b2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/commit/7af40b284d5f7585cc2f518a5886d5855dff5b5f))

### [1.0.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/compare/v1.0.0...v1.0.1) (2022-11-10)


### ⚠ BREAKING CHANGES

* feature/imod37390_lds-lpr-dist-la_lambda

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService!5

* Merge branch 'feature/imod37390_lds-lpr-dist-la_lambda' into 'develop' ([3185741](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-LDSService/commit/318574105e6dde893612ef1a4d7bdc298c8c1609))

## 1.0.0 (2022-03-15)
