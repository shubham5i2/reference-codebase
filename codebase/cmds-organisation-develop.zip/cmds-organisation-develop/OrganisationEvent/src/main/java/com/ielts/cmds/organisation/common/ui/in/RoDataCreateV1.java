package com.ielts.cmds.organisation.common.ui.in;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ielts.cmds.organisation.common.enums.MethodOfDeliveryEnum;
import com.ielts.cmds.organisation.common.enums.OrganisationStatusEnum;
import com.ielts.cmds.organisation.common.enums.VerificationStatusEnum;
import java.util.UUID;
import lombok.Data;
import lombok.NoArgsConstructor;

/** RoDataCreateV1 */
@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RoDataCreateV1 {

    private String organisationName;

    private UUID organisationTypeUuid;

    private VerificationStatusEnum verificationStatus;

    private RoDataCreateV1Addresses addresses;

    private String partnerCode;

    private String partnerContact;

    private MethodOfDeliveryEnum methodOfDelivery;

    private UUID sectorTypeUuid;

    private OrganisationStatusEnum organisationStatus;

    private String websiteUrl;

    private String crmSystem;

    private String organisationCode;

    private Integer resultAvailableForYears;

    private Boolean ieltsDisplayFlag;

    private Boolean orsDisplayFlag;
    
    private Boolean acceptsIOL;
    
    private Boolean acceptsSSR;

    private Boolean acceptsAC;

    private Boolean acceptsGT;

    private RoDataCreateV1Notes notes;

    private RoDataCreateV1AlternateNames alternateNames;

    private RoDataCreateV1Contacts contacts;

    private RoDataCreateV1MinimumScores minimumScores;

    private RoDataCreateV1LinkedOrganisations linkedOrganisations;
}
