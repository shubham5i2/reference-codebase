package com.ielts.cmds.organisation.common.ui.in;

import java.math.BigDecimal;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ielts.cmds.organisation.common.enums.ComponentEnum;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * RoDataCreateV1MinimumScore
 */

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RoDataCreateV1MinimumScore {

	private UUID moduleTypeUuid;

	private ComponentEnum component;

	private BigDecimal minimumScoreValue;

}
