package com.ielts.cmds.organisation.common.ui.in;

import java.util.ArrayList;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Addresss linked to Recognising Organisation/Verified Organisation of Address
 * Type - Main/Delivery
 */

@Data
@EqualsAndHashCode(callSuper = true)
public class RoDataUpdateV1Addresses extends ArrayList<RoDataUpdateV1Address> {

	/**
	 * Generated SerialVersion ID
	 */
	private static final long serialVersionUID = -1248866981878280601L;

}
