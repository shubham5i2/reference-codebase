package com.ielts.cmds.organisation.common.ui.in;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * RoDataCreateV1Note
 */

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RoDataCreateV1Note {

	private String noteContent;

}
