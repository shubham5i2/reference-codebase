package com.ielts.cmds.organisation.common.ui.in;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;


/**
 * List of Linked Organisations to an Organisation with link  Type PARENT_RO , RESULTS_DELIVERY, REPLACED_BY
 *
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class RoDataUpdateV1LinkedOrganisations  extends ArrayList<RoDataUpdateV1LinkedOrganisation> {

    /**
     * Generated SerialVersion ID
     */
    private static final long serialVersionUID = 89271789851022485L;
}
