package com.ielts.cmds.organisation.common.ui.in;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

/** SearchPaginationV1 */
@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SearchPaginationV1 {

    private Integer pageNumber;

    private Integer pageSize;
}
