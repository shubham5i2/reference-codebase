package com.ielts.cmds.organisation.common.ui.in;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * RoDataCreateV1Address
 */

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RoDataCreateV1Address {

	private UUID addressTypeUuid;

	private String addressLine1;

	private String addressLine2;

	private String addressLine3;

	private String addressLine4;

	private String city;

	private UUID territoryUuid;

	private UUID countryUuid;

	private String postalCode;

	private String email;

	private String phone;

}
