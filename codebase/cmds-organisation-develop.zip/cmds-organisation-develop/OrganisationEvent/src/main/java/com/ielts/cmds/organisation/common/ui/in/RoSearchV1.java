package com.ielts.cmds.organisation.common.ui.in;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * RoSearchV1
 */

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RoSearchV1 {

	private RoSearchV1Criteria criteria;

	private SearchPaginationV1 pagination;

	private SearchSortV1 sorting;
}
