package com.ielts.cmds.organisation.common.ui.in;

import java.util.ArrayList;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * List of minimum scores for modules (AC/GT)
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class RoDataUpdateV1MinimumScores extends ArrayList<RoDataUpdateV1MinimumScore> {

	/**
	 * Generated SerialVersion ID
	 */
	private static final long serialVersionUID = 8195645986271769391L;
}
