package com.ielts.cmds.organisation.common.ui.in;

import java.util.ArrayList;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * List of Addressses
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class RoDataCreateV1Addresses extends ArrayList<RoDataCreateV1Address> {

	/**
	 * Generated Serial Version Id
	 */
	private static final long serialVersionUID = -6531039513851474320L;

}
