package com.ielts.cmds.organisation.common.ui.in;

import java.util.ArrayList;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * List of notes of Note Type - Internal
 */

@Data
@EqualsAndHashCode(callSuper = true)
public class RoDataUpdateV1Notes extends ArrayList<RoDataUpdateV1Note> {

	/**
	 * Generated SerialVersion ID
	 */
	private static final long serialVersionUID = 2993419720376256241L;
}
