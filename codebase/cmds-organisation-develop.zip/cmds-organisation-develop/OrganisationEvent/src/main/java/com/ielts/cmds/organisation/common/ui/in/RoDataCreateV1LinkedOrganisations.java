package com.ielts.cmds.organisation.common.ui.in;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;

/**
 * List of Linked Organisations to an Organisation with link  Type PARENT_RO , RESULTS_DELIVERY, REPLACED_BY
 *
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class RoDataCreateV1LinkedOrganisations extends ArrayList<RoDataCreateV1LinkedOrganisation> {
    /**
     * Generated SerialVersion ID
     */
    private static final long serialVersionUID = -8325353521529180256L;

}
