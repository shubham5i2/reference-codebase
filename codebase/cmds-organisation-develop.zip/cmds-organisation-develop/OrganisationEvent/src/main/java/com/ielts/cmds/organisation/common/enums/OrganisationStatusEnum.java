package com.ielts.cmds.organisation.common.enums;

import java.io.IOException;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

/**
 * Status of Organisation
 */
@JsonAdapter(OrganisationStatusEnum.Adapter.class)
public enum OrganisationStatusEnum {
	ACTIVE("ACTIVE"), INACTIVE("INACTIVE");

	private String value;

	OrganisationStatusEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	@Override
	public String toString() {
		return String.valueOf(value);
	}

	public static OrganisationStatusEnum fromValue(String text) {
		for (OrganisationStatusEnum b : OrganisationStatusEnum.values()) {
			if (String.valueOf(b.value).equals(text)) {
				return b;
			}
		}
		return null;
	}

	public static class Adapter extends TypeAdapter<OrganisationStatusEnum> {

		@Override
		public void write(final JsonWriter jsonWriter, final OrganisationStatusEnum enumeration) throws IOException {
			jsonWriter.value(enumeration.getValue());
		}

		@Override
		public OrganisationStatusEnum read(final JsonReader jsonReader) throws IOException {
			Object value = jsonReader.nextString();
			return OrganisationStatusEnum.fromValue(String.valueOf(value));
		}
	}
}
