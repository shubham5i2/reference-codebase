package com.ielts.cmds.organisation.common.ui.in;

import java.util.ArrayList;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * List of Recognised Product for an Organisation
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class RoDataUpdateV1RecognisedProducts extends ArrayList<RoDataUpdateV1RecognisedProduct> {

	/**
	 * Generated SerialVersion ID
	 */
	private static final long serialVersionUID = 7185783271929537037L;

}
