package com.ielts.cmds.organisation.common.ui.in;

import java.util.ArrayList;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * SearchSortV1
 */

@Data
@EqualsAndHashCode(callSuper = true)
public class SearchSortV1 extends ArrayList<SearchSortV1Item> {

	/**
	 * Generated SerialVersion ID
	 */
	private static final long serialVersionUID = -1220337746093825599L;

}
