package com.ielts.cmds.organisation.common.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;

/**
 * Delivery Method
 * E-DELIVERY Type converter
 */
@JsonAdapter(LinkTypeEnum.Adapter.class)
public enum LinkTypeEnum {
	RESULTS_DELIVERY("RESULTS_DELIVERY"),
	PARENT_RO("PARENT_RO"),
	REPLACED_BY("REPLACED_BY");

	private String value;

	LinkTypeEnum(String value) {
		this.value = value;
	}

	@JsonValue
	public String getValue() {
		return value;
	}

	@Override
	public String toString() {
		return String.valueOf(value);
	}

	@JsonCreator
	public static LinkTypeEnum fromValue(String text) {
		for (LinkTypeEnum b : LinkTypeEnum.values()) {
			if (String.valueOf(b.value).equals(text)) {
				return b;
			}
		}
		return null;
	}

	public static class Adapter extends TypeAdapter<LinkTypeEnum> {

		@Override
		public void write(final JsonWriter jsonWriter, final LinkTypeEnum enumeration) throws IOException {
			jsonWriter.value(enumeration.getValue());
		}

		@Override
		public LinkTypeEnum read(final JsonReader jsonReader) throws IOException {
			Object value = jsonReader.nextString();
			return LinkTypeEnum.fromValue(String.valueOf(value));
		}
	}
}
