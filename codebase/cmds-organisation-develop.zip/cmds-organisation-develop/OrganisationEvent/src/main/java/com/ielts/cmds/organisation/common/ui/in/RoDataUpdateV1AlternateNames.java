package com.ielts.cmds.organisation.common.ui.in;

import java.util.ArrayList;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * List of AlternateName for an Organisation
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class RoDataUpdateV1AlternateNames extends ArrayList<RoDataUpdateV1AlternateName> {

	/**
	 * Generated SerialVersion ID
	 */
	private static final long serialVersionUID = -6345313547842857247L;
}