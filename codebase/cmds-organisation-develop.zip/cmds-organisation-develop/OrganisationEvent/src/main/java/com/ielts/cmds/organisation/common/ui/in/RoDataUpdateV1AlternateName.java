package com.ielts.cmds.organisation.common.ui.in;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * RoDataUpdateV1AlternateName
 */

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RoDataUpdateV1AlternateName {

	private UUID alternateNameUuid;

	private String name;

}
