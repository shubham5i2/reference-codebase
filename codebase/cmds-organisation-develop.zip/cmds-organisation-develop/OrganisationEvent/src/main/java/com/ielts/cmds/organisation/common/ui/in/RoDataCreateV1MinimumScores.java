package com.ielts.cmds.organisation.common.ui.in;

import java.util.ArrayList;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * List of minimum scores for modules (AC/GT)
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class RoDataCreateV1MinimumScores extends ArrayList<RoDataCreateV1MinimumScore> {

	/**
	 * Generated SerialVersion ID
	 */
	private static final long serialVersionUID = -1396406478543806355L;

}
