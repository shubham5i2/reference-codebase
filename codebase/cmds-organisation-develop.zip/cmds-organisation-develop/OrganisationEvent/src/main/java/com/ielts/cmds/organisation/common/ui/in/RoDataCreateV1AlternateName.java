package com.ielts.cmds.organisation.common.ui.in;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * RoDataCreateV1AlternateName
 */

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RoDataCreateV1AlternateName {

	private String name;

}
