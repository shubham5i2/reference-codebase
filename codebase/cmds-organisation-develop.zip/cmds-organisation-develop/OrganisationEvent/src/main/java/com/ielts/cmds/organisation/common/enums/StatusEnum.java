package com.ielts.cmds.organisation.common.enums;

import java.io.IOException;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

@JsonAdapter(StatusEnum.Adapter.class)
public enum StatusEnum {
	PENDING("PENDING"), APPROVED("APPROVED"), REJECTED("REJECTED"), VERIFIED("VERIFIED"), INACTIVE("INACTIVE"),  ACTIVE("ACTIVE");


	private String value;

	StatusEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	@Override
	public String toString() {
		return String.valueOf(value);
	}

	public static StatusEnum fromValue(String text) {
		for (StatusEnum b : StatusEnum.values()) {
			if (String.valueOf(b.value).equals(text)) {
				return b;
			}
		}
		return null;
	}

	public static class Adapter extends TypeAdapter<StatusEnum> {

		@Override
		public void write(final JsonWriter jsonWriter, final StatusEnum enumeration) throws IOException {
			jsonWriter.value(enumeration.getValue());
		}

		@Override
		public StatusEnum read(final JsonReader jsonReader) throws IOException {
			Object value = jsonReader.nextString();
			return StatusEnum.fromValue(String.valueOf(value));
		}
	}
}
