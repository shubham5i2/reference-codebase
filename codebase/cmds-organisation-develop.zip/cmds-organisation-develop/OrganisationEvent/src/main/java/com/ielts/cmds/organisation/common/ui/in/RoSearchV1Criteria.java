package com.ielts.cmds.organisation.common.ui.in;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ielts.cmds.organisation.common.enums.OrganisationStatusEnum;
import com.ielts.cmds.organisation.common.enums.VerificationStatusEnum;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * RoSearchV1Criteria
 */

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RoSearchV1Criteria {

	private String organisationName;

	private Integer organisationId;

	private String contactName;

	private OrganisationStatusEnum organisationStatus;

	private VerificationStatusEnum verificationStatus;

	private UUID organisationTypeUuid;

	private String city;

	private String postalCode;

	private String contactEmail;

	private String partnerCode;

	private UUID country;

	private Boolean fuzzyMatch;

	private UUID territory;

}
