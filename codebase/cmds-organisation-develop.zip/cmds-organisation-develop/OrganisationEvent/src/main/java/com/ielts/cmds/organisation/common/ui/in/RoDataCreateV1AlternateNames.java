package com.ielts.cmds.organisation.common.ui.in;

import java.util.ArrayList;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * List of AlternateName for an Organisation
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class RoDataCreateV1AlternateNames extends ArrayList<RoDataCreateV1AlternateName> {

	/**
	 * Generated SerialVersion ID
	 */
	private static final long serialVersionUID = -608476871096275249L;

}
