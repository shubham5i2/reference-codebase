package com.ielts.cmds.organisation.common.ui.in;

import java.util.ArrayList;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * List of Contacts linked to an Organisation of Contact Type - Primary/Results
 * Admin/Partner Contact
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class RoDataUpdateV1Contacts extends ArrayList<RoDataUpdateV1Contact> {

	/**
	 * Generated SerialVersion ID
	 */
	private static final long serialVersionUID = -3949046639455330513L;
}
