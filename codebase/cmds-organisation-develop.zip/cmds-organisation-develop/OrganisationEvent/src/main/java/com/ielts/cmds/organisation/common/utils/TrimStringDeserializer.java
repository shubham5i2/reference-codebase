package com.ielts.cmds.organisation.common.utils;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;


@Slf4j
public class TrimStringDeserializer extends JsonDeserializer<String> {

	public TrimStringDeserializer() {
        super();
        log.info("Deserializer registered");
    }

    @Override
    public String deserialize(JsonParser p, DeserializationContext ctxt) throws IOException, JsonProcessingException {
        String text = p.getText();
        return text != null ? text.trim() : text;
    }

}
