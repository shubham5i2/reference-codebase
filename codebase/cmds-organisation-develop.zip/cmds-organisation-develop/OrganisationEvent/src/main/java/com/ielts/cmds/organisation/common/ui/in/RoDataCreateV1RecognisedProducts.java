package com.ielts.cmds.organisation.common.ui.in;

import java.util.ArrayList;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * List of Recognised Product for an Organisation
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class RoDataCreateV1RecognisedProducts extends ArrayList<RoDataCreateV1RecognisedProduct> {

	/**
	 * Generated SerialVersion ID
	 */
	private static final long serialVersionUID = 8899050480757569424L;

}
