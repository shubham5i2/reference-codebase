package com.ielts.cmds.organisation.common.ui.in;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ielts.cmds.organisation.common.enums.MethodOfDeliveryEnum;
import com.ielts.cmds.organisation.common.enums.OrganisationStatusEnum;
import com.ielts.cmds.organisation.common.enums.VerificationStatusEnum;
import java.util.UUID;
import lombok.Data;
import lombok.NoArgsConstructor;

/** RoDataUpdateV1 */
@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RoDataUpdateV1 {

    private UUID recognisingOrganisationUuid;

    private String organisationName;

    private UUID organisationTypeUuid;

    private VerificationStatusEnum verificationStatus;

    private RoDataUpdateV1Addresses addresses;

    private String partnerCode;

    private String partnerContact;

    private MethodOfDeliveryEnum methodOfDelivery;

    private UUID sectorTypeUuid;

    private OrganisationStatusEnum organisationStatus;

    private String websiteUrl;

    private String crmSystem;

    private String organisationCode;

    private Integer resultAvailableForYears;

    private Boolean ieltsDisplayFlag;

    private Boolean orsDisplayFlag;
    
    private Boolean acceptsIOL;
    
    private Boolean acceptsSSR;

    private Boolean acceptsAC;

    private Boolean acceptsGT;

    private RoDataUpdateV1Notes notes;

    private RoDataUpdateV1AlternateNames alternateNames;

    private RoDataUpdateV1Contacts contacts;

    private RoDataUpdateV1MinimumScores minimumScores;

    private RoDataUpdateV1LinkedOrganisations linkedOrganisations;
}
