package com.ielts.cmds.organisation.common.enums;

import java.io.IOException;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

/**
 * StatusType (ORGANISATION_STATUS/VERIFICATION_STATUS)
 */
@JsonAdapter(StatusTypeEnum.Adapter.class)
public enum StatusTypeEnum {
	ORGANISATION_STATUS("ORGANISATION STATUS"), VERIFICATION_STATUS("VERIFICATION STATUS");

	private String value;

	StatusTypeEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	@Override
	public String toString() {
		return String.valueOf(value);
	}

	public static StatusTypeEnum fromValue(String text) {
		for (StatusTypeEnum b : StatusTypeEnum.values()) {
			if (String.valueOf(b.value).equals(text)) {
				return b;
			}
		}
		return null;
	}

	public static class Adapter extends TypeAdapter<StatusTypeEnum> {

		@Override
		public StatusTypeEnum read(final JsonReader jsonReader) throws IOException {
			Object value = jsonReader.nextString();
			return StatusTypeEnum.fromValue(String.valueOf(value));
		}

		@Override
		public void write(JsonWriter out, StatusTypeEnum value) throws IOException {
			out.value(value.getValue());
		}
	}
}