package com.ielts.cmds.organisation.common.utils;



import java.io.IOException;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Date;

import org.apache.commons.lang.time.DateUtils;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

public class OffsetDateTimeDeserializer extends JsonDeserializer<OffsetDateTime> {

    @Override
    public OffsetDateTime deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        Date parseDate = null;
        try {
            parseDate =
                    DateUtils.parseDate(
                            p.getText(),
                            new String[] {"yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"});

        } catch (Exception e) {
            throw new IOException(e.getMessage());
        }
        return parseDate.toInstant().atOffset(ZoneOffset.UTC);
    }
}

