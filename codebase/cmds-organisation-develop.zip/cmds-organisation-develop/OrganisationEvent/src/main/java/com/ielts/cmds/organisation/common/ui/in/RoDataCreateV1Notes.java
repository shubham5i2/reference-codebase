package com.ielts.cmds.organisation.common.ui.in;

import java.util.ArrayList;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * List of notes of Note Type - Internal
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class RoDataCreateV1Notes extends ArrayList<RoDataCreateV1Note> {

	/**
	 * Generated SerialVersion ID
	 */
	private static final long serialVersionUID = 4548002214014869871L;
}