package com.ielts.cmds.organisation.common.ui.in;

import java.util.ArrayList;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * List of Contacts linked to an Organisation of Contact Type - Primary/Results
 * Admin/Partner Contact
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class RoDataCreateV1Contacts extends ArrayList<RoDataCreateV1Contact> {

	/**
	 * Generated SerialVersion ID
	 */
	private static final long serialVersionUID = 6052076954207132913L;

}
