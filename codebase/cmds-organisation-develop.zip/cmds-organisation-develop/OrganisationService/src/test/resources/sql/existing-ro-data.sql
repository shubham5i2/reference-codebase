DELETE FROM ro_note;
DELETE FROM address;
DELETE FROM contact;
DELETE FROM recognised_product;
DELETE FROM recognising_organisation;

--DELETE FROM alternate_name;
--DELETE FROM minimum_score;

INSERT INTO recognising_organisation(
	recognising_organisation_uuid, organisation_type_uuid, sector_type_uuid, organisation_id, name, verification_status, partner_code, partner_contact, method_of_delivery, org_status, website_url, crm_system, organisation_code, result_available_for_years, ielts_display_flag, ors_display_flag, soft_deleted, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('88e18cae-1bdd-45a7-be1c-0a37926f9bbe', 'e496aa98-86a3-476d-8be3-21ee0aa23c93', '48270c84-4cc8-489e-8eac-2af59898175a', '234', 'University', 'PENDING', 'IDP', 'partner', 'POSTAL', 'ACTIVE', 'www.ielts.org', 'CRM Value', 'UCAS231', 2, false, false, false, 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('66762bf9-da78-4dbe-acac-02d3d2bc1e7d', '88e18cae-1bdd-45a7-be1c-0a37926f9bbe', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('0e685ded-55c2-4a24-9e8c-4bd49a0d0730', '88e18cae-1bdd-45a7-be1c-0a37926f9bbe', 'd13761e9-c134-4f80-a0a8-239a683a9c00', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());	
	
INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('2f199ce8-f850-49ef-99d9-6494ea31d6e9', '88e18cae-1bdd-45a7-be1c-0a37926f9bbe', 'c3397312-8ea3-453d-871b-68a1ef8c9184', 'Ms', 'DB', 'Primary', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('a38e03ff-33ec-4add-bf20-fef0665354be', '88e18cae-1bdd-45a7-be1c-0a37926f9bbe', '457a494b-64ca-497f-868f-cc0e5f30a97f', 'Ms', 'DB', 'Results Admin', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());	
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('3f22f78b-0fcb-43a5-908c-9691db9667f7', null, 'd13761e9-c134-4f80-a0a8-239a683a9c00', '2f199ce8-f850-49ef-99d9-6494ea31d6e9', 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());	
		
--INSERT INTO alternate_name(
--	alternate_name_uuid, recognising_organisation_uuid, name, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
--	VALUES ('714b39a3-15bf-4ac9-8d8d-27478a0a6b89', '88e18cae-1bdd-45a7-be1c-0a37926f9bbe', 'alt name', 0, 'Operations User', now(), 'Operations User', now());
	
--INSERT INTO minimum_score(
--	minscore_req_uuid, recognising_organisation_uuid, module_type_uuid, component, minimum_score_value, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
--	VALUES ('3de9fdd2-4560-45ca-8c15-eba90610422a', '88e18cae-1bdd-45a7-be1c-0a37926f9bbe', '7a28a632-8728-4f74-882e-72e9d3649763', 'L', '7.5', 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO recognised_product(
	recognised_product_uuid, recognising_organisation_uuid, product_uuid, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('91cd43eb-ae26-4ee2-9fe6-f373bfcf8ec9', '88e18cae-1bdd-45a7-be1c-0a37926f9bbe', '3e81e94b-8b6a-42b5-970c-b141f9d195a3','2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());
	
--INSERT INTO recognised_product(
--	recognised_product_uuid, recognising_organisation_uuid, product_uuid, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
--	VALUES ('94810342-2cd0-41ac-9b2e-3d217d409f0f', '88e18cae-1bdd-45a7-be1c-0a37926f9bbe', '3e81e94b-8b6a-42b5-970c-b141f9d195a3','2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO ro_note(
	note_uuid, recognising_organisation_uuid, note_type_uuid, note_content, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('6f1a876d-485e-487b-bf49-406133416c3a', '88e18cae-1bdd-45a7-be1c-0a37926f9bbe', 'f9aa5ac1-da99-40f2-82e7-a5fea9e45979', 'note1', 0, 'Operations User', now(), 'Operations User', now());
	
	
	
/*Existing ro data with ReplaceByID NotNUll*/
INSERT INTO recognising_organisation(
	recognising_organisation_uuid, organisation_type_uuid, sector_type_uuid, organisation_id, name, verification_status, partner_code, partner_contact, method_of_delivery, org_status, website_url, crm_system, organisation_code,result_available_for_years, ielts_display_flag, ors_display_flag, soft_deleted, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('705fc839-5051-4a22-a77d-cf6d734d7d24', 'e496aa98-86a3-476d-8be3-21ee0aa23c93', '48270c84-4cc8-489e-8eac-2af59898175a', '234', 'University', 'APPROVED', 'IDP', 'partner', 'POSTAL', 'ACTIVE', 'www.ielts.org', 'CRM Value', 'UCAS231', 2, false, false, false, 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('596ab10c-1d8d-4df3-8d3e-372fa231c4af', '705fc839-5051-4a22-a77d-cf6d734d7d24', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('86f904cd-b5d2-43a2-84d1-9d2b6e22845b', '705fc839-5051-4a22-a77d-cf6d734d7d24', 'd13761e9-c134-4f80-a0a8-239a683a9c00', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());	
	
INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('1815c230-40e5-4827-b530-846a222888ba', '705fc839-5051-4a22-a77d-cf6d734d7d24', 'c3397312-8ea3-453d-871b-68a1ef8c9184', 'Ms', 'DB', 'Primary', 'Support Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('7d80c4e9-08b2-4341-a7d2-391e2865c0c5', '705fc839-5051-4a22-a77d-cf6d734d7d24', '457a494b-64ca-497f-868f-cc0e5f30a97f', 'Ms', 'DB', 'Results Admin', 'Support Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());	
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('3e6e5095-a0b8-4451-904d-f5fcc5a14bdf', null, 'd13761e9-c134-4f80-a0a8-239a683a9c00', '1815c230-40e5-4827-b530-846a222888ba', 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());	

INSERT INTO recognised_product(
	recognised_product_uuid, recognising_organisation_uuid, product_uuid, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('5af3d8bf-cec7-4ac8-8070-393f4e213029', '705fc839-5051-4a22-a77d-cf6d734d7d24', '3e81e94b-8b6a-42b5-970c-b141f9d195a3','2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO recognised_product(
	recognised_product_uuid, recognising_organisation_uuid, product_uuid, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('d5a9c60c-a2fc-49fb-a2cb-f877690b6c4b', '705fc839-5051-4a22-a77d-cf6d734d7d24', '3e81e94b-8b6a-42b5-970c-b141f9d195a3','2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO ro_note(
	note_uuid, recognising_organisation_uuid, note_type_uuid, note_content, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('e308ea7d-5edf-4dd5-8309-dbd2131c1fa8', '705fc839-5051-4a22-a77d-cf6d734d7d24', 'f9aa5ac1-da99-40f2-82e7-a5fea9e45979', 'note1', 0, 'Operations User', now(), 'Operations User', now());	
	

/**/	
INSERT INTO recognising_organisation(
	recognising_organisation_uuid, organisation_type_uuid, sector_type_uuid, organisation_id, name, verification_status, partner_code, partner_contact, method_of_delivery, org_status, website_url, organisation_code, result_available_for_years, ielts_display_flag, ors_display_flag, soft_deleted, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('9a2b038b-6784-4f31-ab16-a76b30c38d1b', 'e496aa98-86a3-476d-8be3-21ee0aa23c93', '48270c84-4cc8-489e-8eac-2af59898175a', '234', 'University1', 'APPROVED', 'IDP', 'partner', 'POSTAL', 'ACTIVE', 'www.ielts.org', 'UCAS231', 2, false, false, false, 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('e62aed4b-6a53-42b2-8f73-28d5ce26d583', '9a2b038b-6784-4f31-ab16-a76b30c38d1b', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('26266a55-ef2f-47ed-855c-0f5df93fc506', '9a2b038b-6784-4f31-ab16-a76b30c38d1b', 'd13761e9-c134-4f80-a0a8-239a683a9c00', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());	
	
INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, first_name, last_name, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('c1733ba9-c5f6-4e43-b255-0bf96b31b623', '9a2b038b-6784-4f31-ab16-a76b30c38d1b', 'c3397312-8ea3-453d-871b-68a1ef8c9184', 'DB', 'Primary', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, first_name, last_name, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('fd36381b-d72b-49cc-a05d-e8f4199d4a9f', '9a2b038b-6784-4f31-ab16-a76b30c38d1b', '457a494b-64ca-497f-868f-cc0e5f30a97f', 'DB', 'Results Admin', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('810d3ecc-86ea-4d25-b016-60ed26664fa6', null, 'd13761e9-c134-4f80-a0a8-239a683a9c00', 'c1733ba9-c5f6-4e43-b255-0bf96b31b623', 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());	

/**/
INSERT INTO recognising_organisation(
	recognising_organisation_uuid, organisation_type_uuid, sector_type_uuid, organisation_id, name, verification_status, partner_code, partner_contact, method_of_delivery, org_status, website_url, organisation_code, result_available_for_years, ielts_display_flag, ors_display_flag, soft_deleted, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('102b038b-6784-4f31-ab16-a76b30c38d1b', 'e496aa98-86a3-476d-8be3-21ee0aa23c93', '48270c84-4cc8-489e-8eac-2af59898175a', '777777', 'VerifiedRO', 'VERIFIED', 'IDP', 'partner', 'POSTAL', 'ACTIVE', 'www.ielts.org', 'UCAS231', 2, false, false, false, 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('b62aed4b-6a53-42b2-8f73-28d5ce26d583', '102b038b-6784-4f31-ab16-a76b30c38d1b', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('36266a55-ef2f-47ed-855c-0f5df93fc506', '102b038b-6784-4f31-ab16-a76b30c38d1b', 'd13761e9-c134-4f80-a0a8-239a683a9c00', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, first_name, last_name, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('d1733ba9-c5f6-4e43-b255-0bf96b31b623', '102b038b-6784-4f31-ab16-a76b30c38d1b', 'c3397312-8ea3-453d-871b-68a1ef8c9184', 'DB', 'Primary', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());
