DROP ALIAS IF EXISTS SIMILARITY;
CREATE ALIAS IF NOT EXISTS SIMILARITY FOR "com.ielts.cmds.organisation.utills.SearchTestUtility.similar";