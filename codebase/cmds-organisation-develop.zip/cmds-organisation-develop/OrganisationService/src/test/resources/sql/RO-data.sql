INSERT INTO recognising_organisation(recognising_organisation_uuid, 
	organisation_type_uuid, 
	sector_type_uuid, 
	organisation_id, 
	name, 
	verification_status, 
	partner_code,
	partner_contact,
	method_of_delivery, 
	org_status, 
	website_url,
	crm_system,
	organisation_code, 
	soft_deleted, 
	concurrency_version, 
	created_by, 
	created_datetime, 
	updated_by, 
	updated_datetime)
	VALUES ('7b684c61-6d72-4dbd-95ee-85879bc1ec16', 
	'e496aa98-86a3-476d-8be3-21ee0aa23c93', 
	'6a6f32d1-b904-4592-b214-beec9cde3403', 
	321, 
	'London  Metropolitain University 1', 
	'APPROVED', 
	'BC',
	'Partner',
	'POSTAL', 
	'ACTIVE', 
	NULL,
	'CRM Value',
	NULL,
	FALSE,
	1,	
	'ro_migration', 
	'2018-03-11 02:00:00', 
	NULL, 
	NULL);

--Contact DML Script
INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('44c966ee-62ca-4194-84a2-f8231937a0e6', '7b684c61-6d72-4dbd-95ee-85879bc1ec16', '80f4bba7-70b2-4e16-bef4-2ff06c58f620', 'Ms', 'Test', 'Contact', 'Chief Support Manager' , '2018-03-11 02:00:00', '2018-03-11 02:00:00', 1,	
	'ro_migration', 
	'2018-03-11 02:00:00', 
	NULL, 
	NULL);

--Address DML Script
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('1da9f0ed-df81-4ff3-b501-d23f0d13363a', '7b684c61-6d72-4dbd-95ee-85879bc1ec16', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', '44c966ee-62ca-4194-84a2-f8231937a0e6', '029fd27d-b39a-48b4-87e7-131a063bea2d', '029fd27d-b39a-48b4-87e7-131a063bea2d', '166 - 220 Holloway Road', 'London', NULL, NULL, 'Cambridge', 'DBP 001', 'xyz@example.com', NULL, 1,	
	'ro_migration', 
	'2018-03-11 02:00:00', 
	NULL, 
	NULL);
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('82c29fe8-882b-41cc-a484-a7df3535254d', '7b684c61-6d72-4dbd-95ee-85879bc1ec16', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', NULL, '029fd27d-b39a-48b4-87e7-131a063bea2d', '029fd27d-b39a-48b4-87e7-131a063bea2d', '166 - 220 Holloway Road', 'London', NULL, NULL, 'Cambridge', 'DBP 001', 'xyz@example.com', NULL, 1,	
	'ro_migration', 
	'2018-03-11 02:00:00', 
	NULL, 
	NULL);	
	
INSERT INTO recognised_product(
	recognised_product_uuid, recognising_organisation_uuid, product_uuid, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('1eac273f-bcda-4f40-9591-c23ad24bb661', '7b684c61-6d72-4dbd-95ee-85879bc1ec16', '3e81e94b-8b6a-42b5-970c-b141f9d195a3','2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO recognised_product(
	recognised_product_uuid, recognising_organisation_uuid, product_uuid, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('bc7d4578-c9a8-4346-91d8-1c7658c54f4a', '7b684c61-6d72-4dbd-95ee-85879bc1ec16', '6d28d524-472d-4d53-8fd9-dc7c4bb5325d','2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());
