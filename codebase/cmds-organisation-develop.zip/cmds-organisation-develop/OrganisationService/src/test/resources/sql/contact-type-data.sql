--DML scripts contact type
DELETE FROM contact_type;
INSERT INTO contact_type( contact_type_uuid, contact_type, description, effective_from_date, effective_to_date, created_by, created_datetime, concurrency_version)
VALUES ('c3397312-8ea3-453d-871b-68a1ef8c9184',
		'Primary',
		NULL,
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		now(),
		0);


INSERT INTO contact_type( contact_type_uuid, contact_type, description, effective_from_date, effective_to_date, created_by, created_datetime, concurrency_version)
VALUES ('457a494b-64ca-497f-868f-cc0e5f30a97f',
		'Results Admin',
		NULL,
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		now(),
		0);


INSERT INTO contact_type( contact_type_uuid, contact_type, description, effective_from_date, effective_to_date, created_by, created_datetime, concurrency_version)
VALUES ('80f4bba7-70b2-4e16-bef4-2ff06c58f620',
		'Partner Contact',
		NULL,
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		now(),
		0);


INSERT INTO contact_type( contact_type_uuid, contact_type, description, effective_from_date, effective_to_date, created_by, created_datetime, concurrency_version)
VALUES ('d07a3d76-0006-4802-bd47-ee8ece5432ca',
		'Test Centre Manager',
		NULL,
		'2020-07-01',
		'2099-12-31',
		'Operations User',
		now(),
		0);

commit;		