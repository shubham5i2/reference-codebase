INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('24d63f7d-1316-4bd8-9285-4e8da072657b', '5c2e3965-8b90-488f-b5e9-4da8854785cb', 'aecf88e3-a88e-467a-b966-ab4ac939de55', 'PARENT_RO', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', '1234', 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('a7e10ac1-3b34-4e80-9909-09a68b25e0d9', '5c2e3965-8b90-488f-b5e9-4da8854785cb', '08098e22-a98e-495a-9024-e94589bbe9d1', 'RESULTS_DELIVERY', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', '1234', 0, 'Operations User', now(), 'Operations User', now());	
	
INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('33b41e2a-5eea-4f34-a04e-8dd63907a99a', '08098e22-a98e-495a-9024-e94589bbe9d1', '5c2e3965-8b90-488f-b5e9-4da8854785cb', 'PARENT_RO', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', '1234', 0, 'Operations User', now(), 'Operations User', now());	
	
INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('3c790c8a-0ceb-44d3-b270-e323c3721fd8', '8ad1b27b-2abd-48f7-af77-04b0efbde786', '08098e22-a98e-495a-9024-e94589bbe9d1', 'PARENT_RO', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', '1234', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('036fbb44-60fe-408c-b3c0-55fe8baded59', '89d67a10-ef43-4edd-9fd3-89036f8b0065', '0b30c635-80df-49a3-beed-f1752f8bde3c', 'RESULTS_DELIVERY', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', '1234', 0, 'Operations User', now(), 'Operations User', now());
	
	INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('904142e2-3b11-4bf1-8d38-bca94f07c627', 'a727fdeb-24fe-4f64-8347-5b7d19b8f9b6', '49ad3e10-6201-4ad1-b15f-43d3d62beae7', 'PARENT_RO', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', '1234', 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('9f258c77-c61e-4719-ad1c-b2b9b3e2682d', 'a727fdeb-24fe-4f64-8347-5b7d19b8f9b6', '6961ce44-b254-499f-9614-bc2104f6e40d', 'RESULTS_DELIVERY', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', '1234', 0, 'Operations User', now(), 'Operations User', now());	
	
INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('ffc5a0c9-56d0-4fea-afb3-cacdb445e517', '6961ce44-b254-499f-9614-bc2104f6e40d', 'a727fdeb-24fe-4f64-8347-5b7d19b8f9b6', 'PARENT_RO', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', '1234', 0, 'Operations User', now(), 'Operations User', now());	
	
INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('ad902a50-eb43-4950-87fb-91b6a20577e1', '89d67a10-ef43-4edd-9fd3-89036f8b0065', '6961ce44-b254-499f-9614-bc2104f6e40d', 'PARENT_RO', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', '1234', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('e38b343e-84fe-43fa-82b7-b78f618f35d9', '89d67a10-ef43-4edd-9fd3-89036f8b0065', '0b30c635-80df-49a3-beed-f1752f8bde3c', 'RESULTS_DELIVERY', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', '1234', 0, 'Operations User', now(), 'Operations User', now());