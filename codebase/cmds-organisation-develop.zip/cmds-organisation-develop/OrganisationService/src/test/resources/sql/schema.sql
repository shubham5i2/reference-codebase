CREATE SCHEMA IF NOT EXISTS RO_OWNER;

/*** Creating table to store Organisation_type**/	
CREATE TABLE IF NOT EXISTS organisation_type (
    organisation_type_uuid UUID NOT NULL,
    organisation_type VARCHAR(100) NOT NULL,
    description VARCHAR(100) NULL,
    effective_from_date DATE NOT NULL,
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
    created_by VARCHAR(36) NOT NULL,
    created_datetime timestamp NOT NULL DEFAULT current_timestamp,
    updated_by VARCHAR(36),
    updated_datetime timestamp,
    concurrency_version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT pk_organisation_type PRIMARY KEY (organisation_type_uuid)
);

/*** Creating table to store Partner**/	
CREATE TABLE IF NOT EXISTS partner (
    partner_uuid UUID NOT NULL,
    partner_code VARCHAR(20) NOT NULL UNIQUE,
    partner_name VARCHAR(50) NOT NULL,
    effective_from_date DATE NOT NULL,
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
    created_by VARCHAR(36) NOT NULL ,
    created_datetime timestamp NOT NULL DEFAULT current_timestamp,
    updated_by VARCHAR(36),
    updated_datetime timestamp,
    concurrency_version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT pk_partner PRIMARY KEY (partner_uuid)
);

/*** Creating table to store Address Type**/
CREATE TABLE IF NOT EXISTS address_type (
    address_type_uuid UUID NOT NULL,
    address_type_name VARCHAR(50) NOT NULL,
    description VARCHAR(100) NULL,
    effective_from_date DATE NOT NULL,
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
    created_by VARCHAR(36) NOT NULL,
    created_datetime timestamp NOT NULL DEFAULT current_timestamp,
    updated_by VARCHAR(36),
    updated_datetime timestamp,
    concurrency_version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT pk_address_type PRIMARY KEY (address_type_uuid)
);

/*** Creating table to store Sector_type**/	
CREATE TABLE IF NOT EXISTS sector_type (
    sector_type_uuid UUID NOT NULL,
    sector_type VARCHAR(100) NOT NULL,
    description VARCHAR(100) NULL,
    effective_from_date DATE NOT NULL,
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
    created_by VARCHAR(36) NOT NULL,
    created_datetime timestamp NOT NULL DEFAULT current_timestamp,
    updated_by VARCHAR(36),
    updated_datetime timestamp,
    concurrency_version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT pk_sector_type PRIMARY KEY (sector_type_uuid)
);

CREATE TABLE IF NOT EXISTS module_type (
    module_type_uuid UUID NOT NULL,
    module_type VARCHAR(20) NOT NULL,
    description VARCHAR(100) NULL,
    effective_from_date DATE NOT NULL,
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
    created_by VARCHAR(36) NOT NULL ,
    created_datetime timestamp NOT NULL DEFAULT current_date,
    updated_by VARCHAR(36),
    updated_datetime timestamp,
    concurrency_version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT pk_module_type PRIMARY KEY (module_type_uuid)
    );


/** Type For Component Type **/
drop type if exists component_type cascade;
create type component_type AS enum ('R','L','W','S');

drop type if exists product_status_type cascade;
create type product_status_type AS enum ('DRAFT', 'PUBLISHED');

drop type if exists format_type cascade;
create type format_type AS enum ('CD', 'PB');

-- Product Table Creation in Staff Management
CREATE TABLE IF NOT EXISTS product (
	product_uuid UUID ,
	parent_product_uuid UUID NULL,
	module_type_uuid UUID NULL,
	legacy_product_id varchar(24) NULL,
	product_name VARCHAR(100) NOT NULL,
	product_description varchar(1000) NULL,
	product_characteristics varchar(500) NULL,
	bookable BOOLEAN NOT NULL,
	component component_type NULL,
	duration INTEGER NULL,
	format format_type NULL,
	approval_required BOOLEAN NOT NULL,
	available_from_date DATE NOT NULL,
	available_to_date DATE NOT NULL,
	product_status product_status_type NOT NULL,
	created_by varchar(36) NOT NULL,
	created_datetime timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_by varchar(36) NULL,
	updated_datetime timestamp NULL,
	concurrency_version INTEGER NOT NULL,
	CONSTRAINT pk_product PRIMARY KEY (product_uuid),
	CONSTRAINT fk_01_product_product FOREIGN KEY (parent_product_uuid) REFERENCES ro_owner.product (product_uuid)
);


/*** Creating table to store Contact_type**/
CREATE TABLE IF NOT EXISTS contact_type (
    contact_type_uuid UUID NOT NULL,
    contact_type VARCHAR(50) NOT NULL,
    description VARCHAR(100) NULL,
    effective_from_date DATE NOT NULL,
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
    created_by VARCHAR(36) NOT NULL,
    created_datetime timestamp NOT NULL DEFAULT current_timestamp,
    updated_by VARCHAR(36),
    updated_datetime timestamp,
    concurrency_version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT pk_contact_type PRIMARY KEY (contact_type_uuid)
);

/*** Creating table to store Note Type**/	
CREATE TABLE IF NOT EXISTS note_type (
    note_type_uuid UUID NOT NULL,
    note_type VARCHAR(100) NOT NULL,
    description VARCHAR(100) NULL,
    effective_from_date DATE NOT NULL,
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
    created_by VARCHAR(36) NOT NULL,
    created_datetime timestamp NOT NULL DEFAULT current_timestamp,
    updated_by VARCHAR(36),
    updated_datetime timestamp,
    concurrency_version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT pk_note_type PRIMARY KEY (note_type_uuid)
);

/*** Creating table to store Country**/	
CREATE TABLE IF NOT EXISTS country (
    country_uuid UUID NOT NULL, 
    country_iso3_code VARCHAR(3) NOT NULL UNIQUE,
    country_name VARCHAR(100) NOT NULL,  
    legacy_reference VARCHAR(3),
    effective_from_date DATE NOT NULL DEFAULT '2020-07-01',
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
    created_by VARCHAR(36) NOT NULL,
    created_datetime timestamp NOT NULL DEFAULT current_timestamp,
    updated_by VARCHAR(36),
    updated_datetime timestamp,
    concurrency_version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT pk_country PRIMARY KEY (country_uuid)
);

/*** Creating table to store Territory**/
CREATE TABLE IF NOT EXISTS territory (
    territory_uuid UUID NOT NULL,
    country_uuid UUID NOT NULL,
    territory_iso_code VARCHAR(6) NOT NULL UNIQUE,
    territory_name VARCHAR(100) NOT NULL,
    legacy_reference VARCHAR(3),
    effective_from_date DATE NOT NULL,
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
    created_by VARCHAR(36) NOT NULL,
    created_datetime timestamp NOT NULL DEFAULT current_timestamp,
    updated_by VARCHAR(36),
    updated_datetime timestamp,
    concurrency_version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT pk_territory PRIMARY KEY (territory_uuid),
    CONSTRAINT fk_01_territory_country FOREIGN KEY (country_uuid) REFERENCES country(country_uuid)
);


drop type if exists user_active_type cascade;
create type  user_active_type AS enum ('ACTIVE','INACTIVE');

/** Type For Verification Status **/
drop type if exists verification_status cascade;
create type verification_status AS enum ('PENDING','APPROVED','VERIFIED','REJECTED');

/** Type For Method Of Delivery Type **/
drop type if exists method_Of_delivery cascade;
create type method_Of_delivery AS enum ('POSTAL','E-DELIVERY');

/** Type For Organisation Status **/
drop type if exists org_status cascade;
create type org_status AS enum ('ACTIVE','INACTIVE');

/** Create table for recognising_organisation **/
CREATE TABLE IF NOT EXISTS recognising_organisation( 
	recognising_organisation_uuid UUID NOT NULL,
	organisation_type_uuid UUID NOT NULL,
    sector_type_uuid UUID NOT NULL,
    organisation_id integer AUTO_INCREMENT NOT NULL,
    name VARCHAR(255) NOT NULL,
    verification_status verification_status NOT NULL,
    partner_code VARCHAR(25) NOT NULL,
    partner_contact VARCHAR(50),
    method_of_delivery method_Of_delivery NOT NULL,
    org_status org_status NOT NULL,
    website_url VARCHAR(250),
    crm_system VARCHAR(50),
    organisation_code VARCHAR(20),
    result_available_for_years INTEGER NOT NULL DEFAULT 2,
    ielts_display_flag Boolean DEFAULT FALSE,
    ors_display_flag Boolean DEFAULT FALSE,
    soft_deleted Boolean DEFAULT FALSE,
    concurrency_version INTEGER NOT NULL,
    created_by VARCHAR(36) NOT NULL,
	created_datetime timestamp NOT NULL,
	updated_by VARCHAR(36) NULL,
	updated_datetime timestamp NULL,
    CONSTRAINT pk_recognising_organisation PRIMARY KEY (recognising_organisation_uuid)
	);

CREATE SEQUENCE IF NOT EXISTS RO_OWNER.organisationId_generator
INCREMENT BY  1  
MAXVALUE 999999  
START WITH 171183;

drop type if exists linked_recognising_organisation_type_enum cascade;
CREATE TYPE linked_recognising_organisation_type_enum AS enum ('PARENT_RO', 'RESULTS_DELIVERY', 'REPLACED_BY');

CREATE TABLE IF NOT EXISTS linked_recognising_organisation(
linked_recognising_organisation_uuid UUID NOT NULL,
source_recognising_organisation_uuid UUID NOT NULL,
target_recognising_organisation_uuid UUID NOT NULL,
linked_recognising_organisation_type linked_recognising_organisation_type_enum NOT NULL,
effective_from_datetime timestamp NOT NULL,
effective_to_datetime timestamp NOT NULL,
organisation_hierarchy_label VARCHAR(50),
concurency_version INTEGER NOT NULL,
created_by VARCHAR(36) NOT NULL,
created_datetime timestamp NOT NULL,
updated_by VARCHAR(36),
updated_datetime timestamp,
CONSTRAINT pk_linked_recognising_org PRIMARY KEY (linked_recognising_organisation_uuid),
CONSTRAINT fk_01_linked_recognising_org_recognising_org FOREIGN KEY (source_recognising_organisation_uuid ) REFERENCES recognising_organisation (recognising_organisation_uuid) ON UPDATE NO ACTION ON DELETE NO ACTION,
CONSTRAINT fk_02_linked_recognising_org_recognising_org FOREIGN KEY (target_recognising_organisation ) REFERENCES recognising_organisation (recognising_organisation_uuid) ON UPDATE NO ACTION ON DELETE NO ACTION
);

	/*** Creating table for contact**/	
CREATE TABLE IF NOT EXISTS contact(
    contact_uuid UUID NOT NULL,
    recognising_organisation_uuid  UUID NOT NULL,
    contact_type_uuid UUID NOT NULL,
    title VARCHAR(20),
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    job_title VARCHAR(100),
    effective_from_datetime timestamp NOT NULL,
    effective_to_datetime timestamp NOT NULL,
    concurrency_version INTEGER NOT NULL,
    created_by VARCHAR(36) NOT NULL,
	created_datetime timestamp NOT NULL,
	updated_by VARCHAR(36),
	updated_datetime timestamp,
    CONSTRAINT pk_contact PRIMARY KEY (contact_uuid),
    CONSTRAINT fk_01_contact_recognising_org FOREIGN KEY (recognising_organisation_uuid ) REFERENCES recognising_organisation (recognising_organisation_uuid) ON UPDATE NO ACTION ON DELETE NO ACTION
	);

	/*** Creating table to store Address**/	
CREATE TABLE IF NOT EXISTS address( 
    address_uuid UUID NOT NULL,
    recognising_organisation_uuid UUID,
    address_type_uuid UUID NOT NULL,
    contact_uuid UUID,
    territory_uuid UUID,
    country_uuid UUID,
    addressline1 VARCHAR(100),
    addressline2 VARCHAR(100),
    addressline3 VARCHAR(100),
    addressline4 VARCHAR(100),
    city VARCHAR(100),
    postalcode VARCHAR(20),
    email VARCHAR(320) DEFAULT NULL,
    phone VARCHAR(20),
    concurrency_version INTEGER NOT NULL,
    created_by VARCHAR(36) NOT NULL,
	created_datetime timestamp NOT NULL,
	updated_by VARCHAR(36),
	updated_datetime timestamp,
    CONSTRAINT pk_address PRIMARY KEY (address_uuid),
    CONSTRAINT fk_01_address_recognising_org FOREIGN KEY (recognising_organisation_uuid ) REFERENCES recognising_organisation (recognising_organisation_uuid) ON UPDATE NO ACTION ON DELETE NO ACTION,
    CONSTRAINT fk_02_address_contact FOREIGN KEY (contact_uuid) REFERENCES contact (contact_uuid) ON UPDATE NO ACTION ON DELETE NO ACTION	
	);
       

/*** Creating table for ro_note**/	
CREATE TABLE IF NOT EXISTS ro_note( 
    note_uuid UUID NOT NULL,
    recognising_organisation_uuid  UUID NOT NULL,
    note_type_uuid UUID NOT NULL,
    note_content VARCHAR(2000),
    concurrency_version INTEGER NOT NULL,
    created_by VARCHAR(36) NOT NULL,
	created_datetime timestamp NOT NULL,
	updated_by VARCHAR(36),
	updated_datetime timestamp,
    CONSTRAINT pk_notes PRIMARY KEY (note_uuid),
    CONSTRAINT fk_01_ro_note_recognising_org FOREIGN KEY (recognising_organisation_uuid ) REFERENCES recognising_organisation (recognising_organisation_uuid) ON UPDATE NO ACTION ON DELETE NO ACTION
	);

/*** Creating table for alternate_name**/	
CREATE TABLE IF NOT EXISTS alternate_name(
    alternate_name_uuid UUID NOT NULL,
    recognising_organisation_uuid UUID NOT NULL,
    name VARCHAR(255) NOT NULL,
    concurrency_version INTEGER NOT NULL,
    created_by VARCHAR(36) NOT NULL,
	created_datetime timestamp NOT NULL,
	updated_by VARCHAR(36),
	updated_datetime timestamp,
    CONSTRAINT pk_alternate_name PRIMARY KEY (alternate_name_uuid),
    CONSTRAINT fk_01_alternate_name_recognising_org FOREIGN KEY (recognising_organisation_uuid ) REFERENCES recognising_organisation (recognising_organisation_uuid) ON UPDATE NO ACTION ON DELETE NO ACTION
	);

/*** Creating table for minimum_score**/	
CREATE TABLE IF NOT EXISTS minimum_score(
    minscore_req_uuid UUID NOT NULL,
    recognising_organisation_uuid  UUID NOT NULL,
    module_type_uuid UUID NOT NULL,
    component component_type NOT NULL,
    minimum_score_value real NOT NULL,
    concurrency_version INTEGER NOT NULL,
    created_by VARCHAR(36) NOT NULL,
	created_datetime timestamp NOT NULL,
	updated_by VARCHAR(36),
	updated_datetime timestamp,
    CONSTRAINT pk_minimum_score PRIMARY KEY (minscore_req_uuid),
    CONSTRAINT fk_01_min_score_recognising_org FOREIGN KEY (recognising_organisation_uuid ) REFERENCES recognising_organisation (recognising_organisation_uuid) ON UPDATE NO ACTION ON DELETE NO ACTION
	);
	
/*** Creating table for recognised_product**/	
CREATE TABLE IF NOT EXISTS recognised_product( 
    recognised_product_uuid UUID NOT NULL,
    recognising_organisation_uuid  UUID NOT NULL,
    product_uuid UUID NOT NULL,
    effective_from_datetime timestamp NOT NULL,
    effective_to_datetime timestamp DEFAULT '2099-12-31 00:00:00+00',
    concurrency_version INTEGER NOT NULL,
    created_by VARCHAR(36) NOT NULL,
	created_datetime timestamp NOT NULL,
	updated_by VARCHAR(36),
	updated_datetime timestamp,
    CONSTRAINT pk_recognised_product PRIMARY KEY (recognised_product_uuid),
    CONSTRAINT fk_01_recognised_product_recognising_org FOREIGN KEY (recognising_organisation_uuid ) REFERENCES recognising_organisation (recognising_organisation_uuid) ON UPDATE NO ACTION ON DELETE NO ACTION
	);

/** Type For Status **/
drop type if exists status_enum cascade;
create type status_enum AS enum ('PENDING','APPROVED','VERIFIED','REJECTED','INACTIVE','ACTIVE');

/** Type For Status Type**/
drop type if exists status_type_enum cascade;
create type status_type_enum AS enum ('ORGANISATION STATUS','VERIFICATION STATUS');

/*** Creating table for status_history**/	
CREATE TABLE IF NOT EXISTS status_history( 
    status_history_uuid UUID NOT NULL,
    recognising_organisation_uuid  UUID NOT NULL,
    status status_enum NOT NULL,
	status_type status_type_enum NOT NULL,
    status_datetime timestamp NOT NULL,
    concurrency_version INTEGER NOT NULL,
    created_by VARCHAR(36) NOT NULL,
	created_datetime timestamp NOT NULL,
	updated_by VARCHAR(36),
	updated_datetime timestamp,
    CONSTRAINT pk_status_history PRIMARY KEY (status_history_uuid ),
    CONSTRAINT fk_01_status_history_recognising_org FOREIGN KEY (recognising_organisation_uuid ) REFERENCES recognising_organisation (recognising_organisation_uuid) ON UPDATE NO ACTION ON DELETE NO ACTION
	);

