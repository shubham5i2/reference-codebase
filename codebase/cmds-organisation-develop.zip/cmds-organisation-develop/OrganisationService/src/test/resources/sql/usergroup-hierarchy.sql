
drop type if exists JSONB cascade;

CREATE TYPE JSONB AS json;

DROP TABLE user_group_hierarchy;

-- Dumping structure for table user_group_hierarchy
CREATE TABLE IF NOT EXISTS user_group_hierarchy (
	user_group_uuid UUID NOT NULL,
	user_group_data JSONB NOT NULL,
	concurrency_version INTEGER NULL DEFAULT NULL,
	created_by VARCHAR(36) NOT NULL,
	created_time TIMESTAMP NOT NULL,
	updated_by VARCHAR(36) NULL DEFAULT NULL,
	updated_time TIMESTAMP NULL DEFAULT NULL,
	PRIMARY KEY (user_group_uuid)
);

-- Dumping data for table staffmgmnt.user_group_hierarchy: 0 rows

INSERT INTO user_group_hierarchy (user_group_uuid, user_group_data, concurrency_version, created_by, created_time, updated_by, updated_time) VALUES
	('5bd30438-b8c1-406b-a807-64285f23aa5c', JSON'{"products": [], "systemRoles": [{"systemId": "cmds",  "permissions": [], "systemRoleName": "Test Admin Support Manager", "systemRoleUuid": "b452f7fe-aed5-43ff-ad16-ead549e6054f", "externalSystemRoleId": null}], "userGroupName": "IELTS Global Operations Manager", "userGroupUuid": "5bd30438-b8c1-406b-a807-64285f23aa5c", "homeTestCentreRequired": false}', 0, 'OPS-USER', '2021-02-18 14:01:10.424639+00', NULL, NULL),
	('8f40d9d9-4fd4-47a6-9722-d9b9fc5e81ad', JSON'{"products": [{"productName": "IELTS at Home AC", "productUuid": "3e81e94b-8b6a-42b5-970c-b141f9d195a3"}, {"productName": "IELTS at Home GT", "productUuid": "d96eece2-1d7c-495a-a754-6b523b710a82"}], "systemRoles": [{"systemId": "cmds", "permissions": [{"permissionId": "USER_CREATE", "permissionName": "Create User", "permissionUuid": "d6f16125-a981-47a9-94ad-e1196b1d323e"}, {"permissionId": "USER_UPDATE", "permissionName": "Update User", "permissionUuid": "bce58db3-9f26-4696-8d6e-d6ffcc527dbf"}, {"permissionId": "USER_VIEW", "permissionName": "View User", "permissionUuid": "8a8da658-9a68-40d5-ab93-9f80753b94fd"}, {"permissionId": "USER_DELETE", "permissionName": "Delete User", "permissionUuid": "f4d97fe2-0911-4798-84cc-8c7fc8818dca"}, {"permissionId": "RO_ORG_CREATE", "permissionName": "Create Recognising Organisation", "permissionUuid": "5c5c326e-8479-49e9-8ef9-7e2c83e0c77a"}, {"permissionId": "RO_ORG_UPDATE", "permissionName": "Update Recognising Organisation", "permissionUuid": "1d19ce2b-f124-497e-9b7a-13858c58a152"}, {"permissionId": "RO_ORG_VIEW", "permissionName": "View Recognising Organisation", "permissionUuid": "1294c69e-fb95-4bec-9fda-2ac7ce3e0f96"}, {"permissionId": "RO_ORG_DELETE", "permissionName": "Delete Recognising Organisation", "permissionUuid": "e836037d-5d2b-424f-ac45-e97af512b3e3"}, {"permissionId": "VO_ORG_CREATE", "permissionName": "Create Recognising Organisation", "permissionUuid": "88308bf3-a479-42ba-940a-96c49f21aed2"}, {"permissionId": "VO_ORG_UPDATE", "permissionName": "Update Recognising Organisation", "permissionUuid": "6187b51d-221d-457c-ae85-4bc3f6c6003c"}, {"permissionId": "VO_ORG_VIEW", "permissionName": "View Recognising Organisation", "permissionUuid": "2412222a-de6e-4881-a0fc-b21d8c9ac418"}, {"permissionId": "VO_ORG_DELETE", "permissionName": "Delete Recognising Organisation", "permissionUuid": "9467f709-13ab-48e3-8ffe-dcb8e7e194aa"}], "systemRoleName": "IELTS Global Operations Manager", "systemRoleUuid": "b452f7fe-aed5-43ff-ad16-ead549e6054f", "externalSystemRoleId": null}], "userGroupName": "IELTS Global Operations Manager", "userGroupUuid": "8f40d9d9-4fd4-47a6-9722-d9b9fc5e81ad", "homeTestCentreRequired": false}', 0, 'OPS-USER', '2021-05-10 10:33:08.495586+00', NULL, NULL);
commit;
