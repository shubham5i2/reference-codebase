--DELETE FROM address;
--DELETE FROM contact;
--DELETE FROM recognising_organisation;

INSERT INTO recognising_organisation(
	recognising_organisation_uuid, organisation_type_uuid, sector_type_uuid, organisation_id, name, verification_status, partner_code, partner_contact, method_of_delivery, org_status, website_url, crm_system, organisation_code, soft_deleted, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('aecf88e3-a88e-467a-b966-ab4ac939de55', 'e496aa98-86a3-476d-8be3-21ee0aa23c93', '48270c84-4cc8-489e-8eac-2af59898175a', '1234', 'Cambridge University', 'APPROVED', 'IDP', 'partner', 'POSTAL', 'ACTIVE', 'www.ielts.org', 'CRM Value', 'UCAS231', false, 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('98bc8bae-821b-4c1b-97d7-34c8832077d9', 'aecf88e3-a88e-467a-b966-ab4ac939de55', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('1d8e516b-de63-47fb-9740-2794f9d9e1ee', 'aecf88e3-a88e-467a-b966-ab4ac939de55', 'd13761e9-c134-4f80-a0a8-239a683a9c00', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());	
	
INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('c2d72bf1-9afd-4178-afab-0f45b99f30af', 'aecf88e3-a88e-467a-b966-ab4ac939de55', 'c3397312-8ea3-453d-871b-68a1ef8c9184', 'Ms', 'DB', 'Primary', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('ea27ca17-cf7f-46b8-827b-669d57ed15f2', 'aecf88e3-a88e-467a-b966-ab4ac939de55', '457a494b-64ca-497f-868f-cc0e5f30a97f', 'Ms', 'DB', 'Results Admin', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());	
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('3e1eb934-f5ca-44d8-968f-6814b83217fa', null, 'd13761e9-c134-4f80-a0a8-239a683a9c00', 'ea27ca17-cf7f-46b8-827b-669d57ed15f2', 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());	
	
---------
	
INSERT INTO recognising_organisation(
	recognising_organisation_uuid, organisation_type_uuid, sector_type_uuid, organisation_id, name, verification_status, partner_code, partner_contact, method_of_delivery, org_status, website_url, crm_system, organisation_code, soft_deleted, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('5c2e3965-8b90-488f-b5e9-4da8854785cb', 'e496aa98-86a3-476d-8be3-21ee0aa23c93', '48270c84-4cc8-489e-8eac-2af59898175a', '5678', 'Cambridge University-Science', 'APPROVED', 'IDP', 'partner', 'POSTAL', 'ACTIVE', 'www.ielts.org', 'CRM Value', 'UCAS231', false, 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('064f51bf-b63b-42d2-99ce-ac135c314ef8', '5c2e3965-8b90-488f-b5e9-4da8854785cb', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('d2c79c04-96b3-436f-9ad0-dd4fb3c091a8', '5c2e3965-8b90-488f-b5e9-4da8854785cb', 'd13761e9-c134-4f80-a0a8-239a683a9c00', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());	
	
INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('306d4594-29b3-461a-8a7e-b8ded35b0a2c', '5c2e3965-8b90-488f-b5e9-4da8854785cb', 'c3397312-8ea3-453d-871b-68a1ef8c9184', 'Ms', 'DB', 'Primary', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('e586ab78-8172-4ac0-8864-af91328e1358', '5c2e3965-8b90-488f-b5e9-4da8854785cb', '457a494b-64ca-497f-868f-cc0e5f30a97f', 'Ms', 'DB', 'Results Admin', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());	
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('27ea2ac2-572b-4dd3-9fa6-0dadbcccc5fe', null, 'd13761e9-c134-4f80-a0a8-239a683a9c00', 'e586ab78-8172-4ac0-8864-af91328e1358', 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2022@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());	
			
	
------------
INSERT INTO recognising_organisation(
	recognising_organisation_uuid, organisation_type_uuid, sector_type_uuid, organisation_id, name, verification_status, partner_code, partner_contact, method_of_delivery, org_status, website_url, crm_system, organisation_code, soft_deleted, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('08098e22-a98e-495a-9024-e94589bbe9d1', 'e496aa98-86a3-476d-8be3-21ee0aa23c93', '48270c84-4cc8-489e-8eac-2af59898175a', '91011', 'Cambridge University-SC-Physics', 'APPROVED', 'IDP', 'partner', 'POSTAL', 'ACTIVE', 'www.ielts.org', 'CRM Value', 'UCAS231', false, 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('cd3f6c9e-d4c2-4056-9535-30fda2044ff2', '08098e22-a98e-495a-9024-e94589bbe9d1', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('c4f5a105-d9e5-44c8-b0f7-66cf3fbd9f1c', '08098e22-a98e-495a-9024-e94589bbe9d1', 'd13761e9-c134-4f80-a0a8-239a683a9c00', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());	
	
INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('4796b412-6399-48b9-81f7-c1854a348386', '08098e22-a98e-495a-9024-e94589bbe9d1', 'c3397312-8ea3-453d-871b-68a1ef8c9184', 'Ms', 'DB', 'Primary', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('c016eb99-53a2-41e1-9839-e970eb820f21', '08098e22-a98e-495a-9024-e94589bbe9d1', '457a494b-64ca-497f-868f-cc0e5f30a97f', 'Ms', 'DB', 'Results Admin', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());	
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('80daa5a1-aeca-432a-a419-6ff6b0c14ecb', null, 'd13761e9-c134-4f80-a0a8-239a683a9c00', 'c016eb99-53a2-41e1-9839-e970eb820f21', 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2022@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());	
				
	
--------

INSERT INTO recognising_organisation(
	recognising_organisation_uuid, organisation_type_uuid, sector_type_uuid, organisation_id, name, verification_status, partner_code, partner_contact, method_of_delivery, org_status, website_url, crm_system, organisation_code, soft_deleted, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('8ad1b27b-2abd-48f7-af77-04b0efbde786', 'e496aa98-86a3-476d-8be3-21ee0aa23c93', '48270c84-4cc8-489e-8eac-2af59898175a', '1213', 'Cambridge University-SC-Biology', 'APPROVED', 'IDP', 'partner', 'POSTAL', 'ACTIVE', 'www.ielts.org', 'CRM Value', 'UCAS231', false, 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('2f464b4f-5189-4bbe-bd11-11532e799227', '8ad1b27b-2abd-48f7-af77-04b0efbde786', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('af89eeec-c5d5-40f6-8fd0-270d684cc50a', '8ad1b27b-2abd-48f7-af77-04b0efbde786', 'd13761e9-c134-4f80-a0a8-239a683a9c00', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());	
	
INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('95417a67-c65e-4a10-aca7-45feb6c97d23', '8ad1b27b-2abd-48f7-af77-04b0efbde786', 'c3397312-8ea3-453d-871b-68a1ef8c9184', 'Ms', 'DB', 'Primary', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('5b655f56-cf35-4576-8824-b8726dcb5851', '8ad1b27b-2abd-48f7-af77-04b0efbde786', '457a494b-64ca-497f-868f-cc0e5f30a97f', 'Ms', 'DB', 'Results Admin', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());	
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('2838fbb7-414b-473e-965e-2f8cf6a408be', null, 'd13761e9-c134-4f80-a0a8-239a683a9c00', '5b655f56-cf35-4576-8824-b8726dcb5851', 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2022@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());
	
----

	
INSERT INTO recognising_organisation(
	recognising_organisation_uuid, organisation_type_uuid, sector_type_uuid, organisation_id, name, verification_status, partner_code, partner_contact, method_of_delivery, org_status, website_url, crm_system, organisation_code, soft_deleted, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('89d67a10-ef43-4edd-9fd3-89036f8b0065', 'e496aa98-86a3-476d-8be3-21ee0aa23c93', '48270c84-4cc8-489e-8eac-2af59898175a', '1215', 'Cambridge University-SC-Biology', 'APPROVED', 'IDP', 'partner', 'POSTAL', 'ACTIVE', 'www.ielts.org', 'CRM Value', 'UCAS231', false, 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('4cafae75-4e9d-4099-8341-477e5ceb138d', '89d67a10-ef43-4edd-9fd3-89036f8b0065', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('f0a2eb61-bc1e-4965-8183-8d434bd846e1', '89d67a10-ef43-4edd-9fd3-89036f8b0065', 'd13761e9-c134-4f80-a0a8-239a683a9c00', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());	
	
INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('210ce48c-47ad-4044-8156-93c6cc304aea', '89d67a10-ef43-4edd-9fd3-89036f8b0065', 'c3397312-8ea3-453d-871b-68a1ef8c9184', 'Ms', 'DB', 'Primary', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('c5e4268c-a55b-4cf6-b64a-e72e1a458929', '89d67a10-ef43-4edd-9fd3-89036f8b0065', '457a494b-64ca-497f-868f-cc0e5f30a97f', 'Ms', 'DB', 'Results Admin', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());	

----------------

INSERT INTO recognising_organisation(
	recognising_organisation_uuid, organisation_type_uuid, sector_type_uuid, organisation_id, name, verification_status, partner_code, partner_contact, method_of_delivery, org_status, website_url, crm_system, organisation_code, soft_deleted, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('6961ce44-b254-499f-9614-bc2104f6e40d', 'e496aa98-86a3-476d-8be3-21ee0aa23c93', '48270c84-4cc8-489e-8eac-2af59898175a', '91013', 'Cambridge University-SC-Physics', 'VERIFIED', 'IDP', 'partner', 'POSTAL', 'ACTIVE', 'www.ielts.org', 'CRM Value', 'UCAS231', false, 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('e27b9057-4ed8-44c2-a7d9-cacf1251e40a', '6961ce44-b254-499f-9614-bc2104f6e40d', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('77f41baa-8ebb-4020-b2f2-0c45ae9fc7c6', '6961ce44-b254-499f-9614-bc2104f6e40d', 'd13761e9-c134-4f80-a0a8-239a683a9c00', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());	
	
INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('006d8bd8-d07a-46b4-aa3e-4ab821720596', '6961ce44-b254-499f-9614-bc2104f6e40d', 'c3397312-8ea3-453d-871b-68a1ef8c9184', 'Ms', 'DB', 'Primary', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('9e2a397b-2349-46e6-9c06-2387346ed9c7', '6961ce44-b254-499f-9614-bc2104f6e40d', '457a494b-64ca-497f-868f-cc0e5f30a97f', 'Ms', 'DB', 'Results Admin', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());	

------------------

INSERT INTO recognising_organisation(
	recognising_organisation_uuid, organisation_type_uuid, sector_type_uuid, organisation_id, name, verification_status, partner_code, partner_contact, method_of_delivery, org_status, website_url, crm_system, organisation_code, soft_deleted, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('49ad3e10-6201-4ad1-b15f-43d3d62beae7', 'e496aa98-86a3-476d-8be3-21ee0aa23c93', '48270c84-4cc8-489e-8eac-2af59898175a', '1238', 'Cambridge University', 'APPROVED', 'IDP', 'partner', 'POSTAL', 'ACTIVE', 'www.ielts.org', 'CRM Value', 'UCAS231', false, 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('55e390d2-a4b9-49f5-af2f-890840d46bda', '49ad3e10-6201-4ad1-b15f-43d3d62beae7', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('ad515eec-af52-428e-966c-72e9f4a450bf', '49ad3e10-6201-4ad1-b15f-43d3d62beae7', 'd13761e9-c134-4f80-a0a8-239a683a9c00', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());	
	
INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('8f9df3fd-bd29-469a-b966-ef1bb31e6ed5', '49ad3e10-6201-4ad1-b15f-43d3d62beae7', 'c3397312-8ea3-453d-871b-68a1ef8c9184', 'Ms', 'DB', 'Primary', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('eaeae081-df3d-46b7-8a73-775df1894a24', '49ad3e10-6201-4ad1-b15f-43d3d62beae7', '457a494b-64ca-497f-868f-cc0e5f30a97f', 'Ms', 'DB', 'Results Admin', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());
	
		
-----
	
INSERT INTO recognising_organisation(
	recognising_organisation_uuid, organisation_type_uuid, sector_type_uuid, organisation_id, name, verification_status, partner_code, partner_contact, method_of_delivery, org_status, website_url, crm_system, organisation_code, soft_deleted, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('a727fdeb-24fe-4f64-8347-5b7d19b8f9b6', 'e496aa98-86a3-476d-8be3-21ee0aa23c93', '48270c84-4cc8-489e-8eac-2af59898175a', '5670', 'Cambridge University-Science', 'APPROVED', 'IDP', 'partner', 'POSTAL', 'ACTIVE', 'www.ielts.org', 'CRM Value', 'UCAS231', false, 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('81b1c9f5-106f-4cca-a7a5-448c38e12696', 'a727fdeb-24fe-4f64-8347-5b7d19b8f9b6', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('ad09cb87-edcb-458c-9b22-88ec7d9f8d4a', 'a727fdeb-24fe-4f64-8347-5b7d19b8f9b6', 'd13761e9-c134-4f80-a0a8-239a683a9c00', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());	
	
INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('b8074989-9ac8-4406-85cf-39ff5c5c46e2', 'a727fdeb-24fe-4f64-8347-5b7d19b8f9b6', 'c3397312-8ea3-453d-871b-68a1ef8c9184', 'Ms', 'DB', 'Primary', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('327f4e6b-842d-4a92-88bf-eb3f052eae41', 'a727fdeb-24fe-4f64-8347-5b7d19b8f9b6', '457a494b-64ca-497f-868f-cc0e5f30a97f', 'Ms', 'DB', 'Results Admin', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());	
			
-----

		
INSERT INTO recognising_organisation(
	recognising_organisation_uuid, organisation_type_uuid, sector_type_uuid, organisation_id, name, verification_status, partner_code, partner_contact, method_of_delivery, org_status, website_url, crm_system, organisation_code, soft_deleted, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('63c5b3e3-d8e6-4db4-a07e-394cdfd9095b', 'e496aa98-86a3-476d-8be3-21ee0aa23c93', '48270c84-4cc8-489e-8eac-2af59898175a', '5670', 'Cambridge University-Science', 'APPROVED', 'IDP', 'partner', 'POSTAL', 'INACTIVE', 'www.ielts.org', 'CRM Value', 'UCAS231', false, 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('fcc448eb-fef3-4ef6-afba-374db65628a0', '63c5b3e3-d8e6-4db4-a07e-394cdfd9095b', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('f81ebe70-e5ff-4628-bd2e-f322d819843b', '63c5b3e3-d8e6-4db4-a07e-394cdfd9095b', 'd13761e9-c134-4f80-a0a8-239a683a9c00', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());	
	
INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('e0cde748-7ce5-4e16-924b-02063f5adf2e', '63c5b3e3-d8e6-4db4-a07e-394cdfd9095b', 'c3397312-8ea3-453d-871b-68a1ef8c9184', 'Ms', 'DB', 'Primary', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('1f6f9423-c713-478d-88e6-297acd8bd3e6', '63c5b3e3-d8e6-4db4-a07e-394cdfd9095b', '457a494b-64ca-497f-868f-cc0e5f30a97f', 'Ms', 'DB', 'Results Admin', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());	
			
					