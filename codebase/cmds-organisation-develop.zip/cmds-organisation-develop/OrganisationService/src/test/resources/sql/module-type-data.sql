delete from module_type;
--DML scripts for module type
INSERT INTO module_type (module_type_uuid, module_type, description, effective_from_date,
effective_to_date, created_by,created_datetime, concurrency_version, updated_by, updated_datetime)
VALUES ('7a28a632-8728-4f74-882e-72e9d3649763',
        'AC',
        'Academic',
        '2020-07-01', '2099-12-31',
        'Operations User', now(), 0,
        NULL,
        NULL);


INSERT INTO module_type (module_type_uuid, module_type, description, effective_from_date,
effective_to_date, created_by,created_datetime, concurrency_version, updated_by,updated_datetime)
VALUES ('0ae29abe-5862-4c48-92e4-00d7eba376a2',
        'GT',
        'General Training',
        '2020-07-01', '2099-12-31',
        'Operations User', now(), 0,
        NULL,
        NULL);

commit;