DROP ALIAS IF EXISTS ro_owner.ro_exact_search;
CREATE ALIAS IF NOT EXISTS ro_owner.ro_exact_search FOR "com.ielts.cmds.organisation.utills.SearchTestUtility.exactSearchResults";
