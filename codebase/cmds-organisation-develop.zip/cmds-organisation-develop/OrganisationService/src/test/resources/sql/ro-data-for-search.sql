--DML scripts ro search
DELETE FROM address;
DELETE FROM contact;
DELETE FROM recognised_product;
DELETE FROM recognising_organisation;
--Recognising Organisation DML Script
INSERT INTO recognising_organisation(recognising_organisation_uuid, 
	organisation_type_uuid, 
	sector_type_uuid, 
	organisation_id, 
	name, 
	verification_status, 
	partner_code,
	partner_contact,
	method_of_delivery, 
	org_status, 
	website_url,
	crm_system,
	organisation_code, 
	soft_deleted, 
	concurrency_version, 
	created_by, 
	created_datetime, 
	updated_by, 
	updated_datetime)
	VALUES ('eeb87d1e-3d5b-4375-8edf-55e66c86b1de', 
	'e496aa98-86a3-476d-8be3-21ee0aa23c93', 
	'6a6f32d1-b904-4592-b214-beec9cde3403', 
	321, 
	'London Metropolitain University', 
	'APPROVED', 
	'BC',
	'Partner',
	'POSTAL', 
	'ACTIVE', 
	NULL,
	'CRM Value',
	NULL,
	FALSE,
	1,	
	'ro_migration', 
	'2018-03-11 02:00:00', 
	NULL, 
	NULL);

--Contact DML Script
INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('52a77cc9-9923-46b6-bcf1-ecc8790e9868', 'eeb87d1e-3d5b-4375-8edf-55e66c86b1de', '80f4bba7-70b2-4e16-bef4-2ff06c58f620', 'Ms', 'Test', 'Contact', 'Chief Support Manager' , '2018-03-11 02:00:00', '2018-03-11 02:00:00', 1,	
	'ro_migration', 
	'2018-03-11 02:00:00', 
	NULL, 
	NULL);

--Address DML Script
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('8991366f-9013-49eb-af68-b33a11eb38eb', 'eeb87d1e-3d5b-4375-8edf-55e66c86b1de', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', '52a77cc9-9923-46b6-bcf1-ecc8790e9868', '029fd27d-b39a-48b4-87e7-131a063bea2d', '029fd27d-b39a-48b4-87e7-131a063bea2d', '166 - 220 Holloway Road', 'London', NULL, NULL, 'Cambridge', 'DBP 001', 'xyz@example.com', NULL, 1,	
	'ro_migration', 
	'2018-03-11 02:00:00', 
	NULL, 
	NULL);
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('e249522a-9bf2-481b-9787-241852201163', 'eeb87d1e-3d5b-4375-8edf-55e66c86b1de', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', NULL, '029fd27d-b39a-48b4-87e7-131a063bea2d', '029fd27d-b39a-48b4-87e7-131a063bea2d', '166 - 220 Holloway Road', 'London', NULL, NULL, 'Cambridge', 'DBP 001', 'xyz@example.com', NULL, 1,	
	'ro_migration', 
	'2018-03-11 02:00:00', 
	NULL, 
	NULL);

	INSERT INTO recognising_organisation(recognising_organisation_uuid, 
	organisation_type_uuid, 
	sector_type_uuid, 
	organisation_id, 
	name, 
	verification_status, 
	partner_code,
	partner_contact,
	method_of_delivery, 
	org_status, 
	website_url,
	crm_system,
	organisation_code, 
	soft_deleted, 
	concurrency_version, 
	created_by, 
	created_datetime, 
	updated_by, 
	updated_datetime)
	VALUES ('841eafcc-d9ad-4de2-804c-ff2bb5105281', 
	'e496aa98-86a3-476d-8be3-21ee0aa23c93', 
	'6a6f32d1-b904-4592-b214-beec9cde3403', 
	322, 
	'Cambridge University', 
	'APPROVED', 
	'BC',
	'Partner',
	'POSTAL', 
	'ACTIVE', 
	NULL,
	'CRM Value',
	NULL,
	FALSE,
	0,	
	'ro_migration', 
	'2018-03-11 02:00:00', 
	NULL, 
	NULL);

--Contact DML Script
INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('1bd70bab-0a27-4a08-bf9f-23a7dbdd0f9e', 'eeb87d1e-3d5b-4375-8edf-55e66c86b1de', '80f4bba7-70b2-4e16-bef4-2ff06c58f620', 'Ms', 'Test', 'Contact', 'Chief Support Manager' , '2018-03-11 02:00:00', '2018-03-11 02:00:00', 1,	
	'ro_migration', 
	'2018-03-11 02:00:00', 
	NULL, 
	NULL);

--Address DML Script
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('c6dcc762-5cdf-4f8c-b7b3-ef73ce00e931', 'eeb87d1e-3d5b-4375-8edf-55e66c86b1de', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', '52a77cc9-9923-46b6-bcf1-ecc8790e9868', '029fd27d-b39a-48b4-87e7-131a063bea2d', '029fd27d-b39a-48b4-87e7-131a063bea2d', '166 - 220 Holloway Road', 'London', NULL, NULL, 'Cambridge', 'DBP 001', 'xyz@example.com', NULL, 1,	
	'ro_migration', 
	'2018-03-11 02:00:00', 
	NULL, 
	NULL);
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('859a8b92-38f9-4e95-8f35-c6eddf4eb89e', 'eeb87d1e-3d5b-4375-8edf-55e66c86b1de', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', NULL, '029fd27d-b39a-48b4-87e7-131a063bea2d', '029fd27d-b39a-48b4-87e7-131a063bea2d', '166 - 220 Holloway Road', 'London', NULL, NULL, 'Cambridge', 'DBP 001', 'xyz@example.com', NULL, 1,	
	'ro_migration', 
	'2018-03-11 02:00:00', 
	NULL, 
	NULL);
	INSERT INTO recognising_organisation(recognising_organisation_uuid, 
	organisation_type_uuid, 
	sector_type_uuid, 
	organisation_id, 
	name, 
	verification_status, 
	partner_code,
	partner_contact,
	method_of_delivery, 
	org_status, 
	website_url,
	crm_system,
	organisation_code, 
	soft_deleted, 
	concurrency_version, 
	created_by, 
	created_datetime, 
	updated_by, 
	updated_datetime)
	VALUES ('1a85bcfd-06f3-40ad-8dd0-ffd35ee162ba', 
	'e496aa98-86a3-476d-8be3-21ee0aa23c93', 
	'6a6f32d1-b904-4592-b214-beec9cde3403', 
	323, 
	'Cambridge University of arts', 
	'APPROVED', 
	'BC',
	'Partner',
	'POSTAL', 
	'ACTIVE', 
	NULL,
	'CRM Value',
	NULL,
	FALSE,
	1,	
	'ro_migration', 
	'2018-03-11 02:00:00', 
	NULL, 
	NULL);

--Contact DML Script
INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('dd387501-1763-4543-8b39-682b17faac5d', 'eeb87d1e-3d5b-4375-8edf-55e66c86b1de', '80f4bba7-70b2-4e16-bef4-2ff06c58f620', 'Ms', 'Test', 'Contact', 'Chief Support Manager' , '2018-03-11 02:00:00', '2018-03-11 02:00:00', 1,	
	'ro_migration', 
	'2018-03-11 02:00:00', 
	NULL, 
	NULL);

--Address DML Script
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('16dc34ff-12f6-4368-b4dc-5a7a246b9f0e', 'eeb87d1e-3d5b-4375-8edf-55e66c86b1de', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', '52a77cc9-9923-46b6-bcf1-ecc8790e9868', '029fd27d-b39a-48b4-87e7-131a063bea2d', '029fd27d-b39a-48b4-87e7-131a063bea2d', '166 - 220 Holloway Road', 'London', NULL, NULL, 'Cambridge', 'DBP 001', 'xyz@example.com', NULL, 1,	
	'ro_migration', 
	'2018-03-11 02:00:00', 
	NULL, 
	NULL);
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('7e8c35d6-ee96-4dad-9c99-47956c31cc1e', 'eeb87d1e-3d5b-4375-8edf-55e66c86b1de', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', NULL, '029fd27d-b39a-48b4-87e7-131a063bea2d', '029fd27d-b39a-48b4-87e7-131a063bea2d', '166 - 220 Holloway Road', 'London', NULL, NULL, 'Cambridge', 'DBP 001', 'xyz@example.com', NULL, 1,	
	'ro_migration', 
	'2018-03-11 02:00:00', 
	NULL, 
	NULL);

	INSERT INTO recognising_organisation(recognising_organisation_uuid, 
	organisation_type_uuid, 
	sector_type_uuid, 
	organisation_id, 
	name, 
	verification_status, 
	partner_code,
	partner_contact,
	method_of_delivery, 
	org_status, 
	website_url,
	crm_system,
	organisation_code, 
	soft_deleted, 
	concurrency_version, 
	created_by, 
	created_datetime, 
	updated_by, 
	updated_datetime)
	VALUES ('af6a68a8-13f5-40a5-9e2d-2b7a8f2acb39', 
	'e496aa98-86a3-476d-8be3-21ee0aa23c93', 
	'6a6f32d1-b904-4592-b214-beec9cde3403', 
	324, 
	'Cambridge University of medical', 
	'APPROVED', 
	'BC',
	'Partner',
	'POSTAL', 
	'ACTIVE', 
	NULL,
	'CRM Value',
	NULL,
	FALSE,
	1,	
	'ro_migration', 
	'2018-03-11 02:00:00', 
	NULL, 
	NULL);

--Contact DML Script
INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('6be7cd7b-4ee9-4cf0-ac5a-d5dbe143a327', 'eeb87d1e-3d5b-4375-8edf-55e66c86b1de', '80f4bba7-70b2-4e16-bef4-2ff06c58f620', 'Ms', 'Test', 'Contact', 'Chief Support Manager' , '2018-03-11 02:00:00', '2018-03-11 02:00:00', 1,	
	'ro_migration', 
	'2018-03-11 02:00:00', 
	NULL, 
	NULL);

--Address DML Script
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('8414d1fc-e920-4ad9-875b-d9ef3f318e8d', 'eeb87d1e-3d5b-4375-8edf-55e66c86b1de', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', '52a77cc9-9923-46b6-bcf1-ecc8790e9868', '029fd27d-b39a-48b4-87e7-131a063bea2d', '029fd27d-b39a-48b4-87e7-131a063bea2d', '166 - 220 Holloway Road', 'London', NULL, NULL, 'Cambridge', 'DBP 001', 'xyz@example.com', NULL, 1,	
	'ro_migration', 
	'2018-03-11 02:00:00', 
	NULL, 
	NULL);
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('9bf3f324-be73-4380-a440-a8196a73a346', 'eeb87d1e-3d5b-4375-8edf-55e66c86b1de', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', NULL, '029fd27d-b39a-48b4-87e7-131a063bea2d', '029fd27d-b39a-48b4-87e7-131a063bea2d', '166 - 220 Holloway Road', 'London', NULL, NULL, 'Cambridge', 'DBP 001', 'xyz@example.com', NULL, 1,	
	'ro_migration', 
	'2018-03-11 02:00:00', 
	NULL, 
	NULL);

commit;		