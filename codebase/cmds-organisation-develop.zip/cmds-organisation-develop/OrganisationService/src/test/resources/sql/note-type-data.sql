--DML scripts for note type
DELETE FROM note_type;
INSERT INTO note_type(note_type_uuid, note_type, description, effective_from_date, effective_to_date, created_by, created_datetime, concurrency_version) VALUES ('e82a7b48-e4d8-4edd-a87a-bfe7816092a9','Internal', NULL, '2020-07-01','2099-12-31', 'Operations User', now(), 0);
INSERT INTO note_type(note_type_uuid, note_type, description, effective_from_date, effective_to_date, created_by, created_datetime, concurrency_version) VALUES ('21dd3e30-3253-49f4-9ef9-a2071d9bea24','External', NULL, '2020-07-01', '2099-12-31', 'Operations User', now(), 0);

commit;