delete from organisation_type;
--DML scripts for organisation type
INSERT INTO organisation_type(
	organisation_type_uuid, organisation_type, description, effective_from_date, effective_to_date,
	created_by,
	created_datetime, updated_by,
	updated_datetime, concurrency_version) VALUES ('e496aa98-86a3-476d-8be3-21ee0aa23c93','RO','Recognising Organisation',
	'2020-07-01', '2099-12-31', 'Operations User', now(),NULL,NULL, 0);

INSERT INTO organisation_type(
	organisation_type_uuid, organisation_type, description, effective_from_date, effective_to_date,
	created_by, created_datetime, updated_by,
	updated_datetime, concurrency_version)
	VALUES ('e392ae7c-016f-433a-bdfa-b79bfcdddf26','VO','Verified Organisation', '2020-07-01', '2099-12-31', 
	'Operations User', now(),NULL,NULL,0);
	
commit;