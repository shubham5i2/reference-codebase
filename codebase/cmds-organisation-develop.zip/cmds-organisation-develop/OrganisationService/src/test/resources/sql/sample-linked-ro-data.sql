--A1(child) linked to A(Parent) 
INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('46afc4e8-8972-4ffc-9682-40a035e854a2', '63bf1302-acb6-401c-879f-2ae55dfe8c62', 'ae1a5ea5-b6ab-40f3-ba72-cca9dff8332e', 'PARENT_RO', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', '1', 0, 'Operations User', now(), 'Operations User', now());

--D1(child) linked to A(Parent) 	
INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('a8239c83-fc59-4e8e-a860-3bef0defc26f', 'b56d6c5f-d7f9-453d-b14f-ccd7f0586ff5', 'ae1a5ea5-b6ab-40f3-ba72-cca9dff8332e', 'PARENT_RO', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', '1', 0, 'Operations User', now(), 'Operations User', now());

--D11(child) linked to D1(Parent) 	
INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('02b79118-e804-4e27-bdfd-644a44357e50', '4f31efca-c2ed-4607-841d-c7a9afbdbd36', 'b56d6c5f-d7f9-453d-b14f-ccd7f0586ff5', 'PARENT_RO', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', '1', 0, 'Operations User', now(), 'Operations User', now());

--D12(child) linked to D1(Parent) 	
INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('80550f4b-16c4-478e-9a3e-43adfceed9ac', 'fb35dd34-1b87-4c46-b6ab-21186c41663a', 'b56d6c5f-d7f9-453d-b14f-ccd7f0586ff5', 'PARENT_RO', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', '1', 0, 'Operations User', now(), 'Operations User', now());

--D121(child) linked to D12(Parent)	
INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('3add1997-9c79-4230-8da5-0991d07054e2', '602cc9a1-9297-4dc1-b1c6-c0a4d8923750', 'fb35dd34-1b87-4c46-b6ab-21186c41663a', 'PARENT_RO', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', '1', 0, 'Operations User', now(), 'Operations User', now());

--D122(child) linked to D12(Parent)		
INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('0919996b-dba5-4839-a6e5-faa70b88bb48', 'c260bc1c-e3da-40cf-9ca9-f0fc2cfaa67d', 'fb35dd34-1b87-4c46-b6ab-21186c41663a', 'PARENT_RO', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', '1', 0, 'Operations User', now(), 'Operations User', now());
	
--A1 having A as Additional Delivery Organisation	
INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('7ccb3d57-be49-4de2-bc00-67c36b6e6895', '63bf1302-acb6-401c-879f-2ae55dfe8c62', 'ae1a5ea5-b6ab-40f3-ba72-cca9dff8332e', 'RESULTS_DELIVERY', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', null, 0, 'Operations User', now(), 'Operations User', now());	

--A1 having D1 as Additional Delivery Organisation	
INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('40babcfb-be37-45c5-8061-838d4e47f4c8', '63bf1302-acb6-401c-879f-2ae55dfe8c62', 'b56d6c5f-d7f9-453d-b14f-ccd7f0586ff5', 'RESULTS_DELIVERY', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', null, 0, 'Operations User', now(), 'Operations User', now());
	
--D1 having A as Additional Delivery Organisation		
INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('418e2486-64d0-4cef-b0c4-b444199dc447', 'b56d6c5f-d7f9-453d-b14f-ccd7f0586ff5', 'ae1a5ea5-b6ab-40f3-ba72-cca9dff8332e', 'RESULTS_DELIVERY', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', null, 0, 'Operations User', now(), 'Operations User', now());
	
--D11 having A as Additional Delivery Organisation	
INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('81509c7b-fa70-47b2-855b-641c667f14bb', '4f31efca-c2ed-4607-841d-c7a9afbdbd36', 'ae1a5ea5-b6ab-40f3-ba72-cca9dff8332e', 'RESULTS_DELIVERY', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', null, 0, 'Operations User', now(), 'Operations User', now());

--D11 having D1 as Additional Delivery Organisation	
INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('7c9758d1-2fd5-4976-abad-4a8dadc18f44', '4f31efca-c2ed-4607-841d-c7a9afbdbd36', 'b56d6c5f-d7f9-453d-b14f-ccd7f0586ff5', 'RESULTS_DELIVERY', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', null, 0, 'Operations User', now(), 'Operations User', now());

--D12 having A1 as Additional Delivery Organisation	
INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('e3141134-1f6e-455b-8e7d-51418b91d100', 'fb35dd34-1b87-4c46-b6ab-21186c41663a', '63bf1302-acb6-401c-879f-2ae55dfe8c62', 'RESULTS_DELIVERY', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', null, 0, 'Operations User', now(), 'Operations User', now());

--D12 having D121 as Additional Delivery Organisation	
INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('9f637cb4-5b5f-44dd-afe3-ddd9d1af98fb', 'fb35dd34-1b87-4c46-b6ab-21186c41663a', '602cc9a1-9297-4dc1-b1c6-c0a4d8923750', 'RESULTS_DELIVERY', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', null, 0, 'Operations User', now(), 'Operations User', now());

--D121 having A1 as Additional Delivery Organisation
INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('bc268842-8b0c-4899-ace7-8df7cced80f1', '602cc9a1-9297-4dc1-b1c6-c0a4d8923750', '63bf1302-acb6-401c-879f-2ae55dfe8c62', 'RESULTS_DELIVERY', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', null, 0, 'Operations User', now(), 'Operations User', now());

--D121 having D11 as Additional Delivery Organisation	
INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('f7fa008d-7f8f-4406-bc41-6231e9165a86', '602cc9a1-9297-4dc1-b1c6-c0a4d8923750', '4f31efca-c2ed-4607-841d-c7a9afbdbd36', 'RESULTS_DELIVERY', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', null, 0, 'Operations User', now(), 'Operations User', now());

--D122 having D12 as Additional Delivery Organisation	
INSERT INTO linked_recognising_organisation(
	linked_recognising_organisation_uuid, source_recognising_organisation_uuid, target_recognising_organisation_uuid, linked_recognising_organisation_type, effective_from_datetime, effective_to_datetime, organisation_hierarchy_label, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('11a6320c-f767-4161-a8c3-88e7ffbd0730', 'c260bc1c-e3da-40cf-9ca9-f0fc2cfaa67d', 'fb35dd34-1b87-4c46-b6ab-21186c41663a', 'RESULTS_DELIVERY', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', null, 0, 'Operations User', now(), 'Operations User', now());	
	