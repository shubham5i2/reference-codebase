---                                        A
---                                      /   \
---                                     A1    D1
---                                          /  \
---                                        D11  D12
---                                            /  \
---                                         D121  D122
                                   

---A is root Node, A has A1 and D1 as children
INSERT INTO recognising_organisation(
	recognising_organisation_uuid, organisation_type_uuid, sector_type_uuid, organisation_id, name, verification_status, partner_code, partner_contact, method_of_delivery, org_status, website_url, crm_system, organisation_code, soft_deleted, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('ae1a5ea5-b6ab-40f3-ba72-cca9dff8332e', 'e496aa98-86a3-476d-8be3-21ee0aa23c93', '48270c84-4cc8-489e-8eac-2af59898175a', '1', 'A', 'APPROVED', 'IDP', 'partner', 'POSTAL', 'ACTIVE', 'www.ielts.org', 'CRM Value', 'UCAS231', false, 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('edb2161d-4d21-4ddd-bd85-1cb27defcb3c', 'ae1a5ea5-b6ab-40f3-ba72-cca9dff8332e', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('a4d74e99-55da-46c2-aab0-e14d3e073e47', 'ae1a5ea5-b6ab-40f3-ba72-cca9dff8332e', 'd13761e9-c134-4f80-a0a8-239a683a9c00', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('c22354f7-9976-4cee-94aa-09b70bef2fb8', 'ae1a5ea5-b6ab-40f3-ba72-cca9dff8332e', 'c3397312-8ea3-453d-871b-68a1ef8c9184', 'Ms', 'DB', 'Primary', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('9c72784d-bf12-4350-804a-46a1eafacf41', 'ae1a5ea5-b6ab-40f3-ba72-cca9dff8332e', '457a494b-64ca-497f-868f-cc0e5f30a97f', 'Ms', 'DB', 'Results Admin', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('404f51ed-fb87-4c56-8881-b5580c7adc4d', null, 'd13761e9-c134-4f80-a0a8-239a683a9c00', '9c72784d-bf12-4350-804a-46a1eafacf41', 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());
-----------------A1 is child of A
INSERT INTO recognising_organisation(
	recognising_organisation_uuid, organisation_type_uuid, sector_type_uuid, organisation_id, name, verification_status, partner_code, partner_contact, method_of_delivery, org_status, website_url, crm_system, organisation_code, soft_deleted, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('63bf1302-acb6-401c-879f-2ae55dfe8c62', 'e496aa98-86a3-476d-8be3-21ee0aa23c93', '48270c84-4cc8-489e-8eac-2af59898175a', '2', 'A1', 'APPROVED', 'IDP', 'partner', 'POSTAL', 'ACTIVE', 'www.ielts.org', 'CRM Value', 'UCAS231', false, 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('5e190c42-23a4-4e65-b972-fca18f67538b', '63bf1302-acb6-401c-879f-2ae55dfe8c62', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('c000c445-93c2-4b8c-bce5-853b27d11aa7', '63bf1302-acb6-401c-879f-2ae55dfe8c62', 'd13761e9-c134-4f80-a0a8-239a683a9c00', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('babc4275-fb49-4421-b204-143f0fa97be5', '63bf1302-acb6-401c-879f-2ae55dfe8c62', 'c3397312-8ea3-453d-871b-68a1ef8c9184', 'Ms', 'DB', 'Primary', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('7c63d13d-e8ff-4625-abe2-5fecc4780b3d', '63bf1302-acb6-401c-879f-2ae55dfe8c62', '457a494b-64ca-497f-868f-cc0e5f30a97f', 'Ms', 'DB', 'Results Admin', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('e543f652-8e86-4707-8f14-5d2560f72b27', null, 'd13761e9-c134-4f80-a0a8-239a683a9c00', '7c63d13d-e8ff-4625-abe2-5fecc4780b3d', 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());
-------------------------------D1 is chid of A, and D1 is further has D11 and D12 as children
INSERT INTO recognising_organisation(
	recognising_organisation_uuid, organisation_type_uuid, sector_type_uuid, organisation_id, name, verification_status, partner_code, partner_contact, method_of_delivery, org_status, website_url, crm_system, organisation_code, soft_deleted, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('b56d6c5f-d7f9-453d-b14f-ccd7f0586ff5', 'e496aa98-86a3-476d-8be3-21ee0aa23c93', '48270c84-4cc8-489e-8eac-2af59898175a', '3', 'D1', 'APPROVED', 'IDP', 'partner', 'POSTAL', 'ACTIVE', 'www.ielts.org', 'CRM Value', 'UCAS231', false, 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('6fdb84f7-b008-4849-983e-1323db2bc329', 'b56d6c5f-d7f9-453d-b14f-ccd7f0586ff5', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('15141d38-0459-4ad0-8b41-5dad11b51f2f', 'b56d6c5f-d7f9-453d-b14f-ccd7f0586ff5', 'd13761e9-c134-4f80-a0a8-239a683a9c00', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('8a7c812b-803a-45d4-8275-52ef747b9090', 'b56d6c5f-d7f9-453d-b14f-ccd7f0586ff5', 'c3397312-8ea3-453d-871b-68a1ef8c9184', 'Ms', 'DB', 'Primary', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('d43ce9e5-a713-4135-be0d-26a2c66bc0b9', 'b56d6c5f-d7f9-453d-b14f-ccd7f0586ff5', '457a494b-64ca-497f-868f-cc0e5f30a97f', 'Ms', 'DB', 'Results Admin', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('1fc32432-703f-41b7-9d8c-156ecdb7aa27', null, 'd13761e9-c134-4f80-a0a8-239a683a9c00', 'd43ce9e5-a713-4135-be0d-26a2c66bc0b9', 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());
-----------------------------------------D11 child of D1
INSERT INTO recognising_organisation(
	recognising_organisation_uuid, organisation_type_uuid, sector_type_uuid, organisation_id, name, verification_status, partner_code, partner_contact, method_of_delivery, org_status, website_url, crm_system, organisation_code, soft_deleted, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('4f31efca-c2ed-4607-841d-c7a9afbdbd36', 'e496aa98-86a3-476d-8be3-21ee0aa23c93', '48270c84-4cc8-489e-8eac-2af59898175a', '4', 'D11', 'APPROVED', 'IDP', 'partner', 'POSTAL', 'ACTIVE', 'www.ielts.org', 'CRM Value', 'UCAS231', false, 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('bf29a68f-5232-4c65-b1f7-7a6442aa3690', '4f31efca-c2ed-4607-841d-c7a9afbdbd36', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('27249019-c159-429c-8a22-fb4aad968dbd', '4f31efca-c2ed-4607-841d-c7a9afbdbd36', 'd13761e9-c134-4f80-a0a8-239a683a9c00', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('e6184a47-b774-41a4-9838-f73fd453f817', '4f31efca-c2ed-4607-841d-c7a9afbdbd36', 'c3397312-8ea3-453d-871b-68a1ef8c9184', 'Ms', 'DB', 'Primary', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('2112182b-66d4-42f5-83ed-dc30e101619f', '4f31efca-c2ed-4607-841d-c7a9afbdbd36', '457a494b-64ca-497f-868f-cc0e5f30a97f', 'Ms', 'DB', 'Results Admin', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('6e81cc87-8bc1-4a03-8f6b-88870f0c395d', null, 'd13761e9-c134-4f80-a0a8-239a683a9c00', '2112182b-66d4-42f5-83ed-dc30e101619f', 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());
-------------------------------------------D12 child of D1 and D12 furter has D121 and D122 as children
INSERT INTO recognising_organisation(
	recognising_organisation_uuid, organisation_type_uuid, sector_type_uuid, organisation_id, name, verification_status, partner_code, partner_contact, method_of_delivery, org_status, website_url, crm_system, organisation_code, soft_deleted, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('fb35dd34-1b87-4c46-b6ab-21186c41663a', 'e496aa98-86a3-476d-8be3-21ee0aa23c93', '48270c84-4cc8-489e-8eac-2af59898175a', '5', 'D12', 'APPROVED', 'IDP', 'partner', 'POSTAL', 'ACTIVE', 'www.ielts.org', 'CRM Value', 'UCAS231', false, 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('873894a0-375c-4033-9837-9482be015078', 'fb35dd34-1b87-4c46-b6ab-21186c41663a', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('2121976f-1976-4c22-a2b0-c435eb0a7cb3', 'fb35dd34-1b87-4c46-b6ab-21186c41663a', 'd13761e9-c134-4f80-a0a8-239a683a9c00', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('6d25a8ed-3d8b-45f1-a6d9-789153f6390b', 'fb35dd34-1b87-4c46-b6ab-21186c41663a', 'c3397312-8ea3-453d-871b-68a1ef8c9184', 'Ms', 'DB', 'Primary', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('b18450d8-f278-4739-8c95-c324ff1612d7', 'fb35dd34-1b87-4c46-b6ab-21186c41663a', '457a494b-64ca-497f-868f-cc0e5f30a97f', 'Ms', 'DB', 'Results Admin', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('017cc132-6114-44da-b095-4b735ae5e400', null, 'd13761e9-c134-4f80-a0a8-239a683a9c00', 'b18450d8-f278-4739-8c95-c324ff1612d7', 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());
-----------------------------------D121 child of D12
INSERT INTO recognising_organisation(
	recognising_organisation_uuid, organisation_type_uuid, sector_type_uuid, organisation_id, name, verification_status, partner_code, partner_contact, method_of_delivery, org_status, website_url, crm_system, organisation_code, soft_deleted, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('602cc9a1-9297-4dc1-b1c6-c0a4d8923750', 'e496aa98-86a3-476d-8be3-21ee0aa23c93', '48270c84-4cc8-489e-8eac-2af59898175a', '6', 'D121', 'APPROVED', 'IDP', 'partner', 'POSTAL', 'ACTIVE', 'www.ielts.org', 'CRM Value', 'UCAS231', false, 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('de5a9aa2-4f25-4b08-827b-0fae1198c504', '602cc9a1-9297-4dc1-b1c6-c0a4d8923750', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('19a9e97e-5a66-46e9-8432-82ff9627e245', '602cc9a1-9297-4dc1-b1c6-c0a4d8923750', 'd13761e9-c134-4f80-a0a8-239a683a9c00', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('be35a024-0312-4369-9430-5588be48343e', '602cc9a1-9297-4dc1-b1c6-c0a4d8923750', 'c3397312-8ea3-453d-871b-68a1ef8c9184', 'Ms', 'DB', 'Primary', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('986ed5f1-e54a-4829-aeab-c3ffd98ccb59', '602cc9a1-9297-4dc1-b1c6-c0a4d8923750', '457a494b-64ca-497f-868f-cc0e5f30a97f', 'Ms', 'DB', 'Results Admin', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('1f24c697-33db-4c99-b0e4-fd24fffa5f8f', null, 'd13761e9-c134-4f80-a0a8-239a683a9c00', '986ed5f1-e54a-4829-aeab-c3ffd98ccb59', 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());
-------------------------------------------D122 child of D12
INSERT INTO recognising_organisation(
	recognising_organisation_uuid, organisation_type_uuid, sector_type_uuid, organisation_id, name, verification_status, partner_code, partner_contact, method_of_delivery, org_status, website_url, crm_system, organisation_code, soft_deleted, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('c260bc1c-e3da-40cf-9ca9-f0fc2cfaa67d', 'e496aa98-86a3-476d-8be3-21ee0aa23c93', '48270c84-4cc8-489e-8eac-2af59898175a', '7', 'D122', 'APPROVED', 'IDP', 'partner', 'POSTAL', 'ACTIVE', 'www.ielts.org', 'CRM Value', 'UCAS231', false, 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('c8b4fae7-0ab3-4175-8b2e-8e05ebadd5de', 'c260bc1c-e3da-40cf-9ca9-f0fc2cfaa67d', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('7589764b-82eb-417b-85b8-6fcf409defd6', 'c260bc1c-e3da-40cf-9ca9-f0fc2cfaa67d', 'd13761e9-c134-4f80-a0a8-239a683a9c00', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('27a76330-1208-40a0-acf2-d2fc32f811ab', 'c260bc1c-e3da-40cf-9ca9-f0fc2cfaa67d', 'c3397312-8ea3-453d-871b-68a1ef8c9184', 'Ms', 'DB', 'Primary', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, title, first_name, last_name, job_title, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('f77a12d1-9c33-4b4b-b990-0d3fe0098461', 'c260bc1c-e3da-40cf-9ca9-f0fc2cfaa67d', '457a494b-64ca-497f-868f-cc0e5f30a97f', 'Ms', 'DB', 'Results Admin', 'Chief Operations Manager', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('6e879558-1b55-4936-91e9-1d1fbe5abcdf', null, 'd13761e9-c134-4f80-a0a8-239a683a9c00', 'f77a12d1-9c33-4b4b-b990-0d3fe0098461', 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());

	
/**/	
INSERT INTO recognising_organisation(
	recognising_organisation_uuid, organisation_type_uuid, sector_type_uuid, organisation_id, name, verification_status, partner_code, partner_contact, method_of_delivery, org_status, website_url, organisation_code, result_available_for_years, ielts_display_flag, ors_display_flag, soft_deleted, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('0b30c635-80df-49a3-beed-f1752f8bde3c', 'e496aa98-86a3-476d-8be3-21ee0aa23c93', '48270c84-4cc8-489e-8eac-2af59898175a', '234', 'University1', 'APPROVED', 'IDP', 'partner', 'POSTAL', 'INACTIVE', 'www.ielts.org', 'UCAS231', 2, false, false, false, 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('b8287b55-102d-45d3-8592-e8b74d6a6bbd', '0b30c635-80df-49a3-beed-f1752f8bde3c', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('0bfa1392-b0ca-4ffb-a52e-21f981230408', '0b30c635-80df-49a3-beed-f1752f8bde3c', 'd13761e9-c134-4f80-a0a8-239a683a9c00', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());	
	
INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, first_name, last_name, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('305303f4-2156-41a2-8bb9-d29497332bc7', '0b30c635-80df-49a3-beed-f1752f8bde3c', 'c3397312-8ea3-453d-871b-68a1ef8c9184', 'DB', 'Primary', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, first_name, last_name, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('e14429c8-e909-49df-8bcc-36ea57eced1d', '0b30c635-80df-49a3-beed-f1752f8bde3c', '457a494b-64ca-497f-868f-cc0e5f30a97f', 'DB', 'Results Admin', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());
	
	