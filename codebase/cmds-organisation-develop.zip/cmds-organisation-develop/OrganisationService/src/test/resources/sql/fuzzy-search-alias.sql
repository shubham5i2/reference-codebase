DROP ALIAS IF EXISTS ro_owner.ro_fuzzy_search;
CREATE ALIAS IF NOT EXISTS ro_owner.ro_fuzzy_search FOR "com.ielts.cmds.organisation.utills.SearchTestUtility.fuzzySearchResults";
