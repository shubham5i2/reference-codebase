/**/	
INSERT INTO recognising_organisation(
	recognising_organisation_uuid, organisation_type_uuid, sector_type_uuid, organisation_id, name, verification_status, partner_code, partner_contact, method_of_delivery, org_status, website_url, organisation_code,result_available_for_years, ielts_display_flag, ors_display_flag, soft_deleted, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('d303bc54-d13b-4252-aae6-486cf5a4f1f6', 'e392ae7c-016f-433a-bdfa-b79bfcdddf26', '48270c84-4cc8-489e-8eac-2af59898175a', '234', 'University1', 'VERIFIED', 'IDP', 'partner', 'POSTAL', 'ACTIVE', 'www.ielts.org', 'UCAS231',2, false, false, false, 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('b8f81631-46ac-4ba6-a69d-6f1a27de05e0', 'd303bc54-d13b-4252-aae6-486cf5a4f1f6', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('066756f1-feb9-4998-9ed5-00bd1e71a264', 'd303bc54-d13b-4252-aae6-486cf5a4f1f6', 'd13761e9-c134-4f80-a0a8-239a683a9c00', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());	
	
INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, first_name, last_name, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('ef4e93a7-ab5a-480a-8e31-58d05f3dc7d9', 'd303bc54-d13b-4252-aae6-486cf5a4f1f6', 'c3397312-8ea3-453d-871b-68a1ef8c9184', 'DB', 'Primary', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());

INSERT INTO contact(
	contact_uuid, recognising_organisation_uuid, contact_type_uuid, first_name, last_name, effective_from_datetime, effective_to_datetime, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('bb4cbc41-26f3-4eb4-824b-a7b4105e7957', 'd303bc54-d13b-4252-aae6-486cf5a4f1f6', '457a494b-64ca-497f-868f-cc0e5f30a97f', 'DB', 'Results Admin', '2021-07-07 14:16:54.871', '2099-07-07 14:16:54.871', 0, 'Operations User', now(), 'Operations User', now());	
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('d6cce278-43dc-44b2-a7fc-a75037f5b2bd', null, 'd13761e9-c134-4f80-a0a8-239a683a9c00', 'bb4cbc41-26f3-4eb4-824b-a7b4105e7957', 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());	

-----------
	
INSERT INTO recognising_organisation(
	recognising_organisation_uuid, organisation_type_uuid, sector_type_uuid, organisation_id, name, verification_status, partner_code, partner_contact, method_of_delivery, org_status, website_url, organisation_code,result_available_for_years, ielts_display_flag, ors_display_flag, soft_deleted, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('f00a3502-bb69-4f85-a606-0bdb621e3a90', 'e392ae7c-016f-433a-bdfa-b79bfcdddf26', '48270c84-4cc8-489e-8eac-2af59898175a', '234', 'University1', 'VERIFIED', 'IDP', 'partner', 'POSTAL', 'ACTIVE', 'www.ielts.org', 'UCAS231',2, false, false, false, 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('917bbe07-f6c6-4dc8-a757-0a5745df6bfc', 'f00a3502-bb69-4f85-a606-0bdb621e3a90', 'c96fbd08-a302-4aa2-a594-13cdb33bb380', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());
	
INSERT INTO address(
	address_uuid, recognising_organisation_uuid, address_type_uuid, contact_uuid, territory_uuid, country_uuid, addressline1, addressline2, addressline3, addressline4, city, postalcode, email, phone, concurrency_version, created_by, created_datetime, updated_by, updated_datetime)
	VALUES ('6e9d3b7b-e437-476d-a63d-82715153f1d9', 'f00a3502-bb69-4f85-a606-0bdb621e3a90', 'd13761e9-c134-4f80-a0a8-239a683a9c00', null, 'f1bccce9-89e9-46da-a8dd-03c6db8b3815', '4b8dac87-d2dd-4599-b055-2f73a5f0a01a', 'Cambridge', null, null, null, 'Cambridge', 'CB2 8EA', 'alan_2021@cambridgeassessment.org.uk', '+1 234 234 3456', 0, 'Operations User', now(), 'Operations User', now());	
	