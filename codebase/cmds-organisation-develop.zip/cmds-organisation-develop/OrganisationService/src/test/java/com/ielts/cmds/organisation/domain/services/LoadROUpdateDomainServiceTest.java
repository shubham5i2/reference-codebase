package com.ielts.cmds.organisation.domain.services;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.organisation.domain.commands.LoadROData;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

/** @author cts */
@ExtendWith(MockitoExtension.class)
class LoadROUpdateDomainServiceTest {

    @InjectMocks private LoadROUpdateDomainService loadROUpdateDomainService;

    @Mock private LoadROHierarchyHelper loadROHierarchyHelper;

    @Mock private BulkRORecognisedProductsUpdateHelper productUpdateHelper;

    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(
                loadROUpdateDomainService, "loadROHierarchyHelper", loadROHierarchyHelper);
        ReflectionTestUtils.setField(
                loadROUpdateDomainService, "updateROProductsHelper", productUpdateHelper);
    }

    @ParameterizedTest()
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void when_onCommand_UpdateHierarchy_ProcessLoadHierarchy(
            BaseEvent<UiHeader> event, LoadROData loadROData) throws IOException {
        event.getEventHeader()
                .getEventContext()
                .put(OrganisationConstants.GenericConstants.MODE, "update");
        LoadROData loadROData1 =
                LoadROData.builder()
                        .eventHeaders(event.getEventHeader())
                        .eventErrors(event.getEventErrors())
                        .audit(new BaseAudit())
                        .build();
        when(loadROHierarchyHelper.getOperationMode(event.getEventHeader())).thenReturn("update");
        loadROUpdateDomainService.onCommand(loadROData1);
        verify(loadROHierarchyHelper, times(1)).onHierarchyUpdateCommand(loadROData1);
    }

    @ParameterizedTest()
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void when_onCommand_UpdateProduct_ProcessLoadHierarchy(
            BaseEvent<UiHeader> event, LoadROData loadROData) throws IOException {
        when(loadROHierarchyHelper.getOperationMode(event.getEventHeader()))
                .thenReturn("updateProducts");
        loadROUpdateDomainService.onCommand(loadROData);

        verify(productUpdateHelper, times(1)).onRecognisedProductsUpdate(loadROData);
    }
    /*
     * This is method source to provide arguments for the required test cases
     * wherever this method source has been used. It's specific to LoadROData event
     */
    private static Stream<Arguments> argumentsProviderForOrganisationLoadDataEvent()
            throws JsonProcessingException {

        UiHeader roHeaders = OrganisationTestUtil.generateEventHeader();
        roHeaders.setEventName(
                OrganisationConstants.GenericConstants.OPERATION_TYPE_GET
                        + OrganisationConstants.GenericConstants.LOAD_RO_DATA_RESOURCE_TYPE);
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put(OrganisationConstants.GenericConstants.RO_DATA_FILE, "test.csv");
        eventContext.put(OrganisationConstants.GenericConstants.MODE, "updateProduct");
        eventContext.put(
                OrganisationConstants.GenericConstants.LOAD_ORGANISATION_TYPE,
                OrganisationConstants.GenericConstants.RECOGNISING_ORGANISATION);
        roHeaders.setEventContext(eventContext);
        BaseAudit audit = new BaseAudit();
        final BaseEvent<UiHeader> event = new BaseEvent<UiHeader>(roHeaders, null, null, audit);
        LoadROData loadROData =
                LoadROData.builder()
                        .eventHeaders(event.getEventHeader())
                        .eventErrors(event.getEventErrors())
                        .audit(audit)
                        .build();
        return Stream.of(Arguments.of(event, loadROData));
    }
}
