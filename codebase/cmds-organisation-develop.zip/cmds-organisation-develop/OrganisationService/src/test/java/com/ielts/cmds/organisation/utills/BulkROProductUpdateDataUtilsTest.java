package com.ielts.cmds.organisation.utills;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doReturn;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.organisation.cache.JedisGenericReader;
import com.ielts.cmds.organisation.domain.commands.UpdateROVO;
import com.ielts.cmds.organisation.domain.model.BulkRORecognisedProductsUpdateDataV1;
import com.ielts.cmds.organisation.domain.model.RoDataUpdateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.ProductRepository;
import com.ielts.cmds.organisation.utils.BulkROProductsUpdateDataUtils;
import com.ielts.cmds.organisation.utils.LoadROHierarchyDataUtils;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
class BulkROProductUpdateDataUtilsTest {

    @InjectMocks BulkROProductsUpdateDataUtils productUpdateDataUtils;

    @Spy private LoadROHierarchyDataUtils loadROHierarchyDataUtils;

    @Spy private OrganisationCommonUtils organisationCommonUtils;

    @Mock private JedisGenericReader jedisGenericReader;


    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(
                loadROHierarchyDataUtils, "organisationCommonUtils", organisationCommonUtils);
        ReflectionTestUtils.setField(
                organisationCommonUtils, "jedisGenericReader", jedisGenericReader);
    }

    @ParameterizedTest
    @MethodSource("provideArgumentsForLoadROProductUpdateDataUtils")
    void loadData_ExpectValue(
            RecognisingOrganisation organisation, BulkRORecognisedProductsUpdateDataV1 record)
            throws JSONException, JsonProcessingException {
        doReturn(CreateOrganisationDataSetup.getproductDataWithCharacteristics())
                .when(jedisGenericReader)
                .retrieveAllBookableProductsDataFromRedisCache();
        RoDataUpdateV1Valid actual = productUpdateDataUtils.updateProductData(organisation);
        assertNotNull(actual);
    }

    @ParameterizedTest
    @MethodSource("provideArgumentsForLoadROProductUpdateDataUtils")
    void loadDataWithIOLFlagFalse_ExpectValue(
            RecognisingOrganisation organisation, BulkRORecognisedProductsUpdateDataV1 record)
            throws JSONException, JsonProcessingException {
        organisation.setRecognisedProducts(
                CreateOrganisationDataSetup.populateRecognisedProducts(false, true, organisation));
        doReturn(CreateOrganisationDataSetup.getproductDataWithCharacteristics())
                .when(jedisGenericReader)
                .retrieveAllBookableProductsDataFromRedisCache();
        RoDataUpdateV1Valid actual = productUpdateDataUtils.updateProductData(organisation);
        assertNotNull(actual);
        assertFalse(actual.getAcceptsIOL());
        assertTrue(actual.getAcceptsSSR());
    }

    @ParameterizedTest
    @MethodSource("provideArgumentsForLoadROProductUpdateDataUtils")
    void loadDataWithIOLFlagTrue_acceptsSSRFalse_ExpectValue(
            RecognisingOrganisation organisation, BulkRORecognisedProductsUpdateDataV1 record)
            throws JSONException, JsonProcessingException {
        organisation.setRecognisedProducts(
                CreateOrganisationDataSetup.populateRecognisedProducts(true, true, organisation));
        doReturn(CreateOrganisationDataSetup.getproductDataWithCharacteristics())
                .when(jedisGenericReader)
                .retrieveAllBookableProductsDataFromRedisCache();
        RoDataUpdateV1Valid actual = productUpdateDataUtils.updateProductData(organisation);
        assertNotNull(actual);
        assertTrue(actual.getAcceptsIOL());
        assertTrue(actual.getAcceptsSSR());
    }

    private static Stream<Arguments> provideArgumentsForLoadROProductUpdateDataUtils() {
        RoDataUpdateV1Valid roData = UpdateOrganisationDataSetup.updateOrgData();
        final UpdateROVO updateROVO = UpdateROVO.builder().eventBody(roData).build();
        RecognisingOrganisation publishRo =
                UpdateOrganisationDataSetup.getExistingOrganisationDetails(
                        updateROVO.getEventBody(), new RecognisingOrganisation());
        return Stream.of(
                Arguments.of(
                        publishRo,
                        BulkROProductUpdateDataSetup.getLoadROProductUpdateDataV1List().get(0)));
    }
}
