package com.ielts.cmds.organisation.domain.services;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.common.out.event.RoDetailsDataGeneratedEventV1;
import com.ielts.cmds.organisation.domain.commands.CreateROVO;
import com.ielts.cmds.organisation.domain.model.RoDataCreateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.utills.CreateOrganisationDataSetup;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.outbox.event.OutboxEventBuilder;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.api.service.impl.RBACServiceImpl;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Stream;
import javax.validation.ConstraintViolation;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
class SearchByOrgIdDomainServiceTest {

    @InjectMocks @Spy SearchByOrgIdDomainService searchByOrgIdDomainService;

    @Mock private ObjectMapper objectMapper;

    @Spy private OrganisationCommonUtils organisationCommonUtils;

    @Mock private ApplicationEventPublisher applicationEventPublisher;

    @Mock private RBACServiceImpl rbacServiceImpl;

    @Mock private CMDSErrorResolver<Object> errorResolver;

    @Captor private ArgumentCaptor<BaseHeader> headerCaptor;

    @Captor private ArgumentCaptor<Set<ConstraintViolation<Object>>> violationSetCapt;

    @Captor private ArgumentCaptor<BaseEvent<BaseHeader>> roRequestedEventCaptor;

    @Mock private OutboxEventBuilder outboxEventBuilder;

    @Mock private RecognisingOrganisationRepository organisationRepository;

    @BeforeEach
    void setup() throws IOException  {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(
                searchByOrgIdDomainService, "rbacServiceImpl", rbacServiceImpl);
        ReflectionTestUtils.setField(
                searchByOrgIdDomainService, "organisationCommonUtils", organisationCommonUtils);
        ReflectionTestUtils.setField(
                searchByOrgIdDomainService, "rbacServiceImpl", rbacServiceImpl);
        ReflectionTestUtils.setField(
                organisationCommonUtils, "applicationEventPublisher", applicationEventPublisher);
        ReflectionTestUtils.setField(organisationCommonUtils, "objectMapper", objectMapper);
        ReflectionTestUtils.setField(organisationCommonUtils, "outboxEventBuilder", outboxEventBuilder);
        ReflectionTestUtils.setField(organisationCommonUtils, "orgRepository", organisationRepository);
        CMDSHeaderContext header = OrganisationTestUtil
                .generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_SEARCH_BY_ORG_ID_REQUEST_EVENT);
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put("organisationUuid", "161645");
        header.setEventContext(eventContext);
        ThreadLocalHeaderContext.setContext(header);
        String authorisedAccessToken = OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessToken);
        ThreadLocalAuditContext.setContext(OrganisationTestUtil.getBaseAudit());
    }

    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchOrgByIdCommand")
    void whenReceivedValid_SearchByOrgIdCommand_thenNoException(
            final RecognisingOrganisation recognisingOrganisation)
            throws JsonProcessingException, RbacValidationException {
        BaseHeader header = organisationCommonUtils
                .buildUiHeader();
        BaseAudit audit = organisationCommonUtils.getBaseAudit();
        Set<RecognisingOrganisation> roList = new HashSet<>();
        roList.add(recognisingOrganisation);
        doReturn(true)
                .when(rbacServiceImpl)
                .isAuthorised(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION);
        doNothing()
                .when(organisationCommonUtils)
                .publishForRODetailsDataGenerated(
                        header, roList, audit);

        doReturn(Optional.of(recognisingOrganisation))
                .when(organisationCommonUtils)
                .getOrganisationByOrgId(161645);

        Executable executable = () -> searchByOrgIdDomainService.onCommand(161645);
        assertDoesNotThrow(executable);
        verify(organisationCommonUtils)
                .publishForRODetailsDataGenerated(
                        header, roList, audit);

    }

    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchOrgByIdCommand")
    void whenReceivedValid_SearchOrgByIdCommand_thenVerifyPublishEvent(
            final RecognisingOrganisation recognisingOrganisation,
            final RoDetailsDataGeneratedEventV1 roDetails)
            throws JsonProcessingException, RbacValidationException {
        Set<RecognisingOrganisation> roList = new HashSet<>();
        BaseHeader header = organisationCommonUtils
                .buildUiHeader();
        BaseAudit audit = organisationCommonUtils.getBaseAudit();
        roList.add(recognisingOrganisation);
        doReturn(true)
                .when(rbacServiceImpl)
                .isAuthorised(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION);

        doReturn(header).when(organisationCommonUtils).buildUiHeader();
        String expectedEventBodyString = new ObjectMapper().writeValueAsString(roDetails);
        doReturn(roDetails)
                .when(organisationCommonUtils)
                .entityToEventMapperForOrgDetailsDataGenerated(roList);
        doReturn(Optional.of(recognisingOrganisation))
                .when(organisationCommonUtils)
                .getOrganisationByOrgId(161645);
        doReturn(expectedEventBodyString).when(objectMapper).writeValueAsString(roDetails);
        searchByOrgIdDomainService.onCommand(161645);
        verify(applicationEventPublisher).publishEvent(roRequestedEventCaptor.capture());
        assertNull(roRequestedEventCaptor.getValue().getEventErrors());
        assertEquals(expectedEventBodyString, roRequestedEventCaptor.getValue().getEventBody());
        assertEquals(
                OrganisationConstants.EventType.RO_DETAILS_DATA_GENERATED_EVENT,
                roRequestedEventCaptor.getValue().getEventHeader().getEventName());

    }

    @DisplayName("Valid Command No Permission - Expect Reject Event")
    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchOrgByIdCommand")
    void whenReceivedValid_SearchOrgByIdCommand_thenExpectRejectEventToBePublished(
            final RecognisingOrganisation recognisingOrganisation,
            final RoDetailsDataGeneratedEventV1 roDetails)
            throws Exception {
        BaseHeader header = organisationCommonUtils
                .buildUiHeader();
        BaseAudit audit = organisationCommonUtils.getBaseAudit();
        Set<RecognisingOrganisation> roList = new HashSet<>();
        roList.add(recognisingOrganisation);
        doReturn(false)
                .when(rbacServiceImpl)
                .isAuthorised(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION);
        Set<ConstraintViolation<Object>> violationSet =
                OrganisationTestUtil.getSetforNullViolationOfEventBody(
                        "V0044", "UnauthorisedToViewOrganisation");
        doReturn(violationSet)
                .when(organisationCommonUtils)
                .getSetforNullViolationOfEventBody("V0044", "UnauthorisedToViewOrganisation");

        Executable executable = () -> searchByOrgIdDomainService.onCommand(161645);
        assertDoesNotThrow(executable);
        verify(organisationCommonUtils)
                .getSetforNullViolationOfEventBody("V0044", "UnauthorisedToViewOrganisation");
        verify(organisationCommonUtils)
                .generateRejectedEventResponse(
                        headerCaptor.capture(),
                        violationSetCapt.capture(),
                        eq(audit),
                        eq(null));
        verify(organisationCommonUtils, never())
                .publishForRODetailsDataGenerated(
                        header, roList, audit);

    }

    @DisplayName("Valid Command OrganisationNotFound - Expect Empty Event")
    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchOrgByIdCommand")
    void whenReceivedValid_SearchOrgByIdCommand_thenExpectNotFound_EmptyEventToBePublished(
            final RecognisingOrganisation recognisingOrganisation)
            throws RbacValidationException {
        BaseHeader header = organisationCommonUtils
                .buildUiHeader();
        BaseAudit audit = organisationCommonUtils.getBaseAudit();
        doReturn(true)
                .when(rbacServiceImpl)
                .isAuthorised(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION);
        doReturn(header).when(organisationCommonUtils).buildUiHeader();
        Optional<RecognisingOrganisation> organisationDetails = Optional.empty();
        when(organisationRepository.findByOrganisationId(Integer.valueOf("161645"))).thenReturn(organisationDetails);
        Executable executable = () -> searchByOrgIdDomainService.onCommand(161645);
        assertDoesNotThrow(executable);
        verify(applicationEventPublisher).publishEvent(roRequestedEventCaptor.capture());
    }

    private static Stream<Arguments> provideArgumentsForSearchOrgByIdCommand() {

        final RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        UiHeader roHeaders = OrganisationTestUtil.generateEventHeader();
        BaseEvent<BaseHeader> event = new BaseEvent<>(roHeaders, null, null, null);

        CreateROVO createRo =
                CreateROVO.builder()
                        .eventHeaders(event.getEventHeader())
                        .eventBody(roDataCreateV1)
                        .eventErrors(event.getEventErrors())
                        .build();
        Set<RecognisingOrganisation> recognisingOrganisationList = new HashSet<>();
        RecognisingOrganisation recognisingOrganisation =
                CreateOrganisationDataSetup.populateOrganisation(
                        createRo.getEventBody(), new RecognisingOrganisation());
        recognisingOrganisation.setRecognisingOrganisationUuid(
                UUID.fromString("d4f0b3f0-64c5-4168-ae92-b244b4f103a4"));
        recognisingOrganisation.setName("A.T. Still University Arizona");
        recognisingOrganisationList.add(recognisingOrganisation);
        RoDetailsDataGeneratedEventV1 roDetails =
                CreateOrganisationDataSetup.entityToEventMapperForSearchByOrgId(
                        recognisingOrganisationList);

        return Stream.of(Arguments.of(recognisingOrganisation, roDetails));
    }
}
