package com.ielts.cmds.organisation.domain.services;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.organisation.domain.commands.CreateROVO;
import com.ielts.cmds.organisation.domain.commands.LoadROData;
import com.ielts.cmds.organisation.domain.model.LoadRODataV1;
import com.ielts.cmds.organisation.domain.model.LoadROMessageV1;
import com.ielts.cmds.organisation.domain.model.LoadRORecordEvent;
import com.ielts.cmds.organisation.domain.model.RoDataCreateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.utills.CreateOrganisationDataSetup;
import com.ielts.cmds.organisation.utills.LoadRODataSetup;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utils.LoadROEventMapper;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
class LoadRODomainServiceTest {

    @InjectMocks private LoadRODomainService loadRODomainService;

    @Mock private CsvMapper csvMapper;

    @Mock private AmazonS3 s3Client;

    @Mock private ProcessRODomainService processRODomainService;

    @Mock private ApplicationEventPublisher applicationEventPublisher;

    @Mock private LoadROEventMapper loadROEventMapper;

    @Mock private ObjectMapper objectMapper;

    @Mock private S3Object s3Object;

    @Mock private CsvSchema csvSchema;

    @Mock private ObjectReader objectReader;

    @Mock private MappingIterator<LoadRODataV1> mappingIterator;

    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(loadRODomainService, "roBucketName", "test-bucket");
        ReflectionTestUtils.setField(loadRODomainService, "processCount", "100");
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void when_OnCommand_ExpectNoException(
            final LoadROData loadROData,
            final S3ObjectInputStream s3ObjectInputStream,
            final List<LoadRODataV1> loadRODataV1List,
            final Map<String, LoadRORecordEvent> eventsMap,
            final LoadROMessageV1 loadROMessageV1)
            throws IOException {
        doReturn(s3Object).when(s3Client).getObject("test-bucket", "test.csv");
        doReturn(s3ObjectInputStream).when(s3Object).getObjectContent();
        doReturn(csvSchema).when(csvMapper).schema();
        doReturn(csvSchema).when(csvSchema).withHeader();
        doReturn(csvSchema).when(csvSchema).withColumnSeparator(',');
        doReturn(objectReader).when(csvMapper).readerFor(LoadRODataV1.class);
        doReturn(objectReader).when(objectReader).with(csvSchema);
        doReturn(mappingIterator).when(objectReader).readValues(any(BufferedReader.class));

        doReturn(loadRODataV1List).when(mappingIterator).readAll();
        doReturn(eventsMap.get("1").getEvent())
                .when(processRODomainService)
                .processRecord(loadROData, loadRODataV1List.get(0));

        doReturn(loadROMessageV1).when(loadROEventMapper).mapToEvent(eventsMap);
        doNothing().when(applicationEventPublisher).publishEvent(any(BaseEvent.class));
        doReturn(new ObjectMapper().writeValueAsString(loadROMessageV1))
                .when(objectMapper)
                .writeValueAsString(loadROMessageV1);
        assertDoesNotThrow(() -> loadRODomainService.onCommand(loadROData));
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void when_ProcessCompletes_ExpectNoException(
            final LoadROData loadROData,
            final S3ObjectInputStream s3ObjectInputStream,
            final List<LoadRODataV1> loadRODataV1List,
            final Map<String, LoadRORecordEvent> eventsMap,
            final LoadROMessageV1 loadROMessageV1)
            throws IOException {
        loadROData
                .getEventHeaders()
                .getEventContext()
                .put("start", String.valueOf(loadRODataV1List.size() + 1));
        doReturn(s3Object).when(s3Client).getObject("test-bucket", "test.csv");
        doReturn(s3ObjectInputStream).when(s3Object).getObjectContent();
        doReturn(csvSchema).when(csvMapper).schema();
        doReturn(csvSchema).when(csvSchema).withHeader();
        doReturn(csvSchema).when(csvSchema).withColumnSeparator(',');
        doReturn(objectReader).when(csvMapper).readerFor(LoadRODataV1.class);
        doReturn(objectReader).when(objectReader).with(csvSchema);
        doReturn(mappingIterator).when(objectReader).readValues(any(BufferedReader.class));

        doReturn(loadRODataV1List).when(mappingIterator).readAll();
        assertDoesNotThrow(() -> loadRODomainService.onCommand(loadROData));
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void when_OnCommand_Exception_ExpectNoException(
            final LoadROData loadROData,
            final S3ObjectInputStream s3ObjectInputStream,
            final List<LoadRODataV1> loadRODataV1List,
            final Map<String, LoadRORecordEvent> eventsMap,
            final LoadROMessageV1 loadROMessageV1)
            throws IOException {

        doReturn(s3Object).when(s3Client).getObject("test-bucket", "test.csv");
        doReturn(s3ObjectInputStream).when(s3Object).getObjectContent();
        doReturn(csvSchema).when(csvMapper).schema();
        doReturn(csvSchema).when(csvSchema).withHeader();
        doReturn(csvSchema).when(csvSchema).withColumnSeparator(',');
        doReturn(objectReader).when(csvMapper).readerFor(LoadRODataV1.class);
        doReturn(objectReader).when(objectReader).with(csvSchema);
        doReturn(mappingIterator).when(objectReader).readValues(any(BufferedReader.class));

        doReturn(loadRODataV1List).when(mappingIterator).readAll();

        doThrow(new RuntimeException("Invalid data"))
                .when(processRODomainService)
                .processRecord(loadROData, loadRODataV1List.get(0));

        assertDoesNotThrow(() -> loadRODomainService.onCommand(loadROData));
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void when_OnCommand_ExpectIllegalArgumentException(
            final LoadROData loadROData,
            final S3ObjectInputStream s3ObjectInputStream,
            final List<LoadRODataV1> loadRODataV1List,
            final Map<String, LoadRORecordEvent> eventsMap,
            final LoadROMessageV1 loadROMessageV1)
            throws IOException {
        loadROData.getEventHeaders().setEventContext(null);
        assertThrows(
                IllegalArgumentException.class, () -> loadRODomainService.onCommand(loadROData));
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void when_OnCommand_FileNotPresent_ExpectIllegalArgumentException(
            final LoadROData loadROData,
            final S3ObjectInputStream s3ObjectInputStream,
            final List<LoadRODataV1> loadRODataV1List,
            final Map<String, LoadRORecordEvent> eventsMap,
            final LoadROMessageV1 loadROMessageV1)
            throws IOException {
        loadROData.getEventHeaders().getEventContext().clear();
        assertThrows(
                IllegalArgumentException.class, () -> loadRODomainService.onCommand(loadROData));
    }

    private static Stream<Arguments> argumentsProviderForOrganisationLoadDataEvent()
            throws JsonProcessingException {

        InputStream inputStream = IOUtils.toInputStream("a,b,c", Charset.defaultCharset());
        S3ObjectInputStream s3ObjectInputStream = new S3ObjectInputStream(inputStream, null);

        UiHeader roHeaders = OrganisationTestUtil.generateEventHeader();
        roHeaders.setEventName(
                OrganisationConstants.GenericConstants.OPERATION_TYPE_GET
                        + OrganisationConstants.GenericConstants.LOAD_RO_DATA_RESOURCE_TYPE);
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put(OrganisationConstants.GenericConstants.RO_DATA_FILE, "test.csv");
        eventContext.put(
                OrganisationConstants.GenericConstants.LOAD_ORGANISATION_TYPE,
                OrganisationConstants.GenericConstants.RECOGNISING_ORGANISATION);
        eventContext.put(OrganisationConstants.GenericConstants.MODE, "create");
        roHeaders.setEventContext(eventContext);

        final BaseEvent<UiHeader> event = new BaseEvent<UiHeader>(roHeaders, null, null, null);
        LoadROData loadROData =
                LoadROData.builder()
                        .eventHeaders(event.getEventHeader())
                        .eventErrors(event.getEventErrors())
                        .build();
        List<LoadRODataV1> loadRODataV1List = LoadRODataSetup.getLoadRODataV1List();

        LoadROMessageV1 loadROMessageV1 =
                LoadRODataSetup.getLoadROMessageV1(loadRODataV1List.get(0));
        RoDataCreateV1Valid roData = CreateOrganisationDataSetup.createOrgData();
        final CreateROVO createROVO = CreateROVO.builder().eventBody(roData).build();
        RecognisingOrganisation publishRo =
                CreateOrganisationDataSetup.populateOrganisation(
                        createROVO.getEventBody(), new RecognisingOrganisation());
        Map<String, LoadRORecordEvent> eventsMap =
                LoadRODataSetup.getEventsMap(
                        LoadRODataSetup.getROCreatedEvent(publishRo), loadRODataV1List.get(0));
        return Stream.of(
                Arguments.of(
                        loadROData,
                        s3ObjectInputStream,
                        loadRODataV1List,
                        eventsMap,
                        loadROMessageV1));
    }
}
