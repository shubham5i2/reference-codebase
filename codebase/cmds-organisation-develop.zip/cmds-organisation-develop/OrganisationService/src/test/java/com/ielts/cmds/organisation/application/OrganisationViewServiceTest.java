package com.ielts.cmds.organisation.application;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.roui008rodetailsrequested.RODetailsRequestParams;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.domain.services.ViewOrganisationDomainService;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utils.OrganisationConstants;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static org.mockito.Mockito.times;

@ExtendWith(MockitoExtension.class)
class OrganisationViewServiceTest {

  @InjectMocks private OrganisationViewService orgViewApplicationService;

  @Mock private ViewOrganisationDomainService viewOrgDomainService;

  @Mock private ObjectMapper objectMapper;
  @BeforeEach
  void init() {
    ThreadLocalHeaderContext.setContext(OrganisationTestUtil
            .generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_DETAILS_REQUEST_EVENT));

    ThreadLocalAuditContext.setContext(OrganisationTestUtil.getBaseAudit());
  }
  @Test
  void whenValidPayload_thenVerifyDomainCallWithNoException() throws Exception {

    UiHeader roHeaders = OrganisationTestUtil.generateEventHeader();
    roHeaders.setEventName(OrganisationConstants.GenericConstants.RO_DETAILS_REQUEST_EVENT);
    Map<String, String> eventContext = new HashMap<>();
    eventContext.put("recognisingOrganisationUuid", "cef4fcb1-2bd2-51f3-889d-abd47d775634");
    roHeaders.setEventContext(eventContext);
    RODetailsRequestParams eventBody = new RODetailsRequestParams();
    eventBody.setRecognisingOrganisationUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775634"));
    orgViewApplicationService.process(eventBody);
    verify(viewOrgDomainService, times(1)).onCommand("cef4fcb1-2bd2-51f3-889d-abd47d775634");
    assertNotNull(
            roHeaders.getEventContext().get("recognisingOrganisationUuid"));
    assertEquals(
        "cef4fcb1-2bd2-51f3-889d-abd47d775634",
            roHeaders.getEventContext().get("recognisingOrganisationUuid"));
   }

  @Test
  void whenInValidPayload_thenVerifyForException() throws Exception {
    UiHeader roHeaders = OrganisationTestUtil.generateEventHeader();
    roHeaders.setEventName(OrganisationConstants.GenericConstants.RO_DETAILS_REQUEST_EVENT);
    RODetailsRequestParams eventBody = new RODetailsRequestParams();
    eventBody.setRecognisingOrganisationUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775634"));

    doThrow(RuntimeException.class).when(viewOrgDomainService).onCommand("cef4fcb1-2bd2-51f3-889d-abd47d775634");
    Executable executable = () -> orgViewApplicationService.process(eventBody);
    ProcessingException processingException = assertThrows(ProcessingException.class, executable);
    assertTrue(processingException.getCause() instanceof RuntimeException);
  }

    @Test
    void whenValidPayload_thenNoException() throws Exception {
        UiHeader roHeaders = OrganisationTestUtil.generateEventHeader();
        roHeaders.setEventName(OrganisationConstants.GenericConstants.RO_DETAILS_REQUEST_EVENT);
      RODetailsRequestParams eventBody = new RODetailsRequestParams();
      eventBody.setRecognisingOrganisationUuid(UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775634"));
        orgViewApplicationService.process(eventBody);
        verify(viewOrgDomainService).onCommand("cef4fcb1-2bd2-51f3-889d-abd47d775634");
    }

}
