package com.ielts.cmds.organisation.utills;

import static com.ielts.cmds.organisation.utils.OrganisationConstants.GenericConstants.RO_DATA_FILE;

import com.amazonaws.services.sns.model.MessageAttributeValue;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.infrastructure.event.context.CMDSAuditContext;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import javax.validation.ConstraintViolation;
import javax.validation.Path;
import javax.validation.metadata.ConstraintDescriptor;
import org.apache.commons.lang.StringUtils;
import org.hibernate.validator.internal.engine.ConstraintViolationImpl;
import org.hibernate.validator.internal.engine.path.PathImpl;

public class OrganisationTestUtil {

    public static final String ACCESS_TOKEN_FILE_PATH = "src/test/resources/access-tokens/";

    public static UiHeader generateEventHeader() {
        UiHeader eventHeader = new UiHeader();
        eventHeader.setConnectionId("ec81310d-03b6-");
        eventHeader.setCorrelationId(UUID.fromString("413b7690-990f-42ce-ab76-783af084513a"));
        eventHeader.setEventDateTime(null);
        eventHeader.setEventDateTime(LocalDateTime.of(2023, 06, 24, 02, 45));
        eventHeader.setTransactionId(UUID.fromString("13009c19-5bef-4bf3-871e-fd08748e0339"));
        eventHeader.setXaccessToken("");
        eventHeader.setEventName("RoCreateRequest");
        Map<String, String> eventContext = new HashMap<String, String>();
        eventContext.put("recognisingOrganisationUuid", "88e18cae-1bdd-45a7-be1c-0a37926f9bbe");
        eventHeader.setEventContext(eventContext);

        return eventHeader;
    }

    public static CMDSHeaderContext generateBuildHeaderContext(final String eventName) {
        final CMDSHeaderContext headerContext = new CMDSHeaderContext();
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put(OrganisationConstants.GenericConstants.REQ_PARAM_INCLUDE_INACTIVE, "false");
        eventContext.put("recognisingOrganisationUuid", "88e18cae-1bdd-45a7-be1c-0a37926f9bbe");
        headerContext.setEventContext(eventContext);
        headerContext.setXaccessToken("token");
        headerContext.setEventDateTime(LocalDateTime.of(2023, 7, 3, 13, 5, 3));
        headerContext.setEventName(eventName);
        headerContext.setPartnerCode("BC");
        headerContext.setCorrelationId(UUID.fromString("413b7690-990f-42ce-ab76-783af084513a"));
        headerContext.setTransactionId(UUID.fromString("13009c19-5bef-4bf3-871e-fd08748e0339"));
        return headerContext;
    }
    public static CMDSHeaderContext generateBuildHeaderContextWithIncludeAsActive(final String eventName) {
        final CMDSHeaderContext headerContext = new CMDSHeaderContext();
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put(OrganisationConstants.GenericConstants.REQ_PARAM_INCLUDE_INACTIVE, "true");
        headerContext.setEventContext(eventContext);
        headerContext.setXaccessToken("token");
        headerContext.setEventDateTime(LocalDateTime.of(2023, 7, 3, 13, 5, 3));
        headerContext.setEventName(eventName);
        headerContext.setPartnerCode("BC");
        headerContext.setCorrelationId(UUID.randomUUID());
        headerContext.setTransactionId(UUID.randomUUID());
        return headerContext;
    }
    public static CMDSAuditContext getBaseAudit() {
        final CMDSAuditContext auditContext = new CMDSAuditContext();
        auditContext.setCausedByCorrelationId(UUID.fromString("e873fca7-849b-4e3b-8dfc-b6b5108608db"));
        auditContext.setCausedByTransactionId(UUID.fromString("e873fca7-849b-4e3b-8dfc-b6b5108608db"));
        auditContext.setPrincipalId("principal_Id");
        auditContext.setPrincipalName("principal_name");
        auditContext.setPermission("true");
        auditContext.setCausedByEventDateTime(LocalDateTime.of(2023, 7, 3, 13, 5, 3, 891));
        auditContext.setCausedByEventName("event_name");
        ThreadLocalAuditContext.setContext(auditContext);
        return ThreadLocalAuditContext.getContext();
    }

    public static Set<ConstraintViolation<BaseEvent<UiHeader>>> getSetforNullViolationOfHeaders(
            final String... interpolatedMessages) {

        Set<ConstraintViolation<BaseEvent<UiHeader>>> violationSet = new HashSet<>();
        for (final String interpolatedMessage : interpolatedMessages) {
            final String messageTemplate = null;
            final String interpolatedHeaderMessage = interpolatedMessage;
            final Class<BaseEvent<UiHeader>> rootBeanClass = null;
            final BaseEvent<UiHeader> rootBean = null;
            final BaseEvent<UiHeader> leafBeanInstance = null;
            final BaseEvent<UiHeader> value = null;
            final Path propertyPath = null;
            final ConstraintDescriptor<?> constraintDescriptor = null;
            final Map<String, Object> messageParameters = new HashMap<>();
            final Map<String, Object> expressionVariables = new HashMap<>();
            ConstraintViolation<BaseEvent<UiHeader>> constraintViolationImpl1 =
                    (ConstraintViolationImpl<BaseEvent<UiHeader>>)
                            ConstraintViolationImpl.forBeanValidation(
                                    messageTemplate,
                                    messageParameters,
                                    expressionVariables,
                                    interpolatedHeaderMessage,
                                    rootBeanClass,
                                    rootBean,
                                    leafBeanInstance,
                                    value,
                                    propertyPath,
                                    constraintDescriptor,
                                    null);
            violationSet.add(constraintViolationImpl1);
        }

        return violationSet;
    }

    public static Set<ConstraintViolation<BaseEvent<BaseHeader>>>
            getSetforNullViolationOfHeadersBaseHeader(final String... interpolatedMessages) {

        Set<ConstraintViolation<BaseEvent<BaseHeader>>> violationSet = new HashSet<>();
        for (final String interpolatedMessage : interpolatedMessages) {
            final String messageTemplate = null;
            final String interpolatedHeaderMessage = interpolatedMessage;
            final Class<BaseEvent<BaseHeader>> rootBeanClass = null;
            final BaseEvent<BaseHeader> rootBean = null;
            final BaseEvent<BaseHeader> leafBeanInstance = null;
            final BaseEvent<BaseHeader> value = null;
            final Path propertyPath = null;
            final ConstraintDescriptor<?> constraintDescriptor = null;
            final Map<String, Object> messageParameters = new HashMap<>();
            final Map<String, Object> expressionVariables = new HashMap<>();
            ConstraintViolation<BaseEvent<BaseHeader>> constraintViolationImpl1 =
                    (ConstraintViolationImpl<BaseEvent<BaseHeader>>)
                            ConstraintViolationImpl.forBeanValidation(
                                    messageTemplate,
                                    messageParameters,
                                    expressionVariables,
                                    interpolatedHeaderMessage,
                                    rootBeanClass,
                                    rootBean,
                                    leafBeanInstance,
                                    value,
                                    propertyPath,
                                    constraintDescriptor,
                                    null);
            violationSet.add(constraintViolationImpl1);
        }

        return violationSet;
    }

    public static CMDSErrorResponse getROErrorResponse(
            String errorCode, String message, String title) {

        ErrorDescription errorDescription1 = new ErrorDescription();
        errorDescription1.setInterfaceName("RO-Microservice");
        errorDescription1.setType(ErrorTypeEnum.ERROR);
        errorDescription1.setErrorCode(errorCode);
        errorDescription1.setMessage(message);
        errorDescription1.setTitle(OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT);
        errorDescription1.setErrorTicketUuid(UUID.randomUUID());
        Source source = Source.builder().path("").value("").build();
        errorDescription1.setSource(source);

        List<ErrorDescription> errorList = new ArrayList<>();
        errorList.add(errorDescription1);

        CMDSErrorResponse errResponse = CMDSErrorResponse.builder().errorList(errorList).build();
        return errResponse;
    }

    public static Set<ConstraintViolation<Object>> getSetforNullViolationOfEventBody(
            final String interpolatedMessage, String path) {

        Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
        final String messageTemplate = null;
        final String interpolatedHeaderMessage = interpolatedMessage;
        final Class<Object> rootBeanClass = null;
        final Object rootBean = null;
        final Object leafBeanInstance = null;
        final Object value = null;
        final Path propertyPath = PathImpl.createPathFromString(path);
        final ConstraintDescriptor<?> constraintDescriptor = null;
        final Map<String, Object> messageParameters = new HashMap<>();
        final Map<String, Object> expressionVariables = new HashMap<>();
        ConstraintViolation<Object> constraintViolationImpl1 =
                (ConstraintViolationImpl<Object>)
                        ConstraintViolationImpl.forBeanValidation(
                                messageTemplate,
                                messageParameters,
                                expressionVariables,
                                interpolatedHeaderMessage,
                                rootBeanClass,
                                rootBean,
                                leafBeanInstance,
                                value,
                                propertyPath,
                                constraintDescriptor,
                                null);

        violationSet.add(constraintViolationImpl1);
        return violationSet;
    }

    public static String getAccessToken(String filename) throws IOException {

        BufferedReader reader =
                new BufferedReader(new FileReader(ACCESS_TOKEN_FILE_PATH + filename));
        String accessToken = reader.readLine();
        reader.close();
        return accessToken;
    }

    public static Map<String, MessageAttributeValue> getMessageAttributes(
            final BaseHeader eventHeader) {
        final Map<String, MessageAttributeValue> messageAttributes = new HashMap<>();
        if (eventHeader instanceof UiHeader
                && StringUtils.isNotEmpty(((UiHeader) eventHeader).getConnectionId())) {
            messageAttributes.put(
                    OrganisationConstants.GenericConstants.CONNECTION_ID,
                    new MessageAttributeValue()
                            .withDataType(OrganisationConstants.GenericConstants.MSG_ATTR_DATA_TYPE)
                            .withStringValue(((UiHeader) eventHeader).getConnectionId()));
        }
        messageAttributes.put(
                OrganisationConstants.GenericConstants.EVENT_NAME,
                new MessageAttributeValue()
                        .withDataType(OrganisationConstants.GenericConstants.MSG_ATTR_DATA_TYPE)
                        .withStringValue(eventHeader.getEventName()));
        if (!StringUtils.isEmpty(eventHeader.getPartnerCode())) {
            messageAttributes.put(
                    OrganisationConstants.GenericConstants.PARTNER_CODE,
                    new MessageAttributeValue()
                            .withDataType(OrganisationConstants.GenericConstants.MSG_ATTR_DATA_TYPE)
                            .withStringValue(eventHeader.getPartnerCode()));
        }
        if (eventHeader.getEventDiscriminator() != null) {
            messageAttributes.put(
                    OrganisationConstants.GenericConstants.EVENT_DISCRIMINATOR,
                    new MessageAttributeValue()
                            .withDataType(OrganisationConstants.GenericConstants.MSG_ATTR_DATA_TYPE)
                            .withStringValue(eventHeader.getEventDiscriminator()));
        }
        if (eventHeader.getEventContext() != null
                && eventHeader.getEventContext().containsKey(RO_DATA_FILE)) {
            messageAttributes.put(
                    OrganisationConstants.GenericConstants.CSV_FILE,
                    new MessageAttributeValue()
                            .withDataType(OrganisationConstants.GenericConstants.MSG_ATTR_DATA_TYPE)
                            .withStringValue(eventHeader.getEventContext().get(RO_DATA_FILE)));
        }

        return messageAttributes;
    }

}
