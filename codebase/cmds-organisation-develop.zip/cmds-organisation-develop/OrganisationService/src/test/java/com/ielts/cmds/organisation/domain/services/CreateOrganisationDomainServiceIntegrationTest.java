
package com.ielts.cmds.organisation.domain.services;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.roui007rocreaterequested.VerificationStatusEnum;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.cache.JedisGenericReader;
import com.ielts.cmds.organisation.cache.factory.JedisFactory;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Addresses;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Contacts;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Notes;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1RecognisedProducts;

import com.ielts.cmds.organisation.domain.model.RoDataCreateV1Valid;
import com.ielts.cmds.organisation.infrastructure.config.RBACTestConfig;
import com.ielts.cmds.organisation.infrastructure.entity.Address;
import com.ielts.cmds.organisation.infrastructure.entity.Contact;
import com.ielts.cmds.organisation.infrastructure.entity.MinimumScore;
import com.ielts.cmds.organisation.cache.entity.Product;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.entity.RoNote;
import com.ielts.cmds.organisation.infrastructure.repository.LinkedRecognisingOrganisationRepository;
import com.ielts.cmds.organisation.infrastructure.repository.OrganisationTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.utills.CreateOrganisationDataSetup;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.rbac.api.service.RBACService;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.implementation.impl.LocationHierarchyServiceImpl;
import com.ielts.cmds.rbac.implementation.impl.UserGroupServiceImpl;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;
import javax.transaction.Transactional;

import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = RBACTestConfig.class)
@ActiveProfiles("test")
@Sql({
    "/sql/schema.sql",
    "/sql/organisation-type-data.sql",
    "/sql/partner-data.sql",
    "/sql/address-type-data.sql",
    "/sql/sector-type-data.sql",
    "/sql/product-data.sql",
    "/sql/note-type-data.sql",
    "/sql/contact-type-data.sql",
    "/sql/country-data.sql",
    "/sql/territory-data.sql",
    "/sql/module-type-data.sql",
    "/sql/usergroup-hierarchy.sql",
    "/sql/existing-ro-data.sql"
})
@Transactional
class CreateOrganisationDomainServiceIntegrationTest {

    @Autowired private RecognisingOrganisationRepository recognisingOrgRepository;

    @Spy private OrganisationCommonUtils organisationCommonUtils;

    @Autowired private CMDSThreadLocalContextService cmdsThreadLocalContextService;

    @MockBean private ApplicationEventPublisher applicationEventPublisher;

    @Autowired private CreateOrganisationDomainService createOrganisationDomainService;

    @Captor ArgumentCaptor<BaseEvent<BaseHeader>> publishedEventCaptor;

    @Autowired private LinkedRecognisingOrganisationRepository linkedRORepository;

    @Autowired private ObjectMapper objectMapper;
    @Autowired private RBACService rbacService;
    @Autowired private UserGroupServiceImpl userGroupServiceImpl;
    @Autowired private LocationHierarchyServiceImpl locationHierarchyServiceImpl;
    @Autowired private OrganisationTypeRepository organisationTypeRepository;
    @MockBean private JedisGenericReader jedisGenericReader;
    @MockBean private JedisFactory jedisFactory;

    @BeforeEach
    void setup() throws RbacValidationException {
        userGroupServiceImpl.populateUserGroupHierarchyData();
        locationHierarchyServiceImpl.populateRootData();
        ReflectionTestUtils.setField(
                createOrganisationDomainService,
                "applicationEventPublisher",
                applicationEventPublisher);
        ReflectionTestUtils.setField(organisationCommonUtils, "objectMapper", objectMapper);
        ReflectionTestUtils.setField(
                organisationCommonUtils, "orgRepository", recognisingOrgRepository);
        ReflectionTestUtils.setField(
                organisationCommonUtils,
                "linkedRecognisingOrganisationRepository",
                linkedRORepository);
        ReflectionTestUtils.setField(
                organisationCommonUtils, "organisationTypeRepository", organisationTypeRepository);
        ReflectionTestUtils.setField(
                organisationCommonUtils, "jedisGenericReader", jedisGenericReader);
        ThreadLocalHeaderContext.setContext(OrganisationTestUtil.generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_CREATE_REQUEST_EVENT));
        ThreadLocalAuditContext.setContext(OrganisationTestUtil.getBaseAudit());


    }

    @Test
    final void testSaveOrganisation() throws SQLException, IOException {

        String authorisedAccessTokenToCreate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToCreate);
        RoDataCreateV1Valid roDataCreate = CreateOrganisationDataSetup.createOrgData();
        roDataCreate.getContacts().get(0).getAddresses().get(0).setEmail("test@gmail.com");
        roDataCreate.getContacts().get(0).getAddresses().get(1).setEmail("test@gmail.com");

        roDataCreate
                .getContacts()
                .get(1)
                .getAddresses()
                .get(0)
                .setEmail("M'chris$tine.sharon-&ggr123@dha-fraschools.fe.com");
        roDataCreate
                .getContacts()
                .get(1)
                .getAddresses()
                .get(1)
                .setEmail("K'christ#ine.sharon-&rtd123@dha-fraschools.efe-grrfe.kkkk-ooo.com");
        roDataCreate.setAcceptsSSR(true);
        roDataCreate.setAcceptsAC(true);
        roDataCreate.setAcceptsGT(true);
        List<Product> products = CreateOrganisationDataSetup.getproductDataWithCharacteristics();
        when(jedisGenericReader.retrieveAllBookableProductsDataFromRedisCache()).thenReturn(products);
        createOrganisationDomainService.onCommand(roDataCreate);
        RecognisingOrganisation recognisingOrganisation =
                recognisingOrgRepository.findByName("McGill University");

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();

        RoChangedEventV1 roCreatedEvent =
                objectMapper.readValue(event.getEventBody(), RoChangedEventV1.class);
        /* Count Check */
        assertTrue(recognisingOrgRepository.count() > 0);

        /* Organisation Details Verified */
        assertAll(
                "Organisation",
                () ->
                        assertEquals(
                                recognisingOrganisation.getName(),
                                roDataCreate.getOrganisationName()),
                () ->
                        assertEquals(
                                recognisingOrganisation.getVerificationStatus(),
                                roDataCreate.getVerificationStatus()),
                () ->
                        assertEquals(
                                recognisingOrganisation.getPartnerCode(),
                                roDataCreate.getPartnerCode()),
                () ->
                        assertEquals(
                                recognisingOrganisation.getOrganisationCode(),
                                roDataCreate.getOrganisationCode()),
                () ->
                        assertEquals(
                                recognisingOrganisation.getResultAvailableForYears(),
                                roDataCreate.getResultAvailableForYears()));

        List<Address> savedAddresses = recognisingOrganisation.getAddresses();
        assertEquals(2, savedAddresses.stream().count());

        List<RoNote> savedNotes = recognisingOrganisation.getNotes();
        assertEquals(2, savedNotes.stream().count());

        List<Contact> savedContacts = recognisingOrganisation.getContacts();
        assertEquals(2, savedContacts.stream().count());

        List<MinimumScore> savedMinimumScores = recognisingOrganisation.getMinimumScores();
        assertEquals(2, savedMinimumScores.stream().count());

        /* Published Organisation Details Verified */
        assertAll(
                "RoCreated",
                () ->
                        assertEquals(
                                roCreatedEvent.getRecognisingOrganisationUuid(),
                                recognisingOrganisation.getRecognisingOrganisationUuid()),
                () ->
                        assertEquals(
                                roCreatedEvent.getOrganisationName(),
                                recognisingOrganisation.getName()),
                () ->
                        assertEquals(
                                roCreatedEvent.getOrganisationStatus(),
                                recognisingOrganisation.getOrgStatus()),
                () ->
                        assertEquals(
                                roCreatedEvent.getPartnerCode(),
                                recognisingOrganisation.getPartnerCode()),
                () ->
                        assertEquals(
                                roCreatedEvent.getMethodOfDelivery(),
                                recognisingOrganisation.getMethodOfDelivery()),
                () ->
                        assertEquals(
                                roCreatedEvent.getOrganisationCode(),
                                recognisingOrganisation.getOrganisationCode()));

        RoChangedEventV1Addresses publishedAddresses = roCreatedEvent.getAddresses();
        assertEquals(2, publishedAddresses.stream().count());

        RoChangedEventV1Notes publishedNotes = roCreatedEvent.getNotes();
        assertEquals(2, publishedNotes.stream().count());

        RoChangedEventV1Contacts publishedContacts = roCreatedEvent.getContacts();
        assertEquals(2, publishedContacts.stream().count());

        RoChangedEventV1RecognisedProducts publishedRecognisedProducts =
                roCreatedEvent.getRecognisedProducts();
        assertEquals(7, publishedRecognisedProducts.stream().count()); // 2-IOL, SSR-4, IOC-2
        assertNotNull(roCreatedEvent.getOrganisationId());
    }

    @Test
    final void testSaveOrganisationWithNonMandatoryFields() throws SQLException, IOException {

        String authorisedAccessTokenToCreate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToCreate);
        RoDataCreateV1Valid roDataCreate = CreateOrganisationDataSetup.createOrgData();
        roDataCreate.setLinkedOrganisations(null);
        roDataCreate.getContacts().get(0).getAddresses().get(0).setEmail("test@gmail.com");
        roDataCreate.getContacts().get(0).getAddresses().get(1).setEmail("test@gmail.com");
        roDataCreate.getContacts().get(1).getAddresses().get(0).setEmail("test@gmail.com");
        roDataCreate.getContacts().get(1).getAddresses().get(1).setEmail("test@gmail.com");
        roDataCreate.setPartnerContact("");
        roDataCreate.setNotes(null);
        roDataCreate.setAlternateNames(null);
        roDataCreate.setMinimumScores(null);
        roDataCreate.setLinkedOrganisations(null);
        createOrganisationDomainService.onCommand(roDataCreate);
        RecognisingOrganisation recognisingOrganisation =
                recognisingOrgRepository.findByName("McGill University");

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();

        RoChangedEventV1 roCreatedEvent =
                objectMapper.readValue(event.getEventBody(), RoChangedEventV1.class);
        /* Count Check */
        assertTrue(recognisingOrgRepository.count() > 0);

        /* Organisation Details Verified */
        assertAll(
                "Organisation",
                () ->
                        assertEquals(
                                recognisingOrganisation.getName(),
                                roDataCreate.getOrganisationName()),
                () ->
                        assertEquals(
                                recognisingOrganisation.getVerificationStatus(),
                                roDataCreate.getVerificationStatus()),
                () ->
                        assertEquals(
                                recognisingOrganisation.getPartnerCode(),
                                roDataCreate.getPartnerCode()),
                () ->
                        assertEquals(
                                recognisingOrganisation.getOrganisationCode(),
                                roDataCreate.getOrganisationCode()));

        List<Address> savedAddresses = recognisingOrganisation.getAddresses();
        assertEquals(2, savedAddresses.stream().count());

        List<RoNote> savedNotes = recognisingOrganisation.getNotes();
        assertTrue(savedNotes.isEmpty());

        List<Contact> savedContacts = recognisingOrganisation.getContacts();
        assertEquals(2, savedContacts.stream().count());

        List<MinimumScore> savedMinimumScores = recognisingOrganisation.getMinimumScores();
        assertTrue(savedMinimumScores.isEmpty());

        /* Published Organisation Details Verified */
        assertAll(
                "RoCreated",
                () ->
                        assertEquals(
                                roCreatedEvent.getRecognisingOrganisationUuid(),
                                recognisingOrganisation.getRecognisingOrganisationUuid()),
                () ->
                        assertEquals(
                                roCreatedEvent.getOrganisationName(),
                                recognisingOrganisation.getName()),
                () ->
                        assertEquals(
                                roCreatedEvent.getOrganisationStatus(),
                                recognisingOrganisation.getOrgStatus()),
                () ->
                        assertEquals(
                                roCreatedEvent.getPartnerCode(),
                                recognisingOrganisation.getPartnerCode()),
                () ->
                        assertEquals(
                                roCreatedEvent.getMethodOfDelivery(),
                                recognisingOrganisation.getMethodOfDelivery()),
                () ->
                        assertEquals(
                                roCreatedEvent.getOrganisationCode(),
                                recognisingOrganisation.getOrganisationCode()));

        RoChangedEventV1Addresses publishedAddresses = roCreatedEvent.getAddresses();
        assertEquals(2, publishedAddresses.stream().count());

        RoChangedEventV1Notes publishedNotes = roCreatedEvent.getNotes();
        assertEquals(0, publishedNotes.stream().count());
    }

    @Test
    void testUnauthorisedUserRejectedEvent() throws IOException, RbacValidationException {
        String authorisedAccessTokenToCreate =
                OrganisationTestUtil.getAccessToken("test-admin-support-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToCreate);
        RoDataCreateV1Valid roDataCreate = CreateOrganisationDataSetup.createOrgData();
        roDataCreate.setOrganisationTypeUuid(
                UUID.fromString("e392ae7c-016f-433a-bdfa-b79bfcdddf26"));
        createOrganisationDomainService.onCommand(roDataCreate);
        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        assertFalse(rbacService.isAuthorised(authorisedAccessTokenToCreate, "VO"));
        BaseHeader header = publishedEventCaptor.getValue().getEventHeader();
        assertEquals("RoRejected", header.getEventName());
    }

    @Test
    void testSaveOrganisationWithDuplicateOrgNameRejectedEvent() throws SQLException, IOException {

        String authorisedAccessTokenToCreate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToCreate);
        RoDataCreateV1Valid roDataCreate = CreateOrganisationDataSetup.createOrgData();
        roDataCreate.setPartnerContact("");
        roDataCreate.setNotes(null);
        roDataCreate.setAlternateNames(null);
        roDataCreate.setMinimumScores(null);
        //        roDataCreate.setRecognisedProducts(null);
        roDataCreate.setLinkedOrganisations(null);
        recognisingOrgRepository.save(
                organisationCommonUtils.populateOrganisation(
                        roDataCreate, new RecognisingOrganisation()));
        roDataCreate.getContacts().get(0).getAddresses().get(0).setEmail("smith@gmail.com");
        roDataCreate.getContacts().get(1).getAddresses().get(0).setEmail("smith@gmail.com");
        roDataCreate.getContacts().get(0).getAddresses().get(1).setEmail("smith1@gmail.com");
        roDataCreate.getContacts().get(1).getAddresses().get(1).setEmail("smith1@gmail.com");
        createOrganisationDomainService.onCommand(roDataCreate);

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        assertEquals(
                OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT,
                event.getEventHeader().getEventName());
        assertEquals(1, event.getEventErrors().getErrorList().size());
        assertEquals("V0048", event.getEventErrors().getErrorList().get(0).getErrorCode());
    }

    @Test
    final void testSaveOrganisationWhenPrimaryEmailDuplicateAndAdminEmailUnique()
            throws SQLException, IOException {

        String authorisedAccessTokenToCreate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToCreate);

        RoDataCreateV1Valid roDataCreate = CreateOrganisationDataSetup.createOrgData();
        roDataCreate.setPartnerContact("");
        roDataCreate.setNotes(null);
        roDataCreate.setAlternateNames(null);
        roDataCreate.setMinimumScores(null);
        //        roDataCreate.setRecognisedProducts(null);
        roDataCreate.getContacts().get(0).getAddresses().get(0).setEmail("alan@gmail.com");
        roDataCreate.getContacts().get(0).getAddresses().get(1).setEmail("alan@gmail.com");
        recognisingOrgRepository.save(
                organisationCommonUtils.populateOrganisation(
                        roDataCreate, new RecognisingOrganisation()));
        roDataCreate.setOrganisationName("Arizona State University");
        roDataCreate.getContacts().get(1).getAddresses().get(0).setEmail("lucas@gmail.com");
        roDataCreate.getContacts().get(1).getAddresses().get(1).setEmail("lucas@gmail.com");
        createOrganisationDomainService.onCommand(roDataCreate);
        RecognisingOrganisation recognisingOrganisation =
                recognisingOrgRepository.findByName("Arizona State University");
        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        assertEquals(OrganisationConstants.EventType.RO_CREATED_EVENT,
                event.getEventHeader().getEventName());
        assertAll(
                "RoCreated",
                () ->
                        assertEquals(
                                recognisingOrganisation.getName(),
                                roDataCreate.getOrganisationName()),
                () ->
                        assertEquals(
                                recognisingOrganisation.getVerificationStatus(),
                                roDataCreate.getVerificationStatus()),
                () ->
                        assertEquals(
                                recognisingOrganisation.getPartnerCode(),
                                roDataCreate.getPartnerCode()),
                () ->
                        assertEquals(
                                recognisingOrganisation.getOrganisationCode(),
                                roDataCreate.getOrganisationCode()));
    }

    @Test
    void testSaveOrganisationWithDuplicateEmailRejectedEvent() throws SQLException, IOException {

        String authorisedAccessTokenToCreate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToCreate);

        RoDataCreateV1Valid roDataCreate = CreateOrganisationDataSetup.createOrgData();
        roDataCreate.setPartnerContact("");
        roDataCreate.setNotes(null);
        roDataCreate.setAlternateNames(null);
        roDataCreate.setMinimumScores(null);
        //        roDataCreate.setRecognisedProducts(null);
        roDataCreate.setLinkedOrganisations(null);
        roDataCreate.getContacts().get(1).getAddresses().get(0).setEmail("alan@gmail.com");
        roDataCreate.getContacts().get(1).getAddresses().get(1).setEmail("alan@gmail.com");
        roDataCreate.getContacts().get(0).getAddresses().get(0).setEmail("alan@gmail.com");
        roDataCreate.getContacts().get(0).getAddresses().get(1).setEmail("alan@gmail.com");
        recognisingOrgRepository.save(
                organisationCommonUtils.populateOrganisation(
                        roDataCreate, new RecognisingOrganisation()));
        roDataCreate.setOrganisationName("Arizona State University");
        createOrganisationDomainService.onCommand(roDataCreate);

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        assertEquals(
                OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT,
                event.getEventHeader().getEventName());
        assertEquals(1, event.getEventErrors().getErrorList().size());
        assertEquals("V0055", event.getEventErrors().getErrorList().get(0).getErrorCode());
    }
    @Test
    void testSaveOrganisationWithVerifiedROEmptyEmailFirstNameLastNamePublishSuccessEvent() throws SQLException, IOException {

        String authorisedAccessTokenToCreate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToCreate);

        RoDataCreateV1Valid roDataCreate = CreateOrganisationDataSetup.createOrgData();

        roDataCreate.setPartnerContact("");
        roDataCreate.setNotes(null);
        roDataCreate.setAlternateNames(null);
        roDataCreate.setMinimumScores(null);
        roDataCreate.setLinkedOrganisations(null);
        roDataCreate.setVerificationStatus(VerificationStatusEnum.VERIFIED);
        roDataCreate.getContacts().get(1).setFirstName(null);
        roDataCreate.getContacts().get(1).setLastName(null);
        roDataCreate.getContacts().get(1).getAddresses().get(0).setEmail(null);
        roDataCreate.getContacts().get(1).getAddresses().get(1).setEmail(null);
        recognisingOrgRepository.save(
                organisationCommonUtils.populateOrganisation(
                        roDataCreate, new RecognisingOrganisation()));
        roDataCreate.setOrganisationName("Arizona State University");
        createOrganisationDomainService.onCommand(roDataCreate);

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        assertEquals(OrganisationConstants.EventType.RO_CREATED_EVENT,
                event.getEventHeader().getEventName());
        RoChangedEventV1 roCreatedEvent =
                objectMapper.readValue(event.getEventBody(), RoChangedEventV1.class);
        assertEquals(null, roCreatedEvent.getContacts().get(1).getAddresses().get(0).getEmail());
    }
    @Test
    void testEventDiscriminatorInHeadersWhilePublishingROToLA() throws IOException {

        String authorisedAccessTokenToCreate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToCreate);

        RoDataCreateV1Valid roDataCreate = CreateOrganisationDataSetup.createOrgData();
        roDataCreate.getContacts().get(0).getAddresses().get(0).setEmail("test@gmail.com");
        roDataCreate.getContacts().get(0).getAddresses().get(1).setEmail("test@gmail.com");
        roDataCreate.getContacts().get(1).getAddresses().get(0).setEmail("test@gmail.com");
        roDataCreate.getContacts().get(1).getAddresses().get(1).setEmail("test@gmail.com");
        createOrganisationDomainService.onCommand(roDataCreate);

        RecognisingOrganisation recognisingOrganisation =
                recognisingOrgRepository.findByName("McGill University");

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        BaseHeader header = event.getEventHeader();
        RoChangedEventV1 roCreatedEvent =
                objectMapper.readValue(event.getEventBody(), RoChangedEventV1.class);
        assertAll(
                "Headers",
                () ->
                        assertEquals(
                                OrganisationConstants.EventType.RO_CREATED_EVENT,
                                header.getEventName()),
                () -> assertEquals("ROApproved", header.getEventDiscriminator()));
        assertEquals(
                recognisingOrganisation.getOrganisationId(), roCreatedEvent.getOrganisationId());
    }

    @Test
    void testEventDiscriminatorInHeadersWhilePublishingROToORS() throws IOException {

        String authorisedAccessTokenToCreate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToCreate);

        RoDataCreateV1Valid roDataCreate = CreateOrganisationDataSetup.createOrgData();
        roDataCreate.getContacts().get(0).getAddresses().get(0).setEmail("test@gmail.com");
        roDataCreate.getContacts().get(0).getAddresses().get(1).setEmail("test@gmail.com");
        roDataCreate.getContacts().get(1).getAddresses().get(0).setEmail("test@gmail.com");
        roDataCreate.getContacts().get(1).getAddresses().get(1).setEmail("test@gmail.com");
        roDataCreate.setLinkedOrganisations(null);
        createOrganisationDomainService.onCommand(roDataCreate);

        RecognisingOrganisation recognisingOrganisation =
                recognisingOrgRepository.findByName("McGill University");

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        BaseHeader header = event.getEventHeader();
        RoChangedEventV1 roCreatedEvent =
                objectMapper.readValue(event.getEventBody(), RoChangedEventV1.class);
        assertAll(
                "Headers",
                () ->
                        assertEquals(
                                OrganisationConstants.EventType.RO_CREATED_EVENT,
                                header.getEventName()),
                () -> assertEquals("ROApproved", header.getEventDiscriminator()),
                () -> assertEquals("IDP", header.getPartnerCode()));
        assertEquals(
                recognisingOrganisation.getOrganisationId(), roCreatedEvent.getOrganisationId());
    }

    @Test
    void testEventDiscriminatorInHeadersWhilePublishingVOToORS() throws IOException {

        String authorisedAccessTokenToCreate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToCreate);

        RoDataCreateV1Valid roDataCreate = CreateOrganisationDataSetup.createOrgData();
        roDataCreate.setOrganisationTypeUuid(
                UUID.fromString("e392ae7c-016f-433a-bdfa-b79bfcdddf26")); // VO organisationTypeUuid
        roDataCreate.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.VERIFIED.getValue()));
        roDataCreate.getContacts().get(1).getAddresses().get(0).setEmail("test@gmail.com");
        roDataCreate.getContacts().get(1).getAddresses().get(1).setEmail("test@gmail.com");
        roDataCreate.setLinkedOrganisations(null);
        UiHeader uiHeader = OrganisationTestUtil.generateEventHeader();
        uiHeader.setEventName(OrganisationConstants.EventType.RO_CREATED_EVENT);
        createOrganisationDomainService.onCommand(roDataCreate);
        RecognisingOrganisation recognisingOrganisation =
                recognisingOrgRepository.findByName("McGill University");

        verify(applicationEventPublisher, times(1)).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        BaseHeader header = event.getEventHeader();
        RoChangedEventV1 roCreatedEvent =
                objectMapper.readValue(event.getEventBody(), RoChangedEventV1.class);
        assertAll(
                "Headers",
                () ->
                        assertEquals(
                                OrganisationConstants.EventType.RO_CREATED_EVENT,
                                header.getEventName()),
                () -> assertEquals("VOVerified", header.getEventDiscriminator()),
                () -> assertEquals("IDP", header.getPartnerCode()));
        assertEquals(
                recognisingOrganisation.getOrganisationId(), roCreatedEvent.getOrganisationId());

        roDataCreate.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.PENDING.getValue()));
        roDataCreate.setOrganisationName("Pending University");
         createOrganisationDomainService.onCommand(roDataCreate);
        RecognisingOrganisation recognisingOrganisation1 =
                recognisingOrgRepository.findByName("Pending University");

        verify(applicationEventPublisher, times(2)).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event1 = publishedEventCaptor.getValue();
        BaseHeader header1 = event1.getEventHeader();
        RoChangedEventV1 roCreatedEvent1 =
                objectMapper.readValue(event1.getEventBody(), RoChangedEventV1.class);
        assertAll(
                "Headers",
                () ->
                        assertEquals(
                                OrganisationConstants.EventType.RO_CREATED_EVENT,
                                header1.getEventName()),
                () -> assertNull(header1.getEventDiscriminator()),
                () -> assertEquals("IDP", header1.getPartnerCode()));
        assertEquals(
                recognisingOrganisation1.getOrganisationId(), roCreatedEvent1.getOrganisationId());
    }
    @Test
    void testEventDiscriminatorInHeadersWhileNotPublishingVerifiedROToLA() throws IOException {

        String authorisedAccessTokenToCreate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToCreate);

        RoDataCreateV1Valid roDataCreate = CreateOrganisationDataSetup.createOrgData();
        roDataCreate.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.VERIFIED.getValue()));
        roDataCreate.getContacts().get(0).getAddresses().get(0).setEmail("test@gmail.com");
        roDataCreate.getContacts().get(0).getAddresses().get(1).setEmail("test@gmail.com");
        roDataCreate.getContacts().get(1).getAddresses().get(0).setEmail("test@gmail.com");
        roDataCreate.getContacts().get(1).getAddresses().get(1).setEmail("test@gmail.com");
        UiHeader uiHeader = OrganisationTestUtil.generateEventHeader();
        uiHeader.setEventName(OrganisationConstants.EventType.RO_CREATED_EVENT);
        uiHeader.setXaccessToken(authorisedAccessTokenToCreate);
        createOrganisationDomainService.onCommand(roDataCreate);

        RecognisingOrganisation recognisingOrganisation =
                recognisingOrgRepository.findByName("McGill University");

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        BaseHeader header = event.getEventHeader();
        RoChangedEventV1 roCreatedEvent =
                objectMapper.readValue(event.getEventBody(), RoChangedEventV1.class);
        assertAll(
                "Headers",
                () ->
                        assertEquals(
                                OrganisationConstants.EventType.RO_CREATED_EVENT,
                                header.getEventName()),
                () -> assertEquals("VOVerified", header.getEventDiscriminator()));
        assertEquals(
                recognisingOrganisation.getOrganisationId(), roCreatedEvent.getOrganisationId());
    }
    @Test
    final void testSaveRecognisingOrganisationWithVerificationStatusAsVerified() throws IOException {

        String authorisedAccessTokenToCreate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToCreate);

        RoDataCreateV1Valid roDataCreate = CreateOrganisationDataSetup.createOrgData();
        roDataCreate.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.VERIFIED.getValue()));
        roDataCreate.getContacts().get(0).getAddresses().get(0).setEmail("test@gmail.com");
        roDataCreate.getContacts().get(0).getAddresses().get(1).setEmail("test@gmail.com");

        roDataCreate
                .getContacts()
                .get(1)
                .getAddresses()
                .get(0)
                .setEmail("M'chris$tine.sharon-&ggr123@dha-fraschools.fe.com");
        roDataCreate
                .getContacts()
                .get(1)
                .getAddresses()
                .get(1)
                .setEmail("K'christ#ine.sharon-&rtd123@dha-fraschools.efe-grrfe.kkkk-ooo.com");
        roDataCreate.setAcceptsSSR(true);
        UiHeader uiHeader = OrganisationTestUtil.generateEventHeader();
        uiHeader.setEventName(OrganisationConstants.EventType.RO_CREATED_EVENT);
        uiHeader.setXaccessToken(authorisedAccessTokenToCreate);
        createOrganisationDomainService.onCommand(roDataCreate);

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();

        RoChangedEventV1 roCreatedEvent =
                objectMapper.readValue(event.getEventBody(), RoChangedEventV1.class);
        /* Count Check */
        assertTrue(recognisingOrgRepository.count() > 0);
        assertEquals(VerificationStatusEnum.valueOf(VerificationStatusEnum.VERIFIED.getValue()), roCreatedEvent.getVerificationStatus());
        assertEquals("VOVerified", event.getEventHeader().getEventDiscriminator());
    }
    @Test
    void testSaveOrganisationWithVerifiedStatusDuplicateEmailRejectedEvent() throws SQLException, IOException {

        String authorisedAccessTokenToCreate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToCreate);

        RoDataCreateV1Valid roDataCreate = CreateOrganisationDataSetup.createOrgData();
        roDataCreate.setVerificationStatus(VerificationStatusEnum.VERIFIED);
        roDataCreate.setPartnerContact("");
        roDataCreate.setNotes(null);
        roDataCreate.setAlternateNames(null);
        roDataCreate.setMinimumScores(null);
        roDataCreate.setLinkedOrganisations(null);
        roDataCreate.getContacts().get(1).getAddresses().get(0).setEmail("alan@gmail.com");
        roDataCreate.getContacts().get(1).getAddresses().get(1).setEmail("alan@gmail.com");
        roDataCreate.getContacts().get(0).getAddresses().get(0).setEmail("alan@gmail.com");
        roDataCreate.getContacts().get(0).getAddresses().get(1).setEmail("alan@gmail.com");
        recognisingOrgRepository.save(
                organisationCommonUtils.populateOrganisation(
                        roDataCreate, new RecognisingOrganisation()));
        roDataCreate.setOrganisationName("Arizona State University");
        createOrganisationDomainService.onCommand(roDataCreate);

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        assertEquals(
                OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT,
                event.getEventHeader().getEventName());
        assertEquals(1, event.getEventErrors().getErrorList().size());
        assertEquals("V0055", event.getEventErrors().getErrorList().get(0).getErrorCode());
    }
}
