package com.ielts.cmds.organisation.utills;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import com.ielts.cmds.api.roui007rocreaterequested.MethodOfDeliveryEnum;
import com.ielts.cmds.organisation.utils.MethodOfDeliveryEnumConverter;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;


import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreate;

@ExtendWith(MockitoExtension.class)
public class MethodOfDeliveryEnumConverterTest {

    @Test
    public void testWhenValidMethodOfEDelivery_convertToDBColumn() {
    	MethodOfDeliveryEnumConverter methodOfDeliveryEnumConverters = new MethodOfDeliveryEnumConverter();
        String eDeliveryValue = methodOfDeliveryEnumConverters.convertToDatabaseColumn(MethodOfDeliveryEnum.E_DELIVERY);
        assertEquals(eDeliveryValue, MethodOfDeliveryEnum.E_DELIVERY.getValue());
    }

    @Test
    public void testWhenNullMethodOfEDelivery_convertToDBColumn() {
    	MethodOfDeliveryEnumConverter methodOfDeliveryEnumConverters = new MethodOfDeliveryEnumConverter();
    	String eDeliveryValue = methodOfDeliveryEnumConverters.convertToDatabaseColumn(null);
        assertNull(eDeliveryValue);
    }

    @Test
    public void testWhenValidMethodOfEDelivery_convertToEntityAttribute() {
    	MethodOfDeliveryEnumConverter methodOfDeliveryEnumConverters = new MethodOfDeliveryEnumConverter();
        MethodOfDeliveryEnum eDeliveryValue = methodOfDeliveryEnumConverters.convertToEntityAttribute("E-DELIVERY");
        assertEquals(eDeliveryValue.toString(), MethodOfDeliveryEnum.E_DELIVERY.toString());
    }

    @Test
    public void testWhenNullMethodOfEDelivery_convertToEntityAttribute() {
    	MethodOfDeliveryEnumConverter methodOfDeliveryEnumConverters = new MethodOfDeliveryEnumConverter();
    	MethodOfDeliveryEnum eDeliveryValue = methodOfDeliveryEnumConverters.convertToEntityAttribute(null);
        assertNull(eDeliveryValue);
    }
}
