package com.ielts.cmds.organisation.domain.services;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.Instant;
import java.util.UUID;

import javax.transaction.Transactional;

import com.ielts.cmds.organisation.cache.JedisGenericReader;
import com.ielts.cmds.organisation.cache.factory.JedisFactory;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ielts.cmds.api.roui007rocreaterequested.VerificationStatusEnum;
import com.ielts.cmds.api.roui007rocreaterequested.MethodOfDeliveryEnum;
import com.ielts.cmds.api.roui007rocreaterequested.OrganisationStatusEnum;
import com.ielts.cmds.organisation.infrastructure.config.RBACTestConfig;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = RBACTestConfig.class)
@ActiveProfiles("test")
@Sql({
    "/sql/schema.sql"
})
@Transactional
class OrganisationIdIntegrationTest {

	@Autowired private RecognisingOrganisationRepository recognisingOrgRepository;

	@MockBean
	private JedisGenericReader jedisGenericReader;

	@Spy
	private OrganisationCommonUtils orgCommonUtils;

	@MockBean private JedisFactory jedisFactory;

	@BeforeEach
	void setup() {
		ReflectionTestUtils.setField(
				orgCommonUtils, "jedisGenericReader", jedisGenericReader);
	}
	
	@Test
    final void testSaveOrganisationWithOrganisationIdProvided() {
		RecognisingOrganisation org = new RecognisingOrganisation();
		org.setRecognisingOrganisationUuid(UUID.randomUUID());
		org.setName("Organisation");
		org.setOrganisationTypeUuid(UUID.randomUUID());
		org.setSectorTypeUuid(UUID.randomUUID());
		org.setOrganisationId(123);
		org.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.APPROVED.getValue()));
		org.setPartnerCode("BC");
		org.setMethodOfDelivery(MethodOfDeliveryEnum.valueOf(MethodOfDeliveryEnum.POSTAL.getValue()));
		org.setOrgStatus(OrganisationStatusEnum.valueOf(OrganisationStatusEnum.ACTIVE.getValue()));
		org.setCreatedBy("OPS-USER");
		org.setCreatedDatetime(Instant.now());
		recognisingOrgRepository.save(org);
		RecognisingOrganisation recognisingOrganisation =
                recognisingOrgRepository.findByName("Organisation");
		assertEquals(123, recognisingOrganisation.getOrganisationId());
	}
	
	@Test
    final void testSaveOrganisationWithoutOrgaisationId() {
		RecognisingOrganisation org = new RecognisingOrganisation();
		org.setRecognisingOrganisationUuid(UUID.randomUUID());
		org.setName("Univeristy");
		org.setOrganisationTypeUuid(UUID.randomUUID());
		org.setSectorTypeUuid(UUID.randomUUID());
		org.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.APPROVED.getValue()));
		org.setPartnerCode("BC");
		org.setMethodOfDelivery(MethodOfDeliveryEnum.valueOf(MethodOfDeliveryEnum.POSTAL.getValue()));
		org.setOrgStatus(OrganisationStatusEnum.valueOf(OrganisationStatusEnum.ACTIVE.getValue()));
		org.setCreatedBy("OPS-USER");
		org.setCreatedDatetime(Instant.now());
		RecognisingOrganisation savedOrg = recognisingOrgRepository.save(org);
		RecognisingOrganisation recognisingOrganisation =
                recognisingOrgRepository.findByName("Univeristy");
		assertEquals(savedOrg.getOrganisationId(), recognisingOrganisation.getOrganisationId());
	}
}
