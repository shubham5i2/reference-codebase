package com.ielts.cmds.organisation.domain.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.roui005rosearchrequested.RoSearchCriteria;
import com.ielts.cmds.api.roui005rosearchrequested.RoSearchObject;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1;
import com.ielts.cmds.organisation.domain.commands.CreateROVO;
import com.ielts.cmds.organisation.domain.validators.SearchRoCriteriaValidator;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.SearchOrganisationRepository;
import com.ielts.cmds.organisation.utills.CreateOrganisationDataSetup;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utills.SearchOrganisationDataSetup;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.organisation.utils.SearchCriteriaSpecificationUtil;
import com.ielts.cmds.organisation.utils.SearchRoEntityToEventMapper;
import com.ielts.cmds.outbox.event.OutboxEventBuilder;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.api.service.impl.RBACServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.*;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.test.util.ReflectionTestUtils;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.validation.ValidationException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SearchOrganisationDomainServiceTest {

    @InjectMocks @Spy
    private SearchOrganisationDomainService searchOrganisationDomainService;

    @Mock private SearchRoCriteriaValidator searchRoCriteriaValidator;

    @Mock private RBACServiceImpl rbacServiceImpl;

    @Mock private CriteriaBuilder criteriaBuilder;

    @Mock private CriteriaQuery<RecognisingOrganisation> criteriaQuery;

    @Mock private Root<RecognisingOrganisation> recognisingOrganisationRoot;

    @Mock private Specification<RecognisingOrganisation> addressCriteriaSpec;

    @Mock private Specification<RecognisingOrganisation> roCriteriaSpec;

    @Mock private Specification<RecognisingOrganisation> contactCriteriaSpec;

    @Mock private Specification<RecognisingOrganisation> criteriaSpec;

    @Mock private Specification<RecognisingOrganisation> intermediaryCriteriaSpec;

    @Mock private SearchOrganisationRepository searchOrganisationRepository;

    @Mock private ObjectMapper objectMapper;

    @Mock private SearchCriteriaSpecificationUtil searchCriteriaSpecificationUtil;

    @Mock private SearchRoEntityToEventMapper searchRoEntityToEventMapper;

    @Mock private ApplicationEventPublisher applicationEventPublisher;

    @Captor private ArgumentCaptor<Specification<RecognisingOrganisation>> specificationCaptor;

    @Captor private ArgumentCaptor<Pageable> pageableCaptor;

    @Captor private ArgumentCaptor<RecognisingOrganisation> recognisingOrgCapt;

    @Captor private ArgumentCaptor<BaseEvent<BaseHeader>> roSearchResultsCaptor;

    @Mock private OutboxEventBuilder outboxEventBuilder;

    @Spy private OrganisationCommonUtils orgCommonUtils;

    @BeforeEach
    void setup() {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(
                searchOrganisationDomainService, "orgUtils", orgCommonUtils);

        ReflectionTestUtils.setField(
                searchOrganisationDomainService, "rbacServiceImpl", rbacServiceImpl);
        ReflectionTestUtils.setField(
                searchOrganisationDomainService,
                "searchRoCriteriaValidator",
                searchRoCriteriaValidator);
        ReflectionTestUtils.setField(
                searchOrganisationDomainService,
                "searchCriteriaSpecificationUtil",
                searchCriteriaSpecificationUtil);
        ReflectionTestUtils.setField(
                searchOrganisationDomainService,
                "searchRoEntityToEventMapper",
                searchRoEntityToEventMapper);
        ReflectionTestUtils.setField(
                searchOrganisationDomainService,
                "searchOrganisationRepository",
                searchOrganisationRepository);
        ReflectionTestUtils.setField(searchOrganisationDomainService, "objectMapper", objectMapper);
        ReflectionTestUtils.setField(
                searchOrganisationDomainService,
                "applicationEventPublisher",
                applicationEventPublisher);
        ReflectionTestUtils.setField(
                searchOrganisationDomainService, "outboxEventBuilder", outboxEventBuilder);
        ThreadLocalHeaderContext.setContext(OrganisationTestUtil.generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_SEARCH_REQUEST_EVENT));
        ThreadLocalAuditContext.setContext(OrganisationTestUtil.getBaseAudit());

    }

    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchRoCommand")
    void whenReceivedValid_SearchRoCommand_thenNoException(
            final RoSearchObject roSearchObject,
            final Pageable pageable,
            final List<Sort.Order> sorts,
            final Page<RecognisingOrganisation> page,
            final RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1)
            throws RbacValidationException {

        doReturn(true)
                .when(rbacServiceImpl)
                .isAuthorised(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION);
        doReturn(true).when(searchRoCriteriaValidator).isValid(roSearchObject);

        doReturn(criteriaSpec)
                .when(searchOrganisationDomainService)
                .getSpecification(roSearchObject.getCriteria());

        doReturn(sorts)
                .when(searchOrganisationDomainService)
                .getSortDirection(roSearchObject.getSorting());

        doReturn(page).when(searchOrganisationRepository).findAll(criteriaSpec, pageable);

        doNothing()
                .when(searchOrganisationDomainService)
                .publishSearchRoResponse(
                        any(),
                        any(),
                        any());

        doReturn(rosSearchResultsGeneratedEventV1)
                .when(searchRoEntityToEventMapper)
                .mapEntityToEvent(roSearchObject, page.getContent(), page.getTotalElements());

        searchOrganisationDomainService.onCommand(roSearchObject);

        verify(searchOrganisationDomainService)
                .getSortDirection(roSearchObject.getSorting());
        verify(searchOrganisationRepository)
                .findAll(specificationCaptor.capture(), pageableCaptor.capture());
        assertNotNull(specificationCaptor.getValue());
        assertNotNull(pageableCaptor.getValue());
        assertEquals(criteriaSpec, specificationCaptor.getValue());
        assertEquals(pageable, pageableCaptor.getValue());
    }

    @DisplayName("Empty Search Criteria - Validation Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchRoCommandEmptySearchCriteria")
    void whenReceivedValid_SearchRoCommand_WithEmptySearchCriteria_thenValidationException(
            final RoSearchObject roSearchObject) throws RbacValidationException {
        UiHeader header = orgCommonUtils.buildUiHeader();

        doReturn(true)
                .when(rbacServiceImpl)
                .isAuthorised(
                        header.getXaccessToken(),
                        OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION);

        doReturn(false).when(searchRoCriteriaValidator).isValid(roSearchObject);

        Executable executable = () -> searchOrganisationDomainService.onCommand(roSearchObject);

        ValidationException exception = assertThrows(ValidationException.class, executable);
        assertEquals(
                OrganisationConstants.ErrorResponse.CANNOT_PERFORM_SEARCH, exception.getMessage());
        verify(searchOrganisationDomainService, never())
                .getSortDirection(roSearchObject.getSorting());
    }

    @DisplayName("UnAuthorised User - Validation Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchRoCommandEmptySearchCriteria")
    void whenReceivedValid_SearchRoCommand_UnauthorisedUser_thenValidationException(
            final RoSearchObject roSearchObject) throws RbacValidationException {
        UiHeader header = orgCommonUtils.buildUiHeader();

        doReturn(false)
                .when(rbacServiceImpl)
                .isAuthorised(
                        header.getXaccessToken(),
                        OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION);

        Executable executable = () -> searchOrganisationDomainService.onCommand(roSearchObject);

        ValidationException exception = assertThrows(ValidationException.class, executable);
        assertEquals(
                OrganisationConstants.ErrorResponse.CANNOT_PERFORM_SEARCH, exception.getMessage());
        verify(searchOrganisationDomainService, never())
                .getSortDirection(roSearchObject.getSorting());
    }

    @DisplayName("Valid Command RuntimeException - Expect Publish Not Called")
    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchRoCommand")
    void whenValid_SearchRoCommandWithDbException_thenPublisherNotInvoked(
            final RoSearchObject roSearchObject,
            final Pageable pageable,
            final List<Sort.Order> sorts,
            final Page<RecognisingOrganisation> page,
            final RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1)
            throws RbacValidationException {

        UiHeader header = orgCommonUtils.buildUiHeader();

        doReturn(true)
                .when(rbacServiceImpl)
                .isAuthorised(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION);

        doReturn(true).when(searchRoCriteriaValidator).isValid(roSearchObject);

        doReturn(criteriaSpec)
                .when(searchOrganisationDomainService)
                .getSpecification(roSearchObject.getCriteria());

        doReturn(sorts)
                .when(searchOrganisationDomainService)
                .getSortDirection(roSearchObject.getSorting());

        doThrow(RuntimeException.class)
                .when(searchOrganisationRepository)
                .findAll(criteriaSpec, pageable);

        searchOrganisationDomainService.onCommand(roSearchObject);

        verify(searchOrganisationDomainService)
                .getSortDirection(roSearchObject.getSorting());
        verify(searchOrganisationRepository)
                .findAll(specificationCaptor.capture(), pageableCaptor.capture());
        assertEquals(criteriaSpec, specificationCaptor.getValue());
        assertEquals(pageable, pageableCaptor.getValue());
        verify(searchOrganisationDomainService, never())
                .publishSearchRoResponse(
                        rosSearchResultsGeneratedEventV1,
                        header,
                        orgCommonUtils.getBaseAudit());
    }

    @DisplayName("SortDirection - Expect sort list")
    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchRoCommand")
    void whenSortCriteria_SortDirection_thenExpectSortList(
            final RoSearchObject roSearchObject,
            final Pageable pageable,
            final List<Sort.Order> sorts,
            final Page<RecognisingOrganisation> page,
            final RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1) {

        List<Sort.Order> actual =
                searchOrganisationDomainService.getSortDirection(
                        roSearchObject.getSorting());
        assertNotNull(actual);
        assertEquals(sorts, actual);
    }

    @DisplayName("SortDirection - Expect sort list")
    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchRoCommand")
    void whenSortCriteriaEmpty_SortDirection_thenExpectEmptySortList(
            final RoSearchObject roSearchObject,
            final Pageable pageable,
            final List<Sort.Order> sorts,
            final Page<RecognisingOrganisation> page,
            final RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1) {
        roSearchObject.setSorting(null);
        List<Sort.Order> actual =
                searchOrganisationDomainService.getSortDirection(
                        roSearchObject.getSorting());
        assertTrue(actual.isEmpty());
    }

    @DisplayName("Specification - Expect specification to be returned")
    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchRoCommand")
    void whenSpecification_GetSpecification_thenReturnSpecification(
            final RoSearchObject roSearchObject,
            final Pageable pageable,
            final List<Sort.Order> sorts,
            final Page<RecognisingOrganisation> page,
            final RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1) {

        doReturn(roCriteriaSpec)
                .when(searchCriteriaSpecificationUtil)
                .criteriaMatches(roSearchObject.getCriteria());

        Specification<RecognisingOrganisation> actual =
                searchOrganisationDomainService.getSpecification(
                        roSearchObject.getCriteria());
        actual.toPredicate(recognisingOrganisationRoot, criteriaQuery, criteriaBuilder);
        assertNotNull(actual);
    }

    @DisplayName("Call Publisher - Expect Publisher To Be Invoked")
    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchRoCommand")
    void whenPublish_PublishSearchResponse_thenExpectPublisherToBeInvoked(
            final RoSearchObject roSearchObject,
            final Pageable pageable,
            final List<Sort.Order> sorts,
            final Page<RecognisingOrganisation> page,
            final RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1)
            throws JsonProcessingException {
        UiHeader header = orgCommonUtils.buildUiHeader();

        doReturn(new ObjectMapper().writeValueAsString(rosSearchResultsGeneratedEventV1))
                .when(objectMapper)
                .writeValueAsString(rosSearchResultsGeneratedEventV1);

        doNothing().when(applicationEventPublisher).publishEvent(any(BaseEvent.class));
        Executable executable =
                () ->
                        searchOrganisationDomainService.publishSearchRoResponse(
                                rosSearchResultsGeneratedEventV1,
                                header,
                                orgCommonUtils.getBaseAudit());
        assertDoesNotThrow(executable);
        verify(applicationEventPublisher).publishEvent(roSearchResultsCaptor.capture());
        assertEquals(
                OrganisationConstants.EventType.RO_SEARCH_RESULT_GENERATED_EVENT,
                roSearchResultsCaptor.getValue().getEventHeader().getEventName());
    }

    @DisplayName("Call Publisher: JsonProcessingException - Expect IllegalArgumentException")
    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchRoCommand")
    void whenPublish_PublishSearchResponse_thenExpectIllegalArgumentException(
            final RoSearchObject roSearchObject,
            final Pageable pageable,
            final List<Sort.Order> sorts,
            final Page<RecognisingOrganisation> page,
            final RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1)
            throws JsonProcessingException {
        UiHeader header = orgCommonUtils.buildUiHeader();

        doThrow(JsonProcessingException.class)
                .when(objectMapper)
                .writeValueAsString(rosSearchResultsGeneratedEventV1);

        Executable executable =
                () ->
                        searchOrganisationDomainService.publishSearchRoResponse(
                                rosSearchResultsGeneratedEventV1,
                                header,
                                orgCommonUtils.getBaseAudit());

        assertThrows(IllegalArgumentException.class, executable);
        verify(applicationEventPublisher, never()).publishEvent(any(BaseEvent.class));
    }

    private static Stream<Arguments> provideArgumentsForSearchRoCommand() {

        final RoSearchObject roSearchObject = SearchOrganisationDataSetup.getRoSearchData();
        UiHeader uiHeaders = OrganisationTestUtil.generateEventHeader();
        uiHeaders.setEventName(OrganisationConstants.GenericConstants.RO_SEARCH_REQUEST_EVENT);

        List<Sort.Order> sorts = new ArrayList<>();
        sorts.add(new Sort.Order(Direction.ASC, "organisationId"));

        CreateROVO createRo =
                CreateROVO.builder()
                        .eventHeaders(OrganisationTestUtil.generateEventHeader())
                        .eventBody(CreateOrganisationDataSetup.createOrgData())
                        .build();
        RecognisingOrganisation organisation = new RecognisingOrganisation();
        RecognisingOrganisation recognisingOrganisation =
                CreateOrganisationDataSetup.populateOrganisation(createRo.getEventBody(), organisation);
        List<RecognisingOrganisation> recognisingOrganisations = new ArrayList<>();
        recognisingOrganisations.add(recognisingOrganisation);

        Page<RecognisingOrganisation> page = new PageImpl<>(recognisingOrganisations);

        RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1 =
                new RosSearchResultsGeneratedEventV1();
        rosSearchResultsGeneratedEventV1.setSearch(
                new com.ielts.cmds.organisation.common.out.event.RoSearchV1());
        BigDecimal pageNumber = new BigDecimal(String.valueOf(roSearchObject.getPagination().getPageNumber()));
        BigDecimal pageSize = new BigDecimal(String.valueOf(roSearchObject.getPagination().getPageSize()));

        Pageable pageable =
                PageRequest.of(
                        pageNumber.intValue(),
                        pageSize.intValue(),
                        Sort.by(sorts));
        return Stream.of(
                Arguments.of(roSearchObject, pageable, sorts, page, rosSearchResultsGeneratedEventV1));
    }

    private static Stream<Arguments> provideArgumentsForSearchRoCommandEmptySearchCriteria() {

        final RoSearchObject roSearchObject = new RoSearchObject();
        roSearchObject.setCriteria(new RoSearchCriteria());

        return Stream.of(Arguments.of(roSearchObject));
    }
}
