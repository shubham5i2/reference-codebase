package com.ielts.cmds.organisation.domain.services;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.organisation.domain.commands.CreateROVO;
import com.ielts.cmds.organisation.domain.commands.LoadROData;
import com.ielts.cmds.organisation.domain.model.LoadRODataV1;
import com.ielts.cmds.organisation.domain.model.RoDataCreateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.utills.CreateOrganisationDataSetup;
import com.ielts.cmds.organisation.utills.LoadRODataSetup;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utils.LoadRODataUtils;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;
import javax.validation.ConstraintViolation;
import org.apache.commons.lang.StringUtils;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataIntegrityViolationException;

@ExtendWith(MockitoExtension.class)
class ProcessRODomainServiceTest {

    @InjectMocks private ProcessRODomainService processRODomainService;

    @Spy private LoadRODataUtils loadRODataUtils;

    @Mock private OrganisationCommonUtils organisationCommonUtils;

    @Mock private CreateOrganisationDomainService createOrganisationDomainService;

    @Mock private RecognisingOrganisationRepository recognisingOrganisationRepository;

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void when_OnCommand_ExpectNoException(
            final LoadROData loadROData,
            final LoadRODataV1 loadRODataV1,
            final RoDataCreateV1Valid roDataCreateV1Valid,
            final RecognisingOrganisation recognisingOrganisation,
            final CreateROVO createROVO,
            final BaseEvent<BaseHeader> baseEvent)
            throws IOException {
        doReturn(roDataCreateV1Valid)
                .when(loadRODataUtils)
                .loadData(
                        loadRODataV1,
                        OrganisationConstants.GenericConstants.RECOGNISING_ORGANISATION);
        doReturn(new HashSet<>())
                .when(createOrganisationDomainService)
                .validateRODetails(roDataCreateV1Valid);
        doReturn(recognisingOrganisation)
                .when(organisationCommonUtils)
                .populateOrganisation(createROVO.getEventBody(), new RecognisingOrganisation());
        doReturn(recognisingOrganisation)
                .when(recognisingOrganisationRepository)
                .save(recognisingOrganisation);
        doReturn(baseEvent)
                .when(createOrganisationDomainService)
                .registerandPublishCreateOrganisationEvent(
                        loadROData.getEventHeaders(),
                        recognisingOrganisation,
                        loadROData.getAudit());
        assertEquals(baseEvent, processRODomainService.processRecord(loadROData, loadRODataV1));
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void when_OnCommandException_ExpectNoException(
            final LoadROData loadROData,
            final LoadRODataV1 loadRODataV1,
            final RoDataCreateV1Valid roDataCreateV1Valid,
            final RecognisingOrganisation recognisingOrganisation,
            final CreateROVO createROVO,
            final BaseEvent<BaseHeader> baseEvent)
            throws IOException {
        doReturn(roDataCreateV1Valid)
                .when(loadRODataUtils)
                .loadData(
                        loadRODataV1,
                        OrganisationConstants.GenericConstants.RECOGNISING_ORGANISATION);
        doReturn(new HashSet<>())
                .when(createOrganisationDomainService)
                .validateRODetails(roDataCreateV1Valid);
        doReturn(recognisingOrganisation)
                .when(organisationCommonUtils)
                .populateOrganisation(createROVO.getEventBody(), new RecognisingOrganisation());
        doThrow(new DataIntegrityViolationException(""))
                .when(recognisingOrganisationRepository)
                .save(recognisingOrganisation);
        BaseEvent<BaseHeader> actual =
                assertDoesNotThrow(
                        () -> processRODomainService.processRecord(loadROData, loadRODataV1));
        assertNull(actual);
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void when_OnCommandRejectedEvent_ExpectRejectedEvent(
            final LoadROData loadROData,
            final LoadRODataV1 loadRODataV1,
            final RoDataCreateV1Valid roDataCreateV1Valid,
            final RecognisingOrganisation recognisingOrganisation,
            final CreateROVO createROVO)
            throws IOException {
        Set<ConstraintViolation<Object>> violations =
                OrganisationTestUtil.getSetforNullViolationOfEventBody("V0004", "name");
        doReturn(roDataCreateV1Valid)
                .when(loadRODataUtils)
                .loadData(
                        loadRODataV1,
                        OrganisationConstants.GenericConstants.RECOGNISING_ORGANISATION);
        doReturn(violations)
                .when(createOrganisationDomainService)
                .validateRODetails(roDataCreateV1Valid);
        final BaseEvent<BaseHeader> roRejectedEvent = LoadRODataSetup.getRORejectedEvent();
        doReturn(roRejectedEvent)
                .when(createOrganisationDomainService)
                .generateRejectedEventResponse(
                        loadROData.getEventHeaders(), createROVO.getEventBody(), createROVO.getAudit(), violations, null);
        assertEquals(
                roRejectedEvent, processRODomainService.processRecord(loadROData, loadRODataV1));
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void when_DuplicateOrgId_ExpectRejectedEvent(
            final LoadROData loadROData,
            final LoadRODataV1 loadRODataV1,
            final RoDataCreateV1Valid roDataCreateV1Valid,
            final RecognisingOrganisation recognisingOrganisation,
            final CreateROVO createROVO)
            throws IOException {
        Set<ConstraintViolation<Object>> violations =
                OrganisationTestUtil.getSetforNullViolationOfEventBody(
                        "V0066", "DuplicateOrganisationId");
        doReturn(roDataCreateV1Valid)
                .when(loadRODataUtils)
                .loadData(
                        loadRODataV1,
                        OrganisationConstants.GenericConstants.RECOGNISING_ORGANISATION);
        doReturn(Boolean.TRUE)
                .when(recognisingOrganisationRepository)
                .existsByOrganisationIdAndSoftDeletedFalse(
                        Integer.valueOf(
                                StringUtils.deleteWhitespace(loadRODataV1.getOrganisationId())));
        doReturn(violations)
                .when(organisationCommonUtils)
                .getSetforNullViolationOfEventBody("V0066", "DuplicateOrganisationId");
        final BaseEvent<BaseHeader> roRejectedEvent = LoadRODataSetup.getRORejectedEvent();
        doReturn(roRejectedEvent)
                .when(createOrganisationDomainService)
                .generateRejectedEventResponse(
                        loadROData.getEventHeaders(), createROVO.getEventBody(), createROVO.getAudit(), violations, null);
        assertEquals(
                roRejectedEvent, processRODomainService.processRecord(loadROData, loadRODataV1));
    }

    private static Stream<Arguments> argumentsProviderForOrganisationLoadDataEvent()
            throws JsonProcessingException {
        UiHeader roHeaders = OrganisationTestUtil.generateEventHeader();
        roHeaders.setEventName(
                OrganisationConstants.GenericConstants.OPERATION_TYPE_GET
                        + OrganisationConstants.GenericConstants.LOAD_RO_DATA_RESOURCE_TYPE);
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put(OrganisationConstants.GenericConstants.RO_DATA_FILE, "test.csv");
        eventContext.put(
                OrganisationConstants.GenericConstants.LOAD_ORGANISATION_TYPE,
                OrganisationConstants.GenericConstants.RECOGNISING_ORGANISATION);
        roHeaders.setEventContext(eventContext);

        final BaseEvent<UiHeader> event = new BaseEvent<UiHeader>(roHeaders, null, null, null);
        LoadROData loadROData =
                LoadROData.builder()
                        .eventHeaders(event.getEventHeader())
                        .eventErrors(event.getEventErrors())
                        .build();
        RoDataCreateV1Valid roData = CreateOrganisationDataSetup.createOrgData();
        final CreateROVO createROVO = CreateROVO.builder().eventBody(roData).build();
        RecognisingOrganisation publishRo =
                CreateOrganisationDataSetup.populateOrganisation(
                        createROVO.getEventBody(), new RecognisingOrganisation());
        return Stream.of(
                Arguments.of(
                        loadROData,
                        LoadRODataSetup.getLoadRODataV1List().get(0),
                        roData,
                        publishRo,
                        createROVO,
                        LoadRODataSetup.getROCreatedEvent(publishRo)));
    }
}
