package com.ielts.cmds.organisation.domain.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.organisation.domain.commands.LoadROData;
import com.ielts.cmds.organisation.domain.commands.UpdateROVO;
import com.ielts.cmds.organisation.domain.model.LoadROHierarchyDataV1;
import com.ielts.cmds.organisation.domain.model.RoDataUpdateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.utills.LoadROHierarchyDataSetup;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utills.UpdateOrganisationDataSetup;
import com.ielts.cmds.organisation.utils.LoadROHierarchyDataUtils;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.organisation.utils.UpdateOrganisationUtil;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Stream;
import javax.validation.ConstraintViolation;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
class ProcessROHierarchyDomainServiceTest {

    @InjectMocks private ProcessROHierarchyDomainService processROHierarchyDomainService;

    @Spy private LoadROHierarchyDataUtils loadROHierarchyDataUtils;

    @Spy private OrganisationCommonUtils organisationCommonUtils;

    @Mock private UpdateOrganisationUtil updateOrganisationUtil;

    @Mock private UpdateOrganisationDomainService updateOrganisationDomainService;

    @Mock private RecognisingOrganisationRepository recognisingOrganisationRepository;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(
                loadROHierarchyDataUtils,
                "recognisingOrgRepository",
                recognisingOrganisationRepository);
        ReflectionTestUtils.setField(
                processROHierarchyDomainService, "orgCommonUtils", organisationCommonUtils);
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void when_OnCommand_ExpectNoException(
            final LoadROData loadROData,
            final LoadROHierarchyDataV1 loadROHierarchyDataV1,
            final RoDataUpdateV1Valid roDataUpdateV1Valid,
            final RecognisingOrganisation recognisingOrganisation,
            final UpdateROVO updateROVO,
            final BaseEvent<BaseHeader> baseEvent)
            throws Exception {
        doReturn(roDataUpdateV1Valid)
                .when(loadROHierarchyDataUtils)
                .loadHierarchyData(recognisingOrganisation, loadROHierarchyDataV1);
        doReturn(new HashSet<>())
                .when(updateOrganisationDomainService)
                .validateUpdateRODetails(roDataUpdateV1Valid);
        doReturn(recognisingOrganisation)
                .when(updateOrganisationUtil)
                .populateOrganisation(roDataUpdateV1Valid, recognisingOrganisation, new HashMap<>());
        doReturn(Optional.of(recognisingOrganisation))
                .when(recognisingOrganisationRepository)
                .findByOrganisationId(Mockito.anyInt());
        doReturn(recognisingOrganisation)
                .when(recognisingOrganisationRepository)
                .save(recognisingOrganisation);
        doReturn(baseEvent)
                .when(organisationCommonUtils)
                .publishUpdateEvent(
                        loadROData.getEventHeaders(),
                        loadROData.getAudit(),
                        recognisingOrganisation);
        assertEquals(
                baseEvent,
                processROHierarchyDomainService.processRecord(loadROData, loadROHierarchyDataV1));
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void when_OnCommandException_ExpectNoException(
            final LoadROData loadROData,
            final LoadROHierarchyDataV1 loadROHierarchyDataV1,
            final RoDataUpdateV1Valid roDataUpdateV1Valid,
            final RecognisingOrganisation recognisingOrganisation,
            final UpdateROVO updateROVO,
            final BaseEvent<BaseHeader> baseEvent)
            throws IOException, JSONException {
        doReturn(roDataUpdateV1Valid)
                .when(loadROHierarchyDataUtils)
                .loadHierarchyData(recognisingOrganisation, loadROHierarchyDataV1);
        doReturn(new HashSet<>())
                .when(updateOrganisationDomainService)
                .validateUpdateRODetails(roDataUpdateV1Valid);
        doReturn(recognisingOrganisation)
                .when(updateOrganisationUtil)
                .populateOrganisation(roDataUpdateV1Valid, recognisingOrganisation, new HashMap<>());
        doReturn(Optional.of(recognisingOrganisation))
                .when(recognisingOrganisationRepository)
                .findByOrganisationId(Mockito.anyInt());
        doThrow(new DataIntegrityViolationException(""))
                .when(recognisingOrganisationRepository)
                .save(recognisingOrganisation);
        Executable executable =
                () ->
                        processROHierarchyDomainService.processRecord(
                                loadROData, loadROHierarchyDataV1);
        assertThrows(DataIntegrityViolationException.class, executable);
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void when_OnCommandRejectedEvent_ExpectRejectedEvent(
            final LoadROData loadROData,
            final LoadROHierarchyDataV1 loadROHierarchyDataV1,
            final RoDataUpdateV1Valid roDataUpdateV1Valid,
            final RecognisingOrganisation recognisingOrganisation,
            final UpdateROVO updateROVO,
            final BaseEvent<BaseHeader> baseEvent)
            throws Exception {
        Set<ConstraintViolation<Object>> violations =
                OrganisationTestUtil.getSetforNullViolationOfEventBody("V0004", "name");
        doReturn(roDataUpdateV1Valid)
                .when(loadROHierarchyDataUtils)
                .loadHierarchyData(recognisingOrganisation, loadROHierarchyDataV1);
        doReturn(Optional.of(recognisingOrganisation))
                .when(recognisingOrganisationRepository)
                .findByOrganisationId(Mockito.anyInt());
        doReturn(violations)
                .when(updateOrganisationDomainService)
                .validateUpdateRODetails(roDataUpdateV1Valid);
        final BaseEvent<BaseHeader> roRejectedEvent =
                LoadROHierarchyDataSetup.getROChangedRejectedEvent();
        doReturn(roRejectedEvent)
                .when(updateOrganisationDomainService)
                .generateRejectedEventResponse(
                        loadROData.getEventHeaders(), roDataUpdateV1Valid, Optional.of(recognisingOrganisation),loadROData.getAudit(), violations, null);
        assertEquals(
                roRejectedEvent,
                processROHierarchyDomainService.processRecord(loadROData, loadROHierarchyDataV1));
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void when_AnyOrgIdDoesntExistsInDB_ThenRejectedEvent_ExpectRejectedEvent(
            final LoadROData loadROData,
            final LoadROHierarchyDataV1 loadROHierarchyDataV1,
            final RoDataUpdateV1Valid roDataUpdateV1Valid,
            final RecognisingOrganisation recognisingOrganisation,
            final UpdateROVO updateROVO,
            final BaseEvent<BaseHeader> baseEvent)
            throws Exception {

        List<ErrorDescription> errorList =
                OrganisationTestUtil.getROErrorResponse(
                                "E0002",
                                "456 Doesn't Exists in Database",
                                "Linked Organisations Failure")
                        .getErrorList();
        errorList.addAll(
                OrganisationTestUtil.getROErrorResponse(
                                "E0002",
                                "123 Doesn't Exists in Database",
                                "Linked Organisations Failure")
                        .getErrorList());
        errorList.addAll(
                OrganisationTestUtil.getROErrorResponse(
                                "E0002",
                                "789 Doesn't Exists in Database",
                                "Linked Organisations Failure")
                        .getErrorList());
        errorList.addAll(
                OrganisationTestUtil.getROErrorResponse(
                                "E0002",
                                "456 Doesn't Exists in Database",
                                "Linked Organisations Failure")
                        .getErrorList());
        doReturn(Optional.empty())
                .when(recognisingOrganisationRepository)
                .findByOrganisationId(Mockito.anyInt());
        assertEquals(
                errorList.size(),
                processROHierarchyDomainService
                        .processRecord(loadROData, loadROHierarchyDataV1)
                        .getEventErrors()
                        .getErrorList()
                        .size());
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void when_OrgIdIsEmpty_ThenRejectedEvent_ExpectRejectedEvent(
        final LoadROData loadROData,
        final LoadROHierarchyDataV1 loadROHierarchyDataV1,
        final RoDataUpdateV1Valid roDataUpdateV1Valid,
        final RecognisingOrganisation recognisingOrganisation,
        final UpdateROVO updateROVO,
        final BaseEvent<BaseHeader> baseEvent)
        throws Exception {

        List<ErrorDescription> errorList =
            OrganisationTestUtil.getROErrorResponse(
                    "E0001",
                    "Organisation ID is empty",
                    "Empty Organisation ID")
                .getErrorList();
        errorList.addAll(
            OrganisationTestUtil.getROErrorResponse(
                    "E0002",
                    "789 Doesn't Exists in Database",
                    "Linked Organisations Failure")
                .getErrorList());
        recognisingOrganisation.setOrganisationId(456);
        doReturn(Optional.of(recognisingOrganisation))
            .when(recognisingOrganisationRepository)
            .findByOrganisationId(Integer.valueOf(loadROHierarchyDataV1.getParentOrganisationId()));

        loadROHierarchyDataV1.setOrganisationId("");
        assertEquals(
            errorList.size(),
            processROHierarchyDomainService
                .processRecord(loadROData, loadROHierarchyDataV1)
                .getEventErrors()
                .getErrorList()
                .size());
    }
    private static Stream<Arguments> argumentsProviderForOrganisationLoadDataEvent()
            throws JsonProcessingException {
        UiHeader roHeaders = OrganisationTestUtil.generateEventHeader();
        roHeaders.setEventName(
                OrganisationConstants.GenericConstants.OPERATION_TYPE_GET
                        + OrganisationConstants.GenericConstants.LOAD_RO_DATA_RESOURCE_TYPE);
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put(OrganisationConstants.GenericConstants.RO_DATA_FILE, "test.csv");
        eventContext.put(OrganisationConstants.GenericConstants.MODE, "update");
        roHeaders.setEventContext(eventContext);
        BaseAudit audit = new BaseAudit();
        final BaseEvent<UiHeader> event = new BaseEvent<UiHeader>(roHeaders, null, null, audit);
        LoadROData loadROData =
                LoadROData.builder()
                        .eventHeaders(event.getEventHeader())
                        .eventErrors(event.getEventErrors())
                        .audit(event.getAudit())
                        .build();
        RoDataUpdateV1Valid roData = UpdateOrganisationDataSetup.updateOrgData();
        final UpdateROVO updateROVO = UpdateROVO.builder().eventBody(roData).build();
        RecognisingOrganisation publishRo =
                UpdateOrganisationDataSetup.getExistingOrganisationDetails(
                        updateROVO.getEventBody(), new RecognisingOrganisation());
        return Stream.of(
                Arguments.of(
                        loadROData,
                        LoadROHierarchyDataSetup.getLoadROHierarchyDataV1List().get(0),
                        roData,
                        publishRo,
                        updateROVO,
                        LoadROHierarchyDataSetup.getROCreatedEvent(publishRo)));
    }
}
