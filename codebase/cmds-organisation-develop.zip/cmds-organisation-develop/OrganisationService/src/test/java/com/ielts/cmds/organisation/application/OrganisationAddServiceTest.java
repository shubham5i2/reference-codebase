package com.ielts.cmds.organisation.application;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.domain.model.RoDataCreateV1Valid;
import com.ielts.cmds.organisation.domain.services.CreateOrganisationDomainService;
import com.ielts.cmds.organisation.utills.CreateOrganisationDataSetup;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OrganisationAddServiceTest {

    @InjectMocks private OrganisationAddService orgAddApplicationService;

    @Mock private CreateOrganisationDomainService createOrgDomainService;

    @Mock private ObjectMapper objectMapper;

    @Mock private OrganisationCommonUtils orgUtils;

    @Captor ArgumentCaptor<RoDataCreateV1Valid> createOrgArg;

    @BeforeEach
    void setUp() throws Exception {
      MockitoAnnotations.initMocks(this);
      ThreadLocalHeaderContext.setContext(OrganisationTestUtil.generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_CREATE_REQUEST_EVENT));
      ThreadLocalAuditContext.setContext(OrganisationTestUtil.getBaseAudit());
    }


  @ParameterizedTest
    @MethodSource("argumentsProviderForOrgCreateEvent")
    void whenValidPayload_thenVerifyDomainCallWithNoException(
            RoDataCreateV1Valid createOrg) throws Exception {
        assertDoesNotThrow(() -> orgAddApplicationService.process(createOrg));
        verify(createOrgDomainService, times(1)).onCommand(createOrg);

        verify(createOrgDomainService).onCommand(createOrgArg.capture());
        assertNotNull(createOrgArg.getValue());
        assertEquals("IDP", createOrgArg.getValue().getPartnerCode());
        
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrgCreateEvent")
    void whenInValidPayload_thenVerifyForException(
            RoDataCreateV1Valid createOrg)
            throws JsonProcessingException, ProcessingException {
        doThrow(RuntimeException.class).when(createOrgDomainService).onCommand(createOrg);
        Executable executable = () -> orgAddApplicationService.process(createOrg);
        ProcessingException processingException =
                assertThrows(ProcessingException.class, executable);
        assertTrue(processingException.getCause() instanceof RuntimeException);
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrgCreateEvent")
    void whenInValidPayload_thenVerifyForJSONException(
            RoDataCreateV1Valid createOrg) throws Exception {
        Executable executable = () -> orgAddApplicationService.process(null);
        ProcessingException processingException =
                assertThrows(ProcessingException.class, executable);
        assertTrue(processingException.getCause() instanceof IllegalArgumentException);
    }

    /*
     * This is method source to provide arguments for the required test cases
     * wherever this method source has been used. It's specific to
     * CreateOrganisation event
     */
    private static Stream<Arguments> argumentsProviderForOrgCreateEvent()
            throws JsonProcessingException {
        final RoDataCreateV1Valid organisationDetailsModel =
                CreateOrganisationDataSetup.createOrgData();
        return Stream.of(Arguments.of(organisationDetailsModel));
    }
}
