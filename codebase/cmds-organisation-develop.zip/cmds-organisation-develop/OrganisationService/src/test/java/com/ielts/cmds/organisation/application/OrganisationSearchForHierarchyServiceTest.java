package com.ielts.cmds.organisation.application;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.roui010rohierarchyrequested.ROHierarchyRequestParam;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.domain.commands.SearchForHierarchy;
import com.ielts.cmds.organisation.domain.services.SearchForHierarchyDomainService;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class OrganisationSearchForHierarchyServiceTest {

    @InjectMocks OrganisationSearchForHierarchy organisationSearchForHierarchy;

    @Mock SearchForHierarchyDomainService searchForHierarchyDomainService;

    @Mock private ObjectMapper objectMapper;

    @Captor ArgumentCaptor<SearchForHierarchy> searchForHierarchyArgumentCaptor;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        ThreadLocalHeaderContext.setContext(OrganisationTestUtil.generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_SEARCH_REQUEST_EVENT));
        ThreadLocalAuditContext.setContext(OrganisationTestUtil.getBaseAudit());
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrgHierarchyEvent")
    void whenValidPayload_thenVerifyDomainCallWithNoException(
            UiHeader header)
            throws Exception {
        UiHeader roHeaders = OrganisationTestUtil.generateEventHeader();
        roHeaders.setEventName(OrganisationConstants.GenericConstants.RO_SEARCH_REQUEST_EVENT);
        ROHierarchyRequestParam eventBody = new ROHierarchyRequestParam();
        eventBody.setRecognisingOrganisationUuid(UUID.fromString("f90b3eee-01f3-4f9c-af05-fd8151738228"));
        organisationSearchForHierarchy.process(eventBody);

        verify(searchForHierarchyDomainService)
                .onCommand(eventBody);
//        assertNotNull(searchForHierarchyArgumentCaptor.getValue().getEventHeaders());
        assertNotNull(
                header
                        .getEventContext()
                        .get("recognisingOrganisationUuid"));
        assertEquals(
                "f90b3eee-01f3-4f9c-af05-fd8151738228",
                header
                        .getEventContext()
                        .get("recognisingOrganisationUuid"));
       // assertEquals(searchForHierarchy, searchForHierarchyArgumentCaptor.getValue());
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrgHierarchyEvent")
    void whenInValidPayload_thenVerifyForException(
            UiHeader orgCmdsEvent)
            throws JsonProcessingException, ProcessingException, RbacValidationException {
        ROHierarchyRequestParam eventBody = new ROHierarchyRequestParam();
        eventBody.setRecognisingOrganisationUuid(UUID.fromString("f90b3eee-01f3-4f9c-af05-fd8151738228"));
        doThrow(RuntimeException.class)
                .when(searchForHierarchyDomainService)
                .onCommand(eventBody);
        Executable executable = () -> organisationSearchForHierarchy.process(null);
        ProcessingException processingException =
                assertThrows(ProcessingException.class, executable);
        assertTrue(processingException.getCause() instanceof RuntimeException);
    }

    private static Stream<Arguments> argumentsProviderForOrgHierarchyEvent()
            throws JsonProcessingException {

        UiHeader orgViewHeaders = OrganisationTestUtil.generateEventHeader();
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put("recognisingOrganisationUuid", "f90b3eee-01f3-4f9c-af05-fd8151738228");
        orgViewHeaders.setEventContext(eventContext);

        orgViewHeaders.setEventName(
                OrganisationConstants.GenericConstants.RO_HIERARCHY_SEARCH_REQUEST_EVENT);
        BaseAudit audit = new BaseAudit();
        final BaseEvent<UiHeader> event =
                new BaseEvent<UiHeader>(orgViewHeaders, null, null, audit);
        SearchForHierarchy searchForHierarchy =
                SearchForHierarchy.builder()
                        .eventHeaders(event.getEventHeader())
                        .eventErrors(event.getEventErrors())
                        .audit(audit)
                        .build();
        return Stream.of(Arguments.of(orgViewHeaders));
    }
}
