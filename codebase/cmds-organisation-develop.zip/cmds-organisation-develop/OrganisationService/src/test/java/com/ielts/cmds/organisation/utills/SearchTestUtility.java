package com.ielts.cmds.organisation.utills;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.h2.tools.Csv;

public class SearchTestUtility {

    // Mocking Postgres similarity function in H2
    public static Double similar(String column, String criteria) {
        return 0.5;
    }

    public static Double nonSimilar(String column, String criteria) {
        return 0.1;
    }

    public static ResultSet exactSearchResults(
            String organisationName, String city, String postalcode) throws SQLException {
        ResultSet resultSet =
                new Csv().read("src/test/resources/full-text-duplicate-search-ro.csv", null, null);
        return resultSet;
    }
    public static ResultSet fuzzySearchResults(
            String organisationName, String city, String postalcode) throws SQLException {
        ResultSet resultSet =
                new Csv().read("src/test/resources/duplicate-search-ro.csv", null, null);
        return resultSet;
    }
}
