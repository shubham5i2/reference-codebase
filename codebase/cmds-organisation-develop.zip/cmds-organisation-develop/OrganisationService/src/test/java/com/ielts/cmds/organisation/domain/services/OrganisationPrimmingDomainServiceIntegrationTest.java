package com.ielts.cmds.organisation.domain.services;

import static org.junit.Assert.assertEquals;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.cache.JedisGenericReader;
import com.ielts.cmds.organisation.cache.factory.JedisFactory;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.organisation.domain.commands.OrganisationPrimmingCommand;
import com.ielts.cmds.organisation.domain.model.OrganisationPrimmingModel;
import com.ielts.cmds.organisation.domain.utils.DomainEventsPublisher;
import com.ielts.cmds.organisation.infrastructure.config.RBACTestConfig;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.transaction.Transactional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = RBACTestConfig.class)
@ActiveProfiles("test")
@Sql({
    "/sql/schema.sql",
    "/sql/organisation-type-data.sql",
    "/sql/partner-data.sql",
    "/sql/address-type-data.sql",
    "/sql/sector-type-data.sql",
    "/sql/product-data.sql",
    "/sql/note-type-data.sql",
    "/sql/contact-type-data.sql",
    "/sql/country-data.sql",
    "/sql/territory-data.sql",
    "/sql/module-type-data.sql",
    "/sql/usergroup-hierarchy.sql",
    "/sql/existing-ro-data.sql",
    "/sql/existing-vo-data.sql"
})
@Transactional
class OrganisationPrimmingDomainServiceIntegrationTest {

    @Autowired OrganisationPrimmingDomainService orgPrimmingDomainService;

    @Autowired RecognisingOrganisationRepository orgRepository;

    @Autowired private OrganisationCommonUtils organisationCommonUtils;

    @MockBean private DomainEventsPublisher domainEventPublisher;

    @Captor ArgumentCaptor<List<BaseEvent<BaseHeader>>> publishedEventCaptor;

    @Autowired ObjectMapper objectMapper;

    @MockBean private JedisGenericReader jedisGenericReader;

    @MockBean private JedisFactory jedisFactory;

    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(
                organisationCommonUtils, "jedisGenericReader", jedisGenericReader);
    }

    @Test
    void whenOrgUuidsInDBArePresentInPrimmingEvent_thenPublishRoChangedEventForEachOrg()
            throws JsonProcessingException {
        OrganisationPrimmingModel eventBody = new OrganisationPrimmingModel();
        List<RecognisingOrganisation> orgsInDB = orgRepository.findAll();
        List<UUID> roUuidsFromDB =
                orgsInDB.stream()
                        .map(RecognisingOrganisation::getRecognisingOrganisationUuid)
                        .collect(Collectors.toList());
        List<UUID> uuidsList = new ArrayList<>();
        for (UUID orgUuid : roUuidsFromDB) {
            uuidsList.add(orgUuid);
        }
        eventBody.setOrganisationsToBePublished(uuidsList);
        OrganisationPrimmingCommand command =
                OrganisationPrimmingCommand.builder()
                        .eventHeaders(OrganisationTestUtil.generateEventHeader())
                        .eventBody(eventBody)
                        .eventErrors(null)
                        .audit(null)
                        .build();
        orgPrimmingDomainService.onCommand(command);
        Mockito.verify(domainEventPublisher).baseEventListPublisher(publishedEventCaptor.capture());
        int roCountInDB = orgsInDB.size();
        List<BaseEvent<BaseHeader>> listOfEvents = publishedEventCaptor.getValue();
        assertEquals(roCountInDB, listOfEvents.size());
    }

    @Test
    void whenOrgUuidOfROInDBIsInPrimmingEvent_thenVerifyRoChangedEvent()
            throws JsonProcessingException {
        OrganisationPrimmingModel eventBody = new OrganisationPrimmingModel();
        Optional<RecognisingOrganisation> orgInDB =
                orgRepository.findById(UUID.fromString("705fc839-5051-4a22-a77d-cf6d734d7d24"));
        List<UUID> uuidsList = new ArrayList<>();
        uuidsList.add(orgInDB.get().getRecognisingOrganisationUuid());
        eventBody.setOrganisationsToBePublished(uuidsList);
        OrganisationPrimmingCommand command =
                OrganisationPrimmingCommand.builder()
                        .eventHeaders(OrganisationTestUtil.generateEventHeader())
                        .eventBody(eventBody)
                        .eventErrors(null)
                        .audit(null)
                        .build();
        orgPrimmingDomainService.onCommand(command);
        Mockito.verify(domainEventPublisher).baseEventListPublisher(publishedEventCaptor.capture());
        List<BaseEvent<BaseHeader>> listOfEvents = publishedEventCaptor.getValue();
        RoChangedEventV1 publishedEvent =
                objectMapper.readValue(listOfEvents.get(0).getEventBody(), RoChangedEventV1.class);
        assertEquals("ROApproved", listOfEvents.get(0).getEventHeader().getEventDiscriminator());
        assertEquals(orgInDB.get().getName(), publishedEvent.getOrganisationName());
        assertEquals(orgInDB.get().getAddresses().size(), publishedEvent.getAddresses().size());
        assertEquals(
                orgInDB.get().getAlternateNames().size(),
                publishedEvent.getAlternateNames().size());
        assertEquals(orgInDB.get().getContacts().size(), publishedEvent.getContacts().size());
        assertEquals(
                orgInDB.get().getContacts().get(0).getAddresses().size(),
                publishedEvent.getContacts().get(0).getAddresses().size());
        assertEquals(
                orgInDB.get().getContacts().get(1).getAddresses().size(),
                publishedEvent.getContacts().get(1).getAddresses().size());
        assertEquals(
                orgInDB.get().getLinkedRecognisingOrganisations().size(),
                publishedEvent.getLinkedOrganisations().size());
        assertEquals(
                orgInDB.get().getMinimumScores().size(), publishedEvent.getMinimumScores().size());
        assertEquals(orgInDB.get().getNotes().size(), publishedEvent.getNotes().size());
        assertEquals(
                orgInDB.get().getRecognisedProducts().size(),
                publishedEvent.getRecognisedProducts().size());
    }

    @Test
    void whenOrgUuidOfVOInDBIsInPrimmingEvent_thenVerifyRoChangedEvent()
            throws JsonProcessingException {
        OrganisationPrimmingModel eventBody = new OrganisationPrimmingModel();
        Optional<RecognisingOrganisation> orgInDB =
                orgRepository.findById(UUID.fromString("d303bc54-d13b-4252-aae6-486cf5a4f1f6"));
        List<UUID> uuidsList = new ArrayList<>();
        uuidsList.add(orgInDB.get().getRecognisingOrganisationUuid());
        eventBody.setOrganisationsToBePublished(uuidsList);
        OrganisationPrimmingCommand command =
                OrganisationPrimmingCommand.builder()
                        .eventHeaders(OrganisationTestUtil.generateEventHeader())
                        .eventBody(eventBody)
                        .eventErrors(null)
                        .audit(null)
                        .build();
        orgPrimmingDomainService.onCommand(command);
        Mockito.verify(domainEventPublisher).baseEventListPublisher(publishedEventCaptor.capture());
        List<BaseEvent<BaseHeader>> listOfEvents = publishedEventCaptor.getValue();
        RoChangedEventV1 publishedEvent =
                objectMapper.readValue(listOfEvents.get(0).getEventBody(), RoChangedEventV1.class);
        assertEquals("VOVerified", listOfEvents.get(0).getEventHeader().getEventDiscriminator());
        assertEquals(orgInDB.get().getName(), publishedEvent.getOrganisationName());
        assertEquals(orgInDB.get().getAddresses().size(), publishedEvent.getAddresses().size());
        assertEquals(
                orgInDB.get().getAlternateNames().size(),
                publishedEvent.getAlternateNames().size());
        assertEquals(orgInDB.get().getContacts().size(), publishedEvent.getContacts().size());
        assertEquals(
                orgInDB.get().getContacts().get(0).getAddresses().size(),
                publishedEvent.getContacts().get(0).getAddresses().size());
        assertEquals(
                orgInDB.get().getContacts().get(1).getAddresses().size(),
                publishedEvent.getContacts().get(1).getAddresses().size());
        assertEquals(
                orgInDB.get().getLinkedRecognisingOrganisations().size(),
                publishedEvent.getLinkedOrganisations().size());
        assertEquals(
                orgInDB.get().getMinimumScores().size(), publishedEvent.getMinimumScores().size());
        assertEquals(orgInDB.get().getNotes().size(), publishedEvent.getNotes().size());
        assertEquals(
                orgInDB.get().getRecognisedProducts().size(),
                publishedEvent.getRecognisedProducts().size());
    }
}
