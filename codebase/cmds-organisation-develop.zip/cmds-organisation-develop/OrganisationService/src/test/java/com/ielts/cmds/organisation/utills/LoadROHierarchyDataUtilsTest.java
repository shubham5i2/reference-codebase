package com.ielts.cmds.organisation.utills;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.doReturn;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.organisation.domain.commands.UpdateROVO;
import com.ielts.cmds.organisation.domain.model.LoadROHierarchyDataV1;
import com.ielts.cmds.organisation.domain.model.RoDataUpdateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.LinkedRecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.LinkedRecognisingOrganisationRepository;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.utils.LoadROHierarchyDataUtils;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.configurationprocessor.json.JSONException;

@ExtendWith(MockitoExtension.class)
class LoadROHierarchyDataUtilsTest {

    @InjectMocks private LoadROHierarchyDataUtils loadROHierarchyDataUtils;

    @Mock private RecognisingOrganisationRepository recognisingOrganisationRepository;

    @Mock private OrganisationCommonUtils organisationCommonUtils;

    @Mock private LinkedRecognisingOrganisationRepository linkedRecognisingOrganisationRepository;

    @ParameterizedTest
    @MethodSource("provideArgumentsForLoadROHierarchyDataUtils")
    void loadData_ExpectValue(RecognisingOrganisation organisation, LoadROHierarchyDataV1 record) throws JSONException, JsonProcessingException {
        doReturn(Optional.of(organisation))
                .when(recognisingOrganisationRepository)
                .findByOrganisationId(Mockito.anyInt());
        List<LinkedRecognisingOrganisation> linkedRecognisingOrganisation = new ArrayList();
        RoDataUpdateV1Valid actual =
                loadROHierarchyDataUtils.loadHierarchyData(organisation, record);
        assertNotNull(actual);
    }
    @ParameterizedTest
    @MethodSource("provideArgumentsForLoadROHierarchyDataUtils")
    void loadData_ExpectValue_ExistingLinkedOgsEmpty(RecognisingOrganisation organisation, LoadROHierarchyDataV1 record) throws JSONException, JsonProcessingException {
        organisation.setLinkedRecognisingOrganisations(new ArrayList<>());
        doReturn(Optional.of(organisation))
                .when(recognisingOrganisationRepository)
                .findByOrganisationId(Mockito.anyInt());
        RoDataUpdateV1Valid actual =
                loadROHierarchyDataUtils.loadHierarchyData(organisation, record);
        assertNotNull(actual);
    }

    private static Stream<Arguments> provideArgumentsForLoadROHierarchyDataUtils() {
        RoDataUpdateV1Valid roData = UpdateOrganisationDataSetup.updateOrgData();
        final UpdateROVO updateROVO = UpdateROVO.builder().eventBody(roData).build();
        RecognisingOrganisation publishRo =
                UpdateOrganisationDataSetup.getExistingOrganisationDetails(
                        updateROVO.getEventBody(), new RecognisingOrganisation());
        return Stream.of(
                Arguments.of(
                        publishRo, LoadROHierarchyDataSetup.getLoadROHierarchyDataV1List().get(0)));
    }
}
