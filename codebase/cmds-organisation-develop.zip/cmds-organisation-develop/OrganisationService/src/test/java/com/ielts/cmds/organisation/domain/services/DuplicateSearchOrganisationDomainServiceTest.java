package com.ielts.cmds.organisation.domain.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.roui005rosearchrequested.RoSearchObject;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.cache.factory.JedisFactory;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1;
import com.ielts.cmds.organisation.infrastructure.entity.RODuplicateExactSearchResult;
import com.ielts.cmds.organisation.infrastructure.entity.RODuplicateFuzzySearchResult;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utills.SearchOrganisationDataSetup;
import com.ielts.cmds.organisation.utils.DuplicateSearchRoEntityToEventMapper;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.api.service.impl.RBACServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.util.ReflectionTestUtils;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.StoredProcedureQuery;
import javax.validation.ValidationException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DuplicateSearchOrganisationDomainServiceTest {

	@InjectMocks @Spy
	private DuplicateSearchOrganisationDomainService duplicateSearchOrganisationDomainService;

	@Mock
	private RBACServiceImpl rbacServiceImpl;

	@Spy private OrganisationCommonUtils orgCommonUtils;

	@Mock
	private EntityManager entityManager;

	@Mock
	private StoredProcedureQuery query;

	@Mock
	private DuplicateSearchRoEntityToEventMapper duplicateSearchRoEntityToEventMapper;

	@Mock private SearchOrganisationDomainService searchOrganisationDomainService;

	@MockBean
	private JedisFactory jedisFactory;

	@BeforeEach
	void setup() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(
				duplicateSearchOrganisationDomainService, "orgUtils", orgCommonUtils);

		ReflectionTestUtils.setField(duplicateSearchOrganisationDomainService, "rbacServiceImpl", rbacServiceImpl);
		ReflectionTestUtils.setField(duplicateSearchOrganisationDomainService, "duplicateSearchRoEntityToEventMapper",
				duplicateSearchRoEntityToEventMapper);
		ReflectionTestUtils.setField(duplicateSearchOrganisationDomainService, "entityManager", entityManager);
		ReflectionTestUtils.setField(duplicateSearchOrganisationDomainService, "searchOrganisationDomainService",
				searchOrganisationDomainService);
		ThreadLocalHeaderContext.setContext(OrganisationTestUtil
				.generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_SEARCH_REQUEST_EVENT));
		ThreadLocalAuditContext.setContext(OrganisationTestUtil.getBaseAudit());
	}

	@DisplayName("Valid Command - No Exception")
	@ParameterizedTest
	@MethodSource("provideArgumentsForFuzzySearchRoCommand")
	void whenReceivedValidWithFuzzySearchTrue_SearchRoCommand_thenNoException(final RoSearchObject roSearchObject,
			final RODuplicateFuzzySearchResult roDuplicateSearchResult) throws RbacValidationException {

		doReturn(true).when(rbacServiceImpl).isAuthorised(ThreadLocalHeaderContext.getContext().getXaccessToken(),
				OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION);
		doReturn(query).when(entityManager).createNamedStoredProcedureQuery("getFuzzySearchResults");
		doReturn(query).when(query).setParameter("_org_name",
				roSearchObject.getCriteria().getOrganisationName());
		doReturn(query).when(query).setParameter("_city_name", roSearchObject.getCriteria().getCity());
		doReturn(query).when(query).setParameter("_postal_code",
				roSearchObject.getCriteria().getPostalCode());

		doReturn(true).when(query).execute();
		UiHeader header = orgCommonUtils.buildUiHeader();
		List<RODuplicateFuzzySearchResult> orgList = new ArrayList<>();
		orgList.add(roDuplicateSearchResult);
		doReturn(orgList).when(query).getResultList();
		RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1 = new RosSearchResultsGeneratedEventV1();
		doReturn(new RosSearchResultsGeneratedEventV1()).when(duplicateSearchRoEntityToEventMapper)
				.mapEntityToEventForFuzzySearch(roSearchObject, orgList);
		/*doNothing().when(searchOrganisationDomainService).publishSearchRoResponse(rosSearchResultsGeneratedEventV1,
				header, orgCommonUtils.getBaseAudit());
*/
		duplicateSearchOrganisationDomainService.onCommand(roSearchObject);
		verify(query, times(1)).execute();
		verify(query, times(1)).getResultList();
		verify(duplicateSearchRoEntityToEventMapper).mapEntityToEventForFuzzySearch(roSearchObject, orgList);

	}

	@DisplayName("Valid Command - No Exception")
	@ParameterizedTest
	@MethodSource("provideArgumentsForFullTextSearchRoCommand")
	void whenReceivedValidwithFuzzySearchFalse_SearchRoCommand_thenNoException(final RoSearchObject roSearchObject,
			final RODuplicateExactSearchResult roDuplicateSearchResult) throws RbacValidationException {

		roSearchObject.getCriteria().setFuzzyMatch(false);
		doReturn(true).when(rbacServiceImpl).isAuthorised(ThreadLocalHeaderContext.getContext().getXaccessToken(),
				OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION);
		doReturn(query).when(entityManager).createNamedStoredProcedureQuery("getExactSearchResults");
		doReturn(query).when(query).setParameter("_org_name",
				(roSearchObject.getCriteria().getOrganisationName() != null)
						? "%" + roSearchObject.getCriteria().getOrganisationName().toLowerCase() + "%"
						: "NULL");
		doReturn(query).when(query).setParameter("_city_name",
				(roSearchObject.getCriteria().getCity() != null)
						? "%" + roSearchObject.getCriteria().getCity().toLowerCase() + "%"
						: "NULL");
		doReturn(query).when(query).setParameter("_postal_code",
				roSearchObject.getCriteria().getPostalCode());

		doReturn(true).when(query).execute();

		List<RODuplicateExactSearchResult> orgList = new ArrayList<>();
		orgList.add(roDuplicateSearchResult);

		UiHeader header = orgCommonUtils.buildUiHeader();

		doReturn(orgList).when(query).getResultList();
		RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1 = new RosSearchResultsGeneratedEventV1();
		doReturn(new RosSearchResultsGeneratedEventV1()).when(duplicateSearchRoEntityToEventMapper)
				.mapEntityToEventForFullTextSearch(roSearchObject, orgList);

		duplicateSearchOrganisationDomainService.onCommand(roSearchObject);
		verify(query, times(1)).execute();
		verify(query, times(1)).getResultList();
		verify(duplicateSearchRoEntityToEventMapper).mapEntityToEventForFullTextSearch(roSearchObject, orgList);

	}

	@DisplayName("UnAuthorised User - Validation Exception")
	@ParameterizedTest
	@MethodSource("provideArgumentsForFuzzySearchRoCommand")
	void whenReceivedValid_SearchRoCommand_UnauthorisedUser_thenValidationException(final RoSearchObject roSearchObject)
			throws RbacValidationException {

		doReturn(false).when(rbacServiceImpl).isAuthorised(ThreadLocalHeaderContext.getContext().getXaccessToken(),
				OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION);

		Executable executable = () -> duplicateSearchOrganisationDomainService.onCommand(roSearchObject);

		ValidationException exception = assertThrows(ValidationException.class, executable);
		assertEquals(OrganisationConstants.ErrorResponse.CANNOT_PERFORM_SEARCH, exception.getMessage());
	}

	@DisplayName("Valid Command Db Exception")
	@ParameterizedTest
	@MethodSource("provideArgumentsForFuzzySearchRoCommand")
	void whenReceivedValidwithFuzzySearchTrue_SearchRoCommandDbException_thenNoException(final RoSearchObject roSearchObject)
			throws RbacValidationException {

		doReturn(true).when(rbacServiceImpl).isAuthorised(ThreadLocalHeaderContext.getContext().getXaccessToken(),
				OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION);
		doReturn(query).when(entityManager).createNamedStoredProcedureQuery("getFuzzySearchResults");
		doReturn(query).when(query).setParameter("_org_name",
				roSearchObject.getCriteria().getOrganisationName());
		doReturn(query).when(query).setParameter("_city_name", roSearchObject.getCriteria().getCity());
		doReturn(query).when(query).setParameter("_postal_code",
				roSearchObject.getCriteria().getPostalCode());

		doThrow(PersistenceException.class).when(query).execute();

		assertThrows(PersistenceException.class, () -> duplicateSearchOrganisationDomainService.onCommand(roSearchObject));
		verify(query, never()).getResultList();
	}

	@DisplayName("Valid Command Db Exception")
	@ParameterizedTest
	@MethodSource("provideArgumentsForFullTextSearchRoCommand")
	void whenReceivedValidWithFuzzySearchFalse_SearchRoCommandDbException_thenNoException(final RoSearchObject roSearchObject)
			throws RbacValidationException {

		roSearchObject.getCriteria().setFuzzyMatch(false);
		doReturn(true).when(rbacServiceImpl).isAuthorised(ThreadLocalHeaderContext.getContext().getXaccessToken(),
				OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION);
		doReturn(query).when(entityManager).createNamedStoredProcedureQuery("getExactSearchResults");
		doReturn(query).when(query).setParameter("_org_name",
				(roSearchObject.getCriteria().getOrganisationName() != null)
						? "%" + roSearchObject.getCriteria().getOrganisationName().toLowerCase() + "%"
						: "NULL");
		doReturn(query).when(query).setParameter("_city_name",
				(roSearchObject.getCriteria().getCity() != null)
						? "%" + roSearchObject.getCriteria().getCity().toLowerCase() + "%"
						: "NULL");
		doReturn(query).when(query).setParameter("_postal_code",
				roSearchObject.getCriteria().getPostalCode());

		doThrow(PersistenceException.class).when(query).execute();

		assertThrows(PersistenceException.class, () -> duplicateSearchOrganisationDomainService.onCommand(roSearchObject));
		verify(query, never()).getResultList();
	}

	private static Stream<Arguments> provideArgumentsForFuzzySearchRoCommand() throws JsonProcessingException {

		final RoSearchObject roSearchObject = SearchOrganisationDataSetup.getRoSearchData();
		roSearchObject.setSorting(null);
		UiHeader uiHeaders = OrganisationTestUtil.generateEventHeader();
		uiHeaders.setEventName(OrganisationConstants.GenericConstants.RO_SEARCH_REQUEST_EVENT);
		final RODuplicateFuzzySearchResult roDuplicateSearchResult = SearchOrganisationDataSetup
				.getRoDuplicateSearchResult();

		return Stream.of(Arguments.of(roSearchObject, roDuplicateSearchResult));
	}

	private static Stream<Arguments> provideArgumentsForFullTextSearchRoCommand() throws JsonProcessingException {

		final RoSearchObject roSearchObject = SearchOrganisationDataSetup.getRoSearchData();
		roSearchObject.setSorting(null);
		UiHeader uiHeaders = OrganisationTestUtil.generateEventHeader();
		uiHeaders.setEventName(OrganisationConstants.GenericConstants.RO_SEARCH_REQUEST_EVENT);
		final RODuplicateExactSearchResult roDuplicateSearchResult = SearchOrganisationDataSetup
				.getRoDuplicateFullTextSearchResult();

		return Stream.of(Arguments.of(roSearchObject, roDuplicateSearchResult));
	}
}
