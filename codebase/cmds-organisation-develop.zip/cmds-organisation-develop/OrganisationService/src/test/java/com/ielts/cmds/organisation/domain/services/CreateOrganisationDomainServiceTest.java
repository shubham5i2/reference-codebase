package com.ielts.cmds.organisation.domain.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.roui007rocreaterequested.LinkTypeEnum;
import com.ielts.cmds.api.roui007rocreaterequested.VerificationStatusEnum;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.cache.JedisGenericReader;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.organisation.domain.model.RoDataCreateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.*;
import com.ielts.cmds.organisation.infrastructure.repository.*;
import com.ielts.cmds.organisation.utills.CreateOrganisationDataSetup;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utills.ProductDataSetUp;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.rbac.api.service.RBACService;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.util.ReflectionTestUtils;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import java.util.*;
import java.util.stream.Stream;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@RunWith(MockitoJUnitRunner.class)
class CreateOrganisationDomainServiceTest {

    @InjectMocks private CreateOrganisationDomainService createOrgDomainService;

    @Mock private RecognisingOrganisationRepository recognisingOrganisationRepository;

    @Mock private ObjectMapper objectMapper;

    @Spy private OrganisationCommonUtils orgCommonUtils;

    @Mock private ApplicationEventPublisher applicationEventPublisher;

    @Mock private ContactTypeRepository contactTypeRepository;

    @Mock private NoteTypeRepository noteTypeRepository;

    @Mock private TerritoryRepository territoryRepository;

    @Mock private CountryRepository countryRepository;

    @Mock private SectorTypeRepository sectorTypeRepository;

    @Mock private AddressTypeRepository addressTypeRepository;

    @Captor private ArgumentCaptor<RecognisingOrganisation> recognisingOrgCapt;

    @Captor private ArgumentCaptor<BaseEvent<BaseHeader>> roChangedEventCaptor;
    @Mock private Validator roValidator;
    @Mock private CMDSErrorResolver<Object> errorResolver;
    @Captor private ArgumentCaptor<Set<ConstraintViolation<Object>>> violationSetCapt;
    @Mock private RBACService rbacService;
    @Mock private OrganisationTypeRepository orgTypeRepository;
    @Mock private LinkedRecognisingOrganisationRepository linkedRORepository;
    @Mock private JedisGenericReader jedisGenericReader;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(createOrgDomainService, "orgUtils", orgCommonUtils);
        ReflectionTestUtils.setField(
                createOrgDomainService, "orgRepository", recognisingOrganisationRepository);
        ReflectionTestUtils.setField(orgCommonUtils, "noteTypeRepository", noteTypeRepository);
        ReflectionTestUtils.setField(
                orgCommonUtils, "contactTypeRepository", contactTypeRepository);
        ReflectionTestUtils.setField(orgCommonUtils, "territoryRepository", territoryRepository);
        ReflectionTestUtils.setField(createOrgDomainService, "errorResolver", errorResolver);
        ReflectionTestUtils.setField(createOrgDomainService, "roValidator", roValidator);
        ReflectionTestUtils.setField(orgCommonUtils, "countryRepository", countryRepository);
        ReflectionTestUtils.setField(orgCommonUtils, "sectorTypeRepository", sectorTypeRepository);
        ReflectionTestUtils.setField(
                orgCommonUtils, "organisationTypeRepository", orgTypeRepository);
        ReflectionTestUtils.setField(
                orgCommonUtils, "addressTypeRepository", addressTypeRepository);
        ReflectionTestUtils.setField(
                createOrgDomainService, "orgTypeRepository", orgTypeRepository);
        ReflectionTestUtils.setField(orgCommonUtils, "rbacService", rbacService);
        ReflectionTestUtils.setField(
                orgCommonUtils, "orgRepository", recognisingOrganisationRepository);
        ReflectionTestUtils.setField(
                orgCommonUtils, "linkedRecognisingOrganisationRepository", linkedRORepository);
        ReflectionTestUtils.setField(orgCommonUtils, "jedisGenericReader", jedisGenericReader);
        ThreadLocalHeaderContext.setContext(OrganisationTestUtil.generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_CREATE_REQUEST_EVENT));
        ThreadLocalAuditContext.setContext(OrganisationTestUtil.getBaseAudit());
    }

    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForCreateOrgCommand")
    void whenReceivedValid_CreateOrgCommand_thenNoException(
            final RoDataCreateV1Valid roDataCreateV1,
            final RoChangedEventV1 roChangedEventV1,
            final RecognisingOrganisation organisation,
            final NoteType noteType,
            final ContactType contactType)
            throws RbacValidationException {

        Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
        roDataCreateV1.setLinkedOrganisations(null);
        OrganisationType organisationType = CreateOrganisationDataSetup.getOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        orgType,
                        OrganisationConstants.GenericConstants.CREATE,
                        ThreadLocalAuditContext.getContext()))
                .thenReturn(violationSet);
        when(createOrgDomainService.validateRODetails(roDataCreateV1))
                .thenReturn(violationSet);
        when(noteTypeRepository.findByNotesType("Internal")).thenReturn(noteType);
        lenient()
                .when(recognisingOrganisationRepository.save(organisation))
                .thenReturn(organisation);
        createOrgDomainService.onCommand(roDataCreateV1);
        // verify DAO Call
        verify(recognisingOrganisationRepository, times(1)).save(recognisingOrgCapt.capture());
        assertNotNull(recognisingOrgCapt.getValue().getAddresses());
        assertEquals("McGill University", recognisingOrgCapt.getValue().getName());
        assertEquals("UCAS231", recognisingOrgCapt.getValue().getOrganisationCode());
        assertEquals(
                "3", String.valueOf(recognisingOrgCapt.getValue().getResultAvailableForYears()));
    }

    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForCreateOrgCommand")
    void whenReceivedValid_CreateOrgCommand_thenVerifyPublishEvent(
            final RoDataCreateV1Valid roDataCreateV1,
            final RoChangedEventV1 roChangedEventV1,
            final RecognisingOrganisation organisation,
            final NoteType noteType,
            final ContactType contactType,
            final Territory territory) {

        OrganisationType organisationType = CreateOrganisationDataSetup.getOrganisationTypeData();
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        List<Territory> territories = new ArrayList<>();
        territories.add(territory);
        when(territoryRepository.findAll()).thenReturn(territories);
        List<Country> countries = new ArrayList<>();
        countries.add(CreateOrganisationDataSetup.getCountryData());
        when(countryRepository.findAll()).thenReturn(countries);
        List<ContactType> contactTypeList = new ArrayList<>();
        contactTypeList.add(CreateOrganisationDataSetup.getContactTypeData());
        doReturn(contactTypeList).when(contactTypeRepository).findAll();
        Contact contact = new Contact();
        contact.setFirstName("Alan");
        RoChangedEventV1 roCreated = orgCommonUtils.entityToEventMapper(organisation);
        assertEquals("McGill University", roCreated.getOrganisationName());
        assertEquals(roCreated.getOrganisationCode(), organisation.getOrganisationCode());
        assertEquals(2, roCreated.getAddresses().size());
        assertEquals(2, roCreated.getAlternateNames().size());
        assertEquals(2, roCreated.getMinimumScores().size());
        assertEquals(2, roCreated.getNotes().size());
        assertEquals(2, roCreated.getContacts().size());
        assertEquals(4, roCreated.getRecognisedProducts().size());
        assertEquals(
                territory.getTerritoryIsoCode(),
                roCreated.getAddresses().get(0).getTerritoryIsoCode());
        assertEquals("3", String.valueOf(roCreated.getResultAvailableForYears()));
    }

    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForCreateOrgCommand")
    void whenReceivedInValid_CreateOrgCommand_thenRejectedEvent(
            final RoDataCreateV1Valid roDataCreateV1,
            final RoChangedEventV1 roChangedEventV1,
            final RecognisingOrganisation organisation,
            final NoteType noteType,
            final ContactType contactType)
            throws RbacValidationException {

        roDataCreateV1.setOrganisationName("");
        roDataCreateV1.setLinkedOrganisations(null);
        Set<ConstraintViolation<Object>> violationSet =
                OrganisationTestUtil.getSetforNullViolationOfEventBody("V0004", "name");
        OrganisationType organisationType = CreateOrganisationDataSetup.getOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        orgType,
                        OrganisationConstants.GenericConstants.CREATE,
                ThreadLocalAuditContext.getContext()))
                .thenReturn(new HashSet<>());
        when(createOrgDomainService.validateRODetails(roDataCreateV1))
                .thenReturn(violationSet);
        CMDSErrorResponse cmdsErrorResponse =
                OrganisationTestUtil.getROErrorResponse(
                        "V0004",
                        "Organisation Name is empty",
                        OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT);
        when(errorResolver.populatErrorResponse(
                        violationSet, OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT))
                .thenReturn(cmdsErrorResponse);
        createOrgDomainService.onCommand(roDataCreateV1);
        // verify DAO Call
        verify(recognisingOrganisationRepository, times(0)).save(recognisingOrgCapt.capture());
        ThreadLocalHeaderContext.getContext().setEventName("RoRejected");
          // verify(applicationEventPublisher, times(1)).publishEvent(event);
        verify(errorResolver, times(1))
                .populatErrorResponse(
                        violationSetCapt.capture(),
                        Mockito.eq(OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT));
        assertNotNull(violationSetCapt.getValue().iterator().next().getMessage());
        assertEquals("V0004", violationSetCapt.getValue().iterator().next().getMessage());
    }

    @DisplayName("Organisation Type Invalid- Exception Test")
    @ParameterizedTest
    @MethodSource("provideArgumentsForCreateOrgCommand")
    void whenReceivedValid_CreateRoCommand_WithOrganisationTypeInvalid_thenRejectEvent(
            final RoDataCreateV1Valid roDataCreateV1,
            final RoChangedEventV1 roChangedEventV1,
            final RecognisingOrganisation organisation,
            final NoteType noteType,
            final ContactType contactType) {
        Set<ConstraintViolation<Object>> constraintViolation =
                orgCommonUtils.getSetforNullViolationOfEventBody("V0001", "organisationTypeUuid");
        CMDSErrorResponse cmdsErrorResponse =
                OrganisationTestUtil.getROErrorResponse(
                        "V0001",
                        "Organisation Type is not valid.",
                        OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT);

        when(errorResolver.populatErrorResponse(constraintViolation, "RoRejected"))
                .thenReturn(cmdsErrorResponse);
        createOrgDomainService.onCommand(roDataCreateV1);
        verify(errorResolver, times(1))
                .populatErrorResponse(violationSetCapt.capture(), Mockito.eq("RoRejected"));
        ThreadLocalHeaderContext.getContext().setEventName("RoRejected");
            //verify(applicationEventPublisher, times(1)).publishEvent(event);
        assertNotNull(violationSetCapt.getValue().iterator().next().getMessage());
        assertEquals("V0001", violationSetCapt.getValue().iterator().next().getMessage());
    }

    @DisplayName("Organisation Type null- Exception Test")
    @ParameterizedTest
    @MethodSource("provideArgumentsForCreateOrgCommand")
    void whenReceivedValid_CreateRoCommand_WithOrganisationTypeNull_thenRejectEvent(
            final RoDataCreateV1Valid roDataCreateV1,
            final RoChangedEventV1 roChangedEventV1,
            final RecognisingOrganisation organisation,
            final NoteType noteType,
            final ContactType contactType) {
        roDataCreateV1.setOrganisationTypeUuid(null);
        Set<ConstraintViolation<Object>> constraintViolation =
                orgCommonUtils.getSetforNullViolationOfEventBody("V0001", "organisationTypeUuid");
        CMDSErrorResponse cmdsErrorResponse =
                OrganisationTestUtil.getROErrorResponse(
                        "V0001",
                        "Organisation Type is not valid.",
                        OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT);

        when(errorResolver.populatErrorResponse(constraintViolation, "RoRejected"))
                .thenReturn(cmdsErrorResponse);
        createOrgDomainService.onCommand(roDataCreateV1);
        verify(errorResolver, times(1))
                .populatErrorResponse(violationSetCapt.capture(), Mockito.eq("RoRejected"));
        assertNotNull(violationSetCapt.getValue().iterator().next().getMessage());
        assertEquals("V0001", violationSetCapt.getValue().iterator().next().getMessage());
    }

    @DisplayName("Unauthorised User - CreateRO - Exception Test")
    @ParameterizedTest
    @MethodSource("provideArgumentsForCreateOrgCommand")
    void whenReceivedValid_CreateRoCommand_WithUnauthorisedUser_thenRejectEvent(
            final RoDataCreateV1Valid roDataCreateV1,
            final RoChangedEventV1 roChangedEventV1,
            final RecognisingOrganisation organisation,
            final NoteType noteType,
            final ContactType contactType)
            throws RbacValidationException {
        Set<ConstraintViolation<Object>> constraintViolation =
                orgCommonUtils.getSetforNullViolationOfEventBody("V0017", "UnauthorisedToCreateRO");
        OrganisationType organisationType = CreateOrganisationDataSetup.getOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        orgType,
                        OrganisationConstants.GenericConstants.CREATE,
                ThreadLocalAuditContext.getContext()))
                .thenReturn(constraintViolation);
        CMDSErrorResponse cmdsErrorResponse =
                OrganisationTestUtil.getROErrorResponse(
                        "V0017",
                        "You do not have permission to create a RO.",
                        OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT);

        when(errorResolver.populatErrorResponse(constraintViolation, "RoRejected"))
                .thenReturn(cmdsErrorResponse);
        createOrgDomainService.onCommand(roDataCreateV1);
        verify(errorResolver, times(1))
                .populatErrorResponse(violationSetCapt.capture(), Mockito.eq("RoRejected"));
        assertNotNull(violationSetCapt.getValue().iterator().next().getMessage());
        assertEquals("V0017", violationSetCapt.getValue().iterator().next().getMessage());
    }

    @DisplayName("Unauthorised User - CreateVO - Exception Test")
    @ParameterizedTest
    @MethodSource("provideArgumentsForCreateOrgCommand")
    void whenReceivedValid_CreateVoCommand_WithUnauthorisedUser_thenRejectEvent(
            final RoDataCreateV1Valid roDataCreateV1,
            final RoChangedEventV1 roChangedEventV1,
            final RecognisingOrganisation organisation,
            final NoteType noteType,
            final ContactType contactType)
            throws RbacValidationException {
           roDataCreateV1.setOrganisationTypeUuid(
                UUID.fromString("e392ae7c-016f-433a-bdfa-b79bfcdddf26"));
        Set<ConstraintViolation<Object>> constraintViolation =
                orgCommonUtils.getSetforNullViolationOfEventBody("V0018", "UnauthorisedToCreateVO");
        OrganisationType organisationType = CreateOrganisationDataSetup.getOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        orgType,
                        OrganisationConstants.GenericConstants.CREATE,
                ThreadLocalAuditContext.getContext()))
                .thenReturn(constraintViolation);
        CMDSErrorResponse cmdsErrorResponse =
                OrganisationTestUtil.getROErrorResponse(
                        "V0018",
                        "You do not have permission to create a VO.",
                        OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT);

        when(errorResolver.populatErrorResponse(constraintViolation, "RoRejected"))
                .thenReturn(cmdsErrorResponse);
        createOrgDomainService.onCommand(roDataCreateV1);
        verify(errorResolver, times(1))
                .populatErrorResponse(violationSetCapt.capture(), Mockito.eq("RoRejected"));
        assertNotNull(violationSetCapt.getValue().iterator().next().getMessage());
        assertEquals("V0018", violationSetCapt.getValue().iterator().next().getMessage());
    }

    @DisplayName("ResultsDeliveryButNotHavingParent - CreateRO - Exception Test")
    @ParameterizedTest
    @MethodSource("provideArgumentsForCreateOrgCommand")
    void whenReceivedValid_CreateROCommand_WithResultsDeliveryButNotHavingParent_thenRejectEvent(
            final RoDataCreateV1Valid roDataCreateV1,
            final RoChangedEventV1 roChangedEventV1,
            final RecognisingOrganisation organisation,
            final NoteType noteType,
            final ContactType contactType)
            throws RbacValidationException {
        Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
        roDataCreateV1
                .getLinkedOrganisations()
                .get(0)
                .setLinkType(LinkTypeEnum.valueOf(LinkTypeEnum.RESULTS_DELIVERY.getValue()));
        Set<ConstraintViolation<Object>> constraintViolation =
                orgCommonUtils.getSetforNullViolationOfEventBody("V0063", "ParentNotSelected");
        OrganisationType organisationType = CreateOrganisationDataSetup.getOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        orgType,
                        OrganisationConstants.GenericConstants.CREATE,
                ThreadLocalAuditContext.getContext()))
                .thenReturn(violationSet);
        CMDSErrorResponse cmdsErrorResponse =
                OrganisationTestUtil.getROErrorResponse(
                        "V0063",
                        "Parent Must be added to add Additional Delivery organisations",
                        OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT);
        //doReturn(new BaseAudit()).when(orgCommonUtils).getBaseAudit();
        when(errorResolver.populatErrorResponse(constraintViolation, "RoRejected"))
                .thenReturn(cmdsErrorResponse);
        createOrgDomainService.onCommand(roDataCreateV1);
        verify(errorResolver, times(1))
                .populatErrorResponse(violationSetCapt.capture(), Mockito.eq("RoRejected"));
        assertNotNull(violationSetCapt.getValue().iterator().next().getMessage());
        assertEquals("V0063", violationSetCapt.getValue().iterator().next().getMessage());
    }

    @DisplayName("AdditionalDeliveryOrganisation - NotInHierarchy - Exception Test")
    @ParameterizedTest
    @MethodSource("provideArgumentsForCreateOrgCommand")
    void whenReceivedValid_CreateROCommand_WithResultsDeliveryNotInOrganisation_thenRejectEvent(
            final RoDataCreateV1Valid roDataCreateV1,
            final RoChangedEventV1 roChangedEventV1,
            final RecognisingOrganisation organisation,
            final NoteType noteType,
            final ContactType contactType)
            throws RbacValidationException {
        Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
        Set<ConstraintViolation<Object>> constraintViolation =
                orgCommonUtils.getSetforNullViolationOfEventBody(
                        "V0064", "DeliveryOrganisationsNotInHierarchy");
        OrganisationType organisationType = CreateOrganisationDataSetup.getOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        orgType,
                        OrganisationConstants.GenericConstants.CREATE,
                ThreadLocalAuditContext.getContext()))
                .thenReturn(violationSet);
        CMDSErrorResponse cmdsErrorResponse =
                OrganisationTestUtil.getROErrorResponse(
                        "V0064",
                        "Additional Delivery organisations must be in Hierarchy List",
                        OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT);
        when(errorResolver.populatErrorResponse(constraintViolation, "RoRejected"))
                .thenReturn(cmdsErrorResponse);
        createOrgDomainService.onCommand(roDataCreateV1);

        verify(errorResolver, times(1))
                .populatErrorResponse(violationSetCapt.capture(), Mockito.eq("RoRejected"));
        assertNotNull(violationSetCapt.getValue().iterator().next().getMessage());
        assertEquals("V0064", violationSetCapt.getValue().iterator().next().getMessage());
    }

    @DisplayName("IELTSDISPLAYFlag True - CreateVO ")
    @ParameterizedTest
    @MethodSource("provideArgumentsForCreateOrgCommand")
    void whenReceived_CreateVOCommand_WithIELTSFlagNull_thenSetDefaultTrue(
            final RoDataCreateV1Valid roDataCreateV1,
            final RoChangedEventV1 roChangedEventV1,
            final RecognisingOrganisation organisation,
            final NoteType noteType,
            final ContactType contactType)
            throws RbacValidationException {
       roDataCreateV1.setOrganisationTypeUuid(
                UUID.fromString("e392ae7c-016f-433a-bdfa-b79bfcdddf26"));
        roDataCreateV1.setVerificationStatus(VerificationStatusEnum.valueOf("VERIFIED"));
        roDataCreateV1.setIeltsDisplayFlag(null);
        Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
        roDataCreateV1.setLinkedOrganisations(null);
        OrganisationType organisationType = CreateOrganisationDataSetup.getOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        orgType,
                        OrganisationConstants.GenericConstants.CREATE,
                ThreadLocalAuditContext.getContext()))
                .thenReturn(violationSet);
        when(createOrgDomainService.validateRODetails(roDataCreateV1))
                .thenReturn(violationSet);
        when(noteTypeRepository.findByNotesType("Internal")).thenReturn(noteType);
        lenient()
                .when(recognisingOrganisationRepository.save(organisation))
                .thenReturn(organisation);
        createOrgDomainService.onCommand(roDataCreateV1);
        // verify DAO Call
        verify(recognisingOrganisationRepository, times(1)).save(recognisingOrgCapt.capture());
        assertEquals(Boolean.TRUE, recognisingOrgCapt.getValue().getIeltsDisplayFlag());
    }

    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForCreateOrgCommand")
    void testSaveRecognisingOrganisationWithIOLTrueSSRTrueACTrueGTFalse(
            final RoDataCreateV1Valid roDataCreateV1,
            final RoChangedEventV1 roChangedEventV1,
            final RecognisingOrganisation organisation,
            final NoteType noteType,
            final ContactType contactType)
            throws RbacValidationException, JsonProcessingException {

        Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
        roDataCreateV1.setLinkedOrganisations(null);
        roDataCreateV1.setAcceptsIOL(true);
        roDataCreateV1.setAcceptsSSR(true);
        roDataCreateV1.setAcceptsAC(true);
        roDataCreateV1.setAcceptsGT(false);
        OrganisationType organisationType = CreateOrganisationDataSetup.getOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                ThreadLocalHeaderContext.getContext().getXaccessToken(),
                orgType,
                OrganisationConstants.GenericConstants.CREATE,
                ThreadLocalAuditContext.getContext()))
                .thenReturn(violationSet);
        when(createOrgDomainService.validateRODetails(roDataCreateV1))
                .thenReturn(violationSet);
        when(noteTypeRepository.findByNotesType("Internal")).thenReturn(noteType);
        lenient()
                .when(recognisingOrganisationRepository.save(organisation))
                .thenReturn(organisation);
        createOrgDomainService.onCommand(roDataCreateV1);
        // verify DAO Call
        verify(recognisingOrganisationRepository, times(1)).save(recognisingOrgCapt.capture());
        assertNotNull(recognisingOrgCapt.getValue().getAddresses());
        assertEquals(0, recognisingOrgCapt.getValue().getRecognisedProducts().size());

    }
    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForCreateOrgCommand")
    void testSaveRecognisingOrganisationWithIOLTrueSSRTrueACFalseGTTrue(
            final RoDataCreateV1Valid roDataCreateV1,
            final RoChangedEventV1 roChangedEventV1,
            final RecognisingOrganisation organisation,
            final NoteType noteType,
            final ContactType contactType)
            throws RbacValidationException, JsonProcessingException {

        Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
        roDataCreateV1.setLinkedOrganisations(null);
        roDataCreateV1.setAcceptsIOL(true);
        roDataCreateV1.setAcceptsSSR(true);
        roDataCreateV1.setAcceptsAC(false);
        roDataCreateV1.setAcceptsGT(true);
        OrganisationType organisationType = CreateOrganisationDataSetup.getOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                ThreadLocalHeaderContext.getContext().getXaccessToken(),
                orgType,
                OrganisationConstants.GenericConstants.CREATE,
                ThreadLocalAuditContext.getContext()))
                .thenReturn(violationSet);
        when(createOrgDomainService.validateRODetails(roDataCreateV1))
                .thenReturn(violationSet);
        when(noteTypeRepository.findByNotesType("Internal")).thenReturn(noteType);
        lenient()
                .when(recognisingOrganisationRepository.save(organisation))
                .thenReturn(organisation);
        createOrgDomainService.onCommand(roDataCreateV1);
        // verify DAO Call
        verify(recognisingOrganisationRepository, times(1)).save(recognisingOrgCapt.capture());
        assertNotNull(recognisingOrgCapt.getValue().getAddresses());
        assertEquals(0, recognisingOrgCapt.getValue().getRecognisedProducts().size());

    }
    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForCreateOrgCommand")
    void testSaveRecognisingOrganisationWithIOLFalseSSRTrueACTrueGTTrue(
            final RoDataCreateV1Valid roDataCreateV1,
            final RoChangedEventV1 roChangedEventV1,
            final RecognisingOrganisation organisation,
            final NoteType noteType,
            final ContactType contactType)
            throws RbacValidationException, JsonProcessingException {

        Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
        roDataCreateV1.setLinkedOrganisations(null);
        roDataCreateV1.setAcceptsIOL(false);
        roDataCreateV1.setAcceptsSSR(true);
        roDataCreateV1.setAcceptsAC(true);
        roDataCreateV1.setAcceptsGT(true);
        OrganisationType organisationType = CreateOrganisationDataSetup.getOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                ThreadLocalHeaderContext.getContext().getXaccessToken(),
                orgType,
                OrganisationConstants.GenericConstants.CREATE,
                ThreadLocalAuditContext.getContext()))
                .thenReturn(violationSet);
        when(createOrgDomainService.validateRODetails(roDataCreateV1))
                .thenReturn(violationSet);
        when(noteTypeRepository.findByNotesType("Internal")).thenReturn(noteType);
        lenient()
                .when(recognisingOrganisationRepository.save(organisation))
                .thenReturn(organisation);
        createOrgDomainService.onCommand(roDataCreateV1);
        // verify DAO Call
        verify(recognisingOrganisationRepository, times(1)).save(recognisingOrgCapt.capture());
        assertNotNull(recognisingOrgCapt.getValue().getAddresses());
        assertEquals(0, recognisingOrgCapt.getValue().getRecognisedProducts().size());

    }
    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForCreateOrgCommand")
    void testSaveRecognisingOrganisationWithIOLFalseSSRTrueACTrueGTFalse(
                    final RoDataCreateV1Valid roDataCreateV1,
                    final RoChangedEventV1 roChangedEventV1,
                    final RecognisingOrganisation organisation,
                    final NoteType noteType,
                    final ContactType contactType)
            throws RbacValidationException, JsonProcessingException {

        Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
        roDataCreateV1.setLinkedOrganisations(null);
        roDataCreateV1.setAcceptsIOL(false);
        roDataCreateV1.setAcceptsSSR(true);
        roDataCreateV1.setAcceptsAC(true);
        roDataCreateV1.setAcceptsGT(false);
        OrganisationType organisationType = CreateOrganisationDataSetup.getOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                ThreadLocalHeaderContext.getContext().getXaccessToken(),
                orgType,
                OrganisationConstants.GenericConstants.CREATE,
                ThreadLocalAuditContext.getContext()))
                .thenReturn(violationSet);
        when(createOrgDomainService.validateRODetails(roDataCreateV1))
                .thenReturn(violationSet);
        when(noteTypeRepository.findByNotesType("Internal")).thenReturn(noteType);
        lenient()
                .when(recognisingOrganisationRepository.save(organisation))
                .thenReturn(organisation);
        createOrgDomainService.onCommand(roDataCreateV1);
        // verify DAO Call
        verify(recognisingOrganisationRepository, times(1)).save(recognisingOrgCapt.capture());
        assertNotNull(recognisingOrgCapt.getValue().getAddresses());
        assertEquals(0, recognisingOrgCapt.getValue().getRecognisedProducts().size());

    }


    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForCreateOrgCommand")
    void testSaveRecognisingOrganisationWithIOLFalseSSRTrueACFalseGTTrue(
            final RoDataCreateV1Valid roDataCreateV1,
            final RoChangedEventV1 roChangedEventV1,
            final RecognisingOrganisation organisation,
            final NoteType noteType,
            final ContactType contactType)
            throws RbacValidationException, JsonProcessingException {

        Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
        roDataCreateV1.setLinkedOrganisations(null);
        roDataCreateV1.setAcceptsIOL(false);
        roDataCreateV1.setAcceptsSSR(true);
        roDataCreateV1.setAcceptsAC(false);
        roDataCreateV1.setAcceptsGT(true);
        OrganisationType organisationType = CreateOrganisationDataSetup.getOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                ThreadLocalHeaderContext.getContext().getXaccessToken(),
                orgType,
                OrganisationConstants.GenericConstants.CREATE,
                ThreadLocalAuditContext.getContext()))
                .thenReturn(violationSet);
        when(createOrgDomainService.validateRODetails(roDataCreateV1))
                .thenReturn(violationSet);
        when(noteTypeRepository.findByNotesType("Internal")).thenReturn(noteType);
        lenient()
                .when(recognisingOrganisationRepository.save(organisation))
                .thenReturn(organisation);
        createOrgDomainService.onCommand(roDataCreateV1);
        // verify DAO Call
        verify(recognisingOrganisationRepository, times(1)).save(recognisingOrgCapt.capture());
        assertNotNull(recognisingOrgCapt.getValue().getAddresses());
        assertEquals(0, recognisingOrgCapt.getValue().getRecognisedProducts().size());

    }

    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForCreateOrgCommand")
    void testSaveRecognisingOrganisationWithIOLTrueSSRFalseACTrueGTFalse(
            final RoDataCreateV1Valid roDataCreateV1,
            final RoChangedEventV1 roChangedEventV1,
            final RecognisingOrganisation organisation,
            final NoteType noteType,
            final ContactType contactType)
            throws RbacValidationException, JsonProcessingException {

        Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
        roDataCreateV1.setLinkedOrganisations(null);
        roDataCreateV1.setAcceptsIOL(true);
        roDataCreateV1.setAcceptsSSR(false);
        roDataCreateV1.setAcceptsAC(true);
        roDataCreateV1.setAcceptsGT(false);
        OrganisationType organisationType = CreateOrganisationDataSetup.getOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                ThreadLocalHeaderContext.getContext().getXaccessToken(),
                orgType,
                OrganisationConstants.GenericConstants.CREATE,
                ThreadLocalAuditContext.getContext()))
                .thenReturn(violationSet);
        when(createOrgDomainService.validateRODetails(roDataCreateV1))
                .thenReturn(violationSet);
        when(noteTypeRepository.findByNotesType("Internal")).thenReturn(noteType);
        lenient()
                .when(recognisingOrganisationRepository.save(organisation))
                .thenReturn(organisation);
        createOrgDomainService.onCommand(roDataCreateV1);
        // verify DAO Call
        verify(recognisingOrganisationRepository, times(1)).save(recognisingOrgCapt.capture());
        assertNotNull(recognisingOrgCapt.getValue().getAddresses());
        assertEquals(0, recognisingOrgCapt.getValue().getRecognisedProducts().size());

    }

    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForCreateOrgCommand")
    void testSaveRecognisingOrganisationWithIOLFalseSSRFalseACTrueGTFalse(
            final RoDataCreateV1Valid roDataCreateV1,
            final RoChangedEventV1 roChangedEventV1,
            final RecognisingOrganisation organisation,
            final NoteType noteType,
            final ContactType contactType)
            throws RbacValidationException, JsonProcessingException {

        Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
        roDataCreateV1.setLinkedOrganisations(null);
        roDataCreateV1.setAcceptsIOL(false);
        roDataCreateV1.setAcceptsSSR(false);
        roDataCreateV1.setAcceptsAC(true);
        roDataCreateV1.setAcceptsGT(false);
        OrganisationType organisationType = CreateOrganisationDataSetup.getOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                ThreadLocalHeaderContext.getContext().getXaccessToken(),
                orgType,
                OrganisationConstants.GenericConstants.CREATE,
                ThreadLocalAuditContext.getContext()))
                .thenReturn(violationSet);
        when(createOrgDomainService.validateRODetails(roDataCreateV1))
                .thenReturn(violationSet);
        when(noteTypeRepository.findByNotesType("Internal")).thenReturn(noteType);
        lenient()
                .when(recognisingOrganisationRepository.save(organisation))
                .thenReturn(organisation);
        createOrgDomainService.onCommand(roDataCreateV1);
        // verify DAO Call
        verify(recognisingOrganisationRepository, times(1)).save(recognisingOrgCapt.capture());
        assertNotNull(recognisingOrgCapt.getValue().getAddresses());
        assertEquals(0, recognisingOrgCapt.getValue().getRecognisedProducts().size());
    }
    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForCreateOrgCommand")
    void testSaveRecognisingOrganisationWithIOLFalseSSRFalseACFalseGTTrue(
            final RoDataCreateV1Valid roDataCreateV1,
            final RoChangedEventV1 roChangedEventV1,
            final RecognisingOrganisation organisation,
            final NoteType noteType,
            final ContactType contactType)
            throws RbacValidationException, JsonProcessingException {

        Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
        roDataCreateV1.setLinkedOrganisations(null);
        roDataCreateV1.setAcceptsIOL(false);
        roDataCreateV1.setAcceptsSSR(false);
        roDataCreateV1.setAcceptsAC(false);
        roDataCreateV1.setAcceptsGT(true);
        OrganisationType organisationType = CreateOrganisationDataSetup.getOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                ThreadLocalHeaderContext.getContext().getXaccessToken(),
                orgType,
                OrganisationConstants.GenericConstants.CREATE,
                ThreadLocalAuditContext.getContext()))
                .thenReturn(violationSet);
        when(createOrgDomainService.validateRODetails(roDataCreateV1))
                .thenReturn(violationSet);
        when(noteTypeRepository.findByNotesType("Internal")).thenReturn(noteType);
        lenient()
                .when(recognisingOrganisationRepository.save(organisation))
                .thenReturn(organisation);
        createOrgDomainService.onCommand(roDataCreateV1);
        // verify DAO Call
        verify(recognisingOrganisationRepository, times(1)).save(recognisingOrgCapt.capture());
        assertNotNull(recognisingOrgCapt.getValue().getAddresses());
        assertEquals(0, recognisingOrgCapt.getValue().getRecognisedProducts().size());

    }
    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForCreateOrgCommand")
    void testRecognisingOrganisationWithACFalseAndGTFalse_throwException(
            final RoDataCreateV1Valid roDataCreateV1,
            final RoChangedEventV1 roChangedEventV1,
            final RecognisingOrganisation organisation,
            final NoteType noteType,
            final ContactType contactType)
            throws RbacValidationException, JsonProcessingException {

        roDataCreateV1.setAcceptsAC(false);
        roDataCreateV1.setAcceptsGT(false);
        roDataCreateV1.setLinkedOrganisations(null);
        Set<ConstraintViolation<Object>> violationSet =
                OrganisationTestUtil.getSetforNullViolationOfEventBody("V0070", "productAcceptance");
        OrganisationType organisationType = CreateOrganisationDataSetup.getOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                ThreadLocalHeaderContext.getContext().getXaccessToken(),
                orgType,
                OrganisationConstants.GenericConstants.CREATE,
                ThreadLocalAuditContext.getContext()))
                .thenReturn(new HashSet<>());
        when(createOrgDomainService.validateRODetails(roDataCreateV1))
                .thenReturn(violationSet);
        CMDSErrorResponse cmdsErrorResponse =
                OrganisationTestUtil.getROErrorResponse(
                        "V0070",
                        "acceptsAC or acceptsGT any one of two must be true",
                        OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT);
        when(errorResolver.populatErrorResponse(
                violationSet, OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT))
                .thenReturn(cmdsErrorResponse);
        createOrgDomainService.onCommand(roDataCreateV1);
        // verify DAO Call
        verify(recognisingOrganisationRepository, times(0)).save(recognisingOrgCapt.capture());
        ThreadLocalHeaderContext.getContext().setEventName("RoRejected");
        // verify(applicationEventPublisher, times(1)).publishEvent(event);
        verify(errorResolver, times(1))
                .populatErrorResponse(
                        violationSetCapt.capture(),
                        Mockito.eq(OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT));
        assertNotNull(violationSetCapt.getValue().iterator().next().getMessage());
        assertEquals("V0070", violationSetCapt.getValue().iterator().next().getMessage());


    }
    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForCreateOrgCommand")
    void testRecognisingOrganisationWithACNullAndGTNull_throwException(
            final RoDataCreateV1Valid roDataCreateV1,
            final RoChangedEventV1 roChangedEventV1,
            final RecognisingOrganisation organisation,
            final NoteType noteType,
            final ContactType contactType)
            throws RbacValidationException, JsonProcessingException {

        roDataCreateV1.setAcceptsAC(null);
        roDataCreateV1.setAcceptsGT(null);
        roDataCreateV1.setLinkedOrganisations(null);
        Set<ConstraintViolation<Object>> violationSet =
                OrganisationTestUtil.getSetforNullViolationOfEventBody("V0070", "productAcceptance");
        OrganisationType organisationType = CreateOrganisationDataSetup.getOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                ThreadLocalHeaderContext.getContext().getXaccessToken(),
                orgType,
                OrganisationConstants.GenericConstants.CREATE,
                ThreadLocalAuditContext.getContext()))
                .thenReturn(new HashSet<>());
        when(createOrgDomainService.validateRODetails(roDataCreateV1))
                .thenReturn(violationSet);
        CMDSErrorResponse cmdsErrorResponse =
                OrganisationTestUtil.getROErrorResponse(
                        "V0070",
                        "acceptsAC or acceptsGT any one of two must be true",
                        OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT);
        when(errorResolver.populatErrorResponse(
                violationSet, OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT))
                .thenReturn(cmdsErrorResponse);
        createOrgDomainService.onCommand(roDataCreateV1);
        // verify DAO Call
        verify(recognisingOrganisationRepository, times(0)).save(recognisingOrgCapt.capture());
        ThreadLocalHeaderContext.getContext().setEventName("RoRejected");
        // verify(applicationEventPublisher, times(1)).publishEvent(event);
        verify(errorResolver, times(1))
                .populatErrorResponse(
                        violationSetCapt.capture(),
                        Mockito.eq(OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT));
        assertNotNull(violationSetCapt.getValue().iterator().next().getMessage());
        assertEquals("V0070", violationSetCapt.getValue().iterator().next().getMessage());


    }
    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForCreateOrgCommand")
    void testVerifiedOrganisationWithADO_throwException(
            final RoDataCreateV1Valid roDataCreateV1,
            final RoChangedEventV1 roChangedEventV1,
            final RecognisingOrganisation organisation,
            final NoteType noteType,
            final ContactType contactType)
            throws RbacValidationException, JsonProcessingException {

        roDataCreateV1.setAcceptsAC(true);
        roDataCreateV1.setAcceptsGT(true);
        roDataCreateV1.setOrganisationTypeUuid(UUID.fromString("e392ae7c-016f-433a-bdfa-b79bfcdddf26"));
        Set<ConstraintViolation<Object>> violationSet =
                OrganisationTestUtil.getSetforNullViolationOfEventBody("V0071", "linkedOrganisations");
        OrganisationType organisationType = CreateOrganisationDataSetup.getVOOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                ThreadLocalHeaderContext.getContext().getXaccessToken(),
                orgType,
                OrganisationConstants.GenericConstants.CREATE,
                ThreadLocalAuditContext.getContext()))
                .thenReturn(new HashSet<>());
        when(createOrgDomainService.validateRODetails(roDataCreateV1))
                .thenReturn(violationSet);
        CMDSErrorResponse cmdsErrorResponse =
                OrganisationTestUtil.getROErrorResponse(
                        "V0071",
                        "VOs don't support ADOs",
                        OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT);
        when(errorResolver.populatErrorResponse(
                violationSet, OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT))
                .thenReturn(cmdsErrorResponse);
        createOrgDomainService.onCommand(roDataCreateV1);
        // verify DAO Call
        verify(recognisingOrganisationRepository, times(0)).save(recognisingOrgCapt.capture());
        ThreadLocalHeaderContext.getContext().setEventName("RoRejected");
        // verify(applicationEventPublisher, times(1)).publishEvent(event);
        verify(errorResolver, times(1))
                .populatErrorResponse(
                        violationSetCapt.capture(),
                        Mockito.eq(OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT));
        assertNotNull(violationSetCapt.getValue().iterator().next().getMessage());
        assertEquals("V0071", violationSetCapt.getValue().iterator().next().getMessage());


    }
    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForCreateOrgCommand")
    void testSaveRecognisingOrganisationWithIOLFalseSSRFalseACTrueGTTrue(
            final RoDataCreateV1Valid roDataCreateV1,
            final RoChangedEventV1 roChangedEventV1,
            final RecognisingOrganisation organisation,
            final NoteType noteType,
            final ContactType contactType)
            throws RbacValidationException, JsonProcessingException {

        Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
        roDataCreateV1.setLinkedOrganisations(null);
        roDataCreateV1.setAcceptsIOL(false);
        roDataCreateV1.setAcceptsSSR(false);
        roDataCreateV1.setAcceptsAC(true);
        roDataCreateV1.setAcceptsGT(true);
        OrganisationType organisationType = CreateOrganisationDataSetup.getOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(jedisGenericReader.retrieveAllBookableProductsDataFromRedisCache()).thenReturn(ProductDataSetUp.bookableProducts());
        when(orgCommonUtils.checkPermissionForROVO(
                ThreadLocalHeaderContext.getContext().getXaccessToken(),
                orgType,
                OrganisationConstants.GenericConstants.CREATE,
                ThreadLocalAuditContext.getContext()))
                .thenReturn(violationSet);
        when(createOrgDomainService.validateRODetails(roDataCreateV1))
                .thenReturn(violationSet);
        when(noteTypeRepository.findByNotesType("Internal")).thenReturn(noteType);
        lenient()
                .when(recognisingOrganisationRepository.save(organisation))
                .thenReturn(organisation);
        createOrgDomainService.onCommand(roDataCreateV1);
        // verify DAO Call
        verify(recognisingOrganisationRepository, times(1)).save(recognisingOrgCapt.capture());
        assertNotNull(recognisingOrgCapt.getValue().getAddresses());
        assertEquals(4, recognisingOrgCapt.getValue().getRecognisedProducts().size());

    }
    private static Stream<Arguments> provideArgumentsForCreateOrgCommand() {

        final RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();

        RecognisingOrganisation organisation = new RecognisingOrganisation();
        RecognisingOrganisation recognisingOrganisation =
                CreateOrganisationDataSetup.populateOrganisation(roDataCreateV1, organisation);
        NoteType noteType = CreateOrganisationDataSetup.getNoteTypesData();
        ContactType contactType = CreateOrganisationDataSetup.getContactTypeData();
        Territory territory = CreateOrganisationDataSetup.getTerritoryData();
        RoChangedEventV1 roChangedEvent =
                CreateOrganisationDataSetup.entityToEventMapper(recognisingOrganisation);
      return Stream.of(
                Arguments.of(
                        roDataCreateV1,
                        roChangedEvent,
                        recognisingOrganisation,
                        noteType,
                        contactType,
                        territory));
    }
}
