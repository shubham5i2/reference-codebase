package com.ielts.cmds.organisation.utills;

import static com.ielts.cmds.organisation.utils.OrganisationConstants.GenericConstants.SIMILARITY;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.ListJoin;
import javax.persistence.criteria.Root;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.jpa.domain.Specification;


import com.ielts.cmds.api.roui005rosearchrequested.RoSearchCriteria;
import com.ielts.cmds.organisation.infrastructure.entity.Address;
import com.ielts.cmds.organisation.infrastructure.entity.Contact;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.utils.SearchPartialRoNameCriteriaSpecificationUtil;
import com.ielts.cmds.organisation.utils.SearchRemaningCriteriaSpecificationUtil;

@ExtendWith(MockitoExtension.class)
class SearchPartialCriteriaSpecificationUtilTest {

	@InjectMocks
	private SearchPartialRoNameCriteriaSpecificationUtil searchPartialCriteriaSpecificationUtil;

	@Mock
	private CriteriaBuilder criteriaBuilder;

	@Mock
	private CriteriaQuery<RecognisingOrganisation> criteriaQuery;

	@Mock
	private Root<RecognisingOrganisation> recognisingOrganisationRoot;

	@Mock
	private ListJoin<RecognisingOrganisation, Address> joinAddressMock;

	@Mock
	private SearchRemaningCriteriaSpecificationUtil searchRemaningCriteriaSpecificationUtil;

	@Mock
	private Specification<RecognisingOrganisation> partialMatchSpec;

	@BeforeEach
	void setup() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void whenAllCriteria_PartialCriteriaMatches_ExpectCriteriaBuilderIsCalled() {

		RoSearchCriteria searchCriteria = SearchOrganisationDataSetup.getRoSearchCriteria();
		doReturn(partialMatchSpec).when(searchRemaningCriteriaSpecificationUtil).criteriaMatches(searchCriteria,
				joinAddressMock);
		Specification<RecognisingOrganisation> actual = searchPartialCriteriaSpecificationUtil
				.criteriaMatches(searchCriteria, joinAddressMock);
		actual.toPredicate(recognisingOrganisationRoot, criteriaQuery, criteriaBuilder);

		verify(criteriaBuilder).function(SIMILARITY, Double.class, recognisingOrganisationRoot.get("name"),
				criteriaBuilder.literal(searchCriteria.getOrganisationName()));

	}

	@Test
	void whenOrgNameCriteriaIsEmpty_PartialCriteriaMatches_ExpectOrgNameCriteriaBuilderIsNeverCalled() {
		RoSearchCriteria searchCriteria = SearchOrganisationDataSetup.getRoSearchCriteria();
		searchCriteria.setOrganisationName("");
		doReturn(partialMatchSpec).when(searchRemaningCriteriaSpecificationUtil).criteriaMatches(searchCriteria,
				joinAddressMock);
		Specification<RecognisingOrganisation> actual = searchPartialCriteriaSpecificationUtil
				.criteriaMatches(searchCriteria, joinAddressMock);
		actual.toPredicate(recognisingOrganisationRoot, criteriaQuery, criteriaBuilder);

		verify(criteriaBuilder, never()).function(SIMILARITY, Double.class, recognisingOrganisationRoot.get("name"),
				criteriaBuilder.literal(searchCriteria.getOrganisationName()));

	}

}
