package com.ielts.cmds.organisation.utills;

import static com.ielts.cmds.organisation.utils.OrganisationConstants.GenericConstants.SIMILARITY;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.ListJoin;
import javax.persistence.criteria.Root;

import com.ielts.cmds.api.roui005rosearchrequested.RoSearchCriteria;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.jpa.domain.Specification;
import com.ielts.cmds.organisation.infrastructure.entity.Address;
import com.ielts.cmds.organisation.infrastructure.entity.Contact;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.utils.SearchRemaningCriteriaSpecificationUtil;

@ExtendWith(MockitoExtension.class)
class SearchRemainingCriteriaSpecificationUtilTest {

	@Mock
	private CriteriaBuilder criteriaBuilder;

	@Mock
	private CriteriaQuery<RecognisingOrganisation> criteriaQuery;

	@Mock
	private Root<RecognisingOrganisation> recognisingOrganisationRoot;

	@Mock
	private ListJoin<RecognisingOrganisation, Address> joinAddressMock;

	@Mock
	private ListJoin<RecognisingOrganisation, Contact> joinContactMock;

	@InjectMocks
	private SearchRemaningCriteriaSpecificationUtil searchRemaningCriteriaSpecificationUtil;

	@BeforeEach
	void setup() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void whenAllCriteria_RemainingCriteriaMatches_ExpectCriteriaBuilderIsCalled() {

		RoSearchCriteria searchCriteria = SearchOrganisationDataSetup.getRoSearchCriteria();
		doReturn(joinContactMock).when(recognisingOrganisationRoot).joinList("contacts", JoinType.LEFT);

		Specification<RecognisingOrganisation> actual = searchRemaningCriteriaSpecificationUtil
				.criteriaMatches(searchCriteria, joinAddressMock);
		actual.toPredicate(recognisingOrganisationRoot, criteriaQuery, criteriaBuilder);

		verify(criteriaBuilder, times(2)).function(SIMILARITY, Double.class, joinContactMock.get("firstName"),
				criteriaBuilder.literal(searchCriteria.getContactName()));
		verify(criteriaBuilder).function(SIMILARITY, Double.class, joinAddressMock.get("email"),
				criteriaBuilder.literal(searchCriteria.getContactEmail()));
	}

	@Test
	void whenContactEmailCriteriaIsEmpty_RemainingCriteriaMatches_ExpectContactEmailCriteriaBuilderIsNeverCalled() {
		RoSearchCriteria searchCriteria = SearchOrganisationDataSetup.getRoSearchCriteria();
		searchCriteria.setContactEmail("");
		doReturn(joinContactMock).when(recognisingOrganisationRoot).joinList("contacts", JoinType.LEFT);

		Specification<RecognisingOrganisation> actual = searchRemaningCriteriaSpecificationUtil
				.criteriaMatches(searchCriteria, joinAddressMock);
		actual.toPredicate(recognisingOrganisationRoot, criteriaQuery, criteriaBuilder);

		verify(criteriaBuilder, times(2)).function(SIMILARITY, Double.class, joinContactMock.get("firstName"),
				criteriaBuilder.literal(searchCriteria.getContactName()));
		verify(criteriaBuilder, never()).function(SIMILARITY, Double.class, joinAddressMock.get("email"),
				criteriaBuilder.literal(searchCriteria.getContactEmail()));
	}

	@Test
	void whenContactNameCriteriaIsEmpty_RemainingCriteriaMatches_ExpectContactNameCriteriaBuilderIsNeverCalled() {
		RoSearchCriteria searchCriteria = SearchOrganisationDataSetup.getRoSearchCriteria();
		searchCriteria.setContactName("");
		doReturn(joinContactMock).when(recognisingOrganisationRoot).joinList("contacts", JoinType.LEFT);

		Specification<RecognisingOrganisation> actual = searchRemaningCriteriaSpecificationUtil
				.criteriaMatches(searchCriteria, joinAddressMock);
		actual.toPredicate(recognisingOrganisationRoot, criteriaQuery, criteriaBuilder);

		verify(criteriaBuilder, never()).function(SIMILARITY, Double.class, joinContactMock.get("firstName"),
				criteriaBuilder.literal(searchCriteria.getContactName()));
		verify(criteriaBuilder).function(SIMILARITY, Double.class, joinAddressMock.get("email"),
				criteriaBuilder.literal(searchCriteria.getContactEmail()));
	}

}
