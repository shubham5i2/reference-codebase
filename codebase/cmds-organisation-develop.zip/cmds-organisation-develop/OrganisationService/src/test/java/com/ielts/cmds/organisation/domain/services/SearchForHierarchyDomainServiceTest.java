package com.ielts.cmds.organisation.domain.services;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.roui010rohierarchyrequested.ROHierarchyRequestParam;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.common.out.event.RoDetailsDataGeneratedEventV1;
import com.ielts.cmds.organisation.domain.commands.CreateROVO;
import com.ielts.cmds.organisation.domain.model.RoDataCreateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.utills.CreateOrganisationDataSetup;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.outbox.event.OutboxEventBuilder;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.api.service.impl.RBACServiceImpl;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Stream;
import javax.validation.ConstraintViolation;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
class SearchForHierarchyDomainServiceTest {

    @InjectMocks @Spy SearchForHierarchyDomainService searchForHierarchyDomainService;

    @Mock private ObjectMapper objectMapper;

    @Spy private OrganisationCommonUtils organisationCommonUtils;

    @Mock private ApplicationEventPublisher applicationEventPublisher;

    @Mock private RBACServiceImpl rbacServiceImpl;

    @Mock private CMDSErrorResolver<Object> errorResolver;

    @Captor private ArgumentCaptor<BaseHeader> headerCaptor;

    @Captor private ArgumentCaptor<Set<ConstraintViolation<Object>>> violationSetCapt;

    @Captor private ArgumentCaptor<BaseEvent<BaseHeader>> roRequestedEventCaptor;

    @Mock private OutboxEventBuilder outboxEventBuilder;

    @BeforeEach
    void setup() throws IOException  {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(
                searchForHierarchyDomainService, "rbacServiceImpl", rbacServiceImpl);
        ReflectionTestUtils.setField(searchForHierarchyDomainService, "objectMapper", objectMapper);
        ReflectionTestUtils.setField(
                searchForHierarchyDomainService,
                "organisationCommonUtils",
                organisationCommonUtils);
        ReflectionTestUtils.setField(
                searchForHierarchyDomainService, "errorResolver", errorResolver);
        ReflectionTestUtils.setField(
                searchForHierarchyDomainService, "rbacServiceImpl", rbacServiceImpl);
        ReflectionTestUtils.setField(
                searchForHierarchyDomainService,
                "applicationEventPublisher",
                applicationEventPublisher);
        ReflectionTestUtils.setField(
                organisationCommonUtils, "applicationEventPublisher", applicationEventPublisher);
        ReflectionTestUtils.setField(organisationCommonUtils, "objectMapper", objectMapper);
        ReflectionTestUtils.setField(organisationCommonUtils, "outboxEventBuilder", outboxEventBuilder);
        CMDSHeaderContext header = OrganisationTestUtil
                .generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_HIERARCHY_SEARCH_REQUEST_EVENT);
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put("recognisingOrganisationUuid", "1f50ca55-3800-48c7-8f30-0723f5fac264");
        header.setEventContext(eventContext);
        ThreadLocalHeaderContext.setContext(header);
        String authorisedAccessToken = OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessToken);
        ThreadLocalAuditContext.setContext(OrganisationTestUtil.getBaseAudit());

    }

    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchForHierarchyCommand")
    void whenReceivedValid_SearchForHierarchyCommand_thenNoException(
            final RecognisingOrganisation recognisingOrganisation)
            throws JsonProcessingException, RbacValidationException {
         BaseHeader header = organisationCommonUtils.buildUiHeader();

        BaseAudit audit =  organisationCommonUtils.getBaseAudit();
        ROHierarchyRequestParam eventBody = new ROHierarchyRequestParam();
        eventBody.setRecognisingOrganisationUuid(UUID.fromString("1f50ca55-3800-48c7-8f30-0723f5fac264"));
        eventBody.setOnlyImmediateChildren(Boolean.FALSE);
        Set<RecognisingOrganisation> roList = new HashSet<>();
        roList.add(recognisingOrganisation);
        doReturn(true)
                .when(rbacServiceImpl)
                .isAuthorised(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION);
        doReturn(header).when(organisationCommonUtils).buildUiHeader();

        doNothing()
                .when(organisationCommonUtils)
                .publishForRODetailsDataGenerated(
                        header,
                        roList,
                        audit);
        doReturn(roList)
                .when(organisationCommonUtils)
                .getChildHierarchyBasedOnRO(
                        UUID.fromString("1f50ca55-3800-48c7-8f30-0723f5fac264"), Boolean.FALSE);

        Executable executable = () -> searchForHierarchyDomainService.onCommand(eventBody);
        assertDoesNotThrow(executable);
        verify(organisationCommonUtils)
                .publishForRODetailsDataGenerated(
                        header,
                        roList,
                        audit);
    }

    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchForHierarchyCommand")
    void whenReceivedValid_SearchForHierarchyCommand_thenVerifyPublishEvent(
            final RecognisingOrganisation recognisingOrganisation,
            final RoDetailsDataGeneratedEventV1 roDetails)
            throws JsonProcessingException, RbacValidationException {
        BaseHeader header = organisationCommonUtils.buildUiHeader();

        BaseAudit audit =  organisationCommonUtils.getBaseAudit();

        doReturn(true)
                .when(rbacServiceImpl)
                .isAuthorised(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION);
        doReturn(header).when(organisationCommonUtils).buildUiHeader();
        ROHierarchyRequestParam eventBody = new ROHierarchyRequestParam();
        eventBody.setRecognisingOrganisationUuid(UUID.fromString("1f50ca55-3800-48c7-8f30-0723f5fac264"));
        eventBody.setOnlyImmediateChildren(Boolean.FALSE);
        Set<RecognisingOrganisation> roList = new HashSet<>();
        roList.add(recognisingOrganisation);
        String expectedEventBodyString = new ObjectMapper().writeValueAsString(roDetails);
        doReturn(roDetails)
                .when(organisationCommonUtils)
                .entityToEventMapperForOrgDetailsDataGenerated(roList);
        doReturn(roList)
                .when(organisationCommonUtils)
                .getChildHierarchyBasedOnRO(
                        UUID.fromString("1f50ca55-3800-48c7-8f30-0723f5fac264"), Boolean.FALSE);
        doReturn(expectedEventBodyString).when(objectMapper).writeValueAsString(roDetails);

        searchForHierarchyDomainService.onCommand(eventBody);
        verify(applicationEventPublisher).publishEvent(roRequestedEventCaptor.capture());
        assertNull(roRequestedEventCaptor.getValue().getEventErrors());
        assertEquals(expectedEventBodyString, roRequestedEventCaptor.getValue().getEventBody());
        assertEquals(
                OrganisationConstants.EventType.RO_DETAILS_DATA_GENERATED_EVENT,
                roRequestedEventCaptor.getValue().getEventHeader().getEventName());
    }

    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchForHierarchyCommand")
    void whenReceivedValid_SearchForHierarchyCommand_withROUuidAndParentROUuid_thenVerifyPublishEvent(
                     final RecognisingOrganisation recognisingOrganisation,
                    final RoDetailsDataGeneratedEventV1 roDetails)
                    throws JsonProcessingException, RbacValidationException {
         BaseHeader header = organisationCommonUtils.buildUiHeader();

        BaseAudit audit =  organisationCommonUtils.getBaseAudit();

        doReturn(true)
                .when(rbacServiceImpl)
                .isAuthorised(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION);
        doReturn(header).when(organisationCommonUtils).buildUiHeader();

//        Map<String, String> eventContext = ThreadLocalHeaderContext.getContext().getEventContext();
//        eventContext.put("recognisingOrganisationUuid", "1f50ca55-3800-48c7-8f30-0723f5fac264");
//        eventContext.put("parentROUuid", "705fc839-5051-4a22-a77d-cf6d734d7d24");
        ROHierarchyRequestParam eventBody = new ROHierarchyRequestParam();
        eventBody.setRecognisingOrganisationUuid(UUID.fromString("1f50ca55-3800-48c7-8f30-0723f5fac264"));
        eventBody.setParentROUuid(UUID.fromString("705fc839-5051-4a22-a77d-cf6d734d7d24"));
        eventBody.setOnlyImmediateChildren(Boolean.FALSE);
        Set<RecognisingOrganisation> roList = new HashSet<>();
        roList.add(recognisingOrganisation);
        roList.add(CreateOrganisationDataSetup.getExistingOrganisationDetails());
        Set<RecognisingOrganisation> parentROHierarchy = new HashSet<>();
        parentROHierarchy.add(CreateOrganisationDataSetup.getExistingOrganisationDetails());
        RoDetailsDataGeneratedEventV1 parentRoDetails =
                CreateOrganisationDataSetup.entityToEventMapperForSearchByOrgId(parentROHierarchy);
        roDetails.addAll(parentRoDetails);
        String expectedEventBodyString = new ObjectMapper().writeValueAsString(roDetails);
        doReturn(roDetails)
                .when(organisationCommonUtils)
                .entityToEventMapperForOrgDetailsDataGenerated(roList);
        doReturn(roList)
                .when(organisationCommonUtils)
                .getChildHierarchyBasedOnRO(
                        UUID.fromString("1f50ca55-3800-48c7-8f30-0723f5fac264"), Boolean.FALSE);

        doReturn(parentROHierarchy)
                .when(organisationCommonUtils)
                .getHierarchyBasedOnRecognisingOrganisationUuid(
                        UUID.fromString("705fc839-5051-4a22-a77d-cf6d734d7d24"));
        doReturn(expectedEventBodyString).when(objectMapper).writeValueAsString(roDetails);
        searchForHierarchyDomainService.onCommand(eventBody);
        verify(applicationEventPublisher).publishEvent(roRequestedEventCaptor.capture());
        assertNull(roRequestedEventCaptor.getValue().getEventErrors());
        assertEquals(expectedEventBodyString, roRequestedEventCaptor.getValue().getEventBody());
        assertEquals(
                OrganisationConstants.EventType.RO_DETAILS_DATA_GENERATED_EVENT,
                roRequestedEventCaptor.getValue().getEventHeader().getEventName());
    }

    @DisplayName("Valid Command No Permission - Expect Reject Event")
    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchForHierarchyCommand")
    void whenReceivedValid_SearchForHierarchyCommand_thenExpectRejectEventToBePublished(
            final RecognisingOrganisation recognisingOrganisation)
            throws Exception {
        BaseHeader header = organisationCommonUtils.buildUiHeader();
        BaseAudit audit =  organisationCommonUtils.getBaseAudit();
        ROHierarchyRequestParam eventBody = new ROHierarchyRequestParam();
        eventBody.setRecognisingOrganisationUuid(UUID.fromString("5c2e3965-8b90-488f-b5e9-4da8854785cb"));
        Set<RecognisingOrganisation> roList = new HashSet<>();
        roList.add(recognisingOrganisation);
        doReturn(false)
                .when(rbacServiceImpl)
                .isAuthorised(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION);
        Set<ConstraintViolation<Object>> violationSet =
                OrganisationTestUtil.getSetforNullViolationOfEventBody(
                        "V0044", "UnauthorisedToViewOrganisation");
        doReturn(violationSet)
                .when(organisationCommonUtils)
                .getSetforNullViolationOfEventBody("V0044", "UnauthorisedToViewOrganisation");

        Executable executable = () -> searchForHierarchyDomainService.onCommand(eventBody);
        assertDoesNotThrow(executable);
        verify(organisationCommonUtils)
                .getSetforNullViolationOfEventBody("V0044", "UnauthorisedToViewOrganisation");
        verify(organisationCommonUtils)
                .generateRejectedEventResponse(
                        headerCaptor.capture(),
                        violationSetCapt.capture(),
                        eq(audit),
                        eq(header
                                        .getEventContext()
                                        .get("recognisingOrganisationUuid")));
        verify(organisationCommonUtils, never())
                .publishForRODetailsDataGenerated(
                        header,
                        roList,
                        audit);
    }

    @DisplayName("Valid Command OrganisationNotFound - Expect Empty Event")
    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchForHierarchyCommand")
    void whenReceivedValid_SearchForHierarchyCommand_thenExpectNotFound_EmptyEventToBePublished(
            final RecognisingOrganisation recognisingOrganisation)
            throws JsonProcessingException, RbacValidationException {

       BaseHeader header = organisationCommonUtils.buildUiHeader();
       BaseAudit audit =  organisationCommonUtils.getBaseAudit();
        ROHierarchyRequestParam eventBody = new ROHierarchyRequestParam();
        eventBody.setRecognisingOrganisationUuid(UUID.fromString("1f50ca55-3800-48c7-8f30-0723f5fac264"));
        eventBody.setOnlyImmediateChildren(Boolean.FALSE);
        Set<RecognisingOrganisation> roList = new HashSet<>();
        doReturn(true)
                .when(rbacServiceImpl)
                .isAuthorised(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION);
        doReturn(header).when(organisationCommonUtils).buildUiHeader();

        doReturn(roList)
                .when(organisationCommonUtils)
                .getChildHierarchyBasedOnRO(
                        UUID.fromString("1f50ca55-3800-48c7-8f30-0723f5fac264"), Boolean.FALSE);
        Executable executable = () -> searchForHierarchyDomainService.onCommand(eventBody);
        assertDoesNotThrow(executable);
        verify(organisationCommonUtils)
                .publishForRODetailsDataGenerated(
                        header,
                        roList,
                        audit);
    }

    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchForHierarchyCommand")
    void whenReceivedValid_SearchForHierarchyCommand_withROUuidAndOnlyImmediateChild_thenVerifyPublishEvent(
                     final RecognisingOrganisation recognisingOrganisation,
                    final RoDetailsDataGeneratedEventV1 roDetails)
                    throws JsonProcessingException, RbacValidationException {
        UiHeader header = organisationCommonUtils.buildUiHeader();
        BaseAudit audit =  organisationCommonUtils.getBaseAudit();

        Map<String, String> eventContext1 = new HashMap<>();
        eventContext1.put("recognisingOrganisationUuid", "1f50ca55-3800-48c7-8f30-0723f5fac264");
        CMDSHeaderContext headerContext = OrganisationTestUtil
                .generateBuildHeaderContext(OrganisationConstants.EventType.RO_DETAILS_DATA_GENERATED_EVENT);
        headerContext.setEventContext(eventContext1);
        ThreadLocalHeaderContext.setContext(headerContext);

        doReturn(true)
                .when(rbacServiceImpl)
                .isAuthorised(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION);
        doReturn(header).when(organisationCommonUtils).buildUiHeader();

//        Map<String, String> eventContext = ThreadLocalHeaderContext.getContext().getEventContext();
//        eventContext.put("recognisingOrganisationUuid", "705fc839-5051-4a22-a77d-cf6d734d7d24");
//        eventContext.put("onlyImmediateChildren", "true");
        ROHierarchyRequestParam eventBody = new ROHierarchyRequestParam();
        eventBody.setRecognisingOrganisationUuid(UUID.fromString("705fc839-5051-4a22-a77d-cf6d734d7d24"));
        eventBody.setOnlyImmediateChildren(Boolean.TRUE);
        Set<RecognisingOrganisation> roList = new HashSet<>();
        roList.add(recognisingOrganisation);
        String expectedEventBodyString = new ObjectMapper().writeValueAsString(roDetails);
        doReturn(roDetails)
                .when(organisationCommonUtils)
                .entityToEventMapperForOrgDetailsDataGenerated(roList);
        doReturn(roList)
                .when(organisationCommonUtils)
                .getChildHierarchyBasedOnRO(
                        UUID.fromString("705fc839-5051-4a22-a77d-cf6d734d7d24"), Boolean.TRUE);
        doReturn(expectedEventBodyString).when(objectMapper).writeValueAsString(roDetails);
        searchForHierarchyDomainService.onCommand(eventBody);
        verify(applicationEventPublisher).publishEvent(roRequestedEventCaptor.capture());
        assertNull(roRequestedEventCaptor.getValue().getEventErrors());
        assertEquals(expectedEventBodyString, roRequestedEventCaptor.getValue().getEventBody());
        assertEquals(
                OrganisationConstants.EventType.RO_DETAILS_DATA_GENERATED_EVENT,
                roRequestedEventCaptor.getValue().getEventHeader().getEventName());
    }

    private static Stream<Arguments> provideArgumentsForSearchForHierarchyCommand() {

        final RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        UiHeader roHeaders = OrganisationTestUtil.generateEventHeader();
        BaseEvent<BaseHeader> event = new BaseEvent<>(roHeaders, null, null, null);

        CreateROVO createRo =
                CreateROVO.builder()
                        .eventHeaders(event.getEventHeader())
                        .eventBody(roDataCreateV1)
                        .eventErrors(event.getEventErrors())
                        .build();
        Set<RecognisingOrganisation> recognisingOrganisationList = new HashSet<>();
        RecognisingOrganisation recognisingOrganisation =
                CreateOrganisationDataSetup.populateOrganisation(
                        createRo.getEventBody(), new RecognisingOrganisation());
        recognisingOrganisation.setRecognisingOrganisationUuid(
                UUID.fromString("1f50ca55-3800-48c7-8f30-0723f5fac264"));
        recognisingOrganisation.setName("Delft University");
        recognisingOrganisationList.add(recognisingOrganisation);
        RoDetailsDataGeneratedEventV1 roDetails =
                CreateOrganisationDataSetup.entityToEventMapperForSearchByOrgId(
                        recognisingOrganisationList);

        return Stream.of(Arguments.of(recognisingOrganisation, roDetails));
    }
}
