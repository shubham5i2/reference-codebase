package com.ielts.cmds.organisation.cache;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.organisation.cache.constants.ProductDataReadCacheConstants;
import com.ielts.cmds.organisation.cache.entity.Module;
import com.ielts.cmds.organisation.cache.entity.Product;
import com.ielts.cmds.organisation.utills.CacheTestDataSetup;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.UnifiedJedis;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@RunWith(MockitoJUnitRunner.class)
class JedisCacheReaderTest {

    @InjectMocks
    private JedisCacheReader jedisCacheReader;

    @Spy
    private JedisReaderHelper jedisReaderHelper;

    @Mock
    UnifiedJedis jedisMock;

    @Test
    void testRetrieveSingleProductDataFromRedisCacheHashMap() throws JsonProcessingException {
        Map<String, String> productDataSetUpInCache = CacheTestDataSetup.getProductDataInHashMap();
        when(jedisMock.hgetAll("product-81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498")).thenReturn(productDataSetUpInCache);
        Optional<Product> productDataOpt = jedisCacheReader
                .retrieveSingleProductDataFromRedisCache("81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");
        Product productData = productDataOpt.get();
        verify(jedisMock, times(1)).hgetAll("product-81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");
        assertEquals(UUID.fromString(productDataSetUpInCache.get(ProductDataReadCacheConstants.PRODUCT_UUID)),
                productData.getProductUuid());
        assertEquals(UUID.fromString(productDataSetUpInCache.get(ProductDataReadCacheConstants.PARENT_PRODUCT_UUID)),
                productData.getParentProductUuid());
        assertEquals(new ObjectMapper().readValue(productDataSetUpInCache.get(ProductDataReadCacheConstants.MODULE),
                Module.class), productData.getModule());
        assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.LEGACY_PRODUCT_ID),
                productData.getLegacyProductId());
        assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.NAME), productData.getName());
        assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.DESCRIPTION),
                productData.getDescription());
        assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.PRODUCT_CHARACTERISTICS),
                productData.getProductCharacteristics());
        assertEquals(Boolean.valueOf(productDataSetUpInCache.get(ProductDataReadCacheConstants.BOOKABLE)),
                productData.isBookable());
        assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.COMPONENT), productData.getComponent());
        assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.DURATION),
                String.valueOf(productData.getDuration()));
        assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.FORMAT), productData.getFormat());
        assertEquals(Boolean.valueOf(productDataSetUpInCache.get(ProductDataReadCacheConstants.APPROVAL_REQUIRED)),
                productData.isApprovalRequired());
        assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.AVAILABLE_FROM_DATE),
                productData.getAvailableFrom().toString());
        assertEquals(productDataSetUpInCache.get(ProductDataReadCacheConstants.AVAILABLE_TO_DATE),
                productData.getAvailableTo().toString());
    }

    @Test
    void whenRequestedProductDataIsNotPresentInCache_verifyEmptyProductIsReturned() throws JsonProcessingException {
        Optional<Product> productData = jedisCacheReader
                .retrieveSingleProductDataFromRedisCache("81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");
        verify(jedisMock, times(1)).hgetAll("product-81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");
        assertEquals(Optional.empty(), productData);
    }

    @Test
    void testRetrieveAllBookableProductsDataFromRedisCache() throws JsonProcessingException {
        Set<String> bookableProductKeys = new HashSet<String>();
        bookableProductKeys.add("product-81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");
        Map<String, String> productDataSetUpInCache = CacheTestDataSetup.getProductDataInHashMap();
        when(jedisMock.smembers(ProductDataReadCacheConstants.KEY_OF_ALL_BOOKABLE_PRODUCTS)).thenReturn(bookableProductKeys);
        when(jedisMock.hgetAll("product-81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498")).thenReturn(productDataSetUpInCache);
        List<Product> bookableProductList = jedisCacheReader.retrieveAllBookableProductsDataFromRedisCache();
        verify(jedisMock, times(1)).smembers(ProductDataReadCacheConstants.KEY_OF_ALL_BOOKABLE_PRODUCTS);
        assertEquals(1, bookableProductList.size());
        assertEquals(true, bookableProductList.get(0).isBookable());
    }

    @Test
    void whenBookableProductsAreNotPresentInCache_verifyEmptyListIsReturned() throws JsonProcessingException {
        List<Product> bookableProductList = jedisCacheReader.retrieveAllBookableProductsDataFromRedisCache();
        verify(jedisMock, times(1)).smembers(ProductDataReadCacheConstants.KEY_OF_ALL_BOOKABLE_PRODUCTS);
        assertTrue(bookableProductList.isEmpty());
    }

    @Test
    void testRetrieveAllProductsDataFromRedisCache() throws JsonProcessingException {
        Set<String> allProductKeys = new HashSet<String>();
        allProductKeys.add("product-81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");
        Map<String, String> productDataSetUpInCache = CacheTestDataSetup.getProductDataInHashMap();
        when(jedisMock.smembers(ProductDataReadCacheConstants.KEY_OF_ALL_PRODUCTS)).thenReturn(allProductKeys);
        when(jedisMock.hgetAll("product-81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498")).thenReturn(productDataSetUpInCache);
        List<Product> allProductList = jedisCacheReader.retrieveAllProductsDataFromRedisCache();
        verify(jedisMock, times(1)).smembers(ProductDataReadCacheConstants.KEY_OF_ALL_PRODUCTS);
        verify(jedisMock, times(1)).hgetAll("product-81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");
        assertEquals(1, allProductList.size());
        assertEquals(true, allProductList.get(0).isBookable());
    }

    @Test
    void whenProductsAreNotPresentInCache_verifyEmptyListIsReturned() throws JsonProcessingException {
        List<Product> allProductList = jedisCacheReader.retrieveAllProductsDataFromRedisCache();
        verify(jedisMock, times(1)).smembers(ProductDataReadCacheConstants.KEY_OF_ALL_PRODUCTS);
        assertTrue(allProductList.isEmpty());
    }

}
