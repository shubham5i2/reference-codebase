package com.ielts.cmds.organisation.utills;

import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.ielts.cmds.api.roui005rosearchrequested.RoSearchCriteria;
import com.ielts.cmds.api.roui007rocreaterequested.OrganisationStatusEnum;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreate;
import com.ielts.cmds.organisation.infrastructure.entity.Address;
import com.ielts.cmds.organisation.infrastructure.entity.AddressType;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.AddressTypeRepository;
import com.ielts.cmds.organisation.utils.SearchCriteriaSpecificationUtil;
import com.ielts.cmds.organisation.utils.SearchFullTextRoNameCriteriaSpecificationUtil;
import com.ielts.cmds.organisation.utils.SearchPartialRoNameCriteriaSpecificationUtil;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.ListJoin;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Root;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
class SearchCriteriaSpecificationUtilTest {

    @InjectMocks private SearchCriteriaSpecificationUtil searchCriteriaSpecificationUtil;

    @Mock private CriteriaBuilder criteriaBuilder;

    @Mock private CriteriaQuery<RecognisingOrganisation> criteriaQuery;

    @Mock private Root<RecognisingOrganisation> recognisingOrganisationRoot;

    @Mock private ListJoin<RecognisingOrganisation, Address> joinAddressMock;

    @Mock private Specification<RecognisingOrganisation> partialMatchSpec;

    @Mock private SearchPartialRoNameCriteriaSpecificationUtil searchPartialRoNameCriteriaSpecificationUtil;

    @Mock private SearchFullTextRoNameCriteriaSpecificationUtil searchFullTextRoNameCriteriaSpecificationUtil;
    
    @Mock private AddressTypeRepository addressTypeRepository;

    @Captor private ArgumentCaptor<Path<Object>> pathCaptor;

    @BeforeEach
    void setup() {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(
                searchCriteriaSpecificationUtil,
                "searchPartialRoNameCriteriaSpecificationUtil",
                searchPartialRoNameCriteriaSpecificationUtil);
        ReflectionTestUtils.setField(
        		searchCriteriaSpecificationUtil,
                "searchFullTextRoNameCriteriaSpecificationUtil",
                searchFullTextRoNameCriteriaSpecificationUtil);
        ReflectionTestUtils.setField(
                searchCriteriaSpecificationUtil, "addressTypeRepository", addressTypeRepository);

        AddressType mainAddressType = CreateOrganisationDataSetup.getAddressTypeData();
        List<AddressType> addressTypeList = new ArrayList<>();
        addressTypeList.add(mainAddressType);
        doReturn(addressTypeList).when(addressTypeRepository).findAll();
    }

    @Test
    void whenAllCriteria_CriteriaMatches_ExpectCriteriaBuilderIsCalled() {

        RoSearchCriteria searchCriteria = SearchOrganisationDataSetup.getRoSearchCriteria();
        doReturn(joinAddressMock)
                .when(recognisingOrganisationRoot)
                .joinList("addresses", JoinType.LEFT);
        doReturn(partialMatchSpec)
        .when(searchPartialRoNameCriteriaSpecificationUtil)
        .criteriaMatches(searchCriteria, joinAddressMock);

        Specification<RecognisingOrganisation> actual =
                searchCriteriaSpecificationUtil.criteriaMatches(searchCriteria);
        actual.toPredicate(recognisingOrganisationRoot, criteriaQuery, criteriaBuilder);

        verify(criteriaBuilder, times(4)).isNull(pathCaptor.capture());
        verify(criteriaBuilder)
                .equal(
                        recognisingOrganisationRoot.get("organisationTypeUuid"),
                        searchCriteria.getOrganisationTypeUuid());
    }

    @Test
    void
            whenOrgStatusCriteriaIsEmpty_CriteriaMatches_ExpectOrgStatusCriteriaBuilderIsNeverCalled() {
        RoSearchCriteria searchCriteria = SearchOrganisationDataSetup.getRoSearchCriteria();
        searchCriteria.setOrganisationStatus(null);
        doReturn(joinAddressMock)
                .when(recognisingOrganisationRoot)
                .joinList("addresses", JoinType.LEFT);
        doReturn(partialMatchSpec)
        .when(searchPartialRoNameCriteriaSpecificationUtil)
        .criteriaMatches(searchCriteria, joinAddressMock);
        Specification<RecognisingOrganisation> actual =
                searchCriteriaSpecificationUtil.criteriaMatches(searchCriteria);
        actual.toPredicate(recognisingOrganisationRoot, criteriaQuery, criteriaBuilder);

        verify(criteriaBuilder, times(4)).isNull(pathCaptor.capture());
        verify(criteriaBuilder, never())
                .equal(
                        recognisingOrganisationRoot.get("orgStatus"),
                        searchCriteria.getOrganisationStatus());
    }

    @Test
    void
            whenVerificationStatusCriteriaIsEmpty_CriteriaMatches_ExpectVerificationStatusCriteriaBuilderIsNeverCalled() {
        RoSearchCriteria searchCriteria = SearchOrganisationDataSetup.getRoSearchCriteria();
        searchCriteria.setVerificationStatus(null);
        doReturn(joinAddressMock)
                .when(recognisingOrganisationRoot)
                .joinList("addresses", JoinType.LEFT);
        doReturn(partialMatchSpec)
        .when(searchPartialRoNameCriteriaSpecificationUtil)
        .criteriaMatches(searchCriteria, joinAddressMock);
        Specification<RecognisingOrganisation> actual =
                searchCriteriaSpecificationUtil.criteriaMatches(searchCriteria);
        actual.toPredicate(recognisingOrganisationRoot, criteriaQuery, criteriaBuilder);

        verify(criteriaBuilder, times(4)).isNull(pathCaptor.capture());
        verify(criteriaBuilder, never())
                .equal(
                        recognisingOrganisationRoot.get("verificationStatus"),
                        searchCriteria.getVerificationStatus());
    }

    @Test
    void whenOrgIdCriteriaIsEmpty_CriteriaMatches_ExpectOrgIdCriteriaBuilderIsNeverCalled() {
        RoSearchCriteria searchCriteria = SearchOrganisationDataSetup.getRoSearchCriteria();
        searchCriteria.setOrganisationId(null);
        doReturn(joinAddressMock)
                .when(recognisingOrganisationRoot)
                .joinList("addresses", JoinType.LEFT);
        doReturn(partialMatchSpec)
        .when(searchPartialRoNameCriteriaSpecificationUtil)
        .criteriaMatches(searchCriteria, joinAddressMock);
        Specification<RecognisingOrganisation> actual =
                searchCriteriaSpecificationUtil.criteriaMatches(searchCriteria);
        actual.toPredicate(recognisingOrganisationRoot, criteriaQuery, criteriaBuilder);

        verify(criteriaBuilder, times(4)).isNull(pathCaptor.capture());
        verify(criteriaBuilder, never())
                .equal(
                        recognisingOrganisationRoot.get("organisationId"),
                        searchCriteria.getOrganisationId());
    }

    @Test
    void
            whenOrgTypeUuidCriteriaIsEmpty_CriteriaMatches_ExpectOrgTypeUuidCriteriaBuilderIsNeverCalled() {
        RoSearchCriteria searchCriteria = SearchOrganisationDataSetup.getRoSearchCriteria();
        searchCriteria.setOrganisationTypeUuid(null);
        doReturn(joinAddressMock)
                .when(recognisingOrganisationRoot)
                .joinList("addresses", JoinType.LEFT);
     doReturn(partialMatchSpec)
        .when(searchPartialRoNameCriteriaSpecificationUtil)
        .criteriaMatches(searchCriteria, joinAddressMock);

        Specification<RecognisingOrganisation> actual =
                searchCriteriaSpecificationUtil.criteriaMatches(searchCriteria);
        actual.toPredicate(recognisingOrganisationRoot, criteriaQuery, criteriaBuilder);

        verify(criteriaBuilder, times(4)).isNull(pathCaptor.capture());
        verify(criteriaBuilder, never())
                .equal(
                        recognisingOrganisationRoot.get("organisationTypeUuid"),
                        searchCriteria.getOrganisationTypeUuid());
    }

    @Test
    void
            whenPartnerCodeCriteriaIsEmpty_CriteriaMatches_ExpectPartnerCodeCriteriaBuilderIsNeverCalled() {
        RoSearchCriteria searchCriteria = SearchOrganisationDataSetup.getRoSearchCriteria();
        searchCriteria.setPartnerCode("");
        doReturn(joinAddressMock)
                .when(recognisingOrganisationRoot)
                .joinList("addresses", JoinType.LEFT);
        doReturn(partialMatchSpec)
        .when(searchPartialRoNameCriteriaSpecificationUtil)
        .criteriaMatches(searchCriteria, joinAddressMock);
        Specification<RecognisingOrganisation> actual =
                searchCriteriaSpecificationUtil.criteriaMatches(searchCriteria);
        actual.toPredicate(recognisingOrganisationRoot, criteriaQuery, criteriaBuilder);

        verify(criteriaBuilder, times(4)).isNull(pathCaptor.capture());
        verify(criteriaBuilder, never())
                .equal(
                        recognisingOrganisationRoot.get("partnerCode"),
                        searchCriteria.getPartnerCode());
    }

    @Test
    void whenCityCriteriaIsEmpty_CriteriaMatches_ExpectCityCriteriaBuilderIsNeverCalled() {
        RoSearchCriteria searchCriteria = SearchOrganisationDataSetup.getRoSearchCriteria();
        searchCriteria.setCity("");
        doReturn(joinAddressMock)
                .when(recognisingOrganisationRoot)
                .joinList("addresses", JoinType.LEFT);
        doReturn(partialMatchSpec)
        .when(searchPartialRoNameCriteriaSpecificationUtil)
        .criteriaMatches(searchCriteria, joinAddressMock);
        Specification<RecognisingOrganisation> actual =
                searchCriteriaSpecificationUtil.criteriaMatches(searchCriteria);
        actual.toPredicate(recognisingOrganisationRoot, criteriaQuery, criteriaBuilder);

        verify(criteriaBuilder, times(3)).isNull(pathCaptor.capture());
        verify(criteriaBuilder, never())
                .equal(joinAddressMock.get("city"), searchCriteria.getCity());
    }

    @Test
    void
            whenPostalCodeCriteriaIsEmpty_CriteriaMatches_ExpectPostalCodeCriteriaBuilderIsNeverCalled() {
        RoSearchCriteria searchCriteria = SearchOrganisationDataSetup.getRoSearchCriteria();
        searchCriteria.setPostalCode("");
        doReturn(joinAddressMock)
                .when(recognisingOrganisationRoot)
                .joinList("addresses", JoinType.LEFT);
        doReturn(partialMatchSpec)
        .when(searchPartialRoNameCriteriaSpecificationUtil)
        .criteriaMatches(searchCriteria, joinAddressMock);
        Specification<RecognisingOrganisation> actual =
                searchCriteriaSpecificationUtil.criteriaMatches(searchCriteria);
        actual.toPredicate(recognisingOrganisationRoot, criteriaQuery, criteriaBuilder);

        verify(criteriaBuilder, times(3)).isNull(pathCaptor.capture());
        verify(criteriaBuilder, never())
                .equal(joinAddressMock.get("postalCode"), searchCriteria.getPostalCode());
    }
    @Test
    void
    whenCountryCriteriaIsEmpty_CriteriaMatches_ExpectCountryCriteriaBuilderIsNeverCalled() {
        RoSearchCriteria searchCriteria = SearchOrganisationDataSetup.getRoSearchCriteria();
        searchCriteria.setCountry(null);
        doReturn(joinAddressMock)
                .when(recognisingOrganisationRoot)
                .joinList("addresses", JoinType.LEFT);
        doReturn(partialMatchSpec)
        .when(searchPartialRoNameCriteriaSpecificationUtil)
        .criteriaMatches(searchCriteria, joinAddressMock);
        Specification<RecognisingOrganisation> actual =
                searchCriteriaSpecificationUtil.criteriaMatches(searchCriteria);
        actual.toPredicate(recognisingOrganisationRoot, criteriaQuery, criteriaBuilder);

        verify(criteriaBuilder, times(3)).isNull(pathCaptor.capture());
        verify(criteriaBuilder, never())
                .equal(joinAddressMock.get("countryUuid"), searchCriteria.getPostalCode());
    }
    @Test
    void
    whenTerritoryCriteriaIsEmpty_ExactCriteriaMatches_ExpectTerritoryCriteriaBuilderIsNeverCalled() {
        RoSearchCriteria searchCriteria = SearchOrganisationDataSetup.getRoSearchCriteria();
        searchCriteria.setTerritory(null);;
        doReturn(joinAddressMock)
                .when(recognisingOrganisationRoot)
                .joinList("addresses", JoinType.LEFT);
        doReturn(partialMatchSpec)
                .when(searchPartialRoNameCriteriaSpecificationUtil)
                .criteriaMatches(searchCriteria, joinAddressMock);

        Specification<RecognisingOrganisation> actual =
                searchCriteriaSpecificationUtil.criteriaMatches(searchCriteria);
        actual.toPredicate(recognisingOrganisationRoot, criteriaQuery, criteriaBuilder);

        verify(criteriaBuilder, times(3)).isNull(pathCaptor.capture());
        verify(criteriaBuilder, never())
                .equal(joinAddressMock.get("terrirtoeyUuuid"), searchCriteria.getPostalCode());
    }

}
