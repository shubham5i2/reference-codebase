package com.ielts.cmds.organisation.domain.services;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.organisation.domain.commands.OrganisationHierarchyUpdate;
import com.ielts.cmds.organisation.domain.model.HierarchyUpdateV1;
import com.ielts.cmds.organisation.domain.model.RoDataUpdateV1Valid;
import com.ielts.cmds.organisation.domain.utils.OrganisationHierarchyUpdateUtil;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.LinkedRecognisingOrganisationRepository;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.utills.CreateOrganisationDataSetup;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utills.ROHierarchyUpdateDataSetup;
import com.ielts.cmds.organisation.utills.UpdateOrganisationDataSetup;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
@RunWith(MockitoJUnitRunner.class)
class OrganisationHierarchyUpdateDomainServiceTest {

    @InjectMocks private OrganisationHierarchyUpdateDomainService hierarchyUpdateDomainService;

    @Mock private RecognisingOrganisationRepository roRepository;

    @Mock private LinkedRecognisingOrganisationRepository linkedRORepository;

    @Mock private OrganisationCommonUtils orgCommonUtils;

    @Mock private ObjectMapper objectMapper;

    @Captor private ArgumentCaptor<RecognisingOrganisation> organisationCapt;

    @Mock private ApplicationEventPublisher applicationEventPublisher;

    @Spy private OrganisationHierarchyUpdateUtil organisationHierarchyUpdateUtil;

    /** @throws Exception */
    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(orgCommonUtils, "orgRepository", roRepository);
        ReflectionTestUtils.setField(
                hierarchyUpdateDomainService, "orgCommonUtils", orgCommonUtils);
        ReflectionTestUtils.setField(
                hierarchyUpdateDomainService,
                "orgHierarchyUpdateUtil",
                organisationHierarchyUpdateUtil);
        ReflectionTestUtils.setField(
                organisationHierarchyUpdateUtil, "linkedRORepository", linkedRORepository);
    }

    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("argumentsProviderForHierarchyROUpdateEvent")
    void whenReceivedValidCommmand_updateSiblingOrganisation_thenNoException(
            final BaseEvent<UiHeader> rocmdsEvent,
            final OrganisationHierarchyUpdate organisationHierarchyUpdate,
            RecognisingOrganisation organisation,
            RoChangedEventV1 roChangedEvent)
            throws JsonProcessingException, RbacValidationException {

        when(linkedRORepository.findAllByOrganisationHierarchyLabel(
                organisationHierarchyUpdate.getEventBody().getOldHierarchyLabel()))
                .thenReturn(organisation.getLinkedRecognisingOrganisations());
        Set<RecognisingOrganisation> childHierarchy = new HashSet<>();
        RecognisingOrganisation childRO = new RecognisingOrganisation();
        childRO.setRecognisingOrganisationUuid(
                organisation
                        .getLinkedRecognisingOrganisations()
                        .get(0)
                        .getTargetRecognisingOrganisation()
                        .getRecognisingOrganisationUuid());
        childRO.setLinkedRecognisingOrganisations(organisation.getLinkedRecognisingOrganisations());
        childHierarchy.add(childRO);
        when(orgCommonUtils.getChildHierarchyBasedOnRO(
                organisationHierarchyUpdate
                        .getEventBody()
                        .getTriggerRecognisingOrganisationUuid(),
                Boolean.FALSE))
                .thenReturn(childHierarchy);
        when(roRepository.findById(
                organisationHierarchyUpdate
                        .getEventBody()
                        .getRecognisingOrganisationUuid()))
                .thenReturn(Optional.of(organisation));
        when(roRepository.save(organisation)).thenReturn(organisation);
        hierarchyUpdateDomainService.onCommand(organisationHierarchyUpdate);
        verify(roRepository, times(1)).save(organisationCapt.capture());
        verify(orgCommonUtils)
                .publishUpdateEvent(
                        organisationHierarchyUpdate.getEventHeaders(),
                        organisationHierarchyUpdate.getAudit(),
                        organisation);
    }

    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("argumentsProviderForHierarchyROUpdateEvent")
    void whenReceivedValidCommmand_updateChildOrganisation_thenNoException(
            final BaseEvent<UiHeader> rocmdsEvent,
            final OrganisationHierarchyUpdate organisationHierarchyUpdate,
            RecognisingOrganisation organisation,
            RoChangedEventV1 roChangedEvent)
            throws JsonProcessingException, RbacValidationException {

        organisationHierarchyUpdate
                .getEventBody()
                .setRecognisingOrganisationUuid(
                        UUID.fromString("f2fa0e53-a0ea-4024-9fec-32eab97d3aa0"));
        when(linkedRORepository.findAllByOrganisationHierarchyLabel(
                organisationHierarchyUpdate.getEventBody().getOldHierarchyLabel()))
                .thenReturn(organisation.getLinkedRecognisingOrganisations());
        Set<RecognisingOrganisation> childHierarchy = new HashSet<>();
        RecognisingOrganisation childRO = new RecognisingOrganisation();
        childRO.setRecognisingOrganisationUuid(
                UUID.fromString("f2fa0e53-a0ea-4024-9fec-32eab97d3aa0"));
        childRO.setLinkedRecognisingOrganisations(organisation.getLinkedRecognisingOrganisations());
        childHierarchy.add(childRO);
        when(orgCommonUtils.getChildHierarchyBasedOnRO(
                organisationHierarchyUpdate
                        .getEventBody()
                        .getTriggerRecognisingOrganisationUuid(),
                Boolean.FALSE))
                .thenReturn(childHierarchy);
        when(roRepository.findById(
                organisationHierarchyUpdate
                        .getEventBody()
                        .getRecognisingOrganisationUuid()))
                .thenReturn(Optional.of(childRO));
        when(roRepository.save(childRO)).thenReturn(childRO);
        hierarchyUpdateDomainService.onCommand(organisationHierarchyUpdate);
        verify(roRepository, times(1)).save(organisationCapt.capture());
        verify(orgCommonUtils)
                .publishUpdateEvent(
                        organisationHierarchyUpdate.getEventHeaders(),
                        organisationHierarchyUpdate.getAudit(),
                        childRO);
    }

    private static Stream<Arguments> argumentsProviderForHierarchyROUpdateEvent()
            throws JsonProcessingException {
        UiHeader roHeaders = OrganisationTestUtil.generateEventHeader();
        roHeaders.setEventName(OrganisationConstants.EventType.RO_HIERARCHY_UPDATE_EVENT);
        HierarchyUpdateV1 hierarchyUpdateV1 =
                ROHierarchyUpdateDataSetup.createHierarchyUpdateV1Data();
        BaseAudit audit = new BaseAudit();
        Map<String, String> auditContext = new HashMap<>();
        audit.setAuditContext(auditContext);
        final BaseEvent<UiHeader> event =
                new BaseEvent<UiHeader>(
                        roHeaders,
                        new ObjectMapper().writeValueAsString(hierarchyUpdateV1),
                        null,
                        audit);
        OrganisationHierarchyUpdate hierarchyROAnalysis =
                OrganisationHierarchyUpdate.builder()
                        .eventHeaders(event.getEventHeader())
                        .eventBody(hierarchyUpdateV1)
                        .eventErrors(event.getEventErrors())
                        .audit(audit)
                        .build();
        final RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        RecognisingOrganisation organisation =
                UpdateOrganisationDataSetup.getExistingOrganisationDetails(
                        roDataUpdate, new RecognisingOrganisation());
        RoChangedEventV1 roChangedEvent =
                CreateOrganisationDataSetup.entityToEventMapper(organisation);
        return Stream.of(Arguments.of(event, hierarchyROAnalysis, organisation, roChangedEvent));
    }
}
