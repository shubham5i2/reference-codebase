package com.ielts.cmds.organisation.infrastructure.config;

import com.cmds.auth0.validation.service.JWTDecoderImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.ielts.cmds.common.config.AWSCredentialsProviderFactory;
import com.ielts.cmds.common.config.JmsListnerConfig;
import com.ielts.cmds.organisation.application.OrganisationAddService;
import com.ielts.cmds.organisation.domain.services.*;
import com.ielts.cmds.organisation.infrastructure.event.listner.OrganisationIntListener;
import com.ielts.cmds.organisation.infrastructure.event.listner.OrganisationListner;
import com.ielts.cmds.outbox.event.OutboxEventBuilder;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.api.service.impl.RBACServiceImpl;
import com.ielts.cmds.rbac.implementation.impl.LocationHierarchyServiceImpl;
import com.ielts.cmds.rbac.implementation.impl.ProductHierarchyServiceImpl;
import com.ielts.cmds.rbac.implementation.impl.UserGroupServiceImpl;
import java.util.Optional;

import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@TestPropertySource("classpath:application-test.properties")
@EntityScan({
    "com.ielts.cmds.organisation.infrastructure.entity",
    "com.ielts.cmds.organisation.utils",
    "com.ielts.cmds.rbac.implementation.infrastucture.entity",
    "com.ielts.cmds.outbox.infra.entity",
        "com.ielts.cmds.organisation.cache.entity",
    "com.ielts.cmds.outbox.event"
})
@DataJpaTest(
        excludeAutoConfiguration = {JmsListnerConfig.class, AWSCredentialsProviderFactory.class})
@EnableTransactionManagement
@EnableJpaAuditing(auditorAwareRef = "testAuditorProvider")
@EnableJpaRepositories(
        basePackages = {
            "com.ielts.cmds.organisation.infrastructure.repository",
            "com.ielts.cmds.rbac.implementation.infrastucture.repository",
            "com.ielts.cmds.outbox.infra.repository"
        })
@Profile("test")
@EnableCaching(proxyTargetClass = true)
@ComponentScan(
        basePackages = {
            "com.ielts.cmds.rbac.implementation.impl",
                "com.ielts.cmds.organisation.cache.factory",
                "com.ielts.cmds.organisation.cache",
            "com.ielts.cmds.common.exception",
            "com.ielts.cmds.organisation.domain",
            "com.ielts.cmds.organisation.infrastructure",
            "com.ielts.cmds.organisation.utils",
            "com.ielts.cmds.outbox.event",
            "com.ielts.cmds.serialization.application.utils"
        },
        excludeFilters = {
            @ComponentScan.Filter(
                    type = FilterType.ASSIGNABLE_TYPE,
                    value = OrganisationAddService.class),
            @ComponentScan.Filter(
                    type = FilterType.ASSIGNABLE_TYPE,
                    value = OrganisationIntListener.class),
            @ComponentScan.Filter(
                    type = FilterType.ASSIGNABLE_TYPE,
                    value = OrganisationListner.class),
            @ComponentScan.Filter(
                    type = FilterType.ASSIGNABLE_TYPE,
                    value = LoadRODomainService.class),
            @ComponentScan.Filter(
                    type = FilterType.ASSIGNABLE_TYPE,
                    value = LoadROUpdateDomainService.class),
            @ComponentScan.Filter(
                    type = FilterType.ASSIGNABLE_TYPE,
                    value = LoadROHierarchyHelper.class),
            @ComponentScan.Filter(
                    type = FilterType.ASSIGNABLE_TYPE,
                    value = BulkRORecognisedProductsUpdateHelper.class),
            @ComponentScan.Filter(
                        type = FilterType.ASSIGNABLE_TYPE,
                        value = ROApplicationConfig.class)
        })
public class RBACTestConfig {

    static long cacheAndBucketSize = 10;
    static long leewayInSecond = 300000000;
    static long expiresInHours = 1;
    static long refillRateInMinutes = 1;
    static String auth0PublicEndpoint = "https://cmds-sandbox.eu.auth0.com/";
    static String auth0NamespaceRoles = "https://cmdsiz.com/roles";
    static String auth0NamespacePartnerCode = "https://cmdsiz.com/partnerCode";
    static String auth0NamespaceNickname = "https://cmdsiz.com/nickname";
    static String auth0NamespaceId = "https://cmdsiz.com/id";
    static String auth0NamespaceEmail = "https://cmdsiz.com/email";
    static String auth0NamespaceFirstName = "https://cmdsiz.com/firstName";
    static String auth0NamespaceLastName = "https://cmdsiz.com/lastName";

    @Autowired private UserGroupServiceImpl userGroupServiceImpl;
    @Autowired private LocationHierarchyServiceImpl locationHierarchyServiceImpl;
    @Autowired private ProductHierarchyServiceImpl productHierarchyServiceImpl;

    @Value("${is-cluster-mode-enabled}")
    private String isClusterModeEnabled;

    @Bean
    public RBACServiceImpl getRbacServiceImpl() throws RbacValidationException {
        JWTDecoderImpl jwtDecoder =
                new JWTDecoderImpl(
                        auth0PublicEndpoint,
                        cacheAndBucketSize,
                        expiresInHours,
                        refillRateInMinutes,
                        auth0NamespaceRoles,
                        auth0NamespacePartnerCode,
                        auth0NamespaceNickname,
                        auth0NamespaceId,
                        auth0NamespaceEmail,
                        auth0NamespaceFirstName,
                        auth0NamespaceLastName,
                        leewayInSecond) {};
        RBACServiceImpl rbacServiceImpl =
                new RBACServiceImpl(
                        jwtDecoder,
                        userGroupServiceImpl,
                        locationHierarchyServiceImpl,
                        productHierarchyServiceImpl);
        return rbacServiceImpl;
    }

    @Bean
    @Primary
    public ObjectMapper getObjectMapper() {
        return new ObjectMapper();
    }

    @Bean
    public CsvMapper csvMapper() {
        return new CsvMapper();
    }

    @Bean
    public AuditorAware<String> testAuditorProvider() {
        return () -> Optional.of("Test auditor");
    }

    @Bean
    public OutboxEventBuilder getOutboxEventBuilder() {
        return new OutboxEventBuilder();
    }

}
