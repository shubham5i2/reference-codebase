package com.ielts.cmds.organisation.domain.services;

import static org.junit.jupiter.api.Assertions.assertThrows;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

/** @author cts */
@ExtendWith(MockitoExtension.class)
class CommonLoadROServiceTest {

    @Mock private CsvMapper csvMapper;
    @Mock private ObjectMapper objectMapper;
    @InjectMocks private CommonLoadROService commonLoadROService;

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void whenEventContext_isNull_thenVerifyForCMDSException(BaseEvent<UiHeader> roCmdsEvent)
            throws Exception {
        roCmdsEvent.getEventHeader().setEventContext(null);
        Executable executable =
                () -> commonLoadROService.getOperationMode(roCmdsEvent.getEventHeader());
        IllegalArgumentException illegalArgumentException =
                assertThrows(IllegalArgumentException.class, executable);
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void whenEventContext_isEmpty_thenVerifyForCMDSException(BaseEvent<UiHeader> roCmdsEvent)
            throws Exception {
        roCmdsEvent.getEventHeader().setEventContext(new HashMap<>());
        Executable executable =
                () -> commonLoadROService.getOperationMode(roCmdsEvent.getEventHeader());
        IllegalArgumentException illegalArgumentException =
                assertThrows(IllegalArgumentException.class, executable);
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void whenOrganisationType_isNotPresent_thenVerifyForCMDSException(
            BaseEvent<UiHeader> roCmdsEvent) throws Exception {
        Executable executable =
                () -> commonLoadROService.getOperationMode(roCmdsEvent.getEventHeader());
        IllegalArgumentException illegalArgumentException =
                assertThrows(IllegalArgumentException.class, executable);
    }

    /*
     * This is method source to provide arguments for the required test cases
     * wherever this method source has been used. It's specific to LoadROData event
     */
    private static Stream<Arguments> argumentsProviderForOrganisationLoadDataEvent()
            throws JsonProcessingException {

        UiHeader roHeaders = OrganisationTestUtil.generateEventHeader();
        roHeaders.setEventName(
                OrganisationConstants.GenericConstants.OPERATION_TYPE_GET
                        + OrganisationConstants.GenericConstants.LOAD_RO_DATA_RESOURCE_TYPE);
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put(OrganisationConstants.GenericConstants.RO_DATA_FILE, "test.csv");
        eventContext.put(OrganisationConstants.GenericConstants.MODE, "create");
        roHeaders.setEventContext(eventContext);
        BaseAudit audit = new BaseAudit();
        final BaseEvent<UiHeader> event = new BaseEvent<UiHeader>(roHeaders, null, null, audit);

        return Stream.of(Arguments.of(event));
    }
}
