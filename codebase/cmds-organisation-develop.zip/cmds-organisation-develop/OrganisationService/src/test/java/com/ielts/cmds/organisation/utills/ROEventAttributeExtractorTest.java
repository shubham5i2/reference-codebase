package com.ielts.cmds.organisation.utills;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.organisation.utils.ROEventAttributeExtractor;
import com.ielts.cmds.outbox.event.model.OutboxEventAttribute;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ROEventAttributeExtractorTest {

    @InjectMocks ROEventAttributeExtractor roEventAttributeExtractor;

    @Test
    void when_validCommand_withBaseHeader_thenVerify_EventName() {
        BaseHeader baseHeader = new BaseHeader();
        baseHeader.setEventName("mockEvent");
        BaseEvent<BaseHeader> event = new BaseEvent<>();
        event.setEventHeader(baseHeader);
        event.setEventBody(null);
        event.setEventErrors(null);
        List<OutboxEventAttribute> eventAttributes;
        eventAttributes = roEventAttributeExtractor.apply(event);
        assertEquals("mockEvent", eventAttributes.get(0).getAttributeValue());
    }

    @Test
    void when_validCommand_withUiHeader_thenVerify_ConnectionId() {
        UiHeader baseHeader = new UiHeader();
        baseHeader.setEventName("mockEvent");
        baseHeader.setConnectionId("ec81310d-03b6-");
        BaseEvent<BaseHeader> event = new BaseEvent<>(baseHeader, null, null, null);
        List<OutboxEventAttribute> eventAttributes;
        eventAttributes = roEventAttributeExtractor.apply(event);
        assertEquals("ec81310d-03b6-", eventAttributes.get(1).getAttributeValue());
    }
}
