package com.ielts.cmds.organisation.utills;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.domain.model.LoadROHierarchyDataV1;
import com.ielts.cmds.organisation.domain.model.LoadROHierarchyMapV1;
import com.ielts.cmds.organisation.domain.model.LoadROHierarchyMessageV1;
import com.ielts.cmds.organisation.domain.model.LoadROHierarchyRecordEvent;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LoadROHierarchyDataSetup {

    public static List<LoadROHierarchyDataV1> getLoadROHierarchyDataV1List() {
        List<LoadROHierarchyDataV1> loadROHierarchyDataV1List = new ArrayList<>();
        LoadROHierarchyDataV1 loadROHierarchyDataV1 = new LoadROHierarchyDataV1();
        loadROHierarchyDataV1.setRecognisingOrganisationUuid("31c2d165-83cb-4ae0-8c4c-082317b9b1f8");
        loadROHierarchyDataV1.setOrganisationId("123");
        loadROHierarchyDataV1.setParentOrganisationId("456");
        loadROHierarchyDataV1.setResultsDeliveryOrgIds("789|456");
        loadROHierarchyDataV1List.add(loadROHierarchyDataV1);
        return loadROHierarchyDataV1List;
    }

    public static Map<String, LoadROHierarchyRecordEvent> getEventsMap(
            final BaseEvent<BaseHeader> baseEvent,
            final LoadROHierarchyDataV1 loadROHierarchyDataV1) {
        Map<String, LoadROHierarchyRecordEvent> eventsMap = new HashMap<>();
        LoadROHierarchyRecordEvent loadROHierarchyRecordEvent = new LoadROHierarchyRecordEvent();
        loadROHierarchyRecordEvent.setEvent(baseEvent);
        loadROHierarchyRecordEvent.setLoadROHierarchyRecord(loadROHierarchyDataV1);
        eventsMap.put("1", loadROHierarchyRecordEvent);
        return eventsMap;
    }

    public static BaseEvent<BaseHeader> getROCreatedEvent(final RecognisingOrganisation publishRo)
            throws JsonProcessingException {
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        BaseHeader baseHeader = (BaseHeader) OrganisationTestUtil.generateEventHeader();
        baseHeader.setEventName(OrganisationConstants.EventType.RO_UPDATED_EVENT);
        baseEvent.setEventHeader(baseHeader);
        baseEvent.setEventBody(
                new ObjectMapper()
                        .writeValueAsString(
                                CreateOrganisationDataSetup.entityToEventMapper(publishRo)));
        return baseEvent;
    }

    public static BaseEvent<BaseHeader> getROChangedRejectedEvent() {
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        BaseHeader baseHeader = (BaseHeader) OrganisationTestUtil.generateEventHeader();
        baseHeader.setEventName(OrganisationConstants.EventType.RO_UPDATE_REJECTED_EVENT);
        baseEvent.setEventHeader(baseHeader);
        baseEvent.setEventErrors(
                new BaseEventErrors(
                        OrganisationTestUtil.getROErrorResponse(
                                        "V0004",
                                        "Organisation Name is Empty",
                                        "Mandatory Field Validation Failure - OrganisationName")
                                .getErrorList()));
        return baseEvent;
    }

    public static LoadROHierarchyMessageV1 getLoadROHierarchyMessageV1(
            final LoadROHierarchyDataV1 loadROHierarchyDataV1) {
        LoadROHierarchyMessageV1 loadROHierarchyMessageV1 = new LoadROHierarchyMessageV1();
        LoadROHierarchyMapV1 loadROHierarchyMapV1 = new LoadROHierarchyMapV1();
        loadROHierarchyMapV1.put("1", loadROHierarchyDataV1);
        loadROHierarchyMessageV1.setMsg(loadROHierarchyMapV1);
        return loadROHierarchyMessageV1;
    }
}
