package com.ielts.cmds.organisation.utills;

import com.ielts.cmds.api.roui005rosearchrequested.RoSearchCriteria;
import com.ielts.cmds.api.roui005rosearchrequested.RoSearchObject;
import com.ielts.cmds.api.roui005rosearchrequested.SearchPagination;
import com.ielts.cmds.api.roui005rosearchrequested.SearchSortItem;
import com.ielts.cmds.api.roui007rocreaterequested.VerificationStatusEnum;
import com.ielts.cmds.api.roui007rocreaterequested.MethodOfDeliveryEnum;
import com.ielts.cmds.api.roui007rocreaterequested.OrganisationStatusEnum;
import com.ielts.cmds.organisation.infrastructure.entity.RODuplicateExactSearchResult;
import com.ielts.cmds.organisation.infrastructure.entity.RODuplicateFuzzySearchResult;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class SearchOrganisationDataSetup {

    private SearchOrganisationDataSetup() {}

    public static RoSearchObject getRoSearchData() {
        RoSearchObject roSearchObject = new RoSearchObject();
        roSearchObject.setCriteria(getRoSearchCriteria());
        roSearchObject.setPagination(getRoSearchV1Pagination());
        roSearchObject.setSorting(getRoSearchSorting());
        return roSearchObject;
    }

    public static List<SearchSortItem> getRoSearchSorting() {
        List<SearchSortItem> searchSortItems = new ArrayList<>();
        SearchSortItem searchSortItem = new SearchSortItem();
        searchSortItem.setSortBy("organisationId");
        searchSortItem.setSortType("ASC");
        searchSortItems.add(searchSortItem);
        return searchSortItems;
    }

    public static SearchPagination getRoSearchV1Pagination() {
        SearchPagination searchPagination = new SearchPagination();
        searchPagination.setPageNumber(BigDecimal.valueOf(0));
        searchPagination.setPageSize(BigDecimal.valueOf(20));
        return searchPagination;
    }

    public static RoSearchCriteria getRoSearchCriteria() {
        RoSearchCriteria roSearchCriteria = new RoSearchCriteria();
        roSearchCriteria.setCity("Cambridge");
        roSearchCriteria.setContactEmail("xyz@example.com");
        roSearchCriteria.setFuzzyMatch(true);
        roSearchCriteria.setContactName("Test Contact");
        roSearchCriteria.setOrganisationId(321);
        roSearchCriteria.setOrganisationName("London Metropolitain University");
        roSearchCriteria.setOrganisationStatus(RoSearchCriteria.OrganisationStatusEnum.valueOf(OrganisationStatusEnum.ACTIVE.getValue()));
        roSearchCriteria.setOrganisationTypeUuid(UUID.fromString("e496aa98-86a3-476d-8be3-21ee0aa23c93"));
        roSearchCriteria.setPartnerCode("BC");
        roSearchCriteria.setPostalCode("DBP 001");
        roSearchCriteria.setVerificationStatus(RoSearchCriteria.VerificationStatusEnum.valueOf(VerificationStatusEnum.APPROVED.getValue()));
        roSearchCriteria.setCountry(UUID.fromString("029fd27d-b39a-48b4-87e7-131a063bea2d"));
        roSearchCriteria.setTerritory(UUID.fromString("029fd27d-b39a-48b4-87e7-131a063bea2d"));
        return roSearchCriteria;
    }

    public static RoSearchCriteria getRoSearchCriteriaOnlyOrgName() {
        RoSearchCriteria roSearchCriteria = new RoSearchCriteria();
        roSearchCriteria.setOrganisationName("cambridge university");
        roSearchCriteria.setFuzzyMatch(true);

        return roSearchCriteria;
    }

    public static RODuplicateFuzzySearchResult getRoDuplicateSearchResult() {
    	RODuplicateFuzzySearchResult roDuplicateSearchResult = new RODuplicateFuzzySearchResult();
        roDuplicateSearchResult.setRecognisingOrganisationUuid(UUID.randomUUID());
        roDuplicateSearchResult.setName("London  Metropolitain University");
        roDuplicateSearchResult.setOrganisationCode("UCAS231");
        roDuplicateSearchResult.setMethodOfDelivery(MethodOfDeliveryEnum.POSTAL);
        roDuplicateSearchResult.setVerificationStatus(VerificationStatusEnum.APPROVED);
        roDuplicateSearchResult.setOrgStatus(OrganisationStatusEnum.ACTIVE);
        roDuplicateSearchResult.setOrganisationId(323);
        roDuplicateSearchResult.setPartnerCode("BC");
        roDuplicateSearchResult.setPhone("+41 023467698");
        roDuplicateSearchResult.setSectorTypeUuid(UUID.randomUUID());
        roDuplicateSearchResult.setSoftDeleted(false);
        roDuplicateSearchResult.setTargetRecognisingOrganisationUuid(
                UUID.fromString("2828b396-3e05-412a-b659-eda0903898bb"));
        populateAddressDuplicateSearchResult(roDuplicateSearchResult);
        return roDuplicateSearchResult;
    }

    public static void populateAddressDuplicateSearchResult(
    		RODuplicateFuzzySearchResult roDuplicateSearchResult) {
        roDuplicateSearchResult.setAddressline1("42, Duncan Street");
        roDuplicateSearchResult.setAddressline2("Third Avenue");
        roDuplicateSearchResult.setAddressTypeUuid(UUID.randomUUID());
        roDuplicateSearchResult.setEmail("alan@gmail.com");
        roDuplicateSearchResult.setCity("Cambridge");
        roDuplicateSearchResult.setAddressUuid(UUID.randomUUID());
        roDuplicateSearchResult.setCountryUuid(UUID.randomUUID());
        roDuplicateSearchResult.setTerritoryUuid(UUID.randomUUID());
        roDuplicateSearchResult.setWebsiteUrl("www.dciu.org");
        roDuplicateSearchResult.setPostalCode("CB2 8EA");
    }
    public static RODuplicateExactSearchResult getRoDuplicateFullTextSearchResult() {
    	RODuplicateExactSearchResult roDuplicateSearchResult = new RODuplicateExactSearchResult();
        roDuplicateSearchResult.setRecognisingOrganisationUuid(UUID.randomUUID());
        roDuplicateSearchResult.setName("London  Metropolitain University");
        roDuplicateSearchResult.setOrganisationCode("UCAS231");
        roDuplicateSearchResult.setMethodOfDelivery(MethodOfDeliveryEnum.POSTAL);
        roDuplicateSearchResult.setVerificationStatus(VerificationStatusEnum.APPROVED);
        roDuplicateSearchResult.setOrgStatus(OrganisationStatusEnum.ACTIVE);
        roDuplicateSearchResult.setOrganisationId(323);
        roDuplicateSearchResult.setPartnerCode("BC");
        roDuplicateSearchResult.setPhone("+41 023467698");
        roDuplicateSearchResult.setSectorTypeUuid(UUID.randomUUID());
        roDuplicateSearchResult.setSoftDeleted(false);
        roDuplicateSearchResult.setTargetRecognisingOrganisationUuid(
                UUID.fromString("2828b396-3e05-412a-b659-eda0903898bb"));
        populateAddressDuplicateSearchResult(roDuplicateSearchResult);
        return roDuplicateSearchResult;
    }
    public static void populateAddressDuplicateSearchResult(
    		RODuplicateExactSearchResult roDuplicateSearchResult) {
        roDuplicateSearchResult.setAddressline1("42, Duncan Street");
        roDuplicateSearchResult.setAddressline2("Third Avenue");
        roDuplicateSearchResult.setAddressTypeUuid(UUID.randomUUID());
        roDuplicateSearchResult.setEmail("alan@gmail.com");
        roDuplicateSearchResult.setCity("Cambridge");
        roDuplicateSearchResult.setAddressUuid(UUID.randomUUID());
        roDuplicateSearchResult.setCountryUuid(UUID.randomUUID());
        roDuplicateSearchResult.setTerritoryUuid(UUID.randomUUID());
        roDuplicateSearchResult.setWebsiteUrl("www.dciu.org");
        roDuplicateSearchResult.setPostalCode("CB2 8EA");
    }
}
