package com.ielts.cmds.organisation.domain.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.roui005rosearchrequested.RoSearchObject;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.cache.JedisGenericReader;
import com.ielts.cmds.organisation.cache.factory.JedisFactory;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1;
import com.ielts.cmds.organisation.infrastructure.config.RBACTestConfig;
import com.ielts.cmds.organisation.infrastructure.entity.RODuplicateExactSearchResult;
import com.ielts.cmds.organisation.infrastructure.entity.RODuplicateFuzzySearchResult;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utills.SearchOrganisationDataSetup;
import com.ielts.cmds.organisation.utils.DuplicateSearchRoEntityToEventMapper;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.api.service.impl.RBACServiceImpl;
import com.ielts.cmds.rbac.implementation.impl.LocationHierarchyServiceImpl;
import com.ielts.cmds.rbac.implementation.impl.UserGroupServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

import javax.transaction.Transactional;
import javax.validation.ValidationException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = RBACTestConfig.class)
@ActiveProfiles("test")
@Sql({ "/sql/schema.sql", "/sql/note-type-data.sql", "/sql/ro-data-for-search.sql", "/sql/usergroup-hierarchy.sql",
      "/sql/contact-type-data.sql",
      "/sql/country-data.sql",
	   "/sql/product-data.sql",
      "/sql/territory-data.sql",
      "/sql/address-type-data.sql",
      "/sql/organisation-type-data.sql" })
@Transactional
class DuplicateSearchOrganisationDomainServiceIntegrationTest {

	@Autowired
	private DuplicateSearchOrganisationDomainService duplicateSearchOrganisationDomainService;

	@MockBean
	private DuplicateSearchRoEntityToEventMapper duplicateSearchRoEntityToEventMapper;

	@MockBean
	private SearchOrganisationDomainService searchOrganisationDomainService;

	@Autowired
	private RBACServiceImpl rbacServiceImpl;

	@Autowired
	private UserGroupServiceImpl userGroupServiceImpl;

	@Spy
	private OrganisationCommonUtils orgCommonUtils;

	@Autowired
	private LocationHierarchyServiceImpl locationHierarchyServiceImpl;

	@Captor
	private ArgumentCaptor<List<RODuplicateFuzzySearchResult>> fetchedFuzzyListCaptor;

	@Captor
	private ArgumentCaptor<List<RODuplicateExactSearchResult>> fetchedFullTextListCaptor;

	@MockBean private JedisGenericReader jedisGenericReader;

	@MockBean private JedisFactory jedisFactory;

	@BeforeEach
	void setup() throws RbacValidationException {
		MockitoAnnotations.initMocks(this);
		userGroupServiceImpl.populateUserGroupHierarchyData();
		locationHierarchyServiceImpl.populateRootData();
		ReflectionTestUtils.setField(duplicateSearchOrganisationDomainService, "rbacServiceImpl", rbacServiceImpl);
		ReflectionTestUtils.setField(duplicateSearchOrganisationDomainService, "duplicateSearchRoEntityToEventMapper",
				duplicateSearchRoEntityToEventMapper);
		ReflectionTestUtils.setField(duplicateSearchOrganisationDomainService, "searchOrganisationDomainService",
				searchOrganisationDomainService);
		ThreadLocalHeaderContext.setContext(OrganisationTestUtil
				.generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_UPDATE_REQUEST_EVENT));
		ThreadLocalAuditContext.setContext(OrganisationTestUtil.getBaseAudit());
		ReflectionTestUtils.setField(
				orgCommonUtils, "jedisGenericReader", jedisGenericReader);

	}

	@Sql(scripts = "/sql/fuzzy-search-alias.sql",
            executionPhase = ExecutionPhase.BEFORE_TEST_METHOD)
	@ParameterizedTest
	@MethodSource("provideArgumentsForSearchIntegrationTest")
	@Rollback
	void whenFuzzyToggleTrue_SearchROVO_FuzzyDataFetched(final RoSearchObject roSearchObject,
			final List<RecognisingOrganisation> orgList,
			final RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1)
			throws IOException {

		ThreadLocalHeaderContext.getContext().setXaccessToken(OrganisationTestUtil.getAccessToken("ops-manager-access-token"));

		assertDoesNotThrow(() -> duplicateSearchOrganisationDomainService.onCommand(roSearchObject));
		verify(duplicateSearchRoEntityToEventMapper).mapEntityToEventForFuzzySearch(eq(roSearchObject),
				fetchedFuzzyListCaptor.capture());
		assertEquals(1, fetchedFuzzyListCaptor.getValue().size());
		assertEquals("Dublin City University", fetchedFuzzyListCaptor.getValue().get(0).getName());
		assertEquals(234, fetchedFuzzyListCaptor.getValue().get(0).getOrganisationId());
		assertEquals("DXB 1234", fetchedFuzzyListCaptor.getValue().get(0).getPostalCode());
	}

	@Sql(scripts = "/sql/full-text-search-alias.sql",
            executionPhase = ExecutionPhase.BEFORE_TEST_METHOD)
	@ParameterizedTest
	@MethodSource("provideArgumentsForSearchIntegrationTest")
	@Rollback
	void whenFuzzyToggleFalse_SearchROVO_FullTextDataFetched(final RoSearchObject roSearchObject,
			final List<RecognisingOrganisation> orgList,
			final RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1)
			throws IOException {

		ThreadLocalHeaderContext.getContext().setXaccessToken(OrganisationTestUtil.getAccessToken("ops-manager-access-token"));

		roSearchObject.getCriteria().setFuzzyMatch(false);
		assertDoesNotThrow(() -> duplicateSearchOrganisationDomainService.onCommand(roSearchObject));
		verify(duplicateSearchRoEntityToEventMapper).mapEntityToEventForFullTextSearch(eq(roSearchObject),
				fetchedFullTextListCaptor.capture());
		assertEquals(1, fetchedFullTextListCaptor.getValue().size());
		assertEquals("Cambridge univeristy", fetchedFullTextListCaptor.getValue().get(0).getName());
		assertEquals(111, fetchedFullTextListCaptor.getValue().get(0).getOrganisationId());
		assertEquals("BC447", fetchedFullTextListCaptor.getValue().get(0).getPostalCode());
	}
	@Sql(scripts = "/sql/fuzzy-search-alias.sql",
            executionPhase = ExecutionPhase.BEFORE_TEST_METHOD)

	@ParameterizedTest
	@MethodSource("provideArgumentsForSearchIntegrationTest")
	@Rollback
	void whenSearchWithPostalCodeWithoutSpacesReturnResult(final RoSearchObject roSearchObject,
			final List<RecognisingOrganisation> orgList,
			final RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1)
			throws IOException {

		ThreadLocalHeaderContext.getContext().setXaccessToken(OrganisationTestUtil.getAccessToken("ops-manager-access-token"));
		roSearchObject.getCriteria().setPostalCode("DBP001");
		assertDoesNotThrow(() -> duplicateSearchOrganisationDomainService.onCommand(roSearchObject));
		verify(duplicateSearchRoEntityToEventMapper).mapEntityToEventForFuzzySearch(eq(roSearchObject),
				fetchedFuzzyListCaptor.capture());
		assertEquals(1, fetchedFuzzyListCaptor.getValue().size());
	}

	@ParameterizedTest
	@MethodSource("provideArgumentsForSearchIntegrationTest")
	@Rollback
	void whenInvalidToken_SearchROVO_ExpectException(final RoSearchObject roSearchObject,
			final List<RecognisingOrganisation> orgList,
			final RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1)
			throws IOException {

		ThreadLocalHeaderContext.getContext()
				.setXaccessToken(OrganisationTestUtil.getAccessToken("test-admin-support-access-token"));

		Executable executable = () -> duplicateSearchOrganisationDomainService.onCommand(roSearchObject);

		ValidationException exception = assertThrows(ValidationException.class, executable);
		assertEquals(OrganisationConstants.ErrorResponse.CANNOT_PERFORM_SEARCH, exception.getMessage());
	}

	private static Stream<Arguments> provideArgumentsForSearchIntegrationTest() throws JsonProcessingException {

		final RoSearchObject roSearchObject = SearchOrganisationDataSetup.getRoSearchData();

		final UiHeader uiHeaders = OrganisationTestUtil.generateEventHeader();
		uiHeaders.setEventName(OrganisationConstants.GenericConstants.RO_SEARCH_REQUEST_EVENT);
		final ObjectMapper mapper = new ObjectMapper();
		final String eventBody = mapper.writeValueAsString(roSearchObject);
		final BaseEvent<UiHeader> event = new BaseEvent<UiHeader>(uiHeaders, eventBody, null, null);
		List<RecognisingOrganisation> orgList = new ArrayList<>();
		orgList.add(new RecognisingOrganisation());

		RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1 = new RosSearchResultsGeneratedEventV1();
		rosSearchResultsGeneratedEventV1.setSearch(new com.ielts.cmds.organisation.common.out.event.RoSearchV1());
		return Stream.of(Arguments.of(roSearchObject, orgList, rosSearchResultsGeneratedEventV1));
	}
}
