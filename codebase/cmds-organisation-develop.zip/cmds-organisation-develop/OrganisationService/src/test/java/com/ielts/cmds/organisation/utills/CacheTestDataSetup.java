package com.ielts.cmds.organisation.utills;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.organisation.cache.constants.ProductDataReadCacheConstants;

import java.util.HashMap;
import java.util.Map;

public class CacheTestDataSetup {

    public static Map<String, String> getProductDataInHashMap() throws JsonProcessingException {
        Map<String, String> hash = new HashMap<>();
        hash.put(ProductDataReadCacheConstants.PRODUCT_UUID, "81cf9e4e-c33d-4bc8-9ce8-16a0ea91c498");
        hash.put(ProductDataReadCacheConstants.PARENT_PRODUCT_UUID, "c007e869-7e35-4209-b0f1-ee5760d7c6fd");
        hash.put(ProductDataReadCacheConstants.LEGACY_PRODUCT_ID, "D901");
        hash.put(ProductDataReadCacheConstants.MODULE,
                "{\"moduleType\":\"AC\",\"moduleTypeUuid\":\"98728fc7-fa65-4757-85e4-90aa022f2816\",\"description\":\"Academic\"}");
        hash.put(ProductDataReadCacheConstants.NAME, "IELTS Online AC W");
        hash.put(ProductDataReadCacheConstants.DESCRIPTION, "string");
        hash.put(ProductDataReadCacheConstants.BOOKABLE, "true");
        hash.put(ProductDataReadCacheConstants.DURATION, "60");
        hash.put(ProductDataReadCacheConstants.PRODUCT_CHARACTERISTICS, "{\"characteristics\":[\"IOL\",\"IOC\"]}");
        hash.put(ProductDataReadCacheConstants.FORMAT, "CD");
        hash.put(ProductDataReadCacheConstants.COMPONENT, "W");
        hash.put(ProductDataReadCacheConstants.APPROVAL_REQUIRED, "false");
        hash.put(ProductDataReadCacheConstants.AVAILABLE_FROM_DATE, "2022-01-01");
        hash.put(ProductDataReadCacheConstants.AVAILABLE_TO_DATE, "2099-12-31");
        return hash;
    }

}

