package com.ielts.cmds.organisation.domain.services;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreateLinkedOrganisation;
import com.ielts.cmds.api.roui007rocreaterequested.LinkTypeEnum;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.cache.JedisGenericReader;
import com.ielts.cmds.organisation.cache.factory.JedisFactory;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.organisation.domain.model.RoDataCreateV1Valid;
import com.ielts.cmds.organisation.infrastructure.config.RBACTestConfig;
import com.ielts.cmds.organisation.infrastructure.entity.LinkedRecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.utills.CreateOrganisationDataSetup;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.implementation.impl.LocationHierarchyServiceImpl;
import com.ielts.cmds.rbac.implementation.impl.UserGroupServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

import javax.transaction.Transactional;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.verify;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = RBACTestConfig.class)
@ActiveProfiles("test")
@Sql({
    "/sql/schema.sql",
    "/sql/organisation-type-data.sql",
    "/sql/partner-data.sql",
    "/sql/address-type-data.sql",
    "/sql/sector-type-data.sql",
    "/sql/product-data.sql",
    "/sql/note-type-data.sql",
    "/sql/contact-type-data.sql",
    "/sql/country-data.sql",
    "/sql/territory-data.sql",
    "/sql/module-type-data.sql",
    "/sql/usergroup-hierarchy.sql",
    "/sql/existing-ro-data.sql",
    "/sql/existing-vo-data.sql",
    "/sql/ro-hierarchy-data.sql",
    "/sql/sample-hierarchy-data.sql",
    "/sql/linked-recognising-organisation-data.sql"
})
@Transactional
class CreateOrganisationWithROHierarchyIntegrationTest {

    @Autowired private RecognisingOrganisationRepository recognisingOrgRepository;

    @Spy private OrganisationCommonUtils organisationCommonUtils;

    @MockBean private ApplicationEventPublisher applicationEventPublisher;

    @Autowired private CreateOrganisationDomainService createOrganisationDomainService;

    @Captor ArgumentCaptor<BaseEvent<BaseHeader>> publishedEventCaptor;

    @Autowired private ObjectMapper objectMapper;
    @Autowired private UserGroupServiceImpl userGroupServiceImpl;
    @Autowired private LocationHierarchyServiceImpl locationHierarchyServiceImpl;
    @MockBean private JedisGenericReader jedisGenericReader;
    @MockBean private JedisFactory jedisFactory;

    @BeforeEach
    void setup() throws RbacValidationException {
        userGroupServiceImpl.populateUserGroupHierarchyData();
        locationHierarchyServiceImpl.populateRootData();
        ReflectionTestUtils.setField(
                createOrganisationDomainService,
                "applicationEventPublisher",
                applicationEventPublisher);
        ReflectionTestUtils.setField(
                organisationCommonUtils, "jedisGenericReader", jedisGenericReader);
        ThreadLocalHeaderContext.setContext(OrganisationTestUtil.generateBuildHeaderContext(OrganisationConstants.EventType.RO_CREATED_EVENT));
        ThreadLocalAuditContext.setContext(OrganisationTestUtil.getBaseAudit());
    }

    @Test
    final void testSaveOrganisationWithParent() throws IOException {

        String authorisedAccessTokenToCreate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");

        RoDataCreateV1Valid roDataCreate = CreateOrganisationDataSetup.createOrgData();
        roDataCreate.getContacts().get(0).getAddresses().get(0).setEmail("test@gmail.com");
        roDataCreate.getContacts().get(0).getAddresses().get(1).setEmail("test@gmail.com");
        roDataCreate.getContacts().get(1).getAddresses().get(0).setEmail("test@gmail.com");
        roDataCreate.getContacts().get(1).getAddresses().get(1).setEmail("test@gmail.com");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToCreate);
        createOrganisationDomainService.onCommand(roDataCreate);
        RecognisingOrganisation recognisingOrganisation =
                recognisingOrgRepository.findByName("McGill University");

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();

        RoChangedEventV1 roCreatedEvent =
                objectMapper.readValue(event.getEventBody(), RoChangedEventV1.class);
       /* Count Check */
        assertTrue(recognisingOrgRepository.count() > 0);

        List<LinkedRecognisingOrganisation> savedLinkedOrganisation =
                recognisingOrganisation.getLinkedRecognisingOrganisations();
        assertEquals(3, savedLinkedOrganisation.stream().count());
        assertEquals(
                LinkTypeEnum.PARENT_RO.getValue(),
                savedLinkedOrganisation.get(0).getLinkedRecognisingOrganisationType().getValue());
        assertEquals(2, roCreatedEvent.getLinkedOrganisations().stream().count());
        assertEquals(
                LinkTypeEnum.PARENT_RO.getValue(),
                roDataCreate.getLinkedOrganisations().get(0).getLinkType().getValue());
    }

    @Test
    void testRejectedEventForVOAsParentAndInvalidResultsDelivery()
            throws IOException, RbacValidationException {
        String authorisedAccessTokenToCreate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");

        RoDataCreateV1Valid roDataCreate = CreateOrganisationDataSetup.createOrgData();
        roDataCreate.getContacts().get(0).getAddresses().get(0).setEmail("test@gmail.com");
        roDataCreate.getContacts().get(0).getAddresses().get(1).setEmail("test@gmail.com");
        roDataCreate.getContacts().get(1).getAddresses().get(0).setEmail("test@gmail.com");
        roDataCreate.getContacts().get(1).getAddresses().get(1).setEmail("test@gmail.com");
        roDataCreate
                .getLinkedOrganisations()
                .get(0)
                .setTargetRecognisingOrganisationUuid(
                        UUID.fromString(
                                "d303bc54-d13b-4252-aae6-486cf5a4f1f6")); // Organisation with VO
        // type
        roDataCreate
                .getLinkedOrganisations()
                .get(1)
                .setTargetRecognisingOrganisationUuid(
                        UUID.fromString(
                                "d903bc54-d13b-4252-aae6-486cf5a4f1f6")); // Organisation which is
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToCreate);

        createOrganisationDomainService.onCommand(roDataCreate);
        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        assertEquals(
                OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT,
                event.getEventHeader().getEventName());
        assertEquals(3, event.getEventErrors().getErrorList().size());
        List<String> listOfErrorCodes =
                event.getEventErrors().getErrorList().stream()
                        .map(errorList -> errorList.getErrorCode())
                        .collect(Collectors.toList());


        assertTrue(listOfErrorCodes.contains("V0060"));
        assertTrue(listOfErrorCodes.contains("V0059"));
        assertTrue(listOfErrorCodes.contains("V0064"));
 }

    @Test
    void testSaveOrganisationWithMainRootNodeAsHierarchyLabel() throws IOException {
        String authorisedAccessTokenToCreate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");

        RoDataCreateV1Valid roDataCreate = CreateOrganisationDataSetup.createOrgData();
        roDataCreate.setLinkedOrganisations(getLinkedOrganisationsWithOnlyParentTestData());
        roDataCreate.getContacts().get(1).getAddresses().get(0).setEmail("test@gmail.com");
        roDataCreate.getContacts().get(1).getAddresses().get(1).setEmail("test@gmail.com");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToCreate);

        createOrganisationDomainService.onCommand(roDataCreate);
        RecognisingOrganisation recognisingOrganisation =
                recognisingOrgRepository.findByName("McGill University");

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();

        RoChangedEventV1 roCreatedEvent =
                objectMapper.readValue(event.getEventBody(), RoChangedEventV1.class);
        /* Count Check */
        assertTrue(recognisingOrgRepository.count() > 0);

        List<LinkedRecognisingOrganisation> savedLinkedOrganisation =
                recognisingOrganisation.getLinkedRecognisingOrganisations();
        assertEquals(1, savedLinkedOrganisation.stream().count());
        assertEquals(
                LinkTypeEnum.PARENT_RO.getValue(),
                savedLinkedOrganisation.get(0).getLinkedRecognisingOrganisationType().getValue());
        assertEquals(1, roCreatedEvent.getLinkedOrganisations().stream().count());
        assertEquals("1234", savedLinkedOrganisation.get(0).getOrganisationHierarchyLabel());
    }

    @Test
    void testSaveOrganisationWithValidParentAndResultsDeliveryOrganisations() throws IOException {
        String authorisedAccessTokenToCreate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");

        RoDataCreateV1Valid roDataCreate = CreateOrganisationDataSetup.createOrgData();
        roDataCreate.setLinkedOrganisations(
                getLinkedOrganisationsWithLinkedOrganisationsTestData());
        roDataCreate.getContacts().get(1).getAddresses().get(0).setEmail("test@gmail.com");
        roDataCreate.getContacts().get(1).getAddresses().get(1).setEmail("test@gmail.com");

        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToCreate);


        createOrganisationDomainService.onCommand(roDataCreate);
        RecognisingOrganisation recognisingOrganisation =
                recognisingOrgRepository.findByName("McGill University");
        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();

        RoChangedEventV1 roCreatedEvent =
                objectMapper.readValue(event.getEventBody(), RoChangedEventV1.class);

        /* Count Check */
        assertTrue(recognisingOrgRepository.count() > 0);

        List<LinkedRecognisingOrganisation> savedLinkedOrganisation =
                recognisingOrganisation.getLinkedRecognisingOrganisations();
        assertEquals(2, savedLinkedOrganisation.stream().count());
        assertEquals(
                LinkTypeEnum.PARENT_RO.getValue(),
                savedLinkedOrganisation.get(0).getLinkedRecognisingOrganisationType().getValue());
        assertEquals(
                LinkTypeEnum.RESULTS_DELIVERY.getValue(),
                savedLinkedOrganisation.get(1).getLinkedRecognisingOrganisationType().getValue());
        assertEquals(2, roCreatedEvent.getLinkedOrganisations().stream().count());
        assertEquals("1234", savedLinkedOrganisation.get(0).getOrganisationHierarchyLabel());
    }

    @Test
    void testRejectOrganisationWithAdditionalDeliveryNotInHierarchy() throws IOException {
        String authorisedAccessTokenToCreate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");

        RoDataCreateV1Valid roDataCreate = CreateOrganisationDataSetup.createOrgData();
        roDataCreate.setLinkedOrganisations(
                getLinkedOrganisationsWithLinkedOrganisationsTestData());
        roDataCreate
                .getLinkedOrganisations()
                .get(1)
                .setTargetRecognisingOrganisationUuid(
                        UUID.fromString(
                                "88e18cae-1bdd-45a7-be1c-0a37926f9bbe")); // Uuid exists in DB but
        // not in the hierarchy
        roDataCreate.getContacts().get(1).getAddresses().get(0).setEmail("test@gmail.com");
        roDataCreate.getContacts().get(1).getAddresses().get(1).setEmail("test@gmail.com");

        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToCreate);

        createOrganisationDomainService.onCommand(roDataCreate);
        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        assertEquals(
                OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT,
                event.getEventHeader().getEventName());
        assertEquals(1, event.getEventErrors().getErrorList().size());
        assertEquals("V0064", event.getEventErrors().getErrorList().get(0).getErrorCode());
    }

    private List<RoDataCreateLinkedOrganisation> getLinkedOrganisationsWithOnlyParentTestData() {
        List<RoDataCreateLinkedOrganisation> linkedOrganisations =
                new ArrayList<>();
        RoDataCreateLinkedOrganisation linkedOrg = new RoDataCreateLinkedOrganisation();
        linkedOrg.setTargetRecognisingOrganisationUuid(
                UUID.fromString("8ad1b27b-2abd-48f7-af77-04b0efbde786"));
        linkedOrg.setLinkType(LinkTypeEnum.valueOf(LinkTypeEnum.PARENT_RO.getValue()));
        linkedOrg.setLinkEffectiveFromDateTime(OffsetDateTime.now());
        linkedOrg.setLinkEffectiveToDateTime(LocalDateTime.of(2099, 12, 31, 11, 59).atOffset(ZoneOffset.UTC));
        linkedOrganisations.add(linkedOrg);
        return linkedOrganisations;
    }

    private List<RoDataCreateLinkedOrganisation>
            getLinkedOrganisationsWithLinkedOrganisationsTestData() {
        List<RoDataCreateLinkedOrganisation> linkedOrganisations =
                new ArrayList<>();
        RoDataCreateLinkedOrganisation linkedOrg = new RoDataCreateLinkedOrganisation();
        linkedOrg.setTargetRecognisingOrganisationUuid(
                UUID.fromString("8ad1b27b-2abd-48f7-af77-04b0efbde786"));
        linkedOrg.setLinkType(LinkTypeEnum.valueOf(LinkTypeEnum.PARENT_RO.getValue()));
        linkedOrg.setLinkEffectiveFromDateTime(OffsetDateTime.now());
        linkedOrg.setLinkEffectiveToDateTime(LocalDateTime.of(2099, 12, 31, 11, 59).atOffset(ZoneOffset.UTC));
        linkedOrganisations.add(linkedOrg);
        RoDataCreateLinkedOrganisation linkedOrg1 = new RoDataCreateLinkedOrganisation();
        linkedOrg1.setTargetRecognisingOrganisationUuid(
                UUID.fromString("aecf88e3-a88e-467a-b966-ab4ac939de55"));
        linkedOrg1.setLinkType(LinkTypeEnum.valueOf(LinkTypeEnum.RESULTS_DELIVERY.getValue()));
        linkedOrg1.setLinkEffectiveFromDateTime(OffsetDateTime.now());
        linkedOrg1.setLinkEffectiveToDateTime(LocalDateTime.of(2099, 12, 31, 11, 59).atOffset(ZoneOffset.UTC));
        linkedOrganisations.add(linkedOrg1);
        return linkedOrganisations;
    }
}
