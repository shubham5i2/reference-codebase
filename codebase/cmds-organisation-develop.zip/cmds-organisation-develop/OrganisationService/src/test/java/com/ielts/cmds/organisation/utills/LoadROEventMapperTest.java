package com.ielts.cmds.organisation.utills;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Stream;

import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.organisation.domain.commands.CreateROVO;
import com.ielts.cmds.organisation.domain.model.LoadRODataV1;
import com.ielts.cmds.organisation.domain.model.LoadROMessageV1;
import com.ielts.cmds.organisation.domain.model.LoadRORecordEvent;
import com.ielts.cmds.organisation.domain.model.RoDataCreateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.utils.LoadROEventMapper;

@ExtendWith(MockitoExtension.class)
class LoadROEventMapperTest {

	@InjectMocks private LoadROEventMapper loadROEventMapper;

	@Mock private ObjectMapper objectMapper;

	@ParameterizedTest
	@MethodSource("argumentsProviderForOrganisationLoadDataEvent")
	void mapToEvent_ExpectNoException(Map<String, LoadRORecordEvent> eventsMap, 
			RoChangedEventV1 roChangedEventV1) throws JsonProcessingException {
		doReturn(roChangedEventV1)
		.when(objectMapper)
		.readValue(eventsMap.get("1").getEvent().getEventBody(), RoChangedEventV1.class);
		LoadROMessageV1 actual = loadROEventMapper.mapToEvent(eventsMap);
		assertNotNull(actual);
	}
	
	@ParameterizedTest
	@MethodSource("argumentsProviderForOrganisationLoadDataEventWithoutOrgId")
	void mapToEventWithOutOrgId_ExpectNoException(Map<String, LoadRORecordEvent> eventsMap, 
			RoChangedEventV1 roChangedEventV1) throws JsonProcessingException {
		doReturn(roChangedEventV1)
		.when(objectMapper)
		.readValue(eventsMap.get("1").getEvent().getEventBody(), RoChangedEventV1.class);
		LoadROMessageV1 actual = loadROEventMapper.mapToEvent(eventsMap);
		assertNotNull(actual);
	}
	
	@ParameterizedTest
	@MethodSource("argumentsProviderForOrganisationLoadDataEvent")
	void mapToEvent_JsonProcessingException_ExpectNoException(Map<String, LoadRORecordEvent> eventsMap, 
			RoChangedEventV1 roChangedEventV1) throws JsonProcessingException {
		doThrow(JsonProcessingException.class)
		.when(objectMapper)
		.readValue(eventsMap.get("1").getEvent().getEventBody(), RoChangedEventV1.class);
		assertDoesNotThrow(()->loadROEventMapper.mapToEvent(eventsMap));
	}
	
	@ParameterizedTest
	@MethodSource("argumentsProviderForOrganisationLoadDataEventRejected")
	void mapToEvent_Rejected_ExpectNoException(Map<String, LoadRORecordEvent> eventsMap) {
		LoadROMessageV1 actual = loadROEventMapper.mapToEvent(eventsMap);
		assertNotNull(actual);
	}

	private static Stream<Arguments> argumentsProviderForOrganisationLoadDataEvent()
			throws JsonProcessingException {
		List<LoadRODataV1> loadRODataV1List = LoadRODataSetup.getLoadRODataV1List();
		RoDataCreateV1Valid roData = CreateOrganisationDataSetup.createOrgData();
		final CreateROVO createROVO =
				CreateROVO.builder().eventBody(roData).build();
		RecognisingOrganisation publishRo = CreateOrganisationDataSetup.populateOrganisation(createROVO.getEventBody(), new RecognisingOrganisation());
		publishRo.setRecognisingOrganisationUuid(UUID.fromString("8a1b4ce2-ac2b-46c7-8a8d-fb74df1eebec"));
		Map<String, LoadRORecordEvent> eventsMap = LoadRODataSetup.getEventsMap(LoadRODataSetup.getROCreatedEvent(publishRo), loadRODataV1List.get(0));

		return Stream.of(Arguments.of(eventsMap, CreateOrganisationDataSetup.entityToEventMapper(publishRo)));
	}
	
	private static Stream<Arguments> argumentsProviderForOrganisationLoadDataEventWithoutOrgId()
			throws JsonProcessingException {
		List<LoadRODataV1> loadRODataV1List = LoadRODataSetup.getLoadRODataV1List();
		loadRODataV1List.get(0).setOrganisationId("");
		RoDataCreateV1Valid roData = CreateOrganisationDataSetup.createOrgData();
		final CreateROVO createROVO =
				CreateROVO.builder().eventBody(roData).build();
		RecognisingOrganisation publishRo = CreateOrganisationDataSetup.populateOrganisation(createROVO.getEventBody(), new RecognisingOrganisation());
		publishRo.setOrganisationId(1234);
		publishRo.setRecognisingOrganisationUuid(UUID.fromString("8a1b4ce2-ac2b-46c7-8a8d-fb74df1eebec"));
		Map<String, LoadRORecordEvent> eventsMap = LoadRODataSetup.getEventsMap(LoadRODataSetup.getROCreatedEvent(publishRo), loadRODataV1List.get(0));

		return Stream.of(Arguments.of(eventsMap, CreateOrganisationDataSetup.entityToEventMapper(publishRo)));
	}
	
	private static Stream<Arguments> argumentsProviderForOrganisationLoadDataEventRejected() {
		List<LoadRODataV1> loadRoErrorData = LoadRODataSetup.getLoadRODataV1List();
		Map<String, LoadRORecordEvent> errorEvent = LoadRODataSetup.getEventsMap(LoadRODataSetup.getRORejectedEvent(), loadRoErrorData.get(0));

		return Stream.of(Arguments.of(errorEvent));
	}




}
