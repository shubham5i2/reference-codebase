package com.ielts.cmds.organisation.application;


import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.junit.Assert.assertTrue;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.domain.model.RoDataUpdateV1Valid;
import com.ielts.cmds.organisation.domain.services.UpdateOrganisationDomainService;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utills.UpdateOrganisationDataSetup;
import java.util.stream.Stream;

import com.ielts.cmds.organisation.utils.OrganisationConstants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

/** @author cts */
@ExtendWith(MockitoExtension.class)
class OrganisationUpdateServiceTest {

    @InjectMocks private OrganisationUpdateService orgUpdateAplicationService;

    @Mock private UpdateOrganisationDomainService updateOrganisationDomainService;

    @Captor ArgumentCaptor<RoDataUpdateV1Valid> updateROVOArg;

    @Mock private ObjectMapper objectMapper;
    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        ThreadLocalHeaderContext.setContext(OrganisationTestUtil.generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_UPDATE_REQUEST_EVENT));
        ThreadLocalAuditContext.setContext(OrganisationTestUtil.getBaseAudit());
    }
    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationUpdateEvent")
    void whenValidPayload_thenVerifyDomainCallWithNoException(
            RoDataUpdateV1Valid roDataUpdateV1) throws Exception {
        orgUpdateAplicationService.process(roDataUpdateV1);
        verify(updateOrganisationDomainService, times(1)).onCommand(roDataUpdateV1);

        verify(updateOrganisationDomainService).onCommand(updateROVOArg.capture());
        assertNotNull(updateROVOArg);
        assertEquals("IDP", updateROVOArg.getValue().getPartnerCode());
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationUpdateEvent")
    void whenInValidPayload_thenVerifyForException(RoDataUpdateV1Valid roDataUpdate) throws Exception {

        Executable executable = () -> orgUpdateAplicationService.process(null);
        ProcessingException processingException =
                assertThrows(ProcessingException.class, executable);
        assertTrue(processingException.getCause() instanceof RuntimeException);
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationUpdateEvent")
    void whenInValidPayload_thenVerifyForCMDSException(RoDataUpdateV1Valid roDataUpdate) throws Exception {
        doThrow(JsonProcessingException.class)
                .when(updateOrganisationDomainService)
                .onCommand(roDataUpdate);
        Executable executable = () -> orgUpdateAplicationService.process(roDataUpdate);
        ProcessingException processingException =
                assertThrows(ProcessingException.class, executable);
        assertTrue(processingException.getCause() instanceof JsonProcessingException);
    }

    /*
     * This is method source to provide arguments for the required test cases
     * wherever this method source has been used. It's specific to UpdateROVO event
     */
    private static Stream<Arguments> argumentsProviderForOrganisationUpdateEvent()
            throws JsonProcessingException {
        final RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        return Stream.of(Arguments.of( roDataUpdateV1));
    }
}
