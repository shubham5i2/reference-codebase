package com.ielts.cmds.organisation.infrastructure.event.listner;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.config.IApplicationService;
import com.ielts.cmds.common.exception.util.CMDSServiceException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.infrastructure.config.OrganisationApplicationServiceConfig;
import com.ielts.cmds.organisation.infrastructure.config.ValidationConfig;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.rbac.api.service.RBACService;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.api.service.model.CmdsAuthentication;
import com.ielts.cmds.rbac.api.service.model.UserDetails;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;
import javax.validation.ConstraintValidatorContext;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import org.json.simple.parser.ParseException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
class OrganisationExtListenerTest<T> {

    @Spy private ObjectMapper objectMapper;

    private ObjectMapper mapper = null;

    @InjectMocks private OrganisationExtListener orgListener;

    @Mock private OrganisationApplicationServiceConfig serviceFactory;

    @Mock private Map<String, IApplicationService> iapplicationServiceMap;

    @Mock private static Validator validator;

    @Mock private IApplicationService service;

    @Mock private ConstraintValidatorContext constraintValidatorContext;

    @Mock private ValidationConfig<?> validationConfig;

    @Mock private OrganisationCommonUtils orgCommonUtil;

    @Mock private RBACService rbacService;

    @InjectMocks private OrganisationCommonUtils injectMockorgCommonUtil;

    private Map<String, String> errorMap = new HashMap<>();

    private Map<String, IApplicationService> applicationServiceMap = new HashMap<>();

    private String eventName =
             OrganisationConstants.GenericConstants.RO_CREATE_REQUEST_EVENT;

    /** @throws Exception */
    @BeforeEach
    void setUp() throws Exception {

        applicationServiceMap.put(eventName, service);
        MockitoAnnotations.initMocks(this);
        orgListener.init();
        mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
        ReflectionTestUtils.setField(orgCommonUtil, "objectMapper", mapper);
    }

    /**
     * Test method for
     *
     * @throws JsonProcessingException
     * @throws CMDSServiceException
     */
    @DisplayName("EventPayload is valid")
    @ParameterizedTest
    @MethodSource("provideArgumentsForEventPayload")
    void whenValidSQSMessageReceived_thennoException(
            BaseEvent<BaseHeader> uiCMDSEvent, String sqsROMessage)
            throws JsonProcessingException, CMDSServiceException, RbacValidationException {

        UserDetails userDetails =
                UserDetails.builder()
                        .id("auth0|09d43b09-c0ed-4568-98d0-a47829f93acb")
                        .email("jammy@cambridgeassessment.org.uk")
                        .build();
        CmdsAuthentication cmdsAuthentication = new CmdsAuthentication("", "", null, userDetails);
        when(rbacService.getCmdsAuthentication(uiCMDSEvent.getEventHeader().getXaccessToken()))
                .thenReturn(cmdsAuthentication);

        when(orgCommonUtil.processRequest(sqsROMessage, BaseHeader.class)).thenReturn(uiCMDSEvent);

        when(iapplicationServiceMap.get(eventName))
                .thenReturn(applicationServiceMap.get(eventName));
        // When
        orgListener.onReceive(sqsROMessage);
        // then
        verify(orgCommonUtil, times(1)).processRequest(sqsROMessage, BaseHeader.class);
    }

    /**
     * @throws JsonProcessingException
     * @throws CMDSServiceException
     */
    @Test
    void whenemptymessagereceived_thencmdsexception()
            throws JsonProcessingException, CMDSServiceException {

        Executable executable = () -> orgListener.onReceive(" ");
        assertThrows(CMDSServiceException.class, executable);
    }

    /**
     * Test method for
     *
     * @throws JsonProcessingException
     * @throws CMDSServiceException
     */
    @DisplayName("Headers are null")
    @ParameterizedTest
    @MethodSource("provideArgumentsForEventPayload")
    void whenSQSMessage_MissingHeaders_thenException(
            BaseEvent<BaseHeader> uiCMDSEvent, String sqsROMessage)
            throws JsonProcessingException, CMDSServiceException {
        uiCMDSEvent.setEventHeader(null);
        Set<ConstraintViolation<BaseEvent<BaseHeader>>> constraintViolation =
                OrganisationTestUtil.getSetforNullViolationOfHeadersBaseHeader("V006");
        when(validator.validate(uiCMDSEvent)).thenReturn(constraintViolation);
        errorMap.put("V006", "Header can't be null");
        when(validationConfig.getErrorCode()).thenReturn(errorMap);
        final String invalidSqsMessage = mapper.writeValueAsString(uiCMDSEvent);
        // when(objectMapper.getTypeFactory().constructParametricType(any(Class.class),any(Class.class))).thenReturn(type);
        final Exception thrown =
                assertThrows(
                        IllegalArgumentException.class,
                        () -> {
                            injectMockorgCommonUtil.processRequest(
                                    invalidSqsMessage, BaseHeader.class);
                        });
        verify(validationConfig, times(1)).getErrorCode();
        assertTrue(
                thrown.getMessage()
                        .contains(
                                "Organisation Event Validation failed- [Header can't be null] for the request"));
    }

    /**
     * Test method for
     *
     * @throws JsonProcessingException
     */
    @DisplayName("Headers - TrasactionUUID is null")
    @ParameterizedTest
    @MethodSource("provideArgumentsForEventPayload")
    void whenSQSMessage_MissingTrasactionUUID_thenException(
            BaseEvent<BaseHeader> uiCMDSEvent, String sqsSMMessage) throws JsonProcessingException {

        uiCMDSEvent.getEventHeader().setTransactionId(null);
        ;
        Set<ConstraintViolation<BaseEvent<BaseHeader>>> constraintViolation =
                OrganisationTestUtil.getSetforNullViolationOfHeadersBaseHeader("V010");
        when(validator.validate(uiCMDSEvent)).thenReturn(constraintViolation);
        errorMap.put("V010", "TrasactionUuid cannot be null or empty.");
        when(validationConfig.getErrorCode()).thenReturn(errorMap);
        final String invalidSqsMessage = mapper.writeValueAsString(uiCMDSEvent);
        final Exception thrown =
                assertThrows(
                        IllegalArgumentException.class,
                        () -> {
                            injectMockorgCommonUtil.validateHeaders(uiCMDSEvent, invalidSqsMessage);
                        });
        verify(validationConfig, times(1)).getErrorCode();
        assertTrue(
                thrown.getMessage()
                        .contains(
                                "Organisation Event Validation failed- [TrasactionUuid cannot be null or empty.] for the request"));
    }

    /**
     * Test method for
     *
     * @throws JsonProcessingException
     */
    @DisplayName("Headers - CorrelationId is null")
    @ParameterizedTest
    @MethodSource("provideArgumentsForEventPayload")
    void whenSQSMessage_MissingCorrelationId_thenException(
            BaseEvent<BaseHeader> uiCMDSEvent, String sqsSMMessage) throws JsonProcessingException {

        uiCMDSEvent.getEventHeader().setCorrelationId(null);
        Set<ConstraintViolation<BaseEvent<BaseHeader>>> constraintViolation =
                OrganisationTestUtil.getSetforNullViolationOfHeadersBaseHeader("V008");
        when(validator.validate(uiCMDSEvent)).thenReturn(constraintViolation);
        errorMap.put("V008", "CorrelationId cannot be null or empty.");
        when(validationConfig.getErrorCode()).thenReturn(errorMap);
        final String invalidSqsMessage = mapper.writeValueAsString(uiCMDSEvent);
        final Exception thrown =
                assertThrows(
                        IllegalArgumentException.class,
                        () -> {
                            injectMockorgCommonUtil.validateHeaders(uiCMDSEvent, invalidSqsMessage);
                        });
        verify(validationConfig, times(1)).getErrorCode();
        assertTrue(
                thrown.getMessage()
                        .contains(
                                "Organisation Event Validation failed- [CorrelationId cannot be null or empty.] for the request"));
    }

    /**
     * Test method for
     *
     * @throws JsonProcessingException
     */
    @DisplayName("Headers - EventDateTime is null")
    @ParameterizedTest
    @MethodSource("provideArgumentsForEventPayload")
    void whenSQSMessage_MissingEventDateTime_thenException(
            BaseEvent<BaseHeader> uiCMDSEvent, String sqsSMMessage) throws JsonProcessingException {

        uiCMDSEvent.getEventHeader().setEventDateTime(null);
        Set<ConstraintViolation<BaseEvent<BaseHeader>>> constraintViolation =
                OrganisationTestUtil.getSetforNullViolationOfHeadersBaseHeader("V009");
        when(validator.validate(uiCMDSEvent)).thenReturn(constraintViolation);
        errorMap.put("V009", "EventDateTime cannot be null or empty.");
        when(validationConfig.getErrorCode()).thenReturn(errorMap);
        final String invalidSqsMessage = mapper.writeValueAsString(uiCMDSEvent);

        final Exception thrown =
                assertThrows(
                        IllegalArgumentException.class,
                        () -> {
                            injectMockorgCommonUtil.validateHeaders(uiCMDSEvent, invalidSqsMessage);
                        });
        verify(validationConfig, times(1)).getErrorCode();
        assertTrue(
                thrown.getMessage()
                        .contains(
                                "Organisation Event Validation failed- [EventDateTime cannot be null or empty.] for the request"));
    }

    /**
     * Test method for
     *
     * @throws JsonProcessingException
     */
    @DisplayName("Headers - OperationType and Resource is null")
    @ParameterizedTest
    @MethodSource("provideArgumentsForEventPayload")
    void whenSQSMessage_MissingResourceAndOperationType_thenException(
            BaseEvent<BaseHeader> uiCmdsEvent, String sqsSMMessage) throws JsonProcessingException {

        uiCmdsEvent.getEventHeader().setEventName(null);
        Set<ConstraintViolation<BaseEvent<BaseHeader>>> constraintViolation =
                OrganisationTestUtil.getSetforNullViolationOfHeadersBaseHeader("V011");

        when(validator.validate(uiCmdsEvent)).thenReturn(constraintViolation);
        errorMap.put("V011", "EventName cannot be null or empty.");
        when(validationConfig.getErrorCode()).thenReturn(errorMap);
        final String invalidSqsMessage = mapper.writeValueAsString(uiCmdsEvent);

        final Exception thrown =
                assertThrows(
                        IllegalArgumentException.class,
                        () -> {
                            injectMockorgCommonUtil.validateHeaders(uiCmdsEvent, invalidSqsMessage);
                        });
        verify(validationConfig, times(1)).getErrorCode();
        assertTrue(
                thrown.getMessage()
                        .contains(
                                "Organisation Event Validation failed- [EventName cannot be null or empty.] for the request "));
    }

    /**
     * Test method for
     *
     * @throws JsonProcessingException
     */
    @DisplayName("EventPayload is Invalid - OperationType  is not valid")
    @ParameterizedTest
    @MethodSource("provideArgumentsForEventPayload")
    void whenEventNameIsInvalid_thenIllegalArgumentException(
            BaseEvent<BaseHeader> roCMDSEvent, String sqsRoMessage) throws JsonProcessingException {

        roCMDSEvent
                .getEventHeader()
                .setEventName(OrganisationConstants.GenericConstants.OPERATION_TYPE_POST);
        when(orgCommonUtil.processRequest(sqsRoMessage, BaseHeader.class)).thenReturn(roCMDSEvent);
        // When
        Executable executable = () -> orgListener.onReceive(sqsRoMessage);
        // Then
        assertThrows(IllegalArgumentException.class, executable);
    }

    /**
     * Test method for
     *
     * @throws JsonProcessingException
     */
    @Test
    void whenEventNameIsInvalid_thenJsonException() throws JsonProcessingException {

        String invalidJsonSqsMessage = "{\\\"eventHeader\\\":{\\\"transactionId\\\"";
        doThrow(JsonProcessingException.class)
                .when(orgCommonUtil)
                .processRequest(invalidJsonSqsMessage, BaseHeader.class);
        // When
        Executable executable = () -> orgListener.onReceive(invalidJsonSqsMessage);
        // Then
        assertThrows(JsonProcessingException.class, executable);
    }

    /**
     * @return
     * @throws JsonProcessingException
     * @throws IOException
     * @throws ParseException
     */
    private static Stream<Arguments> provideArgumentsForEventPayload()
            throws JsonProcessingException {

        BaseEvent<BaseHeader> uiCMDSEvent =
                new BaseEvent<>(OrganisationTestUtil.generateEventHeader(), null, null, null);
        String orgMessage = new ObjectMapper().writeValueAsString(uiCMDSEvent);
        return Stream.of(Arguments.of(uiCMDSEvent, orgMessage));
    }
}
