package com.ielts.cmds.organisation.application;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.verify;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.roui011rodetailsbyorgidrequested.RODetailsByOrgIdRequestParam;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.domain.commands.SearchRoByOrgId;
import com.ielts.cmds.organisation.domain.services.SearchByOrgIdDomainService;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class OrganisationSearchByOrgIdServiceTest {

    @InjectMocks OrganisationSearchByOrgIdService organisationSearchByOrgIdService;

    @Mock private SearchByOrgIdDomainService searchByOrgIdDomainService;

    @Mock private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        ThreadLocalHeaderContext.setContext(OrganisationTestUtil.generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_SEARCH_REQUEST_EVENT));
        ThreadLocalAuditContext.setContext(OrganisationTestUtil.getBaseAudit());
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrgViewEvent")
    void whenValidPayload_thenVerifyDomainCallWithNoException(
            UiHeader header) throws Exception {
        UiHeader roHeaders = OrganisationTestUtil.generateEventHeader();
        roHeaders.setEventName(OrganisationConstants.GenericConstants.RO_SEARCH_REQUEST_EVENT);
        RODetailsByOrgIdRequestParam eventBody =  new RODetailsByOrgIdRequestParam();
        eventBody.setOrganisationId(15400);
         organisationSearchByOrgIdService.process(eventBody);

        verify(searchByOrgIdDomainService).onCommand(eventBody.getOrganisationId());
        //assertNotNull(searchByOrgIdOrgArgCaptor.getValue());
        assertNotNull(
                         header
                         .getEventContext()
                        .get("organisationId"));
        assertEquals(
                "15400",
                        header
                        .getEventContext()
                        .get("organisationId"));
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrgViewEvent")
    void whenInValidPayload_thenVerifyForException(
            UiHeader orgCmdsEvent)
            throws JsonProcessingException, ProcessingException, RbacValidationException {
        RODetailsByOrgIdRequestParam eventBody =  new RODetailsByOrgIdRequestParam();
        eventBody.setOrganisationId(Integer.valueOf("15400"));
        Executable executable = () -> organisationSearchByOrgIdService.process(null);
        ProcessingException processingException =
                assertThrows(ProcessingException.class, executable);
        assertTrue(processingException.getCause() instanceof RuntimeException);
    }

    private static Stream<Arguments> argumentsProviderForOrgViewEvent()
            throws JsonProcessingException {

        UiHeader orgViewHeaders = OrganisationTestUtil.generateEventHeader();
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put("organisationId", "15400");
        orgViewHeaders.setEventContext(eventContext);

        orgViewHeaders.setEventName(
                 OrganisationConstants.GenericConstants.RO_SEARCH_BY_ORG_ID_REQUEST_EVENT);
        BaseAudit audit = new BaseAudit();
        final BaseEvent<UiHeader> event =
                new BaseEvent<UiHeader>(orgViewHeaders, null, null, audit);
        SearchRoByOrgId searchRoByOrgId =
                SearchRoByOrgId.builder()
                        .eventHeaders(event.getEventHeader())
                        .eventErrors(event.getEventErrors())
                        .audit(audit)
                        .build();
        return Stream.of(Arguments.of(orgViewHeaders));
    }
}
