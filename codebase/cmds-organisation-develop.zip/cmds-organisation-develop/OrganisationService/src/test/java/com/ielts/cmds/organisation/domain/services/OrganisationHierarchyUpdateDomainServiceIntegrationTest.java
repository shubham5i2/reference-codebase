package com.ielts.cmds.organisation.domain.services;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateLinkedOrganisation;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.api.roui009roupdaterequested.LinkTypeEnum;
import com.ielts.cmds.organisation.cache.JedisGenericReader;
import com.ielts.cmds.organisation.cache.factory.JedisFactory;
import com.ielts.cmds.organisation.domain.commands.OrganisationHierarchyUpdate;
import com.ielts.cmds.organisation.domain.model.HierarchyUpdateV1;
import com.ielts.cmds.organisation.domain.model.RoDataUpdateV1Valid;
import com.ielts.cmds.organisation.domain.utils.DomainEventsPublisher;
import com.ielts.cmds.organisation.domain.utils.OrganisationHierarchyUpdateUtil;
import com.ielts.cmds.organisation.infrastructure.config.RBACTestConfig;
import com.ielts.cmds.organisation.infrastructure.entity.LinkedRecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utills.ROHierarchyUpdateDataSetup;
import com.ielts.cmds.organisation.utills.UpdateOrganisationDataSetup;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.implementation.impl.LocationHierarchyServiceImpl;
import com.ielts.cmds.rbac.implementation.impl.UserGroupServiceImpl;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.*;
import java.util.stream.Collectors;
import javax.transaction.Transactional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = RBACTestConfig.class)
@ActiveProfiles("test")
@Sql({
    "/sql/schema.sql",
    "/sql/organisation-type-data.sql",
    "/sql/partner-data.sql",
    "/sql/address-type-data.sql",
    "/sql/sector-type-data.sql",
    "/sql/note-type-data.sql",
    "/sql/contact-type-data.sql",
    "/sql/country-data.sql",
    "/sql/territory-data.sql",
    "/sql/module-type-data.sql",
    "/sql/usergroup-hierarchy.sql",
    "/sql/sample-hierarchy-data.sql",
    "/sql/sample-linked-ro-data.sql",
    "/sql/ro-hierarchy-data.sql",
    "/sql/linked-recognising-organisation-data.sql"
})
@Transactional
class OrganisationHierarchyUpdateDomainServiceIntegrationTest {

    @Autowired private RecognisingOrganisationRepository roRepository;
    @Autowired private OrganisationCommonUtils organisationCommonUtils;
    @Autowired UpdateOrganisationDomainService updateOrganisationDomainService;
    @Autowired OrganisationHierarchyUpdateDomainService hierarchyUpdateDomainService;
    @Autowired OrganisationHierarchyUpdateUtil organisationHierarchyDataUtil;
    @MockBean private ApplicationEventPublisher applicationEventPublisher;
    @MockBean private DomainEventsPublisher domainEventPublisher;
    @Captor ArgumentCaptor<BaseEvent<BaseHeader>> publishedEventCaptor;
    @Captor ArgumentCaptor<List<BaseEvent<BaseHeader>>> publishedListEventCaptor;
    @Captor ArgumentCaptor<BaseEvent<UiHeader>> roHierarchyUpdateEventCaptor;
    @Autowired private UserGroupServiceImpl userGroupServiceImpl;
    @Autowired private LocationHierarchyServiceImpl locationHierarchyServiceImpl;
    @MockBean private JedisGenericReader jedisGenericReader;
    @MockBean private JedisFactory jedisFactory;

    @BeforeEach
    void setup() throws RbacValidationException {
        userGroupServiceImpl.populateUserGroupHierarchyData();
        locationHierarchyServiceImpl.populateRootData();
        ReflectionTestUtils.setField(
                organisationCommonUtils, "applicationEventPublisher", applicationEventPublisher);
        ThreadLocalHeaderContext.setContext(OrganisationTestUtil.generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_UPDATE_REQUEST_EVENT));
        ThreadLocalAuditContext.setContext(OrganisationTestUtil.getBaseAudit());
        ReflectionTestUtils.setField(
                organisationCommonUtils, "jedisGenericReader", jedisGenericReader);
    }

    @Test
    final void testUpdateOrganisation() throws IOException {

        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");

        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setLinkedOrganisations(removeAParentRODataSetUp());
        roDataUpdate.setContacts(UpdateOrganisationDataSetup.getContactsDataForIntegrationTest());

        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);
        ThreadLocalHeaderContext.getContext().setEventName(OrganisationConstants.EventType.RO_UPDATED_EVENT);
        Map<String, String> eventContextList = new HashMap<>();
        eventContextList.put("recognisingOrganisationUuid", "b56d6c5f-d7f9-453d-b14f-ccd7f0586ff5");
        ThreadLocalHeaderContext.getContext().setEventContext(eventContextList);
        roDataUpdate.setRecognisingOrganisationUuid(UUID.fromString("b56d6c5f-d7f9-453d-b14f-ccd7f0586ff5"));
        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));
        Set<RecognisingOrganisation> expectedRoListToBePublished =
                organisationHierarchyDataUtil.getAllTheOrgsOfPreviousHierarchy("1");
        verify(domainEventPublisher).baseEventListPublisher(publishedListEventCaptor.capture());
        List<BaseEvent<BaseHeader>> event = publishedListEventCaptor.getValue();
        assertEquals(
                OrganisationConstants.EventType.RO_HIERARCHY_UPDATE_EVENT,
                event.get(0).getEventHeader().getEventName());
        assertEquals(expectedRoListToBePublished.size(), event.size());
    }

    @Test
    final void testOrganisationHierarchyUpdateForSiblingOrg() throws SQLException, IOException {
        HierarchyUpdateV1 hierarchyUpdate =
                ROHierarchyUpdateDataSetup.createHierarchyUpdateV1Data();
        hierarchyUpdate.setTriggerRecognisingOrganisationUuid(
                UUID.fromString("b56d6c5f-d7f9-453d-b14f-ccd7f0586ff5")); // D1 roUuid
        hierarchyUpdate.setRecognisingOrganisationUuid(
                UUID.fromString("63bf1302-acb6-401c-879f-2ae55dfe8c62")); // A1 roUuid (Sibling)

        BaseHeader baseHeader = OrganisationTestUtil.generateEventHeader();
        baseHeader.setEventName(OrganisationConstants.EventType.RO_HIERARCHY_UPDATE_EVENT);
        BaseAudit audit = new BaseAudit();
        Map<String, String> auditContext = new HashMap<>();
        audit.setAuditContext(auditContext);

        OrganisationHierarchyUpdate orgHierarchyUpdate =
                OrganisationHierarchyUpdate.builder()
                        .eventHeaders(baseHeader)
                        .eventBody(hierarchyUpdate)
                        .eventErrors(null)
                        .audit(audit)
                        .build();
        hierarchyUpdateDomainService.onCommand(orgHierarchyUpdate);
        Optional<RecognisingOrganisation> ro =
                roRepository.findById(UUID.fromString("63bf1302-acb6-401c-879f-2ae55dfe8c62"));
        List<LinkedRecognisingOrganisation> linkedRos =
                ro.get().getLinkedRecognisingOrganisations();
        List<LinkedRecognisingOrganisation> resultsDeliveryOrgsList =
                linkedRos.stream()
                        .filter(
                                linkedRO ->
                                        LinkTypeEnum.RESULTS_DELIVERY.getValue().equals(
                                                linkedRO.getLinkedRecognisingOrganisationType().getValue()))
                        .collect(Collectors.toList());
        assertTrue(
                resultsDeliveryOrgsList
                        .get(0)
                        .getEffectiveToDatetime()
                        .isAfter(OffsetDateTime.now()));
        assertFalse(
                resultsDeliveryOrgsList
                        .get(1)
                        .getEffectiveToDatetime()
                        .isAfter(OffsetDateTime.now()));
    }

    @Test
    final void testOrganisationHierarchyUpdateForChildOrg() throws SQLException, IOException {
        HierarchyUpdateV1 hierarchyUpdate =
                ROHierarchyUpdateDataSetup.createHierarchyUpdateV1Data();
        hierarchyUpdate.setTriggerRecognisingOrganisationUuid(
                UUID.fromString("b56d6c5f-d7f9-453d-b14f-ccd7f0586ff5")); // D1 roUuid
        hierarchyUpdate.setRecognisingOrganisationUuid(
                UUID.fromString("fb35dd34-1b87-4c46-b6ab-21186c41663a")); // D12 roUuid (Child)
        BaseHeader baseHeader = OrganisationTestUtil.generateEventHeader();
        baseHeader.setEventName(OrganisationConstants.EventType.RO_HIERARCHY_UPDATE_EVENT);
        BaseAudit audit = new BaseAudit();
        Map<String, String> auditContext = new HashMap<>();
        audit.setAuditContext(auditContext);
        OrganisationHierarchyUpdate orgHierarchyUpdate =
                OrganisationHierarchyUpdate.builder()
                        .eventHeaders(baseHeader)
                        .eventBody(hierarchyUpdate)
                        .eventErrors(null)
                        .audit(audit)
                        .build();
        hierarchyUpdateDomainService.onCommand(orgHierarchyUpdate);
        Optional<RecognisingOrganisation> ro =
                roRepository.findById(UUID.fromString("fb35dd34-1b87-4c46-b6ab-21186c41663a"));
        List<LinkedRecognisingOrganisation> linkedRos =
                ro.get().getLinkedRecognisingOrganisations();
        List<LinkedRecognisingOrganisation> resultsDeliveryOrgsList =
                linkedRos.stream()
                        .filter(
                                linkedRO ->
                                        LinkTypeEnum.RESULTS_DELIVERY.getValue().equals(
                                                linkedRO.getLinkedRecognisingOrganisationType().getValue()))
                        .collect(Collectors.toList());
        assertEquals(
                "3",
                linkedRos.stream()
                        .filter(
                                linkedRO ->
                                        LinkTypeEnum.PARENT_RO.getValue().equals(
                                                linkedRO.getLinkedRecognisingOrganisationType().getValue()))
                        .map(LinkedRecognisingOrganisation::getOrganisationHierarchyLabel)
                        .collect(Collectors.toList())
                        .get(0));
        assertTrue(
                resultsDeliveryOrgsList
                        .get(1)
                        .getEffectiveToDatetime()
                        .isAfter(OffsetDateTime.now()));
        assertFalse(
                resultsDeliveryOrgsList
                        .get(0)
                        .getEffectiveToDatetime()
                        .isAfter(OffsetDateTime.now()));
    }

    @Test
    final void testUpdateOrganisationWhenParentIsChanged() throws IOException {

        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");

        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setLinkedOrganisations(changeParentRODataSetUp());
        roDataUpdate.setContacts(UpdateOrganisationDataSetup.getContactsDataForIntegrationTest());

        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);
        ThreadLocalHeaderContext.getContext().setEventName(OrganisationConstants.EventType.RO_UPDATED_EVENT);
        Map<String, String> eventContextList = new HashMap<>();
        eventContextList.put("recognisingOrganisationUuid", "b56d6c5f-d7f9-453d-b14f-ccd7f0586ff5");
        ThreadLocalHeaderContext.getContext().setEventContext(eventContextList);
        roDataUpdate.setRecognisingOrganisationUuid(UUID.fromString("b56d6c5f-d7f9-453d-b14f-ccd7f0586ff5"));
        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));
        Set<RecognisingOrganisation> expectedRoListToBePublished =
                organisationHierarchyDataUtil.getAllTheOrgsOfPreviousHierarchy("1");
        Optional<RecognisingOrganisation> roUpdated =
                roRepository.findById(UUID.fromString("b56d6c5f-d7f9-453d-b14f-ccd7f0586ff5"));
        verify(domainEventPublisher).baseEventListPublisher(publishedListEventCaptor.capture());
        List<BaseEvent<BaseHeader>> event = publishedListEventCaptor.getValue();
        assertEquals(
                OrganisationConstants.EventType.RO_HIERARCHY_UPDATE_EVENT,
                event.get(0).getEventHeader().getEventName());
        assertEquals(expectedRoListToBePublished.size(), event.size());
        List<LinkedRecognisingOrganisation> linkedRos =
                roUpdated.get().getLinkedRecognisingOrganisations();
        List<LinkedRecognisingOrganisation> resultsDeliveryOrgsList =
                linkedRos.stream()
                        .filter(
                                linkedRO ->
                                        LinkTypeEnum.RESULTS_DELIVERY.getValue().equals(
                                                linkedRO.getLinkedRecognisingOrganisationType().getValue()))
                        .collect(Collectors.toList());
        assertEquals(
                "1234",
                linkedRos.stream()
                        .filter(
                                linkedRO ->
                                        LinkTypeEnum.PARENT_RO.getValue().equals(
                                                linkedRO.getLinkedRecognisingOrganisationType().getValue()))
                        .map(LinkedRecognisingOrganisation::getOrganisationHierarchyLabel)
                        .collect(Collectors.toList())
                        .get(0));
        assertTrue(
                resultsDeliveryOrgsList
                        .get(0)
                        .getEffectiveToDatetime()
                        .isAfter(OffsetDateTime.now()));
        assertTrue(
                resultsDeliveryOrgsList
                        .get(1)
                        .getEffectiveToDatetime()
                        .isAfter(OffsetDateTime.now()));
    }

    @Test
    final void whenParentIsAddedToRootNodeThenExpectNoException() throws IOException {

        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");

        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        List<RoDataUpdateLinkedOrganisation> newlinkedRos = new ArrayList<>();
        newlinkedRos.add(addNewParentForRootNodeDataSetUp());
        roDataUpdate.setLinkedOrganisations(newlinkedRos);
        roDataUpdate.setContacts(UpdateOrganisationDataSetup.getContactsDataForIntegrationTest());

        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);
        ThreadLocalHeaderContext.getContext().setEventName(OrganisationConstants.EventType.RO_UPDATED_EVENT);
        Map<String, String> eventContextList = new HashMap<>();
        eventContextList.put("recognisingOrganisationUuid", "ae1a5ea5-b6ab-40f3-ba72-cca9dff8332e");
        ThreadLocalHeaderContext.getContext().setEventContext(eventContextList);
        roDataUpdate.setRecognisingOrganisationUuid(UUID.fromString("ae1a5ea5-b6ab-40f3-ba72-cca9dff8332e"));
        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));
        Set<RecognisingOrganisation> expectedRoListToBePublished =
                organisationHierarchyDataUtil.getAllTheOrgsOfPreviousHierarchy("1");
        Optional<RecognisingOrganisation> roUpdated =
                roRepository.findById(UUID.fromString("ae1a5ea5-b6ab-40f3-ba72-cca9dff8332e"));
        verify(domainEventPublisher).baseEventListPublisher(publishedListEventCaptor.capture());
        List<BaseEvent<BaseHeader>> event = publishedListEventCaptor.getValue();
        assertEquals(
                OrganisationConstants.EventType.RO_HIERARCHY_UPDATE_EVENT,
                event.get(0).getEventHeader().getEventName());
        assertEquals(expectedRoListToBePublished.size(), event.size());
        List<LinkedRecognisingOrganisation> linkedRos =
                roUpdated.get().getLinkedRecognisingOrganisations();
        assertEquals(
                "1234",
                linkedRos.stream()
                        .filter(
                                linkedRO ->
                                        LinkTypeEnum.PARENT_RO.getValue().equals(
                                                linkedRO.getLinkedRecognisingOrganisationType().getValue()))
                        .map(LinkedRecognisingOrganisation::getOrganisationHierarchyLabel)
                        .collect(Collectors.toList())
                        .get(0));
    }

    @Test
    final void whenParentIsAddedToRootNodeThenUpdateLabelForAllChildren()
            throws SQLException, IOException {
        HierarchyUpdateV1 hierarchyUpdate =
                ROHierarchyUpdateDataSetup.createHierarchyUpdateV1Data();
        hierarchyUpdate.setNewHierarchyLabel("1234");
        hierarchyUpdate.setTriggerRecognisingOrganisationUuid(
                UUID.fromString("ae1a5ea5-b6ab-40f3-ba72-cca9dff8332e")); // A roUuid
        hierarchyUpdate.setRecognisingOrganisationUuid(
                UUID.fromString(
                        "63bf1302-acb6-401c-879f-2ae55dfe8c62")); // A1 roUuid (One of the Children)
        BaseHeader baseHeader = OrganisationTestUtil.generateEventHeader();
        baseHeader.setEventName(OrganisationConstants.EventType.RO_HIERARCHY_UPDATE_EVENT);
        BaseAudit audit = new BaseAudit();
        Map<String, String> auditContext = new HashMap<>();
        audit.setAuditContext(auditContext);
        OrganisationHierarchyUpdate orgHierarchyUpdate =
                OrganisationHierarchyUpdate.builder()
                        .eventHeaders(baseHeader)
                        .eventBody(hierarchyUpdate)
                        .eventErrors(null)
                        .audit(audit)
                        .build();
        hierarchyUpdateDomainService.onCommand(orgHierarchyUpdate);
        Optional<RecognisingOrganisation> ro =
                roRepository.findById(UUID.fromString("63bf1302-acb6-401c-879f-2ae55dfe8c62"));
        List<LinkedRecognisingOrganisation> linkedRos =
                ro.get().getLinkedRecognisingOrganisations();
        List<LinkedRecognisingOrganisation> resultsDeliveryOrgsList =
                linkedRos.stream()
                        .filter(
                                linkedRO ->
                                        LinkTypeEnum.RESULTS_DELIVERY.getValue().equals(
                                                linkedRO.getLinkedRecognisingOrganisationType().getValue()))
                        .collect(Collectors.toList());
        assertTrue(
                resultsDeliveryOrgsList
                        .get(0)
                        .getEffectiveToDatetime()
                        .isAfter(OffsetDateTime.now()));
        assertTrue(
                resultsDeliveryOrgsList
                        .get(1)
                        .getEffectiveToDatetime()
                        .isAfter(OffsetDateTime.now()));
        verify(applicationEventPublisher, times(1)).publishEvent(publishedEventCaptor.capture());
    }

    @Test
    final void testOrganisationHierarchyUpdateForSiblingOrgWhenParentIsChanged()
            throws SQLException, IOException {
        HierarchyUpdateV1 hierarchyUpdate =
                ROHierarchyUpdateDataSetup.createHierarchyUpdateV1Data();
        hierarchyUpdate.setNewHierarchyLabel("1234");
        hierarchyUpdate.setTriggerRecognisingOrganisationUuid(
                UUID.fromString("b56d6c5f-d7f9-453d-b14f-ccd7f0586ff5")); // D1 roUuid
        hierarchyUpdate.setRecognisingOrganisationUuid(
                UUID.fromString("63bf1302-acb6-401c-879f-2ae55dfe8c62")); // A1 roUuid (Sibling)
        BaseHeader baseHeader = OrganisationTestUtil.generateEventHeader();
        baseHeader.setEventName(OrganisationConstants.EventType.RO_HIERARCHY_UPDATE_EVENT);
        BaseAudit audit = new BaseAudit();
        Map<String, String> auditContext = new HashMap<>();
        audit.setAuditContext(auditContext);
        OrganisationHierarchyUpdate orgHierarchyUpdate =
                OrganisationHierarchyUpdate.builder()
                        .eventHeaders(baseHeader)
                        .eventBody(hierarchyUpdate)
                        .eventErrors(null)
                        .audit(audit)
                        .build();
        hierarchyUpdateDomainService.onCommand(orgHierarchyUpdate);
        Optional<RecognisingOrganisation> ro =
                roRepository.findById(UUID.fromString("63bf1302-acb6-401c-879f-2ae55dfe8c62"));
        List<LinkedRecognisingOrganisation> linkedRos =
                ro.get().getLinkedRecognisingOrganisations();
        List<LinkedRecognisingOrganisation> resultsDeliveryOrgsList =
                linkedRos.stream()
                        .filter(
                                linkedRO ->
                                        LinkTypeEnum.RESULTS_DELIVERY.getValue().equals(
                                                linkedRO.getLinkedRecognisingOrganisationType().getValue()))
                        .collect(Collectors.toList());
        assertTrue(
                resultsDeliveryOrgsList
                        .get(0)
                        .getEffectiveToDatetime()
                        .isAfter(OffsetDateTime.now()));
        assertFalse(
                resultsDeliveryOrgsList
                        .get(1)
                        .getEffectiveToDatetime()
                        .isAfter(OffsetDateTime.now()));
    }

    @Test
    final void testOrganisationHierarchyUpdateForChildOrgWhenParentIsChanged()
            throws SQLException, IOException {
        HierarchyUpdateV1 hierarchyUpdate =
                ROHierarchyUpdateDataSetup.createHierarchyUpdateV1Data();
        hierarchyUpdate.setNewHierarchyLabel("1234");
        hierarchyUpdate.setTriggerRecognisingOrganisationUuid(
                UUID.fromString("b56d6c5f-d7f9-453d-b14f-ccd7f0586ff5")); // D1 roUuid
        hierarchyUpdate.setRecognisingOrganisationUuid(
                UUID.fromString("fb35dd34-1b87-4c46-b6ab-21186c41663a")); // D12 roUuid (Child)
        BaseHeader baseHeader = OrganisationTestUtil.generateEventHeader();
        baseHeader.setEventName(OrganisationConstants.EventType.RO_HIERARCHY_UPDATE_EVENT);
        BaseAudit audit = new BaseAudit();
        Map<String, String> auditContext = new HashMap<>();
        audit.setAuditContext(auditContext);
        OrganisationHierarchyUpdate orgHierarchyUpdate =
                OrganisationHierarchyUpdate.builder()
                        .eventHeaders(baseHeader)
                        .eventBody(hierarchyUpdate)
                        .eventErrors(null)
                        .audit(audit)
                        .build();
        hierarchyUpdateDomainService.onCommand(orgHierarchyUpdate);
        Optional<RecognisingOrganisation> ro =
                roRepository.findById(UUID.fromString("fb35dd34-1b87-4c46-b6ab-21186c41663a"));
        List<LinkedRecognisingOrganisation> linkedRos =
                ro.get().getLinkedRecognisingOrganisations();
        List<LinkedRecognisingOrganisation> resultsDeliveryOrgsList =
                linkedRos.stream()
                        .filter(
                                linkedRO ->
                                        LinkTypeEnum.RESULTS_DELIVERY.getValue().equals(
                                                linkedRO.getLinkedRecognisingOrganisationType().getValue()))
                        .collect(Collectors.toList());
        assertEquals(
                "1234",
                linkedRos.stream()
                        .filter(
                                linkedRO ->
                                        LinkTypeEnum.PARENT_RO.getValue().equals(
                                                linkedRO.getLinkedRecognisingOrganisationType().getValue()))
                        .map(LinkedRecognisingOrganisation::getOrganisationHierarchyLabel)
                        .collect(Collectors.toList())
                        .get(0));
        assertTrue(
                resultsDeliveryOrgsList
                        .get(1)
                        .getEffectiveToDatetime()
                        .isAfter(OffsetDateTime.now()));
        assertFalse(
                resultsDeliveryOrgsList
                        .get(0)
                        .getEffectiveToDatetime()
                        .isAfter(OffsetDateTime.now()));
    }

    @Test
    final void whenUpdateParent_withSameHierarchy_thenDoNotTriggerDomainEvent()
            throws SQLException, IOException {

        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");

        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        List<RoDataUpdateLinkedOrganisation> linkedOrganisations =
                removeAParentRODataSetUp(); // D1 parent is changed to another node of same
        // hierarchy
        linkedOrganisations
                .get(0)
                .setTargetRecognisingOrganisationUuid(
                        UUID.fromString("63bf1302-acb6-401c-879f-2ae55dfe8c62"));
        linkedOrganisations
                .get(0)
                .setLinkEffectiveToDateTime(LocalDateTime.of(2099, 12, 31, 00, 59).atOffset(ZoneOffset.UTC));
        roDataUpdate.setLinkedOrganisations(linkedOrganisations);
        roDataUpdate.setContacts(UpdateOrganisationDataSetup.getContactsDataForIntegrationTest());

        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);
        ThreadLocalHeaderContext.getContext().setEventName(OrganisationConstants.EventType.RO_UPDATED_EVENT);
        Map<String, String> eventContextList = new HashMap<>();
        eventContextList.put("recognisingOrganisationUuid", "b56d6c5f-d7f9-453d-b14f-ccd7f0586ff5");
        ThreadLocalHeaderContext.getContext().setEventContext(eventContextList);
        roDataUpdate.setRecognisingOrganisationUuid(UUID.fromString("b56d6c5f-d7f9-453d-b14f-ccd7f0586ff5"));
        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));
        verify(applicationEventPublisher, times(1)).publishEvent(publishedEventCaptor.capture());
        verify(domainEventPublisher, times(0))
                .baseEventListPublisher(publishedListEventCaptor.capture());
    }

    private List<RoDataUpdateLinkedOrganisation> removeAParentRODataSetUp() {
        List<RoDataUpdateLinkedOrganisation> updatedLinkedRos =
                new ArrayList<>();
        RoDataUpdateLinkedOrganisation updateLinkedRO1 = new RoDataUpdateLinkedOrganisation();
        updateLinkedRO1.setLinkedRecognisingOrganisationUuid(
                UUID.fromString("a8239c83-fc59-4e8e-a860-3bef0defc26f"));
        updateLinkedRO1.setTargetRecognisingOrganisationUuid(
                UUID.fromString("ae1a5ea5-b6ab-40f3-ba72-cca9dff8332e"));
        updateLinkedRO1.setLinkType(LinkTypeEnum.valueOf(LinkTypeEnum.PARENT_RO.getValue()));
        updateLinkedRO1.setLinkEffectiveFromDateTime(LocalDateTime.of(2022, 04, 20, 11, 59).atOffset(ZoneOffset.UTC));
        updateLinkedRO1.setLinkEffectiveToDateTime(LocalDateTime.of(2022, 04, 22, 00, 59).atOffset(ZoneOffset.UTC));
        updatedLinkedRos.add(updateLinkedRO1);
        RoDataUpdateLinkedOrganisation updateLinkedRO2 = new RoDataUpdateLinkedOrganisation();
        updateLinkedRO2.setLinkedRecognisingOrganisationUuid(
                UUID.fromString("418e2486-64d0-4cef-b0c4-b444199dc447"));
        updateLinkedRO2.setTargetRecognisingOrganisationUuid(
                UUID.fromString("ae1a5ea5-b6ab-40f3-ba72-cca9dff8332e"));
        updateLinkedRO2.setLinkType(LinkTypeEnum.valueOf(LinkTypeEnum.RESULTS_DELIVERY.getValue()));
        updateLinkedRO2.setLinkEffectiveFromDateTime(LocalDateTime.of(2022, 04, 20, 11, 59).atOffset(ZoneOffset.UTC));
        updateLinkedRO2.setLinkEffectiveToDateTime(LocalDateTime.of(2022, 04, 22, 00, 59).atOffset(ZoneOffset.UTC));
        updatedLinkedRos.add(updateLinkedRO2);
        return updatedLinkedRos;
    }

    private List<RoDataUpdateLinkedOrganisation> changeParentRODataSetUp() {
        List<RoDataUpdateLinkedOrganisation> updatedLinkedRos =
                new ArrayList<>();
        RoDataUpdateLinkedOrganisation updateLinkedRO1 = new RoDataUpdateLinkedOrganisation();
        updateLinkedRO1.setLinkedRecognisingOrganisationUuid(
                UUID.fromString("a8239c83-fc59-4e8e-a860-3bef0defc26f"));
        updateLinkedRO1.setTargetRecognisingOrganisationUuid(
                UUID.fromString(
                        "aecf88e3-a88e-467a-b966-ab4ac939de55")); // Cambridge University UUID (root
        // node of another tree
        updateLinkedRO1.setLinkType(LinkTypeEnum.valueOf(LinkTypeEnum.PARENT_RO.getValue()));
        updateLinkedRO1.setLinkEffectiveFromDateTime(LocalDateTime.of(2022, 04, 20, 11, 59).atOffset(ZoneOffset.UTC));
        updateLinkedRO1.setLinkEffectiveToDateTime(LocalDateTime.of(2099, 12, 31, 00, 59).atOffset(ZoneOffset.UTC));
        updatedLinkedRos.add(updateLinkedRO1);
        RoDataUpdateLinkedOrganisation updateLinkedRO2 = new RoDataUpdateLinkedOrganisation();
        updateLinkedRO2.setLinkedRecognisingOrganisationUuid(
                UUID.fromString("418e2486-64d0-4cef-b0c4-b444199dc447"));
        updateLinkedRO2.setTargetRecognisingOrganisationUuid(
                UUID.fromString("ae1a5ea5-b6ab-40f3-ba72-cca9dff8332e"));
        updateLinkedRO2.setLinkType(LinkTypeEnum.valueOf(LinkTypeEnum.RESULTS_DELIVERY.getValue()));
        updateLinkedRO2.setLinkEffectiveFromDateTime(LocalDateTime.of(2022, 04, 20, 11, 59).atOffset(ZoneOffset.UTC));
        updateLinkedRO2.setLinkEffectiveToDateTime(LocalDateTime.of(2022, 04, 22, 00, 59).atOffset(ZoneOffset.UTC));
        updatedLinkedRos.add(updateLinkedRO2);
        RoDataUpdateLinkedOrganisation newADOFromParentHierarchy =
                new RoDataUpdateLinkedOrganisation();
        newADOFromParentHierarchy.setTargetRecognisingOrganisationUuid(
                UUID.fromString(
                        "5c2e3965-8b90-488f-b5e9-4da8854785cb")); // Cambridge University - Science
        newADOFromParentHierarchy.setLinkType(LinkTypeEnum.valueOf(LinkTypeEnum.RESULTS_DELIVERY.getValue()));
        newADOFromParentHierarchy.setLinkEffectiveFromDateTime(
                LocalDateTime.of(2022, 04, 20, 11, 59).atOffset(ZoneOffset.UTC));
        newADOFromParentHierarchy.setLinkEffectiveToDateTime(
                LocalDateTime.of(2099, 12, 31, 00, 59).atOffset(ZoneOffset.UTC));
        updatedLinkedRos.add(newADOFromParentHierarchy);
        return updatedLinkedRos;
    }

    private RoDataUpdateLinkedOrganisation addNewParentForRootNodeDataSetUp() {
        RoDataUpdateLinkedOrganisation newParent = new RoDataUpdateLinkedOrganisation();
        newParent.setTargetRecognisingOrganisationUuid(
                UUID.fromString("aecf88e3-a88e-467a-b966-ab4ac939de55")); // Cambridge University
        newParent.setLinkType(LinkTypeEnum.valueOf(LinkTypeEnum.PARENT_RO.getValue()));
        newParent.setLinkEffectiveFromDateTime(LocalDateTime.of(2022, 04, 20, 11, 59).atOffset(ZoneOffset.UTC));
        newParent.setLinkEffectiveToDateTime(LocalDateTime.of(2099, 12, 31, 00, 59).atOffset(ZoneOffset.UTC));
        return newParent;
    }
}
