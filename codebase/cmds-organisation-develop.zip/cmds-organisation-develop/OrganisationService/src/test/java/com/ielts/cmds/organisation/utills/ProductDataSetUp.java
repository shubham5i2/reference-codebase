package com.ielts.cmds.organisation.utills;



import com.ielts.cmds.organisation.cache.entity.Product;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ProductDataSetUp {
    public static List<com.ielts.cmds.organisation.cache.entity.Product> bookableProducts(){
        List<Product> bookableProductsList = new ArrayList<>();
        Product product1 = new Product();
        product1.setProductUuid(UUID.fromString("d96eece2-1d7c-495a-a754-6b523b710a82"));
        product1.setName("IELTS Online GT");
        product1.setProductCharacteristics("{\"characteristics\": [\"IOL\",\"GT\"],\"RoAutoAccepted\": [\"FALSE\"]}");
        bookableProductsList.add(product1);

        Product product2 = new Product();
        product2.setProductUuid(UUID.fromString("3e81e94b-8b6a-42b5-970c-b141f9d195a3"));
        product2.setName("IELTS Online AC");
        product2.setProductCharacteristics("{\"characteristics\": [\"IOL\",\"AC\"],\"RoAutoAccepted\": [\"FALSE\"]}");
        bookableProductsList.add(product2);

        Product product3 = new Product();
        product3.setProductUuid(UUID.fromString("6d04f596-22f2-49c4-9d47-85b167b8ca6f"));
        product3.setName("IELTS SELT on Computer AC");
        product3.setProductCharacteristics("{\"characteristics\": [\"IOC\",\"AC\", \"SELT\"],\"RoAutoAccepted\": [\"FALSE\"]}");
        bookableProductsList.add(product3);

        Product product4 = new Product();
        product4.setProductUuid(UUID.fromString("fdbacec5-e80a-4710-b3de-7d5f310b1466"));
        product4.setName("IELTS on Computer AC");
        product4.setProductCharacteristics("{\"characteristics\": [\"IOC\",\"AC\"],\"RoAutoAccepted\": [\"FALSE\"]}");
        bookableProductsList.add(product4);

        Product product5 = new Product();
        product5.setProductUuid(UUID.fromString("54b9d8df-c07a-4cb4-b397-adc4faa87c3f"));
        product5.setName("IELTS SELT on Computer GT");
        product5.setProductCharacteristics("{\"characteristics\": [\"IOC\", \"GT\",\"SELT\"],\"RoAutoAccepted\": [\"FALSE\"]}");
        bookableProductsList.add(product5);

        Product product6 = new Product();
        product6.setProductUuid(UUID.fromString("6d28d524-472d-4d53-8fd9-dc7c4bb5325d"));
        product6.setName("IELTS OSR Online AC");
        product6.setProductCharacteristics("{\"characteristics\": [\"IOL\", \"OSR\", \"SSR\",\"AC\"],\"RoAutoAccepted\": [\"FALSE\"]}");
        bookableProductsList.add(product6);

        Product product7 = new Product();
        product7.setProductUuid(UUID.fromString("7b1d8d96-c314-40cd-a61c-2b681086a458"));
        product7.setName("IELTS OSR Online GT");
        product7.setProductCharacteristics("{\"characteristics\": [\"IOL\", \"OSR\", \"SSR\",\"GT\"],\"RoAutoAccepted\": [\"FALSE\"]}");
        bookableProductsList.add(product7);

        Product product8 = new Product();
        product8.setProductUuid(UUID.fromString("4ca26fd2-5216-4e9a-ba08-89bb94599778"));
        product8.setName("IELTS SELT Online AC");
        product8.setProductCharacteristics("{\"characteristics\": [\"IOL\", \"SELT\",\"AC\"],\"RoAutoAccepted\": [\"FALSE\"]}");
        bookableProductsList.add(product8);

        Product product9 = new Product();
        product9.setProductUuid(UUID.fromString("0b0e3eb3-7929-4e38-bc63-dea6ffe6def8"));
        product9.setName("IELTS SELT Online GT");
        product9.setProductCharacteristics("{\"characteristics\": [\"IOL\", \"SELT\",\"GT\"],\"RoAutoAccepted\": [\"FALSE\"]}");
        bookableProductsList.add(product9);

        Product product10 = new Product();
        product10.setProductUuid(UUID.fromString("2948e48b-519b-484e-aed9-93a30a8a9485"));
        product10.setName("IELTS OSR SELT Online AC");
        product10.setProductCharacteristics("{\"characteristics\": [\"IOL\", \"SELT\",\"OSR\", \"SSR\",\"AC\"],\"RoAutoAccepted\": [\"FALSE\"]}");
        bookableProductsList.add(product10);

        Product product11 = new Product();
        product11.setProductUuid(UUID.fromString("58c171e7-6789-498c-9e2e-e26f4bf8c90c"));
        product11.setName("IELTS OSR SELT Online GT");
        product11.setProductCharacteristics("{\"characteristics\": [\"IOL\", \"SELT\",\"OSR\", \"SSR\",\"GT\"],\"RoAutoAccepted\": [\"FALSE\"]}");
        bookableProductsList.add(product11);

        Product product12 = new Product();
        product12.setProductUuid(UUID.fromString("cf9a05e9-2679-42da-b7d2-b34ea3e0724e"));
        product12.setName("IELTS on Computer GT");
        product12.setProductCharacteristics("{\"characteristics\": [\"IOC\",\"GT\"],\"RoAutoAccepted\": [\"FALSE\"]}");
        bookableProductsList.add(product12);

        Product product13 = new Product();
        product13.setProductUuid(UUID.fromString("cb7cd48c-5e79-4a28-8104-e0bcd8e39999"));
        product13.setName("IELTS OSR on Computer AC");
        product13.setProductCharacteristics("{\"characteristics\": [\"IOC\", \"OSR\", \"SSR\",\"AC\"],\"RoAutoAccepted\": [\"FALSE\"]}");
        bookableProductsList.add(product13);

        Product product14 = new Product();
        product14.setProductUuid(UUID.fromString("c37e2fab-898d-46d4-a61b-17f24bb29e83"));
        product14.setName("IELTS OSR on Computer GT");
        product14.setProductCharacteristics("{\"characteristics\": [\"IOC\", \"OSR\", \"SSR\",\"GT\"],\"RoAutoAccepted\": [\"FALSE\"]}");
        bookableProductsList.add(product14);

        Product product15 = new Product();
        product15.setProductUuid(UUID.fromString("de58e8e0-39c6-4c54-b62e-40cacbc6c56d"));
        product15.setName("IELTS OSR SELT on Computer AC");
        product15.setProductCharacteristics("{\"characteristics\": [\"IOC\", \"SELT\",\"OSR\", \"SSR\",\"AC\"],\"RoAutoAccepted\": [\"FALSE\"]}");
        bookableProductsList.add(product15);

        Product product16 = new Product();
        product16.setProductUuid(UUID.fromString("fa91bc2a-29e2-4ef5-a1be-785c6ad0a2db"));
        product16.setName("IELTS OSR SELT on Computer GT");
        product16.setProductCharacteristics("{\"characteristics\": [\"IOC\", \"SELT\",\"OSR\", \"SSR\",\"GT\"],\"RoAutoAccepted\": [\"FALSE\"]}");
        bookableProductsList.add(product16);
        return bookableProductsList;
    }
}
