package com.ielts.cmds.organisation.domain.services;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.cache.JedisGenericReader;
import com.ielts.cmds.organisation.cache.factory.JedisFactory;
import com.ielts.cmds.organisation.common.out.event.RoDetailsDataGeneratedEventV1;
import com.ielts.cmds.organisation.domain.commands.CreateROVO;
import com.ielts.cmds.organisation.domain.commands.SearchRoByOrgId;
import com.ielts.cmds.organisation.domain.model.RoDataCreateV1Valid;
import com.ielts.cmds.organisation.infrastructure.config.RBACTestConfig;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.utills.CreateOrganisationDataSetup;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.implementation.impl.LocationHierarchyServiceImpl;
import com.ielts.cmds.rbac.implementation.impl.UserGroupServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

import javax.transaction.Transactional;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Stream;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = RBACTestConfig.class)
@ActiveProfiles("test")
@Sql({
    "/sql/schema.sql",
    "/sql/organisation-type-data.sql",
    "/sql/partner-data.sql",
    "/sql/address-type-data.sql",
    "/sql/sector-type-data.sql",
    "/sql/product-data.sql",
    "/sql/note-type-data.sql",
    "/sql/contact-type-data.sql",
    "/sql/country-data.sql",
    "/sql/territory-data.sql",
    "/sql/module-type-data.sql",
    "/sql/ro-data-for-search.sql",
    "/sql/usergroup-hierarchy.sql"
})
@Transactional
class SearchByOrgIdDomainServiceIntegrationTest {

    @Autowired private RecognisingOrganisationRepository recognisingOrgRepository;

    @MockBean private ApplicationEventPublisher applicationEventPublisher;

    @Autowired private OrganisationCommonUtils organisationCommonUtils;

    @Autowired
    private SearchByOrgIdDomainService searchByOrgIdDomainService;

    @Captor ArgumentCaptor<BaseEvent<BaseHeader>> publishedEventCaptor;

    @Autowired private UserGroupServiceImpl userGroupServiceImpl;

    @Autowired private LocationHierarchyServiceImpl locationHierarchyServiceImpl;

    @Autowired private ObjectMapper objectMapper;

    @Spy private OrganisationCommonUtils orgUtils;

    @MockBean private JedisGenericReader jedisGenericReader;

    @MockBean private JedisFactory jedisFactory;

    @BeforeEach
    void setup() throws RbacValidationException {
        userGroupServiceImpl.populateUserGroupHierarchyData();
        locationHierarchyServiceImpl.populateRootData();
        ReflectionTestUtils.setField(
                organisationCommonUtils, "applicationEventPublisher", applicationEventPublisher);
        Map<String, String> eventContextList = new HashMap<>();
        eventContextList.put("organisationId", "321");
        CMDSHeaderContext header = OrganisationTestUtil
                .generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_SEARCH_BY_ORG_ID_REQUEST_EVENT);
        header.setEventContext(eventContextList);
        ThreadLocalHeaderContext.setContext(header);
        ThreadLocalAuditContext.setContext(OrganisationTestUtil.getBaseAudit());
        ReflectionTestUtils.setField(
                organisationCommonUtils, "jedisGenericReader", jedisGenericReader);
    }

    @MethodSource("provideArgumentsForSearchOrgByIdCommand")
    @ParameterizedTest
    void whenValidToken_SearchByOrgId_ExpectEvent(
            final RecognisingOrganisation recognisingOrganisation)
            throws IOException, RbacValidationException {

        String authorisedAccessToken =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessToken);
        Integer orgId = 321;
        searchByOrgIdDomainService.onCommand(orgId);

        verify(applicationEventPublisher, times(1)).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();

        RoDetailsDataGeneratedEventV1 roDetailsDataGeneratedEventV1 =
                objectMapper.readValue(event.getEventBody(), RoDetailsDataGeneratedEventV1.class);
        Optional<RecognisingOrganisation> roDataFromDb =
                recognisingOrgRepository.findByRecognisingOrganisationUuid(
                        recognisingOrganisation.getRecognisingOrganisationUuid());
        assertEquals(
                OrganisationConstants.EventType.RO_DETAILS_DATA_GENERATED_EVENT,
                event.getEventHeader().getEventName());
        assertTrue(roDataFromDb.isPresent());
        assertEquals(
                roDataFromDb.get().getRecognisingOrganisationUuid(),
                roDetailsDataGeneratedEventV1.get(0).getRecognisingOrganisationUuid());
        assertEquals(roDataFromDb.get().getName(), roDetailsDataGeneratedEventV1.get(0).getName());
    }

    @MethodSource("provideArgumentsForSearchOrgByIdCommand")
    @ParameterizedTest
    void whenRecordNotFound_SearchOrgByOrgId_ExpectEmptyListEvent() throws IOException, RbacValidationException {
        BaseHeader header = organisationCommonUtils
                .buildUiHeader();
        String authorisedAccessToken =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessToken);
        Integer orgId = 321;
        doReturn(null).when(orgUtils).getOrganisationByOrgId(321);
        searchByOrgIdDomainService.onCommand(orgId);

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();

        assertEquals(
                OrganisationConstants.EventType.RO_DETAILS_DATA_GENERATED_EVENT,
                event.getEventHeader().getEventName());
    }

    @MethodSource("provideArgumentsForSearchOrgByIdCommand")
    @ParameterizedTest
    void whenInvalidToken_SearchOrgById_ExpectRejectEvent(
            final RecognisingOrganisation recognisingOrganisation)
            throws IOException {

        String unAuthorisedAccessToken =
                OrganisationTestUtil.getAccessToken("test-admin-support-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(unAuthorisedAccessToken);

        CMDSErrorResponse expectedErrorResponse =
                OrganisationTestUtil.getROErrorResponse(
                        "V0044",
                        "UnauthorisedToViewOrganisation",
                        OrganisationConstants.EventType.RO_VIEW_DETAILS_REJECTED_EVENT);
        searchByOrgIdDomainService.onCommand(321);

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();

        assertEquals(
                expectedErrorResponse.getErrorList().size(),
                event.getEventErrors().getErrorList().size());
        assertEquals(
                expectedErrorResponse.getErrorList().get(0).getErrorCode(),
                event.getEventErrors().getErrorList().get(0).getErrorCode());
        assertEquals(
                OrganisationConstants.EventType.RO_VIEW_DETAILS_REJECTED_EVENT,
                event.getEventHeader().getEventName());
    }

    private static Stream<Arguments> provideArgumentsForSearchOrgByIdCommand() {

        final RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        UiHeader roHeaders = OrganisationTestUtil.generateEventHeader();
        BaseEvent<BaseHeader> event = new BaseEvent<>(roHeaders, null, null, null);
        SearchRoByOrgId searchRoByOrgId =
                SearchRoByOrgId.builder()
                        .eventHeaders(event.getEventHeader())
                        .eventBody(event.getEventBody())
                        .eventErrors(event.getEventErrors())
                        .build();

        CreateROVO createRo =
                CreateROVO.builder()
                        .eventHeaders(event.getEventHeader())
                        .eventBody(roDataCreateV1)
                        .eventErrors(event.getEventErrors())
                        .build();
        BaseAudit audit = new BaseAudit();
        Map<String, String> auditContext = new HashMap<>();
        audit.setAuditContext(auditContext);
        searchRoByOrgId.setAudit(audit);
        Set<RecognisingOrganisation> recognisingOrganisationList = new HashSet<>();
        RecognisingOrganisation recognisingOrganisation =
                CreateOrganisationDataSetup.populateOrganisation(
                        createRo.getEventBody(), new RecognisingOrganisation());
        recognisingOrganisation.setRecognisingOrganisationUuid(
                UUID.fromString("eeb87d1e-3d5b-4375-8edf-55e66c86b1de"));
        recognisingOrganisation.setName("London  Metropolitain University");
        recognisingOrganisation.setOrganisationId(321);
        recognisingOrganisationList.add(recognisingOrganisation);
        RoDetailsDataGeneratedEventV1 roDetails =
                CreateOrganisationDataSetup.entityToEventMapperForSearchByOrgId(
                        recognisingOrganisationList);
        Map<String, String> eventContextList = new HashMap<>();
        eventContextList.put("organisationId", "321");
        BaseHeader roHeader = searchRoByOrgId.getEventHeaders();
        roHeader.setEventName(OrganisationConstants.EventType.RO_DETAILS_DATA_GENERATED_EVENT);
        roHeader.setEventDateTime(LocalDateTime.now());
        roHeader.setEventDiscriminator("RO-UI");
        roHeader.setEventContext(eventContextList);

        return Stream.of(Arguments.of(recognisingOrganisation, roDetails));
    }
}
