package com.ielts.cmds.organisation.utills;

import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.ListJoin;
import javax.persistence.criteria.Root;

import com.ielts.cmds.api.roui005rosearchrequested.RoSearchCriteria;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.jpa.domain.Specification;
import com.ielts.cmds.organisation.infrastructure.entity.Address;
import com.ielts.cmds.organisation.infrastructure.entity.Contact;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.utils.SearchFullTextRoNameCriteriaSpecificationUtil;
import com.ielts.cmds.organisation.utils.SearchRemaningCriteriaSpecificationUtil;

@ExtendWith(MockitoExtension.class)
class SearchFullTextCriteriaSpecificationUtilTest {

	@InjectMocks
	private SearchFullTextRoNameCriteriaSpecificationUtil searchFullTextRoNameCriteriaSpecificationUtil;

	@Mock
	private CriteriaBuilder criteriaBuilder;

	@Mock
	private CriteriaQuery<RecognisingOrganisation> criteriaQuery;

	@Mock
	private Root<RecognisingOrganisation> recognisingOrganisationRoot;

	@Mock
	private ListJoin<RecognisingOrganisation, Address> joinAddressMock;

	@Mock
	private ListJoin<RecognisingOrganisation, Contact> joinContactMock;
	
	@Mock private SearchRemaningCriteriaSpecificationUtil searchRemaningCriteriaSpecificationUtil;
	
	@Mock private Specification<RecognisingOrganisation> partialMatchSpec;

	@BeforeEach
	void setup() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void whenOrgNameCriteriaIsEmpty_FullTextCriteriaMatches_ExpectOrgNameCriteriaBuilderIsNeverCalled() {

		RoSearchCriteria searchCriteria = SearchOrganisationDataSetup.getRoSearchCriteria();
		searchCriteria.setOrganisationName("");
		searchCriteria.setFuzzyMatch(false);
		doReturn(partialMatchSpec)
        .when(searchRemaningCriteriaSpecificationUtil)
        .criteriaMatches(searchCriteria, joinAddressMock);
		Specification<RecognisingOrganisation> actual = searchFullTextRoNameCriteriaSpecificationUtil
				.criteriaMatches(searchCriteria, joinAddressMock);
		actual.toPredicate(recognisingOrganisationRoot, criteriaQuery, criteriaBuilder);

		verify(criteriaBuilder, never()).equal(recognisingOrganisationRoot.get("name"),
				criteriaBuilder.literal(searchCriteria.getOrganisationName()));
	}

}
