package com.ielts.cmds.organisation.domain.services;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.organisation.domain.commands.LoadROData;
import com.ielts.cmds.organisation.domain.commands.UpdateROVO;
import com.ielts.cmds.organisation.domain.model.LoadROHierarchyDataV1;
import com.ielts.cmds.organisation.domain.model.LoadROHierarchyMessageV1;
import com.ielts.cmds.organisation.domain.model.LoadROHierarchyRecordEvent;
import com.ielts.cmds.organisation.domain.model.RoDataUpdateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.utills.LoadROHierarchyDataSetup;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utills.UpdateOrganisationDataSetup;
import com.ielts.cmds.organisation.utils.LoadROHierarchyEventMapper;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
class LoadROHierarchyDomainServiceTest {

    @InjectMocks private LoadROHierarchyHelper loadROHierarchyDomainService;

    @Mock private CsvMapper csvMapper;

    @Mock private AmazonS3 s3Client;

    @Mock private ProcessROHierarchyDomainService processROHierarchyDomainService;

    @Mock private ApplicationEventPublisher applicationEventPublisher;

    @Mock private LoadROHierarchyEventMapper loadROHierarchyEventMapper;

    @Mock private ObjectMapper objectMapper;

    @Mock private S3Object s3Object;

    @Mock private CsvSchema csvSchema;

    @Mock private ObjectReader objectReader;

    @Mock private MappingIterator<LoadROHierarchyDataV1> mappingIterator;

    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(loadROHierarchyDomainService, "roBucketName", "test-bucket");
        ReflectionTestUtils.setField(loadROHierarchyDomainService, "processCount", "100");
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void when_OnCommand_ExpectNoException(
            final LoadROData loadROData,
            final S3ObjectInputStream s3ObjectInputStream,
            final List<LoadROHierarchyDataV1> loadROHierarchyDataV1List,
            final Map<String, LoadROHierarchyRecordEvent> eventsMap,
            final LoadROHierarchyMessageV1 loadROHierarchyMessageV1)
            throws Exception {
        doReturn(s3Object).when(s3Client).getObject("test-bucket", "test.csv");
        doReturn(s3ObjectInputStream).when(s3Object).getObjectContent();
        doReturn(csvSchema).when(csvMapper).schema();
        doReturn(csvSchema).when(csvSchema).withHeader();
        doReturn(csvSchema).when(csvSchema).withColumnSeparator(',');
        doReturn(objectReader).when(csvMapper).readerFor(LoadROHierarchyDataV1.class);
        doReturn(objectReader).when(objectReader).with(csvSchema);
        doReturn(mappingIterator).when(objectReader).readValues(any(BufferedReader.class));

        doReturn(loadROHierarchyDataV1List).when(mappingIterator).readAll();
        doReturn(eventsMap.get("1").getEvent())
                .when(processROHierarchyDomainService)
                .processRecord(loadROData, loadROHierarchyDataV1List.get(0));

        doReturn(loadROHierarchyMessageV1).when(loadROHierarchyEventMapper).mapToEvent(eventsMap);
        doNothing().when(applicationEventPublisher).publishEvent(any(BaseEvent.class));
        doReturn(new ObjectMapper().writeValueAsString(loadROHierarchyMessageV1))
                .when(objectMapper)
                .writeValueAsString(loadROHierarchyMessageV1);
        assertDoesNotThrow(() -> loadROHierarchyDomainService.onHierarchyUpdateCommand(loadROData));
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void when_ProcessCompletes_ExpectNoException(
            final LoadROData loadROData,
            final S3ObjectInputStream s3ObjectInputStream,
            final List<LoadROHierarchyDataV1> loadROHierarchyDataV1List,
            final Map<String, LoadROHierarchyRecordEvent> eventsMap,
            final LoadROHierarchyMessageV1 loadROHierarchyMessageV1)
            throws Exception {
        loadROData
                .getEventHeaders()
                .getEventContext()
                .put("start", String.valueOf(loadROHierarchyDataV1List.size() + 1));
        doReturn(s3Object).when(s3Client).getObject("test-bucket", "test.csv");
        doReturn(s3ObjectInputStream).when(s3Object).getObjectContent();
        doReturn(csvSchema).when(csvMapper).schema();
        doReturn(csvSchema).when(csvSchema).withHeader();
        doReturn(csvSchema).when(csvSchema).withColumnSeparator(',');
        doReturn(objectReader).when(csvMapper).readerFor(LoadROHierarchyDataV1.class);
        doReturn(objectReader).when(objectReader).with(csvSchema);
        doReturn(mappingIterator).when(objectReader).readValues(any(BufferedReader.class));

        doReturn(loadROHierarchyDataV1List).when(mappingIterator).readAll();
        assertDoesNotThrow(() -> loadROHierarchyDomainService.onHierarchyUpdateCommand(loadROData));
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void when_OnCommand_Exception_ExpectNoException(
            final LoadROData loadROData,
            final S3ObjectInputStream s3ObjectInputStream,
            final List<LoadROHierarchyDataV1> loadROHierarchyDataV1List,
            final Map<String, LoadROHierarchyRecordEvent> eventsMap,
            final LoadROHierarchyMessageV1 loadROHierarchyMessageV1)
            throws Exception {

        doReturn(s3Object).when(s3Client).getObject("test-bucket", "test.csv");
        doReturn(s3ObjectInputStream).when(s3Object).getObjectContent();
        doReturn(csvSchema).when(csvMapper).schema();
        doReturn(csvSchema).when(csvSchema).withHeader();
        doReturn(csvSchema).when(csvSchema).withColumnSeparator(',');
        doReturn(objectReader).when(csvMapper).readerFor(LoadROHierarchyDataV1.class);
        doReturn(objectReader).when(objectReader).with(csvSchema);
        doReturn(mappingIterator).when(objectReader).readValues(any(BufferedReader.class));

        doReturn(loadROHierarchyDataV1List).when(mappingIterator).readAll();

        doThrow(new RuntimeException("Invalid data"))
                .when(processROHierarchyDomainService)
                .processRecord(loadROData, loadROHierarchyDataV1List.get(0));

        assertDoesNotThrow(() -> loadROHierarchyDomainService.onHierarchyUpdateCommand(loadROData));
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void when_OnCommand_ExpectIllegalArgumentException(
            final LoadROData loadROData,
            final S3ObjectInputStream s3ObjectInputStream,
            final List<LoadROHierarchyDataV1> loadROHierarchyDataV1List,
            final Map<String, LoadROHierarchyRecordEvent> eventsMap,
            final LoadROHierarchyMessageV1 loadROHierarchyMessageV1)
            throws IOException {
        loadROData.getEventHeaders().setEventContext(null);
        assertThrows(
                IllegalArgumentException.class,
                () -> loadROHierarchyDomainService.onHierarchyUpdateCommand(loadROData));
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void when_OnCommand_FileNotPresent_ExpectIllegalArgumentException(
            final LoadROData loadROData,
            final S3ObjectInputStream s3ObjectInputStream,
            final List<LoadROHierarchyDataV1> loadROHierarchyDataV1List,
            final Map<String, LoadROHierarchyRecordEvent> eventsMap,
            final LoadROHierarchyMessageV1 loadROHierarchyMessageV1)
            throws IOException {
        loadROData.getEventHeaders().getEventContext().clear();
        assertThrows(
                IllegalArgumentException.class,
                () -> loadROHierarchyDomainService.onHierarchyUpdateCommand(loadROData));
    }

    private static Stream<Arguments> argumentsProviderForOrganisationLoadDataEvent()
            throws JsonProcessingException {

        InputStream inputStream = IOUtils.toInputStream("a,b,c", Charset.defaultCharset());
        S3ObjectInputStream s3ObjectInputStream = new S3ObjectInputStream(inputStream, null);

        UiHeader roHeaders = OrganisationTestUtil.generateEventHeader();
        roHeaders.setEventName(
                OrganisationConstants.GenericConstants.OPERATION_TYPE_GET
                        + OrganisationConstants.GenericConstants.LOAD_RO_DATA_RESOURCE_TYPE);
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put(OrganisationConstants.GenericConstants.RO_DATA_FILE, "test.csv");
        eventContext.put(
                OrganisationConstants.GenericConstants.LOAD_ORGANISATION_TYPE,
                OrganisationConstants.GenericConstants.RECOGNISING_ORGANISATION);
        eventContext.put(OrganisationConstants.GenericConstants.MODE, "update");
        roHeaders.setEventContext(eventContext);

        final BaseEvent<UiHeader> event = new BaseEvent<UiHeader>(roHeaders, null, null, null);
        LoadROData loadROData =
                LoadROData.builder()
                        .eventHeaders(event.getEventHeader())
                        .eventErrors(event.getEventErrors())
                        .build();
        List<LoadROHierarchyDataV1> loadROHierarchyDataV1List =
                LoadROHierarchyDataSetup.getLoadROHierarchyDataV1List();

        LoadROHierarchyMessageV1 loadROHierarchyMessageV1 =
                LoadROHierarchyDataSetup.getLoadROHierarchyMessageV1(
                        loadROHierarchyDataV1List.get(0));
        RoDataUpdateV1Valid roData = UpdateOrganisationDataSetup.updateOrgData();
        final UpdateROVO updateROVO = UpdateROVO.builder().eventBody(roData).build();
        RecognisingOrganisation publishRo =
                UpdateOrganisationDataSetup.getExistingOrganisationDetails(
                        updateROVO.getEventBody(), new RecognisingOrganisation());
        Map<String, LoadROHierarchyRecordEvent> eventsMap =
                LoadROHierarchyDataSetup.getEventsMap(
                        LoadROHierarchyDataSetup.getROCreatedEvent(publishRo),
                        loadROHierarchyDataV1List.get(0));
        return Stream.of(
                Arguments.of(
                        loadROData,
                        s3ObjectInputStream,
                        loadROHierarchyDataV1List,
                        eventsMap,
                        loadROHierarchyMessageV1));
    }
}
