package com.ielts.cmds.organisation.cache.factory;

import com.ielts.cmds.organisation.cache.JedisCacheReader;
import com.ielts.cmds.organisation.cache.JedisGenericReader;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisPooled;
import redis.clients.jedis.UnifiedJedis;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class JedisFactoryTest {

	@Spy
	@InjectMocks
	private JedisFactory jedisFactory;

	@Mock
	private JedisCluster jedisCluster;

	@Mock
	private UnifiedJedis jedis;

	@Mock
	private JedisPooled jedisPool;
	
	@BeforeEach
    void setup() {
        ReflectionTestUtils.setField(jedisFactory, "isClusterModeEnabled", "false");
        ReflectionTestUtils.setField(jedisFactory, "redisElasticacheHost", "jj");
        ReflectionTestUtils.setField(jedisFactory, "redisElasticachePort", "6379");
    }
	
	@Test
	void testIsClusterModeifFalse() {
		boolean isClusterModeEnabled = jedisFactory.isClusterModeEnabled();
		assertFalse(isClusterModeEnabled);
	}

	@Test
	void testGetJedisInstance() {
		when(jedisFactory.getJedisPool()).thenReturn(jedisPool);
		UnifiedJedis jedisInstanceReturned = jedisFactory.jedis();
		assertTrue(jedisInstanceReturned instanceof UnifiedJedis);
	}

	@Test
	void testIsClusterMode() {
		ReflectionTestUtils.setField(jedisFactory, "isClusterModeEnabled", "true");
		boolean isClusterModeEnabled = jedisFactory.isClusterModeEnabled();
		assertTrue(isClusterModeEnabled);
	}

	@Test
	void testGetJedisClusterInstance() {
		ReflectionTestUtils.setField(jedisFactory, "isClusterModeEnabled", "true");
		doReturn(jedisCluster).when(jedisFactory).jedisCluster();
		UnifiedJedis jedisClusterInstance = jedisFactory.jedisCluster();
		assertNotNull(jedisClusterInstance);
		assertTrue(jedisClusterInstance instanceof UnifiedJedis);
	}

	@Test
	void test_whenGetJedisWriter_thenReturnJedisClusterCacheWriterInstance() {
		ReflectionTestUtils.setField(jedisFactory, "isClusterModeEnabled", "true");
		doReturn(jedisCluster).when(jedisFactory).jedisCluster();
		JedisGenericReader jedisClusterCacheReaderInstance = jedisFactory.jedisClusterReader();
		assertTrue(jedisClusterCacheReaderInstance instanceof JedisCacheReader);
	}

	@Test
	void test_whenGetJedisWriter_thenReturnJedisCacheWriterInstance() {
		doReturn(jedis).when(jedisFactory).jedis();
		JedisGenericReader jedisCacheReaderInstance = jedisFactory.jedisCacheReader();
		assertTrue(jedisCacheReaderInstance instanceof JedisCacheReader);
	}

}
