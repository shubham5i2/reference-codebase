package com.ielts.cmds.organisation.domain.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.roui009roupdaterequested.VerificationStatusEnum;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.*;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.cache.JedisGenericReader;
import com.ielts.cmds.organisation.cache.entity.Product;
import com.ielts.cmds.organisation.domain.model.RoDataUpdateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.*;
import com.ielts.cmds.organisation.infrastructure.repository.*;
import com.ielts.cmds.organisation.utills.CreateOrganisationDataSetup;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utills.UpdateOrganisationDataSetup;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.organisation.utils.UpdateOrganisationUtil;
import com.ielts.cmds.rbac.api.service.RBACService;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.util.ReflectionTestUtils;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import java.lang.reflect.InvocationTargetException;
import java.util.*;
import java.util.stream.Stream;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@RunWith(MockitoJUnitRunner.class)
class UpdateOrganisationDomainServiceTest {

    @InjectMocks private UpdateOrganisationDomainService updateOrganisationDomainService;

    @Mock private ObjectMapper objectMapper;

    @Spy private OrganisationCommonUtils orgCommonUtils;

    @Mock private RecognisingOrganisationRepository recognisingOrganisationRepository;

    @Mock private NoteTypeRepository noteTypeRepository;

    @Mock private CountryRepository countryRepository;

    @Mock private TerritoryRepository territoryRepository;

    @Mock private ContactTypeRepository contactTypeRepository;

    @Mock private StatusHistoryRepository statusHistoryRepository;

    @Mock private OrganisationTypeRepository organisationTypeRepository;

    @Mock private AddressTypeRepository addressTypeRepository;

    @Mock private SectorTypeRepository sectorTypeRepository;

    @Spy private UpdateOrganisationUtil updateOrgUtil;

    @Mock private Validator roValidator;

    @Captor private ArgumentCaptor<RecognisingOrganisation> organisationCapt;
    @Captor private ArgumentCaptor<StatusHistory> statusHistoryCapt;
    @Mock private CMDSErrorResolver<Object> errorResolver;
    @Captor private ArgumentCaptor<Set<ConstraintViolation<Object>>> violationSetCapt;
    @Mock private ApplicationEventPublisher applicationEventPublisher;
    @Mock private RBACService rbacService;
    @Mock private LinkedRecognisingOrganisationRepository linkedRORepository;
    @Mock private JedisGenericReader jedisGenericReader;

    /** @throws Exception */
    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(
                updateOrganisationDomainService, "orgCommonUtils", orgCommonUtils);
        ReflectionTestUtils.setField(updateOrganisationDomainService, "objectMapper", objectMapper);
        ReflectionTestUtils.setField(
                orgCommonUtils, "orgRepository", recognisingOrganisationRepository);
        ReflectionTestUtils.setField(
                updateOrganisationDomainService,
                "recognisingOrganisationRepository",
                recognisingOrganisationRepository);
        ReflectionTestUtils.setField(updateOrgUtil, "noteTypeRepository", noteTypeRepository);
        ReflectionTestUtils.setField(
                updateOrganisationDomainService, "updateOrgUtil", updateOrgUtil);
        ReflectionTestUtils.setField(orgCommonUtils, "countryRepository", countryRepository);
        ReflectionTestUtils.setField(orgCommonUtils, "territoryRepository", territoryRepository);
        ReflectionTestUtils.setField(
                updateOrganisationDomainService,
                "statusHistoryRepository",
                statusHistoryRepository);
        ReflectionTestUtils.setField(
                orgCommonUtils, "organisationTypeRepository", organisationTypeRepository);
        ReflectionTestUtils.setField(
                orgCommonUtils, "addressTypeRepository", addressTypeRepository);
        ReflectionTestUtils.setField(orgCommonUtils, "sectorTypeRepository", sectorTypeRepository);
        ReflectionTestUtils.setField(
                orgCommonUtils, "contactTypeRepository", contactTypeRepository);
        ReflectionTestUtils.setField(orgCommonUtils, "rbacService", rbacService);
        ReflectionTestUtils.setField(
                orgCommonUtils, "statusHistoryRepository", statusHistoryRepository);
        ReflectionTestUtils.setField(
                orgCommonUtils, "linkedRecognisingOrganisationRepository", linkedRORepository);
        ReflectionTestUtils.setField(
                updateOrgUtil, "orgRepository", recognisingOrganisationRepository);
        ReflectionTestUtils.setField(updateOrgUtil, "organisationCommonUtils", orgCommonUtils);
        ReflectionTestUtils.setField(
                orgCommonUtils, "applicationEventPublisher", applicationEventPublisher);
        ReflectionTestUtils.setField(orgCommonUtils, "objectMapper", objectMapper);
        ReflectionTestUtils.setField(
                orgCommonUtils, "jedisGenericReader", jedisGenericReader);
        ThreadLocalHeaderContext.setContext(OrganisationTestUtil
                .generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_UPDATE_REQUEST_EVENT));
        ThreadLocalAuditContext.setContext(OrganisationTestUtil.getBaseAudit());
    }

    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForUpdateOrganisationCommand")
    void whenReceivedValidCommmand_thenNoException(
            final CMDSHeaderContext uiHeader,
            final RoDataUpdateV1Valid roDataUpdate,
            RecognisingOrganisation organisation)
            throws JsonProcessingException, RbacValidationException {

        mockReferenceData();
        Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
        roDataUpdate.setLinkedOrganisations(null);
        organisation.setLinkedRecognisingOrganisations(new ArrayList<>());
        when(recognisingOrganisationRepository.findById(
                        UUID.fromString(
                                        uiHeader
                                        .getEventContext()
                                        .get("recognisingOrganisationUuid"))))
                .thenReturn(Optional.of(organisation));

        when(noteTypeRepository.findByNotesType("Internal"))
                .thenReturn(UpdateOrganisationDataSetup.getNoteTypesData());
        when(recognisingOrganisationRepository.save(organisation)).thenReturn(organisation);
        OrganisationType organisationType = CreateOrganisationDataSetup.getOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(organisationTypeRepository.findById(
                roDataUpdate.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        orgType,
                        OrganisationConstants.GenericConstants.UPDATE,
                        ThreadLocalAuditContext.getContext()))
                .thenReturn(violationSet);
        when(updateOrganisationDomainService.validateUpdateRODetails(roDataUpdate))
                .thenReturn(violationSet);
        when(statusHistoryRepository.findByRecognisingOrganisationOrderByStatusDatetimeDesc(
                        organisation))
                .thenReturn(UpdateOrganisationDataSetup.getStatusHistoryDetails());
        List<Product> products = CreateOrganisationDataSetup.getproductDataWithCharacteristics();
        when(jedisGenericReader.retrieveAllBookableProductsDataFromRedisCache()).thenReturn(products);
        updateOrganisationDomainService.onCommand(roDataUpdate);
        verify(recognisingOrganisationRepository, times(1)).save(organisationCapt.capture());
        assertNotNull(organisationCapt.getValue().getAddresses());
        assertEquals("McGill University", organisationCapt.getValue().getName());
        assertEquals("UCAS231", organisationCapt.getValue().getOrganisationCode());
        assertEquals("3", String.valueOf(organisationCapt.getValue().getResultAvailableForYears()));
    }

    @DisplayName("Record Not Found - Rejected Event")
    @ParameterizedTest
    @MethodSource("provideArgumentsForUpdateOrganisationCommand")
    void whenReceivedValidCommmand_recognisingOrganisationUuid_isNull_thenRejectedEvent(
            final CMDSHeaderContext uiHeader,
            final RoDataUpdateV1Valid roDataUpdate,
            RecognisingOrganisation organisation)
            throws JsonProcessingException, RbacValidationException, InvocationTargetException, IllegalAccessException {

        ThreadLocalHeaderContext.getContext().setEventContext(new HashMap<>());
        Set<ConstraintViolation<Object>> constraintViolation =
                orgCommonUtils.getSetforNullViolationOfEventBody("V0043", "OrganisationNotFound");
        final BaseAudit audit =  orgCommonUtils.getBaseAudit();
        CMDSErrorResponse cmdsErrorResponse =
                OrganisationTestUtil.getROErrorResponse(
                        "V0043",
                        "Organisation Not Found.",
                        OrganisationConstants.EventType.RO_UPDATE_REJECTED_EVENT);
        when(errorResolver.populatErrorResponse(
                        constraintViolation,
                        OrganisationConstants.EventType.RO_UPDATE_REJECTED_EVENT))
                .thenReturn(cmdsErrorResponse);
        UiHeader header = orgCommonUtils.buildUiHeader();
        updateOrganisationDomainService.onCommand(roDataUpdate);
        verify(errorResolver, times(1))
                .populatErrorResponse(violationSetCapt.capture(), Mockito.eq("RoChangeRejected"));
        header.setEventName("RoChangeRejected");
        BaseEvent<BaseHeader> event = new BaseEvent<>(header, objectMapper.writeValueAsString(roDataUpdate),
                new BaseEventErrors(cmdsErrorResponse.getErrorList()), audit);
        verify(applicationEventPublisher, times(1)).publishEvent(event);
        assertNotNull(violationSetCapt.getValue().iterator().next().getMessage());
        assertEquals("V0043", violationSetCapt.getValue().iterator().next().getMessage());
    }

    @DisplayName("Record Not Found - Rejected Event")
    @ParameterizedTest
    @MethodSource("provideArgumentsForUpdateOrganisationCommand")
    void whenReceivedValidCommand_testSaveStatusHistory_thenRejectedEvent(
            final CMDSHeaderContext uiHeader,
            final RoDataUpdateV1Valid roDataUpdate,
            RecognisingOrganisation organisation)
            throws JsonProcessingException, RbacValidationException {

        mockReferenceData();
        Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
        roDataUpdate.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.PENDING.getValue()));
        roDataUpdate.setLinkedOrganisations(null);
        when(recognisingOrganisationRepository.findById(
                        UUID.fromString(
                                        uiHeader
                                        .getEventContext()
                                        .get("recognisingOrganisationUuid"))))
                .thenReturn(Optional.of(organisation));
        when(noteTypeRepository.findByNotesType("Internal"))
                .thenReturn(UpdateOrganisationDataSetup.getNoteTypesData());
        OrganisationType organisationType = CreateOrganisationDataSetup.getOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(organisationTypeRepository.findById(
                roDataUpdate.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        orgType,
                        OrganisationConstants.GenericConstants.UPDATE,
                        ThreadLocalAuditContext.getContext()))
                .thenReturn(violationSet);
        when(updateOrganisationDomainService.validateUpdateRODetails(roDataUpdate))
                .thenReturn(violationSet);
        when(recognisingOrganisationRepository.save(organisation)).thenReturn(organisation);
        Contact contact = new Contact();
        contact.setFirstName("Alan");
        updateOrganisationDomainService.onCommand(roDataUpdate);
        verify(statusHistoryRepository, times(1)).save(statusHistoryCapt.capture());
        verify(recognisingOrganisationRepository, times(1)).save(organisationCapt.capture());
    }

    @DisplayName("Record Not Found - Rejected Event")
    @ParameterizedTest
    @MethodSource("provideArgumentsForUpdateOrganisationCommand")
    void whenReceivedInvalidUpdateCommmand_thenRejectedEvent(
            final CMDSHeaderContext uiHeader,
            final RoDataUpdateV1Valid roDataUpdate,
            RecognisingOrganisation organisation)
            throws JsonProcessingException, RbacValidationException, InvocationTargetException, IllegalAccessException {
        roDataUpdate.setOrganisationName("");
        roDataUpdate.setLinkedOrganisations(null);
        when(recognisingOrganisationRepository.findById(
                        UUID.fromString(
                                         uiHeader
                                        .getEventContext()
                                        .get("recognisingOrganisationUuid"))))
                .thenReturn(Optional.of(organisation));
        Set<ConstraintViolation<Object>> violationSet =
                OrganisationTestUtil.getSetforNullViolationOfEventBody("V0004", "name");
        OrganisationType organisationType = CreateOrganisationDataSetup.getOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(organisationTypeRepository.findById(
                roDataUpdate.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        orgType,
                        OrganisationConstants.GenericConstants.UPDATE,
                        ThreadLocalAuditContext.getContext()))
                .thenReturn(new HashSet<>());
        when(updateOrganisationDomainService.validateUpdateRODetails(roDataUpdate))
                .thenReturn(violationSet);
        UiHeader header = orgCommonUtils.buildUiHeader();
        doReturn(header).when(orgCommonUtils)
                .buildUiHeader();
        CMDSErrorResponse cmdsErrorResponse =
                OrganisationTestUtil.getROErrorResponse(
                        "V0004",
                        "Organisation Name is empty",
                        OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT);
        when(errorResolver.populatErrorResponse(
                        violationSet, OrganisationConstants.EventType.RO_UPDATE_REJECTED_EVENT))
                .thenReturn(cmdsErrorResponse);
        updateOrganisationDomainService.onCommand(roDataUpdate);
        // verify DAO Call
        verify(recognisingOrganisationRepository, times(0)).save(organisationCapt.capture());
        verify(errorResolver, times(1))
                .populatErrorResponse(
                        violationSetCapt.capture(),
                        Mockito.eq(OrganisationConstants.EventType.RO_UPDATE_REJECTED_EVENT));
        final BaseAudit audit = orgCommonUtils.getBaseAudit();
        header.setEventName("RoChangeRejected");
        BaseEvent<BaseHeader> event = new BaseEvent<>(header, objectMapper.writeValueAsString(organisation), new BaseEventErrors(cmdsErrorResponse.getErrorList()), audit);
        verify(applicationEventPublisher, times(1)).publishEvent(event);
        assertNotNull(violationSetCapt.getValue().iterator().next().getMessage());
        assertEquals("V0004", violationSetCapt.getValue().iterator().next().getMessage());
    }

    @DisplayName("Organisation Type null- RejectedEvent Test")
    @ParameterizedTest
    @MethodSource("provideArgumentsForUpdateOrganisationCommand")
    void whenReceivedValid_UpdateRoCommand_WithOrganisationTypeNull_thenRejectEvent(
            final CMDSHeaderContext uiHeader,
            final RoDataUpdateV1Valid roDataUpdateV1,
            RecognisingOrganisation organisation)
            throws JsonProcessingException, RbacValidationException {
        roDataUpdateV1.setOrganisationTypeUuid(null);
        when(recognisingOrganisationRepository.findById(
                        UUID.fromString(
                                         uiHeader
                                        .getEventContext()
                                        .get("recognisingOrganisationUuid"))))
                .thenReturn(Optional.of(organisation));
        Set<ConstraintViolation<Object>> constraintViolation =
                orgCommonUtils.getSetforNullViolationOfEventBody("V0001", "organisationTypeUuid");
        CMDSErrorResponse cmdsErrorResponse =
                OrganisationTestUtil.getROErrorResponse(
                        "V0001",
                        "Organisation Type is not valid.",
                        OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT);

        when(errorResolver.populatErrorResponse(constraintViolation, "RoChangeRejected"))
                .thenReturn(cmdsErrorResponse);
        updateOrganisationDomainService.onCommand(roDataUpdateV1);
        verify(errorResolver, times(1))
                .populatErrorResponse(violationSetCapt.capture(), Mockito.eq("RoChangeRejected"));
        assertNotNull(violationSetCapt.getValue().iterator().next().getMessage());
        assertEquals("V0001", violationSetCapt.getValue().iterator().next().getMessage());
    }

    @DisplayName("Unauthorised User - UpdateRO - Rejected Event Test")
    @ParameterizedTest
    @MethodSource("provideArgumentsForUpdateOrganisationCommand")
    void whenReceivedValid_UpdateRoCommand_WithUnauthorisedUser_thenRejectEvent(
            final CMDSHeaderContext uiHeader,
            final RoDataUpdateV1Valid roDataUpdate,
            RecognisingOrganisation organisation)
            throws JsonProcessingException, RbacValidationException {
        when(recognisingOrganisationRepository.findById(
                        UUID.fromString(
                                        uiHeader
                                        .getEventContext()
                                        .get("recognisingOrganisationUuid"))))
                .thenReturn(Optional.of(organisation));
        Set<ConstraintViolation<Object>> constraintViolation =
                orgCommonUtils.getSetforNullViolationOfEventBody("V0046", "UnauthorisedToUpdateRO");
        OrganisationType organisationType = CreateOrganisationDataSetup.getOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(organisationTypeRepository.findById(
                roDataUpdate.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        orgType,
                        OrganisationConstants.GenericConstants.UPDATE,
                        ThreadLocalAuditContext.getContext()))
                .thenReturn(constraintViolation);
        CMDSErrorResponse cmdsErrorResponse =
                OrganisationTestUtil.getROErrorResponse(
                        "V0046",
                        "You do not have permission to update a RO.",
                        OrganisationConstants.EventType.RO_UPDATE_REJECTED_EVENT);

        when(errorResolver.populatErrorResponse(constraintViolation, "RoChangeRejected"))
                .thenReturn(cmdsErrorResponse);
        updateOrganisationDomainService.onCommand(roDataUpdate);
        verify(errorResolver, times(1))
                .populatErrorResponse(violationSetCapt.capture(), Mockito.eq("RoChangeRejected"));
        assertNotNull(violationSetCapt.getValue().iterator().next().getMessage());
        assertEquals("V0046", violationSetCapt.getValue().iterator().next().getMessage());
    }

    @DisplayName("Unauthorised User - UpdateVO - RejectedEvent Test")
    @ParameterizedTest
    @MethodSource("provideArgumentsForUpdateOrganisationCommand")
    void whenReceivedValid_UpdateVoCommand_WithUnauthorisedUser_thenRejectEvent(
            final CMDSHeaderContext uiHeader,
            final RoDataUpdateV1Valid roDataUpdateV1,
            RecognisingOrganisation organisation)
            throws JsonProcessingException, RbacValidationException {

        roDataUpdateV1.setOrganisationTypeUuid(
                UUID.fromString("e392ae7c-016f-433a-bdfa-b79bfcdddf26"));
        organisation.setOrganisationTypeUuid(
                UUID.fromString("e392ae7c-016f-433a-bdfa-b79bfcdddf26"));
        Set<ConstraintViolation<Object>> constraintViolation =
                orgCommonUtils.getSetforNullViolationOfEventBody("V0047", "UnauthorisedToUpdateVO");
        when(recognisingOrganisationRepository.findById(
                        UUID.fromString(
                                        uiHeader
                                        .getEventContext()
                                        .get("recognisingOrganisationUuid"))))
                .thenReturn(Optional.of(organisation));
        OrganisationType organisationType = UpdateOrganisationDataSetup.getVoOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(organisationTypeRepository.findById(organisation.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        orgType,
                        OrganisationConstants.GenericConstants.UPDATE,
                        ThreadLocalAuditContext.getContext()))
                .thenReturn(constraintViolation);
        CMDSErrorResponse cmdsErrorResponse =
                OrganisationTestUtil.getROErrorResponse(
                        "V0047",
                        "You do not have permission to update a VO.",
                        OrganisationConstants.EventType.RO_UPDATE_REJECTED_EVENT);

        when(errorResolver.populatErrorResponse(constraintViolation, "RoChangeRejected"))
                .thenReturn(cmdsErrorResponse);
        updateOrganisationDomainService.onCommand(roDataUpdateV1);
        verify(errorResolver, times(1))
                .populatErrorResponse(violationSetCapt.capture(), Mockito.eq("RoChangeRejected"));
        assertNotNull(violationSetCapt.getValue().iterator().next().getMessage());
        assertEquals("V0047", violationSetCapt.getValue().iterator().next().getMessage());
    }

    @DisplayName("IELTSDisplayFlagNull - Default True")
    @ParameterizedTest
    @MethodSource("provideArgumentsForUpdateOrganisationCommand")
    void whenReceivedValidRO_IELTSDisplayFlagAsNull_Then_setDefault_True(
            final CMDSHeaderContext uiHeader,
            final RoDataUpdateV1Valid roDataUpdateV1,
            RecognisingOrganisation organisation)
            throws JsonProcessingException, RbacValidationException {

        mockReferenceData();
        Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
        roDataUpdateV1.setLinkedOrganisations(null);
        roDataUpdateV1.setIeltsDisplayFlag(null);
        organisation.setLinkedRecognisingOrganisations(new ArrayList<>());
        when(recognisingOrganisationRepository.findById(
                        UUID.fromString(
                                uiHeader
                                        .getEventContext()
                                        .get("recognisingOrganisationUuid"))))
                .thenReturn(Optional.of(organisation));

        when(noteTypeRepository.findByNotesType("Internal"))
                .thenReturn(UpdateOrganisationDataSetup.getNoteTypesData());
        when(recognisingOrganisationRepository.save(organisation)).thenReturn(organisation);
        OrganisationType organisationType = CreateOrganisationDataSetup.getOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(organisationTypeRepository.findById(
                roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        orgType,
                        OrganisationConstants.GenericConstants.UPDATE,
                        ThreadLocalAuditContext.getContext()))
                .thenReturn(violationSet);
        when(updateOrganisationDomainService.validateUpdateRODetails(roDataUpdateV1))
                .thenReturn(violationSet);
        when(statusHistoryRepository.findByRecognisingOrganisationOrderByStatusDatetimeDesc(
                        organisation))
                .thenReturn(UpdateOrganisationDataSetup.getStatusHistoryDetails());
        updateOrganisationDomainService.onCommand(roDataUpdateV1);
        verify(recognisingOrganisationRepository, times(1)).save(organisationCapt.capture());
        assertNotNull(organisationCapt.getValue().getAddresses());
        assertEquals(Boolean.TRUE, organisationCapt.getValue().getIeltsDisplayFlag());
    }
    @DisplayName("ADOs in Hierarchy - UpdateVO - RejectedEvent Test")
    @ParameterizedTest
    @MethodSource("provideArgumentsForUpdateOrganisationCommand")
    void whenReceivedValid_UpdateVoCommand_WithADOsInHierarchy_thenRejectEvent(
            final CMDSHeaderContext uiHeader,
            final RoDataUpdateV1Valid roDataUpdateV1,
            RecognisingOrganisation organisation)
            throws JsonProcessingException, RbacValidationException {

        roDataUpdateV1.setOrganisationTypeUuid(
                UUID.fromString("e392ae7c-016f-433a-bdfa-b79bfcdddf26"));
        organisation.setOrganisationTypeUuid(
                UUID.fromString("e392ae7c-016f-433a-bdfa-b79bfcdddf26"));
        Set<ConstraintViolation<Object>> constraintViolation =
                orgCommonUtils.getSetforNullViolationOfEventBody("V0071", "linkedOrganisations");
        when(recognisingOrganisationRepository.findById(
                UUID.fromString(
                        uiHeader
                                .getEventContext()
                                .get("recognisingOrganisationUuid"))))
                .thenReturn(Optional.of(organisation));
        OrganisationType organisationType = UpdateOrganisationDataSetup.getVoOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(organisationTypeRepository.findById(organisation.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                ThreadLocalHeaderContext.getContext().getXaccessToken(),
                orgType,
                OrganisationConstants.GenericConstants.UPDATE,
                ThreadLocalAuditContext.getContext()))
                .thenReturn(constraintViolation);
        CMDSErrorResponse cmdsErrorResponse =
                OrganisationTestUtil.getROErrorResponse(
                        "V0071",
                        "VOs don't support ADOs",
                        OrganisationConstants.EventType.RO_UPDATE_REJECTED_EVENT);

        when(errorResolver.populatErrorResponse(constraintViolation, "RoChangeRejected"))
                .thenReturn(cmdsErrorResponse);
        updateOrganisationDomainService.onCommand(roDataUpdateV1);
        verify(errorResolver, times(1))
                .populatErrorResponse(violationSetCapt.capture(), Mockito.eq("RoChangeRejected"));
        assertNotNull(violationSetCapt.getValue().iterator().next().getMessage());
        assertEquals("V0071", violationSetCapt.getValue().iterator().next().getMessage());
    }

    private static Stream<Arguments> provideArgumentsForUpdateOrganisationCommand() {

        final RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        CMDSHeaderContext uiHeader = OrganisationTestUtil.generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_UPDATE_REQUEST_EVENT);

        uiHeader.setEventName(OrganisationConstants.GenericConstants.RO_UPDATE_REQUEST_EVENT);
        RecognisingOrganisation organisation =
                UpdateOrganisationDataSetup.getExistingOrganisationDetails(
                        roDataUpdate, new RecognisingOrganisation());

        return Stream.of(Arguments.of(uiHeader, roDataUpdate, organisation));
    }

    private void mockReferenceData() {
        List<Country> countryList = new ArrayList<>();
        countryList.add(CreateOrganisationDataSetup.getTerritoryData().getCountry());
        List<Territory> territoryList = new ArrayList<>();
        territoryList.add(CreateOrganisationDataSetup.getTerritoryData());
        List<SectorType> sectorList = new ArrayList<>();
        sectorList.add(CreateOrganisationDataSetup.getSectorTypeData());
        List<ContactType> contactTypeList = new ArrayList<>();
        contactTypeList.add(CreateOrganisationDataSetup.getContactTypeData());
        List<AddressType> addressTypeList = new ArrayList<>();
        addressTypeList.add(CreateOrganisationDataSetup.getAddressTypeData());
        addressTypeList.add(CreateOrganisationDataSetup.getDeliveryAddressTypeData());
        List<OrganisationType> organisationTypeList = new ArrayList<>();
        organisationTypeList.add(CreateOrganisationDataSetup.getOrganisationTypeData());

        doReturn(countryList).when(countryRepository).findAll();
        doReturn(sectorList).when(sectorTypeRepository).findAll();
        doReturn(territoryList).when(territoryRepository).findAll();
        doReturn(addressTypeList).when(addressTypeRepository).findAll();
        doReturn(organisationTypeList).when(organisationTypeRepository).findAll();
    }
}
