package com.ielts.cmds.organisation.domain.services;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.application.OrganisationPrimmingServiceTestSetup;
import com.ielts.cmds.organisation.cache.factory.JedisFactory;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.organisation.domain.commands.OrganisationPrimmingCommand;
import com.ielts.cmds.organisation.domain.model.RoDataUpdateV1Valid;
import com.ielts.cmds.organisation.domain.utils.DomainEventsPublisher;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.utills.CreateOrganisationDataSetup;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utills.UpdateOrganisationDataSetup;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.mock.mockito.MockBean;

@ExtendWith(MockitoExtension.class)
class OrganisationPrimmingDomainServiceTest {

    @InjectMocks OrganisationPrimmingDomainService orgPrimmingDomainService;

    @Mock OrganisationCommonUtils orgCommonUtils;

    @Mock RecognisingOrganisationRepository orgRepository;

    @Mock private ObjectMapper objectMapper;

    @Mock private DomainEventsPublisher domainEventPublisher;

    @Captor private ArgumentCaptor<List<BaseEvent<BaseHeader>>> eventCaptor;

    @MockBean private JedisFactory jedisFactory;

    @Test
    void whenOnCommand_OrgPrimmingEvent_verifyNoException() throws JsonProcessingException {
        OrganisationPrimmingCommand command =
                OrganisationPrimmingServiceTestSetup.getOrganisationPrimingCommand();
        when(orgRepository.findByRecognisingOrganisationUuidIn(
                        command.getEventBody().getOrganisationsToBePublished()))
                .thenReturn(
                        OrganisationPrimmingServiceTestSetup.getExistingOrganisations(
                                command.getEventBody().getOrganisationsToBePublished()));
        orgPrimmingDomainService.onCommand(command);
        Mockito.verify(domainEventPublisher).baseEventListPublisher(eventCaptor.capture());
        List<BaseEvent<BaseHeader>> listOfEvents = eventCaptor.getValue();
        assertEquals(5, listOfEvents.size());
    }

    @Test
    void whenRequestPayloadNotEmpty_thenVerifyRoChangedEvent() throws JsonProcessingException {
        OrganisationPrimmingCommand command =
                OrganisationPrimmingServiceTestSetup.getOrganisationPrimingCommand();
        final RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        RecognisingOrganisation organisation =
                UpdateOrganisationDataSetup.getExistingOrganisationDetails(
                        roDataUpdate, new RecognisingOrganisation());
        RoChangedEventV1 expectedEvent =
                CreateOrganisationDataSetup.entityToEventMapper(organisation);
        ObjectMapper mapper = new ObjectMapper();
        String expectedResponse = mapper.writeValueAsString(expectedEvent);
        when(orgCommonUtils.entityToEventMapper(organisation)).thenReturn(expectedEvent);
        when(objectMapper.writeValueAsString(expectedEvent)).thenReturn(expectedResponse);

        BaseEvent<BaseHeader> roChanged =
                orgPrimmingDomainService.generateRoChangedEvent(
                        command.getEventHeaders(), null, organisation);

        BaseHeader eventHeader = OrganisationTestUtil.generateEventHeader();
        eventHeader.setEventName(OrganisationConstants.EventType.RO_UPDATED_EVENT);
        eventHeader.setPartnerCode(organisation.getPartnerCode().toString());
        BaseEvent<BaseHeader> expectedRoChangedEvent =
                new BaseEvent<BaseHeader>(eventHeader, expectedResponse, null, null);
        assertEquals(
                OrganisationConstants.EventType.RO_UPDATED_EVENT,
                roChanged.getEventHeader().getEventName());
        assertEquals(
                expectedRoChangedEvent.getEventHeader().getPartnerCode(),
                roChanged.getEventHeader().getPartnerCode());
        assertEquals(
                expectedRoChangedEvent.getEventHeader().getTransactionId(),
                roChanged.getEventHeader().getTransactionId());
        assertEquals(expectedRoChangedEvent.getEventBody(), roChanged.getEventBody());
        assertEquals(expectedRoChangedEvent.getEventErrors(), roChanged.getEventErrors());
    }
}
