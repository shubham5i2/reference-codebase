package com.ielts.cmds.organisation.application;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.roui005rosearchrequested.RoSearchObject;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.domain.services.DuplicateSearchOrganisationDomainService;
import com.ielts.cmds.organisation.domain.services.SearchOrganisationDomainService;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utills.SearchOrganisationDataSetup;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class OrganisationSearchServiceTest {

    @InjectMocks private OrganisationSearchService organisationSearchService;

    @Mock private SearchOrganisationDomainService searchOrganisationDomainService;

    @Mock private DuplicateSearchOrganisationDomainService duplicateSearchOrganisationDomainService;

    @Captor ArgumentCaptor<RoSearchObject> searchROVOCommanCaptor;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        ThreadLocalHeaderContext.setContext(OrganisationTestUtil.generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_SEARCH_REQUEST_EVENT));
        ThreadLocalAuditContext.setContext(OrganisationTestUtil.getBaseAudit());
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForSearchOrganisation")
    void whenValidPayload_thenVerifyDomainCallWithNoException(
            RoSearchObject roSearchObject) throws Exception {
        ThreadLocalHeaderContext.getContext()
                .getEventContext()
                .put("mode", "generic");

        assertDoesNotThrow(() -> organisationSearchService.process(roSearchObject));
        verify(searchOrganisationDomainService, times(1))
                .onCommand(searchROVOCommanCaptor.capture());
        assertNotNull(searchROVOCommanCaptor.getValue());
        assertEquals(roSearchObject, searchROVOCommanCaptor.getValue());
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForSearchOrganisation")
    void whenValidPayload_DuplicateSearch_thenVerifyDomainCallWithNoException(
            RoSearchObject roSearchObject) throws Exception {

        ThreadLocalHeaderContext.getContext()
                .getEventContext()
                .put("mode", OrganisationConstants.GenericConstants.DUPLICATE_SEARCH_MODE);
        assertDoesNotThrow(() -> organisationSearchService.process(roSearchObject));
        verify(duplicateSearchOrganisationDomainService)
                .onCommand(searchROVOCommanCaptor.capture());
        assertNotNull(searchROVOCommanCaptor.getValue());
        assertEquals(roSearchObject, searchROVOCommanCaptor.getValue());
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForSearchOrganisation")
    void whenInValidPayload_thenVerifyForException(
            RoSearchObject roSearchObject)
            throws JsonProcessingException, ProcessingException, RbacValidationException {
        doThrow(RuntimeException.class).when(searchOrganisationDomainService).onCommand(roSearchObject);
        Executable executable = () -> organisationSearchService.process(roSearchObject);
        ProcessingException processingException =
                assertThrows(ProcessingException.class, executable);
        assertTrue(processingException.getCause() instanceof RuntimeException);
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForSearchOrganisation")
    void whenInValidPayload_thenVerifyForJSONException()
             {
         Executable executable = () -> organisationSearchService.process(null);
        ProcessingException processingException =
                assertThrows(ProcessingException.class, executable);
        assertTrue(processingException.getCause() instanceof IllegalArgumentException);
    }

    /*
     * This is method source to provide arguments for the required test cases
     * wherever this method source has been used. It's specific to
     * CreateOrganisation event
     */
    private static Stream<Arguments> argumentsProviderForSearchOrganisation()
             {
        final RoSearchObject roSearchObject = SearchOrganisationDataSetup.getRoSearchData();
        return Stream.of(Arguments.of(roSearchObject));
    }
}
