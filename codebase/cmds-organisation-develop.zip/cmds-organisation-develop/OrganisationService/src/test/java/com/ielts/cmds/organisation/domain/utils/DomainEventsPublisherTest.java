package com.ielts.cmds.organisation.domain.utils;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;

@ExtendWith(MockitoExtension.class)
class DomainEventsPublisherTest {

    @InjectMocks DomainEventsPublisher domainEventsPublisher;

    @Test
    void checkForPositiveFlow() {
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        baseEvent.setEventHeader(OrganisationTestUtil.generateEventHeader());
        baseEvent.setEventBody(null);
        baseEvent.setEventErrors(null);

        BaseEvent<BaseHeader> baseEvent2 = new BaseEvent<>();
        baseEvent2.setEventHeader(OrganisationTestUtil.generateEventHeader());
        baseEvent2.setEventBody(null);
        baseEvent2.setEventErrors(null);

        List<BaseEvent<BaseHeader>> list = new ArrayList<>();
        list.add(baseEvent);
        list.add(baseEvent2);

        domainEventsPublisher.baseEventListPublisher(list);
        assertNotNull(list);
        assertNotNull(list.get(0).getEventHeader());
        assertNull(list.get(0).getEventErrors());
    }
}
