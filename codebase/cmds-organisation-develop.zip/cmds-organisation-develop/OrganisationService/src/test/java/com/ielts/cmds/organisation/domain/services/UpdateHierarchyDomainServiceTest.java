package com.ielts.cmds.organisation.domain.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateLinkedOrganisation;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.domain.model.RoDataUpdateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.OrganisationType;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.LinkedRecognisingOrganisationRepository;
import com.ielts.cmds.organisation.infrastructure.repository.OrganisationTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.utills.CreateOrganisationDataSetup;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utills.UpdateOrganisationDataSetup;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.organisation.utils.UpdateOrganisationUtil;
import com.ielts.cmds.rbac.api.service.RBACService;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.util.ReflectionTestUtils;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import java.util.*;
import java.util.stream.Stream;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@RunWith(MockitoJUnitRunner.class)
class UpdateHierarchyDomainServiceTest {

    @InjectMocks @Spy
    private UpdateOrganisationDomainService updateOrganisationDomainService;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private OrganisationCommonUtils orgCommonUtils;

    @Mock private RecognisingOrganisationRepository recognisingOrganisationRepository;

    @Mock private OrganisationTypeRepository organisationTypeRepository;

    @Mock private UpdateOrganisationUtil updateOrgUtil;

    @Mock private Validator roValidator;

    @Captor private ArgumentCaptor<RecognisingOrganisation> organisationCapt;

    @Mock private CMDSErrorResolver<Object> errorResolver;
    @Captor private ArgumentCaptor<Set<ConstraintViolation<Object>>> violationSetCapt;
    @Mock private ApplicationEventPublisher applicationEventPublisher;
    @Mock private RBACService rbacService;
    @Mock private LinkedRecognisingOrganisationRepository linkedRORepository;

    /** @throws Exception */
    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(
                updateOrganisationDomainService, "orgCommonUtils", orgCommonUtils);

        Map<String, String> eventContext = new HashMap<>();
        eventContext.put("recognisingOrganisationUuid", "5c2e3965-8b90-488f-b5e9-4da8854785cb");
        CMDSHeaderContext headerContext = OrganisationTestUtil
                .generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_DETAILS_REQUEST_EVENT);
        headerContext.setEventContext(eventContext);
        ThreadLocalHeaderContext.setContext(headerContext);
        ThreadLocalAuditContext.setContext(OrganisationTestUtil.getBaseAudit());
    }

    @DisplayName("Valid Command - No Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForUpdateOrganisationCommand")
    void whenReceivedValidChangeParentCommmand_thenNoException(
            final RoDataUpdateV1Valid roDataUpdateV1,
            final RecognisingOrganisation organisation)
            throws JsonProcessingException, RbacValidationException {

        UiHeader header = CreateOrganisationDataSetup
                .getUiHeaderForTest();

        Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
        List<RoDataUpdateLinkedOrganisation> linkedRos =
                roDataUpdateV1.getLinkedOrganisations();
        linkedRos
                .get(0)
                .setLinkedRecognisingOrganisationUuid(
                        UUID.fromString("9170edce-df87-464b-81a5-0df7725ba48c"));
        linkedRos
                .get(0)
                .setTargetRecognisingOrganisationUuid(
                        UUID.fromString("f327b560-02d3-4866-94d9-3922906bc530"));
        organisation
                .getLinkedRecognisingOrganisations()
                .get(0)
                .setLinkedRecognisingOrganisationUuid(
                        UUID.fromString("9170edce-df87-464b-81a5-0df7725ba48c"));

       /* UiHeader header = orgCommonUtils
                .buildUiHeader();*/
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put("recognisingOrganisationUuid", "5c2e3965-8b90-488f-b5e9-4da8854785cb");
        CMDSHeaderContext headerContext = OrganisationTestUtil
                .generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_DETAILS_REQUEST_EVENT);
        headerContext.setEventContext(eventContext);
        ThreadLocalHeaderContext.setContext(headerContext);

        doReturn(header).when(orgCommonUtils).buildUiHeader();

        doReturn(Optional.ofNullable(organisation))
                .when(orgCommonUtils)
                .getOrganisationViewDetails("5c2e3965-8b90-488f-b5e9-4da8854785cb");

        when(recognisingOrganisationRepository.save(organisation)).thenReturn(organisation);
        OrganisationType organisationType = CreateOrganisationDataSetup.getOrganisationTypeData();
        String orgType = organisationType.getOrganisationsType();
        when(organisationTypeRepository.findById(
                roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(organisationType));
        when(orgCommonUtils.checkPermissionForROVO(
                ThreadLocalHeaderContext.getContext().getXaccessToken(),
                orgType,
                OrganisationConstants.GenericConstants.UPDATE,
                ThreadLocalAuditContext.getContext()))
                .thenReturn(violationSet);
        when(updateOrganisationDomainService.validateLinkedOrganisations(
                organisation.getRecognisingOrganisationUuid(),
                roDataUpdateV1.getLinkedOrganisations()))
                .thenReturn(violationSet);
        when(updateOrganisationDomainService.validateUpdateRODetails(roDataUpdateV1))
                .thenReturn(violationSet);
        Map<String, String> hierarchyUpdateMap = new HashMap<>();
        when(updateOrgUtil.populateOrganisation(roDataUpdateV1, organisation, hierarchyUpdateMap))
                .thenReturn(organisation);
        updateOrganisationDomainService.onCommand(roDataUpdateV1);
        verify(recognisingOrganisationRepository, times(1)).save(organisationCapt.capture());
    }

    private static Stream<Arguments> provideArgumentsForUpdateOrganisationCommand() {

        final RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setRecognisingOrganisationUuid(UUID.fromString("5c2e3965-8b90-488f-b5e9-4da8854785cb"));
        RecognisingOrganisation organisation =
                UpdateOrganisationDataSetup.getExistingOrganisationDetails(
                        roDataUpdate, new RecognisingOrganisation());

        return Stream.of(Arguments.of(roDataUpdate, organisation));
    }
}
