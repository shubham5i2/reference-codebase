package com.ielts.cmds.organisation.domain.services;

import com.ielts.cmds.api.roui009roupdaterequested.VerificationStatusEnum;
import com.ielts.cmds.api.roui009roupdaterequested.OrganisationStatusEnum;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.cache.JedisGenericReader;
import com.ielts.cmds.organisation.cache.factory.JedisFactory;
import com.ielts.cmds.organisation.domain.model.RoDataCreateV1Valid;
import com.ielts.cmds.organisation.domain.model.RoDataUpdateV1Valid;
import com.ielts.cmds.organisation.infrastructure.config.RBACTestConfig;
import com.ielts.cmds.organisation.infrastructure.entity.*;
import com.ielts.cmds.organisation.infrastructure.repository.LinkedRecognisingOrganisationRepository;
import com.ielts.cmds.organisation.infrastructure.repository.OrganisationTypeRepository;
import com.ielts.cmds.organisation.cache.entity.Product;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.infrastructure.repository.StatusHistoryRepository;
import com.ielts.cmds.organisation.utills.CreateOrganisationDataSetup;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utills.UpdateOrganisationDataSetup;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.organisation.utils.UpdateOrganisationUtil;
import com.ielts.cmds.rbac.api.service.RBACService;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.implementation.impl.LocationHierarchyServiceImpl;
import com.ielts.cmds.rbac.implementation.impl.UserGroupServiceImpl;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

import javax.transaction.Transactional;
import java.io.IOException;
import java.sql.SQLException;
import java.time.OffsetDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = RBACTestConfig.class)
@ActiveProfiles("test")
@Sql({
    "/sql/schema.sql",
    "/sql/organisation-type-data.sql",
    "/sql/partner-data.sql",
    "/sql/address-type-data.sql",
    "/sql/sector-type-data.sql",
    "/sql/note-type-data.sql",
    "/sql/product-data.sql",
    "/sql/contact-type-data.sql",
    "/sql/country-data.sql",
    "/sql/territory-data.sql",
    "/sql/module-type-data.sql",
    "/sql/usergroup-hierarchy.sql",
    "/sql/existing-ro-data.sql",
    "/sql/existing-vo-data.sql",
    "/sql/sample-hierarchy-data.sql",
    "/sql/ro-hierarchy-data.sql",
    "/sql/linked-recognising-organisation-data.sql"
})
@Transactional
class UpdateOrganisationDomainServiceIntegrationTest {

    @Autowired private CMDSThreadLocalContextService cmdsThreadLocalContextService;

    @Autowired private RecognisingOrganisationRepository recognisingOrgRepository;

    @Autowired private StatusHistoryRepository statusHistoryRepository;

    @Autowired private OrganisationCommonUtils organisationCommonUtils;

    @Spy private UpdateOrganisationUtil updateOrganisationUtil;

    @Autowired UpdateOrganisationDomainService updateOrganisationDomainService;

    @MockBean private ApplicationEventPublisher applicationEventPublisher;

    @Captor ArgumentCaptor<BaseEvent<BaseHeader>> publishedEventCaptor;

    @Autowired private LinkedRecognisingOrganisationRepository linkedRORepository;

    @Autowired private RBACService rbacService;
    @Autowired private UserGroupServiceImpl userGroupServiceImpl;
    @Autowired private LocationHierarchyServiceImpl locationHierarchyServiceImpl;
    @Autowired private OrganisationTypeRepository organisationTypeRepository;
    @MockBean private JedisGenericReader jedisGenericReader;
    @MockBean private JedisFactory jedisFactory;

    @BeforeEach
    void setup() throws RbacValidationException {
        userGroupServiceImpl.populateUserGroupHierarchyData();
        locationHierarchyServiceImpl.populateRootData();
        ReflectionTestUtils.setField(
                updateOrganisationDomainService,
                "applicationEventPublisher",
                applicationEventPublisher);
        ReflectionTestUtils.setField(
                organisationCommonUtils, "orgRepository", recognisingOrgRepository);
        ReflectionTestUtils.setField(
                organisationCommonUtils,
                "linkedRecognisingOrganisationRepository",
                linkedRORepository);
        ReflectionTestUtils.setField(
                organisationCommonUtils, "organisationTypeRepository", organisationTypeRepository);
        ReflectionTestUtils.setField(
                organisationCommonUtils, "applicationEventPublisher", applicationEventPublisher);
        ThreadLocalHeaderContext.setContext(OrganisationTestUtil.generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_UPDATE_REQUEST_EVENT));
        ThreadLocalAuditContext.setContext(OrganisationTestUtil.getBaseAudit());
        ReflectionTestUtils.setField(
                organisationCommonUtils, "jedisGenericReader", jedisGenericReader);
   }

    @Test
    final void testUpdateOrganisation() throws IOException {

        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);
        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setAcceptsIOL(false);
        roDataUpdate.setAcceptsAC(true);
        roDataUpdate.setAcceptsGT(false);
        roDataUpdate.setContacts(UpdateOrganisationDataSetup.getContactsDataForIntegrationTest());
        roDataUpdate.setPartnerContact("Partner Contact");
        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));
        Optional<RecognisingOrganisation> recognisingOrganisation =
                recognisingOrgRepository.findByRecognisingOrganisationUuid(
                        UUID.fromString("88e18cae-1bdd-45a7-be1c-0a37926f9bbe"));
        assertAll(
                "Organisation",
                () ->
                        assertEquals(
                                recognisingOrganisation.get().getName(),
                                roDataUpdate.getOrganisationName()),
                () ->
                        assertEquals(
                                VerificationStatusEnum.APPROVED.getValue(),
                                recognisingOrganisation.get().getVerificationStatus().getValue()),
                () ->
                        assertEquals(
                                recognisingOrganisation.get().getPartnerCode(),
                                roDataUpdate.getPartnerCode()),
                () ->
                        assertEquals(
                                OrganisationStatusEnum.ACTIVE.getValue(),
                                recognisingOrganisation.get().getOrgStatus().getValue()),
                () ->
                        assertEquals(
                                recognisingOrganisation.get().getResultAvailableForYears(),
                                roDataUpdate.getResultAvailableForYears()));

        List<Address> savedAddresses = recognisingOrganisation.get().getAddresses();
        assertEquals(2, savedAddresses.stream().count());

        List<RoNote> savedNotes = recognisingOrganisation.get().getNotes();
        assertEquals(2, savedNotes.stream().count());

        List<AlternateName> savedAltNames = recognisingOrganisation.get().getAlternateNames();
        assertEquals(2, savedAltNames.stream().count());

        List<Contact> savedContacts = recognisingOrganisation.get().getContacts();
        assertEquals(2, savedContacts.stream().count());
        assertEquals("update results admin", savedContacts.get(1).getFirstName());
        assertEquals("update primary", savedContacts.get(0).getFirstName());

        List<Address> primaryContactAddress = savedContacts.get(0).getAddresses();
        assertEquals(1, primaryContactAddress.stream().count());

        List<Address> resultsAdminContactAddress = savedContacts.get(0).getAddresses();
        assertEquals(1, resultsAdminContactAddress.stream().count());

        List<MinimumScore> savedMinimumScores = recognisingOrganisation.get().getMinimumScores();
        assertEquals(2, savedMinimumScores.stream().count());

        List<RecognisedProduct> savedProducts =
                recognisingOrganisation.get().getRecognisedProducts().stream()
                        .filter(
                                product ->
                                        product.getEffectiveToDatetime()
                                                .isAfter(OffsetDateTime.now()))
                        .collect(Collectors.toList());
        assertEquals(0, savedProducts.stream().count()); // IOC products as IOL is set to false

        List<StatusHistory> statusHistoryDetails =
                statusHistoryRepository.findByRecognisingOrganisationOrderByStatusDatetimeDesc(
                        recognisingOrganisation.get());
        assertEquals(1, statusHistoryDetails.stream().count());
    }
    @Test
    final void test_verifiedRO_EmptyFirstName_LastName_EmailUpdateOrganisation() throws IOException {

        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);
        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setAcceptsIOL(true);
        roDataUpdate.setContacts(UpdateOrganisationDataSetup.getContactsDataForIntegrationTest());
        roDataUpdate.setPartnerContact("Partner Contact");
        roDataUpdate.setVerificationStatus(VerificationStatusEnum.VERIFIED);
        roDataUpdate.getContacts().get(1).setFirstName(null);
        roDataUpdate.getContacts().get(1).setLastName(null);
        roDataUpdate.getContacts().get(1).getAddresses().get(0).setEmail(null);
        List<Product> products = CreateOrganisationDataSetup.getproductDataWithCharacteristics();
        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));
        Optional<RecognisingOrganisation> recognisingOrganisation =
                recognisingOrgRepository.findByRecognisingOrganisationUuid(
                        UUID.fromString("88e18cae-1bdd-45a7-be1c-0a37926f9bbe"));

        assertEquals( VerificationStatusEnum.VERIFIED.getValue(), recognisingOrganisation.get().getVerificationStatus().getValue());

        List<Address> savedAddresses = recognisingOrganisation.get().getAddresses();
        assertEquals(2, savedAddresses.stream().count());

        List<Contact> savedContacts = recognisingOrganisation.get().getContacts();
        assertEquals(2, savedContacts.stream().count());
        assertEquals(null, savedContacts.get(1).getFirstName());
        assertEquals("update primary", savedContacts.get(0).getFirstName());

        List<Address> primaryContactAddress = savedContacts.get(0).getAddresses();
        assertEquals(1, primaryContactAddress.stream().count());

        List<Address> resultsAdminContactAddress = savedContacts.get(1).getAddresses();
        assertEquals(1, resultsAdminContactAddress.stream().count());
        assertEquals(null, resultsAdminContactAddress.get(0).getEmail());
    }

    @Test
    void testUnauthorisedUserRejectedEvent() throws IOException, RbacValidationException {

        String unauthorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("test-admin-support-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(unauthorisedAccessTokenToUpdate);
        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setContacts(UpdateOrganisationDataSetup.getContactsDataForIntegrationTest());
        roDataUpdate.setPartnerContact("Partner Contact");
        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));
        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        assertFalse(rbacService.isAuthorised(unauthorisedAccessTokenToUpdate, "RO_ORG_UPDATE"));
        BaseHeader header = publishedEventCaptor.getValue().getEventHeader();
        assertEquals("RoChangeRejected", header.getEventName());
    }

    @Test
    void testUpdateOrganisationWithDuplicateNameRejectOrganisation()
            throws IOException, RbacValidationException {

        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);

        RoDataCreateV1Valid roDataCreate = CreateOrganisationDataSetup.createOrgData();
        roDataCreate.setOrganisationName("Arizona State University");
        roDataCreate.setPartnerContact("");
        roDataCreate.setNotes(null);
        roDataCreate.setAlternateNames(null);
        roDataCreate.setMinimumScores(null);
        roDataCreate.setLinkedOrganisations(null);
        UiHeader uiHeaderForCreate = OrganisationTestUtil.generateEventHeader();
        uiHeaderForCreate.setEventName(
                OrganisationConstants.GenericConstants.OPERATION_TYPE_POST
                        + OrganisationConstants.EventType.RO_CREATED_EVENT);
        uiHeaderForCreate.setXaccessToken(authorisedAccessTokenToUpdate);
        recognisingOrgRepository.save(
                organisationCommonUtils.populateOrganisation(
                        roDataCreate, new RecognisingOrganisation()));

        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setOrganisationName("Arizona State University");
        roDataUpdate.setContacts(UpdateOrganisationDataSetup.getContactsDataForIntegrationTest());
        roDataUpdate.setPartnerContact("Partner Contact");
        ThreadLocalHeaderContext.getContext().setEventName(OrganisationConstants.GenericConstants.OPERATION_TYPE_PUT
                + OrganisationConstants.EventType.RO_UPDATED_EVENT);
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);
        updateOrganisationDomainService.onCommand(roDataUpdate);

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        assertEquals(
                OrganisationConstants.EventType.RO_UPDATE_REJECTED_EVENT,
                event.getEventHeader().getEventName());
        assertEquals(1, event.getEventErrors().getErrorList().size());
        assertEquals("V0048", event.getEventErrors().getErrorList().get(0).getErrorCode());
    }

    @Test
    void testUpdateInActiveOrganisation_whenVerficationStatusChangedFromApprovedToVerfication()
            throws IOException, RbacValidationException {

        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);

        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setRecognisingOrganisationUuid(UUID.fromString("0b30c635-80df-49a3-beed-f1752f8bde3c"));
        roDataUpdate.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.VERIFIED.getValue()));
        roDataUpdate.setContacts(UpdateOrganisationDataSetup.getContactsDataForIntegrationTest());
        roDataUpdate.setPartnerContact("Partner Contact");
        ThreadLocalHeaderContext.getContext().setEventName(OrganisationConstants.GenericConstants.OPERATION_TYPE_PUT
                + OrganisationConstants.EventType.RO_UPDATED_EVENT);
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);
        updateOrganisationDomainService.onCommand(roDataUpdate);

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        assertEquals(
                OrganisationConstants.EventType.RO_UPDATE_REJECTED_EVENT,
                event.getEventHeader().getEventName());
        assertEquals(1, event.getEventErrors().getErrorList().size());
        assertEquals("V0069", event.getEventErrors().getErrorList().get(0).getErrorCode());
    }

    @Test
    void testUpdateInActiveOrganisationWithNonLinkedOrganisation_whenVerficationStatusChangedFromApprovedToVerfication()
            throws IOException, RbacValidationException {

        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);

        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setRecognisingOrganisationUuid(UUID.fromString("63c5b3e3-d8e6-4db4-a07e-394cdfd9095b"));
        roDataUpdate.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.VERIFIED.getValue()));
        roDataUpdate.setContacts(UpdateOrganisationDataSetup.getContactsDataForIntegrationTest());
        roDataUpdate.setPartnerContact("Partner Contact");
        ThreadLocalHeaderContext.getContext().setEventName(OrganisationConstants.GenericConstants.OPERATION_TYPE_PUT
                + OrganisationConstants.EventType.RO_UPDATED_EVENT);
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);
        updateOrganisationDomainService.onCommand(roDataUpdate);

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        assertEquals("RoChanged",event.getEventHeader().getEventName());
    }


    @Test
    final void testSaveOrganisationWhenPrimaryEmailDuplicateAndAdminEmailUnique()
            throws IOException, RbacValidationException {

        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);
        RoDataCreateV1Valid roDataCreate = CreateOrganisationDataSetup.createOrgData();
        roDataCreate.setPartnerContact("");
        roDataCreate.setNotes(null);
        roDataCreate.setAlternateNames(null);
        roDataCreate.setMinimumScores(null);
        roDataCreate.getContacts().get(0).getAddresses().get(0).setEmail("alan@gmail.com");
        roDataCreate.getContacts().get(0).getAddresses().get(1).setEmail("alan@gmail.com");
        ThreadLocalHeaderContext.getContext().setEventName(OrganisationConstants.EventType.RO_CREATED_EVENT);
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);
        recognisingOrgRepository.save(
                organisationCommonUtils.populateOrganisation(
                        roDataCreate, new RecognisingOrganisation()));
        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setOrganisationName("Arizona State University");
        roDataUpdate.getContacts().get(1).getAddresses().get(0).setEmail("lucas@gmail.com");
        roDataUpdate.getContacts().get(1).getAddresses().get(1).setEmail("lucas@gmail.com");

        updateOrganisationDomainService.onCommand(roDataUpdate);
        RecognisingOrganisation recognisingOrganisation =
                recognisingOrgRepository.findByName("Arizona State University");
        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        assertEquals(
                OrganisationConstants.EventType.RO_UPDATED_EVENT,
                event.getEventHeader().getEventName());
        assertAll(
                "RoUpdated",
                () ->
                        assertEquals(
                                recognisingOrganisation.getName(),
                                roDataUpdate.getOrganisationName()),
                () ->
                        assertEquals(
                                recognisingOrganisation.getVerificationStatus().getValue(),
                                roDataUpdate.getVerificationStatus().getValue()),
                () ->
                        assertEquals(
                                recognisingOrganisation.getPartnerCode(),
                                roDataUpdate.getPartnerCode()),
                () ->
                        assertEquals(
                                recognisingOrganisation.getOrganisationCode(),
                                roDataUpdate.getOrganisationCode()));
    }

    @Test
    void testUpdateOrganisationWithDuplicateEmailRejectOrganisation()
            throws IOException, RbacValidationException {

        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);
        RoDataCreateV1Valid roDataCreate = CreateOrganisationDataSetup.createOrgData();
        roDataCreate.setOrganisationName("Arizona State University");
        roDataCreate.setPartnerContact("");
        roDataCreate.setNotes(null);
        roDataCreate.setAlternateNames(null);
        roDataCreate.setMinimumScores(null);
        recognisingOrgRepository.save(
                organisationCommonUtils.populateOrganisation(
                        roDataCreate, new RecognisingOrganisation()));

        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate
                .getContacts()
                .get(0)
                .getAddresses()
                .get(0)
                .setEmail("alan_2021@cambridgeassessment.org.uk");
        roDataUpdate
                .getContacts()
                .get(1)
                .getAddresses()
                .get(0)
                .setEmail("alan_2021@cambridgeassessment.org.uk");
        roDataUpdate
                .getContacts()
                .get(0)
                .getAddresses()
                .get(1)
                .setEmail("alan_2021@cambridgeassessment.org.uk");
        roDataUpdate
                .getContacts()
                .get(1)
                .getAddresses()
                .get(1)
                .setEmail("alan_2021@cambridgeassessment.org.uk");
        roDataUpdate.setPartnerContact("Partner Contact");

        updateOrganisationDomainService.onCommand(roDataUpdate);

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        assertEquals(
                OrganisationConstants.EventType.RO_UPDATE_REJECTED_EVENT,
                event.getEventHeader().getEventName());
        assertEquals(1, event.getEventErrors().getErrorList().size());
        assertEquals("V0055", event.getEventErrors().getErrorList().get(0).getErrorCode());
    }

    @Test
    void testEventDiscriminatorInHeadersWhilePublishingROToLA() throws IOException {
        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);
        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setContacts(UpdateOrganisationDataSetup.getContactsDataForIntegrationTest());
        roDataUpdate.setPartnerContact("Partner Contact");

        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));
        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        BaseHeader header = event.getEventHeader();
        assertAll(
                "Headers",
                () ->
                        assertEquals(
                                OrganisationConstants.EventType.RO_UPDATED_EVENT,
                                header.getEventName()),
                () -> assertEquals("ROApproved", header.getEventDiscriminator()));
    }

    @Test
    void testEventDiscriminatorInHeadersWhilePublishingROToORS() throws IOException {
        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);
        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setContacts(UpdateOrganisationDataSetup.getContactsDataForIntegrationTest());
        roDataUpdate.setPartnerContact("Partner Contact");
        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));
        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        BaseHeader header = event.getEventHeader();
        assertAll(
                "Headers",
                () ->
                        assertEquals(
                                OrganisationConstants.EventType.RO_UPDATED_EVENT,
                                header.getEventName()),
                () -> assertEquals("ROApproved", header.getEventDiscriminator()),
                () -> assertEquals("IDP", header.getPartnerCode()));
    }

    @Test
    final void testEventDiscriminatorWhenVerificationStatusUpdatedFromApproved()
            throws IOException {

        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);
        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setRecognisingOrganisationUuid(
                UUID.fromString("9a2b038b-6784-4f31-ab16-a76b30c38d1b"));
        roDataUpdate.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.PENDING.getValue()));
        UiHeader uiHeader = OrganisationTestUtil.generateEventHeader();
        Map<String, String> eventContext = new HashMap<String, String>();
        eventContext.put("recognisingOrganisationUuid", "9a2b038b-6784-4f31-ab16-a76b30c38d1b");
        ThreadLocalHeaderContext.getContext().setEventContext(eventContext);
        ThreadLocalHeaderContext.getContext().setEventName(OrganisationConstants.GenericConstants.OPERATION_TYPE_PUT
                + OrganisationConstants.EventType.RO_UPDATED_EVENT);
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);
        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));
        Optional<RecognisingOrganisation> recognisingOrganisation =
                recognisingOrgRepository.findByRecognisingOrganisationUuid(
                        UUID.fromString("9a2b038b-6784-4f31-ab16-a76b30c38d1b"));
        verify(applicationEventPublisher, times(1)).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        BaseHeader header = event.getEventHeader();
        assertAll(
                "Organisation",
                () ->
                        assertEquals(
                                recognisingOrganisation.get().getName(),
                                roDataUpdate.getOrganisationName()),
                () ->
                        assertEquals(
                                VerificationStatusEnum.PENDING.getValue(),
                                recognisingOrganisation.get().getVerificationStatus().getValue()));

        List<StatusHistory> statusHistoryDetails =
                statusHistoryRepository.findByRecognisingOrganisationOrderByStatusDatetimeDesc(
                        recognisingOrganisation.get());
        assertEquals(1, statusHistoryDetails.stream().count());
        assertEquals("ROApproved", header.getEventDiscriminator());
        ThreadLocalHeaderContext.getContext().setEventDiscriminator(null);
        RoDataUpdateV1Valid roDataUpdate1 = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate1.setRecognisingOrganisationUuid(
                UUID.fromString("9a2b038b-6784-4f31-ab16-a76b30c38d1b"));
        roDataUpdate1.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.REJECTED.getValue()));
        roDataUpdate1.setLinkedOrganisations(null);

        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate1));
        Optional<RecognisingOrganisation> recognisingOrganisation1 =
                recognisingOrgRepository.findByRecognisingOrganisationUuid(
                        UUID.fromString("9a2b038b-6784-4f31-ab16-a76b30c38d1b"));
        verify(applicationEventPublisher, times(2)).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event1 = publishedEventCaptor.getValue();
        BaseHeader header1 = event1.getEventHeader();
        assertEquals(
                VerificationStatusEnum.REJECTED.getValue(),
                recognisingOrganisation1.get().getVerificationStatus().getValue());
        List<StatusHistory> statusHistoryDetails1 =
                statusHistoryRepository.findByRecognisingOrganisationOrderByStatusDatetimeDesc(
                        recognisingOrganisation1.get());
        assertEquals(2, statusHistoryDetails1.stream().count());
        assertEquals(null, header1.getEventDiscriminator());
    }

    @Test
    final void testUpdateVerifiedOrganisation() throws IOException {

        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");

        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setLinkedOrganisations(null);
        roDataUpdate.setAcceptsAC(true);
        roDataUpdate.setAcceptsGT(true);
        roDataUpdate.setRecognisingOrganisationUuid(
                UUID.fromString("f00a3502-bb69-4f85-a606-0bdb621e3a90"));
        roDataUpdate.setOrganisationTypeUuid(
                UUID.fromString("e392ae7c-016f-433a-bdfa-b79bfcdddf26"));
        roDataUpdate.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.VERIFIED.getValue()));
        roDataUpdate.setContacts(UpdateOrganisationDataSetup.getContactsDataForIntegrationTest());
        ThreadLocalHeaderContext.getContext().setEventName(OrganisationConstants.EventType.RO_UPDATED_EVENT);
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);

        Map<String, String> eventContext = new HashMap<>();
        eventContext.put("recognisingOrganisationUuid", "f00a3502-bb69-4f85-a606-0bdb621e3a90");
        ThreadLocalHeaderContext.getContext().setEventContext(eventContext);

        List<Product> products = CreateOrganisationDataSetup.getproductDataWithCharacteristics();
        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));
        Optional<RecognisingOrganisation> recognisingOrganisation =
                recognisingOrgRepository.findByRecognisingOrganisationUuid(
                        UUID.fromString("f00a3502-bb69-4f85-a606-0bdb621e3a90"));
        assertAll(
                "Organisation",
                () ->
                        assertEquals(
                                recognisingOrganisation.get().getName(),
                                roDataUpdate.getOrganisationName()),
                () ->
                        assertEquals(
                                VerificationStatusEnum.VERIFIED.getValue(),
                                recognisingOrganisation.get().getVerificationStatus().getValue()),
                () ->
                        assertEquals(
                                recognisingOrganisation.get().getPartnerCode(),
                                roDataUpdate.getPartnerCode()),
                () ->
                        assertEquals(
                                OrganisationStatusEnum.ACTIVE.getValue(),
                                recognisingOrganisation.get().getOrgStatus().getValue()),
                () ->
                        assertEquals(
                                recognisingOrganisation.get().getResultAvailableForYears(),
                                roDataUpdate.getResultAvailableForYears()));

        List<Address> savedAddresses = recognisingOrganisation.get().getAddresses();
        assertEquals(2, savedAddresses.stream().count());

        List<RoNote> savedNotes = recognisingOrganisation.get().getNotes();
        assertEquals(2, savedNotes.stream().count());

        List<AlternateName> savedAltNames = recognisingOrganisation.get().getAlternateNames();
        assertEquals(2, savedAltNames.stream().count());

        List<Contact> savedContacts = recognisingOrganisation.get().getContacts();
        assertEquals(2, savedContacts.stream().count());

        List<Address> primaryContactAddress = savedContacts.get(0).getAddresses();
        assertEquals(1, primaryContactAddress.stream().count());

        List<Address> resultsAdminContactAddress = savedContacts.get(0).getAddresses();
        assertEquals(1, resultsAdminContactAddress.stream().count());

        List<MinimumScore> savedMinimumScores = recognisingOrganisation.get().getMinimumScores();
        assertEquals(2, savedMinimumScores.stream().count());

        List<RecognisedProduct> savedProducts =
                recognisingOrganisation.get().getRecognisedProducts();
        assertEquals(0, savedProducts.stream().count());
    }

    @Test
    void testEventDiscriminatorInHeadersWhilePublishingVOToORS() throws IOException {
        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);
        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setLinkedOrganisations(null);
        roDataUpdate.setOrganisationTypeUuid(
                UUID.fromString("e392ae7c-016f-433a-bdfa-b79bfcdddf26")); // VO organisationTypeUuid
        roDataUpdate.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.VERIFIED.getValue()));
        ThreadLocalHeaderContext.getContext().setEventName(OrganisationConstants.GenericConstants.OPERATION_TYPE_PUT
                +OrganisationConstants.EventType.RO_UPDATED_EVENT);

        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));
        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        BaseHeader header = event.getEventHeader();
        assertAll(
                "Headers",
                () ->
                        assertEquals(
                                OrganisationConstants.EventType.RO_UPDATED_EVENT,
                                header.getEventName()),
                () -> assertEquals("VOVerified", header.getEventDiscriminator()),
                () -> assertEquals("IDP", header.getPartnerCode()));
    }

    @Test
    final void testEventDiscriminatorWhenVerificationStatusUpdatedFromVerified()
            throws IOException {

        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");

        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setLinkedOrganisations(null);
        roDataUpdate.setOrganisationTypeUuid(
                UUID.fromString("e392ae7c-016f-433a-bdfa-b79bfcdddf26"));
        roDataUpdate.setRecognisingOrganisationUuid(
                UUID.fromString("d303bc54-d13b-4252-aae6-486cf5a4f1f6"));

        roDataUpdate.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.PENDING.getValue()));
        UiHeader uiHeader = OrganisationTestUtil.generateEventHeader();
        Map<String, String> eventContext = new HashMap<String, String>();
        eventContext.put("recognisingOrganisationUuid", "d303bc54-d13b-4252-aae6-486cf5a4f1f6");
        ThreadLocalHeaderContext.getContext().setEventContext(eventContext);
        ThreadLocalHeaderContext.getContext().setEventName(OrganisationConstants.GenericConstants.OPERATION_TYPE_PUT
                + OrganisationConstants.EventType.RO_UPDATED_EVENT);
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);
        List<Product> products = CreateOrganisationDataSetup.getproductDataWithCharacteristics();
        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));
        Optional<RecognisingOrganisation> recognisingOrganisation =
                recognisingOrgRepository.findByRecognisingOrganisationUuid(
                        UUID.fromString("d303bc54-d13b-4252-aae6-486cf5a4f1f6"));
        verify(applicationEventPublisher, times(1)).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        BaseHeader header = event.getEventHeader();
        assertAll(
                "Organisation",
                () ->
                        assertEquals(
                                recognisingOrganisation.get().getName(),
                                roDataUpdate.getOrganisationName()),
                () ->
                        assertEquals(
                                VerificationStatusEnum.PENDING.getValue(),
                                recognisingOrganisation.get().getVerificationStatus().getValue()));

        List<StatusHistory> statusHistoryDetails =
                statusHistoryRepository.findByRecognisingOrganisationOrderByStatusDatetimeDesc(
                        recognisingOrganisation.get());
        assertEquals(1, statusHistoryDetails.stream().count());
        assertEquals("VOVerified", header.getEventDiscriminator());
        ThreadLocalHeaderContext.getContext().setEventDiscriminator(null);
        RoDataUpdateV1Valid roDataUpdate1 = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate1.setRecognisingOrganisationUuid(
                UUID.fromString("d303bc54-d13b-4252-aae6-486cf5a4f1f6"));
        roDataUpdate1.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.REJECTED.getValue()));
        roDataUpdate1.setLinkedOrganisations(null);

         assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate1));
        Optional<RecognisingOrganisation> recognisingOrganisation1 =
                recognisingOrgRepository.findByRecognisingOrganisationUuid(
                        UUID.fromString("d303bc54-d13b-4252-aae6-486cf5a4f1f6"));
        assertEquals(
                VerificationStatusEnum.REJECTED.getValue(),
                recognisingOrganisation1.get().getVerificationStatus().getValue());
        verify(applicationEventPublisher, times(2)).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event1 = publishedEventCaptor.getValue();
        BaseHeader header1 = event1.getEventHeader();
        List<StatusHistory> statusHistoryDetails1 =
                statusHistoryRepository.findByRecognisingOrganisationOrderByStatusDatetimeDesc(
                        recognisingOrganisation1.get());
        assertEquals(2, statusHistoryDetails1.stream().count());
        assertEquals(null, header1.getEventDiscriminator());
    }

    @Test
    final void testEventDiscriminatorWhenApprovedROisUpdatedToVerifiedVO()
            throws IOException {

        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");

        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setOrganisationTypeUuid(
                UUID.fromString("e392ae7c-016f-433a-bdfa-b79bfcdddf26")); // VO OrganisationTypeUuid
        roDataUpdate.setRecognisingOrganisationUuid(
                UUID.fromString("705fc839-5051-4a22-a77d-cf6d734d7d24"));

        roDataUpdate.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.VERIFIED.getValue()));
        roDataUpdate.setLinkedOrganisations(null);
         Map<String, String> eventContext = new HashMap<String, String>();
        eventContext.put("recognisingOrganisationUuid", "705fc839-5051-4a22-a77d-cf6d734d7d24");
        ThreadLocalHeaderContext.getContext().setEventContext(eventContext);
        ThreadLocalHeaderContext.getContext().setEventName(OrganisationConstants.EventType.RO_UPDATED_EVENT);
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);
        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));
        Optional<RecognisingOrganisation> recognisingOrganisation =
                recognisingOrgRepository.findByRecognisingOrganisationUuid(
                        UUID.fromString("705fc839-5051-4a22-a77d-cf6d734d7d24"));
        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        BaseHeader header = event.getEventHeader();
        assertAll(
                "Organisation",
                () ->
                        assertEquals(
                                recognisingOrganisation.get().getName(),
                                roDataUpdate.getOrganisationName()),
                () ->
                        assertEquals(
                                VerificationStatusEnum.VERIFIED.getValue(),
                                recognisingOrganisation.get().getVerificationStatus().getValue()));

        List<StatusHistory> statusHistoryDetails =
                statusHistoryRepository.findByRecognisingOrganisationOrderByStatusDatetimeDesc(
                        recognisingOrganisation.get());
        assertEquals(1, statusHistoryDetails.stream().count());
        assertEquals("VOVerified", header.getEventDiscriminator());
    }

    @Test
    final void testEventDiscriminatorWhenVerifiedVOisUpdatedToApprovedRO()
            throws SQLException, IOException {

        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");

        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setRecognisingOrganisationUuid(
                UUID.fromString("d303bc54-d13b-4252-aae6-486cf5a4f1f6"));

        roDataUpdate.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.APPROVED.getValue()));
        UiHeader uiHeader = OrganisationTestUtil.generateEventHeader();
        Map<String, String> eventContext = new HashMap<String, String>();
        eventContext.put("recognisingOrganisationUuid", "d303bc54-d13b-4252-aae6-486cf5a4f1f6");

        ThreadLocalHeaderContext.getContext().setEventContext(eventContext);
        ThreadLocalHeaderContext.getContext().setEventName(OrganisationConstants.EventType.RO_UPDATED_EVENT);
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);
        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));
        Optional<RecognisingOrganisation> recognisingOrganisation =
                recognisingOrgRepository.findByRecognisingOrganisationUuid(
                        UUID.fromString("d303bc54-d13b-4252-aae6-486cf5a4f1f6"));
        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        BaseHeader header = event.getEventHeader();
        assertAll(
                "Organisation",
                () ->
                        assertEquals(
                                recognisingOrganisation.get().getName(),
                                roDataUpdate.getOrganisationName()),
                () ->
                        assertEquals(
                                VerificationStatusEnum.APPROVED.getValue(),
                                recognisingOrganisation.get().getVerificationStatus().getValue()));

        List<StatusHistory> statusHistoryDetails =
                statusHistoryRepository.findByRecognisingOrganisationOrderByStatusDatetimeDesc(
                        recognisingOrganisation.get());
        assertEquals(1, statusHistoryDetails.stream().count());
        assertEquals("ROApproved", header.getEventDiscriminator());
    }

    @Test
    final void testEventDiscriminatorWhenApprovedROisUpdatedToPendingorRejectedVO()
            throws IOException {

        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");

        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setOrganisationTypeUuid(
                UUID.fromString("e392ae7c-016f-433a-bdfa-b79bfcdddf26")); // VO OrganisationTypeUuid
        roDataUpdate.setRecognisingOrganisationUuid(
                UUID.fromString("705fc839-5051-4a22-a77d-cf6d734d7d24")); // Approved RO

        roDataUpdate.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.PENDING.getValue()));
        roDataUpdate.setLinkedOrganisations(null);
        Map<String, String> eventContext = new HashMap<String, String>();
        eventContext.put("recognisingOrganisationUuid", "705fc839-5051-4a22-a77d-cf6d734d7d24");
        ThreadLocalHeaderContext.getContext().setEventContext(eventContext);
        ThreadLocalHeaderContext.getContext().setEventName(OrganisationConstants.EventType.RO_UPDATED_EVENT);
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);
        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));
        Optional<RecognisingOrganisation> recognisingOrganisation =
                recognisingOrgRepository.findByRecognisingOrganisationUuid(
                        UUID.fromString("705fc839-5051-4a22-a77d-cf6d734d7d24"));
        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        BaseHeader header = event.getEventHeader();
        assertAll(
                "Organisation",
                () ->
                        assertEquals(
                                recognisingOrganisation.get().getName(),
                                roDataUpdate.getOrganisationName()),
                () ->
                        assertEquals(
                                VerificationStatusEnum.PENDING.getValue(),
                                recognisingOrganisation.get().getVerificationStatus().getValue()));

        List<StatusHistory> statusHistoryDetails =
                statusHistoryRepository.findByRecognisingOrganisationOrderByStatusDatetimeDesc(
                        recognisingOrganisation.get());
        assertEquals(1, statusHistoryDetails.stream().count());
        assertEquals("VOVerified", header.getEventDiscriminator());
    }

    @Test
    final void testEventDiscriminatorWhenVerifiedVOisUpdatedToPendingorRejectedRO()
            throws IOException {

        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");

        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setRecognisingOrganisationUuid(
                UUID.fromString("d303bc54-d13b-4252-aae6-486cf5a4f1f6")); // Verified VO

        roDataUpdate.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.REJECTED.getValue()));
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put("recognisingOrganisationUuid", "d303bc54-d13b-4252-aae6-486cf5a4f1f6");
        ThreadLocalHeaderContext.getContext().setEventContext(eventContext);
        ThreadLocalHeaderContext.getContext().setEventName(OrganisationConstants.EventType.RO_UPDATED_EVENT);
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);

        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));
        Optional<RecognisingOrganisation> recognisingOrganisation =
                recognisingOrgRepository.findByRecognisingOrganisationUuid(
                        UUID.fromString("d303bc54-d13b-4252-aae6-486cf5a4f1f6"));
        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        BaseHeader header = event.getEventHeader();
    assertAll(
        "Organisation",
        () ->
            assertEquals(
                recognisingOrganisation.get().getName(), roDataUpdate.getOrganisationName()),
        () ->
            assertEquals(
                VerificationStatusEnum.REJECTED.getValue(),
                recognisingOrganisation.get().getVerificationStatus().getValue()));

        List<StatusHistory> statusHistoryDetails =
                statusHistoryRepository.findByRecognisingOrganisationOrderByStatusDatetimeDesc(
                        recognisingOrganisation.get());
        assertEquals(1, statusHistoryDetails.stream().count());
        assertEquals(null, header.getEventDiscriminator());
    }
    @Test
    void testEventDiscriminatorInHeadersWhileNotPublishingROToLA() throws IOException {
        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");

        Map<String, String> eventContext = new HashMap<String, String>();
        eventContext.put("recognisingOrganisationUuid", "d303bc54-d13b-4252-aae6-486cf5a4f1f6");
        ThreadLocalHeaderContext.getContext().setEventContext(eventContext);
        ThreadLocalHeaderContext.getContext().setEventName(OrganisationConstants.EventType.RO_UPDATED_EVENT);
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);

        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.VERIFIED.getValue()));
        roDataUpdate.setContacts(UpdateOrganisationDataSetup.getContactsDataForIntegrationTest());
        roDataUpdate.setPartnerContact("Partner Contact");
        UiHeader uiHeader = OrganisationTestUtil.generateEventHeader();
        uiHeader.setEventName(OrganisationConstants.EventType.RO_UPDATED_EVENT);
        uiHeader.setXaccessToken(authorisedAccessTokenToUpdate);
        //uiHeader.setEventDiscriminator("VOVerified");
        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));
        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        BaseHeader header = event.getEventHeader();
        assertAll(
                "Headers",
                () ->
                        assertEquals(
                                OrganisationConstants.EventType.RO_UPDATED_EVENT,
                                header.getEventName()),
                () -> assertEquals("VOVerified", header.getEventDiscriminator()));
    }

    @Test
    void testUpdateSuccessIfVerificationStatusOfActiveROisUpdatedFromPendingToVerified() throws IOException {
        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");

        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.VERIFIED.getValue()));
        roDataUpdate.setContacts(UpdateOrganisationDataSetup.getContactsDataForIntegrationTest());
        roDataUpdate.setPartnerContact("Partner Contact");
        UiHeader uiHeader = OrganisationTestUtil.generateEventHeader();
        uiHeader.setEventName(OrganisationConstants.EventType.RO_UPDATED_EVENT);
        uiHeader.setXaccessToken(authorisedAccessTokenToUpdate);

        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);

        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));
        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        BaseHeader header = event.getEventHeader();
        assertAll(
                "Headers",
                () ->
                        assertEquals(
                                OrganisationConstants.EventType.RO_UPDATED_EVENT,
                                header.getEventName()),
                () -> assertEquals("VOVerified", header.getEventDiscriminator()));
    }
    @Test
    void testUpdateFailureIFVerificationStatusOfActiveROisUpdatedFromApprovedToVerified() throws IOException {

        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");

        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setRecognisingOrganisationUuid(UUID.fromString("705fc839-5051-4a22-a77d-cf6d734d7d24"));
        roDataUpdate.setOrganisationCode("234");
        roDataUpdate.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.VERIFIED.getValue()));
        roDataUpdate.setContacts(UpdateOrganisationDataSetup.getContactsDataForIntegrationTest());
        roDataUpdate.setPartnerContact("Partner Contact");
        UiHeader uiHeader = OrganisationTestUtil.generateEventHeader();
        uiHeader.setEventName(OrganisationConstants.EventType.RO_UPDATED_EVENT);
        uiHeader.setXaccessToken(authorisedAccessTokenToUpdate);
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put("recognisingOrganisationUuid", "705fc839-5051-4a22-a77d-cf6d734d7d24");
        uiHeader.setEventContext(eventContext);

        ThreadLocalHeaderContext.getContext().setEventContext(eventContext);
        ThreadLocalHeaderContext.getContext().setEventName(OrganisationConstants.EventType.RO_UPDATED_EVENT);
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);

        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));
        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseHeader header = publishedEventCaptor.getValue().getEventHeader();
        assertEquals("RoChangeRejected", header.getEventName());
    }
    @Test
    void testIfVerificationStatusOfROisUpdatedFromVerifiedToPendingDoNotSendToLA() throws IOException {
        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");

        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setRecognisingOrganisationUuid(UUID.fromString("102b038b-6784-4f31-ab16-a76b30c38d1b"));
        roDataUpdate.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.PENDING.getValue()));
        roDataUpdate.setContacts(UpdateOrganisationDataSetup.getContactsDataForIntegrationTest());
        roDataUpdate.setPartnerContact("Partner Contact");
        UiHeader uiHeader = OrganisationTestUtil.generateEventHeader();
        uiHeader.setEventName(OrganisationConstants.EventType.RO_UPDATED_EVENT);
        uiHeader.setXaccessToken(authorisedAccessTokenToUpdate);

        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);


        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));
        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();
        BaseHeader header = event.getEventHeader();
        assertAll(
                "Headers",
                () ->
                        assertEquals(
                                OrganisationConstants.EventType.RO_UPDATED_EVENT,
                                header.getEventName()),
                () -> assertEquals(null, header.getEventDiscriminator()));
    }
}
