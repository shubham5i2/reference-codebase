package com.ielts.cmds.organisation.utills;

import com.ielts.cmds.api.roui007rocreaterequested.*;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Address;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Addresses;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1AlternateName;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1AlternateNames;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Contact;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Contacts;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1MinimumScore;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1MinimumScores;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Note;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Notes;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1RecognisedProduct;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1RecognisedProducts;
import com.ielts.cmds.organisation.common.out.event.RoDetailsDataGeneratedEventV1;
import com.ielts.cmds.organisation.common.out.event.RoDetailsDataGeneratedEventV1RO;
import com.ielts.cmds.organisation.common.out.event.RoRequestedEventV1;
import com.ielts.cmds.organisation.domain.model.RoDataCreateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.Address;
import com.ielts.cmds.organisation.infrastructure.entity.AddressType;
import com.ielts.cmds.organisation.infrastructure.entity.AlternateName;
import com.ielts.cmds.organisation.infrastructure.entity.Contact;
import com.ielts.cmds.organisation.infrastructure.entity.ContactType;
import com.ielts.cmds.organisation.infrastructure.entity.Country;
import com.ielts.cmds.organisation.infrastructure.entity.MinimumScore;
import com.ielts.cmds.organisation.infrastructure.entity.ModuleType;
import com.ielts.cmds.organisation.infrastructure.entity.NoteType;
import com.ielts.cmds.organisation.infrastructure.entity.OrganisationType;
import com.ielts.cmds.organisation.infrastructure.entity.PartnerCode;
import com.ielts.cmds.organisation.cache.entity.Product;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisedProduct;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.entity.RoNote;
import com.ielts.cmds.organisation.infrastructure.entity.SectorType;
import com.ielts.cmds.organisation.infrastructure.entity.Territory;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import java.math.BigDecimal;
import java.time.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class CreateOrganisationDataSetup {

    public static RoDataCreateV1Valid createOrgData() {

        RoDataCreateV1Valid roDataCreate = new RoDataCreateV1Valid();

        roDataCreate.setOrganisationName("McGill University");
        roDataCreate.setOrganisationTypeUuid(
                UUID.fromString("e496aa98-86a3-476d-8be3-21ee0aa23c93"));
        roDataCreate.setOrganisationStatus(OrganisationStatusEnum.valueOf(OrganisationStatusEnum.ACTIVE.getValue()));
        roDataCreate.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.APPROVED.getValue()));
        roDataCreate.setAddresses(getAddressData());
        roDataCreate.setPartnerCode("IDP");
        roDataCreate.setPartnerContact("Partner Contact");
        roDataCreate.setMethodOfDelivery(MethodOfDeliveryEnum.valueOf(MethodOfDeliveryEnum.POSTAL.getValue()));
        roDataCreate.setSectorTypeUuid(UUID.fromString("48270c84-4cc8-489e-8eac-2af59898175a"));
        roDataCreate.setWebsiteUrl("www.officialxyz.com");
        roDataCreate.setCrmSystem("CRM Value");
        roDataCreate.setOrganisationCode("UCAS231");
        roDataCreate.setResultAvailableForYears(3);
        roDataCreate.setNotes(getNotesData());
        roDataCreate.setAlternateNames(getAlternateNamesData());
        roDataCreate.setContacts(getContactsData());
        roDataCreate.setAcceptsIOL(true);
        roDataCreate.setAcceptsSSR(false);
        roDataCreate.setAcceptsAC(true);
        roDataCreate.setAcceptsGT(false);
        roDataCreate.setMinimumScores(getMinimumScoresData());
        roDataCreate.setIeltsDisplayFlag(false);
        roDataCreate.setOrsDisplayFlag(false);
        roDataCreate.setLinkedOrganisations(getLinkedOrganisationsData());
        return roDataCreate;
    }

    public static List<RoDataCreateLinkedOrganisation> getLinkedOrganisationsData() {
        List<RoDataCreateLinkedOrganisation> linkedOrganisations =
                new ArrayList<>();
        RoDataCreateLinkedOrganisation linkedOrg = new RoDataCreateLinkedOrganisation();
        linkedOrg.setTargetRecognisingOrganisationUuid(
                UUID.fromString("705fc839-5051-4a22-a77d-cf6d734d7d24"));
        linkedOrg.setLinkType(LinkTypeEnum.valueOf(LinkTypeEnum.PARENT_RO.getValue()));
        linkedOrg.setLinkEffectiveFromDateTime(OffsetDateTime.now());
        linkedOrg.setLinkEffectiveToDateTime(LocalDateTime.of(2099, 12, 31, 11, 59).atOffset(ZoneOffset.UTC));
        linkedOrganisations.add(linkedOrg);
        RoDataCreateLinkedOrganisation additionalOrganisation1 =
                new RoDataCreateLinkedOrganisation();
        additionalOrganisation1.setTargetRecognisingOrganisationUuid(
                UUID.fromString("705fc839-5051-4a22-a77d-cf6d734d7d24"));
        additionalOrganisation1.setLinkType(LinkTypeEnum.valueOf(LinkTypeEnum.RESULTS_DELIVERY.getValue()));
        additionalOrganisation1.setLinkEffectiveFromDateTime(OffsetDateTime.now());
        additionalOrganisation1.setLinkEffectiveToDateTime(LocalDateTime.of(2099, 12, 31, 11, 59).atOffset(ZoneOffset.UTC));
        linkedOrganisations.add(additionalOrganisation1);
        RoDataCreateLinkedOrganisation additionalOrganisation2 =
                new RoDataCreateLinkedOrganisation();
        additionalOrganisation2.setTargetRecognisingOrganisationUuid(
                UUID.fromString("705fc839-5051-4a22-a77d-cf6d734d7d24"));
        additionalOrganisation2.setLinkType(LinkTypeEnum.valueOf(LinkTypeEnum.RESULTS_DELIVERY.getValue()));
        additionalOrganisation2.setLinkEffectiveFromDateTime(OffsetDateTime.now());
        additionalOrganisation2.setLinkEffectiveToDateTime(OffsetDateTime.now());
        linkedOrganisations.add(additionalOrganisation2);
        return linkedOrganisations;
    }

    private static List<RoDataCreateMinimumScore> getMinimumScoresData() {

        List<RoDataCreateMinimumScore> minScores = new ArrayList<>();
        RoDataCreateMinimumScore minScore = new RoDataCreateMinimumScore();
        minScore.setModuleTypeUuid(UUID.fromString("7a28a632-8728-4f74-882e-72e9d3649763"));
        minScore.setComponent(ComponentEnum.valueOf(ComponentEnum.L.getValue()));
        minScore.setMinimumScoreValue(new BigDecimal(7));
        minScores.add(minScore);
        RoDataCreateMinimumScore minScore1 = new RoDataCreateMinimumScore();
        minScore1.setModuleTypeUuid(UUID.fromString("7a28a632-8728-4f74-882e-72e9d3649763"));
        minScore1.setComponent(ComponentEnum.valueOf(ComponentEnum.R.getValue()));
        minScore1.setMinimumScoreValue(new BigDecimal(7));
        minScores.add(minScore1);
        return minScores;
    }

    private static List<RoDataCreateContact> getContactsData() {

        List<RoDataCreateContact> contacts = new ArrayList<>();
        RoDataCreateContact primaryContact = new RoDataCreateContact();
        primaryContact.setTitle("Ms");
        primaryContact.setFirstName("primary");
        primaryContact.setLastName("name");
        primaryContact.setJobTitle("Chief Suport Manager");
        primaryContact.setContactTypeUuid(UUID.fromString("c3397312-8ea3-453d-871b-68a1ef8c9184"));
        primaryContact.setEffectiveFromDateTime(OffsetDateTime.now());
        primaryContact.setEffectiveToDateTime(OffsetDateTime.now());
        primaryContact.setAddresses(getAddressData());
        contacts.add(primaryContact);
        RoDataCreateContact resultsAdminContact = new RoDataCreateContact();
        resultsAdminContact.setTitle("Ms");
        resultsAdminContact.setFirstName("results admin");
        resultsAdminContact.setLastName("name");
        resultsAdminContact.setJobTitle("Chief Suport Manager");
        resultsAdminContact.setContactTypeUuid(
                UUID.fromString("457a494b-64ca-497f-868f-cc0e5f30a97f"));
        resultsAdminContact.setEffectiveFromDateTime(OffsetDateTime.now());
        resultsAdminContact.setEffectiveToDateTime(OffsetDateTime.now());
        resultsAdminContact.setAddresses(getAddressData());
        contacts.add(resultsAdminContact);
        return contacts;
    }

    private static List<RoDataCreateAlternateName> getAlternateNamesData() {

        List<RoDataCreateAlternateName> altnames = new ArrayList<>();
        RoDataCreateAlternateName altname1 = new RoDataCreateAlternateName();
        altname1.setName("altname1");
        altnames.add(altname1);
        RoDataCreateAlternateName altname2 = new RoDataCreateAlternateName();
        altname2.setName("altname2");
        altnames.add(altname2);
        return altnames;
    }

    private static List<RoDataCreateNote> getNotesData() {

        List<RoDataCreateNote> notes = new ArrayList<>();
        RoDataCreateNote note1 = new RoDataCreateNote();
        note1.setNoteContent("content1");
        notes.add(note1);
        RoDataCreateNote note2 = new RoDataCreateNote();
        note2.setNoteContent("content2");
        notes.add(note2);
        return notes;
    }

    private static List<RoDataCreateAddress> getAddressData() {

        List<RoDataCreateAddress> addresses = new ArrayList<>();
        RoDataCreateAddress mainAddress = new RoDataCreateAddress();
        mainAddress.setAddressTypeUuid(UUID.fromString("c96fbd08-a302-4aa2-a594-13cdb33bb380"));
        mainAddress.setAddressLine1("22 Heathfield Gardens");
        mainAddress.setAddressLine2("string");
        mainAddress.setAddressLine3("string");
        mainAddress.setAddressLine4("string");
        mainAddress.setCity("Cambridge");
        mainAddress.setTerritoryUuid(UUID.fromString("f1bccce9-89e9-46da-a8dd-03c6db8b3815"));
        mainAddress.setCountryUuid(UUID.fromString("4b8dac87-d2dd-4599-b055-2f73a5f0a01a"));
        mainAddress.setPostalCode("CB2 8EA");
        mainAddress.setEmail("alan_2021@cambridgeassessment.org.uk");
        mainAddress.setPhone("+1 234 234 3456");
        addresses.add(mainAddress);
        RoDataCreateAddress deliveryAddress = new RoDataCreateAddress();
        deliveryAddress.setAddressTypeUuid(UUID.fromString("d13761e9-c134-4f80-a0a8-239a683a9c00"));
        deliveryAddress.setAddressLine1("22 Heathfield Gardens");
        deliveryAddress.setAddressLine2("string");
        deliveryAddress.setAddressLine3("string");
        deliveryAddress.setAddressLine4("string");
        deliveryAddress.setCity("Cambridge");
        deliveryAddress.setTerritoryUuid(UUID.fromString("f1bccce9-89e9-46da-a8dd-03c6db8b3815"));
        deliveryAddress.setCountryUuid(UUID.fromString("4b8dac87-d2dd-4599-b055-2f73a5f0a01a"));
        deliveryAddress.setPostalCode("CB2 8EA");
        deliveryAddress.setEmail("alan_2021@cambridgeassessment.org.uk");
        deliveryAddress.setPhone("+1 234 234 3456");
        addresses.add(deliveryAddress);
        return addresses;
    }

    public static RecognisingOrganisation populateOrganisation(
            final RoDataCreate roDataCreate, RecognisingOrganisation organisation) {

        organisation = populateOrgDetailsBasedOnAction(roDataCreate, organisation);
        organisation.setAddresses(populateAddress(null, roDataCreate.getAddresses(), organisation));
        organisation.setNotes(populateRoNotes(roDataCreate.getNotes(), organisation));
        organisation.setAlternateNames(
                populateAlternateName(roDataCreate.getAlternateNames(), organisation));
        organisation.setContacts(populateContacts(roDataCreate.getContacts(), organisation));
        //        organisation.setRecognisedProducts(
        //                populateRecognisedProducts(roDataCreate.getRecognisedProducts(),
        // organisation));
        organisation.setRecognisedProducts(
                populateRecognisedProducts(
                        roDataCreate.getAcceptsIOL(), roDataCreate.getAcceptsSSR(), organisation));
        organisation.setMinimumScores(
                populateMinimumScores(roDataCreate.getMinimumScores(), organisation));
        return organisation;
    }

    private static List<MinimumScore> populateMinimumScores(
            List<RoDataCreateMinimumScore> minimumScores, RecognisingOrganisation organisation) {

        List<MinimumScore> minimumScoresList = new ArrayList<>();
        minimumScores.forEach(
                minScore -> {
                    MinimumScore minScoreToBeAdded = new MinimumScore();
                    minScoreToBeAdded.setConcurrencyVersion(0);
                    minScoreToBeAdded.setCreatedBy(
                            OrganisationConstants.GenericConstants.OPERATIONAL_USER);
                    minScoreToBeAdded.setCreatedDatetime(Instant.now());
                    minScoreToBeAdded.setUpdatedBy(
                            OrganisationConstants.GenericConstants.OPERATIONAL_USER);
                    minScoreToBeAdded.setUpdatedDatetime(Instant.now());

                    minScoreToBeAdded.setModuleTypeUuid(minScore.getModuleTypeUuid());
                    minScoreToBeAdded.setComponent(ComponentEnum.valueOf(minScore.getComponent().getValue()));
                    minScoreToBeAdded.setMinimumScoreValue(minScore.getMinimumScoreValue());
                    minScoreToBeAdded.setRecognisingOrganisation(organisation);
                    minimumScoresList.add(minScoreToBeAdded);
                });
        return minimumScoresList;
    }

    public static List<RecognisedProduct> populateRecognisedProducts(
            Boolean acceptsIOL, Boolean acceptsSSR, RecognisingOrganisation organisation) {

        List<RecognisedProduct> recognisedProductList = new ArrayList<>();
        recognisedProductList =
                createNewRecognisedProduct(
                        UUID.fromString("fdbacec5-e80a-4710-b3de-7d5f310b1466"),
                        organisation,
                        recognisedProductList); // IOC AC
        recognisedProductList =
                createNewRecognisedProduct(
                        UUID.fromString("cf9a05e9-2679-42da-b7d2-b34ea3e0724e"),
                        organisation,
                        recognisedProductList); // IOC GT
        if (acceptsIOL) {
            recognisedProductList =
                    createNewRecognisedProduct(
                            UUID.fromString("3e81e94b-8b6a-42b5-970c-b141f9d195a3"),
                            organisation,
                            recognisedProductList); // IOL AC
            recognisedProductList =
                    createNewRecognisedProduct(
                            UUID.fromString("d96eece2-1d7c-495a-a754-6b523b710a82"),
                            organisation,
                            recognisedProductList); // IOL GT
        }
        if (acceptsSSR) {
            if (acceptsIOL) {
                recognisedProductList =
                        createNewRecognisedProduct(
                                UUID.fromString("6d28d524-472d-4d53-8fd9-dc7c4bb5325d"),
                                organisation,
                                recognisedProductList); // SSR IOL AC
                recognisedProductList =
                        createNewRecognisedProduct(
                                UUID.fromString("7b1d8d96-c314-40cd-a61c-2b681086a458"),
                                organisation,
                                recognisedProductList); // SSR IOL GT
                recognisedProductList =
                        createNewRecognisedProduct(
                                UUID.fromString("cb7cd48c-5e79-4a28-8104-e0bcd8e39999"),
                                organisation,
                                recognisedProductList); // SSR IOC AC
                recognisedProductList =
                        createNewRecognisedProduct(
                                UUID.fromString("c37e2fab-898d-46d4-a61b-17f24bb29e83"),
                                organisation,
                                recognisedProductList); // SSR IOC GT
            } else {
                recognisedProductList =
                        createNewRecognisedProduct(
                                UUID.fromString("cb7cd48c-5e79-4a28-8104-e0bcd8e39999"),
                                organisation,
                                recognisedProductList); // SSR IOC AC
                recognisedProductList =
                        createNewRecognisedProduct(
                                UUID.fromString("c37e2fab-898d-46d4-a61b-17f24bb29e83"),
                                organisation,
                                recognisedProductList); // SSR IOC GT
            }
        }
        return recognisedProductList;
    }

    private static List<RecognisedProduct> createNewRecognisedProduct(
            UUID productUUid,
            RecognisingOrganisation organisation,
            List<RecognisedProduct> recognisedProductList) {
        RecognisedProduct recognisedProductToBeAdded = new RecognisedProduct();
        recognisedProductToBeAdded.setConcurrencyVersion(0);
        recognisedProductToBeAdded.setCreatedBy(
                OrganisationConstants.GenericConstants.OPERATIONAL_USER);
        recognisedProductToBeAdded.setCreatedDatetime(Instant.now());
        recognisedProductToBeAdded.setUpdatedBy(
                OrganisationConstants.GenericConstants.OPERATIONAL_USER);
        recognisedProductToBeAdded.setUpdatedDatetime(Instant.now());

        recognisedProductToBeAdded.setProductUuid(productUUid);
        recognisedProductToBeAdded.setEffectiveFromDatetime(OffsetDateTime.now(ZoneOffset.UTC));
        recognisedProductToBeAdded.setEffectiveToDatetime(LocalDateTime.of(2099, 12, 31, 11, 59).atOffset(ZoneOffset.UTC));
        recognisedProductToBeAdded.setRecognisingOrganisation(organisation);
        recognisedProductList.add(recognisedProductToBeAdded);
        return recognisedProductList;
    }

    private static List<Contact> populateContacts(
            List<RoDataCreateContact> contacts, RecognisingOrganisation organisation) {

        List<Contact> contactList = new ArrayList<>();
        contacts.forEach(
                contact -> {
                    Contact contactToBeAdded = new Contact();
                    contactToBeAdded.setConcurrencyVersion(0);
                    contactToBeAdded.setCreatedBy(
                            OrganisationConstants.GenericConstants.OPERATIONAL_USER);
                    contactToBeAdded.setCreatedDatetime(Instant.now());
                    contactToBeAdded.setUpdatedBy(
                            OrganisationConstants.GenericConstants.OPERATIONAL_USER);
                    contactToBeAdded.setUpdatedDatetime(Instant.now());

                    contactToBeAdded.setTitle(contact.getTitle());
                    contactToBeAdded.setFirstName(contact.getFirstName());
                    contactToBeAdded.setLastName(contact.getLastName());
                    contactToBeAdded.setContactTypeUuid(contact.getContactTypeUuid());
                    contactToBeAdded.setEffectiveFromDatetime(contact.getEffectiveFromDateTime());
                    contactToBeAdded.setEffectiveToDatetime(contact.getEffectiveToDateTime());
                    contactToBeAdded.setJobTitle(contact.getJobTitle());
                    contactToBeAdded.setAddresses(
                            populateAddress(
                                    contactToBeAdded, contact.getAddresses(), organisation));
                    contactToBeAdded.setRecognisingOrganisation(organisation);
                    contactList.add(contactToBeAdded);
                });

        return contactList;
    }

    private static List<AlternateName> populateAlternateName(
            List<RoDataCreateAlternateName> alternateNames, RecognisingOrganisation organisation) {

        List<AlternateName> alternateNamesList = new ArrayList<>();
        alternateNames.forEach(
                altName -> {
                    AlternateName altNameToBeAdded = new AlternateName();
                    altNameToBeAdded.setConcurrencyVersion(0);
                    altNameToBeAdded.setCreatedBy(
                            OrganisationConstants.GenericConstants.OPERATIONAL_USER);
                    altNameToBeAdded.setCreatedDatetime(Instant.now());
                    altNameToBeAdded.setUpdatedBy(
                            OrganisationConstants.GenericConstants.OPERATIONAL_USER);
                    altNameToBeAdded.setUpdatedDatetime(Instant.now());

                    altNameToBeAdded.setName(altName.getName());
                    altNameToBeAdded.setRecognisingOrganisation(organisation);
                    alternateNamesList.add(altNameToBeAdded);
                });
        return alternateNamesList;
    }

    private static List<RoNote> populateRoNotes(
            List<RoDataCreateNote> notes, RecognisingOrganisation organisation) {

        List<RoNote> roNotesList = new ArrayList<>();
        notes.forEach(
                note -> {
                    RoNote noteToBeAdded = new RoNote();
                    noteToBeAdded.setConcurrencyVersion(0);
                    noteToBeAdded.setCreatedBy(
                            OrganisationConstants.GenericConstants.OPERATIONAL_USER);
                    noteToBeAdded.setCreatedDatetime(Instant.now());
                    noteToBeAdded.setUpdatedBy(
                            OrganisationConstants.GenericConstants.OPERATIONAL_USER);
                    noteToBeAdded.setUpdatedDatetime(Instant.now());

                    noteToBeAdded.setNoteContent(note.getNoteContent());
                    noteToBeAdded.setNoteTypeUuid(
                            UUID.fromString("f9aa5ac1-da99-40f2-82e7-a5fea9e45979"));
                    noteToBeAdded.setRecognisingOrganisation(organisation);
                    roNotesList.add(noteToBeAdded);
                });
        return roNotesList;
    }

    private static List<Address> populateAddress(
            Contact contact,
            List<RoDataCreateAddress> addresses,
            RecognisingOrganisation organisation) {

        List<Address> addressList = new ArrayList<>();
        addresses.forEach(
                address -> {
                    Address addressToBeAdded = new Address();
                    addressToBeAdded.setConcurrencyVersion(0);
                    addressToBeAdded.setCreatedBy(
                            OrganisationConstants.GenericConstants.OPERATIONAL_USER);
                    addressToBeAdded.setCreatedDatetime(Instant.now());
                    addressToBeAdded.setUpdatedBy(
                            OrganisationConstants.GenericConstants.OPERATIONAL_USER);
                    addressToBeAdded.setUpdatedDatetime(Instant.now());

                    addressToBeAdded.setAddressTypeUuid(address.getAddressTypeUuid());
                    addressToBeAdded.setCountryUuid(address.getCountryUuid());
                    addressToBeAdded.setTerritoryUuid(address.getTerritoryUuid());
                    addressToBeAdded.setAddressline1(address.getAddressLine1());
                    addressToBeAdded.setAddressline2(address.getAddressLine2());
                    addressToBeAdded.setAddressline3(address.getAddressLine3());
                    addressToBeAdded.setAddressline4(address.getAddressLine4());
                    addressToBeAdded.setCity(address.getCity());
                    addressToBeAdded.setPostalCode(address.getPostalCode());
                    addressToBeAdded.setEmail(address.getEmail());
                    addressToBeAdded.setPhone(address.getPhone());
                    addressToBeAdded.setRecognisingOrganisation(organisation);
                    if (contact != null) {
                        addressToBeAdded.setContact(contact);
                    }
                    addressList.add(addressToBeAdded);
                });
        return addressList;
    }

    public static RecognisingOrganisation populateSetterMethods(
            final RoDataCreate roData, final RecognisingOrganisation orgDetails) {

        orgDetails.setName(roData.getOrganisationName());
        orgDetails.setOrganisationTypeUuid(roData.getOrganisationTypeUuid());
        orgDetails.setSectorTypeUuid(roData.getSectorTypeUuid());
        orgDetails.setVerificationStatus(roData.getVerificationStatus());
        orgDetails.setPartnerCode(roData.getPartnerCode());
        orgDetails.setMethodOfDelivery(roData.getMethodOfDelivery());
        orgDetails.setOrgStatus(roData.getOrganisationStatus());
        orgDetails.setWebsiteUrl(roData.getWebsiteUrl());
        orgDetails.setCrmSystem("CRM Value");
        orgDetails.setOrganisationCode(roData.getOrganisationCode());
        orgDetails.setResultAvailableForYears(roData.getResultAvailableForYears());
        orgDetails.setSoftDeleted(false);
        return orgDetails;
    }

    public static RecognisingOrganisation populateOrgDetailsBasedOnAction(
            final RoDataCreate roData, final RecognisingOrganisation orgDetails) {

        orgDetails.setConcurrencyVersion(0);
        orgDetails.setCreatedBy(OrganisationConstants.GenericConstants.OPERATIONAL_USER);
        orgDetails.setCreatedDatetime(Instant.now());
        orgDetails.setUpdatedBy(OrganisationConstants.GenericConstants.OPERATIONAL_USER);
        orgDetails.setUpdatedDatetime(Instant.now());
        return populateSetterMethods(roData, orgDetails);
    }

    public static RoChangedEventV1 entityToEventMapper(RecognisingOrganisation publishRo) {

        RoChangedEventV1 roChangedEvent = new RoChangedEventV1();
        roChangedEvent.setRecognisingOrganisationUuid(publishRo.getRecognisingOrganisationUuid());
        roChangedEvent.setOrganisationName(publishRo.getName());
        roChangedEvent.setOrganisationId(publishRo.getOrganisationId());
        roChangedEvent.setOrganisationTypeUuid(publishRo.getOrganisationTypeUuid());
        roChangedEvent.setOrganisationStatus(publishRo.getOrgStatus());
        roChangedEvent.setVerificationStatus(publishRo.getVerificationStatus());
        roChangedEvent.setAddresses(getAddresses(publishRo.getAddresses()));
        roChangedEvent.setPartnerCode(publishRo.getPartnerCode());
        roChangedEvent.setMethodOfDelivery(publishRo.getMethodOfDelivery());
        roChangedEvent.setSectorTypeUuid(publishRo.getSectorTypeUuid());
        roChangedEvent.setWebsiteUrl(publishRo.getWebsiteUrl());
        roChangedEvent.setCrmSystem("CRM Value");
        roChangedEvent.setOrganisationCode(publishRo.getOrganisationCode());
        roChangedEvent.setResultAvailableForYears(publishRo.getResultAvailableForYears());
        roChangedEvent.setIeltsDisplayFlag(false);
        roChangedEvent.setOrsDisplayFlag(false);
        roChangedEvent.setNotes(getNotes(publishRo));
        roChangedEvent.setAlternateNames(getAlternateNames(publishRo));
        roChangedEvent.setContacts(getContacts(publishRo));
        roChangedEvent.setRecognisedProducts(getRecognisedProducts(publishRo));
        roChangedEvent.setMinimumScores(getMinimumScores(publishRo));
        return roChangedEvent;
    }

    public static RoRequestedEventV1 entityToEventMapperForView(RecognisingOrganisation publishRo) {

        RoRequestedEventV1 roRequestedEvent = new RoRequestedEventV1();
        roRequestedEvent.setRecognisingOrganisationUuid(publishRo.getRecognisingOrganisationUuid());
        roRequestedEvent.setOrganisationName(publishRo.getName());
        roRequestedEvent.setOrganisationId(publishRo.getOrganisationId());
        roRequestedEvent.setOrganisationTypeUuid(publishRo.getOrganisationTypeUuid());
        roRequestedEvent.setOrganisationStatus(OrganisationStatusEnum.valueOf(publishRo.getOrgStatus().getValue()));
        roRequestedEvent.setVerificationStatus(VerificationStatusEnum.valueOf(publishRo.getVerificationStatus().getValue()));
        roRequestedEvent.setAddresses(getAddresses(publishRo.getAddresses()));
        roRequestedEvent.setPartnerCode(publishRo.getPartnerCode());
        roRequestedEvent.setMethodOfDelivery(MethodOfDeliveryEnum.valueOf(publishRo.getMethodOfDelivery().getValue()));
        roRequestedEvent.setSectorTypeUuid(publishRo.getSectorTypeUuid());
        roRequestedEvent.setWebsiteUrl(publishRo.getWebsiteUrl());
        roRequestedEvent.setCrmSystem("CRM Value");
        roRequestedEvent.setOrganisationCode(publishRo.getOrganisationCode());
        roRequestedEvent.setResultAvailableForYears(publishRo.getResultAvailableForYears());
        roRequestedEvent.setIeltsDisplayFlag(false);
        roRequestedEvent.setOrsDisplayFlag(false);
        roRequestedEvent.setNotes(getNotes(publishRo));
        roRequestedEvent.setAlternateNames(getAlternateNames(publishRo));
        roRequestedEvent.setContacts(getContacts(publishRo));
        roRequestedEvent.setAcceptsIOL(true);
        roRequestedEvent.setAcceptsSSR(true);
        //        roChangedEvent.setRecognisedProducts(getRecognisedProducts(publishRo));
        roRequestedEvent.setMinimumScores(getMinimumScores(publishRo));
        return roRequestedEvent;
    }

    public static RoDetailsDataGeneratedEventV1 entityToEventMapperForSearchByOrgId(
            Set<RecognisingOrganisation> orgDetails) {

        RoDetailsDataGeneratedEventV1 roDetailsDataGeneratedEventV1 =
                new RoDetailsDataGeneratedEventV1();
        for (RecognisingOrganisation recognisingOrganisation : orgDetails) {
            RoDetailsDataGeneratedEventV1RO event = new RoDetailsDataGeneratedEventV1RO();
            event.setName(recognisingOrganisation.getName());
            event.setRecognisingOrganisationUuid(
                    recognisingOrganisation.getRecognisingOrganisationUuid());
            roDetailsDataGeneratedEventV1.add(event);
        }
        return roDetailsDataGeneratedEventV1;
    }

    private static RoChangedEventV1MinimumScores getMinimumScores(
            RecognisingOrganisation publishRo) {

        RoChangedEventV1MinimumScores minScores = new RoChangedEventV1MinimumScores();
        for (MinimumScore minScore : publishRo.getMinimumScores()) {
            RoChangedEventV1MinimumScore roChangedEventMinScore =
                    new RoChangedEventV1MinimumScore();
            roChangedEventMinScore.setMinimumScoreUuid(minScore.getMinscoreReqUuid());
            roChangedEventMinScore.setModuleTypeUuid(minScore.getModuleTypeUuid());
            roChangedEventMinScore.setComponent(minScore.getComponent());
            roChangedEventMinScore.setMinimumScoreValue(minScore.getMinimumScoreValue());
            minScores.add(roChangedEventMinScore);
        }
        return minScores;
    }

    private static RoChangedEventV1RecognisedProducts getRecognisedProducts(
            RecognisingOrganisation publishRo) {

        RoChangedEventV1RecognisedProducts recognisedProducts =
                new RoChangedEventV1RecognisedProducts();
        for (RecognisedProduct recognisedProduct : publishRo.getRecognisedProducts()) {
            RoChangedEventV1RecognisedProduct roChangedEventRecognisedProduct =
                    new RoChangedEventV1RecognisedProduct();
            roChangedEventRecognisedProduct.setRecognisedProductUuid(
                    recognisedProduct.getRecognisedProductUuid());
            roChangedEventRecognisedProduct.setProductUuid(recognisedProduct.getProductUuid());
            roChangedEventRecognisedProduct.setEffectiveFromDateTime(
                    recognisedProduct.getEffectiveFromDatetime());
            roChangedEventRecognisedProduct.setEffectiveToDateTime(
                    recognisedProduct.getEffectiveToDatetime());
            recognisedProducts.add(roChangedEventRecognisedProduct);
        }
        return recognisedProducts;
    }

    private static RoChangedEventV1Contacts getContacts(RecognisingOrganisation publishRo) {

        RoChangedEventV1Contacts contacts = new RoChangedEventV1Contacts();
        for (Contact contact : publishRo.getContacts()) {
            RoChangedEventV1Contact roChangedEventContact = new RoChangedEventV1Contact();
            roChangedEventContact.setContactUuid(contact.getContactUuid());
            roChangedEventContact.setTitle(contact.getTitle());
            roChangedEventContact.setFirstName(contact.getFirstName());
            roChangedEventContact.setLastName(contact.getLastName());
            roChangedEventContact.setJobTitle(contact.getJobTitle());
            roChangedEventContact.setContactTypeUuid(contact.getContactTypeUuid());
            roChangedEventContact.setEffectiveFromDateTime(contact.getEffectiveFromDatetime());
            roChangedEventContact.setEffectiveToDateTime(contact.getEffectiveToDatetime());
            roChangedEventContact.setAddresses(getAddresses(contact.getAddresses()));
            contacts.add(roChangedEventContact);
        }
        return contacts;
    }

    private static RoChangedEventV1AlternateNames getAlternateNames(
            RecognisingOrganisation publishRo) {

        RoChangedEventV1AlternateNames alternateNames = new RoChangedEventV1AlternateNames();
        for (AlternateName altName : publishRo.getAlternateNames()) {
            RoChangedEventV1AlternateName roChangedEventAltName =
                    new RoChangedEventV1AlternateName();
            roChangedEventAltName.setAlternateNameUuid(altName.getAlternateNameUuid());
            roChangedEventAltName.setName(altName.getName());
            alternateNames.add(roChangedEventAltName);
        }
        return alternateNames;
    }

    private static RoChangedEventV1Notes getNotes(RecognisingOrganisation publishRo) {

        RoChangedEventV1Notes notes = new RoChangedEventV1Notes();
        for (RoNote note : publishRo.getNotes()) {
            RoChangedEventV1Note roChangedEventNote = new RoChangedEventV1Note();
            roChangedEventNote.setNoteUuid(note.getNoteUuid());
            roChangedEventNote.setNoteTypeUuid(note.getNoteTypeUuid());
            roChangedEventNote.setNoteContent(note.getNoteContent());
            LocalDateTime updatedDateTime =
                    LocalDateTime.ofInstant(note.getUpdatedDatetime(), ZoneOffset.UTC);
            roChangedEventNote.setUpdatedDatetime(updatedDateTime);
            notes.add(roChangedEventNote);
        }
        return notes;
    }

    private static RoChangedEventV1Addresses getAddresses(List<Address> publishRoAddresses) {

        if (publishRoAddresses != null) {
            RoChangedEventV1Addresses addresses = new RoChangedEventV1Addresses();
            for (Address address : publishRoAddresses) {
                RoChangedEventV1Address roChangedEventAddress = new RoChangedEventV1Address();
                roChangedEventAddress.setAddressUuid(address.getAddressUuid());
                roChangedEventAddress.setAddressTypeUuid(address.getAddressTypeUuid());
                roChangedEventAddress.setAddressLine1(address.getAddressline1());
                roChangedEventAddress.setAddressLine2(address.getAddressline2());
                roChangedEventAddress.setAddressLine3(address.getAddressline3());
                roChangedEventAddress.setAddressLine4(address.getAddressline4());
                roChangedEventAddress.setCity(address.getCity());
                roChangedEventAddress.setTerritoryUuid(address.getTerritoryUuid());
                Territory territory = getTerritoryData();
                roChangedEventAddress.setTerritoryIsoCode(territory.getTerritoryIsoCode());
                roChangedEventAddress.setCountryIso3Code(
                        territory.getCountry().getCountryIso3Code());
                roChangedEventAddress.setPostalCode(address.getPostalCode());
                roChangedEventAddress.setEmail(address.getEmail());
                roChangedEventAddress.setPhone(address.getPhone());
                addresses.add(roChangedEventAddress);
            }
            return addresses;
        }

        return null;
    }

    public static Territory getTerritoryData() {
        Country countryOne = new Country();
        countryOne.setCountryUuid(UUID.fromString("4b8dac87-d2dd-4599-b055-2f73a5f0a01a"));
        countryOne.setLegacyReference("IND");
        countryOne.setCountryName("INDIA");
        countryOne.setCountryIso3Code("IND");
        countryOne.setEffectiveFromDate(LocalDate.of(2020, 7, 1));
        countryOne.setEffectiveToDate(LocalDate.of(2099, 12, 31));
        Territory territoryOne = new Territory();
        territoryOne.setTerritoryUuid(UUID.fromString("f1bccce9-89e9-46da-a8dd-03c6db8b3815"));
        territoryOne.setLegacyReference(null);
        territoryOne.setTerritoryIsoCode("IN-AN");
        territoryOne.setTerritoryName("Andaman and Nicobar Islands");
        territoryOne.setCountry(countryOne);
        territoryOne.setEffectiveFromDate(LocalDate.of(2020, 7, 1));
        territoryOne.setEffectiveToDate(LocalDate.of(2099, 12, 31));
        return territoryOne;
    }

    public static NoteType getNoteTypesData() {
        NoteType noteType = new NoteType();
        noteType.setNoteTypeUuid(UUID.fromString("f9aa5ac1-da99-40f2-82e7-a5fea9e45979"));
        noteType.setNotesType("Internal");
        noteType.setDescription("");
        noteType.setEffectiveFromDate(LocalDate.of(2020, 7, 1));
        noteType.setEffectiveToDate(LocalDate.of(2099, 12, 31));
        return noteType;
    }

    public static ContactType getContactTypeData() {
        ContactType contactType = new ContactType();
        contactType.setContactTypeUuid(UUID.fromString("80f4bba7-70b2-4e16-bef4-2ff06c58f620"));
        contactType.setContactsType("Partner Contact");
        contactType.setDescription("");
        contactType.setEffectiveFromDate(LocalDate.of(2020, 7, 1));
        contactType.setEffectiveToDate(LocalDate.of(2099, 12, 31));
        return contactType;
    }

    public static PartnerCode getPartnerData() {
        PartnerCode partner = new PartnerCode();
        partner.setPartnerUuid(UUID.fromString("945a233a-6779-43a1-be88-dc97b9b36509"));
        partner.setPartnerName("IDP");
        partner.setPartnersCode("IDP");
        partner.setEffectiveFromDate(LocalDate.of(2020, 7, 1));
        partner.setEffectiveToDate(LocalDate.of(2099, 12, 31));
        return partner;
    }

    public static SectorType getSectorTypeData() {
        SectorType sectorType = new SectorType();
        sectorType.setSectorTypeUuid(UUID.fromString("48270c84-4cc8-489e-8eac-2af59898175a"));
        sectorType.setSectorsType("College / University");
        sectorType.setDescription(null);
        sectorType.setEffectiveFromDate(LocalDate.of(2020, 7, 1));
        sectorType.setEffectiveToDate(LocalDate.of(2099, 12, 31));
        return sectorType;
    }

    public static AddressType getAddressTypeData() {
        AddressType addressType = new AddressType();
        addressType.setAddressTypeUuid(UUID.fromString("c96fbd08-a302-4aa2-a594-13cdb33bb380"));
        addressType.setAddressTypeName("Main");
        addressType.setDescription(null);
        addressType.setEffectiveFromDate(LocalDate.of(2020, 7, 1));
        addressType.setEffectiveToDate(LocalDate.of(2099, 12, 31));
        return addressType;
    }

    public static AddressType getDeliveryAddressTypeData() {
        AddressType addressType = new AddressType();
        addressType.setAddressTypeUuid(UUID.fromString("d13761e9-c134-4f80-a0a8-239a683a9c00"));
        addressType.setAddressTypeName("Delivery");
        addressType.setDescription(null);
        addressType.setEffectiveFromDate(LocalDate.of(2020, 7, 1));
        addressType.setEffectiveToDate(LocalDate.of(2099, 12, 31));
        return addressType;
    }

    public static Country getCountryData() {
        Country country = new Country();
        country.setCountryUuid(UUID.fromString("4b8dac87-d2dd-4599-b055-2f73a5f0a01a"));
        country.setCountryName("INDIA");
        country.setCountryIso3Code("IND");
        country.setLegacyReference("IND");
        country.setEffectiveFromDate(LocalDate.of(2020, 7, 1));
        country.setEffectiveToDate(LocalDate.of(2099, 12, 31));
        return country;
    }

    public static Product getproductData() {
        Product product = new Product();
        product.setProductUuid(UUID.fromString("3e81e94b-8b6a-42b5-970c-b141f9d195a3"));
        product.setBookable(true);
        product.setName("");
        return product;
    }

    public static List<Product> getproductDataWithCharacteristics() {
        List<Product> bookableProductList = new ArrayList<>();
        Product product1 = new Product();
        product1.setProductUuid(UUID.fromString("3e81e94b-8b6a-42b5-970c-b141f9d195a3"));
        product1.setBookable(true);
        product1.setName("");
        product1.setProductCharacteristics(
                "{\"characteristics\": [\"IOL\",\"AC\"],\"RoAutoAccepted\": [\"FALSE\"]}");
        bookableProductList.add(product1);
        Product product2 = new Product();
        product2.setProductUuid(UUID.fromString("d96eece2-1d7c-495a-a754-6b523b710a82"));
        product2.setBookable(true);
        product2.setName("");
        product2.setProductCharacteristics(
                "{\"characteristics\": [\"IOL\",\"AC\"],\"RoAutoAccepted\": [\"FALSE\"]}");
        bookableProductList.add(product2);
        Product product3 = new Product();
        product3.setProductUuid(UUID.fromString("fdbacec5-e80a-4710-b3de-7d5f310b1466"));
        product3.setBookable(true);
        product3.setName("");
        product3.setProductCharacteristics(
                "{\"characteristics\": [\"IOC\",\"AC\"],\"RoAutoAccepted\": [\"TRUE\"]}");
        bookableProductList.add(product3);
        Product product4 = new Product();
        product4.setProductUuid(UUID.fromString("cf9a05e9-2679-42da-b7d2-b34ea3e0724e"));
        product4.setBookable(true);
        product4.setName("");
        product4.setProductCharacteristics(
                "{\"characteristics\": [\"IOC\",\"GT\"],\"RoAutoAccepted\": [\"TRUE\"]}");
        bookableProductList.add(product4);
        Product product5 = new Product();
        product5.setProductUuid(UUID.fromString("cb7cd48c-5e79-4a28-8104-e0bcd8e39999"));
        product5.setBookable(true);
        product5.setName("");
        product5.setProductCharacteristics(
                "{\"characteristics\": [\"IOC\", \"AC\",\"SSR\"],\"RoAutoAccepted\": [\"FALSE\"]}");
        bookableProductList.add(product5);
        Product product6 = new Product();
        product6.setProductUuid(UUID.fromString("c37e2fab-898d-46d4-a61b-17f24bb29e83"));
        product6.setBookable(true);
        product6.setName("");
        product6.setProductCharacteristics(
                "{\"characteristics\": [\"IOC\",\"GT\",\"SSR\"],\"RoAutoAccepted\": [\"FALSE\"]}");
        bookableProductList.add(product6);
        Product product7 = new Product();
        product7.setProductUuid(UUID.fromString("6d28d524-472d-4d53-8fd9-dc7c4bb5325d"));
        product7.setBookable(true);
        product7.setName("");
        product7.setProductCharacteristics(
                "{\"characteristics\": [\"IOL\",\"AC\", \"SSR\"],\"RoAutoAccepted\": [\"FALSE\"]}");
        bookableProductList.add(product7);
        return bookableProductList;
    }

    public static OrganisationType getOrganisationTypeData() {
        OrganisationType organisationType = new OrganisationType();
        organisationType.setOrganisationTypeUuid(
                UUID.fromString("e496aa98-86a3-476d-8be3-21ee0aa23c93"));
        organisationType.setOrganisationsType("RO");
        organisationType.setDescription("Recognising Organisation");
        organisationType.setEffectiveFromDate(LocalDate.of(2020, 7, 1));
        organisationType.setEffectiveToDate(LocalDate.of(2099, 12, 31));
        return organisationType;
    }

    public static OrganisationType getVOOrganisationTypeData() {
        OrganisationType organisationType = new OrganisationType();
        organisationType.setOrganisationTypeUuid(
                UUID.fromString("e392ae7c-016f-433a-bdfa-b79bfcdddf26"));
        organisationType.setOrganisationsType("VO");
        organisationType.setDescription("Verified Organisation");
        organisationType.setEffectiveFromDate(LocalDate.of(2020, 7, 1));
        organisationType.setEffectiveToDate(LocalDate.of(2099, 12, 31));
        return organisationType;
    }

    public static ContactType getPrimaryContactTypeData() {
        ContactType contactType = new ContactType();
        contactType.setContactTypeUuid(UUID.fromString("c3397312-8ea3-453d-871b-68a1ef8c9184"));
        contactType.setContactsType("Primary");
        contactType.setDescription(null);
        contactType.setEffectiveFromDate(LocalDate.of(2020, 7, 1));
        contactType.setEffectiveToDate(LocalDate.of(2099, 12, 31));
        return contactType;
    }

    public static ContactType getResultsAdminContactTypeData() {
        ContactType contactType = new ContactType();
        contactType.setContactTypeUuid(UUID.fromString("457a494b-64ca-497f-868f-cc0e5f30a97f"));
        contactType.setContactsType("Results Admin");
        contactType.setDescription(null);
        contactType.setEffectiveFromDate(LocalDate.of(2020, 7, 1));
        contactType.setEffectiveToDate(LocalDate.of(2099, 12, 31));
        return contactType;
    }

    public static ModuleType getModuleTypeData() {
        ModuleType moduleType = new ModuleType();
        moduleType.setModuleTypeUuid(UUID.fromString("7a28a632-8728-4f74-882e-72e9d3649763"));
        moduleType.setModulesType("AC");
        moduleType.setDescription("Academic");
        moduleType.setEffectiveFromDate(LocalDate.of(2020, 7, 1));
        moduleType.setEffectiveToDate(LocalDate.of(2099, 12, 31));
        return moduleType;
    }

    public static RecognisingOrganisation getExistingOrganisationDetails() {
        RecognisingOrganisation existingRO = new RecognisingOrganisation();
        existingRO.setRecognisingOrganisationUuid(
                UUID.fromString("705fc839-5051-4a22-a77d-cf6d734d7d24"));
        existingRO.setName("RO Name");
        existingRO.setOrgStatus(OrganisationStatusEnum.valueOf(OrganisationStatusEnum.ACTIVE.getValue()));
        existingRO.setOrganisationTypeUuid(UUID.fromString("e392ae7c-016f-433a-bdfa-b79bfcdddf26"));
        return existingRO;
    }

    public static UiHeader getUiHeaderForTest() {
        final CMDSHeaderContext headerContext = ThreadLocalHeaderContext.getContext();
        UiHeader uiHeader = new UiHeader();
        uiHeader.setEventContext(headerContext.getEventContext());
        uiHeader.setCorrelationId(headerContext.getCorrelationId());
        uiHeader.setPartnerCode(headerContext.getPartnerCode());
        uiHeader.setCallbackURL(headerContext.getCallbackURL());
        uiHeader.setTransactionId(headerContext.getTransactionId());
        uiHeader.setConnectionId(headerContext.getConnectionId());
        uiHeader.setEventDiscriminator(headerContext.getEventDiscriminator());
        uiHeader.setXaccessToken(headerContext.getXaccessToken());
        uiHeader.setEventDateTime(headerContext.getEventDateTime());
        uiHeader.setEventName(headerContext.getEventName());
        return uiHeader;
    }
}
