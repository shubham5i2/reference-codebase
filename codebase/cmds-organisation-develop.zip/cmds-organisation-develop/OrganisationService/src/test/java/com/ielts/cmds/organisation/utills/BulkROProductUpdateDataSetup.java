package com.ielts.cmds.organisation.utills;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.domain.model.BulkROProductsUpdateRecordEvent;
import com.ielts.cmds.organisation.domain.model.BulkRORecognisedProductUpdateMessageV1;
import com.ielts.cmds.organisation.domain.model.BulkRORecognisedProductsUpdateDataV1;
import com.ielts.cmds.organisation.domain.model.BulkRORecognisedProductsUpdateMapV1;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BulkROProductUpdateDataSetup {

    public static List<BulkRORecognisedProductsUpdateDataV1> getLoadROProductUpdateDataV1List() {
        List<BulkRORecognisedProductsUpdateDataV1> loadROProductUpdateDataV1List =
                new ArrayList<>();
        BulkRORecognisedProductsUpdateDataV1 loadROProductUpdateDataV1 =
                new BulkRORecognisedProductsUpdateDataV1();
        loadROProductUpdateDataV1.setOrganisationId("123");
        loadROProductUpdateDataV1.setRecognisedProduct("IOC");
        loadROProductUpdateDataV1List.add(loadROProductUpdateDataV1);
        return loadROProductUpdateDataV1List;
    }

    public static Map<String, BulkROProductsUpdateRecordEvent> getEventsMap(
            final BaseEvent<BaseHeader> baseEvent,
            final BulkRORecognisedProductsUpdateDataV1 loadROProductUpdateDataV1) {
        Map<String, BulkROProductsUpdateRecordEvent> eventsMap = new HashMap<>();
        BulkROProductsUpdateRecordEvent loadROProductUpdateRecordEvent =
                new BulkROProductsUpdateRecordEvent();
        loadROProductUpdateRecordEvent.setEvent(baseEvent);
        loadROProductUpdateRecordEvent.setBulkRoProductsUpdateRecord(loadROProductUpdateDataV1);
        eventsMap.put("1", loadROProductUpdateRecordEvent);
        return eventsMap;
    }

    public static BaseEvent<BaseHeader> getROUpdatedEvent(final RecognisingOrganisation publishRo)
            throws JsonProcessingException {
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        BaseHeader baseHeader = (BaseHeader) OrganisationTestUtil.generateEventHeader();
        baseHeader.setEventName(OrganisationConstants.EventType.RO_UPDATED_EVENT);
        baseEvent.setEventHeader(baseHeader);
        baseEvent.setEventBody(
                new ObjectMapper()
                        .writeValueAsString(
                                CreateOrganisationDataSetup.entityToEventMapper(publishRo)));
        return baseEvent;
    }

    public static BaseEvent<BaseHeader> getROChangedRejectedEvent() {
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        BaseHeader baseHeader = (BaseHeader) OrganisationTestUtil.generateEventHeader();
        baseHeader.setEventName(OrganisationConstants.EventType.RO_UPDATE_REJECTED_EVENT);
        baseEvent.setEventHeader(baseHeader);
        baseEvent.setEventErrors(
                new BaseEventErrors(
                        OrganisationTestUtil.getROErrorResponse(
                                        "V0004",
                                        "Organisation Name is Empty",
                                        "Mandatory Field Validation Failure - OrganisationName")
                                .getErrorList()));
        return baseEvent;
    }

    public static BulkRORecognisedProductUpdateMessageV1 getLoadROProductUpdateMessageV1(
            final BulkRORecognisedProductsUpdateDataV1 loadROProductUpdateDataV1) {
        BulkRORecognisedProductUpdateMessageV1 loadROProductUpdateMessageV1 =
                new BulkRORecognisedProductUpdateMessageV1();
        BulkRORecognisedProductsUpdateMapV1 loadROProductUpdateMapV1 =
                new BulkRORecognisedProductsUpdateMapV1();
        loadROProductUpdateMapV1.put("1", loadROProductUpdateDataV1);
        loadROProductUpdateMessageV1.setMsg(loadROProductUpdateMapV1);
        return loadROProductUpdateMessageV1;
    }
}
