package com.ielts.cmds.organisation.domain.validators;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import com.ielts.cmds.api.roui005rosearchrequested.RoSearchCriteria;
import com.ielts.cmds.api.roui005rosearchrequested.RoSearchObject;
import com.ielts.cmds.api.roui007rocreaterequested.OrganisationStatusEnum;
import com.ielts.cmds.api.roui007rocreaterequested.VerificationStatusEnum;
import java.util.UUID;
import java.util.stream.Stream;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class SearchRoCriteriaValidatorTest {

    @InjectMocks private SearchRoCriteriaValidator searchRoCriteriaValidator;

    @ParameterizedTest
    @MethodSource("provideArgumentsForInvalidSearchCriteria")
    void whenSearchCriteria_IsValid_ExpectValidationToBeFalse(final RoSearchObject roSearchObject) {
        assertFalse(searchRoCriteriaValidator.isValid(roSearchObject));
    }

    @ParameterizedTest
    @MethodSource("provideArgumentsForValidSearchCriteria")
    void whenSearchCriteria_IsValid_ExpectValidationToBeTrue(final RoSearchObject roSearchObject) {
        assertTrue(searchRoCriteriaValidator.isValid(roSearchObject));
    }

    private static Stream<Arguments> provideArgumentsForInvalidSearchCriteria() {

        final RoSearchObject roSearchObject = new RoSearchObject();
        roSearchObject.setCriteria(new RoSearchCriteria());

        return Stream.of(Arguments.of(roSearchObject));
    }

    private static Stream<Arguments> provideArgumentsForValidSearchCriteria() {

        final RoSearchObject onlyCity = new RoSearchObject();
        final RoSearchCriteria onlyCityCriteria = new RoSearchCriteria();
        onlyCityCriteria.setCity("Cambridge");
        onlyCity.setCriteria(onlyCityCriteria);

        final RoSearchObject onlyContactName = new RoSearchObject();
        final RoSearchCriteria onlyContactNameCriteria = new RoSearchCriteria();
        onlyContactNameCriteria.setContactName("Partner Contact");
        onlyContactName.setCriteria(onlyContactNameCriteria);

        final RoSearchObject onlyContactEmail = new RoSearchObject();
        final RoSearchCriteria onlyContactEmailCriteria = new RoSearchCriteria();
        onlyContactEmailCriteria.setContactEmail("alan@gmail.com");
        onlyContactEmail.setCriteria(onlyContactEmailCriteria);

        final RoSearchObject onlyOrgId = new RoSearchObject();
        final RoSearchCriteria onlyOrgIdCriteria = new RoSearchCriteria();
        onlyOrgIdCriteria.setOrganisationId(321);
        onlyOrgId.setCriteria(onlyOrgIdCriteria);

        final RoSearchObject onlyOrgTypeUuid = new RoSearchObject();
        final RoSearchCriteria onlyOrgTypeUuidCriteria = new RoSearchCriteria();
        onlyOrgTypeUuidCriteria.setOrganisationTypeUuid(UUID.randomUUID());
        onlyOrgTypeUuid.setCriteria(onlyOrgTypeUuidCriteria);

        final RoSearchObject onlyVerificationStatus = new RoSearchObject();
        final RoSearchCriteria onlyVerificationStatusCriteria = new RoSearchCriteria();
        onlyVerificationStatusCriteria.setVerificationStatus(RoSearchCriteria.VerificationStatusEnum.valueOf(VerificationStatusEnum.APPROVED.getValue()));
        onlyVerificationStatus.setCriteria(onlyVerificationStatusCriteria);

        final RoSearchObject onlyPartnerCode = new RoSearchObject();
        final RoSearchCriteria onlyPartnerCodeCriteria = new RoSearchCriteria();
        onlyPartnerCodeCriteria.setPartnerCode("IDP");
        onlyPartnerCode.setCriteria(onlyPartnerCodeCriteria);

        final RoSearchObject onlyPostalCode = new RoSearchObject();
        final RoSearchCriteria onlyPostalCodeCriteria = new RoSearchCriteria();
        onlyPostalCodeCriteria.setPostalCode("DBP 01");
        onlyPostalCode.setCriteria(onlyPostalCodeCriteria);

        final RoSearchObject onlyOrgStatus = new RoSearchObject();
        final RoSearchCriteria onlyOrgStatusCriteria = new RoSearchCriteria();
        onlyOrgStatusCriteria.setOrganisationStatus(RoSearchCriteria.OrganisationStatusEnum.valueOf(OrganisationStatusEnum.ACTIVE.getValue()));
        onlyOrgStatus.setCriteria(onlyOrgStatusCriteria);

        final RoSearchObject onlyOrgName = new RoSearchObject();
        final RoSearchCriteria onlyOrgNameCriteria = new RoSearchCriteria();
        onlyOrgNameCriteria.setOrganisationName("London Metropolitan University");
        onlyOrgName.setCriteria(onlyOrgNameCriteria);
        
        final RoSearchObject bothCountryAndTerritory = new RoSearchObject();
        final RoSearchCriteria bothCountryAndTerritoryCriteria = new RoSearchCriteria();
        bothCountryAndTerritoryCriteria.setCountry(UUID.fromString("029fd27d-b39a-48b4-87e7-131a063bea2d"));
        bothCountryAndTerritoryCriteria.setTerritory(UUID.fromString("029fd27d-b39a-48b4-87e7-131a063bea2d"));
        bothCountryAndTerritory.setCriteria(bothCountryAndTerritoryCriteria);

        return Stream.of(
                Arguments.of(onlyCity),
                Arguments.of(onlyContactName),
                Arguments.of(onlyContactEmail),
                Arguments.of(onlyOrgId),
                Arguments.of(onlyOrgTypeUuid),
                Arguments.of(onlyPartnerCode),
                Arguments.of(onlyPostalCode),
                Arguments.of(onlyOrgName),
                Arguments.of(onlyOrgStatus),
                Arguments.of(bothCountryAndTerritory),
                Arguments.of(onlyVerificationStatus));
    }
}
