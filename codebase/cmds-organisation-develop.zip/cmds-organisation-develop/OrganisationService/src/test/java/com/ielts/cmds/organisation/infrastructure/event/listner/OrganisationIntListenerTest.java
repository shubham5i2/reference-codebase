package com.ielts.cmds.organisation.infrastructure.event.listner;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OrganisationIntListenerTest {

    @InjectMocks
    private OrganisationIntListener organisationIntListener;

    @Test
    void whenValidExtSqsMessageIsReceived_ThenNoExceptionIsRaised() {
        Message<String> message = new Message() {
            @Override
            public Object getPayload() {
                return "Payload";
            }

            @Override
            public MessageHeaders getHeaders() {
                return null;
            }
        };
        OrganisationIntListener organisationIntListenerSpy = Mockito.spy(organisationIntListener);
        doNothing().when(organisationIntListenerSpy).onReceive(message.getHeaders(), message.getPayload());
        organisationIntListenerSpy.on(message);

        verify(organisationIntListenerSpy, times(1)).onReceive(message.getHeaders(), message.getPayload());
    }
}
