package com.ielts.cmds.organisation.domain.validators;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import com.ielts.cmds.api.roui007rocreaterequested.*;
import com.ielts.cmds.organisation.domain.model.RoDataCreateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.Address;
import com.ielts.cmds.organisation.infrastructure.entity.OrganisationType;
import com.ielts.cmds.organisation.infrastructure.repository.AddressRepository;
import com.ielts.cmds.organisation.infrastructure.repository.AddressTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.ContactTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.CountryRepository;
import com.ielts.cmds.organisation.infrastructure.repository.ModuleTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.OrganisationTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.PartnerCodeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.infrastructure.repository.SectorTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.TerritoryRepository;
import com.ielts.cmds.organisation.utills.CreateOrganisationDataSetup;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import javax.validation.ConstraintValidatorContext;
import javax.validation.ConstraintValidatorContext.ConstraintViolationBuilder;
import javax.validation.ConstraintValidatorContext.ConstraintViolationBuilder.NodeBuilderCustomizableContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

/** @author cts */
@ExtendWith(MockitoExtension.class)
class CheckRODetailsValidatorTest {

    @Spy private CheckRODetailsValidator rovoDetailsValidator;

    @Mock private CheckOrganisationDetailsValidator orgDetailsValidator;

    @Mock private ConstraintValidatorContext context;

    @Mock private ConstraintViolationBuilder builder;

    @Mock private OrganisationTypeRepository orgTypeRepository;

    @Mock private ContactTypeRepository contactTypeRepository;

    @Mock private SectorTypeRepository sectorTypeRepository;

    @Mock private AddressTypeRepository addressTypeRepository;

    @Mock private AddressRepository addressRepository;

    @Mock private CountryRepository countryRepository;

    @Mock private PartnerCodeRepository partnerRepository;

    @Mock private TerritoryRepository territoryRepository;

    @Mock private ModuleTypeRepository moduleTypeRepository;

    @Mock private RecognisingOrganisationRepository recognisingOrganisationRepository;

    @Mock private NodeBuilderCustomizableContext nodeBuilderCustomizableContext;

    /** @throws Exception */
    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(rovoDetailsValidator, "orgTypeRepository", orgTypeRepository);
        ReflectionTestUtils.setField(
                rovoDetailsValidator, "contactTypeRepository", contactTypeRepository);
        ReflectionTestUtils.setField(
                rovoDetailsValidator, "sectorTypeRepository", sectorTypeRepository);
        ReflectionTestUtils.setField(
                rovoDetailsValidator, "addressTypeRepository", addressTypeRepository);
        ReflectionTestUtils.setField(rovoDetailsValidator, "addressRepository", addressRepository);
        ReflectionTestUtils.setField(rovoDetailsValidator, "countryRepository", countryRepository);
        ReflectionTestUtils.setField(rovoDetailsValidator, "partnerRepository", partnerRepository);
        ReflectionTestUtils.setField(
                rovoDetailsValidator, "territoryRepository", territoryRepository);
        ReflectionTestUtils.setField(
                rovoDetailsValidator, "moduleTypeRepository", moduleTypeRepository);
        ReflectionTestUtils.setField(
                rovoDetailsValidator,
                "recognisingOrganisationRepository",
                recognisingOrganisationRepository);
        ReflectionTestUtils.setField(
                orgDetailsValidator,
                "recognisingOrganisationRepository",
                recognisingOrganisationRepository);
    }

    @Test
    void testValidationFailureIfOrgTypeIsEmpty() {
        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.organisationTypeUuid}");
        doReturn(nodeBuilderCustomizableContext)
                .when(builder)
                .addPropertyNode("organisationTypeUuid");

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }

    @Test
    void testValidationSuccessIfVerificationStatusIsVerifiedForRO() {
        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        roDataCreateV1.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.VERIFIED.getValue()));
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(rovoDetailsValidator)
                .checkAllCommonFieldsForROVO(roDataCreateV1, context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidLinkedOrganisations(roDataCreateV1, context, true);
        doReturn(true).when(rovoDetailsValidator).isValidContact(roDataCreateV1, context, true);
        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(true, isValid);
    }

    @Test
    void testValidationFailureIfMethodOfDeliveryIsInvalid() {
        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        roDataCreateV1.setMethodOfDelivery(null);
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(rovoDetailsValidator)
                .checkAllCommonFieldsForROVO(roDataCreateV1, context, true);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidLinkedOrganisations(roDataCreateV1, context, false);
        doReturn(false).when(rovoDetailsValidator).isValidContact(roDataCreateV1, context, false);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.methodOfDelivery}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("methodOfDelivery");

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }

    @Test
    void testValidationFailureIfWebsiteUrlIsEmptyOrInvalid() {
        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        roDataCreateV1.setWebsiteUrl(null);
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(rovoDetailsValidator)
                .checkAllCommonFieldsForROVO(roDataCreateV1, context, true);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidLinkedOrganisations(roDataCreateV1, context, false);
        doReturn(false).when(rovoDetailsValidator).isValidContact(roDataCreateV1, context, false);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.websiteUrl}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("websiteUrl");

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }

    @Test
    void testValidationFailureIfContactIsEmpty() {
        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(rovoDetailsValidator)
                .checkAllCommonFieldsForROVO(roDataCreateV1, context, true);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidLinkedOrganisations(roDataCreateV1, context, false);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.contacts}");
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.primaryContact}");
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.resultsAdminContact}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("contacts");

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }

    @Test
    void testValidationFailureIfAddressIsEmptyForContacts() {
        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        List<RoDataCreateAddress> address = roDataCreateV1.getContacts().get(0).getAddresses();
        address.get(0).setEmail(null);
        List<RoDataCreateContact> contacts = roDataCreateV1.getContacts();
        contacts.get(0).setAddresses(address);
        roDataCreateV1.setContacts(contacts);
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(rovoDetailsValidator)
                .checkAllCommonFieldsForROVO(roDataCreateV1, context, true);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidLinkedOrganisations(roDataCreateV1, context, false);
        when(contactTypeRepository.findById(
                        roDataCreateV1.getContacts().get(0).getContactTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getPrimaryContactTypeData()));
        when(contactTypeRepository.findById(
                        roDataCreateV1.getContacts().get(1).getContactTypeUuid()))
                .thenReturn(
                        Optional.of(CreateOrganisationDataSetup.getResultsAdminContactTypeData()));
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.email.Primary}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("addresses");

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }

    @Test
    void testValidationFailureIfEmailIsInvalidForContactsAddresses() {
        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        List<RoDataCreateAddress> address = roDataCreateV1.getContacts().get(0).getAddresses();
        address.get(0).setEmail(".com");
        List<RoDataCreateContact> contacts = roDataCreateV1.getContacts();
        contacts.get(0).setAddresses(address);
        roDataCreateV1.setContacts(contacts);
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(rovoDetailsValidator)
                .checkAllCommonFieldsForROVO(roDataCreateV1, context, true);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidLinkedOrganisations(roDataCreateV1, context, false);
        when(contactTypeRepository.findById(
                        roDataCreateV1.getContacts().get(0).getContactTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getPrimaryContactTypeData()));
        when(contactTypeRepository.findById(
                        roDataCreateV1.getContacts().get(1).getContactTypeUuid()))
                .thenReturn(
                        Optional.of(CreateOrganisationDataSetup.getResultsAdminContactTypeData()));
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.email.Primary}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("addresses");

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }

    @Test
    void testValidationFailureIfKnownNameIsInvalidForContacts() {
        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        List<RoDataCreateContact> contacts = roDataCreateV1.getContacts();
        contacts.get(0).setFirstName("");
        roDataCreateV1.setContacts(contacts);
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(rovoDetailsValidator)
                .checkAllCommonFieldsForROVO(roDataCreateV1, context, true);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidLinkedOrganisations(roDataCreateV1, context, false);
        when(contactTypeRepository.findById(
                        roDataCreateV1.getContacts().get(0).getContactTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getPrimaryContactTypeData()));
        when(contactTypeRepository.findById(
                        roDataCreateV1.getContacts().get(1).getContactTypeUuid()))
                .thenReturn(
                        Optional.of(CreateOrganisationDataSetup.getResultsAdminContactTypeData()));
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.firstName.Primary}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("contacts");

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }

    @Test
    void testValidationFailureIfLastNameIsEmptyForContacts() {
        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        List<RoDataCreateContact> contacts = roDataCreateV1.getContacts();
        contacts.get(0).setLastName("");
        roDataCreateV1.setContacts(contacts);
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(rovoDetailsValidator)
                .checkAllCommonFieldsForROVO(roDataCreateV1, context, true);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidLinkedOrganisations(roDataCreateV1, context, false);
        when(contactTypeRepository.findById(
                        roDataCreateV1.getContacts().get(0).getContactTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getPrimaryContactTypeData()));
        when(contactTypeRepository.findById(
                        roDataCreateV1.getContacts().get(1).getContactTypeUuid()))
                .thenReturn(
                        Optional.of(CreateOrganisationDataSetup.getResultsAdminContactTypeData()));
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.lastName.Primary}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("contacts");

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }

    @Test
    void testValidationFailureIfVerificationStatusIsInvalidForVO() {
        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        OrganisationType orgType = CreateOrganisationDataSetup.getOrganisationTypeData();
        orgType.setOrganisationsType("VO");
        orgType.setDescription("Verified Organisation");
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(orgType));
        doReturn(true)
                .when(rovoDetailsValidator)
                .checkAllCommonFieldsForROVO(roDataCreateV1, context, true);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidLinkedOrganisations(roDataCreateV1, context, false);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.verificationStatus}");
        doReturn(nodeBuilderCustomizableContext)
                .when(builder)
                .addPropertyNode("verificationStatus");

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }

    @Test
    void testValidationFailureIfMethodOfDeliveryIsInvalidForVO() {
        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        roDataCreateV1.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.VERIFIED.getValue()));
        roDataCreateV1.setMethodOfDelivery(MethodOfDeliveryEnum.E_DELIVERY);

        OrganisationType orgType = CreateOrganisationDataSetup.getOrganisationTypeData();
        orgType.setOrganisationsType("VO");
        orgType.setDescription("Verified Organisation");
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(orgType));
        doReturn(true)
                .when(rovoDetailsValidator)
                .checkAllCommonFieldsForROVO(roDataCreateV1, context, true);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidLinkedOrganisations(roDataCreateV1, context, false);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.methodOfDelivery}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("methodOfDelivery");

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("Validate Organisation Name")
    @Test
    void testValidationFailureIfOrgNameIsEmpty() {

        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        roDataCreateV1.setOrganisationName(null);
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(false).when(rovoDetailsValidator).isValidContact(roDataCreateV1, context, false);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidPartnerCode(roDataCreateV1.getPartnerCode(), context, false);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidSectorType(roDataCreateV1.getSectorTypeUuid(), context, false);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidAddress(roDataCreateV1.getAddresses(), context, false);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidMinimumScores(roDataCreateV1.getMinimumScores(), context, false);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidLinkedOrganisations(roDataCreateV1, context, false);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.organisationName}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("organisationName");

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("Validate Partner Code")
    @Test
    void testValidationFailureIfPartnerCodeisInvalidOrEmpty() {

        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        roDataCreateV1.setPartnerCode("Inactive");
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(rovoDetailsValidator)
                .isEmptyOrganisationName(roDataCreateV1.getOrganisationName(), context, true);
        doReturn(false).when(rovoDetailsValidator).isValidContact(roDataCreateV1, context, false);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidSectorType(roDataCreateV1.getSectorTypeUuid(), context, false);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidAddress(roDataCreateV1.getAddresses(), context, false);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidMinimumScores(roDataCreateV1.getMinimumScores(), context, false);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidLinkedOrganisations(roDataCreateV1, context, false);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.partnerCode}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("partnerCode");
        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("Validate Sector Type")
    @Test
    void testValidationFailureIfSectorTypeIsInvalidOrEmpty() {
        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        roDataCreateV1.setSectorTypeUuid(null);

        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.sectorTypeUuid}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("sectorTypeUuid");
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(rovoDetailsValidator)
                .isEmptyOrganisationName(roDataCreateV1.getOrganisationName(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidPartnerCode(roDataCreateV1.getPartnerCode(), context, true);
        doReturn(false).when(rovoDetailsValidator).isValidContact(roDataCreateV1, context, false);

        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidAddress(roDataCreateV1.getAddresses(), context, false);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidMinimumScores(roDataCreateV1.getMinimumScores(), context, false);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidLinkedOrganisations(roDataCreateV1, context, false);
        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("Validate Address Type")
    @Test
    void testValidationFailureIfAddressTypeIsInvalidOrEmpty() {

        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(rovoDetailsValidator)
                .isEmptyOrganisationName(roDataCreateV1.getOrganisationName(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidPartnerCode(roDataCreateV1.getPartnerCode(), context, true);
        doReturn(false).when(rovoDetailsValidator).isValidContact(roDataCreateV1, context, false);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidSectorType(roDataCreateV1.getSectorTypeUuid(), context, true);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidMinimumScores(roDataCreateV1.getMinimumScores(), context, false);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidLinkedOrganisations(roDataCreateV1, context, false);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.addressTypeName}");
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.mainAddress}");
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.deliveryAddress}");
        doReturn(nodeBuilderCustomizableContext)
                .when(builder)
                .addPropertyNode(OrganisationConstants.GenericConstants.ADDRESS_PROPERTY_NODE);

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("Validate Address Lines")
    @Test
    void testValidationFailureIfAddressLineIsEmpty() {

        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        List<RoDataCreateAddress> address = roDataCreateV1.getAddresses();
        address.get(0).setAddressLine1("");
        roDataCreateV1.setAddresses(address);
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(rovoDetailsValidator)
                .isEmptyOrganisationName(roDataCreateV1.getOrganisationName(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidPartnerCode(roDataCreateV1.getPartnerCode(), context, true);
        doReturn(false).when(rovoDetailsValidator).isValidContact(roDataCreateV1, context, false);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidSectorType(roDataCreateV1.getSectorTypeUuid(), context, true);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidMinimumScores(roDataCreateV1.getMinimumScores(), context, false);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidLinkedOrganisations(roDataCreateV1, context, false);
        when(addressTypeRepository.findById(
                        UUID.fromString("d13761e9-c134-4f80-a0a8-239a683a9c00")))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getDeliveryAddressTypeData()));
        when(addressTypeRepository.findById(
                        roDataCreateV1.getAddresses().get(0).getAddressTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getAddressTypeData()));
        when(countryRepository.findById(roDataCreateV1.getAddresses().get(0).getCountryUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getCountryData()));
        when(territoryRepository.findById(roDataCreateV1.getAddresses().get(0).getTerritoryUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getTerritoryData()));
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate(
                        "{cmds.invalid.addressline1."
                                + CreateOrganisationDataSetup.getAddressTypeData()
                                        .getAddressTypeName()
                                + "}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("addresses");

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("Validate City")
    @Test
    void testValidationFailureIfCityIsEmpty() {

        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        List<RoDataCreateAddress> address = roDataCreateV1.getAddresses();
        address.get(0).setCity("");
        roDataCreateV1.setAddresses(address);
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(rovoDetailsValidator)
                .isEmptyOrganisationName(roDataCreateV1.getOrganisationName(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidPartnerCode(roDataCreateV1.getPartnerCode(), context, true);
        doReturn(false).when(rovoDetailsValidator).isValidContact(roDataCreateV1, context, false);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidSectorType(roDataCreateV1.getSectorTypeUuid(), context, true);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidMinimumScores(roDataCreateV1.getMinimumScores(), context, false);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidLinkedOrganisations(roDataCreateV1, context, false);
        when(addressTypeRepository.findById(
                        UUID.fromString("d13761e9-c134-4f80-a0a8-239a683a9c00")))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getDeliveryAddressTypeData()));
        when(addressTypeRepository.findById(
                        roDataCreateV1.getAddresses().get(0).getAddressTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getAddressTypeData()));
        when(countryRepository.findById(roDataCreateV1.getAddresses().get(0).getCountryUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getCountryData()));
        when(territoryRepository.findById(roDataCreateV1.getAddresses().get(0).getTerritoryUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getTerritoryData()));
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate(
                        "{cmds.invalid.city."
                                + CreateOrganisationDataSetup.getAddressTypeData()
                                        .getAddressTypeName()
                                + "}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("addresses");

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("Validate Country Name")
    @Test
    void testValidationFailureIfCountryIsEmpty() {

        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        List<RoDataCreateAddress> address = roDataCreateV1.getAddresses();
        address.get(0).setCountryUuid(null);
        roDataCreateV1.setAddresses(address);
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(rovoDetailsValidator)
                .isEmptyOrganisationName(roDataCreateV1.getOrganisationName(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidPartnerCode(roDataCreateV1.getPartnerCode(), context, true);
        doReturn(false).when(rovoDetailsValidator).isValidContact(roDataCreateV1, context, false);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidSectorType(roDataCreateV1.getSectorTypeUuid(), context, true);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidMinimumScores(roDataCreateV1.getMinimumScores(), context, false);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidLinkedOrganisations(roDataCreateV1, context, false);
        when(addressTypeRepository.findById(
                        UUID.fromString("d13761e9-c134-4f80-a0a8-239a683a9c00")))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getDeliveryAddressTypeData()));
        when(addressTypeRepository.findById(
                        roDataCreateV1.getAddresses().get(0).getAddressTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getAddressTypeData()));
        when(territoryRepository.findById(roDataCreateV1.getAddresses().get(0).getTerritoryUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getTerritoryData()));
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate(
                        "{cmds.invalid.countryName."
                                + CreateOrganisationDataSetup.getAddressTypeData()
                                        .getAddressTypeName()
                                + "}");
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.countryName.Delivery}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("addresses");

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("Validate TerritoryUuid")
    @Test
    void testValidationFailureIfTerritoryIsInvalid() {

        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        List<RoDataCreateAddress> address = roDataCreateV1.getAddresses();
        address.get(0).setTerritoryUuid(UUID.fromString("d13761e9-c134-4f80-a0a8-239a683a9c00"));
        roDataCreateV1.setAddresses(address);
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(rovoDetailsValidator)
                .isEmptyOrganisationName(roDataCreateV1.getOrganisationName(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidPartnerCode(roDataCreateV1.getPartnerCode(), context, true);
        doReturn(false).when(rovoDetailsValidator).isValidContact(roDataCreateV1, context, false);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidSectorType(roDataCreateV1.getSectorTypeUuid(), context, true);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidMinimumScores(roDataCreateV1.getMinimumScores(), context, false);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidLinkedOrganisations(roDataCreateV1, context, false);
        when(addressTypeRepository.findById(
                        UUID.fromString("d13761e9-c134-4f80-a0a8-239a683a9c00")))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getDeliveryAddressTypeData()));
        when(addressTypeRepository.findById(
                        roDataCreateV1.getAddresses().get(0).getAddressTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getAddressTypeData()));
        when(countryRepository.findById(roDataCreateV1.getAddresses().get(0).getCountryUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getCountryData()));
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate(
                        "{cmds.invalid.territoryUuid."
                                + CreateOrganisationDataSetup.getAddressTypeData()
                                        .getAddressTypeName()
                                + "}");
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.territoryUuid.Delivery}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("addresses");

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("Validate ModuleTypeUuid")
    @Test
    void testValidationFailureIfModuleTypeUuidIsInvalid() {

        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(rovoDetailsValidator)
                .isEmptyOrganisationName(roDataCreateV1.getOrganisationName(), context, true);
        doReturn(false).when(rovoDetailsValidator).isValidContact(roDataCreateV1, context, false);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidPartnerCode(roDataCreateV1.getPartnerCode(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidSectorType(roDataCreateV1.getSectorTypeUuid(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidAddress(roDataCreateV1.getAddresses(), context, true);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidLinkedOrganisations(roDataCreateV1, context, false);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.moduleTypeUuid}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("minimumScores");

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }

    @Test
    void testValidationFailureIfEmailIsDuplicate() {
        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        List<RoDataCreateAddress> address = roDataCreateV1.getContacts().get(1).getAddresses();
        address.get(0).setEmail("alan@gmail.com");
        Address address1 = new Address();
        address1.setEmail("alan@gmail.com");
        List<RoDataCreateContact> contacts = roDataCreateV1.getContacts();
        contacts.get(0).setAddresses(address);
        roDataCreateV1.setContacts(contacts);
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(rovoDetailsValidator)
                .checkAllCommonFieldsForROVO(roDataCreateV1, context, true);
        doReturn(false)
                .when(rovoDetailsValidator)
                .isValidLinkedOrganisations(roDataCreateV1, context, false);
        when(contactTypeRepository.findById(
                        roDataCreateV1.getContacts().get(0).getContactTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getPrimaryContactTypeData()));
        when(contactTypeRepository.findById(
                        roDataCreateV1.getContacts().get(1).getContactTypeUuid()))
                .thenReturn(
                        Optional.of(CreateOrganisationDataSetup.getResultsAdminContactTypeData()));
        when(addressRepository.findByEmailAndContactContactUuidIsNotNull("alan@gmail.com"))
                .thenReturn(Collections.singletonList(address1));
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.email.Duplicate}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("addresses");

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("Validate TargetRecognisingOrganisationUuid")
    @Test
    void testValidationFailureIfTargetRecognisingOrganisationUuidIsInvalid() {

        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        roDataCreateV1.setLinkedOrganisations(
                CreateOrganisationDataSetup.getLinkedOrganisationsData());
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(rovoDetailsValidator)
                .isEmptyOrganisationName(roDataCreateV1.getOrganisationName(), context, true);
        doReturn(true).when(rovoDetailsValidator).isValidContact(roDataCreateV1, context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidPartnerCode(roDataCreateV1.getPartnerCode(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidSectorType(roDataCreateV1.getSectorTypeUuid(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidAddress(roDataCreateV1.getAddresses(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidMinimumScores(roDataCreateV1.getMinimumScores(), context, true);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate(
                        "{cmds.invalid.targetRecognisingOrganisation.parentro}");
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate(
                        "{cmds.invalid.targetRecognisingOrganisation.resultsdelivery}");
        doReturn(nodeBuilderCustomizableContext)
                .when(builder)
                .addPropertyNode(
                        OrganisationConstants.GenericConstants.LINKED_ORGANISATIONS_PROPERTY_NODE);

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("Validate TargetRecognisingOrganisationUuid")
    @Test
    void testValidationFailureIfThereIsMoreThanOneParent() {

        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        roDataCreateV1.setLinkedOrganisations(
                CreateOrganisationDataSetup.getLinkedOrganisationsData());
        roDataCreateV1
                .getLinkedOrganisations()
                .addAll(CreateOrganisationDataSetup.getLinkedOrganisationsData());
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        when(recognisingOrganisationRepository.findById(
                        roDataCreateV1
                                .getLinkedOrganisations()
                                .get(0)
                                .getTargetRecognisingOrganisationUuid()))
                .thenReturn(
                        Optional.of(CreateOrganisationDataSetup.getExistingOrganisationDetails()));
        doReturn(true)
                .when(rovoDetailsValidator)
                .isEmptyOrganisationName(roDataCreateV1.getOrganisationName(), context, true);
        doReturn(true).when(rovoDetailsValidator).isValidContact(roDataCreateV1, context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidPartnerCode(roDataCreateV1.getPartnerCode(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidSectorType(roDataCreateV1.getSectorTypeUuid(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidAddress(roDataCreateV1.getAddresses(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidMinimumScores(roDataCreateV1.getMinimumScores(), context, true);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate(
                        "{cmds.invalid.linkedRecognisingOrganisationType}");
        doReturn(nodeBuilderCustomizableContext)
                .when(builder)
                .addPropertyNode(
                        OrganisationConstants.GenericConstants.LINKED_ORGANISATIONS_PROPERTY_NODE);

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }
    @DisplayName("Validate EffectiveFromDateisAfterToDate")
    @Test
    void testValidationFailureIfEffectiveFromDateisAfterToDate() {

        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        roDataCreateV1.setLinkedOrganisations(
                CreateOrganisationDataSetup.getLinkedOrganisationsData());
        roDataCreateV1
                .getLinkedOrganisations()
                .get(0)
                .setLinkEffectiveFromDateTime(
                        LocalDateTime.of(2025, Month.NOVEMBER, 23, 05, 52, 55).atOffset(ZoneOffset.UTC));
        roDataCreateV1
                .getLinkedOrganisations()
                .get(0)
                .setLinkEffectiveToDateTime(LocalDateTime.of(2022, Month.NOVEMBER, 23, 05, 52, 55).atOffset(ZoneOffset.UTC));
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        when(recognisingOrganisationRepository.findById(
                        roDataCreateV1
                                .getLinkedOrganisations()
                                .get(0)
                                .getTargetRecognisingOrganisationUuid()))
                .thenReturn(
                        Optional.of(CreateOrganisationDataSetup.getExistingOrganisationDetails()));
        doReturn(true)
                .when(rovoDetailsValidator)
                .isEmptyOrganisationName(roDataCreateV1.getOrganisationName(), context, true);
        doReturn(true).when(rovoDetailsValidator).isValidContact(roDataCreateV1, context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidPartnerCode(roDataCreateV1.getPartnerCode(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidSectorType(roDataCreateV1.getSectorTypeUuid(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidAddress(roDataCreateV1.getAddresses(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidMinimumScores(roDataCreateV1.getMinimumScores(), context, true);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.effectiveFromDatetime}");
        doReturn(nodeBuilderCustomizableContext)
                .when(builder)
                .addPropertyNode(
                        OrganisationConstants.GenericConstants.LINKED_ORGANISATIONS_PROPERTY_NODE);

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }

    @Test
    void testValidationFailureIfResultAvailableForYearsIsLessThan2() {
        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        roDataCreateV1.setResultAvailableForYears(1);
        roDataCreateV1.setLinkedOrganisations(
                CreateOrganisationDataSetup.getLinkedOrganisationsData());
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        when(recognisingOrganisationRepository.findById(
                        roDataCreateV1
                                .getLinkedOrganisations()
                                .get(0)
                                .getTargetRecognisingOrganisationUuid()))
                .thenReturn(
                        Optional.of(CreateOrganisationDataSetup.getExistingOrganisationDetails()));
        doReturn(true)
                .when(rovoDetailsValidator)
                .isEmptyOrganisationName(roDataCreateV1.getOrganisationName(), context, true);
        doReturn(true).when(rovoDetailsValidator).isValidContact(roDataCreateV1, context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidPartnerCode(roDataCreateV1.getPartnerCode(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidSectorType(roDataCreateV1.getSectorTypeUuid(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidAddress(roDataCreateV1.getAddresses(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidMinimumScores(roDataCreateV1.getMinimumScores(), context, true);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.resultAvailableForYears}");
        doReturn(nodeBuilderCustomizableContext)
                .when(builder)
                .addPropertyNode(OrganisationConstants.GenericConstants.RESULT_AVAILABLE_FOR_YEARS);

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }

    @Test
    void testValidationFailureIfResultAvailableForYearsIsGreaterThan10() {
        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        roDataCreateV1.setResultAvailableForYears(11);
        roDataCreateV1.setLinkedOrganisations(
                CreateOrganisationDataSetup.getLinkedOrganisationsData());
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        when(recognisingOrganisationRepository.findById(
                        roDataCreateV1
                                .getLinkedOrganisations()
                                .get(0)
                                .getTargetRecognisingOrganisationUuid()))
                .thenReturn(
                        Optional.of(CreateOrganisationDataSetup.getExistingOrganisationDetails()));
        doReturn(true)
                .when(rovoDetailsValidator)
                .isEmptyOrganisationName(roDataCreateV1.getOrganisationName(), context, true);
        doReturn(true).when(rovoDetailsValidator).isValidContact(roDataCreateV1, context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidPartnerCode(roDataCreateV1.getPartnerCode(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidSectorType(roDataCreateV1.getSectorTypeUuid(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidAddress(roDataCreateV1.getAddresses(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidMinimumScores(roDataCreateV1.getMinimumScores(), context, true);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.resultAvailableForYears}");
        doReturn(nodeBuilderCustomizableContext)
                .when(builder)
                .addPropertyNode(OrganisationConstants.GenericConstants.RESULT_AVAILABLE_FOR_YEARS);

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }
    @Test
    void testValidationFailureIfACAndGTareNull () {
        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        roDataCreateV1.setAcceptsAC(null);
        roDataCreateV1.setAcceptsGT(null);
        roDataCreateV1.setLinkedOrganisations(
                CreateOrganisationDataSetup.getLinkedOrganisationsData());
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        when(recognisingOrganisationRepository.findById(
                roDataCreateV1
                        .getLinkedOrganisations()
                        .get(0)
                        .getTargetRecognisingOrganisationUuid()))
                .thenReturn(
                        Optional.of(CreateOrganisationDataSetup.getExistingOrganisationDetails()));
        doReturn(true)
                .when(rovoDetailsValidator)
                .isEmptyOrganisationName(roDataCreateV1.getOrganisationName(), context, true);
        doReturn(false).when(rovoDetailsValidator).isValidContact(roDataCreateV1, context, false);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidPartnerCode(roDataCreateV1.getPartnerCode(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidSectorType(roDataCreateV1.getSectorTypeUuid(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidAddress(roDataCreateV1.getAddresses(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidMinimumScores(roDataCreateV1.getMinimumScores(), context, true);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.productAcceptance}");
        doReturn(nodeBuilderCustomizableContext)
                .when(builder)
                .addPropertyNode(OrganisationConstants.GenericConstants.PRODUCT_ACCEPTANCE);

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }
    @Test
    void testValidationFailureIfACFalseAndGTareNull () {
        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        roDataCreateV1.setAcceptsAC(false);
        roDataCreateV1.setAcceptsGT(null);
        roDataCreateV1.setLinkedOrganisations(
                CreateOrganisationDataSetup.getLinkedOrganisationsData());
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        when(recognisingOrganisationRepository.findById(
                roDataCreateV1
                        .getLinkedOrganisations()
                        .get(0)
                        .getTargetRecognisingOrganisationUuid()))
                .thenReturn(
                        Optional.of(CreateOrganisationDataSetup.getExistingOrganisationDetails()));
        doReturn(true)
                .when(rovoDetailsValidator)
                .isEmptyOrganisationName(roDataCreateV1.getOrganisationName(), context, true);
        doReturn(false).when(rovoDetailsValidator).isValidContact(roDataCreateV1, context, false);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidPartnerCode(roDataCreateV1.getPartnerCode(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidSectorType(roDataCreateV1.getSectorTypeUuid(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidAddress(roDataCreateV1.getAddresses(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidMinimumScores(roDataCreateV1.getMinimumScores(), context, true);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.productAcceptance}");
        doReturn(nodeBuilderCustomizableContext)
                .when(builder)
                .addPropertyNode(OrganisationConstants.GenericConstants.PRODUCT_ACCEPTANCE);

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }
    @Test
    void testValidationFailureIfACNullAndGTFalse() {
        RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        roDataCreateV1.setAcceptsAC(null);
        roDataCreateV1.setAcceptsGT(false);
        roDataCreateV1.setLinkedOrganisations(
                CreateOrganisationDataSetup.getLinkedOrganisationsData());
        when(orgTypeRepository.findById(roDataCreateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        when(recognisingOrganisationRepository.findById(
                roDataCreateV1
                        .getLinkedOrganisations()
                        .get(0)
                        .getTargetRecognisingOrganisationUuid()))
                .thenReturn(
                        Optional.of(CreateOrganisationDataSetup.getExistingOrganisationDetails()));
        doReturn(true)
                .when(rovoDetailsValidator)
                .isEmptyOrganisationName(roDataCreateV1.getOrganisationName(), context, true);
        doReturn(false).when(rovoDetailsValidator).isValidContact(roDataCreateV1, context, false);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidPartnerCode(roDataCreateV1.getPartnerCode(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidSectorType(roDataCreateV1.getSectorTypeUuid(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidAddress(roDataCreateV1.getAddresses(), context, true);
        doReturn(true)
                .when(rovoDetailsValidator)
                .isValidMinimumScores(roDataCreateV1.getMinimumScores(), context, true);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.productAcceptance}");
        doReturn(nodeBuilderCustomizableContext)
                .when(builder)
                .addPropertyNode(OrganisationConstants.GenericConstants.PRODUCT_ACCEPTANCE);

        boolean isValid = rovoDetailsValidator.isValid(roDataCreateV1, context);
        assertEquals(false, isValid);
    }

}
