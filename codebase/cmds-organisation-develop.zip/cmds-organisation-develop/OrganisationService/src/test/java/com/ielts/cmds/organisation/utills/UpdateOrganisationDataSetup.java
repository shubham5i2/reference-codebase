package com.ielts.cmds.organisation.utills;

import com.ielts.cmds.organisation.common.enums.StatusEnum;
import com.ielts.cmds.organisation.common.enums.StatusTypeEnum;

import com.ielts.cmds.api.roui009roupdaterequested.*;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdate;
import com.ielts.cmds.organisation.domain.model.RoDataUpdateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.Address;
import com.ielts.cmds.organisation.infrastructure.entity.AlternateName;
import com.ielts.cmds.organisation.infrastructure.entity.Contact;
import com.ielts.cmds.organisation.infrastructure.entity.ContactType;
import com.ielts.cmds.organisation.infrastructure.entity.LinkedRecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.entity.MinimumScore;
import com.ielts.cmds.organisation.infrastructure.entity.NoteType;
import com.ielts.cmds.organisation.infrastructure.entity.OrganisationType;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.entity.RoNote;
import com.ielts.cmds.organisation.infrastructure.entity.StatusHistory;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import java.math.BigDecimal;
import java.time.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public class UpdateOrganisationDataSetup {

    public static RoDataUpdateV1Valid updateOrgData() {

        RoDataUpdateV1Valid roDataUpdate = new RoDataUpdateV1Valid();

        roDataUpdate.setRecognisingOrganisationUuid(
                UUID.fromString("88e18cae-1bdd-45a7-be1c-0a37926f9bbe"));
        roDataUpdate.setOrganisationName("McGill University");
        roDataUpdate.setOrganisationTypeUuid(
                UUID.fromString("e496aa98-86a3-476d-8be3-21ee0aa23c93"));
        roDataUpdate.setOrganisationStatus(OrganisationStatusEnum.valueOf(OrganisationStatusEnum.ACTIVE.getValue()));
        roDataUpdate.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.APPROVED.getValue()));
        roDataUpdate.setAddresses(getAddressData());
        roDataUpdate.setPartnerCode("IDP");
        roDataUpdate.setPartnerContact("");
        roDataUpdate.setMethodOfDelivery(MethodOfDeliveryEnum.POSTAL);
        roDataUpdate.setSectorTypeUuid(UUID.fromString("48270c84-4cc8-489e-8eac-2af59898175a"));
        roDataUpdate.setWebsiteUrl("www.officialxyz.com");
        roDataUpdate.setCrmSystem("CRM Value");
        roDataUpdate.setOrganisationCode("UCAS231");
        roDataUpdate.setResultAvailableForYears(3);
        roDataUpdate.setNotes(getNotesData());
        roDataUpdate.setAlternateNames(getAlternateNamesData());
        roDataUpdate.setContacts(getContactsData());
        roDataUpdate.setOrganisationStatus(OrganisationStatusEnum.valueOf(OrganisationStatusEnum.ACTIVE.getValue()));
        roDataUpdate.setAcceptsIOL(true);
        roDataUpdate.setAcceptsSSR(false);
        roDataUpdate.setAcceptsAC(true);
        roDataUpdate.setAcceptsGT(true);
        roDataUpdate.setMinimumScores(getMinimumScoresData());
        roDataUpdate.setIeltsDisplayFlag(false);
        roDataUpdate.setOrsDisplayFlag(false);
        roDataUpdate.setLinkedOrganisations(getLinkedOrganisationsData());
        return roDataUpdate;
    }

    public static List<RoDataUpdateLinkedOrganisation> getLinkedOrganisationsData() {
        List<RoDataUpdateLinkedOrganisation> linkedOrganisations =
                new ArrayList<>();
        RoDataUpdateLinkedOrganisation linkedOrg = new RoDataUpdateLinkedOrganisation();
        linkedOrg.setTargetRecognisingOrganisationUuid(
                UUID.fromString("705fc839-5051-4a22-a77d-cf6d734d7d24"));
        linkedOrg.setLinkType(LinkTypeEnum.valueOf(LinkTypeEnum.PARENT_RO.getValue()));
        linkedOrg.setLinkEffectiveFromDateTime(OffsetDateTime.now(ZoneOffset.UTC));
        linkedOrg.setLinkEffectiveToDateTime(LocalDateTime.of(2099, 12, 31, 11, 59).atOffset(ZoneOffset.UTC));
        linkedOrganisations.add(linkedOrg);
        RoDataUpdateLinkedOrganisation additionalOrganisation1 =
                new RoDataUpdateLinkedOrganisation();
        additionalOrganisation1.setTargetRecognisingOrganisationUuid(
                UUID.fromString("705fc839-5051-4a22-a77d-cf6d734d7d24"));
        additionalOrganisation1.setLinkType(LinkTypeEnum.valueOf(LinkTypeEnum.RESULTS_DELIVERY.getValue()));
        additionalOrganisation1.setLinkEffectiveFromDateTime(OffsetDateTime.now(ZoneOffset.UTC));
        additionalOrganisation1.setLinkEffectiveToDateTime(LocalDateTime.of(2099, 12, 31, 11, 59).atOffset(ZoneOffset.UTC));
        linkedOrganisations.add(additionalOrganisation1);
        RoDataUpdateLinkedOrganisation additionalOrganisation2 =
                new RoDataUpdateLinkedOrganisation();
        additionalOrganisation2.setTargetRecognisingOrganisationUuid(
                UUID.fromString("705fc839-5051-4a22-a77d-cf6d734d7d24"));
        additionalOrganisation2.setLinkType(LinkTypeEnum.valueOf(LinkTypeEnum.RESULTS_DELIVERY.getValue()));
        additionalOrganisation2.setLinkEffectiveFromDateTime(OffsetDateTime.now(ZoneOffset.UTC));
        additionalOrganisation2.setLinkEffectiveToDateTime(LocalDateTime.of(2099, 12, 31, 11, 59).atOffset(ZoneOffset.UTC));
        linkedOrganisations.add(additionalOrganisation2);
        return linkedOrganisations;
    }

    private static List<RoDataUpdateMinimumScore> getMinimumScoresData() {

        List<RoDataUpdateMinimumScore> minScores = new ArrayList<>();
        RoDataUpdateMinimumScore minScore = new RoDataUpdateMinimumScore();
        minScore.setMinimumScoreUuid(UUID.fromString("3de9fdd2-4560-45ca-8c15-eba90610422a"));
        minScore.setModuleTypeUuid(UUID.fromString("7a28a632-8728-4f74-882e-72e9d3649763"));
        minScore.setComponent(ComponentEnum.valueOf(ComponentEnum.L.getValue()));
        minScore.setMinimumScoreValue(new BigDecimal(7));
        minScores.add(minScore);
        RoDataUpdateMinimumScore minScore1 = new RoDataUpdateMinimumScore();
        minScore1.setMinimumScoreUuid(UUID.randomUUID());
        minScore1.setModuleTypeUuid(UUID.fromString("7a28a632-8728-4f74-882e-72e9d3649763"));
        minScore1.setComponent(ComponentEnum.valueOf(ComponentEnum.R.getValue()));
        minScore1.setMinimumScoreValue(new BigDecimal(7));
        minScores.add(minScore1);
        return minScores;
    }

    private static List<RoDataUpdateContact> getContactsData() {

        List<RoDataUpdateContact> contacts = new ArrayList<>();
        RoDataUpdateContact primaryContact = new RoDataUpdateContact();
        primaryContact.setContactUuid(UUID.fromString("2f199ce8-f850-49ef-99d9-6494ea31d6e9"));
        primaryContact.setTitle("Ms");
        primaryContact.setFirstName("primary");
        primaryContact.setLastName("name");
        primaryContact.setJobTitle("Chief Support Engineer");
        primaryContact.setContactTypeUuid(UUID.fromString("c3397312-8ea3-453d-871b-68a1ef8c9184"));
        primaryContact.setEffectiveFromDateTime(OffsetDateTime.now(ZoneOffset.UTC));
        primaryContact.setEffectiveToDateTime(OffsetDateTime.now(ZoneOffset.UTC));
        primaryContact.setAddresses(getAddressData());
        contacts.add(primaryContact);
        RoDataUpdateContact resultsAdminContact = new RoDataUpdateContact();
        resultsAdminContact.setContactUuid(UUID.fromString("a38e03ff-33ec-4add-bf20-fef0665354be"));
        resultsAdminContact.setTitle("Ms");
        resultsAdminContact.setFirstName("results admin");
        resultsAdminContact.setLastName("name");
        resultsAdminContact.setJobTitle("Chief Support Engineer");
        resultsAdminContact.setContactTypeUuid(
                UUID.fromString("457a494b-64ca-497f-868f-cc0e5f30a97f"));
        resultsAdminContact.setEffectiveFromDateTime(OffsetDateTime.now(ZoneOffset.UTC));
        resultsAdminContact.setEffectiveToDateTime(OffsetDateTime.now(ZoneOffset.UTC));
        resultsAdminContact.setAddresses(getAddressData());
        contacts.add(resultsAdminContact);
        return contacts;
    }

    public static List<RoDataUpdateContact> getContactsDataForIntegrationTest() {

        List<RoDataUpdateContact> contacts = new ArrayList<>();
        RoDataUpdateContact primaryContact = new RoDataUpdateContact();
        primaryContact.setContactUuid(UUID.fromString("2f199ce8-f850-49ef-99d9-6494ea31d6e9"));
        primaryContact.setTitle("Ms");
        primaryContact.setFirstName("update primary");
        primaryContact.setLastName("name");
        primaryContact.setJobTitle("Support Engineer");
        primaryContact.setContactTypeUuid(UUID.fromString("c3397312-8ea3-453d-871b-68a1ef8c9184"));
        primaryContact.setEffectiveFromDateTime(OffsetDateTime.now(ZoneOffset.UTC));
        primaryContact.setEffectiveToDateTime(OffsetDateTime.now(ZoneOffset.UTC));
        primaryContact.setAddresses(getPrimaryAddressData());
        contacts.add(primaryContact);
        RoDataUpdateContact resultsAdminContact = new RoDataUpdateContact();
        resultsAdminContact.setContactUuid(UUID.fromString("a38e03ff-33ec-4add-bf20-fef0665354be"));
        resultsAdminContact.setTitle("Ms");
        resultsAdminContact.setFirstName("update results admin");
        resultsAdminContact.setLastName("name");
        resultsAdminContact.setJobTitle("Chief Support Engineer");
        resultsAdminContact.setContactTypeUuid(
                UUID.fromString("457a494b-64ca-497f-868f-cc0e5f30a97f"));
        resultsAdminContact.setEffectiveFromDateTime(OffsetDateTime.now(ZoneOffset.UTC));
        resultsAdminContact.setEffectiveToDateTime(OffsetDateTime.now(ZoneOffset.UTC));
        resultsAdminContact.setAddresses(getDeliveryAddressData());
        contacts.add(resultsAdminContact);
        return contacts;
    }

    private static List<RoDataUpdateAddress> getPrimaryAddressData() {

        List<RoDataUpdateAddress> addresses = new ArrayList<>();
        RoDataUpdateAddress mainAddress = new RoDataUpdateAddress();
        mainAddress.setAddressUuid(UUID.fromString("3f22f78b-0fcb-43a5-908c-9691db9667f7"));
        mainAddress.setAddressTypeUuid(UUID.fromString("c96fbd08-a302-4aa2-a594-13cdb33bb380"));
        mainAddress.setAddressLine1("Primary Address Update");
        mainAddress.setAddressLine2("string");
        mainAddress.setAddressLine3("string");
        mainAddress.setAddressLine4("string");
        mainAddress.setCity("Primary Cambridge");
        mainAddress.setTerritoryUuid(UUID.fromString("f1bccce9-89e9-46da-a8dd-03c6db8b3815"));
        mainAddress.setCountryUuid(UUID.fromString("4b8dac87-d2dd-4599-b055-2f73a5f0a01a"));
        mainAddress.setPostalCode("CB2 8EA");
        mainAddress.setEmail("alan2021@cambridgeassessment.org.uk");
        mainAddress.setPhone("+1 234 234 3456");
        addresses.add(mainAddress);
        return addresses;
    }

    private static List<RoDataUpdateAddress> getDeliveryAddressData() {

        List<RoDataUpdateAddress> addresses = new ArrayList<>();
        RoDataUpdateAddress mainAddress = new RoDataUpdateAddress();
        mainAddress.setAddressTypeUuid(UUID.fromString("c96fbd08-a302-4aa2-a594-13cdb33bb380"));
        mainAddress.setAddressLine1("New Address");
        mainAddress.setAddressLine2("string");
        mainAddress.setAddressLine3("string");
        mainAddress.setAddressLine4("string");
        mainAddress.setCity("New Cambridge");
        mainAddress.setTerritoryUuid(UUID.fromString("f1bccce9-89e9-46da-a8dd-03c6db8b3815"));
        mainAddress.setCountryUuid(UUID.fromString("4b8dac87-d2dd-4599-b055-2f73a5f0a01a"));
        mainAddress.setPostalCode("CB2 8EA");
        mainAddress.setEmail("alan2021@cambridgeassessment.org.uk");
        mainAddress.setPhone("+1 234 234 3456");
        addresses.add(mainAddress);
        return addresses;
    }

    private static List<RoDataUpdateAlternateName> getAlternateNamesData() {

        List<RoDataUpdateAlternateName> altnames = new ArrayList<>();
        RoDataUpdateAlternateName altname1 = new RoDataUpdateAlternateName();
        altname1.setAlternateNameUuid(UUID.fromString("714b39a3-15bf-4ac9-8d8d-27478a0a6b89"));
        altname1.setName("altname1");
        altnames.add(altname1);
        RoDataUpdateAlternateName altname2 = new RoDataUpdateAlternateName();
        altname2.setAlternateNameUuid(UUID.randomUUID());
        altname2.setName("altname2");
        altnames.add(altname2);
        return altnames;
    }

    private static List<RoDataUpdateNote> getNotesData() {

        List<RoDataUpdateNote> notes = new ArrayList<>();
        RoDataUpdateNote note1 = new RoDataUpdateNote();
        note1.setNoteContent("new content1");
        note1.setNoteUuid(UUID.fromString("6f1a876d-485e-487b-bf49-406133416c3a"));
        note1.setNoteTypeUuid(UUID.fromString("f9aa5ac1-da99-40f2-82e7-a5fea9e45979"));
        notes.add(note1);
        RoDataUpdateNote note2 = new RoDataUpdateNote();
        note2.setNoteTypeUuid(UUID.fromString("f9aa5ac1-da99-40f2-82e7-a5fea9e45979"));
        note2.setNoteContent("content2");
        notes.add(note2);
        return notes;
    }

    private static List<RoDataUpdateAddress> getAddressData() {

        List<RoDataUpdateAddress> addresses = new ArrayList<>();
        RoDataUpdateAddress mainAddress = new RoDataUpdateAddress();
        mainAddress.setAddressUuid(UUID.fromString("66762bf9-da78-4dbe-acac-02d3d2bc1e7d"));
        mainAddress.setAddressTypeUuid(UUID.fromString("c96fbd08-a302-4aa2-a594-13cdb33bb380"));
        mainAddress.setAddressLine1("22 Heathfield Gardens");
        mainAddress.setAddressLine2("string");
        mainAddress.setAddressLine3("string");
        mainAddress.setAddressLine4("string");
        mainAddress.setCity("Cambridge");
        mainAddress.setTerritoryUuid(UUID.fromString("f1bccce9-89e9-46da-a8dd-03c6db8b3815"));
        mainAddress.setCountryUuid(UUID.fromString("4b8dac87-d2dd-4599-b055-2f73a5f0a01a"));
        mainAddress.setPostalCode("CB2 8EA");
        mainAddress.setEmail("alan_2021@cambridgeassessment.org.uk");
        mainAddress.setPhone("+1 234 234 3456");
        addresses.add(mainAddress);
        RoDataUpdateAddress deliveryAddress = new RoDataUpdateAddress();
        deliveryAddress.setAddressUuid(UUID.fromString("0e685ded-55c2-4a24-9e8c-4bd49a0d0730"));
        deliveryAddress.setAddressTypeUuid(UUID.fromString("d13761e9-c134-4f80-a0a8-239a683a9c00"));
        deliveryAddress.setAddressLine1("22 Heathfield Gardens");
        deliveryAddress.setAddressLine2("string");
        deliveryAddress.setAddressLine3("string");
        deliveryAddress.setAddressLine4("string");
        deliveryAddress.setCity("Cambridge");
        deliveryAddress.setTerritoryUuid(UUID.fromString("f1bccce9-89e9-46da-a8dd-03c6db8b3815"));
        deliveryAddress.setCountryUuid(UUID.fromString("4b8dac87-d2dd-4599-b055-2f73a5f0a01a"));
        deliveryAddress.setPostalCode("CB2 8EA");
        deliveryAddress.setEmail("alan_2021@cambridgeassessment.org.uk");
        deliveryAddress.setPhone("+1 234 234 3456");
        addresses.add(deliveryAddress);
        return addresses;
    }

    public static RecognisingOrganisation getExistingOrganisationDetails(
            RoDataUpdate roDataUpdate, RecognisingOrganisation organisation) {

        organisation = populateOrgDetailsBasedOnAction(roDataUpdate, organisation);
        organisation.setAddresses(populateAddress(null, roDataUpdate.getAddresses(), organisation));
        organisation.setNotes(populateRoNotes(roDataUpdate.getNotes(), organisation));
        organisation.setAlternateNames(
                populateAlternateName(roDataUpdate.getAlternateNames(), organisation));
        organisation.setContacts(populateContacts(roDataUpdate.getContacts(), organisation));
        organisation.setRecognisedProducts(
                CreateOrganisationDataSetup.populateRecognisedProducts(
                        roDataUpdate.getAcceptsIOL(), roDataUpdate.getAcceptsSSR(), organisation));
        organisation.setMinimumScores(
                populateMinimumScores(roDataUpdate.getMinimumScores(), organisation));
        organisation.setLinkedRecognisingOrganisations(
                populateLinkedOrganisations(roDataUpdate.getLinkedOrganisations(), organisation));
        return organisation;
    }

    private static List<LinkedRecognisingOrganisation> populateLinkedOrganisations(
            List<RoDataUpdateLinkedOrganisation> linkedOrganisations,
            RecognisingOrganisation organisation) {

        List<LinkedRecognisingOrganisation> linkedOrganisationsList = new ArrayList<>();
        if (linkedOrganisations != null) {
            linkedOrganisations.forEach(
                    linkedOrg -> {
                        LinkedRecognisingOrganisation linkedOrganisationToBeCreated =
                                new LinkedRecognisingOrganisation();
                        linkedOrganisationToBeCreated.setConcurrencyVersion(0);
                        linkedOrganisationToBeCreated.setCreatedBy(
                                OrganisationConstants.GenericConstants.OPERATIONAL_USER);
                        linkedOrganisationToBeCreated.setCreatedDatetime(Instant.now());
                        linkedOrganisationToBeCreated.setUpdatedBy(
                                OrganisationConstants.GenericConstants.OPERATIONAL_USER);
                        linkedOrganisationToBeCreated.setUpdatedDatetime(Instant.now());

                        linkedOrganisationToBeCreated.setSourceRecognisingOrganisation(
                                organisation);
                        RecognisingOrganisation ro = new RecognisingOrganisation();
                        ro.setRecognisingOrganisationUuid(
                                linkedOrg.getTargetRecognisingOrganisationUuid());
                        linkedOrganisationToBeCreated.setTargetRecognisingOrganisation(ro);
                        linkedOrganisationToBeCreated.setLinkedRecognisingOrganisationType(
                                com.ielts.cmds.api.roui007rocreaterequested.LinkTypeEnum.valueOf(linkedOrg.getLinkType().getValue()));
                        linkedOrganisationToBeCreated.setEffectiveFromDatetime(
                                Optional.of(linkedOrg.getLinkEffectiveFromDateTime())
                                        .orElse(OffsetDateTime.now(ZoneOffset.UTC)));
                        linkedOrganisationToBeCreated.setEffectiveToDatetime(
                                Optional.of(linkedOrg.getLinkEffectiveToDateTime())
                                        .orElse(
                                                LocalDateTime.of(
                                                        2099, Month.DECEMBER, 31, 11, 59, 59).atOffset(ZoneOffset.UTC)));
                        linkedOrganisationsList.add(linkedOrganisationToBeCreated);
                    });
        }
        return linkedOrganisationsList;
    }

    private static List<MinimumScore> populateMinimumScores(
            List<RoDataUpdateMinimumScore> minimumScores, RecognisingOrganisation organisation) {

        List<MinimumScore> minimumScoresList = new ArrayList<>();
        if (minimumScores != null) {
            minimumScores.forEach(
                    minScore -> {
                        MinimumScore minScoreToBeAdded = new MinimumScore();
                        minScoreToBeAdded.setConcurrencyVersion(0);
                        minScoreToBeAdded.setCreatedBy(
                                OrganisationConstants.GenericConstants.OPERATIONAL_USER);
                        minScoreToBeAdded.setCreatedDatetime(Instant.now());
                        minScoreToBeAdded.setUpdatedBy(
                                OrganisationConstants.GenericConstants.OPERATIONAL_USER);
                        minScoreToBeAdded.setUpdatedDatetime(Instant.now());

                        minScoreToBeAdded.setMinscoreReqUuid(minScore.getMinimumScoreUuid());
                        minScoreToBeAdded.setModuleTypeUuid(minScore.getModuleTypeUuid());
                        minScoreToBeAdded.setComponent(com.ielts.cmds.api.roui007rocreaterequested.ComponentEnum.valueOf(minScore.getComponent().getValue()));
                        minScoreToBeAdded.setMinimumScoreValue(minScore.getMinimumScoreValue());
                        minScoreToBeAdded.setRecognisingOrganisation(organisation);
                        minimumScoresList.add(minScoreToBeAdded);
                    });
        }
        return minimumScoresList;
    }

    private static List<Contact> populateContacts(
            List<RoDataUpdateContact> contacts, RecognisingOrganisation organisation) {

        List<Contact> contactList = new ArrayList<>();
        contacts.forEach(
                contact -> {
                    Contact contactToBeAdded = new Contact();
                    contactToBeAdded.setConcurrencyVersion(0);
                    contactToBeAdded.setCreatedBy(
                            OrganisationConstants.GenericConstants.OPERATIONAL_USER);
                    contactToBeAdded.setCreatedDatetime(Instant.now());
                    contactToBeAdded.setUpdatedBy(
                            OrganisationConstants.GenericConstants.OPERATIONAL_USER);
                    contactToBeAdded.setUpdatedDatetime(Instant.now());

                    contactToBeAdded.setContactUuid(contact.getContactUuid());
                    contactToBeAdded.setTitle(contact.getTitle());
                    contactToBeAdded.setFirstName(contact.getFirstName());
                    contactToBeAdded.setLastName(contact.getLastName());
                    contactToBeAdded.setJobTitle(contact.getJobTitle());
                    contactToBeAdded.setContactTypeUuid(contact.getContactTypeUuid());
                    // Here the effective_from_datetime and effective_to_datetime are not coming
                    // from UI, So we are hardcoding them here
                    contactToBeAdded.setEffectiveFromDatetime(contact.getEffectiveFromDateTime());
                    contactToBeAdded.setEffectiveToDatetime(contact.getEffectiveToDateTime());
                    contactToBeAdded.setAddresses(
                            populateAddress(
                                    contactToBeAdded, contact.getAddresses(), organisation));
                    contactToBeAdded.setRecognisingOrganisation(organisation);
                    contactList.add(contactToBeAdded);
                });

        return contactList;
    }

    private static List<AlternateName> populateAlternateName(
            List<RoDataUpdateAlternateName> alternateNames, RecognisingOrganisation organisation) {

        List<AlternateName> alternateNamesList = new ArrayList<>();
        if (alternateNames != null) {
            alternateNames.forEach(
                    altName -> {
                        AlternateName altNameToBeAdded = new AlternateName();
                        altNameToBeAdded.setConcurrencyVersion(0);
                        altNameToBeAdded.setCreatedBy(
                                OrganisationConstants.GenericConstants.OPERATIONAL_USER);
                        altNameToBeAdded.setCreatedDatetime(Instant.now());
                        altNameToBeAdded.setUpdatedBy(
                                OrganisationConstants.GenericConstants.OPERATIONAL_USER);
                        altNameToBeAdded.setUpdatedDatetime(Instant.now());

                        altNameToBeAdded.setAlternateNameUuid(altName.getAlternateNameUuid());
                        altNameToBeAdded.setName(altName.getName());
                        altNameToBeAdded.setRecognisingOrganisation(organisation);
                        alternateNamesList.add(altNameToBeAdded);
                    });
        }
        return alternateNamesList;
    }

    private static List<RoNote> populateRoNotes(
            List<RoDataUpdateNote> notes, RecognisingOrganisation organisation) {
        List<RoNote> roNotesList = new ArrayList<>();
        if (notes != null) {
            notes.forEach(
                    note -> {
                        if (note.getNoteUuid() != null) {
                            RoNote noteToBeAdded = new RoNote();
                            noteToBeAdded.setConcurrencyVersion(0);
                            noteToBeAdded.setCreatedBy(
                                    OrganisationConstants.GenericConstants.OPERATIONAL_USER);
                            noteToBeAdded.setCreatedDatetime(Instant.now());
                            noteToBeAdded.setUpdatedBy(
                                    OrganisationConstants.GenericConstants.OPERATIONAL_USER);
                            noteToBeAdded.setUpdatedDatetime(Instant.now());
                            noteToBeAdded.setNoteUuid(note.getNoteUuid());
                            noteToBeAdded.setNoteContent(note.getNoteContent());
                            /*
                             * NoteType is not sent from UI so for now we are hardcoding it to Internal
                             * NoteType
                             */
                            NoteType noteType = getNoteTypesData();
                            noteToBeAdded.setNoteTypeUuid(noteType.getNoteTypeUuid());
                            noteToBeAdded.setRecognisingOrganisation(organisation);
                            roNotesList.add(noteToBeAdded);
                        }
                    });
        }
        return roNotesList;
    }

    private static List<Address> populateAddress(
            Contact contact,
            List<RoDataUpdateAddress> addresses,
            RecognisingOrganisation organisation) {

        List<Address> addressList = new ArrayList<>();
        addresses.forEach(
                address -> {
                    Address addressToBeAdded = new Address();
                    addressToBeAdded.setConcurrencyVersion(0);
                    addressToBeAdded.setCreatedBy(
                            OrganisationConstants.GenericConstants.OPERATIONAL_USER);
                    addressToBeAdded.setCreatedDatetime(Instant.now());
                    addressToBeAdded.setUpdatedBy(
                            OrganisationConstants.GenericConstants.OPERATIONAL_USER);
                    addressToBeAdded.setUpdatedDatetime(Instant.now());

                    addressToBeAdded.setAddressUuid(address.getAddressUuid());
                    addressToBeAdded.setAddressTypeUuid(address.getAddressTypeUuid());
                    addressToBeAdded.setCountryUuid(address.getCountryUuid());
                    addressToBeAdded.setTerritoryUuid(address.getTerritoryUuid());
                    addressToBeAdded.setAddressline1(address.getAddressLine1());
                    addressToBeAdded.setAddressline2(address.getAddressLine2());
                    addressToBeAdded.setAddressline3(address.getAddressLine3());
                    addressToBeAdded.setAddressline4(address.getAddressLine4());
                    addressToBeAdded.setCity(address.getCity());
                    addressToBeAdded.setPostalCode(address.getPostalCode());
                    addressToBeAdded.setEmail(address.getEmail());
                    addressToBeAdded.setPhone(address.getPhone());
                    addressToBeAdded.setRecognisingOrganisation(organisation);
                    if (contact != null) {
                        addressToBeAdded.setContact(contact);
                    }
                    addressList.add(addressToBeAdded);
                });
        return addressList;
    }

    public static RecognisingOrganisation populateSetterMethods(
            final RoDataUpdate roData, final RecognisingOrganisation orgDetails) {

        orgDetails.setRecognisingOrganisationUuid(roData.getRecognisingOrganisationUuid());
        orgDetails.setName(roData.getOrganisationName());
        orgDetails.setOrganisationTypeUuid(roData.getOrganisationTypeUuid());
        orgDetails.setSectorTypeUuid(roData.getSectorTypeUuid());
        orgDetails.setVerificationStatus(com.ielts.cmds.api.roui007rocreaterequested.VerificationStatusEnum.valueOf(roData.getVerificationStatus().getValue()));
        orgDetails.setPartnerCode(roData.getPartnerCode());
        orgDetails.setMethodOfDelivery(com.ielts.cmds.api.roui007rocreaterequested.MethodOfDeliveryEnum.valueOf(roData.getMethodOfDelivery().getValue()));
        orgDetails.setOrgStatus(com.ielts.cmds.api.roui007rocreaterequested.OrganisationStatusEnum.valueOf(roData.getOrganisationStatus().getValue()));
        orgDetails.setWebsiteUrl(roData.getWebsiteUrl());
        orgDetails.setCrmSystem(roData.getCrmSystem());
        orgDetails.setOrganisationCode(roData.getOrganisationCode());
        orgDetails.setResultAvailableForYears(roData.getResultAvailableForYears());
        orgDetails.setIeltsDisplayFlag(roData.getIeltsDisplayFlag());
        orgDetails.setOrsDisplayFlag(roData.getOrsDisplayFlag());
        return orgDetails;
    }

    public static RecognisingOrganisation populateOrgDetailsBasedOnAction(
            final RoDataUpdate roData, final RecognisingOrganisation orgDetails) {

        orgDetails.setConcurrencyVersion(0);
        orgDetails.setCreatedBy(OrganisationConstants.GenericConstants.OPERATIONAL_USER);
        orgDetails.setCreatedDatetime(Instant.now());
        orgDetails.setUpdatedBy(OrganisationConstants.GenericConstants.OPERATIONAL_USER);
        orgDetails.setUpdatedDatetime(Instant.now());
        return populateSetterMethods(roData, orgDetails);
    }

    public static NoteType getNoteTypesData() {
        NoteType noteType = new NoteType();
        noteType.setNoteTypeUuid(UUID.fromString("f9aa5ac1-da99-40f2-82e7-a5fea9e45979"));
        noteType.setNotesType("Internal");
        noteType.setDescription("");
        noteType.setEffectiveFromDate(LocalDate.of(2020, 7, 1));
        noteType.setEffectiveToDate(LocalDate.of(2099, 12, 31));
        return noteType;
    }

    public static ContactType getContactTypeData() {
        ContactType contactType = new ContactType();
        contactType.setContactTypeUuid(UUID.fromString("80f4bba7-70b2-4e16-bef4-2ff06c58f620"));
        contactType.setContactsType("Partner Contact");
        contactType.setDescription("");
        contactType.setEffectiveFromDate(LocalDate.of(2020, 7, 1));
        contactType.setEffectiveToDate(LocalDate.of(2099, 12, 31));
        return contactType;
    }

    public static StatusHistory getStatusHistoryData(RecognisingOrganisation organisation) {
        StatusHistory statusHistory = new StatusHistory();
        statusHistory.setConcurrencyVersion(0);
        statusHistory.setCreatedBy(OrganisationConstants.GenericConstants.OPERATIONAL_USER);
        statusHistory.setCreatedDatetime(Instant.now());
        statusHistory.setUpdatedBy(OrganisationConstants.GenericConstants.OPERATIONAL_USER);
        statusHistory.setUpdatedDatetime(Instant.now());

        statusHistory.setRecognisingOrganisation(organisation);
        statusHistory.setStatusType(StatusTypeEnum.VERIFICATION_STATUS);
        statusHistory.setStatus(StatusEnum.fromValue(VerificationStatusEnum.PENDING.toString()));
        statusHistory.setStatusDatetime(LocalDateTime.now());
        return statusHistory;
    }

    public static OrganisationType getVoOrganisationTypeData() {
        OrganisationType organisationType = new OrganisationType();
        organisationType.setOrganisationTypeUuid(
                UUID.fromString("e392ae7c-016f-433a-bdfa-b79bfcdddf26"));
        organisationType.setOrganisationsType("VO");
        organisationType.setDescription("Verified Organisation");
        organisationType.setEffectiveFromDate(LocalDate.of(2020, 7, 1));
        organisationType.setEffectiveToDate(LocalDate.of(2099, 12, 31));
        return organisationType;
    }

    public static List<StatusHistory> getStatusHistoryDetails() {
        List<StatusHistory> statusHistoryList = new ArrayList<>();
        StatusHistory statusHistory = new StatusHistory();
        statusHistory.setStatusHistoryUuid(UUID.randomUUID());
        statusHistory.setStatusType(StatusTypeEnum.VERIFICATION_STATUS);
        statusHistory.setStatus(StatusEnum.APPROVED);
        statusHistoryList.add(statusHistory);
        return statusHistoryList;
    }
}
