package com.ielts.cmds.organisation.application;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.domain.commands.OrganisationPrimmingCommand;
import com.ielts.cmds.organisation.domain.model.OrganisationPrimmingModel;
import com.ielts.cmds.organisation.domain.model.RoDataUpdateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utills.UpdateOrganisationDataSetup;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class OrganisationPrimmingServiceTestSetup {

    public static OrganisationPrimmingCommand getOrganisationPrimingCommand()
            throws JsonProcessingException {
        BaseEvent<BaseHeader> cmdsEvent = getCMDSEvent();
        OrganisationPrimmingCommand organisationPrimmingCommand =
                OrganisationPrimmingCommand.builder()
                        .eventHeaders(cmdsEvent.getEventHeader())
                        .eventBody(
                                new ObjectMapper()
                                        .readValue(
                                                cmdsEvent.getEventBody(),
                                                OrganisationPrimmingModel.class))
                        .eventErrors(null)
                        .build();
        return organisationPrimmingCommand;
    }

    public static BaseEvent<BaseHeader> getCMDSEvent() throws JsonProcessingException {
        BaseEvent<BaseHeader> cmdsEvent = new BaseEvent<>();
        BaseHeader header = OrganisationTestUtil.generateEventHeader();
        header.setEventName("OrganisationPrimmingEvent");
        cmdsEvent.setEventHeader(header);
        cmdsEvent.setEventBody(new ObjectMapper().writeValueAsString(getPrimmingEventBody()));
        cmdsEvent.setEventErrors(null);
        return cmdsEvent;
    }

    public static OrganisationPrimmingModel getPrimmingEventBody() {
        List<UUID> orgUuids = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            orgUuids.add(UUID.randomUUID());
        }
        OrganisationPrimmingModel model = new OrganisationPrimmingModel();
        model.setOrganisationsToBePublished(orgUuids);
        return model;
    }

    public static List<RecognisingOrganisation> getExistingOrganisations(List<UUID> orgUuids) {
        List<RecognisingOrganisation> organisations = new ArrayList<>();
        final RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        for (UUID orgUuid : orgUuids) {
            RecognisingOrganisation organisation =
                    UpdateOrganisationDataSetup.getExistingOrganisationDetails(
                            roDataUpdate, new RecognisingOrganisation());
            organisation.setRecognisingOrganisationUuid(orgUuid);
            organisations.add(organisation);
        }
        return organisations;
    }
}
