package com.ielts.cmds.organisation.application;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.organisation.domain.commands.OrganisationHierarchyUpdate;
import com.ielts.cmds.organisation.domain.model.HierarchyUpdateV1;
import com.ielts.cmds.organisation.domain.services.OrganisationHierarchyUpdateDomainService;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import java.util.UUID;
import java.util.stream.Stream;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

/** @author cts */
@ExtendWith(MockitoExtension.class)
class OrganisationHierarchyUpdateServiceTest {

    @InjectMocks private OrganisationHierarchyUpdateService rOHierarchyUpdateService;

    @Mock private OrganisationHierarchyUpdateDomainService updateHierarchyDomainService;

    @Captor ArgumentCaptor<OrganisationHierarchyUpdate> hierarchyArg;

    @Mock private ObjectMapper objectMapper;

    @ParameterizedTest
    @MethodSource("argumentsProviderForROHirarchyUpdateEvent")
    void whenValidPayload_thenVerifyDomainCallWithNoException(
            BaseEvent<UiHeader> roCmdsEvent, OrganisationHierarchyUpdate hierarchyROAnalysis)
            throws Exception {
        when(objectMapper.readValue(roCmdsEvent.getEventBody(), HierarchyUpdateV1.class))
                .thenReturn(hierarchyROAnalysis.getEventBody());
        assertNotNull(rOHierarchyUpdateService.getServiceIdentifier());
        rOHierarchyUpdateService.process(roCmdsEvent);
        verify(updateHierarchyDomainService, times(1)).onCommand(hierarchyROAnalysis);

        verify(updateHierarchyDomainService).onCommand(hierarchyArg.capture());
        assertNotNull(hierarchyArg.getValue().getEventBody());
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForROHirarchyUpdateEvent")
    void whenInValidPayload_thenVerifyForException(
            BaseEvent<UiHeader> roCmdsEvent, OrganisationHierarchyUpdate hierarchyROAnalysis)
            throws Exception {
        when(objectMapper.readValue(roCmdsEvent.getEventBody(), HierarchyUpdateV1.class))
                .thenReturn(hierarchyROAnalysis.getEventBody());
        doThrow(RuntimeException.class)
                .when(updateHierarchyDomainService)
                .onCommand(hierarchyROAnalysis);
        Executable executable = () -> rOHierarchyUpdateService.process(roCmdsEvent);
        ProcessingException processingException =
                assertThrows(ProcessingException.class, executable);
        assertTrue(processingException.getCause() instanceof RuntimeException);

    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForROHirarchyUpdateEvent")
    void whenInValidPayload_thenVerifyForCMDSException(
            BaseEvent<UiHeader> roCmdsEvent, OrganisationHierarchyUpdate hierarchyROAnalysis)
            throws Exception {
        roCmdsEvent.setEventBody("{\\\"eventHeader\\\":{\\\"transactionId");
        Executable executable = () -> rOHierarchyUpdateService.process(roCmdsEvent);
        ProcessingException processingException =
                assertThrows(ProcessingException.class, executable);
        assertTrue(processingException.getCause() instanceof IllegalArgumentException);
    }

    /*
     * This is method source to provide arguments for the required test cases
     * wherever this method source has been used. It's specific to ROHierarchyUpdate event
     */
    private static Stream<Arguments> argumentsProviderForROHirarchyUpdateEvent()
            throws JsonProcessingException {

        UiHeader roHeaders = OrganisationTestUtil.generateEventHeader();
        roHeaders.setEventName(OrganisationConstants.EventType.RO_HIERARCHY_UPDATE_EVENT);
        BaseAudit audit = new BaseAudit();
        HierarchyUpdateV1 hierarchyUpdateV1 = new HierarchyUpdateV1();
        hierarchyUpdateV1.setOldHierarchyLabel("1234");
        hierarchyUpdateV1.setNewHierarchyLabel("5678");
        hierarchyUpdateV1.setTriggerRecognisingOrganisationUuid(
                UUID.fromString("6dafc1f5-bb16-41db-8b5d-295691c75300"));
        final ObjectMapper mapper = new ObjectMapper();
        final BaseEvent<UiHeader> event =
                new BaseEvent<UiHeader>(
                        roHeaders, mapper.writeValueAsString(hierarchyUpdateV1), null, audit);
        OrganisationHierarchyUpdate hierarchyROAnalysis =
                OrganisationHierarchyUpdate.builder()
                        .eventHeaders(event.getEventHeader())
                        .eventBody(hierarchyUpdateV1)
                        .eventErrors(event.getEventErrors())
                        .audit(audit)
                        .build();
        return Stream.of(Arguments.of(event, hierarchyROAnalysis));
    }
}
