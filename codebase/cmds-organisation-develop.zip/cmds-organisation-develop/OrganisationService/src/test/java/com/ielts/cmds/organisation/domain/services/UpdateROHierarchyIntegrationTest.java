package com.ielts.cmds.organisation.domain.services;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.cache.JedisGenericReader;
import com.ielts.cmds.organisation.cache.factory.JedisFactory;
import com.ielts.cmds.organisation.common.enums.LinkTypeEnum;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.organisation.common.ui.in.RoDataUpdateV1LinkedOrganisation;
import com.ielts.cmds.organisation.common.ui.in.RoDataUpdateV1LinkedOrganisations;
import com.ielts.cmds.organisation.domain.model.RoDataUpdateV1Valid;
import com.ielts.cmds.organisation.infrastructure.config.RBACTestConfig;
import com.ielts.cmds.organisation.infrastructure.entity.LinkedRecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utills.UpdateOrganisationDataSetup;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.implementation.impl.LocationHierarchyServiceImpl;
import com.ielts.cmds.rbac.implementation.impl.UserGroupServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

import javax.transaction.Transactional;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.verify;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = RBACTestConfig.class)
@ActiveProfiles("test")
@Sql({
    "/sql/schema.sql",
    "/sql/organisation-type-data.sql",
    "/sql/partner-data.sql",
    "/sql/address-type-data.sql",
    "/sql/sector-type-data.sql",
    "/sql/note-type-data.sql",
    "/sql/contact-type-data.sql",
    "/sql/country-data.sql",
    "/sql/territory-data.sql",
    "/sql/module-type-data.sql",
    "/sql/usergroup-hierarchy.sql",
    "/sql/existing-ro-data.sql",
    "/sql/existing-vo-data.sql",
    "/sql/ro-hierarchy-data.sql",
    "/sql/sample-hierarchy-data.sql",
    "/sql/linked-recognising-organisation-data.sql"
})
@Transactional
class UpdateROHierarchyIntegrationTest {

    @Autowired private RecognisingOrganisationRepository recognisingOrgRepository;

    @Autowired private OrganisationCommonUtils organisationCommonUtils;

    @MockBean private ApplicationEventPublisher applicationEventPublisher;

    @Autowired private UpdateOrganisationDomainService updateOrganisationDomainService;

    @Captor ArgumentCaptor<BaseEvent<BaseHeader>> publishedEventCaptor;

    @Autowired private ObjectMapper objectMapper;
    @Autowired private UserGroupServiceImpl userGroupServiceImpl;
    @Autowired private LocationHierarchyServiceImpl locationHierarchyServiceImpl;
    @MockBean private JedisGenericReader jedisGenericReader;
    @MockBean private JedisFactory jedisFactory;

    @BeforeEach
    void setup() throws RbacValidationException {
        userGroupServiceImpl.populateUserGroupHierarchyData();
        locationHierarchyServiceImpl.populateRootData();
        ReflectionTestUtils.setField(
                updateOrganisationDomainService,
                "applicationEventPublisher",
                applicationEventPublisher);
        ReflectionTestUtils.setField(
                organisationCommonUtils, "applicationEventPublisher", applicationEventPublisher);
        ThreadLocalHeaderContext.setContext(OrganisationTestUtil.generateBuildHeaderContext(OrganisationConstants.EventType.RO_HIERARCHY_UPDATE_EVENT));
        ThreadLocalAuditContext.setContext(OrganisationTestUtil.getBaseAudit());
        ReflectionTestUtils.setField(
                organisationCommonUtils, "jedisGenericReader", jedisGenericReader);

    }

    @Test
    final void testUpdateOrganisation() throws IOException {

        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");

        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setContacts(UpdateOrganisationDataSetup.getContactsDataForIntegrationTest());

        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);

        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));
        Optional<RecognisingOrganisation> recognisingOrganisation =
                recognisingOrgRepository.findByRecognisingOrganisationUuid(
                        UUID.fromString("88e18cae-1bdd-45a7-be1c-0a37926f9bbe"));

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();

        RoChangedEventV1 roCreatedEvent =
                objectMapper.readValue(event.getEventBody(), RoChangedEventV1.class);
        /* Count Check */
        assertTrue(recognisingOrgRepository.count() > 0);

        List<LinkedRecognisingOrganisation> savedLinkedOrganisation =
                recognisingOrganisation.get().getLinkedRecognisingOrganisations();
        assertEquals(3, savedLinkedOrganisation.stream().count());
        assertEquals(
                LinkTypeEnum.PARENT_RO.getValue(),
                savedLinkedOrganisation.get(0).getLinkedRecognisingOrganisationType().getValue());
        assertEquals(3, roCreatedEvent.getLinkedOrganisations().stream().count());
        assertEquals(
                LinkTypeEnum.PARENT_RO.getValue(),
                roCreatedEvent.getLinkedOrganisations().get(0).getLinkType().getValue());
        assertEquals(
                2,
                roCreatedEvent.getLinkedOrganisations().stream()
                        .filter(
                                linkedRO ->
                                        LinkTypeEnum.RESULTS_DELIVERY.getValue().equals(
                                                linkedRO.getLinkType().getValue()))
                        .count());
        assertEquals(
                LinkTypeEnum.RESULTS_DELIVERY.getValue(),
                savedLinkedOrganisation.get(1).getLinkedRecognisingOrganisationType().getValue());
        assertEquals(
                LinkTypeEnum.RESULTS_DELIVERY.getValue(),
                roCreatedEvent.getLinkedOrganisations().get(1).getLinkType().getValue());
    }

    @Test
    final void testRejectedEventForVOAsParentAndInvalidResultsDelivery()
            throws IOException {

        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");

        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate
                .getLinkedOrganisations()
                .get(0)
                .setTargetRecognisingOrganisationUuid(
                        UUID.fromString(
                                "d303bc54-d13b-4252-aae6-486cf5a4f1f6")); // Organisation with VO
        // type
        roDataUpdate
                .getLinkedOrganisations()
                .get(1)
                .setTargetRecognisingOrganisationUuid(
                        UUID.fromString(
                                "d903bc54-d13b-4252-aae6-486cf5a4f1f6")); // Organisation which is
        // not present in DB
        roDataUpdate.setContacts(UpdateOrganisationDataSetup.getContactsDataForIntegrationTest());

        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);
        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();

        assertEquals(
                OrganisationConstants.EventType.RO_UPDATE_REJECTED_EVENT,
                event.getEventHeader().getEventName());
        assertEquals(3, event.getEventErrors().getErrorList().size());
        List<String> listOfErrorCodes =
                event.getEventErrors().getErrorList().stream()
                        .map(errorList -> errorList.getErrorCode())
                        .collect(Collectors.toList());
        /*Parent Recognising Organisation must be an RO*/
        assertTrue(listOfErrorCodes.contains("V0060"));
        /*Additional Delivery Organisation is not valid*/
        assertTrue(listOfErrorCodes.contains("V0059"));
        /*Additional Delivery organisations must be in Hierarchy List*/
        assertTrue(listOfErrorCodes.contains("V0064"));
    }

    @Test
    final void testRejectedEventWhenRObeingUpdatedIsItselfAddedAsParent()
            throws IOException {

        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");

        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate
                .getLinkedOrganisations()
                .get(0)
                .setTargetRecognisingOrganisationUuid(
                        roDataUpdate.getRecognisingOrganisationUuid());
        roDataUpdate.setContacts(UpdateOrganisationDataSetup.getContactsDataForIntegrationTest());
        UiHeader uiHeader = OrganisationTestUtil.generateEventHeader();
        uiHeader.setEventName(OrganisationConstants.EventType.RO_UPDATED_EVENT);
        uiHeader.setXaccessToken(authorisedAccessTokenToUpdate);
        BaseAudit audit = new BaseAudit();
        Map<String, String> auditContext = new HashMap<>();
        audit.setAuditContext(auditContext);
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);
        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();

        assertEquals(
                OrganisationConstants.EventType.RO_UPDATE_REJECTED_EVENT,
                event.getEventHeader().getEventName());
        assertEquals(1, event.getEventErrors().getErrorList().size());
        List<String> listOfErrorCodes =
                event.getEventErrors().getErrorList().stream()
                        .map(errorList -> errorList.getErrorCode())
                        .collect(Collectors.toList());
        assertTrue(listOfErrorCodes.contains("V0065"));
    }

    @Test
    final void testRejectedEventToAddParentWhenRoIsAlreadyHavingParent()
            throws IOException {

        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");

        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setRecognisingOrganisationUuid(
                UUID.fromString("5c2e3965-8b90-488f-b5e9-4da8854785cb"));
        roDataUpdate.setContacts(UpdateOrganisationDataSetup.getContactsDataForIntegrationTest());
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put("recognisingOrganisationUuid", "5c2e3965-8b90-488f-b5e9-4da8854785cb");

        CMDSHeaderContext headerContext = OrganisationTestUtil
                .generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_DETAILS_REQUEST_EVENT);
        headerContext.setEventContext(eventContext);
        ThreadLocalHeaderContext.setContext(headerContext);
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);
        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();

        assertEquals(
                OrganisationConstants.EventType.RO_UPDATE_REJECTED_EVENT,
                event.getEventHeader().getEventName());
        assertEquals(1, event.getEventErrors().getErrorList().size());
        List<String> listOfErrorCodes =
                event.getEventErrors().getErrorList().stream()
                        .map(errorList -> errorList.getErrorCode())
                        .collect(Collectors.toList());
        assertTrue(listOfErrorCodes.contains("V0062"));
    }

    @Test
    final void testUpdateExistingROResultsDeliveryOrganisations() throws IOException {

        String authorisedAccessTokenToUpdate =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");

        RoDataUpdateV1Valid roDataUpdate = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdate.setRecognisingOrganisationUuid(
                UUID.fromString("5c2e3965-8b90-488f-b5e9-4da8854785cb"));
        roDataUpdate
                .getLinkedOrganisations()
                .get(0)
                .setLinkedRecognisingOrganisationUuid(
                        UUID.fromString("24d63f7d-1316-4bd8-9285-4e8da072657b"));
        roDataUpdate
                .getLinkedOrganisations()
                .get(1)
                .setLinkedRecognisingOrganisationUuid(
                        UUID.fromString("a7e10ac1-3b34-4e80-9909-09a68b25e0d9"));
        roDataUpdate.setContacts(UpdateOrganisationDataSetup.getContactsDataForIntegrationTest());
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put("recognisingOrganisationUuid", "5c2e3965-8b90-488f-b5e9-4da8854785cb");
        CMDSHeaderContext headerContext = OrganisationTestUtil
                .generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_DETAILS_REQUEST_EVENT);
        headerContext.setEventContext(eventContext);
        ThreadLocalHeaderContext.setContext(headerContext);

        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessTokenToUpdate);
        assertDoesNotThrow(() -> updateOrganisationDomainService.onCommand(roDataUpdate));
        Optional<RecognisingOrganisation> recognisingOrganisation =
                recognisingOrgRepository.findByRecognisingOrganisationUuid(
                        UUID.fromString("5c2e3965-8b90-488f-b5e9-4da8854785cb"));

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();

        RoChangedEventV1 roCreatedEvent =
                objectMapper.readValue(event.getEventBody(), RoChangedEventV1.class);
        /* Count Check */
        assertTrue(recognisingOrgRepository.count() > 0);

        List<LinkedRecognisingOrganisation> savedLinkedOrganisation =
                recognisingOrganisation.get().getLinkedRecognisingOrganisations();
        assertEquals(3, savedLinkedOrganisation.stream().count());
        assertEquals(
                LinkTypeEnum.PARENT_RO.getValue(),
                savedLinkedOrganisation.get(0).getLinkedRecognisingOrganisationType().getValue());
        assertEquals(3, roCreatedEvent.getLinkedOrganisations().stream().count());
        assertEquals(
                LinkTypeEnum.PARENT_RO.getValue(),
                roCreatedEvent.getLinkedOrganisations().get(0).getLinkType().getValue());
        assertEquals(
                2,
                roCreatedEvent.getLinkedOrganisations().stream()
                        .filter(
                                linkedRO ->
                                        LinkTypeEnum.RESULTS_DELIVERY.getValue().equals(
                                                linkedRO.getLinkType().getValue()))
                        .count());
        assertEquals(
                LinkTypeEnum.RESULTS_DELIVERY.getValue(),
                savedLinkedOrganisation.get(1).getLinkedRecognisingOrganisationType().getValue());
        assertEquals(
                LinkTypeEnum.RESULTS_DELIVERY.getValue(),
                roCreatedEvent.getLinkedOrganisations().get(1).getLinkType().getValue());
    }

    private RoDataUpdateV1LinkedOrganisations getLinkedOrganisationsWithOnlyParentTestData() {
        RoDataUpdateV1LinkedOrganisations linkedOrganisations =
                new RoDataUpdateV1LinkedOrganisations();
        RoDataUpdateV1LinkedOrganisation linkedOrg = new RoDataUpdateV1LinkedOrganisation();
        linkedOrg.setTargetRecognisingOrganisationUuid(
                UUID.fromString("8ad1b27b-2abd-48f7-af77-04b0efbde786"));
        linkedOrg.setLinkType(LinkTypeEnum.PARENT_RO);
        linkedOrg.setLinkEffectiveFromDateTime(LocalDateTime.now());
        linkedOrg.setLinkEffectiveToDateTime(LocalDateTime.now());
        linkedOrganisations.add(linkedOrg);
        return linkedOrganisations;
    }
}
