package com.ielts.cmds.organisation.domain.validators;

import com.ielts.cmds.api.roui007rocreaterequested.LinkTypeEnum;
import com.ielts.cmds.api.roui007rocreaterequested.OrganisationStatusEnum;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateAddress;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateContact;
import com.ielts.cmds.api.roui009roupdaterequested.VerificationStatusEnum;
import com.ielts.cmds.api.roui009roupdaterequested.MethodOfDeliveryEnum;
import com.ielts.cmds.organisation.domain.model.RoDataUpdateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.Address;
import com.ielts.cmds.organisation.infrastructure.entity.LinkedRecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.entity.OrganisationType;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.*;
import com.ielts.cmds.organisation.utills.CreateOrganisationDataSetup;
import com.ielts.cmds.organisation.utills.UpdateOrganisationDataSetup;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import javax.validation.ConstraintValidatorContext;
import javax.validation.ConstraintValidatorContext.ConstraintViolationBuilder;
import javax.validation.ConstraintValidatorContext.ConstraintViolationBuilder.NodeBuilderCustomizableContext;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.ArrayList;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

/** @author cts */
@ExtendWith(MockitoExtension.class)
class CheckUpdateROVODetailsValidatorTest {

    @Spy @InjectMocks private CheckUpdateROVODetailsValidator checkUpdateRoVoDetails;

    @Mock private ConstraintValidatorContext context;

    @Mock private ConstraintViolationBuilder builder;

    @Mock private OrganisationTypeRepository orgTypeRepository;

    @Mock private ContactTypeRepository contactTypeRepository;

    @Mock private SectorTypeRepository sectorTypeRepository;

    @Mock private AddressTypeRepository addressTypeRepository;

    @Mock private CountryRepository countryRepository;

    @Mock private PartnerCodeRepository partnerRepository;

    @Mock private TerritoryRepository territoryRepository;

    @Mock private ModuleTypeRepository moduleTypeRepository;

    @Mock private RecognisingOrganisationRepository recognisingOrganisationRepository;

    @Mock private NodeBuilderCustomizableContext nodeBuilderCustomizableContext;

    @Mock private AddressRepository addressRepository;

    @Mock private LinkedRecognisingOrganisationRepository linkedRORepository;

    /** @throws Exception */
    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(
                checkUpdateRoVoDetails, "orgTypeRepository", orgTypeRepository);
        ReflectionTestUtils.setField(
                checkUpdateRoVoDetails, "contactTypeRepository", contactTypeRepository);
        ReflectionTestUtils.setField(
                checkUpdateRoVoDetails, "sectorTypeRepository", sectorTypeRepository);
        ReflectionTestUtils.setField(
                checkUpdateRoVoDetails, "addressTypeRepository", addressTypeRepository);
        ReflectionTestUtils.setField(
                checkUpdateRoVoDetails, "addressRepository", addressRepository);
        ReflectionTestUtils.setField(
                checkUpdateRoVoDetails, "countryRepository", countryRepository);
        ReflectionTestUtils.setField(
                checkUpdateRoVoDetails, "partnerRepository", partnerRepository);
        ReflectionTestUtils.setField(
                checkUpdateRoVoDetails, "territoryRepository", territoryRepository);
        ReflectionTestUtils.setField(
                checkUpdateRoVoDetails, "moduleTypeRepository", moduleTypeRepository);
        ReflectionTestUtils.setField(
                checkUpdateRoVoDetails,
                "recognisingOrganisationRepository",
                recognisingOrganisationRepository);
        ReflectionTestUtils.setField(
                checkUpdateRoVoDetails, "linkedRORepository", linkedRORepository);
    }

    @Test
    void testValidationFailureIfOrgTypeIsEmpty() {
        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.organisationTypeUuid}");
        doReturn(nodeBuilderCustomizableContext)
                .when(builder)
                .addPropertyNode("organisationTypeUuid");

        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }

    @Test
    void testValidationSuccessIfVerificationStatusIsVerifiedForRO() {
        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdateV1.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.VERIFIED.getValue()));
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .checkAllCommonFieldsForROVO(roDataUpdateV1, context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidLinkedOrganisations(roDataUpdateV1, context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidContactToUpdate(
                        roDataUpdateV1.getContacts(),
                        context,
                        true,
                        roDataUpdateV1.getRecognisingOrganisationUuid(),
                        roDataUpdateV1.getVerificationStatus().getValue());
        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(true, isValid);
    }

    @Test
    void testValidationFailureIfWebsiteUrlIsEmptyOrInvalid() {
        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdateV1.setWebsiteUrl(null);
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .checkAllCommonFieldsForROVO(roDataUpdateV1, context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidLinkedOrganisations(roDataUpdateV1, context, false);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidContactToUpdate(
                        roDataUpdateV1.getContacts(),
                        context,
                        true,
                        roDataUpdateV1.getRecognisingOrganisationUuid(),
                        roDataUpdateV1.getVerificationStatus().getValue());
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.websiteUrl}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("websiteUrl");

        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }

    @Test
    void testValidationFailureIfContactIsEmpty() {
        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .checkAllCommonFieldsForROVO(roDataUpdateV1, context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidLinkedOrganisations(roDataUpdateV1, context, false);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.contacts}");
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.primaryContact}");
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.resultsAdminContact}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("contacts");

        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }

    @Test
    void testValidationFailureIfAddressIsEmptyForContacts() {
        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        List<RoDataUpdateAddress> address = roDataUpdateV1.getContacts().get(0).getAddresses();
        address.get(0).setEmail(null);
        List<RoDataUpdateContact> contacts = roDataUpdateV1.getContacts();
        contacts.get(0).setAddresses(address);
        roDataUpdateV1.setContacts(contacts);
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .checkAllCommonFieldsForROVO(roDataUpdateV1, context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidLinkedOrganisations(roDataUpdateV1, context, false);
        
        when(contactTypeRepository.findById(
                        roDataUpdateV1.getContacts().get(0).getContactTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getPrimaryContactTypeData()));
        when(contactTypeRepository.findById(
                        roDataUpdateV1.getContacts().get(1).getContactTypeUuid()))
                .thenReturn(
                        Optional.of(CreateOrganisationDataSetup.getResultsAdminContactTypeData()));
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.email.Primary}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("addresses");

        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }

    @Test
    void testValidationFailureIfKnowNameIsEmptyForContacts() {
        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        List<RoDataUpdateContact> contacts = roDataUpdateV1.getContacts();
        contacts.get(0).setFirstName("");
        roDataUpdateV1.setContacts(contacts);
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .checkAllCommonFieldsForROVO(roDataUpdateV1, context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidLinkedOrganisations(roDataUpdateV1, context, false);
        when(contactTypeRepository.findById(
                        roDataUpdateV1.getContacts().get(0).getContactTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getPrimaryContactTypeData()));
        when(contactTypeRepository.findById(
                        roDataUpdateV1.getContacts().get(1).getContactTypeUuid()))
                .thenReturn(
                        Optional.of(CreateOrganisationDataSetup.getResultsAdminContactTypeData()));
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.firstName.Primary}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("contacts");

        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }

    @Test
    void testValidationFailureIfLastNameIsEmptyForContacts() {
        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        List<RoDataUpdateContact> contacts = roDataUpdateV1.getContacts();
        contacts.get(0).setLastName("");
        roDataUpdateV1.setContacts(contacts);
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .checkAllCommonFieldsForROVO(roDataUpdateV1, context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidLinkedOrganisations(roDataUpdateV1, context, false);
        when(contactTypeRepository.findById(
                        roDataUpdateV1.getContacts().get(0).getContactTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getPrimaryContactTypeData()));
        when(contactTypeRepository.findById(
                        roDataUpdateV1.getContacts().get(1).getContactTypeUuid()))
                .thenReturn(
                        Optional.of(CreateOrganisationDataSetup.getResultsAdminContactTypeData()));
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.lastName.Primary}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("contacts");

        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }

    @Test
    void testValidationFailureIfEmailIsInvalidForContactsAddresses() {
        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        List<RoDataUpdateAddress> address = roDataUpdateV1.getContacts().get(0).getAddresses();
        address.get(0).setEmail(".com");
        List<RoDataUpdateContact> contacts = roDataUpdateV1.getContacts();
        contacts.get(0).setAddresses(address);
        roDataUpdateV1.setContacts(contacts);
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .checkAllCommonFieldsForROVO(roDataUpdateV1, context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidLinkedOrganisations(roDataUpdateV1, context, false);
        when(contactTypeRepository.findById(
                        roDataUpdateV1.getContacts().get(0).getContactTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getPrimaryContactTypeData()));
        when(contactTypeRepository.findById(
                        roDataUpdateV1.getContacts().get(1).getContactTypeUuid()))
                .thenReturn(
                        Optional.of(CreateOrganisationDataSetup.getResultsAdminContactTypeData()));
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.email.Primary}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("addresses");

        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }

    @Test
    void testValidationFailureIfEmailIsDuplicate() {
        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        List<RoDataUpdateAddress> address = roDataUpdateV1.getContacts().get(1).getAddresses();
        address.get(0).setEmail("alan@gmail.com");
        Address address1 = new Address();
        address1.setEmail("alan@gmail.com");
        List<RoDataUpdateContact> contacts = roDataUpdateV1.getContacts();
        contacts.get(0).setAddresses(address);
        roDataUpdateV1.setContacts(contacts);
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .checkAllCommonFieldsForROVO(roDataUpdateV1, context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidLinkedOrganisations(roDataUpdateV1, context, false);
        when(contactTypeRepository.findById(
                        roDataUpdateV1.getContacts().get(0).getContactTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getPrimaryContactTypeData()));
        when(contactTypeRepository.findById(
                        roDataUpdateV1.getContacts().get(1).getContactTypeUuid()))
                .thenReturn(
                        Optional.of(CreateOrganisationDataSetup.getResultsAdminContactTypeData()));
        when(addressRepository
                        .findByEmailAndRecognisingOrganisationRecognisingOrganisationUuidNotAndContactContactUuidIsNotNull(
                                "alan@gmail.com",
                                UUID.fromString("88e18cae-1bdd-45a7-be1c-0a37926f9bbe")))
                .thenReturn(Collections.singletonList(address1));
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.email.Duplicate}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("addresses");

        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("Validate Organisation Name")
    @Test
    void testValidationFailureIfOrgNameIsEmpty() {

        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdateV1.setOrganisationName(null);
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidContactToUpdate(
                        roDataUpdateV1.getContacts(),
                        context,
                        false,
                        roDataUpdateV1.getRecognisingOrganisationUuid(),
                        roDataUpdateV1.getVerificationStatus().getValue());
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidPartnerCode(roDataUpdateV1.getPartnerCode(), context, false);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidSectorType(roDataUpdateV1.getSectorTypeUuid(), context, false);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidAddressToUpdate(roDataUpdateV1.getAddresses(), context, false);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidMinimumScores(roDataUpdateV1.getMinimumScores(), context, false);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidLinkedOrganisations(roDataUpdateV1, context, false);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.organisationName}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("organisationName");

        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("Validate Partner Code")
    @Test
    void testValidationFailureIfPartnerCodeisInvalidOrEmpty() {

        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdateV1.setPartnerCode("Inactive");
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isEmptyOrganisationName(roDataUpdateV1.getOrganisationName(), context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidContactToUpdate(
                        roDataUpdateV1.getContacts(),
                        context,
                        false,
                        roDataUpdateV1.getRecognisingOrganisationUuid(),
                        roDataUpdateV1.getVerificationStatus().getValue());
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidSectorType(roDataUpdateV1.getSectorTypeUuid(), context, false);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidAddressToUpdate(roDataUpdateV1.getAddresses(), context, false);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidLinkedOrganisations(roDataUpdateV1, context, false);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidMinimumScores(roDataUpdateV1.getMinimumScores(), context, false);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.partnerCode}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("partnerCode");
        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("Validate Sector Type")
    @Test
    void testValidationFailureIfSectorTypeIsInvalidOrEmpty() {
        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdateV1.setSectorTypeUuid(null);

        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.sectorTypeUuid}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("sectorTypeUuid");
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isEmptyOrganisationName(roDataUpdateV1.getOrganisationName(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidPartnerCode(roDataUpdateV1.getPartnerCode(), context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidContactToUpdate(
                        roDataUpdateV1.getContacts(),
                        context,
                        false,
                        roDataUpdateV1.getRecognisingOrganisationUuid(),
                        roDataUpdateV1.getVerificationStatus().getValue());
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidLinkedOrganisations(roDataUpdateV1, context, false);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidAddressToUpdate(roDataUpdateV1.getAddresses(), context, false);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidMinimumScores(roDataUpdateV1.getMinimumScores(), context, false);
        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("Validate Address Type")
    @Test
    void testValidationFailureIfAddressTypeIsInvalidOrEmpty() {

        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isEmptyOrganisationName(roDataUpdateV1.getOrganisationName(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidPartnerCode(roDataUpdateV1.getPartnerCode(), context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidContactToUpdate(
                        roDataUpdateV1.getContacts(),
                        context,
                        false,
                        roDataUpdateV1.getRecognisingOrganisationUuid(),
                        roDataUpdateV1.getVerificationStatus().getValue());
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidSectorType(roDataUpdateV1.getSectorTypeUuid(), context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidMinimumScores(roDataUpdateV1.getMinimumScores(), context, false);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidLinkedOrganisations(roDataUpdateV1, context, false);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.addressTypeName}");
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.mainAddress}");
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.deliveryAddress}");
        doReturn(nodeBuilderCustomizableContext)
                .when(builder)
                .addPropertyNode(OrganisationConstants.GenericConstants.ADDRESS_PROPERTY_NODE);

        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("Validate Address Lines")
    @Test
    void testValidationFailureIfAddressLineIsEmpty() {

        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        List<RoDataUpdateAddress> address = roDataUpdateV1.getAddresses();
        address.get(0).setAddressLine1("");
        roDataUpdateV1.setAddresses(address);
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isEmptyOrganisationName(roDataUpdateV1.getOrganisationName(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidPartnerCode(roDataUpdateV1.getPartnerCode(), context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidContactToUpdate(
                        roDataUpdateV1.getContacts(),
                        context,
                        false,
                        roDataUpdateV1.getRecognisingOrganisationUuid(),
                        roDataUpdateV1.getVerificationStatus().getValue());
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidSectorType(roDataUpdateV1.getSectorTypeUuid(), context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidMinimumScores(roDataUpdateV1.getMinimumScores(), context, false);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidLinkedOrganisations(roDataUpdateV1, context, false);
        when(addressTypeRepository.findById(
                        UUID.fromString("d13761e9-c134-4f80-a0a8-239a683a9c00")))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getDeliveryAddressTypeData()));
        when(addressTypeRepository.findById(
                        roDataUpdateV1.getAddresses().get(0).getAddressTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getAddressTypeData()));
        when(countryRepository.findById(roDataUpdateV1.getAddresses().get(0).getCountryUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getCountryData()));
        when(territoryRepository.findById(roDataUpdateV1.getAddresses().get(0).getTerritoryUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getTerritoryData()));
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate(
                        "{cmds.invalid.addressline1."
                                + CreateOrganisationDataSetup.getAddressTypeData()
                                        .getAddressTypeName()
                                + "}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("addresses");

        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("Validate City")
    @Test
    void testValidationFailureIfCityIsEmpty() {

        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        List<RoDataUpdateAddress> address = roDataUpdateV1.getAddresses();
        address.get(0).setCity("");
        roDataUpdateV1.setAddresses(address);
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isEmptyOrganisationName(roDataUpdateV1.getOrganisationName(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidPartnerCode(roDataUpdateV1.getPartnerCode(), context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidContactToUpdate(
                        roDataUpdateV1.getContacts(),
                        context,
                        false,
                        roDataUpdateV1.getRecognisingOrganisationUuid(),
                        roDataUpdateV1.getVerificationStatus().getValue());
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidSectorType(roDataUpdateV1.getSectorTypeUuid(), context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidMinimumScores(roDataUpdateV1.getMinimumScores(), context, false);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidLinkedOrganisations(roDataUpdateV1, context, false);
        when(addressTypeRepository.findById(
                        UUID.fromString("d13761e9-c134-4f80-a0a8-239a683a9c00")))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getDeliveryAddressTypeData()));
        when(addressTypeRepository.findById(
                        roDataUpdateV1.getAddresses().get(0).getAddressTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getAddressTypeData()));
        when(countryRepository.findById(roDataUpdateV1.getAddresses().get(0).getCountryUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getCountryData()));
        when(territoryRepository.findById(roDataUpdateV1.getAddresses().get(0).getTerritoryUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getTerritoryData()));
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate(
                        "{cmds.invalid.city."
                                + CreateOrganisationDataSetup.getAddressTypeData()
                                        .getAddressTypeName()
                                + "}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("addresses");

        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("Validate Country Name")
    @Test
    void testValidationFailureIfCountryIsEmpty() {

        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        List<RoDataUpdateAddress> address = roDataUpdateV1.getAddresses();
        address.get(0).setCountryUuid(null);
        roDataUpdateV1.setAddresses(address);
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isEmptyOrganisationName(roDataUpdateV1.getOrganisationName(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidPartnerCode(roDataUpdateV1.getPartnerCode(), context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidContactToUpdate(
                        roDataUpdateV1.getContacts(),
                        context,
                        false,
                        roDataUpdateV1.getRecognisingOrganisationUuid(),
                        roDataUpdateV1.getVerificationStatus().getValue());
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidSectorType(roDataUpdateV1.getSectorTypeUuid(), context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidMinimumScores(roDataUpdateV1.getMinimumScores(), context, false);
        when(addressTypeRepository.findById(
                        UUID.fromString("d13761e9-c134-4f80-a0a8-239a683a9c00")))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getDeliveryAddressTypeData()));
        when(addressTypeRepository.findById(
                        roDataUpdateV1.getAddresses().get(0).getAddressTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getAddressTypeData()));
        when(territoryRepository.findById(roDataUpdateV1.getAddresses().get(0).getTerritoryUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getTerritoryData()));
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidLinkedOrganisations(roDataUpdateV1, context, false);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate(
                        "{cmds.invalid.countryName."
                                + CreateOrganisationDataSetup.getAddressTypeData()
                                        .getAddressTypeName()
                                + "}");
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.countryName.Delivery}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("addresses");

        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("Validate TerritoryUuid")
    @Test
    void testValidationFailureIfTerritoryIsInvalid() {

        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        List<RoDataUpdateAddress> address = roDataUpdateV1.getAddresses();
        address.get(0).setTerritoryUuid(UUID.fromString("d13761e9-c134-4f80-a0a8-239a683a9c00"));
        roDataUpdateV1.setAddresses(address);
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isEmptyOrganisationName(roDataUpdateV1.getOrganisationName(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidPartnerCode(roDataUpdateV1.getPartnerCode(), context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidContactToUpdate(
                        roDataUpdateV1.getContacts(),
                        context,
                        false,
                        roDataUpdateV1.getRecognisingOrganisationUuid(),
                        roDataUpdateV1.getVerificationStatus().getValue());
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidSectorType(roDataUpdateV1.getSectorTypeUuid(), context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidMinimumScores(roDataUpdateV1.getMinimumScores(), context, false);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidLinkedOrganisations(roDataUpdateV1, context, false);
        when(addressTypeRepository.findById(
                        UUID.fromString("d13761e9-c134-4f80-a0a8-239a683a9c00")))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getDeliveryAddressTypeData()));
        when(addressTypeRepository.findById(
                        roDataUpdateV1.getAddresses().get(0).getAddressTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getAddressTypeData()));
        when(countryRepository.findById(roDataUpdateV1.getAddresses().get(0).getCountryUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getCountryData()));
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate(
                        "{cmds.invalid.territoryUuid."
                                + CreateOrganisationDataSetup.getAddressTypeData()
                                        .getAddressTypeName()
                                + "}");
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.territoryUuid.Delivery}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("addresses");

        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("Validate ModuleTypeUuid")
    @Test
    void testValidationFailureIfModuleTypeUuidIsInvalid() {

        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isEmptyOrganisationName(roDataUpdateV1.getOrganisationName(), context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidContactToUpdate(
                        roDataUpdateV1.getContacts(),
                        context,
                        false,
                        roDataUpdateV1.getRecognisingOrganisationUuid(),
                        roDataUpdateV1.getVerificationStatus().getValue());
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidPartnerCode(roDataUpdateV1.getPartnerCode(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidSectorType(roDataUpdateV1.getSectorTypeUuid(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidAddressToUpdate(roDataUpdateV1.getAddresses(), context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidLinkedOrganisations(roDataUpdateV1, context, false);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.moduleTypeUuid}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("minimumScores");

        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }

    @Test
    void testValidationFailureIfVerificationStatusIsInvalidForVO() {
        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        OrganisationType orgType = CreateOrganisationDataSetup.getOrganisationTypeData();
        orgType.setOrganisationsType("VO");
        orgType.setDescription("Verified Organisation");
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(orgType));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .checkAllCommonFieldsForROVO(roDataUpdateV1, context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidLinkedOrganisations(roDataUpdateV1, context, false);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.verificationStatus}");
        doReturn(nodeBuilderCustomizableContext)
                .when(builder)
                .addPropertyNode("verificationStatus");

        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }

    @Test
    void testValidationFailureIfMethodOfDeliveryIsInvalidForVO() {
        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdateV1.setVerificationStatus(VerificationStatusEnum.valueOf(VerificationStatusEnum.VERIFIED.getValue()));
        roDataUpdateV1.setMethodOfDelivery(MethodOfDeliveryEnum.E_DELIVERY);
        OrganisationType orgType = CreateOrganisationDataSetup.getOrganisationTypeData();
        orgType.setOrganisationsType("VO");
        orgType.setDescription("Verified Organisation");
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(orgType));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .checkAllCommonFieldsForROVO(roDataUpdateV1, context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidLinkedOrganisations(roDataUpdateV1, context, false);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.methodOfDelivery}");
        doReturn(nodeBuilderCustomizableContext).when(builder).addPropertyNode("methodOfDelivery");

        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("Validate Parent in LinkedOrganisations")
    @Test
    void testValidationFailureIfThereIsMoreThanOneParent() {

        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdateV1
                .getLinkedOrganisations()
                .addAll(UpdateOrganisationDataSetup.getLinkedOrganisationsData());
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        when(recognisingOrganisationRepository.findById(
                        roDataUpdateV1
                                .getLinkedOrganisations()
                                .get(0)
                                .getTargetRecognisingOrganisationUuid()))
                .thenReturn(
                        Optional.of(CreateOrganisationDataSetup.getExistingOrganisationDetails()));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isEmptyOrganisationName(roDataUpdateV1.getOrganisationName(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidContactToUpdate(
                        roDataUpdateV1.getContacts(),
                        context,
                        true,
                        roDataUpdateV1.getRecognisingOrganisationUuid(),
                        roDataUpdateV1.getVerificationStatus().getValue());
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidPartnerCode(roDataUpdateV1.getPartnerCode(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidSectorType(roDataUpdateV1.getSectorTypeUuid(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidAddressToUpdate(roDataUpdateV1.getAddresses(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidMinimumScores(roDataUpdateV1.getMinimumScores(), context, true);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate(
                        "{cmds.invalid.linkedRecognisingOrganisationType}");
        doReturn(nodeBuilderCustomizableContext)
                .when(builder)
                .addPropertyNode(
                        OrganisationConstants.GenericConstants.LINKED_ORGANISATIONS_PROPERTY_NODE);

        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("Validate if Parent is active in LinkedOrganisations")
    @Test
    void testValidationFailureIfParentisInactive() {

        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        RecognisingOrganisation existingRO =
                CreateOrganisationDataSetup.getExistingOrganisationDetails();
        existingRO.setOrgStatus(OrganisationStatusEnum.INACTIVE);
        when(recognisingOrganisationRepository.findById(
                        roDataUpdateV1
                                .getLinkedOrganisations()
                                .get(0)
                                .getTargetRecognisingOrganisationUuid()))
                .thenReturn(Optional.of(existingRO));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isEmptyOrganisationName(roDataUpdateV1.getOrganisationName(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidContactToUpdate(
                        roDataUpdateV1.getContacts(),
                        context,
                        true,
                        roDataUpdateV1.getRecognisingOrganisationUuid(),
                        roDataUpdateV1.getVerificationStatus().getValue());
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidPartnerCode(roDataUpdateV1.getPartnerCode(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidSectorType(roDataUpdateV1.getSectorTypeUuid(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidAddressToUpdate(roDataUpdateV1.getAddresses(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidMinimumScores(roDataUpdateV1.getMinimumScores(), context, true);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.inactiveParent}");
        doReturn(nodeBuilderCustomizableContext)
                .when(builder)
                .addPropertyNode(
                        OrganisationConstants.GenericConstants.LINKED_ORGANISATIONS_PROPERTY_NODE);

        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("Validate result available for years")
    @Test
    void testValidationFailureIfResultAvailableForYearsIsLessThan2() {

        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdateV1.setResultAvailableForYears(1);
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        when(recognisingOrganisationRepository.findById(
                        roDataUpdateV1
                                .getLinkedOrganisations()
                                .get(0)
                                .getTargetRecognisingOrganisationUuid()))
                .thenReturn(
                        Optional.of(CreateOrganisationDataSetup.getExistingOrganisationDetails()));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isEmptyOrganisationName(roDataUpdateV1.getOrganisationName(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidContactToUpdate(
                        roDataUpdateV1.getContacts(),
                        context,
                        true,
                        roDataUpdateV1.getRecognisingOrganisationUuid(),
                        roDataUpdateV1.getVerificationStatus().getValue());
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidPartnerCode(roDataUpdateV1.getPartnerCode(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidSectorType(roDataUpdateV1.getSectorTypeUuid(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidAddressToUpdate(roDataUpdateV1.getAddresses(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidMinimumScores(roDataUpdateV1.getMinimumScores(), context, true);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.resultAvailableForYears}");
        doReturn(nodeBuilderCustomizableContext)
                .when(builder)
                .addPropertyNode(OrganisationConstants.GenericConstants.RESULT_AVAILABLE_FOR_YEARS);

        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("Validate result available for years")
    @Test
    void testValidationFailureIfResultAvailableForYearsIsGreaterThan10() {

        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdateV1.setResultAvailableForYears(20);
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        when(recognisingOrganisationRepository.findById(
                        roDataUpdateV1
                                .getLinkedOrganisations()
                                .get(0)
                                .getTargetRecognisingOrganisationUuid()))
                .thenReturn(
                        Optional.of(CreateOrganisationDataSetup.getExistingOrganisationDetails()));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isEmptyOrganisationName(roDataUpdateV1.getOrganisationName(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidContactToUpdate(
                        roDataUpdateV1.getContacts(),
                        context,
                        true,
                        roDataUpdateV1.getRecognisingOrganisationUuid(),
                        roDataUpdateV1.getVerificationStatus().getValue());
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidPartnerCode(roDataUpdateV1.getPartnerCode(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidSectorType(roDataUpdateV1.getSectorTypeUuid(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidAddressToUpdate(roDataUpdateV1.getAddresses(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidMinimumScores(roDataUpdateV1.getMinimumScores(), context, true);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.resultAvailableForYears}");
        doReturn(nodeBuilderCustomizableContext)
                .when(builder)
                .addPropertyNode(OrganisationConstants.GenericConstants.RESULT_AVAILABLE_FOR_YEARS);

        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }
    @DisplayName("AC and GT Null")
    @Test
    void testValidationFailureIfAcNullAndGTNull() {

        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdateV1.setAcceptsAC(null);
        roDataUpdateV1.setAcceptsGT(null);
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        when(recognisingOrganisationRepository.findById(
                roDataUpdateV1
                        .getLinkedOrganisations()
                        .get(0)
                        .getTargetRecognisingOrganisationUuid()))
                .thenReturn(
                        Optional.of(CreateOrganisationDataSetup.getExistingOrganisationDetails()));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isEmptyOrganisationName(roDataUpdateV1.getOrganisationName(), context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidContactToUpdate(
                        roDataUpdateV1.getContacts(),
                        context,
                        false,
                        roDataUpdateV1.getRecognisingOrganisationUuid(),
                        roDataUpdateV1.getVerificationStatus().getValue());
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidPartnerCode(roDataUpdateV1.getPartnerCode(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidSectorType(roDataUpdateV1.getSectorTypeUuid(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidAddressToUpdate(roDataUpdateV1.getAddresses(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidMinimumScores(roDataUpdateV1.getMinimumScores(), context, true);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.productAcceptance}");
        doReturn(nodeBuilderCustomizableContext)
                .when(builder)
                .addPropertyNode(OrganisationConstants.GenericConstants.PRODUCT_ACCEPTANCE);

        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("AC and GT Null")
    @Test
    void testValidationFailureIfAcFalseAndGTNull() {

        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdateV1.setAcceptsAC(false);
        roDataUpdateV1.setAcceptsGT(null);
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        when(recognisingOrganisationRepository.findById(
                roDataUpdateV1
                        .getLinkedOrganisations()
                        .get(0)
                        .getTargetRecognisingOrganisationUuid()))
                .thenReturn(
                        Optional.of(CreateOrganisationDataSetup.getExistingOrganisationDetails()));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isEmptyOrganisationName(roDataUpdateV1.getOrganisationName(), context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidContactToUpdate(
                        roDataUpdateV1.getContacts(),
                        context,
                        false,
                        roDataUpdateV1.getRecognisingOrganisationUuid(),
                        roDataUpdateV1.getVerificationStatus().getValue());
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidPartnerCode(roDataUpdateV1.getPartnerCode(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidSectorType(roDataUpdateV1.getSectorTypeUuid(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidAddressToUpdate(roDataUpdateV1.getAddresses(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidMinimumScores(roDataUpdateV1.getMinimumScores(), context, true);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.productAcceptance}");
        doReturn(nodeBuilderCustomizableContext)
                .when(builder)
                .addPropertyNode(OrganisationConstants.GenericConstants.PRODUCT_ACCEPTANCE);

        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }

    @DisplayName("AC and GT Null")
    @Test
    void testValidationFailureIfAcNullAndGTFalse() {

        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdateV1.setAcceptsAC(null);
        roDataUpdateV1.setAcceptsGT(false);
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getOrganisationTypeData()));
        when(recognisingOrganisationRepository.findById(
                roDataUpdateV1
                        .getLinkedOrganisations()
                        .get(0)
                        .getTargetRecognisingOrganisationUuid()))
                .thenReturn(
                        Optional.of(CreateOrganisationDataSetup.getExistingOrganisationDetails()));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isEmptyOrganisationName(roDataUpdateV1.getOrganisationName(), context, true);
        doReturn(false)
                .when(checkUpdateRoVoDetails)
                .isValidContactToUpdate(
                        roDataUpdateV1.getContacts(),
                        context,
                        false,
                        roDataUpdateV1.getRecognisingOrganisationUuid(),
                        roDataUpdateV1.getVerificationStatus().getValue());
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidPartnerCode(roDataUpdateV1.getPartnerCode(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidSectorType(roDataUpdateV1.getSectorTypeUuid(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidAddressToUpdate(roDataUpdateV1.getAddresses(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidMinimumScores(roDataUpdateV1.getMinimumScores(), context, true);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.productAcceptance}");
        doReturn(nodeBuilderCustomizableContext)
                .when(builder)
                .addPropertyNode(OrganisationConstants.GenericConstants.PRODUCT_ACCEPTANCE);

        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }
    @DisplayName("Invalid Update ")
    @Test
    void testUpdateFailureROisUpdatedFromROToVOWhenROHasAdo() {

        RoDataUpdateV1Valid roDataUpdateV1 = UpdateOrganisationDataSetup.updateOrgData();
        roDataUpdateV1.setOrganisationTypeUuid(UUID.fromString("e392ae7c-016f-433a-bdfa-b79bfcdddf26"));
        roDataUpdateV1.setVerificationStatus(VerificationStatusEnum.VERIFIED);

        RecognisingOrganisation organisation =
                UpdateOrganisationDataSetup.getExistingOrganisationDetails(
                        roDataUpdateV1, new RecognisingOrganisation());
        organisation.setOrganisationTypeUuid(UUID.fromString("e496aa98-86a3-476d-8be3-21ee0aa23c93"));
        List<LinkedRecognisingOrganisation> linkedRecognisingOrganisationList = new ArrayList<>();
        LinkedRecognisingOrganisation linkedRecognisingOrganisation = new LinkedRecognisingOrganisation();
        linkedRecognisingOrganisation.setSourceRecognisingOrganisation(organisation);

        RecognisingOrganisation targetRecognisingOrganisation = new RecognisingOrganisation();
        targetRecognisingOrganisation.setRecognisingOrganisationUuid(UUID.fromString("705fc839-5051-4a22-a77d-cf6d734d7d24"));

        linkedRecognisingOrganisation.setTargetRecognisingOrganisation(targetRecognisingOrganisation);
        linkedRecognisingOrganisation.setLinkedRecognisingOrganisationType(LinkTypeEnum.RESULTS_DELIVERY);
        linkedRecognisingOrganisationList.add(linkedRecognisingOrganisation);

        when(linkedRORepository.findByTargetRecognisingOrganisationRecognisingOrganisationUuidAndLinkedRecognisingOrganisationType(roDataUpdateV1.getRecognisingOrganisationUuid(), LinkTypeEnum.RESULTS_DELIVERY))
                .thenReturn(linkedRecognisingOrganisationList);
        when(orgTypeRepository.findById(roDataUpdateV1.getOrganisationTypeUuid()))
                .thenReturn(Optional.of(CreateOrganisationDataSetup.getVOOrganisationTypeData()));
        when(recognisingOrganisationRepository.findByRecognisingOrganisationUuid(
                UUID.fromString("88e18cae-1bdd-45a7-be1c-0a37926f9bbe")))
                .thenReturn(Optional.of(organisation));
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isEmptyOrganisationName(roDataUpdateV1.getOrganisationName(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidPartnerCode(roDataUpdateV1.getPartnerCode(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidSectorType(roDataUpdateV1.getSectorTypeUuid(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidAddressToUpdate(roDataUpdateV1.getAddresses(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                .isValidMinimumScores(roDataUpdateV1.getMinimumScores(), context, true);
        doReturn(true)
                .when(checkUpdateRoVoDetails)
                        .isValidLinkedOrganisations(roDataUpdateV1, context, true);
        doReturn(builder)
                .when(context)
                .buildConstraintViolationWithTemplate("{cmds.invalid.organisationTypeToUpdate}");
        doReturn(nodeBuilderCustomizableContext)
                .when(builder)
                .addPropertyNode("organisationTypeUuid");

        boolean isValid = checkUpdateRoVoDetails.isValid(roDataUpdateV1, context);
        assertEquals(false, isValid);
    }
}
