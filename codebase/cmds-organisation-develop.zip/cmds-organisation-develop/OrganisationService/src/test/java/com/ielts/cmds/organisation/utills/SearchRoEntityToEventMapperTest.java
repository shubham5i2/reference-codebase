package com.ielts.cmds.organisation.utills;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

import com.ielts.cmds.api.roui005rosearchrequested.RoSearchCriteria;
import com.ielts.cmds.api.roui005rosearchrequested.RoSearchObject;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1;
import com.ielts.cmds.organisation.domain.commands.CreateROVO;
import com.ielts.cmds.organisation.domain.commands.SearchROVO;
import com.ielts.cmds.organisation.infrastructure.entity.AddressType;
import com.ielts.cmds.organisation.infrastructure.entity.ContactType;
import com.ielts.cmds.organisation.infrastructure.entity.Country;
import com.ielts.cmds.organisation.infrastructure.entity.OrganisationType;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.entity.Territory;
import com.ielts.cmds.organisation.infrastructure.repository.AddressTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.ContactTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.CountryRepository;
import com.ielts.cmds.organisation.infrastructure.repository.OrganisationTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.TerritoryRepository;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.SearchRoEntityToEventMapper;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
class SearchRoEntityToEventMapperTest {

    @Mock private CountryRepository countryRepository;

    @Mock private TerritoryRepository territoryRepository;

    @Mock private AddressTypeRepository addressTypeRepository;

    @Mock private OrganisationTypeRepository organisationTypeRepository;

    @InjectMocks SearchRoEntityToEventMapper searchRoEntityToEventMapper;

    @Spy private OrganisationCommonUtils orgCommonUtils;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(searchRoEntityToEventMapper, "orgCommonUtils", orgCommonUtils);
    }

    @ParameterizedTest
    @MethodSource("provideArgumentsForMapper")
    void whenSearchRoEntityMapper_ValidROList_RoSearchResultEventGenerated(
            final RoSearchObject roSearchObject,
            final List<RecognisingOrganisation> recognisingOrganisations,
            final List<Country> countryList,
            final List<Territory> territoryList,
            final List<ContactType> contactTypeList,
            final List<AddressType> addressTypeList,
            final List<OrganisationType> organisationTypeList) {
        doReturn(countryList).when(countryRepository).findAll();
        doReturn(territoryList).when(territoryRepository).findAll();
        doReturn(addressTypeList).when(addressTypeRepository).findAll();
        doReturn(organisationTypeList).when(organisationTypeRepository).findAll();

        RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1 =
                searchRoEntityToEventMapper.mapEntityToEvent(
                        roSearchObject, recognisingOrganisations, 1L);
        assertNotNull(rosSearchResultsGeneratedEventV1);
        RoSearchCriteria expected = roSearchObject.getCriteria();
        assertEquals(
                expected.getCity(),
                rosSearchResultsGeneratedEventV1.getSearch().getCriteria().getCity());
        assertEquals(
                expected.getOrganisationId(),
                rosSearchResultsGeneratedEventV1.getSearch().getCriteria().getOrganisationId());
        assertEquals(
                expected.getPartnerCode(),
                rosSearchResultsGeneratedEventV1.getSearch().getCriteria().getPartnerCode());
        assertEquals(
                expected.getVerificationStatus().getValue(),
                rosSearchResultsGeneratedEventV1.getSearch().getCriteria().getVerificationStatus().getValue());
        assertEquals(
                expected.getContactEmail(),
                rosSearchResultsGeneratedEventV1.getSearch().getCriteria().getContactEmail());
    }

    private static Stream<Arguments> provideArgumentsForMapper() {
        RoSearchObject roSearchObject = SearchOrganisationDataSetup.getRoSearchData();
        SearchROVO searchROVO =
                SearchROVO.builder()
                        .eventBody(SearchOrganisationDataSetup.getRoSearchData())
                        .eventHeaders(OrganisationTestUtil.generateEventHeader())
                        .build();
        CreateROVO createRo =
                CreateROVO.builder()
                        .eventHeaders(OrganisationTestUtil.generateEventHeader())
                        .eventBody(CreateOrganisationDataSetup.createOrgData())
                        .build();
        RecognisingOrganisation organisation = new RecognisingOrganisation();
        RecognisingOrganisation recognisingOrganisation =
                CreateOrganisationDataSetup.populateOrganisation(createRo.getEventBody(), organisation);
        List<RecognisingOrganisation> recognisingOrganisations = new ArrayList<>();
        recognisingOrganisations.add(recognisingOrganisation);

        List<Country> countryList = new ArrayList<>();
        countryList.add(CreateOrganisationDataSetup.getTerritoryData().getCountry());
        List<Territory> territoryList = new ArrayList<>();
        territoryList.add(CreateOrganisationDataSetup.getTerritoryData());
        List<ContactType> contactTypeList = new ArrayList<>();
        contactTypeList.add(CreateOrganisationDataSetup.getContactTypeData());
        List<AddressType> addressTypeList = new ArrayList<>();
        addressTypeList.add(CreateOrganisationDataSetup.getAddressTypeData());
        addressTypeList.add(CreateOrganisationDataSetup.getDeliveryAddressTypeData());
        List<OrganisationType> organisationTypeList = new ArrayList<>();
        organisationTypeList.add(CreateOrganisationDataSetup.getOrganisationTypeData());

        return Stream.of(
                Arguments.of(roSearchObject,
                        recognisingOrganisations,
                        countryList,
                        territoryList,
                        contactTypeList,
                        addressTypeList,
                        organisationTypeList));
    }
}
