package com.ielts.cmds.organisation.domain.services;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.roui005rosearchrequested.RoSearchCriteria;
import com.ielts.cmds.api.roui005rosearchrequested.RoSearchObject;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.cache.JedisGenericReader;
import com.ielts.cmds.organisation.cache.factory.JedisFactory;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1;
import com.ielts.cmds.organisation.infrastructure.config.RBACTestConfig;
import com.ielts.cmds.organisation.infrastructure.entity.*;
import com.ielts.cmds.organisation.infrastructure.repository.*;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utills.SearchOrganisationDataSetup;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.organisation.utils.SearchRoEntityToEventMapper;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.api.service.impl.RBACServiceImpl;
import com.ielts.cmds.rbac.implementation.impl.LocationHierarchyServiceImpl;
import com.ielts.cmds.rbac.implementation.impl.UserGroupServiceImpl;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cache.CacheManager;
import org.springframework.cache.interceptor.SimpleKey;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlMergeMode;
import org.springframework.test.context.jdbc.SqlMergeMode.MergeMode;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

import javax.transaction.Transactional;
import javax.validation.ValidationException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = RBACTestConfig.class)
@ActiveProfiles("test")
@Sql(
        scripts = {
            "/sql/schema.sql",
            "/sql/note-type-data.sql",
            "/sql/contact-type-data.sql",
            "/sql/country-data.sql",
            "/sql/territory-data.sql",
            "/sql/ro-data-for-search.sql",
            "/sql/usergroup-hierarchy.sql",
            "/sql/address-type-data.sql",
            "/sql/organisation-type-data.sql"
        },
        executionPhase = ExecutionPhase.BEFORE_TEST_METHOD)
@SqlMergeMode(MergeMode.MERGE)
@Transactional
class SearchOrganisationDomainServiceIntegrationTest {

    @Autowired private SearchOrganisationDomainService searchOrganisationDomainService;

    @Autowired private CountryRepository countryRepository;

    @Autowired private TerritoryRepository territoryRepository;

    @Autowired private ContactTypeRepository contactTypeRepository;

    @Autowired private AddressTypeRepository addressTypeRepository;

    @Autowired private OrganisationTypeRepository organisationTypeRepository;

    @Autowired private CacheManager cacheManager;

    @Autowired private RBACServiceImpl rbacServiceImpl;

    @Autowired private UserGroupServiceImpl userGroupServiceImpl;

    @Autowired private LocationHierarchyServiceImpl locationHierarchyServiceImpl;

    @MockBean private ApplicationEventPublisher applicationEventPublisher;

    @MockBean private SearchRoEntityToEventMapper searchRoEntityToEventMapper;
    
    @Spy private SearchRoEntityToEventMapper searchRoEntityToEventMapperSpy;

    @Captor private ArgumentCaptor<List<RecognisingOrganisation>> fetchedListCaptor;

    @Captor private ArgumentCaptor<List<Country>> countryListCaptor;

    @Captor private ArgumentCaptor<List<Territory>> territoryListCaptor;

    @Captor private ArgumentCaptor<List<ContactType>> contactTypeListCaptor;

    @Autowired private ObjectMapper objectMapper;

    @Spy private OrganisationCommonUtils orgCommonUtils;

    @Autowired private CMDSThreadLocalContextService cmdsThreadLocalContextService;

    @MockBean private JedisGenericReader jedisGenericReader;

    @MockBean private JedisFactory jedisFactory;

    @BeforeEach
    void setup() throws RbacValidationException {
        MockitoAnnotations.initMocks(this);
        userGroupServiceImpl.populateUserGroupHierarchyData();
        locationHierarchyServiceImpl.populateRootData();
        ReflectionTestUtils.setField(searchOrganisationDomainService, "orgUtils", orgCommonUtils);

        ReflectionTestUtils.setField(
                searchOrganisationDomainService,
                "searchRoEntityToEventMapper",
                searchRoEntityToEventMapper);
        ReflectionTestUtils.setField(
                searchOrganisationDomainService, "rbacServiceImpl", rbacServiceImpl);
        ReflectionTestUtils.setField(searchOrganisationDomainService, "objectMapper", objectMapper);
        ReflectionTestUtils.setField(
                searchOrganisationDomainService,
                "applicationEventPublisher",
                applicationEventPublisher);
        ThreadLocalHeaderContext.setContext(OrganisationTestUtil.generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_CREATE_REQUEST_EVENT));
        ThreadLocalAuditContext.setContext(OrganisationTestUtil.getBaseAudit());
        ReflectionTestUtils.setField(
                orgCommonUtils, "jedisGenericReader", jedisGenericReader);

    }

    @SuppressWarnings("unchecked")
    @Test
    void whenCountryRepository_findAll_ExpectCountriesToBeCached() {
        assertFalse(
                Optional.ofNullable(
                                cacheManager.getCache("countries").get(SimpleKey.EMPTY, List.class))
                        .isPresent());
        final List<Country> fetchedCountries = countryRepository.findAll();
        final List<Country> cachedCountries =
                Optional.ofNullable(
                                cacheManager.getCache("countries").get(SimpleKey.EMPTY, List.class))
                        .orElse(null);
        assertNotNull(cachedCountries);
        assertEquals(fetchedCountries.size(), cachedCountries.size());
    }

    @SuppressWarnings("unchecked")
    @Test
    void whenTerritoryRepository_findAll_ExpectTerritoriesToBeCached() {
        assertFalse(
                Optional.ofNullable(
                                cacheManager
                                        .getCache("territories")
                                        .get(SimpleKey.EMPTY, List.class))
                        .isPresent());
        final List<Territory> fetchedTerritories = territoryRepository.findAll();
        final List<Territory> cachedTerritories =
                Optional.ofNullable(
                                cacheManager
                                        .getCache("territories")
                                        .get(SimpleKey.EMPTY, List.class))
                        .orElse(null);
        assertNotNull(cachedTerritories);
        assertEquals(fetchedTerritories.size(), cachedTerritories.size());
    }

    @SuppressWarnings("unchecked")
    @Test
    void whenContactTypeRepository_findAll_ExpectContactTypeToBeCached() {
        assertFalse(
                Optional.ofNullable(
                                cacheManager
                                        .getCache("contacttypes")
                                        .get(SimpleKey.EMPTY, List.class))
                        .isPresent());
        final List<ContactType> fetchedContactTypes = contactTypeRepository.findAll();
        final List<ContactType> cachedContactTypes =
                Optional.ofNullable(
                                cacheManager
                                        .getCache("contacttypes")
                                        .get(SimpleKey.EMPTY, List.class))
                        .orElse(null);
        assertNotNull(cachedContactTypes);
        assertEquals(fetchedContactTypes.size(), cachedContactTypes.size());
    }

    @SuppressWarnings("unchecked")
    @Test
    void whenAddressTypeRepository_findAll_ExpectAddressTypeToBeCached() {
        cacheManager.getCache("addresstypes").evictIfPresent(SimpleKey.EMPTY);
        assertFalse(
                Optional.ofNullable(
                                cacheManager
                                        .getCache("addresstypes")
                                        .get(SimpleKey.EMPTY, List.class))
                        .isPresent());
        final List<AddressType> fetchedAddressTypes = addressTypeRepository.findAll();
        final List<AddressType> cachedAddressTypes =
                Optional.ofNullable(
                                cacheManager
                                        .getCache("addresstypes")
                                        .get(SimpleKey.EMPTY, List.class))
                        .orElse(null);
        assertNotNull(cachedAddressTypes);
        assertEquals(fetchedAddressTypes.size(), cachedAddressTypes.size());
    }

    @SuppressWarnings("unchecked")
    @Test
    void whenOrganisationTypeRepository_findAll_ExpectOrganisationTypeToBeCached() {
        assertFalse(
                Optional.ofNullable(
                                cacheManager
                                        .getCache("organisationtypes")
                                        .get(SimpleKey.EMPTY, List.class))
                        .isPresent());
        final List<OrganisationType> fetchedOrganisationTypes =
                organisationTypeRepository.findAll();
        final List<OrganisationType> cachedOrganisationTypes =
                Optional.ofNullable(
                                cacheManager
                                        .getCache("organisationtypes")
                                        .get(SimpleKey.EMPTY, List.class))
                        .orElse(null);
        assertNotNull(cachedOrganisationTypes);
        assertEquals(fetchedOrganisationTypes.size(), cachedOrganisationTypes.size());
    }

    @Sql(
            scripts = "/sql/similarity-similar.sql",
            executionPhase = ExecutionPhase.BEFORE_TEST_METHOD)
    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchIntegrationTest")
    void whenValidToken_SearchROVO_ExpectDataFetched(
            final RoSearchObject roSearchObject,
            final Page<RecognisingOrganisation> page,
            final RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1)
            throws RbacValidationException, IOException {

        final RoSearchCriteria expectedCriteria = roSearchObject.getCriteria();
        ThreadLocalHeaderContext.getContext()
                .setXaccessToken(OrganisationTestUtil.getAccessToken("ops-manager-access-token"));
        doReturn(rosSearchResultsGeneratedEventV1)
                .when(searchRoEntityToEventMapper)
                .mapEntityToEvent(roSearchObject, page.getContent(), page.getTotalElements());

        doNothing().when(applicationEventPublisher).publishEvent(any(BaseEvent.class));

        searchOrganisationDomainService.onCommand(roSearchObject);

        verify(searchRoEntityToEventMapper)
                .mapEntityToEvent(
                        eq(roSearchObject), fetchedListCaptor.capture(), eq(page.getTotalElements()));
        final List<RecognisingOrganisation> actualList = fetchedListCaptor.getValue();
        assertEquals(1, actualList.size());
        final RecognisingOrganisation actualRo = actualList.get(0);
        assertEquals(8, actualRo.getAddresses().size());
        assertEquals(4, actualRo.getContacts().size());
        final Address actualAddress = actualRo.getAddresses().get(0);
        final Contact actualContact = actualRo.getContacts().get(0);
        assertEquals(expectedCriteria.getCity(), actualAddress.getCity());
        assertEquals(expectedCriteria.getContactEmail(), actualAddress.getEmail());
        assertEquals(
                expectedCriteria.getContactName(),
                actualContact.getFirstName() + " " + actualContact.getLastName());
        assertEquals(expectedCriteria.getCountry(), actualAddress.getCountryUuid());
    }
    @Sql(
            scripts = "/sql/similarity-similar.sql",
            executionPhase = ExecutionPhase.BEFORE_TEST_METHOD)
    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchIntegrationTest")
    void whenToggelOFF_SearchROVO_with_RoName_ExpectDataFetchedShouldBeFullTextSsearch(
            final RoSearchObject roSearchObject,
            final Page<RecognisingOrganisation> page,
            final RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1)
            throws RbacValidationException, IOException {

        ReflectionTestUtils.setField(
                searchOrganisationDomainService,
                "searchRoEntityToEventMapper",
                searchRoEntityToEventMapperSpy);

        ThreadLocalHeaderContext.getContext()
                .setXaccessToken(OrganisationTestUtil.getAccessToken("ops-manager-access-token"));
        roSearchObject.setCriteria(SearchOrganisationDataSetup.getRoSearchCriteriaOnlyOrgName());
        roSearchObject.getCriteria().setFuzzyMatch(false);
        List<RecognisingOrganisation> list = new ArrayList<>();
        list.add(new RecognisingOrganisation());
        list.add(new RecognisingOrganisation());
        list.add(new RecognisingOrganisation());

        Page<RecognisingOrganisation> page2 = new PageImpl<>(list);

        doNothing().when(applicationEventPublisher).publishEvent(any(BaseEvent.class));

        searchOrganisationDomainService.onCommand(roSearchObject);

        verify(searchRoEntityToEventMapperSpy)
                .mapEntityToEvent(
                        eq(roSearchObject), fetchedListCaptor.capture(), eq(page2.getTotalElements()));
        final List<RecognisingOrganisation> actualList = fetchedListCaptor.getValue();
        assertEquals(3, actualList.size());

    }

    @Sql(
            scripts = "/sql/similarity-similar.sql",
            executionPhase = ExecutionPhase.BEFORE_TEST_METHOD)
    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchIntegrationTest")
    void whenToggleOn_SearchROVO_with_RoName_ExpectDataFetchedShouldBeFuzzySsearch(
            final RoSearchObject roSearchObject,
            final Page<RecognisingOrganisation> page,
            final RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1)
            throws RbacValidationException, IOException {

        ReflectionTestUtils.setField(
                searchOrganisationDomainService,
                "searchRoEntityToEventMapper",
                searchRoEntityToEventMapperSpy);


        roSearchObject.getCriteria().setOrganisationName("cambridge University");
        ThreadLocalHeaderContext.getContext()
                .setXaccessToken(OrganisationTestUtil.getAccessToken("ops-manager-access-token"));
        roSearchObject.setCriteria(SearchOrganisationDataSetup.getRoSearchCriteriaOnlyOrgName());
        List<RecognisingOrganisation> list = new ArrayList<>();
        list.add(new RecognisingOrganisation());
        list.add(new RecognisingOrganisation());
        list.add(new RecognisingOrganisation());
        list.add(new RecognisingOrganisation());

        Page<RecognisingOrganisation> page2 = new PageImpl<>(list);

        doNothing().when(applicationEventPublisher).publishEvent(any(BaseEvent.class));

        searchOrganisationDomainService.onCommand(roSearchObject);

        verify(searchRoEntityToEventMapperSpy)
                .mapEntityToEvent(
                        eq(roSearchObject), fetchedListCaptor.capture(), eq(page2.getTotalElements()));
        final List<RecognisingOrganisation> actualList = fetchedListCaptor.getValue();
        assertEquals(4, actualList.size());

    }

    @Sql(
            scripts = "/sql/similarity-similar.sql",
            executionPhase = ExecutionPhase.BEFORE_TEST_METHOD)
    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchIntegrationTest")
    void whenValidToken_SearchROVO_with_country_ExpectDataFetched(
            final RoSearchObject roSearchObject,
            final Page<RecognisingOrganisation> page,
            final RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1)
            throws RbacValidationException, IOException {

        final RoSearchCriteria expectedCriteria = new RoSearchCriteria();
        expectedCriteria.setCountry(UUID.fromString("029fd27d-b39a-48b4-87e7-131a063bea2d"));
        ThreadLocalHeaderContext.getContext()
                .setXaccessToken(OrganisationTestUtil.getAccessToken("ops-manager-access-token"));
        doReturn(rosSearchResultsGeneratedEventV1)
                .when(searchRoEntityToEventMapper)
                .mapEntityToEvent(roSearchObject, page.getContent(), page.getTotalElements());

        doNothing().when(applicationEventPublisher).publishEvent(any(BaseEvent.class));

        searchOrganisationDomainService.onCommand(roSearchObject);

        verify(searchRoEntityToEventMapper)
                .mapEntityToEvent(
                        eq(roSearchObject), fetchedListCaptor.capture(), eq(page.getTotalElements()));
        final List<RecognisingOrganisation> actualList = fetchedListCaptor.getValue();
        assertEquals(1, actualList.size());
        final RecognisingOrganisation actualRo = actualList.get(0);
        assertEquals(8, actualRo.getAddresses().size());
        assertEquals(4, actualRo.getContacts().size());
        final Address actualAddress = actualRo.getAddresses().get(0);
        assertEquals(expectedCriteria.getCountry(), actualAddress.getCountryUuid());
    }

    @Sql(
            scripts = "/sql/similarity-similar.sql",
            executionPhase = ExecutionPhase.BEFORE_TEST_METHOD)
    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchIntegrationTest")
    void whenValidToken_SearchROVO_with_Territory_ExpectDataFetched(
            final RoSearchObject roSearchObject,
            final Page<RecognisingOrganisation> page,
            final RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1)
            throws RbacValidationException, IOException {

        final RoSearchCriteria expectedCriteria = new RoSearchCriteria();
        expectedCriteria.setTerritory(UUID.fromString("029fd27d-b39a-48b4-87e7-131a063bea2d"));;
        ThreadLocalHeaderContext.getContext()
                .setXaccessToken(OrganisationTestUtil.getAccessToken("ops-manager-access-token"));
        doReturn(rosSearchResultsGeneratedEventV1)
                .when(searchRoEntityToEventMapper)
                .mapEntityToEvent(roSearchObject, page.getContent(), page.getTotalElements());

        doNothing().when(applicationEventPublisher).publishEvent(any(BaseEvent.class));

        searchOrganisationDomainService.onCommand(roSearchObject);

        verify(searchRoEntityToEventMapper)
                .mapEntityToEvent(
                        eq(roSearchObject), fetchedListCaptor.capture(), eq(page.getTotalElements()));
        final List<RecognisingOrganisation> actualList = fetchedListCaptor.getValue();
        assertEquals(1, actualList.size());
        final RecognisingOrganisation actualRo = actualList.get(0);
        assertEquals(8, actualRo.getAddresses().size());
        assertEquals(4, actualRo.getContacts().size());
        final Address actualAddress = actualRo.getAddresses().get(0);
        assertEquals(expectedCriteria.getTerritory(), actualAddress.getTerritoryUuid());
    }
    @Sql(
            scripts = {"/sql/similarity-non-similar.sql", "/sql/usergroup-hierarchy.sql"},
            executionPhase = ExecutionPhase.BEFORE_TEST_METHOD)
    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchIntegrationTest")
    void whenValidToken_PartialMatchCriteriaNotMet_SearchROVO_ExpectDataFetched(
            final RoSearchObject roSearchObject,
            final Page<RecognisingOrganisation> page,
            final RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1)
            throws RbacValidationException, IOException {

        ThreadLocalHeaderContext.getContext()
                .setXaccessToken(OrganisationTestUtil.getAccessToken("ops-manager-access-token"));
        doReturn(rosSearchResultsGeneratedEventV1)
                .when(searchRoEntityToEventMapper)
                .mapEntityToEvent(roSearchObject, page.getContent(), page.getTotalElements());

        doNothing().when(applicationEventPublisher).publishEvent(any(BaseEvent.class));

        searchOrganisationDomainService.onCommand(roSearchObject);

        verify(searchRoEntityToEventMapper)
                .mapEntityToEvent(eq(roSearchObject), fetchedListCaptor.capture(), eq(0L));
        final List<RecognisingOrganisation> actualList = fetchedListCaptor.getValue();
        assertEquals(0, actualList.size());
    }

    @ParameterizedTest
    @MethodSource("provideArgumentsForSearchIntegrationTest")
    void whenInvalidToken_SearchROVO_ExpectDataFetched(
            final RoSearchObject roSearchObject,
            final Page<RecognisingOrganisation> page,
            final RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1)
            throws RbacValidationException, IOException {

        ThreadLocalHeaderContext.getContext()
                .setXaccessToken(
                        OrganisationTestUtil.getAccessToken("test-admin-support-access-token"));

        Executable executable = () -> searchOrganisationDomainService.onCommand(roSearchObject);

        ValidationException exception = assertThrows(ValidationException.class, executable);
        assertEquals(
                OrganisationConstants.ErrorResponse.CANNOT_PERFORM_SEARCH, exception.getMessage());

        verify(searchRoEntityToEventMapper, never())
                .mapEntityToEvent(
                        eq(roSearchObject), fetchedListCaptor.capture(), eq(page.getTotalElements()));
    }

    private static Stream<Arguments> provideArgumentsForSearchIntegrationTest() {

        final RoSearchObject roSearchObject = SearchOrganisationDataSetup.getRoSearchData();
        roSearchObject.getCriteria().setOrganisationTypeUuid(null);

        List<RecognisingOrganisation> list = new ArrayList<>();
        list.add(new RecognisingOrganisation());

        Page<RecognisingOrganisation> page = new PageImpl<>(list);

        RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1 =
                new RosSearchResultsGeneratedEventV1();
        rosSearchResultsGeneratedEventV1.setSearch(
                new com.ielts.cmds.organisation.common.out.event.RoSearchV1());
        return Stream.of(Arguments.of(roSearchObject, page, rosSearchResultsGeneratedEventV1));
    }
}
