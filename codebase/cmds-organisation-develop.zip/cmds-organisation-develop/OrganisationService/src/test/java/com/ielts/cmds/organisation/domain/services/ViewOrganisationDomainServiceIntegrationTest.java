package com.ielts.cmds.organisation.domain.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.cache.JedisGenericReader;
import com.ielts.cmds.organisation.cache.factory.JedisFactory;
import com.ielts.cmds.organisation.common.out.event.RoRequestedEventV1;
import com.ielts.cmds.organisation.domain.commands.CreateROVO;
import com.ielts.cmds.organisation.domain.commands.ViewROVO;
import com.ielts.cmds.organisation.domain.model.RoDataCreateV1Valid;
import com.ielts.cmds.organisation.infrastructure.config.RBACTestConfig;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.utills.CreateOrganisationDataSetup;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.implementation.impl.LocationHierarchyServiceImpl;
import com.ielts.cmds.rbac.implementation.impl.UserGroupServiceImpl;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

import javax.transaction.Transactional;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Stream;

import static org.junit.Assert.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = RBACTestConfig.class)
@ActiveProfiles("test")
@Sql({
    "/sql/schema.sql",
    "/sql/organisation-type-data.sql",
    "/sql/partner-data.sql",
    "/sql/address-type-data.sql",
    "/sql/sector-type-data.sql",
    "/sql/product-data.sql",
    "/sql/note-type-data.sql",
    "/sql/contact-type-data.sql",
    "/sql/country-data.sql",
    "/sql/territory-data.sql",
    "/sql/module-type-data.sql",
    "/sql/ro-data-for-search.sql",
    "/sql/RO-data.sql",
    "/sql/usergroup-hierarchy.sql",
})
@Transactional
class ViewOrganisationDomainServiceIntegrationTest {

    @Autowired private CMDSThreadLocalContextService cmdsThreadLocalContextService;

    @Autowired private RecognisingOrganisationRepository recognisingOrgRepository;

    @MockBean private ApplicationEventPublisher applicationEventPublisher;

    @Autowired private ViewOrganisationDomainService viewOrganisationDomainService; 

    @Captor ArgumentCaptor<BaseEvent<BaseHeader>> publishedEventCaptor;

    @Captor ArgumentCaptor<RecognisingOrganisation> recognisingOrganisationArgumentCaptor;

    @Autowired private UserGroupServiceImpl userGroupServiceImpl;

    @Autowired private LocationHierarchyServiceImpl locationHierarchyServiceImpl;

    @Autowired private OrganisationCommonUtils organisationCommonUtils;

    @MockBean private JedisGenericReader jedisGenericReader;

    @MockBean private JedisFactory jedisFactory;


    @BeforeEach
    void setup() throws RbacValidationException {
        MockitoAnnotations.initMocks(this);
        userGroupServiceImpl.populateUserGroupHierarchyData();
        locationHierarchyServiceImpl.populateRootData();
        ReflectionTestUtils.setField(
                viewOrganisationDomainService,
                "applicationEventPublisher",
                applicationEventPublisher);
        ReflectionTestUtils.setField(viewOrganisationDomainService, "organisationCommonUtils", organisationCommonUtils);

        CMDSHeaderContext header = OrganisationTestUtil
                .generateBuildHeaderContext(OrganisationConstants.EventType.RO_VIEW_DETAILS_EVENT);
        Map<String, String> eventContextList = new HashMap<>();
        eventContextList.put("recognisingOrganisationUuid", "eeb87d1e-3d5b-4375-8edf-55e66c86b1de");
        header.setEventContext(eventContextList);
        ThreadLocalHeaderContext.setContext(header);
        ThreadLocalAuditContext.setContext(OrganisationTestUtil.getBaseAudit());
        ReflectionTestUtils.setField(
                organisationCommonUtils, "jedisGenericReader", jedisGenericReader);

    }

    @MethodSource("provideArgumentsForViewOrgCommand")
    @ParameterizedTest
    void whenValidToken_ViewRo_ExpectEvent(
            final RecognisingOrganisation recognisingOrganisation)
            throws IOException, RbacValidationException, JSONException {

        String authorisedAccessToken =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessToken);
        viewOrganisationDomainService.onCommand("eeb87d1e-3d5b-4375-8edf-55e66c86b1de");
        Optional<RecognisingOrganisation> roDataFromDb =
                recognisingOrgRepository.findById(
                        recognisingOrganisation.getRecognisingOrganisationUuid());

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();

        RoRequestedEventV1 roChangedEventV1 =
                new ObjectMapper().readValue(event.getEventBody(), RoRequestedEventV1.class);

        assertEquals(
                OrganisationConstants.EventType.RO_VIEW_DETAILS_EVENT,
                event.getEventHeader().getEventName());
        assertTrue(roDataFromDb.isPresent());
        assertEquals(roDataFromDb.get().getOrganisationId(), roChangedEventV1.getOrganisationId());
        assertEquals(
                roDataFromDb.get().getOrganisationCode(), roChangedEventV1.getOrganisationCode());
        assertEquals(roDataFromDb.get().getName(), roChangedEventV1.getOrganisationName());
        assertEquals(roDataFromDb.get().getOrgStatus(), roChangedEventV1.getOrganisationStatus());
        assertEquals(
                roDataFromDb.get().getOrganisationTypeUuid(),
                roChangedEventV1.getOrganisationTypeUuid());
    
    }
    @MethodSource("provideArgumentsForViewFlagsOrgCommand")
    @ParameterizedTest
    void TestCase_for_Accepts_SSR_and_Accepts_IOL (final RoDataCreateV1Valid roDataCreateV1,
    		final RecognisingOrganisation recognisingOrganisation )
    		throws IOException, RbacValidationException, JSONException {
    	String authorisedAccessToken =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessToken);
        viewOrganisationDomainService.onCommand("eeb87d1e-3d5b-4375-8edf-55e66c86b1de");
        
        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();

        RoRequestedEventV1 roRequestedEventV1 =
                new ObjectMapper().readValue(event.getEventBody(), RoRequestedEventV1.class);
        assertEquals(roDataCreateV1.getAcceptsIOL(), roRequestedEventV1.getAcceptsIOL());
        assertEquals(roDataCreateV1.getAcceptsSSR(), roRequestedEventV1.getAcceptsSSR());

    }
    
    @Test
    void whenNoProductsAssigned_thenVerifyFlagsAreFalse ()
    		throws IOException, RbacValidationException, JSONException {
    	String authorisedAccessToken =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessToken);

        viewOrganisationDomainService.onCommand("eeb87d1e-3d5b-4375-8edf-55e66c86b1de");
        Optional<RecognisingOrganisation> roDataFromDb =
                recognisingOrgRepository.findById(UUID.fromString("eeb87d1e-3d5b-4375-8edf-55e66c86b1de"));
        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> publishedevent = publishedEventCaptor.getValue();

        RoRequestedEventV1 roRequestedEventV1 =
                new ObjectMapper().readValue(publishedevent.getEventBody(), RoRequestedEventV1.class);
        assertEquals(0, roDataFromDb.get().getRecognisedProducts().size());
        assertFalse(roRequestedEventV1.getAcceptsIOL());
        assertFalse(roRequestedEventV1.getAcceptsSSR());
    }
    
    @Test
    void whenAtleastOneProductOfIOLandOSRIsAssigned_thenVerifyFlagsAreTrue ()
    		throws IOException, RbacValidationException, JSONException {
    	String authorisedAccessToken =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        CMDSHeaderContext header = OrganisationTestUtil
                .generateBuildHeaderContext(OrganisationConstants.EventType.RO_VIEW_DETAILS_EVENT);
        Map<String, String> eventContextList = new HashMap<>();
        eventContextList.put("recognisingOrganisationUuid", "7b684c61-6d72-4dbd-95ee-85879bc1ec16");
        header.setEventContext(eventContextList);
        ThreadLocalHeaderContext.setContext(header);

        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessToken);
        viewOrganisationDomainService.onCommand("7b684c61-6d72-4dbd-95ee-85879bc1ec16");
        Optional<RecognisingOrganisation> roDataFromDb =
                recognisingOrgRepository.findById(UUID.fromString("7b684c61-6d72-4dbd-95ee-85879bc1ec16"));
        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> publishedevent = publishedEventCaptor.getValue();

        RoRequestedEventV1 roRequestedEventV1 =
                new ObjectMapper().readValue(publishedevent.getEventBody(), RoRequestedEventV1.class);
        assertEquals(2, roDataFromDb.get().getRecognisedProducts().size()); // One IOL and one OSR product assigned to this RO
        assertFalse(roRequestedEventV1.getAcceptsIOL());
        assertFalse(roRequestedEventV1.getAcceptsSSR());
    }

	@MethodSource("provideArgumentsForViewOrgCommandReject")
    @ParameterizedTest
    void whenRecordNotFound_ViewRo_ExpectRejectEvent()
            throws IOException, RbacValidationException, JSONException {

        String authorisedAccessToken =
                OrganisationTestUtil.getAccessToken("ops-manager-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessToken);
        Map<String, String> eventContextList = new HashMap<>();
        eventContextList.put("recognisingOrganisationUuid", "7fd4dad6-547c-446b-afe3-d7a6110120c8");
        ThreadLocalHeaderContext.getContext().setEventContext(eventContextList);

        CMDSErrorResponse expectedErrorResponse =
                OrganisationTestUtil.getROErrorResponse(
                        "V0043",
                        "OrganisationNotFound",
                        OrganisationConstants.EventType.RO_VIEW_DETAILS_REJECTED_EVENT);
        viewOrganisationDomainService.onCommand("7fd4dad6-547c-446b-afe3-d7a6110120c8");

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();

        assertEquals(
                expectedErrorResponse.getErrorList().size(),
                event.getEventErrors().getErrorList().size());
        assertEquals(
                expectedErrorResponse.getErrorList().get(0).getErrorCode(),
                event.getEventErrors().getErrorList().get(0).getErrorCode());
        assertEquals(
                OrganisationConstants.EventType.RO_VIEW_DETAILS_REJECTED_EVENT,
                event.getEventHeader().getEventName());
    }

    @MethodSource("provideArgumentsForViewOrgCommand")
    @ParameterizedTest
    void whenInvalidToken_ViewRo_ExpectRejectEvent(
            final RecognisingOrganisation recognisingOrganisation)
            throws IOException, RbacValidationException, JSONException {

        String unAuthorisedAccessToken =
                OrganisationTestUtil.getAccessToken("test-admin-support-access-token");
        ThreadLocalHeaderContext.getContext().setXaccessToken(unAuthorisedAccessToken);
        CMDSErrorResponse expectedErrorResponse =
                OrganisationTestUtil.getROErrorResponse(
                        "V0044",
                        "UnauthorisedToViewOrganisation",
                        OrganisationConstants.EventType.RO_VIEW_DETAILS_REJECTED_EVENT);
        viewOrganisationDomainService.onCommand("eeb87d1e-3d5b-4375-8edf-55e66c86b1de");

        verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
        BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();

        assertEquals(
                expectedErrorResponse.getErrorList().size(),
                event.getEventErrors().getErrorList().size());
        assertEquals(
                expectedErrorResponse.getErrorList().get(0).getErrorCode(),
                event.getEventErrors().getErrorList().get(0).getErrorCode());
        assertEquals(
                OrganisationConstants.EventType.RO_VIEW_DETAILS_REJECTED_EVENT,
                event.getEventHeader().getEventName());
    }
    
    private static Stream<Arguments> provideArgumentsForViewFlagsOrgCommand()
            throws JsonProcessingException {

        final RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        roDataCreateV1.setAcceptsIOL(false);
        UiHeader roHeaders = OrganisationTestUtil.generateEventHeader();
        BaseAudit audit = new BaseAudit();
        Map<String, String> auditContext = new HashMap<>();
        audit.setAuditContext(auditContext);
        BaseEvent<BaseHeader> event = new BaseEvent<>(roHeaders, null, null, null);
        ViewROVO viewRo =
                ViewROVO.builder()
                        .eventHeaders(event.getEventHeader())
                        .eventBody(event.getEventBody())
                        .eventErrors(event.getEventErrors())
                        .audit(audit)
                        .build();

        CreateROVO createRo =
                CreateROVO.builder()
                        .eventHeaders(event.getEventHeader())
                        .eventBody(roDataCreateV1)
                        .eventErrors(event.getEventErrors())
                        .build();

        RecognisingOrganisation recognisingOrganisation =
                CreateOrganisationDataSetup.populateOrganisation(
                        createRo.getEventBody(), new RecognisingOrganisation());
      Map<String, String> eventContextList = new HashMap<>();
        eventContextList.put("recognisingOrganisationUuid", "eeb87d1e-3d5b-4375-8edf-55e66c86b1de");
        BaseHeader roHeader = viewRo.getEventHeaders();
        roHeader.setEventName(OrganisationConstants.EventType.RO_VIEW_DETAILS_EVENT);
        roHeader.setEventDateTime(LocalDateTime.now());
        roHeader.setEventDiscriminator("RO-UI");
        roHeader.setEventContext(eventContextList);
        

        return Stream.of(Arguments.of(roDataCreateV1,recognisingOrganisation));
    }


    private static Stream<Arguments> provideArgumentsForViewOrgCommand() {

        final RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        UiHeader roHeaders = OrganisationTestUtil.generateEventHeader();
        BaseAudit audit = new BaseAudit();
        Map<String, String> auditContext = new HashMap<>();
        audit.setAuditContext(auditContext);
        BaseEvent<BaseHeader> event = new BaseEvent<>(roHeaders, null, null, null);
        ViewROVO viewRo =
                ViewROVO.builder()
                        .eventHeaders(event.getEventHeader())
                        .eventBody(event.getEventBody())
                        .eventErrors(event.getEventErrors())
                        .audit(audit)
                        .build();

        CreateROVO createRo =
                CreateROVO.builder()
                        .eventHeaders(event.getEventHeader())
                        .eventBody(roDataCreateV1)
                        .eventErrors(event.getEventErrors())
                        .build();

        RecognisingOrganisation recognisingOrganisation =
                CreateOrganisationDataSetup.populateOrganisation(
                        createRo.getEventBody(), new RecognisingOrganisation());
        recognisingOrganisation.setRecognisingOrganisationUuid(
                UUID.fromString("eeb87d1e-3d5b-4375-8edf-55e66c86b1de"));
        RoRequestedEventV1 roChangedEvent =
                CreateOrganisationDataSetup.entityToEventMapperForView(recognisingOrganisation);
        Map<String, String> eventContextList = new HashMap<>();
        eventContextList.put("recognisingOrganisationUuid", "eeb87d1e-3d5b-4375-8edf-55e66c86b1de");
        BaseHeader roHeader = viewRo.getEventHeaders();
        roHeader.setEventName(OrganisationConstants.EventType.RO_VIEW_DETAILS_EVENT);
        roHeader.setEventDateTime(LocalDateTime.now());
        roHeader.setEventDiscriminator("RO-UI");
        roHeader.setEventContext(eventContextList);

        return Stream.of(Arguments.of(recognisingOrganisation, roChangedEvent));
    }

    private static Stream<Arguments> provideArgumentsForViewOrgCommandReject() {

        UiHeader roHeaders = OrganisationTestUtil.generateEventHeader();
        BaseAudit audit = new BaseAudit();
        Map<String, String> auditContext = new HashMap<>();
        audit.setAuditContext(auditContext);
        BaseEvent<BaseHeader> event = new BaseEvent<>(roHeaders, null, null, null);
        ViewROVO viewRo =
                ViewROVO.builder()
                        .eventHeaders(event.getEventHeader())
                        .eventBody(event.getEventBody())
                        .eventErrors(event.getEventErrors())
                        .audit(audit)
                        .build();
        Map<String, String> eventContextList = new HashMap<>();
        eventContextList.put("recognisingOrganisationUuid", "7fd4dad6-547c-446b-afe3-d7a6110120c8");
        BaseHeader roHeader = viewRo.getEventHeaders();
        roHeader.setEventName(OrganisationConstants.EventType.RO_VIEW_DETAILS_EVENT);
        roHeader.setEventDateTime(LocalDateTime.now());
        roHeader.setEventDiscriminator("RO-UI");
        roHeader.setEventContext(eventContextList);

        return Stream.of(Arguments.of(viewRo));
    }
}
