package com.ielts.cmds.organisation.utills;

import com.ielts.cmds.organisation.common.enums.MethodOfDeliveryEnum;
import com.ielts.cmds.organisation.common.enums.VerificationStatusEnum;
import com.ielts.cmds.organisation.domain.model.LoadRODataV1;
import java.util.ArrayList;
import java.util.List;

public class LoadVODataSetup {

    public static List<LoadRODataV1> getLoadVODataV1List() {
        List<LoadRODataV1> loadVODataV1List = new ArrayList<>();
        LoadRODataV1 loadVODataV1 = new LoadRODataV1();
        loadVODataV1.setName("McGill University");
        loadVODataV1.setSectorType("College / University");
        loadVODataV1.setVerificationStatus(VerificationStatusEnum.APPROVED.getValue());
        loadVODataV1.setAddressLine1("22 Heathfield Gardens");
        loadVODataV1.setAddressLine2("string");
        loadVODataV1.setAddressLine3("string");
        loadVODataV1.setAddressLine4("string");
        loadVODataV1.setCity("Cambridge");
        loadVODataV1.setTerritoryIso3Code("");
        loadVODataV1.setCountryIso3Code("");
        loadVODataV1.setPostalCode("CB2 8EA");
        loadVODataV1.setTelephoneNo("+1 234 234 3456");
        loadVODataV1.setPartnerCode("IDP");
        loadVODataV1.setMethodOfDelivery(MethodOfDeliveryEnum.POSTAL.getValue());
        loadVODataV1.setTitle("Ms");
        loadVODataV1.setFirstName("results admin");
        loadVODataV1.setLastName("name");
        loadVODataV1.setJobTitle("Chief Suport Manager");
        loadVODataV1.setWebsiteUrl("www.officialxyz.com");
        loadVODataV1.setCrmSystem("CRM Value");
        loadVODataV1.setOrganisationId("12345");
        loadVODataV1.setRecognisedProduct("IOL");
        loadVODataV1.setAcMinimumScoreValue("4.5");
        loadVODataV1.setAcListeningMinimumScoreValue("4.5");
        loadVODataV1.setAcWritingMinimumScoreValue("4.5");
        loadVODataV1.setAcReadingMinimumScoreValue("4.5");
        loadVODataV1.setAcSpeakingMinimumScoreValue("4.5");
        loadVODataV1.setGtMinimumScoreValue("4");
        loadVODataV1.setGtWritingMinimumScoreValue("4");
        loadVODataV1.setGtListeningMinimumScoreValue("4");
        loadVODataV1.setGtReadingMinimumScoreValue("4");
        loadVODataV1.setGtSpeakingMinimumScoreValue("4");
        loadVODataV1.setAlternateName1("University Of McGill");
        loadVODataV1.setAlternateName2("University Of McGill");
        loadVODataV1.setAlternateName3("University Of McGill");
        loadVODataV1.setVisibleOnIelts("true");
        loadVODataV1.setSelectableOnOrs("true");
        loadVODataV1List.add(loadVODataV1);
        return loadVODataV1List;
    }

    public static List<LoadRODataV1> getLoadVODataList() {
        List<LoadRODataV1> loadVODataV1List = new ArrayList<>();
        LoadRODataV1 loadVODataV1 = new LoadRODataV1();
        loadVODataV1.setName("McGill University");
        loadVODataV1.setSectorType("College / University");
        loadVODataV1.setVerificationStatus(VerificationStatusEnum.APPROVED.getValue());
        loadVODataV1.setAddressLine1("22 Heathfield Gardens");
        loadVODataV1.setCity("Cambridge");
        loadVODataV1.setCountryIso3Code("");
        loadVODataV1.setPartnerCode("IDP");
        loadVODataV1.setMethodOfDelivery(MethodOfDeliveryEnum.POSTAL.getValue());
        loadVODataV1.setOrganisationId("12345");
        loadVODataV1.setRecognisedProduct("NULL");
        loadVODataV1.setAcMinimumScoreValue("NULL");
        loadVODataV1.setAcListeningMinimumScoreValue("NULL");
        loadVODataV1.setAcWritingMinimumScoreValue("NULL");
        loadVODataV1.setAcReadingMinimumScoreValue("NULL");
        loadVODataV1.setAcSpeakingMinimumScoreValue("NULL");
        loadVODataV1.setGtMinimumScoreValue("NULL");
        loadVODataV1.setGtWritingMinimumScoreValue("NULL");
        loadVODataV1.setGtListeningMinimumScoreValue("NULL");
        loadVODataV1.setGtReadingMinimumScoreValue("NULL");
        loadVODataV1.setGtSpeakingMinimumScoreValue("NULL");
        loadVODataV1.setAlternateName1("University Of McGill");
        loadVODataV1.setAlternateName2("NULL");
        loadVODataV1.setAlternateName3("NULL");
        loadVODataV1.setVisibleOnIelts(" TRUE");
        loadVODataV1.setSelectableOnOrs("false");
        loadVODataV1List.add(loadVODataV1);
        return loadVODataV1List;
    }
}
