package com.ielts.cmds.organisation.domain.services;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.roui010rohierarchyrequested.ROHierarchyRequestParam;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.cache.JedisGenericReader;
import com.ielts.cmds.organisation.cache.factory.JedisFactory;
import com.ielts.cmds.organisation.common.out.event.RoDetailsDataGeneratedEventV1;
import com.ielts.cmds.organisation.infrastructure.config.RBACTestConfig;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.LinkedRecognisingOrganisationRepository;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.implementation.impl.LocationHierarchyServiceImpl;
import com.ielts.cmds.rbac.implementation.impl.UserGroupServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

import javax.transaction.Transactional;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = RBACTestConfig.class)
@ActiveProfiles("test")
@Sql({
  "/sql/schema.sql",
  "/sql/organisation-type-data.sql",
  "/sql/partner-data.sql",
  "/sql/address-type-data.sql",
  "/sql/sector-type-data.sql",
  "/sql/product-data.sql",
  "/sql/note-type-data.sql",
  "/sql/contact-type-data.sql",
  "/sql/country-data.sql",
  "/sql/territory-data.sql",
  "/sql/module-type-data.sql",
  "/sql/ro-data-for-search.sql",
  "/sql/usergroup-hierarchy.sql",
  "/sql/ro-hierarchy-data.sql",
  "/sql/sample-hierarchy-data.sql",
  "/sql/linked-recognising-organisation-data.sql"
})
@Transactional
class SearchForHierarchyDomainServiceIntegrationTest {

  @Autowired private RecognisingOrganisationRepository recognisingOrgRepository;

  @MockBean private ApplicationEventPublisher applicationEventPublisher;

  @Spy private OrganisationCommonUtils orgUtils;

  @Autowired private OrganisationCommonUtils organisationCommonUtils;

  @Autowired private SearchForHierarchyDomainService searchForHierarchyDomainService;

  @Captor ArgumentCaptor<BaseEvent<BaseHeader>> publishedEventCaptor;

  @Captor ArgumentCaptor<RecognisingOrganisation> recognisingOrganisationArgumentCaptor;

  @Autowired private UserGroupServiceImpl userGroupServiceImpl;

  @Autowired private LocationHierarchyServiceImpl locationHierarchyServiceImpl;

  @Autowired private LinkedRecognisingOrganisationRepository linkedRecognisingOrgRepository;

  @MockBean private JedisGenericReader jedisGenericReader;

  @MockBean private JedisFactory jedisFactory;

  @BeforeEach
  void setup() throws RbacValidationException {
    userGroupServiceImpl.populateUserGroupHierarchyData();
    locationHierarchyServiceImpl.populateRootData();
    ReflectionTestUtils.setField(
        searchForHierarchyDomainService, "applicationEventPublisher", applicationEventPublisher);
    ReflectionTestUtils.setField(
        organisationCommonUtils,
        "linkedRecognisingOrganisationRepository",
        linkedRecognisingOrgRepository);
    ReflectionTestUtils.setField(
        organisationCommonUtils, "orgRepository", recognisingOrgRepository);
    ReflectionTestUtils.setField(
        organisationCommonUtils, "applicationEventPublisher", applicationEventPublisher);

    CMDSHeaderContext header =
        OrganisationTestUtil.generateBuildHeaderContext(
            OrganisationConstants.GenericConstants.RO_HIERARCHY_SEARCH_REQUEST_EVENT);
    Map<String, String> eventContextList = new HashMap<>();
    eventContextList.put("recognisingOrganisationUuid", "eeb87d1e-3d5b-4375-8edf-55e66c86b1de");
    header.setEventContext(eventContextList);
    ThreadLocalHeaderContext.setContext(header);
    ThreadLocalAuditContext.setContext(OrganisationTestUtil.getBaseAudit());
    ReflectionTestUtils.setField(
            organisationCommonUtils, "jedisGenericReader", jedisGenericReader);
  }

  @Test
  void whenValidToken_SearchByOrgId_ForOrgWithNoHierarchy_ThenExpectEvent() throws IOException {

    String authorisedAccessToken = OrganisationTestUtil.getAccessToken("ops-manager-access-token");
    ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessToken);
    ROHierarchyRequestParam eventBody = new ROHierarchyRequestParam();
    eventBody.setRecognisingOrganisationUuid(UUID.fromString("eeb87d1e-3d5b-4375-8edf-55e66c86b1de"));
    eventBody.setOnlyImmediateChildren(Boolean.FALSE);
    searchForHierarchyDomainService.onCommand(eventBody);
    Set<RecognisingOrganisation> roDataFromDb =
        organisationCommonUtils.getHierarchyBasedOnRecognisingOrganisationUuid(
            UUID.fromString("eeb87d1e-3d5b-4375-8edf-55e66c86b1de"));

    verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
    BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();

    RoDetailsDataGeneratedEventV1 roDetailsDataGeneratedEventV1 =
        new ObjectMapper().readValue(event.getEventBody(), RoDetailsDataGeneratedEventV1.class);

    assertEquals(
        OrganisationConstants.EventType.RO_DETAILS_DATA_GENERATED_EVENT,
        event.getEventHeader().getEventName());
    assertTrue(!roDataFromDb.isEmpty());
    assertEquals(roDataFromDb.stream().count(), roDetailsDataGeneratedEventV1.stream().count());
  }

  @Test
  void whenRecordNotFound_SearchOrgByOrgId_ExpectEmptyListEvent() throws IOException {

    String authorisedAccessToken = OrganisationTestUtil.getAccessToken("ops-manager-access-token");
    ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessToken);
    ROHierarchyRequestParam eventBody = new ROHierarchyRequestParam();
    eventBody.setRecognisingOrganisationUuid(UUID.fromString("eeb87d1e-3d5b-4375-8edf-55e66c86b1de"));
    eventBody.setOnlyImmediateChildren(Boolean.FALSE);
    doReturn(null)
        .when(orgUtils)
        .getHierarchyBasedOnRecognisingOrganisationUuid(
            (eventBody.getRecognisingOrganisationUuid()));
    searchForHierarchyDomainService.onCommand(eventBody);

    verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
    BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();

    assertEquals(
        OrganisationConstants.EventType.RO_DETAILS_DATA_GENERATED_EVENT,
        event.getEventHeader().getEventName());
  }

  @Test
  void whenInvalidToken_SearchForHierarchy_ExpectRejectEvent() throws IOException {

    String unAuthorisedAccessToken =
        OrganisationTestUtil.getAccessToken("test-admin-support-access-token");
    ThreadLocalHeaderContext.getContext().setXaccessToken(unAuthorisedAccessToken);
    ROHierarchyRequestParam eventBody = new ROHierarchyRequestParam();
    eventBody.setRecognisingOrganisationUuid(UUID.fromString("eeb87d1e-3d5b-4375-8edf-55e66c86b1de"));
    CMDSErrorResponse expectedErrorResponse =
        OrganisationTestUtil.getROErrorResponse(
            "V0044",
            "UnauthorisedToViewOrganisation",
            OrganisationConstants.EventType.RO_VIEW_DETAILS_REJECTED_EVENT);

    searchForHierarchyDomainService.onCommand(eventBody);

    verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
    BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();

    assertEquals(
        expectedErrorResponse.getErrorList().size(), event.getEventErrors().getErrorList().size());
    assertEquals(
        expectedErrorResponse.getErrorList().get(0).getErrorCode(),
        event.getEventErrors().getErrorList().get(0).getErrorCode());
    assertEquals(
        OrganisationConstants.EventType.RO_VIEW_DETAILS_REJECTED_EVENT,
        event.getEventHeader().getEventName());
  }

  @Test
  void whenValidToken_SearchForHierarchy_WithRootNodeUuid_ThenExpectEvent() throws IOException {
    String authorisedAccessToken = OrganisationTestUtil.getAccessToken("ops-manager-access-token");
    ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessToken);

    ROHierarchyRequestParam eventBody = new ROHierarchyRequestParam();
    eventBody.setRecognisingOrganisationUuid(UUID.fromString("eeb87d1e-3d5b-4375-8edf-55e66c86b1de"));
    eventBody.setOnlyImmediateChildren(Boolean.FALSE);
    searchForHierarchyDomainService.onCommand(eventBody);
    Set<RecognisingOrganisation> roDataFromDb =
        organisationCommonUtils.getChildHierarchyBasedOnRO(
            UUID.fromString("8ad1b27b-2abd-48f7-af77-04b0efbde786"), Boolean.FALSE);

    verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
    BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();

    RoDetailsDataGeneratedEventV1 roDetailsDataGeneratedEventV1 =
        new ObjectMapper().readValue(event.getEventBody(), RoDetailsDataGeneratedEventV1.class);

    assertEquals(
        OrganisationConstants.EventType.RO_DETAILS_DATA_GENERATED_EVENT,
        event.getEventHeader().getEventName());
    assertEquals(roDataFromDb.size(), roDetailsDataGeneratedEventV1.size());
  }

  @Test
  void whenValidToken_SearchForHierarchy_WithROUuidAndParentROUuid_ThenExpectSucessEvent()
      throws IOException {
    String authorisedAccessToken = OrganisationTestUtil.getAccessToken("ops-manager-access-token");
    ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessToken);

    ROHierarchyRequestParam eventBody = new ROHierarchyRequestParam();
    eventBody.setRecognisingOrganisationUuid(UUID.fromString("aecf88e3-a88e-467a-b966-ab4ac939de55"));
    eventBody.setParentROUuid(UUID.fromString("eeb87d1e-3d5b-4375-8edf-55e66c86b1de"));
    eventBody.setOnlyImmediateChildren(Boolean.FALSE);
    searchForHierarchyDomainService.onCommand(eventBody);

    verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
    BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();

    RoDetailsDataGeneratedEventV1 roDetailsDataGeneratedEventV1 =
        new ObjectMapper().readValue(event.getEventBody(), RoDetailsDataGeneratedEventV1.class);

    assertEquals(
        OrganisationConstants.EventType.RO_DETAILS_DATA_GENERATED_EVENT,
        event.getEventHeader().getEventName());
    assertEquals(5, roDetailsDataGeneratedEventV1.size());
  }

  @Test
  void whenValidToken_SearchForHierarchy_WithROUuidAndParentROUuid_AtLeastOneVERIFIEDStatus_ThenExpectSucessEvent()
      throws IOException {
    String authorisedAccessToken = OrganisationTestUtil.getAccessToken("ops-manager-access-token");
    ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessToken);

    ROHierarchyRequestParam eventBody = new ROHierarchyRequestParam();
    eventBody.setRecognisingOrganisationUuid(UUID.fromString("49ad3e10-6201-4ad1-b15f-43d3d62beae7"));
    eventBody.setParentROUuid(UUID.fromString("eeb87d1e-3d5b-4375-8edf-55e66c86b1de"));
    eventBody.setOnlyImmediateChildren(Boolean.FALSE);
    searchForHierarchyDomainService.onCommand(eventBody);

    verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
    BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();

    RoDetailsDataGeneratedEventV1 roDetailsDataGeneratedEventV1 =
        new ObjectMapper().readValue(event.getEventBody(), RoDetailsDataGeneratedEventV1.class);

    assertEquals(
        OrganisationConstants.EventType.RO_DETAILS_DATA_GENERATED_EVENT,
        event.getEventHeader().getEventName());
    assertEquals(4, roDetailsDataGeneratedEventV1.size());
  }

  @Test
  void
      whenValidToken_SearchForHierarchy_WithRecognisingOrganisationUuid_ThenExpectItsImmediateChildren()
          throws IOException {
    String authorisedAccessToken = OrganisationTestUtil.getAccessToken("ops-manager-access-token");
    ThreadLocalHeaderContext.getContext().setXaccessToken(authorisedAccessToken);


    ROHierarchyRequestParam eventBody = new ROHierarchyRequestParam();
    eventBody.setRecognisingOrganisationUuid(UUID.fromString("5c2e3965-8b90-488f-b5e9-4da8854785cb"));
    eventBody.setOnlyImmediateChildren(Boolean.TRUE);
    searchForHierarchyDomainService.onCommand(eventBody);
    Set<RecognisingOrganisation> roDataFromDb =
        organisationCommonUtils.getChildHierarchyBasedOnRO(
            UUID.fromString("5c2e3965-8b90-488f-b5e9-4da8854785cb"), Boolean.TRUE);

    verify(applicationEventPublisher).publishEvent(publishedEventCaptor.capture());
    BaseEvent<BaseHeader> event = publishedEventCaptor.getValue();

    RoDetailsDataGeneratedEventV1 roDetailsDataGeneratedEventV1 =
        new ObjectMapper().readValue(event.getEventBody(), RoDetailsDataGeneratedEventV1.class);

    assertEquals(
        OrganisationConstants.EventType.RO_DETAILS_DATA_GENERATED_EVENT,
        event.getEventHeader().getEventName());
    assertEquals(roDataFromDb.size(), roDetailsDataGeneratedEventV1.size());
  }
}
