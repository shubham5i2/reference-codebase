package com.ielts.cmds.organisation.domain.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.cache.JedisGenericReader;
import com.ielts.cmds.organisation.cache.entity.Product;
import com.ielts.cmds.organisation.common.out.event.RoRequestedEventV1;
import com.ielts.cmds.organisation.domain.commands.CreateROVO;
import com.ielts.cmds.organisation.domain.commands.ViewROVO;
import com.ielts.cmds.organisation.domain.model.RoDataCreateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.utills.CreateOrganisationDataSetup;
import com.ielts.cmds.organisation.utills.OrganisationTestUtil;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.outbox.event.OutboxEventBuilder;
import com.ielts.cmds.rbac.api.service.impl.RBACServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.util.ReflectionTestUtils;

import javax.validation.ConstraintViolation;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Stream;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ViewOrganisationDomainServiceTest {

    @InjectMocks @Spy
    private ViewOrganisationDomainService viewOrganisationDomainService;

    @Mock private ObjectMapper objectMapper;

    @Spy private OrganisationCommonUtils organisationCommonUtils;

    @Mock private ApplicationEventPublisher applicationEventPublisher;

    @Mock private RBACServiceImpl rbacServiceImpl;

    @Mock private CMDSErrorResolver<Object> errorResolver;

    @Captor private ArgumentCaptor<RecognisingOrganisation> recognisingOrgCapt;

    @Captor private ArgumentCaptor<BaseEvent<BaseHeader>> roRequestedEventCaptor;

    @Captor private ArgumentCaptor<BaseHeader> headerCaptor;

    @Captor private ArgumentCaptor<Set<ConstraintViolation<Object>>> violationSetCapt;

    @Mock private OutboxEventBuilder outboxEventBuilder;

    @Mock private JedisGenericReader jedisGenericReader;

    @BeforeEach
    void setup() {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(
                viewOrganisationDomainService, "rbacServiceImpl", rbacServiceImpl);
        ReflectionTestUtils.setField(viewOrganisationDomainService, "objectMapper", objectMapper);
        ReflectionTestUtils.setField(
                viewOrganisationDomainService, "organisationCommonUtils", organisationCommonUtils);
        ReflectionTestUtils.setField(
                viewOrganisationDomainService,
                "applicationEventPublisher",
                applicationEventPublisher);
        ReflectionTestUtils.setField(viewOrganisationDomainService, "errorResolver", errorResolver);
        ReflectionTestUtils.setField(
                viewOrganisationDomainService, "rbacServiceImpl", rbacServiceImpl);
        ReflectionTestUtils.setField(
            viewOrganisationDomainService, "outboxEventBuilder", outboxEventBuilder);
        ReflectionTestUtils.setField(
                organisationCommonUtils, "jedisGenericReader", jedisGenericReader);
    }
    @BeforeEach
    void init() {
        ThreadLocalHeaderContext.setContext(OrganisationTestUtil
                .generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_DETAILS_REQUEST_EVENT));

        ThreadLocalAuditContext.setContext(OrganisationTestUtil.getBaseAudit());

    }

    @DisplayName("Valid Command - Expect Event")
    @ParameterizedTest
    @MethodSource("provideArgumentsForViewOrgCommand")
    void whenReceivedValid_ViewOrgCommand_thenExpectEventToBePublished(
            final RecognisingOrganisation recognisingOrganisation)
            throws Exception {
        UiHeader header = organisationCommonUtils
                .buildUiHeader();
        BaseAudit audit = organisationCommonUtils.getBaseAudit();


        doReturn(true)
                .when(rbacServiceImpl)
                .isAuthorised(
                        header.getXaccessToken(),
                        OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION);
        doNothing()
                .when(viewOrganisationDomainService)
                .registerandPublishViewOrganisationEvent(
                        header, audit, recognisingOrganisation);

        doReturn(Optional.ofNullable(recognisingOrganisation))
                .when(organisationCommonUtils)
                .getOrganisationViewDetails("cef4fcb1-2bd2-51f3-889d-abd47d775634");

        Executable executable = () -> viewOrganisationDomainService.onCommand("cef4fcb1-2bd2-51f3-889d-abd47d775634");
        assertDoesNotThrow(executable);
        verify(viewOrganisationDomainService)
                .registerandPublishViewOrganisationEvent(
                        header, audit, recognisingOrganisation);
    }

    @DisplayName("Valid Command JsonProcessingException - Expect Exception")
    @ParameterizedTest
    @MethodSource("provideArgumentsForViewOrgCommand")
    void whenReceivedValid_ViewOrgCommand_JsonProcessingException_thenExpectException(
            final RecognisingOrganisation recognisingOrganisation)
            throws Exception {
        UiHeader header = organisationCommonUtils
                .buildUiHeader();
        BaseAudit audit = organisationCommonUtils.getBaseAudit();

        doReturn(true)
                .when(rbacServiceImpl)
                .isAuthorised(
                        header.getXaccessToken(),
                        OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION);

        doReturn(Optional.ofNullable(recognisingOrganisation))
                .when(organisationCommonUtils)
                .getOrganisationViewDetails("cef4fcb1-2bd2-51f3-889d-abd47d775634");

        doThrow(JsonProcessingException.class)
                .when(viewOrganisationDomainService)
                .registerandPublishViewOrganisationEvent(
                        header, audit, recognisingOrganisation);

        Executable executable = () -> viewOrganisationDomainService.onCommand("cef4fcb1-2bd2-51f3-889d-abd47d775634");
        assertThrows(JsonProcessingException.class, executable);
    }

    @DisplayName("Valid Command No Permission - Expect Reject Event")
    @ParameterizedTest
    @MethodSource("provideArgumentsForViewOrgCommand")
    void whenReceivedValid_ViewOrgCommand_thenExpectRejectEventToBePublished(
            final RecognisingOrganisation recognisingOrganisation)
            throws Exception {

        UiHeader header = organisationCommonUtils
                .buildUiHeader();
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put("recognisingOrganisationUuid", "cef4fcb1-2bd2-51f3-889d-abd47d775634");
        header.setEventContext(eventContext);
        BaseAudit audit = organisationCommonUtils.getBaseAudit();

        CMDSHeaderContext headerContext = OrganisationTestUtil
                .generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_DETAILS_REQUEST_EVENT);
        headerContext.setEventContext(eventContext);
        ThreadLocalHeaderContext.setContext(headerContext);

        doReturn(false)
                .when(rbacServiceImpl)
                .isAuthorised(
                        header.getXaccessToken(),
                        OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION);
        Set<ConstraintViolation<Object>> violationSet =
                OrganisationTestUtil.getSetforNullViolationOfEventBody(
                        "V0044", "UnauthorisedToViewOrganisation");
        doReturn(violationSet)
                .when(organisationCommonUtils)
                .getSetforNullViolationOfEventBody("V0044", "UnauthorisedToViewOrganisation");
        doNothing()
                .when(viewOrganisationDomainService)
                .generateRejectedEventResponse(
                        header,
                        audit,
                        violationSet,
                        recognisingOrganisation.getRecognisingOrganisationUuid().toString());
        Executable executable = () -> viewOrganisationDomainService.onCommand("cef4fcb1-2bd2-51f3-889d-abd47d775634");
        assertDoesNotThrow(executable);
        verify(organisationCommonUtils)
                .getSetforNullViolationOfEventBody("V0044", "UnauthorisedToViewOrganisation");
        verify(viewOrganisationDomainService)
                .generateRejectedEventResponse(
                        headerCaptor.capture(),
                        eq(audit),
                        violationSetCapt.capture(),
                        eq(recognisingOrganisation.getRecognisingOrganisationUuid().toString()));
        assertEquals(violationSet, violationSetCapt.getValue());
        verify(viewOrganisationDomainService, never())
                .registerandPublishViewOrganisationEvent(
                        header, audit, recognisingOrganisation);
    }

    @DisplayName("Valid Command OrganisationNotFound - Expect Reject Event")
    @ParameterizedTest
    @MethodSource("provideArgumentsForViewOrgCommand")
    void whenReceivedValid_ViewOrgCommand_thenExpectNotFoundRejectEventToBePublished(
            final RecognisingOrganisation recognisingOrganisation)
            throws Exception {
        BaseAudit audit = organisationCommonUtils.getBaseAudit();

        UiHeader header = organisationCommonUtils
                .buildUiHeader();
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put("recognisingOrganisationUuid", "cef4fcb1-2bd2-51f3-889d-abd47d775634");
        header.setEventContext(eventContext);

        CMDSHeaderContext headerContext = OrganisationTestUtil
                .generateBuildHeaderContext(OrganisationConstants.GenericConstants.RO_DETAILS_REQUEST_EVENT);
        headerContext.setEventContext(eventContext);
        ThreadLocalHeaderContext.setContext(headerContext);

        doReturn(true)
                .when(rbacServiceImpl)
                .isAuthorised(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION);
        doReturn(Optional.empty())
                .when(organisationCommonUtils)
                .getOrganisationViewDetails("cef4fcb1-2bd2-51f3-889d-abd47d775634");
        Set<ConstraintViolation<Object>> violationSet =
                OrganisationTestUtil.getSetforNullViolationOfEventBody(
                        "V0043", "OrganisationNotFound");
        doReturn(violationSet)
                .when(organisationCommonUtils)
                .getSetforNullViolationOfEventBody("V0043", "OrganisationNotFound");


        doNothing()
                .when(viewOrganisationDomainService)
                .generateRejectedEventResponse(
                        header,
                        audit,
                        violationSet,
                        recognisingOrganisation.getRecognisingOrganisationUuid().toString());
          Executable executable = () -> viewOrganisationDomainService.onCommand("cef4fcb1-2bd2-51f3-889d-abd47d775634");
        assertDoesNotThrow(executable);
        verify(organisationCommonUtils)
                .getSetforNullViolationOfEventBody("V0043", "OrganisationNotFound");
        verify(viewOrganisationDomainService)
                .generateRejectedEventResponse(
                        headerCaptor.capture(),
                        eq(audit),
                        violationSetCapt.capture(),
                        eq(recognisingOrganisation.getRecognisingOrganisationUuid().toString()));
        assertEquals(violationSet, violationSetCapt.getValue());
        verify(viewOrganisationDomainService, never())
                .registerandPublishViewOrganisationEvent(
                        header, audit, recognisingOrganisation);
    }

    @ParameterizedTest
    @MethodSource("provideArgumentsForViewOrgCommand")
    void when_PublishRejectEvent_thenExpectRejectEventToBePublished(
            final RecognisingOrganisation recognisingOrganisation)
            throws Exception {
        UiHeader header = organisationCommonUtils
                .buildUiHeader();
        BaseAudit audit = organisationCommonUtils.getBaseAudit();

        Set<ConstraintViolation<Object>> violationSet =
                OrganisationTestUtil.getSetforNullViolationOfEventBody(
                        "V0043", "OrganisationNotFound");
        CMDSErrorResponse cmdsErrorResponse =
                OrganisationTestUtil.getROErrorResponse(
                        "V0043",
                        "OrganisationNotFound",
                        OrganisationConstants.EventType.RO_VIEW_DETAILS_REJECTED_EVENT);

        doReturn(cmdsErrorResponse)
                .when(errorResolver)
                .populatErrorResponse(
                        violationSet,
                        OrganisationConstants.EventType.RO_VIEW_DETAILS_REJECTED_EVENT);

        viewOrganisationDomainService.generateRejectedEventResponse(
                header,
                audit,
                violationSet,
                recognisingOrganisation.getRecognisingOrganisationUuid().toString());
        verify(applicationEventPublisher).publishEvent(roRequestedEventCaptor.capture());
        assertNull(roRequestedEventCaptor.getValue().getEventBody());
        assertEquals(
                cmdsErrorResponse.getErrorList(),
                roRequestedEventCaptor.getValue().getEventErrors().getErrorList());
        assertEquals(
                OrganisationConstants.EventType.RO_VIEW_DETAILS_REJECTED_EVENT,
                roRequestedEventCaptor.getValue().getEventHeader().getEventName());
    }

    @ParameterizedTest
    @MethodSource("provideArgumentsForViewOrgCommand")
    void when_PublishRoRequestedEvent_thenExpectEventToBePublished(
            final RecognisingOrganisation recognisingOrganisation,
            final RoRequestedEventV1 roRequestedEventV1)
            throws Exception {
        UiHeader header = organisationCommonUtils
                .buildUiHeader();
        BaseAudit audit = organisationCommonUtils.getBaseAudit();

        String expectedEventBodyString = new ObjectMapper().writeValueAsString(roRequestedEventV1);
        doReturn(roRequestedEventV1)
                .when(viewOrganisationDomainService)
                .entityToEventMapper(recognisingOrganisation);
        doReturn(expectedEventBodyString).when(objectMapper).writeValueAsString(roRequestedEventV1);
        viewOrganisationDomainService.registerandPublishViewOrganisationEvent(
                header, audit, recognisingOrganisation);
        verify(applicationEventPublisher).publishEvent(roRequestedEventCaptor.capture());
        assertNull(roRequestedEventCaptor.getValue().getEventErrors());
        assertEquals(expectedEventBodyString, roRequestedEventCaptor.getValue().getEventBody());
        assertEquals(
                OrganisationConstants.EventType.RO_VIEW_DETAILS_EVENT,
                roRequestedEventCaptor.getValue().getEventHeader().getEventName());
    }
    
    @ParameterizedTest
    @MethodSource("provideArgumentsForViewOrgCommand")
    void whenProductsAreAssigned_verifyFlagValuesInEventPublished(
            final RecognisingOrganisation recognisingOrganisation,
            final RoRequestedEventV1 roRequestedEventV1) throws Exception {
        List<UUID> activeProductUuidList = new ArrayList<>();
        activeProductUuidList.add(UUID.fromString("3e81e94b-8b6a-42b5-970c-b141f9d195a3"));
        activeProductUuidList.add(UUID.fromString("cb7cd48c-5e79-4a28-8104-e0bcd8e39999"));
        List<Product> products = CreateOrganisationDataSetup.getproductDataWithCharacteristics();
        when(jedisGenericReader.retrieveAllBookableProductsDataFromRedisCache()).thenReturn(products);
        recognisingOrganisation.getRecognisedProducts().get(1).setProductUuid(UUID.fromString("cb7cd48c-5e79-4a28-8104-e0bcd8e39999"));
        viewOrganisationDomainService.acceptSSRAndAcceptIOLFlagMap(recognisingOrganisation.getRecognisedProducts(), roRequestedEventV1);
        assertTrue(roRequestedEventV1.getAcceptsIOL());
        assertTrue(roRequestedEventV1.getAcceptsSSR());
    }
    
    @Test
    void whenOnlyIOLProductIsAssigned_verifyFlagValuesInEventPublished() throws Exception {
    	Map<String, Boolean> acceptsSSRFlagMapandAcceptsIOL = new HashMap<>();
        acceptsSSRFlagMapandAcceptsIOL.put(OrganisationConstants.GenericConstants.IOL, Boolean.TRUE);
        acceptsSSRFlagMapandAcceptsIOL.put(OrganisationConstants.GenericConstants.SSR, Boolean.FALSE);
        acceptsSSRFlagMapandAcceptsIOL.put(OrganisationConstants.GenericConstants.AC, Boolean.FALSE);
        acceptsSSRFlagMapandAcceptsIOL.put(OrganisationConstants.GenericConstants.GT, Boolean.FALSE);
        Set<UUID> activeProductUuidList = new HashSet<>();
        activeProductUuidList.add(UUID.fromString("3e81e94b-8b6a-42b5-970c-b141f9d195a3"));
        organisationCommonUtils.getIOLSSRACGTFlagsBasedOnExistingActiveProductUuidList(activeProductUuidList, acceptsSSRFlagMapandAcceptsIOL);
        assertTrue(acceptsSSRFlagMapandAcceptsIOL.get(OrganisationConstants.GenericConstants.IOL));
        assertFalse(acceptsSSRFlagMapandAcceptsIOL.get(OrganisationConstants.GenericConstants.SSR));
    }

    @ParameterizedTest
    @MethodSource("provideArgumentsForViewOrgCommand")
    void whenACAndGtProductIsAssigned_verifyFlagValuesInEventPublished(
            final RecognisingOrganisation recognisingOrganisation,
            final RoRequestedEventV1 roRequestedEventV1) throws Exception {
        List<Product> products = CreateOrganisationDataSetup.getproductDataWithCharacteristics();
        when(jedisGenericReader.retrieveAllBookableProductsDataFromRedisCache()).thenReturn(products);
        recognisingOrganisation.getRecognisedProducts().get(0).setProductUuid(UUID.fromString("fdbacec5-e80a-4710-b3de-7d5f310b1466"));
        recognisingOrganisation.getRecognisedProducts().get(1).setProductUuid(UUID.fromString("cf9a05e9-2679-42da-b7d2-b34ea3e0724e"));
        recognisingOrganisation.getRecognisedProducts().get(2).setProductUuid(UUID.fromString("6d04f596-22f2-49c4-9d47-85b167b8ca6f"));
        recognisingOrganisation.getRecognisedProducts().get(3).setProductUuid(UUID.fromString("54b9d8df-c07a-4cb4-b397-adc4faa87c3f"));
        viewOrganisationDomainService.acceptSSRAndAcceptIOLFlagMap(recognisingOrganisation.getRecognisedProducts(), roRequestedEventV1);
        assertTrue(roRequestedEventV1.getAcceptsAC());
        assertTrue(roRequestedEventV1.getAcceptsGT());
    }

    private static Stream<Arguments> provideArgumentsForViewOrgCommand() {

        final RoDataCreateV1Valid roDataCreateV1 = CreateOrganisationDataSetup.createOrgData();
        UiHeader roHeaders = OrganisationTestUtil.generateEventHeader();
        BaseAudit audit = new BaseAudit();
        Map<String, String> auditContext = new HashMap<>();
        audit.setAuditContext(auditContext);

        BaseEvent<BaseHeader> event = new BaseEvent<>(roHeaders, null, null, audit);
        ViewROVO viewRo =
                ViewROVO.builder()
                        .eventHeaders(event.getEventHeader())
                        .eventBody(event.getEventBody())
                        .eventErrors(event.getEventErrors())
                        .audit(audit)
                        .build();

        CreateROVO createRo =
                CreateROVO.builder()
                        .eventHeaders(event.getEventHeader())
                        .eventBody(roDataCreateV1)
                        .eventErrors(event.getEventErrors())
                        .audit(audit)
                        .build();

        RecognisingOrganisation recognisingOrganisation =
                CreateOrganisationDataSetup.populateOrganisation(
                        createRo.getEventBody(), new RecognisingOrganisation());
        recognisingOrganisation.setRecognisingOrganisationUuid(
                UUID.fromString("cef4fcb1-2bd2-51f3-889d-abd47d775634"));
        RoRequestedEventV1 roChangedEvent =
                CreateOrganisationDataSetup.entityToEventMapperForView(recognisingOrganisation);
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put("recognisingOrganisationUuid", "cef4fcb1-2bd2-51f3-889d-abd47d775634");
        BaseHeader roHeader = viewRo.getEventHeaders();
        roHeader.setEventName(OrganisationConstants.EventType.RO_VIEW_DETAILS_EVENT);
        roHeader.setEventDateTime(LocalDateTime.now());
        roHeader.setEventDiscriminator("RO-UI");
        roHeader.setEventContext(eventContext);

        return Stream.of(Arguments.of(recognisingOrganisation, roChangedEvent));
    }
}
