package com.ielts.cmds.organisation.utills;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.common.enums.MethodOfDeliveryEnum;
import com.ielts.cmds.organisation.common.enums.VerificationStatusEnum;
import com.ielts.cmds.organisation.domain.model.LoadRODataV1;
import com.ielts.cmds.organisation.domain.model.LoadROMapV1;
import com.ielts.cmds.organisation.domain.model.LoadROMessageV1;
import com.ielts.cmds.organisation.domain.model.LoadRORecordEvent;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LoadRODataSetup {

    public static List<LoadRODataV1> getLoadRODataV1List() {
        List<LoadRODataV1> loadRODataV1List = new ArrayList<>();
        LoadRODataV1 loadRODataV1 = new LoadRODataV1();
        loadRODataV1.setName("McGill University");
        loadRODataV1.setSectorType("College / University");
        loadRODataV1.setVerificationStatus(VerificationStatusEnum.APPROVED.getValue());
        loadRODataV1.setAddressLine1("22 Heathfield Gardens");
        loadRODataV1.setAddressLine2("string");
        loadRODataV1.setAddressLine3("string");
        loadRODataV1.setAddressLine4("string");
        loadRODataV1.setCity("Cambridge");
        loadRODataV1.setTerritoryIso3Code("");
        loadRODataV1.setCountryIso3Code("");
        loadRODataV1.setPostalCode("CB2 8EA");
        loadRODataV1.setContactEmail("alan_2021@cambridgeassessment.org.uk");
        loadRODataV1.setTelephoneNo("+1 234 234 3456");
        loadRODataV1.setPartnerCode("IDP");
        loadRODataV1.setMethodOfDelivery(MethodOfDeliveryEnum.POSTAL.getValue());
        loadRODataV1.setTitle("Ms");
        loadRODataV1.setFirstName("results admin");
        loadRODataV1.setLastName("name");
        loadRODataV1.setJobTitle("Chief Suport Manager");
        loadRODataV1.setWebsiteUrl("www.officialxyz.com");
        loadRODataV1.setCrmSystem("CRM Value");
        loadRODataV1.setOrganisationId("12345");
        loadRODataV1.setRecognisedProduct("IOL");
        loadRODataV1.setAcMinimumScoreValue("4.5");
        loadRODataV1.setAcListeningMinimumScoreValue("4.5");
        loadRODataV1.setAcWritingMinimumScoreValue(null);
        loadRODataV1.setAcReadingMinimumScoreValue("4.5");
        loadRODataV1.setAcSpeakingMinimumScoreValue("4.5");
        loadRODataV1.setGtMinimumScoreValue("4");
        loadRODataV1.setGtWritingMinimumScoreValue("4");
        loadRODataV1.setGtListeningMinimumScoreValue("4");
        loadRODataV1.setGtReadingMinimumScoreValue(null);
        loadRODataV1.setGtSpeakingMinimumScoreValue("4");
        loadRODataV1.setAlternateName1("University Of McGill");
        loadRODataV1.setAlternateName2("University Of McGill");
        loadRODataV1.setAlternateName3("University Of McGill");
        loadRODataV1.setVisibleOnIelts("true");
        loadRODataV1.setSelectableOnOrs("false");
        loadRODataV1List.add(loadRODataV1);
        return loadRODataV1List;
    }

    public static List<LoadRODataV1> getLoadRODataList() {
        List<LoadRODataV1> loadRODataV1List = new ArrayList<>();
        LoadRODataV1 loadROData2 = new LoadRODataV1();
        loadROData2.setName("McGill University");
        loadROData2.setSectorType("College / University");
        loadROData2.setVerificationStatus(VerificationStatusEnum.APPROVED.getValue());
        loadROData2.setAddressLine1("22 Heathfield Gardens");
        loadROData2.setAddressLine2("string");
        loadROData2.setAddressLine3("string");
        loadROData2.setAddressLine4("string");
        loadROData2.setCity("Cambridge");
        loadROData2.setTerritoryIso3Code("");
        loadROData2.setCountryIso3Code("");
        loadROData2.setPostalCode("CB2 8EA");
        loadROData2.setContactEmail("alan_2021@cambridgeassessment.org.uk");
        loadROData2.setTelephoneNo("+1 234 234 3456");
        loadROData2.setPartnerCode("IDP");
        loadROData2.setMethodOfDelivery(MethodOfDeliveryEnum.POSTAL.getValue());
        loadROData2.setTitle("Ms");
        loadROData2.setFirstName("results admin");
        loadROData2.setLastName("name");
        loadROData2.setJobTitle("Chief Suport Manager");
        loadROData2.setWebsiteUrl("www.officialxyz.com");
        loadROData2.setCrmSystem("CRM Value");
        loadROData2.setOrganisationId("12345");
        loadROData2.setRecognisedProduct("NULL");
        loadROData2.setAlternateName1("NULL");
        loadRODataV1List.add(loadROData2);
        return loadRODataV1List;
    }

    public static Map<String, LoadRORecordEvent> getEventsMap(
            final BaseEvent<BaseHeader> baseEvent, final LoadRODataV1 loadRODataV1) {
        Map<String, LoadRORecordEvent> eventsMap = new HashMap<>();
        LoadRORecordEvent loadRORecordEvent = new LoadRORecordEvent();
        loadRORecordEvent.setEvent(baseEvent);
        loadRORecordEvent.setLoadRORecord(loadRODataV1);
        eventsMap.put("1", loadRORecordEvent);
        return eventsMap;
    }

    public static BaseEvent<BaseHeader> getROCreatedEvent(final RecognisingOrganisation publishRo)
            throws JsonProcessingException {
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        BaseHeader baseHeader = (BaseHeader) OrganisationTestUtil.generateEventHeader();
        baseHeader.setEventName(OrganisationConstants.EventType.RO_CREATED_EVENT);
        baseEvent.setEventHeader(baseHeader);
        baseEvent.setEventBody(
                new ObjectMapper()
                        .writeValueAsString(
                                CreateOrganisationDataSetup.entityToEventMapper(publishRo)));
        return baseEvent;
    }

    public static BaseEvent<BaseHeader> getRORejectedEvent() {
        BaseEvent<BaseHeader> baseEvent = new BaseEvent<>();
        BaseHeader baseHeader = (BaseHeader) OrganisationTestUtil.generateEventHeader();
        baseHeader.setEventName(OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT);
        baseEvent.setEventHeader(baseHeader);
        baseEvent.setEventErrors(
                new BaseEventErrors(
                        OrganisationTestUtil.getROErrorResponse(
                                        "V0001", "Invalid Website URL", "Invalid Website URL")
                                .getErrorList()));
        return baseEvent;
    }

    public static LoadROMessageV1 getLoadROMessageV1(final LoadRODataV1 loadRODataV1) {
        LoadROMessageV1 loadROMessageV1 = new LoadROMessageV1();
        LoadROMapV1 loadROMapV1 = new LoadROMapV1();
        loadROMapV1.put("1", loadRODataV1);
        loadROMessageV1.setMsg(loadROMapV1);
        return loadROMessageV1;
    }
}
