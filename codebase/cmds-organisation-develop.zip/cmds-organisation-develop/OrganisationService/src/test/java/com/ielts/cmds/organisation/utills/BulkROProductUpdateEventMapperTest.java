package com.ielts.cmds.organisation.utills;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.organisation.domain.commands.UpdateROVO;
import com.ielts.cmds.organisation.domain.model.BulkROProductsUpdateRecordEvent;
import com.ielts.cmds.organisation.domain.model.BulkRORecognisedProductUpdateMessageV1;
import com.ielts.cmds.organisation.domain.model.BulkRORecognisedProductsUpdateDataV1;
import com.ielts.cmds.organisation.domain.model.RoDataUpdateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.utils.BulkROProductUpdateEventMapper;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Stream;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class BulkROProductUpdateEventMapperTest {

    @InjectMocks private BulkROProductUpdateEventMapper bulkROProductUpdateEventMapper;

    @Mock private ObjectMapper objectMapper;

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void mapToEvent_ExpectNoException(
            Map<String, BulkROProductsUpdateRecordEvent> eventsMap,
            RoChangedEventV1 roChangedEventV1)
            throws JsonProcessingException {
        doReturn(roChangedEventV1)
                .when(objectMapper)
                .readValue(eventsMap.get("1").getEvent().getEventBody(), RoChangedEventV1.class);
        BulkRORecognisedProductUpdateMessageV1 actual =
                bulkROProductUpdateEventMapper.mapToEvent(eventsMap);
        assertNotNull(actual);
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationLoadDataEvent")
    void mapToEvent_JsonProcessingException_ExpectNoException(
            Map<String, BulkROProductsUpdateRecordEvent> eventsMap,
            RoChangedEventV1 roChangedEventV1)
            throws JsonProcessingException {
        doThrow(JsonProcessingException.class)
                .when(objectMapper)
                .readValue(eventsMap.get("1").getEvent().getEventBody(), RoChangedEventV1.class);
        assertDoesNotThrow(() -> bulkROProductUpdateEventMapper.mapToEvent(eventsMap));
    }

    @ParameterizedTest
    @MethodSource("argumentsProviderForOrganisationLoadDataEventRejected")
    void mapToEvent_Rejected_ExpectNoException(
            Map<String, BulkROProductsUpdateRecordEvent> eventsMap) {
        BulkRORecognisedProductUpdateMessageV1 actual =
                bulkROProductUpdateEventMapper.mapToEvent(eventsMap);
        assertNotNull(actual);
    }

    private static Stream<Arguments> argumentsProviderForOrganisationLoadDataEvent()
            throws JsonProcessingException {
        List<BulkRORecognisedProductsUpdateDataV1> bulkROProductsUpdateDataV1List =
                BulkROProductUpdateDataSetup.getLoadROProductUpdateDataV1List();
        RoDataUpdateV1Valid roData = UpdateOrganisationDataSetup.updateOrgData();
        final UpdateROVO updateROVO = UpdateROVO.builder().eventBody(roData).build();
        RecognisingOrganisation publishRo =
                UpdateOrganisationDataSetup.getExistingOrganisationDetails(
                        updateROVO.getEventBody(), new RecognisingOrganisation());
        publishRo.setRecognisingOrganisationUuid(
                UUID.fromString("8a1b4ce2-ac2b-46c7-8a8d-fb74df1eebec"));
        Map<String, BulkROProductsUpdateRecordEvent> eventsMap =
                BulkROProductUpdateDataSetup.getEventsMap(
                        BulkROProductUpdateDataSetup.getROUpdatedEvent(publishRo),
                        bulkROProductsUpdateDataV1List.get(0));

        return Stream.of(
                Arguments.of(
                        eventsMap, CreateOrganisationDataSetup.entityToEventMapper(publishRo)));
    }

    private static Stream<Arguments> argumentsProviderForOrganisationLoadDataEventRejected() {
        List<BulkRORecognisedProductsUpdateDataV1> loadRoErrorData =
                BulkROProductUpdateDataSetup.getLoadROProductUpdateDataV1List();
        Map<String, BulkROProductsUpdateRecordEvent> errorEvent =
                BulkROProductUpdateDataSetup.getEventsMap(
                        BulkROProductUpdateDataSetup.getROChangedRejectedEvent(),
                        loadRoErrorData.get(0));

        return Stream.of(Arguments.of(errorEvent));
    }
}
