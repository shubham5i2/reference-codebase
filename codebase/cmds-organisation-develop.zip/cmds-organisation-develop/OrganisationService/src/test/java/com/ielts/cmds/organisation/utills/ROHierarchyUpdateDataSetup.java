package com.ielts.cmds.organisation.utills;

import com.ielts.cmds.organisation.domain.model.HierarchyUpdateV1;
import java.util.UUID;

public class ROHierarchyUpdateDataSetup {

    public static HierarchyUpdateV1 createHierarchyUpdateV1Data() {
        HierarchyUpdateV1 hierarchyUpdateV1 = new HierarchyUpdateV1();
        hierarchyUpdateV1.setOldHierarchyLabel("1");
        hierarchyUpdateV1.setNewHierarchyLabel("3");
        hierarchyUpdateV1.setTriggerRecognisingOrganisationUuid(
                UUID.fromString("6dafc1f5-bb16-41db-8b5d-295691c75300"));
        hierarchyUpdateV1.setRecognisingOrganisationUuid(
                UUID.fromString("88e18cae-1bdd-45a7-be1c-0a37926f9bbe"));
        return hierarchyUpdateV1;
    }
}
