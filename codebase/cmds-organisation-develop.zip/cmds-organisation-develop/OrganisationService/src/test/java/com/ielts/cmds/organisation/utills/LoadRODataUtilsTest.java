package com.ielts.cmds.organisation.utills;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.doReturn;

import com.ielts.cmds.organisation.domain.model.LoadRODataV1;
import com.ielts.cmds.organisation.domain.model.RoDataCreateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.AddressType;
import com.ielts.cmds.organisation.infrastructure.entity.Country;
import com.ielts.cmds.organisation.infrastructure.entity.SectorType;
import com.ielts.cmds.organisation.infrastructure.entity.Territory;
import com.ielts.cmds.organisation.infrastructure.repository.AddressTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.ContactTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.CountryRepository;
import com.ielts.cmds.organisation.infrastructure.repository.ModuleTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.OrganisationTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.SectorTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.TerritoryRepository;
import com.ielts.cmds.organisation.utils.LoadRODataUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class LoadRODataUtilsTest {

    @InjectMocks private LoadRODataUtils loadRODataUtils;

    @Mock private CountryRepository countryRepository;

    @Mock private TerritoryRepository territoryRepository;

    @Mock private OrganisationTypeRepository organisationTypeRepository;

    @Mock private SectorTypeRepository sectorTypeRepository;

    @Mock private ModuleTypeRepository moduleTypeRepository;

    @Mock private ContactTypeRepository contactTypeRepository;

    @Mock private AddressTypeRepository addressTypeRepository;

    @ParameterizedTest
    @MethodSource("provideArgumentsForLoadRODataUtils")
    void loadData_ExpectValue(LoadRODataV1 record) {
        doReturn(CreateOrganisationDataSetup.getOrganisationTypeData())
                .when(organisationTypeRepository)
                .findByOrganisationsType(
                        OrganisationConstants.GenericConstants.RECOGNISING_ORGANISATION);
        doReturn(CreateOrganisationDataSetup.getModuleTypeData())
                .when(moduleTypeRepository)
                .findByModulesType("AC");
        doReturn(CreateOrganisationDataSetup.getModuleTypeData())
                .when(moduleTypeRepository)
                .findByModulesType("GT");
        List<Country> countries = new ArrayList<>();
        countries.add(CreateOrganisationDataSetup.getCountryData());
        doReturn(countries).when(countryRepository).findAll();
        List<Territory> territories = new ArrayList<>();
        territories.add(CreateOrganisationDataSetup.getTerritoryData());
        doReturn(territories).when(territoryRepository).findAll();
        List<SectorType> sectorTypeList = new ArrayList<>();
        sectorTypeList.add(CreateOrganisationDataSetup.getSectorTypeData());
        doReturn(sectorTypeList).when(sectorTypeRepository).findAll();

        List<AddressType> addressTypes = new ArrayList<>();
        addressTypes.add(CreateOrganisationDataSetup.getAddressTypeData());
        doReturn(addressTypes).when(addressTypeRepository).findAll();

        doReturn(CreateOrganisationDataSetup.getPrimaryContactTypeData())
                .when(contactTypeRepository)
                .findByContactsType(OrganisationConstants.GenericConstants.PRIMARY_CONTACT);

        doReturn(CreateOrganisationDataSetup.getResultsAdminContactTypeData())
                .when(contactTypeRepository)
                .findByContactsType(OrganisationConstants.GenericConstants.RESULT_ADMIN);
        RoDataCreateV1Valid actual =
                loadRODataUtils.loadData(
                        record, OrganisationConstants.GenericConstants.RECOGNISING_ORGANISATION);
        assertNotNull(actual);
    }

    @ParameterizedTest
    @MethodSource("provideArgumentsForLoadRODataUtilsAlternatePath")
    void loadData_AlternatePath_ExpectValue(LoadRODataV1 record) {
        doReturn(CreateOrganisationDataSetup.getOrganisationTypeData())
                .when(organisationTypeRepository)
                .findByOrganisationsType(
                        OrganisationConstants.GenericConstants.RECOGNISING_ORGANISATION);
        List<Country> countries = new ArrayList<>();
        countries.add(CreateOrganisationDataSetup.getCountryData());
        doReturn(countries).when(countryRepository).findAll();
        List<Territory> territories = new ArrayList<>();
        territories.add(CreateOrganisationDataSetup.getTerritoryData());
        doReturn(territories).when(territoryRepository).findAll();
        List<SectorType> sectorTypeList = new ArrayList<>();
        sectorTypeList.add(CreateOrganisationDataSetup.getSectorTypeData());
        doReturn(sectorTypeList).when(sectorTypeRepository).findAll();

        List<AddressType> addressTypes = new ArrayList<>();
        addressTypes.add(CreateOrganisationDataSetup.getAddressTypeData());
        doReturn(addressTypes).when(addressTypeRepository).findAll();

        doReturn(CreateOrganisationDataSetup.getPrimaryContactTypeData())
                .when(contactTypeRepository)
                .findByContactsType(OrganisationConstants.GenericConstants.PRIMARY_CONTACT);

        doReturn(CreateOrganisationDataSetup.getResultsAdminContactTypeData())
                .when(contactTypeRepository)
                .findByContactsType(OrganisationConstants.GenericConstants.RESULT_ADMIN);
        RoDataCreateV1Valid actual =
                loadRODataUtils.loadData(
                        record, OrganisationConstants.GenericConstants.RECOGNISING_ORGANISATION);
        assertNotNull(actual);
    }

    @ParameterizedTest
    @MethodSource("provideArgumentsForLoadVODataUtils")
    void loadVOData_ExpectValue(LoadRODataV1 record) {
        doReturn(CreateOrganisationDataSetup.getVOOrganisationTypeData())
                .when(organisationTypeRepository)
                .findByOrganisationsType(
                        OrganisationConstants.GenericConstants.VERIFIED_ORGANISATION);
        doReturn(CreateOrganisationDataSetup.getModuleTypeData())
                .when(moduleTypeRepository)
                .findByModulesType("AC");
        doReturn(CreateOrganisationDataSetup.getModuleTypeData())
                .when(moduleTypeRepository)
                .findByModulesType("GT");
        List<Country> countries = new ArrayList<>();
        countries.add(CreateOrganisationDataSetup.getCountryData());
        doReturn(countries).when(countryRepository).findAll();
        List<Territory> territories = new ArrayList<>();
        territories.add(CreateOrganisationDataSetup.getTerritoryData());
        doReturn(territories).when(territoryRepository).findAll();
        List<SectorType> sectorTypeList = new ArrayList<>();
        sectorTypeList.add(CreateOrganisationDataSetup.getSectorTypeData());
        doReturn(sectorTypeList).when(sectorTypeRepository).findAll();

        List<AddressType> addressTypes = new ArrayList<>();
        addressTypes.add(CreateOrganisationDataSetup.getAddressTypeData());
        doReturn(addressTypes).when(addressTypeRepository).findAll();

        doReturn(CreateOrganisationDataSetup.getPrimaryContactTypeData())
                .when(contactTypeRepository)
                .findByContactsType(OrganisationConstants.GenericConstants.PRIMARY_CONTACT);

        doReturn(CreateOrganisationDataSetup.getResultsAdminContactTypeData())
                .when(contactTypeRepository)
                .findByContactsType(OrganisationConstants.GenericConstants.RESULT_ADMIN);
        RoDataCreateV1Valid actual =
                loadRODataUtils.loadData(
                        record, OrganisationConstants.GenericConstants.VERIFIED_ORGANISATION);
        assertNotNull(actual);
    }

    @ParameterizedTest
    @MethodSource("provideArgumentsForLoadVODataUtilsAlternatePath")
    void loadVOData_AlternatePath_ExpectValue(LoadRODataV1 record) {
        doReturn(CreateOrganisationDataSetup.getVOOrganisationTypeData())
                .when(organisationTypeRepository)
                .findByOrganisationsType(
                        OrganisationConstants.GenericConstants.VERIFIED_ORGANISATION);
        List<Country> countries = new ArrayList<>();
        countries.add(CreateOrganisationDataSetup.getCountryData());
        doReturn(countries).when(countryRepository).findAll();
        List<SectorType> sectorTypeList = new ArrayList<>();
        sectorTypeList.add(CreateOrganisationDataSetup.getSectorTypeData());
        doReturn(sectorTypeList).when(sectorTypeRepository).findAll();

        List<AddressType> addressTypes = new ArrayList<>();
        addressTypes.add(CreateOrganisationDataSetup.getAddressTypeData());
        doReturn(addressTypes).when(addressTypeRepository).findAll();
        RoDataCreateV1Valid actual =
                loadRODataUtils.loadData(
                        record, OrganisationConstants.GenericConstants.VERIFIED_ORGANISATION);
        assertNotNull(actual);
    }

    private static Stream<Arguments> provideArgumentsForLoadRODataUtils() {
        return Stream.of(Arguments.of(LoadRODataSetup.getLoadRODataV1List().get(0)));
    }

    private static Stream<Arguments> provideArgumentsForLoadRODataUtilsAlternatePath() {
        return Stream.of(Arguments.of(LoadRODataSetup.getLoadRODataList().get(0)));
    }

    private static Stream<Arguments> provideArgumentsForLoadVODataUtils() {
        return Stream.of(Arguments.of(LoadVODataSetup.getLoadVODataV1List().get(0)));
    }

    private static Stream<Arguments> provideArgumentsForLoadVODataUtilsAlternatePath() {
        return Stream.of(Arguments.of(LoadVODataSetup.getLoadVODataList().get(0)));
    }
}
