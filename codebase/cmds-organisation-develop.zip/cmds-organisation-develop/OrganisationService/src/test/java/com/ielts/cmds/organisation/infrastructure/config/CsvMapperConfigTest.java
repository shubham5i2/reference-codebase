package com.ielts.cmds.organisation.infrastructure.config;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;

@ExtendWith(MockitoExtension.class)
class CsvMapperConfigTest {
	
	@InjectMocks private CSVMapperConfig csvMapperConfig;
	
	@Test
	void csvMapperConfigTest() {
		CsvMapper actual = csvMapperConfig.csvMapper();
		assertNotNull(actual);
		assertFalse(actual.isEnabled(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES));
		assertFalse(actual.isEnabled(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY));
	}
}
