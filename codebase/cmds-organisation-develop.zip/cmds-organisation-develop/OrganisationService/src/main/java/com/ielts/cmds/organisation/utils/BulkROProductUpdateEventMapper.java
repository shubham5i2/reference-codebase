package com.ielts.cmds.organisation.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.organisation.domain.model.BulkROProductsUpdateRecordEvent;
import com.ielts.cmds.organisation.domain.model.BulkRORecognisedProductUpdateMessageV1;
import com.ielts.cmds.organisation.domain.model.BulkRORecognisedProductsUpdateDataV1;
import com.ielts.cmds.organisation.domain.model.BulkRORecognisedProductsUpdateMapV1;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class BulkROProductUpdateEventMapper {

    @Autowired private ObjectMapper objectMapper;

    public BulkRORecognisedProductUpdateMessageV1 mapToEvent(
            Map<String, BulkROProductsUpdateRecordEvent> eventsMap) {
        BulkRORecognisedProductUpdateMessageV1 bulkROProductUpdateMessageV1 =
                new BulkRORecognisedProductUpdateMessageV1();
        BulkRORecognisedProductsUpdateMapV1 bulkROProductUpdateMapV1 =
                new BulkRORecognisedProductsUpdateMapV1();
        eventsMap.forEach(
                (key, value) -> {
                    try {
                        log.debug(
                                "The record being mapped : {} ",
                                objectMapper.writeValueAsString(value));
                        BulkRORecognisedProductsUpdateDataV1 bulkROProductUpdateDataV1 =
                                getBulkROProdcutUpdateDataV1(value);
                        bulkROProductUpdateDataV1.setRowNumber(key);
                        bulkROProductUpdateMapV1.put(key, bulkROProductUpdateDataV1);
                    } catch (JsonProcessingException e) {
                        log.error("Exception: {}", e);
                    }
                });
        bulkROProductUpdateMessageV1.setMsg(bulkROProductUpdateMapV1);
        return bulkROProductUpdateMessageV1;
    }

    public BulkRORecognisedProductsUpdateDataV1 getBulkROProdcutUpdateDataV1(
            final BulkROProductsUpdateRecordEvent bulkROProductUpdateRecordEvent)
            throws JsonProcessingException {
        BulkRORecognisedProductsUpdateDataV1 bulkROProductUpdateDataV1 =
                bulkROProductUpdateRecordEvent.getBulkRoProductsUpdateRecord();
        log.debug(
                "OrganisationID Record: {} and recognisingOrganisationUUid : {}",
                bulkROProductUpdateDataV1.getOrganisationId(),
                bulkROProductUpdateDataV1.getRecognisingOrganisationUuid());

        if (OrganisationConstants.EventType.RO_UPDATED_EVENT.equals(
                bulkROProductUpdateRecordEvent.getEvent().getEventHeader().getEventName())) {
            RoChangedEventV1 eventBody =
                    objectMapper.readValue(
                            bulkROProductUpdateRecordEvent.getEvent().getEventBody(),
                            RoChangedEventV1.class);
            bulkROProductUpdateDataV1.setRecognisingOrganisationUuid(
                    eventBody.getRecognisingOrganisationUuid().toString());
        } else if (OrganisationConstants.EventType.RO_UPDATE_REJECTED_EVENT.equals(
                bulkROProductUpdateRecordEvent.getEvent().getEventHeader().getEventName())) {
            String errorListString =
                    bulkROProductUpdateRecordEvent.getEvent().getEventErrors().getErrorList()
                            .stream()
                            .map(this::populateErrorCodeAndTitle)
                            .collect(Collectors.joining(", "));
            bulkROProductUpdateDataV1.setErrorListString(errorListString);
        }else{
            throw new IllegalStateException();
        }
        return bulkROProductUpdateDataV1;
    }


    public String populateErrorCodeAndTitle(final ErrorDescription errorDescription) {
        return errorDescription.getErrorCode() + "-" + errorDescription.getMessage();
    }
}
