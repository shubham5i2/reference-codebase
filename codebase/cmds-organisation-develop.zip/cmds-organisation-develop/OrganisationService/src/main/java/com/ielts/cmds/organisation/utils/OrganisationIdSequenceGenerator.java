package com.ielts.cmds.organisation.utils;

import java.math.BigInteger;

import javax.persistence.FlushModeType;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.hibernate.tuple.ValueGenerator;

import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;

public class OrganisationIdSequenceGenerator implements ValueGenerator<Integer> {

	@Override
	public Integer generateValue(Session session, Object obj) {

		RecognisingOrganisation recObj = (RecognisingOrganisation) obj;
		if(recObj.getOrganisationId()!=null) {
			return recObj.getOrganisationId();
		}else {
			Query<?> query = session.createSQLQuery("SELECT nextval('ro_owner.organisationId_generator')");
			Long organisationIdValue = ((BigInteger) query.setFlushMode(FlushModeType.COMMIT).uniqueResult()).longValue();
			return Integer.valueOf(organisationIdValue.intValue());
		}
	}
}