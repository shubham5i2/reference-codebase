package com.ielts.cmds.organisation.application;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.common.config.IApplicationService;
import com.ielts.cmds.common.config.IBaseAuditService;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.common.exception.util.CMDSServiceException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.domain.commands.LoadROData;
import com.ielts.cmds.organisation.domain.services.LoadRODomainService;
import com.ielts.cmds.organisation.domain.services.LoadROUpdateDomainService;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class OrganisationLoadDataService implements IApplicationService, IBaseAuditService {

    @Autowired private LoadRODomainService loadRODomainService;

    @Autowired private LoadROUpdateDomainService loadROUpdateDomainService;

    private static final String EVENTNAME =
             OrganisationConstants.GenericConstants.RO_PROCESS_REQUEST_EVENT;

    /**
     * This method handles incoming requests and creates command to call domain service for further
     * processing
     *
     * @throws CMDSServiceException
     * @throws JsonProcessingException
     */
    @Override
    public String getServiceIdentifier() {
        return EVENTNAME;
    }

    @Override
    public void process(BaseEvent<? extends BaseHeader> baseEvent) throws ProcessingException {
        try {
            log.debug(
                    "Request with transactionId and eventname as: {},{}",
                    baseEvent.getEventHeader().getTransactionId(),
                    baseEvent.getEventHeader().getEventName());

            populateAuditFields(baseEvent.getAudit());
            // build command
            final LoadROData loadROData =
                    LoadROData.builder()
                            .eventHeaders(baseEvent.getEventHeader())
                            .eventErrors(baseEvent.getEventErrors())
                            .audit(baseEvent.getAudit())
                            .build();
            // Execute command
            String mode = loadRODomainService.getOperationMode(baseEvent.getEventHeader());
            if (OrganisationConstants.GenericConstants.CREATE_MODE.equals(mode)) {
                loadRODomainService.onCommand(loadROData);
            } else {
                loadROUpdateDomainService.onCommand(loadROData);
            }

        } catch (Exception e) {
            log.error("Exception while processing: ", e);
            throw new ProcessingException(e.getMessage(), e);
        }
    }

    @Override
    public String getPermission() {
        return OrganisationConstants.Permissions.ORG_CREATE;
    }

    @Override
    public String getScreen() {
        return null;
    }

    @Override
    public String getAction() {
        return LoadROData.class.getSimpleName();
    }
}
