package com.ielts.cmds.organisation.cache.factory;

import com.ielts.cmds.organisation.cache.JedisCacheReader;
import com.ielts.cmds.organisation.cache.JedisGenericReader;
import com.ielts.cmds.organisation.cache.JedisReaderHelper;
import lombok.NoArgsConstructor;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import redis.clients.jedis.Connection;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisPooled;
import redis.clients.jedis.UnifiedJedis;

import java.net.URI;
import java.util.HashSet;
import java.util.Set;

@Configuration
@NoArgsConstructor
public class JedisFactory {

	@Value("${is-cluster-mode-enabled}")
	private String isClusterModeEnabled;

	@Value("${redis-elasticache-host}")
	private String redisElasticacheHost;

	@Value("${redis-elasticache-port:6379}")
	private String redisElasticachePort;

	@Autowired
	private JedisReaderHelper jedisReaderHelper;
	
	public boolean isClusterModeEnabled() {
		return Boolean.valueOf(isClusterModeEnabled);
	}

	public UnifiedJedis jedisCluster() {
		Set<HostAndPort> jedisClusterNodes = new HashSet<>();
		jedisClusterNodes.add(new HostAndPort(redisElasticacheHost,
				Integer.parseInt(redisElasticachePort)));
		return new JedisCluster(jedisClusterNodes);
	}

	public UnifiedJedis jedis() {
		return getJedisPool();
	}

	public JedisPooled getJedisPool(){
		final GenericObjectPoolConfig<Connection> poolConfig = buildPoolConfig();
		String redisEndpointUrl = redisElasticacheHost + ":"
				+ redisElasticachePort;
		return new JedisPooled(poolConfig, URI.create("rediss://" + redisEndpointUrl));
	}

	public GenericObjectPoolConfig<Connection> buildPoolConfig() {
		final GenericObjectPoolConfig<Connection> poolConfig = new GenericObjectPoolConfig<>();
		poolConfig.setMaxTotal(2);
		poolConfig.setMaxIdle(1);
		return poolConfig;
	}

	@Bean(name ="jedisClusterCacheReader")
	@ConditionalOnProperty(name = "is-cluster-mode-enabled", havingValue = "true")
	public JedisGenericReader jedisClusterReader() {
		return new JedisCacheReader(jedisReaderHelper, jedisCluster());
	}

	@Bean(name ="jedisCacheReader")
	@ConditionalOnProperty(name = "is-cluster-mode-enabled", havingValue = "false")
	public JedisGenericReader jedisCacheReader() {
		return new JedisCacheReader(jedisReaderHelper, jedis());
	}
}
