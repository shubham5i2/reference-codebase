package com.ielts.cmds.organisation.infrastructure.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.IdClass;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@IdClass(DuplicateSearchResultId.class)
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@NamedStoredProcedureQuery(
        name = "getFuzzySearchResults",
        procedureName = "ro_owner.ro_fuzzy_search",
        resultClasses = RODuplicateFuzzySearchResult.class,
        parameters = {
            @StoredProcedureParameter(
                    name = "_org_name",
                    mode = ParameterMode.IN,
                    type = String.class),
            @StoredProcedureParameter(
                    name = "_city_name",
                    mode = ParameterMode.IN,
                    type = String.class),
            @StoredProcedureParameter(
                    name = "_postal_code",
                    mode = ParameterMode.IN,
                    type = String.class)
        })
public class RODuplicateFuzzySearchResult extends RODuplicateSearchReturnType implements Serializable {

        /** Generated SerialVersionId */
        private static final long serialVersionUID = -4870765980203375570L;
  
}
