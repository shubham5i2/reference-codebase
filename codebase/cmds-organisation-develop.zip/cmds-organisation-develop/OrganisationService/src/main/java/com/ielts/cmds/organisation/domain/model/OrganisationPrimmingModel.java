package com.ielts.cmds.organisation.domain.model;

import java.util.List;
import java.util.UUID;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode
@Data
@NoArgsConstructor
public class OrganisationPrimmingModel {

    List<UUID> organisationsToBePublished;
}
