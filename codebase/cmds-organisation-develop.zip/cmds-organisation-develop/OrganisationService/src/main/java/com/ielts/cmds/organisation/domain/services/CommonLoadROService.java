package com.ielts.cmds.organisation.domain.services;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CommonLoadROService {

    @Autowired protected ObjectMapper objectMapper;

    @Autowired protected CsvMapper csvMapper;

    /**
     * Get S3 Bucket Filename from eventContext
     *
     * @param baseHeader
     * @return
     */
    protected String getFileName(final BaseHeader baseHeader) {
        final Map<String, String> eventContext =
                Optional.ofNullable(baseHeader.getEventContext())
                        .orElseThrow(
                                () ->
                                        new IllegalArgumentException(
                                                "Event Context cannot be empty"));
        final String fileName =
                eventContext.get(OrganisationConstants.GenericConstants.RO_DATA_FILE);
        if (StringUtils.isEmpty(fileName)) {
            throw new IllegalArgumentException("File name cannot be empty");
        }
        return fileName;
    }

    /**
     * Get Mode Of Operation from eventContext
     *
     * @param baseHeader
     * @return
     */
    public String getOperationMode(final BaseHeader baseHeader) {
        final Map<String, String> eventContext =
                Optional.ofNullable(baseHeader.getEventContext())
                        .orElseThrow(
                                () ->
                                        new IllegalArgumentException(
                                                "Event Context cannot be empty"));
        final String mode = eventContext.get(OrganisationConstants.GenericConstants.MODE);
        if (StringUtils.isEmpty(mode)) {
            throw new IllegalArgumentException("Mode cannot be empty");
        }
        if (StringUtils.isEmpty(
                eventContext.get(OrganisationConstants.GenericConstants.LOAD_ORGANISATION_TYPE))) {
            throw new IllegalArgumentException("Organisation Type cannot be empty");
        }
        return mode;
    }

    protected BaseEvent<BaseHeader> generateErrorFromException(
            BaseHeader eventHeaders, Exception e, String eventName) {
        BaseHeader baseHeader = new BaseHeader();
        BeanUtils.copyProperties(eventHeaders, baseHeader);
        baseHeader.setEventName(eventName);
        List<ErrorDescription> errorList = new ArrayList<>();
        ErrorDescription errorDescription = new ErrorDescription();
        errorDescription.setErrorCode("E0001");
        errorDescription.setInterfaceName(OrganisationConstants.ErrorResponse.RO_INTERFACE_ERROR);
        errorDescription.setTitle(e.getMessage());
        errorDescription.setMessage(e.getMessage());
        errorDescription.setType(ErrorTypeEnum.ERROR);
        errorList.add(errorDescription);
        BaseEventErrors eventErrors = new BaseEventErrors(errorList);
        return new BaseEvent<>(baseHeader, null, eventErrors, null);
    }
}
