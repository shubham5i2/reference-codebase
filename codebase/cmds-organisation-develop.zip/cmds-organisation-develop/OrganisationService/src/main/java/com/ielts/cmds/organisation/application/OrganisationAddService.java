package com.ielts.cmds.organisation.application;

import com.ielts.cmds.common.config.IBaseAuditService;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.domain.commands.CreateROVO;
import com.ielts.cmds.organisation.domain.model.RoDataCreateV1Valid;
import com.ielts.cmds.organisation.domain.services.CreateOrganisationDomainService;
import com.ielts.cmds.organisation.utils.OrganisationConstants;

import com.ielts.cmds.serialization.application.service.IApplicationServiceV2;
import com.ielts.cmds.serialization.utils.ServiceIdentifier;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@ServiceIdentifier(OrganisationConstants.GenericConstants.RO_CREATE_REQUEST_EVENT)
public class OrganisationAddService implements IApplicationServiceV2<RoDataCreateV1Valid>, IBaseAuditService {

    @Autowired
    private CreateOrganisationDomainService createOrganisationDomainService;

    /**
     * This method handles incoming requests and creates command to call domain service for further
     * processing
     *
     * @param cmdsEventBody
     */
    @SneakyThrows
    @Override
    public void process(final RoDataCreateV1Valid cmdsEventBody) {

        try {
            log.debug(
                    "Request with transactionId and event name as: {}, {}",
                    ThreadLocalHeaderContext.getContext().getTransactionId(),
                    ThreadLocalHeaderContext.getContext().getEventName());
            if (cmdsEventBody == null) {
                throw new IllegalArgumentException(
                        OrganisationConstants.ErrorResponse.EMPTY_PAYLOAD);
            }
            populateAuditFields();
            // Execute command
            createOrganisationDomainService.onCommand(cmdsEventBody);
        } catch (Exception e) {
            log.error("Exception while processing Request: ", e);
            throw new ProcessingException(e.getMessage(), e);
        }
    }

    @Override
    public String getPermission() {
        return OrganisationConstants.Permissions.ORG_CREATE;
    }

    @Override
    public String getScreen() {
        return OrganisationConstants.Screen.CREATE_ORGANISATION;
    }

    @Override
    public String getAction() {
        return CreateROVO.class.getSimpleName();
    }


}
