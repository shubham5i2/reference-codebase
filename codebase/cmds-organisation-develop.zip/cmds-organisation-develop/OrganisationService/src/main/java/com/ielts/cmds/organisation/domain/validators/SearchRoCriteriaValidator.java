package com.ielts.cmds.organisation.domain.validators;


import com.ielts.cmds.api.roui005rosearchrequested.RoSearchObject;
import com.ielts.cmds.api.roui005rosearchrequested.RoSearchCriteria;
import java.util.Objects;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

@Component
public class SearchRoCriteriaValidator {

    public boolean isValid(RoSearchObject roSearchObject) {

        RoSearchCriteria searchCriteria = roSearchObject.getCriteria();

        return !(StringUtils.isEmpty(searchCriteria.getCity())
                && StringUtils.isEmpty(searchCriteria.getContactEmail())
                && StringUtils.isEmpty(searchCriteria.getContactName())
                && Objects.isNull(searchCriteria.getOrganisationId())
                && StringUtils.isEmpty(searchCriteria.getOrganisationName())
                && StringUtils.isEmpty(searchCriteria.getPartnerCode())
                && StringUtils.isEmpty(searchCriteria.getPostalCode())
                && Objects.isNull(searchCriteria.getOrganisationStatus())
                && Objects.isNull(searchCriteria.getOrganisationTypeUuid())
                && Objects.isNull(searchCriteria.getVerificationStatus())
                && Objects.isNull(searchCriteria.getCountry())
                && Objects.isNull(searchCriteria.getTerritory()));
    }
}
