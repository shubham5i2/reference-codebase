package com.ielts.cmds.organisation.infrastructure.entity;

import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;

@Entity(name = "organisation_type")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class OrganisationType extends ReferenceModel implements Serializable {

    /** Generated SerialVersionID */
    private static final long serialVersionUID = 5192256667642411161L;

    @Id
    @GeneratedValue
    @Type(type = "uuid-char")
    @Column(name = "organisation_type_uuid")
    private UUID organisationTypeUuid;

    @Column(name = "organisation_type", nullable = false)
    private String organisationsType;

    @Column(name = "description")
    private String description;
}
