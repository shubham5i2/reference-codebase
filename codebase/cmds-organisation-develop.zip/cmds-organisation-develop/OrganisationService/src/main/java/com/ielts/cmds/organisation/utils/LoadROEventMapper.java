package com.ielts.cmds.organisation.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.organisation.domain.model.LoadRODataV1;
import com.ielts.cmds.organisation.domain.model.LoadROMapV1;
import com.ielts.cmds.organisation.domain.model.LoadROMessageV1;
import com.ielts.cmds.organisation.domain.model.LoadRORecordEvent;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class LoadROEventMapper {

    @Autowired private ObjectMapper objectMapper;

    public LoadROMessageV1 mapToEvent(Map<String, LoadRORecordEvent> eventsMap) {
        LoadROMessageV1 loadROMessageV1 = new LoadROMessageV1();
        LoadROMapV1 loadROMapV1 = new LoadROMapV1();
        eventsMap.forEach(
                (key, value) -> {
                    try {
                        LoadRODataV1 loadRODataV1 = getLoadRODataV1(value);
                        loadRODataV1.setRowNumber(key);
                        loadROMapV1.put(key, loadRODataV1);
                    } catch (JsonProcessingException e) {
                        log.error("Exception: {}", e);
                    }
                });
        loadROMessageV1.setMsg(loadROMapV1);
        return loadROMessageV1;
    }

    public LoadRODataV1 getLoadRODataV1(final LoadRORecordEvent loadRORecordEvent)
            throws JsonProcessingException {
        LoadRODataV1 loadRODataV1 = loadRORecordEvent.getLoadRORecord();

        if (OrganisationConstants.EventType.RO_CREATED_EVENT.equals(
                loadRORecordEvent.getEvent().getEventHeader().getEventName())) {
            RoChangedEventV1 eventBody =
                    objectMapper.readValue(
                            loadRORecordEvent.getEvent().getEventBody(), RoChangedEventV1.class);
            loadRODataV1.setRecognisingOrganisationUuid(
                    eventBody.getRecognisingOrganisationUuid().toString());
            if(loadRODataV1.getOrganisationId().isEmpty()) {
                loadRODataV1.setOrganisationId(eventBody.getOrganisationId().toString());
            }
            loadRODataV1.setDbRoName(eventBody.getOrganisationName());
        } else if (OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT.equals(
                loadRORecordEvent.getEvent().getEventHeader().getEventName())) {
            String errorListString =
                    loadRORecordEvent.getEvent().getEventErrors().getErrorList().stream()
                            .map(this::populateErrorCodeAndTitle)
                            .collect(Collectors.joining(", "));
            loadRODataV1.setErrorListString(errorListString);
        } else{
            throw new IllegalStateException();
        }
        return loadRODataV1;
    }

    public String populateErrorCodeAndTitle(final ErrorDescription errorDescription) {
        return errorDescription.getErrorCode() + "-" + errorDescription.getMessage();
    }
}
