package com.ielts.cmds.organisation.cache;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.organisation.cache.constants.ProductDataReadCacheConstants;
import com.ielts.cmds.organisation.cache.entity.Product;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.UnifiedJedis;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

@Slf4j
@RequiredArgsConstructor
public class JedisCacheReader implements JedisGenericReader {

	private final JedisReaderHelper readerHelper;

	private final UnifiedJedis jedis;

	@Override
	public Optional<Product> retrieveSingleProductDataFromRedisCache(String key) throws JsonProcessingException {
		String productKey = String.join("-", "product", key);
		return retrieveProductDataFromHashMap(productKey);
	}

	@Override
	public List<Product> retrieveAllBookableProductsDataFromRedisCache() throws JsonProcessingException {
		return getProductDataByKeyOfSet(ProductDataReadCacheConstants.KEY_OF_ALL_BOOKABLE_PRODUCTS);
	}

	@Override
	public List<Product> retrieveAllProductsDataFromRedisCache() throws JsonProcessingException {
		return getProductDataByKeyOfSet(ProductDataReadCacheConstants.KEY_OF_ALL_PRODUCTS);
	}
	
	private List<Product> getProductDataByKeyOfSet(String keyOfSet) throws JsonProcessingException {
		Set<String> allProductsKeys = jedis.smembers(keyOfSet);
		if(allProductsKeys.isEmpty()) {
			return new ArrayList<>();
		} else {
			log.debug("Products keys :{} from Set :{} ", allProductsKeys, keyOfSet);
			List<Product> listOfAllProducts = new ArrayList<>();
			for(String productKey : allProductsKeys) {
				Optional<Product> productData = retrieveProductDataFromHashMap(productKey);
				productData.ifPresent(listOfAllProducts::add);
			}
			log.debug("List of All Products : {}", listOfAllProducts);
			return listOfAllProducts;
		}
	}

	private Optional<Product> retrieveProductDataFromHashMap(String productKey) throws JsonProcessingException {
		Map<String, String> productDataFromCache = jedis.hgetAll(productKey);
		log.debug("HashMap Product Data: {}", productDataFromCache);
		if (productDataFromCache.isEmpty()) {
			return Optional.empty();
		} else {
			return Optional.ofNullable(readerHelper.mapHashMapToProductResponse(productDataFromCache));
		}
	}
}
