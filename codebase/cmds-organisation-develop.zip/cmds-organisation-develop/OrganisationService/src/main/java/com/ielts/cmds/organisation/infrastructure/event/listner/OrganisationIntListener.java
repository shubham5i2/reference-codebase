/** */
package com.ielts.cmds.organisation.infrastructure.event.listner;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.serialization.application.service.ApplicationServiceFactory;
import com.ielts.cmds.serialization.application.service.ApplicationServiceFactoryV2;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.infra.AbstractListener;
import com.ielts.cmds.serialization.utils.BaseEventExtractor;
import com.ielts.cmds.serialization.utils.CmdsLoggerInitializer;
import com.ielts.cmds.serialization.utils.CmdsLoggerInitializerV2;
import com.ielts.cmds.serialization.utils.EventBodyExtractor;
import com.ielts.cmds.serialization.utils.MessageVersionIdentifier;

import lombok.extern.slf4j.Slf4j;



/**
 * @author vedire
 */
@Slf4j
@Service
public class OrganisationIntListener extends AbstractListener<BaseHeader> {

  public OrganisationIntListener(
      ObjectMapper mapper,
      EventBodyExtractor extractEventBody,
      BaseEventExtractor extractBaseEvent,
      CmdsLoggerInitializerV2 initializeCmdsLogger,
      CmdsLoggerInitializer initializeCmdsLoggerV1,
      MessageVersionIdentifier identifyVersion,
      ApplicationServiceFactoryV2 applicationServiceFactoryV2,
      ApplicationServiceFactory applicationServiceFactory,
      CMDSThreadLocalContextService service) {
    super(
            mapper,
        extractEventBody,
        extractBaseEvent,
        initializeCmdsLogger,
        initializeCmdsLoggerV1,
        identifyVersion,
        applicationServiceFactoryV2,
        applicationServiceFactory,
            service);
  }

  /**
   * This method is to accept sqsmessage from RO-Int queue.
   *
   * @param message
   */
  @JmsListener(destination = "${aws.sqs.ro-int-queue-in.name}")
  public void on(Message<String> message) {

    onReceive(message.getHeaders(), message.getPayload());
  }

}
