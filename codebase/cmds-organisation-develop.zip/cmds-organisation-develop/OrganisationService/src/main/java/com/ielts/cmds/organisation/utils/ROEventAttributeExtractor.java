package com.ielts.cmds.organisation.utils;

import static com.ielts.cmds.organisation.utils.OrganisationConstants.GenericConstants.RO_DATA_FILE;

import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.outbox.event.v1.EventAttributeExtractor;
import com.ielts.cmds.outbox.event.model.OutboxEventAttribute;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

@Component
public class ROEventAttributeExtractor implements EventAttributeExtractor {
    @Override
    public List<OutboxEventAttribute> apply(final BaseEvent<? extends BaseHeader> event) {
        List<OutboxEventAttribute> eventAttributes = new ArrayList<>();

        eventAttributes.add(
                OutboxEventAttribute.builder()
                        .attributeKey(OrganisationConstants.GenericConstants.EVENT_NAME)
                        .attributeValue(event.getEventHeader().getEventName())
                        .build());

        if (event.getEventHeader() instanceof UiHeader
                && !StringUtils.isEmpty(((UiHeader) event.getEventHeader()).getConnectionId())) {
            eventAttributes.add(
                    OutboxEventAttribute.builder()
                            .attributeKey(OrganisationConstants.GenericConstants.CONNECTION_ID)
                            .attributeValue(((UiHeader) event.getEventHeader()).getConnectionId())
                            .build());
        }
        if (!StringUtils.isEmpty(event.getEventHeader().getPartnerCode())) {
            eventAttributes.add(
                    OutboxEventAttribute.builder()
                            .attributeKey(OrganisationConstants.GenericConstants.PARTNER_CODE)
                            .attributeValue(event.getEventHeader().getPartnerCode())
                            .build());
        }
        if (event.getEventHeader().getEventDiscriminator() != null) {
            eventAttributes.add(
                    OutboxEventAttribute.builder()
                            .attributeKey(
                                    OrganisationConstants.GenericConstants.EVENT_DISCRIMINATOR)
                            .attributeValue(event.getEventHeader().getEventDiscriminator())
                            .build());
        }
        if (event.getEventHeader().getEventContext() != null
                && event.getEventHeader().getEventContext().containsKey(RO_DATA_FILE)) {
            eventAttributes.add(
                    OutboxEventAttribute.builder()
                            .attributeKey(OrganisationConstants.GenericConstants.CSV_FILE)
                            .attributeValue(
                                    event.getEventHeader().getEventContext().get(RO_DATA_FILE))
                            .build());
        }
        return eventAttributes;
    }
}
