package com.ielts.cmds.organisation.utils;

import static com.ielts.cmds.organisation.utils.OrganisationConstants.GenericConstants.SIMILARITY;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.ListJoin;
import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.ielts.cmds.api.roui005rosearchrequested.RoSearchCriteria;
import com.ielts.cmds.organisation.infrastructure.entity.Address;
import com.ielts.cmds.organisation.infrastructure.entity.Contact;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
@Component
public class SearchRemaningCriteriaSpecificationUtil {
	 /**
     * Method to get {@link Specification} for the given {@link RoSearchCriteria} and {@link
     * ListJoin} of {@link Address} and {@link RecognisingOrganisation}
     *
     * @param roSearchCriteria
     * @param joinAddress
     * @return
     */
	public Specification<RecognisingOrganisation> criteriaMatches(
            final RoSearchCriteria roSearchCriteria,
            final ListJoin<RecognisingOrganisation, Address> joinAddress) {

        return (recognisingOrganisation, query, criteriaBuilder) -> {
            ListJoin<RecognisingOrganisation, Contact> joinContact =
                    recognisingOrganisation.joinList("contacts", JoinType.LEFT);
            List<Predicate> partialMatchPredicateList = new ArrayList<>();
            if (!StringUtils.isEmpty(roSearchCriteria.getContactName())) {
                Predicate firstNamePredicate =
                        criteriaBuilder.greaterThanOrEqualTo(
                                criteriaBuilder.function(
                                        SIMILARITY,
                                        Double.class,
                                        joinContact.get("firstName"),
                                        criteriaBuilder.literal(
                                                roSearchCriteria.getContactName())),
                                criteriaBuilder.literal(0.5));
                Predicate lastNamePredicate =
                        criteriaBuilder.greaterThanOrEqualTo(
                                criteriaBuilder.function(
                                        SIMILARITY,
                                        Double.class,
                                        joinContact.get("lastName"),
                                        criteriaBuilder.literal(
                                                roSearchCriteria.getContactName())),
                                criteriaBuilder.literal(0.5));
                partialMatchPredicateList.add(
                        criteriaBuilder.or(firstNamePredicate, lastNamePredicate));
            }
            if (!StringUtils.isEmpty(roSearchCriteria.getContactEmail())) {
                partialMatchPredicateList.add(
                        criteriaBuilder.greaterThanOrEqualTo(
                                criteriaBuilder.function(
                                        SIMILARITY,
                                        Double.class,
                                        joinAddress.get("email"),
                                        criteriaBuilder.literal(
                                                roSearchCriteria.getContactEmail())),
                                criteriaBuilder.literal(0.5)));
            }
            Predicate[] partialMatchPredicates = new Predicate[partialMatchPredicateList.size()];
            query.distinct(true);
            return criteriaBuilder.and(partialMatchPredicateList.toArray(partialMatchPredicates));
        };
    }

}
