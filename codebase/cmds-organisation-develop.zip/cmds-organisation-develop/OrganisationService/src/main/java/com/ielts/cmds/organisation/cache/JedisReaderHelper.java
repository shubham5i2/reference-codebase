package com.ielts.cmds.organisation.cache;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.organisation.cache.constants.ProductDataReadCacheConstants;
import com.ielts.cmds.organisation.cache.entity.Module;
import com.ielts.cmds.organisation.cache.entity.Product;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

@Component
public class JedisReaderHelper {

	public Product mapHashMapToProductResponse(Map<String, String> productDataFromCache) throws JsonProcessingException {

		Product product = new Product();
		Optional.ofNullable(productDataFromCache.get(ProductDataReadCacheConstants.PRODUCT_UUID))
				.ifPresent(productUuid -> product.setProductUuid(UUID.fromString(productUuid)));
		Optional.ofNullable(productDataFromCache.get(ProductDataReadCacheConstants.PARENT_PRODUCT_UUID))
				.ifPresent(parentProductUuid -> product.setParentProductUuid(UUID.fromString(parentProductUuid)));
		product.setLegacyProductId(productDataFromCache.get(ProductDataReadCacheConstants.LEGACY_PRODUCT_ID));
		product.setName(productDataFromCache.get(ProductDataReadCacheConstants.NAME));
		product.setDescription(productDataFromCache.get(ProductDataReadCacheConstants.DESCRIPTION));
		product.setProductCharacteristics(
				productDataFromCache.get(ProductDataReadCacheConstants.PRODUCT_CHARACTERISTICS));
		Optional.ofNullable(productDataFromCache.get(ProductDataReadCacheConstants.BOOKABLE))
				.ifPresent(bookable -> product.setBookable(Boolean.valueOf(bookable)));
		product.setComponent(productDataFromCache.get(ProductDataReadCacheConstants.COMPONENT));
		Optional.ofNullable(productDataFromCache.get(ProductDataReadCacheConstants.DURATION))
				.ifPresent(duration -> product.setDuration(Integer.parseInt(duration)));
		product.setFormat(productDataFromCache.get(ProductDataReadCacheConstants.FORMAT));
		Optional.ofNullable(productDataFromCache.get(ProductDataReadCacheConstants.APPROVAL_REQUIRED))
				.ifPresent(approvalRequired -> product.setApprovalRequired(Boolean.valueOf(approvalRequired)));
		Optional.ofNullable(productDataFromCache.get(ProductDataReadCacheConstants.AVAILABLE_FROM_DATE))
				.ifPresent(availableFromDate -> product.setAvailableFrom(LocalDate.parse(availableFromDate)));
		Optional.ofNullable(productDataFromCache.get(ProductDataReadCacheConstants.AVAILABLE_TO_DATE))
				.ifPresent(availableToDate -> product.setAvailableTo(LocalDate.parse(availableToDate)));

		if (productDataFromCache.get(ProductDataReadCacheConstants.MODULE) != null) {
			Module module = new ObjectMapper().readValue(productDataFromCache.get(ProductDataReadCacheConstants.MODULE),
					Module.class);
			product.setModule(module);
		}

		return product;
	}
}
