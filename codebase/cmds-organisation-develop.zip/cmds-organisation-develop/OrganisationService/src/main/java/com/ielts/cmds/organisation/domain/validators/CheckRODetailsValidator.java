package com.ielts.cmds.organisation.domain.validators;

import com.ielts.cmds.api.roui007rocreaterequested.MethodOfDeliveryEnum;
import com.ielts.cmds.api.roui007rocreaterequested.VerificationStatusEnum;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreateAddress;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreateContact;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreateLinkedOrganisation;
import com.ielts.cmds.api.roui007rocreaterequested.LinkTypeEnum;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreateMinimumScore;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateContact;
import com.ielts.cmds.organisation.domain.model.RoDataCreateV1Valid;
import com.ielts.cmds.organisation.domain.validators.validations.ValidateOrgDetails;
import com.ielts.cmds.organisation.infrastructure.entity.AddressType;
import com.ielts.cmds.organisation.infrastructure.entity.ContactType;
import com.ielts.cmds.organisation.infrastructure.entity.OrganisationType;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.AddressRepository;
import com.ielts.cmds.organisation.infrastructure.repository.AddressTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.ContactTypeRepository;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Slf4j
@Component
public class CheckRODetailsValidator extends CheckOrganisationDetailsValidator
        implements ConstraintValidator<ValidateOrgDetails, RoDataCreateV1Valid> {

    @Autowired private ContactTypeRepository contactTypeRepository;

    @Autowired private AddressTypeRepository addressTypeRepository;

    @Autowired private AddressRepository addressRepository;

    @Override
    public boolean isValid(RoDataCreateV1Valid orgDetails, ConstraintValidatorContext context) {

        context.disableDefaultConstraintViolation();

        boolean isValidOrgDetails = true;
        final UUID organisationTypeUuid = orgDetails.getOrganisationTypeUuid();
        Optional<OrganisationType> organisationType =
                orgTypeRepository.findById(organisationTypeUuid);
        if (!organisationType.isPresent()) {
            isValidOrgDetails = false;
            log.debug("Organisation Type is not valid");
            addConstraintViolation(
                    context, "{cmds.invalid.organisationTypeUuid}", "organisationTypeUuid");
        } else {
            /*
             * If OrganisationType is Recognising Organisation then make a call to RO
             * Validations Method.
             */
            if (OrganisationConstants.GenericConstants.RECOGNISING_ORGANISATION.equals(
                    organisationType.get().getOrganisationsType())) {
                isValidOrgDetails = isValidRO(orgDetails, context);
            } else {
                /*
                 * If OrganisationType is Verified Organisation then make a call to VO
                 * Validations Method.
                 */
                isValidOrgDetails = isValidVO(orgDetails, context);
            }
        }
        return isValidOrgDetails;
    }

    private boolean isValidOrganisationNameForCreate(
            RoDataCreateV1Valid orgDetails, ConstraintValidatorContext context) {
        boolean isValidOrganisationNameForCreate = true;

        if (recognisingOrganisationRepository.existsByNameIgnoreCaseAndSoftDeletedFalse(
                        orgDetails.getOrganisationName())) {
            log.debug("Organisation already present with this names");
            isValidOrganisationNameForCreate = false;
            addConstraintViolation(
                    context, "{cmds.duplicate.organisationName}", "organisationName");
        }
        return isValidOrganisationNameForCreate;
    }

    /**
     * Method to validate ALL the VO related Validations.
     *
     * @param orgDetails
     * @param context
     * @return
     */
    private boolean isValidVO(RoDataCreateV1Valid orgDetails, ConstraintValidatorContext context) {

        boolean isValidVoDetails = isValidOrganisationNameForCreate(orgDetails, context);

        isValidVoDetails = checkAllCommonFieldsForROVO(orgDetails, context, isValidVoDetails);
        isValidVoDetails =
                isValidVOVerificationStatusEnum(
                        VerificationStatusEnum.valueOf(orgDetails.getVerificationStatus().getValue()), context, isValidVoDetails);
        isValidVoDetails =
                isValidVOMethodOfDeliveryEnum(
                        MethodOfDeliveryEnum.valueOf(orgDetails.getMethodOfDelivery().name()), context, isValidVoDetails);
        isValidVoDetails =
                isValidResultsAvailableForYears(
                        orgDetails.getResultAvailableForYears(), context, isValidVoDetails);
        isValidVoDetails = isValidLinkedOrganisations(orgDetails, context, isValidVoDetails);
        return isValidVoDetails;
    }

    public boolean checkAllCommonFieldsForROVO(
            RoDataCreateV1Valid orgDetails, ConstraintValidatorContext context, boolean isValid) {

        isValid = isEmptyOrganisationName(orgDetails.getOrganisationName(), context, isValid);
        isValid = isValidPartnerCode(orgDetails.getPartnerCode(), context, isValid);
        isValid = isValidSectorType(orgDetails.getSectorTypeUuid(), context, isValid);
        isValid = isValidAddress(orgDetails.getAddresses(), context, isValid);
        isValid = isValidMinimumScores(orgDetails.getMinimumScores(), context, isValid);
        isValid = isValidProductAcceptanceFlags(orgDetails.getAcceptsAC(), orgDetails.getAcceptsGT(), context, isValid);
        return isValid;
    }

    /**
     * Method to validate ALL RO related validations.
     *
     * @param orgDetails
     * @param context
     * @return
     */
    private boolean isValidRO(RoDataCreateV1Valid orgDetails, ConstraintValidatorContext context) {

        boolean isValidRoDetails = isValidOrganisationNameForCreate(orgDetails, context);
        isValidRoDetails = checkAllCommonFieldsForROVO(orgDetails, context, isValidRoDetails);
        isValidRoDetails =
              isValidROMethodOfDeliveryEnum(
                  orgDetails.getMethodOfDelivery(),
                  context,
                  isValidRoDetails);
        isValidRoDetails = isValidWebsiteUrl(orgDetails.getWebsiteUrl(), context, isValidRoDetails);
        isValidRoDetails = isValidContact(orgDetails, context, isValidRoDetails);
        isValidRoDetails = isValidLinkedOrganisations(orgDetails, context, isValidRoDetails);
        isValidRoDetails =
                isValidResultsAvailableForYears(
                        orgDetails.getResultAvailableForYears(), context, isValidRoDetails);
        return isValidRoDetails;
    }

    private boolean isValidProductAcceptanceFlags(Boolean acceptsAC, Boolean acceptsGT, ConstraintValidatorContext context, boolean isValidRoDetails) {
        final boolean acFalseGtFalse = Boolean.FALSE.equals(acceptsAC) && Boolean.FALSE.equals(acceptsGT);
        if(acFalseGtFalse || (acceptsAC == null && acceptsGT == null)
        ||(acceptsAC == null && Boolean.FALSE.equals(acceptsGT)) || (Boolean.FALSE.equals(acceptsAC) && acceptsGT == null)){
            isValidRoDetails = false;
            log.debug("acceptsAC or acceptsGT any one of two must be true");
            addConstraintViolation(
                    context,
                    "{cmds.invalid.productAcceptance}",
                    OrganisationConstants.GenericConstants.PRODUCT_ACCEPTANCE);
        }
        return isValidRoDetails;
    }

    public boolean isValidLinkedOrganisations(
            RoDataCreateV1Valid orgDetails,
            ConstraintValidatorContext context,
            boolean isValidRoDetails) {

        List<RoDataCreateLinkedOrganisation> linkedOrganisations = orgDetails.getLinkedOrganisations();
        if (linkedOrganisations != null) {
            for (RoDataCreateLinkedOrganisation linkedOrg : linkedOrganisations) {
                isValidRoDetails =
                        checkLinkedOrganisationValidation(
                                orgDetails.getOrganisationTypeUuid(),
                                linkedOrg.getTargetRecognisingOrganisationUuid(),
                                LinkTypeEnum.valueOf(linkedOrg.getLinkType().getValue()),
                                context,
                                isValidRoDetails);
                isValidRoDetails =
                        checkEffectiveFromDate(
                                linkedOrg.getLinkEffectiveFromDateTime(),
                                linkedOrg.getLinkEffectiveToDateTime(),
                                context,
                                isValidRoDetails,
                                OrganisationConstants.GenericConstants
                                        .LINKED_ORGANISATIONS_PROPERTY_NODE);
            }
            if (linkedOrganisations.stream()
                            .filter(
                                    linkedOrg ->
                                            LinkTypeEnum.PARENT_RO==linkedOrg.getLinkType())
                            .count()
                    > 1) {
                isValidRoDetails = false;
                log.debug("Any RO can have only one Parent Organisation");
                addConstraintViolation(
                        context,
                        "{cmds.invalid.linkedRecognisingOrganisationType}",
                        OrganisationConstants.GenericConstants.LINKED_ORGANISATIONS_PROPERTY_NODE);
            }
        }
        return isValidRoDetails;
    }

    public boolean isValidMinimumScores(
            List<RoDataCreateMinimumScore> minimumScores,
            ConstraintValidatorContext context,
            boolean isValidRoVoDetails) {
        if (minimumScores != null) {
            for (RoDataCreateMinimumScore minScore : minimumScores) {
                isValidRoVoDetails =
                        isValidModuleTypeUuid(
                                minScore.getModuleTypeUuid(), context, isValidRoVoDetails);
            }
        }
        return isValidRoVoDetails;
    }

    /**
     * Method to check Address Related Validations.
     *
     * @param roDataCreateAddress
     * @param context
     * @param isValidAddress
     * @return
     */
    public boolean isValidAddress(
            List<RoDataCreateAddress> roDataCreateAddress,
            ConstraintValidatorContext context,
            boolean isValidAddress) {
        int mainAddressCount = 0;
        int deliveryAddressCount = 0;
        for (RoDataCreateAddress address : roDataCreateAddress) {
          
                Optional<AddressType> optAddress =
                        addressTypeRepository.findById(address.getAddressTypeUuid());
                if (!optAddress.isPresent()) {
                    isValidAddress = false;
                    log.debug("Address Type is not valid");
                    addConstraintViolation(
                            context,
                            "{cmds.invalid.addressTypeName}",
                            OrganisationConstants.GenericConstants.ADDRESS_PROPERTY_NODE);
                } else {
                    isValidAddress =
                            addressCheck(
                                    address,
                                    optAddress.get().getAddressTypeName(),
                                    context,
                                    isValidAddress);
                    mainAddressCount =
                            countMainAddress(
                                    optAddress.get().getAddressTypeName(), mainAddressCount);
                    deliveryAddressCount =
                            countDeliveryAddress(
                                    optAddress.get().getAddressTypeName(), deliveryAddressCount);
                }
            
        }
        isValidAddress =
                checkMainAndDeliveryAddress(
                        mainAddressCount, deliveryAddressCount, context, isValidAddress);
        return isValidAddress;
    }

    private boolean addressCheck(
            RoDataCreateAddress address,
            String addressTypeName,
            ConstraintValidatorContext context,
            boolean isValidAddress) {
        isValidAddress =
                mandatoryAddressLineCheck(
                        address.getAddressLine1(), addressTypeName, context, isValidAddress);
        isValidAddress =
                mandatoryCityCheck(address.getCity(), addressTypeName, context, isValidAddress);
        isValidAddress =
                isValidCountry(address.getCountryUuid(), addressTypeName, context, isValidAddress);
        isValidAddress =
                isValidTerritory(
                        address.getTerritoryUuid(), addressTypeName, context, isValidAddress);
        return isValidAddress;
    }

    /**
     * Method to Validate Contacts Validations.
     *
     * @param orgDetails
     * @param context
     * @return
     */
    public boolean isValidContact(
            RoDataCreateV1Valid orgDetails,
            ConstraintValidatorContext context,
            boolean isValidContact) {
        int primaryContactCount = 0;
        int resultsAdminContactCount = 0;
        for (RoDataCreateContact contact : orgDetails.getContacts()) {
            Optional<ContactType> contactType = Optional.empty();
            if (Objects.nonNull(contact)) {
                contactType = contactTypeRepository.findById(contact.getContactTypeUuid());
            }
            if (contactType.isPresent()) {
                String contactName = contactType.get().getContactsType();
                isValidContact = checkContactBasedOnVerificationStatus( contactName, contact, context, isValidContact, orgDetails);
                primaryContactCount = checkPrimaryContact(contactName, primaryContactCount);
                resultsAdminContactCount =
                        checkResultsAdminContact(contactName, resultsAdminContactCount);

                isValidContact =
                            checkEmailForPrimaryOrResultAdminContact(
                                    contact.getAddresses(), contactName, context, isValidContact, orgDetails.getVerificationStatus().getValue());
            } else {
                isValidContact = false;
                log.debug("Contact Type is not valid");
                addConstraintViolation(
                        context,
                        "{cmds.invalid.contacts}",
                        OrganisationConstants.GenericConstants.CONTACTS_PROPERTY_NODE);
            }
        }
        isValidContact =
                checkPrimaryandResultsAdminContact(
                        primaryContactCount, resultsAdminContactCount, context, isValidContact);
        return isValidContact;
    }
    private boolean checkContactBasedOnVerificationStatus(String contactName,
                                                          RoDataCreateContact contact,
                                                          ConstraintValidatorContext context,
                                                          boolean isValidContact,
                                                          RoDataCreateV1Valid orgDetails){
        if (VerificationStatusEnum.VERIFIED == orgDetails.getVerificationStatus()
                && Objects.equals(contactName, OrganisationConstants.GenericConstants.RESULT_ADMIN)){
            isValidContact = true;

        }else{
            isValidContact =
                    isEmptyKnownName(
                            contact.getFirstName(),
                            contact.getLastName(),
                            context,
                            contactName,
                            isValidContact);
        }
        return isValidContact;
    }
    /**
     * Method to validate Email for Primary and ResultsAdmin Contacts.
     *
     * @param addresses
     * @param contactName
     * @param context
     * @param isValidContact
     * @return
     */
    private boolean checkEmailForPrimaryOrResultAdminContact(
            List<RoDataCreateAddress> addresses,
            String contactName,
            ConstraintValidatorContext context,
            boolean isValidContact,
            String verificationStatus) {
        if (OrganisationConstants.GenericConstants.PRIMARY_CONTACT.equals(contactName)
                || OrganisationConstants.GenericConstants.RESULT_ADMIN.equals(contactName)) {
            isValidContact = checkEmail(addresses, contactName, context, isValidContact, verificationStatus);
        }
        return isValidContact;
    }

    /**
     * Method to validate Email for Primary and ResultsAdmin Contacts.
     *
     * @param addresses
     * @param contactTypeName
     * @param context
     * @param isValidContact
     * @return
     */
    private boolean checkEmail(
            List<RoDataCreateAddress> addresses,
            String contactTypeName,
            ConstraintValidatorContext context,
            boolean isValidContact,
            String verificationStatus) {
        if (addresses != null) {
            for (RoDataCreateAddress address : addresses) {
                isValidContact =
                        isValidEmail(address.getEmail(), contactTypeName, context, isValidContact, verificationStatus);
                isValidContact =
                        isUniqueEmail(address.getEmail(), contactTypeName, context, isValidContact);

            }
        }
        return isValidContact;
    }

    protected boolean isUniqueEmail(
            String email,
            String contactTypeName,
            ConstraintValidatorContext context,
            boolean isValidContact) {
        if ((OrganisationConstants.GenericConstants.RESULT_ADMIN.equals(contactTypeName))
                && (!addressRepository
                        .findByEmailAndContactContactUuidIsNotNull(email)
                        .isEmpty())
                && Objects.nonNull(email)) {
            isValidContact = false;
            log.debug("RO Admin email address must be unique");
            addConstraintViolation(
                    context,
                    "{cmds.invalid.email.Duplicate}",
                    OrganisationConstants.GenericConstants.ADDRESS_PROPERTY_NODE);
        }

        return isValidContact;
    }
}
