package com.ielts.cmds.organisation.infrastructure.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.ielts.cmds.api.roui007rocreaterequested.LinkTypeEnum;
import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.hibernate.annotations.Type;

@Data
@EqualsAndHashCode(
        callSuper = true,
        exclude = {"sourceRecognisingOrganisation", "targetRecognisingOrganisation"})
@Entity(name = "linked_recognising_organisation")
@ToString(exclude = {"sourceRecognisingOrganisation", "targetRecognisingOrganisation"})
public class LinkedRecognisingOrganisation extends Model implements Serializable {
    /** */
    private static final long serialVersionUID = 791404692061249590L;

    @Id
    @GeneratedValue
    @Column(name = "linked_recognising_organisation_uuid", nullable = false)
    @Type(type = "uuid-char")
    private UUID linkedRecognisingOrganisationUuid;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "source_recognising_organisation_uuid", nullable = false)
    @JsonManagedReference
    private RecognisingOrganisation sourceRecognisingOrganisation;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "target_recognising_organisation_uuid", nullable = false)
    @JsonManagedReference
    private RecognisingOrganisation targetRecognisingOrganisation;

    @Column(name = "linked_recognising_organisation_type")
    @Enumerated(EnumType.STRING)
    private LinkTypeEnum linkedRecognisingOrganisationType;

    @Column(name = "organisation_hierarchy_label")
    private String organisationHierarchyLabel;
}
