package com.ielts.cmds.organisation.domain.services;

import java.util.List;
import java.util.Locale;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;
import javax.validation.ValidationException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.ielts.cmds.api.roui005rosearchrequested.RoSearchObject;
import com.ielts.cmds.organisation.infrastructure.entity.RODuplicateExactSearchResult;
import com.ielts.cmds.organisation.infrastructure.entity.RODuplicateFuzzySearchResult;
import com.ielts.cmds.organisation.utils.DuplicateSearchRoEntityToEventMapper;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.api.service.impl.RBACServiceImpl;

import lombok.extern.slf4j.Slf4j;

/** @author CTS */
@Service
@Slf4j
public class DuplicateSearchOrganisationDomainService extends AbstractCMDSDomainService<RosSearchResultsGeneratedEventV1>  {

	@Autowired
	private RBACServiceImpl rbacServiceImpl;

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private DuplicateSearchRoEntityToEventMapper duplicateSearchRoEntityToEventMapper;

	@Autowired
	private SearchOrganisationDomainService searchOrganisationDomainService;

	@Autowired private OrganisationCommonUtils orgUtils;

	@Autowired
	protected DuplicateSearchOrganisationDomainService(ApplicationEventPublisher publisher, ObjectMapper objectMapper, @Value("${duplicateSearchOrganisationDomain.v2}") String isV2Enabled, CMDSThreadLocalContextService cmdsThreadLocalContextService) {
		super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
	}

	/**
	 * Method to process {@link RoSearchObject} command object
	 *
	 * @param roSearchObject
	 * @throws RbacValidationException
	 */
	@Transactional
	public void onCommand(final RoSearchObject roSearchObject) throws RbacValidationException {
		log.debug("Event Body: {}", roSearchObject);
		if (rbacServiceImpl.isAuthorised(ThreadLocalHeaderContext.getContext().getXaccessToken(),
				OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION)) {
			try {

				if (Boolean.TRUE.equals(roSearchObject.getCriteria().getFuzzyMatch())) {

					log.debug("searching Fuzzy match : {}", roSearchObject);
	                StoredProcedureQuery query =
	                        entityManager.createNamedStoredProcedureQuery("getFuzzySearchResults");
	                query.setParameter("_org_name", roSearchObject.getCriteria().getOrganisationName());
	                query.setParameter("_city_name", roSearchObject.getCriteria().getCity());
	                query.setParameter("_postal_code", roSearchObject.getCriteria().getPostalCode());

	                // Execute query
	                query.execute();
	                List<RODuplicateFuzzySearchResult> fetchedOrganisationList = query.getResultList();
                    searchOrganisationDomainService.publishSearchRoResponse(
	                        duplicateSearchRoEntityToEventMapper.mapEntityToEventForFuzzySearch(roSearchObject, fetchedOrganisationList),
							orgUtils.buildUiHeader(),
	                      	orgUtils.getBaseAudit());
	                log.debug("Fetched List Size :{}", fetchedOrganisationList.size());

				} else {

					log.debug("searching Full text match : {}", roSearchObject);
					StoredProcedureQuery query = entityManager.createNamedStoredProcedureQuery("getExactSearchResults");

					query.setParameter("_org_name",
							(roSearchObject.getCriteria().getOrganisationName() != null)
									? ("%" + roSearchObject.getCriteria().getOrganisationName().toLowerCase(Locale.ENGLISH) + "%")
									: "NULL");

					query.setParameter("_city_name",
							(roSearchObject.getCriteria().getCity() != null)
									? ("%" + roSearchObject.getCriteria().getCity().toLowerCase(Locale.ENGLISH) + "%")
									: "NULL");

					query.setParameter("_postal_code", roSearchObject.getCriteria().getPostalCode());

					// Execute query
					query.execute();

					List<RODuplicateExactSearchResult> fetchedOrganisationList = query.getResultList();
					searchOrganisationDomainService.publishSearchRoResponse(
							duplicateSearchRoEntityToEventMapper.mapEntityToEventForFullTextSearch(roSearchObject, fetchedOrganisationList),
							orgUtils.buildUiHeader(),
							orgUtils.getBaseAudit());
							log.debug("Fetched List Size :{}", fetchedOrganisationList.size());

				}
			} catch (Exception e) {
				log.error("Exception in Duplicate Search Organisation Domain Service:  ", e);
				throw e;
			}
		} else {
			log.error(
					"Cannot Perform Search. User should be authorised and should have atleast one of the search criteria");
			throw new ValidationException(OrganisationConstants.ErrorResponse.CANNOT_PERFORM_SEARCH);
		}
	}
}
