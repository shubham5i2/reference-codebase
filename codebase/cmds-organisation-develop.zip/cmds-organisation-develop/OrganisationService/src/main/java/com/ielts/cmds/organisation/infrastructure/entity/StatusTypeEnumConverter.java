package com.ielts.cmds.organisation.infrastructure.entity;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import java.util.stream.Stream;

import com.ielts.cmds.organisation.common.enums.StatusTypeEnum;

@Converter(autoApply = true)
public class StatusTypeEnumConverter implements AttributeConverter<StatusTypeEnum, String> {

	@Override
    public String convertToDatabaseColumn(StatusTypeEnum statusTypeEnum) {
        if (statusTypeEnum == null) {
            return null;
        }
        return statusTypeEnum.getValue();
    }

    @Override
    public StatusTypeEnum convertToEntityAttribute(String statusType) {
        if (statusType == null) {
            return null;
        }

        return Stream.of(StatusTypeEnum.values())
                .filter(statusTypeEnum -> statusTypeEnum.getValue().equals(statusType))
                .findFirst()
                .orElseThrow(IllegalArgumentException::new);
    }

}
