package com.ielts.cmds.organisation.domain.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.roui005rosearchrequested.RoSearchObject;
import com.ielts.cmds.api.roui005rosearchrequested.SearchPagination;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1;
import com.ielts.cmds.api.roui005rosearchrequested.RoSearchCriteria;
import com.ielts.cmds.api.roui005rosearchrequested.SearchSortItem;
import com.ielts.cmds.organisation.domain.validators.SearchRoCriteriaValidator;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.SearchOrganisationRepository;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.organisation.utils.SearchCriteriaSpecificationUtil;
import com.ielts.cmds.organisation.utils.SearchRoEntityToEventMapper;
import com.ielts.cmds.outbox.event.OutboxEventBuilder;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.api.service.impl.RBACServiceImpl;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.validation.ValidationException;

import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Order;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** @author CTS */
@Service
@Slf4j
public class SearchOrganisationDomainService extends AbstractCMDSDomainService<RosSearchResultsGeneratedEventV1>  {

    @Autowired private RBACServiceImpl rbacServiceImpl;

    @Autowired private SearchRoCriteriaValidator searchRoCriteriaValidator;

    @Autowired private SearchOrganisationRepository searchOrganisationRepository;

    @Autowired private SearchCriteriaSpecificationUtil searchCriteriaSpecificationUtil;

    @Autowired private SearchRoEntityToEventMapper searchRoEntityToEventMapper;

    @Autowired private ObjectMapper objectMapper;

    @Autowired private ApplicationEventPublisher applicationEventPublisher;

    @Autowired private OutboxEventBuilder outboxEventBuilder;

    @Autowired private OrganisationCommonUtils orgUtils;

    @Autowired
    protected SearchOrganisationDomainService(ApplicationEventPublisher publisher, ObjectMapper objectMapper, @Value("${searchOrganisationDomain.v2}") String isV2Enabled, CMDSThreadLocalContextService cmdsThreadLocalContextService) {
        super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
    }

    /**
     * Method to process {@link RoSearchObject} command object
     *
     * @param roSearchObject
     * @throws RbacValidationException
     */
    @Transactional
    public void onCommand(final RoSearchObject roSearchObject) throws RbacValidationException {
        log.debug("Event Body: {}", roSearchObject);
        if (rbacServiceImpl.isAuthorised(
                        ThreadLocalHeaderContext.getContext().getXaccessToken(),
                        OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION)
                && searchRoCriteriaValidator.isValid(roSearchObject)) {
            try {
                SearchPagination searchPagination = roSearchObject.getPagination();
                Pageable pageable =
                        PageRequest.of(
                                searchPagination.getPageNumber().intValue(),
                                searchPagination.getPageSize().intValue(),
                                Sort.by(getSortDirection(roSearchObject.getSorting())));

                Page<RecognisingOrganisation> fetchedOrganisationPage =
                        searchOrganisationRepository.findAll(
                                getSpecification(roSearchObject.getCriteria()), pageable);

                log.debug("Fetched List Size :{}", fetchedOrganisationPage.getTotalElements());
                publishSearchRoResponse(
                        searchRoEntityToEventMapper.mapEntityToEvent(
                                roSearchObject,
                                fetchedOrganisationPage.getContent(),
                                fetchedOrganisationPage.getTotalElements()),
                        orgUtils.buildUiHeader(),
                        orgUtils.getBaseAudit());
            } catch (Exception e) {
                log.error("Exception in Search Organisation Domain Service: {} ", e);
            }
        } else {
            log.error(
                    "Cannot Perform Search. User should be authorised and should have atleast one of the search criteria");
            throw new ValidationException(
                    OrganisationConstants.ErrorResponse.CANNOT_PERFORM_SEARCH);
        }
    }

    /**
     * Method to frame and publish event
     *
     * @param eventBody
     * @param eventHeaders
     */
    public void publishSearchRoResponse(
            RosSearchResultsGeneratedEventV1 eventBody, BaseHeader eventHeaders, BaseAudit audit) {
        eventHeaders.setEventName(OrganisationConstants.EventType.RO_SEARCH_RESULT_GENERATED_EVENT);
        eventHeaders.setEventDateTime(LocalDateTime.now(ZoneOffset.UTC));
        try {
            BaseEvent<BaseHeader> event =
                    new BaseEvent<>(
                            eventHeaders, objectMapper.writeValueAsString(eventBody), null, audit);

            applicationEventPublisher.publishEvent(event);
        } catch (JsonProcessingException exception) {
            throw new IllegalArgumentException(exception);
        }
    }

    /**
     * Method to get {@link Specification} for the given {@link RoSearchCriteria}
     *
     * @param roSearchCriteria
     * @return
     */
    public Specification<RecognisingOrganisation> getSpecification(
            final RoSearchCriteria roSearchCriteria) {

        return searchCriteriaSpecificationUtil.criteriaMatches(roSearchCriteria);
    }

    /**
     * Method to get {@link List} of {@link Order} based on the given {@link SearchSortItem}
     *
     * @param searchSortItems
     * @return
     */
    public List<Sort.Order> getSortDirection(final List<SearchSortItem> searchSortItems) {
        List<Sort.Order> sorts = new ArrayList<>();
        if (Objects.nonNull(searchSortItems)) {
            for (SearchSortItem sortItem : searchSortItems) {
                Sort.Direction sortDirection =
                        Sort.Direction.fromString(sortItem.getSortType().toUpperCase());
                sorts.add(new Sort.Order(sortDirection, sortItem.getSortBy()));
            }
        }
        return sorts;
    }
}
