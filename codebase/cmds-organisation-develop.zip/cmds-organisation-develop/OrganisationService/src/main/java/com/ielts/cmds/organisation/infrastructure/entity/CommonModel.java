package com.ielts.cmds.organisation.infrastructure.entity;

import java.io.Serializable;
import java.time.Instant;
import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Data
@EqualsAndHashCode(exclude = {"updatedDatetime", "createdDatetime"})
@NoArgsConstructor
@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
public class CommonModel implements Serializable {

    /** Generated SerialVersionID */
    private static final long serialVersionUID = -156453558926984718L;

    @Version
    @Column(name = "concurrency_version", precision = 10)
    protected int concurrencyVersion;

    @Column(name = "created_by", nullable = false, length = 36)
    @CreatedBy
    protected String createdBy;

    @Column(name = "created_datetime", nullable = false)
    @CreatedDate
    protected Instant createdDatetime;

    @Column(name = "updated_by", length = 36)
    @LastModifiedBy
    protected String updatedBy;

    @Column(name = "updated_datetime")
    @LastModifiedDate
    protected Instant updatedDatetime;
}
