package com.ielts.cmds.organisation.infrastructure.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;

@Configuration
public class CSVMapperConfig {
	
	@Bean
	public CsvMapper csvMapper() {
		CsvMapper csvMapper = new CsvMapper();
        csvMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        csvMapper.disable(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY);
        return csvMapper;
	}
}
