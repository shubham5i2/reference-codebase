package com.ielts.cmds.organisation.infrastructure.entity;

import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode(
        callSuper = true,
        exclude = {"recognisingOrganisation", "contact"})
@Entity(name = "address")
@ToString(exclude = {"recognisingOrganisation", "contact"})
public class Address extends CommonModel implements Serializable {

    /** Generated SerialVersionID */
    private static final long serialVersionUID = -5972072729124708197L;

    @Id
    @GeneratedValue
    @Column(columnDefinition = "uuid", name = "address_uuid")
    private UUID addressUuid;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "recognising_organisation_uuid")
    private RecognisingOrganisation recognisingOrganisation;

    @Column(columnDefinition = "uuid", name = "address_type_uuid", nullable = false)
    private UUID addressTypeUuid;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "contact_uuid")
    private Contact contact;

    @Column(columnDefinition = "uuid", name = "territory_uuid")
    private UUID territoryUuid;

    @Column(columnDefinition = "uuid", name = "country_uuid")
    private UUID countryUuid;

    @Column(name = "addressline1", length = 100)
    private String addressline1;

    @Column(name = "addressline2", length = 100)
    private String addressline2;

    @Column(name = "addressline3", length = 100)
    private String addressline3;

    @Column(name = "addressline4", length = 100)
    private String addressline4;

    @Column(name = "city", length = 100)
    private String city;

    @Column(name = "postalcode", length = 20)
    private String postalCode;

    @Column(name = "email", length = 320)
    private String email;

    @Column(name = "phone", length = 20)
    private String phone;
}
