package com.ielts.cmds.organisation.application;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.config.IBaseAuditService;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.domain.commands.UpdateROVO;
import com.ielts.cmds.organisation.domain.model.RoDataUpdateV1Valid;
import com.ielts.cmds.organisation.domain.services.UpdateOrganisationDomainService;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.serialization.application.service.IApplicationServiceV2;
import com.ielts.cmds.serialization.utils.ServiceIdentifier;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
@Slf4j
@ServiceIdentifier(OrganisationConstants.GenericConstants.RO_UPDATE_REQUEST_EVENT)
public class OrganisationUpdateService implements IApplicationServiceV2<RoDataUpdateV1Valid>, IBaseAuditService {

  @Autowired UpdateOrganisationDomainService updateOrgDomainService;

  /**
   * This method handles incoming requests and creates command to call domain service for further
   * processing
   *
   * @param cmdsEventBody
   */
  @SneakyThrows
  @Override
  public void process(final RoDataUpdateV1Valid cmdsEventBody) {

    try {
      log.debug(
              "Request with transactionId and event name as: {}, {}",
              ThreadLocalHeaderContext.getContext().getTransactionId(),
              ThreadLocalHeaderContext.getContext().getEventName());
      if (cmdsEventBody == null) {
        throw new IllegalArgumentException(
                OrganisationConstants.ErrorResponse.EMPTY_PAYLOAD);
      }
      populateAuditFields();
      // Execute command
      updateOrgDomainService.onCommand(cmdsEventBody);
    } catch (Exception e) {
      log.error("Exception while processing Request: ", e);
      throw new ProcessingException(e.getMessage(), e);
    }
  }

  @Override
  public String getPermission() {
    return OrganisationConstants.Permissions.ORG_UPDATE;
  }

  @Override
  public String getScreen() {
    return OrganisationConstants.Screen.UPDATE_ORGANISATION;
  }

  @Override
  public String getAction() {
    return UpdateROVO.class.getSimpleName();
  }
}
