package com.ielts.cmds.organisation.infrastructure.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ielts.cmds.organisation.infrastructure.entity.NoteType;

@Repository
public interface NoteTypeRepository extends JpaRepository<NoteType, UUID> {

	NoteType findByNotesType(String noteType);
}
