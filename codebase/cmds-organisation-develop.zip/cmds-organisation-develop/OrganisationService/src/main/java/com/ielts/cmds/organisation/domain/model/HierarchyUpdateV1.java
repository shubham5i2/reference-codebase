package com.ielts.cmds.organisation.domain.model;

import java.util.UUID;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode
@ToString
public class HierarchyUpdateV1 {

    private String oldHierarchyLabel;

    private String newHierarchyLabel;

    private UUID triggerRecognisingOrganisationUuid;

    private UUID recognisingOrganisationUuid;
}
