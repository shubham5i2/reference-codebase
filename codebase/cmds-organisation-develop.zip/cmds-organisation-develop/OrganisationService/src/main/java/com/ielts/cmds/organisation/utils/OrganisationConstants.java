package com.ielts.cmds.organisation.utils;

public final class OrganisationConstants {

    private OrganisationConstants(){
        throw new IllegalArgumentException("Organisation Constants");
    }
    public static final class Permissions {
        private Permissions() {
            throw new IllegalArgumentException("Permissions");
        }

        public static final String ORG_CREATE = "ORG_CREATE";
        public static final String ORG_UPDATE = "ORG_UPDATE";
        public static final String ORG_VIEW = "ORG_VIEW";
    }

    public static final class Screen {
        private Screen() {
            throw new IllegalArgumentException("Screen");
        }

        public static final String CREATE_ORGANISATION = "Create Organisation";
        public static final String UPDATE_ORGANISATION = "Update Organisation";
        public static final String VIEW_ORGANISATION = "View Organisation";
        public static final String SEARCH_ORGANISATION = "Search Organisation";
        public static final String SEARCH_ORGANISATION_BY_ID = "Search Organisation By ID";
        public static final String SEARCH_ORGANISATION_HIERARCHY = "Search Organisation Hierarchy";
    }

    public static final class EventType {
        private EventType() {
            throw new IllegalArgumentException("EventType");
        }

        public static final String RO_CREATED_EVENT = "RoCreated";
        public static final String RO_CREATE_REJECTED_EVENT = "RoRejected";

        public static final String RO_SEARCH_RESULT_GENERATED_EVENT = "RoSearchResultGenerated";
        public static final String RO_UPDATED_EVENT = "RoChanged";
        public static final String RO_UPDATE_REJECTED_EVENT = "RoChangeRejected";

        public static final String RO_VIEW_DETAILS_EVENT = "RoRequested";
        public static final String RO_VIEW_DETAILS_REJECTED_EVENT = "RoRequestRejected";

        public static final String RO_PROCESS_EVENT = "ROProcess";
        public static final String RO_DETAILS_DATA_GENERATED_EVENT = "RoDetailsDataGenerated";
        public static final String LOAD_RO_UPDATE_EVENT = "ROUpdate";
        public static final String RO_HIERARCHY_UPDATE_EVENT = "ROHierarchyUpdate";
    }

    public static final class ErrorResponse {
        private ErrorResponse() {
            throw new IllegalArgumentException("ExceptionErrorCodes");
        }

        public static final String EMPTY_PAYLOAD = "Payload is Empty";
        public static final String RO_INTERFACE_ERROR = "RO-MX";
        public static final String CANNOT_PERFORM_SEARCH =
                "User should be authorised and should have one of the "
                        + "search criteria to perform this operation";
    }

    public static final class GenericConstants {
        public static final String RECOGNISING_ORGANISATION_UUID = "recognisingOrganisationUuid";
        public static final String PARENT_RO_UUID = "parentROUuid";
        public static final String RECORD = "record";
        public static final String ONLY_IMMEDIATE_CHILDREN = "onlyImmediateChildren";
        public static final String OUTBOX_DELETE_EVENT = "OutboxDeleteEventRequested";

        public static final String RO_PROCESS_REQUEST_EVENT = "RoProcessRequest" ;
        public static final String RO_CREATE_REQUEST_EVENT = "RoCreateRequest" ;
        public static final String RO_UPDATE_REQUEST_EVENT = "RoUpdateRequest" ;
        public static final String RO_SEARCH_REQUEST_EVENT = "RoSearchRequest" ;
        public static final String RO_SEARCH_BY_ORG_ID_REQUEST_EVENT = "RoSearchByOrgIdRequest" ;
        public static final String RO_HIERARCHY_SEARCH_REQUEST_EVENT = "RoHierarchySearchRequest" ;
        public static final String RO_DETAILS_REQUEST_EVENT = "RoDetailsRequest" ;

        private GenericConstants() {
            throw new IllegalArgumentException("GenericConstants");
        }

        public static final String OPERATION_TYPE_GET = "GET";
        public static final String OPERATION_TYPE_POST = "POST";
        public static final String OPERATION_TYPE_PUT = "PUT";
        public static final String OPERATION_TYPE_DELETE = "DELETE";
        public static final String OPERATIONAL_USER = "OPS_USER";
        public static final String UPDATE_RO_RESOURCE_TYPE = "/v1/ros/{recognisingOrganisationUuid}";
        public static final String LOAD_RO_DATA_RESOURCE_TYPE = "/v1/ros/process";
        public static final String MSG_ATTR_DATA_TYPE = "String";
        public static final String CONNECTION_ID = "connectionId";
        public static final String EVENT_NAME = "eventName";
        public static final String EVENT_DISCRIMINATOR = "eventDiscriminator";
        public static final String PARTNER_CONTACT = "Partner Contact";
        public static final String ORGANISATION_NAME = "OrganisationName";
        public static final String ORGANISATION_TYPE = "OrganisationType";
        public static final String VERIFICATION_STATUS = "verificationStatus";
        public static final String RECOGNISING_ORGANISATION = "RO";
        public static final String VERIFIED_ORGANISATION = "VO";
        public static final String PRIMARY_CONTACT = "Primary";
        public static final String RESULT_ADMIN = "Results Admin";
        public static final String MAIN_ADDRESS_TYPE = "Main";
        public static final String DELIVERY_ADDRESS_TYPE = "Delivery";
        public static final String ADDRESS_PROPERTY_NODE = "addresses";
        public static final String PRODUCT_ACCEPTANCE = "acceptsAC";
        public static final String CONTACTS_PROPERTY_NODE = "contacts";
        public static final String RO_ORG_VIEW_PERMISSION = "RO_ORG_VIEW";
        public static final String SIMILARITY = "similarity";
        public static final String DUPLICATE_SEARCH_MODE = "duplicate";
        public static final String CREATE = "Create";
        public static final String UPDATE = "Update";
        public static final String CREATE_RO_PERMISSION_ID = "RO_ORG_CREATE";
        public static final String CREATE_VO_PERMISSION_ID = "VO_ORG_CREATE";
        public static final String UPDATE_RO_PERMISSION_ID = "RO_ORG_UPDATE";
        public static final String UPDATE_VO_PERMISSION_ID = "VO_ORG_UPDATE";
        public static final String RO_DESCRIPTION = "Recognising Organisation";
        public static final String VO_DESCRIPTION = "Verified Organisation";
        public static final String PARTNER_CODE = "partnerCode";
        public static final String RO_DATA_FILE = "roDataFile";
        public static final String RO = "RO";
        public static final String IELTS_DISPLAY_FLAG = "ieltsDisplayFlag";
        public static final String ORS_DISPLAY_FLAG = "orsDisplayFlag";
        public static final String LINKED_ORGANISATIONS_PROPERTY_NODE = "linkedOrganisations";
        public static final String MODE = "mode";
        public static final String CREATE_MODE = "create";
        public static final String UPDATE_MODE = "update";
        public static final String HIERARCHY_MODE = "hierarchy";
        public static final String ORGANISATION_ID = "organisationId";
        public static final String CSV_FILE = "csvFile";
        public static final String RESULT_AVAILABLE_FOR_YEARS = "resultAvailableForYears";
        public static final String DEFAULT_RESULT_AVAILABLE_FOR_YEARS = "3";
        public static final String OLD_HIERARCHY_LABEL = "oldHierarchyLabel";
        public static final String NEW_HIERARCHY_LABEL = "newHierarchyLabel";
        public static final String TRIGGER_RO_UUID = "triggerRecognisingOrganisationUuid";
        public static final String LOAD_ORGANISATION_TYPE = "organisationType";
        public static final String IOL = "IOL";
        public static final String IOC = "IOC";
        public static final String SSR = "SSR";
        public static final String AC = "AC";
        public static final String GT = "GT";
        public static final String ORGANISATION_PRIMMING_EVENT = "OrganisationPrimmingEvent";
        public static final String ADDRESS_TYPE_UUID = "addressTypeUuid";
        public static final String CONTACT = "contact";
        public static final String SOFT_DELETED = "softDeleted";
        public static final String ORGANISATION_STATUS= "orgStatus";
        public static final String ORGANISATION_TYPE_UUID= "organisationTypeUuid";
        public static final String CITY = "city";
        public static final String POSTAL_CODE = "postalCode";
        public static final String COUNTRY_UUID = "countryUuid";
        public static final String TERRITORY_UUID = "territoryUuid";
        public static final String CHARACTERISTICS = "characteristics";
        public static final String REQ_PARAM_INCLUDE_INACTIVE = "includeInactive";
    }
}
