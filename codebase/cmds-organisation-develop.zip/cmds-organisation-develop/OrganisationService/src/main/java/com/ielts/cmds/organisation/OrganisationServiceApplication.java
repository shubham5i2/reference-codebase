package com.ielts.cmds.organisation;

import com.ielts.cmds.outbox.configuration.EnableOutbox;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@ComponentScan({"com.ielts.cmds"})
@SpringBootApplication
@EnableJpaRepositories(
        basePackages = {
            "com.ielts.cmds.organisation.infrastructure.repository",
            "com.ielts.cmds.rbac",
            "com.ielts.cmds.outbox.infra.repository",
            "com.ielts.cmds.location.infrastructure.repository"
        })
@EntityScan(
        basePackages = {
            "com.ielts.cmds.organisation.infrastructure.entity",
                "com.ielts.cmds.organisation.cache",
            "com.ielts.cmds.rbac",
            "com.ielts.cmds.outbox.infra.entity",
            "com.ielts.cmds.location.infrastructure.model",
            "com.ielts.cmds.organisation.utils",
                "com.ielts.cmds.organisation.cache.entity"

        })
@EnableCaching
@EnableOutbox
public class OrganisationServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(OrganisationServiceApplication.class, args);
    }
}
