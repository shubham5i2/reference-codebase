package com.ielts.cmds.organisation.domain.validators.validations;

import com.ielts.cmds.organisation.domain.validators.CheckRODetailsValidator;
import com.ielts.cmds.organisation.domain.validators.CheckUpdateROVODetailsValidator;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;

@Constraint(validatedBy = {CheckRODetailsValidator.class, CheckUpdateROVODetailsValidator.class})
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
public @interface ValidateOrgDetails {

    public String message() default "";

    public Class<?>[] groups() default {};

    public Class<? extends Payload>[] payload() default {};
}
