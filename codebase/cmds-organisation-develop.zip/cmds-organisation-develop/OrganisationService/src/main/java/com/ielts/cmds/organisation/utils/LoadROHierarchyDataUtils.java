package com.ielts.cmds.organisation.utils;


import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.roui009roupdaterequested.ComponentEnum;
import com.ielts.cmds.api.roui009roupdaterequested.LinkTypeEnum;
import com.ielts.cmds.api.roui009roupdaterequested.MethodOfDeliveryEnum;
import com.ielts.cmds.api.roui009roupdaterequested.OrganisationStatusEnum;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateAddress;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateAlternateName;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateContact;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateLinkedOrganisation;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateMinimumScore;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateNote;
import com.ielts.cmds.api.roui009roupdaterequested.VerificationStatusEnum;
import com.ielts.cmds.organisation.domain.model.LoadROHierarchyDataV1;
import com.ielts.cmds.organisation.domain.model.RoDataUpdateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.Address;
import com.ielts.cmds.organisation.infrastructure.entity.AlternateName;
import com.ielts.cmds.organisation.infrastructure.entity.Contact;
import com.ielts.cmds.organisation.infrastructure.entity.LinkedRecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.entity.MinimumScore;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisedProduct;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.entity.RoNote;
import com.ielts.cmds.organisation.infrastructure.repository.LinkedRecognisingOrganisationRepository;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class LoadROHierarchyDataUtils {

    @Autowired LoadRODataUtils loadRODataUtils;

    @Autowired RecognisingOrganisationRepository recognisingOrgRepository;

    @Autowired OrganisationCommonUtils organisationCommonUtils;

    @Autowired LinkedRecognisingOrganisationRepository linkedRecognisingOrganisationRepository;

    public RoDataUpdateV1Valid loadHierarchyData(
            RecognisingOrganisation roToBeUpdated, LoadROHierarchyDataV1 loadRoHierarchyData) throws JSONException, JsonProcessingException {
        RoDataUpdateV1Valid roDataUpdateV1Valid = new RoDataUpdateV1Valid();
        roDataUpdateV1Valid.setRecognisingOrganisationUuid(
                roToBeUpdated.getRecognisingOrganisationUuid());
        roDataUpdateV1Valid.setOrganisationName(roToBeUpdated.getName());
        roDataUpdateV1Valid.setOrganisationStatus(OrganisationStatusEnum.valueOf(roToBeUpdated.getOrgStatus().getValue()));
        roDataUpdateV1Valid.setOrganisationTypeUuid(roToBeUpdated.getOrganisationTypeUuid());

        roDataUpdateV1Valid.setVerificationStatus(VerificationStatusEnum.valueOf(roToBeUpdated.getVerificationStatus().getValue()));
        roDataUpdateV1Valid.setSectorTypeUuid(roToBeUpdated.getSectorTypeUuid());
        roDataUpdateV1Valid.setPartnerCode(roToBeUpdated.getPartnerCode());
        roDataUpdateV1Valid.setPartnerContact(roToBeUpdated.getPartnerContact());
        roDataUpdateV1Valid.setMethodOfDelivery(MethodOfDeliveryEnum.fromValue(roToBeUpdated.getMethodOfDelivery().getValue()));
        roDataUpdateV1Valid.setCrmSystem(roToBeUpdated.getCrmSystem());
        roDataUpdateV1Valid.setWebsiteUrl(roToBeUpdated.getWebsiteUrl());
        roDataUpdateV1Valid.setOrganisationCode(roToBeUpdated.getOrganisationCode());
        roDataUpdateV1Valid.setIeltsDisplayFlag(roToBeUpdated.getIeltsDisplayFlag());
        roDataUpdateV1Valid.setOrsDisplayFlag(roToBeUpdated.getOrsDisplayFlag());
        List<Address> addressList =
                roToBeUpdated.getAddresses().stream()
                        .filter(address -> address.getContact() == null)
                        .collect(Collectors.toList());
        roDataUpdateV1Valid.setAddresses(loadAddressData(addressList));
        roDataUpdateV1Valid.setContacts(loadContactsData(roToBeUpdated.getContacts()));
        roDataUpdateV1Valid.setNotes(loadNotesData(roToBeUpdated.getNotes()));
        setAcceptsIOLandAcceptsSSRFlags(roToBeUpdated.getRecognisedProducts(), roDataUpdateV1Valid);
        roDataUpdateV1Valid.setMinimumScores(
                loadMinimumScoresData(roToBeUpdated.getMinimumScores()));
        roDataUpdateV1Valid.setAlternateNames(
                loadAlternateNames(roToBeUpdated.getAlternateNames()));
        roDataUpdateV1Valid.setLinkedOrganisations(
                loadLinkedOrganisationsData(
                        roToBeUpdated.getLinkedRecognisingOrganisations(), loadRoHierarchyData));
        return roDataUpdateV1Valid;
    }

    protected List<RoDataUpdateAlternateName> loadAlternateNames(List<AlternateName> alternateNames) {

        List<RoDataUpdateAlternateName> updateAltNames = new ArrayList<>();
        if (!alternateNames.isEmpty()) {
            for (AlternateName altName : alternateNames) {
                RoDataUpdateAlternateName updateAltName = new RoDataUpdateAlternateName();
                updateAltName.setAlternateNameUuid(altName.getAlternateNameUuid());
                updateAltName.setName(altName.getName());
                updateAltNames.add(updateAltName);
            }
        }
        return updateAltNames;
    }

    protected List<RoDataUpdateMinimumScore> loadMinimumScoresData(List<MinimumScore> minimumScores) {
        List<RoDataUpdateMinimumScore> updateMinimumScores = new ArrayList<>();
        if (!minimumScores.isEmpty()) {
            for (MinimumScore minimumScore : minimumScores) {
                RoDataUpdateMinimumScore updateminimumScore = new RoDataUpdateMinimumScore();
                updateminimumScore.setMinimumScoreUuid(minimumScore.getMinscoreReqUuid());
                updateminimumScore.setModuleTypeUuid(minimumScore.getModuleTypeUuid());
                updateminimumScore.setComponent(ComponentEnum.valueOf(minimumScore.getComponent().getValue()));
                updateminimumScore.setMinimumScoreValue(minimumScore.getMinimumScoreValue());
                updateMinimumScores.add(updateminimumScore);
            }
        }
        return updateMinimumScores;
    }

    protected void setAcceptsIOLandAcceptsSSRFlags(
            List<RecognisedProduct> recognisedProducts, RoDataUpdateV1Valid roUpdate) throws JSONException, JsonProcessingException {

        Set<UUID> activeRecognisedProductUUidList =
                recognisedProducts.stream()
                        .filter(
                                product ->
                                        product.getEffectiveToDatetime()
                                                .isAfter(OffsetDateTime.now(ZoneOffset.UTC)))
                        .map(RecognisedProduct::getProductUuid)
                        .collect(Collectors.toSet());
        Map<String, Boolean> acceptsSSRAcceptsIOLAcceptsACAcceptsGTMap = new HashMap<>();
        acceptsSSRAcceptsIOLAcceptsACAcceptsGTMap.put(
                OrganisationConstants.GenericConstants.IOL, Boolean.FALSE);
        acceptsSSRAcceptsIOLAcceptsACAcceptsGTMap.put(
                OrganisationConstants.GenericConstants.SSR, Boolean.FALSE);
        acceptsSSRAcceptsIOLAcceptsACAcceptsGTMap.put(OrganisationConstants.GenericConstants.AC, Boolean.FALSE);
        acceptsSSRAcceptsIOLAcceptsACAcceptsGTMap.put(OrganisationConstants.GenericConstants.GT, Boolean.FALSE);
        organisationCommonUtils.getIOLSSRACGTFlagsBasedOnExistingActiveProductUuidList(
                activeRecognisedProductUUidList, acceptsSSRAcceptsIOLAcceptsACAcceptsGTMap);
        roUpdate.setAcceptsIOL(
                acceptsSSRAcceptsIOLAcceptsACAcceptsGTMap.get(OrganisationConstants.GenericConstants.IOL));
        roUpdate.setAcceptsSSR(
                acceptsSSRAcceptsIOLAcceptsACAcceptsGTMap.get(OrganisationConstants.GenericConstants.SSR));
        roUpdate.setAcceptsAC(acceptsSSRAcceptsIOLAcceptsACAcceptsGTMap.get(OrganisationConstants.GenericConstants.AC));
        roUpdate.setAcceptsGT(acceptsSSRAcceptsIOLAcceptsACAcceptsGTMap.get(OrganisationConstants.GenericConstants.GT));
    }

    protected List<RoDataUpdateNote> loadNotesData(List<RoNote> notes) {

        List<RoDataUpdateNote> updateNotes = new ArrayList<>();
        if (!notes.isEmpty()) {
            for (RoNote note : notes) {
                RoDataUpdateNote updateNote = new RoDataUpdateNote();
                updateNote.setNoteUuid(note.getNoteUuid());
                updateNote.setNoteTypeUuid(note.getNoteTypeUuid());
                updateNote.setNoteContent(note.getNoteContent());
                updateNotes.add(updateNote);
            }
        }
        return updateNotes;
    }

    protected List<RoDataUpdateContact> loadContactsData(List<Contact> contacts) {

        List<RoDataUpdateContact> updateContacts = new ArrayList<>();
        if (!contacts.isEmpty()) {
            for (Contact contact : contacts) {
                RoDataUpdateContact updateContact = new RoDataUpdateContact();
                updateContact.setContactUuid(contact.getContactUuid());
                updateContact.setContactTypeUuid(contact.getContactTypeUuid());
                updateContact.setFirstName(contact.getFirstName());
                updateContact.setLastName(contact.getLastName());
                updateContact.setTitle(contact.getTitle());
                updateContact.setJobTitle(contact.getJobTitle());
                updateContact.setEffectiveFromDateTime(contact.getEffectiveFromDatetime());
                updateContact.setEffectiveToDateTime(contact.getEffectiveToDatetime());
                updateContact.setAddresses(loadAddressData(contact.getAddresses()));
                updateContacts.add(updateContact);
            }
        }
        return updateContacts;
    }

    protected List<RoDataUpdateAddress> loadAddressData(List<Address> addresses) {
        List<RoDataUpdateAddress> updateAddresses = new ArrayList<>();
        if (!addresses.isEmpty()) {
            for (Address address : addresses) {
                RoDataUpdateAddress updateAddress = new RoDataUpdateAddress();
                updateAddress.setAddressUuid(address.getAddressUuid());
                updateAddress.setAddressTypeUuid(address.getAddressTypeUuid());
                updateAddress.setAddressLine1(address.getAddressline1());
                updateAddress.setAddressLine2(address.getAddressline2());
                updateAddress.setAddressLine3(address.getAddressline3());
                updateAddress.setAddressLine4(address.getAddressline4());
                updateAddress.setCity(address.getCity());
                updateAddress.setCountryUuid(address.getCountryUuid());
                updateAddress.setTerritoryUuid(address.getTerritoryUuid());
                updateAddress.setEmail(address.getEmail());
                updateAddress.setPhone(address.getPhone());
                updateAddress.setPostalCode(address.getPostalCode());
                updateAddresses.add(updateAddress);
            }
        }
        return updateAddresses;
    }

    public Optional<RecognisingOrganisation> getRecognisingOrganisationByOrgId(
            Integer organisationId) {
        if(!StringUtils.isEmpty(String.valueOf(organisationId))) {
            return recognisingOrgRepository.findByOrganisationId(organisationId);
        }
        else{
            return Optional.empty();
        }
    }

    private List<RoDataUpdateLinkedOrganisation> loadLinkedOrganisationsData(
            List<LinkedRecognisingOrganisation> existingLinkedOrgs,
            LoadROHierarchyDataV1 loadRoHierarchyData) {
        List<RoDataUpdateLinkedOrganisation> roDataUpdateLinkedOrganisations =
                new ArrayList<>();
        RoDataUpdateLinkedOrganisation parentLinkedOrganisation =
                new RoDataUpdateLinkedOrganisation();

        if (existingLinkedOrgs.isEmpty()) {               
            if (StringUtils.isNotBlank(loadRoHierarchyData.getParentOrganisationId())) {
                Optional<RecognisingOrganisation> optRo =
                        getRecognisingOrganisationByOrgId(
                                Integer.valueOf(
                                        StringUtils.deleteWhitespace(
                                                loadRoHierarchyData.getParentOrganisationId())));
                if (optRo.isPresent()) {
                    parentLinkedOrganisation.setTargetRecognisingOrganisationUuid(
                            optRo.get().getRecognisingOrganisationUuid());
                }
                parentLinkedOrganisation.setLinkType(LinkTypeEnum.valueOf(LinkTypeEnum.PARENT_RO.getValue()));
                parentLinkedOrganisation.setLinkEffectiveFromDateTime(
                        OffsetDateTime.now(ZoneOffset.UTC));
                parentLinkedOrganisation.setLinkEffectiveToDateTime(
                        LocalDateTime.of(2099, 12, 31, 0, 0).atOffset(ZoneOffset.UTC));
                roDataUpdateLinkedOrganisations.add(parentLinkedOrganisation);
            } else  {
                //Here parent RO may be empty , but it can still have delivery orgs. Head of hierarchy
                loadResultsDeliveryOrganisationsData(loadRoHierarchyData, roDataUpdateLinkedOrganisations);
            }
        } else {
                log.debug("ADO RUN {} ", existingLinkedOrgs);
            for (LinkedRecognisingOrganisation linkedOrg : existingLinkedOrgs) {
                if (LinkTypeEnum.PARENT_RO.getValue().equals(
                        linkedOrg.getLinkedRecognisingOrganisationType().getValue())) {
                    parentLinkedOrganisation.setLinkedRecognisingOrganisationUuid(
                            linkedOrg.getLinkedRecognisingOrganisationUuid());
                    parentLinkedOrganisation.setTargetRecognisingOrganisationUuid(
                            linkedOrg
                                    .getTargetRecognisingOrganisation()
                                    .getRecognisingOrganisationUuid());
                    parentLinkedOrganisation.setLinkType(
                            LinkTypeEnum.valueOf(linkedOrg.getLinkedRecognisingOrganisationType().getValue()));
                    parentLinkedOrganisation.setLinkEffectiveFromDateTime(
                            linkedOrg.getEffectiveFromDatetime());
                    parentLinkedOrganisation.setLinkEffectiveToDateTime(
                            linkedOrg.getEffectiveToDatetime());
                    roDataUpdateLinkedOrganisations.add(parentLinkedOrganisation);
                }
            }

            if (StringUtils.isNotBlank(loadRoHierarchyData.getParentOrganisationId())) {
                loadResultsDeliveryOrganisationsData(loadRoHierarchyData, roDataUpdateLinkedOrganisations);
            }

        }
        return roDataUpdateLinkedOrganisations;
    }

    public List<Integer> getResultsDeliveryOrgIds(String resultsDeliveryOrgs) {
        List<Integer> resultsDeliverysOrgIds = new ArrayList<>();
        if (StringUtils.isNotBlank(resultsDeliveryOrgs)) {
            String[] resultsDeliveryOrgsSplit = resultsDeliveryOrgs.split("\\|");
            List<String> resultsDeliverysOrgIdsInString = Arrays.asList(resultsDeliveryOrgsSplit);
            resultsDeliverysOrgIdsInString.forEach(
                    orgId -> resultsDeliverysOrgIds.add(Integer.parseInt(orgId)));
        }
        return resultsDeliverysOrgIds;
    }

    private List<RoDataUpdateLinkedOrganisation> loadResultsDeliveryOrganisationsData(
            LoadROHierarchyDataV1 loadRoHierarchyData,
            List<RoDataUpdateLinkedOrganisation> roDataUpdateLinkedOrganisations) {

        Optional<RecognisingOrganisation> recognisingOrganisation = recognisingOrgRepository.findByOrganisationId(Integer.valueOf(loadRoHierarchyData.getOrganisationId()));
        if(recognisingOrganisation.isPresent()) {
                List<Integer> resultsDeliveryOrgIds =
                        getResultsDeliveryOrgIds(
                                StringUtils.deleteWhitespace(
                                        loadRoHierarchyData.getResultsDeliveryOrgIds()));
                if (!resultsDeliveryOrgIds.isEmpty()) {
                    for (Integer orgId : resultsDeliveryOrgIds) {
                        RoDataUpdateLinkedOrganisation linkedOrganisation =
                                new RoDataUpdateLinkedOrganisation();
                        Optional<RecognisingOrganisation> optRo =
                                getRecognisingOrganisationByOrgId(orgId);
                        if (optRo.isPresent()) {
                            linkedOrganisation.setTargetRecognisingOrganisationUuid(
                                    optRo.get().getRecognisingOrganisationUuid());
                        }
                        linkedOrganisation.setLinkType(LinkTypeEnum.valueOf(LinkTypeEnum.RESULTS_DELIVERY.getValue()));
                        linkedOrganisation.setLinkEffectiveFromDateTime(
                                OffsetDateTime.now(ZoneOffset.UTC));
                        linkedOrganisation.setLinkEffectiveToDateTime(
                                LocalDateTime.of(2099, 12, 31, 0, 0).atOffset(ZoneOffset.UTC));
                        roDataUpdateLinkedOrganisations.add(linkedOrganisation);
                    }
                }
            }
        return roDataUpdateLinkedOrganisations;
    }
}
