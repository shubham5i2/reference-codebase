package com.ielts.cmds.organisation.infrastructure.entity;

import com.ielts.cmds.organisation.common.enums.ComponentEnum;
import com.ielts.cmds.organisation.enums.FormatTypeEnum;
import com.ielts.cmds.organisation.enums.ProductStatusType;
import java.time.LocalDate;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;

@Entity(name = "product")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class Product extends CommonModel {

    /** Generated SerialVersionId */
    private static final long serialVersionUID = -6993055984777010701L;

    @Id
    @GeneratedValue
    @Type(type = "uuid-char")
    @Column(name = "product_uuid")
    private UUID productUuid;

    @Column(name = "parent_product_uuid")
    @Type(type = "uuid-char")
    private UUID parentProductUuid;

    @Column(name = "module_type_uuid")
    @Type(type = "uuid-char")
    private UUID moduleTypeUuid;

    @Column(name = "legacy_product_id")
    private String legacyProductId;

    @Column(name = "product_name", nullable = false)
    private String productName;

    @Column(name = "product_description")
    private String productDescription;

    @Column(name = "product_characteristics")
    private String productCharacteristics;

    @Column(name = "bookable", nullable = false)
    private boolean bookable;

    @Column(name = "component")
    @Enumerated(EnumType.STRING)
    private ComponentEnum component;

    @Column(name = "duration")
    private Integer duration;

    @Column(name = "format")
    @Enumerated(EnumType.STRING)
    private FormatTypeEnum format;

    @Column(name = "approval_required", nullable = false)
    private boolean approvalRequired;

    @Column(name = "available_from_date", nullable = false)
    private LocalDate availableFromDate;

    @Column(name = "available_to_date", nullable = false)
    private LocalDate availableToDate;

    @Column(name = "product_status", nullable = false)
    @Enumerated(EnumType.STRING)
    private ProductStatusType productStatus;
}
