package com.ielts.cmds.organisation.domain.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode
@ToString
public class LoadROHierarchyDataV1 {

    @JsonProperty("rowNumber")
    private String rowNumber;

    @JsonProperty("recognising_organisation_uuid")
    private String recognisingOrganisationUuid;

    @JsonProperty("trf.organisation_id")
    private String organisationId;

    @JsonProperty("business_identifier")
    private String businessIdentifier;

    @JsonProperty("parent_organisation_id")
    private String parentOrganisationId;

    @JsonProperty("results_delivery_org_ids")
    private String resultsDeliveryOrgIds;

    @JsonProperty("partner_code")
    private String partnerCode;

    @JsonProperty("error_list")
    private String errorListString;
}
