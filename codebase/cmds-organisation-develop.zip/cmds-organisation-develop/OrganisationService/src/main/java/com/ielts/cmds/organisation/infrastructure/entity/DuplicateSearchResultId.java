package com.ielts.cmds.organisation.infrastructure.entity;

import java.io.Serializable;
import java.util.UUID;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode
@ToString
public class DuplicateSearchResultId implements Serializable {

    /** Generated SerialVersionID */
    private static final long serialVersionUID = -5972072729124708197L;

    private UUID recognisingOrganisationUuid;

    private UUID addressUuid;
}
