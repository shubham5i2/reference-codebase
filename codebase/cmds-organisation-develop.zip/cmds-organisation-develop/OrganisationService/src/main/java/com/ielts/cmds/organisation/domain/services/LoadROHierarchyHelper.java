package com.ielts.cmds.organisation.domain.services;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.S3Object;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.domain.commands.LoadROData;
import com.ielts.cmds.organisation.domain.model.LoadROHierarchyDataV1;
import com.ielts.cmds.organisation.domain.model.LoadROHierarchyMessageV1;
import com.ielts.cmds.organisation.domain.model.LoadROHierarchyRecordEvent;
import com.ielts.cmds.organisation.utils.LoadROHierarchyEventMapper;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@NoArgsConstructor
public class LoadROHierarchyHelper extends CommonLoadROService {

    @Value("${ro.data.bucket.name}")
    private String roBucketName;

    @Value("${process.count}")
    private String processCount;

    @Autowired private AmazonS3 s3Client;

    @Autowired private ProcessROHierarchyDomainService processROHierarchyDomainService;

    @Autowired private ApplicationEventPublisher applicationEventPublisher;

    @Autowired private LoadROHierarchyEventMapper loadROHierarchyEventMapper;

    /**
     * This method will be used to get the file from S3 bucket and process the records As it is a
     * bulk load operation, it won't perform this operation in a single transaction
     *
     * @param loadROData
     * @throws IOException
     */
    public void onHierarchyUpdateCommand(final LoadROData loadROData) throws IOException {
        long startTime = System.currentTimeMillis();
        try {
            log.debug(
                    "Bucket Name: {}, Key: {} ",
                    roBucketName,
                    getFileName(loadROData.getEventHeaders()));
            S3Object s3object =
                    s3Client.getObject(roBucketName, getFileName(loadROData.getEventHeaders()));
            BufferedReader sheetdata =
                    new BufferedReader(new InputStreamReader(s3object.getObjectContent()));
            CsvSchema csvSchema = csvMapper.schema().withHeader().withColumnSeparator(',');
            MappingIterator<LoadROHierarchyDataV1> mappingIterator =
                    csvMapper
                            .readerFor(LoadROHierarchyDataV1.class)
                            .with(csvSchema)
                            .readValues(sheetdata);
            List<LoadROHierarchyDataV1> loadROHierarchyDataV1List = mappingIterator.readAll();

            int start =
                    Integer.parseInt(
                            loadROData
                                    .getEventHeaders()
                                    .getEventContext()
                                    .getOrDefault("start", "0"));
            int end = start + Integer.parseInt(processCount);
            log.debug("End: {}. Total Records: {}", end, loadROHierarchyDataV1List.size());
            Map<String, LoadROHierarchyRecordEvent> eventsMap =
                    processRecords(loadROData, loadROHierarchyDataV1List, start, end);
            // If start is lesser than total records, then there are remaining records to be
            // processed
            if (start < loadROHierarchyDataV1List.size()) {
                long duration = System.currentTimeMillis() - startTime;
                log.debug("Time took to process {} records: {}", processCount, duration);
                publishLoadROHierarchyEvent(
                        loadROData.getEventHeaders(), loadROData.getAudit(), eventsMap, end);
            } else {
                String mode = getOperationMode(loadROData.getEventHeaders());
                log.info(
                        "{} File processing completed with mode: {} , records processed {}",
                        getFileName(loadROData.getEventHeaders()),
                        mode,
                        start - 1);
            }
        } catch (IllegalArgumentException e) {
            log.error("Exception while getting file name/parsing: ", e);
            throw e;
        }
    }

    public void publishLoadROHierarchyEvent(
            BaseHeader eventHeaders,
            BaseAudit audit,
            Map<String, LoadROHierarchyRecordEvent> eventsMap,
            int end)
            throws JsonProcessingException {
        BaseHeader baseHeader = new BaseHeader();
        BeanUtils.copyProperties(eventHeaders, baseHeader);
        baseHeader.setEventName(OrganisationConstants.EventType.LOAD_RO_UPDATE_EVENT);
        baseHeader.getEventContext().put("start", Integer.toString(end));
        baseHeader.setEventDateTime(LocalDateTime.now(ZoneOffset.UTC));

        LoadROHierarchyMessageV1 loadROHierarchyMessageV1 =
                loadROHierarchyEventMapper.mapToEvent(eventsMap);
        BaseEvent<BaseHeader> event =
                new BaseEvent<>(
                        baseHeader,
                        objectMapper.writeValueAsString(loadROHierarchyMessageV1),
                        null,
                        audit);
        applicationEventPublisher.publishEvent(event);
    }

    /**
     * This method processes only processCount(property) records at a time. The processing stops
     * once all records have been processed. If there is any exception in any given row, exception
     * will be logged and processing will continue
     *
     * @param loadROData
     * @param records
     * @param endValue
     */
    public Map<String, LoadROHierarchyRecordEvent> processRecords(
            final LoadROData loadROData,
            final List<LoadROHierarchyDataV1> records,
            Integer startValue,
            Integer endValue) {
        Map<String, LoadROHierarchyRecordEvent> eventsMap = new HashMap<>();
        while (startValue < endValue && startValue < records.size()) {
            int rowNumber = startValue + 1;
            LoadROHierarchyRecordEvent loadROHierarchyRecordEvent =
                    new LoadROHierarchyRecordEvent();
            try {

                log.debug(
                        "Record Number: {}. Organisation Id to be processed: {}. Parent Organisation Id: {}. RO UUID:{}",
                        rowNumber,
                        records.get(startValue).getOrganisationId(),
                        records.get(startValue).getParentOrganisationId(),
                        records.get(startValue).getRecognisingOrganisationUuid());
                loadROHierarchyRecordEvent.setLoadROHierarchyRecord(records.get(startValue));
                loadROHierarchyRecordEvent.setEvent(
                        processROHierarchyDomainService.processRecord(
                                loadROData, records.get(startValue)));
                eventsMap.put(String.valueOf(rowNumber), loadROHierarchyRecordEvent);
            } catch (Exception e) {
                log.error("Exception in Load RO Process Records: ", e);
                loadROHierarchyRecordEvent.setLoadROHierarchyRecord(records.get(rowNumber - 1));
                loadROHierarchyRecordEvent.setEvent(
                        generateErrorFromException(
                                loadROData.getEventHeaders(),
                                e,
                                OrganisationConstants.EventType.RO_UPDATE_REJECTED_EVENT));
                eventsMap.put(String.valueOf(rowNumber), loadROHierarchyRecordEvent);
            }
            startValue++;
        }
        return eventsMap;
    }
}
