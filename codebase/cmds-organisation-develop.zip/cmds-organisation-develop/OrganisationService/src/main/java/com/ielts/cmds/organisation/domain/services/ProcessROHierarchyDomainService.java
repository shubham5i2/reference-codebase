package com.ielts.cmds.organisation.domain.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.domain.commands.LoadROData;
import com.ielts.cmds.organisation.domain.commands.UpdateROVO;
import com.ielts.cmds.organisation.domain.model.LoadROHierarchyDataV1;
import com.ielts.cmds.organisation.domain.model.RoDataUpdateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.utils.LoadROHierarchyDataUtils;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.organisation.utils.UpdateOrganisationUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import javax.validation.ConstraintViolation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Slf4j
public class ProcessROHierarchyDomainService {

    @Autowired private LoadROHierarchyDataUtils loadRoHierarchyDataUtils;

    @Autowired private RecognisingOrganisationRepository recognisingOrganisationRepository;

    @Autowired private UpdateOrganisationDomainService updateOrganisationDomainService;

    @Autowired private UpdateOrganisationUtil updateOrganisationUtil;

    @Autowired private OrganisationCommonUtils orgCommonUtils;

    /**
     * For each {@link CSVRecord}, this method will be invoked. All operations under this method,
     * will be executed under one single transaction
     *
     * @param loadROData
     * @param loadROHierarchyDataV1
     * @throws Exception
     * @throws JsonProcessingException
     */
    @Transactional
    public BaseEvent<BaseHeader> processRecord(
            final LoadROData loadROData, final LoadROHierarchyDataV1 loadROHierarchyDataV1)
            throws Exception {

        BaseEvent<BaseHeader> event = null;
        Map<String, String> eventContext =
                Optional.ofNullable(loadROData.getEventHeaders().getEventContext())
                        .orElseGet(HashMap::new);
        try {
            loadROData.getEventHeaders().setCorrelationId(UUID.randomUUID());
            Optional<RecognisingOrganisation> roToBeUpdated = Optional.empty();
            List<ErrorDescription> errorList = new ArrayList<>();
            if(!StringUtils.isEmpty(loadROHierarchyDataV1.getOrganisationId())) {
                Integer organisationId =
                        Integer.valueOf(
                                StringUtils.deleteWhitespace(
                                        loadROHierarchyDataV1.getOrganisationId()));
                roToBeUpdated =
                        recognisingOrganisationRepository.findByOrganisationId(organisationId);
            }else{
                getErrorDescriptionsForEmptyOrgId(errorList);
            }
            errorList = getViolationIfAnyOrgIdsDoesntExistInDB(loadROHierarchyDataV1);
            if (roToBeUpdated.isPresent() && errorList.isEmpty()) {
                final RoDataUpdateV1Valid roDataUpdate =
                        loadRoHierarchyDataUtils.loadHierarchyData(
                                roToBeUpdated.get(), loadROHierarchyDataV1);
                Set<ConstraintViolation<Object>> violations =
                        updateOrganisationDomainService.validateLinkedOrganisations(
                                roDataUpdate.getRecognisingOrganisationUuid(),
                                roDataUpdate.getLinkedOrganisations());
                Set<ConstraintViolation<Object>> dataViolations =
                        updateOrganisationDomainService.validateUpdateRODetails(roDataUpdate);
                violations.addAll(dataViolations);
                if (violations.isEmpty()) {
                    RecognisingOrganisation updateRO =
                            updateOrganisationUtil.populateOrganisation(
                                    roDataUpdate, roToBeUpdated.get(), new HashMap<>());
                    RecognisingOrganisation publishRO =
                            recognisingOrganisationRepository.save(updateRO);
                    event =
                            orgCommonUtils.publishUpdateEvent(
                                    loadROData.getEventHeaders(), loadROData.getAudit(), publishRO);
                } else {
                    log.debug("Violations : {}", violations);
                    event =
                            updateOrganisationDomainService.generateRejectedEventResponse(
                                    loadROData.getEventHeaders(),
                                    roDataUpdate,
                                    roToBeUpdated,
                                    loadROData.getAudit(),
                                    violations,
                                    eventContext.getOrDefault(
                                            OrganisationConstants.GenericConstants
                                                    .RECOGNISING_ORGANISATION_UUID,
                                            null));
                }
            } else {
                if(!StringUtils.isEmpty(loadROHierarchyDataV1.getOrganisationId())) {
                    checkifOrgIdExistsInDB(
                            roToBeUpdated,
                            Integer.valueOf(loadROHierarchyDataV1.getOrganisationId()),
                            errorList);
                }else {
                    getErrorDescriptionsForEmptyOrgId(errorList);
                }
                log.debug(
                        "No Records Found with ID :{}", loadROHierarchyDataV1.getOrganisationId());
                event =
                        orgCommonUtils.generateErrorEvent(
                                loadROData.getEventHeaders(), String.valueOf(loadROHierarchyDataV1), errorList);
            }
        } catch (Exception e) {
            log.error("Exception in Process Record: {}", e);
            throw e;
        }
        return event;
    }

    public List<ErrorDescription> getViolationIfAnyOrgIdsDoesntExistInDB(
            LoadROHierarchyDataV1 loadROHierarchyDataV1) {
        String parentOrgId = loadROHierarchyDataV1.getParentOrganisationId();
        Optional<RecognisingOrganisation> parentRecognisingOrganisation;
        List<ErrorDescription> errorList = new ArrayList<>();
        if(!StringUtils.isEmpty(parentOrgId)) {
            parentRecognisingOrganisation =
                    loadRoHierarchyDataUtils.getRecognisingOrganisationByOrgId(
                            Integer.valueOf(parentOrgId));
            checkifOrgIdExistsInDB(
                    parentRecognisingOrganisation,
                    Integer.valueOf(loadROHierarchyDataV1.getParentOrganisationId()),
                    errorList);
        }

        if(!StringUtils.isEmpty(loadROHierarchyDataV1.getResultsDeliveryOrgIds())) {
            List<Integer> resultsDeliveryOrgIds =
                    loadRoHierarchyDataUtils.getResultsDeliveryOrgIds(
                            loadROHierarchyDataV1.getResultsDeliveryOrgIds());
            for (Integer resultsDeliveryOrgId : resultsDeliveryOrgIds) {
                Optional<RecognisingOrganisation> ro;
                ro = loadRoHierarchyDataUtils.getRecognisingOrganisationByOrgId(
                        resultsDeliveryOrgId);
                checkifOrgIdExistsInDB(ro, resultsDeliveryOrgId, errorList);
            }
        }

        return errorList;
    }

    private List<ErrorDescription> checkifOrgIdExistsInDB(
            Optional<RecognisingOrganisation> ro, Integer orgId, List<ErrorDescription> errorList) {
        if (!ro.isPresent()) {
            log.debug("Organisation Doesn't exists with orgId : {}", orgId);
            orgCommonUtils.getErrorDescriptions(errorList, orgId);
        }
        return errorList;
    }
    public List<ErrorDescription> getErrorDescriptionsForEmptyOrgId(
            List<ErrorDescription> errorList) {
        ErrorDescription errorDescription = new ErrorDescription();
        errorDescription.setInterfaceName(OrganisationConstants.ErrorResponse.RO_INTERFACE_ERROR);
        errorDescription.setErrorCode("E0001");
        errorDescription.setTitle("Empty Organisation ID");
        errorDescription.setType(ErrorTypeEnum.ERROR);
        errorDescription.setMessage("Organisation ID is empty");
        errorList.add(errorDescription);
        return errorList;
    }
}
