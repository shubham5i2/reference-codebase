package com.ielts.cmds.organisation.infrastructure.entity;

import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.hibernate.annotations.Type;

@Data
@EqualsAndHashCode
@ToString
@MappedSuperclass
public class AddressDuplicateSearchResult implements Serializable {

    /** Generated SerialVersionID */
    private static final long serialVersionUID = -5972072729124708197L;

    @Id
    @Type(type = "uuid-char")
    @Column(columnDefinition = "uuid", name = "address_uuid")
    private UUID addressUuid;

    @Column(name = "addressline1", length = 100)
    private String addressline1;

    @Column(name = "addressline2", length = 100)
    private String addressline2;

    @Column(name = "addressline3", length = 100)
    private String addressline3;

    @Column(name = "addressline4", length = 100)
    private String addressline4;

    @Column(name = "phone", length = 20)
    private String phone;

    @Type(type = "uuid-char")
    @Column(columnDefinition = "uuid", name = "address_type_uuid")
    private UUID addressTypeUuid;

    @Type(type = "uuid-char")
    @Column(columnDefinition = "uuid", name = "contact_uuid")
    private UUID contactUuid;

    @Column(name = "postalcode", length = 20)
    private String postalCode;

    @Type(type = "uuid-char")
    @Column(columnDefinition = "uuid", name = "country_uuid")
    private UUID countryUuid;

    @Type(type = "uuid-char")
    @Column(columnDefinition = "uuid", name = "territory_uuid")
    private UUID territoryUuid;

    @Column(name = "city", length = 100)
    private String city;

    @Column(name = "email", length = 320)
    private String email;
}
