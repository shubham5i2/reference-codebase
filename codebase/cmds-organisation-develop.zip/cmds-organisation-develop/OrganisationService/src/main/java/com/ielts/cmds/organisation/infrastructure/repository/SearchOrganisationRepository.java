package com.ielts.cmds.organisation.infrastructure.repository;

import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface SearchOrganisationRepository
        extends JpaRepository<RecognisingOrganisation, UUID>,
                JpaSpecificationExecutor<RecognisingOrganisation> {}
