package com.ielts.cmds.organisation.infrastructure.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


import com.ielts.cmds.api.roui007rocreaterequested.ComponentEnum;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode(callSuper = true, exclude = { "recognisingOrganisation" })
@Entity(name = "minimum_score")
@ToString(exclude = { "recognisingOrganisation" })
public class MinimumScore extends CommonModel implements Serializable {

	/**
	 * Generated SerialVersionID
	 */
	private static final long serialVersionUID = 2475887359852265899L;

	@Id
	@GeneratedValue
	@Column(name = "minscore_req_uuid")
	private UUID minscoreReqUuid;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "recognising_organisation_uuid", nullable = false)
	private RecognisingOrganisation recognisingOrganisation;

	@Column(name = "module_type_uuid", nullable = false)
	private UUID moduleTypeUuid;

	@Column(name = "component", nullable = false)
	@Enumerated(EnumType.STRING)
	private ComponentEnum component;

	@Column(name = "minimum_score_value", nullable = false)
	private BigDecimal minimumScoreValue;
}
