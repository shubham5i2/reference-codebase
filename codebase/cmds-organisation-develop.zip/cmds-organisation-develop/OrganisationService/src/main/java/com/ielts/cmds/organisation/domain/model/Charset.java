package com.ielts.cmds.organisation.domain.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class Charset {

    private final int minOccurence;
    private final int maxOccurence;
    private final String characters;
}
