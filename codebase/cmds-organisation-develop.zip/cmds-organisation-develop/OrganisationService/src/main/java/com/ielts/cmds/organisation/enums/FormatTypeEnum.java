package com.ielts.cmds.organisation.enums;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;

@JsonAdapter(FormatTypeEnum.Adapter.class)
public enum FormatTypeEnum {
    CD("CD"),
    PB("PB");

    private String value;

    FormatTypeEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static FormatTypeEnum fromValue(String text) {
        for (FormatTypeEnum b : FormatTypeEnum.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        return null;
    }

    public static class Adapter extends TypeAdapter<FormatTypeEnum> {

        @Override
        public void write(final JsonWriter jsonWriter, final FormatTypeEnum enumeration)
                throws IOException {
            jsonWriter.value(enumeration.getValue());
        }

        @Override
        public FormatTypeEnum read(final JsonReader jsonReader) throws IOException {
            Object value = jsonReader.nextString();
            return FormatTypeEnum.fromValue(String.valueOf(value));
        }
    }
}
