package com.ielts.cmds.organisation.infrastructure.entity;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Type;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity(name = "country")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class Country extends ReferenceModel implements Serializable {

	/**
	 * Generated SerialVersionId
	 */
	private static final long serialVersionUID = 1283504712556255707L;

	@Id
	@GeneratedValue
	@Type(type="uuid-char")
	@Column(name = "country_uuid")
	private UUID countryUuid;

	@Column(name = "country_iso3_code", nullable = false)
	private String countryIso3Code;

	@Column(name = "country_name", nullable = false)
	private String countryName;

	@Column(name = "legacy_reference")
	private String legacyReference;

	@OneToMany(mappedBy = "country", cascade = CascadeType.ALL)
	private List<Territory> territories;

}
