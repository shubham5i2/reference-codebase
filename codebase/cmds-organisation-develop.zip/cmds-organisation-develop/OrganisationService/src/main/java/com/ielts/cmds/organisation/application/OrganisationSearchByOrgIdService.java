package com.ielts.cmds.organisation.application;

import com.ielts.cmds.api.roui011rodetailsbyorgidrequested.RODetailsByOrgIdRequestParam;
import com.ielts.cmds.common.config.IBaseAuditService;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.domain.commands.SearchRoByOrgId;
import com.ielts.cmds.organisation.domain.services.SearchByOrgIdDomainService;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.serialization.application.service.IApplicationServiceV2;
import com.ielts.cmds.serialization.utils.ServiceIdentifier;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@ServiceIdentifier(OrganisationConstants.GenericConstants.RO_SEARCH_BY_ORG_ID_REQUEST_EVENT)
public class OrganisationSearchByOrgIdService implements IApplicationServiceV2<RODetailsByOrgIdRequestParam>, IBaseAuditService {

    @Autowired private SearchByOrgIdDomainService searchByOrgIdDomainService;

    /**
     * This method handles incoming requests and creates command to call domain service for further
     * processing
     *
     * @param eventBody
     */
    @SneakyThrows
    @Override
    public void process(RODetailsByOrgIdRequestParam eventBody)  {
        try {
            log.debug(
                    "Request with transactionId and eventname as: {}, {}",
                    ThreadLocalHeaderContext.getContext().getTransactionId(),
                    ThreadLocalHeaderContext.getContext().getEventName());
            populateAuditFields();
            // Execute command
            searchByOrgIdDomainService.onCommand(eventBody.getOrganisationId());

        } catch (Exception e) {
            log.error("Exception while processing Request: ", e);
            throw new ProcessingException(e.getMessage(), e);
        }
    }

    @Override
    public String getPermission() {
        return OrganisationConstants.Permissions.ORG_VIEW;
    }

    @Override
    public String getScreen() {
        return OrganisationConstants.Screen.SEARCH_ORGANISATION_BY_ID;
    }

    @Override
    public String getAction() {
        return SearchRoByOrgId.class.getSimpleName();
    }
}
