package com.ielts.cmds.organisation.infrastructure.repository;

import com.ielts.cmds.organisation.infrastructure.entity.Address;
import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AddressRepository extends JpaRepository<Address, UUID> {

    List<Address> findByEmailAndContactContactUuidIsNotNull(String email);

    List<Address>
            findByEmailAndRecognisingOrganisationRecognisingOrganisationUuidNotAndContactContactUuidIsNotNull(
                    String email, UUID recognisingOrganisingUuid);
}
