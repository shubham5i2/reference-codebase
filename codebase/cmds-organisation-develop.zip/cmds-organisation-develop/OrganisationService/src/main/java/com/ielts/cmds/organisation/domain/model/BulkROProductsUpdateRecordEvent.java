package com.ielts.cmds.organisation.domain.model;

import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode
public class BulkROProductsUpdateRecordEvent {

    private BaseEvent<BaseHeader> event;

    private BulkRORecognisedProductsUpdateDataV1 bulkRoProductsUpdateRecord;

}
