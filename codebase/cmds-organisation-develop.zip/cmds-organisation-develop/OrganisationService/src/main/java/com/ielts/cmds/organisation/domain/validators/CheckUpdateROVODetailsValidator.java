package com.ielts.cmds.organisation.domain.validators;

import com.ielts.cmds.api.roui007rocreaterequested.MethodOfDeliveryEnum;
import com.ielts.cmds.api.roui007rocreaterequested.VerificationStatusEnum;
import com.ielts.cmds.api.roui007rocreaterequested.LinkTypeEnum;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateAddress;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateContact;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateLinkedOrganisation;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateMinimumScore;
import com.ielts.cmds.organisation.common.enums.OrganisationStatusEnum;
import com.ielts.cmds.organisation.domain.model.RoDataUpdateV1Valid;
import com.ielts.cmds.organisation.domain.validators.validations.ValidateOrgDetails;
import com.ielts.cmds.organisation.infrastructure.entity.AddressType;
import com.ielts.cmds.organisation.infrastructure.entity.ContactType;
import com.ielts.cmds.organisation.infrastructure.entity.LinkedRecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.entity.OrganisationType;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.AddressRepository;
import com.ielts.cmds.organisation.infrastructure.repository.AddressTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.ContactTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.LinkedRecognisingOrganisationRepository;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Slf4j
@Component
public class CheckUpdateROVODetailsValidator extends CheckOrganisationDetailsValidator
        implements ConstraintValidator<ValidateOrgDetails, RoDataUpdateV1Valid> {

    @Autowired private ContactTypeRepository contactTypeRepository;

    @Autowired private AddressTypeRepository addressTypeRepository;

    @Autowired private AddressRepository addressRepository;

    @Autowired private LinkedRecognisingOrganisationRepository linkedRORepository;

    @Override
    public boolean isValid(RoDataUpdateV1Valid roDataUpdate, ConstraintValidatorContext context) {
        context.disableDefaultConstraintViolation();
        boolean isValidOrgDetailsToUpdate = true;
        final UUID organisationTypeUuid = roDataUpdate.getOrganisationTypeUuid();
        Optional<OrganisationType> organisationType = orgTypeRepository.findById(organisationTypeUuid);
        if (!organisationType.isPresent()) {
            isValidOrgDetailsToUpdate = false;
            log.debug("Organisation Type is not valid");
            addConstraintViolation(
                    context, "{cmds.invalid.organisationTypeUuid}", "organisationTypeUuid");
        } else {
            /*
             * If OrganisationType is Recognising Organisation then make a call to RO
             * Validations Method.
             */
            if (OrganisationConstants.GenericConstants.RECOGNISING_ORGANISATION.equals(
                    organisationType.get().getOrganisationsType())) {
                isValidOrgDetailsToUpdate = isValidRO(roDataUpdate, context);
            } else {
                /*
                 * If OrganisationType is Verified Organisation then make a call to VO
                 * Validations Method.
                 */
                isValidOrgDetailsToUpdate = isValidVO(roDataUpdate, context);
            }
        }
        boolean isValidOrganisationNameForUpdate =
                isValidOrganisationNameForUpdate(roDataUpdate, context);
        return isValidOrgDetailsToUpdate && isValidOrganisationNameForUpdate;
    }

    private boolean isValidVO(RoDataUpdateV1Valid roDataUpdate, ConstraintValidatorContext context) {
        boolean isValidVoDetailsToUpdate = true;
        isValidVoDetailsToUpdate =
                checkAllCommonFieldsForROVO(roDataUpdate, context, isValidVoDetailsToUpdate);
        isValidVoDetailsToUpdate =
                isValidVOVerificationStatusEnum(
                        VerificationStatusEnum.valueOf(roDataUpdate.getVerificationStatus().getValue()),
                        context,
                        isValidVoDetailsToUpdate);
            isValidVoDetailsToUpdate =
                    isValidVOMethodOfDeliveryEnum(
                            MethodOfDeliveryEnum.valueOf(roDataUpdate.getMethodOfDelivery().name()),
                            context,
                            isValidVoDetailsToUpdate);

        isValidVoDetailsToUpdate =
                isValidResultsAvailableForYears(
                        roDataUpdate.getResultAvailableForYears(), context, isValidVoDetailsToUpdate);
        isValidVoDetailsToUpdate = isValidLinkedOrganisations(roDataUpdate, context, isValidVoDetailsToUpdate);
        isValidVoDetailsToUpdate = isValidUpdateFromROToVO(roDataUpdate, context, isValidVoDetailsToUpdate);
        return isValidVoDetailsToUpdate;
    }
    private boolean isValidUpdateFromROToVO( RoDataUpdateV1Valid roDataUpdate,
                                             ConstraintValidatorContext context,
                                             boolean isValidRoDetailsToUpdate) {
        Optional<RecognisingOrganisation> existingRO = recognisingOrganisationRepository.findByRecognisingOrganisationUuid(roDataUpdate.getRecognisingOrganisationUuid());
        List<LinkedRecognisingOrganisation> linkedRo = linkedRORepository
                .findByTargetRecognisingOrganisationRecognisingOrganisationUuidAndLinkedRecognisingOrganisationType(
                        roDataUpdate.getRecognisingOrganisationUuid(),
                        LinkTypeEnum.RESULTS_DELIVERY);
        if(existingRO.isPresent()
                && !roDataUpdate.getOrganisationTypeUuid().equals(existingRO.get().getRecognisingOrganisationUuid())
                && !linkedRo.isEmpty()){
                    isValidRoDetailsToUpdate = false;
                    log.debug("You can't update RO to VO because this Ro is selected as ADO of other RO");
                    addConstraintViolation(context,
                            "{cmds.invalid.organisationTypeToUpdate}",
                            "organisationTypeUuid");
        }
        return isValidRoDetailsToUpdate;
    }
    private boolean isValidOrganisationNameForUpdate(
            RoDataUpdateV1Valid roDataUpdate, ConstraintValidatorContext context) {
        boolean isValidOrganisationNameForUpdate = true;

        if (recognisingOrganisationRepository
                .existsByNameIgnoreCaseAndRecognisingOrganisationUuidNotAndSoftDeletedFalse(
                        roDataUpdate.getOrganisationName(),
                        roDataUpdate.getRecognisingOrganisationUuid())) {
            log.debug("Organisation already present with this names");
            isValidOrganisationNameForUpdate = false;
            addConstraintViolation(context, "{cmds.duplicate.organisationName}", "organisationName");
        }
        return isValidOrganisationNameForUpdate;
    }

    private boolean isValidRO(RoDataUpdateV1Valid roDataUpdate, ConstraintValidatorContext context) {
        boolean isValidRoDetailsToUpdate = true;
        Optional<RecognisingOrganisation> existingRO = recognisingOrganisationRepository.findByRecognisingOrganisationUuid(roDataUpdate.getRecognisingOrganisationUuid());

        isValidRoDetailsToUpdate =
                checkAllCommonFieldsForROVO(roDataUpdate, context, isValidRoDetailsToUpdate);
        isValidRoDetailsToUpdate =
                isValidContactToUpdate(
                        roDataUpdate.getContacts(),
                        context,
                        isValidRoDetailsToUpdate,
                        roDataUpdate.getRecognisingOrganisationUuid(),
                        roDataUpdate.getVerificationStatus().getValue());

		if (existingRO.isPresent()) {

				isValidRoDetailsToUpdate = isValidVerificationStatusForActiveApprovedROUpdate(existingRO.get(),
						roDataUpdate, context, isValidRoDetailsToUpdate);
				isValidRoDetailsToUpdate = isValidVerificationStatusForADOROUpdate(existingRO.get(),
						roDataUpdate, context, isValidRoDetailsToUpdate);
		}
		isValidRoDetailsToUpdate = isValidROMethodOfDeliveryEnum(
                            MethodOfDeliveryEnum.valueOf(roDataUpdate.getMethodOfDelivery().name()),
                            context,
                            isValidRoDetailsToUpdate);
        isValidRoDetailsToUpdate =
                isValidWebsiteUrl(roDataUpdate.getWebsiteUrl(), context, isValidRoDetailsToUpdate);
        isValidRoDetailsToUpdate =
                isValidResultsAvailableForYears(
                        roDataUpdate.getResultAvailableForYears(), context, isValidRoDetailsToUpdate);
        isValidRoDetailsToUpdate = isValidLinkedOrganisations(roDataUpdate, context, isValidRoDetailsToUpdate);
        return isValidRoDetailsToUpdate;
    }

	private boolean isValidVerificationStatusForADOROUpdate(RecognisingOrganisation existingRO, RoDataUpdateV1Valid roDataUpdate, ConstraintValidatorContext context,
			boolean isValidRoDetailsToUpdate) {
		if ((!VerificationStatusEnum.VERIFIED.getValue().equals(existingRO.getVerificationStatus().getValue()))
				&& VerificationStatusEnum.VERIFIED.getValue().equals(roDataUpdate.getVerificationStatus().getValue())) {
			List<LinkedRecognisingOrganisation> linkedRo = linkedRORepository
					.findByTargetRecognisingOrganisationRecognisingOrganisationUuidAndLinkedRecognisingOrganisationType(
							roDataUpdate.getRecognisingOrganisationUuid(),
							LinkTypeEnum.RESULTS_DELIVERY);
			if (!linkedRo.isEmpty()) {
				isValidRoDetailsToUpdate = false;
				log.debug("You can't update INActive RO Verification Status from approved to verified because this Ro was ADO to other RO");
				addConstraintViolation(context, "{cmds.invalid.verificationStatus.orgStatus.inActive}",
						"verificationStatus");
			}
		}
		return isValidRoDetailsToUpdate;
	}


	public boolean isValidLinkedOrganisations(
            RoDataUpdateV1Valid roDataUpdate,
            ConstraintValidatorContext context,
            boolean isValidRoDetailsToUpdate) {
        List<RoDataUpdateLinkedOrganisation> roDataUpdateLinkedOrganisations =
                roDataUpdate.getLinkedOrganisations();
        if (roDataUpdateLinkedOrganisations != null) {
            for (RoDataUpdateLinkedOrganisation linkedOrg : roDataUpdateLinkedOrganisations) {
                isValidRoDetailsToUpdate =
                        checkLinkedOrganisationValidation(
                                roDataUpdate.getOrganisationTypeUuid(),
                                linkedOrg.getTargetRecognisingOrganisationUuid(),
                                LinkTypeEnum.valueOf(linkedOrg.getLinkType().getValue()),
                                context,
                                isValidRoDetailsToUpdate);
                isValidRoDetailsToUpdate =
                        checkEffectiveFromDate(
                                linkedOrg.getLinkEffectiveFromDateTime(),
                                linkedOrg.getLinkEffectiveToDateTime(),
                                context,
                                isValidRoDetailsToUpdate,
                                OrganisationConstants.GenericConstants.LINKED_ORGANISATIONS_PROPERTY_NODE);
            }

                Optional<LinkedRecognisingOrganisation> parentForExistingRo =
                        linkedRORepository
                                .findBySourceRecognisingOrganisationRecognisingOrganisationUuidAndLinkedRecognisingOrganisationTypeAndEffectiveToDatetimeAfter(
                                        roDataUpdate.getRecognisingOrganisationUuid(),
                                        LinkTypeEnum.PARENT_RO,
                                        OffsetDateTime.now(ZoneOffset.UTC));
                if (parentForExistingRo.isPresent()
                        && parentForExistingRo
                        .get()
                        .getEffectiveToDatetime()
                        .isAfter(OffsetDateTime.now(ZoneOffset.UTC))
                        && roDataUpdateLinkedOrganisations.stream()
                        .filter(
                                linkedRo ->
                                        linkedRo.getLinkedRecognisingOrganisationUuid() == null
                                                && LinkTypeEnum.PARENT_RO
                                                .getValue()
                                                .equals(linkedRo.getLinkType().getValue()))
                        .count()
                        >= 1) {
                    isValidRoDetailsToUpdate = false;
                    log.debug("Any RO can have only one Parent Organisation");
                    addConstraintViolation(
                            context,
                            "{cmds.invalid.linkedRecognisingOrganisationType}",
                            OrganisationConstants.GenericConstants.LINKED_ORGANISATIONS_PROPERTY_NODE);
                }

            if (roDataUpdateLinkedOrganisations.stream()
                    .filter(
                            linkedOrg ->
                                    LinkTypeEnum.PARENT_RO.getValue().equals(linkedOrg.getLinkType().getValue()))
                    .count()
                    > 1) {
                isValidRoDetailsToUpdate = false;
                log.debug("Any RO can have only one Parent Organisation");
                addConstraintViolation(
                        context,
                        "{cmds.invalid.linkedRecognisingOrganisationType}",
                        OrganisationConstants.GenericConstants.LINKED_ORGANISATIONS_PROPERTY_NODE);
            }
        }
        return isValidRoDetailsToUpdate;
    }

    public boolean checkAllCommonFieldsForROVO(
            RoDataUpdateV1Valid roDataUpdate, ConstraintValidatorContext context, boolean isValidUpdate) {

        isValidUpdate =
                isEmptyOrganisationName(roDataUpdate.getOrganisationName(), context, isValidUpdate);
        isValidUpdate = isValidPartnerCode(roDataUpdate.getPartnerCode(), context, isValidUpdate);
        isValidUpdate = isValidSectorType(roDataUpdate.getSectorTypeUuid(), context, isValidUpdate);
        isValidUpdate = isValidAddressToUpdate(roDataUpdate.getAddresses(), context, isValidUpdate);
        isValidUpdate = isValidMinimumScores(roDataUpdate.getMinimumScores(), context, isValidUpdate);
        isValidUpdate = isValidProductAcceptanceFlags(roDataUpdate.getAcceptsAC(), roDataUpdate.getAcceptsGT(), context, isValidUpdate);
        return isValidUpdate;
    }
    private boolean isValidProductAcceptanceFlags(Boolean acceptsAC, Boolean acceptsGT, ConstraintValidatorContext context, boolean isValidRoDetails) {
        final boolean acFalseGtFalse = Boolean.FALSE.equals(acceptsAC) && Boolean.FALSE.equals(acceptsGT);
        if(acFalseGtFalse || (acceptsAC == null && acceptsGT == null)
                ||(acceptsAC == null && Boolean.FALSE.equals(acceptsGT)) || (Boolean.FALSE.equals(acceptsAC) && acceptsGT == null)){
            isValidRoDetails = false;
            log.debug("acceptsAC or acceptsGT any one of two must be true");
            addConstraintViolation(
                    context,
                    "{cmds.invalid.productAcceptance}",
                    OrganisationConstants.GenericConstants.PRODUCT_ACCEPTANCE);
        }
        return isValidRoDetails;
    }
    public boolean isValidMinimumScores(
            List<RoDataUpdateMinimumScore> minimumScores,
            ConstraintValidatorContext context,
            boolean isValidRoVoDetails) {
        if (minimumScores != null) {
            for (RoDataUpdateMinimumScore minScore : minimumScores) {
                isValidRoVoDetails =
                        isValidModuleTypeUuid(minScore.getModuleTypeUuid(), context, isValidRoVoDetails);
            }
        }
        return isValidRoVoDetails;
    }

    public boolean isValidAddressToUpdate(
            List<RoDataUpdateAddress> roDataUpdateAddress,
            ConstraintValidatorContext context,
            boolean isValidAddress) {
        int mainAddressCount = 0;
        int deliveryAddressCount = 0;
        for (RoDataUpdateAddress updateAddress : roDataUpdateAddress) {
                Optional<AddressType> optAddress =
                        addressTypeRepository.findById(updateAddress.getAddressTypeUuid());
                if (!optAddress.isPresent()) {
                    isValidAddress = false;
                    log.debug("Address Type is not valid");
                    addConstraintViolation(
                            context,
                            "{cmds.invalid.addressTypeName}",
                            OrganisationConstants.GenericConstants.ADDRESS_PROPERTY_NODE);
                } else {
                    isValidAddress =
                            addressCheck(
                                    updateAddress,
                                    optAddress.get().getAddressTypeName(),
                                    context,
                                    isValidAddress);
                    mainAddressCount =
                            countMainAddress(
                                    optAddress.get().getAddressTypeName(), mainAddressCount);
                    deliveryAddressCount =
                            countDeliveryAddress(
                                    optAddress.get().getAddressTypeName(), deliveryAddressCount);
                }

        }
        isValidAddress =
                checkMainAndDeliveryAddress(
                        mainAddressCount, deliveryAddressCount, context, isValidAddress);
        return isValidAddress;
    }

    private boolean addressCheck(
            RoDataUpdateAddress roDataUpdateaddress,
            String addressTypeName,
            ConstraintValidatorContext context,
            boolean isValidAddress) {
        isValidAddress =
                mandatoryAddressLineCheck(
                        roDataUpdateaddress.getAddressLine1(),
                        addressTypeName,
                        context,
                        isValidAddress);
        isValidAddress =
                mandatoryCityCheck(
                        roDataUpdateaddress.getCity(), addressTypeName, context, isValidAddress);
        isValidAddress =
                isValidCountry(
                        roDataUpdateaddress.getCountryUuid(),
                        addressTypeName,
                        context,
                        isValidAddress);
        isValidAddress =
                isValidTerritory(
                        roDataUpdateaddress.getTerritoryUuid(),
                        addressTypeName,
                        context,
                        isValidAddress);
        return isValidAddress;
    }

    public boolean isValidContactToUpdate(
            List<RoDataUpdateContact> roDataUpdateContacts,
            ConstraintValidatorContext context,
            boolean isValidRoDetailsToUpdate,
            UUID recognisingOrganisationUuid,
            String verificationStatus) {
        int primaryContactCount = 0;
        int resultsAdminContactCount = 0;
        for (RoDataUpdateContact contact : roDataUpdateContacts) {
            Optional<ContactType> contactType = Optional.empty();
            if (Objects.nonNull(contact)) {
                contactType = contactTypeRepository.findById(contact.getContactTypeUuid());
            }
            if (contactType.isPresent()) {
                String contactName = contactType.get().getContactsType();
                isValidRoDetailsToUpdate = checkContactBasedOnVerificationStatus(contactName, contact, context, isValidRoDetailsToUpdate, verificationStatus);
                primaryContactCount = checkPrimaryContact(contactName, primaryContactCount);
                resultsAdminContactCount =
                        checkResultsAdminContact(contactName, resultsAdminContactCount);
                isValidRoDetailsToUpdate =
                        checkEmailForPrimaryOrResultAdminContact(
                                contact.getAddresses(),
                                contactName,
                                context,
                                isValidRoDetailsToUpdate,
                                recognisingOrganisationUuid,
                                verificationStatus);

            } else {
                isValidRoDetailsToUpdate = false;
                log.debug("Contact Type is not valid");
                addConstraintViolation(
                        context,
                        "{cmds.invalid.contacts}",
                        OrganisationConstants.GenericConstants.CONTACTS_PROPERTY_NODE);
            }
        }
        isValidRoDetailsToUpdate =
                checkPrimaryandResultsAdminContact(
                        primaryContactCount,
                        resultsAdminContactCount,
                        context,
                        isValidRoDetailsToUpdate);
        return isValidRoDetailsToUpdate;
    }
    private boolean checkContactBasedOnVerificationStatus(String contactName,
                                                          RoDataUpdateContact contact,
                                                          ConstraintValidatorContext context,
                                                          boolean isValidRoDetailsToUpdate,
                                                          String verificationStatus){
        if (Objects.equals(VerificationStatusEnum.VERIFIED.getValue(), verificationStatus)
                && Objects.equals(contactName, OrganisationConstants.GenericConstants.RESULT_ADMIN)){
            isValidRoDetailsToUpdate = true;

        }else {
            isValidRoDetailsToUpdate =
                    isEmptyKnownName(
                            contact.getFirstName(),
                            contact.getLastName(),
                            context,
                            contactName,
                            isValidRoDetailsToUpdate);
        }
        return isValidRoDetailsToUpdate;
    }

    /**
     * Method to validate Email for Primary and ResultsAdmin Contacts.
     *
     * @param addresses
     * @param contactName
     * @param context
     * @param isValidContact
     * @return
     */
    private boolean checkEmailForPrimaryOrResultAdminContact(
            List<RoDataUpdateAddress> addresses,
            String contactName,
            ConstraintValidatorContext context,
            boolean isValidContact,
            UUID recognisingOrganisationUuid,
            String verificationStatus) {
        if (OrganisationConstants.GenericConstants.PRIMARY_CONTACT.equals(contactName)
                || OrganisationConstants.GenericConstants.RESULT_ADMIN.equals(contactName)) {
            isValidContact =
                    checkEmail(
                            addresses,
                            contactName,
                            context,
                            isValidContact,
                            recognisingOrganisationUuid,
                            verificationStatus);
        }
        return isValidContact;
    }

    /**
     * Method to validate Email for Primary and ResultsAdmin Contacts.
     *
     * @param addresses
     * @param contactTypeName
     * @param context
     * @param isValidContact
     * @return
     */
    private boolean checkEmail(
            List<RoDataUpdateAddress> addresses,
            String contactTypeName,
            ConstraintValidatorContext context,
            boolean isValidContact,
            UUID recognisingOrganisationUuid,
            String verificationStatus) {
        if (addresses != null) {
            for (RoDataUpdateAddress address : addresses) {
                isValidContact =
                        isValidEmail(address.getEmail(), contactTypeName, context, isValidContact, verificationStatus);
                    isValidContact =
                            isUniqueEmail(
                                    address.getEmail(),
                                    contactTypeName,
                                    context,
                                    isValidContact,
                                    recognisingOrganisationUuid);
            }
        }
        return isValidContact;
    }

    protected boolean isUniqueEmail(
            String email,
            String contactTypeName,
            ConstraintValidatorContext context,
            boolean isValidContact,
            UUID recognisingOrganisationUuid) {
        if ((OrganisationConstants.GenericConstants.RESULT_ADMIN.equals(contactTypeName))
                && (!addressRepository
                .findByEmailAndRecognisingOrganisationRecognisingOrganisationUuidNotAndContactContactUuidIsNotNull(
                        email, recognisingOrganisationUuid)
                .isEmpty())
                && Objects.nonNull(email)) {
            isValidContact = false;
            log.debug("RO Admin email address must be unique");
            addConstraintViolation(
                    context,
                    "{cmds.invalid.email.Duplicate}",
                    OrganisationConstants.GenericConstants.ADDRESS_PROPERTY_NODE);
        }
        return isValidContact;
    }
}
