package com.ielts.cmds.organisation.infrastructure.entity;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.Type;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity(name = "contact_type")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class ContactType extends ReferenceModel implements Serializable {

	/**
	 * Generated SerialVersionId
	 */
	private static final long serialVersionUID = -7171646788988473973L;

	@Id
	@GeneratedValue
	@Type(type="uuid-char")
	@Column(name = "contact_type_uuid")
	private UUID contactTypeUuid;

	@Column(name = "contact_type", nullable = false)
	private String contactsType;

	@Column(name = "description")
	private String description;

}
