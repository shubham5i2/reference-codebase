package com.ielts.cmds.organisation.domain.commands;

import com.ielts.cmds.application.command.BaseCommand;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.domain.model.RoDataCreateV1Valid;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** @author cts */
@Data
@EqualsAndHashCode(callSuper = true)
public class CreateROVO extends BaseCommand<BaseHeader, RoDataCreateV1Valid> {

    @Builder
    public CreateROVO(
            final BaseHeader eventHeaders,
            final RoDataCreateV1Valid eventBody,
            final BaseEventErrors eventErrors,
            final BaseAudit audit) {
        super(eventHeaders, eventBody, eventErrors, audit);
    }
}
