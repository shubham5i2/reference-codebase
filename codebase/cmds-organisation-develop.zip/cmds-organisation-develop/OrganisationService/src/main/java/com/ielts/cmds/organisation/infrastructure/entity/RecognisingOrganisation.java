package com.ielts.cmds.organisation.infrastructure.entity;



import java.io.Serializable;
import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.GenerationTime;
import org.hibernate.annotations.GeneratorType;
import org.hibernate.annotations.GenericGenerator;

import com.ielts.cmds.api.roui007rocreaterequested.MethodOfDeliveryEnum;
import com.ielts.cmds.api.roui007rocreaterequested.OrganisationStatusEnum;
import com.ielts.cmds.api.roui007rocreaterequested.VerificationStatusEnum;
import com.ielts.cmds.organisation.utils.OrganisationIdSequenceGenerator;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity(name = "recognising_organisation")
@Data
@EqualsAndHashCode(
        callSuper = true,
        exclude = {
            "notes",
            "alternateNames",
            "recognisedProducts",
            "minimumScores",
            "addresses",
            "contacts"
        })
@NoArgsConstructor
public class RecognisingOrganisation extends CommonModel implements Serializable {

    /** Generated SerialVersionId */
    private static final long serialVersionUID = -5240178090895236758L;

    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
    @Column(
            columnDefinition = "uuid",
            name = "recognising_organisation_uuid",
            unique = true,
            nullable = false)
    private UUID recognisingOrganisationUuid;

    @Column(columnDefinition = "uuid", name = "organisation_type_uuid", nullable = false)
    private UUID organisationTypeUuid;

    @Column(columnDefinition = "uuid", name = "sector_type_uuid", nullable = false)
    private UUID sectorTypeUuid;

    @GeneratorType(type = OrganisationIdSequenceGenerator.class, when = GenerationTime.INSERT)
    @Column(name = "organisation_id", nullable = false)
    private Integer organisationId;

    @Column(name = "name", nullable = false, length = 255)
    private String name;

    @Column(name = "verification_status", nullable = false)
    @Enumerated(EnumType.STRING)
    private VerificationStatusEnum verificationStatus;

    @Column(name = "partner_code", nullable = false, length = 25)
    private String partnerCode;

    @Column(name = "partner_contact", length = 50)
    private String partnerContact;

    @Column(name = "method_of_delivery", nullable = false)
    private MethodOfDeliveryEnum methodOfDelivery;

    @Column(name = "org_status")
    @Enumerated(EnumType.STRING)
    private OrganisationStatusEnum orgStatus;

    @Column(name = "website_url", length = 250)
    private String websiteUrl;

    @Column(name = "crm_system", length = 50)
    private String crmSystem;

    @Column(name = "organisation_code", length = 20)
    private String organisationCode;

    @Column(name = "ielts_display_flag")
    private Boolean ieltsDisplayFlag;

    @Column(name = "ors_display_flag")
    private Boolean orsDisplayFlag;

    @Column(name = "result_available_for_years")
    private Integer resultAvailableForYears;

    @Column(name = "soft_deleted")
    private Boolean softDeleted;

    @OneToMany(
            mappedBy = "recognisingOrganisation",
            cascade = CascadeType.ALL,
            fetch = FetchType.LAZY)
    private List<RoNote> notes;

    @OneToMany(
            mappedBy = "recognisingOrganisation",
            cascade = CascadeType.ALL,
            fetch = FetchType.LAZY)
    private List<AlternateName> alternateNames;

    @OneToMany(
            mappedBy = "recognisingOrganisation",
            cascade = CascadeType.ALL,
            fetch = FetchType.LAZY)
    private List<RecognisedProduct> recognisedProducts;

    @OneToMany(
            mappedBy = "recognisingOrganisation",
            cascade = CascadeType.ALL,
            fetch = FetchType.LAZY)
    private List<MinimumScore> minimumScores;

    @OneToMany(
            mappedBy = "recognisingOrganisation",
            cascade = CascadeType.ALL,
            fetch = FetchType.LAZY)
    private List<Address> addresses;

    @OneToMany(
            mappedBy = "recognisingOrganisation",
            cascade = CascadeType.ALL,
            fetch = FetchType.LAZY)
    private List<Contact> contacts;

    @OneToMany(
            mappedBy = "sourceRecognisingOrganisation",
            cascade = CascadeType.ALL,
            fetch = FetchType.LAZY)
    private List<LinkedRecognisingOrganisation> linkedRecognisingOrganisations;
}
