package com.ielts.cmds.organisation.cache;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.organisation.cache.entity.Product;

import java.util.List;
import java.util.Optional;

public interface JedisGenericReader {

	Optional<Product> retrieveSingleProductDataFromRedisCache(String productKey) throws JsonProcessingException;
	
	List<Product> retrieveAllBookableProductsDataFromRedisCache() throws JsonProcessingException;
	
	List<Product> retrieveAllProductsDataFromRedisCache() throws JsonProcessingException;
}
