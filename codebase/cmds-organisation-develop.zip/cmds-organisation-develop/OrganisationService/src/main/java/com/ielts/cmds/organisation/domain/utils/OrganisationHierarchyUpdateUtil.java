package com.ielts.cmds.organisation.domain.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.organisation.common.enums.LinkTypeEnum;
import com.ielts.cmds.organisation.infrastructure.entity.LinkedRecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.LinkedRecognisingOrganisationRepository;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class OrganisationHierarchyUpdateUtil {

    @Autowired private LinkedRecognisingOrganisationRepository linkedRORepository;

    /**
     * This method updates all the organisations(siblings and its children) of the organisation for
     * which the parent is removed or changed.
     *
     * @param recognisingOrganisation
     * @param childRoUuidList
     * @return
     * @throws JsonProcessingException
     */
    public RecognisingOrganisation updateSiblingOrgAdditionalDeliveryOrganisations(
            RecognisingOrganisation recognisingOrganisation, List<UUID> childRoUuidList)
            throws JsonProcessingException {
        log.debug(
                "Linked Organisations of {}, before update - {}",
                recognisingOrganisation.getName(),
                recognisingOrganisation.getLinkedRecognisingOrganisations().toString());
        List<LinkedRecognisingOrganisation> updatedLinkedRos =
                invalidateAdditionalDeliveryOrgs(
                        recognisingOrganisation.getLinkedRecognisingOrganisations().stream()
                                .filter(
                                        linkedRO ->
                                                linkedRO.getEffectiveToDatetime()
                                                        .isAfter(OffsetDateTime.now(ZoneOffset.UTC)))
                                .collect(Collectors.toList()),
                        childRoUuidList);
        recognisingOrganisation.setLinkedRecognisingOrganisations(updatedLinkedRos);
        log.debug(
                "Linked Organisations of {}, after update {}",
                recognisingOrganisation.getName(),
                recognisingOrganisation.getLinkedRecognisingOrganisations().toString());
        return recognisingOrganisation;
    }

    /**
     * This method updates all the organisations(children) below the organisation for which the
     * parent is removed or changed.
     *
     * @param childRo
     * @param previousHierarchyOrgs
     * @param newOrganisationHierarchyLabel
     * @return
     * @throws JsonProcessingException
     */
    public RecognisingOrganisation updateChildOrgLabelAndAdditionalDeliveryOrgs(
            RecognisingOrganisation childRo,
            List<UUID> previousHierarchyOrgs,
            String newOrganisationHierarchyLabel)
            throws JsonProcessingException {
        log.debug(
                "Linked Organisations of {}, before update {}",
                childRo.getName(),
                childRo.getLinkedRecognisingOrganisations().toString());
        List<LinkedRecognisingOrganisation> updatedLinkedROs =
                updateOrganisationLabelAndDeliveryOrgs(
                        childRo.getLinkedRecognisingOrganisations().stream()
                                .filter(
                                        linkedRO ->
                                                linkedRO.getEffectiveToDatetime()
                                                        .isAfter(OffsetDateTime.now(ZoneOffset.UTC)))
                                .collect(Collectors.toList()),
                        newOrganisationHierarchyLabel,
                        previousHierarchyOrgs);
        childRo.setLinkedRecognisingOrganisations(updatedLinkedROs);
        log.debug(
                "Linked Organisations of {}, after update {}",
                childRo.getName(),
                childRo.getLinkedRecognisingOrganisations().toString());
        return childRo;
    }

    /**
     * update the additional delivery organisations for all the organisations in the previous
     * hierarchy when the parent is removed or changed.
     *
     * @param additionalDeliveryOrgsList
     * @param childRoUuidList
     * @return
     */
    private List<LinkedRecognisingOrganisation> invalidateAdditionalDeliveryOrgs(
            List<LinkedRecognisingOrganisation> additionalDeliveryOrgsList,
            List<UUID> childRoUuidList) {
        additionalDeliveryOrgsList = additionalDeliveryOrgsList.stream()
                .filter(
                        linkedRecord ->
                                LinkTypeEnum.RESULTS_DELIVERY.getValue().equals(
                                        linkedRecord.getLinkedRecognisingOrganisationType().getValue()))
                .map(
                        (LinkedRecognisingOrganisation linkedROToBeUpdated) ->
                                invalidate(linkedROToBeUpdated, childRoUuidList))
                .collect(Collectors.toList());


        return additionalDeliveryOrgsList;
    }

    /**
     * Check for invalid Addition delivery organisations and if there are invalid ADO's then set the
     * effective-to-datetime to current date(i.e., make them inactive).
     *
     * @param linkedOrg
     * @param roUuidList
     * @return
     */
    private LinkedRecognisingOrganisation invalidate(
            LinkedRecognisingOrganisation linkedOrg, List<UUID> roUuidList) {
        if (roUuidList.contains(
                linkedOrg.getTargetRecognisingOrganisation().getRecognisingOrganisationUuid())) {
            linkedOrg.setEffectiveToDatetime(OffsetDateTime.now(ZoneOffset.UTC));
        }
        return linkedOrg;
    }

    /**
     * This method sets the organisationHierarchyLabel to new label(root node of new hierarchy) and
     * update the additional delivery organisations for all the child organisations of the
     * organisation for which the parent is removed or changed.
     *
     * @param activeLinkedRos
     * @param newHierarchyLabel
     * @param previousHierarchyRoUuids
     * @return
     */
    public List<LinkedRecognisingOrganisation> updateOrganisationLabelAndDeliveryOrgs(
            List<LinkedRecognisingOrganisation> activeLinkedRos,
            String newHierarchyLabel,
            List<UUID> previousHierarchyRoUuids) {
        for (LinkedRecognisingOrganisation linkedRO : activeLinkedRos) {
            if (LinkTypeEnum.PARENT_RO.getValue().equals(linkedRO.getLinkedRecognisingOrganisationType().getValue())) {
                linkedRO.setOrganisationHierarchyLabel(newHierarchyLabel);
            } else {
                invalidate(linkedRO, previousHierarchyRoUuids);
            }
        }
        return activeLinkedRos;
    }

    /**
     * This method is used to get all the organisations of the previous hierarchy when ever a parent
     * is removed or changed.
     *
     * @param oldHierarchyLabel
     * @return
     */
    public Set<RecognisingOrganisation> getAllTheOrgsOfPreviousHierarchy(String oldHierarchyLabel) {
        Set<RecognisingOrganisation> allTheOrgsOfPreviousTree = new HashSet<>();
        List<LinkedRecognisingOrganisation> allTheLinkedOrgs = new ArrayList<>();
        if (Objects.nonNull(oldHierarchyLabel)) {
            allTheLinkedOrgs =
                    linkedRORepository.findAllByOrganisationHierarchyLabel(oldHierarchyLabel)
                            .stream()
                            .filter(
                                    linkedRO ->
                                            linkedRO.getEffectiveToDatetime()
                                                    .isAfter(OffsetDateTime.now(ZoneOffset.UTC)))
                            .collect(Collectors.toList());
        }
        if (!allTheLinkedOrgs.isEmpty()) {
            allTheOrgsOfPreviousTree.addAll(
                    allTheLinkedOrgs.stream()
                            .map(LinkedRecognisingOrganisation::getSourceRecognisingOrganisation)
                            .collect(Collectors.toSet()));
            allTheOrgsOfPreviousTree.addAll(
                    allTheLinkedOrgs.stream()
                            .map(LinkedRecognisingOrganisation::getTargetRecognisingOrganisation)
                            .collect(Collectors.toSet()));
        }
        return allTheOrgsOfPreviousTree;
    }
}
