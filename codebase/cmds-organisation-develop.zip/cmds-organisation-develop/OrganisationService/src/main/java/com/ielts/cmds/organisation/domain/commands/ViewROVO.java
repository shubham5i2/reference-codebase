package com.ielts.cmds.organisation.domain.commands;

import com.ielts.cmds.application.command.BaseCommand;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** @author cts */
@Data
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Builder
public class ViewROVO extends BaseCommand<BaseHeader, Object> {

    private BaseHeader eventHeaders;
    private Object eventBody;
    private BaseEventErrors eventErrors;
    private BaseAudit audit;
}
