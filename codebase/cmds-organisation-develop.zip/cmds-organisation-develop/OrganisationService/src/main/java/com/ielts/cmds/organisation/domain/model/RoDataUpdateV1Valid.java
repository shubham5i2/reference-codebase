package com.ielts.cmds.organisation.domain.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdate;
import com.ielts.cmds.organisation.domain.validators.validations.ValidateOrgDetails;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@ValidateOrgDetails
public class RoDataUpdateV1Valid extends RoDataUpdate {}
