package com.ielts.cmds.organisation.domain.utils;

import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class DomainEventsPublisher {

    private final ApplicationEventPublisher applicationEventPublisher;

    public void baseEventListPublisher(List<BaseEvent<BaseHeader>> eventList) {
        eventList.forEach(
                e ->
                        log.debug(
                                "List of Events to be published: {}",
                                e.getEventHeader().getEventName()));

        try {
            eventList.forEach(applicationEventPublisher::publishEvent);
            eventList.forEach(
                    (i ->
                            log.info(
                                    "Event being Published from {} with metadata as {} and error as {}",
                                    OrganisationConstants.GenericConstants.RO,
                                    i.getEventHeader(),
                                    i.getEventErrors())));

        } catch (Exception e) {
            log.info("Exception while publishing event list", e);
        }
    }
}
