package com.ielts.cmds.organisation.domain.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreateLinkedOrganisation;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.BodyCallBackEvent;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.common.enums.LinkTypeEnum;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.organisation.domain.model.RoDataCreateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.OrganisationType;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.OrganisationTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** @author CTS */
@Service
@Slf4j
public class CreateOrganisationDomainService extends AbstractCMDSDomainService<RoChangedEventV1> {

    @Autowired private ObjectMapper objectMapper;

    @Autowired private OrganisationCommonUtils orgUtils;

    @Autowired private RecognisingOrganisationRepository orgRepository;

    @Autowired private ApplicationEventPublisher applicationEventPublisher;

    @Autowired private Validator roValidator;

    @Autowired private CMDSErrorResolver<Object> errorResolver;

    @Autowired private OrganisationTypeRepository orgTypeRepository;

    @Autowired
    protected CreateOrganisationDomainService(ApplicationEventPublisher publisher, ObjectMapper objectMapper, @Value("${createOrganisationDomain.v2}") String isV2Enabled, CMDSThreadLocalContextService cmdsThreadLocalContextService) {
        super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
    }

    /**
     * @param eventBody
     */
    @Transactional
    public void onCommand(final RoDataCreateV1Valid eventBody) {

        try {
            final UUID organisationTypeUuid = eventBody.getOrganisationTypeUuid();
            Map<String, String> eventContext =
                    Optional.ofNullable(ThreadLocalHeaderContext.getContext().getEventContext())
                            .orElseGet(HashMap::new);


                Optional<OrganisationType> organisationType =
                        orgTypeRepository.findById(organisationTypeUuid);
                if (!organisationType.isPresent()) {
                    log.debug(
                            "Organisation Type is not valid {} ",
                            eventBody.getOrganisationTypeUuid());
                    Set<ConstraintViolation<Object>> violations =
                            orgUtils.getSetforNullViolationOfEventBody(
                                    "V0001", "organisationTypeUuid");
                    generateRejectedEventResponse(
                            orgUtils.buildUiHeader(),
                            eventBody,
                            orgUtils.getBaseAudit(),
                            violations,
                            eventContext.getOrDefault(
                                    OrganisationConstants.GenericConstants
                                            .RECOGNISING_ORGANISATION_UUID,
                                    null));

                } else {
                    Set<ConstraintViolation<Object>> violations =
                            orgUtils.checkPermissionForROVO(
                                    ThreadLocalHeaderContext.getContext().getXaccessToken(),
                                    organisationType.get().getOrganisationsType(),
                                    OrganisationConstants.GenericConstants.CREATE,
                                    ThreadLocalAuditContext.getContext());
                    if (!violations.isEmpty()) {
                        generateRejectedEventResponse(
                                orgUtils.buildUiHeader(),
                                eventBody,
                                orgUtils.getBaseAudit(),
                                violations,
                                eventContext.getOrDefault(
                                        OrganisationConstants.GenericConstants
                                                .RECOGNISING_ORGANISATION_UUID,
                                        null));

                    } else {
                        createRoVoOrganisation(eventBody);
                    }
                }
        } catch (Exception e) {
            log.error("Exception in Create Organisation Domain Service:  ", e);
        }
    }

    private void createRoVoOrganisation(RoDataCreateV1Valid eventBody) throws JsonProcessingException {
        Set<ConstraintViolation<Object>> violations = new HashSet<>();
        Optional<OrganisationType> organisationType =
                orgTypeRepository.findById(eventBody.getOrganisationTypeUuid());
        if(organisationType.isPresent()
                && !OrganisationConstants.GenericConstants.VERIFIED_ORGANISATION.equals(organisationType.get().getOrganisationsType())) {
            violations =
                    checkAdditionalDeliveryOrganisationIsInHierarchy(
                            eventBody.getLinkedOrganisations());
        }
        Set<ConstraintViolation<Object>> dataviolations =
                validateRODetails(eventBody);
        violations.addAll(dataviolations);

        Map<String, String> eventContext =
                Optional.ofNullable(ThreadLocalHeaderContext.getContext().getEventContext())
                        .orElseGet(HashMap::new);

        if (!violations.isEmpty()) {
            log.debug("Violations: {}", violations);
            generateRejectedEventResponse(
                    orgUtils.buildUiHeader(),
                    eventBody,
                    orgUtils.getBaseAudit(),
                    violations,
                    eventContext.getOrDefault(
                            OrganisationConstants.GenericConstants
                                    .RECOGNISING_ORGANISATION_UUID,
                            null));

        } else {
            RecognisingOrganisation publishRo = null;
            RecognisingOrganisation createRO = new RecognisingOrganisation();
            RecognisingOrganisation roData = orgUtils.populateOrganisation(eventBody, createRO);
            publishRo = orgRepository.save(roData);
            orgRepository.flush();
            registerandPublishCreateOrganisationEvent(
                    orgUtils.buildUiHeader(), publishRo, orgUtils.getBaseAudit());
        }
    }

    public BaseEvent<BaseHeader> generateRejectedEventResponse(
            final BaseHeader baseHeader,
            final RoDataCreateV1Valid eventBody,
            final BaseAudit audit,
            final Set<ConstraintViolation<Object>> violations,
            final String dataRecord)
            throws JsonProcessingException {
        UiHeader roHeader = new UiHeader();
        BeanUtils.copyProperties(baseHeader, roHeader);
        roHeader.setEventName(OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT);
        CMDSErrorResponse eventErrors =
                errorResolver.populatErrorResponse(
                        violations, OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT);
        BaseEventErrors baseEventErrors = new BaseEventErrors(eventErrors.getErrorList());
        if (Objects.nonNull(dataRecord)) {
            audit.getAuditContext().put(OrganisationConstants.GenericConstants.RECORD, dataRecord);
        }

        BaseEvent<BaseHeader> event = new BaseEvent<>(roHeader, objectMapper.writeValueAsString(eventBody), baseEventErrors, audit);
        if (log.isDebugEnabled()) {
            log.debug("BaseEvent : {}", objectMapper.writeValueAsString(event));
        }
        applicationEventPublisher.publishEvent(event);
        return event;
    }

    public Set<ConstraintViolation<Object>> validateRODetails(RoDataCreateV1Valid roDetails) {

        Set<ConstraintViolation<Object>> roDetailsViolation = roValidator.validate(roDetails);

        if (log.isDebugEnabled() && CollectionUtils.isNotEmpty(roDetailsViolation)) {
            roDetailsViolation.forEach(
                    violation -> log.debug("Invalid Request :" + violation.getMessage()));
        }

        return roDetailsViolation;
    }

    public BaseEvent<BaseHeader> registerandPublishCreateOrganisationEvent(
            final BaseHeader baseHeader, final RecognisingOrganisation publishRo, BaseAudit audit) {
        UiHeader roHeader = new UiHeader();
        BeanUtils.copyProperties(baseHeader, roHeader);
        roHeader.setEventName(OrganisationConstants.EventType.RO_CREATED_EVENT);
        roHeader.setEventDateTime(LocalDateTime.now());
        roHeader.setPartnerCode(publishRo.getPartnerCode());
        orgUtils.setEventDiscriminatorForExternalSystems(roHeader, publishRo);

        BaseEvent<BaseHeader> event =
                new BodyCallBackEvent<>(
                        roHeader,
                        () -> {
                            try {
                                RoChangedEventV1 roChangedEvent =
                                        orgUtils.entityToEventMapper(publishRo);
                                audit.getAuditContext()
                                        .put(
                                                OrganisationConstants.GenericConstants.RECORD,
                                                roChangedEvent
                                                        .getRecognisingOrganisationUuid()
                                                        .toString());
                                return objectMapper.writeValueAsString(roChangedEvent);
                            } catch (JsonProcessingException e) {
                                throw new IllegalArgumentException(e);
                            }
                        },
                        null,
                        audit);
        applicationEventPublisher.publishEvent(event);
        return event;
    }

    private Set<ConstraintViolation<Object>> checkAdditionalDeliveryOrganisationIsInHierarchy(
            List<RoDataCreateLinkedOrganisation> linkedOrganisations) {
        Set<ConstraintViolation<Object>> violations = new HashSet<>();
        if (linkedOrganisations != null) {
            for (RoDataCreateLinkedOrganisation linkedOrganisation : linkedOrganisations) {
                if (LinkTypeEnum.RESULTS_DELIVERY.getValue().equals(linkedOrganisation.getLinkType().getValue())) {
                    violations =
                            validationForResultsDelivery(
                                    linkedOrganisations, linkedOrganisation, violations);
                }
            }
        }
        return violations;
    }

    private Set<ConstraintViolation<Object>> validationForResultsDelivery(
            List<RoDataCreateLinkedOrganisation> linkedOrganisations,
            RoDataCreateLinkedOrganisation linkedOrganisation,
            Set<ConstraintViolation<Object>> violations) {
        List<RoDataCreateLinkedOrganisation> parentOrg =
                linkedOrganisations.stream()
                        .filter(linkedOrg -> LinkTypeEnum.PARENT_RO.getValue().equals(linkedOrg.getLinkType().getValue()))
                        .collect(Collectors.toList());
        /*If we try to add additional delivery organisations without adding parent then we reject the creation of RO*/

        if (parentOrg.isEmpty()) {
            log.debug("Parent Must be added to add Additional Delivery organisations");
            violations = orgUtils.getSetforNullViolationOfEventBody("V0063", "ParentNotSelected");
            return violations;
            /*If parent and additional delivery organisations are present in the request then check if the addition delivery organisations are in hierarchy or not*/
        } else {
            UUID parentOrganisationUuid = parentOrg.get(0).getTargetRecognisingOrganisationUuid();
            Set<RecognisingOrganisation> finalHierarchyList =
                    orgUtils.getHierarchyBasedOnRecognisingOrganisationUuid(parentOrganisationUuid);
            List<UUID> finalHierarchyListUuids =
                    finalHierarchyList.stream()
                            .map(RecognisingOrganisation::getRecognisingOrganisationUuid)
                            .collect(Collectors.toList());
            /*If additional delivery organisation are not in hierarchy then reject the creation of RO*/
            if (!finalHierarchyListUuids.contains(
                    linkedOrganisation.getTargetRecognisingOrganisationUuid())) {
                log.debug("Additional Delivery organisations must be in Hierarchy List");
                violations =
                        orgUtils.getSetforNullViolationOfEventBody(
                                "V0064", "DeliveryOrganisationsNotInHierarchy");
                return violations;
            }
        }
        return violations;
    }
}
