package com.ielts.cmds.organisation.domain.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.organisation.domain.commands.OrganisationHierarchyUpdate;
import com.ielts.cmds.organisation.domain.utils.OrganisationHierarchyUpdateUtil;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Slf4j
public class OrganisationHierarchyUpdateDomainService {

    @Autowired private RecognisingOrganisationRepository roRepository;

    @Autowired private OrganisationCommonUtils orgCommonUtils;

    @Autowired private OrganisationHierarchyUpdateUtil orgHierarchyUpdateUtil;

    /**
     * @param organisationHierarchyUpdate
     * @throws JsonProcessingException
     */
    @Transactional
    public void onCommand(OrganisationHierarchyUpdate organisationHierarchyUpdate)
            throws JsonProcessingException {
        Set<RecognisingOrganisation> allTheOrgsOfPreviousTree = new HashSet<>();
        Set<RecognisingOrganisation> childHierarchy = new HashSet<>();
        /*Based on the oldHierarchyLabel get all the sourceRecognisingOrganisations which are the nodes of previous hierarchy*/
        try {
            if (Objects.nonNull(
                    organisationHierarchyUpdate.getEventBody().getOldHierarchyLabel())) {
                allTheOrgsOfPreviousTree =
                        orgHierarchyUpdateUtil.getAllTheOrgsOfPreviousHierarchy(
                                organisationHierarchyUpdate.getEventBody().getOldHierarchyLabel());
            }
            /*Based on the TriggerRoUuid we are getting the RO and all the children of the RO which has triggered the ROHierarchyUpdate Event*/
            if (Objects.nonNull(
                    organisationHierarchyUpdate
                            .getEventBody()
                            .getTriggerRecognisingOrganisationUuid())) {
                childHierarchy =
                        orgCommonUtils.getChildHierarchyBasedOnRO(
                                organisationHierarchyUpdate
                                        .getEventBody()
                                        .getTriggerRecognisingOrganisationUuid(),
                                Boolean.FALSE);
            }
            List<UUID> childRoUuidList =
                    childHierarchy.stream()
                            .map(RecognisingOrganisation::getRecognisingOrganisationUuid)
                            .collect(Collectors.toList());
            List<RecognisingOrganisation> siblingOrgsList = new ArrayList<>();
            for (RecognisingOrganisation ro : allTheOrgsOfPreviousTree) {
                if (!childRoUuidList.contains(ro.getRecognisingOrganisationUuid())) {
                    siblingOrgsList.add(ro);
                }
            }
            List<UUID> siblingsInPreviousHierarchy =
                    siblingOrgsList.stream()
                            .map(RecognisingOrganisation::getRecognisingOrganisationUuid)
                            .collect(Collectors.toList());
            RecognisingOrganisation publishOrganisation = null;
            /*Update the Siblings by updating the invalid additional delivery organisations*/
            if (siblingsInPreviousHierarchy.contains(
                    organisationHierarchyUpdate.getEventBody().getRecognisingOrganisationUuid())) {
                publishOrganisation = updateSiblingsAdditionalDeliveryOrganisation(organisationHierarchyUpdate, childRoUuidList, publishOrganisation);
            }

            /*Update the Children by updating the invalid additional delivery organisations*/
            if (childRoUuidList.contains(
                    organisationHierarchyUpdate.getEventBody().getRecognisingOrganisationUuid())) {
                publishOrganisation= updateChildrenAdditionalDeliveryOrganisation(organisationHierarchyUpdate, siblingsInPreviousHierarchy, publishOrganisation);
            }
            orgCommonUtils.publishUpdateEvent(
                    organisationHierarchyUpdate.getEventHeaders(),
                    organisationHierarchyUpdate.getAudit(),
                    publishOrganisation);
        } catch (Exception e) {
            log.error("Exception in OrganisationHerarchyUpdateDomainService : ", e);
        }
    }
    public RecognisingOrganisation updateChildrenAdditionalDeliveryOrganisation(OrganisationHierarchyUpdate organisationHierarchyUpdate, List<UUID> siblingsInPreviousHierarchy, RecognisingOrganisation publishOrganisation) throws JsonProcessingException {
        Optional<RecognisingOrganisation> ro =
                roRepository.findById(
                        organisationHierarchyUpdate
                                .getEventBody()
                                .getRecognisingOrganisationUuid());
        if (ro.isPresent()) {
            log.debug(
                    "Updating the Child Organisation : {}, Name: {}",
                    ro.get().getRecognisingOrganisationUuid(),
                    ro.get().getName());
            RecognisingOrganisation childOrg =
                    orgHierarchyUpdateUtil.updateChildOrgLabelAndAdditionalDeliveryOrgs(
                            ro.get(),
                            siblingsInPreviousHierarchy,
                            organisationHierarchyUpdate
                                    .getEventBody()
                                    .getNewHierarchyLabel());
            publishOrganisation = roRepository.save(childOrg);
            log.debug(
                    "Saved Organisation {}, as {}",
                    publishOrganisation.getName(),
                    publishOrganisation.toString());
        }
        return publishOrganisation;
    }
    public RecognisingOrganisation updateSiblingsAdditionalDeliveryOrganisation(OrganisationHierarchyUpdate organisationHierarchyUpdate, List<UUID> childRoUuidList, RecognisingOrganisation publishOrganisation) throws JsonProcessingException {
        Optional<RecognisingOrganisation> ro =
                roRepository.findById(
                        organisationHierarchyUpdate
                                .getEventBody()
                                .getRecognisingOrganisationUuid());
        if (ro.isPresent()) {
            log.debug(
                    "Updating the Sibling Organisation : {}, Name: {}",
                    ro.get().getRecognisingOrganisationUuid(),
                    ro.get().getName());
            RecognisingOrganisation siblingOrg =
                    orgHierarchyUpdateUtil.updateSiblingOrgAdditionalDeliveryOrganisations(
                            ro.get(), childRoUuidList);
            publishOrganisation = roRepository.save(siblingOrg);
            log.debug(
                    "Updated the Previous Hierarchy Organisation and Saved Organisation with UUID : {} and Name : {}",
                    publishOrganisation.getRecognisingOrganisationUuid(),
                    publishOrganisation.getName());
        }
        return publishOrganisation;
    }
}
