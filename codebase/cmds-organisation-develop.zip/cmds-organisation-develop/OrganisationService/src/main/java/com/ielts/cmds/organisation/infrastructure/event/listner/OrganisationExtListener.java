package com.ielts.cmds.organisation.infrastructure.event.listner;

import static java.lang.String.format;

import java.util.Map;
import java.util.Objects;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.common.config.IApplicationService;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.common.exception.util.CMDSServiceException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.rbac.api.service.RBACService;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.api.utils.AuditDataUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class OrganisationExtListener {

    @Resource(name = "applicationServiceMap")
    private Map<String, IApplicationService> applicationServiceMap;

    @Autowired private OrganisationCommonUtils organisationCommonUtils;

    @Autowired private RBACService rbacService;

    @Autowired  AuditDataUtils auditDataUtils;

    @PostConstruct
    public void init() {
        auditDataUtils = new AuditDataUtils(rbacService);
    }

    /**
     * This method is to accept create / update request from destination queue and deserialize
     * request into SMEvent to pass it on to SMService.
     *
     * @param orgMessage
     * @throws CMDSServiceException
     * @throws JsonProcessingException
     * @throws Exception
     */
    @JmsListener(destination = "${aws.sqs.ro-ext-queue-in.name}")
    public void onReceive(@Payload final String orgMessage)
            throws CMDSServiceException, JsonProcessingException, RbacValidationException {

        if (StringUtils.isBlank(orgMessage)) {
            throw new CMDSServiceException(OrganisationConstants.ErrorResponse.EMPTY_PAYLOAD);
        }
        try {
            BaseEvent<BaseHeader> cmdsEvent =
                    organisationCommonUtils.processRequest(orgMessage, BaseHeader.class);
            log.info(
                    "Event Received in {} with metadata as {}",
                    OrganisationConstants.GenericConstants.RO,
                    cmdsEvent.getEventHeader());
            final IApplicationService service =
                    applicationServiceMap.get(cmdsEvent.getEventHeader().getEventName());

            if (Objects.nonNull(service)) {
                log.debug("AuditData: {}", auditDataUtils);
                auditDataUtils.withSecurityContext(
                        cmdsEvent,
                        cmdsEventcall -> {
                            try {
                                service.process(cmdsEventcall);
                            } catch (ProcessingException e) {
                                log.error("Exception while processing: ", e);
                            }
                        });
            } else {
                throw new IllegalArgumentException(
                        format(
                                "Due to invalid operationType, aborting request:%s",
                                cmdsEvent.getEventHeader().getEventName()));
            }

        } catch (JsonProcessingException ex) {
            log.error("Error in parsing message - JsonProcessingException. ", ex);
            throw ex;
        } catch (Exception e) {
            log.error("Exception in Others. ", e);
            log.debug(ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }
}
