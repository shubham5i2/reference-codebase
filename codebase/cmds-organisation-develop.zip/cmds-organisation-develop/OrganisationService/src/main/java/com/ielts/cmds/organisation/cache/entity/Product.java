package com.ielts.cmds.organisation.cache.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.UUID;

@Data
@NoArgsConstructor
public class Product {

    private UUID productUuid;

    private UUID parentProductUuid;

    private Module module;

    private String legacyProductId;

    private String name;

    private String description;

    private String productCharacteristics;

    private boolean bookable;

    private String component;

    private int duration;

    private String format;

    private boolean approvalRequired;

    private LocalDate availableFrom;

    private LocalDate availableTo;
}
