package com.ielts.cmds.organisation.domain.services;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.roui007rocreaterequested.OrganisationStatusEnum;
import com.ielts.cmds.api.roui007rocreaterequested.VerificationStatusEnum;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.common.out.event.RoRequestedEventV1;
import com.ielts.cmds.organisation.infrastructure.entity.PartnerCode;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisedProduct;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.OrganisationTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.PartnerCodeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.SectorTypeRepository;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.outbox.event.OutboxEventBuilder;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.rbac.api.service.impl.RBACServiceImpl;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;

import lombok.extern.slf4j.Slf4j;

/** @author CTS */
@Service
@Slf4j
public class ViewOrganisationDomainService extends AbstractCMDSDomainService<RoRequestedEventV1>  {

	@Autowired private ObjectMapper objectMapper;

    @Autowired private RBACServiceImpl rbacServiceImpl;

    @Autowired private OrganisationCommonUtils organisationCommonUtils;

    @Autowired private CMDSErrorResolver<Object> errorResolver;

    @Autowired private ApplicationEventPublisher applicationEventPublisher;
    
    @Autowired private OrganisationTypeRepository organisationTypeRepository;
    
	@Autowired private SectorTypeRepository sectorTypeRepository;
	
	@Autowired private PartnerCodeRepository partnerCodeRepository;

	@Autowired private OutboxEventBuilder outboxEventBuilder;

	@Autowired
	protected ViewOrganisationDomainService(ApplicationEventPublisher publisher, ObjectMapper objectMapper, @Value("${viewOrganisationDomain.v2}") String isV2Enabled, CMDSThreadLocalContextService cmdsThreadLocalContextService) {
		super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
	}

    /**
	 * @throws JsonProcessingException
	 * @throws JSONException
     * @throws RbacValidationException
     */
    @Transactional
    public void onCommand(String organisationUuid)
            throws JsonProcessingException, JSONException, RbacValidationException {
		UiHeader header = organisationCommonUtils
				.buildUiHeader();
		 BaseAudit audit = organisationCommonUtils.getBaseAudit();
		Map<String, String> eventContext =
				Optional.ofNullable(ThreadLocalHeaderContext.getContext().getEventContext())
						.orElseGet(HashMap::new);
		try {
            if (rbacServiceImpl.isAuthorised(
					header.getXaccessToken(),
                    OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION)) {
                Optional<RecognisingOrganisation> organisationDetails =
                        organisationCommonUtils.getOrganisationViewDetails(
                                organisationUuid);

                if (!organisationDetails.isPresent()) {
                    final Set<ConstraintViolation<Object>> violations =
                            organisationCommonUtils.getSetforNullViolationOfEventBody(
                                    "V0043", "OrganisationNotFound");
                    generateRejectedEventResponse(
                            header,
                            audit,
                            violations,
                            eventContext.getOrDefault(
                                    OrganisationConstants.GenericConstants
                                            .RECOGNISING_ORGANISATION_UUID,
                                    null));
                } else {
                    registerandPublishViewOrganisationEvent(
                            header,
                            audit,
                            organisationDetails.get());
                }
            } else {
                final Set<ConstraintViolation<Object>> violations =
                        organisationCommonUtils.getSetforNullViolationOfEventBody(
                                "V0044", "UnauthorisedToViewOrganisation");
                generateRejectedEventResponse(
                        header,
                        audit,
                        violations,
                        eventContext.getOrDefault(
                                OrganisationConstants.GenericConstants
                                        .RECOGNISING_ORGANISATION_UUID,
                                null));
            }
        } catch (Exception e) {
            log.error("Exception in View Organisation Domain Service:  ", e);
            throw e;
        }
    }

    void generateRejectedEventResponse(
            final BaseHeader roHeader,
            final BaseAudit audit,
            final Set<ConstraintViolation<Object>> violations,
            final String dataRecord)
            throws JsonProcessingException {

        roHeader.setEventName(OrganisationConstants.EventType.RO_VIEW_DETAILS_REJECTED_EVENT);
        CMDSErrorResponse eventErrors =
                errorResolver.populatErrorResponse(
                        violations, OrganisationConstants.EventType.RO_VIEW_DETAILS_REJECTED_EVENT);
        BaseEventErrors baseEventErrors = new BaseEventErrors(eventErrors.getErrorList());
        if (Objects.nonNull(dataRecord)) {
            audit.getAuditContext().put(OrganisationConstants.GenericConstants.RECORD, dataRecord);
        }
        BaseEvent<? extends BaseHeader> event =
                new BaseEvent<>(roHeader, null, baseEventErrors, audit);
        log.debug("BaseEvent : {}", objectMapper.writeValueAsString(event));
        applicationEventPublisher.publishEvent(event);
    }

    void registerandPublishViewOrganisationEvent(
            final BaseHeader eventHeaders,
            final BaseAudit audit,
            final RecognisingOrganisation recognisingOrganisation)
            throws JsonProcessingException, JSONException {
        eventHeaders.setEventName(OrganisationConstants.EventType.RO_VIEW_DETAILS_EVENT);
        eventHeaders.setEventDateTime(LocalDateTime.now());

        RoRequestedEventV1 eventBody = entityToEventMapper(recognisingOrganisation);

        BaseEvent<? extends BaseHeader> event =
                new BaseEvent<>(
                        eventHeaders, objectMapper.writeValueAsString(eventBody), null, audit);
        applicationEventPublisher.publishEvent(event);
    }
    public RoRequestedEventV1 entityToEventMapper(RecognisingOrganisation publishRo) throws JSONException, JsonProcessingException {
		 
		 RoRequestedEventV1 roRequestedEvent = new RoRequestedEventV1();
		 Optional<PartnerCode> partnerCode =partnerCodeRepository.findByPartnersCode(publishRo.getPartnerCode());
	        roRequestedEvent.setRecognisingOrganisationUuid(publishRo.getRecognisingOrganisationUuid());
	        roRequestedEvent.setOrganisationName(publishRo.getName());
	        roRequestedEvent.setOrganisationId(publishRo.getOrganisationId());
	        roRequestedEvent.setOrganisationTypeUuid(publishRo.getOrganisationTypeUuid());
	        roRequestedEvent.setOrganisationType(
	        		organisationCommonUtils.getOrganisationTypeFromUuid(
	                        organisationTypeRepository.findAll(),
	                        roRequestedEvent.getOrganisationTypeUuid()));
	        roRequestedEvent.setOrganisationStatus(OrganisationStatusEnum.valueOf(publishRo.getOrgStatus().getValue()));
	        roRequestedEvent.setVerificationStatus(VerificationStatusEnum.valueOf(publishRo.getVerificationStatus().getValue()));
	        roRequestedEvent.setAddresses(organisationCommonUtils.setAddressesForOrganisationAddresses(publishRo.getAddresses()));
            if(partnerCode.isPresent()) {
            
            	roRequestedEvent.setPartnerName(partnerCode.get().getPartnerName());
            }
	        
	        roRequestedEvent.setPartnerCode(publishRo.getPartnerCode());
	        roRequestedEvent.setPartnerContact(publishRo.getPartnerContact());
	        roRequestedEvent.setMethodOfDelivery(publishRo.getMethodOfDelivery());
	        roRequestedEvent.setSectorTypeUuid(publishRo.getSectorTypeUuid());
	        roRequestedEvent.setSectorType(
	        		organisationCommonUtils.getSectorTypeFromUuid(
	                        sectorTypeRepository.findAll(), roRequestedEvent.getSectorTypeUuid()));
	        roRequestedEvent.setWebsiteUrl(publishRo.getWebsiteUrl());
	        roRequestedEvent.setCrmSystem(publishRo.getCrmSystem());
	        roRequestedEvent.setOrganisationCode(publishRo.getOrganisationCode());
	        roRequestedEvent.setResultAvailableForYears(
	        		organisationCommonUtils.populateResultAvailableForYears(publishRo.getResultAvailableForYears()));
	        roRequestedEvent.setIeltsDisplayFlag(
	        		organisationCommonUtils.populateIeltsFlag(
	                        publishRo.getOrganisationTypeUuid(), publishRo.getIeltsDisplayFlag()));
	        roRequestedEvent.setOrsDisplayFlag(organisationCommonUtils.populateOrsFlag(publishRo.getOrsDisplayFlag()));
	        roRequestedEvent.setNotes(organisationCommonUtils.getNotes(publishRo));
	        roRequestedEvent.setAlternateNames(organisationCommonUtils.getAlternateNames(publishRo));
	        roRequestedEvent.setContacts(organisationCommonUtils.getContacts(publishRo));
	        roRequestedEvent.setMinimumScores(organisationCommonUtils.getMinimumScores(publishRo));
	        roRequestedEvent.setSoftDeleted(publishRo.getSoftDeleted());
	        acceptSSRAndAcceptIOLFlagMap(publishRo.getRecognisedProducts(), roRequestedEvent);
           roRequestedEvent.setLinkedOrganisations(organisationCommonUtils.getLinkedOrganisations(publishRo));
	        roRequestedEvent.setParentOrgId(
	        		organisationCommonUtils.getParentOrg(publishRo.getLinkedRecognisingOrganisations()).getOrganisationId());
	        return roRequestedEvent; 
	 }
    
	 protected void acceptSSRAndAcceptIOLFlagMap(
	            List<RecognisedProduct> recognisedProducts, RoRequestedEventV1 roRequestedEventV1) throws JSONException, JsonProcessingException {

		 Set<UUID> recognisedProductUUidActiveList =
	                recognisedProducts.stream()
	                        .filter(
	                                product ->
	                                        product.getEffectiveToDatetime()
	                                                .isAfter(OffsetDateTime.now(ZoneOffset.UTC)))
	                        .map(RecognisedProduct::getProductUuid)
	                        .collect(Collectors.toSet());
	        Map<String, Boolean> acceptsSSRAcceptsIOLAcceptsACAcceptsGTMap = new HashMap<>();
		 acceptsSSRAcceptsIOLAcceptsACAcceptsGTMap.put(OrganisationConstants.GenericConstants.IOL, Boolean.FALSE);
		 acceptsSSRAcceptsIOLAcceptsACAcceptsGTMap.put(OrganisationConstants.GenericConstants.SSR, Boolean.FALSE);
		 acceptsSSRAcceptsIOLAcceptsACAcceptsGTMap.put(OrganisationConstants.GenericConstants.AC, Boolean.FALSE);
		 acceptsSSRAcceptsIOLAcceptsACAcceptsGTMap.put(OrganisationConstants.GenericConstants.GT, Boolean.FALSE);
	        organisationCommonUtils.getIOLSSRACGTFlagsBasedOnExistingActiveProductUuidList(
	        		recognisedProductUUidActiveList, acceptsSSRAcceptsIOLAcceptsACAcceptsGTMap);
	        roRequestedEventV1.setAcceptsIOL(acceptsSSRAcceptsIOLAcceptsACAcceptsGTMap.get(OrganisationConstants.GenericConstants.IOL));
	        roRequestedEventV1.setAcceptsSSR(acceptsSSRAcceptsIOLAcceptsACAcceptsGTMap.get(OrganisationConstants.GenericConstants.SSR));
		 	roRequestedEventV1.setAcceptsAC(acceptsSSRAcceptsIOLAcceptsACAcceptsGTMap.get(OrganisationConstants.GenericConstants.AC));
		 	roRequestedEventV1.setAcceptsGT(acceptsSSRAcceptsIOLAcceptsACAcceptsGTMap.get(OrganisationConstants.GenericConstants.GT));
	 }

}
