package com.ielts.cmds.organisation.infrastructure.repository;

import com.ielts.cmds.api.roui007rocreaterequested.LinkTypeEnum;
import com.ielts.cmds.organisation.infrastructure.entity.LinkedRecognisingOrganisation;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LinkedRecognisingOrganisationRepository
        extends JpaRepository<LinkedRecognisingOrganisation, UUID> {

    Optional<LinkedRecognisingOrganisation>
            findBySourceRecognisingOrganisationRecognisingOrganisationUuidAndLinkedRecognisingOrganisationTypeAndEffectiveToDatetimeAfter(
                    UUID parentOrganisationUuid, LinkTypeEnum linkType, OffsetDateTime currentDate);

    List<LinkedRecognisingOrganisation>
            findBySourceRecognisingOrganisationRecognisingOrganisationUuidAndLinkedRecognisingOrganisationTypeOrTargetRecognisingOrganisationRecognisingOrganisationUuidAndLinkedRecognisingOrganisationType(
                    UUID sourceUuuid,
                    LinkTypeEnum linkType,
                    UUID targetUuid,
                    LinkTypeEnum linkTypeEnum);

    default List<LinkedRecognisingOrganisation> findBySourceAndLinkTypeOrTargetAndLinkType(
            UUID sourceUuuid, LinkTypeEnum linkType, UUID targetUuid,LinkTypeEnum linkTypeEnum) {
        return findBySourceRecognisingOrganisationRecognisingOrganisationUuidAndLinkedRecognisingOrganisationTypeOrTargetRecognisingOrganisationRecognisingOrganisationUuidAndLinkedRecognisingOrganisationType(
                sourceUuuid, linkType, targetUuid, linkTypeEnum);
    }

    List<LinkedRecognisingOrganisation>
            findByLinkedRecognisingOrganisationTypeAndOrganisationHierarchyLabel(
            LinkTypeEnum linkType, String label);

    List<LinkedRecognisingOrganisation>
            findByTargetRecognisingOrganisationRecognisingOrganisationUuidAndLinkedRecognisingOrganisationType(
                    UUID targetUuid, LinkTypeEnum linkType);

    default List<LinkedRecognisingOrganisation> findByTargetRoUuidAndParentOrganisationType(
            UUID targetRoUuid, LinkTypeEnum parentLinkType) {
        return findByTargetRecognisingOrganisationRecognisingOrganisationUuidAndLinkedRecognisingOrganisationType(
                targetRoUuid, parentLinkType);
    }

    List<LinkedRecognisingOrganisation> findAllByOrganisationHierarchyLabel(String orgId);

}
