package com.ielts.cmds.organisation.domain.services;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.roui007rocreaterequested.VerificationStatusEnum;
import com.ielts.cmds.api.roui010rohierarchyrequested.ROHierarchyRequestParam;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.common.out.event.RoDetailsDataGeneratedEventV1;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.LinkedRecognisingOrganisationRepository;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.rbac.api.service.impl.RBACServiceImpl;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import javax.validation.ConstraintViolation;

import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** @author CTS */
@Service
@Slf4j
public class SearchForHierarchyDomainService extends AbstractCMDSDomainService<RoDetailsDataGeneratedEventV1>  {

    @Autowired private RBACServiceImpl rbacServiceImpl;

    @Autowired private ObjectMapper objectMapper;

    @Autowired private ApplicationEventPublisher applicationEventPublisher;

    @Autowired private OrganisationCommonUtils organisationCommonUtils;

    @Autowired private CMDSErrorResolver<Object> errorResolver;

    @Autowired private SearchByOrgIdDomainService searchByOrgIdDomainService;

    @Autowired
    private LinkedRecognisingOrganisationRepository linkedRecognisingOrganisationRepository;

    @Autowired
    public SearchForHierarchyDomainService(ApplicationEventPublisher publisher, ObjectMapper objectMapper, @Value("${searchForHierarchyDomain.v2}") String isV2Enabled, CMDSThreadLocalContextService cmdsThreadLocalContextService) {
        super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
    }

    @Transactional
    public void onCommand(ROHierarchyRequestParam eventBody) {
        try {
            BaseHeader header = organisationCommonUtils.buildUiHeader();

            if (rbacServiceImpl.isAuthorised(
                    ThreadLocalHeaderContext.getContext().getXaccessToken(),
                    OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION)) {
                if (eventBody != null) {
                    Set<RecognisingOrganisation> finalHierarchyList = new HashSet<>();
                    if (StringUtils.isNotEmpty(
                            String.valueOf(eventBody.getRecognisingOrganisationUuid()))
                            && StringUtils.isNotBlank(
                            String.valueOf(eventBody.getRecognisingOrganisationUuid()))) {
                       finalHierarchyList.addAll(searchWithRecognisingOrganisationsUuid(eventBody));
                    }
                    if (StringUtils.isNotEmpty(
                            String.valueOf(eventBody.getParentROUuid()))
                            && eventBody.getParentROUuid() != null) {
                       finalHierarchyList.addAll(searchWithParentROUuidUuid(eventBody));
                    }
                  
                    organisationCommonUtils.publishForRODetailsDataGenerated(
                            header,
                            finalHierarchyList,
                            organisationCommonUtils.getBaseAudit());
                }
            } else {
                final Set<ConstraintViolation<Object>> violations =
                        organisationCommonUtils.getSetforNullViolationOfEventBody(
                                "V0044", "UnauthorisedToViewOrganisation");
                organisationCommonUtils.generateRejectedEventResponse(
                        header,
                        violations,
                        organisationCommonUtils.getBaseAudit(),
                        ThreadLocalHeaderContext.getContext()
                                .getEventContext()
                                .get("recognisingOrganisationUuid"));
            }

        } catch (Exception e) {
            log.error("Exception in Search for Organisation Hierarchy Domain Service:  ", e);
        }
    }
    public Set<RecognisingOrganisation> searchWithRecognisingOrganisationsUuid(ROHierarchyRequestParam eventBody){
		Set<RecognisingOrganisation> hierarchyList = new HashSet<>();
		Set<RecognisingOrganisation> hierarchyListOfRoUuid = organisationCommonUtils.getChildHierarchyBasedOnRO(
				UUID.fromString(String.valueOf(eventBody.getRecognisingOrganisationUuid())),
				eventBody.getOnlyImmediateChildren());
		for (RecognisingOrganisation recognisingOrganisation : hierarchyListOfRoUuid) {
			if (recognisingOrganisation.getVerificationStatus() != VerificationStatusEnum.VERIFIED) {
				hierarchyList.add(recognisingOrganisation);
			}
		}
		return hierarchyList;
	}
    public Set<RecognisingOrganisation> searchWithParentROUuidUuid(ROHierarchyRequestParam eventBody){
		Set<RecognisingOrganisation> hierarchyList = new HashSet<>();
		Set<RecognisingOrganisation> hierarchyListOfParentROUuid =
                organisationCommonUtils
                        .getHierarchyBasedOnRecognisingOrganisationUuid(
                                UUID.fromString(
                                        String.valueOf(eventBody.getParentROUuid())));
        for (RecognisingOrganisation recognisingOrganisation : hierarchyListOfParentROUuid) {
        	if(recognisingOrganisation.getVerificationStatus() != VerificationStatusEnum.VERIFIED) {
        		hierarchyList.add(recognisingOrganisation);
        	}
        }
		return hierarchyList;
	}
}
