package com.ielts.cmds.organisation.domain.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.organisation.domain.commands.OrganisationPrimmingCommand;
import com.ielts.cmds.organisation.domain.model.OrganisationPrimmingModel;
import com.ielts.cmds.organisation.domain.utils.DomainEventsPublisher;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
public class OrganisationPrimmingDomainService {

    @Autowired private ObjectMapper objectMapper;

    @Autowired private DomainEventsPublisher domainEventPublisher;

    @Autowired private RecognisingOrganisationRepository orgRepository;

    @Autowired private OrganisationCommonUtils organisationCommonUtils;

    @Transactional
    public void onCommand(final OrganisationPrimmingCommand organisationPrimmingCommand)
            throws JsonProcessingException {
        long startTime = System.currentTimeMillis();
        log.debug(
                "Inside onCommand of Organisation Primming Method: {}",
                organisationPrimmingCommand);
        final OrganisationPrimmingModel eventBody = organisationPrimmingCommand.getEventBody();
        if (Objects.nonNull(eventBody)) {
            List<RecognisingOrganisation> orgsToBePublished =
                    orgRepository.findByRecognisingOrganisationUuidIn(
                            eventBody.getOrganisationsToBePublished());
            List<BaseEvent<BaseHeader>> publishingEventList = new ArrayList<>();
            for (RecognisingOrganisation organisation : orgsToBePublished) {
                BaseEvent<BaseHeader> roChangedEvent =
                        generateRoChangedEvent(
                                organisationPrimmingCommand.getEventHeaders(),
                                organisationPrimmingCommand.getAudit(),
                                organisation);
                publishingEventList.add(roChangedEvent);
            }
            domainEventPublisher.baseEventListPublisher(publishingEventList);
            log.debug("Published all the events of list : {}", publishingEventList.toString());
            long duration = System.currentTimeMillis() - startTime;
            log.debug("Time took to process {} records: {}", orgsToBePublished.size(), duration);
        }
    }

    public BaseEvent<BaseHeader> generateRoChangedEvent(
            final BaseHeader baseHeader,
            final BaseAudit audit,
            final RecognisingOrganisation publishRO)
            throws JsonProcessingException {
        BaseHeader header =
                generateHeader(baseHeader, OrganisationConstants.EventType.RO_UPDATED_EVENT);
        header.setEventDateTime(LocalDateTime.now());
        header.setPartnerCode(publishRO.getPartnerCode());
        organisationCommonUtils.setEventDiscriminatorForExternalSystems(header, publishRO);
        RoChangedEventV1 orgUpdateEvent = organisationCommonUtils.entityToEventMapper(publishRO);

        return new BaseEvent<>(
                header, objectMapper.writeValueAsString(orgUpdateEvent), null, audit);
    }

    public BaseHeader generateHeader(final BaseHeader header, final String eventName) {
        BaseHeader roHeaders = new BaseHeader();
        roHeaders.setTransactionId(header.getTransactionId());
        roHeaders.setCorrelationId(UUID.randomUUID());
        roHeaders.setCallbackURL(header.getCallbackURL());
        roHeaders.setEventContext(header.getEventContext());
        roHeaders.setEventDateTime(header.getEventDateTime());
        roHeaders.setEventDateTimeAsString(header.getEventDateTimeAsString());
        roHeaders.setEventDiscriminator(header.getEventDiscriminator());
        roHeaders.setEventName(eventName);
        roHeaders.setPartnerCode(header.getPartnerCode());
        roHeaders.setXaccessToken(header.getXaccessToken());
        return roHeaders;
    }
}
