package com.ielts.cmds.organisation.domain.services;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.common.out.event.RoDetailsDataGeneratedEventV1;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.rbac.api.service.impl.RBACServiceImpl;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import javax.validation.ConstraintViolation;

import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** @author CTS */
@Service
@Slf4j
public class SearchByOrgIdDomainService extends AbstractCMDSDomainService<RoDetailsDataGeneratedEventV1>  {

    @Autowired private RBACServiceImpl rbacServiceImpl;

    @Autowired private OrganisationCommonUtils organisationCommonUtils;

    @Autowired
    public SearchByOrgIdDomainService(ApplicationEventPublisher publisher, ObjectMapper objectMapper, @Value("${searchByOrgIdDomain.v2}") String isV2Enabled, CMDSThreadLocalContextService cmdsThreadLocalContextService) {
        super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
    }

    @Transactional
    public void onCommand(Integer eventBody) {
        Map<String, String> eventContext =
                Optional.ofNullable(ThreadLocalHeaderContext.getContext().getEventContext())
                        .orElseGet(HashMap::new);
        try {
            BaseHeader header = organisationCommonUtils.buildUiHeader();
              if (rbacServiceImpl.isAuthorised(
                    ThreadLocalHeaderContext.getContext().getXaccessToken(),
                    OrganisationConstants.GenericConstants.RO_ORG_VIEW_PERMISSION)) {
                Optional<RecognisingOrganisation> recognisingOrganisation =
                        organisationCommonUtils.getOrganisationByOrgId(
                                eventBody);
                Set<RecognisingOrganisation> recognisingOrganisationSet = new HashSet<>();
                if (recognisingOrganisation.isPresent()) {
                    recognisingOrganisationSet.add(recognisingOrganisation.get());
                }
                organisationCommonUtils.publishForRODetailsDataGenerated(
                        header,
                        recognisingOrganisationSet,
                        organisationCommonUtils.getBaseAudit());

            } else {
                final Set<ConstraintViolation<Object>> violations =
                        organisationCommonUtils.getSetforNullViolationOfEventBody(
                                "V0044", "UnauthorisedToViewOrganisation");
                organisationCommonUtils.generateRejectedEventResponse(
                        header,
                           violations,
                        organisationCommonUtils.getBaseAudit(),
                        eventContext.getOrDefault(
                                OrganisationConstants.GenericConstants.ORGANISATION_ID, null));
            }
        } catch (Exception e) {
            log.error("Exception in Search by Organisation Id Domain Service:  ", e);
        }
    }
}
