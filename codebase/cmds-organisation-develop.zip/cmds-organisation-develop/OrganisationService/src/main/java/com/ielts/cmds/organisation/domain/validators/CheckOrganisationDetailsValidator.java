package com.ielts.cmds.organisation.domain.validators;


import com.ielts.cmds.api.roui007rocreaterequested.LinkTypeEnum;
import com.ielts.cmds.api.roui007rocreaterequested.MethodOfDeliveryEnum;
import com.ielts.cmds.api.roui007rocreaterequested.VerificationStatusEnum;
import com.ielts.cmds.api.roui007rocreaterequested.OrganisationStatusEnum;
import com.ielts.cmds.organisation.domain.model.RoDataCreateV1Valid;
import com.ielts.cmds.organisation.domain.model.RoDataUpdateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.Country;
import com.ielts.cmds.organisation.infrastructure.entity.ModuleType;
import com.ielts.cmds.organisation.infrastructure.entity.OrganisationType;
import com.ielts.cmds.organisation.infrastructure.entity.PartnerCode;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.entity.SectorType;
import com.ielts.cmds.organisation.infrastructure.entity.Territory;
import com.ielts.cmds.organisation.infrastructure.repository.CountryRepository;
import com.ielts.cmds.organisation.infrastructure.repository.ModuleTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.OrganisationTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.PartnerCodeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.infrastructure.repository.SectorTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.TerritoryRepository;
import com.ielts.cmds.organisation.utils.OrganisationConstants;

import java.time.OffsetDateTime;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.regex.Pattern;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.validation.ConstraintValidatorContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

/**
 * Class used to validate All the mandatory fields are present in the create Organisation Request.
 */
@Slf4j
@Component
public class CheckOrganisationDetailsValidator {

    @Autowired private SectorTypeRepository sectorTypeRepository;

    @Autowired private CountryRepository countryRepository;

    @Autowired private PartnerCodeRepository partnerRepository;

    @Autowired private TerritoryRepository territoryRepository;

    @Autowired private ModuleTypeRepository moduleTypeRepository;

    @Autowired protected OrganisationTypeRepository orgTypeRepository;

    @Autowired protected RecognisingOrganisationRepository recognisingOrganisationRepository;

    private static final Pattern URLREGX = Pattern.compile("^((https?):\\/\\/)?[-a-zA-Z0-9+&@#\\/%?=~_|!:,.;]*[-a-zA-Z0-9+?&@#\\/%=~_|.]");
    private static final Pattern myRegex = Pattern.compile("\\s");
    protected void addConstraintViolation(
            ConstraintValidatorContext context, String messageTemplate, String propertyNode) {
        context.buildConstraintViolationWithTemplate(messageTemplate)
                .addPropertyNode(propertyNode)
                .addConstraintViolation();
    }
    protected boolean isValidVerificationStatusForActiveApprovedROUpdate(
    		RecognisingOrganisation existingRO,
    		RoDataUpdateV1Valid roDataUpdate,
            ConstraintValidatorContext context,
            boolean isValidRoDetails){
		if (existingRO.getOrgStatus() == OrganisationStatusEnum.ACTIVE &&VerificationStatusEnum.APPROVED.getValue().equals(existingRO.getVerificationStatus().getValue())
				&& VerificationStatusEnum.VERIFIED.getValue().equals(roDataUpdate.getVerificationStatus().getValue())) {
				log.debug("You can't update Active RO Verification Status from approved to verified");
				isValidRoDetails = false;
				addConstraintViolation(context, "{cmds.invalid.verificationStatus}", "verificationStatus");
		}
        return isValidRoDetails;
    }

    protected boolean isValidVOVerificationStatusEnum(
            VerificationStatusEnum verificationStatus,
            ConstraintValidatorContext context,
            boolean isValidVoDetails) {
        if (VerificationStatusEnum.APPROVED.getValue().equals(verificationStatus.getValue())) {
            log.debug("For VO Verification Status should be PENDING or VERIFIED or REJECTED");
            isValidVoDetails = false;
            addConstraintViolation(
                    context, "{cmds.invalid.verificationStatus}", "verificationStatus");
        }
        return isValidVoDetails;
    }

    protected boolean isValidWebsiteUrl(
            String websiteUrl, ConstraintValidatorContext context, boolean isValidRoDetails) {
        if (!StringUtils.hasText(websiteUrl)
                || !URLREGX.matcher(websiteUrl).matches()) {
            isValidRoDetails = false;
            log.debug("URL is not valid/empty");
            addConstraintViolation(context, "{cmds.invalid.websiteUrl}", "websiteUrl");
        }
        return isValidRoDetails;
    }

    protected boolean isValidROMethodOfDeliveryEnum(
            MethodOfDeliveryEnum methodOfDelivery,
            ConstraintValidatorContext context,
            boolean isValidRoDetails) {
        if (!(MethodOfDeliveryEnum.POSTAL==methodOfDelivery
                        || MethodOfDeliveryEnum.E_DELIVERY==methodOfDelivery)) {
            isValidRoDetails = false;
            log.debug("Method of Delivery should be POSTAL or E-DELIVERY");
            addConstraintViolation(context, "{cmds.invalid.methodOfDelivery}", "methodOfDelivery");
        }
        return isValidRoDetails;
    }

    protected boolean isValidVOMethodOfDeliveryEnum(
            MethodOfDeliveryEnum methodOfDelivery,
            ConstraintValidatorContext context,
            boolean isValidVoDetails) {
        if (!MethodOfDeliveryEnum.POSTAL.getValue().equals(methodOfDelivery.name())) {
            isValidVoDetails = false;
            log.debug("For VO Method of Delivery should be POSTAL");
            addConstraintViolation(context, "{cmds.invalid.methodOfDelivery}", "methodOfDelivery");
        }
        return isValidVoDetails;
    }

    protected int checkPrimaryContact(String contactName, int primaryContactCount) {

        if (OrganisationConstants.GenericConstants.PRIMARY_CONTACT.equals(contactName)) {
            primaryContactCount++;
        }
        return primaryContactCount;
    }

    protected int checkResultsAdminContact(String contactName, int resultsAdminContactCount) {

        if (OrganisationConstants.GenericConstants.RESULT_ADMIN.equals(contactName)) {
            resultsAdminContactCount++;
        }
        return resultsAdminContactCount;
    }

    protected boolean isValidEmail(
            String email,
            String contactTypeName,
            ConstraintValidatorContext context,
            boolean isValidContact,
            String verificationStatus) {
        if (StringUtils.hasText(email)) {
            try {
                InternetAddress address = new InternetAddress(email, true);
                address.validate();
            } catch (AddressException e) {
                log.error("AddressException{}",e);
                isValidContact = false;
                /*
                 * Appending contactTypeName to the violation template to differentiate which
                 * contact type is causing the violation and removing the spaces if any in the
                 * contactTypeName because spaces can't be there in the properties.
                 */
                addConstraintViolation(
                        context,
                        "{cmds.invalid.email." + contactTypeName.replaceAll(String.valueOf(myRegex), "") + "}",
                        OrganisationConstants.GenericConstants.ADDRESS_PROPERTY_NODE);
            }
        } else if(Objects.equals(verificationStatus, VerificationStatusEnum.VERIFIED.getValue())
                && Objects.equals(contactTypeName, OrganisationConstants.GenericConstants.RESULT_ADMIN)){
            isValidContact = true;
        }else{
            isValidContact = false;
            addConstraintViolation(
                    context,
                    "{cmds.invalid.email." + contactTypeName.replaceAll(String.valueOf(myRegex), "") + "}",
                    OrganisationConstants.GenericConstants.ADDRESS_PROPERTY_NODE);
        }
        return isValidContact;
    }

    protected boolean isEmptyOrganisationName(
            String organisationName,
            ConstraintValidatorContext context,
            boolean isValidOrganisationDetails) {
        if (!StringUtils.hasText(organisationName)) {
            log.debug("Organisation Name is Empty");
            isValidOrganisationDetails = false;
            addConstraintViolation(context, "{cmds.invalid.organisationName}", "organisationName");
        }
        return isValidOrganisationDetails;
    }

    protected boolean isEmptyKnownName(
            String firstName,
            String lastName,
            ConstraintValidatorContext context,
            String contactTypeName,
            boolean isValidContact) {
        if (!StringUtils.hasText(firstName)) {
            log.debug("First Name is Empty");
            isValidContact = false;
            /*
             * Appending contactTypeName to the violation template to differentiate which
             * contact type is causing the violation and removing the spaces if any in the
             * contactTypeName because spaces can't be there in the properties.
             */
            addConstraintViolation(
                    context,
                    "{cmds.invalid.firstName." + contactTypeName.replaceAll(String.valueOf(myRegex), "") + "}",
                    OrganisationConstants.GenericConstants.CONTACTS_PROPERTY_NODE);
        }
        if (!StringUtils.hasText(lastName)) {
            log.debug("Last Name is Empty");
            isValidContact = false;
            /*
             * Appending contactTypeName to the violation template to differentiate which
             * contact type is causing the violation and removing the spaces if any in the
             * contactTypeName because spaces can't be there in the properties.
             */
            addConstraintViolation(
                    context,
                    "{cmds.invalid.lastName." + contactTypeName.replaceAll(String.valueOf(myRegex), "") + "}",
                    OrganisationConstants.GenericConstants.CONTACTS_PROPERTY_NODE);
        }
        return isValidContact;
    }

    protected boolean isValidModuleTypeUuid(
            UUID moduleTypeUuid, ConstraintValidatorContext context, boolean isValidRoVoDetails) {
        Optional<ModuleType> moduleType = moduleTypeRepository.findById(moduleTypeUuid);
        if (!moduleType.isPresent()) {
            log.debug("Module Type is not valid");
            isValidRoVoDetails = false;
            addConstraintViolation(context, "{cmds.invalid.moduleTypeUuid}", "minimumScores");
        }
        return isValidRoVoDetails;
    }

    /**
     * Method to validate the SectorType from the reference data
     *
     * @param sectorTypeUuid
     * @param context
     * @return
     */
    protected boolean isValidSectorType(
            UUID sectorTypeUuid, ConstraintValidatorContext context, boolean isValidSectorType) {
        Optional<SectorType> optSectorType = Optional.empty();
        if (sectorTypeUuid != null) {
            optSectorType = sectorTypeRepository.findById(sectorTypeUuid);
        }
        if (!optSectorType.isPresent()) {
            log.debug("Sector Type is not valid");
            isValidSectorType = false;
            addConstraintViolation(context, "{cmds.invalid.sectorTypeUuid}", "sectorTypeUuid");
        }
        return isValidSectorType;
    }

    /**
     * Method to validate mandatory field PartnerCode.
     *
     * @param partnerCode
     * @param context
     * @return
     */
    protected boolean isValidPartnerCode(
            String partnerCode, ConstraintValidatorContext context, boolean isValidPartnerCode) {
        Optional<PartnerCode> optPartnerCode = Optional.empty();
        if (!StringUtils.isEmpty(partnerCode)) {
            optPartnerCode = partnerRepository.findByPartnersCode(partnerCode);
        }
        if (!optPartnerCode.isPresent()) {
            log.debug("Partner Code is not Valid");
            isValidPartnerCode = false;
            addConstraintViolation(context, "{cmds.invalid.partnerCode}", "partnerCode");
        }
        return isValidPartnerCode;
    }

    /**
     * Method to check Address Related Validations.
     *
     * @param roDataCreateAddress
     * @param context
     * @return
     */

    /**
     * Method to validate if the request contains Main and Delivery Addresses.
     *
     * @param mainAddressCount
     * @param deliveryAddressCount
     * @param context
     * @param isValidAddress
     * @return
     */
    protected boolean checkMainAndDeliveryAddress(
            int mainAddressCount,
            int deliveryAddressCount,
            ConstraintValidatorContext context,
            boolean isValidAddress) {

        if (mainAddressCount != 1) {
            isValidAddress = false;
            log.debug("Missing Main Address/ Multiple Main Addresses");
            addConstraintViolation(
                    context,
                    "{cmds.invalid.mainAddress}",
                    OrganisationConstants.GenericConstants.ADDRESS_PROPERTY_NODE);
        }

        if (deliveryAddressCount != 1) {
            isValidAddress = false;
            log.debug("Missing Delivery Address/ Multiple Delivery Addresses");
            addConstraintViolation(
                    context,
                    "{cmds.invalid.deliveryAddress}",
                    OrganisationConstants.GenericConstants.ADDRESS_PROPERTY_NODE);
        }
        return isValidAddress;
    }

    protected int countMainAddress(String addressTypeName, int mainAddressCount) {
        if (OrganisationConstants.GenericConstants.MAIN_ADDRESS_TYPE.equals(addressTypeName)) {
            mainAddressCount++;
        }
        return mainAddressCount;
    }

    protected int countDeliveryAddress(String addressTypeName, int deliveryAddressCount) {
        if (OrganisationConstants.GenericConstants.DELIVERY_ADDRESS_TYPE.equals(addressTypeName)) {
            deliveryAddressCount++;
        }
        return deliveryAddressCount;
    }

    /**
     * Method to validate if the Request contains the Primary and ResultsAdmin Contacts.
     *
     * @param primaryContactCount
     * @param resultsAdminContactCount
     * @param context
     * @param isValidContact
     * @return
     */
    protected boolean checkPrimaryandResultsAdminContact(
            int primaryContactCount,
            int resultsAdminContactCount,
            ConstraintValidatorContext context,
            boolean isValidContact) {

        if (primaryContactCount != 1) {
            isValidContact = false;
            log.debug("Missing Primary Contact/ Multiple Primary Contacts");
            addConstraintViolation(
                    context,
                    "{cmds.invalid.primaryContact}",
                    OrganisationConstants.GenericConstants.CONTACTS_PROPERTY_NODE);
        }

        if (resultsAdminContactCount != 1) {
            isValidContact = false;
            log.debug("Missing Results Admin Contact/ Multiple Results Admin Contacts");
            addConstraintViolation(
                    context,
                    "{cmds.invalid.resultsAdminContact}",
                    OrganisationConstants.GenericConstants.CONTACTS_PROPERTY_NODE);
        }
        return isValidContact;
    }

    /**
     * Method to validate the mandatory field addressLine1.
     *
     * @param addressLine
     * @param addressTypeName
     * @param context
     * @param isValidAddress
     * @return
     */
    protected boolean mandatoryAddressLineCheck(
            String addressLine,
            String addressTypeName,
            ConstraintValidatorContext context,
            boolean isValidAddress) {
        if (!StringUtils.hasText(addressLine)) {
            log.debug("Address Line is empty");
            isValidAddress = false;
            /*
             * Appending the addressTypeName in the violation template to differentiate
             * which address type is causing the violation.
             */
            addConstraintViolation(
                    context,
                    "{cmds.invalid.addressline1." + addressTypeName + "}",
                    OrganisationConstants.GenericConstants.ADDRESS_PROPERTY_NODE);
        }
        return isValidAddress;
    }

    /**
     * Method to validate the mandatory field city.
     *
     * @param city
     * @param addressTypeName
     * @param context
     * @param isValidAddress
     * @return
     */
    protected boolean mandatoryCityCheck(
            String city,
            String addressTypeName,
            ConstraintValidatorContext context,
            boolean isValidAddress) {
        if (!StringUtils.hasText(city)) {
            log.debug("City is mandatory");
            isValidAddress = false;
            /*
             * Appending the addressTypeName in the violation template to differentiate
             * which address type is causing the violation.
             */
            addConstraintViolation(
                    context,
                    "{cmds.invalid.city." + addressTypeName + "}",
                    OrganisationConstants.GenericConstants.ADDRESS_PROPERTY_NODE);
        }
        return isValidAddress;
    }

    /**
     * Method to validate the mandatory field countryUuid with the DB values.
     *
     * @param countryUuid
     * @param addressTypeName
     * @param context
     * @param isValidAddress
     * @return
     */
    protected boolean isValidCountry(
            UUID countryUuid,
            String addressTypeName,
            ConstraintValidatorContext context,
            boolean isValidAddress) {
        Optional<Country> optCountry = Optional.empty();
        if (countryUuid != null) {
            optCountry = countryRepository.findById(countryUuid);
        }
        if (!optCountry.isPresent()) {
            log.debug("Country is mandatory");
            isValidAddress = false;
            /*
             * Appending the addressTypeName in the violation template to differentiate
             * which address type is causing the violation.
             */
            addConstraintViolation(
                    context,
                    "{cmds.invalid.countryName." + addressTypeName + "}",
                    OrganisationConstants.GenericConstants.ADDRESS_PROPERTY_NODE);
        }
        return isValidAddress;
    }

    /**
     * Method to validate the territoryUuid field with the DB values.
     *
     * @param territoryUuid
     * @param addressTypeName
     * @param context
     * @param isValidAddress
     * @return
     */
    protected boolean isValidTerritory(
            UUID territoryUuid,
            String addressTypeName,
            ConstraintValidatorContext context,
            boolean isValidAddress) {
        if (territoryUuid != null) {
            Optional<Territory> optTerritory = territoryRepository.findById(territoryUuid);
            if (!optTerritory.isPresent()) {
                log.debug("TerritoryUuid is not valid");
                isValidAddress = false;
                /*
                 * Appending the addressTypeName in the violation template to differentiate
                 * which address type is causing the violation.
                 */
                addConstraintViolation(
                        context,
                        "{cmds.invalid.territoryUuid." + addressTypeName + "}",
                        OrganisationConstants.GenericConstants.ADDRESS_PROPERTY_NODE);
            }
        }
        return isValidAddress;
    }

    protected boolean isValidResultsAvailableForYears(
            Integer resultAvailableForYears, ConstraintValidatorContext context, boolean isValid) {
        if (resultAvailableForYears != null
                && (resultAvailableForYears < 2 || resultAvailableForYears > 10)) {
            isValid = false;
            log.debug("Number of Years Available for results should be in range of 2 to 10");
            addConstraintViolation(
                    context,
                    "{cmds.invalid.resultAvailableForYears}",
                    OrganisationConstants.GenericConstants.RESULT_AVAILABLE_FOR_YEARS);
        }
        return isValid;
    }

    protected boolean checkLinkedOrganisationValidation(
            UUID organisationTypeUuid,
            UUID targetRecognisingOrganisationUuid,
            LinkTypeEnum linkType,
            ConstraintValidatorContext context,
            boolean isValidTargetROUuid) {
        String linkedType = linkType.getValue().toLowerCase().replace("_", "");
        Optional<RecognisingOrganisation> linkedOrganisationDetails = Optional.empty();
        if (targetRecognisingOrganisationUuid != null) {
            linkedOrganisationDetails =
                    recognisingOrganisationRepository.findById(targetRecognisingOrganisationUuid);
        }
        if (!linkedOrganisationDetails.isPresent()) {
            isValidTargetROUuid = false;
            log.debug("Target Recognising Organisation Not Found");
            addConstraintViolation(
                    context,
                    "{cmds.invalid.targetRecognisingOrganisation." + linkedType + "}",
                    OrganisationConstants.GenericConstants.LINKED_ORGANISATIONS_PROPERTY_NODE);
        } else {
            if (LinkTypeEnum.PARENT_RO.getValue().equals(linkType.getValue())
                    && !OrganisationStatusEnum.ACTIVE
                            .getValue()
                            .equals(linkedOrganisationDetails.get().getOrgStatus().getValue())) {
                isValidTargetROUuid = false;
                addConstraintViolation(
                        context,
                        "{cmds.invalid.inactiveParent}",
                        OrganisationConstants.GenericConstants.LINKED_ORGANISATIONS_PROPERTY_NODE);
            }
            Optional<OrganisationType> linkedRoOrganisationType =
                    orgTypeRepository.findById(
                            linkedOrganisationDetails.get().getOrganisationTypeUuid());
            if (linkedRoOrganisationType.isPresent()
                    && !organisationTypeUuid.equals(
                            linkedRoOrganisationType.get().getOrganisationTypeUuid())) {
                isValidTargetROUuid = false;
                log.debug("Target Organisation type must be same as creating organisation type");
                addConstraintViolation(
                        context,
                        "{cmds.invalid.targetRecognisingOrganisation.OrganisationType."
                                + linkedType
                                + "}",
                        OrganisationConstants.GenericConstants.LINKED_ORGANISATIONS_PROPERTY_NODE);
            }
            isValidTargetROUuid = checkIfVOHasADOs(organisationTypeUuid, linkType, context, isValidTargetROUuid);

        }
        return isValidTargetROUuid;
    }

    public boolean checkIfVOHasADOs(UUID organisationTypeUuid, LinkTypeEnum linkType, ConstraintValidatorContext context,boolean isValidTargetUUID) {
        Optional<OrganisationType> organisationType =
                orgTypeRepository.findById(organisationTypeUuid);
        String linkedType = linkType.getValue().toLowerCase().replace("_", "");
        if(organisationType.isPresent() && LinkTypeEnum.RESULTS_DELIVERY.getValue().equals(linkType.getValue())
            && OrganisationConstants.GenericConstants.VERIFIED_ORGANISATION.equals(organisationType.get().getOrganisationsType())) {
            isValidTargetUUID = false;
            log.debug("VOs don't support ADOs");
            addConstraintViolation(
                    context,
                    "{cmds.invalid.invalidLinkTypeForVO"
                            + linkedType
                            + "}",
                    OrganisationConstants.GenericConstants.LINKED_ORGANISATIONS_PROPERTY_NODE);
        }
        return isValidTargetUUID;
    }

    protected boolean checkEffectiveFromDate(
            OffsetDateTime effectiveFromDateTime,
            OffsetDateTime effectiveToDateTime,
            ConstraintValidatorContext context,
            boolean isValidEffectiveFromAndToDate,
            String propertyNode) {
        if (effectiveFromDateTime != null
                && effectiveToDateTime != null
                && effectiveFromDateTime.isAfter(effectiveToDateTime)) {
            isValidEffectiveFromAndToDate = false;
            log.debug("EffectiveFromDate should be any date that is before the EffectiveToDate");
            addConstraintViolation(context, "{cmds.invalid.effectiveFromDatetime}", propertyNode);
        }
        return isValidEffectiveFromAndToDate;
    }
}
