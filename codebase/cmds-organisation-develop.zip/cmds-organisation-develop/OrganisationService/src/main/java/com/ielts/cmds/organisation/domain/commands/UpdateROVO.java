package com.ielts.cmds.organisation.domain.commands;

import com.ielts.cmds.application.command.BaseCommand;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.domain.model.RoDataUpdateV1Valid;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** @author cts */
@Data
@EqualsAndHashCode(callSuper = true)
public class UpdateROVO extends BaseCommand<BaseHeader, RoDataUpdateV1Valid> {

    @Builder
    public UpdateROVO(
            final BaseHeader eventHeaders,
            final RoDataUpdateV1Valid eventBody,
            final BaseEventErrors eventErrors,
            final BaseAudit audit) {
        super(eventHeaders, eventBody, eventErrors, audit);
    }
}
