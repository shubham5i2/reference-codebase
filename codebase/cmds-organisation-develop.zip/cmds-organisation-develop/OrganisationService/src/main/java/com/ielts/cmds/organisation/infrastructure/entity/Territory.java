package com.ielts.cmds.organisation.infrastructure.entity;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity(name = "territory")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class Territory extends ReferenceModel implements Serializable {

	/**
	 * Generated Serial VersionId
	 */
	private static final long serialVersionUID = 5459070582492136260L;

	@Id
	@GeneratedValue
	@Type(type="uuid-char")
	@Column(name = "territory_uuid")
	private UUID territoryUuid;

	@Column(name = "territory_iso_code", nullable = false)
	private String territoryIsoCode;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "country_uuid", nullable = false)
	@JsonManagedReference
	private Country country;

	@Column(name = "territory_name", nullable = false)
	private String territoryName;

	@Column(name = "legacy_reference")
	private String legacyReference;

}
