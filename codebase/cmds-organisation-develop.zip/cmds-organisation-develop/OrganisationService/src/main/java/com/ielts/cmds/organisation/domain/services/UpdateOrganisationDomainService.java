package com.ielts.cmds.organisation.domain.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateLinkedOrganisation;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.common.enums.LinkTypeEnum;
import com.ielts.cmds.organisation.common.enums.StatusEnum;
import com.ielts.cmds.organisation.common.enums.StatusTypeEnum;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.organisation.domain.model.HierarchyUpdateV1;
import com.ielts.cmds.organisation.domain.model.RoDataUpdateV1Valid;
import com.ielts.cmds.organisation.domain.utils.DomainEventsPublisher;
import com.ielts.cmds.organisation.domain.utils.OrganisationHierarchyUpdateUtil;
import com.ielts.cmds.organisation.infrastructure.entity.OrganisationType;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.entity.StatusHistory;
import com.ielts.cmds.organisation.infrastructure.repository.OrganisationTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.infrastructure.repository.StatusHistoryRepository;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.organisation.utils.UpdateOrganisationUtil;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.domain.AbstractCMDSDomainService;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** @author CTS */
@Service
@Slf4j
public class UpdateOrganisationDomainService extends AbstractCMDSDomainService<RoChangedEventV1> {

    @Autowired private OrganisationCommonUtils orgCommonUtils;

    @Autowired private UpdateOrganisationUtil updateOrgUtil;

    @Autowired private ObjectMapper objectMapper;

    @Autowired private RecognisingOrganisationRepository recognisingOrganisationRepository;

    @Autowired private ApplicationEventPublisher applicationEventPublisher;

    @Autowired private Validator roValidator;

    @Autowired private CMDSErrorResolver<Object> errorResolver;

    @Autowired private StatusHistoryRepository statusHistoryRepository;

    @Autowired private OrganisationTypeRepository orgTypeRepository;

    @Autowired private DomainEventsPublisher domainEventPublisher;

    @Autowired private OrganisationHierarchyUpdateUtil orgHierarchyUpdateUtil;

    @Autowired
    public UpdateOrganisationDomainService(ApplicationEventPublisher publisher, ObjectMapper objectMapper, @Value("${updateOrganisationDomain.v2}") String isV2Enabled, CMDSThreadLocalContextService cmdsThreadLocalContextService) {
        super(publisher, objectMapper, isV2Enabled, cmdsThreadLocalContextService);
    }


    /**
     * @param roDataUpdateV1
     * @throws JsonProcessingException
     * @throws RbacValidationException
     */
    @Transactional
    public void onCommand(final RoDataUpdateV1Valid  roDataUpdateV1)
            throws JsonProcessingException, RbacValidationException {
        RecognisingOrganisation publishOrganisation = null;
        UiHeader header = orgCommonUtils
                .buildUiHeader();
        Optional<RecognisingOrganisation> optionalOrgToBeUpdated =
                orgCommonUtils.getOrganisationViewDetails(String.valueOf(roDataUpdateV1.getRecognisingOrganisationUuid()));
        Map<String, String> eventContext =
                Optional.ofNullable(ThreadLocalHeaderContext.getContext().getEventContext())
                        .orElseGet(HashMap::new);

        if (!optionalOrgToBeUpdated.isPresent()) {
            log.debug(
                    "No Records Found with ID :{}",
                            header
                            .getEventContext()
                            .get("recognisingOrganisationUuid"));
            Set<ConstraintViolation<Object>> violation =
                    orgCommonUtils.getSetforNullViolationOfEventBody(
                            "V0043", "OrganisationNotFound");
            generateRejectedEventResponse(
                    header,
                    roDataUpdateV1,
                    optionalOrgToBeUpdated,
                    orgCommonUtils.getBaseAudit(),
                    violation,
                    eventContext.getOrDefault(
                            OrganisationConstants.GenericConstants.RECOGNISING_ORGANISATION_UUID,
                            null));

        } else {
            publishOrganisation = optionalOrgToBeUpdated.get();
            updatePermissionCheck(roDataUpdateV1, publishOrganisation, header);
        }
    }

    private void updatePermissionCheck(
            final RoDataUpdateV1Valid roDataUpdateV1Valid, RecognisingOrganisation publishOrganisation, BaseHeader header)
            throws JsonProcessingException, RbacValidationException {
        final UUID organisationTypeUuid = publishOrganisation.getOrganisationTypeUuid();
        Map<String, String> eventContext =
                Optional.ofNullable(header.getEventContext())
                        .orElseGet(HashMap::new);
        Optional<OrganisationType> organisationType =
                orgTypeRepository.findById(organisationTypeUuid);
        if (!organisationType.isPresent()) {
            log.debug(
                    "Organisation Type is not valid {} ",
                    roDataUpdateV1Valid.getOrganisationTypeUuid());
            Set<ConstraintViolation<Object>> violations =
                    orgCommonUtils.getSetforNullViolationOfEventBody(
                            "V0001", "organisationTypeUuid");
            generateRejectedEventResponse(
                    header,
                    roDataUpdateV1Valid,
                    Optional.of(publishOrganisation),
                    orgCommonUtils.getBaseAudit(),
                    violations,
                    eventContext.getOrDefault(
                            OrganisationConstants.GenericConstants.RECOGNISING_ORGANISATION_UUID,
                            null));
        } else {
            Set<ConstraintViolation<Object>> violations =
                    orgCommonUtils.checkPermissionForROVO(
                            header.getXaccessToken(),
                            organisationType.get().getOrganisationsType(),
                            OrganisationConstants.GenericConstants.UPDATE,
                            ThreadLocalAuditContext.getContext());
            if (!violations.isEmpty()) {
                generateRejectedEventResponse(
                        header,
                        roDataUpdateV1Valid,
                        Optional.of(publishOrganisation),
                        orgCommonUtils.getBaseAudit(),
                        violations,
                        eventContext.getOrDefault(
                                OrganisationConstants.GenericConstants
                                        .RECOGNISING_ORGANISATION_UUID,
                                null));
            } else {
                updateRoVoOrganisations(roDataUpdateV1Valid, publishOrganisation);
            }
        }
    }

    private void updateRoVoOrganisations(
            final RoDataUpdateV1Valid roDataUpdateV1Valid, RecognisingOrganisation publishOrganisation)
            throws JsonProcessingException {

        log.debug(
                "Organisation To Be Updated: {}",
                publishOrganisation.getRecognisingOrganisationUuid());
         Map<String, String> eventContext =
                Optional.ofNullable(ThreadLocalHeaderContext.getContext().getEventContext())
                        .orElseGet(HashMap::new);
        roDataUpdateV1Valid.setRecognisingOrganisationUuid(
                publishOrganisation.getRecognisingOrganisationUuid());
        Set<ConstraintViolation<Object>> violations =
                validateLinkedOrganisations(
                        roDataUpdateV1Valid.getRecognisingOrganisationUuid(),
                        roDataUpdateV1Valid.getLinkedOrganisations());
        Set<ConstraintViolation<Object>> dataViolations =
                validateUpdateRODetails(roDataUpdateV1Valid);
        violations.addAll(dataViolations);
        if (!violations.isEmpty()) {
            log.debug("Violations: {}", violations);
            generateRejectedEventResponse(
                    orgCommonUtils.buildUiHeader(),
                    roDataUpdateV1Valid,
                    Optional.of(publishOrganisation),
                    orgCommonUtils.getBaseAudit(),
                    violations,
                    eventContext.getOrDefault(
                            OrganisationConstants.GenericConstants.RECOGNISING_ORGANISATION_UUID,
                            null));
        } else {
            log.debug(
                    "Updating the Organisation with ID: {}",
                    publishOrganisation.getRecognisingOrganisationUuid());
            saveStatusHistoryDetails(roDataUpdateV1Valid, publishOrganisation);
            Map<String, String> hierarchyUpdateMap = new HashMap<>();
            RecognisingOrganisation updatedOrganisation =
                    updateOrgUtil.populateOrganisation(
                            roDataUpdateV1Valid, publishOrganisation, hierarchyUpdateMap);
            publishOrganisation = recognisingOrganisationRepository.save(updatedOrganisation);
            log.debug(
                    "Updated the Organisation with id: {}",
                    publishOrganisation.getRecognisingOrganisationUuid());
            orgCommonUtils.publishUpdateEvent(
                    orgCommonUtils.buildUiHeader(), orgCommonUtils.getBaseAudit(), publishOrganisation);
            if (!hierarchyUpdateMap.isEmpty()
                    && Objects.nonNull(
                            hierarchyUpdateMap.get(
                                    OrganisationConstants.GenericConstants.OLD_HIERARCHY_LABEL))) {
                rOHierarchyUpdateAnalysis(
                        hierarchyUpdateMap,
                        ThreadLocalHeaderContext.getContext().getTransactionId(),
                        ThreadLocalHeaderContext.getContext().getXaccessToken());
            }
        }
    }

    Set<ConstraintViolation<Object>> validateUpdateRODetails(RoDataUpdateV1Valid roDetails) {

        Set<ConstraintViolation<Object>> roDetailsViolation = roValidator.validate(roDetails);

        if (log.isDebugEnabled() && CollectionUtils.isNotEmpty(roDetailsViolation)) {
            roDetailsViolation.forEach(
                    violation -> log.debug("Invalid Request :" + violation.getMessage()));
        }

        return roDetailsViolation;
    }

    public void rOHierarchyUpdateAnalysis(
            Map<String, String> hierarchyUpdateMap, UUID transactionId, String accessToken)
            throws JsonProcessingException {
        Set<RecognisingOrganisation> allTheOrgsOfPreviousTree = new HashSet<>();
        /*Based on the oldHierarchyLabel get all the sourceRecognisingOrganisations which are the nodes of previous hierarchy*/
        String oldHierarchyLabel =
                hierarchyUpdateMap.get(OrganisationConstants.GenericConstants.OLD_HIERARCHY_LABEL);
        if (StringUtils.isNotEmpty(oldHierarchyLabel)
                && StringUtils.isNotBlank(oldHierarchyLabel)) {
            allTheOrgsOfPreviousTree =
                    orgHierarchyUpdateUtil.getAllTheOrgsOfPreviousHierarchy(oldHierarchyLabel);
        }
        List<BaseEvent<BaseHeader>> publishingEventList = new ArrayList<>();
        for (RecognisingOrganisation ro : allTheOrgsOfPreviousTree) {
            BaseEvent<BaseHeader> event =
                    createROHierarchyUpdateEvent(
                            hierarchyUpdateMap,
                            ro.getRecognisingOrganisationUuid(),
                            transactionId,
                            accessToken);
            publishingEventList.add(event);
        }
        domainEventPublisher.baseEventListPublisher(publishingEventList);
        log.debug("Published all the orgs of list : {}", publishingEventList.toString());
    }

    public BaseEvent<BaseHeader> createROHierarchyUpdateEvent(
            Map<String, String> hierarchyUpdateMap,
            UUID recognisingOrganisationUuid,
            UUID transactionId,
            String accessToken)
            throws JsonProcessingException {
        BaseHeader baseHeader = new BaseHeader();
        BaseAudit audit = new BaseAudit();
        Map<String, String> auditContext = new HashMap<>();
        auditContext.put(
                OrganisationConstants.GenericConstants.RECORD,
                recognisingOrganisationUuid.toString());
        audit.setAuditContext(auditContext);
        baseHeader.setTransactionId(transactionId);
        baseHeader.setCorrelationId(UUID.randomUUID());
        baseHeader.setXaccessToken(accessToken);
        baseHeader.setEventDateTime(LocalDateTime.now());
        baseHeader.setEventName(OrganisationConstants.EventType.RO_HIERARCHY_UPDATE_EVENT);
        Map<String, String> eventContext = new HashMap<>();
        baseHeader.setEventContext(eventContext);
        HierarchyUpdateV1 hierarchyUpdateV1 = new HierarchyUpdateV1();
        if (Objects.nonNull(hierarchyUpdateMap)) {
            if (StringUtils.isNotEmpty(
                            hierarchyUpdateMap.get(
                                    OrganisationConstants.GenericConstants.OLD_HIERARCHY_LABEL))
                    && StringUtils.isNotBlank(
                            hierarchyUpdateMap.get(
                                    OrganisationConstants.GenericConstants.OLD_HIERARCHY_LABEL))) {
                hierarchyUpdateV1.setOldHierarchyLabel(
                        hierarchyUpdateMap.get(
                                OrganisationConstants.GenericConstants.OLD_HIERARCHY_LABEL));
            }
            if (StringUtils.isNotEmpty(
                            hierarchyUpdateMap.get(
                                    OrganisationConstants.GenericConstants.NEW_HIERARCHY_LABEL))
                    && StringUtils.isNotBlank(
                            hierarchyUpdateMap.get(
                                    OrganisationConstants.GenericConstants.NEW_HIERARCHY_LABEL))) {
                hierarchyUpdateV1.setNewHierarchyLabel(
                        hierarchyUpdateMap.get(
                                OrganisationConstants.GenericConstants.NEW_HIERARCHY_LABEL));
            }
            if (StringUtils.isNotEmpty(
                            hierarchyUpdateMap.get(
                                    OrganisationConstants.GenericConstants.TRIGGER_RO_UUID))
                    && StringUtils.isNotBlank(
                            hierarchyUpdateMap.get(
                                    OrganisationConstants.GenericConstants.TRIGGER_RO_UUID))) {
                hierarchyUpdateV1.setTriggerRecognisingOrganisationUuid(
                        UUID.fromString(
                                hierarchyUpdateMap.get(
                                        OrganisationConstants.GenericConstants.TRIGGER_RO_UUID)));
            }
            hierarchyUpdateV1.setRecognisingOrganisationUuid(recognisingOrganisationUuid);
        }
        return new BaseEvent<>(
                baseHeader, objectMapper.writeValueAsString(hierarchyUpdateV1), null, audit);
    }

    public BaseEvent<BaseHeader> generateRejectedEventResponse(
            final BaseHeader baseHeader,
            final RoDataUpdateV1Valid  roDataUpdateV1Valid ,
            final Optional<RecognisingOrganisation> eventBody,
            final BaseAudit audit,
            final Set<ConstraintViolation<Object>> violation,
            final String dataRecord) throws JsonProcessingException {
        log.debug("Update Organisation error event audit {} ", audit);
        UiHeader roHeader = new UiHeader();
        BeanUtils.copyProperties(baseHeader, roHeader);
        roHeader.setEventName(OrganisationConstants.EventType.RO_UPDATE_REJECTED_EVENT);

        CMDSErrorResponse eventErrors =
                errorResolver.populatErrorResponse(
                        violation, OrganisationConstants.EventType.RO_UPDATE_REJECTED_EVENT);
        BaseEventErrors baseEventErrors = new BaseEventErrors(eventErrors.getErrorList());
        if (Objects.nonNull(dataRecord)) {
            audit.getAuditContext().put(OrganisationConstants.GenericConstants.RECORD, dataRecord);
        }

        BaseEvent<BaseHeader> event;
        if(eventBody.isPresent()){
            event = new BaseEvent<>(roHeader, objectMapper.writeValueAsString(orgCommonUtils.entityToEventMapper(eventBody.get())), baseEventErrors, audit);
        }else{
            event = new BaseEvent<>(roHeader, objectMapper.writeValueAsString(roDataUpdateV1Valid), baseEventErrors, audit);
        }
        applicationEventPublisher.publishEvent(event);
        return event;
    }

    private void saveStatusHistoryDetails(
            RoDataUpdateV1Valid roDataUpdateV1Valid, RecognisingOrganisation organisation) {
        if (!organisation
                .getOrgStatus().getValue()
                .equals(roDataUpdateV1Valid.getOrganisationStatus().getValue())) {
            StatusHistory orgStatusHistory = setStatusHistoryDetails(organisation);
            orgStatusHistory.setStatusType(StatusTypeEnum.ORGANISATION_STATUS);
            String status = organisation.getOrgStatus().getValue();
            orgStatusHistory.setStatus(StatusEnum.fromValue(status));
            orgStatusHistory.setStatusDatetime(LocalDateTime.now());
            statusHistoryRepository.save(orgStatusHistory);
        }
        if (!organisation
                .getVerificationStatus().getValue()
                .equals(roDataUpdateV1Valid.getVerificationStatus().getValue())) {
            StatusHistory verificationStatusHistory = setStatusHistoryDetails(organisation);
            statusHistoryRepository.save(verificationStatusHistory);
        }
    }

    public StatusHistory setStatusHistoryDetails(RecognisingOrganisation organisation) {
        StatusHistory statusHistory = new StatusHistory();
        statusHistory.setRecognisingOrganisation(organisation);
        statusHistory.setStatusType(StatusTypeEnum.VERIFICATION_STATUS);
        String status = organisation.getVerificationStatus().getValue();
        statusHistory.setStatus(StatusEnum.fromValue(status));
        statusHistory.setStatusDatetime(LocalDateTime.now());
        return statusHistory;
    }

    public Set<ConstraintViolation<Object>> validateLinkedOrganisations(
            UUID roToBeUpdatedUuid, List<RoDataUpdateLinkedOrganisation> linkedOrganisations) {
        Set<ConstraintViolation<Object>> violations = new HashSet<>();
        if (linkedOrganisations != null) {
            for (RoDataUpdateLinkedOrganisation linkedRO : linkedOrganisations) {
                /*Checking if Parent is not in a circular assignment in the hierarchy*/
                if (LinkTypeEnum.PARENT_RO.getValue().equals(linkedRO.getLinkType().getValue())) {
                    Set<RecognisingOrganisation> childrenOfROToBeUpdated =
                            orgCommonUtils.getChildHierarchyBasedOnRO(
                                    roToBeUpdatedUuid, Boolean.FALSE);
                    List<UUID> childrenUuids =
                            childrenOfROToBeUpdated.stream()
                                    .map(RecognisingOrganisation::getRecognisingOrganisationUuid)
                                    .collect(Collectors.toList());
                    if (childrenUuids.contains(linkedRO.getTargetRecognisingOrganisationUuid())) {
                        log.debug("Parent is Invalid");
                        violations =
                                orgCommonUtils.getSetforNullViolationOfEventBody(
                                        "V0065", "InvalidParent");
                        return violations;
                    }
                }
                /*Check if the Results_Delivery Organisations are valid or not*/
                if (LinkTypeEnum.RESULTS_DELIVERY.getValue().equals(linkedRO.getLinkType().getValue())
                        && linkedRO.getLinkEffectiveToDateTime()
                                .isAfter(OffsetDateTime.now(ZoneOffset.UTC))) {
                    violations =
                            validationForResultsDelivery(
                                    roToBeUpdatedUuid, linkedOrganisations, linkedRO, violations);
                }
            }
        }
        return violations;
    }

    private Set<ConstraintViolation<Object>> validationForResultsDelivery(
            UUID roToBeUpdatedUuid,
            List<RoDataUpdateLinkedOrganisation> linkedOrganisations,
            RoDataUpdateLinkedOrganisation linkedOrganisation,
            Set<ConstraintViolation<Object>> violations) {
        List<RoDataUpdateLinkedOrganisation> parentOrg =
                linkedOrganisations.stream()
                        .filter(linkedOrg -> LinkTypeEnum.PARENT_RO.getValue().equals(linkedOrg.getLinkType().getValue()))
                        .collect(Collectors.toList());
        if (parentOrg.isEmpty()) {
            /*If the parent is not selected then we can add the additional delivery organisations which are in Hierarchy of RO being updated*/
            Set<RecognisingOrganisation> currentROHierarchyList =
                    orgCommonUtils.getHierarchyBasedOnRecognisingOrganisationUuid(
                            roToBeUpdatedUuid);
            violations =
                    checkViolationifTargetisNotInHierarchy(
                            currentROHierarchyList, linkedOrganisation, violations);
            /*If parent and additional delivery organisations are present in the request then check if the addition delivery organisations are in hierarchy  or not of both parent and RO being updated*/
        } else {
            UUID parentOrganisationUuid = parentOrg.get(0).getTargetRecognisingOrganisationUuid();
            /*Check effectiveToDate of parentRO*/
            Set<RecognisingOrganisation> finalHierarchyList = new HashSet<>();
            if (linkedOrganisation
                    .getLinkEffectiveToDateTime()
                    .isAfter(OffsetDateTime.now(ZoneOffset.UTC))) {
                Set<RecognisingOrganisation> parentHierarchyList =
                        orgCommonUtils.getHierarchyBasedOnRecognisingOrganisationUuid(
                                parentOrganisationUuid);
                finalHierarchyList.addAll(parentHierarchyList);
            }
            Set<RecognisingOrganisation> currentROHierarchyList =
                    orgCommonUtils.getChildHierarchyBasedOnRO(roToBeUpdatedUuid, Boolean.FALSE);
            finalHierarchyList.addAll(currentROHierarchyList);
            violations =
                    checkViolationifTargetisNotInHierarchy(
                            finalHierarchyList, linkedOrganisation, violations);
        }
        return violations;
    }

    private Set<ConstraintViolation<Object>> checkViolationifTargetisNotInHierarchy(
            Set<RecognisingOrganisation> finalHierarchyList,
            RoDataUpdateLinkedOrganisation linkedOrganisation,
            Set<ConstraintViolation<Object>> violations) {
        List<UUID> finalHierarchyListUuids =
                finalHierarchyList.stream()
                        .map(RecognisingOrganisation::getRecognisingOrganisationUuid)
                        .collect(Collectors.toList());
        /*If additional delivery organisation are not in hierarchy then reject the creation of RO*/
        if (!finalHierarchyListUuids.contains(
                linkedOrganisation.getTargetRecognisingOrganisationUuid())) {
            log.debug("Additional Delivery organisations must be in Hierarchy List");
            violations =
                    orgCommonUtils.getSetforNullViolationOfEventBody(
                            "V0064", "DeliveryOrganisationsNotInHierarchy");
            return violations;
        }
        return violations;
    }
}
