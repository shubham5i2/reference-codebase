package com.ielts.cmds.organisation.infrastructure.entity;

import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;

@Entity(name = "address_type")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class AddressType extends ReferenceModel implements Serializable {

    /** Generated SerialVersionID */
    private static final long serialVersionUID = 2656531170958185452L;

    @Id
    @GeneratedValue
    @Type(type = "uuid-char")
    @Column(name = "address_type_uuid")
    private UUID addressTypeUuid;

    @Column(name = "address_type_name", nullable = false)
    private String addressTypeName;

    @Column(name = "description")
    private String description;
}
