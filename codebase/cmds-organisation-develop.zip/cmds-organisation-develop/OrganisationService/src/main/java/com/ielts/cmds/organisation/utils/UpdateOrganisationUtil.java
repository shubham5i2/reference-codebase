package com.ielts.cmds.organisation.utils;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.roui007rocreaterequested.ComponentEnum;
import com.ielts.cmds.api.roui007rocreaterequested.LinkTypeEnum;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdate;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateAddress;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateAlternateName;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateContact;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateLinkedOrganisation;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateMinimumScore;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateNote;
import com.ielts.cmds.organisation.infrastructure.entity.Address;
import com.ielts.cmds.organisation.infrastructure.entity.AlternateName;
import com.ielts.cmds.organisation.infrastructure.entity.Contact;
import com.ielts.cmds.organisation.infrastructure.entity.LinkedRecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.entity.MinimumScore;
import com.ielts.cmds.organisation.infrastructure.entity.NoteType;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisedProduct;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.entity.RoNote;
import com.ielts.cmds.organisation.infrastructure.repository.LinkedRecognisingOrganisationRepository;
import com.ielts.cmds.organisation.infrastructure.repository.NoteTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;

@Component
public class UpdateOrganisationUtil {

    @Autowired private NoteTypeRepository noteTypeRepository;

    @Autowired private RecognisingOrganisationRepository orgRepository;

    @Autowired
    private LinkedRecognisingOrganisationRepository linkedRecognisingOrganisationRepository;

    @Autowired private OrganisationCommonUtils organisationCommonUtils;

    /**
     * Populate all the lists in organisation
     *
     * @param roDataUpdate
     * @param organisation
     * @param hierarchyUpdateMap
     * @return
     */
    public RecognisingOrganisation populateOrganisation(
            final RoDataUpdate roDataUpdate,
            RecognisingOrganisation organisation,
            Map<String, String> hierarchyUpdateMap) throws JsonProcessingException {

        organisation = populateSetterMethods(roDataUpdate, organisation);
        organisation.setAddresses(populateAddress(roDataUpdate.getAddresses(), organisation));
        organisation.setNotes(populateRoNotes(roDataUpdate.getNotes(), organisation));
        organisation.setAlternateNames(
                populateAlternateName(roDataUpdate.getAlternateNames(), organisation));
        organisation.setContacts(populateContacts(roDataUpdate.getContacts(), organisation));
        organisation.setRecognisedProducts(
                populateRecognisedProducts(
                        roDataUpdate.getAcceptsIOL(), roDataUpdate.getAcceptsSSR(), roDataUpdate.getAcceptsAC(), roDataUpdate.getAcceptsGT(),organisation));
        organisation.setMinimumScores(
                populateMinimumScores(roDataUpdate.getMinimumScores(), organisation));
        organisation.setLinkedRecognisingOrganisations(
                populateLinkedOrganisations(
                        roDataUpdate.getLinkedOrganisations(), organisation, hierarchyUpdateMap));
        return organisation;
    }

    private List<LinkedRecognisingOrganisation> populateLinkedOrganisations(
            List<RoDataUpdateLinkedOrganisation> linkedOrganisations,
            RecognisingOrganisation organisation,
            Map<String, String> hierarchyUpdateMap) {
        List<LinkedRecognisingOrganisation> existingLinkedROList =
                organisation.getLinkedRecognisingOrganisations();
        List<LinkedRecognisingOrganisation> newLinkedOrganisationList = new ArrayList<>();
        if (linkedOrganisations != null) {
            if (existingLinkedROList.isEmpty()) {
                for (RoDataUpdateLinkedOrganisation linkedOrg : linkedOrganisations) {
                    addNewLinkedOrganisations(
                            linkedOrg, organisation, newLinkedOrganisationList, hierarchyUpdateMap);
                }
            } else {
                updateOrCreateLinkedOrganisations(
                        linkedOrganisations,
                        organisation,
                        existingLinkedROList,
                        newLinkedOrganisationList,
                        hierarchyUpdateMap);
            }
            existingLinkedROList.addAll(newLinkedOrganisationList);
        }
        return existingLinkedROList;
    }

    private void updateOrCreateLinkedOrganisations(
            List<RoDataUpdateLinkedOrganisation> linkedOrganisations,
            RecognisingOrganisation organisation,
            List<LinkedRecognisingOrganisation> existingLinkedROList,
            List<LinkedRecognisingOrganisation> newLinkedOrganisationList,
            Map<String, String> hierarchyUpdateMap) {

        for (RoDataUpdateLinkedOrganisation payloadLinkedRo : linkedOrganisations) {
            if (payloadLinkedRo.getLinkedRecognisingOrganisationUuid() == null) {
                addNewLinkedOrganisations(
                        payloadLinkedRo,
                        organisation,
                        newLinkedOrganisationList,
                        hierarchyUpdateMap);
            } else {
                existingLinkedROList = existingLinkedROList.stream()
                        .filter(
                                linkedRoToBeUpdated ->
                                        payloadLinkedRo
                                                .getLinkedRecognisingOrganisationUuid()
                                                .compareTo(
                                                        linkedRoToBeUpdated
                                                                .getLinkedRecognisingOrganisationUuid())
                                                == 0)
                        .map(
                                (LinkedRecognisingOrganisation linkedOrgToBeUpdated) ->
                                        updateExistingLinkedOrganisations(
                                                payloadLinkedRo,
                                                linkedOrgToBeUpdated,
                                                organisation,
                                                hierarchyUpdateMap))
                        .collect(Collectors.toList());
            }
        }
    }

    private LinkedRecognisingOrganisation updateExistingLinkedOrganisations(
            RoDataUpdateLinkedOrganisation payloadLinkedRo,
            LinkedRecognisingOrganisation linkedOrgToBeUpdated,
            RecognisingOrganisation organisation,
            Map<String, String> hierarchyUpdateMap) {
        linkedOrgToBeUpdated.setUpdatedDatetime(Instant.now());
        linkedOrgToBeUpdated.setUpdatedBy(OrganisationConstants.GenericConstants.OPERATIONAL_USER);

        linkedOrgToBeUpdated.setSourceRecognisingOrganisation(organisation);
        setTargetAndLabel(payloadLinkedRo, linkedOrgToBeUpdated, organisation, hierarchyUpdateMap);
        linkedOrgToBeUpdated.setLinkedRecognisingOrganisationType(LinkTypeEnum.valueOf(payloadLinkedRo.getLinkType().getValue()));
        linkedOrgToBeUpdated.setEffectiveFromDatetime(
                payloadLinkedRo.getLinkEffectiveFromDateTime());
        linkedOrgToBeUpdated.setEffectiveToDatetime(payloadLinkedRo.getLinkEffectiveToDateTime());
        return linkedOrgToBeUpdated;
    }

    private void addNewLinkedOrganisations(
            RoDataUpdateLinkedOrganisation linkedOrganisation,
            RecognisingOrganisation organisation,
            List<LinkedRecognisingOrganisation> newLinkedOrganisationList,
            Map<String, String> hierarchyUpdateMap) {
        LinkedRecognisingOrganisation linkedOrganisationToBeCreated =
                new LinkedRecognisingOrganisation();
        linkedOrganisationToBeCreated.setConcurrencyVersion(0);
        linkedOrganisationToBeCreated.setCreatedBy(
                OrganisationConstants.GenericConstants.OPERATIONAL_USER);
        linkedOrganisationToBeCreated.setCreatedDatetime(Instant.now());
        linkedOrganisationToBeCreated.setUpdatedBy(
                OrganisationConstants.GenericConstants.OPERATIONAL_USER);
        linkedOrganisationToBeCreated.setUpdatedDatetime(Instant.now());

        linkedOrganisationToBeCreated.setSourceRecognisingOrganisation(organisation);
        setTargetAndLabel(
                linkedOrganisation,
                linkedOrganisationToBeCreated,
                organisation,
                hierarchyUpdateMap);
        linkedOrganisationToBeCreated.setLinkedRecognisingOrganisationType(
                LinkTypeEnum.valueOf(linkedOrganisation.getLinkType().getValue()));
        linkedOrganisationToBeCreated.setEffectiveFromDatetime(
                Optional.of(linkedOrganisation.getLinkEffectiveFromDateTime())
                        .orElse(OffsetDateTime.now()));
        linkedOrganisationToBeCreated.setEffectiveToDatetime(
                Optional.of(linkedOrganisation.getLinkEffectiveToDateTime())
                        .orElse(OffsetDateTime.of(LocalDateTime.of(2099, 12, 31, 11, 59),ZoneOffset.UTC)));
        newLinkedOrganisationList.add(linkedOrganisationToBeCreated);
    }

    private void setTargetAndLabel(
            RoDataUpdateLinkedOrganisation linkedOrganisation,
            LinkedRecognisingOrganisation linkedOrganisationToBeSaved,
            RecognisingOrganisation organisation,
            Map<String, String> hierarchyUpdateMap) {

        if (LinkTypeEnum.PARENT_RO.getValue().equals(linkedOrganisation.getLinkType().getValue())) {

            processParentRoType(linkedOrganisation, linkedOrganisationToBeSaved, organisation, hierarchyUpdateMap);

        } else {
            processResultsDeliveryType(linkedOrganisation, linkedOrganisationToBeSaved);
        }
    }

    private void processParentRoType(
            RoDataUpdateLinkedOrganisation linkedOrganisation,
            LinkedRecognisingOrganisation linkedOrganisationToBeSaved,
            RecognisingOrganisation organisation,
            Map<String, String> hierarchyUpdateMap) {

        createHierarchyUpdateMapIfAParentIsRemoved(
                linkedOrganisation,
                linkedOrganisationToBeSaved,
                organisation,
                hierarchyUpdateMap);

        Optional<LinkedRecognisingOrganisation> parentLinkedRO = getParentLinkedRO(organisation);

        if (parentLinkedRO.isPresent()) {
            processExistingParent(linkedOrganisation, linkedOrganisationToBeSaved, hierarchyUpdateMap, parentLinkedRO.get(), organisation);
        } else if (checkIfTheROToBeUpdatedHasAnyChildren(organisation)) {
            processAddedParentToRootNodeHierarchy(linkedOrganisation, linkedOrganisationToBeSaved, hierarchyUpdateMap, organisation);
        } else {
            populateTargetAndHierarchyLabel(linkedOrganisation, linkedOrganisationToBeSaved);
        }
    }

    private Optional<LinkedRecognisingOrganisation> getParentLinkedRO(RecognisingOrganisation organisation) {
        return organisation.getLinkedRecognisingOrganisations().stream()
                .filter(linkedRO -> LinkTypeEnum.PARENT_RO.getValue().equals(
                        linkedRO.getLinkedRecognisingOrganisationType().getValue())
                        && linkedRO.getEffectiveToDatetime().isAfter(
                        OffsetDateTime.now(ZoneOffset.UTC)))
                .findAny();
    }

    private void processExistingParent(
            RoDataUpdateLinkedOrganisation linkedOrganisation,
            LinkedRecognisingOrganisation linkedOrganisationToBeSaved,
            Map<String, String> hierarchyUpdateMap,
            LinkedRecognisingOrganisation parentLinkedRO,
            RecognisingOrganisation organisation) {

        if (parentLinkedRO.getTargetRecognisingOrganisation().getRecognisingOrganisationUuid()
                .compareTo(linkedOrganisation.getTargetRecognisingOrganisationUuid()) != 0
                && linkedOrganisation.getLinkEffectiveToDateTime().isAfter(OffsetDateTime.now())
                && !checkIfTheChangedParentBelongsToSameExistingHierarchy(linkedOrganisation, organisation)) {

            hierarchyUpdateMap.put(OrganisationConstants.GenericConstants.OLD_HIERARCHY_LABEL,
                    parentLinkedRO.getOrganisationHierarchyLabel());
            populateTargetAndHierarchyLabel(linkedOrganisation, linkedOrganisationToBeSaved);
            hierarchyUpdateMap.put(OrganisationConstants.GenericConstants.NEW_HIERARCHY_LABEL,
                    linkedOrganisationToBeSaved.getOrganisationHierarchyLabel());
            hierarchyUpdateMap.put(OrganisationConstants.GenericConstants.TRIGGER_RO_UUID,
                    organisation.getRecognisingOrganisationUuid().toString());
        } else {
            populateTargetAndHierarchyLabel(linkedOrganisation, linkedOrganisationToBeSaved);
        }
    }

    private void processAddedParentToRootNodeHierarchy(
            RoDataUpdateLinkedOrganisation linkedOrganisation,
            LinkedRecognisingOrganisation linkedOrganisationToBeSaved,
            Map<String, String> hierarchyUpdateMap,
            RecognisingOrganisation organisation) {

        List<LinkedRecognisingOrganisation> linkedParentRecords = linkedRecognisingOrganisationRepository
                .findBySourceAndLinkTypeOrTargetAndLinkType(
                        organisation.getRecognisingOrganisationUuid(),
                        LinkTypeEnum.PARENT_RO,
                        organisation.getRecognisingOrganisationUuid(),
                        LinkTypeEnum.PARENT_RO);
        Optional<LinkedRecognisingOrganisation> activeLinkedRO = linkedParentRecords.stream()
                .filter(activeLinkedRecord ->
                        activeLinkedRecord.getEffectiveToDatetime().isAfter(OffsetDateTime.now(ZoneOffset.UTC)))
                .findFirst();

        if (activeLinkedRO.isPresent()) {
            hierarchyUpdateMap.put(OrganisationConstants.GenericConstants.OLD_HIERARCHY_LABEL,
                    activeLinkedRO.get().getOrganisationHierarchyLabel());
        }
        populateTargetAndHierarchyLabel(linkedOrganisation, linkedOrganisationToBeSaved);
        hierarchyUpdateMap.put(OrganisationConstants.GenericConstants.NEW_HIERARCHY_LABEL,
                linkedOrganisationToBeSaved.getOrganisationHierarchyLabel());
        hierarchyUpdateMap.put(OrganisationConstants.GenericConstants.TRIGGER_RO_UUID,
                organisation.getRecognisingOrganisationUuid().toString());
    }

    private void processResultsDeliveryType(
            RoDataUpdateLinkedOrganisation linkedOrganisation,
            LinkedRecognisingOrganisation linkedOrganisationToBeSaved) {

        Optional<RecognisingOrganisation> targetRecognisingOrganisation =
                orgRepository.findById(linkedOrganisation.getTargetRecognisingOrganisationUuid());

        targetRecognisingOrganisation.ifPresent(org ->
                linkedOrganisationToBeSaved.setTargetRecognisingOrganisation(org));
    }


    private boolean checkIfTheChangedParentBelongsToSameExistingHierarchy(
            RoDataUpdateLinkedOrganisation linkedOrganisation,
            RecognisingOrganisation organisation) {

        Set<RecognisingOrganisation> hierarchyListofOrgWhichIsBeingUpdated =
                organisationCommonUtils.getHierarchyBasedOnRecognisingOrganisationUuid(
                        organisation.getRecognisingOrganisationUuid());
        for (RecognisingOrganisation org : hierarchyListofOrgWhichIsBeingUpdated) {
            if (org.getRecognisingOrganisationUuid()
                    .equals(linkedOrganisation.getTargetRecognisingOrganisationUuid())) {
                return true;
            }
        }
        return false;
    }

    private void populateTargetAndHierarchyLabel(
            RoDataUpdateLinkedOrganisation linkedOrganisation,
            LinkedRecognisingOrganisation linkedOrganisationToBeSaved) {
        Optional<RecognisingOrganisation> targetRecognisingOrganisation =
                orgRepository.findById(linkedOrganisation.getTargetRecognisingOrganisationUuid());
        if (targetRecognisingOrganisation.isPresent()) {
            List<LinkedRecognisingOrganisation> linkedParentRecord =
                    linkedRecognisingOrganisationRepository
                            .findBySourceAndLinkTypeOrTargetAndLinkType(
                                    targetRecognisingOrganisation
                                            .get()
                                            .getRecognisingOrganisationUuid(),
                                    LinkTypeEnum.PARENT_RO,
                                    targetRecognisingOrganisation
                                            .get()
                                            .getRecognisingOrganisationUuid(),
                                    LinkTypeEnum.PARENT_RO);
            if (!linkedParentRecord.isEmpty()) {
                linkedOrganisationToBeSaved.setOrganisationHierarchyLabel(
                        linkedParentRecord.get(0).getOrganisationHierarchyLabel());
            } else {
                linkedOrganisationToBeSaved.setOrganisationHierarchyLabel(
                        targetRecognisingOrganisation.get().getOrganisationId().toString());
            }
            linkedOrganisationToBeSaved.setTargetRecognisingOrganisation(
                    targetRecognisingOrganisation.get());
        }
    }

    private boolean checkIfTheROToBeUpdatedHasAnyChildren(RecognisingOrganisation roToBeUpdated) {

        Set<RecognisingOrganisation> childOrganisationsList =
                organisationCommonUtils.getChildHierarchyBasedOnRO(
                        roToBeUpdated.getRecognisingOrganisationUuid(), Boolean.TRUE);
        return !childOrganisationsList.isEmpty();
    }

    private void createHierarchyUpdateMapIfAParentIsRemoved(
            RoDataUpdateLinkedOrganisation linkedOrganisation,
            LinkedRecognisingOrganisation linkedOrganisationToBeSaved,
            RecognisingOrganisation organisation,
            Map<String, String> hierarchyUpdateMap) {
        if (LinkTypeEnum.PARENT_RO.getValue().equals(linkedOrganisation.getLinkType().getValue())
                && !linkedOrganisation
                .getLinkEffectiveToDateTime()
                .isAfter(OffsetDateTime.now(ZoneOffset.UTC))) {
            String oldLabel = null;
            /*Get label of the linked organisation based on the primary key of the linked ro which is being updated*/
            Optional<LinkedRecognisingOrganisation> linkedRoRecord =
                    linkedRecognisingOrganisationRepository.findById(
                            linkedOrganisationToBeSaved.getLinkedRecognisingOrganisationUuid());
            if (linkedRoRecord.isPresent()
                    && LinkTypeEnum.PARENT_RO.getValue().equals(
                    linkedRoRecord.get().getLinkedRecognisingOrganisationType().getValue())) {
                oldLabel = linkedRoRecord.get().getOrganisationHierarchyLabel();
            }
            hierarchyUpdateMap.put(
                    OrganisationConstants.GenericConstants.OLD_HIERARCHY_LABEL, oldLabel);
            hierarchyUpdateMap.put(
                    OrganisationConstants.GenericConstants.NEW_HIERARCHY_LABEL,
                    organisation.getOrganisationId().toString());
            hierarchyUpdateMap.put(
                    OrganisationConstants.GenericConstants.TRIGGER_RO_UUID,
                    organisation.getRecognisingOrganisationUuid().toString());
        }
    }

    private List<Address> populateAddress(
            List<RoDataUpdateAddress> addresses, RecognisingOrganisation organisation) {

        List<Address> addressList = organisation.getAddresses();

        addresses.stream()
                .forEach(
                        payloadAddress ->
                                addressList.stream()
                                        .filter(
                                                addressToBeUpdated ->
                                                        payloadAddress.getAddressUuid() != null
                                                                && payloadAddress
                                                                .getAddressUuid()
                                                                .equals(
                                                                        addressToBeUpdated
                                                                                .getAddressUuid()))
                                        .map(
                                                (Address addressToBeUpdated) ->
                                                        updateAddressEntity(
                                                                addressToBeUpdated,
                                                                payloadAddress,
                                                                organisation))
                                        .collect(Collectors.toList()));
        return addressList;
    }

    private Address updateAddressEntity(
            Address addressToBeUpdated,
            RoDataUpdateAddress payloadAddress,
            RecognisingOrganisation organisation) {

        addressToBeUpdated.setAddressTypeUuid(payloadAddress.getAddressTypeUuid());
        addressToBeUpdated.setCountryUuid(payloadAddress.getCountryUuid());
        addressToBeUpdated.setTerritoryUuid(payloadAddress.getTerritoryUuid());
        addressToBeUpdated.setAddressline1(payloadAddress.getAddressLine1());
        addressToBeUpdated.setAddressline2(payloadAddress.getAddressLine2());
        addressToBeUpdated.setAddressline3(payloadAddress.getAddressLine3());
        addressToBeUpdated.setAddressline4(payloadAddress.getAddressLine4());
        addressToBeUpdated.setCity(payloadAddress.getCity());
        addressToBeUpdated.setPostalCode(payloadAddress.getPostalCode());
        addressToBeUpdated.setEmail(payloadAddress.getEmail());
        addressToBeUpdated.setPhone(payloadAddress.getPhone());
        addressToBeUpdated.setRecognisingOrganisation(organisation);
        return addressToBeUpdated;
    }

    private List<MinimumScore> populateMinimumScores(
            List<RoDataUpdateMinimumScore> minimumScores, RecognisingOrganisation organisation) {

        List<MinimumScore> minimumScoresList = organisation.getMinimumScores();
        List<MinimumScore> newMinScoresList = new ArrayList<>();
        if (minimumScores != null) {
            if (minimumScoresList.isEmpty()) {
                for (RoDataUpdateMinimumScore minScore : minimumScores) {
                    addNewMinScore(minScore, organisation, newMinScoresList);
                }
            } else {
                updateOrCreateMinimumScores(
                        minimumScores, organisation, minimumScoresList, newMinScoresList);
            }
        }
        minimumScoresList.addAll(newMinScoresList);
        return minimumScoresList;
    }

    private List<MinimumScore> updateOrCreateMinimumScores(
            List<RoDataUpdateMinimumScore> minimumScores,
            RecognisingOrganisation organisation,
            List<MinimumScore> minimumScoresList,
            List<MinimumScore> newMinScoresList) {
        for (RoDataUpdateMinimumScore payloadMinScore : minimumScores) {
            if (payloadMinScore.getMinimumScoreUuid() == null) {
                addNewMinScore(payloadMinScore, organisation, newMinScoresList);
            } else {
                newMinScoresList = minimumScoresList.stream()
                        .filter(
                                minScoreToBeUpdated ->
                                        payloadMinScore.getMinimumScoreUuid() != null
                                                && payloadMinScore
                                                .getMinimumScoreUuid()
                                                .compareTo(
                                                        minScoreToBeUpdated
                                                                .getMinscoreReqUuid())
                                                == 0)
                        .map(
                                (MinimumScore minScoreToBeUpdated) ->
                                        updateExistingMinimumScores(
                                                payloadMinScore, minScoreToBeUpdated, organisation))
                        .collect(Collectors.toList());
            }
        }
        return newMinScoresList;
    }

    private MinimumScore updateExistingMinimumScores(
            RoDataUpdateMinimumScore payloadMinScore,
            MinimumScore minScoreToBeUpdated,
            RecognisingOrganisation organisation) {
        minScoreToBeUpdated.setModuleTypeUuid(payloadMinScore.getModuleTypeUuid());
        minScoreToBeUpdated.setComponent(ComponentEnum.fromValue(payloadMinScore.getComponent().getValue()));
        minScoreToBeUpdated.setMinimumScoreValue(payloadMinScore.getMinimumScoreValue());
        minScoreToBeUpdated.setRecognisingOrganisation(organisation);
        return minScoreToBeUpdated;
    }

    private List<MinimumScore> addNewMinScore(
            RoDataUpdateMinimumScore minScore,
            RecognisingOrganisation organisation,
            List<MinimumScore> newMinScoresList) {
        MinimumScore newMinScore = new MinimumScore();
        newMinScore.setModuleTypeUuid(minScore.getModuleTypeUuid());
        newMinScore.setComponent(ComponentEnum.valueOf(minScore.getComponent().getValue()));
        newMinScore.setMinimumScoreValue(minScore.getMinimumScoreValue());
        newMinScore.setRecognisingOrganisation(organisation);
        newMinScoresList.add(newMinScore);
        return newMinScoresList;
    }

    private List<RecognisedProduct> populateRecognisedProducts(
            Boolean acceptsIOL, Boolean acceptsSSR,Boolean acceptsAC, Boolean acceptsGT, RecognisingOrganisation organisation) throws JsonProcessingException {

        List<RecognisedProduct> recognisedProductList =
                organisation.getRecognisedProducts().stream()
                        .filter(
                                product ->
                                        product.getEffectiveToDatetime()
                                                .isAfter(OffsetDateTime.now(ZoneOffset.UTC)))
                        .collect(Collectors.toList());
        List<RecognisedProduct> newRecognisedProductsList = new ArrayList<>();
        Map<String, Set<UUID>> map =
                organisationCommonUtils.getProductUuidsBasedOnCharacteristics();
        Set<UUID> roAcceptedProductUuids =
                organisationCommonUtils.getROAcceptedProductUuids(acceptsIOL, acceptsSSR, acceptsAC, acceptsGT, map);
        /*If any of the flags were created as true and are updated to false in update flow then make the products inactive*/
        for (RecognisedProduct recognisedProduct : recognisedProductList) {
            if (!roAcceptedProductUuids.contains(recognisedProduct.getProductUuid())) {
                recognisedProduct.setEffectiveToDatetime(OffsetDateTime.now(ZoneOffset.UTC));
            }
        }
        /*If any of the flags were created as false and are updated to true in update flow then add the products*/
        List<UUID> existingProducts =
                recognisedProductList.stream()
                        .map(RecognisedProduct::getProductUuid)
                        .collect(Collectors.toList());
        for (UUID acceptedProductUuid : roAcceptedProductUuids) {
            if (!existingProducts.contains(acceptedProductUuid)) {
                addNewRecognisedProduct(
                        acceptedProductUuid, organisation, newRecognisedProductsList);
            }
        }
        recognisedProductList.addAll(newRecognisedProductsList);
        return recognisedProductList;
    }

    private List<RecognisedProduct> addNewRecognisedProduct(
            UUID acceptedProduct,
            RecognisingOrganisation organisation,
            List<RecognisedProduct> newRecognisedProductsList) {
        RecognisedProduct newRecognisedProduct = new RecognisedProduct();
        newRecognisedProduct.setProductUuid(acceptedProduct);
        newRecognisedProduct.setEffectiveFromDatetime(OffsetDateTime.now(ZoneOffset.UTC));
        LocalDateTime endDate = LocalDateTime.of(2099, Month.DECEMBER, 31, 11, 59, 59);
        newRecognisedProduct.setEffectiveToDatetime(OffsetDateTime.of(endDate,ZoneOffset.UTC));
        newRecognisedProduct.setRecognisingOrganisation(organisation);
        newRecognisedProductsList.add(newRecognisedProduct);
        return newRecognisedProductsList;
    }

    private List<Contact> populateContacts(
            List<RoDataUpdateContact> contacts, RecognisingOrganisation organisation) {

        List<Contact> contactList = organisation.getContacts();
        List<Contact> newContactList = new ArrayList<>();
        if (contacts != null) {
            if (!contactList.isEmpty()) {
                updateOrCreateContacts(contacts, organisation, contactList, newContactList);
            } else {
                for (RoDataUpdateContact contact : contacts) {
                    setContactsData(contact, organisation, newContactList);
                }
            }
        }
        contactList.addAll(newContactList);
        return contactList;
    }

    private List<Contact> updateOrCreateContacts(
            List<RoDataUpdateContact> contacts,
            RecognisingOrganisation organisation,
            List<Contact> contactList,
            List<Contact> newContactsList) {
        for (RoDataUpdateContact payloadContact : contacts) {
            if (payloadContact.getContactUuid() == null) {
                setContactsData(payloadContact, organisation, newContactsList);
            } else {
                newContactsList = contactList.stream()
                        .filter(
                                contactToBeUpdated ->
                                        payloadContact.getContactUuid() != null
                                                && payloadContact
                                                .getContactUuid()
                                                .compareTo(
                                                        contactToBeUpdated
                                                                .getContactUuid())
                                                == 0)
                        .map(
                                (Contact contactToBeUpdated) ->
                                        updateExistingContacts(
                                                payloadContact, contactToBeUpdated, organisation))
                        .collect(Collectors.toList());
            }
        }
        return contactList;
    }

    private Contact updateExistingContacts(
            RoDataUpdateContact payloadContact,
            Contact contactToBeUpdated,
            RecognisingOrganisation organisation) {
        contactToBeUpdated.setTitle(payloadContact.getTitle());
        contactToBeUpdated.setFirstName(payloadContact.getFirstName());
        contactToBeUpdated.setLastName(payloadContact.getLastName());
        contactToBeUpdated.setJobTitle(payloadContact.getJobTitle());
        contactToBeUpdated.setAddresses(
                populateContactAddress(
                        contactToBeUpdated, payloadContact.getAddresses(), organisation));
        contactToBeUpdated.setRecognisingOrganisation(organisation);
        return contactToBeUpdated;
    }

    private List<Contact> setContactsData(
            RoDataUpdateContact contact,
            RecognisingOrganisation organisation,
            List<Contact> newContactList) {
        Contact contactToBeAdded = new Contact();
        contactToBeAdded.setTitle(contact.getTitle());
        contactToBeAdded.setJobTitle(contact.getJobTitle());
        contactToBeAdded.setFirstName(contact.getFirstName());
        contactToBeAdded.setLastName(contact.getLastName());
        contactToBeAdded.setContactTypeUuid(contact.getContactTypeUuid());
        // Here the effective_from_datetime and effective_to_datetime are not coming
        // from UI, So we are hardcoding them here
        contactToBeAdded.setEffectiveFromDatetime(OffsetDateTime.now());
        contactToBeAdded.setEffectiveToDatetime(OffsetDateTime.now());
        contactToBeAdded.setAddresses(
                populateContactAddress(contactToBeAdded, contact.getAddresses(), organisation));
        contactToBeAdded.setRecognisingOrganisation(organisation);
        newContactList.add(contactToBeAdded);
        return newContactList;
    }

    private List<Address> populateContactAddress(
            Contact contactToBeUpdated,
            List<RoDataUpdateAddress> addresses,
            RecognisingOrganisation organisation) {

        List<Address> addressList = new ArrayList<>();
        List<Address> contactsNewAddressList = new ArrayList<>();
        if (addresses != null) {
            if (Objects.isNull(contactToBeUpdated.getAddresses())) {
                for (RoDataUpdateAddress address : addresses) {
                    createNewAddressForContact(contactToBeUpdated, address, contactsNewAddressList);
                }
            } else {
                addressList = contactToBeUpdated.getAddresses();
                for (RoDataUpdateAddress payloadAddress : addresses) {
                    if (payloadAddress.getAddressUuid() == null) {
                        createNewAddressForContact(
                                contactToBeUpdated, payloadAddress, contactsNewAddressList);
                    } else {
                        updateExistingContactAddresses(
                                contactToBeUpdated, payloadAddress, addressList, organisation);
                    }
                }
            }
        }
        addressList.addAll(contactsNewAddressList);
        return addressList;
    }

    private void updateExistingContactAddresses(
            Contact contactToBeUpdated,
            RoDataUpdateAddress payloadAddress,
            List<Address> addressList,
            RecognisingOrganisation organisation) {
        for (Address contactaddressToBeUpdated : addressList) {
            if (contactToBeUpdated.equals(contactaddressToBeUpdated.getContact())
                    && payloadAddress.getAddressUuid() != null
                    && payloadAddress
                    .getAddressUuid()
                    .compareTo(contactaddressToBeUpdated.getAddressUuid())
                    == 0) {
                updateAddressEntity(contactaddressToBeUpdated, payloadAddress, organisation);
                contactaddressToBeUpdated.setContact(contactToBeUpdated);
            }
        }
    }

    public List<Address> createNewAddressForContact(
            Contact contact, RoDataUpdateAddress contactAddress, List<Address> newAddressList) {

        if (contact != null) {
            Address addressToBeAdded = new Address();
            addressToBeAdded.setAddressTypeUuid(contactAddress.getAddressTypeUuid());
            addressToBeAdded.setCountryUuid(contactAddress.getCountryUuid());
            addressToBeAdded.setTerritoryUuid(contactAddress.getTerritoryUuid());
            addressToBeAdded.setAddressline1(contactAddress.getAddressLine1());
            addressToBeAdded.setAddressline2(contactAddress.getAddressLine2());
            addressToBeAdded.setAddressline3(contactAddress.getAddressLine3());
            addressToBeAdded.setAddressline4(contactAddress.getAddressLine4());
            addressToBeAdded.setCity(contactAddress.getCity());
            addressToBeAdded.setPostalCode(contactAddress.getPostalCode());
            addressToBeAdded.setEmail(contactAddress.getEmail());
            addressToBeAdded.setPhone(contactAddress.getPhone());
            addressToBeAdded.setContact(contact);
            newAddressList.add(addressToBeAdded);
        }
        return newAddressList;
    }

    /**
     * Method to Update Alternate Names.
     *
     * @param alternateNames
     * @param organisation
     * @return
     */
    private List<AlternateName> populateAlternateName(
            List<RoDataUpdateAlternateName> alternateNames, RecognisingOrganisation organisation) {

        List<AlternateName> alternateNamesList = organisation.getAlternateNames();
        List<AlternateName> newAltNameList = new ArrayList<>();
        if (alternateNames != null) {
            /* if there are no records in DB, create the alternate names*/
            if (alternateNamesList.isEmpty()) {
                for (RoDataUpdateAlternateName altName : alternateNames) {
                    addNewAltName(altName, organisation, newAltNameList);
                }
            } else {
                updateOrCreateAlternateNames(
                        alternateNames, organisation, alternateNamesList, newAltNameList);
            }
        }
        alternateNamesList.addAll(newAltNameList);
        return alternateNamesList;
    }

    private List<AlternateName> updateOrCreateAlternateNames(
            List<RoDataUpdateAlternateName> alternateNames,
            RecognisingOrganisation organisation,
            List<AlternateName> alternateNamesList,
            List<AlternateName> newAltNameList) {
        for (RoDataUpdateAlternateName payloadAltName : alternateNames) {
            /*If the request does not contain alternateNameUuid then create a new record */
            if (payloadAltName.getAlternateNameUuid() == null) {
                addNewAltName(payloadAltName, organisation, newAltNameList);
            } else {
                alternateNamesList = alternateNamesList.stream()
                        .filter(
                                altNameToBeUpdated ->
                                        payloadAltName.getAlternateNameUuid() != null
                                                && payloadAltName
                                                .getAlternateNameUuid()
                                                .compareTo(
                                                        altNameToBeUpdated
                                                                .getAlternateNameUuid())
                                                == 0)
                        .map(
                                (AlternateName altNameToBeUpdated) ->
                                        updateExistingAlternateNames(
                                                payloadAltName, altNameToBeUpdated, organisation))
                        .collect(Collectors.toList());
            }
        }
        return newAltNameList;
    }

    private AlternateName updateExistingAlternateNames(
            RoDataUpdateAlternateName payloadAltName,
            AlternateName altNameToBeUpdated,
            RecognisingOrganisation organisation) {
        altNameToBeUpdated.setName(payloadAltName.getName());
        altNameToBeUpdated.setRecognisingOrganisation(organisation);
        return altNameToBeUpdated;
    }
    /**
     * Method to create New Alternate Names if required.
     *
     * @param altName
     * @param organisation
     * @param newAltNameList
     * @return
     */
    private List<AlternateName> addNewAltName(
            RoDataUpdateAlternateName altName,
            RecognisingOrganisation organisation,
            List<AlternateName> newAltNameList) {
        AlternateName altNameToBeAdded = new AlternateName();
        altNameToBeAdded.setName(altName.getName());
        altNameToBeAdded.setRecognisingOrganisation(organisation);
        newAltNameList.add(altNameToBeAdded);
        return newAltNameList;
    }

    /**
     * Method to update the RO_Notes.
     *
     * @param notes
     * @param organisation
     * @return
     */
    private List<RoNote> populateRoNotes(
            List<RoDataUpdateNote> notes, RecognisingOrganisation organisation) {
        List<RoNote> roNotesList = organisation.getNotes();
        List<RoNote> newRoNotesList = new ArrayList<>();
        if (notes != null) {
            if (roNotesList.isEmpty()) {
                for (RoDataUpdateNote note : notes) {
                    addNewRoNote(note, organisation, newRoNotesList);
                }
            } else {
                updateOrCreateRONotes(notes, organisation, roNotesList, newRoNotesList);
            }
        }
        roNotesList.addAll(newRoNotesList);
        return roNotesList;
    }

    private List<RoNote> updateOrCreateRONotes(
            List<RoDataUpdateNote> notes,
            RecognisingOrganisation organisation,
            List<RoNote> roNotesList,
            List<RoNote> newRoNotesList) {

        for (RoDataUpdateNote payloadnotes : notes) {
            if (payloadnotes.getNoteUuid() == null) {
                addNewRoNote(payloadnotes, organisation, newRoNotesList);
            } else {
                roNotesList = roNotesList.stream()
                        .filter(
                                noteToBeUpdated ->
                                        payloadnotes.getNoteUuid() != null
                                                && payloadnotes
                                                .getNoteUuid()
                                                .compareTo(
                                                        noteToBeUpdated
                                                                .getNoteUuid())
                                                == 0)
                        .map(
                                (RoNote noteToBeUpdated) ->
                                        updateExistingRoNote(
                                                payloadnotes, noteToBeUpdated, organisation))
                        .collect(Collectors.toList());
            }
        }
        return newRoNotesList;
    }

    private RoNote updateExistingRoNote(
            RoDataUpdateNote payloadNotes,
            RoNote noteToBeUpdated,
            RecognisingOrganisation organisation) {

        noteToBeUpdated.setNoteContent(payloadNotes.getNoteContent());
        noteToBeUpdated.setNoteTypeUuid(payloadNotes.getNoteTypeUuid());
        noteToBeUpdated.setRecognisingOrganisation(organisation);
        return noteToBeUpdated;
    }

    /**
     * Method to create New RO_Note if required.
     *
     * @param roNote
     * @param organisation
     * @param newRoNotesList
     * @return
     */
    private List<RoNote> addNewRoNote(
            RoDataUpdateNote roNote,
            RecognisingOrganisation organisation,
            List<RoNote> newRoNotesList) {

        RoNote noteToBeAdded = new RoNote();
        noteToBeAdded.setNoteContent(roNote.getNoteContent());
        /*
         * NoteType is not sent from UI so for now we are hardcoding it to Internal
         * NoteType
         */
        NoteType noteType = noteTypeRepository.findByNotesType("Internal");
        noteToBeAdded.setNoteTypeUuid(noteType.getNoteTypeUuid());
        noteToBeAdded.setRecognisingOrganisation(organisation);
        newRoNotesList.add(noteToBeAdded);
        return newRoNotesList;
    }

    /**
     * Method to set all the individual fields in Organisation.
     *
     * @param roData
     * @param orgDetails
     * @return
     */
    public RecognisingOrganisation populateSetterMethods(
            final RoDataUpdate roData, final RecognisingOrganisation orgDetails) {

        orgDetails.setName(roData.getOrganisationName());
        orgDetails.setOrganisationTypeUuid(roData.getOrganisationTypeUuid());
        orgDetails.setVerificationStatus(com.ielts.cmds.api.roui007rocreaterequested.VerificationStatusEnum.valueOf(roData.getVerificationStatus().getValue()));
        orgDetails.setPartnerCode(roData.getPartnerCode());
        orgDetails.setPartnerContact(roData.getPartnerContact());
        orgDetails.setMethodOfDelivery((com.ielts.cmds.api.roui007rocreaterequested.MethodOfDeliveryEnum.fromValue(roData.getMethodOfDelivery().getValue())));
        orgDetails.setSectorTypeUuid(roData.getSectorTypeUuid());
        orgDetails.setOrgStatus((com.ielts.cmds.api.roui007rocreaterequested.OrganisationStatusEnum.valueOf(roData.getOrganisationStatus().getValue())));
        orgDetails.setWebsiteUrl(roData.getWebsiteUrl());
        orgDetails.setCrmSystem(roData.getCrmSystem());
        orgDetails.setOrganisationCode(roData.getOrganisationCode());
        orgDetails.setResultAvailableForYears(
                organisationCommonUtils.populateResultAvailableForYears(
                        roData.getResultAvailableForYears()));
        orgDetails.setIeltsDisplayFlag(
                organisationCommonUtils.populateIeltsFlag(
                        roData.getOrganisationTypeUuid(), roData.getIeltsDisplayFlag()));
        orgDetails.setOrsDisplayFlag(
                organisationCommonUtils.populateOrsFlag(roData.getOrsDisplayFlag()));
        return orgDetails;
    }
}
