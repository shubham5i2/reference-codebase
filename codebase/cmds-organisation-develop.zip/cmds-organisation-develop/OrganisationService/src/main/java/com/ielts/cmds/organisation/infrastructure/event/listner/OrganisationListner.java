package com.ielts.cmds.organisation.infrastructure.event.listner;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.rbac.api.service.RBACService;
import com.ielts.cmds.serialization.application.service.ApplicationServiceFactory;
import com.ielts.cmds.serialization.application.service.ApplicationServiceFactoryV2;
import com.ielts.cmds.serialization.application.utils.CMDSThreadLocalContextService;
import com.ielts.cmds.serialization.infra.AbstractUIListener;
import com.ielts.cmds.serialization.utils.BaseEventExtractor;
import com.ielts.cmds.serialization.utils.CmdsLoggerInitializer;
import com.ielts.cmds.serialization.utils.CmdsLoggerInitializerV2;
import com.ielts.cmds.serialization.utils.EventBodyExtractor;
import com.ielts.cmds.serialization.utils.MessageVersionIdentifier;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class OrganisationListner extends AbstractUIListener<UiHeader> {

    @Autowired
    public OrganisationListner(ObjectMapper mapper, EventBodyExtractor<?> extractEventBody, BaseEventExtractor<?> extractBaseEvent,
                               CmdsLoggerInitializerV2<?> initializeCmdsLogger, CmdsLoggerInitializer<?> initializeCmdsLoggerV1,
                               MessageVersionIdentifier identifyVersion, ApplicationServiceFactoryV2<?> applicationServiceFactoryV2,
                               ApplicationServiceFactory applicationServiceFactory, RBACService rbacService, CMDSThreadLocalContextService service) {
        super(mapper, extractEventBody, extractBaseEvent, initializeCmdsLogger, initializeCmdsLoggerV1, identifyVersion,
                applicationServiceFactoryV2, applicationServiceFactory, rbacService, service);
    }

    /**
     * This method is to accept create / update request from destination queue and deserialize
     * request into SMEvent to pass it on to SMService.
     *
     * @param message

     */
    @JmsListener(destination = "${aws.sqs.ro-ui-queue-in.name}")
    public void on(final Message<String> sqsMessage) {
        log.debug("Generic SQS message recieved - {}", sqsMessage);
        onReceive(sqsMessage.getHeaders(), sqsMessage.getPayload());
    }

}
