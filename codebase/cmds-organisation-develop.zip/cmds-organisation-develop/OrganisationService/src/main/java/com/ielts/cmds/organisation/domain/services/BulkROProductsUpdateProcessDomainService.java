package com.ielts.cmds.organisation.domain.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.domain.commands.LoadROData;
import com.ielts.cmds.organisation.domain.commands.UpdateROVO;
import com.ielts.cmds.organisation.domain.model.BulkRORecognisedProductsUpdateDataV1;
import com.ielts.cmds.organisation.domain.model.RoDataUpdateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.utils.BulkROProductsUpdateDataUtils;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import com.ielts.cmds.organisation.utils.UpdateOrganisationUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import javax.validation.ConstraintViolation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Slf4j
public class BulkROProductsUpdateProcessDomainService {

    @Autowired private RecognisingOrganisationRepository recognisingOrganisationRepository;

    @Autowired private BulkROProductsUpdateDataUtils bulkROProductUpdateUtils;

    @Autowired private UpdateOrganisationDomainService updateOrganisationDomainService;

    @Autowired private UpdateOrganisationUtil updateOrganisationUtil;

    @Autowired private OrganisationCommonUtils orgCommonUtils;

    /**
     * For each {@link CSVRecord}, this method will be invoked. All operations under this method,
     * will be executed under one single transaction
     *
     * @param loadROData
     * @param loadROHierarchyDataV1
     * @throws Exception
     * @throws JsonProcessingException
     */
    @Transactional
    public BaseEvent<BaseHeader> processRecord(
            final LoadROData loadROData,
            final BulkRORecognisedProductsUpdateDataV1 bulkROProductUpdateDataV1)
            throws Exception {
        BaseEvent<BaseHeader> event = null;
        Map<String, String> eventContext =
                Optional.ofNullable(loadROData.getEventHeaders().getEventContext())
                        .orElseGet(HashMap::new);
        loadROData.getEventHeaders().setCorrelationId(UUID.randomUUID());
        Optional<RecognisingOrganisation> roToBeUpdatedWithProducts = Optional.empty();
        Integer organisationId =
                Integer.valueOf(
                        StringUtils.deleteWhitespace(
                                bulkROProductUpdateDataV1.getOrganisationId()));
        if (organisationId != null) {
            roToBeUpdatedWithProducts =
                    recognisingOrganisationRepository.findByOrganisationId(organisationId);
        }
        if (roToBeUpdatedWithProducts.isPresent()) {
            final RoDataUpdateV1Valid roDataUpdate =
                bulkROProductUpdateUtils.updateProductData(roToBeUpdatedWithProducts.get());
            Set<ConstraintViolation<Object>> violations =
                updateOrganisationDomainService.validateLinkedOrganisations(
                    roDataUpdate.getRecognisingOrganisationUuid(),
                    roDataUpdate.getLinkedOrganisations());
            Set<ConstraintViolation<Object>> dataViolations =
                updateOrganisationDomainService.validateUpdateRODetails(roDataUpdate);
            violations.addAll(dataViolations);
            if (violations.isEmpty()) {
                RecognisingOrganisation updateRO =
                        updateOrganisationUtil.populateOrganisation(
                                roDataUpdate, roToBeUpdatedWithProducts.get(), new HashMap<>());
                RecognisingOrganisation publishRO =
                        recognisingOrganisationRepository.save(updateRO);
                event =
                        orgCommonUtils.publishUpdateEvent(
                                loadROData.getEventHeaders(), loadROData.getAudit(), publishRO);
            } else {
                log.debug("Violations : {}", violations);
                event =
                        updateOrganisationDomainService.generateRejectedEventResponse(
                                loadROData.getEventHeaders(),
                                roDataUpdate,
                                roToBeUpdatedWithProducts,
                                loadROData.getAudit(),
                                violations,
                                eventContext.getOrDefault(
                                        OrganisationConstants.GenericConstants
                                                .RECOGNISING_ORGANISATION_UUID,
                                        null));
            }
        } else {
            log.debug("Organisation Doesn't exists with orgId : {}", organisationId);
            List<ErrorDescription> errorList =
                    orgCommonUtils.getErrorDescriptions(new ArrayList<>(), organisationId);
            errorList.get(0).setTitle("OrganisationId Failure");
            event =
                    orgCommonUtils.generateErrorEvent(
                            loadROData.getEventHeaders(), String.valueOf(loadROData.getEventBody()), errorList);
        }
        return event;
    }
}
