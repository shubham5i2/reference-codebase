package com.ielts.cmds.organisation.infrastructure.repository;

import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RecognisingOrganisationRepository
        extends JpaRepository<RecognisingOrganisation, UUID> {

    List<RecognisingOrganisation> findByOrganisationIdAndName(
            final String organisationId, final String organisationName);

    Optional<RecognisingOrganisation> findByRecognisingOrganisationUuid(
            UUID recognisingOrganisationUuid);

    RecognisingOrganisation findByName(final String organisationName);

    RecognisingOrganisation findByNameIgnoreCase(final String organisationName);

    boolean existsByNameIgnoreCaseAndSoftDeletedFalse(final String organisationName);

    boolean existsByNameIgnoreCaseAndRecognisingOrganisationUuidNotAndSoftDeletedFalse(
            final String organisationName, final UUID recognisingOrganisationUuid);

    Optional<RecognisingOrganisation> findByOrganisationId(final Integer organisationId);

    List<RecognisingOrganisation> findByRecognisingOrganisationUuidIn(List<UUID> roUuidList);

    boolean existsByOrganisationIdAndSoftDeletedFalse(final Integer organisationId);
}
