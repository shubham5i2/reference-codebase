package com.ielts.cmds.organisation.domain.model;

import java.util.HashMap;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class BulkRORecognisedProductsUpdateMapV1
        extends HashMap<String, BulkRORecognisedProductsUpdateDataV1> {

    /** */
    private static final long serialVersionUID = 7768307846528535813L;
}
