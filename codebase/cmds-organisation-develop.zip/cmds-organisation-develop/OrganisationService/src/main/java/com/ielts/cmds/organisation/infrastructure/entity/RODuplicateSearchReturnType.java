package com.ielts.cmds.organisation.infrastructure.entity;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

import org.hibernate.annotations.Type;

import com.ielts.cmds.api.roui007rocreaterequested.OrganisationStatusEnum;
import com.ielts.cmds.api.roui007rocreaterequested.MethodOfDeliveryEnum;
import com.ielts.cmds.api.roui007rocreaterequested.VerificationStatusEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode
@ToString
@MappedSuperclass
public class RODuplicateSearchReturnType extends AddressDuplicateSearchResult implements Serializable {

    /** Generated SerialVersionId */
    private static final long serialVersionUID = -5240178090895236758L;



    @Id
    @Type(type = "uuid-char")
    @Column(
            columnDefinition = "uuid",
            name = "recognising_organisation_uuid",
            unique = true,
            nullable = false)
    private UUID recognisingOrganisationUuid;

    @Column(name = "name", nullable = false, length = 255)
    private String name;

    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "organisation_id", length = 25)
    private Integer organisationId;

    @Type(type = "uuid-char")
    @Column(columnDefinition = "uuid", name = "organisation_type_uuid")
    private UUID organisationTypeUuid;

    @Type(type = "uuid-char")
    @Column(columnDefinition = "uuid", name = "sector_type_uuid")
    private UUID sectorTypeUuid;

    @Column(name = "partner_code", length = 25)
    private String partnerCode;

    @Column(name = "partner_contact", length = 25)
    private String partnerContact;

    @Column(name = "method_of_delivery")
    private MethodOfDeliveryEnum methodOfDelivery;

    @Column(name = "organisation_code", length = 20)
    private String organisationCode;

    @Column(name = "verification_status")
    @Enumerated(EnumType.STRING)
    private VerificationStatusEnum verificationStatus;

    @Column(name = "org_status")
    @Enumerated(EnumType.STRING)
    private OrganisationStatusEnum orgStatus;

    @Column(name = "website_url", length = 250)
    private String websiteUrl;

    @Column(name = "soft_deleted")
    private Boolean softDeleted;

    @Column(name = "target_recognising_organisation_uuid")
    private UUID targetRecognisingOrganisationUuid;
}
