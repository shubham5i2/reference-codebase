package com.ielts.cmds.organisation.domain.services;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.S3Object;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.domain.commands.LoadROData;
import com.ielts.cmds.organisation.domain.model.LoadRODataV1;
import com.ielts.cmds.organisation.domain.model.LoadROMessageV1;
import com.ielts.cmds.organisation.domain.model.LoadRORecordEvent;
import com.ielts.cmds.organisation.utils.LoadROEventMapper;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@NoArgsConstructor
public class LoadRODomainService extends CommonLoadROService {

    @Value("${ro.data.bucket.name}")
    private String roBucketName;

    @Value("${process.count}")
    private String processCount;

    @Autowired private AmazonS3 s3Client;

    @Autowired private ProcessRODomainService processRODomainService;

    @Autowired private ApplicationEventPublisher applicationEventPublisher;

    @Autowired private LoadROEventMapper loadROEventMapper;

    /**
     * This method will be used to get the file from S3 bucket and process the records As it is a
     * bulk load operation, it won't perform this operation in a single transaction
     *
     * @param loadROData
     * @throws IOException
     */
    public void onCommand(final LoadROData loadROData) throws IOException {
        long startTime = System.currentTimeMillis();
        try {
            log.debug(
                    "Bucket Name: {}, Key: {} ",
                    roBucketName,
                    getFileName(loadROData.getEventHeaders()));
            S3Object s3Object =
                    s3Client.getObject(roBucketName, getFileName(loadROData.getEventHeaders()));
            BufferedReader data =
                    new BufferedReader(new InputStreamReader(s3Object.getObjectContent()));
            CsvSchema schema = csvMapper.schema().withHeader().withColumnSeparator(',');
            MappingIterator<LoadRODataV1> mappingIterator =
                    csvMapper.readerFor(LoadRODataV1.class).with(schema).readValues(data);
            List<LoadRODataV1> loadRODataV1List = mappingIterator.readAll();

            int start =
                    Integer.parseInt(
                            loadROData
                                    .getEventHeaders()
                                    .getEventContext()
                                    .getOrDefault("start", "0"));
            int end = start + Integer.parseInt(processCount);
            log.debug("End: {}. Total Records: {}", end, loadRODataV1List.size());
            Map<String, LoadRORecordEvent> eventsMap =
                    processRecords(loadROData, loadRODataV1List, start, end);
            // If start is lesser than total records, then there are remaining records to be
            // processed
            if (start < loadRODataV1List.size()) {
                long duration = System.currentTimeMillis() - startTime;
                log.debug("Time took to process {} records: {}", processCount, duration);
                publishLoadROEvent(
                        loadROData.getEventHeaders(), loadROData.getAudit(), eventsMap, end);
            } else {
                String mode = getOperationMode(loadROData.getEventHeaders());
                log.info(
                        "{} File processing completed with mode: {} , records processed {}",
                        getFileName(loadROData.getEventHeaders()),
                        mode,
                        loadRODataV1List.size());
            }
        } catch (IllegalArgumentException e) {
            log.error("Exception while getting file name/parsing: ", e);
            throw e;
        }
    }

    public void publishLoadROEvent(
            BaseHeader eventHeaders,
            BaseAudit audit,
            Map<String, LoadRORecordEvent> eventsMap,
            int end)
            throws JsonProcessingException {
        BaseHeader baseHeader = new BaseHeader();
        BeanUtils.copyProperties(eventHeaders, baseHeader);
        baseHeader.setEventName(OrganisationConstants.EventType.RO_PROCESS_EVENT);
        baseHeader.getEventContext().put("start", Integer.toString(end));
        baseHeader.setEventDateTime(LocalDateTime.now(ZoneOffset.UTC));

        LoadROMessageV1 loadROMessageV1 = loadROEventMapper.mapToEvent(eventsMap);
        BaseEvent<BaseHeader> event =
                new BaseEvent<>(
                        baseHeader, objectMapper.writeValueAsString(loadROMessageV1), null, audit);
        applicationEventPublisher.publishEvent(event);
    }

    /**
     * This method processes only processCount(property) records at a time. The processing stops
     * once all records have been processed. If there is any exception in any given row, exception
     * will be logged and processing will continue
     *
     * @param loadROData
     * @param records
     * @param endValue
     */
    public Map<String, LoadRORecordEvent> processRecords(
            final LoadROData loadROData,
            final List<LoadRODataV1> records,
            Integer startValue,
            Integer endValue) {
        Map<String, LoadRORecordEvent> eventsMap = new HashMap<>();
        while (startValue < endValue && startValue < records.size()) {
            int rowNumber = startValue + 1;
            LoadRORecordEvent loadRORecordEvent = new LoadRORecordEvent();
            try {

                log.debug(
                        "Record Number: {}. Organisation Name to be processed: {}",
                        rowNumber,
                        records.get(startValue).getName());
                loadRORecordEvent.setLoadRORecord(records.get(startValue));
                loadRORecordEvent.setEvent(
                        processRODomainService.processRecord(
                                loadROData, records.get(startValue)));
                eventsMap.put(String.valueOf(rowNumber), loadRORecordEvent);
            } catch (Exception e) {
                log.error("Exception in Load RO Process Records: ", e);
                loadRORecordEvent.setLoadRORecord(records.get(rowNumber - 1));
                loadRORecordEvent.setEvent(
                        generateErrorFromException(
                                loadROData.getEventHeaders(),
                                e,
                                OrganisationConstants.EventType.RO_CREATE_REJECTED_EVENT));
                eventsMap.put(String.valueOf(rowNumber), loadRORecordEvent);
            }
            startValue++;
        }
        return eventsMap;
    }
}
