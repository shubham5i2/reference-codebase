package com.ielts.cmds.organisation.utils;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.ListJoin;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.ielts.cmds.api.roui005rosearchrequested.RoSearchCriteria;
import com.ielts.cmds.organisation.infrastructure.entity.Address;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
@Component
public class SearchFullTextRoNameCriteriaSpecificationUtil implements RoSearchStrategy{

	/**
	 * Method to get {@link Specification} for the given {@link RoSearchCriteria}
	 * and {@link ListJoin} of {@link Address} and {@link RecognisingOrganisation}
	 *
	 * @param roSearchV1Criteria
	 * @param joinAddress
	 * @return
	 */
	@Autowired
	private SearchRemaningCriteriaSpecificationUtil searchRemaningCriteriaSpecificationUtil;
	@Override
	public Specification<RecognisingOrganisation> criteriaMatches(final RoSearchCriteria roSearchV1Criteria,
			final ListJoin<RecognisingOrganisation, Address> joinAddress) {

		return (recognisingOrganisation, query, criteriaBuilder) -> {
			List<Predicate> fullTextlMatchPredicateList = new ArrayList<>();
			if (!StringUtils.isEmpty(roSearchV1Criteria.getOrganisationName())) {
				fullTextlMatchPredicateList.add(criteriaBuilder.like(criteriaBuilder.lower(recognisingOrganisation.get("name")),
						"%"+roSearchV1Criteria.getOrganisationName().toLowerCase()+"%"));
			}
			fullTextlMatchPredicateList.add(searchRemaningCriteriaSpecificationUtil.criteriaMatches(roSearchV1Criteria, joinAddress).toPredicate(recognisingOrganisation, query, criteriaBuilder));
			Predicate[] exactMatchPredicates = new Predicate[fullTextlMatchPredicateList.size()];
			query.distinct(true);
			return criteriaBuilder.and(fullTextlMatchPredicateList.toArray(exactMatchPredicates));
		};
	}

}
