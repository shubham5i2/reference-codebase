package com.ielts.cmds.organisation.application;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.config.IBaseAuditService;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.api.roui005rosearchrequested.RoSearchObject;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.domain.commands.SearchROVO;
import com.ielts.cmds.organisation.domain.services.DuplicateSearchOrganisationDomainService;
import com.ielts.cmds.organisation.domain.services.SearchOrganisationDomainService;
import com.ielts.cmds.organisation.utils.OrganisationConstants;

import com.ielts.cmds.serialization.application.service.IApplicationServiceV2;
import com.ielts.cmds.serialization.utils.ServiceIdentifier;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@ServiceIdentifier(OrganisationConstants.GenericConstants.RO_SEARCH_REQUEST_EVENT)
public class OrganisationSearchService
    implements IApplicationServiceV2<RoSearchObject>, IBaseAuditService {

  @Autowired private SearchOrganisationDomainService searchOrganisationDomainService;

  @Autowired
  private DuplicateSearchOrganisationDomainService duplicateSearchOrganisationDomainService;


  /**
   * This method handles incoming requests and creates command to call domain service for further
   * processing
   *
   * @param cmdsEventBody
  */
  @SneakyThrows
  @Override
  public void process(final RoSearchObject cmdsEventBody) {

    try {
      log.debug(
              "Request with transactionId and event name as: {}, {}",
              ThreadLocalHeaderContext.getContext().getTransactionId(),
              ThreadLocalHeaderContext.getContext().getEventName());

      log.debug("Event Body: {}", cmdsEventBody);
      if (cmdsEventBody == null) {
        throw new IllegalArgumentException(OrganisationConstants.ErrorResponse.EMPTY_PAYLOAD);
      }
      populateAuditFields();
      // Execute command
      if (OrganisationConstants.GenericConstants.DUPLICATE_SEARCH_MODE.equals(
          ThreadLocalHeaderContext.getContext()
              .getEventContext()
              .getOrDefault("mode", "generic"))) {
        duplicateSearchOrganisationDomainService.onCommand(cmdsEventBody);
      } else {
        searchOrganisationDomainService.onCommand(cmdsEventBody);
      }
    } catch (Exception e) {
      log.error("Exception while processing Request: ", e);
      throw new ProcessingException(e.getMessage(), e);
    }
  }

  @Override
  public String getPermission() {
    return OrganisationConstants.Permissions.ORG_VIEW;
  }

  @Override
  public String getScreen() {
    return OrganisationConstants.Screen.SEARCH_ORGANISATION;
  }

  @Override
  public String getAction() {
    return SearchROVO.class.getSimpleName();
  }
}
