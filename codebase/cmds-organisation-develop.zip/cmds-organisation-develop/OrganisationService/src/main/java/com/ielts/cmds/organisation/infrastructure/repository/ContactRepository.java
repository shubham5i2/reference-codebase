package com.ielts.cmds.organisation.infrastructure.repository;

import com.ielts.cmds.organisation.infrastructure.entity.Contact;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ContactRepository extends JpaRepository<Contact, UUID> {

    Optional<Contact> findByRecognisingOrganisationRecognisingOrganisationUuidAndContactTypeUuid(
            UUID recognisingOrganisationUuid, UUID contactTypeUuid);
}
