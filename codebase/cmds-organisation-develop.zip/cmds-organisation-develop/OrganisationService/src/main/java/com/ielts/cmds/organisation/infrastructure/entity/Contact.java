package com.ielts.cmds.organisation.infrastructure.entity;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode(
        callSuper = true,
        exclude = {"recognisingOrganisation"})
@Entity(name = "contact")
@ToString(exclude = {"recognisingOrganisation"})
public class Contact extends Model implements Serializable {

    /** Generated SerialVersionID */
    private static final long serialVersionUID = -2951189844768741128L;

    @Id
    @GeneratedValue
    @Column(columnDefinition = "uuid", name = "contact_uuid")
    private UUID contactUuid;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "recognising_organisation_uuid", nullable = false)
    private RecognisingOrganisation recognisingOrganisation;

    @Column(columnDefinition = "uuid", name = "contact_type_uuid", nullable = false)
    private UUID contactTypeUuid;

    @Column(name = "title", length = 20)
    private String title;

    @Column(name = "first_name", length = 50)
    private String firstName;

    @Column(name = "last_name", length = 50)
    private String lastName;

    @Column(name = "job_title", length = 100)
    private String jobTitle;

    @OneToMany(mappedBy = "contact", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Address> addresses;
}
