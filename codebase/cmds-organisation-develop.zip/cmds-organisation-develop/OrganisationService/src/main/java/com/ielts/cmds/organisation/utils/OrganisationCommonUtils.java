package com.ielts.cmds.organisation.utils;

import static java.lang.String.format;

import java.time.LocalDateTime;
import java.time.Month;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;
import javax.validation.Path;
import javax.validation.Validator;

import com.ielts.cmds.organisation.cache.JedisGenericReader;
import com.ielts.cmds.organisation.cache.entity.Product;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.validator.internal.engine.ConstraintViolationImpl;
import org.hibernate.validator.internal.engine.path.PathImpl;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.roui007rocreaterequested.LinkTypeEnum;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreate;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreateAddress;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreateAlternateName;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreateContact;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreateLinkedOrganisation;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreateMinimumScore;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreateNote;
import com.ielts.cmds.api.roui007rocreaterequested.VerificationStatusEnum;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.CMDSErrorResolver;
import com.ielts.cmds.common.exception.util.CMDSErrorResponse;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.logger.util.CMDSLoggerUtils;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.infrastructure.event.context.CMDSAuditContext;
import com.ielts.cmds.infrastructure.event.context.CMDSHeaderContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalAuditContext;
import com.ielts.cmds.infrastructure.event.context.ThreadLocalHeaderContext;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Address;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Addresses;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1AlternateName;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1AlternateNames;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Contact;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Contacts;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1LinkedOrganisation;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1LinkedOrganisations;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1MinimumScore;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1MinimumScores;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Note;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Notes;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1RecognisedProduct;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1RecognisedProducts;
import com.ielts.cmds.organisation.common.out.event.RoDetailsDataGeneratedEventV1;
import com.ielts.cmds.organisation.common.out.event.RoDetailsDataGeneratedEventV1RO;
import com.ielts.cmds.organisation.domain.model.RoDataCreateV1Valid;
import com.ielts.cmds.organisation.infrastructure.config.ValidationConfig;
import com.ielts.cmds.organisation.infrastructure.entity.Address;
import com.ielts.cmds.organisation.infrastructure.entity.AddressType;
import com.ielts.cmds.organisation.infrastructure.entity.AlternateName;
import com.ielts.cmds.organisation.infrastructure.entity.Contact;
import com.ielts.cmds.organisation.infrastructure.entity.ContactType;
import com.ielts.cmds.organisation.infrastructure.entity.Country;
import com.ielts.cmds.organisation.infrastructure.entity.LinkedRecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.entity.MinimumScore;
import com.ielts.cmds.organisation.infrastructure.entity.NoteType;
import com.ielts.cmds.organisation.infrastructure.entity.OrganisationType;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisedProduct;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.entity.RoNote;
import com.ielts.cmds.organisation.infrastructure.entity.SectorType;
import com.ielts.cmds.organisation.infrastructure.entity.StatusHistory;
import com.ielts.cmds.organisation.infrastructure.entity.Territory;
import com.ielts.cmds.organisation.infrastructure.repository.AddressTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.ContactTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.CountryRepository;
import com.ielts.cmds.organisation.infrastructure.repository.LinkedRecognisingOrganisationRepository;
import com.ielts.cmds.organisation.infrastructure.repository.NoteTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.OrganisationTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.infrastructure.repository.SectorTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.StatusHistoryRepository;
import com.ielts.cmds.organisation.infrastructure.repository.TerritoryRepository;
import com.ielts.cmds.outbox.event.OutboxEventBuilder;
import com.ielts.cmds.rbac.api.service.RBACService;
import com.ielts.cmds.rbac.api.service.exception.RbacValidationException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class OrganisationCommonUtils {

  @Autowired CMDSLoggerUtils loggerUtil;

  @Autowired private ObjectMapper objectMapper;

  @Autowired private Validator roValidator;

  @Autowired private ValidationConfig<?> validatorConfig;

  @Autowired private NoteTypeRepository noteTypeRepository;

  @Autowired private ContactTypeRepository contactTypeRepository;

  @Autowired private TerritoryRepository territoryRepository;

  @Autowired private CountryRepository countryRepository;

  @Autowired private AddressTypeRepository addressTypeRepository;

  @Autowired private OrganisationTypeRepository organisationTypeRepository;

  @Autowired private SectorTypeRepository sectorTypeRepository;

  @Autowired private RBACService rbacService;

  @Autowired private RecognisingOrganisationRepository orgRepository;

  @Autowired private StatusHistoryRepository statusHistoryRepository;

  @Autowired
  private LinkedRecognisingOrganisationRepository linkedRecognisingOrganisationRepository;

  @Autowired private ApplicationEventPublisher applicationEventPublisher;

  @Autowired private CMDSErrorResolver<Object> errorResolver;

    @Autowired private JedisGenericReader jedisGenericReader;

    @Autowired private OutboxEventBuilder outboxEventBuilder;

  public <T extends BaseHeader> BaseEvent<T> processRequest(
      final String cmdsEventMsg, final Class<T> headerType) throws JsonProcessingException {

    final JavaType javaType =
        objectMapper.getTypeFactory().constructParametricType(BaseEvent.class, headerType);
    final BaseEvent<T> eventPayload = objectMapper.readValue(cmdsEventMsg, javaType);
    validateHeaders(eventPayload, cmdsEventMsg);

    initializeCmdsLogger(eventPayload.getEventHeader());
    return eventPayload;
  }

  public void validateHeaders(final BaseEvent<?> uiCmdsEvent, final String roMessage) {

    Set<ConstraintViolation<BaseEvent<?>>> orgHeaderViolation = roValidator.validate(uiCmdsEvent);
    validateEventHeaders(roMessage, orgHeaderViolation);
  }

  private void validateEventHeaders(
      final String roMessage, Set<? extends ConstraintViolation<?>> smHeaderViolation) {
    final List<String> errorMessageList = new ArrayList<>();
    if (CollectionUtils.isNotEmpty(smHeaderViolation)) {
      log.debug("Error in validation {}", smHeaderViolation.toString());
      smHeaderViolation.forEach(
          action -> {
            final Map<String, String> errorMap = validatorConfig.getErrorCode();
            final String message = errorMap.get(action.getMessage());
            errorMessageList.add(message);
          });
      String errorMessage = StringUtils.join(errorMessageList, ",");
      log.error("Validation failed for OrganisationEvent - {} :", errorMessage);

      throw new IllegalArgumentException(
          format(
              "Organisation Event Validation failed- [%s] for the request %s",
              errorMessage, roMessage));
    }
  }

  public Optional<RecognisingOrganisation> getOrganisationViewDetails(final String  organisation_uuid) {

    Optional<RecognisingOrganisation> organisationDetails = Optional.empty();
    if(organisation_uuid != null){
      organisationDetails = orgRepository.findById(UUID.fromString(organisation_uuid));
    }
    return organisationDetails;
  }

  public Optional<RecognisingOrganisation> getOrganisationByOrgId(final Integer orgId) {

    Optional<RecognisingOrganisation> organisationDetails = Optional.empty();
    if (orgId != null){

      organisationDetails = orgRepository.findByOrganisationId(orgId);

    }
    return organisationDetails;
  }

  /* @param baseHeader */
  private void initializeCmdsLogger(final BaseHeader baseHeader) {
    /* Logger Initialization */
    loggerUtil.initializeMDCContext(
        baseHeader.getTransactionId().toString(),
        "OrganisationService",
        baseHeader.getCorrelationId().toString(),
        baseHeader.getEventContext());
  }

  public void clearMDCContext() {
    loggerUtil.clearMDCContext();
  }

  public Set<ConstraintViolation<Object>> getSetforNullViolationOfEventBody(
      final String interpolatedMessage, final String pathProperty) {

    Set<ConstraintViolation<Object>> violationSet = new HashSet<>();
    final String messageTemplate = null;
    Path path = PathImpl.createPathFromString(pathProperty);
    final String interpolatedHeaderMessage = interpolatedMessage;
    final Map<String, Object> messageParameters = new HashMap<>();
    final Map<String, Object> expressionVariables = new HashMap<>();
    ConstraintViolation<Object> constraintViolationImpl =
        ConstraintViolationImpl.forBeanValidation(
            messageTemplate,
            messageParameters,
            expressionVariables,
            interpolatedHeaderMessage,
            null,
            null,
            null,
            null,
            path,
            null,
            null);

    violationSet.add(constraintViolationImpl);
    return violationSet;
  }

  public RecognisingOrganisation populateOrganisation(
      final RoDataCreateV1Valid roDataCreate, RecognisingOrganisation organisation) throws JsonProcessingException {

    organisation = populateOrgDetailsBasedOnAction(roDataCreate, organisation);
    organisation.setAddresses(populateAddress(null, roDataCreate.getAddresses(), organisation));
    organisation.setNotes(populateRoNotes(roDataCreate.getNotes(), organisation));
    organisation.setAlternateNames(
        populateAlternateName(roDataCreate.getAlternateNames(), organisation));
    organisation.setContacts(populateContacts(roDataCreate.getContacts(), organisation));
    organisation.setRecognisedProducts(
        populateRecognisedProducts(
            roDataCreate.getAcceptsIOL(), roDataCreate.getAcceptsSSR(), roDataCreate.getAcceptsAC(), roDataCreate.getAcceptsGT(), organisation));
    organisation.setMinimumScores(
        populateMinimumScores(roDataCreate.getMinimumScores(), organisation));
    organisation.setLinkedRecognisingOrganisations(
        populateLinkedRecognisingOrganisations(
            roDataCreate.getLinkedOrganisations(), organisation));
    return organisation;
  }

  private List<MinimumScore> populateMinimumScores(
          List<RoDataCreateMinimumScore> minimumScores, RecognisingOrganisation organisation) {

    List<MinimumScore> minimumScoresList = new ArrayList<>();
    if (minimumScores != null) {
      minimumScores.forEach(
          minScore -> {
            MinimumScore minScoreToBeAdded = new MinimumScore();
            minScoreToBeAdded.setModuleTypeUuid(minScore.getModuleTypeUuid());
            minScoreToBeAdded.setComponent(minScore.getComponent());
            minScoreToBeAdded.setMinimumScoreValue(minScore.getMinimumScoreValue());
            minScoreToBeAdded.setRecognisingOrganisation(organisation);
            minimumScoresList.add(minScoreToBeAdded);
          });
    }
    return minimumScoresList;
  }

  private List<LinkedRecognisingOrganisation> populateLinkedRecognisingOrganisations(
      List<RoDataCreateLinkedOrganisation> linkedOrganisations,
      RecognisingOrganisation recognisingOrganisation) {

    List<LinkedRecognisingOrganisation> linkedRecognisingOrganisationList = new ArrayList<>();
    if (linkedOrganisations != null) {
      linkedOrganisations.forEach(
          linkedOrganisation -> {
            LinkedRecognisingOrganisation linkedOrganisationToBeCreated =
                new LinkedRecognisingOrganisation();

            linkedOrganisationToBeCreated.setSourceRecognisingOrganisation(recognisingOrganisation);
            setTargetAndLabel(linkedOrganisation, linkedOrganisationToBeCreated);
            linkedOrganisationToBeCreated.setLinkedRecognisingOrganisationType(
                linkedOrganisation.getLinkType());
            linkedOrganisationToBeCreated.setEffectiveFromDatetime(
                Optional.of(linkedOrganisation.getLinkEffectiveFromDateTime())
                    .orElse(OffsetDateTime.now()));
            LocalDateTime endDate = LocalDateTime.of(2099, Month.DECEMBER, 31, 11, 59, 59);
            linkedOrganisationToBeCreated.setEffectiveToDatetime(
                Optional.of(linkedOrganisation.getLinkEffectiveToDateTime())
                    .orElse(OffsetDateTime.of(endDate,ZoneOffset.UTC)));
            linkedRecognisingOrganisationList.add(linkedOrganisationToBeCreated);
          });
    }
    return linkedRecognisingOrganisationList;
  }

  private void setTargetAndLabel(
      RoDataCreateLinkedOrganisation linkedOrganisation,
      LinkedRecognisingOrganisation linkedOrganisationToBeCreated) {
      Optional<RecognisingOrganisation> targetRecognisingOrganisation =
          orgRepository.findById(linkedOrganisation.getTargetRecognisingOrganisationUuid());
      if (targetRecognisingOrganisation.isPresent()) {
        linkedOrganisationToBeCreated.setTargetRecognisingOrganisation(
            targetRecognisingOrganisation.get());
        if (LinkTypeEnum.PARENT_RO.getValue().equals(linkedOrganisation.getLinkType().getValue())) {
          Optional<LinkedRecognisingOrganisation> linkedParentRecord =
              linkedRecognisingOrganisationRepository
                  .findBySourceRecognisingOrganisationRecognisingOrganisationUuidAndLinkedRecognisingOrganisationTypeAndEffectiveToDatetimeAfter(
                      targetRecognisingOrganisation.get().getRecognisingOrganisationUuid(),
                      LinkTypeEnum.PARENT_RO,
                      OffsetDateTime.now(ZoneOffset.UTC));
          if (linkedParentRecord.isPresent()) {
            linkedOrganisationToBeCreated.setOrganisationHierarchyLabel(
                linkedParentRecord.get().getOrganisationHierarchyLabel());
          } else {
            linkedOrganisationToBeCreated.setOrganisationHierarchyLabel(
                targetRecognisingOrganisation.get().getOrganisationId().toString());
          }
        }
    }
  }

  private List<RecognisedProduct> populateRecognisedProducts(
      Boolean acceptsIOL, Boolean acceptsSSR, Boolean acceptsAC, Boolean acceptsGT, RecognisingOrganisation organisation) throws JsonProcessingException {

    Map<String, Set<UUID>> map = getProductUuidsBasedOnCharacteristics();
    Set<UUID> roAcceptedProductUuids = getROAcceptedProductUuids(acceptsIOL, acceptsSSR, acceptsAC, acceptsGT, map);
    List<RecognisedProduct> recognisedProductList = new ArrayList<>();

    setRecognisedProductsBasedOnCharacteristics(
        roAcceptedProductUuids, organisation, recognisedProductList);

    return recognisedProductList;
  }

  private List<RecognisedProduct> setRecognisedProductsBasedOnCharacteristics(
      Set<UUID> productUuids,
      RecognisingOrganisation organisation,
      List<RecognisedProduct> recognisedProductList) {
    for (UUID productUuid : productUuids) {
      RecognisedProduct recognisedProductToBeAdded = new RecognisedProduct();
      recognisedProductToBeAdded.setProductUuid(productUuid);
      recognisedProductToBeAdded.setEffectiveFromDatetime(OffsetDateTime.now());
      recognisedProductToBeAdded.setEffectiveToDatetime(OffsetDateTime.of(LocalDateTime.of(2099, 12, 31, 11, 59),ZoneOffset.UTC));
      recognisedProductToBeAdded.setRecognisingOrganisation(organisation);
      recognisedProductList.add(recognisedProductToBeAdded);
    }
    return recognisedProductList;
  }

  public Map<String, Set<UUID>> getProductUuidsBasedOnCharacteristics() throws JsonProcessingException {

    List<Product> bookableProducts = jedisGenericReader.retrieveAllBookableProductsDataFromRedisCache();
    Map<String, Set<UUID>> map = new HashMap<>();
    Set<UUID> roAcceptedProducts = new HashSet<>();
    Set<UUID> acProducts = new HashSet<>();
    Set<UUID> gtProducts = new HashSet<>();
    Set<UUID> iolProducts = new HashSet<>();
    Set<UUID> ssrProducts = new HashSet<>();
    try {
      for (Product product : bookableProducts) {
        JSONObject productCharacteristics = new JSONObject(product.getProductCharacteristics());
        String characteristics = productCharacteristics.getString(OrganisationConstants.GenericConstants.CHARACTERISTICS);
        if (characteristics.contains(OrganisationConstants.GenericConstants.IOC)
            && !characteristics.contains(OrganisationConstants.GenericConstants.SSR)) {
          roAcceptedProducts.add(product.getProductUuid());
        }
        if (characteristics.contains(OrganisationConstants.GenericConstants.AC)) {
          acProducts.add(product.getProductUuid());
        }
        if (characteristics.contains(OrganisationConstants.GenericConstants.GT)) {
          gtProducts.add(product.getProductUuid());
        }
        if (characteristics.contains(OrganisationConstants.GenericConstants.IOL)) {
          iolProducts.add(product.getProductUuid());
        }
        if (characteristics.contains(OrganisationConstants.GenericConstants.SSR)) {
          ssrProducts.add(product.getProductUuid());
        }
      }
    } catch (JSONException e) {
      log.error("Json Processing Exception on product characteristics: {}", e.getMessage());
    }
    map.put(OrganisationConstants.GenericConstants.IOC, roAcceptedProducts);
    map.put(OrganisationConstants.GenericConstants.AC, acProducts);
    map.put(OrganisationConstants.GenericConstants.GT, gtProducts);
    map.put(OrganisationConstants.GenericConstants.IOL, iolProducts);
    map.put(OrganisationConstants.GenericConstants.SSR, ssrProducts);
    return map;
  }

  public Set<UUID> getROAcceptedProductUuids(
      Boolean acceptsIOL, Boolean acceptsSSR, Boolean acceptsAC, Boolean acceptsGT, Map<String, Set<UUID>> map) {
    Set<UUID> roAcceptedProductUuids = new HashSet<>();
    roAcceptedProductUuids.addAll(map.get(OrganisationConstants.GenericConstants.IOC));
    Set<UUID> acProducts = map.get(OrganisationConstants.GenericConstants.AC);
    Set<UUID> gtProducts = map.get(OrganisationConstants.GenericConstants.GT);
    final boolean acTrueGtTrue = Boolean.TRUE.equals(acceptsAC) && Boolean.TRUE.equals(acceptsGT);
    final boolean acTrueGtFalse = Boolean.TRUE.equals(acceptsAC) && Boolean.FALSE.equals(acceptsGT);
    if (Boolean.TRUE.equals(acceptsIOL) && Boolean.TRUE.equals(acceptsSSR)) {
      getProductsBasedOnToggleIOLTrueSSRTrue(acTrueGtTrue, acTrueGtFalse, roAcceptedProductUuids,map,acProducts,gtProducts);
    } else if (Boolean.FALSE.equals(acceptsIOL) && Boolean.TRUE.equals(acceptsSSR)) {
      getProductsBasedOnToggleIOLFalseSSRTrue(acTrueGtTrue, acTrueGtFalse, roAcceptedProductUuids,map,acProducts,gtProducts);
    } else if (Boolean.TRUE.equals(acceptsIOL) && Boolean.FALSE.equals(acceptsSSR)) {
      getProductsBasedOnToggleIOLTrueSSRFalse(acTrueGtTrue, acTrueGtFalse, roAcceptedProductUuids,map,acProducts,gtProducts);
    } else {
      if(acTrueGtTrue){
        return  roAcceptedProductUuids;
      }
      else{
        getProductsBasedOnToggleIOLFalseSSRFalse(acTrueGtFalse, roAcceptedProductUuids,acProducts,gtProducts);
      }
    }
    return roAcceptedProductUuids;
  }

  private void getProductsBasedOnToggleIOLFalseSSRFalse(boolean acTrueGtFalse, Set<UUID> roAcceptedProductUuids, Set<UUID> acProducts, Set<UUID> gtProducts) {
    if(acTrueGtFalse){
      roAcceptedProductUuids.removeAll(gtProducts);
    } else{
      roAcceptedProductUuids.removeAll(acProducts);
    }
  }

  private void getProductsBasedOnToggleIOLTrueSSRFalse(boolean acTrueGtTrue, boolean acTrueGtFalse, Set<UUID> roAcceptedProductUuids, Map<String, Set<UUID>> map, Set<UUID> acProducts, Set<UUID> gtProducts) {
    if(acTrueGtTrue) {
      Set<UUID> iolProducts = map.get(OrganisationConstants.GenericConstants.IOL);
      iolProducts.removeAll(map.get(OrganisationConstants.GenericConstants.SSR));
      roAcceptedProductUuids.addAll(iolProducts);
    }else if(acTrueGtFalse) {
      Set<UUID> iolProducts = map.get(OrganisationConstants.GenericConstants.IOL);
      iolProducts.removeAll(map.get(OrganisationConstants.GenericConstants.SSR));
      iolProducts.removeAll(gtProducts);
      roAcceptedProductUuids.removeAll(gtProducts);
      roAcceptedProductUuids.addAll(iolProducts);
    }else {
      Set<UUID> iolProducts = map.get(OrganisationConstants.GenericConstants.IOL);
      iolProducts.removeAll(map.get(OrganisationConstants.GenericConstants.SSR));
      iolProducts.removeAll(acProducts);
      roAcceptedProductUuids.removeAll(acProducts);
      roAcceptedProductUuids.addAll(iolProducts);
    }
  }

  private void getProductsBasedOnToggleIOLFalseSSRTrue(boolean acTrueGtTrue, boolean acTrueGtFalse, Set<UUID> roAcceptedProductUuids, Map<String, Set<UUID>> map, Set<UUID> acProducts, Set<UUID> gtProducts) {
    if(acTrueGtTrue) {
      Set<UUID> ssrProducts = map.get(OrganisationConstants.GenericConstants.SSR);
      ssrProducts.removeAll(map.get(OrganisationConstants.GenericConstants.IOL));
      roAcceptedProductUuids.addAll(ssrProducts);
    }else if(acTrueGtFalse) {
      Set<UUID> ssrProducts = map.get(OrganisationConstants.GenericConstants.SSR);
      ssrProducts.removeAll(map.get(OrganisationConstants.GenericConstants.IOL));
      ssrProducts.removeAll(gtProducts);
      roAcceptedProductUuids.removeAll(gtProducts);
      roAcceptedProductUuids.addAll(ssrProducts);
    }else  {
      Set<UUID> ssrProducts = map.get(OrganisationConstants.GenericConstants.SSR);
      ssrProducts.removeAll(map.get(OrganisationConstants.GenericConstants.IOL));
      ssrProducts.removeAll(acProducts);
      roAcceptedProductUuids.removeAll(acProducts);
      roAcceptedProductUuids.addAll(ssrProducts);
    }
  }

  private void getProductsBasedOnToggleIOLTrueSSRTrue(boolean acTrueGtTrue, boolean acTrueGtFalse, Set<UUID> roAcceptedProductUuids, Map<String, Set<UUID>> map, Set<UUID> acProducts, Set<UUID> gtProducts) {
    if(acTrueGtTrue) {
      roAcceptedProductUuids.addAll(map.get(OrganisationConstants.GenericConstants.IOL));
      roAcceptedProductUuids.addAll(map.get(OrganisationConstants.GenericConstants.SSR));
    }else if(acTrueGtFalse) {
      roAcceptedProductUuids.addAll(map.get(OrganisationConstants.GenericConstants.IOL));
      roAcceptedProductUuids.addAll(map.get(OrganisationConstants.GenericConstants.SSR));
      roAcceptedProductUuids.removeAll(gtProducts);
    }else {
      roAcceptedProductUuids.addAll(map.get(OrganisationConstants.GenericConstants.IOL));
      roAcceptedProductUuids.addAll(map.get(OrganisationConstants.GenericConstants.SSR));
      roAcceptedProductUuids.removeAll(acProducts);
    }
  }

  private List<Contact> populateContacts(
          List<RoDataCreateContact> contacts, RecognisingOrganisation organisation) {

    List<Contact> contactList = new ArrayList<>();
    if (contacts != null) {
      contacts.forEach(
          contact -> {
            Contact contactToBeAdded = new Contact();
            contactToBeAdded.setTitle(contact.getTitle());
            contactToBeAdded.setFirstName(contact.getFirstName());
            contactToBeAdded.setLastName(contact.getLastName());
            contactToBeAdded.setJobTitle(contact.getJobTitle());
            contactToBeAdded.setContactTypeUuid(contact.getContactTypeUuid());
            // Here the effective_from_datetime and effective_to_datetime are not coming
            // from UI, So we are hardcoding them here
            contactToBeAdded.setEffectiveFromDatetime(contact.getEffectiveFromDateTime());
            contactToBeAdded.setEffectiveToDatetime(contact.getEffectiveToDateTime());
            contactToBeAdded.setAddresses(
                populateAddress(contactToBeAdded, contact.getAddresses(), organisation));
            contactToBeAdded.setRecognisingOrganisation(organisation);
            contactList.add(contactToBeAdded);
          });
    }
    return contactList;
  }

  private List<AlternateName> populateAlternateName(
          List<RoDataCreateAlternateName> alternateNames, RecognisingOrganisation organisation) {

    List<AlternateName> alternateNamesList = new ArrayList<>();
    if (alternateNames != null) {
      alternateNames.forEach(
          altName -> {
            AlternateName altNameToBeAdded = new AlternateName();
            altNameToBeAdded.setName(altName.getName());
            altNameToBeAdded.setRecognisingOrganisation(organisation);
            alternateNamesList.add(altNameToBeAdded);
          });
    }
    return alternateNamesList;
  }

  private List<RoNote> populateRoNotes(
          List<RoDataCreateNote> notes, RecognisingOrganisation organisation) {
    List<RoNote> roNotesList = new ArrayList<>();
    if (notes != null) {
      notes.forEach(
          note -> {
            RoNote noteToBeAdded = new RoNote();
            noteToBeAdded.setNoteContent(note.getNoteContent());
            /*
             * NoteType is not sent from UI so for now we are hardcoding it to Internal
             * NoteType
             */
            NoteType noteType = noteTypeRepository.findByNotesType("Internal");
            noteToBeAdded.setNoteTypeUuid(noteType.getNoteTypeUuid());
            noteToBeAdded.setRecognisingOrganisation(organisation);
            roNotesList.add(noteToBeAdded);
          });
    }
    return roNotesList;
  }

  private List<Address> populateAddress(
          Contact contact, List<RoDataCreateAddress> addresses, RecognisingOrganisation organisation) {

    List<Address> addressList = new ArrayList<>();
    if (addresses != null) {
      addresses.forEach(
          address -> {
            Address addressToBeAdded = new Address();
            addressToBeAdded.setAddressTypeUuid(address.getAddressTypeUuid());
            addressToBeAdded.setCountryUuid(address.getCountryUuid());
            addressToBeAdded.setTerritoryUuid(address.getTerritoryUuid());
            addressToBeAdded.setAddressline1(address.getAddressLine1());
            addressToBeAdded.setAddressline2(address.getAddressLine2());
            addressToBeAdded.setAddressline3(address.getAddressLine3());
            addressToBeAdded.setAddressline4(address.getAddressLine4());
            addressToBeAdded.setCity(address.getCity());
            addressToBeAdded.setPostalCode(address.getPostalCode());
            addressToBeAdded.setEmail(address.getEmail());
            addressToBeAdded.setPhone(address.getPhone());
            addressToBeAdded.setRecognisingOrganisation(organisation);
            if (contact != null) {
              addressToBeAdded.setContact(contact);
            }
            addressList.add(addressToBeAdded);
          });
    }
    return addressList;
  }

  public RecognisingOrganisation populateSetterMethods(
      final RoDataCreate roData, final RecognisingOrganisation orgDetails) {

    orgDetails.setName(roData.getOrganisationName());
    orgDetails.setOrganisationTypeUuid(roData.getOrganisationTypeUuid());
    orgDetails.setSectorTypeUuid(roData.getSectorTypeUuid());
    orgDetails.setVerificationStatus(roData.getVerificationStatus());
    orgDetails.setPartnerCode(roData.getPartnerCode());
    orgDetails.setPartnerContact(roData.getPartnerContact());
    orgDetails.setMethodOfDelivery(roData.getMethodOfDelivery());
    orgDetails.setOrgStatus(roData.getOrganisationStatus());
    orgDetails.setWebsiteUrl(roData.getWebsiteUrl());
    orgDetails.setOrganisationCode(roData.getOrganisationCode());
    orgDetails.setResultAvailableForYears(
        populateResultAvailableForYears(roData.getResultAvailableForYears()));
    orgDetails.setIeltsDisplayFlag(
        populateIeltsFlag(roData.getOrganisationTypeUuid(), roData.getIeltsDisplayFlag()));
    orgDetails.setOrsDisplayFlag(populateOrsFlag(roData.getOrsDisplayFlag()));
    orgDetails.setCrmSystem(roData.getCrmSystem());
    orgDetails.setSoftDeleted(false);
    return orgDetails;
  }
  /**
   * @param organisationTypeUuid
   * @param ieltsDisplayFlag
   * @return populateIeltsFlag method is used to set default values in code if flag is coming as
   *     null through api request
   */
  public boolean populateIeltsFlag(UUID organisationTypeUuid, Boolean ieltsDisplayFlag) {
    Boolean flag = ieltsDisplayFlag;
    Optional<OrganisationType> organisationType =
        organisationTypeRepository.findById(organisationTypeUuid);
    if (organisationType.isPresent() && ieltsDisplayFlag == null) {
      flag =
          OrganisationConstants.GenericConstants.RECOGNISING_ORGANISATION.equals(
              organisationType.get().getOrganisationsType());
    }
    return flag;
  }

  /**
   * @param orsDisplayFlag
   * @return populateOrsFlag method is used to set default values in code if flag is coming as null
   *     through api request
   */
  public boolean populateOrsFlag(Boolean orsDisplayFlag) {
    Boolean flag = orsDisplayFlag;
    if (orsDisplayFlag == null) {
      flag = true;
    }
    return flag;
  }

  public int populateResultAvailableForYears(Integer resultAvailableForYears) {
    if (resultAvailableForYears == null) {
      resultAvailableForYears =
          Integer.valueOf(
              OrganisationConstants.GenericConstants.DEFAULT_RESULT_AVAILABLE_FOR_YEARS);
    }
    return resultAvailableForYears;
  }

  public RecognisingOrganisation populateOrgDetailsBasedOnAction(
          final RoDataCreate roData, final RecognisingOrganisation orgDetails) {
    return populateSetterMethods(roData, orgDetails);
  }

  public RoDetailsDataGeneratedEventV1 entityToEventMapperForOrgDetailsDataGenerated(
      Set<RecognisingOrganisation> orgDetails) {

    RoDetailsDataGeneratedEventV1 roDetailsDataGeneratedEventV1 =
        new RoDetailsDataGeneratedEventV1();
    for (RecognisingOrganisation recognisingOrganisation : orgDetails) {
      RoDetailsDataGeneratedEventV1RO event = new RoDetailsDataGeneratedEventV1RO();
      event.setName(recognisingOrganisation.getName());
      event.setRecognisingOrganisationUuid(
          recognisingOrganisation.getRecognisingOrganisationUuid());
      event.setOrganisationTypeUuid(recognisingOrganisation.getOrganisationTypeUuid());
      roDetailsDataGeneratedEventV1.add(event);
    }
    return roDetailsDataGeneratedEventV1;
  }

  public RoChangedEventV1 entityToEventMapper(RecognisingOrganisation publishRo) {

    RoChangedEventV1 roChangedEvent = new RoChangedEventV1();
    roChangedEvent.setRecognisingOrganisationUuid(publishRo.getRecognisingOrganisationUuid());
    roChangedEvent.setOrganisationName(publishRo.getName());
    roChangedEvent.setOrganisationId(publishRo.getOrganisationId());
    roChangedEvent.setOrganisationTypeUuid(publishRo.getOrganisationTypeUuid());
    roChangedEvent.setOrganisationType(
        getOrganisationTypeFromUuid(
            organisationTypeRepository.findAll(), roChangedEvent.getOrganisationTypeUuid()));
    roChangedEvent.setOrganisationStatus(publishRo.getOrgStatus());
    roChangedEvent.setVerificationStatus(publishRo.getVerificationStatus());
    roChangedEvent.setAddresses(setAddressesForOrganisationAddresses(publishRo.getAddresses()));
    roChangedEvent.setPartnerCode(publishRo.getPartnerCode());
    roChangedEvent.setPartnerContact(publishRo.getPartnerContact());
    roChangedEvent.setMethodOfDelivery(publishRo.getMethodOfDelivery());
    roChangedEvent.setSectorTypeUuid(publishRo.getSectorTypeUuid());
    roChangedEvent.setSectorType(
        getSectorTypeFromUuid(sectorTypeRepository.findAll(), roChangedEvent.getSectorTypeUuid()));
    roChangedEvent.setWebsiteUrl(publishRo.getWebsiteUrl());
    roChangedEvent.setCrmSystem(publishRo.getCrmSystem());
    roChangedEvent.setOrganisationCode(publishRo.getOrganisationCode());
    roChangedEvent.setResultAvailableForYears(
        populateResultAvailableForYears(publishRo.getResultAvailableForYears()));
    roChangedEvent.setIeltsDisplayFlag(
        populateIeltsFlag(publishRo.getOrganisationTypeUuid(), publishRo.getIeltsDisplayFlag()));
    roChangedEvent.setOrsDisplayFlag(populateOrsFlag(publishRo.getOrsDisplayFlag()));
    roChangedEvent.setNotes(getNotes(publishRo));
    roChangedEvent.setAlternateNames(getAlternateNames(publishRo));
    roChangedEvent.setContacts(getContacts(publishRo));
    roChangedEvent.setRecognisedProducts(getRecognisedProducts(publishRo));
    roChangedEvent.setMinimumScores(getMinimumScores(publishRo));
    roChangedEvent.setSoftDeleted(publishRo.getSoftDeleted());
    roChangedEvent.setLinkedOrganisations(getLinkedOrganisations(publishRo));
    roChangedEvent.setParentOrgId(
        getParentOrg(publishRo.getLinkedRecognisingOrganisations()).getOrganisationId());
    return roChangedEvent;
  }

    public RecognisingOrganisation getParentOrg(
            List<LinkedRecognisingOrganisation> linkedOrganisations) {
        if (linkedOrganisations != null) {
            return linkedOrganisations.stream()
                    .filter(
                            linkedOrg ->
                  LinkTypeEnum.PARENT_RO.getValue().equals(linkedOrg.getLinkedRecognisingOrganisationType().getValue())
                      && linkedOrg
                          .getEffectiveToDatetime()
                          .isAfter(OffsetDateTime.now()))
          .map(LinkedRecognisingOrganisation::getTargetRecognisingOrganisation)
          .findAny()
          .orElse(new RecognisingOrganisation());
    }
    return new RecognisingOrganisation();
  }

  public RoChangedEventV1LinkedOrganisations getLinkedOrganisations(
      RecognisingOrganisation publishRo) {
    RoChangedEventV1LinkedOrganisations linkedOrganisations =
        new RoChangedEventV1LinkedOrganisations();
    if (publishRo.getLinkedRecognisingOrganisations() != null) {
      for (LinkedRecognisingOrganisation savedLinkedOrganisation :
          publishRo.getLinkedRecognisingOrganisations()) {
        if (savedLinkedOrganisation.getEffectiveToDatetime().isAfter(OffsetDateTime.now())) {
          RoChangedEventV1LinkedOrganisation roChangedLinkedOrganisation =
              new RoChangedEventV1LinkedOrganisation();
          roChangedLinkedOrganisation.setLinkedRecognisingOrganisationUuid(
              savedLinkedOrganisation.getLinkedRecognisingOrganisationUuid());
          roChangedLinkedOrganisation.setTargetRecognisingOrganisationUuid(
              savedLinkedOrganisation
                  .getTargetRecognisingOrganisation()
                  .getRecognisingOrganisationUuid());
          roChangedLinkedOrganisation.setTargetRecognisingOrganisationName(
              savedLinkedOrganisation.getTargetRecognisingOrganisation().getName());
          roChangedLinkedOrganisation.setLinkType(
              savedLinkedOrganisation.getLinkedRecognisingOrganisationType());
          roChangedLinkedOrganisation.setLinkEffectiveFromDateTime(
              savedLinkedOrganisation.getEffectiveFromDatetime());
          roChangedLinkedOrganisation.setLinkEffectiveToDateTime(
              savedLinkedOrganisation.getEffectiveToDatetime());
          linkedOrganisations.add(roChangedLinkedOrganisation);
        }
      }
    }
    return linkedOrganisations;
  }

  public RoChangedEventV1MinimumScores getMinimumScores(RecognisingOrganisation publishRo) {

    RoChangedEventV1MinimumScores minScores = new RoChangedEventV1MinimumScores();
    if (publishRo.getMinimumScores() != null) {
      for (MinimumScore minScore : publishRo.getMinimumScores()) {
        RoChangedEventV1MinimumScore roChangedEventMinScore = new RoChangedEventV1MinimumScore();
        roChangedEventMinScore.setMinimumScoreUuid(minScore.getMinscoreReqUuid());
        roChangedEventMinScore.setModuleTypeUuid(minScore.getModuleTypeUuid());
        roChangedEventMinScore.setComponent(minScore.getComponent());
        roChangedEventMinScore.setMinimumScoreValue(minScore.getMinimumScoreValue());
        minScores.add(roChangedEventMinScore);
      }
    }
    return minScores;
  }

  private RoChangedEventV1RecognisedProducts getRecognisedProducts(
      RecognisingOrganisation publishRo) {

    RoChangedEventV1RecognisedProducts recognisedProducts =
        new RoChangedEventV1RecognisedProducts();
    if (publishRo.getRecognisedProducts() != null) {
      for (RecognisedProduct recognisedProduct : publishRo.getRecognisedProducts()) {
        RoChangedEventV1RecognisedProduct roChangedEventRecognisedProduct =
            new RoChangedEventV1RecognisedProduct();
        roChangedEventRecognisedProduct.setRecognisedProductUuid(
            recognisedProduct.getRecognisedProductUuid());
        roChangedEventRecognisedProduct.setProductUuid(recognisedProduct.getProductUuid());
        roChangedEventRecognisedProduct.setEffectiveFromDateTime(
            recognisedProduct.getEffectiveFromDatetime());
        roChangedEventRecognisedProduct.setEffectiveToDateTime(
            recognisedProduct.getEffectiveToDatetime());
        recognisedProducts.add(roChangedEventRecognisedProduct);
      }
    }
    return recognisedProducts;
  }

  public RoChangedEventV1Contacts getContacts(RecognisingOrganisation publishRo) {

    RoChangedEventV1Contacts contacts = new RoChangedEventV1Contacts();
    if (publishRo.getContacts() != null) {
      for (Contact contact : publishRo.getContacts()) {
        RoChangedEventV1Contact roChangedEventContact = new RoChangedEventV1Contact();
        roChangedEventContact.setContactUuid(contact.getContactUuid());
        roChangedEventContact.setTitle(contact.getTitle());
        roChangedEventContact.setFirstName(contact.getFirstName());
        roChangedEventContact.setLastName(contact.getLastName());
        roChangedEventContact.setJobTitle(contact.getJobTitle());
        roChangedEventContact.setContactTypeUuid(contact.getContactTypeUuid());
        roChangedEventContact.setContactType(
            getContactTypeFromUuid(roChangedEventContact.getContactTypeUuid()));
        roChangedEventContact.setEffectiveFromDateTime(contact.getEffectiveFromDatetime());
        roChangedEventContact.setEffectiveToDateTime(contact.getEffectiveToDatetime());
        roChangedEventContact.setAddresses(getAddresses(contact.getAddresses()));
        contacts.add(roChangedEventContact);
      }
    }
    return contacts;
  }

  public RoChangedEventV1AlternateNames getAlternateNames(RecognisingOrganisation publishRo) {

    RoChangedEventV1AlternateNames alternateNames = new RoChangedEventV1AlternateNames();
    if (publishRo.getAlternateNames() != null) {
      for (AlternateName altName : publishRo.getAlternateNames()) {
        RoChangedEventV1AlternateName roChangedEventAltName = new RoChangedEventV1AlternateName();
        roChangedEventAltName.setAlternateNameUuid(altName.getAlternateNameUuid());
        roChangedEventAltName.setName(altName.getName());
        alternateNames.add(roChangedEventAltName);
      }
    }
    return alternateNames;
  }

  public RoChangedEventV1Notes getNotes(RecognisingOrganisation publishRo) {

    RoChangedEventV1Notes notes = new RoChangedEventV1Notes();
    if (publishRo.getNotes() != null) {
      for (RoNote note : publishRo.getNotes()) {
        RoChangedEventV1Note roChangedEventNote = new RoChangedEventV1Note();
        roChangedEventNote.setNoteUuid(note.getNoteUuid());
        roChangedEventNote.setNoteTypeUuid(note.getNoteTypeUuid());
        roChangedEventNote.setNoteContent(note.getNoteContent());
        if (note.getUpdatedDatetime() != null) {
          LocalDateTime updatedDateTime =
              LocalDateTime.ofInstant(note.getUpdatedDatetime(), ZoneOffset.UTC);
          roChangedEventNote.setUpdatedDatetime(updatedDateTime);
        }
        notes.add(roChangedEventNote);
      }
    }
    return notes;
  }

  public RoChangedEventV1Addresses setAddressesForOrganisationAddresses(
      List<Address> publishRoAddresses) {
    if (publishRoAddresses != null) {
      RoChangedEventV1Addresses addresses = new RoChangedEventV1Addresses();
      for (Address address : publishRoAddresses) {
        if (address.getContact() == null) {
          setAddresses(address, addresses);
        }
      }
      return addresses;
    }
    return new RoChangedEventV1Addresses();
  }

  private void setAddresses(Address address, RoChangedEventV1Addresses addresses) {

    RoChangedEventV1Address roChangedEventAddress = new RoChangedEventV1Address();
    roChangedEventAddress.setAddressUuid(address.getAddressUuid());
    roChangedEventAddress.setAddressTypeUuid(address.getAddressTypeUuid());
    roChangedEventAddress.setAddressType(
        getAddressTypeFromUuid(roChangedEventAddress.getAddressTypeUuid()));
    roChangedEventAddress.setAddressLine1(address.getAddressline1());
    roChangedEventAddress.setAddressLine2(address.getAddressline2());
    roChangedEventAddress.setAddressLine3(address.getAddressline3());
    roChangedEventAddress.setAddressLine4(address.getAddressline4());
    roChangedEventAddress.setCity(address.getCity());
    roChangedEventAddress.setTerritoryUuid(address.getTerritoryUuid());
    Territory territory =
        getTerritoryFromTerritoryUuid(
            territoryRepository.findAll(), roChangedEventAddress.getTerritoryUuid());
    roChangedEventAddress.setTerritoryIsoCode(territory.getTerritoryIsoCode());
    roChangedEventAddress.setTerritory(territory.getTerritoryName());
    roChangedEventAddress.setCountryUuid(address.getCountryUuid());
    Country country =
        getCountryFromCountryUuid(
            countryRepository.findAll(), roChangedEventAddress.getCountryUuid());
    roChangedEventAddress.setCountryIso3Code(country.getCountryIso3Code());
    roChangedEventAddress.setCountry(country.getCountryName());
    roChangedEventAddress.setPostalCode(address.getPostalCode());
    roChangedEventAddress.setEmail(address.getEmail());
    roChangedEventAddress.setPhone(address.getPhone());
    addresses.add(roChangedEventAddress);
  }

  private RoChangedEventV1Addresses getAddresses(List<Address> publishRoAddresses) {

    if (publishRoAddresses != null) {
      RoChangedEventV1Addresses addresses = new RoChangedEventV1Addresses();
      for (Address address : publishRoAddresses) {
        setAddresses(address, addresses);
      }
      return addresses;
    }

    return new RoChangedEventV1Addresses();
  }

  private Country getCountryFromCountryUuid(final List<Country> countries, final UUID countryUuid) {
    return countries.stream()
        .filter(country -> country.getCountryUuid().equals(countryUuid))
        .findAny()
        .orElseGet(Country::new);
  }

  private Territory getTerritoryFromTerritoryUuid(
      final List<Territory> territories, final UUID territoryUuid) {
    return territories.stream()
        .filter(territory -> territory.getTerritoryUuid().equals(territoryUuid))
        .findAny()
        .orElseGet(Territory::new);
  }

  public String getOrganisationTypeFromUuid(
      final List<OrganisationType> organisationTypes, final UUID organisationTypeUuid) {
    return organisationTypes.stream()
        .filter(
            organisationType ->
                organisationType.getOrganisationTypeUuid().equals(organisationTypeUuid))
        .findAny()
        .map(OrganisationType::getDescription)
        .orElse(null);
  }

  public String getSectorTypeFromUuid(
      final List<SectorType> sectorTypes, final UUID sectorTypeUuid) {
    return sectorTypes.stream()
        .filter(sectorType -> sectorType.getSectorTypeUuid().equals(sectorTypeUuid))
        .findAny()
        .map(SectorType::getSectorsType)
        .orElse(null);
  }

  public String getAddressTypeFromUuid(final UUID addressTypeUuid) {
    final List<AddressType> addressTypes = addressTypeRepository.findAll();
    return addressTypes.stream()
        .filter(addressType -> addressType.getAddressTypeUuid().equals(addressTypeUuid))
        .findAny()
        .map(AddressType::getAddressTypeName)
        .orElse(null);
  }

  private String getContactTypeFromUuid(final UUID contactTypeUuid) {
    List<ContactType> contactTypes = contactTypeRepository.findAll();
    return contactTypes.stream()
        .filter(contactType -> contactType.getContactTypeUuid().equals(contactTypeUuid))
        .findAny()
        .map(ContactType::getContactsType)
        .orElse(null);
  }

  public Set<ConstraintViolation<Object>> checkPermissionForROVO(
      String accessToken, String orgType, String operation, CMDSAuditContext audit)
      throws RbacValidationException {

    Set<ConstraintViolation<Object>> violations = new HashSet<>();

    HashMap<String, String> permissionsMap = new HashMap<>();
    permissionsMap.put(
        OrganisationConstants.GenericConstants.CREATE
            + OrganisationConstants.GenericConstants.RECOGNISING_ORGANISATION,
        OrganisationConstants.GenericConstants.CREATE_RO_PERMISSION_ID);
    permissionsMap.put(
        OrganisationConstants.GenericConstants.CREATE
            + OrganisationConstants.GenericConstants.VERIFIED_ORGANISATION,
        OrganisationConstants.GenericConstants.CREATE_VO_PERMISSION_ID);
    permissionsMap.put(
        OrganisationConstants.GenericConstants.UPDATE
            + OrganisationConstants.GenericConstants.RECOGNISING_ORGANISATION,
        OrganisationConstants.GenericConstants.UPDATE_RO_PERMISSION_ID);
    permissionsMap.put(
        OrganisationConstants.GenericConstants.UPDATE
            + OrganisationConstants.GenericConstants.VERIFIED_ORGANISATION,
        OrganisationConstants.GenericConstants.UPDATE_VO_PERMISSION_ID);
    audit.setPermission(permissionsMap.get(operation + orgType));
    if (!rbacService.isAuthorised(accessToken, permissionsMap.get(operation + orgType))) {
      violations = getRbacRelatedViolations(operation + orgType, violations);
    }
    return violations;
  }

  public Set<ConstraintViolation<Object>> getRbacRelatedViolations(
      String organisationType, Set<ConstraintViolation<Object>> violations) {
    switch (organisationType) {
      case OrganisationConstants.GenericConstants.CREATE
          + OrganisationConstants.GenericConstants.RECOGNISING_ORGANISATION:
        violations = getSetforNullViolationOfEventBody("V0017", "UnauthorisedToCreateRO");
        log.debug("You do not have permission to create a RO. {} ", organisationType);
        break;

      case OrganisationConstants.GenericConstants.CREATE
          + OrganisationConstants.GenericConstants.VERIFIED_ORGANISATION:
        violations = getSetforNullViolationOfEventBody("V0018", "UnauthorisedToCreateVO");
        log.debug("You do not have permission to create a VO. {} ", organisationType);
        break;

      case OrganisationConstants.GenericConstants.UPDATE
          + OrganisationConstants.GenericConstants.RECOGNISING_ORGANISATION:
        violations = getSetforNullViolationOfEventBody("V0046", "UnauthorisedToUpdateRO");
        log.debug("You do not have permission to update a RO. {} ", organisationType);
        break;

      case OrganisationConstants.GenericConstants.UPDATE
          + OrganisationConstants.GenericConstants.VERIFIED_ORGANISATION:
        violations = getSetforNullViolationOfEventBody("V0047", "UnauthorisedToUpdateVO");
        log.debug("You do not have permission to update a VO. {} ", organisationType);
        break;

      default:
        break;
    }
    return violations;
  }

  public void setEventDiscriminatorForExternalSystems(
      final BaseHeader roHeader, final RecognisingOrganisation publishRo) {

    String organisationTypeDescription =
        getOrganisationTypeFromUuid(
            organisationTypeRepository.findAll(), publishRo.getOrganisationTypeUuid());
    final boolean isApprovedOrVerifiedStatusExists = checkVerifiedOrApprovedStatusExists(publishRo, organisationTypeDescription);
    if (OrganisationConstants.GenericConstants.RO_DESCRIPTION.equals(organisationTypeDescription)) {
      if (VerificationStatusEnum.APPROVED.getValue().equals(publishRo.getVerificationStatus().getValue())
          || isApprovedOrVerifiedStatusExists) {
        roHeader.setEventDiscriminator("ROApproved");
      } else {
        roHeader.setEventDiscriminator(null);
      }
      if(VerificationStatusEnum.VERIFIED.getValue().equals(publishRo.getVerificationStatus().getValue())) {
        roHeader.setEventDiscriminator("VOVerified");
      }
    } else if (OrganisationConstants.GenericConstants.VO_DESCRIPTION.equals(
        organisationTypeDescription)) {
      if (VerificationStatusEnum.VERIFIED.getValue().equals(publishRo.getVerificationStatus().getValue())
          || isApprovedOrVerifiedStatusExists) {
        roHeader.setEventDiscriminator("VOVerified");
      } else {
        roHeader.setEventDiscriminator(null);
      }
    } else {
    	throw new IllegalStateException();
    }
  }

    private Boolean checkVerifiedOrApprovedStatusExists(RecognisingOrganisation publishRo, String organisationTypeDescription) {

    boolean isVerifiedOrApprovedStatusExists = false;
    List<StatusHistory> statusHistoryDetails =
        statusHistoryRepository.findByRecognisingOrganisationOrderByStatusDatetimeDesc(publishRo);
    if (!statusHistoryDetails.isEmpty()
        && (VerificationStatusEnum.VERIFIED
                .getValue()
                .equals(statusHistoryDetails.get(0).getStatus().getValue())
            || VerificationStatusEnum.APPROVED
                .getValue()
                .equals(statusHistoryDetails.get(0).getStatus().getValue()))) {
            isVerifiedOrApprovedStatusExists = true;
        }
      if(!statusHistoryDetails.isEmpty()
              && OrganisationConstants.GenericConstants.RO_DESCRIPTION.equals(organisationTypeDescription)
              && VerificationStatusEnum.VERIFIED.getValue().
              equals(statusHistoryDetails.get(statusHistoryDetails.size()-1).getStatus().getValue())){
        isVerifiedOrApprovedStatusExists = false;
      }
        return isVerifiedOrApprovedStatusExists;
    }

  public Set<RecognisingOrganisation> getHierarchyBasedOnRecognisingOrganisationUuid(
      UUID organisationUuid) {
    log.debug("OrganisationUuid: {}", organisationUuid);
    /*Checking if we have any records in linkedOrganisation table with OrganisatonUuid*/
    List<LinkedRecognisingOrganisation> linkedROListMatchingWithSourceOrTarget =
        linkedRecognisingOrganisationRepository.findBySourceAndLinkTypeOrTargetAndLinkType(
            organisationUuid, LinkTypeEnum.PARENT_RO, organisationUuid, LinkTypeEnum.PARENT_RO);
    List<LinkedRecognisingOrganisation> activeLinkedROListMatchingWithSourceOrTarget =
        linkedROListMatchingWithSourceOrTarget.stream()
            .filter(linkedRO -> linkedRO.getEffectiveToDatetime().isAfter(OffsetDateTime.now()))
            .collect(Collectors.toList());
    log.debug(
        "Data Matching with source or target in linkedOrganisations:{}",
        activeLinkedROListMatchingWithSourceOrTarget.toString());
    Set<RecognisingOrganisation> finalHierarchySet = new HashSet<>();
    if (activeLinkedROListMatchingWithSourceOrTarget.isEmpty()) {
      /*If there is no record in linkedOrganisation table then that Organisation is considered as main root node and we return it in hierarchy list*/
      Optional<RecognisingOrganisation> ro = orgRepository.findById(organisationUuid);
      if (ro.isPresent()) {
        finalHierarchySet.add(ro.get());
      }
    } else {
      /*If we find some records then we take the organisationHierarchyLabel and query on linkedOrganisationRepository with all matching labels to get the hierarchy*/
      List<LinkedRecognisingOrganisation> hierarchyList =
          linkedRecognisingOrganisationRepository
              .findByLinkedRecognisingOrganisationTypeAndOrganisationHierarchyLabel(
                  LinkTypeEnum.PARENT_RO,
                  activeLinkedROListMatchingWithSourceOrTarget
                      .get(0)
                      .getOrganisationHierarchyLabel())
              .stream()
              .filter(linkedRO -> linkedRO.getEffectiveToDatetime().isAfter(OffsetDateTime.now()))
              .collect(Collectors.toList());
      /*Taking all the source and target recognising organisations to get the hierarchyList*/
      List<RecognisingOrganisation> sourceUuids =
          hierarchyList.stream()
              .map(LinkedRecognisingOrganisation::getSourceRecognisingOrganisation)
              .collect(Collectors.toList());
      List<RecognisingOrganisation> targetUuids =
          hierarchyList.stream()
              .map(LinkedRecognisingOrganisation::getTargetRecognisingOrganisation)
              .collect(Collectors.toList());
      finalHierarchySet.addAll(sourceUuids);
      finalHierarchySet.addAll(targetUuids);
    }
    log.debug("Final Hierarchy List: {}", finalHierarchySet.toString());
    return finalHierarchySet;
  }

  public Set<RecognisingOrganisation> getChildHierarchyBasedOnRO(
      UUID roUuid, Boolean onlyImmediateChildFlag) {
    Set<RecognisingOrganisation> finalHierarchySet = new HashSet<>();
    Optional<RecognisingOrganisation> ro = orgRepository.findById(roUuid);
    if (ro.isPresent() && onlyImmediateChildFlag.equals(Boolean.FALSE)) {
      finalHierarchySet.add(ro.get());
    }
    getChildrenOfRoUuidRecursively(roUuid, finalHierarchySet, onlyImmediateChildFlag);
    return finalHierarchySet;
  }

  public Set<RecognisingOrganisation> getChildrenOfRoUuidRecursively(
      UUID roUuid, Set<RecognisingOrganisation> finalHierarchySet, Boolean onlyImmediateChildFlag) {
    /*Get all the LinkedOrganisations where RoUuid is in target(i.e. as Parent)*/
    List<LinkedRecognisingOrganisation> linkedROListMatchingWithTarget =
        linkedRecognisingOrganisationRepository.findByTargetRoUuidAndParentOrganisationType(
            roUuid, LinkTypeEnum.PARENT_RO);
    if (!linkedROListMatchingWithTarget.isEmpty()) {
      /*If the Organisation with roUuid has children then iterate on each child and get its children recursively*/
      for (LinkedRecognisingOrganisation linkedRO : linkedROListMatchingWithTarget) {
        if (linkedRO.getEffectiveToDatetime().isAfter(OffsetDateTime.now())) {
          /*Source Organisations are added nto the final hierarchy list as they are children of roUuid organisation*/
          finalHierarchySet.add(linkedRO.getSourceRecognisingOrganisation());
          if (onlyImmediateChildFlag.equals(Boolean.FALSE)) {
            UUID sourceUuid =
                linkedRO.getSourceRecognisingOrganisation().getRecognisingOrganisationUuid();
            getChildrenOfRoUuidRecursively(sourceUuid, finalHierarchySet, onlyImmediateChildFlag);
          }
        }
      }
    }
    return finalHierarchySet;
  }

  public void generateRejectedEventResponse(
      final BaseHeader roHeader,
      final Set<ConstraintViolation<Object>> violations,
      BaseAudit audit,
      final String dataRecord)
      throws JsonProcessingException {
    roHeader.setEventName(OrganisationConstants.EventType.RO_VIEW_DETAILS_REJECTED_EVENT);
    CMDSErrorResponse eventErrors =
        errorResolver.populatErrorResponse(
            violations, OrganisationConstants.EventType.RO_VIEW_DETAILS_REJECTED_EVENT);
    BaseEventErrors baseEventErrors = new BaseEventErrors(eventErrors.getErrorList());
    if (Objects.nonNull(dataRecord)) {
      audit.getAuditContext().put(OrganisationConstants.GenericConstants.RECORD, dataRecord);
    }
    BaseEvent<? extends BaseHeader> event = new BaseEvent<>(roHeader, null, baseEventErrors, audit);
    log.debug("BaseEvent : {}", objectMapper.writeValueAsString(event));
    applicationEventPublisher.publishEvent(event);
  }

  public void publishForRODetailsDataGenerated(
      final BaseHeader eventHeaders,
      final Set<RecognisingOrganisation> recognisingOrganisation,
      BaseAudit audit)
      throws JsonProcessingException {
    eventHeaders.setEventName(OrganisationConstants.EventType.RO_DETAILS_DATA_GENERATED_EVENT);
    eventHeaders.setEventDateTime(LocalDateTime.now());

    RoDetailsDataGeneratedEventV1 eventBody = null;
    if (!recognisingOrganisation.isEmpty()) {
      eventBody = entityToEventMapperForOrgDetailsDataGenerated(recognisingOrganisation);

    } else {
      log.debug("Organisation doesn't exist with this ID");
      eventBody = new RoDetailsDataGeneratedEventV1();
    }
    BaseEvent<BaseHeader> event =
        new BaseEvent<>(eventHeaders, objectMapper.writeValueAsString(eventBody), null, audit);
    applicationEventPublisher.publishEvent(event);
  }

  public BaseEvent<BaseHeader> publishUpdateEvent(
      final BaseHeader baseHeader, final BaseAudit audit, final RecognisingOrganisation publishRO)
      throws JsonProcessingException {
    log.debug("Update Organisation success event audit {} ", audit);
    UiHeader roHeader = new UiHeader();
    BeanUtils.copyProperties(baseHeader, roHeader);
    roHeader.setEventName(OrganisationConstants.EventType.RO_UPDATED_EVENT);
    roHeader.setEventDateTime(LocalDateTime.now());
    roHeader.setPartnerCode(publishRO.getPartnerCode());
    setEventDiscriminatorForExternalSystems(roHeader, publishRO);
    RoChangedEventV1 orgUpdateEvent = entityToEventMapper(publishRO);
    audit
        .getAuditContext()
        .put(
            OrganisationConstants.GenericConstants.RECORD,
            orgUpdateEvent.getRecognisingOrganisationUuid().toString());

    BaseEvent<BaseHeader> event =
        new BaseEvent<>(roHeader, objectMapper.writeValueAsString(orgUpdateEvent), null, audit);
    applicationEventPublisher.publishEvent(event);
    return event;
  }

  public BaseEvent<BaseHeader> generateErrorEvent(
      BaseHeader eventHeaders, String eventBody, List<ErrorDescription> errorList) {
    BaseHeader baseHeader = new BaseHeader();
    BeanUtils.copyProperties(eventHeaders, baseHeader);
    baseHeader.setEventName(OrganisationConstants.EventType.RO_UPDATE_REJECTED_EVENT);
    BaseEventErrors eventErrors = new BaseEventErrors(errorList);
    return new BaseEvent<>(baseHeader, eventBody, eventErrors, null);
  }

  public List<ErrorDescription> getErrorDescriptions(
      List<ErrorDescription> errorList, Integer orgId) {
    ErrorDescription errorDescription = new ErrorDescription();
    errorDescription.setErrorCode("E0002");
    errorDescription.setInterfaceName(OrganisationConstants.ErrorResponse.RO_INTERFACE_ERROR);
    errorDescription.setTitle("Linked Organisations Failure");
    errorDescription.setMessage(orgId + " " + "Doesn't Exists in Database");
    errorDescription.setType(ErrorTypeEnum.ERROR);
    errorList.add(errorDescription);
    return errorList;
  }

  public void getIOLSSRACGTFlagsBasedOnExistingActiveProductUuidList(
      Set<UUID> activeProductUuidList, Map<String, Boolean> acceptsIOLandAcceptsSSRFlagMap)
          throws JSONException, JsonProcessingException {
    List<Product> bookableProductsInDB = jedisGenericReader.retrieveAllBookableProductsDataFromRedisCache();
    log.debug("Bookable Products FromCache:{}", bookableProductsInDB );
    for (UUID existingActiveProduct : activeProductUuidList) {
      Optional<String> productCharacteristic =
          bookableProductsInDB.stream()
              .filter(
                  bookableProduct ->
                      bookableProduct.getProductUuid().compareTo(existingActiveProduct) == 0)
              .map(Product::getProductCharacteristics)
              .findAny();
      if (productCharacteristic.isPresent()) {
        JSONObject productCharacteristics = new JSONObject(productCharacteristic.get());
        if (productCharacteristics
            .getString(OrganisationConstants.GenericConstants.CHARACTERISTICS)
            .contains(OrganisationConstants.GenericConstants.IOL)) {
          acceptsIOLandAcceptsSSRFlagMap.put(
              OrganisationConstants.GenericConstants.IOL, Boolean.TRUE);
        }
        if (productCharacteristics
            .getString(OrganisationConstants.GenericConstants.CHARACTERISTICS)
            .contains(OrganisationConstants.GenericConstants.SSR)) {
          acceptsIOLandAcceptsSSRFlagMap.put(
              OrganisationConstants.GenericConstants.SSR, Boolean.TRUE);
        }
        if (productCharacteristics
                .getString(OrganisationConstants.GenericConstants.CHARACTERISTICS)
                .contains(OrganisationConstants.GenericConstants.AC)) {
          acceptsIOLandAcceptsSSRFlagMap.put(
                  OrganisationConstants.GenericConstants.AC, Boolean.TRUE);
        }
        if (productCharacteristics
                .getString(OrganisationConstants.GenericConstants.CHARACTERISTICS)
                .contains(OrganisationConstants.GenericConstants.GT)) {
          acceptsIOLandAcceptsSSRFlagMap.put(
                  OrganisationConstants.GenericConstants.GT, Boolean.TRUE);
        }
      }
    }
  }

  public UiHeader buildUiHeader() {
    final CMDSHeaderContext headerContext = ThreadLocalHeaderContext.getContext();
    UiHeader uiHeader = new UiHeader();
    uiHeader.setEventContext(headerContext.getEventContext());
    uiHeader.setCorrelationId(headerContext.getCorrelationId());
    uiHeader.setPartnerCode(headerContext.getPartnerCode());
    uiHeader.setCallbackURL(headerContext.getCallbackURL());
    uiHeader.setTransactionId(headerContext.getTransactionId());
    uiHeader.setConnectionId(headerContext.getConnectionId());
    uiHeader.setEventDiscriminator(headerContext.getEventDiscriminator());
    uiHeader.setXaccessToken(headerContext.getXaccessToken());
    uiHeader.setEventDateTime(headerContext.getEventDateTime());
    uiHeader.setEventName(headerContext.getEventName());
    return uiHeader;
  }

  public BaseAudit getBaseAudit() {
    CMDSAuditContext cmdsAuditContext = ThreadLocalAuditContext.getContext();
    BaseAudit baseAudit = new BaseAudit();
    baseAudit.setPermission(cmdsAuditContext.getPermission());
    baseAudit.setPrincipalId(cmdsAuditContext.getPrincipalId());
    baseAudit.setCausedByTransactionId(cmdsAuditContext.getCausedByTransactionId());
    baseAudit.setCausedByCorrelationId(cmdsAuditContext.getCausedByCorrelationId());
    baseAudit.setAuditContext(cmdsAuditContext.getAuditContext());
    baseAudit.setPrincipalName(cmdsAuditContext.getPrincipalName());
    baseAudit.setCausedByEventName(cmdsAuditContext.getCausedByEventName());
    LocalDateTime localDateTime = cmdsAuditContext.getCausedByEventDateTime();

    // Define the time zone offset
    ZoneOffset zoneOffset = ZoneOffset.ofHoursMinutes(5, 30);

    // Convert the local date and time to an offset zone date and time
    OffsetDateTime offsetDateTime = OffsetDateTime.of(localDateTime, zoneOffset);

    baseAudit.setCausedByEventDateTime(offsetDateTime);

    return baseAudit;
  }

}
