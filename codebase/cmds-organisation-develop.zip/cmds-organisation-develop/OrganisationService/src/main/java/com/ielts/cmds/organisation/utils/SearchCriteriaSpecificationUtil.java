package com.ielts.cmds.organisation.utils;

import com.ielts.cmds.api.roui005rosearchrequested.RoSearchCriteria;
import com.ielts.cmds.api.roui007rocreaterequested.OrganisationStatusEnum;
import com.ielts.cmds.api.roui007rocreaterequested.VerificationStatusEnum;
import com.ielts.cmds.organisation.infrastructure.entity.Address;
import com.ielts.cmds.organisation.infrastructure.entity.AddressType;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.AddressTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.ListJoin;
import javax.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


@Component
public class SearchCriteriaSpecificationUtil {

	@Autowired
	private SearchPartialRoNameCriteriaSpecificationUtil searchPartialRoNameCriteriaSpecificationUtil;

	@Autowired
	private SearchFullTextRoNameCriteriaSpecificationUtil searchFullTextRoNameCriteriaSpecificationUtil;

	@Autowired
	private AddressTypeRepository addressTypeRepository;

	/**
	 * Method to get {@link Specification} for the given {@link RoSearchCriteria}
	 *
	 * @param roSearchCriteria
	 * @return
	 */
	public Specification<RecognisingOrganisation> criteriaMatches(final RoSearchCriteria roSearchCriteria) {
		return (recognisingOrganisation, query, criteriaBuilder) -> {
			List<Predicate> matchCriteriaPredicateList = buildMatchCriteriaPredicateList(recognisingOrganisation,
					roSearchCriteria, criteriaBuilder);
			Predicate[] exactMatchPredicates = new Predicate[matchCriteriaPredicateList.size()];
			ListJoin<RecognisingOrganisation, Address> joinAddress = recognisingOrganisation
					.joinList(OrganisationConstants.GenericConstants.ADDRESS_PROPERTY_NODE, JoinType.LEFT);
			if (Boolean.TRUE.equals(roSearchCriteria.getFuzzyMatch())) {

				RoSearchContext searchContext = new RoSearchContext(searchPartialRoNameCriteriaSpecificationUtil);

				matchCriteriaPredicateList.add(searchContext.roSearchCriteria(roSearchCriteria, joinAddress)
						.toPredicate(recognisingOrganisation, query, criteriaBuilder));
			} else {
				RoSearchContext searchContext = new RoSearchContext(searchFullTextRoNameCriteriaSpecificationUtil);
				matchCriteriaPredicateList.add(searchContext.roSearchCriteria(roSearchCriteria, joinAddress)
						.toPredicate(recognisingOrganisation, query, criteriaBuilder));
			}
			query.distinct(true);
			return criteriaBuilder.and(matchCriteriaPredicateList.toArray(exactMatchPredicates));
		};
	}

	private List<Predicate> buildMatchCriteriaPredicateList(From<?, RecognisingOrganisation> recognisingOrganisation,
															RoSearchCriteria roSearchCriteria, CriteriaBuilder criteriaBuilder) {
		List<Predicate> matchCriteriaPredicateList = new ArrayList<>();
		addSoftDeletePredicate(recognisingOrganisation, criteriaBuilder, matchCriteriaPredicateList);
		addOrganisationStatusPredicate(recognisingOrganisation, roSearchCriteria, criteriaBuilder,
				matchCriteriaPredicateList);
		addVerificationStatusPredicate(recognisingOrganisation, roSearchCriteria, criteriaBuilder,
				matchCriteriaPredicateList);
		addOrganisationIdPredicate(recognisingOrganisation, roSearchCriteria, criteriaBuilder,
				matchCriteriaPredicateList);
		addPartnerCodePredicate(recognisingOrganisation, roSearchCriteria, criteriaBuilder, matchCriteriaPredicateList);
		addOrganisationTypeUuidPredicate(recognisingOrganisation, roSearchCriteria, criteriaBuilder,
				matchCriteriaPredicateList);
		addCityPredicate(recognisingOrganisation, roSearchCriteria, criteriaBuilder, matchCriteriaPredicateList);
		addPostalCodePredicate(recognisingOrganisation, roSearchCriteria, criteriaBuilder, matchCriteriaPredicateList);
		addCountryPredicate(recognisingOrganisation, roSearchCriteria, criteriaBuilder, matchCriteriaPredicateList);
		addTerritoryPredicate(recognisingOrganisation, roSearchCriteria, criteriaBuilder, matchCriteriaPredicateList);
		return matchCriteriaPredicateList;
	}

	private void addSoftDeletePredicate(From<?, RecognisingOrganisation> recognisingOrganisation,
										CriteriaBuilder criteriaBuilder, List<Predicate> predicateList) {
		predicateList.add(criteriaBuilder
				.isFalse(recognisingOrganisation.get(OrganisationConstants.GenericConstants.SOFT_DELETED)));
	}

	private void addOrganisationStatusPredicate(From<?, RecognisingOrganisation> recognisingOrganisation,
												RoSearchCriteria roSearchCriteria, CriteriaBuilder criteriaBuilder, List<Predicate> predicateList) {
		if (!StringUtils.isEmpty(roSearchCriteria.getOrganisationStatus())) {
			predicateList.add(criteriaBuilder.equal(
					recognisingOrganisation.get(OrganisationConstants.GenericConstants.ORGANISATION_STATUS),
					OrganisationStatusEnum.valueOf(roSearchCriteria.getOrganisationStatus().getValue())));
		}
	}

	private void addVerificationStatusPredicate(From<?, RecognisingOrganisation> recognisingOrganisation,
												RoSearchCriteria roSearchCriteria, CriteriaBuilder criteriaBuilder, List<Predicate> predicateList) {
		if (!StringUtils.isEmpty(roSearchCriteria.getVerificationStatus())) {
			predicateList.add(criteriaBuilder.equal(
					recognisingOrganisation.get(OrganisationConstants.GenericConstants.VERIFICATION_STATUS),
					VerificationStatusEnum.valueOf(roSearchCriteria.getVerificationStatus().getValue())));
		}
	}

	private void addOrganisationIdPredicate(From<?, RecognisingOrganisation> recognisingOrganisation,
											RoSearchCriteria roSearchCriteria, CriteriaBuilder criteriaBuilder, List<Predicate> predicateList) {
		if (!StringUtils.isEmpty(roSearchCriteria.getOrganisationId())) {
			predicateList.add(criteriaBuilder.equal(
					recognisingOrganisation.get(OrganisationConstants.GenericConstants.ORGANISATION_ID),
					roSearchCriteria.getOrganisationId()));
		}
	}

	private void addPartnerCodePredicate(From<?, RecognisingOrganisation> recognisingOrganisation,
										 RoSearchCriteria roSearchCriteria, CriteriaBuilder criteriaBuilder, List<Predicate> predicateList) {
		if (!StringUtils.isEmpty(roSearchCriteria.getPartnerCode())) {
			predicateList.add(criteriaBuilder.equal(
					recognisingOrganisation.get(OrganisationConstants.GenericConstants.PARTNER_CODE),
					roSearchCriteria.getPartnerCode()));
		}
	}

	private void addOrganisationTypeUuidPredicate(From<?, RecognisingOrganisation> recognisingOrganisation,
												  RoSearchCriteria roSearchCriteria, CriteriaBuilder criteriaBuilder, List<Predicate> predicateList) {
		if (!StringUtils.isEmpty(roSearchCriteria.getOrganisationTypeUuid())) {
			predicateList.add(criteriaBuilder.equal(
					recognisingOrganisation.get(OrganisationConstants.GenericConstants.ORGANISATION_TYPE_UUID),
					roSearchCriteria.getOrganisationTypeUuid()));
		}
	}


	private void addCityPredicate(From<?, RecognisingOrganisation> recognisingOrganisation,
								  RoSearchCriteria roSearchCriteria, CriteriaBuilder criteriaBuilder, List<Predicate> predicateList) {
		if (!StringUtils.isEmpty(roSearchCriteria.getCity())) {
			ListJoin<RecognisingOrganisation, Address> joinAddress = recognisingOrganisation
					.joinList(OrganisationConstants.GenericConstants.ADDRESS_PROPERTY_NODE, JoinType.LEFT);
			List<AddressType> addressTypes = addressTypeRepository.findAll();
			UUID mainAddressTypeUuid = addressTypes.stream()
					.filter(addressType -> addressType.getAddressTypeName()
							.equals(OrganisationConstants.GenericConstants.MAIN_ADDRESS_TYPE))
					.findAny().map(AddressType::getAddressTypeUuid).orElse(null);

			predicateList.add(
					criteriaBuilder.equal(joinAddress.get(OrganisationConstants.GenericConstants.ADDRESS_TYPE_UUID),
							criteriaBuilder.literal(mainAddressTypeUuid)));
			predicateList.add(criteriaBuilder.isNull(joinAddress.get(OrganisationConstants.GenericConstants.CONTACT)));
			predicateList.add(criteriaBuilder.equal(
					criteriaBuilder.lower(joinAddress.get(OrganisationConstants.GenericConstants.CITY)),
					roSearchCriteria.getCity().toLowerCase()));
		}
	}

	private void addPostalCodePredicate(From<?, RecognisingOrganisation> recognisingOrganisation,
										RoSearchCriteria roSearchCriteria, CriteriaBuilder criteriaBuilder, List<Predicate> predicateList) {
		if (!StringUtils.isEmpty(roSearchCriteria.getPostalCode())) {
			ListJoin<RecognisingOrganisation, Address> joinAddress = recognisingOrganisation
					.joinList(OrganisationConstants.GenericConstants.ADDRESS_PROPERTY_NODE, JoinType.LEFT);
			List<AddressType> addressTypes = addressTypeRepository.findAll();
			UUID mainAddressTypeUuid = addressTypes.stream()
					.filter(addressType -> addressType.getAddressTypeName()
							.equals(OrganisationConstants.GenericConstants.MAIN_ADDRESS_TYPE))
					.findAny().map(AddressType::getAddressTypeUuid).orElse(null);

			predicateList.add(
					criteriaBuilder.equal(joinAddress.get(OrganisationConstants.GenericConstants.ADDRESS_TYPE_UUID),
							criteriaBuilder.literal(mainAddressTypeUuid)));
			predicateList.add(criteriaBuilder.isNull(joinAddress.get(OrganisationConstants.GenericConstants.CONTACT)));
			predicateList.add(criteriaBuilder.equal(
					criteriaBuilder.lower(joinAddress.get(OrganisationConstants.GenericConstants.POSTAL_CODE)),
					roSearchCriteria.getPostalCode().toLowerCase()));
		}
	}

	private void addCountryPredicate(From<?, RecognisingOrganisation> recognisingOrganisation,
									 RoSearchCriteria roSearchCriteria, CriteriaBuilder criteriaBuilder, List<Predicate> predicateList) {
		if (!StringUtils.isEmpty(roSearchCriteria.getCountry())) {
			ListJoin<RecognisingOrganisation, Address> joinAddress = recognisingOrganisation
					.joinList(OrganisationConstants.GenericConstants.ADDRESS_PROPERTY_NODE, JoinType.LEFT);
			List<AddressType> addressTypes = addressTypeRepository.findAll();
			UUID mainAddressTypeUuid = addressTypes.stream()
					.filter(addressType -> addressType.getAddressTypeName()
							.equals(OrganisationConstants.GenericConstants.MAIN_ADDRESS_TYPE))
					.findAny().map(AddressType::getAddressTypeUuid).orElse(null);

			predicateList.add(
					criteriaBuilder.equal(joinAddress.get(OrganisationConstants.GenericConstants.ADDRESS_TYPE_UUID),
							criteriaBuilder.literal(mainAddressTypeUuid)));
			predicateList.add(criteriaBuilder.isNull(joinAddress.get(OrganisationConstants.GenericConstants.CONTACT)));
			predicateList
					.add(criteriaBuilder.equal(joinAddress.get(OrganisationConstants.GenericConstants.COUNTRY_UUID),
							roSearchCriteria.getCountry()));
		}
	}

	private void addTerritoryPredicate(From<?, RecognisingOrganisation> recognisingOrganisation,
									   RoSearchCriteria roSearchCriteria, CriteriaBuilder criteriaBuilder, List<Predicate> predicateList) {
		if (!StringUtils.isEmpty(roSearchCriteria.getTerritory())) {
			ListJoin<RecognisingOrganisation, Address> joinAddress = recognisingOrganisation
					.joinList(OrganisationConstants.GenericConstants.ADDRESS_PROPERTY_NODE, JoinType.LEFT);
			List<AddressType> addressTypes = addressTypeRepository.findAll();
			UUID mainAddressTypeUuid = addressTypes.stream()
					.filter(addressType -> addressType.getAddressTypeName()
							.equals(OrganisationConstants.GenericConstants.MAIN_ADDRESS_TYPE))
					.findAny().map(AddressType::getAddressTypeUuid).orElse(null);

			predicateList.add(
					criteriaBuilder.equal(joinAddress.get(OrganisationConstants.GenericConstants.ADDRESS_TYPE_UUID),
							criteriaBuilder.literal(mainAddressTypeUuid)));
			predicateList.add(criteriaBuilder.isNull(joinAddress.get(OrganisationConstants.GenericConstants.CONTACT)));
			predicateList
					.add(criteriaBuilder.equal(joinAddress.get(OrganisationConstants.GenericConstants.TERRITORY_UUID),
							roSearchCriteria.getTerritory()));
		}
	}

}
