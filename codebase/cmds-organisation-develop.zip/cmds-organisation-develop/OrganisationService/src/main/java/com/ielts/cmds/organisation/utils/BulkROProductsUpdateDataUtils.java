package com.ielts.cmds.organisation.utils;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import com.ielts.cmds.organisation.cache.JedisGenericReader;
import com.ielts.cmds.organisation.cache.entity.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.roui009roupdaterequested.VerificationStatusEnum;
import com.ielts.cmds.api.roui009roupdaterequested.OrganisationStatusEnum;
import com.ielts.cmds.api.roui009roupdaterequested.MethodOfDeliveryEnum;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateLinkedOrganisation;
import com.ielts.cmds.api.roui009roupdaterequested.LinkTypeEnum;
import com.ielts.cmds.organisation.domain.model.RoDataUpdateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.Address;
import com.ielts.cmds.organisation.infrastructure.entity.LinkedRecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisedProduct;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;

@Component
public class BulkROProductsUpdateDataUtils {

    @Autowired RecognisingOrganisationRepository recognisingOrgRepository;

    @Autowired private JedisGenericReader jedisGenericReader;

    @Autowired LoadROHierarchyDataUtils loadROHierarchyDataUtils;

    public RoDataUpdateV1Valid updateProductData(RecognisingOrganisation roToBeUpdated)
            throws JSONException, JsonProcessingException {
        RoDataUpdateV1Valid roDataUpdateV1Valid = new RoDataUpdateV1Valid();
        roDataUpdateV1Valid.setRecognisingOrganisationUuid(
                roToBeUpdated.getRecognisingOrganisationUuid());
        roDataUpdateV1Valid.setOrganisationName(roToBeUpdated.getName());
        roDataUpdateV1Valid.setOrganisationStatus(OrganisationStatusEnum.valueOf(roToBeUpdated.getOrgStatus().getValue()));
        roDataUpdateV1Valid.setOrganisationTypeUuid(roToBeUpdated.getOrganisationTypeUuid());
        roDataUpdateV1Valid.setSectorTypeUuid(roToBeUpdated.getSectorTypeUuid());
        roDataUpdateV1Valid.setPartnerCode(roToBeUpdated.getPartnerCode());
        roDataUpdateV1Valid.setVerificationStatus(VerificationStatusEnum.valueOf(roToBeUpdated.getVerificationStatus().getValue()));
        roDataUpdateV1Valid.setPartnerContact(roToBeUpdated.getPartnerContact());
        roDataUpdateV1Valid.setMethodOfDelivery(MethodOfDeliveryEnum.valueOf(roToBeUpdated.getMethodOfDelivery().getValue()));
        roDataUpdateV1Valid.setWebsiteUrl(roToBeUpdated.getWebsiteUrl());
        roDataUpdateV1Valid.setOrganisationCode(roToBeUpdated.getOrganisationCode());
        roDataUpdateV1Valid.setIeltsDisplayFlag(roToBeUpdated.getIeltsDisplayFlag());
        roDataUpdateV1Valid.setOrsDisplayFlag(roToBeUpdated.getOrsDisplayFlag());
        roDataUpdateV1Valid.setCrmSystem(roToBeUpdated.getCrmSystem());
        roDataUpdateV1Valid.setResultAvailableForYears(roToBeUpdated.getResultAvailableForYears());
        List<Address> addressList =
                roToBeUpdated.getAddresses().stream()
                        .filter(address -> address.getContact() == null)
                        .collect(Collectors.toList());
        roDataUpdateV1Valid.setAddresses(loadROHierarchyDataUtils.loadAddressData(addressList));
        roDataUpdateV1Valid.setContacts(
                loadROHierarchyDataUtils.loadContactsData(roToBeUpdated.getContacts()));
        roDataUpdateV1Valid.setNotes(
                loadROHierarchyDataUtils.loadNotesData(roToBeUpdated.getNotes()));
        setAcceptsIOLandAcceptsSSRFlags(roToBeUpdated.getRecognisedProducts(), roDataUpdateV1Valid);
        roDataUpdateV1Valid.setMinimumScores(
                loadROHierarchyDataUtils.loadMinimumScoresData(roToBeUpdated.getMinimumScores()));
        roDataUpdateV1Valid.setAlternateNames(
                loadROHierarchyDataUtils.loadAlternateNames(roToBeUpdated.getAlternateNames()));
        roDataUpdateV1Valid.setLinkedOrganisations(
                loadLinkedOrganisationsData(roToBeUpdated.getLinkedRecognisingOrganisations()));
        return roDataUpdateV1Valid;
    }

    protected void setAcceptsIOLandAcceptsSSRFlags(
            List<RecognisedProduct> recognisedProducts, RoDataUpdateV1Valid roUpdate)
            throws JSONException, JsonProcessingException {

        Set<UUID> activeRecognisedProductUUidList =
                recognisedProducts.stream()
                        .filter(
                                product ->
                                        product.getEffectiveToDatetime()
                                                .isAfter(OffsetDateTime.now(ZoneOffset.UTC)))
                        .map(RecognisedProduct::getProductUuid)
                        .collect(Collectors.toSet());
        Map<String, Boolean> acceptsIOLandAcceptsSSRFlagMap = new HashMap<>();
        acceptsIOLandAcceptsSSRFlagMap.put(
                OrganisationConstants.GenericConstants.IOL, Boolean.FALSE);
        acceptsIOLandAcceptsSSRFlagMap.put(
                OrganisationConstants.GenericConstants.SSR, Boolean.FALSE);
        getFlagsBasedOnProductUuid(activeRecognisedProductUUidList, acceptsIOLandAcceptsSSRFlagMap);
        roUpdate.setAcceptsIOL(
                acceptsIOLandAcceptsSSRFlagMap.get(OrganisationConstants.GenericConstants.IOL));
        roUpdate.setAcceptsSSR(
                acceptsIOLandAcceptsSSRFlagMap.get(OrganisationConstants.GenericConstants.SSR));
    }

    public void getFlagsBasedOnProductUuid(
            Set<UUID> savedRecognisedProductUuidList,
            Map<String, Boolean> acceptsIOLandAcceptsSSRFlagMap)
            throws JSONException, JsonProcessingException {
        List<Product> bookableProducts = jedisGenericReader.retrieveAllBookableProductsDataFromRedisCache();
        for (UUID savedProduct : savedRecognisedProductUuidList) {
            Optional<String> productCharacteristic =
                    bookableProducts.stream()
                            .filter(
                                    bookableProduct ->
                                            bookableProduct.getProductUuid().compareTo(savedProduct)
                                                    == 0)
                            .map(Product::getProductCharacteristics)
                            .findAny();
            if (productCharacteristic.isPresent()) {
                JSONObject productChracteristics = new JSONObject(productCharacteristic.get());
                if (productChracteristics
                        .getString("characteristics")
                        .contains(OrganisationConstants.GenericConstants.IOL)) {
                    acceptsIOLandAcceptsSSRFlagMap.put(
                            OrganisationConstants.GenericConstants.IOL, Boolean.TRUE);
                }
                if (productChracteristics
                        .getString("characteristics")
                        .contains(OrganisationConstants.GenericConstants.SSR)) {
                    acceptsIOLandAcceptsSSRFlagMap.put(
                            OrganisationConstants.GenericConstants.SSR, Boolean.TRUE);
                }
            }
        }
    }

    private List<RoDataUpdateLinkedOrganisation> loadLinkedOrganisationsData(
            List<LinkedRecognisingOrganisation> existingLinkedOrgs) {
        List<RoDataUpdateLinkedOrganisation> roDataUpdateLinkedOrganisations =
                new ArrayList<>();
        if (!existingLinkedOrgs.isEmpty()) {
            for (LinkedRecognisingOrganisation linkedRO : existingLinkedOrgs) {
                RoDataUpdateLinkedOrganisation linkedOrganisation =
                        new RoDataUpdateLinkedOrganisation();
                linkedOrganisation.setLinkedRecognisingOrganisationUuid(
                        linkedRO.getLinkedRecognisingOrganisationUuid());
                linkedOrganisation.setTargetRecognisingOrganisationUuid(
                        linkedRO.getTargetRecognisingOrganisation()
                                .getRecognisingOrganisationUuid());
                linkedOrganisation.setLinkType(LinkTypeEnum.valueOf(linkedRO.getLinkedRecognisingOrganisationType().getValue()));
                linkedOrganisation.setLinkEffectiveFromDateTime(
                        linkedRO.getEffectiveFromDatetime());
                linkedOrganisation.setLinkEffectiveToDateTime(linkedRO.getEffectiveToDatetime());
                roDataUpdateLinkedOrganisations.add(linkedOrganisation);
            }
        }
        return roDataUpdateLinkedOrganisations;
    }
}
