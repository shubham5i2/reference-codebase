package com.ielts.cmds.organisation.infrastructure.entity;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.Type;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity(name = "note_type")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class NoteType extends ReferenceModel implements Serializable {
	
	/**
	 * Generated SerialVersionId
	 */
	private static final long serialVersionUID = -950095258239669865L;

	@Id
	@GeneratedValue
	@Type(type="uuid-char")
	@Column(name = "note_type_uuid")
	private UUID noteTypeUuid;

	@Column(name = "note_type", nullable = false)
	private String notesType;

	@Column(name = "description")
	private String description;

	
}
