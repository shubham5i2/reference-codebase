package com.ielts.cmds.organisation.infrastructure.entity;

import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.hibernate.annotations.Type;

@Data
@EqualsAndHashCode(
        callSuper = true,
        exclude = {"recognisingOrganisation"})
@Entity(name = "recognised_product")
@ToString(exclude = {"recognisingOrganisation"})
public class RecognisedProduct extends Model implements Serializable {

    /** Generated SerialVersionID */
    private static final long serialVersionUID = 3028573676843762060L;

    @Id
    @GeneratedValue
    @Column(name = "recognised_product_uuid", nullable = false)
    @Type(type = "uuid-char")
    private UUID recognisedProductUuid;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "recognising_organisation_uuid", nullable = false)
    private RecognisingOrganisation recognisingOrganisation;

    @Column(name = "product_uuid", nullable = false)
    @Type(type = "uuid-char")
    private UUID productUuid;
}
