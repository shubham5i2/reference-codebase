package com.ielts.cmds.organisation.domain.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.domain.commands.CreateROVO;
import com.ielts.cmds.organisation.domain.commands.LoadROData;
import com.ielts.cmds.organisation.domain.model.LoadRODataV1;
import com.ielts.cmds.organisation.domain.model.RoDataCreateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.utils.LoadRODataUtils;
import com.ielts.cmds.organisation.utils.OrganisationCommonUtils;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import javax.validation.ConstraintViolation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Slf4j
public class ProcessRODomainService {

    @Autowired private LoadRODataUtils loadRODataUtils;

    @Autowired private OrganisationCommonUtils organisationCommonUtils;

    @Autowired private CreateOrganisationDomainService createOrganisationDomainService;

    @Autowired private RecognisingOrganisationRepository recognisingOrganisationRepository;

    /**
     * For each {@link }, this method will be invoked. All operations under this method, will be
     * executed under one single transaction
     *
     * @param loadROData
     * @throws JsonProcessingException
     */
    @Transactional
    public BaseEvent<BaseHeader> processRecord(
            final LoadROData loadROData, final LoadRODataV1 loadRODataV1) {

        BaseEvent<BaseHeader> event = null;
        Map<String, String> eventContext =
                Optional.ofNullable(loadROData.getEventHeaders().getEventContext())
                        .orElseGet(HashMap::new);

        try {
            RoDataCreateV1Valid roDataCreateV1Valid = new RoDataCreateV1Valid();
            loadROData.getEventHeaders().setCorrelationId(UUID.randomUUID());
            if (eventContext.containsKey(
                    OrganisationConstants.GenericConstants.LOAD_ORGANISATION_TYPE)) {
                roDataCreateV1Valid =
                        loadRODataUtils.loadData(
                                loadRODataV1,
                                eventContext.get(
                                        OrganisationConstants.GenericConstants
                                                .LOAD_ORGANISATION_TYPE));
            }
            Set<ConstraintViolation<Object>> violations = new HashSet<>();
            Set<ConstraintViolation<Object>> dataViolations =
                    createOrganisationDomainService.validateRODetails(roDataCreateV1Valid);
            if (StringUtils.isNotBlank(loadRODataV1.getOrganisationId())) {
                boolean isDuplicateOrgId =
                        recognisingOrganisationRepository.existsByOrganisationIdAndSoftDeletedFalse(
                                Integer.valueOf(
                                        StringUtils.deleteWhitespace(
                                                loadRODataV1.getOrganisationId())));
                if (isDuplicateOrgId) {
                    violations =
                            organisationCommonUtils.getSetforNullViolationOfEventBody(
                                    "V0066", "DuplicateOrganisationId");
                }
            }
            violations.addAll(dataViolations);
            if (violations.isEmpty()) {
                final CreateROVO createROVO =
                        CreateROVO.builder().eventBody(roDataCreateV1Valid).build();
                RecognisingOrganisation roData =
                        organisationCommonUtils.populateOrganisation(
                                createROVO.getEventBody(), new RecognisingOrganisation());
                if (StringUtils.isNotBlank(loadRODataV1.getOrganisationId())) {
                    roData.setOrganisationId(
                            Integer.valueOf(
                                    StringUtils.deleteWhitespace(
                                            loadRODataV1.getOrganisationId())));
                }
                RecognisingOrganisation publishRo = recognisingOrganisationRepository.save(roData);
                recognisingOrganisationRepository.flush();
                
                event =
                        createOrganisationDomainService.registerandPublishCreateOrganisationEvent(
                                loadROData.getEventHeaders(), publishRo, loadROData.getAudit());
            } else {
                log.debug("Violations: {}", violations);
                event =
                        createOrganisationDomainService.generateRejectedEventResponse(
                                loadROData.getEventHeaders(),
                                roDataCreateV1Valid,
                                loadROData.getAudit(),
                                violations,
                                eventContext.getOrDefault(
                                        OrganisationConstants.GenericConstants
                                                .RECOGNISING_ORGANISATION_UUID,
                                        null));
            }
        } catch (Exception e) {
            log.error("Exception in Process Record: {}", e);
        }
        return event;
    }
}
