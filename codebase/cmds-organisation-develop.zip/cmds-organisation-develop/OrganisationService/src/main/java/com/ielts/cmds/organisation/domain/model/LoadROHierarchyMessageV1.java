package com.ielts.cmds.organisation.domain.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode
public class LoadROHierarchyMessageV1 {

    private LoadROHierarchyMapV1 msg;
}
