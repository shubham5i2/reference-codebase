/*
 *
 */
package com.ielts.cmds.organisation.infrastructure.config;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ielts.cmds.common.config.IApplicationService;
import com.ielts.cmds.common.logger.util.CMDSLoggerUtils;
import com.ielts.cmds.rbac.api.service.RBACService;
import com.ielts.cmds.rbac.api.utils.AuditDataUtils;

/**
 * @author vedire
 *
 */
@Configuration
public class OrganisationApplicationServiceConfig {

	List<IApplicationService> iapplicationServices;

	@Autowired
	public OrganisationApplicationServiceConfig(final List<IApplicationService> iapplicationServices) {
		this.iapplicationServices = iapplicationServices;
	}

	@Bean(name="applicationServiceMap")
	public Map<String, IApplicationService> getApplicationServiceMap() {
		return  iapplicationServices.stream()
				.collect(Collectors.toMap(IApplicationService::getServiceIdentifier, Function.identity()));

	}

	@Bean
	public CMDSLoggerUtils getCMDSLoggerUtils() {
		return new CMDSLoggerUtils();
	}
	@Bean
	public AuditDataUtils getAuditDataUtils(RBACService rbacService){
		return new AuditDataUtils(rbacService);
	}
}
