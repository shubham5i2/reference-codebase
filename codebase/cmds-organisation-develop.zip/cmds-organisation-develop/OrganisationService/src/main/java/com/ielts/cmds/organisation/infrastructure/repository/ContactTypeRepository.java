package com.ielts.cmds.organisation.infrastructure.repository;

import com.ielts.cmds.organisation.infrastructure.entity.ContactType;
import java.util.List;
import java.util.UUID;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ContactTypeRepository extends JpaRepository<ContactType, UUID> {

    ContactType findByContactsType(String contactType);

    @Cacheable(value = "contacttypes")
    List<ContactType> findAll();
}
