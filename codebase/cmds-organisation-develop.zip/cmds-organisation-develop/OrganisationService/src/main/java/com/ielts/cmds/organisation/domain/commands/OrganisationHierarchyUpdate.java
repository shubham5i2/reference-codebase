package com.ielts.cmds.organisation.domain.commands;

import com.ielts.cmds.application.command.BaseCommand;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.domain.model.HierarchyUpdateV1;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** @author cts */
@Data
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Builder
public class OrganisationHierarchyUpdate extends BaseCommand<BaseHeader, HierarchyUpdateV1> {

    private BaseHeader eventHeaders;
    private HierarchyUpdateV1 eventBody;
    private BaseEventErrors eventErrors;
    private BaseAudit audit;
}
