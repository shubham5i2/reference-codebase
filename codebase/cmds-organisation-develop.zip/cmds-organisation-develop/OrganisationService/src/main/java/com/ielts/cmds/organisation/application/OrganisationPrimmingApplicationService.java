package com.ielts.cmds.organisation.application;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.config.IApplicationService;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.domain.commands.OrganisationPrimmingCommand;
import com.ielts.cmds.organisation.domain.model.OrganisationPrimmingModel;
import com.ielts.cmds.organisation.domain.services.OrganisationPrimmingDomainService;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class OrganisationPrimmingApplicationService implements IApplicationService {

    @Autowired private ObjectMapper objectMapper;

    @Autowired private OrganisationPrimmingDomainService orgPrimmingDomainService;

    private static final String EVENTNAME =
            OrganisationConstants.GenericConstants.ORGANISATION_PRIMMING_EVENT;

    @Override
    public void process(BaseEvent<? extends BaseHeader> baseEvent) throws ProcessingException {

        try {
            OrganisationPrimmingModel model =
                    objectMapper.readValue(
                            baseEvent.getEventBody(), OrganisationPrimmingModel.class);
            if (model == null) {
                throw new IllegalArgumentException(
                        OrganisationConstants.ErrorResponse.EMPTY_PAYLOAD);
            }
            OrganisationPrimmingCommand command =
                    OrganisationPrimmingCommand.builder()
                            .eventHeaders(baseEvent.getEventHeader())
                            .eventBody(model)
                            .eventErrors(null)
                            .audit(null)
                            .build();
            orgPrimmingDomainService.onCommand(command);
        } catch (Exception e) {
            log.error("Exception while processing Request: ", e);
            throw new ProcessingException(e.getMessage(), e);
        }
    }

    @Override
    public String getServiceIdentifier() {
        return EVENTNAME;
    }
}
