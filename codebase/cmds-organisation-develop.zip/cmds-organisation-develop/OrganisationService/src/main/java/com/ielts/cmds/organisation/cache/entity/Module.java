package com.ielts.cmds.organisation.cache.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Module {

	private UUID moduleTypeUuid;
	
	private String moduleType;
	
	private String description;
}
