package com.ielts.cmds.organisation.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.organisation.domain.model.LoadROHierarchyDataV1;
import com.ielts.cmds.organisation.domain.model.LoadROHierarchyMapV1;
import com.ielts.cmds.organisation.domain.model.LoadROHierarchyMessageV1;
import com.ielts.cmds.organisation.domain.model.LoadROHierarchyRecordEvent;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class LoadROHierarchyEventMapper {

    @Autowired private ObjectMapper objectMapper;

    public LoadROHierarchyMessageV1 mapToEvent(Map<String, LoadROHierarchyRecordEvent> eventsMap) {
        LoadROHierarchyMessageV1 loadROHierarchyMessageV1 = new LoadROHierarchyMessageV1();
        LoadROHierarchyMapV1 loadROHierarchyMapV1 = new LoadROHierarchyMapV1();
        eventsMap.forEach(
                (key, value) -> {
                    try {
                        LoadROHierarchyDataV1 loadROHierarchyDataV1 =
                                getLoadROHierarchyDataV1(value);
                        loadROHierarchyDataV1.setRowNumber(key);
                        loadROHierarchyMapV1.put(key, loadROHierarchyDataV1);
                    } catch (JsonProcessingException e) {
                        log.error("Exception: {}", e);
                    }
                });
        loadROHierarchyMessageV1.setMsg(loadROHierarchyMapV1);
        return loadROHierarchyMessageV1;
    }

    public LoadROHierarchyDataV1 getLoadROHierarchyDataV1(
            final LoadROHierarchyRecordEvent loadROHierarchyRecordEvent)
            throws JsonProcessingException {
        LoadROHierarchyDataV1 loadROHierarchyDataV1 =
                loadROHierarchyRecordEvent.getLoadROHierarchyRecord();

        if (OrganisationConstants.EventType.RO_UPDATED_EVENT.equals(
                loadROHierarchyRecordEvent.getEvent().getEventHeader().getEventName())) {
            RoChangedEventV1 eventBody =
                    objectMapper.readValue(
                            loadROHierarchyRecordEvent.getEvent().getEventBody(),
                            RoChangedEventV1.class);
            loadROHierarchyDataV1.setRecognisingOrganisationUuid(
                    eventBody.getRecognisingOrganisationUuid().toString());
        } else if (OrganisationConstants.EventType.RO_UPDATE_REJECTED_EVENT.equals(
                loadROHierarchyRecordEvent.getEvent().getEventHeader().getEventName())) {
            String errorListString =
                    loadROHierarchyRecordEvent.getEvent().getEventErrors().getErrorList().stream()
                            .map(this::populateErrorCodeAndTitle)
                            .collect(Collectors.joining(", "));
            loadROHierarchyDataV1.setErrorListString(errorListString);
        }else{
            throw new IllegalStateException();
        }
        return loadROHierarchyDataV1;
    }

    public String populateErrorCodeAndTitle(final ErrorDescription errorDescription) {
        return errorDescription.getErrorCode() + "-" + errorDescription.getMessage();
    }
}
