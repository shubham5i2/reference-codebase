package com.ielts.cmds.organisation.domain.commands;

import com.ielts.cmds.application.command.BaseCommand;
import com.ielts.cmds.infrastructure.event.BaseAudit;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.domain.model.OrganisationPrimmingModel;
import lombok.Builder;
import lombok.NoArgsConstructor;

@NoArgsConstructor
public class OrganisationPrimmingCommand
        extends BaseCommand<BaseHeader, OrganisationPrimmingModel> {

    @Builder
    public OrganisationPrimmingCommand(
            final BaseHeader eventHeaders,
            final OrganisationPrimmingModel eventBody,
            final BaseEventErrors eventErrors,
            final BaseAudit audit) {
        super(eventHeaders, eventBody, eventErrors, null);
    }
}
