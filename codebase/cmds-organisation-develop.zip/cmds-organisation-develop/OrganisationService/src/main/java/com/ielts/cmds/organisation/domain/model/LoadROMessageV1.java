package com.ielts.cmds.organisation.domain.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/** MessageV1 */
@Data
@NoArgsConstructor
@EqualsAndHashCode
public class LoadROMessageV1 {

    private LoadROMapV1 msg;
}
