package com.ielts.cmds.organisation.application;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.config.IApplicationService;
import com.ielts.cmds.common.config.IBaseAuditService;
import com.ielts.cmds.common.exception.ProcessingException;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.organisation.domain.commands.OrganisationHierarchyUpdate;
import com.ielts.cmds.organisation.domain.model.HierarchyUpdateV1;
import com.ielts.cmds.organisation.domain.services.OrganisationHierarchyUpdateDomainService;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class OrganisationHierarchyUpdateService implements IApplicationService, IBaseAuditService {

    @Autowired private ObjectMapper objectMapper;
    @Autowired OrganisationHierarchyUpdateDomainService updateHierarchyDomainService;

    private static final String EVENTNAME =
            OrganisationConstants.EventType.RO_HIERARCHY_UPDATE_EVENT;

    @Override
    public void process(BaseEvent<? extends BaseHeader> baseEvent) throws ProcessingException {
        try {
            HierarchyUpdateV1 hierarchyUpdateV1 =
                    objectMapper.readValue(baseEvent.getEventBody(), HierarchyUpdateV1.class);
            if (Objects.isNull(hierarchyUpdateV1)) {
                throw new IllegalArgumentException(
                        OrganisationConstants.ErrorResponse.EMPTY_PAYLOAD);
            }
            log.debug(
                    "Request with transactionId: {}, eventname: {}",
                    baseEvent.getEventHeader().getTransactionId(),
                    baseEvent.getEventHeader().getEventName());
            populateAuditFields(baseEvent.getAudit());
            OrganisationHierarchyUpdate organisationHierarchyUpdateCommand =
                    OrganisationHierarchyUpdate.builder()
                            .eventHeaders(baseEvent.getEventHeader())
                            .eventBody(hierarchyUpdateV1)
                            .eventErrors(baseEvent.getEventErrors())
                            .audit(baseEvent.getAudit())
                            .build();
            updateHierarchyDomainService.onCommand(organisationHierarchyUpdateCommand);

        } catch (Exception e) {
            log.error("Exception while processing Request: ", e);
            throw new ProcessingException(e.getMessage(), e);
        }
    }

    @Override
    public String getAction() {
        return OrganisationHierarchyUpdate.class.getSimpleName();
    }

    @Override
    public String getPermission() {
        return OrganisationConstants.Permissions.ORG_UPDATE;
    }

    @Override
    public String getScreen() {
        return OrganisationConstants.Screen.UPDATE_ORGANISATION;
    }

    @Override
    public String getServiceIdentifier() {
        return EVENTNAME;
    }
}
