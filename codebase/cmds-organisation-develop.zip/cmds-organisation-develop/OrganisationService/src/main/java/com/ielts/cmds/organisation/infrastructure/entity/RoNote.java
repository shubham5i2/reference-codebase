package com.ielts.cmds.organisation.infrastructure.entity;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.Type;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@Entity(name = "ro_note")
@EqualsAndHashCode(callSuper = true, exclude = { "recognisingOrganisation" })
@ToString(exclude = { "recognisingOrganisation" })
public class RoNote extends CommonModel implements Serializable {

	/**
	 * Generated SerialVersionID
	 */
	private static final long serialVersionUID = 6121139434218774777L;

	@Id
	@GeneratedValue
	@Type(type="uuid-char")
	@Column(name = "note_uuid", nullable = false)
	private UUID noteUuid;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "recognising_organisation_uuid", nullable = false)
	private RecognisingOrganisation recognisingOrganisation;

	@Column(name = "note_type_uuid", nullable = false)
	@Type(type="uuid-char")
	private UUID noteTypeUuid;

	@Column(name = "note_content", length = 2000)
	private String noteContent;
}
