package com.ielts.cmds.organisation.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import com.ielts.cmds.api.roui005rosearchrequested.RoSearchObject;
import com.ielts.cmds.api.roui005rosearchrequested.SearchPagination;
import com.ielts.cmds.api.roui007rocreaterequested.OrganisationStatusEnum;
import com.ielts.cmds.api.roui007rocreaterequested.VerificationStatusEnum;
import com.ielts.cmds.organisation.infrastructure.entity.AddressType;
import com.ielts.cmds.organisation.infrastructure.entity.OrganisationType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.support.PagedListHolder;
import org.springframework.stereotype.Component;

import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1Address;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1Addresses;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1ROList;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1Result;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1RoBasic;
import com.ielts.cmds.organisation.infrastructure.entity.Country;
import com.ielts.cmds.organisation.infrastructure.entity.RODuplicateExactSearchResult;
import com.ielts.cmds.organisation.infrastructure.entity.RODuplicateFuzzySearchResult;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.entity.Territory;
import com.ielts.cmds.organisation.infrastructure.repository.AddressTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.CountryRepository;
import com.ielts.cmds.organisation.infrastructure.repository.OrganisationTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.RecognisingOrganisationRepository;
import com.ielts.cmds.organisation.infrastructure.repository.TerritoryRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class DuplicateSearchRoEntityToEventMapper {

	@Autowired
	private CountryRepository countryRepository;

	@Autowired
	private TerritoryRepository territoryRepository;

	@Autowired
	private AddressTypeRepository addressTypeRepository;

	@Autowired
	private OrganisationTypeRepository organisationTypeRepository;

	@Autowired
	private RecognisingOrganisationRepository recognisingOrganisationRepository;

	@Autowired
	private OrganisationCommonUtils orgCommonUtils;

	public RosSearchResultsGeneratedEventV1 mapEntityToEventForFullTextSearch(final RoSearchObject roSearchObject,
			final List<RODuplicateExactSearchResult> recognisingOrganisations) {
		RosSearchResultsGeneratedEventV1 rosFullTextSearchResultsGeneratedEventV1 = new RosSearchResultsGeneratedEventV1();
		rosFullTextSearchResultsGeneratedEventV1.setSearch(SearchRoEntityToEventMapper.getSearch(roSearchObject));
		rosFullTextSearchResultsGeneratedEventV1.setResult(
				getResultForFullTextSearch(recognisingOrganisations, roSearchObject.getPagination()));
		return rosFullTextSearchResultsGeneratedEventV1;
	}

	public RosSearchResultsGeneratedEventV1 mapEntityToEventForFuzzySearch(final RoSearchObject roSearchObject,
			final List<RODuplicateFuzzySearchResult> recognisingOrganisations) {
		RosSearchResultsGeneratedEventV1 rosFuzzySearchResultsGeneratedEventV1 = new RosSearchResultsGeneratedEventV1();
		rosFuzzySearchResultsGeneratedEventV1.setSearch(SearchRoEntityToEventMapper.getSearch(roSearchObject));
		rosFuzzySearchResultsGeneratedEventV1.setResult(
				getResultForFuzzySearch(recognisingOrganisations, roSearchObject.getPagination()));
		return rosFuzzySearchResultsGeneratedEventV1;
	}

	private RosSearchResultsGeneratedEventV1Result getResultForFullTextSearch(
			final List<RODuplicateExactSearchResult> duplicateSearchOrganisationList,
			final SearchPagination searchPagination) {
		RosSearchResultsGeneratedEventV1Result roFullTextSearchResult = new RosSearchResultsGeneratedEventV1Result();
		List<RosSearchResultsGeneratedEventV1RoBasic> distinctEntries = getEntriesForFullTextSearch(
				duplicateSearchOrganisationList).stream()
						.filter(distinctByKey(RosSearchResultsGeneratedEventV1RoBasic::getRecognisingOrganisationUuid))
						.collect(Collectors.toList());
		roFullTextSearchResult.setTotalCount(distinctEntries.size());
		roFullTextSearchResult.setEntries(
				getPagedEntries(distinctEntries, searchPagination.getPageNumber().intValue(), searchPagination.getPageSize().intValue()));
		return roFullTextSearchResult;
	}

	private RosSearchResultsGeneratedEventV1Result getResultForFuzzySearch(
			final List<RODuplicateFuzzySearchResult> duplicateSearchOrganisationList,
			final SearchPagination searchPagination) {
		RosSearchResultsGeneratedEventV1Result roFuzzySearchResult = new RosSearchResultsGeneratedEventV1Result();
		List<RosSearchResultsGeneratedEventV1RoBasic> distinctEntries = getEntriesForFuzzySearch(
				duplicateSearchOrganisationList).stream()
						.filter(distinctByKey(RosSearchResultsGeneratedEventV1RoBasic::getRecognisingOrganisationUuid))
						.collect(Collectors.toList());
		roFuzzySearchResult.setTotalCount(distinctEntries.size());
		roFuzzySearchResult.setEntries(
				getPagedEntries(distinctEntries, searchPagination.getPageNumber().intValue(), searchPagination.getPageSize().intValue()));
		return roFuzzySearchResult;
	}

	private RosSearchResultsGeneratedEventV1ROList getPagedEntries(
			List<RosSearchResultsGeneratedEventV1RoBasic> distinctEntries, Integer pageNumber, Integer pageSize) {
		PagedListHolder<RosSearchResultsGeneratedEventV1RoBasic> roBasicListPage = new PagedListHolder<>(
				distinctEntries);
		roBasicListPage.setPage(pageNumber);
		roBasicListPage.setPageSize(pageSize);
		RosSearchResultsGeneratedEventV1ROList rosSearchResultsGeneratedEventV1ROList = new RosSearchResultsGeneratedEventV1ROList();
		rosSearchResultsGeneratedEventV1ROList.addAll(roBasicListPage.getPageList());
		return rosSearchResultsGeneratedEventV1ROList;
	}

	public static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
		Set<Object> seen = ConcurrentHashMap.newKeySet();
		return t -> seen.add(keyExtractor.apply(t));
	}

	private RosSearchResultsGeneratedEventV1ROList getEntriesForFullTextSearch(
			final List<RODuplicateExactSearchResult> duplicateSearchOrganisationList) {
		RosSearchResultsGeneratedEventV1ROList rosFullTextSearchResultsGeneratedEventV1ROList = new RosSearchResultsGeneratedEventV1ROList();
		Map<UUID, UUID> parentMap = new HashMap<>();
		List<OrganisationType> organisationTypes = organisationTypeRepository.findAll();

		duplicateSearchOrganisationList.forEach(duplicateSearchOrganisation -> {
			RosSearchResultsGeneratedEventV1RoBasic roFullTextSearchResultBasic = new RosSearchResultsGeneratedEventV1RoBasic();
			if (duplicateSearchOrganisation.getTargetRecognisingOrganisationUuid() != null) {
				parentMap.put(duplicateSearchOrganisation.getRecognisingOrganisationUuid(),
						duplicateSearchOrganisation.getTargetRecognisingOrganisationUuid());
			}
			roFullTextSearchResultBasic.setOrganisationCode(duplicateSearchOrganisation.getOrganisationCode());
			roFullTextSearchResultBasic.setOrganisationId(duplicateSearchOrganisation.getOrganisationId());
			roFullTextSearchResultBasic.setOrganisationName(duplicateSearchOrganisation.getName());
			roFullTextSearchResultBasic.setOrganisationStatus(OrganisationStatusEnum.valueOf(duplicateSearchOrganisation.getOrgStatus().getValue()));
			roFullTextSearchResultBasic.setOrganisationTypeUuid(duplicateSearchOrganisation.getOrganisationTypeUuid());
			roFullTextSearchResultBasic.setOrganisationType(SearchRoEntityToEventMapper.getOrganisationTypeFromUuid(
					organisationTypes, roFullTextSearchResultBasic.getOrganisationTypeUuid()));
			roFullTextSearchResultBasic.setPartnerCode(duplicateSearchOrganisation.getPartnerCode());
			roFullTextSearchResultBasic
					.setRecognisingOrganisationUuid(duplicateSearchOrganisation.getRecognisingOrganisationUuid());
			roFullTextSearchResultBasic.setSoftDeleted(duplicateSearchOrganisation.getSoftDeleted());
			roFullTextSearchResultBasic.setVerificationStatus(VerificationStatusEnum.valueOf(duplicateSearchOrganisation.getVerificationStatus().getValue()));
			roFullTextSearchResultBasic.setPartnerContact(duplicateSearchOrganisation.getPartnerContact());
			roFullTextSearchResultBasic.setAddresses(getAddressesForFullTextSearch(duplicateSearchOrganisationList.stream()
					.filter(organisation -> organisation.getRecognisingOrganisationUuid()
							.equals(roFullTextSearchResultBasic.getRecognisingOrganisationUuid())
							&& Objects.isNull(organisation.getContactUuid()))
					.collect(Collectors.toList())));
			rosFullTextSearchResultsGeneratedEventV1ROList.add(roFullTextSearchResultBasic);
		});
		Map<UUID, String> parentDetailsMap = getParentDetails(parentMap);
		rosFullTextSearchResultsGeneratedEventV1ROList.forEach(rosFullTextSearchResultsGeneratedEventV1RoBasic -> {
			String parentDetails = parentDetailsMap
					.get(rosFullTextSearchResultsGeneratedEventV1RoBasic.getRecognisingOrganisationUuid());
			if (parentDetails != null) {
				String[] parentDetailsString = parentDetails.split(Pattern.quote("|"));
				rosFullTextSearchResultsGeneratedEventV1RoBasic.setParentRecognisingOrganisationName(parentDetailsString[0]);
				rosFullTextSearchResultsGeneratedEventV1RoBasic
						.setParentRecognisingOrganisationUuid(UUID.fromString(parentDetailsString[1]));
				rosFullTextSearchResultsGeneratedEventV1RoBasic.setParentOrgId(Integer.valueOf(parentDetailsString[2]));
			}
		});
		return rosFullTextSearchResultsGeneratedEventV1ROList;
	}

	private RosSearchResultsGeneratedEventV1ROList getEntriesForFuzzySearch(
			final List<RODuplicateFuzzySearchResult> duplicateSearchOrganisationList) {
		RosSearchResultsGeneratedEventV1ROList rosFuzzySearchResultsGeneratedEventV1ROList = new RosSearchResultsGeneratedEventV1ROList();
		Map<UUID, UUID> parentMap = new HashMap<>();
		List<OrganisationType> organisationTypes = organisationTypeRepository.findAll();

		duplicateSearchOrganisationList.forEach(duplicateSearchOrganisation -> {
			RosSearchResultsGeneratedEventV1RoBasic roFuzzySearchResultBasic = new RosSearchResultsGeneratedEventV1RoBasic();
			if (duplicateSearchOrganisation.getTargetRecognisingOrganisationUuid() != null) {
				parentMap.put(duplicateSearchOrganisation.getRecognisingOrganisationUuid(),
						duplicateSearchOrganisation.getTargetRecognisingOrganisationUuid());
			}
			roFuzzySearchResultBasic.setOrganisationCode(duplicateSearchOrganisation.getOrganisationCode());
			roFuzzySearchResultBasic.setOrganisationId(duplicateSearchOrganisation.getOrganisationId());
			roFuzzySearchResultBasic.setOrganisationName(duplicateSearchOrganisation.getName());
			roFuzzySearchResultBasic.setOrganisationStatus(OrganisationStatusEnum.valueOf(duplicateSearchOrganisation.getOrgStatus().getValue()));
			roFuzzySearchResultBasic.setOrganisationTypeUuid(duplicateSearchOrganisation.getOrganisationTypeUuid());
			roFuzzySearchResultBasic.setOrganisationType(SearchRoEntityToEventMapper.getOrganisationTypeFromUuid(
					organisationTypes, roFuzzySearchResultBasic.getOrganisationTypeUuid()));
			roFuzzySearchResultBasic.setPartnerCode(duplicateSearchOrganisation.getPartnerCode());
			roFuzzySearchResultBasic
					.setRecognisingOrganisationUuid(duplicateSearchOrganisation.getRecognisingOrganisationUuid());
			roFuzzySearchResultBasic.setSoftDeleted(duplicateSearchOrganisation.getSoftDeleted());
			roFuzzySearchResultBasic.setVerificationStatus(VerificationStatusEnum.valueOf(duplicateSearchOrganisation.getVerificationStatus().getValue()));
			roFuzzySearchResultBasic.setPartnerContact(duplicateSearchOrganisation.getPartnerContact());
			roFuzzySearchResultBasic.setAddresses(getAddressesForFuzzySearch(duplicateSearchOrganisationList.stream()
					.filter(organisation -> organisation.getRecognisingOrganisationUuid()
							.equals(roFuzzySearchResultBasic.getRecognisingOrganisationUuid())
							&& Objects.isNull(organisation.getContactUuid()))
					.collect(Collectors.toList())));
			rosFuzzySearchResultsGeneratedEventV1ROList.add(roFuzzySearchResultBasic);
		});
		Map<UUID, String> parentDetailsMap = getParentDetails(parentMap);
		rosFuzzySearchResultsGeneratedEventV1ROList.forEach(rosFuzzySearchResultsGeneratedEventV1RoBasic -> {
			String parentDetails = parentDetailsMap
					.get(rosFuzzySearchResultsGeneratedEventV1RoBasic.getRecognisingOrganisationUuid());
			if (parentDetails != null) {
				String[] parentFuzzyDetailsString = parentDetails.split(Pattern.quote("|"));
				rosFuzzySearchResultsGeneratedEventV1RoBasic.setParentRecognisingOrganisationName(parentFuzzyDetailsString[0]);
				rosFuzzySearchResultsGeneratedEventV1RoBasic
						.setParentRecognisingOrganisationUuid(UUID.fromString(parentFuzzyDetailsString[1]));
				rosFuzzySearchResultsGeneratedEventV1RoBasic.setParentOrgId(Integer.valueOf(parentFuzzyDetailsString[2]));
			}
		});
		return rosFuzzySearchResultsGeneratedEventV1ROList;
	}

	public Map<UUID, String> getParentDetails(Map<UUID, UUID> parentDetailsMap) {
		List<UUID> parentUuidList = new ArrayList<>(parentDetailsMap.values());
		HashMap<UUID, String> finalMap = new HashMap<>();
		String mapValue;
		UUID childUuid;
		List<RecognisingOrganisation> recognisingOrganisationList = recognisingOrganisationRepository
				.findByRecognisingOrganisationUuidIn(parentUuidList);
		if (!recognisingOrganisationList.isEmpty()) {
			for (Map.Entry<UUID, UUID> entry : parentDetailsMap.entrySet()) {
				childUuid = entry.getKey();
				for (RecognisingOrganisation recognisingOrganisation : recognisingOrganisationList) {
					if (entry.getValue().equals(recognisingOrganisation.getRecognisingOrganisationUuid())) {
						mapValue = recognisingOrganisation.getName() + "|"
								+ recognisingOrganisation.getRecognisingOrganisationUuid().toString() + "|"
								+ recognisingOrganisation.getOrganisationId().toString();
						finalMap.put(childUuid, mapValue);
					}
				}
			}
		}
		return finalMap;
	}

	private RosSearchResultsGeneratedEventV1Addresses getAddressesForFullTextSearch(
			final List<RODuplicateExactSearchResult> duplicateSearchOrganisationList) {
		final List<Country> countries = countryRepository.findAll();
		final List<Territory> territories = territoryRepository.findAll();
		final List<AddressType> addressTypes = addressTypeRepository.findAll();

		RosSearchResultsGeneratedEventV1Addresses fullTextaAdressList = new RosSearchResultsGeneratedEventV1Addresses();
		duplicateSearchOrganisationList.forEach(duplicateSearchOrganisation -> {
			if (fullTextaAdressList.stream().noneMatch(address -> Objects.nonNull(address.getAddressUuid())
					&& address.getAddressUuid().equals(duplicateSearchOrganisation.getAddressUuid()))) {
				RosSearchResultsGeneratedEventV1Address roFullTextSearchResultAddress = new RosSearchResultsGeneratedEventV1Address();
				roFullTextSearchResultAddress.setAddressLine1(duplicateSearchOrganisation.getAddressline1());
				roFullTextSearchResultAddress.setAddressLine2(duplicateSearchOrganisation.getAddressline2());
				roFullTextSearchResultAddress.setAddressLine3(duplicateSearchOrganisation.getAddressline3());
				roFullTextSearchResultAddress.setAddressLine4(duplicateSearchOrganisation.getAddressline4());
				roFullTextSearchResultAddress.setAddressTypeUuid(duplicateSearchOrganisation.getAddressTypeUuid());
				roFullTextSearchResultAddress.setAddressType(SearchRoEntityToEventMapper.getAddressTypeFromUuid(
						addressTypes, roFullTextSearchResultAddress.getAddressTypeUuid()));
				roFullTextSearchResultAddress.setAddressUuid(duplicateSearchOrganisation.getAddressUuid());
				roFullTextSearchResultAddress.setCity(duplicateSearchOrganisation.getCity());
				roFullTextSearchResultAddress.setCountryUuid(duplicateSearchOrganisation.getCountryUuid());
				Country country = SearchRoEntityToEventMapper.getCountryFromCountryUuid(countries,
						roFullTextSearchResultAddress.getCountryUuid());
				roFullTextSearchResultAddress.setCountry(country.getCountryName());
				roFullTextSearchResultAddress.setCountryIso3Code(country.getCountryIso3Code());
				roFullTextSearchResultAddress.setEmail(duplicateSearchOrganisation.getEmail());
				roFullTextSearchResultAddress.setPhone(duplicateSearchOrganisation.getPhone());
				roFullTextSearchResultAddress.setPostalCode(duplicateSearchOrganisation.getPostalCode());
				roFullTextSearchResultAddress.setTerritoryUuid(duplicateSearchOrganisation.getTerritoryUuid());
				Territory territory = SearchRoEntityToEventMapper.getTerritoryFromTerritoryryUuid(territories,
						roFullTextSearchResultAddress.getTerritoryUuid());
				roFullTextSearchResultAddress.setTerritory(territory.getTerritoryName());
				roFullTextSearchResultAddress.setTerritoryIsoCode(territory.getTerritoryIsoCode());
				fullTextaAdressList.add(roFullTextSearchResultAddress);
			}
		});
		return fullTextaAdressList;
	}

	private RosSearchResultsGeneratedEventV1Addresses getAddressesForFuzzySearch(
			final List<RODuplicateFuzzySearchResult> duplicateSearchOrganisationList) {
		final List<Country> countries = countryRepository.findAll();
		final List<Territory> territories = territoryRepository.findAll();
		final List<AddressType> addressTypes = addressTypeRepository.findAll();

		RosSearchResultsGeneratedEventV1Addresses fuzzyAddressList = new RosSearchResultsGeneratedEventV1Addresses();
		duplicateSearchOrganisationList.forEach(duplicateSearchOrganisation -> {
			if (fuzzyAddressList.stream().noneMatch(address -> Objects.nonNull(address.getAddressUuid())
					&& address.getAddressUuid().equals(duplicateSearchOrganisation.getAddressUuid()))) {
				RosSearchResultsGeneratedEventV1Address roFuzzySearchResultAddress = new RosSearchResultsGeneratedEventV1Address();
				roFuzzySearchResultAddress.setAddressLine1(duplicateSearchOrganisation.getAddressline1());
				roFuzzySearchResultAddress.setAddressLine2(duplicateSearchOrganisation.getAddressline2());
				roFuzzySearchResultAddress.setAddressLine3(duplicateSearchOrganisation.getAddressline3());
				roFuzzySearchResultAddress.setAddressLine4(duplicateSearchOrganisation.getAddressline4());
				roFuzzySearchResultAddress.setAddressTypeUuid(duplicateSearchOrganisation.getAddressTypeUuid());
				roFuzzySearchResultAddress.setAddressType(SearchRoEntityToEventMapper.getAddressTypeFromUuid(
						addressTypes, roFuzzySearchResultAddress.getAddressTypeUuid()));
				roFuzzySearchResultAddress.setAddressUuid(duplicateSearchOrganisation.getAddressUuid());
				roFuzzySearchResultAddress.setCity(duplicateSearchOrganisation.getCity());
				roFuzzySearchResultAddress.setCountryUuid(duplicateSearchOrganisation.getCountryUuid());
				Country country = SearchRoEntityToEventMapper.getCountryFromCountryUuid(countries,
						roFuzzySearchResultAddress.getCountryUuid());
				roFuzzySearchResultAddress.setCountry(country.getCountryName());
				roFuzzySearchResultAddress.setCountryIso3Code(country.getCountryIso3Code());
				roFuzzySearchResultAddress.setEmail(duplicateSearchOrganisation.getEmail());
				roFuzzySearchResultAddress.setPhone(duplicateSearchOrganisation.getPhone());
				roFuzzySearchResultAddress.setPostalCode(duplicateSearchOrganisation.getPostalCode());
				roFuzzySearchResultAddress.setTerritoryUuid(duplicateSearchOrganisation.getTerritoryUuid());
				Territory territory = SearchRoEntityToEventMapper.getTerritoryFromTerritoryryUuid(territories,
						roFuzzySearchResultAddress.getTerritoryUuid());
				roFuzzySearchResultAddress.setTerritory(territory.getTerritoryName());
				roFuzzySearchResultAddress.setTerritoryIsoCode(territory.getTerritoryIsoCode());
				fuzzyAddressList.add(roFuzzySearchResultAddress);
			}
		});
		return fuzzyAddressList;
	}
}
