package com.ielts.cmds.organisation.domain.services;

import com.ielts.cmds.organisation.domain.commands.LoadROData;
import com.ielts.cmds.organisation.utils.OrganisationConstants;
import java.io.IOException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class LoadROUpdateDomainService {

    @Autowired private LoadROHierarchyHelper loadROHierarchyHelper;

    @Autowired private BulkRORecognisedProductsUpdateHelper updateROProductsHelper;

    public void onCommand(final LoadROData loadROData) throws IOException {
        String mode = loadROHierarchyHelper.getOperationMode(loadROData.getEventHeaders());
        if (OrganisationConstants.GenericConstants.UPDATE_MODE.equalsIgnoreCase(mode)) {
            loadROHierarchyHelper.onHierarchyUpdateCommand(loadROData);
        } else {
            updateROProductsHelper.onRecognisedProductsUpdate(loadROData);
        }
    }
}
