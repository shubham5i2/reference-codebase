package com.ielts.cmds.organisation.utils;

import com.ielts.cmds.api.roui007rocreaterequested.MethodOfDeliveryEnum;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import java.util.stream.Stream;

@Converter(autoApply = true)
public class MethodOfDeliveryEnumConverter implements AttributeConverter<MethodOfDeliveryEnum, String> {


    @Override
    public String convertToDatabaseColumn(MethodOfDeliveryEnum methodOfDeliveryEnum) {
        if(methodOfDeliveryEnum == null){
            return null;
        }
        return methodOfDeliveryEnum.getValue();
    }

    @Override
    public MethodOfDeliveryEnum convertToEntityAttribute(String s) {
        if( s == null){
            return null;
        }
        return Stream.of(MethodOfDeliveryEnum.values())
                .filter(c -> c.getValue().equals(s))
                .findFirst()
                .orElseThrow(IllegalArgumentException::new);
    }
}
