package com.ielts.cmds.organisation.utils;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ielts.cmds.api.roui007rocreaterequested.ComponentEnum;
import com.ielts.cmds.api.roui007rocreaterequested.MethodOfDeliveryEnum;
import com.ielts.cmds.api.roui007rocreaterequested.OrganisationStatusEnum;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreate;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreateAddress;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreateAlternateName;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreateContact;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreateMinimumScore;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreateNote;
import com.ielts.cmds.api.roui007rocreaterequested.VerificationStatusEnum;
import com.ielts.cmds.organisation.domain.model.LoadRODataV1;
import com.ielts.cmds.organisation.domain.model.RoDataCreateV1Valid;
import com.ielts.cmds.organisation.infrastructure.entity.AddressType;
import com.ielts.cmds.organisation.infrastructure.entity.Country;
import com.ielts.cmds.organisation.infrastructure.entity.SectorType;
import com.ielts.cmds.organisation.infrastructure.entity.Territory;
import com.ielts.cmds.organisation.infrastructure.repository.AddressTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.ContactTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.CountryRepository;
import com.ielts.cmds.organisation.infrastructure.repository.ModuleTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.OrganisationTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.SectorTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.TerritoryRepository;

import lombok.extern.slf4j.Slf4j;


@Component
@Slf4j
public class LoadRODataUtils {

    @Autowired private CountryRepository countryRepository;

    @Autowired private TerritoryRepository territoryRepository;

    @Autowired private OrganisationTypeRepository organisationTypeRepository;

    @Autowired private SectorTypeRepository sectorTypeRepository;

    @Autowired private ModuleTypeRepository moduleTypeRepository;

    @Autowired private ContactTypeRepository contactTypeRepository;

    @Autowired private AddressTypeRepository addressTypeRepository;

    public RoDataCreateV1Valid loadData(final LoadRODataV1 loadRORecord, String organisationType) {
        RoDataCreateV1Valid roDataCreateV1Valid = new RoDataCreateV1Valid();
        roDataCreateV1Valid.setOrganisationName(loadRORecord.getName());
        roDataCreateV1Valid.setOrganisationStatus(OrganisationStatusEnum.valueOf(OrganisationStatusEnum.ACTIVE.getValue()));
        setOrganisationTypeUuidBasedOnOrganisationType(
                loadRORecord, organisationType, roDataCreateV1Valid);

        roDataCreateV1Valid.setVerificationStatus(
                VerificationStatusEnum.fromValue(
                        loadRORecord.getVerificationStatus().toUpperCase()));
        roDataCreateV1Valid.setSectorTypeUuid(
                getSectorTypeUuidFromSectorType(loadRORecord.getSectorType().trim()));
        roDataCreateV1Valid.setPartnerCode(loadRORecord.getPartnerCode());
        roDataCreateV1Valid.setMethodOfDelivery(
                MethodOfDeliveryEnum.fromValue(loadRORecord.getMethodOfDelivery().toUpperCase()));
        if (StringUtils.isNotBlank(loadRORecord.getWebsiteUrl())) {
            roDataCreateV1Valid.setWebsiteUrl(loadRORecord.getWebsiteUrl().trim());
        }
        if (StringUtils.isNotBlank(loadRORecord.getVisibleOnIelts())
                && loadRORecord.getVisibleOnIelts().trim().equalsIgnoreCase("TRUE")) {
            roDataCreateV1Valid.setIeltsDisplayFlag(Boolean.TRUE);
        } else {
            roDataCreateV1Valid.setIeltsDisplayFlag(Boolean.FALSE);
        }
        if (StringUtils.isNotBlank(loadRORecord.getSelectableOnOrs())
                && loadRORecord.getSelectableOnOrs().trim().equalsIgnoreCase("TRUE")) {
            roDataCreateV1Valid.setOrsDisplayFlag(Boolean.TRUE);
        } else {
            roDataCreateV1Valid.setOrsDisplayFlag(Boolean.FALSE);
        }
        roDataCreateV1Valid.setAddresses(loadAddressData(loadRORecord));
        roDataCreateV1Valid.setNotes(loadNotesData(loadRORecord));
        if (StringUtils.isNotBlank(loadRORecord.getRecognisedProduct())) {
            List<String> recognisedProducts =
                    getRecognisedProductsList(loadRORecord.getRecognisedProduct());
            for (String recognisedProduct : recognisedProducts) {
                setRecognisedProductCharacteristics(roDataCreateV1Valid, recognisedProduct);
                /*acceptsSSR is set to FALSE because it will be opted from UI*/
                roDataCreateV1Valid.setAcceptsSSR(Boolean.FALSE);
            }
        } else {
            roDataCreateV1Valid.setAcceptsIOL(Boolean.FALSE);
            roDataCreateV1Valid.setAcceptsSSR(Boolean.FALSE);
        }
        roDataCreateV1Valid.setMinimumScores(loadMinimumScoresData(loadRORecord));
        roDataCreateV1Valid.setAlternateNames(loadAlternateNames(loadRORecord));
        return roDataCreateV1Valid;
    }

    private void setRecognisedProductCharacteristics(RoDataCreateV1Valid roDataCreateV1Valid, String recognisedProduct) {
        if (recognisedProduct.trim().equalsIgnoreCase(OrganisationConstants.GenericConstants.IOL)) {
            roDataCreateV1Valid.setAcceptsIOL(Boolean.TRUE);
        }else if(recognisedProduct.trim().equalsIgnoreCase(OrganisationConstants.GenericConstants.AC)){
            roDataCreateV1Valid.setAcceptsAC(Boolean.TRUE);
        }else if(recognisedProduct.trim().equalsIgnoreCase(OrganisationConstants.GenericConstants.GT)){
            roDataCreateV1Valid.setAcceptsGT(Boolean.TRUE);
        } else{
            roDataCreateV1Valid.setAcceptsIOL(Boolean.FALSE);
        }
    }

    private List<String> getRecognisedProductsList(String recognisedProducts) {
        List<String> recognisedProductsList = new ArrayList<>();
        if (StringUtils.isNotBlank(recognisedProducts)) {
            if (recognisedProducts.contains("|")) {
                String[] recognisedProductsSplit = recognisedProducts.split("\\|");
                recognisedProductsList = Arrays.asList(recognisedProductsSplit);
            } else {
                recognisedProductsList.add(recognisedProducts);
            }
        }
        return recognisedProductsList;
    }

    private void setOrganisationTypeUuidBasedOnOrganisationType(
            final LoadRODataV1 loadRORecord,
            String organisationType,
            RoDataCreateV1Valid roDataCreateV1Valid) {
        if (OrganisationConstants.GenericConstants.RECOGNISING_ORGANISATION.equalsIgnoreCase(
                organisationType)) {
            roDataCreateV1Valid.setOrganisationTypeUuid(
                    organisationTypeRepository
                            .findByOrganisationsType(
                                    OrganisationConstants.GenericConstants.RECOGNISING_ORGANISATION)
                            .getOrganisationTypeUuid());
            roDataCreateV1Valid.setContacts(loadContactsData(loadRORecord));
        } else {
            roDataCreateV1Valid.setOrganisationTypeUuid(
                    organisationTypeRepository
                            .findByOrganisationsType(
                                    OrganisationConstants.GenericConstants.VERIFIED_ORGANISATION)
                            .getOrganisationTypeUuid());
            if (StringUtils.isNotBlank(loadRORecord.getFirstName())
                    || StringUtils.isNotBlank(loadRORecord.getLastName())) {
                roDataCreateV1Valid.setContacts(loadContactsData(loadRORecord));
            }
        }
    }

    private List<RoDataCreateAlternateName> loadAlternateNames(LoadRODataV1 loadRORecord) {
        List<RoDataCreateAlternateName> roDataCreateV1AlternateNames =
                new ArrayList<>();
        if (StringUtils.isNotBlank(loadRORecord.getAlternateName1())
                && !loadRORecord.getAlternateName1().trim().equalsIgnoreCase("NULL")) {
            roDataCreateV1AlternateNames.add(
                    populateAlternateName(loadRORecord.getAlternateName1()));
        }
        if (StringUtils.isNotBlank(loadRORecord.getAlternateName2())
                && !loadRORecord.getAlternateName2().trim().equalsIgnoreCase("NULL")) {
            roDataCreateV1AlternateNames.add(
                    populateAlternateName(loadRORecord.getAlternateName2()));
        }
        if (StringUtils.isNotBlank(loadRORecord.getAlternateName3())
                && !loadRORecord.getAlternateName3().trim().equalsIgnoreCase("NULL")) {
            roDataCreateV1AlternateNames.add(
                    populateAlternateName(loadRORecord.getAlternateName3()));
        }
        return roDataCreateV1AlternateNames;
    }

    private RoDataCreateAlternateName populateAlternateName(String alternateName) {
        RoDataCreateAlternateName roDataCreateV1AlternateName = new RoDataCreateAlternateName();
        roDataCreateV1AlternateName.setName(alternateName);
        return roDataCreateV1AlternateName;
    }

    private List<RoDataCreateMinimumScore> loadMinimumScoresData(LoadRODataV1 loadRORecord) {
        List<RoDataCreateMinimumScore> roDataCreateV1MinimumScores = new ArrayList<>();
        roDataCreateV1MinimumScores.addAll(populateAcMiniumumScoreValues(loadRORecord));
        roDataCreateV1MinimumScores.addAll(populateGtMiniumumScoreValues(loadRORecord));
        return roDataCreateV1MinimumScores;
    }

    private List<RoDataCreateMinimumScore> populateAcMiniumumScoreValues(LoadRODataV1 loadRORecord) {
        List<RoDataCreateMinimumScore> roDataAcCreateV1MinimumScores =
                new ArrayList<>();

        if (!StringUtils.isEmpty(loadRORecord.getAcMinimumScoreValue())
                && !loadRORecord.getAcMinimumScoreValue().trim().equalsIgnoreCase("NULL")) {
                        log.debug("MinScoreValue:{}", loadRORecord.getAcMinimumScoreValue());
            roDataAcCreateV1MinimumScores.add(
                    populateMinimumScore(
                            ComponentEnum.ALL,
                            moduleTypeRepository.findByModulesType("AC").getModuleTypeUuid(),
                            loadRORecord.getAcMinimumScoreValue()));
        }
        if (!StringUtils.isEmpty(loadRORecord.getAcListeningMinimumScoreValue())
                && !loadRORecord
                        .getAcListeningMinimumScoreValue()
                        .trim()
                        .equalsIgnoreCase("NULL")) {
            roDataAcCreateV1MinimumScores.add(
                    populateMinimumScore(
                            ComponentEnum.L,
                            moduleTypeRepository.findByModulesType("AC").getModuleTypeUuid(),
                            loadRORecord.getAcListeningMinimumScoreValue()));
        }
        if (!StringUtils.isEmpty(loadRORecord.getAcWritingMinimumScoreValue())
                && !loadRORecord.getAcWritingMinimumScoreValue().trim().equalsIgnoreCase("NULL")) {
            roDataAcCreateV1MinimumScores.add(
                    populateMinimumScore(
                            ComponentEnum.W,
                            moduleTypeRepository.findByModulesType("AC").getModuleTypeUuid(),
                            loadRORecord.getAcWritingMinimumScoreValue()));
        }
        if (!StringUtils.isEmpty(loadRORecord.getAcReadingMinimumScoreValue())
                && !loadRORecord.getAcReadingMinimumScoreValue().trim().equalsIgnoreCase("NULL")) {
            roDataAcCreateV1MinimumScores.add(
                    populateMinimumScore(
                            ComponentEnum.R,
                            moduleTypeRepository.findByModulesType("AC").getModuleTypeUuid(),
                            loadRORecord.getAcReadingMinimumScoreValue()));
        }
        if (!StringUtils.isEmpty(loadRORecord.getAcSpeakingMinimumScoreValue())
                && !loadRORecord.getAcSpeakingMinimumScoreValue().trim().equalsIgnoreCase("NULL")) {
            roDataAcCreateV1MinimumScores.add(
                    populateMinimumScore(
                            ComponentEnum.S,
                            moduleTypeRepository.findByModulesType("AC").getModuleTypeUuid(),
                            loadRORecord.getAcSpeakingMinimumScoreValue()));
        }
        return roDataAcCreateV1MinimumScores;
    }

    private List<RoDataCreateMinimumScore> populateGtMiniumumScoreValues(LoadRODataV1 loadRORecord) {
        List<RoDataCreateMinimumScore> roDataGtCreateV1MinimumScores =
                new ArrayList<>();
        if (!StringUtils.isEmpty(loadRORecord.getGtMinimumScoreValue())
                && !loadRORecord.getGtMinimumScoreValue().trim().equalsIgnoreCase("NULL")) {
            roDataGtCreateV1MinimumScores.add(
                    populateMinimumScore(
                            ComponentEnum.ALL,
                            moduleTypeRepository.findByModulesType("GT").getModuleTypeUuid(),
                            loadRORecord.getGtMinimumScoreValue()));
        }

        if (!StringUtils.isEmpty(loadRORecord.getGtListeningMinimumScoreValue())
                && !loadRORecord
                        .getGtListeningMinimumScoreValue()
                        .trim()
                        .equalsIgnoreCase("NULL")) {
            roDataGtCreateV1MinimumScores.add(
                    populateMinimumScore(
                            ComponentEnum.L,
                            moduleTypeRepository.findByModulesType("GT").getModuleTypeUuid(),
                            loadRORecord.getGtListeningMinimumScoreValue()));
        }

        if (!StringUtils.isEmpty(loadRORecord.getGtWritingMinimumScoreValue())
                && !loadRORecord.getGtWritingMinimumScoreValue().trim().equalsIgnoreCase("NULL")) {
            roDataGtCreateV1MinimumScores.add(
                    populateMinimumScore(
                            ComponentEnum.W,
                            moduleTypeRepository.findByModulesType("GT").getModuleTypeUuid(),
                            loadRORecord.getGtWritingMinimumScoreValue()));
        }

        if (!StringUtils.isEmpty(loadRORecord.getGtReadingMinimumScoreValue())
                && !loadRORecord.getGtReadingMinimumScoreValue().trim().equalsIgnoreCase("NULL")) {
            roDataGtCreateV1MinimumScores.add(
                    populateMinimumScore(
                            ComponentEnum.R,
                            moduleTypeRepository.findByModulesType("GT").getModuleTypeUuid(),
                            loadRORecord.getGtReadingMinimumScoreValue()));
        }

        if (!StringUtils.isEmpty(loadRORecord.getGtSpeakingMinimumScoreValue())
                && !loadRORecord.getGtSpeakingMinimumScoreValue().trim().equalsIgnoreCase("NULL")) {
            roDataGtCreateV1MinimumScores.add(
                    populateMinimumScore(
                            ComponentEnum.S,
                            moduleTypeRepository.findByModulesType("GT").getModuleTypeUuid(),
                            loadRORecord.getGtSpeakingMinimumScoreValue()));
        }
        return roDataGtCreateV1MinimumScores;
    }

    private RoDataCreateMinimumScore populateMinimumScore(
            ComponentEnum componentEnum, UUID moduleTypeUuid, String minimumScore) {
        log.debug("PopulateMinScoreValue:{}", minimumScore);
        RoDataCreateMinimumScore roDataCreateV1MinimumScore = new RoDataCreateMinimumScore();
        roDataCreateV1MinimumScore.setComponent(ComponentEnum.valueOf(componentEnum.getValue()));
        roDataCreateV1MinimumScore.setMinimumScoreValue(new BigDecimal(minimumScore.trim()));
        roDataCreateV1MinimumScore.setModuleTypeUuid(moduleTypeUuid);
        return roDataCreateV1MinimumScore;
    }

    private List<RoDataCreateNote> loadNotesData(LoadRODataV1 loadRORecord) {
        List<RoDataCreateNote> roDataCreateV1Notes = new ArrayList<>();
        RoDataCreateNote note = new RoDataCreateNote();
        note.setNoteContent(loadRORecord.getNoteContent());
        roDataCreateV1Notes.add(note);
        return roDataCreateV1Notes;
    }

    private List<RoDataCreateContact> loadContactsData(LoadRODataV1 loadRORecord) {
        List<RoDataCreateContact> roDataCreateV1Contacts = new ArrayList<>();
        roDataCreateV1Contacts.add(
                populateContact(
                        loadRORecord,
                        contactTypeRepository
                                .findByContactsType(
                                        OrganisationConstants.GenericConstants.PRIMARY_CONTACT)
                                .getContactTypeUuid()));
        roDataCreateV1Contacts.add(
                populateContact(
                        loadRORecord,
                        contactTypeRepository
                                .findByContactsType(
                                        OrganisationConstants.GenericConstants.RESULT_ADMIN)
                                .getContactTypeUuid()));
        return roDataCreateV1Contacts;
    }

    private RoDataCreateContact populateContact(LoadRODataV1 loadRORecord, UUID contactTypeUuid) {
        RoDataCreateContact roDataCreateV1Contact = new RoDataCreateContact();
        roDataCreateV1Contact.setContactTypeUuid(contactTypeUuid);
        roDataCreateV1Contact.setFirstName(loadRORecord.getFirstName());
        roDataCreateV1Contact.setLastName(loadRORecord.getLastName());
        roDataCreateV1Contact.setEffectiveFromDateTime(OffsetDateTime.now(ZoneOffset.UTC));
        roDataCreateV1Contact.setEffectiveToDateTime(LocalDateTime.of(2099, 12, 31, 0, 0).atOffset(ZoneOffset.UTC));
        roDataCreateV1Contact.setAddresses(
                populateContactAddress(
                        loadRORecord,
                        getAddressTypeUuidFromAddressType(
                                OrganisationConstants.GenericConstants.MAIN_ADDRESS_TYPE)));
        return roDataCreateV1Contact;
    }

    private List<RoDataCreateAddress> populateContactAddress(
            LoadRODataV1 loadRORecord, UUID addressTypeUuid) {
        List<RoDataCreateAddress> roDataCreateV1Addresses = new ArrayList<>();
        if (StringUtils.isNotBlank(loadRORecord.getContactEmail())
                || StringUtils.isNotBlank(loadRORecord.getTelephoneNo())) {
            RoDataCreateAddress contactAddress = new RoDataCreateAddress();
            contactAddress.setEmail(loadRORecord.getContactEmail());
            contactAddress.setAddressTypeUuid(addressTypeUuid);
            contactAddress.setPhone(loadRORecord.getTelephoneNo());
            roDataCreateV1Addresses.add(contactAddress);
        }
        return roDataCreateV1Addresses;
    }

    private List<RoDataCreateAddress> loadAddressData(LoadRODataV1 loadRORecord) {
        List<RoDataCreateAddress> roDataCreateV1Addresses = new ArrayList<>();
        roDataCreateV1Addresses.add(
                populateAddress(
                        loadRORecord,
                        getAddressTypeUuidFromAddressType(
                                OrganisationConstants.GenericConstants.MAIN_ADDRESS_TYPE)));
        roDataCreateV1Addresses.add(
                populateAddress(
                        loadRORecord,
                        getAddressTypeUuidFromAddressType(
                                OrganisationConstants.GenericConstants.DELIVERY_ADDRESS_TYPE)));
        return roDataCreateV1Addresses;
    }

    private RoDataCreateAddress populateAddress(LoadRODataV1 loadRORecord, UUID addressTypeUuid) {
        RoDataCreateAddress roDataCreateV1Address = new RoDataCreateAddress();
        roDataCreateV1Address.setAddressTypeUuid(addressTypeUuid);
        roDataCreateV1Address.setAddressLine1(loadRORecord.getAddressLine1());
        roDataCreateV1Address.setAddressLine2(loadRORecord.getAddressLine2());
        roDataCreateV1Address.setAddressLine3(loadRORecord.getAddressLine3());
        roDataCreateV1Address.setAddressLine4(loadRORecord.getAddressLine4());
        roDataCreateV1Address.setCity(loadRORecord.getCity());
        roDataCreateV1Address.setPostalCode(loadRORecord.getPostalCode());
        roDataCreateV1Address.setCountryUuid(getCountryFromCode(loadRORecord.getCountryIso3Code()));
        roDataCreateV1Address.setTerritoryUuid(
                getTerritoryFromCode(loadRORecord.getTerritoryIso3Code()));
        return roDataCreateV1Address;
    }

    private UUID getCountryFromCode(final String countryCode) {
        return countryRepository.findAll().stream()
                .filter(country -> country.getCountryIso3Code().equals(countryCode))
                .findAny()
                .map(Country::getCountryUuid)
                .orElse(null);
    }

    private UUID getTerritoryFromCode(final String territoryCode) {
        return territoryRepository.findAll().stream()
                .filter(territory -> territory.getTerritoryIsoCode().equals(territoryCode))
                .findAny()
                .map(Territory::getTerritoryUuid)
                .orElse(null);
    }

    private UUID getSectorTypeUuidFromSectorType(final String sectorsType) {
        return sectorTypeRepository.findAll().stream()
                .filter(sectorType -> sectorType.getSectorsType().equalsIgnoreCase(sectorsType))
                .findAny()
                .map(SectorType::getSectorTypeUuid)
                .orElse(null);
    }

    private UUID getAddressTypeUuidFromAddressType(final String addressTypeVal) {
        return addressTypeRepository.findAll().stream()
                .filter(addressType -> addressType.getAddressTypeName().equals(addressTypeVal))
                .findAny()
                .map(AddressType::getAddressTypeUuid)
                .orElse(null);
    }
}
