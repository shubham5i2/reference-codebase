package com.ielts.cmds.organisation.infrastructure.entity;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode(callSuper = true, exclude = { "recognisingOrganisation" })
@Entity(name = "alternate_name")
@ToString(exclude = { "recognisingOrganisation" })
public class AlternateName extends CommonModel implements Serializable {

	/**
	 * Generated SerialVersionID
	 */
	private static final long serialVersionUID = -9056885308253349400L;

	@Id
	@GeneratedValue
	@Column(name = "alternate_name_uuid")
	private UUID alternateNameUuid;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "recognising_organisation_uuid", nullable = false)
	private RecognisingOrganisation recognisingOrganisation;

	@Column(name = "name", nullable = false, length = 255)
	private String name;
}
