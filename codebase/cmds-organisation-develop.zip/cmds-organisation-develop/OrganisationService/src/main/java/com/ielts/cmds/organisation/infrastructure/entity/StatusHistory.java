package com.ielts.cmds.organisation.infrastructure.entity;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.ielts.cmds.organisation.common.enums.StatusEnum;
import com.ielts.cmds.organisation.common.enums.StatusTypeEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode(callSuper = true, exclude = { "recognisingOrganisation" })
@Entity(name = "status_history")
@ToString(exclude = { "recognisingOrganisation" })
public class StatusHistory extends CommonModel implements Serializable {

	/**
	 * Generated SerialVersionID
	 */
	private static final long serialVersionUID = -113467177426284409L;

	@Id
	@GeneratedValue
	@Column(name = "status_history_uuid")
	private UUID statusHistoryUuid;

	@ManyToOne
	@JoinColumn(name = "recognising_organisation_uuid", nullable = false)
	private RecognisingOrganisation recognisingOrganisation;

	@Enumerated(EnumType.STRING)
	@Column(name = "status", nullable = false)
	private StatusEnum status;

	@Column(name = "status_type", nullable = false)
	private StatusTypeEnum statusType;

	@Column(name = "status_datetime", nullable = false)
	@JsonSerialize(using = LocalDateTimeSerializer.class)
	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
	private LocalDateTime statusDatetime;
}
