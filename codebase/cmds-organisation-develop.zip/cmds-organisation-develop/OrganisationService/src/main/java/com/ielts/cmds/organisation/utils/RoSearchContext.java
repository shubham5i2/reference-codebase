package com.ielts.cmds.organisation.utils;

import javax.persistence.criteria.ListJoin;

import com.ielts.cmds.api.roui005rosearchrequested.RoSearchCriteria;
import org.springframework.data.jpa.domain.Specification;

import com.ielts.cmds.organisation.infrastructure.entity.Address;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;

public class RoSearchContext {

  private RoSearchStrategy roSearchStrategy;

  public RoSearchContext(RoSearchStrategy roSearchContext) {
    this.roSearchStrategy = roSearchContext;
  }

  public Specification<RecognisingOrganisation> roSearchCriteria(
      final RoSearchCriteria roSearchCriteria,
      final ListJoin<RecognisingOrganisation, Address> joinAddress) {
    return roSearchStrategy.criteriaMatches(roSearchCriteria, joinAddress);
  }
}
