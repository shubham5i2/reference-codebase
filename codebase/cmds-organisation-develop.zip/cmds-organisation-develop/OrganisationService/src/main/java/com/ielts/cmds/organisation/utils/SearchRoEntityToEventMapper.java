package com.ielts.cmds.organisation.utils;

import com.ielts.cmds.api.roui007rocreaterequested.OrganisationStatusEnum;
import com.ielts.cmds.api.roui005rosearchrequested.RoSearchObject;
import com.ielts.cmds.api.roui005rosearchrequested.SearchSortItem;
import com.ielts.cmds.api.roui007rocreaterequested.VerificationStatusEnum;
import com.ielts.cmds.organisation.common.out.event.RoSearchV1;
import com.ielts.cmds.organisation.common.out.event.RoSearchV1Criteria;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1Address;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1Addresses;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1ROList;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1Result;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1RoBasic;
import com.ielts.cmds.organisation.common.out.event.SearchPaginationV1;
import com.ielts.cmds.organisation.common.out.event.SearchSortV1;
import com.ielts.cmds.organisation.common.out.event.SearchSortV1Item;
import com.ielts.cmds.organisation.infrastructure.entity.Address;
import com.ielts.cmds.organisation.infrastructure.entity.AddressType;
import com.ielts.cmds.organisation.infrastructure.entity.Country;
import com.ielts.cmds.organisation.infrastructure.entity.OrganisationType;
import com.ielts.cmds.organisation.infrastructure.entity.RecognisingOrganisation;
import com.ielts.cmds.organisation.infrastructure.entity.Territory;
import com.ielts.cmds.organisation.infrastructure.repository.AddressTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.CountryRepository;
import com.ielts.cmds.organisation.infrastructure.repository.OrganisationTypeRepository;
import com.ielts.cmds.organisation.infrastructure.repository.TerritoryRepository;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SearchRoEntityToEventMapper {

    @Autowired private CountryRepository countryRepository;

    @Autowired private TerritoryRepository territoryRepository;

    @Autowired private AddressTypeRepository addressTypeRepository;

    @Autowired private OrganisationTypeRepository organisationTypeRepository;

    @Autowired private OrganisationCommonUtils orgCommonUtils;

    public RosSearchResultsGeneratedEventV1 mapEntityToEvent(
            final RoSearchObject roSearchObject,
            final List<RecognisingOrganisation> recognisingOrganisations,
            final long totalRecords) {
        RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1 =
                new RosSearchResultsGeneratedEventV1();
        rosSearchResultsGeneratedEventV1.setSearch(getSearch(roSearchObject));
        rosSearchResultsGeneratedEventV1.setResult(
                getResult(recognisingOrganisations, totalRecords));
        return rosSearchResultsGeneratedEventV1;
    }

    private RosSearchResultsGeneratedEventV1Result getResult(
            final List<RecognisingOrganisation> recognisingOrganisations, final long totalRecords) {
        RosSearchResultsGeneratedEventV1Result result =
                new RosSearchResultsGeneratedEventV1Result();
        result.setTotalCount((int) totalRecords);
        result.setEntries(getEntries(recognisingOrganisations));
        return result;
    }

    private RosSearchResultsGeneratedEventV1ROList getEntries(
            final List<RecognisingOrganisation> recognisingOrganisations) {
        RosSearchResultsGeneratedEventV1ROList rosSearchResultsGeneratedEventV1ROList =
                new RosSearchResultsGeneratedEventV1ROList();
        List<OrganisationType> organisationTypes = organisationTypeRepository.findAll();

        recognisingOrganisations.forEach(
                recognisingOrganisation -> {
                    RosSearchResultsGeneratedEventV1RoBasic result =
                            new RosSearchResultsGeneratedEventV1RoBasic();
                    result.setOrganisationCode(recognisingOrganisation.getOrganisationCode());
                    result.setOrganisationId(recognisingOrganisation.getOrganisationId());
                    result.setOrganisationName(recognisingOrganisation.getName());
                    result.setOrganisationStatus(OrganisationStatusEnum.valueOf(recognisingOrganisation.getOrgStatus().getValue()));
                    result.setOrganisationTypeUuid(
                            recognisingOrganisation.getOrganisationTypeUuid());
                    result.setOrganisationType(
                            getOrganisationTypeFromUuid(
                                    organisationTypes,
                                    result.getOrganisationTypeUuid()));
                    result.setPartnerCode(recognisingOrganisation.getPartnerCode());
                    result.setPartnerContact(recognisingOrganisation.getPartnerContact());
                    result.setRecognisingOrganisationUuid(
                            recognisingOrganisation.getRecognisingOrganisationUuid());
                    result.setSoftDeleted(recognisingOrganisation.getSoftDeleted());
                    result.setVerificationStatus(VerificationStatusEnum.valueOf(recognisingOrganisation.getVerificationStatus().getValue()));
                    List<Address> addressList =
                            recognisingOrganisation.getAddresses().stream()
                                    .filter(address -> Objects.isNull(address.getContact()))
                                    .collect(Collectors.toList());
                    result.setAddresses(getAddresses(addressList));
                    RecognisingOrganisation parentOrgDetails =
                            orgCommonUtils.getParentOrg(
                                    recognisingOrganisation.getLinkedRecognisingOrganisations());
                    result.setParentOrgId(parentOrgDetails.getOrganisationId());
                    result.setParentRecognisingOrganisationUuid(
                            parentOrgDetails.getRecognisingOrganisationUuid());
                    result.setParentRecognisingOrganisationName(parentOrgDetails.getName());
                    rosSearchResultsGeneratedEventV1ROList.add(result);
                });
        return rosSearchResultsGeneratedEventV1ROList;
    }

    private RosSearchResultsGeneratedEventV1Addresses getAddresses(final List<Address> addresses) {
        final List<Country> countries = countryRepository.findAll();
        final List<Territory> territories = territoryRepository.findAll();
        List<AddressType> addressTypes = addressTypeRepository.findAll();
        RosSearchResultsGeneratedEventV1Addresses addressList =
                new RosSearchResultsGeneratedEventV1Addresses();
        addresses.forEach(
                addressEntity -> {
                    RosSearchResultsGeneratedEventV1Address address =
                            new RosSearchResultsGeneratedEventV1Address();
                    address.setAddressLine1(addressEntity.getAddressline1());
                    address.setAddressLine2(addressEntity.getAddressline2());
                    address.setAddressLine3(addressEntity.getAddressline3());
                    address.setAddressLine4(addressEntity.getAddressline4());
                    address.setAddressTypeUuid(addressEntity.getAddressTypeUuid());
                    address.setAddressType(
                            getAddressTypeFromUuid(
                                    addressTypes, address.getAddressTypeUuid()));
                    address.setAddressUuid(addressEntity.getAddressUuid());
                    address.setCity(addressEntity.getCity());
                    address.setCountryUuid(addressEntity.getCountryUuid());
                    Country country =
                            getCountryFromCountryUuid(countries, address.getCountryUuid());
                    address.setCountry(country.getCountryName());
                    address.setCountryIso3Code(country.getCountryIso3Code());
                    address.setEmail(addressEntity.getEmail());
                    address.setPhone(addressEntity.getPhone());
                    address.setPostalCode(addressEntity.getPostalCode());
                    address.setTerritoryUuid(addressEntity.getTerritoryUuid());
                    Territory territory =
                            getTerritoryFromTerritoryryUuid(
                                    territories, address.getTerritoryUuid());
                    address.setTerritory(territory.getTerritoryName());
                    address.setTerritoryIsoCode(territory.getTerritoryIsoCode());
                    addressList.add(address);
                });
        return addressList;
    }

    public static Country getCountryFromCountryUuid(
            final List<Country> countries, final UUID countryUuid) {
        return countries.stream()
                .filter(country -> country.getCountryUuid().equals(countryUuid))
                .findAny()
                .orElseGet(Country::new);
    }

    public static Territory getTerritoryFromTerritoryryUuid(
            final List<Territory> territories, final UUID territoryUuid) {
        return territories.stream()
                .filter(territory -> territory.getTerritoryUuid().equals(territoryUuid))
                .findAny()
                .orElseGet(Territory::new);
    }

    public static String getOrganisationTypeFromUuid(
            final List<OrganisationType> organisationTypes, final UUID organisationTypeUuid) {
        return organisationTypes.stream()
                .filter(
                        organisationType ->
                                organisationType
                                        .getOrganisationTypeUuid()
                                        .equals(organisationTypeUuid))
                .map(OrganisationType::getDescription)
                .findAny()
                .orElse(null);
    }

    public static String getAddressTypeFromUuid(
            final List<AddressType> addressTypes, final UUID addressTypeUuid) {
        return addressTypes.stream()
                .filter(addressType -> addressType.getAddressTypeUuid().equals(addressTypeUuid))
                .map(AddressType::getAddressTypeName)
                .findAny()
                .orElse(null);
    }

    public static RoSearchV1 getSearch(final RoSearchObject roSearchObject) {
        RoSearchV1 roSearchV1 = new RoSearchV1();
        roSearchV1.setSorting(getSearchSorting(roSearchObject));
        roSearchV1.setPagination(getSearchPaginationV1(roSearchObject));
        roSearchV1.setCriteria(getSearchCriteria(roSearchObject));
        return roSearchV1;
    }

    public static SearchSortV1 getSearchSorting(final RoSearchObject roSearchObject) {
        SearchSortV1 searchSort = new SearchSortV1();
        if (Objects.nonNull(roSearchObject.getSorting())) {
            for (SearchSortItem sortItem :
                    roSearchObject.getSorting()) {
                SearchSortV1Item searchSortItemV1 = new SearchSortV1Item();
                searchSortItemV1.setSortBy(sortItem.getSortBy());
                searchSortItemV1.setSortType(sortItem.getSortType());
                searchSort.add(searchSortItemV1);
            }
        }
        return searchSort;
    }

    public static SearchPaginationV1 getSearchPaginationV1(final RoSearchObject roSearchObject) {

        SearchPaginationV1 searchPaginationV1 = new SearchPaginationV1();
        searchPaginationV1.setPageNumber(roSearchObject.getPagination().getPageNumber().intValue());
        searchPaginationV1.setPageSize(roSearchObject.getPagination().getPageSize().intValue());
        return searchPaginationV1;
    }

    public static RoSearchV1Criteria getSearchCriteria(final RoSearchObject roSearchObject) {

        RoSearchV1Criteria roSearchV1Criteria = new RoSearchV1Criteria();
        roSearchV1Criteria.setCity(roSearchObject.getCriteria().getCity());
        roSearchV1Criteria.setContactEmail(
                roSearchObject.getCriteria().getContactEmail());
        roSearchV1Criteria.setContactName(roSearchObject.getCriteria().getContactName());
        roSearchV1Criteria.setOrganisationId(
                roSearchObject.getCriteria().getOrganisationId());
        roSearchV1Criteria.setOrganisationName(
                roSearchObject.getCriteria().getOrganisationName());
        if (null != roSearchObject.getCriteria().getOrganisationStatus()
        && StringUtils.isNotEmpty(roSearchObject.getCriteria().getOrganisationStatus().getValue())) {
        roSearchV1Criteria.setOrganisationStatus(
          OrganisationStatusEnum.valueOf(
              roSearchObject.getCriteria().getOrganisationStatus().getValue()));
        }
        roSearchV1Criteria.setOrganisationTypeUuid(
                roSearchObject.getCriteria().getOrganisationTypeUuid());
        roSearchV1Criteria.setPartnerCode(roSearchObject.getCriteria().getPartnerCode());
        roSearchV1Criteria.setPostalCode(roSearchObject.getCriteria().getPostalCode());
        if (null != roSearchObject.getCriteria().getVerificationStatus()
        && StringUtils.isNotEmpty(roSearchObject.getCriteria().getVerificationStatus().getValue())) {
            roSearchV1Criteria.setVerificationStatus(
          VerificationStatusEnum.valueOf(
              roSearchObject.getCriteria().getVerificationStatus().getValue()));
         }
        roSearchV1Criteria.setCountry(roSearchObject.getCriteria().getCountry());
        roSearchV1Criteria.setTerritory(roSearchObject.getCriteria().getTerritory());
        roSearchV1Criteria.setFuzzyMatch(roSearchObject.getCriteria().getFuzzyMatch());
        return roSearchV1Criteria;
    }


}
