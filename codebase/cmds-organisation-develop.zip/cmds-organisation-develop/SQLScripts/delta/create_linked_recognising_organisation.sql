DO $$ BEGIN
 CREATE TYPE ro_owner.linked_recognising_organisation_type AS ENUM ('PARENT_RO', 'RESULTS_DELIVERY', 'REPLACED_BY');
 	EXCEPTION
     WHEN duplicate_object THEN null;
END $$;

CREATE TABLE IF NOT EXISTS ro_owner.linked_recognising_organisation(
			linked_recognising_organisation_uuid UUID NOT NULL,
			source_recognising_organisation_uuid UUID NOT NULL,
			target_recognising_organisation_uuid UUID NOT NULL,
			linked_recognising_organisation_type ro_owner.linked_recognising_organisation_type NOT NULL,
			effective_from_datetime timestamptz NOT NULL,
			effective_to_datetime timestamptz NOT NULL,
			organisation_hierarchy_label VARCHAR(50),
			concurrency_version INTEGER NOT NULL,
			created_by VARCHAR(36) NOT NULL,
			created_datetime timestamptz NOT NULL,
			updated_by VARCHAR(36),
			updated_datetime timestamptz,
			CONSTRAINT pk_linked_recognising_org PRIMARY KEY (linked_recognising_organisation_uuid),
			CONSTRAINT fk_01_linked_recognising_org_recognising_org FOREIGN KEY (source_recognising_organisation_uuid ) REFERENCES ro_owner.recognising_organisation (recognising_organisation_uuid) ON UPDATE NO ACTION ON DELETE NO ACTION,
			CONSTRAINT fk_02_linked_recognising_org_recognising_org FOREIGN KEY (target_recognising_organisation_uuid ) REFERENCES ro_owner.recognising_organisation (recognising_organisation_uuid) ON UPDATE NO ACTION ON DELETE NO ACTION
		);