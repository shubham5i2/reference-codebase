		
INSERT INTO ro_owner.sector_type(sector_type_uuid, sector_type, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('7000e02a-0bfc-44f0-af55-84dc72c12cac',
		'Regulator',
		NULL,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(sector_type_uuid) DO NOTHING;

INSERT INTO ro_owner.sector_type(sector_type_uuid, sector_type, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('d82b6817-62ff-4528-9783-1ed323c2e29a',
		'Regulatory Authority',
		NULL,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(sector_type_uuid) DO NOTHING;

INSERT INTO ro_owner.sector_type(sector_type_uuid, sector_type, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('6bab326c-9f11-4183-9b30-04f88fa845ef',
		'English Language School',
		NULL,
		'2020-07-01',
		'Operations User',
		NULL,
		NULL) ON CONFLICT(sector_type_uuid) DO NOTHING;

