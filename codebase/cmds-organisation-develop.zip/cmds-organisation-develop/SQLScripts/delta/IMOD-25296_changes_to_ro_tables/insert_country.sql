--DML scripts for country

TRUNCATE TABLE ro_owner.country CASCADE;

INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('211d70ab-8739-46dd-b846-f2d8c174c2d0',
        'AFG',
        'Afghanistan',
        'AFG',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('a8a36663-c8e3-428a-aece-633b97877ec9',
        'ALA',
        'Åland Islands',
        'ALI',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('49aeddf8-bb4e-45c0-8720-728c093280e3',
        'ALB',
        'Albania',
        'ALB',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('ec4837e4-4430-423b-abfd-fe811c7dc40f',
        'DZA',
        'Algeria',
        'ALG',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('4fa2adbd-771f-41e4-aedd-0c89d2ee1966',
        'ASM',
        'American Samoa',
        'ASM',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('becc53c3-953e-4242-8fea-e6608de8e4f4',
        'AND',
        'Andorra',
        'AND',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('2a75c834-778c-4ea5-85ca-1bdd9fa0ecb7',
        'AGO',
        'Angola',
        'AGO',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('72dd959b-6b96-4821-ac32-114cf7853468',
        'AIA',
        'Anguilla',
        'ANG',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('19e2e144-a1c9-402b-9661-c4fb2374a9a6',
        'ATA',
        'Antarctica',
        'ANC',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('415b5e6b-a31b-4187-8b9b-783c483c40ba',
        'ATG',
        'Antigua and Barbuda',
        'ATG',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('e5a29b3f-d276-40cb-82d4-edb6df9ecf60',
        'ARG',
        'Argentina',
        'ARG',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('ffb87177-ff8e-48f1-a843-4beea49a148f',
        'ARM',
        'Armenia',
        'ARM',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('0a44303f-6c27-4d66-93f0-775a8ac586f1',
        'ABW',
        'Aruba',
        'ARU',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('74a4f195-60e0-419e-9b04-c1a0c1b8febe',
        'AUS',
        'Australia',
        'AUS',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('f744f5a3-37d3-4637-b797-4ffb7bcd04ba',
        'AUT',
        'Austria',
        'AUT',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('a58e615a-45c1-42e3-8565-4a024c4ef38d',
        'AZE',
        'Azerbaijan',
        'AZE',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('984f2e27-8124-4055-9d8c-509c8fadb5fb',
        'BHS',
        'Bahamas (the)',
        'BHS',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('d3cf6759-069b-459d-b0c7-f8f6e0f84b95',
        'BHR',
        'Bahrain',
        'BAH',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('69553347-9953-4ea0-a09d-7e5cd9a51b03',
        'BGD',
        'Bangladesh',
        'BAN',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('ea809bf6-d3d4-4a93-ab8d-3468faf95d64',
        'BRB',
        'Barbados',
        'BRB',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('9505d299-8958-4489-aad6-2aca702d8e2a',
        'BLR',
        'Belarus',
        'BRS',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('8fb17ebc-b118-4249-b3e6-e0b423210a0c',
        'BEL',
        'Belgium',
        'BEL',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('debce9ff-dad6-43d2-84eb-0015b3f3f999',
        'BLZ',
        'Belize',
        'BLZ',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('adff8703-2dab-442c-9259-baa81df6abf6',
        'BEN',
        'Benin',
        'BEN',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('69dfcbbf-1fac-496c-972a-b20919b39d51',
        'BMU',
        'Bermuda',
        'BMU',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('9166bfb5-e9e6-4e05-b658-c2150e963b12',
        'BTN',
        'Bhutan',
        'BTN',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('7bc450cf-1260-428d-b500-af11b73938e1',
        'BOL',
        'Bolivia (Plurinational State of)',
        'BOL',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('79e71395-5ce1-434b-a073-8145ac502ce2',
        'BES',
        'Bonaire, Sint Eustatius and Saba',
        'BES',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('5c180bd5-4cc1-41a6-980e-e02dc572b0f5',
        'BIH',
        'Bosnia and Herzegovina',
        'BOS',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('505777ae-1b0f-4a16-9e87-a8771357a1ae',
        'BWA',
        'Botswana',
        'BOT',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('e0d4e03b-6c96-48ce-8e49-976db5c8a21f',
        'BVT',
        'Bouvet Island',
        'BVT',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('3813d4c0-4eeb-4131-a0ee-5785141087e5',
        'BRA',
        'Brazil',
        'BRA',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('a4f3b613-51cf-41d4-a1c5-0606f5906ec7',
        'IOT',
        'British Indian Ocean Territory (the)',
        'IOT',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('a8d157b7-aac0-4f03-beb4-3619343cb6ac',
        'BRN',
        'Brunei Darussalam',
        'BRN',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('c0675c06-d5b3-478c-9995-b5737a68e816',
        'BGR',
        'Bulgaria',
        'BUL',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('378bd7d1-8f01-492c-b4ad-91c8e3574285',
        'BFA',
        'Burkina Faso',
        'BKF',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('7e74157b-d8d4-4e99-af88-c42a143de8c1',
        'BDI',
        'Burundi',
        'BDI',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('4c094c23-510c-4f3d-9aa4-c3c393064ae4',
        'KHM',
        'Cambodia',
        'CAM',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('a1983af2-9ceb-49e9-919e-f7dd546a1888',
        'CMR',
        'Cameroon',
        'CMR',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('8bb206ec-cdc2-4179-80ba-a9f1a53aee49',
        'CAN',
        'Canada',
        'CAN',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('ea114a6f-c054-4dda-8128-99b02da02390',
        'CPV',
        'Cabo Verde',
        'CPV',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('df2e849b-4d09-4fd4-a792-00f1a1cf5f3b',
        'CYM',
        'Cayman Islands (the)',
        'CYM',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('0ecacbec-f061-4f2b-ad46-f6451e32220d',
        'CAF',
        'Central African Republic (the)',
        'CAF',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('8dd39292-2f5c-4748-80e2-f13590f54fbb',
        'TCD',
        'Chad',
        'TCD',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('e5b3ce5f-aa1c-4d88-9709-3645313be5d2',
        'CHL',
        'Chile',
        'CHL',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('fa328170-6289-4a3d-bac1-2c1c87081719',
        'CHN',
        'China',
        'CHN',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('4eaef528-c7fb-45ce-bc46-568700e6e92e',
        'CXR',
        'Christmas Island',
        'CXR',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('be61814c-0c3d-4ea6-8ce7-329b99947f77',
        'CCK',
        'Cocos (Keeling) Islands (the)',
        'CCK',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('eff601b6-01dd-4ba8-8de3-1e98e63ea7c5',
        'COL',
        'Colombia',
        'COL',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('225b8ebb-1976-4082-964d-805c3825f59b',
        'COM',
        'Comoros (the)',
        'COM',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('7498e44c-475e-4d44-a15b-c4bb36b5f160',
        'COG',
        'Congo (the)',
        'COG',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('5f1cecee-6027-4bee-94c7-e66473ad9523',
        'COD',
        'Congo (the Democratic Republic of the)',
        'CNG',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('90550ef5-27a2-467c-8e19-08690a76990a',
        'COK',
        'Cook Islands (the)',
        'COK',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('b44c89e1-0d5e-489d-a7b8-59c6b49434ba',
        'CRI',
        'Costa Rica',
        'CRI',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('72fc97b6-dabf-43a7-9af7-6e945d980801',
        'CIV',
        'Côte d''Ivoire',
        'CIV',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('f6585010-900c-448b-9b51-eda77f1d2626',
        'HRV',
        'Croatia',
        'CRO',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('fd9717c3-708a-40c4-9755-c9c41052349e',
        'CUB',
        'Cuba',
        'CUB',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('142c59aa-ec6c-4f1c-8099-db5dc43a16f2',
        'CUW',
        'Curaçao',
        'ANT',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;
		
INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('ee1115c4-a067-4bf2-b2f2-9a9b5ecfbcdf',
        'CZE',
        'Czechia',
        'CSK',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('553cd677-3c9d-472d-becd-740621449a2f',
        'CYP',
        'Cyprus',
        'CYP',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('dc90f18c-5235-4d28-89a2-195530882f0c',
        'DNK',
        'Denmark',
        'DNK',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('321546b6-cbaf-49d6-9da6-c5a80101aadf',
        'DJI',
        'Djibouti',
        'DJI',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('f8aa68a7-3d77-4df5-9285-996273516d4a',
        'DMA',
        'Dominica',
        'DMA',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('d6947ee9-7cad-44a1-8d6c-44571596a086',
        'DOM',
        'Dominican Republic (the)',
        'DOM',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('8314847f-9e8e-43ec-a16c-590b64da6307',
        'ECU',
        'Ecuador',
        'ECU',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('28e14ff5-3368-45b5-bd86-504533db5121',
        'EGY',
        'Egypt',
        'EGY',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('cf6a4544-3fa0-48d0-8958-1ea33508e802',
        'SLV',
        'El Salvador',
        'SLV',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('82e063ee-585f-4ffe-b44d-2b22ccce1c5a',
        'GNQ',
        'Equatorial Guinea',
        'GNQ',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('e44fa6ae-8891-4f90-88f5-03677d922913',
        'ERI',
        'Eritrea',
        'ERI',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('eac22140-5138-4607-954f-175249fe1380',
        'EST',
        'Estonia',
        'EST',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('c25d29f7-507e-45af-83d6-624058a29a55',
        'SWZ',
        'Eswatini',
        'SWZ',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('1bd65587-6174-4af3-a14d-535ac09fff16',
        'ETH',
        'Ethiopia',
        'ETH',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('6ee147f1-b7dd-485b-932c-6a6e516463ce',
        'FLK',
        'Falkland Islands (the) [Malvinas]',
        'FLK',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('d5fc03b2-9475-44fe-b876-51b9a1c9717e',
        'FRO',
        'Faroe Islands (the)',
        'FRO',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('0fea3958-6d01-4c17-bcc6-acbab6dd941e',
        'FJI',
        'Fiji',
        'FJI',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('9c0c0dbd-8baf-455d-bda6-8ebf13797675',
        'FIN',
        'Finland',
        'FIN',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('edc58430-6013-41b6-a91a-ddd2ec59bc5f',
        'FRA',
        'France',
        'FRA',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('ee6ecd95-ea0a-4ef3-a7d4-1f3e25a4b7d7',
        'GUF',
        'French Guiana',
        'GUF',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('08528e84-6e15-4c67-b0b9-0c7c77bc1b2d',
        'PYF',
        'French Polynesia',
        'PYF',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('69295f1c-8d02-414d-bebe-dea94eadb505',
        'ATF',
        'French Southern Territories (the)',
        'FST',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('1d59063d-e525-4dde-8ea9-9a09f62c51b9',
        'GAB',
        'Gabon',
        'GAB',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('6dcce438-2d9e-478b-9d6b-cac8cb9a7bc8',
        'GMB',
        'Gambia (the)',
        'GMB',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('ef6cd030-ca84-46ba-bd22-eb0671335acc',
        'GEO',
        'Georgia',
        'GEO',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('902e9304-ebb0-4d28-82bd-b8caf90db915',
        'DEU',
        'Germany',
        'GER',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('08283301-6826-466c-bebd-4b882181473b',
        'GHA',
        'Ghana',
        'GHA',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('9e3d3e08-d09c-457c-b99f-6dc9d59fac4a',
        'GIB',
        'Gibraltar',
        'GIB',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('61e90cbe-8fec-4103-afb2-3136c40cfaf2',
        'GRC',
        'Greece',
        'GRC',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('9cf0caf4-8427-48ba-bd9e-d75c65ce6a86',
        'GRL',
        'Greenland',
        'GRL',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('22e1d34a-f9c2-4e65-90f0-ff249465e06f',
        'GRD',
        'Grenada',
        'GRD',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('43c25feb-6afe-4ffe-9515-42551e487730',
        'GLP',
        'Guadeloupe',
        'GLP',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('a57932b6-9390-426a-8b13-1f19f5661875',
        'GUM',
        'Guam',
        'GUM',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('bbc2fd7b-9239-4ca8-9da5-e1357b261b04',
        'GTM',
        'Guatemala',
        'GTM',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('5cc1267f-5d3a-4eed-b9a3-b9c96a2257f1',
        'GGY',
        'Guernsey',
        'GGY',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('19f80662-0476-43c7-847f-e77a739352e2',
        'GIN',
        'Guinea',
        'GIN',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('3f46e167-f6fd-4556-8bce-164c25632793',
        'GNB',
        'Guinea-Bissau',
        'GNB',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('070635e4-612f-4bc4-bc2c-fb86c7b41a23',
        'GUY',
        'Guyana',
        'GUY',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('08f1a260-a676-4d42-9574-2434e3f53357',
        'HTI',
        'Haiti',
        'HTI',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('20659e45-6ee9-452a-b49f-909a5349e253',
        'HMD',
        'Heard Island and McDonald Islands',
        'HMD',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('68f0b8ef-bd61-4964-a517-dd749a8c13d8',
        'VAT',
        'Holy See (the)',
        'VAT',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('1e4c026e-c6d0-49a1-8979-966553554aba',
        'HND',
        'Honduras',
        'HND',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('932e9d84-44a9-4e67-b3b8-55a4ad4013c7',
        'HKG',
        'Hong Kong',
        'HKG',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('31b8b478-8772-4c09-96d2-15406a780195',
        'HUN',
        'Hungary',
        'HUN',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('31c98c4b-b2e5-4670-b6ee-80153dc8a5df',
        'ISL',
        'Iceland',
        'ISL',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('4b8dac87-d2dd-4599-b055-2f73a5f0a01a',
        'IND',
        'India',
        'IND',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('2998dc96-e507-4c95-b067-51d19bee8319',
        'IDN',
        'Indonesia',
        'IDN',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('0166e4b4-42cd-41ca-9685-187d357ed8bc',
        'IRN',
        'Iran (Islamic Republic of)',
        'IRN',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('4a0834d0-3d1f-4ac1-89a4-aab7b1ef78b8',
        'IRQ',
        'Iraq',
        'IRQ',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('a74b9941-3971-4075-9902-6f5fdcdfec4b',
        'IRL',
        'Ireland',
        'EIR',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('ce4889d8-ae35-467c-ae2e-5a59846932ac',
        'ISR',
        'Israel',
        'ISR',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('0000108a-d774-4e0b-b3da-415b07bd77a1',
        'ITA',
        'Italy',
        'ITA',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('51d1438d-0720-48a2-b326-3f2e159b34c4',
        'JAM',
        'Jamaica',
        'JAM',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('0b9bfed2-ae52-435c-9719-15854637cd18',
        'JPN',
        'Japan',
        'JAP',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('3fe52c8b-613e-43bb-825a-c8526d203b22',
        'JEY',
        'Jersey',
        'JEY',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('209e325f-52ec-4769-a3f7-eab17a803695',
        'JOR',
        'Jordan',
        'JOR',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('02d45f67-cdf7-4b66-b782-e31255ff08a8',
        'KAZ',
        'Kazakhstan',
        'KAZ',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('dd83f749-5dc3-462f-827c-e9a109b3f91d',
        'KEN',
        'Kenya',
        'KEN',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('f4b6dca3-0592-46e9-b83c-89b9269894f7',
        'KIR',
        'Kiribati',
        'KIR',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('f54b49e5-cad6-49cc-9d62-175fdafaaeca',
        'PRK',
        'Korea (the Democratic Peoples Republic of)',
        'KON',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('c947082b-0d2f-4a85-9c64-592ad0a4dfa4',
        'KOR',
        'Korea (the Republic of)',
        'KOR',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('ef910575-3a48-4139-b944-2dd0da584e64',
        'KOS',
        'Kosovo',
        'KOS',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('2ff75e65-d39b-428e-bc40-12e0955b1dd7',
        'KWT',
        'Kuwait',
        'KWT',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('54a2a395-fb6f-41a2-9be4-0b0e0914e52a',
        'KGZ',
        'Kyrgyzstan',
        'KYG',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('ff9b2078-3f68-4350-92ea-853f5a476eff',
        'LAO',
        'Lao Peoples Democratic Republic (the)',
        'LAO',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('bb915e83-9f70-474b-adb7-c992334330a0',
        'LVA',
        'Latvia',
        'LAT',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('4c669be3-0768-4536-ad21-7ba41083d210',
        'LBN',
        'Lebanon',
        'LBN',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('f9abc255-1e49-4199-8b0b-3293070deb1c',
        'LSO',
        'Lesotho',
        'LSO',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('17324c02-a920-4d8b-a59d-bff2398e1fcf',
        'LBR',
        'Liberia',
        'LBR',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('462cf2e1-f1d6-497b-ab1a-a51d09ac6bb8',
        'LBY',
        'Libya',
        'LBY',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('4007175e-c39d-421f-854d-2ab92affe48d',
        'LIE',
        'Liechtenstein',
        'LIE',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('4d247639-930b-4bd7-a071-9127e7041ee0',
        'LTU',
        'Lithuania',
        'LIT',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('619b8b6f-7032-47e6-8dc9-5ca3ab4b1c0b',
        'LUX',
        'Luxembourg',
        'LUX',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('fb243970-ddf2-49cc-a593-503f2fdaa0bc',
        'MAC',
        'Macao',
        'MAC',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('6586050e-c99a-4540-881b-868d38167aef',
        'MDG',
        'Madagascar',
        'MDG',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('19fa7f93-7f25-41a4-bd1a-76fe927c9ef3',
        'MWI',
        'Malawi',
        'MWI',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('53df568c-3d08-4bbe-9ca1-dce0c14dfe88',
        'MYS',
        'Malaysia',
        'MYS',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('a61f50af-37e3-4e81-806d-29859d6eddb2',
        'MDV',
        'Maldives',
        'MDV',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('a940f5c5-0ecc-4345-8844-71a44cd8fadb',
        'MLI',
        'Mali',
        'MLI',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('819c9279-53e0-4e28-b766-a4c8fad793ec',
        'MLT',
        'Malta',
        'MLT',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('849de61a-f808-4e04-913a-b7ca5d4c44e8',
        'MHL',
        'Marshall Islands (the)',
        'MSI',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('12dc453d-6f2e-4227-a5ca-2f84e0b23e48',
        'MTQ',
        'Martinique',
        'MTQ',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('ebc0f617-a473-459d-85df-c6abc774b3fe',
        'MRT',
        'Mauritania',
        'MRT',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('bade52bb-ab24-4561-bbf9-251a0b0769c9',
        'MUS',
        'Mauritius',
        'MUS',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('f6cdd01b-efcb-48be-ae3c-ca07a0dcd2e1',
        'MYT',
        'Mayotte',
        'MAY',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('b5a9774c-5473-4d05-b995-883b4a97406b',
        'MEX',
        'Mexico',
        'MEX',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('d21069e1-1c00-4fe6-845c-8684cb7a4dcb',
        'FSM',
        'Micronesia (Federated States of)',
        'MIC',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('e16929eb-b6a8-4792-b650-fba2139d000c',
        'MDA',
        'Moldova (the Republic of)',
        'MOL',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('87d74e28-347e-470e-8bc9-0c2fb87328e9',
        'MCO',
        'Monaco',
        'MCO',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('0e57c829-cdbd-4447-aaf5-dae29a53668a',
        'MNG',
        'Mongolia',
        'MNG',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('40bb735d-b165-400f-b378-ff40d085ccfe',
        'MNE',
        'Montenegro',
        'MNE',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('9a28a10b-35b7-4e4e-9274-591f178d898f',
        'MSR',
        'Montserrat',
        'MSR',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('9a8a63bc-2d9f-4289-b31c-b093204bb834',
        'MAR',
        'Morocco',
        'MAR',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('6924d070-742c-46a7-a111-e8e540ec76e4',
        'MOZ',
        'Mozambique',
        'MOZ',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('aa0a4ebb-4574-45be-8287-d4dd74160c51',
        'MMR',
        'Myanmar',
        'MYN',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('0a092b0a-6d18-4e42-97b7-1d3600045562',
        'NAM',
        'Namibia',
        'NAM',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('05cc78fe-4d87-4678-9544-f2a534264195',
        'NRU',
        'Nauru',
        'NRU',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('7bb7f4b4-54be-4a61-addf-2eb06d833e8c',
        'NPL',
        'Nepal',
        'NPL',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;



INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('89ca7ab5-ac3a-44bd-8035-6bf72d3d3a4b',
        'NLD',
        'Netherlands (the)',
        'NLD',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('cd542abb-1dc4-4cd5-a578-cde159d3520d',
        'NCL',
        'New Caledonia',
        'NCL',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('0db40418-3cb3-4aae-afcc-329c3ca677a3',
        'NZL',
        'New Zealand',
        'NZ',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('9a04b342-417d-4c56-af08-57e0f35ddf29',
        'NIC',
        'Nicaragua',
        'NIC',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('a1d47606-5f2b-42e9-aea1-c8081971cc7d',
        'NER',
        'Niger (the)',
        'NER',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('3c986cd3-b55d-4e1f-b0c5-9955dd7dd2c1',
        'NGA',
        'Nigeria',
        'NGA',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('2096270f-f469-4ddc-b008-4638ea925ac1',
        'NIU',
        'Niue',
        'NIU',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('f9812ccf-537e-4e39-8bbd-49660443435e',
        'NFK',
        'Norfolk Island',
        'NFK',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('255aeef7-dc4c-4179-9351-8f047c1f764a',
        'MKD',
        'North Macedonia',
        'FMK',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('b2288fc2-a146-4d9d-a8b6-58a4e17ec278',
        'MNP',
        'Northern Mariana Islands (the)',
        'NMS',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('06b9fa4e-ba5d-4fc3-9002-72a58868e4d7',
        'NOR',
        'Norway',
        'NOR',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('960f14d2-b656-4aee-90ac-66e2a1895974',
        'OMN',
        'Oman',
        'OMN',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('0979b1d6-89f1-4397-844f-a393c69e83fe',
        '0',
        'Other',
        '0',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('5946b53b-73c9-4767-82b2-1c8449a1b09f',
        'PAK',
        'Pakistan',
        'PAK',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('6c61d94b-5112-40c6-b4f8-ab885a3e1891',
        'PLW',
        'Palau',
        'PAA',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('7ea874fb-d7fb-4086-a8db-538d9c39ddb0',
        'PSE',
        'Palestine, State of',
        'PAL',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('fae16a5d-07b2-47cb-ae8b-43c74b31bab4',
        'PAN',
        'Panama',
        'PAN',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('f847712d-6ae4-49b3-be3c-d51fccaeae72',
        'PNG',
        'Papua New Guinea',
        'PNG',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('1cfc81fd-975a-4524-ae8d-9308196bd3c2',
        'PRY',
        'Paraguay',
        'PRY',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('b0e8700a-52d5-4940-bc76-443e6bcdd6fa',
        'PER',
        'Peru',
        'PER',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('7e682041-3309-410e-a152-04dd5ffcaaf7',
        'PHL',
        'Philippines (the)',
        'PHL',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('fcb27c5d-3396-4016-ae4b-68a191ab2f5e',
        'PCN',
        'Pitcairn ',
        'PCN',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('9c3330f2-b32c-4a6c-9bd7-31320e9d75ad',
        'POL',
        'Poland',
        'POL',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('e1dae6d8-f66a-44e8-a87b-c70ab492dcc6',
        'PRT',
        'Portugal',
        'PRT',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('1a1516d0-a435-45d3-9ef0-2d2dff867f7f',
        'PRI',
        'Puerto Rico',
        'PRI',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('a05ad2f5-186b-4a8d-92e3-13c5769549ce',
        'QAT',
        'Qatar',
        'QAT',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('b984e7a2-8ef9-4d4f-b985-a849ca6fa0c6',
        'REU',
        'Réunion',
        'REU',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('6420d400-4917-4e08-abd2-48589930aa24',
        'ROU',
        'Romania',
        'ROM',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('018a95fe-fb24-43f9-a972-2cadce41e822',
        'RUS',
        'Russian Federation (the)',
        'SUN',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('2b75b482-128e-4c7c-9e9e-a9d0ff639f9a',
        'RWA',
        'Rwanda',
        'RWA',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('3cc511a8-f946-46b0-b1b1-ed0b9857d55f',
        'BLM',
        'Saint Barthelemy',
        'BLM',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('79ded6ec-b30d-4786-a27d-a55bed9492c1',
        'SHN',
        'Saint Helena, Ascension and Tristan da Cunha',
        'SHN',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('7d36c834-4da2-4e73-8b08-8f09d5d18d37',
        'KNA',
        'Saint Kitts and Nevis',
        'KNA',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('011d57a1-50fe-4bfc-8947-df1ca0b44b1e',
        'LCA',
        'Saint Lucia',
        'LCA',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('19be48f2-10fc-4124-b438-d18e97113c90',
        'MAF',
        'Saint Martin (French part)',
       'MAF',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('5dd7f90a-88cf-403b-af5c-5a29b5fa272b',
        'SPM',
        'Saint Pierre and Miquelon',
        'SPM',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('6945081a-27a7-4ee4-8592-a49c1c1bcd60',
        'VCT',
        'Saint Vincent and the Grenadines',
        'VCT',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('f0fcfc0d-4017-4aea-a2a1-a98b4bc30a81',
        'WSM',
        'Samoa',
        'WSM',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('cccdcd10-7e59-414c-b779-a779ebd102dc',
        'SMR',
        'San Marino',
        'SMR',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('fdfad402-0f6e-4133-b46a-c1c1fba8bc03',
        'STP',
        'São Tomé and Príncipe',
        'STP',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('7d9ffad1-a1b5-49d1-98cc-0f1b1ed5fcb4',
        'SAU',
        'Saudi Arabia',
        'SAU',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('aca23ec9-90b0-47ef-baca-52635d6a4f42',
        'SEN',
        'Senegal',
        'SEN',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('96955224-8f44-44c4-a9a2-68b0a7a58ac5',
        'SRB',
        'Serbia',
        'SRB',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('06c6da42-b9b6-4e1a-a767-ceaef5f7e091',
        'SYC',
        'Seychelles',
        'SYC',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('c85d453a-213e-46ad-b9a0-3d9b7dba026b',
        'SLE',
        'Sierra Leone',
        'SLE',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('418d69e3-6ace-4008-932c-6ef710d58faf',
        'SGP',
        'Singapore',
        'SGP',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('338fccce-9376-487f-bd52-5d70d757e8cf',
        'SXM',
        'Sint Maarten (Dutch part)',
        'SXM',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('c5107dd8-745d-4421-8835-97d1fd57aef1',
        'SVK',
        'Slovakia',
        'SLK',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('b15ffa6f-d2b0-41b3-86ee-8f470c051080',
        'SVN',
        'Slovenia',
        'SLO',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('06e815dd-eea6-4092-bbfd-405479d7c618',
        'SLB',
        'Solomon Islands',
        'SLB',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('dc8a8054-fdc8-4bd8-a80a-8a28af1a4b44',
        'SOM',
        'Somalia',
        'SOM',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('3a3aa277-8a59-4061-a6ed-e9a9dacc4808',
        'ZAF',
        'South Africa',
        'ZAF',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('6770a5a2-38ab-4928-9475-ff75489fd0a9',
        'SGS',
        'South Georgia and the South Sandwich Islands',
        'SGS',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('ed70286b-6802-4a95-a0f7-9f1deb00037a',
        'SSD',
        'South Sudan',
        'SSD',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('85ad033e-360b-44eb-a117-2af7fe0bfc01',
        'ESP',
        'Spain',
        'SPA',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('059d9adb-3e83-4f1d-825c-03c301557a7a',
        'LKA',
        'Sri Lanka',
        'LKA',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('793034d7-1bac-4c2e-90a3-3373b43a77c8',
        'SDN',
        'Sudan (the)',
        'SDN',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('9be3af1f-25f3-4f73-88f1-c4237cfdbed9',
        'SUR',
        'Suriname',
        'SUR',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('3fcaa812-426b-4cc2-938d-af17831bfbbc',
        'SJM',
        'Svalbard and Jan Mayen',
        'SJM',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('d5c91f11-29c6-447d-8afa-a006202fdd5f',
        'SWE',
        'Sweden',
        'SWE',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('7f9b0db1-3414-4a9c-b050-fb810e48e679',
        'CHE',
        'Switzerland',
        'SWI',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('876ddbb6-5019-4043-886d-f928d6b830cb',
        'SYR',
        'Syrian Arab Republic (the)',
        'SYR',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('41e21aff-5441-4bc0-94c6-825adab59e2c',
        'TWN',
        'Taiwan (Province of China)',
        'TWN',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('30a01674-a19b-4fdb-b1d2-21149451cca2',
        'TJK',
        'Tajikistan',
        'TAJ',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('c3e037af-f62c-4039-8cb5-841d48a2b442',
        'TZA',
        'Tanzania,the United Republic of',
        'TZA',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('638845dd-d24c-4a80-ab4b-1d0fc2115f55',
        'THA',
        'Thailand',
        'THA',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('0c170c66-44da-47d2-97e0-00706156c70b',
        'TLS',
        'Timor-Leste',
        'TSL',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('11232776-7c0d-46f2-814b-86caadba61cc',
        'TGO',
        'Togo',
        'TGO',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('8f05c3df-381c-4457-b82a-066e36a5334d',
        'TKL',
        'Tokelau',
        'TKL',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('bc56de3c-4281-4cd8-a61c-20dc284d3485',
        'TON',
        'Tonga',
        'TON',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('790bbd64-613e-4205-bbf6-0731d48e9869',
        'TTO',
        'Trinidad and Tobago',
        'TTO',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('5e6d4c18-8478-4ad0-80d3-75c6933026e8',
        'TUN',
        'Tunisia',
        'TUN',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('ccc7bd66-d434-4e33-8a5d-c347f0a1fc0b',
        'TUR',
        'Turkey',
        'TUR',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('c94d0596-9ab1-4da9-8b8f-e01c231f0c62',
        'TKM',
        'Turkmenistan',
        'TUM',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('485e9cc3-7f13-45ad-9984-9b077c17fcc3',
        'TCA',
        'Turks and Caicos Islands (the)',
        'TCA',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('7f97748b-c02d-4107-9c8a-d303e8414325',
        'TUV',
        'Tuvalu',
        'TUV',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('90024512-5230-44eb-839f-f1594d07b2d9',
        'UGA',
        'Uganda',
        'UGA',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('132c30d9-3a47-4986-8829-cb519464b4fa',
        'UKR',
        'Ukraine',
        'UKR',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('1777e131-b5ca-4f6c-90fd-802d1097b7f4',
        'ARE',
        'United Arab Emirates (the)',
        'UAE',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('029fd27d-b39a-48b4-87e7-131a063bea2d',
        'GBR',
        'United Kingdom of Great Britain and Northern Ireland (the)',
        'UK',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('c429af8b-f357-4ff5-b4a2-a7b7453cb664',
        'UMI',
        'United States Minor Outlying Islands (the)',
        'USI',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('185f8b77-9e53-4a5c-8a79-51a8ad7961aa',
        'USA',
        'United States of America (the)',
        'USA',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('25b16284-e213-44a0-bc7e-b0bb5bce17d6',
        '999',
        'Unknown',
        '999',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('b620debf-3a44-4ae8-b356-0cadb261f309',
        'URY',
        'Uruguay',
        'URY',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('66dacbfd-b488-470c-9c9d-e1193ade7790',
        'UZB',
        'Uzbekistan',
        'UZB',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('ce37fcda-c5de-437e-9dc1-e4fbaec86a7f',
        'VUT',
        'Vanuatu',
        'VUT',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('7ce7c29a-2e7f-41b9-a153-27819329d80e',
        'VEN',
        'Venezuela (Bolivarian Republic of)',
        'VEN',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('5e9c2e3a-fc9b-4ecc-ab30-3bdbb7c2abe5',
        'VNM',
        'Vietnam',
        'VNM',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('a99e3727-c0d3-4eac-935e-717a5a33f918',
        'VGB',
        'Virgin Islands (British)',
        'VGB',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('c8b0e5a6-ba54-4d40-aa94-c019ce14c651',
        'VIR',
        'Virgin Islands (U.S.)',
        'VIR',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('5d97640f-7767-44f8-8e1e-403e7346c38c',
        'WLF',
        'Wallis and Futuna ',
        'WLF',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('de8d0c02-3a73-4da6-b79a-5cc756c90bc3',
        'ESH',
        'Western Sahara*',
        'WES',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('1ecb1c51-23d4-4bc8-990c-95fc17a15ca1',
        'YEM',
        'Yemen',
        'YEM',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('11c26d50-249e-48e2-8024-cee55ed51c35',
        'ZMB',
        'Zambia',
        'ZMB',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;


INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('77d6a91f-1447-4dc5-be27-c3199e6df6fa',
        'ZWE',
        'Zimbabwe',
        'ZWE',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;

INSERT INTO ro_owner.country (country_uuid, country_iso3_code, country_name, legacy_reference, created_by, updated_by, updated_datetime)
VALUES ('1acac64e-25a4-4aa1-875b-99bed3af24ff',
        'IMN',
        'Isle of Man',
        'IMN',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(country_uuid) DO NOTHING;