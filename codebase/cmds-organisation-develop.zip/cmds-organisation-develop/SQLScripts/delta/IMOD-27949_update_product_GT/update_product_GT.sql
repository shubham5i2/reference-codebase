

UPDATE ro_owner.product SET available_to_date='2022-03-28' WHERE product_uuid='18c94472-35e8-4d89-93da-f6d9caa7f003';

UPDATE ro_owner.product SET available_to_date='2022-03-28' WHERE product_uuid='f21e2e7f-02e8-4bd7-9602-c247e8a02a5a';

UPDATE ro_owner.product SET available_to_date='2022-03-28' WHERE product_uuid='d8c32eff-1112-467b-a881-9e52f5acc796';

UPDATE ro_owner.product SET available_to_date='2022-03-28' WHERE product_uuid='48b0643a-11eb-4eff-b4e3-3f930c6fcdd3';

UPDATE ro_owner.product SET available_to_date='2022-03-28' WHERE product_uuid='d96eece2-1d7c-495a-a754-6b523b710a82';