ALTER TABLE ro_owner.recognising_organisation ADD COLUMN ielts_display_flag BOOLEAN DEFAULT FALSE;
ALTER TABLE ro_owner.recognising_organisation ADD COLUMN ors_display_flag BOOLEAN DEFAULT FALSE;
