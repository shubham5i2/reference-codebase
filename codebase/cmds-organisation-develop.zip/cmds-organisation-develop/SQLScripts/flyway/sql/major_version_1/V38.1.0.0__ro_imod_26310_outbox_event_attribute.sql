CREATE TABLE IF NOT EXISTS ro_owner.outbox_event_attribute (
    outbox_event_attribute_uuid UUID NOT NULL,
    event_outbox_uuid UUID NOT NULL,
	attribute_key VARCHAR(256) NOT NULL,
	attribute_value TEXT,
	updated_datetime TIMESTAMPTZ NOT NULL,
    CONSTRAINT pk_outbox_event_attribute PRIMARY KEY (outbox_event_attribute_uuid),
	CONSTRAINT fk_01_outbox_event_attribute_event_outbox_uuid_outbox_event_outbox_event_uuid FOREIGN KEY (event_outbox_uuid) References ro_owner.outbox_event(outbox_event_uuid),
	CONSTRAINT uk_01_outbox_event_attribute UNIQUE (event_outbox_uuid, attribute_key)
);