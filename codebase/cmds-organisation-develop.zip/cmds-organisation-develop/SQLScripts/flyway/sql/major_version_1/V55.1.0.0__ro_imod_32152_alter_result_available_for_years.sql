ALTER TABLE ro_owner.recognising_organisation ALTER COLUMN result_available_for_years SET DEFAULT 3;
