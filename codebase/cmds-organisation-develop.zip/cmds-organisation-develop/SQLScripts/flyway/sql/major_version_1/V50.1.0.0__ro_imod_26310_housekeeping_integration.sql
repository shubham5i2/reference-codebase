GRANT DELETE 
ON  ro_owner.outbox_event, ro_owner.outbox_event_attribute
TO  ro_user;