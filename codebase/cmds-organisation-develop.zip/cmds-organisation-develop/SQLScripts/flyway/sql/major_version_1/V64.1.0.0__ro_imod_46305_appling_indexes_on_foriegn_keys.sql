--Applying indexing on recognising_organisation_uuid as it is foriegn key in Address Table.
Create INDEX IF NOT EXISTS idx_address_recognising_organisation_uuid ON ro_owner.address (recognising_organisation_uuid);

--Applying indexing on contact_uuid as it is foriegn key in Address Table.
Create INDEX IF NOT EXISTS idx_address_contact_uuid ON ro_owner.address (contact_uuid);

--Applying indexing on recognising_organisation_uuid as it is foriegn key in Contact Table.
Create INDEX IF NOT EXISTS idx_contact_recognising_organisation_uuid ON ro_owner.contact (recognising_organisation_uuid);

--Applying indexing on recognising_organisation_uuid as it is foriegn key in RO_Note Table.
Create INDEX IF NOT EXISTS idx_ro_note_recognising_organisation_uuid ON ro_owner.ro_note (recognising_organisation_uuid);

--Applying indexing on recognising_organisation_uuid as it is foriegn key in Alternate_Name Table.
Create INDEX IF NOT EXISTS idx_alternate_name_recognising_organisation_uuid ON ro_owner.alternate_name (recognising_organisation_uuid);

--Applying indexing on recognising_organisation_uuid as it is foriegn key in Minimum_Score Table.
Create INDEX IF NOT EXISTS idx_minimum_score_recognising_organisation_uuid ON ro_owner.minimum_score (recognising_organisation_uuid);

--Applying indexing on recognising_organisation_uuid as it is foriegn key in Recognised_Product Table.
Create INDEX IF NOT EXISTS idx_recognised_product_recognising_organisation_uuid ON ro_owner.recognised_product (recognising_organisation_uuid);

--Applying indexing on recognising_organisation_uuid as it is foriegn key in Status_History Table.
Create INDEX IF NOT EXISTS idx_status_history_recognising_organisation_uuid ON ro_owner.status_history (recognising_organisation_uuid);

----Applying indexing on source_recognising_organisation_uuid as it is foriegn key in Linked Organisation Table.
Create INDEX IF NOT EXISTS idx_linked_recognising_organisation_source_recognising_organisation_uuid ON ro_owner.linked_recognising_organisation (source_recognising_organisation_uuid);

--Applying indexing on target_recognising_organisation_uuid as it is foriegn key in Linked Organisation Table.
Create INDEX IF NOT EXISTS idx_linked_recognising_organisation_target_recognising_organisation_uuid ON ro_owner.linked_recognising_organisation (target_recognising_organisation_uuid);


----Applying indexing on country_uuid as it is foriegn key in Territory Table.
Create INDEX IF NOT EXISTS idx_territory_country_uuid ON ro_owner.territory (country_uuid);