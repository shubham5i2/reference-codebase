--- Delete test taker 
DELETE FROM ro_owner.sector_type WHERE sector_type_uuid='e8795152-efb4-494d-807e-dfd4893133fa';

--- Update "Recruiter or Education Agent" to "Education Agent"
UPDATE ro_owner.sector_type SET  sector_type = 'Education Agent' WHERE sector_type_uuid= 'f3192aae-9979-4c5d-bf57-4126d4fbfad7';

--- Update "Agent" to "Recruiter Agent"
UPDATE ro_owner.sector_type SET  sector_type = 'Recruiter Agent' WHERE sector_type_uuid= 'c4dd65e0-ca6d-433f-9460-7838e7664640';