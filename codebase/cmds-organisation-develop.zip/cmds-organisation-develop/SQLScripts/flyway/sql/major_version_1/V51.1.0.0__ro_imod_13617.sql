UPDATE ro_owner.partner SET partner_name='Cambridge' WHERE partner_uuid='6889087c-d81d-4461-a734-477a056c7d89';

UPDATE ro_owner.partner SET partner_name='IELTS USA' WHERE partner_uuid='8bf20f44-b5d4-4234-8f8d-93d5045d0588';
