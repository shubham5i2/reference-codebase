ALTER TABLE ro_owner.recognising_organisation ADD COLUMN IF NOT EXISTS crm_system VARCHAR(50);
ALTER TABLE ro_owner.contact ADD COLUMN IF NOT EXISTS title VARCHAR(20);
ALTER TABLE ro_owner.contact ADD COLUMN IF NOT EXISTS job_title VARCHAR(100);
ALTER TABLE ro_owner.recognising_organisation ALTER COLUMN website_url TYPE varchar(250);