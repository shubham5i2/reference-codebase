/*** Creating table to store Partner**/	
CREATE TABLE IF NOT EXISTS ro_owner.partner (
    partner_uuid UUID NOT NULL,
    partner_code VARCHAR(20) NOT NULL UNIQUE,
    partner_name VARCHAR(50) NOT NULL,
    effective_from_date DATE NOT NULL,
    effective_to_date DATE NOT NULL DEFAULT '2099-12-31',
    created_by VARCHAR(36) NOT NULL ,
    created_datetime TIMESTAMPTZ NOT NULL DEFAULT current_timestamp,
    updated_by VARCHAR(36),
    updated_datetime TIMESTAMPTZ,
    concurrency_version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT pk_partner PRIMARY KEY (partner_uuid)
);