-- Create ENUM Type for location types
DO $$ BEGIN
	CREATE TYPE ro_owner.location_type AS ENUM
    ('GLOBAL', 'PARTNER', 'REGION', 'COUNTRY', 'TEST_CENTRE', 'VIRTUAL_BUILDING', 'PHYSICAL_BUILDING', 'ROOM');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Create ENUM Type for location status
DO $$ BEGIN
	CREATE TYPE ro_owner.location_status AS ENUM
    ('ACTIVE', 'SUSPENDED', 'INACTIVE');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

CREATE TABLE IF NOT EXISTS ro_owner.location (
	location_uuid uuid NOT NULL,
	parent_location_uuid uuid NULL,
	status ro_owner.location_status NOT null ,
	location_type ro_owner.location_type NOT null ,
	partner_code varchar(20) NOT NULL,
	test_centre_location_uuid uuid NULL,
	location_name varchar(100) NOT NULL,
	created_datetime timestamptz NOT NULL,
	updated_datetime timestamptz NOT NULL,
	concurrency_version int4 NOT NULL,
	test_centre_number varchar(5) NULL DEFAULT NULL::character varying,
	CONSTRAINT pk_location PRIMARY KEY (location_uuid)
);
