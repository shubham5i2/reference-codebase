-- Type Creation for Product Status Type
DO $$ BEGIN
	CREATE TYPE ro_owner.product_status_type AS ENUM
   	('DRAFT', 'PUBLISHED');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

--Type Creation for Format Type
DO $$ BEGIN
	CREATE TYPE ro_owner.format_type AS ENUM
   	('CD', 'PB');
	EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Product Table Creation in Staff Management
CREATE TABLE IF NOT EXISTS ro_owner.product (
	product_uuid UUID ,
	parent_product_uuid UUID NULL,
	module_type_uuid UUID NULL,
	legacy_product_id varchar(24) NULL,
	product_name VARCHAR(100) NOT NULL,
	product_description varchar(1000) NULL,
	bookable BOOLEAN NOT NULL,
	component ro_owner.component_type NULL,
	duration INTEGER NULL,
	format ro_owner.format_type NULL,
	approval_required BOOLEAN NOT NULL,
	available_from_date DATE NOT NULL,
	available_to_date DATE NOT NULL,
	product_status ro_owner.product_status_type NOT NULL,
	created_by varchar(36) NOT NULL,
	created_datetime timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_by varchar(36) NULL,
	updated_datetime timestamptz NULL,
	concurrency_version INTEGER NOT NULL,
	CONSTRAINT pk_product PRIMARY KEY (product_uuid),
	CONSTRAINT fk_01_product_product FOREIGN KEY (parent_product_uuid) REFERENCES ro_owner.product (product_uuid)
);