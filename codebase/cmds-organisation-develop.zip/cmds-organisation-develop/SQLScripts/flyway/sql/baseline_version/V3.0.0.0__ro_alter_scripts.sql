
ALTER TABLE ro_owner.recognising_organisation ADD COLUMN ielts_display_flag BOOLEAN DEFAULT FALSE;
ALTER TABLE ro_owner.recognising_organisation ADD COLUMN ors_display_flag BOOLEAN DEFAULT FALSE;
ALTER TABLE ro_owner.recognising_organisation drop column parent_recognising_organisation_uuid;
ALTER TABLE ro_owner.recognising_organisation drop column replaced_by_recognising_organisation_uuid;
ALTER TABLE ro_owner.recognising_organisation ADD COLUMN result_available_for_years INTEGER DEFAULT 2;
