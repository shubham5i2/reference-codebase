--DML scripts for module type
INSERT INTO ro_owner.module_type (module_type_uuid, module_type, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('7a28a632-8728-4f74-882e-72e9d3649763',
        'AC',
        'Academic',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(module_type_uuid) DO NOTHING;


INSERT INTO ro_owner.module_type (module_type_uuid, module_type, description, effective_from_date, created_by, updated_by,updated_datetime)
VALUES ('0ae29abe-5862-4c48-92e4-00d7eba376a2',
        'GT',
        'General Training',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(module_type_uuid) DO NOTHING;

