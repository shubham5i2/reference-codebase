--DML scripts for note type
INSERT INTO ro_owner.note_type(
	note_type_uuid, note_type, description, effective_from_date, created_by, updated_by, updated_datetime)
	VALUES ('f9aa5ac1-da99-40f2-82e7-a5fea9e45979','Internal', NULL, '2020-07-01', 'Operations User',NULL,NULL)  ON CONFLICT(note_type_uuid) DO NOTHING;
INSERT INTO ro_owner.note_type(
    note_type_uuid, note_type, description, effective_from_date, created_by, updated_by, updated_datetime)
    VALUES ('21dd3e30-3253-49f4-9ef9-a2071d9bea24','External', NULL, '2020-07-01', 'Operations User',NULL,NULL)  ON CONFLICT(note_type_uuid) DO NOTHING;