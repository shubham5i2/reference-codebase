--DML scripts for address type
INSERT INTO ro_owner.address_type (address_type_uuid, address_type_name, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('c96fbd08-a302-4aa2-a594-13cdb33bb380',
        'Main',
        NULL,
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(address_type_uuid) DO NOTHING;


INSERT INTO ro_owner.address_type (address_type_uuid, address_type_name, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('d13761e9-c134-4f80-a0a8-239a683a9c00',
        'Delivery',
        NULL,
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(address_type_uuid) DO NOTHING;


INSERT INTO ro_owner.address_type (address_type_uuid, address_type_name, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('cb3c2358-a932-4d12-90ab-e4c94fbf9fe3',
        'Postal',
        NULL,
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(address_type_uuid) DO NOTHING;


INSERT INTO ro_owner.address_type (address_type_uuid, address_type_name, description, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('8b563242-dbbe-4625-b727-c3aba52a8b96',
        'Physical',
        NULL,
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(address_type_uuid) DO NOTHING;

