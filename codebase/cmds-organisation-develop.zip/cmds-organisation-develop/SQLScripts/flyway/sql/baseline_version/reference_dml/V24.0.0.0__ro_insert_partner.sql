--DML scripts for partner
INSERT INTO ro_owner.partner (partner_uuid, partner_code, partner_name, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('c39eb8a4-6127-4236-8363-deae1c01dd83',
        'GLOBAL_IELTS',
        'Global IELTS',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(partner_uuid) DO NOTHING;


INSERT INTO ro_owner.partner (partner_uuid, partner_code, partner_name, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('8a37c2fc-edd2-44c2-960b-d8de98dade28',
        'BC',
        'British Council',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(partner_uuid) DO NOTHING;


INSERT INTO ro_owner.partner (partner_uuid, partner_code, partner_name, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('945a233a-6779-43a1-be88-dc97b9b36509',
        'IDP',
        'IDP',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(partner_uuid) DO NOTHING;


INSERT INTO ro_owner.partner (partner_uuid, partner_code, partner_name, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('6889087c-d81d-4461-a734-477a056c7d89',
        'CA',
        'UCLES',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(partner_uuid) DO NOTHING;


INSERT INTO ro_owner.partner (partner_uuid, partner_code, partner_name, effective_from_date, created_by, updated_by, updated_datetime)
VALUES ('8bf20f44-b5d4-4234-8f8d-93d5045d0588',
        'IELTS_USA',
        'CEII',
        '2020-07-01',
        'Operations User',
        NULL,
        NULL) ON CONFLICT(partner_uuid) DO NOTHING;