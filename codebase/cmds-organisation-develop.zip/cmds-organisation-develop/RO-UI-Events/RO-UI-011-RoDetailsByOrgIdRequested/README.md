
# roui011rodetailsbyorgidrequested RoDetailsByOrgIdRequested Event
roui011rodetailsbyorgidrequested RoDetailsByOrgIdRequested Event




Event published by _____


Put description here


| Code | Description |
| ---- | ----------- |
| 202 | Accepted |



| Name | Type | Description | Required |
| ---- | ---- | ----------- | -------- |


| Name | Type | Description | Required |
| ---- | ---- | ----------- | -------- |
