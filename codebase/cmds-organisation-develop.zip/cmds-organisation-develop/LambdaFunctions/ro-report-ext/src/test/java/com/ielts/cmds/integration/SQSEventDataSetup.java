package com.ielts.cmds.integration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.model.BulkRORecognisedProductUpdateMapV1;
import com.ielts.cmds.integration.model.BulkRORecognisedProductUpdateMessageV1;
import com.ielts.cmds.integration.model.BulkRORecognisedProductsUpdateDataV1;
import com.ielts.cmds.integration.model.LoadRODataV1;
import com.ielts.cmds.integration.model.LoadROHierarchyDataV1;
import com.ielts.cmds.integration.model.LoadROHierarchyMapV1;
import com.ielts.cmds.integration.model.LoadROHierarchyMessageV1;
import com.ielts.cmds.integration.model.LoadROMapV1;
import com.ielts.cmds.integration.model.LoadROMessageV1;
import org.joda.time.DateTime;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class SQSEventDataSetup {

    static final ObjectMapper mapper = new ObjectMapper();

    public static String getEventRequest() throws JsonProcessingException {
        return mapper.writeValueAsString(getEvent());
    }

    public static BaseEvent<BaseHeader> getEvent() throws JsonProcessingException {

        final BaseHeader header = populateEventHeader();
        final LoadROMessageV1 bodyList = populateEventBody();
        final String body = mapper.writeValueAsString(bodyList);
        final BaseEventErrors errors = null;
        final BaseEvent<BaseHeader> event = new BaseEvent<>(header, body, errors, null);
        return event;
    }

    public static LoadROMessageV1 populateEventBody() {
        LoadROMessageV1 loadROMessageV1 = new LoadROMessageV1();
        LoadROMapV1 msg = new LoadROMapV1();
        LoadRODataV1 value = populateLoadROData();
        msg.put("1", value);
        loadROMessageV1.setMsg(msg);
        return loadROMessageV1;
    }

    public static LoadRODataV1 populateLoadROData() {
        LoadRODataV1 loadRODataV1 = new LoadRODataV1();
        loadRODataV1.setRowNumber("1");
        loadRODataV1.setName("Sinister University");
        loadRODataV1.setRecognisingOrganisationUuid("3e81e94b-8b6a-42b5-970c-b141f9d195a4");
        loadRODataV1.setWebsiteUrl("wwww.siniste.org");
        loadRODataV1.setTelephoneNo("98 91883");
        loadRODataV1.setAcMinimumScoreValue("7.5");
        loadRODataV1.setAddressLine1("22, Hawthorne Heights");
        loadRODataV1.setAddressLine2("Second Avenue");
        loadRODataV1.setCity("Cambridge");
        loadRODataV1.setPostalCode("CB2 8EA");
        loadRODataV1.setVisibleOnIelts("true");
        loadRODataV1.setSelectableOnOrs("false");
        return loadRODataV1;
    }

    public static BaseHeader populateEventHeader() {
        BaseHeader baseHeader = new BaseHeader();
        baseHeader.setTransactionId(UUID.fromString("3e81e94b-8b6a-42b5-970c-b141f9d195a4"));
        baseHeader.setCorrelationId(UUID.fromString("123e4567-e89b-12d3-a456-426614174000"));
        baseHeader.setPartnerCode(null);
        baseHeader.setEventName("ROProcess");
        baseHeader.setEventDateTime(LocalDateTime.of(2020, 1, 1, 0, 0));
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put("roDataFile", "test.csv");
        eventContext.put("mode", "create");
        baseHeader.setEventContext(eventContext);
        return baseHeader;
    }

    public static BaseEvent<BaseHeader> getHierarchyEvent() throws JsonProcessingException {

        final BaseHeader header = populateEventHeader();
        header.getEventContext().put("mode", "update");
        final LoadROHierarchyMessageV1 bodyList = populateHierarchyEventBody();
        final String body = mapper.writeValueAsString(bodyList);
        final BaseEventErrors errors = null;
        final BaseEvent<BaseHeader> event = new BaseEvent<>(header, body, errors, null);
        return event;
    }

    public static LoadROHierarchyMessageV1 populateHierarchyEventBody() {
        LoadROHierarchyMessageV1 loadROHierarchyMessageV1 = new LoadROHierarchyMessageV1();
        LoadROHierarchyMapV1 msg = new LoadROHierarchyMapV1();
        LoadROHierarchyDataV1 value = populateLoadROHierarchyData();
        msg.put("1", value);
        loadROHierarchyMessageV1.setMsg(msg);
        return loadROHierarchyMessageV1;
    }

    public static LoadROHierarchyDataV1 populateLoadROHierarchyData() {
        LoadROHierarchyDataV1 loadROHierarchyDataV1 = new LoadROHierarchyDataV1();
        loadROHierarchyDataV1.setRowNumber("1");
        loadROHierarchyDataV1.setRecognisingOrganisationUuid(
                "3e81e94b-8b6a-42b5-970c-b141f9d195a4");
        loadROHierarchyDataV1.setOrganisationId("123");
        loadROHierarchyDataV1.setParentOrganisationId("456");
        loadROHierarchyDataV1.setResultsDeliveryOrgIds("789|456");
        return loadROHierarchyDataV1;
    }

    public static BaseEvent<BaseHeader> getProductUpdateEvent() throws JsonProcessingException {

        final BaseHeader header = populateEventHeader();
        header.getEventContext().put("mode", "updateProduct");
        final BulkRORecognisedProductUpdateMessageV1 bodyList = populateProductUpdateEventBody();
        final String body = mapper.writeValueAsString(bodyList);
        final BaseEventErrors errors = null;
        final BaseEvent<BaseHeader> event = new BaseEvent<>(header, body, errors, null);
        return event;
    }

    public static BulkRORecognisedProductUpdateMessageV1 populateProductUpdateEventBody() {
        BulkRORecognisedProductUpdateMessageV1 messageV1 =
                new BulkRORecognisedProductUpdateMessageV1();
        BulkRORecognisedProductUpdateMapV1 msg = new BulkRORecognisedProductUpdateMapV1();
        BulkRORecognisedProductsUpdateDataV1 value = populateBulkROProductUpdateData();
        msg.put("1", value);
        messageV1.setMsg(msg);
        return messageV1;
    }

    public static BulkRORecognisedProductsUpdateDataV1 populateBulkROProductUpdateData() {
        BulkRORecognisedProductsUpdateDataV1 bulkROProductUpdateDataV1 =
                new BulkRORecognisedProductsUpdateDataV1();
        bulkROProductUpdateDataV1.setRowNumber("1");
        bulkROProductUpdateDataV1.setRecognisingOrganisationUuid(
                "3e81e94b-8b6a-42b5-970c-b141f9d195a4");
        bulkROProductUpdateDataV1.setOrganisationId("123");
        bulkROProductUpdateDataV1.setRecognisedProduct("IOC");
        return bulkROProductUpdateDataV1;
    }
}
