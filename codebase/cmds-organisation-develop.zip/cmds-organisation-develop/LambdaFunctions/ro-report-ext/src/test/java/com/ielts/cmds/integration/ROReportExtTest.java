package com.ielts.cmds.integration;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.amazonaws.services.lambda.runtime.events.SQSEvent.SQSMessage;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.config.LambdaConfig;
import com.ielts.cmds.integration.model.BulkRORecognisedProductsUpdateDataV1;
import com.ielts.cmds.integration.model.LoadRODataV1;
import com.ielts.cmds.integration.model.LoadROHierarchyDataV1;
import com.ielts.cmds.integration.util.ROReportExtConstants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class ROReportExtTest {

    @Mock private Context context;

    @Mock private LambdaConfig lambdaConfig;

    @Spy private ROReportExt roReportExt;

    @Spy private ObjectMapper objectMapper;

    @Mock private AmazonS3Client s3Client;

    @Mock private ObjectWriter bodyObjectWriter;

    @Mock private ObjectWriter headerObjectWriter;

    private SQSEvent event, hierarchyEvent, productUpdateEvent;
    private SQSMessage message, hierarchyMessage, productUpdateMessage;

    private TypeReference<BaseEvent<BaseHeader>> typeRef;

    public static final String TEST_BUCKET_NAME = "test-bucket";

    public static final String FILE_NAME = "test_report_"+SQSEventDataSetup.populateEventHeader().getTransactionId()+".csv";

    @BeforeEach
    void setup() throws JsonProcessingException {
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        objectMapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        objectMapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);

        typeRef = new TypeReference<BaseEvent<BaseHeader>>() {};
        String eventBody = SQSEventDataSetup.getEventRequest();
        message = new SQSMessage();
        message.setBody(eventBody);
        List<SQSMessage> records = new ArrayList<>();
        records.add(message);
        event = new SQSEvent();
        event.setRecords(records);

        BaseEvent<BaseHeader> baseEvent = SQSEventDataSetup.getHierarchyEvent();
        String loadHierarchyEventBody = objectMapper.writeValueAsString(baseEvent);
        hierarchyMessage = new SQSMessage();
        hierarchyMessage.setBody(loadHierarchyEventBody);
        List<SQSMessage> records1 = new ArrayList<>();
        records1.add(hierarchyMessage);
        hierarchyEvent = new SQSEvent();
        hierarchyEvent.setRecords(records1);

        BaseEvent<BaseHeader> event = SQSEventDataSetup.getProductUpdateEvent();
        String bulkProductUpdateEventBody = objectMapper.writeValueAsString(event);
        productUpdateMessage = new SQSMessage();
        productUpdateMessage.setBody(bulkProductUpdateEventBody);
        List<SQSMessage> records2 = new ArrayList<>();
        records2.add(productUpdateMessage);
        productUpdateEvent = new SQSEvent();
        productUpdateEvent.setRecords(records2);

        ReflectionTestUtils.setField(roReportExt, "mapper", objectMapper);

    }

    @Test
    void handleRequest_NoException() throws IOException {
        BaseEvent<BaseHeader> baseEvent = SQSEventDataSetup.getEvent();
        doNothing().when(roReportExt).createReport(baseEvent);
        assertDoesNotThrow(() -> roReportExt.handleRequest(event, context));
        verify(roReportExt)
                .initializeLogger(baseEvent.getEventHeader().getTransactionId(), context);
        verify(roReportExt).validateMessage(event.getRecords().get(0).getBody(), objectMapper);
    }

    @Test
    void handleRequestWithUpdateMode_NoException() throws IOException {
        BaseEvent<BaseHeader> baseEvent = SQSEventDataSetup.getHierarchyEvent();
        doNothing().when(roReportExt).createReport(baseEvent);
        assertDoesNotThrow(() -> roReportExt.handleRequest(hierarchyEvent, context));
        verify(roReportExt)
                .initializeLogger(baseEvent.getEventHeader().getTransactionId(), context);
        verify(roReportExt)
                .validateMessage(hierarchyEvent.getRecords().get(0).getBody(), objectMapper);
    }


    @Test
    void handleRequestWithUpdateProductMode_NoException() throws IOException {
        BaseEvent<BaseHeader> baseEvent = SQSEventDataSetup.getProductUpdateEvent();
        doNothing().when(roReportExt).createReport(baseEvent);
        assertDoesNotThrow(() -> roReportExt.handleRequest(productUpdateEvent, context));
        verify(roReportExt)
                .initializeLogger(baseEvent.getEventHeader().getTransactionId(), context);
        verify(roReportExt)
                .validateMessage(productUpdateEvent.getRecords().get(0).getBody(), objectMapper);
    }

    @Test
    void handleRequest_Exception() throws IOException {
        BaseEvent<BaseHeader> baseEvent = SQSEventDataSetup.getEvent();
        doThrow(IOException.class).when(roReportExt).createReport(baseEvent);
        assertDoesNotThrow(() -> roReportExt.handleRequest(event, context));
        verify(roReportExt)
                .initializeLogger(baseEvent.getEventHeader().getTransactionId(), context);
        verify(roReportExt).validateMessage(event.getRecords().get(0).getBody(), objectMapper);
    }

    @Test
    void createReport_FileExists_NoException() throws IOException {
        doReturn(lambdaConfig).when(roReportExt).createLambdaConfig();
        doReturn(s3Client).when(lambdaConfig).getAmazonS3Client();
        doReturn(FILE_NAME).when(roReportExt).getFileName(any(BaseHeader.class));
        doReturn(FILE_NAME).when(roReportExt).getFileWithPath(FILE_NAME);
        doReturn(TEST_BUCKET_NAME)
                .when(lambdaConfig)
                .getValueFromEnvironmentKey(ROReportExtConstants.BUCKET_NAME);
        doReturn(true).when(s3Client).doesObjectExist(TEST_BUCKET_NAME, FILE_NAME);
        doReturn(bodyObjectWriter).when(lambdaConfig).getObjectWriter(false, LoadRODataV1.class);
        doNothing()
                .when(bodyObjectWriter)
                .writeValue(any(BufferedWriter.class), eq(SQSEventDataSetup.populateLoadROData()));
        doReturn(mock(PutObjectResult.class))
                .when(s3Client)
                .putObject(TEST_BUCKET_NAME, FILE_NAME, new File(FILE_NAME));
        assertDoesNotThrow(() -> roReportExt.createReport(SQSEventDataSetup.getEvent()));
        verify(roReportExt).createLambdaConfig();
        verify(lambdaConfig).getAmazonS3Client();
    }

    @Test
    void createReportForHierarchyData_FileExists_NoException() throws IOException {
        doReturn(lambdaConfig).when(roReportExt).createLambdaConfig();
        doReturn(s3Client).when(lambdaConfig).getAmazonS3Client();
        doReturn(FILE_NAME).when(roReportExt).getFileName(any(BaseHeader.class));
        doReturn(FILE_NAME).when(roReportExt).getFileWithPath(FILE_NAME);
        doReturn(TEST_BUCKET_NAME)
                .when(lambdaConfig)
                .getValueFromEnvironmentKey(ROReportExtConstants.BUCKET_NAME);
        doReturn(true).when(s3Client).doesObjectExist(TEST_BUCKET_NAME, FILE_NAME);
        doReturn(bodyObjectWriter)
                .when(lambdaConfig)
                .getObjectWriter(false, LoadROHierarchyDataV1.class);
        doNothing()
                .when(bodyObjectWriter)
                .writeValue(
                        any(BufferedWriter.class),
                        eq(SQSEventDataSetup.populateLoadROHierarchyData()));
        doReturn(mock(PutObjectResult.class))
                .when(s3Client)
                .putObject(TEST_BUCKET_NAME, FILE_NAME, new File(FILE_NAME));
        assertDoesNotThrow(() -> roReportExt.createReport(SQSEventDataSetup.getHierarchyEvent()));
        verify(roReportExt).createLambdaConfig();
        verify(lambdaConfig).getAmazonS3Client();
    }

    @Test
    void createReportForProductUpdateData_FileExists_NoException() throws IOException {
        doReturn(lambdaConfig).when(roReportExt).createLambdaConfig();
        doReturn(s3Client).when(lambdaConfig).getAmazonS3Client();
        doReturn(FILE_NAME).when(roReportExt).getFileName(any(BaseHeader.class));
        doReturn(FILE_NAME).when(roReportExt).getFileWithPath(FILE_NAME);
        doReturn(TEST_BUCKET_NAME)
                .when(lambdaConfig)
                .getValueFromEnvironmentKey(ROReportExtConstants.BUCKET_NAME);
        doReturn(true).when(s3Client).doesObjectExist(TEST_BUCKET_NAME, FILE_NAME);
        doReturn(bodyObjectWriter)
                .when(lambdaConfig)
                .getObjectWriter(false, BulkRORecognisedProductsUpdateDataV1.class);
        doNothing()
                .when(bodyObjectWriter)
                .writeValue(
                        any(BufferedWriter.class),
                        eq(SQSEventDataSetup.populateBulkROProductUpdateData()));
        doReturn(mock(PutObjectResult.class))
                .when(s3Client)
                .putObject(TEST_BUCKET_NAME, FILE_NAME, new File(FILE_NAME));
        assertDoesNotThrow(
                () -> roReportExt.createReport(SQSEventDataSetup.getProductUpdateEvent()));
        verify(roReportExt).createLambdaConfig();
        verify(lambdaConfig).getAmazonS3Client();
    }

    @Test
    void createReport_FileExists_Exception() throws IOException {
        doReturn(lambdaConfig).when(roReportExt).createLambdaConfig();
        doReturn(s3Client).when(lambdaConfig).getAmazonS3Client();
        doReturn(FILE_NAME).when(roReportExt).getFileName(any(BaseHeader.class));
        doReturn(FILE_NAME).when(roReportExt).getFileWithPath(FILE_NAME);
        doReturn(TEST_BUCKET_NAME)
                .when(lambdaConfig)
                .getValueFromEnvironmentKey(ROReportExtConstants.BUCKET_NAME);
        doReturn(true).when(s3Client).doesObjectExist(TEST_BUCKET_NAME, FILE_NAME);
        doReturn(bodyObjectWriter).when(lambdaConfig).getObjectWriter(false, LoadRODataV1.class);
        doThrow(JsonProcessingException.class)
                .when(bodyObjectWriter)
                .writeValue(any(BufferedWriter.class), eq(SQSEventDataSetup.populateLoadROData()));
        assertDoesNotThrow(() -> roReportExt.createReport(SQSEventDataSetup.getEvent()));
    }

    @Test
    void createReportForHierarchyData_FileExists_Exception() throws IOException {
        doReturn(lambdaConfig).when(roReportExt).createLambdaConfig();
        doReturn(s3Client).when(lambdaConfig).getAmazonS3Client();
        doReturn(FILE_NAME).when(roReportExt).getFileName(any(BaseHeader.class));
        doReturn(FILE_NAME).when(roReportExt).getFileWithPath(FILE_NAME);
        doReturn(TEST_BUCKET_NAME)
                .when(lambdaConfig)
                .getValueFromEnvironmentKey(ROReportExtConstants.BUCKET_NAME);
        doReturn(true).when(s3Client).doesObjectExist(TEST_BUCKET_NAME, FILE_NAME);
        doReturn(bodyObjectWriter)
                .when(lambdaConfig)
                .getObjectWriter(false, LoadROHierarchyDataV1.class);
        doThrow(JsonProcessingException.class)
                .when(bodyObjectWriter)
                .writeValue(
                        any(BufferedWriter.class),
                        eq(SQSEventDataSetup.populateLoadROHierarchyData()));
        assertDoesNotThrow(() -> roReportExt.createReport(SQSEventDataSetup.getHierarchyEvent()));
    }

    @Test
    void createReportForProductUpdateData_FileExists_Exception() throws IOException {
        doReturn(lambdaConfig).when(roReportExt).createLambdaConfig();
        doReturn(s3Client).when(lambdaConfig).getAmazonS3Client();
        doReturn(FILE_NAME).when(roReportExt).getFileName(any(BaseHeader.class));
        doReturn(FILE_NAME).when(roReportExt).getFileWithPath(FILE_NAME);
        doReturn(TEST_BUCKET_NAME)
                .when(lambdaConfig)
                .getValueFromEnvironmentKey(ROReportExtConstants.BUCKET_NAME);
        doReturn(true).when(s3Client).doesObjectExist(TEST_BUCKET_NAME, FILE_NAME);
        doReturn(bodyObjectWriter)
                .when(lambdaConfig)
                .getObjectWriter(false, BulkRORecognisedProductsUpdateDataV1.class);
        doThrow(JsonProcessingException.class)
                .when(bodyObjectWriter)
                .writeValue(
                        any(BufferedWriter.class),
                        eq(SQSEventDataSetup.populateBulkROProductUpdateData()));
        assertDoesNotThrow(
                () -> roReportExt.createReport(SQSEventDataSetup.getProductUpdateEvent()));
    }

    @Test
    void createReport_FileNotExists_NoException() throws IOException {
        doReturn(lambdaConfig).when(roReportExt).createLambdaConfig();
        doReturn(s3Client).when(lambdaConfig).getAmazonS3Client();
        doReturn(FILE_NAME).when(roReportExt).getFileName(any(BaseHeader.class));
        doReturn(FILE_NAME).when(roReportExt).getFileWithPath(FILE_NAME);
        doReturn(TEST_BUCKET_NAME)
                .when(lambdaConfig)
                .getValueFromEnvironmentKey(ROReportExtConstants.BUCKET_NAME);
        doReturn(false).when(s3Client).doesObjectExist(TEST_BUCKET_NAME, FILE_NAME);
        doReturn(headerObjectWriter).when(lambdaConfig).getObjectWriter(true, LoadRODataV1.class);
        doNothing().when(headerObjectWriter).writeValue(any(BufferedWriter.class), eq(null));
        doReturn(bodyObjectWriter).when(lambdaConfig).getObjectWriter(false, LoadRODataV1.class);
        doNothing()
                .when(bodyObjectWriter)
                .writeValue(any(BufferedWriter.class), eq(SQSEventDataSetup.populateLoadROData()));
        doReturn(mock(PutObjectResult.class))
                .when(s3Client)
                .putObject(TEST_BUCKET_NAME, FILE_NAME, new File(FILE_NAME));
        assertDoesNotThrow(() -> roReportExt.createReport(SQSEventDataSetup.getEvent()));
        verify(roReportExt).createLambdaConfig();
        verify(lambdaConfig).getAmazonS3Client();
    }

    @Test
    void createReportForHierarchyData_FileNotExists_NoException() throws IOException {
        doReturn(lambdaConfig).when(roReportExt).createLambdaConfig();
        doReturn(s3Client).when(lambdaConfig).getAmazonS3Client();
        doReturn(FILE_NAME).when(roReportExt).getFileName(any(BaseHeader.class));
        doReturn(FILE_NAME).when(roReportExt).getFileWithPath(FILE_NAME);
        doReturn(TEST_BUCKET_NAME)
                .when(lambdaConfig)
                .getValueFromEnvironmentKey(ROReportExtConstants.BUCKET_NAME);
        doReturn(false).when(s3Client).doesObjectExist(TEST_BUCKET_NAME, FILE_NAME);
        doReturn(headerObjectWriter)
                .when(lambdaConfig)
                .getObjectWriter(true, LoadROHierarchyDataV1.class);
        doNothing().when(headerObjectWriter).writeValue(any(BufferedWriter.class), eq(null));
        doReturn(bodyObjectWriter)
                .when(lambdaConfig)
                .getObjectWriter(false, LoadROHierarchyDataV1.class);
        doNothing()
                .when(bodyObjectWriter)
                .writeValue(
                        any(BufferedWriter.class),
                        eq(SQSEventDataSetup.populateLoadROHierarchyData()));
        doReturn(mock(PutObjectResult.class))
                .when(s3Client)
                .putObject(TEST_BUCKET_NAME, FILE_NAME, new File(FILE_NAME));
        assertDoesNotThrow(() -> roReportExt.createReport(SQSEventDataSetup.getHierarchyEvent()));
        verify(roReportExt).createLambdaConfig();
        verify(lambdaConfig).getAmazonS3Client();
    }

    @Test
    void createReportForProductUpdateData_FileNotExists_NoException() throws IOException {
        doReturn(lambdaConfig).when(roReportExt).createLambdaConfig();
        doReturn(s3Client).when(lambdaConfig).getAmazonS3Client();
        doReturn(FILE_NAME).when(roReportExt).getFileName(any(BaseHeader.class));
        doReturn(FILE_NAME).when(roReportExt).getFileWithPath(FILE_NAME);
        doReturn(TEST_BUCKET_NAME)
                .when(lambdaConfig)
                .getValueFromEnvironmentKey(ROReportExtConstants.BUCKET_NAME);
        doReturn(false).when(s3Client).doesObjectExist(TEST_BUCKET_NAME, FILE_NAME);
        doReturn(headerObjectWriter)
                .when(lambdaConfig)
                .getObjectWriter(true, BulkRORecognisedProductsUpdateDataV1.class);
        doNothing().when(headerObjectWriter).writeValue(any(BufferedWriter.class), eq(null));
        doReturn(bodyObjectWriter)
                .when(lambdaConfig)
                .getObjectWriter(false, BulkRORecognisedProductsUpdateDataV1.class);
        doNothing()
                .when(bodyObjectWriter)
                .writeValue(
                        any(BufferedWriter.class),
                        eq(SQSEventDataSetup.populateBulkROProductUpdateData()));
        doReturn(mock(PutObjectResult.class))
                .when(s3Client)
                .putObject(TEST_BUCKET_NAME, FILE_NAME, new File(FILE_NAME));
        assertDoesNotThrow(
                () -> roReportExt.createReport(SQSEventDataSetup.getProductUpdateEvent()));
        verify(roReportExt).createLambdaConfig();
        verify(lambdaConfig).getAmazonS3Client();
    }

    @Test
    void createReport_FileNotExists_Exception() throws IOException {
        doReturn(lambdaConfig).when(roReportExt).createLambdaConfig();
        doReturn(s3Client).when(lambdaConfig).getAmazonS3Client();
        doReturn(FILE_NAME).when(roReportExt).getFileName(any(BaseHeader.class));
        doReturn(FILE_NAME).when(roReportExt).getFileWithPath(FILE_NAME);
        doReturn(TEST_BUCKET_NAME)
                .when(lambdaConfig)
                .getValueFromEnvironmentKey(ROReportExtConstants.BUCKET_NAME);
        doReturn(false).when(s3Client).doesObjectExist(TEST_BUCKET_NAME, FILE_NAME);
        doReturn(headerObjectWriter).when(lambdaConfig).getObjectWriter(true, LoadRODataV1.class);
        doNothing().when(headerObjectWriter).writeValue(any(BufferedWriter.class), eq(null));
        doReturn(bodyObjectWriter).when(lambdaConfig).getObjectWriter(false, LoadRODataV1.class);
        doThrow(JsonProcessingException.class)
                .when(bodyObjectWriter)
                .writeValue(any(BufferedWriter.class), eq(SQSEventDataSetup.populateLoadROData()));
        assertDoesNotThrow(() -> roReportExt.createReport(SQSEventDataSetup.getEvent()));
    }

    @Test
    void getFileWithPath_ExpectWithPath() {

        String actual = roReportExt.getFileWithPath(FILE_NAME);
        String expected = ROReportExtConstants.BASE_PATH + FILE_NAME;
        assertEquals(expected, actual);
    }

    @Test
    void handleRequest_ExpectExceptionToBeThrown() throws JsonProcessingException {
        message.setBody("///");
        List<SQSMessage> records = new ArrayList<>();
        records.add(message);
        event.setRecords(records);
        assertDoesNotThrow(() -> roReportExt.handleRequest(event, context));
    }

    @Test
    void handleRequest_TransactionIdNull_ExpectExceptionToBeThrown()
            throws JsonProcessingException {
        String eventBody = SQSEventDataSetup.getEventRequest();
        BaseEvent<BaseHeader> baseEvent = objectMapper.readValue(eventBody, typeRef);
        baseEvent.getEventHeader().setTransactionId(null);
        eventBody = objectMapper.writeValueAsString(baseEvent);
        message.setBody(eventBody);
        List<SQSMessage> records = new ArrayList<>();
        records.add(message);
        event.setRecords(records);
        assertDoesNotThrow(() -> roReportExt.handleRequest(event, context));
    }

    @Test
    void handleRequest_EventContextNull_ExpectExceptionToBeThrown() throws JsonProcessingException {
        String eventBody = SQSEventDataSetup.getEventRequest();
        BaseEvent<BaseHeader> baseEvent = objectMapper.readValue(eventBody, typeRef);
        baseEvent.getEventHeader().setEventContext(null);
        eventBody = objectMapper.writeValueAsString(baseEvent);
        message.setBody(eventBody);
        List<SQSMessage> records = new ArrayList<>();
        records.add(message);
        event.setRecords(records);
        assertDoesNotThrow(() -> roReportExt.handleRequest(event, context));
    }

    @Test
    void handleRequest_EventContextKeyNotFound_ExpectExceptionToBeThrown()
            throws JsonProcessingException {
        String eventBody = SQSEventDataSetup.getEventRequest();
        BaseEvent<BaseHeader> baseEvent = objectMapper.readValue(eventBody, typeRef);
        baseEvent.getEventHeader().setEventContext(new HashMap<>());
        eventBody = objectMapper.writeValueAsString(baseEvent);
        message.setBody(eventBody);
        List<SQSMessage> records = new ArrayList<>();
        records.add(message);
        event.setRecords(records);
        assertDoesNotThrow(() -> roReportExt.handleRequest(event, context));
    }

    @Test
    void handleRequest_EventContextEmptyFilename_ExpectExceptionToBeThrown()
            throws JsonProcessingException {
        String eventBody = SQSEventDataSetup.getEventRequest();
        BaseEvent<BaseHeader> baseEvent = objectMapper.readValue(eventBody, typeRef);
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put("roDataFile", "");
        baseEvent.getEventHeader().setEventContext(eventContext);
        eventBody = objectMapper.writeValueAsString(baseEvent);
        message.setBody(eventBody);
        List<SQSMessage> records = new ArrayList<>();
        records.add(message);
        event.setRecords(records);
        assertDoesNotThrow(() -> roReportExt.handleRequest(event, context));
    }

    @Test
    void handleRequest_EventContextEmptyMode_ExpectExceptionToBeThrown()
            throws JsonProcessingException {
        String eventBody = SQSEventDataSetup.getEventRequest();
        BaseEvent<BaseHeader> baseEvent = objectMapper.readValue(eventBody, typeRef);
        Map<String, String> eventContext = new HashMap<>();
        eventContext.put("roDataFile", "test.csv");
        eventContext.put("mode", "");
        baseEvent.getEventHeader().setEventContext(eventContext);
        eventBody = objectMapper.writeValueAsString(baseEvent);
        message.setBody(eventBody);
        List<SQSMessage> records = new ArrayList<>();
        records.add(message);
        event.setRecords(records);
        doReturn(lambdaConfig).when(roReportExt).createLambdaConfig();
        doReturn(s3Client).when(lambdaConfig).getAmazonS3Client();
        doReturn(FILE_NAME).when(roReportExt).getFileName(any(BaseHeader.class));
        doReturn(FILE_NAME).when(roReportExt).getFileWithPath(FILE_NAME);
        doReturn(TEST_BUCKET_NAME)
                .when(lambdaConfig)
                .getValueFromEnvironmentKey(ROReportExtConstants.BUCKET_NAME);
        //doReturn(true).when(s3Client).doesObjectExist(TEST_BUCKET_NAME, FILE_NAME);
        assertDoesNotThrow(() -> roReportExt.handleRequest(event, context));
    }
}
