package com.ielts.cmds.integration.config;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.ielts.cmds.integration.model.BulkRORecognisedProductsUpdateDataV1;
import com.ielts.cmds.integration.model.LoadRODataV1;
import com.ielts.cmds.integration.model.LoadROHierarchyDataV1;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class LambdaConfigTest {

    @InjectMocks private LambdaConfig lambdaConfig;

    @Test
    void getObjectWriterTest() {
        ObjectWriter actual = lambdaConfig.getObjectWriter(true, LoadRODataV1.class);
        assertNotNull(actual);
        assertFalse(actual.isEnabled(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY));
    }

    @Test
    void getObjectWriterTestWithHierarchyData() {
        ObjectWriter actual = lambdaConfig.getObjectWriter(true, LoadROHierarchyDataV1.class);
        assertNotNull(actual);
        assertFalse(actual.isEnabled(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY));
    }

    @Test
    void getObjectWriterTestWithProductUpdateData() {
        ObjectWriter actual =
                lambdaConfig.getObjectWriter(true, BulkRORecognisedProductsUpdateDataV1.class);
        assertNotNull(actual);
        assertFalse(actual.isEnabled(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY));
    }
}
