package com.ielts.cmds.integration.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
public class BulkRORecognisedProductsUpdateDataV1 {

    @JsonProperty("rowNumber")
    private String rowNumber;

    @JsonProperty("recognising_organisation_uuid")
    private String recognisingOrganisationUuid;

    @JsonProperty("trf.organisation_id")
    private String organisationId;

    @JsonProperty("recognised_product")
    private String recognisedProduct;

    @JsonProperty("error_list")
    private String errorListString;
}
