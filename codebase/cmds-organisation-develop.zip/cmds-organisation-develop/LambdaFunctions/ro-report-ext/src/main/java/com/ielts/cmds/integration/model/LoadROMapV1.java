package com.ielts.cmds.integration.model;

import java.util.HashMap;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class LoadROMapV1 extends HashMap<String, LoadRODataV1> {
    /** */
    private static final long serialVersionUID = 1L;
}
