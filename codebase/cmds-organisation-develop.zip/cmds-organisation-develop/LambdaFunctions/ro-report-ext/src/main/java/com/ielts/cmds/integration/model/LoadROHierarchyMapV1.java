package com.ielts.cmds.integration.model;

import java.util.HashMap;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class LoadROHierarchyMapV1 extends HashMap<String, LoadROHierarchyDataV1> {
    /** */
    private static final long serialVersionUID = 2831110529648581238L;
}
