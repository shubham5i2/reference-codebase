package com.ielts.cmds.integration.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/** MessageV1 */
@Data
@NoArgsConstructor
@EqualsAndHashCode
public class LoadROMessageV1 {

    private LoadROMapV1 msg;
}
