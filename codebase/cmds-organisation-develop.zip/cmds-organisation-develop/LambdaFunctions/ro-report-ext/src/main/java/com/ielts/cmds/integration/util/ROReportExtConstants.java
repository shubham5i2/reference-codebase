package com.ielts.cmds.integration.util;

public final class ROReportExtConstants {

    private ROReportExtConstants() {}

    public static final String RO_REPORT_EXT_LAMBDA = "ROReportExtLambda";
    public static final String EXCEPTION_MESSAGE_PROCESSING = "Processing Issue";

    public static final String LOG_MESSAGE_TEMPLATE = "Exception message: {}";

    public static final String BASE_PATH = "/tmp/";
    public static final String BUCKET_NAME = "ro_data_bucket_name";
    public static final String RO = "RO";
    public static final String OPERATION_MODE = "mode";
    public static final String CREATE_MODE = "create";
    public static final String UPDATE_MODE = "update";
    public static final String HIERARCHY_MODE = "hierarchy";
}
