package com.ielts.cmds.integration.model;

import java.util.HashMap;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class BulkRORecognisedProductUpdateMapV1
        extends HashMap<String, BulkRORecognisedProductsUpdateDataV1> {
    /** */
    private static final long serialVersionUID = -8929807626427780571L;
}
