package com.ielts.cmds.integration;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.amazonaws.services.lambda.runtime.events.SQSEvent.SQSMessage;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;
import com.ielts.cmds.common.logger.util.CMDSLambdaLoggerUtil;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.integration.config.LambdaConfig;
import com.ielts.cmds.integration.model.BulkRORecognisedProductUpdateMessageV1;
import com.ielts.cmds.integration.model.BulkRORecognisedProductsUpdateDataV1;
import com.ielts.cmds.integration.model.LoadRODataV1;
import com.ielts.cmds.integration.model.LoadROHierarchyDataV1;
import com.ielts.cmds.integration.model.LoadROHierarchyMessageV1;
import com.ielts.cmds.integration.model.LoadROMessageV1;
import com.ielts.cmds.integration.util.ROReportExtConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.nio.file.NoSuchFileException;
import java.nio.file.DirectoryNotEmptyException;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;

import static com.ielts.cmds.integration.util.ROReportExtConstants.LOG_MESSAGE_TEMPLATE;


@Slf4j
public class ROReportExt {
    final CMDSLambdaLoggerUtil loggerUtil = new CMDSLambdaLoggerUtil();
    private final ObjectMapper mapper;

    public ROReportExt() {
        this.mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
    }

    /**
     * This method is invoked every time a message comes into the queue
     *
     * @param event
     * @param context
     * @throws IOException
     */
    public void handleRequest(SQSEvent event, Context context) throws IOException {

        BaseEvent<? extends BaseHeader> cmdsEvent = null;

        try {
            for (SQSMessage message : event.getRecords()) {
                String roMessage = message.getBody();
                log.debug("EventBody in lambda:{}", roMessage);
                cmdsEvent = validateMessage(roMessage, mapper);
                initializeLogger(cmdsEvent.getEventHeader().getTransactionId(), context);

                log.info(
                        "Event Received in {}:{} with metadata as {} and error as {}",
                        ROReportExtConstants.RO,
                        ROReportExtConstants.RO_REPORT_EXT_LAMBDA,
                        cmdsEvent.getEventHeader(),
                        cmdsEvent.getEventErrors());
                createReport(cmdsEvent);
                log.info(
                        "Event being Published from {}:{} with metadata as {} and error as {}",
                        ROReportExtConstants.RO,
                        ROReportExtConstants.RO_REPORT_EXT_LAMBDA,
                        cmdsEvent.getEventHeader(),
                        cmdsEvent.getEventErrors());
            }
        } catch (Exception e) {
            if (cmdsEvent != null) {
                generateAndLogErrorResponse(cmdsEvent.getEventHeader(), e);
            } else {
                log.error("Exception message {} ", e);
            }
        }
    }

    /**
     * This method is used to create a report from {@link BaseEvent}
     *
     * @param cmdsEvent
     * @throws IOException
     */
    void createReport(BaseEvent<? extends BaseHeader> cmdsEvent) throws IOException {

        LambdaConfig lambdaConfig = createLambdaConfig();
        AmazonS3 s3Client = lambdaConfig.getAmazonS3Client();
        String fileName = getFileName(cmdsEvent.getEventHeader());
        String bucketName =
                lambdaConfig.getValueFromEnvironmentKey(ROReportExtConstants.BUCKET_NAME);
        String filePath = getFileWithPath(fileName);
        File file = new File(filePath);
        try (BufferedWriter bufferedWriter =
                     Files.newBufferedWriter(
                             Paths.get(filePath),
                             StandardOpenOption.APPEND,
                             StandardOpenOption.CREATE)) {
            String mode = getOperationMode(cmdsEvent.getEventHeader());
            if (ROReportExtConstants.CREATE_MODE.equals(mode)) {
                loadRO(cmdsEvent, s3Client, lambdaConfig, bufferedWriter);
            } else if (ROReportExtConstants.UPDATE_MODE.equals(mode)) {
                loadROHierarchy(cmdsEvent, s3Client, lambdaConfig, bufferedWriter);
            }else {
                bulkROProductUpdate(cmdsEvent, s3Client, lambdaConfig, bufferedWriter);
            }

            s3Client.putObject(bucketName, fileName, file);
            Path path = Paths.get(filePath);
            cleanUp(path);
        }
    }
    public void cleanUp(Path path) throws NoSuchFileException, DirectoryNotEmptyException, IOException {
        Files.delete(path);
    }
    void bulkROProductUpdate(BaseEvent<? extends BaseHeader> cmdsEvent, AmazonS3 s3Client, LambdaConfig lambdaConfig, BufferedWriter bufferedWriter) throws JsonGenerationException, JsonMappingException, IOException {
        String bucketName =
                lambdaConfig.getValueFromEnvironmentKey(ROReportExtConstants.BUCKET_NAME);
        String fileName = getFileName(cmdsEvent.getEventHeader());
        boolean doesFileExists = s3Client.doesObjectExist(bucketName, fileName);

        String filePath = getFileWithPath(fileName);
        File file = new File(filePath);
        BulkRORecognisedProductUpdateMessageV1 bulkROProductUpdateMessageV1 =
                mapper.readValue(
                        cmdsEvent.getEventBody(),
                        BulkRORecognisedProductUpdateMessageV1.class);
        if (doesFileExists) {
            s3Client.getObject(new GetObjectRequest(bucketName, fileName), file);
        } else {
            ObjectWriter headerObjectWriter =
                    lambdaConfig.getObjectWriter(
                            true, BulkRORecognisedProductsUpdateDataV1.class);
            headerObjectWriter.writeValue(bufferedWriter, null);
        }

        ObjectWriter bodyObjectWriter =
                lambdaConfig.getObjectWriter(
                        false, BulkRORecognisedProductsUpdateDataV1.class);
        bulkROProductUpdateMessageV1
                .getMsg()
                .forEach(
                        (key, value) -> {
                            try {
                                bodyObjectWriter.writeValue(bufferedWriter, value);
                            } catch (IOException e) {
                                log.error(LOG_MESSAGE_TEMPLATE, e.getMessage());
                            }
                        });
    }
    void loadROHierarchy(BaseEvent<? extends BaseHeader> cmdsEvent, AmazonS3 s3Client, LambdaConfig lambdaConfig, BufferedWriter bufferedWriter) throws JsonGenerationException, JsonMappingException, IOException {
        String bucketName =
                lambdaConfig.getValueFromEnvironmentKey(ROReportExtConstants.BUCKET_NAME);
        String fileName = getFileName(cmdsEvent.getEventHeader());
        boolean doesFileExists = s3Client.doesObjectExist(bucketName, fileName);

        String filePath = getFileWithPath(fileName);
        File file = new File(filePath);
        LoadROHierarchyMessageV1 loadROHierarchyMessageV1 = mapper.readValue(cmdsEvent.getEventBody(),
                LoadROHierarchyMessageV1.class);
        if (doesFileExists) {
            s3Client.getObject(new GetObjectRequest(bucketName, fileName), file);
        } else {
            ObjectWriter headerObjectWriter =     lambdaConfig.getObjectWriter(true, LoadROHierarchyDataV1.class);
            headerObjectWriter.writeValue(bufferedWriter, null);
        }

        ObjectWriter bodyObjectWriter =
                lambdaConfig.getObjectWriter(false, LoadROHierarchyDataV1.class);
        loadROHierarchyMessageV1
                .getMsg()
                .forEach(
                        (key, value) -> {
                            try {
                                bodyObjectWriter.writeValue(bufferedWriter, value);
                            } catch (IOException e) {
                                log.error(LOG_MESSAGE_TEMPLATE, e.getMessage());
                            }
                        });
    }

    void loadRO(BaseEvent<? extends BaseHeader> cmdsEvent, AmazonS3 s3Client, LambdaConfig lambdaConfig, BufferedWriter bufferedWriter) throws IOException {
        LoadROMessageV1 loadROMessageV1 =
                mapper.readValue(cmdsEvent.getEventBody(), LoadROMessageV1.class);
        String bucketName =
                lambdaConfig.getValueFromEnvironmentKey(ROReportExtConstants.BUCKET_NAME);
        String fileName = getFileName(cmdsEvent.getEventHeader());
        boolean doesFileExists = s3Client.doesObjectExist(bucketName, fileName);

        String filePath = getFileWithPath(fileName);
        File file = new File(filePath);
        if (doesFileExists) {
            s3Client.getObject(new GetObjectRequest(bucketName, fileName), file);
        } else {
            ObjectWriter headerObjectWriter =
                    lambdaConfig.getObjectWriter(true, LoadRODataV1.class);
            headerObjectWriter.writeValue(bufferedWriter, null);
        }

        ObjectWriter bodyObjectWriter =
                lambdaConfig.getObjectWriter(false, LoadRODataV1.class);
        loadROMessageV1
                .getMsg()
                .forEach(
                        (key, value) -> {
                            try {
                                bodyObjectWriter.writeValue(bufferedWriter, value);
                            } catch (IOException e) {
                                log.error(LOG_MESSAGE_TEMPLATE, e.getMessage());
                            }
                        });


    }

    /**
     * This method will return an instance of {@link LambdaConfig}. Intentionally, kept in separate
     * method for testability
     *
     * @return
     */
    LambdaConfig createLambdaConfig() {
        return new LambdaConfig();
    }

    /**
     * This method will append the base path to filename. Intentionally, kept in separate method for
     * testability
     *
     * @param fileName
     * @return
     */
    String getFileWithPath(String fileName) {
        return ROReportExtConstants.BASE_PATH + fileName;
    }

    /**
     * This method will get the input filename from {@link BaseHeader} and return the output
     * filename
     *
     * @param baseHeader
     * @return
     */
    String getFileName(final BaseHeader baseHeader) {
        final Map<String, String> eventContext =
                Optional.ofNullable(baseHeader.getEventContext())
                        .orElseThrow(
                                () ->
                                        new IllegalArgumentException(
                                                "Event Context cannot be empty"));
        final String fileName = eventContext.get("roDataFile");
        if (fileName == null || fileName.isEmpty()) {
            throw new IllegalArgumentException("File name cannot be empty");
        }
        return fileName.replace(".csv", "_report_"+baseHeader.getTransactionId()+".csv");
    }



    /**
     * Get Mode Of Operation from eventContext
     *
     * @param baseHeader
     * @return
     */
    public String getOperationMode(final BaseHeader baseHeader) {
        final Map<String, String> eventContext = baseHeader.getEventContext();
        final String mode = eventContext.get(ROReportExtConstants.OPERATION_MODE);
        if (StringUtils.isEmpty(mode)) {
            throw new IllegalArgumentException("Mode cannot be empty");
        }
        return mode;
    }

    /**
     * This method will return the {@link BaseEvent} from message body
     *
     * @param roMessage
     * @param mapper
     * @return
     */
    protected BaseEvent<BaseHeader> validateMessage(String roMessage, ObjectMapper mapper) {

        BaseEvent<BaseHeader> cmdsEvent;

        try {
            JavaType type =
                    mapper.getTypeFactory()
                            .constructParametricType(BaseEvent.class, BaseHeader.class);
            cmdsEvent = mapper.readValue(roMessage, type);

        } catch (JsonProcessingException e) {
            log.error("Exception in Incoming Message:{}", e);
            throw new IllegalArgumentException(e);
        }
        return cmdsEvent;
    }

    /**
     * Method to initialise Logger Context for RO Report Ext lambda
     *
     * @param transactionId
     * @param context
     */
    protected void initializeLogger(UUID transactionId, Context context) {

        if (transactionId != null) {
            loggerUtil.initializeThreadContextMap(
                    transactionId.toString(),
                    ROReportExtConstants.RO_REPORT_EXT_LAMBDA,
                    context.getAwsRequestId());
        } else {
            throw new IllegalArgumentException("TransactionId is null");
        }
    }

    /**
     * Method to generate Error Response
     *
     * @param eventHeader
     * @param exception
     * @return
     */
    protected List<ErrorDescription> generateAndLogErrorResponse(
            BaseHeader eventHeader, Exception exception) {
        ErrorDescription errorDescription = new ErrorDescription();
        errorDescription.setInterfaceName(ROReportExtConstants.RO_REPORT_EXT_LAMBDA);
        errorDescription.setMessage(exception.getMessage());
        errorDescription.setTitle(ROReportExtConstants.EXCEPTION_MESSAGE_PROCESSING);
        errorDescription.setType(ErrorTypeEnum.ERROR);
        errorDescription.setErrorCode(eventHeader.getEventName());
        errorDescription.setErrorTicketUuid(null);

        Source source = new Source(exception.getMessage(), eventHeader.getEventName());
        errorDescription.setSource(source);

        List<ErrorDescription> eventErrors = new ArrayList<>();
        eventErrors.add(errorDescription);
        log.error("Exception while Creating Report: {} ", eventErrors);
        return eventErrors;
    }
}
