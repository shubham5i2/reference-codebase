package com.ielts.cmds.integration.config;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.fasterxml.jackson.core.JsonGenerator.Feature;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

/**
 * This class contains method for configurations in Ro Report Ext Lambda
 *
 * @author nshrir
 */
public class LambdaConfig {

    /**
     * This method is used to get the environment variable value from the key
     *
     * @param key
     * @return
     */
    public String getValueFromEnvironmentKey(String key) {
        return System.getenv(key);
    }

    /**
     * This method will provide {@link ObjectWriter} for header as well as body
     *
     * @param isHeader
     * @return
     */
    public ObjectWriter getObjectWriter(boolean isHeader, Class<?> pojoClassType) {
        CsvMapper csvMapper = getCsvMapper();
        CsvSchema schema =
                csvMapper.schemaFor(pojoClassType).withColumnSeparator(',').withUseHeader(isHeader);
        return csvMapper.writer(schema);
    }

    /**
     * This method will return the {@link CsvMapper} object with configuration
     *
     * @return
     */
    public CsvMapper getCsvMapper() {
        CsvMapper csvMapper = new CsvMapper();
        csvMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        csvMapper.disable(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY);
        csvMapper.disable(Feature.AUTO_CLOSE_TARGET);
        return csvMapper;
    }

    /**
     * This method will return the {@link AmazonS3} object with configuration
     *
     * @return
     */
    public AmazonS3 getAmazonS3Client() {
        return AmazonS3ClientBuilder.standard().withRegion(Regions.EU_WEST_2).build();
    }
}
