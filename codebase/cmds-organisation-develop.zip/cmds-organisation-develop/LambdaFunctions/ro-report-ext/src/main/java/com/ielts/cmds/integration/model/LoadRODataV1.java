package com.ielts.cmds.integration.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
public class LoadRODataV1 {

    @JsonProperty("rowNumber")
    private String rowNumber;

    @JsonProperty("recognising_organisation_uuid")
    private String recognisingOrganisationUuid;

    @JsonProperty("trf.organisation_id")
    private String organisationId;

    @JsonProperty("business_identifier")
    private String businessIdentifier;

    @JsonProperty("db_ro_name")
    private String dbRoName;

    @JsonProperty("sector_type")
    private String sectorType;

    @JsonProperty("name")
    private String name;

    @JsonProperty("verification_status")
    private String verificationStatus;

    @JsonProperty("partner_code")
    private String partnerCode;

    @JsonProperty("method_of_delivery")
    private String methodOfDelivery;

    @JsonProperty("parent_recognising_organisation_uuid")
    private String parentRecognisingOrganisationUuid;

    @JsonProperty("website_url")
    private String websiteUrl;

    @JsonProperty("country_uuid")
    private String countryIso3Code;

    @JsonProperty("addressline1")
    private String addressLine1;

    @JsonProperty("addressline2")
    private String addressLine2;

    @JsonProperty("addressline3")
    private String addressLine3;

    @JsonProperty("addressline4")
    private String addressLine4;

    @JsonProperty("city")
    private String city;

    @JsonProperty("ros.state")
    private String territoryIso3Code;

    @JsonProperty("pc.postcode")
    private String postalCode;

    @JsonProperty("full_address")
    private String fullAddress;

    @JsonProperty("contact_email")
    private String contactEmail;

    @JsonProperty("telephone_no")
    private String telephoneNo;

    @JsonProperty("first_name")
    private String firstName;

    @JsonProperty("last_name")
    private String lastName;

    @JsonProperty("irs_user_id")
    private String irsUserId;

    @JsonProperty("irs_email_admin_only")
    private String irsEmailAdminOnly;

    @JsonProperty("irs_firstname")
    private String irsFirstName;

    @JsonProperty("irs_lastname")
    private String irsLastName;

    @JsonProperty("title")
    private String title;

    @JsonProperty("job_title")
    private String jobTitle;

    @JsonProperty("crm_system")
    private String crmSystem;

    @JsonProperty("note_content")
    private String noteContent;

    @JsonProperty("alternative_name_1")
    private String alternateName1;

    @JsonProperty("alternative_name_2")
    private String alternateName2;

    @JsonProperty("alternative_name_3")
    private String alternateName3;

    @JsonProperty("ac_minimum_score_value")
    private String acMinimumScoreValue;

    @JsonProperty("ac_writing_minimum_score_value")
    private String acWritingMinimumScoreValue;

    @JsonProperty("ac_reading_minimum_score_value")
    private String acReadingMinimumScoreValue;

    @JsonProperty("ac_listening_minimum_score_value")
    private String acListeningMinimumScoreValue;

    @JsonProperty("ac_speaking_minimum_score_value")
    private String acSpeakingMinimumScoreValue;

    @JsonProperty("gt_minimum_score_value")
    private String gtMinimumScoreValue;

    @JsonProperty("gt_writing_minimum_score_value")
    private String gtWritingMinimumScoreValue;

    @JsonProperty("gt_reading_minimum_score_value")
    private String gtReadingMinimumScoreValue;

    @JsonProperty("gt_listening_minimum_score_value")
    private String gtListeningMinimumScoreValue;

    @JsonProperty("gt_speaking_minimum_score_value")
    private String gtSpeakingMinimumScoreValue;

    @JsonProperty("recognised_product")
    private String recognisedProduct;

    @JsonProperty("trf.admin_user_id")
    private String adminUserId;

    @JsonProperty("mark_for_deletion")
    private String markForDeletion;

    @JsonProperty("visible_on_ielts")
    private String visibleOnIelts;

    @JsonProperty("selectable_on_ors")
    private String selectableOnOrs;

    @JsonProperty("error_list")
    private String errorListString;
}
