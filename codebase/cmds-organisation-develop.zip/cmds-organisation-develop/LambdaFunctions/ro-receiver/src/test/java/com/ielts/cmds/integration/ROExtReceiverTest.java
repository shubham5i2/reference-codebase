package com.ielts.cmds.integration;

import com.amazonaws.services.sns.AmazonSNS;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.common.external_client.OrganisationNodeV1;
import com.ielts.cmds.api.common.ui_client.RoDataCreateV1;
import com.ielts.cmds.integration.helper.ROReceiverTestHelper;
import com.ielts.cmds.integration.service.ROCreateService;
import com.ielts.cmds.integration.service.ROProcessService;
import com.ielts.cmds.serialization.lambda.config.SNSClientConfig;
import com.ielts.cmds.serialization.lambda.receiver.service.AbstractServiceFactory;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.org.webcompere.systemstubs.environment.EnvironmentVariables;
import uk.org.webcompere.systemstubs.jupiter.SystemStub;
import uk.org.webcompere.systemstubs.jupiter.SystemStubsExtension;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.spy;

@ExtendWith(MockitoExtension.class)
@ExtendWith(SystemStubsExtension.class)
class ROExtReceiverTest {

  @InjectMocks private ROProcessService roProcessService;

  private ROExtReceiver roExtReceiver;

  @Mock private AmazonSNS snsClient;

  private static MockedStatic<SNSClientConfig> snsClientConfig;

  @Mock private ObjectMapper mapper;

  private AbstractServiceFactory serviceFactory;

  @SystemStub private EnvironmentVariables env;

  @BeforeAll
  static void init() {
    snsClientConfig = Mockito.mockStatic(SNSClientConfig.class);
  }

  @BeforeEach
  void setup() {
    snsClientConfig.when(SNSClientConfig::getSNSClient).thenReturn(snsClient);
    ROExtReceiver receiverLambdaObject = new ROExtReceiver();
    roExtReceiver = spy(receiverLambdaObject);
    final Map<String, IReceiverService> initServices = new HashMap<>();
    initServices.put("GET/v1/ros/process", new ROProcessService());
    serviceFactory = spy(new ReceiverServiceFactory(initServices));
  }

  @AfterAll
  static void clear() {
    snsClientConfig.close();
  }

  @Test
  void whenGetTopicArn_ExpectUITopic() {
    env.set("ro_ext_topic_in_arn", "ro_ext_topic_in");
    assertEquals("ro_ext_topic_in", roExtReceiver.getTopicArn());
  }

  @Test
  void whenRoProcessRequest_ExpectCorrectServiceCalled() {

    IReceiverService service = serviceFactory.getService("GET/v1/ros/process");
    assertEquals(ROProcessService.class, service.getClass());
    assertEquals("RoProcessRequest", service.getOutgoingEventName());
  }

  @Test
  void whenRoProcessRequest_thenIncomingEventIsMappedCorrectlyToOutgoingEvent() {
    OrganisationNodeV1 incomingEvent = new OrganisationNodeV1();
    incomingEvent.setOrganisationUuid(UUID.randomUUID());
    OrganisationNodeV1 outgoingEvent = roProcessService.process(incomingEvent);
    assertNotNull(incomingEvent);
  }
}
