package com.ielts.cmds.integration.service;

import com.ielts.cmds.api.common.ui_client.RoDataCreateV1;
import com.ielts.cmds.integration.helper.ROReceiverTestHelper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;

import static com.ielts.cmds.integration.constants.ROReceiverConstants.RO_CREATE_REQUEST_OUTGOING_EVENT_NAME;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

@ExtendWith(MockitoExtension.class)
class ROCreateServiceTest {

    @InjectMocks
    private ROCreateService roCreateService;

    @Test
    void when_callingGetOutgoingEventName_thenReturnEvent() {
        String actualEventName = roCreateService.getOutgoingEventName();
        assertEquals(RO_CREATE_REQUEST_OUTGOING_EVENT_NAME, actualEventName);
    }

    @Test
    void whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEvent() {
        RoDataCreateV1 incomingEvent = ROReceiverTestHelper.getROCreateRequest();
        com.ielts.cmds.api.roui007rocreaterequested.RoDataCreate outgoingEvent = roCreateService
                .process(incomingEvent);
        assertEquals(incomingEvent.getAcceptsIOL(), outgoingEvent.getAcceptsIOL());
        assertEquals(incomingEvent.getOrganisationCode(), outgoingEvent.getOrganisationCode());
        assertEquals(incomingEvent.getPartnerCode(), outgoingEvent.getPartnerCode());
    }

    @Test
    void whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEventWhenFirstNameIsNull() {
        RoDataCreateV1 incomingEvent = ROReceiverTestHelper.getROCreateRequest();

        incomingEvent.getContacts().get(0).setFirstName(null);
        com.ielts.cmds.api.roui007rocreaterequested.RoDataCreate outgoingEvent = roCreateService
                .process(incomingEvent);
        assertNull(incomingEvent.getContacts().get(0).getFirstName());
    }

    @Test
    void whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEventWhenLastNameIsNull() {
        RoDataCreateV1 incomingEvent = ROReceiverTestHelper.getROCreateRequest();

        incomingEvent.getContacts().get(0).setLastName(null);
        com.ielts.cmds.api.roui007rocreaterequested.RoDataCreate outgoingEvent = roCreateService
                .process(incomingEvent);
        assertNull(incomingEvent.getContacts().get(0).getLastName());
    }

    @Test
    void whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEventWhenAlternateNameIsEmpty() {
        RoDataCreateV1 incomingEvent = ROReceiverTestHelper.getROCreateRequest();

        incomingEvent.setAlternateNames(new ArrayList<>());
        com.ielts.cmds.api.roui007rocreaterequested.RoDataCreate outgoingEvent = roCreateService
                .process(incomingEvent);
        assertEquals(0,incomingEvent.getAlternateNames().size());
    }

    @Test
    void whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEventWhenContactIsEmpty() {
        RoDataCreateV1 incomingEvent = ROReceiverTestHelper.getROCreateRequest();

        incomingEvent.setContacts(new ArrayList<>());
        com.ielts.cmds.api.roui007rocreaterequested.RoDataCreate outgoingEvent = roCreateService
                .process(incomingEvent);
        assertEquals(0,incomingEvent.getContacts().size());
    }

    @Test
    void whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEventWhenLinkedOrganizationIsEmpty() {
        RoDataCreateV1 incomingEvent = ROReceiverTestHelper.getROCreateRequest();

        incomingEvent.setLinkedOrganisations(new ArrayList<>());
        com.ielts.cmds.api.roui007rocreaterequested.RoDataCreate outgoingEvent = roCreateService
                .process(incomingEvent);
        assertEquals(0,incomingEvent.getLinkedOrganisations().size());
    }

    @Test
    void whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEventWhenAddressIsEmpty() {
        RoDataCreateV1 incomingEvent = ROReceiverTestHelper.getROCreateRequest();

        incomingEvent.setAddresses(new ArrayList<>());
        com.ielts.cmds.api.roui007rocreaterequested.RoDataCreate outgoingEvent = roCreateService
                .process(incomingEvent);
        assertEquals(0,incomingEvent.getAddresses().size());
    }

    @Test
    void whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEventWhenNoteIsEmpty() {
        RoDataCreateV1 incomingEvent = ROReceiverTestHelper.getROCreateRequest();

        incomingEvent.setNotes(new ArrayList<>());
        com.ielts.cmds.api.roui007rocreaterequested.RoDataCreate outgoingEvent = roCreateService
                .process(incomingEvent);
        assertEquals(0,incomingEvent.getNotes().size());
    }

    @Test
    void whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEventWhenMinimumScoreIsEmpty() {
        RoDataCreateV1 incomingEvent = ROReceiverTestHelper.getROCreateRequest();

        incomingEvent.setMinimumScores(new ArrayList<>());
        com.ielts.cmds.api.roui007rocreaterequested.RoDataCreate outgoingEvent = roCreateService
                .process(incomingEvent);
        assertEquals(0,incomingEvent.getMinimumScores().size());
    }
}
