package com.ielts.cmds.integration.service;

import com.ielts.cmds.api.common.ui_client.RoSearchV1;

import com.ielts.cmds.integration.helper.ROReceiverTestHelper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.ielts.cmds.integration.constants.ROReceiverConstants.RO_SEARCH_REQUEST_OUTGOING_EVENT_NAME;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

@ExtendWith(MockitoExtension.class)
class ROSearchServiceTest {
  @InjectMocks private ROSearchService roSearchService;

  @Test
  void when_callingGetOutgoingEventName_thenReturnEvent() {
    String actualEventName = roSearchService.getOutgoingEventName();
    assertEquals(RO_SEARCH_REQUEST_OUTGOING_EVENT_NAME, actualEventName);
  }

  @Test
  void whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEvent() {
    RoSearchV1 incomingEvent = ROReceiverTestHelper.getROSearchRequest();
    com.ielts.cmds.api.roui005rosearchrequested.RoSearchObject outgoingEvent =
        roSearchService.process(incomingEvent);
    assertEquals(incomingEvent.getCriteria().getCity(), outgoingEvent.getCriteria().getCity());
    assertEquals(
        incomingEvent.getCriteria().getOrganisationName(),
        outgoingEvent.getCriteria().getOrganisationName());
    assertEquals(
        incomingEvent.getCriteria().getCountry(), outgoingEvent.getCriteria().getCountry());
    assertEquals(
        incomingEvent.getCriteria().getFuzzyMatch(), outgoingEvent.getCriteria().getFuzzyMatch());
    assertEquals(
        incomingEvent.getCriteria().getPartnerCode(), outgoingEvent.getCriteria().getPartnerCode());
    assertEquals(
        incomingEvent.getCriteria().getOrganisationId(),
        outgoingEvent.getCriteria().getOrganisationId());
    assertEquals(
        incomingEvent.getCriteria().getTerritory(), outgoingEvent.getCriteria().getTerritory());

    assertEquals(
        incomingEvent.getSorting().get(0).getSortBy(),
        outgoingEvent.getSorting().get(0).getSortBy());
    assertEquals(
        incomingEvent.getSorting().get(0).getSortType(),
        outgoingEvent.getSorting().get(0).getSortType());

    assertEquals(
        incomingEvent.getPagination().getPageNumber(),
        outgoingEvent.getPagination().getPageNumber());
    assertEquals(
        incomingEvent.getPagination().getPageSize(), outgoingEvent.getPagination().getPageSize());
  }

  @Test
  void whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEventWhenOrganisationStatusIsNull() {
    RoSearchV1 incomingEvent = ROReceiverTestHelper.getROSearchRequest();
    incomingEvent.getCriteria().setOrganisationStatus(null);
    com.ielts.cmds.api.roui005rosearchrequested.RoSearchObject outgoingEvent =
        roSearchService.process(incomingEvent);
    assertNull(incomingEvent.getCriteria().getOrganisationStatus());
  }

  @Test
  void whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEventWhenVerificationStatusIsNull() {
    RoSearchV1 incomingEvent = ROReceiverTestHelper.getROSearchRequest();
    incomingEvent.getCriteria().setVerificationStatus(null);
    com.ielts.cmds.api.roui005rosearchrequested.RoSearchObject outgoingEvent =
        roSearchService.process(incomingEvent);
    assertNull(incomingEvent.getCriteria().getVerificationStatus());
  }
}
