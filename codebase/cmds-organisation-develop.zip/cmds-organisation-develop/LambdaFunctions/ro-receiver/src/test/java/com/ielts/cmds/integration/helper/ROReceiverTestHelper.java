package com.ielts.cmds.integration.helper;

import com.ielts.cmds.api.common.ui_client.*;
import com.ielts.cmds.api.roui005rosearchrequested.RoSearchCriteria;
import com.ielts.cmds.api.roui005rosearchrequested.RoSearchObject;
import com.ielts.cmds.api.roui005rosearchrequested.SearchPagination;
import com.ielts.cmds.api.roui005rosearchrequested.SearchSortItem;
import com.ielts.cmds.api.roui007rocreaterequested.*;
import com.ielts.cmds.api.roui009roupdaterequested.*;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ROReceiverTestHelper {
    public static RoDataCreateV1 getROCreateRequest() {
        RoDataCreateV1 roDataCreateV1 = new RoDataCreateV1();
        roDataCreateV1.setOrganisationName("Boston University");
        roDataCreateV1.setOrganisationTypeUuid(UUID.randomUUID());
        roDataCreateV1.setVerificationStatus(RoDataCreateV1.VerificationStatusEnum.valueOf("APPROVED"));
        roDataCreateV1.setPartnerCode("IDP");
        roDataCreateV1.setPartnerContact("");
        roDataCreateV1.setMethodOfDelivery(RoDataCreateV1.MethodOfDeliveryEnum.valueOf("POSTAL"));
        roDataCreateV1.setSectorTypeUuid(UUID.randomUUID());
        roDataCreateV1.setOrganisationStatus(RoDataCreateV1.OrganisationStatusEnum.ACTIVE);
        roDataCreateV1.setWebsiteUrl("www.test.com");
        roDataCreateV1.setCrmSystem("CRM");
        roDataCreateV1.setOrganisationCode("12345");
        roDataCreateV1.setResultAvailableForYears(3);
        roDataCreateV1.setIeltsDisplayFlag(true);
        roDataCreateV1.setOrsDisplayFlag(true);
        roDataCreateV1.setAcceptsIOL(true);
        roDataCreateV1.setAcceptsSSR(false);

        List<RoDataCreateV1Address> addresses = new ArrayList<>();
        RoDataCreateV1Address address = new RoDataCreateV1Address();
        address.setAddressTypeUuid(UUID.randomUUID());
        address.setAddressLine1("address line1");
        address.setAddressLine2("address line2");
        address.setAddressLine3("address line3");
        address.setAddressLine4("address line4");
        address.setCity("Cambridge");
        address.setTerritoryUuid(UUID.randomUUID());
        address.setCountryUuid(UUID.randomUUID());
        address.setPostalCode("4543");
        address.setEmail("test@test.com");
        address.setPhone("+673433234323");
        addresses.add(address);
        roDataCreateV1.setAddresses(addresses);

        List<RoDataCreateV1Note> notes = new ArrayList<>();
        RoDataCreateV1Note note = new RoDataCreateV1Note();
        note.setNoteContent("notes");
        notes.add(note);
        roDataCreateV1.setNotes(notes);

        List<RoDataCreateV1AlternateName> alternateNames = new ArrayList<>();
        RoDataCreateV1AlternateName alternateName = new RoDataCreateV1AlternateName();
        alternateName.setName("Edison");
        alternateNames.add(alternateName);
        roDataCreateV1.setAlternateNames(alternateNames);
        
        List<RoDataCreateV1Contact> contacts = new ArrayList<>();
        RoDataCreateV1Contact contact = new RoDataCreateV1Contact();
        contact.setContactTypeUuid(UUID.randomUUID());
        contact.setEffectiveFromDateTime(OffsetDateTime.now());
        contact.setFirstName("smith ");
        contact.setTitle("Mr");
        contact.setLastName("Thomas ");
        contact.setEffectiveToDateTime(OffsetDateTime.now());
        contact.setAddresses(addresses);
        contacts.add(contact);
        roDataCreateV1.setContacts(contacts);

        List<RoDataCreateV1MinimumScore> minimumScores = new ArrayList<>();
        RoDataCreateV1MinimumScore minimumScore = new RoDataCreateV1MinimumScore();
        minimumScore.setMinimumScoreValue(BigDecimal.valueOf(5.0));
        minimumScore.setComponent(RoDataCreateV1MinimumScore.ComponentEnum.valueOf("L"));
        minimumScore.setModuleTypeUuid(UUID.randomUUID());
        minimumScores.add(minimumScore);
        roDataCreateV1.setMinimumScores(minimumScores);

        List<RoDataCreateV1LinkedOrganisation> linkedOrganisations = new ArrayList<>();
        RoDataCreateV1LinkedOrganisation linkedOrganisation =
                new RoDataCreateV1LinkedOrganisation();
        linkedOrganisation.setLinkType(
                RoDataCreateV1LinkedOrganisation.LinkTypeEnum.valueOf("PARENT_RO"));
        linkedOrganisation.setTargetRecognisingOrganisationUuid(
                UUID.randomUUID());
        linkedOrganisation.setLinkEffectiveFromDateTime(OffsetDateTime.now());
        linkedOrganisation.setLinkEffectiveToDateTime(OffsetDateTime.now());
        linkedOrganisations.add(linkedOrganisation);
        roDataCreateV1.setLinkedOrganisations(linkedOrganisations);

        return roDataCreateV1;
    }

    public static RoDataUpdateV1 getROUpdateRequest() {
        RoDataUpdateV1 roDataUpdateV1 = new RoDataUpdateV1();
        roDataUpdateV1.setRecognisingOrganisationUuid(UUID.randomUUID());
        roDataUpdateV1.setOrganisationName("Boston University");
        roDataUpdateV1.setOrganisationTypeUuid(UUID.randomUUID());
        roDataUpdateV1.setVerificationStatus(RoDataUpdateV1.VerificationStatusEnum.valueOf("APPROVED"));
        roDataUpdateV1.setPartnerCode("IDP");
        roDataUpdateV1.setPartnerContact("");
        roDataUpdateV1.setMethodOfDelivery(RoDataUpdateV1.MethodOfDeliveryEnum.valueOf("POSTAL"));
        roDataUpdateV1.setSectorTypeUuid(UUID.randomUUID());
        roDataUpdateV1.setOrganisationStatus(RoDataUpdateV1.OrganisationStatusEnum.valueOf("ACTIVE"));
        roDataUpdateV1.setWebsiteUrl("www.test.com");
        roDataUpdateV1.setCrmSystem("");
        roDataUpdateV1.setOrganisationCode("12345");
        roDataUpdateV1.setResultAvailableForYears(3);
        roDataUpdateV1.setIeltsDisplayFlag(true);
        roDataUpdateV1.setOrsDisplayFlag(true);
        roDataUpdateV1.setAcceptsIOL(true);
        roDataUpdateV1.setAcceptsSSR(false);

        List<RoDataUpdateV1Address> addresses = new ArrayList<>();
        RoDataUpdateV1Address address = new RoDataUpdateV1Address();
        address.setAddressUuid(UUID.randomUUID());
        address.setAddressTypeUuid(UUID.randomUUID());
        address.setAddressLine1("address line1");
        address.setAddressLine2("address line2");
        address.setAddressLine3("address line3");
        address.setAddressLine4("address line4");
        address.setCity("Cambridge");
        address.setTerritoryUuid(UUID.randomUUID());
        address.setCountryUuid(UUID.randomUUID());
        address.setPostalCode("4543");
        address.setEmail("test@test.com");
        address.setPhone("+673433234323");
        addresses.add(address);
        roDataUpdateV1.setAddresses(addresses);

        List<RoDataUpdateV1Note> notes = new ArrayList<>();
        RoDataUpdateV1Note note = new RoDataUpdateV1Note();
        note.setNoteTypeUuid(UUID.randomUUID());
        note.setNoteContent("notes");
        note.setNoteUuid(UUID.randomUUID());
        notes.add(note);
        roDataUpdateV1.setNotes(notes);

        List<RoDataUpdateV1AlternateName> alternateNames = new ArrayList<>();
        RoDataUpdateV1AlternateName alternateName = new RoDataUpdateV1AlternateName();
        alternateName.setName("Edison");
        alternateName.setAlternateNameUuid(UUID.randomUUID());
        alternateNames.add(alternateName);
        roDataUpdateV1.setAlternateNames(alternateNames);

        List<RoDataUpdateV1Contact> contacts = new ArrayList<>();
        RoDataUpdateV1Contact contact = new RoDataUpdateV1Contact();
        contact.setContactUuid(UUID.randomUUID());
        contact.setContactTypeUuid(UUID.randomUUID());
        contact.setEffectiveFromDateTime(OffsetDateTime.now());
        contact.setFirstName("smith ");
        contact.setTitle("Mr");
        contact.setLastName("Thomas ");
        contact.setEffectiveToDateTime(OffsetDateTime.now());
        contact.setAddresses(addresses);
        contacts.add(contact);
        roDataUpdateV1.setContacts(contacts);

        List<RoDataUpdateV1MinimumScore> minimumScores = new ArrayList<>();
        RoDataUpdateV1MinimumScore minimumScore = new RoDataUpdateV1MinimumScore();
        minimumScore.setMinimumScoreUuid(UUID.randomUUID());
        minimumScore.setMinimumScoreValue(BigDecimal.valueOf(5.0));
        minimumScore.setComponent(RoDataUpdateV1MinimumScore.ComponentEnum.valueOf("L"));
        minimumScore.setModuleTypeUuid(UUID.randomUUID());
        minimumScores.add(minimumScore);
        roDataUpdateV1.setMinimumScores(minimumScores);

        List<RoDataUpdateV1LinkedOrganisation> linkedOrganisations = new ArrayList<>();
        RoDataUpdateV1LinkedOrganisation linkedOrganisation =
                new RoDataUpdateV1LinkedOrganisation();
        linkedOrganisation.setLinkedRecognisingOrganisationUuid(UUID.randomUUID());
        linkedOrganisation.setLinkType(
                RoDataUpdateV1LinkedOrganisation.LinkTypeEnum.valueOf("PARENT_RO"));
        linkedOrganisation.setTargetRecognisingOrganisationUuid(
                UUID.randomUUID());
        linkedOrganisation.setLinkEffectiveFromDateTime(OffsetDateTime.now());
        linkedOrganisation.setLinkEffectiveToDateTime(OffsetDateTime.now());
        linkedOrganisations.add(linkedOrganisation);
        roDataUpdateV1.setLinkedOrganisations(linkedOrganisations);
        return roDataUpdateV1;
    }

    public static RoSearchV1 getROSearchRequest() {
        RoSearchV1 roSearchV1 = new RoSearchV1();

        RoSearchV1Criteria roSearchV1Criteria = new RoSearchV1Criteria();
        roSearchV1Criteria.setOrganisationName("Boston University");
        roSearchV1Criteria.setOrganisationId(12345);
        roSearchV1Criteria.setContactName("Thomas");
        roSearchV1Criteria.setOrganisationStatus(
                RoSearchV1Criteria.OrganisationStatusEnum.valueOf("ACTIVE"));
        roSearchV1Criteria.setVerificationStatus(
                RoSearchV1Criteria.VerificationStatusEnum.valueOf("APPROVED"));
        roSearchV1Criteria.setOrganisationTypeUuid(UUID.randomUUID());
        roSearchV1Criteria.setCity("Cambridge");
        roSearchV1Criteria.setPostalCode("4545");
        roSearchV1Criteria.setContactEmail("test@test.com");
        roSearchV1Criteria.setPartnerCode("IDP");
        roSearchV1Criteria.setCountry(UUID.randomUUID());
        roSearchV1Criteria.setFuzzyMatch(true);
        roSearchV1Criteria.setTerritory(UUID.randomUUID());
        roSearchV1.setCriteria(roSearchV1Criteria);

        SearchPaginationV1 searchPaginationV1 = new SearchPaginationV1();
        searchPaginationV1.setPageNumber(BigDecimal.valueOf(2));
        searchPaginationV1.setPageSize(BigDecimal.valueOf(10));
        roSearchV1.setPagination(searchPaginationV1);

        List<SearchSortV1Item> searchSortItems = new ArrayList<>();
        SearchSortV1Item searchSortV1Item = new SearchSortV1Item();
        searchSortV1Item.setSortBy("name");
        searchSortV1Item.setSortType("ASC");
        searchSortItems.add(searchSortV1Item);
        roSearchV1.setSorting(searchSortItems);
        return roSearchV1;
    }
}
