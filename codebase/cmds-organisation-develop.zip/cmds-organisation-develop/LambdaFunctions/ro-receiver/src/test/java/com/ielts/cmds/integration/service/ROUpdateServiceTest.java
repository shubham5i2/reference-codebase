package com.ielts.cmds.integration.service;

import com.ielts.cmds.api.common.ui_client.RoDataCreateV1;
import com.ielts.cmds.api.common.ui_client.RoDataUpdateV1;
import com.ielts.cmds.api.common.ui_client.RoDataUpdateV1Contact;
import com.ielts.cmds.api.common.ui_client.RoSearchV1;
import com.ielts.cmds.integration.helper.ROReceiverTestHelper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static com.ielts.cmds.integration.constants.ROReceiverConstants.RO_UPDATE_REQUEST_OUTGOING_EVENT_NAME;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

@ExtendWith(MockitoExtension.class)
class ROUpdateServiceTest {
  @InjectMocks private ROUpdateService roUpdateService;

  @Test
  void when_callingGetOutgoingEventName_thenReturnEvent() {
    String actualEventName = roUpdateService.getOutgoingEventName();
    assertEquals(RO_UPDATE_REQUEST_OUTGOING_EVENT_NAME, actualEventName);
  }

  @Test
  void whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEvent() {
    RoDataUpdateV1 incomingEvent = ROReceiverTestHelper.getROUpdateRequest();
    com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdate outgoingEvent =
        roUpdateService.process(incomingEvent);
    assertEquals(incomingEvent.getAcceptsIOL(), outgoingEvent.getAcceptsIOL());
    assertEquals(incomingEvent.getOrganisationCode(), outgoingEvent.getOrganisationCode());
    assertEquals(incomingEvent.getPartnerCode(), outgoingEvent.getPartnerCode());
  }

  @Test
  void whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEventWhenFirstNameIsNull() {
    RoDataUpdateV1 incomingEvent = ROReceiverTestHelper.getROUpdateRequest();

    incomingEvent.getContacts().get(0).setFirstName(null);
    com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdate outgoingEvent =
        roUpdateService.process(incomingEvent);
    assertNull(incomingEvent.getContacts().get(0).getFirstName());
  }

  @Test
  void whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEventWhenLastNameIsNull() {
    RoDataUpdateV1 incomingEvent = ROReceiverTestHelper.getROUpdateRequest();

    incomingEvent.getContacts().get(0).setLastName(null);
    com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdate outgoingEvent =
        roUpdateService.process(incomingEvent);
    assertNull(incomingEvent.getContacts().get(0).getLastName());
  }

  @Test
  void whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEventWhenAlternateNameIsEmpty() {
    RoDataUpdateV1 incomingEvent = ROReceiverTestHelper.getROUpdateRequest();

    incomingEvent.setAlternateNames(new ArrayList<>());
    com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdate outgoingEvent =
        roUpdateService.process(incomingEvent);
    assertEquals(0,incomingEvent.getAlternateNames().size());
  }

  @Test
  void whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEventWhenContactIsEmpty() {
    RoDataUpdateV1 incomingEvent = ROReceiverTestHelper.getROUpdateRequest();

    incomingEvent.setContacts(new ArrayList<>());
    com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdate outgoingEvent =
        roUpdateService.process(incomingEvent);
    assertEquals(0,incomingEvent.getContacts().size());
  }

  @Test
  void
      whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEventWhenLinkedOrganizationIsEmpty() {
    RoDataUpdateV1 incomingEvent = ROReceiverTestHelper.getROUpdateRequest();

    incomingEvent.setLinkedOrganisations(new ArrayList<>());
    com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdate outgoingEvent =
        roUpdateService.process(incomingEvent);
    assertEquals(0,incomingEvent.getLinkedOrganisations().size());
  }

  @Test
  void whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEventWhenAddressIsEmpty() {
    RoDataUpdateV1 incomingEvent = ROReceiverTestHelper.getROUpdateRequest();

    incomingEvent.setAddresses(new ArrayList<>());
    com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdate outgoingEvent =
        roUpdateService.process(incomingEvent);
    assertEquals(0,incomingEvent.getAddresses().size());
  }

  @Test
  void whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEventWhenNoteIsEmpty() {
    RoDataUpdateV1 incomingEvent = ROReceiverTestHelper.getROUpdateRequest();

    incomingEvent.setNotes(new ArrayList<>());
    com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdate outgoingEvent =
        roUpdateService.process(incomingEvent);
    assertEquals(0,incomingEvent.getNotes().size());
  }

  @Test
  void whenProcess_thenIncomingEventIsMappedCorrectlyToOutgoingEventWhenMinimumScoreIsEmpty() {
    RoDataUpdateV1 incomingEvent = ROReceiverTestHelper.getROUpdateRequest();

    incomingEvent.setMinimumScores(new ArrayList<>());
    com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdate outgoingEvent =
        roUpdateService.process(incomingEvent);
    assertEquals(0,incomingEvent.getMinimumScores().size());
  }
}
