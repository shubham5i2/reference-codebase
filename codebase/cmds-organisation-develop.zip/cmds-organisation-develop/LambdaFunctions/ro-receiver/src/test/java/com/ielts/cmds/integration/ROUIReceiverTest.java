package com.ielts.cmds.integration;

import com.amazonaws.services.sns.AmazonSNS;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.integration.service.*;
import com.ielts.cmds.serialization.lambda.config.SNSClientConfig;
import com.ielts.cmds.serialization.lambda.receiver.service.AbstractServiceFactory;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.spy;
import uk.org.webcompere.systemstubs.environment.EnvironmentVariables;
import uk.org.webcompere.systemstubs.jupiter.SystemStub;
import uk.org.webcompere.systemstubs.jupiter.SystemStubsExtension;

@ExtendWith(MockitoExtension.class)
@ExtendWith(SystemStubsExtension.class)
class ROUIReceiverTest {

    private ROUIReceiver rouiReceiver;
    @Mock
    private AmazonSNS snsClient;

    private static MockedStatic<SNSClientConfig> snsClientConfig;

    @Mock
    private ObjectMapper mapper;

    private AbstractServiceFactory serviceFactory;

    @SystemStub
    private EnvironmentVariables env;

    @BeforeAll
    static void init() {
        snsClientConfig = Mockito.mockStatic(SNSClientConfig.class);

    }

    @BeforeEach
    void setup() {

        snsClientConfig.when(SNSClientConfig::getSNSClient).thenReturn(snsClient);
        ROUIReceiver receiverLambdaObject = new ROUIReceiver();
        rouiReceiver = spy(receiverLambdaObject);
        final Map<String, IReceiverService> initServices = new HashMap<>();
        initServices.put("POST/v1/ros", new ROCreateService());
        initServices.put("POST/v1/ros/search", new ROSearchService());
        initServices.put("PUT/v1/ros/{recognisingOrganisationUuid}", new ROUpdateService());
        initServices.put("GET/v1/ros/orgId/{organisationId}", new ROSearchByOrgIdRequestService(this.mapper));
        initServices.put("GET/v1/ros/{recognisingOrganisationUuid}", new RODetailsService(this.mapper));
        initServices.put("GET/v1/ros/hierarchy", new ROHierarchySearchService(this.mapper));
        serviceFactory = spy(new ReceiverServiceFactory(initServices));

    }

    @AfterAll
    static void clear() {
        snsClientConfig.close();
    }

    @Test
    void whenGetTopicArn_ExpectUITopic() {
        env.set("ro_ui_topic_in_arn", "ro_ui_topic_in");
        assertEquals("ro_ui_topic_in", rouiReceiver.getTopicArn());
    }

    @Test
    void whenROCreateRequest_ExpectCorrectServiceCalled() {
        IReceiverService service = serviceFactory.getService("POST/v1/ros");
        assertEquals(ROCreateService.class, service.getClass());
        assertEquals("RoCreateRequest", service.getOutgoingEventName());
    }

    @Test
    void whenROUpdateRequest_ExpectCorrectServiceCalled() {
        IReceiverService service = serviceFactory.getService("PUT/v1/ros/{recognisingOrganisationUuid}");
        assertEquals(ROUpdateService.class, service.getClass());
        assertEquals("RoUpdateRequest", service.getOutgoingEventName());
    }

    @Test
    void whenROSearchRequest_ExpectCorrectServiceCalled() {
        IReceiverService service = serviceFactory.getService("POST/v1/ros/search");
        assertEquals(ROSearchService.class, service.getClass());
        assertEquals("RoSearchRequest", service.getOutgoingEventName());
    }

    @Test
    void whenROSearchByOrgIdRequest_ExpectCorrectServiceCalled() {
        IReceiverService service = serviceFactory.getService("GET/v1/ros/orgId/{organisationId}");
        assertEquals(ROSearchByOrgIdRequestService.class, service.getClass());
        assertEquals("RoSearchByOrgIdRequest", service.getOutgoingEventName());
    }

    @Test
    void whenROHierarchySearchRequest_ExpectCorrectServiceCalled() {
        IReceiverService service = serviceFactory.getService("GET/v1/ros/hierarchy");
        assertEquals(ROHierarchySearchService.class, service.getClass());
        assertEquals("RoHierarchySearchRequest", service.getOutgoingEventName());
    }

    @Test
    void whenRODetailsRequest_ExpectCorrectServiceCalled() {
        IReceiverService service = serviceFactory.getService("GET/v1/ros/{recognisingOrganisationUuid}");
        assertEquals(RODetailsService.class, service.getClass());
        assertEquals("RoDetailsRequest", service.getOutgoingEventName());
    }

}
