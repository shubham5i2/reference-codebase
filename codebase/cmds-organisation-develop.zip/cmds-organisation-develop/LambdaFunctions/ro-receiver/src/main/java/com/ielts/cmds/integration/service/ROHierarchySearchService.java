package com.ielts.cmds.integration.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.roui010rohierarchyrequested.ROHierarchyRequestParam;
import com.ielts.cmds.serialization.lambda.receiver.service.RequestWithParamsReceiverService;
import com.ielts.cmds.integration.constants.ROReceiverConstants;

public class ROHierarchySearchService extends RequestWithParamsReceiverService<ROHierarchyRequestParam> {

    public ROHierarchySearchService(ObjectMapper mapper) {

        super(mapper);
    }
    @Override
    public String getOutgoingEventName() {

        return ROReceiverConstants.RO_HIERARCHY_SEARCH_REQUEST_OUTGOING_EVENT_NAME;
    }

}