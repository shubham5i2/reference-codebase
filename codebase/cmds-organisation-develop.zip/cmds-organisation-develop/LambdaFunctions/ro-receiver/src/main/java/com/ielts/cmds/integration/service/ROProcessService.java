package com.ielts.cmds.integration.service;

import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;
import com.ielts.cmds.api.common.external_client.OrganisationNodeV1;
import com.ielts.cmds.integration.constants.ROReceiverConstants;

public class ROProcessService implements IReceiverService<OrganisationNodeV1, OrganisationNodeV1> {

    @Override
    public OrganisationNodeV1 process(final OrganisationNodeV1 extInput) {

        return extInput;
    }

    @Override
    public String getOutgoingEventName() {

        return ROReceiverConstants.RO_PROCESS_REQUEST_OUTGOING_EVENT_NAME;
    }

}