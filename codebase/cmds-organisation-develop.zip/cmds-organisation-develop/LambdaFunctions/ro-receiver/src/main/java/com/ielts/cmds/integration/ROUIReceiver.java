package com.ielts.cmds.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.utils.CMDSCommonUtils;
import com.ielts.cmds.integration.constants.ROReceiverConstants;
import com.ielts.cmds.integration.service.ROCreateService;
import com.ielts.cmds.integration.service.RODetailsService;
import com.ielts.cmds.integration.service.ROHierarchySearchService;
import com.ielts.cmds.integration.service.ROSearchByOrgIdRequestService;
import com.ielts.cmds.integration.service.ROSearchService;
import com.ielts.cmds.integration.service.ROUpdateService;
import com.ielts.cmds.serialization.lambda.AbstractReceiverLambda;
import com.ielts.cmds.serialization.lambda.config.DisablePublishToDedicatedEventTopic;
import com.ielts.cmds.serialization.lambda.mapper.IObjectMapper;
import com.ielts.cmds.serialization.lambda.receiver.service.AbstractServiceFactory;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.Map;

@NoArgsConstructor
@DisablePublishToDedicatedEventTopic
public class ROUIReceiver extends AbstractReceiverLambda implements IObjectMapper {

	private ObjectMapper mapper;

	@Override
	public AbstractServiceFactory getServiceFactory() {
		@SuppressWarnings("rawtypes")
		final Map<String, IReceiverService> initServices = new HashMap<>();
		this.mapper = getMapperWithProperties();
		initServices.put("POST/v1/ros", new ROCreateService());
		initServices.put("POST/v1/ros/search", new ROSearchService());
		initServices.put("PUT/v1/ros/{recognisingOrganisationUuid}", new ROUpdateService());
		initServices.put("GET/v1/ros/{recognisingOrganisationUuid}", new RODetailsService(this.mapper));
		initServices.put("GET/v1/ros/orgId/{organisationId}", new ROSearchByOrgIdRequestService(this.mapper));
		initServices.put("GET/v1/ros/hierarchy", new ROHierarchySearchService(this.mapper));
		return new ReceiverServiceFactory(initServices);
	}

	@Override
	public String getTopicArn() {

		return System.getenv(ROReceiverConstants.RO_UI_TOPIC_IN);
	}

	@Override
	protected String getPartnerCode() {
		return CMDSCommonUtils.getDataFromClaims(
				ThreadLocalHeaderContext.getContext().getXaccessToken(),
				ROReceiverConstants.PARTNER_CODE);
	}

}