package com.ielts.cmds.integration.service;

import com.ielts.cmds.api.common.ui_client.RoDataCreateV1;
import com.ielts.cmds.api.common.ui_client.RoDataCreateV1Address;
import com.ielts.cmds.api.common.ui_client.RoDataCreateV1AlternateName;
import com.ielts.cmds.api.common.ui_client.RoDataCreateV1Contact;
import com.ielts.cmds.api.common.ui_client.RoDataCreateV1LinkedOrganisation;
import com.ielts.cmds.api.common.ui_client.RoDataCreateV1MinimumScore;
import com.ielts.cmds.api.common.ui_client.RoDataCreateV1Note;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreate;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreateAddress;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreateAlternateName;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreateContact;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreateLinkedOrganisation;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreateMinimumScore;
import com.ielts.cmds.api.roui007rocreaterequested.RoDataCreateNote;
import com.ielts.cmds.api.roui007rocreaterequested.OrganisationStatusEnum;
import com.ielts.cmds.api.roui007rocreaterequested.MethodOfDeliveryEnum;
import com.ielts.cmds.api.roui007rocreaterequested.VerificationStatusEnum;
import com.ielts.cmds.api.roui007rocreaterequested.ComponentEnum;
import com.ielts.cmds.api.roui007rocreaterequested.LinkTypeEnum;
import com.ielts.cmds.integration.constants.ROReceiverConstants;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class ROCreateService implements IReceiverService<RoDataCreateV1, RoDataCreate> {

    @Override
    public RoDataCreate process(final RoDataCreateV1 eventBody) {
        final RoDataCreate roDataCreate = new RoDataCreate();
        roDataCreate.setOrganisationName(eventBody.getOrganisationName());
        roDataCreate.setOrganisationTypeUuid(eventBody.getOrganisationTypeUuid());
        roDataCreate.setVerificationStatus(
                VerificationStatusEnum.fromValue(eventBody.getVerificationStatus().getValue()));
        roDataCreate.setPartnerCode(eventBody.getPartnerCode());
        roDataCreate.setPartnerContact(eventBody.getPartnerContact());
        roDataCreate.setMethodOfDelivery(
                MethodOfDeliveryEnum.fromValue(eventBody.getMethodOfDelivery().getValue()));
        roDataCreate.setSectorTypeUuid(eventBody.getSectorTypeUuid());
        roDataCreate.setOrganisationStatus(
                OrganisationStatusEnum.fromValue(eventBody.getOrganisationStatus().getValue()));
        roDataCreate.setWebsiteUrl(eventBody.getWebsiteUrl());
        roDataCreate.setCrmSystem(eventBody.getCrmSystem());
        roDataCreate.setOrganisationCode(eventBody.getOrganisationCode());
        roDataCreate.setResultAvailableForYears(eventBody.getResultAvailableForYears());
        roDataCreate.setIeltsDisplayFlag(eventBody.getIeltsDisplayFlag());
        roDataCreate.setOrsDisplayFlag(eventBody.getOrsDisplayFlag());
        roDataCreate.setAcceptsIOL(eventBody.getAcceptsIOL());
        roDataCreate.setAcceptsSSR(eventBody.getAcceptsSSR());
        roDataCreate.setAcceptsAC(eventBody.getAcceptsAC());
        roDataCreate.setAcceptsGT(eventBody.getAcceptsGT());
        roDataCreate.setAddresses(getAddresses(eventBody.getAddresses()));
        if(eventBody.getNotes() != null) {
            roDataCreate.setNotes(getNotes(eventBody.getNotes()));
        }
        if(eventBody.getAlternateNames() != null) {
            roDataCreate.setAlternateNames(getAlternateNames(eventBody.getAlternateNames()));
        }
        roDataCreate.setContacts(getContacts(eventBody.getContacts()));
        roDataCreate.setMinimumScores(getMinimumScores(eventBody.getMinimumScores()));
        roDataCreate.setLinkedOrganisations(getLinkedOrganisations(eventBody.getLinkedOrganisations()));
        return roDataCreate;
    }

    private List<RoDataCreateAlternateName> getAlternateNames(
            List<RoDataCreateV1AlternateName> alternateNames) {
        List<RoDataCreateAlternateName> alternateNamesResponse = new ArrayList<>();
        if (!alternateNames.isEmpty()) {
            alternateNames.forEach(
                    alternateName -> {
                        RoDataCreateAlternateName alternateNameResponse = new RoDataCreateAlternateName();
                        alternateNameResponse.setName(alternateName.getName());
                        alternateNamesResponse.add(alternateNameResponse);
                    });
        }
        return alternateNamesResponse;
    }

    private List<RoDataCreateNote> getNotes(List<RoDataCreateV1Note> notes) {
        List<RoDataCreateNote> notesResponse = new ArrayList<>();
        if (!notes.isEmpty()) {
            notes.forEach(
                    note -> {
                        RoDataCreateNote noteResponse = new RoDataCreateNote();
                        noteResponse.setNoteContent(note.getNoteContent());
                        notesResponse.add(noteResponse);
                    });
        }
        return notesResponse;
    }

    private List<RoDataCreateContact> getContacts(List<RoDataCreateV1Contact> contacts) {
        List<RoDataCreateContact> contactsResponse = new ArrayList<>();
        if (!contacts.isEmpty()) {
            contacts.forEach(
                    contact -> {
                        RoDataCreateContact contactResponse = new RoDataCreateContact();
                        contactResponse.setContactTypeUuid(contact.getContactTypeUuid());
                        contactResponse.setEffectiveFromDateTime(contact.getEffectiveFromDateTime());
                        contactResponse.setFirstName(StringUtils.trimToNull(contact.getFirstName()));
                        contactResponse.setLastName(StringUtils.trimToNull(contact.getLastName()));
                        contactResponse.setTitle(contact.getTitle());
                        contactResponse.setJobTitle(contact.getJobTitle());
                        contactResponse.setEffectiveToDateTime(contact.getEffectiveToDateTime());
                        contactResponse.setAddresses(getAddresses(contact.getAddresses()));
                        contactsResponse.add(contactResponse);
                    });
        }
        return contactsResponse;
    }

    private List<RoDataCreateAddress> getAddresses(List<RoDataCreateV1Address> addresses) {
        List<RoDataCreateAddress> addressesResponse = new ArrayList<>();
        if (!addresses.isEmpty()) {
            addresses.forEach(
                    address -> {
                        RoDataCreateAddress addressResponse = new RoDataCreateAddress();
                        addressResponse.setAddressTypeUuid(address.getAddressTypeUuid());
                        addressResponse.setAddressLine1(address.getAddressLine1());
                        addressResponse.setAddressLine2(address.getAddressLine2());
                        addressResponse.setAddressLine3(address.getAddressLine3());
                        addressResponse.setAddressLine4(address.getAddressLine4());
                        addressResponse.setCity(address.getCity());
                        addressResponse.setTerritoryUuid(address.getTerritoryUuid());
                        addressResponse.setCountryUuid(address.getCountryUuid());
                        addressResponse.setPostalCode(address.getPostalCode());
                        addressResponse.setEmail(address.getEmail());
                        addressResponse.setPhone(address.getPhone());
                        addressesResponse.add(addressResponse);
                    });
        }
        return addressesResponse;
    }

    private List<RoDataCreateMinimumScore> getMinimumScores(
            List<RoDataCreateV1MinimumScore> minimumScores) {
        List<RoDataCreateMinimumScore> minimumScoresResponse = new ArrayList<>();
        if (!minimumScores.isEmpty()) {
            minimumScores.forEach(
                    minimumScore -> {
                        RoDataCreateMinimumScore minimumScoreResponse = new RoDataCreateMinimumScore();
                        minimumScoreResponse.setMinimumScoreValue(minimumScore.getMinimumScoreValue());
                        minimumScoreResponse.setComponent(
                                ComponentEnum.fromValue(
                                        minimumScore.getComponent().getValue()));
                        minimumScoreResponse.setModuleTypeUuid(minimumScore.getModuleTypeUuid());
                        minimumScoresResponse.add(minimumScoreResponse);
                    });
        }
        return minimumScoresResponse;
    }

    private List<RoDataCreateLinkedOrganisation> getLinkedOrganisations(
            List<RoDataCreateV1LinkedOrganisation> linkedOrganisations) {
        List<RoDataCreateLinkedOrganisation> linkedOrganisationsResponse = new ArrayList<>();
        if (!linkedOrganisations.isEmpty()) {
            linkedOrganisations.forEach(
                    linkedOrganisation -> {
                        RoDataCreateLinkedOrganisation linkedOrganisationResponse =
                                new RoDataCreateLinkedOrganisation();
                        linkedOrganisationResponse.setLinkType(
                                LinkTypeEnum.fromValue(
                                        linkedOrganisation.getLinkType().getValue()));
                        linkedOrganisationResponse.setTargetRecognisingOrganisationUuid(
                                linkedOrganisation.getTargetRecognisingOrganisationUuid());
                        linkedOrganisationResponse.setLinkEffectiveFromDateTime(
                                linkedOrganisation.getLinkEffectiveFromDateTime());
                        linkedOrganisationResponse.setLinkEffectiveToDateTime(
                                linkedOrganisation.getLinkEffectiveToDateTime());
                        linkedOrganisationsResponse.add(linkedOrganisationResponse);
                    });
        }
        return linkedOrganisationsResponse;
    }

    @Override
    public String getOutgoingEventName() {
        return ROReceiverConstants.RO_CREATE_REQUEST_OUTGOING_EVENT_NAME;
    }
}
