package com.ielts.cmds.integration.service;

import com.ielts.cmds.api.common.ui_client.RoDataUpdateV1;
import com.ielts.cmds.api.common.ui_client.RoDataUpdateV1Address;
import com.ielts.cmds.api.common.ui_client.RoDataUpdateV1AlternateName;
import com.ielts.cmds.api.common.ui_client.RoDataUpdateV1Contact;
import com.ielts.cmds.api.common.ui_client.RoDataUpdateV1LinkedOrganisation;
import com.ielts.cmds.api.common.ui_client.RoDataUpdateV1MinimumScore;
import com.ielts.cmds.api.common.ui_client.RoDataUpdateV1Note;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdate;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateAddress;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateAlternateName;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateContact;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateLinkedOrganisation;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateMinimumScore;
import com.ielts.cmds.api.roui009roupdaterequested.RoDataUpdateNote;
import com.ielts.cmds.api.roui009roupdaterequested.OrganisationStatusEnum;
import com.ielts.cmds.api.roui009roupdaterequested.VerificationStatusEnum;
import com.ielts.cmds.api.roui009roupdaterequested.MethodOfDeliveryEnum;
import com.ielts.cmds.api.roui009roupdaterequested.LinkTypeEnum;
import com.ielts.cmds.api.roui009roupdaterequested.ComponentEnum;
import com.ielts.cmds.integration.constants.ROReceiverConstants;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class ROUpdateService implements IReceiverService<RoDataUpdateV1, RoDataUpdate> {

	@Override
	public RoDataUpdate process(final RoDataUpdateV1 eventBody) {
		final RoDataUpdate roDataUpdate = new RoDataUpdate();
		roDataUpdate.setRecognisingOrganisationUuid(eventBody.getRecognisingOrganisationUuid());
		roDataUpdate.setOrganisationName(eventBody.getOrganisationName());
		roDataUpdate.setOrganisationTypeUuid(eventBody.getOrganisationTypeUuid());
		roDataUpdate.setVerificationStatus(
				VerificationStatusEnum.fromValue(eventBody.getVerificationStatus().getValue()));
		roDataUpdate.setPartnerCode(eventBody.getPartnerCode());
		roDataUpdate.setPartnerContact(eventBody.getPartnerContact());
		roDataUpdate.setMethodOfDelivery(
				MethodOfDeliveryEnum.fromValue(eventBody.getMethodOfDelivery().getValue()));
		roDataUpdate.setSectorTypeUuid(eventBody.getSectorTypeUuid());
		roDataUpdate.setOrganisationStatus(
				OrganisationStatusEnum.fromValue(eventBody.getOrganisationStatus().getValue()));
		roDataUpdate.setWebsiteUrl(eventBody.getWebsiteUrl());
		roDataUpdate.setCrmSystem(eventBody.getCrmSystem());
		roDataUpdate.setOrganisationCode(eventBody.getOrganisationCode());
		roDataUpdate.setResultAvailableForYears(eventBody.getResultAvailableForYears());
		roDataUpdate.setIeltsDisplayFlag(eventBody.getIeltsDisplayFlag());
		roDataUpdate.setOrsDisplayFlag(eventBody.getOrsDisplayFlag());
		roDataUpdate.setAcceptsIOL(eventBody.getAcceptsIOL());
		roDataUpdate.setAcceptsSSR(eventBody.getAcceptsSSR());
		roDataUpdate.setAcceptsAC(eventBody.getAcceptsAC());
		roDataUpdate.setAcceptsGT(eventBody.getAcceptsGT());
		roDataUpdate.setAddresses(getAddresses(eventBody.getAddresses()));
		if(eventBody.getNotes() != null){
		roDataUpdate.setNotes(getNotes(eventBody.getNotes()));
		}
		if(eventBody.getAlternateNames() != null) {
			roDataUpdate.setAlternateNames(getAlternateNames(eventBody.getAlternateNames()));
		}
		roDataUpdate.setContacts(getContacts(eventBody.getContacts()));
		roDataUpdate.setMinimumScores(getMinimumScores(eventBody.getMinimumScores()));
		roDataUpdate.setLinkedOrganisations(getLinkedOrganisations(eventBody.getLinkedOrganisations()));
		return roDataUpdate;
	}

	private List<RoDataUpdateAlternateName> getAlternateNames(
			List<RoDataUpdateV1AlternateName> alternateNames) {
		List<RoDataUpdateAlternateName> alternateNamesResponse = new ArrayList<>();
		if (!alternateNames.isEmpty()) {
			alternateNames.forEach(
					alternateName -> {
						RoDataUpdateAlternateName alternateNameResponse = new RoDataUpdateAlternateName();
						alternateNameResponse.setName(alternateName.getName());
						alternateNameResponse.setAlternateNameUuid(alternateName.getAlternateNameUuid());
						alternateNamesResponse.add(alternateNameResponse);
					});
		}
		return alternateNamesResponse;
	}

	private List<RoDataUpdateNote> getNotes(List<RoDataUpdateV1Note> notes) {
		List<RoDataUpdateNote> notesResponse = new ArrayList<>();
		if (!notes.isEmpty()) {
			notes.forEach(
					note -> {
						RoDataUpdateNote noteResponse = new RoDataUpdateNote();
						noteResponse.setNoteUuid(note.getNoteUuid());
						noteResponse.setNoteContent(note.getNoteContent());
						noteResponse.setNoteTypeUuid(note.getNoteTypeUuid());
						notesResponse.add(noteResponse);
					});
		}
		return notesResponse;
	}

	private List<RoDataUpdateContact> getContacts(List<RoDataUpdateV1Contact> contacts) {
		List<RoDataUpdateContact> contactsResponse = new ArrayList<>();
		if (!contacts.isEmpty()) {
			contacts.forEach(
					contact -> {
						RoDataUpdateContact contactResponse = new RoDataUpdateContact();
						contactResponse.setContactUuid(contact.getContactUuid());
						contactResponse.setContactTypeUuid(contact.getContactTypeUuid());
						contactResponse.setEffectiveFromDateTime(contact.getEffectiveFromDateTime());
						contactResponse.setFirstName(StringUtils.trimToNull(contact.getFirstName()));
						contactResponse.setTitle(contact.getTitle());
						contactResponse.setLastName(StringUtils.trimToNull(contact.getLastName()));
						contactResponse.setJobTitle(contact.getJobTitle());
						contactResponse.setEffectiveToDateTime(contact.getEffectiveToDateTime());
						contactResponse.setAddresses(getAddresses(contact.getAddresses()));
						contactsResponse.add(contactResponse);
					});
		}
		return contactsResponse;
	}

	private List<RoDataUpdateAddress> getAddresses(List<RoDataUpdateV1Address> addresses) {
		List<RoDataUpdateAddress> addressesResponse = new ArrayList<>();
		if (!addresses.isEmpty()) {
			addresses.forEach(
					address -> {
						RoDataUpdateAddress addressResponse = new RoDataUpdateAddress();
						addressResponse.setAddressUuid(address.getAddressUuid());
						addressResponse.setAddressTypeUuid(address.getAddressTypeUuid());
						addressResponse.setAddressLine1(address.getAddressLine1());
						addressResponse.setAddressLine2(address.getAddressLine2());
						addressResponse.setAddressLine3(address.getAddressLine3());
						addressResponse.setAddressLine4(address.getAddressLine4());
						addressResponse.setCity(address.getCity());
						addressResponse.setTerritoryUuid(address.getTerritoryUuid());
						addressResponse.setCountryUuid(address.getCountryUuid());
						addressResponse.setPostalCode(address.getPostalCode());
						addressResponse.setEmail(address.getEmail());
						addressResponse.setPhone(address.getPhone());
						addressesResponse.add(addressResponse);
					});
		}
		return addressesResponse;
	}

	private List<RoDataUpdateMinimumScore> getMinimumScores(
			List<RoDataUpdateV1MinimumScore> minimumScores) {
		List<RoDataUpdateMinimumScore> minimumScoresResponse = new ArrayList<>();
		if (!minimumScores.isEmpty()) {
			minimumScores.forEach(
					minimumScore -> {
						RoDataUpdateMinimumScore minimumScoreResponse = new RoDataUpdateMinimumScore();
						minimumScoreResponse.setMinimumScoreUuid(minimumScore.getMinimumScoreUuid());
						minimumScoreResponse.setMinimumScoreValue(minimumScore.getMinimumScoreValue());
						minimumScoreResponse.setComponent(
								ComponentEnum.fromValue(
										minimumScore.getComponent().getValue()));
						minimumScoreResponse.setModuleTypeUuid(minimumScore.getModuleTypeUuid());
						minimumScoresResponse.add(minimumScoreResponse);
					});
		}
		return minimumScoresResponse;
	}

	private List<RoDataUpdateLinkedOrganisation> getLinkedOrganisations(
			List<RoDataUpdateV1LinkedOrganisation> linkedOrganisations) {
		List<RoDataUpdateLinkedOrganisation> linkedOrganisationsResponse = new ArrayList<>();
		if (!linkedOrganisations.isEmpty()) {
			linkedOrganisations.forEach(
					linkedOrganisation -> {
						RoDataUpdateLinkedOrganisation linkedOrganisationResponse =
								new RoDataUpdateLinkedOrganisation();
						linkedOrganisationResponse.setLinkedRecognisingOrganisationUuid(
								linkedOrganisation.getLinkedRecognisingOrganisationUuid());
						linkedOrganisationResponse.setLinkType(
								LinkTypeEnum.fromValue(
										linkedOrganisation.getLinkType().getValue()));
						linkedOrganisationResponse.setTargetRecognisingOrganisationUuid(
								linkedOrganisation.getTargetRecognisingOrganisationUuid());
						linkedOrganisationResponse.setLinkEffectiveFromDateTime(
								linkedOrganisation.getLinkEffectiveFromDateTime());
						linkedOrganisationResponse.setLinkEffectiveToDateTime(
								linkedOrganisation.getLinkEffectiveToDateTime());
						linkedOrganisationsResponse.add(linkedOrganisationResponse);
					});
		}
		return linkedOrganisationsResponse;
	}

	@Override
	public String getOutgoingEventName() {
		return ROReceiverConstants.RO_UPDATE_REQUEST_OUTGOING_EVENT_NAME;
	}
}
