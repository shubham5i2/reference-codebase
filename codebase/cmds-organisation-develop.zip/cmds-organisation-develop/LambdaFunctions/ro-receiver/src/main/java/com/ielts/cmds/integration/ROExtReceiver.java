package com.ielts.cmds.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.common.utils.CMDSCommonUtils;
import com.ielts.cmds.integration.constants.ROReceiverConstants;
import com.ielts.cmds.integration.service.ROProcessService;
import com.ielts.cmds.serialization.lambda.AbstractReceiverLambda;
import com.ielts.cmds.serialization.lambda.mapper.IObjectMapper;
import com.ielts.cmds.serialization.lambda.receiver.service.AbstractServiceFactory;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.Map;

@NoArgsConstructor
public class ROExtReceiver extends AbstractReceiverLambda implements IObjectMapper {

	private ObjectMapper mapper;

	@Override
	public AbstractServiceFactory getServiceFactory() {
		@SuppressWarnings("rawtypes")
		final Map<String, IReceiverService> initServices = new HashMap<>();
		this.mapper = getMapperWithProperties();
		initServices.put("GET/v1/ros/process", new ROProcessService());
		return new ReceiverServiceFactory(initServices);
	}

	@Override
	public String getTopicArn() {
		return System.getenv(ROReceiverConstants.RO_EXT_TOPIC_IN);
	}

	@Override
	protected String getPartnerCode() {
		return CMDSCommonUtils.getDataFromClaims(
				ThreadLocalHeaderContext.getContext().getXaccessToken(),
				ROReceiverConstants.PARTNER_CODE);
	}
}
