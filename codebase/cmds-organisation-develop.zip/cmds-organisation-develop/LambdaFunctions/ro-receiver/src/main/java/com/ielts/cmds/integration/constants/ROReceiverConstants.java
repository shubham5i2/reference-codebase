package com.ielts.cmds.integration.constants;

public final class ROReceiverConstants {

    private ROReceiverConstants() {}

    public static final String RO = "RO";
    public static final String PARTNER_CODE = "partnerCode";
    public static final String RO_UI_TOPIC_IN = "ro_ui_topic_in_arn";
    public static final String RO_EXT_TOPIC_IN = "ro_ext_topic_in_arn";

    public static final String RO_CREATE_REQUEST_OUTGOING_EVENT_NAME = "RoCreateRequest";
    public static final String RO_UPDATE_REQUEST_OUTGOING_EVENT_NAME = "RoUpdateRequest";
    public static final String RO_SEARCH_REQUEST_OUTGOING_EVENT_NAME = "RoSearchRequest";
    public static final String RO_DETAILS_REQUEST_OUTGOING_EVENT_NAME = "RoDetailsRequest";
    public static final String RO_PROCESS_REQUEST_OUTGOING_EVENT_NAME = "RoProcessRequest";
    public static final String RO_HIERARCHY_SEARCH_REQUEST_OUTGOING_EVENT_NAME = "RoHierarchySearchRequest";
    public static final String RO_SEARCH_ORG_ID_REQUEST_OUTGOING_EVENT_NAME = "RoSearchByOrgIdRequest";

}
