package com.ielts.cmds.integration.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.roui008rodetailsrequested.RODetailsRequestParams;
import com.ielts.cmds.serialization.lambda.receiver.service.RequestWithParamsReceiverService;
import com.ielts.cmds.integration.constants.ROReceiverConstants;

public class RODetailsService extends RequestWithParamsReceiverService<RODetailsRequestParams> {

    public RODetailsService(ObjectMapper mapper) {
        super(mapper);
    }

    @Override
    public String getOutgoingEventName() {

        return ROReceiverConstants.RO_DETAILS_REQUEST_OUTGOING_EVENT_NAME;
    }

}