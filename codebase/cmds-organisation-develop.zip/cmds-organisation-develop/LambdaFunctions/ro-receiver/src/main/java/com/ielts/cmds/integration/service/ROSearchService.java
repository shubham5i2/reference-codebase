package com.ielts.cmds.integration.service;

import com.ielts.cmds.api.common.ui_client.RoSearchV1;
import com.ielts.cmds.api.common.ui_client.RoSearchV1Criteria;
import com.ielts.cmds.api.common.ui_client.SearchPaginationV1;
import com.ielts.cmds.api.common.ui_client.SearchSortV1Item;
import com.ielts.cmds.api.roui005rosearchrequested.RoSearchObject;
import com.ielts.cmds.api.roui005rosearchrequested.RoSearchCriteria;
import com.ielts.cmds.api.roui005rosearchrequested.SearchPagination;
import com.ielts.cmds.api.roui005rosearchrequested.SearchSortItem;
import com.ielts.cmds.api.roui005rosearchrequested.OrganisationStatusEnum;
import com.ielts.cmds.api.roui005rosearchrequested.VerificationStatusEnum;
import com.ielts.cmds.integration.constants.ROReceiverConstants;
import com.ielts.cmds.serialization.lambda.receiver.service.IReceiverService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Slf4j
public class ROSearchService implements IReceiverService<RoSearchV1, RoSearchObject> {

  @Override
  public RoSearchObject process(final RoSearchV1 eventBody) {
    final RoSearchObject roSearchObject = new RoSearchObject();
    roSearchObject.setCriteria(getSearchCriteria(eventBody.getCriteria()));
    roSearchObject.setPagination(getSearchPagination(eventBody.getPagination()));
    roSearchObject.setSorting(getSearchSortItems(eventBody.getSorting()));
    return roSearchObject;
  }

  private RoSearchCriteria getSearchCriteria(RoSearchV1Criteria roSearchV1Criteria) {
    RoSearchCriteria roSearchCriteria = new RoSearchCriteria();
    roSearchCriteria.setOrganisationName(roSearchV1Criteria.getOrganisationName());
    roSearchCriteria.setOrganisationId(roSearchV1Criteria.getOrganisationId());
    roSearchCriteria.setContactName(roSearchV1Criteria.getContactName());
    if (null != roSearchV1Criteria.getOrganisationStatus() && StringUtils.isNotEmpty(roSearchV1Criteria.getOrganisationStatus().getValue())) {
      roSearchCriteria.setOrganisationStatus(OrganisationStatusEnum.valueOf(roSearchV1Criteria.getOrganisationStatus().getValue()));
    }
    if (null != roSearchV1Criteria.getVerificationStatus() && StringUtils.isNotEmpty(roSearchV1Criteria.getVerificationStatus().getValue())) {
      roSearchCriteria.setVerificationStatus(VerificationStatusEnum.valueOf(roSearchV1Criteria.getVerificationStatus().getValue()));
    }
    roSearchCriteria.setOrganisationTypeUuid(roSearchV1Criteria.getOrganisationTypeUuid());
    roSearchCriteria.setCity(roSearchV1Criteria.getCity());
    roSearchCriteria.setPostalCode(roSearchV1Criteria.getPostalCode());
    roSearchCriteria.setContactEmail(roSearchV1Criteria.getContactEmail());
    roSearchCriteria.setPartnerCode(roSearchV1Criteria.getPartnerCode());
    roSearchCriteria.setCountry(roSearchV1Criteria.getCountry());
    roSearchCriteria.setFuzzyMatch(roSearchV1Criteria.getFuzzyMatch());
    roSearchCriteria.setTerritory(roSearchV1Criteria.getTerritory());
    return roSearchCriteria;
  }

  private SearchPagination getSearchPagination(SearchPaginationV1 searchPaginationV1) {
    SearchPagination searchPagination = new SearchPagination();
    searchPagination.setPageNumber(searchPaginationV1.getPageNumber());
    searchPagination.setPageSize(searchPaginationV1.getPageSize());
    return searchPagination;
  }

  private List<SearchSortItem> getSearchSortItems(List<SearchSortV1Item> sortItems) {
    List<SearchSortItem> searchSortItemsResponse = new ArrayList<>();
    if (Objects.nonNull(sortItems)) {
      sortItems.forEach(
          sortItem -> {
            SearchSortItem searchSortItemResponse = new SearchSortItem();
            searchSortItemResponse.setSortBy(sortItem.getSortBy());
            searchSortItemResponse.setSortType(sortItem.getSortType());
            searchSortItemsResponse.add(searchSortItemResponse);
          });
    }
    return searchSortItemsResponse;
  }

  @Override
  public String getOutgoingEventName() {
    return ROReceiverConstants.RO_SEARCH_REQUEST_OUTGOING_EVENT_NAME;
  }
}
