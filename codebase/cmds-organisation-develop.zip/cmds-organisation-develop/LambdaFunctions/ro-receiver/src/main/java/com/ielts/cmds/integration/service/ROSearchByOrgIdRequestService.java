package com.ielts.cmds.integration.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ielts.cmds.api.roui011rodetailsbyorgidrequested.RODetailsByOrgIdRequestParam;
import com.ielts.cmds.serialization.lambda.receiver.service.RequestWithParamsReceiverService;
import com.ielts.cmds.integration.constants.ROReceiverConstants;

public class ROSearchByOrgIdRequestService extends RequestWithParamsReceiverService<RODetailsByOrgIdRequestParam> {

    public ROSearchByOrgIdRequestService (ObjectMapper mapper) {

        super(mapper);
    }

    @Override
    public String getOutgoingEventName() {
        return ROReceiverConstants.RO_SEARCH_ORG_ID_REQUEST_OUTGOING_EVENT_NAME;
    }

}
