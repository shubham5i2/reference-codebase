package com.ielts.cmds.integration;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.amazonaws.services.lambda.runtime.events.SQSEvent.SQSMessage;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.integration.exception.ROChangedDistLAException;
import com.ielts.cmds.integration.model.MessageV1;
import com.ielts.cmds.integration.util.ROChangedDistLaConstants;
import com.ielts.cmds.organisation.common.enums.MethodOfDeliveryEnum;
import com.ielts.cmds.organisation.common.enums.OrganisationStatusEnum;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@ExtendWith(MockitoExtension.class)
class ROChangedDistLaTest {

    @Spy private ObjectMapper objectMapper;

    @Mock private Context context;

    @Spy private ROChangedDistLa roChangedDistLa;

    @Mock AuthenticationClient authenticationClient;

    @Mock ResponseEntity<String> response;

    @Mock private EnvironmentAwareAuthenticationClientFactory securityAuthenticationFactory;

    private SQSEvent event, event2;
    private SQSMessage message, message2;

    private TypeReference<BaseEvent<UiHeader>> typeRef;

    @Mock private RestTemplate restTemplate;
    SQSEvent event1;

    @BeforeEach
    public void setUp() throws JsonProcessingException {
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        objectMapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        objectMapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
        typeRef = new TypeReference<BaseEvent<UiHeader>>() {};
        String eventBody = SQSEventDataSetup.getEventRequest();
        message = new SQSMessage();
        message.setBody(eventBody);
        List<SQSMessage> records = new ArrayList<>();
        records.add(message);
        event = new SQSEvent();
        event.setRecords(records);
        ReflectionTestUtils.setField(
                roChangedDistLa, "securityAuthenticationFactory", securityAuthenticationFactory);
        ReflectionTestUtils.setField(roChangedDistLa, "mapper", objectMapper);
    }

    @Test
    void whenRequestHasValidAuthenticationHeader_ThenVerifyCallToRestTemplate() throws Exception {
        Map<String, String> map = new HashMap<>();
        map.put(
                ROChangedDistLaConstants.ACCESS_TOKEN,
                SQSEventDataSetup.getEnvironmentVariablesStub()
                        .get(ROChangedDistLaConstants.ACCESS_TOKEN));
        map.put(ROChangedDistLaConstants.AUTH_HEADER, ROChangedDistLaConstants.AUTH_HEADER_NAME);
        ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.OK);
        doReturn(authenticationClient)
                .when(securityAuthenticationFactory)
                .getAuthenticationClient("CA");
        HttpHeaders httpHeaders = getHttpHeaders(authenticationClient);
        httpHeaders.set(
                map.get(ROChangedDistLaConstants.AUTH_HEADER),
                map.get(ROChangedDistLaConstants.ACCESS_TOKEN));
        doReturn(map.get(ROChangedDistLaConstants.AUTH_HEADER))
                .when(authenticationClient)
                .getAuthorizationHeaderName();
        doReturn(map.get(ROChangedDistLaConstants.ACCESS_TOKEN))
                .when(authenticationClient)
                .getAccessToken();
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        String url = "http://35.178.179.164:8105/romaster";
        doReturn(url).when(roChangedDistLa).getLAEndpointUrl();
        MessageV1 msg = SQSEventDataSetup.mockCMDSMessage();
        HttpEntity<?> eventEntity = new HttpEntity<>(msg, httpHeaders);
        doReturn(response2).when(restTemplate).postForEntity(url, eventEntity, String.class);
        // Execute and assert test
        assertDoesNotThrow(() -> roChangedDistLa.handleRequest(event, context));
        assertEquals(2, msg.getMsg().get(0).getLinkedOrganisations().size());
        assertEquals(
                "41dfca9e-5308-40a7-a3db-7c9b1ae78bc5",
                msg.getMsg()
                        .get(0)
                        .getLinkedOrganisations()
                        .get(0)
                        .getLinkedRecognisingOrganisationUuid());
        assertEquals(
                "1f50ca55-3800-48c7-8f30-0723f5fac264",
                msg.getMsg()
                        .get(0)
                        .getLinkedOrganisations()
                        .get(0)
                        .getTargetRecognisingOrganisationUuid());
        assertEquals(
                "PARENT_RO", msg.getMsg().get(0).getLinkedOrganisations().get(0).getLinkType());
        assertEquals(
                "2020-11-23T05:52:55Z",
                String.valueOf(
                        msg.getMsg()
                                .get(0)
                                .getLinkedOrganisations()
                                .get(0)
                                .getLinkEffectiveFromDateTime()));
        assertEquals(
                "2020-12-23T00:00:00Z",
                String.valueOf(
                        msg.getMsg()
                                .get(0)
                                .getLinkedOrganisations()
                                .get(0)
                                .getLinkEffectiveToDateTime()));
    }

    @Test
    void whenRequestHasValidAuthenticationHeader_ThenVerifyMethodOfDelivery() throws Exception {
        Map<String, String> map = new HashMap<>();
        map.put(
                ROChangedDistLaConstants.ACCESS_TOKEN,
                SQSEventDataSetup.getEnvironmentVariablesStub()
                        .get(ROChangedDistLaConstants.ACCESS_TOKEN));
        map.put(ROChangedDistLaConstants.AUTH_HEADER, ROChangedDistLaConstants.AUTH_HEADER_NAME);
        ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.OK);
        doReturn(authenticationClient)
                .when(securityAuthenticationFactory)
                .getAuthenticationClient("CA");
        HttpHeaders httpHeaders = getHttpHeaders(authenticationClient);
        httpHeaders.set(
                map.get(ROChangedDistLaConstants.AUTH_HEADER),
                map.get(ROChangedDistLaConstants.ACCESS_TOKEN));
        doReturn(map.get(ROChangedDistLaConstants.AUTH_HEADER))
                .when(authenticationClient)
                .getAuthorizationHeaderName();
        doReturn(map.get(ROChangedDistLaConstants.ACCESS_TOKEN))
                .when(authenticationClient)
                .getAccessToken();
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        String url = "http://35.178.179.164:8105/romaster";
        doReturn(url).when(roChangedDistLa).getLAEndpointUrl();
        MessageV1 msg = SQSEventDataSetup.mockCMDSMessage();
        msg.getMsg().get(0).getRoData().setDownloadSubscription(1);
        msg.getMsg().get(0).getRoData().setIsDeleted(1);
        HttpEntity<?> eventEntity = new HttpEntity<>(msg, httpHeaders);
        doReturn(response2).when(restTemplate).postForEntity(url, eventEntity, String.class);

        String eventBody = SQSEventDataSetup.getEventRequest();
        BaseEvent<? extends BaseHeader> baseEvent = objectMapper.readValue(eventBody, typeRef);
        RoChangedEventV1 eventV1 =
                objectMapper.readValue(baseEvent.getEventBody(), RoChangedEventV1.class);
        eventV1.setMethodOfDelivery(MethodOfDeliveryEnum.E_DELIVERY);
        eventV1.setOrganisationStatus(OrganisationStatusEnum.INACTIVE);
        String eventBodyString = objectMapper.writeValueAsString(eventV1);
        baseEvent.setEventBody(eventBodyString);
        String baseEventString = objectMapper.writeValueAsString(baseEvent);
        message2 = new SQSMessage();
        message2.setBody(baseEventString);
        List<SQSMessage> records2 = new ArrayList<>();
        records2.add(message2);
        event2 = new SQSEvent();
        event2.setRecords(records2);
        assertDoesNotThrow(() -> roChangedDistLa.handleRequest(event2, context));
    }
    /**
     * Method to validate handle request Illegal Argument Exception scenario
     *
     * @param event
     * @param cmdsEvent
     * @throws JsonProcessingException
     */
    @Test
    void handleRequest_ExpectIllegalArgumentExceptionToBeThrown() throws JsonProcessingException {
        message.setBody("///");
        List<SQSMessage> records = new ArrayList<>();
        records.add(message);
        event.setRecords(records);
        assertThrows(
                IllegalArgumentException.class,
                () -> roChangedDistLa.handleRequest(event, context));
    }

    @Test
    void whenRequestNotSentCorrectly_ThenVerifyStatusCode() throws Exception {
        Map<String, String> map = new HashMap<>();
        map.put(
                ROChangedDistLaConstants.ACCESS_TOKEN,
                SQSEventDataSetup.getEnvironmentVariablesStub()
                        .get(ROChangedDistLaConstants.ACCESS_TOKEN));
        map.put(ROChangedDistLaConstants.AUTH_HEADER, ROChangedDistLaConstants.AUTH_HEADER_NAME);
        ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        doReturn(authenticationClient)
                .when(securityAuthenticationFactory)
                .getAuthenticationClient("CA");
        HttpHeaders httpHeaders = getHttpHeaders(authenticationClient);
        httpHeaders.set(
                map.get(ROChangedDistLaConstants.AUTH_HEADER),
                map.get(ROChangedDistLaConstants.ACCESS_TOKEN));
        doReturn(map.get(ROChangedDistLaConstants.AUTH_HEADER))
                .when(authenticationClient)
                .getAuthorizationHeaderName();
        doReturn(map.get(ROChangedDistLaConstants.ACCESS_TOKEN))
                .when(authenticationClient)
                .getAccessToken();
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        String url = "http://35.178.179.164:8105/romaster";
        doReturn(url).when(roChangedDistLa).getLAEndpointUrl();
        MessageV1 msg = SQSEventDataSetup.mockCMDSMessage();
        HttpEntity<?> eventEntity = new HttpEntity<>(msg, httpHeaders);
        doReturn(response2).when(restTemplate).postForEntity(url, eventEntity, String.class);
        // Execute and assert test
        assertThrows(
                ROChangedDistLAException.class,
                () -> roChangedDistLa.handleRequest(event, context));
    }

    @Test
    void whenRequestisInValid_ThenVerifyStatusCode() throws Exception {
        Map<String, String> map = new HashMap<>();
        map.put(
                ROChangedDistLaConstants.ACCESS_TOKEN,
                SQSEventDataSetup.getEnvironmentVariablesStub()
                        .get(ROChangedDistLaConstants.ACCESS_TOKEN));
        map.put(ROChangedDistLaConstants.AUTH_HEADER, ROChangedDistLaConstants.AUTH_HEADER_NAME);
        ResponseEntity<String> response2 = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        doReturn(authenticationClient)
                .when(securityAuthenticationFactory)
                .getAuthenticationClient("CA");
        HttpHeaders httpHeaders = getHttpHeaders(authenticationClient);
        doReturn(map.get(ROChangedDistLaConstants.AUTH_HEADER))
                .when(authenticationClient)
                .getAuthorizationHeaderName();
        doReturn(map.get(ROChangedDistLaConstants.ACCESS_TOKEN))
                .when(authenticationClient)
                .getAccessToken();
        httpHeaders.set(
                map.get(ROChangedDistLaConstants.AUTH_HEADER),
                map.get(ROChangedDistLaConstants.ACCESS_TOKEN));
        doReturn(restTemplate).when(authenticationClient).getRestTemplate();
        String url = "http://35.178.179.164:8105/romaster";
        doReturn(url).when(roChangedDistLa).getLAEndpointUrl();
        MessageV1 msg = SQSEventDataSetup.mockCMDSMessage();
        HttpEntity<?> eventEntity = new HttpEntity<>(msg, httpHeaders);
        doReturn(response2).when(restTemplate).postForEntity(url, eventEntity, String.class);
        // Execute and assert test
        assertThrows(
                ROChangedDistLAException.class,
                () -> roChangedDistLa.handleRequest(event, context));
    }

    @Test
    void whenRequestNotSentWithToken_ThenVerifyStatusCode() throws Exception {
        Map<String, String> map = new HashMap<>();
        map.put(
                ROChangedDistLaConstants.ACCESS_TOKEN,
                SQSEventDataSetup.getEnvironmentVariablesStub()
                        .get(ROChangedDistLaConstants.ACCESS_TOKEN));
        map.put(ROChangedDistLaConstants.AUTH_HEADER, ROChangedDistLaConstants.AUTH_HEADER_NAME);
        doReturn(authenticationClient)
                .when(securityAuthenticationFactory)
                .getAuthenticationClient("CA");
        HttpHeaders httpHeaders = getHttpHeaders(authenticationClient);
        doReturn(map.get(ROChangedDistLaConstants.AUTH_HEADER))
                .when(authenticationClient)
                .getAuthorizationHeaderName();
        doThrow(RestClientException.class).when(authenticationClient).getRestTemplate();
        httpHeaders.set(
                map.get(ROChangedDistLaConstants.AUTH_HEADER),
                map.get(ROChangedDistLaConstants.ACCESS_TOKEN));
        // Execute and assert test
        assertThrows(
                ROChangedDistLAException.class,
                () -> roChangedDistLa.handleRequest(event, context));
    }

    @Test
    void testWhenTransactionIdIsNull_thenVerifyException() throws JsonProcessingException {
        String eventBody = SQSEventDataSetup.getEventRequest();
        BaseEvent<? extends BaseHeader> baseEvent = objectMapper.readValue(eventBody, typeRef);
        baseEvent.getEventHeader().setTransactionId(null);
        eventBody = objectMapper.writeValueAsString(baseEvent);
        message.setBody(eventBody);
        List<SQSMessage> records = new ArrayList<>();
        records.add(message);
        event.setRecords(records);
        assertThrows(
                IllegalArgumentException.class,
                () -> roChangedDistLa.handleRequest(event, context));
    }

    /**
     * Method to test generate error response
     *
     * @throws JsonProcessingException
     */
    @Test
    void generateAndLogErrorResponse_ExpectErrorResponseToBePopulated()
            throws JsonProcessingException {
        String eventBody = SQSEventDataSetup.getEventRequest();
        BaseEvent<? extends BaseHeader> cmdsEvent = objectMapper.readValue(eventBody, typeRef);
        List<ErrorDescription> actual =
                roChangedDistLa.generateAndLogErrorResponse(
                        cmdsEvent.getEventHeader(), new Exception("message"));
        List<ErrorDescription> expectedErrorResponse = new ArrayList<>();
        Source source = new Source("message", "ROChangedDistLaLambda");
        ErrorDescription errorDescription = new ErrorDescription();
        errorDescription.setInterfaceName(ROChangedDistLaConstants.RO_CHANGED_DIST_LA_LAMBDA);
        errorDescription.setMessage("message");
        errorDescription.setTitle(ROChangedDistLaConstants.EXCEPTION_MESSAGE_PROCESSING);
        errorDescription.setType(ErrorTypeEnum.ERROR);
        errorDescription.setErrorTicketUuid(null);
        errorDescription.setErrorCode("RoChanged");

        errorDescription.setSource(source);

        expectedErrorResponse.add(errorDescription);
        assertEquals(1, actual.size());
        assertEquals(expectedErrorResponse.get(0), actual.get(0));
    }

    private HttpHeaders getHttpHeaders(AuthenticationClient authenticationClient) {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        return httpHeaders;
    }
}
