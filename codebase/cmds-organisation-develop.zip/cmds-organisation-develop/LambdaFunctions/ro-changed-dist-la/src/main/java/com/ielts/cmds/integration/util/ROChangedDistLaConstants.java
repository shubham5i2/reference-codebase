package com.ielts.cmds.integration.util;

public class ROChangedDistLaConstants {

    private ROChangedDistLaConstants() {}

    public static final String RO_CHANGED_DIST_LA_LAMBDA = "ROChangedDistLaLambda";
    public static final String MAIN_ADDRESS_TYPE = "Main";
    public static final String RESULTS_ADMIN_CONTACT_TYPE = "Results Admin";
    public static final String EXCEPTION_MESSAGE_PROCESSING = "Processing Issue";
    public static final String CALLBACK_URL = "callback_url";
    public static final String CLIENT_ID = "client_id";
    public static final String CLIENT_SECRET = "client_secret";
    public static final String AUTH_HEADER = "auth_header";
    public static final String AUTH_HEADER_NAME = "Authentication";
    public static final String ACCESS_TOKEN = "access_token";
    public static final String RO = "RO";
}
