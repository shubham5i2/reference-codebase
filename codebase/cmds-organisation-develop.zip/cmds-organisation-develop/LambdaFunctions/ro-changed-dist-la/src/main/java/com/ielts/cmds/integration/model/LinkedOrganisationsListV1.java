package com.ielts.cmds.integration.model;

import java.util.ArrayList;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/** LinkedOrganisationsListV1 */
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class LinkedOrganisationsListV1 extends ArrayList<LinkedOrganisationsDetailsV1> {}
