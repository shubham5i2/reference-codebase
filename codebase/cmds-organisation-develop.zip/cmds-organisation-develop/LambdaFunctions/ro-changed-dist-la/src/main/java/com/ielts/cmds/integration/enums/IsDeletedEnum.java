package com.ielts.cmds.integration.enums;

public enum IsDeletedEnum {
    ZERO(0),
    ONE(1);

    private Integer value;

    IsDeletedEnum(Integer value) {
        this.value = value;
    }

    public Integer getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }
}
