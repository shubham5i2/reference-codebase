package com.ielts.cmds.integration;

import static java.lang.String.format;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.amazonaws.services.lambda.runtime.events.SQSEvent.SQSMessage;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ielts.cmds.common.enums.ErrorTypeEnum;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.common.exception.util.Source;
import com.ielts.cmds.common.logger.util.CMDSLambdaLoggerUtil;
import com.ielts.cmds.infrastructure.event.BaseEvent;
import com.ielts.cmds.infrastructure.event.BaseHeader;
import com.ielts.cmds.infrastructure.event.UiHeader;
import com.ielts.cmds.integration.enums.DownloadSubscriptionEnum;
import com.ielts.cmds.integration.enums.IsDeletedEnum;
import com.ielts.cmds.integration.exception.ROChangedDistLAException;
import com.ielts.cmds.integration.model.LinkedOrganisationsDetailsV1;
import com.ielts.cmds.integration.model.LinkedOrganisationsListV1;
import com.ielts.cmds.integration.model.MessageDetailsV1;
import com.ielts.cmds.integration.model.MessageDetailsV1Inner;
import com.ielts.cmds.integration.model.MessageV1;
import com.ielts.cmds.integration.model.RoDataV1;
import com.ielts.cmds.integration.util.ROChangedDistLaConstants;
import com.ielts.cmds.organisation.common.enums.MethodOfDeliveryEnum;
import com.ielts.cmds.organisation.common.enums.OrganisationStatusEnum;
import com.ielts.cmds.organisation.common.enums.VerificationStatusEnum;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Address;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Addresses;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Contact;
import com.ielts.cmds.security.clients.AuthenticationClient;
import com.ielts.cmds.security.exception.TokenNotReceivedException;
import com.ielts.cmds.security.factory.AuthenticationClientFactory;
import com.ielts.cmds.security.factory.EnvironmentAwareAuthenticationClientFactory;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;

@Slf4j
public class ROChangedDistLa {

    final CMDSLambdaLoggerUtil loggerUtil = new CMDSLambdaLoggerUtil();
    private final ObjectMapper mapper;
    private AuthenticationClientFactory securityAuthenticationFactory;

    public ROChangedDistLa() {
        this.mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, true);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
        this.securityAuthenticationFactory = new EnvironmentAwareAuthenticationClientFactory();
    }

    public void handleRequest(SQSEvent event, Context context) throws Exception {

        BaseEvent<? extends BaseHeader> cmdsEvent = null;

        try {
            for (SQSMessage message : event.getRecords()) {
                String roMessage = message.getBody();
                cmdsEvent = validateMessage(roMessage, mapper);
                initializeLogger(cmdsEvent.getEventHeader(), context);
                log.info(
                        "Event Received in {}:{} with metadata as {}",
                        ROChangedDistLaConstants.RO,
                        ROChangedDistLaConstants.RO_CHANGED_DIST_LA_LAMBDA,
                        cmdsEvent.getEventHeader());
                mapAndSendExternalEvent(cmdsEvent);
            }
        } catch (Exception e) {
            if (cmdsEvent != null) {
                generateAndLogErrorResponse(cmdsEvent.getEventHeader(), e);
            } else {
                log.error("Exception message {} ", ExceptionUtils.getStackTrace(e));
            }
            throw e;
        }
    }

    private void mapAndSendExternalEvent(BaseEvent<? extends BaseHeader> cmdsEvent)
            throws Exception {

        RoChangedEventV1 roChangedEvent =
                mapper.readValue(cmdsEvent.getEventBody(), RoChangedEventV1.class);
        RoDataV1 roData = new RoDataV1();
        roData.setOrganisationId(roChangedEvent.getOrganisationId());
        roData.setName(roChangedEvent.getOrganisationName());
        Optional<RoChangedEventV1Contact> resultsAdminContact =
                roChangedEvent.getContacts().stream()
                        .filter(
                                contact ->
                                        contact.getContactType()
                                                .equals(
                                                        ROChangedDistLaConstants
                                                                .RESULTS_ADMIN_CONTACT_TYPE))
                        .findAny();
        if (MethodOfDeliveryEnum.E_DELIVERY.equals(roChangedEvent.getMethodOfDelivery())) {
            roData.setDownloadSubscription(DownloadSubscriptionEnum.E_DELIVERY.getValue());
        } else {
            roData.setDownloadSubscription(DownloadSubscriptionEnum.POSTAL.getValue());
        }
        resultsAdminContact.ifPresent(
                contact -> {
                    roData.setTitle(resultsAdminContact.get().getTitle());
                    roData.setFirstName(resultsAdminContact.get().getFirstName());
                    roData.setLastName(resultsAdminContact.get().getLastName());
                    Optional<RoChangedEventV1Address> resultAdminAddress =
                            getMainAddressDetails(resultsAdminContact.get().getAddresses());
                    resultAdminAddress.ifPresent(
                            address -> roData.setEmail(resultAdminAddress.get().getEmail()));
                });
        Optional<RoChangedEventV1Address> mainAddress =
                getMainAddressDetails(roChangedEvent.getAddresses());
        mainAddress.ifPresent(address -> setData(roData, address));
        if (OrganisationStatusEnum.ACTIVE.equals(roChangedEvent.getOrganisationStatus())
                && VerificationStatusEnum.APPROVED.equals(roChangedEvent.getVerificationStatus())) {
            roData.setIsDeleted(IsDeletedEnum.ZERO.getValue());
        } else {
            roData.setIsDeleted(IsDeletedEnum.ONE.getValue());
        }
        MessageDetailsV1Inner messageDetails = new MessageDetailsV1Inner();
        messageDetails.setRecId(roChangedEvent.getRecognisingOrganisationUuid().toString());
        messageDetails.setRoData(roData);
        messageDetails.setLinkedOrganisations(setLinkedOrganisationsData(roChangedEvent));
        MessageDetailsV1 msgDetailsList = new MessageDetailsV1();
        msgDetailsList.add(messageDetails);
        MessageV1 msg = new MessageV1();
        msg.setMsg(msgDetailsList);
        log.debug("Request Body to LA: {}", mapper.writeValueAsString(msg));
        postRequestToExternalAPI(msg, cmdsEvent);
    }

    private LinkedOrganisationsListV1 setLinkedOrganisationsData(RoChangedEventV1 roChangedEvent) {
        LinkedOrganisationsListV1 linkedOrganisationsListV1 = new LinkedOrganisationsListV1();
        roChangedEvent
                .getLinkedOrganisations()
                .forEach(
                        linkedOrganisation -> {
                            LinkedOrganisationsDetailsV1 details =
                                    new LinkedOrganisationsDetailsV1();
                            details.setLinkedRecognisingOrganisationUuid(
                                    String.valueOf(
                                            linkedOrganisation
                                                    .getLinkedRecognisingOrganisationUuid()));
                            details.setTargetRecognisingOrganisationUuid(
                                    String.valueOf(
                                            linkedOrganisation
                                                    .getTargetRecognisingOrganisationUuid()));
                            details.setLinkType(String.valueOf(linkedOrganisation.getLinkType()));
                            DateTimeFormatter formatter =
                                    DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
                            String formattedFromDateTime =
                                    linkedOrganisation
                                            .getLinkEffectiveFromDateTime()
                                            .format(formatter);
                            details.setLinkEffectiveFromDateTime(formattedFromDateTime);
                            String formattedToDateTime =
                                    linkedOrganisation
                                            .getLinkEffectiveToDateTime()
                                            .format(formatter);
                            details.setLinkEffectiveToDateTime(formattedToDateTime);
                            linkedOrganisationsListV1.add(details);
                        });
        return linkedOrganisationsListV1;
    }

    private void setData(RoDataV1 roData, RoChangedEventV1Address mainAddress) {
        roData.setPhoneNo(mainAddress.getPhone());
        roData.setCountryIsoCode(mainAddress.getCountryIso3Code());
        roData.setAddressLine1(mainAddress.getAddressLine1());
        roData.setAddressLine2(mainAddress.getAddressLine2());
        roData.setAddressLine3(mainAddress.getAddressLine3());
        roData.setAddressLine4(mainAddress.getAddressLine4());
    }

    private void postRequestToExternalAPI(
            MessageV1 requestMsg, BaseEvent<? extends BaseHeader> cmdsEvent) throws Exception {

        AuthenticationClient authenticationClient =
                securityAuthenticationFactory.getAuthenticationClient("CA");
        UUID transactionId = cmdsEvent.getEventHeader().getTransactionId();
        try {
            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.setContentType(MediaType.APPLICATION_JSON);
            httpHeaders.set(
                    authenticationClient.getAuthorizationHeaderName(),
                    authenticationClient.getAccessToken());
            final HttpEntity<?> eventEntity = new HttpEntity<>(requestMsg, httpHeaders);
            final ResponseEntity<String> response =
                    authenticationClient
                            .getRestTemplate()
                            .postForEntity(getLAEndpointUrl(), eventEntity, String.class);
            if (response.getStatusCode() != HttpStatus.OK) {

                throw new ROChangedDistLAException(
                        format(
                                "Request Failed with StatusCode:%s, message:%s, TransactionId:%s",
                                response.getStatusCode(), response.getBody(), transactionId));
            }
            log.info(
                    "Request success with StatusCode: {} and message: {}. TransactionId: {} ",
                    response.getStatusCode(),
                    response.getBody(),
                    transactionId);
            log.info(
                    "Event being Published from {}:{} with metadata as {} and error as {}",
                    ROChangedDistLaConstants.RO,
                    ROChangedDistLaConstants.RO_CHANGED_DIST_LA_LAMBDA,
                    cmdsEvent.getEventHeader(),
                    cmdsEvent.getEventErrors());
        } catch (RestClientException
                | TokenNotReceivedException
                 | JsonProcessingException ex) {
            log.error("Exception on posting requestBody: ", ex);
            generateAndLogErrorResponse(cmdsEvent.getEventHeader(), ex);
            throw new ROChangedDistLAException(
                    format(
                            "TransactionId:%s - Exception on posting requestBody: %s",
                            transactionId, ex));
        }
    }

    public String getLAEndpointUrl() {
        return System.getenv(ROChangedDistLaConstants.CALLBACK_URL);
    }

    Optional<RoChangedEventV1Address> getMainAddressDetails(
            RoChangedEventV1Addresses roChangedEventAddresses) {

        return roChangedEventAddresses.stream()
                .filter(
                        address ->
                                ROChangedDistLaConstants.MAIN_ADDRESS_TYPE.equals(
                                        address.getAddressType()))
                .findAny();
    }

    protected BaseEvent<UiHeader> validateMessage(String roMessage, ObjectMapper mapper) {

        BaseEvent<UiHeader> uiCMDSEvent;

        try {
            JavaType type =
                    mapper.getTypeFactory()
                            .constructParametricType(BaseEvent.class, UiHeader.class);
            uiCMDSEvent = mapper.readValue(roMessage, type);

        } catch (JsonProcessingException e) {
            log.error("Exception in Incoming Message:", e);
            throw new IllegalArgumentException(e);
        }
        return uiCMDSEvent;
    }

    /**
     * Method to initialise Logger Context for identity lambda
     *
     * @param eventHeader
     * @param context
     */
    protected void initializeLogger(BaseHeader eventHeader, Context context) {

        if (eventHeader.getTransactionId() != null) {
            loggerUtil.initializeThreadContextMap(
                    eventHeader.getTransactionId().toString(),
                    ROChangedDistLaConstants.RO_CHANGED_DIST_LA_LAMBDA,
                    context.getAwsRequestId(),
                    eventHeader.getEventContext());
        } else {
            throw new IllegalArgumentException("TransactionId is null");
        }
    }

    /**
     * Method to generate Error Response
     *
     * @param eventHeader
     * @param exception
     * @return
     */
    protected List<ErrorDescription> generateAndLogErrorResponse(
            BaseHeader eventHeader, Exception exception) {
        String stackTrace = ExceptionUtils.getStackTrace(exception);
        log.error("Stack trace for exception {}", stackTrace);
        ErrorDescription errorDescription = new ErrorDescription();
        errorDescription.setInterfaceName(ROChangedDistLaConstants.RO_CHANGED_DIST_LA_LAMBDA);
        errorDescription.setMessage(exception.getMessage());
        errorDescription.setTitle(ROChangedDistLaConstants.EXCEPTION_MESSAGE_PROCESSING);
        errorDescription.setType(ErrorTypeEnum.ERROR);
        errorDescription.setErrorCode(eventHeader.getEventName());
        errorDescription.setErrorTicketUuid(null);

        Source source =
                new Source(
                        exception.getMessage(), ROChangedDistLaConstants.RO_CHANGED_DIST_LA_LAMBDA);
        errorDescription.setSource(source);

        List<ErrorDescription> eventErrors = new ArrayList<>();
        eventErrors.add(errorDescription);
        log.error("Exception while calling LA API: {} ", eventErrors);
        return eventErrors;
    }
}

