package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.api.rows159searchresultsgenerated.RoSearchResultsV1Envelope;
import com.ielts.cmds.api.rows159searchresultsgenerated.RoSearchResultsV1;
import com.ielts.cmds.api.rows159searchresultsgenerated.RoDataOutV1Address;
import com.ielts.cmds.api.rows159searchresultsgenerated.RoBasicDataOutV1;
import com.ielts.cmds.api.rows159searchresultsgenerated.SocketResponseMetaDataV1;
import com.ielts.cmds.api.rows159searchresultsgenerated.BaseEventErrorsErrorListInner;
import com.ielts.cmds.api.rows159searchresultsgenerated.RoSearchResultsV1Result;

import com.ielts.cmds.api.rows159searchresultsgenerated.RoBasicDataOutV1.OrganisationStatusEnum;
import com.ielts.cmds.api.rows159searchresultsgenerated.RoBasicDataOutV1.VerificationStatusEnum;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1Address;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1RoBasic;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class RoSearchEventMapping implements IServiceV2<RosSearchResultsGeneratedEventV1, RoSearchResultsV1Envelope> {

    @Override
    public RoSearchResultsV1Envelope process(RosSearchResultsGeneratedEventV1 cmdsEventBody) {
        RoSearchResultsV1Envelope roSearchResultsV1Envelope  = new RoSearchResultsV1Envelope();
        final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
        final BaseEventErrors responseErrors = ThreadLocalErrorContext.getContext();
        final RoSearchResultsV1 responseBody = mapRequestEventBodyToResponseBody(cmdsEventBody);
        roSearchResultsV1Envelope.setResponse(responseBody);
        roSearchResultsV1Envelope.setMeta(responseHeaders);
        if(Objects.nonNull(responseErrors)) {
            roSearchResultsV1Envelope.setErrors(getSearchBaseEventErrors(responseErrors));
        }
        return roSearchResultsV1Envelope;
    }

   private com.ielts.cmds.api.rows159searchresultsgenerated.BaseEventErrors getSearchBaseEventErrors(BaseEventErrors errors) {
        com.ielts.cmds.api.rows159searchresultsgenerated.BaseEventErrors searchBaseEventErrorsOutput = new com.ielts.cmds.api.rows159searchresultsgenerated.BaseEventErrors();
        List<BaseEventErrorsErrorListInner> errorList = new ArrayList<>();
        errors.getErrorList().forEach(errorDescriptionInput -> {
            BaseEventErrorsErrorListInner searchErrorDescription = new BaseEventErrorsErrorListInner();
            searchErrorDescription.setMessage(errorDescriptionInput.getMessage());
            searchErrorDescription.setInterface(errorDescriptionInput.getInterfaceName());
            searchErrorDescription.setType(BaseEventErrorsErrorListInner.TypeEnum.ERROR);
            searchErrorDescription.setErrorCode(errorDescriptionInput.getErrorCode());
            searchErrorDescription.setTitle(errorDescriptionInput.getTitle());
            searchErrorDescription.setErrorTicketUuid(errorDescriptionInput.getErrorTicketUuid());
            searchErrorDescription.setSource(searchErrorDescription.getSource());
            errorList.add(searchErrorDescription);
        });
        searchBaseEventErrorsOutput.setErrorList(errorList);
        return searchBaseEventErrorsOutput;
    }

    public static List<RoDataOutV1Address> getSearchAddresses(RosSearchResultsGeneratedEventV1RoBasic eventV1ResultBasic) {
        List<RoDataOutV1Address> addressesList = new ArrayList<>();
        for (RosSearchResultsGeneratedEventV1Address searchAddress : eventV1ResultBasic.getAddresses()) {
            RoDataOutV1Address roDataOutV1Address = new RoDataOutV1Address();
            roDataOutV1Address.setAddressUuid(searchAddress.getAddressUuid());
            roDataOutV1Address.setAddressTypeUuid(searchAddress.getAddressTypeUuid());
            roDataOutV1Address.setAddressType(searchAddress.getAddressType());
            roDataOutV1Address.setAddressLine1(searchAddress.getAddressLine1());
            roDataOutV1Address.setAddressLine2(searchAddress.getAddressLine2());
            roDataOutV1Address.setAddressLine3(searchAddress.getAddressLine3());
            roDataOutV1Address.setAddressLine4(searchAddress.getAddressLine4());
            roDataOutV1Address.setCity(searchAddress.getCity());
            roDataOutV1Address.setTerritory(searchAddress.getTerritory());
            roDataOutV1Address.setTerritoryUuid(searchAddress.getTerritoryUuid());
            roDataOutV1Address.setTerritoryIsoCode(searchAddress.getTerritoryIsoCode());
            roDataOutV1Address.setCountry(searchAddress.getCountry());
            roDataOutV1Address.setCountryUuid(searchAddress.getCountryUuid());
            roDataOutV1Address.setCountryIso3Code(searchAddress.getCountryIso3Code());
            roDataOutV1Address.setPostalCode(searchAddress.getPostalCode());
            roDataOutV1Address.setEmail(searchAddress.getEmail());
            roDataOutV1Address.setPhone(searchAddress.getPhone());
            addressesList.add(roDataOutV1Address);
        }
        return addressesList;
    }

    public SocketResponseMetaDataV1 mapRequestEventHeaderToSocketResponseHeader(){
        final SocketResponseMetaDataV1 searchResponseHeaders=new SocketResponseMetaDataV1();
        searchResponseHeaders.setCorrelationId(String.valueOf(ThreadLocalHeaderContext.getContext().getCorrelationId()));
        searchResponseHeaders.setConnectionId(ThreadLocalHeaderContext.getContext().getConnectionId());
        return searchResponseHeaders;
    }

    public RoSearchResultsV1 mapRequestEventBodyToResponseBody(
            final RosSearchResultsGeneratedEventV1 eventBody) {
        if (eventBody == null) {
            return null;
        } else {
            List<RoBasicDataOutV1> resultsList = new ArrayList<>();
            for (RosSearchResultsGeneratedEventV1RoBasic eventV1ResultBasic :
                    eventBody.getResult().getEntries()) {
                RoBasicDataOutV1 roDataResultOut = new RoBasicDataOutV1();
                roDataResultOut.setRecognisingOrganisationUuid(
                        eventV1ResultBasic.getRecognisingOrganisationUuid());
                roDataResultOut.setOrganisationName(eventV1ResultBasic.getOrganisationName());
                roDataResultOut.setOrganisationId(eventV1ResultBasic.getOrganisationId());
                roDataResultOut.setOrganisationType(eventV1ResultBasic.getOrganisationType());
                roDataResultOut.setOrganisationTypeUuid(eventV1ResultBasic.getOrganisationTypeUuid());

                roDataResultOut.setOrganisationStatus(OrganisationStatusEnum.valueOf(eventV1ResultBasic.getOrganisationStatus().getValue()));
                roDataResultOut.setVerificationStatus(VerificationStatusEnum.valueOf(eventV1ResultBasic.getVerificationStatus().getValue()));

                List<RoDataOutV1Address> addressesList = getSearchAddresses(eventV1ResultBasic);
                roDataResultOut.setAddresses(addressesList);
                roDataResultOut.setPartnerCode(eventV1ResultBasic.getPartnerCode());
                roDataResultOut.setPartnerContact(eventV1ResultBasic.getPartnerContact());
                roDataResultOut.setOrganisationCode(eventV1ResultBasic.getOrganisationCode());
                roDataResultOut.setSoftDeleted(eventV1ResultBasic.getSoftDeleted());
                roDataResultOut.setParentOrgId(eventV1ResultBasic.getParentOrgId());
                roDataResultOut.setParentRecognisingOrganisationUuid(
                        eventV1ResultBasic.getParentRecognisingOrganisationUuid());
                roDataResultOut.setParentRecognisingOrganisationName(
                        eventV1ResultBasic.getParentRecognisingOrganisationName());

                resultsList.add(roDataResultOut);
            }

            RoSearchResultsV1Result roSearchResultsV1Result = new RoSearchResultsV1Result();
            roSearchResultsV1Result.setTotalCount(eventBody.getResult().getTotalCount());
            roSearchResultsV1Result.setEntries(resultsList);
            RoSearchResultsV1 roSearchResultsV1=new RoSearchResultsV1();
            roSearchResultsV1.setResult(roSearchResultsV1Result);
            return roSearchResultsV1;

        }
    }
}
