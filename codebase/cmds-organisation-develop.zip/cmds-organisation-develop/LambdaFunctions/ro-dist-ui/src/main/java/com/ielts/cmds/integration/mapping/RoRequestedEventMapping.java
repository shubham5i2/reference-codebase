package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.api.rows173requestedresponsegenerated.RoDataOutV1LinkedOrganisation;
import com.ielts.cmds.api.rows173requestedresponsegenerated.RoDataOutV1Address;
import com.ielts.cmds.api.rows173requestedresponsegenerated.RoDataOutV1Contact;
import com.ielts.cmds.api.rows173requestedresponsegenerated.RoDataOutV1AlternateName;
import com.ielts.cmds.api.rows173requestedresponsegenerated.RoDataOutV1MinimumScore;
import com.ielts.cmds.api.rows173requestedresponsegenerated.RoDataOutV1Note;
import com.ielts.cmds.api.rows173requestedresponsegenerated.RoDataOutV1Envelope;
import com.ielts.cmds.api.rows173requestedresponsegenerated.SocketResponseMetaDataV1;
import com.ielts.cmds.api.rows173requestedresponsegenerated.RoDataOutV1;
import com.ielts.cmds.api.rows173requestedresponsegenerated.BaseEventErrorsErrorListInner;

import com.ielts.cmds.infrastructure.event.BaseEventErrors;

import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Address;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Note;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Addresses;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1LinkedOrganisation;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Contacts;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Contact;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1MinimumScores;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1MinimumScore;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Notes;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1AlternateName;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1AlternateNames;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1LinkedOrganisations;
import com.ielts.cmds.organisation.common.out.event.RoRequestedEventV1;

import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class RoRequestedEventMapping implements  IServiceV2<RoRequestedEventV1, RoDataOutV1Envelope> {

	@Override
	public RoDataOutV1Envelope process(RoRequestedEventV1 cmdsEventBody) {
		RoDataOutV1Envelope roDataOutV1Envelope  = new RoDataOutV1Envelope();
		final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
		final BaseEventErrors responseErrors= ThreadLocalErrorContext.getContext();
		if(Objects.nonNull(cmdsEventBody)) {
			final RoDataOutV1 responseBody = mapRequestEventBodyToResponseBody(cmdsEventBody);
			roDataOutV1Envelope.setResponse(responseBody);
		}
		roDataOutV1Envelope.setMeta(responseHeaders);
		if(Objects.nonNull(responseErrors)) {
			roDataOutV1Envelope.setErrors(getRequestedBaseEventErrors(responseErrors));
		}
		return roDataOutV1Envelope;
	}

	public RoDataOutV1 mapRequestEventBodyToResponseBody(final RoRequestedEventV1 eventbody) {
			RoDataOutV1 roDataOutV1 = new RoDataOutV1();
			roDataOutV1.setRecognisingOrganisationUuid(eventbody.getRecognisingOrganisationUuid());
			roDataOutV1.setOrganisationName(eventbody.getOrganisationName());
			roDataOutV1.setOrganisationId(String.valueOf(eventbody.getOrganisationId()));
			roDataOutV1.setOrganisationType(eventbody.getOrganisationType());
			roDataOutV1.setOrganisationTypeUuid(eventbody.getOrganisationTypeUuid());
			roDataOutV1.setOrganisationStatus(RoDataOutV1.OrganisationStatusEnum.valueOf(eventbody.getOrganisationStatus().getValue()));
			roDataOutV1.setVerificationStatus(RoDataOutV1.VerificationStatusEnum.valueOf(eventbody.getVerificationStatus().getValue()));
			roDataOutV1.setAddresses(getRoChangedAddresses(eventbody.getAddresses()));
			roDataOutV1.setPartnerName(eventbody.getPartnerName());
			roDataOutV1.setPartnerCode(eventbody.getPartnerCode());
			roDataOutV1.setPartnerContact(eventbody.getPartnerContact());
			roDataOutV1.setMethodOfDelivery(RoDataOutV1.MethodOfDeliveryEnum.fromValue(eventbody.getMethodOfDelivery().getValue()));
			roDataOutV1.setSectorType(eventbody.getSectorType());
			roDataOutV1.setSectorTypeUuid(eventbody.getSectorTypeUuid());
			roDataOutV1.setWebsiteUrl(eventbody.getWebsiteUrl());
			roDataOutV1.setCrmSystem(eventbody.getCrmSystem());
			roDataOutV1.setOrganisationCode(eventbody.getOrganisationCode());
			roDataOutV1.setResultAvailableForYears(eventbody.getResultAvailableForYears());
			roDataOutV1.setIeltsDisplayFlag(eventbody.getIeltsDisplayFlag());
			roDataOutV1.setOrsDisplayFlag(eventbody.getOrsDisplayFlag());
			roDataOutV1.setParentOrgId(eventbody.getParentOrgId());
			roDataOutV1.setSoftDeleted(eventbody.getSoftDeleted());
			roDataOutV1.setAcceptsIOL(eventbody.getAcceptsIOL());
			roDataOutV1.setAcceptsSSR(eventbody.getAcceptsSSR());
			roDataOutV1.setAcceptsAC(eventbody.getAcceptsAC());
			roDataOutV1.setAcceptsGT(eventbody.getAcceptsGT());
			roDataOutV1.setNotes(getNotesList(eventbody.getNotes()));
			roDataOutV1.setAlternateNames(getAlternateNameList(eventbody.getAlternateNames()));
			roDataOutV1.setContacts(getContactList(eventbody.getContacts()));
			roDataOutV1.setMinimumScores(getMinimumScoreList(eventbody.getMinimumScores()));
			roDataOutV1.setLinkedOrganisations(getLinkedOrganisationList(eventbody.getLinkedOrganisations()));
			return roDataOutV1;

	}

	public List<RoDataOutV1Note> getNotesList(RoChangedEventV1Notes notes) {
		List<RoDataOutV1Note> roDataOutV1NoteList =new ArrayList<>();
		for(RoChangedEventV1Note roChangedEventV1Note:notes){
			RoDataOutV1Note roDataOutV1Note=new RoDataOutV1Note();
			roDataOutV1Note.setNoteContent(roChangedEventV1Note.getNoteContent());
			roDataOutV1Note.setNoteUuid(roChangedEventV1Note.getNoteUuid());
			roDataOutV1Note.setNoteTypeUuid(roChangedEventV1Note.getNoteTypeUuid());
			roDataOutV1Note.setUpdatedDatetime(OffsetDateTime.of(roChangedEventV1Note.getUpdatedDatetime(), ZoneOffset.UTC));
			roDataOutV1NoteList.add(roDataOutV1Note);
		}
		return roDataOutV1NoteList;
	}


	public List<RoDataOutV1AlternateName> getAlternateNameList(RoChangedEventV1AlternateNames alternateNames) {
		List<RoDataOutV1AlternateName> roDataOutV1AlternateNameList=new ArrayList<>();
		for(RoChangedEventV1AlternateName roChangedEventV1AlternateName: alternateNames){
			RoDataOutV1AlternateName roDataOutV1AlternateName=new RoDataOutV1AlternateName();
			roDataOutV1AlternateName.setAlternateNameUuid(roChangedEventV1AlternateName.getAlternateNameUuid());
			roDataOutV1AlternateName.setName(roChangedEventV1AlternateName.getName());
			roDataOutV1AlternateNameList.add(roDataOutV1AlternateName);
		}
		return roDataOutV1AlternateNameList;
	}

	public List<RoDataOutV1LinkedOrganisation> getLinkedOrganisationList(RoChangedEventV1LinkedOrganisations linkedOrganisations) {
		List<RoDataOutV1LinkedOrganisation> roDataOutV1LinkedOrganisationList=new ArrayList<>();
		for(RoChangedEventV1LinkedOrganisation roChangedEventV1LinkedOrganisation:linkedOrganisations ){
			RoDataOutV1LinkedOrganisation roDataOutV1LinkedOrganisation=new RoDataOutV1LinkedOrganisation();
			roDataOutV1LinkedOrganisation.setLinkedRecognisingOrganisationUuid(roChangedEventV1LinkedOrganisation.getLinkedRecognisingOrganisationUuid());
			roDataOutV1LinkedOrganisation.setTargetRecognisingOrganisationName(roChangedEventV1LinkedOrganisation.getTargetRecognisingOrganisationName());
			roDataOutV1LinkedOrganisation.setTargetRecognisingOrganisationUuid(roChangedEventV1LinkedOrganisation.getTargetRecognisingOrganisationUuid());
			roDataOutV1LinkedOrganisation.setLinkType(RoDataOutV1LinkedOrganisation.LinkTypeEnum.fromValue(roChangedEventV1LinkedOrganisation.getLinkType().getValue()));
			roDataOutV1LinkedOrganisation.setLinkEffectiveFromDateTime(OffsetDateTime.of(roChangedEventV1LinkedOrganisation.getLinkEffectiveFromDateTime().toLocalDateTime(),ZoneOffset.UTC));
			roDataOutV1LinkedOrganisation.setLinkEffectiveToDateTime(OffsetDateTime.of(roChangedEventV1LinkedOrganisation.getLinkEffectiveToDateTime().toLocalDateTime(),ZoneOffset.UTC));
			roDataOutV1LinkedOrganisationList.add(roDataOutV1LinkedOrganisation);
		}
		return roDataOutV1LinkedOrganisationList;
	}
	public List<RoDataOutV1MinimumScore> getMinimumScoreList(RoChangedEventV1MinimumScores minimumScores) {
		List<RoDataOutV1MinimumScore> roDataOutV1MinimumScoreList=new ArrayList<>();
		for(RoChangedEventV1MinimumScore  roChangedEventV1MinimumScore:minimumScores){
			RoDataOutV1MinimumScore roDataOutV1MinimumScore= new RoDataOutV1MinimumScore();
			roDataOutV1MinimumScore.setModuleTypeUuid(roChangedEventV1MinimumScore.getModuleTypeUuid());
			roDataOutV1MinimumScore.setComponent(RoDataOutV1MinimumScore.ComponentEnum.fromValue(roChangedEventV1MinimumScore.getComponent().getValue()));
			roDataOutV1MinimumScore.setMinimumScoreUuid(roChangedEventV1MinimumScore.getMinimumScoreUuid());
			roDataOutV1MinimumScore.setMinimumScoreValue(roChangedEventV1MinimumScore.getMinimumScoreValue());
			roDataOutV1MinimumScoreList.add(roDataOutV1MinimumScore);
		}
		return roDataOutV1MinimumScoreList;
	}

	public List<RoDataOutV1Contact> getContactList(RoChangedEventV1Contacts contacts) {

		List<RoDataOutV1Contact>  roDataOutV1ContactList=new ArrayList<>();
		for(RoChangedEventV1Contact roChangedEventV1Contact : contacts){
			RoDataOutV1Contact roDataOutV1Contact=new RoDataOutV1Contact();
			roDataOutV1Contact.setContactUuid(roChangedEventV1Contact.getContactUuid());
			roDataOutV1Contact.setContactTypeUuid(roChangedEventV1Contact.getContactTypeUuid());
			roDataOutV1Contact.setFirstName(roChangedEventV1Contact.getFirstName());
			roDataOutV1Contact.setLastName(roChangedEventV1Contact.getLastName());
			List<RoDataOutV1Address> addressesList = getRoChangedAddresses(roChangedEventV1Contact.getAddresses());
			roDataOutV1Contact.setAddresses(addressesList);
			roDataOutV1Contact.setEffectiveToDateTime(OffsetDateTime.of(roChangedEventV1Contact.getEffectiveToDateTime().toLocalDateTime(),ZoneOffset.UTC));
			roDataOutV1Contact.setEffectiveFromDateTime(OffsetDateTime.of(roChangedEventV1Contact.getEffectiveFromDateTime().toLocalDateTime(),ZoneOffset.UTC));
			roDataOutV1ContactList.add(roDataOutV1Contact);
		}
		return roDataOutV1ContactList;
	}

	public List<RoDataOutV1Address> getRoChangedAddresses(RoChangedEventV1Addresses roChangedEventV1Addresses) {
		List<RoDataOutV1Address> addressesList = new ArrayList<>();
		for(RoChangedEventV1Address address : roChangedEventV1Addresses) {
			RoDataOutV1Address roDataOutV1Address = getCommonAddress(address);
			addressesList.add(roDataOutV1Address);
		}
		return addressesList;
	}
	public RoDataOutV1Address getCommonAddress(final RoChangedEventV1Address address) {

		RoDataOutV1Address roDataOutV1Address = new RoDataOutV1Address();
		roDataOutV1Address.setAddressUuid(address.getAddressUuid());
		roDataOutV1Address.setAddressType(address.getAddressType());
		roDataOutV1Address.setAddressTypeUuid(address.getAddressTypeUuid());
		roDataOutV1Address.setAddressLine1(address.getAddressLine1());
		roDataOutV1Address.setAddressLine2(address.getAddressLine2());
		roDataOutV1Address.setAddressLine3(address.getAddressLine3());
		roDataOutV1Address.setAddressLine4(address.getAddressLine4());
		roDataOutV1Address.setCity(address.getCity());
		roDataOutV1Address.setTerritory(address.getTerritory());
		roDataOutV1Address.setTerritoryUuid(address.getTerritoryUuid());
		roDataOutV1Address.setTerritoryIsoCode(address.getTerritoryIsoCode());
		roDataOutV1Address.setCountry(address.getCountry());
		roDataOutV1Address.setCountryUuid(address.getCountryUuid());
		roDataOutV1Address.setCountryIso3Code(address.getCountryIso3Code());
		roDataOutV1Address.setPostalCode(address.getPostalCode());
		roDataOutV1Address.setEmail(address.getEmail());
		roDataOutV1Address.setPhone(address.getPhone());
		return roDataOutV1Address;
	}

	public com.ielts.cmds.api.rows173requestedresponsegenerated.BaseEventErrors getRequestedBaseEventErrors(BaseEventErrors errors) {
		final com.ielts.cmds.api.rows173requestedresponsegenerated.BaseEventErrors baseEventErrorsOutput =new com.ielts.cmds.api.rows173requestedresponsegenerated.BaseEventErrors();
		List<BaseEventErrorsErrorListInner> errorList = new ArrayList<>();
		errors.getErrorList().forEach(errorDescriptionInput -> {
			BaseEventErrorsErrorListInner requestedErrorDescription = new BaseEventErrorsErrorListInner();
			requestedErrorDescription.setMessage(errorDescriptionInput.getMessage());
			requestedErrorDescription.setInterface(errorDescriptionInput.getInterfaceName());
			requestedErrorDescription.setType(BaseEventErrorsErrorListInner.TypeEnum.ERROR);
			requestedErrorDescription.setErrorCode(errorDescriptionInput.getErrorCode());
			requestedErrorDescription.setTitle(errorDescriptionInput.getTitle());
			requestedErrorDescription.setErrorTicketUuid(errorDescriptionInput.getErrorTicketUuid());
			requestedErrorDescription.setSource(requestedErrorDescription.getSource());
			errorList.add(requestedErrorDescription);
		});
		baseEventErrorsOutput.setErrorList(errorList);
		return baseEventErrorsOutput;
	}

	public SocketResponseMetaDataV1 mapRequestEventHeaderToSocketResponseHeader(){
		final SocketResponseMetaDataV1 requestedResponseHeaders=new SocketResponseMetaDataV1();
		requestedResponseHeaders.setCorrelationId(String.valueOf(ThreadLocalHeaderContext.getContext().getCorrelationId()));
		requestedResponseHeaders.setConnectionId(ThreadLocalHeaderContext.getContext().getConnectionId());
		return requestedResponseHeaders;
	}
}
