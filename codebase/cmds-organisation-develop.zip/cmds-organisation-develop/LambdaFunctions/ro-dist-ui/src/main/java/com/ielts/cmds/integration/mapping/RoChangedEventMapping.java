package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.api.rows178changedresponsegenerated.RoDataOutV1Envelope;
import com.ielts.cmds.api.rows178changedresponsegenerated.RoDataOutV1;
import com.ielts.cmds.api.rows178changedresponsegenerated.SocketResponseMetaDataV1;
import com.ielts.cmds.api.rows178changedresponsegenerated.BaseEventErrorsErrorListInner;

import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;


import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class RoChangedEventMapping implements  IServiceV2<RoChangedEventV1, RoDataOutV1Envelope> {

	@Override
	public RoDataOutV1Envelope process(RoChangedEventV1 cmdsEventBody) {
		RoDataOutV1Envelope response  = new RoDataOutV1Envelope();
		final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
		final BaseEventErrors responseErrors= ThreadLocalErrorContext.getContext();
		final RoDataOutV1 responseBody = mapRequestEventBodyToResponseBody(cmdsEventBody);
		response.setResponse(responseBody);
		response.setMeta(responseHeaders);
		if(Objects.nonNull(responseErrors)) {
			response.setErrors(getChangedBaseEventErrors(responseErrors));
		}
		return response;
	}

	public RoDataOutV1 mapRequestEventBodyToResponseBody(final RoChangedEventV1 eventBody) {
		if (eventBody == null) {
			return null;
		} else {
			RoDataOutV1 roChangeData = new RoDataOutV1();
			roChangeData.setRecognisingOrganisationUuid(eventBody.getRecognisingOrganisationUuid());
			roChangeData.setOrganisationName(eventBody.getOrganisationName());
			roChangeData.setOrganisationId(String.valueOf(eventBody.getOrganisationId()));
			return roChangeData;
		}
	}

	public com.ielts.cmds.api.rows178changedresponsegenerated.BaseEventErrors getChangedBaseEventErrors(BaseEventErrors errors) {
		final com.ielts.cmds.api.rows178changedresponsegenerated.BaseEventErrors changedBaseEventErrorsOutput =new com.ielts.cmds.api.rows178changedresponsegenerated.BaseEventErrors();
		List<BaseEventErrorsErrorListInner> errorList = new ArrayList<>();
		errors.getErrorList().forEach(errorDescriptionInput -> {
			BaseEventErrorsErrorListInner changedErrorDescription = new BaseEventErrorsErrorListInner();
			changedErrorDescription.setMessage(errorDescriptionInput.getMessage());
			changedErrorDescription.setInterface(errorDescriptionInput.getInterfaceName());
			changedErrorDescription.setType(BaseEventErrorsErrorListInner.TypeEnum.ERROR);
			changedErrorDescription.setErrorCode(errorDescriptionInput.getErrorCode());
			changedErrorDescription.setTitle(errorDescriptionInput.getTitle());
			changedErrorDescription.setErrorTicketUuid(errorDescriptionInput.getErrorTicketUuid());
			changedErrorDescription.setSource(changedErrorDescription.getSource());
			errorList.add(changedErrorDescription);
		});
		changedBaseEventErrorsOutput.setErrorList(errorList);
		return changedBaseEventErrorsOutput;
	}

	public SocketResponseMetaDataV1 mapRequestEventHeaderToSocketResponseHeader(){
        final SocketResponseMetaDataV1 changedResponseHeaders=new SocketResponseMetaDataV1();
		changedResponseHeaders.setCorrelationId(String.valueOf(ThreadLocalHeaderContext.getContext().getCorrelationId()));
		changedResponseHeaders.setConnectionId(ThreadLocalHeaderContext.getContext().getConnectionId());
        return changedResponseHeaders;
    }

}
