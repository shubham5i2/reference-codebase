package com.ielts.cmds.integration.constants;

/** Constants class for RO Distributor Lambda */
public final class RODistConstants {

	private RODistConstants() {
	}
	
	public static final String APPLICATION_NAME = "RO-DIST-LAMBDA";
	public static final String RO = "RO";
}
