package com.ielts.cmds.integration.mapping;

import com.ielts.cmds.api.rows402detailsdatagenerated.BaseEventErrorsErrorListInner;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;

import com.ielts.cmds.api.rows402detailsdatagenerated.RoDetailsDataOutV1Envelope;
import com.ielts.cmds.api.rows402detailsdatagenerated.RoDetailsDataOutV1;
import com.ielts.cmds.api.rows402detailsdatagenerated.SocketResponseMetaDataV1;

import com.ielts.cmds.organisation.common.out.event.RoDetailsDataGeneratedEventV1;
import com.ielts.cmds.organisation.common.out.event.RoDetailsDataGeneratedEventV1RO;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class RoDetailsDataGeneratedEventMapping implements IServiceV2<RoDetailsDataGeneratedEventV1, RoDetailsDataOutV1Envelope> {

    public List<RoDetailsDataOutV1> mapRequestEventBodyToResponseBody(
            final RoDetailsDataGeneratedEventV1 eventBody) {
        List<RoDetailsDataOutV1> roDetailsDataOutV1List = new ArrayList<>();
        if (eventBody != null)
        {
            for (RoDetailsDataGeneratedEventV1RO event : eventBody) {
                RoDetailsDataOutV1 roDetails = new RoDetailsDataOutV1();
                roDetails.setRecognisingOrganisationUuid(event.getRecognisingOrganisationUuid());
                roDetails.setOrganisationTypeUuid(event.getOrganisationTypeUuid());
                roDetails.setName(event.getName());
                roDetails.setOrganisationTypeUuid(event.getOrganisationTypeUuid());
                roDetailsDataOutV1List.add(roDetails);
            }
        }
        return roDetailsDataOutV1List;
    }

    @Override
    public RoDetailsDataOutV1Envelope process(RoDetailsDataGeneratedEventV1 cmdsEventBody) {
        RoDetailsDataOutV1Envelope response = new RoDetailsDataOutV1Envelope();
        final SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
        final BaseEventErrors responseErrors = ThreadLocalErrorContext.getContext();
        response.setMeta(responseHeaders);
        final List<RoDetailsDataOutV1> responseBody=mapRequestEventBodyToResponseBody(cmdsEventBody);
        response.setResponse(responseBody);
        if(Objects.nonNull(responseErrors)) {
            response.setErrors(getDetailsDataBaseEventErrors(responseErrors));
        }
        return response;
    }
    public com.ielts.cmds.api.rows402detailsdatagenerated.BaseEventErrors getDetailsDataBaseEventErrors(BaseEventErrors errors) {
        final com.ielts.cmds.api.rows402detailsdatagenerated.BaseEventErrors baseEventErrorsOutput =new com.ielts.cmds.api.rows402detailsdatagenerated.BaseEventErrors();
        List<BaseEventErrorsErrorListInner> errorList = new ArrayList<>();
        errors.getErrorList().forEach(errorDescriptionInput -> {
            BaseEventErrorsErrorListInner detailsDataErrorDescription = new BaseEventErrorsErrorListInner();
            detailsDataErrorDescription.setMessage(errorDescriptionInput.getMessage());
            detailsDataErrorDescription.setInterface(errorDescriptionInput.getInterfaceName());
            detailsDataErrorDescription.setType(BaseEventErrorsErrorListInner.TypeEnum.ERROR);
            detailsDataErrorDescription.setErrorCode(errorDescriptionInput.getErrorCode());
            detailsDataErrorDescription.setTitle(errorDescriptionInput.getTitle());
            detailsDataErrorDescription.setErrorTicketUuid(errorDescriptionInput.getErrorTicketUuid());
            detailsDataErrorDescription.setSource(detailsDataErrorDescription.getSource());
            errorList.add(detailsDataErrorDescription);
        });
        baseEventErrorsOutput.setErrorList(errorList);
        return baseEventErrorsOutput;
    }

    public SocketResponseMetaDataV1 mapRequestEventHeaderToSocketResponseHeader(){
        final SocketResponseMetaDataV1 detailsDataResponseHeaders=new SocketResponseMetaDataV1();
        detailsDataResponseHeaders.setCorrelationId(String.valueOf(ThreadLocalHeaderContext.getContext().getCorrelationId()));
        detailsDataResponseHeaders.setConnectionId(ThreadLocalHeaderContext.getContext().getConnectionId());
        return detailsDataResponseHeaders;
    }
}