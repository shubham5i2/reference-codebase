package com.ielts.cmds.integration.factory;

import java.util.HashMap;
import java.util.Map;

import com.ielts.cmds.integration.mapping.RoChangedEventMapping;
import com.ielts.cmds.integration.mapping.RoDetailsDataGeneratedEventMapping;
import com.ielts.cmds.integration.mapping.RoRequestedEventMapping;
import com.ielts.cmds.integration.mapping.RoSearchEventMapping;
import com.ielts.cmds.serialization.lambda.dist.ui.service.AbstractServiceFactoryV2;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;

public class ServiceFactoryV2 extends AbstractServiceFactoryV2 {

	@SuppressWarnings("rawtypes")
	private static final Map<String, IServiceV2> mapServices = new HashMap<>();

	static {
		mapServices.put("RoCreated", new RoChangedEventMapping());
		mapServices.put("RoRejected", new RoChangedEventMapping());
		mapServices.put("RoChanged", new RoChangedEventMapping());
		mapServices.put("RoRequested", new RoRequestedEventMapping());
		mapServices.put("RoRequestRejected", new RoRequestedEventMapping());
		mapServices.put("RoSearchResultGenerated", new RoSearchEventMapping());
		mapServices.put("RoChangeRejected", new RoChangedEventMapping());
		mapServices.put("RoDetailsDataGenerated", new RoDetailsDataGeneratedEventMapping());
	}

	public ServiceFactoryV2() {
		super(mapServices);
	}

	@SuppressWarnings("unchecked")
	@Override
	public <InputType, OutputType> IServiceV2<InputType, OutputType> getService(String eventIdentifier) {
		return mapServices.get(eventIdentifier);
	}
}
