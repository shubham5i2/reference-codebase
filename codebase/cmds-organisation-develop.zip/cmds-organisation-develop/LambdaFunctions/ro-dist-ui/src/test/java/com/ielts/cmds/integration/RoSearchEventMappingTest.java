package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.RoSearchSQSEventSetup.getBaseEventErrors;
import static com.ielts.cmds.integration.RoSearchSQSEventSetup.mapRequestEventHeaderToSocketResponseHeader;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doReturn;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.api.rows159searchresultsgenerated.RoSearchResultsV1;
import com.ielts.cmds.api.rows159searchresultsgenerated.SocketResponseMetaDataV1;
import com.ielts.cmds.api.rows159searchresultsgenerated.RoSearchResultsV1Envelope;
import com.ielts.cmds.integration.mapping.RoSearchEventMapping;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import java.util.UUID;

@ExtendWith(MockitoExtension.class)
class RoSearchEventMappingTest {

	@Spy
	private RoSearchEventMapping roSearchEventMapping;

	final HeaderContext context = new HeaderContext();

	/**
	 * Test to validate the Response Event Body when Request Event Body is passed.
	 *
	 * @throws JsonProcessingException
	 */

	@BeforeEach
	public void setUp() {
		context.setConnectionId("a6d58192-dd39");
		context.setCorrelationId(UUID.fromString("a6d58192-dd39-4953-a619-26b8b43cf2ad"));
		ThreadLocalHeaderContext.setContext(context);
	}

	@Test
	void whenRequestEventBodyProvided_ThenValidateSocketResponseEventBody() throws JsonProcessingException {
		ThreadLocalErrorContext.setContext(getBaseEventErrors());
		RosSearchResultsGeneratedEventV1 eventBody = RoSearchSQSEventSetup.populateRoSearchEventBody();
		final RoSearchResultsV1Envelope response = roSearchEventMapping.process(eventBody);
		final RoSearchResultsV1 responseBody = roSearchEventMapping.mapRequestEventBodyToResponseBody(eventBody);
		assertEquals(eventBody.getResult().getTotalCount(), responseBody.getResult().getTotalCount());
		assertEquals("V3069", response.getErrors().getErrorList().get(0).getErrorCode());
	}

	@Test
	void whenRequestEventBodyProvided_ThenValidateSocketResponseEventErrors() {
		RosSearchResultsGeneratedEventV1 eventBody = RoSearchSQSEventSetup.populateRoSearchEventBody();
		String expectedErrorMessage = "Ro not found";
		String expectedErrorCode = "V3069";
		ThreadLocalErrorContext.setContext(getBaseEventErrors());
		com.ielts.cmds.api.rows159searchresultsgenerated.SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
		doReturn(responseHeaders).when(roSearchEventMapping).mapRequestEventHeaderToSocketResponseHeader();
		RoSearchResultsV1Envelope actualResult = roSearchEventMapping.process(eventBody);
		assertEquals(expectedErrorMessage, actualResult.getErrors().getErrorList().get(0).getMessage());
		assertEquals(expectedErrorCode, actualResult.getErrors().getErrorList().get(0).getErrorCode());
		assertEquals(responseHeaders.getConnectionId(), actualResult.getMeta().getConnectionId());
		assertEquals(responseHeaders.getCorrelationId(), actualResult.getMeta().getCorrelationId());

	}

	@Test
	void whenRequestEventBodyProvided_ThenValidateSocketResponseEventBodyIsNull() throws JsonProcessingException {
		ThreadLocalErrorContext.setContext(getBaseEventErrors());
		RosSearchResultsGeneratedEventV1 eventBody =null;
		SocketResponseMetaDataV1 responseHeaders=mapRequestEventHeaderToSocketResponseHeader();
		doReturn(responseHeaders).when(roSearchEventMapping).mapRequestEventHeaderToSocketResponseHeader();
		final RoSearchResultsV1Envelope response = roSearchEventMapping.process(eventBody);
		assertEquals(null, response.getResponse());
		}

	@Test
	void whenRequestEventBodyProvided_ThenValidateSocketResponseHeader() {
		SocketResponseMetaDataV1 responseHeader=RoSearchSQSEventSetup.mapRequestEventHeaderToSocketResponseHeader();
		doReturn(responseHeader).when(roSearchEventMapping).mapRequestEventHeaderToSocketResponseHeader();
		RosSearchResultsGeneratedEventV1 eventBody = RoSearchSQSEventSetup.populateRoSearchEventBody();
		final RoSearchResultsV1Envelope response = roSearchEventMapping.process(eventBody);
		assertEquals(context.getCorrelationId(),UUID.fromString((response.getMeta().getCorrelationId())));
		assertEquals(context.getConnectionId(),response.getMeta().getConnectionId());
	}
}
