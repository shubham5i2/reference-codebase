package com.ielts.cmds.integration;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ielts.cmds.integration.factory.ServiceFactoryV2;
import com.ielts.cmds.integration.mapping.RoChangedEventMapping;
import com.ielts.cmds.integration.mapping.RoDetailsDataGeneratedEventMapping;
import com.ielts.cmds.integration.mapping.RoRequestedEventMapping;
import com.ielts.cmds.integration.mapping.RoSearchEventMapping;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.organisation.common.out.event.RoDetailsDataGeneratedEventV1;
import com.ielts.cmds.organisation.common.out.event.RoRequestedEventV1;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1;
import com.ielts.cmds.serialization.lambda.dist.ui.service.IServiceV2;

import com.ielts.cmds.organisation.common.out.socketresponse.RoDetailsDataOutV1Envelope;

import com.ielts.cmds.api.rows173requestedresponsegenerated.RoDataOutV1Envelope;
import com.ielts.cmds.api.rows159searchresultsgenerated.RoSearchResultsV1Envelope;


@ExtendWith(MockitoExtension.class)
class ServiceFactoryV2Test {
	
	@Spy
	private ServiceFactoryV2 serviceFactory;

	@ParameterizedTest
	@ValueSource(strings={"RoCreated","RoRejected","RoChanged","RoChangeRejected"})
	void testMappingClassing(String eventName) {
		IServiceV2<RoChangedEventV1, RoDataOutV1Envelope> responseMapping = serviceFactory.getService(eventName);
		assertEquals(responseMapping.getClass(), RoChangedEventMapping.class);
	}
	@Test
	void testMappingClassing_whenEventNameIsRoRequested() {
		IServiceV2<RoRequestedEventV1, RoDataOutV1Envelope> responseMapping = serviceFactory.getService("RoRequested");
		assertEquals(responseMapping.getClass(), RoRequestedEventMapping.class);
	}
	@Test
	void testMappingClassing_whenEventNameIsRoRequestedRejected() {
		IServiceV2<RoRequestedEventV1, RoDataOutV1Envelope> responseMapping = serviceFactory.getService("RoRequestRejected");
		assertEquals(responseMapping.getClass(), RoRequestedEventMapping.class);
	}
	@Test
	void testMappingClassing_whenEventNameIsRoSearchResultGenerated() {
		IServiceV2<RosSearchResultsGeneratedEventV1, RoSearchResultsV1Envelope> responseMapping = serviceFactory.getService("RoSearchResultGenerated");
		assertEquals(responseMapping.getClass(), RoSearchEventMapping.class);
	}
	@Test
	void testMappingClassing_whenEventNameIsRoDetailsDataGenerated() {
		IServiceV2<RoDetailsDataGeneratedEventV1, RoDetailsDataOutV1Envelope> responseMapping = serviceFactory.getService("RoDetailsDataGenerated");
		assertEquals(responseMapping.getClass(), RoDetailsDataGeneratedEventMapping.class);
	}
}

