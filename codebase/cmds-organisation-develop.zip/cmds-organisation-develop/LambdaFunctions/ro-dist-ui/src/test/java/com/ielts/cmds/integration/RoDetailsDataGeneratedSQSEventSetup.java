package com.ielts.cmds.integration;


import com.ielts.cmds.organisation.common.out.event.RoDetailsDataGeneratedEventV1;
import com.ielts.cmds.organisation.common.out.event.RoDetailsDataGeneratedEventV1RO;

import java.util.UUID;

public class RoDetailsDataGeneratedSQSEventSetup {


    public static RoDetailsDataGeneratedEventV1 populateRoSearchByIdEventBody() {
        final RoDetailsDataGeneratedEventV1 roDetailsDataGeneratedEventV1 =
                new RoDetailsDataGeneratedEventV1();
        RoDetailsDataGeneratedEventV1RO roDetails = new RoDetailsDataGeneratedEventV1RO();
        roDetails.setRecognisingOrganisationUuid(
                UUID.fromString("9edbc4ef-b58f-445c-bc41-1239e0168c9e"));
        roDetails.setName("university");
        RoDetailsDataGeneratedEventV1RO roDetails1 = new RoDetailsDataGeneratedEventV1RO();
        roDetails1.setRecognisingOrganisationUuid(
                UUID.fromString("9edbc4ef-b58f-345c-bc41-1239e0168c9e"));
        roDetails1.setName("university1");
        RoDetailsDataGeneratedEventV1RO roDetails2 = new RoDetailsDataGeneratedEventV1RO();
        roDetails2.setRecognisingOrganisationUuid(
                UUID.fromString("9edbc4ef-b58f-245c-bc41-1239e0168c9e"));
        roDetails2.setName("university2");
        roDetailsDataGeneratedEventV1.add(roDetails);
        roDetailsDataGeneratedEventV1.add(roDetails1);
        roDetailsDataGeneratedEventV1.add(roDetails2);
        return roDetailsDataGeneratedEventV1;
    }


}
