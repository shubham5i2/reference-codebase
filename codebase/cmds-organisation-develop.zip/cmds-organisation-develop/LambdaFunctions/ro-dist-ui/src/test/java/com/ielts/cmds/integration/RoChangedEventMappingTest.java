package com.ielts.cmds.integration;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doReturn;
import com.fasterxml.jackson.core.JsonProcessingException;
import static com.ielts.cmds.integration.RoChangedSQSEventSetup.getBaseEventErrors;
import static com.ielts.cmds.integration.RoChangedSQSEventSetup.mapRequestEventHeaderToSocketResponseHeader;
import com.ielts.cmds.integration.mapping.RoChangedEventMapping;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import com.ielts.cmds.api.rows178changedresponsegenerated.RoDataOutV1;
import com.ielts.cmds.api.rows178changedresponsegenerated.RoDataOutV1Envelope;
import com.ielts.cmds.api.rows178changedresponsegenerated.SocketResponseMetaDataV1;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.UUID;

@ExtendWith(MockitoExtension.class)
class RoChangedEventMappingTest {

    @Spy private RoChangedEventMapping roChangedEventMapping;

    final HeaderContext context = new HeaderContext();

    /**
     * Test to validate the Response Event Body when Request Event Body is passed.
     *
     * @throws JsonProcessingException
     */
    @BeforeEach
    public void setUp() {
        context.setConnectionId("a6d58192-dd39");
        context.setCorrelationId(UUID.fromString("a6d58192-dd39-4953-a619-26b8b43cf2ad"));
        ThreadLocalHeaderContext.setContext(context);
    }

    @Test
    void whenRequestEventBodyProvided_ThenValidateSocketResponseEventBody() throws JsonProcessingException {
        ThreadLocalErrorContext.setContext(getBaseEventErrors());
        RoChangedEventV1 eventBody = RoChangedSQSEventSetup.populateRoChangedEventBody();
        SocketResponseMetaDataV1 responseHeaders=mapRequestEventHeaderToSocketResponseHeader();
        doReturn(responseHeaders).when(roChangedEventMapping).mapRequestEventHeaderToSocketResponseHeader();
        RoDataOutV1Envelope response=roChangedEventMapping.process(eventBody);
        RoDataOutV1 responseBody = roChangedEventMapping.mapRequestEventBodyToResponseBody(eventBody);
        assertEquals(
                eventBody.getRecognisingOrganisationUuid(),
                responseBody.getRecognisingOrganisationUuid());
        assertEquals(eventBody.getOrganisationName(), responseBody.getOrganisationName());
        assertEquals(eventBody.getRecognisingOrganisationUuid(), responseBody.getRecognisingOrganisationUuid());
        assertEquals("V3069", response.getErrors().getErrorList().get(0).getErrorCode());

    }
    @Test
    void whenRequestEventBodyProvided_ThenValidateSocketResponseEventErrors() {
        RoChangedEventV1 eventBody = RoChangedSQSEventSetup.populateRoChangedEventBody();
        String expectedErrorMessage = "Ro can not update";
        String expectedErrorCode = "V3069";
        ThreadLocalErrorContext.setContext(getBaseEventErrors());
        SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
        doReturn(responseHeaders).when(roChangedEventMapping).mapRequestEventHeaderToSocketResponseHeader();
        RoDataOutV1Envelope actualResult = roChangedEventMapping.process(eventBody);
        assertEquals(expectedErrorMessage, actualResult.getErrors().getErrorList().get(0).getMessage());
        assertEquals(expectedErrorCode, actualResult.getErrors().getErrorList().get(0).getErrorCode());
        assertEquals(responseHeaders.getConnectionId(), actualResult.getMeta().getConnectionId());
        assertEquals(responseHeaders.getCorrelationId(), actualResult.getMeta().getCorrelationId());

    }

    @Test
    void whenRequestEventBodyProvided_ThenValidateSocketResponseEventBodyIsNull() throws JsonProcessingException {
        ThreadLocalErrorContext.setContext(RoChangedSQSEventSetup.getBaseEventErrors());
        RoChangedEventV1 eventBody =null;
        final RoDataOutV1Envelope response = roChangedEventMapping.process(eventBody);
        assertEquals(null, response.getResponse());
    }

}