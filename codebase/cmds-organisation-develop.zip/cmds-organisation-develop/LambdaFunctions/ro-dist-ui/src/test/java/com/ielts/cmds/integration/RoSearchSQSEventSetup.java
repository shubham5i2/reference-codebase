package com.ielts.cmds.integration;

import com.ielts.cmds.api.rows159searchresultsgenerated.SocketResponseMetaDataV1;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.organisation.common.out.event.RoSearchV1;
import com.ielts.cmds.organisation.common.out.event.RoSearchV1Criteria;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1Address;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1Addresses;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1ROList;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1Result;
import com.ielts.cmds.organisation.common.out.event.RosSearchResultsGeneratedEventV1RoBasic;
import com.ielts.cmds.organisation.common.out.event.SearchPaginationV1;
import com.ielts.cmds.organisation.common.out.event.SearchSortV1;
import com.ielts.cmds.organisation.common.out.event.SearchSortV1Item;

import com.ielts.cmds.api.roui007rocreaterequested.OrganisationStatusEnum;
import com.ielts.cmds.api.roui007rocreaterequested.VerificationStatusEnum;


import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class RoSearchSQSEventSetup {

    public static RosSearchResultsGeneratedEventV1 populateRoSearchEventBody() {
        final RosSearchResultsGeneratedEventV1 rosSearchResultsGeneratedEventV1 =
                new RosSearchResultsGeneratedEventV1();

        RoSearchV1Criteria roSearchV1Criteria = new RoSearchV1Criteria();

        roSearchV1Criteria.setOrganisationName("Cambridge University");
        roSearchV1Criteria.setOrganisationId(13455);
        roSearchV1Criteria.setContactName("Allen");
        roSearchV1Criteria.setOrganisationStatus(OrganisationStatusEnum.ACTIVE);
        roSearchV1Criteria.setVerificationStatus(VerificationStatusEnum.APPROVED);
        roSearchV1Criteria.setOrganisationTypeUuid(
                UUID.fromString("9edbc4ef-b58f-445c-bc41-1239e0168c9e"));
        roSearchV1Criteria.setCity("cambridge");
        roSearchV1Criteria.setPostalCode("022334");
        roSearchV1Criteria.setContactEmail("allen.123@gmail.com");
        roSearchV1Criteria.setPartnerCode("BC");

        RosSearchResultsGeneratedEventV1ROList resultsList =
                new RosSearchResultsGeneratedEventV1ROList();
        RosSearchResultsGeneratedEventV1RoBasic roDataResultOut =
                new RosSearchResultsGeneratedEventV1RoBasic();

        RosSearchResultsGeneratedEventV1Addresses addressesList =
                new RosSearchResultsGeneratedEventV1Addresses();
        roDataResultOut.setRecognisingOrganisationUuid(
                UUID.fromString("9edbc4ef-b58f-445c-bc41-1239e0168c9e"));
        roDataResultOut.setOrganisationName("Junit Organisation");
        roDataResultOut.setOrganisationId(12345);
        roDataResultOut.setOrganisationTypeUuid(
                UUID.fromString("9edbc4ef-b58f-445c-bc41-1239e0168c9e"));
        roDataResultOut.setOrganisationStatus(OrganisationStatusEnum.ACTIVE);
        roDataResultOut.setVerificationStatus(VerificationStatusEnum.APPROVED);

        RosSearchResultsGeneratedEventV1Address roDataOutV1Address =
                new RosSearchResultsGeneratedEventV1Address();
        roDataOutV1Address.setAddressUuid(UUID.fromString("9edbc4ef-b58f-445c-bc41-1239e0168c9e"));
        roDataOutV1Address.setAddressTypeUuid(
                UUID.fromString("9edbc4ef-b58f-445c-bc41-1239e0168c9e"));
        roDataOutV1Address.setAddressLine1("flat 102, block 2");
        roDataOutV1Address.setAddressLine2("Near KG park");
        roDataOutV1Address.setAddressLine3("RR Road");
        roDataOutV1Address.setAddressLine4("");
        roDataOutV1Address.setCity("Hyd");
        roDataOutV1Address.setTerritoryUuid(
                UUID.fromString("9edbc4ef-b58f-445c-bc41-1239e0168c9e"));
        roDataOutV1Address.setTerritoryIsoCode("GB-BIR");
        roDataOutV1Address.setCountryIso3Code("GBR");
        roDataOutV1Address.setPostalCode("CB2 8EA");
        roDataOutV1Address.setEmail("alan@gmail.com");
        roDataOutV1Address.setPhone("9876543221");
        addressesList.add(roDataOutV1Address);
        roDataResultOut.setAddresses(addressesList);

        roDataResultOut.setPartnerCode("BC");
        roDataResultOut.setPartnerContact("Home");
        roDataResultOut.setOrganisationCode("4321");
        roDataResultOut.setSoftDeleted(false);
        roDataResultOut.setParentRecognisingOrganisationUuid(UUID.randomUUID());
        roDataResultOut.setParentRecognisingOrganisationName("Cambridge Univeristy");
        resultsList.add(roDataResultOut);

        RosSearchResultsGeneratedEventV1Result resultsData =
                new RosSearchResultsGeneratedEventV1Result();
        resultsData.setTotalCount(5);
        resultsData.setEntries(resultsList);

        rosSearchResultsGeneratedEventV1.setResult(resultsData);

        return rosSearchResultsGeneratedEventV1;
    }
    public static SocketResponseMetaDataV1 mapRequestEventHeaderToSocketResponseHeader() {
        final SocketResponseMetaDataV1 responseHeaders = new SocketResponseMetaDataV1();
        responseHeaders.setCorrelationId("a6d58192-dd39-4953-a619-26b8b43cf2ad");
        responseHeaders.setConnectionId("a6d58192-dd39");
        return responseHeaders;
    }

    public static BaseEventErrors getBaseEventErrors(){
        BaseEventErrors baseEventErrors;
        List<ErrorDescription> errorDescriptionList = new ArrayList<>();
        ErrorDescription errorDescription = new ErrorDescription();
        errorDescription.setErrorCode("V3069");
        errorDescription.setMessage("Ro not found");
        errorDescriptionList.add(errorDescription);
        baseEventErrors = new BaseEventErrors(errorDescriptionList);
        return baseEventErrors;
    }

}
