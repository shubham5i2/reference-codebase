package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.RoViewDetailsSQSEventSetup.getBaseEventErrors;
import static com.ielts.cmds.integration.RoViewDetailsSQSEventSetup.mapRequestEventHeaderToSocketResponseHeader;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doReturn;

import java.util.List;
import java.util.UUID;

import com.ielts.cmds.api.rows402detailsdatagenerated.SocketResponseMetaDataV1;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import com.ielts.cmds.organisation.common.out.event.RoDetailsDataGeneratedEventV1RO;
import com.ielts.cmds.organisation.common.out.event.RoRequestedEventV1;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ielts.cmds.integration.mapping.RoDetailsDataGeneratedEventMapping;
import com.ielts.cmds.organisation.common.out.event.RoDetailsDataGeneratedEventV1;
import com.ielts.cmds.api.rows402detailsdatagenerated.RoDetailsDataOutV1Envelope;
import com.ielts.cmds.api.rows402detailsdatagenerated.RoDetailsDataOutV1;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

@ExtendWith(MockitoExtension.class)
class RoDetailsDataGeneratedEventMappingTest {

    @Spy private RoDetailsDataGeneratedEventMapping roDetailsDataGeneratedEventMapping;

    final HeaderContext context = new HeaderContext();

    /**
     * Test to validate the Response Event Body when Request Event Body is passed.
     *
     * @throws JsonProcessingException
     */
    @BeforeEach
    public void setUp() {
        context.setConnectionId("a6d58192-dd39");
        context.setCorrelationId(UUID.fromString("a6d58192-dd39-4953-a619-26b8b43cf2ad"));
        ThreadLocalHeaderContext.setContext(context);
    }

    @Test
    void whenRequestEventBodyProvided_ThenValidateSocketResponseEventBody()
            throws JsonProcessingException {

        RoDetailsDataGeneratedEventV1 eventBody = RoDetailsDataGeneratedSQSEventSetup.populateRoSearchByIdEventBody();
        final RoDetailsDataOutV1Envelope response = roDetailsDataGeneratedEventMapping.process(eventBody);
        List<RoDetailsDataOutV1> responseBody = roDetailsDataGeneratedEventMapping.mapRequestEventBodyToResponseBody(eventBody);
        assertEquals(eventBody.size(), responseBody.size());
        assertEquals(eventBody.get(0).getName(), responseBody.get(0).getName());
        assertEquals(
                eventBody.get(0).getRecognisingOrganisationUuid(),
                eventBody.get(0).getRecognisingOrganisationUuid());
    }
    @Test
    void whenRequestEventBodyProvided_ThenValidateSocketResponseEventErrors() {
        RoDetailsDataGeneratedEventV1 eventBody = RoDetailsDataGeneratedSQSEventSetup.populateRoSearchByIdEventBody();
        String expectedErrorMessage = "Ro not found";
        String expectedErrorCode = "V3069";
        ThreadLocalErrorContext.setContext(getBaseEventErrors());
        RoDetailsDataOutV1Envelope actualResult = roDetailsDataGeneratedEventMapping.process(eventBody);
        assertEquals(expectedErrorMessage, actualResult.getErrors().getErrorList().get(0).getMessage());
        assertEquals(expectedErrorCode, actualResult.getErrors().getErrorList().get(0).getErrorCode());

    }
}
