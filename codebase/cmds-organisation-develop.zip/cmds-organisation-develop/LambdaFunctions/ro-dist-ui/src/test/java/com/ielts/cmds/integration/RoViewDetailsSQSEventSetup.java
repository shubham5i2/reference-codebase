package com.ielts.cmds.integration;

import com.ielts.cmds.api.rows173requestedresponsegenerated.SocketResponseMetaDataV1;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.api.roui007rocreaterequested.OrganisationStatusEnum;
import com.ielts.cmds.api.roui007rocreaterequested.MethodOfDeliveryEnum;
import com.ielts.cmds.api.roui007rocreaterequested.VerificationStatusEnum;
import com.ielts.cmds.api.roui007rocreaterequested.LinkTypeEnum;
import com.ielts.cmds.api.roui007rocreaterequested.ComponentEnum;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Address;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Addresses;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1AlternateName;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1AlternateNames;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Contact;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Contacts;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1LinkedOrganisation;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1LinkedOrganisations;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1MinimumScore;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1MinimumScores;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Note;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1Notes;
import com.ielts.cmds.organisation.common.out.event.RoRequestedEventV1;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.Month;

import java.util.ArrayList;
import java.util.List;
import java.time.OffsetDateTime;
import java.util.UUID;

public class RoViewDetailsSQSEventSetup {

    
    public static RoRequestedEventV1 populateRoViewDetailsEventBody() {
        final RoRequestedEventV1 roViewDetailsData = new RoRequestedEventV1();
        roViewDetailsData.setRecognisingOrganisationUuid(
                UUID.fromString("9edbc4ef-b58f-445c-bc41-1239e0168c9e"));
        roViewDetailsData.setOrganisationName("Cambridge University");
        roViewDetailsData.setOrganisationId(13455);
        roViewDetailsData.setOrganisationTypeUuid(
                UUID.fromString("9edbc4ef-b58f-445c-bc41-1239e0168c9e"));
        roViewDetailsData.setOrganisationStatus(OrganisationStatusEnum.ACTIVE);
        roViewDetailsData.setVerificationStatus(VerificationStatusEnum.APPROVED);
        roViewDetailsData.setAcceptsIOL(true);
        roViewDetailsData.setAcceptsSSR(true);

        RoChangedEventV1Addresses addressesList = new RoChangedEventV1Addresses();
        RoChangedEventV1Address roChangedEventV1Address = new RoChangedEventV1Address();
        roChangedEventV1Address.setAddressUuid(
                UUID.fromString("ba0b67f6-adfc-4d47-a9cb-0da8655075ac"));
        roChangedEventV1Address.setAddressTypeUuid(
                UUID.fromString("8088042f-c82f-418c-90a4-2e20e8ef40b3"));
        roChangedEventV1Address.setAddressLine1("22 Heathfield Gardens");
        roChangedEventV1Address.setAddressLine2("James Lane");
        roChangedEventV1Address.setAddressLine3("Park Colony");
        roChangedEventV1Address.setAddressLine4("Near KFC");
        roChangedEventV1Address.setCity("Cambridge");
        roChangedEventV1Address.setTerritoryUuid(
                UUID.fromString("dd858eb6-4738-479a-9bd7-3e293aa271b5"));
        roChangedEventV1Address.setTerritoryIsoCode("GB-BIR");
        roChangedEventV1Address.setCountryIso3Code("GBR");
        roChangedEventV1Address.setCountryUuid(
                UUID.fromString("dd858eb6-4738-479a-9bd7-3e293aa271b5"));
        roChangedEventV1Address.setPostalCode("CB2 8EA");
        roChangedEventV1Address.setEmail("alan@gmail.com");
        roChangedEventV1Address.setPhone("1234567890");
        addressesList.add(roChangedEventV1Address);
        roViewDetailsData.setAddresses(addressesList);

        roViewDetailsData.setPartnerCode("BC");
        roViewDetailsData.setPartnerContact("HOME");
        roViewDetailsData.setMethodOfDelivery(MethodOfDeliveryEnum.POSTAL);
        roViewDetailsData.setSectorTypeUuid(
                UUID.fromString("acafb6bd-00a6-4fa9-b9f4-562eaa7ea1cb"));
        roViewDetailsData.setWebsiteUrl("http://www.officialxyz.com/");
        roViewDetailsData.setOrganisationCode("UCAS231");

        RoChangedEventV1Notes notesList = new RoChangedEventV1Notes();
        RoChangedEventV1Note notes = new RoChangedEventV1Note();
        notes.setNoteUuid(UUID.fromString("a910dbb1-4379-4157-8ff8-cbdffe44599d"));
        notes.setNoteContent("");
        notes.setNoteTypeUuid(UUID.fromString("ea7c0de6-4646-4b1d-9ee7-9983c6f99fc8"));
        notes.setUpdatedDatetime(LocalDateTime.now());
        notesList.add(notes);
        roViewDetailsData.setNotes(notesList);

        RoChangedEventV1AlternateNames alternativeNamesList = new RoChangedEventV1AlternateNames();
        RoChangedEventV1AlternateName alternativeNames = new RoChangedEventV1AlternateName();
        alternativeNames.setAlternateNameUuid(
                UUID.fromString("ba0b67f6-adfc-4d47-a9cb-0da8655075ac"));
        alternativeNames.setName("Allen");
        alternativeNamesList.add(alternativeNames);
        roViewDetailsData.setAlternateNames(alternativeNamesList);

        RoChangedEventV1Contacts contactsList = new RoChangedEventV1Contacts();
        RoChangedEventV1Contact contacts = new RoChangedEventV1Contact();
        contacts.setContactUuid(UUID.fromString("a910dbb1-4379-4157-8ff8-cbdffe44599d"));
        contacts.setFirstName("Claire");
        contacts.setLastName("Van");
        contacts.setContactTypeUuid(UUID.fromString("d0f6a688-ae50-4f09-936f-2b62dc6266bb"));
        contacts.setEffectiveFromDateTime(OffsetDateTime.now());
        contacts.setEffectiveToDateTime(OffsetDateTime.now());
        contacts.setAddresses(addressesList);
        contactsList.add(contacts);
        roViewDetailsData.setContacts(contactsList);
        RoChangedEventV1MinimumScores minimumScoreList = new RoChangedEventV1MinimumScores();
        RoChangedEventV1MinimumScore minimumScore = new RoChangedEventV1MinimumScore();
        minimumScore.setMinimumScoreUuid(UUID.fromString("5b5b0ba1-0e7b-41e9-ad19-9ebdad8de876"));
        minimumScore.setModuleTypeUuid(UUID.fromString("5b5b0ba1-0e7b-41e9-ad19-9ebdad8de876"));
        minimumScore.setComponent(ComponentEnum.W);
        minimumScore.setMinimumScoreValue(BigDecimal.TEN);
        minimumScoreList.add(minimumScore);
        roViewDetailsData.setMinimumScores(minimumScoreList);

        RoChangedEventV1LinkedOrganisations linkedOrganisationList =
                new RoChangedEventV1LinkedOrganisations();
        RoChangedEventV1LinkedOrganisation linkedOrganisation =
                new RoChangedEventV1LinkedOrganisation();
        linkedOrganisation.setLinkedRecognisingOrganisationUuid(
                UUID.fromString("5bb8c97c-d829-4d54-87c9-8709a36979a0"));
        linkedOrganisation.setLinkType(LinkTypeEnum.valueOf("PARENT_RO"));
        linkedOrganisation.setLinkEffectiveFromDateTime(
                OffsetDateTime.now());
        linkedOrganisation.setLinkEffectiveToDateTime(
                OffsetDateTime.now());
        linkedOrganisation.setTargetRecognisingOrganisationUuid(
                UUID.fromString("5bb8c97c-d829-4d54-77c9-8709a36979a0"));
        linkedOrganisationList.add(linkedOrganisation);
        RoChangedEventV1LinkedOrganisation linkedOrganisation1 =
                new RoChangedEventV1LinkedOrganisation();
        linkedOrganisation1.setLinkedRecognisingOrganisationUuid(
                UUID.fromString("5bb8c97c-d829-3d54-87c9-8709a36979a0"));
        linkedOrganisation1.setLinkType(LinkTypeEnum.valueOf("RESULTS_DELIVERY"));
        linkedOrganisation1.setLinkEffectiveFromDateTime(
                OffsetDateTime.now());
        linkedOrganisation1.setLinkEffectiveToDateTime(
                OffsetDateTime.now());
        linkedOrganisation.setTargetRecognisingOrganisationUuid(
                UUID.fromString("5bb8c97c-d829-4d54-67c9-8709a36979a0"));
        linkedOrganisationList.add(linkedOrganisation1);
        roViewDetailsData.setLinkedOrganisations(linkedOrganisationList);
        return roViewDetailsData;
    }

    public RoRequestedEventV1 populateRoViewDetailsEventBodyTwo() {
        final RoRequestedEventV1 roViewDetails = new RoRequestedEventV1();
        roViewDetails.setRecognisingOrganisationUuid(
                UUID.fromString("9edbc4ef-b58f-445c-bc41-1239e0168c9e"));
        roViewDetails.setOrganisationName("Cambridge University");
        roViewDetails.setOrganisationId(13455);
        roViewDetails.setOrganisationTypeUuid(
                UUID.fromString("9edbc4ef-b58f-445c-bc41-1239e0168c9e"));
        roViewDetails.setOrganisationStatus(OrganisationStatusEnum.ACTIVE);
        roViewDetails.setVerificationStatus(VerificationStatusEnum.APPROVED);
        roViewDetails.setAcceptsIOL(true);
        roViewDetails.setAcceptsSSR(true);
        roViewDetails.setAcceptsAC(true);
        roViewDetails.setAcceptsGT(true);

        RoChangedEventV1Addresses addressesList = new RoChangedEventV1Addresses();
        RoChangedEventV1Address roChangedEventV1Address = new RoChangedEventV1Address();
        roChangedEventV1Address.setAddressUuid(
                UUID.fromString("ba0b67f6-adfc-4d47-a9cb-0da8655075ac"));
        roChangedEventV1Address.setAddressTypeUuid(
                UUID.fromString("8088042f-c82f-418c-90a4-2e20e8ef40b3"));
        roChangedEventV1Address.setAddressLine1("22 Heathfield Gardens");
        roChangedEventV1Address.setAddressLine2("James Lane");
        roChangedEventV1Address.setAddressLine3("Park Colony");
        roChangedEventV1Address.setAddressLine4("Near KFC");
        roChangedEventV1Address.setCity("Cambridge");
        roChangedEventV1Address.setTerritoryUuid(
                UUID.fromString("dd858eb6-4738-479a-9bd7-3e293aa271b5"));
        roChangedEventV1Address.setTerritoryIsoCode("GB-BIR");
        roChangedEventV1Address.setCountryIso3Code("GBR");
        roChangedEventV1Address.setCountryUuid(
                UUID.fromString("dd858eb6-4738-479a-9bd7-3e293aa271b5"));
        roChangedEventV1Address.setPostalCode("CB2 8EA");
        roChangedEventV1Address.setEmail("alan@gmail.com");
        roChangedEventV1Address.setPhone("1234567890");
        addressesList.add(roChangedEventV1Address);
        roViewDetails.setAddresses(addressesList);

        roViewDetails.setPartnerCode("BC");
        roViewDetails.setPartnerContact("HOME");
        roViewDetails.setMethodOfDelivery(MethodOfDeliveryEnum.POSTAL);
        roViewDetails.setSectorTypeUuid(UUID.fromString("acafb6bd-00a6-4fa9-b9f4-562eaa7ea1cb"));
        roViewDetails.setWebsiteUrl("http://www.officialxyz.com/");
        roViewDetails.setOrganisationCode("UCAS231");

        RoChangedEventV1Notes notesList = new RoChangedEventV1Notes();
        RoChangedEventV1Note notes = new RoChangedEventV1Note();
        notes.setNoteUuid(UUID.fromString("a910dbb1-4379-4157-8ff8-cbdffe44599d"));
        notes.setNoteContent("");
        notes.setNoteTypeUuid(UUID.fromString("ea7c0de6-4646-4b1d-9ee7-9983c6f99fc8"));
        notes.setUpdatedDatetime(LocalDateTime.now());
        notesList.add(notes);
        roViewDetails.setNotes(notesList);

        RoChangedEventV1AlternateNames alternativeNamesList = new RoChangedEventV1AlternateNames();
        RoChangedEventV1AlternateName alternativeNames = new RoChangedEventV1AlternateName();
        alternativeNames.setAlternateNameUuid(
                UUID.fromString("ba0b67f6-adfc-4d47-a9cb-0da8655075ac"));
        alternativeNames.setName("Allen");
        alternativeNamesList.add(alternativeNames);
        roViewDetails.setAlternateNames(alternativeNamesList);

        RoChangedEventV1Contacts contactsList = new RoChangedEventV1Contacts();
        RoChangedEventV1Contact contacts = new RoChangedEventV1Contact();
        contacts.setContactUuid(UUID.fromString("a910dbb1-4379-4157-8ff8-cbdffe44599d"));
        contacts.setFirstName("Claire");
        contacts.setLastName("Van");
        contacts.setContactTypeUuid(UUID.fromString("d0f6a688-ae50-4f09-936f-2b62dc6266bb"));
        contacts.setEffectiveFromDateTime(OffsetDateTime.from(LocalDateTime.of(2020, Month.JUNE, 23, 05, 52, 55)));
        contacts.setEffectiveToDateTime(OffsetDateTime.from(LocalDateTime.of(2022, Month.NOVEMBER, 30, 05, 52, 55)));
        contacts.setAddresses(null);
        contactsList.add(contacts);
        roViewDetails.setContacts(contactsList);

        RoChangedEventV1MinimumScores minimumScoreList = new RoChangedEventV1MinimumScores();
        RoChangedEventV1MinimumScore minimumScore = new RoChangedEventV1MinimumScore();
        minimumScore.setMinimumScoreUuid(UUID.fromString("5b5b0ba1-0e7b-41e9-ad19-9ebdad8de876"));
        minimumScore.setModuleTypeUuid(UUID.fromString("5b5b0ba1-0e7b-41e9-ad19-9ebdad8de876"));
        minimumScore.setComponent(ComponentEnum.W);
        minimumScore.setMinimumScoreValue(BigDecimal.TEN);
        minimumScoreList.add(minimumScore);
        roViewDetails.setMinimumScores(minimumScoreList);

        RoChangedEventV1LinkedOrganisations linkedOrganisationList =
                new RoChangedEventV1LinkedOrganisations();
        RoChangedEventV1LinkedOrganisation linkedOrganisation =
                new RoChangedEventV1LinkedOrganisation();
        linkedOrganisation.setLinkedRecognisingOrganisationUuid(
                UUID.fromString("5bb8c97c-d829-4d54-87c9-8709a36979a0"));
        linkedOrganisation.setLinkType(LinkTypeEnum.valueOf("PARENT_RO"));
        linkedOrganisation.setLinkEffectiveFromDateTime(
                OffsetDateTime.from(LocalDateTime.of(2021, Month.JUNE, 20, 05, 52, 55)));
        linkedOrganisation.setLinkEffectiveToDateTime(
                OffsetDateTime.from(LocalDateTime.of(2022, Month.NOVEMBER, 30, 05, 52, 55)));
        linkedOrganisation.setTargetRecognisingOrganisationUuid(
                UUID.fromString("5bb8c97c-d829-4d54-77c9-8709a36979a0"));
        linkedOrganisationList.add(linkedOrganisation);
        RoChangedEventV1LinkedOrganisation linkedOrganisation1 =
                new RoChangedEventV1LinkedOrganisation();
        linkedOrganisation1.setLinkedRecognisingOrganisationUuid(
                UUID.fromString("5bb8c97c-d829-3d54-87c9-8709a36979a0"));
        linkedOrganisation1.setLinkType(LinkTypeEnum.valueOf("RESULTS_DELIVERY"));
        linkedOrganisation1.setLinkEffectiveFromDateTime(
                OffsetDateTime.from(LocalDateTime.of(2021, Month.JUNE, 21, 05, 52, 55)));
        linkedOrganisation1.setLinkEffectiveToDateTime(
                OffsetDateTime.from(LocalDateTime.of(2022, Month.NOVEMBER, 29, 05, 52, 55)));
        linkedOrganisation.setTargetRecognisingOrganisationUuid(
                UUID.fromString("5bb8c97c-d829-4d54-67c9-8709a36979a0"));
        linkedOrganisationList.add(linkedOrganisation1);
        roViewDetails.setLinkedOrganisations(linkedOrganisationList);

        return roViewDetails;
    }
    public static SocketResponseMetaDataV1 mapRequestEventHeaderToSocketResponseHeader() {
        final SocketResponseMetaDataV1 responseHeaders = new SocketResponseMetaDataV1();
        responseHeaders.setCorrelationId("a6d58192-dd39-4953-a619-26b8b43cf2ad");
        responseHeaders.setConnectionId("a6d58192-dd39");
        return responseHeaders;
    }

    public static BaseEventErrors getBaseEventErrors(){
        BaseEventErrors baseEventErrors;
        List<ErrorDescription> errorDescriptionList = new ArrayList<>();
        ErrorDescription errorDescription = new ErrorDescription();
        errorDescription.setErrorCode("V3069");
        errorDescription.setMessage("Ro not found");
        errorDescriptionList.add(errorDescription);
        baseEventErrors = new BaseEventErrors(errorDescriptionList);
        return baseEventErrors;
    }

}
