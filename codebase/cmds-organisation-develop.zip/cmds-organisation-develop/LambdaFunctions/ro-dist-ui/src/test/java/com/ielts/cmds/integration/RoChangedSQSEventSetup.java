package com.ielts.cmds.integration;

import com.fasterxml.jackson.databind.ObjectMapper;

import com.ielts.cmds.api.roui007rocreaterequested.OrganisationStatusEnum;
import com.ielts.cmds.api.roui007rocreaterequested.MethodOfDeliveryEnum;
import com.ielts.cmds.api.roui007rocreaterequested.VerificationStatusEnum;
import com.ielts.cmds.api.roui007rocreaterequested.LinkTypeEnum;
import com.ielts.cmds.api.roui007rocreaterequested.ComponentEnum;
import com.ielts.cmds.api.rows178changedresponsegenerated.SocketResponseMetaDataV1;
import com.ielts.cmds.common.exception.util.ErrorDescription;
import com.ielts.cmds.infrastructure.event.BaseEventErrors;
import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class RoChangedSQSEventSetup {

    final ObjectMapper mapper = new ObjectMapper();

    public static RoChangedEventV1 populateRoChangedEventBody() {
        final RoChangedEventV1 roChangeData = new RoChangedEventV1();
        roChangeData.setRecognisingOrganisationUuid(
                UUID.fromString("9edbc4ef-b58f-445c-bc41-1239e0168c9e"));
        roChangeData.setOrganisationName("Cambridge");
        roChangeData.setOrganisationId(13455);

        return roChangeData;
    }

    public RoChangedEventV1 populateRoChangedEventBodyTwo() {
        final RoChangedEventV1 roChangeData = new RoChangedEventV1();
        roChangeData.setRecognisingOrganisationUuid(
                UUID.fromString("9edbc4ef-b58f-445c-bc41-1239e0168c9e"));
        roChangeData.setOrganisationName("Cambridge");
        roChangeData.setOrganisationId(13455);

        return roChangeData;
    }
    public static SocketResponseMetaDataV1 mapRequestEventHeaderToSocketResponseHeader() {
        final SocketResponseMetaDataV1 responseHeaders = new SocketResponseMetaDataV1();
        responseHeaders.setCorrelationId("a6d58192-dd39-4953-a619-26b8b43cf2ad");
        responseHeaders.setConnectionId("a6d58192-dd39");
        return responseHeaders;
    }

    public static BaseEventErrors getBaseEventErrors(){
        BaseEventErrors baseEventErrors;
        List<ErrorDescription> errorDescriptionList = new ArrayList<>();
        ErrorDescription errorDescription = new ErrorDescription();
        errorDescription.setErrorCode("V3069");
        errorDescription.setMessage("Ro can not update");
        errorDescriptionList.add(errorDescription);
        baseEventErrors = new BaseEventErrors(errorDescriptionList);
        return baseEventErrors;
    }

}
