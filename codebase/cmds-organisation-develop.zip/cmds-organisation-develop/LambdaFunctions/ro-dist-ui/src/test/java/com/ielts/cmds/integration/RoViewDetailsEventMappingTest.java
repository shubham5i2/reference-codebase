package com.ielts.cmds.integration;

import static com.ielts.cmds.integration.RoViewDetailsSQSEventSetup.getBaseEventErrors;
import static com.ielts.cmds.integration.RoViewDetailsSQSEventSetup.mapRequestEventHeaderToSocketResponseHeader;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doReturn;

import com.ielts.cmds.api.rows173requestedresponsegenerated.RoDataOutV1;
import com.ielts.cmds.api.rows173requestedresponsegenerated.RoDataOutV1Envelope;
import com.ielts.cmds.api.rows173requestedresponsegenerated.SocketResponseMetaDataV1;
import com.ielts.cmds.serialization.lambda.utils.HeaderContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalErrorContext;
import com.ielts.cmds.serialization.lambda.utils.ThreadLocalHeaderContext;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import com.fasterxml.jackson.core.JsonProcessingException;

import com.ielts.cmds.integration.mapping.RoRequestedEventMapping;
import com.ielts.cmds.organisation.common.out.event.RoRequestedEventV1;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.UUID;

@ExtendWith(MockitoExtension.class)
class RoViewDetailsEventMappingTest {

    @Spy
    private RoRequestedEventMapping roViewDetailsEventMapping;

    final HeaderContext context = new HeaderContext();

    /**
     * Test to validate the Response Event Body when Request Event Body is passed.
     *
     * @throws JsonProcessingException
     */

    @BeforeEach
    public void setUp() {
        context.setConnectionId("a6d58192-dd39");
        context.setCorrelationId(UUID.fromString("a6d58192-dd39-4953-a619-26b8b43cf2ad"));
        ThreadLocalHeaderContext.setContext(context);
    }

    @Test
    void whenRequestEventBodyProvided_ThenValidateSocketResponseEventBody() throws JsonProcessingException {

        ThreadLocalErrorContext.setContext(getBaseEventErrors());
        RoRequestedEventV1 eventBody = RoViewDetailsSQSEventSetup.populateRoViewDetailsEventBody();
        RoDataOutV1Envelope response=roViewDetailsEventMapping.process(eventBody);
        RoDataOutV1 responseBody = roViewDetailsEventMapping.mapRequestEventBodyToResponseBody(eventBody);
        assertEquals(eventBody.getRecognisingOrganisationUuid(),responseBody.getRecognisingOrganisationUuid());
        assertEquals(eventBody.getOrganisationTypeUuid(), responseBody.getOrganisationTypeUuid());
        assertEquals(eventBody.getAcceptsSSR(), responseBody.getAcceptsSSR());
        assertEquals(eventBody.getOrganisationCode(), responseBody.getOrganisationCode());
        assertEquals("V3069", response.getErrors().getErrorList().get(0).getErrorCode());
    }

    @Test
    void whenRequestEventBodyProvided_ThenValidateSocketResponseEventErrors() {
        RoRequestedEventV1 eventBody = RoViewDetailsSQSEventSetup.populateRoViewDetailsEventBody();
        String expectedErrorMessage = "Ro not found";
        String expectedErrorCode = "V3069";
        ThreadLocalErrorContext.setContext(getBaseEventErrors());
        SocketResponseMetaDataV1 responseHeaders = mapRequestEventHeaderToSocketResponseHeader();
        doReturn(responseHeaders).when(roViewDetailsEventMapping).mapRequestEventHeaderToSocketResponseHeader();
        RoDataOutV1Envelope actualResult = roViewDetailsEventMapping.process(eventBody);
        assertEquals(expectedErrorMessage, actualResult.getErrors().getErrorList().get(0).getMessage());
        assertEquals(expectedErrorCode, actualResult.getErrors().getErrorList().get(0).getErrorCode());
        assertEquals(responseHeaders.getConnectionId(), actualResult.getMeta().getConnectionId());
        assertEquals(responseHeaders.getCorrelationId(), actualResult.getMeta().getCorrelationId());

    }

    @Test
    void whenRequestEventBodyProvided_ThenValidateSocketResponseEventBodyIsNull() throws JsonProcessingException {
        ThreadLocalErrorContext.setContext(RoViewDetailsSQSEventSetup.getBaseEventErrors());
        RoRequestedEventV1 eventBody =null;
        final RoDataOutV1Envelope response = roViewDetailsEventMapping.process(eventBody);
        assertEquals(null, response.getResponse());
    }

}
