package com.ielts.cmds.integration;

import com.ielts.cmds.organisation.common.out.event.RoChangedEventV1;
import java.util.UUID;

public class RoUpdateSQSEventSetup {

       public static RoChangedEventV1 populateRoChangedEventBody() {
        final RoChangedEventV1 roChangeData = new RoChangedEventV1();
        roChangeData.setRecognisingOrganisationUuid(
                UUID.fromString("9edbc4ef-b58f-445c-bc41-1239e0168c9e"));
        roChangeData.setOrganisationName("Cambridge");
        roChangeData.setOrganisationId(13455);
        roChangeData.setOrganisationTypeUuid(
                UUID.fromString("9edbc4ef-b58f-445c-bc41-1239e0168c9e"));
        return roChangeData;
    }

    public RoChangedEventV1 populateRoChangedEventBodyTwo() {
        final RoChangedEventV1 roChangeData = new RoChangedEventV1();
        roChangeData.setRecognisingOrganisationUuid(
                UUID.fromString("9edbc4ef-b58f-445c-bc41-1239e0168c9e"));
        roChangeData.setOrganisationName("Cambridge");
        roChangeData.setOrganisationId(13455);
        roChangeData.setOrganisationTypeUuid(
                UUID.fromString("9edbc4ef-b58f-445c-bc41-1239e0168c9e"));

        return roChangeData;
    }

}
