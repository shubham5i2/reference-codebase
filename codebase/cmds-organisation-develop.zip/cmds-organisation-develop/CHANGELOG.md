### [3.4.54](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.53...v3.4.54) (2024-05-21)


### ⚠ BREAKING CHANGES

* feature/IMOD_62045_and_IMOD_62016

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!388

* Merge branch 'feature/IMOD_62045_and_IMOD_62016' into 'develop' ([7974ce4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/7974ce407a6b4fb109345a10d824e1c7b31eec4d))

### [3.4.53](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.52...v3.4.53) (2024-05-17)


### ⚠ BREAKING CHANGES

* Feature/IMOD-60920-ro-to-vo-defect

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!387

* Merge branch 'feature/IMOD-60920-RO-to-VO-Defect' into 'develop' ([19b703f](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/19b703fcd2e3bcb15dd7289588a2f50c18c16224))

### [3.4.52](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.51...v3.4.52) (2024-05-08)


### ⚠ BREAKING CHANGES

* feature/component_type_enum_update

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!385

* Merge branch 'feature/component_type_enum_update' into 'develop' ([3aace52](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/3aace52129e4c86df8dbef7aeee735abc8144b50))

### [3.4.51](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.50...v3.4.51) (2024-05-08)


### ⚠ BREAKING CHANGES

* Feature/imod 60391 ro ui event jars

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!380

* Merge branch 'feature/IMOD-60391-ro-ui-event-jars' into 'develop' ([1d00232](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/1d0023290ae02d39c49e8c830472892d5d9573cc))

### [3.4.50](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.49...v3.4.50) (2024-05-08)


### Features

* <h2> Tech Debt </h2> <h3> IMOD-60283 - Optimizing RO product cache and Need to delete product table </h3> <br/> ([077ad09](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/077ad09fea047f7806c1bfb19e5c9e954e0bd1c6))

### [3.4.49](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.48...v3.4.49) (2024-05-07)


### Features

* <h2> Tech Debt </h2> <h3> IMOD-48376 - Panda : Tech Debt : Distributor lambda response size reduction RO</h3> <br/> ([f7c700d](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/f7c700d6041c74f9a12a3fd3e171c84c3c8375bb))

### [3.4.48](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.47...v3.4.48) (2024-05-07)


### ⚠ BREAKING CHANGES

* Feature/ro ui response jars

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!358

* Merge branch 'feature/RO_UI_Response_jars' into 'develop' ([99f6370](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/99f6370d427b48dc425d1d5f482291f9248fb7b1))

### [3.4.47](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.46...v3.4.47) (2024-05-07)


### Features

* <h2> Business Story </h2> <h3> IMOD-45753 - Enable VO hierarchies in CMDS</h3> <br/> ([6a93617](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/6a936178165d90913cec86f7ff025cc1686f363e))

### [3.4.46](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.45...v3.4.46) (2024-05-06)


### ⚠ BREAKING CHANGES

* Feature/ IMOD-60806-version upd

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!381

* Merge branch 'feature/version_upd' into 'develop' ([3140bf4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/3140bf4b1c849f5eade2bbd94e7fa9bc503fb83a))

### [3.4.45](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.44...v3.4.45) (2024-04-29)


### Features

* <h2> Defect </h2> <h3> IMOD-60938 - [CMDS-BC-SIT] : Results Admin Email Address accepting duplicate email id while Create/Update ROs with verification status of "verified" </h3> <br/> ([d91442a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/d91442a8003f7ae90afd5529a408c6a477a6eddc))

### [3.4.44](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.43...v3.4.44) (2024-04-29)


### Features

* <h2> Technical Story </h2> <h3> IMOD-51775 - RO:Separate SQS for LocationChanged event </h3> <br/> ([9e7a47b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/9e7a47b5ed80a0b9012186f0f9f1c34be5ff1c35))

### [3.4.43](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.42...v3.4.43) (2024-04-26)


### Features

* <h2> Defect </h2> <h3> IMOD-60990 - [CUPA - SIT] 'Accepts AC' is getting deselected when creating a new RO in the CMDS UI </h3> <br/> ([455fc7b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/455fc7b8cd3946c5e96fe331905f458b47401b5f))

### [3.4.42](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.41...v3.4.42) (2024-04-15)


### ⚠ BREAKING CHANGES

* ac_gt_product-characteristics

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!370

* Merge branch 'feature/ac_gt_db-changes' into 'develop' ([e54d749](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/e54d74960a8c6d40cc7d1ad0989cf2f9e4290a90))

### [3.4.41](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.40...v3.4.41) (2024-04-15)


### ⚠ BREAKING CHANGES

* lambda reduce size

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!371

* Merge branch 'feature/dist-ui-reduction' into 'develop' ([88c2d82](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/88c2d8207dcae2bc9ca8233526f32b4ac75c7ae3))

### [3.4.40](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.39...v3.4.40) (2024-04-15)


### Features

* <h2> Business feature</h2> <h3> IMOD-58482 - Make RO Admin details optional in the back end for ROs with a verification status of "Verified"</h3><br/> <h3> IMOD-46800 - Disallow selection of "Verified" ROs as an ADO in a hierarchy </h3><br/> <h3> IMOD-59328 - Create entries for AC/GT product acceptance in the LPR RO.RECOGNISED_PRODUCT table </h3> <br/> ([5832f4d](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/5832f4d24e2e152d3a59f22bd8e4886ab91c48a6))

### [3.4.39](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.38...v3.4.39) (2024-04-12)


### ⚠ BREAKING CHANGES

* feature/AC_GT_Negative_scenario

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!368

* Merge branch 'feature/AC_GT_Negative_scenario' into 'develop' ([f02751a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/f02751af316974b253c5c7ba21941674fb4e23fa))

### [3.4.38](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.37...v3.4.38) (2024-04-12)


### ⚠ BREAKING CHANGES

* feature/AC_GT_null_check_fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!367

* Merge branch 'feature/AC_GT_null_check' into 'develop' ([55aa82a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/55aa82a8e16a9fb17a94d2c71b6477c8730c6aeb))

### [3.4.37](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.36...v3.4.37) (2024-04-10)


### ⚠ BREAKING CHANGES

* Feature/imod-59256-and-imod-59328-ac-gt-product-characteristics

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!354

* Merge branch 'feature/IMOD-59256-and-IMOD-59328-AC-GT-Product-characteristics' into 'develop' ([f903b33](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/f903b3341b469400646d8f0895c9a485c0a7375a))

### [3.4.36](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.35...v3.4.36) (2024-04-01)


### ⚠ BREAKING CHANGES

* feature/RO_sonar_code_smells_fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!343

* Merge branch 'feature/RO_sonar_code_smells_fix' into 'develop' ([86ac742](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/86ac7428a87969ab80a59ca800fa0f23a365cb4e))

### [3.4.35](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.34...v3.4.35) (2024-03-26)


### ⚠ BREAKING CHANGES

* feature/IMOD_46800_disallow_selection_of_verfication_of_Ros_as_an_ADO

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!347

* Merge branch 'feature/IMOD_46800_disallow_selection_of_verfication_of_Ros_as_an_ADO' into 'develop' ([4d2490a](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/4d2490a79b746ae44c2148313221c98486ee5726))

### [3.4.34](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.33...v3.4.34) (2024-03-25)


### ⚠ BREAKING CHANGES

* Feature/imod-58482-admin-details-optional-for-verified-ro

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!349

* Merge branch 'feature/IMOD-58482-admin-details-optional-for-verified-ro' into 'develop' ([b0e5db9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/b0e5db92da42243fe64f37af014b7f4111e771ad))

### [3.4.33](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.32...v3.4.33) (2024-03-22)


### ⚠ BREAKING CHANGES

* method_of_delivery_enum_issue_fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!345

* Merge branch 'feature/heirarchy_update_code_fix' into 'develop' ([44834c6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/44834c6f92d516e25bbeb8540b59fd31d6ce3d1f))

### [3.4.32](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.31...v3.4.32) (2024-03-21)


### ⚠ BREAKING CHANGES

* Feature/enum-issue-fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!352

* Merge branch 'feature/enum-issue-fix' into 'develop' ([5041b68](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/5041b683dd191b4ee1fcbc7c7d4c2c81b1ba34ea))

### [3.4.31](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.30...v3.4.31) (2024-03-18)


### ⚠ BREAKING CHANGES

* Feature/imod-59190-defect-fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!348

* Merge branch 'feature/IMOD-59190-defect-fix' into 'develop' ([3bff09e](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/3bff09e7c82ffb8717a0a788c02764371bd1b5c2))

### [3.4.30](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.29...v3.4.30) (2024-03-01)


### ⚠ BREAKING CHANGES

* feature/Release_version_organisation_events

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!344
* feature/imod-57976-RO-publish-release-version

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!341

* Merge branch 'feature/imod-57976-RO-publish-release-version' into 'develop' ([7b572c0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/7b572c06714aa55ba07bbedebb5d6270d8bc19fe))
* Merge branch 'feature/Release_version_organisation_events' into 'develop' ([81c9d6f](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/81c9d6faacfb57cc2fd502e151cda6b71af9a1cb))

### [3.4.29](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.28...v3.4.29) (2024-01-08)


### ⚠ BREAKING CHANGES

* feature/MR_for_tag_genrate

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!335
* feature/IMOD_56202_ro_Vulnerabilities

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!333

* Merge branch 'feature/IMOD_56202_ro_Vulnerabilities' into 'develop' ([2175f81](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/2175f810faa33228f6806ce2b43ad8f312e6fbd2))
* Merge branch 'feature/MR_for_tag_genrate' into 'develop' ([7ebe4e5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/7ebe4e523988496304175f2ba19cc9840619a0e9))

### [3.4.28](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.27...v3.4.28) (2023-12-22)

### [3.4.27](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.26...v3.4.27) (2023-12-20)


### ⚠ BREAKING CHANGES

* RO Access product data from cache

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!331

* Merge branch 'feature/48463-jedisRead-final' into 'develop' ([0290e07](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/0290e070ac660970bf4ca01bb0c00eaf5bfb426a))

### [3.4.26](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.25...v3.4.26) (2023-12-12)


### ⚠ BREAKING CHANGES

* upgrading-outbox-version-to-0.0.15

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!332

* Merge branch 'feature/IMOD-47906-dedicated-sns' into 'develop' ([27ea660](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/27ea66060de06d169fd10d9b416b3f5235bcda00))

### [3.4.25](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.24...v3.4.25) (2023-11-29)


### ⚠ BREAKING CHANGES

* Feature/code-smell-fixing and  IMOD-55469

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!330

* Merge branch 'feature/code-smell-fixing' into 'develop' ([f3840c6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/f3840c6447b0633089d8acc3bbf43e8d52c582df))

### [3.4.24](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.23...v3.4.24) (2023-11-16)


### ⚠ BREAKING CHANGES

* Feature/imod 50199 ro event serialization changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!317

* Merge branch 'feature/IMOD-50199-RO-event-serialization-changes' into 'develop' ([06f8338](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/06f833878be5aa5134d8b4673717c6e3fd2b49d9))

### [3.4.23](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.22...v3.4.23) (2023-11-14)


### ⚠ BREAKING CHANGES

* feature/IMOD_52042_fixing_outbox_ignore_Persistence_changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!329

* Merge branch 'feature/IMOD_52042_fixing_outbox_ignore_Persistence_changes' into 'develop' ([b01e58b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/b01e58b1c118dc90de70e1ed911074ca269e4b61))

### [3.4.22](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.21...v3.4.22) (2023-10-30)


### ⚠ BREAKING CHANGES

* feature/IMOD_50799_fix_for_ro_dist_ui

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!325

* Merge branch 'feature/IMOD_50799_fix_for_ro_dist_ui' into 'develop' ([9f3bf0b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/9f3bf0b767d7943806c57580a02e7e80943f69a7))

### [3.4.21](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.20...v3.4.21) (2023-09-15)


### ⚠ BREAKING CHANGES

* Feature/IMOD-49966 RO Verified changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!318

* Merge branch 'feature/IMOD-49966' into 'develop' ([5b00012](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/5b00012ec2cbf0b4f257df1d2a639c451e268d33))

### [3.4.20](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.19...v3.4.20) (2023-09-11)


### ⚠ BREAKING CHANGES

* hotfix merge

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!311

* Merge branch 'hotfix' into 'develop' ([1ea74f7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/1ea74f724f15a8da43707d844ad5e79a61c0d433))

### [3.4.19](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.18...v3.4.19) (2023-08-29)


### ⚠ BREAKING CHANGES

* Feature/IMOD-49507-sonar-fix

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!314

* Merge branch 'feature/IMOD-49507-sonar-fix' into 'develop' ([27c375c](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/27c375ccee32ff5ebd4e1e145d55394bfee4544c))

### [3.4.18](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.17...v3.4.18) (2023-08-24)


### ⚠ BREAKING CHANGES

* feature/Bug_fix_IMOD_50035_49167_50128

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!315

* Merge branch 'feature/IMOD-50035_search_fields_fix' into 'develop' ([d2247e9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/d2247e90e9d1fb2c26677b2ddacb402ec64429f9))

### [3.4.17](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.16...v3.4.17) (2023-08-18)

### [3.4.16](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.15...v3.4.16) (2023-08-17)

### [3.4.15](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.14...v3.4.15) (2023-08-16)

### [3.4.14](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.13...v3.4.14) (2023-08-08)


### ⚠ BREAKING CHANGES

* Feature/IMOD-49354-sonar-fix-for-develop

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!305

* Merge branch 'feature/sonar-fix-for-develop' into 'develop' ([e2f4538](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/e2f4538da0968e806f984e54d7bd2ca6a4e79da5))

### [3.4.13](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.12...v3.4.13) (2023-08-07)


### ⚠ BREAKING CHANGES

* feature/Remove_sandbox3_below_baseline_file

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!309

* Merge branch 'feature/Remove_sandbox3_below_baseline_file' into 'develop' ([2987c77](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/2987c773da7410529249e9ef978157040eab5cdf))

### [3.4.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.11...v3.4.12) (2023-08-07)

### [3.4.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.10...v3.4.11) (2023-08-07)


### ⚠ BREAKING CHANGES

* Merge hotfix ( v3.4.5-hotfix.1) into develop

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!303

* Merge branch 'hotfix' into 'develop' ([e722fc0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/e722fc0809ce736ed03e6f1560b0920444ef72c6))


### Features

* <h1>Features :</h1><h2>Business Features</h2><h3>IMOD-46502 Add State/Territory to search criteria for an RO/VO</h3><p><strong>Purpose:</strong><br />To be able to search for the RO based on territory selection </p><br /><h3>IMOD-44732 - Database Script Changes in SM (Description: New permission has to be added in user_group_hierarchy table for View Ban (VIEW_TT_BAN_EVENT) w.r.t [IMOD-28044] implementation and added new permissions to Business Assurance Manager and Business Assurance Admin support for View TT History (UTT_BOOKING_HISTORY_VIEW) w.r.t [IMOD-41396])</h3><p><strong>Purpose:</strong><br />To have the permission data up to date as per SM DB </p><br /><h3>IMOD-48613 DEV: RO hierarchy data load automation script changes</h3><p><strong>Purpose:</strong><br />To perform RO data load in all environments with the script execution </p><br /><h2>Defects</h2><h3>IMOD-48401 100 character limit in RO website data field</h3><br /><h2>Additional Info</h2><h3>IMOD-48834 -  [SIT Release V0.0.57.Green] DevOps support ticket for RO MX </h3><p><strong>Purpose:</strong><br /> To have code release version and pipeline details </p><br /><h3>IMOD-48836  - [SIT Release v0.0.57.Green] - Smoke Test for RO Mx </h3><p><strong>Purpose:</strong><br />To track smoke test results </p><br /> ([74f7527](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/74f7527432311590746839b1888104642a8683fc))

### [3.4.5-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.4...v3.4.5-hotfix.1) (2023-08-03)

### [3.4.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.9...v3.4.10) (2023-07-21)


### ⚠ BREAKING CHANGES

* increasing version of CMDSCommonutils and event-adapter-java lib

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!299

* Merge branch 'feature/fix-develop-pipeline' into 'develop' ([169f2fe](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/169f2fe56cf324fc7ffe28f6724f8caff78a2db9))

### [3.4.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.8...v3.4.9) (2023-07-05)


### Features

* <h1>Features :</h1><h2>Business Features</h2><h3>IMOD-45173 Enhance "main" search for RO names </h3><p><strong>Purpose:</strong><br />To implement organisation name full text/exact match search in RO main screen </p><br /><h3>IMOD-48275 [RO MX] Add UKVI IOC OSR product data to RO (AC and GT) </h3><p><strong>Purpose:</strong><br />To activate SELT IOC OSR AC and GT products </p><br /><h3>IMOD-38411 Add the UKVI SELT IOC products to the product acceptance table for all ROs </h3><p><strong>Purpose:</strong><br />ROs need to be selectable for UKVI SELT IOC results delivery so that the test taker can send their SELT results to any RO’ . This is to retro-fit SELT IOC acceptance for any RO that does not currently have the products in their product acceptance table. All newly created ROs will have this product acceptance set automatically if they opt in to IOC. </p><br /><h3>IMOD-34572 Add the UKVI IOL SELT products to the product acceptance table for all ROs that accept IOL </h3><p><strong>Purpose:</strong><br />ROs need to be selectable for UKVI SELT IOL results delivery so that the test taker can send their SELT results to any RO’ . This is to retro-fit SELT IOL acceptance for any RO that does not currently have the products in their product acceptance table. All newly created ROs will have this product acceptance set automatically if they opt in to IOL. </p><br /><h2>Technical Features</h2><h3>IMOD-41923 RO : Automation script for hierarchy sheet </h3><p><strong>Purpose:</strong><br />Create script to prepare RO hierarchy sheet with org ids as needed for actual hierarchy update .</p><br /><h3>IMOD-44258 Event serialization  -> Changes in Dist Lambda (RO) -> ro-dist-ui </h3><p><strong>Purpose:</strong><br />Event serialization changes for RO dist UI lamda.</p><br /><h3>IMOD-41954 Panda: RO : Event Serialization Change for - EVT-112 - LocationChanged </h3><p><strong>Purpose:</strong><br />Event serialization changes for EVT-112(business event) consumer changes</p><br /><h2>Defect Fixes</h2><h3>IMOD-45159 IOL acceptance flag not working correctly for RO/VO records</h3><br /><h2>Additional Info</h2><h3>IMOD-45562 [SIT Release v0.0.56.3] - Infra Support Ticket for RO Mx</h3><p><strong>Purpose:</strong><br />Instructions on how to update SELT IOC and IOL products for all ROs.</p><br /><h3>IMOD-46540 Platform Deployment Infra Activities Needed for RO MX for Event Serialization - 2 </h3><p><strong>Purpose:</strong><br /> Event serialization infra changes to add required SSM parameters.</p><br /><h3>IMOD-45558 [SIT Release v0.0.56.3] - Smoke Test for RO Mx </h3><p><strong>Purpose:</strong><br /> To track smoke test results.</p><br /><h3>IMOD-45516 [SIT Release V0.0.56.3] DevOps support ticket for RO and RO Swagger </h3><p><strong>Purpose:</strong><br /> To define release version details for both RO MX and RO Swagger.</p><br /> ([e6fb36b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/e6fb36b05b06d3d9d715477c22d4077e86fa73fd))

### [3.4.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.7...v3.4.8) (2023-07-05)


### Features

* <h1>Features :</h1><h2>Business Features</h2><h3>IMOD-45173 Enhance "main" search for RO names </h3><p><strong>Purpose:</strong><br />To implement organisation name full text/exact match search in RO main screen </p><br /><h3>IMOD-48275 [RO MX] Add UKVI IOC OSR product data to RO (AC and GT) </h3><p><strong>Purpose:</strong><br />To activate SELT IOC OSR AC and GT products </p><br /><h3>IMOD-38411 Add the UKVI SELT IOC products to the product acceptance table for all ROs </h3><p><strong>Purpose:</strong><br />ROs need to be selectable for UKVI SELT IOC results delivery so that the test taker can send their SELT results to any RO’ . This is to retro-fit SELT IOC acceptance for any RO that does not currently have the products in their product acceptance table. All newly created ROs will have this product acceptance set automatically if they opt in to IOC. </p><br /><h3>IMOD-34572 Add the UKVI IOL SELT products to the product acceptance table for all ROs that accept IOL </h3><p><strong>Purpose:</strong><br />ROs need to be selectable for UKVI SELT IOL results delivery so that the test taker can send their SELT results to any RO’ . This is to retro-fit SELT IOL acceptance for any RO that does not currently have the products in their product acceptance table. All newly created ROs will have this product acceptance set automatically if they opt in to IOL. </p><br /><h2>Technical Features</h2><h3>IMOD-41923 RO : Automation script for hierarchy sheet </h3><p><strong>Purpose:</strong><br />Create script to prepare RO hierarchy sheet with org ids as needed for actual hierarchy update .</p><br /><h3>IMOD-44258 Event serialization  -> Changes in Dist Lambda (RO) -> ro-dist-ui </h3><p><strong>Purpose:</strong><br />Event serialization changes for RO dist UI lamda.</p><br /><h3>IMOD-41954 Panda: RO : Event Serialization Change for - EVT-112 - LocationChanged </h3><p><strong>Purpose:</strong><br />Event serialization changes for EVT-112(business event) consumer changes</p><br /><h2>Defect Fixes</h2><h3>IMOD-45159 IOL acceptance flag not working correctly for RO/VO records</h3><br /><h2>Additional Info</h2><h3>IMOD-45562 [SIT Release v0.0.56.3] - Infra Support Ticket for RO Mx</h3><p><strong>Purpose:</strong><br />Instructions on how to update SELT IOC and IOL products for all ROs.</p><br /><h3>IMOD-46540 Platform Deployment Infra Activities Needed for RO MX for Event Serialization - 2 </h3><p><strong>Purpose:</strong><br /> Event serialization infra changes to add required SSM parameters.</p><br /><h3>IMOD-45510 Platform Deployment Infra Activities Needed for RO MX for user_group_hierarchy table manual script run </h3><p><strong>Purpose:</strong><br /> To update user_group_hierarchy table manually by Infra due to having large sql.</p><br /><h3>IMOD-45558 [SIT Release v0.0.56.3] - Smoke Test for RO Mx </h3><p><strong>Purpose:</strong><br /> To track smoke test results.</p><br /><h3>IMOD-45516 [SIT Release V0.0.56.3] DevOps support ticket for RO and RO Swagger </h3><p><strong>Purpose:</strong><br /> To define release version details for both RO MX and RO Swagger.</p><br /> ([fa71309](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/fa71309db5c8b6084d798a42c0920d7a624d4510))

### [3.4.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.6...v3.4.7) (2023-07-04)

### [3.4.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.5...v3.4.6) (2023-07-03)

### [3.4.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.4...v3.4.5) (2023-07-03)




### [3.4.5-hotfix.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.5-hotfix.3...v3.4.5-hotfix.4) (2023-08-08)

### [3.4.5-hotfix.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.5-hotfix.2...v3.4.5-hotfix.3) (2023-08-07)

### [3.4.5-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.5-hotfix.1...v3.4.5-hotfix.2) (2023-08-04)

### [3.4.5-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.4...v3.4.5-hotfix.1) (2023-08-03)

### [3.4.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.3...v3.4.4) (2023-06-27)

### [3.4.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.2...v3.4.3) (2023-06-26)


### ⚠ BREAKING CHANGES

* update user group hierarchy imod_44732

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!274

* Merge branch 'feature/update_user_group_hierarchy_table' into 'develop' ([e3f5437](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/e3f54373c4ff1fca87e91cdcabe811ea5d781961))

### [3.4.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.1...v3.4.2) (2023-06-26)

### [3.4.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.4.0...v3.4.1) (2023-06-20)

## [3.4.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.49...v3.4.0) (2023-06-20)


### Features

* <h2>Additional Info</h2><h3>IMOD-45562 [SIT Release v0.0.56] - Infra Support Ticket for RO Mx</h3><p><strong>Purpose:</strong><br />Instructions on how to update SELT IOC and IOL products for all ROs.</p><br /> ([9ae3e1e](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/9ae3e1e9794ebb3d29a7db4f5c7a4ba7c8326b58))
* <h2>Additional Info</h2><h3>IMOD-45562 [SIT Release v0.0.56] - Infra Support Ticket for RO Mx</h3><p><strong>Purpose:</strong><br />Instructions on how to update SELT IOC and IOL products for all ROs.</p><br /> ([fc234e4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/fc234e4a139c0a5661ee3b37a9a4238d9575abff))

### [3.3.49](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.48...v3.3.49) (2023-06-19)


### ⚠ BREAKING CHANGES

* IMOD_46051_deactivating_products

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!281

* Merge branch 'hotfix' into 'develop' ([8d8e2eb](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/8d8e2eb1c16fcb48b5e7624707b8b32a2e82593b))


### Features

* <h3> ([7f2a377](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/7f2a377f4ed77fd2a1a3f1bee7d4832c2ebeab49))
* <h3>Features :</h3><h2>Business Features</h2><h3>IMOD-39569 Add Country to search criteria for an RO/VO </h3><p><strong>Purpose:</strong><br />Helps searching for Organisations based on country </p><br /><h3>IMOD-36331 Change 'Accepts SSR' flag for ROs to 'Accept OSR' </h3><p><strong>Purpose:</strong><br />'Accepts SSR’ flag in the RO UI will be changed to ‘Accepts One Skill Retakes’ for marketing </p><br /><h3>IMOD-38411 Add the UKVI SELT IOC products to the product acceptance table for all ROs </h3><p><strong>Purpose:</strong><br />ROs need to be selectable for UKVI SELT IOC results delivery so that the test taker can send their SELT results to any RO’ . This is to retro-fit SELT IOC acceptance for any RO that does not currently have the products in their product acceptance table. All newly created ROs will have this product acceptance set automatically if they opt in to IOC. </p><br /><h3>IMOD-34572 Add the UKVI IOL SELT products to the product acceptance table for all ROs that accept IOL </h3><p><strong>Purpose:</strong><br />ROs need to be selectable for UKVI SELT IOL results delivery so that the test taker can send their SELT results to any RO’ . This is to retro-fit SELT IOL acceptance for any RO that does not currently have the products in their product acceptance table. All newly created ROs will have this product acceptance set automatically if they opt in to IOL. </p><br /><h2>Technical Features</h2><h3>IMOD-41923 RO : Automation script for hierarchy sheet </h3><p><strong>Purpose:</strong><br />Create script to prepare RO hierarchy sheet with org ids as needed for actual hierarchy update .</p><br /> ([5e31156](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/5e31156aec3a9c35f422546b83f6a26c0a25edbd))
* <h3>Features :</h3><h2>Business Features</h2><h3>IMOD-39569 Add Country to search criteria for an RO/VO </h3><p><strong>Purpose:</strong><br />Helps searching for Organisations based on country </p><br /><h3>IMOD-36331 Change 'Accepts SSR' flag for ROs to 'Accept OSR' </h3><p><strong>Purpose:</strong><br />'Accepts SSR’ flag in the RO UI will be changed to ‘Accepts One Skill Retakes’ for marketing </p><br /><h3>IMOD-38411 Add the UKVI SELT IOC products to the product acceptance table for all ROs </h3><p><strong>Purpose:</strong><br />ROs need to be selectable for UKVI SELT IOC results delivery so that the test taker can send their SELT results to any RO’ . This is to retro-fit SELT IOC acceptance for any RO that does not currently have the products in their product acceptance table. All newly created ROs will have this product acceptance set automatically if they opt in to IOC. </p><br /><h3>IMOD-34572 Add the UKVI IOL SELT products to the product acceptance table for all ROs that accept IOL </h3><p><strong>Purpose:</strong><br />ROs need to be selectable for UKVI SELT IOL results delivery so that the test taker can send their SELT results to any RO’ . This is to retro-fit SELT IOL acceptance for any RO that does not currently have the products in their product acceptance table. All newly created ROs will have this product acceptance set automatically if they opt in to IOL. </p><br /><h2>Technical Features</h2><h3>IMOD-41923 RO : Automation script for hierarchy sheet </h3><p><strong>Purpose:</strong><br />Create script to prepare RO hierarchy sheet with org ids as needed for actual hierarchy update .</p><br /> ([06ef38e](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/06ef38e0dce7a1f410ca0d397dfc48be4d4ad765))

### [3.3.49-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.48...v3.3.49-hotfix.1) (2023-06-09)

### [3.3.48](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.47...v3.3.48) (2023-05-25)

### [3.3.47](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.46...v3.3.47) (2023-05-24)

### [3.3.46](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.45...v3.3.46) (2023-05-23)


### ⚠ BREAKING CHANGES

* IMOD-44258 ro dist ui lambda event serialization changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!254

* Merge branch 'feature/IMOD-44258-RO-Dist-Event-Serialisation' into 'develop' ([443f730](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/443f73094247189aceb0f4472f340be922ab0ba5))

### [3.3.45](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.44...v3.3.45) (2023-04-26)


### ⚠ BREAKING CHANGES

* feature/IMOD_43700_and_43708_user_group_hierarchy

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!256

* Merge branch 'feature/IMOD_43700_and_43708_user_group_hierarchy' into 'develop' ([86de221](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/86de221d144aa9aea5a6cfe6f002a8403e3dca23))

### [3.3.44](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.43...v3.3.44) (2023-03-30)

### [3.3.43](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.42...v3.3.43) (2023-03-21)

### [3.3.42](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.41...v3.3.42) (2023-03-15)


### ⚠ BREAKING CHANGES

* Deleted Ro-CHANGED-DIST-ORS lambda

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!248

* Merge branch 'feature/deletion_of_RO_CHANGED-ORS_lambda' into 'develop' ([bd76a26](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/bd76a2611a72f1936e54667347b2ba43fe087d40))

### [3.3.41](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.40...v3.3.41) (2023-03-09)


### ⚠ BREAKING CHANGES

* feature/IMOD_42691_add_other_territory_option

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!246

* Merge branch 'feature/IMOD_42691_add_other_territory_option' into 'develop' ([8d654ca](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/8d654cabc2d139064455c3e4364bb84a11987fbf))

### [3.3.40](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.39...v3.3.40) (2023-03-08)

### [3.3.39](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.38...v3.3.39) (2023-02-01)


### ⚠ BREAKING CHANGES

* IMOD-40797-staging-changes

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!241

* Merge branch 'feature/IMOD-40797-staging-changes' into 'develop' ([b884e7b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/b884e7b957e8c33266559dc6d01537c86eac47fe))

### [3.3.38](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.37...v3.3.38) (2023-01-24)


### ⚠ BREAKING CHANGES

* feature/Alter_location_table_eventdateTime

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!240

* Merge branch 'feature/Alter_location_table_eventdateTime' into 'develop' ([7344fda](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/7344fda1177ac45147b164f7617475f96e2123b3))

### [3.3.37](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.36...v3.3.37) (2023-01-24)

### [3.3.36](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.35...v3.3.36) (2023-01-23)

### [3.3.35](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.34...v3.3.35) (2023-01-23)

### [3.3.34](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.33...v3.3.34) (2023-01-20)


### ⚠ BREAKING CHANGES

* feature/IMOD_36271_updating_available_to_date

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!238

* Merge branch 'feature/IMOD_36271_updating_available_to_date' into 'develop' ([a97c0bc](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/a97c0bc0347b33ed4f5a13e41cbd83ef93923832))

### [3.3.33](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.32...v3.3.33) (2023-01-19)

### [3.3.32](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.31...v3.3.32) (2022-11-07)

### [3.3.31](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.30...v3.3.31) (2022-10-27)


### ⚠ BREAKING CHANGES

* changes-to-fix-region-issue

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!230

* Merge branch 'feature/fix-region-issue' into 'develop' ([e1bb4b5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/e1bb4b588c797adf4f3561c83ac8ddb7afe28067))

### [3.3.30](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.29...v3.3.30) (2022-10-12)

### [3.3.29](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.28...v3.3.29) (2022-09-21)

### [3.3.28](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.27...v3.3.28) (2022-09-20)


### ⚠ BREAKING CHANGES

* Feature/imod 30431 change in event failure payload

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!215

### Bug Fixes

* IMOD-30151 Incorrect Additional Delivery Org List Displayed in Add RO Screen After Removing/Changing the Parent ([937f4e9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/937f4e9fc21616902e554b00b5a8ecee02804fd6))


* Merge branch 'feature/IMOD-30431_change_in_event_failure_payload' into 'develop' ([036a835](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/036a8350ea8f0a74e7715db9c7ffafbb86cab29b))

### [3.3.27](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.26...v3.3.27) (2022-09-19)

### [3.3.26](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.25...v3.3.26) (2022-09-13)


### ⚠ BREAKING CHANGES

* Feature/create version from develop

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!223

### Bug Fixes

* Fix for Negetive flow in update load RO scripts ( IMOD-27314 Unable to get the S3 bucket Report for Negative Hierarchy LoadRO Testing , IMOD-27312 Created RO with Duplicate Org ID using Load RO Sheet) ([8e90cf3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/8e90cf384395dbafc697ea142be340ffe37e760c))
* IMOD-13617 Update organization names in LPR ([4c85b12](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/4c85b120e81e658c07d1ce0f80916be619830c00))


* Merge branch 'feature/create_version_from_develop' into 'develop' ([8d4c262](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/8d4c262a1ca9ca1cb63135e04d18fa2d35551b9e))

### [3.3.25](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.24...v3.3.25) (2022-09-09)


### ⚠ BREAKING CHANGES

* Feature/imod 35469 org

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!221

### Bug Fixes

* Correcting json for product characteristics for UKVI products ([422b281](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/422b281ed53dcab59f7e9b5a3c2f72affbdc3be8))


* Merge branch 'feature/IMOD-35469_org_id' into 'develop' ([2cf2961](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/2cf29617648b756b72fa3cdb0474e6bb5292bf3a))

### [3.3.24](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.23...v3.3.24) (2022-09-05)

### [3.3.23](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.22...v3.3.23) (2022-09-02)


### ⚠ BREAKING CHANGES

* Feature/imod-26310_guaranteed_delivery

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!194

* Merge branch 'feature/IMOD-26310_guaranteed_delivery' into 'develop' ([96d60bd](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/96d60bd8adb7458bfea95e9e2de11738589eeeac))

### [3.3.22](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.21...v3.3.22) (2022-08-30)


### Bug Fixes

* IMOD-34781 CMDS-IDP-SIT: IELTS SSR Online General Training products 'available_to_date' is showing in the future where it should be a past date ([78e3ed5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/78e3ed5160779ca6f0ee31ed4045ad525a5ca7bf))
* IMOD-34783 : CMDS-IDP-SIT: Effective_To_Date is not updated in the Recognised Product table of RD MX when RO opted-out of IOL and SSR ([7ca7727](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/7ca77276b01d1ccb9ba8f797da4236b1af5b6264))

### [3.3.21](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.20...v3.3.21) (2022-08-26)


### Bug Fixes

* IMOD-33779- CMDS-IDP-SIT - Additional Delivery Organisation is not added properly while removing a parent id and adding the same parent id to a RO ([c3c7c72](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/c3c7c72abff9281463341052b02100425f8770ab))


### Features

* IMOD-34113 Adding UKVI products ([c8b0bd8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/c8b0bd8405bf7396b2e70cd8dbe434006a7138d7))

### [3.3.20](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.19...v3.3.20) (2022-08-17)

### [3.3.19](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.18...v3.3.19) (2022-08-11)

### [3.3.18](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.17...v3.3.18) (2022-08-10)

### [3.3.17](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.16...v3.3.17) (2022-08-02)

### [3.3.16](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.15...v3.3.16) (2022-07-18)

### [3.3.15](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.14...v3.3.15) (2022-07-18)

### [3.3.14](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.13...v3.3.14) (2022-06-28)

### [3.3.13](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.12...v3.3.13) (2022-06-14)

### [3.3.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.11...v3.3.12) (2022-06-08)

### [3.3.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.10...v3.3.11) (2022-05-23)

### [3.3.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.9...v3.3.10) (2022-05-05)


### ⚠ BREAKING CHANGES

* Feature/imod-28922_vo_not_selectable_on_ors_flag

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!186

* Merge branch 'feature/IMOD-28922_VO_not_selectable_on_ORSflag' into 'develop' ([cd8331b](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/cd8331b13d91e067fa0ec0183ebace5160f62b5f))

### [3.3.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.8...v3.3.9) (2022-05-04)

### [3.3.8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.7...v3.3.8) (2022-04-28)


### ⚠ BREAKING CHANGES

* Feature/imod-21179_identify_child_ros

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!184

* Merge branch 'feature/IMOD-21179_identify_child_ros' into 'develop' ([0184281](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/01842812612b48139360c92f36ce24dfedb2124c))

### [3.3.7](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.6...v3.3.7) (2022-04-18)


### Bug Fixes

* **service:** Duplicate org Id records from csv file are validated ([4923e74](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/4923e744fb29feea6723d5128e92f9063d77df09))


### Features

* **database:** feature/IMOD-27949 Amending product GT effective to date ([9edfca8](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/9edfca81a058a4cfd0111b57d527daab22e589d0))

### [3.3.4-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.3...v3.3.4-hotfix.1) (2022-04-01)

### [3.3.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.5...v3.3.6) (2022-04-04)


### ⚠ BREAKING CHANGES

* DB CI CD implementation

See merge request ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation!174

* Merge branch 'feature/IMOD-22892_db_pipeline' into 'develop' ([7724337](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/commit/77243378f87c342cefe706a8316649a6d2f435ee))

### [3.3.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.4...v3.3.5) (2022-03-25)

### [3.3.4-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.3...v3.3.4-hotfix.1) (2022-04-01)

### [3.3.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.3...v3.3.4) (2022-03-25)

### [3.3.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.2...v3.3.3) (2022-03-22)

### [3.3.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.1...v3.3.2) (2022-03-21)

### [3.3.1](https://git-us-east1-c.ci-gateway.int.gprd.gitlab.net:8989/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.3.0...v3.3.1) (2022-03-15)

## [3.3.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.24...v3.3.0) (2022-03-12)

### [3.2.24](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.23...v3.2.24) (2022-03-11)

### [3.2.23](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.22...v3.2.23) (2022-02-25)

### [3.2.22](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.21...v3.2.22) (2022-02-23)

### [3.2.21](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.20...v3.2.21) (2022-02-22)

### [3.2.20](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.19...v3.2.20) (2022-02-15)

### [3.2.19](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.18...v3.2.19) (2022-02-11)

### [3.2.18](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.17...v3.2.18) (2022-02-10)

### [3.2.17](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.16...v3.2.17) (2022-02-08)

### [3.2.16](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.15...v3.2.16) (2022-02-08)

### [3.2.15](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.14...v3.2.15) (2022-02-01)

### [3.2.14](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.13...v3.2.14) (2022-01-27)

### [3.2.13](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.12...v3.2.13) (2022-01-17)

### [3.2.12](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.11...v3.2.12) (2022-01-12)

### [3.2.11](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.10...v3.2.11) (2022-01-07)

### [3.2.10](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.9...v3.2.10) (2022-01-04)

### [3.2.9](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.8...v3.2.9) (2022-01-04)

### [3.2.9-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.8...v3.2.9-hotfix.1) (2021-12-24)

### [3.2.7-hotfix.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.7-hotfix.1...v3.2.7-hotfix.2) (2021-12-17)

### [3.2.7-hotfix.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.6...v3.2.7-hotfix.1) (2021-12-09)

### [3.2.6](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.5...v3.2.6) (2021-11-17)

### [3.2.5](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.4...v3.2.5) (2021-11-16)

### [3.2.4](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.3...v3.2.4) (2021-11-15)

### [3.2.3](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.2...v3.2.3) (2021-11-03)

### [3.2.2](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.1...v3.2.2) (2021-11-03)

### [3.2.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.2.0...v3.2.1) (2021-11-01)

## [3.2.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.1.0...v3.2.0) (2021-10-28)

## [3.1.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.0.1...v3.1.0) (2021-10-05)

### [3.0.1](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v3.0.0...v3.0.1) (2021-08-10)

## [3.0.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v2.0.0...v3.0.0) (2021-08-03)

## [2.0.0](https://gitlab.com/ielts-cmds/IELTS-CMDS-services-grp/cmds-organisation/compare/v1.0.0...v2.0.0) (2021-07-16)

## 1.0.0 (2021-07-06)
